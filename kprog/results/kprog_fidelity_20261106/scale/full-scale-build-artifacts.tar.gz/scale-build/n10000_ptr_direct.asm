
/workspaces/repository/kprog/fidelity/build-x86/scale/n10000_ptr_direct.native.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <entry>:
       0:	48 8b 37                                        	mov    rsi,QWORD PTR [rdi]
       3:	48 8b 57 08                                     	mov    rdx,QWORD PTR [rdi+0x8]
       7:	48 8d 46 10                                     	lea    rax,[rsi+0x10]
       b:	48 39 d0                                        	cmp    rax,rdx
       e:	0f 87 a4 9c 00 00                               	ja     9cb8 <bad>
      14:	44 0f b6 4e 08                                  	movzx  r9d,BYTE PTR [rsi+0x8]
      19:	41 b8 07 00 00 00                               	mov    r8d,0x7
      1f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
      24:	4d 01 d0                                        	add    r8,r10
      27:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
      2c:	4d 01 d0                                        	add    r8,r10
      2f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
      34:	4d 01 d0                                        	add    r8,r10
      37:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
      3c:	4d 01 d0                                        	add    r8,r10
      3f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
      44:	4d 01 d0                                        	add    r8,r10
      47:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
      4c:	4d 01 d0                                        	add    r8,r10
      4f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
      54:	4d 01 d0                                        	add    r8,r10
      57:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
      5c:	4d 01 d0                                        	add    r8,r10
      5f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
      64:	4d 01 d0                                        	add    r8,r10
      67:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
      6c:	4d 01 d0                                        	add    r8,r10
      6f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
      74:	4d 01 d0                                        	add    r8,r10
      77:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
      7c:	4d 01 d0                                        	add    r8,r10
      7f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
      84:	4d 01 d0                                        	add    r8,r10
      87:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
      8c:	4d 01 d0                                        	add    r8,r10
      8f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
      94:	4d 01 d0                                        	add    r8,r10
      97:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
      9c:	4d 01 d0                                        	add    r8,r10
      9f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
      a4:	4d 01 d0                                        	add    r8,r10
      a7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
      ac:	4d 01 d0                                        	add    r8,r10
      af:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
      b4:	4d 01 d0                                        	add    r8,r10
      b7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
      bc:	4d 01 d0                                        	add    r8,r10
      bf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
      c4:	4d 01 d0                                        	add    r8,r10
      c7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
      cc:	4d 01 d0                                        	add    r8,r10
      cf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
      d4:	4d 01 d0                                        	add    r8,r10
      d7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
      dc:	4d 01 d0                                        	add    r8,r10
      df:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
      e4:	4d 01 d0                                        	add    r8,r10
      e7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
      ec:	4d 01 d0                                        	add    r8,r10
      ef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
      f4:	4d 01 d0                                        	add    r8,r10
      f7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
      fc:	4d 01 d0                                        	add    r8,r10
      ff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     104:	4d 01 d0                                        	add    r8,r10
     107:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     10c:	4d 01 d0                                        	add    r8,r10
     10f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     114:	4d 01 d0                                        	add    r8,r10
     117:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     11c:	4d 01 d0                                        	add    r8,r10
     11f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     124:	4d 01 d0                                        	add    r8,r10
     127:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     12c:	4d 01 d0                                        	add    r8,r10
     12f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     134:	4d 01 d0                                        	add    r8,r10
     137:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     13c:	4d 01 d0                                        	add    r8,r10
     13f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     144:	4d 01 d0                                        	add    r8,r10
     147:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     14c:	4d 01 d0                                        	add    r8,r10
     14f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     154:	4d 01 d0                                        	add    r8,r10
     157:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     15c:	4d 01 d0                                        	add    r8,r10
     15f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     164:	4d 01 d0                                        	add    r8,r10
     167:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     16c:	4d 01 d0                                        	add    r8,r10
     16f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     174:	4d 01 d0                                        	add    r8,r10
     177:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     17c:	4d 01 d0                                        	add    r8,r10
     17f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     184:	4d 01 d0                                        	add    r8,r10
     187:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     18c:	4d 01 d0                                        	add    r8,r10
     18f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     194:	4d 01 d0                                        	add    r8,r10
     197:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     19c:	4d 01 d0                                        	add    r8,r10
     19f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     1a4:	4d 01 d0                                        	add    r8,r10
     1a7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     1ac:	4d 01 d0                                        	add    r8,r10
     1af:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     1b4:	4d 01 d0                                        	add    r8,r10
     1b7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     1bc:	4d 01 d0                                        	add    r8,r10
     1bf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     1c4:	4d 01 d0                                        	add    r8,r10
     1c7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     1cc:	4d 01 d0                                        	add    r8,r10
     1cf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     1d4:	4d 01 d0                                        	add    r8,r10
     1d7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     1dc:	4d 01 d0                                        	add    r8,r10
     1df:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     1e4:	4d 01 d0                                        	add    r8,r10
     1e7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     1ec:	4d 01 d0                                        	add    r8,r10
     1ef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     1f4:	4d 01 d0                                        	add    r8,r10
     1f7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     1fc:	4d 01 d0                                        	add    r8,r10
     1ff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     204:	4d 01 d0                                        	add    r8,r10
     207:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     20c:	4d 01 d0                                        	add    r8,r10
     20f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     214:	4d 01 d0                                        	add    r8,r10
     217:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     21c:	4d 01 d0                                        	add    r8,r10
     21f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     224:	4d 01 d0                                        	add    r8,r10
     227:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     22c:	4d 01 d0                                        	add    r8,r10
     22f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     234:	4d 01 d0                                        	add    r8,r10
     237:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     23c:	4d 01 d0                                        	add    r8,r10
     23f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     244:	4d 01 d0                                        	add    r8,r10
     247:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     24c:	4d 01 d0                                        	add    r8,r10
     24f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     254:	4d 01 d0                                        	add    r8,r10
     257:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     25c:	4d 01 d0                                        	add    r8,r10
     25f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     264:	4d 01 d0                                        	add    r8,r10
     267:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     26c:	4d 01 d0                                        	add    r8,r10
     26f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     274:	4d 01 d0                                        	add    r8,r10
     277:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     27c:	4d 01 d0                                        	add    r8,r10
     27f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     284:	4d 01 d0                                        	add    r8,r10
     287:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     28c:	4d 01 d0                                        	add    r8,r10
     28f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     294:	4d 01 d0                                        	add    r8,r10
     297:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     29c:	4d 01 d0                                        	add    r8,r10
     29f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     2a4:	4d 01 d0                                        	add    r8,r10
     2a7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     2ac:	4d 01 d0                                        	add    r8,r10
     2af:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     2b4:	4d 01 d0                                        	add    r8,r10
     2b7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     2bc:	4d 01 d0                                        	add    r8,r10
     2bf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     2c4:	4d 01 d0                                        	add    r8,r10
     2c7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     2cc:	4d 01 d0                                        	add    r8,r10
     2cf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     2d4:	4d 01 d0                                        	add    r8,r10
     2d7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     2dc:	4d 01 d0                                        	add    r8,r10
     2df:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     2e4:	4d 01 d0                                        	add    r8,r10
     2e7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     2ec:	4d 01 d0                                        	add    r8,r10
     2ef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     2f4:	4d 01 d0                                        	add    r8,r10
     2f7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     2fc:	4d 01 d0                                        	add    r8,r10
     2ff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     304:	4d 01 d0                                        	add    r8,r10
     307:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     30c:	4d 01 d0                                        	add    r8,r10
     30f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     314:	4d 01 d0                                        	add    r8,r10
     317:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     31c:	4d 01 d0                                        	add    r8,r10
     31f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     324:	4d 01 d0                                        	add    r8,r10
     327:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     32c:	4d 01 d0                                        	add    r8,r10
     32f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     334:	4d 01 d0                                        	add    r8,r10
     337:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     33c:	4d 01 d0                                        	add    r8,r10
     33f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     344:	4d 01 d0                                        	add    r8,r10
     347:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     34c:	4d 01 d0                                        	add    r8,r10
     34f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     354:	4d 01 d0                                        	add    r8,r10
     357:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     35c:	4d 01 d0                                        	add    r8,r10
     35f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     364:	4d 01 d0                                        	add    r8,r10
     367:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     36c:	4d 01 d0                                        	add    r8,r10
     36f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     374:	4d 01 d0                                        	add    r8,r10
     377:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     37c:	4d 01 d0                                        	add    r8,r10
     37f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     384:	4d 01 d0                                        	add    r8,r10
     387:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     38c:	4d 01 d0                                        	add    r8,r10
     38f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     394:	4d 01 d0                                        	add    r8,r10
     397:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     39c:	4d 01 d0                                        	add    r8,r10
     39f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     3a4:	4d 01 d0                                        	add    r8,r10
     3a7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     3ac:	4d 01 d0                                        	add    r8,r10
     3af:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     3b4:	4d 01 d0                                        	add    r8,r10
     3b7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     3bc:	4d 01 d0                                        	add    r8,r10
     3bf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     3c4:	4d 01 d0                                        	add    r8,r10
     3c7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     3cc:	4d 01 d0                                        	add    r8,r10
     3cf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     3d4:	4d 01 d0                                        	add    r8,r10
     3d7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     3dc:	4d 01 d0                                        	add    r8,r10
     3df:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     3e4:	4d 01 d0                                        	add    r8,r10
     3e7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     3ec:	4d 01 d0                                        	add    r8,r10
     3ef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     3f4:	4d 01 d0                                        	add    r8,r10
     3f7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     3fc:	4d 01 d0                                        	add    r8,r10
     3ff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     404:	4d 01 d0                                        	add    r8,r10
     407:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     40c:	4d 01 d0                                        	add    r8,r10
     40f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     414:	4d 01 d0                                        	add    r8,r10
     417:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     41c:	4d 01 d0                                        	add    r8,r10
     41f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     424:	4d 01 d0                                        	add    r8,r10
     427:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     42c:	4d 01 d0                                        	add    r8,r10
     42f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     434:	4d 01 d0                                        	add    r8,r10
     437:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     43c:	4d 01 d0                                        	add    r8,r10
     43f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     444:	4d 01 d0                                        	add    r8,r10
     447:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     44c:	4d 01 d0                                        	add    r8,r10
     44f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     454:	4d 01 d0                                        	add    r8,r10
     457:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     45c:	4d 01 d0                                        	add    r8,r10
     45f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     464:	4d 01 d0                                        	add    r8,r10
     467:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     46c:	4d 01 d0                                        	add    r8,r10
     46f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     474:	4d 01 d0                                        	add    r8,r10
     477:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     47c:	4d 01 d0                                        	add    r8,r10
     47f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     484:	4d 01 d0                                        	add    r8,r10
     487:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     48c:	4d 01 d0                                        	add    r8,r10
     48f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     494:	4d 01 d0                                        	add    r8,r10
     497:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     49c:	4d 01 d0                                        	add    r8,r10
     49f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     4a4:	4d 01 d0                                        	add    r8,r10
     4a7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     4ac:	4d 01 d0                                        	add    r8,r10
     4af:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     4b4:	4d 01 d0                                        	add    r8,r10
     4b7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     4bc:	4d 01 d0                                        	add    r8,r10
     4bf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     4c4:	4d 01 d0                                        	add    r8,r10
     4c7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     4cc:	4d 01 d0                                        	add    r8,r10
     4cf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     4d4:	4d 01 d0                                        	add    r8,r10
     4d7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     4dc:	4d 01 d0                                        	add    r8,r10
     4df:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     4e4:	4d 01 d0                                        	add    r8,r10
     4e7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     4ec:	4d 01 d0                                        	add    r8,r10
     4ef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     4f4:	4d 01 d0                                        	add    r8,r10
     4f7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     4fc:	4d 01 d0                                        	add    r8,r10
     4ff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     504:	4d 01 d0                                        	add    r8,r10
     507:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     50c:	4d 01 d0                                        	add    r8,r10
     50f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     514:	4d 01 d0                                        	add    r8,r10
     517:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     51c:	4d 01 d0                                        	add    r8,r10
     51f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     524:	4d 01 d0                                        	add    r8,r10
     527:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     52c:	4d 01 d0                                        	add    r8,r10
     52f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     534:	4d 01 d0                                        	add    r8,r10
     537:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     53c:	4d 01 d0                                        	add    r8,r10
     53f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     544:	4d 01 d0                                        	add    r8,r10
     547:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     54c:	4d 01 d0                                        	add    r8,r10
     54f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     554:	4d 01 d0                                        	add    r8,r10
     557:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     55c:	4d 01 d0                                        	add    r8,r10
     55f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     564:	4d 01 d0                                        	add    r8,r10
     567:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     56c:	4d 01 d0                                        	add    r8,r10
     56f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     574:	4d 01 d0                                        	add    r8,r10
     577:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     57c:	4d 01 d0                                        	add    r8,r10
     57f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     584:	4d 01 d0                                        	add    r8,r10
     587:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     58c:	4d 01 d0                                        	add    r8,r10
     58f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     594:	4d 01 d0                                        	add    r8,r10
     597:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     59c:	4d 01 d0                                        	add    r8,r10
     59f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     5a4:	4d 01 d0                                        	add    r8,r10
     5a7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     5ac:	4d 01 d0                                        	add    r8,r10
     5af:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     5b4:	4d 01 d0                                        	add    r8,r10
     5b7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     5bc:	4d 01 d0                                        	add    r8,r10
     5bf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     5c4:	4d 01 d0                                        	add    r8,r10
     5c7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     5cc:	4d 01 d0                                        	add    r8,r10
     5cf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     5d4:	4d 01 d0                                        	add    r8,r10
     5d7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     5dc:	4d 01 d0                                        	add    r8,r10
     5df:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     5e4:	4d 01 d0                                        	add    r8,r10
     5e7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     5ec:	4d 01 d0                                        	add    r8,r10
     5ef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     5f4:	4d 01 d0                                        	add    r8,r10
     5f7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     5fc:	4d 01 d0                                        	add    r8,r10
     5ff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     604:	4d 01 d0                                        	add    r8,r10
     607:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     60c:	4d 01 d0                                        	add    r8,r10
     60f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     614:	4d 01 d0                                        	add    r8,r10
     617:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     61c:	4d 01 d0                                        	add    r8,r10
     61f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     624:	4d 01 d0                                        	add    r8,r10
     627:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     62c:	4d 01 d0                                        	add    r8,r10
     62f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     634:	4d 01 d0                                        	add    r8,r10
     637:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     63c:	4d 01 d0                                        	add    r8,r10
     63f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     644:	4d 01 d0                                        	add    r8,r10
     647:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     64c:	4d 01 d0                                        	add    r8,r10
     64f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     654:	4d 01 d0                                        	add    r8,r10
     657:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     65c:	4d 01 d0                                        	add    r8,r10
     65f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     664:	4d 01 d0                                        	add    r8,r10
     667:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     66c:	4d 01 d0                                        	add    r8,r10
     66f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     674:	4d 01 d0                                        	add    r8,r10
     677:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     67c:	4d 01 d0                                        	add    r8,r10
     67f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     684:	4d 01 d0                                        	add    r8,r10
     687:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     68c:	4d 01 d0                                        	add    r8,r10
     68f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     694:	4d 01 d0                                        	add    r8,r10
     697:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     69c:	4d 01 d0                                        	add    r8,r10
     69f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     6a4:	4d 01 d0                                        	add    r8,r10
     6a7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     6ac:	4d 01 d0                                        	add    r8,r10
     6af:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     6b4:	4d 01 d0                                        	add    r8,r10
     6b7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     6bc:	4d 01 d0                                        	add    r8,r10
     6bf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     6c4:	4d 01 d0                                        	add    r8,r10
     6c7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     6cc:	4d 01 d0                                        	add    r8,r10
     6cf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     6d4:	4d 01 d0                                        	add    r8,r10
     6d7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     6dc:	4d 01 d0                                        	add    r8,r10
     6df:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     6e4:	4d 01 d0                                        	add    r8,r10
     6e7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     6ec:	4d 01 d0                                        	add    r8,r10
     6ef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     6f4:	4d 01 d0                                        	add    r8,r10
     6f7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     6fc:	4d 01 d0                                        	add    r8,r10
     6ff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     704:	4d 01 d0                                        	add    r8,r10
     707:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     70c:	4d 01 d0                                        	add    r8,r10
     70f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     714:	4d 01 d0                                        	add    r8,r10
     717:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     71c:	4d 01 d0                                        	add    r8,r10
     71f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     724:	4d 01 d0                                        	add    r8,r10
     727:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     72c:	4d 01 d0                                        	add    r8,r10
     72f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     734:	4d 01 d0                                        	add    r8,r10
     737:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     73c:	4d 01 d0                                        	add    r8,r10
     73f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     744:	4d 01 d0                                        	add    r8,r10
     747:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     74c:	4d 01 d0                                        	add    r8,r10
     74f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     754:	4d 01 d0                                        	add    r8,r10
     757:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     75c:	4d 01 d0                                        	add    r8,r10
     75f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     764:	4d 01 d0                                        	add    r8,r10
     767:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     76c:	4d 01 d0                                        	add    r8,r10
     76f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     774:	4d 01 d0                                        	add    r8,r10
     777:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     77c:	4d 01 d0                                        	add    r8,r10
     77f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     784:	4d 01 d0                                        	add    r8,r10
     787:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     78c:	4d 01 d0                                        	add    r8,r10
     78f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     794:	4d 01 d0                                        	add    r8,r10
     797:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     79c:	4d 01 d0                                        	add    r8,r10
     79f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     7a4:	4d 01 d0                                        	add    r8,r10
     7a7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     7ac:	4d 01 d0                                        	add    r8,r10
     7af:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     7b4:	4d 01 d0                                        	add    r8,r10
     7b7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     7bc:	4d 01 d0                                        	add    r8,r10
     7bf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     7c4:	4d 01 d0                                        	add    r8,r10
     7c7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     7cc:	4d 01 d0                                        	add    r8,r10
     7cf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     7d4:	4d 01 d0                                        	add    r8,r10
     7d7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     7dc:	4d 01 d0                                        	add    r8,r10
     7df:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     7e4:	4d 01 d0                                        	add    r8,r10
     7e7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     7ec:	4d 01 d0                                        	add    r8,r10
     7ef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     7f4:	4d 01 d0                                        	add    r8,r10
     7f7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     7fc:	4d 01 d0                                        	add    r8,r10
     7ff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     804:	4d 01 d0                                        	add    r8,r10
     807:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     80c:	4d 01 d0                                        	add    r8,r10
     80f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     814:	4d 01 d0                                        	add    r8,r10
     817:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     81c:	4d 01 d0                                        	add    r8,r10
     81f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     824:	4d 01 d0                                        	add    r8,r10
     827:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     82c:	4d 01 d0                                        	add    r8,r10
     82f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     834:	4d 01 d0                                        	add    r8,r10
     837:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     83c:	4d 01 d0                                        	add    r8,r10
     83f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     844:	4d 01 d0                                        	add    r8,r10
     847:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     84c:	4d 01 d0                                        	add    r8,r10
     84f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     854:	4d 01 d0                                        	add    r8,r10
     857:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     85c:	4d 01 d0                                        	add    r8,r10
     85f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     864:	4d 01 d0                                        	add    r8,r10
     867:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     86c:	4d 01 d0                                        	add    r8,r10
     86f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     874:	4d 01 d0                                        	add    r8,r10
     877:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     87c:	4d 01 d0                                        	add    r8,r10
     87f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     884:	4d 01 d0                                        	add    r8,r10
     887:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     88c:	4d 01 d0                                        	add    r8,r10
     88f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     894:	4d 01 d0                                        	add    r8,r10
     897:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     89c:	4d 01 d0                                        	add    r8,r10
     89f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     8a4:	4d 01 d0                                        	add    r8,r10
     8a7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     8ac:	4d 01 d0                                        	add    r8,r10
     8af:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     8b4:	4d 01 d0                                        	add    r8,r10
     8b7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     8bc:	4d 01 d0                                        	add    r8,r10
     8bf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     8c4:	4d 01 d0                                        	add    r8,r10
     8c7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     8cc:	4d 01 d0                                        	add    r8,r10
     8cf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     8d4:	4d 01 d0                                        	add    r8,r10
     8d7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     8dc:	4d 01 d0                                        	add    r8,r10
     8df:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     8e4:	4d 01 d0                                        	add    r8,r10
     8e7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     8ec:	4d 01 d0                                        	add    r8,r10
     8ef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     8f4:	4d 01 d0                                        	add    r8,r10
     8f7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     8fc:	4d 01 d0                                        	add    r8,r10
     8ff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     904:	4d 01 d0                                        	add    r8,r10
     907:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     90c:	4d 01 d0                                        	add    r8,r10
     90f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     914:	4d 01 d0                                        	add    r8,r10
     917:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     91c:	4d 01 d0                                        	add    r8,r10
     91f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     924:	4d 01 d0                                        	add    r8,r10
     927:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     92c:	4d 01 d0                                        	add    r8,r10
     92f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     934:	4d 01 d0                                        	add    r8,r10
     937:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     93c:	4d 01 d0                                        	add    r8,r10
     93f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     944:	4d 01 d0                                        	add    r8,r10
     947:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     94c:	4d 01 d0                                        	add    r8,r10
     94f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     954:	4d 01 d0                                        	add    r8,r10
     957:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     95c:	4d 01 d0                                        	add    r8,r10
     95f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     964:	4d 01 d0                                        	add    r8,r10
     967:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     96c:	4d 01 d0                                        	add    r8,r10
     96f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     974:	4d 01 d0                                        	add    r8,r10
     977:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     97c:	4d 01 d0                                        	add    r8,r10
     97f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     984:	4d 01 d0                                        	add    r8,r10
     987:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     98c:	4d 01 d0                                        	add    r8,r10
     98f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     994:	4d 01 d0                                        	add    r8,r10
     997:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     99c:	4d 01 d0                                        	add    r8,r10
     99f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     9a4:	4d 01 d0                                        	add    r8,r10
     9a7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     9ac:	4d 01 d0                                        	add    r8,r10
     9af:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     9b4:	4d 01 d0                                        	add    r8,r10
     9b7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     9bc:	4d 01 d0                                        	add    r8,r10
     9bf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     9c4:	4d 01 d0                                        	add    r8,r10
     9c7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     9cc:	4d 01 d0                                        	add    r8,r10
     9cf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     9d4:	4d 01 d0                                        	add    r8,r10
     9d7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     9dc:	4d 01 d0                                        	add    r8,r10
     9df:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     9e4:	4d 01 d0                                        	add    r8,r10
     9e7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     9ec:	4d 01 d0                                        	add    r8,r10
     9ef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     9f4:	4d 01 d0                                        	add    r8,r10
     9f7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     9fc:	4d 01 d0                                        	add    r8,r10
     9ff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     a04:	4d 01 d0                                        	add    r8,r10
     a07:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     a0c:	4d 01 d0                                        	add    r8,r10
     a0f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     a14:	4d 01 d0                                        	add    r8,r10
     a17:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     a1c:	4d 01 d0                                        	add    r8,r10
     a1f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     a24:	4d 01 d0                                        	add    r8,r10
     a27:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     a2c:	4d 01 d0                                        	add    r8,r10
     a2f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     a34:	4d 01 d0                                        	add    r8,r10
     a37:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     a3c:	4d 01 d0                                        	add    r8,r10
     a3f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     a44:	4d 01 d0                                        	add    r8,r10
     a47:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     a4c:	4d 01 d0                                        	add    r8,r10
     a4f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     a54:	4d 01 d0                                        	add    r8,r10
     a57:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     a5c:	4d 01 d0                                        	add    r8,r10
     a5f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     a64:	4d 01 d0                                        	add    r8,r10
     a67:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     a6c:	4d 01 d0                                        	add    r8,r10
     a6f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     a74:	4d 01 d0                                        	add    r8,r10
     a77:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     a7c:	4d 01 d0                                        	add    r8,r10
     a7f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     a84:	4d 01 d0                                        	add    r8,r10
     a87:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     a8c:	4d 01 d0                                        	add    r8,r10
     a8f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     a94:	4d 01 d0                                        	add    r8,r10
     a97:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     a9c:	4d 01 d0                                        	add    r8,r10
     a9f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     aa4:	4d 01 d0                                        	add    r8,r10
     aa7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     aac:	4d 01 d0                                        	add    r8,r10
     aaf:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     ab4:	4d 01 d0                                        	add    r8,r10
     ab7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     abc:	4d 01 d0                                        	add    r8,r10
     abf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     ac4:	4d 01 d0                                        	add    r8,r10
     ac7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     acc:	4d 01 d0                                        	add    r8,r10
     acf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     ad4:	4d 01 d0                                        	add    r8,r10
     ad7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     adc:	4d 01 d0                                        	add    r8,r10
     adf:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     ae4:	4d 01 d0                                        	add    r8,r10
     ae7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     aec:	4d 01 d0                                        	add    r8,r10
     aef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     af4:	4d 01 d0                                        	add    r8,r10
     af7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     afc:	4d 01 d0                                        	add    r8,r10
     aff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     b04:	4d 01 d0                                        	add    r8,r10
     b07:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     b0c:	4d 01 d0                                        	add    r8,r10
     b0f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     b14:	4d 01 d0                                        	add    r8,r10
     b17:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     b1c:	4d 01 d0                                        	add    r8,r10
     b1f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     b24:	4d 01 d0                                        	add    r8,r10
     b27:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     b2c:	4d 01 d0                                        	add    r8,r10
     b2f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     b34:	4d 01 d0                                        	add    r8,r10
     b37:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     b3c:	4d 01 d0                                        	add    r8,r10
     b3f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     b44:	4d 01 d0                                        	add    r8,r10
     b47:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     b4c:	4d 01 d0                                        	add    r8,r10
     b4f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     b54:	4d 01 d0                                        	add    r8,r10
     b57:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     b5c:	4d 01 d0                                        	add    r8,r10
     b5f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     b64:	4d 01 d0                                        	add    r8,r10
     b67:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     b6c:	4d 01 d0                                        	add    r8,r10
     b6f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     b74:	4d 01 d0                                        	add    r8,r10
     b77:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     b7c:	4d 01 d0                                        	add    r8,r10
     b7f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     b84:	4d 01 d0                                        	add    r8,r10
     b87:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     b8c:	4d 01 d0                                        	add    r8,r10
     b8f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     b94:	4d 01 d0                                        	add    r8,r10
     b97:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     b9c:	4d 01 d0                                        	add    r8,r10
     b9f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     ba4:	4d 01 d0                                        	add    r8,r10
     ba7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     bac:	4d 01 d0                                        	add    r8,r10
     baf:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     bb4:	4d 01 d0                                        	add    r8,r10
     bb7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     bbc:	4d 01 d0                                        	add    r8,r10
     bbf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     bc4:	4d 01 d0                                        	add    r8,r10
     bc7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     bcc:	4d 01 d0                                        	add    r8,r10
     bcf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     bd4:	4d 01 d0                                        	add    r8,r10
     bd7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     bdc:	4d 01 d0                                        	add    r8,r10
     bdf:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     be4:	4d 01 d0                                        	add    r8,r10
     be7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     bec:	4d 01 d0                                        	add    r8,r10
     bef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     bf4:	4d 01 d0                                        	add    r8,r10
     bf7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     bfc:	4d 01 d0                                        	add    r8,r10
     bff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     c04:	4d 01 d0                                        	add    r8,r10
     c07:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     c0c:	4d 01 d0                                        	add    r8,r10
     c0f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     c14:	4d 01 d0                                        	add    r8,r10
     c17:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     c1c:	4d 01 d0                                        	add    r8,r10
     c1f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     c24:	4d 01 d0                                        	add    r8,r10
     c27:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     c2c:	4d 01 d0                                        	add    r8,r10
     c2f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     c34:	4d 01 d0                                        	add    r8,r10
     c37:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     c3c:	4d 01 d0                                        	add    r8,r10
     c3f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     c44:	4d 01 d0                                        	add    r8,r10
     c47:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     c4c:	4d 01 d0                                        	add    r8,r10
     c4f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     c54:	4d 01 d0                                        	add    r8,r10
     c57:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     c5c:	4d 01 d0                                        	add    r8,r10
     c5f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     c64:	4d 01 d0                                        	add    r8,r10
     c67:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     c6c:	4d 01 d0                                        	add    r8,r10
     c6f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     c74:	4d 01 d0                                        	add    r8,r10
     c77:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     c7c:	4d 01 d0                                        	add    r8,r10
     c7f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     c84:	4d 01 d0                                        	add    r8,r10
     c87:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     c8c:	4d 01 d0                                        	add    r8,r10
     c8f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     c94:	4d 01 d0                                        	add    r8,r10
     c97:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     c9c:	4d 01 d0                                        	add    r8,r10
     c9f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     ca4:	4d 01 d0                                        	add    r8,r10
     ca7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     cac:	4d 01 d0                                        	add    r8,r10
     caf:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     cb4:	4d 01 d0                                        	add    r8,r10
     cb7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     cbc:	4d 01 d0                                        	add    r8,r10
     cbf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     cc4:	4d 01 d0                                        	add    r8,r10
     cc7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     ccc:	4d 01 d0                                        	add    r8,r10
     ccf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     cd4:	4d 01 d0                                        	add    r8,r10
     cd7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     cdc:	4d 01 d0                                        	add    r8,r10
     cdf:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     ce4:	4d 01 d0                                        	add    r8,r10
     ce7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     cec:	4d 01 d0                                        	add    r8,r10
     cef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     cf4:	4d 01 d0                                        	add    r8,r10
     cf7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     cfc:	4d 01 d0                                        	add    r8,r10
     cff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     d04:	4d 01 d0                                        	add    r8,r10
     d07:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     d0c:	4d 01 d0                                        	add    r8,r10
     d0f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     d14:	4d 01 d0                                        	add    r8,r10
     d17:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     d1c:	4d 01 d0                                        	add    r8,r10
     d1f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     d24:	4d 01 d0                                        	add    r8,r10
     d27:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     d2c:	4d 01 d0                                        	add    r8,r10
     d2f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     d34:	4d 01 d0                                        	add    r8,r10
     d37:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     d3c:	4d 01 d0                                        	add    r8,r10
     d3f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     d44:	4d 01 d0                                        	add    r8,r10
     d47:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     d4c:	4d 01 d0                                        	add    r8,r10
     d4f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     d54:	4d 01 d0                                        	add    r8,r10
     d57:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     d5c:	4d 01 d0                                        	add    r8,r10
     d5f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     d64:	4d 01 d0                                        	add    r8,r10
     d67:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     d6c:	4d 01 d0                                        	add    r8,r10
     d6f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     d74:	4d 01 d0                                        	add    r8,r10
     d77:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     d7c:	4d 01 d0                                        	add    r8,r10
     d7f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     d84:	4d 01 d0                                        	add    r8,r10
     d87:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     d8c:	4d 01 d0                                        	add    r8,r10
     d8f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     d94:	4d 01 d0                                        	add    r8,r10
     d97:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     d9c:	4d 01 d0                                        	add    r8,r10
     d9f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     da4:	4d 01 d0                                        	add    r8,r10
     da7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     dac:	4d 01 d0                                        	add    r8,r10
     daf:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     db4:	4d 01 d0                                        	add    r8,r10
     db7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     dbc:	4d 01 d0                                        	add    r8,r10
     dbf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     dc4:	4d 01 d0                                        	add    r8,r10
     dc7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     dcc:	4d 01 d0                                        	add    r8,r10
     dcf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     dd4:	4d 01 d0                                        	add    r8,r10
     dd7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     ddc:	4d 01 d0                                        	add    r8,r10
     ddf:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     de4:	4d 01 d0                                        	add    r8,r10
     de7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     dec:	4d 01 d0                                        	add    r8,r10
     def:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     df4:	4d 01 d0                                        	add    r8,r10
     df7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     dfc:	4d 01 d0                                        	add    r8,r10
     dff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     e04:	4d 01 d0                                        	add    r8,r10
     e07:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     e0c:	4d 01 d0                                        	add    r8,r10
     e0f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     e14:	4d 01 d0                                        	add    r8,r10
     e17:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     e1c:	4d 01 d0                                        	add    r8,r10
     e1f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     e24:	4d 01 d0                                        	add    r8,r10
     e27:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     e2c:	4d 01 d0                                        	add    r8,r10
     e2f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     e34:	4d 01 d0                                        	add    r8,r10
     e37:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     e3c:	4d 01 d0                                        	add    r8,r10
     e3f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     e44:	4d 01 d0                                        	add    r8,r10
     e47:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     e4c:	4d 01 d0                                        	add    r8,r10
     e4f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     e54:	4d 01 d0                                        	add    r8,r10
     e57:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     e5c:	4d 01 d0                                        	add    r8,r10
     e5f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     e64:	4d 01 d0                                        	add    r8,r10
     e67:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     e6c:	4d 01 d0                                        	add    r8,r10
     e6f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     e74:	4d 01 d0                                        	add    r8,r10
     e77:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     e7c:	4d 01 d0                                        	add    r8,r10
     e7f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     e84:	4d 01 d0                                        	add    r8,r10
     e87:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     e8c:	4d 01 d0                                        	add    r8,r10
     e8f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     e94:	4d 01 d0                                        	add    r8,r10
     e97:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     e9c:	4d 01 d0                                        	add    r8,r10
     e9f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     ea4:	4d 01 d0                                        	add    r8,r10
     ea7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     eac:	4d 01 d0                                        	add    r8,r10
     eaf:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     eb4:	4d 01 d0                                        	add    r8,r10
     eb7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     ebc:	4d 01 d0                                        	add    r8,r10
     ebf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     ec4:	4d 01 d0                                        	add    r8,r10
     ec7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     ecc:	4d 01 d0                                        	add    r8,r10
     ecf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     ed4:	4d 01 d0                                        	add    r8,r10
     ed7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     edc:	4d 01 d0                                        	add    r8,r10
     edf:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     ee4:	4d 01 d0                                        	add    r8,r10
     ee7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     eec:	4d 01 d0                                        	add    r8,r10
     eef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     ef4:	4d 01 d0                                        	add    r8,r10
     ef7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     efc:	4d 01 d0                                        	add    r8,r10
     eff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     f04:	4d 01 d0                                        	add    r8,r10
     f07:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     f0c:	4d 01 d0                                        	add    r8,r10
     f0f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     f14:	4d 01 d0                                        	add    r8,r10
     f17:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     f1c:	4d 01 d0                                        	add    r8,r10
     f1f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     f24:	4d 01 d0                                        	add    r8,r10
     f27:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     f2c:	4d 01 d0                                        	add    r8,r10
     f2f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     f34:	4d 01 d0                                        	add    r8,r10
     f37:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     f3c:	4d 01 d0                                        	add    r8,r10
     f3f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     f44:	4d 01 d0                                        	add    r8,r10
     f47:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     f4c:	4d 01 d0                                        	add    r8,r10
     f4f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     f54:	4d 01 d0                                        	add    r8,r10
     f57:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     f5c:	4d 01 d0                                        	add    r8,r10
     f5f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     f64:	4d 01 d0                                        	add    r8,r10
     f67:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     f6c:	4d 01 d0                                        	add    r8,r10
     f6f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     f74:	4d 01 d0                                        	add    r8,r10
     f77:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     f7c:	4d 01 d0                                        	add    r8,r10
     f7f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     f84:	4d 01 d0                                        	add    r8,r10
     f87:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     f8c:	4d 01 d0                                        	add    r8,r10
     f8f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     f94:	4d 01 d0                                        	add    r8,r10
     f97:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     f9c:	4d 01 d0                                        	add    r8,r10
     f9f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     fa4:	4d 01 d0                                        	add    r8,r10
     fa7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     fac:	4d 01 d0                                        	add    r8,r10
     faf:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     fb4:	4d 01 d0                                        	add    r8,r10
     fb7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     fbc:	4d 01 d0                                        	add    r8,r10
     fbf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     fc4:	4d 01 d0                                        	add    r8,r10
     fc7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     fcc:	4d 01 d0                                        	add    r8,r10
     fcf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     fd4:	4d 01 d0                                        	add    r8,r10
     fd7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     fdc:	4d 01 d0                                        	add    r8,r10
     fdf:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     fe4:	4d 01 d0                                        	add    r8,r10
     fe7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     fec:	4d 01 d0                                        	add    r8,r10
     fef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     ff4:	4d 01 d0                                        	add    r8,r10
     ff7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     ffc:	4d 01 d0                                        	add    r8,r10
     fff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1004:	4d 01 d0                                        	add    r8,r10
    1007:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    100c:	4d 01 d0                                        	add    r8,r10
    100f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1014:	4d 01 d0                                        	add    r8,r10
    1017:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    101c:	4d 01 d0                                        	add    r8,r10
    101f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1024:	4d 01 d0                                        	add    r8,r10
    1027:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    102c:	4d 01 d0                                        	add    r8,r10
    102f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1034:	4d 01 d0                                        	add    r8,r10
    1037:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    103c:	4d 01 d0                                        	add    r8,r10
    103f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1044:	4d 01 d0                                        	add    r8,r10
    1047:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    104c:	4d 01 d0                                        	add    r8,r10
    104f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1054:	4d 01 d0                                        	add    r8,r10
    1057:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    105c:	4d 01 d0                                        	add    r8,r10
    105f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1064:	4d 01 d0                                        	add    r8,r10
    1067:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    106c:	4d 01 d0                                        	add    r8,r10
    106f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1074:	4d 01 d0                                        	add    r8,r10
    1077:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    107c:	4d 01 d0                                        	add    r8,r10
    107f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1084:	4d 01 d0                                        	add    r8,r10
    1087:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    108c:	4d 01 d0                                        	add    r8,r10
    108f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1094:	4d 01 d0                                        	add    r8,r10
    1097:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    109c:	4d 01 d0                                        	add    r8,r10
    109f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    10a4:	4d 01 d0                                        	add    r8,r10
    10a7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    10ac:	4d 01 d0                                        	add    r8,r10
    10af:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    10b4:	4d 01 d0                                        	add    r8,r10
    10b7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    10bc:	4d 01 d0                                        	add    r8,r10
    10bf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    10c4:	4d 01 d0                                        	add    r8,r10
    10c7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    10cc:	4d 01 d0                                        	add    r8,r10
    10cf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    10d4:	4d 01 d0                                        	add    r8,r10
    10d7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    10dc:	4d 01 d0                                        	add    r8,r10
    10df:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    10e4:	4d 01 d0                                        	add    r8,r10
    10e7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    10ec:	4d 01 d0                                        	add    r8,r10
    10ef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    10f4:	4d 01 d0                                        	add    r8,r10
    10f7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    10fc:	4d 01 d0                                        	add    r8,r10
    10ff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1104:	4d 01 d0                                        	add    r8,r10
    1107:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    110c:	4d 01 d0                                        	add    r8,r10
    110f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1114:	4d 01 d0                                        	add    r8,r10
    1117:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    111c:	4d 01 d0                                        	add    r8,r10
    111f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1124:	4d 01 d0                                        	add    r8,r10
    1127:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    112c:	4d 01 d0                                        	add    r8,r10
    112f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1134:	4d 01 d0                                        	add    r8,r10
    1137:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    113c:	4d 01 d0                                        	add    r8,r10
    113f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1144:	4d 01 d0                                        	add    r8,r10
    1147:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    114c:	4d 01 d0                                        	add    r8,r10
    114f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1154:	4d 01 d0                                        	add    r8,r10
    1157:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    115c:	4d 01 d0                                        	add    r8,r10
    115f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1164:	4d 01 d0                                        	add    r8,r10
    1167:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    116c:	4d 01 d0                                        	add    r8,r10
    116f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1174:	4d 01 d0                                        	add    r8,r10
    1177:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    117c:	4d 01 d0                                        	add    r8,r10
    117f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1184:	4d 01 d0                                        	add    r8,r10
    1187:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    118c:	4d 01 d0                                        	add    r8,r10
    118f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1194:	4d 01 d0                                        	add    r8,r10
    1197:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    119c:	4d 01 d0                                        	add    r8,r10
    119f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    11a4:	4d 01 d0                                        	add    r8,r10
    11a7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    11ac:	4d 01 d0                                        	add    r8,r10
    11af:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    11b4:	4d 01 d0                                        	add    r8,r10
    11b7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    11bc:	4d 01 d0                                        	add    r8,r10
    11bf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    11c4:	4d 01 d0                                        	add    r8,r10
    11c7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    11cc:	4d 01 d0                                        	add    r8,r10
    11cf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    11d4:	4d 01 d0                                        	add    r8,r10
    11d7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    11dc:	4d 01 d0                                        	add    r8,r10
    11df:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    11e4:	4d 01 d0                                        	add    r8,r10
    11e7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    11ec:	4d 01 d0                                        	add    r8,r10
    11ef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    11f4:	4d 01 d0                                        	add    r8,r10
    11f7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    11fc:	4d 01 d0                                        	add    r8,r10
    11ff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1204:	4d 01 d0                                        	add    r8,r10
    1207:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    120c:	4d 01 d0                                        	add    r8,r10
    120f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1214:	4d 01 d0                                        	add    r8,r10
    1217:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    121c:	4d 01 d0                                        	add    r8,r10
    121f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1224:	4d 01 d0                                        	add    r8,r10
    1227:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    122c:	4d 01 d0                                        	add    r8,r10
    122f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1234:	4d 01 d0                                        	add    r8,r10
    1237:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    123c:	4d 01 d0                                        	add    r8,r10
    123f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1244:	4d 01 d0                                        	add    r8,r10
    1247:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    124c:	4d 01 d0                                        	add    r8,r10
    124f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1254:	4d 01 d0                                        	add    r8,r10
    1257:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    125c:	4d 01 d0                                        	add    r8,r10
    125f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1264:	4d 01 d0                                        	add    r8,r10
    1267:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    126c:	4d 01 d0                                        	add    r8,r10
    126f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1274:	4d 01 d0                                        	add    r8,r10
    1277:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    127c:	4d 01 d0                                        	add    r8,r10
    127f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1284:	4d 01 d0                                        	add    r8,r10
    1287:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    128c:	4d 01 d0                                        	add    r8,r10
    128f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1294:	4d 01 d0                                        	add    r8,r10
    1297:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    129c:	4d 01 d0                                        	add    r8,r10
    129f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    12a4:	4d 01 d0                                        	add    r8,r10
    12a7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    12ac:	4d 01 d0                                        	add    r8,r10
    12af:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    12b4:	4d 01 d0                                        	add    r8,r10
    12b7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    12bc:	4d 01 d0                                        	add    r8,r10
    12bf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    12c4:	4d 01 d0                                        	add    r8,r10
    12c7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    12cc:	4d 01 d0                                        	add    r8,r10
    12cf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    12d4:	4d 01 d0                                        	add    r8,r10
    12d7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    12dc:	4d 01 d0                                        	add    r8,r10
    12df:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    12e4:	4d 01 d0                                        	add    r8,r10
    12e7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    12ec:	4d 01 d0                                        	add    r8,r10
    12ef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    12f4:	4d 01 d0                                        	add    r8,r10
    12f7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    12fc:	4d 01 d0                                        	add    r8,r10
    12ff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1304:	4d 01 d0                                        	add    r8,r10
    1307:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    130c:	4d 01 d0                                        	add    r8,r10
    130f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1314:	4d 01 d0                                        	add    r8,r10
    1317:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    131c:	4d 01 d0                                        	add    r8,r10
    131f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1324:	4d 01 d0                                        	add    r8,r10
    1327:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    132c:	4d 01 d0                                        	add    r8,r10
    132f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1334:	4d 01 d0                                        	add    r8,r10
    1337:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    133c:	4d 01 d0                                        	add    r8,r10
    133f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1344:	4d 01 d0                                        	add    r8,r10
    1347:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    134c:	4d 01 d0                                        	add    r8,r10
    134f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1354:	4d 01 d0                                        	add    r8,r10
    1357:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    135c:	4d 01 d0                                        	add    r8,r10
    135f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1364:	4d 01 d0                                        	add    r8,r10
    1367:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    136c:	4d 01 d0                                        	add    r8,r10
    136f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1374:	4d 01 d0                                        	add    r8,r10
    1377:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    137c:	4d 01 d0                                        	add    r8,r10
    137f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1384:	4d 01 d0                                        	add    r8,r10
    1387:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    138c:	4d 01 d0                                        	add    r8,r10
    138f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1394:	4d 01 d0                                        	add    r8,r10
    1397:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    139c:	4d 01 d0                                        	add    r8,r10
    139f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    13a4:	4d 01 d0                                        	add    r8,r10
    13a7:	41 f6 c1 01                                     	test   r9b,0x1
    13ab:	74 04                                           	je     13b1 <join_0>
    13ad:	49 83 f0 01                                     	xor    r8,0x1

00000000000013b1 <join_0>:
    13b1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    13b6:	4d 01 d0                                        	add    r8,r10
    13b9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    13be:	4d 01 d0                                        	add    r8,r10
    13c1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    13c6:	4d 01 d0                                        	add    r8,r10
    13c9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    13ce:	4d 01 d0                                        	add    r8,r10
    13d1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    13d6:	4d 01 d0                                        	add    r8,r10
    13d9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    13de:	4d 01 d0                                        	add    r8,r10
    13e1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    13e6:	4d 01 d0                                        	add    r8,r10
    13e9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    13ee:	4d 01 d0                                        	add    r8,r10
    13f1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    13f6:	4d 01 d0                                        	add    r8,r10
    13f9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    13fe:	4d 01 d0                                        	add    r8,r10
    1401:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1406:	4d 01 d0                                        	add    r8,r10
    1409:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    140e:	4d 01 d0                                        	add    r8,r10
    1411:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1416:	4d 01 d0                                        	add    r8,r10
    1419:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    141e:	4d 01 d0                                        	add    r8,r10
    1421:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1426:	4d 01 d0                                        	add    r8,r10
    1429:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    142e:	4d 01 d0                                        	add    r8,r10
    1431:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1436:	4d 01 d0                                        	add    r8,r10
    1439:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    143e:	4d 01 d0                                        	add    r8,r10
    1441:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1446:	4d 01 d0                                        	add    r8,r10
    1449:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    144e:	4d 01 d0                                        	add    r8,r10
    1451:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1456:	4d 01 d0                                        	add    r8,r10
    1459:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    145e:	4d 01 d0                                        	add    r8,r10
    1461:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1466:	4d 01 d0                                        	add    r8,r10
    1469:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    146e:	4d 01 d0                                        	add    r8,r10
    1471:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1476:	4d 01 d0                                        	add    r8,r10
    1479:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    147e:	4d 01 d0                                        	add    r8,r10
    1481:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1486:	4d 01 d0                                        	add    r8,r10
    1489:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    148e:	4d 01 d0                                        	add    r8,r10
    1491:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1496:	4d 01 d0                                        	add    r8,r10
    1499:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    149e:	4d 01 d0                                        	add    r8,r10
    14a1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    14a6:	4d 01 d0                                        	add    r8,r10
    14a9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    14ae:	4d 01 d0                                        	add    r8,r10
    14b1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    14b6:	4d 01 d0                                        	add    r8,r10
    14b9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    14be:	4d 01 d0                                        	add    r8,r10
    14c1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    14c6:	4d 01 d0                                        	add    r8,r10
    14c9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    14ce:	4d 01 d0                                        	add    r8,r10
    14d1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    14d6:	4d 01 d0                                        	add    r8,r10
    14d9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    14de:	4d 01 d0                                        	add    r8,r10
    14e1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    14e6:	4d 01 d0                                        	add    r8,r10
    14e9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    14ee:	4d 01 d0                                        	add    r8,r10
    14f1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    14f6:	4d 01 d0                                        	add    r8,r10
    14f9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    14fe:	4d 01 d0                                        	add    r8,r10
    1501:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1506:	4d 01 d0                                        	add    r8,r10
    1509:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    150e:	4d 01 d0                                        	add    r8,r10
    1511:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1516:	4d 01 d0                                        	add    r8,r10
    1519:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    151e:	4d 01 d0                                        	add    r8,r10
    1521:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1526:	4d 01 d0                                        	add    r8,r10
    1529:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    152e:	4d 01 d0                                        	add    r8,r10
    1531:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1536:	4d 01 d0                                        	add    r8,r10
    1539:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    153e:	4d 01 d0                                        	add    r8,r10
    1541:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1546:	4d 01 d0                                        	add    r8,r10
    1549:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    154e:	4d 01 d0                                        	add    r8,r10
    1551:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1556:	4d 01 d0                                        	add    r8,r10
    1559:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    155e:	4d 01 d0                                        	add    r8,r10
    1561:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1566:	4d 01 d0                                        	add    r8,r10
    1569:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    156e:	4d 01 d0                                        	add    r8,r10
    1571:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1576:	4d 01 d0                                        	add    r8,r10
    1579:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    157e:	4d 01 d0                                        	add    r8,r10
    1581:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1586:	4d 01 d0                                        	add    r8,r10
    1589:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    158e:	4d 01 d0                                        	add    r8,r10
    1591:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1596:	4d 01 d0                                        	add    r8,r10
    1599:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    159e:	4d 01 d0                                        	add    r8,r10
    15a1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    15a6:	4d 01 d0                                        	add    r8,r10
    15a9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    15ae:	4d 01 d0                                        	add    r8,r10
    15b1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    15b6:	4d 01 d0                                        	add    r8,r10
    15b9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    15be:	4d 01 d0                                        	add    r8,r10
    15c1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    15c6:	4d 01 d0                                        	add    r8,r10
    15c9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    15ce:	4d 01 d0                                        	add    r8,r10
    15d1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    15d6:	4d 01 d0                                        	add    r8,r10
    15d9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    15de:	4d 01 d0                                        	add    r8,r10
    15e1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    15e6:	4d 01 d0                                        	add    r8,r10
    15e9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    15ee:	4d 01 d0                                        	add    r8,r10
    15f1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    15f6:	4d 01 d0                                        	add    r8,r10
    15f9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    15fe:	4d 01 d0                                        	add    r8,r10
    1601:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1606:	4d 01 d0                                        	add    r8,r10
    1609:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    160e:	4d 01 d0                                        	add    r8,r10
    1611:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1616:	4d 01 d0                                        	add    r8,r10
    1619:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    161e:	4d 01 d0                                        	add    r8,r10
    1621:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1626:	4d 01 d0                                        	add    r8,r10
    1629:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    162e:	4d 01 d0                                        	add    r8,r10
    1631:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1636:	4d 01 d0                                        	add    r8,r10
    1639:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    163e:	4d 01 d0                                        	add    r8,r10
    1641:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1646:	4d 01 d0                                        	add    r8,r10
    1649:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    164e:	4d 01 d0                                        	add    r8,r10
    1651:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1656:	4d 01 d0                                        	add    r8,r10
    1659:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    165e:	4d 01 d0                                        	add    r8,r10
    1661:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1666:	4d 01 d0                                        	add    r8,r10
    1669:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    166e:	4d 01 d0                                        	add    r8,r10
    1671:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1676:	4d 01 d0                                        	add    r8,r10
    1679:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    167e:	4d 01 d0                                        	add    r8,r10
    1681:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1686:	4d 01 d0                                        	add    r8,r10
    1689:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    168e:	4d 01 d0                                        	add    r8,r10
    1691:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1696:	4d 01 d0                                        	add    r8,r10
    1699:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    169e:	4d 01 d0                                        	add    r8,r10
    16a1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    16a6:	4d 01 d0                                        	add    r8,r10
    16a9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    16ae:	4d 01 d0                                        	add    r8,r10
    16b1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    16b6:	4d 01 d0                                        	add    r8,r10
    16b9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    16be:	4d 01 d0                                        	add    r8,r10
    16c1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    16c6:	4d 01 d0                                        	add    r8,r10
    16c9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    16ce:	4d 01 d0                                        	add    r8,r10
    16d1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    16d6:	4d 01 d0                                        	add    r8,r10
    16d9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    16de:	4d 01 d0                                        	add    r8,r10
    16e1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    16e6:	4d 01 d0                                        	add    r8,r10
    16e9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    16ee:	4d 01 d0                                        	add    r8,r10
    16f1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    16f6:	4d 01 d0                                        	add    r8,r10
    16f9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    16fe:	4d 01 d0                                        	add    r8,r10
    1701:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1706:	4d 01 d0                                        	add    r8,r10
    1709:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    170e:	4d 01 d0                                        	add    r8,r10
    1711:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1716:	4d 01 d0                                        	add    r8,r10
    1719:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    171e:	4d 01 d0                                        	add    r8,r10
    1721:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1726:	4d 01 d0                                        	add    r8,r10
    1729:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    172e:	4d 01 d0                                        	add    r8,r10
    1731:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1736:	4d 01 d0                                        	add    r8,r10
    1739:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    173e:	4d 01 d0                                        	add    r8,r10
    1741:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1746:	4d 01 d0                                        	add    r8,r10
    1749:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    174e:	4d 01 d0                                        	add    r8,r10
    1751:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1756:	4d 01 d0                                        	add    r8,r10
    1759:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    175e:	4d 01 d0                                        	add    r8,r10
    1761:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1766:	4d 01 d0                                        	add    r8,r10
    1769:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    176e:	4d 01 d0                                        	add    r8,r10
    1771:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1776:	4d 01 d0                                        	add    r8,r10
    1779:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    177e:	4d 01 d0                                        	add    r8,r10
    1781:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1786:	4d 01 d0                                        	add    r8,r10
    1789:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    178e:	4d 01 d0                                        	add    r8,r10
    1791:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1796:	4d 01 d0                                        	add    r8,r10
    1799:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    179e:	4d 01 d0                                        	add    r8,r10
    17a1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    17a6:	4d 01 d0                                        	add    r8,r10
    17a9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    17ae:	4d 01 d0                                        	add    r8,r10
    17b1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    17b6:	4d 01 d0                                        	add    r8,r10
    17b9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    17be:	4d 01 d0                                        	add    r8,r10
    17c1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    17c6:	4d 01 d0                                        	add    r8,r10
    17c9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    17ce:	4d 01 d0                                        	add    r8,r10
    17d1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    17d6:	4d 01 d0                                        	add    r8,r10
    17d9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    17de:	4d 01 d0                                        	add    r8,r10
    17e1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    17e6:	4d 01 d0                                        	add    r8,r10
    17e9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    17ee:	4d 01 d0                                        	add    r8,r10
    17f1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    17f6:	4d 01 d0                                        	add    r8,r10
    17f9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    17fe:	4d 01 d0                                        	add    r8,r10
    1801:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1806:	4d 01 d0                                        	add    r8,r10
    1809:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    180e:	4d 01 d0                                        	add    r8,r10
    1811:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1816:	4d 01 d0                                        	add    r8,r10
    1819:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    181e:	4d 01 d0                                        	add    r8,r10
    1821:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1826:	4d 01 d0                                        	add    r8,r10
    1829:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    182e:	4d 01 d0                                        	add    r8,r10
    1831:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1836:	4d 01 d0                                        	add    r8,r10
    1839:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    183e:	4d 01 d0                                        	add    r8,r10
    1841:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1846:	4d 01 d0                                        	add    r8,r10
    1849:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    184e:	4d 01 d0                                        	add    r8,r10
    1851:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1856:	4d 01 d0                                        	add    r8,r10
    1859:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    185e:	4d 01 d0                                        	add    r8,r10
    1861:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1866:	4d 01 d0                                        	add    r8,r10
    1869:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    186e:	4d 01 d0                                        	add    r8,r10
    1871:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1876:	4d 01 d0                                        	add    r8,r10
    1879:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    187e:	4d 01 d0                                        	add    r8,r10
    1881:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1886:	4d 01 d0                                        	add    r8,r10
    1889:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    188e:	4d 01 d0                                        	add    r8,r10
    1891:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1896:	4d 01 d0                                        	add    r8,r10
    1899:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    189e:	4d 01 d0                                        	add    r8,r10
    18a1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    18a6:	4d 01 d0                                        	add    r8,r10
    18a9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    18ae:	4d 01 d0                                        	add    r8,r10
    18b1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    18b6:	4d 01 d0                                        	add    r8,r10
    18b9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    18be:	4d 01 d0                                        	add    r8,r10
    18c1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    18c6:	4d 01 d0                                        	add    r8,r10
    18c9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    18ce:	4d 01 d0                                        	add    r8,r10
    18d1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    18d6:	4d 01 d0                                        	add    r8,r10
    18d9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    18de:	4d 01 d0                                        	add    r8,r10
    18e1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    18e6:	4d 01 d0                                        	add    r8,r10
    18e9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    18ee:	4d 01 d0                                        	add    r8,r10
    18f1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    18f6:	4d 01 d0                                        	add    r8,r10
    18f9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    18fe:	4d 01 d0                                        	add    r8,r10
    1901:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1906:	4d 01 d0                                        	add    r8,r10
    1909:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    190e:	4d 01 d0                                        	add    r8,r10
    1911:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1916:	4d 01 d0                                        	add    r8,r10
    1919:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    191e:	4d 01 d0                                        	add    r8,r10
    1921:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1926:	4d 01 d0                                        	add    r8,r10
    1929:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    192e:	4d 01 d0                                        	add    r8,r10
    1931:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1936:	4d 01 d0                                        	add    r8,r10
    1939:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    193e:	4d 01 d0                                        	add    r8,r10
    1941:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1946:	4d 01 d0                                        	add    r8,r10
    1949:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    194e:	4d 01 d0                                        	add    r8,r10
    1951:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1956:	4d 01 d0                                        	add    r8,r10
    1959:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    195e:	4d 01 d0                                        	add    r8,r10
    1961:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1966:	4d 01 d0                                        	add    r8,r10
    1969:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    196e:	4d 01 d0                                        	add    r8,r10
    1971:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1976:	4d 01 d0                                        	add    r8,r10
    1979:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    197e:	4d 01 d0                                        	add    r8,r10
    1981:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1986:	4d 01 d0                                        	add    r8,r10
    1989:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    198e:	4d 01 d0                                        	add    r8,r10
    1991:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1996:	4d 01 d0                                        	add    r8,r10
    1999:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    199e:	4d 01 d0                                        	add    r8,r10
    19a1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    19a6:	4d 01 d0                                        	add    r8,r10
    19a9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    19ae:	4d 01 d0                                        	add    r8,r10
    19b1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    19b6:	4d 01 d0                                        	add    r8,r10
    19b9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    19be:	4d 01 d0                                        	add    r8,r10
    19c1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    19c6:	4d 01 d0                                        	add    r8,r10
    19c9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    19ce:	4d 01 d0                                        	add    r8,r10
    19d1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    19d6:	4d 01 d0                                        	add    r8,r10
    19d9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    19de:	4d 01 d0                                        	add    r8,r10
    19e1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    19e6:	4d 01 d0                                        	add    r8,r10
    19e9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    19ee:	4d 01 d0                                        	add    r8,r10
    19f1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    19f6:	4d 01 d0                                        	add    r8,r10
    19f9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    19fe:	4d 01 d0                                        	add    r8,r10
    1a01:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1a06:	4d 01 d0                                        	add    r8,r10
    1a09:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1a0e:	4d 01 d0                                        	add    r8,r10
    1a11:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1a16:	4d 01 d0                                        	add    r8,r10
    1a19:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1a1e:	4d 01 d0                                        	add    r8,r10
    1a21:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1a26:	4d 01 d0                                        	add    r8,r10
    1a29:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1a2e:	4d 01 d0                                        	add    r8,r10
    1a31:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1a36:	4d 01 d0                                        	add    r8,r10
    1a39:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1a3e:	4d 01 d0                                        	add    r8,r10
    1a41:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1a46:	4d 01 d0                                        	add    r8,r10
    1a49:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1a4e:	4d 01 d0                                        	add    r8,r10
    1a51:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1a56:	4d 01 d0                                        	add    r8,r10
    1a59:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1a5e:	4d 01 d0                                        	add    r8,r10
    1a61:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1a66:	4d 01 d0                                        	add    r8,r10
    1a69:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1a6e:	4d 01 d0                                        	add    r8,r10
    1a71:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1a76:	4d 01 d0                                        	add    r8,r10
    1a79:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1a7e:	4d 01 d0                                        	add    r8,r10
    1a81:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1a86:	4d 01 d0                                        	add    r8,r10
    1a89:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1a8e:	4d 01 d0                                        	add    r8,r10
    1a91:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1a96:	4d 01 d0                                        	add    r8,r10
    1a99:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1a9e:	4d 01 d0                                        	add    r8,r10
    1aa1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1aa6:	4d 01 d0                                        	add    r8,r10
    1aa9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1aae:	4d 01 d0                                        	add    r8,r10
    1ab1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1ab6:	4d 01 d0                                        	add    r8,r10
    1ab9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1abe:	4d 01 d0                                        	add    r8,r10
    1ac1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1ac6:	4d 01 d0                                        	add    r8,r10
    1ac9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1ace:	4d 01 d0                                        	add    r8,r10
    1ad1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1ad6:	4d 01 d0                                        	add    r8,r10
    1ad9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1ade:	4d 01 d0                                        	add    r8,r10
    1ae1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1ae6:	4d 01 d0                                        	add    r8,r10
    1ae9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1aee:	4d 01 d0                                        	add    r8,r10
    1af1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1af6:	4d 01 d0                                        	add    r8,r10
    1af9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1afe:	4d 01 d0                                        	add    r8,r10
    1b01:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1b06:	4d 01 d0                                        	add    r8,r10
    1b09:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1b0e:	4d 01 d0                                        	add    r8,r10
    1b11:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1b16:	4d 01 d0                                        	add    r8,r10
    1b19:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1b1e:	4d 01 d0                                        	add    r8,r10
    1b21:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1b26:	4d 01 d0                                        	add    r8,r10
    1b29:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1b2e:	4d 01 d0                                        	add    r8,r10
    1b31:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1b36:	4d 01 d0                                        	add    r8,r10
    1b39:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1b3e:	4d 01 d0                                        	add    r8,r10
    1b41:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1b46:	4d 01 d0                                        	add    r8,r10
    1b49:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1b4e:	4d 01 d0                                        	add    r8,r10
    1b51:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1b56:	4d 01 d0                                        	add    r8,r10
    1b59:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1b5e:	4d 01 d0                                        	add    r8,r10
    1b61:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1b66:	4d 01 d0                                        	add    r8,r10
    1b69:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1b6e:	4d 01 d0                                        	add    r8,r10
    1b71:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1b76:	4d 01 d0                                        	add    r8,r10
    1b79:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1b7e:	4d 01 d0                                        	add    r8,r10
    1b81:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1b86:	4d 01 d0                                        	add    r8,r10
    1b89:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1b8e:	4d 01 d0                                        	add    r8,r10
    1b91:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1b96:	4d 01 d0                                        	add    r8,r10
    1b99:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1b9e:	4d 01 d0                                        	add    r8,r10
    1ba1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1ba6:	4d 01 d0                                        	add    r8,r10
    1ba9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1bae:	4d 01 d0                                        	add    r8,r10
    1bb1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1bb6:	4d 01 d0                                        	add    r8,r10
    1bb9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1bbe:	4d 01 d0                                        	add    r8,r10
    1bc1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1bc6:	4d 01 d0                                        	add    r8,r10
    1bc9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1bce:	4d 01 d0                                        	add    r8,r10
    1bd1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1bd6:	4d 01 d0                                        	add    r8,r10
    1bd9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1bde:	4d 01 d0                                        	add    r8,r10
    1be1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1be6:	4d 01 d0                                        	add    r8,r10
    1be9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1bee:	4d 01 d0                                        	add    r8,r10
    1bf1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1bf6:	4d 01 d0                                        	add    r8,r10
    1bf9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1bfe:	4d 01 d0                                        	add    r8,r10
    1c01:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1c06:	4d 01 d0                                        	add    r8,r10
    1c09:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1c0e:	4d 01 d0                                        	add    r8,r10
    1c11:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1c16:	4d 01 d0                                        	add    r8,r10
    1c19:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1c1e:	4d 01 d0                                        	add    r8,r10
    1c21:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1c26:	4d 01 d0                                        	add    r8,r10
    1c29:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1c2e:	4d 01 d0                                        	add    r8,r10
    1c31:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1c36:	4d 01 d0                                        	add    r8,r10
    1c39:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1c3e:	4d 01 d0                                        	add    r8,r10
    1c41:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1c46:	4d 01 d0                                        	add    r8,r10
    1c49:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1c4e:	4d 01 d0                                        	add    r8,r10
    1c51:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1c56:	4d 01 d0                                        	add    r8,r10
    1c59:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1c5e:	4d 01 d0                                        	add    r8,r10
    1c61:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1c66:	4d 01 d0                                        	add    r8,r10
    1c69:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1c6e:	4d 01 d0                                        	add    r8,r10
    1c71:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1c76:	4d 01 d0                                        	add    r8,r10
    1c79:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1c7e:	4d 01 d0                                        	add    r8,r10
    1c81:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1c86:	4d 01 d0                                        	add    r8,r10
    1c89:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1c8e:	4d 01 d0                                        	add    r8,r10
    1c91:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1c96:	4d 01 d0                                        	add    r8,r10
    1c99:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1c9e:	4d 01 d0                                        	add    r8,r10
    1ca1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1ca6:	4d 01 d0                                        	add    r8,r10
    1ca9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1cae:	4d 01 d0                                        	add    r8,r10
    1cb1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1cb6:	4d 01 d0                                        	add    r8,r10
    1cb9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1cbe:	4d 01 d0                                        	add    r8,r10
    1cc1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1cc6:	4d 01 d0                                        	add    r8,r10
    1cc9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1cce:	4d 01 d0                                        	add    r8,r10
    1cd1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1cd6:	4d 01 d0                                        	add    r8,r10
    1cd9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1cde:	4d 01 d0                                        	add    r8,r10
    1ce1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1ce6:	4d 01 d0                                        	add    r8,r10
    1ce9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1cee:	4d 01 d0                                        	add    r8,r10
    1cf1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1cf6:	4d 01 d0                                        	add    r8,r10
    1cf9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1cfe:	4d 01 d0                                        	add    r8,r10
    1d01:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1d06:	4d 01 d0                                        	add    r8,r10
    1d09:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1d0e:	4d 01 d0                                        	add    r8,r10
    1d11:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1d16:	4d 01 d0                                        	add    r8,r10
    1d19:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1d1e:	4d 01 d0                                        	add    r8,r10
    1d21:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1d26:	4d 01 d0                                        	add    r8,r10
    1d29:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1d2e:	4d 01 d0                                        	add    r8,r10
    1d31:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1d36:	4d 01 d0                                        	add    r8,r10
    1d39:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1d3e:	4d 01 d0                                        	add    r8,r10
    1d41:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1d46:	4d 01 d0                                        	add    r8,r10
    1d49:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1d4e:	4d 01 d0                                        	add    r8,r10
    1d51:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1d56:	4d 01 d0                                        	add    r8,r10
    1d59:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1d5e:	4d 01 d0                                        	add    r8,r10
    1d61:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1d66:	4d 01 d0                                        	add    r8,r10
    1d69:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1d6e:	4d 01 d0                                        	add    r8,r10
    1d71:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1d76:	4d 01 d0                                        	add    r8,r10
    1d79:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1d7e:	4d 01 d0                                        	add    r8,r10
    1d81:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1d86:	4d 01 d0                                        	add    r8,r10
    1d89:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1d8e:	4d 01 d0                                        	add    r8,r10
    1d91:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1d96:	4d 01 d0                                        	add    r8,r10
    1d99:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1d9e:	4d 01 d0                                        	add    r8,r10
    1da1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1da6:	4d 01 d0                                        	add    r8,r10
    1da9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1dae:	4d 01 d0                                        	add    r8,r10
    1db1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1db6:	4d 01 d0                                        	add    r8,r10
    1db9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1dbe:	4d 01 d0                                        	add    r8,r10
    1dc1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1dc6:	4d 01 d0                                        	add    r8,r10
    1dc9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1dce:	4d 01 d0                                        	add    r8,r10
    1dd1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1dd6:	4d 01 d0                                        	add    r8,r10
    1dd9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1dde:	4d 01 d0                                        	add    r8,r10
    1de1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1de6:	4d 01 d0                                        	add    r8,r10
    1de9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1dee:	4d 01 d0                                        	add    r8,r10
    1df1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1df6:	4d 01 d0                                        	add    r8,r10
    1df9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1dfe:	4d 01 d0                                        	add    r8,r10
    1e01:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1e06:	4d 01 d0                                        	add    r8,r10
    1e09:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1e0e:	4d 01 d0                                        	add    r8,r10
    1e11:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1e16:	4d 01 d0                                        	add    r8,r10
    1e19:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1e1e:	4d 01 d0                                        	add    r8,r10
    1e21:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1e26:	4d 01 d0                                        	add    r8,r10
    1e29:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1e2e:	4d 01 d0                                        	add    r8,r10
    1e31:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1e36:	4d 01 d0                                        	add    r8,r10
    1e39:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1e3e:	4d 01 d0                                        	add    r8,r10
    1e41:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1e46:	4d 01 d0                                        	add    r8,r10
    1e49:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1e4e:	4d 01 d0                                        	add    r8,r10
    1e51:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1e56:	4d 01 d0                                        	add    r8,r10
    1e59:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1e5e:	4d 01 d0                                        	add    r8,r10
    1e61:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1e66:	4d 01 d0                                        	add    r8,r10
    1e69:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1e6e:	4d 01 d0                                        	add    r8,r10
    1e71:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1e76:	4d 01 d0                                        	add    r8,r10
    1e79:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1e7e:	4d 01 d0                                        	add    r8,r10
    1e81:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1e86:	4d 01 d0                                        	add    r8,r10
    1e89:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1e8e:	4d 01 d0                                        	add    r8,r10
    1e91:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1e96:	4d 01 d0                                        	add    r8,r10
    1e99:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1e9e:	4d 01 d0                                        	add    r8,r10
    1ea1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1ea6:	4d 01 d0                                        	add    r8,r10
    1ea9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1eae:	4d 01 d0                                        	add    r8,r10
    1eb1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1eb6:	4d 01 d0                                        	add    r8,r10
    1eb9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1ebe:	4d 01 d0                                        	add    r8,r10
    1ec1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1ec6:	4d 01 d0                                        	add    r8,r10
    1ec9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1ece:	4d 01 d0                                        	add    r8,r10
    1ed1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1ed6:	4d 01 d0                                        	add    r8,r10
    1ed9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1ede:	4d 01 d0                                        	add    r8,r10
    1ee1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1ee6:	4d 01 d0                                        	add    r8,r10
    1ee9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1eee:	4d 01 d0                                        	add    r8,r10
    1ef1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1ef6:	4d 01 d0                                        	add    r8,r10
    1ef9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1efe:	4d 01 d0                                        	add    r8,r10
    1f01:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1f06:	4d 01 d0                                        	add    r8,r10
    1f09:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1f0e:	4d 01 d0                                        	add    r8,r10
    1f11:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1f16:	4d 01 d0                                        	add    r8,r10
    1f19:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1f1e:	4d 01 d0                                        	add    r8,r10
    1f21:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1f26:	4d 01 d0                                        	add    r8,r10
    1f29:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1f2e:	4d 01 d0                                        	add    r8,r10
    1f31:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1f36:	4d 01 d0                                        	add    r8,r10
    1f39:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1f3e:	4d 01 d0                                        	add    r8,r10
    1f41:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1f46:	4d 01 d0                                        	add    r8,r10
    1f49:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1f4e:	4d 01 d0                                        	add    r8,r10
    1f51:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1f56:	4d 01 d0                                        	add    r8,r10
    1f59:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1f5e:	4d 01 d0                                        	add    r8,r10
    1f61:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1f66:	4d 01 d0                                        	add    r8,r10
    1f69:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1f6e:	4d 01 d0                                        	add    r8,r10
    1f71:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1f76:	4d 01 d0                                        	add    r8,r10
    1f79:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1f7e:	4d 01 d0                                        	add    r8,r10
    1f81:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1f86:	4d 01 d0                                        	add    r8,r10
    1f89:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1f8e:	4d 01 d0                                        	add    r8,r10
    1f91:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1f96:	4d 01 d0                                        	add    r8,r10
    1f99:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1f9e:	4d 01 d0                                        	add    r8,r10
    1fa1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1fa6:	4d 01 d0                                        	add    r8,r10
    1fa9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1fae:	4d 01 d0                                        	add    r8,r10
    1fb1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1fb6:	4d 01 d0                                        	add    r8,r10
    1fb9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1fbe:	4d 01 d0                                        	add    r8,r10
    1fc1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1fc6:	4d 01 d0                                        	add    r8,r10
    1fc9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1fce:	4d 01 d0                                        	add    r8,r10
    1fd1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1fd6:	4d 01 d0                                        	add    r8,r10
    1fd9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1fde:	4d 01 d0                                        	add    r8,r10
    1fe1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1fe6:	4d 01 d0                                        	add    r8,r10
    1fe9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1fee:	4d 01 d0                                        	add    r8,r10
    1ff1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1ff6:	4d 01 d0                                        	add    r8,r10
    1ff9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1ffe:	4d 01 d0                                        	add    r8,r10
    2001:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2006:	4d 01 d0                                        	add    r8,r10
    2009:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    200e:	4d 01 d0                                        	add    r8,r10
    2011:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2016:	4d 01 d0                                        	add    r8,r10
    2019:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    201e:	4d 01 d0                                        	add    r8,r10
    2021:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2026:	4d 01 d0                                        	add    r8,r10
    2029:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    202e:	4d 01 d0                                        	add    r8,r10
    2031:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2036:	4d 01 d0                                        	add    r8,r10
    2039:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    203e:	4d 01 d0                                        	add    r8,r10
    2041:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2046:	4d 01 d0                                        	add    r8,r10
    2049:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    204e:	4d 01 d0                                        	add    r8,r10
    2051:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2056:	4d 01 d0                                        	add    r8,r10
    2059:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    205e:	4d 01 d0                                        	add    r8,r10
    2061:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2066:	4d 01 d0                                        	add    r8,r10
    2069:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    206e:	4d 01 d0                                        	add    r8,r10
    2071:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2076:	4d 01 d0                                        	add    r8,r10
    2079:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    207e:	4d 01 d0                                        	add    r8,r10
    2081:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2086:	4d 01 d0                                        	add    r8,r10
    2089:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    208e:	4d 01 d0                                        	add    r8,r10
    2091:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2096:	4d 01 d0                                        	add    r8,r10
    2099:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    209e:	4d 01 d0                                        	add    r8,r10
    20a1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    20a6:	4d 01 d0                                        	add    r8,r10
    20a9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    20ae:	4d 01 d0                                        	add    r8,r10
    20b1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    20b6:	4d 01 d0                                        	add    r8,r10
    20b9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    20be:	4d 01 d0                                        	add    r8,r10
    20c1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    20c6:	4d 01 d0                                        	add    r8,r10
    20c9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    20ce:	4d 01 d0                                        	add    r8,r10
    20d1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    20d6:	4d 01 d0                                        	add    r8,r10
    20d9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    20de:	4d 01 d0                                        	add    r8,r10
    20e1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    20e6:	4d 01 d0                                        	add    r8,r10
    20e9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    20ee:	4d 01 d0                                        	add    r8,r10
    20f1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    20f6:	4d 01 d0                                        	add    r8,r10
    20f9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    20fe:	4d 01 d0                                        	add    r8,r10
    2101:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2106:	4d 01 d0                                        	add    r8,r10
    2109:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    210e:	4d 01 d0                                        	add    r8,r10
    2111:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2116:	4d 01 d0                                        	add    r8,r10
    2119:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    211e:	4d 01 d0                                        	add    r8,r10
    2121:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2126:	4d 01 d0                                        	add    r8,r10
    2129:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    212e:	4d 01 d0                                        	add    r8,r10
    2131:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2136:	4d 01 d0                                        	add    r8,r10
    2139:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    213e:	4d 01 d0                                        	add    r8,r10
    2141:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2146:	4d 01 d0                                        	add    r8,r10
    2149:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    214e:	4d 01 d0                                        	add    r8,r10
    2151:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2156:	4d 01 d0                                        	add    r8,r10
    2159:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    215e:	4d 01 d0                                        	add    r8,r10
    2161:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2166:	4d 01 d0                                        	add    r8,r10
    2169:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    216e:	4d 01 d0                                        	add    r8,r10
    2171:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2176:	4d 01 d0                                        	add    r8,r10
    2179:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    217e:	4d 01 d0                                        	add    r8,r10
    2181:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2186:	4d 01 d0                                        	add    r8,r10
    2189:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    218e:	4d 01 d0                                        	add    r8,r10
    2191:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2196:	4d 01 d0                                        	add    r8,r10
    2199:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    219e:	4d 01 d0                                        	add    r8,r10
    21a1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    21a6:	4d 01 d0                                        	add    r8,r10
    21a9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    21ae:	4d 01 d0                                        	add    r8,r10
    21b1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    21b6:	4d 01 d0                                        	add    r8,r10
    21b9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    21be:	4d 01 d0                                        	add    r8,r10
    21c1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    21c6:	4d 01 d0                                        	add    r8,r10
    21c9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    21ce:	4d 01 d0                                        	add    r8,r10
    21d1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    21d6:	4d 01 d0                                        	add    r8,r10
    21d9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    21de:	4d 01 d0                                        	add    r8,r10
    21e1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    21e6:	4d 01 d0                                        	add    r8,r10
    21e9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    21ee:	4d 01 d0                                        	add    r8,r10
    21f1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    21f6:	4d 01 d0                                        	add    r8,r10
    21f9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    21fe:	4d 01 d0                                        	add    r8,r10
    2201:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2206:	4d 01 d0                                        	add    r8,r10
    2209:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    220e:	4d 01 d0                                        	add    r8,r10
    2211:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2216:	4d 01 d0                                        	add    r8,r10
    2219:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    221e:	4d 01 d0                                        	add    r8,r10
    2221:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2226:	4d 01 d0                                        	add    r8,r10
    2229:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    222e:	4d 01 d0                                        	add    r8,r10
    2231:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2236:	4d 01 d0                                        	add    r8,r10
    2239:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    223e:	4d 01 d0                                        	add    r8,r10
    2241:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2246:	4d 01 d0                                        	add    r8,r10
    2249:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    224e:	4d 01 d0                                        	add    r8,r10
    2251:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2256:	4d 01 d0                                        	add    r8,r10
    2259:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    225e:	4d 01 d0                                        	add    r8,r10
    2261:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2266:	4d 01 d0                                        	add    r8,r10
    2269:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    226e:	4d 01 d0                                        	add    r8,r10
    2271:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2276:	4d 01 d0                                        	add    r8,r10
    2279:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    227e:	4d 01 d0                                        	add    r8,r10
    2281:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2286:	4d 01 d0                                        	add    r8,r10
    2289:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    228e:	4d 01 d0                                        	add    r8,r10
    2291:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2296:	4d 01 d0                                        	add    r8,r10
    2299:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    229e:	4d 01 d0                                        	add    r8,r10
    22a1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    22a6:	4d 01 d0                                        	add    r8,r10
    22a9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    22ae:	4d 01 d0                                        	add    r8,r10
    22b1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    22b6:	4d 01 d0                                        	add    r8,r10
    22b9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    22be:	4d 01 d0                                        	add    r8,r10
    22c1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    22c6:	4d 01 d0                                        	add    r8,r10
    22c9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    22ce:	4d 01 d0                                        	add    r8,r10
    22d1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    22d6:	4d 01 d0                                        	add    r8,r10
    22d9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    22de:	4d 01 d0                                        	add    r8,r10
    22e1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    22e6:	4d 01 d0                                        	add    r8,r10
    22e9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    22ee:	4d 01 d0                                        	add    r8,r10
    22f1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    22f6:	4d 01 d0                                        	add    r8,r10
    22f9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    22fe:	4d 01 d0                                        	add    r8,r10
    2301:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2306:	4d 01 d0                                        	add    r8,r10
    2309:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    230e:	4d 01 d0                                        	add    r8,r10
    2311:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2316:	4d 01 d0                                        	add    r8,r10
    2319:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    231e:	4d 01 d0                                        	add    r8,r10
    2321:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2326:	4d 01 d0                                        	add    r8,r10
    2329:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    232e:	4d 01 d0                                        	add    r8,r10
    2331:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2336:	4d 01 d0                                        	add    r8,r10
    2339:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    233e:	4d 01 d0                                        	add    r8,r10
    2341:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2346:	4d 01 d0                                        	add    r8,r10
    2349:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    234e:	4d 01 d0                                        	add    r8,r10
    2351:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2356:	4d 01 d0                                        	add    r8,r10
    2359:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    235e:	4d 01 d0                                        	add    r8,r10
    2361:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2366:	4d 01 d0                                        	add    r8,r10
    2369:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    236e:	4d 01 d0                                        	add    r8,r10
    2371:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2376:	4d 01 d0                                        	add    r8,r10
    2379:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    237e:	4d 01 d0                                        	add    r8,r10
    2381:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2386:	4d 01 d0                                        	add    r8,r10
    2389:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    238e:	4d 01 d0                                        	add    r8,r10
    2391:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2396:	4d 01 d0                                        	add    r8,r10
    2399:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    239e:	4d 01 d0                                        	add    r8,r10
    23a1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    23a6:	4d 01 d0                                        	add    r8,r10
    23a9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    23ae:	4d 01 d0                                        	add    r8,r10
    23b1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    23b6:	4d 01 d0                                        	add    r8,r10
    23b9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    23be:	4d 01 d0                                        	add    r8,r10
    23c1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    23c6:	4d 01 d0                                        	add    r8,r10
    23c9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    23ce:	4d 01 d0                                        	add    r8,r10
    23d1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    23d6:	4d 01 d0                                        	add    r8,r10
    23d9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    23de:	4d 01 d0                                        	add    r8,r10
    23e1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    23e6:	4d 01 d0                                        	add    r8,r10
    23e9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    23ee:	4d 01 d0                                        	add    r8,r10
    23f1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    23f6:	4d 01 d0                                        	add    r8,r10
    23f9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    23fe:	4d 01 d0                                        	add    r8,r10
    2401:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2406:	4d 01 d0                                        	add    r8,r10
    2409:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    240e:	4d 01 d0                                        	add    r8,r10
    2411:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2416:	4d 01 d0                                        	add    r8,r10
    2419:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    241e:	4d 01 d0                                        	add    r8,r10
    2421:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2426:	4d 01 d0                                        	add    r8,r10
    2429:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    242e:	4d 01 d0                                        	add    r8,r10
    2431:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2436:	4d 01 d0                                        	add    r8,r10
    2439:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    243e:	4d 01 d0                                        	add    r8,r10
    2441:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2446:	4d 01 d0                                        	add    r8,r10
    2449:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    244e:	4d 01 d0                                        	add    r8,r10
    2451:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2456:	4d 01 d0                                        	add    r8,r10
    2459:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    245e:	4d 01 d0                                        	add    r8,r10
    2461:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2466:	4d 01 d0                                        	add    r8,r10
    2469:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    246e:	4d 01 d0                                        	add    r8,r10
    2471:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2476:	4d 01 d0                                        	add    r8,r10
    2479:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    247e:	4d 01 d0                                        	add    r8,r10
    2481:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2486:	4d 01 d0                                        	add    r8,r10
    2489:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    248e:	4d 01 d0                                        	add    r8,r10
    2491:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2496:	4d 01 d0                                        	add    r8,r10
    2499:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    249e:	4d 01 d0                                        	add    r8,r10
    24a1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    24a6:	4d 01 d0                                        	add    r8,r10
    24a9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    24ae:	4d 01 d0                                        	add    r8,r10
    24b1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    24b6:	4d 01 d0                                        	add    r8,r10
    24b9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    24be:	4d 01 d0                                        	add    r8,r10
    24c1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    24c6:	4d 01 d0                                        	add    r8,r10
    24c9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    24ce:	4d 01 d0                                        	add    r8,r10
    24d1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    24d6:	4d 01 d0                                        	add    r8,r10
    24d9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    24de:	4d 01 d0                                        	add    r8,r10
    24e1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    24e6:	4d 01 d0                                        	add    r8,r10
    24e9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    24ee:	4d 01 d0                                        	add    r8,r10
    24f1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    24f6:	4d 01 d0                                        	add    r8,r10
    24f9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    24fe:	4d 01 d0                                        	add    r8,r10
    2501:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2506:	4d 01 d0                                        	add    r8,r10
    2509:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    250e:	4d 01 d0                                        	add    r8,r10
    2511:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2516:	4d 01 d0                                        	add    r8,r10
    2519:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    251e:	4d 01 d0                                        	add    r8,r10
    2521:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2526:	4d 01 d0                                        	add    r8,r10
    2529:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    252e:	4d 01 d0                                        	add    r8,r10
    2531:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2536:	4d 01 d0                                        	add    r8,r10
    2539:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    253e:	4d 01 d0                                        	add    r8,r10
    2541:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2546:	4d 01 d0                                        	add    r8,r10
    2549:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    254e:	4d 01 d0                                        	add    r8,r10
    2551:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2556:	4d 01 d0                                        	add    r8,r10
    2559:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    255e:	4d 01 d0                                        	add    r8,r10
    2561:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2566:	4d 01 d0                                        	add    r8,r10
    2569:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    256e:	4d 01 d0                                        	add    r8,r10
    2571:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2576:	4d 01 d0                                        	add    r8,r10
    2579:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    257e:	4d 01 d0                                        	add    r8,r10
    2581:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2586:	4d 01 d0                                        	add    r8,r10
    2589:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    258e:	4d 01 d0                                        	add    r8,r10
    2591:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2596:	4d 01 d0                                        	add    r8,r10
    2599:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    259e:	4d 01 d0                                        	add    r8,r10
    25a1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    25a6:	4d 01 d0                                        	add    r8,r10
    25a9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    25ae:	4d 01 d0                                        	add    r8,r10
    25b1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    25b6:	4d 01 d0                                        	add    r8,r10
    25b9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    25be:	4d 01 d0                                        	add    r8,r10
    25c1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    25c6:	4d 01 d0                                        	add    r8,r10
    25c9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    25ce:	4d 01 d0                                        	add    r8,r10
    25d1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    25d6:	4d 01 d0                                        	add    r8,r10
    25d9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    25de:	4d 01 d0                                        	add    r8,r10
    25e1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    25e6:	4d 01 d0                                        	add    r8,r10
    25e9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    25ee:	4d 01 d0                                        	add    r8,r10
    25f1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    25f6:	4d 01 d0                                        	add    r8,r10
    25f9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    25fe:	4d 01 d0                                        	add    r8,r10
    2601:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2606:	4d 01 d0                                        	add    r8,r10
    2609:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    260e:	4d 01 d0                                        	add    r8,r10
    2611:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2616:	4d 01 d0                                        	add    r8,r10
    2619:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    261e:	4d 01 d0                                        	add    r8,r10
    2621:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2626:	4d 01 d0                                        	add    r8,r10
    2629:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    262e:	4d 01 d0                                        	add    r8,r10
    2631:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2636:	4d 01 d0                                        	add    r8,r10
    2639:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    263e:	4d 01 d0                                        	add    r8,r10
    2641:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2646:	4d 01 d0                                        	add    r8,r10
    2649:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    264e:	4d 01 d0                                        	add    r8,r10
    2651:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2656:	4d 01 d0                                        	add    r8,r10
    2659:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    265e:	4d 01 d0                                        	add    r8,r10
    2661:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2666:	4d 01 d0                                        	add    r8,r10
    2669:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    266e:	4d 01 d0                                        	add    r8,r10
    2671:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2676:	4d 01 d0                                        	add    r8,r10
    2679:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    267e:	4d 01 d0                                        	add    r8,r10
    2681:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2686:	4d 01 d0                                        	add    r8,r10
    2689:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    268e:	4d 01 d0                                        	add    r8,r10
    2691:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2696:	4d 01 d0                                        	add    r8,r10
    2699:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    269e:	4d 01 d0                                        	add    r8,r10
    26a1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    26a6:	4d 01 d0                                        	add    r8,r10
    26a9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    26ae:	4d 01 d0                                        	add    r8,r10
    26b1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    26b6:	4d 01 d0                                        	add    r8,r10
    26b9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    26be:	4d 01 d0                                        	add    r8,r10
    26c1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    26c6:	4d 01 d0                                        	add    r8,r10
    26c9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    26ce:	4d 01 d0                                        	add    r8,r10
    26d1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    26d6:	4d 01 d0                                        	add    r8,r10
    26d9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    26de:	4d 01 d0                                        	add    r8,r10
    26e1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    26e6:	4d 01 d0                                        	add    r8,r10
    26e9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    26ee:	4d 01 d0                                        	add    r8,r10
    26f1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    26f6:	4d 01 d0                                        	add    r8,r10
    26f9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    26fe:	4d 01 d0                                        	add    r8,r10
    2701:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2706:	4d 01 d0                                        	add    r8,r10
    2709:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    270e:	4d 01 d0                                        	add    r8,r10
    2711:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2716:	4d 01 d0                                        	add    r8,r10
    2719:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    271e:	4d 01 d0                                        	add    r8,r10
    2721:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2726:	4d 01 d0                                        	add    r8,r10
    2729:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    272e:	4d 01 d0                                        	add    r8,r10
    2731:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2736:	4d 01 d0                                        	add    r8,r10
    2739:	41 f6 c1 01                                     	test   r9b,0x1
    273d:	74 04                                           	je     2743 <join_1>
    273f:	49 83 f0 01                                     	xor    r8,0x1

0000000000002743 <join_1>:
    2743:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2748:	4d 01 d0                                        	add    r8,r10
    274b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2750:	4d 01 d0                                        	add    r8,r10
    2753:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2758:	4d 01 d0                                        	add    r8,r10
    275b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2760:	4d 01 d0                                        	add    r8,r10
    2763:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2768:	4d 01 d0                                        	add    r8,r10
    276b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2770:	4d 01 d0                                        	add    r8,r10
    2773:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2778:	4d 01 d0                                        	add    r8,r10
    277b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2780:	4d 01 d0                                        	add    r8,r10
    2783:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2788:	4d 01 d0                                        	add    r8,r10
    278b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2790:	4d 01 d0                                        	add    r8,r10
    2793:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2798:	4d 01 d0                                        	add    r8,r10
    279b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    27a0:	4d 01 d0                                        	add    r8,r10
    27a3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    27a8:	4d 01 d0                                        	add    r8,r10
    27ab:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    27b0:	4d 01 d0                                        	add    r8,r10
    27b3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    27b8:	4d 01 d0                                        	add    r8,r10
    27bb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    27c0:	4d 01 d0                                        	add    r8,r10
    27c3:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    27c8:	4d 01 d0                                        	add    r8,r10
    27cb:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    27d0:	4d 01 d0                                        	add    r8,r10
    27d3:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    27d8:	4d 01 d0                                        	add    r8,r10
    27db:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    27e0:	4d 01 d0                                        	add    r8,r10
    27e3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    27e8:	4d 01 d0                                        	add    r8,r10
    27eb:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    27f0:	4d 01 d0                                        	add    r8,r10
    27f3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    27f8:	4d 01 d0                                        	add    r8,r10
    27fb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2800:	4d 01 d0                                        	add    r8,r10
    2803:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2808:	4d 01 d0                                        	add    r8,r10
    280b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2810:	4d 01 d0                                        	add    r8,r10
    2813:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2818:	4d 01 d0                                        	add    r8,r10
    281b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2820:	4d 01 d0                                        	add    r8,r10
    2823:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2828:	4d 01 d0                                        	add    r8,r10
    282b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2830:	4d 01 d0                                        	add    r8,r10
    2833:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2838:	4d 01 d0                                        	add    r8,r10
    283b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2840:	4d 01 d0                                        	add    r8,r10
    2843:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2848:	4d 01 d0                                        	add    r8,r10
    284b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2850:	4d 01 d0                                        	add    r8,r10
    2853:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2858:	4d 01 d0                                        	add    r8,r10
    285b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2860:	4d 01 d0                                        	add    r8,r10
    2863:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2868:	4d 01 d0                                        	add    r8,r10
    286b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2870:	4d 01 d0                                        	add    r8,r10
    2873:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2878:	4d 01 d0                                        	add    r8,r10
    287b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2880:	4d 01 d0                                        	add    r8,r10
    2883:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2888:	4d 01 d0                                        	add    r8,r10
    288b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2890:	4d 01 d0                                        	add    r8,r10
    2893:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2898:	4d 01 d0                                        	add    r8,r10
    289b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    28a0:	4d 01 d0                                        	add    r8,r10
    28a3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    28a8:	4d 01 d0                                        	add    r8,r10
    28ab:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    28b0:	4d 01 d0                                        	add    r8,r10
    28b3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    28b8:	4d 01 d0                                        	add    r8,r10
    28bb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    28c0:	4d 01 d0                                        	add    r8,r10
    28c3:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    28c8:	4d 01 d0                                        	add    r8,r10
    28cb:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    28d0:	4d 01 d0                                        	add    r8,r10
    28d3:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    28d8:	4d 01 d0                                        	add    r8,r10
    28db:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    28e0:	4d 01 d0                                        	add    r8,r10
    28e3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    28e8:	4d 01 d0                                        	add    r8,r10
    28eb:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    28f0:	4d 01 d0                                        	add    r8,r10
    28f3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    28f8:	4d 01 d0                                        	add    r8,r10
    28fb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2900:	4d 01 d0                                        	add    r8,r10
    2903:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2908:	4d 01 d0                                        	add    r8,r10
    290b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2910:	4d 01 d0                                        	add    r8,r10
    2913:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2918:	4d 01 d0                                        	add    r8,r10
    291b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2920:	4d 01 d0                                        	add    r8,r10
    2923:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2928:	4d 01 d0                                        	add    r8,r10
    292b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2930:	4d 01 d0                                        	add    r8,r10
    2933:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2938:	4d 01 d0                                        	add    r8,r10
    293b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2940:	4d 01 d0                                        	add    r8,r10
    2943:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2948:	4d 01 d0                                        	add    r8,r10
    294b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2950:	4d 01 d0                                        	add    r8,r10
    2953:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2958:	4d 01 d0                                        	add    r8,r10
    295b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2960:	4d 01 d0                                        	add    r8,r10
    2963:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2968:	4d 01 d0                                        	add    r8,r10
    296b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2970:	4d 01 d0                                        	add    r8,r10
    2973:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2978:	4d 01 d0                                        	add    r8,r10
    297b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2980:	4d 01 d0                                        	add    r8,r10
    2983:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2988:	4d 01 d0                                        	add    r8,r10
    298b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2990:	4d 01 d0                                        	add    r8,r10
    2993:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2998:	4d 01 d0                                        	add    r8,r10
    299b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    29a0:	4d 01 d0                                        	add    r8,r10
    29a3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    29a8:	4d 01 d0                                        	add    r8,r10
    29ab:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    29b0:	4d 01 d0                                        	add    r8,r10
    29b3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    29b8:	4d 01 d0                                        	add    r8,r10
    29bb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    29c0:	4d 01 d0                                        	add    r8,r10
    29c3:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    29c8:	4d 01 d0                                        	add    r8,r10
    29cb:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    29d0:	4d 01 d0                                        	add    r8,r10
    29d3:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    29d8:	4d 01 d0                                        	add    r8,r10
    29db:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    29e0:	4d 01 d0                                        	add    r8,r10
    29e3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    29e8:	4d 01 d0                                        	add    r8,r10
    29eb:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    29f0:	4d 01 d0                                        	add    r8,r10
    29f3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    29f8:	4d 01 d0                                        	add    r8,r10
    29fb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2a00:	4d 01 d0                                        	add    r8,r10
    2a03:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2a08:	4d 01 d0                                        	add    r8,r10
    2a0b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2a10:	4d 01 d0                                        	add    r8,r10
    2a13:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2a18:	4d 01 d0                                        	add    r8,r10
    2a1b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2a20:	4d 01 d0                                        	add    r8,r10
    2a23:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2a28:	4d 01 d0                                        	add    r8,r10
    2a2b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2a30:	4d 01 d0                                        	add    r8,r10
    2a33:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2a38:	4d 01 d0                                        	add    r8,r10
    2a3b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2a40:	4d 01 d0                                        	add    r8,r10
    2a43:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2a48:	4d 01 d0                                        	add    r8,r10
    2a4b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2a50:	4d 01 d0                                        	add    r8,r10
    2a53:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2a58:	4d 01 d0                                        	add    r8,r10
    2a5b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2a60:	4d 01 d0                                        	add    r8,r10
    2a63:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2a68:	4d 01 d0                                        	add    r8,r10
    2a6b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2a70:	4d 01 d0                                        	add    r8,r10
    2a73:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2a78:	4d 01 d0                                        	add    r8,r10
    2a7b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2a80:	4d 01 d0                                        	add    r8,r10
    2a83:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2a88:	4d 01 d0                                        	add    r8,r10
    2a8b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2a90:	4d 01 d0                                        	add    r8,r10
    2a93:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2a98:	4d 01 d0                                        	add    r8,r10
    2a9b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2aa0:	4d 01 d0                                        	add    r8,r10
    2aa3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2aa8:	4d 01 d0                                        	add    r8,r10
    2aab:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2ab0:	4d 01 d0                                        	add    r8,r10
    2ab3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2ab8:	4d 01 d0                                        	add    r8,r10
    2abb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2ac0:	4d 01 d0                                        	add    r8,r10
    2ac3:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2ac8:	4d 01 d0                                        	add    r8,r10
    2acb:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2ad0:	4d 01 d0                                        	add    r8,r10
    2ad3:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2ad8:	4d 01 d0                                        	add    r8,r10
    2adb:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2ae0:	4d 01 d0                                        	add    r8,r10
    2ae3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2ae8:	4d 01 d0                                        	add    r8,r10
    2aeb:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2af0:	4d 01 d0                                        	add    r8,r10
    2af3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2af8:	4d 01 d0                                        	add    r8,r10
    2afb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2b00:	4d 01 d0                                        	add    r8,r10
    2b03:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2b08:	4d 01 d0                                        	add    r8,r10
    2b0b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2b10:	4d 01 d0                                        	add    r8,r10
    2b13:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2b18:	4d 01 d0                                        	add    r8,r10
    2b1b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2b20:	4d 01 d0                                        	add    r8,r10
    2b23:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2b28:	4d 01 d0                                        	add    r8,r10
    2b2b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2b30:	4d 01 d0                                        	add    r8,r10
    2b33:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2b38:	4d 01 d0                                        	add    r8,r10
    2b3b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2b40:	4d 01 d0                                        	add    r8,r10
    2b43:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2b48:	4d 01 d0                                        	add    r8,r10
    2b4b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2b50:	4d 01 d0                                        	add    r8,r10
    2b53:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2b58:	4d 01 d0                                        	add    r8,r10
    2b5b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2b60:	4d 01 d0                                        	add    r8,r10
    2b63:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2b68:	4d 01 d0                                        	add    r8,r10
    2b6b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2b70:	4d 01 d0                                        	add    r8,r10
    2b73:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2b78:	4d 01 d0                                        	add    r8,r10
    2b7b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2b80:	4d 01 d0                                        	add    r8,r10
    2b83:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2b88:	4d 01 d0                                        	add    r8,r10
    2b8b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2b90:	4d 01 d0                                        	add    r8,r10
    2b93:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2b98:	4d 01 d0                                        	add    r8,r10
    2b9b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2ba0:	4d 01 d0                                        	add    r8,r10
    2ba3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2ba8:	4d 01 d0                                        	add    r8,r10
    2bab:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2bb0:	4d 01 d0                                        	add    r8,r10
    2bb3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2bb8:	4d 01 d0                                        	add    r8,r10
    2bbb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2bc0:	4d 01 d0                                        	add    r8,r10
    2bc3:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2bc8:	4d 01 d0                                        	add    r8,r10
    2bcb:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2bd0:	4d 01 d0                                        	add    r8,r10
    2bd3:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2bd8:	4d 01 d0                                        	add    r8,r10
    2bdb:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2be0:	4d 01 d0                                        	add    r8,r10
    2be3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2be8:	4d 01 d0                                        	add    r8,r10
    2beb:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2bf0:	4d 01 d0                                        	add    r8,r10
    2bf3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2bf8:	4d 01 d0                                        	add    r8,r10
    2bfb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2c00:	4d 01 d0                                        	add    r8,r10
    2c03:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2c08:	4d 01 d0                                        	add    r8,r10
    2c0b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2c10:	4d 01 d0                                        	add    r8,r10
    2c13:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2c18:	4d 01 d0                                        	add    r8,r10
    2c1b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2c20:	4d 01 d0                                        	add    r8,r10
    2c23:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2c28:	4d 01 d0                                        	add    r8,r10
    2c2b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2c30:	4d 01 d0                                        	add    r8,r10
    2c33:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2c38:	4d 01 d0                                        	add    r8,r10
    2c3b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2c40:	4d 01 d0                                        	add    r8,r10
    2c43:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2c48:	4d 01 d0                                        	add    r8,r10
    2c4b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2c50:	4d 01 d0                                        	add    r8,r10
    2c53:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2c58:	4d 01 d0                                        	add    r8,r10
    2c5b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2c60:	4d 01 d0                                        	add    r8,r10
    2c63:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2c68:	4d 01 d0                                        	add    r8,r10
    2c6b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2c70:	4d 01 d0                                        	add    r8,r10
    2c73:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2c78:	4d 01 d0                                        	add    r8,r10
    2c7b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2c80:	4d 01 d0                                        	add    r8,r10
    2c83:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2c88:	4d 01 d0                                        	add    r8,r10
    2c8b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2c90:	4d 01 d0                                        	add    r8,r10
    2c93:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2c98:	4d 01 d0                                        	add    r8,r10
    2c9b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2ca0:	4d 01 d0                                        	add    r8,r10
    2ca3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2ca8:	4d 01 d0                                        	add    r8,r10
    2cab:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2cb0:	4d 01 d0                                        	add    r8,r10
    2cb3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2cb8:	4d 01 d0                                        	add    r8,r10
    2cbb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2cc0:	4d 01 d0                                        	add    r8,r10
    2cc3:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2cc8:	4d 01 d0                                        	add    r8,r10
    2ccb:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2cd0:	4d 01 d0                                        	add    r8,r10
    2cd3:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2cd8:	4d 01 d0                                        	add    r8,r10
    2cdb:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2ce0:	4d 01 d0                                        	add    r8,r10
    2ce3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2ce8:	4d 01 d0                                        	add    r8,r10
    2ceb:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2cf0:	4d 01 d0                                        	add    r8,r10
    2cf3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2cf8:	4d 01 d0                                        	add    r8,r10
    2cfb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2d00:	4d 01 d0                                        	add    r8,r10
    2d03:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2d08:	4d 01 d0                                        	add    r8,r10
    2d0b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2d10:	4d 01 d0                                        	add    r8,r10
    2d13:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2d18:	4d 01 d0                                        	add    r8,r10
    2d1b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2d20:	4d 01 d0                                        	add    r8,r10
    2d23:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2d28:	4d 01 d0                                        	add    r8,r10
    2d2b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2d30:	4d 01 d0                                        	add    r8,r10
    2d33:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2d38:	4d 01 d0                                        	add    r8,r10
    2d3b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2d40:	4d 01 d0                                        	add    r8,r10
    2d43:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2d48:	4d 01 d0                                        	add    r8,r10
    2d4b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2d50:	4d 01 d0                                        	add    r8,r10
    2d53:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2d58:	4d 01 d0                                        	add    r8,r10
    2d5b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2d60:	4d 01 d0                                        	add    r8,r10
    2d63:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2d68:	4d 01 d0                                        	add    r8,r10
    2d6b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2d70:	4d 01 d0                                        	add    r8,r10
    2d73:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2d78:	4d 01 d0                                        	add    r8,r10
    2d7b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2d80:	4d 01 d0                                        	add    r8,r10
    2d83:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2d88:	4d 01 d0                                        	add    r8,r10
    2d8b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2d90:	4d 01 d0                                        	add    r8,r10
    2d93:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2d98:	4d 01 d0                                        	add    r8,r10
    2d9b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2da0:	4d 01 d0                                        	add    r8,r10
    2da3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2da8:	4d 01 d0                                        	add    r8,r10
    2dab:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2db0:	4d 01 d0                                        	add    r8,r10
    2db3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2db8:	4d 01 d0                                        	add    r8,r10
    2dbb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2dc0:	4d 01 d0                                        	add    r8,r10
    2dc3:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2dc8:	4d 01 d0                                        	add    r8,r10
    2dcb:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2dd0:	4d 01 d0                                        	add    r8,r10
    2dd3:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2dd8:	4d 01 d0                                        	add    r8,r10
    2ddb:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2de0:	4d 01 d0                                        	add    r8,r10
    2de3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2de8:	4d 01 d0                                        	add    r8,r10
    2deb:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2df0:	4d 01 d0                                        	add    r8,r10
    2df3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2df8:	4d 01 d0                                        	add    r8,r10
    2dfb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2e00:	4d 01 d0                                        	add    r8,r10
    2e03:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2e08:	4d 01 d0                                        	add    r8,r10
    2e0b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2e10:	4d 01 d0                                        	add    r8,r10
    2e13:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2e18:	4d 01 d0                                        	add    r8,r10
    2e1b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2e20:	4d 01 d0                                        	add    r8,r10
    2e23:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2e28:	4d 01 d0                                        	add    r8,r10
    2e2b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2e30:	4d 01 d0                                        	add    r8,r10
    2e33:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2e38:	4d 01 d0                                        	add    r8,r10
    2e3b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2e40:	4d 01 d0                                        	add    r8,r10
    2e43:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2e48:	4d 01 d0                                        	add    r8,r10
    2e4b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2e50:	4d 01 d0                                        	add    r8,r10
    2e53:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2e58:	4d 01 d0                                        	add    r8,r10
    2e5b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2e60:	4d 01 d0                                        	add    r8,r10
    2e63:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2e68:	4d 01 d0                                        	add    r8,r10
    2e6b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2e70:	4d 01 d0                                        	add    r8,r10
    2e73:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2e78:	4d 01 d0                                        	add    r8,r10
    2e7b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2e80:	4d 01 d0                                        	add    r8,r10
    2e83:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2e88:	4d 01 d0                                        	add    r8,r10
    2e8b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2e90:	4d 01 d0                                        	add    r8,r10
    2e93:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2e98:	4d 01 d0                                        	add    r8,r10
    2e9b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2ea0:	4d 01 d0                                        	add    r8,r10
    2ea3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2ea8:	4d 01 d0                                        	add    r8,r10
    2eab:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2eb0:	4d 01 d0                                        	add    r8,r10
    2eb3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2eb8:	4d 01 d0                                        	add    r8,r10
    2ebb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2ec0:	4d 01 d0                                        	add    r8,r10
    2ec3:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2ec8:	4d 01 d0                                        	add    r8,r10
    2ecb:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2ed0:	4d 01 d0                                        	add    r8,r10
    2ed3:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2ed8:	4d 01 d0                                        	add    r8,r10
    2edb:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2ee0:	4d 01 d0                                        	add    r8,r10
    2ee3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2ee8:	4d 01 d0                                        	add    r8,r10
    2eeb:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2ef0:	4d 01 d0                                        	add    r8,r10
    2ef3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2ef8:	4d 01 d0                                        	add    r8,r10
    2efb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2f00:	4d 01 d0                                        	add    r8,r10
    2f03:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2f08:	4d 01 d0                                        	add    r8,r10
    2f0b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2f10:	4d 01 d0                                        	add    r8,r10
    2f13:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2f18:	4d 01 d0                                        	add    r8,r10
    2f1b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2f20:	4d 01 d0                                        	add    r8,r10
    2f23:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2f28:	4d 01 d0                                        	add    r8,r10
    2f2b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2f30:	4d 01 d0                                        	add    r8,r10
    2f33:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2f38:	4d 01 d0                                        	add    r8,r10
    2f3b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2f40:	4d 01 d0                                        	add    r8,r10
    2f43:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2f48:	4d 01 d0                                        	add    r8,r10
    2f4b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2f50:	4d 01 d0                                        	add    r8,r10
    2f53:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2f58:	4d 01 d0                                        	add    r8,r10
    2f5b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2f60:	4d 01 d0                                        	add    r8,r10
    2f63:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2f68:	4d 01 d0                                        	add    r8,r10
    2f6b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2f70:	4d 01 d0                                        	add    r8,r10
    2f73:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2f78:	4d 01 d0                                        	add    r8,r10
    2f7b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2f80:	4d 01 d0                                        	add    r8,r10
    2f83:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2f88:	4d 01 d0                                        	add    r8,r10
    2f8b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2f90:	4d 01 d0                                        	add    r8,r10
    2f93:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2f98:	4d 01 d0                                        	add    r8,r10
    2f9b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2fa0:	4d 01 d0                                        	add    r8,r10
    2fa3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2fa8:	4d 01 d0                                        	add    r8,r10
    2fab:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2fb0:	4d 01 d0                                        	add    r8,r10
    2fb3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2fb8:	4d 01 d0                                        	add    r8,r10
    2fbb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2fc0:	4d 01 d0                                        	add    r8,r10
    2fc3:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2fc8:	4d 01 d0                                        	add    r8,r10
    2fcb:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2fd0:	4d 01 d0                                        	add    r8,r10
    2fd3:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2fd8:	4d 01 d0                                        	add    r8,r10
    2fdb:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2fe0:	4d 01 d0                                        	add    r8,r10
    2fe3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2fe8:	4d 01 d0                                        	add    r8,r10
    2feb:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2ff0:	4d 01 d0                                        	add    r8,r10
    2ff3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2ff8:	4d 01 d0                                        	add    r8,r10
    2ffb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3000:	4d 01 d0                                        	add    r8,r10
    3003:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3008:	4d 01 d0                                        	add    r8,r10
    300b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3010:	4d 01 d0                                        	add    r8,r10
    3013:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3018:	4d 01 d0                                        	add    r8,r10
    301b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3020:	4d 01 d0                                        	add    r8,r10
    3023:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3028:	4d 01 d0                                        	add    r8,r10
    302b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3030:	4d 01 d0                                        	add    r8,r10
    3033:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3038:	4d 01 d0                                        	add    r8,r10
    303b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3040:	4d 01 d0                                        	add    r8,r10
    3043:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3048:	4d 01 d0                                        	add    r8,r10
    304b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3050:	4d 01 d0                                        	add    r8,r10
    3053:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3058:	4d 01 d0                                        	add    r8,r10
    305b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3060:	4d 01 d0                                        	add    r8,r10
    3063:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3068:	4d 01 d0                                        	add    r8,r10
    306b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3070:	4d 01 d0                                        	add    r8,r10
    3073:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3078:	4d 01 d0                                        	add    r8,r10
    307b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3080:	4d 01 d0                                        	add    r8,r10
    3083:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3088:	4d 01 d0                                        	add    r8,r10
    308b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3090:	4d 01 d0                                        	add    r8,r10
    3093:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3098:	4d 01 d0                                        	add    r8,r10
    309b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    30a0:	4d 01 d0                                        	add    r8,r10
    30a3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    30a8:	4d 01 d0                                        	add    r8,r10
    30ab:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    30b0:	4d 01 d0                                        	add    r8,r10
    30b3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    30b8:	4d 01 d0                                        	add    r8,r10
    30bb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    30c0:	4d 01 d0                                        	add    r8,r10
    30c3:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    30c8:	4d 01 d0                                        	add    r8,r10
    30cb:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    30d0:	4d 01 d0                                        	add    r8,r10
    30d3:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    30d8:	4d 01 d0                                        	add    r8,r10
    30db:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    30e0:	4d 01 d0                                        	add    r8,r10
    30e3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    30e8:	4d 01 d0                                        	add    r8,r10
    30eb:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    30f0:	4d 01 d0                                        	add    r8,r10
    30f3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    30f8:	4d 01 d0                                        	add    r8,r10
    30fb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3100:	4d 01 d0                                        	add    r8,r10
    3103:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3108:	4d 01 d0                                        	add    r8,r10
    310b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3110:	4d 01 d0                                        	add    r8,r10
    3113:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3118:	4d 01 d0                                        	add    r8,r10
    311b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3120:	4d 01 d0                                        	add    r8,r10
    3123:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3128:	4d 01 d0                                        	add    r8,r10
    312b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3130:	4d 01 d0                                        	add    r8,r10
    3133:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3138:	4d 01 d0                                        	add    r8,r10
    313b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3140:	4d 01 d0                                        	add    r8,r10
    3143:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3148:	4d 01 d0                                        	add    r8,r10
    314b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3150:	4d 01 d0                                        	add    r8,r10
    3153:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3158:	4d 01 d0                                        	add    r8,r10
    315b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3160:	4d 01 d0                                        	add    r8,r10
    3163:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3168:	4d 01 d0                                        	add    r8,r10
    316b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3170:	4d 01 d0                                        	add    r8,r10
    3173:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3178:	4d 01 d0                                        	add    r8,r10
    317b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3180:	4d 01 d0                                        	add    r8,r10
    3183:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3188:	4d 01 d0                                        	add    r8,r10
    318b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3190:	4d 01 d0                                        	add    r8,r10
    3193:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3198:	4d 01 d0                                        	add    r8,r10
    319b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    31a0:	4d 01 d0                                        	add    r8,r10
    31a3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    31a8:	4d 01 d0                                        	add    r8,r10
    31ab:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    31b0:	4d 01 d0                                        	add    r8,r10
    31b3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    31b8:	4d 01 d0                                        	add    r8,r10
    31bb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    31c0:	4d 01 d0                                        	add    r8,r10
    31c3:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    31c8:	4d 01 d0                                        	add    r8,r10
    31cb:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    31d0:	4d 01 d0                                        	add    r8,r10
    31d3:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    31d8:	4d 01 d0                                        	add    r8,r10
    31db:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    31e0:	4d 01 d0                                        	add    r8,r10
    31e3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    31e8:	4d 01 d0                                        	add    r8,r10
    31eb:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    31f0:	4d 01 d0                                        	add    r8,r10
    31f3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    31f8:	4d 01 d0                                        	add    r8,r10
    31fb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3200:	4d 01 d0                                        	add    r8,r10
    3203:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3208:	4d 01 d0                                        	add    r8,r10
    320b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3210:	4d 01 d0                                        	add    r8,r10
    3213:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3218:	4d 01 d0                                        	add    r8,r10
    321b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3220:	4d 01 d0                                        	add    r8,r10
    3223:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3228:	4d 01 d0                                        	add    r8,r10
    322b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3230:	4d 01 d0                                        	add    r8,r10
    3233:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3238:	4d 01 d0                                        	add    r8,r10
    323b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3240:	4d 01 d0                                        	add    r8,r10
    3243:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3248:	4d 01 d0                                        	add    r8,r10
    324b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3250:	4d 01 d0                                        	add    r8,r10
    3253:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3258:	4d 01 d0                                        	add    r8,r10
    325b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3260:	4d 01 d0                                        	add    r8,r10
    3263:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3268:	4d 01 d0                                        	add    r8,r10
    326b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3270:	4d 01 d0                                        	add    r8,r10
    3273:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3278:	4d 01 d0                                        	add    r8,r10
    327b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3280:	4d 01 d0                                        	add    r8,r10
    3283:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3288:	4d 01 d0                                        	add    r8,r10
    328b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3290:	4d 01 d0                                        	add    r8,r10
    3293:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3298:	4d 01 d0                                        	add    r8,r10
    329b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    32a0:	4d 01 d0                                        	add    r8,r10
    32a3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    32a8:	4d 01 d0                                        	add    r8,r10
    32ab:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    32b0:	4d 01 d0                                        	add    r8,r10
    32b3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    32b8:	4d 01 d0                                        	add    r8,r10
    32bb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    32c0:	4d 01 d0                                        	add    r8,r10
    32c3:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    32c8:	4d 01 d0                                        	add    r8,r10
    32cb:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    32d0:	4d 01 d0                                        	add    r8,r10
    32d3:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    32d8:	4d 01 d0                                        	add    r8,r10
    32db:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    32e0:	4d 01 d0                                        	add    r8,r10
    32e3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    32e8:	4d 01 d0                                        	add    r8,r10
    32eb:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    32f0:	4d 01 d0                                        	add    r8,r10
    32f3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    32f8:	4d 01 d0                                        	add    r8,r10
    32fb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3300:	4d 01 d0                                        	add    r8,r10
    3303:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3308:	4d 01 d0                                        	add    r8,r10
    330b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3310:	4d 01 d0                                        	add    r8,r10
    3313:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3318:	4d 01 d0                                        	add    r8,r10
    331b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3320:	4d 01 d0                                        	add    r8,r10
    3323:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3328:	4d 01 d0                                        	add    r8,r10
    332b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3330:	4d 01 d0                                        	add    r8,r10
    3333:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3338:	4d 01 d0                                        	add    r8,r10
    333b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3340:	4d 01 d0                                        	add    r8,r10
    3343:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3348:	4d 01 d0                                        	add    r8,r10
    334b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3350:	4d 01 d0                                        	add    r8,r10
    3353:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3358:	4d 01 d0                                        	add    r8,r10
    335b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3360:	4d 01 d0                                        	add    r8,r10
    3363:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3368:	4d 01 d0                                        	add    r8,r10
    336b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3370:	4d 01 d0                                        	add    r8,r10
    3373:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3378:	4d 01 d0                                        	add    r8,r10
    337b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3380:	4d 01 d0                                        	add    r8,r10
    3383:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3388:	4d 01 d0                                        	add    r8,r10
    338b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3390:	4d 01 d0                                        	add    r8,r10
    3393:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3398:	4d 01 d0                                        	add    r8,r10
    339b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    33a0:	4d 01 d0                                        	add    r8,r10
    33a3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    33a8:	4d 01 d0                                        	add    r8,r10
    33ab:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    33b0:	4d 01 d0                                        	add    r8,r10
    33b3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    33b8:	4d 01 d0                                        	add    r8,r10
    33bb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    33c0:	4d 01 d0                                        	add    r8,r10
    33c3:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    33c8:	4d 01 d0                                        	add    r8,r10
    33cb:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    33d0:	4d 01 d0                                        	add    r8,r10
    33d3:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    33d8:	4d 01 d0                                        	add    r8,r10
    33db:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    33e0:	4d 01 d0                                        	add    r8,r10
    33e3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    33e8:	4d 01 d0                                        	add    r8,r10
    33eb:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    33f0:	4d 01 d0                                        	add    r8,r10
    33f3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    33f8:	4d 01 d0                                        	add    r8,r10
    33fb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3400:	4d 01 d0                                        	add    r8,r10
    3403:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3408:	4d 01 d0                                        	add    r8,r10
    340b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3410:	4d 01 d0                                        	add    r8,r10
    3413:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3418:	4d 01 d0                                        	add    r8,r10
    341b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3420:	4d 01 d0                                        	add    r8,r10
    3423:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3428:	4d 01 d0                                        	add    r8,r10
    342b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3430:	4d 01 d0                                        	add    r8,r10
    3433:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3438:	4d 01 d0                                        	add    r8,r10
    343b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3440:	4d 01 d0                                        	add    r8,r10
    3443:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3448:	4d 01 d0                                        	add    r8,r10
    344b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3450:	4d 01 d0                                        	add    r8,r10
    3453:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3458:	4d 01 d0                                        	add    r8,r10
    345b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3460:	4d 01 d0                                        	add    r8,r10
    3463:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3468:	4d 01 d0                                        	add    r8,r10
    346b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3470:	4d 01 d0                                        	add    r8,r10
    3473:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3478:	4d 01 d0                                        	add    r8,r10
    347b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3480:	4d 01 d0                                        	add    r8,r10
    3483:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3488:	4d 01 d0                                        	add    r8,r10
    348b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3490:	4d 01 d0                                        	add    r8,r10
    3493:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3498:	4d 01 d0                                        	add    r8,r10
    349b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    34a0:	4d 01 d0                                        	add    r8,r10
    34a3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    34a8:	4d 01 d0                                        	add    r8,r10
    34ab:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    34b0:	4d 01 d0                                        	add    r8,r10
    34b3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    34b8:	4d 01 d0                                        	add    r8,r10
    34bb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    34c0:	4d 01 d0                                        	add    r8,r10
    34c3:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    34c8:	4d 01 d0                                        	add    r8,r10
    34cb:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    34d0:	4d 01 d0                                        	add    r8,r10
    34d3:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    34d8:	4d 01 d0                                        	add    r8,r10
    34db:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    34e0:	4d 01 d0                                        	add    r8,r10
    34e3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    34e8:	4d 01 d0                                        	add    r8,r10
    34eb:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    34f0:	4d 01 d0                                        	add    r8,r10
    34f3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    34f8:	4d 01 d0                                        	add    r8,r10
    34fb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3500:	4d 01 d0                                        	add    r8,r10
    3503:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3508:	4d 01 d0                                        	add    r8,r10
    350b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3510:	4d 01 d0                                        	add    r8,r10
    3513:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3518:	4d 01 d0                                        	add    r8,r10
    351b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3520:	4d 01 d0                                        	add    r8,r10
    3523:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3528:	4d 01 d0                                        	add    r8,r10
    352b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3530:	4d 01 d0                                        	add    r8,r10
    3533:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3538:	4d 01 d0                                        	add    r8,r10
    353b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3540:	4d 01 d0                                        	add    r8,r10
    3543:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3548:	4d 01 d0                                        	add    r8,r10
    354b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3550:	4d 01 d0                                        	add    r8,r10
    3553:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3558:	4d 01 d0                                        	add    r8,r10
    355b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3560:	4d 01 d0                                        	add    r8,r10
    3563:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3568:	4d 01 d0                                        	add    r8,r10
    356b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3570:	4d 01 d0                                        	add    r8,r10
    3573:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3578:	4d 01 d0                                        	add    r8,r10
    357b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3580:	4d 01 d0                                        	add    r8,r10
    3583:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3588:	4d 01 d0                                        	add    r8,r10
    358b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3590:	4d 01 d0                                        	add    r8,r10
    3593:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3598:	4d 01 d0                                        	add    r8,r10
    359b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    35a0:	4d 01 d0                                        	add    r8,r10
    35a3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    35a8:	4d 01 d0                                        	add    r8,r10
    35ab:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    35b0:	4d 01 d0                                        	add    r8,r10
    35b3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    35b8:	4d 01 d0                                        	add    r8,r10
    35bb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    35c0:	4d 01 d0                                        	add    r8,r10
    35c3:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    35c8:	4d 01 d0                                        	add    r8,r10
    35cb:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    35d0:	4d 01 d0                                        	add    r8,r10
    35d3:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    35d8:	4d 01 d0                                        	add    r8,r10
    35db:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    35e0:	4d 01 d0                                        	add    r8,r10
    35e3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    35e8:	4d 01 d0                                        	add    r8,r10
    35eb:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    35f0:	4d 01 d0                                        	add    r8,r10
    35f3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    35f8:	4d 01 d0                                        	add    r8,r10
    35fb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3600:	4d 01 d0                                        	add    r8,r10
    3603:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3608:	4d 01 d0                                        	add    r8,r10
    360b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3610:	4d 01 d0                                        	add    r8,r10
    3613:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3618:	4d 01 d0                                        	add    r8,r10
    361b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3620:	4d 01 d0                                        	add    r8,r10
    3623:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3628:	4d 01 d0                                        	add    r8,r10
    362b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3630:	4d 01 d0                                        	add    r8,r10
    3633:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3638:	4d 01 d0                                        	add    r8,r10
    363b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3640:	4d 01 d0                                        	add    r8,r10
    3643:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3648:	4d 01 d0                                        	add    r8,r10
    364b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3650:	4d 01 d0                                        	add    r8,r10
    3653:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3658:	4d 01 d0                                        	add    r8,r10
    365b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3660:	4d 01 d0                                        	add    r8,r10
    3663:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3668:	4d 01 d0                                        	add    r8,r10
    366b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3670:	4d 01 d0                                        	add    r8,r10
    3673:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3678:	4d 01 d0                                        	add    r8,r10
    367b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3680:	4d 01 d0                                        	add    r8,r10
    3683:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3688:	4d 01 d0                                        	add    r8,r10
    368b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3690:	4d 01 d0                                        	add    r8,r10
    3693:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3698:	4d 01 d0                                        	add    r8,r10
    369b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    36a0:	4d 01 d0                                        	add    r8,r10
    36a3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    36a8:	4d 01 d0                                        	add    r8,r10
    36ab:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    36b0:	4d 01 d0                                        	add    r8,r10
    36b3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    36b8:	4d 01 d0                                        	add    r8,r10
    36bb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    36c0:	4d 01 d0                                        	add    r8,r10
    36c3:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    36c8:	4d 01 d0                                        	add    r8,r10
    36cb:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    36d0:	4d 01 d0                                        	add    r8,r10
    36d3:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    36d8:	4d 01 d0                                        	add    r8,r10
    36db:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    36e0:	4d 01 d0                                        	add    r8,r10
    36e3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    36e8:	4d 01 d0                                        	add    r8,r10
    36eb:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    36f0:	4d 01 d0                                        	add    r8,r10
    36f3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    36f8:	4d 01 d0                                        	add    r8,r10
    36fb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3700:	4d 01 d0                                        	add    r8,r10
    3703:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3708:	4d 01 d0                                        	add    r8,r10
    370b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3710:	4d 01 d0                                        	add    r8,r10
    3713:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3718:	4d 01 d0                                        	add    r8,r10
    371b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3720:	4d 01 d0                                        	add    r8,r10
    3723:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3728:	4d 01 d0                                        	add    r8,r10
    372b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3730:	4d 01 d0                                        	add    r8,r10
    3733:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3738:	4d 01 d0                                        	add    r8,r10
    373b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3740:	4d 01 d0                                        	add    r8,r10
    3743:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3748:	4d 01 d0                                        	add    r8,r10
    374b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3750:	4d 01 d0                                        	add    r8,r10
    3753:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3758:	4d 01 d0                                        	add    r8,r10
    375b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3760:	4d 01 d0                                        	add    r8,r10
    3763:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3768:	4d 01 d0                                        	add    r8,r10
    376b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3770:	4d 01 d0                                        	add    r8,r10
    3773:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3778:	4d 01 d0                                        	add    r8,r10
    377b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3780:	4d 01 d0                                        	add    r8,r10
    3783:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3788:	4d 01 d0                                        	add    r8,r10
    378b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3790:	4d 01 d0                                        	add    r8,r10
    3793:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3798:	4d 01 d0                                        	add    r8,r10
    379b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    37a0:	4d 01 d0                                        	add    r8,r10
    37a3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    37a8:	4d 01 d0                                        	add    r8,r10
    37ab:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    37b0:	4d 01 d0                                        	add    r8,r10
    37b3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    37b8:	4d 01 d0                                        	add    r8,r10
    37bb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    37c0:	4d 01 d0                                        	add    r8,r10
    37c3:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    37c8:	4d 01 d0                                        	add    r8,r10
    37cb:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    37d0:	4d 01 d0                                        	add    r8,r10
    37d3:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    37d8:	4d 01 d0                                        	add    r8,r10
    37db:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    37e0:	4d 01 d0                                        	add    r8,r10
    37e3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    37e8:	4d 01 d0                                        	add    r8,r10
    37eb:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    37f0:	4d 01 d0                                        	add    r8,r10
    37f3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    37f8:	4d 01 d0                                        	add    r8,r10
    37fb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3800:	4d 01 d0                                        	add    r8,r10
    3803:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3808:	4d 01 d0                                        	add    r8,r10
    380b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3810:	4d 01 d0                                        	add    r8,r10
    3813:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3818:	4d 01 d0                                        	add    r8,r10
    381b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3820:	4d 01 d0                                        	add    r8,r10
    3823:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3828:	4d 01 d0                                        	add    r8,r10
    382b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3830:	4d 01 d0                                        	add    r8,r10
    3833:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3838:	4d 01 d0                                        	add    r8,r10
    383b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3840:	4d 01 d0                                        	add    r8,r10
    3843:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3848:	4d 01 d0                                        	add    r8,r10
    384b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3850:	4d 01 d0                                        	add    r8,r10
    3853:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3858:	4d 01 d0                                        	add    r8,r10
    385b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3860:	4d 01 d0                                        	add    r8,r10
    3863:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3868:	4d 01 d0                                        	add    r8,r10
    386b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3870:	4d 01 d0                                        	add    r8,r10
    3873:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3878:	4d 01 d0                                        	add    r8,r10
    387b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3880:	4d 01 d0                                        	add    r8,r10
    3883:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3888:	4d 01 d0                                        	add    r8,r10
    388b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3890:	4d 01 d0                                        	add    r8,r10
    3893:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3898:	4d 01 d0                                        	add    r8,r10
    389b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    38a0:	4d 01 d0                                        	add    r8,r10
    38a3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    38a8:	4d 01 d0                                        	add    r8,r10
    38ab:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    38b0:	4d 01 d0                                        	add    r8,r10
    38b3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    38b8:	4d 01 d0                                        	add    r8,r10
    38bb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    38c0:	4d 01 d0                                        	add    r8,r10
    38c3:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    38c8:	4d 01 d0                                        	add    r8,r10
    38cb:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    38d0:	4d 01 d0                                        	add    r8,r10
    38d3:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    38d8:	4d 01 d0                                        	add    r8,r10
    38db:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    38e0:	4d 01 d0                                        	add    r8,r10
    38e3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    38e8:	4d 01 d0                                        	add    r8,r10
    38eb:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    38f0:	4d 01 d0                                        	add    r8,r10
    38f3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    38f8:	4d 01 d0                                        	add    r8,r10
    38fb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3900:	4d 01 d0                                        	add    r8,r10
    3903:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3908:	4d 01 d0                                        	add    r8,r10
    390b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3910:	4d 01 d0                                        	add    r8,r10
    3913:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3918:	4d 01 d0                                        	add    r8,r10
    391b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3920:	4d 01 d0                                        	add    r8,r10
    3923:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3928:	4d 01 d0                                        	add    r8,r10
    392b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3930:	4d 01 d0                                        	add    r8,r10
    3933:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3938:	4d 01 d0                                        	add    r8,r10
    393b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3940:	4d 01 d0                                        	add    r8,r10
    3943:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3948:	4d 01 d0                                        	add    r8,r10
    394b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3950:	4d 01 d0                                        	add    r8,r10
    3953:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3958:	4d 01 d0                                        	add    r8,r10
    395b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3960:	4d 01 d0                                        	add    r8,r10
    3963:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3968:	4d 01 d0                                        	add    r8,r10
    396b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3970:	4d 01 d0                                        	add    r8,r10
    3973:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3978:	4d 01 d0                                        	add    r8,r10
    397b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3980:	4d 01 d0                                        	add    r8,r10
    3983:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3988:	4d 01 d0                                        	add    r8,r10
    398b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3990:	4d 01 d0                                        	add    r8,r10
    3993:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3998:	4d 01 d0                                        	add    r8,r10
    399b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    39a0:	4d 01 d0                                        	add    r8,r10
    39a3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    39a8:	4d 01 d0                                        	add    r8,r10
    39ab:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    39b0:	4d 01 d0                                        	add    r8,r10
    39b3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    39b8:	4d 01 d0                                        	add    r8,r10
    39bb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    39c0:	4d 01 d0                                        	add    r8,r10
    39c3:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    39c8:	4d 01 d0                                        	add    r8,r10
    39cb:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    39d0:	4d 01 d0                                        	add    r8,r10
    39d3:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    39d8:	4d 01 d0                                        	add    r8,r10
    39db:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    39e0:	4d 01 d0                                        	add    r8,r10
    39e3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    39e8:	4d 01 d0                                        	add    r8,r10
    39eb:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    39f0:	4d 01 d0                                        	add    r8,r10
    39f3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    39f8:	4d 01 d0                                        	add    r8,r10
    39fb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3a00:	4d 01 d0                                        	add    r8,r10
    3a03:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3a08:	4d 01 d0                                        	add    r8,r10
    3a0b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3a10:	4d 01 d0                                        	add    r8,r10
    3a13:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3a18:	4d 01 d0                                        	add    r8,r10
    3a1b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3a20:	4d 01 d0                                        	add    r8,r10
    3a23:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3a28:	4d 01 d0                                        	add    r8,r10
    3a2b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3a30:	4d 01 d0                                        	add    r8,r10
    3a33:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3a38:	4d 01 d0                                        	add    r8,r10
    3a3b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3a40:	4d 01 d0                                        	add    r8,r10
    3a43:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3a48:	4d 01 d0                                        	add    r8,r10
    3a4b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3a50:	4d 01 d0                                        	add    r8,r10
    3a53:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3a58:	4d 01 d0                                        	add    r8,r10
    3a5b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3a60:	4d 01 d0                                        	add    r8,r10
    3a63:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3a68:	4d 01 d0                                        	add    r8,r10
    3a6b:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3a70:	4d 01 d0                                        	add    r8,r10
    3a73:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3a78:	4d 01 d0                                        	add    r8,r10
    3a7b:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3a80:	4d 01 d0                                        	add    r8,r10
    3a83:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3a88:	4d 01 d0                                        	add    r8,r10
    3a8b:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3a90:	4d 01 d0                                        	add    r8,r10
    3a93:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3a98:	4d 01 d0                                        	add    r8,r10
    3a9b:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3aa0:	4d 01 d0                                        	add    r8,r10
    3aa3:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3aa8:	4d 01 d0                                        	add    r8,r10
    3aab:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3ab0:	4d 01 d0                                        	add    r8,r10
    3ab3:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3ab8:	4d 01 d0                                        	add    r8,r10
    3abb:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3ac0:	4d 01 d0                                        	add    r8,r10
    3ac3:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3ac8:	4d 01 d0                                        	add    r8,r10
    3acb:	41 f6 c1 01                                     	test   r9b,0x1
    3acf:	74 04                                           	je     3ad5 <join_2>
    3ad1:	49 83 f0 01                                     	xor    r8,0x1

0000000000003ad5 <join_2>:
    3ad5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3ada:	4d 01 d0                                        	add    r8,r10
    3add:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3ae2:	4d 01 d0                                        	add    r8,r10
    3ae5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3aea:	4d 01 d0                                        	add    r8,r10
    3aed:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3af2:	4d 01 d0                                        	add    r8,r10
    3af5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3afa:	4d 01 d0                                        	add    r8,r10
    3afd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3b02:	4d 01 d0                                        	add    r8,r10
    3b05:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3b0a:	4d 01 d0                                        	add    r8,r10
    3b0d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3b12:	4d 01 d0                                        	add    r8,r10
    3b15:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3b1a:	4d 01 d0                                        	add    r8,r10
    3b1d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3b22:	4d 01 d0                                        	add    r8,r10
    3b25:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3b2a:	4d 01 d0                                        	add    r8,r10
    3b2d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3b32:	4d 01 d0                                        	add    r8,r10
    3b35:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3b3a:	4d 01 d0                                        	add    r8,r10
    3b3d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3b42:	4d 01 d0                                        	add    r8,r10
    3b45:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3b4a:	4d 01 d0                                        	add    r8,r10
    3b4d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3b52:	4d 01 d0                                        	add    r8,r10
    3b55:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3b5a:	4d 01 d0                                        	add    r8,r10
    3b5d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3b62:	4d 01 d0                                        	add    r8,r10
    3b65:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3b6a:	4d 01 d0                                        	add    r8,r10
    3b6d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3b72:	4d 01 d0                                        	add    r8,r10
    3b75:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3b7a:	4d 01 d0                                        	add    r8,r10
    3b7d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3b82:	4d 01 d0                                        	add    r8,r10
    3b85:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3b8a:	4d 01 d0                                        	add    r8,r10
    3b8d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3b92:	4d 01 d0                                        	add    r8,r10
    3b95:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3b9a:	4d 01 d0                                        	add    r8,r10
    3b9d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3ba2:	4d 01 d0                                        	add    r8,r10
    3ba5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3baa:	4d 01 d0                                        	add    r8,r10
    3bad:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3bb2:	4d 01 d0                                        	add    r8,r10
    3bb5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3bba:	4d 01 d0                                        	add    r8,r10
    3bbd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3bc2:	4d 01 d0                                        	add    r8,r10
    3bc5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3bca:	4d 01 d0                                        	add    r8,r10
    3bcd:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3bd2:	4d 01 d0                                        	add    r8,r10
    3bd5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3bda:	4d 01 d0                                        	add    r8,r10
    3bdd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3be2:	4d 01 d0                                        	add    r8,r10
    3be5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3bea:	4d 01 d0                                        	add    r8,r10
    3bed:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3bf2:	4d 01 d0                                        	add    r8,r10
    3bf5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3bfa:	4d 01 d0                                        	add    r8,r10
    3bfd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3c02:	4d 01 d0                                        	add    r8,r10
    3c05:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3c0a:	4d 01 d0                                        	add    r8,r10
    3c0d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3c12:	4d 01 d0                                        	add    r8,r10
    3c15:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3c1a:	4d 01 d0                                        	add    r8,r10
    3c1d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3c22:	4d 01 d0                                        	add    r8,r10
    3c25:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3c2a:	4d 01 d0                                        	add    r8,r10
    3c2d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3c32:	4d 01 d0                                        	add    r8,r10
    3c35:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3c3a:	4d 01 d0                                        	add    r8,r10
    3c3d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3c42:	4d 01 d0                                        	add    r8,r10
    3c45:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3c4a:	4d 01 d0                                        	add    r8,r10
    3c4d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3c52:	4d 01 d0                                        	add    r8,r10
    3c55:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3c5a:	4d 01 d0                                        	add    r8,r10
    3c5d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3c62:	4d 01 d0                                        	add    r8,r10
    3c65:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3c6a:	4d 01 d0                                        	add    r8,r10
    3c6d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3c72:	4d 01 d0                                        	add    r8,r10
    3c75:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3c7a:	4d 01 d0                                        	add    r8,r10
    3c7d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3c82:	4d 01 d0                                        	add    r8,r10
    3c85:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3c8a:	4d 01 d0                                        	add    r8,r10
    3c8d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3c92:	4d 01 d0                                        	add    r8,r10
    3c95:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3c9a:	4d 01 d0                                        	add    r8,r10
    3c9d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3ca2:	4d 01 d0                                        	add    r8,r10
    3ca5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3caa:	4d 01 d0                                        	add    r8,r10
    3cad:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3cb2:	4d 01 d0                                        	add    r8,r10
    3cb5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3cba:	4d 01 d0                                        	add    r8,r10
    3cbd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3cc2:	4d 01 d0                                        	add    r8,r10
    3cc5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3cca:	4d 01 d0                                        	add    r8,r10
    3ccd:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3cd2:	4d 01 d0                                        	add    r8,r10
    3cd5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3cda:	4d 01 d0                                        	add    r8,r10
    3cdd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3ce2:	4d 01 d0                                        	add    r8,r10
    3ce5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3cea:	4d 01 d0                                        	add    r8,r10
    3ced:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3cf2:	4d 01 d0                                        	add    r8,r10
    3cf5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3cfa:	4d 01 d0                                        	add    r8,r10
    3cfd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3d02:	4d 01 d0                                        	add    r8,r10
    3d05:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3d0a:	4d 01 d0                                        	add    r8,r10
    3d0d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3d12:	4d 01 d0                                        	add    r8,r10
    3d15:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3d1a:	4d 01 d0                                        	add    r8,r10
    3d1d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3d22:	4d 01 d0                                        	add    r8,r10
    3d25:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3d2a:	4d 01 d0                                        	add    r8,r10
    3d2d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3d32:	4d 01 d0                                        	add    r8,r10
    3d35:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3d3a:	4d 01 d0                                        	add    r8,r10
    3d3d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3d42:	4d 01 d0                                        	add    r8,r10
    3d45:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3d4a:	4d 01 d0                                        	add    r8,r10
    3d4d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3d52:	4d 01 d0                                        	add    r8,r10
    3d55:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3d5a:	4d 01 d0                                        	add    r8,r10
    3d5d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3d62:	4d 01 d0                                        	add    r8,r10
    3d65:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3d6a:	4d 01 d0                                        	add    r8,r10
    3d6d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3d72:	4d 01 d0                                        	add    r8,r10
    3d75:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3d7a:	4d 01 d0                                        	add    r8,r10
    3d7d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3d82:	4d 01 d0                                        	add    r8,r10
    3d85:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3d8a:	4d 01 d0                                        	add    r8,r10
    3d8d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3d92:	4d 01 d0                                        	add    r8,r10
    3d95:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3d9a:	4d 01 d0                                        	add    r8,r10
    3d9d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3da2:	4d 01 d0                                        	add    r8,r10
    3da5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3daa:	4d 01 d0                                        	add    r8,r10
    3dad:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3db2:	4d 01 d0                                        	add    r8,r10
    3db5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3dba:	4d 01 d0                                        	add    r8,r10
    3dbd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3dc2:	4d 01 d0                                        	add    r8,r10
    3dc5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3dca:	4d 01 d0                                        	add    r8,r10
    3dcd:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3dd2:	4d 01 d0                                        	add    r8,r10
    3dd5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3dda:	4d 01 d0                                        	add    r8,r10
    3ddd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3de2:	4d 01 d0                                        	add    r8,r10
    3de5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3dea:	4d 01 d0                                        	add    r8,r10
    3ded:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3df2:	4d 01 d0                                        	add    r8,r10
    3df5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3dfa:	4d 01 d0                                        	add    r8,r10
    3dfd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3e02:	4d 01 d0                                        	add    r8,r10
    3e05:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3e0a:	4d 01 d0                                        	add    r8,r10
    3e0d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3e12:	4d 01 d0                                        	add    r8,r10
    3e15:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3e1a:	4d 01 d0                                        	add    r8,r10
    3e1d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3e22:	4d 01 d0                                        	add    r8,r10
    3e25:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3e2a:	4d 01 d0                                        	add    r8,r10
    3e2d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3e32:	4d 01 d0                                        	add    r8,r10
    3e35:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3e3a:	4d 01 d0                                        	add    r8,r10
    3e3d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3e42:	4d 01 d0                                        	add    r8,r10
    3e45:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3e4a:	4d 01 d0                                        	add    r8,r10
    3e4d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3e52:	4d 01 d0                                        	add    r8,r10
    3e55:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3e5a:	4d 01 d0                                        	add    r8,r10
    3e5d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3e62:	4d 01 d0                                        	add    r8,r10
    3e65:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3e6a:	4d 01 d0                                        	add    r8,r10
    3e6d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3e72:	4d 01 d0                                        	add    r8,r10
    3e75:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3e7a:	4d 01 d0                                        	add    r8,r10
    3e7d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3e82:	4d 01 d0                                        	add    r8,r10
    3e85:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3e8a:	4d 01 d0                                        	add    r8,r10
    3e8d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3e92:	4d 01 d0                                        	add    r8,r10
    3e95:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3e9a:	4d 01 d0                                        	add    r8,r10
    3e9d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3ea2:	4d 01 d0                                        	add    r8,r10
    3ea5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3eaa:	4d 01 d0                                        	add    r8,r10
    3ead:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3eb2:	4d 01 d0                                        	add    r8,r10
    3eb5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3eba:	4d 01 d0                                        	add    r8,r10
    3ebd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3ec2:	4d 01 d0                                        	add    r8,r10
    3ec5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3eca:	4d 01 d0                                        	add    r8,r10
    3ecd:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3ed2:	4d 01 d0                                        	add    r8,r10
    3ed5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3eda:	4d 01 d0                                        	add    r8,r10
    3edd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3ee2:	4d 01 d0                                        	add    r8,r10
    3ee5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3eea:	4d 01 d0                                        	add    r8,r10
    3eed:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3ef2:	4d 01 d0                                        	add    r8,r10
    3ef5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3efa:	4d 01 d0                                        	add    r8,r10
    3efd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3f02:	4d 01 d0                                        	add    r8,r10
    3f05:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3f0a:	4d 01 d0                                        	add    r8,r10
    3f0d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3f12:	4d 01 d0                                        	add    r8,r10
    3f15:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3f1a:	4d 01 d0                                        	add    r8,r10
    3f1d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3f22:	4d 01 d0                                        	add    r8,r10
    3f25:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3f2a:	4d 01 d0                                        	add    r8,r10
    3f2d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3f32:	4d 01 d0                                        	add    r8,r10
    3f35:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3f3a:	4d 01 d0                                        	add    r8,r10
    3f3d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3f42:	4d 01 d0                                        	add    r8,r10
    3f45:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3f4a:	4d 01 d0                                        	add    r8,r10
    3f4d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3f52:	4d 01 d0                                        	add    r8,r10
    3f55:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3f5a:	4d 01 d0                                        	add    r8,r10
    3f5d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3f62:	4d 01 d0                                        	add    r8,r10
    3f65:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3f6a:	4d 01 d0                                        	add    r8,r10
    3f6d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3f72:	4d 01 d0                                        	add    r8,r10
    3f75:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3f7a:	4d 01 d0                                        	add    r8,r10
    3f7d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3f82:	4d 01 d0                                        	add    r8,r10
    3f85:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3f8a:	4d 01 d0                                        	add    r8,r10
    3f8d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3f92:	4d 01 d0                                        	add    r8,r10
    3f95:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3f9a:	4d 01 d0                                        	add    r8,r10
    3f9d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3fa2:	4d 01 d0                                        	add    r8,r10
    3fa5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3faa:	4d 01 d0                                        	add    r8,r10
    3fad:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3fb2:	4d 01 d0                                        	add    r8,r10
    3fb5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3fba:	4d 01 d0                                        	add    r8,r10
    3fbd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3fc2:	4d 01 d0                                        	add    r8,r10
    3fc5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3fca:	4d 01 d0                                        	add    r8,r10
    3fcd:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3fd2:	4d 01 d0                                        	add    r8,r10
    3fd5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3fda:	4d 01 d0                                        	add    r8,r10
    3fdd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3fe2:	4d 01 d0                                        	add    r8,r10
    3fe5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3fea:	4d 01 d0                                        	add    r8,r10
    3fed:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3ff2:	4d 01 d0                                        	add    r8,r10
    3ff5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3ffa:	4d 01 d0                                        	add    r8,r10
    3ffd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4002:	4d 01 d0                                        	add    r8,r10
    4005:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    400a:	4d 01 d0                                        	add    r8,r10
    400d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4012:	4d 01 d0                                        	add    r8,r10
    4015:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    401a:	4d 01 d0                                        	add    r8,r10
    401d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4022:	4d 01 d0                                        	add    r8,r10
    4025:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    402a:	4d 01 d0                                        	add    r8,r10
    402d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4032:	4d 01 d0                                        	add    r8,r10
    4035:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    403a:	4d 01 d0                                        	add    r8,r10
    403d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4042:	4d 01 d0                                        	add    r8,r10
    4045:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    404a:	4d 01 d0                                        	add    r8,r10
    404d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4052:	4d 01 d0                                        	add    r8,r10
    4055:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    405a:	4d 01 d0                                        	add    r8,r10
    405d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4062:	4d 01 d0                                        	add    r8,r10
    4065:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    406a:	4d 01 d0                                        	add    r8,r10
    406d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4072:	4d 01 d0                                        	add    r8,r10
    4075:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    407a:	4d 01 d0                                        	add    r8,r10
    407d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4082:	4d 01 d0                                        	add    r8,r10
    4085:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    408a:	4d 01 d0                                        	add    r8,r10
    408d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4092:	4d 01 d0                                        	add    r8,r10
    4095:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    409a:	4d 01 d0                                        	add    r8,r10
    409d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    40a2:	4d 01 d0                                        	add    r8,r10
    40a5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    40aa:	4d 01 d0                                        	add    r8,r10
    40ad:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    40b2:	4d 01 d0                                        	add    r8,r10
    40b5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    40ba:	4d 01 d0                                        	add    r8,r10
    40bd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    40c2:	4d 01 d0                                        	add    r8,r10
    40c5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    40ca:	4d 01 d0                                        	add    r8,r10
    40cd:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    40d2:	4d 01 d0                                        	add    r8,r10
    40d5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    40da:	4d 01 d0                                        	add    r8,r10
    40dd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    40e2:	4d 01 d0                                        	add    r8,r10
    40e5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    40ea:	4d 01 d0                                        	add    r8,r10
    40ed:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    40f2:	4d 01 d0                                        	add    r8,r10
    40f5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    40fa:	4d 01 d0                                        	add    r8,r10
    40fd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4102:	4d 01 d0                                        	add    r8,r10
    4105:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    410a:	4d 01 d0                                        	add    r8,r10
    410d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4112:	4d 01 d0                                        	add    r8,r10
    4115:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    411a:	4d 01 d0                                        	add    r8,r10
    411d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4122:	4d 01 d0                                        	add    r8,r10
    4125:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    412a:	4d 01 d0                                        	add    r8,r10
    412d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4132:	4d 01 d0                                        	add    r8,r10
    4135:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    413a:	4d 01 d0                                        	add    r8,r10
    413d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4142:	4d 01 d0                                        	add    r8,r10
    4145:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    414a:	4d 01 d0                                        	add    r8,r10
    414d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4152:	4d 01 d0                                        	add    r8,r10
    4155:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    415a:	4d 01 d0                                        	add    r8,r10
    415d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4162:	4d 01 d0                                        	add    r8,r10
    4165:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    416a:	4d 01 d0                                        	add    r8,r10
    416d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4172:	4d 01 d0                                        	add    r8,r10
    4175:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    417a:	4d 01 d0                                        	add    r8,r10
    417d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4182:	4d 01 d0                                        	add    r8,r10
    4185:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    418a:	4d 01 d0                                        	add    r8,r10
    418d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4192:	4d 01 d0                                        	add    r8,r10
    4195:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    419a:	4d 01 d0                                        	add    r8,r10
    419d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    41a2:	4d 01 d0                                        	add    r8,r10
    41a5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    41aa:	4d 01 d0                                        	add    r8,r10
    41ad:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    41b2:	4d 01 d0                                        	add    r8,r10
    41b5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    41ba:	4d 01 d0                                        	add    r8,r10
    41bd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    41c2:	4d 01 d0                                        	add    r8,r10
    41c5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    41ca:	4d 01 d0                                        	add    r8,r10
    41cd:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    41d2:	4d 01 d0                                        	add    r8,r10
    41d5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    41da:	4d 01 d0                                        	add    r8,r10
    41dd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    41e2:	4d 01 d0                                        	add    r8,r10
    41e5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    41ea:	4d 01 d0                                        	add    r8,r10
    41ed:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    41f2:	4d 01 d0                                        	add    r8,r10
    41f5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    41fa:	4d 01 d0                                        	add    r8,r10
    41fd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4202:	4d 01 d0                                        	add    r8,r10
    4205:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    420a:	4d 01 d0                                        	add    r8,r10
    420d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4212:	4d 01 d0                                        	add    r8,r10
    4215:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    421a:	4d 01 d0                                        	add    r8,r10
    421d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4222:	4d 01 d0                                        	add    r8,r10
    4225:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    422a:	4d 01 d0                                        	add    r8,r10
    422d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4232:	4d 01 d0                                        	add    r8,r10
    4235:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    423a:	4d 01 d0                                        	add    r8,r10
    423d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4242:	4d 01 d0                                        	add    r8,r10
    4245:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    424a:	4d 01 d0                                        	add    r8,r10
    424d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4252:	4d 01 d0                                        	add    r8,r10
    4255:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    425a:	4d 01 d0                                        	add    r8,r10
    425d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4262:	4d 01 d0                                        	add    r8,r10
    4265:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    426a:	4d 01 d0                                        	add    r8,r10
    426d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4272:	4d 01 d0                                        	add    r8,r10
    4275:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    427a:	4d 01 d0                                        	add    r8,r10
    427d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4282:	4d 01 d0                                        	add    r8,r10
    4285:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    428a:	4d 01 d0                                        	add    r8,r10
    428d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4292:	4d 01 d0                                        	add    r8,r10
    4295:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    429a:	4d 01 d0                                        	add    r8,r10
    429d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    42a2:	4d 01 d0                                        	add    r8,r10
    42a5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    42aa:	4d 01 d0                                        	add    r8,r10
    42ad:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    42b2:	4d 01 d0                                        	add    r8,r10
    42b5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    42ba:	4d 01 d0                                        	add    r8,r10
    42bd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    42c2:	4d 01 d0                                        	add    r8,r10
    42c5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    42ca:	4d 01 d0                                        	add    r8,r10
    42cd:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    42d2:	4d 01 d0                                        	add    r8,r10
    42d5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    42da:	4d 01 d0                                        	add    r8,r10
    42dd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    42e2:	4d 01 d0                                        	add    r8,r10
    42e5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    42ea:	4d 01 d0                                        	add    r8,r10
    42ed:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    42f2:	4d 01 d0                                        	add    r8,r10
    42f5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    42fa:	4d 01 d0                                        	add    r8,r10
    42fd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4302:	4d 01 d0                                        	add    r8,r10
    4305:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    430a:	4d 01 d0                                        	add    r8,r10
    430d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4312:	4d 01 d0                                        	add    r8,r10
    4315:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    431a:	4d 01 d0                                        	add    r8,r10
    431d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4322:	4d 01 d0                                        	add    r8,r10
    4325:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    432a:	4d 01 d0                                        	add    r8,r10
    432d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4332:	4d 01 d0                                        	add    r8,r10
    4335:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    433a:	4d 01 d0                                        	add    r8,r10
    433d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4342:	4d 01 d0                                        	add    r8,r10
    4345:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    434a:	4d 01 d0                                        	add    r8,r10
    434d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4352:	4d 01 d0                                        	add    r8,r10
    4355:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    435a:	4d 01 d0                                        	add    r8,r10
    435d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4362:	4d 01 d0                                        	add    r8,r10
    4365:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    436a:	4d 01 d0                                        	add    r8,r10
    436d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4372:	4d 01 d0                                        	add    r8,r10
    4375:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    437a:	4d 01 d0                                        	add    r8,r10
    437d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4382:	4d 01 d0                                        	add    r8,r10
    4385:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    438a:	4d 01 d0                                        	add    r8,r10
    438d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4392:	4d 01 d0                                        	add    r8,r10
    4395:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    439a:	4d 01 d0                                        	add    r8,r10
    439d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    43a2:	4d 01 d0                                        	add    r8,r10
    43a5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    43aa:	4d 01 d0                                        	add    r8,r10
    43ad:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    43b2:	4d 01 d0                                        	add    r8,r10
    43b5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    43ba:	4d 01 d0                                        	add    r8,r10
    43bd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    43c2:	4d 01 d0                                        	add    r8,r10
    43c5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    43ca:	4d 01 d0                                        	add    r8,r10
    43cd:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    43d2:	4d 01 d0                                        	add    r8,r10
    43d5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    43da:	4d 01 d0                                        	add    r8,r10
    43dd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    43e2:	4d 01 d0                                        	add    r8,r10
    43e5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    43ea:	4d 01 d0                                        	add    r8,r10
    43ed:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    43f2:	4d 01 d0                                        	add    r8,r10
    43f5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    43fa:	4d 01 d0                                        	add    r8,r10
    43fd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4402:	4d 01 d0                                        	add    r8,r10
    4405:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    440a:	4d 01 d0                                        	add    r8,r10
    440d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4412:	4d 01 d0                                        	add    r8,r10
    4415:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    441a:	4d 01 d0                                        	add    r8,r10
    441d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4422:	4d 01 d0                                        	add    r8,r10
    4425:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    442a:	4d 01 d0                                        	add    r8,r10
    442d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4432:	4d 01 d0                                        	add    r8,r10
    4435:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    443a:	4d 01 d0                                        	add    r8,r10
    443d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4442:	4d 01 d0                                        	add    r8,r10
    4445:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    444a:	4d 01 d0                                        	add    r8,r10
    444d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4452:	4d 01 d0                                        	add    r8,r10
    4455:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    445a:	4d 01 d0                                        	add    r8,r10
    445d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4462:	4d 01 d0                                        	add    r8,r10
    4465:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    446a:	4d 01 d0                                        	add    r8,r10
    446d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4472:	4d 01 d0                                        	add    r8,r10
    4475:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    447a:	4d 01 d0                                        	add    r8,r10
    447d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4482:	4d 01 d0                                        	add    r8,r10
    4485:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    448a:	4d 01 d0                                        	add    r8,r10
    448d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4492:	4d 01 d0                                        	add    r8,r10
    4495:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    449a:	4d 01 d0                                        	add    r8,r10
    449d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    44a2:	4d 01 d0                                        	add    r8,r10
    44a5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    44aa:	4d 01 d0                                        	add    r8,r10
    44ad:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    44b2:	4d 01 d0                                        	add    r8,r10
    44b5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    44ba:	4d 01 d0                                        	add    r8,r10
    44bd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    44c2:	4d 01 d0                                        	add    r8,r10
    44c5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    44ca:	4d 01 d0                                        	add    r8,r10
    44cd:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    44d2:	4d 01 d0                                        	add    r8,r10
    44d5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    44da:	4d 01 d0                                        	add    r8,r10
    44dd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    44e2:	4d 01 d0                                        	add    r8,r10
    44e5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    44ea:	4d 01 d0                                        	add    r8,r10
    44ed:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    44f2:	4d 01 d0                                        	add    r8,r10
    44f5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    44fa:	4d 01 d0                                        	add    r8,r10
    44fd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4502:	4d 01 d0                                        	add    r8,r10
    4505:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    450a:	4d 01 d0                                        	add    r8,r10
    450d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4512:	4d 01 d0                                        	add    r8,r10
    4515:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    451a:	4d 01 d0                                        	add    r8,r10
    451d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4522:	4d 01 d0                                        	add    r8,r10
    4525:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    452a:	4d 01 d0                                        	add    r8,r10
    452d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4532:	4d 01 d0                                        	add    r8,r10
    4535:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    453a:	4d 01 d0                                        	add    r8,r10
    453d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4542:	4d 01 d0                                        	add    r8,r10
    4545:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    454a:	4d 01 d0                                        	add    r8,r10
    454d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4552:	4d 01 d0                                        	add    r8,r10
    4555:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    455a:	4d 01 d0                                        	add    r8,r10
    455d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4562:	4d 01 d0                                        	add    r8,r10
    4565:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    456a:	4d 01 d0                                        	add    r8,r10
    456d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4572:	4d 01 d0                                        	add    r8,r10
    4575:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    457a:	4d 01 d0                                        	add    r8,r10
    457d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4582:	4d 01 d0                                        	add    r8,r10
    4585:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    458a:	4d 01 d0                                        	add    r8,r10
    458d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4592:	4d 01 d0                                        	add    r8,r10
    4595:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    459a:	4d 01 d0                                        	add    r8,r10
    459d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    45a2:	4d 01 d0                                        	add    r8,r10
    45a5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    45aa:	4d 01 d0                                        	add    r8,r10
    45ad:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    45b2:	4d 01 d0                                        	add    r8,r10
    45b5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    45ba:	4d 01 d0                                        	add    r8,r10
    45bd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    45c2:	4d 01 d0                                        	add    r8,r10
    45c5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    45ca:	4d 01 d0                                        	add    r8,r10
    45cd:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    45d2:	4d 01 d0                                        	add    r8,r10
    45d5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    45da:	4d 01 d0                                        	add    r8,r10
    45dd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    45e2:	4d 01 d0                                        	add    r8,r10
    45e5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    45ea:	4d 01 d0                                        	add    r8,r10
    45ed:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    45f2:	4d 01 d0                                        	add    r8,r10
    45f5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    45fa:	4d 01 d0                                        	add    r8,r10
    45fd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4602:	4d 01 d0                                        	add    r8,r10
    4605:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    460a:	4d 01 d0                                        	add    r8,r10
    460d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4612:	4d 01 d0                                        	add    r8,r10
    4615:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    461a:	4d 01 d0                                        	add    r8,r10
    461d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4622:	4d 01 d0                                        	add    r8,r10
    4625:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    462a:	4d 01 d0                                        	add    r8,r10
    462d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4632:	4d 01 d0                                        	add    r8,r10
    4635:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    463a:	4d 01 d0                                        	add    r8,r10
    463d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4642:	4d 01 d0                                        	add    r8,r10
    4645:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    464a:	4d 01 d0                                        	add    r8,r10
    464d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4652:	4d 01 d0                                        	add    r8,r10
    4655:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    465a:	4d 01 d0                                        	add    r8,r10
    465d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4662:	4d 01 d0                                        	add    r8,r10
    4665:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    466a:	4d 01 d0                                        	add    r8,r10
    466d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4672:	4d 01 d0                                        	add    r8,r10
    4675:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    467a:	4d 01 d0                                        	add    r8,r10
    467d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4682:	4d 01 d0                                        	add    r8,r10
    4685:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    468a:	4d 01 d0                                        	add    r8,r10
    468d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4692:	4d 01 d0                                        	add    r8,r10
    4695:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    469a:	4d 01 d0                                        	add    r8,r10
    469d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    46a2:	4d 01 d0                                        	add    r8,r10
    46a5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    46aa:	4d 01 d0                                        	add    r8,r10
    46ad:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    46b2:	4d 01 d0                                        	add    r8,r10
    46b5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    46ba:	4d 01 d0                                        	add    r8,r10
    46bd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    46c2:	4d 01 d0                                        	add    r8,r10
    46c5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    46ca:	4d 01 d0                                        	add    r8,r10
    46cd:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    46d2:	4d 01 d0                                        	add    r8,r10
    46d5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    46da:	4d 01 d0                                        	add    r8,r10
    46dd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    46e2:	4d 01 d0                                        	add    r8,r10
    46e5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    46ea:	4d 01 d0                                        	add    r8,r10
    46ed:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    46f2:	4d 01 d0                                        	add    r8,r10
    46f5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    46fa:	4d 01 d0                                        	add    r8,r10
    46fd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4702:	4d 01 d0                                        	add    r8,r10
    4705:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    470a:	4d 01 d0                                        	add    r8,r10
    470d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4712:	4d 01 d0                                        	add    r8,r10
    4715:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    471a:	4d 01 d0                                        	add    r8,r10
    471d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4722:	4d 01 d0                                        	add    r8,r10
    4725:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    472a:	4d 01 d0                                        	add    r8,r10
    472d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4732:	4d 01 d0                                        	add    r8,r10
    4735:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    473a:	4d 01 d0                                        	add    r8,r10
    473d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4742:	4d 01 d0                                        	add    r8,r10
    4745:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    474a:	4d 01 d0                                        	add    r8,r10
    474d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4752:	4d 01 d0                                        	add    r8,r10
    4755:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    475a:	4d 01 d0                                        	add    r8,r10
    475d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4762:	4d 01 d0                                        	add    r8,r10
    4765:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    476a:	4d 01 d0                                        	add    r8,r10
    476d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4772:	4d 01 d0                                        	add    r8,r10
    4775:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    477a:	4d 01 d0                                        	add    r8,r10
    477d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4782:	4d 01 d0                                        	add    r8,r10
    4785:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    478a:	4d 01 d0                                        	add    r8,r10
    478d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4792:	4d 01 d0                                        	add    r8,r10
    4795:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    479a:	4d 01 d0                                        	add    r8,r10
    479d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    47a2:	4d 01 d0                                        	add    r8,r10
    47a5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    47aa:	4d 01 d0                                        	add    r8,r10
    47ad:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    47b2:	4d 01 d0                                        	add    r8,r10
    47b5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    47ba:	4d 01 d0                                        	add    r8,r10
    47bd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    47c2:	4d 01 d0                                        	add    r8,r10
    47c5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    47ca:	4d 01 d0                                        	add    r8,r10
    47cd:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    47d2:	4d 01 d0                                        	add    r8,r10
    47d5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    47da:	4d 01 d0                                        	add    r8,r10
    47dd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    47e2:	4d 01 d0                                        	add    r8,r10
    47e5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    47ea:	4d 01 d0                                        	add    r8,r10
    47ed:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    47f2:	4d 01 d0                                        	add    r8,r10
    47f5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    47fa:	4d 01 d0                                        	add    r8,r10
    47fd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4802:	4d 01 d0                                        	add    r8,r10
    4805:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    480a:	4d 01 d0                                        	add    r8,r10
    480d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4812:	4d 01 d0                                        	add    r8,r10
    4815:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    481a:	4d 01 d0                                        	add    r8,r10
    481d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4822:	4d 01 d0                                        	add    r8,r10
    4825:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    482a:	4d 01 d0                                        	add    r8,r10
    482d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4832:	4d 01 d0                                        	add    r8,r10
    4835:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    483a:	4d 01 d0                                        	add    r8,r10
    483d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4842:	4d 01 d0                                        	add    r8,r10
    4845:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    484a:	4d 01 d0                                        	add    r8,r10
    484d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4852:	4d 01 d0                                        	add    r8,r10
    4855:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    485a:	4d 01 d0                                        	add    r8,r10
    485d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4862:	4d 01 d0                                        	add    r8,r10
    4865:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    486a:	4d 01 d0                                        	add    r8,r10
    486d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4872:	4d 01 d0                                        	add    r8,r10
    4875:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    487a:	4d 01 d0                                        	add    r8,r10
    487d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4882:	4d 01 d0                                        	add    r8,r10
    4885:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    488a:	4d 01 d0                                        	add    r8,r10
    488d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4892:	4d 01 d0                                        	add    r8,r10
    4895:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    489a:	4d 01 d0                                        	add    r8,r10
    489d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    48a2:	4d 01 d0                                        	add    r8,r10
    48a5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    48aa:	4d 01 d0                                        	add    r8,r10
    48ad:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    48b2:	4d 01 d0                                        	add    r8,r10
    48b5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    48ba:	4d 01 d0                                        	add    r8,r10
    48bd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    48c2:	4d 01 d0                                        	add    r8,r10
    48c5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    48ca:	4d 01 d0                                        	add    r8,r10
    48cd:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    48d2:	4d 01 d0                                        	add    r8,r10
    48d5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    48da:	4d 01 d0                                        	add    r8,r10
    48dd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    48e2:	4d 01 d0                                        	add    r8,r10
    48e5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    48ea:	4d 01 d0                                        	add    r8,r10
    48ed:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    48f2:	4d 01 d0                                        	add    r8,r10
    48f5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    48fa:	4d 01 d0                                        	add    r8,r10
    48fd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4902:	4d 01 d0                                        	add    r8,r10
    4905:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    490a:	4d 01 d0                                        	add    r8,r10
    490d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4912:	4d 01 d0                                        	add    r8,r10
    4915:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    491a:	4d 01 d0                                        	add    r8,r10
    491d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4922:	4d 01 d0                                        	add    r8,r10
    4925:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    492a:	4d 01 d0                                        	add    r8,r10
    492d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4932:	4d 01 d0                                        	add    r8,r10
    4935:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    493a:	4d 01 d0                                        	add    r8,r10
    493d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4942:	4d 01 d0                                        	add    r8,r10
    4945:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    494a:	4d 01 d0                                        	add    r8,r10
    494d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4952:	4d 01 d0                                        	add    r8,r10
    4955:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    495a:	4d 01 d0                                        	add    r8,r10
    495d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4962:	4d 01 d0                                        	add    r8,r10
    4965:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    496a:	4d 01 d0                                        	add    r8,r10
    496d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4972:	4d 01 d0                                        	add    r8,r10
    4975:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    497a:	4d 01 d0                                        	add    r8,r10
    497d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4982:	4d 01 d0                                        	add    r8,r10
    4985:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    498a:	4d 01 d0                                        	add    r8,r10
    498d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4992:	4d 01 d0                                        	add    r8,r10
    4995:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    499a:	4d 01 d0                                        	add    r8,r10
    499d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    49a2:	4d 01 d0                                        	add    r8,r10
    49a5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    49aa:	4d 01 d0                                        	add    r8,r10
    49ad:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    49b2:	4d 01 d0                                        	add    r8,r10
    49b5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    49ba:	4d 01 d0                                        	add    r8,r10
    49bd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    49c2:	4d 01 d0                                        	add    r8,r10
    49c5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    49ca:	4d 01 d0                                        	add    r8,r10
    49cd:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    49d2:	4d 01 d0                                        	add    r8,r10
    49d5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    49da:	4d 01 d0                                        	add    r8,r10
    49dd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    49e2:	4d 01 d0                                        	add    r8,r10
    49e5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    49ea:	4d 01 d0                                        	add    r8,r10
    49ed:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    49f2:	4d 01 d0                                        	add    r8,r10
    49f5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    49fa:	4d 01 d0                                        	add    r8,r10
    49fd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4a02:	4d 01 d0                                        	add    r8,r10
    4a05:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4a0a:	4d 01 d0                                        	add    r8,r10
    4a0d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4a12:	4d 01 d0                                        	add    r8,r10
    4a15:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4a1a:	4d 01 d0                                        	add    r8,r10
    4a1d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4a22:	4d 01 d0                                        	add    r8,r10
    4a25:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4a2a:	4d 01 d0                                        	add    r8,r10
    4a2d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4a32:	4d 01 d0                                        	add    r8,r10
    4a35:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4a3a:	4d 01 d0                                        	add    r8,r10
    4a3d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4a42:	4d 01 d0                                        	add    r8,r10
    4a45:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4a4a:	4d 01 d0                                        	add    r8,r10
    4a4d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4a52:	4d 01 d0                                        	add    r8,r10
    4a55:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4a5a:	4d 01 d0                                        	add    r8,r10
    4a5d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4a62:	4d 01 d0                                        	add    r8,r10
    4a65:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4a6a:	4d 01 d0                                        	add    r8,r10
    4a6d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4a72:	4d 01 d0                                        	add    r8,r10
    4a75:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4a7a:	4d 01 d0                                        	add    r8,r10
    4a7d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4a82:	4d 01 d0                                        	add    r8,r10
    4a85:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4a8a:	4d 01 d0                                        	add    r8,r10
    4a8d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4a92:	4d 01 d0                                        	add    r8,r10
    4a95:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4a9a:	4d 01 d0                                        	add    r8,r10
    4a9d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4aa2:	4d 01 d0                                        	add    r8,r10
    4aa5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4aaa:	4d 01 d0                                        	add    r8,r10
    4aad:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4ab2:	4d 01 d0                                        	add    r8,r10
    4ab5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4aba:	4d 01 d0                                        	add    r8,r10
    4abd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4ac2:	4d 01 d0                                        	add    r8,r10
    4ac5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4aca:	4d 01 d0                                        	add    r8,r10
    4acd:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4ad2:	4d 01 d0                                        	add    r8,r10
    4ad5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4ada:	4d 01 d0                                        	add    r8,r10
    4add:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4ae2:	4d 01 d0                                        	add    r8,r10
    4ae5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4aea:	4d 01 d0                                        	add    r8,r10
    4aed:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4af2:	4d 01 d0                                        	add    r8,r10
    4af5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4afa:	4d 01 d0                                        	add    r8,r10
    4afd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4b02:	4d 01 d0                                        	add    r8,r10
    4b05:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4b0a:	4d 01 d0                                        	add    r8,r10
    4b0d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4b12:	4d 01 d0                                        	add    r8,r10
    4b15:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4b1a:	4d 01 d0                                        	add    r8,r10
    4b1d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4b22:	4d 01 d0                                        	add    r8,r10
    4b25:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4b2a:	4d 01 d0                                        	add    r8,r10
    4b2d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4b32:	4d 01 d0                                        	add    r8,r10
    4b35:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4b3a:	4d 01 d0                                        	add    r8,r10
    4b3d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4b42:	4d 01 d0                                        	add    r8,r10
    4b45:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4b4a:	4d 01 d0                                        	add    r8,r10
    4b4d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4b52:	4d 01 d0                                        	add    r8,r10
    4b55:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4b5a:	4d 01 d0                                        	add    r8,r10
    4b5d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4b62:	4d 01 d0                                        	add    r8,r10
    4b65:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4b6a:	4d 01 d0                                        	add    r8,r10
    4b6d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4b72:	4d 01 d0                                        	add    r8,r10
    4b75:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4b7a:	4d 01 d0                                        	add    r8,r10
    4b7d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4b82:	4d 01 d0                                        	add    r8,r10
    4b85:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4b8a:	4d 01 d0                                        	add    r8,r10
    4b8d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4b92:	4d 01 d0                                        	add    r8,r10
    4b95:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4b9a:	4d 01 d0                                        	add    r8,r10
    4b9d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4ba2:	4d 01 d0                                        	add    r8,r10
    4ba5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4baa:	4d 01 d0                                        	add    r8,r10
    4bad:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4bb2:	4d 01 d0                                        	add    r8,r10
    4bb5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4bba:	4d 01 d0                                        	add    r8,r10
    4bbd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4bc2:	4d 01 d0                                        	add    r8,r10
    4bc5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4bca:	4d 01 d0                                        	add    r8,r10
    4bcd:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4bd2:	4d 01 d0                                        	add    r8,r10
    4bd5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4bda:	4d 01 d0                                        	add    r8,r10
    4bdd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4be2:	4d 01 d0                                        	add    r8,r10
    4be5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4bea:	4d 01 d0                                        	add    r8,r10
    4bed:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4bf2:	4d 01 d0                                        	add    r8,r10
    4bf5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4bfa:	4d 01 d0                                        	add    r8,r10
    4bfd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4c02:	4d 01 d0                                        	add    r8,r10
    4c05:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4c0a:	4d 01 d0                                        	add    r8,r10
    4c0d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4c12:	4d 01 d0                                        	add    r8,r10
    4c15:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4c1a:	4d 01 d0                                        	add    r8,r10
    4c1d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4c22:	4d 01 d0                                        	add    r8,r10
    4c25:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4c2a:	4d 01 d0                                        	add    r8,r10
    4c2d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4c32:	4d 01 d0                                        	add    r8,r10
    4c35:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4c3a:	4d 01 d0                                        	add    r8,r10
    4c3d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4c42:	4d 01 d0                                        	add    r8,r10
    4c45:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4c4a:	4d 01 d0                                        	add    r8,r10
    4c4d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4c52:	4d 01 d0                                        	add    r8,r10
    4c55:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4c5a:	4d 01 d0                                        	add    r8,r10
    4c5d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4c62:	4d 01 d0                                        	add    r8,r10
    4c65:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4c6a:	4d 01 d0                                        	add    r8,r10
    4c6d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4c72:	4d 01 d0                                        	add    r8,r10
    4c75:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4c7a:	4d 01 d0                                        	add    r8,r10
    4c7d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4c82:	4d 01 d0                                        	add    r8,r10
    4c85:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4c8a:	4d 01 d0                                        	add    r8,r10
    4c8d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4c92:	4d 01 d0                                        	add    r8,r10
    4c95:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4c9a:	4d 01 d0                                        	add    r8,r10
    4c9d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4ca2:	4d 01 d0                                        	add    r8,r10
    4ca5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4caa:	4d 01 d0                                        	add    r8,r10
    4cad:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4cb2:	4d 01 d0                                        	add    r8,r10
    4cb5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4cba:	4d 01 d0                                        	add    r8,r10
    4cbd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4cc2:	4d 01 d0                                        	add    r8,r10
    4cc5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4cca:	4d 01 d0                                        	add    r8,r10
    4ccd:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4cd2:	4d 01 d0                                        	add    r8,r10
    4cd5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4cda:	4d 01 d0                                        	add    r8,r10
    4cdd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4ce2:	4d 01 d0                                        	add    r8,r10
    4ce5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4cea:	4d 01 d0                                        	add    r8,r10
    4ced:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4cf2:	4d 01 d0                                        	add    r8,r10
    4cf5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4cfa:	4d 01 d0                                        	add    r8,r10
    4cfd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4d02:	4d 01 d0                                        	add    r8,r10
    4d05:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4d0a:	4d 01 d0                                        	add    r8,r10
    4d0d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4d12:	4d 01 d0                                        	add    r8,r10
    4d15:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4d1a:	4d 01 d0                                        	add    r8,r10
    4d1d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4d22:	4d 01 d0                                        	add    r8,r10
    4d25:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4d2a:	4d 01 d0                                        	add    r8,r10
    4d2d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4d32:	4d 01 d0                                        	add    r8,r10
    4d35:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4d3a:	4d 01 d0                                        	add    r8,r10
    4d3d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4d42:	4d 01 d0                                        	add    r8,r10
    4d45:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4d4a:	4d 01 d0                                        	add    r8,r10
    4d4d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4d52:	4d 01 d0                                        	add    r8,r10
    4d55:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4d5a:	4d 01 d0                                        	add    r8,r10
    4d5d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4d62:	4d 01 d0                                        	add    r8,r10
    4d65:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4d6a:	4d 01 d0                                        	add    r8,r10
    4d6d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4d72:	4d 01 d0                                        	add    r8,r10
    4d75:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4d7a:	4d 01 d0                                        	add    r8,r10
    4d7d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4d82:	4d 01 d0                                        	add    r8,r10
    4d85:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4d8a:	4d 01 d0                                        	add    r8,r10
    4d8d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4d92:	4d 01 d0                                        	add    r8,r10
    4d95:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4d9a:	4d 01 d0                                        	add    r8,r10
    4d9d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4da2:	4d 01 d0                                        	add    r8,r10
    4da5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4daa:	4d 01 d0                                        	add    r8,r10
    4dad:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4db2:	4d 01 d0                                        	add    r8,r10
    4db5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4dba:	4d 01 d0                                        	add    r8,r10
    4dbd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4dc2:	4d 01 d0                                        	add    r8,r10
    4dc5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4dca:	4d 01 d0                                        	add    r8,r10
    4dcd:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4dd2:	4d 01 d0                                        	add    r8,r10
    4dd5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4dda:	4d 01 d0                                        	add    r8,r10
    4ddd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4de2:	4d 01 d0                                        	add    r8,r10
    4de5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4dea:	4d 01 d0                                        	add    r8,r10
    4ded:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4df2:	4d 01 d0                                        	add    r8,r10
    4df5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4dfa:	4d 01 d0                                        	add    r8,r10
    4dfd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4e02:	4d 01 d0                                        	add    r8,r10
    4e05:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4e0a:	4d 01 d0                                        	add    r8,r10
    4e0d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4e12:	4d 01 d0                                        	add    r8,r10
    4e15:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4e1a:	4d 01 d0                                        	add    r8,r10
    4e1d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4e22:	4d 01 d0                                        	add    r8,r10
    4e25:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4e2a:	4d 01 d0                                        	add    r8,r10
    4e2d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4e32:	4d 01 d0                                        	add    r8,r10
    4e35:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4e3a:	4d 01 d0                                        	add    r8,r10
    4e3d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4e42:	4d 01 d0                                        	add    r8,r10
    4e45:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4e4a:	4d 01 d0                                        	add    r8,r10
    4e4d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4e52:	4d 01 d0                                        	add    r8,r10
    4e55:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4e5a:	4d 01 d0                                        	add    r8,r10
    4e5d:	41 f6 c1 01                                     	test   r9b,0x1
    4e61:	74 04                                           	je     4e67 <join_3>
    4e63:	49 83 f0 01                                     	xor    r8,0x1

0000000000004e67 <join_3>:
    4e67:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4e6c:	4d 01 d0                                        	add    r8,r10
    4e6f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4e74:	4d 01 d0                                        	add    r8,r10
    4e77:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4e7c:	4d 01 d0                                        	add    r8,r10
    4e7f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4e84:	4d 01 d0                                        	add    r8,r10
    4e87:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4e8c:	4d 01 d0                                        	add    r8,r10
    4e8f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4e94:	4d 01 d0                                        	add    r8,r10
    4e97:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4e9c:	4d 01 d0                                        	add    r8,r10
    4e9f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4ea4:	4d 01 d0                                        	add    r8,r10
    4ea7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4eac:	4d 01 d0                                        	add    r8,r10
    4eaf:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4eb4:	4d 01 d0                                        	add    r8,r10
    4eb7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4ebc:	4d 01 d0                                        	add    r8,r10
    4ebf:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4ec4:	4d 01 d0                                        	add    r8,r10
    4ec7:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4ecc:	4d 01 d0                                        	add    r8,r10
    4ecf:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4ed4:	4d 01 d0                                        	add    r8,r10
    4ed7:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4edc:	4d 01 d0                                        	add    r8,r10
    4edf:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4ee4:	4d 01 d0                                        	add    r8,r10
    4ee7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4eec:	4d 01 d0                                        	add    r8,r10
    4eef:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4ef4:	4d 01 d0                                        	add    r8,r10
    4ef7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4efc:	4d 01 d0                                        	add    r8,r10
    4eff:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4f04:	4d 01 d0                                        	add    r8,r10
    4f07:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4f0c:	4d 01 d0                                        	add    r8,r10
    4f0f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4f14:	4d 01 d0                                        	add    r8,r10
    4f17:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4f1c:	4d 01 d0                                        	add    r8,r10
    4f1f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4f24:	4d 01 d0                                        	add    r8,r10
    4f27:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4f2c:	4d 01 d0                                        	add    r8,r10
    4f2f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4f34:	4d 01 d0                                        	add    r8,r10
    4f37:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4f3c:	4d 01 d0                                        	add    r8,r10
    4f3f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4f44:	4d 01 d0                                        	add    r8,r10
    4f47:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4f4c:	4d 01 d0                                        	add    r8,r10
    4f4f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4f54:	4d 01 d0                                        	add    r8,r10
    4f57:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4f5c:	4d 01 d0                                        	add    r8,r10
    4f5f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4f64:	4d 01 d0                                        	add    r8,r10
    4f67:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4f6c:	4d 01 d0                                        	add    r8,r10
    4f6f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4f74:	4d 01 d0                                        	add    r8,r10
    4f77:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4f7c:	4d 01 d0                                        	add    r8,r10
    4f7f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4f84:	4d 01 d0                                        	add    r8,r10
    4f87:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4f8c:	4d 01 d0                                        	add    r8,r10
    4f8f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4f94:	4d 01 d0                                        	add    r8,r10
    4f97:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4f9c:	4d 01 d0                                        	add    r8,r10
    4f9f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4fa4:	4d 01 d0                                        	add    r8,r10
    4fa7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4fac:	4d 01 d0                                        	add    r8,r10
    4faf:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4fb4:	4d 01 d0                                        	add    r8,r10
    4fb7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4fbc:	4d 01 d0                                        	add    r8,r10
    4fbf:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4fc4:	4d 01 d0                                        	add    r8,r10
    4fc7:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4fcc:	4d 01 d0                                        	add    r8,r10
    4fcf:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4fd4:	4d 01 d0                                        	add    r8,r10
    4fd7:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4fdc:	4d 01 d0                                        	add    r8,r10
    4fdf:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4fe4:	4d 01 d0                                        	add    r8,r10
    4fe7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4fec:	4d 01 d0                                        	add    r8,r10
    4fef:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4ff4:	4d 01 d0                                        	add    r8,r10
    4ff7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4ffc:	4d 01 d0                                        	add    r8,r10
    4fff:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5004:	4d 01 d0                                        	add    r8,r10
    5007:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    500c:	4d 01 d0                                        	add    r8,r10
    500f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5014:	4d 01 d0                                        	add    r8,r10
    5017:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    501c:	4d 01 d0                                        	add    r8,r10
    501f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5024:	4d 01 d0                                        	add    r8,r10
    5027:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    502c:	4d 01 d0                                        	add    r8,r10
    502f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5034:	4d 01 d0                                        	add    r8,r10
    5037:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    503c:	4d 01 d0                                        	add    r8,r10
    503f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5044:	4d 01 d0                                        	add    r8,r10
    5047:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    504c:	4d 01 d0                                        	add    r8,r10
    504f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5054:	4d 01 d0                                        	add    r8,r10
    5057:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    505c:	4d 01 d0                                        	add    r8,r10
    505f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5064:	4d 01 d0                                        	add    r8,r10
    5067:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    506c:	4d 01 d0                                        	add    r8,r10
    506f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5074:	4d 01 d0                                        	add    r8,r10
    5077:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    507c:	4d 01 d0                                        	add    r8,r10
    507f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5084:	4d 01 d0                                        	add    r8,r10
    5087:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    508c:	4d 01 d0                                        	add    r8,r10
    508f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5094:	4d 01 d0                                        	add    r8,r10
    5097:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    509c:	4d 01 d0                                        	add    r8,r10
    509f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    50a4:	4d 01 d0                                        	add    r8,r10
    50a7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    50ac:	4d 01 d0                                        	add    r8,r10
    50af:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    50b4:	4d 01 d0                                        	add    r8,r10
    50b7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    50bc:	4d 01 d0                                        	add    r8,r10
    50bf:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    50c4:	4d 01 d0                                        	add    r8,r10
    50c7:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    50cc:	4d 01 d0                                        	add    r8,r10
    50cf:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    50d4:	4d 01 d0                                        	add    r8,r10
    50d7:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    50dc:	4d 01 d0                                        	add    r8,r10
    50df:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    50e4:	4d 01 d0                                        	add    r8,r10
    50e7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    50ec:	4d 01 d0                                        	add    r8,r10
    50ef:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    50f4:	4d 01 d0                                        	add    r8,r10
    50f7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    50fc:	4d 01 d0                                        	add    r8,r10
    50ff:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5104:	4d 01 d0                                        	add    r8,r10
    5107:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    510c:	4d 01 d0                                        	add    r8,r10
    510f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5114:	4d 01 d0                                        	add    r8,r10
    5117:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    511c:	4d 01 d0                                        	add    r8,r10
    511f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5124:	4d 01 d0                                        	add    r8,r10
    5127:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    512c:	4d 01 d0                                        	add    r8,r10
    512f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5134:	4d 01 d0                                        	add    r8,r10
    5137:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    513c:	4d 01 d0                                        	add    r8,r10
    513f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5144:	4d 01 d0                                        	add    r8,r10
    5147:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    514c:	4d 01 d0                                        	add    r8,r10
    514f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5154:	4d 01 d0                                        	add    r8,r10
    5157:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    515c:	4d 01 d0                                        	add    r8,r10
    515f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5164:	4d 01 d0                                        	add    r8,r10
    5167:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    516c:	4d 01 d0                                        	add    r8,r10
    516f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5174:	4d 01 d0                                        	add    r8,r10
    5177:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    517c:	4d 01 d0                                        	add    r8,r10
    517f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5184:	4d 01 d0                                        	add    r8,r10
    5187:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    518c:	4d 01 d0                                        	add    r8,r10
    518f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5194:	4d 01 d0                                        	add    r8,r10
    5197:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    519c:	4d 01 d0                                        	add    r8,r10
    519f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    51a4:	4d 01 d0                                        	add    r8,r10
    51a7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    51ac:	4d 01 d0                                        	add    r8,r10
    51af:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    51b4:	4d 01 d0                                        	add    r8,r10
    51b7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    51bc:	4d 01 d0                                        	add    r8,r10
    51bf:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    51c4:	4d 01 d0                                        	add    r8,r10
    51c7:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    51cc:	4d 01 d0                                        	add    r8,r10
    51cf:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    51d4:	4d 01 d0                                        	add    r8,r10
    51d7:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    51dc:	4d 01 d0                                        	add    r8,r10
    51df:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    51e4:	4d 01 d0                                        	add    r8,r10
    51e7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    51ec:	4d 01 d0                                        	add    r8,r10
    51ef:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    51f4:	4d 01 d0                                        	add    r8,r10
    51f7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    51fc:	4d 01 d0                                        	add    r8,r10
    51ff:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5204:	4d 01 d0                                        	add    r8,r10
    5207:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    520c:	4d 01 d0                                        	add    r8,r10
    520f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5214:	4d 01 d0                                        	add    r8,r10
    5217:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    521c:	4d 01 d0                                        	add    r8,r10
    521f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5224:	4d 01 d0                                        	add    r8,r10
    5227:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    522c:	4d 01 d0                                        	add    r8,r10
    522f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5234:	4d 01 d0                                        	add    r8,r10
    5237:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    523c:	4d 01 d0                                        	add    r8,r10
    523f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5244:	4d 01 d0                                        	add    r8,r10
    5247:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    524c:	4d 01 d0                                        	add    r8,r10
    524f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5254:	4d 01 d0                                        	add    r8,r10
    5257:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    525c:	4d 01 d0                                        	add    r8,r10
    525f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5264:	4d 01 d0                                        	add    r8,r10
    5267:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    526c:	4d 01 d0                                        	add    r8,r10
    526f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5274:	4d 01 d0                                        	add    r8,r10
    5277:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    527c:	4d 01 d0                                        	add    r8,r10
    527f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5284:	4d 01 d0                                        	add    r8,r10
    5287:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    528c:	4d 01 d0                                        	add    r8,r10
    528f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5294:	4d 01 d0                                        	add    r8,r10
    5297:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    529c:	4d 01 d0                                        	add    r8,r10
    529f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    52a4:	4d 01 d0                                        	add    r8,r10
    52a7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    52ac:	4d 01 d0                                        	add    r8,r10
    52af:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    52b4:	4d 01 d0                                        	add    r8,r10
    52b7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    52bc:	4d 01 d0                                        	add    r8,r10
    52bf:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    52c4:	4d 01 d0                                        	add    r8,r10
    52c7:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    52cc:	4d 01 d0                                        	add    r8,r10
    52cf:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    52d4:	4d 01 d0                                        	add    r8,r10
    52d7:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    52dc:	4d 01 d0                                        	add    r8,r10
    52df:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    52e4:	4d 01 d0                                        	add    r8,r10
    52e7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    52ec:	4d 01 d0                                        	add    r8,r10
    52ef:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    52f4:	4d 01 d0                                        	add    r8,r10
    52f7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    52fc:	4d 01 d0                                        	add    r8,r10
    52ff:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5304:	4d 01 d0                                        	add    r8,r10
    5307:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    530c:	4d 01 d0                                        	add    r8,r10
    530f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5314:	4d 01 d0                                        	add    r8,r10
    5317:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    531c:	4d 01 d0                                        	add    r8,r10
    531f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5324:	4d 01 d0                                        	add    r8,r10
    5327:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    532c:	4d 01 d0                                        	add    r8,r10
    532f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5334:	4d 01 d0                                        	add    r8,r10
    5337:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    533c:	4d 01 d0                                        	add    r8,r10
    533f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5344:	4d 01 d0                                        	add    r8,r10
    5347:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    534c:	4d 01 d0                                        	add    r8,r10
    534f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5354:	4d 01 d0                                        	add    r8,r10
    5357:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    535c:	4d 01 d0                                        	add    r8,r10
    535f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5364:	4d 01 d0                                        	add    r8,r10
    5367:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    536c:	4d 01 d0                                        	add    r8,r10
    536f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5374:	4d 01 d0                                        	add    r8,r10
    5377:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    537c:	4d 01 d0                                        	add    r8,r10
    537f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5384:	4d 01 d0                                        	add    r8,r10
    5387:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    538c:	4d 01 d0                                        	add    r8,r10
    538f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5394:	4d 01 d0                                        	add    r8,r10
    5397:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    539c:	4d 01 d0                                        	add    r8,r10
    539f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    53a4:	4d 01 d0                                        	add    r8,r10
    53a7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    53ac:	4d 01 d0                                        	add    r8,r10
    53af:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    53b4:	4d 01 d0                                        	add    r8,r10
    53b7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    53bc:	4d 01 d0                                        	add    r8,r10
    53bf:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    53c4:	4d 01 d0                                        	add    r8,r10
    53c7:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    53cc:	4d 01 d0                                        	add    r8,r10
    53cf:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    53d4:	4d 01 d0                                        	add    r8,r10
    53d7:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    53dc:	4d 01 d0                                        	add    r8,r10
    53df:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    53e4:	4d 01 d0                                        	add    r8,r10
    53e7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    53ec:	4d 01 d0                                        	add    r8,r10
    53ef:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    53f4:	4d 01 d0                                        	add    r8,r10
    53f7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    53fc:	4d 01 d0                                        	add    r8,r10
    53ff:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5404:	4d 01 d0                                        	add    r8,r10
    5407:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    540c:	4d 01 d0                                        	add    r8,r10
    540f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5414:	4d 01 d0                                        	add    r8,r10
    5417:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    541c:	4d 01 d0                                        	add    r8,r10
    541f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5424:	4d 01 d0                                        	add    r8,r10
    5427:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    542c:	4d 01 d0                                        	add    r8,r10
    542f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5434:	4d 01 d0                                        	add    r8,r10
    5437:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    543c:	4d 01 d0                                        	add    r8,r10
    543f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5444:	4d 01 d0                                        	add    r8,r10
    5447:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    544c:	4d 01 d0                                        	add    r8,r10
    544f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5454:	4d 01 d0                                        	add    r8,r10
    5457:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    545c:	4d 01 d0                                        	add    r8,r10
    545f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5464:	4d 01 d0                                        	add    r8,r10
    5467:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    546c:	4d 01 d0                                        	add    r8,r10
    546f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5474:	4d 01 d0                                        	add    r8,r10
    5477:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    547c:	4d 01 d0                                        	add    r8,r10
    547f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5484:	4d 01 d0                                        	add    r8,r10
    5487:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    548c:	4d 01 d0                                        	add    r8,r10
    548f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5494:	4d 01 d0                                        	add    r8,r10
    5497:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    549c:	4d 01 d0                                        	add    r8,r10
    549f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    54a4:	4d 01 d0                                        	add    r8,r10
    54a7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    54ac:	4d 01 d0                                        	add    r8,r10
    54af:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    54b4:	4d 01 d0                                        	add    r8,r10
    54b7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    54bc:	4d 01 d0                                        	add    r8,r10
    54bf:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    54c4:	4d 01 d0                                        	add    r8,r10
    54c7:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    54cc:	4d 01 d0                                        	add    r8,r10
    54cf:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    54d4:	4d 01 d0                                        	add    r8,r10
    54d7:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    54dc:	4d 01 d0                                        	add    r8,r10
    54df:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    54e4:	4d 01 d0                                        	add    r8,r10
    54e7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    54ec:	4d 01 d0                                        	add    r8,r10
    54ef:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    54f4:	4d 01 d0                                        	add    r8,r10
    54f7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    54fc:	4d 01 d0                                        	add    r8,r10
    54ff:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5504:	4d 01 d0                                        	add    r8,r10
    5507:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    550c:	4d 01 d0                                        	add    r8,r10
    550f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5514:	4d 01 d0                                        	add    r8,r10
    5517:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    551c:	4d 01 d0                                        	add    r8,r10
    551f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5524:	4d 01 d0                                        	add    r8,r10
    5527:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    552c:	4d 01 d0                                        	add    r8,r10
    552f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5534:	4d 01 d0                                        	add    r8,r10
    5537:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    553c:	4d 01 d0                                        	add    r8,r10
    553f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5544:	4d 01 d0                                        	add    r8,r10
    5547:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    554c:	4d 01 d0                                        	add    r8,r10
    554f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5554:	4d 01 d0                                        	add    r8,r10
    5557:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    555c:	4d 01 d0                                        	add    r8,r10
    555f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5564:	4d 01 d0                                        	add    r8,r10
    5567:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    556c:	4d 01 d0                                        	add    r8,r10
    556f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5574:	4d 01 d0                                        	add    r8,r10
    5577:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    557c:	4d 01 d0                                        	add    r8,r10
    557f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5584:	4d 01 d0                                        	add    r8,r10
    5587:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    558c:	4d 01 d0                                        	add    r8,r10
    558f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5594:	4d 01 d0                                        	add    r8,r10
    5597:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    559c:	4d 01 d0                                        	add    r8,r10
    559f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    55a4:	4d 01 d0                                        	add    r8,r10
    55a7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    55ac:	4d 01 d0                                        	add    r8,r10
    55af:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    55b4:	4d 01 d0                                        	add    r8,r10
    55b7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    55bc:	4d 01 d0                                        	add    r8,r10
    55bf:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    55c4:	4d 01 d0                                        	add    r8,r10
    55c7:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    55cc:	4d 01 d0                                        	add    r8,r10
    55cf:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    55d4:	4d 01 d0                                        	add    r8,r10
    55d7:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    55dc:	4d 01 d0                                        	add    r8,r10
    55df:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    55e4:	4d 01 d0                                        	add    r8,r10
    55e7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    55ec:	4d 01 d0                                        	add    r8,r10
    55ef:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    55f4:	4d 01 d0                                        	add    r8,r10
    55f7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    55fc:	4d 01 d0                                        	add    r8,r10
    55ff:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5604:	4d 01 d0                                        	add    r8,r10
    5607:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    560c:	4d 01 d0                                        	add    r8,r10
    560f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5614:	4d 01 d0                                        	add    r8,r10
    5617:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    561c:	4d 01 d0                                        	add    r8,r10
    561f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5624:	4d 01 d0                                        	add    r8,r10
    5627:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    562c:	4d 01 d0                                        	add    r8,r10
    562f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5634:	4d 01 d0                                        	add    r8,r10
    5637:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    563c:	4d 01 d0                                        	add    r8,r10
    563f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5644:	4d 01 d0                                        	add    r8,r10
    5647:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    564c:	4d 01 d0                                        	add    r8,r10
    564f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5654:	4d 01 d0                                        	add    r8,r10
    5657:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    565c:	4d 01 d0                                        	add    r8,r10
    565f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5664:	4d 01 d0                                        	add    r8,r10
    5667:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    566c:	4d 01 d0                                        	add    r8,r10
    566f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5674:	4d 01 d0                                        	add    r8,r10
    5677:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    567c:	4d 01 d0                                        	add    r8,r10
    567f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5684:	4d 01 d0                                        	add    r8,r10
    5687:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    568c:	4d 01 d0                                        	add    r8,r10
    568f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5694:	4d 01 d0                                        	add    r8,r10
    5697:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    569c:	4d 01 d0                                        	add    r8,r10
    569f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    56a4:	4d 01 d0                                        	add    r8,r10
    56a7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    56ac:	4d 01 d0                                        	add    r8,r10
    56af:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    56b4:	4d 01 d0                                        	add    r8,r10
    56b7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    56bc:	4d 01 d0                                        	add    r8,r10
    56bf:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    56c4:	4d 01 d0                                        	add    r8,r10
    56c7:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    56cc:	4d 01 d0                                        	add    r8,r10
    56cf:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    56d4:	4d 01 d0                                        	add    r8,r10
    56d7:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    56dc:	4d 01 d0                                        	add    r8,r10
    56df:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    56e4:	4d 01 d0                                        	add    r8,r10
    56e7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    56ec:	4d 01 d0                                        	add    r8,r10
    56ef:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    56f4:	4d 01 d0                                        	add    r8,r10
    56f7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    56fc:	4d 01 d0                                        	add    r8,r10
    56ff:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5704:	4d 01 d0                                        	add    r8,r10
    5707:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    570c:	4d 01 d0                                        	add    r8,r10
    570f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5714:	4d 01 d0                                        	add    r8,r10
    5717:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    571c:	4d 01 d0                                        	add    r8,r10
    571f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5724:	4d 01 d0                                        	add    r8,r10
    5727:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    572c:	4d 01 d0                                        	add    r8,r10
    572f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5734:	4d 01 d0                                        	add    r8,r10
    5737:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    573c:	4d 01 d0                                        	add    r8,r10
    573f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5744:	4d 01 d0                                        	add    r8,r10
    5747:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    574c:	4d 01 d0                                        	add    r8,r10
    574f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5754:	4d 01 d0                                        	add    r8,r10
    5757:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    575c:	4d 01 d0                                        	add    r8,r10
    575f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5764:	4d 01 d0                                        	add    r8,r10
    5767:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    576c:	4d 01 d0                                        	add    r8,r10
    576f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5774:	4d 01 d0                                        	add    r8,r10
    5777:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    577c:	4d 01 d0                                        	add    r8,r10
    577f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5784:	4d 01 d0                                        	add    r8,r10
    5787:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    578c:	4d 01 d0                                        	add    r8,r10
    578f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5794:	4d 01 d0                                        	add    r8,r10
    5797:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    579c:	4d 01 d0                                        	add    r8,r10
    579f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    57a4:	4d 01 d0                                        	add    r8,r10
    57a7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    57ac:	4d 01 d0                                        	add    r8,r10
    57af:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    57b4:	4d 01 d0                                        	add    r8,r10
    57b7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    57bc:	4d 01 d0                                        	add    r8,r10
    57bf:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    57c4:	4d 01 d0                                        	add    r8,r10
    57c7:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    57cc:	4d 01 d0                                        	add    r8,r10
    57cf:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    57d4:	4d 01 d0                                        	add    r8,r10
    57d7:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    57dc:	4d 01 d0                                        	add    r8,r10
    57df:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    57e4:	4d 01 d0                                        	add    r8,r10
    57e7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    57ec:	4d 01 d0                                        	add    r8,r10
    57ef:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    57f4:	4d 01 d0                                        	add    r8,r10
    57f7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    57fc:	4d 01 d0                                        	add    r8,r10
    57ff:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5804:	4d 01 d0                                        	add    r8,r10
    5807:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    580c:	4d 01 d0                                        	add    r8,r10
    580f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5814:	4d 01 d0                                        	add    r8,r10
    5817:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    581c:	4d 01 d0                                        	add    r8,r10
    581f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5824:	4d 01 d0                                        	add    r8,r10
    5827:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    582c:	4d 01 d0                                        	add    r8,r10
    582f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5834:	4d 01 d0                                        	add    r8,r10
    5837:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    583c:	4d 01 d0                                        	add    r8,r10
    583f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5844:	4d 01 d0                                        	add    r8,r10
    5847:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    584c:	4d 01 d0                                        	add    r8,r10
    584f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5854:	4d 01 d0                                        	add    r8,r10
    5857:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    585c:	4d 01 d0                                        	add    r8,r10
    585f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5864:	4d 01 d0                                        	add    r8,r10
    5867:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    586c:	4d 01 d0                                        	add    r8,r10
    586f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5874:	4d 01 d0                                        	add    r8,r10
    5877:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    587c:	4d 01 d0                                        	add    r8,r10
    587f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5884:	4d 01 d0                                        	add    r8,r10
    5887:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    588c:	4d 01 d0                                        	add    r8,r10
    588f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5894:	4d 01 d0                                        	add    r8,r10
    5897:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    589c:	4d 01 d0                                        	add    r8,r10
    589f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    58a4:	4d 01 d0                                        	add    r8,r10
    58a7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    58ac:	4d 01 d0                                        	add    r8,r10
    58af:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    58b4:	4d 01 d0                                        	add    r8,r10
    58b7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    58bc:	4d 01 d0                                        	add    r8,r10
    58bf:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    58c4:	4d 01 d0                                        	add    r8,r10
    58c7:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    58cc:	4d 01 d0                                        	add    r8,r10
    58cf:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    58d4:	4d 01 d0                                        	add    r8,r10
    58d7:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    58dc:	4d 01 d0                                        	add    r8,r10
    58df:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    58e4:	4d 01 d0                                        	add    r8,r10
    58e7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    58ec:	4d 01 d0                                        	add    r8,r10
    58ef:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    58f4:	4d 01 d0                                        	add    r8,r10
    58f7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    58fc:	4d 01 d0                                        	add    r8,r10
    58ff:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5904:	4d 01 d0                                        	add    r8,r10
    5907:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    590c:	4d 01 d0                                        	add    r8,r10
    590f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5914:	4d 01 d0                                        	add    r8,r10
    5917:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    591c:	4d 01 d0                                        	add    r8,r10
    591f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5924:	4d 01 d0                                        	add    r8,r10
    5927:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    592c:	4d 01 d0                                        	add    r8,r10
    592f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5934:	4d 01 d0                                        	add    r8,r10
    5937:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    593c:	4d 01 d0                                        	add    r8,r10
    593f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5944:	4d 01 d0                                        	add    r8,r10
    5947:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    594c:	4d 01 d0                                        	add    r8,r10
    594f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5954:	4d 01 d0                                        	add    r8,r10
    5957:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    595c:	4d 01 d0                                        	add    r8,r10
    595f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5964:	4d 01 d0                                        	add    r8,r10
    5967:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    596c:	4d 01 d0                                        	add    r8,r10
    596f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5974:	4d 01 d0                                        	add    r8,r10
    5977:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    597c:	4d 01 d0                                        	add    r8,r10
    597f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5984:	4d 01 d0                                        	add    r8,r10
    5987:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    598c:	4d 01 d0                                        	add    r8,r10
    598f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5994:	4d 01 d0                                        	add    r8,r10
    5997:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    599c:	4d 01 d0                                        	add    r8,r10
    599f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    59a4:	4d 01 d0                                        	add    r8,r10
    59a7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    59ac:	4d 01 d0                                        	add    r8,r10
    59af:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    59b4:	4d 01 d0                                        	add    r8,r10
    59b7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    59bc:	4d 01 d0                                        	add    r8,r10
    59bf:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    59c4:	4d 01 d0                                        	add    r8,r10
    59c7:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    59cc:	4d 01 d0                                        	add    r8,r10
    59cf:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    59d4:	4d 01 d0                                        	add    r8,r10
    59d7:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    59dc:	4d 01 d0                                        	add    r8,r10
    59df:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    59e4:	4d 01 d0                                        	add    r8,r10
    59e7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    59ec:	4d 01 d0                                        	add    r8,r10
    59ef:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    59f4:	4d 01 d0                                        	add    r8,r10
    59f7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    59fc:	4d 01 d0                                        	add    r8,r10
    59ff:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5a04:	4d 01 d0                                        	add    r8,r10
    5a07:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5a0c:	4d 01 d0                                        	add    r8,r10
    5a0f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5a14:	4d 01 d0                                        	add    r8,r10
    5a17:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5a1c:	4d 01 d0                                        	add    r8,r10
    5a1f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5a24:	4d 01 d0                                        	add    r8,r10
    5a27:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5a2c:	4d 01 d0                                        	add    r8,r10
    5a2f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5a34:	4d 01 d0                                        	add    r8,r10
    5a37:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5a3c:	4d 01 d0                                        	add    r8,r10
    5a3f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5a44:	4d 01 d0                                        	add    r8,r10
    5a47:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5a4c:	4d 01 d0                                        	add    r8,r10
    5a4f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5a54:	4d 01 d0                                        	add    r8,r10
    5a57:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5a5c:	4d 01 d0                                        	add    r8,r10
    5a5f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5a64:	4d 01 d0                                        	add    r8,r10
    5a67:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5a6c:	4d 01 d0                                        	add    r8,r10
    5a6f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5a74:	4d 01 d0                                        	add    r8,r10
    5a77:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5a7c:	4d 01 d0                                        	add    r8,r10
    5a7f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5a84:	4d 01 d0                                        	add    r8,r10
    5a87:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5a8c:	4d 01 d0                                        	add    r8,r10
    5a8f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5a94:	4d 01 d0                                        	add    r8,r10
    5a97:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5a9c:	4d 01 d0                                        	add    r8,r10
    5a9f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5aa4:	4d 01 d0                                        	add    r8,r10
    5aa7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5aac:	4d 01 d0                                        	add    r8,r10
    5aaf:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5ab4:	4d 01 d0                                        	add    r8,r10
    5ab7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5abc:	4d 01 d0                                        	add    r8,r10
    5abf:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5ac4:	4d 01 d0                                        	add    r8,r10
    5ac7:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5acc:	4d 01 d0                                        	add    r8,r10
    5acf:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5ad4:	4d 01 d0                                        	add    r8,r10
    5ad7:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5adc:	4d 01 d0                                        	add    r8,r10
    5adf:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5ae4:	4d 01 d0                                        	add    r8,r10
    5ae7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5aec:	4d 01 d0                                        	add    r8,r10
    5aef:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5af4:	4d 01 d0                                        	add    r8,r10
    5af7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5afc:	4d 01 d0                                        	add    r8,r10
    5aff:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5b04:	4d 01 d0                                        	add    r8,r10
    5b07:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5b0c:	4d 01 d0                                        	add    r8,r10
    5b0f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5b14:	4d 01 d0                                        	add    r8,r10
    5b17:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5b1c:	4d 01 d0                                        	add    r8,r10
    5b1f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5b24:	4d 01 d0                                        	add    r8,r10
    5b27:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5b2c:	4d 01 d0                                        	add    r8,r10
    5b2f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5b34:	4d 01 d0                                        	add    r8,r10
    5b37:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5b3c:	4d 01 d0                                        	add    r8,r10
    5b3f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5b44:	4d 01 d0                                        	add    r8,r10
    5b47:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5b4c:	4d 01 d0                                        	add    r8,r10
    5b4f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5b54:	4d 01 d0                                        	add    r8,r10
    5b57:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5b5c:	4d 01 d0                                        	add    r8,r10
    5b5f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5b64:	4d 01 d0                                        	add    r8,r10
    5b67:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5b6c:	4d 01 d0                                        	add    r8,r10
    5b6f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5b74:	4d 01 d0                                        	add    r8,r10
    5b77:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5b7c:	4d 01 d0                                        	add    r8,r10
    5b7f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5b84:	4d 01 d0                                        	add    r8,r10
    5b87:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5b8c:	4d 01 d0                                        	add    r8,r10
    5b8f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5b94:	4d 01 d0                                        	add    r8,r10
    5b97:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5b9c:	4d 01 d0                                        	add    r8,r10
    5b9f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5ba4:	4d 01 d0                                        	add    r8,r10
    5ba7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5bac:	4d 01 d0                                        	add    r8,r10
    5baf:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5bb4:	4d 01 d0                                        	add    r8,r10
    5bb7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5bbc:	4d 01 d0                                        	add    r8,r10
    5bbf:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5bc4:	4d 01 d0                                        	add    r8,r10
    5bc7:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5bcc:	4d 01 d0                                        	add    r8,r10
    5bcf:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5bd4:	4d 01 d0                                        	add    r8,r10
    5bd7:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5bdc:	4d 01 d0                                        	add    r8,r10
    5bdf:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5be4:	4d 01 d0                                        	add    r8,r10
    5be7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5bec:	4d 01 d0                                        	add    r8,r10
    5bef:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5bf4:	4d 01 d0                                        	add    r8,r10
    5bf7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5bfc:	4d 01 d0                                        	add    r8,r10
    5bff:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5c04:	4d 01 d0                                        	add    r8,r10
    5c07:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5c0c:	4d 01 d0                                        	add    r8,r10
    5c0f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5c14:	4d 01 d0                                        	add    r8,r10
    5c17:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5c1c:	4d 01 d0                                        	add    r8,r10
    5c1f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5c24:	4d 01 d0                                        	add    r8,r10
    5c27:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5c2c:	4d 01 d0                                        	add    r8,r10
    5c2f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5c34:	4d 01 d0                                        	add    r8,r10
    5c37:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5c3c:	4d 01 d0                                        	add    r8,r10
    5c3f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5c44:	4d 01 d0                                        	add    r8,r10
    5c47:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5c4c:	4d 01 d0                                        	add    r8,r10
    5c4f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5c54:	4d 01 d0                                        	add    r8,r10
    5c57:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5c5c:	4d 01 d0                                        	add    r8,r10
    5c5f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5c64:	4d 01 d0                                        	add    r8,r10
    5c67:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5c6c:	4d 01 d0                                        	add    r8,r10
    5c6f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5c74:	4d 01 d0                                        	add    r8,r10
    5c77:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5c7c:	4d 01 d0                                        	add    r8,r10
    5c7f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5c84:	4d 01 d0                                        	add    r8,r10
    5c87:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5c8c:	4d 01 d0                                        	add    r8,r10
    5c8f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5c94:	4d 01 d0                                        	add    r8,r10
    5c97:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5c9c:	4d 01 d0                                        	add    r8,r10
    5c9f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5ca4:	4d 01 d0                                        	add    r8,r10
    5ca7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5cac:	4d 01 d0                                        	add    r8,r10
    5caf:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5cb4:	4d 01 d0                                        	add    r8,r10
    5cb7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5cbc:	4d 01 d0                                        	add    r8,r10
    5cbf:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5cc4:	4d 01 d0                                        	add    r8,r10
    5cc7:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5ccc:	4d 01 d0                                        	add    r8,r10
    5ccf:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5cd4:	4d 01 d0                                        	add    r8,r10
    5cd7:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5cdc:	4d 01 d0                                        	add    r8,r10
    5cdf:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5ce4:	4d 01 d0                                        	add    r8,r10
    5ce7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5cec:	4d 01 d0                                        	add    r8,r10
    5cef:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5cf4:	4d 01 d0                                        	add    r8,r10
    5cf7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5cfc:	4d 01 d0                                        	add    r8,r10
    5cff:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5d04:	4d 01 d0                                        	add    r8,r10
    5d07:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5d0c:	4d 01 d0                                        	add    r8,r10
    5d0f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5d14:	4d 01 d0                                        	add    r8,r10
    5d17:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5d1c:	4d 01 d0                                        	add    r8,r10
    5d1f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5d24:	4d 01 d0                                        	add    r8,r10
    5d27:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5d2c:	4d 01 d0                                        	add    r8,r10
    5d2f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5d34:	4d 01 d0                                        	add    r8,r10
    5d37:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5d3c:	4d 01 d0                                        	add    r8,r10
    5d3f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5d44:	4d 01 d0                                        	add    r8,r10
    5d47:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5d4c:	4d 01 d0                                        	add    r8,r10
    5d4f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5d54:	4d 01 d0                                        	add    r8,r10
    5d57:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5d5c:	4d 01 d0                                        	add    r8,r10
    5d5f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5d64:	4d 01 d0                                        	add    r8,r10
    5d67:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5d6c:	4d 01 d0                                        	add    r8,r10
    5d6f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5d74:	4d 01 d0                                        	add    r8,r10
    5d77:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5d7c:	4d 01 d0                                        	add    r8,r10
    5d7f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5d84:	4d 01 d0                                        	add    r8,r10
    5d87:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5d8c:	4d 01 d0                                        	add    r8,r10
    5d8f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5d94:	4d 01 d0                                        	add    r8,r10
    5d97:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5d9c:	4d 01 d0                                        	add    r8,r10
    5d9f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5da4:	4d 01 d0                                        	add    r8,r10
    5da7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5dac:	4d 01 d0                                        	add    r8,r10
    5daf:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5db4:	4d 01 d0                                        	add    r8,r10
    5db7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5dbc:	4d 01 d0                                        	add    r8,r10
    5dbf:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5dc4:	4d 01 d0                                        	add    r8,r10
    5dc7:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5dcc:	4d 01 d0                                        	add    r8,r10
    5dcf:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5dd4:	4d 01 d0                                        	add    r8,r10
    5dd7:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5ddc:	4d 01 d0                                        	add    r8,r10
    5ddf:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5de4:	4d 01 d0                                        	add    r8,r10
    5de7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5dec:	4d 01 d0                                        	add    r8,r10
    5def:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5df4:	4d 01 d0                                        	add    r8,r10
    5df7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5dfc:	4d 01 d0                                        	add    r8,r10
    5dff:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5e04:	4d 01 d0                                        	add    r8,r10
    5e07:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5e0c:	4d 01 d0                                        	add    r8,r10
    5e0f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5e14:	4d 01 d0                                        	add    r8,r10
    5e17:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5e1c:	4d 01 d0                                        	add    r8,r10
    5e1f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5e24:	4d 01 d0                                        	add    r8,r10
    5e27:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5e2c:	4d 01 d0                                        	add    r8,r10
    5e2f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5e34:	4d 01 d0                                        	add    r8,r10
    5e37:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5e3c:	4d 01 d0                                        	add    r8,r10
    5e3f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5e44:	4d 01 d0                                        	add    r8,r10
    5e47:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5e4c:	4d 01 d0                                        	add    r8,r10
    5e4f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5e54:	4d 01 d0                                        	add    r8,r10
    5e57:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5e5c:	4d 01 d0                                        	add    r8,r10
    5e5f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5e64:	4d 01 d0                                        	add    r8,r10
    5e67:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5e6c:	4d 01 d0                                        	add    r8,r10
    5e6f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5e74:	4d 01 d0                                        	add    r8,r10
    5e77:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5e7c:	4d 01 d0                                        	add    r8,r10
    5e7f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5e84:	4d 01 d0                                        	add    r8,r10
    5e87:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5e8c:	4d 01 d0                                        	add    r8,r10
    5e8f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5e94:	4d 01 d0                                        	add    r8,r10
    5e97:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5e9c:	4d 01 d0                                        	add    r8,r10
    5e9f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5ea4:	4d 01 d0                                        	add    r8,r10
    5ea7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5eac:	4d 01 d0                                        	add    r8,r10
    5eaf:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5eb4:	4d 01 d0                                        	add    r8,r10
    5eb7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5ebc:	4d 01 d0                                        	add    r8,r10
    5ebf:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5ec4:	4d 01 d0                                        	add    r8,r10
    5ec7:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5ecc:	4d 01 d0                                        	add    r8,r10
    5ecf:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5ed4:	4d 01 d0                                        	add    r8,r10
    5ed7:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5edc:	4d 01 d0                                        	add    r8,r10
    5edf:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5ee4:	4d 01 d0                                        	add    r8,r10
    5ee7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5eec:	4d 01 d0                                        	add    r8,r10
    5eef:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5ef4:	4d 01 d0                                        	add    r8,r10
    5ef7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5efc:	4d 01 d0                                        	add    r8,r10
    5eff:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5f04:	4d 01 d0                                        	add    r8,r10
    5f07:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5f0c:	4d 01 d0                                        	add    r8,r10
    5f0f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5f14:	4d 01 d0                                        	add    r8,r10
    5f17:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5f1c:	4d 01 d0                                        	add    r8,r10
    5f1f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5f24:	4d 01 d0                                        	add    r8,r10
    5f27:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5f2c:	4d 01 d0                                        	add    r8,r10
    5f2f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5f34:	4d 01 d0                                        	add    r8,r10
    5f37:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5f3c:	4d 01 d0                                        	add    r8,r10
    5f3f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5f44:	4d 01 d0                                        	add    r8,r10
    5f47:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5f4c:	4d 01 d0                                        	add    r8,r10
    5f4f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5f54:	4d 01 d0                                        	add    r8,r10
    5f57:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5f5c:	4d 01 d0                                        	add    r8,r10
    5f5f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5f64:	4d 01 d0                                        	add    r8,r10
    5f67:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5f6c:	4d 01 d0                                        	add    r8,r10
    5f6f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5f74:	4d 01 d0                                        	add    r8,r10
    5f77:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5f7c:	4d 01 d0                                        	add    r8,r10
    5f7f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5f84:	4d 01 d0                                        	add    r8,r10
    5f87:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5f8c:	4d 01 d0                                        	add    r8,r10
    5f8f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5f94:	4d 01 d0                                        	add    r8,r10
    5f97:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5f9c:	4d 01 d0                                        	add    r8,r10
    5f9f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5fa4:	4d 01 d0                                        	add    r8,r10
    5fa7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5fac:	4d 01 d0                                        	add    r8,r10
    5faf:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5fb4:	4d 01 d0                                        	add    r8,r10
    5fb7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5fbc:	4d 01 d0                                        	add    r8,r10
    5fbf:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5fc4:	4d 01 d0                                        	add    r8,r10
    5fc7:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5fcc:	4d 01 d0                                        	add    r8,r10
    5fcf:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5fd4:	4d 01 d0                                        	add    r8,r10
    5fd7:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5fdc:	4d 01 d0                                        	add    r8,r10
    5fdf:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5fe4:	4d 01 d0                                        	add    r8,r10
    5fe7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5fec:	4d 01 d0                                        	add    r8,r10
    5fef:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5ff4:	4d 01 d0                                        	add    r8,r10
    5ff7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5ffc:	4d 01 d0                                        	add    r8,r10
    5fff:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6004:	4d 01 d0                                        	add    r8,r10
    6007:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    600c:	4d 01 d0                                        	add    r8,r10
    600f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6014:	4d 01 d0                                        	add    r8,r10
    6017:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    601c:	4d 01 d0                                        	add    r8,r10
    601f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6024:	4d 01 d0                                        	add    r8,r10
    6027:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    602c:	4d 01 d0                                        	add    r8,r10
    602f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6034:	4d 01 d0                                        	add    r8,r10
    6037:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    603c:	4d 01 d0                                        	add    r8,r10
    603f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6044:	4d 01 d0                                        	add    r8,r10
    6047:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    604c:	4d 01 d0                                        	add    r8,r10
    604f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6054:	4d 01 d0                                        	add    r8,r10
    6057:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    605c:	4d 01 d0                                        	add    r8,r10
    605f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6064:	4d 01 d0                                        	add    r8,r10
    6067:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    606c:	4d 01 d0                                        	add    r8,r10
    606f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6074:	4d 01 d0                                        	add    r8,r10
    6077:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    607c:	4d 01 d0                                        	add    r8,r10
    607f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6084:	4d 01 d0                                        	add    r8,r10
    6087:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    608c:	4d 01 d0                                        	add    r8,r10
    608f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6094:	4d 01 d0                                        	add    r8,r10
    6097:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    609c:	4d 01 d0                                        	add    r8,r10
    609f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    60a4:	4d 01 d0                                        	add    r8,r10
    60a7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    60ac:	4d 01 d0                                        	add    r8,r10
    60af:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    60b4:	4d 01 d0                                        	add    r8,r10
    60b7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    60bc:	4d 01 d0                                        	add    r8,r10
    60bf:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    60c4:	4d 01 d0                                        	add    r8,r10
    60c7:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    60cc:	4d 01 d0                                        	add    r8,r10
    60cf:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    60d4:	4d 01 d0                                        	add    r8,r10
    60d7:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    60dc:	4d 01 d0                                        	add    r8,r10
    60df:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    60e4:	4d 01 d0                                        	add    r8,r10
    60e7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    60ec:	4d 01 d0                                        	add    r8,r10
    60ef:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    60f4:	4d 01 d0                                        	add    r8,r10
    60f7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    60fc:	4d 01 d0                                        	add    r8,r10
    60ff:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6104:	4d 01 d0                                        	add    r8,r10
    6107:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    610c:	4d 01 d0                                        	add    r8,r10
    610f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6114:	4d 01 d0                                        	add    r8,r10
    6117:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    611c:	4d 01 d0                                        	add    r8,r10
    611f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6124:	4d 01 d0                                        	add    r8,r10
    6127:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    612c:	4d 01 d0                                        	add    r8,r10
    612f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6134:	4d 01 d0                                        	add    r8,r10
    6137:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    613c:	4d 01 d0                                        	add    r8,r10
    613f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6144:	4d 01 d0                                        	add    r8,r10
    6147:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    614c:	4d 01 d0                                        	add    r8,r10
    614f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6154:	4d 01 d0                                        	add    r8,r10
    6157:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    615c:	4d 01 d0                                        	add    r8,r10
    615f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6164:	4d 01 d0                                        	add    r8,r10
    6167:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    616c:	4d 01 d0                                        	add    r8,r10
    616f:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6174:	4d 01 d0                                        	add    r8,r10
    6177:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    617c:	4d 01 d0                                        	add    r8,r10
    617f:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6184:	4d 01 d0                                        	add    r8,r10
    6187:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    618c:	4d 01 d0                                        	add    r8,r10
    618f:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6194:	4d 01 d0                                        	add    r8,r10
    6197:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    619c:	4d 01 d0                                        	add    r8,r10
    619f:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    61a4:	4d 01 d0                                        	add    r8,r10
    61a7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    61ac:	4d 01 d0                                        	add    r8,r10
    61af:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    61b4:	4d 01 d0                                        	add    r8,r10
    61b7:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    61bc:	4d 01 d0                                        	add    r8,r10
    61bf:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    61c4:	4d 01 d0                                        	add    r8,r10
    61c7:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    61cc:	4d 01 d0                                        	add    r8,r10
    61cf:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    61d4:	4d 01 d0                                        	add    r8,r10
    61d7:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    61dc:	4d 01 d0                                        	add    r8,r10
    61df:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    61e4:	4d 01 d0                                        	add    r8,r10
    61e7:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    61ec:	4d 01 d0                                        	add    r8,r10
    61ef:	41 f6 c1 01                                     	test   r9b,0x1
    61f3:	74 04                                           	je     61f9 <join_4>
    61f5:	49 83 f0 01                                     	xor    r8,0x1

00000000000061f9 <join_4>:
    61f9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    61fe:	4d 01 d0                                        	add    r8,r10
    6201:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6206:	4d 01 d0                                        	add    r8,r10
    6209:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    620e:	4d 01 d0                                        	add    r8,r10
    6211:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6216:	4d 01 d0                                        	add    r8,r10
    6219:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    621e:	4d 01 d0                                        	add    r8,r10
    6221:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6226:	4d 01 d0                                        	add    r8,r10
    6229:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    622e:	4d 01 d0                                        	add    r8,r10
    6231:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6236:	4d 01 d0                                        	add    r8,r10
    6239:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    623e:	4d 01 d0                                        	add    r8,r10
    6241:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6246:	4d 01 d0                                        	add    r8,r10
    6249:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    624e:	4d 01 d0                                        	add    r8,r10
    6251:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6256:	4d 01 d0                                        	add    r8,r10
    6259:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    625e:	4d 01 d0                                        	add    r8,r10
    6261:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6266:	4d 01 d0                                        	add    r8,r10
    6269:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    626e:	4d 01 d0                                        	add    r8,r10
    6271:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6276:	4d 01 d0                                        	add    r8,r10
    6279:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    627e:	4d 01 d0                                        	add    r8,r10
    6281:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6286:	4d 01 d0                                        	add    r8,r10
    6289:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    628e:	4d 01 d0                                        	add    r8,r10
    6291:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6296:	4d 01 d0                                        	add    r8,r10
    6299:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    629e:	4d 01 d0                                        	add    r8,r10
    62a1:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    62a6:	4d 01 d0                                        	add    r8,r10
    62a9:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    62ae:	4d 01 d0                                        	add    r8,r10
    62b1:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    62b6:	4d 01 d0                                        	add    r8,r10
    62b9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    62be:	4d 01 d0                                        	add    r8,r10
    62c1:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    62c6:	4d 01 d0                                        	add    r8,r10
    62c9:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    62ce:	4d 01 d0                                        	add    r8,r10
    62d1:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    62d6:	4d 01 d0                                        	add    r8,r10
    62d9:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    62de:	4d 01 d0                                        	add    r8,r10
    62e1:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    62e6:	4d 01 d0                                        	add    r8,r10
    62e9:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    62ee:	4d 01 d0                                        	add    r8,r10
    62f1:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    62f6:	4d 01 d0                                        	add    r8,r10
    62f9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    62fe:	4d 01 d0                                        	add    r8,r10
    6301:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6306:	4d 01 d0                                        	add    r8,r10
    6309:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    630e:	4d 01 d0                                        	add    r8,r10
    6311:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6316:	4d 01 d0                                        	add    r8,r10
    6319:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    631e:	4d 01 d0                                        	add    r8,r10
    6321:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6326:	4d 01 d0                                        	add    r8,r10
    6329:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    632e:	4d 01 d0                                        	add    r8,r10
    6331:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6336:	4d 01 d0                                        	add    r8,r10
    6339:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    633e:	4d 01 d0                                        	add    r8,r10
    6341:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6346:	4d 01 d0                                        	add    r8,r10
    6349:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    634e:	4d 01 d0                                        	add    r8,r10
    6351:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6356:	4d 01 d0                                        	add    r8,r10
    6359:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    635e:	4d 01 d0                                        	add    r8,r10
    6361:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6366:	4d 01 d0                                        	add    r8,r10
    6369:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    636e:	4d 01 d0                                        	add    r8,r10
    6371:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6376:	4d 01 d0                                        	add    r8,r10
    6379:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    637e:	4d 01 d0                                        	add    r8,r10
    6381:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6386:	4d 01 d0                                        	add    r8,r10
    6389:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    638e:	4d 01 d0                                        	add    r8,r10
    6391:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6396:	4d 01 d0                                        	add    r8,r10
    6399:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    639e:	4d 01 d0                                        	add    r8,r10
    63a1:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    63a6:	4d 01 d0                                        	add    r8,r10
    63a9:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    63ae:	4d 01 d0                                        	add    r8,r10
    63b1:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    63b6:	4d 01 d0                                        	add    r8,r10
    63b9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    63be:	4d 01 d0                                        	add    r8,r10
    63c1:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    63c6:	4d 01 d0                                        	add    r8,r10
    63c9:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    63ce:	4d 01 d0                                        	add    r8,r10
    63d1:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    63d6:	4d 01 d0                                        	add    r8,r10
    63d9:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    63de:	4d 01 d0                                        	add    r8,r10
    63e1:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    63e6:	4d 01 d0                                        	add    r8,r10
    63e9:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    63ee:	4d 01 d0                                        	add    r8,r10
    63f1:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    63f6:	4d 01 d0                                        	add    r8,r10
    63f9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    63fe:	4d 01 d0                                        	add    r8,r10
    6401:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6406:	4d 01 d0                                        	add    r8,r10
    6409:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    640e:	4d 01 d0                                        	add    r8,r10
    6411:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6416:	4d 01 d0                                        	add    r8,r10
    6419:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    641e:	4d 01 d0                                        	add    r8,r10
    6421:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6426:	4d 01 d0                                        	add    r8,r10
    6429:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    642e:	4d 01 d0                                        	add    r8,r10
    6431:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6436:	4d 01 d0                                        	add    r8,r10
    6439:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    643e:	4d 01 d0                                        	add    r8,r10
    6441:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6446:	4d 01 d0                                        	add    r8,r10
    6449:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    644e:	4d 01 d0                                        	add    r8,r10
    6451:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6456:	4d 01 d0                                        	add    r8,r10
    6459:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    645e:	4d 01 d0                                        	add    r8,r10
    6461:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6466:	4d 01 d0                                        	add    r8,r10
    6469:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    646e:	4d 01 d0                                        	add    r8,r10
    6471:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6476:	4d 01 d0                                        	add    r8,r10
    6479:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    647e:	4d 01 d0                                        	add    r8,r10
    6481:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6486:	4d 01 d0                                        	add    r8,r10
    6489:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    648e:	4d 01 d0                                        	add    r8,r10
    6491:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6496:	4d 01 d0                                        	add    r8,r10
    6499:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    649e:	4d 01 d0                                        	add    r8,r10
    64a1:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    64a6:	4d 01 d0                                        	add    r8,r10
    64a9:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    64ae:	4d 01 d0                                        	add    r8,r10
    64b1:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    64b6:	4d 01 d0                                        	add    r8,r10
    64b9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    64be:	4d 01 d0                                        	add    r8,r10
    64c1:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    64c6:	4d 01 d0                                        	add    r8,r10
    64c9:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    64ce:	4d 01 d0                                        	add    r8,r10
    64d1:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    64d6:	4d 01 d0                                        	add    r8,r10
    64d9:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    64de:	4d 01 d0                                        	add    r8,r10
    64e1:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    64e6:	4d 01 d0                                        	add    r8,r10
    64e9:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    64ee:	4d 01 d0                                        	add    r8,r10
    64f1:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    64f6:	4d 01 d0                                        	add    r8,r10
    64f9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    64fe:	4d 01 d0                                        	add    r8,r10
    6501:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6506:	4d 01 d0                                        	add    r8,r10
    6509:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    650e:	4d 01 d0                                        	add    r8,r10
    6511:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6516:	4d 01 d0                                        	add    r8,r10
    6519:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    651e:	4d 01 d0                                        	add    r8,r10
    6521:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6526:	4d 01 d0                                        	add    r8,r10
    6529:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    652e:	4d 01 d0                                        	add    r8,r10
    6531:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6536:	4d 01 d0                                        	add    r8,r10
    6539:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    653e:	4d 01 d0                                        	add    r8,r10
    6541:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6546:	4d 01 d0                                        	add    r8,r10
    6549:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    654e:	4d 01 d0                                        	add    r8,r10
    6551:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6556:	4d 01 d0                                        	add    r8,r10
    6559:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    655e:	4d 01 d0                                        	add    r8,r10
    6561:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6566:	4d 01 d0                                        	add    r8,r10
    6569:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    656e:	4d 01 d0                                        	add    r8,r10
    6571:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6576:	4d 01 d0                                        	add    r8,r10
    6579:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    657e:	4d 01 d0                                        	add    r8,r10
    6581:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6586:	4d 01 d0                                        	add    r8,r10
    6589:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    658e:	4d 01 d0                                        	add    r8,r10
    6591:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6596:	4d 01 d0                                        	add    r8,r10
    6599:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    659e:	4d 01 d0                                        	add    r8,r10
    65a1:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    65a6:	4d 01 d0                                        	add    r8,r10
    65a9:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    65ae:	4d 01 d0                                        	add    r8,r10
    65b1:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    65b6:	4d 01 d0                                        	add    r8,r10
    65b9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    65be:	4d 01 d0                                        	add    r8,r10
    65c1:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    65c6:	4d 01 d0                                        	add    r8,r10
    65c9:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    65ce:	4d 01 d0                                        	add    r8,r10
    65d1:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    65d6:	4d 01 d0                                        	add    r8,r10
    65d9:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    65de:	4d 01 d0                                        	add    r8,r10
    65e1:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    65e6:	4d 01 d0                                        	add    r8,r10
    65e9:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    65ee:	4d 01 d0                                        	add    r8,r10
    65f1:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    65f6:	4d 01 d0                                        	add    r8,r10
    65f9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    65fe:	4d 01 d0                                        	add    r8,r10
    6601:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6606:	4d 01 d0                                        	add    r8,r10
    6609:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    660e:	4d 01 d0                                        	add    r8,r10
    6611:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6616:	4d 01 d0                                        	add    r8,r10
    6619:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    661e:	4d 01 d0                                        	add    r8,r10
    6621:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6626:	4d 01 d0                                        	add    r8,r10
    6629:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    662e:	4d 01 d0                                        	add    r8,r10
    6631:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6636:	4d 01 d0                                        	add    r8,r10
    6639:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    663e:	4d 01 d0                                        	add    r8,r10
    6641:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6646:	4d 01 d0                                        	add    r8,r10
    6649:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    664e:	4d 01 d0                                        	add    r8,r10
    6651:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6656:	4d 01 d0                                        	add    r8,r10
    6659:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    665e:	4d 01 d0                                        	add    r8,r10
    6661:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6666:	4d 01 d0                                        	add    r8,r10
    6669:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    666e:	4d 01 d0                                        	add    r8,r10
    6671:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6676:	4d 01 d0                                        	add    r8,r10
    6679:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    667e:	4d 01 d0                                        	add    r8,r10
    6681:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6686:	4d 01 d0                                        	add    r8,r10
    6689:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    668e:	4d 01 d0                                        	add    r8,r10
    6691:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6696:	4d 01 d0                                        	add    r8,r10
    6699:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    669e:	4d 01 d0                                        	add    r8,r10
    66a1:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    66a6:	4d 01 d0                                        	add    r8,r10
    66a9:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    66ae:	4d 01 d0                                        	add    r8,r10
    66b1:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    66b6:	4d 01 d0                                        	add    r8,r10
    66b9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    66be:	4d 01 d0                                        	add    r8,r10
    66c1:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    66c6:	4d 01 d0                                        	add    r8,r10
    66c9:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    66ce:	4d 01 d0                                        	add    r8,r10
    66d1:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    66d6:	4d 01 d0                                        	add    r8,r10
    66d9:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    66de:	4d 01 d0                                        	add    r8,r10
    66e1:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    66e6:	4d 01 d0                                        	add    r8,r10
    66e9:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    66ee:	4d 01 d0                                        	add    r8,r10
    66f1:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    66f6:	4d 01 d0                                        	add    r8,r10
    66f9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    66fe:	4d 01 d0                                        	add    r8,r10
    6701:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6706:	4d 01 d0                                        	add    r8,r10
    6709:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    670e:	4d 01 d0                                        	add    r8,r10
    6711:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6716:	4d 01 d0                                        	add    r8,r10
    6719:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    671e:	4d 01 d0                                        	add    r8,r10
    6721:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6726:	4d 01 d0                                        	add    r8,r10
    6729:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    672e:	4d 01 d0                                        	add    r8,r10
    6731:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6736:	4d 01 d0                                        	add    r8,r10
    6739:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    673e:	4d 01 d0                                        	add    r8,r10
    6741:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6746:	4d 01 d0                                        	add    r8,r10
    6749:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    674e:	4d 01 d0                                        	add    r8,r10
    6751:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6756:	4d 01 d0                                        	add    r8,r10
    6759:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    675e:	4d 01 d0                                        	add    r8,r10
    6761:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6766:	4d 01 d0                                        	add    r8,r10
    6769:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    676e:	4d 01 d0                                        	add    r8,r10
    6771:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6776:	4d 01 d0                                        	add    r8,r10
    6779:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    677e:	4d 01 d0                                        	add    r8,r10
    6781:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6786:	4d 01 d0                                        	add    r8,r10
    6789:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    678e:	4d 01 d0                                        	add    r8,r10
    6791:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6796:	4d 01 d0                                        	add    r8,r10
    6799:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    679e:	4d 01 d0                                        	add    r8,r10
    67a1:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    67a6:	4d 01 d0                                        	add    r8,r10
    67a9:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    67ae:	4d 01 d0                                        	add    r8,r10
    67b1:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    67b6:	4d 01 d0                                        	add    r8,r10
    67b9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    67be:	4d 01 d0                                        	add    r8,r10
    67c1:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    67c6:	4d 01 d0                                        	add    r8,r10
    67c9:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    67ce:	4d 01 d0                                        	add    r8,r10
    67d1:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    67d6:	4d 01 d0                                        	add    r8,r10
    67d9:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    67de:	4d 01 d0                                        	add    r8,r10
    67e1:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    67e6:	4d 01 d0                                        	add    r8,r10
    67e9:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    67ee:	4d 01 d0                                        	add    r8,r10
    67f1:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    67f6:	4d 01 d0                                        	add    r8,r10
    67f9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    67fe:	4d 01 d0                                        	add    r8,r10
    6801:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6806:	4d 01 d0                                        	add    r8,r10
    6809:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    680e:	4d 01 d0                                        	add    r8,r10
    6811:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6816:	4d 01 d0                                        	add    r8,r10
    6819:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    681e:	4d 01 d0                                        	add    r8,r10
    6821:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6826:	4d 01 d0                                        	add    r8,r10
    6829:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    682e:	4d 01 d0                                        	add    r8,r10
    6831:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6836:	4d 01 d0                                        	add    r8,r10
    6839:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    683e:	4d 01 d0                                        	add    r8,r10
    6841:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6846:	4d 01 d0                                        	add    r8,r10
    6849:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    684e:	4d 01 d0                                        	add    r8,r10
    6851:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6856:	4d 01 d0                                        	add    r8,r10
    6859:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    685e:	4d 01 d0                                        	add    r8,r10
    6861:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6866:	4d 01 d0                                        	add    r8,r10
    6869:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    686e:	4d 01 d0                                        	add    r8,r10
    6871:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6876:	4d 01 d0                                        	add    r8,r10
    6879:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    687e:	4d 01 d0                                        	add    r8,r10
    6881:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6886:	4d 01 d0                                        	add    r8,r10
    6889:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    688e:	4d 01 d0                                        	add    r8,r10
    6891:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6896:	4d 01 d0                                        	add    r8,r10
    6899:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    689e:	4d 01 d0                                        	add    r8,r10
    68a1:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    68a6:	4d 01 d0                                        	add    r8,r10
    68a9:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    68ae:	4d 01 d0                                        	add    r8,r10
    68b1:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    68b6:	4d 01 d0                                        	add    r8,r10
    68b9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    68be:	4d 01 d0                                        	add    r8,r10
    68c1:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    68c6:	4d 01 d0                                        	add    r8,r10
    68c9:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    68ce:	4d 01 d0                                        	add    r8,r10
    68d1:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    68d6:	4d 01 d0                                        	add    r8,r10
    68d9:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    68de:	4d 01 d0                                        	add    r8,r10
    68e1:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    68e6:	4d 01 d0                                        	add    r8,r10
    68e9:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    68ee:	4d 01 d0                                        	add    r8,r10
    68f1:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    68f6:	4d 01 d0                                        	add    r8,r10
    68f9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    68fe:	4d 01 d0                                        	add    r8,r10
    6901:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6906:	4d 01 d0                                        	add    r8,r10
    6909:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    690e:	4d 01 d0                                        	add    r8,r10
    6911:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6916:	4d 01 d0                                        	add    r8,r10
    6919:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    691e:	4d 01 d0                                        	add    r8,r10
    6921:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6926:	4d 01 d0                                        	add    r8,r10
    6929:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    692e:	4d 01 d0                                        	add    r8,r10
    6931:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6936:	4d 01 d0                                        	add    r8,r10
    6939:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    693e:	4d 01 d0                                        	add    r8,r10
    6941:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6946:	4d 01 d0                                        	add    r8,r10
    6949:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    694e:	4d 01 d0                                        	add    r8,r10
    6951:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6956:	4d 01 d0                                        	add    r8,r10
    6959:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    695e:	4d 01 d0                                        	add    r8,r10
    6961:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6966:	4d 01 d0                                        	add    r8,r10
    6969:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    696e:	4d 01 d0                                        	add    r8,r10
    6971:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6976:	4d 01 d0                                        	add    r8,r10
    6979:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    697e:	4d 01 d0                                        	add    r8,r10
    6981:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6986:	4d 01 d0                                        	add    r8,r10
    6989:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    698e:	4d 01 d0                                        	add    r8,r10
    6991:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6996:	4d 01 d0                                        	add    r8,r10
    6999:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    699e:	4d 01 d0                                        	add    r8,r10
    69a1:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    69a6:	4d 01 d0                                        	add    r8,r10
    69a9:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    69ae:	4d 01 d0                                        	add    r8,r10
    69b1:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    69b6:	4d 01 d0                                        	add    r8,r10
    69b9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    69be:	4d 01 d0                                        	add    r8,r10
    69c1:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    69c6:	4d 01 d0                                        	add    r8,r10
    69c9:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    69ce:	4d 01 d0                                        	add    r8,r10
    69d1:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    69d6:	4d 01 d0                                        	add    r8,r10
    69d9:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    69de:	4d 01 d0                                        	add    r8,r10
    69e1:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    69e6:	4d 01 d0                                        	add    r8,r10
    69e9:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    69ee:	4d 01 d0                                        	add    r8,r10
    69f1:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    69f6:	4d 01 d0                                        	add    r8,r10
    69f9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    69fe:	4d 01 d0                                        	add    r8,r10
    6a01:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6a06:	4d 01 d0                                        	add    r8,r10
    6a09:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6a0e:	4d 01 d0                                        	add    r8,r10
    6a11:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6a16:	4d 01 d0                                        	add    r8,r10
    6a19:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6a1e:	4d 01 d0                                        	add    r8,r10
    6a21:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6a26:	4d 01 d0                                        	add    r8,r10
    6a29:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6a2e:	4d 01 d0                                        	add    r8,r10
    6a31:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6a36:	4d 01 d0                                        	add    r8,r10
    6a39:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6a3e:	4d 01 d0                                        	add    r8,r10
    6a41:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6a46:	4d 01 d0                                        	add    r8,r10
    6a49:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6a4e:	4d 01 d0                                        	add    r8,r10
    6a51:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6a56:	4d 01 d0                                        	add    r8,r10
    6a59:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6a5e:	4d 01 d0                                        	add    r8,r10
    6a61:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6a66:	4d 01 d0                                        	add    r8,r10
    6a69:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6a6e:	4d 01 d0                                        	add    r8,r10
    6a71:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6a76:	4d 01 d0                                        	add    r8,r10
    6a79:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6a7e:	4d 01 d0                                        	add    r8,r10
    6a81:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6a86:	4d 01 d0                                        	add    r8,r10
    6a89:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6a8e:	4d 01 d0                                        	add    r8,r10
    6a91:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6a96:	4d 01 d0                                        	add    r8,r10
    6a99:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6a9e:	4d 01 d0                                        	add    r8,r10
    6aa1:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6aa6:	4d 01 d0                                        	add    r8,r10
    6aa9:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6aae:	4d 01 d0                                        	add    r8,r10
    6ab1:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6ab6:	4d 01 d0                                        	add    r8,r10
    6ab9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6abe:	4d 01 d0                                        	add    r8,r10
    6ac1:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6ac6:	4d 01 d0                                        	add    r8,r10
    6ac9:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6ace:	4d 01 d0                                        	add    r8,r10
    6ad1:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6ad6:	4d 01 d0                                        	add    r8,r10
    6ad9:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6ade:	4d 01 d0                                        	add    r8,r10
    6ae1:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6ae6:	4d 01 d0                                        	add    r8,r10
    6ae9:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6aee:	4d 01 d0                                        	add    r8,r10
    6af1:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6af6:	4d 01 d0                                        	add    r8,r10
    6af9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6afe:	4d 01 d0                                        	add    r8,r10
    6b01:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6b06:	4d 01 d0                                        	add    r8,r10
    6b09:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6b0e:	4d 01 d0                                        	add    r8,r10
    6b11:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6b16:	4d 01 d0                                        	add    r8,r10
    6b19:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6b1e:	4d 01 d0                                        	add    r8,r10
    6b21:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6b26:	4d 01 d0                                        	add    r8,r10
    6b29:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6b2e:	4d 01 d0                                        	add    r8,r10
    6b31:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6b36:	4d 01 d0                                        	add    r8,r10
    6b39:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6b3e:	4d 01 d0                                        	add    r8,r10
    6b41:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6b46:	4d 01 d0                                        	add    r8,r10
    6b49:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6b4e:	4d 01 d0                                        	add    r8,r10
    6b51:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6b56:	4d 01 d0                                        	add    r8,r10
    6b59:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6b5e:	4d 01 d0                                        	add    r8,r10
    6b61:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6b66:	4d 01 d0                                        	add    r8,r10
    6b69:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6b6e:	4d 01 d0                                        	add    r8,r10
    6b71:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6b76:	4d 01 d0                                        	add    r8,r10
    6b79:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6b7e:	4d 01 d0                                        	add    r8,r10
    6b81:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6b86:	4d 01 d0                                        	add    r8,r10
    6b89:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6b8e:	4d 01 d0                                        	add    r8,r10
    6b91:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6b96:	4d 01 d0                                        	add    r8,r10
    6b99:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6b9e:	4d 01 d0                                        	add    r8,r10
    6ba1:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6ba6:	4d 01 d0                                        	add    r8,r10
    6ba9:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6bae:	4d 01 d0                                        	add    r8,r10
    6bb1:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6bb6:	4d 01 d0                                        	add    r8,r10
    6bb9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6bbe:	4d 01 d0                                        	add    r8,r10
    6bc1:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6bc6:	4d 01 d0                                        	add    r8,r10
    6bc9:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6bce:	4d 01 d0                                        	add    r8,r10
    6bd1:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6bd6:	4d 01 d0                                        	add    r8,r10
    6bd9:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6bde:	4d 01 d0                                        	add    r8,r10
    6be1:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6be6:	4d 01 d0                                        	add    r8,r10
    6be9:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6bee:	4d 01 d0                                        	add    r8,r10
    6bf1:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6bf6:	4d 01 d0                                        	add    r8,r10
    6bf9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6bfe:	4d 01 d0                                        	add    r8,r10
    6c01:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6c06:	4d 01 d0                                        	add    r8,r10
    6c09:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6c0e:	4d 01 d0                                        	add    r8,r10
    6c11:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6c16:	4d 01 d0                                        	add    r8,r10
    6c19:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6c1e:	4d 01 d0                                        	add    r8,r10
    6c21:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6c26:	4d 01 d0                                        	add    r8,r10
    6c29:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6c2e:	4d 01 d0                                        	add    r8,r10
    6c31:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6c36:	4d 01 d0                                        	add    r8,r10
    6c39:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6c3e:	4d 01 d0                                        	add    r8,r10
    6c41:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6c46:	4d 01 d0                                        	add    r8,r10
    6c49:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6c4e:	4d 01 d0                                        	add    r8,r10
    6c51:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6c56:	4d 01 d0                                        	add    r8,r10
    6c59:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6c5e:	4d 01 d0                                        	add    r8,r10
    6c61:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6c66:	4d 01 d0                                        	add    r8,r10
    6c69:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6c6e:	4d 01 d0                                        	add    r8,r10
    6c71:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6c76:	4d 01 d0                                        	add    r8,r10
    6c79:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6c7e:	4d 01 d0                                        	add    r8,r10
    6c81:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6c86:	4d 01 d0                                        	add    r8,r10
    6c89:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6c8e:	4d 01 d0                                        	add    r8,r10
    6c91:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6c96:	4d 01 d0                                        	add    r8,r10
    6c99:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6c9e:	4d 01 d0                                        	add    r8,r10
    6ca1:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6ca6:	4d 01 d0                                        	add    r8,r10
    6ca9:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6cae:	4d 01 d0                                        	add    r8,r10
    6cb1:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6cb6:	4d 01 d0                                        	add    r8,r10
    6cb9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6cbe:	4d 01 d0                                        	add    r8,r10
    6cc1:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6cc6:	4d 01 d0                                        	add    r8,r10
    6cc9:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6cce:	4d 01 d0                                        	add    r8,r10
    6cd1:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6cd6:	4d 01 d0                                        	add    r8,r10
    6cd9:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6cde:	4d 01 d0                                        	add    r8,r10
    6ce1:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6ce6:	4d 01 d0                                        	add    r8,r10
    6ce9:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6cee:	4d 01 d0                                        	add    r8,r10
    6cf1:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6cf6:	4d 01 d0                                        	add    r8,r10
    6cf9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6cfe:	4d 01 d0                                        	add    r8,r10
    6d01:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6d06:	4d 01 d0                                        	add    r8,r10
    6d09:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6d0e:	4d 01 d0                                        	add    r8,r10
    6d11:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6d16:	4d 01 d0                                        	add    r8,r10
    6d19:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6d1e:	4d 01 d0                                        	add    r8,r10
    6d21:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6d26:	4d 01 d0                                        	add    r8,r10
    6d29:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6d2e:	4d 01 d0                                        	add    r8,r10
    6d31:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6d36:	4d 01 d0                                        	add    r8,r10
    6d39:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6d3e:	4d 01 d0                                        	add    r8,r10
    6d41:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6d46:	4d 01 d0                                        	add    r8,r10
    6d49:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6d4e:	4d 01 d0                                        	add    r8,r10
    6d51:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6d56:	4d 01 d0                                        	add    r8,r10
    6d59:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6d5e:	4d 01 d0                                        	add    r8,r10
    6d61:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6d66:	4d 01 d0                                        	add    r8,r10
    6d69:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6d6e:	4d 01 d0                                        	add    r8,r10
    6d71:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6d76:	4d 01 d0                                        	add    r8,r10
    6d79:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6d7e:	4d 01 d0                                        	add    r8,r10
    6d81:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6d86:	4d 01 d0                                        	add    r8,r10
    6d89:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6d8e:	4d 01 d0                                        	add    r8,r10
    6d91:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6d96:	4d 01 d0                                        	add    r8,r10
    6d99:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6d9e:	4d 01 d0                                        	add    r8,r10
    6da1:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6da6:	4d 01 d0                                        	add    r8,r10
    6da9:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6dae:	4d 01 d0                                        	add    r8,r10
    6db1:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6db6:	4d 01 d0                                        	add    r8,r10
    6db9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6dbe:	4d 01 d0                                        	add    r8,r10
    6dc1:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6dc6:	4d 01 d0                                        	add    r8,r10
    6dc9:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6dce:	4d 01 d0                                        	add    r8,r10
    6dd1:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6dd6:	4d 01 d0                                        	add    r8,r10
    6dd9:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6dde:	4d 01 d0                                        	add    r8,r10
    6de1:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6de6:	4d 01 d0                                        	add    r8,r10
    6de9:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6dee:	4d 01 d0                                        	add    r8,r10
    6df1:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6df6:	4d 01 d0                                        	add    r8,r10
    6df9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6dfe:	4d 01 d0                                        	add    r8,r10
    6e01:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6e06:	4d 01 d0                                        	add    r8,r10
    6e09:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6e0e:	4d 01 d0                                        	add    r8,r10
    6e11:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6e16:	4d 01 d0                                        	add    r8,r10
    6e19:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6e1e:	4d 01 d0                                        	add    r8,r10
    6e21:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6e26:	4d 01 d0                                        	add    r8,r10
    6e29:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6e2e:	4d 01 d0                                        	add    r8,r10
    6e31:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6e36:	4d 01 d0                                        	add    r8,r10
    6e39:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6e3e:	4d 01 d0                                        	add    r8,r10
    6e41:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6e46:	4d 01 d0                                        	add    r8,r10
    6e49:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6e4e:	4d 01 d0                                        	add    r8,r10
    6e51:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6e56:	4d 01 d0                                        	add    r8,r10
    6e59:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6e5e:	4d 01 d0                                        	add    r8,r10
    6e61:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6e66:	4d 01 d0                                        	add    r8,r10
    6e69:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6e6e:	4d 01 d0                                        	add    r8,r10
    6e71:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6e76:	4d 01 d0                                        	add    r8,r10
    6e79:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6e7e:	4d 01 d0                                        	add    r8,r10
    6e81:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6e86:	4d 01 d0                                        	add    r8,r10
    6e89:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6e8e:	4d 01 d0                                        	add    r8,r10
    6e91:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6e96:	4d 01 d0                                        	add    r8,r10
    6e99:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6e9e:	4d 01 d0                                        	add    r8,r10
    6ea1:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6ea6:	4d 01 d0                                        	add    r8,r10
    6ea9:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6eae:	4d 01 d0                                        	add    r8,r10
    6eb1:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6eb6:	4d 01 d0                                        	add    r8,r10
    6eb9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6ebe:	4d 01 d0                                        	add    r8,r10
    6ec1:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6ec6:	4d 01 d0                                        	add    r8,r10
    6ec9:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6ece:	4d 01 d0                                        	add    r8,r10
    6ed1:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6ed6:	4d 01 d0                                        	add    r8,r10
    6ed9:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6ede:	4d 01 d0                                        	add    r8,r10
    6ee1:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6ee6:	4d 01 d0                                        	add    r8,r10
    6ee9:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6eee:	4d 01 d0                                        	add    r8,r10
    6ef1:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6ef6:	4d 01 d0                                        	add    r8,r10
    6ef9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6efe:	4d 01 d0                                        	add    r8,r10
    6f01:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6f06:	4d 01 d0                                        	add    r8,r10
    6f09:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6f0e:	4d 01 d0                                        	add    r8,r10
    6f11:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6f16:	4d 01 d0                                        	add    r8,r10
    6f19:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6f1e:	4d 01 d0                                        	add    r8,r10
    6f21:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6f26:	4d 01 d0                                        	add    r8,r10
    6f29:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6f2e:	4d 01 d0                                        	add    r8,r10
    6f31:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6f36:	4d 01 d0                                        	add    r8,r10
    6f39:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6f3e:	4d 01 d0                                        	add    r8,r10
    6f41:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6f46:	4d 01 d0                                        	add    r8,r10
    6f49:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6f4e:	4d 01 d0                                        	add    r8,r10
    6f51:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6f56:	4d 01 d0                                        	add    r8,r10
    6f59:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6f5e:	4d 01 d0                                        	add    r8,r10
    6f61:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6f66:	4d 01 d0                                        	add    r8,r10
    6f69:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6f6e:	4d 01 d0                                        	add    r8,r10
    6f71:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6f76:	4d 01 d0                                        	add    r8,r10
    6f79:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6f7e:	4d 01 d0                                        	add    r8,r10
    6f81:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6f86:	4d 01 d0                                        	add    r8,r10
    6f89:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6f8e:	4d 01 d0                                        	add    r8,r10
    6f91:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6f96:	4d 01 d0                                        	add    r8,r10
    6f99:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6f9e:	4d 01 d0                                        	add    r8,r10
    6fa1:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6fa6:	4d 01 d0                                        	add    r8,r10
    6fa9:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6fae:	4d 01 d0                                        	add    r8,r10
    6fb1:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6fb6:	4d 01 d0                                        	add    r8,r10
    6fb9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6fbe:	4d 01 d0                                        	add    r8,r10
    6fc1:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6fc6:	4d 01 d0                                        	add    r8,r10
    6fc9:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6fce:	4d 01 d0                                        	add    r8,r10
    6fd1:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6fd6:	4d 01 d0                                        	add    r8,r10
    6fd9:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6fde:	4d 01 d0                                        	add    r8,r10
    6fe1:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6fe6:	4d 01 d0                                        	add    r8,r10
    6fe9:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6fee:	4d 01 d0                                        	add    r8,r10
    6ff1:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6ff6:	4d 01 d0                                        	add    r8,r10
    6ff9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6ffe:	4d 01 d0                                        	add    r8,r10
    7001:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7006:	4d 01 d0                                        	add    r8,r10
    7009:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    700e:	4d 01 d0                                        	add    r8,r10
    7011:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7016:	4d 01 d0                                        	add    r8,r10
    7019:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    701e:	4d 01 d0                                        	add    r8,r10
    7021:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7026:	4d 01 d0                                        	add    r8,r10
    7029:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    702e:	4d 01 d0                                        	add    r8,r10
    7031:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7036:	4d 01 d0                                        	add    r8,r10
    7039:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    703e:	4d 01 d0                                        	add    r8,r10
    7041:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7046:	4d 01 d0                                        	add    r8,r10
    7049:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    704e:	4d 01 d0                                        	add    r8,r10
    7051:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7056:	4d 01 d0                                        	add    r8,r10
    7059:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    705e:	4d 01 d0                                        	add    r8,r10
    7061:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7066:	4d 01 d0                                        	add    r8,r10
    7069:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    706e:	4d 01 d0                                        	add    r8,r10
    7071:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7076:	4d 01 d0                                        	add    r8,r10
    7079:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    707e:	4d 01 d0                                        	add    r8,r10
    7081:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7086:	4d 01 d0                                        	add    r8,r10
    7089:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    708e:	4d 01 d0                                        	add    r8,r10
    7091:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7096:	4d 01 d0                                        	add    r8,r10
    7099:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    709e:	4d 01 d0                                        	add    r8,r10
    70a1:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    70a6:	4d 01 d0                                        	add    r8,r10
    70a9:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    70ae:	4d 01 d0                                        	add    r8,r10
    70b1:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    70b6:	4d 01 d0                                        	add    r8,r10
    70b9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    70be:	4d 01 d0                                        	add    r8,r10
    70c1:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    70c6:	4d 01 d0                                        	add    r8,r10
    70c9:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    70ce:	4d 01 d0                                        	add    r8,r10
    70d1:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    70d6:	4d 01 d0                                        	add    r8,r10
    70d9:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    70de:	4d 01 d0                                        	add    r8,r10
    70e1:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    70e6:	4d 01 d0                                        	add    r8,r10
    70e9:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    70ee:	4d 01 d0                                        	add    r8,r10
    70f1:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    70f6:	4d 01 d0                                        	add    r8,r10
    70f9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    70fe:	4d 01 d0                                        	add    r8,r10
    7101:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7106:	4d 01 d0                                        	add    r8,r10
    7109:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    710e:	4d 01 d0                                        	add    r8,r10
    7111:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7116:	4d 01 d0                                        	add    r8,r10
    7119:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    711e:	4d 01 d0                                        	add    r8,r10
    7121:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7126:	4d 01 d0                                        	add    r8,r10
    7129:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    712e:	4d 01 d0                                        	add    r8,r10
    7131:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7136:	4d 01 d0                                        	add    r8,r10
    7139:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    713e:	4d 01 d0                                        	add    r8,r10
    7141:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7146:	4d 01 d0                                        	add    r8,r10
    7149:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    714e:	4d 01 d0                                        	add    r8,r10
    7151:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7156:	4d 01 d0                                        	add    r8,r10
    7159:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    715e:	4d 01 d0                                        	add    r8,r10
    7161:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7166:	4d 01 d0                                        	add    r8,r10
    7169:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    716e:	4d 01 d0                                        	add    r8,r10
    7171:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7176:	4d 01 d0                                        	add    r8,r10
    7179:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    717e:	4d 01 d0                                        	add    r8,r10
    7181:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7186:	4d 01 d0                                        	add    r8,r10
    7189:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    718e:	4d 01 d0                                        	add    r8,r10
    7191:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7196:	4d 01 d0                                        	add    r8,r10
    7199:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    719e:	4d 01 d0                                        	add    r8,r10
    71a1:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    71a6:	4d 01 d0                                        	add    r8,r10
    71a9:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    71ae:	4d 01 d0                                        	add    r8,r10
    71b1:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    71b6:	4d 01 d0                                        	add    r8,r10
    71b9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    71be:	4d 01 d0                                        	add    r8,r10
    71c1:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    71c6:	4d 01 d0                                        	add    r8,r10
    71c9:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    71ce:	4d 01 d0                                        	add    r8,r10
    71d1:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    71d6:	4d 01 d0                                        	add    r8,r10
    71d9:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    71de:	4d 01 d0                                        	add    r8,r10
    71e1:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    71e6:	4d 01 d0                                        	add    r8,r10
    71e9:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    71ee:	4d 01 d0                                        	add    r8,r10
    71f1:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    71f6:	4d 01 d0                                        	add    r8,r10
    71f9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    71fe:	4d 01 d0                                        	add    r8,r10
    7201:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7206:	4d 01 d0                                        	add    r8,r10
    7209:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    720e:	4d 01 d0                                        	add    r8,r10
    7211:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7216:	4d 01 d0                                        	add    r8,r10
    7219:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    721e:	4d 01 d0                                        	add    r8,r10
    7221:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7226:	4d 01 d0                                        	add    r8,r10
    7229:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    722e:	4d 01 d0                                        	add    r8,r10
    7231:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7236:	4d 01 d0                                        	add    r8,r10
    7239:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    723e:	4d 01 d0                                        	add    r8,r10
    7241:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7246:	4d 01 d0                                        	add    r8,r10
    7249:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    724e:	4d 01 d0                                        	add    r8,r10
    7251:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7256:	4d 01 d0                                        	add    r8,r10
    7259:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    725e:	4d 01 d0                                        	add    r8,r10
    7261:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7266:	4d 01 d0                                        	add    r8,r10
    7269:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    726e:	4d 01 d0                                        	add    r8,r10
    7271:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7276:	4d 01 d0                                        	add    r8,r10
    7279:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    727e:	4d 01 d0                                        	add    r8,r10
    7281:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7286:	4d 01 d0                                        	add    r8,r10
    7289:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    728e:	4d 01 d0                                        	add    r8,r10
    7291:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7296:	4d 01 d0                                        	add    r8,r10
    7299:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    729e:	4d 01 d0                                        	add    r8,r10
    72a1:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    72a6:	4d 01 d0                                        	add    r8,r10
    72a9:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    72ae:	4d 01 d0                                        	add    r8,r10
    72b1:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    72b6:	4d 01 d0                                        	add    r8,r10
    72b9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    72be:	4d 01 d0                                        	add    r8,r10
    72c1:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    72c6:	4d 01 d0                                        	add    r8,r10
    72c9:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    72ce:	4d 01 d0                                        	add    r8,r10
    72d1:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    72d6:	4d 01 d0                                        	add    r8,r10
    72d9:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    72de:	4d 01 d0                                        	add    r8,r10
    72e1:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    72e6:	4d 01 d0                                        	add    r8,r10
    72e9:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    72ee:	4d 01 d0                                        	add    r8,r10
    72f1:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    72f6:	4d 01 d0                                        	add    r8,r10
    72f9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    72fe:	4d 01 d0                                        	add    r8,r10
    7301:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7306:	4d 01 d0                                        	add    r8,r10
    7309:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    730e:	4d 01 d0                                        	add    r8,r10
    7311:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7316:	4d 01 d0                                        	add    r8,r10
    7319:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    731e:	4d 01 d0                                        	add    r8,r10
    7321:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7326:	4d 01 d0                                        	add    r8,r10
    7329:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    732e:	4d 01 d0                                        	add    r8,r10
    7331:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7336:	4d 01 d0                                        	add    r8,r10
    7339:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    733e:	4d 01 d0                                        	add    r8,r10
    7341:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7346:	4d 01 d0                                        	add    r8,r10
    7349:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    734e:	4d 01 d0                                        	add    r8,r10
    7351:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7356:	4d 01 d0                                        	add    r8,r10
    7359:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    735e:	4d 01 d0                                        	add    r8,r10
    7361:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7366:	4d 01 d0                                        	add    r8,r10
    7369:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    736e:	4d 01 d0                                        	add    r8,r10
    7371:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7376:	4d 01 d0                                        	add    r8,r10
    7379:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    737e:	4d 01 d0                                        	add    r8,r10
    7381:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7386:	4d 01 d0                                        	add    r8,r10
    7389:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    738e:	4d 01 d0                                        	add    r8,r10
    7391:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7396:	4d 01 d0                                        	add    r8,r10
    7399:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    739e:	4d 01 d0                                        	add    r8,r10
    73a1:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    73a6:	4d 01 d0                                        	add    r8,r10
    73a9:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    73ae:	4d 01 d0                                        	add    r8,r10
    73b1:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    73b6:	4d 01 d0                                        	add    r8,r10
    73b9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    73be:	4d 01 d0                                        	add    r8,r10
    73c1:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    73c6:	4d 01 d0                                        	add    r8,r10
    73c9:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    73ce:	4d 01 d0                                        	add    r8,r10
    73d1:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    73d6:	4d 01 d0                                        	add    r8,r10
    73d9:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    73de:	4d 01 d0                                        	add    r8,r10
    73e1:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    73e6:	4d 01 d0                                        	add    r8,r10
    73e9:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    73ee:	4d 01 d0                                        	add    r8,r10
    73f1:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    73f6:	4d 01 d0                                        	add    r8,r10
    73f9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    73fe:	4d 01 d0                                        	add    r8,r10
    7401:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7406:	4d 01 d0                                        	add    r8,r10
    7409:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    740e:	4d 01 d0                                        	add    r8,r10
    7411:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7416:	4d 01 d0                                        	add    r8,r10
    7419:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    741e:	4d 01 d0                                        	add    r8,r10
    7421:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7426:	4d 01 d0                                        	add    r8,r10
    7429:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    742e:	4d 01 d0                                        	add    r8,r10
    7431:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7436:	4d 01 d0                                        	add    r8,r10
    7439:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    743e:	4d 01 d0                                        	add    r8,r10
    7441:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7446:	4d 01 d0                                        	add    r8,r10
    7449:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    744e:	4d 01 d0                                        	add    r8,r10
    7451:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7456:	4d 01 d0                                        	add    r8,r10
    7459:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    745e:	4d 01 d0                                        	add    r8,r10
    7461:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7466:	4d 01 d0                                        	add    r8,r10
    7469:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    746e:	4d 01 d0                                        	add    r8,r10
    7471:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7476:	4d 01 d0                                        	add    r8,r10
    7479:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    747e:	4d 01 d0                                        	add    r8,r10
    7481:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7486:	4d 01 d0                                        	add    r8,r10
    7489:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    748e:	4d 01 d0                                        	add    r8,r10
    7491:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7496:	4d 01 d0                                        	add    r8,r10
    7499:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    749e:	4d 01 d0                                        	add    r8,r10
    74a1:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    74a6:	4d 01 d0                                        	add    r8,r10
    74a9:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    74ae:	4d 01 d0                                        	add    r8,r10
    74b1:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    74b6:	4d 01 d0                                        	add    r8,r10
    74b9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    74be:	4d 01 d0                                        	add    r8,r10
    74c1:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    74c6:	4d 01 d0                                        	add    r8,r10
    74c9:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    74ce:	4d 01 d0                                        	add    r8,r10
    74d1:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    74d6:	4d 01 d0                                        	add    r8,r10
    74d9:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    74de:	4d 01 d0                                        	add    r8,r10
    74e1:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    74e6:	4d 01 d0                                        	add    r8,r10
    74e9:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    74ee:	4d 01 d0                                        	add    r8,r10
    74f1:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    74f6:	4d 01 d0                                        	add    r8,r10
    74f9:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    74fe:	4d 01 d0                                        	add    r8,r10
    7501:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7506:	4d 01 d0                                        	add    r8,r10
    7509:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    750e:	4d 01 d0                                        	add    r8,r10
    7511:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7516:	4d 01 d0                                        	add    r8,r10
    7519:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    751e:	4d 01 d0                                        	add    r8,r10
    7521:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7526:	4d 01 d0                                        	add    r8,r10
    7529:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    752e:	4d 01 d0                                        	add    r8,r10
    7531:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7536:	4d 01 d0                                        	add    r8,r10
    7539:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    753e:	4d 01 d0                                        	add    r8,r10
    7541:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7546:	4d 01 d0                                        	add    r8,r10
    7549:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    754e:	4d 01 d0                                        	add    r8,r10
    7551:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7556:	4d 01 d0                                        	add    r8,r10
    7559:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    755e:	4d 01 d0                                        	add    r8,r10
    7561:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7566:	4d 01 d0                                        	add    r8,r10
    7569:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    756e:	4d 01 d0                                        	add    r8,r10
    7571:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7576:	4d 01 d0                                        	add    r8,r10
    7579:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    757e:	4d 01 d0                                        	add    r8,r10
    7581:	41 f6 c1 01                                     	test   r9b,0x1
    7585:	74 04                                           	je     758b <join_5>
    7587:	49 83 f0 01                                     	xor    r8,0x1

000000000000758b <join_5>:
    758b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7590:	4d 01 d0                                        	add    r8,r10
    7593:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7598:	4d 01 d0                                        	add    r8,r10
    759b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    75a0:	4d 01 d0                                        	add    r8,r10
    75a3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    75a8:	4d 01 d0                                        	add    r8,r10
    75ab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    75b0:	4d 01 d0                                        	add    r8,r10
    75b3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    75b8:	4d 01 d0                                        	add    r8,r10
    75bb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    75c0:	4d 01 d0                                        	add    r8,r10
    75c3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    75c8:	4d 01 d0                                        	add    r8,r10
    75cb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    75d0:	4d 01 d0                                        	add    r8,r10
    75d3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    75d8:	4d 01 d0                                        	add    r8,r10
    75db:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    75e0:	4d 01 d0                                        	add    r8,r10
    75e3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    75e8:	4d 01 d0                                        	add    r8,r10
    75eb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    75f0:	4d 01 d0                                        	add    r8,r10
    75f3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    75f8:	4d 01 d0                                        	add    r8,r10
    75fb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7600:	4d 01 d0                                        	add    r8,r10
    7603:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7608:	4d 01 d0                                        	add    r8,r10
    760b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7610:	4d 01 d0                                        	add    r8,r10
    7613:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7618:	4d 01 d0                                        	add    r8,r10
    761b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7620:	4d 01 d0                                        	add    r8,r10
    7623:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7628:	4d 01 d0                                        	add    r8,r10
    762b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7630:	4d 01 d0                                        	add    r8,r10
    7633:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7638:	4d 01 d0                                        	add    r8,r10
    763b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7640:	4d 01 d0                                        	add    r8,r10
    7643:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7648:	4d 01 d0                                        	add    r8,r10
    764b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7650:	4d 01 d0                                        	add    r8,r10
    7653:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7658:	4d 01 d0                                        	add    r8,r10
    765b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7660:	4d 01 d0                                        	add    r8,r10
    7663:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7668:	4d 01 d0                                        	add    r8,r10
    766b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7670:	4d 01 d0                                        	add    r8,r10
    7673:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7678:	4d 01 d0                                        	add    r8,r10
    767b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7680:	4d 01 d0                                        	add    r8,r10
    7683:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7688:	4d 01 d0                                        	add    r8,r10
    768b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7690:	4d 01 d0                                        	add    r8,r10
    7693:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7698:	4d 01 d0                                        	add    r8,r10
    769b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    76a0:	4d 01 d0                                        	add    r8,r10
    76a3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    76a8:	4d 01 d0                                        	add    r8,r10
    76ab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    76b0:	4d 01 d0                                        	add    r8,r10
    76b3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    76b8:	4d 01 d0                                        	add    r8,r10
    76bb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    76c0:	4d 01 d0                                        	add    r8,r10
    76c3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    76c8:	4d 01 d0                                        	add    r8,r10
    76cb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    76d0:	4d 01 d0                                        	add    r8,r10
    76d3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    76d8:	4d 01 d0                                        	add    r8,r10
    76db:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    76e0:	4d 01 d0                                        	add    r8,r10
    76e3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    76e8:	4d 01 d0                                        	add    r8,r10
    76eb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    76f0:	4d 01 d0                                        	add    r8,r10
    76f3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    76f8:	4d 01 d0                                        	add    r8,r10
    76fb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7700:	4d 01 d0                                        	add    r8,r10
    7703:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7708:	4d 01 d0                                        	add    r8,r10
    770b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7710:	4d 01 d0                                        	add    r8,r10
    7713:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7718:	4d 01 d0                                        	add    r8,r10
    771b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7720:	4d 01 d0                                        	add    r8,r10
    7723:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7728:	4d 01 d0                                        	add    r8,r10
    772b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7730:	4d 01 d0                                        	add    r8,r10
    7733:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7738:	4d 01 d0                                        	add    r8,r10
    773b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7740:	4d 01 d0                                        	add    r8,r10
    7743:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7748:	4d 01 d0                                        	add    r8,r10
    774b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7750:	4d 01 d0                                        	add    r8,r10
    7753:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7758:	4d 01 d0                                        	add    r8,r10
    775b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7760:	4d 01 d0                                        	add    r8,r10
    7763:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7768:	4d 01 d0                                        	add    r8,r10
    776b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7770:	4d 01 d0                                        	add    r8,r10
    7773:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7778:	4d 01 d0                                        	add    r8,r10
    777b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7780:	4d 01 d0                                        	add    r8,r10
    7783:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7788:	4d 01 d0                                        	add    r8,r10
    778b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7790:	4d 01 d0                                        	add    r8,r10
    7793:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7798:	4d 01 d0                                        	add    r8,r10
    779b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    77a0:	4d 01 d0                                        	add    r8,r10
    77a3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    77a8:	4d 01 d0                                        	add    r8,r10
    77ab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    77b0:	4d 01 d0                                        	add    r8,r10
    77b3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    77b8:	4d 01 d0                                        	add    r8,r10
    77bb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    77c0:	4d 01 d0                                        	add    r8,r10
    77c3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    77c8:	4d 01 d0                                        	add    r8,r10
    77cb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    77d0:	4d 01 d0                                        	add    r8,r10
    77d3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    77d8:	4d 01 d0                                        	add    r8,r10
    77db:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    77e0:	4d 01 d0                                        	add    r8,r10
    77e3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    77e8:	4d 01 d0                                        	add    r8,r10
    77eb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    77f0:	4d 01 d0                                        	add    r8,r10
    77f3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    77f8:	4d 01 d0                                        	add    r8,r10
    77fb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7800:	4d 01 d0                                        	add    r8,r10
    7803:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7808:	4d 01 d0                                        	add    r8,r10
    780b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7810:	4d 01 d0                                        	add    r8,r10
    7813:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7818:	4d 01 d0                                        	add    r8,r10
    781b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7820:	4d 01 d0                                        	add    r8,r10
    7823:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7828:	4d 01 d0                                        	add    r8,r10
    782b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7830:	4d 01 d0                                        	add    r8,r10
    7833:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7838:	4d 01 d0                                        	add    r8,r10
    783b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7840:	4d 01 d0                                        	add    r8,r10
    7843:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7848:	4d 01 d0                                        	add    r8,r10
    784b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7850:	4d 01 d0                                        	add    r8,r10
    7853:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7858:	4d 01 d0                                        	add    r8,r10
    785b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7860:	4d 01 d0                                        	add    r8,r10
    7863:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7868:	4d 01 d0                                        	add    r8,r10
    786b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7870:	4d 01 d0                                        	add    r8,r10
    7873:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7878:	4d 01 d0                                        	add    r8,r10
    787b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7880:	4d 01 d0                                        	add    r8,r10
    7883:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7888:	4d 01 d0                                        	add    r8,r10
    788b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7890:	4d 01 d0                                        	add    r8,r10
    7893:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7898:	4d 01 d0                                        	add    r8,r10
    789b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    78a0:	4d 01 d0                                        	add    r8,r10
    78a3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    78a8:	4d 01 d0                                        	add    r8,r10
    78ab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    78b0:	4d 01 d0                                        	add    r8,r10
    78b3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    78b8:	4d 01 d0                                        	add    r8,r10
    78bb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    78c0:	4d 01 d0                                        	add    r8,r10
    78c3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    78c8:	4d 01 d0                                        	add    r8,r10
    78cb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    78d0:	4d 01 d0                                        	add    r8,r10
    78d3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    78d8:	4d 01 d0                                        	add    r8,r10
    78db:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    78e0:	4d 01 d0                                        	add    r8,r10
    78e3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    78e8:	4d 01 d0                                        	add    r8,r10
    78eb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    78f0:	4d 01 d0                                        	add    r8,r10
    78f3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    78f8:	4d 01 d0                                        	add    r8,r10
    78fb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7900:	4d 01 d0                                        	add    r8,r10
    7903:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7908:	4d 01 d0                                        	add    r8,r10
    790b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7910:	4d 01 d0                                        	add    r8,r10
    7913:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7918:	4d 01 d0                                        	add    r8,r10
    791b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7920:	4d 01 d0                                        	add    r8,r10
    7923:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7928:	4d 01 d0                                        	add    r8,r10
    792b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7930:	4d 01 d0                                        	add    r8,r10
    7933:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7938:	4d 01 d0                                        	add    r8,r10
    793b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7940:	4d 01 d0                                        	add    r8,r10
    7943:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7948:	4d 01 d0                                        	add    r8,r10
    794b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7950:	4d 01 d0                                        	add    r8,r10
    7953:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7958:	4d 01 d0                                        	add    r8,r10
    795b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7960:	4d 01 d0                                        	add    r8,r10
    7963:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7968:	4d 01 d0                                        	add    r8,r10
    796b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7970:	4d 01 d0                                        	add    r8,r10
    7973:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7978:	4d 01 d0                                        	add    r8,r10
    797b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7980:	4d 01 d0                                        	add    r8,r10
    7983:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7988:	4d 01 d0                                        	add    r8,r10
    798b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7990:	4d 01 d0                                        	add    r8,r10
    7993:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7998:	4d 01 d0                                        	add    r8,r10
    799b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    79a0:	4d 01 d0                                        	add    r8,r10
    79a3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    79a8:	4d 01 d0                                        	add    r8,r10
    79ab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    79b0:	4d 01 d0                                        	add    r8,r10
    79b3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    79b8:	4d 01 d0                                        	add    r8,r10
    79bb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    79c0:	4d 01 d0                                        	add    r8,r10
    79c3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    79c8:	4d 01 d0                                        	add    r8,r10
    79cb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    79d0:	4d 01 d0                                        	add    r8,r10
    79d3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    79d8:	4d 01 d0                                        	add    r8,r10
    79db:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    79e0:	4d 01 d0                                        	add    r8,r10
    79e3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    79e8:	4d 01 d0                                        	add    r8,r10
    79eb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    79f0:	4d 01 d0                                        	add    r8,r10
    79f3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    79f8:	4d 01 d0                                        	add    r8,r10
    79fb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7a00:	4d 01 d0                                        	add    r8,r10
    7a03:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7a08:	4d 01 d0                                        	add    r8,r10
    7a0b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7a10:	4d 01 d0                                        	add    r8,r10
    7a13:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7a18:	4d 01 d0                                        	add    r8,r10
    7a1b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7a20:	4d 01 d0                                        	add    r8,r10
    7a23:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7a28:	4d 01 d0                                        	add    r8,r10
    7a2b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7a30:	4d 01 d0                                        	add    r8,r10
    7a33:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7a38:	4d 01 d0                                        	add    r8,r10
    7a3b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7a40:	4d 01 d0                                        	add    r8,r10
    7a43:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7a48:	4d 01 d0                                        	add    r8,r10
    7a4b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7a50:	4d 01 d0                                        	add    r8,r10
    7a53:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7a58:	4d 01 d0                                        	add    r8,r10
    7a5b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7a60:	4d 01 d0                                        	add    r8,r10
    7a63:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7a68:	4d 01 d0                                        	add    r8,r10
    7a6b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7a70:	4d 01 d0                                        	add    r8,r10
    7a73:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7a78:	4d 01 d0                                        	add    r8,r10
    7a7b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7a80:	4d 01 d0                                        	add    r8,r10
    7a83:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7a88:	4d 01 d0                                        	add    r8,r10
    7a8b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7a90:	4d 01 d0                                        	add    r8,r10
    7a93:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7a98:	4d 01 d0                                        	add    r8,r10
    7a9b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7aa0:	4d 01 d0                                        	add    r8,r10
    7aa3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7aa8:	4d 01 d0                                        	add    r8,r10
    7aab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7ab0:	4d 01 d0                                        	add    r8,r10
    7ab3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7ab8:	4d 01 d0                                        	add    r8,r10
    7abb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7ac0:	4d 01 d0                                        	add    r8,r10
    7ac3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7ac8:	4d 01 d0                                        	add    r8,r10
    7acb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7ad0:	4d 01 d0                                        	add    r8,r10
    7ad3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7ad8:	4d 01 d0                                        	add    r8,r10
    7adb:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7ae0:	4d 01 d0                                        	add    r8,r10
    7ae3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7ae8:	4d 01 d0                                        	add    r8,r10
    7aeb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7af0:	4d 01 d0                                        	add    r8,r10
    7af3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7af8:	4d 01 d0                                        	add    r8,r10
    7afb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7b00:	4d 01 d0                                        	add    r8,r10
    7b03:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7b08:	4d 01 d0                                        	add    r8,r10
    7b0b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7b10:	4d 01 d0                                        	add    r8,r10
    7b13:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7b18:	4d 01 d0                                        	add    r8,r10
    7b1b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7b20:	4d 01 d0                                        	add    r8,r10
    7b23:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7b28:	4d 01 d0                                        	add    r8,r10
    7b2b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7b30:	4d 01 d0                                        	add    r8,r10
    7b33:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7b38:	4d 01 d0                                        	add    r8,r10
    7b3b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7b40:	4d 01 d0                                        	add    r8,r10
    7b43:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7b48:	4d 01 d0                                        	add    r8,r10
    7b4b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7b50:	4d 01 d0                                        	add    r8,r10
    7b53:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7b58:	4d 01 d0                                        	add    r8,r10
    7b5b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7b60:	4d 01 d0                                        	add    r8,r10
    7b63:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7b68:	4d 01 d0                                        	add    r8,r10
    7b6b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7b70:	4d 01 d0                                        	add    r8,r10
    7b73:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7b78:	4d 01 d0                                        	add    r8,r10
    7b7b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7b80:	4d 01 d0                                        	add    r8,r10
    7b83:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7b88:	4d 01 d0                                        	add    r8,r10
    7b8b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7b90:	4d 01 d0                                        	add    r8,r10
    7b93:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7b98:	4d 01 d0                                        	add    r8,r10
    7b9b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7ba0:	4d 01 d0                                        	add    r8,r10
    7ba3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7ba8:	4d 01 d0                                        	add    r8,r10
    7bab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7bb0:	4d 01 d0                                        	add    r8,r10
    7bb3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7bb8:	4d 01 d0                                        	add    r8,r10
    7bbb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7bc0:	4d 01 d0                                        	add    r8,r10
    7bc3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7bc8:	4d 01 d0                                        	add    r8,r10
    7bcb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7bd0:	4d 01 d0                                        	add    r8,r10
    7bd3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7bd8:	4d 01 d0                                        	add    r8,r10
    7bdb:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7be0:	4d 01 d0                                        	add    r8,r10
    7be3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7be8:	4d 01 d0                                        	add    r8,r10
    7beb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7bf0:	4d 01 d0                                        	add    r8,r10
    7bf3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7bf8:	4d 01 d0                                        	add    r8,r10
    7bfb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7c00:	4d 01 d0                                        	add    r8,r10
    7c03:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7c08:	4d 01 d0                                        	add    r8,r10
    7c0b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7c10:	4d 01 d0                                        	add    r8,r10
    7c13:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7c18:	4d 01 d0                                        	add    r8,r10
    7c1b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7c20:	4d 01 d0                                        	add    r8,r10
    7c23:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7c28:	4d 01 d0                                        	add    r8,r10
    7c2b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7c30:	4d 01 d0                                        	add    r8,r10
    7c33:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7c38:	4d 01 d0                                        	add    r8,r10
    7c3b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7c40:	4d 01 d0                                        	add    r8,r10
    7c43:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7c48:	4d 01 d0                                        	add    r8,r10
    7c4b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7c50:	4d 01 d0                                        	add    r8,r10
    7c53:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7c58:	4d 01 d0                                        	add    r8,r10
    7c5b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7c60:	4d 01 d0                                        	add    r8,r10
    7c63:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7c68:	4d 01 d0                                        	add    r8,r10
    7c6b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7c70:	4d 01 d0                                        	add    r8,r10
    7c73:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7c78:	4d 01 d0                                        	add    r8,r10
    7c7b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7c80:	4d 01 d0                                        	add    r8,r10
    7c83:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7c88:	4d 01 d0                                        	add    r8,r10
    7c8b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7c90:	4d 01 d0                                        	add    r8,r10
    7c93:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7c98:	4d 01 d0                                        	add    r8,r10
    7c9b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7ca0:	4d 01 d0                                        	add    r8,r10
    7ca3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7ca8:	4d 01 d0                                        	add    r8,r10
    7cab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7cb0:	4d 01 d0                                        	add    r8,r10
    7cb3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7cb8:	4d 01 d0                                        	add    r8,r10
    7cbb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7cc0:	4d 01 d0                                        	add    r8,r10
    7cc3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7cc8:	4d 01 d0                                        	add    r8,r10
    7ccb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7cd0:	4d 01 d0                                        	add    r8,r10
    7cd3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7cd8:	4d 01 d0                                        	add    r8,r10
    7cdb:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7ce0:	4d 01 d0                                        	add    r8,r10
    7ce3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7ce8:	4d 01 d0                                        	add    r8,r10
    7ceb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7cf0:	4d 01 d0                                        	add    r8,r10
    7cf3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7cf8:	4d 01 d0                                        	add    r8,r10
    7cfb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7d00:	4d 01 d0                                        	add    r8,r10
    7d03:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7d08:	4d 01 d0                                        	add    r8,r10
    7d0b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7d10:	4d 01 d0                                        	add    r8,r10
    7d13:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7d18:	4d 01 d0                                        	add    r8,r10
    7d1b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7d20:	4d 01 d0                                        	add    r8,r10
    7d23:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7d28:	4d 01 d0                                        	add    r8,r10
    7d2b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7d30:	4d 01 d0                                        	add    r8,r10
    7d33:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7d38:	4d 01 d0                                        	add    r8,r10
    7d3b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7d40:	4d 01 d0                                        	add    r8,r10
    7d43:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7d48:	4d 01 d0                                        	add    r8,r10
    7d4b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7d50:	4d 01 d0                                        	add    r8,r10
    7d53:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7d58:	4d 01 d0                                        	add    r8,r10
    7d5b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7d60:	4d 01 d0                                        	add    r8,r10
    7d63:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7d68:	4d 01 d0                                        	add    r8,r10
    7d6b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7d70:	4d 01 d0                                        	add    r8,r10
    7d73:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7d78:	4d 01 d0                                        	add    r8,r10
    7d7b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7d80:	4d 01 d0                                        	add    r8,r10
    7d83:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7d88:	4d 01 d0                                        	add    r8,r10
    7d8b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7d90:	4d 01 d0                                        	add    r8,r10
    7d93:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7d98:	4d 01 d0                                        	add    r8,r10
    7d9b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7da0:	4d 01 d0                                        	add    r8,r10
    7da3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7da8:	4d 01 d0                                        	add    r8,r10
    7dab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7db0:	4d 01 d0                                        	add    r8,r10
    7db3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7db8:	4d 01 d0                                        	add    r8,r10
    7dbb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7dc0:	4d 01 d0                                        	add    r8,r10
    7dc3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7dc8:	4d 01 d0                                        	add    r8,r10
    7dcb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7dd0:	4d 01 d0                                        	add    r8,r10
    7dd3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7dd8:	4d 01 d0                                        	add    r8,r10
    7ddb:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7de0:	4d 01 d0                                        	add    r8,r10
    7de3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7de8:	4d 01 d0                                        	add    r8,r10
    7deb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7df0:	4d 01 d0                                        	add    r8,r10
    7df3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7df8:	4d 01 d0                                        	add    r8,r10
    7dfb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7e00:	4d 01 d0                                        	add    r8,r10
    7e03:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7e08:	4d 01 d0                                        	add    r8,r10
    7e0b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7e10:	4d 01 d0                                        	add    r8,r10
    7e13:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7e18:	4d 01 d0                                        	add    r8,r10
    7e1b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7e20:	4d 01 d0                                        	add    r8,r10
    7e23:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7e28:	4d 01 d0                                        	add    r8,r10
    7e2b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7e30:	4d 01 d0                                        	add    r8,r10
    7e33:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7e38:	4d 01 d0                                        	add    r8,r10
    7e3b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7e40:	4d 01 d0                                        	add    r8,r10
    7e43:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7e48:	4d 01 d0                                        	add    r8,r10
    7e4b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7e50:	4d 01 d0                                        	add    r8,r10
    7e53:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7e58:	4d 01 d0                                        	add    r8,r10
    7e5b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7e60:	4d 01 d0                                        	add    r8,r10
    7e63:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7e68:	4d 01 d0                                        	add    r8,r10
    7e6b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7e70:	4d 01 d0                                        	add    r8,r10
    7e73:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7e78:	4d 01 d0                                        	add    r8,r10
    7e7b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7e80:	4d 01 d0                                        	add    r8,r10
    7e83:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7e88:	4d 01 d0                                        	add    r8,r10
    7e8b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7e90:	4d 01 d0                                        	add    r8,r10
    7e93:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7e98:	4d 01 d0                                        	add    r8,r10
    7e9b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7ea0:	4d 01 d0                                        	add    r8,r10
    7ea3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7ea8:	4d 01 d0                                        	add    r8,r10
    7eab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7eb0:	4d 01 d0                                        	add    r8,r10
    7eb3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7eb8:	4d 01 d0                                        	add    r8,r10
    7ebb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7ec0:	4d 01 d0                                        	add    r8,r10
    7ec3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7ec8:	4d 01 d0                                        	add    r8,r10
    7ecb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7ed0:	4d 01 d0                                        	add    r8,r10
    7ed3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7ed8:	4d 01 d0                                        	add    r8,r10
    7edb:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7ee0:	4d 01 d0                                        	add    r8,r10
    7ee3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7ee8:	4d 01 d0                                        	add    r8,r10
    7eeb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7ef0:	4d 01 d0                                        	add    r8,r10
    7ef3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7ef8:	4d 01 d0                                        	add    r8,r10
    7efb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7f00:	4d 01 d0                                        	add    r8,r10
    7f03:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7f08:	4d 01 d0                                        	add    r8,r10
    7f0b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7f10:	4d 01 d0                                        	add    r8,r10
    7f13:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7f18:	4d 01 d0                                        	add    r8,r10
    7f1b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7f20:	4d 01 d0                                        	add    r8,r10
    7f23:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7f28:	4d 01 d0                                        	add    r8,r10
    7f2b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7f30:	4d 01 d0                                        	add    r8,r10
    7f33:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7f38:	4d 01 d0                                        	add    r8,r10
    7f3b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7f40:	4d 01 d0                                        	add    r8,r10
    7f43:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7f48:	4d 01 d0                                        	add    r8,r10
    7f4b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7f50:	4d 01 d0                                        	add    r8,r10
    7f53:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7f58:	4d 01 d0                                        	add    r8,r10
    7f5b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7f60:	4d 01 d0                                        	add    r8,r10
    7f63:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7f68:	4d 01 d0                                        	add    r8,r10
    7f6b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7f70:	4d 01 d0                                        	add    r8,r10
    7f73:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7f78:	4d 01 d0                                        	add    r8,r10
    7f7b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7f80:	4d 01 d0                                        	add    r8,r10
    7f83:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7f88:	4d 01 d0                                        	add    r8,r10
    7f8b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7f90:	4d 01 d0                                        	add    r8,r10
    7f93:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7f98:	4d 01 d0                                        	add    r8,r10
    7f9b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7fa0:	4d 01 d0                                        	add    r8,r10
    7fa3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7fa8:	4d 01 d0                                        	add    r8,r10
    7fab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7fb0:	4d 01 d0                                        	add    r8,r10
    7fb3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7fb8:	4d 01 d0                                        	add    r8,r10
    7fbb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7fc0:	4d 01 d0                                        	add    r8,r10
    7fc3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7fc8:	4d 01 d0                                        	add    r8,r10
    7fcb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7fd0:	4d 01 d0                                        	add    r8,r10
    7fd3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7fd8:	4d 01 d0                                        	add    r8,r10
    7fdb:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7fe0:	4d 01 d0                                        	add    r8,r10
    7fe3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7fe8:	4d 01 d0                                        	add    r8,r10
    7feb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7ff0:	4d 01 d0                                        	add    r8,r10
    7ff3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7ff8:	4d 01 d0                                        	add    r8,r10
    7ffb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8000:	4d 01 d0                                        	add    r8,r10
    8003:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8008:	4d 01 d0                                        	add    r8,r10
    800b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8010:	4d 01 d0                                        	add    r8,r10
    8013:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8018:	4d 01 d0                                        	add    r8,r10
    801b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8020:	4d 01 d0                                        	add    r8,r10
    8023:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8028:	4d 01 d0                                        	add    r8,r10
    802b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8030:	4d 01 d0                                        	add    r8,r10
    8033:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8038:	4d 01 d0                                        	add    r8,r10
    803b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8040:	4d 01 d0                                        	add    r8,r10
    8043:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8048:	4d 01 d0                                        	add    r8,r10
    804b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8050:	4d 01 d0                                        	add    r8,r10
    8053:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8058:	4d 01 d0                                        	add    r8,r10
    805b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8060:	4d 01 d0                                        	add    r8,r10
    8063:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8068:	4d 01 d0                                        	add    r8,r10
    806b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8070:	4d 01 d0                                        	add    r8,r10
    8073:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8078:	4d 01 d0                                        	add    r8,r10
    807b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8080:	4d 01 d0                                        	add    r8,r10
    8083:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8088:	4d 01 d0                                        	add    r8,r10
    808b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8090:	4d 01 d0                                        	add    r8,r10
    8093:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8098:	4d 01 d0                                        	add    r8,r10
    809b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    80a0:	4d 01 d0                                        	add    r8,r10
    80a3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    80a8:	4d 01 d0                                        	add    r8,r10
    80ab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    80b0:	4d 01 d0                                        	add    r8,r10
    80b3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    80b8:	4d 01 d0                                        	add    r8,r10
    80bb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    80c0:	4d 01 d0                                        	add    r8,r10
    80c3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    80c8:	4d 01 d0                                        	add    r8,r10
    80cb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    80d0:	4d 01 d0                                        	add    r8,r10
    80d3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    80d8:	4d 01 d0                                        	add    r8,r10
    80db:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    80e0:	4d 01 d0                                        	add    r8,r10
    80e3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    80e8:	4d 01 d0                                        	add    r8,r10
    80eb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    80f0:	4d 01 d0                                        	add    r8,r10
    80f3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    80f8:	4d 01 d0                                        	add    r8,r10
    80fb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8100:	4d 01 d0                                        	add    r8,r10
    8103:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8108:	4d 01 d0                                        	add    r8,r10
    810b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8110:	4d 01 d0                                        	add    r8,r10
    8113:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8118:	4d 01 d0                                        	add    r8,r10
    811b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8120:	4d 01 d0                                        	add    r8,r10
    8123:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8128:	4d 01 d0                                        	add    r8,r10
    812b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8130:	4d 01 d0                                        	add    r8,r10
    8133:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8138:	4d 01 d0                                        	add    r8,r10
    813b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8140:	4d 01 d0                                        	add    r8,r10
    8143:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8148:	4d 01 d0                                        	add    r8,r10
    814b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8150:	4d 01 d0                                        	add    r8,r10
    8153:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8158:	4d 01 d0                                        	add    r8,r10
    815b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8160:	4d 01 d0                                        	add    r8,r10
    8163:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8168:	4d 01 d0                                        	add    r8,r10
    816b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8170:	4d 01 d0                                        	add    r8,r10
    8173:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8178:	4d 01 d0                                        	add    r8,r10
    817b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8180:	4d 01 d0                                        	add    r8,r10
    8183:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8188:	4d 01 d0                                        	add    r8,r10
    818b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8190:	4d 01 d0                                        	add    r8,r10
    8193:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8198:	4d 01 d0                                        	add    r8,r10
    819b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    81a0:	4d 01 d0                                        	add    r8,r10
    81a3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    81a8:	4d 01 d0                                        	add    r8,r10
    81ab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    81b0:	4d 01 d0                                        	add    r8,r10
    81b3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    81b8:	4d 01 d0                                        	add    r8,r10
    81bb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    81c0:	4d 01 d0                                        	add    r8,r10
    81c3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    81c8:	4d 01 d0                                        	add    r8,r10
    81cb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    81d0:	4d 01 d0                                        	add    r8,r10
    81d3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    81d8:	4d 01 d0                                        	add    r8,r10
    81db:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    81e0:	4d 01 d0                                        	add    r8,r10
    81e3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    81e8:	4d 01 d0                                        	add    r8,r10
    81eb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    81f0:	4d 01 d0                                        	add    r8,r10
    81f3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    81f8:	4d 01 d0                                        	add    r8,r10
    81fb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8200:	4d 01 d0                                        	add    r8,r10
    8203:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8208:	4d 01 d0                                        	add    r8,r10
    820b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8210:	4d 01 d0                                        	add    r8,r10
    8213:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8218:	4d 01 d0                                        	add    r8,r10
    821b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8220:	4d 01 d0                                        	add    r8,r10
    8223:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8228:	4d 01 d0                                        	add    r8,r10
    822b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8230:	4d 01 d0                                        	add    r8,r10
    8233:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8238:	4d 01 d0                                        	add    r8,r10
    823b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8240:	4d 01 d0                                        	add    r8,r10
    8243:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8248:	4d 01 d0                                        	add    r8,r10
    824b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8250:	4d 01 d0                                        	add    r8,r10
    8253:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8258:	4d 01 d0                                        	add    r8,r10
    825b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8260:	4d 01 d0                                        	add    r8,r10
    8263:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8268:	4d 01 d0                                        	add    r8,r10
    826b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8270:	4d 01 d0                                        	add    r8,r10
    8273:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8278:	4d 01 d0                                        	add    r8,r10
    827b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8280:	4d 01 d0                                        	add    r8,r10
    8283:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8288:	4d 01 d0                                        	add    r8,r10
    828b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8290:	4d 01 d0                                        	add    r8,r10
    8293:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8298:	4d 01 d0                                        	add    r8,r10
    829b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    82a0:	4d 01 d0                                        	add    r8,r10
    82a3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    82a8:	4d 01 d0                                        	add    r8,r10
    82ab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    82b0:	4d 01 d0                                        	add    r8,r10
    82b3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    82b8:	4d 01 d0                                        	add    r8,r10
    82bb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    82c0:	4d 01 d0                                        	add    r8,r10
    82c3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    82c8:	4d 01 d0                                        	add    r8,r10
    82cb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    82d0:	4d 01 d0                                        	add    r8,r10
    82d3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    82d8:	4d 01 d0                                        	add    r8,r10
    82db:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    82e0:	4d 01 d0                                        	add    r8,r10
    82e3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    82e8:	4d 01 d0                                        	add    r8,r10
    82eb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    82f0:	4d 01 d0                                        	add    r8,r10
    82f3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    82f8:	4d 01 d0                                        	add    r8,r10
    82fb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8300:	4d 01 d0                                        	add    r8,r10
    8303:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8308:	4d 01 d0                                        	add    r8,r10
    830b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8310:	4d 01 d0                                        	add    r8,r10
    8313:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8318:	4d 01 d0                                        	add    r8,r10
    831b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8320:	4d 01 d0                                        	add    r8,r10
    8323:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8328:	4d 01 d0                                        	add    r8,r10
    832b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8330:	4d 01 d0                                        	add    r8,r10
    8333:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8338:	4d 01 d0                                        	add    r8,r10
    833b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8340:	4d 01 d0                                        	add    r8,r10
    8343:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8348:	4d 01 d0                                        	add    r8,r10
    834b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8350:	4d 01 d0                                        	add    r8,r10
    8353:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8358:	4d 01 d0                                        	add    r8,r10
    835b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8360:	4d 01 d0                                        	add    r8,r10
    8363:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8368:	4d 01 d0                                        	add    r8,r10
    836b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8370:	4d 01 d0                                        	add    r8,r10
    8373:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8378:	4d 01 d0                                        	add    r8,r10
    837b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8380:	4d 01 d0                                        	add    r8,r10
    8383:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8388:	4d 01 d0                                        	add    r8,r10
    838b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8390:	4d 01 d0                                        	add    r8,r10
    8393:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8398:	4d 01 d0                                        	add    r8,r10
    839b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    83a0:	4d 01 d0                                        	add    r8,r10
    83a3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    83a8:	4d 01 d0                                        	add    r8,r10
    83ab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    83b0:	4d 01 d0                                        	add    r8,r10
    83b3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    83b8:	4d 01 d0                                        	add    r8,r10
    83bb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    83c0:	4d 01 d0                                        	add    r8,r10
    83c3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    83c8:	4d 01 d0                                        	add    r8,r10
    83cb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    83d0:	4d 01 d0                                        	add    r8,r10
    83d3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    83d8:	4d 01 d0                                        	add    r8,r10
    83db:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    83e0:	4d 01 d0                                        	add    r8,r10
    83e3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    83e8:	4d 01 d0                                        	add    r8,r10
    83eb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    83f0:	4d 01 d0                                        	add    r8,r10
    83f3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    83f8:	4d 01 d0                                        	add    r8,r10
    83fb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8400:	4d 01 d0                                        	add    r8,r10
    8403:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8408:	4d 01 d0                                        	add    r8,r10
    840b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8410:	4d 01 d0                                        	add    r8,r10
    8413:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8418:	4d 01 d0                                        	add    r8,r10
    841b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8420:	4d 01 d0                                        	add    r8,r10
    8423:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8428:	4d 01 d0                                        	add    r8,r10
    842b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8430:	4d 01 d0                                        	add    r8,r10
    8433:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8438:	4d 01 d0                                        	add    r8,r10
    843b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8440:	4d 01 d0                                        	add    r8,r10
    8443:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8448:	4d 01 d0                                        	add    r8,r10
    844b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8450:	4d 01 d0                                        	add    r8,r10
    8453:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8458:	4d 01 d0                                        	add    r8,r10
    845b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8460:	4d 01 d0                                        	add    r8,r10
    8463:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8468:	4d 01 d0                                        	add    r8,r10
    846b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8470:	4d 01 d0                                        	add    r8,r10
    8473:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8478:	4d 01 d0                                        	add    r8,r10
    847b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8480:	4d 01 d0                                        	add    r8,r10
    8483:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8488:	4d 01 d0                                        	add    r8,r10
    848b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8490:	4d 01 d0                                        	add    r8,r10
    8493:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8498:	4d 01 d0                                        	add    r8,r10
    849b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    84a0:	4d 01 d0                                        	add    r8,r10
    84a3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    84a8:	4d 01 d0                                        	add    r8,r10
    84ab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    84b0:	4d 01 d0                                        	add    r8,r10
    84b3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    84b8:	4d 01 d0                                        	add    r8,r10
    84bb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    84c0:	4d 01 d0                                        	add    r8,r10
    84c3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    84c8:	4d 01 d0                                        	add    r8,r10
    84cb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    84d0:	4d 01 d0                                        	add    r8,r10
    84d3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    84d8:	4d 01 d0                                        	add    r8,r10
    84db:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    84e0:	4d 01 d0                                        	add    r8,r10
    84e3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    84e8:	4d 01 d0                                        	add    r8,r10
    84eb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    84f0:	4d 01 d0                                        	add    r8,r10
    84f3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    84f8:	4d 01 d0                                        	add    r8,r10
    84fb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8500:	4d 01 d0                                        	add    r8,r10
    8503:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8508:	4d 01 d0                                        	add    r8,r10
    850b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8510:	4d 01 d0                                        	add    r8,r10
    8513:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8518:	4d 01 d0                                        	add    r8,r10
    851b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8520:	4d 01 d0                                        	add    r8,r10
    8523:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8528:	4d 01 d0                                        	add    r8,r10
    852b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8530:	4d 01 d0                                        	add    r8,r10
    8533:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8538:	4d 01 d0                                        	add    r8,r10
    853b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8540:	4d 01 d0                                        	add    r8,r10
    8543:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8548:	4d 01 d0                                        	add    r8,r10
    854b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8550:	4d 01 d0                                        	add    r8,r10
    8553:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8558:	4d 01 d0                                        	add    r8,r10
    855b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8560:	4d 01 d0                                        	add    r8,r10
    8563:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8568:	4d 01 d0                                        	add    r8,r10
    856b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8570:	4d 01 d0                                        	add    r8,r10
    8573:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8578:	4d 01 d0                                        	add    r8,r10
    857b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8580:	4d 01 d0                                        	add    r8,r10
    8583:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8588:	4d 01 d0                                        	add    r8,r10
    858b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8590:	4d 01 d0                                        	add    r8,r10
    8593:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8598:	4d 01 d0                                        	add    r8,r10
    859b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    85a0:	4d 01 d0                                        	add    r8,r10
    85a3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    85a8:	4d 01 d0                                        	add    r8,r10
    85ab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    85b0:	4d 01 d0                                        	add    r8,r10
    85b3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    85b8:	4d 01 d0                                        	add    r8,r10
    85bb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    85c0:	4d 01 d0                                        	add    r8,r10
    85c3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    85c8:	4d 01 d0                                        	add    r8,r10
    85cb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    85d0:	4d 01 d0                                        	add    r8,r10
    85d3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    85d8:	4d 01 d0                                        	add    r8,r10
    85db:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    85e0:	4d 01 d0                                        	add    r8,r10
    85e3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    85e8:	4d 01 d0                                        	add    r8,r10
    85eb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    85f0:	4d 01 d0                                        	add    r8,r10
    85f3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    85f8:	4d 01 d0                                        	add    r8,r10
    85fb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8600:	4d 01 d0                                        	add    r8,r10
    8603:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8608:	4d 01 d0                                        	add    r8,r10
    860b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8610:	4d 01 d0                                        	add    r8,r10
    8613:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8618:	4d 01 d0                                        	add    r8,r10
    861b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8620:	4d 01 d0                                        	add    r8,r10
    8623:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8628:	4d 01 d0                                        	add    r8,r10
    862b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8630:	4d 01 d0                                        	add    r8,r10
    8633:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8638:	4d 01 d0                                        	add    r8,r10
    863b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8640:	4d 01 d0                                        	add    r8,r10
    8643:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8648:	4d 01 d0                                        	add    r8,r10
    864b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8650:	4d 01 d0                                        	add    r8,r10
    8653:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8658:	4d 01 d0                                        	add    r8,r10
    865b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8660:	4d 01 d0                                        	add    r8,r10
    8663:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8668:	4d 01 d0                                        	add    r8,r10
    866b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8670:	4d 01 d0                                        	add    r8,r10
    8673:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8678:	4d 01 d0                                        	add    r8,r10
    867b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8680:	4d 01 d0                                        	add    r8,r10
    8683:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8688:	4d 01 d0                                        	add    r8,r10
    868b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8690:	4d 01 d0                                        	add    r8,r10
    8693:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8698:	4d 01 d0                                        	add    r8,r10
    869b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    86a0:	4d 01 d0                                        	add    r8,r10
    86a3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    86a8:	4d 01 d0                                        	add    r8,r10
    86ab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    86b0:	4d 01 d0                                        	add    r8,r10
    86b3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    86b8:	4d 01 d0                                        	add    r8,r10
    86bb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    86c0:	4d 01 d0                                        	add    r8,r10
    86c3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    86c8:	4d 01 d0                                        	add    r8,r10
    86cb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    86d0:	4d 01 d0                                        	add    r8,r10
    86d3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    86d8:	4d 01 d0                                        	add    r8,r10
    86db:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    86e0:	4d 01 d0                                        	add    r8,r10
    86e3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    86e8:	4d 01 d0                                        	add    r8,r10
    86eb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    86f0:	4d 01 d0                                        	add    r8,r10
    86f3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    86f8:	4d 01 d0                                        	add    r8,r10
    86fb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8700:	4d 01 d0                                        	add    r8,r10
    8703:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8708:	4d 01 d0                                        	add    r8,r10
    870b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8710:	4d 01 d0                                        	add    r8,r10
    8713:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8718:	4d 01 d0                                        	add    r8,r10
    871b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8720:	4d 01 d0                                        	add    r8,r10
    8723:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8728:	4d 01 d0                                        	add    r8,r10
    872b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8730:	4d 01 d0                                        	add    r8,r10
    8733:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8738:	4d 01 d0                                        	add    r8,r10
    873b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8740:	4d 01 d0                                        	add    r8,r10
    8743:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8748:	4d 01 d0                                        	add    r8,r10
    874b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8750:	4d 01 d0                                        	add    r8,r10
    8753:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8758:	4d 01 d0                                        	add    r8,r10
    875b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8760:	4d 01 d0                                        	add    r8,r10
    8763:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8768:	4d 01 d0                                        	add    r8,r10
    876b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8770:	4d 01 d0                                        	add    r8,r10
    8773:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8778:	4d 01 d0                                        	add    r8,r10
    877b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8780:	4d 01 d0                                        	add    r8,r10
    8783:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8788:	4d 01 d0                                        	add    r8,r10
    878b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8790:	4d 01 d0                                        	add    r8,r10
    8793:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8798:	4d 01 d0                                        	add    r8,r10
    879b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    87a0:	4d 01 d0                                        	add    r8,r10
    87a3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    87a8:	4d 01 d0                                        	add    r8,r10
    87ab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    87b0:	4d 01 d0                                        	add    r8,r10
    87b3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    87b8:	4d 01 d0                                        	add    r8,r10
    87bb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    87c0:	4d 01 d0                                        	add    r8,r10
    87c3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    87c8:	4d 01 d0                                        	add    r8,r10
    87cb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    87d0:	4d 01 d0                                        	add    r8,r10
    87d3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    87d8:	4d 01 d0                                        	add    r8,r10
    87db:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    87e0:	4d 01 d0                                        	add    r8,r10
    87e3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    87e8:	4d 01 d0                                        	add    r8,r10
    87eb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    87f0:	4d 01 d0                                        	add    r8,r10
    87f3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    87f8:	4d 01 d0                                        	add    r8,r10
    87fb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8800:	4d 01 d0                                        	add    r8,r10
    8803:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8808:	4d 01 d0                                        	add    r8,r10
    880b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8810:	4d 01 d0                                        	add    r8,r10
    8813:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8818:	4d 01 d0                                        	add    r8,r10
    881b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8820:	4d 01 d0                                        	add    r8,r10
    8823:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8828:	4d 01 d0                                        	add    r8,r10
    882b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8830:	4d 01 d0                                        	add    r8,r10
    8833:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8838:	4d 01 d0                                        	add    r8,r10
    883b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8840:	4d 01 d0                                        	add    r8,r10
    8843:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8848:	4d 01 d0                                        	add    r8,r10
    884b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8850:	4d 01 d0                                        	add    r8,r10
    8853:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8858:	4d 01 d0                                        	add    r8,r10
    885b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8860:	4d 01 d0                                        	add    r8,r10
    8863:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8868:	4d 01 d0                                        	add    r8,r10
    886b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8870:	4d 01 d0                                        	add    r8,r10
    8873:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8878:	4d 01 d0                                        	add    r8,r10
    887b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8880:	4d 01 d0                                        	add    r8,r10
    8883:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8888:	4d 01 d0                                        	add    r8,r10
    888b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8890:	4d 01 d0                                        	add    r8,r10
    8893:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8898:	4d 01 d0                                        	add    r8,r10
    889b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    88a0:	4d 01 d0                                        	add    r8,r10
    88a3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    88a8:	4d 01 d0                                        	add    r8,r10
    88ab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    88b0:	4d 01 d0                                        	add    r8,r10
    88b3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    88b8:	4d 01 d0                                        	add    r8,r10
    88bb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    88c0:	4d 01 d0                                        	add    r8,r10
    88c3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    88c8:	4d 01 d0                                        	add    r8,r10
    88cb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    88d0:	4d 01 d0                                        	add    r8,r10
    88d3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    88d8:	4d 01 d0                                        	add    r8,r10
    88db:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    88e0:	4d 01 d0                                        	add    r8,r10
    88e3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    88e8:	4d 01 d0                                        	add    r8,r10
    88eb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    88f0:	4d 01 d0                                        	add    r8,r10
    88f3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    88f8:	4d 01 d0                                        	add    r8,r10
    88fb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8900:	4d 01 d0                                        	add    r8,r10
    8903:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8908:	4d 01 d0                                        	add    r8,r10
    890b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8910:	4d 01 d0                                        	add    r8,r10
    8913:	41 f6 c1 01                                     	test   r9b,0x1
    8917:	74 04                                           	je     891d <join_6>
    8919:	49 83 f0 01                                     	xor    r8,0x1

000000000000891d <join_6>:
    891d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8922:	4d 01 d0                                        	add    r8,r10
    8925:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    892a:	4d 01 d0                                        	add    r8,r10
    892d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8932:	4d 01 d0                                        	add    r8,r10
    8935:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    893a:	4d 01 d0                                        	add    r8,r10
    893d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8942:	4d 01 d0                                        	add    r8,r10
    8945:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    894a:	4d 01 d0                                        	add    r8,r10
    894d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8952:	4d 01 d0                                        	add    r8,r10
    8955:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    895a:	4d 01 d0                                        	add    r8,r10
    895d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8962:	4d 01 d0                                        	add    r8,r10
    8965:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    896a:	4d 01 d0                                        	add    r8,r10
    896d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8972:	4d 01 d0                                        	add    r8,r10
    8975:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    897a:	4d 01 d0                                        	add    r8,r10
    897d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8982:	4d 01 d0                                        	add    r8,r10
    8985:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    898a:	4d 01 d0                                        	add    r8,r10
    898d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8992:	4d 01 d0                                        	add    r8,r10
    8995:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    899a:	4d 01 d0                                        	add    r8,r10
    899d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    89a2:	4d 01 d0                                        	add    r8,r10
    89a5:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    89aa:	4d 01 d0                                        	add    r8,r10
    89ad:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    89b2:	4d 01 d0                                        	add    r8,r10
    89b5:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    89ba:	4d 01 d0                                        	add    r8,r10
    89bd:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    89c2:	4d 01 d0                                        	add    r8,r10
    89c5:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    89ca:	4d 01 d0                                        	add    r8,r10
    89cd:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    89d2:	4d 01 d0                                        	add    r8,r10
    89d5:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    89da:	4d 01 d0                                        	add    r8,r10
    89dd:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    89e2:	4d 01 d0                                        	add    r8,r10
    89e5:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    89ea:	4d 01 d0                                        	add    r8,r10
    89ed:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    89f2:	4d 01 d0                                        	add    r8,r10
    89f5:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    89fa:	4d 01 d0                                        	add    r8,r10
    89fd:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8a02:	4d 01 d0                                        	add    r8,r10
    8a05:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8a0a:	4d 01 d0                                        	add    r8,r10
    8a0d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8a12:	4d 01 d0                                        	add    r8,r10
    8a15:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8a1a:	4d 01 d0                                        	add    r8,r10
    8a1d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8a22:	4d 01 d0                                        	add    r8,r10
    8a25:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8a2a:	4d 01 d0                                        	add    r8,r10
    8a2d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8a32:	4d 01 d0                                        	add    r8,r10
    8a35:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8a3a:	4d 01 d0                                        	add    r8,r10
    8a3d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8a42:	4d 01 d0                                        	add    r8,r10
    8a45:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8a4a:	4d 01 d0                                        	add    r8,r10
    8a4d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8a52:	4d 01 d0                                        	add    r8,r10
    8a55:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8a5a:	4d 01 d0                                        	add    r8,r10
    8a5d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8a62:	4d 01 d0                                        	add    r8,r10
    8a65:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8a6a:	4d 01 d0                                        	add    r8,r10
    8a6d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8a72:	4d 01 d0                                        	add    r8,r10
    8a75:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8a7a:	4d 01 d0                                        	add    r8,r10
    8a7d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8a82:	4d 01 d0                                        	add    r8,r10
    8a85:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8a8a:	4d 01 d0                                        	add    r8,r10
    8a8d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8a92:	4d 01 d0                                        	add    r8,r10
    8a95:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8a9a:	4d 01 d0                                        	add    r8,r10
    8a9d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8aa2:	4d 01 d0                                        	add    r8,r10
    8aa5:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8aaa:	4d 01 d0                                        	add    r8,r10
    8aad:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8ab2:	4d 01 d0                                        	add    r8,r10
    8ab5:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8aba:	4d 01 d0                                        	add    r8,r10
    8abd:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8ac2:	4d 01 d0                                        	add    r8,r10
    8ac5:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8aca:	4d 01 d0                                        	add    r8,r10
    8acd:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8ad2:	4d 01 d0                                        	add    r8,r10
    8ad5:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8ada:	4d 01 d0                                        	add    r8,r10
    8add:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8ae2:	4d 01 d0                                        	add    r8,r10
    8ae5:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8aea:	4d 01 d0                                        	add    r8,r10
    8aed:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8af2:	4d 01 d0                                        	add    r8,r10
    8af5:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8afa:	4d 01 d0                                        	add    r8,r10
    8afd:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8b02:	4d 01 d0                                        	add    r8,r10
    8b05:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8b0a:	4d 01 d0                                        	add    r8,r10
    8b0d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8b12:	4d 01 d0                                        	add    r8,r10
    8b15:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8b1a:	4d 01 d0                                        	add    r8,r10
    8b1d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8b22:	4d 01 d0                                        	add    r8,r10
    8b25:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8b2a:	4d 01 d0                                        	add    r8,r10
    8b2d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8b32:	4d 01 d0                                        	add    r8,r10
    8b35:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8b3a:	4d 01 d0                                        	add    r8,r10
    8b3d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8b42:	4d 01 d0                                        	add    r8,r10
    8b45:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8b4a:	4d 01 d0                                        	add    r8,r10
    8b4d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8b52:	4d 01 d0                                        	add    r8,r10
    8b55:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8b5a:	4d 01 d0                                        	add    r8,r10
    8b5d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8b62:	4d 01 d0                                        	add    r8,r10
    8b65:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8b6a:	4d 01 d0                                        	add    r8,r10
    8b6d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8b72:	4d 01 d0                                        	add    r8,r10
    8b75:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8b7a:	4d 01 d0                                        	add    r8,r10
    8b7d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8b82:	4d 01 d0                                        	add    r8,r10
    8b85:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8b8a:	4d 01 d0                                        	add    r8,r10
    8b8d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8b92:	4d 01 d0                                        	add    r8,r10
    8b95:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8b9a:	4d 01 d0                                        	add    r8,r10
    8b9d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8ba2:	4d 01 d0                                        	add    r8,r10
    8ba5:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8baa:	4d 01 d0                                        	add    r8,r10
    8bad:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8bb2:	4d 01 d0                                        	add    r8,r10
    8bb5:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8bba:	4d 01 d0                                        	add    r8,r10
    8bbd:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8bc2:	4d 01 d0                                        	add    r8,r10
    8bc5:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8bca:	4d 01 d0                                        	add    r8,r10
    8bcd:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8bd2:	4d 01 d0                                        	add    r8,r10
    8bd5:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8bda:	4d 01 d0                                        	add    r8,r10
    8bdd:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8be2:	4d 01 d0                                        	add    r8,r10
    8be5:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8bea:	4d 01 d0                                        	add    r8,r10
    8bed:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8bf2:	4d 01 d0                                        	add    r8,r10
    8bf5:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8bfa:	4d 01 d0                                        	add    r8,r10
    8bfd:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8c02:	4d 01 d0                                        	add    r8,r10
    8c05:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8c0a:	4d 01 d0                                        	add    r8,r10
    8c0d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8c12:	4d 01 d0                                        	add    r8,r10
    8c15:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8c1a:	4d 01 d0                                        	add    r8,r10
    8c1d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8c22:	4d 01 d0                                        	add    r8,r10
    8c25:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8c2a:	4d 01 d0                                        	add    r8,r10
    8c2d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8c32:	4d 01 d0                                        	add    r8,r10
    8c35:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8c3a:	4d 01 d0                                        	add    r8,r10
    8c3d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8c42:	4d 01 d0                                        	add    r8,r10
    8c45:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8c4a:	4d 01 d0                                        	add    r8,r10
    8c4d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8c52:	4d 01 d0                                        	add    r8,r10
    8c55:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8c5a:	4d 01 d0                                        	add    r8,r10
    8c5d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8c62:	4d 01 d0                                        	add    r8,r10
    8c65:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8c6a:	4d 01 d0                                        	add    r8,r10
    8c6d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8c72:	4d 01 d0                                        	add    r8,r10
    8c75:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8c7a:	4d 01 d0                                        	add    r8,r10
    8c7d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8c82:	4d 01 d0                                        	add    r8,r10
    8c85:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8c8a:	4d 01 d0                                        	add    r8,r10
    8c8d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8c92:	4d 01 d0                                        	add    r8,r10
    8c95:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8c9a:	4d 01 d0                                        	add    r8,r10
    8c9d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8ca2:	4d 01 d0                                        	add    r8,r10
    8ca5:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8caa:	4d 01 d0                                        	add    r8,r10
    8cad:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8cb2:	4d 01 d0                                        	add    r8,r10
    8cb5:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8cba:	4d 01 d0                                        	add    r8,r10
    8cbd:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8cc2:	4d 01 d0                                        	add    r8,r10
    8cc5:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8cca:	4d 01 d0                                        	add    r8,r10
    8ccd:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8cd2:	4d 01 d0                                        	add    r8,r10
    8cd5:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8cda:	4d 01 d0                                        	add    r8,r10
    8cdd:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8ce2:	4d 01 d0                                        	add    r8,r10
    8ce5:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8cea:	4d 01 d0                                        	add    r8,r10
    8ced:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8cf2:	4d 01 d0                                        	add    r8,r10
    8cf5:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8cfa:	4d 01 d0                                        	add    r8,r10
    8cfd:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8d02:	4d 01 d0                                        	add    r8,r10
    8d05:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8d0a:	4d 01 d0                                        	add    r8,r10
    8d0d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8d12:	4d 01 d0                                        	add    r8,r10
    8d15:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8d1a:	4d 01 d0                                        	add    r8,r10
    8d1d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8d22:	4d 01 d0                                        	add    r8,r10
    8d25:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8d2a:	4d 01 d0                                        	add    r8,r10
    8d2d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8d32:	4d 01 d0                                        	add    r8,r10
    8d35:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8d3a:	4d 01 d0                                        	add    r8,r10
    8d3d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8d42:	4d 01 d0                                        	add    r8,r10
    8d45:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8d4a:	4d 01 d0                                        	add    r8,r10
    8d4d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8d52:	4d 01 d0                                        	add    r8,r10
    8d55:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8d5a:	4d 01 d0                                        	add    r8,r10
    8d5d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8d62:	4d 01 d0                                        	add    r8,r10
    8d65:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8d6a:	4d 01 d0                                        	add    r8,r10
    8d6d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8d72:	4d 01 d0                                        	add    r8,r10
    8d75:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8d7a:	4d 01 d0                                        	add    r8,r10
    8d7d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8d82:	4d 01 d0                                        	add    r8,r10
    8d85:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8d8a:	4d 01 d0                                        	add    r8,r10
    8d8d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8d92:	4d 01 d0                                        	add    r8,r10
    8d95:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8d9a:	4d 01 d0                                        	add    r8,r10
    8d9d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8da2:	4d 01 d0                                        	add    r8,r10
    8da5:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8daa:	4d 01 d0                                        	add    r8,r10
    8dad:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8db2:	4d 01 d0                                        	add    r8,r10
    8db5:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8dba:	4d 01 d0                                        	add    r8,r10
    8dbd:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8dc2:	4d 01 d0                                        	add    r8,r10
    8dc5:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8dca:	4d 01 d0                                        	add    r8,r10
    8dcd:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8dd2:	4d 01 d0                                        	add    r8,r10
    8dd5:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8dda:	4d 01 d0                                        	add    r8,r10
    8ddd:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8de2:	4d 01 d0                                        	add    r8,r10
    8de5:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8dea:	4d 01 d0                                        	add    r8,r10
    8ded:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8df2:	4d 01 d0                                        	add    r8,r10
    8df5:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8dfa:	4d 01 d0                                        	add    r8,r10
    8dfd:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8e02:	4d 01 d0                                        	add    r8,r10
    8e05:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8e0a:	4d 01 d0                                        	add    r8,r10
    8e0d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8e12:	4d 01 d0                                        	add    r8,r10
    8e15:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8e1a:	4d 01 d0                                        	add    r8,r10
    8e1d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8e22:	4d 01 d0                                        	add    r8,r10
    8e25:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8e2a:	4d 01 d0                                        	add    r8,r10
    8e2d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8e32:	4d 01 d0                                        	add    r8,r10
    8e35:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8e3a:	4d 01 d0                                        	add    r8,r10
    8e3d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8e42:	4d 01 d0                                        	add    r8,r10
    8e45:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8e4a:	4d 01 d0                                        	add    r8,r10
    8e4d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8e52:	4d 01 d0                                        	add    r8,r10
    8e55:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8e5a:	4d 01 d0                                        	add    r8,r10
    8e5d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8e62:	4d 01 d0                                        	add    r8,r10
    8e65:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8e6a:	4d 01 d0                                        	add    r8,r10
    8e6d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8e72:	4d 01 d0                                        	add    r8,r10
    8e75:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8e7a:	4d 01 d0                                        	add    r8,r10
    8e7d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8e82:	4d 01 d0                                        	add    r8,r10
    8e85:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8e8a:	4d 01 d0                                        	add    r8,r10
    8e8d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8e92:	4d 01 d0                                        	add    r8,r10
    8e95:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8e9a:	4d 01 d0                                        	add    r8,r10
    8e9d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8ea2:	4d 01 d0                                        	add    r8,r10
    8ea5:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8eaa:	4d 01 d0                                        	add    r8,r10
    8ead:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8eb2:	4d 01 d0                                        	add    r8,r10
    8eb5:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8eba:	4d 01 d0                                        	add    r8,r10
    8ebd:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8ec2:	4d 01 d0                                        	add    r8,r10
    8ec5:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8eca:	4d 01 d0                                        	add    r8,r10
    8ecd:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8ed2:	4d 01 d0                                        	add    r8,r10
    8ed5:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8eda:	4d 01 d0                                        	add    r8,r10
    8edd:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8ee2:	4d 01 d0                                        	add    r8,r10
    8ee5:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8eea:	4d 01 d0                                        	add    r8,r10
    8eed:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8ef2:	4d 01 d0                                        	add    r8,r10
    8ef5:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8efa:	4d 01 d0                                        	add    r8,r10
    8efd:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8f02:	4d 01 d0                                        	add    r8,r10
    8f05:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8f0a:	4d 01 d0                                        	add    r8,r10
    8f0d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8f12:	4d 01 d0                                        	add    r8,r10
    8f15:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8f1a:	4d 01 d0                                        	add    r8,r10
    8f1d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8f22:	4d 01 d0                                        	add    r8,r10
    8f25:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8f2a:	4d 01 d0                                        	add    r8,r10
    8f2d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8f32:	4d 01 d0                                        	add    r8,r10
    8f35:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8f3a:	4d 01 d0                                        	add    r8,r10
    8f3d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8f42:	4d 01 d0                                        	add    r8,r10
    8f45:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8f4a:	4d 01 d0                                        	add    r8,r10
    8f4d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8f52:	4d 01 d0                                        	add    r8,r10
    8f55:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8f5a:	4d 01 d0                                        	add    r8,r10
    8f5d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8f62:	4d 01 d0                                        	add    r8,r10
    8f65:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8f6a:	4d 01 d0                                        	add    r8,r10
    8f6d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8f72:	4d 01 d0                                        	add    r8,r10
    8f75:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8f7a:	4d 01 d0                                        	add    r8,r10
    8f7d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8f82:	4d 01 d0                                        	add    r8,r10
    8f85:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8f8a:	4d 01 d0                                        	add    r8,r10
    8f8d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8f92:	4d 01 d0                                        	add    r8,r10
    8f95:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8f9a:	4d 01 d0                                        	add    r8,r10
    8f9d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8fa2:	4d 01 d0                                        	add    r8,r10
    8fa5:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8faa:	4d 01 d0                                        	add    r8,r10
    8fad:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8fb2:	4d 01 d0                                        	add    r8,r10
    8fb5:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8fba:	4d 01 d0                                        	add    r8,r10
    8fbd:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8fc2:	4d 01 d0                                        	add    r8,r10
    8fc5:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8fca:	4d 01 d0                                        	add    r8,r10
    8fcd:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8fd2:	4d 01 d0                                        	add    r8,r10
    8fd5:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8fda:	4d 01 d0                                        	add    r8,r10
    8fdd:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8fe2:	4d 01 d0                                        	add    r8,r10
    8fe5:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8fea:	4d 01 d0                                        	add    r8,r10
    8fed:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8ff2:	4d 01 d0                                        	add    r8,r10
    8ff5:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8ffa:	4d 01 d0                                        	add    r8,r10
    8ffd:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9002:	4d 01 d0                                        	add    r8,r10
    9005:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    900a:	4d 01 d0                                        	add    r8,r10
    900d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9012:	4d 01 d0                                        	add    r8,r10
    9015:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    901a:	4d 01 d0                                        	add    r8,r10
    901d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9022:	4d 01 d0                                        	add    r8,r10
    9025:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    902a:	4d 01 d0                                        	add    r8,r10
    902d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9032:	4d 01 d0                                        	add    r8,r10
    9035:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    903a:	4d 01 d0                                        	add    r8,r10
    903d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9042:	4d 01 d0                                        	add    r8,r10
    9045:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    904a:	4d 01 d0                                        	add    r8,r10
    904d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9052:	4d 01 d0                                        	add    r8,r10
    9055:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    905a:	4d 01 d0                                        	add    r8,r10
    905d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9062:	4d 01 d0                                        	add    r8,r10
    9065:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    906a:	4d 01 d0                                        	add    r8,r10
    906d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9072:	4d 01 d0                                        	add    r8,r10
    9075:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    907a:	4d 01 d0                                        	add    r8,r10
    907d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9082:	4d 01 d0                                        	add    r8,r10
    9085:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    908a:	4d 01 d0                                        	add    r8,r10
    908d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9092:	4d 01 d0                                        	add    r8,r10
    9095:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    909a:	4d 01 d0                                        	add    r8,r10
    909d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    90a2:	4d 01 d0                                        	add    r8,r10
    90a5:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    90aa:	4d 01 d0                                        	add    r8,r10
    90ad:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    90b2:	4d 01 d0                                        	add    r8,r10
    90b5:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    90ba:	4d 01 d0                                        	add    r8,r10
    90bd:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    90c2:	4d 01 d0                                        	add    r8,r10
    90c5:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    90ca:	4d 01 d0                                        	add    r8,r10
    90cd:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    90d2:	4d 01 d0                                        	add    r8,r10
    90d5:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    90da:	4d 01 d0                                        	add    r8,r10
    90dd:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    90e2:	4d 01 d0                                        	add    r8,r10
    90e5:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    90ea:	4d 01 d0                                        	add    r8,r10
    90ed:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    90f2:	4d 01 d0                                        	add    r8,r10
    90f5:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    90fa:	4d 01 d0                                        	add    r8,r10
    90fd:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9102:	4d 01 d0                                        	add    r8,r10
    9105:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    910a:	4d 01 d0                                        	add    r8,r10
    910d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9112:	4d 01 d0                                        	add    r8,r10
    9115:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    911a:	4d 01 d0                                        	add    r8,r10
    911d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9122:	4d 01 d0                                        	add    r8,r10
    9125:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    912a:	4d 01 d0                                        	add    r8,r10
    912d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9132:	4d 01 d0                                        	add    r8,r10
    9135:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    913a:	4d 01 d0                                        	add    r8,r10
    913d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9142:	4d 01 d0                                        	add    r8,r10
    9145:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    914a:	4d 01 d0                                        	add    r8,r10
    914d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9152:	4d 01 d0                                        	add    r8,r10
    9155:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    915a:	4d 01 d0                                        	add    r8,r10
    915d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9162:	4d 01 d0                                        	add    r8,r10
    9165:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    916a:	4d 01 d0                                        	add    r8,r10
    916d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9172:	4d 01 d0                                        	add    r8,r10
    9175:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    917a:	4d 01 d0                                        	add    r8,r10
    917d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9182:	4d 01 d0                                        	add    r8,r10
    9185:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    918a:	4d 01 d0                                        	add    r8,r10
    918d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9192:	4d 01 d0                                        	add    r8,r10
    9195:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    919a:	4d 01 d0                                        	add    r8,r10
    919d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    91a2:	4d 01 d0                                        	add    r8,r10
    91a5:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    91aa:	4d 01 d0                                        	add    r8,r10
    91ad:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    91b2:	4d 01 d0                                        	add    r8,r10
    91b5:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    91ba:	4d 01 d0                                        	add    r8,r10
    91bd:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    91c2:	4d 01 d0                                        	add    r8,r10
    91c5:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    91ca:	4d 01 d0                                        	add    r8,r10
    91cd:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    91d2:	4d 01 d0                                        	add    r8,r10
    91d5:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    91da:	4d 01 d0                                        	add    r8,r10
    91dd:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    91e2:	4d 01 d0                                        	add    r8,r10
    91e5:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    91ea:	4d 01 d0                                        	add    r8,r10
    91ed:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    91f2:	4d 01 d0                                        	add    r8,r10
    91f5:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    91fa:	4d 01 d0                                        	add    r8,r10
    91fd:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9202:	4d 01 d0                                        	add    r8,r10
    9205:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    920a:	4d 01 d0                                        	add    r8,r10
    920d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9212:	4d 01 d0                                        	add    r8,r10
    9215:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    921a:	4d 01 d0                                        	add    r8,r10
    921d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9222:	4d 01 d0                                        	add    r8,r10
    9225:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    922a:	4d 01 d0                                        	add    r8,r10
    922d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9232:	4d 01 d0                                        	add    r8,r10
    9235:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    923a:	4d 01 d0                                        	add    r8,r10
    923d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9242:	4d 01 d0                                        	add    r8,r10
    9245:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    924a:	4d 01 d0                                        	add    r8,r10
    924d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9252:	4d 01 d0                                        	add    r8,r10
    9255:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    925a:	4d 01 d0                                        	add    r8,r10
    925d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9262:	4d 01 d0                                        	add    r8,r10
    9265:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    926a:	4d 01 d0                                        	add    r8,r10
    926d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9272:	4d 01 d0                                        	add    r8,r10
    9275:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    927a:	4d 01 d0                                        	add    r8,r10
    927d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9282:	4d 01 d0                                        	add    r8,r10
    9285:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    928a:	4d 01 d0                                        	add    r8,r10
    928d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9292:	4d 01 d0                                        	add    r8,r10
    9295:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    929a:	4d 01 d0                                        	add    r8,r10
    929d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    92a2:	4d 01 d0                                        	add    r8,r10
    92a5:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    92aa:	4d 01 d0                                        	add    r8,r10
    92ad:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    92b2:	4d 01 d0                                        	add    r8,r10
    92b5:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    92ba:	4d 01 d0                                        	add    r8,r10
    92bd:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    92c2:	4d 01 d0                                        	add    r8,r10
    92c5:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    92ca:	4d 01 d0                                        	add    r8,r10
    92cd:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    92d2:	4d 01 d0                                        	add    r8,r10
    92d5:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    92da:	4d 01 d0                                        	add    r8,r10
    92dd:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    92e2:	4d 01 d0                                        	add    r8,r10
    92e5:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    92ea:	4d 01 d0                                        	add    r8,r10
    92ed:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    92f2:	4d 01 d0                                        	add    r8,r10
    92f5:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    92fa:	4d 01 d0                                        	add    r8,r10
    92fd:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9302:	4d 01 d0                                        	add    r8,r10
    9305:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    930a:	4d 01 d0                                        	add    r8,r10
    930d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9312:	4d 01 d0                                        	add    r8,r10
    9315:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    931a:	4d 01 d0                                        	add    r8,r10
    931d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9322:	4d 01 d0                                        	add    r8,r10
    9325:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    932a:	4d 01 d0                                        	add    r8,r10
    932d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9332:	4d 01 d0                                        	add    r8,r10
    9335:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    933a:	4d 01 d0                                        	add    r8,r10
    933d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9342:	4d 01 d0                                        	add    r8,r10
    9345:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    934a:	4d 01 d0                                        	add    r8,r10
    934d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9352:	4d 01 d0                                        	add    r8,r10
    9355:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    935a:	4d 01 d0                                        	add    r8,r10
    935d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9362:	4d 01 d0                                        	add    r8,r10
    9365:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    936a:	4d 01 d0                                        	add    r8,r10
    936d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9372:	4d 01 d0                                        	add    r8,r10
    9375:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    937a:	4d 01 d0                                        	add    r8,r10
    937d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9382:	4d 01 d0                                        	add    r8,r10
    9385:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    938a:	4d 01 d0                                        	add    r8,r10
    938d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9392:	4d 01 d0                                        	add    r8,r10
    9395:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    939a:	4d 01 d0                                        	add    r8,r10
    939d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    93a2:	4d 01 d0                                        	add    r8,r10
    93a5:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    93aa:	4d 01 d0                                        	add    r8,r10
    93ad:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    93b2:	4d 01 d0                                        	add    r8,r10
    93b5:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    93ba:	4d 01 d0                                        	add    r8,r10
    93bd:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    93c2:	4d 01 d0                                        	add    r8,r10
    93c5:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    93ca:	4d 01 d0                                        	add    r8,r10
    93cd:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    93d2:	4d 01 d0                                        	add    r8,r10
    93d5:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    93da:	4d 01 d0                                        	add    r8,r10
    93dd:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    93e2:	4d 01 d0                                        	add    r8,r10
    93e5:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    93ea:	4d 01 d0                                        	add    r8,r10
    93ed:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    93f2:	4d 01 d0                                        	add    r8,r10
    93f5:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    93fa:	4d 01 d0                                        	add    r8,r10
    93fd:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9402:	4d 01 d0                                        	add    r8,r10
    9405:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    940a:	4d 01 d0                                        	add    r8,r10
    940d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9412:	4d 01 d0                                        	add    r8,r10
    9415:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    941a:	4d 01 d0                                        	add    r8,r10
    941d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9422:	4d 01 d0                                        	add    r8,r10
    9425:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    942a:	4d 01 d0                                        	add    r8,r10
    942d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9432:	4d 01 d0                                        	add    r8,r10
    9435:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    943a:	4d 01 d0                                        	add    r8,r10
    943d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9442:	4d 01 d0                                        	add    r8,r10
    9445:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    944a:	4d 01 d0                                        	add    r8,r10
    944d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9452:	4d 01 d0                                        	add    r8,r10
    9455:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    945a:	4d 01 d0                                        	add    r8,r10
    945d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9462:	4d 01 d0                                        	add    r8,r10
    9465:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    946a:	4d 01 d0                                        	add    r8,r10
    946d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9472:	4d 01 d0                                        	add    r8,r10
    9475:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    947a:	4d 01 d0                                        	add    r8,r10
    947d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9482:	4d 01 d0                                        	add    r8,r10
    9485:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    948a:	4d 01 d0                                        	add    r8,r10
    948d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9492:	4d 01 d0                                        	add    r8,r10
    9495:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    949a:	4d 01 d0                                        	add    r8,r10
    949d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    94a2:	4d 01 d0                                        	add    r8,r10
    94a5:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    94aa:	4d 01 d0                                        	add    r8,r10
    94ad:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    94b2:	4d 01 d0                                        	add    r8,r10
    94b5:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    94ba:	4d 01 d0                                        	add    r8,r10
    94bd:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    94c2:	4d 01 d0                                        	add    r8,r10
    94c5:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    94ca:	4d 01 d0                                        	add    r8,r10
    94cd:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    94d2:	4d 01 d0                                        	add    r8,r10
    94d5:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    94da:	4d 01 d0                                        	add    r8,r10
    94dd:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    94e2:	4d 01 d0                                        	add    r8,r10
    94e5:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    94ea:	4d 01 d0                                        	add    r8,r10
    94ed:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    94f2:	4d 01 d0                                        	add    r8,r10
    94f5:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    94fa:	4d 01 d0                                        	add    r8,r10
    94fd:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9502:	4d 01 d0                                        	add    r8,r10
    9505:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    950a:	4d 01 d0                                        	add    r8,r10
    950d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9512:	4d 01 d0                                        	add    r8,r10
    9515:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    951a:	4d 01 d0                                        	add    r8,r10
    951d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9522:	4d 01 d0                                        	add    r8,r10
    9525:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    952a:	4d 01 d0                                        	add    r8,r10
    952d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9532:	4d 01 d0                                        	add    r8,r10
    9535:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    953a:	4d 01 d0                                        	add    r8,r10
    953d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9542:	4d 01 d0                                        	add    r8,r10
    9545:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    954a:	4d 01 d0                                        	add    r8,r10
    954d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9552:	4d 01 d0                                        	add    r8,r10
    9555:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    955a:	4d 01 d0                                        	add    r8,r10
    955d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9562:	4d 01 d0                                        	add    r8,r10
    9565:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    956a:	4d 01 d0                                        	add    r8,r10
    956d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9572:	4d 01 d0                                        	add    r8,r10
    9575:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    957a:	4d 01 d0                                        	add    r8,r10
    957d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9582:	4d 01 d0                                        	add    r8,r10
    9585:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    958a:	4d 01 d0                                        	add    r8,r10
    958d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9592:	4d 01 d0                                        	add    r8,r10
    9595:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    959a:	4d 01 d0                                        	add    r8,r10
    959d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    95a2:	4d 01 d0                                        	add    r8,r10
    95a5:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    95aa:	4d 01 d0                                        	add    r8,r10
    95ad:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    95b2:	4d 01 d0                                        	add    r8,r10
    95b5:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    95ba:	4d 01 d0                                        	add    r8,r10
    95bd:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    95c2:	4d 01 d0                                        	add    r8,r10
    95c5:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    95ca:	4d 01 d0                                        	add    r8,r10
    95cd:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    95d2:	4d 01 d0                                        	add    r8,r10
    95d5:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    95da:	4d 01 d0                                        	add    r8,r10
    95dd:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    95e2:	4d 01 d0                                        	add    r8,r10
    95e5:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    95ea:	4d 01 d0                                        	add    r8,r10
    95ed:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    95f2:	4d 01 d0                                        	add    r8,r10
    95f5:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    95fa:	4d 01 d0                                        	add    r8,r10
    95fd:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9602:	4d 01 d0                                        	add    r8,r10
    9605:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    960a:	4d 01 d0                                        	add    r8,r10
    960d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9612:	4d 01 d0                                        	add    r8,r10
    9615:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    961a:	4d 01 d0                                        	add    r8,r10
    961d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9622:	4d 01 d0                                        	add    r8,r10
    9625:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    962a:	4d 01 d0                                        	add    r8,r10
    962d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9632:	4d 01 d0                                        	add    r8,r10
    9635:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    963a:	4d 01 d0                                        	add    r8,r10
    963d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9642:	4d 01 d0                                        	add    r8,r10
    9645:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    964a:	4d 01 d0                                        	add    r8,r10
    964d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9652:	4d 01 d0                                        	add    r8,r10
    9655:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    965a:	4d 01 d0                                        	add    r8,r10
    965d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9662:	4d 01 d0                                        	add    r8,r10
    9665:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    966a:	4d 01 d0                                        	add    r8,r10
    966d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9672:	4d 01 d0                                        	add    r8,r10
    9675:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    967a:	4d 01 d0                                        	add    r8,r10
    967d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9682:	4d 01 d0                                        	add    r8,r10
    9685:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    968a:	4d 01 d0                                        	add    r8,r10
    968d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9692:	4d 01 d0                                        	add    r8,r10
    9695:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    969a:	4d 01 d0                                        	add    r8,r10
    969d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    96a2:	4d 01 d0                                        	add    r8,r10
    96a5:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    96aa:	4d 01 d0                                        	add    r8,r10
    96ad:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    96b2:	4d 01 d0                                        	add    r8,r10
    96b5:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    96ba:	4d 01 d0                                        	add    r8,r10
    96bd:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    96c2:	4d 01 d0                                        	add    r8,r10
    96c5:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    96ca:	4d 01 d0                                        	add    r8,r10
    96cd:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    96d2:	4d 01 d0                                        	add    r8,r10
    96d5:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    96da:	4d 01 d0                                        	add    r8,r10
    96dd:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    96e2:	4d 01 d0                                        	add    r8,r10
    96e5:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    96ea:	4d 01 d0                                        	add    r8,r10
    96ed:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    96f2:	4d 01 d0                                        	add    r8,r10
    96f5:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    96fa:	4d 01 d0                                        	add    r8,r10
    96fd:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9702:	4d 01 d0                                        	add    r8,r10
    9705:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    970a:	4d 01 d0                                        	add    r8,r10
    970d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9712:	4d 01 d0                                        	add    r8,r10
    9715:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    971a:	4d 01 d0                                        	add    r8,r10
    971d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9722:	4d 01 d0                                        	add    r8,r10
    9725:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    972a:	4d 01 d0                                        	add    r8,r10
    972d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9732:	4d 01 d0                                        	add    r8,r10
    9735:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    973a:	4d 01 d0                                        	add    r8,r10
    973d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9742:	4d 01 d0                                        	add    r8,r10
    9745:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    974a:	4d 01 d0                                        	add    r8,r10
    974d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9752:	4d 01 d0                                        	add    r8,r10
    9755:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    975a:	4d 01 d0                                        	add    r8,r10
    975d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9762:	4d 01 d0                                        	add    r8,r10
    9765:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    976a:	4d 01 d0                                        	add    r8,r10
    976d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9772:	4d 01 d0                                        	add    r8,r10
    9775:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    977a:	4d 01 d0                                        	add    r8,r10
    977d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9782:	4d 01 d0                                        	add    r8,r10
    9785:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    978a:	4d 01 d0                                        	add    r8,r10
    978d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9792:	4d 01 d0                                        	add    r8,r10
    9795:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    979a:	4d 01 d0                                        	add    r8,r10
    979d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    97a2:	4d 01 d0                                        	add    r8,r10
    97a5:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    97aa:	4d 01 d0                                        	add    r8,r10
    97ad:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    97b2:	4d 01 d0                                        	add    r8,r10
    97b5:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    97ba:	4d 01 d0                                        	add    r8,r10
    97bd:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    97c2:	4d 01 d0                                        	add    r8,r10
    97c5:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    97ca:	4d 01 d0                                        	add    r8,r10
    97cd:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    97d2:	4d 01 d0                                        	add    r8,r10
    97d5:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    97da:	4d 01 d0                                        	add    r8,r10
    97dd:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    97e2:	4d 01 d0                                        	add    r8,r10
    97e5:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    97ea:	4d 01 d0                                        	add    r8,r10
    97ed:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    97f2:	4d 01 d0                                        	add    r8,r10
    97f5:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    97fa:	4d 01 d0                                        	add    r8,r10
    97fd:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9802:	4d 01 d0                                        	add    r8,r10
    9805:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    980a:	4d 01 d0                                        	add    r8,r10
    980d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9812:	4d 01 d0                                        	add    r8,r10
    9815:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    981a:	4d 01 d0                                        	add    r8,r10
    981d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9822:	4d 01 d0                                        	add    r8,r10
    9825:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    982a:	4d 01 d0                                        	add    r8,r10
    982d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9832:	4d 01 d0                                        	add    r8,r10
    9835:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    983a:	4d 01 d0                                        	add    r8,r10
    983d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9842:	4d 01 d0                                        	add    r8,r10
    9845:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    984a:	4d 01 d0                                        	add    r8,r10
    984d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9852:	4d 01 d0                                        	add    r8,r10
    9855:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    985a:	4d 01 d0                                        	add    r8,r10
    985d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9862:	4d 01 d0                                        	add    r8,r10
    9865:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    986a:	4d 01 d0                                        	add    r8,r10
    986d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9872:	4d 01 d0                                        	add    r8,r10
    9875:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    987a:	4d 01 d0                                        	add    r8,r10
    987d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9882:	4d 01 d0                                        	add    r8,r10
    9885:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    988a:	4d 01 d0                                        	add    r8,r10
    988d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9892:	4d 01 d0                                        	add    r8,r10
    9895:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    989a:	4d 01 d0                                        	add    r8,r10
    989d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    98a2:	4d 01 d0                                        	add    r8,r10
    98a5:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    98aa:	4d 01 d0                                        	add    r8,r10
    98ad:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    98b2:	4d 01 d0                                        	add    r8,r10
    98b5:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    98ba:	4d 01 d0                                        	add    r8,r10
    98bd:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    98c2:	4d 01 d0                                        	add    r8,r10
    98c5:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    98ca:	4d 01 d0                                        	add    r8,r10
    98cd:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    98d2:	4d 01 d0                                        	add    r8,r10
    98d5:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    98da:	4d 01 d0                                        	add    r8,r10
    98dd:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    98e2:	4d 01 d0                                        	add    r8,r10
    98e5:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    98ea:	4d 01 d0                                        	add    r8,r10
    98ed:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    98f2:	4d 01 d0                                        	add    r8,r10
    98f5:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    98fa:	4d 01 d0                                        	add    r8,r10
    98fd:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9902:	4d 01 d0                                        	add    r8,r10
    9905:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    990a:	4d 01 d0                                        	add    r8,r10
    990d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9912:	4d 01 d0                                        	add    r8,r10
    9915:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    991a:	4d 01 d0                                        	add    r8,r10
    991d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9922:	4d 01 d0                                        	add    r8,r10
    9925:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    992a:	4d 01 d0                                        	add    r8,r10
    992d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9932:	4d 01 d0                                        	add    r8,r10
    9935:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    993a:	4d 01 d0                                        	add    r8,r10
    993d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9942:	4d 01 d0                                        	add    r8,r10
    9945:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    994a:	4d 01 d0                                        	add    r8,r10
    994d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9952:	4d 01 d0                                        	add    r8,r10
    9955:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    995a:	4d 01 d0                                        	add    r8,r10
    995d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9962:	4d 01 d0                                        	add    r8,r10
    9965:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    996a:	4d 01 d0                                        	add    r8,r10
    996d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9972:	4d 01 d0                                        	add    r8,r10
    9975:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    997a:	4d 01 d0                                        	add    r8,r10
    997d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9982:	4d 01 d0                                        	add    r8,r10
    9985:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    998a:	4d 01 d0                                        	add    r8,r10
    998d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9992:	4d 01 d0                                        	add    r8,r10
    9995:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    999a:	4d 01 d0                                        	add    r8,r10
    999d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    99a2:	4d 01 d0                                        	add    r8,r10
    99a5:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    99aa:	4d 01 d0                                        	add    r8,r10
    99ad:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    99b2:	4d 01 d0                                        	add    r8,r10
    99b5:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    99ba:	4d 01 d0                                        	add    r8,r10
    99bd:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    99c2:	4d 01 d0                                        	add    r8,r10
    99c5:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    99ca:	4d 01 d0                                        	add    r8,r10
    99cd:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    99d2:	4d 01 d0                                        	add    r8,r10
    99d5:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    99da:	4d 01 d0                                        	add    r8,r10
    99dd:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    99e2:	4d 01 d0                                        	add    r8,r10
    99e5:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    99ea:	4d 01 d0                                        	add    r8,r10
    99ed:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    99f2:	4d 01 d0                                        	add    r8,r10
    99f5:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    99fa:	4d 01 d0                                        	add    r8,r10
    99fd:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9a02:	4d 01 d0                                        	add    r8,r10
    9a05:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9a0a:	4d 01 d0                                        	add    r8,r10
    9a0d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9a12:	4d 01 d0                                        	add    r8,r10
    9a15:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9a1a:	4d 01 d0                                        	add    r8,r10
    9a1d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9a22:	4d 01 d0                                        	add    r8,r10
    9a25:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9a2a:	4d 01 d0                                        	add    r8,r10
    9a2d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9a32:	4d 01 d0                                        	add    r8,r10
    9a35:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9a3a:	4d 01 d0                                        	add    r8,r10
    9a3d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9a42:	4d 01 d0                                        	add    r8,r10
    9a45:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9a4a:	4d 01 d0                                        	add    r8,r10
    9a4d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9a52:	4d 01 d0                                        	add    r8,r10
    9a55:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9a5a:	4d 01 d0                                        	add    r8,r10
    9a5d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9a62:	4d 01 d0                                        	add    r8,r10
    9a65:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9a6a:	4d 01 d0                                        	add    r8,r10
    9a6d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9a72:	4d 01 d0                                        	add    r8,r10
    9a75:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9a7a:	4d 01 d0                                        	add    r8,r10
    9a7d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9a82:	4d 01 d0                                        	add    r8,r10
    9a85:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9a8a:	4d 01 d0                                        	add    r8,r10
    9a8d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9a92:	4d 01 d0                                        	add    r8,r10
    9a95:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9a9a:	4d 01 d0                                        	add    r8,r10
    9a9d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9aa2:	4d 01 d0                                        	add    r8,r10
    9aa5:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9aaa:	4d 01 d0                                        	add    r8,r10
    9aad:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9ab2:	4d 01 d0                                        	add    r8,r10
    9ab5:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9aba:	4d 01 d0                                        	add    r8,r10
    9abd:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9ac2:	4d 01 d0                                        	add    r8,r10
    9ac5:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9aca:	4d 01 d0                                        	add    r8,r10
    9acd:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9ad2:	4d 01 d0                                        	add    r8,r10
    9ad5:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9ada:	4d 01 d0                                        	add    r8,r10
    9add:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9ae2:	4d 01 d0                                        	add    r8,r10
    9ae5:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9aea:	4d 01 d0                                        	add    r8,r10
    9aed:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9af2:	4d 01 d0                                        	add    r8,r10
    9af5:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9afa:	4d 01 d0                                        	add    r8,r10
    9afd:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9b02:	4d 01 d0                                        	add    r8,r10
    9b05:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9b0a:	4d 01 d0                                        	add    r8,r10
    9b0d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9b12:	4d 01 d0                                        	add    r8,r10
    9b15:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9b1a:	4d 01 d0                                        	add    r8,r10
    9b1d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9b22:	4d 01 d0                                        	add    r8,r10
    9b25:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9b2a:	4d 01 d0                                        	add    r8,r10
    9b2d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9b32:	4d 01 d0                                        	add    r8,r10
    9b35:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9b3a:	4d 01 d0                                        	add    r8,r10
    9b3d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9b42:	4d 01 d0                                        	add    r8,r10
    9b45:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9b4a:	4d 01 d0                                        	add    r8,r10
    9b4d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9b52:	4d 01 d0                                        	add    r8,r10
    9b55:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9b5a:	4d 01 d0                                        	add    r8,r10
    9b5d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9b62:	4d 01 d0                                        	add    r8,r10
    9b65:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9b6a:	4d 01 d0                                        	add    r8,r10
    9b6d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9b72:	4d 01 d0                                        	add    r8,r10
    9b75:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9b7a:	4d 01 d0                                        	add    r8,r10
    9b7d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9b82:	4d 01 d0                                        	add    r8,r10
    9b85:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9b8a:	4d 01 d0                                        	add    r8,r10
    9b8d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9b92:	4d 01 d0                                        	add    r8,r10
    9b95:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9b9a:	4d 01 d0                                        	add    r8,r10
    9b9d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9ba2:	4d 01 d0                                        	add    r8,r10
    9ba5:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9baa:	4d 01 d0                                        	add    r8,r10
    9bad:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9bb2:	4d 01 d0                                        	add    r8,r10
    9bb5:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9bba:	4d 01 d0                                        	add    r8,r10
    9bbd:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9bc2:	4d 01 d0                                        	add    r8,r10
    9bc5:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9bca:	4d 01 d0                                        	add    r8,r10
    9bcd:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9bd2:	4d 01 d0                                        	add    r8,r10
    9bd5:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9bda:	4d 01 d0                                        	add    r8,r10
    9bdd:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9be2:	4d 01 d0                                        	add    r8,r10
    9be5:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9bea:	4d 01 d0                                        	add    r8,r10
    9bed:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9bf2:	4d 01 d0                                        	add    r8,r10
    9bf5:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9bfa:	4d 01 d0                                        	add    r8,r10
    9bfd:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9c02:	4d 01 d0                                        	add    r8,r10
    9c05:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9c0a:	4d 01 d0                                        	add    r8,r10
    9c0d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9c12:	4d 01 d0                                        	add    r8,r10
    9c15:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9c1a:	4d 01 d0                                        	add    r8,r10
    9c1d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9c22:	4d 01 d0                                        	add    r8,r10
    9c25:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9c2a:	4d 01 d0                                        	add    r8,r10
    9c2d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9c32:	4d 01 d0                                        	add    r8,r10
    9c35:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9c3a:	4d 01 d0                                        	add    r8,r10
    9c3d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9c42:	4d 01 d0                                        	add    r8,r10
    9c45:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9c4a:	4d 01 d0                                        	add    r8,r10
    9c4d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9c52:	4d 01 d0                                        	add    r8,r10
    9c55:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9c5a:	4d 01 d0                                        	add    r8,r10
    9c5d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9c62:	4d 01 d0                                        	add    r8,r10
    9c65:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9c6a:	4d 01 d0                                        	add    r8,r10
    9c6d:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9c72:	4d 01 d0                                        	add    r8,r10
    9c75:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9c7a:	4d 01 d0                                        	add    r8,r10
    9c7d:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9c82:	4d 01 d0                                        	add    r8,r10
    9c85:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9c8a:	4d 01 d0                                        	add    r8,r10
    9c8d:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9c92:	4d 01 d0                                        	add    r8,r10
    9c95:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9c9a:	4d 01 d0                                        	add    r8,r10
    9c9d:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9ca2:	4d 01 d0                                        	add    r8,r10
    9ca5:	41 f6 c1 01                                     	test   r9b,0x1
    9ca9:	74 04                                           	je     9caf <join_7>
    9cab:	49 83 f0 01                                     	xor    r8,0x1

0000000000009caf <join_7>:
    9caf:	4c 89 06                                        	mov    QWORD PTR [rsi],r8
    9cb2:	b8 02 00 00 00                                  	mov    eax,0x2
    9cb7:	c3                                              	ret

0000000000009cb8 <bad>:
    9cb8:	31 c0                                           	xor    eax,eax
    9cba:	c3                                              	ret
