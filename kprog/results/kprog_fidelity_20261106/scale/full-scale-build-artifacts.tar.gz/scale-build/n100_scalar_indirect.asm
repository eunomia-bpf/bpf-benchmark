
/workspaces/repository/kprog/fidelity/build-x86/scale/n100_scalar_indirect.native.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	48 8b 37                                        	mov    rsi,QWORD PTR [rdi]
   3:	48 8b 57 08                                     	mov    rdx,QWORD PTR [rdi+0x8]
   7:	48 8d 46 10                                     	lea    rax,[rsi+0x10]
   b:	48 39 d0                                        	cmp    rax,rdx
   e:	0f 87 c7 01 00 00                               	ja     1db <bad>
  14:	44 0f b6 4e 08                                  	movzx  r9d,BYTE PTR [rsi+0x8]
  19:	41 b8 07 00 00 00                               	mov    r8d,0x7
  1f:	4d 6b c0 03                                     	imul   r8,r8,0x3
  23:	49 83 c0 01                                     	add    r8,0x1
  27:	4d 6b c0 03                                     	imul   r8,r8,0x3
  2b:	49 83 c0 01                                     	add    r8,0x1
  2f:	4d 6b c0 03                                     	imul   r8,r8,0x3
  33:	49 83 c0 01                                     	add    r8,0x1
  37:	4d 6b c0 03                                     	imul   r8,r8,0x3
  3b:	49 83 c0 01                                     	add    r8,0x1
  3f:	4d 6b c0 03                                     	imul   r8,r8,0x3
  43:	49 83 c0 01                                     	add    r8,0x1
  47:	4d 6b c0 03                                     	imul   r8,r8,0x3
  4b:	49 83 c0 01                                     	add    r8,0x1
  4f:	4d 6b c0 03                                     	imul   r8,r8,0x3
  53:	49 83 c0 01                                     	add    r8,0x1
  57:	4d 6b c0 03                                     	imul   r8,r8,0x3
  5b:	49 83 c0 01                                     	add    r8,0x1
  5f:	4d 6b c0 03                                     	imul   r8,r8,0x3
  63:	49 83 c0 01                                     	add    r8,0x1
  67:	4d 6b c0 03                                     	imul   r8,r8,0x3
  6b:	49 83 c0 01                                     	add    r8,0x1
  6f:	4d 6b c0 03                                     	imul   r8,r8,0x3
  73:	49 83 c0 01                                     	add    r8,0x1
  77:	4d 6b c0 03                                     	imul   r8,r8,0x3
  7b:	49 83 c0 01                                     	add    r8,0x1
  7f:	4d 6b c0 03                                     	imul   r8,r8,0x3
  83:	49 83 c0 01                                     	add    r8,0x1
  87:	4d 6b c0 03                                     	imul   r8,r8,0x3
  8b:	49 83 c0 01                                     	add    r8,0x1
  8f:	4d 6b c0 03                                     	imul   r8,r8,0x3
  93:	49 83 c0 01                                     	add    r8,0x1
  97:	4d 6b c0 03                                     	imul   r8,r8,0x3
  9b:	49 83 c0 01                                     	add    r8,0x1
  9f:	4d 6b c0 03                                     	imul   r8,r8,0x3
  a3:	49 83 c0 01                                     	add    r8,0x1
  a7:	4d 6b c0 03                                     	imul   r8,r8,0x3
  ab:	49 83 c0 01                                     	add    r8,0x1
  af:	4d 6b c0 03                                     	imul   r8,r8,0x3
  b3:	49 83 c0 01                                     	add    r8,0x1
  b7:	4d 6b c0 03                                     	imul   r8,r8,0x3
  bb:	49 83 c0 01                                     	add    r8,0x1
  bf:	4d 6b c0 03                                     	imul   r8,r8,0x3
  c3:	49 83 c0 01                                     	add    r8,0x1
  c7:	4d 6b c0 03                                     	imul   r8,r8,0x3
  cb:	49 83 c0 01                                     	add    r8,0x1
  cf:	4d 6b c0 03                                     	imul   r8,r8,0x3
  d3:	49 83 c0 01                                     	add    r8,0x1
  d7:	4d 6b c0 03                                     	imul   r8,r8,0x3
  db:	49 83 c0 01                                     	add    r8,0x1
  df:	4d 6b c0 03                                     	imul   r8,r8,0x3
  e3:	49 83 c0 01                                     	add    r8,0x1
  e7:	4d 6b c0 03                                     	imul   r8,r8,0x3
  eb:	49 83 c0 01                                     	add    r8,0x1
  ef:	4d 6b c0 03                                     	imul   r8,r8,0x3
  f3:	49 83 c0 01                                     	add    r8,0x1
  f7:	4d 6b c0 03                                     	imul   r8,r8,0x3
  fb:	49 83 c0 01                                     	add    r8,0x1
  ff:	4d 6b c0 03                                     	imul   r8,r8,0x3
 103:	49 83 c0 01                                     	add    r8,0x1
 107:	4d 6b c0 03                                     	imul   r8,r8,0x3
 10b:	49 83 c0 01                                     	add    r8,0x1
 10f:	4d 6b c0 03                                     	imul   r8,r8,0x3
 113:	49 83 c0 01                                     	add    r8,0x1
 117:	4d 6b c0 03                                     	imul   r8,r8,0x3
 11b:	49 83 c0 01                                     	add    r8,0x1
 11f:	4d 6b c0 03                                     	imul   r8,r8,0x3
 123:	49 83 c0 01                                     	add    r8,0x1
 127:	4d 6b c0 03                                     	imul   r8,r8,0x3
 12b:	49 83 c0 01                                     	add    r8,0x1
 12f:	4d 6b c0 03                                     	imul   r8,r8,0x3
 133:	49 83 c0 01                                     	add    r8,0x1
 137:	4d 6b c0 03                                     	imul   r8,r8,0x3
 13b:	49 83 c0 01                                     	add    r8,0x1
 13f:	4d 6b c0 03                                     	imul   r8,r8,0x3
 143:	49 83 c0 01                                     	add    r8,0x1
 147:	4d 6b c0 03                                     	imul   r8,r8,0x3
 14b:	49 83 c0 01                                     	add    r8,0x1
 14f:	4d 6b c0 03                                     	imul   r8,r8,0x3
 153:	49 83 c0 01                                     	add    r8,0x1
 157:	4d 6b c0 03                                     	imul   r8,r8,0x3
 15b:	49 83 c0 01                                     	add    r8,0x1
 15f:	4d 6b c0 03                                     	imul   r8,r8,0x3
 163:	49 83 c0 01                                     	add    r8,0x1
 167:	4d 6b c0 03                                     	imul   r8,r8,0x3
 16b:	49 83 c0 01                                     	add    r8,0x1
 16f:	4d 6b c0 03                                     	imul   r8,r8,0x3
 173:	49 83 c0 01                                     	add    r8,0x1
 177:	4d 6b c0 03                                     	imul   r8,r8,0x3
 17b:	49 83 c0 01                                     	add    r8,0x1
 17f:	4d 6b c0 03                                     	imul   r8,r8,0x3
 183:	49 83 c0 01                                     	add    r8,0x1
 187:	4d 6b c0 03                                     	imul   r8,r8,0x3
 18b:	49 83 c0 01                                     	add    r8,0x1
 18f:	4d 6b c0 03                                     	imul   r8,r8,0x3
 193:	49 83 c0 01                                     	add    r8,0x1
 197:	4d 6b c0 03                                     	imul   r8,r8,0x3
 19b:	49 83 c0 01                                     	add    r8,0x1
 19f:	4d 6b c0 03                                     	imul   r8,r8,0x3
 1a3:	49 83 c0 01                                     	add    r8,0x1
 1a7:	4d 6b c0 03                                     	imul   r8,r8,0x3
 1ab:	49 83 c0 01                                     	add    r8,0x1
 1af:	41 f6 c1 01                                     	test   r9b,0x1
 1b3:	75 09                                           	jne    1be <choose_0>
 1b5:	4c 8d 15 0c 00 00 00                            	lea    r10,[rip+0xc]        # 1c8 <target_a_0>
 1bc:	eb 07                                           	jmp    1c5 <dispatch_0>

00000000000001be <choose_0>:
 1be:	4c 8d 15 09 00 00 00                            	lea    r10,[rip+0x9]        # 1ce <target_b_0>

00000000000001c5 <dispatch_0>:
 1c5:	41 ff e2                                        	jmp    r10

00000000000001c8 <target_a_0>:
 1c8:	49 83 c0 01                                     	add    r8,0x1
 1cc:	eb 04                                           	jmp    1d2 <join_0>

00000000000001ce <target_b_0>:
 1ce:	49 83 c0 02                                     	add    r8,0x2

00000000000001d2 <join_0>:
 1d2:	4c 89 06                                        	mov    QWORD PTR [rsi],r8
 1d5:	b8 02 00 00 00                                  	mov    eax,0x2
 1da:	c3                                              	ret

00000000000001db <bad>:
 1db:	31 c0                                           	xor    eax,eax
 1dd:	c3                                              	ret
