
/workspaces/repository/kprog/fidelity/build-x86/scale/n10000_ptr_indirect.native.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <entry>:
       0:	48 8b 37                                        	mov    rsi,QWORD PTR [rdi]
       3:	48 8b 57 08                                     	mov    rdx,QWORD PTR [rdi+0x8]
       7:	48 8d 46 10                                     	lea    rax,[rsi+0x10]
       b:	48 39 d0                                        	cmp    rax,rdx
       e:	0f 87 6c 9d 00 00                               	ja     9d80 <bad>
      14:	44 0f b6 4e 08                                  	movzx  r9d,BYTE PTR [rsi+0x8]
      19:	41 b8 07 00 00 00                               	mov    r8d,0x7
      1f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
      24:	4d 01 d0                                        	add    r8,r10
      27:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
      2c:	4d 01 d0                                        	add    r8,r10
      2f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
      34:	4d 01 d0                                        	add    r8,r10
      37:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
      3c:	4d 01 d0                                        	add    r8,r10
      3f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
      44:	4d 01 d0                                        	add    r8,r10
      47:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
      4c:	4d 01 d0                                        	add    r8,r10
      4f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
      54:	4d 01 d0                                        	add    r8,r10
      57:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
      5c:	4d 01 d0                                        	add    r8,r10
      5f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
      64:	4d 01 d0                                        	add    r8,r10
      67:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
      6c:	4d 01 d0                                        	add    r8,r10
      6f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
      74:	4d 01 d0                                        	add    r8,r10
      77:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
      7c:	4d 01 d0                                        	add    r8,r10
      7f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
      84:	4d 01 d0                                        	add    r8,r10
      87:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
      8c:	4d 01 d0                                        	add    r8,r10
      8f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
      94:	4d 01 d0                                        	add    r8,r10
      97:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
      9c:	4d 01 d0                                        	add    r8,r10
      9f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
      a4:	4d 01 d0                                        	add    r8,r10
      a7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
      ac:	4d 01 d0                                        	add    r8,r10
      af:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
      b4:	4d 01 d0                                        	add    r8,r10
      b7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
      bc:	4d 01 d0                                        	add    r8,r10
      bf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
      c4:	4d 01 d0                                        	add    r8,r10
      c7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
      cc:	4d 01 d0                                        	add    r8,r10
      cf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
      d4:	4d 01 d0                                        	add    r8,r10
      d7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
      dc:	4d 01 d0                                        	add    r8,r10
      df:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
      e4:	4d 01 d0                                        	add    r8,r10
      e7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
      ec:	4d 01 d0                                        	add    r8,r10
      ef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
      f4:	4d 01 d0                                        	add    r8,r10
      f7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
      fc:	4d 01 d0                                        	add    r8,r10
      ff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     104:	4d 01 d0                                        	add    r8,r10
     107:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     10c:	4d 01 d0                                        	add    r8,r10
     10f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     114:	4d 01 d0                                        	add    r8,r10
     117:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     11c:	4d 01 d0                                        	add    r8,r10
     11f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     124:	4d 01 d0                                        	add    r8,r10
     127:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     12c:	4d 01 d0                                        	add    r8,r10
     12f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     134:	4d 01 d0                                        	add    r8,r10
     137:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     13c:	4d 01 d0                                        	add    r8,r10
     13f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     144:	4d 01 d0                                        	add    r8,r10
     147:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     14c:	4d 01 d0                                        	add    r8,r10
     14f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     154:	4d 01 d0                                        	add    r8,r10
     157:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     15c:	4d 01 d0                                        	add    r8,r10
     15f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     164:	4d 01 d0                                        	add    r8,r10
     167:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     16c:	4d 01 d0                                        	add    r8,r10
     16f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     174:	4d 01 d0                                        	add    r8,r10
     177:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     17c:	4d 01 d0                                        	add    r8,r10
     17f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     184:	4d 01 d0                                        	add    r8,r10
     187:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     18c:	4d 01 d0                                        	add    r8,r10
     18f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     194:	4d 01 d0                                        	add    r8,r10
     197:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     19c:	4d 01 d0                                        	add    r8,r10
     19f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     1a4:	4d 01 d0                                        	add    r8,r10
     1a7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     1ac:	4d 01 d0                                        	add    r8,r10
     1af:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     1b4:	4d 01 d0                                        	add    r8,r10
     1b7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     1bc:	4d 01 d0                                        	add    r8,r10
     1bf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     1c4:	4d 01 d0                                        	add    r8,r10
     1c7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     1cc:	4d 01 d0                                        	add    r8,r10
     1cf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     1d4:	4d 01 d0                                        	add    r8,r10
     1d7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     1dc:	4d 01 d0                                        	add    r8,r10
     1df:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     1e4:	4d 01 d0                                        	add    r8,r10
     1e7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     1ec:	4d 01 d0                                        	add    r8,r10
     1ef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     1f4:	4d 01 d0                                        	add    r8,r10
     1f7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     1fc:	4d 01 d0                                        	add    r8,r10
     1ff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     204:	4d 01 d0                                        	add    r8,r10
     207:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     20c:	4d 01 d0                                        	add    r8,r10
     20f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     214:	4d 01 d0                                        	add    r8,r10
     217:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     21c:	4d 01 d0                                        	add    r8,r10
     21f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     224:	4d 01 d0                                        	add    r8,r10
     227:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     22c:	4d 01 d0                                        	add    r8,r10
     22f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     234:	4d 01 d0                                        	add    r8,r10
     237:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     23c:	4d 01 d0                                        	add    r8,r10
     23f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     244:	4d 01 d0                                        	add    r8,r10
     247:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     24c:	4d 01 d0                                        	add    r8,r10
     24f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     254:	4d 01 d0                                        	add    r8,r10
     257:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     25c:	4d 01 d0                                        	add    r8,r10
     25f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     264:	4d 01 d0                                        	add    r8,r10
     267:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     26c:	4d 01 d0                                        	add    r8,r10
     26f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     274:	4d 01 d0                                        	add    r8,r10
     277:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     27c:	4d 01 d0                                        	add    r8,r10
     27f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     284:	4d 01 d0                                        	add    r8,r10
     287:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     28c:	4d 01 d0                                        	add    r8,r10
     28f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     294:	4d 01 d0                                        	add    r8,r10
     297:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     29c:	4d 01 d0                                        	add    r8,r10
     29f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     2a4:	4d 01 d0                                        	add    r8,r10
     2a7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     2ac:	4d 01 d0                                        	add    r8,r10
     2af:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     2b4:	4d 01 d0                                        	add    r8,r10
     2b7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     2bc:	4d 01 d0                                        	add    r8,r10
     2bf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     2c4:	4d 01 d0                                        	add    r8,r10
     2c7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     2cc:	4d 01 d0                                        	add    r8,r10
     2cf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     2d4:	4d 01 d0                                        	add    r8,r10
     2d7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     2dc:	4d 01 d0                                        	add    r8,r10
     2df:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     2e4:	4d 01 d0                                        	add    r8,r10
     2e7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     2ec:	4d 01 d0                                        	add    r8,r10
     2ef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     2f4:	4d 01 d0                                        	add    r8,r10
     2f7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     2fc:	4d 01 d0                                        	add    r8,r10
     2ff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     304:	4d 01 d0                                        	add    r8,r10
     307:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     30c:	4d 01 d0                                        	add    r8,r10
     30f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     314:	4d 01 d0                                        	add    r8,r10
     317:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     31c:	4d 01 d0                                        	add    r8,r10
     31f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     324:	4d 01 d0                                        	add    r8,r10
     327:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     32c:	4d 01 d0                                        	add    r8,r10
     32f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     334:	4d 01 d0                                        	add    r8,r10
     337:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     33c:	4d 01 d0                                        	add    r8,r10
     33f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     344:	4d 01 d0                                        	add    r8,r10
     347:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     34c:	4d 01 d0                                        	add    r8,r10
     34f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     354:	4d 01 d0                                        	add    r8,r10
     357:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     35c:	4d 01 d0                                        	add    r8,r10
     35f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     364:	4d 01 d0                                        	add    r8,r10
     367:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     36c:	4d 01 d0                                        	add    r8,r10
     36f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     374:	4d 01 d0                                        	add    r8,r10
     377:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     37c:	4d 01 d0                                        	add    r8,r10
     37f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     384:	4d 01 d0                                        	add    r8,r10
     387:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     38c:	4d 01 d0                                        	add    r8,r10
     38f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     394:	4d 01 d0                                        	add    r8,r10
     397:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     39c:	4d 01 d0                                        	add    r8,r10
     39f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     3a4:	4d 01 d0                                        	add    r8,r10
     3a7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     3ac:	4d 01 d0                                        	add    r8,r10
     3af:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     3b4:	4d 01 d0                                        	add    r8,r10
     3b7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     3bc:	4d 01 d0                                        	add    r8,r10
     3bf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     3c4:	4d 01 d0                                        	add    r8,r10
     3c7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     3cc:	4d 01 d0                                        	add    r8,r10
     3cf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     3d4:	4d 01 d0                                        	add    r8,r10
     3d7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     3dc:	4d 01 d0                                        	add    r8,r10
     3df:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     3e4:	4d 01 d0                                        	add    r8,r10
     3e7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     3ec:	4d 01 d0                                        	add    r8,r10
     3ef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     3f4:	4d 01 d0                                        	add    r8,r10
     3f7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     3fc:	4d 01 d0                                        	add    r8,r10
     3ff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     404:	4d 01 d0                                        	add    r8,r10
     407:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     40c:	4d 01 d0                                        	add    r8,r10
     40f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     414:	4d 01 d0                                        	add    r8,r10
     417:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     41c:	4d 01 d0                                        	add    r8,r10
     41f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     424:	4d 01 d0                                        	add    r8,r10
     427:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     42c:	4d 01 d0                                        	add    r8,r10
     42f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     434:	4d 01 d0                                        	add    r8,r10
     437:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     43c:	4d 01 d0                                        	add    r8,r10
     43f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     444:	4d 01 d0                                        	add    r8,r10
     447:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     44c:	4d 01 d0                                        	add    r8,r10
     44f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     454:	4d 01 d0                                        	add    r8,r10
     457:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     45c:	4d 01 d0                                        	add    r8,r10
     45f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     464:	4d 01 d0                                        	add    r8,r10
     467:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     46c:	4d 01 d0                                        	add    r8,r10
     46f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     474:	4d 01 d0                                        	add    r8,r10
     477:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     47c:	4d 01 d0                                        	add    r8,r10
     47f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     484:	4d 01 d0                                        	add    r8,r10
     487:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     48c:	4d 01 d0                                        	add    r8,r10
     48f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     494:	4d 01 d0                                        	add    r8,r10
     497:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     49c:	4d 01 d0                                        	add    r8,r10
     49f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     4a4:	4d 01 d0                                        	add    r8,r10
     4a7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     4ac:	4d 01 d0                                        	add    r8,r10
     4af:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     4b4:	4d 01 d0                                        	add    r8,r10
     4b7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     4bc:	4d 01 d0                                        	add    r8,r10
     4bf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     4c4:	4d 01 d0                                        	add    r8,r10
     4c7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     4cc:	4d 01 d0                                        	add    r8,r10
     4cf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     4d4:	4d 01 d0                                        	add    r8,r10
     4d7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     4dc:	4d 01 d0                                        	add    r8,r10
     4df:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     4e4:	4d 01 d0                                        	add    r8,r10
     4e7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     4ec:	4d 01 d0                                        	add    r8,r10
     4ef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     4f4:	4d 01 d0                                        	add    r8,r10
     4f7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     4fc:	4d 01 d0                                        	add    r8,r10
     4ff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     504:	4d 01 d0                                        	add    r8,r10
     507:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     50c:	4d 01 d0                                        	add    r8,r10
     50f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     514:	4d 01 d0                                        	add    r8,r10
     517:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     51c:	4d 01 d0                                        	add    r8,r10
     51f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     524:	4d 01 d0                                        	add    r8,r10
     527:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     52c:	4d 01 d0                                        	add    r8,r10
     52f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     534:	4d 01 d0                                        	add    r8,r10
     537:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     53c:	4d 01 d0                                        	add    r8,r10
     53f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     544:	4d 01 d0                                        	add    r8,r10
     547:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     54c:	4d 01 d0                                        	add    r8,r10
     54f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     554:	4d 01 d0                                        	add    r8,r10
     557:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     55c:	4d 01 d0                                        	add    r8,r10
     55f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     564:	4d 01 d0                                        	add    r8,r10
     567:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     56c:	4d 01 d0                                        	add    r8,r10
     56f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     574:	4d 01 d0                                        	add    r8,r10
     577:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     57c:	4d 01 d0                                        	add    r8,r10
     57f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     584:	4d 01 d0                                        	add    r8,r10
     587:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     58c:	4d 01 d0                                        	add    r8,r10
     58f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     594:	4d 01 d0                                        	add    r8,r10
     597:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     59c:	4d 01 d0                                        	add    r8,r10
     59f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     5a4:	4d 01 d0                                        	add    r8,r10
     5a7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     5ac:	4d 01 d0                                        	add    r8,r10
     5af:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     5b4:	4d 01 d0                                        	add    r8,r10
     5b7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     5bc:	4d 01 d0                                        	add    r8,r10
     5bf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     5c4:	4d 01 d0                                        	add    r8,r10
     5c7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     5cc:	4d 01 d0                                        	add    r8,r10
     5cf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     5d4:	4d 01 d0                                        	add    r8,r10
     5d7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     5dc:	4d 01 d0                                        	add    r8,r10
     5df:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     5e4:	4d 01 d0                                        	add    r8,r10
     5e7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     5ec:	4d 01 d0                                        	add    r8,r10
     5ef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     5f4:	4d 01 d0                                        	add    r8,r10
     5f7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     5fc:	4d 01 d0                                        	add    r8,r10
     5ff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     604:	4d 01 d0                                        	add    r8,r10
     607:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     60c:	4d 01 d0                                        	add    r8,r10
     60f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     614:	4d 01 d0                                        	add    r8,r10
     617:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     61c:	4d 01 d0                                        	add    r8,r10
     61f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     624:	4d 01 d0                                        	add    r8,r10
     627:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     62c:	4d 01 d0                                        	add    r8,r10
     62f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     634:	4d 01 d0                                        	add    r8,r10
     637:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     63c:	4d 01 d0                                        	add    r8,r10
     63f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     644:	4d 01 d0                                        	add    r8,r10
     647:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     64c:	4d 01 d0                                        	add    r8,r10
     64f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     654:	4d 01 d0                                        	add    r8,r10
     657:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     65c:	4d 01 d0                                        	add    r8,r10
     65f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     664:	4d 01 d0                                        	add    r8,r10
     667:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     66c:	4d 01 d0                                        	add    r8,r10
     66f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     674:	4d 01 d0                                        	add    r8,r10
     677:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     67c:	4d 01 d0                                        	add    r8,r10
     67f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     684:	4d 01 d0                                        	add    r8,r10
     687:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     68c:	4d 01 d0                                        	add    r8,r10
     68f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     694:	4d 01 d0                                        	add    r8,r10
     697:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     69c:	4d 01 d0                                        	add    r8,r10
     69f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     6a4:	4d 01 d0                                        	add    r8,r10
     6a7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     6ac:	4d 01 d0                                        	add    r8,r10
     6af:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     6b4:	4d 01 d0                                        	add    r8,r10
     6b7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     6bc:	4d 01 d0                                        	add    r8,r10
     6bf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     6c4:	4d 01 d0                                        	add    r8,r10
     6c7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     6cc:	4d 01 d0                                        	add    r8,r10
     6cf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     6d4:	4d 01 d0                                        	add    r8,r10
     6d7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     6dc:	4d 01 d0                                        	add    r8,r10
     6df:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     6e4:	4d 01 d0                                        	add    r8,r10
     6e7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     6ec:	4d 01 d0                                        	add    r8,r10
     6ef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     6f4:	4d 01 d0                                        	add    r8,r10
     6f7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     6fc:	4d 01 d0                                        	add    r8,r10
     6ff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     704:	4d 01 d0                                        	add    r8,r10
     707:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     70c:	4d 01 d0                                        	add    r8,r10
     70f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     714:	4d 01 d0                                        	add    r8,r10
     717:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     71c:	4d 01 d0                                        	add    r8,r10
     71f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     724:	4d 01 d0                                        	add    r8,r10
     727:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     72c:	4d 01 d0                                        	add    r8,r10
     72f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     734:	4d 01 d0                                        	add    r8,r10
     737:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     73c:	4d 01 d0                                        	add    r8,r10
     73f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     744:	4d 01 d0                                        	add    r8,r10
     747:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     74c:	4d 01 d0                                        	add    r8,r10
     74f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     754:	4d 01 d0                                        	add    r8,r10
     757:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     75c:	4d 01 d0                                        	add    r8,r10
     75f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     764:	4d 01 d0                                        	add    r8,r10
     767:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     76c:	4d 01 d0                                        	add    r8,r10
     76f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     774:	4d 01 d0                                        	add    r8,r10
     777:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     77c:	4d 01 d0                                        	add    r8,r10
     77f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     784:	4d 01 d0                                        	add    r8,r10
     787:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     78c:	4d 01 d0                                        	add    r8,r10
     78f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     794:	4d 01 d0                                        	add    r8,r10
     797:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     79c:	4d 01 d0                                        	add    r8,r10
     79f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     7a4:	4d 01 d0                                        	add    r8,r10
     7a7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     7ac:	4d 01 d0                                        	add    r8,r10
     7af:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     7b4:	4d 01 d0                                        	add    r8,r10
     7b7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     7bc:	4d 01 d0                                        	add    r8,r10
     7bf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     7c4:	4d 01 d0                                        	add    r8,r10
     7c7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     7cc:	4d 01 d0                                        	add    r8,r10
     7cf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     7d4:	4d 01 d0                                        	add    r8,r10
     7d7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     7dc:	4d 01 d0                                        	add    r8,r10
     7df:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     7e4:	4d 01 d0                                        	add    r8,r10
     7e7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     7ec:	4d 01 d0                                        	add    r8,r10
     7ef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     7f4:	4d 01 d0                                        	add    r8,r10
     7f7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     7fc:	4d 01 d0                                        	add    r8,r10
     7ff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     804:	4d 01 d0                                        	add    r8,r10
     807:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     80c:	4d 01 d0                                        	add    r8,r10
     80f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     814:	4d 01 d0                                        	add    r8,r10
     817:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     81c:	4d 01 d0                                        	add    r8,r10
     81f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     824:	4d 01 d0                                        	add    r8,r10
     827:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     82c:	4d 01 d0                                        	add    r8,r10
     82f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     834:	4d 01 d0                                        	add    r8,r10
     837:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     83c:	4d 01 d0                                        	add    r8,r10
     83f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     844:	4d 01 d0                                        	add    r8,r10
     847:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     84c:	4d 01 d0                                        	add    r8,r10
     84f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     854:	4d 01 d0                                        	add    r8,r10
     857:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     85c:	4d 01 d0                                        	add    r8,r10
     85f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     864:	4d 01 d0                                        	add    r8,r10
     867:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     86c:	4d 01 d0                                        	add    r8,r10
     86f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     874:	4d 01 d0                                        	add    r8,r10
     877:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     87c:	4d 01 d0                                        	add    r8,r10
     87f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     884:	4d 01 d0                                        	add    r8,r10
     887:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     88c:	4d 01 d0                                        	add    r8,r10
     88f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     894:	4d 01 d0                                        	add    r8,r10
     897:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     89c:	4d 01 d0                                        	add    r8,r10
     89f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     8a4:	4d 01 d0                                        	add    r8,r10
     8a7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     8ac:	4d 01 d0                                        	add    r8,r10
     8af:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     8b4:	4d 01 d0                                        	add    r8,r10
     8b7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     8bc:	4d 01 d0                                        	add    r8,r10
     8bf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     8c4:	4d 01 d0                                        	add    r8,r10
     8c7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     8cc:	4d 01 d0                                        	add    r8,r10
     8cf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     8d4:	4d 01 d0                                        	add    r8,r10
     8d7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     8dc:	4d 01 d0                                        	add    r8,r10
     8df:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     8e4:	4d 01 d0                                        	add    r8,r10
     8e7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     8ec:	4d 01 d0                                        	add    r8,r10
     8ef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     8f4:	4d 01 d0                                        	add    r8,r10
     8f7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     8fc:	4d 01 d0                                        	add    r8,r10
     8ff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     904:	4d 01 d0                                        	add    r8,r10
     907:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     90c:	4d 01 d0                                        	add    r8,r10
     90f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     914:	4d 01 d0                                        	add    r8,r10
     917:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     91c:	4d 01 d0                                        	add    r8,r10
     91f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     924:	4d 01 d0                                        	add    r8,r10
     927:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     92c:	4d 01 d0                                        	add    r8,r10
     92f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     934:	4d 01 d0                                        	add    r8,r10
     937:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     93c:	4d 01 d0                                        	add    r8,r10
     93f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     944:	4d 01 d0                                        	add    r8,r10
     947:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     94c:	4d 01 d0                                        	add    r8,r10
     94f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     954:	4d 01 d0                                        	add    r8,r10
     957:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     95c:	4d 01 d0                                        	add    r8,r10
     95f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     964:	4d 01 d0                                        	add    r8,r10
     967:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     96c:	4d 01 d0                                        	add    r8,r10
     96f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     974:	4d 01 d0                                        	add    r8,r10
     977:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     97c:	4d 01 d0                                        	add    r8,r10
     97f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     984:	4d 01 d0                                        	add    r8,r10
     987:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     98c:	4d 01 d0                                        	add    r8,r10
     98f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     994:	4d 01 d0                                        	add    r8,r10
     997:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     99c:	4d 01 d0                                        	add    r8,r10
     99f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     9a4:	4d 01 d0                                        	add    r8,r10
     9a7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     9ac:	4d 01 d0                                        	add    r8,r10
     9af:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     9b4:	4d 01 d0                                        	add    r8,r10
     9b7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     9bc:	4d 01 d0                                        	add    r8,r10
     9bf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     9c4:	4d 01 d0                                        	add    r8,r10
     9c7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     9cc:	4d 01 d0                                        	add    r8,r10
     9cf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     9d4:	4d 01 d0                                        	add    r8,r10
     9d7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     9dc:	4d 01 d0                                        	add    r8,r10
     9df:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     9e4:	4d 01 d0                                        	add    r8,r10
     9e7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     9ec:	4d 01 d0                                        	add    r8,r10
     9ef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     9f4:	4d 01 d0                                        	add    r8,r10
     9f7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     9fc:	4d 01 d0                                        	add    r8,r10
     9ff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     a04:	4d 01 d0                                        	add    r8,r10
     a07:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     a0c:	4d 01 d0                                        	add    r8,r10
     a0f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     a14:	4d 01 d0                                        	add    r8,r10
     a17:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     a1c:	4d 01 d0                                        	add    r8,r10
     a1f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     a24:	4d 01 d0                                        	add    r8,r10
     a27:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     a2c:	4d 01 d0                                        	add    r8,r10
     a2f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     a34:	4d 01 d0                                        	add    r8,r10
     a37:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     a3c:	4d 01 d0                                        	add    r8,r10
     a3f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     a44:	4d 01 d0                                        	add    r8,r10
     a47:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     a4c:	4d 01 d0                                        	add    r8,r10
     a4f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     a54:	4d 01 d0                                        	add    r8,r10
     a57:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     a5c:	4d 01 d0                                        	add    r8,r10
     a5f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     a64:	4d 01 d0                                        	add    r8,r10
     a67:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     a6c:	4d 01 d0                                        	add    r8,r10
     a6f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     a74:	4d 01 d0                                        	add    r8,r10
     a77:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     a7c:	4d 01 d0                                        	add    r8,r10
     a7f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     a84:	4d 01 d0                                        	add    r8,r10
     a87:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     a8c:	4d 01 d0                                        	add    r8,r10
     a8f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     a94:	4d 01 d0                                        	add    r8,r10
     a97:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     a9c:	4d 01 d0                                        	add    r8,r10
     a9f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     aa4:	4d 01 d0                                        	add    r8,r10
     aa7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     aac:	4d 01 d0                                        	add    r8,r10
     aaf:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     ab4:	4d 01 d0                                        	add    r8,r10
     ab7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     abc:	4d 01 d0                                        	add    r8,r10
     abf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     ac4:	4d 01 d0                                        	add    r8,r10
     ac7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     acc:	4d 01 d0                                        	add    r8,r10
     acf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     ad4:	4d 01 d0                                        	add    r8,r10
     ad7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     adc:	4d 01 d0                                        	add    r8,r10
     adf:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     ae4:	4d 01 d0                                        	add    r8,r10
     ae7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     aec:	4d 01 d0                                        	add    r8,r10
     aef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     af4:	4d 01 d0                                        	add    r8,r10
     af7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     afc:	4d 01 d0                                        	add    r8,r10
     aff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     b04:	4d 01 d0                                        	add    r8,r10
     b07:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     b0c:	4d 01 d0                                        	add    r8,r10
     b0f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     b14:	4d 01 d0                                        	add    r8,r10
     b17:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     b1c:	4d 01 d0                                        	add    r8,r10
     b1f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     b24:	4d 01 d0                                        	add    r8,r10
     b27:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     b2c:	4d 01 d0                                        	add    r8,r10
     b2f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     b34:	4d 01 d0                                        	add    r8,r10
     b37:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     b3c:	4d 01 d0                                        	add    r8,r10
     b3f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     b44:	4d 01 d0                                        	add    r8,r10
     b47:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     b4c:	4d 01 d0                                        	add    r8,r10
     b4f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     b54:	4d 01 d0                                        	add    r8,r10
     b57:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     b5c:	4d 01 d0                                        	add    r8,r10
     b5f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     b64:	4d 01 d0                                        	add    r8,r10
     b67:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     b6c:	4d 01 d0                                        	add    r8,r10
     b6f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     b74:	4d 01 d0                                        	add    r8,r10
     b77:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     b7c:	4d 01 d0                                        	add    r8,r10
     b7f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     b84:	4d 01 d0                                        	add    r8,r10
     b87:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     b8c:	4d 01 d0                                        	add    r8,r10
     b8f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     b94:	4d 01 d0                                        	add    r8,r10
     b97:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     b9c:	4d 01 d0                                        	add    r8,r10
     b9f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     ba4:	4d 01 d0                                        	add    r8,r10
     ba7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     bac:	4d 01 d0                                        	add    r8,r10
     baf:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     bb4:	4d 01 d0                                        	add    r8,r10
     bb7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     bbc:	4d 01 d0                                        	add    r8,r10
     bbf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     bc4:	4d 01 d0                                        	add    r8,r10
     bc7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     bcc:	4d 01 d0                                        	add    r8,r10
     bcf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     bd4:	4d 01 d0                                        	add    r8,r10
     bd7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     bdc:	4d 01 d0                                        	add    r8,r10
     bdf:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     be4:	4d 01 d0                                        	add    r8,r10
     be7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     bec:	4d 01 d0                                        	add    r8,r10
     bef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     bf4:	4d 01 d0                                        	add    r8,r10
     bf7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     bfc:	4d 01 d0                                        	add    r8,r10
     bff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     c04:	4d 01 d0                                        	add    r8,r10
     c07:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     c0c:	4d 01 d0                                        	add    r8,r10
     c0f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     c14:	4d 01 d0                                        	add    r8,r10
     c17:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     c1c:	4d 01 d0                                        	add    r8,r10
     c1f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     c24:	4d 01 d0                                        	add    r8,r10
     c27:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     c2c:	4d 01 d0                                        	add    r8,r10
     c2f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     c34:	4d 01 d0                                        	add    r8,r10
     c37:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     c3c:	4d 01 d0                                        	add    r8,r10
     c3f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     c44:	4d 01 d0                                        	add    r8,r10
     c47:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     c4c:	4d 01 d0                                        	add    r8,r10
     c4f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     c54:	4d 01 d0                                        	add    r8,r10
     c57:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     c5c:	4d 01 d0                                        	add    r8,r10
     c5f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     c64:	4d 01 d0                                        	add    r8,r10
     c67:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     c6c:	4d 01 d0                                        	add    r8,r10
     c6f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     c74:	4d 01 d0                                        	add    r8,r10
     c77:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     c7c:	4d 01 d0                                        	add    r8,r10
     c7f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     c84:	4d 01 d0                                        	add    r8,r10
     c87:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     c8c:	4d 01 d0                                        	add    r8,r10
     c8f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     c94:	4d 01 d0                                        	add    r8,r10
     c97:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     c9c:	4d 01 d0                                        	add    r8,r10
     c9f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     ca4:	4d 01 d0                                        	add    r8,r10
     ca7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     cac:	4d 01 d0                                        	add    r8,r10
     caf:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     cb4:	4d 01 d0                                        	add    r8,r10
     cb7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     cbc:	4d 01 d0                                        	add    r8,r10
     cbf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     cc4:	4d 01 d0                                        	add    r8,r10
     cc7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     ccc:	4d 01 d0                                        	add    r8,r10
     ccf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     cd4:	4d 01 d0                                        	add    r8,r10
     cd7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     cdc:	4d 01 d0                                        	add    r8,r10
     cdf:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     ce4:	4d 01 d0                                        	add    r8,r10
     ce7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     cec:	4d 01 d0                                        	add    r8,r10
     cef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     cf4:	4d 01 d0                                        	add    r8,r10
     cf7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     cfc:	4d 01 d0                                        	add    r8,r10
     cff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     d04:	4d 01 d0                                        	add    r8,r10
     d07:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     d0c:	4d 01 d0                                        	add    r8,r10
     d0f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     d14:	4d 01 d0                                        	add    r8,r10
     d17:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     d1c:	4d 01 d0                                        	add    r8,r10
     d1f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     d24:	4d 01 d0                                        	add    r8,r10
     d27:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     d2c:	4d 01 d0                                        	add    r8,r10
     d2f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     d34:	4d 01 d0                                        	add    r8,r10
     d37:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     d3c:	4d 01 d0                                        	add    r8,r10
     d3f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     d44:	4d 01 d0                                        	add    r8,r10
     d47:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     d4c:	4d 01 d0                                        	add    r8,r10
     d4f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     d54:	4d 01 d0                                        	add    r8,r10
     d57:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     d5c:	4d 01 d0                                        	add    r8,r10
     d5f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     d64:	4d 01 d0                                        	add    r8,r10
     d67:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     d6c:	4d 01 d0                                        	add    r8,r10
     d6f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     d74:	4d 01 d0                                        	add    r8,r10
     d77:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     d7c:	4d 01 d0                                        	add    r8,r10
     d7f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     d84:	4d 01 d0                                        	add    r8,r10
     d87:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     d8c:	4d 01 d0                                        	add    r8,r10
     d8f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     d94:	4d 01 d0                                        	add    r8,r10
     d97:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     d9c:	4d 01 d0                                        	add    r8,r10
     d9f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     da4:	4d 01 d0                                        	add    r8,r10
     da7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     dac:	4d 01 d0                                        	add    r8,r10
     daf:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     db4:	4d 01 d0                                        	add    r8,r10
     db7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     dbc:	4d 01 d0                                        	add    r8,r10
     dbf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     dc4:	4d 01 d0                                        	add    r8,r10
     dc7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     dcc:	4d 01 d0                                        	add    r8,r10
     dcf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     dd4:	4d 01 d0                                        	add    r8,r10
     dd7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     ddc:	4d 01 d0                                        	add    r8,r10
     ddf:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     de4:	4d 01 d0                                        	add    r8,r10
     de7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     dec:	4d 01 d0                                        	add    r8,r10
     def:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     df4:	4d 01 d0                                        	add    r8,r10
     df7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     dfc:	4d 01 d0                                        	add    r8,r10
     dff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     e04:	4d 01 d0                                        	add    r8,r10
     e07:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     e0c:	4d 01 d0                                        	add    r8,r10
     e0f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     e14:	4d 01 d0                                        	add    r8,r10
     e17:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     e1c:	4d 01 d0                                        	add    r8,r10
     e1f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     e24:	4d 01 d0                                        	add    r8,r10
     e27:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     e2c:	4d 01 d0                                        	add    r8,r10
     e2f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     e34:	4d 01 d0                                        	add    r8,r10
     e37:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     e3c:	4d 01 d0                                        	add    r8,r10
     e3f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     e44:	4d 01 d0                                        	add    r8,r10
     e47:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     e4c:	4d 01 d0                                        	add    r8,r10
     e4f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     e54:	4d 01 d0                                        	add    r8,r10
     e57:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     e5c:	4d 01 d0                                        	add    r8,r10
     e5f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     e64:	4d 01 d0                                        	add    r8,r10
     e67:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     e6c:	4d 01 d0                                        	add    r8,r10
     e6f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     e74:	4d 01 d0                                        	add    r8,r10
     e77:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     e7c:	4d 01 d0                                        	add    r8,r10
     e7f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     e84:	4d 01 d0                                        	add    r8,r10
     e87:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     e8c:	4d 01 d0                                        	add    r8,r10
     e8f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     e94:	4d 01 d0                                        	add    r8,r10
     e97:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     e9c:	4d 01 d0                                        	add    r8,r10
     e9f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     ea4:	4d 01 d0                                        	add    r8,r10
     ea7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     eac:	4d 01 d0                                        	add    r8,r10
     eaf:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     eb4:	4d 01 d0                                        	add    r8,r10
     eb7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     ebc:	4d 01 d0                                        	add    r8,r10
     ebf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     ec4:	4d 01 d0                                        	add    r8,r10
     ec7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     ecc:	4d 01 d0                                        	add    r8,r10
     ecf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     ed4:	4d 01 d0                                        	add    r8,r10
     ed7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     edc:	4d 01 d0                                        	add    r8,r10
     edf:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     ee4:	4d 01 d0                                        	add    r8,r10
     ee7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     eec:	4d 01 d0                                        	add    r8,r10
     eef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     ef4:	4d 01 d0                                        	add    r8,r10
     ef7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     efc:	4d 01 d0                                        	add    r8,r10
     eff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     f04:	4d 01 d0                                        	add    r8,r10
     f07:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     f0c:	4d 01 d0                                        	add    r8,r10
     f0f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     f14:	4d 01 d0                                        	add    r8,r10
     f17:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     f1c:	4d 01 d0                                        	add    r8,r10
     f1f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     f24:	4d 01 d0                                        	add    r8,r10
     f27:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     f2c:	4d 01 d0                                        	add    r8,r10
     f2f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     f34:	4d 01 d0                                        	add    r8,r10
     f37:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     f3c:	4d 01 d0                                        	add    r8,r10
     f3f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     f44:	4d 01 d0                                        	add    r8,r10
     f47:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     f4c:	4d 01 d0                                        	add    r8,r10
     f4f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     f54:	4d 01 d0                                        	add    r8,r10
     f57:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     f5c:	4d 01 d0                                        	add    r8,r10
     f5f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     f64:	4d 01 d0                                        	add    r8,r10
     f67:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     f6c:	4d 01 d0                                        	add    r8,r10
     f6f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     f74:	4d 01 d0                                        	add    r8,r10
     f77:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     f7c:	4d 01 d0                                        	add    r8,r10
     f7f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     f84:	4d 01 d0                                        	add    r8,r10
     f87:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     f8c:	4d 01 d0                                        	add    r8,r10
     f8f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     f94:	4d 01 d0                                        	add    r8,r10
     f97:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     f9c:	4d 01 d0                                        	add    r8,r10
     f9f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     fa4:	4d 01 d0                                        	add    r8,r10
     fa7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     fac:	4d 01 d0                                        	add    r8,r10
     faf:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     fb4:	4d 01 d0                                        	add    r8,r10
     fb7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     fbc:	4d 01 d0                                        	add    r8,r10
     fbf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
     fc4:	4d 01 d0                                        	add    r8,r10
     fc7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
     fcc:	4d 01 d0                                        	add    r8,r10
     fcf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
     fd4:	4d 01 d0                                        	add    r8,r10
     fd7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
     fdc:	4d 01 d0                                        	add    r8,r10
     fdf:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
     fe4:	4d 01 d0                                        	add    r8,r10
     fe7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
     fec:	4d 01 d0                                        	add    r8,r10
     fef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
     ff4:	4d 01 d0                                        	add    r8,r10
     ff7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
     ffc:	4d 01 d0                                        	add    r8,r10
     fff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1004:	4d 01 d0                                        	add    r8,r10
    1007:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    100c:	4d 01 d0                                        	add    r8,r10
    100f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1014:	4d 01 d0                                        	add    r8,r10
    1017:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    101c:	4d 01 d0                                        	add    r8,r10
    101f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1024:	4d 01 d0                                        	add    r8,r10
    1027:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    102c:	4d 01 d0                                        	add    r8,r10
    102f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1034:	4d 01 d0                                        	add    r8,r10
    1037:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    103c:	4d 01 d0                                        	add    r8,r10
    103f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1044:	4d 01 d0                                        	add    r8,r10
    1047:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    104c:	4d 01 d0                                        	add    r8,r10
    104f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1054:	4d 01 d0                                        	add    r8,r10
    1057:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    105c:	4d 01 d0                                        	add    r8,r10
    105f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1064:	4d 01 d0                                        	add    r8,r10
    1067:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    106c:	4d 01 d0                                        	add    r8,r10
    106f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1074:	4d 01 d0                                        	add    r8,r10
    1077:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    107c:	4d 01 d0                                        	add    r8,r10
    107f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1084:	4d 01 d0                                        	add    r8,r10
    1087:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    108c:	4d 01 d0                                        	add    r8,r10
    108f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1094:	4d 01 d0                                        	add    r8,r10
    1097:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    109c:	4d 01 d0                                        	add    r8,r10
    109f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    10a4:	4d 01 d0                                        	add    r8,r10
    10a7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    10ac:	4d 01 d0                                        	add    r8,r10
    10af:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    10b4:	4d 01 d0                                        	add    r8,r10
    10b7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    10bc:	4d 01 d0                                        	add    r8,r10
    10bf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    10c4:	4d 01 d0                                        	add    r8,r10
    10c7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    10cc:	4d 01 d0                                        	add    r8,r10
    10cf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    10d4:	4d 01 d0                                        	add    r8,r10
    10d7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    10dc:	4d 01 d0                                        	add    r8,r10
    10df:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    10e4:	4d 01 d0                                        	add    r8,r10
    10e7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    10ec:	4d 01 d0                                        	add    r8,r10
    10ef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    10f4:	4d 01 d0                                        	add    r8,r10
    10f7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    10fc:	4d 01 d0                                        	add    r8,r10
    10ff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1104:	4d 01 d0                                        	add    r8,r10
    1107:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    110c:	4d 01 d0                                        	add    r8,r10
    110f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1114:	4d 01 d0                                        	add    r8,r10
    1117:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    111c:	4d 01 d0                                        	add    r8,r10
    111f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1124:	4d 01 d0                                        	add    r8,r10
    1127:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    112c:	4d 01 d0                                        	add    r8,r10
    112f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1134:	4d 01 d0                                        	add    r8,r10
    1137:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    113c:	4d 01 d0                                        	add    r8,r10
    113f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1144:	4d 01 d0                                        	add    r8,r10
    1147:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    114c:	4d 01 d0                                        	add    r8,r10
    114f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1154:	4d 01 d0                                        	add    r8,r10
    1157:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    115c:	4d 01 d0                                        	add    r8,r10
    115f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1164:	4d 01 d0                                        	add    r8,r10
    1167:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    116c:	4d 01 d0                                        	add    r8,r10
    116f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1174:	4d 01 d0                                        	add    r8,r10
    1177:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    117c:	4d 01 d0                                        	add    r8,r10
    117f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1184:	4d 01 d0                                        	add    r8,r10
    1187:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    118c:	4d 01 d0                                        	add    r8,r10
    118f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1194:	4d 01 d0                                        	add    r8,r10
    1197:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    119c:	4d 01 d0                                        	add    r8,r10
    119f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    11a4:	4d 01 d0                                        	add    r8,r10
    11a7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    11ac:	4d 01 d0                                        	add    r8,r10
    11af:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    11b4:	4d 01 d0                                        	add    r8,r10
    11b7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    11bc:	4d 01 d0                                        	add    r8,r10
    11bf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    11c4:	4d 01 d0                                        	add    r8,r10
    11c7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    11cc:	4d 01 d0                                        	add    r8,r10
    11cf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    11d4:	4d 01 d0                                        	add    r8,r10
    11d7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    11dc:	4d 01 d0                                        	add    r8,r10
    11df:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    11e4:	4d 01 d0                                        	add    r8,r10
    11e7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    11ec:	4d 01 d0                                        	add    r8,r10
    11ef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    11f4:	4d 01 d0                                        	add    r8,r10
    11f7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    11fc:	4d 01 d0                                        	add    r8,r10
    11ff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1204:	4d 01 d0                                        	add    r8,r10
    1207:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    120c:	4d 01 d0                                        	add    r8,r10
    120f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1214:	4d 01 d0                                        	add    r8,r10
    1217:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    121c:	4d 01 d0                                        	add    r8,r10
    121f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1224:	4d 01 d0                                        	add    r8,r10
    1227:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    122c:	4d 01 d0                                        	add    r8,r10
    122f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1234:	4d 01 d0                                        	add    r8,r10
    1237:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    123c:	4d 01 d0                                        	add    r8,r10
    123f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1244:	4d 01 d0                                        	add    r8,r10
    1247:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    124c:	4d 01 d0                                        	add    r8,r10
    124f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1254:	4d 01 d0                                        	add    r8,r10
    1257:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    125c:	4d 01 d0                                        	add    r8,r10
    125f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1264:	4d 01 d0                                        	add    r8,r10
    1267:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    126c:	4d 01 d0                                        	add    r8,r10
    126f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1274:	4d 01 d0                                        	add    r8,r10
    1277:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    127c:	4d 01 d0                                        	add    r8,r10
    127f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1284:	4d 01 d0                                        	add    r8,r10
    1287:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    128c:	4d 01 d0                                        	add    r8,r10
    128f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1294:	4d 01 d0                                        	add    r8,r10
    1297:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    129c:	4d 01 d0                                        	add    r8,r10
    129f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    12a4:	4d 01 d0                                        	add    r8,r10
    12a7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    12ac:	4d 01 d0                                        	add    r8,r10
    12af:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    12b4:	4d 01 d0                                        	add    r8,r10
    12b7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    12bc:	4d 01 d0                                        	add    r8,r10
    12bf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    12c4:	4d 01 d0                                        	add    r8,r10
    12c7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    12cc:	4d 01 d0                                        	add    r8,r10
    12cf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    12d4:	4d 01 d0                                        	add    r8,r10
    12d7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    12dc:	4d 01 d0                                        	add    r8,r10
    12df:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    12e4:	4d 01 d0                                        	add    r8,r10
    12e7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    12ec:	4d 01 d0                                        	add    r8,r10
    12ef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    12f4:	4d 01 d0                                        	add    r8,r10
    12f7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    12fc:	4d 01 d0                                        	add    r8,r10
    12ff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1304:	4d 01 d0                                        	add    r8,r10
    1307:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    130c:	4d 01 d0                                        	add    r8,r10
    130f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1314:	4d 01 d0                                        	add    r8,r10
    1317:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    131c:	4d 01 d0                                        	add    r8,r10
    131f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1324:	4d 01 d0                                        	add    r8,r10
    1327:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    132c:	4d 01 d0                                        	add    r8,r10
    132f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1334:	4d 01 d0                                        	add    r8,r10
    1337:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    133c:	4d 01 d0                                        	add    r8,r10
    133f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1344:	4d 01 d0                                        	add    r8,r10
    1347:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    134c:	4d 01 d0                                        	add    r8,r10
    134f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1354:	4d 01 d0                                        	add    r8,r10
    1357:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    135c:	4d 01 d0                                        	add    r8,r10
    135f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1364:	4d 01 d0                                        	add    r8,r10
    1367:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    136c:	4d 01 d0                                        	add    r8,r10
    136f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1374:	4d 01 d0                                        	add    r8,r10
    1377:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    137c:	4d 01 d0                                        	add    r8,r10
    137f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1384:	4d 01 d0                                        	add    r8,r10
    1387:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    138c:	4d 01 d0                                        	add    r8,r10
    138f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1394:	4d 01 d0                                        	add    r8,r10
    1397:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    139c:	4d 01 d0                                        	add    r8,r10
    139f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    13a4:	4d 01 d0                                        	add    r8,r10
    13a7:	41 f6 c1 01                                     	test   r9b,0x1
    13ab:	75 09                                           	jne    13b6 <choose_0>
    13ad:	4c 8d 15 0c 00 00 00                            	lea    r10,[rip+0xc]        # 13c0 <target_a_0>
    13b4:	eb 07                                           	jmp    13bd <dispatch_0>

00000000000013b6 <choose_0>:
    13b6:	4c 8d 15 09 00 00 00                            	lea    r10,[rip+0x9]        # 13c6 <target_b_0>

00000000000013bd <dispatch_0>:
    13bd:	41 ff e2                                        	jmp    r10

00000000000013c0 <target_a_0>:
    13c0:	49 83 c0 01                                     	add    r8,0x1
    13c4:	eb 04                                           	jmp    13ca <join_0>

00000000000013c6 <target_b_0>:
    13c6:	49 83 c0 02                                     	add    r8,0x2

00000000000013ca <join_0>:
    13ca:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    13cf:	4d 01 d0                                        	add    r8,r10
    13d2:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    13d7:	4d 01 d0                                        	add    r8,r10
    13da:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    13df:	4d 01 d0                                        	add    r8,r10
    13e2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    13e7:	4d 01 d0                                        	add    r8,r10
    13ea:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    13ef:	4d 01 d0                                        	add    r8,r10
    13f2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    13f7:	4d 01 d0                                        	add    r8,r10
    13fa:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    13ff:	4d 01 d0                                        	add    r8,r10
    1402:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1407:	4d 01 d0                                        	add    r8,r10
    140a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    140f:	4d 01 d0                                        	add    r8,r10
    1412:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1417:	4d 01 d0                                        	add    r8,r10
    141a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    141f:	4d 01 d0                                        	add    r8,r10
    1422:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1427:	4d 01 d0                                        	add    r8,r10
    142a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    142f:	4d 01 d0                                        	add    r8,r10
    1432:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1437:	4d 01 d0                                        	add    r8,r10
    143a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    143f:	4d 01 d0                                        	add    r8,r10
    1442:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1447:	4d 01 d0                                        	add    r8,r10
    144a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    144f:	4d 01 d0                                        	add    r8,r10
    1452:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1457:	4d 01 d0                                        	add    r8,r10
    145a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    145f:	4d 01 d0                                        	add    r8,r10
    1462:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1467:	4d 01 d0                                        	add    r8,r10
    146a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    146f:	4d 01 d0                                        	add    r8,r10
    1472:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1477:	4d 01 d0                                        	add    r8,r10
    147a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    147f:	4d 01 d0                                        	add    r8,r10
    1482:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1487:	4d 01 d0                                        	add    r8,r10
    148a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    148f:	4d 01 d0                                        	add    r8,r10
    1492:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1497:	4d 01 d0                                        	add    r8,r10
    149a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    149f:	4d 01 d0                                        	add    r8,r10
    14a2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    14a7:	4d 01 d0                                        	add    r8,r10
    14aa:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    14af:	4d 01 d0                                        	add    r8,r10
    14b2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    14b7:	4d 01 d0                                        	add    r8,r10
    14ba:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    14bf:	4d 01 d0                                        	add    r8,r10
    14c2:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    14c7:	4d 01 d0                                        	add    r8,r10
    14ca:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    14cf:	4d 01 d0                                        	add    r8,r10
    14d2:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    14d7:	4d 01 d0                                        	add    r8,r10
    14da:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    14df:	4d 01 d0                                        	add    r8,r10
    14e2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    14e7:	4d 01 d0                                        	add    r8,r10
    14ea:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    14ef:	4d 01 d0                                        	add    r8,r10
    14f2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    14f7:	4d 01 d0                                        	add    r8,r10
    14fa:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    14ff:	4d 01 d0                                        	add    r8,r10
    1502:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1507:	4d 01 d0                                        	add    r8,r10
    150a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    150f:	4d 01 d0                                        	add    r8,r10
    1512:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1517:	4d 01 d0                                        	add    r8,r10
    151a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    151f:	4d 01 d0                                        	add    r8,r10
    1522:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1527:	4d 01 d0                                        	add    r8,r10
    152a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    152f:	4d 01 d0                                        	add    r8,r10
    1532:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1537:	4d 01 d0                                        	add    r8,r10
    153a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    153f:	4d 01 d0                                        	add    r8,r10
    1542:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1547:	4d 01 d0                                        	add    r8,r10
    154a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    154f:	4d 01 d0                                        	add    r8,r10
    1552:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1557:	4d 01 d0                                        	add    r8,r10
    155a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    155f:	4d 01 d0                                        	add    r8,r10
    1562:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1567:	4d 01 d0                                        	add    r8,r10
    156a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    156f:	4d 01 d0                                        	add    r8,r10
    1572:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1577:	4d 01 d0                                        	add    r8,r10
    157a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    157f:	4d 01 d0                                        	add    r8,r10
    1582:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1587:	4d 01 d0                                        	add    r8,r10
    158a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    158f:	4d 01 d0                                        	add    r8,r10
    1592:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1597:	4d 01 d0                                        	add    r8,r10
    159a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    159f:	4d 01 d0                                        	add    r8,r10
    15a2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    15a7:	4d 01 d0                                        	add    r8,r10
    15aa:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    15af:	4d 01 d0                                        	add    r8,r10
    15b2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    15b7:	4d 01 d0                                        	add    r8,r10
    15ba:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    15bf:	4d 01 d0                                        	add    r8,r10
    15c2:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    15c7:	4d 01 d0                                        	add    r8,r10
    15ca:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    15cf:	4d 01 d0                                        	add    r8,r10
    15d2:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    15d7:	4d 01 d0                                        	add    r8,r10
    15da:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    15df:	4d 01 d0                                        	add    r8,r10
    15e2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    15e7:	4d 01 d0                                        	add    r8,r10
    15ea:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    15ef:	4d 01 d0                                        	add    r8,r10
    15f2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    15f7:	4d 01 d0                                        	add    r8,r10
    15fa:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    15ff:	4d 01 d0                                        	add    r8,r10
    1602:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1607:	4d 01 d0                                        	add    r8,r10
    160a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    160f:	4d 01 d0                                        	add    r8,r10
    1612:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1617:	4d 01 d0                                        	add    r8,r10
    161a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    161f:	4d 01 d0                                        	add    r8,r10
    1622:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1627:	4d 01 d0                                        	add    r8,r10
    162a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    162f:	4d 01 d0                                        	add    r8,r10
    1632:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1637:	4d 01 d0                                        	add    r8,r10
    163a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    163f:	4d 01 d0                                        	add    r8,r10
    1642:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1647:	4d 01 d0                                        	add    r8,r10
    164a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    164f:	4d 01 d0                                        	add    r8,r10
    1652:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1657:	4d 01 d0                                        	add    r8,r10
    165a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    165f:	4d 01 d0                                        	add    r8,r10
    1662:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1667:	4d 01 d0                                        	add    r8,r10
    166a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    166f:	4d 01 d0                                        	add    r8,r10
    1672:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1677:	4d 01 d0                                        	add    r8,r10
    167a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    167f:	4d 01 d0                                        	add    r8,r10
    1682:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1687:	4d 01 d0                                        	add    r8,r10
    168a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    168f:	4d 01 d0                                        	add    r8,r10
    1692:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1697:	4d 01 d0                                        	add    r8,r10
    169a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    169f:	4d 01 d0                                        	add    r8,r10
    16a2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    16a7:	4d 01 d0                                        	add    r8,r10
    16aa:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    16af:	4d 01 d0                                        	add    r8,r10
    16b2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    16b7:	4d 01 d0                                        	add    r8,r10
    16ba:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    16bf:	4d 01 d0                                        	add    r8,r10
    16c2:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    16c7:	4d 01 d0                                        	add    r8,r10
    16ca:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    16cf:	4d 01 d0                                        	add    r8,r10
    16d2:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    16d7:	4d 01 d0                                        	add    r8,r10
    16da:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    16df:	4d 01 d0                                        	add    r8,r10
    16e2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    16e7:	4d 01 d0                                        	add    r8,r10
    16ea:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    16ef:	4d 01 d0                                        	add    r8,r10
    16f2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    16f7:	4d 01 d0                                        	add    r8,r10
    16fa:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    16ff:	4d 01 d0                                        	add    r8,r10
    1702:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1707:	4d 01 d0                                        	add    r8,r10
    170a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    170f:	4d 01 d0                                        	add    r8,r10
    1712:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1717:	4d 01 d0                                        	add    r8,r10
    171a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    171f:	4d 01 d0                                        	add    r8,r10
    1722:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1727:	4d 01 d0                                        	add    r8,r10
    172a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    172f:	4d 01 d0                                        	add    r8,r10
    1732:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1737:	4d 01 d0                                        	add    r8,r10
    173a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    173f:	4d 01 d0                                        	add    r8,r10
    1742:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1747:	4d 01 d0                                        	add    r8,r10
    174a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    174f:	4d 01 d0                                        	add    r8,r10
    1752:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1757:	4d 01 d0                                        	add    r8,r10
    175a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    175f:	4d 01 d0                                        	add    r8,r10
    1762:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1767:	4d 01 d0                                        	add    r8,r10
    176a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    176f:	4d 01 d0                                        	add    r8,r10
    1772:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1777:	4d 01 d0                                        	add    r8,r10
    177a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    177f:	4d 01 d0                                        	add    r8,r10
    1782:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1787:	4d 01 d0                                        	add    r8,r10
    178a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    178f:	4d 01 d0                                        	add    r8,r10
    1792:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1797:	4d 01 d0                                        	add    r8,r10
    179a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    179f:	4d 01 d0                                        	add    r8,r10
    17a2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    17a7:	4d 01 d0                                        	add    r8,r10
    17aa:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    17af:	4d 01 d0                                        	add    r8,r10
    17b2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    17b7:	4d 01 d0                                        	add    r8,r10
    17ba:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    17bf:	4d 01 d0                                        	add    r8,r10
    17c2:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    17c7:	4d 01 d0                                        	add    r8,r10
    17ca:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    17cf:	4d 01 d0                                        	add    r8,r10
    17d2:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    17d7:	4d 01 d0                                        	add    r8,r10
    17da:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    17df:	4d 01 d0                                        	add    r8,r10
    17e2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    17e7:	4d 01 d0                                        	add    r8,r10
    17ea:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    17ef:	4d 01 d0                                        	add    r8,r10
    17f2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    17f7:	4d 01 d0                                        	add    r8,r10
    17fa:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    17ff:	4d 01 d0                                        	add    r8,r10
    1802:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1807:	4d 01 d0                                        	add    r8,r10
    180a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    180f:	4d 01 d0                                        	add    r8,r10
    1812:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1817:	4d 01 d0                                        	add    r8,r10
    181a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    181f:	4d 01 d0                                        	add    r8,r10
    1822:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1827:	4d 01 d0                                        	add    r8,r10
    182a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    182f:	4d 01 d0                                        	add    r8,r10
    1832:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1837:	4d 01 d0                                        	add    r8,r10
    183a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    183f:	4d 01 d0                                        	add    r8,r10
    1842:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1847:	4d 01 d0                                        	add    r8,r10
    184a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    184f:	4d 01 d0                                        	add    r8,r10
    1852:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1857:	4d 01 d0                                        	add    r8,r10
    185a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    185f:	4d 01 d0                                        	add    r8,r10
    1862:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1867:	4d 01 d0                                        	add    r8,r10
    186a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    186f:	4d 01 d0                                        	add    r8,r10
    1872:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1877:	4d 01 d0                                        	add    r8,r10
    187a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    187f:	4d 01 d0                                        	add    r8,r10
    1882:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1887:	4d 01 d0                                        	add    r8,r10
    188a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    188f:	4d 01 d0                                        	add    r8,r10
    1892:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1897:	4d 01 d0                                        	add    r8,r10
    189a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    189f:	4d 01 d0                                        	add    r8,r10
    18a2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    18a7:	4d 01 d0                                        	add    r8,r10
    18aa:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    18af:	4d 01 d0                                        	add    r8,r10
    18b2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    18b7:	4d 01 d0                                        	add    r8,r10
    18ba:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    18bf:	4d 01 d0                                        	add    r8,r10
    18c2:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    18c7:	4d 01 d0                                        	add    r8,r10
    18ca:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    18cf:	4d 01 d0                                        	add    r8,r10
    18d2:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    18d7:	4d 01 d0                                        	add    r8,r10
    18da:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    18df:	4d 01 d0                                        	add    r8,r10
    18e2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    18e7:	4d 01 d0                                        	add    r8,r10
    18ea:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    18ef:	4d 01 d0                                        	add    r8,r10
    18f2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    18f7:	4d 01 d0                                        	add    r8,r10
    18fa:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    18ff:	4d 01 d0                                        	add    r8,r10
    1902:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1907:	4d 01 d0                                        	add    r8,r10
    190a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    190f:	4d 01 d0                                        	add    r8,r10
    1912:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1917:	4d 01 d0                                        	add    r8,r10
    191a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    191f:	4d 01 d0                                        	add    r8,r10
    1922:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1927:	4d 01 d0                                        	add    r8,r10
    192a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    192f:	4d 01 d0                                        	add    r8,r10
    1932:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1937:	4d 01 d0                                        	add    r8,r10
    193a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    193f:	4d 01 d0                                        	add    r8,r10
    1942:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1947:	4d 01 d0                                        	add    r8,r10
    194a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    194f:	4d 01 d0                                        	add    r8,r10
    1952:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1957:	4d 01 d0                                        	add    r8,r10
    195a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    195f:	4d 01 d0                                        	add    r8,r10
    1962:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1967:	4d 01 d0                                        	add    r8,r10
    196a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    196f:	4d 01 d0                                        	add    r8,r10
    1972:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1977:	4d 01 d0                                        	add    r8,r10
    197a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    197f:	4d 01 d0                                        	add    r8,r10
    1982:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1987:	4d 01 d0                                        	add    r8,r10
    198a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    198f:	4d 01 d0                                        	add    r8,r10
    1992:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1997:	4d 01 d0                                        	add    r8,r10
    199a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    199f:	4d 01 d0                                        	add    r8,r10
    19a2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    19a7:	4d 01 d0                                        	add    r8,r10
    19aa:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    19af:	4d 01 d0                                        	add    r8,r10
    19b2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    19b7:	4d 01 d0                                        	add    r8,r10
    19ba:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    19bf:	4d 01 d0                                        	add    r8,r10
    19c2:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    19c7:	4d 01 d0                                        	add    r8,r10
    19ca:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    19cf:	4d 01 d0                                        	add    r8,r10
    19d2:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    19d7:	4d 01 d0                                        	add    r8,r10
    19da:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    19df:	4d 01 d0                                        	add    r8,r10
    19e2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    19e7:	4d 01 d0                                        	add    r8,r10
    19ea:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    19ef:	4d 01 d0                                        	add    r8,r10
    19f2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    19f7:	4d 01 d0                                        	add    r8,r10
    19fa:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    19ff:	4d 01 d0                                        	add    r8,r10
    1a02:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1a07:	4d 01 d0                                        	add    r8,r10
    1a0a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1a0f:	4d 01 d0                                        	add    r8,r10
    1a12:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1a17:	4d 01 d0                                        	add    r8,r10
    1a1a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1a1f:	4d 01 d0                                        	add    r8,r10
    1a22:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1a27:	4d 01 d0                                        	add    r8,r10
    1a2a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1a2f:	4d 01 d0                                        	add    r8,r10
    1a32:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1a37:	4d 01 d0                                        	add    r8,r10
    1a3a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1a3f:	4d 01 d0                                        	add    r8,r10
    1a42:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1a47:	4d 01 d0                                        	add    r8,r10
    1a4a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1a4f:	4d 01 d0                                        	add    r8,r10
    1a52:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1a57:	4d 01 d0                                        	add    r8,r10
    1a5a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1a5f:	4d 01 d0                                        	add    r8,r10
    1a62:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1a67:	4d 01 d0                                        	add    r8,r10
    1a6a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1a6f:	4d 01 d0                                        	add    r8,r10
    1a72:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1a77:	4d 01 d0                                        	add    r8,r10
    1a7a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1a7f:	4d 01 d0                                        	add    r8,r10
    1a82:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1a87:	4d 01 d0                                        	add    r8,r10
    1a8a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1a8f:	4d 01 d0                                        	add    r8,r10
    1a92:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1a97:	4d 01 d0                                        	add    r8,r10
    1a9a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1a9f:	4d 01 d0                                        	add    r8,r10
    1aa2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1aa7:	4d 01 d0                                        	add    r8,r10
    1aaa:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1aaf:	4d 01 d0                                        	add    r8,r10
    1ab2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1ab7:	4d 01 d0                                        	add    r8,r10
    1aba:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1abf:	4d 01 d0                                        	add    r8,r10
    1ac2:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1ac7:	4d 01 d0                                        	add    r8,r10
    1aca:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1acf:	4d 01 d0                                        	add    r8,r10
    1ad2:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1ad7:	4d 01 d0                                        	add    r8,r10
    1ada:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1adf:	4d 01 d0                                        	add    r8,r10
    1ae2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1ae7:	4d 01 d0                                        	add    r8,r10
    1aea:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1aef:	4d 01 d0                                        	add    r8,r10
    1af2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1af7:	4d 01 d0                                        	add    r8,r10
    1afa:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1aff:	4d 01 d0                                        	add    r8,r10
    1b02:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1b07:	4d 01 d0                                        	add    r8,r10
    1b0a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1b0f:	4d 01 d0                                        	add    r8,r10
    1b12:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1b17:	4d 01 d0                                        	add    r8,r10
    1b1a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1b1f:	4d 01 d0                                        	add    r8,r10
    1b22:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1b27:	4d 01 d0                                        	add    r8,r10
    1b2a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1b2f:	4d 01 d0                                        	add    r8,r10
    1b32:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1b37:	4d 01 d0                                        	add    r8,r10
    1b3a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1b3f:	4d 01 d0                                        	add    r8,r10
    1b42:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1b47:	4d 01 d0                                        	add    r8,r10
    1b4a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1b4f:	4d 01 d0                                        	add    r8,r10
    1b52:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1b57:	4d 01 d0                                        	add    r8,r10
    1b5a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1b5f:	4d 01 d0                                        	add    r8,r10
    1b62:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1b67:	4d 01 d0                                        	add    r8,r10
    1b6a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1b6f:	4d 01 d0                                        	add    r8,r10
    1b72:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1b77:	4d 01 d0                                        	add    r8,r10
    1b7a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1b7f:	4d 01 d0                                        	add    r8,r10
    1b82:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1b87:	4d 01 d0                                        	add    r8,r10
    1b8a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1b8f:	4d 01 d0                                        	add    r8,r10
    1b92:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1b97:	4d 01 d0                                        	add    r8,r10
    1b9a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1b9f:	4d 01 d0                                        	add    r8,r10
    1ba2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1ba7:	4d 01 d0                                        	add    r8,r10
    1baa:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1baf:	4d 01 d0                                        	add    r8,r10
    1bb2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1bb7:	4d 01 d0                                        	add    r8,r10
    1bba:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1bbf:	4d 01 d0                                        	add    r8,r10
    1bc2:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1bc7:	4d 01 d0                                        	add    r8,r10
    1bca:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1bcf:	4d 01 d0                                        	add    r8,r10
    1bd2:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1bd7:	4d 01 d0                                        	add    r8,r10
    1bda:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1bdf:	4d 01 d0                                        	add    r8,r10
    1be2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1be7:	4d 01 d0                                        	add    r8,r10
    1bea:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1bef:	4d 01 d0                                        	add    r8,r10
    1bf2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1bf7:	4d 01 d0                                        	add    r8,r10
    1bfa:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1bff:	4d 01 d0                                        	add    r8,r10
    1c02:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1c07:	4d 01 d0                                        	add    r8,r10
    1c0a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1c0f:	4d 01 d0                                        	add    r8,r10
    1c12:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1c17:	4d 01 d0                                        	add    r8,r10
    1c1a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1c1f:	4d 01 d0                                        	add    r8,r10
    1c22:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1c27:	4d 01 d0                                        	add    r8,r10
    1c2a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1c2f:	4d 01 d0                                        	add    r8,r10
    1c32:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1c37:	4d 01 d0                                        	add    r8,r10
    1c3a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1c3f:	4d 01 d0                                        	add    r8,r10
    1c42:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1c47:	4d 01 d0                                        	add    r8,r10
    1c4a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1c4f:	4d 01 d0                                        	add    r8,r10
    1c52:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1c57:	4d 01 d0                                        	add    r8,r10
    1c5a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1c5f:	4d 01 d0                                        	add    r8,r10
    1c62:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1c67:	4d 01 d0                                        	add    r8,r10
    1c6a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1c6f:	4d 01 d0                                        	add    r8,r10
    1c72:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1c77:	4d 01 d0                                        	add    r8,r10
    1c7a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1c7f:	4d 01 d0                                        	add    r8,r10
    1c82:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1c87:	4d 01 d0                                        	add    r8,r10
    1c8a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1c8f:	4d 01 d0                                        	add    r8,r10
    1c92:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1c97:	4d 01 d0                                        	add    r8,r10
    1c9a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1c9f:	4d 01 d0                                        	add    r8,r10
    1ca2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1ca7:	4d 01 d0                                        	add    r8,r10
    1caa:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1caf:	4d 01 d0                                        	add    r8,r10
    1cb2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1cb7:	4d 01 d0                                        	add    r8,r10
    1cba:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1cbf:	4d 01 d0                                        	add    r8,r10
    1cc2:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1cc7:	4d 01 d0                                        	add    r8,r10
    1cca:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1ccf:	4d 01 d0                                        	add    r8,r10
    1cd2:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1cd7:	4d 01 d0                                        	add    r8,r10
    1cda:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1cdf:	4d 01 d0                                        	add    r8,r10
    1ce2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1ce7:	4d 01 d0                                        	add    r8,r10
    1cea:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1cef:	4d 01 d0                                        	add    r8,r10
    1cf2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1cf7:	4d 01 d0                                        	add    r8,r10
    1cfa:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1cff:	4d 01 d0                                        	add    r8,r10
    1d02:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1d07:	4d 01 d0                                        	add    r8,r10
    1d0a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1d0f:	4d 01 d0                                        	add    r8,r10
    1d12:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1d17:	4d 01 d0                                        	add    r8,r10
    1d1a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1d1f:	4d 01 d0                                        	add    r8,r10
    1d22:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1d27:	4d 01 d0                                        	add    r8,r10
    1d2a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1d2f:	4d 01 d0                                        	add    r8,r10
    1d32:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1d37:	4d 01 d0                                        	add    r8,r10
    1d3a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1d3f:	4d 01 d0                                        	add    r8,r10
    1d42:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1d47:	4d 01 d0                                        	add    r8,r10
    1d4a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1d4f:	4d 01 d0                                        	add    r8,r10
    1d52:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1d57:	4d 01 d0                                        	add    r8,r10
    1d5a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1d5f:	4d 01 d0                                        	add    r8,r10
    1d62:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1d67:	4d 01 d0                                        	add    r8,r10
    1d6a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1d6f:	4d 01 d0                                        	add    r8,r10
    1d72:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1d77:	4d 01 d0                                        	add    r8,r10
    1d7a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1d7f:	4d 01 d0                                        	add    r8,r10
    1d82:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1d87:	4d 01 d0                                        	add    r8,r10
    1d8a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1d8f:	4d 01 d0                                        	add    r8,r10
    1d92:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1d97:	4d 01 d0                                        	add    r8,r10
    1d9a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1d9f:	4d 01 d0                                        	add    r8,r10
    1da2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1da7:	4d 01 d0                                        	add    r8,r10
    1daa:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1daf:	4d 01 d0                                        	add    r8,r10
    1db2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1db7:	4d 01 d0                                        	add    r8,r10
    1dba:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1dbf:	4d 01 d0                                        	add    r8,r10
    1dc2:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1dc7:	4d 01 d0                                        	add    r8,r10
    1dca:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1dcf:	4d 01 d0                                        	add    r8,r10
    1dd2:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1dd7:	4d 01 d0                                        	add    r8,r10
    1dda:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1ddf:	4d 01 d0                                        	add    r8,r10
    1de2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1de7:	4d 01 d0                                        	add    r8,r10
    1dea:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1def:	4d 01 d0                                        	add    r8,r10
    1df2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1df7:	4d 01 d0                                        	add    r8,r10
    1dfa:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1dff:	4d 01 d0                                        	add    r8,r10
    1e02:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1e07:	4d 01 d0                                        	add    r8,r10
    1e0a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1e0f:	4d 01 d0                                        	add    r8,r10
    1e12:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1e17:	4d 01 d0                                        	add    r8,r10
    1e1a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1e1f:	4d 01 d0                                        	add    r8,r10
    1e22:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1e27:	4d 01 d0                                        	add    r8,r10
    1e2a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1e2f:	4d 01 d0                                        	add    r8,r10
    1e32:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1e37:	4d 01 d0                                        	add    r8,r10
    1e3a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1e3f:	4d 01 d0                                        	add    r8,r10
    1e42:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1e47:	4d 01 d0                                        	add    r8,r10
    1e4a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1e4f:	4d 01 d0                                        	add    r8,r10
    1e52:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1e57:	4d 01 d0                                        	add    r8,r10
    1e5a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1e5f:	4d 01 d0                                        	add    r8,r10
    1e62:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1e67:	4d 01 d0                                        	add    r8,r10
    1e6a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1e6f:	4d 01 d0                                        	add    r8,r10
    1e72:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1e77:	4d 01 d0                                        	add    r8,r10
    1e7a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1e7f:	4d 01 d0                                        	add    r8,r10
    1e82:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1e87:	4d 01 d0                                        	add    r8,r10
    1e8a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1e8f:	4d 01 d0                                        	add    r8,r10
    1e92:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1e97:	4d 01 d0                                        	add    r8,r10
    1e9a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1e9f:	4d 01 d0                                        	add    r8,r10
    1ea2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1ea7:	4d 01 d0                                        	add    r8,r10
    1eaa:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1eaf:	4d 01 d0                                        	add    r8,r10
    1eb2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1eb7:	4d 01 d0                                        	add    r8,r10
    1eba:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1ebf:	4d 01 d0                                        	add    r8,r10
    1ec2:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1ec7:	4d 01 d0                                        	add    r8,r10
    1eca:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1ecf:	4d 01 d0                                        	add    r8,r10
    1ed2:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1ed7:	4d 01 d0                                        	add    r8,r10
    1eda:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1edf:	4d 01 d0                                        	add    r8,r10
    1ee2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1ee7:	4d 01 d0                                        	add    r8,r10
    1eea:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1eef:	4d 01 d0                                        	add    r8,r10
    1ef2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1ef7:	4d 01 d0                                        	add    r8,r10
    1efa:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1eff:	4d 01 d0                                        	add    r8,r10
    1f02:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1f07:	4d 01 d0                                        	add    r8,r10
    1f0a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1f0f:	4d 01 d0                                        	add    r8,r10
    1f12:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1f17:	4d 01 d0                                        	add    r8,r10
    1f1a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1f1f:	4d 01 d0                                        	add    r8,r10
    1f22:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1f27:	4d 01 d0                                        	add    r8,r10
    1f2a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1f2f:	4d 01 d0                                        	add    r8,r10
    1f32:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1f37:	4d 01 d0                                        	add    r8,r10
    1f3a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1f3f:	4d 01 d0                                        	add    r8,r10
    1f42:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1f47:	4d 01 d0                                        	add    r8,r10
    1f4a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1f4f:	4d 01 d0                                        	add    r8,r10
    1f52:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1f57:	4d 01 d0                                        	add    r8,r10
    1f5a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1f5f:	4d 01 d0                                        	add    r8,r10
    1f62:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1f67:	4d 01 d0                                        	add    r8,r10
    1f6a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1f6f:	4d 01 d0                                        	add    r8,r10
    1f72:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1f77:	4d 01 d0                                        	add    r8,r10
    1f7a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1f7f:	4d 01 d0                                        	add    r8,r10
    1f82:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1f87:	4d 01 d0                                        	add    r8,r10
    1f8a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1f8f:	4d 01 d0                                        	add    r8,r10
    1f92:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1f97:	4d 01 d0                                        	add    r8,r10
    1f9a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1f9f:	4d 01 d0                                        	add    r8,r10
    1fa2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1fa7:	4d 01 d0                                        	add    r8,r10
    1faa:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1faf:	4d 01 d0                                        	add    r8,r10
    1fb2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1fb7:	4d 01 d0                                        	add    r8,r10
    1fba:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1fbf:	4d 01 d0                                        	add    r8,r10
    1fc2:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    1fc7:	4d 01 d0                                        	add    r8,r10
    1fca:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    1fcf:	4d 01 d0                                        	add    r8,r10
    1fd2:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    1fd7:	4d 01 d0                                        	add    r8,r10
    1fda:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    1fdf:	4d 01 d0                                        	add    r8,r10
    1fe2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    1fe7:	4d 01 d0                                        	add    r8,r10
    1fea:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    1fef:	4d 01 d0                                        	add    r8,r10
    1ff2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    1ff7:	4d 01 d0                                        	add    r8,r10
    1ffa:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    1fff:	4d 01 d0                                        	add    r8,r10
    2002:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2007:	4d 01 d0                                        	add    r8,r10
    200a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    200f:	4d 01 d0                                        	add    r8,r10
    2012:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2017:	4d 01 d0                                        	add    r8,r10
    201a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    201f:	4d 01 d0                                        	add    r8,r10
    2022:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2027:	4d 01 d0                                        	add    r8,r10
    202a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    202f:	4d 01 d0                                        	add    r8,r10
    2032:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2037:	4d 01 d0                                        	add    r8,r10
    203a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    203f:	4d 01 d0                                        	add    r8,r10
    2042:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2047:	4d 01 d0                                        	add    r8,r10
    204a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    204f:	4d 01 d0                                        	add    r8,r10
    2052:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2057:	4d 01 d0                                        	add    r8,r10
    205a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    205f:	4d 01 d0                                        	add    r8,r10
    2062:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2067:	4d 01 d0                                        	add    r8,r10
    206a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    206f:	4d 01 d0                                        	add    r8,r10
    2072:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2077:	4d 01 d0                                        	add    r8,r10
    207a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    207f:	4d 01 d0                                        	add    r8,r10
    2082:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2087:	4d 01 d0                                        	add    r8,r10
    208a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    208f:	4d 01 d0                                        	add    r8,r10
    2092:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2097:	4d 01 d0                                        	add    r8,r10
    209a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    209f:	4d 01 d0                                        	add    r8,r10
    20a2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    20a7:	4d 01 d0                                        	add    r8,r10
    20aa:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    20af:	4d 01 d0                                        	add    r8,r10
    20b2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    20b7:	4d 01 d0                                        	add    r8,r10
    20ba:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    20bf:	4d 01 d0                                        	add    r8,r10
    20c2:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    20c7:	4d 01 d0                                        	add    r8,r10
    20ca:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    20cf:	4d 01 d0                                        	add    r8,r10
    20d2:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    20d7:	4d 01 d0                                        	add    r8,r10
    20da:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    20df:	4d 01 d0                                        	add    r8,r10
    20e2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    20e7:	4d 01 d0                                        	add    r8,r10
    20ea:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    20ef:	4d 01 d0                                        	add    r8,r10
    20f2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    20f7:	4d 01 d0                                        	add    r8,r10
    20fa:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    20ff:	4d 01 d0                                        	add    r8,r10
    2102:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2107:	4d 01 d0                                        	add    r8,r10
    210a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    210f:	4d 01 d0                                        	add    r8,r10
    2112:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2117:	4d 01 d0                                        	add    r8,r10
    211a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    211f:	4d 01 d0                                        	add    r8,r10
    2122:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2127:	4d 01 d0                                        	add    r8,r10
    212a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    212f:	4d 01 d0                                        	add    r8,r10
    2132:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2137:	4d 01 d0                                        	add    r8,r10
    213a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    213f:	4d 01 d0                                        	add    r8,r10
    2142:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2147:	4d 01 d0                                        	add    r8,r10
    214a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    214f:	4d 01 d0                                        	add    r8,r10
    2152:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2157:	4d 01 d0                                        	add    r8,r10
    215a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    215f:	4d 01 d0                                        	add    r8,r10
    2162:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2167:	4d 01 d0                                        	add    r8,r10
    216a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    216f:	4d 01 d0                                        	add    r8,r10
    2172:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2177:	4d 01 d0                                        	add    r8,r10
    217a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    217f:	4d 01 d0                                        	add    r8,r10
    2182:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2187:	4d 01 d0                                        	add    r8,r10
    218a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    218f:	4d 01 d0                                        	add    r8,r10
    2192:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2197:	4d 01 d0                                        	add    r8,r10
    219a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    219f:	4d 01 d0                                        	add    r8,r10
    21a2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    21a7:	4d 01 d0                                        	add    r8,r10
    21aa:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    21af:	4d 01 d0                                        	add    r8,r10
    21b2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    21b7:	4d 01 d0                                        	add    r8,r10
    21ba:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    21bf:	4d 01 d0                                        	add    r8,r10
    21c2:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    21c7:	4d 01 d0                                        	add    r8,r10
    21ca:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    21cf:	4d 01 d0                                        	add    r8,r10
    21d2:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    21d7:	4d 01 d0                                        	add    r8,r10
    21da:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    21df:	4d 01 d0                                        	add    r8,r10
    21e2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    21e7:	4d 01 d0                                        	add    r8,r10
    21ea:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    21ef:	4d 01 d0                                        	add    r8,r10
    21f2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    21f7:	4d 01 d0                                        	add    r8,r10
    21fa:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    21ff:	4d 01 d0                                        	add    r8,r10
    2202:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2207:	4d 01 d0                                        	add    r8,r10
    220a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    220f:	4d 01 d0                                        	add    r8,r10
    2212:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2217:	4d 01 d0                                        	add    r8,r10
    221a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    221f:	4d 01 d0                                        	add    r8,r10
    2222:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2227:	4d 01 d0                                        	add    r8,r10
    222a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    222f:	4d 01 d0                                        	add    r8,r10
    2232:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2237:	4d 01 d0                                        	add    r8,r10
    223a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    223f:	4d 01 d0                                        	add    r8,r10
    2242:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2247:	4d 01 d0                                        	add    r8,r10
    224a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    224f:	4d 01 d0                                        	add    r8,r10
    2252:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2257:	4d 01 d0                                        	add    r8,r10
    225a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    225f:	4d 01 d0                                        	add    r8,r10
    2262:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2267:	4d 01 d0                                        	add    r8,r10
    226a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    226f:	4d 01 d0                                        	add    r8,r10
    2272:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2277:	4d 01 d0                                        	add    r8,r10
    227a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    227f:	4d 01 d0                                        	add    r8,r10
    2282:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2287:	4d 01 d0                                        	add    r8,r10
    228a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    228f:	4d 01 d0                                        	add    r8,r10
    2292:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2297:	4d 01 d0                                        	add    r8,r10
    229a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    229f:	4d 01 d0                                        	add    r8,r10
    22a2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    22a7:	4d 01 d0                                        	add    r8,r10
    22aa:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    22af:	4d 01 d0                                        	add    r8,r10
    22b2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    22b7:	4d 01 d0                                        	add    r8,r10
    22ba:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    22bf:	4d 01 d0                                        	add    r8,r10
    22c2:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    22c7:	4d 01 d0                                        	add    r8,r10
    22ca:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    22cf:	4d 01 d0                                        	add    r8,r10
    22d2:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    22d7:	4d 01 d0                                        	add    r8,r10
    22da:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    22df:	4d 01 d0                                        	add    r8,r10
    22e2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    22e7:	4d 01 d0                                        	add    r8,r10
    22ea:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    22ef:	4d 01 d0                                        	add    r8,r10
    22f2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    22f7:	4d 01 d0                                        	add    r8,r10
    22fa:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    22ff:	4d 01 d0                                        	add    r8,r10
    2302:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2307:	4d 01 d0                                        	add    r8,r10
    230a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    230f:	4d 01 d0                                        	add    r8,r10
    2312:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2317:	4d 01 d0                                        	add    r8,r10
    231a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    231f:	4d 01 d0                                        	add    r8,r10
    2322:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2327:	4d 01 d0                                        	add    r8,r10
    232a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    232f:	4d 01 d0                                        	add    r8,r10
    2332:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2337:	4d 01 d0                                        	add    r8,r10
    233a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    233f:	4d 01 d0                                        	add    r8,r10
    2342:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2347:	4d 01 d0                                        	add    r8,r10
    234a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    234f:	4d 01 d0                                        	add    r8,r10
    2352:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2357:	4d 01 d0                                        	add    r8,r10
    235a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    235f:	4d 01 d0                                        	add    r8,r10
    2362:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2367:	4d 01 d0                                        	add    r8,r10
    236a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    236f:	4d 01 d0                                        	add    r8,r10
    2372:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2377:	4d 01 d0                                        	add    r8,r10
    237a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    237f:	4d 01 d0                                        	add    r8,r10
    2382:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2387:	4d 01 d0                                        	add    r8,r10
    238a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    238f:	4d 01 d0                                        	add    r8,r10
    2392:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2397:	4d 01 d0                                        	add    r8,r10
    239a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    239f:	4d 01 d0                                        	add    r8,r10
    23a2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    23a7:	4d 01 d0                                        	add    r8,r10
    23aa:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    23af:	4d 01 d0                                        	add    r8,r10
    23b2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    23b7:	4d 01 d0                                        	add    r8,r10
    23ba:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    23bf:	4d 01 d0                                        	add    r8,r10
    23c2:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    23c7:	4d 01 d0                                        	add    r8,r10
    23ca:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    23cf:	4d 01 d0                                        	add    r8,r10
    23d2:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    23d7:	4d 01 d0                                        	add    r8,r10
    23da:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    23df:	4d 01 d0                                        	add    r8,r10
    23e2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    23e7:	4d 01 d0                                        	add    r8,r10
    23ea:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    23ef:	4d 01 d0                                        	add    r8,r10
    23f2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    23f7:	4d 01 d0                                        	add    r8,r10
    23fa:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    23ff:	4d 01 d0                                        	add    r8,r10
    2402:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2407:	4d 01 d0                                        	add    r8,r10
    240a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    240f:	4d 01 d0                                        	add    r8,r10
    2412:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2417:	4d 01 d0                                        	add    r8,r10
    241a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    241f:	4d 01 d0                                        	add    r8,r10
    2422:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2427:	4d 01 d0                                        	add    r8,r10
    242a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    242f:	4d 01 d0                                        	add    r8,r10
    2432:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2437:	4d 01 d0                                        	add    r8,r10
    243a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    243f:	4d 01 d0                                        	add    r8,r10
    2442:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2447:	4d 01 d0                                        	add    r8,r10
    244a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    244f:	4d 01 d0                                        	add    r8,r10
    2452:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2457:	4d 01 d0                                        	add    r8,r10
    245a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    245f:	4d 01 d0                                        	add    r8,r10
    2462:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2467:	4d 01 d0                                        	add    r8,r10
    246a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    246f:	4d 01 d0                                        	add    r8,r10
    2472:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2477:	4d 01 d0                                        	add    r8,r10
    247a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    247f:	4d 01 d0                                        	add    r8,r10
    2482:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2487:	4d 01 d0                                        	add    r8,r10
    248a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    248f:	4d 01 d0                                        	add    r8,r10
    2492:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2497:	4d 01 d0                                        	add    r8,r10
    249a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    249f:	4d 01 d0                                        	add    r8,r10
    24a2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    24a7:	4d 01 d0                                        	add    r8,r10
    24aa:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    24af:	4d 01 d0                                        	add    r8,r10
    24b2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    24b7:	4d 01 d0                                        	add    r8,r10
    24ba:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    24bf:	4d 01 d0                                        	add    r8,r10
    24c2:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    24c7:	4d 01 d0                                        	add    r8,r10
    24ca:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    24cf:	4d 01 d0                                        	add    r8,r10
    24d2:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    24d7:	4d 01 d0                                        	add    r8,r10
    24da:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    24df:	4d 01 d0                                        	add    r8,r10
    24e2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    24e7:	4d 01 d0                                        	add    r8,r10
    24ea:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    24ef:	4d 01 d0                                        	add    r8,r10
    24f2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    24f7:	4d 01 d0                                        	add    r8,r10
    24fa:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    24ff:	4d 01 d0                                        	add    r8,r10
    2502:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2507:	4d 01 d0                                        	add    r8,r10
    250a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    250f:	4d 01 d0                                        	add    r8,r10
    2512:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2517:	4d 01 d0                                        	add    r8,r10
    251a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    251f:	4d 01 d0                                        	add    r8,r10
    2522:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2527:	4d 01 d0                                        	add    r8,r10
    252a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    252f:	4d 01 d0                                        	add    r8,r10
    2532:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2537:	4d 01 d0                                        	add    r8,r10
    253a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    253f:	4d 01 d0                                        	add    r8,r10
    2542:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2547:	4d 01 d0                                        	add    r8,r10
    254a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    254f:	4d 01 d0                                        	add    r8,r10
    2552:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2557:	4d 01 d0                                        	add    r8,r10
    255a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    255f:	4d 01 d0                                        	add    r8,r10
    2562:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2567:	4d 01 d0                                        	add    r8,r10
    256a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    256f:	4d 01 d0                                        	add    r8,r10
    2572:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2577:	4d 01 d0                                        	add    r8,r10
    257a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    257f:	4d 01 d0                                        	add    r8,r10
    2582:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2587:	4d 01 d0                                        	add    r8,r10
    258a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    258f:	4d 01 d0                                        	add    r8,r10
    2592:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2597:	4d 01 d0                                        	add    r8,r10
    259a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    259f:	4d 01 d0                                        	add    r8,r10
    25a2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    25a7:	4d 01 d0                                        	add    r8,r10
    25aa:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    25af:	4d 01 d0                                        	add    r8,r10
    25b2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    25b7:	4d 01 d0                                        	add    r8,r10
    25ba:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    25bf:	4d 01 d0                                        	add    r8,r10
    25c2:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    25c7:	4d 01 d0                                        	add    r8,r10
    25ca:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    25cf:	4d 01 d0                                        	add    r8,r10
    25d2:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    25d7:	4d 01 d0                                        	add    r8,r10
    25da:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    25df:	4d 01 d0                                        	add    r8,r10
    25e2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    25e7:	4d 01 d0                                        	add    r8,r10
    25ea:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    25ef:	4d 01 d0                                        	add    r8,r10
    25f2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    25f7:	4d 01 d0                                        	add    r8,r10
    25fa:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    25ff:	4d 01 d0                                        	add    r8,r10
    2602:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2607:	4d 01 d0                                        	add    r8,r10
    260a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    260f:	4d 01 d0                                        	add    r8,r10
    2612:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2617:	4d 01 d0                                        	add    r8,r10
    261a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    261f:	4d 01 d0                                        	add    r8,r10
    2622:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2627:	4d 01 d0                                        	add    r8,r10
    262a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    262f:	4d 01 d0                                        	add    r8,r10
    2632:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2637:	4d 01 d0                                        	add    r8,r10
    263a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    263f:	4d 01 d0                                        	add    r8,r10
    2642:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2647:	4d 01 d0                                        	add    r8,r10
    264a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    264f:	4d 01 d0                                        	add    r8,r10
    2652:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2657:	4d 01 d0                                        	add    r8,r10
    265a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    265f:	4d 01 d0                                        	add    r8,r10
    2662:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2667:	4d 01 d0                                        	add    r8,r10
    266a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    266f:	4d 01 d0                                        	add    r8,r10
    2672:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2677:	4d 01 d0                                        	add    r8,r10
    267a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    267f:	4d 01 d0                                        	add    r8,r10
    2682:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2687:	4d 01 d0                                        	add    r8,r10
    268a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    268f:	4d 01 d0                                        	add    r8,r10
    2692:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2697:	4d 01 d0                                        	add    r8,r10
    269a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    269f:	4d 01 d0                                        	add    r8,r10
    26a2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    26a7:	4d 01 d0                                        	add    r8,r10
    26aa:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    26af:	4d 01 d0                                        	add    r8,r10
    26b2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    26b7:	4d 01 d0                                        	add    r8,r10
    26ba:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    26bf:	4d 01 d0                                        	add    r8,r10
    26c2:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    26c7:	4d 01 d0                                        	add    r8,r10
    26ca:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    26cf:	4d 01 d0                                        	add    r8,r10
    26d2:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    26d7:	4d 01 d0                                        	add    r8,r10
    26da:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    26df:	4d 01 d0                                        	add    r8,r10
    26e2:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    26e7:	4d 01 d0                                        	add    r8,r10
    26ea:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    26ef:	4d 01 d0                                        	add    r8,r10
    26f2:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    26f7:	4d 01 d0                                        	add    r8,r10
    26fa:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    26ff:	4d 01 d0                                        	add    r8,r10
    2702:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2707:	4d 01 d0                                        	add    r8,r10
    270a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    270f:	4d 01 d0                                        	add    r8,r10
    2712:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2717:	4d 01 d0                                        	add    r8,r10
    271a:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    271f:	4d 01 d0                                        	add    r8,r10
    2722:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2727:	4d 01 d0                                        	add    r8,r10
    272a:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    272f:	4d 01 d0                                        	add    r8,r10
    2732:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2737:	4d 01 d0                                        	add    r8,r10
    273a:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    273f:	4d 01 d0                                        	add    r8,r10
    2742:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2747:	4d 01 d0                                        	add    r8,r10
    274a:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    274f:	4d 01 d0                                        	add    r8,r10
    2752:	41 f6 c1 01                                     	test   r9b,0x1
    2756:	75 09                                           	jne    2761 <choose_1>
    2758:	4c 8d 15 0c 00 00 00                            	lea    r10,[rip+0xc]        # 276b <target_a_1>
    275f:	eb 07                                           	jmp    2768 <dispatch_1>

0000000000002761 <choose_1>:
    2761:	4c 8d 15 09 00 00 00                            	lea    r10,[rip+0x9]        # 2771 <target_b_1>

0000000000002768 <dispatch_1>:
    2768:	41 ff e2                                        	jmp    r10

000000000000276b <target_a_1>:
    276b:	49 83 c0 01                                     	add    r8,0x1
    276f:	eb 04                                           	jmp    2775 <join_1>

0000000000002771 <target_b_1>:
    2771:	49 83 c0 02                                     	add    r8,0x2

0000000000002775 <join_1>:
    2775:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    277a:	4d 01 d0                                        	add    r8,r10
    277d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2782:	4d 01 d0                                        	add    r8,r10
    2785:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    278a:	4d 01 d0                                        	add    r8,r10
    278d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2792:	4d 01 d0                                        	add    r8,r10
    2795:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    279a:	4d 01 d0                                        	add    r8,r10
    279d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    27a2:	4d 01 d0                                        	add    r8,r10
    27a5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    27aa:	4d 01 d0                                        	add    r8,r10
    27ad:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    27b2:	4d 01 d0                                        	add    r8,r10
    27b5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    27ba:	4d 01 d0                                        	add    r8,r10
    27bd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    27c2:	4d 01 d0                                        	add    r8,r10
    27c5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    27ca:	4d 01 d0                                        	add    r8,r10
    27cd:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    27d2:	4d 01 d0                                        	add    r8,r10
    27d5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    27da:	4d 01 d0                                        	add    r8,r10
    27dd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    27e2:	4d 01 d0                                        	add    r8,r10
    27e5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    27ea:	4d 01 d0                                        	add    r8,r10
    27ed:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    27f2:	4d 01 d0                                        	add    r8,r10
    27f5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    27fa:	4d 01 d0                                        	add    r8,r10
    27fd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2802:	4d 01 d0                                        	add    r8,r10
    2805:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    280a:	4d 01 d0                                        	add    r8,r10
    280d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2812:	4d 01 d0                                        	add    r8,r10
    2815:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    281a:	4d 01 d0                                        	add    r8,r10
    281d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2822:	4d 01 d0                                        	add    r8,r10
    2825:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    282a:	4d 01 d0                                        	add    r8,r10
    282d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2832:	4d 01 d0                                        	add    r8,r10
    2835:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    283a:	4d 01 d0                                        	add    r8,r10
    283d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2842:	4d 01 d0                                        	add    r8,r10
    2845:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    284a:	4d 01 d0                                        	add    r8,r10
    284d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2852:	4d 01 d0                                        	add    r8,r10
    2855:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    285a:	4d 01 d0                                        	add    r8,r10
    285d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2862:	4d 01 d0                                        	add    r8,r10
    2865:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    286a:	4d 01 d0                                        	add    r8,r10
    286d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2872:	4d 01 d0                                        	add    r8,r10
    2875:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    287a:	4d 01 d0                                        	add    r8,r10
    287d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2882:	4d 01 d0                                        	add    r8,r10
    2885:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    288a:	4d 01 d0                                        	add    r8,r10
    288d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2892:	4d 01 d0                                        	add    r8,r10
    2895:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    289a:	4d 01 d0                                        	add    r8,r10
    289d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    28a2:	4d 01 d0                                        	add    r8,r10
    28a5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    28aa:	4d 01 d0                                        	add    r8,r10
    28ad:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    28b2:	4d 01 d0                                        	add    r8,r10
    28b5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    28ba:	4d 01 d0                                        	add    r8,r10
    28bd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    28c2:	4d 01 d0                                        	add    r8,r10
    28c5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    28ca:	4d 01 d0                                        	add    r8,r10
    28cd:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    28d2:	4d 01 d0                                        	add    r8,r10
    28d5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    28da:	4d 01 d0                                        	add    r8,r10
    28dd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    28e2:	4d 01 d0                                        	add    r8,r10
    28e5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    28ea:	4d 01 d0                                        	add    r8,r10
    28ed:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    28f2:	4d 01 d0                                        	add    r8,r10
    28f5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    28fa:	4d 01 d0                                        	add    r8,r10
    28fd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2902:	4d 01 d0                                        	add    r8,r10
    2905:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    290a:	4d 01 d0                                        	add    r8,r10
    290d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2912:	4d 01 d0                                        	add    r8,r10
    2915:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    291a:	4d 01 d0                                        	add    r8,r10
    291d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2922:	4d 01 d0                                        	add    r8,r10
    2925:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    292a:	4d 01 d0                                        	add    r8,r10
    292d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2932:	4d 01 d0                                        	add    r8,r10
    2935:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    293a:	4d 01 d0                                        	add    r8,r10
    293d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2942:	4d 01 d0                                        	add    r8,r10
    2945:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    294a:	4d 01 d0                                        	add    r8,r10
    294d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2952:	4d 01 d0                                        	add    r8,r10
    2955:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    295a:	4d 01 d0                                        	add    r8,r10
    295d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2962:	4d 01 d0                                        	add    r8,r10
    2965:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    296a:	4d 01 d0                                        	add    r8,r10
    296d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2972:	4d 01 d0                                        	add    r8,r10
    2975:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    297a:	4d 01 d0                                        	add    r8,r10
    297d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2982:	4d 01 d0                                        	add    r8,r10
    2985:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    298a:	4d 01 d0                                        	add    r8,r10
    298d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2992:	4d 01 d0                                        	add    r8,r10
    2995:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    299a:	4d 01 d0                                        	add    r8,r10
    299d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    29a2:	4d 01 d0                                        	add    r8,r10
    29a5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    29aa:	4d 01 d0                                        	add    r8,r10
    29ad:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    29b2:	4d 01 d0                                        	add    r8,r10
    29b5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    29ba:	4d 01 d0                                        	add    r8,r10
    29bd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    29c2:	4d 01 d0                                        	add    r8,r10
    29c5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    29ca:	4d 01 d0                                        	add    r8,r10
    29cd:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    29d2:	4d 01 d0                                        	add    r8,r10
    29d5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    29da:	4d 01 d0                                        	add    r8,r10
    29dd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    29e2:	4d 01 d0                                        	add    r8,r10
    29e5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    29ea:	4d 01 d0                                        	add    r8,r10
    29ed:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    29f2:	4d 01 d0                                        	add    r8,r10
    29f5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    29fa:	4d 01 d0                                        	add    r8,r10
    29fd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2a02:	4d 01 d0                                        	add    r8,r10
    2a05:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2a0a:	4d 01 d0                                        	add    r8,r10
    2a0d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2a12:	4d 01 d0                                        	add    r8,r10
    2a15:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2a1a:	4d 01 d0                                        	add    r8,r10
    2a1d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2a22:	4d 01 d0                                        	add    r8,r10
    2a25:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2a2a:	4d 01 d0                                        	add    r8,r10
    2a2d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2a32:	4d 01 d0                                        	add    r8,r10
    2a35:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2a3a:	4d 01 d0                                        	add    r8,r10
    2a3d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2a42:	4d 01 d0                                        	add    r8,r10
    2a45:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2a4a:	4d 01 d0                                        	add    r8,r10
    2a4d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2a52:	4d 01 d0                                        	add    r8,r10
    2a55:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2a5a:	4d 01 d0                                        	add    r8,r10
    2a5d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2a62:	4d 01 d0                                        	add    r8,r10
    2a65:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2a6a:	4d 01 d0                                        	add    r8,r10
    2a6d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2a72:	4d 01 d0                                        	add    r8,r10
    2a75:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2a7a:	4d 01 d0                                        	add    r8,r10
    2a7d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2a82:	4d 01 d0                                        	add    r8,r10
    2a85:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2a8a:	4d 01 d0                                        	add    r8,r10
    2a8d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2a92:	4d 01 d0                                        	add    r8,r10
    2a95:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2a9a:	4d 01 d0                                        	add    r8,r10
    2a9d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2aa2:	4d 01 d0                                        	add    r8,r10
    2aa5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2aaa:	4d 01 d0                                        	add    r8,r10
    2aad:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2ab2:	4d 01 d0                                        	add    r8,r10
    2ab5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2aba:	4d 01 d0                                        	add    r8,r10
    2abd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2ac2:	4d 01 d0                                        	add    r8,r10
    2ac5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2aca:	4d 01 d0                                        	add    r8,r10
    2acd:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2ad2:	4d 01 d0                                        	add    r8,r10
    2ad5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2ada:	4d 01 d0                                        	add    r8,r10
    2add:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2ae2:	4d 01 d0                                        	add    r8,r10
    2ae5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2aea:	4d 01 d0                                        	add    r8,r10
    2aed:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2af2:	4d 01 d0                                        	add    r8,r10
    2af5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2afa:	4d 01 d0                                        	add    r8,r10
    2afd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2b02:	4d 01 d0                                        	add    r8,r10
    2b05:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2b0a:	4d 01 d0                                        	add    r8,r10
    2b0d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2b12:	4d 01 d0                                        	add    r8,r10
    2b15:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2b1a:	4d 01 d0                                        	add    r8,r10
    2b1d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2b22:	4d 01 d0                                        	add    r8,r10
    2b25:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2b2a:	4d 01 d0                                        	add    r8,r10
    2b2d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2b32:	4d 01 d0                                        	add    r8,r10
    2b35:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2b3a:	4d 01 d0                                        	add    r8,r10
    2b3d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2b42:	4d 01 d0                                        	add    r8,r10
    2b45:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2b4a:	4d 01 d0                                        	add    r8,r10
    2b4d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2b52:	4d 01 d0                                        	add    r8,r10
    2b55:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2b5a:	4d 01 d0                                        	add    r8,r10
    2b5d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2b62:	4d 01 d0                                        	add    r8,r10
    2b65:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2b6a:	4d 01 d0                                        	add    r8,r10
    2b6d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2b72:	4d 01 d0                                        	add    r8,r10
    2b75:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2b7a:	4d 01 d0                                        	add    r8,r10
    2b7d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2b82:	4d 01 d0                                        	add    r8,r10
    2b85:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2b8a:	4d 01 d0                                        	add    r8,r10
    2b8d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2b92:	4d 01 d0                                        	add    r8,r10
    2b95:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2b9a:	4d 01 d0                                        	add    r8,r10
    2b9d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2ba2:	4d 01 d0                                        	add    r8,r10
    2ba5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2baa:	4d 01 d0                                        	add    r8,r10
    2bad:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2bb2:	4d 01 d0                                        	add    r8,r10
    2bb5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2bba:	4d 01 d0                                        	add    r8,r10
    2bbd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2bc2:	4d 01 d0                                        	add    r8,r10
    2bc5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2bca:	4d 01 d0                                        	add    r8,r10
    2bcd:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2bd2:	4d 01 d0                                        	add    r8,r10
    2bd5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2bda:	4d 01 d0                                        	add    r8,r10
    2bdd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2be2:	4d 01 d0                                        	add    r8,r10
    2be5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2bea:	4d 01 d0                                        	add    r8,r10
    2bed:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2bf2:	4d 01 d0                                        	add    r8,r10
    2bf5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2bfa:	4d 01 d0                                        	add    r8,r10
    2bfd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2c02:	4d 01 d0                                        	add    r8,r10
    2c05:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2c0a:	4d 01 d0                                        	add    r8,r10
    2c0d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2c12:	4d 01 d0                                        	add    r8,r10
    2c15:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2c1a:	4d 01 d0                                        	add    r8,r10
    2c1d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2c22:	4d 01 d0                                        	add    r8,r10
    2c25:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2c2a:	4d 01 d0                                        	add    r8,r10
    2c2d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2c32:	4d 01 d0                                        	add    r8,r10
    2c35:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2c3a:	4d 01 d0                                        	add    r8,r10
    2c3d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2c42:	4d 01 d0                                        	add    r8,r10
    2c45:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2c4a:	4d 01 d0                                        	add    r8,r10
    2c4d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2c52:	4d 01 d0                                        	add    r8,r10
    2c55:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2c5a:	4d 01 d0                                        	add    r8,r10
    2c5d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2c62:	4d 01 d0                                        	add    r8,r10
    2c65:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2c6a:	4d 01 d0                                        	add    r8,r10
    2c6d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2c72:	4d 01 d0                                        	add    r8,r10
    2c75:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2c7a:	4d 01 d0                                        	add    r8,r10
    2c7d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2c82:	4d 01 d0                                        	add    r8,r10
    2c85:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2c8a:	4d 01 d0                                        	add    r8,r10
    2c8d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2c92:	4d 01 d0                                        	add    r8,r10
    2c95:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2c9a:	4d 01 d0                                        	add    r8,r10
    2c9d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2ca2:	4d 01 d0                                        	add    r8,r10
    2ca5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2caa:	4d 01 d0                                        	add    r8,r10
    2cad:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2cb2:	4d 01 d0                                        	add    r8,r10
    2cb5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2cba:	4d 01 d0                                        	add    r8,r10
    2cbd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2cc2:	4d 01 d0                                        	add    r8,r10
    2cc5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2cca:	4d 01 d0                                        	add    r8,r10
    2ccd:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2cd2:	4d 01 d0                                        	add    r8,r10
    2cd5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2cda:	4d 01 d0                                        	add    r8,r10
    2cdd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2ce2:	4d 01 d0                                        	add    r8,r10
    2ce5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2cea:	4d 01 d0                                        	add    r8,r10
    2ced:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2cf2:	4d 01 d0                                        	add    r8,r10
    2cf5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2cfa:	4d 01 d0                                        	add    r8,r10
    2cfd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2d02:	4d 01 d0                                        	add    r8,r10
    2d05:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2d0a:	4d 01 d0                                        	add    r8,r10
    2d0d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2d12:	4d 01 d0                                        	add    r8,r10
    2d15:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2d1a:	4d 01 d0                                        	add    r8,r10
    2d1d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2d22:	4d 01 d0                                        	add    r8,r10
    2d25:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2d2a:	4d 01 d0                                        	add    r8,r10
    2d2d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2d32:	4d 01 d0                                        	add    r8,r10
    2d35:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2d3a:	4d 01 d0                                        	add    r8,r10
    2d3d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2d42:	4d 01 d0                                        	add    r8,r10
    2d45:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2d4a:	4d 01 d0                                        	add    r8,r10
    2d4d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2d52:	4d 01 d0                                        	add    r8,r10
    2d55:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2d5a:	4d 01 d0                                        	add    r8,r10
    2d5d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2d62:	4d 01 d0                                        	add    r8,r10
    2d65:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2d6a:	4d 01 d0                                        	add    r8,r10
    2d6d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2d72:	4d 01 d0                                        	add    r8,r10
    2d75:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2d7a:	4d 01 d0                                        	add    r8,r10
    2d7d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2d82:	4d 01 d0                                        	add    r8,r10
    2d85:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2d8a:	4d 01 d0                                        	add    r8,r10
    2d8d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2d92:	4d 01 d0                                        	add    r8,r10
    2d95:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2d9a:	4d 01 d0                                        	add    r8,r10
    2d9d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2da2:	4d 01 d0                                        	add    r8,r10
    2da5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2daa:	4d 01 d0                                        	add    r8,r10
    2dad:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2db2:	4d 01 d0                                        	add    r8,r10
    2db5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2dba:	4d 01 d0                                        	add    r8,r10
    2dbd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2dc2:	4d 01 d0                                        	add    r8,r10
    2dc5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2dca:	4d 01 d0                                        	add    r8,r10
    2dcd:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2dd2:	4d 01 d0                                        	add    r8,r10
    2dd5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2dda:	4d 01 d0                                        	add    r8,r10
    2ddd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2de2:	4d 01 d0                                        	add    r8,r10
    2de5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2dea:	4d 01 d0                                        	add    r8,r10
    2ded:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2df2:	4d 01 d0                                        	add    r8,r10
    2df5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2dfa:	4d 01 d0                                        	add    r8,r10
    2dfd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2e02:	4d 01 d0                                        	add    r8,r10
    2e05:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2e0a:	4d 01 d0                                        	add    r8,r10
    2e0d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2e12:	4d 01 d0                                        	add    r8,r10
    2e15:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2e1a:	4d 01 d0                                        	add    r8,r10
    2e1d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2e22:	4d 01 d0                                        	add    r8,r10
    2e25:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2e2a:	4d 01 d0                                        	add    r8,r10
    2e2d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2e32:	4d 01 d0                                        	add    r8,r10
    2e35:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2e3a:	4d 01 d0                                        	add    r8,r10
    2e3d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2e42:	4d 01 d0                                        	add    r8,r10
    2e45:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2e4a:	4d 01 d0                                        	add    r8,r10
    2e4d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2e52:	4d 01 d0                                        	add    r8,r10
    2e55:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2e5a:	4d 01 d0                                        	add    r8,r10
    2e5d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2e62:	4d 01 d0                                        	add    r8,r10
    2e65:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2e6a:	4d 01 d0                                        	add    r8,r10
    2e6d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2e72:	4d 01 d0                                        	add    r8,r10
    2e75:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2e7a:	4d 01 d0                                        	add    r8,r10
    2e7d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2e82:	4d 01 d0                                        	add    r8,r10
    2e85:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2e8a:	4d 01 d0                                        	add    r8,r10
    2e8d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2e92:	4d 01 d0                                        	add    r8,r10
    2e95:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2e9a:	4d 01 d0                                        	add    r8,r10
    2e9d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2ea2:	4d 01 d0                                        	add    r8,r10
    2ea5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2eaa:	4d 01 d0                                        	add    r8,r10
    2ead:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2eb2:	4d 01 d0                                        	add    r8,r10
    2eb5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2eba:	4d 01 d0                                        	add    r8,r10
    2ebd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2ec2:	4d 01 d0                                        	add    r8,r10
    2ec5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2eca:	4d 01 d0                                        	add    r8,r10
    2ecd:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2ed2:	4d 01 d0                                        	add    r8,r10
    2ed5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2eda:	4d 01 d0                                        	add    r8,r10
    2edd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2ee2:	4d 01 d0                                        	add    r8,r10
    2ee5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2eea:	4d 01 d0                                        	add    r8,r10
    2eed:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2ef2:	4d 01 d0                                        	add    r8,r10
    2ef5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2efa:	4d 01 d0                                        	add    r8,r10
    2efd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2f02:	4d 01 d0                                        	add    r8,r10
    2f05:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2f0a:	4d 01 d0                                        	add    r8,r10
    2f0d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2f12:	4d 01 d0                                        	add    r8,r10
    2f15:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2f1a:	4d 01 d0                                        	add    r8,r10
    2f1d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2f22:	4d 01 d0                                        	add    r8,r10
    2f25:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2f2a:	4d 01 d0                                        	add    r8,r10
    2f2d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2f32:	4d 01 d0                                        	add    r8,r10
    2f35:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2f3a:	4d 01 d0                                        	add    r8,r10
    2f3d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2f42:	4d 01 d0                                        	add    r8,r10
    2f45:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2f4a:	4d 01 d0                                        	add    r8,r10
    2f4d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2f52:	4d 01 d0                                        	add    r8,r10
    2f55:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2f5a:	4d 01 d0                                        	add    r8,r10
    2f5d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2f62:	4d 01 d0                                        	add    r8,r10
    2f65:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2f6a:	4d 01 d0                                        	add    r8,r10
    2f6d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2f72:	4d 01 d0                                        	add    r8,r10
    2f75:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2f7a:	4d 01 d0                                        	add    r8,r10
    2f7d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2f82:	4d 01 d0                                        	add    r8,r10
    2f85:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2f8a:	4d 01 d0                                        	add    r8,r10
    2f8d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2f92:	4d 01 d0                                        	add    r8,r10
    2f95:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2f9a:	4d 01 d0                                        	add    r8,r10
    2f9d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2fa2:	4d 01 d0                                        	add    r8,r10
    2fa5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2faa:	4d 01 d0                                        	add    r8,r10
    2fad:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2fb2:	4d 01 d0                                        	add    r8,r10
    2fb5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2fba:	4d 01 d0                                        	add    r8,r10
    2fbd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    2fc2:	4d 01 d0                                        	add    r8,r10
    2fc5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    2fca:	4d 01 d0                                        	add    r8,r10
    2fcd:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    2fd2:	4d 01 d0                                        	add    r8,r10
    2fd5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    2fda:	4d 01 d0                                        	add    r8,r10
    2fdd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    2fe2:	4d 01 d0                                        	add    r8,r10
    2fe5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    2fea:	4d 01 d0                                        	add    r8,r10
    2fed:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    2ff2:	4d 01 d0                                        	add    r8,r10
    2ff5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    2ffa:	4d 01 d0                                        	add    r8,r10
    2ffd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3002:	4d 01 d0                                        	add    r8,r10
    3005:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    300a:	4d 01 d0                                        	add    r8,r10
    300d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3012:	4d 01 d0                                        	add    r8,r10
    3015:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    301a:	4d 01 d0                                        	add    r8,r10
    301d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3022:	4d 01 d0                                        	add    r8,r10
    3025:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    302a:	4d 01 d0                                        	add    r8,r10
    302d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3032:	4d 01 d0                                        	add    r8,r10
    3035:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    303a:	4d 01 d0                                        	add    r8,r10
    303d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3042:	4d 01 d0                                        	add    r8,r10
    3045:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    304a:	4d 01 d0                                        	add    r8,r10
    304d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3052:	4d 01 d0                                        	add    r8,r10
    3055:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    305a:	4d 01 d0                                        	add    r8,r10
    305d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3062:	4d 01 d0                                        	add    r8,r10
    3065:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    306a:	4d 01 d0                                        	add    r8,r10
    306d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3072:	4d 01 d0                                        	add    r8,r10
    3075:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    307a:	4d 01 d0                                        	add    r8,r10
    307d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3082:	4d 01 d0                                        	add    r8,r10
    3085:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    308a:	4d 01 d0                                        	add    r8,r10
    308d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3092:	4d 01 d0                                        	add    r8,r10
    3095:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    309a:	4d 01 d0                                        	add    r8,r10
    309d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    30a2:	4d 01 d0                                        	add    r8,r10
    30a5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    30aa:	4d 01 d0                                        	add    r8,r10
    30ad:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    30b2:	4d 01 d0                                        	add    r8,r10
    30b5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    30ba:	4d 01 d0                                        	add    r8,r10
    30bd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    30c2:	4d 01 d0                                        	add    r8,r10
    30c5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    30ca:	4d 01 d0                                        	add    r8,r10
    30cd:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    30d2:	4d 01 d0                                        	add    r8,r10
    30d5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    30da:	4d 01 d0                                        	add    r8,r10
    30dd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    30e2:	4d 01 d0                                        	add    r8,r10
    30e5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    30ea:	4d 01 d0                                        	add    r8,r10
    30ed:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    30f2:	4d 01 d0                                        	add    r8,r10
    30f5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    30fa:	4d 01 d0                                        	add    r8,r10
    30fd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3102:	4d 01 d0                                        	add    r8,r10
    3105:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    310a:	4d 01 d0                                        	add    r8,r10
    310d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3112:	4d 01 d0                                        	add    r8,r10
    3115:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    311a:	4d 01 d0                                        	add    r8,r10
    311d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3122:	4d 01 d0                                        	add    r8,r10
    3125:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    312a:	4d 01 d0                                        	add    r8,r10
    312d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3132:	4d 01 d0                                        	add    r8,r10
    3135:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    313a:	4d 01 d0                                        	add    r8,r10
    313d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3142:	4d 01 d0                                        	add    r8,r10
    3145:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    314a:	4d 01 d0                                        	add    r8,r10
    314d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3152:	4d 01 d0                                        	add    r8,r10
    3155:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    315a:	4d 01 d0                                        	add    r8,r10
    315d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3162:	4d 01 d0                                        	add    r8,r10
    3165:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    316a:	4d 01 d0                                        	add    r8,r10
    316d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3172:	4d 01 d0                                        	add    r8,r10
    3175:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    317a:	4d 01 d0                                        	add    r8,r10
    317d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3182:	4d 01 d0                                        	add    r8,r10
    3185:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    318a:	4d 01 d0                                        	add    r8,r10
    318d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3192:	4d 01 d0                                        	add    r8,r10
    3195:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    319a:	4d 01 d0                                        	add    r8,r10
    319d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    31a2:	4d 01 d0                                        	add    r8,r10
    31a5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    31aa:	4d 01 d0                                        	add    r8,r10
    31ad:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    31b2:	4d 01 d0                                        	add    r8,r10
    31b5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    31ba:	4d 01 d0                                        	add    r8,r10
    31bd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    31c2:	4d 01 d0                                        	add    r8,r10
    31c5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    31ca:	4d 01 d0                                        	add    r8,r10
    31cd:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    31d2:	4d 01 d0                                        	add    r8,r10
    31d5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    31da:	4d 01 d0                                        	add    r8,r10
    31dd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    31e2:	4d 01 d0                                        	add    r8,r10
    31e5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    31ea:	4d 01 d0                                        	add    r8,r10
    31ed:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    31f2:	4d 01 d0                                        	add    r8,r10
    31f5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    31fa:	4d 01 d0                                        	add    r8,r10
    31fd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3202:	4d 01 d0                                        	add    r8,r10
    3205:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    320a:	4d 01 d0                                        	add    r8,r10
    320d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3212:	4d 01 d0                                        	add    r8,r10
    3215:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    321a:	4d 01 d0                                        	add    r8,r10
    321d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3222:	4d 01 d0                                        	add    r8,r10
    3225:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    322a:	4d 01 d0                                        	add    r8,r10
    322d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3232:	4d 01 d0                                        	add    r8,r10
    3235:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    323a:	4d 01 d0                                        	add    r8,r10
    323d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3242:	4d 01 d0                                        	add    r8,r10
    3245:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    324a:	4d 01 d0                                        	add    r8,r10
    324d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3252:	4d 01 d0                                        	add    r8,r10
    3255:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    325a:	4d 01 d0                                        	add    r8,r10
    325d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3262:	4d 01 d0                                        	add    r8,r10
    3265:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    326a:	4d 01 d0                                        	add    r8,r10
    326d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3272:	4d 01 d0                                        	add    r8,r10
    3275:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    327a:	4d 01 d0                                        	add    r8,r10
    327d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3282:	4d 01 d0                                        	add    r8,r10
    3285:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    328a:	4d 01 d0                                        	add    r8,r10
    328d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3292:	4d 01 d0                                        	add    r8,r10
    3295:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    329a:	4d 01 d0                                        	add    r8,r10
    329d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    32a2:	4d 01 d0                                        	add    r8,r10
    32a5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    32aa:	4d 01 d0                                        	add    r8,r10
    32ad:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    32b2:	4d 01 d0                                        	add    r8,r10
    32b5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    32ba:	4d 01 d0                                        	add    r8,r10
    32bd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    32c2:	4d 01 d0                                        	add    r8,r10
    32c5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    32ca:	4d 01 d0                                        	add    r8,r10
    32cd:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    32d2:	4d 01 d0                                        	add    r8,r10
    32d5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    32da:	4d 01 d0                                        	add    r8,r10
    32dd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    32e2:	4d 01 d0                                        	add    r8,r10
    32e5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    32ea:	4d 01 d0                                        	add    r8,r10
    32ed:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    32f2:	4d 01 d0                                        	add    r8,r10
    32f5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    32fa:	4d 01 d0                                        	add    r8,r10
    32fd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3302:	4d 01 d0                                        	add    r8,r10
    3305:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    330a:	4d 01 d0                                        	add    r8,r10
    330d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3312:	4d 01 d0                                        	add    r8,r10
    3315:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    331a:	4d 01 d0                                        	add    r8,r10
    331d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3322:	4d 01 d0                                        	add    r8,r10
    3325:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    332a:	4d 01 d0                                        	add    r8,r10
    332d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3332:	4d 01 d0                                        	add    r8,r10
    3335:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    333a:	4d 01 d0                                        	add    r8,r10
    333d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3342:	4d 01 d0                                        	add    r8,r10
    3345:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    334a:	4d 01 d0                                        	add    r8,r10
    334d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3352:	4d 01 d0                                        	add    r8,r10
    3355:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    335a:	4d 01 d0                                        	add    r8,r10
    335d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3362:	4d 01 d0                                        	add    r8,r10
    3365:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    336a:	4d 01 d0                                        	add    r8,r10
    336d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3372:	4d 01 d0                                        	add    r8,r10
    3375:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    337a:	4d 01 d0                                        	add    r8,r10
    337d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3382:	4d 01 d0                                        	add    r8,r10
    3385:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    338a:	4d 01 d0                                        	add    r8,r10
    338d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3392:	4d 01 d0                                        	add    r8,r10
    3395:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    339a:	4d 01 d0                                        	add    r8,r10
    339d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    33a2:	4d 01 d0                                        	add    r8,r10
    33a5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    33aa:	4d 01 d0                                        	add    r8,r10
    33ad:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    33b2:	4d 01 d0                                        	add    r8,r10
    33b5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    33ba:	4d 01 d0                                        	add    r8,r10
    33bd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    33c2:	4d 01 d0                                        	add    r8,r10
    33c5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    33ca:	4d 01 d0                                        	add    r8,r10
    33cd:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    33d2:	4d 01 d0                                        	add    r8,r10
    33d5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    33da:	4d 01 d0                                        	add    r8,r10
    33dd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    33e2:	4d 01 d0                                        	add    r8,r10
    33e5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    33ea:	4d 01 d0                                        	add    r8,r10
    33ed:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    33f2:	4d 01 d0                                        	add    r8,r10
    33f5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    33fa:	4d 01 d0                                        	add    r8,r10
    33fd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3402:	4d 01 d0                                        	add    r8,r10
    3405:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    340a:	4d 01 d0                                        	add    r8,r10
    340d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3412:	4d 01 d0                                        	add    r8,r10
    3415:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    341a:	4d 01 d0                                        	add    r8,r10
    341d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3422:	4d 01 d0                                        	add    r8,r10
    3425:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    342a:	4d 01 d0                                        	add    r8,r10
    342d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3432:	4d 01 d0                                        	add    r8,r10
    3435:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    343a:	4d 01 d0                                        	add    r8,r10
    343d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3442:	4d 01 d0                                        	add    r8,r10
    3445:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    344a:	4d 01 d0                                        	add    r8,r10
    344d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3452:	4d 01 d0                                        	add    r8,r10
    3455:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    345a:	4d 01 d0                                        	add    r8,r10
    345d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3462:	4d 01 d0                                        	add    r8,r10
    3465:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    346a:	4d 01 d0                                        	add    r8,r10
    346d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3472:	4d 01 d0                                        	add    r8,r10
    3475:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    347a:	4d 01 d0                                        	add    r8,r10
    347d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3482:	4d 01 d0                                        	add    r8,r10
    3485:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    348a:	4d 01 d0                                        	add    r8,r10
    348d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3492:	4d 01 d0                                        	add    r8,r10
    3495:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    349a:	4d 01 d0                                        	add    r8,r10
    349d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    34a2:	4d 01 d0                                        	add    r8,r10
    34a5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    34aa:	4d 01 d0                                        	add    r8,r10
    34ad:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    34b2:	4d 01 d0                                        	add    r8,r10
    34b5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    34ba:	4d 01 d0                                        	add    r8,r10
    34bd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    34c2:	4d 01 d0                                        	add    r8,r10
    34c5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    34ca:	4d 01 d0                                        	add    r8,r10
    34cd:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    34d2:	4d 01 d0                                        	add    r8,r10
    34d5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    34da:	4d 01 d0                                        	add    r8,r10
    34dd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    34e2:	4d 01 d0                                        	add    r8,r10
    34e5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    34ea:	4d 01 d0                                        	add    r8,r10
    34ed:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    34f2:	4d 01 d0                                        	add    r8,r10
    34f5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    34fa:	4d 01 d0                                        	add    r8,r10
    34fd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3502:	4d 01 d0                                        	add    r8,r10
    3505:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    350a:	4d 01 d0                                        	add    r8,r10
    350d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3512:	4d 01 d0                                        	add    r8,r10
    3515:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    351a:	4d 01 d0                                        	add    r8,r10
    351d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3522:	4d 01 d0                                        	add    r8,r10
    3525:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    352a:	4d 01 d0                                        	add    r8,r10
    352d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3532:	4d 01 d0                                        	add    r8,r10
    3535:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    353a:	4d 01 d0                                        	add    r8,r10
    353d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3542:	4d 01 d0                                        	add    r8,r10
    3545:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    354a:	4d 01 d0                                        	add    r8,r10
    354d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3552:	4d 01 d0                                        	add    r8,r10
    3555:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    355a:	4d 01 d0                                        	add    r8,r10
    355d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3562:	4d 01 d0                                        	add    r8,r10
    3565:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    356a:	4d 01 d0                                        	add    r8,r10
    356d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3572:	4d 01 d0                                        	add    r8,r10
    3575:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    357a:	4d 01 d0                                        	add    r8,r10
    357d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3582:	4d 01 d0                                        	add    r8,r10
    3585:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    358a:	4d 01 d0                                        	add    r8,r10
    358d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3592:	4d 01 d0                                        	add    r8,r10
    3595:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    359a:	4d 01 d0                                        	add    r8,r10
    359d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    35a2:	4d 01 d0                                        	add    r8,r10
    35a5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    35aa:	4d 01 d0                                        	add    r8,r10
    35ad:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    35b2:	4d 01 d0                                        	add    r8,r10
    35b5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    35ba:	4d 01 d0                                        	add    r8,r10
    35bd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    35c2:	4d 01 d0                                        	add    r8,r10
    35c5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    35ca:	4d 01 d0                                        	add    r8,r10
    35cd:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    35d2:	4d 01 d0                                        	add    r8,r10
    35d5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    35da:	4d 01 d0                                        	add    r8,r10
    35dd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    35e2:	4d 01 d0                                        	add    r8,r10
    35e5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    35ea:	4d 01 d0                                        	add    r8,r10
    35ed:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    35f2:	4d 01 d0                                        	add    r8,r10
    35f5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    35fa:	4d 01 d0                                        	add    r8,r10
    35fd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3602:	4d 01 d0                                        	add    r8,r10
    3605:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    360a:	4d 01 d0                                        	add    r8,r10
    360d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3612:	4d 01 d0                                        	add    r8,r10
    3615:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    361a:	4d 01 d0                                        	add    r8,r10
    361d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3622:	4d 01 d0                                        	add    r8,r10
    3625:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    362a:	4d 01 d0                                        	add    r8,r10
    362d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3632:	4d 01 d0                                        	add    r8,r10
    3635:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    363a:	4d 01 d0                                        	add    r8,r10
    363d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3642:	4d 01 d0                                        	add    r8,r10
    3645:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    364a:	4d 01 d0                                        	add    r8,r10
    364d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3652:	4d 01 d0                                        	add    r8,r10
    3655:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    365a:	4d 01 d0                                        	add    r8,r10
    365d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3662:	4d 01 d0                                        	add    r8,r10
    3665:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    366a:	4d 01 d0                                        	add    r8,r10
    366d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3672:	4d 01 d0                                        	add    r8,r10
    3675:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    367a:	4d 01 d0                                        	add    r8,r10
    367d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3682:	4d 01 d0                                        	add    r8,r10
    3685:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    368a:	4d 01 d0                                        	add    r8,r10
    368d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3692:	4d 01 d0                                        	add    r8,r10
    3695:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    369a:	4d 01 d0                                        	add    r8,r10
    369d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    36a2:	4d 01 d0                                        	add    r8,r10
    36a5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    36aa:	4d 01 d0                                        	add    r8,r10
    36ad:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    36b2:	4d 01 d0                                        	add    r8,r10
    36b5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    36ba:	4d 01 d0                                        	add    r8,r10
    36bd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    36c2:	4d 01 d0                                        	add    r8,r10
    36c5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    36ca:	4d 01 d0                                        	add    r8,r10
    36cd:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    36d2:	4d 01 d0                                        	add    r8,r10
    36d5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    36da:	4d 01 d0                                        	add    r8,r10
    36dd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    36e2:	4d 01 d0                                        	add    r8,r10
    36e5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    36ea:	4d 01 d0                                        	add    r8,r10
    36ed:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    36f2:	4d 01 d0                                        	add    r8,r10
    36f5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    36fa:	4d 01 d0                                        	add    r8,r10
    36fd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3702:	4d 01 d0                                        	add    r8,r10
    3705:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    370a:	4d 01 d0                                        	add    r8,r10
    370d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3712:	4d 01 d0                                        	add    r8,r10
    3715:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    371a:	4d 01 d0                                        	add    r8,r10
    371d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3722:	4d 01 d0                                        	add    r8,r10
    3725:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    372a:	4d 01 d0                                        	add    r8,r10
    372d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3732:	4d 01 d0                                        	add    r8,r10
    3735:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    373a:	4d 01 d0                                        	add    r8,r10
    373d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3742:	4d 01 d0                                        	add    r8,r10
    3745:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    374a:	4d 01 d0                                        	add    r8,r10
    374d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3752:	4d 01 d0                                        	add    r8,r10
    3755:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    375a:	4d 01 d0                                        	add    r8,r10
    375d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3762:	4d 01 d0                                        	add    r8,r10
    3765:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    376a:	4d 01 d0                                        	add    r8,r10
    376d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3772:	4d 01 d0                                        	add    r8,r10
    3775:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    377a:	4d 01 d0                                        	add    r8,r10
    377d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3782:	4d 01 d0                                        	add    r8,r10
    3785:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    378a:	4d 01 d0                                        	add    r8,r10
    378d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3792:	4d 01 d0                                        	add    r8,r10
    3795:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    379a:	4d 01 d0                                        	add    r8,r10
    379d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    37a2:	4d 01 d0                                        	add    r8,r10
    37a5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    37aa:	4d 01 d0                                        	add    r8,r10
    37ad:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    37b2:	4d 01 d0                                        	add    r8,r10
    37b5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    37ba:	4d 01 d0                                        	add    r8,r10
    37bd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    37c2:	4d 01 d0                                        	add    r8,r10
    37c5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    37ca:	4d 01 d0                                        	add    r8,r10
    37cd:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    37d2:	4d 01 d0                                        	add    r8,r10
    37d5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    37da:	4d 01 d0                                        	add    r8,r10
    37dd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    37e2:	4d 01 d0                                        	add    r8,r10
    37e5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    37ea:	4d 01 d0                                        	add    r8,r10
    37ed:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    37f2:	4d 01 d0                                        	add    r8,r10
    37f5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    37fa:	4d 01 d0                                        	add    r8,r10
    37fd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3802:	4d 01 d0                                        	add    r8,r10
    3805:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    380a:	4d 01 d0                                        	add    r8,r10
    380d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3812:	4d 01 d0                                        	add    r8,r10
    3815:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    381a:	4d 01 d0                                        	add    r8,r10
    381d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3822:	4d 01 d0                                        	add    r8,r10
    3825:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    382a:	4d 01 d0                                        	add    r8,r10
    382d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3832:	4d 01 d0                                        	add    r8,r10
    3835:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    383a:	4d 01 d0                                        	add    r8,r10
    383d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3842:	4d 01 d0                                        	add    r8,r10
    3845:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    384a:	4d 01 d0                                        	add    r8,r10
    384d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3852:	4d 01 d0                                        	add    r8,r10
    3855:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    385a:	4d 01 d0                                        	add    r8,r10
    385d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3862:	4d 01 d0                                        	add    r8,r10
    3865:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    386a:	4d 01 d0                                        	add    r8,r10
    386d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3872:	4d 01 d0                                        	add    r8,r10
    3875:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    387a:	4d 01 d0                                        	add    r8,r10
    387d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3882:	4d 01 d0                                        	add    r8,r10
    3885:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    388a:	4d 01 d0                                        	add    r8,r10
    388d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3892:	4d 01 d0                                        	add    r8,r10
    3895:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    389a:	4d 01 d0                                        	add    r8,r10
    389d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    38a2:	4d 01 d0                                        	add    r8,r10
    38a5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    38aa:	4d 01 d0                                        	add    r8,r10
    38ad:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    38b2:	4d 01 d0                                        	add    r8,r10
    38b5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    38ba:	4d 01 d0                                        	add    r8,r10
    38bd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    38c2:	4d 01 d0                                        	add    r8,r10
    38c5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    38ca:	4d 01 d0                                        	add    r8,r10
    38cd:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    38d2:	4d 01 d0                                        	add    r8,r10
    38d5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    38da:	4d 01 d0                                        	add    r8,r10
    38dd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    38e2:	4d 01 d0                                        	add    r8,r10
    38e5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    38ea:	4d 01 d0                                        	add    r8,r10
    38ed:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    38f2:	4d 01 d0                                        	add    r8,r10
    38f5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    38fa:	4d 01 d0                                        	add    r8,r10
    38fd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3902:	4d 01 d0                                        	add    r8,r10
    3905:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    390a:	4d 01 d0                                        	add    r8,r10
    390d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3912:	4d 01 d0                                        	add    r8,r10
    3915:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    391a:	4d 01 d0                                        	add    r8,r10
    391d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3922:	4d 01 d0                                        	add    r8,r10
    3925:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    392a:	4d 01 d0                                        	add    r8,r10
    392d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3932:	4d 01 d0                                        	add    r8,r10
    3935:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    393a:	4d 01 d0                                        	add    r8,r10
    393d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3942:	4d 01 d0                                        	add    r8,r10
    3945:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    394a:	4d 01 d0                                        	add    r8,r10
    394d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3952:	4d 01 d0                                        	add    r8,r10
    3955:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    395a:	4d 01 d0                                        	add    r8,r10
    395d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3962:	4d 01 d0                                        	add    r8,r10
    3965:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    396a:	4d 01 d0                                        	add    r8,r10
    396d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3972:	4d 01 d0                                        	add    r8,r10
    3975:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    397a:	4d 01 d0                                        	add    r8,r10
    397d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3982:	4d 01 d0                                        	add    r8,r10
    3985:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    398a:	4d 01 d0                                        	add    r8,r10
    398d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3992:	4d 01 d0                                        	add    r8,r10
    3995:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    399a:	4d 01 d0                                        	add    r8,r10
    399d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    39a2:	4d 01 d0                                        	add    r8,r10
    39a5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    39aa:	4d 01 d0                                        	add    r8,r10
    39ad:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    39b2:	4d 01 d0                                        	add    r8,r10
    39b5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    39ba:	4d 01 d0                                        	add    r8,r10
    39bd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    39c2:	4d 01 d0                                        	add    r8,r10
    39c5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    39ca:	4d 01 d0                                        	add    r8,r10
    39cd:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    39d2:	4d 01 d0                                        	add    r8,r10
    39d5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    39da:	4d 01 d0                                        	add    r8,r10
    39dd:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    39e2:	4d 01 d0                                        	add    r8,r10
    39e5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    39ea:	4d 01 d0                                        	add    r8,r10
    39ed:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    39f2:	4d 01 d0                                        	add    r8,r10
    39f5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    39fa:	4d 01 d0                                        	add    r8,r10
    39fd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3a02:	4d 01 d0                                        	add    r8,r10
    3a05:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3a0a:	4d 01 d0                                        	add    r8,r10
    3a0d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3a12:	4d 01 d0                                        	add    r8,r10
    3a15:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3a1a:	4d 01 d0                                        	add    r8,r10
    3a1d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3a22:	4d 01 d0                                        	add    r8,r10
    3a25:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3a2a:	4d 01 d0                                        	add    r8,r10
    3a2d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3a32:	4d 01 d0                                        	add    r8,r10
    3a35:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3a3a:	4d 01 d0                                        	add    r8,r10
    3a3d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3a42:	4d 01 d0                                        	add    r8,r10
    3a45:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3a4a:	4d 01 d0                                        	add    r8,r10
    3a4d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3a52:	4d 01 d0                                        	add    r8,r10
    3a55:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3a5a:	4d 01 d0                                        	add    r8,r10
    3a5d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3a62:	4d 01 d0                                        	add    r8,r10
    3a65:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3a6a:	4d 01 d0                                        	add    r8,r10
    3a6d:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3a72:	4d 01 d0                                        	add    r8,r10
    3a75:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3a7a:	4d 01 d0                                        	add    r8,r10
    3a7d:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3a82:	4d 01 d0                                        	add    r8,r10
    3a85:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3a8a:	4d 01 d0                                        	add    r8,r10
    3a8d:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3a92:	4d 01 d0                                        	add    r8,r10
    3a95:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3a9a:	4d 01 d0                                        	add    r8,r10
    3a9d:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3aa2:	4d 01 d0                                        	add    r8,r10
    3aa5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3aaa:	4d 01 d0                                        	add    r8,r10
    3aad:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3ab2:	4d 01 d0                                        	add    r8,r10
    3ab5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3aba:	4d 01 d0                                        	add    r8,r10
    3abd:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3ac2:	4d 01 d0                                        	add    r8,r10
    3ac5:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3aca:	4d 01 d0                                        	add    r8,r10
    3acd:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3ad2:	4d 01 d0                                        	add    r8,r10
    3ad5:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3ada:	4d 01 d0                                        	add    r8,r10
    3add:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3ae2:	4d 01 d0                                        	add    r8,r10
    3ae5:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3aea:	4d 01 d0                                        	add    r8,r10
    3aed:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3af2:	4d 01 d0                                        	add    r8,r10
    3af5:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3afa:	4d 01 d0                                        	add    r8,r10
    3afd:	41 f6 c1 01                                     	test   r9b,0x1
    3b01:	75 09                                           	jne    3b0c <choose_2>
    3b03:	4c 8d 15 0c 00 00 00                            	lea    r10,[rip+0xc]        # 3b16 <target_a_2>
    3b0a:	eb 07                                           	jmp    3b13 <dispatch_2>

0000000000003b0c <choose_2>:
    3b0c:	4c 8d 15 09 00 00 00                            	lea    r10,[rip+0x9]        # 3b1c <target_b_2>

0000000000003b13 <dispatch_2>:
    3b13:	41 ff e2                                        	jmp    r10

0000000000003b16 <target_a_2>:
    3b16:	49 83 c0 01                                     	add    r8,0x1
    3b1a:	eb 04                                           	jmp    3b20 <join_2>

0000000000003b1c <target_b_2>:
    3b1c:	49 83 c0 02                                     	add    r8,0x2

0000000000003b20 <join_2>:
    3b20:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3b25:	4d 01 d0                                        	add    r8,r10
    3b28:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3b2d:	4d 01 d0                                        	add    r8,r10
    3b30:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3b35:	4d 01 d0                                        	add    r8,r10
    3b38:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3b3d:	4d 01 d0                                        	add    r8,r10
    3b40:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3b45:	4d 01 d0                                        	add    r8,r10
    3b48:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3b4d:	4d 01 d0                                        	add    r8,r10
    3b50:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3b55:	4d 01 d0                                        	add    r8,r10
    3b58:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3b5d:	4d 01 d0                                        	add    r8,r10
    3b60:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3b65:	4d 01 d0                                        	add    r8,r10
    3b68:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3b6d:	4d 01 d0                                        	add    r8,r10
    3b70:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3b75:	4d 01 d0                                        	add    r8,r10
    3b78:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3b7d:	4d 01 d0                                        	add    r8,r10
    3b80:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3b85:	4d 01 d0                                        	add    r8,r10
    3b88:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3b8d:	4d 01 d0                                        	add    r8,r10
    3b90:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3b95:	4d 01 d0                                        	add    r8,r10
    3b98:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3b9d:	4d 01 d0                                        	add    r8,r10
    3ba0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3ba5:	4d 01 d0                                        	add    r8,r10
    3ba8:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3bad:	4d 01 d0                                        	add    r8,r10
    3bb0:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3bb5:	4d 01 d0                                        	add    r8,r10
    3bb8:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3bbd:	4d 01 d0                                        	add    r8,r10
    3bc0:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3bc5:	4d 01 d0                                        	add    r8,r10
    3bc8:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3bcd:	4d 01 d0                                        	add    r8,r10
    3bd0:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3bd5:	4d 01 d0                                        	add    r8,r10
    3bd8:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3bdd:	4d 01 d0                                        	add    r8,r10
    3be0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3be5:	4d 01 d0                                        	add    r8,r10
    3be8:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3bed:	4d 01 d0                                        	add    r8,r10
    3bf0:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3bf5:	4d 01 d0                                        	add    r8,r10
    3bf8:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3bfd:	4d 01 d0                                        	add    r8,r10
    3c00:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3c05:	4d 01 d0                                        	add    r8,r10
    3c08:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3c0d:	4d 01 d0                                        	add    r8,r10
    3c10:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3c15:	4d 01 d0                                        	add    r8,r10
    3c18:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3c1d:	4d 01 d0                                        	add    r8,r10
    3c20:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3c25:	4d 01 d0                                        	add    r8,r10
    3c28:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3c2d:	4d 01 d0                                        	add    r8,r10
    3c30:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3c35:	4d 01 d0                                        	add    r8,r10
    3c38:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3c3d:	4d 01 d0                                        	add    r8,r10
    3c40:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3c45:	4d 01 d0                                        	add    r8,r10
    3c48:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3c4d:	4d 01 d0                                        	add    r8,r10
    3c50:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3c55:	4d 01 d0                                        	add    r8,r10
    3c58:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3c5d:	4d 01 d0                                        	add    r8,r10
    3c60:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3c65:	4d 01 d0                                        	add    r8,r10
    3c68:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3c6d:	4d 01 d0                                        	add    r8,r10
    3c70:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3c75:	4d 01 d0                                        	add    r8,r10
    3c78:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3c7d:	4d 01 d0                                        	add    r8,r10
    3c80:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3c85:	4d 01 d0                                        	add    r8,r10
    3c88:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3c8d:	4d 01 d0                                        	add    r8,r10
    3c90:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3c95:	4d 01 d0                                        	add    r8,r10
    3c98:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3c9d:	4d 01 d0                                        	add    r8,r10
    3ca0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3ca5:	4d 01 d0                                        	add    r8,r10
    3ca8:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3cad:	4d 01 d0                                        	add    r8,r10
    3cb0:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3cb5:	4d 01 d0                                        	add    r8,r10
    3cb8:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3cbd:	4d 01 d0                                        	add    r8,r10
    3cc0:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3cc5:	4d 01 d0                                        	add    r8,r10
    3cc8:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3ccd:	4d 01 d0                                        	add    r8,r10
    3cd0:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3cd5:	4d 01 d0                                        	add    r8,r10
    3cd8:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3cdd:	4d 01 d0                                        	add    r8,r10
    3ce0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3ce5:	4d 01 d0                                        	add    r8,r10
    3ce8:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3ced:	4d 01 d0                                        	add    r8,r10
    3cf0:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3cf5:	4d 01 d0                                        	add    r8,r10
    3cf8:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3cfd:	4d 01 d0                                        	add    r8,r10
    3d00:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3d05:	4d 01 d0                                        	add    r8,r10
    3d08:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3d0d:	4d 01 d0                                        	add    r8,r10
    3d10:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3d15:	4d 01 d0                                        	add    r8,r10
    3d18:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3d1d:	4d 01 d0                                        	add    r8,r10
    3d20:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3d25:	4d 01 d0                                        	add    r8,r10
    3d28:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3d2d:	4d 01 d0                                        	add    r8,r10
    3d30:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3d35:	4d 01 d0                                        	add    r8,r10
    3d38:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3d3d:	4d 01 d0                                        	add    r8,r10
    3d40:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3d45:	4d 01 d0                                        	add    r8,r10
    3d48:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3d4d:	4d 01 d0                                        	add    r8,r10
    3d50:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3d55:	4d 01 d0                                        	add    r8,r10
    3d58:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3d5d:	4d 01 d0                                        	add    r8,r10
    3d60:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3d65:	4d 01 d0                                        	add    r8,r10
    3d68:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3d6d:	4d 01 d0                                        	add    r8,r10
    3d70:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3d75:	4d 01 d0                                        	add    r8,r10
    3d78:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3d7d:	4d 01 d0                                        	add    r8,r10
    3d80:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3d85:	4d 01 d0                                        	add    r8,r10
    3d88:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3d8d:	4d 01 d0                                        	add    r8,r10
    3d90:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3d95:	4d 01 d0                                        	add    r8,r10
    3d98:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3d9d:	4d 01 d0                                        	add    r8,r10
    3da0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3da5:	4d 01 d0                                        	add    r8,r10
    3da8:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3dad:	4d 01 d0                                        	add    r8,r10
    3db0:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3db5:	4d 01 d0                                        	add    r8,r10
    3db8:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3dbd:	4d 01 d0                                        	add    r8,r10
    3dc0:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3dc5:	4d 01 d0                                        	add    r8,r10
    3dc8:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3dcd:	4d 01 d0                                        	add    r8,r10
    3dd0:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3dd5:	4d 01 d0                                        	add    r8,r10
    3dd8:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3ddd:	4d 01 d0                                        	add    r8,r10
    3de0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3de5:	4d 01 d0                                        	add    r8,r10
    3de8:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3ded:	4d 01 d0                                        	add    r8,r10
    3df0:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3df5:	4d 01 d0                                        	add    r8,r10
    3df8:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3dfd:	4d 01 d0                                        	add    r8,r10
    3e00:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3e05:	4d 01 d0                                        	add    r8,r10
    3e08:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3e0d:	4d 01 d0                                        	add    r8,r10
    3e10:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3e15:	4d 01 d0                                        	add    r8,r10
    3e18:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3e1d:	4d 01 d0                                        	add    r8,r10
    3e20:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3e25:	4d 01 d0                                        	add    r8,r10
    3e28:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3e2d:	4d 01 d0                                        	add    r8,r10
    3e30:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3e35:	4d 01 d0                                        	add    r8,r10
    3e38:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3e3d:	4d 01 d0                                        	add    r8,r10
    3e40:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3e45:	4d 01 d0                                        	add    r8,r10
    3e48:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3e4d:	4d 01 d0                                        	add    r8,r10
    3e50:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3e55:	4d 01 d0                                        	add    r8,r10
    3e58:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3e5d:	4d 01 d0                                        	add    r8,r10
    3e60:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3e65:	4d 01 d0                                        	add    r8,r10
    3e68:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3e6d:	4d 01 d0                                        	add    r8,r10
    3e70:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3e75:	4d 01 d0                                        	add    r8,r10
    3e78:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3e7d:	4d 01 d0                                        	add    r8,r10
    3e80:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3e85:	4d 01 d0                                        	add    r8,r10
    3e88:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3e8d:	4d 01 d0                                        	add    r8,r10
    3e90:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3e95:	4d 01 d0                                        	add    r8,r10
    3e98:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3e9d:	4d 01 d0                                        	add    r8,r10
    3ea0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3ea5:	4d 01 d0                                        	add    r8,r10
    3ea8:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3ead:	4d 01 d0                                        	add    r8,r10
    3eb0:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3eb5:	4d 01 d0                                        	add    r8,r10
    3eb8:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3ebd:	4d 01 d0                                        	add    r8,r10
    3ec0:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3ec5:	4d 01 d0                                        	add    r8,r10
    3ec8:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3ecd:	4d 01 d0                                        	add    r8,r10
    3ed0:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3ed5:	4d 01 d0                                        	add    r8,r10
    3ed8:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3edd:	4d 01 d0                                        	add    r8,r10
    3ee0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3ee5:	4d 01 d0                                        	add    r8,r10
    3ee8:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3eed:	4d 01 d0                                        	add    r8,r10
    3ef0:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3ef5:	4d 01 d0                                        	add    r8,r10
    3ef8:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3efd:	4d 01 d0                                        	add    r8,r10
    3f00:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3f05:	4d 01 d0                                        	add    r8,r10
    3f08:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3f0d:	4d 01 d0                                        	add    r8,r10
    3f10:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3f15:	4d 01 d0                                        	add    r8,r10
    3f18:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3f1d:	4d 01 d0                                        	add    r8,r10
    3f20:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3f25:	4d 01 d0                                        	add    r8,r10
    3f28:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3f2d:	4d 01 d0                                        	add    r8,r10
    3f30:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3f35:	4d 01 d0                                        	add    r8,r10
    3f38:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3f3d:	4d 01 d0                                        	add    r8,r10
    3f40:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3f45:	4d 01 d0                                        	add    r8,r10
    3f48:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3f4d:	4d 01 d0                                        	add    r8,r10
    3f50:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3f55:	4d 01 d0                                        	add    r8,r10
    3f58:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3f5d:	4d 01 d0                                        	add    r8,r10
    3f60:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3f65:	4d 01 d0                                        	add    r8,r10
    3f68:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3f6d:	4d 01 d0                                        	add    r8,r10
    3f70:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3f75:	4d 01 d0                                        	add    r8,r10
    3f78:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3f7d:	4d 01 d0                                        	add    r8,r10
    3f80:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3f85:	4d 01 d0                                        	add    r8,r10
    3f88:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3f8d:	4d 01 d0                                        	add    r8,r10
    3f90:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3f95:	4d 01 d0                                        	add    r8,r10
    3f98:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3f9d:	4d 01 d0                                        	add    r8,r10
    3fa0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3fa5:	4d 01 d0                                        	add    r8,r10
    3fa8:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3fad:	4d 01 d0                                        	add    r8,r10
    3fb0:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3fb5:	4d 01 d0                                        	add    r8,r10
    3fb8:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3fbd:	4d 01 d0                                        	add    r8,r10
    3fc0:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    3fc5:	4d 01 d0                                        	add    r8,r10
    3fc8:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    3fcd:	4d 01 d0                                        	add    r8,r10
    3fd0:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    3fd5:	4d 01 d0                                        	add    r8,r10
    3fd8:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    3fdd:	4d 01 d0                                        	add    r8,r10
    3fe0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    3fe5:	4d 01 d0                                        	add    r8,r10
    3fe8:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    3fed:	4d 01 d0                                        	add    r8,r10
    3ff0:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    3ff5:	4d 01 d0                                        	add    r8,r10
    3ff8:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    3ffd:	4d 01 d0                                        	add    r8,r10
    4000:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4005:	4d 01 d0                                        	add    r8,r10
    4008:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    400d:	4d 01 d0                                        	add    r8,r10
    4010:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4015:	4d 01 d0                                        	add    r8,r10
    4018:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    401d:	4d 01 d0                                        	add    r8,r10
    4020:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4025:	4d 01 d0                                        	add    r8,r10
    4028:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    402d:	4d 01 d0                                        	add    r8,r10
    4030:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4035:	4d 01 d0                                        	add    r8,r10
    4038:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    403d:	4d 01 d0                                        	add    r8,r10
    4040:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4045:	4d 01 d0                                        	add    r8,r10
    4048:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    404d:	4d 01 d0                                        	add    r8,r10
    4050:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4055:	4d 01 d0                                        	add    r8,r10
    4058:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    405d:	4d 01 d0                                        	add    r8,r10
    4060:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4065:	4d 01 d0                                        	add    r8,r10
    4068:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    406d:	4d 01 d0                                        	add    r8,r10
    4070:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4075:	4d 01 d0                                        	add    r8,r10
    4078:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    407d:	4d 01 d0                                        	add    r8,r10
    4080:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4085:	4d 01 d0                                        	add    r8,r10
    4088:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    408d:	4d 01 d0                                        	add    r8,r10
    4090:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4095:	4d 01 d0                                        	add    r8,r10
    4098:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    409d:	4d 01 d0                                        	add    r8,r10
    40a0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    40a5:	4d 01 d0                                        	add    r8,r10
    40a8:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    40ad:	4d 01 d0                                        	add    r8,r10
    40b0:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    40b5:	4d 01 d0                                        	add    r8,r10
    40b8:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    40bd:	4d 01 d0                                        	add    r8,r10
    40c0:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    40c5:	4d 01 d0                                        	add    r8,r10
    40c8:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    40cd:	4d 01 d0                                        	add    r8,r10
    40d0:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    40d5:	4d 01 d0                                        	add    r8,r10
    40d8:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    40dd:	4d 01 d0                                        	add    r8,r10
    40e0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    40e5:	4d 01 d0                                        	add    r8,r10
    40e8:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    40ed:	4d 01 d0                                        	add    r8,r10
    40f0:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    40f5:	4d 01 d0                                        	add    r8,r10
    40f8:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    40fd:	4d 01 d0                                        	add    r8,r10
    4100:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4105:	4d 01 d0                                        	add    r8,r10
    4108:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    410d:	4d 01 d0                                        	add    r8,r10
    4110:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4115:	4d 01 d0                                        	add    r8,r10
    4118:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    411d:	4d 01 d0                                        	add    r8,r10
    4120:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4125:	4d 01 d0                                        	add    r8,r10
    4128:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    412d:	4d 01 d0                                        	add    r8,r10
    4130:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4135:	4d 01 d0                                        	add    r8,r10
    4138:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    413d:	4d 01 d0                                        	add    r8,r10
    4140:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4145:	4d 01 d0                                        	add    r8,r10
    4148:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    414d:	4d 01 d0                                        	add    r8,r10
    4150:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4155:	4d 01 d0                                        	add    r8,r10
    4158:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    415d:	4d 01 d0                                        	add    r8,r10
    4160:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4165:	4d 01 d0                                        	add    r8,r10
    4168:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    416d:	4d 01 d0                                        	add    r8,r10
    4170:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4175:	4d 01 d0                                        	add    r8,r10
    4178:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    417d:	4d 01 d0                                        	add    r8,r10
    4180:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4185:	4d 01 d0                                        	add    r8,r10
    4188:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    418d:	4d 01 d0                                        	add    r8,r10
    4190:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4195:	4d 01 d0                                        	add    r8,r10
    4198:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    419d:	4d 01 d0                                        	add    r8,r10
    41a0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    41a5:	4d 01 d0                                        	add    r8,r10
    41a8:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    41ad:	4d 01 d0                                        	add    r8,r10
    41b0:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    41b5:	4d 01 d0                                        	add    r8,r10
    41b8:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    41bd:	4d 01 d0                                        	add    r8,r10
    41c0:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    41c5:	4d 01 d0                                        	add    r8,r10
    41c8:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    41cd:	4d 01 d0                                        	add    r8,r10
    41d0:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    41d5:	4d 01 d0                                        	add    r8,r10
    41d8:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    41dd:	4d 01 d0                                        	add    r8,r10
    41e0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    41e5:	4d 01 d0                                        	add    r8,r10
    41e8:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    41ed:	4d 01 d0                                        	add    r8,r10
    41f0:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    41f5:	4d 01 d0                                        	add    r8,r10
    41f8:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    41fd:	4d 01 d0                                        	add    r8,r10
    4200:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4205:	4d 01 d0                                        	add    r8,r10
    4208:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    420d:	4d 01 d0                                        	add    r8,r10
    4210:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4215:	4d 01 d0                                        	add    r8,r10
    4218:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    421d:	4d 01 d0                                        	add    r8,r10
    4220:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4225:	4d 01 d0                                        	add    r8,r10
    4228:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    422d:	4d 01 d0                                        	add    r8,r10
    4230:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4235:	4d 01 d0                                        	add    r8,r10
    4238:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    423d:	4d 01 d0                                        	add    r8,r10
    4240:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4245:	4d 01 d0                                        	add    r8,r10
    4248:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    424d:	4d 01 d0                                        	add    r8,r10
    4250:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4255:	4d 01 d0                                        	add    r8,r10
    4258:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    425d:	4d 01 d0                                        	add    r8,r10
    4260:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4265:	4d 01 d0                                        	add    r8,r10
    4268:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    426d:	4d 01 d0                                        	add    r8,r10
    4270:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4275:	4d 01 d0                                        	add    r8,r10
    4278:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    427d:	4d 01 d0                                        	add    r8,r10
    4280:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4285:	4d 01 d0                                        	add    r8,r10
    4288:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    428d:	4d 01 d0                                        	add    r8,r10
    4290:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4295:	4d 01 d0                                        	add    r8,r10
    4298:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    429d:	4d 01 d0                                        	add    r8,r10
    42a0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    42a5:	4d 01 d0                                        	add    r8,r10
    42a8:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    42ad:	4d 01 d0                                        	add    r8,r10
    42b0:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    42b5:	4d 01 d0                                        	add    r8,r10
    42b8:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    42bd:	4d 01 d0                                        	add    r8,r10
    42c0:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    42c5:	4d 01 d0                                        	add    r8,r10
    42c8:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    42cd:	4d 01 d0                                        	add    r8,r10
    42d0:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    42d5:	4d 01 d0                                        	add    r8,r10
    42d8:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    42dd:	4d 01 d0                                        	add    r8,r10
    42e0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    42e5:	4d 01 d0                                        	add    r8,r10
    42e8:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    42ed:	4d 01 d0                                        	add    r8,r10
    42f0:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    42f5:	4d 01 d0                                        	add    r8,r10
    42f8:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    42fd:	4d 01 d0                                        	add    r8,r10
    4300:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4305:	4d 01 d0                                        	add    r8,r10
    4308:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    430d:	4d 01 d0                                        	add    r8,r10
    4310:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4315:	4d 01 d0                                        	add    r8,r10
    4318:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    431d:	4d 01 d0                                        	add    r8,r10
    4320:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4325:	4d 01 d0                                        	add    r8,r10
    4328:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    432d:	4d 01 d0                                        	add    r8,r10
    4330:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4335:	4d 01 d0                                        	add    r8,r10
    4338:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    433d:	4d 01 d0                                        	add    r8,r10
    4340:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4345:	4d 01 d0                                        	add    r8,r10
    4348:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    434d:	4d 01 d0                                        	add    r8,r10
    4350:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4355:	4d 01 d0                                        	add    r8,r10
    4358:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    435d:	4d 01 d0                                        	add    r8,r10
    4360:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4365:	4d 01 d0                                        	add    r8,r10
    4368:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    436d:	4d 01 d0                                        	add    r8,r10
    4370:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4375:	4d 01 d0                                        	add    r8,r10
    4378:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    437d:	4d 01 d0                                        	add    r8,r10
    4380:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4385:	4d 01 d0                                        	add    r8,r10
    4388:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    438d:	4d 01 d0                                        	add    r8,r10
    4390:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4395:	4d 01 d0                                        	add    r8,r10
    4398:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    439d:	4d 01 d0                                        	add    r8,r10
    43a0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    43a5:	4d 01 d0                                        	add    r8,r10
    43a8:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    43ad:	4d 01 d0                                        	add    r8,r10
    43b0:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    43b5:	4d 01 d0                                        	add    r8,r10
    43b8:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    43bd:	4d 01 d0                                        	add    r8,r10
    43c0:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    43c5:	4d 01 d0                                        	add    r8,r10
    43c8:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    43cd:	4d 01 d0                                        	add    r8,r10
    43d0:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    43d5:	4d 01 d0                                        	add    r8,r10
    43d8:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    43dd:	4d 01 d0                                        	add    r8,r10
    43e0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    43e5:	4d 01 d0                                        	add    r8,r10
    43e8:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    43ed:	4d 01 d0                                        	add    r8,r10
    43f0:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    43f5:	4d 01 d0                                        	add    r8,r10
    43f8:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    43fd:	4d 01 d0                                        	add    r8,r10
    4400:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4405:	4d 01 d0                                        	add    r8,r10
    4408:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    440d:	4d 01 d0                                        	add    r8,r10
    4410:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4415:	4d 01 d0                                        	add    r8,r10
    4418:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    441d:	4d 01 d0                                        	add    r8,r10
    4420:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4425:	4d 01 d0                                        	add    r8,r10
    4428:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    442d:	4d 01 d0                                        	add    r8,r10
    4430:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4435:	4d 01 d0                                        	add    r8,r10
    4438:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    443d:	4d 01 d0                                        	add    r8,r10
    4440:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4445:	4d 01 d0                                        	add    r8,r10
    4448:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    444d:	4d 01 d0                                        	add    r8,r10
    4450:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4455:	4d 01 d0                                        	add    r8,r10
    4458:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    445d:	4d 01 d0                                        	add    r8,r10
    4460:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4465:	4d 01 d0                                        	add    r8,r10
    4468:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    446d:	4d 01 d0                                        	add    r8,r10
    4470:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4475:	4d 01 d0                                        	add    r8,r10
    4478:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    447d:	4d 01 d0                                        	add    r8,r10
    4480:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4485:	4d 01 d0                                        	add    r8,r10
    4488:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    448d:	4d 01 d0                                        	add    r8,r10
    4490:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4495:	4d 01 d0                                        	add    r8,r10
    4498:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    449d:	4d 01 d0                                        	add    r8,r10
    44a0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    44a5:	4d 01 d0                                        	add    r8,r10
    44a8:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    44ad:	4d 01 d0                                        	add    r8,r10
    44b0:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    44b5:	4d 01 d0                                        	add    r8,r10
    44b8:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    44bd:	4d 01 d0                                        	add    r8,r10
    44c0:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    44c5:	4d 01 d0                                        	add    r8,r10
    44c8:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    44cd:	4d 01 d0                                        	add    r8,r10
    44d0:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    44d5:	4d 01 d0                                        	add    r8,r10
    44d8:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    44dd:	4d 01 d0                                        	add    r8,r10
    44e0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    44e5:	4d 01 d0                                        	add    r8,r10
    44e8:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    44ed:	4d 01 d0                                        	add    r8,r10
    44f0:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    44f5:	4d 01 d0                                        	add    r8,r10
    44f8:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    44fd:	4d 01 d0                                        	add    r8,r10
    4500:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4505:	4d 01 d0                                        	add    r8,r10
    4508:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    450d:	4d 01 d0                                        	add    r8,r10
    4510:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4515:	4d 01 d0                                        	add    r8,r10
    4518:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    451d:	4d 01 d0                                        	add    r8,r10
    4520:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4525:	4d 01 d0                                        	add    r8,r10
    4528:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    452d:	4d 01 d0                                        	add    r8,r10
    4530:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4535:	4d 01 d0                                        	add    r8,r10
    4538:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    453d:	4d 01 d0                                        	add    r8,r10
    4540:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4545:	4d 01 d0                                        	add    r8,r10
    4548:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    454d:	4d 01 d0                                        	add    r8,r10
    4550:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4555:	4d 01 d0                                        	add    r8,r10
    4558:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    455d:	4d 01 d0                                        	add    r8,r10
    4560:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4565:	4d 01 d0                                        	add    r8,r10
    4568:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    456d:	4d 01 d0                                        	add    r8,r10
    4570:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4575:	4d 01 d0                                        	add    r8,r10
    4578:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    457d:	4d 01 d0                                        	add    r8,r10
    4580:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4585:	4d 01 d0                                        	add    r8,r10
    4588:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    458d:	4d 01 d0                                        	add    r8,r10
    4590:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4595:	4d 01 d0                                        	add    r8,r10
    4598:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    459d:	4d 01 d0                                        	add    r8,r10
    45a0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    45a5:	4d 01 d0                                        	add    r8,r10
    45a8:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    45ad:	4d 01 d0                                        	add    r8,r10
    45b0:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    45b5:	4d 01 d0                                        	add    r8,r10
    45b8:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    45bd:	4d 01 d0                                        	add    r8,r10
    45c0:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    45c5:	4d 01 d0                                        	add    r8,r10
    45c8:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    45cd:	4d 01 d0                                        	add    r8,r10
    45d0:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    45d5:	4d 01 d0                                        	add    r8,r10
    45d8:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    45dd:	4d 01 d0                                        	add    r8,r10
    45e0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    45e5:	4d 01 d0                                        	add    r8,r10
    45e8:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    45ed:	4d 01 d0                                        	add    r8,r10
    45f0:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    45f5:	4d 01 d0                                        	add    r8,r10
    45f8:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    45fd:	4d 01 d0                                        	add    r8,r10
    4600:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4605:	4d 01 d0                                        	add    r8,r10
    4608:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    460d:	4d 01 d0                                        	add    r8,r10
    4610:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4615:	4d 01 d0                                        	add    r8,r10
    4618:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    461d:	4d 01 d0                                        	add    r8,r10
    4620:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4625:	4d 01 d0                                        	add    r8,r10
    4628:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    462d:	4d 01 d0                                        	add    r8,r10
    4630:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4635:	4d 01 d0                                        	add    r8,r10
    4638:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    463d:	4d 01 d0                                        	add    r8,r10
    4640:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4645:	4d 01 d0                                        	add    r8,r10
    4648:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    464d:	4d 01 d0                                        	add    r8,r10
    4650:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4655:	4d 01 d0                                        	add    r8,r10
    4658:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    465d:	4d 01 d0                                        	add    r8,r10
    4660:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4665:	4d 01 d0                                        	add    r8,r10
    4668:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    466d:	4d 01 d0                                        	add    r8,r10
    4670:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4675:	4d 01 d0                                        	add    r8,r10
    4678:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    467d:	4d 01 d0                                        	add    r8,r10
    4680:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4685:	4d 01 d0                                        	add    r8,r10
    4688:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    468d:	4d 01 d0                                        	add    r8,r10
    4690:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4695:	4d 01 d0                                        	add    r8,r10
    4698:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    469d:	4d 01 d0                                        	add    r8,r10
    46a0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    46a5:	4d 01 d0                                        	add    r8,r10
    46a8:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    46ad:	4d 01 d0                                        	add    r8,r10
    46b0:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    46b5:	4d 01 d0                                        	add    r8,r10
    46b8:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    46bd:	4d 01 d0                                        	add    r8,r10
    46c0:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    46c5:	4d 01 d0                                        	add    r8,r10
    46c8:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    46cd:	4d 01 d0                                        	add    r8,r10
    46d0:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    46d5:	4d 01 d0                                        	add    r8,r10
    46d8:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    46dd:	4d 01 d0                                        	add    r8,r10
    46e0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    46e5:	4d 01 d0                                        	add    r8,r10
    46e8:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    46ed:	4d 01 d0                                        	add    r8,r10
    46f0:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    46f5:	4d 01 d0                                        	add    r8,r10
    46f8:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    46fd:	4d 01 d0                                        	add    r8,r10
    4700:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4705:	4d 01 d0                                        	add    r8,r10
    4708:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    470d:	4d 01 d0                                        	add    r8,r10
    4710:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4715:	4d 01 d0                                        	add    r8,r10
    4718:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    471d:	4d 01 d0                                        	add    r8,r10
    4720:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4725:	4d 01 d0                                        	add    r8,r10
    4728:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    472d:	4d 01 d0                                        	add    r8,r10
    4730:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4735:	4d 01 d0                                        	add    r8,r10
    4738:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    473d:	4d 01 d0                                        	add    r8,r10
    4740:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4745:	4d 01 d0                                        	add    r8,r10
    4748:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    474d:	4d 01 d0                                        	add    r8,r10
    4750:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4755:	4d 01 d0                                        	add    r8,r10
    4758:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    475d:	4d 01 d0                                        	add    r8,r10
    4760:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4765:	4d 01 d0                                        	add    r8,r10
    4768:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    476d:	4d 01 d0                                        	add    r8,r10
    4770:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4775:	4d 01 d0                                        	add    r8,r10
    4778:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    477d:	4d 01 d0                                        	add    r8,r10
    4780:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4785:	4d 01 d0                                        	add    r8,r10
    4788:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    478d:	4d 01 d0                                        	add    r8,r10
    4790:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4795:	4d 01 d0                                        	add    r8,r10
    4798:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    479d:	4d 01 d0                                        	add    r8,r10
    47a0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    47a5:	4d 01 d0                                        	add    r8,r10
    47a8:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    47ad:	4d 01 d0                                        	add    r8,r10
    47b0:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    47b5:	4d 01 d0                                        	add    r8,r10
    47b8:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    47bd:	4d 01 d0                                        	add    r8,r10
    47c0:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    47c5:	4d 01 d0                                        	add    r8,r10
    47c8:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    47cd:	4d 01 d0                                        	add    r8,r10
    47d0:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    47d5:	4d 01 d0                                        	add    r8,r10
    47d8:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    47dd:	4d 01 d0                                        	add    r8,r10
    47e0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    47e5:	4d 01 d0                                        	add    r8,r10
    47e8:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    47ed:	4d 01 d0                                        	add    r8,r10
    47f0:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    47f5:	4d 01 d0                                        	add    r8,r10
    47f8:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    47fd:	4d 01 d0                                        	add    r8,r10
    4800:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4805:	4d 01 d0                                        	add    r8,r10
    4808:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    480d:	4d 01 d0                                        	add    r8,r10
    4810:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4815:	4d 01 d0                                        	add    r8,r10
    4818:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    481d:	4d 01 d0                                        	add    r8,r10
    4820:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4825:	4d 01 d0                                        	add    r8,r10
    4828:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    482d:	4d 01 d0                                        	add    r8,r10
    4830:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4835:	4d 01 d0                                        	add    r8,r10
    4838:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    483d:	4d 01 d0                                        	add    r8,r10
    4840:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4845:	4d 01 d0                                        	add    r8,r10
    4848:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    484d:	4d 01 d0                                        	add    r8,r10
    4850:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4855:	4d 01 d0                                        	add    r8,r10
    4858:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    485d:	4d 01 d0                                        	add    r8,r10
    4860:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4865:	4d 01 d0                                        	add    r8,r10
    4868:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    486d:	4d 01 d0                                        	add    r8,r10
    4870:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4875:	4d 01 d0                                        	add    r8,r10
    4878:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    487d:	4d 01 d0                                        	add    r8,r10
    4880:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4885:	4d 01 d0                                        	add    r8,r10
    4888:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    488d:	4d 01 d0                                        	add    r8,r10
    4890:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4895:	4d 01 d0                                        	add    r8,r10
    4898:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    489d:	4d 01 d0                                        	add    r8,r10
    48a0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    48a5:	4d 01 d0                                        	add    r8,r10
    48a8:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    48ad:	4d 01 d0                                        	add    r8,r10
    48b0:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    48b5:	4d 01 d0                                        	add    r8,r10
    48b8:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    48bd:	4d 01 d0                                        	add    r8,r10
    48c0:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    48c5:	4d 01 d0                                        	add    r8,r10
    48c8:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    48cd:	4d 01 d0                                        	add    r8,r10
    48d0:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    48d5:	4d 01 d0                                        	add    r8,r10
    48d8:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    48dd:	4d 01 d0                                        	add    r8,r10
    48e0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    48e5:	4d 01 d0                                        	add    r8,r10
    48e8:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    48ed:	4d 01 d0                                        	add    r8,r10
    48f0:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    48f5:	4d 01 d0                                        	add    r8,r10
    48f8:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    48fd:	4d 01 d0                                        	add    r8,r10
    4900:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4905:	4d 01 d0                                        	add    r8,r10
    4908:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    490d:	4d 01 d0                                        	add    r8,r10
    4910:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4915:	4d 01 d0                                        	add    r8,r10
    4918:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    491d:	4d 01 d0                                        	add    r8,r10
    4920:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4925:	4d 01 d0                                        	add    r8,r10
    4928:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    492d:	4d 01 d0                                        	add    r8,r10
    4930:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4935:	4d 01 d0                                        	add    r8,r10
    4938:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    493d:	4d 01 d0                                        	add    r8,r10
    4940:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4945:	4d 01 d0                                        	add    r8,r10
    4948:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    494d:	4d 01 d0                                        	add    r8,r10
    4950:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4955:	4d 01 d0                                        	add    r8,r10
    4958:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    495d:	4d 01 d0                                        	add    r8,r10
    4960:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4965:	4d 01 d0                                        	add    r8,r10
    4968:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    496d:	4d 01 d0                                        	add    r8,r10
    4970:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4975:	4d 01 d0                                        	add    r8,r10
    4978:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    497d:	4d 01 d0                                        	add    r8,r10
    4980:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4985:	4d 01 d0                                        	add    r8,r10
    4988:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    498d:	4d 01 d0                                        	add    r8,r10
    4990:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4995:	4d 01 d0                                        	add    r8,r10
    4998:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    499d:	4d 01 d0                                        	add    r8,r10
    49a0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    49a5:	4d 01 d0                                        	add    r8,r10
    49a8:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    49ad:	4d 01 d0                                        	add    r8,r10
    49b0:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    49b5:	4d 01 d0                                        	add    r8,r10
    49b8:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    49bd:	4d 01 d0                                        	add    r8,r10
    49c0:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    49c5:	4d 01 d0                                        	add    r8,r10
    49c8:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    49cd:	4d 01 d0                                        	add    r8,r10
    49d0:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    49d5:	4d 01 d0                                        	add    r8,r10
    49d8:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    49dd:	4d 01 d0                                        	add    r8,r10
    49e0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    49e5:	4d 01 d0                                        	add    r8,r10
    49e8:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    49ed:	4d 01 d0                                        	add    r8,r10
    49f0:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    49f5:	4d 01 d0                                        	add    r8,r10
    49f8:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    49fd:	4d 01 d0                                        	add    r8,r10
    4a00:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4a05:	4d 01 d0                                        	add    r8,r10
    4a08:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4a0d:	4d 01 d0                                        	add    r8,r10
    4a10:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4a15:	4d 01 d0                                        	add    r8,r10
    4a18:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4a1d:	4d 01 d0                                        	add    r8,r10
    4a20:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4a25:	4d 01 d0                                        	add    r8,r10
    4a28:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4a2d:	4d 01 d0                                        	add    r8,r10
    4a30:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4a35:	4d 01 d0                                        	add    r8,r10
    4a38:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4a3d:	4d 01 d0                                        	add    r8,r10
    4a40:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4a45:	4d 01 d0                                        	add    r8,r10
    4a48:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4a4d:	4d 01 d0                                        	add    r8,r10
    4a50:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4a55:	4d 01 d0                                        	add    r8,r10
    4a58:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4a5d:	4d 01 d0                                        	add    r8,r10
    4a60:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4a65:	4d 01 d0                                        	add    r8,r10
    4a68:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4a6d:	4d 01 d0                                        	add    r8,r10
    4a70:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4a75:	4d 01 d0                                        	add    r8,r10
    4a78:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4a7d:	4d 01 d0                                        	add    r8,r10
    4a80:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4a85:	4d 01 d0                                        	add    r8,r10
    4a88:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4a8d:	4d 01 d0                                        	add    r8,r10
    4a90:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4a95:	4d 01 d0                                        	add    r8,r10
    4a98:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4a9d:	4d 01 d0                                        	add    r8,r10
    4aa0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4aa5:	4d 01 d0                                        	add    r8,r10
    4aa8:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4aad:	4d 01 d0                                        	add    r8,r10
    4ab0:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4ab5:	4d 01 d0                                        	add    r8,r10
    4ab8:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4abd:	4d 01 d0                                        	add    r8,r10
    4ac0:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4ac5:	4d 01 d0                                        	add    r8,r10
    4ac8:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4acd:	4d 01 d0                                        	add    r8,r10
    4ad0:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4ad5:	4d 01 d0                                        	add    r8,r10
    4ad8:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4add:	4d 01 d0                                        	add    r8,r10
    4ae0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4ae5:	4d 01 d0                                        	add    r8,r10
    4ae8:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4aed:	4d 01 d0                                        	add    r8,r10
    4af0:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4af5:	4d 01 d0                                        	add    r8,r10
    4af8:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4afd:	4d 01 d0                                        	add    r8,r10
    4b00:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4b05:	4d 01 d0                                        	add    r8,r10
    4b08:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4b0d:	4d 01 d0                                        	add    r8,r10
    4b10:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4b15:	4d 01 d0                                        	add    r8,r10
    4b18:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4b1d:	4d 01 d0                                        	add    r8,r10
    4b20:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4b25:	4d 01 d0                                        	add    r8,r10
    4b28:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4b2d:	4d 01 d0                                        	add    r8,r10
    4b30:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4b35:	4d 01 d0                                        	add    r8,r10
    4b38:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4b3d:	4d 01 d0                                        	add    r8,r10
    4b40:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4b45:	4d 01 d0                                        	add    r8,r10
    4b48:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4b4d:	4d 01 d0                                        	add    r8,r10
    4b50:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4b55:	4d 01 d0                                        	add    r8,r10
    4b58:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4b5d:	4d 01 d0                                        	add    r8,r10
    4b60:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4b65:	4d 01 d0                                        	add    r8,r10
    4b68:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4b6d:	4d 01 d0                                        	add    r8,r10
    4b70:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4b75:	4d 01 d0                                        	add    r8,r10
    4b78:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4b7d:	4d 01 d0                                        	add    r8,r10
    4b80:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4b85:	4d 01 d0                                        	add    r8,r10
    4b88:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4b8d:	4d 01 d0                                        	add    r8,r10
    4b90:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4b95:	4d 01 d0                                        	add    r8,r10
    4b98:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4b9d:	4d 01 d0                                        	add    r8,r10
    4ba0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4ba5:	4d 01 d0                                        	add    r8,r10
    4ba8:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4bad:	4d 01 d0                                        	add    r8,r10
    4bb0:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4bb5:	4d 01 d0                                        	add    r8,r10
    4bb8:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4bbd:	4d 01 d0                                        	add    r8,r10
    4bc0:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4bc5:	4d 01 d0                                        	add    r8,r10
    4bc8:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4bcd:	4d 01 d0                                        	add    r8,r10
    4bd0:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4bd5:	4d 01 d0                                        	add    r8,r10
    4bd8:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4bdd:	4d 01 d0                                        	add    r8,r10
    4be0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4be5:	4d 01 d0                                        	add    r8,r10
    4be8:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4bed:	4d 01 d0                                        	add    r8,r10
    4bf0:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4bf5:	4d 01 d0                                        	add    r8,r10
    4bf8:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4bfd:	4d 01 d0                                        	add    r8,r10
    4c00:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4c05:	4d 01 d0                                        	add    r8,r10
    4c08:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4c0d:	4d 01 d0                                        	add    r8,r10
    4c10:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4c15:	4d 01 d0                                        	add    r8,r10
    4c18:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4c1d:	4d 01 d0                                        	add    r8,r10
    4c20:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4c25:	4d 01 d0                                        	add    r8,r10
    4c28:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4c2d:	4d 01 d0                                        	add    r8,r10
    4c30:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4c35:	4d 01 d0                                        	add    r8,r10
    4c38:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4c3d:	4d 01 d0                                        	add    r8,r10
    4c40:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4c45:	4d 01 d0                                        	add    r8,r10
    4c48:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4c4d:	4d 01 d0                                        	add    r8,r10
    4c50:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4c55:	4d 01 d0                                        	add    r8,r10
    4c58:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4c5d:	4d 01 d0                                        	add    r8,r10
    4c60:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4c65:	4d 01 d0                                        	add    r8,r10
    4c68:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4c6d:	4d 01 d0                                        	add    r8,r10
    4c70:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4c75:	4d 01 d0                                        	add    r8,r10
    4c78:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4c7d:	4d 01 d0                                        	add    r8,r10
    4c80:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4c85:	4d 01 d0                                        	add    r8,r10
    4c88:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4c8d:	4d 01 d0                                        	add    r8,r10
    4c90:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4c95:	4d 01 d0                                        	add    r8,r10
    4c98:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4c9d:	4d 01 d0                                        	add    r8,r10
    4ca0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4ca5:	4d 01 d0                                        	add    r8,r10
    4ca8:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4cad:	4d 01 d0                                        	add    r8,r10
    4cb0:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4cb5:	4d 01 d0                                        	add    r8,r10
    4cb8:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4cbd:	4d 01 d0                                        	add    r8,r10
    4cc0:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4cc5:	4d 01 d0                                        	add    r8,r10
    4cc8:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4ccd:	4d 01 d0                                        	add    r8,r10
    4cd0:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4cd5:	4d 01 d0                                        	add    r8,r10
    4cd8:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4cdd:	4d 01 d0                                        	add    r8,r10
    4ce0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4ce5:	4d 01 d0                                        	add    r8,r10
    4ce8:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4ced:	4d 01 d0                                        	add    r8,r10
    4cf0:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4cf5:	4d 01 d0                                        	add    r8,r10
    4cf8:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4cfd:	4d 01 d0                                        	add    r8,r10
    4d00:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4d05:	4d 01 d0                                        	add    r8,r10
    4d08:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4d0d:	4d 01 d0                                        	add    r8,r10
    4d10:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4d15:	4d 01 d0                                        	add    r8,r10
    4d18:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4d1d:	4d 01 d0                                        	add    r8,r10
    4d20:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4d25:	4d 01 d0                                        	add    r8,r10
    4d28:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4d2d:	4d 01 d0                                        	add    r8,r10
    4d30:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4d35:	4d 01 d0                                        	add    r8,r10
    4d38:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4d3d:	4d 01 d0                                        	add    r8,r10
    4d40:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4d45:	4d 01 d0                                        	add    r8,r10
    4d48:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4d4d:	4d 01 d0                                        	add    r8,r10
    4d50:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4d55:	4d 01 d0                                        	add    r8,r10
    4d58:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4d5d:	4d 01 d0                                        	add    r8,r10
    4d60:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4d65:	4d 01 d0                                        	add    r8,r10
    4d68:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4d6d:	4d 01 d0                                        	add    r8,r10
    4d70:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4d75:	4d 01 d0                                        	add    r8,r10
    4d78:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4d7d:	4d 01 d0                                        	add    r8,r10
    4d80:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4d85:	4d 01 d0                                        	add    r8,r10
    4d88:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4d8d:	4d 01 d0                                        	add    r8,r10
    4d90:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4d95:	4d 01 d0                                        	add    r8,r10
    4d98:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4d9d:	4d 01 d0                                        	add    r8,r10
    4da0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4da5:	4d 01 d0                                        	add    r8,r10
    4da8:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4dad:	4d 01 d0                                        	add    r8,r10
    4db0:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4db5:	4d 01 d0                                        	add    r8,r10
    4db8:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4dbd:	4d 01 d0                                        	add    r8,r10
    4dc0:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4dc5:	4d 01 d0                                        	add    r8,r10
    4dc8:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4dcd:	4d 01 d0                                        	add    r8,r10
    4dd0:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4dd5:	4d 01 d0                                        	add    r8,r10
    4dd8:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4ddd:	4d 01 d0                                        	add    r8,r10
    4de0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4de5:	4d 01 d0                                        	add    r8,r10
    4de8:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4ded:	4d 01 d0                                        	add    r8,r10
    4df0:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4df5:	4d 01 d0                                        	add    r8,r10
    4df8:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4dfd:	4d 01 d0                                        	add    r8,r10
    4e00:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4e05:	4d 01 d0                                        	add    r8,r10
    4e08:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4e0d:	4d 01 d0                                        	add    r8,r10
    4e10:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4e15:	4d 01 d0                                        	add    r8,r10
    4e18:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4e1d:	4d 01 d0                                        	add    r8,r10
    4e20:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4e25:	4d 01 d0                                        	add    r8,r10
    4e28:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4e2d:	4d 01 d0                                        	add    r8,r10
    4e30:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4e35:	4d 01 d0                                        	add    r8,r10
    4e38:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4e3d:	4d 01 d0                                        	add    r8,r10
    4e40:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4e45:	4d 01 d0                                        	add    r8,r10
    4e48:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4e4d:	4d 01 d0                                        	add    r8,r10
    4e50:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4e55:	4d 01 d0                                        	add    r8,r10
    4e58:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4e5d:	4d 01 d0                                        	add    r8,r10
    4e60:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4e65:	4d 01 d0                                        	add    r8,r10
    4e68:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4e6d:	4d 01 d0                                        	add    r8,r10
    4e70:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4e75:	4d 01 d0                                        	add    r8,r10
    4e78:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4e7d:	4d 01 d0                                        	add    r8,r10
    4e80:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4e85:	4d 01 d0                                        	add    r8,r10
    4e88:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4e8d:	4d 01 d0                                        	add    r8,r10
    4e90:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4e95:	4d 01 d0                                        	add    r8,r10
    4e98:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4e9d:	4d 01 d0                                        	add    r8,r10
    4ea0:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4ea5:	4d 01 d0                                        	add    r8,r10
    4ea8:	41 f6 c1 01                                     	test   r9b,0x1
    4eac:	75 09                                           	jne    4eb7 <choose_3>
    4eae:	4c 8d 15 0c 00 00 00                            	lea    r10,[rip+0xc]        # 4ec1 <target_a_3>
    4eb5:	eb 07                                           	jmp    4ebe <dispatch_3>

0000000000004eb7 <choose_3>:
    4eb7:	4c 8d 15 09 00 00 00                            	lea    r10,[rip+0x9]        # 4ec7 <target_b_3>

0000000000004ebe <dispatch_3>:
    4ebe:	41 ff e2                                        	jmp    r10

0000000000004ec1 <target_a_3>:
    4ec1:	49 83 c0 01                                     	add    r8,0x1
    4ec5:	eb 04                                           	jmp    4ecb <join_3>

0000000000004ec7 <target_b_3>:
    4ec7:	49 83 c0 02                                     	add    r8,0x2

0000000000004ecb <join_3>:
    4ecb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4ed0:	4d 01 d0                                        	add    r8,r10
    4ed3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4ed8:	4d 01 d0                                        	add    r8,r10
    4edb:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4ee0:	4d 01 d0                                        	add    r8,r10
    4ee3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4ee8:	4d 01 d0                                        	add    r8,r10
    4eeb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4ef0:	4d 01 d0                                        	add    r8,r10
    4ef3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4ef8:	4d 01 d0                                        	add    r8,r10
    4efb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4f00:	4d 01 d0                                        	add    r8,r10
    4f03:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4f08:	4d 01 d0                                        	add    r8,r10
    4f0b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4f10:	4d 01 d0                                        	add    r8,r10
    4f13:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4f18:	4d 01 d0                                        	add    r8,r10
    4f1b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4f20:	4d 01 d0                                        	add    r8,r10
    4f23:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4f28:	4d 01 d0                                        	add    r8,r10
    4f2b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4f30:	4d 01 d0                                        	add    r8,r10
    4f33:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4f38:	4d 01 d0                                        	add    r8,r10
    4f3b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4f40:	4d 01 d0                                        	add    r8,r10
    4f43:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4f48:	4d 01 d0                                        	add    r8,r10
    4f4b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4f50:	4d 01 d0                                        	add    r8,r10
    4f53:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4f58:	4d 01 d0                                        	add    r8,r10
    4f5b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4f60:	4d 01 d0                                        	add    r8,r10
    4f63:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4f68:	4d 01 d0                                        	add    r8,r10
    4f6b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4f70:	4d 01 d0                                        	add    r8,r10
    4f73:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4f78:	4d 01 d0                                        	add    r8,r10
    4f7b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4f80:	4d 01 d0                                        	add    r8,r10
    4f83:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4f88:	4d 01 d0                                        	add    r8,r10
    4f8b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4f90:	4d 01 d0                                        	add    r8,r10
    4f93:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4f98:	4d 01 d0                                        	add    r8,r10
    4f9b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4fa0:	4d 01 d0                                        	add    r8,r10
    4fa3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4fa8:	4d 01 d0                                        	add    r8,r10
    4fab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4fb0:	4d 01 d0                                        	add    r8,r10
    4fb3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4fb8:	4d 01 d0                                        	add    r8,r10
    4fbb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    4fc0:	4d 01 d0                                        	add    r8,r10
    4fc3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    4fc8:	4d 01 d0                                        	add    r8,r10
    4fcb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    4fd0:	4d 01 d0                                        	add    r8,r10
    4fd3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    4fd8:	4d 01 d0                                        	add    r8,r10
    4fdb:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    4fe0:	4d 01 d0                                        	add    r8,r10
    4fe3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    4fe8:	4d 01 d0                                        	add    r8,r10
    4feb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    4ff0:	4d 01 d0                                        	add    r8,r10
    4ff3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    4ff8:	4d 01 d0                                        	add    r8,r10
    4ffb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5000:	4d 01 d0                                        	add    r8,r10
    5003:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5008:	4d 01 d0                                        	add    r8,r10
    500b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5010:	4d 01 d0                                        	add    r8,r10
    5013:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5018:	4d 01 d0                                        	add    r8,r10
    501b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5020:	4d 01 d0                                        	add    r8,r10
    5023:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5028:	4d 01 d0                                        	add    r8,r10
    502b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5030:	4d 01 d0                                        	add    r8,r10
    5033:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5038:	4d 01 d0                                        	add    r8,r10
    503b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5040:	4d 01 d0                                        	add    r8,r10
    5043:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5048:	4d 01 d0                                        	add    r8,r10
    504b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5050:	4d 01 d0                                        	add    r8,r10
    5053:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5058:	4d 01 d0                                        	add    r8,r10
    505b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5060:	4d 01 d0                                        	add    r8,r10
    5063:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5068:	4d 01 d0                                        	add    r8,r10
    506b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5070:	4d 01 d0                                        	add    r8,r10
    5073:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5078:	4d 01 d0                                        	add    r8,r10
    507b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5080:	4d 01 d0                                        	add    r8,r10
    5083:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5088:	4d 01 d0                                        	add    r8,r10
    508b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5090:	4d 01 d0                                        	add    r8,r10
    5093:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5098:	4d 01 d0                                        	add    r8,r10
    509b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    50a0:	4d 01 d0                                        	add    r8,r10
    50a3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    50a8:	4d 01 d0                                        	add    r8,r10
    50ab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    50b0:	4d 01 d0                                        	add    r8,r10
    50b3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    50b8:	4d 01 d0                                        	add    r8,r10
    50bb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    50c0:	4d 01 d0                                        	add    r8,r10
    50c3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    50c8:	4d 01 d0                                        	add    r8,r10
    50cb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    50d0:	4d 01 d0                                        	add    r8,r10
    50d3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    50d8:	4d 01 d0                                        	add    r8,r10
    50db:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    50e0:	4d 01 d0                                        	add    r8,r10
    50e3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    50e8:	4d 01 d0                                        	add    r8,r10
    50eb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    50f0:	4d 01 d0                                        	add    r8,r10
    50f3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    50f8:	4d 01 d0                                        	add    r8,r10
    50fb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5100:	4d 01 d0                                        	add    r8,r10
    5103:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5108:	4d 01 d0                                        	add    r8,r10
    510b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5110:	4d 01 d0                                        	add    r8,r10
    5113:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5118:	4d 01 d0                                        	add    r8,r10
    511b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5120:	4d 01 d0                                        	add    r8,r10
    5123:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5128:	4d 01 d0                                        	add    r8,r10
    512b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5130:	4d 01 d0                                        	add    r8,r10
    5133:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5138:	4d 01 d0                                        	add    r8,r10
    513b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5140:	4d 01 d0                                        	add    r8,r10
    5143:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5148:	4d 01 d0                                        	add    r8,r10
    514b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5150:	4d 01 d0                                        	add    r8,r10
    5153:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5158:	4d 01 d0                                        	add    r8,r10
    515b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5160:	4d 01 d0                                        	add    r8,r10
    5163:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5168:	4d 01 d0                                        	add    r8,r10
    516b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5170:	4d 01 d0                                        	add    r8,r10
    5173:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5178:	4d 01 d0                                        	add    r8,r10
    517b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5180:	4d 01 d0                                        	add    r8,r10
    5183:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5188:	4d 01 d0                                        	add    r8,r10
    518b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5190:	4d 01 d0                                        	add    r8,r10
    5193:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5198:	4d 01 d0                                        	add    r8,r10
    519b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    51a0:	4d 01 d0                                        	add    r8,r10
    51a3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    51a8:	4d 01 d0                                        	add    r8,r10
    51ab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    51b0:	4d 01 d0                                        	add    r8,r10
    51b3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    51b8:	4d 01 d0                                        	add    r8,r10
    51bb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    51c0:	4d 01 d0                                        	add    r8,r10
    51c3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    51c8:	4d 01 d0                                        	add    r8,r10
    51cb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    51d0:	4d 01 d0                                        	add    r8,r10
    51d3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    51d8:	4d 01 d0                                        	add    r8,r10
    51db:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    51e0:	4d 01 d0                                        	add    r8,r10
    51e3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    51e8:	4d 01 d0                                        	add    r8,r10
    51eb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    51f0:	4d 01 d0                                        	add    r8,r10
    51f3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    51f8:	4d 01 d0                                        	add    r8,r10
    51fb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5200:	4d 01 d0                                        	add    r8,r10
    5203:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5208:	4d 01 d0                                        	add    r8,r10
    520b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5210:	4d 01 d0                                        	add    r8,r10
    5213:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5218:	4d 01 d0                                        	add    r8,r10
    521b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5220:	4d 01 d0                                        	add    r8,r10
    5223:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5228:	4d 01 d0                                        	add    r8,r10
    522b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5230:	4d 01 d0                                        	add    r8,r10
    5233:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5238:	4d 01 d0                                        	add    r8,r10
    523b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5240:	4d 01 d0                                        	add    r8,r10
    5243:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5248:	4d 01 d0                                        	add    r8,r10
    524b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5250:	4d 01 d0                                        	add    r8,r10
    5253:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5258:	4d 01 d0                                        	add    r8,r10
    525b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5260:	4d 01 d0                                        	add    r8,r10
    5263:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5268:	4d 01 d0                                        	add    r8,r10
    526b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5270:	4d 01 d0                                        	add    r8,r10
    5273:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5278:	4d 01 d0                                        	add    r8,r10
    527b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5280:	4d 01 d0                                        	add    r8,r10
    5283:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5288:	4d 01 d0                                        	add    r8,r10
    528b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5290:	4d 01 d0                                        	add    r8,r10
    5293:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5298:	4d 01 d0                                        	add    r8,r10
    529b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    52a0:	4d 01 d0                                        	add    r8,r10
    52a3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    52a8:	4d 01 d0                                        	add    r8,r10
    52ab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    52b0:	4d 01 d0                                        	add    r8,r10
    52b3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    52b8:	4d 01 d0                                        	add    r8,r10
    52bb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    52c0:	4d 01 d0                                        	add    r8,r10
    52c3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    52c8:	4d 01 d0                                        	add    r8,r10
    52cb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    52d0:	4d 01 d0                                        	add    r8,r10
    52d3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    52d8:	4d 01 d0                                        	add    r8,r10
    52db:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    52e0:	4d 01 d0                                        	add    r8,r10
    52e3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    52e8:	4d 01 d0                                        	add    r8,r10
    52eb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    52f0:	4d 01 d0                                        	add    r8,r10
    52f3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    52f8:	4d 01 d0                                        	add    r8,r10
    52fb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5300:	4d 01 d0                                        	add    r8,r10
    5303:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5308:	4d 01 d0                                        	add    r8,r10
    530b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5310:	4d 01 d0                                        	add    r8,r10
    5313:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5318:	4d 01 d0                                        	add    r8,r10
    531b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5320:	4d 01 d0                                        	add    r8,r10
    5323:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5328:	4d 01 d0                                        	add    r8,r10
    532b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5330:	4d 01 d0                                        	add    r8,r10
    5333:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5338:	4d 01 d0                                        	add    r8,r10
    533b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5340:	4d 01 d0                                        	add    r8,r10
    5343:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5348:	4d 01 d0                                        	add    r8,r10
    534b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5350:	4d 01 d0                                        	add    r8,r10
    5353:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5358:	4d 01 d0                                        	add    r8,r10
    535b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5360:	4d 01 d0                                        	add    r8,r10
    5363:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5368:	4d 01 d0                                        	add    r8,r10
    536b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5370:	4d 01 d0                                        	add    r8,r10
    5373:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5378:	4d 01 d0                                        	add    r8,r10
    537b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5380:	4d 01 d0                                        	add    r8,r10
    5383:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5388:	4d 01 d0                                        	add    r8,r10
    538b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5390:	4d 01 d0                                        	add    r8,r10
    5393:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5398:	4d 01 d0                                        	add    r8,r10
    539b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    53a0:	4d 01 d0                                        	add    r8,r10
    53a3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    53a8:	4d 01 d0                                        	add    r8,r10
    53ab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    53b0:	4d 01 d0                                        	add    r8,r10
    53b3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    53b8:	4d 01 d0                                        	add    r8,r10
    53bb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    53c0:	4d 01 d0                                        	add    r8,r10
    53c3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    53c8:	4d 01 d0                                        	add    r8,r10
    53cb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    53d0:	4d 01 d0                                        	add    r8,r10
    53d3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    53d8:	4d 01 d0                                        	add    r8,r10
    53db:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    53e0:	4d 01 d0                                        	add    r8,r10
    53e3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    53e8:	4d 01 d0                                        	add    r8,r10
    53eb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    53f0:	4d 01 d0                                        	add    r8,r10
    53f3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    53f8:	4d 01 d0                                        	add    r8,r10
    53fb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5400:	4d 01 d0                                        	add    r8,r10
    5403:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5408:	4d 01 d0                                        	add    r8,r10
    540b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5410:	4d 01 d0                                        	add    r8,r10
    5413:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5418:	4d 01 d0                                        	add    r8,r10
    541b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5420:	4d 01 d0                                        	add    r8,r10
    5423:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5428:	4d 01 d0                                        	add    r8,r10
    542b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5430:	4d 01 d0                                        	add    r8,r10
    5433:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5438:	4d 01 d0                                        	add    r8,r10
    543b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5440:	4d 01 d0                                        	add    r8,r10
    5443:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5448:	4d 01 d0                                        	add    r8,r10
    544b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5450:	4d 01 d0                                        	add    r8,r10
    5453:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5458:	4d 01 d0                                        	add    r8,r10
    545b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5460:	4d 01 d0                                        	add    r8,r10
    5463:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5468:	4d 01 d0                                        	add    r8,r10
    546b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5470:	4d 01 d0                                        	add    r8,r10
    5473:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5478:	4d 01 d0                                        	add    r8,r10
    547b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5480:	4d 01 d0                                        	add    r8,r10
    5483:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5488:	4d 01 d0                                        	add    r8,r10
    548b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5490:	4d 01 d0                                        	add    r8,r10
    5493:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5498:	4d 01 d0                                        	add    r8,r10
    549b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    54a0:	4d 01 d0                                        	add    r8,r10
    54a3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    54a8:	4d 01 d0                                        	add    r8,r10
    54ab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    54b0:	4d 01 d0                                        	add    r8,r10
    54b3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    54b8:	4d 01 d0                                        	add    r8,r10
    54bb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    54c0:	4d 01 d0                                        	add    r8,r10
    54c3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    54c8:	4d 01 d0                                        	add    r8,r10
    54cb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    54d0:	4d 01 d0                                        	add    r8,r10
    54d3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    54d8:	4d 01 d0                                        	add    r8,r10
    54db:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    54e0:	4d 01 d0                                        	add    r8,r10
    54e3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    54e8:	4d 01 d0                                        	add    r8,r10
    54eb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    54f0:	4d 01 d0                                        	add    r8,r10
    54f3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    54f8:	4d 01 d0                                        	add    r8,r10
    54fb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5500:	4d 01 d0                                        	add    r8,r10
    5503:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5508:	4d 01 d0                                        	add    r8,r10
    550b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5510:	4d 01 d0                                        	add    r8,r10
    5513:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5518:	4d 01 d0                                        	add    r8,r10
    551b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5520:	4d 01 d0                                        	add    r8,r10
    5523:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5528:	4d 01 d0                                        	add    r8,r10
    552b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5530:	4d 01 d0                                        	add    r8,r10
    5533:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5538:	4d 01 d0                                        	add    r8,r10
    553b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5540:	4d 01 d0                                        	add    r8,r10
    5543:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5548:	4d 01 d0                                        	add    r8,r10
    554b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5550:	4d 01 d0                                        	add    r8,r10
    5553:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5558:	4d 01 d0                                        	add    r8,r10
    555b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5560:	4d 01 d0                                        	add    r8,r10
    5563:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5568:	4d 01 d0                                        	add    r8,r10
    556b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5570:	4d 01 d0                                        	add    r8,r10
    5573:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5578:	4d 01 d0                                        	add    r8,r10
    557b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5580:	4d 01 d0                                        	add    r8,r10
    5583:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5588:	4d 01 d0                                        	add    r8,r10
    558b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5590:	4d 01 d0                                        	add    r8,r10
    5593:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5598:	4d 01 d0                                        	add    r8,r10
    559b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    55a0:	4d 01 d0                                        	add    r8,r10
    55a3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    55a8:	4d 01 d0                                        	add    r8,r10
    55ab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    55b0:	4d 01 d0                                        	add    r8,r10
    55b3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    55b8:	4d 01 d0                                        	add    r8,r10
    55bb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    55c0:	4d 01 d0                                        	add    r8,r10
    55c3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    55c8:	4d 01 d0                                        	add    r8,r10
    55cb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    55d0:	4d 01 d0                                        	add    r8,r10
    55d3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    55d8:	4d 01 d0                                        	add    r8,r10
    55db:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    55e0:	4d 01 d0                                        	add    r8,r10
    55e3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    55e8:	4d 01 d0                                        	add    r8,r10
    55eb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    55f0:	4d 01 d0                                        	add    r8,r10
    55f3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    55f8:	4d 01 d0                                        	add    r8,r10
    55fb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5600:	4d 01 d0                                        	add    r8,r10
    5603:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5608:	4d 01 d0                                        	add    r8,r10
    560b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5610:	4d 01 d0                                        	add    r8,r10
    5613:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5618:	4d 01 d0                                        	add    r8,r10
    561b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5620:	4d 01 d0                                        	add    r8,r10
    5623:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5628:	4d 01 d0                                        	add    r8,r10
    562b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5630:	4d 01 d0                                        	add    r8,r10
    5633:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5638:	4d 01 d0                                        	add    r8,r10
    563b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5640:	4d 01 d0                                        	add    r8,r10
    5643:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5648:	4d 01 d0                                        	add    r8,r10
    564b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5650:	4d 01 d0                                        	add    r8,r10
    5653:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5658:	4d 01 d0                                        	add    r8,r10
    565b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5660:	4d 01 d0                                        	add    r8,r10
    5663:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5668:	4d 01 d0                                        	add    r8,r10
    566b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5670:	4d 01 d0                                        	add    r8,r10
    5673:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5678:	4d 01 d0                                        	add    r8,r10
    567b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5680:	4d 01 d0                                        	add    r8,r10
    5683:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5688:	4d 01 d0                                        	add    r8,r10
    568b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5690:	4d 01 d0                                        	add    r8,r10
    5693:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5698:	4d 01 d0                                        	add    r8,r10
    569b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    56a0:	4d 01 d0                                        	add    r8,r10
    56a3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    56a8:	4d 01 d0                                        	add    r8,r10
    56ab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    56b0:	4d 01 d0                                        	add    r8,r10
    56b3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    56b8:	4d 01 d0                                        	add    r8,r10
    56bb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    56c0:	4d 01 d0                                        	add    r8,r10
    56c3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    56c8:	4d 01 d0                                        	add    r8,r10
    56cb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    56d0:	4d 01 d0                                        	add    r8,r10
    56d3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    56d8:	4d 01 d0                                        	add    r8,r10
    56db:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    56e0:	4d 01 d0                                        	add    r8,r10
    56e3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    56e8:	4d 01 d0                                        	add    r8,r10
    56eb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    56f0:	4d 01 d0                                        	add    r8,r10
    56f3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    56f8:	4d 01 d0                                        	add    r8,r10
    56fb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5700:	4d 01 d0                                        	add    r8,r10
    5703:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5708:	4d 01 d0                                        	add    r8,r10
    570b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5710:	4d 01 d0                                        	add    r8,r10
    5713:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5718:	4d 01 d0                                        	add    r8,r10
    571b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5720:	4d 01 d0                                        	add    r8,r10
    5723:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5728:	4d 01 d0                                        	add    r8,r10
    572b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5730:	4d 01 d0                                        	add    r8,r10
    5733:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5738:	4d 01 d0                                        	add    r8,r10
    573b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5740:	4d 01 d0                                        	add    r8,r10
    5743:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5748:	4d 01 d0                                        	add    r8,r10
    574b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5750:	4d 01 d0                                        	add    r8,r10
    5753:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5758:	4d 01 d0                                        	add    r8,r10
    575b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5760:	4d 01 d0                                        	add    r8,r10
    5763:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5768:	4d 01 d0                                        	add    r8,r10
    576b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5770:	4d 01 d0                                        	add    r8,r10
    5773:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5778:	4d 01 d0                                        	add    r8,r10
    577b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5780:	4d 01 d0                                        	add    r8,r10
    5783:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5788:	4d 01 d0                                        	add    r8,r10
    578b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5790:	4d 01 d0                                        	add    r8,r10
    5793:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5798:	4d 01 d0                                        	add    r8,r10
    579b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    57a0:	4d 01 d0                                        	add    r8,r10
    57a3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    57a8:	4d 01 d0                                        	add    r8,r10
    57ab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    57b0:	4d 01 d0                                        	add    r8,r10
    57b3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    57b8:	4d 01 d0                                        	add    r8,r10
    57bb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    57c0:	4d 01 d0                                        	add    r8,r10
    57c3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    57c8:	4d 01 d0                                        	add    r8,r10
    57cb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    57d0:	4d 01 d0                                        	add    r8,r10
    57d3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    57d8:	4d 01 d0                                        	add    r8,r10
    57db:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    57e0:	4d 01 d0                                        	add    r8,r10
    57e3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    57e8:	4d 01 d0                                        	add    r8,r10
    57eb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    57f0:	4d 01 d0                                        	add    r8,r10
    57f3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    57f8:	4d 01 d0                                        	add    r8,r10
    57fb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5800:	4d 01 d0                                        	add    r8,r10
    5803:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5808:	4d 01 d0                                        	add    r8,r10
    580b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5810:	4d 01 d0                                        	add    r8,r10
    5813:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5818:	4d 01 d0                                        	add    r8,r10
    581b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5820:	4d 01 d0                                        	add    r8,r10
    5823:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5828:	4d 01 d0                                        	add    r8,r10
    582b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5830:	4d 01 d0                                        	add    r8,r10
    5833:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5838:	4d 01 d0                                        	add    r8,r10
    583b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5840:	4d 01 d0                                        	add    r8,r10
    5843:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5848:	4d 01 d0                                        	add    r8,r10
    584b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5850:	4d 01 d0                                        	add    r8,r10
    5853:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5858:	4d 01 d0                                        	add    r8,r10
    585b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5860:	4d 01 d0                                        	add    r8,r10
    5863:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5868:	4d 01 d0                                        	add    r8,r10
    586b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5870:	4d 01 d0                                        	add    r8,r10
    5873:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5878:	4d 01 d0                                        	add    r8,r10
    587b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5880:	4d 01 d0                                        	add    r8,r10
    5883:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5888:	4d 01 d0                                        	add    r8,r10
    588b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5890:	4d 01 d0                                        	add    r8,r10
    5893:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5898:	4d 01 d0                                        	add    r8,r10
    589b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    58a0:	4d 01 d0                                        	add    r8,r10
    58a3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    58a8:	4d 01 d0                                        	add    r8,r10
    58ab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    58b0:	4d 01 d0                                        	add    r8,r10
    58b3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    58b8:	4d 01 d0                                        	add    r8,r10
    58bb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    58c0:	4d 01 d0                                        	add    r8,r10
    58c3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    58c8:	4d 01 d0                                        	add    r8,r10
    58cb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    58d0:	4d 01 d0                                        	add    r8,r10
    58d3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    58d8:	4d 01 d0                                        	add    r8,r10
    58db:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    58e0:	4d 01 d0                                        	add    r8,r10
    58e3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    58e8:	4d 01 d0                                        	add    r8,r10
    58eb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    58f0:	4d 01 d0                                        	add    r8,r10
    58f3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    58f8:	4d 01 d0                                        	add    r8,r10
    58fb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5900:	4d 01 d0                                        	add    r8,r10
    5903:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5908:	4d 01 d0                                        	add    r8,r10
    590b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5910:	4d 01 d0                                        	add    r8,r10
    5913:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5918:	4d 01 d0                                        	add    r8,r10
    591b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5920:	4d 01 d0                                        	add    r8,r10
    5923:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5928:	4d 01 d0                                        	add    r8,r10
    592b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5930:	4d 01 d0                                        	add    r8,r10
    5933:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5938:	4d 01 d0                                        	add    r8,r10
    593b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5940:	4d 01 d0                                        	add    r8,r10
    5943:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5948:	4d 01 d0                                        	add    r8,r10
    594b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5950:	4d 01 d0                                        	add    r8,r10
    5953:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5958:	4d 01 d0                                        	add    r8,r10
    595b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5960:	4d 01 d0                                        	add    r8,r10
    5963:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5968:	4d 01 d0                                        	add    r8,r10
    596b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5970:	4d 01 d0                                        	add    r8,r10
    5973:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5978:	4d 01 d0                                        	add    r8,r10
    597b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5980:	4d 01 d0                                        	add    r8,r10
    5983:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5988:	4d 01 d0                                        	add    r8,r10
    598b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5990:	4d 01 d0                                        	add    r8,r10
    5993:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5998:	4d 01 d0                                        	add    r8,r10
    599b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    59a0:	4d 01 d0                                        	add    r8,r10
    59a3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    59a8:	4d 01 d0                                        	add    r8,r10
    59ab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    59b0:	4d 01 d0                                        	add    r8,r10
    59b3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    59b8:	4d 01 d0                                        	add    r8,r10
    59bb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    59c0:	4d 01 d0                                        	add    r8,r10
    59c3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    59c8:	4d 01 d0                                        	add    r8,r10
    59cb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    59d0:	4d 01 d0                                        	add    r8,r10
    59d3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    59d8:	4d 01 d0                                        	add    r8,r10
    59db:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    59e0:	4d 01 d0                                        	add    r8,r10
    59e3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    59e8:	4d 01 d0                                        	add    r8,r10
    59eb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    59f0:	4d 01 d0                                        	add    r8,r10
    59f3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    59f8:	4d 01 d0                                        	add    r8,r10
    59fb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5a00:	4d 01 d0                                        	add    r8,r10
    5a03:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5a08:	4d 01 d0                                        	add    r8,r10
    5a0b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5a10:	4d 01 d0                                        	add    r8,r10
    5a13:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5a18:	4d 01 d0                                        	add    r8,r10
    5a1b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5a20:	4d 01 d0                                        	add    r8,r10
    5a23:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5a28:	4d 01 d0                                        	add    r8,r10
    5a2b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5a30:	4d 01 d0                                        	add    r8,r10
    5a33:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5a38:	4d 01 d0                                        	add    r8,r10
    5a3b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5a40:	4d 01 d0                                        	add    r8,r10
    5a43:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5a48:	4d 01 d0                                        	add    r8,r10
    5a4b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5a50:	4d 01 d0                                        	add    r8,r10
    5a53:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5a58:	4d 01 d0                                        	add    r8,r10
    5a5b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5a60:	4d 01 d0                                        	add    r8,r10
    5a63:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5a68:	4d 01 d0                                        	add    r8,r10
    5a6b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5a70:	4d 01 d0                                        	add    r8,r10
    5a73:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5a78:	4d 01 d0                                        	add    r8,r10
    5a7b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5a80:	4d 01 d0                                        	add    r8,r10
    5a83:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5a88:	4d 01 d0                                        	add    r8,r10
    5a8b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5a90:	4d 01 d0                                        	add    r8,r10
    5a93:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5a98:	4d 01 d0                                        	add    r8,r10
    5a9b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5aa0:	4d 01 d0                                        	add    r8,r10
    5aa3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5aa8:	4d 01 d0                                        	add    r8,r10
    5aab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5ab0:	4d 01 d0                                        	add    r8,r10
    5ab3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5ab8:	4d 01 d0                                        	add    r8,r10
    5abb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5ac0:	4d 01 d0                                        	add    r8,r10
    5ac3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5ac8:	4d 01 d0                                        	add    r8,r10
    5acb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5ad0:	4d 01 d0                                        	add    r8,r10
    5ad3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5ad8:	4d 01 d0                                        	add    r8,r10
    5adb:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5ae0:	4d 01 d0                                        	add    r8,r10
    5ae3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5ae8:	4d 01 d0                                        	add    r8,r10
    5aeb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5af0:	4d 01 d0                                        	add    r8,r10
    5af3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5af8:	4d 01 d0                                        	add    r8,r10
    5afb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5b00:	4d 01 d0                                        	add    r8,r10
    5b03:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5b08:	4d 01 d0                                        	add    r8,r10
    5b0b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5b10:	4d 01 d0                                        	add    r8,r10
    5b13:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5b18:	4d 01 d0                                        	add    r8,r10
    5b1b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5b20:	4d 01 d0                                        	add    r8,r10
    5b23:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5b28:	4d 01 d0                                        	add    r8,r10
    5b2b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5b30:	4d 01 d0                                        	add    r8,r10
    5b33:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5b38:	4d 01 d0                                        	add    r8,r10
    5b3b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5b40:	4d 01 d0                                        	add    r8,r10
    5b43:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5b48:	4d 01 d0                                        	add    r8,r10
    5b4b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5b50:	4d 01 d0                                        	add    r8,r10
    5b53:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5b58:	4d 01 d0                                        	add    r8,r10
    5b5b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5b60:	4d 01 d0                                        	add    r8,r10
    5b63:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5b68:	4d 01 d0                                        	add    r8,r10
    5b6b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5b70:	4d 01 d0                                        	add    r8,r10
    5b73:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5b78:	4d 01 d0                                        	add    r8,r10
    5b7b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5b80:	4d 01 d0                                        	add    r8,r10
    5b83:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5b88:	4d 01 d0                                        	add    r8,r10
    5b8b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5b90:	4d 01 d0                                        	add    r8,r10
    5b93:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5b98:	4d 01 d0                                        	add    r8,r10
    5b9b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5ba0:	4d 01 d0                                        	add    r8,r10
    5ba3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5ba8:	4d 01 d0                                        	add    r8,r10
    5bab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5bb0:	4d 01 d0                                        	add    r8,r10
    5bb3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5bb8:	4d 01 d0                                        	add    r8,r10
    5bbb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5bc0:	4d 01 d0                                        	add    r8,r10
    5bc3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5bc8:	4d 01 d0                                        	add    r8,r10
    5bcb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5bd0:	4d 01 d0                                        	add    r8,r10
    5bd3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5bd8:	4d 01 d0                                        	add    r8,r10
    5bdb:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5be0:	4d 01 d0                                        	add    r8,r10
    5be3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5be8:	4d 01 d0                                        	add    r8,r10
    5beb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5bf0:	4d 01 d0                                        	add    r8,r10
    5bf3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5bf8:	4d 01 d0                                        	add    r8,r10
    5bfb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5c00:	4d 01 d0                                        	add    r8,r10
    5c03:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5c08:	4d 01 d0                                        	add    r8,r10
    5c0b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5c10:	4d 01 d0                                        	add    r8,r10
    5c13:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5c18:	4d 01 d0                                        	add    r8,r10
    5c1b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5c20:	4d 01 d0                                        	add    r8,r10
    5c23:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5c28:	4d 01 d0                                        	add    r8,r10
    5c2b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5c30:	4d 01 d0                                        	add    r8,r10
    5c33:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5c38:	4d 01 d0                                        	add    r8,r10
    5c3b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5c40:	4d 01 d0                                        	add    r8,r10
    5c43:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5c48:	4d 01 d0                                        	add    r8,r10
    5c4b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5c50:	4d 01 d0                                        	add    r8,r10
    5c53:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5c58:	4d 01 d0                                        	add    r8,r10
    5c5b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5c60:	4d 01 d0                                        	add    r8,r10
    5c63:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5c68:	4d 01 d0                                        	add    r8,r10
    5c6b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5c70:	4d 01 d0                                        	add    r8,r10
    5c73:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5c78:	4d 01 d0                                        	add    r8,r10
    5c7b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5c80:	4d 01 d0                                        	add    r8,r10
    5c83:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5c88:	4d 01 d0                                        	add    r8,r10
    5c8b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5c90:	4d 01 d0                                        	add    r8,r10
    5c93:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5c98:	4d 01 d0                                        	add    r8,r10
    5c9b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5ca0:	4d 01 d0                                        	add    r8,r10
    5ca3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5ca8:	4d 01 d0                                        	add    r8,r10
    5cab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5cb0:	4d 01 d0                                        	add    r8,r10
    5cb3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5cb8:	4d 01 d0                                        	add    r8,r10
    5cbb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5cc0:	4d 01 d0                                        	add    r8,r10
    5cc3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5cc8:	4d 01 d0                                        	add    r8,r10
    5ccb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5cd0:	4d 01 d0                                        	add    r8,r10
    5cd3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5cd8:	4d 01 d0                                        	add    r8,r10
    5cdb:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5ce0:	4d 01 d0                                        	add    r8,r10
    5ce3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5ce8:	4d 01 d0                                        	add    r8,r10
    5ceb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5cf0:	4d 01 d0                                        	add    r8,r10
    5cf3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5cf8:	4d 01 d0                                        	add    r8,r10
    5cfb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5d00:	4d 01 d0                                        	add    r8,r10
    5d03:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5d08:	4d 01 d0                                        	add    r8,r10
    5d0b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5d10:	4d 01 d0                                        	add    r8,r10
    5d13:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5d18:	4d 01 d0                                        	add    r8,r10
    5d1b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5d20:	4d 01 d0                                        	add    r8,r10
    5d23:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5d28:	4d 01 d0                                        	add    r8,r10
    5d2b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5d30:	4d 01 d0                                        	add    r8,r10
    5d33:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5d38:	4d 01 d0                                        	add    r8,r10
    5d3b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5d40:	4d 01 d0                                        	add    r8,r10
    5d43:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5d48:	4d 01 d0                                        	add    r8,r10
    5d4b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5d50:	4d 01 d0                                        	add    r8,r10
    5d53:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5d58:	4d 01 d0                                        	add    r8,r10
    5d5b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5d60:	4d 01 d0                                        	add    r8,r10
    5d63:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5d68:	4d 01 d0                                        	add    r8,r10
    5d6b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5d70:	4d 01 d0                                        	add    r8,r10
    5d73:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5d78:	4d 01 d0                                        	add    r8,r10
    5d7b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5d80:	4d 01 d0                                        	add    r8,r10
    5d83:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5d88:	4d 01 d0                                        	add    r8,r10
    5d8b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5d90:	4d 01 d0                                        	add    r8,r10
    5d93:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5d98:	4d 01 d0                                        	add    r8,r10
    5d9b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5da0:	4d 01 d0                                        	add    r8,r10
    5da3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5da8:	4d 01 d0                                        	add    r8,r10
    5dab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5db0:	4d 01 d0                                        	add    r8,r10
    5db3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5db8:	4d 01 d0                                        	add    r8,r10
    5dbb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5dc0:	4d 01 d0                                        	add    r8,r10
    5dc3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5dc8:	4d 01 d0                                        	add    r8,r10
    5dcb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5dd0:	4d 01 d0                                        	add    r8,r10
    5dd3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5dd8:	4d 01 d0                                        	add    r8,r10
    5ddb:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5de0:	4d 01 d0                                        	add    r8,r10
    5de3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5de8:	4d 01 d0                                        	add    r8,r10
    5deb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5df0:	4d 01 d0                                        	add    r8,r10
    5df3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5df8:	4d 01 d0                                        	add    r8,r10
    5dfb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5e00:	4d 01 d0                                        	add    r8,r10
    5e03:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5e08:	4d 01 d0                                        	add    r8,r10
    5e0b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5e10:	4d 01 d0                                        	add    r8,r10
    5e13:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5e18:	4d 01 d0                                        	add    r8,r10
    5e1b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5e20:	4d 01 d0                                        	add    r8,r10
    5e23:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5e28:	4d 01 d0                                        	add    r8,r10
    5e2b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5e30:	4d 01 d0                                        	add    r8,r10
    5e33:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5e38:	4d 01 d0                                        	add    r8,r10
    5e3b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5e40:	4d 01 d0                                        	add    r8,r10
    5e43:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5e48:	4d 01 d0                                        	add    r8,r10
    5e4b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5e50:	4d 01 d0                                        	add    r8,r10
    5e53:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5e58:	4d 01 d0                                        	add    r8,r10
    5e5b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5e60:	4d 01 d0                                        	add    r8,r10
    5e63:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5e68:	4d 01 d0                                        	add    r8,r10
    5e6b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5e70:	4d 01 d0                                        	add    r8,r10
    5e73:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5e78:	4d 01 d0                                        	add    r8,r10
    5e7b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5e80:	4d 01 d0                                        	add    r8,r10
    5e83:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5e88:	4d 01 d0                                        	add    r8,r10
    5e8b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5e90:	4d 01 d0                                        	add    r8,r10
    5e93:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5e98:	4d 01 d0                                        	add    r8,r10
    5e9b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5ea0:	4d 01 d0                                        	add    r8,r10
    5ea3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5ea8:	4d 01 d0                                        	add    r8,r10
    5eab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5eb0:	4d 01 d0                                        	add    r8,r10
    5eb3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5eb8:	4d 01 d0                                        	add    r8,r10
    5ebb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5ec0:	4d 01 d0                                        	add    r8,r10
    5ec3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5ec8:	4d 01 d0                                        	add    r8,r10
    5ecb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5ed0:	4d 01 d0                                        	add    r8,r10
    5ed3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5ed8:	4d 01 d0                                        	add    r8,r10
    5edb:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5ee0:	4d 01 d0                                        	add    r8,r10
    5ee3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5ee8:	4d 01 d0                                        	add    r8,r10
    5eeb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5ef0:	4d 01 d0                                        	add    r8,r10
    5ef3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5ef8:	4d 01 d0                                        	add    r8,r10
    5efb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5f00:	4d 01 d0                                        	add    r8,r10
    5f03:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5f08:	4d 01 d0                                        	add    r8,r10
    5f0b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5f10:	4d 01 d0                                        	add    r8,r10
    5f13:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5f18:	4d 01 d0                                        	add    r8,r10
    5f1b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5f20:	4d 01 d0                                        	add    r8,r10
    5f23:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5f28:	4d 01 d0                                        	add    r8,r10
    5f2b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5f30:	4d 01 d0                                        	add    r8,r10
    5f33:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5f38:	4d 01 d0                                        	add    r8,r10
    5f3b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5f40:	4d 01 d0                                        	add    r8,r10
    5f43:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5f48:	4d 01 d0                                        	add    r8,r10
    5f4b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5f50:	4d 01 d0                                        	add    r8,r10
    5f53:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5f58:	4d 01 d0                                        	add    r8,r10
    5f5b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5f60:	4d 01 d0                                        	add    r8,r10
    5f63:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5f68:	4d 01 d0                                        	add    r8,r10
    5f6b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5f70:	4d 01 d0                                        	add    r8,r10
    5f73:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5f78:	4d 01 d0                                        	add    r8,r10
    5f7b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5f80:	4d 01 d0                                        	add    r8,r10
    5f83:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5f88:	4d 01 d0                                        	add    r8,r10
    5f8b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5f90:	4d 01 d0                                        	add    r8,r10
    5f93:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5f98:	4d 01 d0                                        	add    r8,r10
    5f9b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5fa0:	4d 01 d0                                        	add    r8,r10
    5fa3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5fa8:	4d 01 d0                                        	add    r8,r10
    5fab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5fb0:	4d 01 d0                                        	add    r8,r10
    5fb3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5fb8:	4d 01 d0                                        	add    r8,r10
    5fbb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    5fc0:	4d 01 d0                                        	add    r8,r10
    5fc3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    5fc8:	4d 01 d0                                        	add    r8,r10
    5fcb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    5fd0:	4d 01 d0                                        	add    r8,r10
    5fd3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    5fd8:	4d 01 d0                                        	add    r8,r10
    5fdb:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    5fe0:	4d 01 d0                                        	add    r8,r10
    5fe3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    5fe8:	4d 01 d0                                        	add    r8,r10
    5feb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    5ff0:	4d 01 d0                                        	add    r8,r10
    5ff3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    5ff8:	4d 01 d0                                        	add    r8,r10
    5ffb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6000:	4d 01 d0                                        	add    r8,r10
    6003:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6008:	4d 01 d0                                        	add    r8,r10
    600b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6010:	4d 01 d0                                        	add    r8,r10
    6013:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6018:	4d 01 d0                                        	add    r8,r10
    601b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6020:	4d 01 d0                                        	add    r8,r10
    6023:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6028:	4d 01 d0                                        	add    r8,r10
    602b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6030:	4d 01 d0                                        	add    r8,r10
    6033:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6038:	4d 01 d0                                        	add    r8,r10
    603b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6040:	4d 01 d0                                        	add    r8,r10
    6043:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6048:	4d 01 d0                                        	add    r8,r10
    604b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6050:	4d 01 d0                                        	add    r8,r10
    6053:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6058:	4d 01 d0                                        	add    r8,r10
    605b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6060:	4d 01 d0                                        	add    r8,r10
    6063:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6068:	4d 01 d0                                        	add    r8,r10
    606b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6070:	4d 01 d0                                        	add    r8,r10
    6073:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6078:	4d 01 d0                                        	add    r8,r10
    607b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6080:	4d 01 d0                                        	add    r8,r10
    6083:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6088:	4d 01 d0                                        	add    r8,r10
    608b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6090:	4d 01 d0                                        	add    r8,r10
    6093:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6098:	4d 01 d0                                        	add    r8,r10
    609b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    60a0:	4d 01 d0                                        	add    r8,r10
    60a3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    60a8:	4d 01 d0                                        	add    r8,r10
    60ab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    60b0:	4d 01 d0                                        	add    r8,r10
    60b3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    60b8:	4d 01 d0                                        	add    r8,r10
    60bb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    60c0:	4d 01 d0                                        	add    r8,r10
    60c3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    60c8:	4d 01 d0                                        	add    r8,r10
    60cb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    60d0:	4d 01 d0                                        	add    r8,r10
    60d3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    60d8:	4d 01 d0                                        	add    r8,r10
    60db:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    60e0:	4d 01 d0                                        	add    r8,r10
    60e3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    60e8:	4d 01 d0                                        	add    r8,r10
    60eb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    60f0:	4d 01 d0                                        	add    r8,r10
    60f3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    60f8:	4d 01 d0                                        	add    r8,r10
    60fb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6100:	4d 01 d0                                        	add    r8,r10
    6103:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6108:	4d 01 d0                                        	add    r8,r10
    610b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6110:	4d 01 d0                                        	add    r8,r10
    6113:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6118:	4d 01 d0                                        	add    r8,r10
    611b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6120:	4d 01 d0                                        	add    r8,r10
    6123:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6128:	4d 01 d0                                        	add    r8,r10
    612b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6130:	4d 01 d0                                        	add    r8,r10
    6133:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6138:	4d 01 d0                                        	add    r8,r10
    613b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6140:	4d 01 d0                                        	add    r8,r10
    6143:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6148:	4d 01 d0                                        	add    r8,r10
    614b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6150:	4d 01 d0                                        	add    r8,r10
    6153:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6158:	4d 01 d0                                        	add    r8,r10
    615b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6160:	4d 01 d0                                        	add    r8,r10
    6163:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6168:	4d 01 d0                                        	add    r8,r10
    616b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6170:	4d 01 d0                                        	add    r8,r10
    6173:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6178:	4d 01 d0                                        	add    r8,r10
    617b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6180:	4d 01 d0                                        	add    r8,r10
    6183:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6188:	4d 01 d0                                        	add    r8,r10
    618b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6190:	4d 01 d0                                        	add    r8,r10
    6193:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6198:	4d 01 d0                                        	add    r8,r10
    619b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    61a0:	4d 01 d0                                        	add    r8,r10
    61a3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    61a8:	4d 01 d0                                        	add    r8,r10
    61ab:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    61b0:	4d 01 d0                                        	add    r8,r10
    61b3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    61b8:	4d 01 d0                                        	add    r8,r10
    61bb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    61c0:	4d 01 d0                                        	add    r8,r10
    61c3:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    61c8:	4d 01 d0                                        	add    r8,r10
    61cb:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    61d0:	4d 01 d0                                        	add    r8,r10
    61d3:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    61d8:	4d 01 d0                                        	add    r8,r10
    61db:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    61e0:	4d 01 d0                                        	add    r8,r10
    61e3:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    61e8:	4d 01 d0                                        	add    r8,r10
    61eb:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    61f0:	4d 01 d0                                        	add    r8,r10
    61f3:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    61f8:	4d 01 d0                                        	add    r8,r10
    61fb:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6200:	4d 01 d0                                        	add    r8,r10
    6203:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6208:	4d 01 d0                                        	add    r8,r10
    620b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6210:	4d 01 d0                                        	add    r8,r10
    6213:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6218:	4d 01 d0                                        	add    r8,r10
    621b:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6220:	4d 01 d0                                        	add    r8,r10
    6223:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6228:	4d 01 d0                                        	add    r8,r10
    622b:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6230:	4d 01 d0                                        	add    r8,r10
    6233:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6238:	4d 01 d0                                        	add    r8,r10
    623b:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6240:	4d 01 d0                                        	add    r8,r10
    6243:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6248:	4d 01 d0                                        	add    r8,r10
    624b:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6250:	4d 01 d0                                        	add    r8,r10
    6253:	41 f6 c1 01                                     	test   r9b,0x1
    6257:	75 09                                           	jne    6262 <choose_4>
    6259:	4c 8d 15 0c 00 00 00                            	lea    r10,[rip+0xc]        # 626c <target_a_4>
    6260:	eb 07                                           	jmp    6269 <dispatch_4>

0000000000006262 <choose_4>:
    6262:	4c 8d 15 09 00 00 00                            	lea    r10,[rip+0x9]        # 6272 <target_b_4>

0000000000006269 <dispatch_4>:
    6269:	41 ff e2                                        	jmp    r10

000000000000626c <target_a_4>:
    626c:	49 83 c0 01                                     	add    r8,0x1
    6270:	eb 04                                           	jmp    6276 <join_4>

0000000000006272 <target_b_4>:
    6272:	49 83 c0 02                                     	add    r8,0x2

0000000000006276 <join_4>:
    6276:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    627b:	4d 01 d0                                        	add    r8,r10
    627e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6283:	4d 01 d0                                        	add    r8,r10
    6286:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    628b:	4d 01 d0                                        	add    r8,r10
    628e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6293:	4d 01 d0                                        	add    r8,r10
    6296:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    629b:	4d 01 d0                                        	add    r8,r10
    629e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    62a3:	4d 01 d0                                        	add    r8,r10
    62a6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    62ab:	4d 01 d0                                        	add    r8,r10
    62ae:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    62b3:	4d 01 d0                                        	add    r8,r10
    62b6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    62bb:	4d 01 d0                                        	add    r8,r10
    62be:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    62c3:	4d 01 d0                                        	add    r8,r10
    62c6:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    62cb:	4d 01 d0                                        	add    r8,r10
    62ce:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    62d3:	4d 01 d0                                        	add    r8,r10
    62d6:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    62db:	4d 01 d0                                        	add    r8,r10
    62de:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    62e3:	4d 01 d0                                        	add    r8,r10
    62e6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    62eb:	4d 01 d0                                        	add    r8,r10
    62ee:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    62f3:	4d 01 d0                                        	add    r8,r10
    62f6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    62fb:	4d 01 d0                                        	add    r8,r10
    62fe:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6303:	4d 01 d0                                        	add    r8,r10
    6306:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    630b:	4d 01 d0                                        	add    r8,r10
    630e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6313:	4d 01 d0                                        	add    r8,r10
    6316:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    631b:	4d 01 d0                                        	add    r8,r10
    631e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6323:	4d 01 d0                                        	add    r8,r10
    6326:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    632b:	4d 01 d0                                        	add    r8,r10
    632e:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6333:	4d 01 d0                                        	add    r8,r10
    6336:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    633b:	4d 01 d0                                        	add    r8,r10
    633e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6343:	4d 01 d0                                        	add    r8,r10
    6346:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    634b:	4d 01 d0                                        	add    r8,r10
    634e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6353:	4d 01 d0                                        	add    r8,r10
    6356:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    635b:	4d 01 d0                                        	add    r8,r10
    635e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6363:	4d 01 d0                                        	add    r8,r10
    6366:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    636b:	4d 01 d0                                        	add    r8,r10
    636e:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6373:	4d 01 d0                                        	add    r8,r10
    6376:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    637b:	4d 01 d0                                        	add    r8,r10
    637e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6383:	4d 01 d0                                        	add    r8,r10
    6386:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    638b:	4d 01 d0                                        	add    r8,r10
    638e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6393:	4d 01 d0                                        	add    r8,r10
    6396:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    639b:	4d 01 d0                                        	add    r8,r10
    639e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    63a3:	4d 01 d0                                        	add    r8,r10
    63a6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    63ab:	4d 01 d0                                        	add    r8,r10
    63ae:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    63b3:	4d 01 d0                                        	add    r8,r10
    63b6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    63bb:	4d 01 d0                                        	add    r8,r10
    63be:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    63c3:	4d 01 d0                                        	add    r8,r10
    63c6:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    63cb:	4d 01 d0                                        	add    r8,r10
    63ce:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    63d3:	4d 01 d0                                        	add    r8,r10
    63d6:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    63db:	4d 01 d0                                        	add    r8,r10
    63de:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    63e3:	4d 01 d0                                        	add    r8,r10
    63e6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    63eb:	4d 01 d0                                        	add    r8,r10
    63ee:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    63f3:	4d 01 d0                                        	add    r8,r10
    63f6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    63fb:	4d 01 d0                                        	add    r8,r10
    63fe:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6403:	4d 01 d0                                        	add    r8,r10
    6406:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    640b:	4d 01 d0                                        	add    r8,r10
    640e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6413:	4d 01 d0                                        	add    r8,r10
    6416:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    641b:	4d 01 d0                                        	add    r8,r10
    641e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6423:	4d 01 d0                                        	add    r8,r10
    6426:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    642b:	4d 01 d0                                        	add    r8,r10
    642e:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6433:	4d 01 d0                                        	add    r8,r10
    6436:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    643b:	4d 01 d0                                        	add    r8,r10
    643e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6443:	4d 01 d0                                        	add    r8,r10
    6446:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    644b:	4d 01 d0                                        	add    r8,r10
    644e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6453:	4d 01 d0                                        	add    r8,r10
    6456:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    645b:	4d 01 d0                                        	add    r8,r10
    645e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6463:	4d 01 d0                                        	add    r8,r10
    6466:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    646b:	4d 01 d0                                        	add    r8,r10
    646e:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6473:	4d 01 d0                                        	add    r8,r10
    6476:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    647b:	4d 01 d0                                        	add    r8,r10
    647e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6483:	4d 01 d0                                        	add    r8,r10
    6486:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    648b:	4d 01 d0                                        	add    r8,r10
    648e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6493:	4d 01 d0                                        	add    r8,r10
    6496:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    649b:	4d 01 d0                                        	add    r8,r10
    649e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    64a3:	4d 01 d0                                        	add    r8,r10
    64a6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    64ab:	4d 01 d0                                        	add    r8,r10
    64ae:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    64b3:	4d 01 d0                                        	add    r8,r10
    64b6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    64bb:	4d 01 d0                                        	add    r8,r10
    64be:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    64c3:	4d 01 d0                                        	add    r8,r10
    64c6:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    64cb:	4d 01 d0                                        	add    r8,r10
    64ce:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    64d3:	4d 01 d0                                        	add    r8,r10
    64d6:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    64db:	4d 01 d0                                        	add    r8,r10
    64de:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    64e3:	4d 01 d0                                        	add    r8,r10
    64e6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    64eb:	4d 01 d0                                        	add    r8,r10
    64ee:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    64f3:	4d 01 d0                                        	add    r8,r10
    64f6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    64fb:	4d 01 d0                                        	add    r8,r10
    64fe:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6503:	4d 01 d0                                        	add    r8,r10
    6506:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    650b:	4d 01 d0                                        	add    r8,r10
    650e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6513:	4d 01 d0                                        	add    r8,r10
    6516:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    651b:	4d 01 d0                                        	add    r8,r10
    651e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6523:	4d 01 d0                                        	add    r8,r10
    6526:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    652b:	4d 01 d0                                        	add    r8,r10
    652e:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6533:	4d 01 d0                                        	add    r8,r10
    6536:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    653b:	4d 01 d0                                        	add    r8,r10
    653e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6543:	4d 01 d0                                        	add    r8,r10
    6546:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    654b:	4d 01 d0                                        	add    r8,r10
    654e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6553:	4d 01 d0                                        	add    r8,r10
    6556:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    655b:	4d 01 d0                                        	add    r8,r10
    655e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6563:	4d 01 d0                                        	add    r8,r10
    6566:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    656b:	4d 01 d0                                        	add    r8,r10
    656e:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6573:	4d 01 d0                                        	add    r8,r10
    6576:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    657b:	4d 01 d0                                        	add    r8,r10
    657e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6583:	4d 01 d0                                        	add    r8,r10
    6586:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    658b:	4d 01 d0                                        	add    r8,r10
    658e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6593:	4d 01 d0                                        	add    r8,r10
    6596:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    659b:	4d 01 d0                                        	add    r8,r10
    659e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    65a3:	4d 01 d0                                        	add    r8,r10
    65a6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    65ab:	4d 01 d0                                        	add    r8,r10
    65ae:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    65b3:	4d 01 d0                                        	add    r8,r10
    65b6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    65bb:	4d 01 d0                                        	add    r8,r10
    65be:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    65c3:	4d 01 d0                                        	add    r8,r10
    65c6:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    65cb:	4d 01 d0                                        	add    r8,r10
    65ce:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    65d3:	4d 01 d0                                        	add    r8,r10
    65d6:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    65db:	4d 01 d0                                        	add    r8,r10
    65de:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    65e3:	4d 01 d0                                        	add    r8,r10
    65e6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    65eb:	4d 01 d0                                        	add    r8,r10
    65ee:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    65f3:	4d 01 d0                                        	add    r8,r10
    65f6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    65fb:	4d 01 d0                                        	add    r8,r10
    65fe:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6603:	4d 01 d0                                        	add    r8,r10
    6606:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    660b:	4d 01 d0                                        	add    r8,r10
    660e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6613:	4d 01 d0                                        	add    r8,r10
    6616:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    661b:	4d 01 d0                                        	add    r8,r10
    661e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6623:	4d 01 d0                                        	add    r8,r10
    6626:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    662b:	4d 01 d0                                        	add    r8,r10
    662e:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6633:	4d 01 d0                                        	add    r8,r10
    6636:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    663b:	4d 01 d0                                        	add    r8,r10
    663e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6643:	4d 01 d0                                        	add    r8,r10
    6646:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    664b:	4d 01 d0                                        	add    r8,r10
    664e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6653:	4d 01 d0                                        	add    r8,r10
    6656:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    665b:	4d 01 d0                                        	add    r8,r10
    665e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6663:	4d 01 d0                                        	add    r8,r10
    6666:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    666b:	4d 01 d0                                        	add    r8,r10
    666e:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6673:	4d 01 d0                                        	add    r8,r10
    6676:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    667b:	4d 01 d0                                        	add    r8,r10
    667e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6683:	4d 01 d0                                        	add    r8,r10
    6686:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    668b:	4d 01 d0                                        	add    r8,r10
    668e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6693:	4d 01 d0                                        	add    r8,r10
    6696:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    669b:	4d 01 d0                                        	add    r8,r10
    669e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    66a3:	4d 01 d0                                        	add    r8,r10
    66a6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    66ab:	4d 01 d0                                        	add    r8,r10
    66ae:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    66b3:	4d 01 d0                                        	add    r8,r10
    66b6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    66bb:	4d 01 d0                                        	add    r8,r10
    66be:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    66c3:	4d 01 d0                                        	add    r8,r10
    66c6:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    66cb:	4d 01 d0                                        	add    r8,r10
    66ce:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    66d3:	4d 01 d0                                        	add    r8,r10
    66d6:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    66db:	4d 01 d0                                        	add    r8,r10
    66de:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    66e3:	4d 01 d0                                        	add    r8,r10
    66e6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    66eb:	4d 01 d0                                        	add    r8,r10
    66ee:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    66f3:	4d 01 d0                                        	add    r8,r10
    66f6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    66fb:	4d 01 d0                                        	add    r8,r10
    66fe:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6703:	4d 01 d0                                        	add    r8,r10
    6706:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    670b:	4d 01 d0                                        	add    r8,r10
    670e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6713:	4d 01 d0                                        	add    r8,r10
    6716:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    671b:	4d 01 d0                                        	add    r8,r10
    671e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6723:	4d 01 d0                                        	add    r8,r10
    6726:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    672b:	4d 01 d0                                        	add    r8,r10
    672e:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6733:	4d 01 d0                                        	add    r8,r10
    6736:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    673b:	4d 01 d0                                        	add    r8,r10
    673e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6743:	4d 01 d0                                        	add    r8,r10
    6746:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    674b:	4d 01 d0                                        	add    r8,r10
    674e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6753:	4d 01 d0                                        	add    r8,r10
    6756:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    675b:	4d 01 d0                                        	add    r8,r10
    675e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6763:	4d 01 d0                                        	add    r8,r10
    6766:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    676b:	4d 01 d0                                        	add    r8,r10
    676e:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6773:	4d 01 d0                                        	add    r8,r10
    6776:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    677b:	4d 01 d0                                        	add    r8,r10
    677e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6783:	4d 01 d0                                        	add    r8,r10
    6786:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    678b:	4d 01 d0                                        	add    r8,r10
    678e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6793:	4d 01 d0                                        	add    r8,r10
    6796:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    679b:	4d 01 d0                                        	add    r8,r10
    679e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    67a3:	4d 01 d0                                        	add    r8,r10
    67a6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    67ab:	4d 01 d0                                        	add    r8,r10
    67ae:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    67b3:	4d 01 d0                                        	add    r8,r10
    67b6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    67bb:	4d 01 d0                                        	add    r8,r10
    67be:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    67c3:	4d 01 d0                                        	add    r8,r10
    67c6:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    67cb:	4d 01 d0                                        	add    r8,r10
    67ce:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    67d3:	4d 01 d0                                        	add    r8,r10
    67d6:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    67db:	4d 01 d0                                        	add    r8,r10
    67de:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    67e3:	4d 01 d0                                        	add    r8,r10
    67e6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    67eb:	4d 01 d0                                        	add    r8,r10
    67ee:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    67f3:	4d 01 d0                                        	add    r8,r10
    67f6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    67fb:	4d 01 d0                                        	add    r8,r10
    67fe:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6803:	4d 01 d0                                        	add    r8,r10
    6806:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    680b:	4d 01 d0                                        	add    r8,r10
    680e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6813:	4d 01 d0                                        	add    r8,r10
    6816:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    681b:	4d 01 d0                                        	add    r8,r10
    681e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6823:	4d 01 d0                                        	add    r8,r10
    6826:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    682b:	4d 01 d0                                        	add    r8,r10
    682e:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6833:	4d 01 d0                                        	add    r8,r10
    6836:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    683b:	4d 01 d0                                        	add    r8,r10
    683e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6843:	4d 01 d0                                        	add    r8,r10
    6846:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    684b:	4d 01 d0                                        	add    r8,r10
    684e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6853:	4d 01 d0                                        	add    r8,r10
    6856:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    685b:	4d 01 d0                                        	add    r8,r10
    685e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6863:	4d 01 d0                                        	add    r8,r10
    6866:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    686b:	4d 01 d0                                        	add    r8,r10
    686e:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6873:	4d 01 d0                                        	add    r8,r10
    6876:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    687b:	4d 01 d0                                        	add    r8,r10
    687e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6883:	4d 01 d0                                        	add    r8,r10
    6886:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    688b:	4d 01 d0                                        	add    r8,r10
    688e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6893:	4d 01 d0                                        	add    r8,r10
    6896:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    689b:	4d 01 d0                                        	add    r8,r10
    689e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    68a3:	4d 01 d0                                        	add    r8,r10
    68a6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    68ab:	4d 01 d0                                        	add    r8,r10
    68ae:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    68b3:	4d 01 d0                                        	add    r8,r10
    68b6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    68bb:	4d 01 d0                                        	add    r8,r10
    68be:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    68c3:	4d 01 d0                                        	add    r8,r10
    68c6:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    68cb:	4d 01 d0                                        	add    r8,r10
    68ce:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    68d3:	4d 01 d0                                        	add    r8,r10
    68d6:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    68db:	4d 01 d0                                        	add    r8,r10
    68de:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    68e3:	4d 01 d0                                        	add    r8,r10
    68e6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    68eb:	4d 01 d0                                        	add    r8,r10
    68ee:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    68f3:	4d 01 d0                                        	add    r8,r10
    68f6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    68fb:	4d 01 d0                                        	add    r8,r10
    68fe:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6903:	4d 01 d0                                        	add    r8,r10
    6906:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    690b:	4d 01 d0                                        	add    r8,r10
    690e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6913:	4d 01 d0                                        	add    r8,r10
    6916:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    691b:	4d 01 d0                                        	add    r8,r10
    691e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6923:	4d 01 d0                                        	add    r8,r10
    6926:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    692b:	4d 01 d0                                        	add    r8,r10
    692e:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6933:	4d 01 d0                                        	add    r8,r10
    6936:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    693b:	4d 01 d0                                        	add    r8,r10
    693e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6943:	4d 01 d0                                        	add    r8,r10
    6946:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    694b:	4d 01 d0                                        	add    r8,r10
    694e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6953:	4d 01 d0                                        	add    r8,r10
    6956:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    695b:	4d 01 d0                                        	add    r8,r10
    695e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6963:	4d 01 d0                                        	add    r8,r10
    6966:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    696b:	4d 01 d0                                        	add    r8,r10
    696e:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6973:	4d 01 d0                                        	add    r8,r10
    6976:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    697b:	4d 01 d0                                        	add    r8,r10
    697e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6983:	4d 01 d0                                        	add    r8,r10
    6986:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    698b:	4d 01 d0                                        	add    r8,r10
    698e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6993:	4d 01 d0                                        	add    r8,r10
    6996:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    699b:	4d 01 d0                                        	add    r8,r10
    699e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    69a3:	4d 01 d0                                        	add    r8,r10
    69a6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    69ab:	4d 01 d0                                        	add    r8,r10
    69ae:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    69b3:	4d 01 d0                                        	add    r8,r10
    69b6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    69bb:	4d 01 d0                                        	add    r8,r10
    69be:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    69c3:	4d 01 d0                                        	add    r8,r10
    69c6:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    69cb:	4d 01 d0                                        	add    r8,r10
    69ce:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    69d3:	4d 01 d0                                        	add    r8,r10
    69d6:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    69db:	4d 01 d0                                        	add    r8,r10
    69de:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    69e3:	4d 01 d0                                        	add    r8,r10
    69e6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    69eb:	4d 01 d0                                        	add    r8,r10
    69ee:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    69f3:	4d 01 d0                                        	add    r8,r10
    69f6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    69fb:	4d 01 d0                                        	add    r8,r10
    69fe:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6a03:	4d 01 d0                                        	add    r8,r10
    6a06:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6a0b:	4d 01 d0                                        	add    r8,r10
    6a0e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6a13:	4d 01 d0                                        	add    r8,r10
    6a16:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6a1b:	4d 01 d0                                        	add    r8,r10
    6a1e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6a23:	4d 01 d0                                        	add    r8,r10
    6a26:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6a2b:	4d 01 d0                                        	add    r8,r10
    6a2e:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6a33:	4d 01 d0                                        	add    r8,r10
    6a36:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6a3b:	4d 01 d0                                        	add    r8,r10
    6a3e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6a43:	4d 01 d0                                        	add    r8,r10
    6a46:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6a4b:	4d 01 d0                                        	add    r8,r10
    6a4e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6a53:	4d 01 d0                                        	add    r8,r10
    6a56:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6a5b:	4d 01 d0                                        	add    r8,r10
    6a5e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6a63:	4d 01 d0                                        	add    r8,r10
    6a66:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6a6b:	4d 01 d0                                        	add    r8,r10
    6a6e:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6a73:	4d 01 d0                                        	add    r8,r10
    6a76:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6a7b:	4d 01 d0                                        	add    r8,r10
    6a7e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6a83:	4d 01 d0                                        	add    r8,r10
    6a86:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6a8b:	4d 01 d0                                        	add    r8,r10
    6a8e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6a93:	4d 01 d0                                        	add    r8,r10
    6a96:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6a9b:	4d 01 d0                                        	add    r8,r10
    6a9e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6aa3:	4d 01 d0                                        	add    r8,r10
    6aa6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6aab:	4d 01 d0                                        	add    r8,r10
    6aae:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6ab3:	4d 01 d0                                        	add    r8,r10
    6ab6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6abb:	4d 01 d0                                        	add    r8,r10
    6abe:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6ac3:	4d 01 d0                                        	add    r8,r10
    6ac6:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6acb:	4d 01 d0                                        	add    r8,r10
    6ace:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6ad3:	4d 01 d0                                        	add    r8,r10
    6ad6:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6adb:	4d 01 d0                                        	add    r8,r10
    6ade:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6ae3:	4d 01 d0                                        	add    r8,r10
    6ae6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6aeb:	4d 01 d0                                        	add    r8,r10
    6aee:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6af3:	4d 01 d0                                        	add    r8,r10
    6af6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6afb:	4d 01 d0                                        	add    r8,r10
    6afe:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6b03:	4d 01 d0                                        	add    r8,r10
    6b06:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6b0b:	4d 01 d0                                        	add    r8,r10
    6b0e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6b13:	4d 01 d0                                        	add    r8,r10
    6b16:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6b1b:	4d 01 d0                                        	add    r8,r10
    6b1e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6b23:	4d 01 d0                                        	add    r8,r10
    6b26:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6b2b:	4d 01 d0                                        	add    r8,r10
    6b2e:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6b33:	4d 01 d0                                        	add    r8,r10
    6b36:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6b3b:	4d 01 d0                                        	add    r8,r10
    6b3e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6b43:	4d 01 d0                                        	add    r8,r10
    6b46:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6b4b:	4d 01 d0                                        	add    r8,r10
    6b4e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6b53:	4d 01 d0                                        	add    r8,r10
    6b56:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6b5b:	4d 01 d0                                        	add    r8,r10
    6b5e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6b63:	4d 01 d0                                        	add    r8,r10
    6b66:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6b6b:	4d 01 d0                                        	add    r8,r10
    6b6e:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6b73:	4d 01 d0                                        	add    r8,r10
    6b76:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6b7b:	4d 01 d0                                        	add    r8,r10
    6b7e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6b83:	4d 01 d0                                        	add    r8,r10
    6b86:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6b8b:	4d 01 d0                                        	add    r8,r10
    6b8e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6b93:	4d 01 d0                                        	add    r8,r10
    6b96:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6b9b:	4d 01 d0                                        	add    r8,r10
    6b9e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6ba3:	4d 01 d0                                        	add    r8,r10
    6ba6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6bab:	4d 01 d0                                        	add    r8,r10
    6bae:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6bb3:	4d 01 d0                                        	add    r8,r10
    6bb6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6bbb:	4d 01 d0                                        	add    r8,r10
    6bbe:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6bc3:	4d 01 d0                                        	add    r8,r10
    6bc6:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6bcb:	4d 01 d0                                        	add    r8,r10
    6bce:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6bd3:	4d 01 d0                                        	add    r8,r10
    6bd6:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6bdb:	4d 01 d0                                        	add    r8,r10
    6bde:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6be3:	4d 01 d0                                        	add    r8,r10
    6be6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6beb:	4d 01 d0                                        	add    r8,r10
    6bee:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6bf3:	4d 01 d0                                        	add    r8,r10
    6bf6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6bfb:	4d 01 d0                                        	add    r8,r10
    6bfe:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6c03:	4d 01 d0                                        	add    r8,r10
    6c06:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6c0b:	4d 01 d0                                        	add    r8,r10
    6c0e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6c13:	4d 01 d0                                        	add    r8,r10
    6c16:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6c1b:	4d 01 d0                                        	add    r8,r10
    6c1e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6c23:	4d 01 d0                                        	add    r8,r10
    6c26:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6c2b:	4d 01 d0                                        	add    r8,r10
    6c2e:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6c33:	4d 01 d0                                        	add    r8,r10
    6c36:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6c3b:	4d 01 d0                                        	add    r8,r10
    6c3e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6c43:	4d 01 d0                                        	add    r8,r10
    6c46:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6c4b:	4d 01 d0                                        	add    r8,r10
    6c4e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6c53:	4d 01 d0                                        	add    r8,r10
    6c56:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6c5b:	4d 01 d0                                        	add    r8,r10
    6c5e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6c63:	4d 01 d0                                        	add    r8,r10
    6c66:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6c6b:	4d 01 d0                                        	add    r8,r10
    6c6e:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6c73:	4d 01 d0                                        	add    r8,r10
    6c76:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6c7b:	4d 01 d0                                        	add    r8,r10
    6c7e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6c83:	4d 01 d0                                        	add    r8,r10
    6c86:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6c8b:	4d 01 d0                                        	add    r8,r10
    6c8e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6c93:	4d 01 d0                                        	add    r8,r10
    6c96:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6c9b:	4d 01 d0                                        	add    r8,r10
    6c9e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6ca3:	4d 01 d0                                        	add    r8,r10
    6ca6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6cab:	4d 01 d0                                        	add    r8,r10
    6cae:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6cb3:	4d 01 d0                                        	add    r8,r10
    6cb6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6cbb:	4d 01 d0                                        	add    r8,r10
    6cbe:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6cc3:	4d 01 d0                                        	add    r8,r10
    6cc6:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6ccb:	4d 01 d0                                        	add    r8,r10
    6cce:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6cd3:	4d 01 d0                                        	add    r8,r10
    6cd6:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6cdb:	4d 01 d0                                        	add    r8,r10
    6cde:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6ce3:	4d 01 d0                                        	add    r8,r10
    6ce6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6ceb:	4d 01 d0                                        	add    r8,r10
    6cee:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6cf3:	4d 01 d0                                        	add    r8,r10
    6cf6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6cfb:	4d 01 d0                                        	add    r8,r10
    6cfe:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6d03:	4d 01 d0                                        	add    r8,r10
    6d06:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6d0b:	4d 01 d0                                        	add    r8,r10
    6d0e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6d13:	4d 01 d0                                        	add    r8,r10
    6d16:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6d1b:	4d 01 d0                                        	add    r8,r10
    6d1e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6d23:	4d 01 d0                                        	add    r8,r10
    6d26:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6d2b:	4d 01 d0                                        	add    r8,r10
    6d2e:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6d33:	4d 01 d0                                        	add    r8,r10
    6d36:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6d3b:	4d 01 d0                                        	add    r8,r10
    6d3e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6d43:	4d 01 d0                                        	add    r8,r10
    6d46:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6d4b:	4d 01 d0                                        	add    r8,r10
    6d4e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6d53:	4d 01 d0                                        	add    r8,r10
    6d56:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6d5b:	4d 01 d0                                        	add    r8,r10
    6d5e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6d63:	4d 01 d0                                        	add    r8,r10
    6d66:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6d6b:	4d 01 d0                                        	add    r8,r10
    6d6e:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6d73:	4d 01 d0                                        	add    r8,r10
    6d76:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6d7b:	4d 01 d0                                        	add    r8,r10
    6d7e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6d83:	4d 01 d0                                        	add    r8,r10
    6d86:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6d8b:	4d 01 d0                                        	add    r8,r10
    6d8e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6d93:	4d 01 d0                                        	add    r8,r10
    6d96:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6d9b:	4d 01 d0                                        	add    r8,r10
    6d9e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6da3:	4d 01 d0                                        	add    r8,r10
    6da6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6dab:	4d 01 d0                                        	add    r8,r10
    6dae:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6db3:	4d 01 d0                                        	add    r8,r10
    6db6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6dbb:	4d 01 d0                                        	add    r8,r10
    6dbe:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6dc3:	4d 01 d0                                        	add    r8,r10
    6dc6:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6dcb:	4d 01 d0                                        	add    r8,r10
    6dce:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6dd3:	4d 01 d0                                        	add    r8,r10
    6dd6:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6ddb:	4d 01 d0                                        	add    r8,r10
    6dde:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6de3:	4d 01 d0                                        	add    r8,r10
    6de6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6deb:	4d 01 d0                                        	add    r8,r10
    6dee:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6df3:	4d 01 d0                                        	add    r8,r10
    6df6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6dfb:	4d 01 d0                                        	add    r8,r10
    6dfe:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6e03:	4d 01 d0                                        	add    r8,r10
    6e06:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6e0b:	4d 01 d0                                        	add    r8,r10
    6e0e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6e13:	4d 01 d0                                        	add    r8,r10
    6e16:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6e1b:	4d 01 d0                                        	add    r8,r10
    6e1e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6e23:	4d 01 d0                                        	add    r8,r10
    6e26:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6e2b:	4d 01 d0                                        	add    r8,r10
    6e2e:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6e33:	4d 01 d0                                        	add    r8,r10
    6e36:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6e3b:	4d 01 d0                                        	add    r8,r10
    6e3e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6e43:	4d 01 d0                                        	add    r8,r10
    6e46:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6e4b:	4d 01 d0                                        	add    r8,r10
    6e4e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6e53:	4d 01 d0                                        	add    r8,r10
    6e56:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6e5b:	4d 01 d0                                        	add    r8,r10
    6e5e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6e63:	4d 01 d0                                        	add    r8,r10
    6e66:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6e6b:	4d 01 d0                                        	add    r8,r10
    6e6e:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6e73:	4d 01 d0                                        	add    r8,r10
    6e76:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6e7b:	4d 01 d0                                        	add    r8,r10
    6e7e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6e83:	4d 01 d0                                        	add    r8,r10
    6e86:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6e8b:	4d 01 d0                                        	add    r8,r10
    6e8e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6e93:	4d 01 d0                                        	add    r8,r10
    6e96:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6e9b:	4d 01 d0                                        	add    r8,r10
    6e9e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6ea3:	4d 01 d0                                        	add    r8,r10
    6ea6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6eab:	4d 01 d0                                        	add    r8,r10
    6eae:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6eb3:	4d 01 d0                                        	add    r8,r10
    6eb6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6ebb:	4d 01 d0                                        	add    r8,r10
    6ebe:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6ec3:	4d 01 d0                                        	add    r8,r10
    6ec6:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6ecb:	4d 01 d0                                        	add    r8,r10
    6ece:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6ed3:	4d 01 d0                                        	add    r8,r10
    6ed6:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6edb:	4d 01 d0                                        	add    r8,r10
    6ede:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6ee3:	4d 01 d0                                        	add    r8,r10
    6ee6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6eeb:	4d 01 d0                                        	add    r8,r10
    6eee:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6ef3:	4d 01 d0                                        	add    r8,r10
    6ef6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6efb:	4d 01 d0                                        	add    r8,r10
    6efe:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6f03:	4d 01 d0                                        	add    r8,r10
    6f06:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6f0b:	4d 01 d0                                        	add    r8,r10
    6f0e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6f13:	4d 01 d0                                        	add    r8,r10
    6f16:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6f1b:	4d 01 d0                                        	add    r8,r10
    6f1e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6f23:	4d 01 d0                                        	add    r8,r10
    6f26:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6f2b:	4d 01 d0                                        	add    r8,r10
    6f2e:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6f33:	4d 01 d0                                        	add    r8,r10
    6f36:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6f3b:	4d 01 d0                                        	add    r8,r10
    6f3e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6f43:	4d 01 d0                                        	add    r8,r10
    6f46:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6f4b:	4d 01 d0                                        	add    r8,r10
    6f4e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6f53:	4d 01 d0                                        	add    r8,r10
    6f56:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6f5b:	4d 01 d0                                        	add    r8,r10
    6f5e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6f63:	4d 01 d0                                        	add    r8,r10
    6f66:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6f6b:	4d 01 d0                                        	add    r8,r10
    6f6e:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6f73:	4d 01 d0                                        	add    r8,r10
    6f76:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6f7b:	4d 01 d0                                        	add    r8,r10
    6f7e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6f83:	4d 01 d0                                        	add    r8,r10
    6f86:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6f8b:	4d 01 d0                                        	add    r8,r10
    6f8e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6f93:	4d 01 d0                                        	add    r8,r10
    6f96:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6f9b:	4d 01 d0                                        	add    r8,r10
    6f9e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6fa3:	4d 01 d0                                        	add    r8,r10
    6fa6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6fab:	4d 01 d0                                        	add    r8,r10
    6fae:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6fb3:	4d 01 d0                                        	add    r8,r10
    6fb6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6fbb:	4d 01 d0                                        	add    r8,r10
    6fbe:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    6fc3:	4d 01 d0                                        	add    r8,r10
    6fc6:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    6fcb:	4d 01 d0                                        	add    r8,r10
    6fce:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    6fd3:	4d 01 d0                                        	add    r8,r10
    6fd6:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    6fdb:	4d 01 d0                                        	add    r8,r10
    6fde:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    6fe3:	4d 01 d0                                        	add    r8,r10
    6fe6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    6feb:	4d 01 d0                                        	add    r8,r10
    6fee:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    6ff3:	4d 01 d0                                        	add    r8,r10
    6ff6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    6ffb:	4d 01 d0                                        	add    r8,r10
    6ffe:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7003:	4d 01 d0                                        	add    r8,r10
    7006:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    700b:	4d 01 d0                                        	add    r8,r10
    700e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7013:	4d 01 d0                                        	add    r8,r10
    7016:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    701b:	4d 01 d0                                        	add    r8,r10
    701e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7023:	4d 01 d0                                        	add    r8,r10
    7026:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    702b:	4d 01 d0                                        	add    r8,r10
    702e:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7033:	4d 01 d0                                        	add    r8,r10
    7036:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    703b:	4d 01 d0                                        	add    r8,r10
    703e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7043:	4d 01 d0                                        	add    r8,r10
    7046:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    704b:	4d 01 d0                                        	add    r8,r10
    704e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7053:	4d 01 d0                                        	add    r8,r10
    7056:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    705b:	4d 01 d0                                        	add    r8,r10
    705e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7063:	4d 01 d0                                        	add    r8,r10
    7066:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    706b:	4d 01 d0                                        	add    r8,r10
    706e:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7073:	4d 01 d0                                        	add    r8,r10
    7076:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    707b:	4d 01 d0                                        	add    r8,r10
    707e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7083:	4d 01 d0                                        	add    r8,r10
    7086:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    708b:	4d 01 d0                                        	add    r8,r10
    708e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7093:	4d 01 d0                                        	add    r8,r10
    7096:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    709b:	4d 01 d0                                        	add    r8,r10
    709e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    70a3:	4d 01 d0                                        	add    r8,r10
    70a6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    70ab:	4d 01 d0                                        	add    r8,r10
    70ae:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    70b3:	4d 01 d0                                        	add    r8,r10
    70b6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    70bb:	4d 01 d0                                        	add    r8,r10
    70be:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    70c3:	4d 01 d0                                        	add    r8,r10
    70c6:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    70cb:	4d 01 d0                                        	add    r8,r10
    70ce:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    70d3:	4d 01 d0                                        	add    r8,r10
    70d6:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    70db:	4d 01 d0                                        	add    r8,r10
    70de:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    70e3:	4d 01 d0                                        	add    r8,r10
    70e6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    70eb:	4d 01 d0                                        	add    r8,r10
    70ee:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    70f3:	4d 01 d0                                        	add    r8,r10
    70f6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    70fb:	4d 01 d0                                        	add    r8,r10
    70fe:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7103:	4d 01 d0                                        	add    r8,r10
    7106:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    710b:	4d 01 d0                                        	add    r8,r10
    710e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7113:	4d 01 d0                                        	add    r8,r10
    7116:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    711b:	4d 01 d0                                        	add    r8,r10
    711e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7123:	4d 01 d0                                        	add    r8,r10
    7126:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    712b:	4d 01 d0                                        	add    r8,r10
    712e:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7133:	4d 01 d0                                        	add    r8,r10
    7136:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    713b:	4d 01 d0                                        	add    r8,r10
    713e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7143:	4d 01 d0                                        	add    r8,r10
    7146:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    714b:	4d 01 d0                                        	add    r8,r10
    714e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7153:	4d 01 d0                                        	add    r8,r10
    7156:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    715b:	4d 01 d0                                        	add    r8,r10
    715e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7163:	4d 01 d0                                        	add    r8,r10
    7166:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    716b:	4d 01 d0                                        	add    r8,r10
    716e:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7173:	4d 01 d0                                        	add    r8,r10
    7176:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    717b:	4d 01 d0                                        	add    r8,r10
    717e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7183:	4d 01 d0                                        	add    r8,r10
    7186:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    718b:	4d 01 d0                                        	add    r8,r10
    718e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7193:	4d 01 d0                                        	add    r8,r10
    7196:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    719b:	4d 01 d0                                        	add    r8,r10
    719e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    71a3:	4d 01 d0                                        	add    r8,r10
    71a6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    71ab:	4d 01 d0                                        	add    r8,r10
    71ae:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    71b3:	4d 01 d0                                        	add    r8,r10
    71b6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    71bb:	4d 01 d0                                        	add    r8,r10
    71be:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    71c3:	4d 01 d0                                        	add    r8,r10
    71c6:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    71cb:	4d 01 d0                                        	add    r8,r10
    71ce:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    71d3:	4d 01 d0                                        	add    r8,r10
    71d6:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    71db:	4d 01 d0                                        	add    r8,r10
    71de:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    71e3:	4d 01 d0                                        	add    r8,r10
    71e6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    71eb:	4d 01 d0                                        	add    r8,r10
    71ee:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    71f3:	4d 01 d0                                        	add    r8,r10
    71f6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    71fb:	4d 01 d0                                        	add    r8,r10
    71fe:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7203:	4d 01 d0                                        	add    r8,r10
    7206:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    720b:	4d 01 d0                                        	add    r8,r10
    720e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7213:	4d 01 d0                                        	add    r8,r10
    7216:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    721b:	4d 01 d0                                        	add    r8,r10
    721e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7223:	4d 01 d0                                        	add    r8,r10
    7226:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    722b:	4d 01 d0                                        	add    r8,r10
    722e:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7233:	4d 01 d0                                        	add    r8,r10
    7236:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    723b:	4d 01 d0                                        	add    r8,r10
    723e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7243:	4d 01 d0                                        	add    r8,r10
    7246:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    724b:	4d 01 d0                                        	add    r8,r10
    724e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7253:	4d 01 d0                                        	add    r8,r10
    7256:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    725b:	4d 01 d0                                        	add    r8,r10
    725e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7263:	4d 01 d0                                        	add    r8,r10
    7266:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    726b:	4d 01 d0                                        	add    r8,r10
    726e:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7273:	4d 01 d0                                        	add    r8,r10
    7276:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    727b:	4d 01 d0                                        	add    r8,r10
    727e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7283:	4d 01 d0                                        	add    r8,r10
    7286:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    728b:	4d 01 d0                                        	add    r8,r10
    728e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7293:	4d 01 d0                                        	add    r8,r10
    7296:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    729b:	4d 01 d0                                        	add    r8,r10
    729e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    72a3:	4d 01 d0                                        	add    r8,r10
    72a6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    72ab:	4d 01 d0                                        	add    r8,r10
    72ae:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    72b3:	4d 01 d0                                        	add    r8,r10
    72b6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    72bb:	4d 01 d0                                        	add    r8,r10
    72be:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    72c3:	4d 01 d0                                        	add    r8,r10
    72c6:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    72cb:	4d 01 d0                                        	add    r8,r10
    72ce:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    72d3:	4d 01 d0                                        	add    r8,r10
    72d6:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    72db:	4d 01 d0                                        	add    r8,r10
    72de:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    72e3:	4d 01 d0                                        	add    r8,r10
    72e6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    72eb:	4d 01 d0                                        	add    r8,r10
    72ee:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    72f3:	4d 01 d0                                        	add    r8,r10
    72f6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    72fb:	4d 01 d0                                        	add    r8,r10
    72fe:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7303:	4d 01 d0                                        	add    r8,r10
    7306:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    730b:	4d 01 d0                                        	add    r8,r10
    730e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7313:	4d 01 d0                                        	add    r8,r10
    7316:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    731b:	4d 01 d0                                        	add    r8,r10
    731e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7323:	4d 01 d0                                        	add    r8,r10
    7326:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    732b:	4d 01 d0                                        	add    r8,r10
    732e:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7333:	4d 01 d0                                        	add    r8,r10
    7336:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    733b:	4d 01 d0                                        	add    r8,r10
    733e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7343:	4d 01 d0                                        	add    r8,r10
    7346:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    734b:	4d 01 d0                                        	add    r8,r10
    734e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7353:	4d 01 d0                                        	add    r8,r10
    7356:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    735b:	4d 01 d0                                        	add    r8,r10
    735e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7363:	4d 01 d0                                        	add    r8,r10
    7366:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    736b:	4d 01 d0                                        	add    r8,r10
    736e:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7373:	4d 01 d0                                        	add    r8,r10
    7376:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    737b:	4d 01 d0                                        	add    r8,r10
    737e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7383:	4d 01 d0                                        	add    r8,r10
    7386:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    738b:	4d 01 d0                                        	add    r8,r10
    738e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7393:	4d 01 d0                                        	add    r8,r10
    7396:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    739b:	4d 01 d0                                        	add    r8,r10
    739e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    73a3:	4d 01 d0                                        	add    r8,r10
    73a6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    73ab:	4d 01 d0                                        	add    r8,r10
    73ae:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    73b3:	4d 01 d0                                        	add    r8,r10
    73b6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    73bb:	4d 01 d0                                        	add    r8,r10
    73be:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    73c3:	4d 01 d0                                        	add    r8,r10
    73c6:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    73cb:	4d 01 d0                                        	add    r8,r10
    73ce:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    73d3:	4d 01 d0                                        	add    r8,r10
    73d6:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    73db:	4d 01 d0                                        	add    r8,r10
    73de:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    73e3:	4d 01 d0                                        	add    r8,r10
    73e6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    73eb:	4d 01 d0                                        	add    r8,r10
    73ee:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    73f3:	4d 01 d0                                        	add    r8,r10
    73f6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    73fb:	4d 01 d0                                        	add    r8,r10
    73fe:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7403:	4d 01 d0                                        	add    r8,r10
    7406:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    740b:	4d 01 d0                                        	add    r8,r10
    740e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7413:	4d 01 d0                                        	add    r8,r10
    7416:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    741b:	4d 01 d0                                        	add    r8,r10
    741e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7423:	4d 01 d0                                        	add    r8,r10
    7426:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    742b:	4d 01 d0                                        	add    r8,r10
    742e:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7433:	4d 01 d0                                        	add    r8,r10
    7436:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    743b:	4d 01 d0                                        	add    r8,r10
    743e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7443:	4d 01 d0                                        	add    r8,r10
    7446:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    744b:	4d 01 d0                                        	add    r8,r10
    744e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7453:	4d 01 d0                                        	add    r8,r10
    7456:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    745b:	4d 01 d0                                        	add    r8,r10
    745e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7463:	4d 01 d0                                        	add    r8,r10
    7466:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    746b:	4d 01 d0                                        	add    r8,r10
    746e:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7473:	4d 01 d0                                        	add    r8,r10
    7476:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    747b:	4d 01 d0                                        	add    r8,r10
    747e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7483:	4d 01 d0                                        	add    r8,r10
    7486:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    748b:	4d 01 d0                                        	add    r8,r10
    748e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7493:	4d 01 d0                                        	add    r8,r10
    7496:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    749b:	4d 01 d0                                        	add    r8,r10
    749e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    74a3:	4d 01 d0                                        	add    r8,r10
    74a6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    74ab:	4d 01 d0                                        	add    r8,r10
    74ae:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    74b3:	4d 01 d0                                        	add    r8,r10
    74b6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    74bb:	4d 01 d0                                        	add    r8,r10
    74be:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    74c3:	4d 01 d0                                        	add    r8,r10
    74c6:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    74cb:	4d 01 d0                                        	add    r8,r10
    74ce:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    74d3:	4d 01 d0                                        	add    r8,r10
    74d6:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    74db:	4d 01 d0                                        	add    r8,r10
    74de:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    74e3:	4d 01 d0                                        	add    r8,r10
    74e6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    74eb:	4d 01 d0                                        	add    r8,r10
    74ee:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    74f3:	4d 01 d0                                        	add    r8,r10
    74f6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    74fb:	4d 01 d0                                        	add    r8,r10
    74fe:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7503:	4d 01 d0                                        	add    r8,r10
    7506:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    750b:	4d 01 d0                                        	add    r8,r10
    750e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7513:	4d 01 d0                                        	add    r8,r10
    7516:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    751b:	4d 01 d0                                        	add    r8,r10
    751e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7523:	4d 01 d0                                        	add    r8,r10
    7526:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    752b:	4d 01 d0                                        	add    r8,r10
    752e:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7533:	4d 01 d0                                        	add    r8,r10
    7536:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    753b:	4d 01 d0                                        	add    r8,r10
    753e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7543:	4d 01 d0                                        	add    r8,r10
    7546:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    754b:	4d 01 d0                                        	add    r8,r10
    754e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7553:	4d 01 d0                                        	add    r8,r10
    7556:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    755b:	4d 01 d0                                        	add    r8,r10
    755e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7563:	4d 01 d0                                        	add    r8,r10
    7566:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    756b:	4d 01 d0                                        	add    r8,r10
    756e:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7573:	4d 01 d0                                        	add    r8,r10
    7576:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    757b:	4d 01 d0                                        	add    r8,r10
    757e:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7583:	4d 01 d0                                        	add    r8,r10
    7586:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    758b:	4d 01 d0                                        	add    r8,r10
    758e:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7593:	4d 01 d0                                        	add    r8,r10
    7596:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    759b:	4d 01 d0                                        	add    r8,r10
    759e:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    75a3:	4d 01 d0                                        	add    r8,r10
    75a6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    75ab:	4d 01 d0                                        	add    r8,r10
    75ae:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    75b3:	4d 01 d0                                        	add    r8,r10
    75b6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    75bb:	4d 01 d0                                        	add    r8,r10
    75be:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    75c3:	4d 01 d0                                        	add    r8,r10
    75c6:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    75cb:	4d 01 d0                                        	add    r8,r10
    75ce:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    75d3:	4d 01 d0                                        	add    r8,r10
    75d6:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    75db:	4d 01 d0                                        	add    r8,r10
    75de:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    75e3:	4d 01 d0                                        	add    r8,r10
    75e6:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    75eb:	4d 01 d0                                        	add    r8,r10
    75ee:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    75f3:	4d 01 d0                                        	add    r8,r10
    75f6:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    75fb:	4d 01 d0                                        	add    r8,r10
    75fe:	41 f6 c1 01                                     	test   r9b,0x1
    7602:	75 09                                           	jne    760d <choose_5>
    7604:	4c 8d 15 0c 00 00 00                            	lea    r10,[rip+0xc]        # 7617 <target_a_5>
    760b:	eb 07                                           	jmp    7614 <dispatch_5>

000000000000760d <choose_5>:
    760d:	4c 8d 15 09 00 00 00                            	lea    r10,[rip+0x9]        # 761d <target_b_5>

0000000000007614 <dispatch_5>:
    7614:	41 ff e2                                        	jmp    r10

0000000000007617 <target_a_5>:
    7617:	49 83 c0 01                                     	add    r8,0x1
    761b:	eb 04                                           	jmp    7621 <join_5>

000000000000761d <target_b_5>:
    761d:	49 83 c0 02                                     	add    r8,0x2

0000000000007621 <join_5>:
    7621:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7626:	4d 01 d0                                        	add    r8,r10
    7629:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    762e:	4d 01 d0                                        	add    r8,r10
    7631:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7636:	4d 01 d0                                        	add    r8,r10
    7639:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    763e:	4d 01 d0                                        	add    r8,r10
    7641:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7646:	4d 01 d0                                        	add    r8,r10
    7649:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    764e:	4d 01 d0                                        	add    r8,r10
    7651:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7656:	4d 01 d0                                        	add    r8,r10
    7659:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    765e:	4d 01 d0                                        	add    r8,r10
    7661:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7666:	4d 01 d0                                        	add    r8,r10
    7669:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    766e:	4d 01 d0                                        	add    r8,r10
    7671:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7676:	4d 01 d0                                        	add    r8,r10
    7679:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    767e:	4d 01 d0                                        	add    r8,r10
    7681:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7686:	4d 01 d0                                        	add    r8,r10
    7689:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    768e:	4d 01 d0                                        	add    r8,r10
    7691:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7696:	4d 01 d0                                        	add    r8,r10
    7699:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    769e:	4d 01 d0                                        	add    r8,r10
    76a1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    76a6:	4d 01 d0                                        	add    r8,r10
    76a9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    76ae:	4d 01 d0                                        	add    r8,r10
    76b1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    76b6:	4d 01 d0                                        	add    r8,r10
    76b9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    76be:	4d 01 d0                                        	add    r8,r10
    76c1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    76c6:	4d 01 d0                                        	add    r8,r10
    76c9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    76ce:	4d 01 d0                                        	add    r8,r10
    76d1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    76d6:	4d 01 d0                                        	add    r8,r10
    76d9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    76de:	4d 01 d0                                        	add    r8,r10
    76e1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    76e6:	4d 01 d0                                        	add    r8,r10
    76e9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    76ee:	4d 01 d0                                        	add    r8,r10
    76f1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    76f6:	4d 01 d0                                        	add    r8,r10
    76f9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    76fe:	4d 01 d0                                        	add    r8,r10
    7701:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7706:	4d 01 d0                                        	add    r8,r10
    7709:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    770e:	4d 01 d0                                        	add    r8,r10
    7711:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7716:	4d 01 d0                                        	add    r8,r10
    7719:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    771e:	4d 01 d0                                        	add    r8,r10
    7721:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7726:	4d 01 d0                                        	add    r8,r10
    7729:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    772e:	4d 01 d0                                        	add    r8,r10
    7731:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7736:	4d 01 d0                                        	add    r8,r10
    7739:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    773e:	4d 01 d0                                        	add    r8,r10
    7741:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7746:	4d 01 d0                                        	add    r8,r10
    7749:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    774e:	4d 01 d0                                        	add    r8,r10
    7751:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7756:	4d 01 d0                                        	add    r8,r10
    7759:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    775e:	4d 01 d0                                        	add    r8,r10
    7761:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7766:	4d 01 d0                                        	add    r8,r10
    7769:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    776e:	4d 01 d0                                        	add    r8,r10
    7771:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7776:	4d 01 d0                                        	add    r8,r10
    7779:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    777e:	4d 01 d0                                        	add    r8,r10
    7781:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7786:	4d 01 d0                                        	add    r8,r10
    7789:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    778e:	4d 01 d0                                        	add    r8,r10
    7791:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7796:	4d 01 d0                                        	add    r8,r10
    7799:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    779e:	4d 01 d0                                        	add    r8,r10
    77a1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    77a6:	4d 01 d0                                        	add    r8,r10
    77a9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    77ae:	4d 01 d0                                        	add    r8,r10
    77b1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    77b6:	4d 01 d0                                        	add    r8,r10
    77b9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    77be:	4d 01 d0                                        	add    r8,r10
    77c1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    77c6:	4d 01 d0                                        	add    r8,r10
    77c9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    77ce:	4d 01 d0                                        	add    r8,r10
    77d1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    77d6:	4d 01 d0                                        	add    r8,r10
    77d9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    77de:	4d 01 d0                                        	add    r8,r10
    77e1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    77e6:	4d 01 d0                                        	add    r8,r10
    77e9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    77ee:	4d 01 d0                                        	add    r8,r10
    77f1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    77f6:	4d 01 d0                                        	add    r8,r10
    77f9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    77fe:	4d 01 d0                                        	add    r8,r10
    7801:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7806:	4d 01 d0                                        	add    r8,r10
    7809:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    780e:	4d 01 d0                                        	add    r8,r10
    7811:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7816:	4d 01 d0                                        	add    r8,r10
    7819:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    781e:	4d 01 d0                                        	add    r8,r10
    7821:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7826:	4d 01 d0                                        	add    r8,r10
    7829:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    782e:	4d 01 d0                                        	add    r8,r10
    7831:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7836:	4d 01 d0                                        	add    r8,r10
    7839:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    783e:	4d 01 d0                                        	add    r8,r10
    7841:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7846:	4d 01 d0                                        	add    r8,r10
    7849:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    784e:	4d 01 d0                                        	add    r8,r10
    7851:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7856:	4d 01 d0                                        	add    r8,r10
    7859:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    785e:	4d 01 d0                                        	add    r8,r10
    7861:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7866:	4d 01 d0                                        	add    r8,r10
    7869:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    786e:	4d 01 d0                                        	add    r8,r10
    7871:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7876:	4d 01 d0                                        	add    r8,r10
    7879:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    787e:	4d 01 d0                                        	add    r8,r10
    7881:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7886:	4d 01 d0                                        	add    r8,r10
    7889:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    788e:	4d 01 d0                                        	add    r8,r10
    7891:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7896:	4d 01 d0                                        	add    r8,r10
    7899:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    789e:	4d 01 d0                                        	add    r8,r10
    78a1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    78a6:	4d 01 d0                                        	add    r8,r10
    78a9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    78ae:	4d 01 d0                                        	add    r8,r10
    78b1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    78b6:	4d 01 d0                                        	add    r8,r10
    78b9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    78be:	4d 01 d0                                        	add    r8,r10
    78c1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    78c6:	4d 01 d0                                        	add    r8,r10
    78c9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    78ce:	4d 01 d0                                        	add    r8,r10
    78d1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    78d6:	4d 01 d0                                        	add    r8,r10
    78d9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    78de:	4d 01 d0                                        	add    r8,r10
    78e1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    78e6:	4d 01 d0                                        	add    r8,r10
    78e9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    78ee:	4d 01 d0                                        	add    r8,r10
    78f1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    78f6:	4d 01 d0                                        	add    r8,r10
    78f9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    78fe:	4d 01 d0                                        	add    r8,r10
    7901:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7906:	4d 01 d0                                        	add    r8,r10
    7909:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    790e:	4d 01 d0                                        	add    r8,r10
    7911:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7916:	4d 01 d0                                        	add    r8,r10
    7919:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    791e:	4d 01 d0                                        	add    r8,r10
    7921:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7926:	4d 01 d0                                        	add    r8,r10
    7929:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    792e:	4d 01 d0                                        	add    r8,r10
    7931:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7936:	4d 01 d0                                        	add    r8,r10
    7939:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    793e:	4d 01 d0                                        	add    r8,r10
    7941:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7946:	4d 01 d0                                        	add    r8,r10
    7949:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    794e:	4d 01 d0                                        	add    r8,r10
    7951:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7956:	4d 01 d0                                        	add    r8,r10
    7959:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    795e:	4d 01 d0                                        	add    r8,r10
    7961:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7966:	4d 01 d0                                        	add    r8,r10
    7969:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    796e:	4d 01 d0                                        	add    r8,r10
    7971:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7976:	4d 01 d0                                        	add    r8,r10
    7979:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    797e:	4d 01 d0                                        	add    r8,r10
    7981:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7986:	4d 01 d0                                        	add    r8,r10
    7989:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    798e:	4d 01 d0                                        	add    r8,r10
    7991:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7996:	4d 01 d0                                        	add    r8,r10
    7999:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    799e:	4d 01 d0                                        	add    r8,r10
    79a1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    79a6:	4d 01 d0                                        	add    r8,r10
    79a9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    79ae:	4d 01 d0                                        	add    r8,r10
    79b1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    79b6:	4d 01 d0                                        	add    r8,r10
    79b9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    79be:	4d 01 d0                                        	add    r8,r10
    79c1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    79c6:	4d 01 d0                                        	add    r8,r10
    79c9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    79ce:	4d 01 d0                                        	add    r8,r10
    79d1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    79d6:	4d 01 d0                                        	add    r8,r10
    79d9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    79de:	4d 01 d0                                        	add    r8,r10
    79e1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    79e6:	4d 01 d0                                        	add    r8,r10
    79e9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    79ee:	4d 01 d0                                        	add    r8,r10
    79f1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    79f6:	4d 01 d0                                        	add    r8,r10
    79f9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    79fe:	4d 01 d0                                        	add    r8,r10
    7a01:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7a06:	4d 01 d0                                        	add    r8,r10
    7a09:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7a0e:	4d 01 d0                                        	add    r8,r10
    7a11:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7a16:	4d 01 d0                                        	add    r8,r10
    7a19:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7a1e:	4d 01 d0                                        	add    r8,r10
    7a21:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7a26:	4d 01 d0                                        	add    r8,r10
    7a29:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7a2e:	4d 01 d0                                        	add    r8,r10
    7a31:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7a36:	4d 01 d0                                        	add    r8,r10
    7a39:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7a3e:	4d 01 d0                                        	add    r8,r10
    7a41:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7a46:	4d 01 d0                                        	add    r8,r10
    7a49:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7a4e:	4d 01 d0                                        	add    r8,r10
    7a51:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7a56:	4d 01 d0                                        	add    r8,r10
    7a59:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7a5e:	4d 01 d0                                        	add    r8,r10
    7a61:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7a66:	4d 01 d0                                        	add    r8,r10
    7a69:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7a6e:	4d 01 d0                                        	add    r8,r10
    7a71:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7a76:	4d 01 d0                                        	add    r8,r10
    7a79:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7a7e:	4d 01 d0                                        	add    r8,r10
    7a81:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7a86:	4d 01 d0                                        	add    r8,r10
    7a89:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7a8e:	4d 01 d0                                        	add    r8,r10
    7a91:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7a96:	4d 01 d0                                        	add    r8,r10
    7a99:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7a9e:	4d 01 d0                                        	add    r8,r10
    7aa1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7aa6:	4d 01 d0                                        	add    r8,r10
    7aa9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7aae:	4d 01 d0                                        	add    r8,r10
    7ab1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7ab6:	4d 01 d0                                        	add    r8,r10
    7ab9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7abe:	4d 01 d0                                        	add    r8,r10
    7ac1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7ac6:	4d 01 d0                                        	add    r8,r10
    7ac9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7ace:	4d 01 d0                                        	add    r8,r10
    7ad1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7ad6:	4d 01 d0                                        	add    r8,r10
    7ad9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7ade:	4d 01 d0                                        	add    r8,r10
    7ae1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7ae6:	4d 01 d0                                        	add    r8,r10
    7ae9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7aee:	4d 01 d0                                        	add    r8,r10
    7af1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7af6:	4d 01 d0                                        	add    r8,r10
    7af9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7afe:	4d 01 d0                                        	add    r8,r10
    7b01:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7b06:	4d 01 d0                                        	add    r8,r10
    7b09:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7b0e:	4d 01 d0                                        	add    r8,r10
    7b11:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7b16:	4d 01 d0                                        	add    r8,r10
    7b19:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7b1e:	4d 01 d0                                        	add    r8,r10
    7b21:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7b26:	4d 01 d0                                        	add    r8,r10
    7b29:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7b2e:	4d 01 d0                                        	add    r8,r10
    7b31:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7b36:	4d 01 d0                                        	add    r8,r10
    7b39:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7b3e:	4d 01 d0                                        	add    r8,r10
    7b41:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7b46:	4d 01 d0                                        	add    r8,r10
    7b49:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7b4e:	4d 01 d0                                        	add    r8,r10
    7b51:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7b56:	4d 01 d0                                        	add    r8,r10
    7b59:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7b5e:	4d 01 d0                                        	add    r8,r10
    7b61:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7b66:	4d 01 d0                                        	add    r8,r10
    7b69:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7b6e:	4d 01 d0                                        	add    r8,r10
    7b71:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7b76:	4d 01 d0                                        	add    r8,r10
    7b79:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7b7e:	4d 01 d0                                        	add    r8,r10
    7b81:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7b86:	4d 01 d0                                        	add    r8,r10
    7b89:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7b8e:	4d 01 d0                                        	add    r8,r10
    7b91:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7b96:	4d 01 d0                                        	add    r8,r10
    7b99:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7b9e:	4d 01 d0                                        	add    r8,r10
    7ba1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7ba6:	4d 01 d0                                        	add    r8,r10
    7ba9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7bae:	4d 01 d0                                        	add    r8,r10
    7bb1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7bb6:	4d 01 d0                                        	add    r8,r10
    7bb9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7bbe:	4d 01 d0                                        	add    r8,r10
    7bc1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7bc6:	4d 01 d0                                        	add    r8,r10
    7bc9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7bce:	4d 01 d0                                        	add    r8,r10
    7bd1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7bd6:	4d 01 d0                                        	add    r8,r10
    7bd9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7bde:	4d 01 d0                                        	add    r8,r10
    7be1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7be6:	4d 01 d0                                        	add    r8,r10
    7be9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7bee:	4d 01 d0                                        	add    r8,r10
    7bf1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7bf6:	4d 01 d0                                        	add    r8,r10
    7bf9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7bfe:	4d 01 d0                                        	add    r8,r10
    7c01:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7c06:	4d 01 d0                                        	add    r8,r10
    7c09:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7c0e:	4d 01 d0                                        	add    r8,r10
    7c11:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7c16:	4d 01 d0                                        	add    r8,r10
    7c19:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7c1e:	4d 01 d0                                        	add    r8,r10
    7c21:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7c26:	4d 01 d0                                        	add    r8,r10
    7c29:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7c2e:	4d 01 d0                                        	add    r8,r10
    7c31:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7c36:	4d 01 d0                                        	add    r8,r10
    7c39:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7c3e:	4d 01 d0                                        	add    r8,r10
    7c41:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7c46:	4d 01 d0                                        	add    r8,r10
    7c49:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7c4e:	4d 01 d0                                        	add    r8,r10
    7c51:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7c56:	4d 01 d0                                        	add    r8,r10
    7c59:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7c5e:	4d 01 d0                                        	add    r8,r10
    7c61:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7c66:	4d 01 d0                                        	add    r8,r10
    7c69:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7c6e:	4d 01 d0                                        	add    r8,r10
    7c71:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7c76:	4d 01 d0                                        	add    r8,r10
    7c79:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7c7e:	4d 01 d0                                        	add    r8,r10
    7c81:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7c86:	4d 01 d0                                        	add    r8,r10
    7c89:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7c8e:	4d 01 d0                                        	add    r8,r10
    7c91:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7c96:	4d 01 d0                                        	add    r8,r10
    7c99:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7c9e:	4d 01 d0                                        	add    r8,r10
    7ca1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7ca6:	4d 01 d0                                        	add    r8,r10
    7ca9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7cae:	4d 01 d0                                        	add    r8,r10
    7cb1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7cb6:	4d 01 d0                                        	add    r8,r10
    7cb9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7cbe:	4d 01 d0                                        	add    r8,r10
    7cc1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7cc6:	4d 01 d0                                        	add    r8,r10
    7cc9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7cce:	4d 01 d0                                        	add    r8,r10
    7cd1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7cd6:	4d 01 d0                                        	add    r8,r10
    7cd9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7cde:	4d 01 d0                                        	add    r8,r10
    7ce1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7ce6:	4d 01 d0                                        	add    r8,r10
    7ce9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7cee:	4d 01 d0                                        	add    r8,r10
    7cf1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7cf6:	4d 01 d0                                        	add    r8,r10
    7cf9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7cfe:	4d 01 d0                                        	add    r8,r10
    7d01:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7d06:	4d 01 d0                                        	add    r8,r10
    7d09:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7d0e:	4d 01 d0                                        	add    r8,r10
    7d11:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7d16:	4d 01 d0                                        	add    r8,r10
    7d19:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7d1e:	4d 01 d0                                        	add    r8,r10
    7d21:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7d26:	4d 01 d0                                        	add    r8,r10
    7d29:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7d2e:	4d 01 d0                                        	add    r8,r10
    7d31:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7d36:	4d 01 d0                                        	add    r8,r10
    7d39:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7d3e:	4d 01 d0                                        	add    r8,r10
    7d41:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7d46:	4d 01 d0                                        	add    r8,r10
    7d49:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7d4e:	4d 01 d0                                        	add    r8,r10
    7d51:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7d56:	4d 01 d0                                        	add    r8,r10
    7d59:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7d5e:	4d 01 d0                                        	add    r8,r10
    7d61:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7d66:	4d 01 d0                                        	add    r8,r10
    7d69:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7d6e:	4d 01 d0                                        	add    r8,r10
    7d71:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7d76:	4d 01 d0                                        	add    r8,r10
    7d79:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7d7e:	4d 01 d0                                        	add    r8,r10
    7d81:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7d86:	4d 01 d0                                        	add    r8,r10
    7d89:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7d8e:	4d 01 d0                                        	add    r8,r10
    7d91:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7d96:	4d 01 d0                                        	add    r8,r10
    7d99:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7d9e:	4d 01 d0                                        	add    r8,r10
    7da1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7da6:	4d 01 d0                                        	add    r8,r10
    7da9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7dae:	4d 01 d0                                        	add    r8,r10
    7db1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7db6:	4d 01 d0                                        	add    r8,r10
    7db9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7dbe:	4d 01 d0                                        	add    r8,r10
    7dc1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7dc6:	4d 01 d0                                        	add    r8,r10
    7dc9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7dce:	4d 01 d0                                        	add    r8,r10
    7dd1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7dd6:	4d 01 d0                                        	add    r8,r10
    7dd9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7dde:	4d 01 d0                                        	add    r8,r10
    7de1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7de6:	4d 01 d0                                        	add    r8,r10
    7de9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7dee:	4d 01 d0                                        	add    r8,r10
    7df1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7df6:	4d 01 d0                                        	add    r8,r10
    7df9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7dfe:	4d 01 d0                                        	add    r8,r10
    7e01:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7e06:	4d 01 d0                                        	add    r8,r10
    7e09:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7e0e:	4d 01 d0                                        	add    r8,r10
    7e11:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7e16:	4d 01 d0                                        	add    r8,r10
    7e19:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7e1e:	4d 01 d0                                        	add    r8,r10
    7e21:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7e26:	4d 01 d0                                        	add    r8,r10
    7e29:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7e2e:	4d 01 d0                                        	add    r8,r10
    7e31:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7e36:	4d 01 d0                                        	add    r8,r10
    7e39:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7e3e:	4d 01 d0                                        	add    r8,r10
    7e41:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7e46:	4d 01 d0                                        	add    r8,r10
    7e49:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7e4e:	4d 01 d0                                        	add    r8,r10
    7e51:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7e56:	4d 01 d0                                        	add    r8,r10
    7e59:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7e5e:	4d 01 d0                                        	add    r8,r10
    7e61:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7e66:	4d 01 d0                                        	add    r8,r10
    7e69:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7e6e:	4d 01 d0                                        	add    r8,r10
    7e71:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7e76:	4d 01 d0                                        	add    r8,r10
    7e79:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7e7e:	4d 01 d0                                        	add    r8,r10
    7e81:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7e86:	4d 01 d0                                        	add    r8,r10
    7e89:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7e8e:	4d 01 d0                                        	add    r8,r10
    7e91:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7e96:	4d 01 d0                                        	add    r8,r10
    7e99:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7e9e:	4d 01 d0                                        	add    r8,r10
    7ea1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7ea6:	4d 01 d0                                        	add    r8,r10
    7ea9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7eae:	4d 01 d0                                        	add    r8,r10
    7eb1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7eb6:	4d 01 d0                                        	add    r8,r10
    7eb9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7ebe:	4d 01 d0                                        	add    r8,r10
    7ec1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7ec6:	4d 01 d0                                        	add    r8,r10
    7ec9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7ece:	4d 01 d0                                        	add    r8,r10
    7ed1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7ed6:	4d 01 d0                                        	add    r8,r10
    7ed9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7ede:	4d 01 d0                                        	add    r8,r10
    7ee1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7ee6:	4d 01 d0                                        	add    r8,r10
    7ee9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7eee:	4d 01 d0                                        	add    r8,r10
    7ef1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7ef6:	4d 01 d0                                        	add    r8,r10
    7ef9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7efe:	4d 01 d0                                        	add    r8,r10
    7f01:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7f06:	4d 01 d0                                        	add    r8,r10
    7f09:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7f0e:	4d 01 d0                                        	add    r8,r10
    7f11:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7f16:	4d 01 d0                                        	add    r8,r10
    7f19:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7f1e:	4d 01 d0                                        	add    r8,r10
    7f21:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7f26:	4d 01 d0                                        	add    r8,r10
    7f29:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7f2e:	4d 01 d0                                        	add    r8,r10
    7f31:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7f36:	4d 01 d0                                        	add    r8,r10
    7f39:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7f3e:	4d 01 d0                                        	add    r8,r10
    7f41:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7f46:	4d 01 d0                                        	add    r8,r10
    7f49:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7f4e:	4d 01 d0                                        	add    r8,r10
    7f51:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7f56:	4d 01 d0                                        	add    r8,r10
    7f59:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7f5e:	4d 01 d0                                        	add    r8,r10
    7f61:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7f66:	4d 01 d0                                        	add    r8,r10
    7f69:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7f6e:	4d 01 d0                                        	add    r8,r10
    7f71:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7f76:	4d 01 d0                                        	add    r8,r10
    7f79:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7f7e:	4d 01 d0                                        	add    r8,r10
    7f81:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7f86:	4d 01 d0                                        	add    r8,r10
    7f89:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7f8e:	4d 01 d0                                        	add    r8,r10
    7f91:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7f96:	4d 01 d0                                        	add    r8,r10
    7f99:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7f9e:	4d 01 d0                                        	add    r8,r10
    7fa1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7fa6:	4d 01 d0                                        	add    r8,r10
    7fa9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7fae:	4d 01 d0                                        	add    r8,r10
    7fb1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7fb6:	4d 01 d0                                        	add    r8,r10
    7fb9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7fbe:	4d 01 d0                                        	add    r8,r10
    7fc1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    7fc6:	4d 01 d0                                        	add    r8,r10
    7fc9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    7fce:	4d 01 d0                                        	add    r8,r10
    7fd1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    7fd6:	4d 01 d0                                        	add    r8,r10
    7fd9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    7fde:	4d 01 d0                                        	add    r8,r10
    7fe1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    7fe6:	4d 01 d0                                        	add    r8,r10
    7fe9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    7fee:	4d 01 d0                                        	add    r8,r10
    7ff1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    7ff6:	4d 01 d0                                        	add    r8,r10
    7ff9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    7ffe:	4d 01 d0                                        	add    r8,r10
    8001:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8006:	4d 01 d0                                        	add    r8,r10
    8009:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    800e:	4d 01 d0                                        	add    r8,r10
    8011:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8016:	4d 01 d0                                        	add    r8,r10
    8019:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    801e:	4d 01 d0                                        	add    r8,r10
    8021:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8026:	4d 01 d0                                        	add    r8,r10
    8029:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    802e:	4d 01 d0                                        	add    r8,r10
    8031:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8036:	4d 01 d0                                        	add    r8,r10
    8039:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    803e:	4d 01 d0                                        	add    r8,r10
    8041:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8046:	4d 01 d0                                        	add    r8,r10
    8049:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    804e:	4d 01 d0                                        	add    r8,r10
    8051:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8056:	4d 01 d0                                        	add    r8,r10
    8059:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    805e:	4d 01 d0                                        	add    r8,r10
    8061:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8066:	4d 01 d0                                        	add    r8,r10
    8069:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    806e:	4d 01 d0                                        	add    r8,r10
    8071:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8076:	4d 01 d0                                        	add    r8,r10
    8079:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    807e:	4d 01 d0                                        	add    r8,r10
    8081:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8086:	4d 01 d0                                        	add    r8,r10
    8089:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    808e:	4d 01 d0                                        	add    r8,r10
    8091:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8096:	4d 01 d0                                        	add    r8,r10
    8099:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    809e:	4d 01 d0                                        	add    r8,r10
    80a1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    80a6:	4d 01 d0                                        	add    r8,r10
    80a9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    80ae:	4d 01 d0                                        	add    r8,r10
    80b1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    80b6:	4d 01 d0                                        	add    r8,r10
    80b9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    80be:	4d 01 d0                                        	add    r8,r10
    80c1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    80c6:	4d 01 d0                                        	add    r8,r10
    80c9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    80ce:	4d 01 d0                                        	add    r8,r10
    80d1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    80d6:	4d 01 d0                                        	add    r8,r10
    80d9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    80de:	4d 01 d0                                        	add    r8,r10
    80e1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    80e6:	4d 01 d0                                        	add    r8,r10
    80e9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    80ee:	4d 01 d0                                        	add    r8,r10
    80f1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    80f6:	4d 01 d0                                        	add    r8,r10
    80f9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    80fe:	4d 01 d0                                        	add    r8,r10
    8101:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8106:	4d 01 d0                                        	add    r8,r10
    8109:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    810e:	4d 01 d0                                        	add    r8,r10
    8111:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8116:	4d 01 d0                                        	add    r8,r10
    8119:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    811e:	4d 01 d0                                        	add    r8,r10
    8121:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8126:	4d 01 d0                                        	add    r8,r10
    8129:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    812e:	4d 01 d0                                        	add    r8,r10
    8131:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8136:	4d 01 d0                                        	add    r8,r10
    8139:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    813e:	4d 01 d0                                        	add    r8,r10
    8141:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8146:	4d 01 d0                                        	add    r8,r10
    8149:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    814e:	4d 01 d0                                        	add    r8,r10
    8151:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8156:	4d 01 d0                                        	add    r8,r10
    8159:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    815e:	4d 01 d0                                        	add    r8,r10
    8161:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8166:	4d 01 d0                                        	add    r8,r10
    8169:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    816e:	4d 01 d0                                        	add    r8,r10
    8171:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8176:	4d 01 d0                                        	add    r8,r10
    8179:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    817e:	4d 01 d0                                        	add    r8,r10
    8181:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8186:	4d 01 d0                                        	add    r8,r10
    8189:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    818e:	4d 01 d0                                        	add    r8,r10
    8191:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8196:	4d 01 d0                                        	add    r8,r10
    8199:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    819e:	4d 01 d0                                        	add    r8,r10
    81a1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    81a6:	4d 01 d0                                        	add    r8,r10
    81a9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    81ae:	4d 01 d0                                        	add    r8,r10
    81b1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    81b6:	4d 01 d0                                        	add    r8,r10
    81b9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    81be:	4d 01 d0                                        	add    r8,r10
    81c1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    81c6:	4d 01 d0                                        	add    r8,r10
    81c9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    81ce:	4d 01 d0                                        	add    r8,r10
    81d1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    81d6:	4d 01 d0                                        	add    r8,r10
    81d9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    81de:	4d 01 d0                                        	add    r8,r10
    81e1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    81e6:	4d 01 d0                                        	add    r8,r10
    81e9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    81ee:	4d 01 d0                                        	add    r8,r10
    81f1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    81f6:	4d 01 d0                                        	add    r8,r10
    81f9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    81fe:	4d 01 d0                                        	add    r8,r10
    8201:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8206:	4d 01 d0                                        	add    r8,r10
    8209:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    820e:	4d 01 d0                                        	add    r8,r10
    8211:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8216:	4d 01 d0                                        	add    r8,r10
    8219:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    821e:	4d 01 d0                                        	add    r8,r10
    8221:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8226:	4d 01 d0                                        	add    r8,r10
    8229:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    822e:	4d 01 d0                                        	add    r8,r10
    8231:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8236:	4d 01 d0                                        	add    r8,r10
    8239:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    823e:	4d 01 d0                                        	add    r8,r10
    8241:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8246:	4d 01 d0                                        	add    r8,r10
    8249:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    824e:	4d 01 d0                                        	add    r8,r10
    8251:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8256:	4d 01 d0                                        	add    r8,r10
    8259:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    825e:	4d 01 d0                                        	add    r8,r10
    8261:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8266:	4d 01 d0                                        	add    r8,r10
    8269:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    826e:	4d 01 d0                                        	add    r8,r10
    8271:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8276:	4d 01 d0                                        	add    r8,r10
    8279:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    827e:	4d 01 d0                                        	add    r8,r10
    8281:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8286:	4d 01 d0                                        	add    r8,r10
    8289:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    828e:	4d 01 d0                                        	add    r8,r10
    8291:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8296:	4d 01 d0                                        	add    r8,r10
    8299:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    829e:	4d 01 d0                                        	add    r8,r10
    82a1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    82a6:	4d 01 d0                                        	add    r8,r10
    82a9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    82ae:	4d 01 d0                                        	add    r8,r10
    82b1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    82b6:	4d 01 d0                                        	add    r8,r10
    82b9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    82be:	4d 01 d0                                        	add    r8,r10
    82c1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    82c6:	4d 01 d0                                        	add    r8,r10
    82c9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    82ce:	4d 01 d0                                        	add    r8,r10
    82d1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    82d6:	4d 01 d0                                        	add    r8,r10
    82d9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    82de:	4d 01 d0                                        	add    r8,r10
    82e1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    82e6:	4d 01 d0                                        	add    r8,r10
    82e9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    82ee:	4d 01 d0                                        	add    r8,r10
    82f1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    82f6:	4d 01 d0                                        	add    r8,r10
    82f9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    82fe:	4d 01 d0                                        	add    r8,r10
    8301:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8306:	4d 01 d0                                        	add    r8,r10
    8309:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    830e:	4d 01 d0                                        	add    r8,r10
    8311:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8316:	4d 01 d0                                        	add    r8,r10
    8319:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    831e:	4d 01 d0                                        	add    r8,r10
    8321:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8326:	4d 01 d0                                        	add    r8,r10
    8329:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    832e:	4d 01 d0                                        	add    r8,r10
    8331:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8336:	4d 01 d0                                        	add    r8,r10
    8339:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    833e:	4d 01 d0                                        	add    r8,r10
    8341:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8346:	4d 01 d0                                        	add    r8,r10
    8349:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    834e:	4d 01 d0                                        	add    r8,r10
    8351:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8356:	4d 01 d0                                        	add    r8,r10
    8359:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    835e:	4d 01 d0                                        	add    r8,r10
    8361:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8366:	4d 01 d0                                        	add    r8,r10
    8369:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    836e:	4d 01 d0                                        	add    r8,r10
    8371:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8376:	4d 01 d0                                        	add    r8,r10
    8379:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    837e:	4d 01 d0                                        	add    r8,r10
    8381:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8386:	4d 01 d0                                        	add    r8,r10
    8389:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    838e:	4d 01 d0                                        	add    r8,r10
    8391:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8396:	4d 01 d0                                        	add    r8,r10
    8399:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    839e:	4d 01 d0                                        	add    r8,r10
    83a1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    83a6:	4d 01 d0                                        	add    r8,r10
    83a9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    83ae:	4d 01 d0                                        	add    r8,r10
    83b1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    83b6:	4d 01 d0                                        	add    r8,r10
    83b9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    83be:	4d 01 d0                                        	add    r8,r10
    83c1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    83c6:	4d 01 d0                                        	add    r8,r10
    83c9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    83ce:	4d 01 d0                                        	add    r8,r10
    83d1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    83d6:	4d 01 d0                                        	add    r8,r10
    83d9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    83de:	4d 01 d0                                        	add    r8,r10
    83e1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    83e6:	4d 01 d0                                        	add    r8,r10
    83e9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    83ee:	4d 01 d0                                        	add    r8,r10
    83f1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    83f6:	4d 01 d0                                        	add    r8,r10
    83f9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    83fe:	4d 01 d0                                        	add    r8,r10
    8401:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8406:	4d 01 d0                                        	add    r8,r10
    8409:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    840e:	4d 01 d0                                        	add    r8,r10
    8411:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8416:	4d 01 d0                                        	add    r8,r10
    8419:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    841e:	4d 01 d0                                        	add    r8,r10
    8421:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8426:	4d 01 d0                                        	add    r8,r10
    8429:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    842e:	4d 01 d0                                        	add    r8,r10
    8431:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8436:	4d 01 d0                                        	add    r8,r10
    8439:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    843e:	4d 01 d0                                        	add    r8,r10
    8441:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8446:	4d 01 d0                                        	add    r8,r10
    8449:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    844e:	4d 01 d0                                        	add    r8,r10
    8451:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8456:	4d 01 d0                                        	add    r8,r10
    8459:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    845e:	4d 01 d0                                        	add    r8,r10
    8461:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8466:	4d 01 d0                                        	add    r8,r10
    8469:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    846e:	4d 01 d0                                        	add    r8,r10
    8471:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8476:	4d 01 d0                                        	add    r8,r10
    8479:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    847e:	4d 01 d0                                        	add    r8,r10
    8481:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8486:	4d 01 d0                                        	add    r8,r10
    8489:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    848e:	4d 01 d0                                        	add    r8,r10
    8491:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8496:	4d 01 d0                                        	add    r8,r10
    8499:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    849e:	4d 01 d0                                        	add    r8,r10
    84a1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    84a6:	4d 01 d0                                        	add    r8,r10
    84a9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    84ae:	4d 01 d0                                        	add    r8,r10
    84b1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    84b6:	4d 01 d0                                        	add    r8,r10
    84b9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    84be:	4d 01 d0                                        	add    r8,r10
    84c1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    84c6:	4d 01 d0                                        	add    r8,r10
    84c9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    84ce:	4d 01 d0                                        	add    r8,r10
    84d1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    84d6:	4d 01 d0                                        	add    r8,r10
    84d9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    84de:	4d 01 d0                                        	add    r8,r10
    84e1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    84e6:	4d 01 d0                                        	add    r8,r10
    84e9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    84ee:	4d 01 d0                                        	add    r8,r10
    84f1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    84f6:	4d 01 d0                                        	add    r8,r10
    84f9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    84fe:	4d 01 d0                                        	add    r8,r10
    8501:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8506:	4d 01 d0                                        	add    r8,r10
    8509:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    850e:	4d 01 d0                                        	add    r8,r10
    8511:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8516:	4d 01 d0                                        	add    r8,r10
    8519:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    851e:	4d 01 d0                                        	add    r8,r10
    8521:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8526:	4d 01 d0                                        	add    r8,r10
    8529:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    852e:	4d 01 d0                                        	add    r8,r10
    8531:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8536:	4d 01 d0                                        	add    r8,r10
    8539:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    853e:	4d 01 d0                                        	add    r8,r10
    8541:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8546:	4d 01 d0                                        	add    r8,r10
    8549:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    854e:	4d 01 d0                                        	add    r8,r10
    8551:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8556:	4d 01 d0                                        	add    r8,r10
    8559:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    855e:	4d 01 d0                                        	add    r8,r10
    8561:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8566:	4d 01 d0                                        	add    r8,r10
    8569:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    856e:	4d 01 d0                                        	add    r8,r10
    8571:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8576:	4d 01 d0                                        	add    r8,r10
    8579:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    857e:	4d 01 d0                                        	add    r8,r10
    8581:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8586:	4d 01 d0                                        	add    r8,r10
    8589:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    858e:	4d 01 d0                                        	add    r8,r10
    8591:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8596:	4d 01 d0                                        	add    r8,r10
    8599:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    859e:	4d 01 d0                                        	add    r8,r10
    85a1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    85a6:	4d 01 d0                                        	add    r8,r10
    85a9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    85ae:	4d 01 d0                                        	add    r8,r10
    85b1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    85b6:	4d 01 d0                                        	add    r8,r10
    85b9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    85be:	4d 01 d0                                        	add    r8,r10
    85c1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    85c6:	4d 01 d0                                        	add    r8,r10
    85c9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    85ce:	4d 01 d0                                        	add    r8,r10
    85d1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    85d6:	4d 01 d0                                        	add    r8,r10
    85d9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    85de:	4d 01 d0                                        	add    r8,r10
    85e1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    85e6:	4d 01 d0                                        	add    r8,r10
    85e9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    85ee:	4d 01 d0                                        	add    r8,r10
    85f1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    85f6:	4d 01 d0                                        	add    r8,r10
    85f9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    85fe:	4d 01 d0                                        	add    r8,r10
    8601:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8606:	4d 01 d0                                        	add    r8,r10
    8609:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    860e:	4d 01 d0                                        	add    r8,r10
    8611:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8616:	4d 01 d0                                        	add    r8,r10
    8619:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    861e:	4d 01 d0                                        	add    r8,r10
    8621:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8626:	4d 01 d0                                        	add    r8,r10
    8629:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    862e:	4d 01 d0                                        	add    r8,r10
    8631:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8636:	4d 01 d0                                        	add    r8,r10
    8639:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    863e:	4d 01 d0                                        	add    r8,r10
    8641:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8646:	4d 01 d0                                        	add    r8,r10
    8649:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    864e:	4d 01 d0                                        	add    r8,r10
    8651:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8656:	4d 01 d0                                        	add    r8,r10
    8659:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    865e:	4d 01 d0                                        	add    r8,r10
    8661:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8666:	4d 01 d0                                        	add    r8,r10
    8669:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    866e:	4d 01 d0                                        	add    r8,r10
    8671:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8676:	4d 01 d0                                        	add    r8,r10
    8679:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    867e:	4d 01 d0                                        	add    r8,r10
    8681:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8686:	4d 01 d0                                        	add    r8,r10
    8689:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    868e:	4d 01 d0                                        	add    r8,r10
    8691:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8696:	4d 01 d0                                        	add    r8,r10
    8699:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    869e:	4d 01 d0                                        	add    r8,r10
    86a1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    86a6:	4d 01 d0                                        	add    r8,r10
    86a9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    86ae:	4d 01 d0                                        	add    r8,r10
    86b1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    86b6:	4d 01 d0                                        	add    r8,r10
    86b9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    86be:	4d 01 d0                                        	add    r8,r10
    86c1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    86c6:	4d 01 d0                                        	add    r8,r10
    86c9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    86ce:	4d 01 d0                                        	add    r8,r10
    86d1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    86d6:	4d 01 d0                                        	add    r8,r10
    86d9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    86de:	4d 01 d0                                        	add    r8,r10
    86e1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    86e6:	4d 01 d0                                        	add    r8,r10
    86e9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    86ee:	4d 01 d0                                        	add    r8,r10
    86f1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    86f6:	4d 01 d0                                        	add    r8,r10
    86f9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    86fe:	4d 01 d0                                        	add    r8,r10
    8701:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8706:	4d 01 d0                                        	add    r8,r10
    8709:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    870e:	4d 01 d0                                        	add    r8,r10
    8711:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8716:	4d 01 d0                                        	add    r8,r10
    8719:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    871e:	4d 01 d0                                        	add    r8,r10
    8721:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8726:	4d 01 d0                                        	add    r8,r10
    8729:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    872e:	4d 01 d0                                        	add    r8,r10
    8731:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8736:	4d 01 d0                                        	add    r8,r10
    8739:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    873e:	4d 01 d0                                        	add    r8,r10
    8741:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8746:	4d 01 d0                                        	add    r8,r10
    8749:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    874e:	4d 01 d0                                        	add    r8,r10
    8751:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8756:	4d 01 d0                                        	add    r8,r10
    8759:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    875e:	4d 01 d0                                        	add    r8,r10
    8761:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8766:	4d 01 d0                                        	add    r8,r10
    8769:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    876e:	4d 01 d0                                        	add    r8,r10
    8771:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8776:	4d 01 d0                                        	add    r8,r10
    8779:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    877e:	4d 01 d0                                        	add    r8,r10
    8781:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8786:	4d 01 d0                                        	add    r8,r10
    8789:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    878e:	4d 01 d0                                        	add    r8,r10
    8791:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8796:	4d 01 d0                                        	add    r8,r10
    8799:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    879e:	4d 01 d0                                        	add    r8,r10
    87a1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    87a6:	4d 01 d0                                        	add    r8,r10
    87a9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    87ae:	4d 01 d0                                        	add    r8,r10
    87b1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    87b6:	4d 01 d0                                        	add    r8,r10
    87b9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    87be:	4d 01 d0                                        	add    r8,r10
    87c1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    87c6:	4d 01 d0                                        	add    r8,r10
    87c9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    87ce:	4d 01 d0                                        	add    r8,r10
    87d1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    87d6:	4d 01 d0                                        	add    r8,r10
    87d9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    87de:	4d 01 d0                                        	add    r8,r10
    87e1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    87e6:	4d 01 d0                                        	add    r8,r10
    87e9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    87ee:	4d 01 d0                                        	add    r8,r10
    87f1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    87f6:	4d 01 d0                                        	add    r8,r10
    87f9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    87fe:	4d 01 d0                                        	add    r8,r10
    8801:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8806:	4d 01 d0                                        	add    r8,r10
    8809:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    880e:	4d 01 d0                                        	add    r8,r10
    8811:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8816:	4d 01 d0                                        	add    r8,r10
    8819:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    881e:	4d 01 d0                                        	add    r8,r10
    8821:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8826:	4d 01 d0                                        	add    r8,r10
    8829:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    882e:	4d 01 d0                                        	add    r8,r10
    8831:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8836:	4d 01 d0                                        	add    r8,r10
    8839:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    883e:	4d 01 d0                                        	add    r8,r10
    8841:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8846:	4d 01 d0                                        	add    r8,r10
    8849:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    884e:	4d 01 d0                                        	add    r8,r10
    8851:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8856:	4d 01 d0                                        	add    r8,r10
    8859:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    885e:	4d 01 d0                                        	add    r8,r10
    8861:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8866:	4d 01 d0                                        	add    r8,r10
    8869:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    886e:	4d 01 d0                                        	add    r8,r10
    8871:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8876:	4d 01 d0                                        	add    r8,r10
    8879:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    887e:	4d 01 d0                                        	add    r8,r10
    8881:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8886:	4d 01 d0                                        	add    r8,r10
    8889:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    888e:	4d 01 d0                                        	add    r8,r10
    8891:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8896:	4d 01 d0                                        	add    r8,r10
    8899:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    889e:	4d 01 d0                                        	add    r8,r10
    88a1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    88a6:	4d 01 d0                                        	add    r8,r10
    88a9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    88ae:	4d 01 d0                                        	add    r8,r10
    88b1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    88b6:	4d 01 d0                                        	add    r8,r10
    88b9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    88be:	4d 01 d0                                        	add    r8,r10
    88c1:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    88c6:	4d 01 d0                                        	add    r8,r10
    88c9:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    88ce:	4d 01 d0                                        	add    r8,r10
    88d1:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    88d6:	4d 01 d0                                        	add    r8,r10
    88d9:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    88de:	4d 01 d0                                        	add    r8,r10
    88e1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    88e6:	4d 01 d0                                        	add    r8,r10
    88e9:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    88ee:	4d 01 d0                                        	add    r8,r10
    88f1:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    88f6:	4d 01 d0                                        	add    r8,r10
    88f9:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    88fe:	4d 01 d0                                        	add    r8,r10
    8901:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8906:	4d 01 d0                                        	add    r8,r10
    8909:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    890e:	4d 01 d0                                        	add    r8,r10
    8911:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8916:	4d 01 d0                                        	add    r8,r10
    8919:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    891e:	4d 01 d0                                        	add    r8,r10
    8921:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8926:	4d 01 d0                                        	add    r8,r10
    8929:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    892e:	4d 01 d0                                        	add    r8,r10
    8931:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8936:	4d 01 d0                                        	add    r8,r10
    8939:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    893e:	4d 01 d0                                        	add    r8,r10
    8941:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8946:	4d 01 d0                                        	add    r8,r10
    8949:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    894e:	4d 01 d0                                        	add    r8,r10
    8951:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8956:	4d 01 d0                                        	add    r8,r10
    8959:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    895e:	4d 01 d0                                        	add    r8,r10
    8961:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8966:	4d 01 d0                                        	add    r8,r10
    8969:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    896e:	4d 01 d0                                        	add    r8,r10
    8971:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8976:	4d 01 d0                                        	add    r8,r10
    8979:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    897e:	4d 01 d0                                        	add    r8,r10
    8981:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8986:	4d 01 d0                                        	add    r8,r10
    8989:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    898e:	4d 01 d0                                        	add    r8,r10
    8991:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8996:	4d 01 d0                                        	add    r8,r10
    8999:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    899e:	4d 01 d0                                        	add    r8,r10
    89a1:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    89a6:	4d 01 d0                                        	add    r8,r10
    89a9:	41 f6 c1 01                                     	test   r9b,0x1
    89ad:	75 09                                           	jne    89b8 <choose_6>
    89af:	4c 8d 15 0c 00 00 00                            	lea    r10,[rip+0xc]        # 89c2 <target_a_6>
    89b6:	eb 07                                           	jmp    89bf <dispatch_6>

00000000000089b8 <choose_6>:
    89b8:	4c 8d 15 09 00 00 00                            	lea    r10,[rip+0x9]        # 89c8 <target_b_6>

00000000000089bf <dispatch_6>:
    89bf:	41 ff e2                                        	jmp    r10

00000000000089c2 <target_a_6>:
    89c2:	49 83 c0 01                                     	add    r8,0x1
    89c6:	eb 04                                           	jmp    89cc <join_6>

00000000000089c8 <target_b_6>:
    89c8:	49 83 c0 02                                     	add    r8,0x2

00000000000089cc <join_6>:
    89cc:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    89d1:	4d 01 d0                                        	add    r8,r10
    89d4:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    89d9:	4d 01 d0                                        	add    r8,r10
    89dc:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    89e1:	4d 01 d0                                        	add    r8,r10
    89e4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    89e9:	4d 01 d0                                        	add    r8,r10
    89ec:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    89f1:	4d 01 d0                                        	add    r8,r10
    89f4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    89f9:	4d 01 d0                                        	add    r8,r10
    89fc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8a01:	4d 01 d0                                        	add    r8,r10
    8a04:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8a09:	4d 01 d0                                        	add    r8,r10
    8a0c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8a11:	4d 01 d0                                        	add    r8,r10
    8a14:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8a19:	4d 01 d0                                        	add    r8,r10
    8a1c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8a21:	4d 01 d0                                        	add    r8,r10
    8a24:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8a29:	4d 01 d0                                        	add    r8,r10
    8a2c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8a31:	4d 01 d0                                        	add    r8,r10
    8a34:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8a39:	4d 01 d0                                        	add    r8,r10
    8a3c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8a41:	4d 01 d0                                        	add    r8,r10
    8a44:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8a49:	4d 01 d0                                        	add    r8,r10
    8a4c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8a51:	4d 01 d0                                        	add    r8,r10
    8a54:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8a59:	4d 01 d0                                        	add    r8,r10
    8a5c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8a61:	4d 01 d0                                        	add    r8,r10
    8a64:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8a69:	4d 01 d0                                        	add    r8,r10
    8a6c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8a71:	4d 01 d0                                        	add    r8,r10
    8a74:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8a79:	4d 01 d0                                        	add    r8,r10
    8a7c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8a81:	4d 01 d0                                        	add    r8,r10
    8a84:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8a89:	4d 01 d0                                        	add    r8,r10
    8a8c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8a91:	4d 01 d0                                        	add    r8,r10
    8a94:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8a99:	4d 01 d0                                        	add    r8,r10
    8a9c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8aa1:	4d 01 d0                                        	add    r8,r10
    8aa4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8aa9:	4d 01 d0                                        	add    r8,r10
    8aac:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8ab1:	4d 01 d0                                        	add    r8,r10
    8ab4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8ab9:	4d 01 d0                                        	add    r8,r10
    8abc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8ac1:	4d 01 d0                                        	add    r8,r10
    8ac4:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8ac9:	4d 01 d0                                        	add    r8,r10
    8acc:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8ad1:	4d 01 d0                                        	add    r8,r10
    8ad4:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8ad9:	4d 01 d0                                        	add    r8,r10
    8adc:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8ae1:	4d 01 d0                                        	add    r8,r10
    8ae4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8ae9:	4d 01 d0                                        	add    r8,r10
    8aec:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8af1:	4d 01 d0                                        	add    r8,r10
    8af4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8af9:	4d 01 d0                                        	add    r8,r10
    8afc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8b01:	4d 01 d0                                        	add    r8,r10
    8b04:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8b09:	4d 01 d0                                        	add    r8,r10
    8b0c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8b11:	4d 01 d0                                        	add    r8,r10
    8b14:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8b19:	4d 01 d0                                        	add    r8,r10
    8b1c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8b21:	4d 01 d0                                        	add    r8,r10
    8b24:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8b29:	4d 01 d0                                        	add    r8,r10
    8b2c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8b31:	4d 01 d0                                        	add    r8,r10
    8b34:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8b39:	4d 01 d0                                        	add    r8,r10
    8b3c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8b41:	4d 01 d0                                        	add    r8,r10
    8b44:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8b49:	4d 01 d0                                        	add    r8,r10
    8b4c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8b51:	4d 01 d0                                        	add    r8,r10
    8b54:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8b59:	4d 01 d0                                        	add    r8,r10
    8b5c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8b61:	4d 01 d0                                        	add    r8,r10
    8b64:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8b69:	4d 01 d0                                        	add    r8,r10
    8b6c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8b71:	4d 01 d0                                        	add    r8,r10
    8b74:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8b79:	4d 01 d0                                        	add    r8,r10
    8b7c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8b81:	4d 01 d0                                        	add    r8,r10
    8b84:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8b89:	4d 01 d0                                        	add    r8,r10
    8b8c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8b91:	4d 01 d0                                        	add    r8,r10
    8b94:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8b99:	4d 01 d0                                        	add    r8,r10
    8b9c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8ba1:	4d 01 d0                                        	add    r8,r10
    8ba4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8ba9:	4d 01 d0                                        	add    r8,r10
    8bac:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8bb1:	4d 01 d0                                        	add    r8,r10
    8bb4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8bb9:	4d 01 d0                                        	add    r8,r10
    8bbc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8bc1:	4d 01 d0                                        	add    r8,r10
    8bc4:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8bc9:	4d 01 d0                                        	add    r8,r10
    8bcc:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8bd1:	4d 01 d0                                        	add    r8,r10
    8bd4:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8bd9:	4d 01 d0                                        	add    r8,r10
    8bdc:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8be1:	4d 01 d0                                        	add    r8,r10
    8be4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8be9:	4d 01 d0                                        	add    r8,r10
    8bec:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8bf1:	4d 01 d0                                        	add    r8,r10
    8bf4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8bf9:	4d 01 d0                                        	add    r8,r10
    8bfc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8c01:	4d 01 d0                                        	add    r8,r10
    8c04:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8c09:	4d 01 d0                                        	add    r8,r10
    8c0c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8c11:	4d 01 d0                                        	add    r8,r10
    8c14:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8c19:	4d 01 d0                                        	add    r8,r10
    8c1c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8c21:	4d 01 d0                                        	add    r8,r10
    8c24:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8c29:	4d 01 d0                                        	add    r8,r10
    8c2c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8c31:	4d 01 d0                                        	add    r8,r10
    8c34:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8c39:	4d 01 d0                                        	add    r8,r10
    8c3c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8c41:	4d 01 d0                                        	add    r8,r10
    8c44:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8c49:	4d 01 d0                                        	add    r8,r10
    8c4c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8c51:	4d 01 d0                                        	add    r8,r10
    8c54:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8c59:	4d 01 d0                                        	add    r8,r10
    8c5c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8c61:	4d 01 d0                                        	add    r8,r10
    8c64:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8c69:	4d 01 d0                                        	add    r8,r10
    8c6c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8c71:	4d 01 d0                                        	add    r8,r10
    8c74:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8c79:	4d 01 d0                                        	add    r8,r10
    8c7c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8c81:	4d 01 d0                                        	add    r8,r10
    8c84:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8c89:	4d 01 d0                                        	add    r8,r10
    8c8c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8c91:	4d 01 d0                                        	add    r8,r10
    8c94:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8c99:	4d 01 d0                                        	add    r8,r10
    8c9c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8ca1:	4d 01 d0                                        	add    r8,r10
    8ca4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8ca9:	4d 01 d0                                        	add    r8,r10
    8cac:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8cb1:	4d 01 d0                                        	add    r8,r10
    8cb4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8cb9:	4d 01 d0                                        	add    r8,r10
    8cbc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8cc1:	4d 01 d0                                        	add    r8,r10
    8cc4:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8cc9:	4d 01 d0                                        	add    r8,r10
    8ccc:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8cd1:	4d 01 d0                                        	add    r8,r10
    8cd4:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8cd9:	4d 01 d0                                        	add    r8,r10
    8cdc:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8ce1:	4d 01 d0                                        	add    r8,r10
    8ce4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8ce9:	4d 01 d0                                        	add    r8,r10
    8cec:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8cf1:	4d 01 d0                                        	add    r8,r10
    8cf4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8cf9:	4d 01 d0                                        	add    r8,r10
    8cfc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8d01:	4d 01 d0                                        	add    r8,r10
    8d04:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8d09:	4d 01 d0                                        	add    r8,r10
    8d0c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8d11:	4d 01 d0                                        	add    r8,r10
    8d14:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8d19:	4d 01 d0                                        	add    r8,r10
    8d1c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8d21:	4d 01 d0                                        	add    r8,r10
    8d24:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8d29:	4d 01 d0                                        	add    r8,r10
    8d2c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8d31:	4d 01 d0                                        	add    r8,r10
    8d34:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8d39:	4d 01 d0                                        	add    r8,r10
    8d3c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8d41:	4d 01 d0                                        	add    r8,r10
    8d44:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8d49:	4d 01 d0                                        	add    r8,r10
    8d4c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8d51:	4d 01 d0                                        	add    r8,r10
    8d54:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8d59:	4d 01 d0                                        	add    r8,r10
    8d5c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8d61:	4d 01 d0                                        	add    r8,r10
    8d64:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8d69:	4d 01 d0                                        	add    r8,r10
    8d6c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8d71:	4d 01 d0                                        	add    r8,r10
    8d74:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8d79:	4d 01 d0                                        	add    r8,r10
    8d7c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8d81:	4d 01 d0                                        	add    r8,r10
    8d84:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8d89:	4d 01 d0                                        	add    r8,r10
    8d8c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8d91:	4d 01 d0                                        	add    r8,r10
    8d94:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8d99:	4d 01 d0                                        	add    r8,r10
    8d9c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8da1:	4d 01 d0                                        	add    r8,r10
    8da4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8da9:	4d 01 d0                                        	add    r8,r10
    8dac:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8db1:	4d 01 d0                                        	add    r8,r10
    8db4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8db9:	4d 01 d0                                        	add    r8,r10
    8dbc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8dc1:	4d 01 d0                                        	add    r8,r10
    8dc4:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8dc9:	4d 01 d0                                        	add    r8,r10
    8dcc:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8dd1:	4d 01 d0                                        	add    r8,r10
    8dd4:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8dd9:	4d 01 d0                                        	add    r8,r10
    8ddc:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8de1:	4d 01 d0                                        	add    r8,r10
    8de4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8de9:	4d 01 d0                                        	add    r8,r10
    8dec:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8df1:	4d 01 d0                                        	add    r8,r10
    8df4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8df9:	4d 01 d0                                        	add    r8,r10
    8dfc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8e01:	4d 01 d0                                        	add    r8,r10
    8e04:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8e09:	4d 01 d0                                        	add    r8,r10
    8e0c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8e11:	4d 01 d0                                        	add    r8,r10
    8e14:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8e19:	4d 01 d0                                        	add    r8,r10
    8e1c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8e21:	4d 01 d0                                        	add    r8,r10
    8e24:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8e29:	4d 01 d0                                        	add    r8,r10
    8e2c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8e31:	4d 01 d0                                        	add    r8,r10
    8e34:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8e39:	4d 01 d0                                        	add    r8,r10
    8e3c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8e41:	4d 01 d0                                        	add    r8,r10
    8e44:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8e49:	4d 01 d0                                        	add    r8,r10
    8e4c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8e51:	4d 01 d0                                        	add    r8,r10
    8e54:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8e59:	4d 01 d0                                        	add    r8,r10
    8e5c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8e61:	4d 01 d0                                        	add    r8,r10
    8e64:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8e69:	4d 01 d0                                        	add    r8,r10
    8e6c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8e71:	4d 01 d0                                        	add    r8,r10
    8e74:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8e79:	4d 01 d0                                        	add    r8,r10
    8e7c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8e81:	4d 01 d0                                        	add    r8,r10
    8e84:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8e89:	4d 01 d0                                        	add    r8,r10
    8e8c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8e91:	4d 01 d0                                        	add    r8,r10
    8e94:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8e99:	4d 01 d0                                        	add    r8,r10
    8e9c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8ea1:	4d 01 d0                                        	add    r8,r10
    8ea4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8ea9:	4d 01 d0                                        	add    r8,r10
    8eac:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8eb1:	4d 01 d0                                        	add    r8,r10
    8eb4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8eb9:	4d 01 d0                                        	add    r8,r10
    8ebc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8ec1:	4d 01 d0                                        	add    r8,r10
    8ec4:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8ec9:	4d 01 d0                                        	add    r8,r10
    8ecc:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8ed1:	4d 01 d0                                        	add    r8,r10
    8ed4:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8ed9:	4d 01 d0                                        	add    r8,r10
    8edc:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8ee1:	4d 01 d0                                        	add    r8,r10
    8ee4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8ee9:	4d 01 d0                                        	add    r8,r10
    8eec:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8ef1:	4d 01 d0                                        	add    r8,r10
    8ef4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8ef9:	4d 01 d0                                        	add    r8,r10
    8efc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8f01:	4d 01 d0                                        	add    r8,r10
    8f04:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8f09:	4d 01 d0                                        	add    r8,r10
    8f0c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8f11:	4d 01 d0                                        	add    r8,r10
    8f14:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8f19:	4d 01 d0                                        	add    r8,r10
    8f1c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8f21:	4d 01 d0                                        	add    r8,r10
    8f24:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8f29:	4d 01 d0                                        	add    r8,r10
    8f2c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8f31:	4d 01 d0                                        	add    r8,r10
    8f34:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8f39:	4d 01 d0                                        	add    r8,r10
    8f3c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8f41:	4d 01 d0                                        	add    r8,r10
    8f44:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8f49:	4d 01 d0                                        	add    r8,r10
    8f4c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8f51:	4d 01 d0                                        	add    r8,r10
    8f54:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8f59:	4d 01 d0                                        	add    r8,r10
    8f5c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8f61:	4d 01 d0                                        	add    r8,r10
    8f64:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8f69:	4d 01 d0                                        	add    r8,r10
    8f6c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8f71:	4d 01 d0                                        	add    r8,r10
    8f74:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8f79:	4d 01 d0                                        	add    r8,r10
    8f7c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8f81:	4d 01 d0                                        	add    r8,r10
    8f84:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8f89:	4d 01 d0                                        	add    r8,r10
    8f8c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8f91:	4d 01 d0                                        	add    r8,r10
    8f94:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8f99:	4d 01 d0                                        	add    r8,r10
    8f9c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8fa1:	4d 01 d0                                        	add    r8,r10
    8fa4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8fa9:	4d 01 d0                                        	add    r8,r10
    8fac:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8fb1:	4d 01 d0                                        	add    r8,r10
    8fb4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8fb9:	4d 01 d0                                        	add    r8,r10
    8fbc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    8fc1:	4d 01 d0                                        	add    r8,r10
    8fc4:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    8fc9:	4d 01 d0                                        	add    r8,r10
    8fcc:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    8fd1:	4d 01 d0                                        	add    r8,r10
    8fd4:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    8fd9:	4d 01 d0                                        	add    r8,r10
    8fdc:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    8fe1:	4d 01 d0                                        	add    r8,r10
    8fe4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    8fe9:	4d 01 d0                                        	add    r8,r10
    8fec:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    8ff1:	4d 01 d0                                        	add    r8,r10
    8ff4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    8ff9:	4d 01 d0                                        	add    r8,r10
    8ffc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9001:	4d 01 d0                                        	add    r8,r10
    9004:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9009:	4d 01 d0                                        	add    r8,r10
    900c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9011:	4d 01 d0                                        	add    r8,r10
    9014:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9019:	4d 01 d0                                        	add    r8,r10
    901c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9021:	4d 01 d0                                        	add    r8,r10
    9024:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9029:	4d 01 d0                                        	add    r8,r10
    902c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9031:	4d 01 d0                                        	add    r8,r10
    9034:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9039:	4d 01 d0                                        	add    r8,r10
    903c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9041:	4d 01 d0                                        	add    r8,r10
    9044:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9049:	4d 01 d0                                        	add    r8,r10
    904c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9051:	4d 01 d0                                        	add    r8,r10
    9054:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9059:	4d 01 d0                                        	add    r8,r10
    905c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9061:	4d 01 d0                                        	add    r8,r10
    9064:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9069:	4d 01 d0                                        	add    r8,r10
    906c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9071:	4d 01 d0                                        	add    r8,r10
    9074:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9079:	4d 01 d0                                        	add    r8,r10
    907c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9081:	4d 01 d0                                        	add    r8,r10
    9084:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9089:	4d 01 d0                                        	add    r8,r10
    908c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9091:	4d 01 d0                                        	add    r8,r10
    9094:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9099:	4d 01 d0                                        	add    r8,r10
    909c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    90a1:	4d 01 d0                                        	add    r8,r10
    90a4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    90a9:	4d 01 d0                                        	add    r8,r10
    90ac:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    90b1:	4d 01 d0                                        	add    r8,r10
    90b4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    90b9:	4d 01 d0                                        	add    r8,r10
    90bc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    90c1:	4d 01 d0                                        	add    r8,r10
    90c4:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    90c9:	4d 01 d0                                        	add    r8,r10
    90cc:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    90d1:	4d 01 d0                                        	add    r8,r10
    90d4:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    90d9:	4d 01 d0                                        	add    r8,r10
    90dc:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    90e1:	4d 01 d0                                        	add    r8,r10
    90e4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    90e9:	4d 01 d0                                        	add    r8,r10
    90ec:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    90f1:	4d 01 d0                                        	add    r8,r10
    90f4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    90f9:	4d 01 d0                                        	add    r8,r10
    90fc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9101:	4d 01 d0                                        	add    r8,r10
    9104:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9109:	4d 01 d0                                        	add    r8,r10
    910c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9111:	4d 01 d0                                        	add    r8,r10
    9114:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9119:	4d 01 d0                                        	add    r8,r10
    911c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9121:	4d 01 d0                                        	add    r8,r10
    9124:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9129:	4d 01 d0                                        	add    r8,r10
    912c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9131:	4d 01 d0                                        	add    r8,r10
    9134:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9139:	4d 01 d0                                        	add    r8,r10
    913c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9141:	4d 01 d0                                        	add    r8,r10
    9144:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9149:	4d 01 d0                                        	add    r8,r10
    914c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9151:	4d 01 d0                                        	add    r8,r10
    9154:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9159:	4d 01 d0                                        	add    r8,r10
    915c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9161:	4d 01 d0                                        	add    r8,r10
    9164:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9169:	4d 01 d0                                        	add    r8,r10
    916c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9171:	4d 01 d0                                        	add    r8,r10
    9174:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9179:	4d 01 d0                                        	add    r8,r10
    917c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9181:	4d 01 d0                                        	add    r8,r10
    9184:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9189:	4d 01 d0                                        	add    r8,r10
    918c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9191:	4d 01 d0                                        	add    r8,r10
    9194:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9199:	4d 01 d0                                        	add    r8,r10
    919c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    91a1:	4d 01 d0                                        	add    r8,r10
    91a4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    91a9:	4d 01 d0                                        	add    r8,r10
    91ac:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    91b1:	4d 01 d0                                        	add    r8,r10
    91b4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    91b9:	4d 01 d0                                        	add    r8,r10
    91bc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    91c1:	4d 01 d0                                        	add    r8,r10
    91c4:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    91c9:	4d 01 d0                                        	add    r8,r10
    91cc:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    91d1:	4d 01 d0                                        	add    r8,r10
    91d4:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    91d9:	4d 01 d0                                        	add    r8,r10
    91dc:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    91e1:	4d 01 d0                                        	add    r8,r10
    91e4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    91e9:	4d 01 d0                                        	add    r8,r10
    91ec:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    91f1:	4d 01 d0                                        	add    r8,r10
    91f4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    91f9:	4d 01 d0                                        	add    r8,r10
    91fc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9201:	4d 01 d0                                        	add    r8,r10
    9204:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9209:	4d 01 d0                                        	add    r8,r10
    920c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9211:	4d 01 d0                                        	add    r8,r10
    9214:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9219:	4d 01 d0                                        	add    r8,r10
    921c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9221:	4d 01 d0                                        	add    r8,r10
    9224:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9229:	4d 01 d0                                        	add    r8,r10
    922c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9231:	4d 01 d0                                        	add    r8,r10
    9234:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9239:	4d 01 d0                                        	add    r8,r10
    923c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9241:	4d 01 d0                                        	add    r8,r10
    9244:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9249:	4d 01 d0                                        	add    r8,r10
    924c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9251:	4d 01 d0                                        	add    r8,r10
    9254:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9259:	4d 01 d0                                        	add    r8,r10
    925c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9261:	4d 01 d0                                        	add    r8,r10
    9264:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9269:	4d 01 d0                                        	add    r8,r10
    926c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9271:	4d 01 d0                                        	add    r8,r10
    9274:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9279:	4d 01 d0                                        	add    r8,r10
    927c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9281:	4d 01 d0                                        	add    r8,r10
    9284:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9289:	4d 01 d0                                        	add    r8,r10
    928c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9291:	4d 01 d0                                        	add    r8,r10
    9294:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9299:	4d 01 d0                                        	add    r8,r10
    929c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    92a1:	4d 01 d0                                        	add    r8,r10
    92a4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    92a9:	4d 01 d0                                        	add    r8,r10
    92ac:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    92b1:	4d 01 d0                                        	add    r8,r10
    92b4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    92b9:	4d 01 d0                                        	add    r8,r10
    92bc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    92c1:	4d 01 d0                                        	add    r8,r10
    92c4:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    92c9:	4d 01 d0                                        	add    r8,r10
    92cc:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    92d1:	4d 01 d0                                        	add    r8,r10
    92d4:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    92d9:	4d 01 d0                                        	add    r8,r10
    92dc:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    92e1:	4d 01 d0                                        	add    r8,r10
    92e4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    92e9:	4d 01 d0                                        	add    r8,r10
    92ec:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    92f1:	4d 01 d0                                        	add    r8,r10
    92f4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    92f9:	4d 01 d0                                        	add    r8,r10
    92fc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9301:	4d 01 d0                                        	add    r8,r10
    9304:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9309:	4d 01 d0                                        	add    r8,r10
    930c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9311:	4d 01 d0                                        	add    r8,r10
    9314:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9319:	4d 01 d0                                        	add    r8,r10
    931c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9321:	4d 01 d0                                        	add    r8,r10
    9324:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9329:	4d 01 d0                                        	add    r8,r10
    932c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9331:	4d 01 d0                                        	add    r8,r10
    9334:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9339:	4d 01 d0                                        	add    r8,r10
    933c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9341:	4d 01 d0                                        	add    r8,r10
    9344:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9349:	4d 01 d0                                        	add    r8,r10
    934c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9351:	4d 01 d0                                        	add    r8,r10
    9354:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9359:	4d 01 d0                                        	add    r8,r10
    935c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9361:	4d 01 d0                                        	add    r8,r10
    9364:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9369:	4d 01 d0                                        	add    r8,r10
    936c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9371:	4d 01 d0                                        	add    r8,r10
    9374:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9379:	4d 01 d0                                        	add    r8,r10
    937c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9381:	4d 01 d0                                        	add    r8,r10
    9384:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9389:	4d 01 d0                                        	add    r8,r10
    938c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9391:	4d 01 d0                                        	add    r8,r10
    9394:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9399:	4d 01 d0                                        	add    r8,r10
    939c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    93a1:	4d 01 d0                                        	add    r8,r10
    93a4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    93a9:	4d 01 d0                                        	add    r8,r10
    93ac:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    93b1:	4d 01 d0                                        	add    r8,r10
    93b4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    93b9:	4d 01 d0                                        	add    r8,r10
    93bc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    93c1:	4d 01 d0                                        	add    r8,r10
    93c4:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    93c9:	4d 01 d0                                        	add    r8,r10
    93cc:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    93d1:	4d 01 d0                                        	add    r8,r10
    93d4:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    93d9:	4d 01 d0                                        	add    r8,r10
    93dc:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    93e1:	4d 01 d0                                        	add    r8,r10
    93e4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    93e9:	4d 01 d0                                        	add    r8,r10
    93ec:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    93f1:	4d 01 d0                                        	add    r8,r10
    93f4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    93f9:	4d 01 d0                                        	add    r8,r10
    93fc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9401:	4d 01 d0                                        	add    r8,r10
    9404:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9409:	4d 01 d0                                        	add    r8,r10
    940c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9411:	4d 01 d0                                        	add    r8,r10
    9414:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9419:	4d 01 d0                                        	add    r8,r10
    941c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9421:	4d 01 d0                                        	add    r8,r10
    9424:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9429:	4d 01 d0                                        	add    r8,r10
    942c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9431:	4d 01 d0                                        	add    r8,r10
    9434:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9439:	4d 01 d0                                        	add    r8,r10
    943c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9441:	4d 01 d0                                        	add    r8,r10
    9444:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9449:	4d 01 d0                                        	add    r8,r10
    944c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9451:	4d 01 d0                                        	add    r8,r10
    9454:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9459:	4d 01 d0                                        	add    r8,r10
    945c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9461:	4d 01 d0                                        	add    r8,r10
    9464:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9469:	4d 01 d0                                        	add    r8,r10
    946c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9471:	4d 01 d0                                        	add    r8,r10
    9474:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9479:	4d 01 d0                                        	add    r8,r10
    947c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9481:	4d 01 d0                                        	add    r8,r10
    9484:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9489:	4d 01 d0                                        	add    r8,r10
    948c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9491:	4d 01 d0                                        	add    r8,r10
    9494:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9499:	4d 01 d0                                        	add    r8,r10
    949c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    94a1:	4d 01 d0                                        	add    r8,r10
    94a4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    94a9:	4d 01 d0                                        	add    r8,r10
    94ac:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    94b1:	4d 01 d0                                        	add    r8,r10
    94b4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    94b9:	4d 01 d0                                        	add    r8,r10
    94bc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    94c1:	4d 01 d0                                        	add    r8,r10
    94c4:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    94c9:	4d 01 d0                                        	add    r8,r10
    94cc:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    94d1:	4d 01 d0                                        	add    r8,r10
    94d4:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    94d9:	4d 01 d0                                        	add    r8,r10
    94dc:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    94e1:	4d 01 d0                                        	add    r8,r10
    94e4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    94e9:	4d 01 d0                                        	add    r8,r10
    94ec:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    94f1:	4d 01 d0                                        	add    r8,r10
    94f4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    94f9:	4d 01 d0                                        	add    r8,r10
    94fc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9501:	4d 01 d0                                        	add    r8,r10
    9504:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9509:	4d 01 d0                                        	add    r8,r10
    950c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9511:	4d 01 d0                                        	add    r8,r10
    9514:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9519:	4d 01 d0                                        	add    r8,r10
    951c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9521:	4d 01 d0                                        	add    r8,r10
    9524:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9529:	4d 01 d0                                        	add    r8,r10
    952c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9531:	4d 01 d0                                        	add    r8,r10
    9534:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9539:	4d 01 d0                                        	add    r8,r10
    953c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9541:	4d 01 d0                                        	add    r8,r10
    9544:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9549:	4d 01 d0                                        	add    r8,r10
    954c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9551:	4d 01 d0                                        	add    r8,r10
    9554:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9559:	4d 01 d0                                        	add    r8,r10
    955c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9561:	4d 01 d0                                        	add    r8,r10
    9564:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9569:	4d 01 d0                                        	add    r8,r10
    956c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9571:	4d 01 d0                                        	add    r8,r10
    9574:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9579:	4d 01 d0                                        	add    r8,r10
    957c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9581:	4d 01 d0                                        	add    r8,r10
    9584:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9589:	4d 01 d0                                        	add    r8,r10
    958c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9591:	4d 01 d0                                        	add    r8,r10
    9594:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9599:	4d 01 d0                                        	add    r8,r10
    959c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    95a1:	4d 01 d0                                        	add    r8,r10
    95a4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    95a9:	4d 01 d0                                        	add    r8,r10
    95ac:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    95b1:	4d 01 d0                                        	add    r8,r10
    95b4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    95b9:	4d 01 d0                                        	add    r8,r10
    95bc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    95c1:	4d 01 d0                                        	add    r8,r10
    95c4:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    95c9:	4d 01 d0                                        	add    r8,r10
    95cc:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    95d1:	4d 01 d0                                        	add    r8,r10
    95d4:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    95d9:	4d 01 d0                                        	add    r8,r10
    95dc:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    95e1:	4d 01 d0                                        	add    r8,r10
    95e4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    95e9:	4d 01 d0                                        	add    r8,r10
    95ec:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    95f1:	4d 01 d0                                        	add    r8,r10
    95f4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    95f9:	4d 01 d0                                        	add    r8,r10
    95fc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9601:	4d 01 d0                                        	add    r8,r10
    9604:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9609:	4d 01 d0                                        	add    r8,r10
    960c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9611:	4d 01 d0                                        	add    r8,r10
    9614:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9619:	4d 01 d0                                        	add    r8,r10
    961c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9621:	4d 01 d0                                        	add    r8,r10
    9624:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9629:	4d 01 d0                                        	add    r8,r10
    962c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9631:	4d 01 d0                                        	add    r8,r10
    9634:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9639:	4d 01 d0                                        	add    r8,r10
    963c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9641:	4d 01 d0                                        	add    r8,r10
    9644:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9649:	4d 01 d0                                        	add    r8,r10
    964c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9651:	4d 01 d0                                        	add    r8,r10
    9654:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9659:	4d 01 d0                                        	add    r8,r10
    965c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9661:	4d 01 d0                                        	add    r8,r10
    9664:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9669:	4d 01 d0                                        	add    r8,r10
    966c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9671:	4d 01 d0                                        	add    r8,r10
    9674:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9679:	4d 01 d0                                        	add    r8,r10
    967c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9681:	4d 01 d0                                        	add    r8,r10
    9684:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9689:	4d 01 d0                                        	add    r8,r10
    968c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9691:	4d 01 d0                                        	add    r8,r10
    9694:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9699:	4d 01 d0                                        	add    r8,r10
    969c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    96a1:	4d 01 d0                                        	add    r8,r10
    96a4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    96a9:	4d 01 d0                                        	add    r8,r10
    96ac:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    96b1:	4d 01 d0                                        	add    r8,r10
    96b4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    96b9:	4d 01 d0                                        	add    r8,r10
    96bc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    96c1:	4d 01 d0                                        	add    r8,r10
    96c4:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    96c9:	4d 01 d0                                        	add    r8,r10
    96cc:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    96d1:	4d 01 d0                                        	add    r8,r10
    96d4:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    96d9:	4d 01 d0                                        	add    r8,r10
    96dc:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    96e1:	4d 01 d0                                        	add    r8,r10
    96e4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    96e9:	4d 01 d0                                        	add    r8,r10
    96ec:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    96f1:	4d 01 d0                                        	add    r8,r10
    96f4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    96f9:	4d 01 d0                                        	add    r8,r10
    96fc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9701:	4d 01 d0                                        	add    r8,r10
    9704:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9709:	4d 01 d0                                        	add    r8,r10
    970c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9711:	4d 01 d0                                        	add    r8,r10
    9714:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9719:	4d 01 d0                                        	add    r8,r10
    971c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9721:	4d 01 d0                                        	add    r8,r10
    9724:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9729:	4d 01 d0                                        	add    r8,r10
    972c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9731:	4d 01 d0                                        	add    r8,r10
    9734:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9739:	4d 01 d0                                        	add    r8,r10
    973c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9741:	4d 01 d0                                        	add    r8,r10
    9744:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9749:	4d 01 d0                                        	add    r8,r10
    974c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9751:	4d 01 d0                                        	add    r8,r10
    9754:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9759:	4d 01 d0                                        	add    r8,r10
    975c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9761:	4d 01 d0                                        	add    r8,r10
    9764:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9769:	4d 01 d0                                        	add    r8,r10
    976c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9771:	4d 01 d0                                        	add    r8,r10
    9774:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9779:	4d 01 d0                                        	add    r8,r10
    977c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9781:	4d 01 d0                                        	add    r8,r10
    9784:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9789:	4d 01 d0                                        	add    r8,r10
    978c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9791:	4d 01 d0                                        	add    r8,r10
    9794:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9799:	4d 01 d0                                        	add    r8,r10
    979c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    97a1:	4d 01 d0                                        	add    r8,r10
    97a4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    97a9:	4d 01 d0                                        	add    r8,r10
    97ac:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    97b1:	4d 01 d0                                        	add    r8,r10
    97b4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    97b9:	4d 01 d0                                        	add    r8,r10
    97bc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    97c1:	4d 01 d0                                        	add    r8,r10
    97c4:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    97c9:	4d 01 d0                                        	add    r8,r10
    97cc:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    97d1:	4d 01 d0                                        	add    r8,r10
    97d4:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    97d9:	4d 01 d0                                        	add    r8,r10
    97dc:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    97e1:	4d 01 d0                                        	add    r8,r10
    97e4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    97e9:	4d 01 d0                                        	add    r8,r10
    97ec:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    97f1:	4d 01 d0                                        	add    r8,r10
    97f4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    97f9:	4d 01 d0                                        	add    r8,r10
    97fc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9801:	4d 01 d0                                        	add    r8,r10
    9804:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9809:	4d 01 d0                                        	add    r8,r10
    980c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9811:	4d 01 d0                                        	add    r8,r10
    9814:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9819:	4d 01 d0                                        	add    r8,r10
    981c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9821:	4d 01 d0                                        	add    r8,r10
    9824:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9829:	4d 01 d0                                        	add    r8,r10
    982c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9831:	4d 01 d0                                        	add    r8,r10
    9834:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9839:	4d 01 d0                                        	add    r8,r10
    983c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9841:	4d 01 d0                                        	add    r8,r10
    9844:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9849:	4d 01 d0                                        	add    r8,r10
    984c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9851:	4d 01 d0                                        	add    r8,r10
    9854:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9859:	4d 01 d0                                        	add    r8,r10
    985c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9861:	4d 01 d0                                        	add    r8,r10
    9864:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9869:	4d 01 d0                                        	add    r8,r10
    986c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9871:	4d 01 d0                                        	add    r8,r10
    9874:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9879:	4d 01 d0                                        	add    r8,r10
    987c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9881:	4d 01 d0                                        	add    r8,r10
    9884:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9889:	4d 01 d0                                        	add    r8,r10
    988c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9891:	4d 01 d0                                        	add    r8,r10
    9894:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9899:	4d 01 d0                                        	add    r8,r10
    989c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    98a1:	4d 01 d0                                        	add    r8,r10
    98a4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    98a9:	4d 01 d0                                        	add    r8,r10
    98ac:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    98b1:	4d 01 d0                                        	add    r8,r10
    98b4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    98b9:	4d 01 d0                                        	add    r8,r10
    98bc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    98c1:	4d 01 d0                                        	add    r8,r10
    98c4:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    98c9:	4d 01 d0                                        	add    r8,r10
    98cc:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    98d1:	4d 01 d0                                        	add    r8,r10
    98d4:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    98d9:	4d 01 d0                                        	add    r8,r10
    98dc:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    98e1:	4d 01 d0                                        	add    r8,r10
    98e4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    98e9:	4d 01 d0                                        	add    r8,r10
    98ec:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    98f1:	4d 01 d0                                        	add    r8,r10
    98f4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    98f9:	4d 01 d0                                        	add    r8,r10
    98fc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9901:	4d 01 d0                                        	add    r8,r10
    9904:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9909:	4d 01 d0                                        	add    r8,r10
    990c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9911:	4d 01 d0                                        	add    r8,r10
    9914:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9919:	4d 01 d0                                        	add    r8,r10
    991c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9921:	4d 01 d0                                        	add    r8,r10
    9924:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9929:	4d 01 d0                                        	add    r8,r10
    992c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9931:	4d 01 d0                                        	add    r8,r10
    9934:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9939:	4d 01 d0                                        	add    r8,r10
    993c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9941:	4d 01 d0                                        	add    r8,r10
    9944:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9949:	4d 01 d0                                        	add    r8,r10
    994c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9951:	4d 01 d0                                        	add    r8,r10
    9954:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9959:	4d 01 d0                                        	add    r8,r10
    995c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9961:	4d 01 d0                                        	add    r8,r10
    9964:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9969:	4d 01 d0                                        	add    r8,r10
    996c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9971:	4d 01 d0                                        	add    r8,r10
    9974:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9979:	4d 01 d0                                        	add    r8,r10
    997c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9981:	4d 01 d0                                        	add    r8,r10
    9984:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9989:	4d 01 d0                                        	add    r8,r10
    998c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9991:	4d 01 d0                                        	add    r8,r10
    9994:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9999:	4d 01 d0                                        	add    r8,r10
    999c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    99a1:	4d 01 d0                                        	add    r8,r10
    99a4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    99a9:	4d 01 d0                                        	add    r8,r10
    99ac:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    99b1:	4d 01 d0                                        	add    r8,r10
    99b4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    99b9:	4d 01 d0                                        	add    r8,r10
    99bc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    99c1:	4d 01 d0                                        	add    r8,r10
    99c4:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    99c9:	4d 01 d0                                        	add    r8,r10
    99cc:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    99d1:	4d 01 d0                                        	add    r8,r10
    99d4:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    99d9:	4d 01 d0                                        	add    r8,r10
    99dc:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    99e1:	4d 01 d0                                        	add    r8,r10
    99e4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    99e9:	4d 01 d0                                        	add    r8,r10
    99ec:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    99f1:	4d 01 d0                                        	add    r8,r10
    99f4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    99f9:	4d 01 d0                                        	add    r8,r10
    99fc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9a01:	4d 01 d0                                        	add    r8,r10
    9a04:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9a09:	4d 01 d0                                        	add    r8,r10
    9a0c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9a11:	4d 01 d0                                        	add    r8,r10
    9a14:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9a19:	4d 01 d0                                        	add    r8,r10
    9a1c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9a21:	4d 01 d0                                        	add    r8,r10
    9a24:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9a29:	4d 01 d0                                        	add    r8,r10
    9a2c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9a31:	4d 01 d0                                        	add    r8,r10
    9a34:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9a39:	4d 01 d0                                        	add    r8,r10
    9a3c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9a41:	4d 01 d0                                        	add    r8,r10
    9a44:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9a49:	4d 01 d0                                        	add    r8,r10
    9a4c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9a51:	4d 01 d0                                        	add    r8,r10
    9a54:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9a59:	4d 01 d0                                        	add    r8,r10
    9a5c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9a61:	4d 01 d0                                        	add    r8,r10
    9a64:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9a69:	4d 01 d0                                        	add    r8,r10
    9a6c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9a71:	4d 01 d0                                        	add    r8,r10
    9a74:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9a79:	4d 01 d0                                        	add    r8,r10
    9a7c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9a81:	4d 01 d0                                        	add    r8,r10
    9a84:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9a89:	4d 01 d0                                        	add    r8,r10
    9a8c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9a91:	4d 01 d0                                        	add    r8,r10
    9a94:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9a99:	4d 01 d0                                        	add    r8,r10
    9a9c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9aa1:	4d 01 d0                                        	add    r8,r10
    9aa4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9aa9:	4d 01 d0                                        	add    r8,r10
    9aac:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9ab1:	4d 01 d0                                        	add    r8,r10
    9ab4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9ab9:	4d 01 d0                                        	add    r8,r10
    9abc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9ac1:	4d 01 d0                                        	add    r8,r10
    9ac4:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9ac9:	4d 01 d0                                        	add    r8,r10
    9acc:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9ad1:	4d 01 d0                                        	add    r8,r10
    9ad4:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9ad9:	4d 01 d0                                        	add    r8,r10
    9adc:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9ae1:	4d 01 d0                                        	add    r8,r10
    9ae4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9ae9:	4d 01 d0                                        	add    r8,r10
    9aec:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9af1:	4d 01 d0                                        	add    r8,r10
    9af4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9af9:	4d 01 d0                                        	add    r8,r10
    9afc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9b01:	4d 01 d0                                        	add    r8,r10
    9b04:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9b09:	4d 01 d0                                        	add    r8,r10
    9b0c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9b11:	4d 01 d0                                        	add    r8,r10
    9b14:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9b19:	4d 01 d0                                        	add    r8,r10
    9b1c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9b21:	4d 01 d0                                        	add    r8,r10
    9b24:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9b29:	4d 01 d0                                        	add    r8,r10
    9b2c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9b31:	4d 01 d0                                        	add    r8,r10
    9b34:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9b39:	4d 01 d0                                        	add    r8,r10
    9b3c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9b41:	4d 01 d0                                        	add    r8,r10
    9b44:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9b49:	4d 01 d0                                        	add    r8,r10
    9b4c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9b51:	4d 01 d0                                        	add    r8,r10
    9b54:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9b59:	4d 01 d0                                        	add    r8,r10
    9b5c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9b61:	4d 01 d0                                        	add    r8,r10
    9b64:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9b69:	4d 01 d0                                        	add    r8,r10
    9b6c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9b71:	4d 01 d0                                        	add    r8,r10
    9b74:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9b79:	4d 01 d0                                        	add    r8,r10
    9b7c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9b81:	4d 01 d0                                        	add    r8,r10
    9b84:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9b89:	4d 01 d0                                        	add    r8,r10
    9b8c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9b91:	4d 01 d0                                        	add    r8,r10
    9b94:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9b99:	4d 01 d0                                        	add    r8,r10
    9b9c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9ba1:	4d 01 d0                                        	add    r8,r10
    9ba4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9ba9:	4d 01 d0                                        	add    r8,r10
    9bac:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9bb1:	4d 01 d0                                        	add    r8,r10
    9bb4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9bb9:	4d 01 d0                                        	add    r8,r10
    9bbc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9bc1:	4d 01 d0                                        	add    r8,r10
    9bc4:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9bc9:	4d 01 d0                                        	add    r8,r10
    9bcc:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9bd1:	4d 01 d0                                        	add    r8,r10
    9bd4:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9bd9:	4d 01 d0                                        	add    r8,r10
    9bdc:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9be1:	4d 01 d0                                        	add    r8,r10
    9be4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9be9:	4d 01 d0                                        	add    r8,r10
    9bec:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9bf1:	4d 01 d0                                        	add    r8,r10
    9bf4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9bf9:	4d 01 d0                                        	add    r8,r10
    9bfc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9c01:	4d 01 d0                                        	add    r8,r10
    9c04:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9c09:	4d 01 d0                                        	add    r8,r10
    9c0c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9c11:	4d 01 d0                                        	add    r8,r10
    9c14:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9c19:	4d 01 d0                                        	add    r8,r10
    9c1c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9c21:	4d 01 d0                                        	add    r8,r10
    9c24:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9c29:	4d 01 d0                                        	add    r8,r10
    9c2c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9c31:	4d 01 d0                                        	add    r8,r10
    9c34:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9c39:	4d 01 d0                                        	add    r8,r10
    9c3c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9c41:	4d 01 d0                                        	add    r8,r10
    9c44:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9c49:	4d 01 d0                                        	add    r8,r10
    9c4c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9c51:	4d 01 d0                                        	add    r8,r10
    9c54:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9c59:	4d 01 d0                                        	add    r8,r10
    9c5c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9c61:	4d 01 d0                                        	add    r8,r10
    9c64:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9c69:	4d 01 d0                                        	add    r8,r10
    9c6c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9c71:	4d 01 d0                                        	add    r8,r10
    9c74:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9c79:	4d 01 d0                                        	add    r8,r10
    9c7c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9c81:	4d 01 d0                                        	add    r8,r10
    9c84:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9c89:	4d 01 d0                                        	add    r8,r10
    9c8c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9c91:	4d 01 d0                                        	add    r8,r10
    9c94:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9c99:	4d 01 d0                                        	add    r8,r10
    9c9c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9ca1:	4d 01 d0                                        	add    r8,r10
    9ca4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9ca9:	4d 01 d0                                        	add    r8,r10
    9cac:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9cb1:	4d 01 d0                                        	add    r8,r10
    9cb4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9cb9:	4d 01 d0                                        	add    r8,r10
    9cbc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9cc1:	4d 01 d0                                        	add    r8,r10
    9cc4:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9cc9:	4d 01 d0                                        	add    r8,r10
    9ccc:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9cd1:	4d 01 d0                                        	add    r8,r10
    9cd4:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9cd9:	4d 01 d0                                        	add    r8,r10
    9cdc:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9ce1:	4d 01 d0                                        	add    r8,r10
    9ce4:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9ce9:	4d 01 d0                                        	add    r8,r10
    9cec:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9cf1:	4d 01 d0                                        	add    r8,r10
    9cf4:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9cf9:	4d 01 d0                                        	add    r8,r10
    9cfc:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9d01:	4d 01 d0                                        	add    r8,r10
    9d04:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9d09:	4d 01 d0                                        	add    r8,r10
    9d0c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9d11:	4d 01 d0                                        	add    r8,r10
    9d14:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
    9d19:	4d 01 d0                                        	add    r8,r10
    9d1c:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
    9d21:	4d 01 d0                                        	add    r8,r10
    9d24:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
    9d29:	4d 01 d0                                        	add    r8,r10
    9d2c:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
    9d31:	4d 01 d0                                        	add    r8,r10
    9d34:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
    9d39:	4d 01 d0                                        	add    r8,r10
    9d3c:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
    9d41:	4d 01 d0                                        	add    r8,r10
    9d44:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
    9d49:	4d 01 d0                                        	add    r8,r10
    9d4c:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
    9d51:	4d 01 d0                                        	add    r8,r10
    9d54:	41 f6 c1 01                                     	test   r9b,0x1
    9d58:	75 09                                           	jne    9d63 <choose_7>
    9d5a:	4c 8d 15 0c 00 00 00                            	lea    r10,[rip+0xc]        # 9d6d <target_a_7>
    9d61:	eb 07                                           	jmp    9d6a <dispatch_7>

0000000000009d63 <choose_7>:
    9d63:	4c 8d 15 09 00 00 00                            	lea    r10,[rip+0x9]        # 9d73 <target_b_7>

0000000000009d6a <dispatch_7>:
    9d6a:	41 ff e2                                        	jmp    r10

0000000000009d6d <target_a_7>:
    9d6d:	49 83 c0 01                                     	add    r8,0x1
    9d71:	eb 04                                           	jmp    9d77 <join_7>

0000000000009d73 <target_b_7>:
    9d73:	49 83 c0 02                                     	add    r8,0x2

0000000000009d77 <join_7>:
    9d77:	4c 89 06                                        	mov    QWORD PTR [rsi],r8
    9d7a:	b8 02 00 00 00                                  	mov    eax,0x2
    9d7f:	c3                                              	ret

0000000000009d80 <bad>:
    9d80:	31 c0                                           	xor    eax,eax
    9d82:	c3                                              	ret
