
/workspaces/repository/kprog/fidelity/build-x86/scale/n100_ptr_indirect.native.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <entry>:
   0:	48 8b 37                                        	mov    rsi,QWORD PTR [rdi]
   3:	48 8b 57 08                                     	mov    rdx,QWORD PTR [rdi+0x8]
   7:	48 8d 46 10                                     	lea    rax,[rsi+0x10]
   b:	48 39 d0                                        	cmp    rax,rdx
   e:	0f 87 c7 01 00 00                               	ja     1db <bad>
  14:	44 0f b6 4e 08                                  	movzx  r9d,BYTE PTR [rsi+0x8]
  19:	41 b8 07 00 00 00                               	mov    r8d,0x7
  1f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
  24:	4d 01 d0                                        	add    r8,r10
  27:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
  2c:	4d 01 d0                                        	add    r8,r10
  2f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
  34:	4d 01 d0                                        	add    r8,r10
  37:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
  3c:	4d 01 d0                                        	add    r8,r10
  3f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
  44:	4d 01 d0                                        	add    r8,r10
  47:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
  4c:	4d 01 d0                                        	add    r8,r10
  4f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
  54:	4d 01 d0                                        	add    r8,r10
  57:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
  5c:	4d 01 d0                                        	add    r8,r10
  5f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
  64:	4d 01 d0                                        	add    r8,r10
  67:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
  6c:	4d 01 d0                                        	add    r8,r10
  6f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
  74:	4d 01 d0                                        	add    r8,r10
  77:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
  7c:	4d 01 d0                                        	add    r8,r10
  7f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
  84:	4d 01 d0                                        	add    r8,r10
  87:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
  8c:	4d 01 d0                                        	add    r8,r10
  8f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
  94:	4d 01 d0                                        	add    r8,r10
  97:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
  9c:	4d 01 d0                                        	add    r8,r10
  9f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
  a4:	4d 01 d0                                        	add    r8,r10
  a7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
  ac:	4d 01 d0                                        	add    r8,r10
  af:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
  b4:	4d 01 d0                                        	add    r8,r10
  b7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
  bc:	4d 01 d0                                        	add    r8,r10
  bf:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
  c4:	4d 01 d0                                        	add    r8,r10
  c7:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
  cc:	4d 01 d0                                        	add    r8,r10
  cf:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
  d4:	4d 01 d0                                        	add    r8,r10
  d7:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
  dc:	4d 01 d0                                        	add    r8,r10
  df:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
  e4:	4d 01 d0                                        	add    r8,r10
  e7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
  ec:	4d 01 d0                                        	add    r8,r10
  ef:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
  f4:	4d 01 d0                                        	add    r8,r10
  f7:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
  fc:	4d 01 d0                                        	add    r8,r10
  ff:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 104:	4d 01 d0                                        	add    r8,r10
 107:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 10c:	4d 01 d0                                        	add    r8,r10
 10f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 114:	4d 01 d0                                        	add    r8,r10
 117:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 11c:	4d 01 d0                                        	add    r8,r10
 11f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 124:	4d 01 d0                                        	add    r8,r10
 127:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 12c:	4d 01 d0                                        	add    r8,r10
 12f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 134:	4d 01 d0                                        	add    r8,r10
 137:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 13c:	4d 01 d0                                        	add    r8,r10
 13f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 144:	4d 01 d0                                        	add    r8,r10
 147:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 14c:	4d 01 d0                                        	add    r8,r10
 14f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 154:	4d 01 d0                                        	add    r8,r10
 157:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 15c:	4d 01 d0                                        	add    r8,r10
 15f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 164:	4d 01 d0                                        	add    r8,r10
 167:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 16c:	4d 01 d0                                        	add    r8,r10
 16f:	44 0f b6 56 0a                                  	movzx  r10d,BYTE PTR [rsi+0xa]
 174:	4d 01 d0                                        	add    r8,r10
 177:	44 0f b6 56 0b                                  	movzx  r10d,BYTE PTR [rsi+0xb]
 17c:	4d 01 d0                                        	add    r8,r10
 17f:	44 0f b6 56 0c                                  	movzx  r10d,BYTE PTR [rsi+0xc]
 184:	4d 01 d0                                        	add    r8,r10
 187:	44 0f b6 56 0d                                  	movzx  r10d,BYTE PTR [rsi+0xd]
 18c:	4d 01 d0                                        	add    r8,r10
 18f:	44 0f b6 56 0e                                  	movzx  r10d,BYTE PTR [rsi+0xe]
 194:	4d 01 d0                                        	add    r8,r10
 197:	44 0f b6 56 0f                                  	movzx  r10d,BYTE PTR [rsi+0xf]
 19c:	4d 01 d0                                        	add    r8,r10
 19f:	44 0f b6 56 08                                  	movzx  r10d,BYTE PTR [rsi+0x8]
 1a4:	4d 01 d0                                        	add    r8,r10
 1a7:	44 0f b6 56 09                                  	movzx  r10d,BYTE PTR [rsi+0x9]
 1ac:	4d 01 d0                                        	add    r8,r10
 1af:	41 f6 c1 01                                     	test   r9b,0x1
 1b3:	75 09                                           	jne    1be <choose_0>
 1b5:	4c 8d 15 0c 00 00 00                            	lea    r10,[rip+0xc]        # 1c8 <target_a_0>
 1bc:	eb 07                                           	jmp    1c5 <dispatch_0>

00000000000001be <choose_0>:
 1be:	4c 8d 15 09 00 00 00                            	lea    r10,[rip+0x9]        # 1ce <target_b_0>

00000000000001c5 <dispatch_0>:
 1c5:	41 ff e2                                        	jmp    r10

00000000000001c8 <target_a_0>:
 1c8:	49 83 c0 01                                     	add    r8,0x1
 1cc:	eb 04                                           	jmp    1d2 <join_0>

00000000000001ce <target_b_0>:
 1ce:	49 83 c0 02                                     	add    r8,0x2

00000000000001d2 <join_0>:
 1d2:	4c 89 06                                        	mov    QWORD PTR [rsi],r8
 1d5:	b8 02 00 00 00                                  	mov    eax,0x2
 1da:	c3                                              	ret

00000000000001db <bad>:
 1db:	31 c0                                           	xor    eax,eax
 1dd:	c3                                              	ret
