#define X86_SIM_USE_STATE_STRUCT
#include "/workspaces/.agent-state/kprog-lanes/F/scale-regref-width/snapshot/kprog/x86/x86_sim_local_bpf.h"

extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));

__attribute__((always_inline)) void fidelity_step_0(struct x86_sim_state *);
__attribute__((always_inline)) void fidelity_step_1(struct x86_sim_state *);
__attribute__((always_inline)) void fidelity_step_2(struct x86_sim_state *);
SEC("xdp")
int n10000_scalar_indirect_x86_sim_xdp(struct xdp_md *ctx)
{
	struct x86_sim_state state;
 X86_SIM_L_BIND_COMMON_STATE(&state);
 struct x86_sim_xdp_abi __x86_sim_abi = {.data=(void *)(long)ctx->data,.data_end=(void *)(long)ctx->data_end};
 state.skb_ctx=(void *)0; state.abi_kind=KPROG_ABI_KIND_XDP;
#define INIT_REG(REG, NAME) state.NAME.ptr=(void *)0; state.NAME##_tag=X86_SIM_TAG_SCALAR;
 X86_SIM_L_FOR_EACH_GPR(INIT_REG)
#undef INIT_REG
 state.cf=0;state.zf=0;state.sf=0;state.of=0;state.xmm0_lo=0;state.xmm0_hi=0;state.ret_addr=0;
 state.rdi.ptr=&__x86_sim_abi;state.rdi_tag=X86_SIM_TAG_ABI;
	/* 0x0: mov    rsi,QWORD PTR [rdi] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	/* 0x3: mov    rdx,QWORD PTR [rdi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
	/* 0x7: lea    rax,[rsi+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
	/* 0xb: cmp    rax,rdx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64);
	/* 0xe: ja     9d80 <bad> */
	X86_SIM_X86_JCC(X86_CC_A, 0xe, 0x9d80, x86_l_9d80);
	/* 0x14: movzx  r9d,BYTE PTR [rsi+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R9, X86_RSI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 8ULL);
	/* 0x19: mov    r8d,0x7 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 7ULL);
	/* 0x1f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x23: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x27: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x33: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x37: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x43: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x47: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x53: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x57: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x63: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x67: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x73: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x77: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x83: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x87: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x93: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x97: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xa3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xa7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xab: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xaf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xb3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xb7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xbb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xbf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xc3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xc7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xcb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xcf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xd3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xd7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xdb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xdf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xe3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xe7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xeb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xef: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xf3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xf7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xfb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xff: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x103: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x107: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x10b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x10f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x113: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x117: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x11b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x11f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x123: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x127: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x12b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x12f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x133: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x137: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x13b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x13f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x143: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x147: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x14b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x14f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x153: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x157: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x15b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x15f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x163: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x167: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x16b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x16f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x173: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x177: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x17b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x17f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x183: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x187: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x18b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x18f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x193: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x197: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x19b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x19f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1a3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1a7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1ab: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1af: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1b3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1b7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1bb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1bf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1c3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1c7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1cb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1cf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1d3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1d7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1db: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1df: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1e3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1e7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1eb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1ef: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1f3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1f7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1fb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1ff: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x203: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x207: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x20b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x20f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x213: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x217: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x21b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x21f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x223: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x227: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x22b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x22f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x233: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x237: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x23b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x23f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x243: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x247: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x24b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x24f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x253: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x257: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x25b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x25f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x263: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x267: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x26b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x26f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x273: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x277: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x27b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x27f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x283: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x287: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x28b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x28f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x293: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x297: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x29b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x29f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2a3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2a7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2ab: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2af: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2b3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2b7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2bb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2bf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2c3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2c7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2cb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2cf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2d3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2d7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2db: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2df: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2e3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2e7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2eb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2ef: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2f3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2f7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2fb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2ff: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x303: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x307: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x30b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x30f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x313: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x317: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x31b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x31f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x323: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x327: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x32b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x32f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x333: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x337: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x33b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x33f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x343: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x347: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x34b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x34f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x353: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x357: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x35b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x35f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x363: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x367: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x36b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x36f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x373: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x377: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x37b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x37f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x383: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x387: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x38b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x38f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x393: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x397: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x39b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x39f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3a3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3a7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3ab: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3af: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3b3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3b7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3bb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3bf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3c3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3c7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3cb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3cf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3d3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3d7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3db: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3df: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3e3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3e7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3eb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3ef: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3f3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3f7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3fb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3ff: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x403: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x407: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x40b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x40f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x413: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x417: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x41b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x41f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x423: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x427: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x42b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x42f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x433: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x437: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x43b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x43f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x443: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x447: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x44b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x44f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x453: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x457: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x45b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x45f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x463: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x467: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x46b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x46f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x473: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x477: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x47b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x47f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x483: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x487: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x48b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x48f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x493: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x497: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x49b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x49f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4a3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4a7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4ab: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4af: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4b3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4b7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4bb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4bf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4c3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4c7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4cb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4cf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4d3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4d7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4db: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4df: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4e3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4e7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4eb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4ef: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4f3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4f7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4fb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4ff: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x503: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x507: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x50b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x50f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x513: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x517: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x51b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x51f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x523: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x527: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x52b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x52f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x533: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x537: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x53b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x53f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x543: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x547: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x54b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x54f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x553: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x557: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x55b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x55f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x563: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x567: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x56b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x56f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x573: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x577: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x57b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x57f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x583: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x587: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x58b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x58f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x593: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x597: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x59b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x59f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5a3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5a7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5ab: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5af: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5b3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5b7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5bb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5bf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5c3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5c7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5cb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5cf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5d3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5d7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5db: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5df: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5e3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5e7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5eb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5ef: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5f3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5f7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5fb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5ff: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x603: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x607: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x60b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x60f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x613: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x617: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x61b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x61f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x623: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x627: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x62b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x62f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x633: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x637: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x63b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x63f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x643: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x647: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x64b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x64f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x653: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x657: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x65b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x65f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x663: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x667: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x66b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x66f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x673: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x677: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x67b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x67f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x683: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x687: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x68b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x68f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x693: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x697: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x69b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x69f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6a3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6a7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6ab: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6af: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6b3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6b7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6bb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6bf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6c3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6c7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6cb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6cf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6d3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6d7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6db: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6df: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6e3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6e7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6eb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6ef: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6f3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6f7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6fb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6ff: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x703: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x707: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x70b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x70f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x713: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x717: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x71b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x71f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x723: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x727: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x72b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x72f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x733: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x737: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x73b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x73f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x743: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x747: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x74b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x74f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x753: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x757: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x75b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x75f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x763: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x767: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x76b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x76f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x773: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x777: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x77b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x77f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x783: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x787: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x78b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x78f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x793: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x797: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x79b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x79f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7a3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7a7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7ab: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7af: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7b3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7b7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7bb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7bf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7c3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7c7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7cb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7cf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7d3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7d7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7db: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7df: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7e3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7e7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7eb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7ef: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7f3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7f7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7fb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7ff: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x803: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x807: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x80b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x80f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x813: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x817: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x81b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x81f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x823: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x827: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x82b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x82f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x833: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x837: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x83b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x83f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x843: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x847: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x84b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x84f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x853: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x857: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x85b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x85f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x863: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x867: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x86b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x86f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x873: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x877: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x87b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x87f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x883: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x887: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x88b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x88f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x893: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x897: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x89b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x89f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8a3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8a7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8ab: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8af: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8b3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8b7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8bb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8bf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8c3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8c7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8cb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8cf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8d3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8d7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8db: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8df: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8e3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8e7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8eb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8ef: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8f3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8f7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8fb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8ff: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x903: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x907: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x90b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x90f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x913: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x917: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x91b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x91f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x923: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x927: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x92b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x92f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x933: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x937: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x93b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x93f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x943: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x947: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x94b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x94f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x953: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x957: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x95b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x95f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x963: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x967: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x96b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x96f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x973: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x977: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x97b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x97f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x983: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x987: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x98b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x98f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x993: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x997: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x99b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x99f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9a3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9a7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9ab: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9af: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9b3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9b7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9bb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9bf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9c3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9c7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9cb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9cf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9d3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9d7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9db: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9df: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9e3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9e7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9eb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9ef: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9f3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9f7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9fb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9ff: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xa03: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xa07: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xa0b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xa0f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xa13: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xa17: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xa1b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xa1f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xa23: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xa27: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xa2b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xa2f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xa33: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xa37: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xa3b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xa3f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xa43: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xa47: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xa4b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xa4f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xa53: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xa57: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xa5b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xa5f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xa63: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xa67: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xa6b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xa6f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xa73: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xa77: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xa7b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xa7f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xa83: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xa87: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xa8b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xa8f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xa93: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xa97: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xa9b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xa9f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xaa3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xaa7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xaab: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xaaf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xab3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xab7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xabb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xabf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xac3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xac7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xacb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xacf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xad3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xad7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xadb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xadf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xae3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xae7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xaeb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xaef: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xaf3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xaf7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xafb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xaff: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xb03: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xb07: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xb0b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xb0f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xb13: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xb17: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xb1b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xb1f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xb23: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xb27: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xb2b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xb2f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xb33: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xb37: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xb3b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xb3f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xb43: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xb47: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xb4b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xb4f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xb53: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xb57: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xb5b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xb5f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xb63: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xb67: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xb6b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xb6f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xb73: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xb77: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xb7b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xb7f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xb83: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xb87: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xb8b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xb8f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xb93: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xb97: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xb9b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xb9f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xba3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xba7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xbab: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xbaf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xbb3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xbb7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xbbb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xbbf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xbc3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xbc7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xbcb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xbcf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xbd3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xbd7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xbdb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xbdf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xbe3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xbe7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xbeb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xbef: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xbf3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xbf7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xbfb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xbff: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xc03: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xc07: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xc0b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xc0f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xc13: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xc17: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xc1b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xc1f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xc23: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xc27: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xc2b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xc2f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xc33: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xc37: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xc3b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xc3f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xc43: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xc47: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xc4b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xc4f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xc53: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xc57: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xc5b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xc5f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xc63: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xc67: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xc6b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xc6f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xc73: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xc77: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xc7b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xc7f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xc83: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xc87: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xc8b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xc8f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xc93: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xc97: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xc9b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xc9f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xca3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xca7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xcab: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xcaf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xcb3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xcb7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xcbb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xcbf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xcc3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xcc7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xccb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xccf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xcd3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xcd7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xcdb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xcdf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xce3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xce7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xceb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xcef: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xcf3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xcf7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xcfb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xcff: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xd03: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xd07: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xd0b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xd0f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xd13: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xd17: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xd1b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xd1f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xd23: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xd27: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xd2b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xd2f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xd33: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xd37: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xd3b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xd3f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xd43: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xd47: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xd4b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xd4f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xd53: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xd57: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xd5b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xd5f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xd63: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xd67: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xd6b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xd6f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xd73: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xd77: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xd7b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xd7f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xd83: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xd87: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xd8b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xd8f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xd93: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xd97: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xd9b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xd9f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xda3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xda7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xdab: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xdaf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xdb3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xdb7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xdbb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xdbf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xdc3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xdc7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xdcb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xdcf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xdd3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xdd7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xddb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xddf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xde3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xde7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xdeb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xdef: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xdf3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xdf7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xdfb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xdff: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xe03: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xe07: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xe0b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xe0f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xe13: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xe17: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xe1b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xe1f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xe23: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xe27: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xe2b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xe2f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xe33: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xe37: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xe3b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xe3f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xe43: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xe47: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xe4b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xe4f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xe53: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xe57: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xe5b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xe5f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xe63: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xe67: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xe6b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xe6f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xe73: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xe77: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xe7b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xe7f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xe83: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xe87: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xe8b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xe8f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xe93: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xe97: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xe9b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xe9f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xea3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xea7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xeab: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xeaf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xeb3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xeb7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xebb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xebf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xec3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xec7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xecb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xecf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xed3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xed7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xedb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xedf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xee3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xee7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xeeb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xeef: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xef3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xef7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xefb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xeff: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xf03: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xf07: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xf0b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xf0f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xf13: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xf17: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xf1b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xf1f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xf23: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xf27: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xf2b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xf2f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xf33: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xf37: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xf3b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xf3f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xf43: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xf47: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xf4b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xf4f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xf53: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xf57: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xf5b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xf5f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xf63: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xf67: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xf6b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xf6f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xf73: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xf77: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xf7b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xf7f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xf83: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xf87: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xf8b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xf8f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xf93: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xf97: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xf9b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xf9f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xfa3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xfa7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xfab: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xfaf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xfb3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xfb7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xfbb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xfbf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xfc3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xfc7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xfcb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xfcf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xfd3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xfd7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xfdb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xfdf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xfe3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xfe7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xfeb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xfef: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xff3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xff7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0xffb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0xfff: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1003: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1007: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x100b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x100f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1013: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1017: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x101b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x101f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1023: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1027: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x102b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x102f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1033: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1037: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x103b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x103f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1043: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1047: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x104b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x104f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1053: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1057: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x105b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x105f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1063: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1067: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x106b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x106f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1073: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1077: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x107b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x107f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1083: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1087: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x108b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x108f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1093: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1097: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x109b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x109f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x10a3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x10a7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x10ab: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x10af: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x10b3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x10b7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x10bb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x10bf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x10c3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x10c7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x10cb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x10cf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x10d3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x10d7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x10db: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x10df: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x10e3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x10e7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x10eb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x10ef: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x10f3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x10f7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x10fb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x10ff: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1103: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1107: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x110b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x110f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1113: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1117: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x111b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x111f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1123: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1127: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x112b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x112f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1133: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1137: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x113b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x113f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1143: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1147: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x114b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x114f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1153: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1157: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x115b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x115f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1163: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1167: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x116b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x116f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1173: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1177: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x117b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x117f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1183: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1187: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x118b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x118f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1193: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1197: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x119b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x119f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x11a3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x11a7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x11ab: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x11af: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x11b3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x11b7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x11bb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x11bf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x11c3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x11c7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x11cb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x11cf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x11d3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x11d7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x11db: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x11df: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x11e3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x11e7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x11eb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x11ef: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x11f3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x11f7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x11fb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x11ff: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1203: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1207: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x120b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x120f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1213: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1217: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x121b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x121f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1223: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1227: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x122b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x122f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1233: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1237: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x123b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x123f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1243: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1247: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x124b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x124f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1253: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1257: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x125b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x125f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1263: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1267: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x126b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x126f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1273: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1277: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x127b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x127f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1283: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1287: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x128b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x128f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1293: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1297: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x129b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x129f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x12a3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x12a7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x12ab: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x12af: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x12b3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x12b7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x12bb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x12bf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x12c3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x12c7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x12cb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x12cf: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x12d3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x12d7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x12db: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x12df: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x12e3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x12e7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x12eb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x12ef: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x12f3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x12f7: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x12fb: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x12ff: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1303: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1307: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x130b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x130f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1313: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1317: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x131b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x131f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1323: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1327: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x132b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x132f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1333: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1337: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x133b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x133f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1343: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1347: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x134b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x134f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1353: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1357: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x135b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x135f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1363: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1367: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x136b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x136f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1373: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1377: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x137b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x137f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1383: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1387: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x138b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x138f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1393: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1397: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x139b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x139f: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x13a3: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x13a7: test   r9b,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_TEST_IMM, X86_R9, X86_WIDTH_8, 1ULL);
	/* 0x13ab: jne    13b6 <choose_0> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x13ab, 0x13b6, x86_l_13b6);
	/* 0x13ad: lea    r10,[rip+0xc] */
	X86_SIM_X86_CODE_ADDRESS(X86_R10, 0x13c0ULL);
	/* 0x13b4: jmp    13bd <dispatch_0> */
	X86_SIM_X86_JMP(0x13b4, 0x13bd, x86_l_13bd);
x86_l_13b6:
	/* 0x13b6: lea    r10,[rip+0x9] */
	X86_SIM_X86_CODE_ADDRESS(X86_R10, 0x13c6ULL);
x86_l_13bd:
	/* 0x13bd: jmp    r10 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R10);
		switch (X86_SIM_L_REG_TAG(X86_R10)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x13c0ULL: goto x86_l_13c0;
			case 0x13c6ULL: goto x86_l_13c6;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_13c0:
	/* 0x13c0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x13c4: jmp    13ca <join_0> */
	X86_SIM_X86_JMP(0x13c4, 0x13ca, x86_l_13ca);
x86_l_13c6:
	/* 0x13c6: add    r8,0x2 */
	fidelity_step_1(__x86_state);
x86_l_13ca:
	/* 0x13ca: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x13ce: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x13d2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x13d6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x13da: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x13de: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x13e2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x13e6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x13ea: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x13ee: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x13f2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x13f6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x13fa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x13fe: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1402: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1406: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x140a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x140e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1412: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1416: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x141a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x141e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1422: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1426: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x142a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x142e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1432: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1436: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x143a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x143e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1442: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1446: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x144a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x144e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1452: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1456: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x145a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x145e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1462: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1466: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x146a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x146e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1472: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1476: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x147a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x147e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1482: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1486: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x148a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x148e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1492: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1496: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x149a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x149e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x14a2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x14a6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x14aa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x14ae: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x14b2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x14b6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x14ba: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x14be: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x14c2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x14c6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x14ca: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x14ce: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x14d2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x14d6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x14da: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x14de: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x14e2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x14e6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x14ea: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x14ee: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x14f2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x14f6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x14fa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x14fe: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1502: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1506: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x150a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x150e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1512: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1516: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x151a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x151e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1522: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1526: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x152a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x152e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1532: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1536: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x153a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x153e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1542: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1546: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x154a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x154e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1552: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1556: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x155a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x155e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1562: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1566: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x156a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x156e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1572: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1576: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x157a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x157e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1582: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1586: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x158a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x158e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1592: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1596: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x159a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x159e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x15a2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x15a6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x15aa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x15ae: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x15b2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x15b6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x15ba: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x15be: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x15c2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x15c6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x15ca: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x15ce: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x15d2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x15d6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x15da: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x15de: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x15e2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x15e6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x15ea: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x15ee: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x15f2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x15f6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x15fa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x15fe: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1602: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1606: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x160a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x160e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1612: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1616: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x161a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x161e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1622: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1626: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x162a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x162e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1632: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1636: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x163a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x163e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1642: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1646: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x164a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x164e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1652: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1656: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x165a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x165e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1662: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1666: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x166a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x166e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1672: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1676: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x167a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x167e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1682: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1686: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x168a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x168e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1692: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1696: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x169a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x169e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x16a2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x16a6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x16aa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x16ae: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x16b2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x16b6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x16ba: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x16be: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x16c2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x16c6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x16ca: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x16ce: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x16d2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x16d6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x16da: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x16de: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x16e2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x16e6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x16ea: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x16ee: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x16f2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x16f6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x16fa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x16fe: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1702: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1706: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x170a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x170e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1712: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1716: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x171a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x171e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1722: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1726: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x172a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x172e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1732: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1736: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x173a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x173e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1742: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1746: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x174a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x174e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1752: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1756: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x175a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x175e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1762: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1766: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x176a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x176e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1772: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1776: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x177a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x177e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1782: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1786: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x178a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x178e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1792: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1796: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x179a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x179e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x17a2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x17a6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x17aa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x17ae: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x17b2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x17b6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x17ba: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x17be: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x17c2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x17c6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x17ca: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x17ce: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x17d2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x17d6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x17da: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x17de: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x17e2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x17e6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x17ea: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x17ee: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x17f2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x17f6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x17fa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x17fe: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1802: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1806: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x180a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x180e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1812: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1816: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x181a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x181e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1822: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1826: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x182a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x182e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1832: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1836: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x183a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x183e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1842: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1846: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x184a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x184e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1852: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1856: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x185a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x185e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1862: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1866: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x186a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x186e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1872: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1876: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x187a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x187e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1882: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1886: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x188a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x188e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1892: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1896: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x189a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x189e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x18a2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x18a6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x18aa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x18ae: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x18b2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x18b6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x18ba: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x18be: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x18c2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x18c6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x18ca: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x18ce: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x18d2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x18d6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x18da: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x18de: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x18e2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x18e6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x18ea: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x18ee: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x18f2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x18f6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x18fa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x18fe: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1902: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1906: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x190a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x190e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1912: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1916: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x191a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x191e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1922: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1926: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x192a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x192e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1932: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1936: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x193a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x193e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1942: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1946: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x194a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x194e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1952: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1956: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x195a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x195e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1962: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1966: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x196a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x196e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1972: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1976: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x197a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x197e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1982: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1986: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x198a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x198e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1992: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1996: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x199a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x199e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x19a2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x19a6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x19aa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x19ae: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x19b2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x19b6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x19ba: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x19be: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x19c2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x19c6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x19ca: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x19ce: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x19d2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x19d6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x19da: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x19de: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x19e2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x19e6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x19ea: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x19ee: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x19f2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x19f6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x19fa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x19fe: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1a02: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1a06: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1a0a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1a0e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1a12: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1a16: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1a1a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1a1e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1a22: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1a26: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1a2a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1a2e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1a32: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1a36: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1a3a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1a3e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1a42: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1a46: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1a4a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1a4e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1a52: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1a56: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1a5a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1a5e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1a62: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1a66: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1a6a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1a6e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1a72: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1a76: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1a7a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1a7e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1a82: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1a86: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1a8a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1a8e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1a92: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1a96: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1a9a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1a9e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1aa2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1aa6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1aaa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1aae: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1ab2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1ab6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1aba: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1abe: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1ac2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1ac6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1aca: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1ace: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1ad2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1ad6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1ada: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1ade: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1ae2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1ae6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1aea: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1aee: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1af2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1af6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1afa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1afe: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1b02: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1b06: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1b0a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1b0e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1b12: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1b16: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1b1a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1b1e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1b22: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1b26: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1b2a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1b2e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1b32: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1b36: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1b3a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1b3e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1b42: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1b46: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1b4a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1b4e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1b52: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1b56: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1b5a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1b5e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1b62: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1b66: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1b6a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1b6e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1b72: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1b76: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1b7a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1b7e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1b82: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1b86: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1b8a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1b8e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1b92: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1b96: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1b9a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1b9e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1ba2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1ba6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1baa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1bae: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1bb2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1bb6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1bba: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1bbe: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1bc2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1bc6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1bca: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1bce: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1bd2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1bd6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1bda: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1bde: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1be2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1be6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1bea: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1bee: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1bf2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1bf6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1bfa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1bfe: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1c02: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1c06: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1c0a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1c0e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1c12: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1c16: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1c1a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1c1e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1c22: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1c26: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1c2a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1c2e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1c32: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1c36: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1c3a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1c3e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1c42: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1c46: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1c4a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1c4e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1c52: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1c56: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1c5a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1c5e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1c62: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1c66: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1c6a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1c6e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1c72: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1c76: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1c7a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1c7e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1c82: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1c86: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1c8a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1c8e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1c92: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1c96: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1c9a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1c9e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1ca2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1ca6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1caa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1cae: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1cb2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1cb6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1cba: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1cbe: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1cc2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1cc6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1cca: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1cce: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1cd2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1cd6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1cda: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1cde: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1ce2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1ce6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1cea: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1cee: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1cf2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1cf6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1cfa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1cfe: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1d02: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1d06: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1d0a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1d0e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1d12: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1d16: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1d1a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1d1e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1d22: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1d26: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1d2a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1d2e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1d32: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1d36: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1d3a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1d3e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1d42: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1d46: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1d4a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1d4e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1d52: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1d56: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1d5a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1d5e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1d62: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1d66: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1d6a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1d6e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1d72: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1d76: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1d7a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1d7e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1d82: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1d86: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1d8a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1d8e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1d92: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1d96: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1d9a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1d9e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1da2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1da6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1daa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1dae: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1db2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1db6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1dba: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1dbe: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1dc2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1dc6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1dca: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1dce: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1dd2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1dd6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1dda: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1dde: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1de2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1de6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1dea: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1dee: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1df2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1df6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1dfa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1dfe: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1e02: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1e06: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1e0a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1e0e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1e12: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1e16: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1e1a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1e1e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1e22: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1e26: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1e2a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1e2e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1e32: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1e36: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1e3a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1e3e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1e42: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1e46: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1e4a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1e4e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1e52: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1e56: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1e5a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1e5e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1e62: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1e66: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1e6a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1e6e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1e72: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1e76: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1e7a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1e7e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1e82: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1e86: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1e8a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1e8e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1e92: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1e96: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1e9a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1e9e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1ea2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1ea6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1eaa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1eae: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1eb2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1eb6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1eba: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1ebe: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1ec2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1ec6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1eca: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1ece: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1ed2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1ed6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1eda: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1ede: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1ee2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1ee6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1eea: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1eee: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1ef2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1ef6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1efa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1efe: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1f02: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1f06: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1f0a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1f0e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1f12: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1f16: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1f1a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1f1e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1f22: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1f26: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1f2a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1f2e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1f32: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1f36: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1f3a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1f3e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1f42: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1f46: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1f4a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1f4e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1f52: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1f56: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1f5a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1f5e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1f62: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1f66: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1f6a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1f6e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1f72: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1f76: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1f7a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1f7e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1f82: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1f86: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1f8a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1f8e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1f92: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1f96: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1f9a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1f9e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1fa2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1fa6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1faa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1fae: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1fb2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1fb6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1fba: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1fbe: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1fc2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1fc6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1fca: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1fce: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1fd2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1fd6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1fda: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1fde: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1fe2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1fe6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1fea: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1fee: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1ff2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1ff6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x1ffa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x1ffe: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2002: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2006: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x200a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x200e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2012: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2016: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x201a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x201e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2022: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2026: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x202a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x202e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2032: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2036: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x203a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x203e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2042: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2046: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x204a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x204e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2052: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2056: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x205a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x205e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2062: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2066: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x206a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x206e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2072: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2076: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x207a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x207e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2082: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2086: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x208a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x208e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2092: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2096: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x209a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x209e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x20a2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x20a6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x20aa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x20ae: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x20b2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x20b6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x20ba: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x20be: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x20c2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x20c6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x20ca: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x20ce: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x20d2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x20d6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x20da: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x20de: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x20e2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x20e6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x20ea: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x20ee: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x20f2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x20f6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x20fa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x20fe: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2102: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2106: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x210a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x210e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2112: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2116: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x211a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x211e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2122: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2126: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x212a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x212e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2132: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2136: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x213a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x213e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2142: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2146: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x214a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x214e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2152: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2156: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x215a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x215e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2162: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2166: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x216a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x216e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2172: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2176: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x217a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x217e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2182: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2186: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x218a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x218e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2192: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2196: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x219a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x219e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x21a2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x21a6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x21aa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x21ae: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x21b2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x21b6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x21ba: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x21be: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x21c2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x21c6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x21ca: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x21ce: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x21d2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x21d6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x21da: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x21de: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x21e2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x21e6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x21ea: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x21ee: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x21f2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x21f6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x21fa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x21fe: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2202: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2206: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x220a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x220e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2212: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2216: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x221a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x221e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2222: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2226: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x222a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x222e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2232: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2236: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x223a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x223e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2242: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2246: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x224a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x224e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2252: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2256: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x225a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x225e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2262: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2266: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x226a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x226e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2272: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2276: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x227a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x227e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2282: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2286: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x228a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x228e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2292: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2296: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x229a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x229e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x22a2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x22a6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x22aa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x22ae: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x22b2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x22b6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x22ba: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x22be: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x22c2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x22c6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x22ca: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x22ce: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x22d2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x22d6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x22da: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x22de: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x22e2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x22e6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x22ea: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x22ee: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x22f2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x22f6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x22fa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x22fe: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2302: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2306: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x230a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x230e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2312: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2316: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x231a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x231e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2322: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2326: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x232a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x232e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2332: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2336: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x233a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x233e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2342: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2346: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x234a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x234e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2352: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2356: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x235a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x235e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2362: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2366: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x236a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x236e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2372: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2376: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x237a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x237e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2382: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2386: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x238a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x238e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2392: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2396: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x239a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x239e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x23a2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x23a6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x23aa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x23ae: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x23b2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x23b6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x23ba: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x23be: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x23c2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x23c6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x23ca: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x23ce: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x23d2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x23d6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x23da: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x23de: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x23e2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x23e6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x23ea: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x23ee: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x23f2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x23f6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x23fa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x23fe: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2402: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2406: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x240a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x240e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2412: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2416: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x241a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x241e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2422: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2426: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x242a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x242e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2432: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2436: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x243a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x243e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2442: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2446: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x244a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x244e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2452: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2456: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x245a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x245e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2462: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2466: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x246a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x246e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2472: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2476: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x247a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x247e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2482: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2486: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x248a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x248e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2492: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2496: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x249a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x249e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x24a2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x24a6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x24aa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x24ae: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x24b2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x24b6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x24ba: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x24be: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x24c2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x24c6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x24ca: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x24ce: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x24d2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x24d6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x24da: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x24de: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x24e2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x24e6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x24ea: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x24ee: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x24f2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x24f6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x24fa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x24fe: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2502: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2506: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x250a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x250e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2512: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2516: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x251a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x251e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2522: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2526: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x252a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x252e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2532: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2536: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x253a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x253e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2542: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2546: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x254a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x254e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2552: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2556: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x255a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x255e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2562: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2566: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x256a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x256e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2572: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2576: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x257a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x257e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2582: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2586: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x258a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x258e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2592: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2596: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x259a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x259e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x25a2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x25a6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x25aa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x25ae: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x25b2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x25b6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x25ba: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x25be: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x25c2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x25c6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x25ca: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x25ce: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x25d2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x25d6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x25da: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x25de: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x25e2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x25e6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x25ea: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x25ee: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x25f2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x25f6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x25fa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x25fe: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2602: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2606: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x260a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x260e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2612: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2616: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x261a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x261e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2622: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2626: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x262a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x262e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2632: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2636: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x263a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x263e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2642: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2646: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x264a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x264e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2652: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2656: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x265a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x265e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2662: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2666: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x266a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x266e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2672: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2676: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x267a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x267e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2682: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2686: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x268a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x268e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2692: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2696: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x269a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x269e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x26a2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x26a6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x26aa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x26ae: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x26b2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x26b6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x26ba: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x26be: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x26c2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x26c6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x26ca: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x26ce: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x26d2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x26d6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x26da: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x26de: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x26e2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x26e6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x26ea: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x26ee: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x26f2: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x26f6: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x26fa: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x26fe: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2702: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2706: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x270a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x270e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2712: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2716: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x271a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x271e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2722: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2726: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x272a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x272e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2732: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2736: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x273a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x273e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2742: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2746: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x274a: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x274e: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2752: test   r9b,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_TEST_IMM, X86_R9, X86_WIDTH_8, 1ULL);
	/* 0x2756: jne    2761 <choose_1> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2756, 0x2761, x86_l_2761);
	/* 0x2758: lea    r10,[rip+0xc] */
	X86_SIM_X86_CODE_ADDRESS(X86_R10, 0x276bULL);
	/* 0x275f: jmp    2768 <dispatch_1> */
	X86_SIM_X86_JMP(0x275f, 0x2768, x86_l_2768);
x86_l_2761:
	/* 0x2761: lea    r10,[rip+0x9] */
	X86_SIM_X86_CODE_ADDRESS(X86_R10, 0x2771ULL);
x86_l_2768:
	/* 0x2768: jmp    r10 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R10);
		switch (X86_SIM_L_REG_TAG(X86_R10)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x276bULL: goto x86_l_276b;
			case 0x2771ULL: goto x86_l_2771;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_276b:
	/* 0x276b: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x276f: jmp    2775 <join_1> */
	X86_SIM_X86_JMP(0x276f, 0x2775, x86_l_2775);
x86_l_2771:
	/* 0x2771: add    r8,0x2 */
	fidelity_step_1(__x86_state);
x86_l_2775:
	/* 0x2775: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2779: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x277d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2781: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2785: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2789: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x278d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2791: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2795: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2799: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x279d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x27a1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x27a5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x27a9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x27ad: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x27b1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x27b5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x27b9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x27bd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x27c1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x27c5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x27c9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x27cd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x27d1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x27d5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x27d9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x27dd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x27e1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x27e5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x27e9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x27ed: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x27f1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x27f5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x27f9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x27fd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2801: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2805: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2809: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x280d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2811: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2815: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2819: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x281d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2821: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2825: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2829: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x282d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2831: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2835: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2839: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x283d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2841: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2845: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2849: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x284d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2851: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2855: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2859: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x285d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2861: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2865: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2869: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x286d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2871: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2875: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2879: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x287d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2881: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2885: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2889: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x288d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2891: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2895: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2899: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x289d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x28a1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x28a5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x28a9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x28ad: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x28b1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x28b5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x28b9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x28bd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x28c1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x28c5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x28c9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x28cd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x28d1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x28d5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x28d9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x28dd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x28e1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x28e5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x28e9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x28ed: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x28f1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x28f5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x28f9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x28fd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2901: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2905: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2909: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x290d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2911: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2915: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2919: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x291d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2921: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2925: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2929: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x292d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2931: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2935: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2939: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x293d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2941: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2945: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2949: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x294d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2951: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2955: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2959: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x295d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2961: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2965: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2969: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x296d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2971: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2975: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2979: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x297d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2981: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2985: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2989: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x298d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2991: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2995: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2999: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x299d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x29a1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x29a5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x29a9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x29ad: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x29b1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x29b5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x29b9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x29bd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x29c1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x29c5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x29c9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x29cd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x29d1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x29d5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x29d9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x29dd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x29e1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x29e5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x29e9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x29ed: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x29f1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x29f5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x29f9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x29fd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2a01: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2a05: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2a09: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2a0d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2a11: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2a15: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2a19: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2a1d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2a21: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2a25: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2a29: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2a2d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2a31: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2a35: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2a39: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2a3d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2a41: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2a45: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2a49: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2a4d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2a51: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2a55: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2a59: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2a5d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2a61: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2a65: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2a69: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2a6d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2a71: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2a75: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2a79: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2a7d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2a81: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2a85: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2a89: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2a8d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2a91: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2a95: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2a99: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2a9d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2aa1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2aa5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2aa9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2aad: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2ab1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2ab5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2ab9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2abd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2ac1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2ac5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2ac9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2acd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2ad1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2ad5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2ad9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2add: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2ae1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2ae5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2ae9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2aed: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2af1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2af5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2af9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2afd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2b01: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2b05: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2b09: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2b0d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2b11: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2b15: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2b19: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2b1d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2b21: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2b25: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2b29: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2b2d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2b31: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2b35: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2b39: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2b3d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2b41: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2b45: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2b49: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2b4d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2b51: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2b55: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2b59: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2b5d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2b61: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2b65: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2b69: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2b6d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2b71: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2b75: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2b79: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2b7d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2b81: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2b85: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2b89: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2b8d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2b91: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2b95: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2b99: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2b9d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2ba1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2ba5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2ba9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2bad: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2bb1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2bb5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2bb9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2bbd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2bc1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2bc5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2bc9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2bcd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2bd1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2bd5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2bd9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2bdd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2be1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2be5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2be9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2bed: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2bf1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2bf5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2bf9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2bfd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2c01: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2c05: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2c09: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2c0d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2c11: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2c15: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2c19: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2c1d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2c21: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2c25: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2c29: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2c2d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2c31: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2c35: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2c39: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2c3d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2c41: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2c45: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2c49: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2c4d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2c51: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2c55: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2c59: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2c5d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2c61: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2c65: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2c69: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2c6d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2c71: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2c75: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2c79: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2c7d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2c81: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2c85: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2c89: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2c8d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2c91: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2c95: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2c99: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2c9d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2ca1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2ca5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2ca9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2cad: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2cb1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2cb5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2cb9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2cbd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2cc1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2cc5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2cc9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2ccd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2cd1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2cd5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2cd9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2cdd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2ce1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2ce5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2ce9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2ced: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2cf1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2cf5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2cf9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2cfd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2d01: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2d05: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2d09: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2d0d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2d11: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2d15: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2d19: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2d1d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2d21: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2d25: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2d29: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2d2d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2d31: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2d35: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2d39: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2d3d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2d41: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2d45: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2d49: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2d4d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2d51: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2d55: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2d59: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2d5d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2d61: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2d65: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2d69: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2d6d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2d71: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2d75: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2d79: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2d7d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2d81: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2d85: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2d89: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2d8d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2d91: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2d95: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2d99: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2d9d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2da1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2da5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2da9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2dad: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2db1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2db5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2db9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2dbd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2dc1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2dc5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2dc9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2dcd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2dd1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2dd5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2dd9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2ddd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2de1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2de5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2de9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2ded: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2df1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2df5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2df9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2dfd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2e01: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2e05: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2e09: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2e0d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2e11: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2e15: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2e19: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2e1d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2e21: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2e25: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2e29: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2e2d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2e31: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2e35: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2e39: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2e3d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2e41: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2e45: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2e49: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2e4d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2e51: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2e55: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2e59: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2e5d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2e61: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2e65: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2e69: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2e6d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2e71: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2e75: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2e79: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2e7d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2e81: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2e85: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2e89: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2e8d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2e91: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2e95: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2e99: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2e9d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2ea1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2ea5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2ea9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2ead: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2eb1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2eb5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2eb9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2ebd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2ec1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2ec5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2ec9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2ecd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2ed1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2ed5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2ed9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2edd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2ee1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2ee5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2ee9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2eed: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2ef1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2ef5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2ef9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2efd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2f01: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2f05: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2f09: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2f0d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2f11: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2f15: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2f19: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2f1d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2f21: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2f25: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2f29: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2f2d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2f31: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2f35: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2f39: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2f3d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2f41: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2f45: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2f49: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2f4d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2f51: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2f55: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2f59: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2f5d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2f61: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2f65: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2f69: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2f6d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2f71: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2f75: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2f79: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2f7d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2f81: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2f85: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2f89: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2f8d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2f91: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2f95: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2f99: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2f9d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2fa1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2fa5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2fa9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2fad: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2fb1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2fb5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2fb9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2fbd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2fc1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2fc5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2fc9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2fcd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2fd1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2fd5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2fd9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2fdd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2fe1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2fe5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2fe9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2fed: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2ff1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2ff5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x2ff9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x2ffd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3001: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3005: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3009: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x300d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3011: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3015: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3019: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x301d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3021: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3025: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3029: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x302d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3031: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3035: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3039: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x303d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3041: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3045: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3049: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x304d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3051: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3055: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3059: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x305d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3061: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3065: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3069: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x306d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3071: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3075: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3079: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x307d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3081: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3085: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3089: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x308d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3091: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3095: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3099: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x309d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x30a1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x30a5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x30a9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x30ad: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x30b1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x30b5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x30b9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x30bd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x30c1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x30c5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x30c9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x30cd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x30d1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x30d5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x30d9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x30dd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x30e1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x30e5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x30e9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x30ed: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x30f1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x30f5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x30f9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x30fd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3101: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3105: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3109: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x310d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3111: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3115: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3119: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x311d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3121: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3125: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3129: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x312d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3131: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3135: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3139: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x313d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3141: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3145: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3149: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x314d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3151: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3155: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3159: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x315d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3161: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3165: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3169: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x316d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3171: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3175: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3179: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x317d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3181: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3185: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3189: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x318d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3191: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3195: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3199: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x319d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x31a1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x31a5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x31a9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x31ad: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x31b1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x31b5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x31b9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x31bd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x31c1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x31c5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x31c9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x31cd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x31d1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x31d5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x31d9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x31dd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x31e1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x31e5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x31e9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x31ed: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x31f1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x31f5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x31f9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x31fd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3201: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3205: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3209: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x320d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3211: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3215: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3219: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x321d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3221: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3225: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3229: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x322d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3231: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3235: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3239: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x323d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3241: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3245: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3249: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x324d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3251: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3255: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3259: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x325d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3261: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3265: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3269: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x326d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3271: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3275: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3279: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x327d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3281: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3285: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3289: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x328d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3291: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3295: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3299: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x329d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x32a1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x32a5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x32a9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x32ad: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x32b1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x32b5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x32b9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x32bd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x32c1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x32c5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x32c9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x32cd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x32d1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x32d5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x32d9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x32dd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x32e1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x32e5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x32e9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x32ed: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x32f1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x32f5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x32f9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x32fd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3301: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3305: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3309: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x330d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3311: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3315: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3319: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x331d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3321: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3325: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3329: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x332d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3331: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3335: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3339: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x333d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3341: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3345: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3349: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x334d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3351: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3355: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3359: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x335d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3361: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3365: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3369: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x336d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3371: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3375: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3379: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x337d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3381: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3385: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3389: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x338d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3391: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3395: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3399: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x339d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x33a1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x33a5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x33a9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x33ad: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x33b1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x33b5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x33b9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x33bd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x33c1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x33c5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x33c9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x33cd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x33d1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x33d5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x33d9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x33dd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x33e1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x33e5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x33e9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x33ed: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x33f1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x33f5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x33f9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x33fd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3401: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3405: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3409: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x340d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3411: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3415: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3419: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x341d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3421: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3425: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3429: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x342d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3431: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3435: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3439: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x343d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3441: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3445: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3449: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x344d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3451: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3455: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3459: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x345d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3461: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3465: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3469: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x346d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3471: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3475: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3479: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x347d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3481: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3485: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3489: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x348d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3491: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3495: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3499: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x349d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x34a1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x34a5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x34a9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x34ad: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x34b1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x34b5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x34b9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x34bd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x34c1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x34c5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x34c9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x34cd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x34d1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x34d5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x34d9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x34dd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x34e1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x34e5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x34e9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x34ed: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x34f1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x34f5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x34f9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x34fd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3501: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3505: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3509: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x350d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3511: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3515: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3519: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x351d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3521: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3525: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3529: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x352d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3531: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3535: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3539: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x353d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3541: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3545: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3549: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x354d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3551: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3555: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3559: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x355d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3561: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3565: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3569: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x356d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3571: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3575: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3579: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x357d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3581: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3585: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3589: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x358d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3591: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3595: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3599: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x359d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x35a1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x35a5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x35a9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x35ad: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x35b1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x35b5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x35b9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x35bd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x35c1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x35c5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x35c9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x35cd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x35d1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x35d5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x35d9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x35dd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x35e1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x35e5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x35e9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x35ed: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x35f1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x35f5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x35f9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x35fd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3601: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3605: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3609: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x360d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3611: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3615: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3619: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x361d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3621: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3625: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3629: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x362d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3631: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3635: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3639: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x363d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3641: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3645: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3649: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x364d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3651: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3655: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3659: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x365d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3661: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3665: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3669: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x366d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3671: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3675: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3679: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x367d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3681: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3685: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3689: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x368d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3691: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3695: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3699: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x369d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x36a1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x36a5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x36a9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x36ad: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x36b1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x36b5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x36b9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x36bd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x36c1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x36c5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x36c9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x36cd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x36d1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x36d5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x36d9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x36dd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x36e1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x36e5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x36e9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x36ed: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x36f1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x36f5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x36f9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x36fd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3701: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3705: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3709: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x370d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3711: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3715: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3719: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x371d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3721: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3725: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3729: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x372d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3731: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3735: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3739: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x373d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3741: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3745: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3749: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x374d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3751: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3755: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3759: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x375d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3761: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3765: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3769: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x376d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3771: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3775: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3779: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x377d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3781: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3785: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3789: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x378d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3791: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3795: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3799: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x379d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x37a1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x37a5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x37a9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x37ad: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x37b1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x37b5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x37b9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x37bd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x37c1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x37c5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x37c9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x37cd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x37d1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x37d5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x37d9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x37dd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x37e1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x37e5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x37e9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x37ed: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x37f1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x37f5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x37f9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x37fd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3801: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3805: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3809: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x380d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3811: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3815: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3819: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x381d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3821: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3825: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3829: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x382d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3831: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3835: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3839: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x383d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3841: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3845: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3849: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x384d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3851: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3855: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3859: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x385d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3861: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3865: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3869: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x386d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3871: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3875: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3879: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x387d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3881: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3885: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3889: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x388d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3891: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3895: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3899: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x389d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x38a1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x38a5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x38a9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x38ad: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x38b1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x38b5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x38b9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x38bd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x38c1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x38c5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x38c9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x38cd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x38d1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x38d5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x38d9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x38dd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x38e1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x38e5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x38e9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x38ed: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x38f1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x38f5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x38f9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x38fd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3901: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3905: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3909: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x390d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3911: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3915: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3919: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x391d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3921: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3925: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3929: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x392d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3931: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3935: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3939: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x393d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3941: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3945: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3949: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x394d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3951: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3955: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3959: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x395d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3961: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3965: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3969: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x396d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3971: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3975: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3979: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x397d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3981: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3985: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3989: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x398d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3991: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3995: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3999: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x399d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x39a1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x39a5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x39a9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x39ad: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x39b1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x39b5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x39b9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x39bd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x39c1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x39c5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x39c9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x39cd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x39d1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x39d5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x39d9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x39dd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x39e1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x39e5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x39e9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x39ed: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x39f1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x39f5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x39f9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x39fd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3a01: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3a05: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3a09: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3a0d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3a11: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3a15: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3a19: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3a1d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3a21: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3a25: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3a29: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3a2d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3a31: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3a35: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3a39: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3a3d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3a41: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3a45: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3a49: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3a4d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3a51: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3a55: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3a59: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3a5d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3a61: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3a65: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3a69: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3a6d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3a71: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3a75: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3a79: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3a7d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3a81: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3a85: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3a89: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3a8d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3a91: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3a95: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3a99: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3a9d: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3aa1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3aa5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3aa9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3aad: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3ab1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3ab5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3ab9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3abd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3ac1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3ac5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3ac9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3acd: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3ad1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3ad5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3ad9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3add: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3ae1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3ae5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3ae9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3aed: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3af1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3af5: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3af9: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3afd: test   r9b,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_TEST_IMM, X86_R9, X86_WIDTH_8, 1ULL);
	/* 0x3b01: jne    3b0c <choose_2> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3b01, 0x3b0c, x86_l_3b0c);
	/* 0x3b03: lea    r10,[rip+0xc] */
	X86_SIM_X86_CODE_ADDRESS(X86_R10, 0x3b16ULL);
	/* 0x3b0a: jmp    3b13 <dispatch_2> */
	X86_SIM_X86_JMP(0x3b0a, 0x3b13, x86_l_3b13);
x86_l_3b0c:
	/* 0x3b0c: lea    r10,[rip+0x9] */
	X86_SIM_X86_CODE_ADDRESS(X86_R10, 0x3b1cULL);
x86_l_3b13:
	/* 0x3b13: jmp    r10 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R10);
		switch (X86_SIM_L_REG_TAG(X86_R10)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x3b16ULL: goto x86_l_3b16;
			case 0x3b1cULL: goto x86_l_3b1c;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3b16:
	/* 0x3b16: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3b1a: jmp    3b20 <join_2> */
	X86_SIM_X86_JMP(0x3b1a, 0x3b20, x86_l_3b20);
x86_l_3b1c:
	/* 0x3b1c: add    r8,0x2 */
	fidelity_step_1(__x86_state);
x86_l_3b20:
	/* 0x3b20: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3b24: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3b28: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3b2c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3b30: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3b34: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3b38: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3b3c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3b40: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3b44: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3b48: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3b4c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3b50: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3b54: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3b58: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3b5c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3b60: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3b64: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3b68: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3b6c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3b70: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3b74: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3b78: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3b7c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3b80: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3b84: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3b88: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3b8c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3b90: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3b94: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3b98: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3b9c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3ba0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3ba4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3ba8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3bac: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3bb0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3bb4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3bb8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3bbc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3bc0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3bc4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3bc8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3bcc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3bd0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3bd4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3bd8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3bdc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3be0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3be4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3be8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3bec: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3bf0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3bf4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3bf8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3bfc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3c00: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3c04: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3c08: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3c0c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3c10: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3c14: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3c18: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3c1c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3c20: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3c24: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3c28: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3c2c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3c30: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3c34: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3c38: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3c3c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3c40: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3c44: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3c48: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3c4c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3c50: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3c54: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3c58: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3c5c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3c60: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3c64: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3c68: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3c6c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3c70: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3c74: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3c78: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3c7c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3c80: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3c84: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3c88: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3c8c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3c90: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3c94: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3c98: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3c9c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3ca0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3ca4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3ca8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3cac: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3cb0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3cb4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3cb8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3cbc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3cc0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3cc4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3cc8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3ccc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3cd0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3cd4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3cd8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3cdc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3ce0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3ce4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3ce8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3cec: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3cf0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3cf4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3cf8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3cfc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3d00: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3d04: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3d08: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3d0c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3d10: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3d14: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3d18: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3d1c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3d20: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3d24: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3d28: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3d2c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3d30: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3d34: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3d38: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3d3c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3d40: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3d44: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3d48: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3d4c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3d50: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3d54: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3d58: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3d5c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3d60: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3d64: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3d68: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3d6c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3d70: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3d74: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3d78: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3d7c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3d80: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3d84: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3d88: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3d8c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3d90: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3d94: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3d98: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3d9c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3da0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3da4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3da8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3dac: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3db0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3db4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3db8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3dbc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3dc0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3dc4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3dc8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3dcc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3dd0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3dd4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3dd8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3ddc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3de0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3de4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3de8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3dec: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3df0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3df4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3df8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3dfc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3e00: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3e04: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3e08: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3e0c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3e10: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3e14: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3e18: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3e1c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3e20: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3e24: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3e28: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3e2c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3e30: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3e34: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3e38: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3e3c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3e40: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3e44: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3e48: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3e4c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3e50: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3e54: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3e58: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3e5c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3e60: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3e64: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3e68: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3e6c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3e70: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3e74: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3e78: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3e7c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3e80: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3e84: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3e88: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3e8c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3e90: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3e94: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3e98: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3e9c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3ea0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3ea4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3ea8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3eac: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3eb0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3eb4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3eb8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3ebc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3ec0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3ec4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3ec8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3ecc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3ed0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3ed4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3ed8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3edc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3ee0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3ee4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3ee8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3eec: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3ef0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3ef4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3ef8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3efc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3f00: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3f04: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3f08: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3f0c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3f10: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3f14: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3f18: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3f1c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3f20: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3f24: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3f28: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3f2c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3f30: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3f34: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3f38: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3f3c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3f40: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3f44: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3f48: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3f4c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3f50: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3f54: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3f58: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3f5c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3f60: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3f64: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3f68: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3f6c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3f70: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3f74: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3f78: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3f7c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3f80: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3f84: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3f88: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3f8c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3f90: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3f94: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3f98: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3f9c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3fa0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3fa4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3fa8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3fac: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3fb0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3fb4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3fb8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3fbc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3fc0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3fc4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3fc8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3fcc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3fd0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3fd4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3fd8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3fdc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3fe0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3fe4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3fe8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3fec: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3ff0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3ff4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x3ff8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x3ffc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4000: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4004: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4008: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x400c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4010: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4014: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4018: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x401c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4020: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4024: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4028: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x402c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4030: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4034: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4038: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x403c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4040: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4044: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4048: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x404c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4050: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4054: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4058: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x405c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4060: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4064: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4068: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x406c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4070: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4074: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4078: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x407c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4080: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4084: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4088: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x408c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4090: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4094: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4098: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x409c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x40a0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x40a4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x40a8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x40ac: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x40b0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x40b4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x40b8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x40bc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x40c0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x40c4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x40c8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x40cc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x40d0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x40d4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x40d8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x40dc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x40e0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x40e4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x40e8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x40ec: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x40f0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x40f4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x40f8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x40fc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4100: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4104: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4108: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x410c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4110: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4114: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4118: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x411c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4120: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4124: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4128: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x412c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4130: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4134: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4138: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x413c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4140: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4144: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4148: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x414c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4150: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4154: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4158: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x415c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4160: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4164: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4168: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x416c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4170: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4174: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4178: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x417c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4180: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4184: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4188: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x418c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4190: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4194: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4198: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x419c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x41a0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x41a4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x41a8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x41ac: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x41b0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x41b4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x41b8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x41bc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x41c0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x41c4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x41c8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x41cc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x41d0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x41d4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x41d8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x41dc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x41e0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x41e4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x41e8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x41ec: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x41f0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x41f4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x41f8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x41fc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4200: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4204: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4208: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x420c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4210: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4214: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4218: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x421c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4220: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4224: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4228: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x422c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4230: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4234: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4238: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x423c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4240: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4244: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4248: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x424c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4250: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4254: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4258: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x425c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4260: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4264: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4268: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x426c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4270: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4274: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4278: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x427c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4280: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4284: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4288: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x428c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4290: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4294: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4298: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x429c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x42a0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x42a4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x42a8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x42ac: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x42b0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x42b4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x42b8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x42bc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x42c0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x42c4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x42c8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x42cc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x42d0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x42d4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x42d8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x42dc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x42e0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x42e4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x42e8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x42ec: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x42f0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x42f4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x42f8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x42fc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4300: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4304: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4308: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x430c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4310: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4314: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4318: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x431c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4320: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4324: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4328: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x432c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4330: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4334: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4338: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x433c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4340: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4344: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4348: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x434c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4350: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4354: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4358: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x435c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4360: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4364: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4368: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x436c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4370: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4374: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4378: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x437c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4380: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4384: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4388: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x438c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4390: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4394: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4398: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x439c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x43a0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x43a4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x43a8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x43ac: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x43b0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x43b4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x43b8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x43bc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x43c0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x43c4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x43c8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x43cc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x43d0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x43d4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x43d8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x43dc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x43e0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x43e4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x43e8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x43ec: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x43f0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x43f4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x43f8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x43fc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4400: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4404: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4408: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x440c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4410: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4414: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4418: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x441c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4420: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4424: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4428: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x442c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4430: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4434: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4438: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x443c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4440: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4444: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4448: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x444c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4450: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4454: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4458: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x445c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4460: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4464: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4468: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x446c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4470: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4474: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4478: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x447c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4480: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4484: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4488: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x448c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4490: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4494: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4498: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x449c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x44a0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x44a4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x44a8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x44ac: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x44b0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x44b4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x44b8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x44bc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x44c0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x44c4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x44c8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x44cc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x44d0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x44d4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x44d8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x44dc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x44e0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x44e4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x44e8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x44ec: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x44f0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x44f4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x44f8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x44fc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4500: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4504: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4508: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x450c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4510: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4514: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4518: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x451c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4520: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4524: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4528: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x452c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4530: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4534: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4538: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x453c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4540: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4544: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4548: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x454c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4550: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4554: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4558: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x455c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4560: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4564: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4568: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x456c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4570: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4574: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4578: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x457c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4580: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4584: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4588: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x458c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4590: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4594: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4598: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x459c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x45a0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x45a4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x45a8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x45ac: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x45b0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x45b4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x45b8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x45bc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x45c0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x45c4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x45c8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x45cc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x45d0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x45d4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x45d8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x45dc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x45e0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x45e4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x45e8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x45ec: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x45f0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x45f4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x45f8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x45fc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4600: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4604: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4608: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x460c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4610: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4614: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4618: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x461c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4620: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4624: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4628: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x462c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4630: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4634: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4638: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x463c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4640: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4644: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4648: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x464c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4650: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4654: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4658: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x465c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4660: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4664: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4668: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x466c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4670: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4674: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4678: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x467c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4680: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4684: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4688: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x468c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4690: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4694: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4698: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x469c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x46a0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x46a4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x46a8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x46ac: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x46b0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x46b4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x46b8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x46bc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x46c0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x46c4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x46c8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x46cc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x46d0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x46d4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x46d8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x46dc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x46e0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x46e4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x46e8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x46ec: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x46f0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x46f4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x46f8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x46fc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4700: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4704: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4708: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x470c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4710: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4714: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4718: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x471c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4720: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4724: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4728: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x472c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4730: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4734: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4738: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x473c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4740: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4744: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4748: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x474c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4750: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4754: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4758: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x475c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4760: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4764: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4768: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x476c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4770: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4774: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4778: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x477c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4780: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4784: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4788: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x478c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4790: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4794: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4798: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x479c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x47a0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x47a4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x47a8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x47ac: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x47b0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x47b4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x47b8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x47bc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x47c0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x47c4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x47c8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x47cc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x47d0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x47d4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x47d8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x47dc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x47e0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x47e4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x47e8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x47ec: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x47f0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x47f4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x47f8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x47fc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4800: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4804: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4808: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x480c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4810: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4814: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4818: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x481c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4820: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4824: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4828: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x482c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4830: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4834: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4838: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x483c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4840: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4844: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4848: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x484c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4850: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4854: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4858: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x485c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4860: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4864: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4868: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x486c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4870: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4874: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4878: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x487c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4880: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4884: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4888: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x488c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4890: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4894: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4898: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x489c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x48a0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x48a4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x48a8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x48ac: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x48b0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x48b4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x48b8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x48bc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x48c0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x48c4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x48c8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x48cc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x48d0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x48d4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x48d8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x48dc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x48e0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x48e4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x48e8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x48ec: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x48f0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x48f4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x48f8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x48fc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4900: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4904: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4908: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x490c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4910: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4914: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4918: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x491c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4920: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4924: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4928: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x492c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4930: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4934: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4938: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x493c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4940: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4944: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4948: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x494c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4950: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4954: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4958: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x495c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4960: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4964: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4968: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x496c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4970: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4974: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4978: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x497c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4980: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4984: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4988: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x498c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4990: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4994: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4998: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x499c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x49a0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x49a4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x49a8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x49ac: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x49b0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x49b4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x49b8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x49bc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x49c0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x49c4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x49c8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x49cc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x49d0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x49d4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x49d8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x49dc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x49e0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x49e4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x49e8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x49ec: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x49f0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x49f4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x49f8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x49fc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4a00: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4a04: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4a08: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4a0c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4a10: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4a14: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4a18: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4a1c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4a20: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4a24: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4a28: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4a2c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4a30: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4a34: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4a38: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4a3c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4a40: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4a44: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4a48: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4a4c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4a50: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4a54: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4a58: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4a5c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4a60: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4a64: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4a68: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4a6c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4a70: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4a74: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4a78: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4a7c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4a80: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4a84: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4a88: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4a8c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4a90: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4a94: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4a98: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4a9c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4aa0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4aa4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4aa8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4aac: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4ab0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4ab4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4ab8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4abc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4ac0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4ac4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4ac8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4acc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4ad0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4ad4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4ad8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4adc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4ae0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4ae4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4ae8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4aec: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4af0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4af4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4af8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4afc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4b00: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4b04: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4b08: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4b0c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4b10: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4b14: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4b18: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4b1c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4b20: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4b24: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4b28: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4b2c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4b30: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4b34: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4b38: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4b3c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4b40: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4b44: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4b48: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4b4c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4b50: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4b54: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4b58: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4b5c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4b60: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4b64: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4b68: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4b6c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4b70: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4b74: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4b78: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4b7c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4b80: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4b84: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4b88: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4b8c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4b90: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4b94: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4b98: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4b9c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4ba0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4ba4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4ba8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4bac: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4bb0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4bb4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4bb8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4bbc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4bc0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4bc4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4bc8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4bcc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4bd0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4bd4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4bd8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4bdc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4be0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4be4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4be8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4bec: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4bf0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4bf4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4bf8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4bfc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4c00: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4c04: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4c08: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4c0c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4c10: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4c14: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4c18: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4c1c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4c20: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4c24: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4c28: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4c2c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4c30: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4c34: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4c38: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4c3c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4c40: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4c44: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4c48: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4c4c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4c50: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4c54: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4c58: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4c5c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4c60: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4c64: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4c68: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4c6c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4c70: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4c74: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4c78: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4c7c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4c80: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4c84: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4c88: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4c8c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4c90: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4c94: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4c98: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4c9c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4ca0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4ca4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4ca8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4cac: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4cb0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4cb4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4cb8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4cbc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4cc0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4cc4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4cc8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4ccc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4cd0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4cd4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4cd8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4cdc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4ce0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4ce4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4ce8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4cec: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4cf0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4cf4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4cf8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4cfc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4d00: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4d04: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4d08: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4d0c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4d10: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4d14: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4d18: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4d1c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4d20: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4d24: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4d28: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4d2c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4d30: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4d34: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4d38: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4d3c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4d40: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4d44: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4d48: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4d4c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4d50: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4d54: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4d58: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4d5c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4d60: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4d64: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4d68: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4d6c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4d70: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4d74: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4d78: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4d7c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4d80: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4d84: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4d88: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4d8c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4d90: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4d94: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4d98: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4d9c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4da0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4da4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4da8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4dac: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4db0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4db4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4db8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4dbc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4dc0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4dc4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4dc8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4dcc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4dd0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4dd4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4dd8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4ddc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4de0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4de4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4de8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4dec: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4df0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4df4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4df8: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4dfc: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4e00: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4e04: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4e08: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4e0c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4e10: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4e14: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4e18: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4e1c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4e20: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4e24: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4e28: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4e2c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4e30: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4e34: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4e38: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4e3c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4e40: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4e44: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4e48: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4e4c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4e50: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4e54: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4e58: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4e5c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4e60: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4e64: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4e68: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4e6c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4e70: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4e74: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4e78: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4e7c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4e80: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4e84: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4e88: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4e8c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4e90: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4e94: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4e98: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4e9c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4ea0: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4ea4: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4ea8: test   r9b,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_TEST_IMM, X86_R9, X86_WIDTH_8, 1ULL);
	/* 0x4eac: jne    4eb7 <choose_3> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x4eac, 0x4eb7, x86_l_4eb7);
	/* 0x4eae: lea    r10,[rip+0xc] */
	X86_SIM_X86_CODE_ADDRESS(X86_R10, 0x4ec1ULL);
	/* 0x4eb5: jmp    4ebe <dispatch_3> */
	X86_SIM_X86_JMP(0x4eb5, 0x4ebe, x86_l_4ebe);
x86_l_4eb7:
	/* 0x4eb7: lea    r10,[rip+0x9] */
	X86_SIM_X86_CODE_ADDRESS(X86_R10, 0x4ec7ULL);
x86_l_4ebe:
	/* 0x4ebe: jmp    r10 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R10);
		switch (X86_SIM_L_REG_TAG(X86_R10)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x4ec1ULL: goto x86_l_4ec1;
			case 0x4ec7ULL: goto x86_l_4ec7;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_4ec1:
	/* 0x4ec1: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4ec5: jmp    4ecb <join_3> */
	X86_SIM_X86_JMP(0x4ec5, 0x4ecb, x86_l_4ecb);
x86_l_4ec7:
	/* 0x4ec7: add    r8,0x2 */
	fidelity_step_1(__x86_state);
x86_l_4ecb:
	/* 0x4ecb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4ecf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4ed3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4ed7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4edb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4edf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4ee3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4ee7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4eeb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4eef: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4ef3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4ef7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4efb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4eff: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4f03: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4f07: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4f0b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4f0f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4f13: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4f17: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4f1b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4f1f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4f23: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4f27: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4f2b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4f2f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4f33: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4f37: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4f3b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4f3f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4f43: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4f47: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4f4b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4f4f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4f53: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4f57: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4f5b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4f5f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4f63: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4f67: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4f6b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4f6f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4f73: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4f77: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4f7b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4f7f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4f83: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4f87: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4f8b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4f8f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4f93: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4f97: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4f9b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4f9f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4fa3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4fa7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4fab: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4faf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4fb3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4fb7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4fbb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4fbf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4fc3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4fc7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4fcb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4fcf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4fd3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4fd7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4fdb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4fdf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4fe3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4fe7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4feb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4fef: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4ff3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4ff7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x4ffb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x4fff: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5003: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5007: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x500b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x500f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5013: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5017: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x501b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x501f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5023: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5027: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x502b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x502f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5033: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5037: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x503b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x503f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5043: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5047: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x504b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x504f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5053: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5057: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x505b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x505f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5063: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5067: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x506b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x506f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5073: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5077: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x507b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x507f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5083: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5087: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x508b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x508f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5093: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5097: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x509b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x509f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x50a3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x50a7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x50ab: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x50af: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x50b3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x50b7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x50bb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x50bf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x50c3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x50c7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x50cb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x50cf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x50d3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x50d7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x50db: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x50df: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x50e3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x50e7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x50eb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x50ef: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x50f3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x50f7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x50fb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x50ff: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5103: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5107: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x510b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x510f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5113: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5117: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x511b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x511f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5123: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5127: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x512b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x512f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5133: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5137: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x513b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x513f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5143: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5147: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x514b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x514f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5153: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5157: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x515b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x515f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5163: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5167: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x516b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x516f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5173: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5177: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x517b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x517f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5183: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5187: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x518b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x518f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5193: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5197: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x519b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x519f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x51a3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x51a7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x51ab: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x51af: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x51b3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x51b7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x51bb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x51bf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x51c3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x51c7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x51cb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x51cf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x51d3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x51d7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x51db: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x51df: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x51e3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x51e7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x51eb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x51ef: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x51f3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x51f7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x51fb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x51ff: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5203: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5207: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x520b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x520f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5213: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5217: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x521b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x521f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5223: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5227: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x522b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x522f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5233: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5237: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x523b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x523f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5243: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5247: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x524b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x524f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5253: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5257: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x525b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x525f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5263: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5267: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x526b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x526f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5273: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5277: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x527b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x527f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5283: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5287: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x528b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x528f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5293: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5297: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x529b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x529f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x52a3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x52a7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x52ab: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x52af: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x52b3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x52b7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x52bb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x52bf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x52c3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x52c7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x52cb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x52cf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x52d3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x52d7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x52db: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x52df: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x52e3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x52e7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x52eb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x52ef: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x52f3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x52f7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x52fb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x52ff: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5303: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5307: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x530b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x530f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5313: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5317: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x531b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x531f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5323: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5327: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x532b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x532f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5333: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5337: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x533b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x533f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5343: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5347: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x534b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x534f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5353: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5357: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x535b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x535f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5363: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5367: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x536b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x536f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5373: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5377: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x537b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x537f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5383: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5387: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x538b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x538f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5393: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5397: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x539b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x539f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x53a3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x53a7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x53ab: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x53af: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x53b3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x53b7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x53bb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x53bf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x53c3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x53c7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x53cb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x53cf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x53d3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x53d7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x53db: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x53df: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x53e3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x53e7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x53eb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x53ef: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x53f3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x53f7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x53fb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x53ff: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5403: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5407: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x540b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x540f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5413: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5417: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x541b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x541f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5423: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5427: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x542b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x542f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5433: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5437: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x543b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x543f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5443: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5447: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x544b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x544f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5453: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5457: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x545b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x545f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5463: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5467: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x546b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x546f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5473: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5477: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x547b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x547f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5483: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5487: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x548b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x548f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5493: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5497: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x549b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x549f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x54a3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x54a7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x54ab: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x54af: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x54b3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x54b7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x54bb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x54bf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x54c3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x54c7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x54cb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x54cf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x54d3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x54d7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x54db: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x54df: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x54e3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x54e7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x54eb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x54ef: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x54f3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x54f7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x54fb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x54ff: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5503: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5507: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x550b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x550f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5513: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5517: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x551b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x551f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5523: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5527: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x552b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x552f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5533: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5537: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x553b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x553f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5543: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5547: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x554b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x554f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5553: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5557: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x555b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x555f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5563: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5567: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x556b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x556f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5573: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5577: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x557b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x557f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5583: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5587: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x558b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x558f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5593: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5597: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x559b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x559f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x55a3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x55a7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x55ab: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x55af: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x55b3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x55b7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x55bb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x55bf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x55c3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x55c7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x55cb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x55cf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x55d3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x55d7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x55db: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x55df: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x55e3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x55e7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x55eb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x55ef: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x55f3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x55f7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x55fb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x55ff: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5603: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5607: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x560b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x560f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5613: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5617: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x561b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x561f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5623: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5627: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x562b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x562f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5633: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5637: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x563b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x563f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5643: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5647: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x564b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x564f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5653: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5657: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x565b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x565f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5663: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5667: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x566b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x566f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5673: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5677: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x567b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x567f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5683: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5687: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x568b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x568f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5693: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5697: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x569b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x569f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x56a3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x56a7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x56ab: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x56af: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x56b3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x56b7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x56bb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x56bf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x56c3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x56c7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x56cb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x56cf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x56d3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x56d7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x56db: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x56df: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x56e3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x56e7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x56eb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x56ef: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x56f3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x56f7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x56fb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x56ff: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5703: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5707: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x570b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x570f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5713: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5717: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x571b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x571f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5723: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5727: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x572b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x572f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5733: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5737: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x573b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x573f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5743: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5747: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x574b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x574f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5753: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5757: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x575b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x575f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5763: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5767: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x576b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x576f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5773: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5777: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x577b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x577f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5783: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5787: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x578b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x578f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5793: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5797: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x579b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x579f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x57a3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x57a7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x57ab: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x57af: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x57b3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x57b7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x57bb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x57bf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x57c3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x57c7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x57cb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x57cf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x57d3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x57d7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x57db: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x57df: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x57e3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x57e7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x57eb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x57ef: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x57f3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x57f7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x57fb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x57ff: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5803: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5807: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x580b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x580f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5813: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5817: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x581b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x581f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5823: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5827: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x582b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x582f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5833: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5837: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x583b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x583f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5843: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5847: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x584b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x584f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5853: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5857: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x585b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x585f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5863: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5867: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x586b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x586f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5873: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5877: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x587b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x587f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5883: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5887: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x588b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x588f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5893: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5897: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x589b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x589f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x58a3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x58a7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x58ab: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x58af: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x58b3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x58b7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x58bb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x58bf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x58c3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x58c7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x58cb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x58cf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x58d3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x58d7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x58db: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x58df: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x58e3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x58e7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x58eb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x58ef: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x58f3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x58f7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x58fb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x58ff: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5903: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5907: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x590b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x590f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5913: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5917: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x591b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x591f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5923: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5927: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x592b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x592f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5933: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5937: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x593b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x593f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5943: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5947: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x594b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x594f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5953: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5957: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x595b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x595f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5963: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5967: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x596b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x596f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5973: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5977: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x597b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x597f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5983: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5987: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x598b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x598f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5993: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5997: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x599b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x599f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x59a3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x59a7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x59ab: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x59af: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x59b3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x59b7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x59bb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x59bf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x59c3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x59c7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x59cb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x59cf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x59d3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x59d7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x59db: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x59df: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x59e3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x59e7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x59eb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x59ef: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x59f3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x59f7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x59fb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x59ff: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5a03: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5a07: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5a0b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5a0f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5a13: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5a17: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5a1b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5a1f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5a23: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5a27: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5a2b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5a2f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5a33: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5a37: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5a3b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5a3f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5a43: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5a47: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5a4b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5a4f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5a53: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5a57: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5a5b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5a5f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5a63: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5a67: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5a6b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5a6f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5a73: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5a77: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5a7b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5a7f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5a83: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5a87: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5a8b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5a8f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5a93: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5a97: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5a9b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5a9f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5aa3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5aa7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5aab: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5aaf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5ab3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5ab7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5abb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5abf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5ac3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5ac7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5acb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5acf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5ad3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5ad7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5adb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5adf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5ae3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5ae7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5aeb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5aef: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5af3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5af7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5afb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5aff: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5b03: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5b07: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5b0b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5b0f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5b13: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5b17: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5b1b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5b1f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5b23: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5b27: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5b2b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5b2f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5b33: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5b37: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5b3b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5b3f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5b43: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5b47: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5b4b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5b4f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5b53: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5b57: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5b5b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5b5f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5b63: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5b67: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5b6b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5b6f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5b73: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5b77: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5b7b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5b7f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5b83: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5b87: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5b8b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5b8f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5b93: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5b97: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5b9b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5b9f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5ba3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5ba7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5bab: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5baf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5bb3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5bb7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5bbb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5bbf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5bc3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5bc7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5bcb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5bcf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5bd3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5bd7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5bdb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5bdf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5be3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5be7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5beb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5bef: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5bf3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5bf7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5bfb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5bff: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5c03: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5c07: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5c0b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5c0f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5c13: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5c17: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5c1b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5c1f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5c23: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5c27: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5c2b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5c2f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5c33: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5c37: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5c3b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5c3f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5c43: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5c47: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5c4b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5c4f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5c53: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5c57: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5c5b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5c5f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5c63: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5c67: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5c6b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5c6f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5c73: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5c77: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5c7b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5c7f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5c83: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5c87: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5c8b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5c8f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5c93: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5c97: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5c9b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5c9f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5ca3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5ca7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5cab: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5caf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5cb3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5cb7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5cbb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5cbf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5cc3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5cc7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5ccb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5ccf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5cd3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5cd7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5cdb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5cdf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5ce3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5ce7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5ceb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5cef: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5cf3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5cf7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5cfb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5cff: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5d03: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5d07: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5d0b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5d0f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5d13: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5d17: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5d1b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5d1f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5d23: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5d27: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5d2b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5d2f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5d33: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5d37: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5d3b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5d3f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5d43: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5d47: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5d4b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5d4f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5d53: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5d57: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5d5b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5d5f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5d63: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5d67: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5d6b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5d6f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5d73: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5d77: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5d7b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5d7f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5d83: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5d87: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5d8b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5d8f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5d93: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5d97: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5d9b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5d9f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5da3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5da7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5dab: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5daf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5db3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5db7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5dbb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5dbf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5dc3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5dc7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5dcb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5dcf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5dd3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5dd7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5ddb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5ddf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5de3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5de7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5deb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5def: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5df3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5df7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5dfb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5dff: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5e03: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5e07: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5e0b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5e0f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5e13: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5e17: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5e1b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5e1f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5e23: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5e27: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5e2b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5e2f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5e33: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5e37: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5e3b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5e3f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5e43: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5e47: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5e4b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5e4f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5e53: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5e57: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5e5b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5e5f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5e63: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5e67: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5e6b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5e6f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5e73: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5e77: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5e7b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5e7f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5e83: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5e87: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5e8b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5e8f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5e93: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5e97: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5e9b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5e9f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5ea3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5ea7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5eab: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5eaf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5eb3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5eb7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5ebb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5ebf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5ec3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5ec7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5ecb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5ecf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5ed3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5ed7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5edb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5edf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5ee3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5ee7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5eeb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5eef: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5ef3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5ef7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5efb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5eff: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5f03: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5f07: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5f0b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5f0f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5f13: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5f17: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5f1b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5f1f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5f23: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5f27: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5f2b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5f2f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5f33: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5f37: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5f3b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5f3f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5f43: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5f47: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5f4b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5f4f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5f53: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5f57: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5f5b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5f5f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5f63: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5f67: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5f6b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5f6f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5f73: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5f77: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5f7b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5f7f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5f83: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5f87: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5f8b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5f8f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5f93: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5f97: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5f9b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5f9f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5fa3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5fa7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5fab: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5faf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5fb3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5fb7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5fbb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5fbf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5fc3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5fc7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5fcb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5fcf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5fd3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5fd7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5fdb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5fdf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5fe3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5fe7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5feb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5fef: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5ff3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5ff7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x5ffb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x5fff: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6003: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6007: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x600b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x600f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6013: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6017: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x601b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x601f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6023: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6027: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x602b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x602f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6033: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6037: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x603b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x603f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6043: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6047: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x604b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x604f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6053: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6057: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x605b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x605f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6063: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6067: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x606b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x606f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6073: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6077: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x607b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x607f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6083: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6087: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x608b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x608f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6093: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6097: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x609b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x609f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x60a3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x60a7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x60ab: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x60af: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x60b3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x60b7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x60bb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x60bf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x60c3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x60c7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x60cb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x60cf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x60d3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x60d7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x60db: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x60df: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x60e3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x60e7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x60eb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x60ef: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x60f3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x60f7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x60fb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x60ff: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6103: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6107: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x610b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x610f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6113: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6117: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x611b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x611f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6123: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6127: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x612b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x612f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6133: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6137: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x613b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x613f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6143: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6147: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x614b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x614f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6153: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6157: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x615b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x615f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6163: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6167: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x616b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x616f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6173: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6177: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x617b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x617f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6183: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6187: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x618b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x618f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6193: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6197: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x619b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x619f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x61a3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x61a7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x61ab: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x61af: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x61b3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x61b7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x61bb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x61bf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x61c3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x61c7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x61cb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x61cf: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x61d3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x61d7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x61db: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x61df: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x61e3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x61e7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x61eb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x61ef: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x61f3: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x61f7: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x61fb: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x61ff: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6203: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6207: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x620b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x620f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6213: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6217: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x621b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x621f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6223: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6227: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x622b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x622f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6233: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6237: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x623b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x623f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6243: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6247: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x624b: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x624f: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6253: test   r9b,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_TEST_IMM, X86_R9, X86_WIDTH_8, 1ULL);
	/* 0x6257: jne    6262 <choose_4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x6257, 0x6262, x86_l_6262);
	/* 0x6259: lea    r10,[rip+0xc] */
	X86_SIM_X86_CODE_ADDRESS(X86_R10, 0x626cULL);
	/* 0x6260: jmp    6269 <dispatch_4> */
	X86_SIM_X86_JMP(0x6260, 0x6269, x86_l_6269);
x86_l_6262:
	/* 0x6262: lea    r10,[rip+0x9] */
	X86_SIM_X86_CODE_ADDRESS(X86_R10, 0x6272ULL);
x86_l_6269:
	/* 0x6269: jmp    r10 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R10);
		switch (X86_SIM_L_REG_TAG(X86_R10)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x626cULL: goto x86_l_626c;
			case 0x6272ULL: goto x86_l_6272;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_626c:
	/* 0x626c: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6270: jmp    6276 <join_4> */
	X86_SIM_X86_JMP(0x6270, 0x6276, x86_l_6276);
x86_l_6272:
	/* 0x6272: add    r8,0x2 */
	fidelity_step_1(__x86_state);
x86_l_6276:
	/* 0x6276: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x627a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x627e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6282: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6286: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x628a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x628e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6292: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6296: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x629a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x629e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x62a2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x62a6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x62aa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x62ae: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x62b2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x62b6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x62ba: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x62be: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x62c2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x62c6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x62ca: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x62ce: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x62d2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x62d6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x62da: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x62de: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x62e2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x62e6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x62ea: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x62ee: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x62f2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x62f6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x62fa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x62fe: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6302: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6306: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x630a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x630e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6312: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6316: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x631a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x631e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6322: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6326: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x632a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x632e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6332: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6336: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x633a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x633e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6342: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6346: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x634a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x634e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6352: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6356: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x635a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x635e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6362: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6366: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x636a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x636e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6372: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6376: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x637a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x637e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6382: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6386: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x638a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x638e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6392: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6396: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x639a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x639e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x63a2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x63a6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x63aa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x63ae: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x63b2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x63b6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x63ba: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x63be: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x63c2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x63c6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x63ca: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x63ce: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x63d2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x63d6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x63da: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x63de: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x63e2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x63e6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x63ea: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x63ee: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x63f2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x63f6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x63fa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x63fe: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6402: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6406: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x640a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x640e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6412: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6416: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x641a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x641e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6422: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6426: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x642a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x642e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6432: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6436: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x643a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x643e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6442: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6446: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x644a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x644e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6452: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6456: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x645a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x645e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6462: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6466: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x646a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x646e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6472: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6476: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x647a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x647e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6482: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6486: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x648a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x648e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6492: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6496: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x649a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x649e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x64a2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x64a6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x64aa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x64ae: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x64b2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x64b6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x64ba: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x64be: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x64c2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x64c6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x64ca: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x64ce: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x64d2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x64d6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x64da: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x64de: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x64e2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x64e6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x64ea: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x64ee: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x64f2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x64f6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x64fa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x64fe: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6502: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6506: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x650a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x650e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6512: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6516: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x651a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x651e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6522: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6526: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x652a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x652e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6532: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6536: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x653a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x653e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6542: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6546: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x654a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x654e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6552: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6556: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x655a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x655e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6562: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6566: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x656a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x656e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6572: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6576: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x657a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x657e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6582: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6586: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x658a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x658e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6592: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6596: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x659a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x659e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x65a2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x65a6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x65aa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x65ae: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x65b2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x65b6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x65ba: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x65be: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x65c2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x65c6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x65ca: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x65ce: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x65d2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x65d6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x65da: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x65de: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x65e2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x65e6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x65ea: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x65ee: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x65f2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x65f6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x65fa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x65fe: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6602: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6606: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x660a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x660e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6612: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6616: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x661a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x661e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6622: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6626: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x662a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x662e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6632: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6636: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x663a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x663e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6642: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6646: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x664a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x664e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6652: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6656: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x665a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x665e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6662: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6666: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x666a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x666e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6672: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6676: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x667a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x667e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6682: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6686: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x668a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x668e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6692: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6696: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x669a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x669e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x66a2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x66a6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x66aa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x66ae: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x66b2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x66b6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x66ba: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x66be: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x66c2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x66c6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x66ca: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x66ce: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x66d2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x66d6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x66da: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x66de: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x66e2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x66e6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x66ea: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x66ee: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x66f2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x66f6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x66fa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x66fe: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6702: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6706: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x670a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x670e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6712: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6716: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x671a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x671e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6722: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6726: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x672a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x672e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6732: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6736: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x673a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x673e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6742: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6746: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x674a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x674e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6752: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6756: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x675a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x675e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6762: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6766: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x676a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x676e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6772: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6776: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x677a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x677e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6782: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6786: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x678a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x678e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6792: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6796: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x679a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x679e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x67a2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x67a6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x67aa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x67ae: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x67b2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x67b6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x67ba: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x67be: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x67c2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x67c6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x67ca: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x67ce: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x67d2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x67d6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x67da: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x67de: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x67e2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x67e6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x67ea: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x67ee: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x67f2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x67f6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x67fa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x67fe: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6802: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6806: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x680a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x680e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6812: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6816: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x681a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x681e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6822: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6826: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x682a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x682e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6832: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6836: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x683a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x683e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6842: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6846: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x684a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x684e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6852: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6856: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x685a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x685e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6862: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6866: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x686a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x686e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6872: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6876: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x687a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x687e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6882: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6886: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x688a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x688e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6892: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6896: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x689a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x689e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x68a2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x68a6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x68aa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x68ae: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x68b2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x68b6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x68ba: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x68be: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x68c2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x68c6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x68ca: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x68ce: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x68d2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x68d6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x68da: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x68de: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x68e2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x68e6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x68ea: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x68ee: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x68f2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x68f6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x68fa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x68fe: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6902: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6906: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x690a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x690e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6912: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6916: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x691a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x691e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6922: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6926: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x692a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x692e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6932: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6936: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x693a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x693e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6942: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6946: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x694a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x694e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6952: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6956: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x695a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x695e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6962: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6966: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x696a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x696e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6972: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6976: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x697a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x697e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6982: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6986: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x698a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x698e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6992: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6996: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x699a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x699e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x69a2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x69a6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x69aa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x69ae: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x69b2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x69b6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x69ba: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x69be: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x69c2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x69c6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x69ca: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x69ce: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x69d2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x69d6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x69da: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x69de: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x69e2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x69e6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x69ea: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x69ee: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x69f2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x69f6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x69fa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x69fe: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6a02: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6a06: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6a0a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6a0e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6a12: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6a16: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6a1a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6a1e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6a22: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6a26: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6a2a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6a2e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6a32: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6a36: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6a3a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6a3e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6a42: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6a46: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6a4a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6a4e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6a52: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6a56: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6a5a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6a5e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6a62: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6a66: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6a6a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6a6e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6a72: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6a76: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6a7a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6a7e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6a82: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6a86: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6a8a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6a8e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6a92: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6a96: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6a9a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6a9e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6aa2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6aa6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6aaa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6aae: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6ab2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6ab6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6aba: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6abe: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6ac2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6ac6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6aca: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6ace: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6ad2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6ad6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6ada: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6ade: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6ae2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6ae6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6aea: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6aee: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6af2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6af6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6afa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6afe: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6b02: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6b06: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6b0a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6b0e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6b12: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6b16: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6b1a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6b1e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6b22: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6b26: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6b2a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6b2e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6b32: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6b36: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6b3a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6b3e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6b42: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6b46: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6b4a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6b4e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6b52: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6b56: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6b5a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6b5e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6b62: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6b66: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6b6a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6b6e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6b72: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6b76: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6b7a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6b7e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6b82: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6b86: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6b8a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6b8e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6b92: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6b96: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6b9a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6b9e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6ba2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6ba6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6baa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6bae: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6bb2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6bb6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6bba: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6bbe: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6bc2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6bc6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6bca: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6bce: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6bd2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6bd6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6bda: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6bde: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6be2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6be6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6bea: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6bee: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6bf2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6bf6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6bfa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6bfe: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6c02: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6c06: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6c0a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6c0e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6c12: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6c16: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6c1a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6c1e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6c22: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6c26: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6c2a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6c2e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6c32: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6c36: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6c3a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6c3e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6c42: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6c46: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6c4a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6c4e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6c52: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6c56: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6c5a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6c5e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6c62: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6c66: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6c6a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6c6e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6c72: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6c76: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6c7a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6c7e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6c82: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6c86: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6c8a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6c8e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6c92: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6c96: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6c9a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6c9e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6ca2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6ca6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6caa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6cae: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6cb2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6cb6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6cba: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6cbe: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6cc2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6cc6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6cca: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6cce: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6cd2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6cd6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6cda: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6cde: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6ce2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6ce6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6cea: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6cee: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6cf2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6cf6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6cfa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6cfe: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6d02: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6d06: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6d0a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6d0e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6d12: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6d16: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6d1a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6d1e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6d22: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6d26: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6d2a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6d2e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6d32: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6d36: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6d3a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6d3e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6d42: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6d46: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6d4a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6d4e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6d52: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6d56: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6d5a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6d5e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6d62: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6d66: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6d6a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6d6e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6d72: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6d76: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6d7a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6d7e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6d82: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6d86: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6d8a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6d8e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6d92: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6d96: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6d9a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6d9e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6da2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6da6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6daa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6dae: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6db2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6db6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6dba: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6dbe: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6dc2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6dc6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6dca: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6dce: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6dd2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6dd6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6dda: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6dde: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6de2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6de6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6dea: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6dee: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6df2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6df6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6dfa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6dfe: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6e02: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6e06: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6e0a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6e0e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6e12: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6e16: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6e1a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6e1e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6e22: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6e26: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6e2a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6e2e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6e32: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6e36: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6e3a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6e3e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6e42: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6e46: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6e4a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6e4e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6e52: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6e56: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6e5a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6e5e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6e62: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6e66: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6e6a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6e6e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6e72: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6e76: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6e7a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6e7e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6e82: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6e86: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6e8a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6e8e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6e92: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6e96: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6e9a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6e9e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6ea2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6ea6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6eaa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6eae: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6eb2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6eb6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6eba: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6ebe: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6ec2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6ec6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6eca: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6ece: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6ed2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6ed6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6eda: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6ede: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6ee2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6ee6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6eea: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6eee: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6ef2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6ef6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6efa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6efe: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6f02: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6f06: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6f0a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6f0e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6f12: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6f16: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6f1a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6f1e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6f22: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6f26: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6f2a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6f2e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6f32: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6f36: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6f3a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6f3e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6f42: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6f46: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6f4a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6f4e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6f52: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6f56: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6f5a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6f5e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6f62: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6f66: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6f6a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6f6e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6f72: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6f76: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6f7a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6f7e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6f82: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6f86: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6f8a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6f8e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6f92: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6f96: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6f9a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6f9e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6fa2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6fa6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6faa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6fae: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6fb2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6fb6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6fba: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6fbe: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6fc2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6fc6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6fca: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6fce: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6fd2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6fd6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6fda: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6fde: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6fe2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6fe6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6fea: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6fee: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6ff2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6ff6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x6ffa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x6ffe: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7002: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7006: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x700a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x700e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7012: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7016: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x701a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x701e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7022: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7026: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x702a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x702e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7032: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7036: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x703a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x703e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7042: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7046: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x704a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x704e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7052: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7056: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x705a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x705e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7062: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7066: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x706a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x706e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7072: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7076: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x707a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x707e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7082: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7086: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x708a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x708e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7092: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7096: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x709a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x709e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x70a2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x70a6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x70aa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x70ae: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x70b2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x70b6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x70ba: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x70be: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x70c2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x70c6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x70ca: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x70ce: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x70d2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x70d6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x70da: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x70de: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x70e2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x70e6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x70ea: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x70ee: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x70f2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x70f6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x70fa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x70fe: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7102: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7106: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x710a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x710e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7112: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7116: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x711a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x711e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7122: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7126: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x712a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x712e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7132: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7136: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x713a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x713e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7142: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7146: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x714a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x714e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7152: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7156: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x715a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x715e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7162: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7166: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x716a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x716e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7172: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7176: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x717a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x717e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7182: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7186: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x718a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x718e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7192: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7196: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x719a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x719e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x71a2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x71a6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x71aa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x71ae: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x71b2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x71b6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x71ba: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x71be: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x71c2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x71c6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x71ca: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x71ce: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x71d2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x71d6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x71da: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x71de: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x71e2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x71e6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x71ea: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x71ee: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x71f2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x71f6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x71fa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x71fe: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7202: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7206: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x720a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x720e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7212: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7216: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x721a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x721e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7222: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7226: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x722a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x722e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7232: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7236: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x723a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x723e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7242: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7246: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x724a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x724e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7252: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7256: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x725a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x725e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7262: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7266: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x726a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x726e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7272: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7276: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x727a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x727e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7282: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7286: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x728a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x728e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7292: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7296: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x729a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x729e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x72a2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x72a6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x72aa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x72ae: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x72b2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x72b6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x72ba: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x72be: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x72c2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x72c6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x72ca: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x72ce: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x72d2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x72d6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x72da: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x72de: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x72e2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x72e6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x72ea: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x72ee: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x72f2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x72f6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x72fa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x72fe: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7302: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7306: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x730a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x730e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7312: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7316: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x731a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x731e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7322: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7326: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x732a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x732e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7332: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7336: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x733a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x733e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7342: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7346: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x734a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x734e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7352: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7356: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x735a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x735e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7362: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7366: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x736a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x736e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7372: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7376: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x737a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x737e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7382: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7386: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x738a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x738e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7392: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7396: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x739a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x739e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x73a2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x73a6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x73aa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x73ae: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x73b2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x73b6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x73ba: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x73be: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x73c2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x73c6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x73ca: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x73ce: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x73d2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x73d6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x73da: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x73de: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x73e2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x73e6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x73ea: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x73ee: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x73f2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x73f6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x73fa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x73fe: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7402: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7406: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x740a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x740e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7412: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7416: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x741a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x741e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7422: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7426: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x742a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x742e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7432: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7436: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x743a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x743e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7442: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7446: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x744a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x744e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7452: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7456: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x745a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x745e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7462: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7466: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x746a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x746e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7472: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7476: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x747a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x747e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7482: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7486: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x748a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x748e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7492: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7496: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x749a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x749e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x74a2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x74a6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x74aa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x74ae: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x74b2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x74b6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x74ba: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x74be: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x74c2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x74c6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x74ca: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x74ce: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x74d2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x74d6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x74da: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x74de: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x74e2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x74e6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x74ea: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x74ee: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x74f2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x74f6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x74fa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x74fe: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7502: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7506: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x750a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x750e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7512: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7516: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x751a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x751e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7522: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7526: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x752a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x752e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7532: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7536: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x753a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x753e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7542: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7546: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x754a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x754e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7552: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7556: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x755a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x755e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7562: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7566: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x756a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x756e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7572: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7576: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x757a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x757e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7582: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7586: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x758a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x758e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7592: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7596: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x759a: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x759e: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x75a2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x75a6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x75aa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x75ae: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x75b2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x75b6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x75ba: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x75be: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x75c2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x75c6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x75ca: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x75ce: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x75d2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x75d6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x75da: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x75de: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x75e2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x75e6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x75ea: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x75ee: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x75f2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x75f6: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x75fa: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x75fe: test   r9b,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_TEST_IMM, X86_R9, X86_WIDTH_8, 1ULL);
	/* 0x7602: jne    760d <choose_5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x7602, 0x760d, x86_l_760d);
	/* 0x7604: lea    r10,[rip+0xc] */
	X86_SIM_X86_CODE_ADDRESS(X86_R10, 0x7617ULL);
	/* 0x760b: jmp    7614 <dispatch_5> */
	X86_SIM_X86_JMP(0x760b, 0x7614, x86_l_7614);
x86_l_760d:
	/* 0x760d: lea    r10,[rip+0x9] */
	X86_SIM_X86_CODE_ADDRESS(X86_R10, 0x761dULL);
x86_l_7614:
	/* 0x7614: jmp    r10 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R10);
		switch (X86_SIM_L_REG_TAG(X86_R10)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x7617ULL: goto x86_l_7617;
			case 0x761dULL: goto x86_l_761d;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_7617:
	/* 0x7617: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x761b: jmp    7621 <join_5> */
	X86_SIM_X86_JMP(0x761b, 0x7621, x86_l_7621);
x86_l_761d:
	/* 0x761d: add    r8,0x2 */
	fidelity_step_1(__x86_state);
x86_l_7621:
	/* 0x7621: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7625: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7629: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x762d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7631: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7635: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7639: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x763d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7641: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7645: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7649: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x764d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7651: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7655: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7659: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x765d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7661: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7665: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7669: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x766d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7671: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7675: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7679: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x767d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7681: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7685: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7689: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x768d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7691: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7695: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7699: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x769d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x76a1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x76a5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x76a9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x76ad: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x76b1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x76b5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x76b9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x76bd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x76c1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x76c5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x76c9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x76cd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x76d1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x76d5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x76d9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x76dd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x76e1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x76e5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x76e9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x76ed: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x76f1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x76f5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x76f9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x76fd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7701: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7705: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7709: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x770d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7711: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7715: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7719: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x771d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7721: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7725: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7729: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x772d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7731: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7735: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7739: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x773d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7741: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7745: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7749: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x774d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7751: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7755: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7759: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x775d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7761: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7765: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7769: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x776d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7771: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7775: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7779: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x777d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7781: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7785: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7789: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x778d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7791: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7795: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7799: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x779d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x77a1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x77a5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x77a9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x77ad: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x77b1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x77b5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x77b9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x77bd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x77c1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x77c5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x77c9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x77cd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x77d1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x77d5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x77d9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x77dd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x77e1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x77e5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x77e9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x77ed: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x77f1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x77f5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x77f9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x77fd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7801: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7805: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7809: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x780d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7811: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7815: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7819: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x781d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7821: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7825: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7829: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x782d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7831: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7835: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7839: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x783d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7841: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7845: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7849: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x784d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7851: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7855: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7859: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x785d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7861: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7865: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7869: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x786d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7871: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7875: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7879: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x787d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7881: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7885: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7889: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x788d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7891: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7895: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7899: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x789d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x78a1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x78a5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x78a9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x78ad: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x78b1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x78b5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x78b9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x78bd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x78c1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x78c5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x78c9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x78cd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x78d1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x78d5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x78d9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x78dd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x78e1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x78e5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x78e9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x78ed: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x78f1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x78f5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x78f9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x78fd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7901: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7905: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7909: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x790d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7911: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7915: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7919: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x791d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7921: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7925: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7929: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x792d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7931: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7935: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7939: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x793d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7941: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7945: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7949: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x794d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7951: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7955: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7959: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x795d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7961: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7965: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7969: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x796d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7971: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7975: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7979: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x797d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7981: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7985: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7989: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x798d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7991: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7995: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7999: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x799d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x79a1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x79a5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x79a9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x79ad: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x79b1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x79b5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x79b9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x79bd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x79c1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x79c5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x79c9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x79cd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x79d1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x79d5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x79d9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x79dd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x79e1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x79e5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x79e9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x79ed: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x79f1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x79f5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x79f9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x79fd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7a01: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7a05: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7a09: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7a0d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7a11: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7a15: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7a19: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7a1d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7a21: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7a25: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7a29: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7a2d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7a31: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7a35: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7a39: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7a3d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7a41: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7a45: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7a49: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7a4d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7a51: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7a55: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7a59: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7a5d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7a61: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7a65: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7a69: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7a6d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7a71: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7a75: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7a79: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7a7d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7a81: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7a85: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7a89: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7a8d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7a91: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7a95: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7a99: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7a9d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7aa1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7aa5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7aa9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7aad: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7ab1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7ab5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7ab9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7abd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7ac1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7ac5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7ac9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7acd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7ad1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7ad5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7ad9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7add: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7ae1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7ae5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7ae9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7aed: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7af1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7af5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7af9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7afd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7b01: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7b05: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7b09: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7b0d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7b11: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7b15: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7b19: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7b1d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7b21: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7b25: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7b29: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7b2d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7b31: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7b35: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7b39: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7b3d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7b41: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7b45: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7b49: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7b4d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7b51: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7b55: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7b59: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7b5d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7b61: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7b65: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7b69: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7b6d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7b71: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7b75: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7b79: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7b7d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7b81: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7b85: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7b89: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7b8d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7b91: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7b95: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7b99: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7b9d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7ba1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7ba5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7ba9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7bad: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7bb1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7bb5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7bb9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7bbd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7bc1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7bc5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7bc9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7bcd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7bd1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7bd5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7bd9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7bdd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7be1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7be5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7be9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7bed: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7bf1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7bf5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7bf9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7bfd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7c01: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7c05: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7c09: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7c0d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7c11: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7c15: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7c19: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7c1d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7c21: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7c25: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7c29: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7c2d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7c31: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7c35: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7c39: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7c3d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7c41: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7c45: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7c49: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7c4d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7c51: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7c55: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7c59: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7c5d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7c61: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7c65: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7c69: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7c6d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7c71: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7c75: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7c79: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7c7d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7c81: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7c85: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7c89: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7c8d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7c91: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7c95: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7c99: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7c9d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7ca1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7ca5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7ca9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7cad: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7cb1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7cb5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7cb9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7cbd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7cc1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7cc5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7cc9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7ccd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7cd1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7cd5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7cd9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7cdd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7ce1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7ce5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7ce9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7ced: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7cf1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7cf5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7cf9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7cfd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7d01: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7d05: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7d09: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7d0d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7d11: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7d15: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7d19: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7d1d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7d21: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7d25: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7d29: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7d2d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7d31: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7d35: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7d39: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7d3d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7d41: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7d45: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7d49: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7d4d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7d51: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7d55: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7d59: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7d5d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7d61: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7d65: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7d69: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7d6d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7d71: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7d75: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7d79: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7d7d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7d81: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7d85: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7d89: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7d8d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7d91: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7d95: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7d99: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7d9d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7da1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7da5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7da9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7dad: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7db1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7db5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7db9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7dbd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7dc1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7dc5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7dc9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7dcd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7dd1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7dd5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7dd9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7ddd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7de1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7de5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7de9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7ded: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7df1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7df5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7df9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7dfd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7e01: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7e05: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7e09: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7e0d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7e11: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7e15: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7e19: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7e1d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7e21: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7e25: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7e29: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7e2d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7e31: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7e35: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7e39: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7e3d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7e41: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7e45: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7e49: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7e4d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7e51: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7e55: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7e59: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7e5d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7e61: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7e65: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7e69: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7e6d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7e71: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7e75: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7e79: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7e7d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7e81: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7e85: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7e89: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7e8d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7e91: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7e95: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7e99: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7e9d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7ea1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7ea5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7ea9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7ead: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7eb1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7eb5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7eb9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7ebd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7ec1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7ec5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7ec9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7ecd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7ed1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7ed5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7ed9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7edd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7ee1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7ee5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7ee9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7eed: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7ef1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7ef5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7ef9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7efd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7f01: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7f05: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7f09: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7f0d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7f11: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7f15: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7f19: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7f1d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7f21: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7f25: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7f29: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7f2d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7f31: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7f35: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7f39: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7f3d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7f41: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7f45: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7f49: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7f4d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7f51: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7f55: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7f59: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7f5d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7f61: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7f65: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7f69: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7f6d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7f71: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7f75: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7f79: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7f7d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7f81: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7f85: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7f89: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7f8d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7f91: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7f95: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7f99: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7f9d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7fa1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7fa5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7fa9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7fad: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7fb1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7fb5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7fb9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7fbd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7fc1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7fc5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7fc9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7fcd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7fd1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7fd5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7fd9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7fdd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7fe1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7fe5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7fe9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7fed: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7ff1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7ff5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x7ff9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x7ffd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8001: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8005: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8009: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x800d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8011: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8015: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8019: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x801d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8021: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8025: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8029: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x802d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8031: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8035: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8039: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x803d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8041: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8045: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8049: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x804d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8051: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8055: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8059: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x805d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8061: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8065: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8069: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x806d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8071: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8075: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8079: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x807d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8081: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8085: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8089: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x808d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8091: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8095: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8099: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x809d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x80a1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x80a5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x80a9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x80ad: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x80b1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x80b5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x80b9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x80bd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x80c1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x80c5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x80c9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x80cd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x80d1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x80d5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x80d9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x80dd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x80e1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x80e5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x80e9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x80ed: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x80f1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x80f5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x80f9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x80fd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8101: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8105: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8109: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x810d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8111: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8115: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8119: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x811d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8121: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8125: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8129: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x812d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8131: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8135: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8139: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x813d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8141: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8145: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8149: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x814d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8151: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8155: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8159: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x815d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8161: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8165: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8169: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x816d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8171: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8175: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8179: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x817d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8181: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8185: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8189: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x818d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8191: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8195: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8199: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x819d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x81a1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x81a5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x81a9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x81ad: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x81b1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x81b5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x81b9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x81bd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x81c1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x81c5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x81c9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x81cd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x81d1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x81d5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x81d9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x81dd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x81e1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x81e5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x81e9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x81ed: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x81f1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x81f5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x81f9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x81fd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8201: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8205: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8209: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x820d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8211: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8215: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8219: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x821d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8221: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8225: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8229: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x822d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8231: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8235: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8239: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x823d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8241: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8245: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8249: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x824d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8251: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8255: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8259: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x825d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8261: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8265: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8269: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x826d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8271: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8275: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8279: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x827d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8281: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8285: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8289: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x828d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8291: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8295: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8299: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x829d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x82a1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x82a5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x82a9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x82ad: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x82b1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x82b5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x82b9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x82bd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x82c1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x82c5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x82c9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x82cd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x82d1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x82d5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x82d9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x82dd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x82e1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x82e5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x82e9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x82ed: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x82f1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x82f5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x82f9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x82fd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8301: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8305: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8309: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x830d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8311: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8315: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8319: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x831d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8321: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8325: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8329: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x832d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8331: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8335: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8339: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x833d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8341: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8345: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8349: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x834d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8351: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8355: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8359: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x835d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8361: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8365: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8369: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x836d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8371: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8375: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8379: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x837d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8381: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8385: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8389: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x838d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8391: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8395: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8399: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x839d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x83a1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x83a5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x83a9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x83ad: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x83b1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x83b5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x83b9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x83bd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x83c1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x83c5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x83c9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x83cd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x83d1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x83d5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x83d9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x83dd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x83e1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x83e5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x83e9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x83ed: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x83f1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x83f5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x83f9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x83fd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8401: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8405: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8409: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x840d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8411: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8415: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8419: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x841d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8421: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8425: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8429: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x842d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8431: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8435: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8439: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x843d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8441: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8445: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8449: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x844d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8451: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8455: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8459: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x845d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8461: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8465: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8469: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x846d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8471: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8475: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8479: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x847d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8481: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8485: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8489: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x848d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8491: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8495: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8499: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x849d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x84a1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x84a5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x84a9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x84ad: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x84b1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x84b5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x84b9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x84bd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x84c1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x84c5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x84c9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x84cd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x84d1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x84d5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x84d9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x84dd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x84e1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x84e5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x84e9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x84ed: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x84f1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x84f5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x84f9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x84fd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8501: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8505: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8509: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x850d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8511: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8515: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8519: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x851d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8521: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8525: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8529: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x852d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8531: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8535: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8539: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x853d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8541: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8545: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8549: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x854d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8551: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8555: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8559: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x855d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8561: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8565: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8569: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x856d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8571: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8575: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8579: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x857d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8581: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8585: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8589: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x858d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8591: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8595: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8599: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x859d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x85a1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x85a5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x85a9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x85ad: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x85b1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x85b5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x85b9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x85bd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x85c1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x85c5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x85c9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x85cd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x85d1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x85d5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x85d9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x85dd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x85e1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x85e5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x85e9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x85ed: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x85f1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x85f5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x85f9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x85fd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8601: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8605: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8609: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x860d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8611: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8615: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8619: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x861d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8621: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8625: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8629: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x862d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8631: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8635: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8639: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x863d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8641: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8645: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8649: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x864d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8651: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8655: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8659: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x865d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8661: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8665: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8669: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x866d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8671: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8675: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8679: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x867d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8681: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8685: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8689: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x868d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8691: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8695: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8699: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x869d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x86a1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x86a5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x86a9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x86ad: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x86b1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x86b5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x86b9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x86bd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x86c1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x86c5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x86c9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x86cd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x86d1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x86d5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x86d9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x86dd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x86e1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x86e5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x86e9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x86ed: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x86f1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x86f5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x86f9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x86fd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8701: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8705: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8709: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x870d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8711: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8715: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8719: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x871d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8721: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8725: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8729: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x872d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8731: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8735: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8739: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x873d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8741: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8745: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8749: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x874d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8751: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8755: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8759: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x875d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8761: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8765: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8769: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x876d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8771: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8775: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8779: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x877d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8781: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8785: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8789: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x878d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8791: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8795: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8799: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x879d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x87a1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x87a5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x87a9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x87ad: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x87b1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x87b5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x87b9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x87bd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x87c1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x87c5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x87c9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x87cd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x87d1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x87d5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x87d9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x87dd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x87e1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x87e5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x87e9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x87ed: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x87f1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x87f5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x87f9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x87fd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8801: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8805: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8809: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x880d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8811: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8815: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8819: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x881d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8821: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8825: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8829: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x882d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8831: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8835: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8839: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x883d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8841: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8845: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8849: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x884d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8851: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8855: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8859: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x885d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8861: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8865: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8869: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x886d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8871: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8875: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8879: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x887d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8881: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8885: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8889: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x888d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8891: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8895: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8899: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x889d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x88a1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x88a5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x88a9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x88ad: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x88b1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x88b5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x88b9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x88bd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x88c1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x88c5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x88c9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x88cd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x88d1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x88d5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x88d9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x88dd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x88e1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x88e5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x88e9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x88ed: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x88f1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x88f5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x88f9: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x88fd: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8901: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8905: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8909: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x890d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8911: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8915: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8919: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x891d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8921: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8925: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8929: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x892d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8931: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8935: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8939: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x893d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8941: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8945: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8949: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x894d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8951: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8955: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8959: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x895d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8961: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8965: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8969: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x896d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8971: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8975: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8979: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x897d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8981: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8985: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8989: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x898d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8991: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8995: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8999: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x899d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x89a1: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x89a5: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x89a9: test   r9b,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_TEST_IMM, X86_R9, X86_WIDTH_8, 1ULL);
	/* 0x89ad: jne    89b8 <choose_6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x89ad, 0x89b8, x86_l_89b8);
	/* 0x89af: lea    r10,[rip+0xc] */
	X86_SIM_X86_CODE_ADDRESS(X86_R10, 0x89c2ULL);
	/* 0x89b6: jmp    89bf <dispatch_6> */
	X86_SIM_X86_JMP(0x89b6, 0x89bf, x86_l_89bf);
x86_l_89b8:
	/* 0x89b8: lea    r10,[rip+0x9] */
	X86_SIM_X86_CODE_ADDRESS(X86_R10, 0x89c8ULL);
x86_l_89bf:
	/* 0x89bf: jmp    r10 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R10);
		switch (X86_SIM_L_REG_TAG(X86_R10)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x89c2ULL: goto x86_l_89c2;
			case 0x89c8ULL: goto x86_l_89c8;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_89c2:
	/* 0x89c2: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x89c6: jmp    89cc <join_6> */
	X86_SIM_X86_JMP(0x89c6, 0x89cc, x86_l_89cc);
x86_l_89c8:
	/* 0x89c8: add    r8,0x2 */
	fidelity_step_1(__x86_state);
x86_l_89cc:
	/* 0x89cc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x89d0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x89d4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x89d8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x89dc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x89e0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x89e4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x89e8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x89ec: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x89f0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x89f4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x89f8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x89fc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8a00: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8a04: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8a08: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8a0c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8a10: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8a14: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8a18: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8a1c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8a20: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8a24: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8a28: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8a2c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8a30: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8a34: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8a38: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8a3c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8a40: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8a44: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8a48: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8a4c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8a50: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8a54: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8a58: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8a5c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8a60: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8a64: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8a68: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8a6c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8a70: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8a74: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8a78: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8a7c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8a80: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8a84: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8a88: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8a8c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8a90: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8a94: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8a98: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8a9c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8aa0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8aa4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8aa8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8aac: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8ab0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8ab4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8ab8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8abc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8ac0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8ac4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8ac8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8acc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8ad0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8ad4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8ad8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8adc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8ae0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8ae4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8ae8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8aec: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8af0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8af4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8af8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8afc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8b00: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8b04: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8b08: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8b0c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8b10: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8b14: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8b18: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8b1c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8b20: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8b24: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8b28: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8b2c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8b30: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8b34: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8b38: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8b3c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8b40: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8b44: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8b48: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8b4c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8b50: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8b54: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8b58: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8b5c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8b60: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8b64: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8b68: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8b6c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8b70: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8b74: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8b78: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8b7c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8b80: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8b84: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8b88: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8b8c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8b90: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8b94: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8b98: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8b9c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8ba0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8ba4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8ba8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8bac: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8bb0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8bb4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8bb8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8bbc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8bc0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8bc4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8bc8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8bcc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8bd0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8bd4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8bd8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8bdc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8be0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8be4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8be8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8bec: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8bf0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8bf4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8bf8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8bfc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8c00: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8c04: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8c08: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8c0c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8c10: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8c14: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8c18: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8c1c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8c20: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8c24: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8c28: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8c2c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8c30: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8c34: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8c38: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8c3c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8c40: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8c44: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8c48: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8c4c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8c50: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8c54: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8c58: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8c5c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8c60: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8c64: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8c68: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8c6c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8c70: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8c74: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8c78: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8c7c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8c80: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8c84: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8c88: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8c8c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8c90: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8c94: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8c98: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8c9c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8ca0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8ca4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8ca8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8cac: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8cb0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8cb4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8cb8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8cbc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8cc0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8cc4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8cc8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8ccc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8cd0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8cd4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8cd8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8cdc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8ce0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8ce4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8ce8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8cec: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8cf0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8cf4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8cf8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8cfc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8d00: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8d04: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8d08: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8d0c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8d10: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8d14: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8d18: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8d1c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8d20: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8d24: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8d28: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8d2c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8d30: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8d34: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8d38: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8d3c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8d40: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8d44: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8d48: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8d4c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8d50: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8d54: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8d58: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8d5c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8d60: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8d64: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8d68: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8d6c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8d70: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8d74: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8d78: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8d7c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8d80: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8d84: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8d88: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8d8c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8d90: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8d94: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8d98: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8d9c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8da0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8da4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8da8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8dac: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8db0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8db4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8db8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8dbc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8dc0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8dc4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8dc8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8dcc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8dd0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8dd4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8dd8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8ddc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8de0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8de4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8de8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8dec: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8df0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8df4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8df8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8dfc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8e00: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8e04: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8e08: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8e0c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8e10: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8e14: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8e18: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8e1c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8e20: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8e24: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8e28: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8e2c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8e30: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8e34: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8e38: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8e3c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8e40: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8e44: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8e48: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8e4c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8e50: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8e54: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8e58: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8e5c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8e60: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8e64: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8e68: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8e6c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8e70: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8e74: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8e78: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8e7c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8e80: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8e84: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8e88: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8e8c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8e90: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8e94: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8e98: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8e9c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8ea0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8ea4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8ea8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8eac: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8eb0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8eb4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8eb8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8ebc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8ec0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8ec4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8ec8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8ecc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8ed0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8ed4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8ed8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8edc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8ee0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8ee4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8ee8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8eec: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8ef0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8ef4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8ef8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8efc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8f00: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8f04: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8f08: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8f0c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8f10: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8f14: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8f18: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8f1c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8f20: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8f24: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8f28: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8f2c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8f30: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8f34: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8f38: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8f3c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8f40: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8f44: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8f48: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8f4c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8f50: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8f54: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8f58: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8f5c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8f60: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8f64: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8f68: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8f6c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8f70: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8f74: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8f78: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8f7c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8f80: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8f84: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8f88: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8f8c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8f90: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8f94: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8f98: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8f9c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8fa0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8fa4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8fa8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8fac: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8fb0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8fb4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8fb8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8fbc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8fc0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8fc4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8fc8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8fcc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8fd0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8fd4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8fd8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8fdc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8fe0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8fe4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8fe8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8fec: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8ff0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8ff4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x8ff8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x8ffc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9000: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9004: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9008: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x900c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9010: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9014: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9018: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x901c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9020: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9024: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9028: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x902c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9030: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9034: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9038: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x903c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9040: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9044: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9048: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x904c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9050: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9054: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9058: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x905c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9060: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9064: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9068: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x906c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9070: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9074: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9078: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x907c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9080: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9084: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9088: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x908c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9090: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9094: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9098: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x909c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x90a0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x90a4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x90a8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x90ac: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x90b0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x90b4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x90b8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x90bc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x90c0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x90c4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x90c8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x90cc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x90d0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x90d4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x90d8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x90dc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x90e0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x90e4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x90e8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x90ec: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x90f0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x90f4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x90f8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x90fc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9100: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9104: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9108: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x910c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9110: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9114: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9118: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x911c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9120: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9124: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9128: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x912c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9130: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9134: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9138: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x913c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9140: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9144: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9148: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x914c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9150: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9154: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9158: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x915c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9160: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9164: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9168: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x916c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9170: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9174: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9178: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x917c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9180: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9184: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9188: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x918c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9190: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9194: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9198: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x919c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x91a0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x91a4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x91a8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x91ac: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x91b0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x91b4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x91b8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x91bc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x91c0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x91c4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x91c8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x91cc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x91d0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x91d4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x91d8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x91dc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x91e0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x91e4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x91e8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x91ec: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x91f0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x91f4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x91f8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x91fc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9200: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9204: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9208: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x920c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9210: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9214: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9218: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x921c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9220: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9224: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9228: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x922c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9230: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9234: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9238: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x923c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9240: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9244: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9248: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x924c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9250: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9254: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9258: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x925c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9260: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9264: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9268: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x926c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9270: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9274: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9278: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x927c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9280: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9284: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9288: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x928c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9290: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9294: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9298: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x929c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x92a0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x92a4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x92a8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x92ac: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x92b0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x92b4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x92b8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x92bc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x92c0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x92c4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x92c8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x92cc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x92d0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x92d4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x92d8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x92dc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x92e0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x92e4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x92e8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x92ec: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x92f0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x92f4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x92f8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x92fc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9300: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9304: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9308: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x930c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9310: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9314: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9318: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x931c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9320: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9324: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9328: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x932c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9330: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9334: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9338: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x933c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9340: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9344: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9348: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x934c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9350: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9354: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9358: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x935c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9360: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9364: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9368: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x936c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9370: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9374: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9378: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x937c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9380: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9384: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9388: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x938c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9390: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9394: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9398: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x939c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x93a0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x93a4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x93a8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x93ac: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x93b0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x93b4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x93b8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x93bc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x93c0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x93c4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x93c8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x93cc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x93d0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x93d4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x93d8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x93dc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x93e0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x93e4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x93e8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x93ec: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x93f0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x93f4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x93f8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x93fc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9400: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9404: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9408: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x940c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9410: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9414: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9418: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x941c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9420: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9424: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9428: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x942c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9430: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9434: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9438: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x943c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9440: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9444: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9448: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x944c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9450: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9454: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9458: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x945c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9460: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9464: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9468: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x946c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9470: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9474: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9478: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x947c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9480: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9484: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9488: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x948c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9490: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9494: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9498: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x949c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x94a0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x94a4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x94a8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x94ac: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x94b0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x94b4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x94b8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x94bc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x94c0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x94c4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x94c8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x94cc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x94d0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x94d4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x94d8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x94dc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x94e0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x94e4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x94e8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x94ec: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x94f0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x94f4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x94f8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x94fc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9500: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9504: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9508: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x950c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9510: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9514: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9518: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x951c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9520: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9524: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9528: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x952c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9530: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9534: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9538: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x953c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9540: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9544: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9548: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x954c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9550: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9554: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9558: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x955c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9560: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9564: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9568: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x956c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9570: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9574: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9578: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x957c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9580: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9584: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9588: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x958c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9590: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9594: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9598: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x959c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x95a0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x95a4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x95a8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x95ac: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x95b0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x95b4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x95b8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x95bc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x95c0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x95c4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x95c8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x95cc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x95d0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x95d4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x95d8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x95dc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x95e0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x95e4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x95e8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x95ec: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x95f0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x95f4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x95f8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x95fc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9600: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9604: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9608: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x960c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9610: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9614: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9618: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x961c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9620: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9624: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9628: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x962c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9630: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9634: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9638: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x963c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9640: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9644: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9648: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x964c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9650: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9654: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9658: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x965c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9660: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9664: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9668: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x966c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9670: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9674: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9678: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x967c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9680: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9684: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9688: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x968c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9690: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9694: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9698: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x969c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x96a0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x96a4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x96a8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x96ac: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x96b0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x96b4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x96b8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x96bc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x96c0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x96c4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x96c8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x96cc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x96d0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x96d4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x96d8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x96dc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x96e0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x96e4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x96e8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x96ec: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x96f0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x96f4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x96f8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x96fc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9700: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9704: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9708: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x970c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9710: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9714: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9718: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x971c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9720: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9724: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9728: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x972c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9730: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9734: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9738: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x973c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9740: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9744: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9748: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x974c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9750: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9754: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9758: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x975c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9760: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9764: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9768: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x976c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9770: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9774: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9778: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x977c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9780: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9784: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9788: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x978c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9790: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9794: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9798: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x979c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x97a0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x97a4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x97a8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x97ac: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x97b0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x97b4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x97b8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x97bc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x97c0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x97c4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x97c8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x97cc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x97d0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x97d4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x97d8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x97dc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x97e0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x97e4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x97e8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x97ec: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x97f0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x97f4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x97f8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x97fc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9800: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9804: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9808: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x980c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9810: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9814: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9818: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x981c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9820: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9824: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9828: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x982c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9830: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9834: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9838: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x983c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9840: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9844: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9848: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x984c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9850: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9854: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9858: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x985c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9860: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9864: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9868: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x986c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9870: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9874: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9878: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x987c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9880: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9884: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9888: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x988c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9890: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9894: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9898: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x989c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x98a0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x98a4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x98a8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x98ac: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x98b0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x98b4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x98b8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x98bc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x98c0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x98c4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x98c8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x98cc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x98d0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x98d4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x98d8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x98dc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x98e0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x98e4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x98e8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x98ec: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x98f0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x98f4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x98f8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x98fc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9900: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9904: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9908: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x990c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9910: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9914: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9918: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x991c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9920: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9924: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9928: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x992c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9930: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9934: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9938: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x993c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9940: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9944: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9948: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x994c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9950: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9954: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9958: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x995c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9960: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9964: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9968: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x996c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9970: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9974: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9978: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x997c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9980: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9984: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9988: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x998c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9990: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9994: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9998: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x999c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x99a0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x99a4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x99a8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x99ac: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x99b0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x99b4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x99b8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x99bc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x99c0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x99c4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x99c8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x99cc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x99d0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x99d4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x99d8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x99dc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x99e0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x99e4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x99e8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x99ec: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x99f0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x99f4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x99f8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x99fc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9a00: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9a04: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9a08: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9a0c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9a10: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9a14: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9a18: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9a1c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9a20: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9a24: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9a28: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9a2c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9a30: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9a34: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9a38: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9a3c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9a40: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9a44: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9a48: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9a4c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9a50: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9a54: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9a58: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9a5c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9a60: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9a64: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9a68: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9a6c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9a70: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9a74: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9a78: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9a7c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9a80: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9a84: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9a88: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9a8c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9a90: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9a94: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9a98: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9a9c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9aa0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9aa4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9aa8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9aac: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9ab0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9ab4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9ab8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9abc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9ac0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9ac4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9ac8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9acc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9ad0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9ad4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9ad8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9adc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9ae0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9ae4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9ae8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9aec: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9af0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9af4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9af8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9afc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9b00: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9b04: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9b08: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9b0c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9b10: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9b14: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9b18: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9b1c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9b20: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9b24: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9b28: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9b2c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9b30: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9b34: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9b38: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9b3c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9b40: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9b44: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9b48: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9b4c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9b50: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9b54: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9b58: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9b5c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9b60: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9b64: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9b68: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9b6c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9b70: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9b74: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9b78: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9b7c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9b80: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9b84: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9b88: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9b8c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9b90: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9b94: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9b98: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9b9c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9ba0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9ba4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9ba8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9bac: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9bb0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9bb4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9bb8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9bbc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9bc0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9bc4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9bc8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9bcc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9bd0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9bd4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9bd8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9bdc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9be0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9be4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9be8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9bec: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9bf0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9bf4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9bf8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9bfc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9c00: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9c04: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9c08: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9c0c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9c10: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9c14: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9c18: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9c1c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9c20: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9c24: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9c28: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9c2c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9c30: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9c34: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9c38: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9c3c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9c40: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9c44: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9c48: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9c4c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9c50: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9c54: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9c58: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9c5c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9c60: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9c64: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9c68: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9c6c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9c70: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9c74: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9c78: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9c7c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9c80: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9c84: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9c88: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9c8c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9c90: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9c94: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9c98: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9c9c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9ca0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9ca4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9ca8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9cac: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9cb0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9cb4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9cb8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9cbc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9cc0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9cc4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9cc8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9ccc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9cd0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9cd4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9cd8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9cdc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9ce0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9ce4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9ce8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9cec: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9cf0: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9cf4: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9cf8: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9cfc: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9d00: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9d04: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9d08: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9d0c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9d10: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9d14: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9d18: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9d1c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9d20: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9d24: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9d28: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9d2c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9d30: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9d34: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9d38: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9d3c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9d40: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9d44: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9d48: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9d4c: imul   r8,r8,0x3 */
	fidelity_step_2(__x86_state);
	/* 0x9d50: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9d54: test   r9b,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_TEST_IMM, X86_R9, X86_WIDTH_8, 1ULL);
	/* 0x9d58: jne    9d63 <choose_7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x9d58, 0x9d63, x86_l_9d63);
	/* 0x9d5a: lea    r10,[rip+0xc] */
	X86_SIM_X86_CODE_ADDRESS(X86_R10, 0x9d6dULL);
	/* 0x9d61: jmp    9d6a <dispatch_7> */
	X86_SIM_X86_JMP(0x9d61, 0x9d6a, x86_l_9d6a);
x86_l_9d63:
	/* 0x9d63: lea    r10,[rip+0x9] */
	X86_SIM_X86_CODE_ADDRESS(X86_R10, 0x9d73ULL);
x86_l_9d6a:
	/* 0x9d6a: jmp    r10 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R10);
		switch (X86_SIM_L_REG_TAG(X86_R10)) {
		case X86_SIM_TAG_CODE:
			switch (__x86_target) {
			case 0x9d6dULL: goto x86_l_9d6d;
			case 0x9d73ULL: goto x86_l_9d73;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_9d6d:
	/* 0x9d6d: add    r8,0x1 */
	fidelity_step_0(__x86_state);
	/* 0x9d71: jmp    9d77 <join_7> */
	X86_SIM_X86_JMP(0x9d71, 0x9d77, x86_l_9d77);
x86_l_9d73:
	/* 0x9d73: add    r8,0x2 */
	fidelity_step_1(__x86_state);
x86_l_9d77:
	/* 0x9d77: mov    QWORD PTR [rsi],r8 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSI, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
	/* 0x9d7a: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
	/* 0x9d7f: ret */
	X86_SIM_X86_RET();
x86_l_9d80:
	/* 0x9d80: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
	/* 0x9d82: ret */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
