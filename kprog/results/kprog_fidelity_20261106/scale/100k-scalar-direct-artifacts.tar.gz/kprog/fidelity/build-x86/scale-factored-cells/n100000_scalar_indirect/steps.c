#include "/workspaces/.agent-state/kprog-lanes/F/scale-regref-width/snapshot/kprog/x86/x86_sim_local_bpf.h"

extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));

__attribute__((always_inline)) void fidelity_step_0(union x86_sim_gpr *r8, __u8 *tag, __u8 *cf, __u8 *zf, __u8 *sf, __u8 *of) { X86_SIM_L_DECLARE_STATE(); __x86_r8=*r8;__x86_r8_tag=*tag;__x86_cf=*cf;__x86_zf=*zf;__x86_sf=*sf;__x86_of=*of;X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);*r8=__x86_r8;*tag=__x86_r8_tag;*cf=__x86_cf;*zf=__x86_zf;*sf=__x86_sf;*of=__x86_of; }
__attribute__((always_inline)) void fidelity_step_1(union x86_sim_gpr *r8, __u8 *tag, __u8 *cf, __u8 *zf, __u8 *sf, __u8 *of) { X86_SIM_L_DECLARE_STATE(); __x86_r8=*r8;__x86_r8_tag=*tag;__x86_cf=*cf;__x86_zf=*zf;__x86_sf=*sf;__x86_of=*of;X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 2ULL);*r8=__x86_r8;*tag=__x86_r8_tag;*cf=__x86_cf;*zf=__x86_zf;*sf=__x86_sf;*of=__x86_of; }
__attribute__((always_inline)) void fidelity_step_2(union x86_sim_gpr *r8, __u8 *tag, __u8 *cf, __u8 *zf, __u8 *sf, __u8 *of) { X86_SIM_L_DECLARE_STATE(); __x86_r8=*r8;__x86_r8_tag=*tag;__x86_cf=*cf;__x86_zf=*zf;__x86_sf=*sf;__x86_of=*of;X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);*r8=__x86_r8;*tag=__x86_r8_tag;*cf=__x86_cf;*zf=__x86_zf;*sf=__x86_sf;*of=__x86_of; }
