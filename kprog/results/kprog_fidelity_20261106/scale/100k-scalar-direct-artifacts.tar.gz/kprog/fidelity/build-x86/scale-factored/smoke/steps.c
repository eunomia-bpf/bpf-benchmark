#define X86_SIM_USE_STATE_STRUCT
#include "/workspaces/.agent-state/kprog-lanes/F/scale-regref-width/snapshot/kprog/x86/x86_sim_local_bpf.h"

extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));

__attribute__((always_inline)) void fidelity_step_0(struct x86_sim_state *__x86_state) { X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL); }
__attribute__((always_inline)) void fidelity_step_1(struct x86_sim_state *__x86_state) { X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 2ULL); }
__attribute__((always_inline)) void fidelity_step_2(struct x86_sim_state *__x86_state) { X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL); }
