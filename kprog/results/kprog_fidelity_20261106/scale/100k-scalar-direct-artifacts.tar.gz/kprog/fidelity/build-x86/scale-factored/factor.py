from pathlib import Path
import re
from collections import Counter
import sys
source=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
s=source.read_text()
first=s.index('SEC(')
prefix='#define X86_SIM_USE_STATE_STRUCT\n'+s[:first]
body=s[first:]
forms=sorted(set(re.findall(r'^\s*(X86_SIM_L_EXEC_(?:IMUL_IMM|ALU_IMM)\([^\n]+\));',body,re.M)))
if not forms:raise RuntimeError('no arithmetic forms')
prototypes=[];helpers=[]
for index,form in enumerate(forms):
    name='fidelity_step_'+str(index)
    prototypes.append('__attribute__((always_inline)) void '+name+'(struct x86_sim_state *);')
    helpers.append('__attribute__((always_inline)) void '+name+'(struct x86_sim_state *__x86_state) { '+form+'; }')
    body=body.replace(form+';',name+'(__x86_state);')
entry='''struct x86_sim_state state;
 X86_SIM_L_BIND_COMMON_STATE(&state);
 struct x86_sim_xdp_abi __x86_sim_abi = {.data=(void *)(long)ctx->data,.data_end=(void *)(long)ctx->data_end};
 state.skb_ctx=(void *)0; state.abi_kind=KPROG_ABI_KIND_XDP;
#define INIT_REG(REG, NAME) state.NAME.ptr=(void *)0; state.NAME##_tag=X86_SIM_TAG_SCALAR;
 X86_SIM_L_FOR_EACH_GPR(INIT_REG)
#undef INIT_REG
 state.cf=0;state.zf=0;state.sf=0;state.of=0;state.xmm0_lo=0;state.xmm0_hi=0;state.ret_addr=0;
 state.rdi.ptr=&__x86_sim_abi;state.rdi_tag=X86_SIM_TAG_ABI;'''
if body.count('X86_SIM_ENTRY_XDP(ctx);')!=1:raise RuntimeError('unexpected entry')
body=body.replace('X86_SIM_ENTRY_XDP(ctx);',entry)
# Remove only labels without a static textual reference. Preserve every instruction and branch.
counts=Counter(re.findall(r'\bx86_l_[a-f0-9]+\b',body))
body=re.sub(r'^(x86_l_[a-f0-9]+):\n',lambda m: '' if counts[m[1]]==1 else m[0],body,flags=re.M)
(out/'program.bpf.c').write_text(prefix+'\n'.join(prototypes)+'\n'+body)
(out/'steps.c').write_text(prefix+'\n'.join(helpers)+'\n')
(out/'forms.txt').write_text('\n'.join(forms)+'\n')
print(source, len(forms), 'factored forms')
