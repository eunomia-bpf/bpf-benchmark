from pathlib import Path
from collections import Counter
import re
import sys
source=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
s=source.read_text();first=s.index('SEC(');prefix=s[:first];body=s[first:]
forms=sorted(set(re.findall(r'^\s*(X86_SIM_L_EXEC_(?:IMUL_IMM|ALU_IMM)\([^\n]+\));',body,re.M)))
if not forms:raise RuntimeError('no arithmetic forms')
prototypes=[];helpers=[]
for index,form in enumerate(forms):
    regs=set(re.findall(r'\bX86_R[A-Z0-9]+\b',form))
    if regs!={'X86_R8'}:raise RuntimeError('cell closure not implemented for '+form)
    name='fidelity_step_'+str(index)
    args='union x86_sim_gpr *r8, __u8 *tag, __u8 *cf, __u8 *zf, __u8 *sf, __u8 *of'
    prototypes.append('__attribute__((always_inline)) void '+name+'('+args+');')
    helpers.append('__attribute__((always_inline)) void '+name+'('+args+') { X86_SIM_L_DECLARE_STATE(); __x86_r8=*r8;__x86_r8_tag=*tag;__x86_cf=*cf;__x86_zf=*zf;__x86_sf=*sf;__x86_of=*of;'+form+';*r8=__x86_r8;*tag=__x86_r8_tag;*cf=__x86_cf;*zf=__x86_zf;*sf=__x86_sf;*of=__x86_of; }')
    body=body.replace(form+';',name+'(&__x86_r8,&__x86_r8_tag,&__x86_cf,&__x86_zf,&__x86_sf,&__x86_of);')
counts=Counter(re.findall(r'\bx86_l_[a-f0-9]+\b',body))
body=re.sub(r'^(x86_l_[a-f0-9]+):\n',lambda m: '' if counts[m[1]]==1 else m[0],body,flags=re.M)
(out/'program.bpf.c').write_text(prefix+'\n'.join(prototypes)+'\n'+body)
(out/'steps.c').write_text(prefix+'\n'.join(helpers)+'\n')
(out/'forms.txt').write_text('\n'.join(forms)+'\n')
(out/'entry.txt').write_text(re.search(r'int (\w+)\(',body)[1]+'\n')
print(source,len(forms),'factored forms')
