#line 1 "program.bpf.c"
#include "/workspaces/.agent-state/kprog-lanes/F/scale-regref-width/snapshot/kprog/x86/x86_sim_local_bpf.h"


__KPROG_FIDELITY_CHUNK_BEGIN__
#line 300003 "program.bpf.c"
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_61a71:
	/* 0x61a71: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_61a75:
	/* 0x61a75: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_61a79:
	/* 0x61a79: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_61a7d:
	/* 0x61a7d: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_61a81:
	/* 0x61a81: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_61a85:
	/* 0x61a85: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_61a89:
	/* 0x61a89: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_61a8d:
	/* 0x61a8d: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_61a91:
	/* 0x61a91: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_61a95:
	/* 0x61a95: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_61a99:
	/* 0x61a99: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_61a9d:
	/* 0x61a9d: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_61aa1:
	/* 0x61aa1: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_61aa5:
	/* 0x61aa5: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_61aa9:
	/* 0x61aa9: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_61aad:
	/* 0x61aad: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_61ab1:
	/* 0x61ab1: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_61ab5:
	/* 0x61ab5: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_61ab9:
	/* 0x61ab9: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_61abd:
	/* 0x61abd: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_61ac1:
	/* 0x61ac1: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_61ac5:
	/* 0x61ac5: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_61ac9:
	/* 0x61ac9: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_61acd:
	/* 0x61acd: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_61ad1:
	/* 0x61ad1: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_61ad5:
	/* 0x61ad5: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_61ad9:
	/* 0x61ad9: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_61add:
	/* 0x61add: imul   r8,r8,0x3 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_R8, X86_R8, X86_WIDTH_64, 3ULL);
x86_l_61ae1:
	/* 0x61ae1: add    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_ADD, 1ULL);
x86_l_61ae5:
	/* 0x61ae5: test   r9b,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_TEST_IMM, X86_R9, X86_WIDTH_8, 1ULL);
x86_l_61ae9:
	/* 0x61ae9: je     61aef <join_7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x61ae9, 0x61aef, x86_l_61aef);
x86_l_61aeb:
	/* 0x61aeb: xor    r8,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R8, X86_WIDTH_64, X86_ALU_XOR, 1ULL);
x86_l_61aef:
	/* 0x61aef: mov    QWORD PTR [rsi],r8 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSI, X86_R8, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_61af2:
	/* 0x61af2: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_61af7:
	/* 0x61af7: ret */
	X86_SIM_X86_RET();
x86_l_61af8:
	/* 0x61af8: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_61afa:
	/* 0x61afa: ret */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
