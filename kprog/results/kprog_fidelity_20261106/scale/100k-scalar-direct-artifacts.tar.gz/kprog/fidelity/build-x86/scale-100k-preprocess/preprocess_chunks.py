from pathlib import Path
import json
import subprocess
import sys

source, output = map(Path, sys.argv[1:])
lines = source.read_text().splitlines(keepends=True)
first = next(i for i, line in enumerate(lines) if line.startswith('SEC('))
prefix = ''.join(lines[:first])
root = Path('/workspaces/repository')
command = ['clang', '-E', '-P', '-target', 'bpf',
           '-I'+str(root/'vendor/libbpf/include/uapi'),
           '-I'+str(root/'vendor/libbpf/src'), '-I/usr/include/x86_64-linux-gnu']
marker = '__KPROG_FIDELITY_CHUNK_BEGIN__'
with output.open('w') as merged:
    for begin in range(first, len(lines), 3000):
        chunk = output.with_suffix('.chunk.c')
        expanded = output.with_suffix('.chunk.i')
        chunk.write_text('#line 1 '+json.dumps(str(source))+'\n'+prefix+
                         '\n'+marker+'\n#line '+str(begin+1)+' '+json.dumps(str(source))+'\n'+
                         ''.join(lines[begin:begin+3000]))
        with expanded.open('w') as target:
            subprocess.run(command+[str(chunk)], stdout=target, check=True)
        head, separator, body = expanded.read_text().partition('\n'+marker+'\n')
        if not separator:
            raise RuntimeError('preprocessor chunk marker missing')
        if begin == first:
            merged.write(head+'\n')
        merged.write(body+'\n')
        print(f'preprocessed source lines {begin+1}..{min(begin+3000,len(lines))}', flush=True)
