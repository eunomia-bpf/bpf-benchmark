
build-x86-reference-stack/instructions.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <.text>:
   0:	53                                              	push   rbx
   1:	58                                              	pop    rax
   2:	66 53                                           	push   bx
   4:	66 58                                           	pop    ax
   6:	90                                              	nop
   7:	48 98                                           	cdqe
   9:	0f 10 07                                        	movups xmm0,XMMWORD PTR [rdi]
   c:	0f 11 07                                        	movups XMMWORD PTR [rdi],xmm0
   f:	88 d8                                           	mov    al,bl
  11:	b0 7f                                           	mov    al,0x7f
  13:	88 47 08                                        	mov    BYTE PTR [rdi+0x8],al
  16:	8a 47 08                                        	mov    al,BYTE PTR [rdi+0x8]
  19:	c6 47 08 7f                                     	mov    BYTE PTR [rdi+0x8],0x7f
  1d:	00 d8                                           	add    al,bl
  1f:	04 7f                                           	add    al,0x7f
  21:	00 47 08                                        	add    BYTE PTR [rdi+0x8],al
  24:	80 47 08 7f                                     	add    BYTE PTR [rdi+0x8],0x7f
  28:	02 47 08                                        	add    al,BYTE PTR [rdi+0x8]
  2b:	10 d8                                           	adc    al,bl
  2d:	14 7f                                           	adc    al,0x7f
  2f:	10 47 08                                        	adc    BYTE PTR [rdi+0x8],al
  32:	80 57 08 7f                                     	adc    BYTE PTR [rdi+0x8],0x7f
  36:	12 47 08                                        	adc    al,BYTE PTR [rdi+0x8]
  39:	28 d8                                           	sub    al,bl
  3b:	2c 7f                                           	sub    al,0x7f
  3d:	28 47 08                                        	sub    BYTE PTR [rdi+0x8],al
  40:	80 6f 08 7f                                     	sub    BYTE PTR [rdi+0x8],0x7f
  44:	2a 47 08                                        	sub    al,BYTE PTR [rdi+0x8]
  47:	18 d8                                           	sbb    al,bl
  49:	1c 7f                                           	sbb    al,0x7f
  4b:	18 47 08                                        	sbb    BYTE PTR [rdi+0x8],al
  4e:	80 5f 08 7f                                     	sbb    BYTE PTR [rdi+0x8],0x7f
  52:	1a 47 08                                        	sbb    al,BYTE PTR [rdi+0x8]
  55:	38 d8                                           	cmp    al,bl
  57:	3c 7f                                           	cmp    al,0x7f
  59:	38 47 08                                        	cmp    BYTE PTR [rdi+0x8],al
  5c:	80 7f 08 7f                                     	cmp    BYTE PTR [rdi+0x8],0x7f
  60:	3a 47 08                                        	cmp    al,BYTE PTR [rdi+0x8]
  63:	84 d8                                           	test   al,bl
  65:	a8 7f                                           	test   al,0x7f
  67:	84 47 08                                        	test   BYTE PTR [rdi+0x8],al
  6a:	f6 47 08 7f                                     	test   BYTE PTR [rdi+0x8],0x7f
  6e:	20 d8                                           	and    al,bl
  70:	24 7f                                           	and    al,0x7f
  72:	22 47 08                                        	and    al,BYTE PTR [rdi+0x8]
  75:	20 47 08                                        	and    BYTE PTR [rdi+0x8],al
  78:	80 67 08 7f                                     	and    BYTE PTR [rdi+0x8],0x7f
  7c:	08 d8                                           	or     al,bl
  7e:	0c 7f                                           	or     al,0x7f
  80:	0a 47 08                                        	or     al,BYTE PTR [rdi+0x8]
  83:	08 47 08                                        	or     BYTE PTR [rdi+0x8],al
  86:	80 4f 08 7f                                     	or     BYTE PTR [rdi+0x8],0x7f
  8a:	30 d8                                           	xor    al,bl
  8c:	34 7f                                           	xor    al,0x7f
  8e:	32 47 08                                        	xor    al,BYTE PTR [rdi+0x8]
  91:	30 47 08                                        	xor    BYTE PTR [rdi+0x8],al
  94:	80 77 08 7f                                     	xor    BYTE PTR [rdi+0x8],0x7f
  98:	fe c0                                           	inc    al
  9a:	fe 47 08                                        	inc    BYTE PTR [rdi+0x8]
  9d:	fe c8                                           	dec    al
  9f:	fe 4f 08                                        	dec    BYTE PTR [rdi+0x8]
  a2:	f6 d8                                           	neg    al
  a4:	f6 5f 08                                        	neg    BYTE PTR [rdi+0x8]
  a7:	f6 d0                                           	not    al
  a9:	f6 57 08                                        	not    BYTE PTR [rdi+0x8]
  ac:	86 d8                                           	xchg   al,bl
  ae:	c0 e0 00                                        	shl    al,0x0
  b1:	d0 e0                                           	shl    al,1
  b3:	c0 e0 07                                        	shl    al,0x7
  b6:	c0 e0 08                                        	shl    al,0x8
  b9:	c0 e0 0f                                        	shl    al,0xf
  bc:	c0 e0 10                                        	shl    al,0x10
  bf:	c0 e0 1f                                        	shl    al,0x1f
  c2:	c0 e0 20                                        	shl    al,0x20
  c5:	c0 e0 3f                                        	shl    al,0x3f
  c8:	c0 e0 40                                        	shl    al,0x40
  cb:	c0 e0 ff                                        	shl    al,0xff
  ce:	d2 e0                                           	shl    al,cl
  d0:	c0 e8 00                                        	shr    al,0x0
  d3:	d0 e8                                           	shr    al,1
  d5:	c0 e8 07                                        	shr    al,0x7
  d8:	c0 e8 08                                        	shr    al,0x8
  db:	c0 e8 0f                                        	shr    al,0xf
  de:	c0 e8 10                                        	shr    al,0x10
  e1:	c0 e8 1f                                        	shr    al,0x1f
  e4:	c0 e8 20                                        	shr    al,0x20
  e7:	c0 e8 3f                                        	shr    al,0x3f
  ea:	c0 e8 40                                        	shr    al,0x40
  ed:	c0 e8 ff                                        	shr    al,0xff
  f0:	d2 e8                                           	shr    al,cl
  f2:	c0 f8 00                                        	sar    al,0x0
  f5:	d0 f8                                           	sar    al,1
  f7:	c0 f8 07                                        	sar    al,0x7
  fa:	c0 f8 08                                        	sar    al,0x8
  fd:	c0 f8 0f                                        	sar    al,0xf
 100:	c0 f8 10                                        	sar    al,0x10
 103:	c0 f8 1f                                        	sar    al,0x1f
 106:	c0 f8 20                                        	sar    al,0x20
 109:	c0 f8 3f                                        	sar    al,0x3f
 10c:	c0 f8 40                                        	sar    al,0x40
 10f:	c0 f8 ff                                        	sar    al,0xff
 112:	d2 f8                                           	sar    al,cl
 114:	c0 c0 00                                        	rol    al,0x0
 117:	d0 c0                                           	rol    al,1
 119:	c0 c0 07                                        	rol    al,0x7
 11c:	c0 c0 08                                        	rol    al,0x8
 11f:	c0 c0 0f                                        	rol    al,0xf
 122:	c0 c0 10                                        	rol    al,0x10
 125:	c0 c0 1f                                        	rol    al,0x1f
 128:	c0 c0 20                                        	rol    al,0x20
 12b:	c0 c0 3f                                        	rol    al,0x3f
 12e:	c0 c0 40                                        	rol    al,0x40
 131:	c0 c0 ff                                        	rol    al,0xff
 134:	d2 c0                                           	rol    al,cl
 136:	66 89 d8                                        	mov    ax,bx
 139:	66 b8 7f 00                                     	mov    ax,0x7f
 13d:	66 89 47 08                                     	mov    WORD PTR [rdi+0x8],ax
 141:	66 8b 47 08                                     	mov    ax,WORD PTR [rdi+0x8]
 145:	66 c7 47 08 7f 00                               	mov    WORD PTR [rdi+0x8],0x7f
 14b:	66 01 d8                                        	add    ax,bx
 14e:	66 83 c0 7f                                     	add    ax,0x7f
 152:	66 01 47 08                                     	add    WORD PTR [rdi+0x8],ax
 156:	66 83 47 08 7f                                  	add    WORD PTR [rdi+0x8],0x7f
 15b:	66 03 47 08                                     	add    ax,WORD PTR [rdi+0x8]
 15f:	66 11 d8                                        	adc    ax,bx
 162:	66 83 d0 7f                                     	adc    ax,0x7f
 166:	66 11 47 08                                     	adc    WORD PTR [rdi+0x8],ax
 16a:	66 83 57 08 7f                                  	adc    WORD PTR [rdi+0x8],0x7f
 16f:	66 13 47 08                                     	adc    ax,WORD PTR [rdi+0x8]
 173:	66 29 d8                                        	sub    ax,bx
 176:	66 83 e8 7f                                     	sub    ax,0x7f
 17a:	66 29 47 08                                     	sub    WORD PTR [rdi+0x8],ax
 17e:	66 83 6f 08 7f                                  	sub    WORD PTR [rdi+0x8],0x7f
 183:	66 2b 47 08                                     	sub    ax,WORD PTR [rdi+0x8]
 187:	66 19 d8                                        	sbb    ax,bx
 18a:	66 83 d8 7f                                     	sbb    ax,0x7f
 18e:	66 19 47 08                                     	sbb    WORD PTR [rdi+0x8],ax
 192:	66 83 5f 08 7f                                  	sbb    WORD PTR [rdi+0x8],0x7f
 197:	66 1b 47 08                                     	sbb    ax,WORD PTR [rdi+0x8]
 19b:	66 39 d8                                        	cmp    ax,bx
 19e:	66 83 f8 7f                                     	cmp    ax,0x7f
 1a2:	66 39 47 08                                     	cmp    WORD PTR [rdi+0x8],ax
 1a6:	66 83 7f 08 7f                                  	cmp    WORD PTR [rdi+0x8],0x7f
 1ab:	66 3b 47 08                                     	cmp    ax,WORD PTR [rdi+0x8]
 1af:	66 85 d8                                        	test   ax,bx
 1b2:	66 a9 7f 00                                     	test   ax,0x7f
 1b6:	66 85 47 08                                     	test   WORD PTR [rdi+0x8],ax
 1ba:	66 f7 47 08 7f 00                               	test   WORD PTR [rdi+0x8],0x7f
 1c0:	66 21 d8                                        	and    ax,bx
 1c3:	66 83 e0 7f                                     	and    ax,0x7f
 1c7:	66 23 47 08                                     	and    ax,WORD PTR [rdi+0x8]
 1cb:	66 21 47 08                                     	and    WORD PTR [rdi+0x8],ax
 1cf:	66 83 67 08 7f                                  	and    WORD PTR [rdi+0x8],0x7f
 1d4:	66 09 d8                                        	or     ax,bx
 1d7:	66 83 c8 7f                                     	or     ax,0x7f
 1db:	66 0b 47 08                                     	or     ax,WORD PTR [rdi+0x8]
 1df:	66 09 47 08                                     	or     WORD PTR [rdi+0x8],ax
 1e3:	66 83 4f 08 7f                                  	or     WORD PTR [rdi+0x8],0x7f
 1e8:	66 31 d8                                        	xor    ax,bx
 1eb:	66 83 f0 7f                                     	xor    ax,0x7f
 1ef:	66 33 47 08                                     	xor    ax,WORD PTR [rdi+0x8]
 1f3:	66 31 47 08                                     	xor    WORD PTR [rdi+0x8],ax
 1f7:	66 83 77 08 7f                                  	xor    WORD PTR [rdi+0x8],0x7f
 1fc:	66 ff c0                                        	inc    ax
 1ff:	66 ff 47 08                                     	inc    WORD PTR [rdi+0x8]
 203:	66 ff c8                                        	dec    ax
 206:	66 ff 4f 08                                     	dec    WORD PTR [rdi+0x8]
 20a:	66 f7 d8                                        	neg    ax
 20d:	66 f7 5f 08                                     	neg    WORD PTR [rdi+0x8]
 211:	66 f7 d0                                        	not    ax
 214:	66 f7 57 08                                     	not    WORD PTR [rdi+0x8]
 218:	66 93                                           	xchg   bx,ax
 21a:	66 c1 e0 00                                     	shl    ax,0x0
 21e:	66 d1 e0                                        	shl    ax,1
 221:	66 c1 e0 07                                     	shl    ax,0x7
 225:	66 c1 e0 08                                     	shl    ax,0x8
 229:	66 c1 e0 0f                                     	shl    ax,0xf
 22d:	66 c1 e0 10                                     	shl    ax,0x10
 231:	66 c1 e0 1f                                     	shl    ax,0x1f
 235:	66 c1 e0 20                                     	shl    ax,0x20
 239:	66 c1 e0 3f                                     	shl    ax,0x3f
 23d:	66 c1 e0 40                                     	shl    ax,0x40
 241:	66 c1 e0 ff                                     	shl    ax,0xff
 245:	66 d3 e0                                        	shl    ax,cl
 248:	66 c1 e8 00                                     	shr    ax,0x0
 24c:	66 d1 e8                                        	shr    ax,1
 24f:	66 c1 e8 07                                     	shr    ax,0x7
 253:	66 c1 e8 08                                     	shr    ax,0x8
 257:	66 c1 e8 0f                                     	shr    ax,0xf
 25b:	66 c1 e8 10                                     	shr    ax,0x10
 25f:	66 c1 e8 1f                                     	shr    ax,0x1f
 263:	66 c1 e8 20                                     	shr    ax,0x20
 267:	66 c1 e8 3f                                     	shr    ax,0x3f
 26b:	66 c1 e8 40                                     	shr    ax,0x40
 26f:	66 c1 e8 ff                                     	shr    ax,0xff
 273:	66 d3 e8                                        	shr    ax,cl
 276:	66 c1 f8 00                                     	sar    ax,0x0
 27a:	66 d1 f8                                        	sar    ax,1
 27d:	66 c1 f8 07                                     	sar    ax,0x7
 281:	66 c1 f8 08                                     	sar    ax,0x8
 285:	66 c1 f8 0f                                     	sar    ax,0xf
 289:	66 c1 f8 10                                     	sar    ax,0x10
 28d:	66 c1 f8 1f                                     	sar    ax,0x1f
 291:	66 c1 f8 20                                     	sar    ax,0x20
 295:	66 c1 f8 3f                                     	sar    ax,0x3f
 299:	66 c1 f8 40                                     	sar    ax,0x40
 29d:	66 c1 f8 ff                                     	sar    ax,0xff
 2a1:	66 d3 f8                                        	sar    ax,cl
 2a4:	66 c1 c0 00                                     	rol    ax,0x0
 2a8:	66 d1 c0                                        	rol    ax,1
 2ab:	66 c1 c0 07                                     	rol    ax,0x7
 2af:	66 c1 c0 08                                     	rol    ax,0x8
 2b3:	66 c1 c0 0f                                     	rol    ax,0xf
 2b7:	66 c1 c0 10                                     	rol    ax,0x10
 2bb:	66 c1 c0 1f                                     	rol    ax,0x1f
 2bf:	66 c1 c0 20                                     	rol    ax,0x20
 2c3:	66 c1 c0 3f                                     	rol    ax,0x3f
 2c7:	66 c1 c0 40                                     	rol    ax,0x40
 2cb:	66 c1 c0 ff                                     	rol    ax,0xff
 2cf:	66 d3 c0                                        	rol    ax,cl
 2d2:	66 0f af c3                                     	imul   ax,bx
 2d6:	66 0f af 47 08                                  	imul   ax,WORD PTR [rdi+0x8]
 2db:	66 6b c3 f9                                     	imul   ax,bx,0xfff9
 2df:	66 6b 47 08 f9                                  	imul   ax,WORD PTR [rdi+0x8],0xfff9
 2e4:	66 f3 0f b8 c3                                  	popcnt ax,bx
 2e9:	66 f7 f3                                        	div    bx
 2ec:	66 0f a3 d8                                     	bt     ax,bx
 2f0:	66 0f ba e0 07                                  	bt     ax,0x7
 2f5:	66 0f ba 67 08 07                               	bt     WORD PTR [rdi+0x8],0x7
 2fb:	66 0f 38 f0 47 08                               	movbe  ax,WORD PTR [rdi+0x8]
 301:	66 0f 38 f1 47 08                               	movbe  WORD PTR [rdi+0x8],ax
 307:	66 0f a4 d8 00                                  	shld   ax,bx,0x0
 30c:	66 0f a4 d8 01                                  	shld   ax,bx,0x1
 311:	66 0f a4 d8 07                                  	shld   ax,bx,0x7
 316:	66 0f a4 d8 0f                                  	shld   ax,bx,0xf
 31b:	66 0f ac d8 00                                  	shrd   ax,bx,0x0
 320:	66 0f ac d8 01                                  	shrd   ax,bx,0x1
 325:	66 0f ac d8 07                                  	shrd   ax,bx,0x7
 32a:	66 0f ac d8 0f                                  	shrd   ax,bx,0xf
 32f:	89 d8                                           	mov    eax,ebx
 331:	b8 7f 00 00 00                                  	mov    eax,0x7f
 336:	89 47 08                                        	mov    DWORD PTR [rdi+0x8],eax
 339:	8b 47 08                                        	mov    eax,DWORD PTR [rdi+0x8]
 33c:	c7 47 08 7f 00 00 00                            	mov    DWORD PTR [rdi+0x8],0x7f
 343:	01 d8                                           	add    eax,ebx
 345:	83 c0 7f                                        	add    eax,0x7f
 348:	01 47 08                                        	add    DWORD PTR [rdi+0x8],eax
 34b:	83 47 08 7f                                     	add    DWORD PTR [rdi+0x8],0x7f
 34f:	03 47 08                                        	add    eax,DWORD PTR [rdi+0x8]
 352:	11 d8                                           	adc    eax,ebx
 354:	83 d0 7f                                        	adc    eax,0x7f
 357:	11 47 08                                        	adc    DWORD PTR [rdi+0x8],eax
 35a:	83 57 08 7f                                     	adc    DWORD PTR [rdi+0x8],0x7f
 35e:	13 47 08                                        	adc    eax,DWORD PTR [rdi+0x8]
 361:	29 d8                                           	sub    eax,ebx
 363:	83 e8 7f                                        	sub    eax,0x7f
 366:	29 47 08                                        	sub    DWORD PTR [rdi+0x8],eax
 369:	83 6f 08 7f                                     	sub    DWORD PTR [rdi+0x8],0x7f
 36d:	2b 47 08                                        	sub    eax,DWORD PTR [rdi+0x8]
 370:	19 d8                                           	sbb    eax,ebx
 372:	83 d8 7f                                        	sbb    eax,0x7f
 375:	19 47 08                                        	sbb    DWORD PTR [rdi+0x8],eax
 378:	83 5f 08 7f                                     	sbb    DWORD PTR [rdi+0x8],0x7f
 37c:	1b 47 08                                        	sbb    eax,DWORD PTR [rdi+0x8]
 37f:	39 d8                                           	cmp    eax,ebx
 381:	83 f8 7f                                        	cmp    eax,0x7f
 384:	39 47 08                                        	cmp    DWORD PTR [rdi+0x8],eax
 387:	83 7f 08 7f                                     	cmp    DWORD PTR [rdi+0x8],0x7f
 38b:	3b 47 08                                        	cmp    eax,DWORD PTR [rdi+0x8]
 38e:	85 d8                                           	test   eax,ebx
 390:	a9 7f 00 00 00                                  	test   eax,0x7f
 395:	85 47 08                                        	test   DWORD PTR [rdi+0x8],eax
 398:	f7 47 08 7f 00 00 00                            	test   DWORD PTR [rdi+0x8],0x7f
 39f:	21 d8                                           	and    eax,ebx
 3a1:	83 e0 7f                                        	and    eax,0x7f
 3a4:	23 47 08                                        	and    eax,DWORD PTR [rdi+0x8]
 3a7:	21 47 08                                        	and    DWORD PTR [rdi+0x8],eax
 3aa:	83 67 08 7f                                     	and    DWORD PTR [rdi+0x8],0x7f
 3ae:	09 d8                                           	or     eax,ebx
 3b0:	83 c8 7f                                        	or     eax,0x7f
 3b3:	0b 47 08                                        	or     eax,DWORD PTR [rdi+0x8]
 3b6:	09 47 08                                        	or     DWORD PTR [rdi+0x8],eax
 3b9:	83 4f 08 7f                                     	or     DWORD PTR [rdi+0x8],0x7f
 3bd:	31 d8                                           	xor    eax,ebx
 3bf:	83 f0 7f                                        	xor    eax,0x7f
 3c2:	33 47 08                                        	xor    eax,DWORD PTR [rdi+0x8]
 3c5:	31 47 08                                        	xor    DWORD PTR [rdi+0x8],eax
 3c8:	83 77 08 7f                                     	xor    DWORD PTR [rdi+0x8],0x7f
 3cc:	ff c0                                           	inc    eax
 3ce:	ff 47 08                                        	inc    DWORD PTR [rdi+0x8]
 3d1:	ff c8                                           	dec    eax
 3d3:	ff 4f 08                                        	dec    DWORD PTR [rdi+0x8]
 3d6:	f7 d8                                           	neg    eax
 3d8:	f7 5f 08                                        	neg    DWORD PTR [rdi+0x8]
 3db:	f7 d0                                           	not    eax
 3dd:	f7 57 08                                        	not    DWORD PTR [rdi+0x8]
 3e0:	93                                              	xchg   ebx,eax
 3e1:	c1 e0 00                                        	shl    eax,0x0
 3e4:	d1 e0                                           	shl    eax,1
 3e6:	c1 e0 07                                        	shl    eax,0x7
 3e9:	c1 e0 08                                        	shl    eax,0x8
 3ec:	c1 e0 0f                                        	shl    eax,0xf
 3ef:	c1 e0 10                                        	shl    eax,0x10
 3f2:	c1 e0 1f                                        	shl    eax,0x1f
 3f5:	c1 e0 20                                        	shl    eax,0x20
 3f8:	c1 e0 3f                                        	shl    eax,0x3f
 3fb:	c1 e0 40                                        	shl    eax,0x40
 3fe:	c1 e0 ff                                        	shl    eax,0xff
 401:	d3 e0                                           	shl    eax,cl
 403:	c1 e8 00                                        	shr    eax,0x0
 406:	d1 e8                                           	shr    eax,1
 408:	c1 e8 07                                        	shr    eax,0x7
 40b:	c1 e8 08                                        	shr    eax,0x8
 40e:	c1 e8 0f                                        	shr    eax,0xf
 411:	c1 e8 10                                        	shr    eax,0x10
 414:	c1 e8 1f                                        	shr    eax,0x1f
 417:	c1 e8 20                                        	shr    eax,0x20
 41a:	c1 e8 3f                                        	shr    eax,0x3f
 41d:	c1 e8 40                                        	shr    eax,0x40
 420:	c1 e8 ff                                        	shr    eax,0xff
 423:	d3 e8                                           	shr    eax,cl
 425:	c1 f8 00                                        	sar    eax,0x0
 428:	d1 f8                                           	sar    eax,1
 42a:	c1 f8 07                                        	sar    eax,0x7
 42d:	c1 f8 08                                        	sar    eax,0x8
 430:	c1 f8 0f                                        	sar    eax,0xf
 433:	c1 f8 10                                        	sar    eax,0x10
 436:	c1 f8 1f                                        	sar    eax,0x1f
 439:	c1 f8 20                                        	sar    eax,0x20
 43c:	c1 f8 3f                                        	sar    eax,0x3f
 43f:	c1 f8 40                                        	sar    eax,0x40
 442:	c1 f8 ff                                        	sar    eax,0xff
 445:	d3 f8                                           	sar    eax,cl
 447:	c1 c0 00                                        	rol    eax,0x0
 44a:	d1 c0                                           	rol    eax,1
 44c:	c1 c0 07                                        	rol    eax,0x7
 44f:	c1 c0 08                                        	rol    eax,0x8
 452:	c1 c0 0f                                        	rol    eax,0xf
 455:	c1 c0 10                                        	rol    eax,0x10
 458:	c1 c0 1f                                        	rol    eax,0x1f
 45b:	c1 c0 20                                        	rol    eax,0x20
 45e:	c1 c0 3f                                        	rol    eax,0x3f
 461:	c1 c0 40                                        	rol    eax,0x40
 464:	c1 c0 ff                                        	rol    eax,0xff
 467:	d3 c0                                           	rol    eax,cl
 469:	0f af c3                                        	imul   eax,ebx
 46c:	0f af 47 08                                     	imul   eax,DWORD PTR [rdi+0x8]
 470:	6b c3 f9                                        	imul   eax,ebx,0xfffffff9
 473:	6b 47 08 f9                                     	imul   eax,DWORD PTR [rdi+0x8],0xfffffff9
 477:	f3 0f b8 c3                                     	popcnt eax,ebx
 47b:	f7 f3                                           	div    ebx
 47d:	0f a3 d8                                        	bt     eax,ebx
 480:	0f ba e0 07                                     	bt     eax,0x7
 484:	0f ba 67 08 07                                  	bt     DWORD PTR [rdi+0x8],0x7
 489:	0f 38 f0 47 08                                  	movbe  eax,DWORD PTR [rdi+0x8]
 48e:	0f 38 f1 47 08                                  	movbe  DWORD PTR [rdi+0x8],eax
 493:	0f a4 d8 00                                     	shld   eax,ebx,0x0
 497:	0f a4 d8 01                                     	shld   eax,ebx,0x1
 49b:	0f a4 d8 07                                     	shld   eax,ebx,0x7
 49f:	0f a4 d8 0f                                     	shld   eax,ebx,0xf
 4a3:	0f ac d8 00                                     	shrd   eax,ebx,0x0
 4a7:	0f ac d8 01                                     	shrd   eax,ebx,0x1
 4ab:	0f ac d8 07                                     	shrd   eax,ebx,0x7
 4af:	0f ac d8 0f                                     	shrd   eax,ebx,0xf
 4b3:	8d 44 9f f9                                     	lea    eax,[rdi+rbx*4-0x7]
 4b7:	0f c8                                           	bswap  eax
 4b9:	c4 e2 60 f2 c1                                  	andn   eax,ebx,ecx
 4be:	c4 e2 60 f2 47 08                               	andn   eax,ebx,DWORD PTR [rdi+0x8]
 4c4:	c4 e2 70 f5 c3                                  	bzhi   eax,ebx,ecx
 4c9:	c4 e2 70 f5 47 08                               	bzhi   eax,DWORD PTR [rdi+0x8],ecx
 4cf:	c4 e2 63 f6 c1                                  	mulx   eax,ebx,ecx
 4d4:	c4 e2 71 f7 c3                                  	shlx   eax,ebx,ecx
 4d9:	c4 e2 71 f7 47 08                               	shlx   eax,DWORD PTR [rdi+0x8],ecx
 4df:	c4 e2 73 f7 c3                                  	shrx   eax,ebx,ecx
 4e4:	c4 e2 73 f7 47 08                               	shrx   eax,DWORD PTR [rdi+0x8],ecx
 4ea:	c4 e2 72 f7 c3                                  	sarx   eax,ebx,ecx
 4ef:	c4 e2 72 f7 47 08                               	sarx   eax,DWORD PTR [rdi+0x8],ecx
 4f5:	c4 e3 7b f0 c3 07                               	rorx   eax,ebx,0x7
 4fb:	c4 e3 7b f0 47 08 07                            	rorx   eax,DWORD PTR [rdi+0x8],0x7
 502:	48 89 d8                                        	mov    rax,rbx
 505:	48 c7 c0 7f 00 00 00                            	mov    rax,0x7f
 50c:	48 89 47 08                                     	mov    QWORD PTR [rdi+0x8],rax
 510:	48 8b 47 08                                     	mov    rax,QWORD PTR [rdi+0x8]
 514:	48 c7 47 08 7f 00 00 00                         	mov    QWORD PTR [rdi+0x8],0x7f
 51c:	48 01 d8                                        	add    rax,rbx
 51f:	48 83 c0 7f                                     	add    rax,0x7f
 523:	48 01 47 08                                     	add    QWORD PTR [rdi+0x8],rax
 527:	48 83 47 08 7f                                  	add    QWORD PTR [rdi+0x8],0x7f
 52c:	48 03 47 08                                     	add    rax,QWORD PTR [rdi+0x8]
 530:	48 11 d8                                        	adc    rax,rbx
 533:	48 83 d0 7f                                     	adc    rax,0x7f
 537:	48 11 47 08                                     	adc    QWORD PTR [rdi+0x8],rax
 53b:	48 83 57 08 7f                                  	adc    QWORD PTR [rdi+0x8],0x7f
 540:	48 13 47 08                                     	adc    rax,QWORD PTR [rdi+0x8]
 544:	48 29 d8                                        	sub    rax,rbx
 547:	48 83 e8 7f                                     	sub    rax,0x7f
 54b:	48 29 47 08                                     	sub    QWORD PTR [rdi+0x8],rax
 54f:	48 83 6f 08 7f                                  	sub    QWORD PTR [rdi+0x8],0x7f
 554:	48 2b 47 08                                     	sub    rax,QWORD PTR [rdi+0x8]
 558:	48 19 d8                                        	sbb    rax,rbx
 55b:	48 83 d8 7f                                     	sbb    rax,0x7f
 55f:	48 19 47 08                                     	sbb    QWORD PTR [rdi+0x8],rax
 563:	48 83 5f 08 7f                                  	sbb    QWORD PTR [rdi+0x8],0x7f
 568:	48 1b 47 08                                     	sbb    rax,QWORD PTR [rdi+0x8]
 56c:	48 39 d8                                        	cmp    rax,rbx
 56f:	48 83 f8 7f                                     	cmp    rax,0x7f
 573:	48 39 47 08                                     	cmp    QWORD PTR [rdi+0x8],rax
 577:	48 83 7f 08 7f                                  	cmp    QWORD PTR [rdi+0x8],0x7f
 57c:	48 3b 47 08                                     	cmp    rax,QWORD PTR [rdi+0x8]
 580:	48 85 d8                                        	test   rax,rbx
 583:	48 a9 7f 00 00 00                               	test   rax,0x7f
 589:	48 85 47 08                                     	test   QWORD PTR [rdi+0x8],rax
 58d:	48 f7 47 08 7f 00 00 00                         	test   QWORD PTR [rdi+0x8],0x7f
 595:	48 21 d8                                        	and    rax,rbx
 598:	48 83 e0 7f                                     	and    rax,0x7f
 59c:	48 23 47 08                                     	and    rax,QWORD PTR [rdi+0x8]
 5a0:	48 21 47 08                                     	and    QWORD PTR [rdi+0x8],rax
 5a4:	48 83 67 08 7f                                  	and    QWORD PTR [rdi+0x8],0x7f
 5a9:	48 09 d8                                        	or     rax,rbx
 5ac:	48 83 c8 7f                                     	or     rax,0x7f
 5b0:	48 0b 47 08                                     	or     rax,QWORD PTR [rdi+0x8]
 5b4:	48 09 47 08                                     	or     QWORD PTR [rdi+0x8],rax
 5b8:	48 83 4f 08 7f                                  	or     QWORD PTR [rdi+0x8],0x7f
 5bd:	48 31 d8                                        	xor    rax,rbx
 5c0:	48 83 f0 7f                                     	xor    rax,0x7f
 5c4:	48 33 47 08                                     	xor    rax,QWORD PTR [rdi+0x8]
 5c8:	48 31 47 08                                     	xor    QWORD PTR [rdi+0x8],rax
 5cc:	48 83 77 08 7f                                  	xor    QWORD PTR [rdi+0x8],0x7f
 5d1:	48 ff c0                                        	inc    rax
 5d4:	48 ff 47 08                                     	inc    QWORD PTR [rdi+0x8]
 5d8:	48 ff c8                                        	dec    rax
 5db:	48 ff 4f 08                                     	dec    QWORD PTR [rdi+0x8]
 5df:	48 f7 d8                                        	neg    rax
 5e2:	48 f7 5f 08                                     	neg    QWORD PTR [rdi+0x8]
 5e6:	48 f7 d0                                        	not    rax
 5e9:	48 f7 57 08                                     	not    QWORD PTR [rdi+0x8]
 5ed:	48 93                                           	xchg   rbx,rax
 5ef:	48 c1 e0 00                                     	shl    rax,0x0
 5f3:	48 d1 e0                                        	shl    rax,1
 5f6:	48 c1 e0 07                                     	shl    rax,0x7
 5fa:	48 c1 e0 08                                     	shl    rax,0x8
 5fe:	48 c1 e0 0f                                     	shl    rax,0xf
 602:	48 c1 e0 10                                     	shl    rax,0x10
 606:	48 c1 e0 1f                                     	shl    rax,0x1f
 60a:	48 c1 e0 20                                     	shl    rax,0x20
 60e:	48 c1 e0 3f                                     	shl    rax,0x3f
 612:	48 c1 e0 40                                     	shl    rax,0x40
 616:	48 c1 e0 ff                                     	shl    rax,0xff
 61a:	48 d3 e0                                        	shl    rax,cl
 61d:	48 c1 e8 00                                     	shr    rax,0x0
 621:	48 d1 e8                                        	shr    rax,1
 624:	48 c1 e8 07                                     	shr    rax,0x7
 628:	48 c1 e8 08                                     	shr    rax,0x8
 62c:	48 c1 e8 0f                                     	shr    rax,0xf
 630:	48 c1 e8 10                                     	shr    rax,0x10
 634:	48 c1 e8 1f                                     	shr    rax,0x1f
 638:	48 c1 e8 20                                     	shr    rax,0x20
 63c:	48 c1 e8 3f                                     	shr    rax,0x3f
 640:	48 c1 e8 40                                     	shr    rax,0x40
 644:	48 c1 e8 ff                                     	shr    rax,0xff
 648:	48 d3 e8                                        	shr    rax,cl
 64b:	48 c1 f8 00                                     	sar    rax,0x0
 64f:	48 d1 f8                                        	sar    rax,1
 652:	48 c1 f8 07                                     	sar    rax,0x7
 656:	48 c1 f8 08                                     	sar    rax,0x8
 65a:	48 c1 f8 0f                                     	sar    rax,0xf
 65e:	48 c1 f8 10                                     	sar    rax,0x10
 662:	48 c1 f8 1f                                     	sar    rax,0x1f
 666:	48 c1 f8 20                                     	sar    rax,0x20
 66a:	48 c1 f8 3f                                     	sar    rax,0x3f
 66e:	48 c1 f8 40                                     	sar    rax,0x40
 672:	48 c1 f8 ff                                     	sar    rax,0xff
 676:	48 d3 f8                                        	sar    rax,cl
 679:	48 c1 c0 00                                     	rol    rax,0x0
 67d:	48 d1 c0                                        	rol    rax,1
 680:	48 c1 c0 07                                     	rol    rax,0x7
 684:	48 c1 c0 08                                     	rol    rax,0x8
 688:	48 c1 c0 0f                                     	rol    rax,0xf
 68c:	48 c1 c0 10                                     	rol    rax,0x10
 690:	48 c1 c0 1f                                     	rol    rax,0x1f
 694:	48 c1 c0 20                                     	rol    rax,0x20
 698:	48 c1 c0 3f                                     	rol    rax,0x3f
 69c:	48 c1 c0 40                                     	rol    rax,0x40
 6a0:	48 c1 c0 ff                                     	rol    rax,0xff
 6a4:	48 d3 c0                                        	rol    rax,cl
 6a7:	48 0f af c3                                     	imul   rax,rbx
 6ab:	48 0f af 47 08                                  	imul   rax,QWORD PTR [rdi+0x8]
 6b0:	48 6b c3 f9                                     	imul   rax,rbx,0xfffffffffffffff9
 6b4:	48 6b 47 08 f9                                  	imul   rax,QWORD PTR [rdi+0x8],0xfffffffffffffff9
 6b9:	f3 48 0f b8 c3                                  	popcnt rax,rbx
 6be:	48 f7 f3                                        	div    rbx
 6c1:	48 0f a3 d8                                     	bt     rax,rbx
 6c5:	48 0f ba e0 07                                  	bt     rax,0x7
 6ca:	48 0f ba 67 08 07                               	bt     QWORD PTR [rdi+0x8],0x7
 6d0:	48 0f 38 f0 47 08                               	movbe  rax,QWORD PTR [rdi+0x8]
 6d6:	48 0f 38 f1 47 08                               	movbe  QWORD PTR [rdi+0x8],rax
 6dc:	48 0f a4 d8 00                                  	shld   rax,rbx,0x0
 6e1:	48 0f a4 d8 01                                  	shld   rax,rbx,0x1
 6e6:	48 0f a4 d8 07                                  	shld   rax,rbx,0x7
 6eb:	48 0f a4 d8 0f                                  	shld   rax,rbx,0xf
 6f0:	48 0f ac d8 00                                  	shrd   rax,rbx,0x0
 6f5:	48 0f ac d8 01                                  	shrd   rax,rbx,0x1
 6fa:	48 0f ac d8 07                                  	shrd   rax,rbx,0x7
 6ff:	48 0f ac d8 0f                                  	shrd   rax,rbx,0xf
 704:	48 8d 44 9f f9                                  	lea    rax,[rdi+rbx*4-0x7]
 709:	48 0f c8                                        	bswap  rax
 70c:	c4 e2 e0 f2 c1                                  	andn   rax,rbx,rcx
 711:	c4 e2 e0 f2 47 08                               	andn   rax,rbx,QWORD PTR [rdi+0x8]
 717:	c4 e2 f0 f5 c3                                  	bzhi   rax,rbx,rcx
 71c:	c4 e2 f0 f5 47 08                               	bzhi   rax,QWORD PTR [rdi+0x8],rcx
 722:	c4 e2 e3 f6 c1                                  	mulx   rax,rbx,rcx
 727:	c4 e2 f1 f7 c3                                  	shlx   rax,rbx,rcx
 72c:	c4 e2 f1 f7 47 08                               	shlx   rax,QWORD PTR [rdi+0x8],rcx
 732:	c4 e2 f3 f7 c3                                  	shrx   rax,rbx,rcx
 737:	c4 e2 f3 f7 47 08                               	shrx   rax,QWORD PTR [rdi+0x8],rcx
 73d:	c4 e2 f2 f7 c3                                  	sarx   rax,rbx,rcx
 742:	c4 e2 f2 f7 47 08                               	sarx   rax,QWORD PTR [rdi+0x8],rcx
 748:	c4 e3 fb f0 c3 07                               	rorx   rax,rbx,0x7
 74e:	c4 e3 fb f0 47 08 07                            	rorx   rax,QWORD PTR [rdi+0x8],0x7
 755:	88 fc                                           	mov    ah,bh
 757:	b4 7f                                           	mov    ah,0x7f
 759:	88 67 08                                        	mov    BYTE PTR [rdi+0x8],ah
 75c:	00 fc                                           	add    ah,bh
 75e:	80 c4 7f                                        	add    ah,0x7f
 761:	10 fc                                           	adc    ah,bh
 763:	80 d4 7f                                        	adc    ah,0x7f
 766:	28 fc                                           	sub    ah,bh
 768:	80 ec 7f                                        	sub    ah,0x7f
 76b:	18 fc                                           	sbb    ah,bh
 76d:	80 dc 7f                                        	sbb    ah,0x7f
 770:	38 fc                                           	cmp    ah,bh
 772:	80 fc 7f                                        	cmp    ah,0x7f
 775:	84 fc                                           	test   ah,bh
 777:	f6 c4 7f                                        	test   ah,0x7f
 77a:	fe c4                                           	inc    ah
 77c:	fe cc                                           	dec    ah
 77e:	f6 dc                                           	neg    ah
 780:	f6 d4                                           	not    ah
 782:	66 0f b6 c3                                     	movzx  ax,bl
 786:	66 0f b6 47 08                                  	movzx  ax,BYTE PTR [rdi+0x8]
 78b:	66 0f be c3                                     	movsx  ax,bl
 78f:	66 0f be 47 08                                  	movsx  ax,BYTE PTR [rdi+0x8]
 794:	0f b6 c3                                        	movzx  eax,bl
 797:	0f b6 47 08                                     	movzx  eax,BYTE PTR [rdi+0x8]
 79b:	0f be c3                                        	movsx  eax,bl
 79e:	0f be 47 08                                     	movsx  eax,BYTE PTR [rdi+0x8]
 7a2:	0f b7 c3                                        	movzx  eax,bx
 7a5:	0f b7 47 08                                     	movzx  eax,WORD PTR [rdi+0x8]
 7a9:	0f bf c3                                        	movsx  eax,bx
 7ac:	0f bf 47 08                                     	movsx  eax,WORD PTR [rdi+0x8]
 7b0:	48 0f b6 c3                                     	movzx  rax,bl
 7b4:	48 0f b6 47 08                                  	movzx  rax,BYTE PTR [rdi+0x8]
 7b9:	48 0f be c3                                     	movsx  rax,bl
 7bd:	48 0f be 47 08                                  	movsx  rax,BYTE PTR [rdi+0x8]
 7c2:	48 0f b7 c3                                     	movzx  rax,bx
 7c6:	48 0f b7 47 08                                  	movzx  rax,WORD PTR [rdi+0x8]
 7cb:	48 0f bf c3                                     	movsx  rax,bx
 7cf:	48 0f bf 47 08                                  	movsx  rax,WORD PTR [rdi+0x8]
 7d4:	48 63 c3                                        	movsxd rax,ebx
 7d7:	48 63 47 08                                     	movsxd rax,DWORD PTR [rdi+0x8]
 7db:	0f 92 c0                                        	setb   al
 7de:	0f 92 c4                                        	setb   ah
 7e1:	0f 92 47 08                                     	setb   BYTE PTR [rdi+0x8]
 7e5:	66 0f 42 c3                                     	cmovb  ax,bx
 7e9:	66 0f 42 47 08                                  	cmovb  ax,WORD PTR [rdi+0x8]
 7ee:	0f 42 c3                                        	cmovb  eax,ebx
 7f1:	0f 42 47 08                                     	cmovb  eax,DWORD PTR [rdi+0x8]
 7f5:	48 0f 42 c3                                     	cmovb  rax,rbx
 7f9:	48 0f 42 47 08                                  	cmovb  rax,QWORD PTR [rdi+0x8]
 7fe:	0f 93 c0                                        	setae  al
 801:	0f 93 c4                                        	setae  ah
 804:	0f 93 47 08                                     	setae  BYTE PTR [rdi+0x8]
 808:	66 0f 43 c3                                     	cmovae ax,bx
 80c:	66 0f 43 47 08                                  	cmovae ax,WORD PTR [rdi+0x8]
 811:	0f 43 c3                                        	cmovae eax,ebx
 814:	0f 43 47 08                                     	cmovae eax,DWORD PTR [rdi+0x8]
 818:	48 0f 43 c3                                     	cmovae rax,rbx
 81c:	48 0f 43 47 08                                  	cmovae rax,QWORD PTR [rdi+0x8]
 821:	0f 94 c0                                        	sete   al
 824:	0f 94 c4                                        	sete   ah
 827:	0f 94 47 08                                     	sete   BYTE PTR [rdi+0x8]
 82b:	66 0f 44 c3                                     	cmove  ax,bx
 82f:	66 0f 44 47 08                                  	cmove  ax,WORD PTR [rdi+0x8]
 834:	0f 44 c3                                        	cmove  eax,ebx
 837:	0f 44 47 08                                     	cmove  eax,DWORD PTR [rdi+0x8]
 83b:	48 0f 44 c3                                     	cmove  rax,rbx
 83f:	48 0f 44 47 08                                  	cmove  rax,QWORD PTR [rdi+0x8]
 844:	0f 95 c0                                        	setne  al
 847:	0f 95 c4                                        	setne  ah
 84a:	0f 95 47 08                                     	setne  BYTE PTR [rdi+0x8]
 84e:	66 0f 45 c3                                     	cmovne ax,bx
 852:	66 0f 45 47 08                                  	cmovne ax,WORD PTR [rdi+0x8]
 857:	0f 45 c3                                        	cmovne eax,ebx
 85a:	0f 45 47 08                                     	cmovne eax,DWORD PTR [rdi+0x8]
 85e:	48 0f 45 c3                                     	cmovne rax,rbx
 862:	48 0f 45 47 08                                  	cmovne rax,QWORD PTR [rdi+0x8]
 867:	0f 96 c0                                        	setbe  al
 86a:	0f 96 c4                                        	setbe  ah
 86d:	0f 96 47 08                                     	setbe  BYTE PTR [rdi+0x8]
 871:	66 0f 46 c3                                     	cmovbe ax,bx
 875:	66 0f 46 47 08                                  	cmovbe ax,WORD PTR [rdi+0x8]
 87a:	0f 46 c3                                        	cmovbe eax,ebx
 87d:	0f 46 47 08                                     	cmovbe eax,DWORD PTR [rdi+0x8]
 881:	48 0f 46 c3                                     	cmovbe rax,rbx
 885:	48 0f 46 47 08                                  	cmovbe rax,QWORD PTR [rdi+0x8]
 88a:	0f 97 c0                                        	seta   al
 88d:	0f 97 c4                                        	seta   ah
 890:	0f 97 47 08                                     	seta   BYTE PTR [rdi+0x8]
 894:	66 0f 47 c3                                     	cmova  ax,bx
 898:	66 0f 47 47 08                                  	cmova  ax,WORD PTR [rdi+0x8]
 89d:	0f 47 c3                                        	cmova  eax,ebx
 8a0:	0f 47 47 08                                     	cmova  eax,DWORD PTR [rdi+0x8]
 8a4:	48 0f 47 c3                                     	cmova  rax,rbx
 8a8:	48 0f 47 47 08                                  	cmova  rax,QWORD PTR [rdi+0x8]
 8ad:	0f 98 c0                                        	sets   al
 8b0:	0f 98 c4                                        	sets   ah
 8b3:	0f 98 47 08                                     	sets   BYTE PTR [rdi+0x8]
 8b7:	66 0f 48 c3                                     	cmovs  ax,bx
 8bb:	66 0f 48 47 08                                  	cmovs  ax,WORD PTR [rdi+0x8]
 8c0:	0f 48 c3                                        	cmovs  eax,ebx
 8c3:	0f 48 47 08                                     	cmovs  eax,DWORD PTR [rdi+0x8]
 8c7:	48 0f 48 c3                                     	cmovs  rax,rbx
 8cb:	48 0f 48 47 08                                  	cmovs  rax,QWORD PTR [rdi+0x8]
 8d0:	0f 99 c0                                        	setns  al
 8d3:	0f 99 c4                                        	setns  ah
 8d6:	0f 99 47 08                                     	setns  BYTE PTR [rdi+0x8]
 8da:	66 0f 49 c3                                     	cmovns ax,bx
 8de:	66 0f 49 47 08                                  	cmovns ax,WORD PTR [rdi+0x8]
 8e3:	0f 49 c3                                        	cmovns eax,ebx
 8e6:	0f 49 47 08                                     	cmovns eax,DWORD PTR [rdi+0x8]
 8ea:	48 0f 49 c3                                     	cmovns rax,rbx
 8ee:	48 0f 49 47 08                                  	cmovns rax,QWORD PTR [rdi+0x8]
 8f3:	0f 9c c0                                        	setl   al
 8f6:	0f 9c c4                                        	setl   ah
 8f9:	0f 9c 47 08                                     	setl   BYTE PTR [rdi+0x8]
 8fd:	66 0f 4c c3                                     	cmovl  ax,bx
 901:	66 0f 4c 47 08                                  	cmovl  ax,WORD PTR [rdi+0x8]
 906:	0f 4c c3                                        	cmovl  eax,ebx
 909:	0f 4c 47 08                                     	cmovl  eax,DWORD PTR [rdi+0x8]
 90d:	48 0f 4c c3                                     	cmovl  rax,rbx
 911:	48 0f 4c 47 08                                  	cmovl  rax,QWORD PTR [rdi+0x8]
 916:	0f 9d c0                                        	setge  al
 919:	0f 9d c4                                        	setge  ah
 91c:	0f 9d 47 08                                     	setge  BYTE PTR [rdi+0x8]
 920:	66 0f 4d c3                                     	cmovge ax,bx
 924:	66 0f 4d 47 08                                  	cmovge ax,WORD PTR [rdi+0x8]
 929:	0f 4d c3                                        	cmovge eax,ebx
 92c:	0f 4d 47 08                                     	cmovge eax,DWORD PTR [rdi+0x8]
 930:	48 0f 4d c3                                     	cmovge rax,rbx
 934:	48 0f 4d 47 08                                  	cmovge rax,QWORD PTR [rdi+0x8]
 939:	0f 9e c0                                        	setle  al
 93c:	0f 9e c4                                        	setle  ah
 93f:	0f 9e 47 08                                     	setle  BYTE PTR [rdi+0x8]
 943:	66 0f 4e c3                                     	cmovle ax,bx
 947:	66 0f 4e 47 08                                  	cmovle ax,WORD PTR [rdi+0x8]
 94c:	0f 4e c3                                        	cmovle eax,ebx
 94f:	0f 4e 47 08                                     	cmovle eax,DWORD PTR [rdi+0x8]
 953:	48 0f 4e c3                                     	cmovle rax,rbx
 957:	48 0f 4e 47 08                                  	cmovle rax,QWORD PTR [rdi+0x8]
 95c:	0f 9f c0                                        	setg   al
 95f:	0f 9f c4                                        	setg   ah
 962:	0f 9f 47 08                                     	setg   BYTE PTR [rdi+0x8]
 966:	66 0f 4f c3                                     	cmovg  ax,bx
 96a:	66 0f 4f 47 08                                  	cmovg  ax,WORD PTR [rdi+0x8]
 96f:	0f 4f c3                                        	cmovg  eax,ebx
 972:	0f 4f 47 08                                     	cmovg  eax,DWORD PTR [rdi+0x8]
 976:	48 0f 4f c3                                     	cmovg  rax,rbx
 97a:	48 0f 4f 47 08                                  	cmovg  rax,QWORD PTR [rdi+0x8]
