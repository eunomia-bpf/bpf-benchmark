
/workspaces/repository/kprog/fidelity/build-arm64-exclusive/instructions.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <.text>:
   0:	885f7c80 	ldxr	w0, [x4]
   4:	885ffc80 	ldaxr	w0, [x4]
   8:	88007c81 	stxr	w0, w1, [x4]
   c:	8800fc81 	stlxr	w0, w1, [x4]
  10:	c85f7c80 	ldxr	x0, [x4]
  14:	c85ffc80 	ldaxr	x0, [x4]
  18:	c8007c81 	stxr	w0, x1, [x4]
  1c:	c800fc81 	stlxr	w0, x1, [x4]
