
/workspaces/repository/kprog/fidelity/build-x86-lea-sp-after/instructions.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <.text>:
   0:	48 8d 64 24 10                                  	lea    rsp,[rsp+0x10]
