
build-arm64-sp-observer/instructions.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <.text>:
   0:	d503201f 	nop
   4:	0b020020 	add	w0, w1, w2
   8:	0b020c20 	add	w0, w1, w2, lsl #3
   c:	1101fc20 	add	w0, w1, #0x7f
  10:	4b020020 	sub	w0, w1, w2
  14:	4b020c20 	sub	w0, w1, w2, lsl #3
  18:	5101fc20 	sub	w0, w1, #0x7f
  1c:	0a020020 	and	w0, w1, w2
  20:	0a020c20 	and	w0, w1, w2, lsl #3
  24:	0a220020 	bic	w0, w1, w2
  28:	0a220c20 	bic	w0, w1, w2, lsl #3
  2c:	4a020020 	eor	w0, w1, w2
  30:	4a020c20 	eor	w0, w1, w2, lsl #3
  34:	2a020020 	orr	w0, w1, w2
  38:	2a020c20 	orr	w0, w1, w2, lsl #3
  3c:	2a220020 	orn	w0, w1, w2
  40:	2a220c20 	orn	w0, w1, w2, lsl #3
  44:	2b020020 	adds	w0, w1, w2
  48:	2b020c20 	adds	w0, w1, w2, lsl #3
  4c:	3101fc20 	adds	w0, w1, #0x7f
  50:	6b020020 	subs	w0, w1, w2
  54:	6b020c20 	subs	w0, w1, w2, lsl #3
  58:	7101fc20 	subs	w0, w1, #0x7f
  5c:	6a020020 	ands	w0, w1, w2
  60:	6a020c20 	ands	w0, w1, w2, lsl #3
  64:	6a220020 	bics	w0, w1, w2
  68:	6a220c20 	bics	w0, w1, w2, lsl #3
  6c:	6b02003f 	cmp	w1, w2
  70:	6b020c3f 	cmp	w1, w2, lsl #3
  74:	2b02003f 	cmn	w1, w2
  78:	2b020c3f 	cmn	w1, w2, lsl #3
  7c:	6a02003f 	tst	w1, w2
  80:	6a020c3f 	tst	w1, w2, lsl #3
  84:	2a0103e0 	mov	w0, w1
  88:	52800fe0 	mov	w0, #0x7f                  	// #127
  8c:	72bbd5a0 	movk	w0, #0xdead, lsl #16
  90:	110003e0 	mov	w0, wsp
  94:	1100001f 	mov	wsp, w0
  98:	2a2103e0 	mvn	w0, w1
  9c:	4b0103e0 	neg	w0, w1
  a0:	5ac00820 	rev	w0, w1
  a4:	5ac00420 	rev16	w0, w1
  a8:	13001c20 	sxtb	w0, w1
  ac:	13003c20 	sxth	w0, w1
  b0:	2a2103e0 	mvn	w0, w1
  b4:	2a2107e0 	mvn	w0, w1, lsl #1
  b8:	2a217fe0 	mvn	w0, w1, lsl #31
  bc:	2a6103e0 	mvn	w0, w1, lsr #0
  c0:	2a6107e0 	mvn	w0, w1, lsr #1
  c4:	2a617fe0 	mvn	w0, w1, lsr #31
  c8:	2aa103e0 	mvn	w0, w1, asr #0
  cc:	2aa107e0 	mvn	w0, w1, asr #1
  d0:	2aa17fe0 	mvn	w0, w1, asr #31
  d4:	2ae103e0 	mvn	w0, w1, ror #0
  d8:	2ae107e0 	mvn	w0, w1, ror #1
  dc:	2ae17fe0 	mvn	w0, w1, ror #31
  e0:	4b0103e0 	neg	w0, w1
  e4:	4b0107e0 	neg	w0, w1, lsl #1
  e8:	4b017fe0 	neg	w0, w1, lsl #31
  ec:	4b4103e0 	neg	w0, w1, lsr #0
  f0:	4b4107e0 	neg	w0, w1, lsr #1
  f4:	4b417fe0 	neg	w0, w1, lsr #31
  f8:	4b8103e0 	neg	w0, w1, asr #0
  fc:	4b8107e0 	neg	w0, w1, asr #1
 100:	4b817fe0 	neg	w0, w1, asr #31
 104:	1b027c20 	mul	w0, w1, w2
 108:	1ac20820 	udiv	w0, w1, w2
 10c:	1b020c20 	madd	w0, w1, w2, w3
 110:	1b028c20 	msub	w0, w1, w2, w3
 114:	1ac22020 	lsl	w0, w1, w2
 118:	53007c20 	lsr	w0, w1, #0
 11c:	531f7820 	lsl	w0, w1, #1
 120:	53196020 	lsl	w0, w1, #7
 124:	53010020 	lsl	w0, w1, #31
 128:	1ac22420 	lsr	w0, w1, w2
 12c:	53007c20 	lsr	w0, w1, #0
 130:	53017c20 	lsr	w0, w1, #1
 134:	53077c20 	lsr	w0, w1, #7
 138:	531f7c20 	lsr	w0, w1, #31
 13c:	1ac22820 	asr	w0, w1, w2
 140:	13007c20 	asr	w0, w1, #0
 144:	13017c20 	asr	w0, w1, #1
 148:	13077c20 	asr	w0, w1, #7
 14c:	131f7c20 	asr	w0, w1, #31
 150:	1ac22c20 	ror	w0, w1, w2
 154:	13810020 	ror	w0, w1, #0
 158:	13810420 	ror	w0, w1, #1
 15c:	13811c20 	ror	w0, w1, #7
 160:	13817c20 	ror	w0, w1, #31
 164:	13821c20 	extr	w0, w1, w2, #7
 168:	53074c20 	ubfx	w0, w1, #7, #13
 16c:	13074c20 	sbfx	w0, w1, #7, #13
 170:	53193020 	ubfiz	w0, w1, #7, #13
 174:	33074c20 	bfxil	w0, w1, #7, #13
 178:	33193020 	bfi	w0, w1, #7, #13
 17c:	1a820020 	csel	w0, w1, w2, eq	// eq = none
 180:	1a820420 	csinc	w0, w1, w2, eq	// eq = none
 184:	5a820020 	csinv	w0, w1, w2, eq	// eq = none
 188:	5a820420 	csneg	w0, w1, w2, eq	// eq = none
 18c:	1a811420 	cinc	w0, w1, eq	// eq = none
 190:	5a811020 	cinv	w0, w1, eq	// eq = none
 194:	5a811420 	cneg	w0, w1, eq	// eq = none
 198:	1a9f17e0 	cset	w0, eq	// eq = none
 19c:	5a9f13e0 	csetm	w0, eq	// eq = none
 1a0:	7a420025 	ccmp	w1, w2, #0x5, eq	// eq = none
 1a4:	7a47082a 	ccmp	w1, #0x7, #0xa, eq	// eq = none
 1a8:	1a821020 	csel	w0, w1, w2, ne	// ne = any
 1ac:	1a821420 	csinc	w0, w1, w2, ne	// ne = any
 1b0:	5a821020 	csinv	w0, w1, w2, ne	// ne = any
 1b4:	5a821420 	csneg	w0, w1, w2, ne	// ne = any
 1b8:	1a810420 	cinc	w0, w1, ne	// ne = any
 1bc:	5a810020 	cinv	w0, w1, ne	// ne = any
 1c0:	5a810420 	cneg	w0, w1, ne	// ne = any
 1c4:	1a9f07e0 	cset	w0, ne	// ne = any
 1c8:	5a9f03e0 	csetm	w0, ne	// ne = any
 1cc:	7a421025 	ccmp	w1, w2, #0x5, ne	// ne = any
 1d0:	7a47182a 	ccmp	w1, #0x7, #0xa, ne	// ne = any
 1d4:	1a822020 	csel	w0, w1, w2, cs	// cs = hs, nlast
 1d8:	1a822420 	csinc	w0, w1, w2, cs	// cs = hs, nlast
 1dc:	5a822020 	csinv	w0, w1, w2, cs	// cs = hs, nlast
 1e0:	5a822420 	csneg	w0, w1, w2, cs	// cs = hs, nlast
 1e4:	1a813420 	cinc	w0, w1, cs	// cs = hs, nlast
 1e8:	5a813020 	cinv	w0, w1, cs	// cs = hs, nlast
 1ec:	5a813420 	cneg	w0, w1, cs	// cs = hs, nlast
 1f0:	1a9f37e0 	cset	w0, cs	// cs = hs, nlast
 1f4:	5a9f33e0 	csetm	w0, cs	// cs = hs, nlast
 1f8:	7a422025 	ccmp	w1, w2, #0x5, cs	// cs = hs, nlast
 1fc:	7a47282a 	ccmp	w1, #0x7, #0xa, cs	// cs = hs, nlast
 200:	1a823020 	csel	w0, w1, w2, cc	// cc = lo, ul, last
 204:	1a823420 	csinc	w0, w1, w2, cc	// cc = lo, ul, last
 208:	5a823020 	csinv	w0, w1, w2, cc	// cc = lo, ul, last
 20c:	5a823420 	csneg	w0, w1, w2, cc	// cc = lo, ul, last
 210:	1a812420 	cinc	w0, w1, cc	// cc = lo, ul, last
 214:	5a812020 	cinv	w0, w1, cc	// cc = lo, ul, last
 218:	5a812420 	cneg	w0, w1, cc	// cc = lo, ul, last
 21c:	1a9f27e0 	cset	w0, cc	// cc = lo, ul, last
 220:	5a9f23e0 	csetm	w0, cc	// cc = lo, ul, last
 224:	7a423025 	ccmp	w1, w2, #0x5, cc	// cc = lo, ul, last
 228:	7a47382a 	ccmp	w1, #0x7, #0xa, cc	// cc = lo, ul, last
 22c:	1a824020 	csel	w0, w1, w2, mi	// mi = first
 230:	1a824420 	csinc	w0, w1, w2, mi	// mi = first
 234:	5a824020 	csinv	w0, w1, w2, mi	// mi = first
 238:	5a824420 	csneg	w0, w1, w2, mi	// mi = first
 23c:	1a815420 	cinc	w0, w1, mi	// mi = first
 240:	5a815020 	cinv	w0, w1, mi	// mi = first
 244:	5a815420 	cneg	w0, w1, mi	// mi = first
 248:	1a9f57e0 	cset	w0, mi	// mi = first
 24c:	5a9f53e0 	csetm	w0, mi	// mi = first
 250:	7a424025 	ccmp	w1, w2, #0x5, mi	// mi = first
 254:	7a47482a 	ccmp	w1, #0x7, #0xa, mi	// mi = first
 258:	1a825020 	csel	w0, w1, w2, pl	// pl = nfrst
 25c:	1a825420 	csinc	w0, w1, w2, pl	// pl = nfrst
 260:	5a825020 	csinv	w0, w1, w2, pl	// pl = nfrst
 264:	5a825420 	csneg	w0, w1, w2, pl	// pl = nfrst
 268:	1a814420 	cinc	w0, w1, pl	// pl = nfrst
 26c:	5a814020 	cinv	w0, w1, pl	// pl = nfrst
 270:	5a814420 	cneg	w0, w1, pl	// pl = nfrst
 274:	1a9f47e0 	cset	w0, pl	// pl = nfrst
 278:	5a9f43e0 	csetm	w0, pl	// pl = nfrst
 27c:	7a425025 	ccmp	w1, w2, #0x5, pl	// pl = nfrst
 280:	7a47582a 	ccmp	w1, #0x7, #0xa, pl	// pl = nfrst
 284:	1a826020 	csel	w0, w1, w2, vs
 288:	1a826420 	csinc	w0, w1, w2, vs
 28c:	5a826020 	csinv	w0, w1, w2, vs
 290:	5a826420 	csneg	w0, w1, w2, vs
 294:	1a817420 	cinc	w0, w1, vs
 298:	5a817020 	cinv	w0, w1, vs
 29c:	5a817420 	cneg	w0, w1, vs
 2a0:	1a9f77e0 	cset	w0, vs
 2a4:	5a9f73e0 	csetm	w0, vs
 2a8:	7a426025 	ccmp	w1, w2, #0x5, vs
 2ac:	7a47682a 	ccmp	w1, #0x7, #0xa, vs
 2b0:	1a827020 	csel	w0, w1, w2, vc
 2b4:	1a827420 	csinc	w0, w1, w2, vc
 2b8:	5a827020 	csinv	w0, w1, w2, vc
 2bc:	5a827420 	csneg	w0, w1, w2, vc
 2c0:	1a816420 	cinc	w0, w1, vc
 2c4:	5a816020 	cinv	w0, w1, vc
 2c8:	5a816420 	cneg	w0, w1, vc
 2cc:	1a9f67e0 	cset	w0, vc
 2d0:	5a9f63e0 	csetm	w0, vc
 2d4:	7a427025 	ccmp	w1, w2, #0x5, vc
 2d8:	7a47782a 	ccmp	w1, #0x7, #0xa, vc
 2dc:	1a828020 	csel	w0, w1, w2, hi	// hi = pmore
 2e0:	1a828420 	csinc	w0, w1, w2, hi	// hi = pmore
 2e4:	5a828020 	csinv	w0, w1, w2, hi	// hi = pmore
 2e8:	5a828420 	csneg	w0, w1, w2, hi	// hi = pmore
 2ec:	1a819420 	cinc	w0, w1, hi	// hi = pmore
 2f0:	5a819020 	cinv	w0, w1, hi	// hi = pmore
 2f4:	5a819420 	cneg	w0, w1, hi	// hi = pmore
 2f8:	1a9f97e0 	cset	w0, hi	// hi = pmore
 2fc:	5a9f93e0 	csetm	w0, hi	// hi = pmore
 300:	7a428025 	ccmp	w1, w2, #0x5, hi	// hi = pmore
 304:	7a47882a 	ccmp	w1, #0x7, #0xa, hi	// hi = pmore
 308:	1a829020 	csel	w0, w1, w2, ls	// ls = plast
 30c:	1a829420 	csinc	w0, w1, w2, ls	// ls = plast
 310:	5a829020 	csinv	w0, w1, w2, ls	// ls = plast
 314:	5a829420 	csneg	w0, w1, w2, ls	// ls = plast
 318:	1a818420 	cinc	w0, w1, ls	// ls = plast
 31c:	5a818020 	cinv	w0, w1, ls	// ls = plast
 320:	5a818420 	cneg	w0, w1, ls	// ls = plast
 324:	1a9f87e0 	cset	w0, ls	// ls = plast
 328:	5a9f83e0 	csetm	w0, ls	// ls = plast
 32c:	7a429025 	ccmp	w1, w2, #0x5, ls	// ls = plast
 330:	7a47982a 	ccmp	w1, #0x7, #0xa, ls	// ls = plast
 334:	1a82a020 	csel	w0, w1, w2, ge	// ge = tcont
 338:	1a82a420 	csinc	w0, w1, w2, ge	// ge = tcont
 33c:	5a82a020 	csinv	w0, w1, w2, ge	// ge = tcont
 340:	5a82a420 	csneg	w0, w1, w2, ge	// ge = tcont
 344:	1a81b420 	cinc	w0, w1, ge	// ge = tcont
 348:	5a81b020 	cinv	w0, w1, ge	// ge = tcont
 34c:	5a81b420 	cneg	w0, w1, ge	// ge = tcont
 350:	1a9fb7e0 	cset	w0, ge	// ge = tcont
 354:	5a9fb3e0 	csetm	w0, ge	// ge = tcont
 358:	7a42a025 	ccmp	w1, w2, #0x5, ge	// ge = tcont
 35c:	7a47a82a 	ccmp	w1, #0x7, #0xa, ge	// ge = tcont
 360:	1a82b020 	csel	w0, w1, w2, lt	// lt = tstop
 364:	1a82b420 	csinc	w0, w1, w2, lt	// lt = tstop
 368:	5a82b020 	csinv	w0, w1, w2, lt	// lt = tstop
 36c:	5a82b420 	csneg	w0, w1, w2, lt	// lt = tstop
 370:	1a81a420 	cinc	w0, w1, lt	// lt = tstop
 374:	5a81a020 	cinv	w0, w1, lt	// lt = tstop
 378:	5a81a420 	cneg	w0, w1, lt	// lt = tstop
 37c:	1a9fa7e0 	cset	w0, lt	// lt = tstop
 380:	5a9fa3e0 	csetm	w0, lt	// lt = tstop
 384:	7a42b025 	ccmp	w1, w2, #0x5, lt	// lt = tstop
 388:	7a47b82a 	ccmp	w1, #0x7, #0xa, lt	// lt = tstop
 38c:	1a82c020 	csel	w0, w1, w2, gt
 390:	1a82c420 	csinc	w0, w1, w2, gt
 394:	5a82c020 	csinv	w0, w1, w2, gt
 398:	5a82c420 	csneg	w0, w1, w2, gt
 39c:	1a81d420 	cinc	w0, w1, gt
 3a0:	5a81d020 	cinv	w0, w1, gt
 3a4:	5a81d420 	cneg	w0, w1, gt
 3a8:	1a9fd7e0 	cset	w0, gt
 3ac:	5a9fd3e0 	csetm	w0, gt
 3b0:	7a42c025 	ccmp	w1, w2, #0x5, gt
 3b4:	7a47c82a 	ccmp	w1, #0x7, #0xa, gt
 3b8:	1a82d020 	csel	w0, w1, w2, le
 3bc:	1a82d420 	csinc	w0, w1, w2, le
 3c0:	5a82d020 	csinv	w0, w1, w2, le
 3c4:	5a82d420 	csneg	w0, w1, w2, le
 3c8:	1a81c420 	cinc	w0, w1, le
 3cc:	5a81c020 	cinv	w0, w1, le
 3d0:	5a81c420 	cneg	w0, w1, le
 3d4:	1a9fc7e0 	cset	w0, le
 3d8:	5a9fc3e0 	csetm	w0, le
 3dc:	7a42d025 	ccmp	w1, w2, #0x5, le
 3e0:	7a47d82a 	ccmp	w1, #0x7, #0xa, le
 3e4:	1a82e020 	csel	w0, w1, w2, al
 3e8:	1a82e420 	csinc	w0, w1, w2, al
 3ec:	5a82e020 	csinv	w0, w1, w2, al
 3f0:	5a82e420 	csneg	w0, w1, w2, al
 3f4:	7a42e025 	ccmp	w1, w2, #0x5, al
 3f8:	7a47e82a 	ccmp	w1, #0x7, #0xa, al
 3fc:	1a82f020 	csel	w0, w1, w2, nv
 400:	1a82f420 	csinc	w0, w1, w2, nv
 404:	5a82f020 	csinv	w0, w1, w2, nv
 408:	5a82f420 	csneg	w0, w1, w2, nv
 40c:	7a42f025 	ccmp	w1, w2, #0x5, nv
 410:	7a47f82a 	ccmp	w1, #0x7, #0xa, nv
 414:	b9400880 	ldr	w0, [x4, #8]
 418:	b9000880 	str	w0, [x4, #8]
 41c:	b8408080 	ldur	w0, [x4, #8]
 420:	b8008080 	stur	w0, [x4, #8]
 424:	b8408c80 	ldr	w0, [x4, #8]!
 428:	b8408480 	ldr	w0, [x4], #8
 42c:	b8657880 	ldr	w0, [x4, x5, lsl #2]
 430:	b8008c80 	str	w0, [x4, #8]!
 434:	b8008480 	str	w0, [x4], #8
 438:	b8257880 	str	w0, [x4, x5, lsl #2]
 43c:	39402080 	ldrb	w0, [x4, #8]
 440:	79401080 	ldrh	w0, [x4, #8]
 444:	39002080 	strb	w0, [x4, #8]
 448:	79001080 	strh	w0, [x4, #8]
 44c:	39c02080 	ldrsb	w0, [x4, #8]
 450:	79c01080 	ldrsh	w0, [x4, #8]
 454:	8b020020 	add	x0, x1, x2
 458:	8b020c20 	add	x0, x1, x2, lsl #3
 45c:	9101fc20 	add	x0, x1, #0x7f
 460:	cb020020 	sub	x0, x1, x2
 464:	cb020c20 	sub	x0, x1, x2, lsl #3
 468:	d101fc20 	sub	x0, x1, #0x7f
 46c:	8a020020 	and	x0, x1, x2
 470:	8a020c20 	and	x0, x1, x2, lsl #3
 474:	8a220020 	bic	x0, x1, x2
 478:	8a220c20 	bic	x0, x1, x2, lsl #3
 47c:	ca020020 	eor	x0, x1, x2
 480:	ca020c20 	eor	x0, x1, x2, lsl #3
 484:	aa020020 	orr	x0, x1, x2
 488:	aa020c20 	orr	x0, x1, x2, lsl #3
 48c:	aa220020 	orn	x0, x1, x2
 490:	aa220c20 	orn	x0, x1, x2, lsl #3
 494:	ab020020 	adds	x0, x1, x2
 498:	ab020c20 	adds	x0, x1, x2, lsl #3
 49c:	b101fc20 	adds	x0, x1, #0x7f
 4a0:	eb020020 	subs	x0, x1, x2
 4a4:	eb020c20 	subs	x0, x1, x2, lsl #3
 4a8:	f101fc20 	subs	x0, x1, #0x7f
 4ac:	ea020020 	ands	x0, x1, x2
 4b0:	ea020c20 	ands	x0, x1, x2, lsl #3
 4b4:	ea220020 	bics	x0, x1, x2
 4b8:	ea220c20 	bics	x0, x1, x2, lsl #3
 4bc:	eb02003f 	cmp	x1, x2
 4c0:	eb020c3f 	cmp	x1, x2, lsl #3
 4c4:	ab02003f 	cmn	x1, x2
 4c8:	ab020c3f 	cmn	x1, x2, lsl #3
 4cc:	ea02003f 	tst	x1, x2
 4d0:	ea020c3f 	tst	x1, x2, lsl #3
 4d4:	aa0103e0 	mov	x0, x1
 4d8:	d2800fe0 	mov	x0, #0x7f                  	// #127
 4dc:	f2bbd5a0 	movk	x0, #0xdead, lsl #16
 4e0:	910003e0 	mov	x0, sp
 4e4:	9100001f 	mov	sp, x0
 4e8:	aa2103e0 	mvn	x0, x1
 4ec:	cb0103e0 	neg	x0, x1
 4f0:	dac00c20 	rev	x0, x1
 4f4:	dac00420 	rev16	x0, x1
 4f8:	93401c20 	sxtb	x0, w1
 4fc:	93403c20 	sxth	x0, w1
 500:	aa2103e0 	mvn	x0, x1
 504:	aa2107e0 	mvn	x0, x1, lsl #1
 508:	aa21ffe0 	mvn	x0, x1, lsl #63
 50c:	aa6103e0 	mvn	x0, x1, lsr #0
 510:	aa6107e0 	mvn	x0, x1, lsr #1
 514:	aa61ffe0 	mvn	x0, x1, lsr #63
 518:	aaa103e0 	mvn	x0, x1, asr #0
 51c:	aaa107e0 	mvn	x0, x1, asr #1
 520:	aaa1ffe0 	mvn	x0, x1, asr #63
 524:	aae103e0 	mvn	x0, x1, ror #0
 528:	aae107e0 	mvn	x0, x1, ror #1
 52c:	aae1ffe0 	mvn	x0, x1, ror #63
 530:	cb0103e0 	neg	x0, x1
 534:	cb0107e0 	neg	x0, x1, lsl #1
 538:	cb01ffe0 	neg	x0, x1, lsl #63
 53c:	cb4103e0 	neg	x0, x1, lsr #0
 540:	cb4107e0 	neg	x0, x1, lsr #1
 544:	cb41ffe0 	neg	x0, x1, lsr #63
 548:	cb8103e0 	neg	x0, x1, asr #0
 54c:	cb8107e0 	neg	x0, x1, asr #1
 550:	cb81ffe0 	neg	x0, x1, asr #63
 554:	9b027c20 	mul	x0, x1, x2
 558:	9ac20820 	udiv	x0, x1, x2
 55c:	9b020c20 	madd	x0, x1, x2, x3
 560:	9b028c20 	msub	x0, x1, x2, x3
 564:	9ac22020 	lsl	x0, x1, x2
 568:	d340fc20 	lsr	x0, x1, #0
 56c:	d37ff820 	lsl	x0, x1, #1
 570:	d379e020 	lsl	x0, x1, #7
 574:	d3618020 	lsl	x0, x1, #31
 578:	9ac22420 	lsr	x0, x1, x2
 57c:	d340fc20 	lsr	x0, x1, #0
 580:	d341fc20 	lsr	x0, x1, #1
 584:	d347fc20 	lsr	x0, x1, #7
 588:	d35ffc20 	lsr	x0, x1, #31
 58c:	9ac22820 	asr	x0, x1, x2
 590:	9340fc20 	asr	x0, x1, #0
 594:	9341fc20 	asr	x0, x1, #1
 598:	9347fc20 	asr	x0, x1, #7
 59c:	935ffc20 	asr	x0, x1, #31
 5a0:	9ac22c20 	ror	x0, x1, x2
 5a4:	93c10020 	ror	x0, x1, #0
 5a8:	93c10420 	ror	x0, x1, #1
 5ac:	93c11c20 	ror	x0, x1, #7
 5b0:	93c17c20 	ror	x0, x1, #31
 5b4:	93c21c20 	extr	x0, x1, x2, #7
 5b8:	d3474c20 	ubfx	x0, x1, #7, #13
 5bc:	93474c20 	sbfx	x0, x1, #7, #13
 5c0:	d3793020 	ubfiz	x0, x1, #7, #13
 5c4:	b3474c20 	bfxil	x0, x1, #7, #13
 5c8:	b3793020 	bfi	x0, x1, #7, #13
 5cc:	9a820020 	csel	x0, x1, x2, eq	// eq = none
 5d0:	9a820420 	csinc	x0, x1, x2, eq	// eq = none
 5d4:	da820020 	csinv	x0, x1, x2, eq	// eq = none
 5d8:	da820420 	csneg	x0, x1, x2, eq	// eq = none
 5dc:	9a811420 	cinc	x0, x1, eq	// eq = none
 5e0:	da811020 	cinv	x0, x1, eq	// eq = none
 5e4:	da811420 	cneg	x0, x1, eq	// eq = none
 5e8:	9a9f17e0 	cset	x0, eq	// eq = none
 5ec:	da9f13e0 	csetm	x0, eq	// eq = none
 5f0:	fa420025 	ccmp	x1, x2, #0x5, eq	// eq = none
 5f4:	fa47082a 	ccmp	x1, #0x7, #0xa, eq	// eq = none
 5f8:	9a821020 	csel	x0, x1, x2, ne	// ne = any
 5fc:	9a821420 	csinc	x0, x1, x2, ne	// ne = any
 600:	da821020 	csinv	x0, x1, x2, ne	// ne = any
 604:	da821420 	csneg	x0, x1, x2, ne	// ne = any
 608:	9a810420 	cinc	x0, x1, ne	// ne = any
 60c:	da810020 	cinv	x0, x1, ne	// ne = any
 610:	da810420 	cneg	x0, x1, ne	// ne = any
 614:	9a9f07e0 	cset	x0, ne	// ne = any
 618:	da9f03e0 	csetm	x0, ne	// ne = any
 61c:	fa421025 	ccmp	x1, x2, #0x5, ne	// ne = any
 620:	fa47182a 	ccmp	x1, #0x7, #0xa, ne	// ne = any
 624:	9a822020 	csel	x0, x1, x2, cs	// cs = hs, nlast
 628:	9a822420 	csinc	x0, x1, x2, cs	// cs = hs, nlast
 62c:	da822020 	csinv	x0, x1, x2, cs	// cs = hs, nlast
 630:	da822420 	csneg	x0, x1, x2, cs	// cs = hs, nlast
 634:	9a813420 	cinc	x0, x1, cs	// cs = hs, nlast
 638:	da813020 	cinv	x0, x1, cs	// cs = hs, nlast
 63c:	da813420 	cneg	x0, x1, cs	// cs = hs, nlast
 640:	9a9f37e0 	cset	x0, cs	// cs = hs, nlast
 644:	da9f33e0 	csetm	x0, cs	// cs = hs, nlast
 648:	fa422025 	ccmp	x1, x2, #0x5, cs	// cs = hs, nlast
 64c:	fa47282a 	ccmp	x1, #0x7, #0xa, cs	// cs = hs, nlast
 650:	9a823020 	csel	x0, x1, x2, cc	// cc = lo, ul, last
 654:	9a823420 	csinc	x0, x1, x2, cc	// cc = lo, ul, last
 658:	da823020 	csinv	x0, x1, x2, cc	// cc = lo, ul, last
 65c:	da823420 	csneg	x0, x1, x2, cc	// cc = lo, ul, last
 660:	9a812420 	cinc	x0, x1, cc	// cc = lo, ul, last
 664:	da812020 	cinv	x0, x1, cc	// cc = lo, ul, last
 668:	da812420 	cneg	x0, x1, cc	// cc = lo, ul, last
 66c:	9a9f27e0 	cset	x0, cc	// cc = lo, ul, last
 670:	da9f23e0 	csetm	x0, cc	// cc = lo, ul, last
 674:	fa423025 	ccmp	x1, x2, #0x5, cc	// cc = lo, ul, last
 678:	fa47382a 	ccmp	x1, #0x7, #0xa, cc	// cc = lo, ul, last
 67c:	9a824020 	csel	x0, x1, x2, mi	// mi = first
 680:	9a824420 	csinc	x0, x1, x2, mi	// mi = first
 684:	da824020 	csinv	x0, x1, x2, mi	// mi = first
 688:	da824420 	csneg	x0, x1, x2, mi	// mi = first
 68c:	9a815420 	cinc	x0, x1, mi	// mi = first
 690:	da815020 	cinv	x0, x1, mi	// mi = first
 694:	da815420 	cneg	x0, x1, mi	// mi = first
 698:	9a9f57e0 	cset	x0, mi	// mi = first
 69c:	da9f53e0 	csetm	x0, mi	// mi = first
 6a0:	fa424025 	ccmp	x1, x2, #0x5, mi	// mi = first
 6a4:	fa47482a 	ccmp	x1, #0x7, #0xa, mi	// mi = first
 6a8:	9a825020 	csel	x0, x1, x2, pl	// pl = nfrst
 6ac:	9a825420 	csinc	x0, x1, x2, pl	// pl = nfrst
 6b0:	da825020 	csinv	x0, x1, x2, pl	// pl = nfrst
 6b4:	da825420 	csneg	x0, x1, x2, pl	// pl = nfrst
 6b8:	9a814420 	cinc	x0, x1, pl	// pl = nfrst
 6bc:	da814020 	cinv	x0, x1, pl	// pl = nfrst
 6c0:	da814420 	cneg	x0, x1, pl	// pl = nfrst
 6c4:	9a9f47e0 	cset	x0, pl	// pl = nfrst
 6c8:	da9f43e0 	csetm	x0, pl	// pl = nfrst
 6cc:	fa425025 	ccmp	x1, x2, #0x5, pl	// pl = nfrst
 6d0:	fa47582a 	ccmp	x1, #0x7, #0xa, pl	// pl = nfrst
 6d4:	9a826020 	csel	x0, x1, x2, vs
 6d8:	9a826420 	csinc	x0, x1, x2, vs
 6dc:	da826020 	csinv	x0, x1, x2, vs
 6e0:	da826420 	csneg	x0, x1, x2, vs
 6e4:	9a817420 	cinc	x0, x1, vs
 6e8:	da817020 	cinv	x0, x1, vs
 6ec:	da817420 	cneg	x0, x1, vs
 6f0:	9a9f77e0 	cset	x0, vs
 6f4:	da9f73e0 	csetm	x0, vs
 6f8:	fa426025 	ccmp	x1, x2, #0x5, vs
 6fc:	fa47682a 	ccmp	x1, #0x7, #0xa, vs
 700:	9a827020 	csel	x0, x1, x2, vc
 704:	9a827420 	csinc	x0, x1, x2, vc
 708:	da827020 	csinv	x0, x1, x2, vc
 70c:	da827420 	csneg	x0, x1, x2, vc
 710:	9a816420 	cinc	x0, x1, vc
 714:	da816020 	cinv	x0, x1, vc
 718:	da816420 	cneg	x0, x1, vc
 71c:	9a9f67e0 	cset	x0, vc
 720:	da9f63e0 	csetm	x0, vc
 724:	fa427025 	ccmp	x1, x2, #0x5, vc
 728:	fa47782a 	ccmp	x1, #0x7, #0xa, vc
 72c:	9a828020 	csel	x0, x1, x2, hi	// hi = pmore
 730:	9a828420 	csinc	x0, x1, x2, hi	// hi = pmore
 734:	da828020 	csinv	x0, x1, x2, hi	// hi = pmore
 738:	da828420 	csneg	x0, x1, x2, hi	// hi = pmore
 73c:	9a819420 	cinc	x0, x1, hi	// hi = pmore
 740:	da819020 	cinv	x0, x1, hi	// hi = pmore
 744:	da819420 	cneg	x0, x1, hi	// hi = pmore
 748:	9a9f97e0 	cset	x0, hi	// hi = pmore
 74c:	da9f93e0 	csetm	x0, hi	// hi = pmore
 750:	fa428025 	ccmp	x1, x2, #0x5, hi	// hi = pmore
 754:	fa47882a 	ccmp	x1, #0x7, #0xa, hi	// hi = pmore
 758:	9a829020 	csel	x0, x1, x2, ls	// ls = plast
 75c:	9a829420 	csinc	x0, x1, x2, ls	// ls = plast
 760:	da829020 	csinv	x0, x1, x2, ls	// ls = plast
 764:	da829420 	csneg	x0, x1, x2, ls	// ls = plast
 768:	9a818420 	cinc	x0, x1, ls	// ls = plast
 76c:	da818020 	cinv	x0, x1, ls	// ls = plast
 770:	da818420 	cneg	x0, x1, ls	// ls = plast
 774:	9a9f87e0 	cset	x0, ls	// ls = plast
 778:	da9f83e0 	csetm	x0, ls	// ls = plast
 77c:	fa429025 	ccmp	x1, x2, #0x5, ls	// ls = plast
 780:	fa47982a 	ccmp	x1, #0x7, #0xa, ls	// ls = plast
 784:	9a82a020 	csel	x0, x1, x2, ge	// ge = tcont
 788:	9a82a420 	csinc	x0, x1, x2, ge	// ge = tcont
 78c:	da82a020 	csinv	x0, x1, x2, ge	// ge = tcont
 790:	da82a420 	csneg	x0, x1, x2, ge	// ge = tcont
 794:	9a81b420 	cinc	x0, x1, ge	// ge = tcont
 798:	da81b020 	cinv	x0, x1, ge	// ge = tcont
 79c:	da81b420 	cneg	x0, x1, ge	// ge = tcont
 7a0:	9a9fb7e0 	cset	x0, ge	// ge = tcont
 7a4:	da9fb3e0 	csetm	x0, ge	// ge = tcont
 7a8:	fa42a025 	ccmp	x1, x2, #0x5, ge	// ge = tcont
 7ac:	fa47a82a 	ccmp	x1, #0x7, #0xa, ge	// ge = tcont
 7b0:	9a82b020 	csel	x0, x1, x2, lt	// lt = tstop
 7b4:	9a82b420 	csinc	x0, x1, x2, lt	// lt = tstop
 7b8:	da82b020 	csinv	x0, x1, x2, lt	// lt = tstop
 7bc:	da82b420 	csneg	x0, x1, x2, lt	// lt = tstop
 7c0:	9a81a420 	cinc	x0, x1, lt	// lt = tstop
 7c4:	da81a020 	cinv	x0, x1, lt	// lt = tstop
 7c8:	da81a420 	cneg	x0, x1, lt	// lt = tstop
 7cc:	9a9fa7e0 	cset	x0, lt	// lt = tstop
 7d0:	da9fa3e0 	csetm	x0, lt	// lt = tstop
 7d4:	fa42b025 	ccmp	x1, x2, #0x5, lt	// lt = tstop
 7d8:	fa47b82a 	ccmp	x1, #0x7, #0xa, lt	// lt = tstop
 7dc:	9a82c020 	csel	x0, x1, x2, gt
 7e0:	9a82c420 	csinc	x0, x1, x2, gt
 7e4:	da82c020 	csinv	x0, x1, x2, gt
 7e8:	da82c420 	csneg	x0, x1, x2, gt
 7ec:	9a81d420 	cinc	x0, x1, gt
 7f0:	da81d020 	cinv	x0, x1, gt
 7f4:	da81d420 	cneg	x0, x1, gt
 7f8:	9a9fd7e0 	cset	x0, gt
 7fc:	da9fd3e0 	csetm	x0, gt
 800:	fa42c025 	ccmp	x1, x2, #0x5, gt
 804:	fa47c82a 	ccmp	x1, #0x7, #0xa, gt
 808:	9a82d020 	csel	x0, x1, x2, le
 80c:	9a82d420 	csinc	x0, x1, x2, le
 810:	da82d020 	csinv	x0, x1, x2, le
 814:	da82d420 	csneg	x0, x1, x2, le
 818:	9a81c420 	cinc	x0, x1, le
 81c:	da81c020 	cinv	x0, x1, le
 820:	da81c420 	cneg	x0, x1, le
 824:	9a9fc7e0 	cset	x0, le
 828:	da9fc3e0 	csetm	x0, le
 82c:	fa42d025 	ccmp	x1, x2, #0x5, le
 830:	fa47d82a 	ccmp	x1, #0x7, #0xa, le
 834:	9a82e020 	csel	x0, x1, x2, al
 838:	9a82e420 	csinc	x0, x1, x2, al
 83c:	da82e020 	csinv	x0, x1, x2, al
 840:	da82e420 	csneg	x0, x1, x2, al
 844:	fa42e025 	ccmp	x1, x2, #0x5, al
 848:	fa47e82a 	ccmp	x1, #0x7, #0xa, al
 84c:	9a82f020 	csel	x0, x1, x2, nv
 850:	9a82f420 	csinc	x0, x1, x2, nv
 854:	da82f020 	csinv	x0, x1, x2, nv
 858:	da82f420 	csneg	x0, x1, x2, nv
 85c:	fa42f025 	ccmp	x1, x2, #0x5, nv
 860:	fa47f82a 	ccmp	x1, #0x7, #0xa, nv
 864:	f9400480 	ldr	x0, [x4, #8]
 868:	f9000480 	str	x0, [x4, #8]
 86c:	f8408080 	ldur	x0, [x4, #8]
 870:	f8008080 	stur	x0, [x4, #8]
 874:	f8408c80 	ldr	x0, [x4, #8]!
 878:	f8408480 	ldr	x0, [x4], #8
 87c:	f8657880 	ldr	x0, [x4, x5, lsl #3]
 880:	f8008c80 	str	x0, [x4, #8]!
 884:	f8008480 	str	x0, [x4], #8
 888:	f8257880 	str	x0, [x4, x5, lsl #3]
 88c:	39802080 	ldrsb	x0, [x4, #8]
 890:	79801080 	ldrsh	x0, [x4, #8]
 894:	93407c20 	sxtw	x0, w1
 898:	9bc27c20 	umulh	x0, x1, x2
 89c:	9ba27c20 	umull	x0, w1, w2
 8a0:	9ba20c20 	umaddl	x0, w1, w2, x3
 8a4:	9b220c20 	smaddl	x0, w1, w2, x3
 8a8:	b9800880 	ldrsw	x0, [x4, #8]
 8ac:	a9408480 	ldp	x0, x1, [x4, #8]
 8b0:	a9008480 	stp	x0, x1, [x4, #8]
 8b4:	9e670000 	fmov	d0, x0
 8b8:	9e660000 	fmov	x0, d0
 8bc:	1e270000 	fmov	s0, w0
 8c0:	1e260000 	fmov	w0, s0
 8c4:	0e205800 	cnt	v0.8b, v0.8b
 8c8:	4e205800 	cnt	v0.16b, v0.16b
 8cc:	2e303800 	uaddlv	h0, v0.8b
 8d0:	6e303800 	uaddlv	h0, v0.16b
 8d4:	3dc00480 	ldr	q0, [x4, #16]
 8d8:	3d800480 	str	q0, [x4, #16]
