#include "../driver.h"
#include <stdlib.h>
#define ARM64_SIM_ENABLE_STACK 1
#define ARM64_SIM_RET_CASES_10000f4 
#define ARM64_SIM_RET_CASES_10010f8 
#define ARM64_SIM_RET_CASES_10020f4 
#define ARM64_SIM_RET_CASES_10030f8 
#define ARM64_SIM_RET_CASES_10040f4 
#define ARM64_SIM_RET_CASES_10050f8 
#define ARM64_SIM_RET_CASES_10060f4 
#define ARM64_SIM_RET_CASES_10070f8 
#define ARM64_SIM_RET_CASES_10080f4 
#define ARM64_SIM_RET_CASES_10090f8 
#define ARM64_SIM_RET_CASES_100a0f4 
#define ARM64_SIM_RET_CASES_100b0f8 
#define ARM64_SIM_RET_CASES_100c0f4 
#define ARM64_SIM_RET_CASES_100d0f8 
#define ARM64_SIM_RET_CASES_100e0f4 
#define ARM64_SIM_RET_CASES_100f0f8 
#define ARM64_SIM_RET_CASES_10100f4 
#define ARM64_SIM_RET_CASES_10110f8 
#define ARM64_SIM_RET_CASES_10120f4 
#define ARM64_SIM_RET_CASES_10130f8 
#define ARM64_SIM_RET_CASES_10140f4 
#define ARM64_SIM_RET_CASES_10150f8 
#define ARM64_SIM_RET_CASES_10160f4 
#define ARM64_SIM_RET_CASES_10170f8 
#define ARM64_SIM_RET_CASES_10180f4 
#define ARM64_SIM_RET_CASES_10190f8 
#define ARM64_SIM_RET_CASES_101a0f4 
#define ARM64_SIM_RET_CASES_101b0f8 
#define ARM64_SIM_RET_CASES_101c0f4 
#define ARM64_SIM_RET_CASES_101d0f8 
#define ARM64_SIM_RET_CASES_101e0f4 
#define ARM64_SIM_RET_CASES_101f0f8 
#define ARM64_SIM_RET_CASES_10200f4 
#define ARM64_SIM_RET_CASES_10210f8 
#define ARM64_SIM_RET_CASES_10220f4 
#define ARM64_SIM_RET_CASES_10230f8 
#define ARM64_SIM_RET_CASES_10240f4 
#define ARM64_SIM_RET_CASES_10250f8 
#define ARM64_SIM_RET_CASES_10260f4 
#define ARM64_SIM_RET_CASES_10270f8 
#define ARM64_SIM_RET_CASES_10280f4 
#define ARM64_SIM_RET_CASES_10290f8 
#define ARM64_SIM_RET_CASES_102a0f4 
#define ARM64_SIM_RET_CASES_102b0f8 
#define ARM64_SIM_RET_CASES_102c0f4 
#define ARM64_SIM_RET_CASES_102d0f8 
#define ARM64_SIM_RET_CASES_102e0f4 
#define ARM64_SIM_RET_CASES_102f0f8 
#define ARM64_SIM_RET_CASES_10300f4 
#define ARM64_SIM_RET_CASES_10310f8 
#define ARM64_SIM_RET_CASES_10320f4 
#define ARM64_SIM_RET_CASES_10330f8 
#define ARM64_SIM_RET_CASES_10340f4 
#define ARM64_SIM_RET_CASES_10350f8 
#define ARM64_SIM_RET_CASES_10360f4 
#define ARM64_SIM_RET_CASES_10370f8 
#define ARM64_SIM_RET_CASES_10380f4 
#define ARM64_SIM_RET_CASES_10390f8 
#define ARM64_SIM_RET_CASES_103a0f4 
#define ARM64_SIM_RET_CASES_103b0f8 
#define ARM64_SIM_RET_CASES_103c0f4 
#define ARM64_SIM_RET_CASES_103d0f8 
#define ARM64_SIM_RET_CASES_103e0f4 
#define ARM64_SIM_RET_CASES_103f0f8 
#define ARM64_SIM_RET_CASES_10400f8 
#define ARM64_SIM_RET_CASES_10410f8 
#define ARM64_SIM_RET_CASES_10420f0 
#define ARM64_SIM_RET_CASES_1042104 
#define ARM64_SIM_RET_CASES_10430ec case 0x10430e4ULL: goto arm64_l_10430e4;
#define ARM64_SIM_RET_CASES_10430f0 
#define ARM64_SIM_RET_CASES_10440f0 case 0x10440e4ULL: goto arm64_l_10440e4;
#define ARM64_SIM_RET_CASES_10440f4 
#define ARM64_SIM_RET_CASES_10450f0 case 0x10450e8ULL: goto arm64_l_10450e8;
#define ARM64_SIM_RET_CASES_10450f4 
#define ARM64_SIM_RET_CASES_10460f4 case 0x10460e4ULL: goto arm64_l_10460e4;
#define ARM64_SIM_RET_CASES_10460fc case 0x10460f0ULL: goto arm64_l_10460f0;
#define ARM64_SIM_RET_CASES_1046100 
#define ARM64_SIM_RET_CASES_10470f8 case 0x10470e4ULL: goto arm64_l_10470e4;
#define ARM64_SIM_RET_CASES_1047100 case 0x10470f4ULL: goto arm64_l_10470f4;
#define ARM64_SIM_RET_CASES_1047104 
#define ARM64_SIM_RET_CASES_10480ec 
#define ARM64_SIM_RET_CASES_10490ec 
#define ARM64_SIM_RET_CASES_104a0f8 
#define ARM64_SIM_RET_CASES_104b0ec 
#define ARM64_SIM_RET_CASES_104c0f8 
#include "/workspaces/repository/kprog/fidelity/build-arm64-control-current/snapshot/kprog/arm64/arm64_sim_local_bpf.h"
static void arm64_sim_unsupported_opcode(void) { abort(); }
#undef ARM64_SIM_RET
#define ARM64_SIM_RET() goto observed
extern void native_0(struct state *);
extern unsigned char native_pc_0,native_next_0;
static void sim_0(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10000e0:;
	/* 0x10000e0: b.eq 10000ec <native_pc_0+0xc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x10000e0, 0x10000ec, arm64_l_10000ec);
arm64_l_10000e4:;
	/* 0x10000e4: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10000e8:;
	/* 0x10000e8: b 10000f4 <outer_done_0> */
	ARM64_SIM_A64_JMP(0x10000e8, 0x10000f4, arm64_l_10000f4);
arm64_l_10000ec:;
	/* 0x10000ec: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10000f0:;
	/* 0x10000f0: b 10000f4 <outer_done_0> */
	ARM64_SIM_A64_JMP(0x10000f0, 0x10000f4, arm64_l_10000f4);
arm64_l_10000f4:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_1(struct state *);
extern unsigned char native_pc_1,native_next_1;
static void sim_1(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10010e0:;
	/* 0x10010e0: b 10010ec <native_pc_1+0xc> */
	ARM64_SIM_A64_JMP(0x10010e0, 0x10010ec, arm64_l_10010ec);
arm64_l_10010e4:;
	/* 0x10010e4: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10010e8:;
	/* 0x10010e8: b 10010f8 <outer_done_1> */
	ARM64_SIM_A64_JMP(0x10010e8, 0x10010f8, arm64_l_10010f8);
arm64_l_10010ec:;
	/* 0x10010ec: b.eq 10010e4 <native_pc_1+0x4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x10010ec, 0x10010e4, arm64_l_10010e4);
arm64_l_10010f0:;
	/* 0x10010f0: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10010f4:;
	/* 0x10010f4: b 10010f8 <outer_done_1> */
	ARM64_SIM_A64_JMP(0x10010f4, 0x10010f8, arm64_l_10010f8);
arm64_l_10010f8:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_2(struct state *);
extern unsigned char native_pc_2,native_next_2;
static void sim_2(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10020e0:;
	/* 0x10020e0: b.ne 10020ec <native_pc_2+0xc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x10020e0, 0x10020ec, arm64_l_10020ec);
arm64_l_10020e4:;
	/* 0x10020e4: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10020e8:;
	/* 0x10020e8: b 10020f4 <outer_done_2> */
	ARM64_SIM_A64_JMP(0x10020e8, 0x10020f4, arm64_l_10020f4);
arm64_l_10020ec:;
	/* 0x10020ec: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10020f0:;
	/* 0x10020f0: b 10020f4 <outer_done_2> */
	ARM64_SIM_A64_JMP(0x10020f0, 0x10020f4, arm64_l_10020f4);
arm64_l_10020f4:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_3(struct state *);
extern unsigned char native_pc_3,native_next_3;
static void sim_3(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10030e0:;
	/* 0x10030e0: b 10030ec <native_pc_3+0xc> */
	ARM64_SIM_A64_JMP(0x10030e0, 0x10030ec, arm64_l_10030ec);
arm64_l_10030e4:;
	/* 0x10030e4: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10030e8:;
	/* 0x10030e8: b 10030f8 <outer_done_3> */
	ARM64_SIM_A64_JMP(0x10030e8, 0x10030f8, arm64_l_10030f8);
arm64_l_10030ec:;
	/* 0x10030ec: b.ne 10030e4 <native_pc_3+0x4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x10030ec, 0x10030e4, arm64_l_10030e4);
arm64_l_10030f0:;
	/* 0x10030f0: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10030f4:;
	/* 0x10030f4: b 10030f8 <outer_done_3> */
	ARM64_SIM_A64_JMP(0x10030f4, 0x10030f8, arm64_l_10030f8);
arm64_l_10030f8:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_4(struct state *);
extern unsigned char native_pc_4,native_next_4;
static void sim_4(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10040e0:;
	/* 0x10040e0: b.cs 10040ec <native_pc_4+0xc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x10040e0, 0x10040ec, arm64_l_10040ec);
arm64_l_10040e4:;
	/* 0x10040e4: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10040e8:;
	/* 0x10040e8: b 10040f4 <outer_done_4> */
	ARM64_SIM_A64_JMP(0x10040e8, 0x10040f4, arm64_l_10040f4);
arm64_l_10040ec:;
	/* 0x10040ec: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10040f0:;
	/* 0x10040f0: b 10040f4 <outer_done_4> */
	ARM64_SIM_A64_JMP(0x10040f0, 0x10040f4, arm64_l_10040f4);
arm64_l_10040f4:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_5(struct state *);
extern unsigned char native_pc_5,native_next_5;
static void sim_5(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10050e0:;
	/* 0x10050e0: b 10050ec <native_pc_5+0xc> */
	ARM64_SIM_A64_JMP(0x10050e0, 0x10050ec, arm64_l_10050ec);
arm64_l_10050e4:;
	/* 0x10050e4: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10050e8:;
	/* 0x10050e8: b 10050f8 <outer_done_5> */
	ARM64_SIM_A64_JMP(0x10050e8, 0x10050f8, arm64_l_10050f8);
arm64_l_10050ec:;
	/* 0x10050ec: b.cs 10050e4 <native_pc_5+0x4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x10050ec, 0x10050e4, arm64_l_10050e4);
arm64_l_10050f0:;
	/* 0x10050f0: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10050f4:;
	/* 0x10050f4: b 10050f8 <outer_done_5> */
	ARM64_SIM_A64_JMP(0x10050f4, 0x10050f8, arm64_l_10050f8);
arm64_l_10050f8:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_6(struct state *);
extern unsigned char native_pc_6,native_next_6;
static void sim_6(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10060e0:;
	/* 0x10060e0: b.cc 10060ec <native_pc_6+0xc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x10060e0, 0x10060ec, arm64_l_10060ec);
arm64_l_10060e4:;
	/* 0x10060e4: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10060e8:;
	/* 0x10060e8: b 10060f4 <outer_done_6> */
	ARM64_SIM_A64_JMP(0x10060e8, 0x10060f4, arm64_l_10060f4);
arm64_l_10060ec:;
	/* 0x10060ec: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10060f0:;
	/* 0x10060f0: b 10060f4 <outer_done_6> */
	ARM64_SIM_A64_JMP(0x10060f0, 0x10060f4, arm64_l_10060f4);
arm64_l_10060f4:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_7(struct state *);
extern unsigned char native_pc_7,native_next_7;
static void sim_7(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10070e0:;
	/* 0x10070e0: b 10070ec <native_pc_7+0xc> */
	ARM64_SIM_A64_JMP(0x10070e0, 0x10070ec, arm64_l_10070ec);
arm64_l_10070e4:;
	/* 0x10070e4: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10070e8:;
	/* 0x10070e8: b 10070f8 <outer_done_7> */
	ARM64_SIM_A64_JMP(0x10070e8, 0x10070f8, arm64_l_10070f8);
arm64_l_10070ec:;
	/* 0x10070ec: b.cc 10070e4 <native_pc_7+0x4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x10070ec, 0x10070e4, arm64_l_10070e4);
arm64_l_10070f0:;
	/* 0x10070f0: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10070f4:;
	/* 0x10070f4: b 10070f8 <outer_done_7> */
	ARM64_SIM_A64_JMP(0x10070f4, 0x10070f8, arm64_l_10070f8);
arm64_l_10070f8:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_8(struct state *);
extern unsigned char native_pc_8,native_next_8;
static void sim_8(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10080e0:;
	/* 0x10080e0: b.mi 10080ec <native_pc_8+0xc> */
	ARM64_SIM_A64_JCC(ARM64_COND_MI, 0x10080e0, 0x10080ec, arm64_l_10080ec);
arm64_l_10080e4:;
	/* 0x10080e4: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10080e8:;
	/* 0x10080e8: b 10080f4 <outer_done_8> */
	ARM64_SIM_A64_JMP(0x10080e8, 0x10080f4, arm64_l_10080f4);
arm64_l_10080ec:;
	/* 0x10080ec: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10080f0:;
	/* 0x10080f0: b 10080f4 <outer_done_8> */
	ARM64_SIM_A64_JMP(0x10080f0, 0x10080f4, arm64_l_10080f4);
arm64_l_10080f4:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_9(struct state *);
extern unsigned char native_pc_9,native_next_9;
static void sim_9(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10090e0:;
	/* 0x10090e0: b 10090ec <native_pc_9+0xc> */
	ARM64_SIM_A64_JMP(0x10090e0, 0x10090ec, arm64_l_10090ec);
arm64_l_10090e4:;
	/* 0x10090e4: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10090e8:;
	/* 0x10090e8: b 10090f8 <outer_done_9> */
	ARM64_SIM_A64_JMP(0x10090e8, 0x10090f8, arm64_l_10090f8);
arm64_l_10090ec:;
	/* 0x10090ec: b.mi 10090e4 <native_pc_9+0x4> */
	ARM64_SIM_A64_JCC(ARM64_COND_MI, 0x10090ec, 0x10090e4, arm64_l_10090e4);
arm64_l_10090f0:;
	/* 0x10090f0: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10090f4:;
	/* 0x10090f4: b 10090f8 <outer_done_9> */
	ARM64_SIM_A64_JMP(0x10090f4, 0x10090f8, arm64_l_10090f8);
arm64_l_10090f8:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_10(struct state *);
extern unsigned char native_pc_10,native_next_10;
static void sim_10(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_100a0e0:;
	/* 0x100a0e0: b.pl 100a0ec <native_pc_10+0xc> */
	ARM64_SIM_A64_JCC(ARM64_COND_PL, 0x100a0e0, 0x100a0ec, arm64_l_100a0ec);
arm64_l_100a0e4:;
	/* 0x100a0e4: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_100a0e8:;
	/* 0x100a0e8: b 100a0f4 <outer_done_10> */
	ARM64_SIM_A64_JMP(0x100a0e8, 0x100a0f4, arm64_l_100a0f4);
arm64_l_100a0ec:;
	/* 0x100a0ec: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_100a0f0:;
	/* 0x100a0f0: b 100a0f4 <outer_done_10> */
	ARM64_SIM_A64_JMP(0x100a0f0, 0x100a0f4, arm64_l_100a0f4);
arm64_l_100a0f4:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_11(struct state *);
extern unsigned char native_pc_11,native_next_11;
static void sim_11(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_100b0e0:;
	/* 0x100b0e0: b 100b0ec <native_pc_11+0xc> */
	ARM64_SIM_A64_JMP(0x100b0e0, 0x100b0ec, arm64_l_100b0ec);
arm64_l_100b0e4:;
	/* 0x100b0e4: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_100b0e8:;
	/* 0x100b0e8: b 100b0f8 <outer_done_11> */
	ARM64_SIM_A64_JMP(0x100b0e8, 0x100b0f8, arm64_l_100b0f8);
arm64_l_100b0ec:;
	/* 0x100b0ec: b.pl 100b0e4 <native_pc_11+0x4> */
	ARM64_SIM_A64_JCC(ARM64_COND_PL, 0x100b0ec, 0x100b0e4, arm64_l_100b0e4);
arm64_l_100b0f0:;
	/* 0x100b0f0: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_100b0f4:;
	/* 0x100b0f4: b 100b0f8 <outer_done_11> */
	ARM64_SIM_A64_JMP(0x100b0f4, 0x100b0f8, arm64_l_100b0f8);
arm64_l_100b0f8:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_12(struct state *);
extern unsigned char native_pc_12,native_next_12;
static void sim_12(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_100c0e0:;
	/* 0x100c0e0: b.vs 100c0ec <native_pc_12+0xc> */
	ARM64_SIM_A64_JCC(ARM64_COND_VS, 0x100c0e0, 0x100c0ec, arm64_l_100c0ec);
arm64_l_100c0e4:;
	/* 0x100c0e4: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_100c0e8:;
	/* 0x100c0e8: b 100c0f4 <outer_done_12> */
	ARM64_SIM_A64_JMP(0x100c0e8, 0x100c0f4, arm64_l_100c0f4);
arm64_l_100c0ec:;
	/* 0x100c0ec: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_100c0f0:;
	/* 0x100c0f0: b 100c0f4 <outer_done_12> */
	ARM64_SIM_A64_JMP(0x100c0f0, 0x100c0f4, arm64_l_100c0f4);
arm64_l_100c0f4:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_13(struct state *);
extern unsigned char native_pc_13,native_next_13;
static void sim_13(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_100d0e0:;
	/* 0x100d0e0: b 100d0ec <native_pc_13+0xc> */
	ARM64_SIM_A64_JMP(0x100d0e0, 0x100d0ec, arm64_l_100d0ec);
arm64_l_100d0e4:;
	/* 0x100d0e4: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_100d0e8:;
	/* 0x100d0e8: b 100d0f8 <outer_done_13> */
	ARM64_SIM_A64_JMP(0x100d0e8, 0x100d0f8, arm64_l_100d0f8);
arm64_l_100d0ec:;
	/* 0x100d0ec: b.vs 100d0e4 <native_pc_13+0x4> */
	ARM64_SIM_A64_JCC(ARM64_COND_VS, 0x100d0ec, 0x100d0e4, arm64_l_100d0e4);
arm64_l_100d0f0:;
	/* 0x100d0f0: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_100d0f4:;
	/* 0x100d0f4: b 100d0f8 <outer_done_13> */
	ARM64_SIM_A64_JMP(0x100d0f4, 0x100d0f8, arm64_l_100d0f8);
arm64_l_100d0f8:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_14(struct state *);
extern unsigned char native_pc_14,native_next_14;
static void sim_14(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_100e0e0:;
	/* 0x100e0e0: b.vc 100e0ec <native_pc_14+0xc> */
	ARM64_SIM_A64_JCC(ARM64_COND_VC, 0x100e0e0, 0x100e0ec, arm64_l_100e0ec);
arm64_l_100e0e4:;
	/* 0x100e0e4: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_100e0e8:;
	/* 0x100e0e8: b 100e0f4 <outer_done_14> */
	ARM64_SIM_A64_JMP(0x100e0e8, 0x100e0f4, arm64_l_100e0f4);
arm64_l_100e0ec:;
	/* 0x100e0ec: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_100e0f0:;
	/* 0x100e0f0: b 100e0f4 <outer_done_14> */
	ARM64_SIM_A64_JMP(0x100e0f0, 0x100e0f4, arm64_l_100e0f4);
arm64_l_100e0f4:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_15(struct state *);
extern unsigned char native_pc_15,native_next_15;
static void sim_15(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_100f0e0:;
	/* 0x100f0e0: b 100f0ec <native_pc_15+0xc> */
	ARM64_SIM_A64_JMP(0x100f0e0, 0x100f0ec, arm64_l_100f0ec);
arm64_l_100f0e4:;
	/* 0x100f0e4: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_100f0e8:;
	/* 0x100f0e8: b 100f0f8 <outer_done_15> */
	ARM64_SIM_A64_JMP(0x100f0e8, 0x100f0f8, arm64_l_100f0f8);
arm64_l_100f0ec:;
	/* 0x100f0ec: b.vc 100f0e4 <native_pc_15+0x4> */
	ARM64_SIM_A64_JCC(ARM64_COND_VC, 0x100f0ec, 0x100f0e4, arm64_l_100f0e4);
arm64_l_100f0f0:;
	/* 0x100f0f0: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_100f0f4:;
	/* 0x100f0f4: b 100f0f8 <outer_done_15> */
	ARM64_SIM_A64_JMP(0x100f0f4, 0x100f0f8, arm64_l_100f0f8);
arm64_l_100f0f8:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_16(struct state *);
extern unsigned char native_pc_16,native_next_16;
static void sim_16(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10100e0:;
	/* 0x10100e0: b.hi 10100ec <native_pc_16+0xc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x10100e0, 0x10100ec, arm64_l_10100ec);
arm64_l_10100e4:;
	/* 0x10100e4: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10100e8:;
	/* 0x10100e8: b 10100f4 <outer_done_16> */
	ARM64_SIM_A64_JMP(0x10100e8, 0x10100f4, arm64_l_10100f4);
arm64_l_10100ec:;
	/* 0x10100ec: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10100f0:;
	/* 0x10100f0: b 10100f4 <outer_done_16> */
	ARM64_SIM_A64_JMP(0x10100f0, 0x10100f4, arm64_l_10100f4);
arm64_l_10100f4:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_17(struct state *);
extern unsigned char native_pc_17,native_next_17;
static void sim_17(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10110e0:;
	/* 0x10110e0: b 10110ec <native_pc_17+0xc> */
	ARM64_SIM_A64_JMP(0x10110e0, 0x10110ec, arm64_l_10110ec);
arm64_l_10110e4:;
	/* 0x10110e4: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10110e8:;
	/* 0x10110e8: b 10110f8 <outer_done_17> */
	ARM64_SIM_A64_JMP(0x10110e8, 0x10110f8, arm64_l_10110f8);
arm64_l_10110ec:;
	/* 0x10110ec: b.hi 10110e4 <native_pc_17+0x4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x10110ec, 0x10110e4, arm64_l_10110e4);
arm64_l_10110f0:;
	/* 0x10110f0: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10110f4:;
	/* 0x10110f4: b 10110f8 <outer_done_17> */
	ARM64_SIM_A64_JMP(0x10110f4, 0x10110f8, arm64_l_10110f8);
arm64_l_10110f8:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_18(struct state *);
extern unsigned char native_pc_18,native_next_18;
static void sim_18(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10120e0:;
	/* 0x10120e0: b.ls 10120ec <native_pc_18+0xc> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x10120e0, 0x10120ec, arm64_l_10120ec);
arm64_l_10120e4:;
	/* 0x10120e4: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10120e8:;
	/* 0x10120e8: b 10120f4 <outer_done_18> */
	ARM64_SIM_A64_JMP(0x10120e8, 0x10120f4, arm64_l_10120f4);
arm64_l_10120ec:;
	/* 0x10120ec: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10120f0:;
	/* 0x10120f0: b 10120f4 <outer_done_18> */
	ARM64_SIM_A64_JMP(0x10120f0, 0x10120f4, arm64_l_10120f4);
arm64_l_10120f4:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_19(struct state *);
extern unsigned char native_pc_19,native_next_19;
static void sim_19(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10130e0:;
	/* 0x10130e0: b 10130ec <native_pc_19+0xc> */
	ARM64_SIM_A64_JMP(0x10130e0, 0x10130ec, arm64_l_10130ec);
arm64_l_10130e4:;
	/* 0x10130e4: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10130e8:;
	/* 0x10130e8: b 10130f8 <outer_done_19> */
	ARM64_SIM_A64_JMP(0x10130e8, 0x10130f8, arm64_l_10130f8);
arm64_l_10130ec:;
	/* 0x10130ec: b.ls 10130e4 <native_pc_19+0x4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x10130ec, 0x10130e4, arm64_l_10130e4);
arm64_l_10130f0:;
	/* 0x10130f0: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10130f4:;
	/* 0x10130f4: b 10130f8 <outer_done_19> */
	ARM64_SIM_A64_JMP(0x10130f4, 0x10130f8, arm64_l_10130f8);
arm64_l_10130f8:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_20(struct state *);
extern unsigned char native_pc_20,native_next_20;
static void sim_20(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10140e0:;
	/* 0x10140e0: b.ge 10140ec <native_pc_20+0xc> */
	ARM64_SIM_A64_JCC(ARM64_COND_GE, 0x10140e0, 0x10140ec, arm64_l_10140ec);
arm64_l_10140e4:;
	/* 0x10140e4: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10140e8:;
	/* 0x10140e8: b 10140f4 <outer_done_20> */
	ARM64_SIM_A64_JMP(0x10140e8, 0x10140f4, arm64_l_10140f4);
arm64_l_10140ec:;
	/* 0x10140ec: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10140f0:;
	/* 0x10140f0: b 10140f4 <outer_done_20> */
	ARM64_SIM_A64_JMP(0x10140f0, 0x10140f4, arm64_l_10140f4);
arm64_l_10140f4:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_21(struct state *);
extern unsigned char native_pc_21,native_next_21;
static void sim_21(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10150e0:;
	/* 0x10150e0: b 10150ec <native_pc_21+0xc> */
	ARM64_SIM_A64_JMP(0x10150e0, 0x10150ec, arm64_l_10150ec);
arm64_l_10150e4:;
	/* 0x10150e4: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10150e8:;
	/* 0x10150e8: b 10150f8 <outer_done_21> */
	ARM64_SIM_A64_JMP(0x10150e8, 0x10150f8, arm64_l_10150f8);
arm64_l_10150ec:;
	/* 0x10150ec: b.ge 10150e4 <native_pc_21+0x4> */
	ARM64_SIM_A64_JCC(ARM64_COND_GE, 0x10150ec, 0x10150e4, arm64_l_10150e4);
arm64_l_10150f0:;
	/* 0x10150f0: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10150f4:;
	/* 0x10150f4: b 10150f8 <outer_done_21> */
	ARM64_SIM_A64_JMP(0x10150f4, 0x10150f8, arm64_l_10150f8);
arm64_l_10150f8:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_22(struct state *);
extern unsigned char native_pc_22,native_next_22;
static void sim_22(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10160e0:;
	/* 0x10160e0: b.lt 10160ec <native_pc_22+0xc> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x10160e0, 0x10160ec, arm64_l_10160ec);
arm64_l_10160e4:;
	/* 0x10160e4: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10160e8:;
	/* 0x10160e8: b 10160f4 <outer_done_22> */
	ARM64_SIM_A64_JMP(0x10160e8, 0x10160f4, arm64_l_10160f4);
arm64_l_10160ec:;
	/* 0x10160ec: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10160f0:;
	/* 0x10160f0: b 10160f4 <outer_done_22> */
	ARM64_SIM_A64_JMP(0x10160f0, 0x10160f4, arm64_l_10160f4);
arm64_l_10160f4:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_23(struct state *);
extern unsigned char native_pc_23,native_next_23;
static void sim_23(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10170e0:;
	/* 0x10170e0: b 10170ec <native_pc_23+0xc> */
	ARM64_SIM_A64_JMP(0x10170e0, 0x10170ec, arm64_l_10170ec);
arm64_l_10170e4:;
	/* 0x10170e4: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10170e8:;
	/* 0x10170e8: b 10170f8 <outer_done_23> */
	ARM64_SIM_A64_JMP(0x10170e8, 0x10170f8, arm64_l_10170f8);
arm64_l_10170ec:;
	/* 0x10170ec: b.lt 10170e4 <native_pc_23+0x4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x10170ec, 0x10170e4, arm64_l_10170e4);
arm64_l_10170f0:;
	/* 0x10170f0: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10170f4:;
	/* 0x10170f4: b 10170f8 <outer_done_23> */
	ARM64_SIM_A64_JMP(0x10170f4, 0x10170f8, arm64_l_10170f8);
arm64_l_10170f8:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_24(struct state *);
extern unsigned char native_pc_24,native_next_24;
static void sim_24(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10180e0:;
	/* 0x10180e0: b.gt 10180ec <native_pc_24+0xc> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x10180e0, 0x10180ec, arm64_l_10180ec);
arm64_l_10180e4:;
	/* 0x10180e4: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10180e8:;
	/* 0x10180e8: b 10180f4 <outer_done_24> */
	ARM64_SIM_A64_JMP(0x10180e8, 0x10180f4, arm64_l_10180f4);
arm64_l_10180ec:;
	/* 0x10180ec: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10180f0:;
	/* 0x10180f0: b 10180f4 <outer_done_24> */
	ARM64_SIM_A64_JMP(0x10180f0, 0x10180f4, arm64_l_10180f4);
arm64_l_10180f4:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_25(struct state *);
extern unsigned char native_pc_25,native_next_25;
static void sim_25(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10190e0:;
	/* 0x10190e0: b 10190ec <native_pc_25+0xc> */
	ARM64_SIM_A64_JMP(0x10190e0, 0x10190ec, arm64_l_10190ec);
arm64_l_10190e4:;
	/* 0x10190e4: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10190e8:;
	/* 0x10190e8: b 10190f8 <outer_done_25> */
	ARM64_SIM_A64_JMP(0x10190e8, 0x10190f8, arm64_l_10190f8);
arm64_l_10190ec:;
	/* 0x10190ec: b.gt 10190e4 <native_pc_25+0x4> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x10190ec, 0x10190e4, arm64_l_10190e4);
arm64_l_10190f0:;
	/* 0x10190f0: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10190f4:;
	/* 0x10190f4: b 10190f8 <outer_done_25> */
	ARM64_SIM_A64_JMP(0x10190f4, 0x10190f8, arm64_l_10190f8);
arm64_l_10190f8:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_26(struct state *);
extern unsigned char native_pc_26,native_next_26;
static void sim_26(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_101a0e0:;
	/* 0x101a0e0: b.le 101a0ec <native_pc_26+0xc> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x101a0e0, 0x101a0ec, arm64_l_101a0ec);
arm64_l_101a0e4:;
	/* 0x101a0e4: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_101a0e8:;
	/* 0x101a0e8: b 101a0f4 <outer_done_26> */
	ARM64_SIM_A64_JMP(0x101a0e8, 0x101a0f4, arm64_l_101a0f4);
arm64_l_101a0ec:;
	/* 0x101a0ec: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_101a0f0:;
	/* 0x101a0f0: b 101a0f4 <outer_done_26> */
	ARM64_SIM_A64_JMP(0x101a0f0, 0x101a0f4, arm64_l_101a0f4);
arm64_l_101a0f4:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_27(struct state *);
extern unsigned char native_pc_27,native_next_27;
static void sim_27(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_101b0e0:;
	/* 0x101b0e0: b 101b0ec <native_pc_27+0xc> */
	ARM64_SIM_A64_JMP(0x101b0e0, 0x101b0ec, arm64_l_101b0ec);
arm64_l_101b0e4:;
	/* 0x101b0e4: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_101b0e8:;
	/* 0x101b0e8: b 101b0f8 <outer_done_27> */
	ARM64_SIM_A64_JMP(0x101b0e8, 0x101b0f8, arm64_l_101b0f8);
arm64_l_101b0ec:;
	/* 0x101b0ec: b.le 101b0e4 <native_pc_27+0x4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x101b0ec, 0x101b0e4, arm64_l_101b0e4);
arm64_l_101b0f0:;
	/* 0x101b0f0: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_101b0f4:;
	/* 0x101b0f4: b 101b0f8 <outer_done_27> */
	ARM64_SIM_A64_JMP(0x101b0f4, 0x101b0f8, arm64_l_101b0f8);
arm64_l_101b0f8:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_28(struct state *);
extern unsigned char native_pc_28,native_next_28;
static void sim_28(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_101c0e0:;
	/* 0x101c0e0: cbz w1, 101c0ec <native_pc_28+0xc> */
	ARM64_SIM_A64_CBZ_W(ARM64_X1, 0x101c0e0, 0x101c0ec, arm64_l_101c0ec);
arm64_l_101c0e4:;
	/* 0x101c0e4: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_101c0e8:;
	/* 0x101c0e8: b 101c0f4 <outer_done_28> */
	ARM64_SIM_A64_JMP(0x101c0e8, 0x101c0f4, arm64_l_101c0f4);
arm64_l_101c0ec:;
	/* 0x101c0ec: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_101c0f0:;
	/* 0x101c0f0: b 101c0f4 <outer_done_28> */
	ARM64_SIM_A64_JMP(0x101c0f0, 0x101c0f4, arm64_l_101c0f4);
arm64_l_101c0f4:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_29(struct state *);
extern unsigned char native_pc_29,native_next_29;
static void sim_29(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_101d0e0:;
	/* 0x101d0e0: b 101d0ec <native_pc_29+0xc> */
	ARM64_SIM_A64_JMP(0x101d0e0, 0x101d0ec, arm64_l_101d0ec);
arm64_l_101d0e4:;
	/* 0x101d0e4: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_101d0e8:;
	/* 0x101d0e8: b 101d0f8 <outer_done_29> */
	ARM64_SIM_A64_JMP(0x101d0e8, 0x101d0f8, arm64_l_101d0f8);
arm64_l_101d0ec:;
	/* 0x101d0ec: cbz w1, 101d0e4 <native_pc_29+0x4> */
	ARM64_SIM_A64_CBZ_W(ARM64_X1, 0x101d0ec, 0x101d0e4, arm64_l_101d0e4);
arm64_l_101d0f0:;
	/* 0x101d0f0: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_101d0f4:;
	/* 0x101d0f4: b 101d0f8 <outer_done_29> */
	ARM64_SIM_A64_JMP(0x101d0f4, 0x101d0f8, arm64_l_101d0f8);
arm64_l_101d0f8:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_30(struct state *);
extern unsigned char native_pc_30,native_next_30;
static void sim_30(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_101e0e0:;
	/* 0x101e0e0: cbnz w1, 101e0ec <native_pc_30+0xc> */
	ARM64_SIM_A64_CBNZ_W(ARM64_X1, 0x101e0e0, 0x101e0ec, arm64_l_101e0ec);
arm64_l_101e0e4:;
	/* 0x101e0e4: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_101e0e8:;
	/* 0x101e0e8: b 101e0f4 <outer_done_30> */
	ARM64_SIM_A64_JMP(0x101e0e8, 0x101e0f4, arm64_l_101e0f4);
arm64_l_101e0ec:;
	/* 0x101e0ec: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_101e0f0:;
	/* 0x101e0f0: b 101e0f4 <outer_done_30> */
	ARM64_SIM_A64_JMP(0x101e0f0, 0x101e0f4, arm64_l_101e0f4);
arm64_l_101e0f4:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_31(struct state *);
extern unsigned char native_pc_31,native_next_31;
static void sim_31(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_101f0e0:;
	/* 0x101f0e0: b 101f0ec <native_pc_31+0xc> */
	ARM64_SIM_A64_JMP(0x101f0e0, 0x101f0ec, arm64_l_101f0ec);
arm64_l_101f0e4:;
	/* 0x101f0e4: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_101f0e8:;
	/* 0x101f0e8: b 101f0f8 <outer_done_31> */
	ARM64_SIM_A64_JMP(0x101f0e8, 0x101f0f8, arm64_l_101f0f8);
arm64_l_101f0ec:;
	/* 0x101f0ec: cbnz w1, 101f0e4 <native_pc_31+0x4> */
	ARM64_SIM_A64_CBNZ_W(ARM64_X1, 0x101f0ec, 0x101f0e4, arm64_l_101f0e4);
arm64_l_101f0f0:;
	/* 0x101f0f0: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_101f0f4:;
	/* 0x101f0f4: b 101f0f8 <outer_done_31> */
	ARM64_SIM_A64_JMP(0x101f0f4, 0x101f0f8, arm64_l_101f0f8);
arm64_l_101f0f8:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_32(struct state *);
extern unsigned char native_pc_32,native_next_32;
static void sim_32(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10200e0:;
	/* 0x10200e0: tbz w1, #0, 10200ec <native_pc_32+0xc> */
	ARM64_SIM_A64_TBZ(ARM64_X1, 0, 0x10200e0, 0x10200ec, arm64_l_10200ec);
arm64_l_10200e4:;
	/* 0x10200e4: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10200e8:;
	/* 0x10200e8: b 10200f4 <outer_done_32> */
	ARM64_SIM_A64_JMP(0x10200e8, 0x10200f4, arm64_l_10200f4);
arm64_l_10200ec:;
	/* 0x10200ec: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10200f0:;
	/* 0x10200f0: b 10200f4 <outer_done_32> */
	ARM64_SIM_A64_JMP(0x10200f0, 0x10200f4, arm64_l_10200f4);
arm64_l_10200f4:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_33(struct state *);
extern unsigned char native_pc_33,native_next_33;
static void sim_33(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10210e0:;
	/* 0x10210e0: b 10210ec <native_pc_33+0xc> */
	ARM64_SIM_A64_JMP(0x10210e0, 0x10210ec, arm64_l_10210ec);
arm64_l_10210e4:;
	/* 0x10210e4: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10210e8:;
	/* 0x10210e8: b 10210f8 <outer_done_33> */
	ARM64_SIM_A64_JMP(0x10210e8, 0x10210f8, arm64_l_10210f8);
arm64_l_10210ec:;
	/* 0x10210ec: tbz w1, #0, 10210e4 <native_pc_33+0x4> */
	ARM64_SIM_A64_TBZ(ARM64_X1, 0, 0x10210ec, 0x10210e4, arm64_l_10210e4);
arm64_l_10210f0:;
	/* 0x10210f0: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10210f4:;
	/* 0x10210f4: b 10210f8 <outer_done_33> */
	ARM64_SIM_A64_JMP(0x10210f4, 0x10210f8, arm64_l_10210f8);
arm64_l_10210f8:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_34(struct state *);
extern unsigned char native_pc_34,native_next_34;
static void sim_34(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10220e0:;
	/* 0x10220e0: tbz w1, #7, 10220ec <native_pc_34+0xc> */
	ARM64_SIM_A64_TBZ(ARM64_X1, 7, 0x10220e0, 0x10220ec, arm64_l_10220ec);
arm64_l_10220e4:;
	/* 0x10220e4: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10220e8:;
	/* 0x10220e8: b 10220f4 <outer_done_34> */
	ARM64_SIM_A64_JMP(0x10220e8, 0x10220f4, arm64_l_10220f4);
arm64_l_10220ec:;
	/* 0x10220ec: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10220f0:;
	/* 0x10220f0: b 10220f4 <outer_done_34> */
	ARM64_SIM_A64_JMP(0x10220f0, 0x10220f4, arm64_l_10220f4);
arm64_l_10220f4:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_35(struct state *);
extern unsigned char native_pc_35,native_next_35;
static void sim_35(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10230e0:;
	/* 0x10230e0: b 10230ec <native_pc_35+0xc> */
	ARM64_SIM_A64_JMP(0x10230e0, 0x10230ec, arm64_l_10230ec);
arm64_l_10230e4:;
	/* 0x10230e4: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10230e8:;
	/* 0x10230e8: b 10230f8 <outer_done_35> */
	ARM64_SIM_A64_JMP(0x10230e8, 0x10230f8, arm64_l_10230f8);
arm64_l_10230ec:;
	/* 0x10230ec: tbz w1, #7, 10230e4 <native_pc_35+0x4> */
	ARM64_SIM_A64_TBZ(ARM64_X1, 7, 0x10230ec, 0x10230e4, arm64_l_10230e4);
arm64_l_10230f0:;
	/* 0x10230f0: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10230f4:;
	/* 0x10230f4: b 10230f8 <outer_done_35> */
	ARM64_SIM_A64_JMP(0x10230f4, 0x10230f8, arm64_l_10230f8);
arm64_l_10230f8:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_36(struct state *);
extern unsigned char native_pc_36,native_next_36;
static void sim_36(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10240e0:;
	/* 0x10240e0: tbz w1, #31, 10240ec <native_pc_36+0xc> */
	ARM64_SIM_A64_TBZ(ARM64_X1, 31, 0x10240e0, 0x10240ec, arm64_l_10240ec);
arm64_l_10240e4:;
	/* 0x10240e4: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10240e8:;
	/* 0x10240e8: b 10240f4 <outer_done_36> */
	ARM64_SIM_A64_JMP(0x10240e8, 0x10240f4, arm64_l_10240f4);
arm64_l_10240ec:;
	/* 0x10240ec: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10240f0:;
	/* 0x10240f0: b 10240f4 <outer_done_36> */
	ARM64_SIM_A64_JMP(0x10240f0, 0x10240f4, arm64_l_10240f4);
arm64_l_10240f4:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_37(struct state *);
extern unsigned char native_pc_37,native_next_37;
static void sim_37(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10250e0:;
	/* 0x10250e0: b 10250ec <native_pc_37+0xc> */
	ARM64_SIM_A64_JMP(0x10250e0, 0x10250ec, arm64_l_10250ec);
arm64_l_10250e4:;
	/* 0x10250e4: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10250e8:;
	/* 0x10250e8: b 10250f8 <outer_done_37> */
	ARM64_SIM_A64_JMP(0x10250e8, 0x10250f8, arm64_l_10250f8);
arm64_l_10250ec:;
	/* 0x10250ec: tbz w1, #31, 10250e4 <native_pc_37+0x4> */
	ARM64_SIM_A64_TBZ(ARM64_X1, 31, 0x10250ec, 0x10250e4, arm64_l_10250e4);
arm64_l_10250f0:;
	/* 0x10250f0: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10250f4:;
	/* 0x10250f4: b 10250f8 <outer_done_37> */
	ARM64_SIM_A64_JMP(0x10250f4, 0x10250f8, arm64_l_10250f8);
arm64_l_10250f8:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_38(struct state *);
extern unsigned char native_pc_38,native_next_38;
static void sim_38(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10260e0:;
	/* 0x10260e0: tbnz w1, #0, 10260ec <native_pc_38+0xc> */
	ARM64_SIM_A64_TBNZ(ARM64_X1, 0, 0x10260e0, 0x10260ec, arm64_l_10260ec);
arm64_l_10260e4:;
	/* 0x10260e4: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10260e8:;
	/* 0x10260e8: b 10260f4 <outer_done_38> */
	ARM64_SIM_A64_JMP(0x10260e8, 0x10260f4, arm64_l_10260f4);
arm64_l_10260ec:;
	/* 0x10260ec: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10260f0:;
	/* 0x10260f0: b 10260f4 <outer_done_38> */
	ARM64_SIM_A64_JMP(0x10260f0, 0x10260f4, arm64_l_10260f4);
arm64_l_10260f4:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_39(struct state *);
extern unsigned char native_pc_39,native_next_39;
static void sim_39(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10270e0:;
	/* 0x10270e0: b 10270ec <native_pc_39+0xc> */
	ARM64_SIM_A64_JMP(0x10270e0, 0x10270ec, arm64_l_10270ec);
arm64_l_10270e4:;
	/* 0x10270e4: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10270e8:;
	/* 0x10270e8: b 10270f8 <outer_done_39> */
	ARM64_SIM_A64_JMP(0x10270e8, 0x10270f8, arm64_l_10270f8);
arm64_l_10270ec:;
	/* 0x10270ec: tbnz w1, #0, 10270e4 <native_pc_39+0x4> */
	ARM64_SIM_A64_TBNZ(ARM64_X1, 0, 0x10270ec, 0x10270e4, arm64_l_10270e4);
arm64_l_10270f0:;
	/* 0x10270f0: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10270f4:;
	/* 0x10270f4: b 10270f8 <outer_done_39> */
	ARM64_SIM_A64_JMP(0x10270f4, 0x10270f8, arm64_l_10270f8);
arm64_l_10270f8:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_40(struct state *);
extern unsigned char native_pc_40,native_next_40;
static void sim_40(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10280e0:;
	/* 0x10280e0: tbnz w1, #7, 10280ec <native_pc_40+0xc> */
	ARM64_SIM_A64_TBNZ(ARM64_X1, 7, 0x10280e0, 0x10280ec, arm64_l_10280ec);
arm64_l_10280e4:;
	/* 0x10280e4: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10280e8:;
	/* 0x10280e8: b 10280f4 <outer_done_40> */
	ARM64_SIM_A64_JMP(0x10280e8, 0x10280f4, arm64_l_10280f4);
arm64_l_10280ec:;
	/* 0x10280ec: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10280f0:;
	/* 0x10280f0: b 10280f4 <outer_done_40> */
	ARM64_SIM_A64_JMP(0x10280f0, 0x10280f4, arm64_l_10280f4);
arm64_l_10280f4:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_41(struct state *);
extern unsigned char native_pc_41,native_next_41;
static void sim_41(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10290e0:;
	/* 0x10290e0: b 10290ec <native_pc_41+0xc> */
	ARM64_SIM_A64_JMP(0x10290e0, 0x10290ec, arm64_l_10290ec);
arm64_l_10290e4:;
	/* 0x10290e4: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10290e8:;
	/* 0x10290e8: b 10290f8 <outer_done_41> */
	ARM64_SIM_A64_JMP(0x10290e8, 0x10290f8, arm64_l_10290f8);
arm64_l_10290ec:;
	/* 0x10290ec: tbnz w1, #7, 10290e4 <native_pc_41+0x4> */
	ARM64_SIM_A64_TBNZ(ARM64_X1, 7, 0x10290ec, 0x10290e4, arm64_l_10290e4);
arm64_l_10290f0:;
	/* 0x10290f0: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10290f4:;
	/* 0x10290f4: b 10290f8 <outer_done_41> */
	ARM64_SIM_A64_JMP(0x10290f4, 0x10290f8, arm64_l_10290f8);
arm64_l_10290f8:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_42(struct state *);
extern unsigned char native_pc_42,native_next_42;
static void sim_42(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_102a0e0:;
	/* 0x102a0e0: tbnz w1, #31, 102a0ec <native_pc_42+0xc> */
	ARM64_SIM_A64_TBNZ(ARM64_X1, 31, 0x102a0e0, 0x102a0ec, arm64_l_102a0ec);
arm64_l_102a0e4:;
	/* 0x102a0e4: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_102a0e8:;
	/* 0x102a0e8: b 102a0f4 <outer_done_42> */
	ARM64_SIM_A64_JMP(0x102a0e8, 0x102a0f4, arm64_l_102a0f4);
arm64_l_102a0ec:;
	/* 0x102a0ec: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_102a0f0:;
	/* 0x102a0f0: b 102a0f4 <outer_done_42> */
	ARM64_SIM_A64_JMP(0x102a0f0, 0x102a0f4, arm64_l_102a0f4);
arm64_l_102a0f4:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_43(struct state *);
extern unsigned char native_pc_43,native_next_43;
static void sim_43(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_102b0e0:;
	/* 0x102b0e0: b 102b0ec <native_pc_43+0xc> */
	ARM64_SIM_A64_JMP(0x102b0e0, 0x102b0ec, arm64_l_102b0ec);
arm64_l_102b0e4:;
	/* 0x102b0e4: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_102b0e8:;
	/* 0x102b0e8: b 102b0f8 <outer_done_43> */
	ARM64_SIM_A64_JMP(0x102b0e8, 0x102b0f8, arm64_l_102b0f8);
arm64_l_102b0ec:;
	/* 0x102b0ec: tbnz w1, #31, 102b0e4 <native_pc_43+0x4> */
	ARM64_SIM_A64_TBNZ(ARM64_X1, 31, 0x102b0ec, 0x102b0e4, arm64_l_102b0e4);
arm64_l_102b0f0:;
	/* 0x102b0f0: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_102b0f4:;
	/* 0x102b0f4: b 102b0f8 <outer_done_43> */
	ARM64_SIM_A64_JMP(0x102b0f4, 0x102b0f8, arm64_l_102b0f8);
arm64_l_102b0f8:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_44(struct state *);
extern unsigned char native_pc_44,native_next_44;
static void sim_44(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_102c0e0:;
	/* 0x102c0e0: cbz x1, 102c0ec <native_pc_44+0xc> */
	ARM64_SIM_A64_CBZ(ARM64_X1, 0x102c0e0, 0x102c0ec, arm64_l_102c0ec);
arm64_l_102c0e4:;
	/* 0x102c0e4: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_102c0e8:;
	/* 0x102c0e8: b 102c0f4 <outer_done_44> */
	ARM64_SIM_A64_JMP(0x102c0e8, 0x102c0f4, arm64_l_102c0f4);
arm64_l_102c0ec:;
	/* 0x102c0ec: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_102c0f0:;
	/* 0x102c0f0: b 102c0f4 <outer_done_44> */
	ARM64_SIM_A64_JMP(0x102c0f0, 0x102c0f4, arm64_l_102c0f4);
arm64_l_102c0f4:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_45(struct state *);
extern unsigned char native_pc_45,native_next_45;
static void sim_45(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_102d0e0:;
	/* 0x102d0e0: b 102d0ec <native_pc_45+0xc> */
	ARM64_SIM_A64_JMP(0x102d0e0, 0x102d0ec, arm64_l_102d0ec);
arm64_l_102d0e4:;
	/* 0x102d0e4: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_102d0e8:;
	/* 0x102d0e8: b 102d0f8 <outer_done_45> */
	ARM64_SIM_A64_JMP(0x102d0e8, 0x102d0f8, arm64_l_102d0f8);
arm64_l_102d0ec:;
	/* 0x102d0ec: cbz x1, 102d0e4 <native_pc_45+0x4> */
	ARM64_SIM_A64_CBZ(ARM64_X1, 0x102d0ec, 0x102d0e4, arm64_l_102d0e4);
arm64_l_102d0f0:;
	/* 0x102d0f0: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_102d0f4:;
	/* 0x102d0f4: b 102d0f8 <outer_done_45> */
	ARM64_SIM_A64_JMP(0x102d0f4, 0x102d0f8, arm64_l_102d0f8);
arm64_l_102d0f8:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_46(struct state *);
extern unsigned char native_pc_46,native_next_46;
static void sim_46(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_102e0e0:;
	/* 0x102e0e0: cbnz x1, 102e0ec <native_pc_46+0xc> */
	ARM64_SIM_A64_CBNZ(ARM64_X1, 0x102e0e0, 0x102e0ec, arm64_l_102e0ec);
arm64_l_102e0e4:;
	/* 0x102e0e4: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_102e0e8:;
	/* 0x102e0e8: b 102e0f4 <outer_done_46> */
	ARM64_SIM_A64_JMP(0x102e0e8, 0x102e0f4, arm64_l_102e0f4);
arm64_l_102e0ec:;
	/* 0x102e0ec: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_102e0f0:;
	/* 0x102e0f0: b 102e0f4 <outer_done_46> */
	ARM64_SIM_A64_JMP(0x102e0f0, 0x102e0f4, arm64_l_102e0f4);
arm64_l_102e0f4:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_47(struct state *);
extern unsigned char native_pc_47,native_next_47;
static void sim_47(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_102f0e0:;
	/* 0x102f0e0: b 102f0ec <native_pc_47+0xc> */
	ARM64_SIM_A64_JMP(0x102f0e0, 0x102f0ec, arm64_l_102f0ec);
arm64_l_102f0e4:;
	/* 0x102f0e4: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_102f0e8:;
	/* 0x102f0e8: b 102f0f8 <outer_done_47> */
	ARM64_SIM_A64_JMP(0x102f0e8, 0x102f0f8, arm64_l_102f0f8);
arm64_l_102f0ec:;
	/* 0x102f0ec: cbnz x1, 102f0e4 <native_pc_47+0x4> */
	ARM64_SIM_A64_CBNZ(ARM64_X1, 0x102f0ec, 0x102f0e4, arm64_l_102f0e4);
arm64_l_102f0f0:;
	/* 0x102f0f0: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_102f0f4:;
	/* 0x102f0f4: b 102f0f8 <outer_done_47> */
	ARM64_SIM_A64_JMP(0x102f0f4, 0x102f0f8, arm64_l_102f0f8);
arm64_l_102f0f8:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_48(struct state *);
extern unsigned char native_pc_48,native_next_48;
static void sim_48(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10300e0:;
	/* 0x10300e0: tbz w1, #0, 10300ec <native_pc_48+0xc> */
	ARM64_SIM_A64_TBZ(ARM64_X1, 0, 0x10300e0, 0x10300ec, arm64_l_10300ec);
arm64_l_10300e4:;
	/* 0x10300e4: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10300e8:;
	/* 0x10300e8: b 10300f4 <outer_done_48> */
	ARM64_SIM_A64_JMP(0x10300e8, 0x10300f4, arm64_l_10300f4);
arm64_l_10300ec:;
	/* 0x10300ec: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10300f0:;
	/* 0x10300f0: b 10300f4 <outer_done_48> */
	ARM64_SIM_A64_JMP(0x10300f0, 0x10300f4, arm64_l_10300f4);
arm64_l_10300f4:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_49(struct state *);
extern unsigned char native_pc_49,native_next_49;
static void sim_49(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10310e0:;
	/* 0x10310e0: b 10310ec <native_pc_49+0xc> */
	ARM64_SIM_A64_JMP(0x10310e0, 0x10310ec, arm64_l_10310ec);
arm64_l_10310e4:;
	/* 0x10310e4: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10310e8:;
	/* 0x10310e8: b 10310f8 <outer_done_49> */
	ARM64_SIM_A64_JMP(0x10310e8, 0x10310f8, arm64_l_10310f8);
arm64_l_10310ec:;
	/* 0x10310ec: tbz w1, #0, 10310e4 <native_pc_49+0x4> */
	ARM64_SIM_A64_TBZ(ARM64_X1, 0, 0x10310ec, 0x10310e4, arm64_l_10310e4);
arm64_l_10310f0:;
	/* 0x10310f0: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10310f4:;
	/* 0x10310f4: b 10310f8 <outer_done_49> */
	ARM64_SIM_A64_JMP(0x10310f4, 0x10310f8, arm64_l_10310f8);
arm64_l_10310f8:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_50(struct state *);
extern unsigned char native_pc_50,native_next_50;
static void sim_50(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10320e0:;
	/* 0x10320e0: tbz w1, #7, 10320ec <native_pc_50+0xc> */
	ARM64_SIM_A64_TBZ(ARM64_X1, 7, 0x10320e0, 0x10320ec, arm64_l_10320ec);
arm64_l_10320e4:;
	/* 0x10320e4: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10320e8:;
	/* 0x10320e8: b 10320f4 <outer_done_50> */
	ARM64_SIM_A64_JMP(0x10320e8, 0x10320f4, arm64_l_10320f4);
arm64_l_10320ec:;
	/* 0x10320ec: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10320f0:;
	/* 0x10320f0: b 10320f4 <outer_done_50> */
	ARM64_SIM_A64_JMP(0x10320f0, 0x10320f4, arm64_l_10320f4);
arm64_l_10320f4:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_51(struct state *);
extern unsigned char native_pc_51,native_next_51;
static void sim_51(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10330e0:;
	/* 0x10330e0: b 10330ec <native_pc_51+0xc> */
	ARM64_SIM_A64_JMP(0x10330e0, 0x10330ec, arm64_l_10330ec);
arm64_l_10330e4:;
	/* 0x10330e4: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10330e8:;
	/* 0x10330e8: b 10330f8 <outer_done_51> */
	ARM64_SIM_A64_JMP(0x10330e8, 0x10330f8, arm64_l_10330f8);
arm64_l_10330ec:;
	/* 0x10330ec: tbz w1, #7, 10330e4 <native_pc_51+0x4> */
	ARM64_SIM_A64_TBZ(ARM64_X1, 7, 0x10330ec, 0x10330e4, arm64_l_10330e4);
arm64_l_10330f0:;
	/* 0x10330f0: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10330f4:;
	/* 0x10330f4: b 10330f8 <outer_done_51> */
	ARM64_SIM_A64_JMP(0x10330f4, 0x10330f8, arm64_l_10330f8);
arm64_l_10330f8:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_52(struct state *);
extern unsigned char native_pc_52,native_next_52;
static void sim_52(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10340e0:;
	/* 0x10340e0: tbz w1, #31, 10340ec <native_pc_52+0xc> */
	ARM64_SIM_A64_TBZ(ARM64_X1, 31, 0x10340e0, 0x10340ec, arm64_l_10340ec);
arm64_l_10340e4:;
	/* 0x10340e4: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10340e8:;
	/* 0x10340e8: b 10340f4 <outer_done_52> */
	ARM64_SIM_A64_JMP(0x10340e8, 0x10340f4, arm64_l_10340f4);
arm64_l_10340ec:;
	/* 0x10340ec: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10340f0:;
	/* 0x10340f0: b 10340f4 <outer_done_52> */
	ARM64_SIM_A64_JMP(0x10340f0, 0x10340f4, arm64_l_10340f4);
arm64_l_10340f4:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_53(struct state *);
extern unsigned char native_pc_53,native_next_53;
static void sim_53(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10350e0:;
	/* 0x10350e0: b 10350ec <native_pc_53+0xc> */
	ARM64_SIM_A64_JMP(0x10350e0, 0x10350ec, arm64_l_10350ec);
arm64_l_10350e4:;
	/* 0x10350e4: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10350e8:;
	/* 0x10350e8: b 10350f8 <outer_done_53> */
	ARM64_SIM_A64_JMP(0x10350e8, 0x10350f8, arm64_l_10350f8);
arm64_l_10350ec:;
	/* 0x10350ec: tbz w1, #31, 10350e4 <native_pc_53+0x4> */
	ARM64_SIM_A64_TBZ(ARM64_X1, 31, 0x10350ec, 0x10350e4, arm64_l_10350e4);
arm64_l_10350f0:;
	/* 0x10350f0: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10350f4:;
	/* 0x10350f4: b 10350f8 <outer_done_53> */
	ARM64_SIM_A64_JMP(0x10350f4, 0x10350f8, arm64_l_10350f8);
arm64_l_10350f8:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_54(struct state *);
extern unsigned char native_pc_54,native_next_54;
static void sim_54(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10360e0:;
	/* 0x10360e0: tbz x1, #63, 10360ec <native_pc_54+0xc> */
	ARM64_SIM_A64_TBZ(ARM64_X1, 63, 0x10360e0, 0x10360ec, arm64_l_10360ec);
arm64_l_10360e4:;
	/* 0x10360e4: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10360e8:;
	/* 0x10360e8: b 10360f4 <outer_done_54> */
	ARM64_SIM_A64_JMP(0x10360e8, 0x10360f4, arm64_l_10360f4);
arm64_l_10360ec:;
	/* 0x10360ec: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10360f0:;
	/* 0x10360f0: b 10360f4 <outer_done_54> */
	ARM64_SIM_A64_JMP(0x10360f0, 0x10360f4, arm64_l_10360f4);
arm64_l_10360f4:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_55(struct state *);
extern unsigned char native_pc_55,native_next_55;
static void sim_55(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10370e0:;
	/* 0x10370e0: b 10370ec <native_pc_55+0xc> */
	ARM64_SIM_A64_JMP(0x10370e0, 0x10370ec, arm64_l_10370ec);
arm64_l_10370e4:;
	/* 0x10370e4: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10370e8:;
	/* 0x10370e8: b 10370f8 <outer_done_55> */
	ARM64_SIM_A64_JMP(0x10370e8, 0x10370f8, arm64_l_10370f8);
arm64_l_10370ec:;
	/* 0x10370ec: tbz x1, #63, 10370e4 <native_pc_55+0x4> */
	ARM64_SIM_A64_TBZ(ARM64_X1, 63, 0x10370ec, 0x10370e4, arm64_l_10370e4);
arm64_l_10370f0:;
	/* 0x10370f0: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10370f4:;
	/* 0x10370f4: b 10370f8 <outer_done_55> */
	ARM64_SIM_A64_JMP(0x10370f4, 0x10370f8, arm64_l_10370f8);
arm64_l_10370f8:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_56(struct state *);
extern unsigned char native_pc_56,native_next_56;
static void sim_56(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10380e0:;
	/* 0x10380e0: tbnz w1, #0, 10380ec <native_pc_56+0xc> */
	ARM64_SIM_A64_TBNZ(ARM64_X1, 0, 0x10380e0, 0x10380ec, arm64_l_10380ec);
arm64_l_10380e4:;
	/* 0x10380e4: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10380e8:;
	/* 0x10380e8: b 10380f4 <outer_done_56> */
	ARM64_SIM_A64_JMP(0x10380e8, 0x10380f4, arm64_l_10380f4);
arm64_l_10380ec:;
	/* 0x10380ec: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10380f0:;
	/* 0x10380f0: b 10380f4 <outer_done_56> */
	ARM64_SIM_A64_JMP(0x10380f0, 0x10380f4, arm64_l_10380f4);
arm64_l_10380f4:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_57(struct state *);
extern unsigned char native_pc_57,native_next_57;
static void sim_57(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10390e0:;
	/* 0x10390e0: b 10390ec <native_pc_57+0xc> */
	ARM64_SIM_A64_JMP(0x10390e0, 0x10390ec, arm64_l_10390ec);
arm64_l_10390e4:;
	/* 0x10390e4: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10390e8:;
	/* 0x10390e8: b 10390f8 <outer_done_57> */
	ARM64_SIM_A64_JMP(0x10390e8, 0x10390f8, arm64_l_10390f8);
arm64_l_10390ec:;
	/* 0x10390ec: tbnz w1, #0, 10390e4 <native_pc_57+0x4> */
	ARM64_SIM_A64_TBNZ(ARM64_X1, 0, 0x10390ec, 0x10390e4, arm64_l_10390e4);
arm64_l_10390f0:;
	/* 0x10390f0: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10390f4:;
	/* 0x10390f4: b 10390f8 <outer_done_57> */
	ARM64_SIM_A64_JMP(0x10390f4, 0x10390f8, arm64_l_10390f8);
arm64_l_10390f8:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_58(struct state *);
extern unsigned char native_pc_58,native_next_58;
static void sim_58(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_103a0e0:;
	/* 0x103a0e0: tbnz w1, #7, 103a0ec <native_pc_58+0xc> */
	ARM64_SIM_A64_TBNZ(ARM64_X1, 7, 0x103a0e0, 0x103a0ec, arm64_l_103a0ec);
arm64_l_103a0e4:;
	/* 0x103a0e4: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_103a0e8:;
	/* 0x103a0e8: b 103a0f4 <outer_done_58> */
	ARM64_SIM_A64_JMP(0x103a0e8, 0x103a0f4, arm64_l_103a0f4);
arm64_l_103a0ec:;
	/* 0x103a0ec: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_103a0f0:;
	/* 0x103a0f0: b 103a0f4 <outer_done_58> */
	ARM64_SIM_A64_JMP(0x103a0f0, 0x103a0f4, arm64_l_103a0f4);
arm64_l_103a0f4:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_59(struct state *);
extern unsigned char native_pc_59,native_next_59;
static void sim_59(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_103b0e0:;
	/* 0x103b0e0: b 103b0ec <native_pc_59+0xc> */
	ARM64_SIM_A64_JMP(0x103b0e0, 0x103b0ec, arm64_l_103b0ec);
arm64_l_103b0e4:;
	/* 0x103b0e4: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_103b0e8:;
	/* 0x103b0e8: b 103b0f8 <outer_done_59> */
	ARM64_SIM_A64_JMP(0x103b0e8, 0x103b0f8, arm64_l_103b0f8);
arm64_l_103b0ec:;
	/* 0x103b0ec: tbnz w1, #7, 103b0e4 <native_pc_59+0x4> */
	ARM64_SIM_A64_TBNZ(ARM64_X1, 7, 0x103b0ec, 0x103b0e4, arm64_l_103b0e4);
arm64_l_103b0f0:;
	/* 0x103b0f0: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_103b0f4:;
	/* 0x103b0f4: b 103b0f8 <outer_done_59> */
	ARM64_SIM_A64_JMP(0x103b0f4, 0x103b0f8, arm64_l_103b0f8);
arm64_l_103b0f8:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_60(struct state *);
extern unsigned char native_pc_60,native_next_60;
static void sim_60(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_103c0e0:;
	/* 0x103c0e0: tbnz w1, #31, 103c0ec <native_pc_60+0xc> */
	ARM64_SIM_A64_TBNZ(ARM64_X1, 31, 0x103c0e0, 0x103c0ec, arm64_l_103c0ec);
arm64_l_103c0e4:;
	/* 0x103c0e4: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_103c0e8:;
	/* 0x103c0e8: b 103c0f4 <outer_done_60> */
	ARM64_SIM_A64_JMP(0x103c0e8, 0x103c0f4, arm64_l_103c0f4);
arm64_l_103c0ec:;
	/* 0x103c0ec: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_103c0f0:;
	/* 0x103c0f0: b 103c0f4 <outer_done_60> */
	ARM64_SIM_A64_JMP(0x103c0f0, 0x103c0f4, arm64_l_103c0f4);
arm64_l_103c0f4:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_61(struct state *);
extern unsigned char native_pc_61,native_next_61;
static void sim_61(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_103d0e0:;
	/* 0x103d0e0: b 103d0ec <native_pc_61+0xc> */
	ARM64_SIM_A64_JMP(0x103d0e0, 0x103d0ec, arm64_l_103d0ec);
arm64_l_103d0e4:;
	/* 0x103d0e4: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_103d0e8:;
	/* 0x103d0e8: b 103d0f8 <outer_done_61> */
	ARM64_SIM_A64_JMP(0x103d0e8, 0x103d0f8, arm64_l_103d0f8);
arm64_l_103d0ec:;
	/* 0x103d0ec: tbnz w1, #31, 103d0e4 <native_pc_61+0x4> */
	ARM64_SIM_A64_TBNZ(ARM64_X1, 31, 0x103d0ec, 0x103d0e4, arm64_l_103d0e4);
arm64_l_103d0f0:;
	/* 0x103d0f0: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_103d0f4:;
	/* 0x103d0f4: b 103d0f8 <outer_done_61> */
	ARM64_SIM_A64_JMP(0x103d0f4, 0x103d0f8, arm64_l_103d0f8);
arm64_l_103d0f8:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_62(struct state *);
extern unsigned char native_pc_62,native_next_62;
static void sim_62(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_103e0e0:;
	/* 0x103e0e0: tbnz x1, #63, 103e0ec <native_pc_62+0xc> */
	ARM64_SIM_A64_TBNZ(ARM64_X1, 63, 0x103e0e0, 0x103e0ec, arm64_l_103e0ec);
arm64_l_103e0e4:;
	/* 0x103e0e4: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_103e0e8:;
	/* 0x103e0e8: b 103e0f4 <outer_done_62> */
	ARM64_SIM_A64_JMP(0x103e0e8, 0x103e0f4, arm64_l_103e0f4);
arm64_l_103e0ec:;
	/* 0x103e0ec: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_103e0f0:;
	/* 0x103e0f0: b 103e0f4 <outer_done_62> */
	ARM64_SIM_A64_JMP(0x103e0f0, 0x103e0f4, arm64_l_103e0f4);
arm64_l_103e0f4:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_63(struct state *);
extern unsigned char native_pc_63,native_next_63;
static void sim_63(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_103f0e0:;
	/* 0x103f0e0: b 103f0ec <native_pc_63+0xc> */
	ARM64_SIM_A64_JMP(0x103f0e0, 0x103f0ec, arm64_l_103f0ec);
arm64_l_103f0e4:;
	/* 0x103f0e4: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_103f0e8:;
	/* 0x103f0e8: b 103f0f8 <outer_done_63> */
	ARM64_SIM_A64_JMP(0x103f0e8, 0x103f0f8, arm64_l_103f0f8);
arm64_l_103f0ec:;
	/* 0x103f0ec: tbnz x1, #63, 103f0e4 <native_pc_63+0x4> */
	ARM64_SIM_A64_TBNZ(ARM64_X1, 63, 0x103f0ec, 0x103f0e4, arm64_l_103f0e4);
arm64_l_103f0f0:;
	/* 0x103f0f0: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_103f0f4:;
	/* 0x103f0f4: b 103f0f8 <outer_done_63> */
	ARM64_SIM_A64_JMP(0x103f0f4, 0x103f0f8, arm64_l_103f0f8);
arm64_l_103f0f8:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_64(struct state *);
extern unsigned char native_pc_64,native_next_64;
static void sim_64(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10400e0:;
arm64_l_10400e4:;
ARM64_SIM_A64_CMP_GT(ARM64_OP_CMP_REG, ARM64_X1, ARM64_X2, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0, arm64_l_10400f0);
arm64_l_10400e8:;
	/* 0x10400e8: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10400ec:;
	/* 0x10400ec: b 10400f8 <outer_done_64> */
	ARM64_SIM_A64_JMP(0x10400ec, 0x10400f8, arm64_l_10400f8);
arm64_l_10400f0:;
	/* 0x10400f0: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10400f4:;
	/* 0x10400f4: b 10400f8 <outer_done_64> */
	ARM64_SIM_A64_JMP(0x10400f4, 0x10400f8, arm64_l_10400f8);
arm64_l_10400f8:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_65(struct state *);
extern unsigned char native_pc_65,native_next_65;
static void sim_65(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10410e0:;
arm64_l_10410e4:;
ARM64_SIM_A64_CMP_GT(ARM64_OP_CMP_REG, ARM64_X1, ARM64_X2, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0, arm64_l_10410f0);
arm64_l_10410e8:;
	/* 0x10410e8: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10410ec:;
	/* 0x10410ec: b 10410f8 <outer_done_65> */
	ARM64_SIM_A64_JMP(0x10410ec, 0x10410f8, arm64_l_10410f8);
arm64_l_10410f0:;
	/* 0x10410f0: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10410f4:;
	/* 0x10410f4: b 10410f8 <outer_done_65> */
	ARM64_SIM_A64_JMP(0x10410f4, 0x10410f8, arm64_l_10410f8);
arm64_l_10410f8:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_66(struct state *);
extern unsigned char native_pc_66,native_next_66;
static void sim_66(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10420e0:;
	/* 0x10420e0: tbz w1, #0, 10420ec <native_pc_66+0xc> */
	ARM64_SIM_A64_TBZ(ARM64_X1, 0, 0x10420e0, 0x10420ec, arm64_l_10420ec);
arm64_l_10420e4:;
	/* 0x10420e4: adr x10, 10420f4 <native_pc_66+0x14> */
	ARM64_SIM_A64_ADR(ARM64_X10, 0x10420f4ULL);
arm64_l_10420e8:;
	/* 0x10420e8: b 10420f0 <native_pc_66+0x10> */
	ARM64_SIM_A64_JMP(0x10420e8, 0x10420f0, arm64_l_10420f0);
arm64_l_10420ec:;
	/* 0x10420ec: adr x10, 10420fc <native_pc_66+0x1c> */
	ARM64_SIM_A64_ADR(ARM64_X10, 0x10420fcULL);
arm64_l_10420f0:;
	/* 0x10420f0: br x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			case 0x10420f4ULL: goto arm64_l_10420f4; break;
			case 0x10420fcULL: goto arm64_l_10420fc; break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_10420f4:;
	/* 0x10420f4: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10420f8:;
	/* 0x10420f8: b 1042104 <outer_done_66> */
	ARM64_SIM_A64_JMP(0x10420f8, 0x1042104, arm64_l_1042104);
arm64_l_10420fc:;
	/* 0x10420fc: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1042100:;
	/* 0x1042100: b 1042104 <outer_done_66> */
	ARM64_SIM_A64_JMP(0x1042100, 0x1042104, arm64_l_1042104);
arm64_l_1042104:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_67(struct state *);
extern unsigned char native_pc_67,native_next_67;
static void sim_67(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10430e0:;
	/* 0x10430e0: bl 10430e8 <native_pc_67+0x8> */
	ARM64_SIM_A64_CALL(arm64_l_10430e8, 0x10430e4ULL);
arm64_l_10430e4:;
	/* 0x10430e4: b 10430f0 <outer_done_67> */
	ARM64_SIM_A64_JMP(0x10430e4, 0x10430f0, arm64_l_10430f0);
arm64_l_10430e8:;
	/* 0x10430e8: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10430ec:;
	/* 0x10430ec: ret */
	ARM64_SIM_A64_RET_TO(ARM64_X30, ARM64_SIM_RET_CASES_10430ec);
arm64_l_10430f0:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_68(struct state *);
extern unsigned char native_pc_68,native_next_68;
static void sim_68(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10440e0:;
	/* 0x10440e0: bl 10440e8 <native_pc_68+0x8> */
	ARM64_SIM_A64_CALL(arm64_l_10440e8, 0x10440e4ULL);
arm64_l_10440e4:;
	/* 0x10440e4: b 10440f4 <outer_done_68> */
	ARM64_SIM_A64_JMP(0x10440e4, 0x10440f4, arm64_l_10440f4);
arm64_l_10440e8:;
	/* 0x10440e8: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10440ec:;
	/* 0x10440ec: mov x17, x30 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X17, ARM64_X30, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_10440f0:;
	/* 0x10440f0: ret x17 */
	ARM64_SIM_A64_RET_TO(ARM64_X17, ARM64_SIM_RET_CASES_10440f0);
arm64_l_10440f4:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_69(struct state *);
extern unsigned char native_pc_69,native_next_69;
static void sim_69(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10450e0:;
	/* 0x10450e0: adr x10, 10450ec <native_pc_69+0xc> */
	ARM64_SIM_A64_ADR(ARM64_X10, 0x10450ecULL);
arm64_l_10450e4:;
	/* 0x10450e4: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			case 0x10450ecULL: ARM64_SIM_A64_CALL(arm64_l_10450ec, 0x10450e8ULL); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_10450e8:;
	/* 0x10450e8: b 10450f4 <outer_done_69> */
	ARM64_SIM_A64_JMP(0x10450e8, 0x10450f4, arm64_l_10450f4);
arm64_l_10450ec:;
	/* 0x10450ec: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10450f0:;
	/* 0x10450f0: ret */
	ARM64_SIM_A64_RET_TO(ARM64_X30, ARM64_SIM_RET_CASES_10450f0);
arm64_l_10450f4:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_70(struct state *);
extern unsigned char native_pc_70,native_next_70;
static void sim_70(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10460e0:;
	/* 0x10460e0: bl 10460e8 <native_pc_70+0x8> */
	ARM64_SIM_A64_CALL(arm64_l_10460e8, 0x10460e4ULL);
arm64_l_10460e4:;
	/* 0x10460e4: b 1046100 <outer_done_70> */
	ARM64_SIM_A64_JMP(0x10460e4, 0x1046100, arm64_l_1046100);
arm64_l_10460e8:;
	/* 0x10460e8: stp x19, x30, [sp, #-16]! */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X19, ARM64_X30, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 18446744073709551600ULL);
arm64_l_10460ec:;
	/* 0x10460ec: bl 10460f8 <native_pc_70+0x18> */
	ARM64_SIM_A64_CALL(arm64_l_10460f8, 0x10460f0ULL);
arm64_l_10460f0:;
	/* 0x10460f0: ldp x19, x30, [sp], #16 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X19, ARM64_X30, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 16ULL);
arm64_l_10460f4:;
	/* 0x10460f4: ret */
	ARM64_SIM_A64_RET_TO(ARM64_X30, ARM64_SIM_RET_CASES_10460f4);
arm64_l_10460f8:;
	/* 0x10460f8: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10460fc:;
	/* 0x10460fc: ret */
	ARM64_SIM_A64_RET_TO(ARM64_X30, ARM64_SIM_RET_CASES_10460fc);
arm64_l_1046100:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_71(struct state *);
extern unsigned char native_pc_71,native_next_71;
static void sim_71(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10470e0:;
	/* 0x10470e0: bl 10470e8 <native_pc_71+0x8> */
	ARM64_SIM_A64_CALL(arm64_l_10470e8, 0x10470e4ULL);
arm64_l_10470e4:;
	/* 0x10470e4: b 1047104 <outer_done_71> */
	ARM64_SIM_A64_JMP(0x10470e4, 0x1047104, arm64_l_1047104);
arm64_l_10470e8:;
	/* 0x10470e8: str x30, [sp, #-16]! */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X30, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 18446744073709551600ULL);
arm64_l_10470ec:;
	/* 0x10470ec: adr x10, 10470fc <native_pc_71+0x1c> */
	ARM64_SIM_A64_ADR(ARM64_X10, 0x10470fcULL);
arm64_l_10470f0:;
	/* 0x10470f0: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			case 0x10470fcULL: ARM64_SIM_A64_CALL(arm64_l_10470fc, 0x10470f4ULL); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_10470f4:;
	/* 0x10470f4: ldr x30, [sp], #16 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X30, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 16ULL);
arm64_l_10470f8:;
	/* 0x10470f8: ret */
	ARM64_SIM_A64_RET_TO(ARM64_X30, ARM64_SIM_RET_CASES_10470f8);
arm64_l_10470fc:;
	/* 0x10470fc: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_1047100:;
	/* 0x1047100: ret */
	ARM64_SIM_A64_RET_TO(ARM64_X30, ARM64_SIM_RET_CASES_1047100);
arm64_l_1047104:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_72(struct state *);
extern unsigned char native_pc_72,native_next_72;
static void sim_72(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10480e0:;
	/* 0x10480e0: stp x1, x2, [sp, #-16]! */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X1, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 18446744073709551600ULL);
arm64_l_10480e4:;
	/* 0x10480e4: ldp x0, x3, [sp], #16 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LDP, ARM64_X0, ARM64_X3, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 16ULL);
arm64_l_10480e8:;
	/* 0x10480e8: b 10480ec <outer_done_72> */
	ARM64_SIM_A64_JMP(0x10480e8, 0x10480ec, arm64_l_10480ec);
arm64_l_10480ec:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_73(struct state *);
extern unsigned char native_pc_73,native_next_73;
static void sim_73(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10490e0:;
	/* 0x10490e0: str x1, [sp, #-16]! */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 18446744073709551600ULL);
arm64_l_10490e4:;
	/* 0x10490e4: ldr x0, [sp], #16 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 16ULL);
arm64_l_10490e8:;
	/* 0x10490e8: b 10490ec <outer_done_73> */
	ARM64_SIM_A64_JMP(0x10490e8, 0x10490ec, arm64_l_10490ec);
arm64_l_10490ec:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_74(struct state *);
extern unsigned char native_pc_74,native_next_74;
static void sim_74(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_104a0e0:;
	/* 0x104a0e0: sub sp, sp, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_104a0e4:;
	/* 0x104a0e4: mov x0, sp */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_104a0e8:;
	/* 0x104a0e8: add x0, x0, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_X0, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_104a0ec:;
	/* 0x104a0ec: mov sp, x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_REG, ARM64_SP, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_104a0f0:;
	/* 0x104a0f0: mov x0, #0x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 37ULL);
arm64_l_104a0f4:;
	/* 0x104a0f4: b 104a0f8 <outer_done_74> */
	ARM64_SIM_A64_JMP(0x104a0f4, 0x104a0f8, arm64_l_104a0f8);
arm64_l_104a0f8:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_75(struct state *);
extern unsigned char native_pc_75,native_next_75;
static void sim_75(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_104b0e0:;
	/* 0x104b0e0: sub sp, sp, #0x10 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_IMM, ARM64_SP, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_SUB, ARM64_MOD_NONE, 0), 16ULL);
arm64_l_104b0e4:;
	/* 0x104b0e4: mov x0, #0x25 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_MOV_IMM, ARM64_X0, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 37ULL);
arm64_l_104b0e8:;
	/* 0x104b0e8: b 104b0ec <outer_done_75> */
	ARM64_SIM_A64_JMP(0x104b0e8, 0x104b0ec, arm64_l_104b0ec);
arm64_l_104b0ec:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
extern void native_76(struct state *);
extern unsigned char native_pc_76,native_next_76;
static void sim_76(struct state *s) {
ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BIAS-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_104c0e0:;
	/* 0x104c0e0: cmp sp, #0x0 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_CMP_IMM, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0ULL);
arm64_l_104c0e4:;
	/* 0x104c0e4: b.eq 104c0f0 <native_pc_76+0x10> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x104c0e4, 0x104c0f0, arm64_l_104c0f0);
arm64_l_104c0e8:;
	/* 0x104c0e8: add x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_104c0ec:;
	/* 0x104c0ec: b 104c0f8 <outer_done_76> */
	ARM64_SIM_A64_JMP(0x104c0ec, 0x104c0f8, arm64_l_104c0f8);
arm64_l_104c0f0:;
	/* 0x104c0f0: eor x0, x0, x2 */
	ARM64_SIM_RUN_KNOWN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_104c0f4:;
	/* 0x104c0f4: b 104c0f8 <outer_done_76> */
	ARM64_SIM_A64_JMP(0x104c0f4, 0x104c0f8, arm64_l_104c0f8);
arm64_l_104c0f8:;
goto observed;
goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BIAS-64+k];
}
const struct form forms[]={
{"b.eq forward","ARM64_CONTROL",native_0,sim_0,0xf0000000U,64,0,6,&native_pc_0,&native_next_0},
{"b.eq backward","ARM64_CONTROL",native_1,sim_1,0xf0000000U,64,0,6,&native_pc_1,&native_next_1},
{"b.ne forward","ARM64_CONTROL",native_2,sim_2,0xf0000000U,64,0,6,&native_pc_2,&native_next_2},
{"b.ne backward","ARM64_CONTROL",native_3,sim_3,0xf0000000U,64,0,6,&native_pc_3,&native_next_3},
{"b.cs forward","ARM64_CONTROL",native_4,sim_4,0xf0000000U,64,0,6,&native_pc_4,&native_next_4},
{"b.cs backward","ARM64_CONTROL",native_5,sim_5,0xf0000000U,64,0,6,&native_pc_5,&native_next_5},
{"b.cc forward","ARM64_CONTROL",native_6,sim_6,0xf0000000U,64,0,6,&native_pc_6,&native_next_6},
{"b.cc backward","ARM64_CONTROL",native_7,sim_7,0xf0000000U,64,0,6,&native_pc_7,&native_next_7},
{"b.mi forward","ARM64_CONTROL",native_8,sim_8,0xf0000000U,64,0,6,&native_pc_8,&native_next_8},
{"b.mi backward","ARM64_CONTROL",native_9,sim_9,0xf0000000U,64,0,6,&native_pc_9,&native_next_9},
{"b.pl forward","ARM64_CONTROL",native_10,sim_10,0xf0000000U,64,0,6,&native_pc_10,&native_next_10},
{"b.pl backward","ARM64_CONTROL",native_11,sim_11,0xf0000000U,64,0,6,&native_pc_11,&native_next_11},
{"b.vs forward","ARM64_CONTROL",native_12,sim_12,0xf0000000U,64,0,6,&native_pc_12,&native_next_12},
{"b.vs backward","ARM64_CONTROL",native_13,sim_13,0xf0000000U,64,0,6,&native_pc_13,&native_next_13},
{"b.vc forward","ARM64_CONTROL",native_14,sim_14,0xf0000000U,64,0,6,&native_pc_14,&native_next_14},
{"b.vc backward","ARM64_CONTROL",native_15,sim_15,0xf0000000U,64,0,6,&native_pc_15,&native_next_15},
{"b.hi forward","ARM64_CONTROL",native_16,sim_16,0xf0000000U,64,0,6,&native_pc_16,&native_next_16},
{"b.hi backward","ARM64_CONTROL",native_17,sim_17,0xf0000000U,64,0,6,&native_pc_17,&native_next_17},
{"b.ls forward","ARM64_CONTROL",native_18,sim_18,0xf0000000U,64,0,6,&native_pc_18,&native_next_18},
{"b.ls backward","ARM64_CONTROL",native_19,sim_19,0xf0000000U,64,0,6,&native_pc_19,&native_next_19},
{"b.ge forward","ARM64_CONTROL",native_20,sim_20,0xf0000000U,64,0,6,&native_pc_20,&native_next_20},
{"b.ge backward","ARM64_CONTROL",native_21,sim_21,0xf0000000U,64,0,6,&native_pc_21,&native_next_21},
{"b.lt forward","ARM64_CONTROL",native_22,sim_22,0xf0000000U,64,0,6,&native_pc_22,&native_next_22},
{"b.lt backward","ARM64_CONTROL",native_23,sim_23,0xf0000000U,64,0,6,&native_pc_23,&native_next_23},
{"b.gt forward","ARM64_CONTROL",native_24,sim_24,0xf0000000U,64,0,6,&native_pc_24,&native_next_24},
{"b.gt backward","ARM64_CONTROL",native_25,sim_25,0xf0000000U,64,0,6,&native_pc_25,&native_next_25},
{"b.le forward","ARM64_CONTROL",native_26,sim_26,0xf0000000U,64,0,6,&native_pc_26,&native_next_26},
{"b.le backward","ARM64_CONTROL",native_27,sim_27,0xf0000000U,64,0,6,&native_pc_27,&native_next_27},
{"cbz w1 False","ARM64_CONTROL",native_28,sim_28,0xf0000000U,64,0,6,&native_pc_28,&native_next_28},
{"cbz w1 True","ARM64_CONTROL",native_29,sim_29,0xf0000000U,64,0,6,&native_pc_29,&native_next_29},
{"cbnz w1 False","ARM64_CONTROL",native_30,sim_30,0xf0000000U,64,0,6,&native_pc_30,&native_next_30},
{"cbnz w1 True","ARM64_CONTROL",native_31,sim_31,0xf0000000U,64,0,6,&native_pc_31,&native_next_31},
{"tbz w1 #0 False","ARM64_CONTROL",native_32,sim_32,0xf0000000U,64,0,6,&native_pc_32,&native_next_32},
{"tbz w1 #0 True","ARM64_CONTROL",native_33,sim_33,0xf0000000U,64,0,6,&native_pc_33,&native_next_33},
{"tbz w1 #7 False","ARM64_CONTROL",native_34,sim_34,0xf0000000U,64,0,6,&native_pc_34,&native_next_34},
{"tbz w1 #7 True","ARM64_CONTROL",native_35,sim_35,0xf0000000U,64,0,6,&native_pc_35,&native_next_35},
{"tbz w1 #31 False","ARM64_CONTROL",native_36,sim_36,0xf0000000U,64,0,6,&native_pc_36,&native_next_36},
{"tbz w1 #31 True","ARM64_CONTROL",native_37,sim_37,0xf0000000U,64,0,6,&native_pc_37,&native_next_37},
{"tbnz w1 #0 False","ARM64_CONTROL",native_38,sim_38,0xf0000000U,64,0,6,&native_pc_38,&native_next_38},
{"tbnz w1 #0 True","ARM64_CONTROL",native_39,sim_39,0xf0000000U,64,0,6,&native_pc_39,&native_next_39},
{"tbnz w1 #7 False","ARM64_CONTROL",native_40,sim_40,0xf0000000U,64,0,6,&native_pc_40,&native_next_40},
{"tbnz w1 #7 True","ARM64_CONTROL",native_41,sim_41,0xf0000000U,64,0,6,&native_pc_41,&native_next_41},
{"tbnz w1 #31 False","ARM64_CONTROL",native_42,sim_42,0xf0000000U,64,0,6,&native_pc_42,&native_next_42},
{"tbnz w1 #31 True","ARM64_CONTROL",native_43,sim_43,0xf0000000U,64,0,6,&native_pc_43,&native_next_43},
{"cbz x1 False","ARM64_CONTROL",native_44,sim_44,0xf0000000U,64,0,6,&native_pc_44,&native_next_44},
{"cbz x1 True","ARM64_CONTROL",native_45,sim_45,0xf0000000U,64,0,6,&native_pc_45,&native_next_45},
{"cbnz x1 False","ARM64_CONTROL",native_46,sim_46,0xf0000000U,64,0,6,&native_pc_46,&native_next_46},
{"cbnz x1 True","ARM64_CONTROL",native_47,sim_47,0xf0000000U,64,0,6,&native_pc_47,&native_next_47},
{"tbz x1 #0 False","ARM64_CONTROL",native_48,sim_48,0xf0000000U,64,0,6,&native_pc_48,&native_next_48},
{"tbz x1 #0 True","ARM64_CONTROL",native_49,sim_49,0xf0000000U,64,0,6,&native_pc_49,&native_next_49},
{"tbz x1 #7 False","ARM64_CONTROL",native_50,sim_50,0xf0000000U,64,0,6,&native_pc_50,&native_next_50},
{"tbz x1 #7 True","ARM64_CONTROL",native_51,sim_51,0xf0000000U,64,0,6,&native_pc_51,&native_next_51},
{"tbz x1 #31 False","ARM64_CONTROL",native_52,sim_52,0xf0000000U,64,0,6,&native_pc_52,&native_next_52},
{"tbz x1 #31 True","ARM64_CONTROL",native_53,sim_53,0xf0000000U,64,0,6,&native_pc_53,&native_next_53},
{"tbz x1 #63 False","ARM64_CONTROL",native_54,sim_54,0xf0000000U,64,0,6,&native_pc_54,&native_next_54},
{"tbz x1 #63 True","ARM64_CONTROL",native_55,sim_55,0xf0000000U,64,0,6,&native_pc_55,&native_next_55},
{"tbnz x1 #0 False","ARM64_CONTROL",native_56,sim_56,0xf0000000U,64,0,6,&native_pc_56,&native_next_56},
{"tbnz x1 #0 True","ARM64_CONTROL",native_57,sim_57,0xf0000000U,64,0,6,&native_pc_57,&native_next_57},
{"tbnz x1 #7 False","ARM64_CONTROL",native_58,sim_58,0xf0000000U,64,0,6,&native_pc_58,&native_next_58},
{"tbnz x1 #7 True","ARM64_CONTROL",native_59,sim_59,0xf0000000U,64,0,6,&native_pc_59,&native_next_59},
{"tbnz x1 #31 False","ARM64_CONTROL",native_60,sim_60,0xf0000000U,64,0,6,&native_pc_60,&native_next_60},
{"tbnz x1 #31 True","ARM64_CONTROL",native_61,sim_61,0xf0000000U,64,0,6,&native_pc_61,&native_next_61},
{"tbnz x1 #63 False","ARM64_CONTROL",native_62,sim_62,0xf0000000U,64,0,6,&native_pc_62,&native_next_62},
{"tbnz x1 #63 True","ARM64_CONTROL",native_63,sim_63,0xf0000000U,64,0,6,&native_pc_63,&native_next_63},
{"cmp w1,w2 / b.gt","ARM64_CONTROL",native_64,sim_64,0xf0000000U,64,0,6,&native_pc_64,&native_next_64},
{"cmp x1,x2 / b.gt","ARM64_CONTROL",native_65,sim_65,0xf0000000U,64,0,6,&native_pc_65,&native_next_65},
{"BR finite code choice","ARM64_CONTROL",native_66,sim_66,0xf0000000U,64,0,6,&native_pc_66,&native_next_66},
{"BL / RET x30","ARM64_CONTROL",native_67,sim_67,0xf0000000U,64,0,6,&native_pc_67,&native_next_67},
{"BL / RET x17","ARM64_CONTROL",native_68,sim_68,0xf0000000U,64,0,6,&native_pc_68,&native_next_68},
{"BLR code / RET","ARM64_CONTROL",native_69,sim_69,0xf0000000U,64,0,6,&native_pc_69,&native_next_69},
{"nested BL saved LR stack","ARM64_CONTROL",native_70,sim_70,0xf0000000U,64,0,6,&native_pc_70,&native_next_70},
{"BLR saved LR stack","ARM64_CONTROL",native_71,sim_71,0xf0000000U,64,0,6,&native_pc_71,&native_next_71},
{"stack pair pre/post","ARM64_CONTROL",native_72,sim_72,0xf0000000U,64,0,6,&native_pc_72,&native_next_72},
{"stack scalar pre/post","ARM64_CONTROL",native_73,sim_73,0xf0000000U,64,0,6,&native_pc_73,&native_next_73},
{"MOV SP register round-trip","ARM64_CONTROL",native_74,sim_74,0xf0000000U,64,0,6,&native_pc_74,&native_next_74},
{"SP observation offset","ARM64_CONTROL",native_75,sim_75,0xf0000000U,64,0,6,&native_pc_75,&native_next_75},
{"SP compare flags","ARM64_CONTROL",native_76,sim_76,0xf0000000U,64,0,6,&native_pc_76,&native_next_76}
};
const unsigned form_count=sizeof(forms)/sizeof(forms[0]);
