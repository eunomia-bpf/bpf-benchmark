.PHONY: build
build:
	lake build reference

.PHONY: wire axioms
wire:
	python3 tools/check_reference_x86_path.py
axioms:
	lake env lean PrintPath.lean

.PHONY: memory-wire
memory-wire:
	python3 tools/check_reference_arm64_addressed_memory.py
	python3 tools/check_reference_arm64.py
	python3 tools/check_reference_exclusive.py

.PHONY: memory-model
memory-model:
	lake build KProgFormal.Refinement.Arm64AddressedMemory KProgFormal.Refinement.Arm64VectorMemory reference
