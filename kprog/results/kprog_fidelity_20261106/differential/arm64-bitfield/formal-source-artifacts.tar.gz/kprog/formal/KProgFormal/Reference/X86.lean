import KProgFormal.Reference.Memory

/-!
The x86-64 reference semantics. Architectural rules come from Intel SDM
Volume 2, instruction Operation/Flags Affected descriptions:
https://cdrdv2-public.intel.com/874240/325462-090-sdm-vol-1-2abcd-3abcd-4.pdf
No simulator or generated-contract module is imported here.
-/
namespace KProgFormal.Reference.X86

abbrev Register := Fin 16

/-- CMOV has no 8-bit encoding. Width is architectural operand size, not the
simulator's byte-count code or its absent-width sentinel. -/
inductive CmovWidth
  | w16 | w32 | w64
  deriving DecidableEq, Repr

def CmovWidth.bytes : CmovWidth → Nat
  | .w16 => 2
  | .w32 => 4
  | .w64 => 8

/-- Long-mode stack transfers have 16- or 64-bit operands; 32-bit stack
operands cannot be encoded. An active REX.W overrides the operand-size prefix. -/
inductive StackWidth
  | w16 | w64
  deriving DecidableEq, Repr

def StackWidth.bytes : StackWidth → Nat | .w16 => 2 | .w64 => 8

def StackWidth.registerWidth : StackWidth → CmovWidth
  | .w16 => .w16 | .w64 => .w64

structure State where
  gpr : Register → Word
  rflags : Word
  xmm0 : BitVec 128
  memory : Memory
  pc : Word
  fsBase : Word
  gsBase : Word

/-- All sixteen architectural condition codes, including parity. -/
def condition (flags : Word) (code : Fin 16) : Bool :=
  let cf := flags.getLsbD 0
  let pf := flags.getLsbD 2
  let zf := flags.getLsbD 6
  let sf := flags.getLsbD 7
  let of := flags.getLsbD 11
  match code.val with
  | 0 => of
  | 1 => !of
  | 2 => cf
  | 3 => !cf
  | 4 => zf
  | 5 => !zf
  | 6 => cf || zf
  | 7 => !cf && !zf
  | 8 => sf
  | 9 => !sf
  | 10 => pf
  | 11 => !pf
  | 12 => sf != of
  | 13 => sf == of
  | 14 => zf || (sf != of)
  | _ => !zf && (sf == of)

/-- The operand is read before the destination is changed, including aliasing
registers and a memory source addressed by the destination register. -/
inductive Source
  | register (reg : Register)
  | memory (address : Word)
  deriving DecidableEq, Repr

def readSource (s : State) (source : Source) (bytes : Nat) :
    Except Fault (Word × List Event) :=
  match source with
  | .register r => .ok (s.gpr r, [])
  | .memory address =>
      match readMemory s.memory address bytes with
      | .error fault => .error fault
      | .ok (value, event) => .ok (value, [event])

/-- Intel CMOVcc Operation: 32-bit writes zero-extend even when the condition
is false. The 16-bit untaken case preserves every destination bit. -/
def cmovValue (width : CmovWidth) (taken : Bool) (old source : Word) : Word :=
  match width with
  | .w16 => if taken then (old &&& 0xffffffffffff0000) ||| (source &&& 0xffff)
      else old
  | .w32 => (if taken then source else old) &&& 0xffffffff
  | .w64 => if taken then source else old

/-- Bit selection wraps modulo the operand size. The instruction layer only
supplies architectural widths; the generalized primitive also covers byte lanes. -/
def bitTest (base index : Word) (operandBits : Nat) : Bool :=
  (base &&& ((1 : Word) <<< (index &&& (BitVec.ofNat 64 operandBits - 1)))) != 0

def setFlag (flags : Word) (bit : Nat) (value : Bool) : Word :=
  let mask := (1 : Word) <<< bit
  if value then flags ||| mask else flags &&& ~~~mask

/-- BMI2 zero-high-bits takes an unsigned byte index. This generalized
primitive also serves narrower implementation contracts. -/
def zeroHighBits (source count : Word) (operandBits : Nat) : Word :=
  let index := count &&& 0xff
  let mask := BitVec.ofNat 64 (2 ^ operandBits) - 1
  let kept := if BitVec.ult index (BitVec.ofNat 64 operandBits)
    then ((1 : Word) <<< index) - 1 else mask
  source &&& kept &&& mask

def bzhiCarry (normalizedCount : Word) (operandBits : Nat) : Bool :=
  BitVec.ule (BitVec.ofNat 64 operandBits) normalizedCount

def resultZero (result : Word) : Bool := result == 0

def resultSign (result : Word) (operandBits : Nat) : Bool :=
  result.getLsbD (operandBits - 1)

/-- ZF/SF follow the result; CF reports an index at least the operand size,
OF is cleared. AF/PF are undefined and are handled by the step relation. -/
def bzhiFlags (flags normalizedCount result : Word) (operandBits : Nat) : Word :=
  setFlag (setFlag (setFlag (setFlag flags 0 (bzhiCarry normalizedCount operandBits))
    6 (resultZero result)) 7 (resultSign result operandBits)) 11 false

/-- BMI1 ANDN inverts its first source, not the memory/register second source. -/
def andNot (first second : Word) : Word := ~~~first &&& second

/-- CF/OF are zero and ZF/SF follow the operand-sized result. AF/PF are
undefined, represented by preservation and unconstrained in the step relation. -/
def andnFlags (flags result : Word) (operandBits : Nat) : Word :=
  setFlag (setFlag (setFlag (setFlag flags 0 false) 6 (resultZero result))
    7 (resultSign result operandBits)) 11 false

/-- Double shifts use five count bits, or six at operand size 64. -/
def doubleShiftCount (count : Word) (operandBits : Nat) : Word :=
  count &&& (if operandBits = 64 then 63 else 31)

/-- Form a double-width concatenation, shift it, and select the destination
half. For counts exceeding operand size the ISA permits any low-lane result;
this expression is an executable representative, not an extra defined result. -/
def doubleShiftValue (left : Bool) (destination source count : Word)
    (operandBits : Nat) : Word :=
  let mask := BitVec.ofNat 64 (2 ^ operandBits) - 1
  let dst := (destination &&& mask).setWidth 128
  let src := (source &&& mask).setWidth 128
  let amount := (doubleShiftCount count operandBits).setWidth 128
  let pair := if left then (dst <<< operandBits) ||| src else (src <<< operandBits) ||| dst
  let shifted := if left then (pair <<< amount) >>> BitVec.ofNat 128 operandBits
    else pair >>> amount
  (shifted.setWidth operandBits).setWidth 64

/-- OF at count one reports a sign change for both SHLD and SHRD. The
preserved representative at other counts imposes no ISA-defined flag value. -/
def doubleShiftOverflow (original result count : Word) (operandBits : Nat) (old : Bool) : Bool :=
  if count = 1 then resultSign original operandBits != resultSign result operandBits else old

/-- POP into SP/RSP increments the incoming stack pointer before writing
its destination. The16-bit write retains the incremented pointer's high bits. -/
def popRsp (rsp value : Word) (operandBits : Nat) : Word :=
  let advanced := rsp + BitVec.ofNat 64 (operandBits / 8)
  let mask := BitVec.ofNat 64 (2 ^ operandBits) - 1
  if operandBits = 32 then value &&& mask
  else (advanced &&& ~~~mask) ||| (value &&& mask)

inductive BzhiWidth
  | w32 | w64
  deriving DecidableEq, Repr

def BzhiWidth.bytes : BzhiWidth → Nat | .w32 => 4 | .w64 => 8

def BzhiWidth.bits (width : BzhiWidth) : Nat := width.bytes * 8

inductive BitIndex
  | register (reg : Register)
  | immediate (value : Byte)
  deriving DecidableEq, Repr

def CmovWidth.bits (width : CmovWidth) : Nat := width.bytes * 8

def bitIndexValue (s : State) : BitIndex → Word
  | .register r => s.gpr r
  | .immediate b => b.setWidth 64

/-- A memory bit string with a register index uses a signed word displacement;
immediate indices use the instruction's already encoded effective address. -/
def bitBaseSource (width : CmovWidth) (source : Source) (index : BitIndex)
    (s : State) : Source :=
  match source, index with
  | .memory address, .register r =>
      let value := match width with
        | .w16 => ((s.gpr r).setWidth 16).toInt
        | .w32 => ((s.gpr r).setWidth 32).toInt
        | .w64 => (s.gpr r).toInt
      .memory (address + BitVec.ofInt 64 (value / width.bits * width.bytes))
  | _, _ => source

inductive BmiShift | left | right | arithmetic | rotate
  deriving DecidableEq, Repr

inductive ShiftCount
  | register (reg : Register)
  | immediate (value : BitVec 8)
  deriving DecidableEq, Repr

def countValue (s : State) : ShiftCount → Word
  | .register r => s.gpr r | .immediate value => value.setWidth 64

/-- BMI2 shifts read width-sized operands, mask counts to five/six bits,
and leave every flag unchanged. Rotate selects a window in a doubled source. -/
def bmiShiftValue (width : BzhiWidth) (kind : BmiShift) (value amount : Word) : Word :=
  let source := value.setWidth width.bits
  let count := amount &&& BitVec.ofNat 64 (width.bits - 1)
  match kind with
  | .left => (source <<< count).setWidth 64
  | .right => (source >>> count).setWidth 64
  | .arithmetic => (source.sshiftRight' count).setWidth 64
  | .rotate =>
      let pair := (source.setWidth 128 <<< width.bits) ||| source.setWidth 128
      ((pair >>> count.setWidth 128).setWidth width.bits).setWidth 64

def bmiShiftStep (width : BzhiWidth) (kind : BmiShift) (dst : Register) (source : Source)
    (count : ShiftCount) (nextPc : Word) (s : State) : Transition State :=
  match readSource s source width.bytes with
  | .error fault => ⟨s, [.fault fault], some fault⟩
  | .ok (value, events) =>
      let result := bmiShiftValue width kind value (countValue s count)
      ⟨{ s with gpr := (fun r => if r = dst then result else s.gpr r), pc := nextPc }, events, none⟩

/-- Reverse only the architectural operand bytes, stated by a byte-list
permutation rather than the implementation's mask-and-shift ladder. -/
def reverseBytes (value : Word) (bytes : Nat) : Word :=
  littleEndian 64 (valueBytes value bytes).reverse

def writeValue (width : CmovWidth) (old value : Word) : Word :=
  match width with
  | .w16 => (old &&& 0xffffffffffff0000) ||| (value &&& 0xffff)
  | .w32 => (value.setWidth 32).setWidth 64
  | .w64 => value

def swapStep (width : BzhiWidth) (dst : Register) (nextPc : Word) (s : State) : Transition State :=
  let value := reverseBytes (s.gpr dst) width.bytes
  ⟨{ s with gpr := fun r => if r = dst then value else s.gpr r, pc := nextPc }, [], none⟩

def movbeLoadStep (width : CmovWidth) (dst : Register) (address nextPc : Word) (s : State) : Transition State :=
  match readSource s (.memory address) width.bytes with
  | .error fault => ⟨s, [.fault fault], some fault⟩
  | .ok (source, events) =>
      let value := writeValue width (s.gpr dst) (reverseBytes source width.bytes)
      ⟨{ s with gpr := fun r => if r = dst then value else s.gpr r, pc := nextPc }, events, none⟩

def movbeStoreStep (width : CmovWidth) (src : Register) (address nextPc : Word) (s : State) : Transition State :=
  let value := reverseBytes (s.gpr src) width.bytes
  match writeMemory s.memory address value width.bytes with
  | .error fault => ⟨s, [.fault fault], some fault⟩
  | .ok (memory, event) => ⟨{ s with memory := memory, pc := nextPc }, [event], none⟩

/-- Commit a PUSH transfer only after its read (if any) and whole-width
write permission check. Memory faults preserve every architectural component;
ordered reads preceding a write fault remain observable events. -/
def pushTransfer (width : StackWidth) (value : Word) (reads : List Event)
    (nextPc : Word) (s : State) : Transition State :=
  let address := s.gpr 4 - BitVec.ofNat 64 width.bytes
  match writeMemory s.memory address value width.bytes with
  | .error fault => ⟨s, reads ++ [.fault fault], some fault⟩
  | .ok (memory, event) =>
      ⟨{ s with gpr := (fun r => if r = 4 then address else s.gpr r), memory := memory, pc := nextPc },
        reads ++ [event], none⟩

/-- Scalar integer sizes, including byte-register lanes absent from CMOV. -/
inductive ScalarWidth | w8 | w16 | w32 | w64
  deriving DecidableEq, Repr

def ScalarWidth.bytes : ScalarWidth → Nat
  | .w8 => 1 | .w16 => 2 | .w32 => 4 | .w64 => 8

def ScalarWidth.bits (width : ScalarWidth) : Nat := width.bytes * 8

inductive RegisterSlice
  | low (reg : Register)
  | high (reg : Fin 4)
  deriving DecidableEq, Repr

def RegisterSlice.reg : RegisterSlice → Register
  | .low reg => reg
  | .high reg => ⟨reg.val, by omega⟩

def RegisterSlice.shift (slice : RegisterSlice) (width : ScalarWidth) : Nat :=
  match slice with
  | .high _ => if width = .w8 then 8 else 0
  | .low _ => 0

inductive ScalarSource
  | register (slice : RegisterSlice)
  | memory (address : Word)
  | immediate (value : Word)
  deriving DecidableEq, Repr

inductive ScalarDestination
  | register (slice : RegisterSlice)
  | memory (address : Word)
  deriving DecidableEq, Repr

def scalarRegisterValue (s : State) (width : ScalarWidth) (slice : RegisterSlice) : Word :=
  (((s.gpr slice.reg) >>> slice.shift width).setWidth width.bits).setWidth 64

def scalarWriteValue (old value : Word) (width : ScalarWidth) (slice : RegisterSlice) : Word :=
  if width = .w32 then (value.setWidth 32).setWidth 64
  else
    let shift := slice.shift width
    let mask := BitVec.ofNat 64 (2^width.bits - 1) <<< shift
    (old &&& ~~~mask) ||| (((value.setWidth width.bits).setWidth 64) <<< shift)

def scalarRead (s : State) (width : ScalarWidth) : ScalarSource → Except Fault (Word × List Event)
  | .register slice => .ok (scalarRegisterValue s width slice, [])
  | .immediate value => .ok (value, [])
  | .memory address => readSource s (.memory address) width.bytes

def scalarWrite (s : State) (width : ScalarWidth) (destination : ScalarDestination) (value : Word) :
    Except Fault (State × List Event) :=
  match destination with
  | .register slice =>
      .ok ({ s with gpr := fun r => if r = slice.reg then
        scalarWriteValue (s.gpr r) value width slice else s.gpr r }, [])
  | .memory address =>
      match writeMemory s.memory address value width.bytes with
      | .error fault => .error fault
      | .ok (memory, event) => .ok ({ s with memory := memory }, [event])

/-- Ordinary MOV reads its source before changing an aliased destination or
address register. Byte/word writes preserve other bits, E writes zero-extend,
and every flag and vector is preserved, including on a memory fault. -/
def moveStep (width : ScalarWidth) (dst : ScalarDestination) (src : ScalarSource)
    (nextPc : Word) (s : State) : Transition State :=
  match scalarRead s width src with
  | .error fault => ⟨s, [.fault fault], some fault⟩
  | .ok (value, reads) =>
      match scalarWrite s width dst value with
      | .error fault => ⟨s, reads ++ [.fault fault], some fault⟩
      | .ok (result, writes) => ⟨{ result with pc := nextPc }, reads ++ writes, none⟩

/-- One architectural instruction with its decoded fall-through address.
Effective-address decoding supplies the memory source address; reads remain
part of this step, so a false-condition CMOV cannot suppress an access fault. -/
inductive Instruction
  | move (width : ScalarWidth) (dst : ScalarDestination) (src : ScalarSource) (nextPc : Word)
  | push (width : StackWidth) (src : Register) (nextPc : Word)
  | pushImmediate (width : StackWidth) (value nextPc : Word)
  | pushMemory (width : StackWidth) (address nextPc : Word)
  | popMemory (width : StackWidth) (address nextPc : Word)
  | pop (width : StackWidth) (dst : Register) (nextPc : Word)
  | cmov (width : CmovWidth) (cc : Fin 16) (dst : Register)
      (source : Source) (nextPc : Word)
  | andn (width : BzhiWidth) (dst first : Register) (second : Source) (nextPc : Word)
  | byteSwap (width : BzhiWidth) (dst : Register) (nextPc : Word)
  | movbeLoad (width : CmovWidth) (dst : Register) (address nextPc : Word)
  | movbeStore (width : CmovWidth) (src : Register) (address nextPc : Word)
  | bmiShift (width : BzhiWidth) (kind : BmiShift) (dst : Register) (source : Source)
      (count : ShiftCount) (nextPc : Word)
  | bzhi (width : BzhiWidth) (dst : Register) (source : Source)
      (count : Register) (nextPc : Word)
  | bt (width : CmovWidth) (source : Source) (index : BitIndex) (nextPc : Word)
  deriving DecidableEq, Repr

def step (instruction : Instruction) (s : State) : Transition State :=
  match instruction with
  | .move width dst src nextPc => moveStep width dst src nextPc s
  | .byteSwap width dst nextPc => swapStep width dst nextPc s
  | .movbeLoad width dst address nextPc => movbeLoadStep width dst address nextPc s
  | .movbeStore width src address nextPc => movbeStoreStep width src address nextPc s
  | .bmiShift width kind dst source count nextPc => bmiShiftStep width kind dst source count nextPc s
  | .push width src nextPc => pushTransfer width (s.gpr src) [] nextPc s
  | .pushImmediate width value nextPc => pushTransfer width value [] nextPc s
  | .pushMemory width address nextPc =>
      match readSource s (.memory address) width.bytes with
      | .error fault => ⟨s, [.fault fault], some fault⟩
      | .ok (value, events) => pushTransfer width value events nextPc s
  | .popMemory width address nextPc =>
      match readSource s (.memory (s.gpr 4)) width.bytes with
      | .error fault => ⟨s, [.fault fault], some fault⟩
      | .ok (value, events) =>
          match writeMemory s.memory address value width.bytes with
          | .error fault => ⟨s, events ++ [.fault fault], some fault⟩
          | .ok (memory, event) =>
              let advanced := s.gpr 4 + BitVec.ofNat 64 width.bytes
              ⟨{ s with gpr := (fun r => if r = 4 then advanced else s.gpr r), memory := memory, pc := nextPc },
                events ++ [event], none⟩
  | .pop width dst nextPc =>
      match readSource s (.memory (s.gpr 4)) width.bytes with
      | .error fault => ⟨s, [.fault fault], some fault⟩
      | .ok (value, events) =>
          let advanced := s.gpr 4 + BitVec.ofNat 64 width.bytes
          let afterStack := fun r => if r = 4 then advanced else s.gpr r
          let result := cmovValue width.registerWidth true (afterStack dst) value
          ⟨{ s with gpr := (fun r => if r = dst then result else afterStack r), pc := nextPc }, events, none⟩
  | .cmov width cc dst source nextPc =>
      match readSource s source width.bytes with
      | .error fault => ⟨s, [.fault fault], some fault⟩
      | .ok (value, events) =>
          let result := cmovValue width (condition s.rflags cc) (s.gpr dst) value
          ⟨{ s with gpr := (fun r => if r = dst then result else s.gpr r), pc := nextPc }, events, none⟩
  | .bt width source index nextPc =>
      match readSource s (bitBaseSource width source index s) width.bytes with
      | .error fault => ⟨s, [.fault fault], some fault⟩
      | .ok (value, events) =>
          ⟨{ s with rflags := setFlag s.rflags 0 (bitTest value (bitIndexValue s index) width.bits), pc := nextPc },
            events, none⟩

  | .andn width dst first second nextPc =>
      match readSource s second width.bytes with
      | .error fault => ⟨s, [.fault fault], some fault⟩
      | .ok (value, events) =>
          let mask := BitVec.ofNat 64 (2 ^ width.bits) - 1
          let result := andNot (s.gpr first) value &&& mask
          ⟨{ s with gpr := (fun r => if r = dst then result else s.gpr r), rflags := andnFlags s.rflags result width.bits, pc := nextPc }, events, none⟩
  | .bzhi width dst source count nextPc =>
      match readSource s source width.bytes with
      | .error fault => ⟨s, [.fault fault], some fault⟩
      | .ok (value, events) =>
          let count := s.gpr count &&& 0xff
          let result := zeroHighBits value count width.bits
          ⟨{ s with gpr := (fun r => if r = dst then result else s.gpr r), rflags := bzhiFlags s.rflags count result width.bits, pc := nextPc }, events, none⟩

/-- Defined RFLAGS output bits. BT sets CF and preserves ZF; OF/SF/AF/PF
are undefined. BZHI leaves only AF/PF undefined. The mask is consumed by hardware
checks and the step relation, rather than imposing values on undefined bits. -/
def definedFlags : Instruction → Word
  | .move .. => 0xffffffffffffffff
  | .push .. | .pushImmediate .. | .pushMemory .. | .popMemory .. => 0xffffffffffffffff
  | .byteSwap .. | .movbeLoad .. | .movbeStore .. => 0xffffffffffffffff
  | .bmiShift .. => 0xffffffffffffffff
  | .pop .. => 0xffffffffffffffff
  | .cmov .. => 0xffffffffffffffff
  | .bt .. => 0xfffffffffffff76b
  | .andn .. => 0xffffffffffffffeb
  | .bzhi .. => 0xffffffffffffffeb

/-- The executable gives a representative for undefined flags. The relational
ISA semantics below admits every value for those bits, as required by the SDM. -/
def matchesTransition (i : Instruction) (expected actual : Transition State) : Prop :=
  expected.events = actual.events ∧ expected.fault = actual.fault ∧
    let mask := if expected.fault.isSome then 0xffffffffffffffff else definedFlags i
    { expected.state with rflags := expected.state.rflags &&& mask } =
      { actual.state with rflags := actual.state.rflags &&& mask }

def Step (i : Instruction) (before : State) (after : Transition State) : Prop :=
  matchesTransition i (step i before) after

/-- Legacy prefix state for 64-bit decoding. A legacy prefix after a REX
invalidates that REX; a later REX supersedes earlier ones. -/
private structure Prefix where
  operand16 : Bool := false
  address32 : Bool := false
  rex : Nat := 0
  rexPresent : Bool := false
  segment : Nat := 0
  vexInvalid : Bool := false
  mandatoryPrefix : Nat := 0

private def stackWidth (p : Prefix) : StackWidth :=
  if p.rex / 8 = 1 then .w64 else if p.operand16 then .w16 else .w64

private def prefixes : List Byte → Prefix → Nat → Prefix × List Byte × Nat
  | [], p, n => (p, [], n)
  | b :: rest, p, n =>
      let v := b.toNat
      if v = 0x66 then prefixes rest { p with operand16 := true, rex := 0, rexPresent := false, vexInvalid := true } (n + 1)
      else if v = 0x67 then prefixes rest { p with address32 := true, rex := 0, rexPresent := false } (n + 1)
      else if v = 0x64 ∨ v = 0x65 then
        prefixes rest { p with segment := v, rex := 0, rexPresent := false } (n + 1)
      else if v = 0x26 ∨ v = 0x2e ∨ v = 0x36 ∨ v = 0x3e then
        prefixes rest { p with segment := 0, rex := 0, rexPresent := false } (n + 1)
      else if v = 0xf2 ∨ v = 0xf3 then prefixes rest { p with rex := 0, rexPresent := false, vexInvalid := true, mandatoryPrefix := v } (n + 1)
      else if 0x40 ≤ v ∧ v ≤ 0x4f then prefixes rest { p with rex := v - 0x40, rexPresent := true, vexInvalid := true } (n + 1)
      else (p, b :: rest, n)

private def byteAt (bytes : Array Byte) (position : Nat) : Except String Nat :=
  match bytes[position]? with
  | some b => .ok b.toNat
  | none => .error "truncated native encoding"

private def signedDisplacement (bytes : Array Byte) (position size : Nat) :
    Except String Word := do
  let mut value := 0
  for i in [:size] do
    value := value + (← byteAt bytes (position + i)) * 256 ^ i
  if size = 0 then pure 0
  else pure ((BitVec.ofNat (size * 8) value).signExtend 64)

private def registerCode (code : Nat) : Register :=
  ⟨code % 16, Nat.mod_lt _ (by decide)⟩

private structure AddressParts where
  base : Word
  index : Word
  relative : Bool
  missingBase : Bool
  cursor : Nat

/-- Intel 64 ModRM/SIB addressing. RIP-relative and no-base SIB are distinct;
REX.X permits R12 as an index where the unextended index code means no index. -/
private def addressParts (s : State) (p : Prefix) (bytes : Array Byte)
    (mode rm cursor : Nat) : Except String AddressParts := do
  if rm = 4 then
    let sib ← byteAt bytes cursor
    let baseCode := sib % 8
    let indexCode := (sib / 8) % 8
    let scale := 2 ^ (sib / 64)
    let index := if indexCode = 4 ∧ (p.rex / 2) % 2 = 0 then 0
      else s.gpr (registerCode (indexCode + 8 * ((p.rex / 2) % 2))) * BitVec.ofNat 64 scale
    let missing : Bool := mode == 0 && baseCode == 5
    pure ⟨if missing then 0 else s.gpr (registerCode (baseCode + 8 * (p.rex % 2))),
      index, false, missing, cursor + 1⟩
  else
    let relative : Bool := mode == 0 && rm == 5
    pure ⟨if relative then 0 else s.gpr (registerCode (rm + 8 * (p.rex % 2))),
      0, relative, relative, cursor⟩

/-- Shared register/memory operand decoding. Trailing immediate bytes count
in RIP-relative addressing and in the architectural instruction-length limit. -/
private def operand (bytes : Array Byte) (s : State) (p : Prefix)
    (modrm cursor trailing : Nat) : Except String (Source × Word × Nat) := do
  let mode := modrm / 64
  let rm := modrm % 8
  if mode = 3 then
    let length := cursor + trailing
    if length > 15 then throw "native encoding exceeds the architectural 15-byte limit"
    pure (.register (registerCode (rm + 8 * (p.rex % 2))),
      s.pc + BitVec.ofNat 64 length, cursor)
  else
    let parts ← addressParts s p bytes mode rm cursor
    let size := if mode = 1 then 1 else if mode = 2 ∨ parts.missingBase then 4 else 0
    let displacement ← signedDisplacement bytes parts.cursor size
    let afterDisp := parts.cursor + size
    let length := afterDisp + trailing
    if length > 15 then throw "native encoding exceeds the architectural 15-byte limit"
    let nextPc := s.pc + BitVec.ofNat 64 length
    let base := if parts.relative then nextPc else parts.base
    let offset := base + parts.index + displacement
    let offset := if p.address32 then (offset.setWidth 32).setWidth 64 else offset
    let segment := if p.segment = 0x64 then s.fsBase else if p.segment = 0x65 then s.gsBase else 0
    pure (.memory (segment + offset), nextPc, afterDisp)

private def scalarWidth (p : Prefix) (byte : Bool) : ScalarWidth :=
  if byte then .w8 else if p.rex / 8 = 1 then .w64 else if p.operand16 then .w16 else .w32

private def scalarSlice (p : Prefix) (width : ScalarWidth) (code : Nat) : RegisterSlice :=
  if h : width = .w8 ∧ p.rexPresent = false ∧ 4 ≤ code ∧ code < 8 then
    .high ⟨code - 4, by omega⟩
  else .low (registerCode code)

private def scalarSource (p : Prefix) (width : ScalarWidth) : Source → ScalarSource
  | .register reg => .register (scalarSlice p width reg.val)
  | .memory address => .memory address

private def scalarDestination (p : Prefix) (width : ScalarWidth) : Source → ScalarDestination
  | .register reg => .register (scalarSlice p width reg.val)
  | .memory address => .memory address

private def fallthrough (s : State) (length : Nat) : Except String Word :=
  if length ≤ 15 then .ok (s.pc + BitVec.ofNat 64 length)
  else .error "native encoding exceeds the architectural 15-byte limit"

/-- Decode a native instruction. Operands, effective addresses and fall-through
PC are obtained from bytes, including REX, operand/address size, segment bases,
ModRM, SIB and signed displacement. No caller-supplied decode is trusted. -/
def decode (bytes : Array Byte) (s : State) : Except String Instruction := do
  let (p, _, count) := prefixes bytes.toList {} 0
  let first ← byteAt bytes count
  if 0xb0 ≤ first ∧ first ≤ 0xbf then
    let width := scalarWidth p (decide (first < 0xb8))
    let size := width.bytes
    let immediate ← signedDisplacement bytes (count + 1) size
    let nextPc ← fallthrough s (count + 1 + size)
    let dst := scalarSlice p width (first % 8 + 8 * (p.rex % 2))
    return .move width (.register dst) (.immediate immediate) nextPc
  if 0x88 ≤ first ∧ first ≤ 0x8b then
    let width := scalarWidth p (first % 2 == 0)
    let modrm ← byteAt bytes (count + 1)
    let reg := scalarSlice p width ((modrm / 8) % 8 + 8 * ((p.rex / 4) % 2))
    let (rm, nextPc, _) ← operand bytes s p modrm (count + 2) 0
    if first < 0x8a then
      return .move width (scalarDestination p width rm) (.register reg) nextPc
    else return .move width (.register reg) (scalarSource p width rm) nextPc
  if first = 0xc6 ∨ first = 0xc7 then
    let width := scalarWidth p (first == 0xc6)
    let modrm ← byteAt bytes (count + 1)
    if (modrm / 8) % 8 ≠ 0 then throw "invalid MOV immediate opcode extension"
    let size := if width = .w64 then 4 else width.bytes
    let (rm, nextPc, cursor) ← operand bytes s p modrm (count + 2) size
    let immediate ← signedDisplacement bytes cursor size
    return .move width (scalarDestination p width rm) (.immediate immediate) nextPc
  if 0xa0 ≤ first ∧ first ≤ 0xa3 then
    let width := scalarWidth p (first % 2 == 0)
    let size := if p.address32 then 4 else 8
    let raw ← signedDisplacement bytes (count + 1) size
    let offset := if p.address32 then (raw.setWidth 32).setWidth 64 else raw
    let segment := if p.segment = 0x64 then s.fsBase else if p.segment = 0x65 then s.gsBase else 0
    let nextPc ← fallthrough s (count + 1 + size)
    if first < 0xa2 then return .move width (.register (.low 0)) (.memory (segment + offset)) nextPc
    else return .move width (.memory (segment + offset)) (.register (.low 0)) nextPc
  if 0x50 ≤ first ∧ first ≤ 0x57 then
    let length := count + 1
    if length > 15 then throw "native encoding exceeds the architectural 15-byte limit"
    let src := registerCode (first % 8 + 8 * (p.rex % 2))
    let width := stackWidth p
    return .push width src (s.pc + BitVec.ofNat 64 length)
  if 0x58 ≤ first ∧ first ≤ 0x5f then
    let length := count + 1
    if length > 15 then throw "native encoding exceeds the architectural 15-byte limit"
    let dst := registerCode (first % 8 + 8 * (p.rex % 2))
    let width := stackWidth p
    return .pop width dst (s.pc + BitVec.ofNat 64 length)
  if first = 0x68 ∨ first = 0x6a then
    let width := stackWidth p
    let immediateBytes := if first = 0x6a then 1 else if width = .w16 then 2 else 4
    let value ← signedDisplacement bytes (count + 1) immediateBytes
    let length := count + 1 + immediateBytes
    if length > 15 then throw "native encoding exceeds the architectural 15-byte limit"
    return .pushImmediate width value (s.pc + BitVec.ofNat 64 length)
  if first = 0xff then
    let modrm ← byteAt bytes (count + 1)
    if (modrm / 8) % 8 = 6 then
      let (source, nextPc, _) ← operand bytes s p modrm (count + 2) 0
      match source with
      | .register src => return .push (stackWidth p) src nextPc
      | .memory address => return .pushMemory (stackWidth p) address nextPc
  if first = 0x8f then
    let modrm ← byteAt bytes (count + 1)
    if (modrm / 8) % 8 ≠ 0 then throw "invalid POP opcode extension"
    let width := stackWidth p
    let advanced := s.gpr 4 + BitVec.ofNat 64 width.bytes
    let updated := { s with gpr := fun r => if r = 4 then advanced else s.gpr r }
    let (destination, nextPc, _) ← operand bytes updated p modrm (count + 2) 0
    match destination with
    | .register dst => return .pop width dst nextPc
    | .memory address => return .popMemory width address nextPc
  if first = 0xc4 then
    let vex1 ← byteAt bytes (count + 1)
    let vex2 ← byteAt bytes (count + 2)
    let opcode ← byteAt bytes (count + 3)
    let map := vex1 % 32
    let vexPrefix := vex2 % 8
    let isBit := map == 2 && vexPrefix == 0 && (opcode == 0xf5 || opcode == 0xf2)
    let isShift := map == 2 && opcode == 0xf7 && (vexPrefix == 1 || vexPrefix == 2 || vexPrefix == 3)
    let isRotate := map == 3 && opcode == 0xf0 && vexPrefix == 3 && (vex2 / 8) % 16 == 15
    if p.vexInvalid || !(isBit || isShift || isRotate) then
      throw "invalid BMI VEX encoding"
    let rex := (if vex1 / 128 = 0 then 4 else 0) +
      (if (vex1 / 64) % 2 = 0 then 2 else 0) +
      (if (vex1 / 32) % 2 = 0 then 1 else 0)
    let p := { p with rex := rex }
    let modrm ← byteAt bytes (count + 4)
    let dst := registerCode ((modrm / 8) % 8 + 8 * ((rex / 4) % 2))
    let index := registerCode (15 - (vex2 / 8) % 16)
    let width := if vex2 / 128 = 0 then BzhiWidth.w32 else .w64
    let (source, nextPc, cursor) ← operand bytes s p modrm (count + 5) (if isRotate then 1 else 0)
    if isRotate then
      let immediate ← byteAt bytes cursor
      return .bmiShift width .rotate dst source (.immediate (BitVec.ofNat 8 immediate)) nextPc
    if isShift then
      let kind := if vexPrefix = 1 then BmiShift.left else if vexPrefix = 2 then .arithmetic else .right
      return .bmiShift width kind dst source (.register index) nextPc
    if opcode = 0xf2 then return .andn width dst index source nextPc
    return .bzhi width dst source index nextPc
  let opcode ← byteAt bytes (count + 1)
  if first ≠ 0x0f then throw "expected two-byte native opcode"
  if 0xc8 ≤ opcode ∧ opcode ≤ 0xcf then
    let length := count + 2
    if length > 15 then throw "native encoding exceeds the architectural 15-byte limit"
    if p.operand16 ∧ p.rex / 8 = 0 then throw "BSWAP has no defined 16-bit result"
    let dst := registerCode (opcode % 8 + 8 * (p.rex % 2))
    return .byteSwap (if p.rex / 8 = 1 then .w64 else .w32) dst (s.pc + BitVec.ofNat 64 length)
  if opcode = 0x38 then
    let third ← byteAt bytes (count + 2)
    if p.mandatoryPrefix = 0xf2 ∨ (third ≠ 0xf0 ∧ third ≠ 0xf1) then
      throw "unrecognized three-byte native opcode"
    let modrm ← byteAt bytes (count + 3)
    if modrm / 64 = 3 then throw "MOVBE requires a memory operand"
    let reg := registerCode ((modrm / 8) % 8 + 8 * ((p.rex / 4) % 2))
    let width := if p.rex / 8 = 1 then CmovWidth.w64 else if p.operand16 then .w16 else .w32
    let (source, nextPc, _) ← operand bytes s p modrm (count + 4) 0
    match source with
    | .register _ => throw "MOVBE requires a memory operand"
    | .memory address =>
        if third = 0xf0 then return .movbeLoad width reg address nextPc
        else return .movbeStore width reg address nextPc
  let modrm ← byteAt bytes (count + 2)
  let reg := registerCode ((modrm / 8) % 8 + 8 * ((p.rex / 4) % 2))
  let width := if p.rex / 8 = 1 then CmovWidth.w64
    else if p.operand16 then .w16 else .w32
  if 0x40 ≤ opcode ∧ opcode ≤ 0x4f then
    let (source, nextPc, _) ← operand bytes s p modrm (count + 3) 0
    let cc : Fin 16 := ⟨opcode % 16, Nat.mod_lt _ (by decide)⟩
    pure (.cmov width cc reg source nextPc)
  else if opcode = 0xa3 then
    let (source, nextPc, _) ← operand bytes s p modrm (count + 3) 0
    pure (.bt width source (.register reg) nextPc)
  else if opcode = 0xba ∧ (modrm / 8) % 8 = 4 then
    let (source, nextPc, cursor) ← operand bytes s p modrm (count + 3) 1
    let immediate ← byteAt bytes cursor
    pure (.bt width source (.immediate (BitVec.ofNat 8 immediate)) nextPc)
  else throw "unrecognized native opcode"

end KProgFormal.Reference.X86
