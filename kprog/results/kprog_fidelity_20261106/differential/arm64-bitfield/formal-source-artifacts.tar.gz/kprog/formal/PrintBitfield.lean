import KProgFormal.Refinement.Arm64Bitfield
#print axioms KProgFormal.Refinement.Arm64Bitfield.byte_bounds
#print axioms KProgFormal.Refinement.Arm64Bitfield.value_refines
#print axioms KProgFormal.Refinement.Arm64Bitfield.step_refines
