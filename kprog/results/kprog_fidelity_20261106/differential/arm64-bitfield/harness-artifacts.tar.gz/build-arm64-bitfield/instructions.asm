
/workspaces/repository/kprog/fidelity/build-arm64-bitfield/instructions.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <.text>:
   0:	53074c20 	ubfx	w0, w1, #7, #13
   4:	53007c20 	lsr	w0, w1, #0
   8:	53000020 	ubfx	w0, w1, #0, #1
   c:	531f7c20 	lsr	w0, w1, #31
  10:	53017c20 	lsr	w0, w1, #1
  14:	53074c21 	ubfx	w1, w1, #7, #13
  18:	53074c3f 	ubfx	wzr, w1, #7, #13
  1c:	13074c20 	sbfx	w0, w1, #7, #13
  20:	13007c20 	asr	w0, w1, #0
  24:	13000020 	sbfx	w0, w1, #0, #1
  28:	131f7c20 	asr	w0, w1, #31
  2c:	13017c20 	asr	w0, w1, #1
  30:	13074c21 	sbfx	w1, w1, #7, #13
  34:	13074c3f 	sbfx	wzr, w1, #7, #13
  38:	53193020 	ubfiz	w0, w1, #7, #13
  3c:	53007c20 	lsr	w0, w1, #0
  40:	53000020 	ubfx	w0, w1, #0, #1
  44:	53010020 	lsl	w0, w1, #31
  48:	531f7820 	lsl	w0, w1, #1
  4c:	53193021 	ubfiz	w1, w1, #7, #13
  50:	5319303f 	ubfiz	wzr, w1, #7, #13
  54:	33074c20 	bfxil	w0, w1, #7, #13
  58:	33007c20 	bfxil	w0, w1, #0, #32
  5c:	33000020 	bfxil	w0, w1, #0, #1
  60:	331f7c20 	bfxil	w0, w1, #31, #1
  64:	33017c20 	bfxil	w0, w1, #1, #31
  68:	33074c21 	bfxil	w1, w1, #7, #13
  6c:	33074c3f 	bfxil	wzr, w1, #7, #13
  70:	33193020 	bfi	w0, w1, #7, #13
  74:	33007c20 	bfxil	w0, w1, #0, #32
  78:	33000020 	bfxil	w0, w1, #0, #1
  7c:	33010020 	bfi	w0, w1, #31, #1
  80:	331f7820 	bfi	w0, w1, #1, #31
  84:	33193021 	bfi	w1, w1, #7, #13
  88:	3319303f 	bfi	wzr, w1, #7, #13
  8c:	d3474c20 	ubfx	x0, x1, #7, #13
  90:	d340fc20 	lsr	x0, x1, #0
  94:	d3400020 	ubfx	x0, x1, #0, #1
  98:	d37ffc20 	lsr	x0, x1, #63
  9c:	d341fc20 	lsr	x0, x1, #1
  a0:	d3474c21 	ubfx	x1, x1, #7, #13
  a4:	d3474c3f 	ubfx	xzr, x1, #7, #13
  a8:	93474c20 	sbfx	x0, x1, #7, #13
  ac:	9340fc20 	asr	x0, x1, #0
  b0:	93400020 	sbfx	x0, x1, #0, #1
  b4:	937ffc20 	asr	x0, x1, #63
  b8:	9341fc20 	asr	x0, x1, #1
  bc:	93474c21 	sbfx	x1, x1, #7, #13
  c0:	93474c3f 	sbfx	xzr, x1, #7, #13
  c4:	d3793020 	ubfiz	x0, x1, #7, #13
  c8:	d340fc20 	lsr	x0, x1, #0
  cc:	d3400020 	ubfx	x0, x1, #0, #1
  d0:	d3410020 	lsl	x0, x1, #63
  d4:	d37ff820 	lsl	x0, x1, #1
  d8:	d3793021 	ubfiz	x1, x1, #7, #13
  dc:	d379303f 	ubfiz	xzr, x1, #7, #13
  e0:	b3474c20 	bfxil	x0, x1, #7, #13
  e4:	b340fc20 	bfxil	x0, x1, #0, #64
  e8:	b3400020 	bfxil	x0, x1, #0, #1
  ec:	b37ffc20 	bfxil	x0, x1, #63, #1
  f0:	b341fc20 	bfxil	x0, x1, #1, #63
  f4:	b3474c21 	bfxil	x1, x1, #7, #13
  f8:	b3474c3f 	bfxil	xzr, x1, #7, #13
  fc:	b3793020 	bfi	x0, x1, #7, #13
 100:	b340fc20 	bfxil	x0, x1, #0, #64
 104:	b3400020 	bfxil	x0, x1, #0, #1
 108:	b3410020 	bfi	x0, x1, #63, #1
 10c:	b37ff820 	bfi	x0, x1, #1, #63
 110:	b3793021 	bfi	x1, x1, #7, #13
 114:	b379303f 	bfi	xzr, x1, #7, #13
