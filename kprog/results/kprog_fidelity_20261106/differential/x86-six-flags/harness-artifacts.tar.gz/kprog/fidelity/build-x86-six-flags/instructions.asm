
build-x86-six-flags/instructions.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <.text>:
   0:	53                                              	push   rbx
   1:	58                                              	pop    rax
   2:	66 53                                           	push   bx
   4:	66 58                                           	pop    ax
   6:	90                                              	nop
   7:	48 98                                           	cdqe
   9:	0f 10 07                                        	movups xmm0,XMMWORD PTR [rdi]
   c:	0f 11 07                                        	movups XMMWORD PTR [rdi],xmm0
   f:	48 89 e0                                        	mov    rax,rsp
  12:	89 e0                                           	mov    eax,esp
  14:	48 8d 44 24 10                                  	lea    rax,[rsp+0x10]
  19:	48 83 fc 00                                     	cmp    rsp,0x0
  1d:	48 89 c4                                        	mov    rsp,rax
  20:	89 c4                                           	mov    esp,eax
  22:	48 8d 64 24 10                                  	lea    rsp,[rsp+0x10]
  27:	48 83 c4 10                                     	add    rsp,0x10
  2b:	54                                              	push   rsp
  2c:	5c                                              	pop    rsp
  2d:	66 54                                           	push   sp
  2f:	66 5c                                           	pop    sp
  31:	68 00 00 00 80                                  	push   0xffffffff80000000
  36:	6a 80                                           	push   0xffffffffffffff80
  38:	6a ff                                           	push   0xffffffffffffffff
  3a:	6a 00                                           	push   0x0
  3c:	6a 01                                           	push   0x1
  3e:	6a 7f                                           	push   0x7f
  40:	68 80 00 00 00                                  	push   0x80
  45:	68 78 56 34 12                                  	push   0x12345678
  4a:	66 6a f9                                        	pushw  0xfff9
  4d:	ff 77 08                                        	push   QWORD PTR [rdi+0x8]
  50:	66 ff 77 08                                     	push   WORD PTR [rdi+0x8]
  54:	8f 47 08                                        	pop    QWORD PTR [rdi+0x8]
  57:	66 8f 47 08                                     	pop    WORD PTR [rdi+0x8]
  5b:	ff 74 24 f0                                     	push   QWORD PTR [rsp-0x10]
  5f:	8f 44 24 f0                                     	pop    QWORD PTR [rsp-0x10]
  63:	66 48 53                                        	data16 rex.W push rbx
  66:	48                                              	rex.W
  67:	66 53                                           	push   bx
  69:	66 48 ff f3                                     	data16 rex.W push rbx
  6d:	48                                              	rex.W
  6e:	66 ff f3                                        	push   bx
  71:	66 48 58                                        	data16 rex.W pop rax
  74:	48                                              	rex.W
  75:	66 58                                           	pop    ax
  77:	66 48 8f c0                                     	data16 rex.W pop rax
  7b:	48                                              	rex.W
  7c:	66 8f c0                                        	pop    ax
  7f:	88 d8                                           	mov    al,bl
  81:	b0 7f                                           	mov    al,0x7f
  83:	88 47 08                                        	mov    BYTE PTR [rdi+0x8],al
  86:	8a 47 08                                        	mov    al,BYTE PTR [rdi+0x8]
  89:	c6 47 08 7f                                     	mov    BYTE PTR [rdi+0x8],0x7f
  8d:	00 d8                                           	add    al,bl
  8f:	04 7f                                           	add    al,0x7f
  91:	00 47 08                                        	add    BYTE PTR [rdi+0x8],al
  94:	80 47 08 7f                                     	add    BYTE PTR [rdi+0x8],0x7f
  98:	02 47 08                                        	add    al,BYTE PTR [rdi+0x8]
  9b:	10 d8                                           	adc    al,bl
  9d:	14 7f                                           	adc    al,0x7f
  9f:	10 47 08                                        	adc    BYTE PTR [rdi+0x8],al
  a2:	80 57 08 7f                                     	adc    BYTE PTR [rdi+0x8],0x7f
  a6:	12 47 08                                        	adc    al,BYTE PTR [rdi+0x8]
  a9:	28 d8                                           	sub    al,bl
  ab:	2c 7f                                           	sub    al,0x7f
  ad:	28 47 08                                        	sub    BYTE PTR [rdi+0x8],al
  b0:	80 6f 08 7f                                     	sub    BYTE PTR [rdi+0x8],0x7f
  b4:	2a 47 08                                        	sub    al,BYTE PTR [rdi+0x8]
  b7:	18 d8                                           	sbb    al,bl
  b9:	1c 7f                                           	sbb    al,0x7f
  bb:	18 47 08                                        	sbb    BYTE PTR [rdi+0x8],al
  be:	80 5f 08 7f                                     	sbb    BYTE PTR [rdi+0x8],0x7f
  c2:	1a 47 08                                        	sbb    al,BYTE PTR [rdi+0x8]
  c5:	38 d8                                           	cmp    al,bl
  c7:	3c 7f                                           	cmp    al,0x7f
  c9:	38 47 08                                        	cmp    BYTE PTR [rdi+0x8],al
  cc:	80 7f 08 7f                                     	cmp    BYTE PTR [rdi+0x8],0x7f
  d0:	3a 47 08                                        	cmp    al,BYTE PTR [rdi+0x8]
  d3:	84 d8                                           	test   al,bl
  d5:	a8 7f                                           	test   al,0x7f
  d7:	84 47 08                                        	test   BYTE PTR [rdi+0x8],al
  da:	f6 47 08 7f                                     	test   BYTE PTR [rdi+0x8],0x7f
  de:	20 d8                                           	and    al,bl
  e0:	24 7f                                           	and    al,0x7f
  e2:	22 47 08                                        	and    al,BYTE PTR [rdi+0x8]
  e5:	20 47 08                                        	and    BYTE PTR [rdi+0x8],al
  e8:	80 67 08 7f                                     	and    BYTE PTR [rdi+0x8],0x7f
  ec:	08 d8                                           	or     al,bl
  ee:	0c 7f                                           	or     al,0x7f
  f0:	0a 47 08                                        	or     al,BYTE PTR [rdi+0x8]
  f3:	08 47 08                                        	or     BYTE PTR [rdi+0x8],al
  f6:	80 4f 08 7f                                     	or     BYTE PTR [rdi+0x8],0x7f
  fa:	30 d8                                           	xor    al,bl
  fc:	34 7f                                           	xor    al,0x7f
  fe:	32 47 08                                        	xor    al,BYTE PTR [rdi+0x8]
 101:	30 47 08                                        	xor    BYTE PTR [rdi+0x8],al
 104:	80 77 08 7f                                     	xor    BYTE PTR [rdi+0x8],0x7f
 108:	fe c0                                           	inc    al
 10a:	fe 47 08                                        	inc    BYTE PTR [rdi+0x8]
 10d:	fe c8                                           	dec    al
 10f:	fe 4f 08                                        	dec    BYTE PTR [rdi+0x8]
 112:	f6 d8                                           	neg    al
 114:	f6 5f 08                                        	neg    BYTE PTR [rdi+0x8]
 117:	f6 d0                                           	not    al
 119:	f6 57 08                                        	not    BYTE PTR [rdi+0x8]
 11c:	86 d8                                           	xchg   al,bl
 11e:	c0 e0 00                                        	shl    al,0x0
 121:	d0 e0                                           	shl    al,1
 123:	c0 e0 07                                        	shl    al,0x7
 126:	c0 e0 08                                        	shl    al,0x8
 129:	c0 e0 0f                                        	shl    al,0xf
 12c:	c0 e0 10                                        	shl    al,0x10
 12f:	c0 e0 1f                                        	shl    al,0x1f
 132:	c0 e0 20                                        	shl    al,0x20
 135:	c0 e0 3f                                        	shl    al,0x3f
 138:	c0 e0 40                                        	shl    al,0x40
 13b:	c0 e0 ff                                        	shl    al,0xff
 13e:	d2 e0                                           	shl    al,cl
 140:	c0 e8 00                                        	shr    al,0x0
 143:	d0 e8                                           	shr    al,1
 145:	c0 e8 07                                        	shr    al,0x7
 148:	c0 e8 08                                        	shr    al,0x8
 14b:	c0 e8 0f                                        	shr    al,0xf
 14e:	c0 e8 10                                        	shr    al,0x10
 151:	c0 e8 1f                                        	shr    al,0x1f
 154:	c0 e8 20                                        	shr    al,0x20
 157:	c0 e8 3f                                        	shr    al,0x3f
 15a:	c0 e8 40                                        	shr    al,0x40
 15d:	c0 e8 ff                                        	shr    al,0xff
 160:	d2 e8                                           	shr    al,cl
 162:	c0 f8 00                                        	sar    al,0x0
 165:	d0 f8                                           	sar    al,1
 167:	c0 f8 07                                        	sar    al,0x7
 16a:	c0 f8 08                                        	sar    al,0x8
 16d:	c0 f8 0f                                        	sar    al,0xf
 170:	c0 f8 10                                        	sar    al,0x10
 173:	c0 f8 1f                                        	sar    al,0x1f
 176:	c0 f8 20                                        	sar    al,0x20
 179:	c0 f8 3f                                        	sar    al,0x3f
 17c:	c0 f8 40                                        	sar    al,0x40
 17f:	c0 f8 ff                                        	sar    al,0xff
 182:	d2 f8                                           	sar    al,cl
 184:	c0 c0 00                                        	rol    al,0x0
 187:	d0 c0                                           	rol    al,1
 189:	c0 c0 07                                        	rol    al,0x7
 18c:	c0 c0 08                                        	rol    al,0x8
 18f:	c0 c0 0f                                        	rol    al,0xf
 192:	c0 c0 10                                        	rol    al,0x10
 195:	c0 c0 1f                                        	rol    al,0x1f
 198:	c0 c0 20                                        	rol    al,0x20
 19b:	c0 c0 3f                                        	rol    al,0x3f
 19e:	c0 c0 40                                        	rol    al,0x40
 1a1:	c0 c0 ff                                        	rol    al,0xff
 1a4:	d2 c0                                           	rol    al,cl
 1a6:	66 89 d8                                        	mov    ax,bx
 1a9:	66 b8 7f 00                                     	mov    ax,0x7f
 1ad:	66 89 47 08                                     	mov    WORD PTR [rdi+0x8],ax
 1b1:	66 8b 47 08                                     	mov    ax,WORD PTR [rdi+0x8]
 1b5:	66 c7 47 08 7f 00                               	mov    WORD PTR [rdi+0x8],0x7f
 1bb:	66 01 d8                                        	add    ax,bx
 1be:	66 83 c0 7f                                     	add    ax,0x7f
 1c2:	66 01 47 08                                     	add    WORD PTR [rdi+0x8],ax
 1c6:	66 83 47 08 7f                                  	add    WORD PTR [rdi+0x8],0x7f
 1cb:	66 03 47 08                                     	add    ax,WORD PTR [rdi+0x8]
 1cf:	66 11 d8                                        	adc    ax,bx
 1d2:	66 83 d0 7f                                     	adc    ax,0x7f
 1d6:	66 11 47 08                                     	adc    WORD PTR [rdi+0x8],ax
 1da:	66 83 57 08 7f                                  	adc    WORD PTR [rdi+0x8],0x7f
 1df:	66 13 47 08                                     	adc    ax,WORD PTR [rdi+0x8]
 1e3:	66 29 d8                                        	sub    ax,bx
 1e6:	66 83 e8 7f                                     	sub    ax,0x7f
 1ea:	66 29 47 08                                     	sub    WORD PTR [rdi+0x8],ax
 1ee:	66 83 6f 08 7f                                  	sub    WORD PTR [rdi+0x8],0x7f
 1f3:	66 2b 47 08                                     	sub    ax,WORD PTR [rdi+0x8]
 1f7:	66 19 d8                                        	sbb    ax,bx
 1fa:	66 83 d8 7f                                     	sbb    ax,0x7f
 1fe:	66 19 47 08                                     	sbb    WORD PTR [rdi+0x8],ax
 202:	66 83 5f 08 7f                                  	sbb    WORD PTR [rdi+0x8],0x7f
 207:	66 1b 47 08                                     	sbb    ax,WORD PTR [rdi+0x8]
 20b:	66 39 d8                                        	cmp    ax,bx
 20e:	66 83 f8 7f                                     	cmp    ax,0x7f
 212:	66 39 47 08                                     	cmp    WORD PTR [rdi+0x8],ax
 216:	66 83 7f 08 7f                                  	cmp    WORD PTR [rdi+0x8],0x7f
 21b:	66 3b 47 08                                     	cmp    ax,WORD PTR [rdi+0x8]
 21f:	66 85 d8                                        	test   ax,bx
 222:	66 a9 7f 00                                     	test   ax,0x7f
 226:	66 85 47 08                                     	test   WORD PTR [rdi+0x8],ax
 22a:	66 f7 47 08 7f 00                               	test   WORD PTR [rdi+0x8],0x7f
 230:	66 21 d8                                        	and    ax,bx
 233:	66 83 e0 7f                                     	and    ax,0x7f
 237:	66 23 47 08                                     	and    ax,WORD PTR [rdi+0x8]
 23b:	66 21 47 08                                     	and    WORD PTR [rdi+0x8],ax
 23f:	66 83 67 08 7f                                  	and    WORD PTR [rdi+0x8],0x7f
 244:	66 09 d8                                        	or     ax,bx
 247:	66 83 c8 7f                                     	or     ax,0x7f
 24b:	66 0b 47 08                                     	or     ax,WORD PTR [rdi+0x8]
 24f:	66 09 47 08                                     	or     WORD PTR [rdi+0x8],ax
 253:	66 83 4f 08 7f                                  	or     WORD PTR [rdi+0x8],0x7f
 258:	66 31 d8                                        	xor    ax,bx
 25b:	66 83 f0 7f                                     	xor    ax,0x7f
 25f:	66 33 47 08                                     	xor    ax,WORD PTR [rdi+0x8]
 263:	66 31 47 08                                     	xor    WORD PTR [rdi+0x8],ax
 267:	66 83 77 08 7f                                  	xor    WORD PTR [rdi+0x8],0x7f
 26c:	66 ff c0                                        	inc    ax
 26f:	66 ff 47 08                                     	inc    WORD PTR [rdi+0x8]
 273:	66 ff c8                                        	dec    ax
 276:	66 ff 4f 08                                     	dec    WORD PTR [rdi+0x8]
 27a:	66 f7 d8                                        	neg    ax
 27d:	66 f7 5f 08                                     	neg    WORD PTR [rdi+0x8]
 281:	66 f7 d0                                        	not    ax
 284:	66 f7 57 08                                     	not    WORD PTR [rdi+0x8]
 288:	66 93                                           	xchg   bx,ax
 28a:	66 c1 e0 00                                     	shl    ax,0x0
 28e:	66 d1 e0                                        	shl    ax,1
 291:	66 c1 e0 07                                     	shl    ax,0x7
 295:	66 c1 e0 08                                     	shl    ax,0x8
 299:	66 c1 e0 0f                                     	shl    ax,0xf
 29d:	66 c1 e0 10                                     	shl    ax,0x10
 2a1:	66 c1 e0 1f                                     	shl    ax,0x1f
 2a5:	66 c1 e0 20                                     	shl    ax,0x20
 2a9:	66 c1 e0 3f                                     	shl    ax,0x3f
 2ad:	66 c1 e0 40                                     	shl    ax,0x40
 2b1:	66 c1 e0 ff                                     	shl    ax,0xff
 2b5:	66 d3 e0                                        	shl    ax,cl
 2b8:	66 c1 e8 00                                     	shr    ax,0x0
 2bc:	66 d1 e8                                        	shr    ax,1
 2bf:	66 c1 e8 07                                     	shr    ax,0x7
 2c3:	66 c1 e8 08                                     	shr    ax,0x8
 2c7:	66 c1 e8 0f                                     	shr    ax,0xf
 2cb:	66 c1 e8 10                                     	shr    ax,0x10
 2cf:	66 c1 e8 1f                                     	shr    ax,0x1f
 2d3:	66 c1 e8 20                                     	shr    ax,0x20
 2d7:	66 c1 e8 3f                                     	shr    ax,0x3f
 2db:	66 c1 e8 40                                     	shr    ax,0x40
 2df:	66 c1 e8 ff                                     	shr    ax,0xff
 2e3:	66 d3 e8                                        	shr    ax,cl
 2e6:	66 c1 f8 00                                     	sar    ax,0x0
 2ea:	66 d1 f8                                        	sar    ax,1
 2ed:	66 c1 f8 07                                     	sar    ax,0x7
 2f1:	66 c1 f8 08                                     	sar    ax,0x8
 2f5:	66 c1 f8 0f                                     	sar    ax,0xf
 2f9:	66 c1 f8 10                                     	sar    ax,0x10
 2fd:	66 c1 f8 1f                                     	sar    ax,0x1f
 301:	66 c1 f8 20                                     	sar    ax,0x20
 305:	66 c1 f8 3f                                     	sar    ax,0x3f
 309:	66 c1 f8 40                                     	sar    ax,0x40
 30d:	66 c1 f8 ff                                     	sar    ax,0xff
 311:	66 d3 f8                                        	sar    ax,cl
 314:	66 c1 c0 00                                     	rol    ax,0x0
 318:	66 d1 c0                                        	rol    ax,1
 31b:	66 c1 c0 07                                     	rol    ax,0x7
 31f:	66 c1 c0 08                                     	rol    ax,0x8
 323:	66 c1 c0 0f                                     	rol    ax,0xf
 327:	66 c1 c0 10                                     	rol    ax,0x10
 32b:	66 c1 c0 1f                                     	rol    ax,0x1f
 32f:	66 c1 c0 20                                     	rol    ax,0x20
 333:	66 c1 c0 3f                                     	rol    ax,0x3f
 337:	66 c1 c0 40                                     	rol    ax,0x40
 33b:	66 c1 c0 ff                                     	rol    ax,0xff
 33f:	66 d3 c0                                        	rol    ax,cl
 342:	66 0f af c3                                     	imul   ax,bx
 346:	66 0f af 47 08                                  	imul   ax,WORD PTR [rdi+0x8]
 34b:	66 6b c3 f9                                     	imul   ax,bx,0xfff9
 34f:	66 6b 47 08 f9                                  	imul   ax,WORD PTR [rdi+0x8],0xfff9
 354:	66 f3 0f b8 c3                                  	popcnt ax,bx
 359:	66 f7 f3                                        	div    bx
 35c:	66 0f a3 d8                                     	bt     ax,bx
 360:	66 0f ba e0 07                                  	bt     ax,0x7
 365:	66 0f ba 67 08 07                               	bt     WORD PTR [rdi+0x8],0x7
 36b:	66 0f 38 f0 47 08                               	movbe  ax,WORD PTR [rdi+0x8]
 371:	66 0f 38 f1 47 08                               	movbe  WORD PTR [rdi+0x8],ax
 377:	66 0f a4 d8 00                                  	shld   ax,bx,0x0
 37c:	66 0f a4 d8 01                                  	shld   ax,bx,0x1
 381:	66 0f a4 d8 07                                  	shld   ax,bx,0x7
 386:	66 0f a4 d8 0f                                  	shld   ax,bx,0xf
 38b:	66 0f ac d8 00                                  	shrd   ax,bx,0x0
 390:	66 0f ac d8 01                                  	shrd   ax,bx,0x1
 395:	66 0f ac d8 07                                  	shrd   ax,bx,0x7
 39a:	66 0f ac d8 0f                                  	shrd   ax,bx,0xf
 39f:	89 d8                                           	mov    eax,ebx
 3a1:	b8 7f 00 00 00                                  	mov    eax,0x7f
 3a6:	89 47 08                                        	mov    DWORD PTR [rdi+0x8],eax
 3a9:	8b 47 08                                        	mov    eax,DWORD PTR [rdi+0x8]
 3ac:	c7 47 08 7f 00 00 00                            	mov    DWORD PTR [rdi+0x8],0x7f
 3b3:	01 d8                                           	add    eax,ebx
 3b5:	83 c0 7f                                        	add    eax,0x7f
 3b8:	01 47 08                                        	add    DWORD PTR [rdi+0x8],eax
 3bb:	83 47 08 7f                                     	add    DWORD PTR [rdi+0x8],0x7f
 3bf:	03 47 08                                        	add    eax,DWORD PTR [rdi+0x8]
 3c2:	11 d8                                           	adc    eax,ebx
 3c4:	83 d0 7f                                        	adc    eax,0x7f
 3c7:	11 47 08                                        	adc    DWORD PTR [rdi+0x8],eax
 3ca:	83 57 08 7f                                     	adc    DWORD PTR [rdi+0x8],0x7f
 3ce:	13 47 08                                        	adc    eax,DWORD PTR [rdi+0x8]
 3d1:	29 d8                                           	sub    eax,ebx
 3d3:	83 e8 7f                                        	sub    eax,0x7f
 3d6:	29 47 08                                        	sub    DWORD PTR [rdi+0x8],eax
 3d9:	83 6f 08 7f                                     	sub    DWORD PTR [rdi+0x8],0x7f
 3dd:	2b 47 08                                        	sub    eax,DWORD PTR [rdi+0x8]
 3e0:	19 d8                                           	sbb    eax,ebx
 3e2:	83 d8 7f                                        	sbb    eax,0x7f
 3e5:	19 47 08                                        	sbb    DWORD PTR [rdi+0x8],eax
 3e8:	83 5f 08 7f                                     	sbb    DWORD PTR [rdi+0x8],0x7f
 3ec:	1b 47 08                                        	sbb    eax,DWORD PTR [rdi+0x8]
 3ef:	39 d8                                           	cmp    eax,ebx
 3f1:	83 f8 7f                                        	cmp    eax,0x7f
 3f4:	39 47 08                                        	cmp    DWORD PTR [rdi+0x8],eax
 3f7:	83 7f 08 7f                                     	cmp    DWORD PTR [rdi+0x8],0x7f
 3fb:	3b 47 08                                        	cmp    eax,DWORD PTR [rdi+0x8]
 3fe:	85 d8                                           	test   eax,ebx
 400:	a9 7f 00 00 00                                  	test   eax,0x7f
 405:	85 47 08                                        	test   DWORD PTR [rdi+0x8],eax
 408:	f7 47 08 7f 00 00 00                            	test   DWORD PTR [rdi+0x8],0x7f
 40f:	21 d8                                           	and    eax,ebx
 411:	83 e0 7f                                        	and    eax,0x7f
 414:	23 47 08                                        	and    eax,DWORD PTR [rdi+0x8]
 417:	21 47 08                                        	and    DWORD PTR [rdi+0x8],eax
 41a:	83 67 08 7f                                     	and    DWORD PTR [rdi+0x8],0x7f
 41e:	09 d8                                           	or     eax,ebx
 420:	83 c8 7f                                        	or     eax,0x7f
 423:	0b 47 08                                        	or     eax,DWORD PTR [rdi+0x8]
 426:	09 47 08                                        	or     DWORD PTR [rdi+0x8],eax
 429:	83 4f 08 7f                                     	or     DWORD PTR [rdi+0x8],0x7f
 42d:	31 d8                                           	xor    eax,ebx
 42f:	83 f0 7f                                        	xor    eax,0x7f
 432:	33 47 08                                        	xor    eax,DWORD PTR [rdi+0x8]
 435:	31 47 08                                        	xor    DWORD PTR [rdi+0x8],eax
 438:	83 77 08 7f                                     	xor    DWORD PTR [rdi+0x8],0x7f
 43c:	ff c0                                           	inc    eax
 43e:	ff 47 08                                        	inc    DWORD PTR [rdi+0x8]
 441:	ff c8                                           	dec    eax
 443:	ff 4f 08                                        	dec    DWORD PTR [rdi+0x8]
 446:	f7 d8                                           	neg    eax
 448:	f7 5f 08                                        	neg    DWORD PTR [rdi+0x8]
 44b:	f7 d0                                           	not    eax
 44d:	f7 57 08                                        	not    DWORD PTR [rdi+0x8]
 450:	93                                              	xchg   ebx,eax
 451:	c1 e0 00                                        	shl    eax,0x0
 454:	d1 e0                                           	shl    eax,1
 456:	c1 e0 07                                        	shl    eax,0x7
 459:	c1 e0 08                                        	shl    eax,0x8
 45c:	c1 e0 0f                                        	shl    eax,0xf
 45f:	c1 e0 10                                        	shl    eax,0x10
 462:	c1 e0 1f                                        	shl    eax,0x1f
 465:	c1 e0 20                                        	shl    eax,0x20
 468:	c1 e0 3f                                        	shl    eax,0x3f
 46b:	c1 e0 40                                        	shl    eax,0x40
 46e:	c1 e0 ff                                        	shl    eax,0xff
 471:	d3 e0                                           	shl    eax,cl
 473:	c1 e8 00                                        	shr    eax,0x0
 476:	d1 e8                                           	shr    eax,1
 478:	c1 e8 07                                        	shr    eax,0x7
 47b:	c1 e8 08                                        	shr    eax,0x8
 47e:	c1 e8 0f                                        	shr    eax,0xf
 481:	c1 e8 10                                        	shr    eax,0x10
 484:	c1 e8 1f                                        	shr    eax,0x1f
 487:	c1 e8 20                                        	shr    eax,0x20
 48a:	c1 e8 3f                                        	shr    eax,0x3f
 48d:	c1 e8 40                                        	shr    eax,0x40
 490:	c1 e8 ff                                        	shr    eax,0xff
 493:	d3 e8                                           	shr    eax,cl
 495:	c1 f8 00                                        	sar    eax,0x0
 498:	d1 f8                                           	sar    eax,1
 49a:	c1 f8 07                                        	sar    eax,0x7
 49d:	c1 f8 08                                        	sar    eax,0x8
 4a0:	c1 f8 0f                                        	sar    eax,0xf
 4a3:	c1 f8 10                                        	sar    eax,0x10
 4a6:	c1 f8 1f                                        	sar    eax,0x1f
 4a9:	c1 f8 20                                        	sar    eax,0x20
 4ac:	c1 f8 3f                                        	sar    eax,0x3f
 4af:	c1 f8 40                                        	sar    eax,0x40
 4b2:	c1 f8 ff                                        	sar    eax,0xff
 4b5:	d3 f8                                           	sar    eax,cl
 4b7:	c1 c0 00                                        	rol    eax,0x0
 4ba:	d1 c0                                           	rol    eax,1
 4bc:	c1 c0 07                                        	rol    eax,0x7
 4bf:	c1 c0 08                                        	rol    eax,0x8
 4c2:	c1 c0 0f                                        	rol    eax,0xf
 4c5:	c1 c0 10                                        	rol    eax,0x10
 4c8:	c1 c0 1f                                        	rol    eax,0x1f
 4cb:	c1 c0 20                                        	rol    eax,0x20
 4ce:	c1 c0 3f                                        	rol    eax,0x3f
 4d1:	c1 c0 40                                        	rol    eax,0x40
 4d4:	c1 c0 ff                                        	rol    eax,0xff
 4d7:	d3 c0                                           	rol    eax,cl
 4d9:	0f af c3                                        	imul   eax,ebx
 4dc:	0f af 47 08                                     	imul   eax,DWORD PTR [rdi+0x8]
 4e0:	6b c3 f9                                        	imul   eax,ebx,0xfffffff9
 4e3:	6b 47 08 f9                                     	imul   eax,DWORD PTR [rdi+0x8],0xfffffff9
 4e7:	f3 0f b8 c3                                     	popcnt eax,ebx
 4eb:	f7 f3                                           	div    ebx
 4ed:	0f a3 d8                                        	bt     eax,ebx
 4f0:	0f ba e0 07                                     	bt     eax,0x7
 4f4:	0f ba 67 08 07                                  	bt     DWORD PTR [rdi+0x8],0x7
 4f9:	0f 38 f0 47 08                                  	movbe  eax,DWORD PTR [rdi+0x8]
 4fe:	0f 38 f1 47 08                                  	movbe  DWORD PTR [rdi+0x8],eax
 503:	0f a4 d8 00                                     	shld   eax,ebx,0x0
 507:	0f a4 d8 01                                     	shld   eax,ebx,0x1
 50b:	0f a4 d8 07                                     	shld   eax,ebx,0x7
 50f:	0f a4 d8 0f                                     	shld   eax,ebx,0xf
 513:	0f ac d8 00                                     	shrd   eax,ebx,0x0
 517:	0f ac d8 01                                     	shrd   eax,ebx,0x1
 51b:	0f ac d8 07                                     	shrd   eax,ebx,0x7
 51f:	0f ac d8 0f                                     	shrd   eax,ebx,0xf
 523:	8d 44 9f f9                                     	lea    eax,[rdi+rbx*4-0x7]
 527:	0f c8                                           	bswap  eax
 529:	c4 e2 60 f2 c1                                  	andn   eax,ebx,ecx
 52e:	c4 e2 60 f2 47 08                               	andn   eax,ebx,DWORD PTR [rdi+0x8]
 534:	c4 e2 70 f5 c3                                  	bzhi   eax,ebx,ecx
 539:	c4 e2 70 f5 47 08                               	bzhi   eax,DWORD PTR [rdi+0x8],ecx
 53f:	c4 e2 63 f6 c1                                  	mulx   eax,ebx,ecx
 544:	c4 e2 71 f7 c3                                  	shlx   eax,ebx,ecx
 549:	c4 e2 71 f7 47 08                               	shlx   eax,DWORD PTR [rdi+0x8],ecx
 54f:	c4 e2 73 f7 c3                                  	shrx   eax,ebx,ecx
 554:	c4 e2 73 f7 47 08                               	shrx   eax,DWORD PTR [rdi+0x8],ecx
 55a:	c4 e2 72 f7 c3                                  	sarx   eax,ebx,ecx
 55f:	c4 e2 72 f7 47 08                               	sarx   eax,DWORD PTR [rdi+0x8],ecx
 565:	c4 e3 7b f0 c3 07                               	rorx   eax,ebx,0x7
 56b:	c4 e3 7b f0 47 08 07                            	rorx   eax,DWORD PTR [rdi+0x8],0x7
 572:	48 89 d8                                        	mov    rax,rbx
 575:	48 c7 c0 7f 00 00 00                            	mov    rax,0x7f
 57c:	48 89 47 08                                     	mov    QWORD PTR [rdi+0x8],rax
 580:	48 8b 47 08                                     	mov    rax,QWORD PTR [rdi+0x8]
 584:	48 c7 47 08 7f 00 00 00                         	mov    QWORD PTR [rdi+0x8],0x7f
 58c:	48 01 d8                                        	add    rax,rbx
 58f:	48 83 c0 7f                                     	add    rax,0x7f
 593:	48 01 47 08                                     	add    QWORD PTR [rdi+0x8],rax
 597:	48 83 47 08 7f                                  	add    QWORD PTR [rdi+0x8],0x7f
 59c:	48 03 47 08                                     	add    rax,QWORD PTR [rdi+0x8]
 5a0:	48 11 d8                                        	adc    rax,rbx
 5a3:	48 83 d0 7f                                     	adc    rax,0x7f
 5a7:	48 11 47 08                                     	adc    QWORD PTR [rdi+0x8],rax
 5ab:	48 83 57 08 7f                                  	adc    QWORD PTR [rdi+0x8],0x7f
 5b0:	48 13 47 08                                     	adc    rax,QWORD PTR [rdi+0x8]
 5b4:	48 29 d8                                        	sub    rax,rbx
 5b7:	48 83 e8 7f                                     	sub    rax,0x7f
 5bb:	48 29 47 08                                     	sub    QWORD PTR [rdi+0x8],rax
 5bf:	48 83 6f 08 7f                                  	sub    QWORD PTR [rdi+0x8],0x7f
 5c4:	48 2b 47 08                                     	sub    rax,QWORD PTR [rdi+0x8]
 5c8:	48 19 d8                                        	sbb    rax,rbx
 5cb:	48 83 d8 7f                                     	sbb    rax,0x7f
 5cf:	48 19 47 08                                     	sbb    QWORD PTR [rdi+0x8],rax
 5d3:	48 83 5f 08 7f                                  	sbb    QWORD PTR [rdi+0x8],0x7f
 5d8:	48 1b 47 08                                     	sbb    rax,QWORD PTR [rdi+0x8]
 5dc:	48 39 d8                                        	cmp    rax,rbx
 5df:	48 83 f8 7f                                     	cmp    rax,0x7f
 5e3:	48 39 47 08                                     	cmp    QWORD PTR [rdi+0x8],rax
 5e7:	48 83 7f 08 7f                                  	cmp    QWORD PTR [rdi+0x8],0x7f
 5ec:	48 3b 47 08                                     	cmp    rax,QWORD PTR [rdi+0x8]
 5f0:	48 85 d8                                        	test   rax,rbx
 5f3:	48 a9 7f 00 00 00                               	test   rax,0x7f
 5f9:	48 85 47 08                                     	test   QWORD PTR [rdi+0x8],rax
 5fd:	48 f7 47 08 7f 00 00 00                         	test   QWORD PTR [rdi+0x8],0x7f
 605:	48 21 d8                                        	and    rax,rbx
 608:	48 83 e0 7f                                     	and    rax,0x7f
 60c:	48 23 47 08                                     	and    rax,QWORD PTR [rdi+0x8]
 610:	48 21 47 08                                     	and    QWORD PTR [rdi+0x8],rax
 614:	48 83 67 08 7f                                  	and    QWORD PTR [rdi+0x8],0x7f
 619:	48 09 d8                                        	or     rax,rbx
 61c:	48 83 c8 7f                                     	or     rax,0x7f
 620:	48 0b 47 08                                     	or     rax,QWORD PTR [rdi+0x8]
 624:	48 09 47 08                                     	or     QWORD PTR [rdi+0x8],rax
 628:	48 83 4f 08 7f                                  	or     QWORD PTR [rdi+0x8],0x7f
 62d:	48 31 d8                                        	xor    rax,rbx
 630:	48 83 f0 7f                                     	xor    rax,0x7f
 634:	48 33 47 08                                     	xor    rax,QWORD PTR [rdi+0x8]
 638:	48 31 47 08                                     	xor    QWORD PTR [rdi+0x8],rax
 63c:	48 83 77 08 7f                                  	xor    QWORD PTR [rdi+0x8],0x7f
 641:	48 ff c0                                        	inc    rax
 644:	48 ff 47 08                                     	inc    QWORD PTR [rdi+0x8]
 648:	48 ff c8                                        	dec    rax
 64b:	48 ff 4f 08                                     	dec    QWORD PTR [rdi+0x8]
 64f:	48 f7 d8                                        	neg    rax
 652:	48 f7 5f 08                                     	neg    QWORD PTR [rdi+0x8]
 656:	48 f7 d0                                        	not    rax
 659:	48 f7 57 08                                     	not    QWORD PTR [rdi+0x8]
 65d:	48 93                                           	xchg   rbx,rax
 65f:	48 c1 e0 00                                     	shl    rax,0x0
 663:	48 d1 e0                                        	shl    rax,1
 666:	48 c1 e0 07                                     	shl    rax,0x7
 66a:	48 c1 e0 08                                     	shl    rax,0x8
 66e:	48 c1 e0 0f                                     	shl    rax,0xf
 672:	48 c1 e0 10                                     	shl    rax,0x10
 676:	48 c1 e0 1f                                     	shl    rax,0x1f
 67a:	48 c1 e0 20                                     	shl    rax,0x20
 67e:	48 c1 e0 3f                                     	shl    rax,0x3f
 682:	48 c1 e0 40                                     	shl    rax,0x40
 686:	48 c1 e0 ff                                     	shl    rax,0xff
 68a:	48 d3 e0                                        	shl    rax,cl
 68d:	48 c1 e8 00                                     	shr    rax,0x0
 691:	48 d1 e8                                        	shr    rax,1
 694:	48 c1 e8 07                                     	shr    rax,0x7
 698:	48 c1 e8 08                                     	shr    rax,0x8
 69c:	48 c1 e8 0f                                     	shr    rax,0xf
 6a0:	48 c1 e8 10                                     	shr    rax,0x10
 6a4:	48 c1 e8 1f                                     	shr    rax,0x1f
 6a8:	48 c1 e8 20                                     	shr    rax,0x20
 6ac:	48 c1 e8 3f                                     	shr    rax,0x3f
 6b0:	48 c1 e8 40                                     	shr    rax,0x40
 6b4:	48 c1 e8 ff                                     	shr    rax,0xff
 6b8:	48 d3 e8                                        	shr    rax,cl
 6bb:	48 c1 f8 00                                     	sar    rax,0x0
 6bf:	48 d1 f8                                        	sar    rax,1
 6c2:	48 c1 f8 07                                     	sar    rax,0x7
 6c6:	48 c1 f8 08                                     	sar    rax,0x8
 6ca:	48 c1 f8 0f                                     	sar    rax,0xf
 6ce:	48 c1 f8 10                                     	sar    rax,0x10
 6d2:	48 c1 f8 1f                                     	sar    rax,0x1f
 6d6:	48 c1 f8 20                                     	sar    rax,0x20
 6da:	48 c1 f8 3f                                     	sar    rax,0x3f
 6de:	48 c1 f8 40                                     	sar    rax,0x40
 6e2:	48 c1 f8 ff                                     	sar    rax,0xff
 6e6:	48 d3 f8                                        	sar    rax,cl
 6e9:	48 c1 c0 00                                     	rol    rax,0x0
 6ed:	48 d1 c0                                        	rol    rax,1
 6f0:	48 c1 c0 07                                     	rol    rax,0x7
 6f4:	48 c1 c0 08                                     	rol    rax,0x8
 6f8:	48 c1 c0 0f                                     	rol    rax,0xf
 6fc:	48 c1 c0 10                                     	rol    rax,0x10
 700:	48 c1 c0 1f                                     	rol    rax,0x1f
 704:	48 c1 c0 20                                     	rol    rax,0x20
 708:	48 c1 c0 3f                                     	rol    rax,0x3f
 70c:	48 c1 c0 40                                     	rol    rax,0x40
 710:	48 c1 c0 ff                                     	rol    rax,0xff
 714:	48 d3 c0                                        	rol    rax,cl
 717:	48 0f af c3                                     	imul   rax,rbx
 71b:	48 0f af 47 08                                  	imul   rax,QWORD PTR [rdi+0x8]
 720:	48 6b c3 f9                                     	imul   rax,rbx,0xfffffffffffffff9
 724:	48 6b 47 08 f9                                  	imul   rax,QWORD PTR [rdi+0x8],0xfffffffffffffff9
 729:	f3 48 0f b8 c3                                  	popcnt rax,rbx
 72e:	48 f7 f3                                        	div    rbx
 731:	48 0f a3 d8                                     	bt     rax,rbx
 735:	48 0f ba e0 07                                  	bt     rax,0x7
 73a:	48 0f ba 67 08 07                               	bt     QWORD PTR [rdi+0x8],0x7
 740:	48 0f 38 f0 47 08                               	movbe  rax,QWORD PTR [rdi+0x8]
 746:	48 0f 38 f1 47 08                               	movbe  QWORD PTR [rdi+0x8],rax
 74c:	48 0f a4 d8 00                                  	shld   rax,rbx,0x0
 751:	48 0f a4 d8 01                                  	shld   rax,rbx,0x1
 756:	48 0f a4 d8 07                                  	shld   rax,rbx,0x7
 75b:	48 0f a4 d8 0f                                  	shld   rax,rbx,0xf
 760:	48 0f ac d8 00                                  	shrd   rax,rbx,0x0
 765:	48 0f ac d8 01                                  	shrd   rax,rbx,0x1
 76a:	48 0f ac d8 07                                  	shrd   rax,rbx,0x7
 76f:	48 0f ac d8 0f                                  	shrd   rax,rbx,0xf
 774:	48 8d 44 9f f9                                  	lea    rax,[rdi+rbx*4-0x7]
 779:	48 0f c8                                        	bswap  rax
 77c:	c4 e2 e0 f2 c1                                  	andn   rax,rbx,rcx
 781:	c4 e2 e0 f2 47 08                               	andn   rax,rbx,QWORD PTR [rdi+0x8]
 787:	c4 e2 f0 f5 c3                                  	bzhi   rax,rbx,rcx
 78c:	c4 e2 f0 f5 47 08                               	bzhi   rax,QWORD PTR [rdi+0x8],rcx
 792:	c4 e2 e3 f6 c1                                  	mulx   rax,rbx,rcx
 797:	c4 e2 f1 f7 c3                                  	shlx   rax,rbx,rcx
 79c:	c4 e2 f1 f7 47 08                               	shlx   rax,QWORD PTR [rdi+0x8],rcx
 7a2:	c4 e2 f3 f7 c3                                  	shrx   rax,rbx,rcx
 7a7:	c4 e2 f3 f7 47 08                               	shrx   rax,QWORD PTR [rdi+0x8],rcx
 7ad:	c4 e2 f2 f7 c3                                  	sarx   rax,rbx,rcx
 7b2:	c4 e2 f2 f7 47 08                               	sarx   rax,QWORD PTR [rdi+0x8],rcx
 7b8:	c4 e3 fb f0 c3 07                               	rorx   rax,rbx,0x7
 7be:	c4 e3 fb f0 47 08 07                            	rorx   rax,QWORD PTR [rdi+0x8],0x7
 7c5:	88 fc                                           	mov    ah,bh
 7c7:	b4 7f                                           	mov    ah,0x7f
 7c9:	88 67 08                                        	mov    BYTE PTR [rdi+0x8],ah
 7cc:	00 fc                                           	add    ah,bh
 7ce:	80 c4 7f                                        	add    ah,0x7f
 7d1:	10 fc                                           	adc    ah,bh
 7d3:	80 d4 7f                                        	adc    ah,0x7f
 7d6:	28 fc                                           	sub    ah,bh
 7d8:	80 ec 7f                                        	sub    ah,0x7f
 7db:	18 fc                                           	sbb    ah,bh
 7dd:	80 dc 7f                                        	sbb    ah,0x7f
 7e0:	38 fc                                           	cmp    ah,bh
 7e2:	80 fc 7f                                        	cmp    ah,0x7f
 7e5:	84 fc                                           	test   ah,bh
 7e7:	f6 c4 7f                                        	test   ah,0x7f
 7ea:	fe c4                                           	inc    ah
 7ec:	fe cc                                           	dec    ah
 7ee:	f6 dc                                           	neg    ah
 7f0:	f6 d4                                           	not    ah
 7f2:	66 0f b6 c3                                     	movzx  ax,bl
 7f6:	66 0f b6 47 08                                  	movzx  ax,BYTE PTR [rdi+0x8]
 7fb:	66 0f be c3                                     	movsx  ax,bl
 7ff:	66 0f be 47 08                                  	movsx  ax,BYTE PTR [rdi+0x8]
 804:	0f b6 c3                                        	movzx  eax,bl
 807:	0f b6 47 08                                     	movzx  eax,BYTE PTR [rdi+0x8]
 80b:	0f be c3                                        	movsx  eax,bl
 80e:	0f be 47 08                                     	movsx  eax,BYTE PTR [rdi+0x8]
 812:	0f b7 c3                                        	movzx  eax,bx
 815:	0f b7 47 08                                     	movzx  eax,WORD PTR [rdi+0x8]
 819:	0f bf c3                                        	movsx  eax,bx
 81c:	0f bf 47 08                                     	movsx  eax,WORD PTR [rdi+0x8]
 820:	48 0f b6 c3                                     	movzx  rax,bl
 824:	48 0f b6 47 08                                  	movzx  rax,BYTE PTR [rdi+0x8]
 829:	48 0f be c3                                     	movsx  rax,bl
 82d:	48 0f be 47 08                                  	movsx  rax,BYTE PTR [rdi+0x8]
 832:	48 0f b7 c3                                     	movzx  rax,bx
 836:	48 0f b7 47 08                                  	movzx  rax,WORD PTR [rdi+0x8]
 83b:	48 0f bf c3                                     	movsx  rax,bx
 83f:	48 0f bf 47 08                                  	movsx  rax,WORD PTR [rdi+0x8]
 844:	48 63 c3                                        	movsxd rax,ebx
 847:	48 63 47 08                                     	movsxd rax,DWORD PTR [rdi+0x8]
 84b:	0f 97 c0                                        	seta   al
 84e:	0f 97 c4                                        	seta   ah
 851:	0f 97 47 08                                     	seta   BYTE PTR [rdi+0x8]
 855:	0f 93 c0                                        	setae  al
 858:	0f 93 c4                                        	setae  ah
 85b:	0f 93 47 08                                     	setae  BYTE PTR [rdi+0x8]
 85f:	0f 92 c0                                        	setb   al
 862:	0f 92 c4                                        	setb   ah
 865:	0f 92 47 08                                     	setb   BYTE PTR [rdi+0x8]
 869:	0f 96 c0                                        	setbe  al
 86c:	0f 96 c4                                        	setbe  ah
 86f:	0f 96 47 08                                     	setbe  BYTE PTR [rdi+0x8]
 873:	0f 94 c0                                        	sete   al
 876:	0f 94 c4                                        	sete   ah
 879:	0f 94 47 08                                     	sete   BYTE PTR [rdi+0x8]
 87d:	0f 9f c0                                        	setg   al
 880:	0f 9f c4                                        	setg   ah
 883:	0f 9f 47 08                                     	setg   BYTE PTR [rdi+0x8]
 887:	0f 9d c0                                        	setge  al
 88a:	0f 9d c4                                        	setge  ah
 88d:	0f 9d 47 08                                     	setge  BYTE PTR [rdi+0x8]
 891:	0f 9c c0                                        	setl   al
 894:	0f 9c c4                                        	setl   ah
 897:	0f 9c 47 08                                     	setl   BYTE PTR [rdi+0x8]
 89b:	0f 9e c0                                        	setle  al
 89e:	0f 9e c4                                        	setle  ah
 8a1:	0f 9e 47 08                                     	setle  BYTE PTR [rdi+0x8]
 8a5:	0f 95 c0                                        	setne  al
 8a8:	0f 95 c4                                        	setne  ah
 8ab:	0f 95 47 08                                     	setne  BYTE PTR [rdi+0x8]
 8af:	0f 99 c0                                        	setns  al
 8b2:	0f 99 c4                                        	setns  ah
 8b5:	0f 99 47 08                                     	setns  BYTE PTR [rdi+0x8]
 8b9:	0f 98 c0                                        	sets   al
 8bc:	0f 98 c4                                        	sets   ah
 8bf:	0f 98 47 08                                     	sets   BYTE PTR [rdi+0x8]
 8c3:	66 0f 47 c3                                     	cmova  ax,bx
 8c7:	66 0f 47 47 08                                  	cmova  ax,WORD PTR [rdi+0x8]
 8cc:	0f 47 c3                                        	cmova  eax,ebx
 8cf:	0f 47 47 08                                     	cmova  eax,DWORD PTR [rdi+0x8]
 8d3:	48 0f 47 c3                                     	cmova  rax,rbx
 8d7:	48 0f 47 47 08                                  	cmova  rax,QWORD PTR [rdi+0x8]
 8dc:	66 0f 42 c3                                     	cmovb  ax,bx
 8e0:	66 0f 42 47 08                                  	cmovb  ax,WORD PTR [rdi+0x8]
 8e5:	0f 42 c3                                        	cmovb  eax,ebx
 8e8:	0f 42 47 08                                     	cmovb  eax,DWORD PTR [rdi+0x8]
 8ec:	48 0f 42 c3                                     	cmovb  rax,rbx
 8f0:	48 0f 42 47 08                                  	cmovb  rax,QWORD PTR [rdi+0x8]
 8f5:	66 0f 46 c3                                     	cmovbe ax,bx
 8f9:	66 0f 46 47 08                                  	cmovbe ax,WORD PTR [rdi+0x8]
 8fe:	0f 46 c3                                        	cmovbe eax,ebx
 901:	0f 46 47 08                                     	cmovbe eax,DWORD PTR [rdi+0x8]
 905:	48 0f 46 c3                                     	cmovbe rax,rbx
 909:	48 0f 46 47 08                                  	cmovbe rax,QWORD PTR [rdi+0x8]
 90e:	66 0f 44 c3                                     	cmove  ax,bx
 912:	66 0f 44 47 08                                  	cmove  ax,WORD PTR [rdi+0x8]
 917:	0f 44 c3                                        	cmove  eax,ebx
 91a:	0f 44 47 08                                     	cmove  eax,DWORD PTR [rdi+0x8]
 91e:	48 0f 44 c3                                     	cmove  rax,rbx
 922:	48 0f 44 47 08                                  	cmove  rax,QWORD PTR [rdi+0x8]
 927:	66 0f 4f c3                                     	cmovg  ax,bx
 92b:	66 0f 4f 47 08                                  	cmovg  ax,WORD PTR [rdi+0x8]
 930:	0f 4f c3                                        	cmovg  eax,ebx
 933:	0f 4f 47 08                                     	cmovg  eax,DWORD PTR [rdi+0x8]
 937:	48 0f 4f c3                                     	cmovg  rax,rbx
 93b:	48 0f 4f 47 08                                  	cmovg  rax,QWORD PTR [rdi+0x8]
 940:	66 0f 4d c3                                     	cmovge ax,bx
 944:	66 0f 4d 47 08                                  	cmovge ax,WORD PTR [rdi+0x8]
 949:	0f 4d c3                                        	cmovge eax,ebx
 94c:	0f 4d 47 08                                     	cmovge eax,DWORD PTR [rdi+0x8]
 950:	48 0f 4d c3                                     	cmovge rax,rbx
 954:	48 0f 4d 47 08                                  	cmovge rax,QWORD PTR [rdi+0x8]
 959:	66 0f 43 c3                                     	cmovae ax,bx
 95d:	66 0f 43 47 08                                  	cmovae ax,WORD PTR [rdi+0x8]
 962:	0f 43 c3                                        	cmovae eax,ebx
 965:	0f 43 47 08                                     	cmovae eax,DWORD PTR [rdi+0x8]
 969:	48 0f 43 c3                                     	cmovae rax,rbx
 96d:	48 0f 43 47 08                                  	cmovae rax,QWORD PTR [rdi+0x8]
 972:	66 0f 4c c3                                     	cmovl  ax,bx
 976:	66 0f 4c 47 08                                  	cmovl  ax,WORD PTR [rdi+0x8]
 97b:	0f 4c c3                                        	cmovl  eax,ebx
 97e:	0f 4c 47 08                                     	cmovl  eax,DWORD PTR [rdi+0x8]
 982:	48 0f 4c c3                                     	cmovl  rax,rbx
 986:	48 0f 4c 47 08                                  	cmovl  rax,QWORD PTR [rdi+0x8]
 98b:	66 0f 4e c3                                     	cmovle ax,bx
 98f:	66 0f 4e 47 08                                  	cmovle ax,WORD PTR [rdi+0x8]
 994:	0f 4e c3                                        	cmovle eax,ebx
 997:	0f 4e 47 08                                     	cmovle eax,DWORD PTR [rdi+0x8]
 99b:	48 0f 4e c3                                     	cmovle rax,rbx
 99f:	48 0f 4e 47 08                                  	cmovle rax,QWORD PTR [rdi+0x8]
 9a4:	66 0f 45 c3                                     	cmovne ax,bx
 9a8:	66 0f 45 47 08                                  	cmovne ax,WORD PTR [rdi+0x8]
 9ad:	0f 45 c3                                        	cmovne eax,ebx
 9b0:	0f 45 47 08                                     	cmovne eax,DWORD PTR [rdi+0x8]
 9b4:	48 0f 45 c3                                     	cmovne rax,rbx
 9b8:	48 0f 45 47 08                                  	cmovne rax,QWORD PTR [rdi+0x8]
 9bd:	66 0f 49 c3                                     	cmovns ax,bx
 9c1:	66 0f 49 47 08                                  	cmovns ax,WORD PTR [rdi+0x8]
 9c6:	0f 49 c3                                        	cmovns eax,ebx
 9c9:	0f 49 47 08                                     	cmovns eax,DWORD PTR [rdi+0x8]
 9cd:	48 0f 49 c3                                     	cmovns rax,rbx
 9d1:	48 0f 49 47 08                                  	cmovns rax,QWORD PTR [rdi+0x8]
 9d6:	66 0f 48 c3                                     	cmovs  ax,bx
 9da:	66 0f 48 47 08                                  	cmovs  ax,WORD PTR [rdi+0x8]
 9df:	0f 48 c3                                        	cmovs  eax,ebx
 9e2:	0f 48 47 08                                     	cmovs  eax,DWORD PTR [rdi+0x8]
 9e6:	48 0f 48 c3                                     	cmovs  rax,rbx
 9ea:	48 0f 48 47 08                                  	cmovs  rax,QWORD PTR [rdi+0x8]
