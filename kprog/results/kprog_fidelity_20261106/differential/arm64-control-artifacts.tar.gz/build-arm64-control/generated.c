#include "../driver.h"
#include <stdlib.h>
#define ARM64_SIM_ENABLE_STACK 1
#define ARM64_SIM_RET_CASES_10000e8 
#define ARM64_SIM_RET_CASES_10010ec 
#define ARM64_SIM_RET_CASES_10020e8 
#define ARM64_SIM_RET_CASES_10030ec 
#define ARM64_SIM_RET_CASES_10040e8 
#define ARM64_SIM_RET_CASES_10050ec 
#define ARM64_SIM_RET_CASES_10060e8 
#define ARM64_SIM_RET_CASES_10070ec 
#define ARM64_SIM_RET_CASES_10080e8 
#define ARM64_SIM_RET_CASES_10090ec 
#define ARM64_SIM_RET_CASES_100a0e8 
#define ARM64_SIM_RET_CASES_100b0ec 
#define ARM64_SIM_RET_CASES_100c0e8 
#define ARM64_SIM_RET_CASES_100d0ec 
#define ARM64_SIM_RET_CASES_100e0e8 
#define ARM64_SIM_RET_CASES_100f0ec 
#define ARM64_SIM_RET_CASES_10100e8 
#define ARM64_SIM_RET_CASES_10110ec 
#define ARM64_SIM_RET_CASES_10120e8 
#define ARM64_SIM_RET_CASES_10130ec 
#define ARM64_SIM_RET_CASES_10140e8 
#define ARM64_SIM_RET_CASES_10150ec 
#define ARM64_SIM_RET_CASES_10160e8 
#define ARM64_SIM_RET_CASES_10170ec 
#define ARM64_SIM_RET_CASES_10180e8 
#define ARM64_SIM_RET_CASES_10190ec 
#define ARM64_SIM_RET_CASES_101a0e8 
#define ARM64_SIM_RET_CASES_101b0ec 
#define ARM64_SIM_RET_CASES_101c0e8 
#define ARM64_SIM_RET_CASES_101d0ec 
#define ARM64_SIM_RET_CASES_101e0e8 
#define ARM64_SIM_RET_CASES_101f0ec 
#define ARM64_SIM_RET_CASES_10200e8 
#define ARM64_SIM_RET_CASES_10210ec 
#define ARM64_SIM_RET_CASES_10220e8 
#define ARM64_SIM_RET_CASES_10230ec 
#define ARM64_SIM_RET_CASES_10240e8 
#define ARM64_SIM_RET_CASES_10250ec 
#define ARM64_SIM_RET_CASES_10260e8 
#define ARM64_SIM_RET_CASES_10270ec 
#define ARM64_SIM_RET_CASES_10280e8 
#define ARM64_SIM_RET_CASES_10290ec 
#define ARM64_SIM_RET_CASES_102a0e8 
#define ARM64_SIM_RET_CASES_102b0ec 
#define ARM64_SIM_RET_CASES_102c0e8 
#define ARM64_SIM_RET_CASES_102d0ec 
#define ARM64_SIM_RET_CASES_102e0e8 
#define ARM64_SIM_RET_CASES_102f0ec 
#define ARM64_SIM_RET_CASES_10300e8 
#define ARM64_SIM_RET_CASES_10310ec 
#define ARM64_SIM_RET_CASES_10320e8 
#define ARM64_SIM_RET_CASES_10330ec 
#define ARM64_SIM_RET_CASES_10340e8 
#define ARM64_SIM_RET_CASES_10350ec 
#define ARM64_SIM_RET_CASES_10360e8 
#define ARM64_SIM_RET_CASES_10370ec 
#define ARM64_SIM_RET_CASES_10380e8 
#define ARM64_SIM_RET_CASES_10390ec 
#define ARM64_SIM_RET_CASES_103a0e8 
#define ARM64_SIM_RET_CASES_103b0ec 
#define ARM64_SIM_RET_CASES_103c0e8 
#define ARM64_SIM_RET_CASES_103d0ec 
#define ARM64_SIM_RET_CASES_103e0e8 
#define ARM64_SIM_RET_CASES_103f0ec 
#define ARM64_SIM_RET_CASES_10400ec 
#define ARM64_SIM_RET_CASES_10410ec 
#define ARM64_SIM_RET_CASES_10420e4 
#define ARM64_SIM_RET_CASES_10420f8 
#define ARM64_SIM_RET_CASES_10430e0 case 0x10430d8ULL: goto arm64_l_10430d8;
#define ARM64_SIM_RET_CASES_10430e4 
#define ARM64_SIM_RET_CASES_10440e4 case 0x10440d8ULL: goto arm64_l_10440d8;
#define ARM64_SIM_RET_CASES_10440e8 
#define ARM64_SIM_RET_CASES_10450e4 case 0x10450dcULL: goto arm64_l_10450dc;
#define ARM64_SIM_RET_CASES_10450e8 
#define ARM64_SIM_RET_CASES_10460e8 case 0x10460d8ULL: goto arm64_l_10460d8;
#define ARM64_SIM_RET_CASES_10460f0 case 0x10460e4ULL: goto arm64_l_10460e4;
#define ARM64_SIM_RET_CASES_10460f4 
#define ARM64_SIM_RET_CASES_10470ec case 0x10470d8ULL: goto arm64_l_10470d8;
#define ARM64_SIM_RET_CASES_10470f4 case 0x10470e8ULL: goto arm64_l_10470e8;
#define ARM64_SIM_RET_CASES_10470f8 
#define ARM64_SIM_RET_CASES_10480e0 
#define ARM64_SIM_RET_CASES_10490e0 
#include "/workspaces/repository/kprog/fidelity/build-arm64-control/snapshot/kprog/arm64/arm64_sim_local_bpf.h"
static void arm64_sim_unsupported_opcode(void) { abort(); }
#undef ARM64_SIM_RET
#define ARM64_SIM_RET() goto observed
extern void native_0(struct state *);
extern unsigned char native_pc_0,native_next_0;
static void sim_0(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10000d4:
	/* 0x10000d4: b.eq 10000e0 <native_pc_0+0xc> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x10000d4, 0x10000e0, arm64_l_10000e0);
arm64_l_10000d8:
	/* 0x10000d8: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10000dc:
	/* 0x10000dc: b 10000e8 <outer_done_0> */
	ARM64_SIM_A64_JMP(0x10000dc, 0x10000e8, arm64_l_10000e8);
arm64_l_10000e0:
	/* 0x10000e0: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10000e4:
	/* 0x10000e4: b 10000e8 <outer_done_0> */
	ARM64_SIM_A64_JMP(0x10000e4, 0x10000e8, arm64_l_10000e8);
arm64_l_10000e8:
	/* 0x10000e8: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10000e8);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_1(struct state *);
extern unsigned char native_pc_1,native_next_1;
static void sim_1(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10010d4:
	/* 0x10010d4: b 10010e0 <native_pc_1+0xc> */
	ARM64_SIM_A64_JMP(0x10010d4, 0x10010e0, arm64_l_10010e0);
arm64_l_10010d8:
	/* 0x10010d8: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10010dc:
	/* 0x10010dc: b 10010ec <outer_done_1> */
	ARM64_SIM_A64_JMP(0x10010dc, 0x10010ec, arm64_l_10010ec);
arm64_l_10010e0:
	/* 0x10010e0: b.eq 10010d8 <native_pc_1+0x4> */
	ARM64_SIM_A64_JCC(ARM64_COND_EQ, 0x10010e0, 0x10010d8, arm64_l_10010d8);
arm64_l_10010e4:
	/* 0x10010e4: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10010e8:
	/* 0x10010e8: b 10010ec <outer_done_1> */
	ARM64_SIM_A64_JMP(0x10010e8, 0x10010ec, arm64_l_10010ec);
arm64_l_10010ec:
	/* 0x10010ec: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10010ec);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_2(struct state *);
extern unsigned char native_pc_2,native_next_2;
static void sim_2(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10020d4:
	/* 0x10020d4: b.ne 10020e0 <native_pc_2+0xc> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x10020d4, 0x10020e0, arm64_l_10020e0);
arm64_l_10020d8:
	/* 0x10020d8: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10020dc:
	/* 0x10020dc: b 10020e8 <outer_done_2> */
	ARM64_SIM_A64_JMP(0x10020dc, 0x10020e8, arm64_l_10020e8);
arm64_l_10020e0:
	/* 0x10020e0: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10020e4:
	/* 0x10020e4: b 10020e8 <outer_done_2> */
	ARM64_SIM_A64_JMP(0x10020e4, 0x10020e8, arm64_l_10020e8);
arm64_l_10020e8:
	/* 0x10020e8: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10020e8);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_3(struct state *);
extern unsigned char native_pc_3,native_next_3;
static void sim_3(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10030d4:
	/* 0x10030d4: b 10030e0 <native_pc_3+0xc> */
	ARM64_SIM_A64_JMP(0x10030d4, 0x10030e0, arm64_l_10030e0);
arm64_l_10030d8:
	/* 0x10030d8: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10030dc:
	/* 0x10030dc: b 10030ec <outer_done_3> */
	ARM64_SIM_A64_JMP(0x10030dc, 0x10030ec, arm64_l_10030ec);
arm64_l_10030e0:
	/* 0x10030e0: b.ne 10030d8 <native_pc_3+0x4> */
	ARM64_SIM_A64_JCC(ARM64_COND_NE, 0x10030e0, 0x10030d8, arm64_l_10030d8);
arm64_l_10030e4:
	/* 0x10030e4: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10030e8:
	/* 0x10030e8: b 10030ec <outer_done_3> */
	ARM64_SIM_A64_JMP(0x10030e8, 0x10030ec, arm64_l_10030ec);
arm64_l_10030ec:
	/* 0x10030ec: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10030ec);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_4(struct state *);
extern unsigned char native_pc_4,native_next_4;
static void sim_4(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10040d4:
	/* 0x10040d4: b.cs 10040e0 <native_pc_4+0xc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x10040d4, 0x10040e0, arm64_l_10040e0);
arm64_l_10040d8:
	/* 0x10040d8: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10040dc:
	/* 0x10040dc: b 10040e8 <outer_done_4> */
	ARM64_SIM_A64_JMP(0x10040dc, 0x10040e8, arm64_l_10040e8);
arm64_l_10040e0:
	/* 0x10040e0: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10040e4:
	/* 0x10040e4: b 10040e8 <outer_done_4> */
	ARM64_SIM_A64_JMP(0x10040e4, 0x10040e8, arm64_l_10040e8);
arm64_l_10040e8:
	/* 0x10040e8: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10040e8);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_5(struct state *);
extern unsigned char native_pc_5,native_next_5;
static void sim_5(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10050d4:
	/* 0x10050d4: b 10050e0 <native_pc_5+0xc> */
	ARM64_SIM_A64_JMP(0x10050d4, 0x10050e0, arm64_l_10050e0);
arm64_l_10050d8:
	/* 0x10050d8: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10050dc:
	/* 0x10050dc: b 10050ec <outer_done_5> */
	ARM64_SIM_A64_JMP(0x10050dc, 0x10050ec, arm64_l_10050ec);
arm64_l_10050e0:
	/* 0x10050e0: b.cs 10050d8 <native_pc_5+0x4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CS, 0x10050e0, 0x10050d8, arm64_l_10050d8);
arm64_l_10050e4:
	/* 0x10050e4: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10050e8:
	/* 0x10050e8: b 10050ec <outer_done_5> */
	ARM64_SIM_A64_JMP(0x10050e8, 0x10050ec, arm64_l_10050ec);
arm64_l_10050ec:
	/* 0x10050ec: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10050ec);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_6(struct state *);
extern unsigned char native_pc_6,native_next_6;
static void sim_6(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10060d4:
	/* 0x10060d4: b.cc 10060e0 <native_pc_6+0xc> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x10060d4, 0x10060e0, arm64_l_10060e0);
arm64_l_10060d8:
	/* 0x10060d8: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10060dc:
	/* 0x10060dc: b 10060e8 <outer_done_6> */
	ARM64_SIM_A64_JMP(0x10060dc, 0x10060e8, arm64_l_10060e8);
arm64_l_10060e0:
	/* 0x10060e0: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10060e4:
	/* 0x10060e4: b 10060e8 <outer_done_6> */
	ARM64_SIM_A64_JMP(0x10060e4, 0x10060e8, arm64_l_10060e8);
arm64_l_10060e8:
	/* 0x10060e8: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10060e8);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_7(struct state *);
extern unsigned char native_pc_7,native_next_7;
static void sim_7(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10070d4:
	/* 0x10070d4: b 10070e0 <native_pc_7+0xc> */
	ARM64_SIM_A64_JMP(0x10070d4, 0x10070e0, arm64_l_10070e0);
arm64_l_10070d8:
	/* 0x10070d8: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10070dc:
	/* 0x10070dc: b 10070ec <outer_done_7> */
	ARM64_SIM_A64_JMP(0x10070dc, 0x10070ec, arm64_l_10070ec);
arm64_l_10070e0:
	/* 0x10070e0: b.cc 10070d8 <native_pc_7+0x4> */
	ARM64_SIM_A64_JCC(ARM64_COND_CC, 0x10070e0, 0x10070d8, arm64_l_10070d8);
arm64_l_10070e4:
	/* 0x10070e4: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10070e8:
	/* 0x10070e8: b 10070ec <outer_done_7> */
	ARM64_SIM_A64_JMP(0x10070e8, 0x10070ec, arm64_l_10070ec);
arm64_l_10070ec:
	/* 0x10070ec: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10070ec);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_8(struct state *);
extern unsigned char native_pc_8,native_next_8;
static void sim_8(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10080d4:
	/* 0x10080d4: b.mi 10080e0 <native_pc_8+0xc> */
	ARM64_SIM_A64_JCC(ARM64_COND_MI, 0x10080d4, 0x10080e0, arm64_l_10080e0);
arm64_l_10080d8:
	/* 0x10080d8: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10080dc:
	/* 0x10080dc: b 10080e8 <outer_done_8> */
	ARM64_SIM_A64_JMP(0x10080dc, 0x10080e8, arm64_l_10080e8);
arm64_l_10080e0:
	/* 0x10080e0: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10080e4:
	/* 0x10080e4: b 10080e8 <outer_done_8> */
	ARM64_SIM_A64_JMP(0x10080e4, 0x10080e8, arm64_l_10080e8);
arm64_l_10080e8:
	/* 0x10080e8: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10080e8);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_9(struct state *);
extern unsigned char native_pc_9,native_next_9;
static void sim_9(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10090d4:
	/* 0x10090d4: b 10090e0 <native_pc_9+0xc> */
	ARM64_SIM_A64_JMP(0x10090d4, 0x10090e0, arm64_l_10090e0);
arm64_l_10090d8:
	/* 0x10090d8: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10090dc:
	/* 0x10090dc: b 10090ec <outer_done_9> */
	ARM64_SIM_A64_JMP(0x10090dc, 0x10090ec, arm64_l_10090ec);
arm64_l_10090e0:
	/* 0x10090e0: b.mi 10090d8 <native_pc_9+0x4> */
	ARM64_SIM_A64_JCC(ARM64_COND_MI, 0x10090e0, 0x10090d8, arm64_l_10090d8);
arm64_l_10090e4:
	/* 0x10090e4: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10090e8:
	/* 0x10090e8: b 10090ec <outer_done_9> */
	ARM64_SIM_A64_JMP(0x10090e8, 0x10090ec, arm64_l_10090ec);
arm64_l_10090ec:
	/* 0x10090ec: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10090ec);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_10(struct state *);
extern unsigned char native_pc_10,native_next_10;
static void sim_10(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_100a0d4:
	/* 0x100a0d4: b.pl 100a0e0 <native_pc_10+0xc> */
	ARM64_SIM_A64_JCC(ARM64_COND_PL, 0x100a0d4, 0x100a0e0, arm64_l_100a0e0);
arm64_l_100a0d8:
	/* 0x100a0d8: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_100a0dc:
	/* 0x100a0dc: b 100a0e8 <outer_done_10> */
	ARM64_SIM_A64_JMP(0x100a0dc, 0x100a0e8, arm64_l_100a0e8);
arm64_l_100a0e0:
	/* 0x100a0e0: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_100a0e4:
	/* 0x100a0e4: b 100a0e8 <outer_done_10> */
	ARM64_SIM_A64_JMP(0x100a0e4, 0x100a0e8, arm64_l_100a0e8);
arm64_l_100a0e8:
	/* 0x100a0e8: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_100a0e8);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_11(struct state *);
extern unsigned char native_pc_11,native_next_11;
static void sim_11(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_100b0d4:
	/* 0x100b0d4: b 100b0e0 <native_pc_11+0xc> */
	ARM64_SIM_A64_JMP(0x100b0d4, 0x100b0e0, arm64_l_100b0e0);
arm64_l_100b0d8:
	/* 0x100b0d8: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_100b0dc:
	/* 0x100b0dc: b 100b0ec <outer_done_11> */
	ARM64_SIM_A64_JMP(0x100b0dc, 0x100b0ec, arm64_l_100b0ec);
arm64_l_100b0e0:
	/* 0x100b0e0: b.pl 100b0d8 <native_pc_11+0x4> */
	ARM64_SIM_A64_JCC(ARM64_COND_PL, 0x100b0e0, 0x100b0d8, arm64_l_100b0d8);
arm64_l_100b0e4:
	/* 0x100b0e4: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_100b0e8:
	/* 0x100b0e8: b 100b0ec <outer_done_11> */
	ARM64_SIM_A64_JMP(0x100b0e8, 0x100b0ec, arm64_l_100b0ec);
arm64_l_100b0ec:
	/* 0x100b0ec: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_100b0ec);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_12(struct state *);
extern unsigned char native_pc_12,native_next_12;
static void sim_12(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_100c0d4:
	/* 0x100c0d4: b.vs 100c0e0 <native_pc_12+0xc> */
	ARM64_SIM_A64_JCC(ARM64_COND_VS, 0x100c0d4, 0x100c0e0, arm64_l_100c0e0);
arm64_l_100c0d8:
	/* 0x100c0d8: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_100c0dc:
	/* 0x100c0dc: b 100c0e8 <outer_done_12> */
	ARM64_SIM_A64_JMP(0x100c0dc, 0x100c0e8, arm64_l_100c0e8);
arm64_l_100c0e0:
	/* 0x100c0e0: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_100c0e4:
	/* 0x100c0e4: b 100c0e8 <outer_done_12> */
	ARM64_SIM_A64_JMP(0x100c0e4, 0x100c0e8, arm64_l_100c0e8);
arm64_l_100c0e8:
	/* 0x100c0e8: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_100c0e8);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_13(struct state *);
extern unsigned char native_pc_13,native_next_13;
static void sim_13(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_100d0d4:
	/* 0x100d0d4: b 100d0e0 <native_pc_13+0xc> */
	ARM64_SIM_A64_JMP(0x100d0d4, 0x100d0e0, arm64_l_100d0e0);
arm64_l_100d0d8:
	/* 0x100d0d8: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_100d0dc:
	/* 0x100d0dc: b 100d0ec <outer_done_13> */
	ARM64_SIM_A64_JMP(0x100d0dc, 0x100d0ec, arm64_l_100d0ec);
arm64_l_100d0e0:
	/* 0x100d0e0: b.vs 100d0d8 <native_pc_13+0x4> */
	ARM64_SIM_A64_JCC(ARM64_COND_VS, 0x100d0e0, 0x100d0d8, arm64_l_100d0d8);
arm64_l_100d0e4:
	/* 0x100d0e4: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_100d0e8:
	/* 0x100d0e8: b 100d0ec <outer_done_13> */
	ARM64_SIM_A64_JMP(0x100d0e8, 0x100d0ec, arm64_l_100d0ec);
arm64_l_100d0ec:
	/* 0x100d0ec: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_100d0ec);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_14(struct state *);
extern unsigned char native_pc_14,native_next_14;
static void sim_14(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_100e0d4:
	/* 0x100e0d4: b.vc 100e0e0 <native_pc_14+0xc> */
	ARM64_SIM_A64_JCC(ARM64_COND_VC, 0x100e0d4, 0x100e0e0, arm64_l_100e0e0);
arm64_l_100e0d8:
	/* 0x100e0d8: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_100e0dc:
	/* 0x100e0dc: b 100e0e8 <outer_done_14> */
	ARM64_SIM_A64_JMP(0x100e0dc, 0x100e0e8, arm64_l_100e0e8);
arm64_l_100e0e0:
	/* 0x100e0e0: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_100e0e4:
	/* 0x100e0e4: b 100e0e8 <outer_done_14> */
	ARM64_SIM_A64_JMP(0x100e0e4, 0x100e0e8, arm64_l_100e0e8);
arm64_l_100e0e8:
	/* 0x100e0e8: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_100e0e8);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_15(struct state *);
extern unsigned char native_pc_15,native_next_15;
static void sim_15(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_100f0d4:
	/* 0x100f0d4: b 100f0e0 <native_pc_15+0xc> */
	ARM64_SIM_A64_JMP(0x100f0d4, 0x100f0e0, arm64_l_100f0e0);
arm64_l_100f0d8:
	/* 0x100f0d8: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_100f0dc:
	/* 0x100f0dc: b 100f0ec <outer_done_15> */
	ARM64_SIM_A64_JMP(0x100f0dc, 0x100f0ec, arm64_l_100f0ec);
arm64_l_100f0e0:
	/* 0x100f0e0: b.vc 100f0d8 <native_pc_15+0x4> */
	ARM64_SIM_A64_JCC(ARM64_COND_VC, 0x100f0e0, 0x100f0d8, arm64_l_100f0d8);
arm64_l_100f0e4:
	/* 0x100f0e4: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_100f0e8:
	/* 0x100f0e8: b 100f0ec <outer_done_15> */
	ARM64_SIM_A64_JMP(0x100f0e8, 0x100f0ec, arm64_l_100f0ec);
arm64_l_100f0ec:
	/* 0x100f0ec: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_100f0ec);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_16(struct state *);
extern unsigned char native_pc_16,native_next_16;
static void sim_16(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10100d4:
	/* 0x10100d4: b.hi 10100e0 <native_pc_16+0xc> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x10100d4, 0x10100e0, arm64_l_10100e0);
arm64_l_10100d8:
	/* 0x10100d8: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10100dc:
	/* 0x10100dc: b 10100e8 <outer_done_16> */
	ARM64_SIM_A64_JMP(0x10100dc, 0x10100e8, arm64_l_10100e8);
arm64_l_10100e0:
	/* 0x10100e0: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10100e4:
	/* 0x10100e4: b 10100e8 <outer_done_16> */
	ARM64_SIM_A64_JMP(0x10100e4, 0x10100e8, arm64_l_10100e8);
arm64_l_10100e8:
	/* 0x10100e8: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10100e8);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_17(struct state *);
extern unsigned char native_pc_17,native_next_17;
static void sim_17(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10110d4:
	/* 0x10110d4: b 10110e0 <native_pc_17+0xc> */
	ARM64_SIM_A64_JMP(0x10110d4, 0x10110e0, arm64_l_10110e0);
arm64_l_10110d8:
	/* 0x10110d8: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10110dc:
	/* 0x10110dc: b 10110ec <outer_done_17> */
	ARM64_SIM_A64_JMP(0x10110dc, 0x10110ec, arm64_l_10110ec);
arm64_l_10110e0:
	/* 0x10110e0: b.hi 10110d8 <native_pc_17+0x4> */
	ARM64_SIM_A64_JCC(ARM64_COND_HI, 0x10110e0, 0x10110d8, arm64_l_10110d8);
arm64_l_10110e4:
	/* 0x10110e4: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10110e8:
	/* 0x10110e8: b 10110ec <outer_done_17> */
	ARM64_SIM_A64_JMP(0x10110e8, 0x10110ec, arm64_l_10110ec);
arm64_l_10110ec:
	/* 0x10110ec: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10110ec);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_18(struct state *);
extern unsigned char native_pc_18,native_next_18;
static void sim_18(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10120d4:
	/* 0x10120d4: b.ls 10120e0 <native_pc_18+0xc> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x10120d4, 0x10120e0, arm64_l_10120e0);
arm64_l_10120d8:
	/* 0x10120d8: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10120dc:
	/* 0x10120dc: b 10120e8 <outer_done_18> */
	ARM64_SIM_A64_JMP(0x10120dc, 0x10120e8, arm64_l_10120e8);
arm64_l_10120e0:
	/* 0x10120e0: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10120e4:
	/* 0x10120e4: b 10120e8 <outer_done_18> */
	ARM64_SIM_A64_JMP(0x10120e4, 0x10120e8, arm64_l_10120e8);
arm64_l_10120e8:
	/* 0x10120e8: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10120e8);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_19(struct state *);
extern unsigned char native_pc_19,native_next_19;
static void sim_19(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10130d4:
	/* 0x10130d4: b 10130e0 <native_pc_19+0xc> */
	ARM64_SIM_A64_JMP(0x10130d4, 0x10130e0, arm64_l_10130e0);
arm64_l_10130d8:
	/* 0x10130d8: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10130dc:
	/* 0x10130dc: b 10130ec <outer_done_19> */
	ARM64_SIM_A64_JMP(0x10130dc, 0x10130ec, arm64_l_10130ec);
arm64_l_10130e0:
	/* 0x10130e0: b.ls 10130d8 <native_pc_19+0x4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LS, 0x10130e0, 0x10130d8, arm64_l_10130d8);
arm64_l_10130e4:
	/* 0x10130e4: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10130e8:
	/* 0x10130e8: b 10130ec <outer_done_19> */
	ARM64_SIM_A64_JMP(0x10130e8, 0x10130ec, arm64_l_10130ec);
arm64_l_10130ec:
	/* 0x10130ec: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10130ec);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_20(struct state *);
extern unsigned char native_pc_20,native_next_20;
static void sim_20(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10140d4:
	/* 0x10140d4: b.ge 10140e0 <native_pc_20+0xc> */
	ARM64_SIM_A64_JCC(ARM64_COND_GE, 0x10140d4, 0x10140e0, arm64_l_10140e0);
arm64_l_10140d8:
	/* 0x10140d8: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10140dc:
	/* 0x10140dc: b 10140e8 <outer_done_20> */
	ARM64_SIM_A64_JMP(0x10140dc, 0x10140e8, arm64_l_10140e8);
arm64_l_10140e0:
	/* 0x10140e0: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10140e4:
	/* 0x10140e4: b 10140e8 <outer_done_20> */
	ARM64_SIM_A64_JMP(0x10140e4, 0x10140e8, arm64_l_10140e8);
arm64_l_10140e8:
	/* 0x10140e8: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10140e8);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_21(struct state *);
extern unsigned char native_pc_21,native_next_21;
static void sim_21(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10150d4:
	/* 0x10150d4: b 10150e0 <native_pc_21+0xc> */
	ARM64_SIM_A64_JMP(0x10150d4, 0x10150e0, arm64_l_10150e0);
arm64_l_10150d8:
	/* 0x10150d8: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10150dc:
	/* 0x10150dc: b 10150ec <outer_done_21> */
	ARM64_SIM_A64_JMP(0x10150dc, 0x10150ec, arm64_l_10150ec);
arm64_l_10150e0:
	/* 0x10150e0: b.ge 10150d8 <native_pc_21+0x4> */
	ARM64_SIM_A64_JCC(ARM64_COND_GE, 0x10150e0, 0x10150d8, arm64_l_10150d8);
arm64_l_10150e4:
	/* 0x10150e4: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10150e8:
	/* 0x10150e8: b 10150ec <outer_done_21> */
	ARM64_SIM_A64_JMP(0x10150e8, 0x10150ec, arm64_l_10150ec);
arm64_l_10150ec:
	/* 0x10150ec: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10150ec);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_22(struct state *);
extern unsigned char native_pc_22,native_next_22;
static void sim_22(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10160d4:
	/* 0x10160d4: b.lt 10160e0 <native_pc_22+0xc> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x10160d4, 0x10160e0, arm64_l_10160e0);
arm64_l_10160d8:
	/* 0x10160d8: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10160dc:
	/* 0x10160dc: b 10160e8 <outer_done_22> */
	ARM64_SIM_A64_JMP(0x10160dc, 0x10160e8, arm64_l_10160e8);
arm64_l_10160e0:
	/* 0x10160e0: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10160e4:
	/* 0x10160e4: b 10160e8 <outer_done_22> */
	ARM64_SIM_A64_JMP(0x10160e4, 0x10160e8, arm64_l_10160e8);
arm64_l_10160e8:
	/* 0x10160e8: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10160e8);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_23(struct state *);
extern unsigned char native_pc_23,native_next_23;
static void sim_23(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10170d4:
	/* 0x10170d4: b 10170e0 <native_pc_23+0xc> */
	ARM64_SIM_A64_JMP(0x10170d4, 0x10170e0, arm64_l_10170e0);
arm64_l_10170d8:
	/* 0x10170d8: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10170dc:
	/* 0x10170dc: b 10170ec <outer_done_23> */
	ARM64_SIM_A64_JMP(0x10170dc, 0x10170ec, arm64_l_10170ec);
arm64_l_10170e0:
	/* 0x10170e0: b.lt 10170d8 <native_pc_23+0x4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LT, 0x10170e0, 0x10170d8, arm64_l_10170d8);
arm64_l_10170e4:
	/* 0x10170e4: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10170e8:
	/* 0x10170e8: b 10170ec <outer_done_23> */
	ARM64_SIM_A64_JMP(0x10170e8, 0x10170ec, arm64_l_10170ec);
arm64_l_10170ec:
	/* 0x10170ec: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10170ec);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_24(struct state *);
extern unsigned char native_pc_24,native_next_24;
static void sim_24(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10180d4:
	/* 0x10180d4: b.gt 10180e0 <native_pc_24+0xc> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x10180d4, 0x10180e0, arm64_l_10180e0);
arm64_l_10180d8:
	/* 0x10180d8: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10180dc:
	/* 0x10180dc: b 10180e8 <outer_done_24> */
	ARM64_SIM_A64_JMP(0x10180dc, 0x10180e8, arm64_l_10180e8);
arm64_l_10180e0:
	/* 0x10180e0: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10180e4:
	/* 0x10180e4: b 10180e8 <outer_done_24> */
	ARM64_SIM_A64_JMP(0x10180e4, 0x10180e8, arm64_l_10180e8);
arm64_l_10180e8:
	/* 0x10180e8: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10180e8);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_25(struct state *);
extern unsigned char native_pc_25,native_next_25;
static void sim_25(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10190d4:
	/* 0x10190d4: b 10190e0 <native_pc_25+0xc> */
	ARM64_SIM_A64_JMP(0x10190d4, 0x10190e0, arm64_l_10190e0);
arm64_l_10190d8:
	/* 0x10190d8: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10190dc:
	/* 0x10190dc: b 10190ec <outer_done_25> */
	ARM64_SIM_A64_JMP(0x10190dc, 0x10190ec, arm64_l_10190ec);
arm64_l_10190e0:
	/* 0x10190e0: b.gt 10190d8 <native_pc_25+0x4> */
	ARM64_SIM_A64_JCC(ARM64_COND_GT, 0x10190e0, 0x10190d8, arm64_l_10190d8);
arm64_l_10190e4:
	/* 0x10190e4: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10190e8:
	/* 0x10190e8: b 10190ec <outer_done_25> */
	ARM64_SIM_A64_JMP(0x10190e8, 0x10190ec, arm64_l_10190ec);
arm64_l_10190ec:
	/* 0x10190ec: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10190ec);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_26(struct state *);
extern unsigned char native_pc_26,native_next_26;
static void sim_26(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_101a0d4:
	/* 0x101a0d4: b.le 101a0e0 <native_pc_26+0xc> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x101a0d4, 0x101a0e0, arm64_l_101a0e0);
arm64_l_101a0d8:
	/* 0x101a0d8: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_101a0dc:
	/* 0x101a0dc: b 101a0e8 <outer_done_26> */
	ARM64_SIM_A64_JMP(0x101a0dc, 0x101a0e8, arm64_l_101a0e8);
arm64_l_101a0e0:
	/* 0x101a0e0: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_101a0e4:
	/* 0x101a0e4: b 101a0e8 <outer_done_26> */
	ARM64_SIM_A64_JMP(0x101a0e4, 0x101a0e8, arm64_l_101a0e8);
arm64_l_101a0e8:
	/* 0x101a0e8: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_101a0e8);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_27(struct state *);
extern unsigned char native_pc_27,native_next_27;
static void sim_27(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_101b0d4:
	/* 0x101b0d4: b 101b0e0 <native_pc_27+0xc> */
	ARM64_SIM_A64_JMP(0x101b0d4, 0x101b0e0, arm64_l_101b0e0);
arm64_l_101b0d8:
	/* 0x101b0d8: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_101b0dc:
	/* 0x101b0dc: b 101b0ec <outer_done_27> */
	ARM64_SIM_A64_JMP(0x101b0dc, 0x101b0ec, arm64_l_101b0ec);
arm64_l_101b0e0:
	/* 0x101b0e0: b.le 101b0d8 <native_pc_27+0x4> */
	ARM64_SIM_A64_JCC(ARM64_COND_LE, 0x101b0e0, 0x101b0d8, arm64_l_101b0d8);
arm64_l_101b0e4:
	/* 0x101b0e4: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_101b0e8:
	/* 0x101b0e8: b 101b0ec <outer_done_27> */
	ARM64_SIM_A64_JMP(0x101b0e8, 0x101b0ec, arm64_l_101b0ec);
arm64_l_101b0ec:
	/* 0x101b0ec: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_101b0ec);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_28(struct state *);
extern unsigned char native_pc_28,native_next_28;
static void sim_28(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_101c0d4:
	/* 0x101c0d4: cbz w1, 101c0e0 <native_pc_28+0xc> */
	ARM64_SIM_A64_CBZ(ARM64_X1, 0x101c0d4, 0x101c0e0, arm64_l_101c0e0);
arm64_l_101c0d8:
	/* 0x101c0d8: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_101c0dc:
	/* 0x101c0dc: b 101c0e8 <outer_done_28> */
	ARM64_SIM_A64_JMP(0x101c0dc, 0x101c0e8, arm64_l_101c0e8);
arm64_l_101c0e0:
	/* 0x101c0e0: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_101c0e4:
	/* 0x101c0e4: b 101c0e8 <outer_done_28> */
	ARM64_SIM_A64_JMP(0x101c0e4, 0x101c0e8, arm64_l_101c0e8);
arm64_l_101c0e8:
	/* 0x101c0e8: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_101c0e8);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_29(struct state *);
extern unsigned char native_pc_29,native_next_29;
static void sim_29(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_101d0d4:
	/* 0x101d0d4: b 101d0e0 <native_pc_29+0xc> */
	ARM64_SIM_A64_JMP(0x101d0d4, 0x101d0e0, arm64_l_101d0e0);
arm64_l_101d0d8:
	/* 0x101d0d8: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_101d0dc:
	/* 0x101d0dc: b 101d0ec <outer_done_29> */
	ARM64_SIM_A64_JMP(0x101d0dc, 0x101d0ec, arm64_l_101d0ec);
arm64_l_101d0e0:
	/* 0x101d0e0: cbz w1, 101d0d8 <native_pc_29+0x4> */
	ARM64_SIM_A64_CBZ(ARM64_X1, 0x101d0e0, 0x101d0d8, arm64_l_101d0d8);
arm64_l_101d0e4:
	/* 0x101d0e4: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_101d0e8:
	/* 0x101d0e8: b 101d0ec <outer_done_29> */
	ARM64_SIM_A64_JMP(0x101d0e8, 0x101d0ec, arm64_l_101d0ec);
arm64_l_101d0ec:
	/* 0x101d0ec: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_101d0ec);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_30(struct state *);
extern unsigned char native_pc_30,native_next_30;
static void sim_30(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_101e0d4:
	/* 0x101e0d4: cbnz w1, 101e0e0 <native_pc_30+0xc> */
	ARM64_SIM_A64_CBNZ(ARM64_X1, 0x101e0d4, 0x101e0e0, arm64_l_101e0e0);
arm64_l_101e0d8:
	/* 0x101e0d8: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_101e0dc:
	/* 0x101e0dc: b 101e0e8 <outer_done_30> */
	ARM64_SIM_A64_JMP(0x101e0dc, 0x101e0e8, arm64_l_101e0e8);
arm64_l_101e0e0:
	/* 0x101e0e0: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_101e0e4:
	/* 0x101e0e4: b 101e0e8 <outer_done_30> */
	ARM64_SIM_A64_JMP(0x101e0e4, 0x101e0e8, arm64_l_101e0e8);
arm64_l_101e0e8:
	/* 0x101e0e8: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_101e0e8);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_31(struct state *);
extern unsigned char native_pc_31,native_next_31;
static void sim_31(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_101f0d4:
	/* 0x101f0d4: b 101f0e0 <native_pc_31+0xc> */
	ARM64_SIM_A64_JMP(0x101f0d4, 0x101f0e0, arm64_l_101f0e0);
arm64_l_101f0d8:
	/* 0x101f0d8: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_101f0dc:
	/* 0x101f0dc: b 101f0ec <outer_done_31> */
	ARM64_SIM_A64_JMP(0x101f0dc, 0x101f0ec, arm64_l_101f0ec);
arm64_l_101f0e0:
	/* 0x101f0e0: cbnz w1, 101f0d8 <native_pc_31+0x4> */
	ARM64_SIM_A64_CBNZ(ARM64_X1, 0x101f0e0, 0x101f0d8, arm64_l_101f0d8);
arm64_l_101f0e4:
	/* 0x101f0e4: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_101f0e8:
	/* 0x101f0e8: b 101f0ec <outer_done_31> */
	ARM64_SIM_A64_JMP(0x101f0e8, 0x101f0ec, arm64_l_101f0ec);
arm64_l_101f0ec:
	/* 0x101f0ec: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_101f0ec);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_32(struct state *);
extern unsigned char native_pc_32,native_next_32;
static void sim_32(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10200d4:
	/* 0x10200d4: tbz w1, #0, 10200e0 <native_pc_32+0xc> */
	ARM64_SIM_A64_TBZ(ARM64_X1, 0, 0x10200d4, 0x10200e0, arm64_l_10200e0);
arm64_l_10200d8:
	/* 0x10200d8: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10200dc:
	/* 0x10200dc: b 10200e8 <outer_done_32> */
	ARM64_SIM_A64_JMP(0x10200dc, 0x10200e8, arm64_l_10200e8);
arm64_l_10200e0:
	/* 0x10200e0: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10200e4:
	/* 0x10200e4: b 10200e8 <outer_done_32> */
	ARM64_SIM_A64_JMP(0x10200e4, 0x10200e8, arm64_l_10200e8);
arm64_l_10200e8:
	/* 0x10200e8: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10200e8);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_33(struct state *);
extern unsigned char native_pc_33,native_next_33;
static void sim_33(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10210d4:
	/* 0x10210d4: b 10210e0 <native_pc_33+0xc> */
	ARM64_SIM_A64_JMP(0x10210d4, 0x10210e0, arm64_l_10210e0);
arm64_l_10210d8:
	/* 0x10210d8: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10210dc:
	/* 0x10210dc: b 10210ec <outer_done_33> */
	ARM64_SIM_A64_JMP(0x10210dc, 0x10210ec, arm64_l_10210ec);
arm64_l_10210e0:
	/* 0x10210e0: tbz w1, #0, 10210d8 <native_pc_33+0x4> */
	ARM64_SIM_A64_TBZ(ARM64_X1, 0, 0x10210e0, 0x10210d8, arm64_l_10210d8);
arm64_l_10210e4:
	/* 0x10210e4: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10210e8:
	/* 0x10210e8: b 10210ec <outer_done_33> */
	ARM64_SIM_A64_JMP(0x10210e8, 0x10210ec, arm64_l_10210ec);
arm64_l_10210ec:
	/* 0x10210ec: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10210ec);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_34(struct state *);
extern unsigned char native_pc_34,native_next_34;
static void sim_34(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10220d4:
	/* 0x10220d4: tbz w1, #7, 10220e0 <native_pc_34+0xc> */
	ARM64_SIM_A64_TBZ(ARM64_X1, 7, 0x10220d4, 0x10220e0, arm64_l_10220e0);
arm64_l_10220d8:
	/* 0x10220d8: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10220dc:
	/* 0x10220dc: b 10220e8 <outer_done_34> */
	ARM64_SIM_A64_JMP(0x10220dc, 0x10220e8, arm64_l_10220e8);
arm64_l_10220e0:
	/* 0x10220e0: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10220e4:
	/* 0x10220e4: b 10220e8 <outer_done_34> */
	ARM64_SIM_A64_JMP(0x10220e4, 0x10220e8, arm64_l_10220e8);
arm64_l_10220e8:
	/* 0x10220e8: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10220e8);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_35(struct state *);
extern unsigned char native_pc_35,native_next_35;
static void sim_35(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10230d4:
	/* 0x10230d4: b 10230e0 <native_pc_35+0xc> */
	ARM64_SIM_A64_JMP(0x10230d4, 0x10230e0, arm64_l_10230e0);
arm64_l_10230d8:
	/* 0x10230d8: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10230dc:
	/* 0x10230dc: b 10230ec <outer_done_35> */
	ARM64_SIM_A64_JMP(0x10230dc, 0x10230ec, arm64_l_10230ec);
arm64_l_10230e0:
	/* 0x10230e0: tbz w1, #7, 10230d8 <native_pc_35+0x4> */
	ARM64_SIM_A64_TBZ(ARM64_X1, 7, 0x10230e0, 0x10230d8, arm64_l_10230d8);
arm64_l_10230e4:
	/* 0x10230e4: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10230e8:
	/* 0x10230e8: b 10230ec <outer_done_35> */
	ARM64_SIM_A64_JMP(0x10230e8, 0x10230ec, arm64_l_10230ec);
arm64_l_10230ec:
	/* 0x10230ec: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10230ec);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_36(struct state *);
extern unsigned char native_pc_36,native_next_36;
static void sim_36(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10240d4:
	/* 0x10240d4: tbz w1, #31, 10240e0 <native_pc_36+0xc> */
	ARM64_SIM_A64_TBZ(ARM64_X1, 31, 0x10240d4, 0x10240e0, arm64_l_10240e0);
arm64_l_10240d8:
	/* 0x10240d8: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10240dc:
	/* 0x10240dc: b 10240e8 <outer_done_36> */
	ARM64_SIM_A64_JMP(0x10240dc, 0x10240e8, arm64_l_10240e8);
arm64_l_10240e0:
	/* 0x10240e0: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10240e4:
	/* 0x10240e4: b 10240e8 <outer_done_36> */
	ARM64_SIM_A64_JMP(0x10240e4, 0x10240e8, arm64_l_10240e8);
arm64_l_10240e8:
	/* 0x10240e8: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10240e8);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_37(struct state *);
extern unsigned char native_pc_37,native_next_37;
static void sim_37(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10250d4:
	/* 0x10250d4: b 10250e0 <native_pc_37+0xc> */
	ARM64_SIM_A64_JMP(0x10250d4, 0x10250e0, arm64_l_10250e0);
arm64_l_10250d8:
	/* 0x10250d8: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10250dc:
	/* 0x10250dc: b 10250ec <outer_done_37> */
	ARM64_SIM_A64_JMP(0x10250dc, 0x10250ec, arm64_l_10250ec);
arm64_l_10250e0:
	/* 0x10250e0: tbz w1, #31, 10250d8 <native_pc_37+0x4> */
	ARM64_SIM_A64_TBZ(ARM64_X1, 31, 0x10250e0, 0x10250d8, arm64_l_10250d8);
arm64_l_10250e4:
	/* 0x10250e4: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10250e8:
	/* 0x10250e8: b 10250ec <outer_done_37> */
	ARM64_SIM_A64_JMP(0x10250e8, 0x10250ec, arm64_l_10250ec);
arm64_l_10250ec:
	/* 0x10250ec: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10250ec);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_38(struct state *);
extern unsigned char native_pc_38,native_next_38;
static void sim_38(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10260d4:
	/* 0x10260d4: tbnz w1, #0, 10260e0 <native_pc_38+0xc> */
	ARM64_SIM_A64_TBNZ(ARM64_X1, 0, 0x10260d4, 0x10260e0, arm64_l_10260e0);
arm64_l_10260d8:
	/* 0x10260d8: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10260dc:
	/* 0x10260dc: b 10260e8 <outer_done_38> */
	ARM64_SIM_A64_JMP(0x10260dc, 0x10260e8, arm64_l_10260e8);
arm64_l_10260e0:
	/* 0x10260e0: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10260e4:
	/* 0x10260e4: b 10260e8 <outer_done_38> */
	ARM64_SIM_A64_JMP(0x10260e4, 0x10260e8, arm64_l_10260e8);
arm64_l_10260e8:
	/* 0x10260e8: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10260e8);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_39(struct state *);
extern unsigned char native_pc_39,native_next_39;
static void sim_39(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10270d4:
	/* 0x10270d4: b 10270e0 <native_pc_39+0xc> */
	ARM64_SIM_A64_JMP(0x10270d4, 0x10270e0, arm64_l_10270e0);
arm64_l_10270d8:
	/* 0x10270d8: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10270dc:
	/* 0x10270dc: b 10270ec <outer_done_39> */
	ARM64_SIM_A64_JMP(0x10270dc, 0x10270ec, arm64_l_10270ec);
arm64_l_10270e0:
	/* 0x10270e0: tbnz w1, #0, 10270d8 <native_pc_39+0x4> */
	ARM64_SIM_A64_TBNZ(ARM64_X1, 0, 0x10270e0, 0x10270d8, arm64_l_10270d8);
arm64_l_10270e4:
	/* 0x10270e4: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10270e8:
	/* 0x10270e8: b 10270ec <outer_done_39> */
	ARM64_SIM_A64_JMP(0x10270e8, 0x10270ec, arm64_l_10270ec);
arm64_l_10270ec:
	/* 0x10270ec: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10270ec);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_40(struct state *);
extern unsigned char native_pc_40,native_next_40;
static void sim_40(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10280d4:
	/* 0x10280d4: tbnz w1, #7, 10280e0 <native_pc_40+0xc> */
	ARM64_SIM_A64_TBNZ(ARM64_X1, 7, 0x10280d4, 0x10280e0, arm64_l_10280e0);
arm64_l_10280d8:
	/* 0x10280d8: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10280dc:
	/* 0x10280dc: b 10280e8 <outer_done_40> */
	ARM64_SIM_A64_JMP(0x10280dc, 0x10280e8, arm64_l_10280e8);
arm64_l_10280e0:
	/* 0x10280e0: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10280e4:
	/* 0x10280e4: b 10280e8 <outer_done_40> */
	ARM64_SIM_A64_JMP(0x10280e4, 0x10280e8, arm64_l_10280e8);
arm64_l_10280e8:
	/* 0x10280e8: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10280e8);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_41(struct state *);
extern unsigned char native_pc_41,native_next_41;
static void sim_41(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10290d4:
	/* 0x10290d4: b 10290e0 <native_pc_41+0xc> */
	ARM64_SIM_A64_JMP(0x10290d4, 0x10290e0, arm64_l_10290e0);
arm64_l_10290d8:
	/* 0x10290d8: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10290dc:
	/* 0x10290dc: b 10290ec <outer_done_41> */
	ARM64_SIM_A64_JMP(0x10290dc, 0x10290ec, arm64_l_10290ec);
arm64_l_10290e0:
	/* 0x10290e0: tbnz w1, #7, 10290d8 <native_pc_41+0x4> */
	ARM64_SIM_A64_TBNZ(ARM64_X1, 7, 0x10290e0, 0x10290d8, arm64_l_10290d8);
arm64_l_10290e4:
	/* 0x10290e4: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10290e8:
	/* 0x10290e8: b 10290ec <outer_done_41> */
	ARM64_SIM_A64_JMP(0x10290e8, 0x10290ec, arm64_l_10290ec);
arm64_l_10290ec:
	/* 0x10290ec: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10290ec);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_42(struct state *);
extern unsigned char native_pc_42,native_next_42;
static void sim_42(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_102a0d4:
	/* 0x102a0d4: tbnz w1, #31, 102a0e0 <native_pc_42+0xc> */
	ARM64_SIM_A64_TBNZ(ARM64_X1, 31, 0x102a0d4, 0x102a0e0, arm64_l_102a0e0);
arm64_l_102a0d8:
	/* 0x102a0d8: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_102a0dc:
	/* 0x102a0dc: b 102a0e8 <outer_done_42> */
	ARM64_SIM_A64_JMP(0x102a0dc, 0x102a0e8, arm64_l_102a0e8);
arm64_l_102a0e0:
	/* 0x102a0e0: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_102a0e4:
	/* 0x102a0e4: b 102a0e8 <outer_done_42> */
	ARM64_SIM_A64_JMP(0x102a0e4, 0x102a0e8, arm64_l_102a0e8);
arm64_l_102a0e8:
	/* 0x102a0e8: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_102a0e8);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_43(struct state *);
extern unsigned char native_pc_43,native_next_43;
static void sim_43(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_102b0d4:
	/* 0x102b0d4: b 102b0e0 <native_pc_43+0xc> */
	ARM64_SIM_A64_JMP(0x102b0d4, 0x102b0e0, arm64_l_102b0e0);
arm64_l_102b0d8:
	/* 0x102b0d8: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_102b0dc:
	/* 0x102b0dc: b 102b0ec <outer_done_43> */
	ARM64_SIM_A64_JMP(0x102b0dc, 0x102b0ec, arm64_l_102b0ec);
arm64_l_102b0e0:
	/* 0x102b0e0: tbnz w1, #31, 102b0d8 <native_pc_43+0x4> */
	ARM64_SIM_A64_TBNZ(ARM64_X1, 31, 0x102b0e0, 0x102b0d8, arm64_l_102b0d8);
arm64_l_102b0e4:
	/* 0x102b0e4: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_102b0e8:
	/* 0x102b0e8: b 102b0ec <outer_done_43> */
	ARM64_SIM_A64_JMP(0x102b0e8, 0x102b0ec, arm64_l_102b0ec);
arm64_l_102b0ec:
	/* 0x102b0ec: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_102b0ec);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_44(struct state *);
extern unsigned char native_pc_44,native_next_44;
static void sim_44(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_102c0d4:
	/* 0x102c0d4: cbz x1, 102c0e0 <native_pc_44+0xc> */
	ARM64_SIM_A64_CBZ(ARM64_X1, 0x102c0d4, 0x102c0e0, arm64_l_102c0e0);
arm64_l_102c0d8:
	/* 0x102c0d8: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_102c0dc:
	/* 0x102c0dc: b 102c0e8 <outer_done_44> */
	ARM64_SIM_A64_JMP(0x102c0dc, 0x102c0e8, arm64_l_102c0e8);
arm64_l_102c0e0:
	/* 0x102c0e0: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_102c0e4:
	/* 0x102c0e4: b 102c0e8 <outer_done_44> */
	ARM64_SIM_A64_JMP(0x102c0e4, 0x102c0e8, arm64_l_102c0e8);
arm64_l_102c0e8:
	/* 0x102c0e8: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_102c0e8);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_45(struct state *);
extern unsigned char native_pc_45,native_next_45;
static void sim_45(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_102d0d4:
	/* 0x102d0d4: b 102d0e0 <native_pc_45+0xc> */
	ARM64_SIM_A64_JMP(0x102d0d4, 0x102d0e0, arm64_l_102d0e0);
arm64_l_102d0d8:
	/* 0x102d0d8: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_102d0dc:
	/* 0x102d0dc: b 102d0ec <outer_done_45> */
	ARM64_SIM_A64_JMP(0x102d0dc, 0x102d0ec, arm64_l_102d0ec);
arm64_l_102d0e0:
	/* 0x102d0e0: cbz x1, 102d0d8 <native_pc_45+0x4> */
	ARM64_SIM_A64_CBZ(ARM64_X1, 0x102d0e0, 0x102d0d8, arm64_l_102d0d8);
arm64_l_102d0e4:
	/* 0x102d0e4: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_102d0e8:
	/* 0x102d0e8: b 102d0ec <outer_done_45> */
	ARM64_SIM_A64_JMP(0x102d0e8, 0x102d0ec, arm64_l_102d0ec);
arm64_l_102d0ec:
	/* 0x102d0ec: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_102d0ec);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_46(struct state *);
extern unsigned char native_pc_46,native_next_46;
static void sim_46(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_102e0d4:
	/* 0x102e0d4: cbnz x1, 102e0e0 <native_pc_46+0xc> */
	ARM64_SIM_A64_CBNZ(ARM64_X1, 0x102e0d4, 0x102e0e0, arm64_l_102e0e0);
arm64_l_102e0d8:
	/* 0x102e0d8: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_102e0dc:
	/* 0x102e0dc: b 102e0e8 <outer_done_46> */
	ARM64_SIM_A64_JMP(0x102e0dc, 0x102e0e8, arm64_l_102e0e8);
arm64_l_102e0e0:
	/* 0x102e0e0: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_102e0e4:
	/* 0x102e0e4: b 102e0e8 <outer_done_46> */
	ARM64_SIM_A64_JMP(0x102e0e4, 0x102e0e8, arm64_l_102e0e8);
arm64_l_102e0e8:
	/* 0x102e0e8: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_102e0e8);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_47(struct state *);
extern unsigned char native_pc_47,native_next_47;
static void sim_47(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_102f0d4:
	/* 0x102f0d4: b 102f0e0 <native_pc_47+0xc> */
	ARM64_SIM_A64_JMP(0x102f0d4, 0x102f0e0, arm64_l_102f0e0);
arm64_l_102f0d8:
	/* 0x102f0d8: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_102f0dc:
	/* 0x102f0dc: b 102f0ec <outer_done_47> */
	ARM64_SIM_A64_JMP(0x102f0dc, 0x102f0ec, arm64_l_102f0ec);
arm64_l_102f0e0:
	/* 0x102f0e0: cbnz x1, 102f0d8 <native_pc_47+0x4> */
	ARM64_SIM_A64_CBNZ(ARM64_X1, 0x102f0e0, 0x102f0d8, arm64_l_102f0d8);
arm64_l_102f0e4:
	/* 0x102f0e4: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_102f0e8:
	/* 0x102f0e8: b 102f0ec <outer_done_47> */
	ARM64_SIM_A64_JMP(0x102f0e8, 0x102f0ec, arm64_l_102f0ec);
arm64_l_102f0ec:
	/* 0x102f0ec: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_102f0ec);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_48(struct state *);
extern unsigned char native_pc_48,native_next_48;
static void sim_48(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10300d4:
	/* 0x10300d4: tbz w1, #0, 10300e0 <native_pc_48+0xc> */
	ARM64_SIM_A64_TBZ(ARM64_X1, 0, 0x10300d4, 0x10300e0, arm64_l_10300e0);
arm64_l_10300d8:
	/* 0x10300d8: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10300dc:
	/* 0x10300dc: b 10300e8 <outer_done_48> */
	ARM64_SIM_A64_JMP(0x10300dc, 0x10300e8, arm64_l_10300e8);
arm64_l_10300e0:
	/* 0x10300e0: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10300e4:
	/* 0x10300e4: b 10300e8 <outer_done_48> */
	ARM64_SIM_A64_JMP(0x10300e4, 0x10300e8, arm64_l_10300e8);
arm64_l_10300e8:
	/* 0x10300e8: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10300e8);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_49(struct state *);
extern unsigned char native_pc_49,native_next_49;
static void sim_49(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10310d4:
	/* 0x10310d4: b 10310e0 <native_pc_49+0xc> */
	ARM64_SIM_A64_JMP(0x10310d4, 0x10310e0, arm64_l_10310e0);
arm64_l_10310d8:
	/* 0x10310d8: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10310dc:
	/* 0x10310dc: b 10310ec <outer_done_49> */
	ARM64_SIM_A64_JMP(0x10310dc, 0x10310ec, arm64_l_10310ec);
arm64_l_10310e0:
	/* 0x10310e0: tbz w1, #0, 10310d8 <native_pc_49+0x4> */
	ARM64_SIM_A64_TBZ(ARM64_X1, 0, 0x10310e0, 0x10310d8, arm64_l_10310d8);
arm64_l_10310e4:
	/* 0x10310e4: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10310e8:
	/* 0x10310e8: b 10310ec <outer_done_49> */
	ARM64_SIM_A64_JMP(0x10310e8, 0x10310ec, arm64_l_10310ec);
arm64_l_10310ec:
	/* 0x10310ec: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10310ec);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_50(struct state *);
extern unsigned char native_pc_50,native_next_50;
static void sim_50(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10320d4:
	/* 0x10320d4: tbz w1, #7, 10320e0 <native_pc_50+0xc> */
	ARM64_SIM_A64_TBZ(ARM64_X1, 7, 0x10320d4, 0x10320e0, arm64_l_10320e0);
arm64_l_10320d8:
	/* 0x10320d8: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10320dc:
	/* 0x10320dc: b 10320e8 <outer_done_50> */
	ARM64_SIM_A64_JMP(0x10320dc, 0x10320e8, arm64_l_10320e8);
arm64_l_10320e0:
	/* 0x10320e0: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10320e4:
	/* 0x10320e4: b 10320e8 <outer_done_50> */
	ARM64_SIM_A64_JMP(0x10320e4, 0x10320e8, arm64_l_10320e8);
arm64_l_10320e8:
	/* 0x10320e8: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10320e8);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_51(struct state *);
extern unsigned char native_pc_51,native_next_51;
static void sim_51(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10330d4:
	/* 0x10330d4: b 10330e0 <native_pc_51+0xc> */
	ARM64_SIM_A64_JMP(0x10330d4, 0x10330e0, arm64_l_10330e0);
arm64_l_10330d8:
	/* 0x10330d8: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10330dc:
	/* 0x10330dc: b 10330ec <outer_done_51> */
	ARM64_SIM_A64_JMP(0x10330dc, 0x10330ec, arm64_l_10330ec);
arm64_l_10330e0:
	/* 0x10330e0: tbz w1, #7, 10330d8 <native_pc_51+0x4> */
	ARM64_SIM_A64_TBZ(ARM64_X1, 7, 0x10330e0, 0x10330d8, arm64_l_10330d8);
arm64_l_10330e4:
	/* 0x10330e4: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10330e8:
	/* 0x10330e8: b 10330ec <outer_done_51> */
	ARM64_SIM_A64_JMP(0x10330e8, 0x10330ec, arm64_l_10330ec);
arm64_l_10330ec:
	/* 0x10330ec: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10330ec);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_52(struct state *);
extern unsigned char native_pc_52,native_next_52;
static void sim_52(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10340d4:
	/* 0x10340d4: tbz w1, #31, 10340e0 <native_pc_52+0xc> */
	ARM64_SIM_A64_TBZ(ARM64_X1, 31, 0x10340d4, 0x10340e0, arm64_l_10340e0);
arm64_l_10340d8:
	/* 0x10340d8: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10340dc:
	/* 0x10340dc: b 10340e8 <outer_done_52> */
	ARM64_SIM_A64_JMP(0x10340dc, 0x10340e8, arm64_l_10340e8);
arm64_l_10340e0:
	/* 0x10340e0: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10340e4:
	/* 0x10340e4: b 10340e8 <outer_done_52> */
	ARM64_SIM_A64_JMP(0x10340e4, 0x10340e8, arm64_l_10340e8);
arm64_l_10340e8:
	/* 0x10340e8: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10340e8);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_53(struct state *);
extern unsigned char native_pc_53,native_next_53;
static void sim_53(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10350d4:
	/* 0x10350d4: b 10350e0 <native_pc_53+0xc> */
	ARM64_SIM_A64_JMP(0x10350d4, 0x10350e0, arm64_l_10350e0);
arm64_l_10350d8:
	/* 0x10350d8: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10350dc:
	/* 0x10350dc: b 10350ec <outer_done_53> */
	ARM64_SIM_A64_JMP(0x10350dc, 0x10350ec, arm64_l_10350ec);
arm64_l_10350e0:
	/* 0x10350e0: tbz w1, #31, 10350d8 <native_pc_53+0x4> */
	ARM64_SIM_A64_TBZ(ARM64_X1, 31, 0x10350e0, 0x10350d8, arm64_l_10350d8);
arm64_l_10350e4:
	/* 0x10350e4: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10350e8:
	/* 0x10350e8: b 10350ec <outer_done_53> */
	ARM64_SIM_A64_JMP(0x10350e8, 0x10350ec, arm64_l_10350ec);
arm64_l_10350ec:
	/* 0x10350ec: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10350ec);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_54(struct state *);
extern unsigned char native_pc_54,native_next_54;
static void sim_54(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10360d4:
	/* 0x10360d4: tbz x1, #63, 10360e0 <native_pc_54+0xc> */
	ARM64_SIM_A64_TBZ(ARM64_X1, 63, 0x10360d4, 0x10360e0, arm64_l_10360e0);
arm64_l_10360d8:
	/* 0x10360d8: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10360dc:
	/* 0x10360dc: b 10360e8 <outer_done_54> */
	ARM64_SIM_A64_JMP(0x10360dc, 0x10360e8, arm64_l_10360e8);
arm64_l_10360e0:
	/* 0x10360e0: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10360e4:
	/* 0x10360e4: b 10360e8 <outer_done_54> */
	ARM64_SIM_A64_JMP(0x10360e4, 0x10360e8, arm64_l_10360e8);
arm64_l_10360e8:
	/* 0x10360e8: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10360e8);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_55(struct state *);
extern unsigned char native_pc_55,native_next_55;
static void sim_55(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10370d4:
	/* 0x10370d4: b 10370e0 <native_pc_55+0xc> */
	ARM64_SIM_A64_JMP(0x10370d4, 0x10370e0, arm64_l_10370e0);
arm64_l_10370d8:
	/* 0x10370d8: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10370dc:
	/* 0x10370dc: b 10370ec <outer_done_55> */
	ARM64_SIM_A64_JMP(0x10370dc, 0x10370ec, arm64_l_10370ec);
arm64_l_10370e0:
	/* 0x10370e0: tbz x1, #63, 10370d8 <native_pc_55+0x4> */
	ARM64_SIM_A64_TBZ(ARM64_X1, 63, 0x10370e0, 0x10370d8, arm64_l_10370d8);
arm64_l_10370e4:
	/* 0x10370e4: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10370e8:
	/* 0x10370e8: b 10370ec <outer_done_55> */
	ARM64_SIM_A64_JMP(0x10370e8, 0x10370ec, arm64_l_10370ec);
arm64_l_10370ec:
	/* 0x10370ec: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10370ec);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_56(struct state *);
extern unsigned char native_pc_56,native_next_56;
static void sim_56(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10380d4:
	/* 0x10380d4: tbnz w1, #0, 10380e0 <native_pc_56+0xc> */
	ARM64_SIM_A64_TBNZ(ARM64_X1, 0, 0x10380d4, 0x10380e0, arm64_l_10380e0);
arm64_l_10380d8:
	/* 0x10380d8: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10380dc:
	/* 0x10380dc: b 10380e8 <outer_done_56> */
	ARM64_SIM_A64_JMP(0x10380dc, 0x10380e8, arm64_l_10380e8);
arm64_l_10380e0:
	/* 0x10380e0: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10380e4:
	/* 0x10380e4: b 10380e8 <outer_done_56> */
	ARM64_SIM_A64_JMP(0x10380e4, 0x10380e8, arm64_l_10380e8);
arm64_l_10380e8:
	/* 0x10380e8: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10380e8);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_57(struct state *);
extern unsigned char native_pc_57,native_next_57;
static void sim_57(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10390d4:
	/* 0x10390d4: b 10390e0 <native_pc_57+0xc> */
	ARM64_SIM_A64_JMP(0x10390d4, 0x10390e0, arm64_l_10390e0);
arm64_l_10390d8:
	/* 0x10390d8: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10390dc:
	/* 0x10390dc: b 10390ec <outer_done_57> */
	ARM64_SIM_A64_JMP(0x10390dc, 0x10390ec, arm64_l_10390ec);
arm64_l_10390e0:
	/* 0x10390e0: tbnz w1, #0, 10390d8 <native_pc_57+0x4> */
	ARM64_SIM_A64_TBNZ(ARM64_X1, 0, 0x10390e0, 0x10390d8, arm64_l_10390d8);
arm64_l_10390e4:
	/* 0x10390e4: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10390e8:
	/* 0x10390e8: b 10390ec <outer_done_57> */
	ARM64_SIM_A64_JMP(0x10390e8, 0x10390ec, arm64_l_10390ec);
arm64_l_10390ec:
	/* 0x10390ec: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10390ec);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_58(struct state *);
extern unsigned char native_pc_58,native_next_58;
static void sim_58(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_103a0d4:
	/* 0x103a0d4: tbnz w1, #7, 103a0e0 <native_pc_58+0xc> */
	ARM64_SIM_A64_TBNZ(ARM64_X1, 7, 0x103a0d4, 0x103a0e0, arm64_l_103a0e0);
arm64_l_103a0d8:
	/* 0x103a0d8: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_103a0dc:
	/* 0x103a0dc: b 103a0e8 <outer_done_58> */
	ARM64_SIM_A64_JMP(0x103a0dc, 0x103a0e8, arm64_l_103a0e8);
arm64_l_103a0e0:
	/* 0x103a0e0: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_103a0e4:
	/* 0x103a0e4: b 103a0e8 <outer_done_58> */
	ARM64_SIM_A64_JMP(0x103a0e4, 0x103a0e8, arm64_l_103a0e8);
arm64_l_103a0e8:
	/* 0x103a0e8: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_103a0e8);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_59(struct state *);
extern unsigned char native_pc_59,native_next_59;
static void sim_59(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_103b0d4:
	/* 0x103b0d4: b 103b0e0 <native_pc_59+0xc> */
	ARM64_SIM_A64_JMP(0x103b0d4, 0x103b0e0, arm64_l_103b0e0);
arm64_l_103b0d8:
	/* 0x103b0d8: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_103b0dc:
	/* 0x103b0dc: b 103b0ec <outer_done_59> */
	ARM64_SIM_A64_JMP(0x103b0dc, 0x103b0ec, arm64_l_103b0ec);
arm64_l_103b0e0:
	/* 0x103b0e0: tbnz w1, #7, 103b0d8 <native_pc_59+0x4> */
	ARM64_SIM_A64_TBNZ(ARM64_X1, 7, 0x103b0e0, 0x103b0d8, arm64_l_103b0d8);
arm64_l_103b0e4:
	/* 0x103b0e4: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_103b0e8:
	/* 0x103b0e8: b 103b0ec <outer_done_59> */
	ARM64_SIM_A64_JMP(0x103b0e8, 0x103b0ec, arm64_l_103b0ec);
arm64_l_103b0ec:
	/* 0x103b0ec: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_103b0ec);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_60(struct state *);
extern unsigned char native_pc_60,native_next_60;
static void sim_60(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_103c0d4:
	/* 0x103c0d4: tbnz w1, #31, 103c0e0 <native_pc_60+0xc> */
	ARM64_SIM_A64_TBNZ(ARM64_X1, 31, 0x103c0d4, 0x103c0e0, arm64_l_103c0e0);
arm64_l_103c0d8:
	/* 0x103c0d8: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_103c0dc:
	/* 0x103c0dc: b 103c0e8 <outer_done_60> */
	ARM64_SIM_A64_JMP(0x103c0dc, 0x103c0e8, arm64_l_103c0e8);
arm64_l_103c0e0:
	/* 0x103c0e0: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_103c0e4:
	/* 0x103c0e4: b 103c0e8 <outer_done_60> */
	ARM64_SIM_A64_JMP(0x103c0e4, 0x103c0e8, arm64_l_103c0e8);
arm64_l_103c0e8:
	/* 0x103c0e8: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_103c0e8);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_61(struct state *);
extern unsigned char native_pc_61,native_next_61;
static void sim_61(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_103d0d4:
	/* 0x103d0d4: b 103d0e0 <native_pc_61+0xc> */
	ARM64_SIM_A64_JMP(0x103d0d4, 0x103d0e0, arm64_l_103d0e0);
arm64_l_103d0d8:
	/* 0x103d0d8: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_103d0dc:
	/* 0x103d0dc: b 103d0ec <outer_done_61> */
	ARM64_SIM_A64_JMP(0x103d0dc, 0x103d0ec, arm64_l_103d0ec);
arm64_l_103d0e0:
	/* 0x103d0e0: tbnz w1, #31, 103d0d8 <native_pc_61+0x4> */
	ARM64_SIM_A64_TBNZ(ARM64_X1, 31, 0x103d0e0, 0x103d0d8, arm64_l_103d0d8);
arm64_l_103d0e4:
	/* 0x103d0e4: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_103d0e8:
	/* 0x103d0e8: b 103d0ec <outer_done_61> */
	ARM64_SIM_A64_JMP(0x103d0e8, 0x103d0ec, arm64_l_103d0ec);
arm64_l_103d0ec:
	/* 0x103d0ec: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_103d0ec);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_62(struct state *);
extern unsigned char native_pc_62,native_next_62;
static void sim_62(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_103e0d4:
	/* 0x103e0d4: tbnz x1, #63, 103e0e0 <native_pc_62+0xc> */
	ARM64_SIM_A64_TBNZ(ARM64_X1, 63, 0x103e0d4, 0x103e0e0, arm64_l_103e0e0);
arm64_l_103e0d8:
	/* 0x103e0d8: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_103e0dc:
	/* 0x103e0dc: b 103e0e8 <outer_done_62> */
	ARM64_SIM_A64_JMP(0x103e0dc, 0x103e0e8, arm64_l_103e0e8);
arm64_l_103e0e0:
	/* 0x103e0e0: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_103e0e4:
	/* 0x103e0e4: b 103e0e8 <outer_done_62> */
	ARM64_SIM_A64_JMP(0x103e0e4, 0x103e0e8, arm64_l_103e0e8);
arm64_l_103e0e8:
	/* 0x103e0e8: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_103e0e8);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_63(struct state *);
extern unsigned char native_pc_63,native_next_63;
static void sim_63(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_103f0d4:
	/* 0x103f0d4: b 103f0e0 <native_pc_63+0xc> */
	ARM64_SIM_A64_JMP(0x103f0d4, 0x103f0e0, arm64_l_103f0e0);
arm64_l_103f0d8:
	/* 0x103f0d8: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_103f0dc:
	/* 0x103f0dc: b 103f0ec <outer_done_63> */
	ARM64_SIM_A64_JMP(0x103f0dc, 0x103f0ec, arm64_l_103f0ec);
arm64_l_103f0e0:
	/* 0x103f0e0: tbnz x1, #63, 103f0d8 <native_pc_63+0x4> */
	ARM64_SIM_A64_TBNZ(ARM64_X1, 63, 0x103f0e0, 0x103f0d8, arm64_l_103f0d8);
arm64_l_103f0e4:
	/* 0x103f0e4: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_103f0e8:
	/* 0x103f0e8: b 103f0ec <outer_done_63> */
	ARM64_SIM_A64_JMP(0x103f0e8, 0x103f0ec, arm64_l_103f0ec);
arm64_l_103f0ec:
	/* 0x103f0ec: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_103f0ec);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_64(struct state *);
extern unsigned char native_pc_64,native_next_64;
static void sim_64(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10400d4:
	/* 0x10400d4: cmp w1, w2; 0x10400d8: b.gt 10400e4 <native_pc_64+0x10> */
arm64_l_10400d8:
	ARM64_SIM_A64_CMP_GT(ARM64_OP_CMP_REG, ARM64_X1, ARM64_X2, ARM64_WIDTH_32, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0, arm64_l_10400e4);
arm64_l_10400dc:
	/* 0x10400dc: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10400e0:
	/* 0x10400e0: b 10400ec <outer_done_64> */
	ARM64_SIM_A64_JMP(0x10400e0, 0x10400ec, arm64_l_10400ec);
arm64_l_10400e4:
	/* 0x10400e4: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10400e8:
	/* 0x10400e8: b 10400ec <outer_done_64> */
	ARM64_SIM_A64_JMP(0x10400e8, 0x10400ec, arm64_l_10400ec);
arm64_l_10400ec:
	/* 0x10400ec: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10400ec);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_65(struct state *);
extern unsigned char native_pc_65,native_next_65;
static void sim_65(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10410d4:
	/* 0x10410d4: cmp x1, x2; 0x10410d8: b.gt 10410e4 <native_pc_65+0x10> */
arm64_l_10410d8:
	ARM64_SIM_A64_CMP_GT(ARM64_OP_CMP_REG, ARM64_X1, ARM64_X2, ARM64_WIDTH_64, ARM64_AUX_ALU(0, ARM64_MOD_NONE, 0), 0, arm64_l_10410e4);
arm64_l_10410dc:
	/* 0x10410dc: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10410e0:
	/* 0x10410e0: b 10410ec <outer_done_65> */
	ARM64_SIM_A64_JMP(0x10410e0, 0x10410ec, arm64_l_10410ec);
arm64_l_10410e4:
	/* 0x10410e4: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10410e8:
	/* 0x10410e8: b 10410ec <outer_done_65> */
	ARM64_SIM_A64_JMP(0x10410e8, 0x10410ec, arm64_l_10410ec);
arm64_l_10410ec:
	/* 0x10410ec: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10410ec);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_66(struct state *);
extern unsigned char native_pc_66,native_next_66;
static void sim_66(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10420d4:
	/* 0x10420d4: tbz w1, #0, 10420e0 <native_pc_66+0xc> */
	ARM64_SIM_A64_TBZ(ARM64_X1, 0, 0x10420d4, 0x10420e0, arm64_l_10420e0);
arm64_l_10420d8:
	/* 0x10420d8: adr x10, 10420e8 <native_pc_66+0x14> */
	ARM64_SIM_A64_ADR(ARM64_X10, 0x10420e8ULL);
arm64_l_10420dc:
	/* 0x10420dc: b 10420e4 <native_pc_66+0x10> */
	ARM64_SIM_A64_JMP(0x10420dc, 0x10420e4, arm64_l_10420e4);
arm64_l_10420e0:
	/* 0x10420e0: adr x10, 10420f0 <native_pc_66+0x1c> */
	ARM64_SIM_A64_ADR(ARM64_X10, 0x10420f0ULL);
arm64_l_10420e4:
	/* 0x10420e4: br x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			case 0x10420e8ULL: goto arm64_l_10420e8; break;
			case 0x10420f0ULL: goto arm64_l_10420f0; break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_10420e8:
	/* 0x10420e8: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10420ec:
	/* 0x10420ec: b 10420f8 <outer_done_66> */
	ARM64_SIM_A64_JMP(0x10420ec, 0x10420f8, arm64_l_10420f8);
arm64_l_10420f0:
	/* 0x10420f0: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10420f4:
	/* 0x10420f4: b 10420f8 <outer_done_66> */
	ARM64_SIM_A64_JMP(0x10420f4, 0x10420f8, arm64_l_10420f8);
arm64_l_10420f8:
	/* 0x10420f8: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10420f8);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_67(struct state *);
extern unsigned char native_pc_67,native_next_67;
static void sim_67(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10430d4:
	/* 0x10430d4: bl 10430dc <native_pc_67+0x8> */
	ARM64_SIM_A64_CALL(arm64_l_10430dc, 0x10430d8ULL);
arm64_l_10430d8:
	/* 0x10430d8: b 10430e4 <outer_done_67> */
	ARM64_SIM_A64_JMP(0x10430d8, 0x10430e4, arm64_l_10430e4);
arm64_l_10430dc:
	/* 0x10430dc: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10430e0:
	/* 0x10430e0: ret */
	ARM64_SIM_A64_RET_TO(ARM64_X30, ARM64_SIM_RET_CASES_10430e0);
arm64_l_10430e4:
	/* 0x10430e4: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10430e4);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_68(struct state *);
extern unsigned char native_pc_68,native_next_68;
static void sim_68(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10440d4:
	/* 0x10440d4: bl 10440dc <native_pc_68+0x8> */
	ARM64_SIM_A64_CALL(arm64_l_10440dc, 0x10440d8ULL);
arm64_l_10440d8:
	/* 0x10440d8: b 10440e8 <outer_done_68> */
	ARM64_SIM_A64_JMP(0x10440d8, 0x10440e8, arm64_l_10440e8);
arm64_l_10440dc:
	/* 0x10440dc: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10440e0:
	/* 0x10440e0: mov x17, x30 */
	ARM64_SIM_RUN_OP3(ARM64_OP_MOV_REG, ARM64_X17, ARM64_X30, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, 0, 0);
arm64_l_10440e4:
	/* 0x10440e4: ret x17 */
	ARM64_SIM_A64_RET_TO(ARM64_X17, ARM64_SIM_RET_CASES_10440e4);
arm64_l_10440e8:
	/* 0x10440e8: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10440e8);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_69(struct state *);
extern unsigned char native_pc_69,native_next_69;
static void sim_69(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10450d4:
	/* 0x10450d4: adr x10, 10450e0 <native_pc_69+0xc> */
	ARM64_SIM_A64_ADR(ARM64_X10, 0x10450e0ULL);
arm64_l_10450d8:
	/* 0x10450d8: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			case 0x10450e0ULL: ARM64_SIM_A64_CALL(arm64_l_10450e0, 0x10450dcULL); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_10450dc:
	/* 0x10450dc: b 10450e8 <outer_done_69> */
	ARM64_SIM_A64_JMP(0x10450dc, 0x10450e8, arm64_l_10450e8);
arm64_l_10450e0:
	/* 0x10450e0: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10450e4:
	/* 0x10450e4: ret */
	ARM64_SIM_A64_RET_TO(ARM64_X30, ARM64_SIM_RET_CASES_10450e4);
arm64_l_10450e8:
	/* 0x10450e8: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10450e8);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_70(struct state *);
extern unsigned char native_pc_70,native_next_70;
static void sim_70(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10460d4:
	/* 0x10460d4: bl 10460dc <native_pc_70+0x8> */
	ARM64_SIM_A64_CALL(arm64_l_10460dc, 0x10460d8ULL);
arm64_l_10460d8:
	/* 0x10460d8: b 10460f4 <outer_done_70> */
	ARM64_SIM_A64_JMP(0x10460d8, 0x10460f4, arm64_l_10460f4);
arm64_l_10460dc:
	/* 0x10460dc: stp x19, x30, [sp, #-16]! */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X19, ARM64_X30, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 18446744073709551600ULL);
arm64_l_10460e0:
	/* 0x10460e0: bl 10460ec <native_pc_70+0x18> */
	ARM64_SIM_A64_CALL(arm64_l_10460ec, 0x10460e4ULL);
arm64_l_10460e4:
	/* 0x10460e4: ldp x19, x30, [sp], #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X19, ARM64_X30, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 16ULL);
arm64_l_10460e8:
	/* 0x10460e8: ret */
	ARM64_SIM_A64_RET_TO(ARM64_X30, ARM64_SIM_RET_CASES_10460e8);
arm64_l_10460ec:
	/* 0x10460ec: eor x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_EOR, ARM64_MOD_NONE, 0), 0);
arm64_l_10460f0:
	/* 0x10460f0: ret */
	ARM64_SIM_A64_RET_TO(ARM64_X30, ARM64_SIM_RET_CASES_10460f0);
arm64_l_10460f4:
	/* 0x10460f4: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10460f4);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_71(struct state *);
extern unsigned char native_pc_71,native_next_71;
static void sim_71(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10470d4:
	/* 0x10470d4: bl 10470dc <native_pc_71+0x8> */
	ARM64_SIM_A64_CALL(arm64_l_10470dc, 0x10470d8ULL);
arm64_l_10470d8:
	/* 0x10470d8: b 10470f8 <outer_done_71> */
	ARM64_SIM_A64_JMP(0x10470d8, 0x10470f8, arm64_l_10470f8);
arm64_l_10470dc:
	/* 0x10470dc: str x30, [sp, #-16]! */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X30, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 18446744073709551600ULL);
arm64_l_10470e0:
	/* 0x10470e0: adr x10, 10470f0 <native_pc_71+0x1c> */
	ARM64_SIM_A64_ADR(ARM64_X10, 0x10470f0ULL);
arm64_l_10470e4:
	/* 0x10470e4: blr x10 */
	{
		__u64 __a64_target = ARM64_SIM_L_READ_REG(ARM64_X10);
		if (ARM64_SIM_L_REG_TAG(ARM64_X10) == ARM64_SIM_TAG_CODE) {
			switch (__a64_target) {
			case 0x10470f0ULL: ARM64_SIM_A64_CALL(arm64_l_10470f0, 0x10470e8ULL); break;
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		} else {
			switch (__a64_target) {
			default: ARM64_SIM_L_REJECT_PC(); break;
			}
		}
	}
arm64_l_10470e8:
	/* 0x10470e8: ldr x30, [sp], #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X30, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 16ULL);
arm64_l_10470ec:
	/* 0x10470ec: ret */
	ARM64_SIM_A64_RET_TO(ARM64_X30, ARM64_SIM_RET_CASES_10470ec);
arm64_l_10470f0:
	/* 0x10470f0: add x0, x0, x2 */
	ARM64_SIM_RUN_OP3(ARM64_OP_ALU_REG, ARM64_X0, ARM64_X0, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_ALU(ARM64_ALU_ADD, ARM64_MOD_NONE, 0), 0);
arm64_l_10470f4:
	/* 0x10470f4: ret */
	ARM64_SIM_A64_RET_TO(ARM64_X30, ARM64_SIM_RET_CASES_10470f4);
arm64_l_10470f8:
	/* 0x10470f8: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10470f8);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_72(struct state *);
extern unsigned char native_pc_72,native_next_72;
static void sim_72(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10480d4:
	/* 0x10480d4: stp x1, x2, [sp, #-16]! */
	ARM64_SIM_RUN_OP3(ARM64_OP_STP, ARM64_SP, ARM64_X1, ARM64_X2, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 18446744073709551600ULL);
arm64_l_10480d8:
	/* 0x10480d8: ldp x0, x3, [sp], #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_LDP, ARM64_X0, ARM64_X3, ARM64_SP, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 16ULL);
arm64_l_10480dc:
	/* 0x10480dc: b 10480e0 <outer_done_72> */
	ARM64_SIM_A64_JMP(0x10480dc, 0x10480e0, arm64_l_10480e0);
arm64_l_10480e0:
	/* 0x10480e0: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10480e0);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



extern void native_73(struct state *);
extern unsigned char native_pc_73,native_next_73;
static void sim_73(struct state *s)
{
	ARM64_SIM_L_DECLARE_STATE(); ARM64_SIM_L_DECLARE_STACK(); __u8 __a64_sim_abi_kind=KPROG_ABI_KIND_XDP;
__a64_x0.x=s->r[0];
__a64_x1.x=s->r[1];
__a64_x2.x=s->r[2];
__a64_x3.x=s->r[3];
__a64_x4.x=s->r[4];
__a64_x5.x=s->r[5];
__a64_x6.x=s->r[6];
__a64_x7.x=s->r[7];
__a64_x8.x=s->r[8];
__a64_x9.x=s->r[9];
__a64_x10.x=s->r[10];
__a64_x11.x=s->r[11];
__a64_x12.x=s->r[12];
__a64_x13.x=s->r[13];
__a64_x14.x=s->r[14];
__a64_x15.x=s->r[15];
__a64_x16.x=s->r[16];
__a64_x17.x=s->r[17];
__a64_x18.x=s->r[18];
__a64_x19.x=s->r[19];
__a64_x20.x=s->r[20];
__a64_x21.x=s->r[21];
__a64_x22.x=s->r[22];
__a64_x23.x=s->r[23];
__a64_x24.x=s->r[24];
__a64_x25.x=s->r[25];
__a64_x26.x=s->r[26];
__a64_x27.x=s->r[27];
__a64_x28.x=s->r[28];
__a64_x29.x=s->r[29];
__a64_x30.x=s->r[30];
for (unsigned k=0;k<64;k++) __a64_stack.b[ARM64_SIM_STACK_BYTES-64+k]=s->stack[k];
__a64_n=(s->flags>>31)&1; __a64_z=(s->flags>>30)&1; __a64_c=(s->flags>>29)&1; __a64_v=(s->flags>>28)&1;
__a64_v0=s->vec[0]; __a64_v0_hi=s->vec[1];
arm64_l_10490d4:
	/* 0x10490d4: str x1, [sp, #-16]! */
	ARM64_SIM_RUN_OP3(ARM64_OP_STORE, ARM64_SP, ARM64_X1, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_PRE), 18446744073709551600ULL);
arm64_l_10490d8:
	/* 0x10490d8: ldr x0, [sp], #16 */
	ARM64_SIM_RUN_OP3(ARM64_OP_LOAD, ARM64_X0, ARM64_SP, ARM64_REG_NONE, ARM64_REG_NONE, ARM64_WIDTH_64, ARM64_AUX_MEM(ARM64_REG_NONE, ARM64_MOD_NONE, 0, ARM64_MEM_POST), 16ULL);
arm64_l_10490dc:
	/* 0x10490dc: b 10490e0 <outer_done_73> */
	ARM64_SIM_A64_JMP(0x10490dc, 0x10490e0, arm64_l_10490e0);
arm64_l_10490e0:
	/* 0x10490e0: ret x20 (outer observation) */
	ARM64_SIM_A64_RET_TO(ARM64_X20, ARM64_SIM_RET_CASES_10490e0);
	goto observed;
observed:;
s->r[0]=__a64_x0.x;
s->r[1]=__a64_x1.x;
s->r[2]=__a64_x2.x;
s->r[3]=__a64_x3.x;
s->r[4]=__a64_x4.x;
s->r[5]=__a64_x5.x;
s->r[6]=__a64_x6.x;
s->r[7]=__a64_x7.x;
s->r[8]=__a64_x8.x;
s->r[9]=__a64_x9.x;
s->r[10]=__a64_x10.x;
s->r[11]=__a64_x11.x;
s->r[12]=__a64_x12.x;
s->r[13]=__a64_x13.x;
s->r[14]=__a64_x14.x;
s->r[15]=__a64_x15.x;
s->r[16]=__a64_x16.x;
s->r[17]=__a64_x17.x;
s->r[18]=__a64_x18.x;
s->r[19]=__a64_x19.x;
s->r[20]=__a64_x20.x;
s->r[21]=__a64_x21.x;
s->r[22]=__a64_x22.x;
s->r[23]=__a64_x23.x;
s->r[24]=__a64_x24.x;
s->r[25]=__a64_x25.x;
s->r[26]=__a64_x26.x;
s->r[27]=__a64_x27.x;
s->r[28]=__a64_x28.x;
s->r[29]=__a64_x29.x;
s->r[30]=__a64_x30.x;
s->r[31]=__a64_sp;
s->flags=((uint64_t)__a64_n<<31)|((uint64_t)__a64_z<<30)|((uint64_t)__a64_c<<29)|((uint64_t)__a64_v<<28);
s->vec[0]=__a64_v0; s->vec[1]=__a64_v0_hi;
for (unsigned k=0;k<64;k++) s->stack[k]=__a64_stack.b[ARM64_SIM_STACK_BYTES-64+k];
}



const struct form forms[]={
{"b.eq forward","ARM64_CONTROL",native_0,sim_0,0xf0000000U,64,0,6,&native_pc_0,&native_next_0},
{"b.eq backward","ARM64_CONTROL",native_1,sim_1,0xf0000000U,64,0,6,&native_pc_1,&native_next_1},
{"b.ne forward","ARM64_CONTROL",native_2,sim_2,0xf0000000U,64,0,6,&native_pc_2,&native_next_2},
{"b.ne backward","ARM64_CONTROL",native_3,sim_3,0xf0000000U,64,0,6,&native_pc_3,&native_next_3},
{"b.cs forward","ARM64_CONTROL",native_4,sim_4,0xf0000000U,64,0,6,&native_pc_4,&native_next_4},
{"b.cs backward","ARM64_CONTROL",native_5,sim_5,0xf0000000U,64,0,6,&native_pc_5,&native_next_5},
{"b.cc forward","ARM64_CONTROL",native_6,sim_6,0xf0000000U,64,0,6,&native_pc_6,&native_next_6},
{"b.cc backward","ARM64_CONTROL",native_7,sim_7,0xf0000000U,64,0,6,&native_pc_7,&native_next_7},
{"b.mi forward","ARM64_CONTROL",native_8,sim_8,0xf0000000U,64,0,6,&native_pc_8,&native_next_8},
{"b.mi backward","ARM64_CONTROL",native_9,sim_9,0xf0000000U,64,0,6,&native_pc_9,&native_next_9},
{"b.pl forward","ARM64_CONTROL",native_10,sim_10,0xf0000000U,64,0,6,&native_pc_10,&native_next_10},
{"b.pl backward","ARM64_CONTROL",native_11,sim_11,0xf0000000U,64,0,6,&native_pc_11,&native_next_11},
{"b.vs forward","ARM64_CONTROL",native_12,sim_12,0xf0000000U,64,0,6,&native_pc_12,&native_next_12},
{"b.vs backward","ARM64_CONTROL",native_13,sim_13,0xf0000000U,64,0,6,&native_pc_13,&native_next_13},
{"b.vc forward","ARM64_CONTROL",native_14,sim_14,0xf0000000U,64,0,6,&native_pc_14,&native_next_14},
{"b.vc backward","ARM64_CONTROL",native_15,sim_15,0xf0000000U,64,0,6,&native_pc_15,&native_next_15},
{"b.hi forward","ARM64_CONTROL",native_16,sim_16,0xf0000000U,64,0,6,&native_pc_16,&native_next_16},
{"b.hi backward","ARM64_CONTROL",native_17,sim_17,0xf0000000U,64,0,6,&native_pc_17,&native_next_17},
{"b.ls forward","ARM64_CONTROL",native_18,sim_18,0xf0000000U,64,0,6,&native_pc_18,&native_next_18},
{"b.ls backward","ARM64_CONTROL",native_19,sim_19,0xf0000000U,64,0,6,&native_pc_19,&native_next_19},
{"b.ge forward","ARM64_CONTROL",native_20,sim_20,0xf0000000U,64,0,6,&native_pc_20,&native_next_20},
{"b.ge backward","ARM64_CONTROL",native_21,sim_21,0xf0000000U,64,0,6,&native_pc_21,&native_next_21},
{"b.lt forward","ARM64_CONTROL",native_22,sim_22,0xf0000000U,64,0,6,&native_pc_22,&native_next_22},
{"b.lt backward","ARM64_CONTROL",native_23,sim_23,0xf0000000U,64,0,6,&native_pc_23,&native_next_23},
{"b.gt forward","ARM64_CONTROL",native_24,sim_24,0xf0000000U,64,0,6,&native_pc_24,&native_next_24},
{"b.gt backward","ARM64_CONTROL",native_25,sim_25,0xf0000000U,64,0,6,&native_pc_25,&native_next_25},
{"b.le forward","ARM64_CONTROL",native_26,sim_26,0xf0000000U,64,0,6,&native_pc_26,&native_next_26},
{"b.le backward","ARM64_CONTROL",native_27,sim_27,0xf0000000U,64,0,6,&native_pc_27,&native_next_27},
{"cbz w1 False","ARM64_CONTROL",native_28,sim_28,0xf0000000U,64,0,6,&native_pc_28,&native_next_28},
{"cbz w1 True","ARM64_CONTROL",native_29,sim_29,0xf0000000U,64,0,6,&native_pc_29,&native_next_29},
{"cbnz w1 False","ARM64_CONTROL",native_30,sim_30,0xf0000000U,64,0,6,&native_pc_30,&native_next_30},
{"cbnz w1 True","ARM64_CONTROL",native_31,sim_31,0xf0000000U,64,0,6,&native_pc_31,&native_next_31},
{"tbz w1 #0 False","ARM64_CONTROL",native_32,sim_32,0xf0000000U,64,0,6,&native_pc_32,&native_next_32},
{"tbz w1 #0 True","ARM64_CONTROL",native_33,sim_33,0xf0000000U,64,0,6,&native_pc_33,&native_next_33},
{"tbz w1 #7 False","ARM64_CONTROL",native_34,sim_34,0xf0000000U,64,0,6,&native_pc_34,&native_next_34},
{"tbz w1 #7 True","ARM64_CONTROL",native_35,sim_35,0xf0000000U,64,0,6,&native_pc_35,&native_next_35},
{"tbz w1 #31 False","ARM64_CONTROL",native_36,sim_36,0xf0000000U,64,0,6,&native_pc_36,&native_next_36},
{"tbz w1 #31 True","ARM64_CONTROL",native_37,sim_37,0xf0000000U,64,0,6,&native_pc_37,&native_next_37},
{"tbnz w1 #0 False","ARM64_CONTROL",native_38,sim_38,0xf0000000U,64,0,6,&native_pc_38,&native_next_38},
{"tbnz w1 #0 True","ARM64_CONTROL",native_39,sim_39,0xf0000000U,64,0,6,&native_pc_39,&native_next_39},
{"tbnz w1 #7 False","ARM64_CONTROL",native_40,sim_40,0xf0000000U,64,0,6,&native_pc_40,&native_next_40},
{"tbnz w1 #7 True","ARM64_CONTROL",native_41,sim_41,0xf0000000U,64,0,6,&native_pc_41,&native_next_41},
{"tbnz w1 #31 False","ARM64_CONTROL",native_42,sim_42,0xf0000000U,64,0,6,&native_pc_42,&native_next_42},
{"tbnz w1 #31 True","ARM64_CONTROL",native_43,sim_43,0xf0000000U,64,0,6,&native_pc_43,&native_next_43},
{"cbz x1 False","ARM64_CONTROL",native_44,sim_44,0xf0000000U,64,0,6,&native_pc_44,&native_next_44},
{"cbz x1 True","ARM64_CONTROL",native_45,sim_45,0xf0000000U,64,0,6,&native_pc_45,&native_next_45},
{"cbnz x1 False","ARM64_CONTROL",native_46,sim_46,0xf0000000U,64,0,6,&native_pc_46,&native_next_46},
{"cbnz x1 True","ARM64_CONTROL",native_47,sim_47,0xf0000000U,64,0,6,&native_pc_47,&native_next_47},
{"tbz x1 #0 False","ARM64_CONTROL",native_48,sim_48,0xf0000000U,64,0,6,&native_pc_48,&native_next_48},
{"tbz x1 #0 True","ARM64_CONTROL",native_49,sim_49,0xf0000000U,64,0,6,&native_pc_49,&native_next_49},
{"tbz x1 #7 False","ARM64_CONTROL",native_50,sim_50,0xf0000000U,64,0,6,&native_pc_50,&native_next_50},
{"tbz x1 #7 True","ARM64_CONTROL",native_51,sim_51,0xf0000000U,64,0,6,&native_pc_51,&native_next_51},
{"tbz x1 #31 False","ARM64_CONTROL",native_52,sim_52,0xf0000000U,64,0,6,&native_pc_52,&native_next_52},
{"tbz x1 #31 True","ARM64_CONTROL",native_53,sim_53,0xf0000000U,64,0,6,&native_pc_53,&native_next_53},
{"tbz x1 #63 False","ARM64_CONTROL",native_54,sim_54,0xf0000000U,64,0,6,&native_pc_54,&native_next_54},
{"tbz x1 #63 True","ARM64_CONTROL",native_55,sim_55,0xf0000000U,64,0,6,&native_pc_55,&native_next_55},
{"tbnz x1 #0 False","ARM64_CONTROL",native_56,sim_56,0xf0000000U,64,0,6,&native_pc_56,&native_next_56},
{"tbnz x1 #0 True","ARM64_CONTROL",native_57,sim_57,0xf0000000U,64,0,6,&native_pc_57,&native_next_57},
{"tbnz x1 #7 False","ARM64_CONTROL",native_58,sim_58,0xf0000000U,64,0,6,&native_pc_58,&native_next_58},
{"tbnz x1 #7 True","ARM64_CONTROL",native_59,sim_59,0xf0000000U,64,0,6,&native_pc_59,&native_next_59},
{"tbnz x1 #31 False","ARM64_CONTROL",native_60,sim_60,0xf0000000U,64,0,6,&native_pc_60,&native_next_60},
{"tbnz x1 #31 True","ARM64_CONTROL",native_61,sim_61,0xf0000000U,64,0,6,&native_pc_61,&native_next_61},
{"tbnz x1 #63 False","ARM64_CONTROL",native_62,sim_62,0xf0000000U,64,0,6,&native_pc_62,&native_next_62},
{"tbnz x1 #63 True","ARM64_CONTROL",native_63,sim_63,0xf0000000U,64,0,6,&native_pc_63,&native_next_63},
{"cmp w1,w2 / b.gt","ARM64_CONTROL",native_64,sim_64,0xf0000000U,64,0,6,&native_pc_64,&native_next_64},
{"cmp x1,x2 / b.gt","ARM64_CONTROL",native_65,sim_65,0xf0000000U,64,0,6,&native_pc_65,&native_next_65},
{"BR finite code choice","ARM64_CONTROL",native_66,sim_66,0xf0000000U,64,0,6,&native_pc_66,&native_next_66},
{"BL / RET x30","ARM64_CONTROL",native_67,sim_67,0xf0000000U,64,0,6,&native_pc_67,&native_next_67},
{"BL / RET x17","ARM64_CONTROL",native_68,sim_68,0xf0000000U,64,0,6,&native_pc_68,&native_next_68},
{"BLR code / RET","ARM64_CONTROL",native_69,sim_69,0xf0000000U,64,0,6,&native_pc_69,&native_next_69},
{"nested BL saved LR stack","ARM64_CONTROL",native_70,sim_70,0xf0000000U,64,0,6,&native_pc_70,&native_next_70},
{"BLR saved LR stack","ARM64_CONTROL",native_71,sim_71,0xf0000000U,64,0,6,&native_pc_71,&native_next_71},
{"stack pair pre/post","ARM64_CONTROL",native_72,sim_72,0xf0000000U,64,0,6,&native_pc_72,&native_next_72},
{"stack scalar pre/post","ARM64_CONTROL",native_73,sim_73,0xf0000000U,64,0,6,&native_pc_73,&native_next_73}
};
const unsigned form_count=sizeof(forms)/sizeof(forms[0]);
