
/workspaces/repository/kprog/fidelity/build-x86-division/instructions.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <.text>:
   0:	f6 f0                                           	div    al
   2:	f6 f1                                           	div    cl
   4:	f6 f2                                           	div    dl
   6:	f6 f3                                           	div    bl
   8:	f6 f4                                           	div    ah
   a:	f6 f5                                           	div    ch
   c:	f6 f6                                           	div    dh
   e:	f6 f7                                           	div    bh
  10:	40 f6 f6                                        	div    sil
  13:	40 f6 f7                                        	div    dil
  16:	41 f6 f0                                        	div    r8b
  19:	f6 77 08                                        	div    BYTE PTR [rdi+0x8]
  1c:	66 f7 f0                                        	div    ax
  1f:	66 f7 f1                                        	div    cx
  22:	66 f7 f2                                        	div    dx
  25:	66 f7 f3                                        	div    bx
  28:	66 41 f7 f0                                     	div    r8w
  2c:	66 f7 77 08                                     	div    WORD PTR [rdi+0x8]
  30:	f7 f0                                           	div    eax
  32:	f7 f1                                           	div    ecx
  34:	f7 f2                                           	div    edx
  36:	f7 f3                                           	div    ebx
  38:	41 f7 f0                                        	div    r8d
  3b:	f7 77 08                                        	div    DWORD PTR [rdi+0x8]
  3e:	48 f7 f0                                        	div    rax
  41:	48 f7 f1                                        	div    rcx
  44:	48 f7 f2                                        	div    rdx
  47:	48 f7 f3                                        	div    rbx
  4a:	49 f7 f0                                        	div    r8
  4d:	48 f7 77 08                                     	div    QWORD PTR [rdi+0x8]
