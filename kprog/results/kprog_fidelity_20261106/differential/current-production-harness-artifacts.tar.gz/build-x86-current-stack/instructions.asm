
build-x86-current-stack/instructions.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <.text>:
   0:	53                                              	push   rbx
   1:	58                                              	pop    rax
   2:	66 53                                           	push   bx
   4:	66 58                                           	pop    ax
   6:	90                                              	nop
   7:	48 98                                           	cdqe
   9:	0f 10 07                                        	movups xmm0,XMMWORD PTR [rdi]
   c:	0f 11 07                                        	movups XMMWORD PTR [rdi],xmm0
   f:	68 00 00 00 80                                  	push   0xffffffff80000000
  14:	6a 80                                           	push   0xffffffffffffff80
  16:	6a ff                                           	push   0xffffffffffffffff
  18:	6a 00                                           	push   0x0
  1a:	6a 01                                           	push   0x1
  1c:	6a 7f                                           	push   0x7f
  1e:	68 80 00 00 00                                  	push   0x80
  23:	68 78 56 34 12                                  	push   0x12345678
  28:	66 6a f9                                        	pushw  0xfff9
  2b:	ff 77 08                                        	push   QWORD PTR [rdi+0x8]
  2e:	66 ff 77 08                                     	push   WORD PTR [rdi+0x8]
  32:	8f 47 08                                        	pop    QWORD PTR [rdi+0x8]
  35:	66 8f 47 08                                     	pop    WORD PTR [rdi+0x8]
  39:	ff 74 24 f0                                     	push   QWORD PTR [rsp-0x10]
  3d:	8f 44 24 f0                                     	pop    QWORD PTR [rsp-0x10]
  41:	66 48 53                                        	data16 rex.W push rbx
  44:	48                                              	rex.W
  45:	66 53                                           	push   bx
  47:	66 48 ff f3                                     	data16 rex.W push rbx
  4b:	48                                              	rex.W
  4c:	66 ff f3                                        	push   bx
  4f:	66 48 58                                        	data16 rex.W pop rax
  52:	48                                              	rex.W
  53:	66 58                                           	pop    ax
  55:	66 48 8f c0                                     	data16 rex.W pop rax
  59:	48                                              	rex.W
  5a:	66 8f c0                                        	pop    ax
  5d:	88 d8                                           	mov    al,bl
  5f:	b0 7f                                           	mov    al,0x7f
  61:	88 47 08                                        	mov    BYTE PTR [rdi+0x8],al
  64:	8a 47 08                                        	mov    al,BYTE PTR [rdi+0x8]
  67:	c6 47 08 7f                                     	mov    BYTE PTR [rdi+0x8],0x7f
  6b:	00 d8                                           	add    al,bl
  6d:	04 7f                                           	add    al,0x7f
  6f:	00 47 08                                        	add    BYTE PTR [rdi+0x8],al
  72:	80 47 08 7f                                     	add    BYTE PTR [rdi+0x8],0x7f
  76:	02 47 08                                        	add    al,BYTE PTR [rdi+0x8]
  79:	10 d8                                           	adc    al,bl
  7b:	14 7f                                           	adc    al,0x7f
  7d:	10 47 08                                        	adc    BYTE PTR [rdi+0x8],al
  80:	80 57 08 7f                                     	adc    BYTE PTR [rdi+0x8],0x7f
  84:	12 47 08                                        	adc    al,BYTE PTR [rdi+0x8]
  87:	28 d8                                           	sub    al,bl
  89:	2c 7f                                           	sub    al,0x7f
  8b:	28 47 08                                        	sub    BYTE PTR [rdi+0x8],al
  8e:	80 6f 08 7f                                     	sub    BYTE PTR [rdi+0x8],0x7f
  92:	2a 47 08                                        	sub    al,BYTE PTR [rdi+0x8]
  95:	18 d8                                           	sbb    al,bl
  97:	1c 7f                                           	sbb    al,0x7f
  99:	18 47 08                                        	sbb    BYTE PTR [rdi+0x8],al
  9c:	80 5f 08 7f                                     	sbb    BYTE PTR [rdi+0x8],0x7f
  a0:	1a 47 08                                        	sbb    al,BYTE PTR [rdi+0x8]
  a3:	38 d8                                           	cmp    al,bl
  a5:	3c 7f                                           	cmp    al,0x7f
  a7:	38 47 08                                        	cmp    BYTE PTR [rdi+0x8],al
  aa:	80 7f 08 7f                                     	cmp    BYTE PTR [rdi+0x8],0x7f
  ae:	3a 47 08                                        	cmp    al,BYTE PTR [rdi+0x8]
  b1:	84 d8                                           	test   al,bl
  b3:	a8 7f                                           	test   al,0x7f
  b5:	84 47 08                                        	test   BYTE PTR [rdi+0x8],al
  b8:	f6 47 08 7f                                     	test   BYTE PTR [rdi+0x8],0x7f
  bc:	20 d8                                           	and    al,bl
  be:	24 7f                                           	and    al,0x7f
  c0:	22 47 08                                        	and    al,BYTE PTR [rdi+0x8]
  c3:	20 47 08                                        	and    BYTE PTR [rdi+0x8],al
  c6:	80 67 08 7f                                     	and    BYTE PTR [rdi+0x8],0x7f
  ca:	08 d8                                           	or     al,bl
  cc:	0c 7f                                           	or     al,0x7f
  ce:	0a 47 08                                        	or     al,BYTE PTR [rdi+0x8]
  d1:	08 47 08                                        	or     BYTE PTR [rdi+0x8],al
  d4:	80 4f 08 7f                                     	or     BYTE PTR [rdi+0x8],0x7f
  d8:	30 d8                                           	xor    al,bl
  da:	34 7f                                           	xor    al,0x7f
  dc:	32 47 08                                        	xor    al,BYTE PTR [rdi+0x8]
  df:	30 47 08                                        	xor    BYTE PTR [rdi+0x8],al
  e2:	80 77 08 7f                                     	xor    BYTE PTR [rdi+0x8],0x7f
  e6:	fe c0                                           	inc    al
  e8:	fe 47 08                                        	inc    BYTE PTR [rdi+0x8]
  eb:	fe c8                                           	dec    al
  ed:	fe 4f 08                                        	dec    BYTE PTR [rdi+0x8]
  f0:	f6 d8                                           	neg    al
  f2:	f6 5f 08                                        	neg    BYTE PTR [rdi+0x8]
  f5:	f6 d0                                           	not    al
  f7:	f6 57 08                                        	not    BYTE PTR [rdi+0x8]
  fa:	86 d8                                           	xchg   al,bl
  fc:	c0 e0 00                                        	shl    al,0x0
  ff:	d0 e0                                           	shl    al,1
 101:	c0 e0 07                                        	shl    al,0x7
 104:	c0 e0 08                                        	shl    al,0x8
 107:	c0 e0 0f                                        	shl    al,0xf
 10a:	c0 e0 10                                        	shl    al,0x10
 10d:	c0 e0 1f                                        	shl    al,0x1f
 110:	c0 e0 20                                        	shl    al,0x20
 113:	c0 e0 3f                                        	shl    al,0x3f
 116:	c0 e0 40                                        	shl    al,0x40
 119:	c0 e0 ff                                        	shl    al,0xff
 11c:	d2 e0                                           	shl    al,cl
 11e:	c0 e8 00                                        	shr    al,0x0
 121:	d0 e8                                           	shr    al,1
 123:	c0 e8 07                                        	shr    al,0x7
 126:	c0 e8 08                                        	shr    al,0x8
 129:	c0 e8 0f                                        	shr    al,0xf
 12c:	c0 e8 10                                        	shr    al,0x10
 12f:	c0 e8 1f                                        	shr    al,0x1f
 132:	c0 e8 20                                        	shr    al,0x20
 135:	c0 e8 3f                                        	shr    al,0x3f
 138:	c0 e8 40                                        	shr    al,0x40
 13b:	c0 e8 ff                                        	shr    al,0xff
 13e:	d2 e8                                           	shr    al,cl
 140:	c0 f8 00                                        	sar    al,0x0
 143:	d0 f8                                           	sar    al,1
 145:	c0 f8 07                                        	sar    al,0x7
 148:	c0 f8 08                                        	sar    al,0x8
 14b:	c0 f8 0f                                        	sar    al,0xf
 14e:	c0 f8 10                                        	sar    al,0x10
 151:	c0 f8 1f                                        	sar    al,0x1f
 154:	c0 f8 20                                        	sar    al,0x20
 157:	c0 f8 3f                                        	sar    al,0x3f
 15a:	c0 f8 40                                        	sar    al,0x40
 15d:	c0 f8 ff                                        	sar    al,0xff
 160:	d2 f8                                           	sar    al,cl
 162:	c0 c0 00                                        	rol    al,0x0
 165:	d0 c0                                           	rol    al,1
 167:	c0 c0 07                                        	rol    al,0x7
 16a:	c0 c0 08                                        	rol    al,0x8
 16d:	c0 c0 0f                                        	rol    al,0xf
 170:	c0 c0 10                                        	rol    al,0x10
 173:	c0 c0 1f                                        	rol    al,0x1f
 176:	c0 c0 20                                        	rol    al,0x20
 179:	c0 c0 3f                                        	rol    al,0x3f
 17c:	c0 c0 40                                        	rol    al,0x40
 17f:	c0 c0 ff                                        	rol    al,0xff
 182:	d2 c0                                           	rol    al,cl
 184:	66 89 d8                                        	mov    ax,bx
 187:	66 b8 7f 00                                     	mov    ax,0x7f
 18b:	66 89 47 08                                     	mov    WORD PTR [rdi+0x8],ax
 18f:	66 8b 47 08                                     	mov    ax,WORD PTR [rdi+0x8]
 193:	66 c7 47 08 7f 00                               	mov    WORD PTR [rdi+0x8],0x7f
 199:	66 01 d8                                        	add    ax,bx
 19c:	66 83 c0 7f                                     	add    ax,0x7f
 1a0:	66 01 47 08                                     	add    WORD PTR [rdi+0x8],ax
 1a4:	66 83 47 08 7f                                  	add    WORD PTR [rdi+0x8],0x7f
 1a9:	66 03 47 08                                     	add    ax,WORD PTR [rdi+0x8]
 1ad:	66 11 d8                                        	adc    ax,bx
 1b0:	66 83 d0 7f                                     	adc    ax,0x7f
 1b4:	66 11 47 08                                     	adc    WORD PTR [rdi+0x8],ax
 1b8:	66 83 57 08 7f                                  	adc    WORD PTR [rdi+0x8],0x7f
 1bd:	66 13 47 08                                     	adc    ax,WORD PTR [rdi+0x8]
 1c1:	66 29 d8                                        	sub    ax,bx
 1c4:	66 83 e8 7f                                     	sub    ax,0x7f
 1c8:	66 29 47 08                                     	sub    WORD PTR [rdi+0x8],ax
 1cc:	66 83 6f 08 7f                                  	sub    WORD PTR [rdi+0x8],0x7f
 1d1:	66 2b 47 08                                     	sub    ax,WORD PTR [rdi+0x8]
 1d5:	66 19 d8                                        	sbb    ax,bx
 1d8:	66 83 d8 7f                                     	sbb    ax,0x7f
 1dc:	66 19 47 08                                     	sbb    WORD PTR [rdi+0x8],ax
 1e0:	66 83 5f 08 7f                                  	sbb    WORD PTR [rdi+0x8],0x7f
 1e5:	66 1b 47 08                                     	sbb    ax,WORD PTR [rdi+0x8]
 1e9:	66 39 d8                                        	cmp    ax,bx
 1ec:	66 83 f8 7f                                     	cmp    ax,0x7f
 1f0:	66 39 47 08                                     	cmp    WORD PTR [rdi+0x8],ax
 1f4:	66 83 7f 08 7f                                  	cmp    WORD PTR [rdi+0x8],0x7f
 1f9:	66 3b 47 08                                     	cmp    ax,WORD PTR [rdi+0x8]
 1fd:	66 85 d8                                        	test   ax,bx
 200:	66 a9 7f 00                                     	test   ax,0x7f
 204:	66 85 47 08                                     	test   WORD PTR [rdi+0x8],ax
 208:	66 f7 47 08 7f 00                               	test   WORD PTR [rdi+0x8],0x7f
 20e:	66 21 d8                                        	and    ax,bx
 211:	66 83 e0 7f                                     	and    ax,0x7f
 215:	66 23 47 08                                     	and    ax,WORD PTR [rdi+0x8]
 219:	66 21 47 08                                     	and    WORD PTR [rdi+0x8],ax
 21d:	66 83 67 08 7f                                  	and    WORD PTR [rdi+0x8],0x7f
 222:	66 09 d8                                        	or     ax,bx
 225:	66 83 c8 7f                                     	or     ax,0x7f
 229:	66 0b 47 08                                     	or     ax,WORD PTR [rdi+0x8]
 22d:	66 09 47 08                                     	or     WORD PTR [rdi+0x8],ax
 231:	66 83 4f 08 7f                                  	or     WORD PTR [rdi+0x8],0x7f
 236:	66 31 d8                                        	xor    ax,bx
 239:	66 83 f0 7f                                     	xor    ax,0x7f
 23d:	66 33 47 08                                     	xor    ax,WORD PTR [rdi+0x8]
 241:	66 31 47 08                                     	xor    WORD PTR [rdi+0x8],ax
 245:	66 83 77 08 7f                                  	xor    WORD PTR [rdi+0x8],0x7f
 24a:	66 ff c0                                        	inc    ax
 24d:	66 ff 47 08                                     	inc    WORD PTR [rdi+0x8]
 251:	66 ff c8                                        	dec    ax
 254:	66 ff 4f 08                                     	dec    WORD PTR [rdi+0x8]
 258:	66 f7 d8                                        	neg    ax
 25b:	66 f7 5f 08                                     	neg    WORD PTR [rdi+0x8]
 25f:	66 f7 d0                                        	not    ax
 262:	66 f7 57 08                                     	not    WORD PTR [rdi+0x8]
 266:	66 93                                           	xchg   bx,ax
 268:	66 c1 e0 00                                     	shl    ax,0x0
 26c:	66 d1 e0                                        	shl    ax,1
 26f:	66 c1 e0 07                                     	shl    ax,0x7
 273:	66 c1 e0 08                                     	shl    ax,0x8
 277:	66 c1 e0 0f                                     	shl    ax,0xf
 27b:	66 c1 e0 10                                     	shl    ax,0x10
 27f:	66 c1 e0 1f                                     	shl    ax,0x1f
 283:	66 c1 e0 20                                     	shl    ax,0x20
 287:	66 c1 e0 3f                                     	shl    ax,0x3f
 28b:	66 c1 e0 40                                     	shl    ax,0x40
 28f:	66 c1 e0 ff                                     	shl    ax,0xff
 293:	66 d3 e0                                        	shl    ax,cl
 296:	66 c1 e8 00                                     	shr    ax,0x0
 29a:	66 d1 e8                                        	shr    ax,1
 29d:	66 c1 e8 07                                     	shr    ax,0x7
 2a1:	66 c1 e8 08                                     	shr    ax,0x8
 2a5:	66 c1 e8 0f                                     	shr    ax,0xf
 2a9:	66 c1 e8 10                                     	shr    ax,0x10
 2ad:	66 c1 e8 1f                                     	shr    ax,0x1f
 2b1:	66 c1 e8 20                                     	shr    ax,0x20
 2b5:	66 c1 e8 3f                                     	shr    ax,0x3f
 2b9:	66 c1 e8 40                                     	shr    ax,0x40
 2bd:	66 c1 e8 ff                                     	shr    ax,0xff
 2c1:	66 d3 e8                                        	shr    ax,cl
 2c4:	66 c1 f8 00                                     	sar    ax,0x0
 2c8:	66 d1 f8                                        	sar    ax,1
 2cb:	66 c1 f8 07                                     	sar    ax,0x7
 2cf:	66 c1 f8 08                                     	sar    ax,0x8
 2d3:	66 c1 f8 0f                                     	sar    ax,0xf
 2d7:	66 c1 f8 10                                     	sar    ax,0x10
 2db:	66 c1 f8 1f                                     	sar    ax,0x1f
 2df:	66 c1 f8 20                                     	sar    ax,0x20
 2e3:	66 c1 f8 3f                                     	sar    ax,0x3f
 2e7:	66 c1 f8 40                                     	sar    ax,0x40
 2eb:	66 c1 f8 ff                                     	sar    ax,0xff
 2ef:	66 d3 f8                                        	sar    ax,cl
 2f2:	66 c1 c0 00                                     	rol    ax,0x0
 2f6:	66 d1 c0                                        	rol    ax,1
 2f9:	66 c1 c0 07                                     	rol    ax,0x7
 2fd:	66 c1 c0 08                                     	rol    ax,0x8
 301:	66 c1 c0 0f                                     	rol    ax,0xf
 305:	66 c1 c0 10                                     	rol    ax,0x10
 309:	66 c1 c0 1f                                     	rol    ax,0x1f
 30d:	66 c1 c0 20                                     	rol    ax,0x20
 311:	66 c1 c0 3f                                     	rol    ax,0x3f
 315:	66 c1 c0 40                                     	rol    ax,0x40
 319:	66 c1 c0 ff                                     	rol    ax,0xff
 31d:	66 d3 c0                                        	rol    ax,cl
 320:	66 0f af c3                                     	imul   ax,bx
 324:	66 0f af 47 08                                  	imul   ax,WORD PTR [rdi+0x8]
 329:	66 6b c3 f9                                     	imul   ax,bx,0xfff9
 32d:	66 6b 47 08 f9                                  	imul   ax,WORD PTR [rdi+0x8],0xfff9
 332:	66 f3 0f b8 c3                                  	popcnt ax,bx
 337:	66 f7 f3                                        	div    bx
 33a:	66 0f a3 d8                                     	bt     ax,bx
 33e:	66 0f ba e0 07                                  	bt     ax,0x7
 343:	66 0f ba 67 08 07                               	bt     WORD PTR [rdi+0x8],0x7
 349:	66 0f 38 f0 47 08                               	movbe  ax,WORD PTR [rdi+0x8]
 34f:	66 0f 38 f1 47 08                               	movbe  WORD PTR [rdi+0x8],ax
 355:	66 0f a4 d8 00                                  	shld   ax,bx,0x0
 35a:	66 0f a4 d8 01                                  	shld   ax,bx,0x1
 35f:	66 0f a4 d8 07                                  	shld   ax,bx,0x7
 364:	66 0f a4 d8 0f                                  	shld   ax,bx,0xf
 369:	66 0f ac d8 00                                  	shrd   ax,bx,0x0
 36e:	66 0f ac d8 01                                  	shrd   ax,bx,0x1
 373:	66 0f ac d8 07                                  	shrd   ax,bx,0x7
 378:	66 0f ac d8 0f                                  	shrd   ax,bx,0xf
 37d:	89 d8                                           	mov    eax,ebx
 37f:	b8 7f 00 00 00                                  	mov    eax,0x7f
 384:	89 47 08                                        	mov    DWORD PTR [rdi+0x8],eax
 387:	8b 47 08                                        	mov    eax,DWORD PTR [rdi+0x8]
 38a:	c7 47 08 7f 00 00 00                            	mov    DWORD PTR [rdi+0x8],0x7f
 391:	01 d8                                           	add    eax,ebx
 393:	83 c0 7f                                        	add    eax,0x7f
 396:	01 47 08                                        	add    DWORD PTR [rdi+0x8],eax
 399:	83 47 08 7f                                     	add    DWORD PTR [rdi+0x8],0x7f
 39d:	03 47 08                                        	add    eax,DWORD PTR [rdi+0x8]
 3a0:	11 d8                                           	adc    eax,ebx
 3a2:	83 d0 7f                                        	adc    eax,0x7f
 3a5:	11 47 08                                        	adc    DWORD PTR [rdi+0x8],eax
 3a8:	83 57 08 7f                                     	adc    DWORD PTR [rdi+0x8],0x7f
 3ac:	13 47 08                                        	adc    eax,DWORD PTR [rdi+0x8]
 3af:	29 d8                                           	sub    eax,ebx
 3b1:	83 e8 7f                                        	sub    eax,0x7f
 3b4:	29 47 08                                        	sub    DWORD PTR [rdi+0x8],eax
 3b7:	83 6f 08 7f                                     	sub    DWORD PTR [rdi+0x8],0x7f
 3bb:	2b 47 08                                        	sub    eax,DWORD PTR [rdi+0x8]
 3be:	19 d8                                           	sbb    eax,ebx
 3c0:	83 d8 7f                                        	sbb    eax,0x7f
 3c3:	19 47 08                                        	sbb    DWORD PTR [rdi+0x8],eax
 3c6:	83 5f 08 7f                                     	sbb    DWORD PTR [rdi+0x8],0x7f
 3ca:	1b 47 08                                        	sbb    eax,DWORD PTR [rdi+0x8]
 3cd:	39 d8                                           	cmp    eax,ebx
 3cf:	83 f8 7f                                        	cmp    eax,0x7f
 3d2:	39 47 08                                        	cmp    DWORD PTR [rdi+0x8],eax
 3d5:	83 7f 08 7f                                     	cmp    DWORD PTR [rdi+0x8],0x7f
 3d9:	3b 47 08                                        	cmp    eax,DWORD PTR [rdi+0x8]
 3dc:	85 d8                                           	test   eax,ebx
 3de:	a9 7f 00 00 00                                  	test   eax,0x7f
 3e3:	85 47 08                                        	test   DWORD PTR [rdi+0x8],eax
 3e6:	f7 47 08 7f 00 00 00                            	test   DWORD PTR [rdi+0x8],0x7f
 3ed:	21 d8                                           	and    eax,ebx
 3ef:	83 e0 7f                                        	and    eax,0x7f
 3f2:	23 47 08                                        	and    eax,DWORD PTR [rdi+0x8]
 3f5:	21 47 08                                        	and    DWORD PTR [rdi+0x8],eax
 3f8:	83 67 08 7f                                     	and    DWORD PTR [rdi+0x8],0x7f
 3fc:	09 d8                                           	or     eax,ebx
 3fe:	83 c8 7f                                        	or     eax,0x7f
 401:	0b 47 08                                        	or     eax,DWORD PTR [rdi+0x8]
 404:	09 47 08                                        	or     DWORD PTR [rdi+0x8],eax
 407:	83 4f 08 7f                                     	or     DWORD PTR [rdi+0x8],0x7f
 40b:	31 d8                                           	xor    eax,ebx
 40d:	83 f0 7f                                        	xor    eax,0x7f
 410:	33 47 08                                        	xor    eax,DWORD PTR [rdi+0x8]
 413:	31 47 08                                        	xor    DWORD PTR [rdi+0x8],eax
 416:	83 77 08 7f                                     	xor    DWORD PTR [rdi+0x8],0x7f
 41a:	ff c0                                           	inc    eax
 41c:	ff 47 08                                        	inc    DWORD PTR [rdi+0x8]
 41f:	ff c8                                           	dec    eax
 421:	ff 4f 08                                        	dec    DWORD PTR [rdi+0x8]
 424:	f7 d8                                           	neg    eax
 426:	f7 5f 08                                        	neg    DWORD PTR [rdi+0x8]
 429:	f7 d0                                           	not    eax
 42b:	f7 57 08                                        	not    DWORD PTR [rdi+0x8]
 42e:	93                                              	xchg   ebx,eax
 42f:	c1 e0 00                                        	shl    eax,0x0
 432:	d1 e0                                           	shl    eax,1
 434:	c1 e0 07                                        	shl    eax,0x7
 437:	c1 e0 08                                        	shl    eax,0x8
 43a:	c1 e0 0f                                        	shl    eax,0xf
 43d:	c1 e0 10                                        	shl    eax,0x10
 440:	c1 e0 1f                                        	shl    eax,0x1f
 443:	c1 e0 20                                        	shl    eax,0x20
 446:	c1 e0 3f                                        	shl    eax,0x3f
 449:	c1 e0 40                                        	shl    eax,0x40
 44c:	c1 e0 ff                                        	shl    eax,0xff
 44f:	d3 e0                                           	shl    eax,cl
 451:	c1 e8 00                                        	shr    eax,0x0
 454:	d1 e8                                           	shr    eax,1
 456:	c1 e8 07                                        	shr    eax,0x7
 459:	c1 e8 08                                        	shr    eax,0x8
 45c:	c1 e8 0f                                        	shr    eax,0xf
 45f:	c1 e8 10                                        	shr    eax,0x10
 462:	c1 e8 1f                                        	shr    eax,0x1f
 465:	c1 e8 20                                        	shr    eax,0x20
 468:	c1 e8 3f                                        	shr    eax,0x3f
 46b:	c1 e8 40                                        	shr    eax,0x40
 46e:	c1 e8 ff                                        	shr    eax,0xff
 471:	d3 e8                                           	shr    eax,cl
 473:	c1 f8 00                                        	sar    eax,0x0
 476:	d1 f8                                           	sar    eax,1
 478:	c1 f8 07                                        	sar    eax,0x7
 47b:	c1 f8 08                                        	sar    eax,0x8
 47e:	c1 f8 0f                                        	sar    eax,0xf
 481:	c1 f8 10                                        	sar    eax,0x10
 484:	c1 f8 1f                                        	sar    eax,0x1f
 487:	c1 f8 20                                        	sar    eax,0x20
 48a:	c1 f8 3f                                        	sar    eax,0x3f
 48d:	c1 f8 40                                        	sar    eax,0x40
 490:	c1 f8 ff                                        	sar    eax,0xff
 493:	d3 f8                                           	sar    eax,cl
 495:	c1 c0 00                                        	rol    eax,0x0
 498:	d1 c0                                           	rol    eax,1
 49a:	c1 c0 07                                        	rol    eax,0x7
 49d:	c1 c0 08                                        	rol    eax,0x8
 4a0:	c1 c0 0f                                        	rol    eax,0xf
 4a3:	c1 c0 10                                        	rol    eax,0x10
 4a6:	c1 c0 1f                                        	rol    eax,0x1f
 4a9:	c1 c0 20                                        	rol    eax,0x20
 4ac:	c1 c0 3f                                        	rol    eax,0x3f
 4af:	c1 c0 40                                        	rol    eax,0x40
 4b2:	c1 c0 ff                                        	rol    eax,0xff
 4b5:	d3 c0                                           	rol    eax,cl
 4b7:	0f af c3                                        	imul   eax,ebx
 4ba:	0f af 47 08                                     	imul   eax,DWORD PTR [rdi+0x8]
 4be:	6b c3 f9                                        	imul   eax,ebx,0xfffffff9
 4c1:	6b 47 08 f9                                     	imul   eax,DWORD PTR [rdi+0x8],0xfffffff9
 4c5:	f3 0f b8 c3                                     	popcnt eax,ebx
 4c9:	f7 f3                                           	div    ebx
 4cb:	0f a3 d8                                        	bt     eax,ebx
 4ce:	0f ba e0 07                                     	bt     eax,0x7
 4d2:	0f ba 67 08 07                                  	bt     DWORD PTR [rdi+0x8],0x7
 4d7:	0f 38 f0 47 08                                  	movbe  eax,DWORD PTR [rdi+0x8]
 4dc:	0f 38 f1 47 08                                  	movbe  DWORD PTR [rdi+0x8],eax
 4e1:	0f a4 d8 00                                     	shld   eax,ebx,0x0
 4e5:	0f a4 d8 01                                     	shld   eax,ebx,0x1
 4e9:	0f a4 d8 07                                     	shld   eax,ebx,0x7
 4ed:	0f a4 d8 0f                                     	shld   eax,ebx,0xf
 4f1:	0f ac d8 00                                     	shrd   eax,ebx,0x0
 4f5:	0f ac d8 01                                     	shrd   eax,ebx,0x1
 4f9:	0f ac d8 07                                     	shrd   eax,ebx,0x7
 4fd:	0f ac d8 0f                                     	shrd   eax,ebx,0xf
 501:	8d 44 9f f9                                     	lea    eax,[rdi+rbx*4-0x7]
 505:	0f c8                                           	bswap  eax
 507:	c4 e2 60 f2 c1                                  	andn   eax,ebx,ecx
 50c:	c4 e2 60 f2 47 08                               	andn   eax,ebx,DWORD PTR [rdi+0x8]
 512:	c4 e2 70 f5 c3                                  	bzhi   eax,ebx,ecx
 517:	c4 e2 70 f5 47 08                               	bzhi   eax,DWORD PTR [rdi+0x8],ecx
 51d:	c4 e2 63 f6 c1                                  	mulx   eax,ebx,ecx
 522:	c4 e2 71 f7 c3                                  	shlx   eax,ebx,ecx
 527:	c4 e2 71 f7 47 08                               	shlx   eax,DWORD PTR [rdi+0x8],ecx
 52d:	c4 e2 73 f7 c3                                  	shrx   eax,ebx,ecx
 532:	c4 e2 73 f7 47 08                               	shrx   eax,DWORD PTR [rdi+0x8],ecx
 538:	c4 e2 72 f7 c3                                  	sarx   eax,ebx,ecx
 53d:	c4 e2 72 f7 47 08                               	sarx   eax,DWORD PTR [rdi+0x8],ecx
 543:	c4 e3 7b f0 c3 07                               	rorx   eax,ebx,0x7
 549:	c4 e3 7b f0 47 08 07                            	rorx   eax,DWORD PTR [rdi+0x8],0x7
 550:	48 89 d8                                        	mov    rax,rbx
 553:	48 c7 c0 7f 00 00 00                            	mov    rax,0x7f
 55a:	48 89 47 08                                     	mov    QWORD PTR [rdi+0x8],rax
 55e:	48 8b 47 08                                     	mov    rax,QWORD PTR [rdi+0x8]
 562:	48 c7 47 08 7f 00 00 00                         	mov    QWORD PTR [rdi+0x8],0x7f
 56a:	48 01 d8                                        	add    rax,rbx
 56d:	48 83 c0 7f                                     	add    rax,0x7f
 571:	48 01 47 08                                     	add    QWORD PTR [rdi+0x8],rax
 575:	48 83 47 08 7f                                  	add    QWORD PTR [rdi+0x8],0x7f
 57a:	48 03 47 08                                     	add    rax,QWORD PTR [rdi+0x8]
 57e:	48 11 d8                                        	adc    rax,rbx
 581:	48 83 d0 7f                                     	adc    rax,0x7f
 585:	48 11 47 08                                     	adc    QWORD PTR [rdi+0x8],rax
 589:	48 83 57 08 7f                                  	adc    QWORD PTR [rdi+0x8],0x7f
 58e:	48 13 47 08                                     	adc    rax,QWORD PTR [rdi+0x8]
 592:	48 29 d8                                        	sub    rax,rbx
 595:	48 83 e8 7f                                     	sub    rax,0x7f
 599:	48 29 47 08                                     	sub    QWORD PTR [rdi+0x8],rax
 59d:	48 83 6f 08 7f                                  	sub    QWORD PTR [rdi+0x8],0x7f
 5a2:	48 2b 47 08                                     	sub    rax,QWORD PTR [rdi+0x8]
 5a6:	48 19 d8                                        	sbb    rax,rbx
 5a9:	48 83 d8 7f                                     	sbb    rax,0x7f
 5ad:	48 19 47 08                                     	sbb    QWORD PTR [rdi+0x8],rax
 5b1:	48 83 5f 08 7f                                  	sbb    QWORD PTR [rdi+0x8],0x7f
 5b6:	48 1b 47 08                                     	sbb    rax,QWORD PTR [rdi+0x8]
 5ba:	48 39 d8                                        	cmp    rax,rbx
 5bd:	48 83 f8 7f                                     	cmp    rax,0x7f
 5c1:	48 39 47 08                                     	cmp    QWORD PTR [rdi+0x8],rax
 5c5:	48 83 7f 08 7f                                  	cmp    QWORD PTR [rdi+0x8],0x7f
 5ca:	48 3b 47 08                                     	cmp    rax,QWORD PTR [rdi+0x8]
 5ce:	48 85 d8                                        	test   rax,rbx
 5d1:	48 a9 7f 00 00 00                               	test   rax,0x7f
 5d7:	48 85 47 08                                     	test   QWORD PTR [rdi+0x8],rax
 5db:	48 f7 47 08 7f 00 00 00                         	test   QWORD PTR [rdi+0x8],0x7f
 5e3:	48 21 d8                                        	and    rax,rbx
 5e6:	48 83 e0 7f                                     	and    rax,0x7f
 5ea:	48 23 47 08                                     	and    rax,QWORD PTR [rdi+0x8]
 5ee:	48 21 47 08                                     	and    QWORD PTR [rdi+0x8],rax
 5f2:	48 83 67 08 7f                                  	and    QWORD PTR [rdi+0x8],0x7f
 5f7:	48 09 d8                                        	or     rax,rbx
 5fa:	48 83 c8 7f                                     	or     rax,0x7f
 5fe:	48 0b 47 08                                     	or     rax,QWORD PTR [rdi+0x8]
 602:	48 09 47 08                                     	or     QWORD PTR [rdi+0x8],rax
 606:	48 83 4f 08 7f                                  	or     QWORD PTR [rdi+0x8],0x7f
 60b:	48 31 d8                                        	xor    rax,rbx
 60e:	48 83 f0 7f                                     	xor    rax,0x7f
 612:	48 33 47 08                                     	xor    rax,QWORD PTR [rdi+0x8]
 616:	48 31 47 08                                     	xor    QWORD PTR [rdi+0x8],rax
 61a:	48 83 77 08 7f                                  	xor    QWORD PTR [rdi+0x8],0x7f
 61f:	48 ff c0                                        	inc    rax
 622:	48 ff 47 08                                     	inc    QWORD PTR [rdi+0x8]
 626:	48 ff c8                                        	dec    rax
 629:	48 ff 4f 08                                     	dec    QWORD PTR [rdi+0x8]
 62d:	48 f7 d8                                        	neg    rax
 630:	48 f7 5f 08                                     	neg    QWORD PTR [rdi+0x8]
 634:	48 f7 d0                                        	not    rax
 637:	48 f7 57 08                                     	not    QWORD PTR [rdi+0x8]
 63b:	48 93                                           	xchg   rbx,rax
 63d:	48 c1 e0 00                                     	shl    rax,0x0
 641:	48 d1 e0                                        	shl    rax,1
 644:	48 c1 e0 07                                     	shl    rax,0x7
 648:	48 c1 e0 08                                     	shl    rax,0x8
 64c:	48 c1 e0 0f                                     	shl    rax,0xf
 650:	48 c1 e0 10                                     	shl    rax,0x10
 654:	48 c1 e0 1f                                     	shl    rax,0x1f
 658:	48 c1 e0 20                                     	shl    rax,0x20
 65c:	48 c1 e0 3f                                     	shl    rax,0x3f
 660:	48 c1 e0 40                                     	shl    rax,0x40
 664:	48 c1 e0 ff                                     	shl    rax,0xff
 668:	48 d3 e0                                        	shl    rax,cl
 66b:	48 c1 e8 00                                     	shr    rax,0x0
 66f:	48 d1 e8                                        	shr    rax,1
 672:	48 c1 e8 07                                     	shr    rax,0x7
 676:	48 c1 e8 08                                     	shr    rax,0x8
 67a:	48 c1 e8 0f                                     	shr    rax,0xf
 67e:	48 c1 e8 10                                     	shr    rax,0x10
 682:	48 c1 e8 1f                                     	shr    rax,0x1f
 686:	48 c1 e8 20                                     	shr    rax,0x20
 68a:	48 c1 e8 3f                                     	shr    rax,0x3f
 68e:	48 c1 e8 40                                     	shr    rax,0x40
 692:	48 c1 e8 ff                                     	shr    rax,0xff
 696:	48 d3 e8                                        	shr    rax,cl
 699:	48 c1 f8 00                                     	sar    rax,0x0
 69d:	48 d1 f8                                        	sar    rax,1
 6a0:	48 c1 f8 07                                     	sar    rax,0x7
 6a4:	48 c1 f8 08                                     	sar    rax,0x8
 6a8:	48 c1 f8 0f                                     	sar    rax,0xf
 6ac:	48 c1 f8 10                                     	sar    rax,0x10
 6b0:	48 c1 f8 1f                                     	sar    rax,0x1f
 6b4:	48 c1 f8 20                                     	sar    rax,0x20
 6b8:	48 c1 f8 3f                                     	sar    rax,0x3f
 6bc:	48 c1 f8 40                                     	sar    rax,0x40
 6c0:	48 c1 f8 ff                                     	sar    rax,0xff
 6c4:	48 d3 f8                                        	sar    rax,cl
 6c7:	48 c1 c0 00                                     	rol    rax,0x0
 6cb:	48 d1 c0                                        	rol    rax,1
 6ce:	48 c1 c0 07                                     	rol    rax,0x7
 6d2:	48 c1 c0 08                                     	rol    rax,0x8
 6d6:	48 c1 c0 0f                                     	rol    rax,0xf
 6da:	48 c1 c0 10                                     	rol    rax,0x10
 6de:	48 c1 c0 1f                                     	rol    rax,0x1f
 6e2:	48 c1 c0 20                                     	rol    rax,0x20
 6e6:	48 c1 c0 3f                                     	rol    rax,0x3f
 6ea:	48 c1 c0 40                                     	rol    rax,0x40
 6ee:	48 c1 c0 ff                                     	rol    rax,0xff
 6f2:	48 d3 c0                                        	rol    rax,cl
 6f5:	48 0f af c3                                     	imul   rax,rbx
 6f9:	48 0f af 47 08                                  	imul   rax,QWORD PTR [rdi+0x8]
 6fe:	48 6b c3 f9                                     	imul   rax,rbx,0xfffffffffffffff9
 702:	48 6b 47 08 f9                                  	imul   rax,QWORD PTR [rdi+0x8],0xfffffffffffffff9
 707:	f3 48 0f b8 c3                                  	popcnt rax,rbx
 70c:	48 f7 f3                                        	div    rbx
 70f:	48 0f a3 d8                                     	bt     rax,rbx
 713:	48 0f ba e0 07                                  	bt     rax,0x7
 718:	48 0f ba 67 08 07                               	bt     QWORD PTR [rdi+0x8],0x7
 71e:	48 0f 38 f0 47 08                               	movbe  rax,QWORD PTR [rdi+0x8]
 724:	48 0f 38 f1 47 08                               	movbe  QWORD PTR [rdi+0x8],rax
 72a:	48 0f a4 d8 00                                  	shld   rax,rbx,0x0
 72f:	48 0f a4 d8 01                                  	shld   rax,rbx,0x1
 734:	48 0f a4 d8 07                                  	shld   rax,rbx,0x7
 739:	48 0f a4 d8 0f                                  	shld   rax,rbx,0xf
 73e:	48 0f ac d8 00                                  	shrd   rax,rbx,0x0
 743:	48 0f ac d8 01                                  	shrd   rax,rbx,0x1
 748:	48 0f ac d8 07                                  	shrd   rax,rbx,0x7
 74d:	48 0f ac d8 0f                                  	shrd   rax,rbx,0xf
 752:	48 8d 44 9f f9                                  	lea    rax,[rdi+rbx*4-0x7]
 757:	48 0f c8                                        	bswap  rax
 75a:	c4 e2 e0 f2 c1                                  	andn   rax,rbx,rcx
 75f:	c4 e2 e0 f2 47 08                               	andn   rax,rbx,QWORD PTR [rdi+0x8]
 765:	c4 e2 f0 f5 c3                                  	bzhi   rax,rbx,rcx
 76a:	c4 e2 f0 f5 47 08                               	bzhi   rax,QWORD PTR [rdi+0x8],rcx
 770:	c4 e2 e3 f6 c1                                  	mulx   rax,rbx,rcx
 775:	c4 e2 f1 f7 c3                                  	shlx   rax,rbx,rcx
 77a:	c4 e2 f1 f7 47 08                               	shlx   rax,QWORD PTR [rdi+0x8],rcx
 780:	c4 e2 f3 f7 c3                                  	shrx   rax,rbx,rcx
 785:	c4 e2 f3 f7 47 08                               	shrx   rax,QWORD PTR [rdi+0x8],rcx
 78b:	c4 e2 f2 f7 c3                                  	sarx   rax,rbx,rcx
 790:	c4 e2 f2 f7 47 08                               	sarx   rax,QWORD PTR [rdi+0x8],rcx
 796:	c4 e3 fb f0 c3 07                               	rorx   rax,rbx,0x7
 79c:	c4 e3 fb f0 47 08 07                            	rorx   rax,QWORD PTR [rdi+0x8],0x7
 7a3:	88 fc                                           	mov    ah,bh
 7a5:	b4 7f                                           	mov    ah,0x7f
 7a7:	88 67 08                                        	mov    BYTE PTR [rdi+0x8],ah
 7aa:	00 fc                                           	add    ah,bh
 7ac:	80 c4 7f                                        	add    ah,0x7f
 7af:	10 fc                                           	adc    ah,bh
 7b1:	80 d4 7f                                        	adc    ah,0x7f
 7b4:	28 fc                                           	sub    ah,bh
 7b6:	80 ec 7f                                        	sub    ah,0x7f
 7b9:	18 fc                                           	sbb    ah,bh
 7bb:	80 dc 7f                                        	sbb    ah,0x7f
 7be:	38 fc                                           	cmp    ah,bh
 7c0:	80 fc 7f                                        	cmp    ah,0x7f
 7c3:	84 fc                                           	test   ah,bh
 7c5:	f6 c4 7f                                        	test   ah,0x7f
 7c8:	fe c4                                           	inc    ah
 7ca:	fe cc                                           	dec    ah
 7cc:	f6 dc                                           	neg    ah
 7ce:	f6 d4                                           	not    ah
 7d0:	66 0f b6 c3                                     	movzx  ax,bl
 7d4:	66 0f b6 47 08                                  	movzx  ax,BYTE PTR [rdi+0x8]
 7d9:	66 0f be c3                                     	movsx  ax,bl
 7dd:	66 0f be 47 08                                  	movsx  ax,BYTE PTR [rdi+0x8]
 7e2:	0f b6 c3                                        	movzx  eax,bl
 7e5:	0f b6 47 08                                     	movzx  eax,BYTE PTR [rdi+0x8]
 7e9:	0f be c3                                        	movsx  eax,bl
 7ec:	0f be 47 08                                     	movsx  eax,BYTE PTR [rdi+0x8]
 7f0:	0f b7 c3                                        	movzx  eax,bx
 7f3:	0f b7 47 08                                     	movzx  eax,WORD PTR [rdi+0x8]
 7f7:	0f bf c3                                        	movsx  eax,bx
 7fa:	0f bf 47 08                                     	movsx  eax,WORD PTR [rdi+0x8]
 7fe:	48 0f b6 c3                                     	movzx  rax,bl
 802:	48 0f b6 47 08                                  	movzx  rax,BYTE PTR [rdi+0x8]
 807:	48 0f be c3                                     	movsx  rax,bl
 80b:	48 0f be 47 08                                  	movsx  rax,BYTE PTR [rdi+0x8]
 810:	48 0f b7 c3                                     	movzx  rax,bx
 814:	48 0f b7 47 08                                  	movzx  rax,WORD PTR [rdi+0x8]
 819:	48 0f bf c3                                     	movsx  rax,bx
 81d:	48 0f bf 47 08                                  	movsx  rax,WORD PTR [rdi+0x8]
 822:	48 63 c3                                        	movsxd rax,ebx
 825:	48 63 47 08                                     	movsxd rax,DWORD PTR [rdi+0x8]
 829:	0f 92 c0                                        	setb   al
 82c:	0f 92 c4                                        	setb   ah
 82f:	0f 92 47 08                                     	setb   BYTE PTR [rdi+0x8]
 833:	66 0f 42 c3                                     	cmovb  ax,bx
 837:	66 0f 42 47 08                                  	cmovb  ax,WORD PTR [rdi+0x8]
 83c:	0f 42 c3                                        	cmovb  eax,ebx
 83f:	0f 42 47 08                                     	cmovb  eax,DWORD PTR [rdi+0x8]
 843:	48 0f 42 c3                                     	cmovb  rax,rbx
 847:	48 0f 42 47 08                                  	cmovb  rax,QWORD PTR [rdi+0x8]
 84c:	0f 93 c0                                        	setae  al
 84f:	0f 93 c4                                        	setae  ah
 852:	0f 93 47 08                                     	setae  BYTE PTR [rdi+0x8]
 856:	66 0f 43 c3                                     	cmovae ax,bx
 85a:	66 0f 43 47 08                                  	cmovae ax,WORD PTR [rdi+0x8]
 85f:	0f 43 c3                                        	cmovae eax,ebx
 862:	0f 43 47 08                                     	cmovae eax,DWORD PTR [rdi+0x8]
 866:	48 0f 43 c3                                     	cmovae rax,rbx
 86a:	48 0f 43 47 08                                  	cmovae rax,QWORD PTR [rdi+0x8]
 86f:	0f 94 c0                                        	sete   al
 872:	0f 94 c4                                        	sete   ah
 875:	0f 94 47 08                                     	sete   BYTE PTR [rdi+0x8]
 879:	66 0f 44 c3                                     	cmove  ax,bx
 87d:	66 0f 44 47 08                                  	cmove  ax,WORD PTR [rdi+0x8]
 882:	0f 44 c3                                        	cmove  eax,ebx
 885:	0f 44 47 08                                     	cmove  eax,DWORD PTR [rdi+0x8]
 889:	48 0f 44 c3                                     	cmove  rax,rbx
 88d:	48 0f 44 47 08                                  	cmove  rax,QWORD PTR [rdi+0x8]
 892:	0f 95 c0                                        	setne  al
 895:	0f 95 c4                                        	setne  ah
 898:	0f 95 47 08                                     	setne  BYTE PTR [rdi+0x8]
 89c:	66 0f 45 c3                                     	cmovne ax,bx
 8a0:	66 0f 45 47 08                                  	cmovne ax,WORD PTR [rdi+0x8]
 8a5:	0f 45 c3                                        	cmovne eax,ebx
 8a8:	0f 45 47 08                                     	cmovne eax,DWORD PTR [rdi+0x8]
 8ac:	48 0f 45 c3                                     	cmovne rax,rbx
 8b0:	48 0f 45 47 08                                  	cmovne rax,QWORD PTR [rdi+0x8]
 8b5:	0f 96 c0                                        	setbe  al
 8b8:	0f 96 c4                                        	setbe  ah
 8bb:	0f 96 47 08                                     	setbe  BYTE PTR [rdi+0x8]
 8bf:	66 0f 46 c3                                     	cmovbe ax,bx
 8c3:	66 0f 46 47 08                                  	cmovbe ax,WORD PTR [rdi+0x8]
 8c8:	0f 46 c3                                        	cmovbe eax,ebx
 8cb:	0f 46 47 08                                     	cmovbe eax,DWORD PTR [rdi+0x8]
 8cf:	48 0f 46 c3                                     	cmovbe rax,rbx
 8d3:	48 0f 46 47 08                                  	cmovbe rax,QWORD PTR [rdi+0x8]
 8d8:	0f 97 c0                                        	seta   al
 8db:	0f 97 c4                                        	seta   ah
 8de:	0f 97 47 08                                     	seta   BYTE PTR [rdi+0x8]
 8e2:	66 0f 47 c3                                     	cmova  ax,bx
 8e6:	66 0f 47 47 08                                  	cmova  ax,WORD PTR [rdi+0x8]
 8eb:	0f 47 c3                                        	cmova  eax,ebx
 8ee:	0f 47 47 08                                     	cmova  eax,DWORD PTR [rdi+0x8]
 8f2:	48 0f 47 c3                                     	cmova  rax,rbx
 8f6:	48 0f 47 47 08                                  	cmova  rax,QWORD PTR [rdi+0x8]
 8fb:	0f 98 c0                                        	sets   al
 8fe:	0f 98 c4                                        	sets   ah
 901:	0f 98 47 08                                     	sets   BYTE PTR [rdi+0x8]
 905:	66 0f 48 c3                                     	cmovs  ax,bx
 909:	66 0f 48 47 08                                  	cmovs  ax,WORD PTR [rdi+0x8]
 90e:	0f 48 c3                                        	cmovs  eax,ebx
 911:	0f 48 47 08                                     	cmovs  eax,DWORD PTR [rdi+0x8]
 915:	48 0f 48 c3                                     	cmovs  rax,rbx
 919:	48 0f 48 47 08                                  	cmovs  rax,QWORD PTR [rdi+0x8]
 91e:	0f 99 c0                                        	setns  al
 921:	0f 99 c4                                        	setns  ah
 924:	0f 99 47 08                                     	setns  BYTE PTR [rdi+0x8]
 928:	66 0f 49 c3                                     	cmovns ax,bx
 92c:	66 0f 49 47 08                                  	cmovns ax,WORD PTR [rdi+0x8]
 931:	0f 49 c3                                        	cmovns eax,ebx
 934:	0f 49 47 08                                     	cmovns eax,DWORD PTR [rdi+0x8]
 938:	48 0f 49 c3                                     	cmovns rax,rbx
 93c:	48 0f 49 47 08                                  	cmovns rax,QWORD PTR [rdi+0x8]
 941:	0f 9c c0                                        	setl   al
 944:	0f 9c c4                                        	setl   ah
 947:	0f 9c 47 08                                     	setl   BYTE PTR [rdi+0x8]
 94b:	66 0f 4c c3                                     	cmovl  ax,bx
 94f:	66 0f 4c 47 08                                  	cmovl  ax,WORD PTR [rdi+0x8]
 954:	0f 4c c3                                        	cmovl  eax,ebx
 957:	0f 4c 47 08                                     	cmovl  eax,DWORD PTR [rdi+0x8]
 95b:	48 0f 4c c3                                     	cmovl  rax,rbx
 95f:	48 0f 4c 47 08                                  	cmovl  rax,QWORD PTR [rdi+0x8]
 964:	0f 9d c0                                        	setge  al
 967:	0f 9d c4                                        	setge  ah
 96a:	0f 9d 47 08                                     	setge  BYTE PTR [rdi+0x8]
 96e:	66 0f 4d c3                                     	cmovge ax,bx
 972:	66 0f 4d 47 08                                  	cmovge ax,WORD PTR [rdi+0x8]
 977:	0f 4d c3                                        	cmovge eax,ebx
 97a:	0f 4d 47 08                                     	cmovge eax,DWORD PTR [rdi+0x8]
 97e:	48 0f 4d c3                                     	cmovge rax,rbx
 982:	48 0f 4d 47 08                                  	cmovge rax,QWORD PTR [rdi+0x8]
 987:	0f 9e c0                                        	setle  al
 98a:	0f 9e c4                                        	setle  ah
 98d:	0f 9e 47 08                                     	setle  BYTE PTR [rdi+0x8]
 991:	66 0f 4e c3                                     	cmovle ax,bx
 995:	66 0f 4e 47 08                                  	cmovle ax,WORD PTR [rdi+0x8]
 99a:	0f 4e c3                                        	cmovle eax,ebx
 99d:	0f 4e 47 08                                     	cmovle eax,DWORD PTR [rdi+0x8]
 9a1:	48 0f 4e c3                                     	cmovle rax,rbx
 9a5:	48 0f 4e 47 08                                  	cmovle rax,QWORD PTR [rdi+0x8]
 9aa:	0f 9f c0                                        	setg   al
 9ad:	0f 9f c4                                        	setg   ah
 9b0:	0f 9f 47 08                                     	setg   BYTE PTR [rdi+0x8]
 9b4:	66 0f 4f c3                                     	cmovg  ax,bx
 9b8:	66 0f 4f 47 08                                  	cmovg  ax,WORD PTR [rdi+0x8]
 9bd:	0f 4f c3                                        	cmovg  eax,ebx
 9c0:	0f 4f 47 08                                     	cmovg  eax,DWORD PTR [rdi+0x8]
 9c4:	48 0f 4f c3                                     	cmovg  rax,rbx
 9c8:	48 0f 4f 47 08                                  	cmovg  rax,QWORD PTR [rdi+0x8]
