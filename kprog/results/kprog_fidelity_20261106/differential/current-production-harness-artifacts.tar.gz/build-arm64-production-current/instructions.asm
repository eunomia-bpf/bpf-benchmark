
build-arm64-production-current/instructions.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <.text>:
   0:	d503201f 	nop
   4:	0b020020 	add	w0, w1, w2
   8:	0b020c20 	add	w0, w1, w2, lsl #3
   c:	1101fc20 	add	w0, w1, #0x7f
  10:	4b020020 	sub	w0, w1, w2
  14:	4b020c20 	sub	w0, w1, w2, lsl #3
  18:	5101fc20 	sub	w0, w1, #0x7f
  1c:	0a020020 	and	w0, w1, w2
  20:	0a020c20 	and	w0, w1, w2, lsl #3
  24:	0a220020 	bic	w0, w1, w2
  28:	0a220c20 	bic	w0, w1, w2, lsl #3
  2c:	4a020020 	eor	w0, w1, w2
  30:	4a020c20 	eor	w0, w1, w2, lsl #3
  34:	2a020020 	orr	w0, w1, w2
  38:	2a020c20 	orr	w0, w1, w2, lsl #3
  3c:	2a220020 	orn	w0, w1, w2
  40:	2a220c20 	orn	w0, w1, w2, lsl #3
  44:	2b020020 	adds	w0, w1, w2
  48:	2b020c20 	adds	w0, w1, w2, lsl #3
  4c:	3101fc20 	adds	w0, w1, #0x7f
  50:	6b020020 	subs	w0, w1, w2
  54:	6b020c20 	subs	w0, w1, w2, lsl #3
  58:	7101fc20 	subs	w0, w1, #0x7f
  5c:	6a020020 	ands	w0, w1, w2
  60:	6a020c20 	ands	w0, w1, w2, lsl #3
  64:	6a220020 	bics	w0, w1, w2
  68:	6a220c20 	bics	w0, w1, w2, lsl #3
  6c:	6b02003f 	cmp	w1, w2
  70:	6b020c3f 	cmp	w1, w2, lsl #3
  74:	2b02003f 	cmn	w1, w2
  78:	2b020c3f 	cmn	w1, w2, lsl #3
  7c:	6a02003f 	tst	w1, w2
  80:	6a020c3f 	tst	w1, w2, lsl #3
  84:	2a0103e0 	mov	w0, w1
  88:	52800fe0 	mov	w0, #0x7f                  	// #127
  8c:	72bbd5a0 	movk	w0, #0xdead, lsl #16
  90:	2a2103e0 	mvn	w0, w1
  94:	4b0103e0 	neg	w0, w1
  98:	5ac00820 	rev	w0, w1
  9c:	5ac00420 	rev16	w0, w1
  a0:	13001c20 	sxtb	w0, w1
  a4:	13003c20 	sxth	w0, w1
  a8:	2a2103e0 	mvn	w0, w1
  ac:	2a2107e0 	mvn	w0, w1, lsl #1
  b0:	2a217fe0 	mvn	w0, w1, lsl #31
  b4:	2a6103e0 	mvn	w0, w1, lsr #0
  b8:	2a6107e0 	mvn	w0, w1, lsr #1
  bc:	2a617fe0 	mvn	w0, w1, lsr #31
  c0:	2aa103e0 	mvn	w0, w1, asr #0
  c4:	2aa107e0 	mvn	w0, w1, asr #1
  c8:	2aa17fe0 	mvn	w0, w1, asr #31
  cc:	2ae103e0 	mvn	w0, w1, ror #0
  d0:	2ae107e0 	mvn	w0, w1, ror #1
  d4:	2ae17fe0 	mvn	w0, w1, ror #31
  d8:	4b0103e0 	neg	w0, w1
  dc:	4b0107e0 	neg	w0, w1, lsl #1
  e0:	4b017fe0 	neg	w0, w1, lsl #31
  e4:	4b4103e0 	neg	w0, w1, lsr #0
  e8:	4b4107e0 	neg	w0, w1, lsr #1
  ec:	4b417fe0 	neg	w0, w1, lsr #31
  f0:	4b8103e0 	neg	w0, w1, asr #0
  f4:	4b8107e0 	neg	w0, w1, asr #1
  f8:	4b817fe0 	neg	w0, w1, asr #31
  fc:	1b027c20 	mul	w0, w1, w2
 100:	1ac20820 	udiv	w0, w1, w2
 104:	1b020c20 	madd	w0, w1, w2, w3
 108:	1b028c20 	msub	w0, w1, w2, w3
 10c:	1ac22020 	lsl	w0, w1, w2
 110:	53007c20 	lsr	w0, w1, #0
 114:	531f7820 	lsl	w0, w1, #1
 118:	53196020 	lsl	w0, w1, #7
 11c:	53010020 	lsl	w0, w1, #31
 120:	1ac22420 	lsr	w0, w1, w2
 124:	53007c20 	lsr	w0, w1, #0
 128:	53017c20 	lsr	w0, w1, #1
 12c:	53077c20 	lsr	w0, w1, #7
 130:	531f7c20 	lsr	w0, w1, #31
 134:	1ac22820 	asr	w0, w1, w2
 138:	13007c20 	asr	w0, w1, #0
 13c:	13017c20 	asr	w0, w1, #1
 140:	13077c20 	asr	w0, w1, #7
 144:	131f7c20 	asr	w0, w1, #31
 148:	1ac22c20 	ror	w0, w1, w2
 14c:	13810020 	ror	w0, w1, #0
 150:	13810420 	ror	w0, w1, #1
 154:	13811c20 	ror	w0, w1, #7
 158:	13817c20 	ror	w0, w1, #31
 15c:	13821c20 	extr	w0, w1, w2, #7
 160:	53074c20 	ubfx	w0, w1, #7, #13
 164:	13074c20 	sbfx	w0, w1, #7, #13
 168:	53193020 	ubfiz	w0, w1, #7, #13
 16c:	33074c20 	bfxil	w0, w1, #7, #13
 170:	33193020 	bfi	w0, w1, #7, #13
 174:	1a820020 	csel	w0, w1, w2, eq	// eq = none
 178:	1a820420 	csinc	w0, w1, w2, eq	// eq = none
 17c:	5a820020 	csinv	w0, w1, w2, eq	// eq = none
 180:	5a820420 	csneg	w0, w1, w2, eq	// eq = none
 184:	1a811420 	cinc	w0, w1, eq	// eq = none
 188:	5a811020 	cinv	w0, w1, eq	// eq = none
 18c:	5a811420 	cneg	w0, w1, eq	// eq = none
 190:	1a9f17e0 	cset	w0, eq	// eq = none
 194:	5a9f13e0 	csetm	w0, eq	// eq = none
 198:	7a420025 	ccmp	w1, w2, #0x5, eq	// eq = none
 19c:	7a47082a 	ccmp	w1, #0x7, #0xa, eq	// eq = none
 1a0:	1a821020 	csel	w0, w1, w2, ne	// ne = any
 1a4:	1a821420 	csinc	w0, w1, w2, ne	// ne = any
 1a8:	5a821020 	csinv	w0, w1, w2, ne	// ne = any
 1ac:	5a821420 	csneg	w0, w1, w2, ne	// ne = any
 1b0:	1a810420 	cinc	w0, w1, ne	// ne = any
 1b4:	5a810020 	cinv	w0, w1, ne	// ne = any
 1b8:	5a810420 	cneg	w0, w1, ne	// ne = any
 1bc:	1a9f07e0 	cset	w0, ne	// ne = any
 1c0:	5a9f03e0 	csetm	w0, ne	// ne = any
 1c4:	7a421025 	ccmp	w1, w2, #0x5, ne	// ne = any
 1c8:	7a47182a 	ccmp	w1, #0x7, #0xa, ne	// ne = any
 1cc:	1a822020 	csel	w0, w1, w2, cs	// cs = hs, nlast
 1d0:	1a822420 	csinc	w0, w1, w2, cs	// cs = hs, nlast
 1d4:	5a822020 	csinv	w0, w1, w2, cs	// cs = hs, nlast
 1d8:	5a822420 	csneg	w0, w1, w2, cs	// cs = hs, nlast
 1dc:	1a813420 	cinc	w0, w1, cs	// cs = hs, nlast
 1e0:	5a813020 	cinv	w0, w1, cs	// cs = hs, nlast
 1e4:	5a813420 	cneg	w0, w1, cs	// cs = hs, nlast
 1e8:	1a9f37e0 	cset	w0, cs	// cs = hs, nlast
 1ec:	5a9f33e0 	csetm	w0, cs	// cs = hs, nlast
 1f0:	7a422025 	ccmp	w1, w2, #0x5, cs	// cs = hs, nlast
 1f4:	7a47282a 	ccmp	w1, #0x7, #0xa, cs	// cs = hs, nlast
 1f8:	1a823020 	csel	w0, w1, w2, cc	// cc = lo, ul, last
 1fc:	1a823420 	csinc	w0, w1, w2, cc	// cc = lo, ul, last
 200:	5a823020 	csinv	w0, w1, w2, cc	// cc = lo, ul, last
 204:	5a823420 	csneg	w0, w1, w2, cc	// cc = lo, ul, last
 208:	1a812420 	cinc	w0, w1, cc	// cc = lo, ul, last
 20c:	5a812020 	cinv	w0, w1, cc	// cc = lo, ul, last
 210:	5a812420 	cneg	w0, w1, cc	// cc = lo, ul, last
 214:	1a9f27e0 	cset	w0, cc	// cc = lo, ul, last
 218:	5a9f23e0 	csetm	w0, cc	// cc = lo, ul, last
 21c:	7a423025 	ccmp	w1, w2, #0x5, cc	// cc = lo, ul, last
 220:	7a47382a 	ccmp	w1, #0x7, #0xa, cc	// cc = lo, ul, last
 224:	1a824020 	csel	w0, w1, w2, mi	// mi = first
 228:	1a824420 	csinc	w0, w1, w2, mi	// mi = first
 22c:	5a824020 	csinv	w0, w1, w2, mi	// mi = first
 230:	5a824420 	csneg	w0, w1, w2, mi	// mi = first
 234:	1a815420 	cinc	w0, w1, mi	// mi = first
 238:	5a815020 	cinv	w0, w1, mi	// mi = first
 23c:	5a815420 	cneg	w0, w1, mi	// mi = first
 240:	1a9f57e0 	cset	w0, mi	// mi = first
 244:	5a9f53e0 	csetm	w0, mi	// mi = first
 248:	7a424025 	ccmp	w1, w2, #0x5, mi	// mi = first
 24c:	7a47482a 	ccmp	w1, #0x7, #0xa, mi	// mi = first
 250:	1a825020 	csel	w0, w1, w2, pl	// pl = nfrst
 254:	1a825420 	csinc	w0, w1, w2, pl	// pl = nfrst
 258:	5a825020 	csinv	w0, w1, w2, pl	// pl = nfrst
 25c:	5a825420 	csneg	w0, w1, w2, pl	// pl = nfrst
 260:	1a814420 	cinc	w0, w1, pl	// pl = nfrst
 264:	5a814020 	cinv	w0, w1, pl	// pl = nfrst
 268:	5a814420 	cneg	w0, w1, pl	// pl = nfrst
 26c:	1a9f47e0 	cset	w0, pl	// pl = nfrst
 270:	5a9f43e0 	csetm	w0, pl	// pl = nfrst
 274:	7a425025 	ccmp	w1, w2, #0x5, pl	// pl = nfrst
 278:	7a47582a 	ccmp	w1, #0x7, #0xa, pl	// pl = nfrst
 27c:	1a826020 	csel	w0, w1, w2, vs
 280:	1a826420 	csinc	w0, w1, w2, vs
 284:	5a826020 	csinv	w0, w1, w2, vs
 288:	5a826420 	csneg	w0, w1, w2, vs
 28c:	1a817420 	cinc	w0, w1, vs
 290:	5a817020 	cinv	w0, w1, vs
 294:	5a817420 	cneg	w0, w1, vs
 298:	1a9f77e0 	cset	w0, vs
 29c:	5a9f73e0 	csetm	w0, vs
 2a0:	7a426025 	ccmp	w1, w2, #0x5, vs
 2a4:	7a47682a 	ccmp	w1, #0x7, #0xa, vs
 2a8:	1a827020 	csel	w0, w1, w2, vc
 2ac:	1a827420 	csinc	w0, w1, w2, vc
 2b0:	5a827020 	csinv	w0, w1, w2, vc
 2b4:	5a827420 	csneg	w0, w1, w2, vc
 2b8:	1a816420 	cinc	w0, w1, vc
 2bc:	5a816020 	cinv	w0, w1, vc
 2c0:	5a816420 	cneg	w0, w1, vc
 2c4:	1a9f67e0 	cset	w0, vc
 2c8:	5a9f63e0 	csetm	w0, vc
 2cc:	7a427025 	ccmp	w1, w2, #0x5, vc
 2d0:	7a47782a 	ccmp	w1, #0x7, #0xa, vc
 2d4:	1a828020 	csel	w0, w1, w2, hi	// hi = pmore
 2d8:	1a828420 	csinc	w0, w1, w2, hi	// hi = pmore
 2dc:	5a828020 	csinv	w0, w1, w2, hi	// hi = pmore
 2e0:	5a828420 	csneg	w0, w1, w2, hi	// hi = pmore
 2e4:	1a819420 	cinc	w0, w1, hi	// hi = pmore
 2e8:	5a819020 	cinv	w0, w1, hi	// hi = pmore
 2ec:	5a819420 	cneg	w0, w1, hi	// hi = pmore
 2f0:	1a9f97e0 	cset	w0, hi	// hi = pmore
 2f4:	5a9f93e0 	csetm	w0, hi	// hi = pmore
 2f8:	7a428025 	ccmp	w1, w2, #0x5, hi	// hi = pmore
 2fc:	7a47882a 	ccmp	w1, #0x7, #0xa, hi	// hi = pmore
 300:	1a829020 	csel	w0, w1, w2, ls	// ls = plast
 304:	1a829420 	csinc	w0, w1, w2, ls	// ls = plast
 308:	5a829020 	csinv	w0, w1, w2, ls	// ls = plast
 30c:	5a829420 	csneg	w0, w1, w2, ls	// ls = plast
 310:	1a818420 	cinc	w0, w1, ls	// ls = plast
 314:	5a818020 	cinv	w0, w1, ls	// ls = plast
 318:	5a818420 	cneg	w0, w1, ls	// ls = plast
 31c:	1a9f87e0 	cset	w0, ls	// ls = plast
 320:	5a9f83e0 	csetm	w0, ls	// ls = plast
 324:	7a429025 	ccmp	w1, w2, #0x5, ls	// ls = plast
 328:	7a47982a 	ccmp	w1, #0x7, #0xa, ls	// ls = plast
 32c:	1a82a020 	csel	w0, w1, w2, ge	// ge = tcont
 330:	1a82a420 	csinc	w0, w1, w2, ge	// ge = tcont
 334:	5a82a020 	csinv	w0, w1, w2, ge	// ge = tcont
 338:	5a82a420 	csneg	w0, w1, w2, ge	// ge = tcont
 33c:	1a81b420 	cinc	w0, w1, ge	// ge = tcont
 340:	5a81b020 	cinv	w0, w1, ge	// ge = tcont
 344:	5a81b420 	cneg	w0, w1, ge	// ge = tcont
 348:	1a9fb7e0 	cset	w0, ge	// ge = tcont
 34c:	5a9fb3e0 	csetm	w0, ge	// ge = tcont
 350:	7a42a025 	ccmp	w1, w2, #0x5, ge	// ge = tcont
 354:	7a47a82a 	ccmp	w1, #0x7, #0xa, ge	// ge = tcont
 358:	1a82b020 	csel	w0, w1, w2, lt	// lt = tstop
 35c:	1a82b420 	csinc	w0, w1, w2, lt	// lt = tstop
 360:	5a82b020 	csinv	w0, w1, w2, lt	// lt = tstop
 364:	5a82b420 	csneg	w0, w1, w2, lt	// lt = tstop
 368:	1a81a420 	cinc	w0, w1, lt	// lt = tstop
 36c:	5a81a020 	cinv	w0, w1, lt	// lt = tstop
 370:	5a81a420 	cneg	w0, w1, lt	// lt = tstop
 374:	1a9fa7e0 	cset	w0, lt	// lt = tstop
 378:	5a9fa3e0 	csetm	w0, lt	// lt = tstop
 37c:	7a42b025 	ccmp	w1, w2, #0x5, lt	// lt = tstop
 380:	7a47b82a 	ccmp	w1, #0x7, #0xa, lt	// lt = tstop
 384:	1a82c020 	csel	w0, w1, w2, gt
 388:	1a82c420 	csinc	w0, w1, w2, gt
 38c:	5a82c020 	csinv	w0, w1, w2, gt
 390:	5a82c420 	csneg	w0, w1, w2, gt
 394:	1a81d420 	cinc	w0, w1, gt
 398:	5a81d020 	cinv	w0, w1, gt
 39c:	5a81d420 	cneg	w0, w1, gt
 3a0:	1a9fd7e0 	cset	w0, gt
 3a4:	5a9fd3e0 	csetm	w0, gt
 3a8:	7a42c025 	ccmp	w1, w2, #0x5, gt
 3ac:	7a47c82a 	ccmp	w1, #0x7, #0xa, gt
 3b0:	1a82d020 	csel	w0, w1, w2, le
 3b4:	1a82d420 	csinc	w0, w1, w2, le
 3b8:	5a82d020 	csinv	w0, w1, w2, le
 3bc:	5a82d420 	csneg	w0, w1, w2, le
 3c0:	1a81c420 	cinc	w0, w1, le
 3c4:	5a81c020 	cinv	w0, w1, le
 3c8:	5a81c420 	cneg	w0, w1, le
 3cc:	1a9fc7e0 	cset	w0, le
 3d0:	5a9fc3e0 	csetm	w0, le
 3d4:	7a42d025 	ccmp	w1, w2, #0x5, le
 3d8:	7a47d82a 	ccmp	w1, #0x7, #0xa, le
 3dc:	1a82e020 	csel	w0, w1, w2, al
 3e0:	1a82e420 	csinc	w0, w1, w2, al
 3e4:	5a82e020 	csinv	w0, w1, w2, al
 3e8:	5a82e420 	csneg	w0, w1, w2, al
 3ec:	7a42e025 	ccmp	w1, w2, #0x5, al
 3f0:	7a47e82a 	ccmp	w1, #0x7, #0xa, al
 3f4:	1a82f020 	csel	w0, w1, w2, nv
 3f8:	1a82f420 	csinc	w0, w1, w2, nv
 3fc:	5a82f020 	csinv	w0, w1, w2, nv
 400:	5a82f420 	csneg	w0, w1, w2, nv
 404:	7a42f025 	ccmp	w1, w2, #0x5, nv
 408:	7a47f82a 	ccmp	w1, #0x7, #0xa, nv
 40c:	b9400880 	ldr	w0, [x4, #8]
 410:	b9000880 	str	w0, [x4, #8]
 414:	b8408080 	ldur	w0, [x4, #8]
 418:	b8008080 	stur	w0, [x4, #8]
 41c:	b8408c80 	ldr	w0, [x4, #8]!
 420:	b8408480 	ldr	w0, [x4], #8
 424:	b8657880 	ldr	w0, [x4, x5, lsl #2]
 428:	b8008c80 	str	w0, [x4, #8]!
 42c:	b8008480 	str	w0, [x4], #8
 430:	b8257880 	str	w0, [x4, x5, lsl #2]
 434:	39402080 	ldrb	w0, [x4, #8]
 438:	79401080 	ldrh	w0, [x4, #8]
 43c:	39002080 	strb	w0, [x4, #8]
 440:	79001080 	strh	w0, [x4, #8]
 444:	39c02080 	ldrsb	w0, [x4, #8]
 448:	79c01080 	ldrsh	w0, [x4, #8]
 44c:	8b020020 	add	x0, x1, x2
 450:	8b020c20 	add	x0, x1, x2, lsl #3
 454:	9101fc20 	add	x0, x1, #0x7f
 458:	cb020020 	sub	x0, x1, x2
 45c:	cb020c20 	sub	x0, x1, x2, lsl #3
 460:	d101fc20 	sub	x0, x1, #0x7f
 464:	8a020020 	and	x0, x1, x2
 468:	8a020c20 	and	x0, x1, x2, lsl #3
 46c:	8a220020 	bic	x0, x1, x2
 470:	8a220c20 	bic	x0, x1, x2, lsl #3
 474:	ca020020 	eor	x0, x1, x2
 478:	ca020c20 	eor	x0, x1, x2, lsl #3
 47c:	aa020020 	orr	x0, x1, x2
 480:	aa020c20 	orr	x0, x1, x2, lsl #3
 484:	aa220020 	orn	x0, x1, x2
 488:	aa220c20 	orn	x0, x1, x2, lsl #3
 48c:	ab020020 	adds	x0, x1, x2
 490:	ab020c20 	adds	x0, x1, x2, lsl #3
 494:	b101fc20 	adds	x0, x1, #0x7f
 498:	eb020020 	subs	x0, x1, x2
 49c:	eb020c20 	subs	x0, x1, x2, lsl #3
 4a0:	f101fc20 	subs	x0, x1, #0x7f
 4a4:	ea020020 	ands	x0, x1, x2
 4a8:	ea020c20 	ands	x0, x1, x2, lsl #3
 4ac:	ea220020 	bics	x0, x1, x2
 4b0:	ea220c20 	bics	x0, x1, x2, lsl #3
 4b4:	eb02003f 	cmp	x1, x2
 4b8:	eb020c3f 	cmp	x1, x2, lsl #3
 4bc:	ab02003f 	cmn	x1, x2
 4c0:	ab020c3f 	cmn	x1, x2, lsl #3
 4c4:	ea02003f 	tst	x1, x2
 4c8:	ea020c3f 	tst	x1, x2, lsl #3
 4cc:	aa0103e0 	mov	x0, x1
 4d0:	d2800fe0 	mov	x0, #0x7f                  	// #127
 4d4:	f2bbd5a0 	movk	x0, #0xdead, lsl #16
 4d8:	aa2103e0 	mvn	x0, x1
 4dc:	cb0103e0 	neg	x0, x1
 4e0:	dac00c20 	rev	x0, x1
 4e4:	dac00420 	rev16	x0, x1
 4e8:	93401c20 	sxtb	x0, w1
 4ec:	93403c20 	sxth	x0, w1
 4f0:	aa2103e0 	mvn	x0, x1
 4f4:	aa2107e0 	mvn	x0, x1, lsl #1
 4f8:	aa21ffe0 	mvn	x0, x1, lsl #63
 4fc:	aa6103e0 	mvn	x0, x1, lsr #0
 500:	aa6107e0 	mvn	x0, x1, lsr #1
 504:	aa61ffe0 	mvn	x0, x1, lsr #63
 508:	aaa103e0 	mvn	x0, x1, asr #0
 50c:	aaa107e0 	mvn	x0, x1, asr #1
 510:	aaa1ffe0 	mvn	x0, x1, asr #63
 514:	aae103e0 	mvn	x0, x1, ror #0
 518:	aae107e0 	mvn	x0, x1, ror #1
 51c:	aae1ffe0 	mvn	x0, x1, ror #63
 520:	cb0103e0 	neg	x0, x1
 524:	cb0107e0 	neg	x0, x1, lsl #1
 528:	cb01ffe0 	neg	x0, x1, lsl #63
 52c:	cb4103e0 	neg	x0, x1, lsr #0
 530:	cb4107e0 	neg	x0, x1, lsr #1
 534:	cb41ffe0 	neg	x0, x1, lsr #63
 538:	cb8103e0 	neg	x0, x1, asr #0
 53c:	cb8107e0 	neg	x0, x1, asr #1
 540:	cb81ffe0 	neg	x0, x1, asr #63
 544:	9b027c20 	mul	x0, x1, x2
 548:	9ac20820 	udiv	x0, x1, x2
 54c:	9b020c20 	madd	x0, x1, x2, x3
 550:	9b028c20 	msub	x0, x1, x2, x3
 554:	9ac22020 	lsl	x0, x1, x2
 558:	d340fc20 	lsr	x0, x1, #0
 55c:	d37ff820 	lsl	x0, x1, #1
 560:	d379e020 	lsl	x0, x1, #7
 564:	d3618020 	lsl	x0, x1, #31
 568:	9ac22420 	lsr	x0, x1, x2
 56c:	d340fc20 	lsr	x0, x1, #0
 570:	d341fc20 	lsr	x0, x1, #1
 574:	d347fc20 	lsr	x0, x1, #7
 578:	d35ffc20 	lsr	x0, x1, #31
 57c:	9ac22820 	asr	x0, x1, x2
 580:	9340fc20 	asr	x0, x1, #0
 584:	9341fc20 	asr	x0, x1, #1
 588:	9347fc20 	asr	x0, x1, #7
 58c:	935ffc20 	asr	x0, x1, #31
 590:	9ac22c20 	ror	x0, x1, x2
 594:	93c10020 	ror	x0, x1, #0
 598:	93c10420 	ror	x0, x1, #1
 59c:	93c11c20 	ror	x0, x1, #7
 5a0:	93c17c20 	ror	x0, x1, #31
 5a4:	93c21c20 	extr	x0, x1, x2, #7
 5a8:	d3474c20 	ubfx	x0, x1, #7, #13
 5ac:	93474c20 	sbfx	x0, x1, #7, #13
 5b0:	d3793020 	ubfiz	x0, x1, #7, #13
 5b4:	b3474c20 	bfxil	x0, x1, #7, #13
 5b8:	b3793020 	bfi	x0, x1, #7, #13
 5bc:	9a820020 	csel	x0, x1, x2, eq	// eq = none
 5c0:	9a820420 	csinc	x0, x1, x2, eq	// eq = none
 5c4:	da820020 	csinv	x0, x1, x2, eq	// eq = none
 5c8:	da820420 	csneg	x0, x1, x2, eq	// eq = none
 5cc:	9a811420 	cinc	x0, x1, eq	// eq = none
 5d0:	da811020 	cinv	x0, x1, eq	// eq = none
 5d4:	da811420 	cneg	x0, x1, eq	// eq = none
 5d8:	9a9f17e0 	cset	x0, eq	// eq = none
 5dc:	da9f13e0 	csetm	x0, eq	// eq = none
 5e0:	fa420025 	ccmp	x1, x2, #0x5, eq	// eq = none
 5e4:	fa47082a 	ccmp	x1, #0x7, #0xa, eq	// eq = none
 5e8:	9a821020 	csel	x0, x1, x2, ne	// ne = any
 5ec:	9a821420 	csinc	x0, x1, x2, ne	// ne = any
 5f0:	da821020 	csinv	x0, x1, x2, ne	// ne = any
 5f4:	da821420 	csneg	x0, x1, x2, ne	// ne = any
 5f8:	9a810420 	cinc	x0, x1, ne	// ne = any
 5fc:	da810020 	cinv	x0, x1, ne	// ne = any
 600:	da810420 	cneg	x0, x1, ne	// ne = any
 604:	9a9f07e0 	cset	x0, ne	// ne = any
 608:	da9f03e0 	csetm	x0, ne	// ne = any
 60c:	fa421025 	ccmp	x1, x2, #0x5, ne	// ne = any
 610:	fa47182a 	ccmp	x1, #0x7, #0xa, ne	// ne = any
 614:	9a822020 	csel	x0, x1, x2, cs	// cs = hs, nlast
 618:	9a822420 	csinc	x0, x1, x2, cs	// cs = hs, nlast
 61c:	da822020 	csinv	x0, x1, x2, cs	// cs = hs, nlast
 620:	da822420 	csneg	x0, x1, x2, cs	// cs = hs, nlast
 624:	9a813420 	cinc	x0, x1, cs	// cs = hs, nlast
 628:	da813020 	cinv	x0, x1, cs	// cs = hs, nlast
 62c:	da813420 	cneg	x0, x1, cs	// cs = hs, nlast
 630:	9a9f37e0 	cset	x0, cs	// cs = hs, nlast
 634:	da9f33e0 	csetm	x0, cs	// cs = hs, nlast
 638:	fa422025 	ccmp	x1, x2, #0x5, cs	// cs = hs, nlast
 63c:	fa47282a 	ccmp	x1, #0x7, #0xa, cs	// cs = hs, nlast
 640:	9a823020 	csel	x0, x1, x2, cc	// cc = lo, ul, last
 644:	9a823420 	csinc	x0, x1, x2, cc	// cc = lo, ul, last
 648:	da823020 	csinv	x0, x1, x2, cc	// cc = lo, ul, last
 64c:	da823420 	csneg	x0, x1, x2, cc	// cc = lo, ul, last
 650:	9a812420 	cinc	x0, x1, cc	// cc = lo, ul, last
 654:	da812020 	cinv	x0, x1, cc	// cc = lo, ul, last
 658:	da812420 	cneg	x0, x1, cc	// cc = lo, ul, last
 65c:	9a9f27e0 	cset	x0, cc	// cc = lo, ul, last
 660:	da9f23e0 	csetm	x0, cc	// cc = lo, ul, last
 664:	fa423025 	ccmp	x1, x2, #0x5, cc	// cc = lo, ul, last
 668:	fa47382a 	ccmp	x1, #0x7, #0xa, cc	// cc = lo, ul, last
 66c:	9a824020 	csel	x0, x1, x2, mi	// mi = first
 670:	9a824420 	csinc	x0, x1, x2, mi	// mi = first
 674:	da824020 	csinv	x0, x1, x2, mi	// mi = first
 678:	da824420 	csneg	x0, x1, x2, mi	// mi = first
 67c:	9a815420 	cinc	x0, x1, mi	// mi = first
 680:	da815020 	cinv	x0, x1, mi	// mi = first
 684:	da815420 	cneg	x0, x1, mi	// mi = first
 688:	9a9f57e0 	cset	x0, mi	// mi = first
 68c:	da9f53e0 	csetm	x0, mi	// mi = first
 690:	fa424025 	ccmp	x1, x2, #0x5, mi	// mi = first
 694:	fa47482a 	ccmp	x1, #0x7, #0xa, mi	// mi = first
 698:	9a825020 	csel	x0, x1, x2, pl	// pl = nfrst
 69c:	9a825420 	csinc	x0, x1, x2, pl	// pl = nfrst
 6a0:	da825020 	csinv	x0, x1, x2, pl	// pl = nfrst
 6a4:	da825420 	csneg	x0, x1, x2, pl	// pl = nfrst
 6a8:	9a814420 	cinc	x0, x1, pl	// pl = nfrst
 6ac:	da814020 	cinv	x0, x1, pl	// pl = nfrst
 6b0:	da814420 	cneg	x0, x1, pl	// pl = nfrst
 6b4:	9a9f47e0 	cset	x0, pl	// pl = nfrst
 6b8:	da9f43e0 	csetm	x0, pl	// pl = nfrst
 6bc:	fa425025 	ccmp	x1, x2, #0x5, pl	// pl = nfrst
 6c0:	fa47582a 	ccmp	x1, #0x7, #0xa, pl	// pl = nfrst
 6c4:	9a826020 	csel	x0, x1, x2, vs
 6c8:	9a826420 	csinc	x0, x1, x2, vs
 6cc:	da826020 	csinv	x0, x1, x2, vs
 6d0:	da826420 	csneg	x0, x1, x2, vs
 6d4:	9a817420 	cinc	x0, x1, vs
 6d8:	da817020 	cinv	x0, x1, vs
 6dc:	da817420 	cneg	x0, x1, vs
 6e0:	9a9f77e0 	cset	x0, vs
 6e4:	da9f73e0 	csetm	x0, vs
 6e8:	fa426025 	ccmp	x1, x2, #0x5, vs
 6ec:	fa47682a 	ccmp	x1, #0x7, #0xa, vs
 6f0:	9a827020 	csel	x0, x1, x2, vc
 6f4:	9a827420 	csinc	x0, x1, x2, vc
 6f8:	da827020 	csinv	x0, x1, x2, vc
 6fc:	da827420 	csneg	x0, x1, x2, vc
 700:	9a816420 	cinc	x0, x1, vc
 704:	da816020 	cinv	x0, x1, vc
 708:	da816420 	cneg	x0, x1, vc
 70c:	9a9f67e0 	cset	x0, vc
 710:	da9f63e0 	csetm	x0, vc
 714:	fa427025 	ccmp	x1, x2, #0x5, vc
 718:	fa47782a 	ccmp	x1, #0x7, #0xa, vc
 71c:	9a828020 	csel	x0, x1, x2, hi	// hi = pmore
 720:	9a828420 	csinc	x0, x1, x2, hi	// hi = pmore
 724:	da828020 	csinv	x0, x1, x2, hi	// hi = pmore
 728:	da828420 	csneg	x0, x1, x2, hi	// hi = pmore
 72c:	9a819420 	cinc	x0, x1, hi	// hi = pmore
 730:	da819020 	cinv	x0, x1, hi	// hi = pmore
 734:	da819420 	cneg	x0, x1, hi	// hi = pmore
 738:	9a9f97e0 	cset	x0, hi	// hi = pmore
 73c:	da9f93e0 	csetm	x0, hi	// hi = pmore
 740:	fa428025 	ccmp	x1, x2, #0x5, hi	// hi = pmore
 744:	fa47882a 	ccmp	x1, #0x7, #0xa, hi	// hi = pmore
 748:	9a829020 	csel	x0, x1, x2, ls	// ls = plast
 74c:	9a829420 	csinc	x0, x1, x2, ls	// ls = plast
 750:	da829020 	csinv	x0, x1, x2, ls	// ls = plast
 754:	da829420 	csneg	x0, x1, x2, ls	// ls = plast
 758:	9a818420 	cinc	x0, x1, ls	// ls = plast
 75c:	da818020 	cinv	x0, x1, ls	// ls = plast
 760:	da818420 	cneg	x0, x1, ls	// ls = plast
 764:	9a9f87e0 	cset	x0, ls	// ls = plast
 768:	da9f83e0 	csetm	x0, ls	// ls = plast
 76c:	fa429025 	ccmp	x1, x2, #0x5, ls	// ls = plast
 770:	fa47982a 	ccmp	x1, #0x7, #0xa, ls	// ls = plast
 774:	9a82a020 	csel	x0, x1, x2, ge	// ge = tcont
 778:	9a82a420 	csinc	x0, x1, x2, ge	// ge = tcont
 77c:	da82a020 	csinv	x0, x1, x2, ge	// ge = tcont
 780:	da82a420 	csneg	x0, x1, x2, ge	// ge = tcont
 784:	9a81b420 	cinc	x0, x1, ge	// ge = tcont
 788:	da81b020 	cinv	x0, x1, ge	// ge = tcont
 78c:	da81b420 	cneg	x0, x1, ge	// ge = tcont
 790:	9a9fb7e0 	cset	x0, ge	// ge = tcont
 794:	da9fb3e0 	csetm	x0, ge	// ge = tcont
 798:	fa42a025 	ccmp	x1, x2, #0x5, ge	// ge = tcont
 79c:	fa47a82a 	ccmp	x1, #0x7, #0xa, ge	// ge = tcont
 7a0:	9a82b020 	csel	x0, x1, x2, lt	// lt = tstop
 7a4:	9a82b420 	csinc	x0, x1, x2, lt	// lt = tstop
 7a8:	da82b020 	csinv	x0, x1, x2, lt	// lt = tstop
 7ac:	da82b420 	csneg	x0, x1, x2, lt	// lt = tstop
 7b0:	9a81a420 	cinc	x0, x1, lt	// lt = tstop
 7b4:	da81a020 	cinv	x0, x1, lt	// lt = tstop
 7b8:	da81a420 	cneg	x0, x1, lt	// lt = tstop
 7bc:	9a9fa7e0 	cset	x0, lt	// lt = tstop
 7c0:	da9fa3e0 	csetm	x0, lt	// lt = tstop
 7c4:	fa42b025 	ccmp	x1, x2, #0x5, lt	// lt = tstop
 7c8:	fa47b82a 	ccmp	x1, #0x7, #0xa, lt	// lt = tstop
 7cc:	9a82c020 	csel	x0, x1, x2, gt
 7d0:	9a82c420 	csinc	x0, x1, x2, gt
 7d4:	da82c020 	csinv	x0, x1, x2, gt
 7d8:	da82c420 	csneg	x0, x1, x2, gt
 7dc:	9a81d420 	cinc	x0, x1, gt
 7e0:	da81d020 	cinv	x0, x1, gt
 7e4:	da81d420 	cneg	x0, x1, gt
 7e8:	9a9fd7e0 	cset	x0, gt
 7ec:	da9fd3e0 	csetm	x0, gt
 7f0:	fa42c025 	ccmp	x1, x2, #0x5, gt
 7f4:	fa47c82a 	ccmp	x1, #0x7, #0xa, gt
 7f8:	9a82d020 	csel	x0, x1, x2, le
 7fc:	9a82d420 	csinc	x0, x1, x2, le
 800:	da82d020 	csinv	x0, x1, x2, le
 804:	da82d420 	csneg	x0, x1, x2, le
 808:	9a81c420 	cinc	x0, x1, le
 80c:	da81c020 	cinv	x0, x1, le
 810:	da81c420 	cneg	x0, x1, le
 814:	9a9fc7e0 	cset	x0, le
 818:	da9fc3e0 	csetm	x0, le
 81c:	fa42d025 	ccmp	x1, x2, #0x5, le
 820:	fa47d82a 	ccmp	x1, #0x7, #0xa, le
 824:	9a82e020 	csel	x0, x1, x2, al
 828:	9a82e420 	csinc	x0, x1, x2, al
 82c:	da82e020 	csinv	x0, x1, x2, al
 830:	da82e420 	csneg	x0, x1, x2, al
 834:	fa42e025 	ccmp	x1, x2, #0x5, al
 838:	fa47e82a 	ccmp	x1, #0x7, #0xa, al
 83c:	9a82f020 	csel	x0, x1, x2, nv
 840:	9a82f420 	csinc	x0, x1, x2, nv
 844:	da82f020 	csinv	x0, x1, x2, nv
 848:	da82f420 	csneg	x0, x1, x2, nv
 84c:	fa42f025 	ccmp	x1, x2, #0x5, nv
 850:	fa47f82a 	ccmp	x1, #0x7, #0xa, nv
 854:	f9400480 	ldr	x0, [x4, #8]
 858:	f9000480 	str	x0, [x4, #8]
 85c:	f8408080 	ldur	x0, [x4, #8]
 860:	f8008080 	stur	x0, [x4, #8]
 864:	f8408c80 	ldr	x0, [x4, #8]!
 868:	f8408480 	ldr	x0, [x4], #8
 86c:	f8657880 	ldr	x0, [x4, x5, lsl #3]
 870:	f8008c80 	str	x0, [x4, #8]!
 874:	f8008480 	str	x0, [x4], #8
 878:	f8257880 	str	x0, [x4, x5, lsl #3]
 87c:	39802080 	ldrsb	x0, [x4, #8]
 880:	79801080 	ldrsh	x0, [x4, #8]
 884:	93407c20 	sxtw	x0, w1
 888:	9bc27c20 	umulh	x0, x1, x2
 88c:	9ba27c20 	umull	x0, w1, w2
 890:	9ba20c20 	umaddl	x0, w1, w2, x3
 894:	9b220c20 	smaddl	x0, w1, w2, x3
 898:	b9800880 	ldrsw	x0, [x4, #8]
 89c:	a9408480 	ldp	x0, x1, [x4, #8]
 8a0:	a9008480 	stp	x0, x1, [x4, #8]
 8a4:	9e670000 	fmov	d0, x0
 8a8:	9e660000 	fmov	x0, d0
 8ac:	1e270000 	fmov	s0, w0
 8b0:	1e260000 	fmov	w0, s0
 8b4:	0e205800 	cnt	v0.8b, v0.8b
 8b8:	4e205800 	cnt	v0.16b, v0.16b
 8bc:	2e303800 	uaddlv	h0, v0.8b
 8c0:	6e303800 	uaddlv	h0, v0.16b
 8c4:	3dc00480 	ldr	q0, [x4, #16]
 8c8:	3d800480 	str	q0, [x4, #16]
