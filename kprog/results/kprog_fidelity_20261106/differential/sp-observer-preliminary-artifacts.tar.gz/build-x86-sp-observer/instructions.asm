
build-x86-sp-observer/instructions.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <.text>:
   0:	53                                              	push   rbx
   1:	58                                              	pop    rax
   2:	66 53                                           	push   bx
   4:	66 58                                           	pop    ax
   6:	90                                              	nop
   7:	48 98                                           	cdqe
   9:	0f 10 07                                        	movups xmm0,XMMWORD PTR [rdi]
   c:	0f 11 07                                        	movups XMMWORD PTR [rdi],xmm0
   f:	48 89 e0                                        	mov    rax,rsp
  12:	89 e0                                           	mov    eax,esp
  14:	48 8d 44 24 10                                  	lea    rax,[rsp+0x10]
  19:	48 83 fc 00                                     	cmp    rsp,0x0
  1d:	48 89 c4                                        	mov    rsp,rax
  20:	89 c4                                           	mov    esp,eax
  22:	48 8d 64 24 10                                  	lea    rsp,[rsp+0x10]
  27:	54                                              	push   rsp
  28:	5c                                              	pop    rsp
  29:	66 54                                           	push   sp
  2b:	66 5c                                           	pop    sp
  2d:	68 00 00 00 80                                  	push   0xffffffff80000000
  32:	6a 80                                           	push   0xffffffffffffff80
  34:	6a ff                                           	push   0xffffffffffffffff
  36:	6a 00                                           	push   0x0
  38:	6a 01                                           	push   0x1
  3a:	6a 7f                                           	push   0x7f
  3c:	68 80 00 00 00                                  	push   0x80
  41:	68 78 56 34 12                                  	push   0x12345678
  46:	66 6a f9                                        	pushw  0xfff9
  49:	ff 77 08                                        	push   QWORD PTR [rdi+0x8]
  4c:	66 ff 77 08                                     	push   WORD PTR [rdi+0x8]
  50:	8f 47 08                                        	pop    QWORD PTR [rdi+0x8]
  53:	66 8f 47 08                                     	pop    WORD PTR [rdi+0x8]
  57:	ff 74 24 f0                                     	push   QWORD PTR [rsp-0x10]
  5b:	8f 44 24 f0                                     	pop    QWORD PTR [rsp-0x10]
  5f:	66 48 53                                        	data16 rex.W push rbx
  62:	48                                              	rex.W
  63:	66 53                                           	push   bx
  65:	66 48 ff f3                                     	data16 rex.W push rbx
  69:	48                                              	rex.W
  6a:	66 ff f3                                        	push   bx
  6d:	66 48 58                                        	data16 rex.W pop rax
  70:	48                                              	rex.W
  71:	66 58                                           	pop    ax
  73:	66 48 8f c0                                     	data16 rex.W pop rax
  77:	48                                              	rex.W
  78:	66 8f c0                                        	pop    ax
  7b:	88 d8                                           	mov    al,bl
  7d:	b0 7f                                           	mov    al,0x7f
  7f:	88 47 08                                        	mov    BYTE PTR [rdi+0x8],al
  82:	8a 47 08                                        	mov    al,BYTE PTR [rdi+0x8]
  85:	c6 47 08 7f                                     	mov    BYTE PTR [rdi+0x8],0x7f
  89:	00 d8                                           	add    al,bl
  8b:	04 7f                                           	add    al,0x7f
  8d:	00 47 08                                        	add    BYTE PTR [rdi+0x8],al
  90:	80 47 08 7f                                     	add    BYTE PTR [rdi+0x8],0x7f
  94:	02 47 08                                        	add    al,BYTE PTR [rdi+0x8]
  97:	10 d8                                           	adc    al,bl
  99:	14 7f                                           	adc    al,0x7f
  9b:	10 47 08                                        	adc    BYTE PTR [rdi+0x8],al
  9e:	80 57 08 7f                                     	adc    BYTE PTR [rdi+0x8],0x7f
  a2:	12 47 08                                        	adc    al,BYTE PTR [rdi+0x8]
  a5:	28 d8                                           	sub    al,bl
  a7:	2c 7f                                           	sub    al,0x7f
  a9:	28 47 08                                        	sub    BYTE PTR [rdi+0x8],al
  ac:	80 6f 08 7f                                     	sub    BYTE PTR [rdi+0x8],0x7f
  b0:	2a 47 08                                        	sub    al,BYTE PTR [rdi+0x8]
  b3:	18 d8                                           	sbb    al,bl
  b5:	1c 7f                                           	sbb    al,0x7f
  b7:	18 47 08                                        	sbb    BYTE PTR [rdi+0x8],al
  ba:	80 5f 08 7f                                     	sbb    BYTE PTR [rdi+0x8],0x7f
  be:	1a 47 08                                        	sbb    al,BYTE PTR [rdi+0x8]
  c1:	38 d8                                           	cmp    al,bl
  c3:	3c 7f                                           	cmp    al,0x7f
  c5:	38 47 08                                        	cmp    BYTE PTR [rdi+0x8],al
  c8:	80 7f 08 7f                                     	cmp    BYTE PTR [rdi+0x8],0x7f
  cc:	3a 47 08                                        	cmp    al,BYTE PTR [rdi+0x8]
  cf:	84 d8                                           	test   al,bl
  d1:	a8 7f                                           	test   al,0x7f
  d3:	84 47 08                                        	test   BYTE PTR [rdi+0x8],al
  d6:	f6 47 08 7f                                     	test   BYTE PTR [rdi+0x8],0x7f
  da:	20 d8                                           	and    al,bl
  dc:	24 7f                                           	and    al,0x7f
  de:	22 47 08                                        	and    al,BYTE PTR [rdi+0x8]
  e1:	20 47 08                                        	and    BYTE PTR [rdi+0x8],al
  e4:	80 67 08 7f                                     	and    BYTE PTR [rdi+0x8],0x7f
  e8:	08 d8                                           	or     al,bl
  ea:	0c 7f                                           	or     al,0x7f
  ec:	0a 47 08                                        	or     al,BYTE PTR [rdi+0x8]
  ef:	08 47 08                                        	or     BYTE PTR [rdi+0x8],al
  f2:	80 4f 08 7f                                     	or     BYTE PTR [rdi+0x8],0x7f
  f6:	30 d8                                           	xor    al,bl
  f8:	34 7f                                           	xor    al,0x7f
  fa:	32 47 08                                        	xor    al,BYTE PTR [rdi+0x8]
  fd:	30 47 08                                        	xor    BYTE PTR [rdi+0x8],al
 100:	80 77 08 7f                                     	xor    BYTE PTR [rdi+0x8],0x7f
 104:	fe c0                                           	inc    al
 106:	fe 47 08                                        	inc    BYTE PTR [rdi+0x8]
 109:	fe c8                                           	dec    al
 10b:	fe 4f 08                                        	dec    BYTE PTR [rdi+0x8]
 10e:	f6 d8                                           	neg    al
 110:	f6 5f 08                                        	neg    BYTE PTR [rdi+0x8]
 113:	f6 d0                                           	not    al
 115:	f6 57 08                                        	not    BYTE PTR [rdi+0x8]
 118:	86 d8                                           	xchg   al,bl
 11a:	c0 e0 00                                        	shl    al,0x0
 11d:	d0 e0                                           	shl    al,1
 11f:	c0 e0 07                                        	shl    al,0x7
 122:	c0 e0 08                                        	shl    al,0x8
 125:	c0 e0 0f                                        	shl    al,0xf
 128:	c0 e0 10                                        	shl    al,0x10
 12b:	c0 e0 1f                                        	shl    al,0x1f
 12e:	c0 e0 20                                        	shl    al,0x20
 131:	c0 e0 3f                                        	shl    al,0x3f
 134:	c0 e0 40                                        	shl    al,0x40
 137:	c0 e0 ff                                        	shl    al,0xff
 13a:	d2 e0                                           	shl    al,cl
 13c:	c0 e8 00                                        	shr    al,0x0
 13f:	d0 e8                                           	shr    al,1
 141:	c0 e8 07                                        	shr    al,0x7
 144:	c0 e8 08                                        	shr    al,0x8
 147:	c0 e8 0f                                        	shr    al,0xf
 14a:	c0 e8 10                                        	shr    al,0x10
 14d:	c0 e8 1f                                        	shr    al,0x1f
 150:	c0 e8 20                                        	shr    al,0x20
 153:	c0 e8 3f                                        	shr    al,0x3f
 156:	c0 e8 40                                        	shr    al,0x40
 159:	c0 e8 ff                                        	shr    al,0xff
 15c:	d2 e8                                           	shr    al,cl
 15e:	c0 f8 00                                        	sar    al,0x0
 161:	d0 f8                                           	sar    al,1
 163:	c0 f8 07                                        	sar    al,0x7
 166:	c0 f8 08                                        	sar    al,0x8
 169:	c0 f8 0f                                        	sar    al,0xf
 16c:	c0 f8 10                                        	sar    al,0x10
 16f:	c0 f8 1f                                        	sar    al,0x1f
 172:	c0 f8 20                                        	sar    al,0x20
 175:	c0 f8 3f                                        	sar    al,0x3f
 178:	c0 f8 40                                        	sar    al,0x40
 17b:	c0 f8 ff                                        	sar    al,0xff
 17e:	d2 f8                                           	sar    al,cl
 180:	c0 c0 00                                        	rol    al,0x0
 183:	d0 c0                                           	rol    al,1
 185:	c0 c0 07                                        	rol    al,0x7
 188:	c0 c0 08                                        	rol    al,0x8
 18b:	c0 c0 0f                                        	rol    al,0xf
 18e:	c0 c0 10                                        	rol    al,0x10
 191:	c0 c0 1f                                        	rol    al,0x1f
 194:	c0 c0 20                                        	rol    al,0x20
 197:	c0 c0 3f                                        	rol    al,0x3f
 19a:	c0 c0 40                                        	rol    al,0x40
 19d:	c0 c0 ff                                        	rol    al,0xff
 1a0:	d2 c0                                           	rol    al,cl
 1a2:	66 89 d8                                        	mov    ax,bx
 1a5:	66 b8 7f 00                                     	mov    ax,0x7f
 1a9:	66 89 47 08                                     	mov    WORD PTR [rdi+0x8],ax
 1ad:	66 8b 47 08                                     	mov    ax,WORD PTR [rdi+0x8]
 1b1:	66 c7 47 08 7f 00                               	mov    WORD PTR [rdi+0x8],0x7f
 1b7:	66 01 d8                                        	add    ax,bx
 1ba:	66 83 c0 7f                                     	add    ax,0x7f
 1be:	66 01 47 08                                     	add    WORD PTR [rdi+0x8],ax
 1c2:	66 83 47 08 7f                                  	add    WORD PTR [rdi+0x8],0x7f
 1c7:	66 03 47 08                                     	add    ax,WORD PTR [rdi+0x8]
 1cb:	66 11 d8                                        	adc    ax,bx
 1ce:	66 83 d0 7f                                     	adc    ax,0x7f
 1d2:	66 11 47 08                                     	adc    WORD PTR [rdi+0x8],ax
 1d6:	66 83 57 08 7f                                  	adc    WORD PTR [rdi+0x8],0x7f
 1db:	66 13 47 08                                     	adc    ax,WORD PTR [rdi+0x8]
 1df:	66 29 d8                                        	sub    ax,bx
 1e2:	66 83 e8 7f                                     	sub    ax,0x7f
 1e6:	66 29 47 08                                     	sub    WORD PTR [rdi+0x8],ax
 1ea:	66 83 6f 08 7f                                  	sub    WORD PTR [rdi+0x8],0x7f
 1ef:	66 2b 47 08                                     	sub    ax,WORD PTR [rdi+0x8]
 1f3:	66 19 d8                                        	sbb    ax,bx
 1f6:	66 83 d8 7f                                     	sbb    ax,0x7f
 1fa:	66 19 47 08                                     	sbb    WORD PTR [rdi+0x8],ax
 1fe:	66 83 5f 08 7f                                  	sbb    WORD PTR [rdi+0x8],0x7f
 203:	66 1b 47 08                                     	sbb    ax,WORD PTR [rdi+0x8]
 207:	66 39 d8                                        	cmp    ax,bx
 20a:	66 83 f8 7f                                     	cmp    ax,0x7f
 20e:	66 39 47 08                                     	cmp    WORD PTR [rdi+0x8],ax
 212:	66 83 7f 08 7f                                  	cmp    WORD PTR [rdi+0x8],0x7f
 217:	66 3b 47 08                                     	cmp    ax,WORD PTR [rdi+0x8]
 21b:	66 85 d8                                        	test   ax,bx
 21e:	66 a9 7f 00                                     	test   ax,0x7f
 222:	66 85 47 08                                     	test   WORD PTR [rdi+0x8],ax
 226:	66 f7 47 08 7f 00                               	test   WORD PTR [rdi+0x8],0x7f
 22c:	66 21 d8                                        	and    ax,bx
 22f:	66 83 e0 7f                                     	and    ax,0x7f
 233:	66 23 47 08                                     	and    ax,WORD PTR [rdi+0x8]
 237:	66 21 47 08                                     	and    WORD PTR [rdi+0x8],ax
 23b:	66 83 67 08 7f                                  	and    WORD PTR [rdi+0x8],0x7f
 240:	66 09 d8                                        	or     ax,bx
 243:	66 83 c8 7f                                     	or     ax,0x7f
 247:	66 0b 47 08                                     	or     ax,WORD PTR [rdi+0x8]
 24b:	66 09 47 08                                     	or     WORD PTR [rdi+0x8],ax
 24f:	66 83 4f 08 7f                                  	or     WORD PTR [rdi+0x8],0x7f
 254:	66 31 d8                                        	xor    ax,bx
 257:	66 83 f0 7f                                     	xor    ax,0x7f
 25b:	66 33 47 08                                     	xor    ax,WORD PTR [rdi+0x8]
 25f:	66 31 47 08                                     	xor    WORD PTR [rdi+0x8],ax
 263:	66 83 77 08 7f                                  	xor    WORD PTR [rdi+0x8],0x7f
 268:	66 ff c0                                        	inc    ax
 26b:	66 ff 47 08                                     	inc    WORD PTR [rdi+0x8]
 26f:	66 ff c8                                        	dec    ax
 272:	66 ff 4f 08                                     	dec    WORD PTR [rdi+0x8]
 276:	66 f7 d8                                        	neg    ax
 279:	66 f7 5f 08                                     	neg    WORD PTR [rdi+0x8]
 27d:	66 f7 d0                                        	not    ax
 280:	66 f7 57 08                                     	not    WORD PTR [rdi+0x8]
 284:	66 93                                           	xchg   bx,ax
 286:	66 c1 e0 00                                     	shl    ax,0x0
 28a:	66 d1 e0                                        	shl    ax,1
 28d:	66 c1 e0 07                                     	shl    ax,0x7
 291:	66 c1 e0 08                                     	shl    ax,0x8
 295:	66 c1 e0 0f                                     	shl    ax,0xf
 299:	66 c1 e0 10                                     	shl    ax,0x10
 29d:	66 c1 e0 1f                                     	shl    ax,0x1f
 2a1:	66 c1 e0 20                                     	shl    ax,0x20
 2a5:	66 c1 e0 3f                                     	shl    ax,0x3f
 2a9:	66 c1 e0 40                                     	shl    ax,0x40
 2ad:	66 c1 e0 ff                                     	shl    ax,0xff
 2b1:	66 d3 e0                                        	shl    ax,cl
 2b4:	66 c1 e8 00                                     	shr    ax,0x0
 2b8:	66 d1 e8                                        	shr    ax,1
 2bb:	66 c1 e8 07                                     	shr    ax,0x7
 2bf:	66 c1 e8 08                                     	shr    ax,0x8
 2c3:	66 c1 e8 0f                                     	shr    ax,0xf
 2c7:	66 c1 e8 10                                     	shr    ax,0x10
 2cb:	66 c1 e8 1f                                     	shr    ax,0x1f
 2cf:	66 c1 e8 20                                     	shr    ax,0x20
 2d3:	66 c1 e8 3f                                     	shr    ax,0x3f
 2d7:	66 c1 e8 40                                     	shr    ax,0x40
 2db:	66 c1 e8 ff                                     	shr    ax,0xff
 2df:	66 d3 e8                                        	shr    ax,cl
 2e2:	66 c1 f8 00                                     	sar    ax,0x0
 2e6:	66 d1 f8                                        	sar    ax,1
 2e9:	66 c1 f8 07                                     	sar    ax,0x7
 2ed:	66 c1 f8 08                                     	sar    ax,0x8
 2f1:	66 c1 f8 0f                                     	sar    ax,0xf
 2f5:	66 c1 f8 10                                     	sar    ax,0x10
 2f9:	66 c1 f8 1f                                     	sar    ax,0x1f
 2fd:	66 c1 f8 20                                     	sar    ax,0x20
 301:	66 c1 f8 3f                                     	sar    ax,0x3f
 305:	66 c1 f8 40                                     	sar    ax,0x40
 309:	66 c1 f8 ff                                     	sar    ax,0xff
 30d:	66 d3 f8                                        	sar    ax,cl
 310:	66 c1 c0 00                                     	rol    ax,0x0
 314:	66 d1 c0                                        	rol    ax,1
 317:	66 c1 c0 07                                     	rol    ax,0x7
 31b:	66 c1 c0 08                                     	rol    ax,0x8
 31f:	66 c1 c0 0f                                     	rol    ax,0xf
 323:	66 c1 c0 10                                     	rol    ax,0x10
 327:	66 c1 c0 1f                                     	rol    ax,0x1f
 32b:	66 c1 c0 20                                     	rol    ax,0x20
 32f:	66 c1 c0 3f                                     	rol    ax,0x3f
 333:	66 c1 c0 40                                     	rol    ax,0x40
 337:	66 c1 c0 ff                                     	rol    ax,0xff
 33b:	66 d3 c0                                        	rol    ax,cl
 33e:	66 0f af c3                                     	imul   ax,bx
 342:	66 0f af 47 08                                  	imul   ax,WORD PTR [rdi+0x8]
 347:	66 6b c3 f9                                     	imul   ax,bx,0xfff9
 34b:	66 6b 47 08 f9                                  	imul   ax,WORD PTR [rdi+0x8],0xfff9
 350:	66 f3 0f b8 c3                                  	popcnt ax,bx
 355:	66 f7 f3                                        	div    bx
 358:	66 0f a3 d8                                     	bt     ax,bx
 35c:	66 0f ba e0 07                                  	bt     ax,0x7
 361:	66 0f ba 67 08 07                               	bt     WORD PTR [rdi+0x8],0x7
 367:	66 0f 38 f0 47 08                               	movbe  ax,WORD PTR [rdi+0x8]
 36d:	66 0f 38 f1 47 08                               	movbe  WORD PTR [rdi+0x8],ax
 373:	66 0f a4 d8 00                                  	shld   ax,bx,0x0
 378:	66 0f a4 d8 01                                  	shld   ax,bx,0x1
 37d:	66 0f a4 d8 07                                  	shld   ax,bx,0x7
 382:	66 0f a4 d8 0f                                  	shld   ax,bx,0xf
 387:	66 0f ac d8 00                                  	shrd   ax,bx,0x0
 38c:	66 0f ac d8 01                                  	shrd   ax,bx,0x1
 391:	66 0f ac d8 07                                  	shrd   ax,bx,0x7
 396:	66 0f ac d8 0f                                  	shrd   ax,bx,0xf
 39b:	89 d8                                           	mov    eax,ebx
 39d:	b8 7f 00 00 00                                  	mov    eax,0x7f
 3a2:	89 47 08                                        	mov    DWORD PTR [rdi+0x8],eax
 3a5:	8b 47 08                                        	mov    eax,DWORD PTR [rdi+0x8]
 3a8:	c7 47 08 7f 00 00 00                            	mov    DWORD PTR [rdi+0x8],0x7f
 3af:	01 d8                                           	add    eax,ebx
 3b1:	83 c0 7f                                        	add    eax,0x7f
 3b4:	01 47 08                                        	add    DWORD PTR [rdi+0x8],eax
 3b7:	83 47 08 7f                                     	add    DWORD PTR [rdi+0x8],0x7f
 3bb:	03 47 08                                        	add    eax,DWORD PTR [rdi+0x8]
 3be:	11 d8                                           	adc    eax,ebx
 3c0:	83 d0 7f                                        	adc    eax,0x7f
 3c3:	11 47 08                                        	adc    DWORD PTR [rdi+0x8],eax
 3c6:	83 57 08 7f                                     	adc    DWORD PTR [rdi+0x8],0x7f
 3ca:	13 47 08                                        	adc    eax,DWORD PTR [rdi+0x8]
 3cd:	29 d8                                           	sub    eax,ebx
 3cf:	83 e8 7f                                        	sub    eax,0x7f
 3d2:	29 47 08                                        	sub    DWORD PTR [rdi+0x8],eax
 3d5:	83 6f 08 7f                                     	sub    DWORD PTR [rdi+0x8],0x7f
 3d9:	2b 47 08                                        	sub    eax,DWORD PTR [rdi+0x8]
 3dc:	19 d8                                           	sbb    eax,ebx
 3de:	83 d8 7f                                        	sbb    eax,0x7f
 3e1:	19 47 08                                        	sbb    DWORD PTR [rdi+0x8],eax
 3e4:	83 5f 08 7f                                     	sbb    DWORD PTR [rdi+0x8],0x7f
 3e8:	1b 47 08                                        	sbb    eax,DWORD PTR [rdi+0x8]
 3eb:	39 d8                                           	cmp    eax,ebx
 3ed:	83 f8 7f                                        	cmp    eax,0x7f
 3f0:	39 47 08                                        	cmp    DWORD PTR [rdi+0x8],eax
 3f3:	83 7f 08 7f                                     	cmp    DWORD PTR [rdi+0x8],0x7f
 3f7:	3b 47 08                                        	cmp    eax,DWORD PTR [rdi+0x8]
 3fa:	85 d8                                           	test   eax,ebx
 3fc:	a9 7f 00 00 00                                  	test   eax,0x7f
 401:	85 47 08                                        	test   DWORD PTR [rdi+0x8],eax
 404:	f7 47 08 7f 00 00 00                            	test   DWORD PTR [rdi+0x8],0x7f
 40b:	21 d8                                           	and    eax,ebx
 40d:	83 e0 7f                                        	and    eax,0x7f
 410:	23 47 08                                        	and    eax,DWORD PTR [rdi+0x8]
 413:	21 47 08                                        	and    DWORD PTR [rdi+0x8],eax
 416:	83 67 08 7f                                     	and    DWORD PTR [rdi+0x8],0x7f
 41a:	09 d8                                           	or     eax,ebx
 41c:	83 c8 7f                                        	or     eax,0x7f
 41f:	0b 47 08                                        	or     eax,DWORD PTR [rdi+0x8]
 422:	09 47 08                                        	or     DWORD PTR [rdi+0x8],eax
 425:	83 4f 08 7f                                     	or     DWORD PTR [rdi+0x8],0x7f
 429:	31 d8                                           	xor    eax,ebx
 42b:	83 f0 7f                                        	xor    eax,0x7f
 42e:	33 47 08                                        	xor    eax,DWORD PTR [rdi+0x8]
 431:	31 47 08                                        	xor    DWORD PTR [rdi+0x8],eax
 434:	83 77 08 7f                                     	xor    DWORD PTR [rdi+0x8],0x7f
 438:	ff c0                                           	inc    eax
 43a:	ff 47 08                                        	inc    DWORD PTR [rdi+0x8]
 43d:	ff c8                                           	dec    eax
 43f:	ff 4f 08                                        	dec    DWORD PTR [rdi+0x8]
 442:	f7 d8                                           	neg    eax
 444:	f7 5f 08                                        	neg    DWORD PTR [rdi+0x8]
 447:	f7 d0                                           	not    eax
 449:	f7 57 08                                        	not    DWORD PTR [rdi+0x8]
 44c:	93                                              	xchg   ebx,eax
 44d:	c1 e0 00                                        	shl    eax,0x0
 450:	d1 e0                                           	shl    eax,1
 452:	c1 e0 07                                        	shl    eax,0x7
 455:	c1 e0 08                                        	shl    eax,0x8
 458:	c1 e0 0f                                        	shl    eax,0xf
 45b:	c1 e0 10                                        	shl    eax,0x10
 45e:	c1 e0 1f                                        	shl    eax,0x1f
 461:	c1 e0 20                                        	shl    eax,0x20
 464:	c1 e0 3f                                        	shl    eax,0x3f
 467:	c1 e0 40                                        	shl    eax,0x40
 46a:	c1 e0 ff                                        	shl    eax,0xff
 46d:	d3 e0                                           	shl    eax,cl
 46f:	c1 e8 00                                        	shr    eax,0x0
 472:	d1 e8                                           	shr    eax,1
 474:	c1 e8 07                                        	shr    eax,0x7
 477:	c1 e8 08                                        	shr    eax,0x8
 47a:	c1 e8 0f                                        	shr    eax,0xf
 47d:	c1 e8 10                                        	shr    eax,0x10
 480:	c1 e8 1f                                        	shr    eax,0x1f
 483:	c1 e8 20                                        	shr    eax,0x20
 486:	c1 e8 3f                                        	shr    eax,0x3f
 489:	c1 e8 40                                        	shr    eax,0x40
 48c:	c1 e8 ff                                        	shr    eax,0xff
 48f:	d3 e8                                           	shr    eax,cl
 491:	c1 f8 00                                        	sar    eax,0x0
 494:	d1 f8                                           	sar    eax,1
 496:	c1 f8 07                                        	sar    eax,0x7
 499:	c1 f8 08                                        	sar    eax,0x8
 49c:	c1 f8 0f                                        	sar    eax,0xf
 49f:	c1 f8 10                                        	sar    eax,0x10
 4a2:	c1 f8 1f                                        	sar    eax,0x1f
 4a5:	c1 f8 20                                        	sar    eax,0x20
 4a8:	c1 f8 3f                                        	sar    eax,0x3f
 4ab:	c1 f8 40                                        	sar    eax,0x40
 4ae:	c1 f8 ff                                        	sar    eax,0xff
 4b1:	d3 f8                                           	sar    eax,cl
 4b3:	c1 c0 00                                        	rol    eax,0x0
 4b6:	d1 c0                                           	rol    eax,1
 4b8:	c1 c0 07                                        	rol    eax,0x7
 4bb:	c1 c0 08                                        	rol    eax,0x8
 4be:	c1 c0 0f                                        	rol    eax,0xf
 4c1:	c1 c0 10                                        	rol    eax,0x10
 4c4:	c1 c0 1f                                        	rol    eax,0x1f
 4c7:	c1 c0 20                                        	rol    eax,0x20
 4ca:	c1 c0 3f                                        	rol    eax,0x3f
 4cd:	c1 c0 40                                        	rol    eax,0x40
 4d0:	c1 c0 ff                                        	rol    eax,0xff
 4d3:	d3 c0                                           	rol    eax,cl
 4d5:	0f af c3                                        	imul   eax,ebx
 4d8:	0f af 47 08                                     	imul   eax,DWORD PTR [rdi+0x8]
 4dc:	6b c3 f9                                        	imul   eax,ebx,0xfffffff9
 4df:	6b 47 08 f9                                     	imul   eax,DWORD PTR [rdi+0x8],0xfffffff9
 4e3:	f3 0f b8 c3                                     	popcnt eax,ebx
 4e7:	f7 f3                                           	div    ebx
 4e9:	0f a3 d8                                        	bt     eax,ebx
 4ec:	0f ba e0 07                                     	bt     eax,0x7
 4f0:	0f ba 67 08 07                                  	bt     DWORD PTR [rdi+0x8],0x7
 4f5:	0f 38 f0 47 08                                  	movbe  eax,DWORD PTR [rdi+0x8]
 4fa:	0f 38 f1 47 08                                  	movbe  DWORD PTR [rdi+0x8],eax
 4ff:	0f a4 d8 00                                     	shld   eax,ebx,0x0
 503:	0f a4 d8 01                                     	shld   eax,ebx,0x1
 507:	0f a4 d8 07                                     	shld   eax,ebx,0x7
 50b:	0f a4 d8 0f                                     	shld   eax,ebx,0xf
 50f:	0f ac d8 00                                     	shrd   eax,ebx,0x0
 513:	0f ac d8 01                                     	shrd   eax,ebx,0x1
 517:	0f ac d8 07                                     	shrd   eax,ebx,0x7
 51b:	0f ac d8 0f                                     	shrd   eax,ebx,0xf
 51f:	8d 44 9f f9                                     	lea    eax,[rdi+rbx*4-0x7]
 523:	0f c8                                           	bswap  eax
 525:	c4 e2 60 f2 c1                                  	andn   eax,ebx,ecx
 52a:	c4 e2 60 f2 47 08                               	andn   eax,ebx,DWORD PTR [rdi+0x8]
 530:	c4 e2 70 f5 c3                                  	bzhi   eax,ebx,ecx
 535:	c4 e2 70 f5 47 08                               	bzhi   eax,DWORD PTR [rdi+0x8],ecx
 53b:	c4 e2 63 f6 c1                                  	mulx   eax,ebx,ecx
 540:	c4 e2 71 f7 c3                                  	shlx   eax,ebx,ecx
 545:	c4 e2 71 f7 47 08                               	shlx   eax,DWORD PTR [rdi+0x8],ecx
 54b:	c4 e2 73 f7 c3                                  	shrx   eax,ebx,ecx
 550:	c4 e2 73 f7 47 08                               	shrx   eax,DWORD PTR [rdi+0x8],ecx
 556:	c4 e2 72 f7 c3                                  	sarx   eax,ebx,ecx
 55b:	c4 e2 72 f7 47 08                               	sarx   eax,DWORD PTR [rdi+0x8],ecx
 561:	c4 e3 7b f0 c3 07                               	rorx   eax,ebx,0x7
 567:	c4 e3 7b f0 47 08 07                            	rorx   eax,DWORD PTR [rdi+0x8],0x7
 56e:	48 89 d8                                        	mov    rax,rbx
 571:	48 c7 c0 7f 00 00 00                            	mov    rax,0x7f
 578:	48 89 47 08                                     	mov    QWORD PTR [rdi+0x8],rax
 57c:	48 8b 47 08                                     	mov    rax,QWORD PTR [rdi+0x8]
 580:	48 c7 47 08 7f 00 00 00                         	mov    QWORD PTR [rdi+0x8],0x7f
 588:	48 01 d8                                        	add    rax,rbx
 58b:	48 83 c0 7f                                     	add    rax,0x7f
 58f:	48 01 47 08                                     	add    QWORD PTR [rdi+0x8],rax
 593:	48 83 47 08 7f                                  	add    QWORD PTR [rdi+0x8],0x7f
 598:	48 03 47 08                                     	add    rax,QWORD PTR [rdi+0x8]
 59c:	48 11 d8                                        	adc    rax,rbx
 59f:	48 83 d0 7f                                     	adc    rax,0x7f
 5a3:	48 11 47 08                                     	adc    QWORD PTR [rdi+0x8],rax
 5a7:	48 83 57 08 7f                                  	adc    QWORD PTR [rdi+0x8],0x7f
 5ac:	48 13 47 08                                     	adc    rax,QWORD PTR [rdi+0x8]
 5b0:	48 29 d8                                        	sub    rax,rbx
 5b3:	48 83 e8 7f                                     	sub    rax,0x7f
 5b7:	48 29 47 08                                     	sub    QWORD PTR [rdi+0x8],rax
 5bb:	48 83 6f 08 7f                                  	sub    QWORD PTR [rdi+0x8],0x7f
 5c0:	48 2b 47 08                                     	sub    rax,QWORD PTR [rdi+0x8]
 5c4:	48 19 d8                                        	sbb    rax,rbx
 5c7:	48 83 d8 7f                                     	sbb    rax,0x7f
 5cb:	48 19 47 08                                     	sbb    QWORD PTR [rdi+0x8],rax
 5cf:	48 83 5f 08 7f                                  	sbb    QWORD PTR [rdi+0x8],0x7f
 5d4:	48 1b 47 08                                     	sbb    rax,QWORD PTR [rdi+0x8]
 5d8:	48 39 d8                                        	cmp    rax,rbx
 5db:	48 83 f8 7f                                     	cmp    rax,0x7f
 5df:	48 39 47 08                                     	cmp    QWORD PTR [rdi+0x8],rax
 5e3:	48 83 7f 08 7f                                  	cmp    QWORD PTR [rdi+0x8],0x7f
 5e8:	48 3b 47 08                                     	cmp    rax,QWORD PTR [rdi+0x8]
 5ec:	48 85 d8                                        	test   rax,rbx
 5ef:	48 a9 7f 00 00 00                               	test   rax,0x7f
 5f5:	48 85 47 08                                     	test   QWORD PTR [rdi+0x8],rax
 5f9:	48 f7 47 08 7f 00 00 00                         	test   QWORD PTR [rdi+0x8],0x7f
 601:	48 21 d8                                        	and    rax,rbx
 604:	48 83 e0 7f                                     	and    rax,0x7f
 608:	48 23 47 08                                     	and    rax,QWORD PTR [rdi+0x8]
 60c:	48 21 47 08                                     	and    QWORD PTR [rdi+0x8],rax
 610:	48 83 67 08 7f                                  	and    QWORD PTR [rdi+0x8],0x7f
 615:	48 09 d8                                        	or     rax,rbx
 618:	48 83 c8 7f                                     	or     rax,0x7f
 61c:	48 0b 47 08                                     	or     rax,QWORD PTR [rdi+0x8]
 620:	48 09 47 08                                     	or     QWORD PTR [rdi+0x8],rax
 624:	48 83 4f 08 7f                                  	or     QWORD PTR [rdi+0x8],0x7f
 629:	48 31 d8                                        	xor    rax,rbx
 62c:	48 83 f0 7f                                     	xor    rax,0x7f
 630:	48 33 47 08                                     	xor    rax,QWORD PTR [rdi+0x8]
 634:	48 31 47 08                                     	xor    QWORD PTR [rdi+0x8],rax
 638:	48 83 77 08 7f                                  	xor    QWORD PTR [rdi+0x8],0x7f
 63d:	48 ff c0                                        	inc    rax
 640:	48 ff 47 08                                     	inc    QWORD PTR [rdi+0x8]
 644:	48 ff c8                                        	dec    rax
 647:	48 ff 4f 08                                     	dec    QWORD PTR [rdi+0x8]
 64b:	48 f7 d8                                        	neg    rax
 64e:	48 f7 5f 08                                     	neg    QWORD PTR [rdi+0x8]
 652:	48 f7 d0                                        	not    rax
 655:	48 f7 57 08                                     	not    QWORD PTR [rdi+0x8]
 659:	48 93                                           	xchg   rbx,rax
 65b:	48 c1 e0 00                                     	shl    rax,0x0
 65f:	48 d1 e0                                        	shl    rax,1
 662:	48 c1 e0 07                                     	shl    rax,0x7
 666:	48 c1 e0 08                                     	shl    rax,0x8
 66a:	48 c1 e0 0f                                     	shl    rax,0xf
 66e:	48 c1 e0 10                                     	shl    rax,0x10
 672:	48 c1 e0 1f                                     	shl    rax,0x1f
 676:	48 c1 e0 20                                     	shl    rax,0x20
 67a:	48 c1 e0 3f                                     	shl    rax,0x3f
 67e:	48 c1 e0 40                                     	shl    rax,0x40
 682:	48 c1 e0 ff                                     	shl    rax,0xff
 686:	48 d3 e0                                        	shl    rax,cl
 689:	48 c1 e8 00                                     	shr    rax,0x0
 68d:	48 d1 e8                                        	shr    rax,1
 690:	48 c1 e8 07                                     	shr    rax,0x7
 694:	48 c1 e8 08                                     	shr    rax,0x8
 698:	48 c1 e8 0f                                     	shr    rax,0xf
 69c:	48 c1 e8 10                                     	shr    rax,0x10
 6a0:	48 c1 e8 1f                                     	shr    rax,0x1f
 6a4:	48 c1 e8 20                                     	shr    rax,0x20
 6a8:	48 c1 e8 3f                                     	shr    rax,0x3f
 6ac:	48 c1 e8 40                                     	shr    rax,0x40
 6b0:	48 c1 e8 ff                                     	shr    rax,0xff
 6b4:	48 d3 e8                                        	shr    rax,cl
 6b7:	48 c1 f8 00                                     	sar    rax,0x0
 6bb:	48 d1 f8                                        	sar    rax,1
 6be:	48 c1 f8 07                                     	sar    rax,0x7
 6c2:	48 c1 f8 08                                     	sar    rax,0x8
 6c6:	48 c1 f8 0f                                     	sar    rax,0xf
 6ca:	48 c1 f8 10                                     	sar    rax,0x10
 6ce:	48 c1 f8 1f                                     	sar    rax,0x1f
 6d2:	48 c1 f8 20                                     	sar    rax,0x20
 6d6:	48 c1 f8 3f                                     	sar    rax,0x3f
 6da:	48 c1 f8 40                                     	sar    rax,0x40
 6de:	48 c1 f8 ff                                     	sar    rax,0xff
 6e2:	48 d3 f8                                        	sar    rax,cl
 6e5:	48 c1 c0 00                                     	rol    rax,0x0
 6e9:	48 d1 c0                                        	rol    rax,1
 6ec:	48 c1 c0 07                                     	rol    rax,0x7
 6f0:	48 c1 c0 08                                     	rol    rax,0x8
 6f4:	48 c1 c0 0f                                     	rol    rax,0xf
 6f8:	48 c1 c0 10                                     	rol    rax,0x10
 6fc:	48 c1 c0 1f                                     	rol    rax,0x1f
 700:	48 c1 c0 20                                     	rol    rax,0x20
 704:	48 c1 c0 3f                                     	rol    rax,0x3f
 708:	48 c1 c0 40                                     	rol    rax,0x40
 70c:	48 c1 c0 ff                                     	rol    rax,0xff
 710:	48 d3 c0                                        	rol    rax,cl
 713:	48 0f af c3                                     	imul   rax,rbx
 717:	48 0f af 47 08                                  	imul   rax,QWORD PTR [rdi+0x8]
 71c:	48 6b c3 f9                                     	imul   rax,rbx,0xfffffffffffffff9
 720:	48 6b 47 08 f9                                  	imul   rax,QWORD PTR [rdi+0x8],0xfffffffffffffff9
 725:	f3 48 0f b8 c3                                  	popcnt rax,rbx
 72a:	48 f7 f3                                        	div    rbx
 72d:	48 0f a3 d8                                     	bt     rax,rbx
 731:	48 0f ba e0 07                                  	bt     rax,0x7
 736:	48 0f ba 67 08 07                               	bt     QWORD PTR [rdi+0x8],0x7
 73c:	48 0f 38 f0 47 08                               	movbe  rax,QWORD PTR [rdi+0x8]
 742:	48 0f 38 f1 47 08                               	movbe  QWORD PTR [rdi+0x8],rax
 748:	48 0f a4 d8 00                                  	shld   rax,rbx,0x0
 74d:	48 0f a4 d8 01                                  	shld   rax,rbx,0x1
 752:	48 0f a4 d8 07                                  	shld   rax,rbx,0x7
 757:	48 0f a4 d8 0f                                  	shld   rax,rbx,0xf
 75c:	48 0f ac d8 00                                  	shrd   rax,rbx,0x0
 761:	48 0f ac d8 01                                  	shrd   rax,rbx,0x1
 766:	48 0f ac d8 07                                  	shrd   rax,rbx,0x7
 76b:	48 0f ac d8 0f                                  	shrd   rax,rbx,0xf
 770:	48 8d 44 9f f9                                  	lea    rax,[rdi+rbx*4-0x7]
 775:	48 0f c8                                        	bswap  rax
 778:	c4 e2 e0 f2 c1                                  	andn   rax,rbx,rcx
 77d:	c4 e2 e0 f2 47 08                               	andn   rax,rbx,QWORD PTR [rdi+0x8]
 783:	c4 e2 f0 f5 c3                                  	bzhi   rax,rbx,rcx
 788:	c4 e2 f0 f5 47 08                               	bzhi   rax,QWORD PTR [rdi+0x8],rcx
 78e:	c4 e2 e3 f6 c1                                  	mulx   rax,rbx,rcx
 793:	c4 e2 f1 f7 c3                                  	shlx   rax,rbx,rcx
 798:	c4 e2 f1 f7 47 08                               	shlx   rax,QWORD PTR [rdi+0x8],rcx
 79e:	c4 e2 f3 f7 c3                                  	shrx   rax,rbx,rcx
 7a3:	c4 e2 f3 f7 47 08                               	shrx   rax,QWORD PTR [rdi+0x8],rcx
 7a9:	c4 e2 f2 f7 c3                                  	sarx   rax,rbx,rcx
 7ae:	c4 e2 f2 f7 47 08                               	sarx   rax,QWORD PTR [rdi+0x8],rcx
 7b4:	c4 e3 fb f0 c3 07                               	rorx   rax,rbx,0x7
 7ba:	c4 e3 fb f0 47 08 07                            	rorx   rax,QWORD PTR [rdi+0x8],0x7
 7c1:	88 fc                                           	mov    ah,bh
 7c3:	b4 7f                                           	mov    ah,0x7f
 7c5:	88 67 08                                        	mov    BYTE PTR [rdi+0x8],ah
 7c8:	00 fc                                           	add    ah,bh
 7ca:	80 c4 7f                                        	add    ah,0x7f
 7cd:	10 fc                                           	adc    ah,bh
 7cf:	80 d4 7f                                        	adc    ah,0x7f
 7d2:	28 fc                                           	sub    ah,bh
 7d4:	80 ec 7f                                        	sub    ah,0x7f
 7d7:	18 fc                                           	sbb    ah,bh
 7d9:	80 dc 7f                                        	sbb    ah,0x7f
 7dc:	38 fc                                           	cmp    ah,bh
 7de:	80 fc 7f                                        	cmp    ah,0x7f
 7e1:	84 fc                                           	test   ah,bh
 7e3:	f6 c4 7f                                        	test   ah,0x7f
 7e6:	fe c4                                           	inc    ah
 7e8:	fe cc                                           	dec    ah
 7ea:	f6 dc                                           	neg    ah
 7ec:	f6 d4                                           	not    ah
 7ee:	66 0f b6 c3                                     	movzx  ax,bl
 7f2:	66 0f b6 47 08                                  	movzx  ax,BYTE PTR [rdi+0x8]
 7f7:	66 0f be c3                                     	movsx  ax,bl
 7fb:	66 0f be 47 08                                  	movsx  ax,BYTE PTR [rdi+0x8]
 800:	0f b6 c3                                        	movzx  eax,bl
 803:	0f b6 47 08                                     	movzx  eax,BYTE PTR [rdi+0x8]
 807:	0f be c3                                        	movsx  eax,bl
 80a:	0f be 47 08                                     	movsx  eax,BYTE PTR [rdi+0x8]
 80e:	0f b7 c3                                        	movzx  eax,bx
 811:	0f b7 47 08                                     	movzx  eax,WORD PTR [rdi+0x8]
 815:	0f bf c3                                        	movsx  eax,bx
 818:	0f bf 47 08                                     	movsx  eax,WORD PTR [rdi+0x8]
 81c:	48 0f b6 c3                                     	movzx  rax,bl
 820:	48 0f b6 47 08                                  	movzx  rax,BYTE PTR [rdi+0x8]
 825:	48 0f be c3                                     	movsx  rax,bl
 829:	48 0f be 47 08                                  	movsx  rax,BYTE PTR [rdi+0x8]
 82e:	48 0f b7 c3                                     	movzx  rax,bx
 832:	48 0f b7 47 08                                  	movzx  rax,WORD PTR [rdi+0x8]
 837:	48 0f bf c3                                     	movsx  rax,bx
 83b:	48 0f bf 47 08                                  	movsx  rax,WORD PTR [rdi+0x8]
 840:	48 63 c3                                        	movsxd rax,ebx
 843:	48 63 47 08                                     	movsxd rax,DWORD PTR [rdi+0x8]
 847:	0f 92 c0                                        	setb   al
 84a:	0f 92 c4                                        	setb   ah
 84d:	0f 92 47 08                                     	setb   BYTE PTR [rdi+0x8]
 851:	66 0f 42 c3                                     	cmovb  ax,bx
 855:	66 0f 42 47 08                                  	cmovb  ax,WORD PTR [rdi+0x8]
 85a:	0f 42 c3                                        	cmovb  eax,ebx
 85d:	0f 42 47 08                                     	cmovb  eax,DWORD PTR [rdi+0x8]
 861:	48 0f 42 c3                                     	cmovb  rax,rbx
 865:	48 0f 42 47 08                                  	cmovb  rax,QWORD PTR [rdi+0x8]
 86a:	0f 93 c0                                        	setae  al
 86d:	0f 93 c4                                        	setae  ah
 870:	0f 93 47 08                                     	setae  BYTE PTR [rdi+0x8]
 874:	66 0f 43 c3                                     	cmovae ax,bx
 878:	66 0f 43 47 08                                  	cmovae ax,WORD PTR [rdi+0x8]
 87d:	0f 43 c3                                        	cmovae eax,ebx
 880:	0f 43 47 08                                     	cmovae eax,DWORD PTR [rdi+0x8]
 884:	48 0f 43 c3                                     	cmovae rax,rbx
 888:	48 0f 43 47 08                                  	cmovae rax,QWORD PTR [rdi+0x8]
 88d:	0f 94 c0                                        	sete   al
 890:	0f 94 c4                                        	sete   ah
 893:	0f 94 47 08                                     	sete   BYTE PTR [rdi+0x8]
 897:	66 0f 44 c3                                     	cmove  ax,bx
 89b:	66 0f 44 47 08                                  	cmove  ax,WORD PTR [rdi+0x8]
 8a0:	0f 44 c3                                        	cmove  eax,ebx
 8a3:	0f 44 47 08                                     	cmove  eax,DWORD PTR [rdi+0x8]
 8a7:	48 0f 44 c3                                     	cmove  rax,rbx
 8ab:	48 0f 44 47 08                                  	cmove  rax,QWORD PTR [rdi+0x8]
 8b0:	0f 95 c0                                        	setne  al
 8b3:	0f 95 c4                                        	setne  ah
 8b6:	0f 95 47 08                                     	setne  BYTE PTR [rdi+0x8]
 8ba:	66 0f 45 c3                                     	cmovne ax,bx
 8be:	66 0f 45 47 08                                  	cmovne ax,WORD PTR [rdi+0x8]
 8c3:	0f 45 c3                                        	cmovne eax,ebx
 8c6:	0f 45 47 08                                     	cmovne eax,DWORD PTR [rdi+0x8]
 8ca:	48 0f 45 c3                                     	cmovne rax,rbx
 8ce:	48 0f 45 47 08                                  	cmovne rax,QWORD PTR [rdi+0x8]
 8d3:	0f 96 c0                                        	setbe  al
 8d6:	0f 96 c4                                        	setbe  ah
 8d9:	0f 96 47 08                                     	setbe  BYTE PTR [rdi+0x8]
 8dd:	66 0f 46 c3                                     	cmovbe ax,bx
 8e1:	66 0f 46 47 08                                  	cmovbe ax,WORD PTR [rdi+0x8]
 8e6:	0f 46 c3                                        	cmovbe eax,ebx
 8e9:	0f 46 47 08                                     	cmovbe eax,DWORD PTR [rdi+0x8]
 8ed:	48 0f 46 c3                                     	cmovbe rax,rbx
 8f1:	48 0f 46 47 08                                  	cmovbe rax,QWORD PTR [rdi+0x8]
 8f6:	0f 97 c0                                        	seta   al
 8f9:	0f 97 c4                                        	seta   ah
 8fc:	0f 97 47 08                                     	seta   BYTE PTR [rdi+0x8]
 900:	66 0f 47 c3                                     	cmova  ax,bx
 904:	66 0f 47 47 08                                  	cmova  ax,WORD PTR [rdi+0x8]
 909:	0f 47 c3                                        	cmova  eax,ebx
 90c:	0f 47 47 08                                     	cmova  eax,DWORD PTR [rdi+0x8]
 910:	48 0f 47 c3                                     	cmova  rax,rbx
 914:	48 0f 47 47 08                                  	cmova  rax,QWORD PTR [rdi+0x8]
 919:	0f 98 c0                                        	sets   al
 91c:	0f 98 c4                                        	sets   ah
 91f:	0f 98 47 08                                     	sets   BYTE PTR [rdi+0x8]
 923:	66 0f 48 c3                                     	cmovs  ax,bx
 927:	66 0f 48 47 08                                  	cmovs  ax,WORD PTR [rdi+0x8]
 92c:	0f 48 c3                                        	cmovs  eax,ebx
 92f:	0f 48 47 08                                     	cmovs  eax,DWORD PTR [rdi+0x8]
 933:	48 0f 48 c3                                     	cmovs  rax,rbx
 937:	48 0f 48 47 08                                  	cmovs  rax,QWORD PTR [rdi+0x8]
 93c:	0f 99 c0                                        	setns  al
 93f:	0f 99 c4                                        	setns  ah
 942:	0f 99 47 08                                     	setns  BYTE PTR [rdi+0x8]
 946:	66 0f 49 c3                                     	cmovns ax,bx
 94a:	66 0f 49 47 08                                  	cmovns ax,WORD PTR [rdi+0x8]
 94f:	0f 49 c3                                        	cmovns eax,ebx
 952:	0f 49 47 08                                     	cmovns eax,DWORD PTR [rdi+0x8]
 956:	48 0f 49 c3                                     	cmovns rax,rbx
 95a:	48 0f 49 47 08                                  	cmovns rax,QWORD PTR [rdi+0x8]
 95f:	0f 9c c0                                        	setl   al
 962:	0f 9c c4                                        	setl   ah
 965:	0f 9c 47 08                                     	setl   BYTE PTR [rdi+0x8]
 969:	66 0f 4c c3                                     	cmovl  ax,bx
 96d:	66 0f 4c 47 08                                  	cmovl  ax,WORD PTR [rdi+0x8]
 972:	0f 4c c3                                        	cmovl  eax,ebx
 975:	0f 4c 47 08                                     	cmovl  eax,DWORD PTR [rdi+0x8]
 979:	48 0f 4c c3                                     	cmovl  rax,rbx
 97d:	48 0f 4c 47 08                                  	cmovl  rax,QWORD PTR [rdi+0x8]
 982:	0f 9d c0                                        	setge  al
 985:	0f 9d c4                                        	setge  ah
 988:	0f 9d 47 08                                     	setge  BYTE PTR [rdi+0x8]
 98c:	66 0f 4d c3                                     	cmovge ax,bx
 990:	66 0f 4d 47 08                                  	cmovge ax,WORD PTR [rdi+0x8]
 995:	0f 4d c3                                        	cmovge eax,ebx
 998:	0f 4d 47 08                                     	cmovge eax,DWORD PTR [rdi+0x8]
 99c:	48 0f 4d c3                                     	cmovge rax,rbx
 9a0:	48 0f 4d 47 08                                  	cmovge rax,QWORD PTR [rdi+0x8]
 9a5:	0f 9e c0                                        	setle  al
 9a8:	0f 9e c4                                        	setle  ah
 9ab:	0f 9e 47 08                                     	setle  BYTE PTR [rdi+0x8]
 9af:	66 0f 4e c3                                     	cmovle ax,bx
 9b3:	66 0f 4e 47 08                                  	cmovle ax,WORD PTR [rdi+0x8]
 9b8:	0f 4e c3                                        	cmovle eax,ebx
 9bb:	0f 4e 47 08                                     	cmovle eax,DWORD PTR [rdi+0x8]
 9bf:	48 0f 4e c3                                     	cmovle rax,rbx
 9c3:	48 0f 4e 47 08                                  	cmovle rax,QWORD PTR [rdi+0x8]
 9c8:	0f 9f c0                                        	setg   al
 9cb:	0f 9f c4                                        	setg   ah
 9ce:	0f 9f 47 08                                     	setg   BYTE PTR [rdi+0x8]
 9d2:	66 0f 4f c3                                     	cmovg  ax,bx
 9d6:	66 0f 4f 47 08                                  	cmovg  ax,WORD PTR [rdi+0x8]
 9db:	0f 4f c3                                        	cmovg  eax,ebx
 9de:	0f 4f 47 08                                     	cmovg  eax,DWORD PTR [rdi+0x8]
 9e2:	48 0f 4f c3                                     	cmovg  rax,rbx
 9e6:	48 0f 4f 47 08                                  	cmovg  rax,QWORD PTR [rdi+0x8]
