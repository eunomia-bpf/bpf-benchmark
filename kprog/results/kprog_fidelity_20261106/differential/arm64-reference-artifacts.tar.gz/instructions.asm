
build-arm64-reference/instructions.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <.text>:
   0:	d503201f 	nop
   4:	0b020020 	add	w0, w1, w2
   8:	0b020c20 	add	w0, w1, w2, lsl #3
   c:	1101fc20 	add	w0, w1, #0x7f
  10:	4b020020 	sub	w0, w1, w2
  14:	4b020c20 	sub	w0, w1, w2, lsl #3
  18:	5101fc20 	sub	w0, w1, #0x7f
  1c:	0a020020 	and	w0, w1, w2
  20:	0a020c20 	and	w0, w1, w2, lsl #3
  24:	0a220020 	bic	w0, w1, w2
  28:	0a220c20 	bic	w0, w1, w2, lsl #3
  2c:	4a020020 	eor	w0, w1, w2
  30:	4a020c20 	eor	w0, w1, w2, lsl #3
  34:	2a020020 	orr	w0, w1, w2
  38:	2a020c20 	orr	w0, w1, w2, lsl #3
  3c:	2a220020 	orn	w0, w1, w2
  40:	2a220c20 	orn	w0, w1, w2, lsl #3
  44:	2b020020 	adds	w0, w1, w2
  48:	2b020c20 	adds	w0, w1, w2, lsl #3
  4c:	3101fc20 	adds	w0, w1, #0x7f
  50:	6b020020 	subs	w0, w1, w2
  54:	6b020c20 	subs	w0, w1, w2, lsl #3
  58:	7101fc20 	subs	w0, w1, #0x7f
  5c:	6a020020 	ands	w0, w1, w2
  60:	6a020c20 	ands	w0, w1, w2, lsl #3
  64:	6a220020 	bics	w0, w1, w2
  68:	6a220c20 	bics	w0, w1, w2, lsl #3
  6c:	6b02003f 	cmp	w1, w2
  70:	6b020c3f 	cmp	w1, w2, lsl #3
  74:	2b02003f 	cmn	w1, w2
  78:	2b020c3f 	cmn	w1, w2, lsl #3
  7c:	6a02003f 	tst	w1, w2
  80:	6a020c3f 	tst	w1, w2, lsl #3
  84:	2a0103e0 	mov	w0, w1
  88:	52800fe0 	mov	w0, #0x7f                  	// #127
  8c:	72bbd5a0 	movk	w0, #0xdead, lsl #16
  90:	2a2103e0 	mvn	w0, w1
  94:	4b0103e0 	neg	w0, w1
  98:	5ac00820 	rev	w0, w1
  9c:	5ac00420 	rev16	w0, w1
  a0:	13001c20 	sxtb	w0, w1
  a4:	13003c20 	sxth	w0, w1
  a8:	1b027c20 	mul	w0, w1, w2
  ac:	1ac20820 	udiv	w0, w1, w2
  b0:	1b020c20 	madd	w0, w1, w2, w3
  b4:	1b028c20 	msub	w0, w1, w2, w3
  b8:	1ac22020 	lsl	w0, w1, w2
  bc:	53007c20 	lsr	w0, w1, #0
  c0:	531f7820 	lsl	w0, w1, #1
  c4:	53196020 	lsl	w0, w1, #7
  c8:	53010020 	lsl	w0, w1, #31
  cc:	1ac22420 	lsr	w0, w1, w2
  d0:	53007c20 	lsr	w0, w1, #0
  d4:	53017c20 	lsr	w0, w1, #1
  d8:	53077c20 	lsr	w0, w1, #7
  dc:	531f7c20 	lsr	w0, w1, #31
  e0:	1ac22820 	asr	w0, w1, w2
  e4:	13007c20 	asr	w0, w1, #0
  e8:	13017c20 	asr	w0, w1, #1
  ec:	13077c20 	asr	w0, w1, #7
  f0:	131f7c20 	asr	w0, w1, #31
  f4:	1ac22c20 	ror	w0, w1, w2
  f8:	13810020 	ror	w0, w1, #0
  fc:	13810420 	ror	w0, w1, #1
 100:	13811c20 	ror	w0, w1, #7
 104:	13817c20 	ror	w0, w1, #31
 108:	13821c20 	extr	w0, w1, w2, #7
 10c:	53074c20 	ubfx	w0, w1, #7, #13
 110:	13074c20 	sbfx	w0, w1, #7, #13
 114:	53193020 	ubfiz	w0, w1, #7, #13
 118:	33074c20 	bfxil	w0, w1, #7, #13
 11c:	33193020 	bfi	w0, w1, #7, #13
 120:	1a820020 	csel	w0, w1, w2, eq	// eq = none
 124:	1a820420 	csinc	w0, w1, w2, eq	// eq = none
 128:	5a820020 	csinv	w0, w1, w2, eq	// eq = none
 12c:	5a820420 	csneg	w0, w1, w2, eq	// eq = none
 130:	1a811420 	cinc	w0, w1, eq	// eq = none
 134:	5a811020 	cinv	w0, w1, eq	// eq = none
 138:	5a811420 	cneg	w0, w1, eq	// eq = none
 13c:	1a9f17e0 	cset	w0, eq	// eq = none
 140:	5a9f13e0 	csetm	w0, eq	// eq = none
 144:	7a420025 	ccmp	w1, w2, #0x5, eq	// eq = none
 148:	7a47082a 	ccmp	w1, #0x7, #0xa, eq	// eq = none
 14c:	1a821020 	csel	w0, w1, w2, ne	// ne = any
 150:	1a821420 	csinc	w0, w1, w2, ne	// ne = any
 154:	5a821020 	csinv	w0, w1, w2, ne	// ne = any
 158:	5a821420 	csneg	w0, w1, w2, ne	// ne = any
 15c:	1a810420 	cinc	w0, w1, ne	// ne = any
 160:	5a810020 	cinv	w0, w1, ne	// ne = any
 164:	5a810420 	cneg	w0, w1, ne	// ne = any
 168:	1a9f07e0 	cset	w0, ne	// ne = any
 16c:	5a9f03e0 	csetm	w0, ne	// ne = any
 170:	7a421025 	ccmp	w1, w2, #0x5, ne	// ne = any
 174:	7a47182a 	ccmp	w1, #0x7, #0xa, ne	// ne = any
 178:	1a822020 	csel	w0, w1, w2, cs	// cs = hs, nlast
 17c:	1a822420 	csinc	w0, w1, w2, cs	// cs = hs, nlast
 180:	5a822020 	csinv	w0, w1, w2, cs	// cs = hs, nlast
 184:	5a822420 	csneg	w0, w1, w2, cs	// cs = hs, nlast
 188:	1a813420 	cinc	w0, w1, cs	// cs = hs, nlast
 18c:	5a813020 	cinv	w0, w1, cs	// cs = hs, nlast
 190:	5a813420 	cneg	w0, w1, cs	// cs = hs, nlast
 194:	1a9f37e0 	cset	w0, cs	// cs = hs, nlast
 198:	5a9f33e0 	csetm	w0, cs	// cs = hs, nlast
 19c:	7a422025 	ccmp	w1, w2, #0x5, cs	// cs = hs, nlast
 1a0:	7a47282a 	ccmp	w1, #0x7, #0xa, cs	// cs = hs, nlast
 1a4:	1a823020 	csel	w0, w1, w2, cc	// cc = lo, ul, last
 1a8:	1a823420 	csinc	w0, w1, w2, cc	// cc = lo, ul, last
 1ac:	5a823020 	csinv	w0, w1, w2, cc	// cc = lo, ul, last
 1b0:	5a823420 	csneg	w0, w1, w2, cc	// cc = lo, ul, last
 1b4:	1a812420 	cinc	w0, w1, cc	// cc = lo, ul, last
 1b8:	5a812020 	cinv	w0, w1, cc	// cc = lo, ul, last
 1bc:	5a812420 	cneg	w0, w1, cc	// cc = lo, ul, last
 1c0:	1a9f27e0 	cset	w0, cc	// cc = lo, ul, last
 1c4:	5a9f23e0 	csetm	w0, cc	// cc = lo, ul, last
 1c8:	7a423025 	ccmp	w1, w2, #0x5, cc	// cc = lo, ul, last
 1cc:	7a47382a 	ccmp	w1, #0x7, #0xa, cc	// cc = lo, ul, last
 1d0:	1a824020 	csel	w0, w1, w2, mi	// mi = first
 1d4:	1a824420 	csinc	w0, w1, w2, mi	// mi = first
 1d8:	5a824020 	csinv	w0, w1, w2, mi	// mi = first
 1dc:	5a824420 	csneg	w0, w1, w2, mi	// mi = first
 1e0:	1a815420 	cinc	w0, w1, mi	// mi = first
 1e4:	5a815020 	cinv	w0, w1, mi	// mi = first
 1e8:	5a815420 	cneg	w0, w1, mi	// mi = first
 1ec:	1a9f57e0 	cset	w0, mi	// mi = first
 1f0:	5a9f53e0 	csetm	w0, mi	// mi = first
 1f4:	7a424025 	ccmp	w1, w2, #0x5, mi	// mi = first
 1f8:	7a47482a 	ccmp	w1, #0x7, #0xa, mi	// mi = first
 1fc:	1a825020 	csel	w0, w1, w2, pl	// pl = nfrst
 200:	1a825420 	csinc	w0, w1, w2, pl	// pl = nfrst
 204:	5a825020 	csinv	w0, w1, w2, pl	// pl = nfrst
 208:	5a825420 	csneg	w0, w1, w2, pl	// pl = nfrst
 20c:	1a814420 	cinc	w0, w1, pl	// pl = nfrst
 210:	5a814020 	cinv	w0, w1, pl	// pl = nfrst
 214:	5a814420 	cneg	w0, w1, pl	// pl = nfrst
 218:	1a9f47e0 	cset	w0, pl	// pl = nfrst
 21c:	5a9f43e0 	csetm	w0, pl	// pl = nfrst
 220:	7a425025 	ccmp	w1, w2, #0x5, pl	// pl = nfrst
 224:	7a47582a 	ccmp	w1, #0x7, #0xa, pl	// pl = nfrst
 228:	1a826020 	csel	w0, w1, w2, vs
 22c:	1a826420 	csinc	w0, w1, w2, vs
 230:	5a826020 	csinv	w0, w1, w2, vs
 234:	5a826420 	csneg	w0, w1, w2, vs
 238:	1a817420 	cinc	w0, w1, vs
 23c:	5a817020 	cinv	w0, w1, vs
 240:	5a817420 	cneg	w0, w1, vs
 244:	1a9f77e0 	cset	w0, vs
 248:	5a9f73e0 	csetm	w0, vs
 24c:	7a426025 	ccmp	w1, w2, #0x5, vs
 250:	7a47682a 	ccmp	w1, #0x7, #0xa, vs
 254:	1a827020 	csel	w0, w1, w2, vc
 258:	1a827420 	csinc	w0, w1, w2, vc
 25c:	5a827020 	csinv	w0, w1, w2, vc
 260:	5a827420 	csneg	w0, w1, w2, vc
 264:	1a816420 	cinc	w0, w1, vc
 268:	5a816020 	cinv	w0, w1, vc
 26c:	5a816420 	cneg	w0, w1, vc
 270:	1a9f67e0 	cset	w0, vc
 274:	5a9f63e0 	csetm	w0, vc
 278:	7a427025 	ccmp	w1, w2, #0x5, vc
 27c:	7a47782a 	ccmp	w1, #0x7, #0xa, vc
 280:	1a828020 	csel	w0, w1, w2, hi	// hi = pmore
 284:	1a828420 	csinc	w0, w1, w2, hi	// hi = pmore
 288:	5a828020 	csinv	w0, w1, w2, hi	// hi = pmore
 28c:	5a828420 	csneg	w0, w1, w2, hi	// hi = pmore
 290:	1a819420 	cinc	w0, w1, hi	// hi = pmore
 294:	5a819020 	cinv	w0, w1, hi	// hi = pmore
 298:	5a819420 	cneg	w0, w1, hi	// hi = pmore
 29c:	1a9f97e0 	cset	w0, hi	// hi = pmore
 2a0:	5a9f93e0 	csetm	w0, hi	// hi = pmore
 2a4:	7a428025 	ccmp	w1, w2, #0x5, hi	// hi = pmore
 2a8:	7a47882a 	ccmp	w1, #0x7, #0xa, hi	// hi = pmore
 2ac:	1a829020 	csel	w0, w1, w2, ls	// ls = plast
 2b0:	1a829420 	csinc	w0, w1, w2, ls	// ls = plast
 2b4:	5a829020 	csinv	w0, w1, w2, ls	// ls = plast
 2b8:	5a829420 	csneg	w0, w1, w2, ls	// ls = plast
 2bc:	1a818420 	cinc	w0, w1, ls	// ls = plast
 2c0:	5a818020 	cinv	w0, w1, ls	// ls = plast
 2c4:	5a818420 	cneg	w0, w1, ls	// ls = plast
 2c8:	1a9f87e0 	cset	w0, ls	// ls = plast
 2cc:	5a9f83e0 	csetm	w0, ls	// ls = plast
 2d0:	7a429025 	ccmp	w1, w2, #0x5, ls	// ls = plast
 2d4:	7a47982a 	ccmp	w1, #0x7, #0xa, ls	// ls = plast
 2d8:	1a82a020 	csel	w0, w1, w2, ge	// ge = tcont
 2dc:	1a82a420 	csinc	w0, w1, w2, ge	// ge = tcont
 2e0:	5a82a020 	csinv	w0, w1, w2, ge	// ge = tcont
 2e4:	5a82a420 	csneg	w0, w1, w2, ge	// ge = tcont
 2e8:	1a81b420 	cinc	w0, w1, ge	// ge = tcont
 2ec:	5a81b020 	cinv	w0, w1, ge	// ge = tcont
 2f0:	5a81b420 	cneg	w0, w1, ge	// ge = tcont
 2f4:	1a9fb7e0 	cset	w0, ge	// ge = tcont
 2f8:	5a9fb3e0 	csetm	w0, ge	// ge = tcont
 2fc:	7a42a025 	ccmp	w1, w2, #0x5, ge	// ge = tcont
 300:	7a47a82a 	ccmp	w1, #0x7, #0xa, ge	// ge = tcont
 304:	1a82b020 	csel	w0, w1, w2, lt	// lt = tstop
 308:	1a82b420 	csinc	w0, w1, w2, lt	// lt = tstop
 30c:	5a82b020 	csinv	w0, w1, w2, lt	// lt = tstop
 310:	5a82b420 	csneg	w0, w1, w2, lt	// lt = tstop
 314:	1a81a420 	cinc	w0, w1, lt	// lt = tstop
 318:	5a81a020 	cinv	w0, w1, lt	// lt = tstop
 31c:	5a81a420 	cneg	w0, w1, lt	// lt = tstop
 320:	1a9fa7e0 	cset	w0, lt	// lt = tstop
 324:	5a9fa3e0 	csetm	w0, lt	// lt = tstop
 328:	7a42b025 	ccmp	w1, w2, #0x5, lt	// lt = tstop
 32c:	7a47b82a 	ccmp	w1, #0x7, #0xa, lt	// lt = tstop
 330:	1a82c020 	csel	w0, w1, w2, gt
 334:	1a82c420 	csinc	w0, w1, w2, gt
 338:	5a82c020 	csinv	w0, w1, w2, gt
 33c:	5a82c420 	csneg	w0, w1, w2, gt
 340:	1a81d420 	cinc	w0, w1, gt
 344:	5a81d020 	cinv	w0, w1, gt
 348:	5a81d420 	cneg	w0, w1, gt
 34c:	1a9fd7e0 	cset	w0, gt
 350:	5a9fd3e0 	csetm	w0, gt
 354:	7a42c025 	ccmp	w1, w2, #0x5, gt
 358:	7a47c82a 	ccmp	w1, #0x7, #0xa, gt
 35c:	1a82d020 	csel	w0, w1, w2, le
 360:	1a82d420 	csinc	w0, w1, w2, le
 364:	5a82d020 	csinv	w0, w1, w2, le
 368:	5a82d420 	csneg	w0, w1, w2, le
 36c:	1a81c420 	cinc	w0, w1, le
 370:	5a81c020 	cinv	w0, w1, le
 374:	5a81c420 	cneg	w0, w1, le
 378:	1a9fc7e0 	cset	w0, le
 37c:	5a9fc3e0 	csetm	w0, le
 380:	7a42d025 	ccmp	w1, w2, #0x5, le
 384:	7a47d82a 	ccmp	w1, #0x7, #0xa, le
 388:	b9400880 	ldr	w0, [x4, #8]
 38c:	b9000880 	str	w0, [x4, #8]
 390:	b8408080 	ldur	w0, [x4, #8]
 394:	b8008080 	stur	w0, [x4, #8]
 398:	b8408c80 	ldr	w0, [x4, #8]!
 39c:	b8408480 	ldr	w0, [x4], #8
 3a0:	b8657880 	ldr	w0, [x4, x5, lsl #2]
 3a4:	b8008c80 	str	w0, [x4, #8]!
 3a8:	b8008480 	str	w0, [x4], #8
 3ac:	b8257880 	str	w0, [x4, x5, lsl #2]
 3b0:	39402080 	ldrb	w0, [x4, #8]
 3b4:	79401080 	ldrh	w0, [x4, #8]
 3b8:	39002080 	strb	w0, [x4, #8]
 3bc:	79001080 	strh	w0, [x4, #8]
 3c0:	39c02080 	ldrsb	w0, [x4, #8]
 3c4:	79c01080 	ldrsh	w0, [x4, #8]
 3c8:	8b020020 	add	x0, x1, x2
 3cc:	8b020c20 	add	x0, x1, x2, lsl #3
 3d0:	9101fc20 	add	x0, x1, #0x7f
 3d4:	cb020020 	sub	x0, x1, x2
 3d8:	cb020c20 	sub	x0, x1, x2, lsl #3
 3dc:	d101fc20 	sub	x0, x1, #0x7f
 3e0:	8a020020 	and	x0, x1, x2
 3e4:	8a020c20 	and	x0, x1, x2, lsl #3
 3e8:	8a220020 	bic	x0, x1, x2
 3ec:	8a220c20 	bic	x0, x1, x2, lsl #3
 3f0:	ca020020 	eor	x0, x1, x2
 3f4:	ca020c20 	eor	x0, x1, x2, lsl #3
 3f8:	aa020020 	orr	x0, x1, x2
 3fc:	aa020c20 	orr	x0, x1, x2, lsl #3
 400:	aa220020 	orn	x0, x1, x2
 404:	aa220c20 	orn	x0, x1, x2, lsl #3
 408:	ab020020 	adds	x0, x1, x2
 40c:	ab020c20 	adds	x0, x1, x2, lsl #3
 410:	b101fc20 	adds	x0, x1, #0x7f
 414:	eb020020 	subs	x0, x1, x2
 418:	eb020c20 	subs	x0, x1, x2, lsl #3
 41c:	f101fc20 	subs	x0, x1, #0x7f
 420:	ea020020 	ands	x0, x1, x2
 424:	ea020c20 	ands	x0, x1, x2, lsl #3
 428:	ea220020 	bics	x0, x1, x2
 42c:	ea220c20 	bics	x0, x1, x2, lsl #3
 430:	eb02003f 	cmp	x1, x2
 434:	eb020c3f 	cmp	x1, x2, lsl #3
 438:	ab02003f 	cmn	x1, x2
 43c:	ab020c3f 	cmn	x1, x2, lsl #3
 440:	ea02003f 	tst	x1, x2
 444:	ea020c3f 	tst	x1, x2, lsl #3
 448:	aa0103e0 	mov	x0, x1
 44c:	d2800fe0 	mov	x0, #0x7f                  	// #127
 450:	f2bbd5a0 	movk	x0, #0xdead, lsl #16
 454:	aa2103e0 	mvn	x0, x1
 458:	cb0103e0 	neg	x0, x1
 45c:	dac00c20 	rev	x0, x1
 460:	dac00420 	rev16	x0, x1
 464:	93401c20 	sxtb	x0, w1
 468:	93403c20 	sxth	x0, w1
 46c:	9b027c20 	mul	x0, x1, x2
 470:	9ac20820 	udiv	x0, x1, x2
 474:	9b020c20 	madd	x0, x1, x2, x3
 478:	9b028c20 	msub	x0, x1, x2, x3
 47c:	9ac22020 	lsl	x0, x1, x2
 480:	d340fc20 	lsr	x0, x1, #0
 484:	d37ff820 	lsl	x0, x1, #1
 488:	d379e020 	lsl	x0, x1, #7
 48c:	d3618020 	lsl	x0, x1, #31
 490:	9ac22420 	lsr	x0, x1, x2
 494:	d340fc20 	lsr	x0, x1, #0
 498:	d341fc20 	lsr	x0, x1, #1
 49c:	d347fc20 	lsr	x0, x1, #7
 4a0:	d35ffc20 	lsr	x0, x1, #31
 4a4:	9ac22820 	asr	x0, x1, x2
 4a8:	9340fc20 	asr	x0, x1, #0
 4ac:	9341fc20 	asr	x0, x1, #1
 4b0:	9347fc20 	asr	x0, x1, #7
 4b4:	935ffc20 	asr	x0, x1, #31
 4b8:	9ac22c20 	ror	x0, x1, x2
 4bc:	93c10020 	ror	x0, x1, #0
 4c0:	93c10420 	ror	x0, x1, #1
 4c4:	93c11c20 	ror	x0, x1, #7
 4c8:	93c17c20 	ror	x0, x1, #31
 4cc:	93c21c20 	extr	x0, x1, x2, #7
 4d0:	d3474c20 	ubfx	x0, x1, #7, #13
 4d4:	93474c20 	sbfx	x0, x1, #7, #13
 4d8:	d3793020 	ubfiz	x0, x1, #7, #13
 4dc:	b3474c20 	bfxil	x0, x1, #7, #13
 4e0:	b3793020 	bfi	x0, x1, #7, #13
 4e4:	9a820020 	csel	x0, x1, x2, eq	// eq = none
 4e8:	9a820420 	csinc	x0, x1, x2, eq	// eq = none
 4ec:	da820020 	csinv	x0, x1, x2, eq	// eq = none
 4f0:	da820420 	csneg	x0, x1, x2, eq	// eq = none
 4f4:	9a811420 	cinc	x0, x1, eq	// eq = none
 4f8:	da811020 	cinv	x0, x1, eq	// eq = none
 4fc:	da811420 	cneg	x0, x1, eq	// eq = none
 500:	9a9f17e0 	cset	x0, eq	// eq = none
 504:	da9f13e0 	csetm	x0, eq	// eq = none
 508:	fa420025 	ccmp	x1, x2, #0x5, eq	// eq = none
 50c:	fa47082a 	ccmp	x1, #0x7, #0xa, eq	// eq = none
 510:	9a821020 	csel	x0, x1, x2, ne	// ne = any
 514:	9a821420 	csinc	x0, x1, x2, ne	// ne = any
 518:	da821020 	csinv	x0, x1, x2, ne	// ne = any
 51c:	da821420 	csneg	x0, x1, x2, ne	// ne = any
 520:	9a810420 	cinc	x0, x1, ne	// ne = any
 524:	da810020 	cinv	x0, x1, ne	// ne = any
 528:	da810420 	cneg	x0, x1, ne	// ne = any
 52c:	9a9f07e0 	cset	x0, ne	// ne = any
 530:	da9f03e0 	csetm	x0, ne	// ne = any
 534:	fa421025 	ccmp	x1, x2, #0x5, ne	// ne = any
 538:	fa47182a 	ccmp	x1, #0x7, #0xa, ne	// ne = any
 53c:	9a822020 	csel	x0, x1, x2, cs	// cs = hs, nlast
 540:	9a822420 	csinc	x0, x1, x2, cs	// cs = hs, nlast
 544:	da822020 	csinv	x0, x1, x2, cs	// cs = hs, nlast
 548:	da822420 	csneg	x0, x1, x2, cs	// cs = hs, nlast
 54c:	9a813420 	cinc	x0, x1, cs	// cs = hs, nlast
 550:	da813020 	cinv	x0, x1, cs	// cs = hs, nlast
 554:	da813420 	cneg	x0, x1, cs	// cs = hs, nlast
 558:	9a9f37e0 	cset	x0, cs	// cs = hs, nlast
 55c:	da9f33e0 	csetm	x0, cs	// cs = hs, nlast
 560:	fa422025 	ccmp	x1, x2, #0x5, cs	// cs = hs, nlast
 564:	fa47282a 	ccmp	x1, #0x7, #0xa, cs	// cs = hs, nlast
 568:	9a823020 	csel	x0, x1, x2, cc	// cc = lo, ul, last
 56c:	9a823420 	csinc	x0, x1, x2, cc	// cc = lo, ul, last
 570:	da823020 	csinv	x0, x1, x2, cc	// cc = lo, ul, last
 574:	da823420 	csneg	x0, x1, x2, cc	// cc = lo, ul, last
 578:	9a812420 	cinc	x0, x1, cc	// cc = lo, ul, last
 57c:	da812020 	cinv	x0, x1, cc	// cc = lo, ul, last
 580:	da812420 	cneg	x0, x1, cc	// cc = lo, ul, last
 584:	9a9f27e0 	cset	x0, cc	// cc = lo, ul, last
 588:	da9f23e0 	csetm	x0, cc	// cc = lo, ul, last
 58c:	fa423025 	ccmp	x1, x2, #0x5, cc	// cc = lo, ul, last
 590:	fa47382a 	ccmp	x1, #0x7, #0xa, cc	// cc = lo, ul, last
 594:	9a824020 	csel	x0, x1, x2, mi	// mi = first
 598:	9a824420 	csinc	x0, x1, x2, mi	// mi = first
 59c:	da824020 	csinv	x0, x1, x2, mi	// mi = first
 5a0:	da824420 	csneg	x0, x1, x2, mi	// mi = first
 5a4:	9a815420 	cinc	x0, x1, mi	// mi = first
 5a8:	da815020 	cinv	x0, x1, mi	// mi = first
 5ac:	da815420 	cneg	x0, x1, mi	// mi = first
 5b0:	9a9f57e0 	cset	x0, mi	// mi = first
 5b4:	da9f53e0 	csetm	x0, mi	// mi = first
 5b8:	fa424025 	ccmp	x1, x2, #0x5, mi	// mi = first
 5bc:	fa47482a 	ccmp	x1, #0x7, #0xa, mi	// mi = first
 5c0:	9a825020 	csel	x0, x1, x2, pl	// pl = nfrst
 5c4:	9a825420 	csinc	x0, x1, x2, pl	// pl = nfrst
 5c8:	da825020 	csinv	x0, x1, x2, pl	// pl = nfrst
 5cc:	da825420 	csneg	x0, x1, x2, pl	// pl = nfrst
 5d0:	9a814420 	cinc	x0, x1, pl	// pl = nfrst
 5d4:	da814020 	cinv	x0, x1, pl	// pl = nfrst
 5d8:	da814420 	cneg	x0, x1, pl	// pl = nfrst
 5dc:	9a9f47e0 	cset	x0, pl	// pl = nfrst
 5e0:	da9f43e0 	csetm	x0, pl	// pl = nfrst
 5e4:	fa425025 	ccmp	x1, x2, #0x5, pl	// pl = nfrst
 5e8:	fa47582a 	ccmp	x1, #0x7, #0xa, pl	// pl = nfrst
 5ec:	9a826020 	csel	x0, x1, x2, vs
 5f0:	9a826420 	csinc	x0, x1, x2, vs
 5f4:	da826020 	csinv	x0, x1, x2, vs
 5f8:	da826420 	csneg	x0, x1, x2, vs
 5fc:	9a817420 	cinc	x0, x1, vs
 600:	da817020 	cinv	x0, x1, vs
 604:	da817420 	cneg	x0, x1, vs
 608:	9a9f77e0 	cset	x0, vs
 60c:	da9f73e0 	csetm	x0, vs
 610:	fa426025 	ccmp	x1, x2, #0x5, vs
 614:	fa47682a 	ccmp	x1, #0x7, #0xa, vs
 618:	9a827020 	csel	x0, x1, x2, vc
 61c:	9a827420 	csinc	x0, x1, x2, vc
 620:	da827020 	csinv	x0, x1, x2, vc
 624:	da827420 	csneg	x0, x1, x2, vc
 628:	9a816420 	cinc	x0, x1, vc
 62c:	da816020 	cinv	x0, x1, vc
 630:	da816420 	cneg	x0, x1, vc
 634:	9a9f67e0 	cset	x0, vc
 638:	da9f63e0 	csetm	x0, vc
 63c:	fa427025 	ccmp	x1, x2, #0x5, vc
 640:	fa47782a 	ccmp	x1, #0x7, #0xa, vc
 644:	9a828020 	csel	x0, x1, x2, hi	// hi = pmore
 648:	9a828420 	csinc	x0, x1, x2, hi	// hi = pmore
 64c:	da828020 	csinv	x0, x1, x2, hi	// hi = pmore
 650:	da828420 	csneg	x0, x1, x2, hi	// hi = pmore
 654:	9a819420 	cinc	x0, x1, hi	// hi = pmore
 658:	da819020 	cinv	x0, x1, hi	// hi = pmore
 65c:	da819420 	cneg	x0, x1, hi	// hi = pmore
 660:	9a9f97e0 	cset	x0, hi	// hi = pmore
 664:	da9f93e0 	csetm	x0, hi	// hi = pmore
 668:	fa428025 	ccmp	x1, x2, #0x5, hi	// hi = pmore
 66c:	fa47882a 	ccmp	x1, #0x7, #0xa, hi	// hi = pmore
 670:	9a829020 	csel	x0, x1, x2, ls	// ls = plast
 674:	9a829420 	csinc	x0, x1, x2, ls	// ls = plast
 678:	da829020 	csinv	x0, x1, x2, ls	// ls = plast
 67c:	da829420 	csneg	x0, x1, x2, ls	// ls = plast
 680:	9a818420 	cinc	x0, x1, ls	// ls = plast
 684:	da818020 	cinv	x0, x1, ls	// ls = plast
 688:	da818420 	cneg	x0, x1, ls	// ls = plast
 68c:	9a9f87e0 	cset	x0, ls	// ls = plast
 690:	da9f83e0 	csetm	x0, ls	// ls = plast
 694:	fa429025 	ccmp	x1, x2, #0x5, ls	// ls = plast
 698:	fa47982a 	ccmp	x1, #0x7, #0xa, ls	// ls = plast
 69c:	9a82a020 	csel	x0, x1, x2, ge	// ge = tcont
 6a0:	9a82a420 	csinc	x0, x1, x2, ge	// ge = tcont
 6a4:	da82a020 	csinv	x0, x1, x2, ge	// ge = tcont
 6a8:	da82a420 	csneg	x0, x1, x2, ge	// ge = tcont
 6ac:	9a81b420 	cinc	x0, x1, ge	// ge = tcont
 6b0:	da81b020 	cinv	x0, x1, ge	// ge = tcont
 6b4:	da81b420 	cneg	x0, x1, ge	// ge = tcont
 6b8:	9a9fb7e0 	cset	x0, ge	// ge = tcont
 6bc:	da9fb3e0 	csetm	x0, ge	// ge = tcont
 6c0:	fa42a025 	ccmp	x1, x2, #0x5, ge	// ge = tcont
 6c4:	fa47a82a 	ccmp	x1, #0x7, #0xa, ge	// ge = tcont
 6c8:	9a82b020 	csel	x0, x1, x2, lt	// lt = tstop
 6cc:	9a82b420 	csinc	x0, x1, x2, lt	// lt = tstop
 6d0:	da82b020 	csinv	x0, x1, x2, lt	// lt = tstop
 6d4:	da82b420 	csneg	x0, x1, x2, lt	// lt = tstop
 6d8:	9a81a420 	cinc	x0, x1, lt	// lt = tstop
 6dc:	da81a020 	cinv	x0, x1, lt	// lt = tstop
 6e0:	da81a420 	cneg	x0, x1, lt	// lt = tstop
 6e4:	9a9fa7e0 	cset	x0, lt	// lt = tstop
 6e8:	da9fa3e0 	csetm	x0, lt	// lt = tstop
 6ec:	fa42b025 	ccmp	x1, x2, #0x5, lt	// lt = tstop
 6f0:	fa47b82a 	ccmp	x1, #0x7, #0xa, lt	// lt = tstop
 6f4:	9a82c020 	csel	x0, x1, x2, gt
 6f8:	9a82c420 	csinc	x0, x1, x2, gt
 6fc:	da82c020 	csinv	x0, x1, x2, gt
 700:	da82c420 	csneg	x0, x1, x2, gt
 704:	9a81d420 	cinc	x0, x1, gt
 708:	da81d020 	cinv	x0, x1, gt
 70c:	da81d420 	cneg	x0, x1, gt
 710:	9a9fd7e0 	cset	x0, gt
 714:	da9fd3e0 	csetm	x0, gt
 718:	fa42c025 	ccmp	x1, x2, #0x5, gt
 71c:	fa47c82a 	ccmp	x1, #0x7, #0xa, gt
 720:	9a82d020 	csel	x0, x1, x2, le
 724:	9a82d420 	csinc	x0, x1, x2, le
 728:	da82d020 	csinv	x0, x1, x2, le
 72c:	da82d420 	csneg	x0, x1, x2, le
 730:	9a81c420 	cinc	x0, x1, le
 734:	da81c020 	cinv	x0, x1, le
 738:	da81c420 	cneg	x0, x1, le
 73c:	9a9fc7e0 	cset	x0, le
 740:	da9fc3e0 	csetm	x0, le
 744:	fa42d025 	ccmp	x1, x2, #0x5, le
 748:	fa47d82a 	ccmp	x1, #0x7, #0xa, le
 74c:	f9400480 	ldr	x0, [x4, #8]
 750:	f9000480 	str	x0, [x4, #8]
 754:	f8408080 	ldur	x0, [x4, #8]
 758:	f8008080 	stur	x0, [x4, #8]
 75c:	f8408c80 	ldr	x0, [x4, #8]!
 760:	f8408480 	ldr	x0, [x4], #8
 764:	f8657880 	ldr	x0, [x4, x5, lsl #3]
 768:	f8008c80 	str	x0, [x4, #8]!
 76c:	f8008480 	str	x0, [x4], #8
 770:	f8257880 	str	x0, [x4, x5, lsl #3]
 774:	39802080 	ldrsb	x0, [x4, #8]
 778:	79801080 	ldrsh	x0, [x4, #8]
 77c:	93407c20 	sxtw	x0, w1
 780:	9bc27c20 	umulh	x0, x1, x2
 784:	9ba27c20 	umull	x0, w1, w2
 788:	9ba20c20 	umaddl	x0, w1, w2, x3
 78c:	9b220c20 	smaddl	x0, w1, w2, x3
 790:	b9800880 	ldrsw	x0, [x4, #8]
 794:	a9408480 	ldp	x0, x1, [x4, #8]
 798:	a9008480 	stp	x0, x1, [x4, #8]
 79c:	9e670000 	fmov	d0, x0
 7a0:	9e660000 	fmov	x0, d0
 7a4:	1e270000 	fmov	s0, w0
 7a8:	1e260000 	fmov	w0, s0
 7ac:	0e205800 	cnt	v0.8b, v0.8b
 7b0:	4e205800 	cnt	v0.16b, v0.16b
 7b4:	2e303800 	uaddlv	h0, v0.8b
 7b8:	6e303800 	uaddlv	h0, v0.16b
 7bc:	3dc00480 	ldr	q0, [x4, #16]
 7c0:	3d800480 	str	q0, [x4, #16]
