.PHONY: build
build:
	lake build reference

.PHONY: wire axioms
wire:
	python3 tools/check_reference_x86_path.py
axioms:
	lake env lean PrintPath.lean
