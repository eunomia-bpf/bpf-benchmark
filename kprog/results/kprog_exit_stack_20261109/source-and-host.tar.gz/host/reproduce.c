#include <stdio.h>
#ifdef TEST_ARM64
#define ARM64_SIM_ENABLE_STACK 1
#include "kprog/arm64/arm64_sim_local_bpf.h"
#define ENTRY() ARM64_SIM_ENTRY_RAW((void *)0)
#define WRITE(O,V) ARM64_SIM_L_STACK_WRITE((O),8,(V))
#define READ(O) ARM64_SIM_L_STACK_READ((O),8)
#define SP __a64_sp
#define FP __a64_x29
#define RET() ARM64_SIM_RET()
#else
#define X86_SIM_ENABLE_STACK 1
#include "kprog/x86/x86_sim_local_bpf.h"
#define ENTRY() X86_SIM_ENTRY_RAW((void *)0)
#define WRITE(O,V) X86_SIM_L_STACK_WRITE((O),8,(V))
#define READ(O) X86_SIM_L_STACK_READ((O),8)
#define SP __x86_rsp.ptr
#define FP __x86_rbp
#define RET() X86_SIM_X86_RET()
#endif
static unsigned exit_frame(void) { ENTRY(); FP.ptr=(void *)0x1234; RET(); }
static unsigned long long below_sp(void) { ENTRY(); SP=-16; WRITE(-16,3); SP=0; WRITE(-8,7); return READ(-8); }
int main(void) { printf("changed-frame return=%u; below-SP write/read=%llu\n",exit_frame(),below_sp()); }
unsigned long native_lab_entry_input(unsigned int kind) { return 0; }
