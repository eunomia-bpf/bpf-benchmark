#include <stdio.h>
extern int native_below_sp(void);
int main(void) { int overwritten=native_below_sp(); printf("native CALL overwrites below-SP slot: %d\n",overwritten); return !overwritten; }
