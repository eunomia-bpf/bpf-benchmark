#include <stdio.h>
extern int observe_callee_slot(void);
int main(void) { int alias=observe_callee_slot(); printf("caller below-SP argument aliases callee saved return slot: %d\n",alias);return !alias; }
