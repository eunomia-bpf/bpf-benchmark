from pathlib import Path
from collections import Counter
import csv,gzip,hashlib,io,json,shutil,subprocess,tarfile
O=Path('/var/tmp/kprog-tmp/S7');R=Path('/workspaces/repository');P=O/'report-output';P.mkdir(exist_ok=True)
xs=O/'safety-x86-output';xr=json.loads((xs/'run/outcomes.json').read_text())
ap=O/'safety-arm64-output/trusted-arm64-service-result/summary.json';ameta=json.loads(ap.read_text());archive=ap.parent/ameta['archive']
with tarfile.open(archive) as a:
 ar=json.load(a.extractfile('run/outcomes.json'))
new=['exit_frame_pointer_map','exit_stack_pointer','below_sp_call','below_sp_helper_output','below_sp_memset_output','below_sp_memcpy_output']
def result(rows,isa):
 n=new+['exit_r12' if isa=='x86' else 'exit_x19']
 return dict(cases=len(rows),stages=dict(Counter(r['stage'] for r in rows)),positive_controls={r['name']:r['stage'] for r in rows if not r['negative']},s7_cases={r['name']:r['stage'] for r in rows if r['name'] in n},stack_enforcement={r['name']:r['stage'] for r in rows if r['name'] in ['stack_oob','uninitialized_stack']},accepted_old_cases=[r['name'] for r in rows if r['stage']=='accepted_finding'],negative_native_test_run=sum(bool(r['negative'] and r.get('unsafe_native_executed')) for r in rows))
s=json.loads(subprocess.check_output(['git','show','cc245743c:kprog/results/kprog_exit_stack_20261109/summary.json'],cwd=R,text=True))
for arch,rows in [('x86',xr),('arm64',ar)]:s[arch+'_safety']=result(rows,arch)
s['source_commits']=list(dict.fromkeys(s['source_commits']+['f7c517c0a95a8e7df2e38b6aaaf2bba0e0d9efe2','25a373adf2359e094910004481bf86af17fd437a','cc245743cfc34f873fe51c79864756873ccf4f27']))
s['compile_checks']={name:int((O/(name+'.exit')).read_text()) for name in ['output-micro']}
s['micro']={a:dict(positive_compiled=29,negative_compiled=1,returncode=s['compile_checks']['output-micro']) for a in ['x86','arm64']}
s['host']['opaque_output']='GCC and Clang pass both ISAs; helper, memcpy, memset fault arm and allocated-frame/source controls'
s['runtime_hashes']={a:json.loads((O/('safety-'+a+'-output')/'pins.json').read_text()) for a in ['x86','arm64']}
s['prior_source_diff_size']=s.pop('diff_size',{})
s['followup_source_commits']=['f7c517c0a','25a373adf','cc245743c']
s['followup_diffstat']=subprocess.check_output(['git','show','--format=','--numstat','f7c517c0a','25a373adf','cc245743c','--','kprog/x86/x86_sim_local_bpf.h','kprog/arm64/arm64_sim_local_bpf.h','kprog/fidelity/negative.py','kprog/formal/oracles/test_stack_output_lifetime_host.c'],cwd=R,text=True)
s['requested_cases_completed']=all(v=='verifier_rejected' for a in ['x86','arm64'] for v in s[a+'_safety']['s7_cases'].values()) and all(v=='valid_executed' for a in ['x86','arm64'] for v in s[a+'_safety']['positive_controls'].values()) and all(v=='verifier_rejected' for a in ['x86','arm64'] for v in s[a+'_safety']['stack_enforcement'].values()) and all(len(s[a+'_safety']['s7_cases'])==7 for a in ['x86','arm64']) and s['compile_checks']['output-micro']==0
s['scope_completed']=s['requested_cases_completed'];s['remaining_goal']='Universal exit/stack C-to-Lean, compiled-body and physical-call composition remain V/S13 ledger obligations.'
s['remaining']={'formal':'V owns universal current exit/stack C-to-Lean and compiled-body composition, ledger merge and whole-state oracle alignment','tail_transfer':'S11/S13 own successful native tail unwind/transfer composition','older_fixtures':'A/coordinator own recovery-trigger annotation and broader ARM ALU interpretation','application_precision':'A07:35 reported unchanged BCC sys_enter/capable caller-frame equality precision; preserved raw archive corpus/results/kprog_arm64_app_coverage_20261109/probe-read/lowering/applications/bcc/trusted-arm64-bcc-result/run-20261109T071141599137Z.tar.gz requests2/3. Current finite S7 frame controls retain their measured stages; generic application precision remains an integration goal.'}
s['terminal_transport']={'x86_make_exit':int((O/'output-x86.exit').read_text()),'arm64_make_exit':int((O/'output-arm64.exit').read_text()),'arm64_guest_exit':ameta.get('guest_exit'),'arm64_qemu_returncode':ameta.get('qemu_returncode'),'arm64_hashes_unchanged':ameta.get('hashes_unchanged')}
(P/'summary.json').write_text(json.dumps(s,indent=2)+'\n')
with tarfile.open(P/'x86-replay.tar.gz','w:gz') as a:
 a.add(xs/'run',arcname='run');a.add(xs/'pins.json',arcname='pins.json');a.add(xs/'cases.json',arcname='cases.json')
shutil.copyfile(archive,P/'arm64-replay.tar.gz')
with tarfile.open(P/'source-and-host.tar.gz','w:gz') as a:
 for dirname,arcname in [('output-x86-source','source/x86'),('output-arm64-source','source/arm64'),('before','source/before')]:
  for f in (O/dirname).rglob('*'):
   if f.is_file() and f.suffix in ['.h','.py','.c','.json','.toml']:a.add(f,arcname=str(Path(arcname)/f.relative_to(O/dirname)))
 for f in (O/'host').iterdir():
  if f.is_file() and f.suffix in ['.c','.S','.txt']:a.add(f,arcname='host/'+f.name)
 for name in ['test_stack_output_lifetime_host.c','test_invocation_stack_host.c']:
  a.add(R/'kprog/formal/oracles'/name,arcname='host/'+name)
 for n in ['application-precision.json','review.json','report-output.py','output.mk','output.sh','x86-output.py','arm64-output.py','output-edit.py','native-compile-flags.txt','output-helper-coverage.json','output-x86.log','output-arm64.log','output-micro.log']:
  a.add(O/n,arcname='receipts/'+n)
 for arch in ['x86','arm64']:
  for d in ['output-micro-','output-negative-']:
   for f in (O/(d+arch)).glob('*.compile.json'):a.add(f,arcname='compile/'+arch+'/'+f.name)
text='# Micro compilation receipts\n\n'
for a in ['x86','arm64']:
 for d in ['output-micro-','output-negative-']:text+='## '+d+a+'\n\n'+(O/(d+a+'.md')).read_text()+'\n'
(P/'micro.md').write_text(text.rstrip()+'\n')
with (O/'coverage-updates.tsv').open() as f:
 reader=csv.DictReader(f,delimiter='\t');fields=reader.fieldnames;rows=list(reader)
for r in rows:
 a=r['isa'];r['catalog_sha256']=hashlib.sha256((O/('output-'+a+'-source')/r['catalog_source']).read_bytes()).hexdigest() if (O/('output-'+a+'-source')/r['catalog_source']).exists() else r['catalog_sha256']
 r['replay_evidence']='kprog/results/kprog_exit_stack_20261109/summary.json;kprog/results/kprog_exit_stack_20261109/'+('x86' if a=='x86' else 'arm64')+'-replay.tar.gz'
 r['replay_source_epochs']=json.dumps(list(dict.fromkeys(json.loads(r['replay_source_epochs'])+s['source_commits'])),separators=(',',':'))
 r['hardware_qemu_replay_agreeing']='finite-exit-stack-suite'
 r['scope']+=' Opaque helper/libc output destinations below SP take the existing fault arm. Final replay preserves spilled-SP controls and original stack memory enforcement.'
with (P/'coverage-updates.tsv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=fields,delimiter='\t',lineterminator='\n');w.writeheader();w.writerows(rows)
readme=subprocess.check_output(['git','show','cc245743c:kprog/results/kprog_exit_stack_20261109/README.md'],cwd=R,text=True)
readme=readme.replace('primitive below-SP contracts','below-SP contracts')
readme=readme.replace('`117eb020a`, `088a292b0`.', '`117eb020a`, `088a292b0`, `f7c517c0a`, `25a373adf`, `cc245743c`.')
a=readme.index('| ISA | Valid controls');b=readme.index('The x86 acceptance changes',a)
table='| ISA | Valid controls executed | New S7 cases rejected by verifier | Other negative outcomes |\n| --- | ---: | ---: | --- |\n'
for isa in ['x86','arm64']:
 z=s[isa+'_safety'];other=Counter(r['stage'] for r in (xr if isa=='x86' else ar) if r['negative'] and r['name'] not in z['s7_cases'])
 table+=f"| {isa} | {z['stages'].get('valid_executed',0)} | {sum(v=='verifier_rejected' for v in z['s7_cases'].values())}/7 | "+', '.join(f'{k}={v}' for k,v in sorted(other.items()))+' |\n'
readme=readme[:a]+table+'\n'+readme[b:]
a=readme.index('The exact remaining physical boundary');b=readme.index('AArch64 acceptance changes',a)
readme=readme[:a]+"The coordinator's07:25 decision closes the opaque-output boundary in B. Helper output arguments and libc destinations below the caller SP select the existing architectural-fault arm on both ISAs. Source routing covers26x86 and29ARM output helpers. Actual GCC and Clang host checks exercise their common output-pointer primitive, a helper destination, memcpy/memset and live-frame controls. Three additional load-only output cases perISA reach stock-verifier rejection. The earlier benign address-only observers remain in the host archive as reproduction evidence. S13/V retain universal typed-helper/frame and compiled-body composition.\n\n"+readme[b:]
a=readme.index('AArch64 acceptance changes');b=readme.index('Generic C-to-Lean',a)
readme=readme[:a]+'AArch64 accepted original labels in this captured epoch: '+', '.join('`'+n+'`' for n in s['arm64_safety']['accepted_old_cases'])+'. Every original expectation and measured stage remains in the receipts. Concurrent scalar-native policy can shift SIMD fixtures to generation rejection; protected-read recovery continues to account for the original NULL-load-trigger labels.\n\n'+readme[b:]
a=readme.index('The full suites return')
readme=readme[:a]+"The A07:35 whole-application receipt additionally identifies caller-frame equality precision for unchanged sys_enter and kprobe__cap_capable_entry. The source-and-host archive retains the precise scalar-alias equality/fault contexts and original archive paths. Current standalone spilled-SP/frame controls pass; this application-coverage integration remains explicit in summary.json.\n\nThe terminal source-captured replay records45x86 cases and the measured ARM count in summary.json. All14newS7 cases and the original stack_oob/uninitialized_stack cases reach stock-verifier rejection; all13positive controls execute, including both spilled-SP controls. Both30-case compile batches pass. Full suite diagnostic exit codes remain explicit in summary.json alongside accepted original fixtures. The requested exit/stack source repair and finite regression scope are complete; the universal proof and physical composition interfaces retain the owners recorded above.\n"
(P/'README.md').write_text(readme)
print(json.dumps({a:s[a+'_safety'] for a in ['x86','arm64']}|dict(scope_completed=s['scope_completed']),indent=2))
