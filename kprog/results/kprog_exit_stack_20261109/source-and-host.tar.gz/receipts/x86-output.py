from pathlib import Path
import subprocess,shutil,os,select,json,hashlib,importlib.util
R=Path('/workspaces/repository');O=Path('/var/tmp/kprog-tmp/S7')
# Enter a private mount namespace before mapping this lane's existing harness paths.
os.unshare(os.CLONE_NEWNS);subprocess.run(['mount','--make-rprivate','/'],check=True)
out=O/'safety-x86-output';shutil.copytree(O/'safety-x86',out,ignore=shutil.ignore_patterns('run','requests','*.stdout','*.stderr'))
build=O/'build-x86-output';shutil.copytree(O/'build-x86',build)
for src,dst in [(out,R/'kprog/results/kprog_fidelity_20261107/negative/x86-trusted-sp'),(build,R/'kprog/formal/build/fidelity-trusted')]:subprocess.run(['mount','--bind',str(src),str(dst)],check=True)
script=R/'kprog/results/kprog_fidelity_20261107/negative/x86-trusted-sp/s7.py'
subprocess.run(['python3',str(script),'build'],check=True)
# Capture the sources and runtime that the final replay will actually read.
spec=importlib.util.spec_from_file_location('tcbs',R/'kprog/fidelity/tcb.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
paths=m.includes(R/'kprog/x86/x86_sim_local_bpf.h')|m.imports(R/'kprog/x86/micro-prog/generate_micro_sim_proofs.py')
paths|={R/x for x in ['kprog/trusted_service.py','kprog/trusted_generation.py','kprog/x86/trusted_specializer.py','kprog/tv/build-kernel-x86/arch/x86/boot/bzImage','kprog/tv/build-x86/bpf_x86_native_lab.ko','kprog/libnativeloader/build/trusted-native-loader','kprog/x86/native_lab/native_link/target/release/native-link']}
pins={};snapshot=O/'output-x86-source'
for p in sorted(paths):
 target=snapshot/p.relative_to(R);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target);pins[str(p.relative_to(R))]=hashlib.sha256(target.read_bytes()).hexdigest();subprocess.run(['mount','--bind',str(target),str(p)],check=True)
(out/'pins.json').write_text(json.dumps(pins,indent=2)+'\n');(out/'run').mkdir()
cmd='cd /workspaces/repository && (mountpoint -q /sys/kernel/debug || mount -t debugfs debugfs /sys/kernel/debug) && insmod kprog/tv/build-x86/bpf_x86_native_lab.ko && PATH=/usr/lib/llvm-18/bin:$PATH python3 kprog/results/kprog_fidelity_20261107/negative/x86-trusted-sp/s7.py guest /workspaces/repository/kprog/results/kprog_fidelity_20261107/negative/x86-trusted-sp/run'
ret=subprocess.run(['taskset','-c','20-23','vng','--run',str(R/'kprog/tv/build-kernel-x86/arch/x86/boot/bzImage'),'--cwd',str(R),'--rwdir',str(R),'--overlay-rwdir','/tmp','--disable-monitor','--cpus','2','--memory','2G','--append','loglevel=4 panic=30 oops=panic','--exec',cmd]).returncode
(out/'host.exit').write_text(str(ret)+'\n');raise SystemExit(ret)
