.PHONY: output-micro output-x86 output-arm64
output-micro:
	python3 kprog/run_micro_sim_batch.py --arch x86 --build-only --no-generate --no-build-loader --build-dir /var/tmp/kprog-tmp/S7/output-micro-x86 --markdown /var/tmp/kprog-tmp/S7/output-micro-x86.md --jobs 4
	python3 kprog/run_micro_sim_batch.py --arch x86 --build-only --no-generate --no-build-loader --config kprog/test/kprog_negative_stage2.yaml --build-dir /var/tmp/kprog-tmp/S7/output-negative-x86 --markdown /var/tmp/kprog-tmp/S7/output-negative-x86.md --jobs 1
	python3 kprog/run_micro_sim_batch.py --arch arm64 --build-only --no-generate --no-build-loader --build-dir /var/tmp/kprog-tmp/S7/output-micro-arm64 --markdown /var/tmp/kprog-tmp/S7/output-micro-arm64.md --jobs 4
	python3 kprog/run_micro_sim_batch.py --arch arm64 --build-only --no-generate --no-build-loader --config kprog/test/kprog_negative_stage2.yaml --build-dir /var/tmp/kprog-tmp/S7/output-negative-arm64 --markdown /var/tmp/kprog-tmp/S7/output-negative-arm64.md --jobs 1
output-x86:
	python3 /var/tmp/kprog-tmp/S7/x86-output.py
output-arm64:
	python3 /var/tmp/kprog-tmp/S7/arm64-output.py
