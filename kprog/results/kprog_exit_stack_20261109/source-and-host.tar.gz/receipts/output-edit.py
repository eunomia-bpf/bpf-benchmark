from pathlib import Path
import re,difflib
R=Path('/workspaces/repository');O=Path('/var/tmp/kprog-tmp/S7')
outputs={'probe_read':0,'get_current_comm':0,'skb_get_tunnel_key':1,'skb_load_bytes':2,'probe_write_user':0,'probe_read_str':0,'get_stack':1,'skb_load_bytes_relative':2,'fib_lookup':1,'map_pop_elem':1,'strtol':3,'probe_read_user':0,'probe_read_kernel':0,'probe_read_user_str':0,'probe_read_kernel_str':0,'copy_from_user':0,'check_mtu':2,'ima_inode_hash':1,'get_func_arg':2,'get_func_ret':1,'xdp_load_bytes':2,'copy_from_user_task':0,'ima_file_hash':1,'kptr_xchg':0,'dynptr_from_mem':3,'ringbuf_reserve_dynptr':3,'ringbuf_submit_dynptr':0,'ringbuf_discard_dynptr':0,'dynptr_read':0}
for arch,prefix,stem in [('x86','X86','x86'),('arm64','ARM64','a64')]:
 p=R/f'kprog/{arch}/{arch}_sim_local_bpf.h';old=p.read_text();s=old
 anchor=f'/* Helpers consume' if arch=='x86' else '/* Only the proven'
 idx=s.index(anchor)
 if arch=='x86':
  predicate='X86_SIM_L_REG_TAG(REG) == X86_SIM_TAG_STACK && \\\n           X86_SIM_L_STACK_ALIAS_OFFSET(X86_SIM_L_READ_REG_PTR(REG)) < X86_SIM_L_STACK_SP()'
  fault='X86_SIM_L_ARCHITECTURAL_FAULT()'
 else:
  predicate='ARM64_SIM_L_REG_TAG(REG) == ARM64_SIM_TAG_STACK && \\\n           (__s64)(long)ARM64_SIM_L_READ_REG_PTR(REG) < ARM64_SIM_L_STACK_SP()'
  fault='ARM64_SIM_L_UNSUPPORTED_OPCODE()'
 addition=f'''/* Opaque callees own the bytes below the caller's current SP. */
#define {prefix}_SIM_L_HELPER_WRITE_ARG_PTR(REG) \\
    ({{ if ({predicate}) \\
           {fault}; \\
       {prefix}_SIM_L_HELPER_ARG_PTR(REG); }})

'''
 s=s[:idx]+addition+s[idx:]
 # Replace precisely the destination expression in each existing helper body.
 covered=[]
 for name,arg in outputs.items():
  pat=re.compile(r'(#define '+prefix+r'_SIM_BPF_CALL_bpf_'+name+r'\(\).*?)(?=\n#|\Z)',re.S)
  m=pat.search(s)
  if not m:continue
  reg=f'ARM64_X{arg}' if arch=='arm64' else ['X86_RDI','X86_RSI','X86_RDX','X86_RCX','X86_R8'][arg]
  body=m[0];needle=f'{prefix}_SIM_L_HELPER_ARG_PTR({reg})'
  # Last occurrence is the helper destination; ARM shadow effects use READ_REG_PTR.
  assert needle in body,(arch,name,reg)
  pos=body.rfind(needle)
  body=body[:pos]+body[pos:].replace(needle,f'{prefix}_SIM_L_HELPER_WRITE_ARG_PTR({reg})',1)
  s=s[:m.start()]+body+s[m.end():];covered.append(name)
 if arch=='x86':
  needle='void *__x86_l_dst_ptr = X86_SIM_L_READ_REG_PTR(X86_RDI);'
  start=s.index('#define X86_SIM_L_EXEC_CALL_MEM_STEP')
  a=s[:start];b=s[start:];assert needle in b;b=b.replace(needle,'void *__x86_l_dst_ptr = X86_SIM_L_HELPER_WRITE_ARG_PTR(X86_RDI);',1);s=a+b
 else:
  for macro in ['ARM64_SIM_LIBC_MEMSET','ARM64_SIM_LIBC_MEMCPY']:
   start=s.index('#define '+macro+'()');pos=s.index('do {',start)+len('do {')
   s=s[:pos]+' (void)ARM64_SIM_L_HELPER_WRITE_ARG_PTR(ARM64_X0);'+s[pos:]
 p.write_text(s)
 (O/f'output-{arch}.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='a/'+str(p.relative_to(R)),tofile='b/'+str(p.relative_to(R)))))
 print(arch,'output helpers',len(covered),covered)
