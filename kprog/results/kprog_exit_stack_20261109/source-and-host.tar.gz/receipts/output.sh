#!/bin/bash
ulimit -c 0
export TMPDIR=/var/tmp/kprog-tmp/S7 PYTHONDONTWRITEBYTECODE=1
cd /workspaces/repository
for stage in output-micro output-x86 output-arm64; do
 taskset -c 8-23 make -f /var/tmp/kprog-tmp/S7/output.mk "$stage" >"/var/tmp/kprog-tmp/S7/$stage.log" 2>&1
 echo $? >"/var/tmp/kprog-tmp/S7/$stage.exit"
done
