; ModuleID = '/tmp/native_kernel_link_cache/6ce284013325b945.tmp.637.644.blob.frozen-lto.669/native.o.lpm.1.c'
source_filename = "/tmp/native_kernel_link_cache/6ce284013325b945.tmp.637.644.blob.frozen-lto.669/native.o.lpm.1.c"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

; Function Attrs: nofree norecurse nounwind
define ptr @__native_link_typed_lpm_lookup_1(ptr noundef %0, ptr nocapture noundef readonly %1) local_unnamed_addr #0 {
  %3 = getelementptr inbounds i8, ptr %0, i64 392
  %4 = load i64, ptr %3, align 8, !tbaa !3
  %5 = getelementptr inbounds i8, ptr %0, i64 384
  %6 = load i64, ptr %5, align 8, !tbaa !3
  %7 = load i32, ptr %1, align 1, !tbaa !7
  %8 = zext i32 %7 to i64
  %9 = icmp ult i64 %6, %8
  br i1 %9, label %132, label %10

10:                                               ; preds = %2
  %11 = getelementptr inbounds i8, ptr %0, i64 288
  %12 = getelementptr i8, ptr %1, i64 4
  %13 = load volatile ptr, ptr %11, align 8, !tbaa !8
  %14 = icmp eq ptr %13, null
  br i1 %14, label %126, label %15

15:                                               ; preds = %10
  %16 = icmp ugt i64 %4, 7
  br label %17

17:                                               ; preds = %15, %106
  %18 = phi ptr [ %13, %15 ], [ %124, %106 ]
  %19 = phi ptr [ null, %15 ], [ %111, %106 ]
  %20 = getelementptr inbounds i8, ptr %18, i64 16
  %21 = load i32, ptr %20, align 1, !tbaa !7
  %22 = icmp ugt i32 %21, %7
  br i1 %22, label %126, label %23

23:                                               ; preds = %17
  %24 = getelementptr inbounds i8, ptr %18, i64 24
  %25 = icmp eq i32 %21, 0
  br i1 %25, label %103, label %26

26:                                               ; preds = %23
  br i1 %16, label %27, label %42

27:                                               ; preds = %26
  %28 = load i64, ptr %24, align 1, !tbaa !7
  %29 = load i64, ptr %12, align 1, !tbaa !7
  %30 = xor i64 %29, %28
  %31 = icmp ult i32 %21, 65
  br i1 %31, label %32, label %38

32:                                               ; preds = %27
  %33 = tail call i64 @llvm.bswap.i64(i64 %30)
  %34 = sub nuw nsw i32 64, %21
  %35 = zext nneg i32 %34 to i64
  %36 = lshr i64 %33, %35
  %37 = icmp eq i64 %36, 0
  br i1 %37, label %103, label %126

38:                                               ; preds = %27
  %39 = icmp eq i64 %30, 0
  br i1 %39, label %40, label %126

40:                                               ; preds = %38
  %41 = add i32 %21, -64
  br label %42

42:                                               ; preds = %40, %26
  %43 = phi i64 [ 8, %40 ], [ 0, %26 ]
  %44 = phi i32 [ %41, %40 ], [ %21, %26 ]
  %45 = sub i64 %4, %43
  %46 = icmp ugt i64 %45, 3
  br i1 %46, label %47, label %68

47:                                               ; preds = %42, %63
  %48 = phi i32 [ %64, %63 ], [ %44, %42 ]
  %49 = phi i64 [ %65, %63 ], [ %43, %42 ]
  %50 = getelementptr inbounds i8, ptr %24, i64 %49
  %51 = load i32, ptr %50, align 1, !tbaa !7
  %52 = getelementptr inbounds i8, ptr %12, i64 %49
  %53 = load i32, ptr %52, align 1, !tbaa !7
  %54 = xor i32 %53, %51
  %55 = icmp ult i32 %48, 33
  br i1 %55, label %56, label %61

56:                                               ; preds = %47
  %57 = tail call i32 @llvm.bswap.i32(i32 %54)
  %58 = sub nuw nsw i32 32, %48
  %59 = lshr i32 %57, %58
  %60 = icmp eq i32 %59, 0
  br i1 %60, label %103, label %126

61:                                               ; preds = %47
  %62 = icmp eq i32 %54, 0
  br i1 %62, label %63, label %126

63:                                               ; preds = %61
  %64 = add i32 %48, -32
  %65 = add nuw nsw i64 %49, 4
  %66 = sub i64 %4, %65
  %67 = icmp ugt i64 %66, 3
  br i1 %67, label %47, label %68, !llvm.loop !10

68:                                               ; preds = %63, %42
  %69 = phi i64 [ %43, %42 ], [ %65, %63 ]
  %70 = phi i32 [ %44, %42 ], [ %64, %63 ]
  %71 = phi i64 [ %45, %42 ], [ %66, %63 ]
  %72 = icmp ugt i64 %71, 1
  br i1 %72, label %73, label %85

73:                                               ; preds = %68
  %74 = getelementptr inbounds i8, ptr %24, i64 %69
  %75 = load i16, ptr %74, align 1, !tbaa !7
  %76 = getelementptr inbounds i8, ptr %12, i64 %69
  %77 = load i16, ptr %76, align 1, !tbaa !7
  %78 = xor i16 %77, %75
  %79 = icmp ult i32 %70, 17
  br i1 %79, label %97, label %80

80:                                               ; preds = %73
  %81 = icmp eq i16 %78, 0
  br i1 %81, label %82, label %126

82:                                               ; preds = %80
  %83 = add i32 %70, -16
  %84 = or disjoint i64 %69, 2
  br label %85

85:                                               ; preds = %82, %68
  %86 = phi i64 [ %84, %82 ], [ %69, %68 ]
  %87 = phi i32 [ %83, %82 ], [ %70, %68 ]
  %88 = getelementptr inbounds i8, ptr %24, i64 %86
  %89 = load i8, ptr %88, align 1, !tbaa !7
  %90 = getelementptr inbounds i8, ptr %12, i64 %86
  %91 = load i8, ptr %90, align 1, !tbaa !7
  %92 = xor i8 %91, %89
  %93 = zext i8 %92 to i32
  %94 = sub i32 8, %87
  %95 = lshr i32 %93, %94
  %96 = icmp eq i32 %95, 0
  br i1 %96, label %103, label %126

97:                                               ; preds = %73
  %98 = tail call i16 @llvm.bswap.i16(i16 %78)
  %99 = zext i16 %98 to i32
  %100 = sub nuw nsw i32 16, %70
  %101 = lshr i32 %99, %100
  %102 = icmp eq i32 %101, 0
  br i1 %102, label %103, label %126

103:                                              ; preds = %56, %32, %85, %23, %97
  %104 = zext i32 %21 to i64
  %105 = icmp eq i64 %6, %104
  br i1 %105, label %126, label %106

106:                                              ; preds = %103
  %107 = getelementptr inbounds i8, ptr %18, i64 20
  %108 = load i32, ptr %107, align 1, !tbaa !7
  %109 = and i32 %108, 1
  %110 = icmp eq i32 %109, 0
  %111 = select i1 %110, ptr %18, ptr %19
  %112 = lshr i32 %21, 3
  %113 = zext nneg i32 %112 to i64
  %114 = getelementptr i8, ptr %12, i64 %113
  %115 = load i8, ptr %114, align 1, !tbaa !7
  %116 = zext i8 %115 to i32
  %117 = and i32 %21, 7
  %118 = xor i32 %117, 7
  %119 = lshr i32 %116, %118
  %120 = shl nuw nsw i32 %119, 3
  %121 = and i32 %120, 8
  %122 = zext nneg i32 %121 to i64
  %123 = getelementptr inbounds i8, ptr %18, i64 %122
  %124 = load volatile ptr, ptr %123, align 8, !tbaa !8
  %125 = icmp eq ptr %124, null
  br i1 %125, label %126, label %17

126:                                              ; preds = %106, %97, %17, %103, %38, %80, %85, %32, %56, %61, %10
  %127 = phi ptr [ null, %10 ], [ %19, %61 ], [ %19, %56 ], [ %19, %32 ], [ %19, %85 ], [ %111, %106 ], [ %19, %97 ], [ %19, %17 ], [ %18, %103 ], [ %19, %38 ], [ %19, %80 ]
  %128 = icmp eq ptr %127, null
  %129 = getelementptr inbounds i8, ptr %127, i64 24
  %130 = getelementptr inbounds i8, ptr %129, i64 %4
  %131 = select i1 %128, ptr null, ptr %130
  br label %132

132:                                              ; preds = %2, %126
  %133 = phi ptr [ %131, %126 ], [ null, %2 ]
  ret ptr %133
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.bswap.i64(i64) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.bswap.i32(i32) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.bswap.i16(i16) #1

attributes #0 = { nofree norecurse nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+reserve-x26,+v8a,-fmv,-fp-armv8,-neon,-outline-atomics" "tune-cpu"="neoverse-n1" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.module.flags = !{!0, !1}
!llvm.ident = !{!2}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!3 = !{!4, !4, i64 0}
!4 = !{!"long", !5, i64 0}
!5 = !{!"omnipotent char", !6, i64 0}
!6 = !{!"Simple C/C++ TBAA"}
!7 = !{!5, !5, i64 0}
!8 = !{!9, !9, i64 0}
!9 = !{!"any pointer", !5, i64 0}
!10 = distinct !{!10, !11}
!11 = !{!"llvm.loop.mustprogress"}
