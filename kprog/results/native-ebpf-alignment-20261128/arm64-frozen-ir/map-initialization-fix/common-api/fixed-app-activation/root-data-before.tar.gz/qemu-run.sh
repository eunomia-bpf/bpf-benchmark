#!/bin/sh
set -eu
mount -t tmpfs tmpfs /run
mount -t tmpfs tmpfs /tmp
mount -t tmpfs tmpfs /var/tmp
depmod
insmod /artifacts/kinsn/bpf_arm64_native_lab.ko
echo 1 > /proc/sys/kernel/bpf_stats_enabled
unset BPFREJIT_NATIVE_LOADER_REQUIRE_BOUND_PROOF
export BPFREJIT_INSIDE_RUNTIME_CONTAINER=1 HOME=/root PATH=/usr/lib/llvm-18/bin:$PATH TARGET=arm64-qemu RUN_TARGET_NAME=arm64-qemu RUN_TARGET_ARCH=arm64 RUN_EXECUTOR=kvm RUNTIME_CONTAINER_IMAGE=bpf-benchmark/runner-runtime:arm64 RUNTIME_IMAGE_TAR=/workspaces/repository/.cache/container-images/arm64-runner-runtime.image.tar RUN_REMOTE_PYTHON_BIN=python3 RUN_RUNTIME_PYTHON_BIN=python3 RUN_BPFTOOL_BIN=bpftool RUN_NATIVE_REPOS_CSV=bcc,katran,tracee,tetragon RUN_TOKEN=a84c8347 SAMPLES=1 WORKLOAD_DURATION=10 BPFREJIT_CORPUS_APPS=otelcol-ebpf-profiler/profiling BPFREJIT_CORPUS_BPF_STATS=1 BPFREJIT_SHIM_NATIVE_LOADER=post BPFREJIT_SHIM_NATIVE_MANIFEST=/opt/bpf-benchmark/native-bpf/arm64/otelcol-ebpf-profiler/manifest.json BPFREJIT_NATIVE_LOADER_SO=/usr/local/lib/bpfrejit/libnative_loader.so KEEP_WORKDIRS=all BPFREJIT_KEEP_ALL_WORKDIRS=1 SKIP_REJIT=norejit ETCD_UNSUPPORTED_ARCH=arm64
exec python3 -m corpus.driver
