from pathlib import Path
import os,select,subprocess
G=Path(__file__).parent
for receipt in ['/workspaces/.agent-state/kprog-lanes/C/design-only/remaining-apps/cilium-live-data-end/queue.pid',str(G/'loader.pid'),str(G/'probe.pid')]:
 try:
  fd=os.pidfd_open(int(Path(receipt).read_text()));select.select([fd],[],[]);os.close(fd)
 except ProcessLookupError:pass
with(G/'replay.log').open('wb')as log:q=subprocess.run(['make','-f',str(G/'Makefile'),'replay'],stdout=log,stderr=subprocess.STDOUT,cwd='/workspaces/repository')
(G/'replay.exit').write_text(str(q.returncode)+'\n')
