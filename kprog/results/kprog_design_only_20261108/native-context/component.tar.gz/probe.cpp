#include "/workspaces/repository/kprog/libnativeloader/include/native_loader.hpp"
#include <bpf/bpf.h>
#include <bpf/libbpf.h>
#include <cerrno>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <memory>
#include <stdexcept>
using Object=std::unique_ptr<bpf_object,decltype(&bpf_object__close)>;
static void check_result(int fd,uint64_t expected,uint32_t expected_retval,const char *runtime)
{
    unsigned char input[64]={},output[256]={};
    bpf_test_run_opts run{};
    run.sz=sizeof(run);run.data_in=input;run.data_size_in=sizeof(input);
    run.data_out=output;run.data_size_out=sizeof(output);run.repeat=1;
    if (bpf_prog_test_run_opts(fd,&run)) throw std::runtime_error("BPF_PROG_TEST_RUN failed: "+std::string(std::strerror(errno)));
    if (run.data_size_out<8) throw std::runtime_error("short packet result");
    uint64_t actual;
    std::memcpy(&actual,output,sizeof(actual));
    std::printf("%s result=%llu retval=%u expected_result=%llu expected_retval=%u\n",runtime,
        (unsigned long long)actual,run.retval,(unsigned long long)expected,expected_retval);
    if (actual!=expected || run.retval!=expected_retval) throw std::runtime_error("workload result mismatch");
}
int main(int argc,char **argv)
{
    if (argc!=3 && argc!=5) return 2;
    try {
        Object object(bpf_object__open_file(argv[1],nullptr),bpf_object__close);
        if (!object) throw std::runtime_error("open resource object failed");
        bpf_program *program=bpf_object__next_program(object.get(),nullptr);
        const auto type=bpf_program__type(program);
        bpf_program *p;
        bpf_object__for_each_program(p,object.get())
            if (bpf_program__set_autoload(p,false)) throw std::runtime_error("disable original program load failed");
        if (bpf_object__load(object.get())) throw std::runtime_error("load resource maps failed");
        native_loader::FdLoadOptions options{};
        bpf_prog_info context{};context.type=type;context.gpl_compatible=1;
        options.native_context=context;
        options.native_object_path=std::filesystem::absolute(argv[2]);options.symbol_name="entry";
        options.native_link_path="/workspaces/.agent-state/kprog-lanes/C/design-only/native-link";
        bpf_map *map;
        bpf_object__for_each_map(map,object.get()) {
            bpf_map_info info{};uint32_t size=sizeof(info);
            if (bpf_obj_get_info_by_fd(bpf_map__fd(map),&info,&size)) throw std::runtime_error("query resource map failed");
            options.trusted_maps.push_back({bpf_map__name(map),info.id,std::nullopt});
        }
        auto loaded=native_loader::load_from_fd(options);
        std::printf("native program id=%u source_prog_id=%u\n",loaded.native_prog_id,loaded.original_prog_id);
        if (argc==5) check_result(loaded.prog_fd,std::strtoull(argv[3],nullptr,0),std::strtoul(argv[4],nullptr,0),"native_raw_context");
        native_loader::close_loaded_program(&loaded);
        if (std::fflush(stdout)) throw std::runtime_error("flush probe output failed");
    } catch (const std::exception &error) {
        std::fprintf(stderr,"raw-probe: %s\n",error.what());return 1;
    }
    return 0;
}
