from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,hashlib,os,tarfile
D=Path(__file__).resolve().parent.parent;A=D/'apps';R=Path('/workspaces/repository')
# Refresh the cached module objects and loader for the final source epoch.
with (A/'module-build.log').open('wb') as log:
 subprocess.run(['taskset','-c','20-23','sh',str(D/'all-modules.sh')],stdout=log,stderr=subprocess.STDOUT,check=True)
files=set(json.loads((D/'before.json').read_text()))|{'kprog/x86/x86_sim_local_bpf.h','kprog/trusted_loader.cpp','kprog/fidelity/bound_probe.cpp'}
record=dict(started=datetime.now(timezone.utc).isoformat(),apps='bcc/set,katran',source_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),source_sha256={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in sorted(files)if(R/n).is_file()},cpus='20-23',vcpus=4,guest_memory='8G',samples=1,duration=2)
(A/'inputs.json').write_text(json.dumps(record,indent=2)+'\n')
with (A/'run.log').open('wb') as log:
 p=subprocess.run(['taskset','-c','20-23','sh',str(A/'run.sh')],stdout=log,stderr=subprocess.STDOUT)
(A/'controller.exit').write_text(str(p.returncode)+'\n')
