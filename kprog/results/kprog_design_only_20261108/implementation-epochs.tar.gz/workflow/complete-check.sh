set -eu
D=/workspaces/.agent-state/kprog-lanes/C/design-only
trap 'echo $? > "$D/complete-check.exit"' EXIT
cd /workspaces/repository
sh "$D/loader-build.sh"
make -f "$D/Makefile" safety-complete
