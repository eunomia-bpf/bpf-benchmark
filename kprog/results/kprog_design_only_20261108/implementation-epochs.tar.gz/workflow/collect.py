from pathlib import Path
from datetime import datetime,timezone
import json,tarfile,io,hashlib,collections,subprocess,shutil
R=Path('/workspaces/repository');D=Path(__file__).parent;A=D/'apps';O=R/'kprog/results/kprog_design_only_20261108';O.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=json.loads((A/'summary.json').read_text());root=Path(s['corpus_metadata'][0]['path']).parent;programs=[]
with tarfile.open(A/s['archive'])as t:
 rows=[json.loads(l)for l in t.extractfile('corpus/requests/requests.jsonl').read().splitlines()]
 for row in rows:
  archive=Path(row.get('artifact_archive',row.get('failure_archive'))).name
  with tarfile.open(fileobj=io.BytesIO(t.extractfile('corpus/requests/'+archive).read()))as q:
   names=set(q.getnames());native=q.extractfile('request/kernel.native.o').read();meta=json.loads(q.extractfile('request/kernel.metadata.json').read());entry=q.extractfile('request/kernel.entry').read().decode()
   programs.append(dict(row,entry=entry,prog_type=meta['load_context']['prog_type'],native_sha256_observed=hashlib.sha256(native).hexdigest(),generated='request/generated/trusted_x86.bpf.c'in names,compiled='request/generated/trusted_x86.bpf.o'in names))
apps={}
for p in sorted((root/'details/apps').glob('*.json')):
 d=json.loads(p.read_text());name=d['app'];count=sum(('katran'in r['entry'].lower()or r['native_sha256'].startswith('ba252e0372d1'))==(name=='katran')for r in programs)
 item=dict(status=d['status'],error=d.get('error'),native_programs=count)
 if name=='katran':
  for phase in ['baseline','post_rejit']:
   w=d[phase]['workloads'][0];out=w['config']['outcomes'];item[phase]=dict(workload_returncode=w['returncode'],counters=out['delta']['counters'],receiver=out['delta']['receiver'],interfaces=out['delta']['interfaces'])
 else:
  for phase in ['baseline','post_rejit']:
   item[phase]=dict(workload_returncodes=[w['returncode']for w in d[phase]['workloads']],bpf=d[phase]['bpf'])
 apps[name]=item
observations=dict(collected=datetime.now(timezone.utc).isoformat(),result=str(root),metadata=s['corpus_metadata'][0],apps=apps,service_counts=dict(requests=len(programs),generated=sum(p['generated']for p in programs),compiled=sum(p['compiled']for p in programs),verifier_accepted_native_installed=sum(p['status']==0 for p in programs)),programs=programs,safety={},build_exits={},binary_sha256={},source_epochs=dict(initial_controller_launch=(json.loads((A/'inputs.json').read_text())if(A/'inputs.json').exists()else{}),kernel_base=(D/'kernel-base-commit').read_text().strip()),review_case='COORDINATION Notices records direct kinsn ingress scope for operator decision; extra admission checks await approval')
for label,path in [('first',D/'safety/results/outcomes.json'),('final_kernel',D/'safety/final/outcomes.json'),('complete',D/'safety/complete/outcomes.json')]:
 if path.exists():
  rs=json.loads(path.read_text());observations['safety'][label]=dict(cases=len(rs),stages=dict(collections.Counter(r['stage']for r in rs)),accepted_dangerous=sum(r['stage']=='accepted_finding'for r in rs))
for n in ['build.exit','all-modules.exit','runtime-modules.exit','loader-build.exit','refresh-kernel.exit','safety-run.exit','safety-final.exit','complete-check.exit']:
 if(D/n).exists():observations['build_exits'][n]=int((D/n).read_text())
for n in ['build/arch/x86/boot/bzImage','module/bpf_x86_native_lab.ko','loader/libnative_loader.so','loader/trusted-native-loader','libbpfrejit_shim.so','native-link']:
 if(D/n).is_file():observations['binary_sha256'][n]=sha(D/n)
observations['application_image']=json.loads(subprocess.check_output(['docker','image','inspect','bpf-benchmark/kprog-design-only:c-20261108'],text=True))[0]
observations['current_source_sha256']={n:sha(R/n)for n in sorted(json.loads((D/'refusal-audit.json').read_text())['baseline_sha256'])if(R/n).is_file()}
(O/'observations.json').write_text(json.dumps(observations,indent=2)+'\n')
# Keep actual app-side work and per-program counters in their original files.
with tarfile.open(O/'application-results.tar.gz','w:gz',compresslevel=3)as t:t.add(root,arcname='result')
shutil.copy2(A/s['archive'],O/'application-service.tar.gz')
with tarfile.open(O/'safety-results.tar.gz','w:gz',compresslevel=3)as t:
 t.add(D/'safety',arcname='safety')
 for p in D.glob('*safety*.log'):t.add(p,arcname='logs/'+p.name)
 if(D/'complete-check.log').exists():t.add(D/'complete-check.log',arcname='logs/complete-check.log')
with tarfile.open(O/'implementation-epochs.tar.gz','w:gz',compresslevel=3)as t:
 t.add(D/'before',arcname='baseline')
 for n in ['before.json','refusal-audit.json','removed-files.json','x86_abi.before-noop-retirement.py','audit.py','collect.py','inside-build.sh','build.sh','inside-all-modules.sh','all-modules.sh','inside-runtime-modules.sh','runtime-modules.sh','refresh-kernel.sh','Makefile','complete-check.sh','retired-cache.json','kernel-base-commit']:
  if(D/n).exists():t.add(D/n,arcname='workflow/'+n)
 for p in sorted(D.glob('*.log')):t.add(p,arcname='workflow/'+p.name)
 for p in sorted(D.glob('*.exit')):t.add(p,arcname='workflow/'+p.name)
 for p in (D/'kernel-source').rglob('*'):
  if p.is_file():t.add(p,arcname='kernel-source/'+str(p.relative_to(D/'kernel-source')))
 t.add(A,arcname='runtime',filter=lambda m:None if any(x in m.name for x in ['var-tmp','runtime.image.tar','kernel-modules','trusted-','.live-','corpus-'])else m)
 t.add(D/'apps-attempt-1',arcname='application-setup-epoch')
with tarfile.open(O/'kernel-loader-artifacts.tar.gz','w:gz',compresslevel=3)as t:
 for n in observations['binary_sha256']:t.add(D/n,arcname=n)
 t.add(D/'build/.config',arcname='kernel.config')
 for p in (D/'all-modules').glob('*.ko'):t.add(p,arcname='kinsn/'+p.name)
# The runtime wiring stays beside the evidence; its retained state paths reuse caches.
P=O/'runtime';P.mkdir(exist_ok=True)
for n in ['Makefile','guest.py','Dockerfile','run.sh','retry.sh']:shutil.copy2(A/n,P/n)
observations['artifact_sizes']={p.name:p.stat().st_size for p in O.iterdir()if p.is_file()};(O/'observations.json').write_text(json.dumps(observations,indent=2)+'\n')
print(json.dumps(dict(result=str(root),apps={n:d['status']for n,d in apps.items()},service=observations['service_counts'],safety=observations['safety'],artifact_sizes=observations['artifact_sizes']),indent=2),flush=True)
