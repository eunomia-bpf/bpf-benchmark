set -eu
D=/workspaces/.agent-state/kprog-lanes/C/design-only
R=/workspaces/repository
mount --bind "$D/build" "$R/kprog/tv/build-kernel-x86"
find "$D/kernel-source" -type f | while IFS= read -r source; do
 relative=${source#"$D/kernel-source/"}
 mount --bind "$source" "$R/vendor/linux-framework/$relative"
done
make -C "$R/vendor/linux-framework" O="$R/kprog/tv/build-kernel-x86" ARCH=x86 -j4 bzImage modules_prepare
cp "$D/build/vmlinux.symvers" "$D/build/Module.symvers"
cp "$R/kinsn/module/x86/bpf_x86_native_lab.c" "$D/module/bpf_x86_native_lab.c"
make -C "$D/build" M="$D/module" MO="$D/module-output" ARCH=x86 -j4 modules
cp "$D/module-output/bpf_x86_native_lab.ko" "$D/module/bpf_x86_native_lab.ko"
