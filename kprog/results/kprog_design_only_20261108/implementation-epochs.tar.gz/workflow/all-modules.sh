set -eu
D=/workspaces/.agent-state/kprog-lanes/C/design-only
R=/workspaces/repository
trap 'echo $? > "$D/all-modules.exit"' EXIT
unshare --mount --propagation private sh "$D/inside-all-modules.sh"
