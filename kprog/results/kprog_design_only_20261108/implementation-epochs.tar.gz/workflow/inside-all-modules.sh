set -eu
D=/workspaces/.agent-state/kprog-lanes/C/design-only
R=/workspaces/repository
mount --bind "$D/build" "$R/kprog/tv/build-kernel-x86"
find "$D/kernel-source" -type f | while IFS= read -r source; do
 relative=${source#"$D/kernel-source/"}
 mount --bind "$source" "$R/vendor/linux-framework/$relative"
done
make -C "$D/build" M="$R/kinsn/module/x86" MO="$D/all-modules" ARCH=x86 -j4 modules
