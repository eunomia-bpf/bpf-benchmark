set -eu
D=/workspaces/.agent-state/kprog-lanes/C/design-only
R=/workspaces/repository
mount --bind "$D/build" "$R/kprog/tv/build-kernel-x86"
find "$D/kernel-source" -type f | while IFS= read -r source; do
 relative=${source#"$D/kernel-source/"}
 mount --bind "$source" "$R/vendor/linux-framework/$relative"
done
make -C "$R/vendor/linux-framework" O="$R/kprog/tv/build-kernel-x86" ARCH=x86 -j4 modules
make -C "$R/vendor/linux-framework" O="$R/kprog/tv/build-kernel-x86" ARCH=x86 INSTALL_MOD_PATH="$D/runtime-modules" INSTALL_MOD_STRIP=1 DEPMOD=true modules_install
depmod -b "$D/runtime-modules" "$(cat "$D/build/include/config/kernel.release")"
