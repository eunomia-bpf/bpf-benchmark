set -eu
D=/workspaces/.agent-state/kprog-lanes/C/design-only
trap 'echo $? > "$D/refresh-kernel.exit"' EXIT
unshare --mount --propagation private sh "$D/inside-build.sh"
sha256sum "$D/build/arch/x86/boot/bzImage" "$D/build/vmlinux" "$D/module/bpf_x86_native_lab.ko" > "$D/final-outputs.sha256"
