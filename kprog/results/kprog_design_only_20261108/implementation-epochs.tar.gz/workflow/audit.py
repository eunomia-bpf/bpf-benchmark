from pathlib import Path
import ast,re,json,hashlib,difflib,subprocess
R=Path('/workspaces/repository');D=Path(__file__).parent;O=R/'kprog/results/kprog_design_only_20261108';O.mkdir(exist_ok=True)
# Include transitive loader parsers in the same refusal inventory.
for p in sorted((R/'kprog/libnativeloader/src').glob('*.hpp')):
 q=D/'before'/p.relative_to(R)
 if not q.exists():q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
removed_files=set(json.loads((D/'removed-files.json').read_text()))
removed_functions={'native_lab_binding_validate','native_lab_binding_use','native_lab_binding_snapshot','native_lab_context_matches','native_lab_pin_context','native_lab_readonly_data','native_lab_group_metadata','native_lab_group_prepare','native_lab_exclusive_environment','native_lab_group_use','native_lab_group_program','native_lab_validate_program','native_lab_map_operation_target','native_lab_map_helper_target','native_lab_validate_proof','native_lab_trusted_writer_locked','native_lab_trusted_writer','native_lab_trusted_authorized','native_lab_trusted_seal','native_lab_advance_generation','blob_write','relocs_write','proof_write','binding_write','generation_read','read_blob_generation','seal_bound_chunk','upload_bound_proofs','upload_reloc_chunk','upload_relocs','upload_blob','upload_proof_chunk','validate_job','shim_native_loader_check_bound_abi','NativeLabUploadLock'}
policy_words=['snapshot_generation','generation !=','generation ==','!generation','source interface mismatch','source context mismatch','kernel map shape mismatch','requires exactly','requires only','exact typed','version must','fields differ from','identity changed','canonical files','same generated request','source and architecture','fresh output path','compiler source must belong','invalid source load context version','native resource query version','nonzero-generation','bound-proof-abi','so-switch','differs from bound native symbol','original-program identity','map layout does not match','readonly proof data does not match','readonly map size differs']
rows=[];basehash={}
for p in sorted((D/'before').rglob('*')):
 if not p.is_file()or p.suffix not in {'.h','.hpp','.c','.cpp','.py','.patch'}:continue
 name=str(p.relative_to(D/'before'));text=p.read_text();lines=text.splitlines();basehash[name]=hashlib.sha256(p.read_bytes()).hexdigest();current=(R/name).read_text()if(R/name).is_file()else''
 # Python AST gives precise function scopes; C declarations cover multiline signatures.
 spans=[]
 if p.suffix=='.py':
  try:spans=[(n.lineno,n.end_lineno,n.name)for n in ast.walk(ast.parse(text))if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))]
  except SyntaxError:pass
 else:
  for m in re.finditer(r'(?m)^(?:static\s+)?(?:inline\s+)?(?:extern\s+"C"\s+)?(?:[\w:<>,*&]+\s+)+([A-Za-z_]\w*)\s*\([^;{}]*\)\s*\{',text):
   start=text[:m.start()].count('\n')+1;spans.append((start,len(lines),m.group(1)))
  spans=[(a,spans[i+1][0]-1 if i+1<len(spans)else len(lines),f)for i,(a,_,f)in enumerate(spans)]
 for i,line in enumerate(lines,1):
  if p.suffix=='.patch'and line.startswith(('-', 'diff ', 'index ', '@@')):continue
  if not re.search(r'\breturn\s*-|\b(?:fail|json_fail|raise|exit)\s*\(|\braise\s+(?:ValueError|RuntimeError|SystemExit)|shim_native_loader_fatal(?:_reason)?\(|result.update\(returncode=1|\berr\s*=\s*-[A-Z]',line):continue
  if re.search(r'^(?:static |inline |\[\[noreturn\]\])',line.strip())and'{'not in line:continue
  active=[t for t in spans if t[0]<=i<=t[1]];fn=min(active,key=lambda t:t[1]-t[0])[2]if active else 'file'
  context='\n'.join(lines[max(0,i-7):i+2]);drop=name in removed_files or fn in removed_functions
  if name.endswith('x86_abi.py')and'ABI CFG target'not in line:drop=True
  if any(w in line for w in policy_words):drop=True
  if name.endswith('bpf_x86_native_lab.c')and fn=='map_ptr_query_write'and'capable(CAP_SYS_ADMIN)'in context:drop=True
  if name.endswith('native_lab_trusted.h')and any(w in context for w in ['submission.reserved','map_count > MAX_USED_MAPS','request.version !=','memchr(capsule->entry','memcmp(elf->e_ident','native_lab_service_worker &&','result.reserved','!prog->jited','shape.reserved','native_lab_service_ever']):drop=True
  if name.endswith('trusted_generation.py')and any(w in context for w in ['set(metadata)','set(item) -','map_type"] == 0','value_offset") >=','is_outer !=']):drop=True
  # Deletions in mixed functions are recognized by their diagnostic text.
  quoted=re.findall(r'"([^"\n]{10,})"|\'([^\'\n]{10,})\'',line)
  diagnostic=next((a or b for a,b in quoted),None)
  if diagnostic and diagnostic not in current and fn not in {'file','main'}:drop=True
  if drop:decision='remove';step='outside a?e';purpose='policy or comparison removed'
  elif 'trusted' in name and ('request_id' in context or fn in {'native_lab_trusted_activate','native_lab_active_capsule','native_lab_trusted_complete','next_request','ioctl'}):decision='keep';step='b, c';purpose='request matching and queue lifecycle'
  elif any(w in context for w in ['copy_from_user','copy_to_user','memdup','kzalloc','kmalloc','kcalloc','GFP_KERNEL','-ENOMEM','-EFAULT']):decision='keep';step='b';purpose='copy, allocation and lifetime'
  elif 'CAP_SYS_ADMIN' in context:decision='keep';step='c';purpose='registered service capability'
  elif name.endswith(('generate_micro_sim_proofs.py','x86_abi.py','trusted_generation.py')):decision='keep';step='c';purpose='instruction, ELF or finite-target decoding'
  elif name.endswith(('trusted_service.py','trusted_compile.py')):decision='keep';step='c';purpose='generation, compiler or IO completion'
  else:decision='keep';step='a, e';purpose='input decoding, symbol/relocation resolution or IO'
  rows.append(dict(path=name,line=i,function=fn,decision=decision,step=step,purpose=purpose))
# Actual kernel refusal paths are inventoried against the applied pre-change source.
p=D.parent/'kernel-kfunc-binding/verifier.registered.c';before=p.read_text().splitlines();new=(D/'kernel-source/kernel/bpf/verifier.c').read_text()
fn='file'
for i,l in enumerate(before,1):
 if l.startswith('static ')and'('in l:fn=l.split('(')[0].split()[-1].lstrip('*')
 if fn not in {'validate_kinsn_proof_seq','lower_kinsn_proof_regions','restore_kinsn_proof_regions','check_native_input'}or not re.search(r'return\s*-|return err;',l):continue
 drop=fn in {'validate_kinsn_proof_seq','restore_kinsn_proof_regions','check_native_input'}
 if fn=='check_native_input'and'check_reg_arg' in '\n'.join(before[max(0,i-5):i]):drop=False
 if fn=='lower_kinsn_proof_regions'and any(x in '\n'.join(before[max(0,i-4):i])for x in ['validate_native_program','native_stack_depth >']):drop=True
 rows.append(dict(path='kernel/bpf/verifier.c (applied baseline)',line=i,function=fn,decision='remove'if drop else'keep',step='outside a?e'if drop else'd, e',purpose='native B uses stock verifier; slice descriptors retain their decoder'))
counts={d:sum(r['decision']==d for r in rows)for d in ['keep','remove']}
(D/'refusal-audit.json').write_text(json.dumps(dict(baseline_sha256=basehash,sites=rows,counts=counts),indent=2)+'\n')
readme='''# Design-only trusted native path, 2026-11-08

The five steps are (a) submit P as native bytes, relocations and metadata; (b) retain one kernel copy; (c) the registered service generates and compiles B from that copy; (d) the stock verifier analyzes B; (e) the JIT emits the copy through ordinary link resolution.

Safety has two facts: the stock verifier accepts B, and B faithfully simulates P through universal O1/O2 and O4 link preservation. Steps b?e use one kernel copy, so the installed program is the program B simulates.

## Shared implementation

The registered service creates immutable request-owned chunks through `TRUSTED_CHUNK`. Each handle names one allocation throughout its lifetime. The request retains its ELF/metadata and resources; installed programs retain their request and linked chunks. Copy/allocation failures, service registration capability, request/reply matching, ordinary map/helper/kfunc/relocation resolution, stock verification and JIT emission remain.

Remove decisions cover public blob/relocs/proof/binding/generation writers; binding envelopes and generation vectors; B/P, group, program and context comparisons; worker TGID and boot-lifetime registration pinning; transport versions/flags/reserved refusals and map-count policy caps; exact-key schemas and compiler identity guards; specialization ABI admission refusals; readonly/exclusive matching metadata and their audit fixtures. ABI unspecified entry state and helper caller-clobbers are represented in B as unconstrained architectural values. Stack extent and finite return-site collection continue to supply the representation.

## Refusal inventory

The baseline snapshots and SHA256 ledger identify each source epoch. The appendix assigns each explicit refusal expression a decision and the design step served by each keep. Rewritten functions relocate copy/allocation and lifecycle handling into immutable storage. The native branch of the kernel sequence expander passes B to stock verification; ordinary helper/kfunc resolution supplies the required link information.

'''
readme+=f'The inventory contains {len(rows)} sites: {counts["keep"]} keep and {counts["remove"]} remove decisions. C owns the shared and x86 implementation, A owns the arm64 module port, and V owns theorem-row cleanup.\n\n'
readme+='''## Validation

The incremental kernel, native module, matching module set, loader and shim builds complete. Kernel patch application/idempotence/conflict checks and eight retained service checks pass. The first native-only safety replay executes nine valid controls and records 29 pre-execution refusals with zero accepted dangerous cases. BCC and Katran whole-application replays use the simplified path; terminal receipts provide their counts and workload results.

Commands and raw outputs are retained with the result. The corpus protocol uses its existing two-start workload with one sample of two seconds, on CPUs20?23. These runs provide functional evidence.

## Baseline refusal appendix

| Baseline source line | Function | Decision | Design step | Purpose |
| --- | --- | --- | --- | --- |
'''
for r in rows:readme+='| `'+r['path']+':'+str(r['line'])+'` | `'+r['function']+'` | '+r['decision']+' | '+r['step']+' | '+r['purpose']+' |\n'
(O/'README.md').write_text(readme);print('REFUSAL_DECISIONS',len(rows),counts)
