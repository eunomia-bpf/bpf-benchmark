set -eu
D=/workspaces/.agent-state/kprog-lanes/C/design-only
trap 'echo $? > "$D/runtime-modules.exit"' EXIT
unshare --mount --propagation private sh "$D/inside-runtime-modules.sh"
