set -eu
D=/workspaces/.agent-state/kprog-lanes/C/design-only
R=/workspaces/repository
trap 'echo $? > "$D/build.exit"' EXIT
install -d "$D/build"
rsync -aS --exclude='/.modules-install.*/' --exclude='/modules-install/' --exclude='/.virtme_mods/' "$R/kprog/tv/build-kernel-x86/" "$D/build/"
unshare --mount --propagation private sh "$D/inside-build.sh"
sha256sum "$D/build/arch/x86/boot/bzImage" "$D/build/vmlinux" "$D/module/bpf_x86_native_lab.ko" > "$D/outputs.sha256"
