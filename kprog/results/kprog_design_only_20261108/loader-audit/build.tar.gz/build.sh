#!/bin/bash
cd /workspaces/repository
taskset -c 8-11 make -C kprog/libnativeloader trusted-service-check BUILD_DIR=/workspaces/.agent-state/kprog-lanes/C/design-only/loader-audit/build >/workspaces/.agent-state/kprog-lanes/C/design-only/loader-audit/build.log 2>&1
rc=$?
printf "%s\n" "$rc" >/workspaces/.agent-state/kprog-lanes/C/design-only/loader-audit/build.exit
exit "$rc"
