set -eu
cd /workspaces/repository
taskset -c 8-11 cmake --build kprog/libnativeloader/build --target native_loader native_loader_shared trusted-native-loader trusted-service-client -j2
PYTHONDONTWRITEBYTECODE=1 python3 kprog/test/check_trusted_service.py
PYTHONDONTWRITEBYTECODE=1 python3 kprog/test/check_trusted_worker.py
