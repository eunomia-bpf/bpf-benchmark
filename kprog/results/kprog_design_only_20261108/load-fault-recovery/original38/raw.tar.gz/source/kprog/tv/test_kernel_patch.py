"""Catch --batch auto-reversing an applied patch and partial conflict mutation."""
from pathlib import Path
import subprocess
import re
import tempfile

from apply_kernel_patch import apply

here = Path(__file__).resolve().parent
base = subprocess.run(["git", "show", "HEAD:kernel/bpf/verifier.c"],
                      cwd=here.parents[1] / "vendor/linux-framework",
                      check=True, capture_output=True).stdout
patch = (here / "native-proof-regions.patch").read_bytes()
with tempfile.TemporaryDirectory() as directory:
    kernel = Path(directory)
    source = kernel / "kernel/bpf/verifier.c"
    source.parent.mkdir(parents=True)
    source.write_bytes(base)
    header = kernel / "include/linux/bpf.h"
    header.parent.mkdir(parents=True)
    header.write_bytes(subprocess.run(["git", "show", "HEAD:include/linux/bpf.h"],
        cwd=here.parents[1] / "vendor/linux-framework", check=True, capture_output=True).stdout)
    for name in ("include/linux/bpf_verifier.h", "kernel/bpf/core.c", "kernel/bpf/syscall.c", "kernel/bpf/btf.c", "kernel/bpf/offload.c", "arch/x86/net/bpf_jit_comp.c",
                 "arch/arm64/net/bpf_jit_comp.c", "include/linux/lsm_hook_defs.h"):
        target = kernel / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(subprocess.run(["git", "show", "HEAD:" + name],
            cwd=here.parents[1] / "vendor/linux-framework", check=True, capture_output=True).stdout)
    native_input = subprocess.run(["git", "show", "HEAD:include/linux/bpf_native_input.h"],
        cwd=here.parents[1] / "vendor/linux-framework", capture_output=True)
    if native_input.returncode == 0:
        (kernel / "include/linux/bpf_native_input.h").write_bytes(native_input.stdout)
    reverse = ["patch", "--batch", "--force", "--no-backup-if-mismatch", "-p1", "-d", str(kernel), "--reverse"]
    # Kernel HEAD can contain the preceding patch version. Normalize only this
    # temporary fixture by reversing each already-applied file patch; production
    # apply() must still reject every partially applied/conflicting whole patch.
    for file_patch in re.split(rb"(?=^diff --git )", patch, flags=re.MULTILINE):
        if not file_patch.startswith(b"diff --git "):continue
        if subprocess.run(reverse + ["--dry-run"], input=file_patch, capture_output=True).returncode == 0:
            subprocess.run(reverse, input=file_patch, check=True, capture_output=True)
    base = source.read_bytes()
    apply(kernel, patch)
    assert (kernel / "include/linux/bpf_native_input.h").read_bytes() == (
        here.parents[1] / "kinsn/module/include/native_lab_input.h").read_bytes()
    modified = source.read_bytes()
    assert modified != base
    apply(kernel, patch)
    assert source.read_bytes() == modified, "second apply reversed the kernel fix"
    conflict = modified.replace(b"int err = add_kfunc_desc(env, insn->imm, insn->off, false);", b"int err = add_kfunc_desc(env, insn->imm, insn->off, true);", 1)
    source.write_bytes(conflict)
    try:
        apply(kernel, patch)
    except SystemExit as error:
        assert "conflicts" in str(error)
    else:
        raise AssertionError("conflicting kernel source was accepted")
    assert source.read_bytes() == conflict, "conflict partially changed the source"
print("kernel patch idempotence/conflict regressions: PASS")
