// SPDX-License-Identifier: GPL-2.0
/* Guest fixture: invoke one loaded LSM program with valid and NULL file args. */
#include <linux/bpf.h>
#include <asm/extable.h>
#include <linux/filter.h>
#include <linux/fs.h>
#include <linux/module.h>
#include <linux/rcupdate.h>

static unsigned int prog_id;
static unsigned long observed_control, observed_null, extable_count;
module_param(prog_id, uint, 0400);
module_param(observed_control, ulong, 0444);
module_param(observed_null, ulong, 0444);
module_param(extable_count, ulong, 0444);

static int __init native_load_fault_init(void)
{
    struct bpf_prog *prog = bpf_prog_by_id(prog_id);
    struct file file = { .f_pos = 0x1234abcd };
    unsigned long args[2] = { (unsigned long)&file, 0 };
    if (IS_ERR(prog)) return PTR_ERR(prog);
    extable_count = prog->aux->num_exentries;
    pr_info("native_load_fault: entry=%px extable=%px count=%lu\n",
            prog->bpf_func, prog->aux->extable, extable_count);
    for (unsigned int i = 0; i < extable_count; i++) {
        const struct exception_table_entry *ex = &prog->aux->extable[i];
        pr_info("native_load_fault: site=%u pc=%px fixup=%x data=%x\n",
                i, (const char *)&ex->insn + ex->insn, ex->fixup, ex->data);
    }
    pr_info("native_load_fault: prog=%px auxprog=%px registered=%u start=%lx end=%lx funcs=%u\n",
            prog, prog->aux->prog, prog->aux->ksym.prog,
            prog->aux->ksym.start, prog->aux->ksym.end, prog->aux->func_cnt);
    if (prog->aux->prog)
        pr_info("native_load_fault: auxprog extable=%px count=%u\n",
                prog->aux->prog->aux->extable, prog->aux->prog->aux->num_exentries);
    rcu_read_lock();
    observed_control = bpf_prog_run(prog, args);
    pr_info("native_load_fault: control=%lx\n", observed_control);
    args[0] = 0;
    observed_null = bpf_prog_run(prog, args);
    rcu_read_unlock();
    pr_info("native_load_fault: prog=%u extable=%lu control=%lx null=%lx\n",
            prog_id, extable_count, observed_control, observed_null);
    bpf_prog_put(prog);
    return 0;
}
static void __exit native_load_fault_exit(void) { }
module_init(native_load_fault_init);
module_exit(native_load_fault_exit);
MODULE_LICENSE("GPL");
