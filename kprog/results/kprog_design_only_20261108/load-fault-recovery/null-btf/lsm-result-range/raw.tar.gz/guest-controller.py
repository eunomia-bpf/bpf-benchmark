from pathlib import Path
from datetime import datetime,timezone
import os,select,subprocess,sys,json,tarfile,hashlib,traceback
G=Path(__file__).resolve().parent;C=G.parent.parent.parent;R=Path('/workspaces/repository');O=R/'kprog/results/kprog_design_only_20261108/load-fault-recovery/null-btf/lsm-result-range'
def save(state,**kw):(G/'guest-status.json').write_text(json.dumps(dict(state=state,**kw),indent=2)+'\n')
try:
 save('queued_after_matching_modules_refresh')
 try:fd=os.pidfd_open(int((G.parent/'modules-refresh.pid').read_text()));select.select([fd],[],[]);os.close(fd)
 except ProcessLookupError:pass
 rc=int((G.parent/'modules-refresh.exit').read_text())
 if rc:raise RuntimeError('kernel/module producer build exit '+str(rc))
 save('fixture_build')
 command=['taskset','-c','8-11','make','-C',str(R/'kprog/test/native_load_fault'),'OUT='+str(G/'fixture')]
 with(G/'fixture-build.log').open('w')as f:p=subprocess.run(command,cwd=R,stdout=f,stderr=subprocess.STDOUT)
 (G/'fixture-build.exit').write_text(str(p.returncode)+'\n');p.check_returncode()
 save('guest_running')
 guest='PATH=/usr/lib/llvm-18/bin:$PATH python3 /workspaces/repository/kprog/test/native_load_fault/guest.py '+str(G)
 command=['taskset','-c','20-23','vng','--run',str(R/'kprog/tv/build-kernel-x86/arch/x86/boot/bzImage'),'--cwd',str(R),'--rwdir',str(R),'--rwdir',str(C),'--overlay-rwdir','/tmp','--overlay-rwdir','/run','--disable-monitor','--cpus','4','--memory','2G','--append','loglevel=4 panic=30 oops=panic','--exec',guest];(G/'guest-command.json').write_text(json.dumps(command,indent=2)+'\n')
 with(G/'guest.log').open('w')as f:p=subprocess.run(command,cwd=R,stdout=f,stderr=subprocess.STDOUT)
 (G/'guest.exit').write_text(str(p.returncode)+'\n');j=json.loads((G/'guest/summary.json').read_text())if(G/'guest/summary.json').exists()else{};j.update(guest_exit=p.returncode,native_sha256=hashlib.sha256((G/'fixture/native.o').read_bytes()).hexdigest(),kernel_sha256=hashlib.sha256((R/'kprog/tv/build-kernel-x86/arch/x86/boot/bzImage').read_bytes()).hexdigest(),module_sha256=hashlib.sha256((R/'kprog/tv/build-x86/corpus-modules/bpf_x86_native_lab.ko').read_bytes()).hexdigest());O.mkdir(parents=True,exist_ok=True);(O/'summary.json').write_text(json.dumps(j,indent=2)+'\n');(O/'README.md').write_text('# Actual full-word NULL BTF load recovery\n\nThe authorized guest fixture loads one native LSM file_open program through source0 and the registered service. The original native body reads file.f_pos through the BTF pointer. An isolated guest module invokes that same loaded program first with a live struct file and then with its file argument0; its full-word value projects through -(value&1) to the existing LSM return range; results, program extable count, actual service/native/B/compiler/kernel records and guest survival are retained below. Program execution here is the explicitly requested recovery fixture, separate from the original kernel load-only catalog. Partial-register/ALU/implicit/vector fault-prefix correspondence remains the shared model/O4 work item.\n\nActual outcome: '+repr(j)+'.\n')
 with tarfile.open(O/'raw.tar.gz','w:gz')as tf:
  for n in ['guest','guest.py','guest-command.json','guest-controller.py','guest.log','guest.exit','fixture-build.log','fixture-build.exit']:
   p=G/n
   if p.exists():tf.add(p,arcname=n)
  tf.add(R/'kprog/test/native_load_fault',arcname='fixture-source');tf.add(G/'fixture/native.o',arcname='native.o');tf.add(G/'fixture/probe',arcname='probe');tf.add(G/'fixture/module/native_load_fault_module.ko',arcname='native_load_fault_module.ko')
 sys.path.insert(0,str(C));from publish_owned import publish
 commit=publish([str(p.relative_to(R))for p in O.iterdir()if p.is_file()],'Record actual native NULL BTF load exception recovery',G/'null-publication.json');save('finished',commit=commit,result=j)
 with(C.parent/'COORDINATION.md').open('a')as f:f.write('\n- LOCAL C FOR A/V/R '+datetime.now(timezone.utc).isoformat()+': PUSHED '+commit+' actual authorized full-word NULL BTF guest recovery '+repr(j)+'. Complete actual native/B/service/kernel outcomes retained. Fault-prefix interfaces stay explicit; runtime admission additions0.\n')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
