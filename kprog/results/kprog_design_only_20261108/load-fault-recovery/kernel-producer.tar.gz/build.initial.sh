set -eu
cd /workspaces/repository
export PATH=/root/.cargo/bin:$PATH
G=/workspaces/.agent-state/kprog-lanes/C/design-only/load-fault-recovery
taskset -c 8-11 cargo test -j2 --manifest-path kprog/x86/native_lab/native_link/Cargo.toml > "$G/rust-test.log" 2>&1
taskset -c 8-11 cargo build --release -j2 --manifest-path kprog/x86/native_lab/native_link/Cargo.toml > "$G/rust-build.log" 2>&1
taskset -c 8-11 cmake --build kprog/libnativeloader/build --target native_loader native_loader_shared trusted-native-loader trusted-service-client -j2 > "$G/loader-build.log" 2>&1
PYTHONDONTWRITEBYTECODE=1 python3 kprog/test/check_trusted_service.py > "$G/service-check.log" 2>&1
PYTHONDONTWRITEBYTECODE=1 python3 kprog/test/check_trusted_worker.py > "$G/worker-check.log" 2>&1
echo 0 > "$G/host.exit"
taskset -c 8-11 make -C kprog/tv/build-kernel-x86 ARCH=x86 -j4 bzImage > "$G/kernel-build.log" 2>&1
echo 0 > "$G/kernel.exit"
taskset -c 8-11 make -C kprog/tv/build-kernel-x86 M=/workspaces/repository/kinsn/module/x86 MO=/workspaces/repository/kprog/tv/build-x86/corpus-modules ARCH=x86 -j2 modules > "$G/module-build.log" 2>&1
echo 0 > "$G/module.exit"
