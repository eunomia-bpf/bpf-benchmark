set -eu
cd /workspaces/repository
taskset -c 8-11 make -C kprog/tv/build-kernel-x86 ARCH=x86 -j4 modules > /workspaces/.agent-state/kprog-lanes/C/design-only/load-fault-recovery/modules-refresh.log 2>&1
taskset -c 8-11 make -C kprog/tv/build-kernel-x86 M=/workspaces/repository/kinsn/module/x86 MO=/workspaces/repository/kprog/tv/build-x86/corpus-modules ARCH=x86 -j2 modules > /workspaces/.agent-state/kprog-lanes/C/design-only/load-fault-recovery/module-refresh.log 2>&1
