uname -a
insmod /workspaces/repository/kprog/tv/build-x86/corpus-modules/bpf_x86_native_lab.ko
dmesg | tail -90
