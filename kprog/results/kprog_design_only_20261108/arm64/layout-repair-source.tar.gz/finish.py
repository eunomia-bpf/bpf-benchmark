from pathlib import Path
import datetime,gzip,hashlib,importlib.util,json,os,select,subprocess,tarfile,traceback
R=Path('/workspaces/repository');D=Path(__file__).resolve().parent;A=D.parent;O=R/'kprog/results/kprog_design_only_20261108/arm64';B=R/'kprog/arm64/build/design-only'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(phase,**kw):(D/'status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
def notice(msg):
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A '+now()+': '+msg+'\n')
def publish(paths,message,label):
 spec=importlib.util.spec_from_file_location('arm_pub',A/'six-app-publish.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 return m.publish([str(p.relative_to(R)) for p in paths],message,label)
try:
 save('waiting_incremental_kernel_module',build_pid=538168)
 try:fd=os.pidfd_open(538168)
 except ProcessLookupError:fd=None
 if fd is not None:
  try:select.select([fd],[],[])
  finally:os.close(fd)
 code=int((D/'build.exit').read_text());(O/'build.log.gz').write_bytes(gzip.compress((D/'build.log').read_bytes(),mtime=0))
 if code:raise RuntimeError('Incremental kernel/module build exit '+str(code))
 save('paired_runtime_build',kernel_module_exit=code)
 with (D/'runtime.log').open('w') as log:
  done=subprocess.run(['taskset','-c','16-19','unshare','--mount','--propagation','private','sh',str(D/'runtime-inside.sh')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 (D/'runtime.exit').write_text(str(done.returncode)+'\n');done.check_returncode()
 (O/'runtime.log.gz').write_bytes(gzip.compress((D/'runtime.log').read_bytes(),mtime=0))
 record=dict(utc=now(),shared_commit='82f8e9e77a1ff5ea6ef9730734d80b3ea5db1b76',kernel_module_exit=code,runtime_exit=done.returncode,artifact_pins={str(p.relative_to(R)):sha(p) for p in B.rglob('*') if p.is_file()},source_pins={str(p.relative_to(D)):sha(p) for root in ['kernel-source','module-source','include','model-source'] for p in (D/root).rglob('*') if p.is_file()},kernel_cache=str(A/'kfunc-kernel/cache'),loader_cache='kprog/libnativeloader/build-arm64-typed-tail-v1')
 (O/'build.json').write_text(json.dumps(record,indent=2)+'\n')
 with tarfile.open(O/'build-artifacts.tar.gz','w:gz') as t:t.add(B,arcname='runtime')
 module=R/'kinsn/module/arm64/bpf_arm64_native_lab.c'
 if module.read_bytes()!=(D/'arm64-before.c').read_bytes():raise RuntimeError('ARM source ownership requires continuation')
 module.write_bytes((D/'arm64-candidate.c').read_bytes())
 p=O/'README.md';p.write_text(p.read_text()+'\nThe incremental ARM kernel,11 kinsn modules, kernel module bundle and paired loader/shim build complete with exits0. The repository ARM module adopts the immutable chunk/capsule interface. Exact source/binary hashes, commands and raw build logs accompany build.json and build-artifacts.tar.gz. The private simulator/source profile supplies the existing34-case QEMU run while prior whole-app source epochs retain their captured inputs.\n')
 paths=[module,*[O/n for n in ['README.md','build.json','build.log.gz','runtime.log.gz','build-artifacts.tar.gz']]]
 receipt=publish(paths,'Port ARM native emission to immutable request-owned chunks','arm-design-runtime');(D/'runtime-publication.json').write_text(json.dumps(receipt,indent=2)+'\n');notice('PUSHED '+receipt['commit']+' ARM657-lineimmutablechunkmodule; incrementalImage/11kinsn/kernelmodules/pairedloader-shim exits0. ExistingARMwarmkernel/loaderobjectcachesreused. Exactsource/binary/buildreceipts inrequesteddesign-onlyARMresults. Existing34-caseQEMU16-19 startsonthecoherentprivatekind6/layout/byte-arm/CBsourceepoch; wholeBCC/Katranfollow. CapturedTracee/H/P/Ninputsretained.')
 save('actual_existing34_qemu',runtime_publication=receipt)
 with (D/'safety.log').open('w') as log:
  done=subprocess.run(['taskset','-c','16-19','unshare','--mount','--propagation','private','sh',str(D/'safety-inside.sh')],cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
 (D/'safety.exit').write_text(str(done.returncode)+'\n');(O/'safety.log.gz').write_bytes(gzip.compress((D/'safety.log').read_bytes(),mtime=0))
 report=dict(utc=now(),make_exit=done.returncode,runtime_commit=receipt['commit']);F=O/'safety/trusted-arm64-service-result';paths=[O/'safety.log.gz']
 if (F/'summary.json').exists():
  summary=json.loads((F/'summary.json').read_text());archive=F/summary['archive'];report['summary']=summary
  with tarfile.open(archive) as t:
   names=t.getnames()
   if 'run/outcomes.json' in names:report['outcomes']=json.load(t.extractfile('run/outcomes.json'))
  paths.extend([F/'summary.json',archive])
 (O/'safety-replay.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(O/'safety-replay.json')
 receipt=publish(paths,'Retain ARM five-step native safety replay outcomes','arm-design-safety');(D/'safety-publication.json').write_text(json.dumps(receipt,indent=2)+'\n');save('safety_closed_for_continuation',publication=receipt,make_exit=done.returncode);notice('PUSHED '+receipt['commit']+' ARMexisting34suitereplay terminalMakeexit'+str(done.returncode)+'; actualkernel/service/compiler/loadoutcomesretained. ModelclosureandwholeBCC/Katrancontinuefromthesereceipts.')
except BaseException as e:
 save('requires_continuation',error=str(e),traceback=traceback.format_exc());notice('ARMdesign-onlybuild/replayrequirescontinuation: '+str(e)+'. Capturedlogsandstate retainedatA/design-only/status.json.');raise
