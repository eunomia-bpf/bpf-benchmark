set -eu
mount --bind /workspaces/.agent-state/kprog-lanes/A/design-only/model-source/kprog/arm64/micro-prog/arm64_abi.py /workspaces/repository/kprog/arm64/micro-prog/arm64_abi.py
mount --bind /workspaces/.agent-state/kprog-lanes/A/design-only/model-source/kprog/arm64/micro-prog/generate_micro_sim_proofs.py /workspaces/repository/kprog/arm64/micro-prog/generate_micro_sim_proofs.py
exec make -f /workspaces/.agent-state/kprog-lanes/A/design-only/Makefile existing-micro-generation
