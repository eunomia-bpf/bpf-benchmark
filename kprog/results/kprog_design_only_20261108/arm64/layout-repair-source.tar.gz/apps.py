from pathlib import Path
from collections import Counter
import datetime,gzip,hashlib,importlib.util,io,json,os,select,shutil,subprocess,tarfile,traceback
R=Path('/workspaces/repository');D=Path(__file__).resolve().parent;A=D.parent;O=R/'corpus/results/kprog_arm64_app_coverage_20261108/design-only'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(phase,**kw):(D/'apps-status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
pub=load('arm_design_pub',A/'six-app-publish.py')
def notice(msg):
 with (A.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A '+now()+': '+msg+'\n')
try:
 save('waiting_paired_runtime_and_safety',predecessor_pid=566013)
 try:fd=os.pidfd_open(566013)
 except ProcessLookupError:fd=None
 if fd is not None:
  try:select.select([fd],[],[])
  finally:os.close(fd)
 runtime=json.loads((D/'runtime-publication.json').read_text());S=D/'app-source';shutil.copytree(D/'model-source',S)
 script=(D/'app-inside.sh').read_text().replace(str(D/'model-source'),str(S));(D/'app-inside.sh').write_text(script)
 setup=dict(utc=now(),runtime_publication=runtime,source_pins={str(p.relative_to(S)):sha(p) for p in S.rglob('*') if p.is_file()},source_coverage_collector_sha256=sha(D/'app-coverage.py'),runtime_pins=json.loads((R/'kprog/results/kprog_design_only_20261108/arm64/build.json').read_text())['artifact_pins'],applications=['bcc','katran'],cpus='16-19',guest_cpus=8,guest_memory_mib=8192,scope='Existing whole two-start corpus workload, five-step native request path, paired immutable source/runtime epoch')
 (O/'launch.json').write_text(json.dumps(setup,indent=2)+'\n')
 with tarfile.open(O/'launch-inputs.tar.gz','w:gz') as t:
  for n in ['app-source','app-inside.sh','app-transport.py','app-coverage.py','apps.py','Makefile']:t.add(D/n,arcname=n)
 (O/'README.md').write_text('ARM whole BCC and Katran through the five-step native path\n\nThe existing two-start workload uses8vCPUs/8GiB on16-19 after the paired runtime and34-case controller closes. Captured simulator/service/compiler/loader/kernel inputs accompany the launch. Every closed attempt retains raw request, verifier, workload and per-program counters. QEMU durations provide functional evidence.\n')
 rec=pub.publish([str((O/n).relative_to(R)) for n in ['launch.json','launch-inputs.tar.gz','README.md']],'Queue ARM BCC and Katran on the five-step native path','arm-design-app-launch');(D/'apps-launch-publication.json').write_text(json.dumps(rec,indent=2)+'\n');notice('PUSHED '+rec['commit']+' wholeARM BCC/Katran five-stepreplay launch16-19,8vCPU/8GiB, immutablepairedsource/runtime; originaltwostartworkload retained. Actualterminalrequests andworkcounters follow.')
 scope=dict(Path=Path,Counter=Counter,tarfile=tarfile,io=io,json=json,hashlib=hashlib,now=now);exec(compile((D/'app-coverage.py').read_text(),'arm_design_app_coverage','exec'),scope)
 closed=[]
 for app in ['bcc','katran']:
  save('actual_'+app,launch_commit=rec['commit'],closed_results=closed);notice('START wholeARM '+app+' five-steppath16-19/8vCPU/8GiB; capturesrequest/native/compiledB/stockverifier/applicationwork counters.')
  with (D/('app-'+app+'.log')).open('w') as log:done=subprocess.run(['unshare','--mount','--propagation','private','sh',str(D/'app-inside.sh'),app],cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
  F=O/('trusted-arm64-'+app+'-result');F.mkdir(exist_ok=True);(F/'driver.log.gz').write_bytes(gzip.compress((D/('app-'+app+'.log')).read_bytes(),mtime=0));report=dict(utc=now(),application=app,make_exit=done.returncode);paths=[F/'driver.log.gz']
  if (F/'summary.json').exists():
   s=json.loads((F/'summary.json').read_text());archive=F/s['archive'];report['coverage']=scope['coverage'](s,archive);paths.extend([F/'summary.json',archive])
  (F/'coverage.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(F/'coverage.json');(F/'README.md').write_text('Whole ARM '+app+' five-step replay\n\nMake exit'+str(done.returncode)+'. Raw per-program/phase work counters, source/native/service/compiler/verifier logs and actual app status accompany coverage.json and the runtime archive. Every source program remains in the whole-app attempt.\n');paths.append(F/'README.md');receipt=pub.publish([str(p.relative_to(R)) for p in paths],'Retain whole ARM '+app+' five-step native workload results','arm-design-app-'+app);closed.append(dict(application=app,publication=receipt,make_exit=done.returncode));notice('PUSHED '+receipt['commit']+' wholeARM '+app+' five-stepreplay Makeexit'+str(done.returncode)+'; exactrequest/load/applicationworkresults captured.')
 save('finished',closed_results=closed)
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());notice('ARMfive-stepwholeappqueuerequirescontinuation: '+str(e)+'. Logsandstate retainedatA/design-only/apps-status.json.');raise
