from pathlib import Path
import datetime,gzip,hashlib,importlib.util,json,os,subprocess,tarfile,traceback
R=Path('/workspaces/repository');D=Path(__file__).resolve().parent;O=R/'kprog/results/kprog_design_only_20261108/arm64';F=O/'safety-x30/trusted-arm64-service-result'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(phase,**kw):(D/'safety-retry-status.json').write_text(json.dumps(dict(utc=now(),phase=phase,**kw),indent=2)+'\n')
def notice(s):
 with (D.parent.parent/'COORDINATION.md').open('a') as f:f.write('\n- LOCAL A '+now()+': '+s+'\n')
try:
 save('actual_existing34_x30_state');notice('START ARMexisting34native-onlyQEMU x30symbolicreturnstatecorrection,16-19/twovCPU/2GiB, paired e2d3runtime unchanged. Prior98a66source/outcomes retained. Newmodelusesouterreturncoordinate0; numericLRinputretained; addedadmissionchecks0.')
 with (D/'safety-retry.log').open('w') as log:done=subprocess.run(['taskset','-c','16-19','unshare','--mount','--propagation','private','sh',str(D/'safety-retry-inside.sh')],cwd=R,env=os.environ|{'PYTHONDONTWRITEBYTECODE':'1'},stdout=log,stderr=subprocess.STDOUT)
 (D/'safety-retry.exit').write_text(str(done.returncode)+'\n');(O/'safety-x30.log.gz').write_bytes(gzip.compress((D/'safety-retry.log').read_bytes(),mtime=0));report=dict(utc=now(),make_exit=done.returncode,state_correction=json.loads((D/'x30-fix.json').read_text()));paths=[O/'safety-x30.log.gz']
 if (F/'summary.json').exists():
  s=json.loads((F/'summary.json').read_text());archive=F/s['archive'];report['summary']=s;paths.extend([F/'summary.json',archive])
  with tarfile.open(archive) as t:
   if 'run/outcomes.json' in t.getnames():report['outcomes']=json.load(t.extractfile('run/outcomes.json'))
 (O/'safety-x30-replay.json').write_text(json.dumps(report,indent=2)+'\n');paths.append(O/'safety-x30-replay.json');spec=importlib.util.spec_from_file_location('arm_pub',D.parent/'six-app-publish.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);receipt=m.publish([str(p.relative_to(R)) for p in paths],'Retain ARM native safety outcomes with symbolic return state','arm-design-safety-x30');(D/'safety-retry-publication.json').write_text(json.dumps(receipt,indent=2)+'\n');save('finished',publication=receipt,make_exit=done.returncode);notice('PUSHED '+receipt['commit']+' ARMoriginal34x30-stateQEMUtrial terminalMakeexit'+str(done.returncode)+'; exactstockverifier/nativepositive/entry/helperoutcomes retained. Wholeappscontinuewiththeircapturedsourceepochs.')
except BaseException as e:save('requires_continuation',error=str(e),traceback=traceback.format_exc());raise
