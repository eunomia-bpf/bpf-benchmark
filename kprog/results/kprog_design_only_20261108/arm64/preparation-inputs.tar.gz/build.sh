set +e
unshare --mount --propagation private sh /workspaces/.agent-state/kprog-lanes/A/design-only/inside-build.sh > /workspaces/.agent-state/kprog-lanes/A/design-only/build.log 2>&1
x=$?
printf "%s
" "$x" > /workspaces/.agent-state/kprog-lanes/A/design-only/build.exit
exit "$x"
