from pathlib import Path
import subprocess,json
R=Path('/workspaces/repository');E=Path('/var/tmp/kprog-tmp/S9/ea')
for rel in ['kprog/x86/x86_sim_local_bpf.h','kprog/x86/x86_sim.h']:
 subprocess.run(['mount','--bind',str(E/'source'/rel),str(R/rel)],check=True)
rows=[]
for cc in ['gcc','clang']:
 cmd=['make','-C',str(R/'kprog/test/native_load_fault'),'host','CC='+cc,'OUT='+str(E/('focused-'+cc))]
 p=subprocess.run(cmd,capture_output=True,text=True);(E/('focused-'+cc+'.log')).write_text(p.stdout+p.stderr);rows.append(dict(compiler=cc,exit=p.returncode,command=cmd))
(E/'focused.json').write_text(json.dumps(rows,indent=2)+'\n')
