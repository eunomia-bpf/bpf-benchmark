from pathlib import Path
import os,subprocess
R=Path('/workspaces/repository');G=Path('/var/tmp/kprog-tmp/S9');E=G/'ea'
for p in (G/'prior/host-source').rglob('*'):
 if p.is_file() and p.name not in ['test_x86_callmem_route_host.c','test_x86_specialization_host.c','test_x86_dispatch_singleton_route_host.c']:
  subprocess.run(['mount','--bind',str(p),str(R/p.relative_to(G/'prior/host-source'))],check=True)
for rel in ['kprog/x86/x86_sim_local_bpf.h','kprog/x86/x86_sim.h']:
 subprocess.run(['mount','--bind',str(E/'source'/rel),str(R/rel)],check=True)
cmd=['make','-C',str(R/'kprog/formal'),'-f',str(G/'host-all.mk'),'-k','-j2','host']
with (E/'host-all.log').open('w') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
(E/'host-all.exit').write_text(str(p.returncode)+'\n')
