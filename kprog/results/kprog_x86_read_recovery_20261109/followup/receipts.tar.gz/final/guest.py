from pathlib import Path
import subprocess,os,json,sys,shutil
R=Path('/workspaces/repository');G=Path('/var/tmp');E=G/'ea';O=E/'guest';O.mkdir(exist_ok=True)
for p in sorted((E/'source').rglob('*')):
 if p.is_file():subprocess.run(['mount','--bind',str(p),str(R/p.relative_to(E/'source'))],check=True)
if subprocess.run(['mountpoint','-q','/sys/kernel/debug']).returncode:
 subprocess.run(['mount','-t','debugfs','debugfs','/sys/kernel/debug'],check=True)
subprocess.run(['insmod',str(R/'kprog/tv/build-x86/corpus-modules/bpf_x86_native_lab.ko')],check=True)
header=R/'kprog/x86/x86_sim_local_bpf.h';final=G/'guest-source/kprog/x86/x86_sim_local_bpf.h'
env=dict(os.environ,CLANG='/usr/lib/llvm-18/bin/clang',BPFREJIT_NATIVE_LOADER_REQUIRE_BOUND_PROOF='1')
allrows=[]
for epoch in ['final']:
 subprocess.run(['mount','--bind',str(G/'baseline-published.h' if epoch=='baseline' else final),str(header)],check=True)
 dest=O/epoch;dest.mkdir(exist_ok=True);state=dest/'requests';state.mkdir(mode=0o700,exist_ok=True)
 cmd=[sys.executable,str(R/'kprog/trusted_service.py'),'--arch','1','--endpoint','/sys/kernel/debug/bpf_x86_native_lab/specializer','--state',str(state),'--native-link',str(G/'native-link'),'--loader',str(R/'kprog/libnativeloader/build/trusted-native-loader')]
 service=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);log=[]
 try:
  log.append(service.stdout.readline())
  for name in ['word','byte','half','dword','pop','chain']:
   p=subprocess.run([str(G/'fixture/probe'),str(G/('fixture/'+name+'.o')),str(G/'fixture/module/native_load_fault_module.ko')],env=env,text=True,capture_output=True)
   (dest/(name+'.stdout')).write_text(p.stdout);(dest/(name+'.stderr')).write_text(p.stderr)
   row=dict(epoch=epoch,name=name,exit=p.returncode,stdout=p.stdout,stderr=p.stderr)
   if p.returncode==0 or 'trusted specializer refused' in p.stderr:
    record=service.stdout.readline();log.append(record);row['service']=record
   allrows.append(row);(O/'outcomes.json').write_text(json.dumps(allrows,indent=2)+'\n');print(epoch,name,p.returncode,flush=True)
 finally:
  service.terminate();log.append(service.communicate()[0]);(dest/'service.log').write_text(''.join(log))
# Original38 follows all read forms with the exact final source mounted.
p=subprocess.run([sys.executable,str(E/'safety/safety.py')],env=env,text=True,capture_output=True)
(O/'safety.stdout').write_text(p.stdout);(O/'safety.stderr').write_text(p.stderr);(O/'safety.exit').write_text(str(p.returncode)+'\n');print(p.stdout+p.stderr,flush=True)
(O/'dmesg').write_text(subprocess.check_output(['dmesg'],text=True))
# The coordinator selected these two established recovery-to-zero controls.
state=O/'recovery-controls';state.mkdir(mode=0o700,exist_ok=True)
service=subprocess.Popen([sys.executable,str(R/'kprog/trusted_service.py'),'--arch','1','--endpoint','/sys/kernel/debug/bpf_x86_native_lab/specializer','--state',str(state),'--native-link',str(G/'native-link'),'--loader',str(R/'kprog/libnativeloader/build/trusted-native-loader')],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
controls=[];logs=[service.stdout.readline()]
try:
 old=Path('/workspaces/.agent-state/kprog-lanes/C/design-only/safety/build')
 for name in ['immediate_push_branch','stack_base_flags']:
  cmd=[str(G/'safety/canonical-probe'),str(old/'context_hash.bpf.o'),str(old/(name+'.native.o')),'0','0']
  q=subprocess.run(cmd,env=env,capture_output=True,text=True);logs.append(service.stdout.readline())
  controls.append(dict(name=name,exit=q.returncode,stdout=q.stdout,stderr=q.stderr,command=cmd))
finally:
 service.terminate();logs.append(service.communicate()[0])
 (state/'service.log').write_text(''.join(logs));(O/'recovery-controls.json').write_text(json.dumps(controls,indent=2)+'\n')
sys.exit(0 if all(x['exit']==0 for x in allrows+controls) else 1)
