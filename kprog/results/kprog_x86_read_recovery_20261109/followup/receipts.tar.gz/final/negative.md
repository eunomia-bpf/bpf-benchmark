| Micro program | Status | Compile s | Proof BPF insns | Direct BPF insns | Verify s | Test s | Note |
| --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| `unchecked_packet_read` | ok | 0.284 | 30 |  | 0.000 | 0.000 |  |
