from pathlib import Path
import os,subprocess,json
R=Path('/workspaces/repository');G=Path('/var/tmp/kprog-tmp/S9');E=G/'ea';S=E/'source'
for p in S.rglob('*'):
 if p.is_file() and not str(p.relative_to(S)).startswith('kprog/x86/micro-prog/'):
  subprocess.run(['mount','--bind',str(p),str(R/p.relative_to(S))],check=True)
subprocess.run(['mount','--bind',str(E/'micro-source'),str(R/'kprog/x86/micro-prog')],check=True)
rows=[]
def run(name,cmd):
 p=subprocess.run(cmd,capture_output=True,text=True);(E/(name+'.log')).write_text(p.stdout+p.stderr);rows.append(dict(name=name,exit=p.returncode,command=cmd));(E/'checks.json').write_text(json.dumps(rows,indent=2)+'\n');return p.returncode
for cc in ['gcc','clang']:
 run('host-'+cc,['make','-C',str(R/'kprog/test/native_load_fault'),'host','CC='+cc,'OUT='+str(E/('host-'+cc))])
for name,config,objects in [('positive',R/'micro/config/micro_pure_jit.yaml',G/'micro-native'),('negative',R/'kprog/test/kprog_negative_stage2.yaml',G/'negative-native')]:
 if run('generate-'+name,['python3',str(R/'kprog/x86/micro-prog/generate_micro_sim_proofs.py'),'--config',str(config),'--proof-object-dir',str(objects)]):continue
 run('compile-'+name,['python3',str(R/'kprog/run_micro_sim_batch.py'),'--arch','x86','--build-only','--no-generate','--no-build-loader','--config',str(config),'--build-dir',str(E/('build-'+name)),'--markdown',str(E/(name+'.md')),'--jobs','2'])
cmd=['vng','--run',str(R/'kprog/tv/build-kernel-x86/arch/x86/boot/bzImage'),'--cwd',str(R),'--rwdir',str(R),'--rwdir','/var/tmp='+str(G),'--overlay-rwdir','/tmp','--overlay-rwdir','/run','--disable-monitor','--cpus','2','--memory','2G','--append','loglevel=4 panic=30 oops=panic','--exec','PATH=/usr/lib/llvm-18/bin:$PATH python3 /var/tmp/ea/guest.py']
run('guest',cmd)
