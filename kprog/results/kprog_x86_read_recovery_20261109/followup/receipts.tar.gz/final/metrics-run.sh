#!/bin/bash
export TMPDIR=/var/tmp/kprog-tmp/S9 PYTHONDONTWRITEBYTECODE=1
ulimit -c 0
cd /workspaces/repository
make -f /var/tmp/kprog-tmp/S9/ea/metrics/Makefile probe > /var/tmp/kprog-tmp/S9/ea/metrics/build.log 2>&1 || exit
while [ ! -f /var/tmp/kprog-tmp/S9/ea/guest-final.exit ]; do sleep 5; done
vng --run /workspaces/repository/kprog/tv/build-kernel-x86/arch/x86/boot/bzImage --cwd /workspaces/repository --rwdir /workspaces/repository --rwdir /var/tmp=/var/tmp/kprog-tmp/S9 --overlay-rwdir /tmp --overlay-rwdir /run --disable-monitor --cpus 2 --memory 2G --append 'loglevel=4 panic=30 oops=panic' --exec 'PATH=/usr/lib/llvm-18/bin:$PATH python3 /var/tmp/ea/metrics-guest.py' > /var/tmp/kprog-tmp/S9/ea/metrics/guest.log 2>&1
echo $? > /var/tmp/kprog-tmp/S9/ea/metrics/guest.exit
