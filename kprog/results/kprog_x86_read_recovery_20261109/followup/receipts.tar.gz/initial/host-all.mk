ARM64_HOST_ENV := -include oracles/arm64_entry_environment_host.h -DKPROG_TEST_EXCLUSIVE_FAILURE=0 -include oracles/arm64_exclusive_choice_host.h
CC := gcc
.PHONY: host
host: h0 h1 h2 h3 h4 h5 h6 h7 h8 h9 h10 h11 h12 h13 h14 h15 h16 h17 h18 h19 h20 h21 h22 h23 h24 h25 h26 h27 h28 h29 h30 h31 h32 h33 h34 h35 h36 h37 h38 h39 h40 h41 h42 h43 h44 h45 h46 h47 h48 h49 h50 h51 h52 h53 h54 h55 h56 h57 h58 h59 h60 h61 h62 h63 h64 h65 h66 h67 h68 h69 h70 h71 h72 h73 h74 h75 h76 h77 h78 h79 h80 h81 h82 h83 h84 h85 h86 h87 h88 h89 h90 h91 h92 h93 h94 h95 h96 h97 h98 h99 h100 h101 h102 h103 h104 h105 h106 h107 h108 h109 h110 h111 h112 h113 h114 h115 h116 h117 h118 h119 h120 h121 h122 h123 h124 h125 h126 h127 h128 h129 h130 h131 h132 h133 h134
h0:
	$(CC) -Wall -Wextra -O2 -fsanitize=undefined -fno-sanitize-recover=undefined -I. -I../x86 -I../../vendor/libbpf/src oracles/test_x86_six_flags_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_six_flags_host
	/var/tmp/kprog-tmp/S9/host/test_x86_six_flags_host
h1:
	$(CC) -Wall -Wextra -O2 -fsanitize=undefined -fno-sanitize-recover=undefined -I. -I../x86 -I../../vendor/libbpf/src oracles/test_x86_full_condition_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_full_condition_host
	/var/tmp/kprog-tmp/S9/host/test_x86_full_condition_host
h2:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_branch_emit_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_branch_emit_host
	/var/tmp/kprog-tmp/S9/host/test_x86_branch_emit_host
h3:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_branch_emit_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_branch_emit_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_branch_emit_route_host
h4:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/width_fallback_host.c -o /var/tmp/kprog-tmp/S9/host/width_fallback_host
	/var/tmp/kprog-tmp/S9/host/width_fallback_host
h5:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 oracles/test_x86_alu_result_arm_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_alu_result_arm_host
	/var/tmp/kprog-tmp/S9/host/test_x86_alu_result_arm_host
h6:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_alu_result_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_alu_result_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_alu_result_route_host
h7:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_alu_mem_result_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_alu_mem_result_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_alu_mem_result_route_host
h8:
	$(CC) -Wall -Wextra -O2 -mno-red-zone -fsanitize=undefined -fno-sanitize-recover=all -I. -I../x86 -I../../vendor/libbpf/src oracles/test_x86_alu_memory_frame_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_alu_memory_frame_host
	/var/tmp/kprog-tmp/S9/host/test_x86_alu_memory_frame_host
h9:
	$(CC) -Wall -Wextra -O2 -mno-red-zone -fsanitize=undefined -fno-sanitize-recover=all -I. -I../x86 -I../../vendor/libbpf/src oracles/test_x86_alu_source_frame_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_alu_source_frame_host
	/var/tmp/kprog-tmp/S9/host/test_x86_alu_source_frame_host
h10:
	$(CC) -Wall -Wextra -O2 -mno-red-zone -fsanitize=undefined -fno-sanitize-recover=all -I. -I../x86 -I../../vendor/libbpf/src oracles/test_x86_imul_memory_frame_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_imul_memory_frame_host
	/var/tmp/kprog-tmp/S9/host/test_x86_imul_memory_frame_host
h11:
	$(CC) -Wall -Wextra -O2 -mno-red-zone -fsanitize=undefined -fno-sanitize-recover=all -I. -I../x86 -I../../vendor/libbpf/src oracles/test_x86_bmi_memory_frame_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_bmi_memory_frame_host
	/var/tmp/kprog-tmp/S9/host/test_x86_bmi_memory_frame_host
h12:
	$(CC) -Wall -Wextra -O2 -mno-red-zone -fsanitize=undefined -fno-sanitize-recover=all -I. -I../x86 -I../../vendor/libbpf/src oracles/test_x86_bit_memory_frame_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_bit_memory_frame_host
	/var/tmp/kprog-tmp/S9/host/test_x86_bit_memory_frame_host
h13:
	$(CC) -Wall -Wextra -O2 -mno-red-zone -fsanitize=undefined -fno-sanitize-recover=all -I. -I../x86 -I../../vendor/libbpf/src oracles/test_x86_andn_bt_memory_frame_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_andn_bt_memory_frame_host
	/var/tmp/kprog-tmp/S9/host/test_x86_andn_bt_memory_frame_host
h14:
	$(CC) -Wall -Wextra -O2 -mno-red-zone -fsanitize=undefined -fno-sanitize-recover=all -I. -I../x86 -I../../vendor/libbpf/src oracles/test_x86_xmm0_memory_frame_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_xmm0_memory_frame_host
	/var/tmp/kprog-tmp/S9/host/test_x86_xmm0_memory_frame_host
h15:
	$(CC) -Wall -Wextra -O2 -mno-red-zone -fsanitize=undefined -fno-sanitize-recover=all -I. -I../x86 -I../../vendor/libbpf/src oracles/test_x86_mov_memory_frame_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_mov_memory_frame_host
	/var/tmp/kprog-tmp/S9/host/test_x86_mov_memory_frame_host
h16:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_shiftx_rorx_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_shiftx_rorx_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_shiftx_rorx_route_host
h17:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_movx_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_movx_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_movx_route_host
h18:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_imul_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_imul_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_imul_route_host
h19:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_imul_flags_host.c -o /var/tmp/kprog-tmp/S9/host/test_imul_flags_host
	/var/tmp/kprog-tmp/S9/host/test_imul_flags_host
h20:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_lea_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_lea_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_lea_route_host
h21:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_mov_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_mov_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_mov_route_host
h22:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_bswap_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_bswap_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_bswap_route_host
h23:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 oracles/test_x86_alu_decode_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_alu_decode_host
	/var/tmp/kprog-tmp/S9/host/test_x86_alu_decode_host
h24:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 oracles/test_x86_opcode_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_opcode_host
	/var/tmp/kprog-tmp/S9/host/test_x86_opcode_host
h25:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 oracles/test_x86_specialization_chain_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_specialization_chain_host
	/var/tmp/kprog-tmp/S9/host/test_x86_specialization_chain_host
h26:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_specialization_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_specialization_host
	/var/tmp/kprog-tmp/S9/host/test_x86_specialization_host
h27:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_stack_index_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_stack_index_host
	/var/tmp/kprog-tmp/S9/host/test_x86_stack_index_host
h28:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_stack_arena_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_stack_arena_host
	/var/tmp/kprog-tmp/S9/host/test_x86_stack_arena_host
h29:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_ror_result_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_ror_result_host
	/var/tmp/kprog-tmp/S9/host/test_x86_ror_result_host
h30:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_bswap_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_bswap_host
	/var/tmp/kprog-tmp/S9/host/test_x86_bswap_host
h31:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_signed_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_signed_host
	/var/tmp/kprog-tmp/S9/host/test_x86_signed_host
h32:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_popcount_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_popcount_host
	/var/tmp/kprog-tmp/S9/host/test_x86_popcount_host
h33:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_bitops_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_bitops_host
	/var/tmp/kprog-tmp/S9/host/test_x86_bitops_host
h34:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_doubleshift_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_doubleshift_host
	/var/tmp/kprog-tmp/S9/host/test_x86_doubleshift_host
h35:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_shift_flags_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_shift_flags_host
	/var/tmp/kprog-tmp/S9/host/test_x86_shift_flags_host
h36:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_shift_flags_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_shift_flags_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_shift_flags_route_host
h37:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 oracles/test_x86_reg_lane_aux_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_reg_lane_aux_host
	/var/tmp/kprog-tmp/S9/host/test_x86_reg_lane_aux_host
h38:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 oracles/test_x86_mem_aux_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_mem_aux_host
	/var/tmp/kprog-tmp/S9/host/test_x86_mem_aux_host
h39:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_mem_access_host.c -o /var/tmp/kprog-tmp/S9/host/test_mem_access_host
	/var/tmp/kprog-tmp/S9/host/test_mem_access_host
h40:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_mem_alu_handler_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_mem_alu_handler_host
	/var/tmp/kprog-tmp/S9/host/test_x86_mem_alu_handler_host
h41:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_mem_store_alu_handler_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_mem_store_alu_handler_host
	/var/tmp/kprog-tmp/S9/host/test_x86_mem_store_alu_handler_host
h42:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_mem_unary_handler_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_mem_unary_handler_host
	/var/tmp/kprog-tmp/S9/host/test_x86_mem_unary_handler_host
h43:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_mem_logic_handler_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_mem_logic_handler_host
	/var/tmp/kprog-tmp/S9/host/test_x86_mem_logic_handler_host
h44:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_mem_shift_handler_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_mem_shift_handler_host
	/var/tmp/kprog-tmp/S9/host/test_x86_mem_shift_handler_host
h45:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_mem_bit_handler_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_mem_bit_handler_host
	/var/tmp/kprog-tmp/S9/host/test_x86_mem_bit_handler_host
h46:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_mem_imul_handler_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_mem_imul_handler_host
	/var/tmp/kprog-tmp/S9/host/test_x86_mem_imul_handler_host
h47:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_mem_compare_handler_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_mem_compare_handler_host
	/var/tmp/kprog-tmp/S9/host/test_x86_mem_compare_handler_host
h48:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_mulx_handler_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_mulx_handler_host
	/var/tmp/kprog-tmp/S9/host/test_x86_mulx_handler_host
h49:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_imul_reg_imm_handler_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_imul_reg_imm_handler_host
	/var/tmp/kprog-tmp/S9/host/test_x86_imul_reg_imm_handler_host
h50:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_mem_offset_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_mem_offset_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_mem_offset_route_host
h51:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_mem_index_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_mem_index_host
	/var/tmp/kprog-tmp/S9/host/test_x86_mem_index_host
h52:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_mem_index_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_mem_index_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_mem_index_route_host
h53:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_reg_dispatch_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_reg_dispatch_host
	/var/tmp/kprog-tmp/S9/host/test_x86_reg_dispatch_host
h54:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_reg_dispatch_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_reg_dispatch_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_helper_dispatch_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_helper_dispatch_host
	/var/tmp/kprog-tmp/S9/host/test_x86_helper_dispatch_host
h55:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_helper_dispatch_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_helper_dispatch_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_helper_dispatch_route_host
h56:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/x86_route_host.c -o /var/tmp/kprog-tmp/S9/host/x86_route_host
	/var/tmp/kprog-tmp/S9/host/x86_route_host
h57:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/btmem_index_route_host.c -o /var/tmp/kprog-tmp/S9/host/btmem_index_route_host
	/var/tmp/kprog-tmp/S9/host/btmem_index_route_host
h58:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/value_route_host.c -o /var/tmp/kprog-tmp/S9/host/value_route_host
	/var/tmp/kprog-tmp/S9/host/value_route_host
h59:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_xchg_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_xchg_host
	/var/tmp/kprog-tmp/S9/host/test_x86_xchg_host
h60:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_xchg_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_xchg_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_xchg_route_host
h61:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_mulx_arm_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_mulx_arm_host
	/var/tmp/kprog-tmp/S9/host/test_x86_mulx_arm_host
h62:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_mulx_arm_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_mulx_arm_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_mulx_arm_route_host
h63:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_div_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_div_host
	/var/tmp/kprog-tmp/S9/host/test_x86_div_host
h64:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_div_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_div_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_div_route_host
h65:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_doubleshift_arm_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_doubleshift_arm_host
	/var/tmp/kprog-tmp/S9/host/test_x86_doubleshift_arm_host
h66:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_doubleshift_arm_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_doubleshift_arm_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_doubleshift_arm_route_host
h67:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_popcnt_flags_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_popcnt_flags_host
	/var/tmp/kprog-tmp/S9/host/test_x86_popcnt_flags_host
h68:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_popcnt_flags_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_popcnt_flags_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_popcnt_flags_route_host
h69:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_bzhi_flags_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_bzhi_flags_host
	/var/tmp/kprog-tmp/S9/host/test_x86_bzhi_flags_host
h70:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_bzhi_flags_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_bzhi_flags_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_bzhi_flags_route_host
h71:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_movx_shape_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_movx_shape_host
	/var/tmp/kprog-tmp/S9/host/test_x86_movx_shape_host
h72:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_movx_shape_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_movx_shape_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_movx_shape_route_host
h73:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_mov_reg_arm_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_mov_reg_arm_host
	/var/tmp/kprog-tmp/S9/host/test_x86_mov_reg_arm_host
h74:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_mov_reg_arm_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_mov_reg_arm_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_mov_reg_arm_route_host
h75:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_stack_arm_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_stack_arm_host
	/var/tmp/kprog-tmp/S9/host/test_x86_stack_arm_host
h76:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_stack_arm_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_stack_arm_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_stack_arm_route_host
h77:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_write_width_arm_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_write_width_arm_host
	/var/tmp/kprog-tmp/S9/host/test_x86_write_width_arm_host
h78:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_write_width_arm_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_write_width_arm_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_write_width_arm_route_host
h79:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_stack_write_lanes_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_stack_write_lanes_host
	/var/tmp/kprog-tmp/S9/host/test_x86_stack_write_lanes_host
h80:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_stack_write_lanes_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_stack_write_lanes_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_stack_write_lanes_route_host
h81:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_alu_flag_arm_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_alu_flag_arm_host
	/var/tmp/kprog-tmp/S9/host/test_x86_alu_flag_arm_host
h82:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_alu_flag_arm_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_alu_flag_arm_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_alu_flag_arm_route_host
h83:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_dispatch_family_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_dispatch_family_host
	/var/tmp/kprog-tmp/S9/host/test_x86_dispatch_family_host
h84:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_dispatch_family_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_dispatch_family_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_dispatch_family_route_host
h85:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_dispatch_singleton_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_dispatch_singleton_host
	/var/tmp/kprog-tmp/S9/host/test_x86_dispatch_singleton_host
h86:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_dispatch_singleton_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_dispatch_singleton_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_dispatch_singleton_route_host
h87:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_reg_presence_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_reg_presence_host
	/var/tmp/kprog-tmp/S9/host/test_x86_reg_presence_host
h88:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_reg_presence_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_reg_presence_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_reg_presence_route_host
h89:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_width_effective_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_width_effective_host
	/var/tmp/kprog-tmp/S9/host/test_x86_width_effective_host
h90:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_width_effective_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_width_effective_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_width_effective_route_host
h91:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_lea_handler_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_lea_handler_host
	/var/tmp/kprog-tmp/S9/host/test_x86_lea_handler_host
h92:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_mov_handler_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_mov_handler_host
	/var/tmp/kprog-tmp/S9/host/test_x86_mov_handler_host
h93:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_movx_reg_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_movx_reg_host
	/var/tmp/kprog-tmp/S9/host/test_x86_movx_reg_host
h94:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_mem_read_dispatch_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_mem_read_dispatch_host
	/var/tmp/kprog-tmp/S9/host/test_x86_mem_read_dispatch_host
h95:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_mem_dispatch_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_mem_dispatch_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_mem_dispatch_route_host
h96:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_mov_load_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_mov_load_host
	/var/tmp/kprog-tmp/S9/host/test_x86_mov_load_host
h97:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_mov_load_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_mov_load_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_mov_load_route_host
h98:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_store_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_store_host
	/var/tmp/kprog-tmp/S9/host/test_x86_store_host
h99:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_store_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_store_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_store_route_host
h100:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_setcc_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_setcc_host
	/var/tmp/kprog-tmp/S9/host/test_x86_setcc_host
h101:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_setcc_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_setcc_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_setcc_route_host
h102:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_cc_decode_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_cc_decode_host
	/var/tmp/kprog-tmp/S9/host/test_x86_cc_decode_host
h103:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_setcc_mem_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_setcc_mem_host
	/var/tmp/kprog-tmp/S9/host/test_x86_setcc_mem_host
h104:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_setcc_mem_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_setcc_mem_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_setcc_mem_route_host
h105:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_cmov_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_cmov_host
	/var/tmp/kprog-tmp/S9/host/test_x86_cmov_host
h106:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/cmov_step_route_host.c -o /var/tmp/kprog-tmp/S9/host/cmov_step_route_host
	/var/tmp/kprog-tmp/S9/host/cmov_step_route_host
h107:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_movbe_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_movbe_host
	/var/tmp/kprog-tmp/S9/host/test_x86_movbe_host
h108:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_movbe_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_movbe_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_movbe_route_host
h109:
	$(CC) -Wall -Wextra -O2 -mno-red-zone -fsanitize=undefined -fno-sanitize-recover=all -I. -I../x86 -I../../vendor/libbpf/src oracles/test_x86_mov_load_map_ptr_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_mov_load_map_ptr_host
	/var/tmp/kprog-tmp/S9/host/test_x86_mov_load_map_ptr_host
h110:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_xmm0_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_xmm0_host
	/var/tmp/kprog-tmp/S9/host/test_x86_xmm0_host
h111:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_xmm0_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_xmm0_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_xmm0_route_host
h112:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_callmem_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_callmem_host
	/var/tmp/kprog-tmp/S9/host/test_x86_callmem_host
h113:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_callmem_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_callmem_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_callmem_route_host
h114:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_pushpop_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_pushpop_host
	/var/tmp/kprog-tmp/S9/host/test_x86_pushpop_host
h115:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_pushpop_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_pushpop_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_pushpop_route_host
h116:
	$(CC) -Wall -Wextra -O2 -mno-red-zone -fsanitize=undefined -fno-sanitize-recover=all -I. -I../x86 -I../../vendor/libbpf/src oracles/test_x86_rep_memory_frame_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_rep_memory_frame_host
	/var/tmp/kprog-tmp/S9/host/test_x86_rep_memory_frame_host
h117:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_rep_movs_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_rep_movs_host
	/var/tmp/kprog-tmp/S9/host/test_x86_rep_movs_host
h118:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_rep_movs_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_rep_movs_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_rep_movs_route_host
h119:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_andn_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_andn_host
	/var/tmp/kprog-tmp/S9/host/test_x86_andn_host
h120:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_andn_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_andn_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_andn_route_host
h121:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_bzhi_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_bzhi_host
	/var/tmp/kprog-tmp/S9/host/test_x86_bzhi_host
h122:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_bzhi_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_bzhi_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_bzhi_route_host
h123:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_bt_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_bt_host
	/var/tmp/kprog-tmp/S9/host/test_x86_bt_host
h124:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_bt_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_bt_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_bt_route_host
h125:
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_cmpop_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_cmpop_host
	/var/tmp/kprog-tmp/S9/host/test_x86_cmpop_host
h126:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_cmpop_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_cmpop_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_cmpop_route_host
h127:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_cmp_mem_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_cmp_mem_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_cmp_mem_route_host
h128:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_cmov_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_cmov_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_cmov_route_host
h129:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/cross_isa_tag_host.c -o /var/tmp/kprog-tmp/S9/host/cross_isa_tag_host
	/var/tmp/kprog-tmp/S9/host/cross_isa_tag_host
h130:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/cross_isa_differential_host.c -o /var/tmp/kprog-tmp/S9/host/cross_isa_differential_host
	/var/tmp/kprog-tmp/S9/host/cross_isa_differential_host
h131:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_imul_flags_wide_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_imul_flags_wide_host
	/var/tmp/kprog-tmp/S9/host/test_x86_imul_flags_wide_host
h132:
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../x86 -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_control_flow_trace_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_control_flow_trace_route_host
	/var/tmp/kprog-tmp/S9/host/test_control_flow_trace_route_host
h133:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_call_ret_route_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_call_ret_route_host
	/var/tmp/kprog-tmp/S9/host/test_x86_call_ret_route_host
h134:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_helper_call_host.c -o /var/tmp/kprog-tmp/S9/host/test_x86_helper_call_host
	/var/tmp/kprog-tmp/S9/host/test_x86_helper_call_host
