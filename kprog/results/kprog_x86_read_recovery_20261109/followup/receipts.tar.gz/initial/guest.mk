R := /workspaces/repository
G := /var/tmp/kprog-tmp/S9
.PHONY: build guest safety-guest
build:
	$(MAKE) -C $(R)/kprog/test/native_load_fault OUT=$(G)/fixture
	$(CXX) -std=c++20 -O2 -I$(R)/runner/build-llvmbpf/vendor/libbpf/prefix/include $(G)/canonical-probe.cpp $(G)/libnative_loader.a $(R)/runner/build-llvmbpf/vendor/libbpf/pic-obj/libbpf.a -lelf -lz -ldl -pthread -o $(G)/safety/canonical-probe
