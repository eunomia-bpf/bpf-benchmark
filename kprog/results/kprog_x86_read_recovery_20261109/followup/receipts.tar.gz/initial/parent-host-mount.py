import resource
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
from pathlib import Path
import os,subprocess
R=Path('/workspaces/repository');G=Path('/var/tmp/kprog-tmp/S9')
for p in sorted((G/'prior/host-source').rglob('*')):
 if p.is_file():subprocess.run(['mount','--bind',str(p),str(R/p.relative_to(G/'prior/host-source'))],check=True)
subprocess.run(['mount','--bind',str(G/'baseline-published.h'),str(R/'kprog/x86/x86_sim_local_bpf.h')],check=True)
os.chdir(R/'kprog/formal');os.execvp('make',['make','-f',str(G/'parent-host.mk'),'-k','-j2','host'])
