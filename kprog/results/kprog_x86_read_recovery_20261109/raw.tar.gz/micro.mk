R := /workspaces/repository
G := /var/tmp/kprog-tmp/S1
.PHONY: micro
micro:
	python3 $(G)/prepare-micro.py
	python3 $(R)/kprog/run_micro_sim_batch.py --arch x86 --build-only --no-generate --no-build-loader --build-dir $(G)/micro-build --markdown $(G)/micro.md --jobs 4
	python3 $(R)/kprog/run_micro_sim_batch.py --arch x86 --build-only --no-generate --no-build-loader --config $(R)/kprog/test/kprog_negative_stage2.yaml --build-dir $(G)/negative-build --markdown $(G)/negative.md --jobs 1
