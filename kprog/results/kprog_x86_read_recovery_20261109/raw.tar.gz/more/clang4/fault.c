#define X86_SIM_USE_STATE_STRUCT
#define X86_SIM_ENABLE_STACK 1
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"
#include "/workspaces/repository/kprog/formal/oracles/x86_no_helpers_host.h"
#include <stdio.h>
#include <string.h>
static unsigned calls;
#undef X86_SIM_L_UNSPECIFIED
#define X86_SIM_L_UNSPECIFIED() (calls++,1U)
#undef __x86_sim_is_xdp
#define __x86_sim_is_xdp entry_mode
static __always_inline void run_0(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmova edi,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RDI, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_A)), 68719476736ULL);
}
static __always_inline void run_1(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovae eax,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RAX, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_AE)), 68719476736ULL);
}
static __always_inline void run_2(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovae esp,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RSP, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_AE)), 68719476736ULL);
}
static __always_inline void run_3(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovae edi,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RDI, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_AE)), 68719476736ULL);
}
static __always_inline void run_4(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovb eax,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RAX, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_B)), 68719476736ULL);
}
static __always_inline void run_5(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovb esp,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RSP, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_B)), 68719476736ULL);
}
static __always_inline void run_6(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovb edi,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RDI, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_B)), 68719476736ULL);
}
static __always_inline void run_7(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovbe eax,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RAX, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_BE)), 68719476736ULL);
}
static __always_inline void run_8(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovbe esp,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RSP, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_BE)), 68719476736ULL);
}
static __always_inline void run_9(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovbe edi,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RDI, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_BE)), 68719476736ULL);
}
static __always_inline void run_10(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmove eax,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RAX, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_E)), 68719476736ULL);
}
static __always_inline void run_11(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmove esp,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RSP, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_E)), 68719476736ULL);
}
static __always_inline void run_12(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmove edi,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RDI, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_E)), 68719476736ULL);
}
static __always_inline void run_13(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovne eax,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RAX, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_NE)), 68719476736ULL);
}
static __always_inline void run_14(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovne esp,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RSP, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_NE)), 68719476736ULL);
}
static __always_inline void run_15(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovne edi,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RDI, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_NE)), 68719476736ULL);
}
static __always_inline void run_16(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovg eax,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RAX, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_G)), 68719476736ULL);
}
static __always_inline void run_17(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovg esp,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RSP, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_G)), 68719476736ULL);
}
static __always_inline void run_18(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovg edi,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RDI, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_G)), 68719476736ULL);
}
static __always_inline void run_19(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovge eax,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RAX, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_GE)), 68719476736ULL);
}
static __always_inline void run_20(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovge esp,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RSP, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_GE)), 68719476736ULL);
}
static __always_inline void run_21(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovge edi,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RDI, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_GE)), 68719476736ULL);
}
static __always_inline void run_22(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovl eax,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RAX, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_L)), 68719476736ULL);
}
static __always_inline void run_23(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovl esp,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RSP, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_L)), 68719476736ULL);
}
static __always_inline void run_24(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovl edi,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RDI, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_L)), 68719476736ULL);
}
static __always_inline void run_25(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovle eax,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RAX, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_LE)), 68719476736ULL);
}
static __always_inline void run_26(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovle esp,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RSP, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_LE)), 68719476736ULL);
}
static __always_inline void run_27(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovle edi,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RDI, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_LE)), 68719476736ULL);
}
static __always_inline void run_28(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovo eax,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RAX, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_O)), 68719476736ULL);
}
static __always_inline void run_29(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovo esp,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RSP, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_O)), 68719476736ULL);
}
static __always_inline void run_30(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovo edi,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RDI, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_O)), 68719476736ULL);
}
static __always_inline void run_31(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovno eax,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RAX, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_NO)), 68719476736ULL);
}
static __always_inline void run_32(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovno esp,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RSP, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_NO)), 68719476736ULL);
}
static __always_inline void run_33(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovno edi,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RDI, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_NO)), 68719476736ULL);
}
static __always_inline void run_34(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovp eax,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RAX, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_P)), 68719476736ULL);
}
static __always_inline void run_35(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovp esp,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RSP, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_P)), 68719476736ULL);
}
static __always_inline void run_36(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovp edi,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RDI, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_P)), 68719476736ULL);
}
static __always_inline void run_37(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovnp eax,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RAX, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_NP)), 68719476736ULL);
}
static __always_inline void run_38(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovnp esp,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RSP, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_NP)), 68719476736ULL);
}
static __always_inline void run_39(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovnp edi,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RDI, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_NP)), 68719476736ULL);
}
static __always_inline void run_40(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovs eax,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RAX, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_S)), 68719476736ULL);
}
static __always_inline void run_41(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovs esp,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RSP, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_S)), 68719476736ULL);
}
static __always_inline void run_42(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovs edi,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RDI, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_S)), 68719476736ULL);
}
static __always_inline void run_43(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovns eax,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RAX, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_NS)), 68719476736ULL);
}
static __always_inline void run_44(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovns esp,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RSP, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_NS)), 68719476736ULL);
}
static __always_inline void run_45(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovns edi,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RDI, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_CC_NS)), 68719476736ULL);
}
static __always_inline void run_46(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: shlx eax,DWORD PTR [rdi+16],ecx */
	X86_SIM_RUN_OP(X86_OP_SHIFTX_MEM, X86_RAX, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_RCX)), ((16ULL << 32) | X86_ALU_SHL));
}
static __always_inline void run_47(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: shrx eax,DWORD PTR [rdi+16],ecx */
	X86_SIM_RUN_OP(X86_OP_SHIFTX_MEM, X86_RAX, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_RCX)), ((16ULL << 32) | X86_ALU_SHR));
}
static __always_inline void run_48(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: sarx eax,DWORD PTR [rdi+16],ecx */
	X86_SIM_RUN_OP(X86_OP_SHIFTX_MEM, X86_RAX, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_RCX)), ((16ULL << 32) | X86_ALU_SAR));
}
static __always_inline void run_49(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: bzhi eax,DWORD PTR [rdi+16],ecx */
	X86_SIM_RUN_OP(X86_OP_BZHI_MEM, X86_RAX, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_RCX)), 16ULL);
}
static __always_inline void run_50(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: rorx eax,DWORD PTR [rdi+16],7 */
	X86_SIM_RUN_OP(X86_OP_RORX_MEM, X86_RAX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 68719476743ULL);
}
static __always_inline void run_51(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: andn eax,eax,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_ANDN_MEM(X86_RAX, X86_RAX, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_RDI)), 68719476736ULL);
}
static __always_inline void run_52(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: shlx ecx,DWORD PTR [rdi+16],ecx */
	X86_SIM_RUN_OP(X86_OP_SHIFTX_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_RCX)), ((16ULL << 32) | X86_ALU_SHL));
}
static __always_inline void run_53(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: shrx ecx,DWORD PTR [rdi+16],ecx */
	X86_SIM_RUN_OP(X86_OP_SHIFTX_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_RCX)), ((16ULL << 32) | X86_ALU_SHR));
}
static __always_inline void run_54(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: sarx ecx,DWORD PTR [rdi+16],ecx */
	X86_SIM_RUN_OP(X86_OP_SHIFTX_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_RCX)), ((16ULL << 32) | X86_ALU_SAR));
}
static __always_inline void run_55(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: bzhi ecx,DWORD PTR [rdi+16],ecx */
	X86_SIM_RUN_OP(X86_OP_BZHI_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_RCX)), 16ULL);
}
static __always_inline void run_56(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: rorx ecx,DWORD PTR [rdi+16],7 */
	X86_SIM_RUN_OP(X86_OP_RORX_MEM, X86_RCX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 68719476743ULL);
}
static __always_inline void run_57(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: andn ecx,eax,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_ANDN_MEM(X86_RCX, X86_RAX, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_RDI)), 68719476736ULL);
}
static __always_inline void run_58(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: shlx edx,DWORD PTR [rdi+16],ecx */
	X86_SIM_RUN_OP(X86_OP_SHIFTX_MEM, X86_RDX, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_RCX)), ((16ULL << 32) | X86_ALU_SHL));
}
static __always_inline void run_59(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: shrx edx,DWORD PTR [rdi+16],ecx */
	X86_SIM_RUN_OP(X86_OP_SHIFTX_MEM, X86_RDX, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_RCX)), ((16ULL << 32) | X86_ALU_SHR));
}
static __always_inline void run_60(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: sarx edx,DWORD PTR [rdi+16],ecx */
	X86_SIM_RUN_OP(X86_OP_SHIFTX_MEM, X86_RDX, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_RCX)), ((16ULL << 32) | X86_ALU_SAR));
}
static __always_inline void run_61(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: bzhi edx,DWORD PTR [rdi+16],ecx */
	X86_SIM_RUN_OP(X86_OP_BZHI_MEM, X86_RDX, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_RCX)), 16ULL);
}
static __always_inline void run_62(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: rorx edx,DWORD PTR [rdi+16],7 */
	X86_SIM_RUN_OP(X86_OP_RORX_MEM, X86_RDX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 68719476743ULL);
}
static __always_inline void run_63(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: andn edx,eax,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_ANDN_MEM(X86_RDX, X86_RAX, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_RDI)), 68719476736ULL);
}
static __always_inline void run_64(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: shlx ebx,DWORD PTR [rdi+16],ecx */
	X86_SIM_RUN_OP(X86_OP_SHIFTX_MEM, X86_RBX, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_RCX)), ((16ULL << 32) | X86_ALU_SHL));
}
static __always_inline void run_65(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: shrx ebx,DWORD PTR [rdi+16],ecx */
	X86_SIM_RUN_OP(X86_OP_SHIFTX_MEM, X86_RBX, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_RCX)), ((16ULL << 32) | X86_ALU_SHR));
}
static __always_inline void run_66(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: sarx ebx,DWORD PTR [rdi+16],ecx */
	X86_SIM_RUN_OP(X86_OP_SHIFTX_MEM, X86_RBX, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_RCX)), ((16ULL << 32) | X86_ALU_SAR));
}
static __always_inline void run_67(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: bzhi ebx,DWORD PTR [rdi+16],ecx */
	X86_SIM_RUN_OP(X86_OP_BZHI_MEM, X86_RBX, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_RCX)), 16ULL);
}
static __always_inline void run_68(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: rorx ebx,DWORD PTR [rdi+16],7 */
	X86_SIM_RUN_OP(X86_OP_RORX_MEM, X86_RBX, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 68719476743ULL);
}
static __always_inline void run_69(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: andn ebx,eax,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_ANDN_MEM(X86_RBX, X86_RAX, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_RDI)), 68719476736ULL);
}
static __always_inline void run_70(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: shlx esp,DWORD PTR [rdi+16],ecx */
	X86_SIM_RUN_OP(X86_OP_SHIFTX_MEM, X86_RSP, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_RCX)), ((16ULL << 32) | X86_ALU_SHL));
}
static __always_inline void run_71(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: shrx esp,DWORD PTR [rdi+16],ecx */
	X86_SIM_RUN_OP(X86_OP_SHIFTX_MEM, X86_RSP, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_RCX)), ((16ULL << 32) | X86_ALU_SHR));
}
static __always_inline void run_72(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: sarx esp,DWORD PTR [rdi+16],ecx */
	X86_SIM_RUN_OP(X86_OP_SHIFTX_MEM, X86_RSP, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_RCX)), ((16ULL << 32) | X86_ALU_SAR));
}
static __always_inline void run_73(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: bzhi esp,DWORD PTR [rdi+16],ecx */
	X86_SIM_RUN_OP(X86_OP_BZHI_MEM, X86_RSP, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_RCX)), 16ULL);
}
static __always_inline void run_74(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: rorx esp,DWORD PTR [rdi+16],7 */
	X86_SIM_RUN_OP(X86_OP_RORX_MEM, X86_RSP, X86_RDI, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 68719476743ULL);
}
static __always_inline void run_75(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: andn esp,eax,DWORD PTR [rdi+16] */
	X86_SIM_L_EXEC_ANDN_MEM(X86_RSP, X86_RAX, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_RDI)), 68719476736ULL);
}
static __always_inline void run_76(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: shlx ebp,DWORD PTR [rdi+16],ecx */
	X86_SIM_RUN_OP(X86_OP_SHIFTX_MEM, X86_RBP, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_RCX)), ((16ULL << 32) | X86_ALU_SHL));
}
static __always_inline void run_77(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: shrx ebp,DWORD PTR [rdi+16],ecx */
	X86_SIM_RUN_OP(X86_OP_SHIFTX_MEM, X86_RBP, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_RCX)), ((16ULL << 32) | X86_ALU_SHR));
}
static __always_inline void run_78(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: sarx ebp,DWORD PTR [rdi+16],ecx */
	X86_SIM_RUN_OP(X86_OP_SHIFTX_MEM, X86_RBP, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_RCX)), ((16ULL << 32) | X86_ALU_SAR));
}
static __always_inline void run_79(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: bzhi ebp,DWORD PTR [rdi+16],ecx */
	X86_SIM_RUN_OP(X86_OP_BZHI_MEM, X86_RBP, X86_RDI, X86_WIDTH_32, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32) | X86_REG_AUX_SRC_SHIFT(X86_RCX)), 16ULL);
}
int main(void){unsigned cases=0;
for(unsigned flags=0;flags<64;flags++)for(unsigned pattern=0;pattern<66;pattern++){
__u64 value=pattern<64?1ULL<<pattern:pattern==64?0:~0ULL;
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rdi.ptr=(void *)0;
expected.rdi_tag=X86_SIM_TAG_SCALAR;
calls=0;run_0(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=0 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rax.ptr=(void *)0;
expected.rax_tag=X86_SIM_TAG_SCALAR;
calls=0;run_1(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=1 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rsp.ptr=(void *)(unsigned long)(0ULL-state.native_stack_base);
expected.rsp_tag=X86_SIM_TAG_SCALAR;
calls=0;run_2(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=2 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rdi.ptr=(void *)0;
expected.rdi_tag=X86_SIM_TAG_SCALAR;
calls=0;run_3(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=3 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rax.ptr=(void *)0;
expected.rax_tag=X86_SIM_TAG_SCALAR;
calls=0;run_4(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=4 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rsp.ptr=(void *)(unsigned long)(0ULL-state.native_stack_base);
expected.rsp_tag=X86_SIM_TAG_SCALAR;
calls=0;run_5(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=5 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rdi.ptr=(void *)0;
expected.rdi_tag=X86_SIM_TAG_SCALAR;
calls=0;run_6(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=6 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rax.ptr=(void *)0;
expected.rax_tag=X86_SIM_TAG_SCALAR;
calls=0;run_7(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=7 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rsp.ptr=(void *)(unsigned long)(0ULL-state.native_stack_base);
expected.rsp_tag=X86_SIM_TAG_SCALAR;
calls=0;run_8(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=8 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rdi.ptr=(void *)0;
expected.rdi_tag=X86_SIM_TAG_SCALAR;
calls=0;run_9(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=9 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rax.ptr=(void *)0;
expected.rax_tag=X86_SIM_TAG_SCALAR;
calls=0;run_10(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=10 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rsp.ptr=(void *)(unsigned long)(0ULL-state.native_stack_base);
expected.rsp_tag=X86_SIM_TAG_SCALAR;
calls=0;run_11(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=11 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rdi.ptr=(void *)0;
expected.rdi_tag=X86_SIM_TAG_SCALAR;
calls=0;run_12(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=12 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rax.ptr=(void *)0;
expected.rax_tag=X86_SIM_TAG_SCALAR;
calls=0;run_13(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=13 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rsp.ptr=(void *)(unsigned long)(0ULL-state.native_stack_base);
expected.rsp_tag=X86_SIM_TAG_SCALAR;
calls=0;run_14(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=14 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rdi.ptr=(void *)0;
expected.rdi_tag=X86_SIM_TAG_SCALAR;
calls=0;run_15(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=15 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rax.ptr=(void *)0;
expected.rax_tag=X86_SIM_TAG_SCALAR;
calls=0;run_16(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=16 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rsp.ptr=(void *)(unsigned long)(0ULL-state.native_stack_base);
expected.rsp_tag=X86_SIM_TAG_SCALAR;
calls=0;run_17(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=17 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rdi.ptr=(void *)0;
expected.rdi_tag=X86_SIM_TAG_SCALAR;
calls=0;run_18(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=18 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rax.ptr=(void *)0;
expected.rax_tag=X86_SIM_TAG_SCALAR;
calls=0;run_19(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=19 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rsp.ptr=(void *)(unsigned long)(0ULL-state.native_stack_base);
expected.rsp_tag=X86_SIM_TAG_SCALAR;
calls=0;run_20(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=20 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rdi.ptr=(void *)0;
expected.rdi_tag=X86_SIM_TAG_SCALAR;
calls=0;run_21(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=21 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rax.ptr=(void *)0;
expected.rax_tag=X86_SIM_TAG_SCALAR;
calls=0;run_22(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=22 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rsp.ptr=(void *)(unsigned long)(0ULL-state.native_stack_base);
expected.rsp_tag=X86_SIM_TAG_SCALAR;
calls=0;run_23(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=23 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rdi.ptr=(void *)0;
expected.rdi_tag=X86_SIM_TAG_SCALAR;
calls=0;run_24(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=24 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rax.ptr=(void *)0;
expected.rax_tag=X86_SIM_TAG_SCALAR;
calls=0;run_25(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=25 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rsp.ptr=(void *)(unsigned long)(0ULL-state.native_stack_base);
expected.rsp_tag=X86_SIM_TAG_SCALAR;
calls=0;run_26(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=26 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rdi.ptr=(void *)0;
expected.rdi_tag=X86_SIM_TAG_SCALAR;
calls=0;run_27(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=27 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rax.ptr=(void *)0;
expected.rax_tag=X86_SIM_TAG_SCALAR;
calls=0;run_28(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=28 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rsp.ptr=(void *)(unsigned long)(0ULL-state.native_stack_base);
expected.rsp_tag=X86_SIM_TAG_SCALAR;
calls=0;run_29(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=29 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rdi.ptr=(void *)0;
expected.rdi_tag=X86_SIM_TAG_SCALAR;
calls=0;run_30(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=30 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rax.ptr=(void *)0;
expected.rax_tag=X86_SIM_TAG_SCALAR;
calls=0;run_31(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=31 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rsp.ptr=(void *)(unsigned long)(0ULL-state.native_stack_base);
expected.rsp_tag=X86_SIM_TAG_SCALAR;
calls=0;run_32(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=32 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rdi.ptr=(void *)0;
expected.rdi_tag=X86_SIM_TAG_SCALAR;
calls=0;run_33(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=33 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rax.ptr=(void *)0;
expected.rax_tag=X86_SIM_TAG_SCALAR;
calls=0;run_34(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=34 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rsp.ptr=(void *)(unsigned long)(0ULL-state.native_stack_base);
expected.rsp_tag=X86_SIM_TAG_SCALAR;
calls=0;run_35(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=35 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rdi.ptr=(void *)0;
expected.rdi_tag=X86_SIM_TAG_SCALAR;
calls=0;run_36(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=36 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rax.ptr=(void *)0;
expected.rax_tag=X86_SIM_TAG_SCALAR;
calls=0;run_37(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=37 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rsp.ptr=(void *)(unsigned long)(0ULL-state.native_stack_base);
expected.rsp_tag=X86_SIM_TAG_SCALAR;
calls=0;run_38(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=38 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rdi.ptr=(void *)0;
expected.rdi_tag=X86_SIM_TAG_SCALAR;
calls=0;run_39(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=39 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rax.ptr=(void *)0;
expected.rax_tag=X86_SIM_TAG_SCALAR;
calls=0;run_40(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=40 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rsp.ptr=(void *)(unsigned long)(0ULL-state.native_stack_base);
expected.rsp_tag=X86_SIM_TAG_SCALAR;
calls=0;run_41(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=41 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rdi.ptr=(void *)0;
expected.rdi_tag=X86_SIM_TAG_SCALAR;
calls=0;run_42(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=42 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rax.ptr=(void *)0;
expected.rax_tag=X86_SIM_TAG_SCALAR;
calls=0;run_43(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=43 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rsp.ptr=(void *)(unsigned long)(0ULL-state.native_stack_base);
expected.rsp_tag=X86_SIM_TAG_SCALAR;
calls=0;run_44(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=44 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rdi.ptr=(void *)0;
expected.rdi_tag=X86_SIM_TAG_SCALAR;
calls=0;run_45(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=45 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rax.ptr=(void *)0;
expected.rax_tag=X86_SIM_TAG_SCALAR;
calls=0;run_46(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=46 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rax.ptr=(void *)0;
expected.rax_tag=X86_SIM_TAG_SCALAR;
calls=0;run_47(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=47 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rax.ptr=(void *)0;
expected.rax_tag=X86_SIM_TAG_SCALAR;
calls=0;run_48(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=48 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rax.ptr=(void *)0;
expected.rax_tag=X86_SIM_TAG_SCALAR;
calls=0;run_49(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=49 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rax.ptr=(void *)0;
expected.rax_tag=X86_SIM_TAG_SCALAR;
calls=0;run_50(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=50 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rax.ptr=(void *)0;
expected.rax_tag=X86_SIM_TAG_SCALAR;
calls=0;run_51(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=51 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rcx.ptr=(void *)0;
expected.rcx_tag=X86_SIM_TAG_SCALAR;
calls=0;run_52(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=52 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rcx.ptr=(void *)0;
expected.rcx_tag=X86_SIM_TAG_SCALAR;
calls=0;run_53(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=53 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rcx.ptr=(void *)0;
expected.rcx_tag=X86_SIM_TAG_SCALAR;
calls=0;run_54(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=54 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rcx.ptr=(void *)0;
expected.rcx_tag=X86_SIM_TAG_SCALAR;
calls=0;run_55(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=55 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rcx.ptr=(void *)0;
expected.rcx_tag=X86_SIM_TAG_SCALAR;
calls=0;run_56(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=56 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rcx.ptr=(void *)0;
expected.rcx_tag=X86_SIM_TAG_SCALAR;
calls=0;run_57(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=57 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rdx.ptr=(void *)0;
expected.rdx_tag=X86_SIM_TAG_SCALAR;
calls=0;run_58(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=58 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rdx.ptr=(void *)0;
expected.rdx_tag=X86_SIM_TAG_SCALAR;
calls=0;run_59(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=59 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rdx.ptr=(void *)0;
expected.rdx_tag=X86_SIM_TAG_SCALAR;
calls=0;run_60(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=60 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rdx.ptr=(void *)0;
expected.rdx_tag=X86_SIM_TAG_SCALAR;
calls=0;run_61(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=61 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rdx.ptr=(void *)0;
expected.rdx_tag=X86_SIM_TAG_SCALAR;
calls=0;run_62(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=62 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rdx.ptr=(void *)0;
expected.rdx_tag=X86_SIM_TAG_SCALAR;
calls=0;run_63(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=63 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rbx.ptr=(void *)0;
expected.rbx_tag=X86_SIM_TAG_SCALAR;
calls=0;run_64(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=64 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rbx.ptr=(void *)0;
expected.rbx_tag=X86_SIM_TAG_SCALAR;
calls=0;run_65(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=65 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rbx.ptr=(void *)0;
expected.rbx_tag=X86_SIM_TAG_SCALAR;
calls=0;run_66(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=66 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rbx.ptr=(void *)0;
expected.rbx_tag=X86_SIM_TAG_SCALAR;
calls=0;run_67(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=67 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rbx.ptr=(void *)0;
expected.rbx_tag=X86_SIM_TAG_SCALAR;
calls=0;run_68(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=68 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rbx.ptr=(void *)0;
expected.rbx_tag=X86_SIM_TAG_SCALAR;
calls=0;run_69(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=69 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rsp.ptr=(void *)(unsigned long)(0ULL-state.native_stack_base);
expected.rsp_tag=X86_SIM_TAG_SCALAR;
calls=0;run_70(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=70 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rsp.ptr=(void *)(unsigned long)(0ULL-state.native_stack_base);
expected.rsp_tag=X86_SIM_TAG_SCALAR;
calls=0;run_71(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=71 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rsp.ptr=(void *)(unsigned long)(0ULL-state.native_stack_base);
expected.rsp_tag=X86_SIM_TAG_SCALAR;
calls=0;run_72(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=72 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rsp.ptr=(void *)(unsigned long)(0ULL-state.native_stack_base);
expected.rsp_tag=X86_SIM_TAG_SCALAR;
calls=0;run_73(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=73 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rsp.ptr=(void *)(unsigned long)(0ULL-state.native_stack_base);
expected.rsp_tag=X86_SIM_TAG_SCALAR;
calls=0;run_74(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=74 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rsp.ptr=(void *)(unsigned long)(0ULL-state.native_stack_base);
expected.rsp_tag=X86_SIM_TAG_SCALAR;
calls=0;run_75(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=75 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rbp.ptr=(void *)0;
expected.rbp_tag=X86_SIM_TAG_SCALAR;
calls=0;run_76(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=76 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rbp.ptr=(void *)0;
expected.rbp_tag=X86_SIM_TAG_SCALAR;
calls=0;run_77(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=77 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rbp.ptr=(void *)0;
expected.rbp_tag=X86_SIM_TAG_SCALAR;
calls=0;run_78(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=78 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rbp.ptr=(void *)0;
expected.rbp_tag=X86_SIM_TAG_SCALAR;
calls=0;run_79(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=79 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
}printf("Additional protected-read recovery: %u full-state cases OK\n",cases);return 0;}
