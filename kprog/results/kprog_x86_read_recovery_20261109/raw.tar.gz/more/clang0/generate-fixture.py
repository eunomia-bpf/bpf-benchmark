from pathlib import Path
import sys,importlib.util,json
G=Path(__file__).resolve().parent;R=Path('/workspaces/repository');F=R/'kprog/formal'
sys.path.insert(0,str(R/'kprog'));sys.path.insert(0,str(R/'kprog/x86/micro-prog'))
spec=importlib.util.spec_from_file_location('alu_fault_encoder',R/'kprog/x86/micro-prog/generate_micro_sim_proofs.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
registers=[('rax','eax','ax','al'),('rcx','ecx','cx','cl'),('rdx','edx','dx','dl'),('rbx','ebx','bx','bl'),('rsp','esp','sp','spl'),('rbp','ebp','bp','bpl'),('rsi','esi','si','sil'),('rdi','edi','di','dil')]+[(f'r{i}',f'r{i}d',f'r{i}w',f'r{i}b')for i in range(8,16)]
variants=[]
for bits,index,qual in [(64,0,'QWORD'),(32,1,'DWORD'),(16,2,'WORD'),(8,3,'BYTE')]:
 mem=f'{qual} PTR [rdi+16]'
 for op in ['cmp','test']:
  variants += [(op,(mem,'7'),None),(op,(mem,registers[0][index]),None)]
  if op=='cmp': variants.append((op,(registers[0][index],mem),None))
 for op in ['shl','shr','sar']:
  variants += [(op,(mem,'1'),None),(op,(mem,'cl'),None)]
 variants.append(('ror',(mem,'7'),None))
 variants.append(('div',(mem,),'rax'))
 if bits>=16:
  variants.append(('bt',(mem,'7'),None))
  for reg in registers:
   variants.append(('popcnt',(reg[index],mem),reg[0]))
   variants.append(('imul',(reg[index],mem,'-3'),reg[0]))
   variants.append(('imul',(reg[index],mem),reg[0]))
   variants.append(('movbe',(reg[index],mem),reg[0]))
  for cond in ['a','ae','b','be','e','ne','g','ge','l','le','o','no','p','np','s','ns']:
   for reg in [registers[0],registers[4],registers[7]]:
    variants.append(('cmov'+cond,(reg[index],mem),reg[0]))
 if bits in (32,64):
  for reg in registers:
   for op in ['shlx','shrx','sarx','bzhi']:
    variants.append((op,(reg[index],mem,'rcx' if bits==64 else 'ecx'),reg[0]))
   variants.append(('rorx',(reg[index],mem,'7'),reg[0]))
   variants.append(('andn',(reg[index],'rax' if bits==64 else 'eax',mem),reg[0]))
 if bits in (16,64):
  variants.append(('push',(mem,),None));variants.append(('pop',(mem,),None))
  for reg in registers:variants.append(('pop',(reg[index],),reg[0]))
for op in ['movups','movaps']:variants.append((op,('xmm0','XMMWORD PTR [rdi+16]'),None))
variants=variants[0:80]
source=['#define X86_SIM_USE_STATE_STRUCT','#define X86_SIM_ENABLE_STACK 1','#include "'+str(R/'kprog/x86/x86_sim_local_bpf.h')+'"','#include "'+str(F/'oracles/x86_no_helpers_host.h')+'"','#include <stdio.h>','#include <string.h>','static unsigned calls;','#undef X86_SIM_L_UNSPECIFIED','#define X86_SIM_L_UNSPECIFIED() (calls++,1U)','#undef __x86_sim_is_xdp','#define __x86_sim_is_xdp entry_mode']
for i,(op,args,destination)in enumerate(variants):
 insn=m.NativeInsn(0,op+' '+','.join(args),op,args);e=m.encode(insn,{});body=[];m.append_step(body,insn)
 source+=['static __always_inline void run_'+str(i)+'(struct x86_sim_state *state){','const __u8 entry_mode=state->is_xdp;','X86_SIM_L_BIND_COMMON_STATE(state);',*body,'}']
source+=['int main(void){unsigned cases=0;','for(unsigned flags=0;flags<64;flags++)for(unsigned pattern=0;pattern<66;pattern++){','__u64 value=pattern<64?1ULL<<pattern:pattern==64?0:~0ULL;']
for i,(_,_,dst)in enumerate(variants):
 source+=['{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);']
 for j,reg in enumerate(registers):source+=[f'state.{reg[0]}.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*{j+1}));state.{reg[0]}_tag=0x7f;']
 source+=['state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;','state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;','state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;']
 if dst is not None:
  source+=[f'expected.{dst}.ptr='+(('(void *)(unsigned long)(0ULL-state.native_stack_base);')if dst=='rsp'else'(void *)0;'),f'expected.{dst}_tag=X86_SIM_TAG_SCALAR;']
 source+=[f'calls=0;run_{i}(&state);',f'if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){{fprintf(stderr,"Read recovery variant={i} flags=%u pattern=%u calls=%u\\n",flags,pattern,calls);return 1;}}','cases++;}']
source+=['}printf("Additional protected-read recovery: %u full-state cases OK\\n",cases);return 0;}']
(G/'fault.c').write_text('\n'.join(source)+'\n');(G/'variants.json').write_text(json.dumps(variants,indent=2)+'\n');print('Additional encoded variants',len(variants))
