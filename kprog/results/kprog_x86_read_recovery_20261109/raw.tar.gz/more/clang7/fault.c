#define X86_SIM_USE_STATE_STRUCT
#define X86_SIM_ENABLE_STACK 1
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"
#include "/workspaces/repository/kprog/formal/oracles/x86_no_helpers_host.h"
#include <stdio.h>
#include <string.h>
static unsigned calls;
#undef X86_SIM_L_UNSPECIFIED
#define X86_SIM_L_UNSPECIFIED() (calls++,1U)
#undef __x86_sim_is_xdp
#define __x86_sim_is_xdp entry_mode
static __always_inline void run_0(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovg di,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RDI, X86_RDI, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_REG_AUX_SRC_SHIFT(X86_CC_G)), 68719476736ULL);
}
static __always_inline void run_1(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovge ax,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RAX, X86_RDI, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_REG_AUX_SRC_SHIFT(X86_CC_GE)), 68719476736ULL);
}
static __always_inline void run_2(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovge sp,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RSP, X86_RDI, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_REG_AUX_SRC_SHIFT(X86_CC_GE)), 68719476736ULL);
}
static __always_inline void run_3(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovge di,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RDI, X86_RDI, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_REG_AUX_SRC_SHIFT(X86_CC_GE)), 68719476736ULL);
}
static __always_inline void run_4(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovl ax,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RAX, X86_RDI, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_REG_AUX_SRC_SHIFT(X86_CC_L)), 68719476736ULL);
}
static __always_inline void run_5(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovl sp,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RSP, X86_RDI, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_REG_AUX_SRC_SHIFT(X86_CC_L)), 68719476736ULL);
}
static __always_inline void run_6(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovl di,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RDI, X86_RDI, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_REG_AUX_SRC_SHIFT(X86_CC_L)), 68719476736ULL);
}
static __always_inline void run_7(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovle ax,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RAX, X86_RDI, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_REG_AUX_SRC_SHIFT(X86_CC_LE)), 68719476736ULL);
}
static __always_inline void run_8(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovle sp,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RSP, X86_RDI, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_REG_AUX_SRC_SHIFT(X86_CC_LE)), 68719476736ULL);
}
static __always_inline void run_9(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovle di,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RDI, X86_RDI, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_REG_AUX_SRC_SHIFT(X86_CC_LE)), 68719476736ULL);
}
static __always_inline void run_10(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovo ax,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RAX, X86_RDI, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_REG_AUX_SRC_SHIFT(X86_CC_O)), 68719476736ULL);
}
static __always_inline void run_11(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovo sp,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RSP, X86_RDI, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_REG_AUX_SRC_SHIFT(X86_CC_O)), 68719476736ULL);
}
static __always_inline void run_12(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovo di,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RDI, X86_RDI, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_REG_AUX_SRC_SHIFT(X86_CC_O)), 68719476736ULL);
}
static __always_inline void run_13(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovno ax,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RAX, X86_RDI, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_REG_AUX_SRC_SHIFT(X86_CC_NO)), 68719476736ULL);
}
static __always_inline void run_14(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovno sp,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RSP, X86_RDI, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_REG_AUX_SRC_SHIFT(X86_CC_NO)), 68719476736ULL);
}
static __always_inline void run_15(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovno di,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RDI, X86_RDI, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_REG_AUX_SRC_SHIFT(X86_CC_NO)), 68719476736ULL);
}
static __always_inline void run_16(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovp ax,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RAX, X86_RDI, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_REG_AUX_SRC_SHIFT(X86_CC_P)), 68719476736ULL);
}
static __always_inline void run_17(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovp sp,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RSP, X86_RDI, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_REG_AUX_SRC_SHIFT(X86_CC_P)), 68719476736ULL);
}
static __always_inline void run_18(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovp di,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RDI, X86_RDI, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_REG_AUX_SRC_SHIFT(X86_CC_P)), 68719476736ULL);
}
static __always_inline void run_19(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovnp ax,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RAX, X86_RDI, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_REG_AUX_SRC_SHIFT(X86_CC_NP)), 68719476736ULL);
}
static __always_inline void run_20(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovnp sp,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RSP, X86_RDI, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_REG_AUX_SRC_SHIFT(X86_CC_NP)), 68719476736ULL);
}
static __always_inline void run_21(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovnp di,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RDI, X86_RDI, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_REG_AUX_SRC_SHIFT(X86_CC_NP)), 68719476736ULL);
}
static __always_inline void run_22(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovs ax,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RAX, X86_RDI, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_REG_AUX_SRC_SHIFT(X86_CC_S)), 68719476736ULL);
}
static __always_inline void run_23(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovs sp,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RSP, X86_RDI, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_REG_AUX_SRC_SHIFT(X86_CC_S)), 68719476736ULL);
}
static __always_inline void run_24(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovs di,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RDI, X86_RDI, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_REG_AUX_SRC_SHIFT(X86_CC_S)), 68719476736ULL);
}
static __always_inline void run_25(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovns ax,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RAX, X86_RDI, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_REG_AUX_SRC_SHIFT(X86_CC_NS)), 68719476736ULL);
}
static __always_inline void run_26(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovns sp,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RSP, X86_RDI, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_REG_AUX_SRC_SHIFT(X86_CC_NS)), 68719476736ULL);
}
static __always_inline void run_27(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmovns di,WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_CMOV_MEM(X86_RDI, X86_RDI, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_REG_AUX_SRC_SHIFT(X86_CC_NS)), 68719476736ULL);
}
static __always_inline void run_28(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: push WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_PUSH_OP(X86_RDI, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_PUSHPOP_AUX_MEM), 16ULL);
}
static __always_inline void run_29(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: pop WORD PTR [rdi+16] */
	X86_SIM_L_EXEC_POP_OP(X86_RDI, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_PUSHPOP_AUX_MEM), 16ULL);
}
static __always_inline void run_30(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: pop ax */
	X86_SIM_L_EXEC_POP_OP(X86_RAX, X86_WIDTH_16, 0, 0);
}
static __always_inline void run_31(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: pop cx */
	X86_SIM_L_EXEC_POP_OP(X86_RCX, X86_WIDTH_16, 0, 0);
}
static __always_inline void run_32(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: pop dx */
	X86_SIM_L_EXEC_POP_OP(X86_RDX, X86_WIDTH_16, 0, 0);
}
static __always_inline void run_33(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: pop bx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_16, 0, 0);
}
static __always_inline void run_34(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: pop sp */
	X86_SIM_L_EXEC_POP_OP(X86_RSP, X86_WIDTH_16, 0, 0);
}
static __always_inline void run_35(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: pop bp */
	X86_SIM_L_EXEC_POP_OP(X86_RBP, X86_WIDTH_16, 0, 0);
}
static __always_inline void run_36(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: pop si */
	X86_SIM_L_EXEC_POP_OP(X86_RSI, X86_WIDTH_16, 0, 0);
}
static __always_inline void run_37(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: pop di */
	X86_SIM_L_EXEC_POP_OP(X86_RDI, X86_WIDTH_16, 0, 0);
}
static __always_inline void run_38(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: pop r8w */
	X86_SIM_L_EXEC_POP_OP(X86_R8, X86_WIDTH_16, 0, 0);
}
static __always_inline void run_39(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: pop r9w */
	X86_SIM_L_EXEC_POP_OP(X86_R9, X86_WIDTH_16, 0, 0);
}
static __always_inline void run_40(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: pop r10w */
	X86_SIM_L_EXEC_POP_OP(X86_R10, X86_WIDTH_16, 0, 0);
}
static __always_inline void run_41(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: pop r11w */
	X86_SIM_L_EXEC_POP_OP(X86_R11, X86_WIDTH_16, 0, 0);
}
static __always_inline void run_42(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: pop r12w */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_16, 0, 0);
}
static __always_inline void run_43(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: pop r13w */
	X86_SIM_L_EXEC_POP_OP(X86_R13, X86_WIDTH_16, 0, 0);
}
static __always_inline void run_44(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: pop r14w */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_16, 0, 0);
}
static __always_inline void run_45(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: pop r15w */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_16, 0, 0);
}
static __always_inline void run_46(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmp BYTE PTR [rdi+16],7 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 68719476743ULL);
}
static __always_inline void run_47(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmp BYTE PTR [rdi+16],al */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_REG, X86_RDI, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_48(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: cmp al,BYTE PTR [rdi+16] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_RDI, X86_WIDTH_8, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 16ULL);
}
static __always_inline void run_49(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: test BYTE PTR [rdi+16],7 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_IMM, X86_RDI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 68719476743ULL);
}
static __always_inline void run_50(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: test BYTE PTR [rdi+16],al */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_REG, X86_RDI, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
}
static __always_inline void run_51(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: shl BYTE PTR [rdi+16],1 */
	X86_SIM_L_EXEC_ALU_MEM_IMM(X86_RDI, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_SHL)), 68719476737ULL);
}
static __always_inline void run_52(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: shl BYTE PTR [rdi+16],cl */
	X86_SIM_L_EXEC_ALU_MEM_REG(X86_RDI, X86_RCX, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_SHL)), 16ULL);
}
static __always_inline void run_53(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: shr BYTE PTR [rdi+16],1 */
	X86_SIM_L_EXEC_ALU_MEM_IMM(X86_RDI, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_SHR)), 68719476737ULL);
}
static __always_inline void run_54(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: shr BYTE PTR [rdi+16],cl */
	X86_SIM_L_EXEC_ALU_MEM_REG(X86_RDI, X86_RCX, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_SHR)), 16ULL);
}
static __always_inline void run_55(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: sar BYTE PTR [rdi+16],1 */
	X86_SIM_L_EXEC_ALU_MEM_IMM(X86_RDI, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_SAR)), 68719476737ULL);
}
static __always_inline void run_56(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: sar BYTE PTR [rdi+16],cl */
	X86_SIM_L_EXEC_ALU_MEM_REG(X86_RDI, X86_RCX, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_SAR)), 16ULL);
}
static __always_inline void run_57(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: ror BYTE PTR [rdi+16],7 */
	X86_SIM_L_EXEC_ROR_MEM(X86_RDI, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_REG_AUX_SRC_SHIFT(7ULL)), 16ULL);
}
static __always_inline void run_58(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: div BYTE PTR [rdi+16] */
	if (!X86_SIM_L_READ_RECOVERY(X86_RDI, X86_RAX)) {
		X86_SIM_RUN_OP(X86_OP_DIV, X86_REG_NONE, X86_REG_NONE, X86_WIDTH_8, 0, X86_SIM_L_READ_MEM_VALUE(X86_RDI, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL, X86_WIDTH_8, 0));
	}
}
static __always_inline void run_59(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: movups xmm0,XMMWORD PTR [rdi+16] */
	X86_SIM_RUN_OP(X86_OP_LOAD_XMM0, X86_REG_NONE, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
static __always_inline void run_60(struct x86_sim_state *state){
const __u8 entry_mode=state->is_xdp;
X86_SIM_L_BIND_COMMON_STATE(state);
	/* 0x0: movaps xmm0,XMMWORD PTR [rdi+16] */
	X86_SIM_RUN_OP(X86_OP_LOAD_XMM0, X86_REG_NONE, X86_RDI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
}
int main(void){unsigned cases=0;
for(unsigned flags=0;flags<64;flags++)for(unsigned pattern=0;pattern<66;pattern++){
__u64 value=pattern<64?1ULL<<pattern:pattern==64?0:~0ULL;
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rdi.ptr=(void *)0;
expected.rdi_tag=X86_SIM_TAG_SCALAR;
calls=0;run_0(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=0 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rax.ptr=(void *)0;
expected.rax_tag=X86_SIM_TAG_SCALAR;
calls=0;run_1(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=1 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rsp.ptr=(void *)(unsigned long)(0ULL-state.native_stack_base);
expected.rsp_tag=X86_SIM_TAG_SCALAR;
calls=0;run_2(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=2 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rdi.ptr=(void *)0;
expected.rdi_tag=X86_SIM_TAG_SCALAR;
calls=0;run_3(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=3 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rax.ptr=(void *)0;
expected.rax_tag=X86_SIM_TAG_SCALAR;
calls=0;run_4(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=4 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rsp.ptr=(void *)(unsigned long)(0ULL-state.native_stack_base);
expected.rsp_tag=X86_SIM_TAG_SCALAR;
calls=0;run_5(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=5 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rdi.ptr=(void *)0;
expected.rdi_tag=X86_SIM_TAG_SCALAR;
calls=0;run_6(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=6 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rax.ptr=(void *)0;
expected.rax_tag=X86_SIM_TAG_SCALAR;
calls=0;run_7(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=7 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rsp.ptr=(void *)(unsigned long)(0ULL-state.native_stack_base);
expected.rsp_tag=X86_SIM_TAG_SCALAR;
calls=0;run_8(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=8 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rdi.ptr=(void *)0;
expected.rdi_tag=X86_SIM_TAG_SCALAR;
calls=0;run_9(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=9 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rax.ptr=(void *)0;
expected.rax_tag=X86_SIM_TAG_SCALAR;
calls=0;run_10(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=10 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rsp.ptr=(void *)(unsigned long)(0ULL-state.native_stack_base);
expected.rsp_tag=X86_SIM_TAG_SCALAR;
calls=0;run_11(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=11 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rdi.ptr=(void *)0;
expected.rdi_tag=X86_SIM_TAG_SCALAR;
calls=0;run_12(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=12 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rax.ptr=(void *)0;
expected.rax_tag=X86_SIM_TAG_SCALAR;
calls=0;run_13(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=13 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rsp.ptr=(void *)(unsigned long)(0ULL-state.native_stack_base);
expected.rsp_tag=X86_SIM_TAG_SCALAR;
calls=0;run_14(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=14 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rdi.ptr=(void *)0;
expected.rdi_tag=X86_SIM_TAG_SCALAR;
calls=0;run_15(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=15 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rax.ptr=(void *)0;
expected.rax_tag=X86_SIM_TAG_SCALAR;
calls=0;run_16(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=16 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rsp.ptr=(void *)(unsigned long)(0ULL-state.native_stack_base);
expected.rsp_tag=X86_SIM_TAG_SCALAR;
calls=0;run_17(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=17 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rdi.ptr=(void *)0;
expected.rdi_tag=X86_SIM_TAG_SCALAR;
calls=0;run_18(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=18 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rax.ptr=(void *)0;
expected.rax_tag=X86_SIM_TAG_SCALAR;
calls=0;run_19(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=19 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rsp.ptr=(void *)(unsigned long)(0ULL-state.native_stack_base);
expected.rsp_tag=X86_SIM_TAG_SCALAR;
calls=0;run_20(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=20 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rdi.ptr=(void *)0;
expected.rdi_tag=X86_SIM_TAG_SCALAR;
calls=0;run_21(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=21 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rax.ptr=(void *)0;
expected.rax_tag=X86_SIM_TAG_SCALAR;
calls=0;run_22(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=22 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rsp.ptr=(void *)(unsigned long)(0ULL-state.native_stack_base);
expected.rsp_tag=X86_SIM_TAG_SCALAR;
calls=0;run_23(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=23 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rdi.ptr=(void *)0;
expected.rdi_tag=X86_SIM_TAG_SCALAR;
calls=0;run_24(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=24 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rax.ptr=(void *)0;
expected.rax_tag=X86_SIM_TAG_SCALAR;
calls=0;run_25(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=25 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rsp.ptr=(void *)(unsigned long)(0ULL-state.native_stack_base);
expected.rsp_tag=X86_SIM_TAG_SCALAR;
calls=0;run_26(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=26 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rdi.ptr=(void *)0;
expected.rdi_tag=X86_SIM_TAG_SCALAR;
calls=0;run_27(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=27 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
calls=0;run_28(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=28 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
calls=0;run_29(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=29 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rax.ptr=(void *)0;
expected.rax_tag=X86_SIM_TAG_SCALAR;
calls=0;run_30(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=30 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rcx.ptr=(void *)0;
expected.rcx_tag=X86_SIM_TAG_SCALAR;
calls=0;run_31(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=31 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rdx.ptr=(void *)0;
expected.rdx_tag=X86_SIM_TAG_SCALAR;
calls=0;run_32(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=32 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rbx.ptr=(void *)0;
expected.rbx_tag=X86_SIM_TAG_SCALAR;
calls=0;run_33(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=33 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rsp.ptr=(void *)(unsigned long)(0ULL-state.native_stack_base);
expected.rsp_tag=X86_SIM_TAG_SCALAR;
calls=0;run_34(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=34 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rbp.ptr=(void *)0;
expected.rbp_tag=X86_SIM_TAG_SCALAR;
calls=0;run_35(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=35 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rsi.ptr=(void *)0;
expected.rsi_tag=X86_SIM_TAG_SCALAR;
calls=0;run_36(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=36 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rdi.ptr=(void *)0;
expected.rdi_tag=X86_SIM_TAG_SCALAR;
calls=0;run_37(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=37 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.r8.ptr=(void *)0;
expected.r8_tag=X86_SIM_TAG_SCALAR;
calls=0;run_38(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=38 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.r9.ptr=(void *)0;
expected.r9_tag=X86_SIM_TAG_SCALAR;
calls=0;run_39(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=39 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.r10.ptr=(void *)0;
expected.r10_tag=X86_SIM_TAG_SCALAR;
calls=0;run_40(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=40 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.r11.ptr=(void *)0;
expected.r11_tag=X86_SIM_TAG_SCALAR;
calls=0;run_41(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=41 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.r12.ptr=(void *)0;
expected.r12_tag=X86_SIM_TAG_SCALAR;
calls=0;run_42(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=42 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.r13.ptr=(void *)0;
expected.r13_tag=X86_SIM_TAG_SCALAR;
calls=0;run_43(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=43 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.r14.ptr=(void *)0;
expected.r14_tag=X86_SIM_TAG_SCALAR;
calls=0;run_44(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=44 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.r15.ptr=(void *)0;
expected.r15_tag=X86_SIM_TAG_SCALAR;
calls=0;run_45(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=45 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
calls=0;run_46(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=46 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
calls=0;run_47(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=47 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
calls=0;run_48(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=48 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
calls=0;run_49(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=49 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
calls=0;run_50(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=50 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
calls=0;run_51(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=51 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
calls=0;run_52(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=52 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
calls=0;run_53(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=53 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
calls=0;run_54(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=54 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
calls=0;run_55(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=55 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
calls=0;run_56(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=56 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
calls=0;run_57(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=57 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
expected.rax.ptr=(void *)0;
expected.rax_tag=X86_SIM_TAG_SCALAR;
calls=0;run_58(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=58 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
calls=0;run_59(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=59 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
{struct x86_sim_state state={0};__u8 untouched[32];memset(untouched,0xa5,sizeof untouched);__u8 before[32];memcpy(before,untouched,32);
state.rax.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*1));state.rax_tag=0x7f;
state.rcx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*2));state.rcx_tag=0x7f;
state.rdx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*3));state.rdx_tag=0x7f;
state.rbx.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*4));state.rbx_tag=0x7f;
state.rsp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*5));state.rsp_tag=0x7f;
state.rbp.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*6));state.rbp_tag=0x7f;
state.rsi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*7));state.rsi_tag=0x7f;
state.rdi.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*8));state.rdi_tag=0x7f;
state.r8.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*9));state.r8_tag=0x7f;
state.r9.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*10));state.r9_tag=0x7f;
state.r10.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*11));state.r10_tag=0x7f;
state.r11.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*12));state.r11_tag=0x7f;
state.r12.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*13));state.r12_tag=0x7f;
state.r13.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*14));state.r13_tag=0x7f;
state.r14.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*15));state.r14_tag=0x7f;
state.r15.ptr=(void *)(unsigned long)(value^(0x9e3779b97f4a7c15ULL*16));state.r15_tag=0x7f;
state.rsp.ptr=(void *)0x60;state.rsp_tag=X86_SIM_TAG_SCALAR;state.rdi.ptr=(void *)0x60;state.rdi_tag=X86_SIM_TAG_SCALAR;state.native_stack_base=0x100000000000ULL;state.abi_kind=X86_SIM_ABI_KIND_RAW;
state.cf=flags&1;state.pf=(flags>>1)&1;state.af=(flags>>2)&1;state.zf=(flags>>3)&1;state.sf=(flags>>4)&1;state.of=(flags>>5)&1;
state.xmm0_lo=value;state.xmm0_hi=~value;memset(state.stack_mem.b,0xab,sizeof state.stack_mem.b);struct x86_sim_state expected=state;
calls=0;run_60(&state);
if(calls!=1||memcmp(&state,&expected,sizeof state)||memcmp(before,untouched,32)){fprintf(stderr,"Read recovery variant=60 flags=%u pattern=%u calls=%u\n",flags,pattern,calls);return 1;}
cases++;}
}printf("Additional protected-read recovery: %u full-state cases OK\n",cases);return 0;}
