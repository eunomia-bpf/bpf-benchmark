#!/bin/bash
ulimit -c 0
export TMPDIR=/var/tmp/kprog-tmp/S1
unshare --mount --propagation private python3 /var/tmp/kprog-tmp/S1/host-published-mount.py > /var/tmp/kprog-tmp/S1/host-published.log 2>&1
echo $? > /var/tmp/kprog-tmp/S1/host-published.exit
