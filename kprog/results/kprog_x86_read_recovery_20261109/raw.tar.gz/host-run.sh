#!/bin/bash
cd /workspaces/repository/kprog/formal
ulimit -c 0
export TMPDIR=/var/tmp/kprog-tmp/S1
make -f /var/tmp/kprog-tmp/S1/host.mk host > /var/tmp/kprog-tmp/S1/host.log 2>&1
echo $? > /var/tmp/kprog-tmp/S1/host.exit
