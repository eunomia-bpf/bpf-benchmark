from pathlib import Path
import os,subprocess
R=Path('/workspaces/repository');G=Path('/var/tmp/kprog-tmp/S1')
for p in sorted((G/'host-source').rglob('*')):
 if p.is_file():subprocess.run(['mount','--bind',str(p),str(R/p.relative_to(G/'host-source'))],check=True)
os.chdir(R/'kprog/formal');os.execvp('make',['make','-f',str(G/'host.mk'),'host'])
