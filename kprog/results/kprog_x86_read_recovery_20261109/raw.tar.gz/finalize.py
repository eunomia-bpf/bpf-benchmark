from pathlib import Path
import os,select,sys,json,hashlib,tarfile,subprocess,datetime,csv,io,re
R=Path('/workspaces/repository');G=Path('/var/tmp/kprog-tmp/S1')
STATE=Path('/workspaces/.agent-state/kprog-lanes/S1')
def save(**kw):(STATE/'final.json').write_text(json.dumps(kw,indent=2)+'\n')
save(state='collecting_final_host',pid=os.getpid())
try:
 try:
  fd=os.pidfd_open(2867770);select.select([fd],[],[]);os.close(fd)
 except ProcessLookupError:pass
 names=['component','more-split','rep','micro','safety','host-published','host-rest']
 exits={n:int((G/(n+'.exit')).read_text())for n in names}
 assert all(x==0 for x in exits.values()),exits
 initial=json.loads((G/'source-pins.json').read_text())
 final=json.loads((G/'final-source-pins.json').read_text())
 for n,h in final.items():assert hashlib.sha256((R/n).read_bytes()).hexdigest()==h,n
 rows=json.loads((G/'safety/safety/outcomes.json').read_text())
 stages={s:sum(r['stage']==s for r in rows)for s in sorted({r['stage']for r in rows})}
 assert len(rows)==38 and stages=={'valid_executed':9,'verifier_rejected':28,'specialization_rejected':1},stages
 micro=[x for x in (G/'micro.log').read_text().splitlines()if ': ok:' in x]
 assert len(micro)==30
 split=[int(x)for x in re.findall(r'Additional protected-read recovery: (\d+) full-state cases OK',(G/'more-split.log').read_text())]
 assert sum(split)==2623104 and len(split)==8
 host_recipe=(G/'host.mk').read_text()
 host_runs=[x.strip()for x in host_recipe.splitlines()if x.startswith('\t/var/tmp')]
 assert len(host_runs)==135
 hostlog=(G/'host-published.log').read_text()
 assert all(x in hostlog.splitlines()for x in host_runs)
 publications={n:json.loads((G/(n+'-publication.json')).read_text())['commit']for n in ['production','rep','andn']}
 summary=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
  production_commits=publications,source_sha256=final,
  initial_component_source_sha256=initial,make_exits=exits,
  host_executables=135,host_compile_recipes=136,
  component_cases_per_compiler=dict(mov=2061312,alu=2196480,additional=2623104,rep=549120,total=7430016),
  compilers=['gcc13','clang18'],additional_clang_units=split,
  micro_compile_cases=30,safety_cases=len(rows),safety_stages=stages,
  unsafe_native_executions=0,production_admission_additions=0,
  coverage=json.loads((G/'coverage-plan.json').read_text()),
  remaining=[
   dict(form='RET entry and subroutine',reason='Structured return/entry-ABI macros require an explicit physical next-PC fallthrough relation for a recovered return-stack read.'),
   dict(form='CALL_MEMCPY and CALL_MEMCPY_REG',reason='The external-body abstraction requires actual called instruction bytes, per-PC exception sites and completed-prefix/clobber mapping.'),
   dict(form='PUSH memory later stack write; POP memory destination write; REP destination write',reason='The source-read recovery component is measured. Later write-side faults require a transactional full-instruction/prefix relation, including saved-SP ordering and completed stores.'),
   dict(form='Typed context/stack/map/packet/immutable reads',reason='Existing typed routes retain their universal valid-address/lifetime and permission premise. The fresh read-recovery choice is attached to scalar-address routes.'),
   dict(form='Whole compiled-B/native platform relation',reason='V retains universal O1/O2/O3/compiler, exact decoder-site/frame/handler registration and physical event projection obligations.')
  ])
 O=R/'kprog/results/kprog_x86_read_recovery_20261109';O.mkdir(parents=True,exist_ok=True)
 (O/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 table='\n'.join('| '+r['forms']+' | '+r['table_destination']+' | '+r['recovery']+' |'for r in summary['coverage'])
 remaining='\n'.join('- **'+r['form']+'**: '+r['reason']for r in summary['remaining'])
 (O/'README.md').write_text('''# x86 protected-read recovery
S1 integrates the existing protected-read environment pattern into the production x86 header and generator. Read recovery precedes the scalar-address instruction effects, uses the current native-link exception-table destination, and resumes the next simulated instruction. Register destinations clear their full saved GPR; resume-only profiles retain the complete original state. The successful non-REP macro-body tokens reproduce the entry source after the added recovery arms are erased. REP assigns its completed count inside the recovery branch and preserves the original successful pointer advancement.

Production: `'''+publications['production']+'''`. REP success preservation: `'''+publications['rep']+'''`. ANDN host environment alignment: `'''+publications['andn']+'''`.

| Accepted read forms | Stock table destination | Recovery state |
| --- | --- | --- |
'''+table+'''

The MOV high-byte and DIV memory encodings carry reads inside their immediate expression. Their generator recovery arm surrounds expression evaluation. XMM0 preserves both original vector lanes because its table destination is resume-only. Forward REP retains every completed copy and advances RSI/RDI by that prefix; the table clears RCX.

Validation: 135 existing host executables and 136 compile recipes finish with make exit 0 from a private source snapshot. The 244 MOV forms, 520 ALU forms and 621 additional forms exercise the actual encoder-emitted handlers. GCC and Clang each pass 7,430,016 full-state cases, including 549,120 protected-page REP cases over every count 0-64, every completed prefix, all four widths and all 64 incoming flag states. The existing host oracles retain their original input domains. ANDN explicitly supplies the valid read outcome before both original independent PF/AF choices, and checks consumption of all three outcomes.

The 29 positive micro cases and the existing negative compile case all compile from the final production header. The final 2 GiB guest safety cohort completes all 38 original cases: 9 valid executions, 28 verifier rejections and 1 generation frontier (`unbounded_indirect_jump`). Risky native executions: 0. The final guest pins its source, native link, loader library, module and kernel. It runs the original fixture bytes and annotation expectations.

An initial REP oracle exposed a new success-path truncation, corrected by the REP commit above. The initial combined Clang fixture reached its source-location capacity; eight translation units retain all 621 forms and all 2,623,104 cases. Initial compiler diagnostics and oracle observations accompany the terminal results. Component MOV/ALU/additional receipts use the first production epoch; the final REP, host snapshot, 30 compile cases and 38 safety cases use the final header. summary.json records both epochs.

Named completion interfaces:

'''+remaining+'''

These are measured production/model components and explicit universal interfaces. V owns the full formal check and the universal recovery/compiler/platform rows. Runtime admission additions: 0. The frozen workload and paper paths retain their recorded definitions.

raw.tar.gz contains commands, fixture generators, original/derived host inputs, source snapshots and hashes, all terminal logs, the final safety native/B/request records and micro compiler metadata. Build executables, compiler caches and kernel trees remain temporary outputs.
''')
 # Small, reproducible inputs and observations; retain the actual final B/P records.
 paths=[]
 for p in G.rglob('*'):
  if not p.is_file():continue
  rel=p.relative_to(G);parts=rel.parts
  if p.suffix in {'.log','.exit','.mk','.py','.json','.jsonl','.md','.rs','.sh'}:paths.append(p)
  elif p.suffix in {'.c','.h'} and p.stat().st_size<8*1024*1024:paths.append(p)
  elif parts[:2]==('safety','safety') and p.suffix in {'.o','.stdout','.stderr'}:paths.append(p)
  elif parts and parts[0]in{'micro-build','negative-build'} and p.suffix=='.o':paths.append(p)
 # Include source snapshots, excluding generated preprocessor crash material.
 paths=sorted(set(paths))
 manifest={str(p.relative_to(G)):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in paths}
 (O/'raw-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 with tarfile.open(O/'raw.tar.gz','w:gz')as t:
  for p in paths:t.add(p,arcname=str(p.relative_to(G)))
 assert (O/'raw.tar.gz').stat().st_size<20*1024*1024
 with tarfile.open(O/'raw.tar.gz')as t:
  for n,meta in manifest.items():
   data=t.extractfile(n).read();assert len(data)==meta['bytes']and hashlib.sha256(data).hexdigest()==meta['sha256'],n
 sys.path.insert(0,'/workspaces/.agent-state/kprog-lanes/C');from publish_owned import publish
 commit=publish([str(p.relative_to(R))for p in O.iterdir()if p.is_file()],
  'Record x86 protected-read forms and terminal recovery evidence',STATE/'evidence-publication.json')
 # Supply V with the existing row plus additive source/evidence and scope text.
 coverage=R/'kprog/results/kprog_verification_20261107/coverage.tsv'
 with coverage.open()as f:
  reader=csv.DictReader(f,delimiter='\t');fieldnames=reader.fieldnames
  row=next(x for x in reader if x['operation']=='LOAD_FAULT_RECOVERY')
 row['o4_evidence']+=';'+str(O.relative_to(R))+'/README.md;'+str(O.relative_to(R))+'/summary.json'
 row['o4_completion']+=' S1 production scalar-read prefixes now cover all listed scalar/vector/POP/REP forms under final header '+final['kprog/x86/x86_sim_local_bpf.h']+'. RET/external-copy/later-write prefixes, typed-route lifetime and whole compiled-B/physical correspondence remain named interfaces.'
 row['o4_publication']+=';x86-prefix-model:'+publications['rep']+';x86-evidence:'+commit
 output=io.StringIO();writer=csv.DictWriter(output,fieldnames=fieldnames,delimiter='\t',lineterminator='\n');writer.writerow(row)
 notice='\n- S1 '+summary['utc']+': PUSHED '+commit+' terminal evidence. Existing135host/136compile recipes make0; GCC+Clang each7430016 full-state cases; final30micro compile0; final38=9valid/28verifier/1generation frontier, risky executions0. Source commits '+','.join(publications.values())+'. Named RET/external-copy/later-write/typed-lifetime/compiler-physical interfaces retained. V merges this additive LOAD_FAULT_RECOVERY row text:\n\n```tsv\n'+output.getvalue()+'```\n'
 with (STATE.parent/'COORDINATION.md').open('a')as f:f.write(notice)
 save(state='published',evidence_commit=commit,source_commits=publications,archive_bytes=(O/'raw.tar.gz').stat().st_size,archive_members=len(manifest),make_exits=exits,remaining=summary['remaining'])
except BaseException as e:
 import traceback
 save(state='requires_continuation',error=str(e),traceback=traceback.format_exc());raise
