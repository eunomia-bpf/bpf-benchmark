ARM64_HOST_ENV := -include oracles/arm64_entry_environment_host.h -DKPROG_TEST_EXCLUSIVE_FAILURE=0 -include oracles/arm64_exclusive_choice_host.h
CC := gcc
.PHONY: host
host:
	$(CC) -Wall -Wextra -O2 -fsanitize=undefined -fno-sanitize-recover=undefined -I. -I../x86 -I../../vendor/libbpf/src oracles/test_x86_six_flags_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_six_flags_host
	/var/tmp/kprog-tmp/S1/host/test_x86_six_flags_host
	$(CC) -Wall -Wextra -O2 -fsanitize=undefined -fno-sanitize-recover=undefined -I. -I../x86 -I../../vendor/libbpf/src oracles/test_x86_full_condition_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_full_condition_host
	/var/tmp/kprog-tmp/S1/host/test_x86_full_condition_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_branch_emit_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_branch_emit_host
	/var/tmp/kprog-tmp/S1/host/test_x86_branch_emit_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_branch_emit_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_branch_emit_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_branch_emit_route_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/width_fallback_host.c -o /var/tmp/kprog-tmp/S1/host/width_fallback_host
	/var/tmp/kprog-tmp/S1/host/width_fallback_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 oracles/test_x86_alu_result_arm_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_alu_result_arm_host
	/var/tmp/kprog-tmp/S1/host/test_x86_alu_result_arm_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_alu_result_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_alu_result_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_alu_result_route_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_alu_mem_result_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_alu_mem_result_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_alu_mem_result_route_host
	$(CC) -Wall -Wextra -O2 -mno-red-zone -fsanitize=undefined -fno-sanitize-recover=all -I. -I../x86 -I../../vendor/libbpf/src oracles/test_x86_alu_memory_frame_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_alu_memory_frame_host
	/var/tmp/kprog-tmp/S1/host/test_x86_alu_memory_frame_host
	$(CC) -Wall -Wextra -O2 -mno-red-zone -fsanitize=undefined -fno-sanitize-recover=all -I. -I../x86 -I../../vendor/libbpf/src oracles/test_x86_alu_source_frame_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_alu_source_frame_host
	/var/tmp/kprog-tmp/S1/host/test_x86_alu_source_frame_host
	$(CC) -Wall -Wextra -O2 -mno-red-zone -fsanitize=undefined -fno-sanitize-recover=all -I. -I../x86 -I../../vendor/libbpf/src oracles/test_x86_imul_memory_frame_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_imul_memory_frame_host
	/var/tmp/kprog-tmp/S1/host/test_x86_imul_memory_frame_host
	$(CC) -Wall -Wextra -O2 -mno-red-zone -fsanitize=undefined -fno-sanitize-recover=all -I. -I../x86 -I../../vendor/libbpf/src oracles/test_x86_bmi_memory_frame_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_bmi_memory_frame_host
	/var/tmp/kprog-tmp/S1/host/test_x86_bmi_memory_frame_host
	$(CC) -Wall -Wextra -O2 -mno-red-zone -fsanitize=undefined -fno-sanitize-recover=all -I. -I../x86 -I../../vendor/libbpf/src oracles/test_x86_bit_memory_frame_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_bit_memory_frame_host
	/var/tmp/kprog-tmp/S1/host/test_x86_bit_memory_frame_host
	$(CC) -Wall -Wextra -O2 -mno-red-zone -fsanitize=undefined -fno-sanitize-recover=all -I. -I../x86 -I../../vendor/libbpf/src oracles/test_x86_andn_bt_memory_frame_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_andn_bt_memory_frame_host
	/var/tmp/kprog-tmp/S1/host/test_x86_andn_bt_memory_frame_host
	$(CC) -Wall -Wextra -O2 -mno-red-zone -fsanitize=undefined -fno-sanitize-recover=all -I. -I../x86 -I../../vendor/libbpf/src oracles/test_x86_xmm0_memory_frame_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_xmm0_memory_frame_host
	/var/tmp/kprog-tmp/S1/host/test_x86_xmm0_memory_frame_host
	$(CC) -Wall -Wextra -O2 -mno-red-zone -fsanitize=undefined -fno-sanitize-recover=all -I. -I../x86 -I../../vendor/libbpf/src oracles/test_x86_mov_memory_frame_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_mov_memory_frame_host
	/var/tmp/kprog-tmp/S1/host/test_x86_mov_memory_frame_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_shiftx_rorx_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_shiftx_rorx_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_shiftx_rorx_route_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_movx_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_movx_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_movx_route_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_imul_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_imul_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_imul_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_imul_flags_host.c -o /var/tmp/kprog-tmp/S1/host/test_imul_flags_host
	/var/tmp/kprog-tmp/S1/host/test_imul_flags_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_lea_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_lea_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_lea_route_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_mov_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_mov_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_mov_route_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_bswap_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_bswap_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_bswap_route_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 oracles/test_x86_alu_decode_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_alu_decode_host
	/var/tmp/kprog-tmp/S1/host/test_x86_alu_decode_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 oracles/test_x86_opcode_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_opcode_host
	/var/tmp/kprog-tmp/S1/host/test_x86_opcode_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 oracles/test_x86_specialization_chain_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_specialization_chain_host
	/var/tmp/kprog-tmp/S1/host/test_x86_specialization_chain_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_specialization_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_specialization_host
	/var/tmp/kprog-tmp/S1/host/test_x86_specialization_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_stack_index_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_stack_index_host
	/var/tmp/kprog-tmp/S1/host/test_x86_stack_index_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_stack_arena_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_stack_arena_host
	/var/tmp/kprog-tmp/S1/host/test_x86_stack_arena_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_ror_result_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_ror_result_host
	/var/tmp/kprog-tmp/S1/host/test_x86_ror_result_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_bswap_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_bswap_host
	/var/tmp/kprog-tmp/S1/host/test_x86_bswap_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_signed_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_signed_host
	/var/tmp/kprog-tmp/S1/host/test_x86_signed_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_popcount_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_popcount_host
	/var/tmp/kprog-tmp/S1/host/test_x86_popcount_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_bitops_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_bitops_host
	/var/tmp/kprog-tmp/S1/host/test_x86_bitops_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_doubleshift_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_doubleshift_host
	/var/tmp/kprog-tmp/S1/host/test_x86_doubleshift_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_shift_flags_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_shift_flags_host
	/var/tmp/kprog-tmp/S1/host/test_x86_shift_flags_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_shift_flags_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_shift_flags_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_shift_flags_route_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 oracles/test_x86_reg_lane_aux_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_reg_lane_aux_host
	/var/tmp/kprog-tmp/S1/host/test_x86_reg_lane_aux_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 oracles/test_x86_mem_aux_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_mem_aux_host
	/var/tmp/kprog-tmp/S1/host/test_x86_mem_aux_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_mem_access_host.c -o /var/tmp/kprog-tmp/S1/host/test_mem_access_host
	/var/tmp/kprog-tmp/S1/host/test_mem_access_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_mem_alu_handler_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_mem_alu_handler_host
	/var/tmp/kprog-tmp/S1/host/test_x86_mem_alu_handler_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_mem_store_alu_handler_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_mem_store_alu_handler_host
	/var/tmp/kprog-tmp/S1/host/test_x86_mem_store_alu_handler_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_mem_unary_handler_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_mem_unary_handler_host
	/var/tmp/kprog-tmp/S1/host/test_x86_mem_unary_handler_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_mem_logic_handler_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_mem_logic_handler_host
	/var/tmp/kprog-tmp/S1/host/test_x86_mem_logic_handler_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_mem_shift_handler_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_mem_shift_handler_host
	/var/tmp/kprog-tmp/S1/host/test_x86_mem_shift_handler_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_mem_bit_handler_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_mem_bit_handler_host
	/var/tmp/kprog-tmp/S1/host/test_x86_mem_bit_handler_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_mem_imul_handler_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_mem_imul_handler_host
	/var/tmp/kprog-tmp/S1/host/test_x86_mem_imul_handler_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_mem_compare_handler_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_mem_compare_handler_host
	/var/tmp/kprog-tmp/S1/host/test_x86_mem_compare_handler_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_mulx_handler_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_mulx_handler_host
	/var/tmp/kprog-tmp/S1/host/test_x86_mulx_handler_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_imul_reg_imm_handler_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_imul_reg_imm_handler_host
	/var/tmp/kprog-tmp/S1/host/test_x86_imul_reg_imm_handler_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_mem_offset_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_mem_offset_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_mem_offset_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_mem_index_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_mem_index_host
	/var/tmp/kprog-tmp/S1/host/test_x86_mem_index_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_mem_index_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_mem_index_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_mem_index_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_reg_dispatch_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_reg_dispatch_host
	/var/tmp/kprog-tmp/S1/host/test_x86_reg_dispatch_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_reg_dispatch_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_reg_dispatch_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_helper_dispatch_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_helper_dispatch_host
	/var/tmp/kprog-tmp/S1/host/test_x86_helper_dispatch_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_helper_dispatch_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_helper_dispatch_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_helper_dispatch_route_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/x86_route_host.c -o /var/tmp/kprog-tmp/S1/host/x86_route_host
	/var/tmp/kprog-tmp/S1/host/x86_route_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/btmem_index_route_host.c -o /var/tmp/kprog-tmp/S1/host/btmem_index_route_host
	/var/tmp/kprog-tmp/S1/host/btmem_index_route_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/value_route_host.c -o /var/tmp/kprog-tmp/S1/host/value_route_host
	/var/tmp/kprog-tmp/S1/host/value_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_xchg_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_xchg_host
	/var/tmp/kprog-tmp/S1/host/test_x86_xchg_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_xchg_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_xchg_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_xchg_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_mulx_arm_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_mulx_arm_host
	/var/tmp/kprog-tmp/S1/host/test_x86_mulx_arm_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_mulx_arm_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_mulx_arm_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_mulx_arm_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_div_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_div_host
	/var/tmp/kprog-tmp/S1/host/test_x86_div_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_div_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_div_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_div_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_doubleshift_arm_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_doubleshift_arm_host
	/var/tmp/kprog-tmp/S1/host/test_x86_doubleshift_arm_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_doubleshift_arm_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_doubleshift_arm_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_doubleshift_arm_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_popcnt_flags_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_popcnt_flags_host
	/var/tmp/kprog-tmp/S1/host/test_x86_popcnt_flags_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_popcnt_flags_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_popcnt_flags_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_popcnt_flags_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_bzhi_flags_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_bzhi_flags_host
	/var/tmp/kprog-tmp/S1/host/test_x86_bzhi_flags_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_bzhi_flags_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_bzhi_flags_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_bzhi_flags_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_movx_shape_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_movx_shape_host
	/var/tmp/kprog-tmp/S1/host/test_x86_movx_shape_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_movx_shape_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_movx_shape_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_movx_shape_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_mov_reg_arm_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_mov_reg_arm_host
	/var/tmp/kprog-tmp/S1/host/test_x86_mov_reg_arm_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_mov_reg_arm_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_mov_reg_arm_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_mov_reg_arm_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_stack_arm_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_stack_arm_host
	/var/tmp/kprog-tmp/S1/host/test_x86_stack_arm_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_stack_arm_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_stack_arm_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_stack_arm_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_write_width_arm_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_write_width_arm_host
	/var/tmp/kprog-tmp/S1/host/test_x86_write_width_arm_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_write_width_arm_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_write_width_arm_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_write_width_arm_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_stack_write_lanes_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_stack_write_lanes_host
	/var/tmp/kprog-tmp/S1/host/test_x86_stack_write_lanes_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_stack_write_lanes_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_stack_write_lanes_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_stack_write_lanes_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_alu_flag_arm_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_alu_flag_arm_host
	/var/tmp/kprog-tmp/S1/host/test_x86_alu_flag_arm_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_alu_flag_arm_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_alu_flag_arm_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_alu_flag_arm_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_dispatch_family_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_dispatch_family_host
	/var/tmp/kprog-tmp/S1/host/test_x86_dispatch_family_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_dispatch_family_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_dispatch_family_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_dispatch_family_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_dispatch_singleton_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_dispatch_singleton_host
	/var/tmp/kprog-tmp/S1/host/test_x86_dispatch_singleton_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_dispatch_singleton_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_dispatch_singleton_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_dispatch_singleton_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_reg_presence_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_reg_presence_host
	/var/tmp/kprog-tmp/S1/host/test_x86_reg_presence_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_reg_presence_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_reg_presence_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_reg_presence_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_width_effective_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_width_effective_host
	/var/tmp/kprog-tmp/S1/host/test_x86_width_effective_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_width_effective_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_width_effective_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_width_effective_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_lea_handler_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_lea_handler_host
	/var/tmp/kprog-tmp/S1/host/test_x86_lea_handler_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_mov_handler_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_mov_handler_host
	/var/tmp/kprog-tmp/S1/host/test_x86_mov_handler_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_movx_reg_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_movx_reg_host
	/var/tmp/kprog-tmp/S1/host/test_x86_movx_reg_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_mem_read_dispatch_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_mem_read_dispatch_host
	/var/tmp/kprog-tmp/S1/host/test_x86_mem_read_dispatch_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_mem_dispatch_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_mem_dispatch_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_mem_dispatch_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_mov_load_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_mov_load_host
	/var/tmp/kprog-tmp/S1/host/test_x86_mov_load_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_mov_load_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_mov_load_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_mov_load_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_store_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_store_host
	/var/tmp/kprog-tmp/S1/host/test_x86_store_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_store_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_store_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_store_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_setcc_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_setcc_host
	/var/tmp/kprog-tmp/S1/host/test_x86_setcc_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_setcc_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_setcc_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_setcc_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_cc_decode_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_cc_decode_host
	/var/tmp/kprog-tmp/S1/host/test_x86_cc_decode_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_setcc_mem_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_setcc_mem_host
	/var/tmp/kprog-tmp/S1/host/test_x86_setcc_mem_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_setcc_mem_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_setcc_mem_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_setcc_mem_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_cmov_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_cmov_host
	/var/tmp/kprog-tmp/S1/host/test_x86_cmov_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/cmov_step_route_host.c -o /var/tmp/kprog-tmp/S1/host/cmov_step_route_host
	/var/tmp/kprog-tmp/S1/host/cmov_step_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_movbe_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_movbe_host
	/var/tmp/kprog-tmp/S1/host/test_x86_movbe_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_movbe_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_movbe_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_movbe_route_host
	$(CC) -Wall -Wextra -O2 -mno-red-zone -fsanitize=undefined -fno-sanitize-recover=all -I. -I../x86 -I../../vendor/libbpf/src oracles/test_x86_mov_load_map_ptr_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_mov_load_map_ptr_host
	/var/tmp/kprog-tmp/S1/host/test_x86_mov_load_map_ptr_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_xmm0_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_xmm0_host
	/var/tmp/kprog-tmp/S1/host/test_x86_xmm0_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_xmm0_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_xmm0_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_xmm0_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_callmem_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_callmem_host
	/var/tmp/kprog-tmp/S1/host/test_x86_callmem_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_callmem_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_callmem_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_callmem_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_pushpop_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_pushpop_host
	/var/tmp/kprog-tmp/S1/host/test_x86_pushpop_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_pushpop_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_pushpop_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_pushpop_route_host
	$(CC) -Wall -Wextra -O2 -mno-red-zone -fsanitize=undefined -fno-sanitize-recover=all -I. -I../x86 -I../../vendor/libbpf/src oracles/test_x86_rep_memory_frame_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_rep_memory_frame_host
	/var/tmp/kprog-tmp/S1/host/test_x86_rep_memory_frame_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_rep_movs_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_rep_movs_host
	/var/tmp/kprog-tmp/S1/host/test_x86_rep_movs_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_rep_movs_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_rep_movs_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_rep_movs_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_andn_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_andn_host
	/var/tmp/kprog-tmp/S1/host/test_x86_andn_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_andn_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_andn_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_andn_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_bzhi_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_bzhi_host
	/var/tmp/kprog-tmp/S1/host/test_x86_bzhi_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_bzhi_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_bzhi_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_bzhi_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_bt_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_bt_host
	/var/tmp/kprog-tmp/S1/host/test_x86_bt_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_bt_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_bt_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_bt_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_cmpop_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_cmpop_host
	/var/tmp/kprog-tmp/S1/host/test_x86_cmpop_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_cmpop_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_cmpop_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_cmpop_route_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_cmp_mem_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_cmp_mem_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_cmp_mem_route_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_cmov_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_cmov_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_cmov_route_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/cross_isa_tag_host.c -o /var/tmp/kprog-tmp/S1/host/cross_isa_tag_host
	/var/tmp/kprog-tmp/S1/host/cross_isa_tag_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/cross_isa_differential_host.c -o /var/tmp/kprog-tmp/S1/host/cross_isa_differential_host
	/var/tmp/kprog-tmp/S1/host/cross_isa_differential_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_imul_flags_wide_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_imul_flags_wide_host
	/var/tmp/kprog-tmp/S1/host/test_x86_imul_flags_wide_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../x86 -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_control_flow_trace_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_control_flow_trace_route_host
	/var/tmp/kprog-tmp/S1/host/test_control_flow_trace_route_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_call_ret_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_call_ret_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_call_ret_route_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_helper_call_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_helper_call_host
	/var/tmp/kprog-tmp/S1/host/test_x86_helper_call_host
