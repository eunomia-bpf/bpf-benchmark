ARM64_HOST_ENV := -include oracles/arm64_entry_environment_host.h -DKPROG_TEST_EXCLUSIVE_FAILURE=0 -include oracles/arm64_exclusive_choice_host.h
CC := gcc
.PHONY: host
host:
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_andn_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_andn_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_andn_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_bzhi_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_bzhi_host
	/var/tmp/kprog-tmp/S1/host/test_x86_bzhi_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_bzhi_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_bzhi_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_bzhi_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_bt_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_bt_host
	/var/tmp/kprog-tmp/S1/host/test_x86_bt_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_bt_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_bt_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_bt_route_host
	$(CC) -Wall -Wextra -O2 -I. oracles/test_x86_cmpop_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_cmpop_host
	/var/tmp/kprog-tmp/S1/host/test_x86_cmpop_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_cmpop_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_cmpop_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_cmpop_route_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_cmp_mem_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_cmp_mem_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_cmp_mem_route_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_cmov_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_cmov_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_cmov_route_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/cross_isa_tag_host.c -o /var/tmp/kprog-tmp/S1/host/cross_isa_tag_host
	/var/tmp/kprog-tmp/S1/host/cross_isa_tag_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../arm64 -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/cross_isa_differential_host.c -o /var/tmp/kprog-tmp/S1/host/cross_isa_differential_host
	/var/tmp/kprog-tmp/S1/host/cross_isa_differential_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_imul_flags_wide_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_imul_flags_wide_host
	/var/tmp/kprog-tmp/S1/host/test_x86_imul_flags_wide_host
	$(CC) $(ARM64_HOST_ENV) -Wall -Wextra -O2 -I. -I../x86 -I../arm64 -I../../kprog -I../../vendor/libbpf/src oracles/test_control_flow_trace_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_control_flow_trace_route_host
	/var/tmp/kprog-tmp/S1/host/test_control_flow_trace_route_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_call_ret_route_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_call_ret_route_host
	/var/tmp/kprog-tmp/S1/host/test_x86_call_ret_route_host
	$(CC) -Wall -Wextra -O2 -I. -I../x86 -I../../kprog -I../../vendor/libbpf/src oracles/test_x86_helper_call_host.c -o /var/tmp/kprog-tmp/S1/host/test_x86_helper_call_host
	/var/tmp/kprog-tmp/S1/host/test_x86_helper_call_host
