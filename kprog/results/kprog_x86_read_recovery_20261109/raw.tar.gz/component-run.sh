#!/bin/bash
cd /workspaces/repository
ulimit -c 0
export TMPDIR=/var/tmp/kprog-tmp/S1 PYTHONDONTWRITEBYTECODE=1
make -f /var/tmp/kprog-tmp/S1/component.mk components > /var/tmp/kprog-tmp/S1/component.log 2>&1
echo $? > /var/tmp/kprog-tmp/S1/component.exit
