import os,subprocess
subprocess.run(['mount','--bind','/var/tmp/kprog-tmp/S1/micro-source','/workspaces/repository/kprog/x86/micro-prog'],check=True)
os.chdir('/workspaces/repository')
os.execvp('make',['make','-f','/var/tmp/kprog-tmp/S1/micro.mk','micro'])
