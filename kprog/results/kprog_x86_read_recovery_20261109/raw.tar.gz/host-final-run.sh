#!/bin/bash
cd /workspaces/repository/kprog/formal
ulimit -c 0
export TMPDIR=/var/tmp/kprog-tmp/S1
make -f /var/tmp/kprog-tmp/S1/host-final.mk host > /var/tmp/kprog-tmp/S1/host-final.log 2>&1
echo $? > /var/tmp/kprog-tmp/S1/host-final.exit
