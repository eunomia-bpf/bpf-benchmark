#!/bin/bash
ulimit -c 0
export TMPDIR=/var/tmp/kprog-tmp/S1 PYTHONDONTWRITEBYTECODE=1
unshare --mount --propagation private python3 /var/tmp/kprog-tmp/S1/micro-mount.py > /var/tmp/kprog-tmp/S1/micro.log 2>&1
echo $? > /var/tmp/kprog-tmp/S1/micro.exit
