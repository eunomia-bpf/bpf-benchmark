ROOT := /workspaces/repository
G := /var/tmp/kprog-tmp/S1
INCLUDES := -include $(ROOT)/kprog/formal/oracles/arm64_entry_environment_host.h -I$(ROOT)/kprog/formal -I$(ROOT)/kprog/x86 -I$(ROOT)/vendor/libbpf/src
.PHONY: components
components:
	python3 $(G)/mov/generate-fixture.py
	gcc -O2 -fsanitize=undefined -fno-sanitize-recover=undefined $(INCLUDES) $(G)/mov/host.c -o $(G)/mov/gcc-host
	$(G)/mov/gcc-host
	clang-18 -O2 -fsanitize=undefined -fno-sanitize-recover=undefined $(INCLUDES) -c $(G)/mov/host.c -o $(G)/mov/clang-host.o
	gcc -fsanitize=undefined $(G)/mov/clang-host.o -o $(G)/mov/clang-host
	$(G)/mov/clang-host
	python3 $(G)/alu/generate-fixture.py
	gcc -O2 -fsanitize=undefined -fno-sanitize-recover=undefined $(INCLUDES) $(G)/alu/fault.c -o $(G)/alu/gcc-host
	$(G)/alu/gcc-host
	clang-18 -O2 -fsanitize=undefined -fno-sanitize-recover=undefined $(INCLUDES) -c $(G)/alu/fault.c -o $(G)/alu/clang-host.o
	gcc -fsanitize=undefined $(G)/alu/clang-host.o -o $(G)/alu/clang-host
	$(G)/alu/clang-host
