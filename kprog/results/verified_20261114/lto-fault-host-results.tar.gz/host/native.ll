; ModuleID = '/workspaces/kprog-raw/verified/20261114-lto-fault/host/native.bc'
source_filename = "/workspaces/repository/kprog/test/lto_fault.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

; Function Attrs: nounwind
define noundef i32 @architectural_fault(i32 noundef %0) local_unnamed_addr #0 {
  %2 = icmp eq i32 %0, 0
  br i1 %2, label %3, label %4

3:                                                ; preds = %1
  call void @llvm.trap()
  unreachable

4:                                                ; preds = %1
  %5 = add i32 %0, 3
  ret i32 %5
}

; Function Attrs: nounwind
define noundef i32 @dispatch_fault(i32 noundef %0) local_unnamed_addr #0 {
  %2 = icmp eq i32 %0, 0
  br i1 %2, label %3, label %4

3:                                                ; preds = %1
  call void @llvm.trap()
  unreachable

4:                                                ; preds = %1
  %5 = add i32 %0, 3
  ret i32 %5
}

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #1

attributes #0 = { nounwind "disable-tail-calls"="true" "frame-pointer"="none" "no-jump-tables"="true" "no-trapping-math"="true" "stack-protector-buffer-size"="8" }
attributes #1 = { cold noreturn nounwind memory(inaccessiblemem: write) }

!llvm.module.flags = !{!0, !1}
!llvm.ident = !{!2}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 7, !"frame-pointer", i32 2}
!2 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
