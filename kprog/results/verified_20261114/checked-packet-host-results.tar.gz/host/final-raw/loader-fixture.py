#!/usr/bin/python3
import json,sys
from pathlib import Path
phase=sys.argv[1]
directory=Path(sys.argv[8]).parent
native=directory/'checked-simulator.native.o'
if phase=='verify':
    assert not native.exists(), 'compiled before verification'
    if (directory/'reject').exists(): raise SystemExit(7)
else: assert native.is_file(), 'installed producer instead of checked simulator'
print(json.dumps(dict(request_id=int(sys.argv[3]),status=0,prog_id=19,phase=phase)))
