#include <stdint.h>
unsigned long long kprog_unspecified_input[1];
unsigned char logical[32];
static uint64_t current;
void configure(uint64_t value) { current=value; }
void *bpf_map_lookup_elem(void *map, const uint32_t *key) {
    if (map != (void *)logical || *key != 0) __builtin_trap();
    return &current;
}
