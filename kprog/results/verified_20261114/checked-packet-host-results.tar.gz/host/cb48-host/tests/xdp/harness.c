unsigned long long kprog_unspecified_input[1];
void *bpf_cast_to_kern_ctx(void *ctx) { return ctx; }
