#define X86_SIM_ENABLE_STACK 1
#define X86_SIM_STACK_BYTES 216U
#define X86_SIM_STACK_VALUE_WORDS(M) M(0) M(1) M(2) M(3) M(4) M(5) M(6) M(7) M(8) M(9) M(10) M(11) M(12) M(13) M(14) M(15) M(16) M(17) M(18) M(19) M(20) M(21) M(22) M(23) M(24) M(25) M(26)
#include "/workspaces/repository/kprog/x86/x86_sim_local_bpf.h"

#if defined(__bpf__) || defined(__BPF__)
static __attribute__((always_inline)) inline void
__x86_sim_unresolved_indirect_target(void) {
	asm volatile("call -1" ::: "r0", "r1", "r2", "r3", "r4", "r5", "memory");
}
#else
extern void __x86_sim_unresolved_indirect_target(void)
	__attribute__((error("indirect target was not eliminated by specialization")));
#endif

extern __u8 binary_filter_version[] __ksym;
extern __u8 bufs[] __ksym;
extern __u8 cgroup_id_filter_version[] __ksym;
extern __u8 comm_filter_version[] __ksym;
extern __u8 config_map[] __ksym;
extern __u8 containers_map[] __ksym;
extern __u8 event_data_map[] __ksym;
extern __u8 events_map_version[] __ksym;
extern __u8 mnt_ns_filter_version[] __ksym;
extern __u8 pid_filter_version[] __ksym;
extern __u8 pid_ns_filter_version[] __ksym;
extern __u8 proc_info_map[] __ksym;
extern __u8 process_tree_map_version[] __ksym;
extern __u8 prog_array[] __ksym;
extern __u8 scratch_map[] __ksym;
extern __u8 sys_32_to_64_map[] __ksym;
extern __u8 task_info_map[] __ksym;
extern __u8 uid_filter_version[] __ksym;
extern __u8 use_security_bprm_creds_for_exec[] __ksym;
extern __u8 uts_ns_filter_version[] __ksym;
static const __u8 __x86_rodata_0[15] SEC(".rodata.native.0") __attribute__((aligned(16))) = {0x3c, 0x64, 0x69, 0x73, 0x63, 0x6f, 0x6e, 0x6e, 0x65, 0x63, 0x74, 0x65, 0x64, 0x3e, 0x00};
static const char __x86_rodata_metadata[] SEC(".native_lab.rodata") = "{\"version\":1,\"objects\":[{\"proof_section\":\".rodata.native.0\",\"proof_symbol\":\"__x86_rodata_0\",\"native_symbol\":\".L.str.2\",\"size\":15}]}";

static __always_inline __u64 __x86_rodata_0_value(__u64 offset, __u8 width)
{
	switch (width) {
	case 1: switch (offset) {
	case 0: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 0, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 1: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 1, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 2: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 2, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 3: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 3, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 4: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 4, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 5: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 5, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 6: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 6, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 7: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 7, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 8: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 8, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 9: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 9, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 10: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 10, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 11: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 11, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 12: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 12, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 13: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 13, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	case 14: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 14, 1);
		__asm__("" : "+r"(value));
		return value;
	}
	} break;
	case 2: switch (offset) {
	case 0: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 0, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 1: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 1, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 2: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 2, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 3: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 3, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 4: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 4, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 5: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 5, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 6: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 6, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 7: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 7, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 8: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 8, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 9: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 9, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 10: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 10, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 11: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 11, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 12: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 12, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	case 13: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 13, 2);
		__asm__("" : "+r"(value));
		return value;
	}
	} break;
	case 4: switch (offset) {
	case 0: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 0, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 1: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 1, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 2: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 2, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 3: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 3, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 4: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 4, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 5: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 5, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 6: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 6, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 7: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 7, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 8: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 8, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 9: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 9, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 10: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 10, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	case 11: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 11, 4);
		__asm__("" : "+r"(value));
		return value;
	}
	} break;
	case 8: switch (offset) {
	case 0: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 0, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 1: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 1, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 2: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 2, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 3: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 3, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 4: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 4, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 5: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 5, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 6: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 6, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	case 7: {
		__u64 value = 0;
		__builtin_memcpy(&value, __x86_rodata_0 + 7, 8);
		__asm__("" : "+r"(value));
		return value;
	}
	} break;
	}
	return KPROG_X86_MEM_LOAD((const __u8 *)__x86_rodata_0 + offset, width);
}

#undef X86_SIM_L_NATIVE_DATA_LOAD
#define X86_SIM_L_NATIVE_DATA_LOAD(BASE, OFF, WIDTH) \
({ const void *__x86_ro_base = (BASE); __u64 __x86_ro_off = (OFF); \
   __u8 __x86_ro_width = (WIDTH); __u64 __x86_ro_value; \
   if (__builtin_constant_p((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0)) \
       __x86_ro_value = __x86_rodata_0_value((__u64)(long)__x86_ro_base - (__u64)(long)__x86_rodata_0 + __x86_ro_off, __x86_ro_width); else \
       __x86_ro_value = KPROG_X86_MEM_LOAD(KPROG_PTR_ADD64_BITS(__x86_ro_base, __x86_ro_off), __x86_ro_width); \
   __x86_ro_value; })

SEC("kprobe/trusted")
int trusted_x86_x86_sim_xdp(void *ctx)
{
	X86_SIM_ENTRY_RAW(ctx);
x86_l_0:
	/* 0x0: push   rbp */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1:
	/* 0x1: push   r15 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_3:
	/* 0x3: push   r14 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_5:
	/* 0x5: push   r13 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R13, X86_WIDTH_64, 0, 0);
x86_l_7:
	/* 0x7: push   r12 */
	X86_SIM_L_EXEC_PUSH_OP(X86_R12, X86_WIDTH_64, 0, 0);
x86_l_9:
	/* 0x9: push   rbx */
	X86_SIM_L_EXEC_PUSH_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_a:
	/* 0xa: sub    rsp,0xa8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_SUB, 168ULL);
x86_l_11:
	/* 0x11: mov    rbp,rdi */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RDI, X86_WIDTH_64);
x86_l_14:
	/* 0x14: mov    rax,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RAX, X86_MAP_PTR_AUX_VALUE, ((__u64)(long)use_security_bprm_creds_for_exec));
x86_l_1b:
	/* 0x1b: mov    BYTE PTR [rax],0x1 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RAX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 1ULL);
x86_l_1e:
	/* 0x1e: mov    DWORD PTR [rsp],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25:
	/* 0x25: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)event_data_map));
x86_l_2c:
	/* 0x2c: mov    rsi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RSP, X86_WIDTH_64);
x86_l_2f:
	/* 0x2f: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_34:
	/* 0x34: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_36:
	/* 0x36: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_39:
	/* 0x39: je     1fa7 <trace_security_bprm_creds_for_exec+0x1fa7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x39, 0x1fa7, x86_l_1fa7);
x86_l_3f:
	/* 0x3f: mov    r14,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R14, X86_RAX, X86_WIDTH_64);
x86_l_42:
	/* 0x42: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)config_map));
x86_l_49:
	/* 0x49: mov    rsi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_RSP, X86_WIDTH_64);
x86_l_4c:
	/* 0x4c: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_51:
	/* 0x51: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_53:
	/* 0x53: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_56:
	/* 0x56: je     1fa7 <trace_security_bprm_creds_for_exec+0x1fa7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x56, 0x1fa7, x86_l_1fa7);
x86_l_5c:
	/* 0x5c: mov    r15,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R15, X86_RAX, X86_WIDTH_64);
x86_l_5f:
	/* 0x5f: mov    WORD PTR [r14+0x7d8a],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 138031658958848ULL);
x86_l_69:
	/* 0x69: mov    BYTE PTR [r14+0x88],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 584115552256ULL);
x86_l_71:
	/* 0x71: mov    QWORD PTR [r14+0x7d8c],0xffffffffffffffff */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138044543860735ULL);
x86_l_7c:
	/* 0x7c: mov    QWORD PTR [r14+0x7d94],0xffffffffffffffff */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138078903599103ULL);
x86_l_87:
	/* 0x87: mov    QWORD PTR [r14+0x7d9c],0xffffffffffffffff */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138113263337471ULL);
x86_l_92:
	/* 0x92: mov    QWORD PTR [r14+0x7da4],0xffffffffffffffff */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138147623075839ULL);
x86_l_9d:
	/* 0x9d: mov    QWORD PTR [r14+0x7dac],0xffffffffffffffff */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138181982814207ULL);
x86_l_a8:
	/* 0xa8: mov    QWORD PTR [r14+0x7db4],0xffffffffffffffff */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138216342552575ULL);
x86_l_b3:
	/* 0xb3: mov    QWORD PTR [r14+0x7dbc],0xffffffffffffffff */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138250702290943ULL);
x86_l_be:
	/* 0xbe: mov    QWORD PTR [r14+0x7dc4],0xffffffffffffffff */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138285062029311ULL);
x86_l_c9:
	/* 0xc9: mov    eax,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 35ULL);
x86_l_ce:
	/* 0xce: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x23ULL: X86_SIM_BPF_CALL_bpf_get_current_task(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x23ULL: X86_SIM_BPF_CALL_bpf_get_current_task(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_d0:
	/* 0xd0: mov    QWORD PTR [r14+0x7dd0],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_d7:
	/* 0xd7: mov    QWORD PTR [r14+0x8],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 34359738368ULL);
x86_l_df:
	/* 0xdf: mov    QWORD PTR [r14+0x10],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 68719476736ULL);
x86_l_e7:
	/* 0xe7: mov    QWORD PTR [r14+0x18],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_ef:
	/* 0xef: mov    QWORD PTR [r14+0x20],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 137438953472ULL);
x86_l_f7:
	/* 0xf7: mov    QWORD PTR [r14+0x28],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 171798691840ULL);
x86_l_ff:
	/* 0xff: mov    QWORD PTR [r14+0x30],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_107:
	/* 0x107: mov    QWORD PTR [r14+0x38],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 240518168576ULL);
x86_l_10f:
	/* 0x10f: mov    QWORD PTR [r14+0x40],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 274877906944ULL);
x86_l_117:
	/* 0x117: mov    QWORD PTR [r14+0x48],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 309237645312ULL);
x86_l_11f:
	/* 0x11f: mov    QWORD PTR [r14+0x50],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 343597383680ULL);
x86_l_127:
	/* 0x127: mov    QWORD PTR [r14+0x58],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 377957122048ULL);
x86_l_12f:
	/* 0x12f: mov    QWORD PTR [r14+0x60],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 412316860416ULL);
x86_l_137:
	/* 0x137: mov    QWORD PTR [r14+0x68],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 446676598784ULL);
x86_l_13f:
	/* 0x13f: mov    eax,0xe */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 14ULL);
x86_l_144:
	/* 0x144: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xeULL: X86_SIM_BPF_CALL_bpf_get_current_pid_tgid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_146:
	/* 0x146: mov    DWORD PTR [r14+0x28],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_14a:
	/* 0x14a: shr    rax,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_SHR, 32ULL);
x86_l_14e:
	/* 0x14e: mov    DWORD PTR [r14+0x24],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_152:
	/* 0x152: mov    DWORD PTR [r14+0x70],0x314 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 481036337940ULL);
x86_l_15a:
	/* 0x15a: mov    eax,0x7d */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 125ULL);
x86_l_15f:
	/* 0x15f: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x7dULL: X86_SIM_BPF_CALL_bpf_ktime_get_boot_ns(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x7dULL: X86_SIM_BPF_CALL_bpf_ktime_get_boot_ns(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_161:
	/* 0x161: mov    QWORD PTR [r14],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_164:
	/* 0x164: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_169:
	/* 0x169: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x8ULL: X86_SIM_BPF_CALL_bpf_get_smp_processor_id(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x8ULL: X86_SIM_BPF_CALL_bpf_get_smp_processor_id(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_16b:
	/* 0x16b: mov    WORD PTR [r14+0x7c],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 124ULL);
x86_l_170:
	/* 0x170: mov    eax,0x23 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 35ULL);
x86_l_175:
	/* 0x175: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x23ULL: X86_SIM_BPF_CALL_bpf_get_current_task(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x23ULL: X86_SIM_BPF_CALL_bpf_get_current_task(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_177:
	/* 0x177: mov    r12,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RAX, X86_WIDTH_64);
x86_l_17a:
	/* 0x17a: lea    rdx,[rax+0x4] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 4ULL);
x86_l_17e:
	/* 0x17e: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_183:
	/* 0x183: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_188:
	/* 0x188: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_18d:
	/* 0x18d: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_192:
	/* 0x192: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_194:
	/* 0x194: test   DWORD PTR [rsp+0x30],0x200000 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 206160527360ULL);
x86_l_19c:
	/* 0x19c: mov    eax,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4294967295ULL);
x86_l_1a1:
	/* 0x1a1: jne    21d <trace_security_bprm_creds_for_exec+0x21d> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1a1, 0x21d, x86_l_21d);
x86_l_1a3:
	/* 0x1a3: mov    eax,0x9e */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 158ULL);
x86_l_1a8:
	/* 0x1a8: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x9eULL: X86_SIM_BPF_CALL_bpf_get_current_task_btf(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x9eULL: X86_SIM_BPF_CALL_bpf_get_current_task_btf(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1aa:
	/* 0x1aa: mov    ecx,0xaf */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 175ULL);
x86_l_1af:
	/* 0x1af: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_1b2:
	/* 0x1b2: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xafULL: X86_SIM_BPF_CALL_bpf_task_pt_regs(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xafULL: X86_SIM_BPF_CALL_bpf_task_pt_regs(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1b4:
	/* 0x1b4: lea    rdx,[rax+0x78] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_1b8:
	/* 0x1b8: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1bd:
	/* 0x1bd: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_1c2:
	/* 0x1c2: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_1c7:
	/* 0x1c7: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1cc:
	/* 0x1cc: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1ce:
	/* 0x1ce: mov    eax,DWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1d2:
	/* 0x1d2: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1d6:
	/* 0x1d6: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1db:
	/* 0x1db: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1e0:
	/* 0x1e0: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_1e5:
	/* 0x1e5: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_1ea:
	/* 0x1ea: mov    rdx,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R12, X86_WIDTH_64);
x86_l_1ed:
	/* 0x1ed: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1ef:
	/* 0x1ef: test   BYTE PTR [rsp+0x30],0x2 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 206158430210ULL);
x86_l_1f4:
	/* 0x1f4: jne    1fc <trace_security_bprm_creds_for_exec+0x1fc> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1f4, 0x1fc, x86_l_1fc);
x86_l_1f6:
	/* 0x1f6: mov    eax,DWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1fa:
	/* 0x1fa: jmp    21d <trace_security_bprm_creds_for_exec+0x21d> */
	X86_SIM_X86_JMP(0x1fa, 0x21d, x86_l_21d);
x86_l_1fc:
	/* 0x1fc: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)sys_32_to_64_map));
x86_l_203:
	/* 0x203: lea    rsi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_208:
	/* 0x208: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_20d:
	/* 0x20d: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_20f:
	/* 0x20f: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_212:
	/* 0x212: je     218 <trace_security_bprm_creds_for_exec+0x218> */
	X86_SIM_X86_JCC(X86_CC_E, 0x212, 0x218, x86_l_218);
x86_l_214:
	/* 0x214: mov    eax,DWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_216:
	/* 0x216: jmp    21d <trace_security_bprm_creds_for_exec+0x21d> */
	X86_SIM_X86_JMP(0x216, 0x21d, x86_l_21d);
x86_l_218:
	/* 0x218: mov    eax,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4294967295ULL);
x86_l_21d:
	/* 0x21d: mov    DWORD PTR [r14+0x74],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 116ULL);
x86_l_221:
	/* 0x221: mov    eax,DWORD PTR [r14+0x24] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_225:
	/* 0x225: mov    DWORD PTR [rsp+0x84],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 132ULL);
x86_l_22c:
	/* 0x22c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)proc_info_map));
x86_l_233:
	/* 0x233: lea    rsi,[rsp+0x84] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 132ULL);
x86_l_23b:
	/* 0x23b: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_240:
	/* 0x240: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_242:
	/* 0x242: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_247:
	/* 0x247: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_24a:
	/* 0x24a: je     290 <trace_security_bprm_creds_for_exec+0x290> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24a, 0x290, x86_l_290);
x86_l_24c:
	/* 0x24c: mov    eax,DWORD PTR [r14+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_250:
	/* 0x250: mov    DWORD PTR [rsp+0x9c],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 156ULL);
x86_l_257:
	/* 0x257: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)task_info_map));
x86_l_25e:
	/* 0x25e: lea    rsi,[rsp+0x9c] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 156ULL);
x86_l_266:
	/* 0x266: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_26b:
	/* 0x26b: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_26d:
	/* 0x26d: mov    r13,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_64);
x86_l_270:
	/* 0x270: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_273:
	/* 0x273: je     320 <trace_security_bprm_creds_for_exec+0x320> */
	X86_SIM_X86_JCC(X86_CC_E, 0x273, 0x320, x86_l_320);
x86_l_279:
	/* 0x279: test   BYTE PTR [r15+0x4],0x20 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869216ULL);
x86_l_27e:
	/* 0x27e: jne    860 <trace_security_bprm_creds_for_exec+0x860> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x27e, 0x860, x86_l_860);
x86_l_284:
	/* 0x284: mov    eax,0x50 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 80ULL);
x86_l_289:
	/* 0x289: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x50ULL: X86_SIM_BPF_CALL_bpf_get_current_cgroup_id(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x50ULL: X86_SIM_BPF_CALL_bpf_get_current_cgroup_id(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_28b:
	/* 0x28b: jmp    90e <trace_security_bprm_creds_for_exec+0x90e> */
	X86_SIM_X86_JMP(0x28b, 0x90e, x86_l_90e);
x86_l_290:
	/* 0x290: mov    eax,DWORD PTR [rsp+0x84] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 132ULL);
x86_l_297:
	/* 0x297: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_29b:
	/* 0x29b: mov    DWORD PTR [rsp+0x18],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_2a3:
	/* 0x2a3: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)scratch_map));
x86_l_2aa:
	/* 0x2aa: lea    rsi,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2af:
	/* 0x2af: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2b4:
	/* 0x2b4: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2b6:
	/* 0x2b6: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_2b9:
	/* 0x2b9: je     1fa7 <trace_security_bprm_creds_for_exec+0x1fa7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b9, 0x1fa7, x86_l_1fa7);
x86_l_2bf:
	/* 0x2bf: mov    r12,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R12, X86_RAX, X86_WIDTH_64);
x86_l_2c2:
	/* 0x2c2: mov    eax,DWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2c6:
	/* 0x2c6: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2ca:
	/* 0x2ca: mov    edx,0x170 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 368ULL);
x86_l_2cf:
	/* 0x2cf: mov    rdi,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R12, X86_WIDTH_64);
x86_l_2d2:
	/* 0x2d2: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_2d4:
	/* 0x2d4: call   2d9 <trace_security_bprm_creds_for_exec+0x2d9> */
	X86_SIM_L_EXEC_CALL_MEMSET(368ULL);
x86_l_2d9:
	/* 0x2d9: mov    r13,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_R13, 0, ((__u64)(long)proc_info_map));
x86_l_2e0:
	/* 0x2e0: lea    rsi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2e5:
	/* 0x2e5: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_2ea:
	/* 0x2ea: mov    r8d,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 2ULL);
x86_l_2f0:
	/* 0x2f0: mov    ecx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_2f5:
	/* 0x2f5: mov    rdi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R13, X86_WIDTH_64);
x86_l_2f8:
	/* 0x2f8: mov    rdx,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R12, X86_WIDTH_64);
x86_l_2fb:
	/* 0x2fb: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2fe:
	/* 0x2fe: lea    rsi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_303:
	/* 0x303: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_308:
	/* 0x308: mov    rdi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R13, X86_WIDTH_64);
x86_l_30b:
	/* 0x30b: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_30d:
	/* 0x30d: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_312:
	/* 0x312: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_315:
	/* 0x315: jne    24c <trace_security_bprm_creds_for_exec+0x24c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x315, 0x24c, x86_l_24c);
x86_l_31b:
	/* 0x31b: jmp    1fa7 <trace_security_bprm_creds_for_exec+0x1fa7> */
	X86_SIM_X86_JMP(0x31b, 0x1fa7, x86_l_1fa7);
x86_l_320:
	/* 0x320: mov    QWORD PTR [rsp+0x88],rbp */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_328:
	/* 0x328: mov    eax,DWORD PTR [rsp+0x9c] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 156ULL);
x86_l_32f:
	/* 0x32f: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_333:
	/* 0x333: mov    DWORD PTR [rsp+0x18],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 103079215104ULL);
x86_l_33b:
	/* 0x33b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)scratch_map));
x86_l_342:
	/* 0x342: lea    rsi,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_347:
	/* 0x347: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_34c:
	/* 0x34c: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_34e:
	/* 0x34e: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_351:
	/* 0x351: je     1fa7 <trace_security_bprm_creds_for_exec+0x1fa7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x351, 0x1fa7, x86_l_1fa7);
x86_l_357:
	/* 0x357: mov    r13,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_64);
x86_l_35a:
	/* 0x35a: mov    eax,DWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_35e:
	/* 0x35e: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_362:
	/* 0x362: mov    edx,0xc8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 200ULL);
x86_l_367:
	/* 0x367: mov    rdi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R13, X86_WIDTH_64);
x86_l_36a:
	/* 0x36a: xor    esi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RSI, X86_RSI, X86_WIDTH_32, X86_ALU_XOR);
x86_l_36c:
	/* 0x36c: call   371 <trace_security_bprm_creds_for_exec+0x371> */
	X86_SIM_L_EXEC_CALL_MEMSET(200ULL);
x86_l_371:
	/* 0x371: mov    rbp,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RBP, 0, ((__u64)(long)task_info_map));
x86_l_378:
	/* 0x378: lea    rsi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_37d:
	/* 0x37d: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_382:
	/* 0x382: mov    r8d,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 2ULL);
x86_l_388:
	/* 0x388: mov    ecx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_38d:
	/* 0x38d: mov    rdi,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBP, X86_WIDTH_64);
x86_l_390:
	/* 0x390: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_393:
	/* 0x393: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x2ULL: X86_SIM_BPF_CALL_bpf_map_update_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_396:
	/* 0x396: lea    rsi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_39b:
	/* 0x39b: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_3a0:
	/* 0x3a0: mov    rdi,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBP, X86_WIDTH_64);
x86_l_3a3:
	/* 0x3a3: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3a5:
	/* 0x3a5: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_3a8:
	/* 0x3a8: je     1fa7 <trace_security_bprm_creds_for_exec+0x1fa7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3a8, 0x1fa7, x86_l_1fa7);
x86_l_3ae:
	/* 0x3ae: mov    r13,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_64);
x86_l_3b1:
	/* 0x3b1: mov    rbx,QWORD PTR [r14+0x7dd0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_3b8:
	/* 0x3b8: lea    r12,[rbx+0x28] */
	X86_SIM_L_EXEC_LEA(X86_R12, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3bc:
	/* 0x3bc: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3c1:
	/* 0x3c1: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_3c6:
	/* 0x3c6: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_3cb:
	/* 0x3cb: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3d0:
	/* 0x3d0: mov    rdx,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R12, X86_WIDTH_64);
x86_l_3d3:
	/* 0x3d3: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3d5:
	/* 0x3d5: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3da:
	/* 0x3da: mov    QWORD PTR [rsp+0x28],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3df:
	/* 0x3df: lea    rdx,[rax+0x20] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3e3:
	/* 0x3e3: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3e8:
	/* 0x3e8: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_3ed:
	/* 0x3ed: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_3f2:
	/* 0x3f2: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3f7:
	/* 0x3f7: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3f9:
	/* 0x3f9: mov    rdx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3fe:
	/* 0x3fe: add    rdx,0x28 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 40ULL);
x86_l_402:
	/* 0x402: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_407:
	/* 0x407: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_40c:
	/* 0x40c: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_411:
	/* 0x411: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_416:
	/* 0x416: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_418:
	/* 0x418: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_41d:
	/* 0x41d: mov    QWORD PTR [rsp+0x78],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_422:
	/* 0x422: lea    rdx,[rax+0x14] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_426:
	/* 0x426: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_42b:
	/* 0x42b: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_430:
	/* 0x430: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_435:
	/* 0x435: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_43a:
	/* 0x43a: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_43c:
	/* 0x43c: mov    eax,DWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_440:
	/* 0x440: mov    DWORD PTR [r13+0x24],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_444:
	/* 0x444: mov    QWORD PTR [rsp+0x20],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_449:
	/* 0x449: add    rbx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_44d:
	/* 0x44d: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_452:
	/* 0x452: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_457:
	/* 0x457: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_45c:
	/* 0x45c: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_461:
	/* 0x461: mov    rdx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBX, X86_WIDTH_64);
x86_l_464:
	/* 0x464: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_466:
	/* 0x466: mov    rbp,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_46b:
	/* 0x46b: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_470:
	/* 0x470: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_475:
	/* 0x475: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_47a:
	/* 0x47a: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_47f:
	/* 0x47f: mov    rdx,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBP, X86_WIDTH_64);
x86_l_482:
	/* 0x482: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_484:
	/* 0x484: mov    eax,DWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_488:
	/* 0x488: shl    rax,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_48c:
	/* 0x48c: lea    rdx,[rax+rbp*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_490:
	/* 0x490: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_494:
	/* 0x494: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_499:
	/* 0x499: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_49e:
	/* 0x49e: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_4a3:
	/* 0x4a3: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_4a8:
	/* 0x4a8: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_4aa:
	/* 0x4aa: mov    eax,DWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4ae:
	/* 0x4ae: mov    DWORD PTR [r13+0x14],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_4b2:
	/* 0x4b2: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4b7:
	/* 0x4b7: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_4bc:
	/* 0x4bc: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_4c1:
	/* 0x4c1: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_4c6:
	/* 0x4c6: mov    rdx,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R12, X86_WIDTH_64);
x86_l_4c9:
	/* 0x4c9: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_4cb:
	/* 0x4cb: mov    rdx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4d0:
	/* 0x4d0: add    rdx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_4d4:
	/* 0x4d4: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4d9:
	/* 0x4d9: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_4de:
	/* 0x4de: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_4e3:
	/* 0x4e3: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_4e8:
	/* 0x4e8: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_4ea:
	/* 0x4ea: mov    rbp,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4ef:
	/* 0x4ef: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_4f4:
	/* 0x4f4: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_4f9:
	/* 0x4f9: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_4fe:
	/* 0x4fe: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_503:
	/* 0x503: mov    rdx,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBP, X86_WIDTH_64);
x86_l_506:
	/* 0x506: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_508:
	/* 0x508: mov    eax,DWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_50c:
	/* 0x50c: shl    rax,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_510:
	/* 0x510: lea    rdx,[rax+rbp*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_514:
	/* 0x514: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_518:
	/* 0x518: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_51d:
	/* 0x51d: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_522:
	/* 0x522: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_527:
	/* 0x527: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_52c:
	/* 0x52c: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_52e:
	/* 0x52e: mov    eax,DWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_532:
	/* 0x532: mov    DWORD PTR [r13+0x10],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_536:
	/* 0x536: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_53b:
	/* 0x53b: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_540:
	/* 0x540: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_545:
	/* 0x545: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_54a:
	/* 0x54a: mov    rdx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBX, X86_WIDTH_64);
x86_l_54d:
	/* 0x54d: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_54f:
	/* 0x54f: mov    rbp,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_554:
	/* 0x554: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_559:
	/* 0x559: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_55e:
	/* 0x55e: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_563:
	/* 0x563: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_568:
	/* 0x568: mov    rdx,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBP, X86_WIDTH_64);
x86_l_56b:
	/* 0x56b: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_56d:
	/* 0x56d: mov    eax,DWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_571:
	/* 0x571: shl    rax,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_575:
	/* 0x575: lea    rdx,[rax+rbp*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_579:
	/* 0x579: add    rdx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_57d:
	/* 0x57d: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_582:
	/* 0x582: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_587:
	/* 0x587: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_58c:
	/* 0x58c: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_591:
	/* 0x591: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_593:
	/* 0x593: mov    rdx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_598:
	/* 0x598: add    rdx,0xc */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_59c:
	/* 0x59c: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5a1:
	/* 0x5a1: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_5a6:
	/* 0x5a6: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_5ab:
	/* 0x5ab: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_5b0:
	/* 0x5b0: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_5b2:
	/* 0x5b2: mov    ebx,DWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5b6:
	/* 0x5b6: mov    rax,QWORD PTR [rsp+0x78] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_5bb:
	/* 0x5bb: lea    r12,[rax+0x10] */
	X86_SIM_L_EXEC_LEA(X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_5bf:
	/* 0x5bf: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5c4:
	/* 0x5c4: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_5c9:
	/* 0x5c9: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_5ce:
	/* 0x5ce: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_5d3:
	/* 0x5d3: mov    rdx,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R12, X86_WIDTH_64);
x86_l_5d6:
	/* 0x5d6: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_5d8:
	/* 0x5d8: mov    rbp,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5dd:
	/* 0x5dd: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5e2:
	/* 0x5e2: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_5e7:
	/* 0x5e7: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_5ec:
	/* 0x5ec: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_5f1:
	/* 0x5f1: mov    rdx,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBP, X86_WIDTH_64);
x86_l_5f4:
	/* 0x5f4: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_5f6:
	/* 0x5f6: mov    eax,DWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_5fa:
	/* 0x5fa: shl    rax,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_5fe:
	/* 0x5fe: lea    rdx,[rax+rbp*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_602:
	/* 0x602: add    rdx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_606:
	/* 0x606: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_60b:
	/* 0x60b: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_610:
	/* 0x610: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_615:
	/* 0x615: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_61a:
	/* 0x61a: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_61c:
	/* 0x61c: mov    rdx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_621:
	/* 0x621: add    rdx,0xc */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_625:
	/* 0x625: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_62a:
	/* 0x62a: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_62f:
	/* 0x62f: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_634:
	/* 0x634: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_639:
	/* 0x639: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_63b:
	/* 0x63b: cmp    ebx,DWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RBX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 48ULL);
x86_l_63f:
	/* 0x63f: jne    6a6 <trace_security_bprm_creds_for_exec+0x6a6> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x63f, 0x6a6, x86_l_6a6);
x86_l_641:
	/* 0x641: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_646:
	/* 0x646: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_64b:
	/* 0x64b: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_650:
	/* 0x650: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_655:
	/* 0x655: mov    rdx,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R12, X86_WIDTH_64);
x86_l_658:
	/* 0x658: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_65a:
	/* 0x65a: mov    rbp,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_65f:
	/* 0x65f: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_664:
	/* 0x664: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_669:
	/* 0x669: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_66e:
	/* 0x66e: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_673:
	/* 0x673: mov    rdx,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBP, X86_WIDTH_64);
x86_l_676:
	/* 0x676: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_678:
	/* 0x678: mov    eax,DWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_67c:
	/* 0x67c: shl    rax,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_680:
	/* 0x680: lea    rdx,[rax+rbp*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_RBP, 0), 0ULL);
x86_l_684:
	/* 0x684: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_688:
	/* 0x688: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_68d:
	/* 0x68d: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_692:
	/* 0x692: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_697:
	/* 0x697: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_69c:
	/* 0x69c: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_69e:
	/* 0x69e: mov    eax,DWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_6a2:
	/* 0x6a2: mov    DWORD PTR [r13+0x18],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_6a6:
	/* 0x6a6: mov    DWORD PTR [r13+0x30],ebx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R13, X86_RBX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_6aa:
	/* 0x6aa: mov    rbx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_6af:
	/* 0x6af: lea    rbp,[rbx+0x90] */
	X86_SIM_L_EXEC_LEA(X86_RBP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_6b6:
	/* 0x6b6: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_6bb:
	/* 0x6bb: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_6c0:
	/* 0x6c0: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_6c5:
	/* 0x6c5: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_6ca:
	/* 0x6ca: mov    rdx,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBP, X86_WIDTH_64);
x86_l_6cd:
	/* 0x6cd: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_6cf:
	/* 0x6cf: mov    rdx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_6d4:
	/* 0x6d4: add    rdx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_6d8:
	/* 0x6d8: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_6dd:
	/* 0x6dd: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_6e2:
	/* 0x6e2: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_6e7:
	/* 0x6e7: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_6ec:
	/* 0x6ec: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_6ee:
	/* 0x6ee: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_6f3:
	/* 0x6f3: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_6f8:
	/* 0x6f8: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_6fd:
	/* 0x6fd: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_703:
	/* 0x703: mov    rdx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_708:
	/* 0x708: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_70d:
	/* 0x70d: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_710:
	/* 0x710: mov    eax,DWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_714:
	/* 0x714: mov    DWORD PTR [r13+0x2c],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 44ULL);
x86_l_718:
	/* 0x718: mov    eax,0xf */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 15ULL);
x86_l_71d:
	/* 0x71d: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xfULL: X86_SIM_BPF_CALL_bpf_get_current_uid_gid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xfULL: X86_SIM_BPF_CALL_bpf_get_current_uid_gid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_71f:
	/* 0x71f: mov    DWORD PTR [r13+0x28],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_723:
	/* 0x723: lea    rdx,[rbx+0x50] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 80ULL);
x86_l_727:
	/* 0x727: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_72c:
	/* 0x72c: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_731:
	/* 0x731: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_736:
	/* 0x736: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_73b:
	/* 0x73b: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_73d:
	/* 0x73d: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_742:
	/* 0x742: mov    QWORD PTR [r13+0x0],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_746:
	/* 0x746: mov    rdx,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_74b:
	/* 0x74b: add    rdx,0x50 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_74f:
	/* 0x74f: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_754:
	/* 0x754: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_759:
	/* 0x759: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_75e:
	/* 0x75e: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_763:
	/* 0x763: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_765:
	/* 0x765: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_76a:
	/* 0x76a: mov    QWORD PTR [r13+0x58],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 88ULL);
x86_l_76e:
	/* 0x76e: mov    rdx,QWORD PTR [rsp+0x78] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_773:
	/* 0x773: add    rdx,0x50 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 80ULL);
x86_l_777:
	/* 0x777: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_77c:
	/* 0x77c: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_781:
	/* 0x781: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_786:
	/* 0x786: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_78b:
	/* 0x78b: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_78d:
	/* 0x78d: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_792:
	/* 0x792: mov    QWORD PTR [r13+0x60],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 96ULL);
x86_l_796:
	/* 0x796: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_79b:
	/* 0x79b: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_7a0:
	/* 0x7a0: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_7a5:
	/* 0x7a5: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_7aa:
	/* 0x7aa: mov    rdx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBX, X86_WIDTH_64);
x86_l_7ad:
	/* 0x7ad: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_7af:
	/* 0x7af: test   BYTE PTR [rsp+0x30],0x2 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 206158430210ULL);
x86_l_7b4:
	/* 0x7b4: je     7bb <trace_security_bprm_creds_for_exec+0x7bb> */
	X86_SIM_X86_JCC(X86_CC_E, 0x7b4, 0x7bb, x86_l_7bb);
x86_l_7b6:
	/* 0x7b6: or     BYTE PTR [r13+0x54],0x2 */
	X86_SIM_L_EXEC_ALU_MEM_IMM(X86_R13, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 360777252866ULL);
x86_l_7bb:
	/* 0x7bb: mov    QWORD PTR [r13+0x3c],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 257698037760ULL);
x86_l_7c3:
	/* 0x7c3: lea    rdi,[r13+0x34] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_7c7:
	/* 0x7c7: mov    QWORD PTR [r13+0x34],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 223338299392ULL);
x86_l_7cf:
	/* 0x7cf: mov    eax,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 16ULL);
x86_l_7d4:
	/* 0x7d4: mov    ecx,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 16ULL);
x86_l_7d9:
	/* 0x7d9: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_7de:
	/* 0x7de: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x10ULL: X86_SIM_BPF_CALL_bpf_get_current_comm(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x10ULL: X86_SIM_BPF_CALL_bpf_get_current_comm(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_7e0:
	/* 0x7e0: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_7e5:
	/* 0x7e5: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_7ea:
	/* 0x7ea: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_7ef:
	/* 0x7ef: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_7f4:
	/* 0x7f4: mov    rdx,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBP, X86_WIDTH_64);
x86_l_7f7:
	/* 0x7f7: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_7f9:
	/* 0x7f9: mov    rdx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_7fe:
	/* 0x7fe: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_803:
	/* 0x803: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_808:
	/* 0x808: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_80d:
	/* 0x80d: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_812:
	/* 0x812: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_814:
	/* 0x814: mov    rdx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_819:
	/* 0x819: lea    rbp,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_81e:
	/* 0x81e: mov    eax,0x41 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 65ULL);
x86_l_823:
	/* 0x823: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_828:
	/* 0x828: mov    rdi,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBP, X86_WIDTH_64);
x86_l_82b:
	/* 0x82b: mov    esi,0x41 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 65ULL);
x86_l_830:
	/* 0x830: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_832:
	/* 0x832: mov    rdi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R13, X86_WIDTH_64);
x86_l_835:
	/* 0x835: add    rdi,0x44 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 68ULL);
x86_l_839:
	/* 0x839: mov    eax,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 16ULL);
x86_l_83e:
	/* 0x83e: mov    ecx,0x73 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 115ULL);
x86_l_843:
	/* 0x843: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_848:
	/* 0x848: mov    rdx,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBP, X86_WIDTH_64);
x86_l_84b:
	/* 0x84b: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_84d:
	/* 0x84d: mov    rbp,QWORD PTR [rsp+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_855:
	/* 0x855: test   BYTE PTR [r15+0x4],0x20 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_IMM, X86_R15, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 17179869216ULL);
x86_l_85a:
	/* 0x85a: je     284 <trace_security_bprm_creds_for_exec+0x284> */
	X86_SIM_X86_JCC(X86_CC_E, 0x85a, 0x284, x86_l_284);
x86_l_860:
	/* 0x860: mov    edx,0x98 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 152ULL);
x86_l_865:
	/* 0x865: add    rdx,QWORD PTR [r14+0x7dd0] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_86c:
	/* 0x86c: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_871:
	/* 0x871: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_876:
	/* 0x876: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_87b:
	/* 0x87b: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_880:
	/* 0x880: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_882:
	/* 0x882: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_887:
	/* 0x887: lea    rdi,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_88c:
	/* 0x88c: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_891:
	/* 0x891: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_897:
	/* 0x897: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_89c:
	/* 0x89c: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_8a1:
	/* 0x8a1: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_8a4:
	/* 0x8a4: mov    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_8a9:
	/* 0x8a9: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_8ae:
	/* 0x8ae: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_8b3:
	/* 0x8b3: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_8b9:
	/* 0x8b9: mov    rdx,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_8be:
	/* 0x8be: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_8c3:
	/* 0x8c3: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_8c6:
	/* 0x8c6: mov    rdx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_8cb:
	/* 0x8cb: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_8d0:
	/* 0x8d0: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_8d5:
	/* 0x8d5: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_8da:
	/* 0x8da: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_8df:
	/* 0x8df: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_8e1:
	/* 0x8e1: mov    rdx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_8e6:
	/* 0x8e6: test   rdx,rdx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RDX, X86_RDX, X86_WIDTH_64);
x86_l_8e9:
	/* 0x8e9: je     90c <trace_security_bprm_creds_for_exec+0x90c> */
	X86_SIM_X86_JCC(X86_CC_E, 0x8e9, 0x90c, x86_l_90c);
x86_l_8eb:
	/* 0x8eb: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_8ef:
	/* 0x8ef: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_8f4:
	/* 0x8f4: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_8f9:
	/* 0x8f9: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_8fe:
	/* 0x8fe: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_903:
	/* 0x903: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_905:
	/* 0x905: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_90a:
	/* 0x90a: jmp    90e <trace_security_bprm_creds_for_exec+0x90e> */
	X86_SIM_X86_JMP(0x90a, 0x90e, x86_l_90e);
x86_l_90c:
	/* 0x90c: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_90e:
	/* 0x90e: mov    QWORD PTR [r14+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_912:
	/* 0x912: mov    QWORD PTR [r13+0x8],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_916:
	/* 0x916: mov    DWORD PTR [rsp+0x10],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_91a:
	/* 0x91a: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)containers_map));
x86_l_921:
	/* 0x921: lea    rsi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_926:
	/* 0x926: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_92b:
	/* 0x92b: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_92d:
	/* 0x92d: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_930:
	/* 0x930: je     949 <trace_security_bprm_creds_for_exec+0x949> */
	X86_SIM_X86_JCC(X86_CC_E, 0x930, 0x949, x86_l_949);
x86_l_932:
	/* 0x932: movzx  eax,BYTE PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_935:
	/* 0x935: mov    BYTE PTR [r13+0xb1],al */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R13, X86_RAX, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 177ULL);
x86_l_93c:
	/* 0x93c: or     eax,0x2 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_OR, 2ULL);
x86_l_93f:
	/* 0x93f: cmp    eax,0x3 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 3ULL);
x86_l_942:
	/* 0x942: jne    949 <trace_security_bprm_creds_for_exec+0x949> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x942, 0x949, x86_l_949);
x86_l_944:
	/* 0x944: or     BYTE PTR [r14+0x5c],0x1 */
	X86_SIM_L_EXEC_ALU_MEM_IMM(X86_R14, X86_WIDTH_8, (X86_MEM_AUX(X86_REG_NONE, 0) | X86_MEM_AUX_ALU_OP(X86_ALU_OR)), 395136991233ULL);
x86_l_949:
	/* 0x949: movzx  eax,WORD PTR [r14+0x7e] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 126ULL);
x86_l_94e:
	/* 0x94e: cmp    ax,WORD PTR [r15+0xe] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_R15, X86_WIDTH_16, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_953:
	/* 0x953: jne    1f74 <trace_security_bprm_creds_for_exec+0x1f74> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x953, 0x1f74, x86_l_1f74);
x86_l_959:
	/* 0x959: mov    QWORD PTR [r14+0x7dd8],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138366666407936ULL);
x86_l_964:
	/* 0x964: mov    DWORD PTR [rsp+0x30],0x314 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 206158430996ULL);
x86_l_96c:
	/* 0x96c: mov    WORD PTR [rsp+0x18],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_971:
	/* 0x971: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)events_map_version));
x86_l_978:
	/* 0x978: lea    rsi,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_97d:
	/* 0x97d: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_982:
	/* 0x982: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_984:
	/* 0x984: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_987:
	/* 0x987: je     9f4 <trace_security_bprm_creds_for_exec+0x9f4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x987, 0x9f4, x86_l_9f4);
x86_l_989:
	/* 0x989: lea    rsi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_98e:
	/* 0x98e: mov    ecx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_993:
	/* 0x993: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_996:
	/* 0x996: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_998:
	/* 0x998: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_99b:
	/* 0x99b: je     9f4 <trace_security_bprm_creds_for_exec+0x9f4> */
	X86_SIM_X86_JCC(X86_CC_E, 0x99b, 0x9f4, x86_l_9f4);
x86_l_99d:
	/* 0x99d: mov    rcx,QWORD PTR [rax+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_9a1:
	/* 0x9a1: mov    QWORD PTR [r14+0x7de0],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32224ULL);
x86_l_9a8:
	/* 0x9a8: mov    rcx,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_9ab:
	/* 0x9ab: mov    QWORD PTR [r14+0x7dd8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32216ULL);
x86_l_9b2:
	/* 0x9b2: mov    rcx,QWORD PTR [rax+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_9b6:
	/* 0x9b6: mov    rdx,QWORD PTR [rax+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_9ba:
	/* 0x9ba: mov    QWORD PTR [r14+0x7de8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32232ULL);
x86_l_9c1:
	/* 0x9c1: mov    QWORD PTR [r14+0x7df0],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32240ULL);
x86_l_9c8:
	/* 0x9c8: mov    rcx,QWORD PTR [rax+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_9cc:
	/* 0x9cc: mov    QWORD PTR [r14+0x7df8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32248ULL);
x86_l_9d3:
	/* 0x9d3: mov    rcx,QWORD PTR [rax+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_9d7:
	/* 0x9d7: mov    QWORD PTR [r14+0x7e00],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32256ULL);
x86_l_9de:
	/* 0x9de: mov    rcx,QWORD PTR [rax+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_9e2:
	/* 0x9e2: mov    QWORD PTR [r14+0x7e08],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32264ULL);
x86_l_9e9:
	/* 0x9e9: mov    rax,QWORD PTR [rax+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_9ed:
	/* 0x9ed: mov    QWORD PTR [r14+0x7e10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32272ULL);
x86_l_9f4:
	/* 0x9f4: mov    rax,QWORD PTR [r14+0x7dd8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32216ULL);
x86_l_9fb:
	/* 0x9fb: mov    QWORD PTR [r14+0x80],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_a02:
	/* 0xa02: mov    ecx,DWORD PTR [r15] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_a05:
	/* 0xa05: xor    edx,edx */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RDX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_a07:
	/* 0xa07: mov    QWORD PTR [rsp+0x78],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_a0c:
	/* 0xa0c: cmp    ecx,DWORD PTR [r14+0x24] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_32), 36ULL);
x86_l_a10:
	/* 0xa10: jne    a29 <trace_security_bprm_creds_for_exec+0xa29> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xa10, 0xa29, x86_l_a29);
x86_l_a12:
	/* 0xa12: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_a14:
	/* 0xa14: and    rax,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RBX, X86_WIDTH_64, X86_ALU_AND);
x86_l_a17:
	/* 0xa17: mov    QWORD PTR [r14+0x80],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_a1e:
	/* 0xa1e: jne    120c <trace_security_bprm_creds_for_exec+0x120c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xa1e, 0x120c, x86_l_120c);
x86_l_a24:
	/* 0xa24: jmp    1c64 <trace_security_bprm_creds_for_exec+0x1c64> */
	X86_SIM_X86_JMP(0xa24, 0x1c64, x86_l_1c64);
x86_l_a29:
	/* 0xa29: mov    rax,QWORD PTR [r14+0x7e50] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32336ULL);
x86_l_a30:
	/* 0xa30: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_a33:
	/* 0xa33: je     bdf <trace_security_bprm_creds_for_exec+0xbdf> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa33, 0xbdf, x86_l_bdf);
x86_l_a39:
	/* 0xa39: movzx  ecx,BYTE PTR [r13+0xb1] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R13, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 177ULL);
x86_l_a41:
	/* 0xa41: and    cl,0xfd */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_8, X86_ALU_AND, 253ULL);
x86_l_a44:
	/* 0xa44: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_a46:
	/* 0xa46: cmp    cl,0x1 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_8, 1ULL);
x86_l_a49:
	/* 0xa49: sete   bl */
	X86_SIM_L_EXEC_SETCC(X86_RBX, X86_CC_E);
x86_l_a4c:
	/* 0xa4c: not    rax */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_a4f:
	/* 0xa4f: neg    rbx */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_a52:
	/* 0xa52: xor    rbx,QWORD PTR [r14+0x7ec0] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RBX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32448ULL);
x86_l_a59:
	/* 0xa59: or     rbx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_OR);
x86_l_a5c:
	/* 0xa5c: mov    rax,QWORD PTR [r14+0x7e58] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_a63:
	/* 0xa63: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_a66:
	/* 0xa66: je     a88 <trace_security_bprm_creds_for_exec+0xa88> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa66, 0xa88, x86_l_a88);
x86_l_a68:
	/* 0xa68: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_a6a:
	/* 0xa6a: cmp    BYTE PTR [r13+0xb1],0x3 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R13, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 760209211395ULL);
x86_l_a72:
	/* 0xa72: sete   cl */
	X86_SIM_L_EXEC_SETCC(X86_RCX, X86_CC_E);
x86_l_a75:
	/* 0xa75: not    rax */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_a78:
	/* 0xa78: neg    rcx */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_a7b:
	/* 0xa7b: xor    rcx,QWORD PTR [r14+0x7ec8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32456ULL);
x86_l_a82:
	/* 0xa82: or     rcx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR);
x86_l_a85:
	/* 0xa85: and    rbx,rcx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_AND);
x86_l_a88:
	/* 0xa88: mov    rax,QWORD PTR [r14+0x7e60] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32352ULL);
x86_l_a8f:
	/* 0xa8f: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_a92:
	/* 0xa92: je     aae <trace_security_bprm_creds_for_exec+0xaae> */
	X86_SIM_X86_JCC(X86_CC_E, 0xa92, 0xaae, x86_l_aae);
x86_l_a94:
	/* 0xa94: mov    ecx,DWORD PTR [r14+0x5c] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 92ULL);
x86_l_a98:
	/* 0xa98: not    rax */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_a9b:
	/* 0xa9b: and    ecx,0x1 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 1ULL);
x86_l_a9e:
	/* 0xa9e: neg    rcx */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_aa1:
	/* 0xaa1: xor    rcx,QWORD PTR [r14+0x7ed0] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32464ULL);
x86_l_aa8:
	/* 0xaa8: or     rcx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR);
x86_l_aab:
	/* 0xaab: and    rbx,rcx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_AND);
x86_l_aae:
	/* 0xaae: mov    rax,QWORD PTR [r14+0x7e68] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32360ULL);
x86_l_ab5:
	/* 0xab5: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_ab8:
	/* 0xab8: mov    QWORD PTR [rsp+0x88],rbp */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_ac0:
	/* 0xac0: je     ade <trace_security_bprm_creds_for_exec+0xade> */
	X86_SIM_X86_JCC(X86_CC_E, 0xac0, 0xade, x86_l_ade);
x86_l_ac2:
	/* 0xac2: not    rax */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_ac5:
	/* 0xac5: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_aca:
	/* 0xaca: movsx  rcx,BYTE PTR [rcx] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOVSX_LOAD, X86_RCX, X86_RCX, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8), 0ULL);
x86_l_ace:
	/* 0xace: neg    rcx */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_64, X86_ALU_NEG, 0);
x86_l_ad1:
	/* 0xad1: xor    rcx,QWORD PTR [r14+0x7ed8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RCX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_XOR)), 32472ULL);
x86_l_ad8:
	/* 0xad8: or     rcx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_64, X86_ALU_OR);
x86_l_adb:
	/* 0xadb: and    rbx,rcx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_AND);
x86_l_ade:
	/* 0xade: movzx  eax,WORD PTR [r14+0x7e] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 126ULL);
x86_l_ae3:
	/* 0xae3: mov    rbp,QWORD PTR [r14+0x7e20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32288ULL);
x86_l_aea:
	/* 0xaea: test   rbp,rbp */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBP, X86_RBP, X86_WIDTH_64);
x86_l_aed:
	/* 0xaed: mov    WORD PTR [rsp+0x28],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_af2:
	/* 0xaf2: je     c47 <trace_security_bprm_creds_for_exec+0xc47> */
	X86_SIM_X86_JCC(X86_CC_E, 0xaf2, 0xc47, x86_l_c47);
x86_l_af8:
	/* 0xaf8: mov    rcx,QWORD PTR [r14+0x7e90] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32400ULL);
x86_l_aff:
	/* 0xaff: mov    QWORD PTR [rsp+0xa0],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 160ULL);
x86_l_b07:
	/* 0xb07: mov    rcx,QWORD PTR [r14+0x7f08] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32520ULL);
x86_l_b0e:
	/* 0xb0e: mov    QWORD PTR [rsp+0x20],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_b13:
	/* 0xb13: mov    rcx,QWORD PTR [r14+0x7f10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32528ULL);
x86_l_b1a:
	/* 0xb1a: mov    QWORD PTR [rsp+0x90],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_b22:
	/* 0xb22: mov    WORD PTR [rsp+0x30],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_b27:
	/* 0xb27: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)pid_filter_version));
x86_l_b2e:
	/* 0xb2e: lea    rsi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_b33:
	/* 0xb33: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_b38:
	/* 0xb38: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_b3a:
	/* 0xb3a: mov    r13,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_64);
x86_l_b3d:
	/* 0xb3d: mov    eax,DWORD PTR [r14+0x24] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_b41:
	/* 0xb41: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_b46:
	/* 0xb46: mov    r15,0xffffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_64, 18446744073709551615ULL);
x86_l_b4d:
	/* 0xb4d: test   r13,r13 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64);
x86_l_b50:
	/* 0xb50: je     b72 <trace_security_bprm_creds_for_exec+0xb72> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb50, 0xb72, x86_l_b72);
x86_l_b52:
	/* 0xb52: lea    rsi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_b57:
	/* 0xb57: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_b5c:
	/* 0xb5c: mov    rdi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R13, X86_WIDTH_64);
x86_l_b5f:
	/* 0xb5f: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_b61:
	/* 0xb61: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_b64:
	/* 0xb64: je     b72 <trace_security_bprm_creds_for_exec+0xb72> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb64, 0xb72, x86_l_b72);
x86_l_b66:
	/* 0xb66: mov    r12,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_b69:
	/* 0xb69: mov    r15,QWORD PTR [rax+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_b6d:
	/* 0xb6d: not    r15 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_b70:
	/* 0xb70: jmp    b75 <trace_security_bprm_creds_for_exec+0xb75> */
	X86_SIM_X86_JMP(0xb70, 0xb75, x86_l_b75);
x86_l_b72:
	/* 0xb72: xor    r12d,r12d */
	X86_SIM_L_EXEC_ALU_REG(X86_R12, X86_R12, X86_WIDTH_32, X86_ALU_XOR);
x86_l_b75:
	/* 0xb75: mov    rdx,QWORD PTR [rsp+0x90] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_b7d:
	/* 0xb7d: mov    rsi,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_b82:
	/* 0xb82: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_b87:
	/* 0xb87: dec    rsi */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_b8a:
	/* 0xb8a: cmp    rsi,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64);
x86_l_b8d:
	/* 0xb8d: jb     ba5 <trace_security_bprm_creds_for_exec+0xba5> */
	X86_SIM_X86_JCC(X86_CC_B, 0xb8d, 0xba5, x86_l_ba5);
x86_l_b8f:
	/* 0xb8f: cmp    rdx,0xffffffffffffffff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_64, 18446744073709551615ULL);
x86_l_b93:
	/* 0xb93: je     b9a <trace_security_bprm_creds_for_exec+0xb9a> */
	X86_SIM_X86_JCC(X86_CC_E, 0xb93, 0xb9a, x86_l_b9a);
x86_l_b95:
	/* 0xb95: cmp    rax,rdx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64);
x86_l_b98:
	/* 0xb98: jbe    ba5 <trace_security_bprm_creds_for_exec+0xba5> */
	X86_SIM_X86_JCC(X86_CC_BE, 0xb98, 0xba5, x86_l_ba5);
x86_l_b9a:
	/* 0xb9a: and    r15,QWORD PTR [rsp+0xa0] */
	X86_SIM_L_EXEC_ALU_MEM(X86_R15, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 160ULL);
x86_l_ba2:
	/* 0xba2: or     r12,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_R12, X86_R15, X86_WIDTH_64, X86_ALU_OR);
x86_l_ba5:
	/* 0xba5: mov    eax,DWORD PTR [r14+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_ba9:
	/* 0xba9: mov    QWORD PTR [rsp+0x30],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_bae:
	/* 0xbae: mov    r15,0xffffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_R15, X86_WIDTH_64, 18446744073709551615ULL);
x86_l_bb5:
	/* 0xbb5: test   r13,r13 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R13, X86_R13, X86_WIDTH_64);
x86_l_bb8:
	/* 0xbb8: je     bfb <trace_security_bprm_creds_for_exec+0xbfb> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbb8, 0xbfb, x86_l_bfb);
x86_l_bba:
	/* 0xbba: mov    QWORD PTR [rsp+0x20],rsi */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RSI, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_bbf:
	/* 0xbbf: lea    rsi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_bc4:
	/* 0xbc4: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_bc9:
	/* 0xbc9: mov    rdi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R13, X86_WIDTH_64);
x86_l_bcc:
	/* 0xbcc: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_bce:
	/* 0xbce: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_bd1:
	/* 0xbd1: je     c0c <trace_security_bprm_creds_for_exec+0xc0c> */
	X86_SIM_X86_JCC(X86_CC_E, 0xbd1, 0xc0c, x86_l_c0c);
x86_l_bd3:
	/* 0xbd3: mov    rcx,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_bd6:
	/* 0xbd6: mov    r15,QWORD PTR [rax+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_bda:
	/* 0xbda: not    r15 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_bdd:
	/* 0xbdd: jmp    c0e <trace_security_bprm_creds_for_exec+0xc0e> */
	X86_SIM_X86_JMP(0xbdd, 0xc0e, x86_l_c0e);
x86_l_bdf:
	/* 0xbdf: mov    rbx,0xffffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBX, X86_WIDTH_64, 18446744073709551615ULL);
x86_l_be6:
	/* 0xbe6: mov    rax,QWORD PTR [r14+0x7e58] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32344ULL);
x86_l_bed:
	/* 0xbed: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_bf0:
	/* 0xbf0: jne    a68 <trace_security_bprm_creds_for_exec+0xa68> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xbf0, 0xa68, x86_l_a68);
x86_l_bf6:
	/* 0xbf6: jmp    a88 <trace_security_bprm_creds_for_exec+0xa88> */
	X86_SIM_X86_JMP(0xbf6, 0xa88, x86_l_a88);
x86_l_bfb:
	/* 0xbfb: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_bfd:
	/* 0xbfd: not    rbp */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBP, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_c00:
	/* 0xc00: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_c05:
	/* 0xc05: cmp    rsi,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64);
x86_l_c08:
	/* 0xc08: jae    c28 <trace_security_bprm_creds_for_exec+0xc28> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xc08, 0xc28, x86_l_c28);
x86_l_c0a:
	/* 0xc0a: jmp    c3e <trace_security_bprm_creds_for_exec+0xc3e> */
	X86_SIM_X86_JMP(0xc0a, 0xc3e, x86_l_c3e);
x86_l_c0c:
	/* 0xc0c: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_c0e:
	/* 0xc0e: mov    rdx,QWORD PTR [rsp+0x90] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 144ULL);
x86_l_c16:
	/* 0xc16: mov    rsi,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_c1b:
	/* 0xc1b: not    rbp */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBP, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_c1e:
	/* 0xc1e: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_c23:
	/* 0xc23: cmp    rsi,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RSI, X86_RAX, X86_WIDTH_64);
x86_l_c26:
	/* 0xc26: jb     c3e <trace_security_bprm_creds_for_exec+0xc3e> */
	X86_SIM_X86_JCC(X86_CC_B, 0xc26, 0xc3e, x86_l_c3e);
x86_l_c28:
	/* 0xc28: cmp    rdx,0xffffffffffffffff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RDX, X86_WIDTH_64, 18446744073709551615ULL);
x86_l_c2c:
	/* 0xc2c: je     c33 <trace_security_bprm_creds_for_exec+0xc33> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc2c, 0xc33, x86_l_c33);
x86_l_c2e:
	/* 0xc2e: cmp    rax,rdx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_RDX, X86_WIDTH_64);
x86_l_c31:
	/* 0xc31: jbe    c3e <trace_security_bprm_creds_for_exec+0xc3e> */
	X86_SIM_X86_JCC(X86_CC_BE, 0xc31, 0xc3e, x86_l_c3e);
x86_l_c33:
	/* 0xc33: and    r15,QWORD PTR [rsp+0xa0] */
	X86_SIM_L_EXEC_ALU_MEM(X86_R15, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 160ULL);
x86_l_c3b:
	/* 0xc3b: or     rcx,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_R15, X86_WIDTH_64, X86_ALU_OR);
x86_l_c3e:
	/* 0xc3e: or     r12,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_R12, X86_RBP, X86_WIDTH_64, X86_ALU_OR);
x86_l_c41:
	/* 0xc41: or     r12,rcx */
	X86_SIM_L_EXEC_ALU_REG(X86_R12, X86_RCX, X86_WIDTH_64, X86_ALU_OR);
x86_l_c44:
	/* 0xc44: and    rbx,r12 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_R12, X86_WIDTH_64, X86_ALU_AND);
x86_l_c47:
	/* 0xc47: cmp    QWORD PTR [r14+0x7e18],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138641544314880ULL);
x86_l_c4f:
	/* 0xc4f: je     cec <trace_security_bprm_creds_for_exec+0xcec> */
	X86_SIM_X86_JCC(X86_CC_E, 0xc4f, 0xcec, x86_l_cec);
x86_l_c55:
	/* 0xc55: mov    eax,0xf */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 15ULL);
x86_l_c5a:
	/* 0xc5a: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xfULL: X86_SIM_BPF_CALL_bpf_get_current_uid_gid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xfULL: X86_SIM_BPF_CALL_bpf_get_current_uid_gid(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_c5c:
	/* 0xc5c: mov    DWORD PTR [r14+0x30],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_c60:
	/* 0xc60: mov    r15,QWORD PTR [r14+0x7e18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32280ULL);
x86_l_c67:
	/* 0xc67: mov    rax,QWORD PTR [r14+0x7e88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32392ULL);
x86_l_c6e:
	/* 0xc6e: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_c73:
	/* 0xc73: mov    rbp,QWORD PTR [r14+0x7ef8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32504ULL);
x86_l_c7a:
	/* 0xc7a: mov    r13,QWORD PTR [r14+0x7f00] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32512ULL);
x86_l_c81:
	/* 0xc81: movzx  eax,WORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 40ULL);
x86_l_c86:
	/* 0xc86: mov    WORD PTR [rsp+0x30],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_c8b:
	/* 0xc8b: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)uid_filter_version));
x86_l_c92:
	/* 0xc92: lea    rsi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_c97:
	/* 0xc97: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_c9c:
	/* 0xc9c: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_c9e:
	/* 0xc9e: mov    ecx,DWORD PTR [r14+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_ca2:
	/* 0xca2: mov    QWORD PTR [rsp+0x30],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_ca7:
	/* 0xca7: mov    r12,0xffffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_R12, X86_WIDTH_64, 18446744073709551615ULL);
x86_l_cae:
	/* 0xcae: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_cb1:
	/* 0xcb1: je     cd3 <trace_security_bprm_creds_for_exec+0xcd3> */
	X86_SIM_X86_JCC(X86_CC_E, 0xcb1, 0xcd3, x86_l_cd3);
x86_l_cb3:
	/* 0xcb3: lea    rsi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_cb8:
	/* 0xcb8: mov    ecx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_cbd:
	/* 0xcbd: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_cc0:
	/* 0xcc0: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_cc2:
	/* 0xcc2: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_cc5:
	/* 0xcc5: je     cd3 <trace_security_bprm_creds_for_exec+0xcd3> */
	X86_SIM_X86_JCC(X86_CC_E, 0xcc5, 0xcd3, x86_l_cd3);
x86_l_cc7:
	/* 0xcc7: mov    rcx,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_cca:
	/* 0xcca: mov    r12,QWORD PTR [rax+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_cce:
	/* 0xcce: not    r12 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R12, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_cd1:
	/* 0xcd1: jmp    cd5 <trace_security_bprm_creds_for_exec+0xcd5> */
	X86_SIM_X86_JMP(0xcd1, 0xcd5, x86_l_cd5);
x86_l_cd3:
	/* 0xcd3: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_cd5:
	/* 0xcd5: not    r15 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_cd8:
	/* 0xcd8: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_cdd:
	/* 0xcdd: dec    rbp */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBP, X86_WIDTH_64, X86_ALU_DEC, 1);
x86_l_ce0:
	/* 0xce0: cmp    rbp,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RBP, X86_RAX, X86_WIDTH_64);
x86_l_ce3:
	/* 0xce3: jae    d00 <trace_security_bprm_creds_for_exec+0xd00> */
	X86_SIM_X86_JCC(X86_CC_AE, 0xce3, 0xd00, x86_l_d00);
x86_l_ce5:
	/* 0xce5: movzx  ebp,WORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 40ULL);
x86_l_cea:
	/* 0xcea: jmp    d18 <trace_security_bprm_creds_for_exec+0xd18> */
	X86_SIM_X86_JMP(0xcea, 0xd18, x86_l_d18);
x86_l_cec:
	/* 0xcec: movzx  ebp,WORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 40ULL);
x86_l_cf1:
	/* 0xcf1: cmp    QWORD PTR [r14+0x7e28],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138710263791616ULL);
x86_l_cf9:
	/* 0xcf9: jne    d2c <trace_security_bprm_creds_for_exec+0xd2c> */
	X86_SIM_X86_JCC(X86_CC_NE, 0xcf9, 0xd2c, x86_l_d2c);
x86_l_cfb:
	/* 0xcfb: jmp    df9 <trace_security_bprm_creds_for_exec+0xdf9> */
	X86_SIM_X86_JMP(0xcfb, 0xdf9, x86_l_df9);
x86_l_d00:
	/* 0xd00: cmp    r13,0xffffffffffffffff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R13, X86_WIDTH_64, 18446744073709551615ULL);
x86_l_d04:
	/* 0xd04: movzx  ebp,WORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 40ULL);
x86_l_d09:
	/* 0xd09: je     d10 <trace_security_bprm_creds_for_exec+0xd10> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd09, 0xd10, x86_l_d10);
x86_l_d0b:
	/* 0xd0b: cmp    rax,r13 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RAX, X86_R13, X86_WIDTH_64);
x86_l_d0e:
	/* 0xd0e: jbe    d18 <trace_security_bprm_creds_for_exec+0xd18> */
	X86_SIM_X86_JCC(X86_CC_BE, 0xd0e, 0xd18, x86_l_d18);
x86_l_d10:
	/* 0xd10: and    r12,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_ALU_MEM(X86_R12, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 32ULL);
x86_l_d15:
	/* 0xd15: or     rcx,r12 */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_R12, X86_WIDTH_64, X86_ALU_OR);
x86_l_d18:
	/* 0xd18: or     rcx,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_R15, X86_WIDTH_64, X86_ALU_OR);
x86_l_d1b:
	/* 0xd1b: and    rbx,rcx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RCX, X86_WIDTH_64, X86_ALU_AND);
x86_l_d1e:
	/* 0xd1e: cmp    QWORD PTR [r14+0x7e28],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138710263791616ULL);
x86_l_d26:
	/* 0xd26: je     df9 <trace_security_bprm_creds_for_exec+0xdf9> */
	X86_SIM_X86_JCC(X86_CC_E, 0xd26, 0xdf9, x86_l_df9);
x86_l_d2c:
	/* 0xd2c: mov    edx,0x90 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 144ULL);
x86_l_d31:
	/* 0xd31: add    rdx,QWORD PTR [r14+0x7dd0] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_d38:
	/* 0xd38: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_d3d:
	/* 0xd3d: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_d42:
	/* 0xd42: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_d47:
	/* 0xd47: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_d4c:
	/* 0xd4c: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_d4e:
	/* 0xd4e: mov    rdx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_d53:
	/* 0xd53: add    rdx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_d57:
	/* 0xd57: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_d5c:
	/* 0xd5c: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_d61:
	/* 0xd61: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_d66:
	/* 0xd66: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_d6b:
	/* 0xd6b: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_d6d:
	/* 0xd6d: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_d72:
	/* 0xd72: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_d77:
	/* 0xd77: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_d7c:
	/* 0xd7c: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_d82:
	/* 0xd82: mov    rdx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_d87:
	/* 0xd87: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_d8c:
	/* 0xd8c: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_d8f:
	/* 0xd8f: mov    eax,DWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_d93:
	/* 0xd93: mov    DWORD PTR [r14+0x34],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_d97:
	/* 0xd97: mov    r15,QWORD PTR [r14+0x7e28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32296ULL);
x86_l_d9e:
	/* 0xd9e: mov    r12,QWORD PTR [r14+0x7e98] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32408ULL);
x86_l_da5:
	/* 0xda5: not    r15 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_da8:
	/* 0xda8: mov    WORD PTR [rsp+0x30],bp */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_dad:
	/* 0xdad: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)mnt_ns_filter_version));
x86_l_db4:
	/* 0xdb4: lea    rsi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_db9:
	/* 0xdb9: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_dbe:
	/* 0xdbe: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_dc0:
	/* 0xdc0: mov    r13,0xffffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_64, 18446744073709551615ULL);
x86_l_dc7:
	/* 0xdc7: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_dca:
	/* 0xdca: je     deb <trace_security_bprm_creds_for_exec+0xdeb> */
	X86_SIM_X86_JCC(X86_CC_E, 0xdca, 0xdeb, x86_l_deb);
x86_l_dcc:
	/* 0xdcc: lea    rsi,[r14+0x34] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_dd0:
	/* 0xdd0: mov    ecx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_dd5:
	/* 0xdd5: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_dd8:
	/* 0xdd8: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_dda:
	/* 0xdda: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_ddd:
	/* 0xddd: je     deb <trace_security_bprm_creds_for_exec+0xdeb> */
	X86_SIM_X86_JCC(X86_CC_E, 0xddd, 0xdeb, x86_l_deb);
x86_l_ddf:
	/* 0xddf: mov    rcx,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_de2:
	/* 0xde2: mov    r13,QWORD PTR [rax+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_de6:
	/* 0xde6: not    r13 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_de9:
	/* 0xde9: jmp    ded <trace_security_bprm_creds_for_exec+0xded> */
	X86_SIM_X86_JMP(0xde9, 0xded, x86_l_ded);
x86_l_deb:
	/* 0xdeb: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_ded:
	/* 0xded: or     r15,rcx */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_RCX, X86_WIDTH_64, X86_ALU_OR);
x86_l_df0:
	/* 0xdf0: and    r13,r12 */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R12, X86_WIDTH_64, X86_ALU_AND);
x86_l_df3:
	/* 0xdf3: or     r13,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R15, X86_WIDTH_64, X86_ALU_OR);
x86_l_df6:
	/* 0xdf6: and    rbx,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_R13, X86_WIDTH_64, X86_ALU_AND);
x86_l_df9:
	/* 0xdf9: cmp    QWORD PTR [r14+0x7e30],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138744623529984ULL);
x86_l_e01:
	/* 0xe01: je     ef5 <trace_security_bprm_creds_for_exec+0xef5> */
	X86_SIM_X86_JCC(X86_CC_E, 0xe01, 0xef5, x86_l_ef5);
x86_l_e07:
	/* 0xe07: mov    rdx,QWORD PTR [r14+0x7dd0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32208ULL);
x86_l_e0e:
	/* 0xe0e: add    rdx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_e12:
	/* 0xe12: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_e17:
	/* 0xe17: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_e1c:
	/* 0xe1c: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_e21:
	/* 0xe21: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_e26:
	/* 0xe26: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_e28:
	/* 0xe28: mov    r13,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_e2d:
	/* 0xe2d: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_e32:
	/* 0xe32: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_e37:
	/* 0xe37: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_e3c:
	/* 0xe3c: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_e41:
	/* 0xe41: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_e44:
	/* 0xe44: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_e46:
	/* 0xe46: mov    eax,DWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_e4a:
	/* 0xe4a: shl    rax,0x4 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_SHL, 4ULL);
x86_l_e4e:
	/* 0xe4e: lea    rdx,[rax+r13*1] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_R13, 0), 0ULL);
x86_l_e52:
	/* 0xe52: add    rdx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_e56:
	/* 0xe56: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_e5b:
	/* 0xe5b: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_e60:
	/* 0xe60: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_e65:
	/* 0xe65: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_e6a:
	/* 0xe6a: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_e6c:
	/* 0xe6c: mov    rdx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_e71:
	/* 0xe71: add    rdx,0xc */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 12ULL);
x86_l_e75:
	/* 0xe75: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_e7a:
	/* 0xe7a: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_e7f:
	/* 0xe7f: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_e84:
	/* 0xe84: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_e89:
	/* 0xe89: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_e8b:
	/* 0xe8b: mov    eax,DWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_e8f:
	/* 0xe8f: mov    DWORD PTR [r14+0x38],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_e93:
	/* 0xe93: mov    r15,QWORD PTR [r14+0x7e30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32304ULL);
x86_l_e9a:
	/* 0xe9a: mov    r12,QWORD PTR [r14+0x7ea0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32416ULL);
x86_l_ea1:
	/* 0xea1: not    r15 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_ea4:
	/* 0xea4: mov    WORD PTR [rsp+0x30],bp */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_ea9:
	/* 0xea9: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)pid_ns_filter_version));
x86_l_eb0:
	/* 0xeb0: lea    rsi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_eb5:
	/* 0xeb5: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_eba:
	/* 0xeba: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_ebc:
	/* 0xebc: mov    r13,0xffffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_64, 18446744073709551615ULL);
x86_l_ec3:
	/* 0xec3: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_ec6:
	/* 0xec6: je     ee7 <trace_security_bprm_creds_for_exec+0xee7> */
	X86_SIM_X86_JCC(X86_CC_E, 0xec6, 0xee7, x86_l_ee7);
x86_l_ec8:
	/* 0xec8: lea    rsi,[r14+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_ecc:
	/* 0xecc: mov    ecx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_ed1:
	/* 0xed1: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_ed4:
	/* 0xed4: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_ed6:
	/* 0xed6: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_ed9:
	/* 0xed9: je     ee7 <trace_security_bprm_creds_for_exec+0xee7> */
	X86_SIM_X86_JCC(X86_CC_E, 0xed9, 0xee7, x86_l_ee7);
x86_l_edb:
	/* 0xedb: mov    rcx,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_ede:
	/* 0xede: mov    r13,QWORD PTR [rax+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_ee2:
	/* 0xee2: not    r13 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_ee5:
	/* 0xee5: jmp    ee9 <trace_security_bprm_creds_for_exec+0xee9> */
	X86_SIM_X86_JMP(0xee5, 0xee9, x86_l_ee9);
x86_l_ee7:
	/* 0xee7: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_ee9:
	/* 0xee9: or     r15,rcx */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_RCX, X86_WIDTH_64, X86_ALU_OR);
x86_l_eec:
	/* 0xeec: and    r13,r12 */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R12, X86_WIDTH_64, X86_ALU_AND);
x86_l_eef:
	/* 0xeef: or     r13,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R15, X86_WIDTH_64, X86_ALU_OR);
x86_l_ef2:
	/* 0xef2: and    rbx,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_R13, X86_WIDTH_64, X86_ALU_AND);
x86_l_ef5:
	/* 0xef5: cmp    QWORD PTR [r14+0x7e38],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138778983268352ULL);
x86_l_efd:
	/* 0xefd: je     fdf <trace_security_bprm_creds_for_exec+0xfdf> */
	X86_SIM_X86_JCC(X86_CC_E, 0xefd, 0xfdf, x86_l_fdf);
x86_l_f03:
	/* 0xf03: mov    edx,0x90 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 144ULL);
x86_l_f08:
	/* 0xf08: add    rdx,QWORD PTR [r14+0x7dd0] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32208ULL);
x86_l_f0f:
	/* 0xf0f: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_f14:
	/* 0xf14: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_f19:
	/* 0xf19: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_f1e:
	/* 0xf1e: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_f23:
	/* 0xf23: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_f25:
	/* 0xf25: mov    rdx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_f2a:
	/* 0xf2a: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_f2f:
	/* 0xf2f: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_f34:
	/* 0xf34: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_f39:
	/* 0xf39: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_f3e:
	/* 0xf3e: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_f40:
	/* 0xf40: mov    rdx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_f45:
	/* 0xf45: lea    rbp,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_f4a:
	/* 0xf4a: mov    eax,0x41 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 65ULL);
x86_l_f4f:
	/* 0xf4f: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_f54:
	/* 0xf54: mov    rdi,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBP, X86_WIDTH_64);
x86_l_f57:
	/* 0xf57: mov    esi,0x41 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 65ULL);
x86_l_f5c:
	/* 0xf5c: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_f5e:
	/* 0xf5e: lea    r13,[r14+0x4c] */
	X86_SIM_L_EXEC_LEA(X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 76ULL);
x86_l_f62:
	/* 0xf62: mov    eax,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 16ULL);
x86_l_f67:
	/* 0xf67: mov    ecx,0x73 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 115ULL);
x86_l_f6c:
	/* 0xf6c: mov    rdi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R13, X86_WIDTH_64);
x86_l_f6f:
	/* 0xf6f: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_f74:
	/* 0xf74: mov    rdx,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBP, X86_WIDTH_64);
x86_l_f77:
	/* 0xf77: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_f79:
	/* 0xf79: mov    r15,QWORD PTR [r14+0x7e38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32312ULL);
x86_l_f80:
	/* 0xf80: mov    r12,QWORD PTR [r14+0x7ea8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32424ULL);
x86_l_f87:
	/* 0xf87: not    r15 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_f8a:
	/* 0xf8a: movzx  eax,WORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 40ULL);
x86_l_f8f:
	/* 0xf8f: mov    WORD PTR [rsp+0x30],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_f94:
	/* 0xf94: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)uts_ns_filter_version));
x86_l_f9b:
	/* 0xf9b: lea    rsi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_fa0:
	/* 0xfa0: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_fa5:
	/* 0xfa5: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_fa7:
	/* 0xfa7: mov    rbp,0xffffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_64, 18446744073709551615ULL);
x86_l_fae:
	/* 0xfae: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_fb1:
	/* 0xfb1: je     fd1 <trace_security_bprm_creds_for_exec+0xfd1> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfb1, 0xfd1, x86_l_fd1);
x86_l_fb3:
	/* 0xfb3: mov    ecx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_fb8:
	/* 0xfb8: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_fbb:
	/* 0xfbb: mov    rsi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R13, X86_WIDTH_64);
x86_l_fbe:
	/* 0xfbe: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_fc0:
	/* 0xfc0: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_fc3:
	/* 0xfc3: je     fd1 <trace_security_bprm_creds_for_exec+0xfd1> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfc3, 0xfd1, x86_l_fd1);
x86_l_fc5:
	/* 0xfc5: mov    rcx,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_fc8:
	/* 0xfc8: mov    rbp,QWORD PTR [rax+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_fcc:
	/* 0xfcc: not    rbp */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBP, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_fcf:
	/* 0xfcf: jmp    fd3 <trace_security_bprm_creds_for_exec+0xfd3> */
	X86_SIM_X86_JMP(0xfcf, 0xfd3, x86_l_fd3);
x86_l_fd1:
	/* 0xfd1: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_fd3:
	/* 0xfd3: or     r15,rcx */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_RCX, X86_WIDTH_64, X86_ALU_OR);
x86_l_fd6:
	/* 0xfd6: and    rbp,r12 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_R12, X86_WIDTH_64, X86_ALU_AND);
x86_l_fd9:
	/* 0xfd9: or     rbp,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_R15, X86_WIDTH_64, X86_ALU_OR);
x86_l_fdc:
	/* 0xfdc: and    rbx,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBP, X86_WIDTH_64, X86_ALU_AND);
x86_l_fdf:
	/* 0xfdf: cmp    QWORD PTR [r14+0x7e40],0x0 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_CMP_MEM_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 138813343006720ULL);
x86_l_fe7:
	/* 0xfe7: movzx  ebp,WORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 40ULL);
x86_l_fec:
	/* 0xfec: je     1070 <trace_security_bprm_creds_for_exec+0x1070> */
	X86_SIM_X86_JCC(X86_CC_E, 0xfec, 0x1070, x86_l_1070);
x86_l_ff2:
	/* 0xff2: lea    r13,[r14+0x3c] */
	X86_SIM_L_EXEC_LEA(X86_R13, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 60ULL);
x86_l_ff6:
	/* 0xff6: mov    eax,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 16ULL);
x86_l_ffb:
	/* 0xffb: mov    ecx,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 16ULL);
x86_l_1000:
	/* 0x1000: mov    rdi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R13, X86_WIDTH_64);
x86_l_1003:
	/* 0x1003: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_1008:
	/* 0x1008: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x10ULL: X86_SIM_BPF_CALL_bpf_get_current_comm(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x10ULL: X86_SIM_BPF_CALL_bpf_get_current_comm(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_100a:
	/* 0x100a: mov    r15,QWORD PTR [r14+0x7e40] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32320ULL);
x86_l_1011:
	/* 0x1011: mov    r12,QWORD PTR [r14+0x7eb0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32432ULL);
x86_l_1018:
	/* 0x1018: not    r15 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_101b:
	/* 0x101b: mov    WORD PTR [rsp+0x30],bp */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1020:
	/* 0x1020: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)comm_filter_version));
x86_l_1027:
	/* 0x1027: lea    rsi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_102c:
	/* 0x102c: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1031:
	/* 0x1031: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1033:
	/* 0x1033: mov    rbp,0xffffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_64, 18446744073709551615ULL);
x86_l_103a:
	/* 0x103a: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_103d:
	/* 0x103d: je     105d <trace_security_bprm_creds_for_exec+0x105d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x103d, 0x105d, x86_l_105d);
x86_l_103f:
	/* 0x103f: mov    ecx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_1044:
	/* 0x1044: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_1047:
	/* 0x1047: mov    rsi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RSI, X86_R13, X86_WIDTH_64);
x86_l_104a:
	/* 0x104a: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_104c:
	/* 0x104c: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_104f:
	/* 0x104f: je     105d <trace_security_bprm_creds_for_exec+0x105d> */
	X86_SIM_X86_JCC(X86_CC_E, 0x104f, 0x105d, x86_l_105d);
x86_l_1051:
	/* 0x1051: mov    rcx,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1054:
	/* 0x1054: mov    rbp,QWORD PTR [rax+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1058:
	/* 0x1058: not    rbp */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBP, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_105b:
	/* 0x105b: jmp    105f <trace_security_bprm_creds_for_exec+0x105f> */
	X86_SIM_X86_JMP(0x105b, 0x105f, x86_l_105f);
x86_l_105d:
	/* 0x105d: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_105f:
	/* 0x105f: or     r15,rcx */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_RCX, X86_WIDTH_64, X86_ALU_OR);
x86_l_1062:
	/* 0x1062: and    rbp,r12 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_R12, X86_WIDTH_64, X86_ALU_AND);
x86_l_1065:
	/* 0x1065: or     rbp,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_R15, X86_WIDTH_64, X86_ALU_OR);
x86_l_1068:
	/* 0x1068: and    rbx,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBP, X86_WIDTH_64, X86_ALU_AND);
x86_l_106b:
	/* 0x106b: movzx  ebp,WORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 40ULL);
x86_l_1070:
	/* 0x1070: mov    r15,QWORD PTR [r14+0x7e48] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32328ULL);
x86_l_1077:
	/* 0x1077: test   r15,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64);
x86_l_107a:
	/* 0x107a: je     10e0 <trace_security_bprm_creds_for_exec+0x10e0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x107a, 0x10e0, x86_l_10e0);
x86_l_107c:
	/* 0x107c: mov    eax,DWORD PTR [r14+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1080:
	/* 0x1080: mov    DWORD PTR [rsp+0x30],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1084:
	/* 0x1084: mov    r12,QWORD PTR [r14+0x7eb8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32440ULL);
x86_l_108b:
	/* 0x108b: not    r15 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_108e:
	/* 0x108e: mov    WORD PTR [rsp+0x10],bp */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1093:
	/* 0x1093: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)cgroup_id_filter_version));
x86_l_109a:
	/* 0x109a: lea    rsi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_109f:
	/* 0x109f: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_10a4:
	/* 0x10a4: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_10a6:
	/* 0x10a6: mov    r13,0xffffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_64, 18446744073709551615ULL);
x86_l_10ad:
	/* 0x10ad: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_10b0:
	/* 0x10b0: je     10d2 <trace_security_bprm_creds_for_exec+0x10d2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10b0, 0x10d2, x86_l_10d2);
x86_l_10b2:
	/* 0x10b2: lea    rsi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_10b7:
	/* 0x10b7: mov    ecx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_10bc:
	/* 0x10bc: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_10bf:
	/* 0x10bf: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_10c1:
	/* 0x10c1: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_10c4:
	/* 0x10c4: je     10d2 <trace_security_bprm_creds_for_exec+0x10d2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10c4, 0x10d2, x86_l_10d2);
x86_l_10c6:
	/* 0x10c6: mov    rcx,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_10c9:
	/* 0x10c9: mov    r13,QWORD PTR [rax+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_10cd:
	/* 0x10cd: not    r13 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_10d0:
	/* 0x10d0: jmp    10d4 <trace_security_bprm_creds_for_exec+0x10d4> */
	X86_SIM_X86_JMP(0x10d0, 0x10d4, x86_l_10d4);
x86_l_10d2:
	/* 0x10d2: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_10d4:
	/* 0x10d4: or     r15,rcx */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_RCX, X86_WIDTH_64, X86_ALU_OR);
x86_l_10d7:
	/* 0x10d7: and    r13,r12 */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R12, X86_WIDTH_64, X86_ALU_AND);
x86_l_10da:
	/* 0x10da: or     r13,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R15, X86_WIDTH_64, X86_ALU_OR);
x86_l_10dd:
	/* 0x10dd: and    rbx,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_R13, X86_WIDTH_64, X86_ALU_AND);
x86_l_10e0:
	/* 0x10e0: mov    r15,QWORD PTR [r14+0x7e70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32368ULL);
x86_l_10e7:
	/* 0x10e7: test   r15,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64);
x86_l_10ea:
	/* 0x10ea: je     1147 <trace_security_bprm_creds_for_exec+0x1147> */
	X86_SIM_X86_JCC(X86_CC_E, 0x10ea, 0x1147, x86_l_1147);
x86_l_10ec:
	/* 0x10ec: mov    r12,QWORD PTR [r14+0x7ee0] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32480ULL);
x86_l_10f3:
	/* 0x10f3: not    r15 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_10f6:
	/* 0x10f6: mov    WORD PTR [rsp+0x30],bp */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_10fb:
	/* 0x10fb: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)process_tree_map_version));
x86_l_1102:
	/* 0x1102: lea    rsi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1107:
	/* 0x1107: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_110c:
	/* 0x110c: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_110e:
	/* 0x110e: mov    r13,0xffffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_R13, X86_WIDTH_64, 18446744073709551615ULL);
x86_l_1115:
	/* 0x1115: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1118:
	/* 0x1118: je     1139 <trace_security_bprm_creds_for_exec+0x1139> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1118, 0x1139, x86_l_1139);
x86_l_111a:
	/* 0x111a: lea    rsi,[r14+0x24] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 36ULL);
x86_l_111e:
	/* 0x111e: mov    ecx,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 1ULL);
x86_l_1123:
	/* 0x1123: mov    rdi,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RAX, X86_WIDTH_64);
x86_l_1126:
	/* 0x1126: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1128:
	/* 0x1128: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_112b:
	/* 0x112b: je     1139 <trace_security_bprm_creds_for_exec+0x1139> */
	X86_SIM_X86_JCC(X86_CC_E, 0x112b, 0x1139, x86_l_1139);
x86_l_112d:
	/* 0x112d: mov    rcx,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1130:
	/* 0x1130: mov    r13,QWORD PTR [rax+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1134:
	/* 0x1134: not    r13 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_1137:
	/* 0x1137: jmp    113b <trace_security_bprm_creds_for_exec+0x113b> */
	X86_SIM_X86_JMP(0x1137, 0x113b, x86_l_113b);
x86_l_1139:
	/* 0x1139: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_113b:
	/* 0x113b: or     r15,rcx */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_RCX, X86_WIDTH_64, X86_ALU_OR);
x86_l_113e:
	/* 0x113e: and    r13,r12 */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R12, X86_WIDTH_64, X86_ALU_AND);
x86_l_1141:
	/* 0x1141: or     r13,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_R13, X86_R15, X86_WIDTH_64, X86_ALU_OR);
x86_l_1144:
	/* 0x1144: and    rbx,r13 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_R13, X86_WIDTH_64, X86_ALU_AND);
x86_l_1147:
	/* 0x1147: mov    r15,QWORD PTR [r14+0x7e78] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32376ULL);
x86_l_114e:
	/* 0x114e: test   r15,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R15, X86_R15, X86_WIDTH_64);
x86_l_1151:
	/* 0x1151: je     11ce <trace_security_bprm_creds_for_exec+0x11ce> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1151, 0x11ce, x86_l_11ce);
x86_l_1153:
	/* 0x1153: mov    r12,QWORD PTR [r14+0x7ee8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32488ULL);
x86_l_115a:
	/* 0x115a: not    r15 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_115d:
	/* 0x115d: mov    WORD PTR [rsp+0x30],bp */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1162:
	/* 0x1162: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)binary_filter_version));
x86_l_1169:
	/* 0x1169: lea    rsi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_116e:
	/* 0x116e: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1173:
	/* 0x1173: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1175:
	/* 0x1175: mov    rbp,0xffffffffffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RBP, X86_WIDTH_64, 18446744073709551615ULL);
x86_l_117c:
	/* 0x117c: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_117f:
	/* 0x117f: je     11c0 <trace_security_bprm_creds_for_exec+0x11c0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x117f, 0x11c0, x86_l_11c0);
x86_l_1181:
	/* 0x1181: mov    r13,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_R13, X86_RAX, X86_WIDTH_64);
x86_l_1184:
	/* 0x1184: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1189:
	/* 0x1189: lea    rsi,[rax+0x14] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 20ULL);
x86_l_118d:
	/* 0x118d: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_1192:
	/* 0x1192: mov    rdi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R13, X86_WIDTH_64);
x86_l_1195:
	/* 0x1195: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1197:
	/* 0x1197: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_119a:
	/* 0x119a: jne    11b4 <trace_security_bprm_creds_for_exec+0x11b4> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x119a, 0x11b4, x86_l_11b4);
x86_l_119c:
	/* 0x119c: mov    rax,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_11a1:
	/* 0x11a1: lea    rsi,[rax+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_11a5:
	/* 0x11a5: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_11aa:
	/* 0x11aa: mov    rdi,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R13, X86_WIDTH_64);
x86_l_11ad:
	/* 0x11ad: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_11af:
	/* 0x11af: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_11b2:
	/* 0x11b2: je     11c0 <trace_security_bprm_creds_for_exec+0x11c0> */
	X86_SIM_X86_JCC(X86_CC_E, 0x11b2, 0x11c0, x86_l_11c0);
x86_l_11b4:
	/* 0x11b4: mov    rcx,QWORD PTR [rax] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_11b7:
	/* 0x11b7: mov    rbp,QWORD PTR [rax+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_11bb:
	/* 0x11bb: not    rbp */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBP, X86_WIDTH_64, X86_ALU_NOT, 0);
x86_l_11be:
	/* 0x11be: jmp    11c2 <trace_security_bprm_creds_for_exec+0x11c2> */
	X86_SIM_X86_JMP(0x11be, 0x11c2, x86_l_11c2);
x86_l_11c0:
	/* 0x11c0: xor    ecx,ecx */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RCX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_11c2:
	/* 0x11c2: or     rcx,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_R15, X86_WIDTH_64, X86_ALU_OR);
x86_l_11c5:
	/* 0x11c5: and    rbp,r12 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_R12, X86_WIDTH_64, X86_ALU_AND);
x86_l_11c8:
	/* 0x11c8: or     rbp,rcx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBP, X86_RCX, X86_WIDTH_64, X86_ALU_OR);
x86_l_11cb:
	/* 0x11cb: and    rbx,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBP, X86_WIDTH_64, X86_ALU_AND);
x86_l_11ce:
	/* 0x11ce: mov    rax,QWORD PTR [r14+0x7e80] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32384ULL);
x86_l_11d5:
	/* 0x11d5: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_11d8:
	/* 0x11d8: mov    rbp,QWORD PTR [rsp+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_11e0:
	/* 0x11e0: je     11ee <trace_security_bprm_creds_for_exec+0x11ee> */
	X86_SIM_X86_JCC(X86_CC_E, 0x11e0, 0x11ee, x86_l_11ee);
x86_l_11e2:
	/* 0x11e2: mov    rcx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_11e7:
	/* 0x11e7: and    rax,QWORD PTR [rcx+0x8] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RAX, X86_RCX, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 8ULL);
x86_l_11eb:
	/* 0x11eb: or     rbx,rax */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RAX, X86_WIDTH_64, X86_ALU_OR);
x86_l_11ee:
	/* 0x11ee: and    rbx,QWORD PTR [r14+0x7ef0] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RBX, X86_R14, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_AND)), 32496ULL);
x86_l_11f5:
	/* 0x11f5: mov    rax,QWORD PTR [r14+0x80] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_11fc:
	/* 0x11fc: and    rax,rbx */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RBX, X86_WIDTH_64, X86_ALU_AND);
x86_l_11ff:
	/* 0x11ff: mov    QWORD PTR [r14+0x80],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 128ULL);
x86_l_1206:
	/* 0x1206: je     1c64 <trace_security_bprm_creds_for_exec+0x1c64> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1206, 0x1c64, x86_l_1c64);
x86_l_120c:
	/* 0x120c: mov    r12,QWORD PTR [rbp+0x70] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R12, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 112ULL);
x86_l_1210:
	/* 0x1210: mov    eax,0xffffffff */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4294967295ULL);
x86_l_1215:
	/* 0x1215: mov    QWORD PTR [rsp+0x78],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_121a:
	/* 0x121a: test   r12,r12 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_R12, X86_R12, X86_WIDTH_64);
x86_l_121d:
	/* 0x121d: je     1c64 <trace_security_bprm_creds_for_exec+0x1c64> */
	X86_SIM_X86_JCC(X86_CC_E, 0x121d, 0x1c64, x86_l_1c64);
x86_l_1223:
	/* 0x1223: mov    QWORD PTR [rsp+0x88],rbp */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_122b:
	/* 0x122b: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1230:
	/* 0x1230: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_1235:
	/* 0x1235: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_123a:
	/* 0x123a: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_123f:
	/* 0x123f: mov    rdx,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R12, X86_WIDTH_64);
x86_l_1242:
	/* 0x1242: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1244:
	/* 0x1244: mov    r13,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R13, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1249:
	/* 0x1249: lea    rdx,[r12+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R12, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_124e:
	/* 0x124e: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1253:
	/* 0x1253: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_1258:
	/* 0x1258: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_125d:
	/* 0x125d: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1262:
	/* 0x1262: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1264:
	/* 0x1264: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_126c:
	/* 0x126c: cmp    rax,0x7cff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 31999ULL);
x86_l_1272:
	/* 0x1272: ja     1304 <trace_security_bprm_creds_for_exec+0x1304> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1272, 0x1304, x86_l_1304);
x86_l_1278:
	/* 0x1278: mov    rdx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_127d:
	/* 0x127d: mov    BYTE PTR [r14+rax*1+0x89],0x2 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 588410519554ULL);
x86_l_1286:
	/* 0x1286: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_128e:
	/* 0x128e: mov    WORD PTR [r14+0x7d90],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32144ULL);
x86_l_1296:
	/* 0x1296: cmp    rax,0x6cfb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 27899ULL);
x86_l_129c:
	/* 0x129c: ja     1304 <trace_security_bprm_creds_for_exec+0x1304> */
	X86_SIM_X86_JCC(X86_CC_A, 0x129c, 0x1304, x86_l_1304);
x86_l_129e:
	/* 0x129e: add    rax,r14 */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_R14, X86_WIDTH_64, X86_ALU_ADD);
x86_l_12a1:
	/* 0x12a1: add    rax,0x8e */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 142ULL);
x86_l_12a7:
	/* 0x12a7: mov    ecx,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4096ULL);
x86_l_12ac:
	/* 0x12ac: mov    r8d,0x2d */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 45ULL);
x86_l_12b2:
	/* 0x12b2: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_12ba:
	/* 0x12ba: lea    rdi,[rax+r14*1] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_12be:
	/* 0x12be: add    rdi,0x8e */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 142ULL);
x86_l_12c5:
	/* 0x12c5: mov    esi,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4096ULL);
x86_l_12ca:
	/* 0x12ca: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x2dULL: X86_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x2dULL: X86_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_12cd:
	/* 0x12cd: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_12cf:
	/* 0x12cf: jle    1304 <trace_security_bprm_creds_for_exec+0x1304> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x12cf, 0x1304, x86_l_1304);
x86_l_12d1:
	/* 0x12d1: movzx  ecx,WORD PTR [r14+0x7d8a] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_12d9:
	/* 0x12d9: cmp    rcx,0x6cfb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 27899ULL);
x86_l_12e0:
	/* 0x12e0: ja     1304 <trace_security_bprm_creds_for_exec+0x1304> */
	X86_SIM_X86_JCC(X86_CC_A, 0x12e0, 0x1304, x86_l_1304);
x86_l_12e2:
	/* 0x12e2: mov    DWORD PTR [rcx+r14*1+0x8a],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 138ULL);
x86_l_12ea:
	/* 0x12ea: add    ax,WORD PTR [r14+0x7d8a] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RAX, X86_R14, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32138ULL);
x86_l_12f2:
	/* 0x12f2: add    eax,0x5 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_12f5:
	/* 0x12f5: mov    WORD PTR [r14+0x7d8a],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_12fd:
	/* 0x12fd: inc    BYTE PTR [r14+0x88] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_R14, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_1304:
	/* 0x1304: mov    DWORD PTR [rsp+0x30],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 206158430208ULL);
x86_l_130c:
	/* 0x130c: mov    rdi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RDI, 0, ((__u64)(long)bufs));
x86_l_1313:
	/* 0x1313: lea    rsi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1318:
	/* 0x1318: mov    eax,0x1 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 1ULL);
x86_l_131d:
	/* 0x131d: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x1ULL: X86_SIM_BPF_CALL_bpf_map_lookup_elem(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_131f:
	/* 0x131f: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1322:
	/* 0x1322: je     148a <trace_security_bprm_creds_for_exec+0x148a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1322, 0x148a, x86_l_148a);
x86_l_1328:
	/* 0x1328: mov    rbx,rax */
	X86_SIM_L_EXEC_MOV_REG(X86_RBX, X86_RAX, X86_WIDTH_64);
x86_l_132b:
	/* 0x132b: lea    rdx,[r13+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_132f:
	/* 0x132f: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1334:
	/* 0x1334: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_1339:
	/* 0x1339: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_133e:
	/* 0x133e: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1343:
	/* 0x1343: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1345:
	/* 0x1345: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_134a:
	/* 0x134a: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_134f:
	/* 0x134f: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1354:
	/* 0x1354: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_1359:
	/* 0x1359: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_135f:
	/* 0x135f: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1364:
	/* 0x1364: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_1369:
	/* 0x1369: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_136c:
	/* 0x136c: test   BYTE PTR [rsp+0x30],0x20 */
	X86_SIM_L_EXEC_CMP_MEM(X86_OP_TEST_MEM_IMM, X86_RSP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 206158430240ULL);
x86_l_1371:
	/* 0x1371: jne    14a5 <trace_security_bprm_creds_for_exec+0x14a5> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1371, 0x14a5, x86_l_14a5);
x86_l_1377:
	/* 0x1377: mov    QWORD PTR [rsp+0x28],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_137c:
	/* 0x137c: lea    rdx,[r13+0x8] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_R13, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1380:
	/* 0x1380: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1385:
	/* 0x1385: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_138a:
	/* 0x138a: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_138f:
	/* 0x138f: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1394:
	/* 0x1394: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1396:
	/* 0x1396: mov    rbx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_139b:
	/* 0x139b: lea    rax,[rbx-0x10] */
	X86_SIM_L_EXEC_LEA(X86_RAX, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551600ULL);
x86_l_139f:
	/* 0x139f: mov    QWORD PTR [rsp],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13a3:
	/* 0x13a3: lea    rdi,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_13a8:
	/* 0x13a8: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_13ad:
	/* 0x13ad: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_13b3:
	/* 0x13b3: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_13b7:
	/* 0x13b7: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_13bc:
	/* 0x13bc: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_13bf:
	/* 0x13bf: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_13c4:
	/* 0x13c4: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_13c9:
	/* 0x13c9: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_13ce:
	/* 0x13ce: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_13d3:
	/* 0x13d3: mov    rbp,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RBP, X86_RBX, X86_WIDTH_64);
x86_l_13d6:
	/* 0x13d6: mov    rdx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBX, X86_WIDTH_64);
x86_l_13d9:
	/* 0x13d9: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_13db:
	/* 0x13db: mov    r15,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_13e0:
	/* 0x13e0: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_13e5:
	/* 0x13e5: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_13e9:
	/* 0x13e9: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_13ee:
	/* 0x13ee: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_13f3:
	/* 0x13f3: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_13f8:
	/* 0x13f8: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_13fd:
	/* 0x13fd: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_13ff:
	/* 0x13ff: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1404:
	/* 0x1404: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_1407:
	/* 0x1407: je     14df <trace_security_bprm_creds_for_exec+0x14df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1407, 0x14df, x86_l_14df);
x86_l_140d:
	/* 0x140d: mov    rbx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1412:
	/* 0x1412: cmp    rdx,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_64);
x86_l_1415:
	/* 0x1415: je     14df <trace_security_bprm_creds_for_exec+0x14df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1415, 0x14df, x86_l_14df);
x86_l_141b:
	/* 0x141b: add    rdx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_141f:
	/* 0x141f: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1424:
	/* 0x1424: mov    eax,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 16ULL);
x86_l_1429:
	/* 0x1429: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_142e:
	/* 0x142e: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_1433:
	/* 0x1433: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1435:
	/* 0x1435: mov    esi,DWORD PTR [rsp+0x34] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_1439:
	/* 0x1439: mov    rdx,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_143e:
	/* 0x143e: inc    esi */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1440:
	/* 0x1440: and    esi,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1446:
	/* 0x1446: mov    edi,esi */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSI, X86_WIDTH_32);
x86_l_1448:
	/* 0x1448: neg    edi */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_NEG, 0);
x86_l_144a:
	/* 0x144a: and    edi,0x3fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1450:
	/* 0x1450: add    rdi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 40ULL);
x86_l_1455:
	/* 0x1455: mov    eax,0x73 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 115ULL);
x86_l_145a:
	/* 0x145a: call   rax */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RAX);
		switch (X86_SIM_L_REG_TAG(X86_RAX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_145c:
	/* 0x145c: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_145f:
	/* 0x145f: jl     165a <trace_security_bprm_creds_for_exec+0x165a> */
	X86_SIM_X86_JCC(X86_CC_L, 0x145f, 0x165a, x86_l_165a);
x86_l_1465:
	/* 0x1465: mov    rcx,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_146a:
	/* 0x146a: mov    BYTE PTR [rcx+0x3fff],0x2f */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RCX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70364449210415ULL);
x86_l_1471:
	/* 0x1471: mov    ecx,0x4000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 16384ULL);
x86_l_1476:
	/* 0x1476: sub    ecx,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RCX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_1478:
	/* 0x1478: mov    QWORD PTR [rsp+0x8],rcx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RCX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_147d:
	/* 0x147d: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1482:
	/* 0x1482: mov    rdx,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBP, X86_WIDTH_64);
x86_l_1485:
	/* 0x1485: jmp    156b <trace_security_bprm_creds_for_exec+0x156b> */
	X86_SIM_X86_JMP(0x1485, 0x156b, x86_l_156b);
x86_l_148a:
	/* 0x148a: xor    ebx,ebx */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_RBX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_148c:
	/* 0x148c: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_1494:
	/* 0x1494: cmp    rax,0x7cff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 31999ULL);
x86_l_149a:
	/* 0x149a: jbe    17e3 <trace_security_bprm_creds_for_exec+0x17e3> */
	X86_SIM_X86_JCC(X86_CC_BE, 0x149a, 0x17e3, x86_l_17e3);
x86_l_14a0:
	/* 0x14a0: jmp    186d <trace_security_bprm_creds_for_exec+0x186d> */
	X86_SIM_X86_JMP(0x14a0, 0x186d, x86_l_186d);
x86_l_14a5:
	/* 0x14a5: lea    rdx,[rip+0x0] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_REG_NONE, X86_WIDTH_64, X86_LEA_AUX_RODATA, ((__u64)(long)((__u8 *)(__x86_rodata_0) + (0))));
x86_l_14ac:
	/* 0x14ac: mov    eax,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4096ULL);
x86_l_14b1:
	/* 0x14b1: mov    ecx,0x73 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 115ULL);
x86_l_14b6:
	/* 0x14b6: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_14b9:
	/* 0x14b9: mov    esi,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4096ULL);
x86_l_14be:
	/* 0x14be: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_14c0:
	/* 0x14c0: xor    r15d,r15d */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR);
x86_l_14c3:
	/* 0x14c3: add    rbx,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_R15, X86_WIDTH_64, X86_ALU_ADD);
x86_l_14c6:
	/* 0x14c6: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_14ce:
	/* 0x14ce: cmp    rax,0x7cff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 31999ULL);
x86_l_14d4:
	/* 0x14d4: ja     186d <trace_security_bprm_creds_for_exec+0x186d> */
	X86_SIM_X86_JCC(X86_CC_A, 0x14d4, 0x186d, x86_l_186d);
x86_l_14da:
	/* 0x14da: jmp    17e3 <trace_security_bprm_creds_for_exec+0x17e3> */
	X86_SIM_X86_JMP(0x14da, 0x17e3, x86_l_17e3);
x86_l_14df:
	/* 0x14df: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_14e2:
	/* 0x14e2: jne    165a <trace_security_bprm_creds_for_exec+0x165a> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x14e2, 0x165a, x86_l_165a);
x86_l_14e8:
	/* 0x14e8: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_14ec:
	/* 0x14ec: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_14f1:
	/* 0x14f1: je     165a <trace_security_bprm_creds_for_exec+0x165a> */
	X86_SIM_X86_JCC(X86_CC_E, 0x14f1, 0x165a, x86_l_165a);
x86_l_14f7:
	/* 0x14f7: add    rax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_14fb:
	/* 0x14fb: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1500:
	/* 0x1500: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_1505:
	/* 0x1505: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_150b:
	/* 0x150b: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_150f:
	/* 0x150f: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1513:
	/* 0x1513: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1518:
	/* 0x1518: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_151b:
	/* 0x151b: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_151f:
	/* 0x151f: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_1522:
	/* 0x1522: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_1527:
	/* 0x1527: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_152d:
	/* 0x152d: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1531:
	/* 0x1531: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1536:
	/* 0x1536: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1539:
	/* 0x1539: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_153d:
	/* 0x153d: lea    rdi,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1542:
	/* 0x1542: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_1547:
	/* 0x1547: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_154d:
	/* 0x154d: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1551:
	/* 0x1551: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1556:
	/* 0x1556: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1559:
	/* 0x1559: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_155d:
	/* 0x155d: add    rdx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1561:
	/* 0x1561: mov    eax,0x4000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 16384ULL);
x86_l_1566:
	/* 0x1566: mov    QWORD PTR [rsp+0x8],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_156b:
	/* 0x156b: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1570:
	/* 0x1570: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_1575:
	/* 0x1575: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_157a:
	/* 0x157a: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_157f:
	/* 0x157f: mov    QWORD PTR [rsp+0x20],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1584:
	/* 0x1584: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1586:
	/* 0x1586: mov    r15,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_158b:
	/* 0x158b: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1590:
	/* 0x1590: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1594:
	/* 0x1594: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1599:
	/* 0x1599: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_159e:
	/* 0x159e: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_15a3:
	/* 0x15a3: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_15a8:
	/* 0x15a8: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_15aa:
	/* 0x15aa: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_15af:
	/* 0x15af: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_15b2:
	/* 0x15b2: je     1643 <trace_security_bprm_creds_for_exec+0x1643> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15b2, 0x1643, x86_l_1643);
x86_l_15b8:
	/* 0x15b8: mov    rbx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_15bd:
	/* 0x15bd: cmp    rdx,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_64);
x86_l_15c0:
	/* 0x15c0: je     1643 <trace_security_bprm_creds_for_exec+0x1643> */
	X86_SIM_X86_JCC(X86_CC_E, 0x15c0, 0x1643, x86_l_1643);
x86_l_15c6:
	/* 0x15c6: add    rdx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_15ca:
	/* 0x15ca: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_15cf:
	/* 0x15cf: mov    eax,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 16ULL);
x86_l_15d4:
	/* 0x15d4: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_15d9:
	/* 0x15d9: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_15de:
	/* 0x15de: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_15e0:
	/* 0x15e0: mov    esi,DWORD PTR [rsp+0x34] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_15e4:
	/* 0x15e4: inc    esi */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_15e6:
	/* 0x15e6: and    esi,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_15ec:
	/* 0x15ec: mov    r15,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_15f1:
	/* 0x15f1: mov    edi,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_32);
x86_l_15f4:
	/* 0x15f4: sub    edi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RSI, X86_WIDTH_32, X86_ALU_SUB);
x86_l_15f6:
	/* 0x15f6: jb     17aa <trace_security_bprm_creds_for_exec+0x17aa> */
	X86_SIM_X86_JCC(X86_CC_B, 0x15f6, 0x17aa, x86_l_17aa);
x86_l_15fc:
	/* 0x15fc: mov    rdx,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1601:
	/* 0x1601: and    edi,0x3fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1607:
	/* 0x1607: mov    rbp,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_160c:
	/* 0x160c: add    rdi,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD);
x86_l_160f:
	/* 0x160f: mov    eax,esi */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RSI, X86_WIDTH_32);
x86_l_1611:
	/* 0x1611: mov    ecx,0x73 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 115ULL);
x86_l_1616:
	/* 0x1616: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1618:
	/* 0x1618: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_161b:
	/* 0x161b: jl     164d <trace_security_bprm_creds_for_exec+0x164d> */
	X86_SIM_X86_JCC(X86_CC_L, 0x161b, 0x164d, x86_l_164d);
x86_l_161d:
	/* 0x161d: lea    ecx,[r15-0x1] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1621:
	/* 0x1621: and    ecx,0x7fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1627:
	/* 0x1627: mov    BYTE PTR [rbp+rcx*1+0x0],0x2f */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 47ULL);
x86_l_162c:
	/* 0x162c: sub    r15d,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_RAX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_162f:
	/* 0x162f: mov    QWORD PTR [rsp+0x8],r15 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1634:
	/* 0x1634: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1639:
	/* 0x1639: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_163e:
	/* 0x163e: jmp    1719 <trace_security_bprm_creds_for_exec+0x1719> */
	X86_SIM_X86_JMP(0x163e, 0x1719, x86_l_1719);
x86_l_1643:
	/* 0x1643: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_1646:
	/* 0x1646: je     169f <trace_security_bprm_creds_for_exec+0x169f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1646, 0x169f, x86_l_169f);
x86_l_1648:
	/* 0x1648: mov    r15,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_164d:
	/* 0x164d: cmp    r15d,0x4000 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_R15, X86_WIDTH_32, 16384ULL);
x86_l_1654:
	/* 0x1654: jne    17aa <trace_security_bprm_creds_for_exec+0x17aa> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1654, 0x17aa, x86_l_17aa);
x86_l_165a:
	/* 0x165a: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_165f:
	/* 0x165f: add    rdx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1663:
	/* 0x1663: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1668:
	/* 0x1668: mov    eax,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 16ULL);
x86_l_166d:
	/* 0x166d: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_1672:
	/* 0x1672: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_1677:
	/* 0x1677: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1679:
	/* 0x1679: mov    rdx,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_167e:
	/* 0x167e: mov    eax,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4096ULL);
x86_l_1683:
	/* 0x1683: mov    ecx,0x73 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 115ULL);
x86_l_1688:
	/* 0x1688: mov    rbx,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_168d:
	/* 0x168d: mov    rdi,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RBX, X86_WIDTH_64);
x86_l_1690:
	/* 0x1690: mov    esi,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4096ULL);
x86_l_1695:
	/* 0x1695: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1697:
	/* 0x1697: xor    r15d,r15d */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_R15, X86_WIDTH_32, X86_ALU_XOR);
x86_l_169a:
	/* 0x169a: jmp    17c5 <trace_security_bprm_creds_for_exec+0x17c5> */
	X86_SIM_X86_JMP(0x169a, 0x17c5, x86_l_17c5);
x86_l_169f:
	/* 0x169f: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16a3:
	/* 0x16a3: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_16a8:
	/* 0x16a8: je     1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_E, 0x16a8, 0x1648, x86_l_1648);
x86_l_16aa:
	/* 0x16aa: add    rax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_16ae:
	/* 0x16ae: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_16b3:
	/* 0x16b3: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_16b8:
	/* 0x16b8: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_16be:
	/* 0x16be: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16c2:
	/* 0x16c2: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_16c6:
	/* 0x16c6: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_16cb:
	/* 0x16cb: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_16ce:
	/* 0x16ce: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16d2:
	/* 0x16d2: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_16d5:
	/* 0x16d5: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_16da:
	/* 0x16da: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_16e0:
	/* 0x16e0: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16e4:
	/* 0x16e4: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_16e9:
	/* 0x16e9: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_16ec:
	/* 0x16ec: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_16f0:
	/* 0x16f0: lea    rdi,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_16f5:
	/* 0x16f5: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_16fa:
	/* 0x16fa: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_1700:
	/* 0x1700: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1704:
	/* 0x1704: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1709:
	/* 0x1709: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_170c:
	/* 0x170c: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1710:
	/* 0x1710: add    rdx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1714:
	/* 0x1714: mov    rbp,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_1719:
	/* 0x1719: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_171e:
	/* 0x171e: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_1723:
	/* 0x1723: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_1728:
	/* 0x1728: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_172d:
	/* 0x172d: mov    QWORD PTR [rsp+0x20],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1732:
	/* 0x1732: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1734:
	/* 0x1734: mov    r15,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1739:
	/* 0x1739: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_173e:
	/* 0x173e: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1742:
	/* 0x1742: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1747:
	/* 0x1747: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_174c:
	/* 0x174c: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_1751:
	/* 0x1751: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1756:
	/* 0x1756: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1758:
	/* 0x1758: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_175d:
	/* 0x175d: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_1760:
	/* 0x1760: je     1c7f <trace_security_bprm_creds_for_exec+0x1c7f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1760, 0x1c7f, x86_l_1c7f);
x86_l_1766:
	/* 0x1766: mov    rbx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_176b:
	/* 0x176b: cmp    rdx,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_64);
x86_l_176e:
	/* 0x176e: je     1c7f <trace_security_bprm_creds_for_exec+0x1c7f> */
	X86_SIM_X86_JCC(X86_CC_E, 0x176e, 0x1c7f, x86_l_1c7f);
x86_l_1774:
	/* 0x1774: add    rdx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1778:
	/* 0x1778: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_177d:
	/* 0x177d: mov    eax,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 16ULL);
x86_l_1782:
	/* 0x1782: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_1787:
	/* 0x1787: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_178c:
	/* 0x178c: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_178e:
	/* 0x178e: mov    esi,DWORD PTR [rsp+0x34] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_1792:
	/* 0x1792: inc    esi */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1794:
	/* 0x1794: and    esi,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_179a:
	/* 0x179a: mov    r15,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_179f:
	/* 0x179f: mov    edi,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_32);
x86_l_17a2:
	/* 0x17a2: sub    edi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RSI, X86_WIDTH_32, X86_ALU_SUB);
x86_l_17a4:
	/* 0x17a4: jae    1d03 <trace_security_bprm_creds_for_exec+0x1d03> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x17a4, 0x1d03, x86_l_1d03);
x86_l_17aa:
	/* 0x17aa: dec    r15d */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_32, X86_ALU_DEC, 1);
x86_l_17ad:
	/* 0x17ad: mov    eax,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_R15, X86_WIDTH_32);
x86_l_17b0:
	/* 0x17b0: and    eax,0x7fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_17b5:
	/* 0x17b5: mov    rbx,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_17ba:
	/* 0x17ba: mov    BYTE PTR [rbx+rax*1],0x2f */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 47ULL);
x86_l_17be:
	/* 0x17be: mov    BYTE PTR [rbx+0x3fff],0x0 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RBX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_REG_NONE, 0), 70364449210368ULL);
x86_l_17c5:
	/* 0x17c5: and    r15d,0x3fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_R15, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_17cc:
	/* 0x17cc: add    rbx,r15 */
	X86_SIM_L_EXEC_ALU_REG(X86_RBX, X86_R15, X86_WIDTH_64, X86_ALU_ADD);
x86_l_17cf:
	/* 0x17cf: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_17d7:
	/* 0x17d7: cmp    rax,0x7cff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 31999ULL);
x86_l_17dd:
	/* 0x17dd: ja     186d <trace_security_bprm_creds_for_exec+0x186d> */
	X86_SIM_X86_JCC(X86_CC_A, 0x17dd, 0x186d, x86_l_186d);
x86_l_17e3:
	/* 0x17e3: mov    BYTE PTR [r14+rax*1+0x89],0x3 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 588410519555ULL);
x86_l_17ec:
	/* 0x17ec: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_17f4:
	/* 0x17f4: mov    WORD PTR [r14+0x7d92],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32146ULL);
x86_l_17fc:
	/* 0x17fc: cmp    rax,0x6cfb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 27899ULL);
x86_l_1802:
	/* 0x1802: ja     186d <trace_security_bprm_creds_for_exec+0x186d> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1802, 0x186d, x86_l_186d);
x86_l_1804:
	/* 0x1804: add    rax,r14 */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_R14, X86_WIDTH_64, X86_ALU_ADD);
x86_l_1807:
	/* 0x1807: add    rax,0x8e */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 142ULL);
x86_l_180d:
	/* 0x180d: mov    ecx,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4096ULL);
x86_l_1812:
	/* 0x1812: mov    r8d,0x2d */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 45ULL);
x86_l_1818:
	/* 0x1818: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_1820:
	/* 0x1820: lea    rdi,[rax+r14*1] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_1824:
	/* 0x1824: add    rdi,0x8e */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 142ULL);
x86_l_182b:
	/* 0x182b: mov    esi,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4096ULL);
x86_l_1830:
	/* 0x1830: mov    rdx,rbx */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBX, X86_WIDTH_64);
x86_l_1833:
	/* 0x1833: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x2dULL: X86_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x2dULL: X86_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1836:
	/* 0x1836: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1838:
	/* 0x1838: jle    186d <trace_security_bprm_creds_for_exec+0x186d> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x1838, 0x186d, x86_l_186d);
x86_l_183a:
	/* 0x183a: movzx  ecx,WORD PTR [r14+0x7d8a] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_1842:
	/* 0x1842: cmp    rcx,0x6cfb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 27899ULL);
x86_l_1849:
	/* 0x1849: ja     186d <trace_security_bprm_creds_for_exec+0x186d> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1849, 0x186d, x86_l_186d);
x86_l_184b:
	/* 0x184b: mov    DWORD PTR [rcx+r14*1+0x8a],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 138ULL);
x86_l_1853:
	/* 0x1853: add    ax,WORD PTR [r14+0x7d8a] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RAX, X86_R14, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32138ULL);
x86_l_185b:
	/* 0x185b: add    eax,0x5 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_185e:
	/* 0x185e: mov    WORD PTR [r14+0x7d8a],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_1866:
	/* 0x1866: inc    BYTE PTR [r14+0x88] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_R14, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_186d:
	/* 0x186d: add    r13,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R13, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_1871:
	/* 0x1871: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1876:
	/* 0x1876: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_187b:
	/* 0x187b: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_1880:
	/* 0x1880: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1885:
	/* 0x1885: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_1888:
	/* 0x1888: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_188a:
	/* 0x188a: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_188f:
	/* 0x188f: add    rax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1893:
	/* 0x1893: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1898:
	/* 0x1898: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_189d:
	/* 0x189d: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_18a3:
	/* 0x18a3: mov    rdx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_18a8:
	/* 0x18a8: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_18ac:
	/* 0x18ac: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_18b1:
	/* 0x18b1: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_18b4:
	/* 0x18b4: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_18b9:
	/* 0x18b9: lea    rdi,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_18be:
	/* 0x18be: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_18c3:
	/* 0x18c3: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_18c9:
	/* 0x18c9: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_18ce:
	/* 0x18ce: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_18d3:
	/* 0x18d3: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_18d6:
	/* 0x18d6: mov    eax,DWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_18da:
	/* 0x18da: mov    DWORD PTR [rsp],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_18dd:
	/* 0x18dd: movzx  ebx,WORD PTR [r14+0x7d8a] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_18e5:
	/* 0x18e5: cmp    rbx,0x7cff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 31999ULL);
x86_l_18ec:
	/* 0x18ec: ja     1935 <trace_security_bprm_creds_for_exec+0x1935> */
	X86_SIM_X86_JCC(X86_CC_A, 0x18ec, 0x1935, x86_l_1935);
x86_l_18ee:
	/* 0x18ee: mov    BYTE PTR [r14+rbx*1+0x89],0x4 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519556ULL);
x86_l_18f7:
	/* 0x18f7: cmp    ebx,0x7cfb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 31995ULL);
x86_l_18fd:
	/* 0x18fd: ja     1935 <trace_security_bprm_creds_for_exec+0x1935> */
	X86_SIM_X86_JCC(X86_CC_A, 0x18fd, 0x1935, x86_l_1935);
x86_l_18ff:
	/* 0x18ff: lea    rdi,[rbx+r14*1] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_1903:
	/* 0x1903: add    rdi,0x8a */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_190a:
	/* 0x190a: mov    rdx,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RSP, X86_WIDTH_64);
x86_l_190d:
	/* 0x190d: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1912:
	/* 0x1912: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_1917:
	/* 0x1917: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_191c:
	/* 0x191c: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_191e:
	/* 0x191e: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1921:
	/* 0x1921: js     1935 <trace_security_bprm_creds_for_exec+0x1935> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1921, 0x1935, x86_l_1935);
x86_l_1923:
	/* 0x1923: add    ebx,0x5 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_1926:
	/* 0x1926: mov    WORD PTR [r14+0x7d8a],bx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_192e:
	/* 0x192e: inc    BYTE PTR [r14+0x88] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_R14, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_1935:
	/* 0x1935: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_193a:
	/* 0x193a: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_193f:
	/* 0x193f: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_1944:
	/* 0x1944: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1949:
	/* 0x1949: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_194c:
	/* 0x194c: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_194e:
	/* 0x194e: mov    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1953:
	/* 0x1953: add    rax,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1957:
	/* 0x1957: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_195c:
	/* 0x195c: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_1961:
	/* 0x1961: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_1967:
	/* 0x1967: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_196c:
	/* 0x196c: add    rdx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1970:
	/* 0x1970: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1975:
	/* 0x1975: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1978:
	/* 0x1978: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_197d:
	/* 0x197d: mov    QWORD PTR [rsp+0x18],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1982:
	/* 0x1982: movzx  ebx,WORD PTR [r14+0x7d8a] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_198a:
	/* 0x198a: cmp    rbx,0x7cff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 31999ULL);
x86_l_1991:
	/* 0x1991: ja     19dc <trace_security_bprm_creds_for_exec+0x19dc> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1991, 0x19dc, x86_l_19dc);
x86_l_1993:
	/* 0x1993: mov    BYTE PTR [r14+rbx*1+0x89],0x5 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519557ULL);
x86_l_199c:
	/* 0x199c: cmp    ebx,0x7cf7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 31991ULL);
x86_l_19a2:
	/* 0x19a2: ja     19dc <trace_security_bprm_creds_for_exec+0x19dc> */
	X86_SIM_X86_JCC(X86_CC_A, 0x19a2, 0x19dc, x86_l_19dc);
x86_l_19a4:
	/* 0x19a4: lea    rdi,[rbx+r14*1] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_19a8:
	/* 0x19a8: add    rdi,0x8a */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_19af:
	/* 0x19af: lea    rdx,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_19b4:
	/* 0x19b4: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_19b9:
	/* 0x19b9: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_19be:
	/* 0x19be: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_19c3:
	/* 0x19c3: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_19c5:
	/* 0x19c5: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_19c8:
	/* 0x19c8: js     19dc <trace_security_bprm_creds_for_exec+0x19dc> */
	X86_SIM_X86_JCC(X86_CC_S, 0x19c8, 0x19dc, x86_l_19dc);
x86_l_19ca:
	/* 0x19ca: add    ebx,0x9 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_32, X86_ALU_ADD, 9ULL);
x86_l_19cd:
	/* 0x19cd: mov    WORD PTR [r14+0x7d8a],bx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_19d5:
	/* 0x19d5: inc    BYTE PTR [r14+0x88] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_R14, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_19dc:
	/* 0x19dc: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_19e1:
	/* 0x19e1: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_19e6:
	/* 0x19e6: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_19eb:
	/* 0x19eb: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_19f0:
	/* 0x19f0: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_19f3:
	/* 0x19f3: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_19f5:
	/* 0x19f5: mov    rbp,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBP, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_19fa:
	/* 0x19fa: lea    rdx,[rbp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RBP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_19fe:
	/* 0x19fe: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1a03:
	/* 0x1a03: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_1a08:
	/* 0x1a08: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_1a0d:
	/* 0x1a0d: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1a12:
	/* 0x1a12: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1a14:
	/* 0x1a14: add    rbp,0x20 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBP, X86_WIDTH_64, X86_ALU_ADD, 32ULL);
x86_l_1a18:
	/* 0x1a18: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a1d:
	/* 0x1a1d: mov    eax,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 4ULL);
x86_l_1a22:
	/* 0x1a22: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_1a27:
	/* 0x1a27: mov    esi,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4ULL);
x86_l_1a2c:
	/* 0x1a2c: mov    rdx,rbp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_RBP, X86_WIDTH_64);
x86_l_1a2f:
	/* 0x1a2f: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1a31:
	/* 0x1a31: mov    eax,DWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a35:
	/* 0x1a35: mov    QWORD PTR [rsp+0x38],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1a3a:
	/* 0x1a3a: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a3f:
	/* 0x1a3f: lea    rdx,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1a44:
	/* 0x1a44: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_1a49:
	/* 0x1a49: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_1a4e:
	/* 0x1a4e: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1a53:
	/* 0x1a53: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1a55:
	/* 0x1a55: mov    rbx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a5a:
	/* 0x1a5a: test   rbx,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RBX, X86_RBX, X86_WIDTH_64);
x86_l_1a5d:
	/* 0x1a5d: js     1a88 <trace_security_bprm_creds_for_exec+0x1a88> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1a5d, 0x1a88, x86_l_1a88);
x86_l_1a5f:
	/* 0x1a5f: lea    rdx,[rsp+0x38] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1a64:
	/* 0x1a64: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a69:
	/* 0x1a69: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_1a6e:
	/* 0x1a6e: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_1a73:
	/* 0x1a73: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1a78:
	/* 0x1a78: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1a7a:
	/* 0x1a7a: imul   rax,rbx,0x3b9aca00 */
	X86_SIM_L_EXEC_IMUL_IMM(X86_RAX, X86_RBX, X86_WIDTH_64, 1000000000ULL);
x86_l_1a81:
	/* 0x1a81: add    rax,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RAX, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 16ULL);
x86_l_1a86:
	/* 0x1a86: jmp    1a8a <trace_security_bprm_creds_for_exec+0x1a8a> */
	X86_SIM_X86_JMP(0x1a86, 0x1a8a, x86_l_1a8a);
x86_l_1a88:
	/* 0x1a88: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1a8a:
	/* 0x1a8a: mov    r15,QWORD PTR [rsp+0x88] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 136ULL);
x86_l_1a92:
	/* 0x1a92: mov    QWORD PTR [rsp+0x10],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1a97:
	/* 0x1a97: movzx  ebx,WORD PTR [r14+0x7d8a] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_1a9f:
	/* 0x1a9f: cmp    rbx,0x7cff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 31999ULL);
x86_l_1aa6:
	/* 0x1aa6: ja     1af1 <trace_security_bprm_creds_for_exec+0x1af1> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1aa6, 0x1af1, x86_l_1af1);
x86_l_1aa8:
	/* 0x1aa8: mov    BYTE PTR [r14+rbx*1+0x89],0x6 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519558ULL);
x86_l_1ab1:
	/* 0x1ab1: cmp    ebx,0x7cf7 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 31991ULL);
x86_l_1ab7:
	/* 0x1ab7: ja     1af1 <trace_security_bprm_creds_for_exec+0x1af1> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1ab7, 0x1af1, x86_l_1af1);
x86_l_1ab9:
	/* 0x1ab9: lea    rdi,[rbx+r14*1] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_1abd:
	/* 0x1abd: add    rdi,0x8a */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_1ac4:
	/* 0x1ac4: lea    rdx,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ac9:
	/* 0x1ac9: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_1ace:
	/* 0x1ace: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_1ad3:
	/* 0x1ad3: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1ad8:
	/* 0x1ad8: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1ada:
	/* 0x1ada: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1add:
	/* 0x1add: js     1af1 <trace_security_bprm_creds_for_exec+0x1af1> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1add, 0x1af1, x86_l_1af1);
x86_l_1adf:
	/* 0x1adf: add    ebx,0x9 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_32, X86_ALU_ADD, 9ULL);
x86_l_1ae2:
	/* 0x1ae2: mov    WORD PTR [r14+0x7d8a],bx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_1aea:
	/* 0x1aea: inc    BYTE PTR [r14+0x88] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_R14, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_1af1:
	/* 0x1af1: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1af6:
	/* 0x1af6: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_1afb:
	/* 0x1afb: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_1b00:
	/* 0x1b00: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1b05:
	/* 0x1b05: mov    rdx,r13 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R13, X86_WIDTH_64);
x86_l_1b08:
	/* 0x1b08: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1b0a:
	/* 0x1b0a: mov    rax,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1b0f:
	/* 0x1b0f: lea    rdi,[rsp+0x84] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 132ULL);
x86_l_1b17:
	/* 0x1b17: mov    ecx,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 2ULL);
x86_l_1b1c:
	/* 0x1b1c: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_1b22:
	/* 0x1b22: mov    rdx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1b27:
	/* 0x1b27: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_1b2c:
	/* 0x1b2c: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1b2f:
	/* 0x1b2f: movzx  ebx,WORD PTR [r14+0x7d8a] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_1b37:
	/* 0x1b37: cmp    rbx,0x7cff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_64, 31999ULL);
x86_l_1b3e:
	/* 0x1b3e: ja     1b8c <trace_security_bprm_creds_for_exec+0x1b8c> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1b3e, 0x1b8c, x86_l_1b8c);
x86_l_1b40:
	/* 0x1b40: mov    BYTE PTR [r14+rbx*1+0x89],0x7 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RBX, 0), 588410519559ULL);
x86_l_1b49:
	/* 0x1b49: cmp    ebx,0x7cfd */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RBX, X86_WIDTH_32, 31997ULL);
x86_l_1b4f:
	/* 0x1b4f: ja     1b8c <trace_security_bprm_creds_for_exec+0x1b8c> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1b4f, 0x1b8c, x86_l_1b8c);
x86_l_1b51:
	/* 0x1b51: lea    rdi,[rbx+r14*1] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_1b55:
	/* 0x1b55: add    rdi,0x8a */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 138ULL);
x86_l_1b5c:
	/* 0x1b5c: lea    rdx,[rsp+0x84] */
	X86_SIM_L_EXEC_LEA(X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 132ULL);
x86_l_1b64:
	/* 0x1b64: mov    eax,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_1b69:
	/* 0x1b69: mov    ecx,0x4 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4ULL);
x86_l_1b6e:
	/* 0x1b6e: mov    esi,0x2 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 2ULL);
x86_l_1b73:
	/* 0x1b73: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x4ULL: X86_SIM_BPF_CALL_bpf_probe_read(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1b75:
	/* 0x1b75: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1b78:
	/* 0x1b78: js     1b8c <trace_security_bprm_creds_for_exec+0x1b8c> */
	X86_SIM_X86_JCC(X86_CC_S, 0x1b78, 0x1b8c, x86_l_1b8c);
x86_l_1b7a:
	/* 0x1b7a: add    ebx,0x3 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RBX, X86_WIDTH_32, X86_ALU_ADD, 3ULL);
x86_l_1b7d:
	/* 0x1b7d: mov    WORD PTR [r14+0x7d8a],bx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RBX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_1b85:
	/* 0x1b85: inc    BYTE PTR [r14+0x88] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_R14, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_1b8c:
	/* 0x1b8c: add    r12,0x18 */
	X86_SIM_L_EXEC_ALU_IMM(X86_R12, X86_WIDTH_64, X86_ALU_ADD, 24ULL);
x86_l_1b90:
	/* 0x1b90: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1b95:
	/* 0x1b95: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_1b9a:
	/* 0x1b9a: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_1b9f:
	/* 0x1b9f: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1ba4:
	/* 0x1ba4: mov    rdx,r12 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R12, X86_WIDTH_64);
x86_l_1ba7:
	/* 0x1ba7: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1ba9:
	/* 0x1ba9: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_1bb1:
	/* 0x1bb1: cmp    rax,0x7cff */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 31999ULL);
x86_l_1bb7:
	/* 0x1bb7: ja     1c49 <trace_security_bprm_creds_for_exec+0x1c49> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1bb7, 0x1c49, x86_l_1c49);
x86_l_1bbd:
	/* 0x1bbd: mov    rdx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1bc2:
	/* 0x1bc2: mov    BYTE PTR [r14+rax*1+0x89],0x8 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_R14, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RAX, 0), 588410519560ULL);
x86_l_1bcb:
	/* 0x1bcb: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_1bd3:
	/* 0x1bd3: mov    WORD PTR [r14+0x7d9c],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32156ULL);
x86_l_1bdb:
	/* 0x1bdb: cmp    rax,0x6cfb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_64, 27899ULL);
x86_l_1be1:
	/* 0x1be1: ja     1c49 <trace_security_bprm_creds_for_exec+0x1c49> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1be1, 0x1c49, x86_l_1c49);
x86_l_1be3:
	/* 0x1be3: add    rax,r14 */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_R14, X86_WIDTH_64, X86_ALU_ADD);
x86_l_1be6:
	/* 0x1be6: add    rax,0x8e */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 142ULL);
x86_l_1bec:
	/* 0x1bec: mov    ecx,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 4096ULL);
x86_l_1bf1:
	/* 0x1bf1: mov    r8d,0x2d */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 45ULL);
x86_l_1bf7:
	/* 0x1bf7: movzx  eax,WORD PTR [r14+0x7d8a] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_1bff:
	/* 0x1bff: lea    rdi,[rax+r14*1] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_R14, 0), 0ULL);
x86_l_1c03:
	/* 0x1c03: add    rdi,0x8e */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_64, X86_ALU_ADD, 142ULL);
x86_l_1c0a:
	/* 0x1c0a: mov    esi,0x1000 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 4096ULL);
x86_l_1c0f:
	/* 0x1c0f: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x2dULL: X86_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x2dULL: X86_SIM_BPF_CALL_bpf_probe_read_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1c12:
	/* 0x1c12: test   eax,eax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_32);
x86_l_1c14:
	/* 0x1c14: jle    1c49 <trace_security_bprm_creds_for_exec+0x1c49> */
	X86_SIM_X86_JCC(X86_CC_LE, 0x1c14, 0x1c49, x86_l_1c49);
x86_l_1c16:
	/* 0x1c16: movzx  ecx,WORD PTR [r14+0x7d8a] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RCX, X86_R14, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 32138ULL);
x86_l_1c1e:
	/* 0x1c1e: cmp    rcx,0x6cfb */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RCX, X86_WIDTH_64, 27899ULL);
x86_l_1c25:
	/* 0x1c25: ja     1c49 <trace_security_bprm_creds_for_exec+0x1c49> */
	X86_SIM_X86_JCC(X86_CC_A, 0x1c25, 0x1c49, x86_l_1c49);
x86_l_1c27:
	/* 0x1c27: mov    DWORD PTR [rcx+r14*1+0x8a],eax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RCX, X86_RAX, X86_WIDTH_32, X86_MEM_AUX(X86_R14, 0), 138ULL);
x86_l_1c2f:
	/* 0x1c2f: add    ax,WORD PTR [r14+0x7d8a] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RAX, X86_R14, X86_WIDTH_16, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 32138ULL);
x86_l_1c37:
	/* 0x1c37: add    eax,0x5 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_32, X86_ALU_ADD, 5ULL);
x86_l_1c3a:
	/* 0x1c3a: mov    WORD PTR [r14+0x7d8a],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 32138ULL);
x86_l_1c42:
	/* 0x1c42: inc    BYTE PTR [r14+0x88] */
	X86_SIM_L_EXEC_ALU_MEM_UNARY(X86_R14, X86_WIDTH_8, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_8) | X86_MEM_AUX_ALU_OP(X86_ALU_INC)), 136ULL);
x86_l_1c49:
	/* 0x1c49: mov    rsi,QWORD PTR [rip+0x0] */
	X86_SIM_L_EXEC_PTR_LOAD(X86_OP_MOV_LOAD_MAP_PTR, X86_RSI, 0, ((__u64)(long)prog_array));
x86_l_1c50:
	/* 0x1c50: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_1c55:
	/* 0x1c55: mov    ecx,0xc */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 12ULL);
x86_l_1c5a:
	/* 0x1c5a: mov    rdi,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_64);
x86_l_1c5d:
	/* 0x1c5d: mov    edx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RDX, X86_WIDTH_32, 8ULL);
x86_l_1c62:
	/* 0x1c62: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0xcULL: X86_SIM_BPF_CALL_bpf_tail_call(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0xcULL: X86_SIM_BPF_CALL_bpf_tail_call(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1c64:
	/* 0x1c64: mov    rax,QWORD PTR [rsp+0x78] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_1c69:
	/* 0x1c69: add    rsp,0xa8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSP, X86_WIDTH_64, X86_ALU_ADD, 168ULL);
x86_l_1c70:
	/* 0x1c70: pop    rbx */
	X86_SIM_L_EXEC_POP_OP(X86_RBX, X86_WIDTH_64, 0, 0);
x86_l_1c71:
	/* 0x1c71: pop    r12 */
	X86_SIM_L_EXEC_POP_OP(X86_R12, X86_WIDTH_64, 0, 0);
x86_l_1c73:
	/* 0x1c73: pop    r13 */
	X86_SIM_L_EXEC_POP_OP(X86_R13, X86_WIDTH_64, 0, 0);
x86_l_1c75:
	/* 0x1c75: pop    r14 */
	X86_SIM_L_EXEC_POP_OP(X86_R14, X86_WIDTH_64, 0, 0);
x86_l_1c77:
	/* 0x1c77: pop    r15 */
	X86_SIM_L_EXEC_POP_OP(X86_R15, X86_WIDTH_64, 0, 0);
x86_l_1c79:
	/* 0x1c79: pop    rbp */
	X86_SIM_L_EXEC_POP_OP(X86_RBP, X86_WIDTH_64, 0, 0);
x86_l_1c7a:
	/* 0x1c7a: jmp    34b6 <trace_security_bprm_creds_for_exec+0x34b6> ; native-link entry RET */
	X86_SIM_X86_RET();
x86_l_1c7f:
	/* 0x1c7f: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_1c82:
	/* 0x1c82: jne    1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1c82, 0x1648, x86_l_1648);
x86_l_1c88:
	/* 0x1c88: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1c8c:
	/* 0x1c8c: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_1c91:
	/* 0x1c91: je     1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1c91, 0x1648, x86_l_1648);
x86_l_1c97:
	/* 0x1c97: add    rax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1c9b:
	/* 0x1c9b: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ca0:
	/* 0x1ca0: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_1ca5:
	/* 0x1ca5: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_1cab:
	/* 0x1cab: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1caf:
	/* 0x1caf: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1cb3:
	/* 0x1cb3: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1cb8:
	/* 0x1cb8: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1cbb:
	/* 0x1cbb: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1cbf:
	/* 0x1cbf: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_1cc2:
	/* 0x1cc2: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_1cc7:
	/* 0x1cc7: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_1ccd:
	/* 0x1ccd: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1cd1:
	/* 0x1cd1: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1cd6:
	/* 0x1cd6: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1cd9:
	/* 0x1cd9: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1cdd:
	/* 0x1cdd: lea    rdi,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1ce2:
	/* 0x1ce2: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_1ce7:
	/* 0x1ce7: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_1ced:
	/* 0x1ced: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1cf1:
	/* 0x1cf1: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1cf6:
	/* 0x1cf6: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1cf9:
	/* 0x1cf9: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1cfd:
	/* 0x1cfd: add    rdx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1d01:
	/* 0x1d01: jmp    1d44 <trace_security_bprm_creds_for_exec+0x1d44> */
	X86_SIM_X86_JMP(0x1d01, 0x1d44, x86_l_1d44);
x86_l_1d03:
	/* 0x1d03: mov    rdx,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1d08:
	/* 0x1d08: and    edi,0x3fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1d0e:
	/* 0x1d0e: add    rdi,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD);
x86_l_1d11:
	/* 0x1d11: mov    eax,esi */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RSI, X86_WIDTH_32);
x86_l_1d13:
	/* 0x1d13: mov    ecx,0x73 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 115ULL);
x86_l_1d18:
	/* 0x1d18: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1d1a:
	/* 0x1d1a: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_1d1d:
	/* 0x1d1d: jl     164d <trace_security_bprm_creds_for_exec+0x164d> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1d1d, 0x164d, x86_l_164d);
x86_l_1d23:
	/* 0x1d23: lea    ecx,[r15-0x1] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1d27:
	/* 0x1d27: and    ecx,0x7fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1d2d:
	/* 0x1d2d: mov    BYTE PTR [rbp+rcx*1+0x0],0x2f */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 47ULL);
x86_l_1d32:
	/* 0x1d32: sub    r15d,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_RAX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_1d35:
	/* 0x1d35: mov    QWORD PTR [rsp+0x8],r15 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1d3a:
	/* 0x1d3a: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1d3f:
	/* 0x1d3f: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1d44:
	/* 0x1d44: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1d49:
	/* 0x1d49: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_1d4e:
	/* 0x1d4e: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_1d53:
	/* 0x1d53: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1d58:
	/* 0x1d58: mov    QWORD PTR [rsp+0x20],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1d5d:
	/* 0x1d5d: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1d5f:
	/* 0x1d5f: mov    r15,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1d64:
	/* 0x1d64: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1d69:
	/* 0x1d69: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1d6d:
	/* 0x1d6d: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1d72:
	/* 0x1d72: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_1d77:
	/* 0x1d77: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_1d7c:
	/* 0x1d7c: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1d81:
	/* 0x1d81: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1d83:
	/* 0x1d83: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1d88:
	/* 0x1d88: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_1d8b:
	/* 0x1d8b: je     1e1b <trace_security_bprm_creds_for_exec+0x1e1b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d8b, 0x1e1b, x86_l_1e1b);
x86_l_1d91:
	/* 0x1d91: mov    rbx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1d96:
	/* 0x1d96: cmp    rdx,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_64);
x86_l_1d99:
	/* 0x1d99: je     1e1b <trace_security_bprm_creds_for_exec+0x1e1b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1d99, 0x1e1b, x86_l_1e1b);
x86_l_1d9f:
	/* 0x1d9f: add    rdx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1da3:
	/* 0x1da3: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1da8:
	/* 0x1da8: mov    eax,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 16ULL);
x86_l_1dad:
	/* 0x1dad: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_1db2:
	/* 0x1db2: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_1db7:
	/* 0x1db7: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1db9:
	/* 0x1db9: mov    esi,DWORD PTR [rsp+0x34] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_1dbd:
	/* 0x1dbd: inc    esi */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1dbf:
	/* 0x1dbf: and    esi,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1dc5:
	/* 0x1dc5: mov    r15,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1dca:
	/* 0x1dca: mov    edi,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_32);
x86_l_1dcd:
	/* 0x1dcd: sub    edi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RSI, X86_WIDTH_32, X86_ALU_SUB);
x86_l_1dcf:
	/* 0x1dcf: jb     17aa <trace_security_bprm_creds_for_exec+0x17aa> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1dcf, 0x17aa, x86_l_17aa);
x86_l_1dd5:
	/* 0x1dd5: mov    rdx,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1dda:
	/* 0x1dda: and    edi,0x3fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1de0:
	/* 0x1de0: add    rdi,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD);
x86_l_1de3:
	/* 0x1de3: mov    eax,esi */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RSI, X86_WIDTH_32);
x86_l_1de5:
	/* 0x1de5: mov    ecx,0x73 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 115ULL);
x86_l_1dea:
	/* 0x1dea: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1dec:
	/* 0x1dec: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_1def:
	/* 0x1def: jl     164d <trace_security_bprm_creds_for_exec+0x164d> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1def, 0x164d, x86_l_164d);
x86_l_1df5:
	/* 0x1df5: lea    ecx,[r15-0x1] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1df9:
	/* 0x1df9: and    ecx,0x7fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1dff:
	/* 0x1dff: mov    BYTE PTR [rbp+rcx*1+0x0],0x2f */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 47ULL);
x86_l_1e04:
	/* 0x1e04: sub    r15d,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_RAX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_1e07:
	/* 0x1e07: mov    QWORD PTR [rsp+0x8],r15 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1e0c:
	/* 0x1e0c: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1e11:
	/* 0x1e11: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1e16:
	/* 0x1e16: jmp    1e9d <trace_security_bprm_creds_for_exec+0x1e9d> */
	X86_SIM_X86_JMP(0x1e16, 0x1e9d, x86_l_1e9d);
x86_l_1e1b:
	/* 0x1e1b: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_1e1e:
	/* 0x1e1e: jne    1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1e1e, 0x1648, x86_l_1648);
x86_l_1e24:
	/* 0x1e24: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e28:
	/* 0x1e28: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_1e2d:
	/* 0x1e2d: je     1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1e2d, 0x1648, x86_l_1648);
x86_l_1e33:
	/* 0x1e33: add    rax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1e37:
	/* 0x1e37: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1e3c:
	/* 0x1e3c: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_1e41:
	/* 0x1e41: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_1e47:
	/* 0x1e47: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e4b:
	/* 0x1e4b: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1e4f:
	/* 0x1e4f: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1e54:
	/* 0x1e54: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1e57:
	/* 0x1e57: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e5b:
	/* 0x1e5b: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_1e5e:
	/* 0x1e5e: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_1e63:
	/* 0x1e63: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_1e69:
	/* 0x1e69: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e6d:
	/* 0x1e6d: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1e72:
	/* 0x1e72: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1e75:
	/* 0x1e75: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e79:
	/* 0x1e79: lea    rdi,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_1e7e:
	/* 0x1e7e: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_1e83:
	/* 0x1e83: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_1e89:
	/* 0x1e89: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e8d:
	/* 0x1e8d: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1e92:
	/* 0x1e92: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1e95:
	/* 0x1e95: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1e99:
	/* 0x1e99: add    rdx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1e9d:
	/* 0x1e9d: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1ea2:
	/* 0x1ea2: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_1ea7:
	/* 0x1ea7: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_1eac:
	/* 0x1eac: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1eb1:
	/* 0x1eb1: mov    QWORD PTR [rsp+0x20],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1eb6:
	/* 0x1eb6: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1eb8:
	/* 0x1eb8: mov    r15,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1ebd:
	/* 0x1ebd: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ec2:
	/* 0x1ec2: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1ec6:
	/* 0x1ec6: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1ecb:
	/* 0x1ecb: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_1ed0:
	/* 0x1ed0: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_1ed5:
	/* 0x1ed5: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1eda:
	/* 0x1eda: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1edc:
	/* 0x1edc: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1ee1:
	/* 0x1ee1: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_1ee4:
	/* 0x1ee4: je     1fb3 <trace_security_bprm_creds_for_exec+0x1fb3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ee4, 0x1fb3, x86_l_1fb3);
x86_l_1eea:
	/* 0x1eea: mov    rbx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1eef:
	/* 0x1eef: cmp    rdx,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_64);
x86_l_1ef2:
	/* 0x1ef2: je     1fb3 <trace_security_bprm_creds_for_exec+0x1fb3> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1ef2, 0x1fb3, x86_l_1fb3);
x86_l_1ef8:
	/* 0x1ef8: add    rdx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1efc:
	/* 0x1efc: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_1f01:
	/* 0x1f01: mov    eax,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 16ULL);
x86_l_1f06:
	/* 0x1f06: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_1f0b:
	/* 0x1f0b: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_1f10:
	/* 0x1f10: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1f12:
	/* 0x1f12: mov    esi,DWORD PTR [rsp+0x34] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_1f16:
	/* 0x1f16: inc    esi */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_1f18:
	/* 0x1f18: and    esi,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_1f1e:
	/* 0x1f1e: mov    r15,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f23:
	/* 0x1f23: mov    edi,r15d */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_R15, X86_WIDTH_32);
x86_l_1f26:
	/* 0x1f26: sub    edi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RSI, X86_WIDTH_32, X86_ALU_SUB);
x86_l_1f28:
	/* 0x1f28: jb     17aa <trace_security_bprm_creds_for_exec+0x17aa> */
	X86_SIM_X86_JCC(X86_CC_B, 0x1f28, 0x17aa, x86_l_17aa);
x86_l_1f2e:
	/* 0x1f2e: mov    rdx,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_1f33:
	/* 0x1f33: and    edi,0x3fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_1f39:
	/* 0x1f39: add    rdi,rbp */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RBP, X86_WIDTH_64, X86_ALU_ADD);
x86_l_1f3c:
	/* 0x1f3c: mov    eax,esi */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RSI, X86_WIDTH_32);
x86_l_1f3e:
	/* 0x1f3e: mov    ecx,0x73 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 115ULL);
x86_l_1f43:
	/* 0x1f43: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1f45:
	/* 0x1f45: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_1f48:
	/* 0x1f48: jl     164d <trace_security_bprm_creds_for_exec+0x164d> */
	X86_SIM_X86_JCC(X86_CC_L, 0x1f48, 0x164d, x86_l_164d);
x86_l_1f4e:
	/* 0x1f4e: lea    ecx,[r15-0x1] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_1f52:
	/* 0x1f52: and    ecx,0x7fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_1f58:
	/* 0x1f58: mov    BYTE PTR [rbp+rcx*1+0x0],0x2f */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RBP, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 47ULL);
x86_l_1f5d:
	/* 0x1f5d: sub    r15d,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_RAX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_1f60:
	/* 0x1f60: mov    QWORD PTR [rsp+0x8],r15 */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_R15, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_1f65:
	/* 0x1f65: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1f6a:
	/* 0x1f6a: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_1f6f:
	/* 0x1f6f: jmp    2035 <trace_security_bprm_creds_for_exec+0x2035> */
	X86_SIM_X86_JMP(0x1f6f, 0x2035, x86_l_2035);
x86_l_1f74:
	/* 0x1f74: lea    rdi,[r14+0x7e18] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_R14, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32280ULL);
x86_l_1f7b:
	/* 0x1f7b: mov    rdx,r15 */
	X86_SIM_L_EXEC_MOV_REG(X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_1f7e:
	/* 0x1f7e: add    rdx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_1f82:
	/* 0x1f82: mov    eax,0x100 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 256ULL);
x86_l_1f87:
	/* 0x1f87: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_1f8c:
	/* 0x1f8c: mov    esi,0x100 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 256ULL);
x86_l_1f91:
	/* 0x1f91: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1f93:
	/* 0x1f93: test   rax,rax */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_TEST_REG, X86_RAX, X86_RAX, X86_WIDTH_64);
x86_l_1f96:
	/* 0x1f96: jne    1fa7 <trace_security_bprm_creds_for_exec+0x1fa7> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1f96, 0x1fa7, x86_l_1fa7);
x86_l_1f98:
	/* 0x1f98: movzx  eax,WORD PTR [r15+0xe] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_R15, X86_WIDTH_32, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_16), 14ULL);
x86_l_1f9d:
	/* 0x1f9d: mov    WORD PTR [r14+0x7e],ax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_R14, X86_RAX, X86_WIDTH_16, X86_MEM_AUX(X86_REG_NONE, 0), 126ULL);
x86_l_1fa2:
	/* 0x1fa2: jmp    959 <trace_security_bprm_creds_for_exec+0x959> */
	X86_SIM_X86_JMP(0x1fa2, 0x959, x86_l_959);
x86_l_1fa7:
	/* 0x1fa7: xor    eax,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RAX, X86_RAX, X86_WIDTH_32, X86_ALU_XOR);
x86_l_1fa9:
	/* 0x1fa9: mov    QWORD PTR [rsp+0x78],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 120ULL);
x86_l_1fae:
	/* 0x1fae: jmp    1c64 <trace_security_bprm_creds_for_exec+0x1c64> */
	X86_SIM_X86_JMP(0x1fae, 0x1c64, x86_l_1c64);
x86_l_1fb3:
	/* 0x1fb3: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_1fb6:
	/* 0x1fb6: jne    1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x1fb6, 0x1648, x86_l_1648);
x86_l_1fbc:
	/* 0x1fbc: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fc0:
	/* 0x1fc0: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_1fc5:
	/* 0x1fc5: je     1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_E, 0x1fc5, 0x1648, x86_l_1648);
x86_l_1fcb:
	/* 0x1fcb: add    rax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1fcf:
	/* 0x1fcf: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_1fd4:
	/* 0x1fd4: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_1fd9:
	/* 0x1fd9: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_1fdf:
	/* 0x1fdf: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1fe3:
	/* 0x1fe3: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_1fe7:
	/* 0x1fe7: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_1fec:
	/* 0x1fec: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_1fef:
	/* 0x1fef: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_1ff3:
	/* 0x1ff3: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_1ff6:
	/* 0x1ff6: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_1ffb:
	/* 0x1ffb: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_2001:
	/* 0x2001: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2005:
	/* 0x2005: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_200a:
	/* 0x200a: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_200d:
	/* 0x200d: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2011:
	/* 0x2011: lea    rdi,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2016:
	/* 0x2016: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_201b:
	/* 0x201b: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_2021:
	/* 0x2021: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2025:
	/* 0x2025: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_202a:
	/* 0x202a: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_202d:
	/* 0x202d: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2031:
	/* 0x2031: add    rdx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2035:
	/* 0x2035: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_203a:
	/* 0x203a: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_203f:
	/* 0x203f: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_2044:
	/* 0x2044: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2049:
	/* 0x2049: mov    QWORD PTR [rsp+0x20],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_204e:
	/* 0x204e: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2050:
	/* 0x2050: mov    r15,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2055:
	/* 0x2055: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_205a:
	/* 0x205a: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_205e:
	/* 0x205e: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2063:
	/* 0x2063: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_2068:
	/* 0x2068: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_206d:
	/* 0x206d: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2072:
	/* 0x2072: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2074:
	/* 0x2074: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2079:
	/* 0x2079: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_207c:
	/* 0x207c: je     20c5 <trace_security_bprm_creds_for_exec+0x20c5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x207c, 0x20c5, x86_l_20c5);
x86_l_207e:
	/* 0x207e: mov    rbx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2083:
	/* 0x2083: cmp    rdx,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_64);
x86_l_2086:
	/* 0x2086: je     20c5 <trace_security_bprm_creds_for_exec+0x20c5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2086, 0x20c5, x86_l_20c5);
x86_l_2088:
	/* 0x2088: add    rdx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_208c:
	/* 0x208c: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2091:
	/* 0x2091: mov    eax,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 16ULL);
x86_l_2096:
	/* 0x2096: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_209b:
	/* 0x209b: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_20a0:
	/* 0x20a0: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_20a2:
	/* 0x20a2: mov    esi,DWORD PTR [rsp+0x34] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_20a6:
	/* 0x20a6: inc    esi */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_20a8:
	/* 0x20a8: and    esi,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_20ae:
	/* 0x20ae: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_20b3:
	/* 0x20b3: sub    edi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RSI, X86_WIDTH_32, X86_ALU_SUB);
x86_l_20b5:
	/* 0x20b5: jae    214e <trace_security_bprm_creds_for_exec+0x214e> */
	X86_SIM_X86_JCC(X86_CC_AE, 0x20b5, 0x214e, x86_l_214e);
x86_l_20bb:
	/* 0x20bb: mov    r15,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_20c0:
	/* 0x20c0: jmp    17aa <trace_security_bprm_creds_for_exec+0x17aa> */
	X86_SIM_X86_JMP(0x20c0, 0x17aa, x86_l_17aa);
x86_l_20c5:
	/* 0x20c5: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_20c8:
	/* 0x20c8: jne    1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x20c8, 0x1648, x86_l_1648);
x86_l_20ce:
	/* 0x20ce: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20d2:
	/* 0x20d2: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_20d7:
	/* 0x20d7: je     1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_E, 0x20d7, 0x1648, x86_l_1648);
x86_l_20dd:
	/* 0x20dd: add    rax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_20e1:
	/* 0x20e1: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_20e6:
	/* 0x20e6: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_20eb:
	/* 0x20eb: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_20f1:
	/* 0x20f1: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_20f5:
	/* 0x20f5: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_20f9:
	/* 0x20f9: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_20fe:
	/* 0x20fe: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2101:
	/* 0x2101: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2105:
	/* 0x2105: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2108:
	/* 0x2108: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_210d:
	/* 0x210d: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_2113:
	/* 0x2113: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2117:
	/* 0x2117: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_211c:
	/* 0x211c: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_211f:
	/* 0x211f: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2123:
	/* 0x2123: lea    rdi,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2128:
	/* 0x2128: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_212d:
	/* 0x212d: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_2133:
	/* 0x2133: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2137:
	/* 0x2137: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_213c:
	/* 0x213c: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_213f:
	/* 0x213f: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2143:
	/* 0x2143: add    rax,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2147:
	/* 0x2147: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_214c:
	/* 0x214c: jmp    2193 <trace_security_bprm_creds_for_exec+0x2193> */
	X86_SIM_X86_JMP(0x214c, 0x2193, x86_l_2193);
x86_l_214e:
	/* 0x214e: mov    rdx,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2153:
	/* 0x2153: and    edi,0x3fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2159:
	/* 0x2159: add    rdi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 40ULL);
x86_l_215e:
	/* 0x215e: mov    eax,esi */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RSI, X86_WIDTH_32);
x86_l_2160:
	/* 0x2160: mov    ecx,0x73 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 115ULL);
x86_l_2165:
	/* 0x2165: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2167:
	/* 0x2167: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_216a:
	/* 0x216a: jl     1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_L, 0x216a, 0x1648, x86_l_1648);
x86_l_2170:
	/* 0x2170: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2175:
	/* 0x2175: lea    ecx,[rdx-0x1] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2178:
	/* 0x2178: and    ecx,0x7fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_217e:
	/* 0x217e: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2183:
	/* 0x2183: mov    BYTE PTR [rsi+rcx*1],0x2f */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 47ULL);
x86_l_2187:
	/* 0x2187: sub    edx,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_2189:
	/* 0x2189: mov    QWORD PTR [rsp+0x8],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_218e:
	/* 0x218e: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2193:
	/* 0x2193: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2198:
	/* 0x2198: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_219d:
	/* 0x219d: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_21a2:
	/* 0x21a2: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_21a7:
	/* 0x21a7: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_21ac:
	/* 0x21ac: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_21ae:
	/* 0x21ae: mov    r15,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_21b3:
	/* 0x21b3: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_21b8:
	/* 0x21b8: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_21bc:
	/* 0x21bc: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_21c1:
	/* 0x21c1: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_21c6:
	/* 0x21c6: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_21cb:
	/* 0x21cb: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_21d0:
	/* 0x21d0: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_21d2:
	/* 0x21d2: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_21d7:
	/* 0x21d7: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_21da:
	/* 0x21da: je     226b <trace_security_bprm_creds_for_exec+0x226b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21da, 0x226b, x86_l_226b);
x86_l_21e0:
	/* 0x21e0: mov    rbx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_21e5:
	/* 0x21e5: cmp    rdx,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_64);
x86_l_21e8:
	/* 0x21e8: je     226b <trace_security_bprm_creds_for_exec+0x226b> */
	X86_SIM_X86_JCC(X86_CC_E, 0x21e8, 0x226b, x86_l_226b);
x86_l_21ee:
	/* 0x21ee: add    rdx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_21f2:
	/* 0x21f2: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_21f7:
	/* 0x21f7: mov    eax,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 16ULL);
x86_l_21fc:
	/* 0x21fc: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_2201:
	/* 0x2201: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_2206:
	/* 0x2206: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2208:
	/* 0x2208: mov    esi,DWORD PTR [rsp+0x34] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_220c:
	/* 0x220c: inc    esi */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_220e:
	/* 0x220e: and    esi,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2214:
	/* 0x2214: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2219:
	/* 0x2219: sub    edi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RSI, X86_WIDTH_32, X86_ALU_SUB);
x86_l_221b:
	/* 0x221b: jb     20bb <trace_security_bprm_creds_for_exec+0x20bb> */
	X86_SIM_X86_JCC(X86_CC_B, 0x221b, 0x20bb, x86_l_20bb);
x86_l_2221:
	/* 0x2221: mov    rdx,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2226:
	/* 0x2226: and    edi,0x3fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_222c:
	/* 0x222c: add    rdi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 40ULL);
x86_l_2231:
	/* 0x2231: mov    eax,esi */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RSI, X86_WIDTH_32);
x86_l_2233:
	/* 0x2233: mov    ecx,0x73 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 115ULL);
x86_l_2238:
	/* 0x2238: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_223a:
	/* 0x223a: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_223d:
	/* 0x223d: jl     1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_L, 0x223d, 0x1648, x86_l_1648);
x86_l_2243:
	/* 0x2243: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2248:
	/* 0x2248: lea    ecx,[rdx-0x1] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_224b:
	/* 0x224b: and    ecx,0x7fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2251:
	/* 0x2251: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2256:
	/* 0x2256: mov    BYTE PTR [rsi+rcx*1],0x2f */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 47ULL);
x86_l_225a:
	/* 0x225a: sub    edx,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_225c:
	/* 0x225c: mov    QWORD PTR [rsp+0x8],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2261:
	/* 0x2261: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2266:
	/* 0x2266: jmp    22f2 <trace_security_bprm_creds_for_exec+0x22f2> */
	X86_SIM_X86_JMP(0x2266, 0x22f2, x86_l_22f2);
x86_l_226b:
	/* 0x226b: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_226e:
	/* 0x226e: jne    1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x226e, 0x1648, x86_l_1648);
x86_l_2274:
	/* 0x2274: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2278:
	/* 0x2278: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_227d:
	/* 0x227d: je     1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_E, 0x227d, 0x1648, x86_l_1648);
x86_l_2283:
	/* 0x2283: add    rax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2287:
	/* 0x2287: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_228c:
	/* 0x228c: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_2291:
	/* 0x2291: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_2297:
	/* 0x2297: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_229b:
	/* 0x229b: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_229f:
	/* 0x229f: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_22a4:
	/* 0x22a4: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_22a7:
	/* 0x22a7: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22ab:
	/* 0x22ab: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_22ae:
	/* 0x22ae: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_22b3:
	/* 0x22b3: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_22b9:
	/* 0x22b9: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22bd:
	/* 0x22bd: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_22c2:
	/* 0x22c2: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_22c5:
	/* 0x22c5: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22c9:
	/* 0x22c9: lea    rdi,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_22ce:
	/* 0x22ce: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_22d3:
	/* 0x22d3: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_22d9:
	/* 0x22d9: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22dd:
	/* 0x22dd: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_22e2:
	/* 0x22e2: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_22e5:
	/* 0x22e5: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_22e9:
	/* 0x22e9: add    rax,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_22ed:
	/* 0x22ed: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_22f2:
	/* 0x22f2: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_22f7:
	/* 0x22f7: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_22fc:
	/* 0x22fc: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_2301:
	/* 0x2301: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2306:
	/* 0x2306: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_230b:
	/* 0x230b: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_230d:
	/* 0x230d: mov    r15,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2312:
	/* 0x2312: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2317:
	/* 0x2317: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_231b:
	/* 0x231b: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2320:
	/* 0x2320: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_2325:
	/* 0x2325: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_232a:
	/* 0x232a: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_232f:
	/* 0x232f: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2331:
	/* 0x2331: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2336:
	/* 0x2336: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_2339:
	/* 0x2339: je     23ca <trace_security_bprm_creds_for_exec+0x23ca> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2339, 0x23ca, x86_l_23ca);
x86_l_233f:
	/* 0x233f: mov    rbx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2344:
	/* 0x2344: cmp    rdx,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_64);
x86_l_2347:
	/* 0x2347: je     23ca <trace_security_bprm_creds_for_exec+0x23ca> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2347, 0x23ca, x86_l_23ca);
x86_l_234d:
	/* 0x234d: add    rdx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2351:
	/* 0x2351: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2356:
	/* 0x2356: mov    eax,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 16ULL);
x86_l_235b:
	/* 0x235b: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_2360:
	/* 0x2360: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_2365:
	/* 0x2365: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2367:
	/* 0x2367: mov    esi,DWORD PTR [rsp+0x34] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_236b:
	/* 0x236b: inc    esi */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_236d:
	/* 0x236d: and    esi,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2373:
	/* 0x2373: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2378:
	/* 0x2378: sub    edi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RSI, X86_WIDTH_32, X86_ALU_SUB);
x86_l_237a:
	/* 0x237a: jb     20bb <trace_security_bprm_creds_for_exec+0x20bb> */
	X86_SIM_X86_JCC(X86_CC_B, 0x237a, 0x20bb, x86_l_20bb);
x86_l_2380:
	/* 0x2380: mov    rdx,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2385:
	/* 0x2385: and    edi,0x3fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_238b:
	/* 0x238b: add    rdi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 40ULL);
x86_l_2390:
	/* 0x2390: mov    eax,esi */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RSI, X86_WIDTH_32);
x86_l_2392:
	/* 0x2392: mov    ecx,0x73 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 115ULL);
x86_l_2397:
	/* 0x2397: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2399:
	/* 0x2399: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_239c:
	/* 0x239c: jl     1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_L, 0x239c, 0x1648, x86_l_1648);
x86_l_23a2:
	/* 0x23a2: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_23a7:
	/* 0x23a7: lea    ecx,[rdx-0x1] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_23aa:
	/* 0x23aa: and    ecx,0x7fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_23b0:
	/* 0x23b0: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_23b5:
	/* 0x23b5: mov    BYTE PTR [rsi+rcx*1],0x2f */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 47ULL);
x86_l_23b9:
	/* 0x23b9: sub    edx,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_23bb:
	/* 0x23bb: mov    QWORD PTR [rsp+0x8],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_23c0:
	/* 0x23c0: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_23c5:
	/* 0x23c5: jmp    2451 <trace_security_bprm_creds_for_exec+0x2451> */
	X86_SIM_X86_JMP(0x23c5, 0x2451, x86_l_2451);
x86_l_23ca:
	/* 0x23ca: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_23cd:
	/* 0x23cd: jne    1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x23cd, 0x1648, x86_l_1648);
x86_l_23d3:
	/* 0x23d3: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23d7:
	/* 0x23d7: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_23dc:
	/* 0x23dc: je     1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_E, 0x23dc, 0x1648, x86_l_1648);
x86_l_23e2:
	/* 0x23e2: add    rax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_23e6:
	/* 0x23e6: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_23eb:
	/* 0x23eb: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_23f0:
	/* 0x23f0: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_23f6:
	/* 0x23f6: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_23fa:
	/* 0x23fa: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_23fe:
	/* 0x23fe: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2403:
	/* 0x2403: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2406:
	/* 0x2406: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_240a:
	/* 0x240a: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_240d:
	/* 0x240d: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_2412:
	/* 0x2412: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_2418:
	/* 0x2418: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_241c:
	/* 0x241c: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2421:
	/* 0x2421: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2424:
	/* 0x2424: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2428:
	/* 0x2428: lea    rdi,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_242d:
	/* 0x242d: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_2432:
	/* 0x2432: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_2438:
	/* 0x2438: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_243c:
	/* 0x243c: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2441:
	/* 0x2441: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2444:
	/* 0x2444: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2448:
	/* 0x2448: add    rax,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_244c:
	/* 0x244c: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2451:
	/* 0x2451: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2456:
	/* 0x2456: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_245b:
	/* 0x245b: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_2460:
	/* 0x2460: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2465:
	/* 0x2465: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_246a:
	/* 0x246a: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_246c:
	/* 0x246c: mov    r15,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2471:
	/* 0x2471: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2476:
	/* 0x2476: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_247a:
	/* 0x247a: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_247f:
	/* 0x247f: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_2484:
	/* 0x2484: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_2489:
	/* 0x2489: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_248e:
	/* 0x248e: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2490:
	/* 0x2490: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2495:
	/* 0x2495: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_2498:
	/* 0x2498: je     2529 <trace_security_bprm_creds_for_exec+0x2529> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2498, 0x2529, x86_l_2529);
x86_l_249e:
	/* 0x249e: mov    rbx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_24a3:
	/* 0x24a3: cmp    rdx,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_64);
x86_l_24a6:
	/* 0x24a6: je     2529 <trace_security_bprm_creds_for_exec+0x2529> */
	X86_SIM_X86_JCC(X86_CC_E, 0x24a6, 0x2529, x86_l_2529);
x86_l_24ac:
	/* 0x24ac: add    rdx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_24b0:
	/* 0x24b0: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_24b5:
	/* 0x24b5: mov    eax,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 16ULL);
x86_l_24ba:
	/* 0x24ba: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_24bf:
	/* 0x24bf: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_24c4:
	/* 0x24c4: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_24c6:
	/* 0x24c6: mov    esi,DWORD PTR [rsp+0x34] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_24ca:
	/* 0x24ca: inc    esi */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_24cc:
	/* 0x24cc: and    esi,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_24d2:
	/* 0x24d2: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_24d7:
	/* 0x24d7: sub    edi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RSI, X86_WIDTH_32, X86_ALU_SUB);
x86_l_24d9:
	/* 0x24d9: jb     20bb <trace_security_bprm_creds_for_exec+0x20bb> */
	X86_SIM_X86_JCC(X86_CC_B, 0x24d9, 0x20bb, x86_l_20bb);
x86_l_24df:
	/* 0x24df: mov    rdx,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_24e4:
	/* 0x24e4: and    edi,0x3fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_24ea:
	/* 0x24ea: add    rdi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 40ULL);
x86_l_24ef:
	/* 0x24ef: mov    eax,esi */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RSI, X86_WIDTH_32);
x86_l_24f1:
	/* 0x24f1: mov    ecx,0x73 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 115ULL);
x86_l_24f6:
	/* 0x24f6: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_24f8:
	/* 0x24f8: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_24fb:
	/* 0x24fb: jl     1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_L, 0x24fb, 0x1648, x86_l_1648);
x86_l_2501:
	/* 0x2501: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2506:
	/* 0x2506: lea    ecx,[rdx-0x1] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2509:
	/* 0x2509: and    ecx,0x7fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_250f:
	/* 0x250f: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2514:
	/* 0x2514: mov    BYTE PTR [rsi+rcx*1],0x2f */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 47ULL);
x86_l_2518:
	/* 0x2518: sub    edx,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_251a:
	/* 0x251a: mov    QWORD PTR [rsp+0x8],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_251f:
	/* 0x251f: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2524:
	/* 0x2524: jmp    25b0 <trace_security_bprm_creds_for_exec+0x25b0> */
	X86_SIM_X86_JMP(0x2524, 0x25b0, x86_l_25b0);
x86_l_2529:
	/* 0x2529: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_252c:
	/* 0x252c: jne    1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x252c, 0x1648, x86_l_1648);
x86_l_2532:
	/* 0x2532: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2536:
	/* 0x2536: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_253b:
	/* 0x253b: je     1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_E, 0x253b, 0x1648, x86_l_1648);
x86_l_2541:
	/* 0x2541: add    rax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2545:
	/* 0x2545: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_254a:
	/* 0x254a: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_254f:
	/* 0x254f: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_2555:
	/* 0x2555: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2559:
	/* 0x2559: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_255d:
	/* 0x255d: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2562:
	/* 0x2562: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2565:
	/* 0x2565: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2569:
	/* 0x2569: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_256c:
	/* 0x256c: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_2571:
	/* 0x2571: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_2577:
	/* 0x2577: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_257b:
	/* 0x257b: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2580:
	/* 0x2580: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2583:
	/* 0x2583: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2587:
	/* 0x2587: lea    rdi,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_258c:
	/* 0x258c: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_2591:
	/* 0x2591: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_2597:
	/* 0x2597: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_259b:
	/* 0x259b: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_25a0:
	/* 0x25a0: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_25a3:
	/* 0x25a3: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_25a7:
	/* 0x25a7: add    rax,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_25ab:
	/* 0x25ab: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_25b0:
	/* 0x25b0: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_25b5:
	/* 0x25b5: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_25ba:
	/* 0x25ba: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_25bf:
	/* 0x25bf: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_25c4:
	/* 0x25c4: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_25c9:
	/* 0x25c9: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_25cb:
	/* 0x25cb: mov    r15,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_25d0:
	/* 0x25d0: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_25d5:
	/* 0x25d5: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_25d9:
	/* 0x25d9: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_25de:
	/* 0x25de: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_25e3:
	/* 0x25e3: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_25e8:
	/* 0x25e8: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_25ed:
	/* 0x25ed: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_25ef:
	/* 0x25ef: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_25f4:
	/* 0x25f4: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_25f7:
	/* 0x25f7: je     2688 <trace_security_bprm_creds_for_exec+0x2688> */
	X86_SIM_X86_JCC(X86_CC_E, 0x25f7, 0x2688, x86_l_2688);
x86_l_25fd:
	/* 0x25fd: mov    rbx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2602:
	/* 0x2602: cmp    rdx,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_64);
x86_l_2605:
	/* 0x2605: je     2688 <trace_security_bprm_creds_for_exec+0x2688> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2605, 0x2688, x86_l_2688);
x86_l_260b:
	/* 0x260b: add    rdx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_260f:
	/* 0x260f: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2614:
	/* 0x2614: mov    eax,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 16ULL);
x86_l_2619:
	/* 0x2619: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_261e:
	/* 0x261e: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_2623:
	/* 0x2623: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2625:
	/* 0x2625: mov    esi,DWORD PTR [rsp+0x34] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_2629:
	/* 0x2629: inc    esi */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_262b:
	/* 0x262b: and    esi,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2631:
	/* 0x2631: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2636:
	/* 0x2636: sub    edi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RSI, X86_WIDTH_32, X86_ALU_SUB);
x86_l_2638:
	/* 0x2638: jb     20bb <trace_security_bprm_creds_for_exec+0x20bb> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2638, 0x20bb, x86_l_20bb);
x86_l_263e:
	/* 0x263e: mov    rdx,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2643:
	/* 0x2643: and    edi,0x3fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2649:
	/* 0x2649: add    rdi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 40ULL);
x86_l_264e:
	/* 0x264e: mov    eax,esi */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RSI, X86_WIDTH_32);
x86_l_2650:
	/* 0x2650: mov    ecx,0x73 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 115ULL);
x86_l_2655:
	/* 0x2655: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2657:
	/* 0x2657: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_265a:
	/* 0x265a: jl     1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_L, 0x265a, 0x1648, x86_l_1648);
x86_l_2660:
	/* 0x2660: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2665:
	/* 0x2665: lea    ecx,[rdx-0x1] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2668:
	/* 0x2668: and    ecx,0x7fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_266e:
	/* 0x266e: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2673:
	/* 0x2673: mov    BYTE PTR [rsi+rcx*1],0x2f */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 47ULL);
x86_l_2677:
	/* 0x2677: sub    edx,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_2679:
	/* 0x2679: mov    QWORD PTR [rsp+0x8],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_267e:
	/* 0x267e: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2683:
	/* 0x2683: jmp    270f <trace_security_bprm_creds_for_exec+0x270f> */
	X86_SIM_X86_JMP(0x2683, 0x270f, x86_l_270f);
x86_l_2688:
	/* 0x2688: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_268b:
	/* 0x268b: jne    1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x268b, 0x1648, x86_l_1648);
x86_l_2691:
	/* 0x2691: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2695:
	/* 0x2695: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_269a:
	/* 0x269a: je     1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_E, 0x269a, 0x1648, x86_l_1648);
x86_l_26a0:
	/* 0x26a0: add    rax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_26a4:
	/* 0x26a4: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_26a9:
	/* 0x26a9: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_26ae:
	/* 0x26ae: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_26b4:
	/* 0x26b4: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26b8:
	/* 0x26b8: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_26bc:
	/* 0x26bc: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_26c1:
	/* 0x26c1: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_26c4:
	/* 0x26c4: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26c8:
	/* 0x26c8: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_26cb:
	/* 0x26cb: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_26d0:
	/* 0x26d0: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_26d6:
	/* 0x26d6: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26da:
	/* 0x26da: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_26df:
	/* 0x26df: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_26e2:
	/* 0x26e2: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26e6:
	/* 0x26e6: lea    rdi,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_26eb:
	/* 0x26eb: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_26f0:
	/* 0x26f0: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_26f6:
	/* 0x26f6: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_26fa:
	/* 0x26fa: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_26ff:
	/* 0x26ff: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2702:
	/* 0x2702: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2706:
	/* 0x2706: add    rax,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_270a:
	/* 0x270a: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_270f:
	/* 0x270f: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2714:
	/* 0x2714: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_2719:
	/* 0x2719: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_271e:
	/* 0x271e: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2723:
	/* 0x2723: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2728:
	/* 0x2728: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_272a:
	/* 0x272a: mov    r15,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_272f:
	/* 0x272f: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2734:
	/* 0x2734: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2738:
	/* 0x2738: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_273d:
	/* 0x273d: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_2742:
	/* 0x2742: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_2747:
	/* 0x2747: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_274c:
	/* 0x274c: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_274e:
	/* 0x274e: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2753:
	/* 0x2753: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_2756:
	/* 0x2756: je     27e7 <trace_security_bprm_creds_for_exec+0x27e7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2756, 0x27e7, x86_l_27e7);
x86_l_275c:
	/* 0x275c: mov    rbx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2761:
	/* 0x2761: cmp    rdx,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_64);
x86_l_2764:
	/* 0x2764: je     27e7 <trace_security_bprm_creds_for_exec+0x27e7> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2764, 0x27e7, x86_l_27e7);
x86_l_276a:
	/* 0x276a: add    rdx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_276e:
	/* 0x276e: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2773:
	/* 0x2773: mov    eax,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 16ULL);
x86_l_2778:
	/* 0x2778: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_277d:
	/* 0x277d: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_2782:
	/* 0x2782: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2784:
	/* 0x2784: mov    esi,DWORD PTR [rsp+0x34] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_2788:
	/* 0x2788: inc    esi */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_278a:
	/* 0x278a: and    esi,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2790:
	/* 0x2790: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2795:
	/* 0x2795: sub    edi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RSI, X86_WIDTH_32, X86_ALU_SUB);
x86_l_2797:
	/* 0x2797: jb     20bb <trace_security_bprm_creds_for_exec+0x20bb> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2797, 0x20bb, x86_l_20bb);
x86_l_279d:
	/* 0x279d: mov    rdx,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_27a2:
	/* 0x27a2: and    edi,0x3fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_27a8:
	/* 0x27a8: add    rdi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 40ULL);
x86_l_27ad:
	/* 0x27ad: mov    eax,esi */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RSI, X86_WIDTH_32);
x86_l_27af:
	/* 0x27af: mov    ecx,0x73 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 115ULL);
x86_l_27b4:
	/* 0x27b4: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_27b6:
	/* 0x27b6: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_27b9:
	/* 0x27b9: jl     1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_L, 0x27b9, 0x1648, x86_l_1648);
x86_l_27bf:
	/* 0x27bf: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_27c4:
	/* 0x27c4: lea    ecx,[rdx-0x1] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_27c7:
	/* 0x27c7: and    ecx,0x7fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_27cd:
	/* 0x27cd: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_27d2:
	/* 0x27d2: mov    BYTE PTR [rsi+rcx*1],0x2f */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 47ULL);
x86_l_27d6:
	/* 0x27d6: sub    edx,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_27d8:
	/* 0x27d8: mov    QWORD PTR [rsp+0x8],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_27dd:
	/* 0x27dd: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_27e2:
	/* 0x27e2: jmp    286e <trace_security_bprm_creds_for_exec+0x286e> */
	X86_SIM_X86_JMP(0x27e2, 0x286e, x86_l_286e);
x86_l_27e7:
	/* 0x27e7: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_27ea:
	/* 0x27ea: jne    1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x27ea, 0x1648, x86_l_1648);
x86_l_27f0:
	/* 0x27f0: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_27f4:
	/* 0x27f4: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_27f9:
	/* 0x27f9: je     1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_E, 0x27f9, 0x1648, x86_l_1648);
x86_l_27ff:
	/* 0x27ff: add    rax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2803:
	/* 0x2803: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2808:
	/* 0x2808: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_280d:
	/* 0x280d: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_2813:
	/* 0x2813: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2817:
	/* 0x2817: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_281b:
	/* 0x281b: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2820:
	/* 0x2820: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2823:
	/* 0x2823: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2827:
	/* 0x2827: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_282a:
	/* 0x282a: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_282f:
	/* 0x282f: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_2835:
	/* 0x2835: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2839:
	/* 0x2839: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_283e:
	/* 0x283e: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2841:
	/* 0x2841: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2845:
	/* 0x2845: lea    rdi,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_284a:
	/* 0x284a: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_284f:
	/* 0x284f: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_2855:
	/* 0x2855: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2859:
	/* 0x2859: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_285e:
	/* 0x285e: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2861:
	/* 0x2861: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2865:
	/* 0x2865: add    rax,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2869:
	/* 0x2869: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_286e:
	/* 0x286e: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2873:
	/* 0x2873: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_2878:
	/* 0x2878: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_287d:
	/* 0x287d: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2882:
	/* 0x2882: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2887:
	/* 0x2887: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2889:
	/* 0x2889: mov    r15,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_288e:
	/* 0x288e: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2893:
	/* 0x2893: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2897:
	/* 0x2897: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_289c:
	/* 0x289c: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_28a1:
	/* 0x28a1: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_28a6:
	/* 0x28a6: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_28ab:
	/* 0x28ab: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_28ad:
	/* 0x28ad: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_28b2:
	/* 0x28b2: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_28b5:
	/* 0x28b5: je     2946 <trace_security_bprm_creds_for_exec+0x2946> */
	X86_SIM_X86_JCC(X86_CC_E, 0x28b5, 0x2946, x86_l_2946);
x86_l_28bb:
	/* 0x28bb: mov    rbx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_28c0:
	/* 0x28c0: cmp    rdx,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_64);
x86_l_28c3:
	/* 0x28c3: je     2946 <trace_security_bprm_creds_for_exec+0x2946> */
	X86_SIM_X86_JCC(X86_CC_E, 0x28c3, 0x2946, x86_l_2946);
x86_l_28c9:
	/* 0x28c9: add    rdx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_28cd:
	/* 0x28cd: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_28d2:
	/* 0x28d2: mov    eax,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 16ULL);
x86_l_28d7:
	/* 0x28d7: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_28dc:
	/* 0x28dc: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_28e1:
	/* 0x28e1: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_28e3:
	/* 0x28e3: mov    esi,DWORD PTR [rsp+0x34] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_28e7:
	/* 0x28e7: inc    esi */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_28e9:
	/* 0x28e9: and    esi,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_28ef:
	/* 0x28ef: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_28f4:
	/* 0x28f4: sub    edi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RSI, X86_WIDTH_32, X86_ALU_SUB);
x86_l_28f6:
	/* 0x28f6: jb     20bb <trace_security_bprm_creds_for_exec+0x20bb> */
	X86_SIM_X86_JCC(X86_CC_B, 0x28f6, 0x20bb, x86_l_20bb);
x86_l_28fc:
	/* 0x28fc: mov    rdx,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2901:
	/* 0x2901: and    edi,0x3fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2907:
	/* 0x2907: add    rdi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 40ULL);
x86_l_290c:
	/* 0x290c: mov    eax,esi */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RSI, X86_WIDTH_32);
x86_l_290e:
	/* 0x290e: mov    ecx,0x73 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 115ULL);
x86_l_2913:
	/* 0x2913: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2915:
	/* 0x2915: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_2918:
	/* 0x2918: jl     1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2918, 0x1648, x86_l_1648);
x86_l_291e:
	/* 0x291e: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2923:
	/* 0x2923: lea    ecx,[rdx-0x1] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2926:
	/* 0x2926: and    ecx,0x7fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_292c:
	/* 0x292c: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2931:
	/* 0x2931: mov    BYTE PTR [rsi+rcx*1],0x2f */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 47ULL);
x86_l_2935:
	/* 0x2935: sub    edx,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_2937:
	/* 0x2937: mov    QWORD PTR [rsp+0x8],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_293c:
	/* 0x293c: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2941:
	/* 0x2941: jmp    29cd <trace_security_bprm_creds_for_exec+0x29cd> */
	X86_SIM_X86_JMP(0x2941, 0x29cd, x86_l_29cd);
x86_l_2946:
	/* 0x2946: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_2949:
	/* 0x2949: jne    1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2949, 0x1648, x86_l_1648);
x86_l_294f:
	/* 0x294f: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2953:
	/* 0x2953: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_2958:
	/* 0x2958: je     1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2958, 0x1648, x86_l_1648);
x86_l_295e:
	/* 0x295e: add    rax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2962:
	/* 0x2962: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2967:
	/* 0x2967: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_296c:
	/* 0x296c: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_2972:
	/* 0x2972: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2976:
	/* 0x2976: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_297a:
	/* 0x297a: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_297f:
	/* 0x297f: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2982:
	/* 0x2982: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2986:
	/* 0x2986: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2989:
	/* 0x2989: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_298e:
	/* 0x298e: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_2994:
	/* 0x2994: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2998:
	/* 0x2998: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_299d:
	/* 0x299d: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_29a0:
	/* 0x29a0: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29a4:
	/* 0x29a4: lea    rdi,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_29a9:
	/* 0x29a9: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_29ae:
	/* 0x29ae: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_29b4:
	/* 0x29b4: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29b8:
	/* 0x29b8: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_29bd:
	/* 0x29bd: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_29c0:
	/* 0x29c0: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_29c4:
	/* 0x29c4: add    rax,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_29c8:
	/* 0x29c8: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_29cd:
	/* 0x29cd: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_29d2:
	/* 0x29d2: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_29d7:
	/* 0x29d7: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_29dc:
	/* 0x29dc: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_29e1:
	/* 0x29e1: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_29e6:
	/* 0x29e6: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_29e8:
	/* 0x29e8: mov    r15,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_29ed:
	/* 0x29ed: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_29f2:
	/* 0x29f2: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_29f6:
	/* 0x29f6: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_29fb:
	/* 0x29fb: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_2a00:
	/* 0x2a00: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_2a05:
	/* 0x2a05: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2a0a:
	/* 0x2a0a: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2a0c:
	/* 0x2a0c: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2a11:
	/* 0x2a11: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_2a14:
	/* 0x2a14: je     2aa5 <trace_security_bprm_creds_for_exec+0x2aa5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a14, 0x2aa5, x86_l_2aa5);
x86_l_2a1a:
	/* 0x2a1a: mov    rbx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2a1f:
	/* 0x2a1f: cmp    rdx,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_64);
x86_l_2a22:
	/* 0x2a22: je     2aa5 <trace_security_bprm_creds_for_exec+0x2aa5> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2a22, 0x2aa5, x86_l_2aa5);
x86_l_2a28:
	/* 0x2a28: add    rdx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2a2c:
	/* 0x2a2c: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2a31:
	/* 0x2a31: mov    eax,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 16ULL);
x86_l_2a36:
	/* 0x2a36: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_2a3b:
	/* 0x2a3b: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_2a40:
	/* 0x2a40: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2a42:
	/* 0x2a42: mov    esi,DWORD PTR [rsp+0x34] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_2a46:
	/* 0x2a46: inc    esi */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2a48:
	/* 0x2a48: and    esi,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2a4e:
	/* 0x2a4e: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2a53:
	/* 0x2a53: sub    edi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RSI, X86_WIDTH_32, X86_ALU_SUB);
x86_l_2a55:
	/* 0x2a55: jb     20bb <trace_security_bprm_creds_for_exec+0x20bb> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2a55, 0x20bb, x86_l_20bb);
x86_l_2a5b:
	/* 0x2a5b: mov    rdx,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2a60:
	/* 0x2a60: and    edi,0x3fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2a66:
	/* 0x2a66: add    rdi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 40ULL);
x86_l_2a6b:
	/* 0x2a6b: mov    eax,esi */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RSI, X86_WIDTH_32);
x86_l_2a6d:
	/* 0x2a6d: mov    ecx,0x73 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 115ULL);
x86_l_2a72:
	/* 0x2a72: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2a74:
	/* 0x2a74: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_2a77:
	/* 0x2a77: jl     1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2a77, 0x1648, x86_l_1648);
x86_l_2a7d:
	/* 0x2a7d: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2a82:
	/* 0x2a82: lea    ecx,[rdx-0x1] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2a85:
	/* 0x2a85: and    ecx,0x7fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2a8b:
	/* 0x2a8b: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2a90:
	/* 0x2a90: mov    BYTE PTR [rsi+rcx*1],0x2f */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 47ULL);
x86_l_2a94:
	/* 0x2a94: sub    edx,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_2a96:
	/* 0x2a96: mov    QWORD PTR [rsp+0x8],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2a9b:
	/* 0x2a9b: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2aa0:
	/* 0x2aa0: jmp    2b2c <trace_security_bprm_creds_for_exec+0x2b2c> */
	X86_SIM_X86_JMP(0x2aa0, 0x2b2c, x86_l_2b2c);
x86_l_2aa5:
	/* 0x2aa5: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_2aa8:
	/* 0x2aa8: jne    1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2aa8, 0x1648, x86_l_1648);
x86_l_2aae:
	/* 0x2aae: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ab2:
	/* 0x2ab2: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_2ab7:
	/* 0x2ab7: je     1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ab7, 0x1648, x86_l_1648);
x86_l_2abd:
	/* 0x2abd: add    rax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2ac1:
	/* 0x2ac1: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2ac6:
	/* 0x2ac6: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_2acb:
	/* 0x2acb: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_2ad1:
	/* 0x2ad1: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ad5:
	/* 0x2ad5: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2ad9:
	/* 0x2ad9: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2ade:
	/* 0x2ade: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2ae1:
	/* 0x2ae1: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ae5:
	/* 0x2ae5: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2ae8:
	/* 0x2ae8: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_2aed:
	/* 0x2aed: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_2af3:
	/* 0x2af3: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2af7:
	/* 0x2af7: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2afc:
	/* 0x2afc: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2aff:
	/* 0x2aff: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b03:
	/* 0x2b03: lea    rdi,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2b08:
	/* 0x2b08: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_2b0d:
	/* 0x2b0d: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_2b13:
	/* 0x2b13: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b17:
	/* 0x2b17: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2b1c:
	/* 0x2b1c: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2b1f:
	/* 0x2b1f: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2b23:
	/* 0x2b23: add    rax,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2b27:
	/* 0x2b27: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2b2c:
	/* 0x2b2c: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2b31:
	/* 0x2b31: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_2b36:
	/* 0x2b36: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_2b3b:
	/* 0x2b3b: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2b40:
	/* 0x2b40: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2b45:
	/* 0x2b45: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2b47:
	/* 0x2b47: mov    r15,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2b4c:
	/* 0x2b4c: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2b51:
	/* 0x2b51: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2b55:
	/* 0x2b55: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2b5a:
	/* 0x2b5a: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_2b5f:
	/* 0x2b5f: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_2b64:
	/* 0x2b64: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2b69:
	/* 0x2b69: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2b6b:
	/* 0x2b6b: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2b70:
	/* 0x2b70: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_2b73:
	/* 0x2b73: je     2c04 <trace_security_bprm_creds_for_exec+0x2c04> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b73, 0x2c04, x86_l_2c04);
x86_l_2b79:
	/* 0x2b79: mov    rbx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2b7e:
	/* 0x2b7e: cmp    rdx,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_64);
x86_l_2b81:
	/* 0x2b81: je     2c04 <trace_security_bprm_creds_for_exec+0x2c04> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2b81, 0x2c04, x86_l_2c04);
x86_l_2b87:
	/* 0x2b87: add    rdx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2b8b:
	/* 0x2b8b: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2b90:
	/* 0x2b90: mov    eax,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 16ULL);
x86_l_2b95:
	/* 0x2b95: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_2b9a:
	/* 0x2b9a: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_2b9f:
	/* 0x2b9f: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2ba1:
	/* 0x2ba1: mov    esi,DWORD PTR [rsp+0x34] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_2ba5:
	/* 0x2ba5: inc    esi */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2ba7:
	/* 0x2ba7: and    esi,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2bad:
	/* 0x2bad: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2bb2:
	/* 0x2bb2: sub    edi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RSI, X86_WIDTH_32, X86_ALU_SUB);
x86_l_2bb4:
	/* 0x2bb4: jb     20bb <trace_security_bprm_creds_for_exec+0x20bb> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2bb4, 0x20bb, x86_l_20bb);
x86_l_2bba:
	/* 0x2bba: mov    rdx,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2bbf:
	/* 0x2bbf: and    edi,0x3fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2bc5:
	/* 0x2bc5: add    rdi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 40ULL);
x86_l_2bca:
	/* 0x2bca: mov    eax,esi */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RSI, X86_WIDTH_32);
x86_l_2bcc:
	/* 0x2bcc: mov    ecx,0x73 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 115ULL);
x86_l_2bd1:
	/* 0x2bd1: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2bd3:
	/* 0x2bd3: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_2bd6:
	/* 0x2bd6: jl     1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2bd6, 0x1648, x86_l_1648);
x86_l_2bdc:
	/* 0x2bdc: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2be1:
	/* 0x2be1: lea    ecx,[rdx-0x1] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2be4:
	/* 0x2be4: and    ecx,0x7fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2bea:
	/* 0x2bea: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2bef:
	/* 0x2bef: mov    BYTE PTR [rsi+rcx*1],0x2f */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 47ULL);
x86_l_2bf3:
	/* 0x2bf3: sub    edx,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_2bf5:
	/* 0x2bf5: mov    QWORD PTR [rsp+0x8],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2bfa:
	/* 0x2bfa: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2bff:
	/* 0x2bff: jmp    2c8b <trace_security_bprm_creds_for_exec+0x2c8b> */
	X86_SIM_X86_JMP(0x2bff, 0x2c8b, x86_l_2c8b);
x86_l_2c04:
	/* 0x2c04: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_2c07:
	/* 0x2c07: jne    1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2c07, 0x1648, x86_l_1648);
x86_l_2c0d:
	/* 0x2c0d: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c11:
	/* 0x2c11: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_2c16:
	/* 0x2c16: je     1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2c16, 0x1648, x86_l_1648);
x86_l_2c1c:
	/* 0x2c1c: add    rax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2c20:
	/* 0x2c20: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2c25:
	/* 0x2c25: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_2c2a:
	/* 0x2c2a: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_2c30:
	/* 0x2c30: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c34:
	/* 0x2c34: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2c38:
	/* 0x2c38: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2c3d:
	/* 0x2c3d: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2c40:
	/* 0x2c40: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c44:
	/* 0x2c44: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2c47:
	/* 0x2c47: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_2c4c:
	/* 0x2c4c: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_2c52:
	/* 0x2c52: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c56:
	/* 0x2c56: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2c5b:
	/* 0x2c5b: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2c5e:
	/* 0x2c5e: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c62:
	/* 0x2c62: lea    rdi,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2c67:
	/* 0x2c67: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_2c6c:
	/* 0x2c6c: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_2c72:
	/* 0x2c72: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c76:
	/* 0x2c76: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2c7b:
	/* 0x2c7b: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2c7e:
	/* 0x2c7e: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2c82:
	/* 0x2c82: add    rax,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2c86:
	/* 0x2c86: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2c8b:
	/* 0x2c8b: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2c90:
	/* 0x2c90: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_2c95:
	/* 0x2c95: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_2c9a:
	/* 0x2c9a: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2c9f:
	/* 0x2c9f: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2ca4:
	/* 0x2ca4: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2ca6:
	/* 0x2ca6: mov    r15,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2cab:
	/* 0x2cab: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2cb0:
	/* 0x2cb0: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2cb4:
	/* 0x2cb4: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2cb9:
	/* 0x2cb9: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_2cbe:
	/* 0x2cbe: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_2cc3:
	/* 0x2cc3: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2cc8:
	/* 0x2cc8: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2cca:
	/* 0x2cca: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2ccf:
	/* 0x2ccf: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_2cd2:
	/* 0x2cd2: je     2d63 <trace_security_bprm_creds_for_exec+0x2d63> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2cd2, 0x2d63, x86_l_2d63);
x86_l_2cd8:
	/* 0x2cd8: mov    rbx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2cdd:
	/* 0x2cdd: cmp    rdx,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_64);
x86_l_2ce0:
	/* 0x2ce0: je     2d63 <trace_security_bprm_creds_for_exec+0x2d63> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ce0, 0x2d63, x86_l_2d63);
x86_l_2ce6:
	/* 0x2ce6: add    rdx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2cea:
	/* 0x2cea: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2cef:
	/* 0x2cef: mov    eax,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 16ULL);
x86_l_2cf4:
	/* 0x2cf4: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_2cf9:
	/* 0x2cf9: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_2cfe:
	/* 0x2cfe: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2d00:
	/* 0x2d00: mov    esi,DWORD PTR [rsp+0x34] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_2d04:
	/* 0x2d04: inc    esi */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2d06:
	/* 0x2d06: and    esi,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2d0c:
	/* 0x2d0c: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2d11:
	/* 0x2d11: sub    edi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RSI, X86_WIDTH_32, X86_ALU_SUB);
x86_l_2d13:
	/* 0x2d13: jb     20bb <trace_security_bprm_creds_for_exec+0x20bb> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2d13, 0x20bb, x86_l_20bb);
x86_l_2d19:
	/* 0x2d19: mov    rdx,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2d1e:
	/* 0x2d1e: and    edi,0x3fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2d24:
	/* 0x2d24: add    rdi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 40ULL);
x86_l_2d29:
	/* 0x2d29: mov    eax,esi */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RSI, X86_WIDTH_32);
x86_l_2d2b:
	/* 0x2d2b: mov    ecx,0x73 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 115ULL);
x86_l_2d30:
	/* 0x2d30: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2d32:
	/* 0x2d32: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_2d35:
	/* 0x2d35: jl     1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2d35, 0x1648, x86_l_1648);
x86_l_2d3b:
	/* 0x2d3b: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2d40:
	/* 0x2d40: lea    ecx,[rdx-0x1] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2d43:
	/* 0x2d43: and    ecx,0x7fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2d49:
	/* 0x2d49: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2d4e:
	/* 0x2d4e: mov    BYTE PTR [rsi+rcx*1],0x2f */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 47ULL);
x86_l_2d52:
	/* 0x2d52: sub    edx,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_2d54:
	/* 0x2d54: mov    QWORD PTR [rsp+0x8],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2d59:
	/* 0x2d59: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2d5e:
	/* 0x2d5e: jmp    2dea <trace_security_bprm_creds_for_exec+0x2dea> */
	X86_SIM_X86_JMP(0x2d5e, 0x2dea, x86_l_2dea);
x86_l_2d63:
	/* 0x2d63: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_2d66:
	/* 0x2d66: jne    1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2d66, 0x1648, x86_l_1648);
x86_l_2d6c:
	/* 0x2d6c: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d70:
	/* 0x2d70: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_2d75:
	/* 0x2d75: je     1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2d75, 0x1648, x86_l_1648);
x86_l_2d7b:
	/* 0x2d7b: add    rax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2d7f:
	/* 0x2d7f: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2d84:
	/* 0x2d84: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_2d89:
	/* 0x2d89: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_2d8f:
	/* 0x2d8f: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2d93:
	/* 0x2d93: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2d97:
	/* 0x2d97: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2d9c:
	/* 0x2d9c: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2d9f:
	/* 0x2d9f: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2da3:
	/* 0x2da3: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2da6:
	/* 0x2da6: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_2dab:
	/* 0x2dab: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_2db1:
	/* 0x2db1: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2db5:
	/* 0x2db5: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2dba:
	/* 0x2dba: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2dbd:
	/* 0x2dbd: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2dc1:
	/* 0x2dc1: lea    rdi,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2dc6:
	/* 0x2dc6: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_2dcb:
	/* 0x2dcb: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_2dd1:
	/* 0x2dd1: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2dd5:
	/* 0x2dd5: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2dda:
	/* 0x2dda: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2ddd:
	/* 0x2ddd: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2de1:
	/* 0x2de1: add    rax,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2de5:
	/* 0x2de5: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2dea:
	/* 0x2dea: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2def:
	/* 0x2def: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_2df4:
	/* 0x2df4: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_2df9:
	/* 0x2df9: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2dfe:
	/* 0x2dfe: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2e03:
	/* 0x2e03: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2e05:
	/* 0x2e05: mov    r15,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2e0a:
	/* 0x2e0a: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2e0f:
	/* 0x2e0f: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2e13:
	/* 0x2e13: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2e18:
	/* 0x2e18: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_2e1d:
	/* 0x2e1d: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_2e22:
	/* 0x2e22: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2e27:
	/* 0x2e27: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2e29:
	/* 0x2e29: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2e2e:
	/* 0x2e2e: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_2e31:
	/* 0x2e31: je     2ec2 <trace_security_bprm_creds_for_exec+0x2ec2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e31, 0x2ec2, x86_l_2ec2);
x86_l_2e37:
	/* 0x2e37: mov    rbx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2e3c:
	/* 0x2e3c: cmp    rdx,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_64);
x86_l_2e3f:
	/* 0x2e3f: je     2ec2 <trace_security_bprm_creds_for_exec+0x2ec2> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2e3f, 0x2ec2, x86_l_2ec2);
x86_l_2e45:
	/* 0x2e45: add    rdx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2e49:
	/* 0x2e49: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2e4e:
	/* 0x2e4e: mov    eax,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 16ULL);
x86_l_2e53:
	/* 0x2e53: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_2e58:
	/* 0x2e58: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_2e5d:
	/* 0x2e5d: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2e5f:
	/* 0x2e5f: mov    esi,DWORD PTR [rsp+0x34] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_2e63:
	/* 0x2e63: inc    esi */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2e65:
	/* 0x2e65: and    esi,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2e6b:
	/* 0x2e6b: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2e70:
	/* 0x2e70: sub    edi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RSI, X86_WIDTH_32, X86_ALU_SUB);
x86_l_2e72:
	/* 0x2e72: jb     20bb <trace_security_bprm_creds_for_exec+0x20bb> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2e72, 0x20bb, x86_l_20bb);
x86_l_2e78:
	/* 0x2e78: mov    rdx,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2e7d:
	/* 0x2e7d: and    edi,0x3fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2e83:
	/* 0x2e83: add    rdi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 40ULL);
x86_l_2e88:
	/* 0x2e88: mov    eax,esi */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RSI, X86_WIDTH_32);
x86_l_2e8a:
	/* 0x2e8a: mov    ecx,0x73 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 115ULL);
x86_l_2e8f:
	/* 0x2e8f: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2e91:
	/* 0x2e91: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_2e94:
	/* 0x2e94: jl     1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2e94, 0x1648, x86_l_1648);
x86_l_2e9a:
	/* 0x2e9a: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2e9f:
	/* 0x2e9f: lea    ecx,[rdx-0x1] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_2ea2:
	/* 0x2ea2: and    ecx,0x7fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_2ea8:
	/* 0x2ea8: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_2ead:
	/* 0x2ead: mov    BYTE PTR [rsi+rcx*1],0x2f */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 47ULL);
x86_l_2eb1:
	/* 0x2eb1: sub    edx,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_2eb3:
	/* 0x2eb3: mov    QWORD PTR [rsp+0x8],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2eb8:
	/* 0x2eb8: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2ebd:
	/* 0x2ebd: jmp    2f49 <trace_security_bprm_creds_for_exec+0x2f49> */
	X86_SIM_X86_JMP(0x2ebd, 0x2f49, x86_l_2f49);
x86_l_2ec2:
	/* 0x2ec2: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_2ec5:
	/* 0x2ec5: jne    1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x2ec5, 0x1648, x86_l_1648);
x86_l_2ecb:
	/* 0x2ecb: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ecf:
	/* 0x2ecf: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_2ed4:
	/* 0x2ed4: je     1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2ed4, 0x1648, x86_l_1648);
x86_l_2eda:
	/* 0x2eda: add    rax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2ede:
	/* 0x2ede: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2ee3:
	/* 0x2ee3: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_2ee8:
	/* 0x2ee8: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_2eee:
	/* 0x2eee: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2ef2:
	/* 0x2ef2: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2ef6:
	/* 0x2ef6: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2efb:
	/* 0x2efb: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2efe:
	/* 0x2efe: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f02:
	/* 0x2f02: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_2f05:
	/* 0x2f05: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_2f0a:
	/* 0x2f0a: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_2f10:
	/* 0x2f10: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f14:
	/* 0x2f14: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2f19:
	/* 0x2f19: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2f1c:
	/* 0x2f1c: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f20:
	/* 0x2f20: lea    rdi,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_2f25:
	/* 0x2f25: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_2f2a:
	/* 0x2f2a: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_2f30:
	/* 0x2f30: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f34:
	/* 0x2f34: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2f39:
	/* 0x2f39: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2f3c:
	/* 0x2f3c: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_2f40:
	/* 0x2f40: add    rax,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2f44:
	/* 0x2f44: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2f49:
	/* 0x2f49: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2f4e:
	/* 0x2f4e: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_2f53:
	/* 0x2f53: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_2f58:
	/* 0x2f58: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_2f5d:
	/* 0x2f5d: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2f62:
	/* 0x2f62: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2f64:
	/* 0x2f64: mov    r15,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2f69:
	/* 0x2f69: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2f6e:
	/* 0x2f6e: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_2f72:
	/* 0x2f72: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2f77:
	/* 0x2f77: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_2f7c:
	/* 0x2f7c: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_2f81:
	/* 0x2f81: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_2f86:
	/* 0x2f86: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2f88:
	/* 0x2f88: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_2f8d:
	/* 0x2f8d: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_2f90:
	/* 0x2f90: je     3021 <trace_security_bprm_creds_for_exec+0x3021> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f90, 0x3021, x86_l_3021);
x86_l_2f96:
	/* 0x2f96: mov    rbx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2f9b:
	/* 0x2f9b: cmp    rdx,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_64);
x86_l_2f9e:
	/* 0x2f9e: je     3021 <trace_security_bprm_creds_for_exec+0x3021> */
	X86_SIM_X86_JCC(X86_CC_E, 0x2f9e, 0x3021, x86_l_3021);
x86_l_2fa4:
	/* 0x2fa4: add    rdx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_2fa8:
	/* 0x2fa8: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_2fad:
	/* 0x2fad: mov    eax,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 16ULL);
x86_l_2fb2:
	/* 0x2fb2: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_2fb7:
	/* 0x2fb7: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_2fbc:
	/* 0x2fbc: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2fbe:
	/* 0x2fbe: mov    esi,DWORD PTR [rsp+0x34] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_2fc2:
	/* 0x2fc2: inc    esi */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_2fc4:
	/* 0x2fc4: and    esi,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_2fca:
	/* 0x2fca: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2fcf:
	/* 0x2fcf: sub    edi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RSI, X86_WIDTH_32, X86_ALU_SUB);
x86_l_2fd1:
	/* 0x2fd1: jb     20bb <trace_security_bprm_creds_for_exec+0x20bb> */
	X86_SIM_X86_JCC(X86_CC_B, 0x2fd1, 0x20bb, x86_l_20bb);
x86_l_2fd7:
	/* 0x2fd7: mov    rdx,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_2fdc:
	/* 0x2fdc: and    edi,0x3fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_2fe2:
	/* 0x2fe2: add    rdi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 40ULL);
x86_l_2fe7:
	/* 0x2fe7: mov    eax,esi */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RSI, X86_WIDTH_32);
x86_l_2fe9:
	/* 0x2fe9: mov    ecx,0x73 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 115ULL);
x86_l_2fee:
	/* 0x2fee: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_2ff0:
	/* 0x2ff0: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_2ff3:
	/* 0x2ff3: jl     1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_L, 0x2ff3, 0x1648, x86_l_1648);
x86_l_2ff9:
	/* 0x2ff9: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_2ffe:
	/* 0x2ffe: lea    ecx,[rdx-0x1] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_3001:
	/* 0x3001: and    ecx,0x7fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_3007:
	/* 0x3007: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_300c:
	/* 0x300c: mov    BYTE PTR [rsi+rcx*1],0x2f */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 47ULL);
x86_l_3010:
	/* 0x3010: sub    edx,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_3012:
	/* 0x3012: mov    QWORD PTR [rsp+0x8],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3017:
	/* 0x3017: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_301c:
	/* 0x301c: jmp    30a8 <trace_security_bprm_creds_for_exec+0x30a8> */
	X86_SIM_X86_JMP(0x301c, 0x30a8, x86_l_30a8);
x86_l_3021:
	/* 0x3021: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_3024:
	/* 0x3024: jne    1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3024, 0x1648, x86_l_1648);
x86_l_302a:
	/* 0x302a: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_302e:
	/* 0x302e: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_3033:
	/* 0x3033: je     1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3033, 0x1648, x86_l_1648);
x86_l_3039:
	/* 0x3039: add    rax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_303d:
	/* 0x303d: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3042:
	/* 0x3042: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_3047:
	/* 0x3047: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_304d:
	/* 0x304d: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3051:
	/* 0x3051: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_3055:
	/* 0x3055: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_305a:
	/* 0x305a: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_305d:
	/* 0x305d: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3061:
	/* 0x3061: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_3064:
	/* 0x3064: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_3069:
	/* 0x3069: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_306f:
	/* 0x306f: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3073:
	/* 0x3073: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3078:
	/* 0x3078: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_307b:
	/* 0x307b: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_307f:
	/* 0x307f: lea    rdi,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3084:
	/* 0x3084: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_3089:
	/* 0x3089: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_308f:
	/* 0x308f: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3093:
	/* 0x3093: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3098:
	/* 0x3098: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_309b:
	/* 0x309b: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_309f:
	/* 0x309f: add    rax,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_30a3:
	/* 0x30a3: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_30a8:
	/* 0x30a8: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_30ad:
	/* 0x30ad: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_30b2:
	/* 0x30b2: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_30b7:
	/* 0x30b7: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_30bc:
	/* 0x30bc: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_30c1:
	/* 0x30c1: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_30c3:
	/* 0x30c3: mov    r15,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_30c8:
	/* 0x30c8: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_30cd:
	/* 0x30cd: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_30d1:
	/* 0x30d1: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_30d6:
	/* 0x30d6: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_30db:
	/* 0x30db: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_30e0:
	/* 0x30e0: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_30e5:
	/* 0x30e5: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_30e7:
	/* 0x30e7: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_30ec:
	/* 0x30ec: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_30ef:
	/* 0x30ef: je     3180 <trace_security_bprm_creds_for_exec+0x3180> */
	X86_SIM_X86_JCC(X86_CC_E, 0x30ef, 0x3180, x86_l_3180);
x86_l_30f5:
	/* 0x30f5: mov    rbx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_30fa:
	/* 0x30fa: cmp    rdx,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_64);
x86_l_30fd:
	/* 0x30fd: je     3180 <trace_security_bprm_creds_for_exec+0x3180> */
	X86_SIM_X86_JCC(X86_CC_E, 0x30fd, 0x3180, x86_l_3180);
x86_l_3103:
	/* 0x3103: add    rdx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_3107:
	/* 0x3107: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_310c:
	/* 0x310c: mov    eax,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 16ULL);
x86_l_3111:
	/* 0x3111: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_3116:
	/* 0x3116: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_311b:
	/* 0x311b: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_311d:
	/* 0x311d: mov    esi,DWORD PTR [rsp+0x34] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_3121:
	/* 0x3121: inc    esi */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_3123:
	/* 0x3123: and    esi,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_3129:
	/* 0x3129: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_312e:
	/* 0x312e: sub    edi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RSI, X86_WIDTH_32, X86_ALU_SUB);
x86_l_3130:
	/* 0x3130: jb     20bb <trace_security_bprm_creds_for_exec+0x20bb> */
	X86_SIM_X86_JCC(X86_CC_B, 0x3130, 0x20bb, x86_l_20bb);
x86_l_3136:
	/* 0x3136: mov    rdx,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_313b:
	/* 0x313b: and    edi,0x3fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_3141:
	/* 0x3141: add    rdi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 40ULL);
x86_l_3146:
	/* 0x3146: mov    eax,esi */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RSI, X86_WIDTH_32);
x86_l_3148:
	/* 0x3148: mov    ecx,0x73 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 115ULL);
x86_l_314d:
	/* 0x314d: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_314f:
	/* 0x314f: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_3152:
	/* 0x3152: jl     1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_L, 0x3152, 0x1648, x86_l_1648);
x86_l_3158:
	/* 0x3158: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_315d:
	/* 0x315d: lea    ecx,[rdx-0x1] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_3160:
	/* 0x3160: and    ecx,0x7fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_3166:
	/* 0x3166: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_316b:
	/* 0x316b: mov    BYTE PTR [rsi+rcx*1],0x2f */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 47ULL);
x86_l_316f:
	/* 0x316f: sub    edx,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_3171:
	/* 0x3171: mov    QWORD PTR [rsp+0x8],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3176:
	/* 0x3176: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_317b:
	/* 0x317b: jmp    3207 <trace_security_bprm_creds_for_exec+0x3207> */
	X86_SIM_X86_JMP(0x317b, 0x3207, x86_l_3207);
x86_l_3180:
	/* 0x3180: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_3183:
	/* 0x3183: jne    1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x3183, 0x1648, x86_l_1648);
x86_l_3189:
	/* 0x3189: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_318d:
	/* 0x318d: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_3192:
	/* 0x3192: je     1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3192, 0x1648, x86_l_1648);
x86_l_3198:
	/* 0x3198: add    rax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_319c:
	/* 0x319c: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_31a1:
	/* 0x31a1: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_31a6:
	/* 0x31a6: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_31ac:
	/* 0x31ac: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_31b0:
	/* 0x31b0: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_31b4:
	/* 0x31b4: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_31b9:
	/* 0x31b9: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_31bc:
	/* 0x31bc: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_31c0:
	/* 0x31c0: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_31c3:
	/* 0x31c3: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_31c8:
	/* 0x31c8: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_31ce:
	/* 0x31ce: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_31d2:
	/* 0x31d2: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_31d7:
	/* 0x31d7: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_31da:
	/* 0x31da: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_31de:
	/* 0x31de: lea    rdi,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_31e3:
	/* 0x31e3: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_31e8:
	/* 0x31e8: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_31ee:
	/* 0x31ee: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_31f2:
	/* 0x31f2: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_31f7:
	/* 0x31f7: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_31fa:
	/* 0x31fa: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_31fe:
	/* 0x31fe: add    rax,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_3202:
	/* 0x3202: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3207:
	/* 0x3207: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_320c:
	/* 0x320c: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_3211:
	/* 0x3211: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_3216:
	/* 0x3216: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_321b:
	/* 0x321b: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3220:
	/* 0x3220: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3222:
	/* 0x3222: mov    r15,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3227:
	/* 0x3227: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_322c:
	/* 0x322c: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_3230:
	/* 0x3230: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3235:
	/* 0x3235: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_323a:
	/* 0x323a: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_323f:
	/* 0x323f: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3244:
	/* 0x3244: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3246:
	/* 0x3246: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_324b:
	/* 0x324b: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_324e:
	/* 0x324e: je     32df <trace_security_bprm_creds_for_exec+0x32df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x324e, 0x32df, x86_l_32df);
x86_l_3254:
	/* 0x3254: mov    rbx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3259:
	/* 0x3259: cmp    rdx,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_64);
x86_l_325c:
	/* 0x325c: je     32df <trace_security_bprm_creds_for_exec+0x32df> */
	X86_SIM_X86_JCC(X86_CC_E, 0x325c, 0x32df, x86_l_32df);
x86_l_3262:
	/* 0x3262: add    rdx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_3266:
	/* 0x3266: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_326b:
	/* 0x326b: mov    eax,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 16ULL);
x86_l_3270:
	/* 0x3270: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_3275:
	/* 0x3275: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_327a:
	/* 0x327a: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_327c:
	/* 0x327c: mov    esi,DWORD PTR [rsp+0x34] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_3280:
	/* 0x3280: inc    esi */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_3282:
	/* 0x3282: and    esi,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_3288:
	/* 0x3288: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_328d:
	/* 0x328d: sub    edi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RSI, X86_WIDTH_32, X86_ALU_SUB);
x86_l_328f:
	/* 0x328f: jb     20bb <trace_security_bprm_creds_for_exec+0x20bb> */
	X86_SIM_X86_JCC(X86_CC_B, 0x328f, 0x20bb, x86_l_20bb);
x86_l_3295:
	/* 0x3295: mov    rdx,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_329a:
	/* 0x329a: and    edi,0x3fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_32a0:
	/* 0x32a0: add    rdi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 40ULL);
x86_l_32a5:
	/* 0x32a5: mov    eax,esi */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RSI, X86_WIDTH_32);
x86_l_32a7:
	/* 0x32a7: mov    ecx,0x73 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 115ULL);
x86_l_32ac:
	/* 0x32ac: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_32ae:
	/* 0x32ae: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_32b1:
	/* 0x32b1: jl     1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_L, 0x32b1, 0x1648, x86_l_1648);
x86_l_32b7:
	/* 0x32b7: mov    rdx,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_32bc:
	/* 0x32bc: lea    ecx,[rdx-0x1] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_RDX, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_32bf:
	/* 0x32bf: and    ecx,0x7fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_32c5:
	/* 0x32c5: mov    rsi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_32ca:
	/* 0x32ca: mov    BYTE PTR [rsi+rcx*1],0x2f */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RSI, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 47ULL);
x86_l_32ce:
	/* 0x32ce: sub    edx,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_RDX, X86_RAX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_32d0:
	/* 0x32d0: mov    QWORD PTR [rsp+0x8],rdx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RDX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_32d5:
	/* 0x32d5: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_32da:
	/* 0x32da: jmp    3366 <trace_security_bprm_creds_for_exec+0x3366> */
	X86_SIM_X86_JMP(0x32da, 0x3366, x86_l_3366);
x86_l_32df:
	/* 0x32df: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_32e2:
	/* 0x32e2: jne    1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x32e2, 0x1648, x86_l_1648);
x86_l_32e8:
	/* 0x32e8: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_32ec:
	/* 0x32ec: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_32f1:
	/* 0x32f1: je     1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_E, 0x32f1, 0x1648, x86_l_1648);
x86_l_32f7:
	/* 0x32f7: add    rax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_32fb:
	/* 0x32fb: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3300:
	/* 0x3300: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_3305:
	/* 0x3305: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_330b:
	/* 0x330b: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_330f:
	/* 0x330f: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_3313:
	/* 0x3313: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3318:
	/* 0x3318: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_331b:
	/* 0x331b: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_331f:
	/* 0x331f: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_3322:
	/* 0x3322: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_3327:
	/* 0x3327: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_332d:
	/* 0x332d: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3331:
	/* 0x3331: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3336:
	/* 0x3336: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3339:
	/* 0x3339: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_333d:
	/* 0x333d: lea    rdi,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_3342:
	/* 0x3342: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_3347:
	/* 0x3347: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_334d:
	/* 0x334d: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3351:
	/* 0x3351: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3356:
	/* 0x3356: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3359:
	/* 0x3359: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_335d:
	/* 0x335d: add    rax,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_3361:
	/* 0x3361: mov    QWORD PTR [rsp+0x20],rax */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RAX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_3366:
	/* 0x3366: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_336b:
	/* 0x336b: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_3370:
	/* 0x3370: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_3375:
	/* 0x3375: mov    rdx,QWORD PTR [rsp+0x20] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 32ULL);
x86_l_337a:
	/* 0x337a: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_337f:
	/* 0x337f: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3381:
	/* 0x3381: mov    r15,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3386:
	/* 0x3386: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_338b:
	/* 0x338b: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_338f:
	/* 0x338f: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_3394:
	/* 0x3394: mov    eax,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 8ULL);
x86_l_3399:
	/* 0x3399: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_339e:
	/* 0x339e: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_33a3:
	/* 0x33a3: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_33a5:
	/* 0x33a5: mov    rdx,QWORD PTR [rsp+0x10] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_33aa:
	/* 0x33aa: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_33ad:
	/* 0x33ad: je     3437 <trace_security_bprm_creds_for_exec+0x3437> */
	X86_SIM_X86_JCC(X86_CC_E, 0x33ad, 0x3437, x86_l_3437);
x86_l_33b3:
	/* 0x33b3: mov    rbx,QWORD PTR [rsp+0x30] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RBX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_33b8:
	/* 0x33b8: cmp    rdx,rbx */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_RBX, X86_WIDTH_64);
x86_l_33bb:
	/* 0x33bb: je     3437 <trace_security_bprm_creds_for_exec+0x3437> */
	X86_SIM_X86_JCC(X86_CC_E, 0x33bb, 0x3437, x86_l_3437);
x86_l_33bd:
	/* 0x33bd: add    rdx,0x10 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 16ULL);
x86_l_33c1:
	/* 0x33c1: lea    rdi,[rsp+0x30] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 48ULL);
x86_l_33c6:
	/* 0x33c6: mov    eax,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RAX, X86_WIDTH_32, 16ULL);
x86_l_33cb:
	/* 0x33cb: mov    ecx,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 113ULL);
x86_l_33d0:
	/* 0x33d0: mov    esi,0x10 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 16ULL);
x86_l_33d5:
	/* 0x33d5: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_33d7:
	/* 0x33d7: mov    esi,DWORD PTR [rsp+0x34] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RSI, X86_RSP, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 52ULL);
x86_l_33db:
	/* 0x33db: inc    esi */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_INC, 1);
x86_l_33dd:
	/* 0x33dd: and    esi,0xfff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RSI, X86_WIDTH_32, X86_ALU_AND, 4095ULL);
x86_l_33e3:
	/* 0x33e3: mov    rdi,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_33e8:
	/* 0x33e8: sub    edi,esi */
	X86_SIM_L_EXEC_ALU_REG(X86_RDI, X86_RSI, X86_WIDTH_32, X86_ALU_SUB);
x86_l_33ea:
	/* 0x33ea: jb     20bb <trace_security_bprm_creds_for_exec+0x20bb> */
	X86_SIM_X86_JCC(X86_CC_B, 0x33ea, 0x20bb, x86_l_20bb);
x86_l_33f0:
	/* 0x33f0: mov    rdx,QWORD PTR [rsp+0x38] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 56ULL);
x86_l_33f5:
	/* 0x33f5: and    edi,0x3fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDI, X86_WIDTH_32, X86_ALU_AND, 16383ULL);
x86_l_33fb:
	/* 0x33fb: add    rdi,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_ALU_MEM(X86_RDI, X86_RSP, X86_WIDTH_64, (X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64) | X86_MEM_AUX_ALU_OP(X86_ALU_ADD)), 40ULL);
x86_l_3400:
	/* 0x3400: mov    eax,esi */
	X86_SIM_L_EXEC_MOV_REG(X86_RAX, X86_RSI, X86_WIDTH_32);
x86_l_3402:
	/* 0x3402: mov    ecx,0x73 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 115ULL);
x86_l_3407:
	/* 0x3407: call   rcx */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_RCX);
		switch (X86_SIM_L_REG_TAG(X86_RCX)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x73ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel_str(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3409:
	/* 0x3409: cmp    eax,0x2 */
	X86_SIM_L_EXEC_CMP_IMM_OP(X86_OP_CMP_IMM, X86_RAX, X86_WIDTH_32, 2ULL);
x86_l_340c:
	/* 0x340c: jl     1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_L, 0x340c, 0x1648, x86_l_1648);
x86_l_3412:
	/* 0x3412: mov    r15,QWORD PTR [rsp+0x8] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_R15, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 8ULL);
x86_l_3417:
	/* 0x3417: lea    ecx,[r15-0x1] */
	X86_SIM_L_EXEC_LEA(X86_RCX, X86_R15, X86_WIDTH_32, X86_MEM_AUX(X86_REG_NONE, 0), 18446744073709551615ULL);
x86_l_341b:
	/* 0x341b: and    ecx,0x7fff */
	X86_SIM_L_EXEC_ALU_IMM(X86_RCX, X86_WIDTH_32, X86_ALU_AND, 32767ULL);
x86_l_3421:
	/* 0x3421: mov    rdx,QWORD PTR [rsp+0x28] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 40ULL);
x86_l_3426:
	/* 0x3426: mov    BYTE PTR [rdx+rcx*1],0x2f */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_IMM, X86_RDX, X86_REG_NONE, X86_WIDTH_8, X86_MEM_AUX(X86_RCX, 0), 47ULL);
x86_l_342a:
	/* 0x342a: sub    r15d,eax */
	X86_SIM_L_EXEC_ALU_REG(X86_R15, X86_RAX, X86_WIDTH_32, X86_ALU_SUB);
x86_l_342d:
	/* 0x342d: mov    QWORD PTR [rsp+0x10],rbx */
	X86_SIM_L_EXEC_STORE(X86_OP_MOV_STORE_REG, X86_RSP, X86_RBX, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3432:
	/* 0x3432: jmp    164d <trace_security_bprm_creds_for_exec+0x164d> */
	X86_SIM_X86_JMP(0x3432, 0x164d, x86_l_164d);
x86_l_3437:
	/* 0x3437: cmp    rdx,r15 */
	X86_SIM_L_EXEC_CMP_REG_OP(X86_OP_CMP_REG, X86_RDX, X86_R15, X86_WIDTH_64);
x86_l_343a:
	/* 0x343a: jne    1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_NE, 0x343a, 0x1648, x86_l_1648);
x86_l_3440:
	/* 0x3440: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3444:
	/* 0x3444: cmp    rax,QWORD PTR [rsp+0x18] */
	X86_SIM_L_EXEC_CMP_REG_MEM(X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX_FULL(X86_REG_NONE, 0, X86_WIDTH_64), 24ULL);
x86_l_3449:
	/* 0x3449: je     1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JCC(X86_CC_E, 0x3449, 0x1648, x86_l_1648);
x86_l_344f:
	/* 0x344f: add    rax,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RAX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_3453:
	/* 0x3453: lea    rdi,[rsp+0x10] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 16ULL);
x86_l_3458:
	/* 0x3458: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_345d:
	/* 0x345d: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_3463:
	/* 0x3463: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3467:
	/* 0x3467: add    rdx,0x8 */
	X86_SIM_L_EXEC_ALU_IMM(X86_RDX, X86_WIDTH_64, X86_ALU_ADD, 8ULL);
x86_l_346b:
	/* 0x346b: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_3470:
	/* 0x3470: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3473:
	/* 0x3473: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3477:
	/* 0x3477: mov    rdi,rsp */
	X86_SIM_L_EXEC_MOV_REG(X86_RDI, X86_RSP, X86_WIDTH_64);
x86_l_347a:
	/* 0x347a: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_347f:
	/* 0x347f: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_3485:
	/* 0x3485: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3489:
	/* 0x3489: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_348e:
	/* 0x348e: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_3491:
	/* 0x3491: mov    rax,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RAX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_3495:
	/* 0x3495: lea    rdi,[rsp+0x18] */
	X86_SIM_L_EXEC_LEA(X86_RDI, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 24ULL);
x86_l_349a:
	/* 0x349a: mov    ecx,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RCX, X86_WIDTH_32, 8ULL);
x86_l_349f:
	/* 0x349f: mov    r8d,0x71 */
	X86_SIM_L_EXEC_MOV_IMM(X86_R8, X86_WIDTH_32, 113ULL);
x86_l_34a5:
	/* 0x34a5: mov    rdx,QWORD PTR [rsp] */
	X86_SIM_L_EXEC_MOV_LOAD(X86_OP_MOV_LOAD, X86_RDX, X86_RSP, X86_WIDTH_64, X86_MEM_AUX(X86_REG_NONE, 0), 0ULL);
x86_l_34a9:
	/* 0x34a9: mov    esi,0x8 */
	X86_SIM_L_EXEC_MOV_IMM(X86_RSI, X86_WIDTH_32, 8ULL);
x86_l_34ae:
	/* 0x34ae: call   r8 */
	{
		__u64 __x86_target = X86_SIM_L_READ_REG(X86_R8);
		switch (X86_SIM_L_REG_TAG(X86_R8)) {
		case X86_SIM_TAG_SCALAR:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		case X86_SIM_TAG_HELPER_ID:
			switch (__x86_target) {
			case 0x71ULL: X86_SIM_BPF_CALL_bpf_probe_read_kernel(); break;
			default: __x86_sim_unresolved_indirect_target();
			}
			break;
		default: __x86_sim_unresolved_indirect_target();
		}
	}
x86_l_34b1:
	/* 0x34b1: jmp    1648 <trace_security_bprm_creds_for_exec+0x1648> */
	X86_SIM_X86_JMP(0x34b1, 0x1648, x86_l_1648);
x86_l_34b6:
	/* native-link entry fallthrough exit */
	X86_SIM_X86_RET();
}

X86_SIM_LICENSE();
