#line 1 "/workspaces/kprog-raw/verified/20261114-packet-bounds/final-host/preprocess-control/valid/stream.bpf.c"
#include <linux/bpf.h>
#include <bpf_helpers.h>
#define STEP(N) total += input[N] + __LINE__ + __FILE__[0]
SEC("kprobe/stream") int stream(void *ctx) {
volatile __u64 *input = ctx;
__u64 total = 0;
#pragma kprog_preprocessed_piece
#line 13 "/workspaces/kprog-raw/verified/20261114-packet-bounds/final-host/preprocess-control/valid/stream.bpf.c"
x86_l_3:
return total;
}
char LICENSE[] SEC("license") = "GPL";

