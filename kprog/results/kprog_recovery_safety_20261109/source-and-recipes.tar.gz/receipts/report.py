from pathlib import Path
from collections import Counter
import csv,hashlib,io,json,shutil,tarfile,subprocess
R=Path('/workspaces/repository');O=Path('/var/tmp/kprog-tmp/S16');P=R/'kprog/results/kprog_recovery_safety_20261109'
P.mkdir(exist_ok=True)
def sha(data):return hashlib.sha256(data).hexdigest()
def load_arm(d):
 p=d/'safety-arm64-output/trusted-arm64-service-result/summary.json';meta=json.loads(p.read_text());archive=p.parent/meta['archive']
 assert sha(archive.read_bytes())==meta['archive_sha256']
 with tarfile.open(archive) as t:rows=json.load(t.extractfile('run/outcomes.json'))
 return rows,meta,archive
xr=json.loads((O/'safety-x86-output/run/outcomes.json').read_text());ar,am,aa=load_arm(O);vr,vm,va=load_arm(O/'vector')
assert len(xr)==47 and len(ar)==48 and len(vr)==2
assert all(not x['unsafe_native_executed'] for rows in [xr,ar,vr] for x in rows if x['negative'])
assert all(x['stage']=='valid_executed' for rows in [xr,ar] for x in rows if not x['negative'])
expected={'x86':{'immediate_push_branch','stack_base_flags'},'arm64':{'unpaired_stxr_failure','unpaired_stlxr_failure','paired_stxr_failure','paired_stlxr_failure','entry_return_address_flags','stack_base_flags'}}
assert {x['name'] for x in xr if x['stage']=='accepted_finding'}==expected['x86']
assert {x['name'] for x in ar if x['stage']=='accepted_finding'}==expected['arm64']
assert {r['name']:r['stage'] for r in vr}=={'scalar_vector_load_clear_high':'accepted_finding','scalar_vector_load_clear_high_scalar_store':'verifier_rejected'}
for arch,rows in [('x86',xr),('arm64',ar)]:
 for r in rows:
  if r['name'].endswith('_scalar_store'):
   assert r['stage']==('specialization_rejected' if r['name']=='scalar_vector_load_clear_high_scalar_store' else 'verifier_rejected')
assert am['qemu_returncode']==vm['qemu_returncode']==0
assert am['hashes_unchanged'] and vm['hashes_unchanged']
primary_pins=json.loads((O/'safety-arm64-output/pins.json').read_text())
vector_pins=json.loads((O/'vector/safety-arm64-output/pins.json').read_text())
vector_source_differences={k:{'primary':primary_pins[k],'retained_vector':vector_pins[k]} for k in primary_pins.keys() & vector_pins.keys() if primary_pins[k]!=vector_pins[k]}
assert set(vector_source_differences)=={'kprog/arm64/micro-prog/generate_micro_sim_proofs.py'}
# Keep compact source/native/B identities beside the complete archived request evidence.
def request_evidence(row,arch,arm_archive=None):
 rec=row['request'];p=rec.get('artifact_archive',rec.get('failure_archive'));out={'native_sha256':row['native_sha256'],'request_id':rec['request_id'],'service_status':rec['status'],'prog_id':rec.get('prog_id'),'archive_member':'run/requests/'+Path(p).name}
 if arm_archive:
  with tarfile.open(arm_archive) as t:data=t.extractfile(out['archive_member']).read()
 else:data=(O/'safety-x86-output/run/requests'/Path(p).name).read_bytes()
 out['request_archive_sha256']=sha(data)
 with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as t:
  hashes={m.name:sha(t.extractfile(m).read()) for m in t.getmembers() if m.isfile() and (m.name.endswith(('.bpf.o','.proof.o','kernel.native.o','.blob.bin','.bpf.c')))}
 out['artifacts']=hashes
 if row['stage']=='verifier_rejected':
  lines=[s.strip() for s in row['message'].splitlines() if any(k in s for k in ['invalid mem access','invalid access','R0 invalid','math between','processed '])]
  out['verifier_diagnostic']=list(dict.fromkeys(lines))[-5:]
 return out
reasons={
 ('x86','immediate_push_branch'):'PUSH/POP produces RCX=1; the fallthrough zero-address dword load recovers with RAX=0 and RET consumes the preserved return slot.',
 ('x86','stack_base_flags'):'Restored native RSP supplies the branch flags; each selected zero-address dword load recovers with RAX=0, followed by the preserved RET.',
 ('arm64','scalar_vector_load_clear_high'):'The scalar D0 load clears the upper vector half; its selected zero-address X0 load recovers with X0=0, then W0=2 and RET preserve the entry frame.',
 ('arm64','unpaired_stxr_failure'):'The exclusive-status failure arm selects a zero-address W0 load; recovery clears X0, followed by SP restoration, W0=2 and RET.',
 ('arm64','unpaired_stlxr_failure'):'The release-exclusive-status failure arm selects a zero-address W0 load; recovery clears X0, followed by SP restoration, W0=2 and RET.',
 ('arm64','paired_stxr_failure'):'Either exclusive-store status is safe: success returns directly; failure selects a zero-address W0 load and recovery, then restores SP and returns2.',
 ('arm64','paired_stlxr_failure'):'Either acquire/release-exclusive-store status is safe: success returns directly; failure selects a zero-address W0 load and recovery, then restores SP and returns2.',
 ('arm64','entry_return_address_flags'):'The LR-dependent arm selects a zero-address W0 load; recovery clears X0 and preserves X30 for RET. The other arm returns2.',
 ('arm64','stack_base_flags'):'The restored-SP comparison selects a zero-address W0 load; recovery clears X0 and preserves SP/X30 for RET. The other arm returns2.'}
accepted=[]
for arch,rows,archive in [('x86',xr,None),('arm64',ar,aa),('arm64',vr,va)]:
 for r in rows:
  if r['stage']!='accepted_finding':continue
  domain='retained_SIMD_generator' if rows is vr else 'current_scalar_generator'
  e=request_evidence(r,arch,archive)
  accepted.append(dict(isa=arch,case=r['name'],domain=domain,current_stage=next(z['stage'] for z in ar if z['name']==r['name']) if rows is vr else r['stage'],verdict='benign_protected_read',effect=reasons[arch,r['name']],assembly=r['assembly'],evidence_archive='retained-vector-raw.tar.gz' if rows is vr else arch+'-raw.tar.gz',**e))
# Include every accepted S7/S10 original label in the explicit verdict table.
hist=json.loads((R/'kprog/results/kprog_arm64_read_followup_20261109/final-summary.json').read_text())
assert set(hist['accepted_findings'])=={x['case'] for x in accepted if x['isa']=='arm64'}
variants=[]
for arch,rows,archive in [('x86',xr,None),('arm64',ar,aa),('arm64',vr,va)]:
 for r in rows:
  if r['name'].endswith('_scalar_store'):
   variants.append(dict(isa=arch,case=r['name'],domain='retained_SIMD_generator' if rows is vr else 'current_scalar_generator',stage=r['stage'],evidence_archive='retained-vector-raw.tar.gz' if rows is vr else arch+'-raw.tar.gz',**request_evidence(r,arch,archive)))
(P/'accepted-cases.json').write_text(json.dumps(accepted,indent=2)+'\n')
(P/'store-variants.json').write_text(json.dumps(variants,indent=2)+'\n')
with (P/'accepted-cases.tsv').open('w') as f:
 cols=['isa','case','domain','current_stage','verdict','effect','native_sha256','request_id','service_status','prog_id','request_archive_sha256','evidence_archive','archive_member'];w=csv.DictWriter(f,cols,delimiter='\t',extrasaction='ignore',lineterminator='\n');w.writeheader();w.writerows(accepted)
with (P/'store-variants.tsv').open('w') as f:
 cols=['isa','case','domain','stage','native_sha256','request_id','service_status','request_archive_sha256','evidence_archive','archive_member'];w=csv.DictWriter(f,cols,delimiter='\t',extrasaction='ignore',lineterminator='\n');w.writeheader();w.writerows(variants)
# Raw artifacts preserve all outcomes, requests, compiler logs and verifier diagnostics.
with tarfile.open(P/'x86-raw.tar.gz','w:gz') as t:
 t.add(O/'safety-x86-output/run',arcname='run')
 for n in ['cases.json','pins.json','build.json','s7.py','_base_check.py']:t.add(O/'safety-x86-output'/n,arcname=n)
shutil.copyfile(aa,P/'arm64-raw.tar.gz');shutil.copyfile(va,P/'retained-vector-raw.tar.gz')
with tarfile.open(P/'source-and-recipes.tar.gz','w:gz') as t:
 for root,prefix in [(O/'output-x86-source','current/x86'),(O/'output-arm64-source','current/arm64'),(O/'vector/output-arm64-source','retained-vector/arm64')]:
  for p in sorted(root.rglob('*')):
   if p.is_file() and p.suffix in ['.h','.py','.c','.json','.toml']:t.add(p,arcname=str(Path(prefix)/p.relative_to(root)))
 for n in ['replay.mk','replay.sh','x86-replay.py','arm64-replay.py','x86.log','arm64.log','fixture-review.json','s7-x86-outcomes.json','s7-arm64-outcomes.json','s7-arm64-transport.json','baseline-source-comparison.json','coverage-base.json','report.py']:
  t.add(O/n,arcname='receipts/'+n)
 for n in ['replay.py','replay.mk','run.sh','replay.log','retained-generator.py']:t.add(O/'vector'/n,arcname='retained-vector/'+n)
 t.add(R/'kprog/fidelity/negative.py',arcname='fixtures/negative.py')
 for name in ['x86','arm64']:
  t.add(O/('safety-'+name)/'s7.py',arcname='harness/'+name+'/s7.py');t.add(O/('safety-'+name)/'_base_check.py',arcname='harness/'+name+'/_base_check.py')
summary={'fixture_commit':'9bd4222ba','isa_counts':{},'accepted_case_verdicts':dict(Counter(a['verdict'] for a in accepted)),'observed_safety_violating_acceptances':0,'negative_native_executions':0,'current_store_companions':dict(Counter(x['stage'] for x in variants if x['domain']=='current_scalar_generator')),'retained_vector_store_companion':'verifier_rejected','retained_vector_generator_commit':'dba3416ac^','retained_vector_source_differences':vector_source_differences,'s10_history':hist,'s7_baseline':{},'baseline_source_comparison':json.loads((O/'baseline-source-comparison.json').read_text()),'make_exit':{a:int((O/(a+'.exit')).read_text()) for a in ['x86','arm64']},'retained_vector_make_exit':int((O/'vector/replay.exit').read_text()),'arm64_transport':{'qemu_returncode':am['qemu_returncode'],'guest_exit':am['guest_exit'],'hashes_unchanged':am['hashes_unchanged']},'retained_vector_transport':{'qemu_returncode':vm['qemu_returncode'],'guest_exit':vm['guest_exit'],'hashes_unchanged':vm['hashes_unchanged']},'production_lines_added':0,'fixture_lines_added':9,'universal_proof_status':'Finite safety regression evidence; universal recovery/O2/compiled-body/physical extable composition retains V/S13 ownership.'}
for a,rows in [('x86',xr),('arm64',ar)]:
 summary['isa_counts'][a]={'cases':len(rows),'stages':dict(sorted(Counter(r['stage'] for r in rows).items())),'benign_protected_read_accepted':sum(r['stage']=='accepted_finding' for r in rows),'safety_violating_accepted':0,'store_companions':{r['name']:r['stage'] for r in rows if r['name'].endswith('_scalar_store')},'source_pins':json.loads((O/('safety-'+a+'-output')/'pins.json').read_text())}
 baseline=json.loads((O/('s7-'+a+'-outcomes.json')).read_text());summary['s7_baseline'][a]={'cases':len(baseline),'stages':dict(sorted(Counter(r['stage'] for r in baseline).items()))}
 summary['isa_counts'][a]['original_cases_after_companion_exclusion']=dict(sorted(Counter(r['stage'] for r in rows if not r['name'].endswith('_scalar_store')).items()))
compact={a:[{k:r[k] for k in ['name','assembly','negative','native_sha256','stage','unsafe_native_executed','request']} for r in rows] for a,rows in [('x86',xr),('arm64',ar)]}
(P/'outcomes.json').write_text(json.dumps(compact,indent=2)+'\n')
summary['published_archives']={p.name:{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in sorted(P.glob('*.tar.gz'))}
(P/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
text='''# Recovery-aware native safety fixtures

The current captured scalar domain records eight accepted original labels with benign protected-read effects: two x86 and six AArch64. Their selected zero-address reads recover, preserve the return frame and reach a valid return. The retained SIMD generation domain adds the historical AArch64 vector label with the same benign classification. Observed safety-violating acceptances:0. These finite fixture verdicts support regression coverage; universal recovery, O2, compiled-body and physical exception-table composition retain V/S13 ownership.

Nine scalar-store companions preserve each original instruction sequence and replace its failure read with a store at the same scalar address. Current results give eight stock-verifier rejections and one existing SIMD generation rejection. The two-case retained-SIMD replay uses the primary ARM replay's exact recovery C/runtime plus the pre-dba3416ac generator file: its original vector label is accepted and its store companion reaches stock-verifier rejection. Production additions:0. Original fixture bytes and historical annotations remain preserved.

| ISA and domain | Cases | Valid executed | Verifier rejected | Generation rejected | Benign protected-read accepted | Safety-violating accepted |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
'''
for a in ['x86','arm64']:
 z=summary['isa_counts'][a];c=z['stages'];text+=f"| {a} current scalar | {z['cases']} | {c.get('valid_executed',0)} | {c.get('verifier_rejected',0)} | {c.get('specialization_rejected',0)} | {c.get('accepted_finding',0)} | 0 |\n"
text+='| arm64 retained SIMD companion pair | 2 | 0 | 1 | 0 | 1 | 0 |\n\n'
text+='S7 captured baselines: x86 45=9 valid+33 verifier+1 generation+2 accepted; ARM 41=4 valid+28 verifier+3 generation+6 accepted. S10 dd43bc633 retains ARM 34=4 valid+21 verifier+2 generation+7 accepted. Companion exclusion reproduces both S7 stage counts. SIMD policy accounts for the vector-label transition between the S10 and S7 epochs.\n\n'
text+='| ISA | Accepted original label | Current stage | Verdict and effect | Request evidence |\n| --- | --- | --- | --- | --- |\n'
for a in accepted:
 text+=f"| {a['isa']} | `{a['case']}` | `{a['current_stage']}` | {a['verdict']}: {a['effect']} | `{a['evidence_archive']}/{a['archive_member']}`, request {a['request_id']}, prog {a['prog_id']} |\n"
text+='\nThe TSV and JSON tables carry every accepted label, native SHA256, service request/status, loaded program ID, archive identity and generated C/B artifact SHA256. The store table carries every companion result and the corresponding verifier diagnostics. Complete request, compilation and verifier logs accompany the raw archives. summary.json carries the captured source/runtime hashes and all original-stage counts.\n\n'
text+='Execution reuses S7 runtime recipes with one serial2GiB guest at a time, CPU8-23, and private mount namespaces. Each negative producer has argc3 and performs load only; positive controls carry TEST_RUN arguments. Negative native executions:0. Both ARM transport receipts record QEMU0 and unchanged inputs. Make/guest diagnostic exits preserve the suite convention for accepted original labels; every selected case has a terminal receipt.\n\n'
text+='Numeric SP/LR observations use the invocation-stable native entry inputs through `ARM64_SIM_L_MATERIALIZE`; the relative stack/return payloads retain their indexing role. The S7-to-S16 source comparison records matching captured source/runtime hashes on every shared identity key.\n\nSource predicates: `X86_SIM_L_READ_RECOVERY_AT` and `ARM64_SIM_L_READ_FAULT` select protected-read recovery for scalar effective addresses in the low4KiB page; their store bodies perform the ordinary verifier-visible write. The retained vector epoch changes the generator domain only and preserves primary ARM header/runtime hashes. Actual service/kernel receipts establish the tested route; safety claims retain the universal proof boundary above.\n'
(P/'README.md').write_text(text)
base=json.loads((O/'coverage-base.json').read_text());row=base['row'].copy()
evidence=';'.join(str(P.relative_to(R)/n) for n in ['summary.json','accepted-cases.tsv','store-variants.tsv'])
row['replay_evidence']=';'.join(filter(None,[row['replay_evidence'],evidence]))
row['o4_evidence']+=';'+evidence
row['scope']+=' S16 finite recovery-aware safety fixtures preserve every original label and classify9historical accepted labels as benign_protected_read; scalar-store companions reach8current verifier rejections plus retained-SIMD vector verifier rejection, with current vector generation rejection recorded.'
row['o4_completion']+=' S16 published finite source-captured x8647/ARM48 and retained-vector2 fixture receipts; negative native executions0. Universal recovery/O2/compiled-body/physical exception-table composition retains the existing partial component boundary.'
epochs=json.loads(row['replay_source_epochs']);epochs.append(subprocess.check_output(['git','rev-parse','9bd4222ba'],cwd=R,text=True).strip());row['replay_source_epochs']=json.dumps(list(dict.fromkeys(epochs)),separators=(',',':'))
assert row['o4_preservation_status']==base['row']['o4_preservation_status']
with (P/'coverage-proposal.tsv').open('w') as f:
 w=csv.DictWriter(f,base['fields'],delimiter='\t',lineterminator='\n');w.writeheader();w.writerow(row)

print(json.dumps({'isa_counts':{a:{k:v for k,v in z.items() if k not in ['source_pins','store_companions']} for a,z in summary['isa_counts'].items()},'archives':summary['published_archives']},indent=2))
