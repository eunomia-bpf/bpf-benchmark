.PHONY: x86 arm64
x86:
	python3 /var/tmp/kprog-tmp/S16/x86-replay.py
arm64:
	python3 /var/tmp/kprog-tmp/S16/arm64-replay.py
