#!/bin/bash
ulimit -c 0
export TMPDIR=/var/tmp/kprog-tmp/S16 PYTHONDONTWRITEBYTECODE=1
cd /workspaces/repository
for arch in x86 arm64; do
 taskset -c 8-23 make -f /var/tmp/kprog-tmp/S16/replay.mk "$arch" >"/var/tmp/kprog-tmp/S16/$arch.log" 2>&1
 echo $? >"/var/tmp/kprog-tmp/S16/$arch.exit"
done
