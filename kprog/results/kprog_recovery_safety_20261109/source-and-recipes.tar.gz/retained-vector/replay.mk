.PHONY: vector
vector:
	python3 /var/tmp/kprog-tmp/S16/vector/replay.py
