#!/bin/bash
ulimit -c 0
export TMPDIR=/var/tmp/kprog-tmp/S16/vector PYTHONDONTWRITEBYTECODE=1
while [ ! -f /var/tmp/kprog-tmp/S16/arm64.exit ]; do sleep 30; done
cd /workspaces/repository
taskset -c 8-23 make -f /var/tmp/kprog-tmp/S16/vector/replay.mk vector > /var/tmp/kprog-tmp/S16/vector/replay.log 2>&1
echo $? > /var/tmp/kprog-tmp/S16/vector/replay.exit
