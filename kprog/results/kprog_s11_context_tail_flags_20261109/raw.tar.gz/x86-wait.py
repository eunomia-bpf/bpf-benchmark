import os,selectors,subprocess
from pathlib import Path
O=Path('/var/tmp/kprog-tmp/S11')
try:
 fd=os.pidfd_open(3103919);s=selectors.DefaultSelector();s.register(fd,selectors.EVENT_READ);s.select();os.close(fd)
except ProcessLookupError:pass
for name in ['run','tc']:
 p=O/'safety-x86'/name
 if p.exists():p.rename(p.with_name(name+'-attempt1'))
with (O/'safety-x86-retry.log').open('w') as log:
 x=subprocess.run(['unshare','--mount','--propagation','private','python3',str(O/'safety-x86-inside.py')],stdout=log,stderr=subprocess.STDOUT)
(O/'safety-x86-retry.exit').write_text(str(x.returncode)+'\n')
