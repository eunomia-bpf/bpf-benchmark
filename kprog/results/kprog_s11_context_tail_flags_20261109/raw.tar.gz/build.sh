#!/bin/bash
ulimit -c 0
export TMPDIR=/var/tmp/kprog-tmp/S11 PYTHONDONTWRITEBYTECODE=1 CARGO_TARGET_DIR=/var/tmp/kprog-tmp/S11/cargo
export PATH=/usr/local/cargo/bin:/usr/lib/llvm-18/bin:$PATH
cd /workspaces/repository
(taskset -c 8-23 cargo test --manifest-path kprog/x86/native_lab/native_link/Cargo.toml && taskset -c 8-23 cargo build --release --manifest-path kprog/x86/native_lab/native_link/Cargo.toml) > /var/tmp/kprog-tmp/S11/link-build.log 2>&1
echo $? >/var/tmp/kprog-tmp/S11/link-build.exit
taskset -c 8-23 make -C kprog/libnativeloader trusted-service-check BUILD_DIR=/var/tmp/kprog-tmp/S11/loader > /var/tmp/kprog-tmp/S11/loader-build.log 2>&1
echo $? >/var/tmp/kprog-tmp/S11/loader-build.exit
