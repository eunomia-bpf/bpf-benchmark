import os,selectors,subprocess
from pathlib import Path
O=Path('/var/tmp/kprog-tmp/S11')
try:
 fd=os.pidfd_open(3106964);s=selectors.DefaultSelector();s.register(fd,selectors.EVENT_READ);s.select();os.close(fd)
except ProcessLookupError:pass
with (O/'safety-arm-retry.log').open('w') as log:
 x=subprocess.run(['unshare','--mount','--propagation','private','python3',str(O/'arm-inside.py')],stdout=log,stderr=subprocess.STDOUT)
(O/'safety-arm-retry.exit').write_text(str(x.returncode)+'\n')
