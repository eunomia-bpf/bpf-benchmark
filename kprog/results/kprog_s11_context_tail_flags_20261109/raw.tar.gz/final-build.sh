#!/bin/bash
ulimit -c 0
export TMPDIR=/var/tmp/kprog-tmp/S11 CARGO_TARGET_DIR=/var/tmp/kprog-tmp/S11/cargo PYTHONDONTWRITEBYTECODE=1 PATH=/usr/local/cargo/bin:/usr/lib/llvm-18/bin:$PATH
cd /workspaces/repository
cargo test --manifest-path kprog/x86/native_lab/native_link/Cargo.toml >/var/tmp/kprog-tmp/S11/rust-final.log 2>&1
echo $? >/var/tmp/kprog-tmp/S11/rust-final.exit
make -C kprog/libnativeloader trusted-service-check BUILD_DIR=/var/tmp/kprog-tmp/S11/loader >/var/tmp/kprog-tmp/S11/loader-final.log 2>&1
echo $? >/var/tmp/kprog-tmp/S11/loader-final.exit
