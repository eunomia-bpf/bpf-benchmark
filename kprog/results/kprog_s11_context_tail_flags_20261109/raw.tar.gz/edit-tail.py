from pathlib import Path
p=Path('kinsn/module/include/native_lab_binding.h');s=p.read_text();s=s.replace('#define NATIVE_LAB_RELOC_EXCLUSIVE_FAILURE 9U', '''#define NATIVE_LAB_RELOC_EXCLUSIVE_FAILURE 9U
/* x86 JIT frame immediates, resolved from the final physical stack depth. */
#define NATIVE_LAB_RELOC_X86_TAIL_COUNT 10U
#define NATIVE_LAB_RELOC_X86_TAIL_STACK 11U''');s=s.replace('case 3: case 4: return 4;','case 3: case 4: case 10: case 11: return 4;');p.write_text(s)
p=Path('kprog/libnativeloader/src/native_loader.cpp');s=p.read_text().replace('return kind == kNativeLabRelocHelperCallRel32;', '''return kind == kNativeLabRelocHelperCallRel32 ||
           kind == NATIVE_LAB_RELOC_X86_TAIL_COUNT || kind == NATIVE_LAB_RELOC_X86_TAIL_STACK;''',1);s=s.replace('    case NATIVE_LAB_RELOC_EXCLUSIVE_FAILURE:\n','    case NATIVE_LAB_RELOC_X86_TAIL_COUNT:\n    case NATIVE_LAB_RELOC_X86_TAIL_STACK:\n    case NATIVE_LAB_RELOC_EXCLUSIVE_FAILURE:\n',1);p.write_text(s)
p=Path('kinsn/module/x86/bpf_x86_native_lab.c');s=p.read_text();anchor='\t\t\t\tcase NATIVE_LAB_RELOC_HELPER_CALL_REL32: {'
add='''				case NATIVE_LAB_RELOC_X86_TAIL_COUNT:
				case NATIVE_LAB_RELOC_X86_TAIL_STACK: {
					u32 depth = prog->aux->priv_stack_ptr ? 0 : round_up(prog->aux->stack_depth, 8);
					s32 value = r->kind == NATIVE_LAB_RELOC_X86_TAIL_COUNT ? -16 - depth : depth;

					memcpy(emit_at + r->offset, &value, sizeof(value));
					break;
				}

'''
assert anchor in s;s=s.replace(anchor,add+anchor,1);p.write_text(s)
p=Path('kprog/x86/native_lab/native_link/src/x86.rs');s=p.read_text()
s=s.replace('const NATIVE_LAB_RELOC_HELPER_POINTER: u32 = 7;', '''const NATIVE_LAB_RELOC_HELPER_POINTER: u32 = 7;
const NATIVE_LAB_RELOC_X86_TAIL_COUNT: u32 = 10;
const NATIVE_LAB_RELOC_X86_TAIL_STACK: u32 = 11;''')
s=s.replace('    HelperDispatch { targets: Vec<(u64, u64)> },','    HelperDispatch { targets: Vec<(u64, u64)> },\n    TailCallFrame { count_offset: usize, stack_offset: usize },',1)
s=s.replace('''                        for ib in build_x86_tail_call_inline(''','''                        let (inline, count_offset, stack_offset) = build_x86_tail_call_inline(''',1)
s=s.replace('''                            entry_abi_strip.tail_call_bpf_rbp_is_live,
                        )? {
                            push_x86_synthetic(''','''                            entry_abi_strip.tail_call_bpf_rbp_is_live,
                        )?;
                        let first = kinds.len();
                        for ib in inline {
                            push_x86_synthetic(''',1)
s=s.replace('''                        resolved_helper_call_sites.insert(site_key);
                        clear_x86_call_clobbered_registers(&mut map_symbol_registers);
                        continue;
                    }
                    if name == "bpf_get_smp_processor_id"''','''                        kinds[first] = Some(PatchKind::TailCallFrame { count_offset, stack_offset });
                        resolved_helper_call_sites.insert(site_key);
                        clear_x86_call_clobbered_registers(&mut map_symbol_registers);
                        continue;
                    }
                    if name == "bpf_get_smp_processor_id"''',1)
s=s.replace('''        match &p.kind {
            PatchKind::HelperPointer''','''        match &p.kind {
            PatchKind::TailCallFrame { count_offset, stack_offset } => {
                for (offset, kind) in [(*count_offset, NATIVE_LAB_RELOC_X86_TAIL_COUNT),
                                       (*stack_offset, NATIVE_LAB_RELOC_X86_TAIL_STACK)] {
                    relocs.push(RelocRecord { offset: u32::try_from(p.global_offset + offset)?,
                        kind, target: 0 });
                }
            }
            PatchKind::HelperPointer''',1)
start=s.index('fn build_x86_tail_call_inline(');end=s.index('\nfn ',start+5);f=s[start:end]
f=f.replace(') -> Result<Vec<Instruction>> {',') -> Result<(Vec<Instruction>, usize, usize)> {',1)
f=f.replace('    bytes.extend_from_slice(&(-16i32).to_le_bytes());','    let count_offset = bytes.len();\n    bytes.extend_from_slice(&(-16i32).to_le_bytes());',1)
f=f.replace('    bytes.extend_from_slice(&[0x58, 0x58]); // pop tail_call_cnt_ptr; pop tail_call_cnt','''    bytes.extend_from_slice(&[0x58, 0x58]); // pop tail_call_cnt_ptr; pop tail_call_cnt
    bytes.extend_from_slice(&[0x48, 0x81, 0xC4]); // add rsp, rounded JIT stack depth
    let stack_offset = bytes.len();
    bytes.extend_from_slice(&0u32.to_le_bytes());''',1)
f=f.replace('    declared_byte_chunks(&bytes)','    Ok((declared_byte_chunks(&bytes)?, count_offset, stack_offset))',1)
s=s[:start]+f+s[end:];p.write_text(s)
