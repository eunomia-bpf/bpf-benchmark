#!/bin/bash
set -e
taskset -pc 8-23 $$ >/dev/null
ulimit -c 0
export TMPDIR=/var/tmp/kprog-tmp/S11
cd /workspaces/repository
O=/var/tmp/kprog-tmp/S11
clang-18 -O2 -g -target bpf -Ivendor/libbpf/include/uapi -Ivendor/libbpf/src -I/usr/include/x86_64-linux-gnu -c kprog/test/tail_call_frame/program.c -o "$O/tail.bpf.o"
cc -c kprog/test/tail_call_frame/native.S -o "$O/tail.native.o"
c++ -std=c++20 -O2 -Wall -Wextra -Werror -Irunner/build-llvmbpf/vendor/libbpf/prefix/include kprog/test/tail_call_frame/client.cpp "$O/loader/libnative_loader.a" runner/build-llvmbpf/vendor/libbpf/pic-obj/libbpf.a -lelf -lz -ldl -pthread -o "$O/tail-client"
