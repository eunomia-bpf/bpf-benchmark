#!/bin/bash
ulimit -c 0
export TMPDIR=/var/tmp/kprog-tmp/S11 PYTHONDONTWRITEBYTECODE=1
export PATH=/usr/lib/llvm-18/bin:/usr/local/cargo/bin:$PATH
cd /workspaces/repository
for arch in x86 arm64; do
 taskset -c 8-23 python3 kprog/run_micro_sim_batch.py --arch "$arch" --build-only --no-generate --no-build-loader --build-dir "/var/tmp/kprog-tmp/S11/micro-$arch" --markdown "/var/tmp/kprog-tmp/S11/micro-$arch.md" --jobs 4 > "/var/tmp/kprog-tmp/S11/micro-$arch.log" 2>&1
 echo $? > "/var/tmp/kprog-tmp/S11/micro-$arch.exit"
done
