#!/bin/bash
set -e
ulimit -c 0
export TMPDIR=/var/tmp/kprog-tmp/S11 PATH=/usr/lib/llvm-18/bin:/usr/local/cargo/bin:$PATH
O=/var/tmp/kprog-tmp/S11
make -C "$O/kernel-src" O="$O/kernel-build" -j8 bzImage
mkdir -p "$O/module"
cp /workspaces/repository/kinsn/module/x86/bpf_x86_native_lab.c "$O/module/"
printf 'ccflags-y += -I/workspaces/repository/kinsn/module/include\nobj-m += bpf_x86_native_lab.o\n' > "$O/module/Makefile"
make -C "$O/kernel-build" M="$O/module" -j4 modules
