#!/bin/bash
ulimit -c 0
export TMPDIR=/var/tmp/kprog-tmp/S11 CARGO_TARGET_DIR=/var/tmp/kprog-tmp/S11/cargo KPROG_TAIL_TEST_OUTPUT=/var/tmp/kprog-tmp/S11
export PATH=/usr/local/cargo/bin:$PATH
cd /workspaces/repository
taskset -c 8-23 cargo test --manifest-path kprog/x86/native_lab/native_link/Cargo.toml tail_call_frame > /var/tmp/kprog-tmp/S11/tail-test.log 2>&1
echo $? > /var/tmp/kprog-tmp/S11/tail-test.exit
