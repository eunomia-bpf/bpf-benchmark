from pathlib import Path
import os,selectors
try:
 fd=os.pidfd_open(3111026);s=selectors.DefaultSelector();s.register(fd,selectors.EVENT_READ);s.select();os.close(fd)
except ProcessLookupError:pass
Path('/var/tmp/kprog-tmp/S11/safety-arm64/runtime/compiler/STOP').touch()
