from pathlib import Path
import subprocess,os
R=Path('/workspaces/repository');O=Path('/var/tmp/kprog-tmp/S11')
for p in (O/'micro-source').rglob('*'):
 if p.is_file():subprocess.run(['mount','--bind',str(p),str(R/p.relative_to(O/'micro-source'))],check=True)
for arch in ['x86','arm64']:
 with (O/f'micro-{arch}-final.log').open('w') as log:
  x=subprocess.run(['python3',str(R/'kprog/run_micro_sim_batch.py'),'--arch',arch,'--build-only','--no-generate','--no-build-loader','--build-dir',str(O/f'micro-{arch}-final'),'--markdown',str(O/f'micro-{arch}-final.md'),'--jobs','2'],stdout=log,stderr=subprocess.STDOUT)
 (O/f'micro-{arch}-final.exit').write_text(str(x.returncode)+'\n')
