from pathlib import Path
import subprocess,sys
R=Path('/workspaces/repository');O=Path('/var/tmp/kprog-tmp/S11')
pairs=[(O/'safety-arm64',R/'kprog/results/kprog_fidelity_20261107/negative/arm64-trusted-sp'),(O/'build-arm64',R/'kprog/formal/build/fidelity-trusted-arm64'),(O/'transport-arm-final',R/'kprog/arm64/build/trusted-transport')]
stage=R/'kprog/arm64/build/native-load-recovery/recovery'
for name in ['libnative_loader.so','trusted-native-loader','trusted-service-client']:
 dst=R/'kprog/libnativeloader/build-arm64-a-map-order-v3'/name
 if dst.exists():pairs.append((stage/name,dst))
for src,dst in pairs:subprocess.run(['mount','--bind',str(src),str(dst)],check=True)
script=R/'kprog/results/kprog_fidelity_20261107/negative/arm64-trusted-sp/s11.py'
subprocess.run(['python3',str(script),'build'],check=True)
subprocess.run(['python3',str(script),'host'],check=True)
