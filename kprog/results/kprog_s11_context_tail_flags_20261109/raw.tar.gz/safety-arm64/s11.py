from pathlib import Path
import sys,importlib.util,json,os
R=Path('/workspaces/repository'); O=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('s11base',O/'_base_check.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
ARCH='arm64'
os.environ['LD_LIBRARY_PATH']='/workspaces/repository/kprog/libnativeloader/build-arm64-a-map-order-v3'
m.ARCH=ARCH;m.OUT=O;m.BUILD=R/('kprog/formal/build/fidelity-trusted'+('-arm64' if ARCH=='arm64' else ''))
if ARCH=='arm64':
 positives={'valid_control':'mov w0,#2; ret','valid_copy_restore':'mov x1,sp; mov sp,x1; mov w0,#2; ret','valid_alias_load':'sub sp,sp,#16; mov x1,#37; str x1,[sp]; mov x2,sp; ldr x3,[x2]; add sp,sp,#16; cmp x3,#37; b.ne 1f; mov w0,#2; ret; 1: mov w0,#0; ret','valid_spill_restore':'sub sp,sp,#32; add x1,sp,#16; str x1,[sp]; ldr x1,[sp]; mov sp,x1; add sp,sp,#16; mov w0,#2; ret'}
 m.cases=lambda:[dict(name=n,assembly=a,negative=False) for n,a in positives.items()]+[dict(name=n,assembly=a,negative=True) for n,a in m.fixtures.FIXTURES[ARCH].items()]
if sys.argv[1]=='build':m.build()
elif sys.argv[1]=='guest':
 live=Path(sys.argv[2]); selected=json.loads((O/'cases.json').read_text());(live/'cases.json').write_text(json.dumps(selected));m.cases=lambda:selected;m.OUT=live
 try:m.check()
 finally:
  p=live/'outcomes.json';rows=json.loads(p.read_text()) if p.exists() else []
  (live/'guest.json').write_text(json.dumps(dict(ok=len(rows)==len(selected) and all(x['stage'] in ['valid_executed','verifier_rejected','specialization_rejected','loader_rejected','compiler_rejected'] for x in rows),cases=len(rows),accepted_unsafe=sum(x['stage']=='accepted_finding' for x in rows)),indent=2))
elif sys.argv[1]=='host':
 text=Path('/var/tmp/kprog-tmp/S11/transport-fast.py').read_text()
 ns={'__name__':'s11_transport','__file__':__file__}
 exec(compile(text,'/var/tmp/kprog-tmp/S11/transport-fast.py','exec'),ns)
 ns.update(ROOT=R,HERE=O,__file__=__file__,NATIVE_LINK=m.native_link(),LOADER=m.loader_build())
 ns['host'].__globals__.update(ns);ns['host']()
