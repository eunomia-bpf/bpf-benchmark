from pathlib import Path
import json,subprocess
R=Path('/workspaces/repository');O=Path('/var/tmp/kprog-tmp/S11')
for arch in ['x86','arm64']:
 p=O/'micro-source'/f'kprog/{arch}/{arch}_sim_local_bpf.h'
 subprocess.run(['mount','--bind',str(p),str(R/f'kprog/{arch}/{arch}_sim_local_bpf.h')],check=True)
 command=json.loads((O/f'micro-{arch}-final/simple.compile.json').read_text())['command']
 command[command.index('-c')+1]=str(R/f'kprog/{arch}/micro-prog/unchecked_packet_read.bpf.c')
 command[command.index('-o')+1]=str(O/f'micro-{arch}-final/unchecked_packet_read.bpf.o')
 result=subprocess.run(command,capture_output=True,text=True)
 (O/f'micro-{arch}-negative.json').write_text(json.dumps(dict(command=command,exit=result.returncode,stdout=result.stdout,stderr=result.stderr),indent=2)+'\n')
 print(arch,'unchecked read compile',result.returncode,flush=True)
