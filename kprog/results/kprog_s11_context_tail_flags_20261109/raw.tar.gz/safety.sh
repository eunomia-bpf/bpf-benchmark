#!/bin/bash
ulimit -c 0
export TMPDIR=/var/tmp/kprog-tmp/S11 PYTHONDONTWRITEBYTECODE=1 PATH=/usr/lib/llvm-18/bin:/usr/local/cargo/bin:$PATH
cd /workspaces/repository
unshare --mount --propagation private taskset -c 8-23 python3 /var/tmp/kprog-tmp/S11/safety-inside.py >/var/tmp/kprog-tmp/S11/safety.log 2>&1
echo $? >/var/tmp/kprog-tmp/S11/safety.exit
