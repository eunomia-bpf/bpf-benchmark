from pathlib import Path
import subprocess,sys,os,selectors,shutil
R=Path('/workspaces/repository');O=Path('/var/tmp/kprog-tmp/S11')
for arch in ['x86','arm64']:
 dest=R/'kprog/results/kprog_fidelity_20261107/negative'/('x86-trusted-sp' if arch=='x86' else 'arm64-trusted-sp')
 subprocess.run(['mount','--bind',str(O/('safety-'+arch)),str(dest)],check=True)
 subprocess.run(['mount','--bind',str(O/('build-'+arch)),str(R/('kprog/formal/build/fidelity-trusted'+('-arm64' if arch=='arm64' else '')))],check=True)
# The x86 compile and guest both use this lane's linker and loader.
subprocess.run(['mount','--bind',str(O/'loader'),str(R/'kprog/libnativeloader/build')],check=True)
subprocess.run(['mount','--bind',str(O/'cargo/release/native-link'),str(R/'kprog/x86/native_lab/native_link/target/release/native-link')],check=True)
for arch in ['x86','arm64']:
 dest=R/'kprog/results/kprog_fidelity_20261107/negative'/('x86-trusted-sp' if arch=='x86' else 'arm64-trusted-sp')
 subprocess.run(['python3',str(dest/'s11.py'),'build'],check=True)
assert (O/'kernel-resume.exit').read_text().strip()=='0'
subprocess.run(['mount','--bind',str(O/'module/bpf_x86_native_lab.ko'),str(R/'kprog/tv/build-x86/bpf_x86_native_lab.ko')],check=True)
out=R/'kprog/results/kprog_fidelity_20261107/negative/x86-trusted-sp'
(out/'run').mkdir(exist_ok=True)
tc=out/'tc';tc.mkdir(exist_ok=True)
for name in ['tail-client','tail.bpf.o','tail.native.o','guest-tc.py']:shutil.copyfile(O/name,tc/name)
(tc/'tail-client').chmod(0o755)
cmd='cd /workspaces/repository && (mountpoint -q /sys/kernel/debug || mount -t debugfs debugfs /sys/kernel/debug) && insmod /workspaces/repository/kprog/tv/build-x86/bpf_x86_native_lab.ko; PATH=/usr/lib/llvm-18/bin:$PATH python3 '+str(out/'s11.py')+' guest '+str(out/'run')+'; a=$?; PATH=/usr/lib/llvm-18/bin:$PATH python3 '+str(tc/'guest-tc.py')+'; b=$?; echo "$a $b" > '+str(out/'guest-exits.txt')+'; test "$a $b" = "0 0"'
x86=subprocess.run(['taskset','-c','20-23','vng','--run',str(O/'kernel-build/arch/x86/boot/bzImage'),'--cwd',str(R),'--rwdir',str(R),'--overlay-rwdir','/tmp','--disable-monitor','--cpus','2','--memory','2G','--append','loglevel=4 panic=30 oops=panic','--exec',cmd])
(O/'safety-x86-final.exit').write_text(str(x86.returncode)+'\n')
