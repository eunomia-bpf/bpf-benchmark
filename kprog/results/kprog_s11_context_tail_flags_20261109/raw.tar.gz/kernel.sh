#!/bin/bash
set -e
ulimit -c 0
export TMPDIR=/var/tmp/kprog-tmp/S11
export PATH=/usr/lib/llvm-18/bin:/usr/local/cargo/bin:$PATH
R=/workspaces/repository
O=/var/tmp/kprog-tmp/S11
cp -a --reflink=auto "$R/vendor/linux-framework" "$O/kernel-src"
cp -a --reflink=auto "$R/kprog/tv/build-kernel-x86" "$O/kernel-build"
python3 - <<'PY'
from pathlib import Path
p=Path('/var/tmp/kprog-tmp/S11/kernel-src/kernel/bpf/verifier.c')
s=p.read_text();patch=Path('/workspaces/repository/kprog/tv/native-proof-regions.patch').read_text()
lines=patch.splitlines();a=lines.index('+static void retain_kinsn_proof_flags(struct bpf_verifier_env *env)')
b=next(i for i in range(a,len(lines)) if lines[i].startswith(' static int restore_kinsn_proof_regions'))
f='\n'.join(x[1:] for x in lines[a:b] if x.startswith('+'))+'\n'
assert 'retain_kinsn_proof_flags' not in s
s=s.replace('static int restore_kinsn_proof_regions(',f+'static int restore_kinsn_proof_regions(',1)
a=s.index('static int restore_kinsn_proof_regions(');pos=s.index('\tu32 i;\n',a)+len('\tu32 i;\n');s=s[:pos]+'\n\tretain_kinsn_proof_flags(env);\n'+s[pos:];p.write_text(s)
# Point this private output tree at its private source.
p=Path('/var/tmp/kprog-tmp/S11/kernel-build/source')
if p.is_symlink():p.unlink();p.symlink_to('/var/tmp/kprog-tmp/S11/kernel-src')
PY
taskset -c 8-23 make -C "$O/kernel-src" O="$O/kernel-build" -j8 bzImage
mkdir -p "$O/module"
cp "$R/kinsn/module/x86/bpf_x86_native_lab.c" "$O/module/"
printf 'ccflags-y += -I%s/kinsn/module/include\nobj-m += bpf_x86_native_lab.o\n' "$R" > "$O/module/Makefile"
taskset -c 8-23 make -C "$O/kernel-build" M="$O/module" -j4 modules
