from pathlib import Path
import re
p=Path('kprog/tv/native-proof-regions.patch');s=p.read_text()
start=s.index('@@ -3866,20 +3817,6 @@');end=s.index('\n@@',start+2)
h=s[start:end]
new='''static void retain_kinsn_proof_flags(struct bpf_verifier_env *env)
{
	struct bpf_prog *prog = env->prog;
	u32 i, j;

	for (i = 0; i < env->kinsn_region_cnt; i++) {
		const struct bpf_kinsn_region *r = &env->kinsn_regions[i];

		if (!r->kinsn->native_proof)
			continue;
		for (j = r->start; j < r->start + r->proof_len; j++) {
			struct bpf_insn si = prog->insnsi[j];
			const struct bpf_insn_aux_data *aux = &env->insn_aux_data[j];

			if (!aux->seen)
				continue;
			if (si.code == (BPF_JMP | BPF_CALL) && !si.src_reg) {
				if (si.imm == BPF_FUNC_get_route_realm)
					prog->dst_needed = 1;
				if (si.imm == BPF_FUNC_get_prandom_u32)
					bpf_user_rnd_init_once();
				if (si.imm == BPF_FUNC_override_return)
					prog->kprobe_override = 1;
				if (si.imm == BPF_FUNC_tail_call) {
					prog->cb_access = 1;
					prog->aux->max_pkt_offset = MAX_PACKET_OFF;
					if (!prog->jit_requested || !bpf_jit_supports_subprog_tailcalls())
						env->subprog_info[0].stack_depth = MAX_BPF_STACK;
				}
			} else if (aux->ptr_type == PTR_TO_CTX && env->ops->convert_ctx_access &&
				   BPF_MODE(si.code) == BPF_MEM &&
				   (BPF_CLASS(si.code) == BPF_LDX ||
				    BPF_CLASS(si.code) == BPF_ST || BPF_CLASS(si.code) == BPF_STX)) {
				struct bpf_insn insn_buf[16];
				u32 target_size = 0;
				enum bpf_access_type type = BPF_CLASS(si.code) == BPF_LDX ? BPF_READ : BPF_WRITE;

				/* Retain callback effects with the stock narrow-load normalization. */
				if (BPF_LDST_BYTES(&si) < aux->ctx_field_size) {
					si.off &= ~(bpf_ctx_off_adjust_machine(aux->ctx_field_size) - 1);
					si.code = BPF_LDX | BPF_MEM | (aux->ctx_field_size == 8 ? BPF_DW :
						aux->ctx_field_size == 4 ? BPF_W : BPF_H);
				}
				env->ops->convert_ctx_access(type, &si, insn_buf, prog, &target_size);
			}
		}
	}
}

'''
h=h.replace(' static int restore_kinsn_proof_regions', ''.join('+'+x+'\n' for x in new.splitlines())+' static int restore_kinsn_proof_regions',1)
h=h.replace(' \tu32 i;\n',' \tu32 i;\n+\n+\tretain_kinsn_proof_flags(env);\n',1)
lines=h.splitlines();old=sum(x.startswith((' ','-')) for x in lines[1:]);newcount=sum(x.startswith((' ','+')) for x in lines[1:]);lines[0]=f'@@ -3866,{old} +3817,{newcount} @@'
s=s[:start]+'\n'.join(lines)+s[end:];p.write_text(s)
