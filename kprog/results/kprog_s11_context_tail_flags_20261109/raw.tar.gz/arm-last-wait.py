import os,selectors,subprocess
from pathlib import Path
O=Path('/var/tmp/kprog-tmp/S11')
try:
 fd=os.pidfd_open(3119411);s=selectors.DefaultSelector();s.register(fd,selectors.EVENT_READ);s.select();os.close(fd)
except ProcessLookupError:pass
with (O/'safety-arm-paired.log').open('w') as log:
 x=subprocess.run(['unshare','--mount','--propagation','private','python3',str(O/'arm-inside.py')],stdout=log,stderr=subprocess.STDOUT)
(O/'safety-arm-paired.exit').write_text(str(x.returncode)+'\n')
