from pathlib import Path
import collections,csv,difflib,gzip,hashlib,json,subprocess,tarfile
R=Path('/workspaces/repository');O=Path('/var/tmp/kprog-tmp/S11');D=R/'kprog/results/kprog_s11_context_tail_flags_20261109'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def exitcode(name):return int((O/name).read_text().strip())
assert exitcode('kernel-resume.exit')==0
assert exitcode('rust-final.exit')==0
assert exitcode('loader-final.exit')==0
assert exitcode('tc-guest.exit')==0
micro={}
for arch in ['x86','arm64']:
 assert exitcode(f'micro-{arch}-final.exit')==0
 meta=list((O/f'micro-{arch}-final').glob('*.compile.json'))
 neg=json.loads((O/f'micro-{arch}-negative.json').read_text());assert neg['exit']==0
 micro[arch]=dict(positive_compiles=len(meta),unchecked_read_compile=1,total_compiles=len(meta)+1)
 assert micro[arch]['total_compiles']==30
xrows=json.loads((O/'safety-x86/run/outcomes.json').read_text())
armdir=O/'safety-arm64/trusted-arm64-service-result';arm=json.loads((armdir/'summary.json').read_text())
with tarfile.open(armdir/arm['archive']) as t:
 names=[m for m in t if m.name.endswith('/outcomes.json')]
 arows=json.loads(t.extractfile(names[0]).read())
assert len(arows)==38
safety={a:dict(cases=len(rows),outcomes=dict(collections.Counter(x['stage'] for x in rows)),findings=[dict(name=x['name'],stage=x['stage']) for x in rows if x['stage'] in ['accepted_finding','positive_infrastructure_error']],unsafe_executions=sum(bool(x.get('unsafe_native_executed')) for x in rows)) for a,rows in [('x86',xrows),('arm64',arows)]}
tc=[json.loads(s) for s in (O/'safety-x86/tc/client.stdout').read_text().splitlines()]
assert tc[0]['jit_stack_depth']>0 and tc[0]['jit_stack_pop']==tc[0]['jit_stack_depth']
assert all(x['invocations']==34 and x['tail_transfers']==33 and x['retval']==2 for x in tc[1:])
prod=['kprog/trusted_generation.py','kprog/x86/trusted_specializer.py','kprog/arm64/trusted_specializer.py','kprog/tv/native-proof-regions.patch','kprog/x86/native_lab/native_link/src/x86.rs','kprog/libnativeloader/src/native_loader.cpp','kinsn/module/include/native_lab_binding.h','kinsn/module/x86/bpf_x86_native_lab.c']
source={p:sha(R/p) for p in prod}
source.update({str(p.relative_to(O)):sha(p) for p in [O/'kernel-src/kernel/bpf/verifier.c',O/'kernel-build/.config',O/'kernel-build/arch/x86/boot/bzImage',O/'module/bpf_x86_native_lab.ko',O/'cargo/release/native-link',O/'loader/trusted-native-loader']})
(D/'source-identities.json').write_text(json.dumps(source,indent=2)+'\n')
summary=dict(context=dict(typed_types=[3,6,8],raw_identity_types=[2,5,15,17,20,24,26,27,28,29,31,32],typed_handler_required=[1,4,7,9,10,11,12,13,14,16,18,19,21,22,23,25,30]),tail=dict(host_executions=195,depths_tested=13,relocation_depths=513,saved_rbp_forms=2,tc=tc),flags=dict(host_regression='PASS',kernel_patch_reapply='PASS',private_kernel_build=0,paired_module_build=0),micro=micro,safety=safety,rust_tests=91,service_tests=9,production_commits=['901194c0c','b1be661ee','64ca0ff0a'],proposal_commit='b62382b24',remaining=['S7, S10 and C own the named safety-suite model findings and saved-register/context-spill precision diagnostics.','V and S13 compose universal producer/JIT/entry and successful tail-transfer obligations.','The coordinator selects SIMD ownership and indirect-branch integration from the published cost proposal.'])
# Preserve both initial transport diagnostics and final compiler/runtime receipts.
raw=O/'raw-small';raw.mkdir(exist_ok=True)
base=subprocess.run(['git','show','HEAD:kernel/bpf/verifier.c'],cwd=R/'vendor/linux-framework',capture_output=True,text=True,check=True).stdout
(raw/'kernel-verifier.patch').write_text(''.join(difflib.unified_diff(base.splitlines(True),(O/'kernel-src/kernel/bpf/verifier.c').read_text().splitlines(True),fromfile='a/kernel/bpf/verifier.c',tofile='b/kernel/bpf/verifier.c')))
(raw/'kernel.config.gz').write_bytes(gzip.compress((O/'kernel-build/.config').read_bytes()))
items=[p for p in O.iterdir() if p.is_file() and p.suffix in ['.log','.json','.txt','.sh','.py','.mk','.exit','.tsv']]
items += [O/'safety-x86',O/'safety-arm64',O/'raw-small',O/'proposals',O/'micro-source']
items += list((O/'micro-x86-final').glob('*.compile.json'))+list((O/'micro-arm64-final').glob('*.compile.json'))
manifest=[]
archive=D/'raw.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for top in items:
  files=[top] if top.is_file() else [p for p in top.rglob('*') if p.is_file() and not p.is_symlink()]
  for p in files:
   if p.name in ['tail-client','bound-probe'] or p.suffix in ['.o','.ko','.bin'] or p.name.startswith('libnative'):continue
   name=str(p.relative_to(O));t.add(p,arcname=name,recursive=False);manifest.append(dict(path=name,size=p.stat().st_size,sha256=sha(p)))
(D/'raw-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
summary['raw_archive']=dict(file=archive.name,size=archive.stat().st_size,sha256=sha(archive),entries=len(manifest))
(D/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
text=f'''# Context layouts, tail frames and verifier flags

S11, 2026-11-09. Context generation, actual x86 tail frames and stock rewrite
flags are implemented through the existing trusted service and same-copy JIT
relocation path. The stock verifier checks B. Universal B/P correspondence
remains the shared proof contract.

Context dispatch (901194c0c) retains 3 typed handlers and 12 identity-layout RAW
types. The other 17 context families report a typed generation-handler
requirement. `context-layouts.json` records all 32 kernel context declarations
and converter tables for x86-64 and ARM64. The 32-type test also checks both
specializer call sites.

Flag retention (b1be661ee) visits seen B instructions before restore. It retains
route-destination use, prandom initialization, kprobe override, tail-call cb and
packet extent, and the stock context converter's effects. Narrow loads receive
the stock normalization in the temporary callback input. The executable helper/
callback regression, complete patch application/reapplication/conflict test,
private kernel and paired module build all pass. The final physical ARM kernel
flag integration follows the same shared C patch through the kernel owner.

The x86 tail linker emits two frame relocations: counter displacement
`-16 - round_up(stack_depth,8)` and the matching successful-transfer stack pop.
The kernel emitter uses depth zero with the actual JIT private stack, matching
the stock JIT. The native cleanup and callee-save pops retain their order.
The fixed text adds one seven-byte ADD on successful transfer and two 16-byte
relocation records per lowered tail site.

The Rust producer tests pass 91 cases. Actual emitted code passes 195 userspace
frame executions across 13 stack depths and the populated/empty/index routes;
relocation tests cover all 513 depths from 0 through 512 and both RBP forms.
The real tc test uses an allocated native stack and measures a JIT stack of
{tc[0]['jit_stack_depth']} bytes. Stock and native each return 2 after 34 invocations,
which is 33 tail transfers. The C-produced test's original RET/RBX verifier
diagnostic is retained alongside the caller-register-only assembly test.
S7 owns the general saved-register precision interface exposed by that input.

Final micro compilation: x86 30/30 and ARM64 30/30 (29 positive objects and the
unchecked-read object on each ISA). The captured-source repeat preserves the
initial two x86 Clang SIGBUS diagnostics. Service component tests pass 9/9.
The guest runtime uses one 2 GiB guest at a time and CPU set 8-23. ARM's initial
transport records retain the historical static-library activation diagnosis;
its successor uses the paired loader. Its remaining B compilation uses the
existing host compiler protocol in the private guest namespace.

Safety suites complete: x86 {len(xrows)} cases, {safety['x86']['outcomes']}; ARM64
{len(arows)} cases, {safety['arm64']['outcomes']}. Every negative case stays load-only.
`summary.json` names each finding and preserves the actual outcomes. S7/S10/C own the named
model, stack/ABI and context-spill findings. The current tail-frame and flag
results retain those suite findings as separate evidence. Shared model owners
continue their stack/ABI edits during the suite; every service request records
its actual source identities. The archive preserves the frozen micro source
snapshot and the observed service/compiler/runtime transitions.

The SIMD and branch-hardening proposal, benign emitted-code fixtures, storage/
text costs and engineering estimates are published in `proposals.md`.
V/S13 own the universal source/compiler/physical entry and successful transfer
composition. The coordinator decides reuse of the existing exit predicate at
the successful tail-helper boundary and selects SIMD and branch integration.
The benchmark workload and paper sources retain their frozen ownership.

`raw.tar.gz` contains the commands, source identities, compiler results, host
results, guest service archives and initial diagnostics. `raw-manifest.json`
records each exported file's size and SHA256. Large private outputs retire after
publication and independent archive readback.
'''
(D/'README.md').write_text(text)
print(json.dumps(summary,indent=2))
