from pathlib import Path
import os,subprocess,json
R=Path('/workspaces/repository');O=Path('/var/tmp/kprog-tmp/S11')
visible=R/'kprog/results/kprog_fidelity_20261107/negative/arm64-trusted-sp/runtime'
visible.mkdir(exist_ok=True)
original=visible/'runner-original';original.mkdir(exist_ok=True)
overlay=visible/'runner-overlay';overlay.mkdir(exist_ok=True)
subprocess.run(['mount','--bind',str(R/'runner/build-arm64-llvmbpf'),str(original)],check=True)
for p in original.iterdir():
 dest=overlay/p.name
 if not dest.exists():dest.symlink_to(p)
broker=visible/'compiler';broker.mkdir(exist_ok=True)
wrapper=overlay/'clang'
if wrapper.is_symlink():wrapper.unlink()
wrapper.write_text('''#!/usr/bin/python3
import subprocess,sys
from pathlib import Path
args=sys.argv[1:]
source=args[args.index('-c')+1];output=args[args.index('-o')+1]
raise SystemExit(subprocess.run([sys.executable,'/workspaces/repository/kprog/trusted_compile.py','submit','--state','''+repr(str(broker))+''','--source',source,'--output',output,'--arch','arm64']).returncode)
''');wrapper.chmod(0o755)
log=(visible/'compiler.log').open('w')
server=subprocess.Popen(['taskset','-c','8-23','python3',str(R/'kprog/trusted_compile.py'),'serve','--scope',str(R),'--state',str(broker),'--clang','clang-18','--arm64-sysroot',str(R/'.cache/aarch64-sysroot')],stdout=log,stderr=subprocess.STDOUT,start_new_session=True,env=dict(os.environ,TMPDIR=str(O)))
(visible/'host-compile.json').write_text(json.dumps(dict(pid=server.pid,compiler='clang-18',sysroot=str(R/'.cache/aarch64-sysroot'),transition='remaining B compilations use the existing host compiler protocol'),indent=2)+'\n')
subprocess.run(['mount','--bind',str(overlay),str(R/'runner/build-arm64-llvmbpf')],check=True)
print('host compiler',server.pid,flush=True)
