from pathlib import Path
import subprocess,shutil
R=Path('/workspaces/repository');O=Path('/var/tmp/kprog-tmp/S11')
pairs=[(O/'loader',R/'kprog/libnativeloader/build'),(O/'cargo/release/native-link',R/'kprog/x86/native_lab/native_link/target/release/native-link'),(O/'module/bpf_x86_native_lab.ko',R/'kprog/tv/build-x86/bpf_x86_native_lab.ko'),(O/'safety-x86',R/'kprog/results/kprog_fidelity_20261107/negative/x86-trusted-sp')]
for src,dst in pairs:subprocess.run(['mount','--bind',str(src),str(dst)],check=True)
out=R/'kprog/results/kprog_fidelity_20261107/negative/x86-trusted-sp'
tc=out/'tc'
if tc.exists():tc.rename(out/'tc-direct-image-query')
tc.mkdir()
for name in ['tail-client','tail.bpf.o','tail.native.o','guest-tc.py']:shutil.copyfile(O/name,tc/name)
(tc/'tail-client').chmod(0o755)
cmd='cd /workspaces/repository && (mountpoint -q /sys/kernel/debug || mount -t debugfs debugfs /sys/kernel/debug) && insmod kprog/tv/build-x86/bpf_x86_native_lab.ko && PATH=/usr/lib/llvm-18/bin:$PATH python3 '+str(tc/'guest-tc.py')
x=subprocess.run(['vng','--run',str(O/'kernel-build/arch/x86/boot/bzImage'),'--cwd',str(R),'--rwdir',str(R),'--overlay-rwdir','/tmp','--disable-monitor','--cpus','2','--memory','2G','--append','loglevel=4 panic=30 oops=panic','--exec',cmd])
(O/'tc-guest.exit').write_text(str(x.returncode)+'\n')
