import os,selectors,subprocess
from pathlib import Path
O=Path('/var/tmp/kprog-tmp/S11')
try:
 fd=os.pidfd_open(3158265);s=selectors.DefaultSelector();s.register(fd,selectors.EVENT_READ);s.select();os.close(fd)
except ProcessLookupError:pass
with (O/'report.log').open('w') as log:
 x=subprocess.run(['python3',str(O/'report.py')],stdout=log,stderr=subprocess.STDOUT)
(O/'report.exit').write_text(str(x.returncode)+'\n')
