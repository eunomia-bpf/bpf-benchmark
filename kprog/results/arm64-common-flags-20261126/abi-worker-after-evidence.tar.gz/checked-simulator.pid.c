extern unsigned long long __kprog_bpf_get_current_task(void) __asm__("bpf_get_current_task");
__attribute__((always_inline))
unsigned long long (bpf_get_current_pid_tgid)(void) {
    const char *task = (const char *)(unsigned long)__kprog_bpf_get_current_task();
    if (!task) return (unsigned long long)-22;
    return (unsigned long long)*(const int *)(task + (2260)) << 32 |
           *(const int *)(task + (2256));
}
