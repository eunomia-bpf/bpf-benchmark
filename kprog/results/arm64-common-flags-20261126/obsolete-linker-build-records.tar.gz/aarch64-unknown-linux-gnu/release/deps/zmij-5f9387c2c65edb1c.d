/workspaces/repository/kprog/arm64/build/app-native-link/aarch64-unknown-linux-gnu/release/deps/zmij-5f9387c2c65edb1c.d: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/zmij-1.0.21/src/lib.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/zmij-1.0.21/src/traits.rs

/workspaces/repository/kprog/arm64/build/app-native-link/aarch64-unknown-linux-gnu/release/deps/libzmij-5f9387c2c65edb1c.rlib: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/zmij-1.0.21/src/lib.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/zmij-1.0.21/src/traits.rs

/workspaces/repository/kprog/arm64/build/app-native-link/aarch64-unknown-linux-gnu/release/deps/libzmij-5f9387c2c65edb1c.rmeta: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/zmij-1.0.21/src/lib.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/zmij-1.0.21/src/traits.rs

/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/zmij-1.0.21/src/lib.rs:
/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/zmij-1.0.21/src/traits.rs:
