/workspaces/repository/kprog/arm64/build/app-native-link/aarch64-unknown-linux-gnu/release/deps/anstyle_query-5f6588979c45d338.d: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/anstyle-query-1.1.5/src/lib.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/anstyle-query-1.1.5/src/windows.rs

/workspaces/repository/kprog/arm64/build/app-native-link/aarch64-unknown-linux-gnu/release/deps/libanstyle_query-5f6588979c45d338.rlib: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/anstyle-query-1.1.5/src/lib.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/anstyle-query-1.1.5/src/windows.rs

/workspaces/repository/kprog/arm64/build/app-native-link/aarch64-unknown-linux-gnu/release/deps/libanstyle_query-5f6588979c45d338.rmeta: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/anstyle-query-1.1.5/src/lib.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/anstyle-query-1.1.5/src/windows.rs

/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/anstyle-query-1.1.5/src/lib.rs:
/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/anstyle-query-1.1.5/src/windows.rs:
