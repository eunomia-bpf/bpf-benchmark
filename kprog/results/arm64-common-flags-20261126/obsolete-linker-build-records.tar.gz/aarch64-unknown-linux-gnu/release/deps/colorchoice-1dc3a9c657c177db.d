/workspaces/repository/kprog/arm64/build/app-native-link/aarch64-unknown-linux-gnu/release/deps/colorchoice-1dc3a9c657c177db.d: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/colorchoice-1.0.5/src/lib.rs

/workspaces/repository/kprog/arm64/build/app-native-link/aarch64-unknown-linux-gnu/release/deps/libcolorchoice-1dc3a9c657c177db.rlib: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/colorchoice-1.0.5/src/lib.rs

/workspaces/repository/kprog/arm64/build/app-native-link/aarch64-unknown-linux-gnu/release/deps/libcolorchoice-1dc3a9c657c177db.rmeta: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/colorchoice-1.0.5/src/lib.rs

/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/colorchoice-1.0.5/src/lib.rs:
