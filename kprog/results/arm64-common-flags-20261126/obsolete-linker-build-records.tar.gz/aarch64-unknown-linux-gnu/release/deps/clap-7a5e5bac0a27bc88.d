/workspaces/repository/kprog/arm64/build/app-native-link/aarch64-unknown-linux-gnu/release/deps/clap-7a5e5bac0a27bc88.d: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.1/src/lib.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.1/src/../examples/demo.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.1/src/../examples/demo.md

/workspaces/repository/kprog/arm64/build/app-native-link/aarch64-unknown-linux-gnu/release/deps/libclap-7a5e5bac0a27bc88.rlib: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.1/src/lib.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.1/src/../examples/demo.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.1/src/../examples/demo.md

/workspaces/repository/kprog/arm64/build/app-native-link/aarch64-unknown-linux-gnu/release/deps/libclap-7a5e5bac0a27bc88.rmeta: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.1/src/lib.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.1/src/../examples/demo.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.1/src/../examples/demo.md

/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.1/src/lib.rs:
/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.1/src/../examples/demo.rs:
/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.1/src/../examples/demo.md:
