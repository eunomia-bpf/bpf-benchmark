/workspaces/repository/kprog/arm64/build/app-native-link/aarch64-unknown-linux-gnu/release/deps/native_link-40f52e836c3328eb.d: src/main.rs src/x86.rs

/workspaces/repository/kprog/arm64/build/app-native-link/aarch64-unknown-linux-gnu/release/deps/native_link-40f52e836c3328eb: src/main.rs src/x86.rs

src/main.rs:
src/x86.rs:

# env-dep:CARGO_PKG_NAME=native-link
