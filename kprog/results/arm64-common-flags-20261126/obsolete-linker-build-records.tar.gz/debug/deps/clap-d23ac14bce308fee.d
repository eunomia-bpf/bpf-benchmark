/workspaces/repository/kprog/arm64/build/app-native-link/debug/deps/clap-d23ac14bce308fee.d: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.1/src/lib.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.1/src/../examples/demo.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.1/src/../examples/demo.md

/workspaces/repository/kprog/arm64/build/app-native-link/debug/deps/libclap-d23ac14bce308fee.rlib: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.1/src/lib.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.1/src/../examples/demo.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.1/src/../examples/demo.md

/workspaces/repository/kprog/arm64/build/app-native-link/debug/deps/libclap-d23ac14bce308fee.rmeta: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.1/src/lib.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.1/src/../examples/demo.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.1/src/../examples/demo.md

/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.1/src/lib.rs:
/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.1/src/../examples/demo.rs:
/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.1/src/../examples/demo.md:
