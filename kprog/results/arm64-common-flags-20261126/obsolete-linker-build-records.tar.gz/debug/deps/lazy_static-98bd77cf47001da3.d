/workspaces/repository/kprog/arm64/build/app-native-link/debug/deps/lazy_static-98bd77cf47001da3.d: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/lazy_static-1.5.0/src/lib.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/lazy_static-1.5.0/src/inline_lazy.rs

/workspaces/repository/kprog/arm64/build/app-native-link/debug/deps/liblazy_static-98bd77cf47001da3.rlib: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/lazy_static-1.5.0/src/lib.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/lazy_static-1.5.0/src/inline_lazy.rs

/workspaces/repository/kprog/arm64/build/app-native-link/debug/deps/liblazy_static-98bd77cf47001da3.rmeta: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/lazy_static-1.5.0/src/lib.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/lazy_static-1.5.0/src/inline_lazy.rs

/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/lazy_static-1.5.0/src/lib.rs:
/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/lazy_static-1.5.0/src/inline_lazy.rs:
