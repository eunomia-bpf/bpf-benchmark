/workspaces/repository/kprog/arm64/build/app-native-link/debug/deps/colorchoice-ae9bb2491751696b.d: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/colorchoice-1.0.5/src/lib.rs

/workspaces/repository/kprog/arm64/build/app-native-link/debug/deps/libcolorchoice-ae9bb2491751696b.rlib: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/colorchoice-1.0.5/src/lib.rs

/workspaces/repository/kprog/arm64/build/app-native-link/debug/deps/libcolorchoice-ae9bb2491751696b.rmeta: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/colorchoice-1.0.5/src/lib.rs

/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/colorchoice-1.0.5/src/lib.rs:
