/workspaces/repository/kprog/arm64/build/app-native-link/debug/deps/native_link-47f135697fa1259b.d: src/main.rs src/x86.rs

/workspaces/repository/kprog/arm64/build/app-native-link/debug/deps/native_link-47f135697fa1259b: src/main.rs src/x86.rs

src/main.rs:
src/x86.rs:

# env-dep:CARGO_PKG_NAME=native-link
