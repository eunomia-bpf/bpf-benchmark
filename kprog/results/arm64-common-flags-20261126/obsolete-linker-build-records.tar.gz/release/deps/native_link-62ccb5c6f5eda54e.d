/workspaces/repository/kprog/arm64/build/app-native-link/release/deps/native_link-62ccb5c6f5eda54e.d: src/main.rs src/x86.rs

/workspaces/repository/kprog/arm64/build/app-native-link/release/deps/native_link-62ccb5c6f5eda54e: src/main.rs src/x86.rs

src/main.rs:
src/x86.rs:

# env-dep:CARGO_PKG_NAME=native-link
