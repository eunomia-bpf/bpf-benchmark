/workspaces/repository/kprog/arm64/build/app-native-link/release/deps/native_link_arm64_rodata_extents-8af13e2b28f2c096.d: src/main.rs src/x86.rs

/workspaces/repository/kprog/arm64/build/app-native-link/release/deps/native_link_arm64_rodata_extents-8af13e2b28f2c096: src/main.rs src/x86.rs

src/main.rs:
src/x86.rs:

# env-dep:CARGO_PKG_NAME=native-link
