/workspaces/repository/kprog/arm64/build/app-native-link/release/deps/lazy_static-ae4a585fbc22f7d2.d: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/lazy_static-1.5.0/src/lib.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/lazy_static-1.5.0/src/inline_lazy.rs

/workspaces/repository/kprog/arm64/build/app-native-link/release/deps/liblazy_static-ae4a585fbc22f7d2.rlib: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/lazy_static-1.5.0/src/lib.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/lazy_static-1.5.0/src/inline_lazy.rs

/workspaces/repository/kprog/arm64/build/app-native-link/release/deps/liblazy_static-ae4a585fbc22f7d2.rmeta: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/lazy_static-1.5.0/src/lib.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/lazy_static-1.5.0/src/inline_lazy.rs

/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/lazy_static-1.5.0/src/lib.rs:
/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/lazy_static-1.5.0/src/inline_lazy.rs:
