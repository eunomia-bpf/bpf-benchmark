/workspaces/repository/kprog/arm64/build/app-native-link/release/deps/colorchoice-fc5914e7da56009a.d: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/colorchoice-1.0.5/src/lib.rs

/workspaces/repository/kprog/arm64/build/app-native-link/release/deps/libcolorchoice-fc5914e7da56009a.rlib: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/colorchoice-1.0.5/src/lib.rs

/workspaces/repository/kprog/arm64/build/app-native-link/release/deps/libcolorchoice-fc5914e7da56009a.rmeta: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/colorchoice-1.0.5/src/lib.rs

/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/colorchoice-1.0.5/src/lib.rs:
