/workspaces/repository/kprog/arm64/build/app-native-link/release/deps/utf8parse-6603349c31b65f21.d: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/utf8parse-0.2.2/src/lib.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/utf8parse-0.2.2/src/types.rs

/workspaces/repository/kprog/arm64/build/app-native-link/release/deps/libutf8parse-6603349c31b65f21.rlib: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/utf8parse-0.2.2/src/lib.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/utf8parse-0.2.2/src/types.rs

/workspaces/repository/kprog/arm64/build/app-native-link/release/deps/libutf8parse-6603349c31b65f21.rmeta: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/utf8parse-0.2.2/src/lib.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/utf8parse-0.2.2/src/types.rs

/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/utf8parse-0.2.2/src/lib.rs:
/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/utf8parse-0.2.2/src/types.rs:
