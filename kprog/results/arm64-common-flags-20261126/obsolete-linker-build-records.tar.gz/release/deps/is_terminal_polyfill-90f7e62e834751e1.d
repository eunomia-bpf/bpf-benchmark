/workspaces/repository/kprog/arm64/build/app-native-link/release/deps/is_terminal_polyfill-90f7e62e834751e1.d: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/is_terminal_polyfill-1.70.2/src/lib.rs

/workspaces/repository/kprog/arm64/build/app-native-link/release/deps/libis_terminal_polyfill-90f7e62e834751e1.rlib: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/is_terminal_polyfill-1.70.2/src/lib.rs

/workspaces/repository/kprog/arm64/build/app-native-link/release/deps/libis_terminal_polyfill-90f7e62e834751e1.rmeta: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/is_terminal_polyfill-1.70.2/src/lib.rs

/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/is_terminal_polyfill-1.70.2/src/lib.rs:
