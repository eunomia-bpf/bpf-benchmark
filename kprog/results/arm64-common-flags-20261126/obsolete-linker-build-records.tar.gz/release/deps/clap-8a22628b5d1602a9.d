/workspaces/repository/kprog/arm64/build/app-native-link/release/deps/clap-8a22628b5d1602a9.d: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.1/src/lib.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.1/src/../examples/demo.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.1/src/../examples/demo.md

/workspaces/repository/kprog/arm64/build/app-native-link/release/deps/libclap-8a22628b5d1602a9.rlib: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.1/src/lib.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.1/src/../examples/demo.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.1/src/../examples/demo.md

/workspaces/repository/kprog/arm64/build/app-native-link/release/deps/libclap-8a22628b5d1602a9.rmeta: /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.1/src/lib.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.1/src/../examples/demo.rs /usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.1/src/../examples/demo.md

/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.1/src/lib.rs:
/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.1/src/../examples/demo.rs:
/usr/local/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.1/src/../examples/demo.md:
