from pathlib import Path
import json,os,subprocess
R=Path('/workspaces/repository');O=Path('/var/tmp/kprog-tmp/S14')
os.unshare(os.CLONE_NEWNS);subprocess.run(['mount','--make-rprivate','/'],check=True)
# The tracked arch-specific headers also match the retained 7.0 target source.
for row in json.loads((O/'header-incident.json').read_text()):
 path=R/row['path']; saved=O/'header-incident'/row['path'];src=saved.with_suffix('.HEAD')
 subprocess.run(['mount','--bind',str(src),str(path)],check=True)
for arch in ['x86','arm64']:
 sys='-I/usr/include -I/usr/include/x86_64-linux-gnu' if arch=='x86' else '-I/usr/aarch64-linux-gnu/include -I'+str(R/'.cache/aarch64-sysroot/usr/include')+' -I'+str(R/'.cache/aarch64-sysroot/usr/include/aarch64-linux-gnu')
 cmd=['make','-C',str(R/'vendor/bpf'),'-f',str(O/'corpus.mk'),'-j4','-k','scalar-corpus-objects','ARCH='+arch,'BUILD='+str(O/'corpus-final'),'KERNEL_RELEASE=7.0.0-30-generic','NATIVE_LINK='+str(R/'kprog/x86/native_lab/native_link/target/release/native-link'),'NATIVE_SYS_INCLUDE_FLAGS='+sys]
 for path in [f'targets/{arch}/7.0.0-30-generic/vmlinux.h',f'bcc/libbpf-tools/{arch}/vmlinux.h',f'tetragon/bpf/include/vmlinux_generated_{arch}.h']:
  cmd+=['-o',path]
 with (O/f'corpus-final-{arch}.log').open('w') as log:rc=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT).returncode
 (O/f'corpus-final-{arch}.exit').write_text(str(rc)+'\n')
 print(arch,'corpus native build',rc,flush=True)
