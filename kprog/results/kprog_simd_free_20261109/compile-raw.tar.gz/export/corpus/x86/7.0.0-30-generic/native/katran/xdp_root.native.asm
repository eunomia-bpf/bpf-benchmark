
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/katran/xdp_root.native.o:	file format elf64-x86-64

Disassembly of section xdp:

0000000000000000 <xdp_root>:
       0:      	pushq	%r15
       2:      	pushq	%r14
       4:      	pushq	%rbx
       5:      	movq	%rdi, %rbx
       8:      	movq	(%rip), %r14            # 0xf <xdp_root+0xf>
       f:      	movl	$0xc, %r15d
      15:      	movq	%r14, %rsi
      18:      	xorl	%edx, %edx
      1a:      	callq	*%r15
      1d:      	movq	%rbx, %rdi
      20:      	movq	%r14, %rsi
      23:      	movl	$0x1, %edx
      28:      	callq	*%r15
      2b:      	movq	%rbx, %rdi
      2e:      	movq	%r14, %rsi
      31:      	movl	$0x2, %edx
      36:      	callq	*%r15
      39:      	movl	$0x2, %eax
      3e:      	popq	%rbx
      3f:      	popq	%r14
      41:      	popq	%r15
      43:      	retq
