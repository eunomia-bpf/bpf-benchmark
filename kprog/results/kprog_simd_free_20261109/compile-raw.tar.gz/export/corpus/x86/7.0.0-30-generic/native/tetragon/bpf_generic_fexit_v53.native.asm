
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_generic_fexit_v53.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <native_bpf_strncasestr>:
       0:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
       5:      	testq	%rdx, %rdx
       8:      	je	0x74 <native_bpf_strncasestr+0x74>
       a:      	pushq	%rbx
       b:      	xorl	%ecx, %ecx
       d:      	jmp	0x1b <native_bpf_strncasestr+0x1b>
       f:      	nop
      10:      	incq	%rcx
      13:      	incq	%rdi
      16:      	cmpq	%rdx, %rcx
      19:      	je	0x73 <native_bpf_strncasestr+0x73>
      1b:      	xorl	%r8d, %r8d
      1e:      	nop
      20:      	leaq	(%rcx,%r8), %r9
      24:      	cmpq	%rdx, %r9
      27:      	jae	0x10 <native_bpf_strncasestr+0x10>
      29:      	movsbl	(%rsi,%r8), %r9d
      2e:      	testl	%r9d, %r9d
      31:      	je	0x71 <native_bpf_strncasestr+0x71>
      33:      	movsbl	(%rdi,%r8), %r10d
      38:      	leal	-0x41(%r10), %r11d
      3c:      	movl	%r10d, %ebx
      3f:      	orl	$0x20, %ebx
      42:      	cmpl	$0x1a, %r11d
      46:      	cmovael	%r10d, %ebx
      4a:      	leal	-0x41(%r9), %r10d
      4e:      	movl	%r9d, %r11d
      51:      	orl	$0x20, %r11d
      55:      	cmpl	$0x1a, %r10d
      59:      	cmovael	%r9d, %r11d
      5d:      	cmpl	%r11d, %ebx
      60:      	jne	0x10 <native_bpf_strncasestr+0x10>
      62:      	leaq	0x1(%r8), %r9
      66:      	cmpq	$0x63, %r8
      6a:      	movq	%r9, %r8
      6d:      	jb	0x20 <native_bpf_strncasestr+0x20>
      6f:      	jmp	0x10 <native_bpf_strncasestr+0x10>
      71:      	movl	%ecx, %eax
      73:      	popq	%rbx
      74:      	retq

Disassembly of section fexit/generic_fexit_tail:

0000000000000000 <generic_fexit_filter_arg>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0xb8, %rsp
      11:      	movq	%rdi, %r12
      14:      	movl	$0x0, 0xa4(%rsp)
      1f:      	movq	(%rip), %rdi            # 0x26 <generic_fexit_filter_arg+0x26>
      26:      	leaq	0xa4(%rsp), %rsi
      2e:      	movl	$0x1, %eax
      33:      	callq	*%rax
      35:      	testq	%rax, %rax
      38:      	je	0x17a <generic_fexit_filter_arg+0x17a>
      3e:      	movq	%rax, %r14
      41:      	movl	0x5f00(%rax), %ebx
      47:      	leaq	0x5ef8(%rax), %rsi
      4e:      	movq	(%rip), %rdi            # 0x55 <generic_fexit_filter_arg+0x55>
      55:      	movl	$0x1, %eax
      5a:      	callq	*%rax
      5c:      	testq	%rax, %rax
      5f:      	je	0x15f <generic_fexit_filter_arg+0x15f>
      65:      	cmpb	$0x0, 0x5ee0(%r14)
      6d:      	je	0x15f <generic_fexit_filter_arg+0x15f>
      73:      	movq	%rax, %rdi
      76:      	movl	%ebx, %eax
      78:      	andl	$0x7, %eax
      7b:      	cmpb	$0x0, 0x5ec1(%r14,%rax)
      84:      	je	0xb8 <generic_fexit_filter_arg+0xb8>
      86:      	movl	%eax, %eax
      88:      	movl	0x4(%rdi,%rax,4), %ecx
      8c:      	leaq	(%rcx,%rax,4), %r11
      90:      	addq	$0x8, %r11
      94:      	movl	%r11d, %r9d
      97:      	andl	$0x3ff, %r9d            # imm = 0x3FF
      9e:      	cmpl	$0x19, (%rdi,%r9)
      a3:      	jae	0x104 <generic_fexit_filter_arg+0x104>
      a5:      	cmpq	$0x1, %r9
      a9:      	je	0x15f <generic_fexit_filter_arg+0x15f>
      af:      	testl	%r9d, %r9d
      b2:      	jne	0x13d <generic_fexit_filter_arg+0x13d>
      b8:      	cmpl	$0x1, %ebx
      bb:      	jg	0xd9 <generic_fexit_filter_arg+0xd9>
      bd:      	cmpl	$-0x1, %ebx
      c0:      	je	0x18e <generic_fexit_filter_arg+0x18e>
      c6:      	testl	%ebx, %ebx
      c8:      	je	0x19a <generic_fexit_filter_arg+0x19a>
      ce:      	cmpl	$0x1, %ebx
      d1:      	je	0x1a9 <generic_fexit_filter_arg+0x1a9>
      d7:      	jmp	0xf4 <generic_fexit_filter_arg+0xf4>
      d9:      	cmpl	$0x2, %ebx
      dc:      	je	0x1b8 <generic_fexit_filter_arg+0x1b8>
      e2:      	cmpl	$0x3, %ebx
      e5:      	je	0x1c7 <generic_fexit_filter_arg+0x1c7>
      eb:      	cmpl	$0x4, %ebx
      ee:      	je	0x1d6 <generic_fexit_filter_arg+0x1d6>
      f4:      	cmpl	$0x4, %ebx
      f7:      	jg	0x207 <generic_fexit_filter_arg+0x207>
      fd:      	incl	%ebx
      ff:      	jmp	0x1e5 <generic_fexit_filter_arg+0x1e5>
     104:      	leaq	(%rdi,%r9), %rax
     108:      	movq	%rax, 0xb0(%rsp)
     110:      	xorl	%r13d, %r13d
     113:      	leaq	0x70(%rsp), %rax
     118:      	movq	%rax, 0x30(%rsp)
     11d:      	movq	%rbx, 0xa8(%rsp)
     125:      	movq	%rdi, (%rsp)
     129:      	movq	%r9, 0x8(%rsp)
     12e:      	movq	%r11, 0x10(%rsp)
     133:      	movq	%r12, 0x68(%rsp)
     138:      	jmp	0x283 <generic_fexit_filter_arg+0x283>
     13d:      	movl	%r9d, 0x5f04(%r14)
     144:      	movq	(%rip), %rsi            # 0x14b <generic_fexit_filter_arg+0x14b>
     14b:      	movl	$0x4, %ecx
     150:      	movl	$0xc, %eax
     155:      	movq	%r12, %rdi
     158:      	movl	$0x4, %edx
     15d:      	callq	*%rax
     15f:      	movq	(%rip), %rsi            # 0x166 <generic_fexit_filter_arg+0x166>
     166:      	movl	$0x5, %ecx
     16b:      	movl	$0xc, %eax
     170:      	movq	%r12, %rdi
     173:      	movl	$0x5, %edx
     178:      	callq	*%rax
     17a:      	xorl	%eax, %eax
     17c:      	addq	$0xb8, %rsp
     183:      	popq	%rbx
     184:      	popq	%r12
     186:      	popq	%r13
     188:      	popq	%r14
     18a:      	popq	%r15
     18c:      	popq	%rbp
     18d:      	retq
     18e:      	xorl	%ebx, %ebx
     190:      	cmpb	$0x0, 0x5ec1(%r14)
     198:      	jne	0x1e5 <generic_fexit_filter_arg+0x1e5>
     19a:      	movl	$0x1, %ebx
     19f:      	cmpb	$0x0, 0x5ec2(%r14)
     1a7:      	jne	0x1e5 <generic_fexit_filter_arg+0x1e5>
     1a9:      	movl	$0x2, %ebx
     1ae:      	cmpb	$0x0, 0x5ec3(%r14)
     1b6:      	jne	0x1e5 <generic_fexit_filter_arg+0x1e5>
     1b8:      	movl	$0x3, %ebx
     1bd:      	cmpb	$0x0, 0x5ec4(%r14)
     1c5:      	jne	0x1e5 <generic_fexit_filter_arg+0x1e5>
     1c7:      	movl	$0x4, %ebx
     1cc:      	cmpb	$0x0, 0x5ec5(%r14)
     1d4:      	jne	0x1e5 <generic_fexit_filter_arg+0x1e5>
     1d6:      	movl	$0x5, %ebx
     1db:      	cmpb	$0x0, 0x5ec6(%r14)
     1e3:      	je	0x207 <generic_fexit_filter_arg+0x207>
     1e5:      	movl	%ebx, 0x5f00(%r14)
     1ec:      	movq	(%rip), %rsi            # 0x1f3 <generic_fexit_filter_arg+0x1f3>
     1f3:      	movl	$0x3, %ecx
     1f8:      	movl	$0xc, %eax
     1fd:      	movq	%r12, %rdi
     200:      	movl	$0x3, %edx
     205:      	callq	*%rax
     207:      	movq	0x60(%r14), %rbx
     20b:      	movl	$0xe, %eax
     210:      	callq	*%rax
     212:      	movq	%rbx, 0x38(%rsp)
     217:      	movq	%rax, 0x40(%rsp)
     21c:      	movq	(%rip), %rdi            # 0x223 <generic_fexit_filter_arg+0x223>
     223:      	leaq	0x38(%rsp), %rsi
     228:      	movl	$0x1, %eax
     22d:      	callq	*%rax
     22f:      	testq	%rax, %rax
     232:      	je	0x17a <generic_fexit_filter_arg+0x17a>
     238:      	movq	(%rip), %rdi            # 0x23f <generic_fexit_filter_arg+0x23f>
     23f:      	leaq	0x38(%rsp), %rsi
     244:      	movl	$0x3, %eax
     249:      	callq	*%rax
     24b:      	jmp	0x17a <generic_fexit_filter_arg+0x17a>
     250:      	xorl	%ebx, %ebx
     252:      	movq	(%rsp), %rdi
     256:      	movq	0x8(%rsp), %r9
     25b:      	movq	0x10(%rsp), %r11
     260:      	movq	0x68(%rsp), %r12
     265:      	testq	%rbx, %rbx
     268:      	movq	0xa8(%rsp), %rbx
     270:      	je	0xb8 <generic_fexit_filter_arg+0xb8>
     276:      	incq	%r13
     279:      	cmpq	$0x5, %r13
     27d:      	je	0xa5 <generic_fexit_filter_arg+0xa5>
     283:      	movq	0xb0(%rsp), %rax
     28b:      	movl	0x4(%rax,%r13,4), %r15d
     290:      	testl	$0x3ff, %r15d           # imm = 0x3FF
     297:      	je	0xa5 <generic_fexit_filter_arg+0xa5>
     29d:      	addl	%r11d, %r15d
     2a0:      	andl	$0x3ff, %r15d           # imm = 0x3FF
     2a7:      	movl	0x4(%rdi,%r15), %eax
     2ac:      	cmpl	$0x23, %eax
     2af:      	je	0xb8 <generic_fexit_filter_arg+0xb8>
     2b5:      	addq	%rdi, %r15
     2b8:      	movl	(%r15), %ecx
     2bb:      	cmpq	$0x4, %rcx
     2bf:      	ja	0xb8 <generic_fexit_filter_arg+0xb8>
     2c5:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
     2ce:      	jne	0xb8 <generic_fexit_filter_arg+0xb8>
     2d4:      	movq	0x5e78(%r14,%rcx,8), %rcx
     2dc:      	andl	$0x7ff, %ecx            # imm = 0x7FF
     2e2:      	leaq	(%r14,%rcx), %rbp
     2e6:      	addq	$0x90, %rbp
     2ed:      	movl	0xc(%r15), %ecx
     2f1:      	cmpl	$0x10, %ecx
     2f4:      	jle	0x350 <generic_fexit_filter_arg+0x350>
     2f6:      	leal	-0x1c(%rcx), %edx
     2f9:      	cmpl	$0x9, %edx
     2fc:      	jb	0x541 <generic_fexit_filter_arg+0x541>
     302:      	cmpl	$0x2a, %ecx
     305:      	ja	0x341 <generic_fexit_filter_arg+0x341>
     307:      	movl	%ecx, %edx
     309:      	movabsq	$0xc000000000, %rsi     # imm = 0xC000000000
     313:      	btq	%rdx, %rsi
     317:      	jb	0x379 <generic_fexit_filter_arg+0x379>
     319:      	movabsq	$0x30000000000, %rsi    # imm = 0x30000000000
     323:      	btq	%rdx, %rsi
     327:      	jb	0x89c <generic_fexit_filter_arg+0x89c>
     32d:      	movabsq	$0x42000000000, %rsi    # imm = 0x42000000000
     337:      	btq	%rdx, %rsi
     33b:      	jb	0x3cc <generic_fexit_filter_arg+0x3cc>
     341:      	cmpl	$0x11, %ecx
     344:      	jne	0x276 <generic_fexit_filter_arg+0x276>
     34a:      	addq	$0x4, %rbp
     34e:      	jmp	0x3cc <generic_fexit_filter_arg+0x3cc>
     350:      	cmpl	$0x6, %ecx
     353:      	jg	0x3b4 <generic_fexit_filter_arg+0x3b4>
     355:      	cmpl	$0x3, %ecx
     358:      	jle	0x4f3 <generic_fexit_filter_arg+0x4f3>
     35e:      	cmpl	$0x4, %ecx
     361:      	je	0x541 <generic_fexit_filter_arg+0x541>
     367:      	cmpl	$0x5, %ecx
     36a:      	je	0x89c <generic_fexit_filter_arg+0x89c>
     370:      	cmpl	$0x6, %ecx
     373:      	jne	0x276 <generic_fexit_filter_arg+0x276>
     379:      	movq	%rbp, %rsi
     37c:      	movl	(%rbp), %ebp
     37f:      	addq	$0x4, %rsi
     383:      	cmpl	$0x19, %eax
     386:      	jg	0x6c6 <generic_fexit_filter_arg+0x6c6>
     38c:      	leal	-0x3(%rax), %ecx
     38f:      	cmpl	$0x2, %ecx
     392:      	jb	0xf07 <generic_fexit_filter_arg+0xf07>
     398:      	cmpl	$0x8, %eax
     39b:      	je	0xe67 <generic_fexit_filter_arg+0xe67>
     3a1:      	movl	$0x0, %ebx
     3a6:      	cmpl	$0x9, %eax
     3a9:      	je	0x6e6 <generic_fexit_filter_arg+0x6e6>
     3af:      	jmp	0x2c6b <generic_fexit_filter_arg+0x2c6b>
     3b4:      	leal	-0xa(%rcx), %edx
     3b7:      	cmpl	$0x4, %edx
     3ba:      	jb	0x541 <generic_fexit_filter_arg+0x541>
     3c0:      	leal	-0xf(%rcx), %edx
     3c3:      	cmpl	$0x2, %edx
     3c6:      	jae	0x893 <generic_fexit_filter_arg+0x893>
     3cc:      	movq	%rbp, 0x20(%rsp)
     3d1:      	movl	(%rbp), %ebp
     3d4:      	movl	%eax, %ecx
     3d6:      	andl	$-0x2, %ecx
     3d9:      	cmpl	$0x24, %ecx
     3dc:      	je	0x3e6 <generic_fexit_filter_arg+0x3e6>
     3de:      	testl	%ebp, %ebp
     3e0:      	je	0xb8 <generic_fexit_filter_arg+0xb8>
     3e6:      	cmpl	$0x25, %eax
     3e9:      	movq	0x20(%rsp), %rsi
     3ee:      	ja	0x829 <generic_fexit_filter_arg+0x829>
     3f4:      	movl	%eax, %ecx
     3f6:      	movl	$0x4000100, %edx        # imm = 0x4000100
     3fb:      	btq	%rcx, %rdx
     3ff:      	jb	0xb9d <generic_fexit_filter_arg+0xb9d>
     405:      	movl	$0x8000200, %edx        # imm = 0x8000200
     40a:      	btq	%rcx, %rdx
     40e:      	jb	0xa5b <generic_fexit_filter_arg+0xa5b>
     414:      	movabsq	$0x3000000000, %rdx     # imm = 0x3000000000
     41e:      	btq	%rcx, %rdx
     422:      	jae	0x829 <generic_fexit_filter_arg+0x829>
     428:      	movw	$0x0, 0x38(%rsp)
     42f:      	cmpl	$0x1fe, %ebp            # imm = 0x1FE
     435:      	ja	0x845 <generic_fexit_filter_arg+0x845>
     43b:      	leaq	(%rsi,%rbp), %rcx
     43f:      	addq	$0x8, %rcx
     443:      	movl	$0x4, %eax
     448:      	leaq	0x38(%rsp), %rdi
     44d:      	movl	$0x2, %edx
     452:      	movl	(%rsi), %ecx
     454:      	leaq	(%rsi,%rcx), %rdx
     458:      	addq	$0x8, %rdx
     45c:      	movl	$0x2, %esi
     461:      	callq	*%rax
     463:      	movl	0x10(%r15), %ecx
     467:      	testl	%ecx, %ecx
     469:      	je	0x2aa6 <generic_fexit_filter_arg+0x2aa6>
     46f:      	movzwl	0x38(%rsp), %eax
     474:      	andl	$0xf000, %eax           # imm = 0xF000
     479:      	movl	$0x1, %ebx
     47e:      	cmpl	%eax, %ecx
     480:      	je	0x2aa8 <generic_fexit_filter_arg+0x2aa8>
     486:      	movl	0x8(%r15), %ecx
     48a:      	cmpl	$0xd, %ecx
     48d:      	movq	(%rsp), %rdi
     491:      	movq	0x8(%rsp), %r9
     496:      	movq	0x10(%rsp), %r11
     49b:      	jb	0x845 <generic_fexit_filter_arg+0x845>
     4a1:      	movl	0x14(%r15), %edx
     4a5:      	testl	%edx, %edx
     4a7:      	je	0x845 <generic_fexit_filter_arg+0x845>
     4ad:      	cmpl	%eax, %edx
     4af:      	je	0x2ab6 <generic_fexit_filter_arg+0x2ab6>
     4b5:      	cmpl	$0x11, %ecx
     4b8:      	jb	0x845 <generic_fexit_filter_arg+0x845>
     4be:      	movl	0x18(%r15), %edx
     4c2:      	testl	%edx, %edx
     4c4:      	je	0x845 <generic_fexit_filter_arg+0x845>
     4ca:      	cmpl	%eax, %edx
     4cc:      	je	0x2ab6 <generic_fexit_filter_arg+0x2ab6>
     4d2:      	cmpl	$0x15, %ecx
     4d5:      	jb	0x2aa6 <generic_fexit_filter_arg+0x2aa6>
     4db:      	movl	0x1c(%r15), %ecx
     4df:      	testl	%ecx, %ecx
     4e1:      	je	0x2aa6 <generic_fexit_filter_arg+0x2aa6>
     4e7:      	xorl	%ebx, %ebx
     4e9:      	cmpl	%eax, %ecx
     4eb:      	sete	%bl
     4ee:      	jmp	0x2aa8 <generic_fexit_filter_arg+0x2aa8>
     4f3:      	cmpl	$0x1, %ecx
     4f6:      	je	0x541 <generic_fexit_filter_arg+0x541>
     4f8:      	cmpl	$0x2, %ecx
     4fb:      	jne	0x276 <generic_fexit_filter_arg+0x276>
     501:      	movq	%rbp, %rsi
     504:      	movl	0x4(%rbp), %ebp
     507:      	addq	$0x8, %rsi
     50b:      	cmpl	$0x19, %eax
     50e:      	jg	0xf81 <generic_fexit_filter_arg+0xf81>
     514:      	leal	-0x3(%rax), %ecx
     517:      	cmpl	$0x2, %ecx
     51a:      	jb	0x1754 <generic_fexit_filter_arg+0x1754>
     520:      	movq	%rsi, 0x20(%rsp)
     525:      	cmpl	$0x8, %eax
     528:      	je	0x16c0 <generic_fexit_filter_arg+0x16c0>
     52e:      	movl	$0x0, %ebx
     533:      	cmpl	$0x9, %eax
     536:      	je	0xfa6 <generic_fexit_filter_arg+0xfa6>
     53c:      	jmp	0x2ef2 <generic_fexit_filter_arg+0x2ef2>
     541:      	cmpl	$0xb, %ecx
     544:      	jle	0x5d3 <generic_fexit_filter_arg+0x5d3>
     54a:      	cmpl	$0x24, %ecx
     54d:      	ja	0x61a <generic_fexit_filter_arg+0x61a>
     553:      	movl	%ecx, %edx
     555:      	movabsq	$0x1e00000000, %rsi     # imm = 0x1E00000000
     55f:      	btq	%rdx, %rsi
     563:      	jb	0x5ee <generic_fexit_filter_arg+0x5ee>
     569:      	movl	$0x60000000, %esi       # imm = 0x60000000
     56e:      	btq	%rdx, %rsi
     572:      	jb	0x84c <generic_fexit_filter_arg+0x84c>
     578:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
     582:      	btq	%rdx, %rsi
     586:      	jae	0x61a <generic_fexit_filter_arg+0x61a>
     58c:      	cmpl	$0x20, %eax
     58f:      	ja	0xb8 <generic_fexit_filter_arg+0xb8>
     595:      	movl	%eax, %ecx
     597:      	movl	$0x101e, %edx           # imm = 0x101E
     59c:      	btq	%rcx, %rdx
     5a0:      	jae	0x10ef <generic_fexit_filter_arg+0x10ef>
     5a6:      	movl	0x10(%r15), %ecx
     5aa:      	cmpl	$0x2, %eax
     5ad:      	jle	0x157c <generic_fexit_filter_arg+0x157c>
     5b3:      	leal	-0x3(%rax), %edx
     5b6:      	cmpl	$0x2, %edx
     5b9:      	jae	0x1b2c <generic_fexit_filter_arg+0x1b2c>
     5bf:      	movq	%rbp, %rdx
     5c2:      	movzbl	(%rbp), %edx
     5c6:      	cmpl	%edx, %ecx
     5c8:      	jne	0x1e23 <generic_fexit_filter_arg+0x1e23>
     5ce:      	jmp	0x2e81 <generic_fexit_filter_arg+0x2e81>
     5d3:      	leal	-0xa(%rcx), %edx
     5d6:      	cmpl	$0x2, %edx
     5d9:      	jb	0x95f <generic_fexit_filter_arg+0x95f>
     5df:      	cmpl	$0x1, %ecx
     5e2:      	je	0x626 <generic_fexit_filter_arg+0x626>
     5e4:      	cmpl	$0x4, %ecx
     5e7:      	je	0x626 <generic_fexit_filter_arg+0x626>
     5e9:      	jmp	0x276 <generic_fexit_filter_arg+0x276>
     5ee:      	cmpl	$0x9, %eax
     5f1:      	jle	0x912 <generic_fexit_filter_arg+0x912>
     5f7:      	cmpl	$0x1d, %eax
     5fa:      	jg	0xd40 <generic_fexit_filter_arg+0xd40>
     600:      	leal	-0xa(%rax), %edx
     603:      	cmpl	$0x2, %edx
     606:      	jb	0x9ec <generic_fexit_filter_arg+0x9ec>
     60c:      	cmpl	$0xc, %eax
     60f:      	je	0x975 <generic_fexit_filter_arg+0x975>
     615:      	jmp	0xb8 <generic_fexit_filter_arg+0xb8>
     61a:      	leal	-0xc(%rcx), %edx
     61d:      	cmpl	$0x2, %edx
     620:      	jae	0x956 <generic_fexit_filter_arg+0x956>
     626:      	cmpl	$0x20, %eax
     629:      	ja	0xb8 <generic_fexit_filter_arg+0xb8>
     62f:      	movl	%eax, %edx
     631:      	movl	$0x101e, %esi           # imm = 0x101E
     636:      	btq	%rdx, %rsi
     63a:      	jae	0x663 <generic_fexit_filter_arg+0x663>
     63c:      	movl	0x10(%r15), %edx
     640:      	cmpl	$0x2, %eax
     643:      	jle	0x91f <generic_fexit_filter_arg+0x91f>
     649:      	leal	-0x3(%rax), %esi
     64c:      	cmpl	$0x2, %esi
     64f:      	jae	0x10d8 <generic_fexit_filter_arg+0x10d8>
     655:      	cmpl	%edx, (%rbp)
     658:      	jne	0x2062 <generic_fexit_filter_arg+0x2062>
     65e:      	jmp	0x2e81 <generic_fexit_filter_arg+0x2e81>
     663:      	movl	$0xc00, %esi            # imm = 0xC00
     668:      	btq	%rdx, %rsi
     66c:      	jb	0xc3c <generic_fexit_filter_arg+0xc3c>
     672:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
     67c:      	btq	%rdx, %rsi
     680:      	jae	0xb8 <generic_fexit_filter_arg+0xb8>
     686:      	cmpl	$0x1f, %eax
     689:      	jne	0x1227 <generic_fexit_filter_arg+0x1227>
     68f:      	movl	0x10(%r15), %esi
     693:      	movl	0x14(%r15), %edx
     697:      	cmpl	$0xc, %ecx
     69a:      	ja	0x1eb9 <generic_fexit_filter_arg+0x1eb9>
     6a0:      	movl	$0x1402, %eax           # imm = 0x1402
     6a5:      	btl	%ecx, %eax
     6a8:      	jae	0x1eb9 <generic_fexit_filter_arg+0x1eb9>
     6ae:      	movl	(%rbp), %eax
     6b1:      	cmpl	%eax, %esi
     6b3:      	jg	0x1ec8 <generic_fexit_filter_arg+0x1ec8>
     6b9:      	cmpl	%edx, %eax
     6bb:      	jle	0x276 <generic_fexit_filter_arg+0x276>
     6c1:      	jmp	0x1ec8 <generic_fexit_filter_arg+0x1ec8>
     6c6:      	cmpl	$0x20, %eax
     6c9:      	jg	0xd86 <generic_fexit_filter_arg+0xd86>
     6cf:      	cmpl	$0x1a, %eax
     6d2:      	je	0xe67 <generic_fexit_filter_arg+0xe67>
     6d8:      	movl	$0x0, %ebx
     6dd:      	cmpl	$0x1b, %eax
     6e0:      	jne	0x2c6b <generic_fexit_filter_arg+0x2c6b>
     6e6:      	movq	%rsi, 0x20(%rsp)
     6eb:      	movl	0x10(%r15), %eax
     6ef:      	movl	%eax, 0x38(%rsp)
     6f3:      	movl	$0x0, 0x70(%rsp)
     6fb:      	movl	$0x1, %eax
     700:      	leaq	0x38(%rsp), %rsi
     705:      	movq	(%rip), %rdi            # 0x70c <generic_fexit_filter_arg+0x70c>
     70c:      	callq	*%rax
     70e:      	testl	%ebp, %ebp
     710:      	je	0x2c5b <generic_fexit_filter_arg+0x2c5b>
     716:      	movl	$0x0, %ebx
     71b:      	testq	%rax, %rax
     71e:      	je	0x2c5d <generic_fexit_filter_arg+0x2c5d>
     724:      	movq	%rax, 0x18(%rsp)
     729:      	movl	$0x1, %eax
     72e:      	movq	0x30(%rsp), %rsi
     733:      	movq	(%rip), %rdi            # 0x73a <generic_fexit_filter_arg+0x73a>
     73a:      	callq	*%rax
     73c:      	testq	%rax, %rax
     73f:      	je	0x2c5b <generic_fexit_filter_arg+0x2c5b>
     745:      	movq	%rax, %rdi
     748:      	cmpl	$0x7f, %ebp
     74b:      	movl	$0x7f, %eax
     750:      	cmovbl	%ebp, %eax
     753:      	shll	$0x3, %eax
     756:      	movl	%eax, (%rdi)
     758:      	movq	%rbp, %rax
     75b:      	negq	%rax
     75e:      	movl	$0x3, %ecx
     763:      	subq	%rbp, %rcx
     766:      	leal	-0x4(%rbp), %edx
     769:      	movq	%rdi, 0x60(%rsp)
     76e:      	addq	$0x7, %rdi
     772:      	movl	$0x2, %r8d
     778:      	subq	%rbp, %r8
     77b:      	leal	-0x3(%rbp), %r9d
     77f:      	movl	$0x1, %r10d
     785:      	subq	%rbp, %r10
     788:      	leal	-0x2(%rbp), %r11d
     78c:      	decl	%ebp
     78e:      	xorl	%ebx, %ebx
     790:      	movq	0x20(%rsp), %rsi
     795:      	leal	(%rbx,%rbp), %r12d
     799:      	andl	$0xfff, %r12d           # imm = 0xFFF
     7a0:      	movzbl	(%rsi,%r12), %r12d
     7a5:      	movb	%r12b, -0x3(%rdi)
     7a9:      	cmpq	%rbx, %r10
     7ac:      	je	0x806 <generic_fexit_filter_arg+0x806>
     7ae:      	leal	(%r11,%rbx), %r12d
     7b2:      	andl	$0xfff, %r12d           # imm = 0xFFF
     7b9:      	movzbl	(%rsi,%r12), %r12d
     7be:      	movb	%r12b, -0x2(%rdi)
     7c2:      	cmpq	%rbx, %r8
     7c5:      	je	0x806 <generic_fexit_filter_arg+0x806>
     7c7:      	leal	(%r9,%rbx), %r12d
     7cb:      	andl	$0xfff, %r12d           # imm = 0xFFF
     7d2:      	movzbl	(%rsi,%r12), %r12d
     7d7:      	movb	%r12b, -0x1(%rdi)
     7db:      	cmpq	%rbx, %rcx
     7de:      	je	0x806 <generic_fexit_filter_arg+0x806>
     7e0:      	cmpq	$-0x7c, %rbx
     7e4:      	je	0x806 <generic_fexit_filter_arg+0x806>
     7e6:      	leal	(%rdx,%rbx), %r12d
     7ea:      	andl	$0xfff, %r12d           # imm = 0xFFF
     7f1:      	movzbl	(%rsi,%r12), %r12d
     7f6:      	movb	%r12b, (%rdi)
     7f9:      	addq	$-0x4, %rbx
     7fd:      	addq	$0x4, %rdi
     801:      	cmpq	%rbx, %rax
     804:      	jne	0x795 <generic_fexit_filter_arg+0x795>
     806:      	movl	$0x1, %eax
     80b:      	movq	0x18(%rsp), %rdi
     810:      	movq	0x60(%rsp), %rsi
     815:      	callq	*%rax
     817:      	xorl	%ebx, %ebx
     819:      	testq	%rax, %rax
     81c:      	setne	%bl
     81f:      	movq	0x68(%rsp), %r12
     824:      	jmp	0x2c5d <generic_fexit_filter_arg+0x2c5d>
     829:      	addl	$-0x3, %eax
     82c:      	cmpl	$0x2, %eax
     82f:      	jae	0x845 <generic_fexit_filter_arg+0x845>
     831:      	movl	$0x0, 0x70(%rsp)
     839:      	cmpl	$0x1fe, %ebp            # imm = 0x1FE
     83f:      	jbe	0x11d6 <generic_fexit_filter_arg+0x11d6>
     845:      	xorl	%ebx, %ebx
     847:      	jmp	0x2ab6 <generic_fexit_filter_arg+0x2ab6>
     84c:      	cmpl	$0x20, %eax
     84f:      	ja	0xb8 <generic_fexit_filter_arg+0xb8>
     855:      	movl	%eax, %ecx
     857:      	movl	$0x101e, %edx           # imm = 0x101E
     85c:      	btq	%rcx, %rdx
     860:      	jae	0x1121 <generic_fexit_filter_arg+0x1121>
     866:      	movl	0x10(%r15), %ecx
     86a:      	cmpl	$0x2, %eax
     86d:      	jle	0x159f <generic_fexit_filter_arg+0x159f>
     873:      	leal	-0x3(%rax), %edx
     876:      	cmpl	$0x2, %edx
     879:      	jae	0x1b46 <generic_fexit_filter_arg+0x1b46>
     87f:      	movq	%rbp, %rdx
     882:      	movzwl	(%rbp), %edx
     886:      	cmpl	%edx, %ecx
     888:      	jne	0x1e66 <generic_fexit_filter_arg+0x1e66>
     88e:      	jmp	0x2e81 <generic_fexit_filter_arg+0x2e81>
     893:      	cmpl	$0x7, %ecx
     896:      	jne	0x276 <generic_fexit_filter_arg+0x276>
     89c:      	movq	$0x0, 0x58(%rsp)
     8a5:      	movq	$0x0, 0x50(%rsp)
     8ae:      	movq	$0x0, 0x48(%rsp)
     8b7:      	movq	$0x0, 0x40(%rsp)
     8c0:      	movq	$0x0, 0x38(%rsp)
     8c9:      	cmpl	$0x27, %ecx
     8cc:      	jg	0x8f0 <generic_fexit_filter_arg+0x8f0>
     8ce:      	cmpl	$0x5, %ecx
     8d1:      	movq	%rbp, %rsi
     8d4:      	je	0xcbb <generic_fexit_filter_arg+0xcbb>
     8da:      	movq	%rsi, %rdx
     8dd:      	movl	$0x0, %ebx
     8e2:      	cmpl	$0x7, %ecx
     8e5:      	je	0xcbd <generic_fexit_filter_arg+0xcbd>
     8eb:      	jmp	0x260 <generic_fexit_filter_arg+0x260>
     8f0:      	cmpl	$0x28, %ecx
     8f3:      	movq	%rbp, %rsi
     8f6:      	je	0xc93 <generic_fexit_filter_arg+0xc93>
     8fc:      	movq	%rsi, %rdx
     8ff:      	movl	$0x0, %ebx
     904:      	cmpl	$0x29, %ecx
     907:      	je	0xcbd <generic_fexit_filter_arg+0xcbd>
     90d:      	jmp	0x260 <generic_fexit_filter_arg+0x260>
     912:      	leal	-0x1(%rax), %edx
     915:      	cmpl	$0x4, %edx
     918:      	jb	0x975 <generic_fexit_filter_arg+0x975>
     91a:      	jmp	0xb8 <generic_fexit_filter_arg+0xb8>
     91f:      	cmpl	$0x1, %eax
     922:      	je	0x1382 <generic_fexit_filter_arg+0x1382>
     928:      	cmpl	$0x2, %eax
     92b:      	jne	0x2062 <generic_fexit_filter_arg+0x2062>
     931:      	cmpl	$0xc, %ecx
     934:      	ja	0x2059 <generic_fexit_filter_arg+0x2059>
     93a:      	movl	$0x1402, %esi           # imm = 0x1402
     93f:      	btl	%ecx, %esi
     942:      	jae	0x2059 <generic_fexit_filter_arg+0x2059>
     948:      	cmpl	%edx, (%rbp)
     94b:      	jl	0x276 <generic_fexit_filter_arg+0x276>
     951:      	jmp	0x2062 <generic_fexit_filter_arg+0x2062>
     956:      	cmpl	$0x1c, %ecx
     959:      	jne	0x276 <generic_fexit_filter_arg+0x276>
     95f:      	cmpl	$0x20, %eax
     962:      	ja	0xb8 <generic_fexit_filter_arg+0xb8>
     968:      	movl	%eax, %edx
     96a:      	movl	$0x101e, %esi           # imm = 0x101E
     96f:      	btq	%rdx, %rsi
     973:      	jae	0x999 <generic_fexit_filter_arg+0x999>
     975:      	movq	0x10(%r15), %rdx
     979:      	cmpl	$0x2, %eax
     97c:      	jle	0x9bd <generic_fexit_filter_arg+0x9bd>
     97e:      	leal	-0x3(%rax), %esi
     981:      	cmpl	$0x2, %esi
     984:      	jae	0xc7b <generic_fexit_filter_arg+0xc7b>
     98a:      	cmpq	%rdx, (%rbp)
     98e:      	jne	0x1ab0 <generic_fexit_filter_arg+0x1ab0>
     994:      	jmp	0x2e81 <generic_fexit_filter_arg+0x2e81>
     999:      	movl	$0xc00, %esi            # imm = 0xC00
     99e:      	btq	%rdx, %rsi
     9a2:      	jb	0x9ec <generic_fexit_filter_arg+0x9ec>
     9a4:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
     9ae:      	btq	%rdx, %rsi
     9b2:      	jb	0xd4c <generic_fexit_filter_arg+0xd4c>
     9b8:      	jmp	0xb8 <generic_fexit_filter_arg+0xb8>
     9bd:      	cmpl	$0x1, %eax
     9c0:      	je	0x11b9 <generic_fexit_filter_arg+0x11b9>
     9c6:      	cmpl	$0x2, %eax
     9c9:      	jne	0x1ab0 <generic_fexit_filter_arg+0x1ab0>
     9cf:      	cmpl	$0xc, %ecx
     9d2:      	je	0x9dd <generic_fexit_filter_arg+0x9dd>
     9d4:      	cmpl	$0xa, %ecx
     9d7:      	jne	0x1aa6 <generic_fexit_filter_arg+0x1aa6>
     9dd:      	cmpq	%rdx, (%rbp)
     9e1:      	jl	0x276 <generic_fexit_filter_arg+0x276>
     9e7:      	jmp	0x1ab0 <generic_fexit_filter_arg+0x1ab0>
     9ec:      	movzbl	0x10(%r15), %eax
     9f1:      	movl	%eax, 0x70(%rsp)
     9f5:      	movl	$0x1, %eax
     9fa:      	movq	0x30(%rsp), %rsi
     9ff:      	movq	(%rip), %rdi            # 0xa06 <generic_fexit_filter_arg+0xa06>
     a06:      	callq	*%rax
     a08:      	testq	%rax, %rax
     a0b:      	je	0x166d <generic_fexit_filter_arg+0x166d>
     a11:      	movq	%rax, %rdi
     a14:      	movq	(%rbp), %rax
     a18:      	movq	%rax, 0x38(%rsp)
     a1d:      	movl	$0x1, %eax
     a22:      	leaq	0x38(%rsp), %rsi
     a27:      	callq	*%rax
     a29:      	movl	0x4(%r15), %ecx
     a2d:      	cmpl	$0xb, %ecx
     a30:      	je	0x169a <generic_fexit_filter_arg+0x169a>
     a36:      	cmpl	$0xa, %ecx
     a39:      	movq	(%rsp), %rdi
     a3d:      	movq	0x8(%rsp), %r9
     a42:      	movq	0x10(%rsp), %r11
     a47:      	jne	0x16b6 <generic_fexit_filter_arg+0x16b6>
     a4d:      	testq	%rax, %rax
     a50:      	setne	%al
     a53:      	movzbl	%al, %ebx
     a56:      	jmp	0x265 <generic_fexit_filter_arg+0x265>
     a5b:      	movl	0x10(%r15), %eax
     a5f:      	movl	%eax, 0x38(%rsp)
     a63:      	movl	$0x0, 0x70(%rsp)
     a6b:      	movl	$0x1, %eax
     a70:      	leaq	0x38(%rsp), %rsi
     a75:      	movq	(%rip), %rdi            # 0xa7c <generic_fexit_filter_arg+0xa7c>
     a7c:      	callq	*%rax
     a7e:      	testl	%ebp, %ebp
     a80:      	je	0x2aa6 <generic_fexit_filter_arg+0x2aa6>
     a86:      	movl	$0x0, %ebx
     a8b:      	testq	%rax, %rax
     a8e:      	je	0x2aa8 <generic_fexit_filter_arg+0x2aa8>
     a94:      	movq	%rax, 0x18(%rsp)
     a99:      	movl	$0x1, %eax
     a9e:      	movq	0x30(%rsp), %rsi
     aa3:      	movq	(%rip), %rdi            # 0xaaa <generic_fexit_filter_arg+0xaaa>
     aaa:      	callq	*%rax
     aac:      	testq	%rax, %rax
     aaf:      	je	0x2aa6 <generic_fexit_filter_arg+0x2aa6>
     ab5:      	movq	%rax, %rdi
     ab8:      	cmpl	$0x7f, %ebp
     abb:      	movl	$0x7f, %eax
     ac0:      	cmovbl	%ebp, %eax
     ac3:      	shll	$0x3, %eax
     ac6:      	movl	%eax, (%rdi)
     ac8:      	movq	%rbp, %rax
     acb:      	negq	%rax
     ace:      	movl	$0x3, %ecx
     ad3:      	subq	%rbp, %rcx
     ad6:      	leal	-0x4(%rbp), %edx
     ad9:      	movq	%rdi, 0x60(%rsp)
     ade:      	addq	$0x7, %rdi
     ae2:      	movl	$0x2, %r8d
     ae8:      	subq	%rbp, %r8
     aeb:      	leal	-0x3(%rbp), %r9d
     aef:      	movl	$0x1, %r10d
     af5:      	subq	%rbp, %r10
     af8:      	leal	-0x2(%rbp), %r11d
     afc:      	decl	%ebp
     afe:      	xorl	%ebx, %ebx
     b00:      	movq	0x20(%rsp), %rsi
     b05:      	leal	(%rbx,%rbp), %r12d
     b09:      	andl	$0xfff, %r12d           # imm = 0xFFF
     b10:      	movzbl	0x4(%rsi,%r12), %r12d
     b16:      	movb	%r12b, -0x3(%rdi)
     b1a:      	cmpq	%rbx, %r10
     b1d:      	je	0xb7a <generic_fexit_filter_arg+0xb7a>
     b1f:      	leal	(%r11,%rbx), %r12d
     b23:      	andl	$0xfff, %r12d           # imm = 0xFFF
     b2a:      	movzbl	0x4(%rsi,%r12), %r12d
     b30:      	movb	%r12b, -0x2(%rdi)
     b34:      	cmpq	%rbx, %r8
     b37:      	je	0xb7a <generic_fexit_filter_arg+0xb7a>
     b39:      	leal	(%r9,%rbx), %r12d
     b3d:      	andl	$0xfff, %r12d           # imm = 0xFFF
     b44:      	movzbl	0x4(%rsi,%r12), %r12d
     b4a:      	movb	%r12b, -0x1(%rdi)
     b4e:      	cmpq	%rbx, %rcx
     b51:      	je	0xb7a <generic_fexit_filter_arg+0xb7a>
     b53:      	cmpq	$-0x7c, %rbx
     b57:      	je	0xb7a <generic_fexit_filter_arg+0xb7a>
     b59:      	leal	(%rdx,%rbx), %r12d
     b5d:      	andl	$0xfff, %r12d           # imm = 0xFFF
     b64:      	movzbl	0x4(%rsi,%r12), %r12d
     b6a:      	movb	%r12b, (%rdi)
     b6d:      	addq	$-0x4, %rbx
     b71:      	addq	$0x4, %rdi
     b75:      	cmpq	%rbx, %rax
     b78:      	jne	0xb05 <generic_fexit_filter_arg+0xb05>
     b7a:      	movl	$0x1, %eax
     b7f:      	movq	0x18(%rsp), %rdi
     b84:      	movq	0x60(%rsp), %rsi
     b89:      	callq	*%rax
     b8b:      	xorl	%ebx, %ebx
     b8d:      	testq	%rax, %rax
     b90:      	setne	%bl
     b93:      	movq	0x68(%rsp), %r12
     b98:      	jmp	0x2aa8 <generic_fexit_filter_arg+0x2aa8>
     b9d:      	movl	0x10(%r15), %eax
     ba1:      	movl	%eax, 0x38(%rsp)
     ba5:      	movl	$0x0, 0x70(%rsp)
     bad:      	movl	$0x1, %eax
     bb2:      	leaq	0x38(%rsp), %rsi
     bb7:      	movq	(%rip), %rdi            # 0xbbe <generic_fexit_filter_arg+0xbbe>
     bbe:      	callq	*%rax
     bc0:      	testl	%ebp, %ebp
     bc2:      	je	0x2aa6 <generic_fexit_filter_arg+0x2aa6>
     bc8:      	movl	$0x0, %ebx
     bcd:      	testq	%rax, %rax
     bd0:      	je	0x2aa8 <generic_fexit_filter_arg+0x2aa8>
     bd6:      	movq	%rax, 0x18(%rsp)
     bdb:      	movl	$0x1, %eax
     be0:      	movq	0x30(%rsp), %rsi
     be5:      	movq	(%rip), %rdi            # 0xbec <generic_fexit_filter_arg+0xbec>
     bec:      	callq	*%rax
     bee:      	testq	%rax, %rax
     bf1:      	je	0x2aa6 <generic_fexit_filter_arg+0x2aa6>
     bf7:      	movq	%rax, %rbx
     bfa:      	movq	0x20(%rsp), %rdx
     bff:      	addq	$0x4, %rdx
     c03:      	cmpl	$0xff, %ebp
     c09:      	movl	$0xff, %eax
     c0e:      	cmovael	%eax, %ebp
     c11:      	leal	(,%rbp,8), %eax
     c18:      	movl	%eax, (%rbx)
     c1a:      	movq	%rbx, %rdi
     c1d:      	addq	$0x4, %rdi
     c21:      	movl	$0x4, %eax
     c26:      	movl	%ebp, %esi
     c28:      	callq	*%rax
     c2a:      	movl	$0x1, %eax
     c2f:      	movq	0x18(%rsp), %rdi
     c34:      	movq	%rbx, %rsi
     c37:      	jmp	0x2a9a <generic_fexit_filter_arg+0x2a9a>
     c3c:      	movzbl	0x10(%r15), %eax
     c41:      	movl	%eax, 0x70(%rsp)
     c45:      	movl	$0x1, %eax
     c4a:      	movq	0x30(%rsp), %rsi
     c4f:      	movq	(%rip), %rdi            # 0xc56 <generic_fexit_filter_arg+0xc56>
     c56:      	callq	*%rax
     c58:      	testq	%rax, %rax
     c5b:      	je	0x166d <generic_fexit_filter_arg+0x166d>
     c61:      	movq	%rax, %rdi
     c64:      	movl	(%rbp), %eax
     c67:      	movq	%rax, 0x38(%rsp)
     c6c:      	movl	$0x1, %eax
     c71:      	leaq	0x38(%rsp), %rsi
     c76:      	jmp	0x1636 <generic_fexit_filter_arg+0x1636>
     c7b:      	cmpl	$0xc, %eax
     c7e:      	jne	0x1ab0 <generic_fexit_filter_arg+0x1ab0>
     c84:      	testq	%rdx, (%rbp)
     c88:      	jne	0x276 <generic_fexit_filter_arg+0x276>
     c8e:      	jmp	0x1ab0 <generic_fexit_filter_arg+0x1ab0>
     c93:      	movzwl	(%rsi), %edx
     c96:      	movw	%dx, 0x5e(%rsp)
     c9b:      	movzwl	0x2(%rsi), %edx
     c9f:      	movw	%dx, 0x58(%rsp)
     ca4:      	movq	0x8(%rsi), %rdx
     ca8:      	movq	%rdx, 0x38(%rsp)
     cad:      	movq	0x10(%rsi), %rdx
     cb1:      	movq	%rdx, 0x40(%rsp)
     cb6:      	leaq	0x38(%rsp), %rsi
     cbb:      	xorl	%edx, %edx
     cbd:      	cmpl	$0x13, %eax
     cc0:      	jle	0xce9 <generic_fexit_filter_arg+0xce9>
     cc2:      	cmpl	$0x17, %eax
     cc5:      	jg	0xd1b <generic_fexit_filter_arg+0xd1b>
     cc7:      	leal	-0x14(%rax), %ecx
     cca:      	cmpl	$0x2, %ecx
     ccd:      	jb	0x1273 <generic_fexit_filter_arg+0x1273>
     cd3:      	leal	-0x16(%rax), %ecx
     cd6:      	movl	$0x0, %ebx
     cdb:      	cmpl	$0x2, %ecx
     cde:      	jb	0x126c <generic_fexit_filter_arg+0x126c>
     ce4:      	jmp	0x260 <generic_fexit_filter_arg+0x260>
     ce9:      	cmpl	$0xf, %eax
     cec:      	jle	0xf5c <generic_fexit_filter_arg+0xf5c>
     cf2:      	cmpl	$0x11, %eax
     cf5:      	jg	0x1259 <generic_fexit_filter_arg+0x1259>
     cfb:      	cmpl	$0x10, %eax
     cfe:      	je	0x126c <generic_fexit_filter_arg+0x126c>
     d04:      	movl	$0x0, %ebx
     d09:      	cmpl	$0x11, %eax
     d0c:      	jne	0x260 <generic_fexit_filter_arg+0x260>
     d12:      	movzwl	0x24(%rsi), %ebx
     d16:      	jmp	0x1a17 <generic_fexit_filter_arg+0x1a17>
     d1b:      	cmpl	$0x1b, %eax
     d1e:      	jg	0x12ac <generic_fexit_filter_arg+0x12ac>
     d24:      	cmpl	$0x18, %eax
     d27:      	je	0x12e6 <generic_fexit_filter_arg+0x12e6>
     d2d:      	movl	$0x0, %ebx
     d32:      	cmpl	$0x19, %eax
     d35:      	je	0x12dc <generic_fexit_filter_arg+0x12dc>
     d3b:      	jmp	0x260 <generic_fexit_filter_arg+0x260>
     d40:      	leal	-0x1f(%rax), %edx
     d43:      	cmpl	$0x2, %edx
     d46:      	jae	0x176f <generic_fexit_filter_arg+0x176f>
     d4c:      	cmpl	$0x1f, %eax
     d4f:      	jne	0xf30 <generic_fexit_filter_arg+0xf30>
     d55:      	movq	0x10(%r15), %rsi
     d59:      	movq	0x18(%r15), %rdx
     d5d:      	cmpl	$0xa, %ecx
     d60:      	je	0xd6b <generic_fexit_filter_arg+0xd6b>
     d62:      	cmpl	$0xc, %ecx
     d65:      	jne	0x1979 <generic_fexit_filter_arg+0x1979>
     d6b:      	movq	(%rbp), %rax
     d6f:      	cmpq	%rax, %rsi
     d72:      	jg	0x198b <generic_fexit_filter_arg+0x198b>
     d78:      	cmpq	%rdx, %rax
     d7b:      	jle	0x276 <generic_fexit_filter_arg+0x276>
     d81:      	jmp	0x198b <generic_fexit_filter_arg+0x198b>
     d86:      	cmpl	$0x21, %eax
     d89:      	je	0x13a7 <generic_fexit_filter_arg+0x13a7>
     d8f:      	movl	$0x0, %ebx
     d94:      	cmpl	$0x22, %eax
     d97:      	jne	0x2c6b <generic_fexit_filter_arg+0x2c6b>
     d9d:      	movq	%rsi, 0x20(%rsp)
     da2:      	xorl	%ebx, %ebx
     da4:      	xorl	%r12d, %r12d
     da7:      	movl	0x10(%r15,%rbx,4), %eax
     dac:      	movl	%eax, 0x38(%rsp)
     db0:      	movl	$0x1, %eax
     db5:      	leaq	0x38(%rsp), %rsi
     dba:      	movq	(%rip), %rdi            # 0xdc1 <generic_fexit_filter_arg+0xdc1>
     dc1:      	callq	*%rax
     dc3:      	testq	%rax, %rax
     dc6:      	je	0x211a <generic_fexit_filter_arg+0x211a>
     dcc:      	testl	%ebp, %ebp
     dce:      	movq	0x10(%rsp), %r11
     dd3:      	je	0xe44 <generic_fexit_filter_arg+0xe44>
     dd5:      	movq	0x20(%rsp), %rdx
     dda:      	xorl	%ecx, %ecx
     ddc:      	jmp	0xde9 <generic_fexit_filter_arg+0xde9>
     dde:      	incq	%rcx
     de1:      	incq	%rdx
     de4:      	cmpq	%rbp, %rcx
     de7:      	je	0xe44 <generic_fexit_filter_arg+0xe44>
     de9:      	xorl	%esi, %esi
     deb:      	nopl	(%rax,%rax)
     df0:      	leaq	(%rcx,%rsi), %rdi
     df4:      	cmpq	%rbp, %rdi
     df7:      	jae	0xdde <generic_fexit_filter_arg+0xdde>
     df9:      	movsbl	(%rax,%rsi), %edi
     dfd:      	testl	%edi, %edi
     dff:      	je	0xe3c <generic_fexit_filter_arg+0xe3c>
     e01:      	movsbl	(%rdx,%rsi), %r9d
     e06:      	leal	-0x41(%r9), %r10d
     e0a:      	movl	%r9d, %r8d
     e0d:      	orl	$0x20, %r8d
     e11:      	cmpl	$0x1a, %r10d
     e15:      	cmovael	%r9d, %r8d
     e19:      	leal	-0x41(%rdi), %r10d
     e1d:      	movl	%edi, %r9d
     e20:      	orl	$0x20, %r9d
     e24:      	cmpl	$0x1a, %r10d
     e28:      	cmovael	%edi, %r9d
     e2c:      	cmpq	$0x62, %rsi
     e30:      	ja	0xdde <generic_fexit_filter_arg+0xdde>
     e32:      	incq	%rsi
     e35:      	cmpl	%r9d, %r8d
     e38:      	je	0xdf0 <generic_fexit_filter_arg+0xdf0>
     e3a:      	jmp	0xdde <generic_fexit_filter_arg+0xdde>
     e3c:      	testl	%ecx, %ecx
     e3e:      	jns	0x23f8 <generic_fexit_filter_arg+0x23f8>
     e44:      	leal	0xc(%r12), %eax
     e49:      	cmpl	0x8(%r15), %eax
     e4d:      	jae	0xe60 <generic_fexit_filter_arg+0xe60>
     e4f:      	addl	$0x4, %r12d
     e53:      	incq	%rbx
     e56:      	cmpq	$0x64, %rbx
     e5a:      	jne	0xda7 <generic_fexit_filter_arg+0xda7>
     e60:      	xorl	%ebx, %ebx
     e62:      	jmp	0x23fd <generic_fexit_filter_arg+0x23fd>
     e67:      	movq	%rsi, 0x20(%rsp)
     e6c:      	movl	0x10(%r15), %eax
     e70:      	movl	%eax, 0x38(%rsp)
     e74:      	movl	$0x0, 0x70(%rsp)
     e7c:      	movl	$0x1, %eax
     e81:      	leaq	0x38(%rsp), %rsi
     e86:      	movq	(%rip), %rdi            # 0xe8d <generic_fexit_filter_arg+0xe8d>
     e8d:      	callq	*%rax
     e8f:      	testl	%ebp, %ebp
     e91:      	je	0x2c5b <generic_fexit_filter_arg+0x2c5b>
     e97:      	movl	$0x0, %ebx
     e9c:      	testq	%rax, %rax
     e9f:      	je	0x2c5d <generic_fexit_filter_arg+0x2c5d>
     ea5:      	movq	%rax, 0x18(%rsp)
     eaa:      	movl	$0x1, %eax
     eaf:      	movq	0x30(%rsp), %rsi
     eb4:      	movq	(%rip), %rdi            # 0xebb <generic_fexit_filter_arg+0xebb>
     ebb:      	callq	*%rax
     ebd:      	testq	%rax, %rax
     ec0:      	je	0x2c5b <generic_fexit_filter_arg+0x2c5b>
     ec6:      	cmpl	$0xff, %ebp
     ecc:      	movl	$0xff, %ecx
     ed1:      	cmovael	%ecx, %ebp
     ed4:      	leal	(,%rbp,8), %ecx
     edb:      	movl	%ecx, (%rax)
     edd:      	movq	%rax, %rdi
     ee0:      	addq	$0x4, %rdi
     ee4:      	movq	%rax, %rbx
     ee7:      	movl	$0x4, %eax
     eec:      	movq	0x20(%rsp), %rdx
     ef1:      	movl	%ebp, %esi
     ef3:      	callq	*%rax
     ef5:      	movl	$0x1, %eax
     efa:      	movq	0x18(%rsp), %rdi
     eff:      	movq	%rbx, %rsi
     f02:      	jmp	0x2c4f <generic_fexit_filter_arg+0x2c4f>
     f07:      	movl	$0x0, 0x70(%rsp)
     f0f:      	cmpl	$0x1fe, %ebp            # imm = 0x1FE
     f15:      	jbe	0x1452 <generic_fexit_filter_arg+0x1452>
     f1b:      	xorl	%ebx, %ebx
     f1d:      	movl	0x4(%r15), %eax
     f21:      	cmpq	$0x25, %rax
     f25:      	jbe	0x2c79 <generic_fexit_filter_arg+0x2c79>
     f2b:      	jmp	0x265 <generic_fexit_filter_arg+0x265>
     f30:      	movq	0x10(%r15), %rsi
     f34:      	movq	0x18(%r15), %rax
     f38:      	cmpl	$0xc, %ecx
     f3b:      	je	0xf46 <generic_fexit_filter_arg+0xf46>
     f3d:      	cmpl	$0xa, %ecx
     f40:      	jne	0x19c9 <generic_fexit_filter_arg+0x19c9>
     f46:      	movq	(%rbp), %rdx
     f4a:      	cmpq	%rdx, %rsi
     f4d:      	setle	%sil
     f51:      	cmpq	%rax, %rdx
     f54:      	setle	%al
     f57:      	jmp	0x19da <generic_fexit_filter_arg+0x19da>
     f5c:      	cmpl	$0xd, %eax
     f5f:      	je	0x12e6 <generic_fexit_filter_arg+0x12e6>
     f65:      	cmpl	$0xe, %eax
     f68:      	je	0x12dc <generic_fexit_filter_arg+0x12dc>
     f6e:      	movl	$0x0, %ebx
     f73:      	cmpl	$0xf, %eax
     f76:      	je	0x1273 <generic_fexit_filter_arg+0x1273>
     f7c:      	jmp	0x260 <generic_fexit_filter_arg+0x260>
     f81:      	cmpl	$0x20, %eax
     f84:      	movq	%rsi, 0x20(%rsp)
     f89:      	jg	0x14ef <generic_fexit_filter_arg+0x14ef>
     f8f:      	cmpl	$0x1a, %eax
     f92:      	je	0x16c0 <generic_fexit_filter_arg+0x16c0>
     f98:      	movl	$0x0, %ebx
     f9d:      	cmpl	$0x1b, %eax
     fa0:      	jne	0x2ef2 <generic_fexit_filter_arg+0x2ef2>
     fa6:      	movl	0x10(%r15), %eax
     faa:      	movl	%eax, 0x38(%rsp)
     fae:      	movl	$0x0, 0x70(%rsp)
     fb6:      	movl	$0x1, %eax
     fbb:      	leaq	0x38(%rsp), %rsi
     fc0:      	movq	(%rip), %rdi            # 0xfc7 <generic_fexit_filter_arg+0xfc7>
     fc7:      	callq	*%rax
     fc9:      	testl	%ebp, %ebp
     fcb:      	je	0x2ee2 <generic_fexit_filter_arg+0x2ee2>
     fd1:      	movq	%rax, %r12
     fd4:      	movl	$0x0, %ebx
     fd9:      	testq	%rax, %rax
     fdc:      	je	0x2ee4 <generic_fexit_filter_arg+0x2ee4>
     fe2:      	movl	$0x1, %eax
     fe7:      	movq	0x30(%rsp), %rsi
     fec:      	movq	(%rip), %rdi            # 0xff3 <generic_fexit_filter_arg+0xff3>
     ff3:      	callq	*%rax
     ff5:      	testq	%rax, %rax
     ff8:      	je	0x2ee2 <generic_fexit_filter_arg+0x2ee2>
     ffe:      	movq	%rax, %rdi
    1001:      	movq	%r12, 0x18(%rsp)
    1006:      	cmpl	$0x7f, %ebp
    1009:      	movl	$0x7f, %eax
    100e:      	cmovbl	%ebp, %eax
    1011:      	shll	$0x3, %eax
    1014:      	movl	%eax, (%rdi)
    1016:      	movq	%rbp, %rax
    1019:      	negq	%rax
    101c:      	movl	$0x3, %ecx
    1021:      	subq	%rbp, %rcx
    1024:      	leal	-0x4(%rbp), %edx
    1027:      	movq	%rdi, 0x60(%rsp)
    102c:      	addq	$0x7, %rdi
    1030:      	movl	$0x2, %r8d
    1036:      	subq	%rbp, %r8
    1039:      	leal	-0x3(%rbp), %r9d
    103d:      	movl	$0x1, %r10d
    1043:      	subq	%rbp, %r10
    1046:      	leal	-0x2(%rbp), %r11d
    104a:      	decl	%ebp
    104c:      	xorl	%ebx, %ebx
    104e:      	movq	0x20(%rsp), %rsi
    1053:      	leal	(%rbx,%rbp), %r12d
    1057:      	andl	$0xfff, %r12d           # imm = 0xFFF
    105e:      	movzbl	(%rsi,%r12), %r12d
    1063:      	movb	%r12b, -0x3(%rdi)
    1067:      	cmpq	%rbx, %r10
    106a:      	je	0x10c4 <generic_fexit_filter_arg+0x10c4>
    106c:      	leal	(%r11,%rbx), %r12d
    1070:      	andl	$0xfff, %r12d           # imm = 0xFFF
    1077:      	movzbl	(%rsi,%r12), %r12d
    107c:      	movb	%r12b, -0x2(%rdi)
    1080:      	cmpq	%rbx, %r8
    1083:      	je	0x10c4 <generic_fexit_filter_arg+0x10c4>
    1085:      	leal	(%r9,%rbx), %r12d
    1089:      	andl	$0xfff, %r12d           # imm = 0xFFF
    1090:      	movzbl	(%rsi,%r12), %r12d
    1095:      	movb	%r12b, -0x1(%rdi)
    1099:      	cmpq	%rbx, %rcx
    109c:      	je	0x10c4 <generic_fexit_filter_arg+0x10c4>
    109e:      	cmpq	$-0x7c, %rbx
    10a2:      	je	0x10c4 <generic_fexit_filter_arg+0x10c4>
    10a4:      	leal	(%rdx,%rbx), %r12d
    10a8:      	andl	$0xfff, %r12d           # imm = 0xFFF
    10af:      	movzbl	(%rsi,%r12), %r12d
    10b4:      	movb	%r12b, (%rdi)
    10b7:      	addq	$-0x4, %rbx
    10bb:      	addq	$0x4, %rdi
    10bf:      	cmpq	%rbx, %rax
    10c2:      	jne	0x1053 <generic_fexit_filter_arg+0x1053>
    10c4:      	movl	$0x1, %eax
    10c9:      	movq	0x18(%rsp), %rdi
    10ce:      	movq	0x60(%rsp), %rsi
    10d3:      	jmp	0x2ed6 <generic_fexit_filter_arg+0x2ed6>
    10d8:      	cmpl	$0xc, %eax
    10db:      	jne	0x2062 <generic_fexit_filter_arg+0x2062>
    10e1:      	testl	%edx, (%rbp)
    10e4:      	jne	0x276 <generic_fexit_filter_arg+0x276>
    10ea:      	jmp	0x2062 <generic_fexit_filter_arg+0x2062>
    10ef:      	movl	$0xc00, %edx            # imm = 0xC00
    10f4:      	btq	%rcx, %rdx
    10f8:      	jb	0x15c2 <generic_fexit_filter_arg+0x15c2>
    10fe:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
    1108:      	btq	%rcx, %rdx
    110c:      	jae	0xb8 <generic_fexit_filter_arg+0xb8>
    1112:      	cmpl	$0x1f, %eax
    1115:      	jne	0x1c93 <generic_fexit_filter_arg+0x1c93>
    111b:      	movzbl	(%rbp), %eax
    111f:      	jmp	0x1151 <generic_fexit_filter_arg+0x1151>
    1121:      	movl	$0xc00, %edx            # imm = 0xC00
    1126:      	btq	%rcx, %rdx
    112a:      	jb	0x15ff <generic_fexit_filter_arg+0x15ff>
    1130:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
    113a:      	btq	%rcx, %rdx
    113e:      	jae	0xb8 <generic_fexit_filter_arg+0xb8>
    1144:      	cmpl	$0x1f, %eax
    1147:      	jne	0x1c9d <generic_fexit_filter_arg+0x1c9d>
    114d:      	movzwl	(%rbp), %eax
    1151:      	cmpl	%eax, 0x10(%r15)
    1155:      	ja	0x1161 <generic_fexit_filter_arg+0x1161>
    1157:      	cmpl	%eax, 0x14(%r15)
    115b:      	jae	0x276 <generic_fexit_filter_arg+0x276>
    1161:      	movl	0x8(%r15), %ecx
    1165:      	cmpl	$0x11, %ecx
    1168:      	jb	0xb8 <generic_fexit_filter_arg+0xb8>
    116e:      	cmpl	%eax, 0x18(%r15)
    1172:      	ja	0x117e <generic_fexit_filter_arg+0x117e>
    1174:      	cmpl	%eax, 0x1c(%r15)
    1178:      	jae	0x276 <generic_fexit_filter_arg+0x276>
    117e:      	cmpl	$0x19, %ecx
    1181:      	jb	0xb8 <generic_fexit_filter_arg+0xb8>
    1187:      	cmpl	%eax, 0x20(%r15)
    118b:      	ja	0x1197 <generic_fexit_filter_arg+0x1197>
    118d:      	cmpl	%eax, 0x24(%r15)
    1191:      	jae	0x276 <generic_fexit_filter_arg+0x276>
    1197:      	cmpl	$0x21, %ecx
    119a:      	jb	0xb8 <generic_fexit_filter_arg+0xb8>
    11a0:      	cmpl	%eax, 0x28(%r15)
    11a4:      	ja	0xb8 <generic_fexit_filter_arg+0xb8>
    11aa:      	cmpl	%eax, 0x2c(%r15)
    11ae:      	jae	0x276 <generic_fexit_filter_arg+0x276>
    11b4:      	jmp	0xb8 <generic_fexit_filter_arg+0xb8>
    11b9:      	cmpl	$0xc, %ecx
    11bc:      	je	0x11c7 <generic_fexit_filter_arg+0x11c7>
    11be:      	cmpl	$0xa, %ecx
    11c1:      	jne	0x1a9a <generic_fexit_filter_arg+0x1a9a>
    11c7:      	cmpq	%rdx, (%rbp)
    11cb:      	jg	0x276 <generic_fexit_filter_arg+0x276>
    11d1:      	jmp	0x1ab0 <generic_fexit_filter_arg+0x1ab0>
    11d6:      	movzwl	%bp, %eax
    11d9:      	cmpl	$0x90, %eax
    11de:      	ja	0x17db <generic_fexit_filter_arg+0x17db>
    11e4:      	testw	%bp, %bp
    11e7:      	je	0x11f9 <generic_fexit_filter_arg+0x11f9>
    11e9:      	movl	%ebp, %eax
    11eb:      	movl	$0x18, %ecx
    11f0:      	cltd
    11f1:      	idivl	%ecx
    11f3:      	movl	%ebp, %esi
    11f5:      	testl	%edx, %edx
    11f7:      	je	0x121b <generic_fexit_filter_arg+0x121b>
    11f9:      	movl	%ebp, %eax
    11fb:      	movl	$0x18, %ecx
    1200:      	cltd
    1201:      	idivl	%ecx
    1203:      	shll	$0x3, %eax
    1206:      	leal	(%rax,%rax,2), %eax
    1209:      	addl	$0x18, %eax
    120c:      	movzwl	%ax, %esi
    120f:      	cmpl	$0x90, %esi
    1215:      	ja	0x17ef <generic_fexit_filter_arg+0x17ef>
    121b:      	movl	%esi, %eax
    121d:      	cltd
    121e:      	idivl	%ecx
    1220:      	decl	%eax
    1222:      	jmp	0x1800 <generic_fexit_filter_arg+0x1800>
    1227:      	movl	0x10(%r15), %esi
    122b:      	movl	0x14(%r15), %eax
    122f:      	cmpl	$0xc, %ecx
    1232:      	ja	0x1f0f <generic_fexit_filter_arg+0x1f0f>
    1238:      	movl	$0x1402, %edx           # imm = 0x1402
    123d:      	btl	%ecx, %edx
    1240:      	jae	0x1f0f <generic_fexit_filter_arg+0x1f0f>
    1246:      	movl	(%rbp), %edx
    1249:      	cmpl	%edx, %esi
    124b:      	setle	%sil
    124f:      	cmpl	%eax, %edx
    1251:      	setle	%al
    1254:      	jmp	0x1f1d <generic_fexit_filter_arg+0x1f1d>
    1259:      	cmpl	$0x12, %eax
    125c:      	je	0x1273 <generic_fexit_filter_arg+0x1273>
    125e:      	movl	$0x0, %ebx
    1263:      	cmpl	$0x13, %eax
    1266:      	jne	0x260 <generic_fexit_filter_arg+0x260>
    126c:      	movzwl	0x22(%rsi), %r12d
    1271:      	jmp	0x1278 <generic_fexit_filter_arg+0x1278>
    1273:      	movzwl	0x20(%rsi), %r12d
    1278:      	xorl	%edx, %edx
    127a:      	xorl	%ebp, %ebp
    127c:      	xorl	%r8d, %r8d
    127f:      	xorl	%ebx, %ebx
    1281:      	cmpl	$0x11, %eax
    1284:      	jg	0x12fe <generic_fexit_filter_arg+0x12fe>
    1286:      	leal	-0xd(%rax), %ecx
    1289:      	cmpl	$0x2, %ecx
    128c:      	jb	0x1331 <generic_fexit_filter_arg+0x1331>
    1292:      	leal	-0xf(%rax), %ecx
    1295:      	cmpl	$0x2, %ecx
    1298:      	jb	0x14af <generic_fexit_filter_arg+0x14af>
    129e:      	cmpl	$0x11, %eax
    12a1:      	je	0x1a17 <generic_fexit_filter_arg+0x1a17>
    12a7:      	jmp	0x260 <generic_fexit_filter_arg+0x260>
    12ac:      	cmpl	$0x1c, %eax
    12af:      	je	0x1a13 <generic_fexit_filter_arg+0x1a13>
    12b5:      	movl	$0x0, %ebx
    12ba:      	cmpl	$0x1d, %eax
    12bd:      	jne	0x260 <generic_fexit_filter_arg+0x260>
    12c3:      	cmpl	$0x7, %ecx
    12c6:      	jne	0x1ff2 <generic_fexit_filter_arg+0x1ff2>
    12cc:      	testq	%rdx, %rdx
    12cf:      	jne	0x1ffe <generic_fexit_filter_arg+0x1ffe>
    12d5:      	xorl	%ebx, %ebx
    12d7:      	jmp	0x2010 <generic_fexit_filter_arg+0x2010>
    12dc:      	movq	0x10(%rsi), %rdx
    12e0:      	movq	0x18(%rsi), %r8
    12e4:      	jmp	0x12ed <generic_fexit_filter_arg+0x12ed>
    12e6:      	movq	(%rsi), %rdx
    12e9:      	movq	0x8(%rsi), %r8
    12ed:      	movq	%rdx, %rbp
    12f0:      	shrq	$0x20, %rbp
    12f4:      	xorl	%r12d, %r12d
    12f7:      	xorl	%ebx, %ebx
    12f9:      	cmpl	$0x11, %eax
    12fc:      	jle	0x1286 <generic_fexit_filter_arg+0x1286>
    12fe:      	cmpl	$0x19, %eax
    1301:      	ja	0x14a3 <generic_fexit_filter_arg+0x14a3>
    1307:      	movl	$0x500000, %ecx         # imm = 0x500000
    130c:      	btl	%eax, %ecx
    130f:      	jb	0x17b5 <generic_fexit_filter_arg+0x17b5>
    1315:      	movl	$0xa00000, %ecx         # imm = 0xA00000
    131a:      	btl	%eax, %ecx
    131d:      	jb	0x17c8 <generic_fexit_filter_arg+0x17c8>
    1323:      	movl	$0x3000000, %ecx        # imm = 0x3000000
    1328:      	btl	%eax, %ecx
    132b:      	jae	0x14a3 <generic_fexit_filter_arg+0x14a3>
    1331:      	movzwl	0x26(%rsi), %eax
    1335:      	cmpl	$0xa, %eax
    1338:      	je	0x18e1 <generic_fexit_filter_arg+0x18e1>
    133e:      	cmpl	$0x2, %eax
    1341:      	jne	0x196f <generic_fexit_filter_arg+0x196f>
    1347:      	movq	%rdx, %rbx
    134a:      	movl	0x10(%r15), %eax
    134e:      	movl	%eax, 0x2c(%rsp)
    1352:      	movl	$0x1, %eax
    1357:      	leaq	0x2c(%rsp), %rsi
    135c:      	movq	(%rip), %rdi            # 0x1363 <generic_fexit_filter_arg+0x1363>
    1363:      	callq	*%rax
    1365:      	testq	%rax, %rax
    1368:      	je	0x1b60 <generic_fexit_filter_arg+0x1b60>
    136e:      	movq	%rax, %rdi
    1371:      	movl	$0x20, 0x70(%rsp)
    1379:      	movl	%ebx, 0x74(%rsp)
    137d:      	jmp	0x192f <generic_fexit_filter_arg+0x192f>
    1382:      	cmpl	$0xc, %ecx
    1385:      	ja	0x204e <generic_fexit_filter_arg+0x204e>
    138b:      	movl	$0x1402, %esi           # imm = 0x1402
    1390:      	btl	%ecx, %esi
    1393:      	jae	0x204e <generic_fexit_filter_arg+0x204e>
    1399:      	cmpl	%edx, (%rbp)
    139c:      	jg	0x276 <generic_fexit_filter_arg+0x276>
    13a2:      	jmp	0x2062 <generic_fexit_filter_arg+0x2062>
    13a7:      	movq	%rsi, 0x20(%rsp)
    13ac:      	xorl	%ebx, %ebx
    13ae:      	xorl	%r12d, %r12d
    13b1:      	movl	0x10(%r15,%rbx,4), %eax
    13b6:      	movl	%eax, 0x38(%rsp)
    13ba:      	movl	$0x1, %eax
    13bf:      	leaq	0x38(%rsp), %rsi
    13c4:      	movq	(%rip), %rdi            # 0x13cb <generic_fexit_filter_arg+0x13cb>
    13cb:      	callq	*%rax
    13cd:      	testq	%rax, %rax
    13d0:      	je	0x2109 <generic_fexit_filter_arg+0x2109>
    13d6:      	testl	%ebp, %ebp
    13d8:      	movq	0x8(%rsp), %r9
    13dd:      	movq	0x10(%rsp), %r11
    13e2:      	je	0x142f <generic_fexit_filter_arg+0x142f>
    13e4:      	movq	0x20(%rsp), %rdx
    13e9:      	xorl	%ecx, %ecx
    13eb:      	jmp	0x13f8 <generic_fexit_filter_arg+0x13f8>
    13ed:      	incq	%rcx
    13f0:      	incq	%rdx
    13f3:      	cmpq	%rbp, %rcx
    13f6:      	je	0x142f <generic_fexit_filter_arg+0x142f>
    13f8:      	xorl	%esi, %esi
    13fa:      	nopw	(%rax,%rax)
    1400:      	leaq	(%rcx,%rsi), %rdi
    1404:      	cmpq	%rbp, %rdi
    1407:      	jae	0x13ed <generic_fexit_filter_arg+0x13ed>
    1409:      	movzbl	(%rax,%rsi), %edi
    140d:      	testb	%dil, %dil
    1410:      	je	0x1427 <generic_fexit_filter_arg+0x1427>
    1412:      	cmpq	$0x62, %rsi
    1416:      	ja	0x13ed <generic_fexit_filter_arg+0x13ed>
    1418:      	leaq	0x1(%rsi), %r8
    141c:      	cmpb	%dil, (%rdx,%rsi)
    1420:      	movq	%r8, %rsi
    1423:      	je	0x1400 <generic_fexit_filter_arg+0x1400>
    1425:      	jmp	0x13ed <generic_fexit_filter_arg+0x13ed>
    1427:      	testl	%ecx, %ecx
    1429:      	jns	0x23d7 <generic_fexit_filter_arg+0x23d7>
    142f:      	leal	0xc(%r12), %eax
    1434:      	cmpl	0x8(%r15), %eax
    1438:      	jae	0x144b <generic_fexit_filter_arg+0x144b>
    143a:      	addl	$0x4, %r12d
    143e:      	incq	%rbx
    1441:      	cmpq	$0x64, %rbx
    1445:      	jne	0x13b1 <generic_fexit_filter_arg+0x13b1>
    144b:      	xorl	%ebx, %ebx
    144d:      	jmp	0x23dc <generic_fexit_filter_arg+0x23dc>
    1452:      	movzwl	%bp, %eax
    1455:      	cmpl	$0x90, %eax
    145a:      	ja	0x1b6f <generic_fexit_filter_arg+0x1b6f>
    1460:      	testw	%bp, %bp
    1463:      	je	0x1475 <generic_fexit_filter_arg+0x1475>
    1465:      	movl	%ebp, %eax
    1467:      	movl	$0x18, %ecx
    146c:      	cltd
    146d:      	idivl	%ecx
    146f:      	movl	%ebp, %edi
    1471:      	testl	%edx, %edx
    1473:      	je	0x1497 <generic_fexit_filter_arg+0x1497>
    1475:      	movl	%ebp, %eax
    1477:      	movl	$0x18, %ecx
    147c:      	cltd
    147d:      	idivl	%ecx
    147f:      	shll	$0x3, %eax
    1482:      	leal	(%rax,%rax,2), %eax
    1485:      	addl	$0x18, %eax
    1488:      	movzwl	%ax, %edi
    148b:      	cmpl	$0x90, %edi
    1491:      	ja	0x1b83 <generic_fexit_filter_arg+0x1b83>
    1497:      	movl	%edi, %eax
    1499:      	cltd
    149a:      	idivl	%ecx
    149c:      	decl	%eax
    149e:      	jmp	0x1b94 <generic_fexit_filter_arg+0x1b94>
    14a3:      	addl	$-0x12, %eax
    14a6:      	cmpl	$0x2, %eax
    14a9:      	jae	0x260 <generic_fexit_filter_arg+0x260>
    14af:      	movzbl	0x10(%r15), %eax
    14b4:      	movl	%eax, 0x2c(%rsp)
    14b8:      	movl	$0x1, %eax
    14bd:      	movq	(%rip), %rdi            # 0x14c4 <generic_fexit_filter_arg+0x14c4>
    14c4:      	leaq	0x2c(%rsp), %rsi
    14c9:      	callq	*%rax
    14cb:      	testq	%rax, %rax
    14ce:      	je	0x250 <generic_fexit_filter_arg+0x250>
    14d4:      	movq	%rax, %rdi
    14d7:      	movzwl	%r12w, %eax
    14db:      	movq	%rax, 0x70(%rsp)
    14e0:      	movl	$0x1, %eax
    14e5:      	movq	0x30(%rsp), %rsi
    14ea:      	jmp	0x1a51 <generic_fexit_filter_arg+0x1a51>
    14ef:      	cmpl	$0x21, %eax
    14f2:      	je	0x1d15 <generic_fexit_filter_arg+0x1d15>
    14f8:      	movl	$0x0, %ebx
    14fd:      	cmpl	$0x22, %eax
    1500:      	jne	0x2ef2 <generic_fexit_filter_arg+0x2ef2>
    1506:      	movl	$0x10, %r12d
    150c:      	movl	(%r15,%r12), %eax
    1510:      	movl	%eax, 0x38(%rsp)
    1514:      	movl	$0x1, %eax
    1519:      	leaq	0x38(%rsp), %rsi
    151e:      	movq	(%rip), %rdi            # 0x1525 <generic_fexit_filter_arg+0x1525>
    1525:      	callq	*%rax
    1527:      	testq	%rax, %rax
    152a:      	je	0x2ee2 <generic_fexit_filter_arg+0x2ee2>
    1530:      	movq	0x20(%rsp), %rdi
    1535:      	movq	%rax, %rsi
    1538:      	movq	%rbp, %rdx
    153b:      	callq	0x1540 <generic_fexit_filter_arg+0x1540>
    1540:      	testl	%eax, %eax
    1542:      	jns	0x26e8 <generic_fexit_filter_arg+0x26e8>
    1548:      	addq	$0x4, %r12
    154c:      	leal	-0x8(%r12), %eax
    1551:      	cmpl	0x8(%r15), %eax
    1555:      	movq	(%rsp), %rdi
    1559:      	movq	0x8(%rsp), %r9
    155e:      	movq	0x10(%rsp), %r11
    1563:      	jae	0x1768 <generic_fexit_filter_arg+0x1768>
    1569:      	movl	$0x0, %ebx
    156e:      	cmpq	$0x1a0, %r12            # imm = 0x1A0
    1575:      	jne	0x150c <generic_fexit_filter_arg+0x150c>
    1577:      	jmp	0x2ef2 <generic_fexit_filter_arg+0x2ef2>
    157c:      	cmpl	$0x1, %eax
    157f:      	je	0x1e17 <generic_fexit_filter_arg+0x1e17>
    1585:      	cmpl	$0x2, %eax
    1588:      	jne	0x1e23 <generic_fexit_filter_arg+0x1e23>
    158e:      	movzbl	(%rbp), %edx
    1592:      	cmpl	%edx, %ecx
    1594:      	ja	0x276 <generic_fexit_filter_arg+0x276>
    159a:      	jmp	0x1e23 <generic_fexit_filter_arg+0x1e23>
    159f:      	cmpl	$0x1, %eax
    15a2:      	je	0x1e5a <generic_fexit_filter_arg+0x1e5a>
    15a8:      	cmpl	$0x2, %eax
    15ab:      	jne	0x1e66 <generic_fexit_filter_arg+0x1e66>
    15b1:      	movzwl	(%rbp), %edx
    15b5:      	cmpl	%edx, %ecx
    15b7:      	ja	0x276 <generic_fexit_filter_arg+0x276>
    15bd:      	jmp	0x1e66 <generic_fexit_filter_arg+0x1e66>
    15c2:      	movzbl	0x10(%r15), %eax
    15c7:      	movl	%eax, 0x70(%rsp)
    15cb:      	movl	$0x1, %eax
    15d0:      	movq	0x30(%rsp), %rsi
    15d5:      	movq	(%rip), %rdi            # 0x15dc <generic_fexit_filter_arg+0x15dc>
    15dc:      	callq	*%rax
    15de:      	testq	%rax, %rax
    15e1:      	je	0x166d <generic_fexit_filter_arg+0x166d>
    15e7:      	movq	%rax, %rdi
    15ea:      	movzbl	(%rbp), %eax
    15ee:      	movq	%rax, 0x38(%rsp)
    15f3:      	movl	$0x1, %eax
    15f8:      	leaq	0x38(%rsp), %rsi
    15fd:      	jmp	0x1636 <generic_fexit_filter_arg+0x1636>
    15ff:      	movzbl	0x10(%r15), %eax
    1604:      	movl	%eax, 0x70(%rsp)
    1608:      	movl	$0x1, %eax
    160d:      	movq	0x30(%rsp), %rsi
    1612:      	movq	(%rip), %rdi            # 0x1619 <generic_fexit_filter_arg+0x1619>
    1619:      	callq	*%rax
    161b:      	testq	%rax, %rax
    161e:      	je	0x166d <generic_fexit_filter_arg+0x166d>
    1620:      	movq	%rax, %rdi
    1623:      	movzwl	(%rbp), %eax
    1627:      	movq	%rax, 0x38(%rsp)
    162c:      	movl	$0x1, %eax
    1631:      	leaq	0x38(%rsp), %rsi
    1636:      	callq	*%rax
    1638:      	movl	0x4(%r15), %edx
    163c:      	xorl	%ecx, %ecx
    163e:      	cmpl	$0x1d, %edx
    1641:      	ja	0x263d <generic_fexit_filter_arg+0x263d>
    1647:      	movl	$0x30038400, %esi       # imm = 0x30038400
    164c:      	btl	%edx, %esi
    164f:      	movq	(%rsp), %rdi
    1653:      	movq	0x8(%rsp), %r9
    1658:      	movq	0x10(%rsp), %r11
    165d:      	jae	0x1682 <generic_fexit_filter_arg+0x1682>
    165f:      	testq	%rax, %rax
    1662:      	setne	%cl
    1665:      	movzbl	%cl, %ebx
    1668:      	jmp	0x265 <generic_fexit_filter_arg+0x265>
    166d:      	xorl	%ebx, %ebx
    166f:      	movq	(%rsp), %rdi
    1673:      	movq	0x8(%rsp), %r9
    1678:      	movq	0x10(%rsp), %r11
    167d:      	jmp	0x265 <generic_fexit_filter_arg+0x265>
    1682:      	movl	$0xc0800, %esi          # imm = 0xC0800
    1687:      	btl	%edx, %esi
    168a:      	jae	0x1692 <generic_fexit_filter_arg+0x1692>
    168c:      	testq	%rax, %rax
    168f:      	sete	%cl
    1692:      	movzbl	%cl, %ebx
    1695:      	jmp	0x265 <generic_fexit_filter_arg+0x265>
    169a:      	testq	%rax, %rax
    169d:      	sete	%al
    16a0:      	movq	(%rsp), %rdi
    16a4:      	movq	0x8(%rsp), %r9
    16a9:      	movq	0x10(%rsp), %r11
    16ae:      	movzbl	%al, %ebx
    16b1:      	jmp	0x265 <generic_fexit_filter_arg+0x265>
    16b6:      	xorl	%eax, %eax
    16b8:      	movzbl	%al, %ebx
    16bb:      	jmp	0x265 <generic_fexit_filter_arg+0x265>
    16c0:      	movl	0x10(%r15), %eax
    16c4:      	movl	%eax, 0x38(%rsp)
    16c8:      	movl	$0x0, 0x70(%rsp)
    16d0:      	movl	$0x1, %eax
    16d5:      	leaq	0x38(%rsp), %rsi
    16da:      	movq	(%rip), %rdi            # 0x16e1 <generic_fexit_filter_arg+0x16e1>
    16e1:      	callq	*%rax
    16e3:      	testl	%ebp, %ebp
    16e5:      	je	0x2ee2 <generic_fexit_filter_arg+0x2ee2>
    16eb:      	movq	%rax, %r12
    16ee:      	movl	$0x0, %ebx
    16f3:      	testq	%rax, %rax
    16f6:      	je	0x2ee4 <generic_fexit_filter_arg+0x2ee4>
    16fc:      	movl	$0x1, %eax
    1701:      	movq	0x30(%rsp), %rsi
    1706:      	movq	(%rip), %rdi            # 0x170d <generic_fexit_filter_arg+0x170d>
    170d:      	callq	*%rax
    170f:      	testq	%rax, %rax
    1712:      	je	0x2ee2 <generic_fexit_filter_arg+0x2ee2>
    1718:      	cmpl	$0xff, %ebp
    171e:      	movl	$0xff, %ecx
    1723:      	cmovael	%ecx, %ebp
    1726:      	leal	(,%rbp,8), %ecx
    172d:      	movl	%ecx, (%rax)
    172f:      	movq	%rax, %rdi
    1732:      	addq	$0x4, %rdi
    1736:      	movq	%rax, %rbx
    1739:      	movl	$0x4, %eax
    173e:      	movq	0x20(%rsp), %rdx
    1743:      	movl	%ebp, %esi
    1745:      	callq	*%rax
    1747:      	movl	$0x1, %eax
    174c:      	movq	%r12, %rdi
    174f:      	jmp	0x2ed3 <generic_fexit_filter_arg+0x2ed3>
    1754:      	movl	$0x0, 0x70(%rsp)
    175c:      	cmpl	$0x1fe, %ebp            # imm = 0x1FE
    1762:      	jbe	0x1dc6 <generic_fexit_filter_arg+0x1dc6>
    1768:      	xorl	%ebx, %ebx
    176a:      	jmp	0x2ef2 <generic_fexit_filter_arg+0x2ef2>
    176f:      	cmpl	$0x1e, %eax
    1772:      	jne	0xb8 <generic_fexit_filter_arg+0xb8>
    1778:      	movl	0x10(%r15), %eax
    177c:      	andl	$0x7, %eax
    177f:      	movl	%eax, %ecx
    1781:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
    178a:      	jne	0xb8 <generic_fexit_filter_arg+0xb8>
    1790:      	movq	(%rbp), %rcx
    1794:      	movq	0x5e78(%r14,%rax,8), %rax
    179c:      	andl	$0x7ff, %eax            # imm = 0x7FF
    17a1:      	xorl	%ebx, %ebx
    17a3:      	andnq	0x90(%r14,%rax), %rcx, %rax
    17ad:      	setne	%bl
    17b0:      	jmp	0x265 <generic_fexit_filter_arg+0x265>
    17b5:      	movzwl	%r12w, %eax
    17b9:      	xorl	%ebx, %ebx
    17bb:      	cmpl	$0x400, %eax            # imm = 0x400
    17c0:      	setb	%bl
    17c3:      	jmp	0x260 <generic_fexit_filter_arg+0x260>
    17c8:      	movzwl	%r12w, %eax
    17cc:      	xorl	%ebx, %ebx
    17ce:      	cmpl	$0x400, %eax            # imm = 0x400
    17d3:      	setae	%bl
    17d6:      	jmp	0x260 <generic_fexit_filter_arg+0x260>
    17db:      	cmpl	$0x101, %eax            # imm = 0x101
    17e0:      	movl	$0x100, %esi            # imm = 0x100
    17e5:      	movl	$0x1fe, %eax            # imm = 0x1FE
    17ea:      	cmovael	%eax, %esi
    17ed:      	movl	%esi, %eax
    17ef:      	movzwl	%ax, %ecx
    17f2:      	xorl	%eax, %eax
    17f4:      	cmpl	$0x100, %ecx            # imm = 0x100
    17fa:      	sete	%al
    17fd:      	xorl	$0x7, %eax
    1800:      	movl	%eax, %ecx
    1802:      	andl	$0xf, %ecx
    1805:      	movl	0x10(%r15,%rcx,4), %ecx
    180a:      	cmpl	$-0x1, %ecx
    180d:      	je	0x2aa6 <generic_fexit_filter_arg+0x2aa6>
    1813:      	movl	%ecx, 0x90(%rsp)
    181a:      	movq	%rsi, 0x88(%rsp)
    1822:      	movl	%eax, 0x60(%rsp)
    1826:      	movl	$0x1, %eax
    182b:      	movq	(%rip), %rdi            # 0x1832 <generic_fexit_filter_arg+0x1832>
    1832:      	movq	0x30(%rsp), %rbx
    1837:      	movq	%rbx, %rsi
    183a:      	callq	*%rax
    183c:      	movq	%rax, 0x18(%rsp)
    1841:      	movl	$0x1, %eax
    1846:      	movq	(%rip), %rdi            # 0x184d <generic_fexit_filter_arg+0x184d>
    184d:      	movq	%rbx, %rsi
    1850:      	callq	*%rax
    1852:      	cmpq	$0x0, 0x18(%rsp)
    1858:      	je	0x2aa6 <generic_fexit_filter_arg+0x2aa6>
    185e:      	movl	$0x0, %ebx
    1863:      	testq	%rax, %rax
    1866:      	movq	(%rsp), %rdi
    186a:      	movq	0x8(%rsp), %r9
    186f:      	movq	0x10(%rsp), %r11
    1874:      	je	0x2ab6 <generic_fexit_filter_arg+0x2ab6>
    187a:      	movq	%rax, 0x98(%rsp)
    1882:      	movq	0x20(%rsp), %rdx
    1887:      	addq	$0x4, %rdx
    188b:      	movl	0x60(%rsp), %ebx
    188f:      	cmpl	$0x5, %ebx
    1892:      	jg	0x216c <generic_fexit_filter_arg+0x216c>
    1898:      	movq	0x18(%rsp), %rax
    189d:      	movb	%bpl, (%rax)
    18a0:      	leaq	0x1(%rax), %rdi
    18a4:      	movl	$0x4, %eax
    18a9:      	movl	%ebp, %esi
    18ab:      	callq	*%rax
    18ad:      	movq	0x88(%rsp), %rsi
    18b5:      	subl	%ebp, %esi
    18b7:      	jbe	0x21af <generic_fexit_filter_arg+0x21af>
    18bd:      	movq	0x18(%rsp), %rax
    18c2:      	leaq	(%rax,%rbp), %rdi
    18c6:      	incq	%rdi
    18c9:      	andl	$0xfff, %esi            # imm = 0xFFF
    18cf:      	movl	$0x4, %eax
    18d4:      	movq	0x98(%rsp), %rdx
    18dc:      	jmp	0x21ad <generic_fexit_filter_arg+0x21ad>
    18e1:      	movq	%r8, %r12
    18e4:      	movq	%rdx, %rbx
    18e7:      	movl	0x14(%r15), %eax
    18eb:      	movl	%eax, 0x2c(%rsp)
    18ef:      	movl	$0x1, %eax
    18f4:      	movq	(%rip), %rdi            # 0x18fb <generic_fexit_filter_arg+0x18fb>
    18fb:      	leaq	0x2c(%rsp), %rsi
    1900:      	callq	*%rax
    1902:      	testq	%rax, %rax
    1905:      	je	0x1b60 <generic_fexit_filter_arg+0x1b60>
    190b:      	movq	%rax, %rdi
    190e:      	movl	$0x80, 0x70(%rsp)
    1916:      	movl	%ebx, 0x74(%rsp)
    191a:      	movl	%ebp, 0x78(%rsp)
    191e:      	movl	%r12d, 0x7c(%rsp)
    1923:      	shrq	$0x20, %r12
    1927:      	movl	%r12d, 0x80(%rsp)
    192f:      	movl	$0x1, %eax
    1934:      	movq	0x30(%rsp), %rsi
    1939:      	callq	*%rax
    193b:      	movl	0x4(%r15), %ecx
    193f:      	leal	-0x18(%rcx), %edx
    1942:      	cmpl	$0x2, %edx
    1945:      	jb	0x1e9d <generic_fexit_filter_arg+0x1e9d>
    194b:      	addl	$-0xd, %ecx
    194e:      	cmpl	$0x1, %ecx
    1951:      	movq	(%rsp), %rdi
    1955:      	movq	0x8(%rsp), %r9
    195a:      	movq	0x10(%rsp), %r11
    195f:      	ja	0x196f <generic_fexit_filter_arg+0x196f>
    1961:      	testq	%rax, %rax
    1964:      	setne	%al
    1967:      	movzbl	%al, %ebx
    196a:      	jmp	0x260 <generic_fexit_filter_arg+0x260>
    196f:      	xorl	%eax, %eax
    1971:      	movzbl	%al, %ebx
    1974:      	jmp	0x260 <generic_fexit_filter_arg+0x260>
    1979:      	movq	(%rbp), %rax
    197d:      	cmpq	%rax, %rsi
    1980:      	ja	0x198b <generic_fexit_filter_arg+0x198b>
    1982:      	cmpq	%rdx, %rax
    1985:      	jbe	0x276 <generic_fexit_filter_arg+0x276>
    198b:      	movl	0x8(%r15), %edx
    198f:      	cmpl	$0x19, %edx
    1992:      	jb	0xb8 <generic_fexit_filter_arg+0xb8>
    1998:      	movq	0x20(%r15), %rdi
    199c:      	movq	0x28(%r15), %rsi
    19a0:      	cmpl	$0xc, %ecx
    19a3:      	je	0x19ae <generic_fexit_filter_arg+0x19ae>
    19a5:      	cmpl	$0xa, %ecx
    19a8:      	jne	0x1fa6 <generic_fexit_filter_arg+0x1fa6>
    19ae:      	cmpq	%rax, %rdi
    19b1:      	movq	(%rsp), %rdi
    19b5:      	jg	0x1fb8 <generic_fexit_filter_arg+0x1fb8>
    19bb:      	cmpq	%rsi, %rax
    19be:      	jle	0x276 <generic_fexit_filter_arg+0x276>
    19c4:      	jmp	0x1fb8 <generic_fexit_filter_arg+0x1fb8>
    19c9:      	movq	(%rbp), %rdx
    19cd:      	cmpq	%rdx, %rsi
    19d0:      	setbe	%sil
    19d4:      	cmpq	%rax, %rdx
    19d7:      	setbe	%al
    19da:      	andb	%sil, %al
    19dd:      	movl	0x8(%r15), %esi
    19e1:      	cmpl	$0x19, %esi
    19e4:      	jb	0x2af3 <generic_fexit_filter_arg+0x2af3>
    19ea:      	movq	0x20(%r15), %r8
    19ee:      	movq	0x28(%r15), %rdi
    19f2:      	cmpl	$0xc, %ecx
    19f5:      	je	0x1a00 <generic_fexit_filter_arg+0x1a00>
    19f7:      	cmpl	$0xa, %ecx
    19fa:      	jne	0x1f60 <generic_fexit_filter_arg+0x1f60>
    1a00:      	cmpq	%rdx, %r8
    1a03:      	setle	%r8b
    1a07:      	cmpq	%rdi, %rdx
    1a0a:      	setle	%dil
    1a0e:      	jmp	0x1f6e <generic_fexit_filter_arg+0x1f6e>
    1a13:      	movzwl	0x26(%rsi), %ebx
    1a17:      	movzbl	0x10(%r15), %eax
    1a1c:      	movl	%eax, 0x2c(%rsp)
    1a20:      	movl	$0x1, %eax
    1a25:      	movq	(%rip), %rdi            # 0x1a2c <generic_fexit_filter_arg+0x1a2c>
    1a2c:      	leaq	0x2c(%rsp), %rsi
    1a31:      	callq	*%rax
    1a33:      	testq	%rax, %rax
    1a36:      	je	0x250 <generic_fexit_filter_arg+0x250>
    1a3c:      	movq	%rax, %rdi
    1a3f:      	movzwl	%bx, %eax
    1a42:      	movq	%rax, 0x70(%rsp)
    1a47:      	movl	$0x1, %eax
    1a4c:      	movq	0x30(%rsp), %rsi
    1a51:      	callq	*%rax
    1a53:      	movl	0x4(%r15), %edx
    1a57:      	xorl	%ecx, %ecx
    1a59:      	cmpl	$0x1d, %edx
    1a5c:      	ja	0x2653 <generic_fexit_filter_arg+0x2653>
    1a62:      	movl	$0x30038400, %esi       # imm = 0x30038400
    1a67:      	btl	%edx, %esi
    1a6a:      	movq	(%rsp), %rdi
    1a6e:      	movq	0x8(%rsp), %r9
    1a73:      	movq	0x10(%rsp), %r11
    1a78:      	jae	0x1a82 <generic_fexit_filter_arg+0x1a82>
    1a7a:      	testq	%rax, %rax
    1a7d:      	setne	%cl
    1a80:      	jmp	0x1a92 <generic_fexit_filter_arg+0x1a92>
    1a82:      	movl	$0xc0800, %esi          # imm = 0xC0800
    1a87:      	btl	%edx, %esi
    1a8a:      	jae	0x1a92 <generic_fexit_filter_arg+0x1a92>
    1a8c:      	testq	%rax, %rax
    1a8f:      	sete	%cl
    1a92:      	movzbl	%cl, %ebx
    1a95:      	jmp	0x260 <generic_fexit_filter_arg+0x260>
    1a9a:      	cmpq	%rdx, (%rbp)
    1a9e:      	ja	0x276 <generic_fexit_filter_arg+0x276>
    1aa4:      	jmp	0x1ab0 <generic_fexit_filter_arg+0x1ab0>
    1aa6:      	cmpq	%rdx, (%rbp)
    1aaa:      	jb	0x276 <generic_fexit_filter_arg+0x276>
    1ab0:      	movl	0x8(%r15), %edx
    1ab4:      	cmpl	$0x11, %edx
    1ab7:      	jb	0x2f69 <generic_fexit_filter_arg+0x2f69>
    1abd:      	movq	0x18(%r15), %rsi
    1ac1:      	cmpl	$0x2, %eax
    1ac4:      	jle	0x1ae1 <generic_fexit_filter_arg+0x1ae1>
    1ac6:      	leal	-0x3(%rax), %edi
    1ac9:      	cmpl	$0x2, %edi
    1acc:      	jae	0x1b10 <generic_fexit_filter_arg+0x1b10>
    1ace:      	cmpq	%rsi, (%rbp)
    1ad2:      	movq	(%rsp), %rdi
    1ad6:      	jne	0x2591 <generic_fexit_filter_arg+0x2591>
    1adc:      	jmp	0x2e81 <generic_fexit_filter_arg+0x2e81>
    1ae1:      	cmpl	$0x1, %eax
    1ae4:      	je	0x1c76 <generic_fexit_filter_arg+0x1c76>
    1aea:      	cmpl	$0x2, %eax
    1aed:      	jne	0x2591 <generic_fexit_filter_arg+0x2591>
    1af3:      	cmpl	$0xc, %ecx
    1af6:      	je	0x1b01 <generic_fexit_filter_arg+0x1b01>
    1af8:      	cmpl	$0xa, %ecx
    1afb:      	jne	0x2587 <generic_fexit_filter_arg+0x2587>
    1b01:      	cmpq	%rsi, (%rbp)
    1b05:      	jl	0x276 <generic_fexit_filter_arg+0x276>
    1b0b:      	jmp	0x2591 <generic_fexit_filter_arg+0x2591>
    1b10:      	cmpl	$0xc, %eax
    1b13:      	movq	(%rsp), %rdi
    1b17:      	jne	0x2591 <generic_fexit_filter_arg+0x2591>
    1b1d:      	testq	%rsi, (%rbp)
    1b21:      	jne	0x276 <generic_fexit_filter_arg+0x276>
    1b27:      	jmp	0x2591 <generic_fexit_filter_arg+0x2591>
    1b2c:      	cmpl	$0xc, %eax
    1b2f:      	jne	0x1e23 <generic_fexit_filter_arg+0x1e23>
    1b35:      	movzbl	(%rbp), %edx
    1b39:      	testl	%edx, %ecx
    1b3b:      	jne	0x276 <generic_fexit_filter_arg+0x276>
    1b41:      	jmp	0x1e23 <generic_fexit_filter_arg+0x1e23>
    1b46:      	cmpl	$0xc, %eax
    1b49:      	jne	0x1e66 <generic_fexit_filter_arg+0x1e66>
    1b4f:      	movzwl	(%rbp), %edx
    1b53:      	testl	%edx, %ecx
    1b55:      	jne	0x276 <generic_fexit_filter_arg+0x276>
    1b5b:      	jmp	0x1e66 <generic_fexit_filter_arg+0x1e66>
    1b60:      	movl	0x4(%r15), %eax
    1b64:      	andl	$-0x2, %eax
    1b67:      	cmpl	$0x18, %eax
    1b6a:      	jmp	0x1ea0 <generic_fexit_filter_arg+0x1ea0>
    1b6f:      	cmpl	$0x101, %eax            # imm = 0x101
    1b74:      	movl	$0x100, %edi            # imm = 0x100
    1b79:      	movl	$0x1fe, %eax            # imm = 0x1FE
    1b7e:      	cmovael	%eax, %edi
    1b81:      	movl	%edi, %eax
    1b83:      	movzwl	%ax, %ecx
    1b86:      	xorl	%eax, %eax
    1b88:      	cmpl	$0x100, %ecx            # imm = 0x100
    1b8e:      	sete	%al
    1b91:      	xorl	$0x7, %eax
    1b94:      	movl	%eax, %ecx
    1b96:      	andl	$0xf, %ecx
    1b99:      	movl	0x10(%r15,%rcx,4), %ecx
    1b9e:      	cmpl	$-0x1, %ecx
    1ba1:      	je	0x2c5b <generic_fexit_filter_arg+0x2c5b>
    1ba7:      	movl	%ecx, 0x90(%rsp)
    1bae:      	movq	%rdi, 0x88(%rsp)
    1bb6:      	movl	%eax, 0x60(%rsp)
    1bba:      	movq	%rsi, 0x20(%rsp)
    1bbf:      	movl	$0x1, %eax
    1bc4:      	movq	(%rip), %rdi            # 0x1bcb <generic_fexit_filter_arg+0x1bcb>
    1bcb:      	movq	0x30(%rsp), %rbx
    1bd0:      	movq	%rbx, %rsi
    1bd3:      	callq	*%rax
    1bd5:      	movq	%rax, 0x18(%rsp)
    1bda:      	movl	$0x1, %eax
    1bdf:      	movq	(%rip), %rdi            # 0x1be6 <generic_fexit_filter_arg+0x1be6>
    1be6:      	movq	%rbx, %rsi
    1be9:      	callq	*%rax
    1beb:      	cmpq	$0x0, 0x18(%rsp)
    1bf1:      	je	0x2c5b <generic_fexit_filter_arg+0x2c5b>
    1bf7:      	movl	$0x0, %ebx
    1bfc:      	testq	%rax, %rax
    1bff:      	movq	(%rsp), %rdi
    1c03:      	movq	0x8(%rsp), %r9
    1c08:      	movq	0x10(%rsp), %r11
    1c0d:      	je	0x2c6b <generic_fexit_filter_arg+0x2c6b>
    1c13:      	movq	%rax, 0x98(%rsp)
    1c1b:      	movl	0x60(%rsp), %ebx
    1c1f:      	cmpl	$0x5, %ebx
    1c22:      	jg	0x2466 <generic_fexit_filter_arg+0x2466>
    1c28:      	movq	0x18(%rsp), %rax
    1c2d:      	movb	%bpl, (%rax)
    1c30:      	leaq	0x1(%rax), %rdi
    1c34:      	movl	$0x4, %eax
    1c39:      	movq	0x20(%rsp), %rdx
    1c3e:      	movl	%ebp, %esi
    1c40:      	callq	*%rax
    1c42:      	movq	0x88(%rsp), %rsi
    1c4a:      	subl	%ebp, %esi
    1c4c:      	jbe	0x24ae <generic_fexit_filter_arg+0x24ae>
    1c52:      	movq	0x18(%rsp), %rax
    1c57:      	leaq	(%rax,%rbp), %rdi
    1c5b:      	incq	%rdi
    1c5e:      	andl	$0xfff, %esi            # imm = 0xFFF
    1c64:      	movl	$0x4, %eax
    1c69:      	movq	0x98(%rsp), %rdx
    1c71:      	jmp	0x24ac <generic_fexit_filter_arg+0x24ac>
    1c76:      	cmpl	$0xc, %ecx
    1c79:      	je	0x1c84 <generic_fexit_filter_arg+0x1c84>
    1c7b:      	cmpl	$0xa, %ecx
    1c7e:      	jne	0x257b <generic_fexit_filter_arg+0x257b>
    1c84:      	cmpq	%rsi, (%rbp)
    1c88:      	jg	0x276 <generic_fexit_filter_arg+0x276>
    1c8e:      	jmp	0x2591 <generic_fexit_filter_arg+0x2591>
    1c93:      	movl	0x8(%r15), %edx
    1c97:      	movzbl	(%rbp), %ecx
    1c9b:      	jmp	0x1ca5 <generic_fexit_filter_arg+0x1ca5>
    1c9d:      	movl	0x8(%r15), %edx
    1ca1:      	movzwl	(%rbp), %ecx
    1ca5:      	cmpl	%ecx, 0x10(%r15)
    1ca9:      	setbe	%sil
    1cad:      	cmpl	%ecx, 0x14(%r15)
    1cb1:      	setae	%al
    1cb4:      	andb	%sil, %al
    1cb7:      	cmpl	$0x11, %edx
    1cba:      	jb	0x2af3 <generic_fexit_filter_arg+0x2af3>
    1cc0:      	cmpl	%ecx, 0x18(%r15)
    1cc4:      	setbe	%sil
    1cc8:      	cmpl	%ecx, 0x1c(%r15)
    1ccc:      	setae	%dil
    1cd0:      	andb	%sil, %dil
    1cd3:      	orb	%dil, %al
    1cd6:      	cmpl	$0x19, %edx
    1cd9:      	jb	0x2aef <generic_fexit_filter_arg+0x2aef>
    1cdf:      	cmpl	%ecx, 0x20(%r15)
    1ce3:      	setbe	%sil
    1ce7:      	cmpl	%ecx, 0x24(%r15)
    1ceb:      	setae	%dil
    1cef:      	andb	%sil, %dil
    1cf2:      	orb	%dil, %al
    1cf5:      	cmpl	$0x21, %edx
    1cf8:      	jb	0x2aef <generic_fexit_filter_arg+0x2aef>
    1cfe:      	cmpl	%ecx, 0x28(%r15)
    1d02:      	setbe	%dl
    1d05:      	cmpl	%ecx, 0x2c(%r15)
    1d09:      	setae	%cl
    1d0c:      	andb	%dl, %cl
    1d0e:      	orb	%cl, %al
    1d10:      	jmp	0x2aef <generic_fexit_filter_arg+0x2aef>
    1d15:      	xorl	%ebx, %ebx
    1d17:      	xorl	%r12d, %r12d
    1d1a:      	movl	0x10(%r15,%rbx,4), %eax
    1d1f:      	movl	%eax, 0x38(%rsp)
    1d23:      	movl	$0x1, %eax
    1d28:      	leaq	0x38(%rsp), %rsi
    1d2d:      	movq	(%rip), %rdi            # 0x1d34 <generic_fexit_filter_arg+0x1d34>
    1d34:      	callq	*%rax
    1d36:      	testq	%rax, %rax
    1d39:      	je	0x2683 <generic_fexit_filter_arg+0x2683>
    1d3f:      	testl	%ebp, %ebp
    1d41:      	movq	0x8(%rsp), %r9
    1d46:      	movq	0x10(%rsp), %r11
    1d4b:      	je	0x1d9f <generic_fexit_filter_arg+0x1d9f>
    1d4d:      	movq	0x20(%rsp), %rdx
    1d52:      	xorl	%ecx, %ecx
    1d54:      	jmp	0x1d61 <generic_fexit_filter_arg+0x1d61>
    1d56:      	incq	%rcx
    1d59:      	incq	%rdx
    1d5c:      	cmpq	%rbp, %rcx
    1d5f:      	je	0x1d9f <generic_fexit_filter_arg+0x1d9f>
    1d61:      	xorl	%esi, %esi
    1d63:      	nopw	%cs:(%rax,%rax)
    1d70:      	leaq	(%rcx,%rsi), %rdi
    1d74:      	cmpq	%rbp, %rdi
    1d77:      	jae	0x1d56 <generic_fexit_filter_arg+0x1d56>
    1d79:      	movzbl	(%rax,%rsi), %edi
    1d7d:      	testb	%dil, %dil
    1d80:      	je	0x1d97 <generic_fexit_filter_arg+0x1d97>
    1d82:      	cmpq	$0x62, %rsi
    1d86:      	ja	0x1d56 <generic_fexit_filter_arg+0x1d56>
    1d88:      	leaq	0x1(%rsi), %r8
    1d8c:      	cmpb	%dil, (%rdx,%rsi)
    1d90:      	movq	%r8, %rsi
    1d93:      	je	0x1d70 <generic_fexit_filter_arg+0x1d70>
    1d95:      	jmp	0x1d56 <generic_fexit_filter_arg+0x1d56>
    1d97:      	testl	%ecx, %ecx
    1d99:      	jns	0x297d <generic_fexit_filter_arg+0x297d>
    1d9f:      	leal	0xc(%r12), %eax
    1da4:      	cmpl	0x8(%r15), %eax
    1da8:      	jae	0x1dbb <generic_fexit_filter_arg+0x1dbb>
    1daa:      	addl	$0x4, %r12d
    1dae:      	incq	%rbx
    1db1:      	cmpq	$0x64, %rbx
    1db5:      	jne	0x1d1a <generic_fexit_filter_arg+0x1d1a>
    1dbb:      	xorl	%ebx, %ebx
    1dbd:      	movq	(%rsp), %rdi
    1dc1:      	jmp	0x2ef2 <generic_fexit_filter_arg+0x2ef2>
    1dc6:      	movzwl	%bp, %eax
    1dc9:      	cmpl	$0x90, %eax
    1dce:      	ja	0x223c <generic_fexit_filter_arg+0x223c>
    1dd4:      	testw	%bp, %bp
    1dd7:      	je	0x1de9 <generic_fexit_filter_arg+0x1de9>
    1dd9:      	movl	%ebp, %eax
    1ddb:      	movl	$0x18, %ecx
    1de0:      	cltd
    1de1:      	idivl	%ecx
    1de3:      	movl	%ebp, %edi
    1de5:      	testl	%edx, %edx
    1de7:      	je	0x1e0b <generic_fexit_filter_arg+0x1e0b>
    1de9:      	movl	%ebp, %eax
    1deb:      	movl	$0x18, %ecx
    1df0:      	cltd
    1df1:      	idivl	%ecx
    1df3:      	shll	$0x3, %eax
    1df6:      	leal	(%rax,%rax,2), %eax
    1df9:      	addl	$0x18, %eax
    1dfc:      	movzwl	%ax, %edi
    1dff:      	cmpl	$0x90, %edi
    1e05:      	ja	0x2250 <generic_fexit_filter_arg+0x2250>
    1e0b:      	movl	%edi, %eax
    1e0d:      	cltd
    1e0e:      	idivl	%ecx
    1e10:      	decl	%eax
    1e12:      	jmp	0x2261 <generic_fexit_filter_arg+0x2261>
    1e17:      	movzbl	(%rbp), %edx
    1e1b:      	cmpl	%edx, %ecx
    1e1d:      	jb	0x276 <generic_fexit_filter_arg+0x276>
    1e23:      	movl	0x8(%r15), %ecx
    1e27:      	cmpl	$0xd, %ecx
    1e2a:      	jb	0x2f69 <generic_fexit_filter_arg+0x2f69>
    1e30:      	movl	0x14(%r15), %edx
    1e34:      	cmpl	$0x2, %eax
    1e37:      	jle	0x2126 <generic_fexit_filter_arg+0x2126>
    1e3d:      	leal	-0x3(%rax), %esi
    1e40:      	cmpl	$0x2, %esi
    1e43:      	jae	0x2609 <generic_fexit_filter_arg+0x2609>
    1e49:      	movzbl	(%rbp), %esi
    1e4d:      	cmpl	%esi, %edx
    1e4f:      	jne	0x26fe <generic_fexit_filter_arg+0x26fe>
    1e55:      	jmp	0x2e81 <generic_fexit_filter_arg+0x2e81>
    1e5a:      	movzwl	(%rbp), %edx
    1e5e:      	cmpl	%edx, %ecx
    1e60:      	jb	0x276 <generic_fexit_filter_arg+0x276>
    1e66:      	movl	0x8(%r15), %ecx
    1e6a:      	cmpl	$0xd, %ecx
    1e6d:      	jb	0x2f69 <generic_fexit_filter_arg+0x2f69>
    1e73:      	movl	0x14(%r15), %edx
    1e77:      	cmpl	$0x2, %eax
    1e7a:      	jle	0x2149 <generic_fexit_filter_arg+0x2149>
    1e80:      	leal	-0x3(%rax), %esi
    1e83:      	cmpl	$0x2, %esi
    1e86:      	jae	0x2623 <generic_fexit_filter_arg+0x2623>
    1e8c:      	movzwl	(%rbp), %esi
    1e90:      	cmpl	%esi, %edx
    1e92:      	jne	0x273d <generic_fexit_filter_arg+0x273d>
    1e98:      	jmp	0x2e81 <generic_fexit_filter_arg+0x2e81>
    1e9d:      	testq	%rax, %rax
    1ea0:      	sete	%al
    1ea3:      	movq	(%rsp), %rdi
    1ea7:      	movq	0x8(%rsp), %r9
    1eac:      	movq	0x10(%rsp), %r11
    1eb1:      	movzbl	%al, %ebx
    1eb4:      	jmp	0x260 <generic_fexit_filter_arg+0x260>
    1eb9:      	movl	(%rbp), %eax
    1ebc:      	cmpl	%eax, %esi
    1ebe:      	ja	0x1ec8 <generic_fexit_filter_arg+0x1ec8>
    1ec0:      	cmpl	%edx, %eax
    1ec2:      	jbe	0x276 <generic_fexit_filter_arg+0x276>
    1ec8:      	movl	0x8(%r15), %edx
    1ecc:      	cmpl	$0x11, %edx
    1ecf:      	jb	0xb8 <generic_fexit_filter_arg+0xb8>
    1ed5:      	movl	0x18(%r15), %edi
    1ed9:      	movl	0x1c(%r15), %esi
    1edd:      	cmpl	$0xc, %ecx
    1ee0:      	ja	0x2384 <generic_fexit_filter_arg+0x2384>
    1ee6:      	movl	$0x1402, %r8d           # imm = 0x1402
    1eec:      	btl	%ecx, %r8d
    1ef0:      	jae	0x2384 <generic_fexit_filter_arg+0x2384>
    1ef6:      	cmpl	%eax, %edi
    1ef8:      	movq	(%rsp), %rdi
    1efc:      	jg	0x2394 <generic_fexit_filter_arg+0x2394>
    1f02:      	cmpl	%esi, %eax
    1f04:      	jle	0x276 <generic_fexit_filter_arg+0x276>
    1f0a:      	jmp	0x2394 <generic_fexit_filter_arg+0x2394>
    1f0f:      	movl	(%rbp), %edx
    1f12:      	cmpl	%edx, %esi
    1f14:      	setbe	%sil
    1f18:      	cmpl	%eax, %edx
    1f1a:      	setbe	%al
    1f1d:      	andb	%sil, %al
    1f20:      	movl	0x8(%r15), %esi
    1f24:      	cmpl	$0x11, %esi
    1f27:      	jb	0x2af3 <generic_fexit_filter_arg+0x2af3>
    1f2d:      	movl	0x18(%r15), %r8d
    1f31:      	movl	0x1c(%r15), %edi
    1f35:      	cmpl	$0xc, %ecx
    1f38:      	ja	0x2335 <generic_fexit_filter_arg+0x2335>
    1f3e:      	movl	$0x1402, %r10d          # imm = 0x1402
    1f44:      	btl	%ecx, %r10d
    1f48:      	jae	0x2335 <generic_fexit_filter_arg+0x2335>
    1f4e:      	cmpl	%edx, %r8d
    1f51:      	setle	%r8b
    1f55:      	cmpl	%edi, %edx
    1f57:      	setle	%dil
    1f5b:      	jmp	0x2342 <generic_fexit_filter_arg+0x2342>
    1f60:      	cmpq	%rdx, %r8
    1f63:      	setbe	%r8b
    1f67:      	cmpq	%rdi, %rdx
    1f6a:      	setbe	%dil
    1f6e:      	andb	%r8b, %dil
    1f71:      	orb	%dil, %al
    1f74:      	cmpl	$0x29, %esi
    1f77:      	jb	0x2aef <generic_fexit_filter_arg+0x2aef>
    1f7d:      	movq	0x30(%r15), %r8
    1f81:      	movq	0x38(%r15), %rdi
    1f85:      	cmpl	$0xc, %ecx
    1f88:      	je	0x1f93 <generic_fexit_filter_arg+0x1f93>
    1f8a:      	cmpl	$0xa, %ecx
    1f8d:      	jne	0x241e <generic_fexit_filter_arg+0x241e>
    1f93:      	cmpq	%rdx, %r8
    1f96:      	setle	%r8b
    1f9a:      	cmpq	%rdi, %rdx
    1f9d:      	setle	%dil
    1fa1:      	jmp	0x242c <generic_fexit_filter_arg+0x242c>
    1fa6:      	cmpq	%rax, %rdi
    1fa9:      	movq	(%rsp), %rdi
    1fad:      	ja	0x1fb8 <generic_fexit_filter_arg+0x1fb8>
    1faf:      	cmpq	%rsi, %rax
    1fb2:      	jbe	0x276 <generic_fexit_filter_arg+0x276>
    1fb8:      	cmpl	$0x29, %edx
    1fbb:      	jb	0xb8 <generic_fexit_filter_arg+0xb8>
    1fc1:      	movq	0x30(%r15), %rdi
    1fc5:      	movq	0x38(%r15), %rsi
    1fc9:      	cmpl	$0xc, %ecx
    1fcc:      	je	0x1fd7 <generic_fexit_filter_arg+0x1fd7>
    1fce:      	cmpl	$0xa, %ecx
    1fd1:      	jne	0x2533 <generic_fexit_filter_arg+0x2533>
    1fd7:      	cmpq	%rax, %rdi
    1fda:      	movq	(%rsp), %rdi
    1fde:      	jg	0x2545 <generic_fexit_filter_arg+0x2545>
    1fe4:      	cmpq	%rsi, %rax
    1fe7:      	jle	0x276 <generic_fexit_filter_arg+0x276>
    1fed:      	jmp	0x2545 <generic_fexit_filter_arg+0x2545>
    1ff2:      	xorl	%ebx, %ebx
    1ff4:      	cmpl	$0x29, %ecx
    1ff7:      	jne	0x2002 <generic_fexit_filter_arg+0x2002>
    1ff9:      	testq	%rdx, %rdx
    1ffc:      	je	0x2002 <generic_fexit_filter_arg+0x2002>
    1ffe:      	movzbl	0x3a(%rdx), %ebx
    2002:      	cmpl	$0x29, %ecx
    2005:      	je	0x2010 <generic_fexit_filter_arg+0x2010>
    2007:      	cmpl	$0x7, %ecx
    200a:      	jne	0x245f <generic_fexit_filter_arg+0x245f>
    2010:      	movzbl	0x10(%r15), %eax
    2015:      	movl	%eax, 0x2c(%rsp)
    2019:      	movl	$0x1, %eax
    201e:      	movq	(%rip), %rdi            # 0x2025 <generic_fexit_filter_arg+0x2025>
    2025:      	leaq	0x2c(%rsp), %rsi
    202a:      	callq	*%rax
    202c:      	testq	%rax, %rax
    202f:      	je	0x250 <generic_fexit_filter_arg+0x250>
    2035:      	movq	%rax, %rdi
    2038:      	movl	%ebx, %eax
    203a:      	movq	%rax, 0x70(%rsp)
    203f:      	movl	$0x1, %eax
    2044:      	movq	0x30(%rsp), %rsi
    2049:      	jmp	0x1a51 <generic_fexit_filter_arg+0x1a51>
    204e:      	cmpl	%edx, (%rbp)
    2051:      	ja	0x276 <generic_fexit_filter_arg+0x276>
    2057:      	jmp	0x2062 <generic_fexit_filter_arg+0x2062>
    2059:      	cmpl	%edx, (%rbp)
    205c:      	jb	0x276 <generic_fexit_filter_arg+0x276>
    2062:      	movl	0x8(%r15), %edx
    2066:      	cmpl	$0xd, %edx
    2069:      	jb	0x2f69 <generic_fexit_filter_arg+0x2f69>
    206f:      	movl	0x14(%r15), %esi
    2073:      	cmpl	$0x2, %eax
    2076:      	jle	0x2092 <generic_fexit_filter_arg+0x2092>
    2078:      	leal	-0x3(%rax), %edi
    207b:      	cmpl	$0x2, %edi
    207e:      	jae	0x20c7 <generic_fexit_filter_arg+0x20c7>
    2080:      	cmpl	%esi, (%rbp)
    2083:      	movq	(%rsp), %rdi
    2087:      	jne	0x281f <generic_fexit_filter_arg+0x281f>
    208d:      	jmp	0x2e81 <generic_fexit_filter_arg+0x2e81>
    2092:      	cmpl	$0x1, %eax
    2095:      	je	0x20e2 <generic_fexit_filter_arg+0x20e2>
    2097:      	cmpl	$0x2, %eax
    209a:      	jne	0x281f <generic_fexit_filter_arg+0x281f>
    20a0:      	cmpl	$0xc, %ecx
    20a3:      	ja	0x2816 <generic_fexit_filter_arg+0x2816>
    20a9:      	movl	$0x1402, %r8d           # imm = 0x1402
    20af:      	btl	%ecx, %r8d
    20b3:      	jae	0x2816 <generic_fexit_filter_arg+0x2816>
    20b9:      	cmpl	%esi, (%rbp)
    20bc:      	jl	0x276 <generic_fexit_filter_arg+0x276>
    20c2:      	jmp	0x281f <generic_fexit_filter_arg+0x281f>
    20c7:      	cmpl	$0xc, %eax
    20ca:      	movq	(%rsp), %rdi
    20ce:      	jne	0x281f <generic_fexit_filter_arg+0x281f>
    20d4:      	testl	%esi, (%rbp)
    20d7:      	jne	0x276 <generic_fexit_filter_arg+0x276>
    20dd:      	jmp	0x281f <generic_fexit_filter_arg+0x281f>
    20e2:      	cmpl	$0xc, %ecx
    20e5:      	ja	0x280b <generic_fexit_filter_arg+0x280b>
    20eb:      	movl	$0x1402, %r8d           # imm = 0x1402
    20f1:      	btl	%ecx, %r8d
    20f5:      	jae	0x280b <generic_fexit_filter_arg+0x280b>
    20fb:      	cmpl	%esi, (%rbp)
    20fe:      	jg	0x276 <generic_fexit_filter_arg+0x276>
    2104:      	jmp	0x281f <generic_fexit_filter_arg+0x281f>
    2109:      	xorl	%ebx, %ebx
    210b:      	movq	0x8(%rsp), %r9
    2110:      	movq	0x10(%rsp), %r11
    2115:      	jmp	0x23dc <generic_fexit_filter_arg+0x23dc>
    211a:      	xorl	%ebx, %ebx
    211c:      	movq	0x10(%rsp), %r11
    2121:      	jmp	0x23fd <generic_fexit_filter_arg+0x23fd>
    2126:      	cmpl	$0x1, %eax
    2129:      	je	0x26f2 <generic_fexit_filter_arg+0x26f2>
    212f:      	cmpl	$0x2, %eax
    2132:      	jne	0x26fe <generic_fexit_filter_arg+0x26fe>
    2138:      	movzbl	(%rbp), %esi
    213c:      	cmpl	%esi, %edx
    213e:      	ja	0x276 <generic_fexit_filter_arg+0x276>
    2144:      	jmp	0x26fe <generic_fexit_filter_arg+0x26fe>
    2149:      	cmpl	$0x1, %eax
    214c:      	je	0x2731 <generic_fexit_filter_arg+0x2731>
    2152:      	cmpl	$0x2, %eax
    2155:      	jne	0x273d <generic_fexit_filter_arg+0x273d>
    215b:      	movzwl	(%rbp), %esi
    215f:      	cmpl	%esi, %edx
    2161:      	ja	0x276 <generic_fexit_filter_arg+0x276>
    2167:      	jmp	0x273d <generic_fexit_filter_arg+0x273d>
    216c:      	movq	0x18(%rsp), %rax
    2171:      	movw	%bp, (%rax)
    2174:      	leaq	0x2(%rax), %rdi
    2178:      	movl	$0x4, %eax
    217d:      	movl	%ebp, %esi
    217f:      	callq	*%rax
    2181:      	movq	0x88(%rsp), %rsi
    2189:      	subl	%ebp, %esi
    218b:      	jbe	0x21af <generic_fexit_filter_arg+0x21af>
    218d:      	movq	0x18(%rsp), %rax
    2192:      	leaq	(%rax,%rbp), %rdi
    2196:      	addq	$0x2, %rdi
    219a:      	andl	$0xfff, %esi            # imm = 0xFFF
    21a0:      	movl	$0x4, %eax
    21a5:      	movq	0x98(%rsp), %rdx
    21ad:      	callq	*%rax
    21af:      	movl	0x90(%rsp), %eax
    21b6:      	movl	%eax, 0x38(%rsp)
    21ba:      	cmpl	$0x3, %ebx
    21bd:      	jg	0x21fd <generic_fexit_filter_arg+0x21fd>
    21bf:      	cmpl	$0x1, %ebx
    21c2:      	movq	(%rsp), %rdi
    21c6:      	movq	0x8(%rsp), %r9
    21cb:      	movq	0x10(%rsp), %r11
    21d0:      	jg	0x2698 <generic_fexit_filter_arg+0x2698>
    21d6:      	testl	%ebx, %ebx
    21d8:      	je	0x2a3c <generic_fexit_filter_arg+0x2a3c>
    21de:      	cmpl	$0x1, %ebx
    21e1:      	jne	0x845 <generic_fexit_filter_arg+0x845>
    21e7:      	movl	$0x1, %eax
    21ec:      	leaq	0x38(%rsp), %rsi
    21f1:      	movq	(%rip), %rdi            # 0x21f8 <generic_fexit_filter_arg+0x21f8>
    21f8:      	jmp	0x2a86 <generic_fexit_filter_arg+0x2a86>
    21fd:      	cmpl	$0x5, %ebx
    2200:      	movq	(%rsp), %rdi
    2204:      	movq	0x8(%rsp), %r9
    2209:      	movq	0x10(%rsp), %r11
    220e:      	jg	0x26c0 <generic_fexit_filter_arg+0x26c0>
    2214:      	cmpl	$0x4, %ebx
    2217:      	je	0x2a4f <generic_fexit_filter_arg+0x2a4f>
    221d:      	cmpl	$0x5, %ebx
    2220:      	jne	0x845 <generic_fexit_filter_arg+0x845>
    2226:      	movl	$0x1, %eax
    222b:      	leaq	0x38(%rsp), %rsi
    2230:      	movq	(%rip), %rdi            # 0x2237 <generic_fexit_filter_arg+0x2237>
    2237:      	jmp	0x2a86 <generic_fexit_filter_arg+0x2a86>
    223c:      	cmpl	$0x101, %eax            # imm = 0x101
    2241:      	movl	$0x100, %edi            # imm = 0x100
    2246:      	movl	$0x1fe, %eax            # imm = 0x1FE
    224b:      	cmovael	%eax, %edi
    224e:      	movl	%edi, %eax
    2250:      	movzwl	%ax, %ecx
    2253:      	xorl	%eax, %eax
    2255:      	cmpl	$0x100, %ecx            # imm = 0x100
    225b:      	sete	%al
    225e:      	xorl	$0x7, %eax
    2261:      	movl	%eax, %ecx
    2263:      	andl	$0xf, %ecx
    2266:      	movl	0x10(%r15,%rcx,4), %ecx
    226b:      	cmpl	$-0x1, %ecx
    226e:      	je	0x2ee2 <generic_fexit_filter_arg+0x2ee2>
    2274:      	movl	%ecx, 0x88(%rsp)
    227b:      	movq	%rdi, 0x90(%rsp)
    2283:      	movl	%eax, 0x18(%rsp)
    2287:      	movq	%rsi, 0x20(%rsp)
    228c:      	movl	$0x1, %eax
    2291:      	movq	(%rip), %rdi            # 0x2298 <generic_fexit_filter_arg+0x2298>
    2298:      	movq	0x30(%rsp), %rbx
    229d:      	movq	%rbx, %rsi
    22a0:      	callq	*%rax
    22a2:      	movq	%rax, 0x60(%rsp)
    22a7:      	movl	$0x1, %eax
    22ac:      	movq	(%rip), %rdi            # 0x22b3 <generic_fexit_filter_arg+0x22b3>
    22b3:      	movq	%rbx, %rsi
    22b6:      	callq	*%rax
    22b8:      	movq	0x60(%rsp), %rdx
    22bd:      	testq	%rdx, %rdx
    22c0:      	je	0x2ee2 <generic_fexit_filter_arg+0x2ee2>
    22c6:      	movl	$0x0, %ebx
    22cb:      	testq	%rax, %rax
    22ce:      	movq	(%rsp), %rdi
    22d2:      	movq	0x8(%rsp), %r9
    22d7:      	movq	0x10(%rsp), %r11
    22dc:      	je	0x2ef2 <generic_fexit_filter_arg+0x2ef2>
    22e2:      	movq	%rdx, %rcx
    22e5:      	movq	%rax, %r12
    22e8:      	cmpl	$0x5, 0x18(%rsp)
    22ed:      	jg	0x298b <generic_fexit_filter_arg+0x298b>
    22f3:      	movq	%rcx, %rbx
    22f6:      	movb	%bpl, (%rcx)
    22f9:      	leaq	0x1(%rcx), %rdi
    22fd:      	movl	$0x4, %eax
    2302:      	movq	0x20(%rsp), %rdx
    2307:      	movl	%ebp, %esi
    2309:      	callq	*%rax
    230b:      	movq	0x90(%rsp), %rsi
    2313:      	subl	%ebp, %esi
    2315:      	jbe	0x29c7 <generic_fexit_filter_arg+0x29c7>
    231b:      	leaq	(%rbx,%rbp), %rdi
    231f:      	incq	%rdi
    2322:      	andl	$0xfff, %esi            # imm = 0xFFF
    2328:      	movl	$0x4, %eax
    232d:      	movq	%r12, %rdx
    2330:      	jmp	0x29c5 <generic_fexit_filter_arg+0x29c5>
    2335:      	cmpl	%edx, %r8d
    2338:      	setbe	%r8b
    233c:      	cmpl	%edi, %edx
    233e:      	setbe	%dil
    2342:      	andb	%r8b, %dil
    2345:      	orb	%dil, %al
    2348:      	cmpl	$0x19, %esi
    234b:      	jb	0x2aef <generic_fexit_filter_arg+0x2aef>
    2351:      	movl	0x20(%r15), %r8d
    2355:      	movl	0x24(%r15), %edi
    2359:      	cmpl	$0xc, %ecx
    235c:      	ja	0x2770 <generic_fexit_filter_arg+0x2770>
    2362:      	movl	$0x1402, %r10d          # imm = 0x1402
    2368:      	btl	%ecx, %r10d
    236c:      	jae	0x2770 <generic_fexit_filter_arg+0x2770>
    2372:      	cmpl	%edx, %r8d
    2375:      	setle	%r8b
    2379:      	cmpl	%edi, %edx
    237b:      	setle	%dil
    237f:      	jmp	0x277d <generic_fexit_filter_arg+0x277d>
    2384:      	cmpl	%eax, %edi
    2386:      	movq	(%rsp), %rdi
    238a:      	ja	0x2394 <generic_fexit_filter_arg+0x2394>
    238c:      	cmpl	%esi, %eax
    238e:      	jbe	0x276 <generic_fexit_filter_arg+0x276>
    2394:      	cmpl	$0x19, %edx
    2397:      	jb	0xb8 <generic_fexit_filter_arg+0xb8>
    239d:      	movl	0x20(%r15), %edi
    23a1:      	movl	0x24(%r15), %esi
    23a5:      	cmpl	$0xc, %ecx
    23a8:      	ja	0x27bc <generic_fexit_filter_arg+0x27bc>
    23ae:      	movl	$0x1402, %r8d           # imm = 0x1402
    23b4:      	btl	%ecx, %r8d
    23b8:      	jae	0x27bc <generic_fexit_filter_arg+0x27bc>
    23be:      	cmpl	%eax, %edi
    23c0:      	movq	(%rsp), %rdi
    23c4:      	jg	0x27cc <generic_fexit_filter_arg+0x27cc>
    23ca:      	cmpl	%esi, %eax
    23cc:      	jle	0x276 <generic_fexit_filter_arg+0x276>
    23d2:      	jmp	0x27cc <generic_fexit_filter_arg+0x27cc>
    23d7:      	movl	$0x1, %ebx
    23dc:      	movq	0x68(%rsp), %r12
    23e1:      	movq	(%rsp), %rdi
    23e5:      	movl	0x4(%r15), %eax
    23e9:      	cmpq	$0x25, %rax
    23ed:      	jbe	0x2c79 <generic_fexit_filter_arg+0x2c79>
    23f3:      	jmp	0x265 <generic_fexit_filter_arg+0x265>
    23f8:      	movl	$0x1, %ebx
    23fd:      	movq	0x68(%rsp), %r12
    2402:      	movq	(%rsp), %rdi
    2406:      	movq	0x8(%rsp), %r9
    240b:      	movl	0x4(%r15), %eax
    240f:      	cmpq	$0x25, %rax
    2413:      	jbe	0x2c79 <generic_fexit_filter_arg+0x2c79>
    2419:      	jmp	0x265 <generic_fexit_filter_arg+0x265>
    241e:      	cmpq	%rdx, %r8
    2421:      	setbe	%r8b
    2425:      	cmpq	%rdi, %rdx
    2428:      	setbe	%dil
    242c:      	andb	%r8b, %dil
    242f:      	orb	%dil, %al
    2432:      	cmpl	$0x39, %esi
    2435:      	jb	0x2aef <generic_fexit_filter_arg+0x2aef>
    243b:      	movq	0x40(%r15), %rdi
    243f:      	movq	0x48(%r15), %rsi
    2443:      	cmpl	$0xc, %ecx
    2446:      	je	0x2451 <generic_fexit_filter_arg+0x2451>
    2448:      	cmpl	$0xa, %ecx
    244b:      	jne	0x28c2 <generic_fexit_filter_arg+0x28c2>
    2451:      	cmpq	%rdx, %rdi
    2454:      	setle	%cl
    2457:      	cmpq	%rsi, %rdx
    245a:      	jmp	0x27b4 <generic_fexit_filter_arg+0x27b4>
    245f:      	xorl	%ebx, %ebx
    2461:      	jmp	0x260 <generic_fexit_filter_arg+0x260>
    2466:      	movq	0x18(%rsp), %rax
    246b:      	movw	%bp, (%rax)
    246e:      	leaq	0x2(%rax), %rdi
    2472:      	movl	$0x4, %eax
    2477:      	movq	0x20(%rsp), %rdx
    247c:      	movl	%ebp, %esi
    247e:      	callq	*%rax
    2480:      	movq	0x88(%rsp), %rsi
    2488:      	subl	%ebp, %esi
    248a:      	jbe	0x24ae <generic_fexit_filter_arg+0x24ae>
    248c:      	movq	0x18(%rsp), %rax
    2491:      	leaq	(%rax,%rbp), %rdi
    2495:      	addq	$0x2, %rdi
    2499:      	andl	$0xfff, %esi            # imm = 0xFFF
    249f:      	movl	$0x4, %eax
    24a4:      	movq	0x98(%rsp), %rdx
    24ac:      	callq	*%rax
    24ae:      	movl	0x90(%rsp), %eax
    24b5:      	movl	%eax, 0x38(%rsp)
    24b9:      	cmpl	$0x3, %ebx
    24bc:      	jg	0x24f8 <generic_fexit_filter_arg+0x24f8>
    24be:      	cmpl	$0x1, %ebx
    24c1:      	movq	0x8(%rsp), %r9
    24c6:      	movq	0x10(%rsp), %r11
    24cb:      	jg	0x28d0 <generic_fexit_filter_arg+0x28d0>
    24d1:      	testl	%ebx, %ebx
    24d3:      	je	0x2bf1 <generic_fexit_filter_arg+0x2bf1>
    24d9:      	cmpl	$0x1, %ebx
    24dc:      	jne	0x2c92 <generic_fexit_filter_arg+0x2c92>
    24e2:      	movl	$0x1, %eax
    24e7:      	leaq	0x38(%rsp), %rsi
    24ec:      	movq	(%rip), %rdi            # 0x24f3 <generic_fexit_filter_arg+0x24f3>
    24f3:      	jmp	0x2c3b <generic_fexit_filter_arg+0x2c3b>
    24f8:      	cmpl	$0x5, %ebx
    24fb:      	movq	0x8(%rsp), %r9
    2500:      	movq	0x10(%rsp), %r11
    2505:      	jg	0x28f8 <generic_fexit_filter_arg+0x28f8>
    250b:      	cmpl	$0x4, %ebx
    250e:      	je	0x2c04 <generic_fexit_filter_arg+0x2c04>
    2514:      	cmpl	$0x5, %ebx
    2517:      	jne	0x2c92 <generic_fexit_filter_arg+0x2c92>
    251d:      	movl	$0x1, %eax
    2522:      	leaq	0x38(%rsp), %rsi
    2527:      	movq	(%rip), %rdi            # 0x252e <generic_fexit_filter_arg+0x252e>
    252e:      	jmp	0x2c3b <generic_fexit_filter_arg+0x2c3b>
    2533:      	cmpq	%rax, %rdi
    2536:      	movq	(%rsp), %rdi
    253a:      	ja	0x2545 <generic_fexit_filter_arg+0x2545>
    253c:      	cmpq	%rsi, %rax
    253f:      	jbe	0x276 <generic_fexit_filter_arg+0x276>
    2545:      	cmpl	$0x39, %edx
    2548:      	jb	0xb8 <generic_fexit_filter_arg+0xb8>
    254e:      	movq	0x40(%r15), %rsi
    2552:      	movq	0x48(%r15), %rdx
    2556:      	cmpl	$0xc, %ecx
    2559:      	je	0x2564 <generic_fexit_filter_arg+0x2564>
    255b:      	cmpl	$0xa, %ecx
    255e:      	jne	0x2920 <generic_fexit_filter_arg+0x2920>
    2564:      	cmpq	%rax, %rsi
    2567:      	jg	0xb8 <generic_fexit_filter_arg+0xb8>
    256d:      	cmpq	%rdx, %rax
    2570:      	jle	0x276 <generic_fexit_filter_arg+0x276>
    2576:      	jmp	0xb8 <generic_fexit_filter_arg+0xb8>
    257b:      	cmpq	%rsi, (%rbp)
    257f:      	ja	0x276 <generic_fexit_filter_arg+0x276>
    2585:      	jmp	0x2591 <generic_fexit_filter_arg+0x2591>
    2587:      	cmpq	%rsi, (%rbp)
    258b:      	jb	0x276 <generic_fexit_filter_arg+0x276>
    2591:      	cmpl	$0x19, %edx
    2594:      	jb	0x2f69 <generic_fexit_filter_arg+0x2f69>
    259a:      	movq	0x20(%r15), %rsi
    259e:      	cmpl	$0x2, %eax
    25a1:      	jle	0x25be <generic_fexit_filter_arg+0x25be>
    25a3:      	leal	-0x3(%rax), %edi
    25a6:      	cmpl	$0x2, %edi
    25a9:      	jae	0x25ed <generic_fexit_filter_arg+0x25ed>
    25ab:      	cmpq	%rsi, (%rbp)
    25af:      	movq	(%rsp), %rdi
    25b3:      	jne	0x2b16 <generic_fexit_filter_arg+0x2b16>
    25b9:      	jmp	0x2e81 <generic_fexit_filter_arg+0x2e81>
    25be:      	cmpl	$0x1, %eax
    25c1:      	je	0x2666 <generic_fexit_filter_arg+0x2666>
    25c7:      	cmpl	$0x2, %eax
    25ca:      	jne	0x2b16 <generic_fexit_filter_arg+0x2b16>
    25d0:      	cmpl	$0xc, %ecx
    25d3:      	je	0x25de <generic_fexit_filter_arg+0x25de>
    25d5:      	cmpl	$0xa, %ecx
    25d8:      	jne	0x2b0c <generic_fexit_filter_arg+0x2b0c>
    25de:      	cmpq	%rsi, (%rbp)
    25e2:      	jl	0x276 <generic_fexit_filter_arg+0x276>
    25e8:      	jmp	0x2b16 <generic_fexit_filter_arg+0x2b16>
    25ed:      	cmpl	$0xc, %eax
    25f0:      	movq	(%rsp), %rdi
    25f4:      	jne	0x2b16 <generic_fexit_filter_arg+0x2b16>
    25fa:      	testq	%rsi, (%rbp)
    25fe:      	jne	0x276 <generic_fexit_filter_arg+0x276>
    2604:      	jmp	0x2b16 <generic_fexit_filter_arg+0x2b16>
    2609:      	cmpl	$0xc, %eax
    260c:      	jne	0x26fe <generic_fexit_filter_arg+0x26fe>
    2612:      	movzbl	(%rbp), %esi
    2616:      	testl	%esi, %edx
    2618:      	jne	0x276 <generic_fexit_filter_arg+0x276>
    261e:      	jmp	0x26fe <generic_fexit_filter_arg+0x26fe>
    2623:      	cmpl	$0xc, %eax
    2626:      	jne	0x273d <generic_fexit_filter_arg+0x273d>
    262c:      	movzwl	(%rbp), %esi
    2630:      	testl	%esi, %edx
    2632:      	jne	0x276 <generic_fexit_filter_arg+0x276>
    2638:      	jmp	0x273d <generic_fexit_filter_arg+0x273d>
    263d:      	movq	(%rsp), %rdi
    2641:      	movq	0x8(%rsp), %r9
    2646:      	movq	0x10(%rsp), %r11
    264b:      	movzbl	%cl, %ebx
    264e:      	jmp	0x265 <generic_fexit_filter_arg+0x265>
    2653:      	movq	(%rsp), %rdi
    2657:      	movq	0x8(%rsp), %r9
    265c:      	movq	0x10(%rsp), %r11
    2661:      	jmp	0x1a92 <generic_fexit_filter_arg+0x1a92>
    2666:      	cmpl	$0xc, %ecx
    2669:      	je	0x2674 <generic_fexit_filter_arg+0x2674>
    266b:      	cmpl	$0xa, %ecx
    266e:      	jne	0x2b00 <generic_fexit_filter_arg+0x2b00>
    2674:      	cmpq	%rsi, (%rbp)
    2678:      	jg	0x276 <generic_fexit_filter_arg+0x276>
    267e:      	jmp	0x2b16 <generic_fexit_filter_arg+0x2b16>
    2683:      	xorl	%ebx, %ebx
    2685:      	movq	0x8(%rsp), %r9
    268a:      	movq	0x10(%rsp), %r11
    268f:      	movq	(%rsp), %rdi
    2693:      	jmp	0x2ef2 <generic_fexit_filter_arg+0x2ef2>
    2698:      	cmpl	$0x2, %ebx
    269b:      	je	0x2a62 <generic_fexit_filter_arg+0x2a62>
    26a1:      	cmpl	$0x3, %ebx
    26a4:      	jne	0x845 <generic_fexit_filter_arg+0x845>
    26aa:      	movl	$0x1, %eax
    26af:      	leaq	0x38(%rsp), %rsi
    26b4:      	movq	(%rip), %rdi            # 0x26bb <generic_fexit_filter_arg+0x26bb>
    26bb:      	jmp	0x2a86 <generic_fexit_filter_arg+0x2a86>
    26c0:      	cmpl	$0x6, %ebx
    26c3:      	je	0x2a75 <generic_fexit_filter_arg+0x2a75>
    26c9:      	cmpl	$0x7, %ebx
    26cc:      	jne	0x845 <generic_fexit_filter_arg+0x845>
    26d2:      	movl	$0x1, %eax
    26d7:      	leaq	0x38(%rsp), %rsi
    26dc:      	movq	(%rip), %rdi            # 0x26e3 <generic_fexit_filter_arg+0x26e3>
    26e3:      	jmp	0x2a86 <generic_fexit_filter_arg+0x2a86>
    26e8:      	movl	$0x1, %ebx
    26ed:      	jmp	0x2ee4 <generic_fexit_filter_arg+0x2ee4>
    26f2:      	movzbl	(%rbp), %esi
    26f6:      	cmpl	%esi, %edx
    26f8:      	jb	0x276 <generic_fexit_filter_arg+0x276>
    26fe:      	cmpl	$0x11, %ecx
    2701:      	jb	0x2f69 <generic_fexit_filter_arg+0x2f69>
    2707:      	movl	0x18(%r15), %edx
    270b:      	cmpl	$0x2, %eax
    270e:      	jle	0x2937 <generic_fexit_filter_arg+0x2937>
    2714:      	leal	-0x3(%rax), %esi
    2717:      	cmpl	$0x2, %esi
    271a:      	jae	0x2b8b <generic_fexit_filter_arg+0x2b8b>
    2720:      	movzbl	(%rbp), %esi
    2724:      	cmpl	%esi, %edx
    2726:      	jne	0x2cf9 <generic_fexit_filter_arg+0x2cf9>
    272c:      	jmp	0x2e81 <generic_fexit_filter_arg+0x2e81>
    2731:      	movzwl	(%rbp), %esi
    2735:      	cmpl	%esi, %edx
    2737:      	jb	0x276 <generic_fexit_filter_arg+0x276>
    273d:      	cmpl	$0x11, %ecx
    2740:      	jb	0x2f69 <generic_fexit_filter_arg+0x2f69>
    2746:      	movl	0x18(%r15), %edx
    274a:      	cmpl	$0x2, %eax
    274d:      	jle	0x295a <generic_fexit_filter_arg+0x295a>
    2753:      	leal	-0x3(%rax), %esi
    2756:      	cmpl	$0x2, %esi
    2759:      	jae	0x2ba5 <generic_fexit_filter_arg+0x2ba5>
    275f:      	movzwl	(%rbp), %esi
    2763:      	cmpl	%esi, %edx
    2765:      	jne	0x2d3f <generic_fexit_filter_arg+0x2d3f>
    276b:      	jmp	0x2e81 <generic_fexit_filter_arg+0x2e81>
    2770:      	cmpl	%edx, %r8d
    2773:      	setbe	%r8b
    2777:      	cmpl	%edi, %edx
    2779:      	setbe	%dil
    277d:      	andb	%r8b, %dil
    2780:      	orb	%dil, %al
    2783:      	cmpl	$0x21, %esi
    2786:      	jb	0x2aef <generic_fexit_filter_arg+0x2aef>
    278c:      	movl	0x28(%r15), %edi
    2790:      	movl	0x2c(%r15), %esi
    2794:      	cmpl	$0xc, %ecx
    2797:      	ja	0x2ae1 <generic_fexit_filter_arg+0x2ae1>
    279d:      	movl	$0x1402, %r8d           # imm = 0x1402
    27a3:      	btl	%ecx, %r8d
    27a7:      	jae	0x2ae1 <generic_fexit_filter_arg+0x2ae1>
    27ad:      	cmpl	%edx, %edi
    27af:      	setle	%cl
    27b2:      	cmpl	%esi, %edx
    27b4:      	setle	%dl
    27b7:      	jmp	0x2aeb <generic_fexit_filter_arg+0x2aeb>
    27bc:      	cmpl	%eax, %edi
    27be:      	movq	(%rsp), %rdi
    27c2:      	ja	0x27cc <generic_fexit_filter_arg+0x27cc>
    27c4:      	cmpl	%esi, %eax
    27c6:      	jbe	0x276 <generic_fexit_filter_arg+0x276>
    27cc:      	cmpl	$0x21, %edx
    27cf:      	jb	0xb8 <generic_fexit_filter_arg+0xb8>
    27d5:      	movl	0x28(%r15), %esi
    27d9:      	movl	0x2c(%r15), %edx
    27dd:      	cmpl	$0xc, %ecx
    27e0:      	ja	0x2bbf <generic_fexit_filter_arg+0x2bbf>
    27e6:      	movl	$0x1402, %r8d           # imm = 0x1402
    27ec:      	btl	%ecx, %r8d
    27f0:      	jae	0x2bbf <generic_fexit_filter_arg+0x2bbf>
    27f6:      	cmpl	%eax, %esi
    27f8:      	jg	0xb8 <generic_fexit_filter_arg+0xb8>
    27fe:      	cmpl	%edx, %eax
    2800:      	jle	0x276 <generic_fexit_filter_arg+0x276>
    2806:      	jmp	0xb8 <generic_fexit_filter_arg+0xb8>
    280b:      	cmpl	%esi, (%rbp)
    280e:      	ja	0x276 <generic_fexit_filter_arg+0x276>
    2814:      	jmp	0x281f <generic_fexit_filter_arg+0x281f>
    2816:      	cmpl	%esi, (%rbp)
    2819:      	jb	0x276 <generic_fexit_filter_arg+0x276>
    281f:      	cmpl	$0x11, %edx
    2822:      	jb	0x2f69 <generic_fexit_filter_arg+0x2f69>
    2828:      	movl	0x18(%r15), %esi
    282c:      	cmpl	$0x2, %eax
    282f:      	jle	0x284b <generic_fexit_filter_arg+0x284b>
    2831:      	leal	-0x3(%rax), %edi
    2834:      	cmpl	$0x2, %edi
    2837:      	jae	0x2880 <generic_fexit_filter_arg+0x2880>
    2839:      	cmpl	%esi, (%rbp)
    283c:      	movq	(%rsp), %rdi
    2840:      	jne	0x2d98 <generic_fexit_filter_arg+0x2d98>
    2846:      	jmp	0x2e81 <generic_fexit_filter_arg+0x2e81>
    284b:      	cmpl	$0x1, %eax
    284e:      	je	0x289b <generic_fexit_filter_arg+0x289b>
    2850:      	cmpl	$0x2, %eax
    2853:      	jne	0x2d98 <generic_fexit_filter_arg+0x2d98>
    2859:      	cmpl	$0xc, %ecx
    285c:      	ja	0x2d8f <generic_fexit_filter_arg+0x2d8f>
    2862:      	movl	$0x1402, %r8d           # imm = 0x1402
    2868:      	btl	%ecx, %r8d
    286c:      	jae	0x2d8f <generic_fexit_filter_arg+0x2d8f>
    2872:      	cmpl	%esi, (%rbp)
    2875:      	jl	0x276 <generic_fexit_filter_arg+0x276>
    287b:      	jmp	0x2d98 <generic_fexit_filter_arg+0x2d98>
    2880:      	cmpl	$0xc, %eax
    2883:      	movq	(%rsp), %rdi
    2887:      	jne	0x2d98 <generic_fexit_filter_arg+0x2d98>
    288d:      	testl	%esi, (%rbp)
    2890:      	jne	0x276 <generic_fexit_filter_arg+0x276>
    2896:      	jmp	0x2d98 <generic_fexit_filter_arg+0x2d98>
    289b:      	cmpl	$0xc, %ecx
    289e:      	ja	0x2d84 <generic_fexit_filter_arg+0x2d84>
    28a4:      	movl	$0x1402, %r8d           # imm = 0x1402
    28aa:      	btl	%ecx, %r8d
    28ae:      	jae	0x2d84 <generic_fexit_filter_arg+0x2d84>
    28b4:      	cmpl	%esi, (%rbp)
    28b7:      	jg	0x276 <generic_fexit_filter_arg+0x276>
    28bd:      	jmp	0x2d98 <generic_fexit_filter_arg+0x2d98>
    28c2:      	cmpq	%rdx, %rdi
    28c5:      	setbe	%cl
    28c8:      	cmpq	%rsi, %rdx
    28cb:      	jmp	0x2ae8 <generic_fexit_filter_arg+0x2ae8>
    28d0:      	cmpl	$0x2, %ebx
    28d3:      	je	0x2c17 <generic_fexit_filter_arg+0x2c17>
    28d9:      	cmpl	$0x3, %ebx
    28dc:      	jne	0x2c92 <generic_fexit_filter_arg+0x2c92>
    28e2:      	movl	$0x1, %eax
    28e7:      	leaq	0x38(%rsp), %rsi
    28ec:      	movq	(%rip), %rdi            # 0x28f3 <generic_fexit_filter_arg+0x28f3>
    28f3:      	jmp	0x2c3b <generic_fexit_filter_arg+0x2c3b>
    28f8:      	cmpl	$0x6, %ebx
    28fb:      	je	0x2c2a <generic_fexit_filter_arg+0x2c2a>
    2901:      	cmpl	$0x7, %ebx
    2904:      	jne	0x2c92 <generic_fexit_filter_arg+0x2c92>
    290a:      	movl	$0x1, %eax
    290f:      	leaq	0x38(%rsp), %rsi
    2914:      	movq	(%rip), %rdi            # 0x291b <generic_fexit_filter_arg+0x291b>
    291b:      	jmp	0x2c3b <generic_fexit_filter_arg+0x2c3b>
    2920:      	cmpq	%rax, %rsi
    2923:      	ja	0xb8 <generic_fexit_filter_arg+0xb8>
    2929:      	cmpq	%rdx, %rax
    292c:      	jbe	0x276 <generic_fexit_filter_arg+0x276>
    2932:      	jmp	0xb8 <generic_fexit_filter_arg+0xb8>
    2937:      	cmpl	$0x1, %eax
    293a:      	je	0x2ced <generic_fexit_filter_arg+0x2ced>
    2940:      	cmpl	$0x2, %eax
    2943:      	jne	0x2cf9 <generic_fexit_filter_arg+0x2cf9>
    2949:      	movzbl	(%rbp), %esi
    294d:      	cmpl	%esi, %edx
    294f:      	ja	0x276 <generic_fexit_filter_arg+0x276>
    2955:      	jmp	0x2cf9 <generic_fexit_filter_arg+0x2cf9>
    295a:      	cmpl	$0x1, %eax
    295d:      	je	0x2d33 <generic_fexit_filter_arg+0x2d33>
    2963:      	cmpl	$0x2, %eax
    2966:      	jne	0x2d3f <generic_fexit_filter_arg+0x2d3f>
    296c:      	movzwl	(%rbp), %esi
    2970:      	cmpl	%esi, %edx
    2972:      	ja	0x276 <generic_fexit_filter_arg+0x276>
    2978:      	jmp	0x2d3f <generic_fexit_filter_arg+0x2d3f>
    297d:      	movl	$0x1, %ebx
    2982:      	movq	(%rsp), %rdi
    2986:      	jmp	0x2ef2 <generic_fexit_filter_arg+0x2ef2>
    298b:      	movq	%rcx, %rbx
    298e:      	movw	%bp, (%rcx)
    2991:      	leaq	0x2(%rcx), %rdi
    2995:      	movl	$0x4, %eax
    299a:      	movq	0x20(%rsp), %rdx
    299f:      	movl	%ebp, %esi
    29a1:      	callq	*%rax
    29a3:      	movq	0x90(%rsp), %rsi
    29ab:      	subl	%ebp, %esi
    29ad:      	jbe	0x29c7 <generic_fexit_filter_arg+0x29c7>
    29af:      	leaq	(%rbx,%rbp), %rdi
    29b3:      	addq	$0x2, %rdi
    29b7:      	andl	$0xfff, %esi            # imm = 0xFFF
    29bd:      	movl	$0x4, %eax
    29c2:      	movq	%r12, %rdx
    29c5:      	callq	*%rax
    29c7:      	movl	0x88(%rsp), %eax
    29ce:      	movl	%eax, 0x38(%rsp)
    29d2:      	movl	0x18(%rsp), %eax
    29d6:      	cmpl	$0x3, %eax
    29d9:      	jg	0x2a0b <generic_fexit_filter_arg+0x2a0b>
    29db:      	cmpl	$0x1, %eax
    29de:      	leaq	0x38(%rsp), %rsi
    29e3:      	jg	0x2ca7 <generic_fexit_filter_arg+0x2ca7>
    29e9:      	testl	%eax, %eax
    29eb:      	je	0x2e8e <generic_fexit_filter_arg+0x2e8e>
    29f1:      	cmpl	$0x1, %eax
    29f4:      	jne	0x2ee2 <generic_fexit_filter_arg+0x2ee2>
    29fa:      	movl	$0x1, %eax
    29ff:      	movq	(%rip), %rdi            # 0x2a06 <generic_fexit_filter_arg+0x2a06>
    2a06:      	jmp	0x2ec4 <generic_fexit_filter_arg+0x2ec4>
    2a0b:      	cmpl	$0x5, %eax
    2a0e:      	leaq	0x38(%rsp), %rsi
    2a13:      	jg	0x2cca <generic_fexit_filter_arg+0x2cca>
    2a19:      	cmpl	$0x4, %eax
    2a1c:      	je	0x2e9c <generic_fexit_filter_arg+0x2e9c>
    2a22:      	cmpl	$0x5, %eax
    2a25:      	jne	0x2ee2 <generic_fexit_filter_arg+0x2ee2>
    2a2b:      	movl	$0x1, %eax
    2a30:      	movq	(%rip), %rdi            # 0x2a37 <generic_fexit_filter_arg+0x2a37>
    2a37:      	jmp	0x2ec4 <generic_fexit_filter_arg+0x2ec4>
    2a3c:      	movl	$0x1, %eax
    2a41:      	movq	(%rip), %rdi            # 0x2a48 <generic_fexit_filter_arg+0x2a48>
    2a48:      	leaq	0x38(%rsp), %rsi
    2a4d:      	jmp	0x2a86 <generic_fexit_filter_arg+0x2a86>
    2a4f:      	movl	$0x1, %eax
    2a54:      	leaq	0x38(%rsp), %rsi
    2a59:      	movq	(%rip), %rdi            # 0x2a60 <generic_fexit_filter_arg+0x2a60>
    2a60:      	jmp	0x2a86 <generic_fexit_filter_arg+0x2a86>
    2a62:      	movl	$0x1, %eax
    2a67:      	leaq	0x38(%rsp), %rsi
    2a6c:      	movq	(%rip), %rdi            # 0x2a73 <generic_fexit_filter_arg+0x2a73>
    2a73:      	jmp	0x2a86 <generic_fexit_filter_arg+0x2a86>
    2a75:      	movl	$0x1, %eax
    2a7a:      	leaq	0x38(%rsp), %rsi
    2a7f:      	movq	(%rip), %rdi            # 0x2a86 <generic_fexit_filter_arg+0x2a86>
    2a86:      	callq	*%rax
    2a88:      	testq	%rax, %rax
    2a8b:      	je	0x2aa6 <generic_fexit_filter_arg+0x2aa6>
    2a8d:      	movq	%rax, %rdi
    2a90:      	movl	$0x1, %eax
    2a95:      	movq	0x18(%rsp), %rsi
    2a9a:      	callq	*%rax
    2a9c:      	xorl	%ebx, %ebx
    2a9e:      	testq	%rax, %rax
    2aa1:      	setne	%bl
    2aa4:      	jmp	0x2aa8 <generic_fexit_filter_arg+0x2aa8>
    2aa6:      	xorl	%ebx, %ebx
    2aa8:      	movq	(%rsp), %rdi
    2aac:      	movq	0x8(%rsp), %r9
    2ab1:      	movq	0x10(%rsp), %r11
    2ab6:      	movl	0x4(%r15), %eax
    2aba:      	cmpq	$0x25, %rax
    2abe:      	ja	0x265 <generic_fexit_filter_arg+0x265>
    2ac4:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    2ace:      	btq	%rax, %rcx
    2ad2:      	jae	0x265 <generic_fexit_filter_arg+0x265>
    2ad8:      	xorq	$0x1, %rbx
    2adc:      	jmp	0x265 <generic_fexit_filter_arg+0x265>
    2ae1:      	cmpl	%edx, %edi
    2ae3:      	setbe	%cl
    2ae6:      	cmpl	%esi, %edx
    2ae8:      	setbe	%dl
    2aeb:      	andb	%cl, %dl
    2aed:      	orb	%dl, %al
    2aef:      	movq	(%rsp), %rdi
    2af3:      	testb	%al, %al
    2af5:      	je	0x276 <generic_fexit_filter_arg+0x276>
    2afb:      	jmp	0xb8 <generic_fexit_filter_arg+0xb8>
    2b00:      	cmpq	%rsi, (%rbp)
    2b04:      	ja	0x276 <generic_fexit_filter_arg+0x276>
    2b0a:      	jmp	0x2b16 <generic_fexit_filter_arg+0x2b16>
    2b0c:      	cmpq	%rsi, (%rbp)
    2b10:      	jb	0x276 <generic_fexit_filter_arg+0x276>
    2b16:      	cmpl	$0x21, %edx
    2b19:      	jb	0x2f69 <generic_fexit_filter_arg+0x2f69>
    2b1f:      	movq	0x28(%r15), %rdx
    2b23:      	cmpl	$0x2, %eax
    2b26:      	jle	0x2b51 <generic_fexit_filter_arg+0x2b51>
    2b28:      	leal	-0x3(%rax), %ecx
    2b2b:      	cmpl	$0x2, %ecx
    2b2e:      	jb	0x2b7c <generic_fexit_filter_arg+0x2b7c>
    2b30:      	cmpl	$0x6, %eax
    2b33:      	je	0x276 <generic_fexit_filter_arg+0x276>
    2b39:      	cmpl	$0xc, %eax
    2b3c:      	jne	0xb8 <generic_fexit_filter_arg+0xb8>
    2b42:      	testq	%rdx, (%rbp)
    2b46:      	jne	0x276 <generic_fexit_filter_arg+0x276>
    2b4c:      	jmp	0x2f69 <generic_fexit_filter_arg+0x2f69>
    2b51:      	cmpl	$0x1, %eax
    2b54:      	je	0x2bd4 <generic_fexit_filter_arg+0x2bd4>
    2b56:      	cmpl	$0x2, %eax
    2b59:      	jne	0xb8 <generic_fexit_filter_arg+0xb8>
    2b5f:      	cmpl	$0xc, %ecx
    2b62:      	je	0x2b6d <generic_fexit_filter_arg+0x2b6d>
    2b64:      	cmpl	$0xa, %ecx
    2b67:      	jne	0x2f29 <generic_fexit_filter_arg+0x2f29>
    2b6d:      	cmpq	%rdx, (%rbp)
    2b71:      	jl	0x276 <generic_fexit_filter_arg+0x276>
    2b77:      	jmp	0x2f69 <generic_fexit_filter_arg+0x2f69>
    2b7c:      	cmpq	%rdx, (%rbp)
    2b80:      	je	0x2e81 <generic_fexit_filter_arg+0x2e81>
    2b86:      	jmp	0x2f69 <generic_fexit_filter_arg+0x2f69>
    2b8b:      	cmpl	$0xc, %eax
    2b8e:      	jne	0x2cf9 <generic_fexit_filter_arg+0x2cf9>
    2b94:      	movzbl	(%rbp), %esi
    2b98:      	testl	%esi, %edx
    2b9a:      	jne	0x276 <generic_fexit_filter_arg+0x276>
    2ba0:      	jmp	0x2cf9 <generic_fexit_filter_arg+0x2cf9>
    2ba5:      	cmpl	$0xc, %eax
    2ba8:      	jne	0x2d3f <generic_fexit_filter_arg+0x2d3f>
    2bae:      	movzwl	(%rbp), %esi
    2bb2:      	testl	%esi, %edx
    2bb4:      	jne	0x276 <generic_fexit_filter_arg+0x276>
    2bba:      	jmp	0x2d3f <generic_fexit_filter_arg+0x2d3f>
    2bbf:      	cmpl	%eax, %esi
    2bc1:      	ja	0xb8 <generic_fexit_filter_arg+0xb8>
    2bc7:      	cmpl	%edx, %eax
    2bc9:      	jbe	0x276 <generic_fexit_filter_arg+0x276>
    2bcf:      	jmp	0xb8 <generic_fexit_filter_arg+0xb8>
    2bd4:      	cmpl	$0xc, %ecx
    2bd7:      	je	0x2be2 <generic_fexit_filter_arg+0x2be2>
    2bd9:      	cmpl	$0xa, %ecx
    2bdc:      	jne	0x2f35 <generic_fexit_filter_arg+0x2f35>
    2be2:      	cmpq	%rdx, (%rbp)
    2be6:      	jg	0x276 <generic_fexit_filter_arg+0x276>
    2bec:      	jmp	0x2f69 <generic_fexit_filter_arg+0x2f69>
    2bf1:      	movl	$0x1, %eax
    2bf6:      	movq	(%rip), %rdi            # 0x2bfd <generic_fexit_filter_arg+0x2bfd>
    2bfd:      	leaq	0x38(%rsp), %rsi
    2c02:      	jmp	0x2c3b <generic_fexit_filter_arg+0x2c3b>
    2c04:      	movl	$0x1, %eax
    2c09:      	leaq	0x38(%rsp), %rsi
    2c0e:      	movq	(%rip), %rdi            # 0x2c15 <generic_fexit_filter_arg+0x2c15>
    2c15:      	jmp	0x2c3b <generic_fexit_filter_arg+0x2c3b>
    2c17:      	movl	$0x1, %eax
    2c1c:      	leaq	0x38(%rsp), %rsi
    2c21:      	movq	(%rip), %rdi            # 0x2c28 <generic_fexit_filter_arg+0x2c28>
    2c28:      	jmp	0x2c3b <generic_fexit_filter_arg+0x2c3b>
    2c2a:      	movl	$0x1, %eax
    2c2f:      	leaq	0x38(%rsp), %rsi
    2c34:      	movq	(%rip), %rdi            # 0x2c3b <generic_fexit_filter_arg+0x2c3b>
    2c3b:      	callq	*%rax
    2c3d:      	testq	%rax, %rax
    2c40:      	je	0x2c5b <generic_fexit_filter_arg+0x2c5b>
    2c42:      	movq	%rax, %rdi
    2c45:      	movl	$0x1, %eax
    2c4a:      	movq	0x18(%rsp), %rsi
    2c4f:      	callq	*%rax
    2c51:      	xorl	%ebx, %ebx
    2c53:      	testq	%rax, %rax
    2c56:      	setne	%bl
    2c59:      	jmp	0x2c5d <generic_fexit_filter_arg+0x2c5d>
    2c5b:      	xorl	%ebx, %ebx
    2c5d:      	movq	(%rsp), %rdi
    2c61:      	movq	0x8(%rsp), %r9
    2c66:      	movq	0x10(%rsp), %r11
    2c6b:      	movl	0x4(%r15), %eax
    2c6f:      	cmpq	$0x25, %rax
    2c73:      	ja	0x265 <generic_fexit_filter_arg+0x265>
    2c79:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    2c83:      	btq	%rax, %rcx
    2c87:      	jb	0x2f19 <generic_fexit_filter_arg+0x2f19>
    2c8d:      	jmp	0x265 <generic_fexit_filter_arg+0x265>
    2c92:      	xorl	%ebx, %ebx
    2c94:      	movq	(%rsp), %rdi
    2c98:      	movl	0x4(%r15), %eax
    2c9c:      	cmpq	$0x25, %rax
    2ca0:      	jbe	0x2c79 <generic_fexit_filter_arg+0x2c79>
    2ca2:      	jmp	0x265 <generic_fexit_filter_arg+0x265>
    2ca7:      	cmpl	$0x2, %eax
    2caa:      	je	0x2eaa <generic_fexit_filter_arg+0x2eaa>
    2cb0:      	cmpl	$0x3, %eax
    2cb3:      	jne	0x2ee2 <generic_fexit_filter_arg+0x2ee2>
    2cb9:      	movl	$0x1, %eax
    2cbe:      	movq	(%rip), %rdi            # 0x2cc5 <generic_fexit_filter_arg+0x2cc5>
    2cc5:      	jmp	0x2ec4 <generic_fexit_filter_arg+0x2ec4>
    2cca:      	cmpl	$0x6, %eax
    2ccd:      	je	0x2eb8 <generic_fexit_filter_arg+0x2eb8>
    2cd3:      	cmpl	$0x7, %eax
    2cd6:      	jne	0x2ee2 <generic_fexit_filter_arg+0x2ee2>
    2cdc:      	movl	$0x1, %eax
    2ce1:      	movq	(%rip), %rdi            # 0x2ce8 <generic_fexit_filter_arg+0x2ce8>
    2ce8:      	jmp	0x2ec4 <generic_fexit_filter_arg+0x2ec4>
    2ced:      	movzbl	(%rbp), %esi
    2cf1:      	cmpl	%esi, %edx
    2cf3:      	jb	0x276 <generic_fexit_filter_arg+0x276>
    2cf9:      	cmpl	$0x15, %ecx
    2cfc:      	jb	0x2f69 <generic_fexit_filter_arg+0x2f69>
    2d02:      	movl	0x1c(%r15), %ecx
    2d06:      	cmpl	$0x2, %eax
    2d09:      	jle	0x2e34 <generic_fexit_filter_arg+0x2e34>
    2d0f:      	leal	-0x3(%rax), %edx
    2d12:      	cmpl	$0x2, %edx
    2d15:      	jb	0x2e6f <generic_fexit_filter_arg+0x2e6f>
    2d1b:      	cmpl	$0x6, %eax
    2d1e:      	je	0x276 <generic_fexit_filter_arg+0x276>
    2d24:      	cmpl	$0xc, %eax
    2d27:      	jne	0xb8 <generic_fexit_filter_arg+0xb8>
    2d2d:      	movzbl	(%rbp), %edx
    2d31:      	jmp	0x2d77 <generic_fexit_filter_arg+0x2d77>
    2d33:      	movzwl	(%rbp), %esi
    2d37:      	cmpl	%esi, %edx
    2d39:      	jb	0x276 <generic_fexit_filter_arg+0x276>
    2d3f:      	cmpl	$0x15, %ecx
    2d42:      	jb	0x2f69 <generic_fexit_filter_arg+0x2f69>
    2d48:      	movl	0x1c(%r15), %ecx
    2d4c:      	cmpl	$0x2, %eax
    2d4f:      	jle	0x2e4c <generic_fexit_filter_arg+0x2e4c>
    2d55:      	leal	-0x3(%rax), %edx
    2d58:      	cmpl	$0x2, %edx
    2d5b:      	jb	0x2e75 <generic_fexit_filter_arg+0x2e75>
    2d61:      	cmpl	$0x6, %eax
    2d64:      	je	0x276 <generic_fexit_filter_arg+0x276>
    2d6a:      	cmpl	$0xc, %eax
    2d6d:      	jne	0xb8 <generic_fexit_filter_arg+0xb8>
    2d73:      	movzwl	(%rbp), %edx
    2d77:      	testl	%edx, %ecx
    2d79:      	jne	0x276 <generic_fexit_filter_arg+0x276>
    2d7f:      	jmp	0x2f69 <generic_fexit_filter_arg+0x2f69>
    2d84:      	cmpl	%esi, (%rbp)
    2d87:      	ja	0x276 <generic_fexit_filter_arg+0x276>
    2d8d:      	jmp	0x2d98 <generic_fexit_filter_arg+0x2d98>
    2d8f:      	cmpl	%esi, (%rbp)
    2d92:      	jb	0x276 <generic_fexit_filter_arg+0x276>
    2d98:      	cmpl	$0x15, %edx
    2d9b:      	jb	0x2f69 <generic_fexit_filter_arg+0x2f69>
    2da1:      	movl	0x1c(%r15), %edx
    2da5:      	cmpl	$0x2, %eax
    2da8:      	jle	0x2dd2 <generic_fexit_filter_arg+0x2dd2>
    2daa:      	leal	-0x3(%rax), %ecx
    2dad:      	cmpl	$0x2, %ecx
    2db0:      	jb	0x2e05 <generic_fexit_filter_arg+0x2e05>
    2db2:      	cmpl	$0x6, %eax
    2db5:      	je	0x276 <generic_fexit_filter_arg+0x276>
    2dbb:      	cmpl	$0xc, %eax
    2dbe:      	jne	0xb8 <generic_fexit_filter_arg+0xb8>
    2dc4:      	testl	%edx, (%rbp)
    2dc7:      	jne	0x276 <generic_fexit_filter_arg+0x276>
    2dcd:      	jmp	0x2f69 <generic_fexit_filter_arg+0x2f69>
    2dd2:      	cmpl	$0x1, %eax
    2dd5:      	je	0x2e0f <generic_fexit_filter_arg+0x2e0f>
    2dd7:      	cmpl	$0x2, %eax
    2dda:      	jne	0xb8 <generic_fexit_filter_arg+0xb8>
    2de0:      	cmpl	$0xc, %ecx
    2de3:      	ja	0x2f55 <generic_fexit_filter_arg+0x2f55>
    2de9:      	movl	$0x1402, %esi           # imm = 0x1402
    2dee:      	btl	%ecx, %esi
    2df1:      	jae	0x2f55 <generic_fexit_filter_arg+0x2f55>
    2df7:      	cmpl	%edx, (%rbp)
    2dfa:      	jl	0x276 <generic_fexit_filter_arg+0x276>
    2e00:      	jmp	0x2f69 <generic_fexit_filter_arg+0x2f69>
    2e05:      	cmpl	%edx, (%rbp)
    2e08:      	je	0x2e81 <generic_fexit_filter_arg+0x2e81>
    2e0a:      	jmp	0x2f69 <generic_fexit_filter_arg+0x2f69>
    2e0f:      	cmpl	$0xc, %ecx
    2e12:      	ja	0x2f60 <generic_fexit_filter_arg+0x2f60>
    2e18:      	movl	$0x1402, %esi           # imm = 0x1402
    2e1d:      	btl	%ecx, %esi
    2e20:      	jae	0x2f60 <generic_fexit_filter_arg+0x2f60>
    2e26:      	cmpl	%edx, (%rbp)
    2e29:      	jg	0x276 <generic_fexit_filter_arg+0x276>
    2e2f:      	jmp	0x2f69 <generic_fexit_filter_arg+0x2f69>
    2e34:      	cmpl	$0x1, %eax
    2e37:      	je	0x2f41 <generic_fexit_filter_arg+0x2f41>
    2e3d:      	cmpl	$0x2, %eax
    2e40:      	jne	0xb8 <generic_fexit_filter_arg+0xb8>
    2e46:      	movzbl	(%rbp), %edx
    2e4a:      	jmp	0x2e62 <generic_fexit_filter_arg+0x2e62>
    2e4c:      	cmpl	$0x1, %eax
    2e4f:      	je	0x2f47 <generic_fexit_filter_arg+0x2f47>
    2e55:      	cmpl	$0x2, %eax
    2e58:      	jne	0xb8 <generic_fexit_filter_arg+0xb8>
    2e5e:      	movzwl	(%rbp), %edx
    2e62:      	cmpl	%edx, %ecx
    2e64:      	ja	0x276 <generic_fexit_filter_arg+0x276>
    2e6a:      	jmp	0x2f69 <generic_fexit_filter_arg+0x2f69>
    2e6f:      	movzbl	(%rbp), %edx
    2e73:      	jmp	0x2e79 <generic_fexit_filter_arg+0x2e79>
    2e75:      	movzwl	(%rbp), %edx
    2e79:      	cmpl	%edx, %ecx
    2e7b:      	jne	0x2f69 <generic_fexit_filter_arg+0x2f69>
    2e81:      	xorl	%ebx, %ebx
    2e83:      	cmpl	$0x3, %eax
    2e86:      	sete	%bl
    2e89:      	jmp	0x265 <generic_fexit_filter_arg+0x265>
    2e8e:      	movl	$0x1, %eax
    2e93:      	movq	(%rip), %rdi            # 0x2e9a <generic_fexit_filter_arg+0x2e9a>
    2e9a:      	jmp	0x2ec4 <generic_fexit_filter_arg+0x2ec4>
    2e9c:      	movl	$0x1, %eax
    2ea1:      	movq	(%rip), %rdi            # 0x2ea8 <generic_fexit_filter_arg+0x2ea8>
    2ea8:      	jmp	0x2ec4 <generic_fexit_filter_arg+0x2ec4>
    2eaa:      	movl	$0x1, %eax
    2eaf:      	movq	(%rip), %rdi            # 0x2eb6 <generic_fexit_filter_arg+0x2eb6>
    2eb6:      	jmp	0x2ec4 <generic_fexit_filter_arg+0x2ec4>
    2eb8:      	movl	$0x1, %eax
    2ebd:      	movq	(%rip), %rdi            # 0x2ec4 <generic_fexit_filter_arg+0x2ec4>
    2ec4:      	callq	*%rax
    2ec6:      	testq	%rax, %rax
    2ec9:      	je	0x2ee2 <generic_fexit_filter_arg+0x2ee2>
    2ecb:      	movq	%rax, %rdi
    2ece:      	movl	$0x1, %eax
    2ed3:      	movq	%rbx, %rsi
    2ed6:      	callq	*%rax
    2ed8:      	xorl	%ebx, %ebx
    2eda:      	testq	%rax, %rax
    2edd:      	setne	%bl
    2ee0:      	jmp	0x2ee4 <generic_fexit_filter_arg+0x2ee4>
    2ee2:      	xorl	%ebx, %ebx
    2ee4:      	movq	(%rsp), %rdi
    2ee8:      	movq	0x8(%rsp), %r9
    2eed:      	movq	0x10(%rsp), %r11
    2ef2:      	movl	0x4(%r15), %eax
    2ef6:      	cmpq	$0x25, %rax
    2efa:      	ja	0x260 <generic_fexit_filter_arg+0x260>
    2f00:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    2f0a:      	btq	%rax, %rcx
    2f0e:      	movq	0x68(%rsp), %r12
    2f13:      	jae	0x265 <generic_fexit_filter_arg+0x265>
    2f19:      	xorl	%eax, %eax
    2f1b:      	testq	%rbx, %rbx
    2f1e:      	sete	%al
    2f21:      	movq	%rax, %rbx
    2f24:      	jmp	0x265 <generic_fexit_filter_arg+0x265>
    2f29:      	cmpq	%rdx, (%rbp)
    2f2d:      	jb	0x276 <generic_fexit_filter_arg+0x276>
    2f33:      	jmp	0x2f69 <generic_fexit_filter_arg+0x2f69>
    2f35:      	cmpq	%rdx, (%rbp)
    2f39:      	ja	0x276 <generic_fexit_filter_arg+0x276>
    2f3f:      	jmp	0x2f69 <generic_fexit_filter_arg+0x2f69>
    2f41:      	movzbl	(%rbp), %edx
    2f45:      	jmp	0x2f4b <generic_fexit_filter_arg+0x2f4b>
    2f47:      	movzwl	(%rbp), %edx
    2f4b:      	cmpl	%edx, %ecx
    2f4d:      	jb	0x276 <generic_fexit_filter_arg+0x276>
    2f53:      	jmp	0x2f69 <generic_fexit_filter_arg+0x2f69>
    2f55:      	cmpl	%edx, (%rbp)
    2f58:      	jb	0x276 <generic_fexit_filter_arg+0x276>
    2f5e:      	jmp	0x2f69 <generic_fexit_filter_arg+0x2f69>
    2f60:      	cmpl	%edx, (%rbp)
    2f63:      	ja	0x276 <generic_fexit_filter_arg+0x276>
    2f69:      	orl	$0x2, %eax
    2f6c:      	cmpl	$0x6, %eax
    2f6f:      	je	0x276 <generic_fexit_filter_arg+0x276>
    2f75:      	jmp	0xb8 <generic_fexit_filter_arg+0xb8>
    2f7a:      	nopw	(%rax,%rax)

0000000000002f80 <generic_fexit_actions>:
    2f80:      	pushq	%rbp
    2f81:      	pushq	%r15
    2f83:      	pushq	%r14
    2f85:      	pushq	%r13
    2f87:      	pushq	%r12
    2f89:      	pushq	%rbx
    2f8a:      	subq	$0xa8, %rsp
    2f91:      	movq	%rdi, 0x80(%rsp)
    2f99:      	movl	$0x0, 0x88(%rsp)
    2fa4:      	movq	(%rip), %rdi            # 0x2fab <generic_fexit_actions+0x2b>
    2fab:      	leaq	0x88(%rsp), %rsi
    2fb3:      	movl	$0x1, %eax
    2fb8:      	callq	*%rax
    2fba:      	testq	%rax, %rax
    2fbd:      	je	0x3aa8 <generic_fexit_actions+0xb28>
    2fc3:      	movq	%rax, %rsi
    2fc6:      	movl	0x5f04(%rax), %ebx
    2fcc:      	cmpl	$0x2, %ebx
    2fcf:      	jl	0x3aa8 <generic_fexit_actions+0xb28>
    2fd5:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    2fdc:      	movq	(%rip), %rdi            # 0x2fe3 <generic_fexit_actions+0x63>
    2fe3:      	movl	$0x1, %eax
    2fe8:      	callq	*%rax
    2fea:      	testq	%rax, %rax
    2fed:      	je	0x3aa8 <generic_fexit_actions+0xb28>
    2ff3:      	movq	%rax, %r14
    2ff6:      	movl	%ebx, %eax
    2ff8:      	andl	$0x7ff, %eax            # imm = 0x7FF
    2ffd:      	addl	(%r14,%rax), %ebx
    3001:      	movl	$0x0, 0x8c(%rsp)
    300c:      	movq	(%rip), %rdi            # 0x3013 <generic_fexit_actions+0x93>
    3013:      	leaq	0x8c(%rsp), %rsi
    301b:      	movl	$0x1, %eax
    3020:      	andl	$0x7ff, %ebx            # imm = 0x7FF
    3026:      	callq	*%rax
    3028:      	testq	%rax, %rax
    302b:      	je	0x3052 <generic_fexit_actions+0xd2>
    302d:      	cmpb	$0x0, (%rax)
    3030:      	sete	0x17(%rsp)
    3035:      	je	0x306d <generic_fexit_actions+0xed>
    3037:      	movl	$0x5, %eax
    303c:      	movq	%rax, 0x78(%rsp)
    3041:      	movl	$0x9, %eax
    3046:      	movq	%rax, 0x70(%rsp)
    304b:      	movl	$0x7, %eax
    3050:      	jmp	0x3086 <generic_fexit_actions+0x106>
    3052:      	movl	$0x4, %eax
    3057:      	movq	%rax, 0x78(%rsp)
    305c:      	movl	$0x8, %eax
    3061:      	movq	%rax, 0x70(%rsp)
    3066:      	movb	$0x1, 0x17(%rsp)
    306b:      	jmp	0x3081 <generic_fexit_actions+0x101>
    306d:      	movl	$0x4, %eax
    3072:      	movq	%rax, 0x78(%rsp)
    3077:      	movl	$0x8, %eax
    307c:      	movq	%rax, 0x70(%rsp)
    3081:      	movl	$0x6, %eax
    3086:      	movq	%rax, 0x68(%rsp)
    308b:      	addq	%rbx, %r14
    308e:      	movb	$0x1, %al
    3090:      	movl	%eax, 0x44(%rsp)
    3094:      	movq	(%rip), %rbp            # 0x309b <generic_fexit_actions+0x11b>
    309b:      	xorl	%r12d, %r12d
    309e:      	xorl	%r15d, %r15d
    30a1:      	jmp	0x30ca <generic_fexit_actions+0x14a>
    30a3:      	incl	%r15d
    30a6:      	movl	0x4(%r14,%r15,4), %eax
    30ab:      	movl	%eax, 0x78(%rdx)
    30ae:      	nop
    30b0:      	movq	%r13, 0x70(%rdx)
    30b4:      	incl	%r15d
    30b7:      	movl	%r15d, %ebx
    30ba:      	incl	%r12d
    30bd:      	movl	%ebx, %r15d
    30c0:      	cmpl	$0x3, %r12d
    30c4:      	je	0x3a81 <generic_fexit_actions+0xb01>
    30ca:      	leal	0x4(,%r15,4), %eax
    30d2:      	cmpl	(%r14), %eax
    30d5:      	jae	0x3a81 <generic_fexit_actions+0xb01>
    30db:      	movl	%r15d, %eax
    30de:      	movslq	0x4(%r14,%rax,4), %r13
    30e3:      	movl	$0x0, 0x90(%rsp)
    30ee:      	movl	$0x1, %eax
    30f3:      	leaq	0x90(%rsp), %rsi
    30fb:      	movq	%rbp, %rdi
    30fe:      	callq	*%rax
    3100:      	xorl	%ebx, %ebx
    3102:      	testq	%rax, %rax
    3105:      	je	0x30ba <generic_fexit_actions+0x13a>
    3107:      	movq	%rax, %rdx
    310a:      	cmpl	$0x7, %r13d
    310e:      	jg	0x3140 <generic_fexit_actions+0x1c0>
    3110:      	cmpl	$0x3, %r13d
    3114:      	jg	0x3196 <generic_fexit_actions+0x216>
    311a:      	cmpl	$0x1, %r13d
    311e:      	jg	0x32e7 <generic_fexit_actions+0x367>
    3124:      	testl	%r13d, %r13d
    3127:      	je	0x34f7 <generic_fexit_actions+0x577>
    312d:      	cmpl	$0x1, %r13d
    3131:      	je	0x3300 <generic_fexit_actions+0x380>
    3137:      	jmp	0x30b0 <generic_fexit_actions+0x130>
    313c:      	nopl	(%rax)
    3140:      	cmpl	$0xb, %r13d
    3144:      	jg	0x32b0 <generic_fexit_actions+0x330>
    314a:      	leal	-0xa(%r13), %eax
    314e:      	cmpl	$0x2, %eax
    3151:      	jb	0x338f <generic_fexit_actions+0x40f>
    3157:      	cmpl	$0x8, %r13d
    315b:      	je	0x3451 <generic_fexit_actions+0x4d1>
    3161:      	cmpl	$0x9, %r13d
    3165:      	jne	0x30b0 <generic_fexit_actions+0x130>
    316b:      	movq	%r13, 0x8(%rsp)
    3170:      	movq	%r14, %rax
    3173:      	movq	%rbp, %r13
    3176:      	incl	%r15d
    3179:      	movl	0x4(%r14,%r15,4), %eax
    317e:      	movq	%rdx, %rbp
    3181:      	movl	$0x3, %ebx
    3186:      	cmpb	$0x0, 0x17(%rsp)
    318b:      	jne	0x35d3 <generic_fexit_actions+0x653>
    3191:      	jmp	0x35f8 <generic_fexit_actions+0x678>
    3196:      	leal	-0x6(%r13), %eax
    319a:      	cmpl	$0x2, %eax
    319d:      	jb	0x30a3 <generic_fexit_actions+0x123>
    31a3:      	cmpl	$0x4, %r13d
    31a7:      	je	0x345e <generic_fexit_actions+0x4de>
    31ad:      	cmpl	$0x5, %r13d
    31b1:      	jne	0x30b0 <generic_fexit_actions+0x130>
    31b7:      	leal	0x1(%r15), %eax
    31bb:      	movl	0x4(%r14,%rax,4), %eax
    31c0:      	addl	$0x2, %r15d
    31c4:      	movl	0x4(%r14,%r15,4), %ebx
    31c9:      	movq	$0x0, 0x20(%rsp)
    31d2:      	movq	$0x0, 0x18(%rsp)
    31db:      	andl	$0x7, %eax
    31de:      	cmpl	$0x4, %eax
    31e1:      	ja	0x30b0 <generic_fexit_actions+0x130>
    31e7:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    31ef:      	jne	0x30b0 <generic_fexit_actions+0x130>
    31f5:      	movq	0x5e78(%rdx,%rax,8), %rax
    31fd:      	andl	$0x7ff, %eax            # imm = 0x7FF
    3202:      	movl	0x90(%rdx,%rax), %eax
    3209:      	movl	%eax, 0x20(%rsp)
    320d:      	movl	$0xe, %eax
    3212:      	movq	%rdx, 0x8(%rsp)
    3217:      	callq	*%rax
    3219:      	shrq	$0x20, %rax
    321d:      	movq	%rax, 0x18(%rsp)
    3222:      	movl	$0x1, %eax
    3227:      	leaq	0x18(%rsp), %rsi
    322c:      	movq	(%rip), %rdi            # 0x3233 <generic_fexit_actions+0x2b3>
    3233:      	callq	*%rax
    3235:      	movq	0x8(%rsp), %rdx
    323a:      	testq	%rax, %rax
    323d:      	je	0x30b0 <generic_fexit_actions+0x130>
    3243:      	andl	$0x7, %ebx
    3246:      	cmpl	$0x4, %ebx
    3249:      	ja	0x30b0 <generic_fexit_actions+0x130>
    324f:      	cmpl	$0x0, 0x5ea0(%rdx,%rbx,4)
    3257:      	jne	0x30b0 <generic_fexit_actions+0x130>
    325d:      	movq	0x5e78(%rdx,%rbx,8), %rcx
    3265:      	movl	$0x0, 0x24(%rsp)
    326d:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    3273:      	movl	0x90(%rdx,%rcx), %ecx
    327a:      	movl	%ecx, 0x20(%rsp)
    327e:      	movq	%rax, %rbx
    3281:      	movl	$0xe, %eax
    3286:      	callq	*%rax
    3288:      	shrq	$0x20, %rax
    328c:      	movq	%rax, 0x18(%rsp)
    3291:      	movl	$0x2, %eax
    3296:      	xorl	%ecx, %ecx
    3298:      	leaq	0x18(%rsp), %rsi
    329d:      	movq	(%rip), %rdi            # 0x32a4 <generic_fexit_actions+0x324>
    32a4:      	movq	%rbx, %rdx
    32a7:      	xorl	%ecx, %ecx
    32a9:      	callq	*%rax
    32ab:      	jmp	0x34ed <generic_fexit_actions+0x56d>
    32b0:      	cmpl	$0xc, %r13d
    32b4:      	je	0x35e4 <generic_fexit_actions+0x664>
    32ba:      	cmpl	$0xd, %r13d
    32be:      	je	0x3476 <generic_fexit_actions+0x4f6>
    32c4:      	cmpl	$0xe, %r13d
    32c8:      	jne	0x30b0 <generic_fexit_actions+0x130>
    32ce:      	movq	%r13, 0x8(%rsp)
    32d3:      	movq	%rbp, %r13
    32d6:      	movq	%rdx, %rbp
    32d9:      	addl	$0x2, %r15d
    32dd:      	movq	0x70(%rsp), %rbx
    32e2:      	jmp	0x35f8 <generic_fexit_actions+0x678>
    32e7:      	movl	$0x9, %eax
    32ec:      	cmpl	$0x2, %r13d
    32f0:      	je	0x35bc <generic_fexit_actions+0x63c>
    32f6:      	cmpl	$0x3, %r13d
    32fa:      	jne	0x30b0 <generic_fexit_actions+0x130>
    3300:      	movq	%rdx, 0x8(%rsp)
    3305:      	leal	0x1(%r15), %eax
    3309:      	movq	%r14, %rcx
    330c:      	movl	0x4(%r14,%rax,4), %r14d
    3311:      	addl	$0x2, %r15d
    3315:      	movq	%rcx, %rbp
    3318:      	movl	0x4(%rcx,%r15,4), %eax
    331d:      	movq	%rax, 0x38(%rsp)
    3322:      	movq	$0x0, 0x20(%rsp)
    332b:      	movq	$0x0, 0x18(%rsp)
    3334:      	movl	$0x0, 0x28(%rsp)
    333c:      	movl	$0x1, %eax
    3341:      	leaq	0x28(%rsp), %rsi
    3346:      	movq	(%rip), %rdi            # 0x334d <generic_fexit_actions+0x3cd>
    334d:      	callq	*%rax
    334f:      	xorl	%ecx, %ecx
    3351:      	testq	%rax, %rax
    3354:      	je	0x3788 <generic_fexit_actions+0x808>
    335a:      	andl	$0x7, %r14d
    335e:      	cmpl	$0x4, %r14d
    3362:      	movq	0x8(%rsp), %rdx
    3367:      	ja	0x3378 <generic_fexit_actions+0x3f8>
    3369:      	cmpl	$0x0, 0x5ea0(%rdx,%r14,4)
    3372:      	je	0x362d <generic_fexit_actions+0x6ad>
    3378:      	movq	%rbp, %r14
    337b:      	movq	(%rip), %rbp            # 0x3382 <generic_fexit_actions+0x402>
    3382:      	testl	%ecx, %ecx
    3384:      	jne	0x30ba <generic_fexit_actions+0x13a>
    338a:      	jmp	0x30b0 <generic_fexit_actions+0x130>
    338f:      	incl	%r15d
    3392:      	movl	0x4(%r14,%r15,4), %eax
    3397:      	andl	$0x7, %eax
    339a:      	xorl	%ecx, %ecx
    339c:      	cmpl	$0x4, %eax
    339f:      	ja	0x3797 <generic_fexit_actions+0x817>
    33a5:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    33ad:      	jne	0x3797 <generic_fexit_actions+0x817>
    33b3:      	movq	0x5e78(%rdx,%rax,8), %rax
    33bb:      	andl	$0x7ff, %eax            # imm = 0x7FF
    33c0:      	movq	0xb8(%rdx,%rax), %rax
    33c8:      	movq	%rax, 0x28(%rsp)
    33cd:      	testq	%rax, %rax
    33d0:      	je	0x3797 <generic_fexit_actions+0x817>
    33d6:      	movq	%rdx, 0x8(%rsp)
    33db:      	cmpl	$0xa, %r13d
    33df:      	jne	0x37a4 <generic_fexit_actions+0x824>
    33e5:      	movl	$0xe, %eax
    33ea:      	callq	*%rax
    33ec:      	movq	%rax, 0x38(%rsp)
    33f1:      	shrq	$0x20, %rax
    33f5:      	movl	%eax, 0x18(%rsp)
    33f9:      	movl	$0x1, %eax
    33fe:      	leaq	0x18(%rsp), %rsi
    3403:      	movq	(%rip), %rdi            # 0x340a <generic_fexit_actions+0x48a>
    340a:      	callq	*%rax
    340c:      	xorl	%ecx, %ecx
    340e:      	testq	%rax, %rax
    3411:      	movq	0x8(%rsp), %rdx
    3416:      	je	0x3797 <generic_fexit_actions+0x817>
    341c:      	movl	(%rax), %ecx
    341e:      	movl	%ecx, 0x18(%rsp)
    3422:      	movq	0x38(%rsp), %rcx
    3427:      	movl	%ecx, 0x1c(%rsp)
    342b:      	movq	0x8(%rax), %rax
    342f:      	movq	%rax, 0x20(%rsp)
    3434:      	xorl	%ecx, %ecx
    3436:      	movl	$0x2, %eax
    343b:      	leaq	0x28(%rsp), %rsi
    3440:      	leaq	0x18(%rsp), %rdx
    3445:      	movq	(%rip), %rdi            # 0x344c <generic_fexit_actions+0x4cc>
    344c:      	jmp	0x36f0 <generic_fexit_actions+0x770>
    3451:      	movl	$0x0, 0x44(%rsp)
    3459:      	jmp	0x30b0 <generic_fexit_actions+0x130>
    345e:      	movq	%r13, 0x8(%rsp)
    3463:      	movq	%rbp, %r13
    3466:      	movq	%rdx, %rbp
    3469:      	incl	%r15d
    346c:      	movq	0x78(%rsp), %rbx
    3471:      	jmp	0x35f8 <generic_fexit_actions+0x678>
    3476:      	movq	%rdx, 0x8(%rsp)
    347b:      	movl	$0xe, %eax
    3480:      	callq	*%rax
    3482:      	movq	%rax, 0x50(%rsp)
    3487:      	movl	$0x1, %eax
    348c:      	leaq	0x50(%rsp), %rsi
    3491:      	movq	(%rip), %rdi            # 0x3498 <generic_fexit_actions+0x518>
    3498:      	callq	*%rax
    349a:      	testq	%rax, %rax
    349d:      	je	0x34ed <generic_fexit_actions+0x56d>
    349f:      	movq	0x4(%rax), %rax
    34a3:      	movq	%rax, 0x28(%rsp)
    34a8:      	movl	$0x2, 0x30(%rsp)
    34b0:      	movl	$0x1, %eax
    34b5:      	leaq	0x28(%rsp), %rsi
    34ba:      	movq	(%rip), %rbx            # 0x34c1 <generic_fexit_actions+0x541>
    34c1:      	movq	%rbx, %rdi
    34c4:      	callq	*%rax
    34c6:      	movl	$0x1, 0x5c(%rsp)
    34ce:      	testq	%rax, %rax
    34d1:      	je	0x3708 <generic_fexit_actions+0x788>
    34d7:      	lock
    34d8:      	incl	(%rax)
    34da:      	movl	$0x3, %eax
    34df:      	leaq	0x50(%rsp), %rsi
    34e4:      	movq	(%rip), %rdi            # 0x34eb <generic_fexit_actions+0x56b>
    34eb:      	callq	*%rax
    34ed:      	movq	0x8(%rsp), %rdx
    34f2:      	jmp	0x30b0 <generic_fexit_actions+0x130>
    34f7:      	movq	%rdx, 0x8(%rsp)
    34fc:      	leal	0x1(%r15), %eax
    3500:      	movl	0x4(%r14,%rax,4), %ebx
    3505:      	leal	0x2(%r15), %eax
    3509:      	movl	0x4(%r14,%rax,4), %eax
    350e:      	movl	%eax, 0x60(%rsp)
    3512:      	movl	$0x7d, %eax
    3517:      	callq	*%rax
    3519:      	movq	%rax, 0x18(%rsp)
    351e:      	movl	$0x0, 0x50(%rsp)
    3526:      	movq	%rbx, 0xa0(%rsp)
    352e:      	testq	%rbx, %rbx
    3531:      	je	0x39a8 <generic_fexit_actions+0xa28>
    3537:      	movl	$0x1, %eax
    353c:      	movq	(%rip), %rdi            # 0x3543 <generic_fexit_actions+0x5c3>
    3543:      	leaq	0x50(%rsp), %rsi
    3548:      	callq	*%rax
    354a:      	testq	%rax, %rax
    354d:      	je	0x39a8 <generic_fexit_actions+0xa28>
    3553:      	movq	%rax, 0x48(%rsp)
    3558:      	movq	%rax, %rbx
    355b:      	movl	$0x1, %eax
    3560:      	leaq	0x50(%rsp), %rsi
    3565:      	movq	(%rip), %rdi            # 0x356c <generic_fexit_actions+0x5ec>
    356c:      	callq	*%rax
    356e:      	movq	%rax, %rdx
    3571:      	movq	0x8(%rsp), %rcx
    3576:      	movq	0x60(%rcx), %rax
    357a:      	movq	%rax, (%rbx)
    357d:      	movq	0x70(%rcx), %rax
    3581:      	movq	%rax, 0x8(%rbx)
    3585:      	xorl	%eax, %eax
    3587:      	movq	%rax, 0x38(%rsp)
    358c:      	movl	$0x0, %eax
    3591:      	movl	0x60(%rsp), %esi
    3595:      	cmpl	$0x2, %esi
    3598:      	je	0x37cf <generic_fexit_actions+0x84f>
    359e:      	cmpl	$0x1, %esi
    35a1:      	je	0x37cc <generic_fexit_actions+0x84c>
    35a7:      	testl	%esi, %esi
    35a9:      	jne	0x39a8 <generic_fexit_actions+0xa28>
    35af:      	movq	0x8(%rsp), %rax
    35b4:      	movl	0x7c(%rax), %eax
    35b7:      	jmp	0x37cf <generic_fexit_actions+0x84f>
    35bc:      	movq	%r13, 0x8(%rsp)
    35c1:      	movq	%rbp, %r13
    35c4:      	movq	%rdx, %rbp
    35c7:      	movl	$0x3, %ebx
    35cc:      	cmpb	$0x0, 0x17(%rsp)
    35d1:      	je	0x35f8 <generic_fexit_actions+0x678>
    35d3:      	movslq	%eax, %rdi
    35d6:      	movl	$0x6d, %eax
    35db:      	callq	*%rax
    35dd:      	movl	$0x2, %ebx
    35e2:      	jmp	0x35f8 <generic_fexit_actions+0x678>
    35e4:      	movq	%r13, 0x8(%rsp)
    35e9:      	movq	%rbp, %r13
    35ec:      	movq	%rdx, %rbp
    35ef:      	addl	$0x3, %r15d
    35f3:      	movq	0x68(%rsp), %rbx
    35f8:      	movl	$0x0, 0x18(%rsp)
    3600:      	movl	$0x1, %eax
    3605:      	leaq	0x18(%rsp), %rsi
    360a:      	movq	(%rip), %rdi            # 0x3611 <generic_fexit_actions+0x691>
    3611:      	callq	*%rax
    3613:      	testq	%rax, %rax
    3616:      	je	0x361d <generic_fexit_actions+0x69d>
    3618:      	lock
    3619:      	incq	(%rax,%rbx,8)
    361d:      	movq	%rbp, %rdx
    3620:      	movq	%r13, %rbp
    3623:      	movq	0x8(%rsp), %r13
    3628:      	jmp	0x30b0 <generic_fexit_actions+0x130>
    362d:      	movq	%rax, 0x48(%rsp)
    3632:      	movq	0x5e78(%rdx,%r14,8), %rax
    363a:      	movl	$0x0, 0x24(%rsp)
    3642:      	andl	$0x7ff, %eax            # imm = 0x7FF
    3647:      	movl	0x90(%rdx,%rax), %eax
    364e:      	movl	%eax, 0x20(%rsp)
    3652:      	movl	$0xe, %eax
    3657:      	callq	*%rax
    3659:      	shrq	$0x20, %rax
    365d:      	movq	%rax, 0x18(%rsp)
    3662:      	cmpl	$0x1, %r13d
    3666:      	jne	0x3772 <generic_fexit_actions+0x7f2>
    366c:      	movq	0x38(%rsp), %rax
    3671:      	andl	$0x7, %eax
    3674:      	cmpl	$0x4, %eax
    3677:      	movq	%rbp, %r14
    367a:      	movl	$0x0, %ecx
    367f:      	ja	0x378b <generic_fexit_actions+0x80b>
    3685:      	movq	0x8(%rsp), %rdx
    368a:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    3692:      	movq	(%rip), %rbp            # 0x3699 <generic_fexit_actions+0x719>
    3699:      	jne	0x3797 <generic_fexit_actions+0x817>
    369f:      	movq	0x5e78(%rdx,%rax,8), %rax
    36a7:      	andl	$0x7ff, %eax            # imm = 0x7FF
    36ac:      	addq	%rax, %rdx
    36af:      	addq	$0x90, %rdx
    36b6:      	movq	0x8(%rsp), %rcx
    36bb:      	movl	0x90(%rcx,%rax), %esi
    36c2:      	andl	$0xfff, %esi            # imm = 0xFFF
    36c8:      	addq	$0x8, %rsi
    36cc:      	movl	$0x4, %eax
    36d1:      	movq	0x48(%rsp), %rdi
    36d6:      	callq	*%rax
    36d8:      	xorl	%ecx, %ecx
    36da:      	movl	$0x2, %eax
    36df:      	leaq	0x18(%rsp), %rsi
    36e4:      	movq	(%rip), %rdi            # 0x36eb <generic_fexit_actions+0x76b>
    36eb:      	movq	0x48(%rsp), %rdx
    36f0:      	xorl	%ecx, %ecx
    36f2:      	callq	*%rax
    36f4:      	xorl	%ecx, %ecx
    36f6:      	movq	0x8(%rsp), %rdx
    36fb:      	testl	%ecx, %ecx
    36fd:      	jne	0x30ba <generic_fexit_actions+0x13a>
    3703:      	jmp	0x30b0 <generic_fexit_actions+0x130>
    3708:      	movl	$0x2, %eax
    370d:      	movl	$0x1, %ecx
    3712:      	leaq	0x5c(%rsp), %rdx
    3717:      	leaq	0x28(%rsp), %rsi
    371c:      	movq	%rbx, %rdi
    371f:      	callq	*%rax
    3721:      	testq	%rax, %rax
    3724:      	je	0x34da <generic_fexit_actions+0x55a>
    372a:      	movq	%rax, 0x38(%rsp)
    372f:      	negl	%eax
    3731:      	movw	%ax, 0x18(%rsp)
    3736:      	movw	$0x3, 0x1a(%rsp)
    373d:      	movabsq	$0x20000003b, %rax      # imm = 0x20000003B
    3747:      	movq	%rax, 0x1c(%rsp)
    374c:      	movl	$0x1, %eax
    3751:      	leaq	0x18(%rsp), %rsi
    3756:      	movq	(%rip), %rbx            # 0x375d <generic_fexit_actions+0x7dd>
    375d:      	movq	%rbx, %rdi
    3760:      	callq	*%rax
    3762:      	testq	%rax, %rax
    3765:      	je	0x3a28 <generic_fexit_actions+0xaa8>
    376b:      	incl	(%rax)
    376d:      	jmp	0x3a4e <generic_fexit_actions+0xace>
    3772:      	movl	$0x3, %eax
    3777:      	leaq	0x18(%rsp), %rsi
    377c:      	movq	(%rip), %rdi            # 0x3783 <generic_fexit_actions+0x803>
    3783:      	callq	*%rax
    3785:      	movq	%rax, %rcx
    3788:      	movq	%rbp, %r14
    378b:      	movq	(%rip), %rbp            # 0x3792 <generic_fexit_actions+0x812>
    3792:      	movq	0x8(%rsp), %rdx
    3797:      	testl	%ecx, %ecx
    3799:      	jne	0x30ba <generic_fexit_actions+0x13a>
    379f:      	jmp	0x30b0 <generic_fexit_actions+0x130>
    37a4:      	movl	$0x3, %eax
    37a9:      	leaq	0x28(%rsp), %rsi
    37ae:      	movq	(%rip), %rdi            # 0x37b5 <generic_fexit_actions+0x835>
    37b5:      	callq	*%rax
    37b7:      	movq	%rax, %rcx
    37ba:      	movq	0x8(%rsp), %rdx
    37bf:      	testl	%ecx, %ecx
    37c1:      	jne	0x30ba <generic_fexit_actions+0x13a>
    37c7:      	jmp	0x30b0 <generic_fexit_actions+0x130>
    37cc:      	movl	0x10(%rcx), %eax
    37cf:      	movq	%r14, 0x60(%rsp)
    37d4:      	movl	%eax, %eax
    37d6:      	movq	%rbx, 0x98(%rsp)
    37de:      	movq	%rax, 0x10(%rbx)
    37e2:      	movq	0x48(%rsp), %rdi
    37e7:      	addq	$0x18, %rdi
    37eb:      	movl	$0x4, %eax
    37f0:      	movl	$0xc8, %ecx
    37f5:      	movq	%rdi, 0x48(%rsp)
    37fa:      	movl	$0xc8, %esi
    37ff:      	callq	*%rax
    3801:      	xorl	%r14d, %r14d
    3804:      	leaq	0x28(%rsp), %rbx
    3809:      	jmp	0x3823 <generic_fexit_actions+0x8a3>
    380b:      	nopl	(%rax,%rax)
    3810:      	leaq	0x28(%rsp), %rbx
    3815:      	addq	$0x4, %r14
    3819:      	cmpq	$0x14, %r14
    381d:      	je	0x394b <generic_fexit_actions+0x9cb>
    3823:      	movl	$0x0, 0x28(%rsp)
    382b:      	movl	$0x1, %eax
    3830:      	movq	%rbp, %rdi
    3833:      	movq	%rbx, %rsi
    3836:      	callq	*%rax
    3838:      	testq	%rax, %rax
    383b:      	je	0x394b <generic_fexit_actions+0x9cb>
    3841:      	movq	%rax, %rsi
    3844:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    384b:      	movl	$0x1, %eax
    3850:      	movq	(%rip), %rdi            # 0x3857 <generic_fexit_actions+0x8d7>
    3857:      	callq	*%rax
    3859:      	testq	%rax, %rax
    385c:      	je	0x394b <generic_fexit_actions+0x9cb>
    3862:      	cmpl	$-0x1, 0x40(%rax,%r14)
    3868:      	movq	0x8(%rsp), %rdx
    386d:      	je	0x394b <generic_fexit_actions+0x9cb>
    3873:      	movq	0x5e78(%rdx,%r14,2), %rax
    387b:      	movl	0x4(%rdx), %ecx
    387e:      	cmpq	%rcx, %rax
    3881:      	jge	0x394b <generic_fexit_actions+0x9cb>
    3887:      	cmpq	$0x10, %r14
    388b:      	je	0x38f2 <generic_fexit_actions+0x972>
    388d:      	movl	$0x0, 0x28(%rsp)
    3895:      	movl	$0x1, %eax
    389a:      	movq	%rbp, %rdi
    389d:      	movq	%rbx, %rsi
    38a0:      	callq	*%rax
    38a2:      	testq	%rax, %rax
    38a5:      	je	0x38e5 <generic_fexit_actions+0x965>
    38a7:      	movq	%rax, %rsi
    38aa:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    38b1:      	movl	$0x1, %eax
    38b6:      	movq	(%rip), %rdi            # 0x38bd <generic_fexit_actions+0x93d>
    38bd:      	callq	*%rax
    38bf:      	testq	%rax, %rax
    38c2:      	je	0x38e5 <generic_fexit_actions+0x965>
    38c4:      	cmpl	$-0x1, 0x44(%rax,%r14)
    38ca:      	movq	0x8(%rsp), %rdx
    38cf:      	movq	0x5e78(%rdx,%r14,2), %rax
    38d7:      	je	0x38f2 <generic_fexit_actions+0x972>
    38d9:      	movl	0x5e80(%rdx,%r14,2), %ebx
    38e1:      	subl	%eax, %ebx
    38e3:      	jmp	0x38fa <generic_fexit_actions+0x97a>
    38e5:      	movq	0x8(%rsp), %rdx
    38ea:      	movq	0x5e78(%rdx,%r14,2), %rax
    38f2:      	movl	0x4(%rdx), %ebx
    38f5:      	subl	%eax, %ebx
    38f7:      	addl	$0x4, %ebx
    38fa:      	testl	%ebx, %ebx
    38fc:      	jle	0x3810 <generic_fexit_actions+0x890>
    3902:      	addl	$0x3ffc, %eax           # imm = 0x3FFC
    3907:      	andl	$0x3fff, %eax           # imm = 0x3FFF
    390c:      	cmpl	$0x28, %ebx
    390f:      	movl	$0x28, %ecx
    3914:      	cmovgel	%ecx, %ebx
    3917:      	movzbl	0x38(%rsp), %ebp
    391c:      	movq	0x48(%rsp), %rcx
    3921:      	leaq	(%rcx,%rbp), %rdi
    3925:      	addq	%rax, %rdx
    3928:      	addq	$0x90, %rdx
    392f:      	movl	$0x4, %eax
    3934:      	movl	%ebx, %esi
    3936:      	callq	*%rax
    3938:      	addl	%ebp, %ebx
    393a:      	movq	(%rip), %rbp            # 0x3941 <generic_fexit_actions+0x9c1>
    3941:      	movq	%rbx, 0x38(%rsp)
    3946:      	jmp	0x3810 <generic_fexit_actions+0x890>
    394b:      	movl	$0x1, %eax
    3950:      	movq	(%rip), %rdi            # 0x3957 <generic_fexit_actions+0x9d7>
    3957:      	movq	0x98(%rsp), %rbx
    395f:      	movq	%rbx, %rsi
    3962:      	callq	*%rax
    3964:      	testq	%rax, %rax
    3967:      	movq	0x60(%rsp), %r14
    396c:      	je	0x398e <generic_fexit_actions+0xa0e>
    396e:      	imulq	$-0xf4240, 0xa0(%rsp), %rcx # imm = 0xFFF0BDC0
    397a:      	addq	0x18(%rsp), %rcx
    397f:      	cmpq	%rcx, (%rax)
    3982:      	jbe	0x398e <generic_fexit_actions+0xa0e>
    3984:      	movl	$0x0, 0x44(%rsp)
    398c:      	jmp	0x39a8 <generic_fexit_actions+0xa28>
    398e:      	movl	$0x2, %eax
    3993:      	xorl	%ecx, %ecx
    3995:      	movq	(%rip), %rdi            # 0x399c <generic_fexit_actions+0xa1c>
    399c:      	leaq	0x18(%rsp), %rdx
    39a1:      	movq	%rbx, %rsi
    39a4:      	xorl	%ecx, %ecx
    39a6:      	callq	*%rax
    39a8:      	leal	0x3(%r15), %eax
    39ac:      	cmpl	$0x0, 0x4(%r14,%rax,4)
    39b2:      	movq	0x8(%rsp), %rdx
    39b7:      	je	0x39e3 <generic_fexit_actions+0xa63>
    39b9:      	orb	$0x2, 0x1(%rdx)
    39bd:      	movl	$0x1b, %eax
    39c2:      	movq	0x80(%rsp), %rdi
    39ca:      	xorl	%ecx, %ecx
    39cc:      	movq	(%rip), %rsi            # 0x39d3 <generic_fexit_actions+0xa53>
    39d3:      	xorl	%edx, %edx
    39d5:      	callq	*%rax
    39d7:      	movq	0x8(%rsp), %rdx
    39dc:      	movq	%rax, 0x80(%rdx)
    39e3:      	addl	$0x4, %r15d
    39e7:      	cmpl	$0x0, 0x4(%r14,%r15,4)
    39ed:      	je	0x30b0 <generic_fexit_actions+0x130>
    39f3:      	orb	$0x4, 0x1(%rdx)
    39f7:      	movl	$0x1b, %eax
    39fc:      	movq	0x80(%rsp), %rdi
    3a04:      	movq	(%rip), %rsi            # 0x3a0b <generic_fexit_actions+0xa8b>
    3a0b:      	movl	$0x100, %ecx            # imm = 0x100
    3a10:      	movl	$0x100, %edx            # imm = 0x100
    3a15:      	callq	*%rax
    3a17:      	movq	0x8(%rsp), %rdx
    3a1c:      	movq	%rax, 0x88(%rdx)
    3a23:      	jmp	0x30b0 <generic_fexit_actions+0x130>
    3a28:      	movl	$0x1, 0x94(%rsp)
    3a33:      	movl	$0x2, %eax
    3a38:      	xorl	%ecx, %ecx
    3a3a:      	leaq	0x94(%rsp), %rdx
    3a42:      	leaq	0x18(%rsp), %rsi
    3a47:      	movq	%rbx, %rdi
    3a4a:      	xorl	%ecx, %ecx
    3a4c:      	callq	*%rax
    3a4e:      	cmpl	$0x0, 0x38(%rsp)
    3a53:      	je	0x34da <generic_fexit_actions+0x55a>
    3a59:      	movl	$0x1, %eax
    3a5e:      	leaq	0x28(%rsp), %rsi
    3a63:      	movq	(%rip), %rdi            # 0x3a6a <generic_fexit_actions+0xaea>
    3a6a:      	callq	*%rax
    3a6c:      	testq	%rax, %rax
    3a6f:      	je	0x34da <generic_fexit_actions+0x55a>
    3a75:      	movl	0x5c(%rsp), %ecx
    3a79:      	lock
    3a7a:      	addl	%ecx, (%rax)
    3a7c:      	jmp	0x34da <generic_fexit_actions+0x55a>
    3a81:      	cmpb	$0x0, 0x44(%rsp)
    3a86:      	je	0x3aa8 <generic_fexit_actions+0xb28>
    3a88:      	movq	(%rip), %rsi            # 0x3a8f <generic_fexit_actions+0xb0f>
    3a8f:      	movl	$0x5, %ecx
    3a94:      	movl	$0xc, %eax
    3a99:      	movq	0x80(%rsp), %rdi
    3aa1:      	movl	$0x5, %edx
    3aa6:      	callq	*%rax
    3aa8:      	xorl	%eax, %eax
    3aaa:      	addq	$0xa8, %rsp
    3ab1:      	popq	%rbx
    3ab2:      	popq	%r12
    3ab4:      	popq	%r13
    3ab6:      	popq	%r14
    3ab8:      	popq	%r15
    3aba:      	popq	%rbp
    3abb:      	retq
    3abc:      	nopl	(%rax)

0000000000003ac0 <generic_fexit_output>:
    3ac0:      	pushq	%rbx
    3ac1:      	subq	$0x10, %rsp
    3ac5:      	movq	%rdi, %rbx
    3ac8:      	movl	$0x0, 0x4(%rsp)
    3ad0:      	movq	(%rip), %rdi            # 0x3ad7 <generic_fexit_output+0x17>
    3ad7:      	leaq	0x4(%rsp), %rsi
    3adc:      	movl	$0x1, %eax
    3ae1:      	callq	*%rax
    3ae3:      	testq	%rax, %rax
    3ae6:      	je	0x3b90 <generic_fexit_output+0xd0>
    3aec:      	movq	%rax, %rcx
    3aef:      	movl	$0x90, %eax
    3af4:      	addl	0x4(%rcx), %eax
    3af7:      	andl	$0x7fff, %eax           # imm = 0x7FFF
    3afc:      	cmpl	$0x2328, %eax           # imm = 0x2328
    3b01:      	movl	$0x2328, %r8d           # imm = 0x2328
    3b07:      	cmovbl	%eax, %r8d
    3b0b:      	movq	(%rip), %rsi            # 0x3b12 <generic_fexit_output+0x52>
    3b12:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    3b17:      	movl	$0x19, %eax
    3b1c:      	movq	%rbx, %rdi
    3b1f:      	callq	*%rax
    3b21:      	testq	%rax, %rax
    3b24:      	js	0x3b4d <generic_fexit_output+0x8d>
    3b26:      	movl	$0x0, 0xc(%rsp)
    3b2e:      	movq	(%rip), %rdi            # 0x3b35 <generic_fexit_output+0x75>
    3b35:      	leaq	0xc(%rsp), %rsi
    3b3a:      	movl	$0x1, %eax
    3b3f:      	callq	*%rax
    3b41:      	testq	%rax, %rax
    3b44:      	je	0x3b90 <generic_fexit_output+0xd0>
    3b46:      	lock
    3b47:      	incq	0x8(%rax)
    3b4b:      	jmp	0x3b90 <generic_fexit_output+0xd0>
    3b4d:      	movq	%rax, %rbx
    3b50:      	movl	$0x0, 0x8(%rsp)
    3b58:      	movq	(%rip), %rdi            # 0x3b5f <generic_fexit_output+0x9f>
    3b5f:      	leaq	0x8(%rsp), %rsi
    3b64:      	movl	$0x1, %eax
    3b69:      	callq	*%rax
    3b6b:      	testq	%rax, %rax
    3b6e:      	je	0x3b90 <generic_fexit_output+0xd0>
    3b70:      	cmpq	$-0xc, %rbx
    3b74:      	jg	0x3b98 <generic_fexit_output+0xd8>
    3b76:      	cmpq	$-0x1c, %rbx
    3b7a:      	je	0x3bb2 <generic_fexit_output+0xf2>
    3b7c:      	cmpq	$-0x16, %rbx
    3b80:      	je	0x3bca <generic_fexit_output+0x10a>
    3b82:      	cmpq	$-0x10, %rbx
    3b86:      	jne	0x3bc2 <generic_fexit_output+0x102>
    3b88:      	addq	$0x2f0, %rax            # imm = 0x2F0
    3b8e:      	jmp	0x3bd8 <generic_fexit_output+0x118>
    3b90:      	xorl	%eax, %eax
    3b92:      	addq	$0x10, %rsp
    3b96:      	popq	%rbx
    3b97:      	retq
    3b98:      	cmpq	$-0xb, %rbx
    3b9c:      	je	0x3bba <generic_fexit_output+0xfa>
    3b9e:      	cmpq	$-0x7, %rbx
    3ba2:      	je	0x3bd2 <generic_fexit_output+0x112>
    3ba4:      	cmpq	$-0x2, %rbx
    3ba8:      	jne	0x3bc2 <generic_fexit_output+0x102>
    3baa:      	addq	$0x2e0, %rax            # imm = 0x2E0
    3bb0:      	jmp	0x3bd8 <generic_fexit_output+0x118>
    3bb2:      	addq	$0x300, %rax            # imm = 0x300
    3bb8:      	jmp	0x3bd8 <generic_fexit_output+0x118>
    3bba:      	addq	$0x308, %rax            # imm = 0x308
    3bc0:      	jmp	0x3bd8 <generic_fexit_output+0x118>
    3bc2:      	addq	$0x2d8, %rax            # imm = 0x2D8
    3bc8:      	jmp	0x3bd8 <generic_fexit_output+0x118>
    3bca:      	addq	$0x2f8, %rax            # imm = 0x2F8
    3bd0:      	jmp	0x3bd8 <generic_fexit_output+0x118>
    3bd2:      	addq	$0x2e8, %rax            # imm = 0x2E8
    3bd8:      	lock
    3bd9:      	incq	(%rax)
    3bdc:      	xorl	%eax, %eax
    3bde:      	addq	$0x10, %rsp
    3be2:      	popq	%rbx
    3be3:      	retq

Disassembly of section fexit/generic_fexit:

0000000000000000 <generic_fexit_event>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0xf8, %rsp
      11:      	movq	%rdi, %r13
      14:      	leaq	0xf0(%rsp), %rsi
      1c:      	movl	$0xb8, %eax
      21:      	callq	*%rax
      23:      	movq	0xf0(%rsp), %rax
      2b:      	movq	%rax, 0xb8(%rsp)
      33:      	movl	$0x0, 0xd8(%rsp)
      3e:      	movq	(%rip), %rdi            # 0x45 <generic_fexit_event+0x45>
      45:      	leaq	0xd8(%rsp), %rsi
      4d:      	movl	$0x1, %eax
      52:      	callq	*%rax
      54:      	testq	%rax, %rax
      57:      	je	0x2fb8 <generic_fexit_event+0x2fb8>
      5d:      	movq	%rax, %r15
      60:      	movq	%rax, %rbp
      63:      	leaq	0x5ef8(%rax), %rsi
      6a:      	movl	$0x0, 0x5ef8(%r15)
      75:      	movq	(%rip), %rdi            # 0x7c <generic_fexit_event+0x7c>
      7c:      	movl	$0x1, %eax
      81:      	callq	*%rax
      83:      	testq	%rax, %rax
      86:      	je	0x2fb8 <generic_fexit_event+0x2fb8>
      8c:      	movq	%rax, %r12
      8f:      	movl	(%rax), %eax
      91:      	movq	%rax, 0x60(%rbp)
      95:      	movl	$0xe, %eax
      9a:      	callq	*%rax
      9c:      	cmpq	$-0x16, %rax
      a0:      	jne	0xc1 <generic_fexit_event+0xc1>
      a2:      	leaq	0x20(%r13), %rdx
      a6:      	leaq	0x20(%rsp), %rdi
      ab:      	movl	$0x8, %ecx
      b0:      	movl	$0x4, %eax
      b5:      	movl	$0x8, %esi
      ba:      	callq	*%rax
      bc:      	movq	0x20(%rsp), %rax
      c1:      	movq	%rax, 0x68(%rbp)
      c5:      	movl	$0xe, %eax
      ca:      	callq	*%rax
      cc:      	movl	%eax, 0x7c(%rbp)
      cf:      	movq	0x60(%rbp), %rax
      d3:      	movq	0x68(%rbp), %rcx
      d7:      	movq	%rax, 0x20(%rsp)
      dc:      	movq	%rcx, 0x28(%rsp)
      e1:      	movq	(%rip), %rdi            # 0xe8 <generic_fexit_event+0xe8>
      e8:      	leaq	0x20(%rsp), %rsi
      ed:      	movl	$0x1, %eax
      f2:      	callq	*%rax
      f4:      	testq	%rax, %rax
      f7:      	je	0x2fb8 <generic_fexit_event+0x2fb8>
      fd:      	movq	(%rax), %rbx
     100:      	movq	0x8(%rax), %rcx
     104:      	movq	%rcx, 0x88(%rsp)
     10c:      	movq	0x10(%rax), %rax
     110:      	movq	%rax, 0x80(%rsp)
     118:      	movq	(%rip), %rdi            # 0x11f <generic_fexit_event+0x11f>
     11f:      	leaq	0x20(%rsp), %rsi
     124:      	movl	$0x3, %eax
     129:      	callq	*%rax
     12b:      	movq	%rbx, 0x90(%rbp)
     132:      	movl	0x58(%r12), %eax
     137:      	movl	0x5c(%r12), %r14d
     13c:      	testl	%r14d, %r14d
     13f:      	je	0x1ff <generic_fexit_event+0x1ff>
     145:      	movl	%eax, 0x78(%rsp)
     149:      	movl	$0x0, 0x5ea0(%rbp)
     153:      	movq	0xb8(%rsp), %rbx
     15b:      	movl	$0x0, 0xdc(%rsp)
     166:      	movq	(%rip), %rdi            # 0x16d <generic_fexit_event+0x16d>
     16d:      	leaq	0xdc(%rsp), %rsi
     175:      	movl	$0x1, %eax
     17a:      	callq	*%rax
     17c:      	testq	%rax, %rax
     17f:      	je	0x2f2 <generic_fexit_event+0x2f2>
     185:      	movl	0x5ea0(%rax), %ecx
     18b:      	movl	%ecx, 0x98(%rax)
     191:      	movq	$0xc, 0x5e78(%rax)
     19c:      	testl	%ecx, %ecx
     19e:      	je	0x3cb <generic_fexit_event+0x3cb>
     1a4:      	movl	$0x4, %ebx
     1a9:      	addq	$0x8, %rbx
     1ad:      	movl	0x60(%r12), %eax
     1b2:      	cmpl	$0xb, %eax
     1b5:      	je	0x306 <generic_fexit_event+0x306>
     1bb:      	cmpl	$0xa, %eax
     1be:      	jne	0x31c <generic_fexit_event+0x31c>
     1c4:      	movl	0x10(%rbp), %eax
     1c7:      	movl	%eax, 0x20(%rsp)
     1cb:      	movl	0x7c(%rbp), %eax
     1ce:      	movl	%eax, 0x24(%rsp)
     1d2:      	movq	0x18(%rbp), %rax
     1d6:      	movq	%rax, 0x28(%rsp)
     1db:      	movq	(%rip), %rdi            # 0x1e2 <generic_fexit_event+0x1e2>
     1e2:      	xorl	%ecx, %ecx
     1e4:      	leaq	0xb8(%rsp), %rsi
     1ec:      	leaq	0x20(%rsp), %rdx
     1f1:      	movl	$0x2, %eax
     1f6:      	xorl	%ecx, %ecx
     1f8:      	callq	*%rax
     1fa:      	jmp	0x31c <generic_fexit_event+0x31c>
     1ff:      	movl	$0x8, %ebx
     204:      	addq	$0x90, %r15
     20b:      	cmpl	$0x3, %eax
     20e:      	jne	0x336 <generic_fexit_event+0x336>
     214:      	movq	%r15, 0x18(%rsp)
     219:      	movl	$0x0, (%r15,%rbx)
     221:      	leaq	0x4(%rbx), %r14
     225:      	cmpq	$0x0, 0x80(%rsp)
     22e:      	movq	%r13, 0xb0(%rsp)
     236:      	movq	%r12, 0x60(%rsp)
     23b:      	je	0x432 <generic_fexit_event+0x432>
     241:      	movq	0xb8(%rsp), %r12
     249:      	leaq	0x20(%rsp), %rdi
     24e:      	movl	$0x4, %r15d
     254:      	movl	$0x10, %ecx
     259:      	movl	$0x4, %eax
     25e:      	movq	0x88(%rsp), %rdx
     266:      	movl	$0x10, %esi
     26b:      	callq	*%rax
     26d:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     272:      	testl	%eax, %eax
     274:      	js	0x2d07 <generic_fexit_event+0x2d07>
     27a:      	movq	0x28(%rsp), %rsi
     27f:      	cmpq	%r12, %rsi
     282:      	movq	%r12, %rax
     285:      	cmovbq	%rsi, %r12
     289:      	testq	%rax, %rax
     28c:      	cmovneq	%r12, %rsi
     290:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
     295:      	cmpq	$0xffe, %rsi            # imm = 0xFFE
     29c:      	ja	0x2d07 <generic_fexit_event+0x2d07>
     2a2:      	movq	%rax, %r13
     2a5:      	addq	$0xc, %rbx
     2a9:      	movq	0x18(%rsp), %rax
     2ae:      	movq	%rbx, 0x78(%rsp)
     2b3:      	leaq	(%rax,%rbx), %rdi
     2b7:      	movq	0x20(%rsp), %rcx
     2bc:      	movl	$0x4, %eax
     2c1:      	movq	0x20(%rsp), %rdx
     2c6:      	movq	%rsi, %rbx
     2c9:      	callq	*%rax
     2cb:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     2d0:      	testl	%eax, %eax
     2d2:      	js	0x2d07 <generic_fexit_event+0x2d07>
     2d8:      	movq	%rbx, %rdx
     2db:      	testq	%r13, %r13
     2de:      	je	0xc6e <generic_fexit_event+0xc6e>
     2e4:      	subq	%r12, %r13
     2e7:      	jne	0xc71 <generic_fexit_event+0xc71>
     2ed:      	jmp	0x435 <generic_fexit_event+0x435>
     2f2:      	xorl	%ebx, %ebx
     2f4:      	addq	$0x8, %rbx
     2f8:      	movl	0x60(%r12), %eax
     2fd:      	cmpl	$0xb, %eax
     300:      	jne	0x1bb <generic_fexit_event+0x1bb>
     306:      	movq	(%rip), %rdi            # 0x30d <generic_fexit_event+0x30d>
     30d:      	leaq	0xb8(%rsp), %rsi
     315:      	movl	$0x3, %eax
     31a:      	callq	*%rax
     31c:      	andl	$0x1fff, %ebx           # imm = 0x1FFF
     322:      	movl	0x78(%rsp), %eax
     326:      	addq	$0x90, %r15
     32d:      	cmpl	$0x3, %eax
     330:      	je	0x214 <generic_fexit_event+0x214>
     336:      	cmpl	$0x2, %eax
     339:      	jne	0x2d23 <generic_fexit_event+0x2d23>
     33f:      	movq	%rbp, 0x80(%rsp)
     347:      	movq	%r12, 0x60(%rsp)
     34c:      	movl	$0x0, (%r15,%rbx)
     354:      	movq	0xb8(%rsp), %rbp
     35c:      	cmpq	$0xfff, %rbp            # imm = 0xFFF
     363:      	movl	$0xfff, %r14d           # imm = 0xFFF
     369:      	cmovbq	%rbp, %r14
     36d:      	leaq	(%r15,%rbx), %rdi
     371:      	addq	$0xc, %rdi
     375:      	movl	$0x4, %eax
     37a:      	movq	0x88(%rsp), %rdx
     382:      	movq	%r15, %rcx
     385:      	leaq	0x4(%rbx), %r15
     389:      	leaq	(%rcx,%rbx), %r12
     38d:      	addq	$0x4, %r12
     391:      	movl	$0x4, %ebx
     396:      	movl	%r14d, %esi
     399:      	callq	*%rax
     39b:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     3a0:      	testl	%eax, %eax
     3a2:      	js	0x3b2 <generic_fexit_event+0x3b2>
     3a4:      	movl	%r14d, 0x4(%r12)
     3a9:      	addq	$0x8, %r14
     3ad:      	movl	%ebp, %ecx
     3af:      	movq	%r14, %rbx
     3b2:      	addq	%r15, %rbx
     3b5:      	movl	%ecx, (%r12)
     3b9:      	movq	0x60(%rsp), %r12
     3be:      	movq	0x80(%rsp), %rbp
     3c6:      	jmp	0x2d23 <generic_fexit_event+0x2d23>
     3cb:      	leaq	0x9c(%rax), %rcx
     3d2:      	movq	%rbx, 0x20(%rsp)
     3d7:      	movq	$0x0, 0x68(%rsp)
     3e0:      	cmpl	$0x17, %r14d
     3e4:      	movq	%rax, (%rsp)
     3e8:      	movq	%r13, 0xb0(%rsp)
     3f0:      	movq	%r12, 0x60(%rsp)
     3f5:      	jle	0x44f <generic_fexit_event+0x44f>
     3f7:      	cmpl	$0x18, %r14d
     3fb:      	je	0x46a <generic_fexit_event+0x46a>
     3fd:      	cmpl	$0x25, %r14d
     401:      	je	0x4a8 <generic_fexit_event+0x4a8>
     407:      	cmpl	$0x2a, %r14d
     40b:      	jne	0xa52 <generic_fexit_event+0xa52>
     411:      	movq	$0x0, 0x90(%rsp)
     41d:      	movq	%rbx, 0x98(%rsp)
     425:      	leaq	0x90(%rsp), %r12
     42d:      	jmp	0x4d5 <generic_fexit_event+0x4d5>
     432:      	xorl	%r12d, %r12d
     435:      	movq	0x18(%rsp), %rax
     43a:      	movl	%r12d, (%rax,%r14)
     43e:      	movl	%r12d, 0x4(%rax,%r14)
     443:      	addq	$0x8, %r12
     447:      	movq	%r12, %r15
     44a:      	jmp	0x2d10 <generic_fexit_event+0x2d10>
     44f:      	cmpl	$0xf, %r14d
     453:      	je	0x997 <generic_fexit_event+0x997>
     459:      	cmpl	$0x10, %r14d
     45d:      	jne	0xa52 <generic_fexit_event+0xa52>
     463:      	leaq	0x10(%rsp), %r14
     468:      	jmp	0x492 <generic_fexit_event+0x492>
     46a:      	leaq	0x10(%rsp), %r14
     46f:      	movl	$0x8, %ecx
     474:      	movl	$0x4, %eax
     479:      	movq	0x20(%rsp), %rdx
     47e:      	movq	%r14, %rdi
     481:      	movl	$0x8, %esi
     486:      	callq	*%rax
     488:      	movq	0x10(%rsp), %rax
     48d:      	movq	%rax, 0x20(%rsp)
     492:      	leaq	0x20(%rsp), %rdx
     497:      	movl	$0x8, %ecx
     49c:      	movl	$0x4, %eax
     4a1:      	leaq	0x10(%rsp), %rdi
     4a6:      	jmp	0x4c5 <generic_fexit_event+0x4c5>
     4a8:      	addq	$0x40, %rbx
     4ac:      	movq	%rbx, 0x20(%rsp)
     4b1:      	leaq	0x10(%rsp), %rdi
     4b6:      	movl	$0x8, %ecx
     4bb:      	movl	$0x4, %eax
     4c0:      	movq	0x20(%rsp), %rdx
     4c5:      	movl	$0x8, %esi
     4ca:      	callq	*%rax
     4cc:      	movq	0x10(%rsp), %r12
     4d1:      	addq	$0x40, %r12
     4d5:      	movl	$0x0, 0xa4(%rsp)
     4e0:      	movq	(%rip), %rdi            # 0x4e7 <generic_fexit_event+0x4e7>
     4e7:      	leaq	0xa4(%rsp), %rsi
     4ef:      	movl	$0x1, %eax
     4f4:      	callq	*%rax
     4f6:      	testq	%rax, %rax
     4f9:      	je	0x5a9 <generic_fexit_event+0x5a9>
     4ff:      	movq	%rax, %r13
     502:      	movq	%r15, 0x18(%rsp)
     507:      	addq	$0x1000, %rax           # imm = 0x1000
     50d:      	movq	%rax, 0x8(%rsp)
     512:      	movl	$0x23, %eax
     517:      	callq	*%rax
     519:      	leaq	0xd50(%rax), %rdx
     520:      	leaq	0xc0(%rsp), %rdi
     528:      	movl	$0x8, %ecx
     52d:      	movl	$0x4, %eax
     532:      	movl	$0x8, %esi
     537:      	callq	*%rax
     539:      	movq	0xc0(%rsp), %r14
     541:      	leaq	0x8(%r12), %rdx
     546:      	leaq	0xc8(%rsp), %rdi
     54e:      	movl	$0x8, %ecx
     553:      	movl	$0x4, %eax
     558:      	leaq	0x18(%r14), %rcx
     55c:      	movq	%rcx, 0xe8(%rsp)
     564:      	movl	$0x8, %esi
     569:      	movq	%rdx, 0xe0(%rsp)
     571:      	callq	*%rax
     573:      	movq	0xc8(%rsp), %r15
     57b:      	leaq	0x10(%r15), %rdx
     57f:      	leaq	0x20(%rsp), %rdi
     584:      	movl	$0x8, %ecx
     589:      	movl	$0x4, %eax
     58e:      	movl	$0x8, %esi
     593:      	callq	*%rax
     595:      	cmpq	$0x0, 0x20(%rsp)
     59b:      	movl	$0x1000, %ebx           # imm = 0x1000
     5a0:      	je	0x5b6 <generic_fexit_event+0x5b6>
     5a2:      	movq	0x8(%rsp), %rcx
     5a7:      	jmp	0x606 <generic_fexit_event+0x606>
     5a9:      	xorl	%r13d, %r13d
     5ac:      	movq	0x60(%rsp), %r12
     5b1:      	jmp	0xc41 <generic_fexit_event+0xc41>
     5b6:      	leaq	0x18(%r15), %rdx
     5ba:      	leaq	0x20(%rsp), %rdi
     5bf:      	movl	$0x8, %ecx
     5c4:      	movl	$0x4, %eax
     5c9:      	movl	$0x8, %esi
     5ce:      	callq	*%rax
     5d0:      	cmpq	%r15, 0x20(%rsp)
     5d5:      	movq	0x8(%rsp), %rcx
     5da:      	je	0x606 <generic_fexit_event+0x606>
     5dc:      	movq	%r13, %rcx
     5df:      	addq	$0xff6, %rcx            # imm = 0xFF6
     5e6:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
     5f0:      	movq	%rax, 0xff6(%r13)
     5f7:      	movw	$0x2964, 0xffe(%r13)    # imm = 0x2964
     601:      	movl	$0xff6, %ebx            # imm = 0xFF6
     606:      	movq	$0x0, 0x28(%rsp)
     60f:      	movq	$0x0, 0x20(%rsp)
     618:      	movq	%r13, 0x30(%rsp)
     61d:      	movq	$0x0, 0x38(%rsp)
     626:      	movq	$0x0, 0x40(%rsp)
     62f:      	movq	$0x0, 0x48(%rsp)
     638:      	movq	%rcx, 0x8(%rsp)
     63d:      	movq	%rcx, 0x50(%rsp)
     642:      	movl	%ebx, 0x58(%rsp)
     646:      	movb	$0x0, 0x5c(%rsp)
     64b:      	addq	$0x20, %r14
     64f:      	leaq	0x20(%rsp), %rdi
     654:      	movl	$0x8, %r15d
     65a:      	movl	$0x4, %eax
     65f:      	leaq	0x28(%rsp), %rbx
     664:      	leaq	0x38(%rsp), %r13
     669:      	movl	$0x8, %esi
     66e:      	movq	%r14, %rdx
     671:      	callq	*%rax
     673:      	movl	$0x8, %ecx
     678:      	movl	$0x4, %eax
     67d:      	movq	0xe8(%rsp), %rdx
     685:      	movq	%rbx, %rdi
     688:      	movl	$0x8, %esi
     68d:      	callq	*%rax
     68f:      	movl	$0x8, %ecx
     694:      	movl	$0x4, %eax
     699:      	movq	0xe0(%rsp), %rdx
     6a1:      	movq	%r13, %rdi
     6a4:      	movl	$0x8, %esi
     6a9:      	callq	*%rax
     6ab:      	movl	$0x8, %ecx
     6b0:      	movl	$0x4, %eax
     6b5:      	leaq	0x40(%rsp), %rdi
     6ba:      	movl	$0x8, %esi
     6bf:      	movq	%r12, %rdx
     6c2:      	callq	*%rax
     6c4:      	movq	0x40(%rsp), %rax
     6c9:      	addq	$-0x20, %rax
     6cd:      	movq	%rax, 0x48(%rsp)
     6d2:      	movl	$0x80, %r12d
     6d8:      	movq	0x38(%rsp), %r14
     6dd:      	movq	0x40(%rsp), %rdx
     6e2:      	movq	0x48(%rsp), %r13
     6e7:      	cmpq	0x20(%rsp), %r14
     6ec:      	jne	0x6f9 <generic_fexit_event+0x6f9>
     6ee:      	cmpq	0x28(%rsp), %rdx
     6f3:      	je	0x867 <generic_fexit_event+0x867>
     6f9:      	movl	$0x4, %eax
     6fe:      	leaq	0xa8(%rsp), %rdi
     706:      	movl	$0x8, %esi
     70b:      	callq	*%rax
     70d:      	cmpq	0xa8(%rsp), %r14
     715:      	je	0x810 <generic_fexit_event+0x810>
     71b:      	leaq	0x18(%r14), %rbx
     71f:      	movl	$0x4, %eax
     724:      	leaq	0x10(%rsp), %rdi
     729:      	movl	$0x8, %esi
     72e:      	movq	%rbx, %rdx
     731:      	callq	*%rax
     733:      	cmpq	%r14, 0x10(%rsp)
     738:      	je	0x810 <generic_fexit_event+0x810>
     73e:      	movl	$0x4, %eax
     743:      	leaq	0xd0(%rsp), %rdi
     74b:      	movl	$0x8, %esi
     750:      	movq	%rbx, %rdx
     753:      	callq	*%rax
     755:      	addq	$0x20, %r14
     759:      	movl	$0x4, %eax
     75e:      	leaq	0x68(%rsp), %rdi
     763:      	movl	$0x10, %ecx
     768:      	movl	$0x10, %esi
     76d:      	movq	%r14, %rdx
     770:      	callq	*%rax
     772:      	movq	0x30(%rsp), %rbx
     777:      	movq	0x50(%rsp), %rax
     77c:      	movl	0x6c(%rsp), %r14d
     781:      	subq	%rbx, %rax
     784:      	movl	0x58(%rsp), %r13d
     789:      	movl	%r14d, %edx
     78c:      	subl	%r13d, %edx
     78f:      	movl	$0x0, %ecx
     794:      	cmovbl	%ecx, %edx
     797:      	addq	0x70(%rsp), %rdx
     79c:      	xorl	%esi, %esi
     79e:      	cmpl	%r14d, %r13d
     7a1:      	seta	%sil
     7a5:      	movl	%r14d, %ecx
     7a8:      	cmovbl	%r13d, %ecx
     7ac:      	addl	%ecx, %esi
     7ae:      	movl	%r13d, %edi
     7b1:      	subl	%esi, %edi
     7b3:      	movl	%edi, 0x58(%rsp)
     7b7:      	subq	%rsi, %rax
     7ba:      	jb	0x86c <generic_fexit_event+0x86c>
     7c0:      	cmpq	$0xfff, %rax            # imm = 0xFFF
     7c6:      	ja	0x86c <generic_fexit_event+0x86c>
     7cc:      	cmpl	%r14d, %r13d
     7cf:      	jbe	0x7d5 <generic_fexit_event+0x7d5>
     7d1:      	movb	$0x2f, (%rbx,%rax)
     7d5:      	xorl	%edi, %edi
     7d7:      	cmpl	%r14d, %r13d
     7da:      	seta	%dil
     7de:      	movzbl	%cl, %esi
     7e1:      	addq	%rax, %rbx
     7e4:      	addq	%rbx, %rdi
     7e7:      	movl	$0x4, %eax
     7ec:      	callq	*%rax
     7ee:      	movq	%rbx, 0x50(%rsp)
     7f3:      	cmpl	%r14d, %r13d
     7f6:      	jbe	0x86c <generic_fexit_event+0x86c>
     7f8:      	movq	0xd0(%rsp), %rax
     800:      	movq	%rax, 0x38(%rsp)
     805:      	decl	%r12d
     808:      	jne	0x6d8 <generic_fexit_event+0x6d8>
     80e:      	jmp	0x86c <generic_fexit_event+0x86c>
     810:      	leaq	0x10(%r13), %rdx
     814:      	movl	$0x4, %eax
     819:      	leaq	0x10(%rsp), %rdi
     81e:      	movl	$0x8, %esi
     823:      	callq	*%rax
     825:      	movq	0x48(%rsp), %rax
     82a:      	cmpq	0x10(%rsp), %rax
     82f:      	je	0x867 <generic_fexit_event+0x867>
     831:      	addq	$0x18, %r13
     835:      	movl	$0x4, %eax
     83a:      	leaq	0x38(%rsp), %rdi
     83f:      	movl	$0x8, %esi
     844:      	movq	%r13, %rdx
     847:      	callq	*%rax
     849:      	movq	0x10(%rsp), %rax
     84e:      	movq	%rax, 0x48(%rsp)
     853:      	addq	$0x20, %rax
     857:      	movq	%rax, 0x40(%rsp)
     85c:      	decl	%r12d
     85f:      	jne	0x6d8 <generic_fexit_event+0x6d8>
     865:      	jmp	0x86c <generic_fexit_event+0x86c>
     867:      	movb	$0x1, 0x5c(%rsp)
     86c:      	movq	0x50(%rsp), %rax
     871:      	movq	0x8(%rsp), %rdx
     876:      	xorl	%ebx, %ebx
     878:      	cmpq	%rdx, %rax
     87b:      	je	0x8b8 <generic_fexit_event+0x8b8>
     87d:      	cmpb	$0x0, 0x5c(%rsp)
     882:      	sete	%cl
     885:      	movl	0x58(%rsp), %edx
     889:      	movl	$0x1000, %r13d          # imm = 0x1000
     88f:      	subl	%edx, %r13d
     892:      	testl	%edx, %edx
     894:      	cmovlel	%edx, %r13d
     898:      	testq	%rax, %rax
     89b:      	movq	(%rsp), %rdi
     89f:      	movq	0x60(%rsp), %r12
     8a4:      	movq	0x18(%rsp), %r15
     8a9:      	je	0xc3e <generic_fexit_event+0xc3e>
     8af:      	movb	%cl, %bl
     8b1:      	addl	%ebx, %ebx
     8b3:      	movq	%rax, %rdx
     8b6:      	jmp	0x8c9 <generic_fexit_event+0x8c9>
     8b8:      	xorl	%r13d, %r13d
     8bb:      	movq	(%rsp), %rdi
     8bf:      	movq	0x60(%rsp), %r12
     8c4:      	movq	0x18(%rsp), %r15
     8c9:      	addq	$0xa0, %rdi
     8d0:      	andl	$0xfff, %r13d           # imm = 0xFFF
     8d7:      	movl	$0x4, %eax
     8dc:      	movl	%r13d, %esi
     8df:      	callq	*%rax
     8e1:      	movq	(%rsp), %rax
     8e5:      	movl	%r13d, 0x9c(%rax)
     8ec:      	leaq	0x20(%rsp), %rdi
     8f1:      	movl	$0x8, %ecx
     8f6:      	movl	$0x4, %eax
     8fb:      	movq	0xe0(%rsp), %rdx
     903:      	movl	$0x8, %esi
     908:      	callq	*%rax
     90a:      	movq	0x20(%rsp), %rcx
     90f:      	addq	$0x30, %rcx
     913:      	leaq	0x68(%rsp), %rdi
     918:      	movl	$0x8, %edx
     91d:      	movl	$0x4, %eax
     922:      	movq	0x20(%rsp), %rdx
     927:      	addq	$0x30, %rdx
     92b:      	movl	$0x8, %esi
     930:      	callq	*%rax
     932:      	movq	0x68(%rsp), %rcx
     937:      	leaq	0x10(%rsp), %rdi
     93c:      	movl	$0x2, %edx
     941:      	movl	$0x4, %eax
     946:      	movq	0x68(%rsp), %rdx
     94b:      	movl	$0x2, %esi
     950:      	callq	*%rax
     952:      	movq	(%rsp), %rcx
     956:      	movl	%ebx, 0xa0(%rcx,%r13)
     95e:      	movzwl	0x10(%rsp), %eax
     963:      	movw	%ax, 0xa4(%rcx,%r13)
     96c:      	addl	$0xa, %r13d
     970:      	movl	$0x4, %ebx
     975:      	testl	%r13d, %r13d
     978:      	jns	0xc41 <generic_fexit_event+0xc41>
     97e:      	movl	$0xffffffff, 0x5ea0(%rcx) # imm = 0xFFFFFFFF
     988:      	movl	$0xffffffff, 0x98(%rcx) # imm = 0xFFFFFFFF
     992:      	jmp	0xc4f <generic_fexit_event+0xc4f>
     997:      	movq	%rcx, 0x8(%rsp)
     99c:      	leaq	0x68(%rsp), %rdi
     9a1:      	leaq	0x20(%rsp), %rdx
     9a6:      	movl	$0x8, %ecx
     9ab:      	movl	$0x4, %eax
     9b0:      	movl	$0x8, %esi
     9b5:      	callq	*%rax
     9b7:      	movq	0x68(%rsp), %r12
     9bc:      	testq	%r12, %r12
     9bf:      	jne	0x4d5 <generic_fexit_event+0x4d5>
     9c5:      	movl	$0x0, 0x90(%rsp)
     9d0:      	movq	(%rip), %rdi            # 0x9d7 <generic_fexit_event+0x9d7>
     9d7:      	leaq	0x90(%rsp), %rsi
     9df:      	movl	$0x1, %eax
     9e4:      	callq	*%rax
     9e6:      	xorl	%r13d, %r13d
     9e9:      	testq	%rax, %rax
     9ec:      	je	0xda1 <generic_fexit_event+0xda1>
     9f2:      	cmpl	$0x19, %r14d
     9f6:      	movq	(%rsp), %rcx
     9fa:      	movq	0x60(%rsp), %r12
     9ff:      	jg	0xea0 <generic_fexit_event+0xea0>
     a05:      	cmpl	$0x12, %r14d
     a09:      	jle	0xed6 <generic_fexit_event+0xed6>
     a0f:      	cmpl	$0x14, %r14d
     a13:      	jle	0x12fd <generic_fexit_event+0x12fd>
     a19:      	cmpl	$0x15, %r14d
     a1d:      	je	0x1bf2 <generic_fexit_event+0x1bf2>
     a23:      	cmpl	$0x16, %r14d
     a27:      	je	0x1b5a <generic_fexit_event+0x1b5a>
     a2d:      	cmpl	$0x17, %r14d
     a31:      	jne	0x970 <generic_fexit_event+0x970>
     a37:      	movl	$0x0, 0xa0(%rcx)
     a41:      	movl	%ebx, 0x9c(%rcx)
     a47:      	movl	$0x8, %r13d
     a4d:      	jmp	0x970 <generic_fexit_event+0x970>
     a52:      	movq	%rcx, 0x8(%rsp)
     a57:      	cmpl	$0x28, %r14d
     a5b:      	ja	0x9c5 <generic_fexit_event+0x9c5>
     a61:      	movl	%r14d, %eax
     a64:      	movabsq	$0x1c1f2027cf2, %rcx    # imm = 0x1C1F2027CF2
     a6e:      	btq	%rax, %rcx
     a72:      	jae	0x9c5 <generic_fexit_event+0x9c5>
     a78:      	movq	%rbx, 0x10(%rsp)
     a7d:      	movl	$0x0, 0xd0(%rsp)
     a88:      	movq	(%rip), %rdi            # 0xa8f <generic_fexit_event+0xa8f>
     a8f:      	leaq	0xd0(%rsp), %rsi
     a97:      	movl	$0x1, %eax
     a9c:      	callq	*%rax
     a9e:      	testq	%rax, %rax
     aa1:      	movq	%r15, 0x18(%rsp)
     aa6:      	je	0xd41 <generic_fexit_event+0xd41>
     aac:      	xorl	%r13d, %r13d
     aaf:      	cmpl	$0x10, %r14d
     ab3:      	jg	0xd5c <generic_fexit_event+0xd5c>
     ab9:      	cmpl	$0x9, %r14d
     abd:      	movq	0x60(%rsp), %r12
     ac2:      	movl	$0x4, %ebx
     ac7:      	jg	0xdaf <generic_fexit_event+0xdaf>
     acd:      	cmpl	$0x4, %r14d
     ad1:      	movq	(%rsp), %rcx
     ad5:      	jle	0xf0a <generic_fexit_event+0xf0a>
     adb:      	cmpl	$0x5, %r14d
     adf:      	je	0x14b2 <generic_fexit_event+0x14b2>
     ae5:      	cmpl	$0x6, %r14d
     ae9:      	je	0xe1c <generic_fexit_event+0xe1c>
     aef:      	cmpl	$0x7, %r14d
     af3:      	jne	0x2056 <generic_fexit_event+0x2056>
     af9:      	movq	%rax, %r15
     afc:      	movq	0x10(%rsp), %r12
     b01:      	movq	%r12, 0xc4(%rcx)
     b08:      	leaq	0xc2(%rcx), %rdi
     b0f:      	leaq	0x10(%r12), %rdx
     b14:      	movl	$0x2, %esi
     b19:      	movq	%rcx, %rbx
     b1c:      	movl	$0x4, %eax
     b21:      	movl	$0x2, %esi
     b26:      	callq	*%rax
     b28:      	leaq	0xd6(%rbx), %rdi
     b2f:      	leaq	0x12(%r12), %rdx
     b34:      	movl	$0x1, %ecx
     b39:      	movl	$0x4, %eax
     b3e:      	movl	$0x1, %esi
     b43:      	callq	*%rax
     b45:      	leaq	0xd4(%rbx), %rdi
     b4c:      	leaq	0x226(%r12), %rdx
     b54:      	movl	$0x2, %ecx
     b59:      	movl	$0x4, %eax
     b5e:      	movl	$0x2, %esi
     b63:      	callq	*%rax
     b65:      	leaq	0xc0(%rbx), %rdi
     b6c:      	leaq	0x224(%r12), %rdx
     b74:      	movl	$0x2, %ecx
     b79:      	movl	$0x4, %eax
     b7e:      	movl	$0x2, %esi
     b83:      	callq	*%rax
     b85:      	leaq	0xcc(%rbx), %rdi
     b8c:      	leaq	0x21c(%r12), %rdx
     b94:      	movl	$0x4, %ecx
     b99:      	movl	$0x4, %eax
     b9e:      	movl	$0x4, %esi
     ba3:      	callq	*%rax
     ba5:      	leaq	0xd0(%rbx), %rdi
     bac:      	leaq	0x218(%r12), %rdx
     bb4:      	movl	$0x4, %ecx
     bb9:      	movl	$0x4, %eax
     bbe:      	movl	$0x4, %esi
     bc3:      	callq	*%rax
     bc5:      	leaq	0xac(%rbx), %r14
     bcc:      	movq	0x8(%rsp), %rax
     bd1:      	movq	$0x0, (%rax)
     bd8:      	movq	$0x0, 0x8(%rax)
     be0:      	movq	$0x0, 0x10(%rax)
     be8:      	movq	$0x0, 0x18(%rax)
     bf0:      	movzwl	0xc2(%rbx), %eax
     bf7:      	cmpl	$0xa, %eax
     bfa:      	je	0x1ef6 <generic_fexit_event+0x1ef6>
     c00:      	cmpl	$0x2, %eax
     c03:      	jne	0x1f2a <generic_fexit_event+0x1f2a>
     c09:      	leaq	0x4(%r12), %rdx
     c0e:      	movl	$0x4, %ecx
     c13:      	movl	$0x4, %eax
     c18:      	movq	0x8(%rsp), %rdi
     c1d:      	movl	$0x4, %esi
     c22:      	callq	*%rax
     c24:      	movl	$0x4, %ecx
     c29:      	movl	$0x4, %eax
     c2e:      	movq	%r14, %rdi
     c31:      	movl	$0x4, %esi
     c36:      	movq	%r12, %rdx
     c39:      	jmp	0x1f28 <generic_fexit_event+0x1f28>
     c3e:      	xorl	%r13d, %r13d
     c41:      	andl	$0x7fffffff, %r13d      # imm = 0x7FFFFFFF
     c48:      	addq	$0x4, %r13
     c4c:      	movq	%r13, %rbx
     c4f:      	movq	0xb0(%rsp), %r13
     c57:      	addq	$0x8, %rbx
     c5b:      	movl	0x60(%r12), %eax
     c60:      	cmpl	$0xb, %eax
     c63:      	jne	0x1bb <generic_fexit_event+0x1bb>
     c69:      	jmp	0x306 <generic_fexit_event+0x306>
     c6e:      	xorl	%r13d, %r13d
     c71:      	cmpq	$0x1, 0x80(%rsp)
     c7a:      	jne	0xc84 <generic_fexit_event+0xc84>
     c7c:      	movq	%rdx, %r12
     c7f:      	jmp	0x435 <generic_fexit_event+0x435>
     c84:      	movq	0x88(%rsp), %rax
     c8c:      	leaq	0x10(%rax), %rdx
     c90:      	leaq	0x20(%rsp), %rdi
     c95:      	movl	$0x4, %r15d
     c9b:      	movl	$0x10, %ecx
     ca0:      	movl	$0x4, %eax
     ca5:      	movl	$0x10, %esi
     caa:      	callq	*%rax
     cac:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     cb1:      	testl	%eax, %eax
     cb3:      	js	0x2d07 <generic_fexit_event+0x2d07>
     cb9:      	movq	0x28(%rsp), %rsi
     cbe:      	movq	%r13, %rax
     cc1:      	cmpq	%r13, %rsi
     cc4:      	movq	%r13, %r12
     cc7:      	cmovbq	%rsi, %r12
     ccb:      	testq	%r13, %r13
     cce:      	cmovneq	%r12, %rsi
     cd2:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
     cd7:      	cmpq	$0xffe, %rsi            # imm = 0xFFE
     cde:      	ja	0x2d07 <generic_fexit_event+0x2d07>
     ce4:      	movq	0x78(%rsp), %rcx
     ce9:      	addq	%rbx, %rcx
     cec:      	movq	0x18(%rsp), %rax
     cf1:      	movq	%rcx, 0x78(%rsp)
     cf6:      	leaq	(%rax,%rcx), %rdi
     cfa:      	movq	0x20(%rsp), %rcx
     cff:      	movl	$0x4, %eax
     d04:      	movq	0x20(%rsp), %rdx
     d09:      	movq	%rsi, (%rsp)
     d0d:      	movq	(%rsp), %rsi
     d11:      	callq	*%rax
     d13:      	movq	(%rsp), %rdx
     d17:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     d1c:      	testl	%eax, %eax
     d1e:      	js	0x2d07 <generic_fexit_event+0x2d07>
     d24:      	addq	%rdx, %rbx
     d27:      	testq	%r13, %r13
     d2a:      	je	0x1783 <generic_fexit_event+0x1783>
     d30:      	subq	%r12, %r13
     d33:      	movq	%r13, %r12
     d36:      	jne	0x1786 <generic_fexit_event+0x1786>
     d3c:      	jmp	0x185d <generic_fexit_event+0x185d>
     d41:      	xorl	%r13d, %r13d
     d44:      	movq	(%rsp), %rcx
     d48:      	movq	0x60(%rsp), %r12
     d4d:      	movl	$0x4, %ebx
     d52:      	movq	0x18(%rsp), %r15
     d57:      	jmp	0x975 <generic_fexit_event+0x975>
     d5c:      	cmpl	$0x1e, %r14d
     d60:      	movq	0x60(%rsp), %r12
     d65:      	movl	$0x4, %ebx
     d6a:      	jg	0xe65 <generic_fexit_event+0xe65>
     d70:      	cmpl	$0x1c, %r14d
     d74:      	jg	0xf5c <generic_fexit_event+0xf5c>
     d7a:      	cmpl	$0x11, %r14d
     d7e:      	je	0x1679 <generic_fexit_event+0x1679>
     d84:      	cmpl	$0x19, %r14d
     d88:      	je	0x13d5 <generic_fexit_event+0x13d5>
     d8e:      	cmpl	$0x1c, %r14d
     d92:      	movq	(%rsp), %rcx
     d96:      	je	0xf1a <generic_fexit_event+0xf1a>
     d9c:      	jmp	0x2056 <generic_fexit_event+0x2056>
     da1:      	movq	(%rsp), %rcx
     da5:      	movq	0x60(%rsp), %r12
     daa:      	jmp	0x970 <generic_fexit_event+0x970>
     daf:      	leal	-0xa(%r14), %eax
     db3:      	cmpl	$0x2, %eax
     db6:      	movq	(%rsp), %rcx
     dba:      	jb	0xf1a <generic_fexit_event+0xf1a>
     dc0:      	leal	-0xc(%r14), %eax
     dc4:      	cmpl	$0x2, %eax
     dc7:      	jb	0xf3b <generic_fexit_event+0xf3b>
     dcd:      	cmpl	$0xe, %r14d
     dd1:      	jne	0x2056 <generic_fexit_event+0x2056>
     dd7:      	leaq	0x20(%rsp), %rdi
     ddc:      	leaq	0x10(%rsp), %rbx
     de1:      	movl	$0x8, %ecx
     de6:      	movl	$0x4, %eax
     deb:      	movl	$0x8, %esi
     df0:      	movq	%rbx, %rdx
     df3:      	callq	*%rax
     df5:      	movq	0x20(%rsp), %rcx
     dfa:      	movl	$0x8, %edx
     dff:      	movl	$0x4, %eax
     e04:      	movq	0x20(%rsp), %rdx
     e09:      	movq	%rbx, %rdi
     e0c:      	movl	$0x4, %ebx
     e11:      	movl	$0x8, %esi
     e16:      	callq	*%rax
     e18:      	movq	(%rsp), %rcx
     e1c:      	movq	0x10(%rsp), %rdx
     e21:      	movq	%rcx, %rdi
     e24:      	addq	$0xa0, %rdi
     e2b:      	movl	$0x1ff, %ecx            # imm = 0x1FF
     e30:      	movl	$0x2d, %eax
     e35:      	movl	$0x1ff, %esi            # imm = 0x1FF
     e3a:      	callq	*%rax
     e3c:      	movq	%rax, %r13
     e3f:      	testq	%rax, %rax
     e42:      	js	0x1775 <generic_fexit_event+0x1775>
     e48:      	leal	-0x1(%r13), %eax
     e4c:      	movq	0x8(%rsp), %rcx
     e51:      	movl	%eax, (%rcx)
     e53:      	addq	$0x3, %r13
     e57:      	movq	(%rsp), %rcx
     e5b:      	movq	0x18(%rsp), %r15
     e60:      	jmp	0x975 <generic_fexit_event+0x975>
     e65:      	cmpl	$0x26, %r14d
     e69:      	jg	0xf8b <generic_fexit_event+0xf8b>
     e6f:      	leal	-0x1f(%r14), %eax
     e73:      	cmpl	$0x2, %eax
     e76:      	jae	0x1281 <generic_fexit_event+0x1281>
     e7c:      	leaq	0x10(%rsp), %rdx
     e81:      	movl	$0x4, %r13d
     e87:      	movl	$0x1, %ecx
     e8c:      	movl	$0x4, %eax
     e91:      	movq	0x8(%rsp), %rdi
     e96:      	movl	$0x1, %esi
     e9b:      	jmp	0xf7b <generic_fexit_event+0xf7b>
     ea0:      	cmpl	$0x20, %r14d
     ea4:      	jle	0x11bd <generic_fexit_event+0x11bd>
     eaa:      	leal	-0x21(%r14), %edx
     eae:      	cmpl	$0x4, %edx
     eb1:      	jae	0x103e <generic_fexit_event+0x103e>
     eb7:      	movl	$0x8, %r13d
     ebd:      	movl	$0x8, %ecx
     ec2:      	movl	$0x4, %eax
     ec7:      	movq	0x8(%rsp), %rdi
     ecc:      	movl	$0x8, %esi
     ed1:      	jmp	0x12ef <generic_fexit_event+0x12ef>
     ed6:      	cmpl	$0x7, %r14d
     eda:      	jg	0x12cc <generic_fexit_event+0x12cc>
     ee0:      	cmpl	$0x2, %r14d
     ee4:      	je	0x1865 <generic_fexit_event+0x1865>
     eea:      	cmpl	$0x3, %r14d
     eee:      	jne	0x970 <generic_fexit_event+0x970>
     ef4:      	movq	$0x0, 0x9c(%rax)
     eff:      	movl	$0x8, %r13d
     f05:      	jmp	0x970 <generic_fexit_event+0x970>
     f0a:      	cmpl	$0x1, %r14d
     f0e:      	je	0xf3b <generic_fexit_event+0xf3b>
     f10:      	cmpl	$0x4, %r14d
     f14:      	jne	0x2056 <generic_fexit_event+0x2056>
     f1a:      	movl	$0x8, %r13d
     f20:      	leaq	0x10(%rsp), %rdx
     f25:      	movl	$0x8, %ecx
     f2a:      	movl	$0x4, %eax
     f2f:      	movq	0x8(%rsp), %rdi
     f34:      	movl	$0x8, %esi
     f39:      	jmp	0xf7b <generic_fexit_event+0xf7b>
     f3b:      	leaq	0x10(%rsp), %rdx
     f40:      	movl	$0x4, %r13d
     f46:      	movl	$0x4, %ecx
     f4b:      	movl	$0x4, %eax
     f50:      	movq	0x8(%rsp), %rdi
     f55:      	movl	$0x4, %esi
     f5a:      	jmp	0xf7b <generic_fexit_event+0xf7b>
     f5c:      	leaq	0x10(%rsp), %rdx
     f61:      	movl	$0x4, %r13d
     f67:      	movl	$0x2, %ecx
     f6c:      	movl	$0x4, %eax
     f71:      	movq	0x8(%rsp), %rdi
     f76:      	movl	$0x2, %esi
     f7b:      	callq	*%rax
     f7d:      	movq	(%rsp), %rcx
     f81:      	movq	0x18(%rsp), %r15
     f86:      	jmp	0x975 <generic_fexit_event+0x975>
     f8b:      	cmpl	$0x27, %r14d
     f8f:      	je	0x1743 <generic_fexit_event+0x1743>
     f95:      	cmpl	$0x28, %r14d
     f99:      	movq	(%rsp), %rcx
     f9d:      	jne	0x2056 <generic_fexit_event+0x2056>
     fa3:      	movq	0x10(%rsp), %r12
     fa8:      	movq	0x8(%rsp), %r14
     fad:      	movq	$0x0, 0x10(%r14)
     fb5:      	movq	$0x0, 0x8(%r14)
     fbd:      	movq	$0x0, (%r14)
     fc4:      	movl	$0x2, %ecx
     fc9:      	movl	$0x4, %eax
     fce:      	movq	%r14, %rdi
     fd1:      	movl	$0x2, %esi
     fd6:      	movq	%r12, %rdx
     fd9:      	callq	*%rax
     fdb:      	testq	%rax, %rax
     fde:      	js	0x2047 <generic_fexit_event+0x2047>
     fe4:      	movzwl	(%r14), %eax
     fe8:      	cmpl	$0xa, %eax
     feb:      	je	0x1feb <generic_fexit_event+0x1feb>
     ff1:      	cmpl	$0x2, %eax
     ff4:      	jne	0x202e <generic_fexit_event+0x202e>
     ffa:      	leaq	0x4(%r12), %rdx
     fff:      	leaq	0x20(%rsp), %rdi
    1004:      	movl	$0x4, %ecx
    1009:      	movl	$0x4, %eax
    100e:      	movl	$0x4, %esi
    1013:      	callq	*%rax
    1015:      	movl	0x20(%rsp), %eax
    1019:      	movq	(%rsp), %rdi
    101d:      	movq	%rax, 0xa4(%rdi)
    1024:      	addq	$0x9e, %rdi
    102b:      	addq	$0x2, %r12
    102f:      	movl	$0x2, %ecx
    1034:      	movl	$0x4, %eax
    1039:      	jmp	0x2024 <generic_fexit_event+0x2024>
    103e:      	cmpl	$0x2b, %r14d
    1042:      	je	0x1cfd <generic_fexit_event+0x1cfd>
    1048:      	cmpl	$0x29, %r14d
    104c:      	jne	0x970 <generic_fexit_event+0x970>
    1052:      	movq	%r15, 0x18(%rsp)
    1057:      	movq	%rax, %r15
    105a:      	addq	$0x18, %rbx
    105e:      	leaq	0x20(%rsp), %rdi
    1063:      	movl	$0x4, %r14d
    1069:      	movl	$0x8, %ecx
    106e:      	movl	$0x4, %eax
    1073:      	movl	$0x8, %esi
    1078:      	movq	%rbx, %rdx
    107b:      	callq	*%rax
    107d:      	movq	0x20(%rsp), %r12
    1082:      	testq	%r12, %r12
    1085:      	je	0x219c <generic_fexit_event+0x219c>
    108b:      	movq	(%rsp), %rbx
    108f:      	movq	%r12, 0xc4(%rbx)
    1096:      	leaq	0xc2(%rbx), %rdi
    109d:      	leaq	0x10(%r12), %rdx
    10a2:      	movl	$0x2, %ecx
    10a7:      	movl	$0x4, %eax
    10ac:      	movl	$0x2, %esi
    10b1:      	callq	*%rax
    10b3:      	leaq	0xd6(%rbx), %rdi
    10ba:      	leaq	0x12(%r12), %rdx
    10bf:      	movl	$0x1, %ecx
    10c4:      	movl	$0x4, %eax
    10c9:      	movl	$0x1, %esi
    10ce:      	callq	*%rax
    10d0:      	leaq	0xd4(%rbx), %rdi
    10d7:      	leaq	0x226(%r12), %rdx
    10df:      	movl	$0x2, %ecx
    10e4:      	movl	$0x4, %eax
    10e9:      	movl	$0x2, %esi
    10ee:      	callq	*%rax
    10f0:      	leaq	0xc0(%rbx), %rdi
    10f7:      	leaq	0x224(%r12), %rdx
    10ff:      	movl	$0x2, %ecx
    1104:      	movl	$0x4, %eax
    1109:      	movl	$0x2, %esi
    110e:      	callq	*%rax
    1110:      	leaq	0xcc(%rbx), %rdi
    1117:      	leaq	0x21c(%r12), %rdx
    111f:      	movl	$0x4, %eax
    1124:      	movl	$0x4, %esi
    1129:      	callq	*%rax
    112b:      	leaq	0xd0(%rbx), %rdi
    1132:      	leaq	0x218(%r12), %rdx
    113a:      	movl	$0x4, %eax
    113f:      	movl	$0x4, %esi
    1144:      	callq	*%rax
    1146:      	leaq	0xac(%rbx), %r14
    114d:      	movq	0x8(%rsp), %rax
    1152:      	movq	$0x0, (%rax)
    1159:      	movq	$0x0, 0x8(%rax)
    1161:      	movq	$0x0, 0x10(%rax)
    1169:      	movq	%rax, %rdi
    116c:      	movq	$0x0, 0x18(%rax)
    1174:      	movzwl	0xc2(%rbx), %eax
    117b:      	cmpl	$0xa, %eax
    117e:      	je	0x2115 <generic_fexit_event+0x2115>
    1184:      	cmpl	$0x2, %eax
    1187:      	jne	0x2144 <generic_fexit_event+0x2144>
    118d:      	leaq	0x4(%r12), %rdx
    1192:      	movl	$0x4, %ecx
    1197:      	movl	$0x4, %eax
    119c:      	movl	$0x4, %esi
    11a1:      	callq	*%rax
    11a3:      	movl	$0x4, %ecx
    11a8:      	movl	$0x4, %eax
    11ad:      	movq	%r14, %rdi
    11b0:      	movl	$0x4, %esi
    11b5:      	movq	%r12, %rdx
    11b8:      	jmp	0x2142 <generic_fexit_event+0x2142>
    11bd:      	cmpl	$0x1a, %r14d
    11c1:      	je	0x1da7 <generic_fexit_event+0x1da7>
    11c7:      	cmpl	$0x1b, %r14d
    11cb:      	jne	0x970 <generic_fexit_event+0x970>
    11d1:      	movq	0x8(%rsp), %rax
    11d6:      	movq	$0x0, 0x48(%rax)
    11de:      	movq	$0x0, 0x40(%rax)
    11e6:      	movq	$0x0, 0x38(%rax)
    11ee:      	movq	$0x0, 0x30(%rax)
    11f6:      	movq	$0x0, 0x28(%rax)
    11fe:      	movq	$0x0, 0x20(%rax)
    1206:      	movq	$0x0, 0x18(%rax)
    120e:      	movq	$0x0, 0x10(%rax)
    1216:      	movq	$0x0, 0x8(%rax)
    121e:      	movq	$0x0, (%rax)
    1225:      	leaq	0xac(%rcx), %rdi
    122c:      	leaq	0x18(%rbx), %rdx
    1230:      	movl	$0x3f, %ecx
    1235:      	movl	$0x2d, %eax
    123a:      	movl	$0x3f, %esi
    123f:      	callq	*%rax
    1241:      	testq	%rax, %rax
    1244:      	js	0x1e20 <generic_fexit_event+0x1e20>
    124a:      	movq	(%rsp), %r14
    124e:      	movq	%r14, %rdi
    1251:      	addq	$0xa4, %rdi
    1258:      	addq	$0x348, %rbx            # imm = 0x348
    125f:      	movl	$0x8, %ecx
    1264:      	movl	$0x4, %eax
    1269:      	movl	$0x8, %esi
    126e:      	movq	%rbx, %rdx
    1271:      	callq	*%rax
    1273:      	movq	%r14, %rcx
    1276:      	movl	$0x50, %r13d
    127c:      	jmp	0x970 <generic_fexit_event+0x970>
    1281:      	cmpl	$0x26, %r14d
    1285:      	movq	(%rsp), %rcx
    1289:      	jne	0x2056 <generic_fexit_event+0x2056>
    128f:      	movq	0x10(%rsp), %rsi
    1294:      	movzwl	%si, %edx
    1297:      	addq	0xb0(%rsp), %rdx
    129f:      	shrl	$0x10, %esi
    12a2:      	andl	$0xfff, %esi            # imm = 0xFFF
    12a8:      	movq	%rcx, %rdi
    12ab:      	addq	$0xa0, %rdi
    12b2:      	incl	%esi
    12b4:      	movl	$0x2d, %eax
    12b9:      	callq	*%rax
    12bb:      	movq	%rax, %r13
    12be:      	testq	%rax, %rax
    12c1:      	jns	0xe48 <generic_fexit_event+0xe48>
    12c7:      	jmp	0x1775 <generic_fexit_event+0x1775>
    12cc:      	cmpl	$0x8, %r14d
    12d0:      	je	0x1901 <generic_fexit_event+0x1901>
    12d6:      	cmpl	$0x12, %r14d
    12da:      	jne	0x970 <generic_fexit_event+0x970>
    12e0:      	xorl	%r13d, %r13d
    12e3:      	movl	$0x4, %eax
    12e8:      	movq	0x8(%rsp), %rdi
    12ed:      	xorl	%esi, %esi
    12ef:      	movq	%rbx, %rdx
    12f2:      	callq	*%rax
    12f4:      	movq	(%rsp), %rcx
    12f8:      	jmp	0x970 <generic_fexit_event+0x970>
    12fd:      	cmpl	$0x13, %r14d
    1301:      	je	0x1c9e <generic_fexit_event+0x1c9e>
    1307:      	cmpl	$0x14, %r14d
    130b:      	jne	0x970 <generic_fexit_event+0x970>
    1311:      	movq	$0x0, 0x20(%rsp)
    131a:      	leaq	0x110(%rbx), %rdx
    1321:      	leaq	0x20(%rsp), %rdi
    1326:      	movl	$0x8, %ecx
    132b:      	movl	$0x4, %eax
    1330:      	leaq	0xd8(%rbx), %r14
    1337:      	movl	$0x8, %esi
    133c:      	callq	*%rax
    133e:      	movq	0x20(%rsp), %rcx
    1343:      	movl	$0x80, %edx
    1348:      	movl	$0x2d, %eax
    134d:      	movq	0x8(%rsp), %rdi
    1352:      	movq	0x20(%rsp), %rdx
    1357:      	movl	$0x80, %esi
    135c:      	callq	*%rax
    135e:      	movq	(%rsp), %rax
    1362:      	leaq	0x12c(%rax), %rdi
    1369:      	movl	$0x4, %ecx
    136e:      	movl	$0x4, %eax
    1373:      	movl	$0x4, %esi
    1378:      	movq	%r14, %rdx
    137b:      	callq	*%rax
    137d:      	movq	(%rsp), %rax
    1381:      	leaq	0x11c(%rax), %rdi
    1388:      	leaq	0xe0(%rbx), %rdx
    138f:      	movl	$0x8, %ecx
    1394:      	movl	$0x4, %eax
    1399:      	movl	$0x8, %esi
    139e:      	callq	*%rax
    13a0:      	movq	(%rsp), %rdi
    13a4:      	addq	$0x124, %rdi            # imm = 0x124
    13ab:      	addq	$0x118, %rbx            # imm = 0x118
    13b2:      	movl	$0x8, %ecx
    13b7:      	movl	$0x4, %eax
    13bc:      	movl	$0x8, %esi
    13c1:      	movq	%rbx, %rdx
    13c4:      	callq	*%rax
    13c6:      	movq	(%rsp), %rcx
    13ca:      	movl	$0x98, %r13d
    13d0:      	jmp	0x970 <generic_fexit_event+0x970>
    13d5:      	movq	%rax, %rbx
    13d8:      	movq	0x10(%rsp), %r14
    13dd:      	leaq	0xa8(%rsp), %rdi
    13e5:      	movl	$0x1, %ecx
    13ea:      	movl	$0x4, %eax
    13ef:      	movl	$0x1, %esi
    13f4:      	movq	%r14, %rdx
    13f7:      	callq	*%rax
    13f9:      	cmpb	$0x1, 0xa8(%rsp)
    1401:      	jne	0x1e28 <generic_fexit_event+0x1e28>
    1407:      	addq	$0x10, %r14
    140b:      	leaq	0x20(%rsp), %rdi
    1410:      	movl	$0x8, %ecx
    1415:      	movl	$0x4, %eax
    141a:      	movl	$0x8, %esi
    141f:      	movq	%r14, %rdx
    1422:      	callq	*%rax
    1424:      	movq	0x20(%rsp), %rdx
    1429:      	leaq	0x68(%rsp), %rdi
    142e:      	movl	$0x8, %ecx
    1433:      	movl	$0x4, %eax
    1438:      	movl	$0x8, %esi
    143d:      	callq	*%rax
    143f:      	movq	0x20(%rsp), %rdx
    1444:      	addq	$0x8, %rdx
    1448:      	leaq	0x90(%rsp), %rdi
    1450:      	movl	$0x8, %ecx
    1455:      	movl	$0x4, %eax
    145a:      	movl	$0x8, %esi
    145f:      	callq	*%rax
    1461:      	movq	0x68(%rsp), %rdx
    1466:      	movq	0x90(%rsp), %r14
    146e:      	cmpq	$0xfff, %r14            # imm = 0xFFF
    1475:      	movl	$0xfff, %r13d           # imm = 0xFFF
    147b:      	cmovbq	%r14, %r13
    147f:      	movq	%rbx, %rdi
    1482:      	addq	$0xa4, %rdi
    1489:      	movl	$0x4, %eax
    148e:      	movl	%r13d, %esi
    1491:      	callq	*%rax
    1493:      	testl	%eax, %eax
    1495:      	js	0x1fc8 <generic_fexit_event+0x1fc8>
    149b:      	movl	%r14d, 0x9c(%rbx)
    14a2:      	movl	%r13d, 0xa0(%rbx)
    14a9:      	addq	$0x8, %r13
    14ad:      	jmp	0x1fd8 <generic_fexit_event+0x1fd8>
    14b2:      	movq	0x10(%rsp), %r14
    14b7:      	leaq	0xc4(%rcx), %rdi
    14be:      	leaq	0x98(%r14), %rdx
    14c5:      	movl	$0x4, %esi
    14ca:      	movq	%rcx, %rbx
    14cd:      	movl	$0x4, %eax
    14d2:      	movl	$0x4, %esi
    14d7:      	callq	*%rax
    14d9:      	leaq	0xc8(%rbx), %rdi
    14e0:      	leaq	0x70(%r14), %rdx
    14e4:      	movl	$0x4, %ecx
    14e9:      	movl	$0x4, %eax
    14ee:      	movl	$0x4, %esi
    14f3:      	callq	*%rax
    14f5:      	leaq	0xcc(%rbx), %rdi
    14fc:      	leaq	0x90(%r14), %rdx
    1503:      	movl	$0x4, %ecx
    1508:      	movl	$0x4, %eax
    150d:      	movl	$0x4, %esi
    1512:      	callq	*%rax
    1514:      	leaq	0xd0(%rbx), %rdi
    151b:      	leaq	0xa8(%r14), %rdx
    1522:      	movl	$0x4, %ecx
    1527:      	movl	$0x4, %eax
    152c:      	movl	$0x4, %esi
    1531:      	callq	*%rax
    1533:      	movq	$0x0, 0x20(%rsp)
    153c:      	leaq	0xc8(%r14), %rdx
    1543:      	leaq	0x20(%rsp), %rdi
    1548:      	movl	$0x8, %ecx
    154d:      	movl	$0x4, %eax
    1552:      	movl	$0x8, %esi
    1557:      	callq	*%rax
    1559:      	leaq	0xb8(%r14), %rdx
    1560:      	leaq	0xa8(%rsp), %rdi
    1568:      	movl	$0x2, %ecx
    156d:      	movl	$0x4, %eax
    1572:      	movl	$0x2, %esi
    1577:      	callq	*%rax
    1579:      	movzwl	0xa8(%rsp), %r12d
    1582:      	addq	0x20(%rsp), %r12
    1587:      	leaq	0xa4(%rsp), %rdi
    158f:      	movl	$0x1, %ecx
    1594:      	movl	$0x4, %eax
    1599:      	movl	$0x1, %esi
    159e:      	movq	%r12, %rdx
    15a1:      	callq	*%rax
    15a3:      	movzbl	0xa4(%rsp), %eax
    15ab:      	shrl	$0x4, %eax
    15ae:      	cmpl	$0x6, %eax
    15b1:      	je	0x1e4a <generic_fexit_event+0x1e4a>
    15b7:      	cmpl	$0x4, %eax
    15ba:      	jne	0x2b77 <generic_fexit_event+0x2b77>
    15c0:      	leaq	0x9(%r12), %rdx
    15c5:      	leaq	0xc0(%rsp), %rdi
    15cd:      	movl	$0x1, %ecx
    15d2:      	movl	$0x4, %eax
    15d7:      	movl	$0x1, %esi
    15dc:      	callq	*%rax
    15de:      	movzbl	0xc0(%rsp), %eax
    15e6:      	movq	(%rsp), %rcx
    15ea:      	movw	%ax, 0xc0(%rcx)
    15f1:      	movw	$0x2, 0xc2(%rcx)
    15fa:      	leaq	0xc(%r12), %rdx
    15ff:      	movq	0x8(%rsp), %rdi
    1604:      	movq	$0x0, (%rdi)
    160b:      	movq	$0x0, 0x8(%rdi)
    1613:      	movq	$0x0, 0x10(%rdi)
    161b:      	movq	$0x0, 0x18(%rdi)
    1623:      	movl	$0x4, %esi
    1628:      	movl	$0x4, %eax
    162d:      	leaq	0xac(%rcx), %rbx
    1634:      	movl	$0x4, %esi
    1639:      	callq	*%rax
    163b:      	addq	$0x10, %r12
    163f:      	movl	$0x4, %ecx
    1644:      	movl	$0x4, %eax
    1649:      	movq	%rbx, %rdi
    164c:      	movl	$0x4, %esi
    1651:      	movq	%r12, %rdx
    1654:      	callq	*%rax
    1656:      	leaq	0xb6(%r14), %rdx
    165d:      	leaq	0xc8(%rsp), %rdi
    1665:      	movl	$0x2, %ecx
    166a:      	movl	$0x4, %eax
    166f:      	movl	$0x2, %esi
    1674:      	jmp	0x29f0 <generic_fexit_event+0x29f0>
    1679:      	movq	$0x0, 0x28(%rsp)
    1682:      	movq	$0x0, 0x20(%rsp)
    168b:      	movl	$0xe, %eax
    1690:      	callq	*%rax
    1692:      	shrq	$0x20, %rax
    1696:      	movq	%rax, 0x20(%rsp)
    169b:      	leaq	0x68(%rsp), %rdi
    16a0:      	leaq	0x10(%rsp), %rdx
    16a5:      	movl	$0x4, %ecx
    16aa:      	movl	$0x4, %eax
    16af:      	movl	$0x4, %ebx
    16b4:      	movl	$0x4, %esi
    16b9:      	callq	*%rax
    16bb:      	movl	0x68(%rsp), %eax
    16bf:      	movl	%eax, 0x28(%rsp)
    16c3:      	movq	(%rip), %rdi            # 0x16ca <generic_fexit_event+0x16ca>
    16ca:      	leaq	0x20(%rsp), %rsi
    16cf:      	movl	$0x1, %eax
    16d4:      	callq	*%rax
    16d6:      	testq	%rax, %rax
    16d9:      	je	0x1e3e <generic_fexit_event+0x1e3e>
    16df:      	movl	(%rax), %r13d
    16e2:      	leaq	0x68(%rsp), %rdx
    16e7:      	movq	%rax, %r14
    16ea:      	movl	$0x4, %eax
    16ef:      	movq	0x8(%rsp), %r15
    16f4:      	movq	%r15, %rdi
    16f7:      	movl	$0x4, %esi
    16fc:      	callq	*%rax
    16fe:      	andl	$0xfff, %r13d           # imm = 0xFFF
    1705:      	movq	(%rsp), %rdi
    1709:      	addq	$0xa0, %rdi
    1710:      	leaq	0x4(%r13), %rsi
    1714:      	movl	$0x4, %eax
    1719:      	movq	%r14, %rdx
    171c:      	callq	*%rax
    171e:      	leaq	(%r15,%r13), %rdi
    1722:      	addq	$0x8, %rdi
    1726:      	leaq	(%r14,%r13), %rdx
    172a:      	addq	$0x4, %rdx
    172e:      	movl	$0x4, %eax
    1733:      	movl	$0x4, %esi
    1738:      	callq	*%rax
    173a:      	addq	$0xc, %r13
    173e:      	jmp	0x1fd8 <generic_fexit_event+0x1fd8>
    1743:      	movl	$0x120, %edx            # imm = 0x120
    1748:      	addq	0x10(%rsp), %rdx
    174d:      	movq	(%rsp), %rdi
    1751:      	addq	$0xa0, %rdi
    1758:      	movl	$0x11, %ecx
    175d:      	movl	$0x2d, %eax
    1762:      	movl	$0x11, %esi
    1767:      	callq	*%rax
    1769:      	movq	%rax, %r13
    176c:      	testq	%rax, %rax
    176f:      	jns	0xe48 <generic_fexit_event+0xe48>
    1775:      	movq	(%rsp), %rcx
    1779:      	movq	0x18(%rsp), %r15
    177e:      	jmp	0x975 <generic_fexit_event+0x975>
    1783:      	xorl	%r12d, %r12d
    1786:      	cmpq	$0x3, 0x80(%rsp)
    178f:      	jb	0x185d <generic_fexit_event+0x185d>
    1795:      	movq	%rbx, %r13
    1798:      	movq	0x88(%rsp), %rax
    17a0:      	leaq	0x20(%rax), %rdx
    17a4:      	leaq	0x20(%rsp), %rdi
    17a9:      	movl	$0x4, %r15d
    17af:      	movl	$0x10, %ecx
    17b4:      	movl	$0x4, %eax
    17b9:      	movl	$0x10, %esi
    17be:      	callq	*%rax
    17c0:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    17c5:      	testl	%eax, %eax
    17c7:      	js	0x2d07 <generic_fexit_event+0x2d07>
    17cd:      	movq	0x28(%rsp), %rax
    17d2:      	cmpq	%r12, %rax
    17d5:      	movq	%r12, %rcx
    17d8:      	cmovbq	%rax, %rcx
    17dc:      	movq	%r12, 0x8(%rsp)
    17e1:      	testq	%r12, %r12
    17e4:      	movq	%rax, %r12
    17e7:      	movq	%rcx, %rbx
    17ea:      	cmovneq	%rcx, %r12
    17ee:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    17f3:      	cmpq	$0xffe, %r12            # imm = 0xFFE
    17fa:      	ja	0x2d07 <generic_fexit_event+0x2d07>
    1800:      	movq	(%rsp), %rdi
    1804:      	addq	0x78(%rsp), %rdi
    1809:      	movq	%rdi, (%rsp)
    180d:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    1813:      	addq	0x18(%rsp), %rdi
    1818:      	movq	0x20(%rsp), %rcx
    181d:      	movl	$0x4, %eax
    1822:      	movq	0x20(%rsp), %rdx
    1827:      	movl	%r12d, %esi
    182a:      	callq	*%rax
    182c:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    1831:      	testl	%eax, %eax
    1833:      	js	0x2d07 <generic_fexit_event+0x2d07>
    1839:      	movq	%r12, 0x78(%rsp)
    183e:      	addq	%r12, %r13
    1841:      	cmpq	$0x0, 0x8(%rsp)
    1847:      	je	0x2231 <generic_fexit_event+0x2231>
    184d:      	subq	%rbx, 0x8(%rsp)
    1852:      	jne	0x2238 <generic_fexit_event+0x2238>
    1858:      	jmp	0x2243 <generic_fexit_event+0x2243>
    185d:      	movq	%rbx, %r12
    1860:      	jmp	0x435 <generic_fexit_event+0x435>
    1865:      	movq	%r15, 0x18(%rsp)
    186a:      	movq	$0x0, 0x68(%rsp)
    1873:      	movq	$0x0, 0x20(%rsp)
    187c:      	leaq	0x68(%rsp), %rdi
    1881:      	leaq	0x20(%rsp), %rdx
    1886:      	movl	$0x8, %ecx
    188b:      	movq	%rax, %r15
    188e:      	movl	$0x4, %eax
    1893:      	movl	$0x4, %r13d
    1899:      	movl	$0x8, %esi
    189e:      	callq	*%rax
    18a0:      	movq	0x68(%rsp), %r12
    18a5:      	cmpq	$0xfff, %r12            # imm = 0xFFF
    18ac:      	movl	$0xfff, %r14d           # imm = 0xFFF
    18b2:      	cmovbq	%r12, %r14
    18b6:      	movq	%r15, 0x8(%rsp)
    18bb:      	addq	$0xa4, %r15
    18c2:      	movl	$0x4, %eax
    18c7:      	movq	%r15, %rdi
    18ca:      	movl	%r14d, %esi
    18cd:      	movq	%rbx, %rdx
    18d0:      	callq	*%rax
    18d2:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    18d7:      	testl	%eax, %eax
    18d9:      	js	0x18f1 <generic_fexit_event+0x18f1>
    18db:      	movq	0x8(%rsp), %rax
    18e0:      	movl	%r14d, 0xa0(%rax)
    18e7:      	addq	$0x8, %r14
    18eb:      	movl	%r12d, %ecx
    18ee:      	movq	%r14, %r13
    18f1:      	movq	0x8(%rsp), %rax
    18f6:      	movl	%ecx, 0x9c(%rax)
    18fc:      	jmp	0x21df <generic_fexit_event+0x21df>
    1901:      	leaq	0xc4(%rcx), %r13
    1908:      	movq	%r15, 0x18(%rsp)
    190d:      	movq	%r12, %r15
    1910:      	leaq	0xdc(%rcx), %r12
    1917:      	leaq	0x8(%rbx), %rdx
    191b:      	movl	$0x4, %ecx
    1920:      	movl	$0x4, %eax
    1925:      	movq	0x8(%rsp), %rdi
    192a:      	movl	$0x4, %esi
    192f:      	callq	*%rax
    1931:      	movq	(%rsp), %rax
    1935:      	leaq	0xa0(%rax), %rdi
    193c:      	leaq	0xc(%rbx), %rdx
    1940:      	movl	$0x4, %ecx
    1945:      	movl	$0x4, %eax
    194a:      	movl	$0x4, %esi
    194f:      	callq	*%rax
    1951:      	movq	(%rsp), %rax
    1955:      	leaq	0xac(%rax), %rdi
    195c:      	leaq	0x18(%rbx), %rdx
    1960:      	movl	$0x4, %ecx
    1965:      	movl	$0x4, %eax
    196a:      	movl	$0x4, %esi
    196f:      	callq	*%rax
    1971:      	movq	(%rsp), %rax
    1975:      	leaq	0xb0(%rax), %rdi
    197c:      	leaq	0x1c(%rbx), %rdx
    1980:      	movl	$0x4, %ecx
    1985:      	movl	$0x4, %eax
    198a:      	movl	$0x4, %esi
    198f:      	callq	*%rax
    1991:      	movq	(%rsp), %rax
    1995:      	leaq	0xa4(%rax), %rdi
    199c:      	leaq	0x10(%rbx), %rdx
    19a0:      	movl	$0x4, %ecx
    19a5:      	movl	$0x4, %eax
    19aa:      	movl	$0x4, %esi
    19af:      	callq	*%rax
    19b1:      	movq	(%rsp), %rax
    19b5:      	leaq	0xa8(%rax), %rdi
    19bc:      	leaq	0x14(%rbx), %rdx
    19c0:      	movl	$0x4, %ecx
    19c5:      	movl	$0x4, %eax
    19ca:      	movl	$0x4, %esi
    19cf:      	callq	*%rax
    19d1:      	movq	(%rsp), %rax
    19d5:      	leaq	0xb4(%rax), %rdi
    19dc:      	leaq	0x20(%rbx), %rdx
    19e0:      	movl	$0x4, %ecx
    19e5:      	movl	$0x4, %eax
    19ea:      	movl	$0x4, %esi
    19ef:      	callq	*%rax
    19f1:      	movq	(%rsp), %rax
    19f5:      	leaq	0xb8(%rax), %rdi
    19fc:      	leaq	0x24(%rbx), %rdx
    1a00:      	movl	$0x4, %ecx
    1a05:      	movl	$0x4, %eax
    1a0a:      	movl	$0x4, %esi
    1a0f:      	callq	*%rax
    1a11:      	movq	(%rsp), %rax
    1a15:      	movl	$0x0, 0xc0(%rax)
    1a1f:      	movq	(%rsp), %rax
    1a23:      	leaq	0xbc(%rax), %rdi
    1a2a:      	leaq	0x28(%rbx), %rdx
    1a2e:      	movl	$0x4, %ecx
    1a33:      	movl	$0x4, %eax
    1a38:      	movl	$0x4, %esi
    1a3d:      	callq	*%rax
    1a3f:      	movq	(%rsp), %rax
    1a43:      	leaq	0xcc(%rax), %rdi
    1a4a:      	leaq	0x40(%rbx), %rdx
    1a4e:      	movl	$0x8, %ecx
    1a53:      	movl	$0x4, %eax
    1a58:      	movl	$0x8, %esi
    1a5d:      	callq	*%rax
    1a5f:      	movq	(%rsp), %rax
    1a63:      	leaq	0xd4(%rax), %rdi
    1a6a:      	leaq	0x30(%rbx), %rdx
    1a6e:      	movl	$0x8, %ecx
    1a73:      	movl	$0x4, %eax
    1a78:      	movl	$0x8, %esi
    1a7d:      	callq	*%rax
    1a7f:      	leaq	0x38(%rbx), %rdx
    1a83:      	movl	$0x8, %ecx
    1a88:      	movl	$0x4, %eax
    1a8d:      	movq	%r13, %rdi
    1a90:      	movl	$0x8, %esi
    1a95:      	callq	*%rax
    1a97:      	addq	$0x90, %rbx
    1a9e:      	leaq	0x20(%rsp), %rdi
    1aa3:      	movl	$0x8, %ecx
    1aa8:      	movl	$0x4, %eax
    1aad:      	movl	$0x8, %esi
    1ab2:      	movq	%rbx, %rdx
    1ab5:      	callq	*%rax
    1ab7:      	movq	0x20(%rsp), %r14
    1abc:      	leaq	0xc8(%r14), %rdx
    1ac3:      	movl	$0x4, %ecx
    1ac8:      	movl	$0x4, %eax
    1acd:      	movq	%r12, %rdi
    1ad0:      	movq	%r15, %r12
    1ad3:      	movq	0x18(%rsp), %r15
    1ad8:      	movl	$0x4, %esi
    1add:      	callq	*%rax
    1adf:      	movq	(%rsp), %rax
    1ae3:      	leaq	0xe0(%rax), %rdi
    1aea:      	leaq	0xcc(%r14), %rdx
    1af1:      	movl	$0x4, %ecx
    1af6:      	movl	$0x4, %eax
    1afb:      	movl	$0x4, %esi
    1b00:      	callq	*%rax
    1b02:      	movq	(%rsp), %rax
    1b06:      	leaq	0xe4(%rax), %rdi
    1b0d:      	leaq	0xd0(%r14), %rdx
    1b14:      	movl	$0x4, %ecx
    1b19:      	movl	$0x4, %eax
    1b1e:      	movl	$0x4, %esi
    1b23:      	callq	*%rax
    1b25:      	movq	(%rsp), %rdi
    1b29:      	addq	$0xe8, %rdi
    1b30:      	addq	$0x158, %r14            # imm = 0x158
    1b37:      	movl	$0x4, %ecx
    1b3c:      	movl	$0x4, %eax
    1b41:      	movl	$0x4, %esi
    1b46:      	movq	%r14, %rdx
    1b49:      	callq	*%rax
    1b4b:      	movq	(%rsp), %rcx
    1b4f:      	movl	$0x50, %r13d
    1b55:      	jmp	0x970 <generic_fexit_event+0x970>
    1b5a:      	leaq	0xc8(%rbx), %rdx
    1b61:      	movl	$0x4, %ecx
    1b66:      	movl	$0x4, %eax
    1b6b:      	movq	0x8(%rsp), %rdi
    1b70:      	movl	$0x4, %esi
    1b75:      	callq	*%rax
    1b77:      	movq	(%rsp), %rax
    1b7b:      	leaq	0xa0(%rax), %rdi
    1b82:      	leaq	0xcc(%rbx), %rdx
    1b89:      	movl	$0x4, %ecx
    1b8e:      	movl	$0x4, %eax
    1b93:      	movl	$0x4, %esi
    1b98:      	callq	*%rax
    1b9a:      	movq	(%rsp), %rax
    1b9e:      	leaq	0xa4(%rax), %rdi
    1ba5:      	leaq	0xd0(%rbx), %rdx
    1bac:      	movl	$0x4, %ecx
    1bb1:      	movl	$0x4, %eax
    1bb6:      	movl	$0x4, %esi
    1bbb:      	callq	*%rax
    1bbd:      	movq	(%rsp), %rdi
    1bc1:      	addq	$0xa8, %rdi
    1bc8:      	addq	$0x158, %rbx            # imm = 0x158
    1bcf:      	movl	$0x4, %ecx
    1bd4:      	movl	$0x4, %eax
    1bd9:      	movl	$0x4, %esi
    1bde:      	movq	%rbx, %rdx
    1be1:      	callq	*%rax
    1be3:      	movq	(%rsp), %rcx
    1be7:      	movl	$0x10, %r13d
    1bed:      	jmp	0x970 <generic_fexit_event+0x970>
    1bf2:      	leaq	0x38(%rbx), %rdx
    1bf6:      	movl	$0x4, %ecx
    1bfb:      	movl	$0x4, %eax
    1c00:      	movq	0x8(%rsp), %rdi
    1c05:      	movl	$0x4, %esi
    1c0a:      	callq	*%rax
    1c0c:      	movq	(%rsp), %rax
    1c10:      	leaq	0xa0(%rax), %rdi
    1c17:      	leaq	0x3c(%rbx), %rdx
    1c1b:      	movl	$0x4, %ecx
    1c20:      	movl	$0x4, %eax
    1c25:      	movl	$0x4, %esi
    1c2a:      	callq	*%rax
    1c2c:      	movq	(%rsp), %rax
    1c30:      	leaq	0xa4(%rax), %rdi
    1c37:      	leaq	0x40(%rbx), %rdx
    1c3b:      	movl	$0x4, %ecx
    1c40:      	movl	$0x4, %eax
    1c45:      	movl	$0x4, %esi
    1c4a:      	callq	*%rax
    1c4c:      	movq	(%rsp), %rax
    1c50:      	leaq	0xa8(%rax), %rdi
    1c57:      	leaq	0x44(%rbx), %rdx
    1c5b:      	movl	$0x4, %ecx
    1c60:      	movl	$0x4, %eax
    1c65:      	movl	$0x4, %esi
    1c6a:      	callq	*%rax
    1c6c:      	movq	(%rsp), %rdi
    1c70:      	addq	$0xac, %rdi
    1c77:      	subq	$-0x80, %rbx
    1c7b:      	movl	$0x10, %ecx
    1c80:      	movl	$0x4, %eax
    1c85:      	movl	$0x10, %esi
    1c8a:      	movq	%rbx, %rdx
    1c8d:      	callq	*%rax
    1c8f:      	movq	(%rsp), %rcx
    1c93:      	movl	$0x20, %r13d
    1c99:      	jmp	0x970 <generic_fexit_event+0x970>
    1c9e:      	movl	$0x4, %ecx
    1ca3:      	movl	$0x4, %eax
    1ca8:      	movq	0x8(%rsp), %rdi
    1cad:      	movl	$0x4, %esi
    1cb2:      	movq	%rbx, %rdx
    1cb5:      	callq	*%rax
    1cb7:      	movq	(%rsp), %rax
    1cbb:      	leaq	0xa0(%rax), %rdi
    1cc2:      	leaq	0x4(%rbx), %rdx
    1cc6:      	movl	$0x4, %ecx
    1ccb:      	movl	$0x4, %eax
    1cd0:      	movl	$0x4, %esi
    1cd5:      	callq	*%rax
    1cd7:      	movq	(%rsp), %rdi
    1cdb:      	addq	$0xa4, %rdi
    1ce2:      	addq	$0x30, %rbx
    1ce6:      	movl	$0x10, %ecx
    1ceb:      	movl	$0x4, %eax
    1cf0:      	movl	$0x10, %esi
    1cf5:      	movq	%rbx, %rdx
    1cf8:      	jmp	0x1d96 <generic_fexit_event+0x1d96>
    1cfd:      	leaq	0x4(%rbx), %rdx
    1d01:      	leaq	0x20(%rsp), %rdi
    1d06:      	movl	$0x4, %ecx
    1d0b:      	movl	$0x4, %eax
    1d10:      	movl	$0x4, %esi
    1d15:      	callq	*%rax
    1d17:      	movl	0x20(%rsp), %ecx
    1d1b:      	movq	(%rsp), %rax
    1d1f:      	movl	%ecx, 0x9c(%rax)
    1d25:      	leaq	0xc(%rbx), %rdx
    1d29:      	leaq	0x20(%rsp), %rdi
    1d2e:      	movl	$0x4, %ecx
    1d33:      	movl	$0x4, %eax
    1d38:      	movl	$0x4, %esi
    1d3d:      	callq	*%rax
    1d3f:      	movl	0x20(%rsp), %ecx
    1d43:      	movq	(%rsp), %rax
    1d47:      	movl	%ecx, 0xa0(%rax)
    1d4d:      	addq	$0x50, %rbx
    1d51:      	leaq	0x20(%rsp), %rdi
    1d56:      	movl	$0x8, %ecx
    1d5b:      	movl	$0x2d, %eax
    1d60:      	movl	$0x8, %esi
    1d65:      	movq	%rbx, %rdx
    1d68:      	callq	*%rax
    1d6a:      	movq	(%rsp), %rdi
    1d6e:      	addq	$0xa4, %rdi
    1d75:      	movl	$0x3f8, %edx            # imm = 0x3F8
    1d7a:      	movq	0x20(%rsp), %rcx
    1d7f:      	addq	%rdx, %rcx
    1d82:      	movl	$0x10, %esi
    1d87:      	movl	$0x2d, %eax
    1d8c:      	addq	0x20(%rsp), %rdx
    1d91:      	movl	$0x10, %esi
    1d96:      	callq	*%rax
    1d98:      	movq	(%rsp), %rcx
    1d9c:      	movl	$0x18, %r13d
    1da2:      	jmp	0x970 <generic_fexit_event+0x970>
    1da7:      	movq	0x8(%rsp), %rax
    1dac:      	movq	$0x0, 0x48(%rax)
    1db4:      	movq	$0x0, 0x40(%rax)
    1dbc:      	movq	$0x0, 0x38(%rax)
    1dc4:      	movq	$0x0, 0x30(%rax)
    1dcc:      	movq	$0x0, 0x28(%rax)
    1dd4:      	movq	$0x0, 0x20(%rax)
    1ddc:      	movq	$0x0, 0x18(%rax)
    1de4:      	movq	$0x0, 0x10(%rax)
    1dec:      	movq	$0x0, 0x8(%rax)
    1df4:      	movq	%rax, %r14
    1df7:      	movq	$0x0, (%rax)
    1dfe:      	leaq	0x20(%rsp), %rdi
    1e03:      	movl	$0x8, %ecx
    1e08:      	movl	$0x4, %eax
    1e0d:      	movl	$0x8, %esi
    1e12:      	movq	%rbx, %rdx
    1e15:      	callq	*%rax
    1e17:      	testq	%rax, %rax
    1e1a:      	je	0x2060 <generic_fexit_event+0x2060>
    1e20:      	xorl	%r13d, %r13d
    1e23:      	jmp	0x12f4 <generic_fexit_event+0x12f4>
    1e28:      	movq	$0x0, 0x9c(%rbx)
    1e33:      	movl	$0x8, %r13d
    1e39:      	jmp	0x1fd8 <generic_fexit_event+0x1fd8>
    1e3e:      	movq	$-0x1, %r13
    1e45:      	jmp	0x1fd8 <generic_fexit_event+0x1fd8>
    1e4a:      	movq	0x20(%rsp), %rbx
    1e4f:      	movl	$0x0, 0x68(%rsp)
    1e57:      	movzwl	0xa8(%rsp), %r15d
    1e60:      	movq	(%rip), %rdi            # 0x1e67 <generic_fexit_event+0x1e67>
    1e67:      	leaq	0x68(%rsp), %rsi
    1e6c:      	movl	$0x1, %eax
    1e71:      	leaq	(%rbx,%r15), %r13
    1e75:      	callq	*%rax
    1e77:      	testq	%rax, %rax
    1e7a:      	je	0x2999 <generic_fexit_event+0x2999>
    1e80:      	movq	%rax, %r12
    1e83:      	movw	%r15w, (%r12)
    1e88:      	movb	$-0x1, 0x5(%r12)
    1e8e:      	movb	$0x0, 0x7(%r12)
    1e94:      	movq	%r12, %rdi
    1e97:      	addq	$0x6, %rdi
    1e9b:      	leaq	0x6(%r13), %rdx
    1e9f:      	movl	$0x1, %ecx
    1ea4:      	movl	$0x4, %eax
    1ea9:      	movq	%rdi, %r15
    1eac:      	movl	$0x1, %esi
    1eb1:      	callq	*%rax
    1eb3:      	testq	%rax, %rax
    1eb6:      	js	0x2999 <generic_fexit_event+0x2999>
    1ebc:      	movzbl	0x5(%r12), %eax
    1ec2:      	cmpl	$0x32, %eax
    1ec5:      	jg	0x21f2 <generic_fexit_event+0x21f2>
    1ecb:      	testl	%eax, %eax
    1ecd:      	je	0x221c <generic_fexit_event+0x221c>
    1ed3:      	cmpl	$0x2b, %eax
    1ed6:      	je	0x221c <generic_fexit_event+0x221c>
    1edc:      	cmpl	$0x2c, %eax
    1edf:      	jne	0x23de <generic_fexit_event+0x23de>
    1ee5:      	movw	$0x8, 0x2(%r12)
    1eed:      	movw	$0x8, %ax
    1ef1:      	jmp	0x231f <generic_fexit_event+0x231f>
    1ef6:      	leaq	0x48(%r12), %rdx
    1efb:      	movl	$0x10, %ecx
    1f00:      	movl	$0x4, %eax
    1f05:      	movq	0x8(%rsp), %rdi
    1f0a:      	movl	$0x10, %esi
    1f0f:      	callq	*%rax
    1f11:      	leaq	0x38(%r12), %rdx
    1f16:      	movl	$0x10, %ecx
    1f1b:      	movl	$0x4, %eax
    1f20:      	movq	%r14, %rdi
    1f23:      	movl	$0x10, %esi
    1f28:      	callq	*%rax
    1f2a:      	movq	(%rsp), %r14
    1f2e:      	leaq	0xbc(%r14), %rdi
    1f35:      	leaq	0xc(%r12), %rbx
    1f3a:      	addq	$0xe, %r12
    1f3e:      	movl	$0x2, %ecx
    1f43:      	movl	$0x4, %eax
    1f48:      	movl	$0x2, %esi
    1f4d:      	movq	%r12, %rdx
    1f50:      	callq	*%rax
    1f52:      	movq	%r14, %rdi
    1f55:      	addq	$0xbe, %rdi
    1f5c:      	movl	$0x2, %ecx
    1f61:      	movl	$0x4, %eax
    1f66:      	movl	$0x2, %esi
    1f6b:      	movq	%rbx, %rdx
    1f6e:      	callq	*%rax
    1f70:      	movzwl	0xbe(%r14), %eax
    1f78:      	movbew	%ax, 0xbe(%r14)
    1f82:      	movq	0x10(%rsp), %rax
    1f87:      	movq	%rax, 0x20(%rsp)
    1f8c:      	movq	(%rip), %rdi            # 0x1f93 <generic_fexit_event+0x1f93>
    1f93:      	leaq	0x20(%rsp), %rsi
    1f98:      	movl	$0x1, %eax
    1f9d:      	callq	*%rax
    1f9f:      	testq	%rax, %rax
    1fa2:      	je	0x2b77 <generic_fexit_event+0x2b77>
    1fa8:      	movl	(%rax), %ecx
    1faa:      	movl	%ecx, 0x10(%r15)
    1fae:      	movq	0x8(%rax), %rcx
    1fb2:      	movq	%rcx, 0x18(%r15)
    1fb6:      	movl	0x4(%rax), %eax
    1fb9:      	movl	%eax, 0x7c(%r15)
    1fbd:      	movl	$0x40, %r13d
    1fc3:      	jmp	0xd44 <generic_fexit_event+0xd44>
    1fc8:      	movl	$0xfffffffe, 0x9c(%rbx) # imm = 0xFFFFFFFE
    1fd2:      	movl	$0x4, %r13d
    1fd8:      	movq	(%rsp), %rcx
    1fdc:      	movl	$0x4, %ebx
    1fe1:      	movq	0x18(%rsp), %r15
    1fe6:      	jmp	0x975 <generic_fexit_event+0x975>
    1feb:      	movq	(%rsp), %rbx
    1fef:      	leaq	0xa4(%rbx), %rdi
    1ff6:      	leaq	0x8(%r12), %rdx
    1ffb:      	movl	$0x10, %ecx
    2000:      	movl	$0x4, %eax
    2005:      	movl	$0x10, %esi
    200a:      	callq	*%rax
    200c:      	movq	%rbx, %rdi
    200f:      	addq	$0x9e, %rdi
    2016:      	addq	$0x2, %r12
    201a:      	movl	$0x2, %ecx
    201f:      	movl	$0x4, %eax
    2024:      	movl	$0x2, %esi
    2029:      	movq	%r12, %rdx
    202c:      	callq	*%rax
    202e:      	movq	(%rsp), %rax
    2032:      	movzwl	0x9e(%rax), %ecx
    2039:      	movbew	%cx, 0x9e(%rax)
    2042:      	movl	$0x4, %ebx
    2047:      	movl	$0x18, %r13d
    204d:      	movq	(%rsp), %rcx
    2051:      	movq	0x60(%rsp), %r12
    2056:      	movq	0x18(%rsp), %r15
    205b:      	jmp	0x975 <generic_fexit_event+0x975>
    2060:      	movq	(%rsp), %rax
    2064:      	leaq	0xac(%rax), %rdi
    206b:      	movq	0x20(%rsp), %rcx
    2070:      	movl	$0x3f, %edx
    2075:      	movl	$0x2d, %eax
    207a:      	movq	0x20(%rsp), %rdx
    207f:      	movl	$0x3f, %esi
    2084:      	callq	*%rax
    2086:      	testq	%rax, %rax
    2089:      	js	0x1e20 <generic_fexit_event+0x1e20>
    208f:      	leaq	0x8(%rbx), %rdx
    2093:      	leaq	0x68(%rsp), %rdi
    2098:      	movl	$0x8, %ecx
    209d:      	movl	$0x4, %eax
    20a2:      	movl	$0x8, %esi
    20a7:      	callq	*%rax
    20a9:      	movq	(%rsp), %rdi
    20ad:      	addq	$0xa4, %rdi
    20b4:      	movl	$0x348, %edx            # imm = 0x348
    20b9:      	movq	0x68(%rsp), %rcx
    20be:      	addq	%rdx, %rcx
    20c1:      	movl	$0x8, %esi
    20c6:      	movl	$0x4, %eax
    20cb:      	addq	0x68(%rsp), %rdx
    20d0:      	movl	$0x8, %esi
    20d5:      	callq	*%rax
    20d7:      	addq	$0x58, %rbx
    20db:      	leaq	0x68(%rsp), %rdi
    20e0:      	movl	$0x4, %ecx
    20e5:      	movl	$0x4, %eax
    20ea:      	movl	$0x4, %esi
    20ef:      	movq	%rbx, %rdx
    20f2:      	callq	*%rax
    20f4:      	movl	$0x50, %r13d
    20fa:      	testq	%rax, %rax
    20fd:      	jne	0x12f4 <generic_fexit_event+0x12f4>
    2103:      	xorl	%eax, %eax
    2105:      	cmpl	$0x0, 0x68(%rsp)
    210a:      	setne	%al
    210d:      	movl	%eax, (%r14)
    2110:      	jmp	0x12f4 <generic_fexit_event+0x12f4>
    2115:      	leaq	0x48(%r12), %rdx
    211a:      	movl	$0x10, %ecx
    211f:      	movl	$0x4, %eax
    2124:      	movl	$0x10, %esi
    2129:      	callq	*%rax
    212b:      	leaq	0x38(%r12), %rdx
    2130:      	movl	$0x10, %ecx
    2135:      	movl	$0x4, %eax
    213a:      	movq	%r14, %rdi
    213d:      	movl	$0x10, %esi
    2142:      	callq	*%rax
    2144:      	movq	(%rsp), %r14
    2148:      	leaq	0xbc(%r14), %rdi
    214f:      	leaq	0xc(%r12), %rbx
    2154:      	addq	$0xe, %r12
    2158:      	movl	$0x2, %ecx
    215d:      	movl	$0x4, %eax
    2162:      	movl	$0x2, %esi
    2167:      	movq	%r12, %rdx
    216a:      	callq	*%rax
    216c:      	movq	%r14, %rdi
    216f:      	addq	$0xbe, %rdi
    2176:      	movl	$0x2, %ecx
    217b:      	movl	$0x4, %eax
    2180:      	movl	$0x2, %esi
    2185:      	movq	%rbx, %rdx
    2188:      	callq	*%rax
    218a:      	movzwl	0xbe(%r14), %eax
    2192:      	movbew	%ax, 0xbe(%r14)
    219c:      	movq	(%rsp), %rax
    21a0:      	movq	0xc4(%rax), %rax
    21a7:      	movq	%rax, 0x20(%rsp)
    21ac:      	movq	(%rip), %rdi            # 0x21b3 <generic_fexit_event+0x21b3>
    21b3:      	leaq	0x20(%rsp), %rsi
    21b8:      	movl	$0x1, %eax
    21bd:      	callq	*%rax
    21bf:      	testq	%rax, %rax
    21c2:      	je	0x21d9 <generic_fexit_event+0x21d9>
    21c4:      	movl	(%rax), %ecx
    21c6:      	movl	%ecx, 0x10(%r15)
    21ca:      	movq	0x8(%rax), %rcx
    21ce:      	movq	%rcx, 0x18(%r15)
    21d2:      	movl	0x4(%rax), %eax
    21d5:      	movl	%eax, 0x7c(%r15)
    21d9:      	movl	$0x40, %r13d
    21df:      	movq	(%rsp), %rcx
    21e3:      	movq	0x60(%rsp), %r12
    21e8:      	movq	0x18(%rsp), %r15
    21ed:      	jmp	0x970 <generic_fexit_event+0x970>
    21f2:      	cmpl	$0x33, %eax
    21f5:      	je	0x2309 <generic_fexit_event+0x2309>
    21fb:      	cmpl	$0x3c, %eax
    21fe:      	je	0x221c <generic_fexit_event+0x221c>
    2200:      	cmpl	$0xff, %eax
    2205:      	jne	0x23de <generic_fexit_event+0x23de>
    220b:      	movw	$0x28, 0x2(%r12)
    2213:      	movw	$0x28, %ax
    2217:      	jmp	0x231f <generic_fexit_event+0x231f>
    221c:      	movq	%r12, %rcx
    221f:      	movzbl	0x7(%r12), %eax
    2225:      	leal	0x8(,%rax,8), %eax
    222c:      	jmp	0x2319 <generic_fexit_event+0x2319>
    2231:      	xorl	%eax, %eax
    2233:      	movq	%rax, 0x8(%rsp)
    2238:      	cmpq	$0x3, 0x80(%rsp)
    2241:      	jne	0x224b <generic_fexit_event+0x224b>
    2243:      	movq	%r13, %r12
    2246:      	jmp	0x435 <generic_fexit_event+0x435>
    224b:      	movq	0x88(%rsp), %rax
    2253:      	leaq	0x30(%rax), %rdx
    2257:      	leaq	0x20(%rsp), %rdi
    225c:      	movl	$0x4, %r15d
    2262:      	movl	$0x10, %ecx
    2267:      	movl	$0x4, %eax
    226c:      	movl	$0x10, %esi
    2271:      	callq	*%rax
    2273:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2278:      	testl	%eax, %eax
    227a:      	js	0x2d07 <generic_fexit_event+0x2d07>
    2280:      	movq	0x28(%rsp), %rdx
    2285:      	movq	0x8(%rsp), %rax
    228a:      	cmpq	%rax, %rdx
    228d:      	movq	%rax, %rbx
    2290:      	cmovbq	%rdx, %rbx
    2294:      	testq	%rax, %rax
    2297:      	cmovneq	%rbx, %rdx
    229b:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    22a0:      	cmpq	$0xffe, %rdx            # imm = 0xFFE
    22a7:      	ja	0x2d07 <generic_fexit_event+0x2d07>
    22ad:      	movq	%rdx, %r12
    22b0:      	movq	0x78(%rsp), %rdi
    22b5:      	addq	(%rsp), %rdi
    22b9:      	movq	%rdi, 0x78(%rsp)
    22be:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    22c4:      	addq	0x18(%rsp), %rdi
    22c9:      	movq	0x20(%rsp), %rcx
    22ce:      	movl	$0x4, %eax
    22d3:      	movq	%rdx, %rsi
    22d6:      	movq	0x20(%rsp), %rdx
    22db:      	callq	*%rax
    22dd:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    22e2:      	testl	%eax, %eax
    22e4:      	js	0x2d07 <generic_fexit_event+0x2d07>
    22ea:      	addq	%r12, %r13
    22ed:      	cmpq	$0x0, 0x8(%rsp)
    22f3:      	je	0x2695 <generic_fexit_event+0x2695>
    22f9:      	subq	%rbx, 0x8(%rsp)
    22fe:      	jne	0x269c <generic_fexit_event+0x269c>
    2304:      	jmp	0x2243 <generic_fexit_event+0x2243>
    2309:      	movq	%r12, %rcx
    230c:      	movzbl	0x7(%r12), %eax
    2312:      	leal	0x8(,%rax,4), %eax
    2319:      	movw	%ax, 0x2(%r12)
    231f:      	movq	%r12, %rcx
    2322:      	addw	(%r12), %ax
    2327:      	movw	%ax, (%r12)
    232c:      	movzbl	0x6(%r12), %ecx
    2332:      	cmpq	$0x3c, %rcx
    2336:      	ja	0x2b82 <generic_fexit_event+0x2b82>
    233c:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2346:      	btq	%rcx, %rdx
    234a:      	jae	0x2b82 <generic_fexit_event+0x2b82>
    2350:      	movb	%cl, 0x5(%r12)
    2355:      	movzwl	%ax, %ecx
    2358:      	addq	%rbx, %rcx
    235b:      	movl	$0x2, %edx
    2360:      	movl	$0x4, %eax
    2365:      	movq	%r15, %rdi
    2368:      	movzwl	(%r12), %edx
    236d:      	addq	%rbx, %rdx
    2370:      	movl	$0x2, %esi
    2375:      	callq	*%rax
    2377:      	testq	%rax, %rax
    237a:      	js	0x2999 <generic_fexit_event+0x2999>
    2380:      	movzbl	0x5(%r12), %eax
    2386:      	cmpl	$0x32, %eax
    2389:      	jg	0x23a7 <generic_fexit_event+0x23a7>
    238b:      	testl	%eax, %eax
    238d:      	je	0x23c6 <generic_fexit_event+0x23c6>
    238f:      	cmpl	$0x2b, %eax
    2392:      	je	0x23c6 <generic_fexit_event+0x23c6>
    2394:      	cmpl	$0x2c, %eax
    2397:      	jne	0x2401 <generic_fexit_event+0x2401>
    2399:      	movw	$0x8, 0x2(%r12)
    23a1:      	movw	$0x8, %ax
    23a5:      	jmp	0x2407 <generic_fexit_event+0x2407>
    23a7:      	cmpl	$0x33, %eax
    23aa:      	je	0x23e9 <generic_fexit_event+0x23e9>
    23ac:      	cmpl	$0x3c, %eax
    23af:      	je	0x23c6 <generic_fexit_event+0x23c6>
    23b1:      	cmpl	$0xff, %eax
    23b6:      	jne	0x2401 <generic_fexit_event+0x2401>
    23b8:      	movw	$0x28, 0x2(%r12)
    23c0:      	movw	$0x28, %ax
    23c4:      	jmp	0x2407 <generic_fexit_event+0x2407>
    23c6:      	movq	%r12, %rcx
    23c9:      	movzbl	0x7(%r12), %eax
    23cf:      	leal	0x8(,%rax,8), %eax
    23d6:      	movw	%ax, 0x2(%r12)
    23dc:      	jmp	0x2407 <generic_fexit_event+0x2407>
    23de:      	movzwl	0x2(%r12), %eax
    23e4:      	jmp	0x231f <generic_fexit_event+0x231f>
    23e9:      	movq	%r12, %rcx
    23ec:      	movzbl	0x7(%r12), %eax
    23f2:      	leal	0x8(,%rax,4), %eax
    23f9:      	movw	%ax, 0x2(%r12)
    23ff:      	jmp	0x2407 <generic_fexit_event+0x2407>
    2401:      	movzwl	0x2(%r12), %eax
    2407:      	movq	%r12, %rcx
    240a:      	addw	(%r12), %ax
    240f:      	movw	%ax, (%r12)
    2414:      	movzbl	0x6(%r12), %ecx
    241a:      	cmpq	$0x3c, %rcx
    241e:      	ja	0x2b82 <generic_fexit_event+0x2b82>
    2424:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    242e:      	btq	%rcx, %rdx
    2432:      	jae	0x2b82 <generic_fexit_event+0x2b82>
    2438:      	movb	%cl, 0x5(%r12)
    243d:      	movzwl	%ax, %ecx
    2440:      	addq	%rbx, %rcx
    2443:      	movl	$0x2, %edx
    2448:      	movl	$0x4, %eax
    244d:      	movq	%r15, %rdi
    2450:      	movzwl	(%r12), %edx
    2455:      	addq	%rbx, %rdx
    2458:      	movl	$0x2, %esi
    245d:      	callq	*%rax
    245f:      	testq	%rax, %rax
    2462:      	js	0x2999 <generic_fexit_event+0x2999>
    2468:      	movzbl	0x5(%r12), %eax
    246e:      	cmpl	$0x32, %eax
    2471:      	jg	0x248f <generic_fexit_event+0x248f>
    2473:      	testl	%eax, %eax
    2475:      	je	0x24ae <generic_fexit_event+0x24ae>
    2477:      	cmpl	$0x2b, %eax
    247a:      	je	0x24ae <generic_fexit_event+0x24ae>
    247c:      	cmpl	$0x2c, %eax
    247f:      	jne	0x24de <generic_fexit_event+0x24de>
    2481:      	movw	$0x8, 0x2(%r12)
    2489:      	movw	$0x8, %ax
    248d:      	jmp	0x24e4 <generic_fexit_event+0x24e4>
    248f:      	cmpl	$0x33, %eax
    2492:      	je	0x24c6 <generic_fexit_event+0x24c6>
    2494:      	cmpl	$0x3c, %eax
    2497:      	je	0x24ae <generic_fexit_event+0x24ae>
    2499:      	cmpl	$0xff, %eax
    249e:      	jne	0x24de <generic_fexit_event+0x24de>
    24a0:      	movw	$0x28, 0x2(%r12)
    24a8:      	movw	$0x28, %ax
    24ac:      	jmp	0x24e4 <generic_fexit_event+0x24e4>
    24ae:      	movq	%r12, %rcx
    24b1:      	movzbl	0x7(%r12), %eax
    24b7:      	leal	0x8(,%rax,8), %eax
    24be:      	movw	%ax, 0x2(%r12)
    24c4:      	jmp	0x24e4 <generic_fexit_event+0x24e4>
    24c6:      	movq	%r12, %rcx
    24c9:      	movzbl	0x7(%r12), %eax
    24cf:      	leal	0x8(,%rax,4), %eax
    24d6:      	movw	%ax, 0x2(%r12)
    24dc:      	jmp	0x24e4 <generic_fexit_event+0x24e4>
    24de:      	movzwl	0x2(%r12), %eax
    24e4:      	movq	%r12, %rcx
    24e7:      	addw	(%r12), %ax
    24ec:      	movw	%ax, (%r12)
    24f1:      	movzbl	0x6(%r12), %ecx
    24f7:      	cmpq	$0x3c, %rcx
    24fb:      	ja	0x2b82 <generic_fexit_event+0x2b82>
    2501:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    250b:      	btq	%rcx, %rdx
    250f:      	jae	0x2b82 <generic_fexit_event+0x2b82>
    2515:      	movb	%cl, 0x5(%r12)
    251a:      	movzwl	%ax, %ecx
    251d:      	addq	%rbx, %rcx
    2520:      	movl	$0x2, %edx
    2525:      	movl	$0x4, %eax
    252a:      	movq	%r15, %rdi
    252d:      	movzwl	(%r12), %edx
    2532:      	addq	%rbx, %rdx
    2535:      	movl	$0x2, %esi
    253a:      	callq	*%rax
    253c:      	testq	%rax, %rax
    253f:      	js	0x2999 <generic_fexit_event+0x2999>
    2545:      	movzbl	0x5(%r12), %eax
    254b:      	cmpl	$0x32, %eax
    254e:      	jg	0x256c <generic_fexit_event+0x256c>
    2550:      	testl	%eax, %eax
    2552:      	je	0x258b <generic_fexit_event+0x258b>
    2554:      	cmpl	$0x2b, %eax
    2557:      	je	0x258b <generic_fexit_event+0x258b>
    2559:      	cmpl	$0x2c, %eax
    255c:      	jne	0x25bb <generic_fexit_event+0x25bb>
    255e:      	movw	$0x8, 0x2(%r12)
    2566:      	movw	$0x8, %ax
    256a:      	jmp	0x25c1 <generic_fexit_event+0x25c1>
    256c:      	cmpl	$0x33, %eax
    256f:      	je	0x25a3 <generic_fexit_event+0x25a3>
    2571:      	cmpl	$0x3c, %eax
    2574:      	je	0x258b <generic_fexit_event+0x258b>
    2576:      	cmpl	$0xff, %eax
    257b:      	jne	0x25bb <generic_fexit_event+0x25bb>
    257d:      	movw	$0x28, 0x2(%r12)
    2585:      	movw	$0x28, %ax
    2589:      	jmp	0x25c1 <generic_fexit_event+0x25c1>
    258b:      	movq	%r12, %rcx
    258e:      	movzbl	0x7(%r12), %eax
    2594:      	leal	0x8(,%rax,8), %eax
    259b:      	movw	%ax, 0x2(%r12)
    25a1:      	jmp	0x25c1 <generic_fexit_event+0x25c1>
    25a3:      	movq	%r12, %rcx
    25a6:      	movzbl	0x7(%r12), %eax
    25ac:      	leal	0x8(,%rax,4), %eax
    25b3:      	movw	%ax, 0x2(%r12)
    25b9:      	jmp	0x25c1 <generic_fexit_event+0x25c1>
    25bb:      	movzwl	0x2(%r12), %eax
    25c1:      	movq	%r12, %rcx
    25c4:      	addw	(%r12), %ax
    25c9:      	movw	%ax, (%r12)
    25ce:      	movzbl	0x6(%r12), %ecx
    25d4:      	cmpq	$0x3c, %rcx
    25d8:      	ja	0x2b82 <generic_fexit_event+0x2b82>
    25de:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    25e8:      	btq	%rcx, %rdx
    25ec:      	jae	0x2b82 <generic_fexit_event+0x2b82>
    25f2:      	movb	%cl, 0x5(%r12)
    25f7:      	movzwl	%ax, %ecx
    25fa:      	addq	%rbx, %rcx
    25fd:      	movl	$0x2, %edx
    2602:      	movl	$0x4, %eax
    2607:      	movq	%r15, %rdi
    260a:      	movzwl	(%r12), %edx
    260f:      	addq	%rbx, %rdx
    2612:      	movl	$0x2, %esi
    2617:      	callq	*%rax
    2619:      	testq	%rax, %rax
    261c:      	js	0x2999 <generic_fexit_event+0x2999>
    2622:      	movzbl	0x5(%r12), %eax
    2628:      	cmpl	$0x32, %eax
    262b:      	jg	0x2650 <generic_fexit_event+0x2650>
    262d:      	testl	%eax, %eax
    262f:      	je	0x267a <generic_fexit_event+0x267a>
    2631:      	cmpl	$0x2b, %eax
    2634:      	je	0x267a <generic_fexit_event+0x267a>
    2636:      	cmpl	$0x2c, %eax
    2639:      	jne	0x2781 <generic_fexit_event+0x2781>
    263f:      	movw	$0x8, 0x2(%r12)
    2647:      	movw	$0x8, %ax
    264b:      	jmp	0x2787 <generic_fexit_event+0x2787>
    2650:      	cmpl	$0x33, %eax
    2653:      	je	0x2769 <generic_fexit_event+0x2769>
    2659:      	cmpl	$0x3c, %eax
    265c:      	je	0x267a <generic_fexit_event+0x267a>
    265e:      	cmpl	$0xff, %eax
    2663:      	jne	0x2781 <generic_fexit_event+0x2781>
    2669:      	movw	$0x28, 0x2(%r12)
    2671:      	movw	$0x28, %ax
    2675:      	jmp	0x2787 <generic_fexit_event+0x2787>
    267a:      	movq	%r12, %rcx
    267d:      	movzbl	0x7(%r12), %eax
    2683:      	leal	0x8(,%rax,8), %eax
    268a:      	movw	%ax, 0x2(%r12)
    2690:      	jmp	0x2787 <generic_fexit_event+0x2787>
    2695:      	xorl	%eax, %eax
    2697:      	movq	%rax, 0x8(%rsp)
    269c:      	cmpq	$0x5, 0x80(%rsp)
    26a5:      	jb	0x2243 <generic_fexit_event+0x2243>
    26ab:      	movq	0x88(%rsp), %rax
    26b3:      	leaq	0x40(%rax), %rdx
    26b7:      	leaq	0x20(%rsp), %rdi
    26bc:      	movl	$0x4, %r15d
    26c2:      	movl	$0x10, %ecx
    26c7:      	movl	$0x4, %eax
    26cc:      	movl	$0x10, %esi
    26d1:      	callq	*%rax
    26d3:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    26d8:      	testl	%eax, %eax
    26da:      	js	0x2d07 <generic_fexit_event+0x2d07>
    26e0:      	movq	0x28(%rsp), %rdx
    26e5:      	movq	0x8(%rsp), %rax
    26ea:      	cmpq	%rax, %rdx
    26ed:      	movq	%rax, %rbx
    26f0:      	cmovbq	%rdx, %rbx
    26f4:      	testq	%rax, %rax
    26f7:      	cmovneq	%rbx, %rdx
    26fb:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2700:      	movq	%rdx, (%rsp)
    2704:      	cmpq	$0xffe, %rdx            # imm = 0xFFE
    270b:      	ja	0x2d07 <generic_fexit_event+0x2d07>
    2711:      	movq	%r12, %rdi
    2714:      	addq	0x78(%rsp), %rdi
    2719:      	movq	%rdi, %r12
    271c:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2722:      	addq	0x18(%rsp), %rdi
    2727:      	movq	0x20(%rsp), %rcx
    272c:      	movl	$0x4, %eax
    2731:      	movq	(%rsp), %rsi
    2735:      	movq	0x20(%rsp), %rdx
    273a:      	callq	*%rax
    273c:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2741:      	testl	%eax, %eax
    2743:      	js	0x2d07 <generic_fexit_event+0x2d07>
    2749:      	addq	(%rsp), %r13
    274d:      	cmpq	$0x0, 0x8(%rsp)
    2753:      	je	0x2b8f <generic_fexit_event+0x2b8f>
    2759:      	subq	%rbx, 0x8(%rsp)
    275e:      	jne	0x2b96 <generic_fexit_event+0x2b96>
    2764:      	jmp	0x2243 <generic_fexit_event+0x2243>
    2769:      	movq	%r12, %rcx
    276c:      	movzbl	0x7(%r12), %eax
    2772:      	leal	0x8(,%rax,4), %eax
    2779:      	movw	%ax, 0x2(%r12)
    277f:      	jmp	0x2787 <generic_fexit_event+0x2787>
    2781:      	movzwl	0x2(%r12), %eax
    2787:      	movq	%r12, %rcx
    278a:      	addw	(%r12), %ax
    278f:      	movw	%ax, (%r12)
    2794:      	movzbl	0x6(%r12), %ecx
    279a:      	cmpq	$0x3c, %rcx
    279e:      	ja	0x2b82 <generic_fexit_event+0x2b82>
    27a4:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    27ae:      	btq	%rcx, %rdx
    27b2:      	jae	0x2b82 <generic_fexit_event+0x2b82>
    27b8:      	movb	%cl, 0x5(%r12)
    27bd:      	movzwl	%ax, %ecx
    27c0:      	addq	%rbx, %rcx
    27c3:      	movl	$0x2, %edx
    27c8:      	movl	$0x4, %eax
    27cd:      	movq	%r15, %rdi
    27d0:      	movzwl	(%r12), %edx
    27d5:      	addq	%rbx, %rdx
    27d8:      	movl	$0x2, %esi
    27dd:      	callq	*%rax
    27df:      	testq	%rax, %rax
    27e2:      	js	0x2999 <generic_fexit_event+0x2999>
    27e8:      	movzbl	0x5(%r12), %eax
    27ee:      	cmpl	$0x32, %eax
    27f1:      	jg	0x280f <generic_fexit_event+0x280f>
    27f3:      	testl	%eax, %eax
    27f5:      	je	0x282e <generic_fexit_event+0x282e>
    27f7:      	cmpl	$0x2b, %eax
    27fa:      	je	0x282e <generic_fexit_event+0x282e>
    27fc:      	cmpl	$0x2c, %eax
    27ff:      	jne	0x285e <generic_fexit_event+0x285e>
    2801:      	movw	$0x8, 0x2(%r12)
    2809:      	movw	$0x8, %ax
    280d:      	jmp	0x2864 <generic_fexit_event+0x2864>
    280f:      	cmpl	$0x33, %eax
    2812:      	je	0x2846 <generic_fexit_event+0x2846>
    2814:      	cmpl	$0x3c, %eax
    2817:      	je	0x282e <generic_fexit_event+0x282e>
    2819:      	cmpl	$0xff, %eax
    281e:      	jne	0x285e <generic_fexit_event+0x285e>
    2820:      	movw	$0x28, 0x2(%r12)
    2828:      	movw	$0x28, %ax
    282c:      	jmp	0x2864 <generic_fexit_event+0x2864>
    282e:      	movq	%r12, %rcx
    2831:      	movzbl	0x7(%r12), %eax
    2837:      	leal	0x8(,%rax,8), %eax
    283e:      	movw	%ax, 0x2(%r12)
    2844:      	jmp	0x2864 <generic_fexit_event+0x2864>
    2846:      	movq	%r12, %rcx
    2849:      	movzbl	0x7(%r12), %eax
    284f:      	leal	0x8(,%rax,4), %eax
    2856:      	movw	%ax, 0x2(%r12)
    285c:      	jmp	0x2864 <generic_fexit_event+0x2864>
    285e:      	movzwl	0x2(%r12), %eax
    2864:      	movq	%r12, %rcx
    2867:      	addw	(%r12), %ax
    286c:      	movw	%ax, (%r12)
    2871:      	movzbl	0x6(%r12), %ecx
    2877:      	cmpq	$0x3c, %rcx
    287b:      	ja	0x2b82 <generic_fexit_event+0x2b82>
    2881:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    288b:      	btq	%rcx, %rdx
    288f:      	jae	0x2b82 <generic_fexit_event+0x2b82>
    2895:      	movb	%cl, 0x5(%r12)
    289a:      	movzwl	%ax, %ecx
    289d:      	addq	%rbx, %rcx
    28a0:      	movl	$0x2, %edx
    28a5:      	movl	$0x4, %eax
    28aa:      	movq	%r15, %rdi
    28ad:      	movzwl	(%r12), %edx
    28b2:      	addq	%rbx, %rdx
    28b5:      	movl	$0x2, %esi
    28ba:      	callq	*%rax
    28bc:      	testq	%rax, %rax
    28bf:      	js	0x2999 <generic_fexit_event+0x2999>
    28c5:      	movzbl	0x5(%r12), %eax
    28cb:      	cmpl	$0x32, %eax
    28ce:      	jg	0x28ec <generic_fexit_event+0x28ec>
    28d0:      	testl	%eax, %eax
    28d2:      	je	0x290b <generic_fexit_event+0x290b>
    28d4:      	cmpl	$0x2b, %eax
    28d7:      	je	0x290b <generic_fexit_event+0x290b>
    28d9:      	cmpl	$0x2c, %eax
    28dc:      	jne	0x293b <generic_fexit_event+0x293b>
    28de:      	movw	$0x8, 0x2(%r12)
    28e6:      	movw	$0x8, %ax
    28ea:      	jmp	0x2941 <generic_fexit_event+0x2941>
    28ec:      	cmpl	$0x33, %eax
    28ef:      	je	0x2923 <generic_fexit_event+0x2923>
    28f1:      	cmpl	$0x3c, %eax
    28f4:      	je	0x290b <generic_fexit_event+0x290b>
    28f6:      	cmpl	$0xff, %eax
    28fb:      	jne	0x293b <generic_fexit_event+0x293b>
    28fd:      	movw	$0x28, 0x2(%r12)
    2905:      	movw	$0x28, %ax
    2909:      	jmp	0x2941 <generic_fexit_event+0x2941>
    290b:      	movq	%r12, %rcx
    290e:      	movzbl	0x7(%r12), %eax
    2914:      	leal	0x8(,%rax,8), %eax
    291b:      	movw	%ax, 0x2(%r12)
    2921:      	jmp	0x2941 <generic_fexit_event+0x2941>
    2923:      	movq	%r12, %rcx
    2926:      	movzbl	0x7(%r12), %eax
    292c:      	leal	0x8(,%rax,4), %eax
    2933:      	movw	%ax, 0x2(%r12)
    2939:      	jmp	0x2941 <generic_fexit_event+0x2941>
    293b:      	movzwl	0x2(%r12), %eax
    2941:      	movq	%r12, %rcx
    2944:      	addw	(%r12), %ax
    2949:      	movw	%ax, (%r12)
    294e:      	movzbl	0x6(%r12), %ecx
    2954:      	cmpq	$0x3c, %rcx
    2958:      	ja	0x2b82 <generic_fexit_event+0x2b82>
    295e:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2968:      	btq	%rcx, %rdx
    296c:      	jae	0x2b82 <generic_fexit_event+0x2b82>
    2972:      	movb	%cl, 0x5(%r12)
    2977:      	movzwl	%ax, %ecx
    297a:      	addq	%rbx, %rcx
    297d:      	movl	$0x2, %edx
    2982:      	movl	$0x4, %eax
    2987:      	movzwl	(%r12), %edx
    298c:      	addq	%rbx, %rdx
    298f:      	movq	%r15, %rdi
    2992:      	movl	$0x2, %esi
    2997:      	callq	*%rax
    2999:      	xorl	%ecx, %ecx
    299b:      	movb	%cl, 0xc0(%rsp)
    29a2:      	movzbl	%cl, %eax
    29a5:      	movq	(%rsp), %rbx
    29a9:      	movw	%ax, 0xc0(%rbx)
    29b0:      	movw	$0xa, 0xc2(%rbx)
    29b9:      	leaq	0x8(%r13), %rdx
    29bd:      	movl	$0x10, %ecx
    29c2:      	movl	$0x4, %eax
    29c7:      	movq	0x8(%rsp), %rdi
    29cc:      	movl	$0x10, %esi
    29d1:      	callq	*%rax
    29d3:      	leaq	0xac(%rbx), %rdi
    29da:      	addq	$0x18, %r13
    29de:      	movl	$0x10, %ecx
    29e3:      	movl	$0x4, %eax
    29e8:      	movl	$0x10, %esi
    29ed:      	movq	%r13, %rdx
    29f0:      	callq	*%rax
    29f2:      	movzbl	0xc0(%rsp), %eax
    29fa:      	cmpl	$0x11, %eax
    29fd:      	je	0x2a53 <generic_fexit_event+0x2a53>
    29ff:      	cmpl	$0x6, %eax
    2a02:      	jne	0x2aa5 <generic_fexit_event+0x2aa5>
    2a08:      	movq	0x20(%rsp), %rbx
    2a0d:      	movzwl	0xc8(%rsp), %r15d
    2a16:      	leaq	(%rbx,%r15), %rdx
    2a1a:      	movq	(%rsp), %r12
    2a1e:      	leaq	0xbc(%r12), %rdi
    2a26:      	movl	$0x2, %ecx
    2a2b:      	movl	$0x4, %eax
    2a30:      	movl	$0x2, %esi
    2a35:      	callq	*%rax
    2a37:      	leaq	0xbe(%r12), %rdi
    2a3f:      	leaq	(%rbx,%r15), %rdx
    2a43:      	addq	$0x2, %rdx
    2a47:      	movl	$0x2, %ecx
    2a4c:      	movl	$0x4, %eax
    2a51:      	jmp	0x2a9c <generic_fexit_event+0x2a9c>
    2a53:      	movq	0x20(%rsp), %rbx
    2a58:      	movzwl	0xc8(%rsp), %r15d
    2a61:      	leaq	(%rbx,%r15), %rdx
    2a65:      	movq	(%rsp), %r12
    2a69:      	leaq	0xbc(%r12), %rdi
    2a71:      	movl	$0x2, %ecx
    2a76:      	movl	$0x4, %eax
    2a7b:      	movl	$0x2, %esi
    2a80:      	callq	*%rax
    2a82:      	leaq	0xbe(%r12), %rdi
    2a8a:      	leaq	(%rbx,%r15), %rdx
    2a8e:      	addq	$0x2, %rdx
    2a92:      	movl	$0x2, %ecx
    2a97:      	movl	$0x4, %eax
    2a9c:      	movl	$0x2, %esi
    2aa1:      	callq	*%rax
    2aa3:      	jmp	0x2ab3 <generic_fexit_event+0x2ab3>
    2aa5:      	movq	(%rsp), %rax
    2aa9:      	movl	$0x0, 0xbc(%rax)
    2ab3:      	movq	(%rsp), %rax
    2ab7:      	movzwl	0xbc(%rax), %ecx
    2abe:      	movzwl	0xbe(%rax), %edx
    2ac5:      	movbew	%cx, 0xbc(%rax)
    2ace:      	movbew	%dx, 0xbe(%rax)
    2ad7:      	addq	$0xe0, %r14
    2ade:      	leaq	0x68(%rsp), %rdi
    2ae3:      	movl	$0x8, %ecx
    2ae8:      	movl	$0x4, %eax
    2aed:      	movl	$0x4, %ebx
    2af2:      	movl	$0x8, %esi
    2af7:      	movq	%r14, %rdx
    2afa:      	callq	*%rax
    2afc:      	movq	0x68(%rsp), %rcx
    2b01:      	testq	%rcx, %rcx
    2b04:      	je	0x2b77 <generic_fexit_event+0x2b77>
    2b06:      	addq	$0x5, %rcx
    2b0a:      	leaq	0x90(%rsp), %rdi
    2b12:      	movl	$0x8, %edx
    2b17:      	movl	$0x4, %eax
    2b1c:      	movq	0x68(%rsp), %rdx
    2b21:      	addq	$0x5, %rdx
    2b25:      	movl	$0x8, %esi
    2b2a:      	callq	*%rax
    2b2c:      	movq	0x68(%rsp), %r14
    2b31:      	movq	0x90(%rsp), %r15
    2b39:      	movq	(%rsp), %r12
    2b3d:      	leaq	0xd4(%r12), %rdi
    2b45:      	leaq	(%r14,%r15,8), %rdx
    2b49:      	addq	$0x44, %rdx
    2b4d:      	movl	$0x4, %eax
    2b52:      	movl	$0x4, %esi
    2b57:      	callq	*%rax
    2b59:      	movq	%r12, %rdi
    2b5c:      	addq	$0xd8, %rdi
    2b63:      	leaq	(%r14,%r15,8), %rdx
    2b67:      	addq	$0x45, %rdx
    2b6b:      	movl	$0x4, %eax
    2b70:      	movl	$0x4, %esi
    2b75:      	callq	*%rax
    2b77:      	movl	$0x40, %r13d
    2b7d:      	jmp	0xd44 <generic_fexit_event+0xd44>
    2b82:      	movw	%ax, 0xc8(%rsp)
    2b8a:      	jmp	0x299b <generic_fexit_event+0x299b>
    2b8f:      	xorl	%eax, %eax
    2b91:      	movq	%rax, 0x8(%rsp)
    2b96:      	cmpq	$0x5, 0x80(%rsp)
    2b9f:      	je	0x2243 <generic_fexit_event+0x2243>
    2ba5:      	movq	0x88(%rsp), %rax
    2bad:      	leaq	0x50(%rax), %rdx
    2bb1:      	leaq	0x20(%rsp), %rdi
    2bb6:      	movl	$0x4, %r15d
    2bbc:      	movl	$0x10, %ecx
    2bc1:      	movl	$0x4, %eax
    2bc6:      	movl	$0x10, %esi
    2bcb:      	callq	*%rax
    2bcd:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2bd2:      	testl	%eax, %eax
    2bd4:      	js	0x2d07 <generic_fexit_event+0x2d07>
    2bda:      	movq	0x28(%rsp), %rdx
    2bdf:      	movq	0x8(%rsp), %rax
    2be4:      	cmpq	%rax, %rdx
    2be7:      	movq	%rax, %rbx
    2bea:      	cmovbq	%rdx, %rbx
    2bee:      	testq	%rax, %rax
    2bf1:      	cmovneq	%rbx, %rdx
    2bf5:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2bfa:      	movq	%rdx, 0x78(%rsp)
    2bff:      	cmpq	$0xffe, %rdx            # imm = 0xFFE
    2c06:      	ja	0x2d07 <generic_fexit_event+0x2d07>
    2c0c:      	movq	(%rsp), %rdi
    2c10:      	addq	%r12, %rdi
    2c13:      	movq	%rdi, (%rsp)
    2c17:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2c1d:      	addq	0x18(%rsp), %rdi
    2c22:      	movq	0x20(%rsp), %rcx
    2c27:      	movl	$0x4, %eax
    2c2c:      	movq	0x78(%rsp), %rsi
    2c31:      	movq	0x20(%rsp), %rdx
    2c36:      	callq	*%rax
    2c38:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2c3d:      	testl	%eax, %eax
    2c3f:      	js	0x2d07 <generic_fexit_event+0x2d07>
    2c45:      	addq	0x78(%rsp), %r13
    2c4a:      	cmpq	$0x0, 0x8(%rsp)
    2c50:      	je	0x2c5e <generic_fexit_event+0x2c5e>
    2c52:      	subq	%rbx, 0x8(%rsp)
    2c57:      	jne	0x2c65 <generic_fexit_event+0x2c65>
    2c59:      	jmp	0x2243 <generic_fexit_event+0x2243>
    2c5e:      	xorl	%eax, %eax
    2c60:      	movq	%rax, 0x8(%rsp)
    2c65:      	cmpq	$0x7, 0x80(%rsp)
    2c6e:      	jb	0x2243 <generic_fexit_event+0x2243>
    2c74:      	movq	0x88(%rsp), %rdx
    2c7c:      	addq	$0x60, %rdx
    2c80:      	leaq	0x20(%rsp), %rdi
    2c85:      	movl	$0x4, %r15d
    2c8b:      	movl	$0x10, %ecx
    2c90:      	movl	$0x4, %eax
    2c95:      	movl	$0x10, %esi
    2c9a:      	callq	*%rax
    2c9c:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2ca1:      	testl	%eax, %eax
    2ca3:      	js	0x2d07 <generic_fexit_event+0x2d07>
    2ca5:      	movq	0x28(%rsp), %rax
    2caa:      	movq	0x8(%rsp), %rcx
    2caf:      	cmpq	%rcx, %rax
    2cb2:      	movq	%rcx, %r12
    2cb5:      	cmovbq	%rax, %r12
    2cb9:      	testq	%rcx, %rcx
    2cbc:      	cmoveq	%rax, %r12
    2cc0:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2cc5:      	cmpq	$0xffe, %r12            # imm = 0xFFE
    2ccc:      	ja	0x2d07 <generic_fexit_event+0x2d07>
    2cce:      	movq	0x78(%rsp), %rdi
    2cd3:      	addq	(%rsp), %rdi
    2cd7:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2cdd:      	addq	0x18(%rsp), %rdi
    2ce2:      	movq	0x20(%rsp), %rcx
    2ce7:      	movl	$0x4, %eax
    2cec:      	movq	0x20(%rsp), %rdx
    2cf1:      	movl	%r12d, %esi
    2cf4:      	callq	*%rax
    2cf6:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2cfb:      	testl	%eax, %eax
    2cfd:      	js	0x2d07 <generic_fexit_event+0x2d07>
    2cff:      	addq	%r13, %r12
    2d02:      	jmp	0x435 <generic_fexit_event+0x435>
    2d07:      	movq	0x18(%rsp), %rax
    2d0c:      	movl	%ecx, (%rax,%r14)
    2d10:      	addq	%r14, %r15
    2d13:      	movq	%r15, %rbx
    2d16:      	movq	0xb0(%rsp), %r13
    2d1e:      	movq	0x60(%rsp), %r12
    2d23:      	movl	$0x23, %eax
    2d28:      	callq	*%rax
    2d2a:      	movq	%rax, %rcx
    2d2d:      	movq	%rax, 0x20(%rsp)
    2d32:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    2d39:      	leaq	0x90(%rsp), %rdi
    2d41:      	movl	$0x4, %edx
    2d46:      	movl	$0x71, %eax
    2d4b:      	movl	$0xaf4, %edx            # imm = 0xAF4
    2d50:      	addq	0x20(%rsp), %rdx
    2d55:      	movl	$0x4, %esi
    2d5a:      	callq	*%rax
    2d5c:      	movl	0x90(%rsp), %eax
    2d63:      	movl	%eax, 0x68(%rsp)
    2d67:      	movq	(%rip), %rdi            # 0x2d6e <generic_fexit_event+0x2d6e>
    2d6e:      	leaq	0x68(%rsp), %rsi
    2d73:      	movl	$0x1, %eax
    2d78:      	callq	*%rax
    2d7a:      	testq	%rax, %rax
    2d7d:      	je	0x2d8d <generic_fexit_event+0x2d8d>
    2d7f:      	movq	%rax, %r15
    2d82:      	cmpq	$0x0, 0x8(%rax)
    2d87:      	jne	0x2f63 <generic_fexit_event+0x2f63>
    2d8d:      	movl	$0xb00, %edx            # imm = 0xB00
    2d92:      	movq	0x20(%rsp), %rcx
    2d97:      	addq	%rdx, %rcx
    2d9a:      	leaq	0x20(%rsp), %rdi
    2d9f:      	movl	$0x8, %esi
    2da4:      	movl	$0x71, %eax
    2da9:      	addq	0x20(%rsp), %rdx
    2dae:      	movl	$0x8, %esi
    2db3:      	callq	*%rax
    2db5:      	movq	0x20(%rsp), %rcx
    2dba:      	testq	%rcx, %rcx
    2dbd:      	je	0x2f60 <generic_fexit_event+0x2f60>
    2dc3:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    2dca:      	leaq	0x90(%rsp), %rdi
    2dd2:      	movl	$0x4, %edx
    2dd7:      	movl	$0x71, %eax
    2ddc:      	movl	$0xaf4, %edx            # imm = 0xAF4
    2de1:      	addq	0x20(%rsp), %rdx
    2de6:      	movl	$0x4, %esi
    2deb:      	callq	*%rax
    2ded:      	movl	0x90(%rsp), %eax
    2df4:      	movl	%eax, 0x68(%rsp)
    2df8:      	movq	(%rip), %rdi            # 0x2dff <generic_fexit_event+0x2dff>
    2dff:      	leaq	0x68(%rsp), %rsi
    2e04:      	movl	$0x1, %eax
    2e09:      	callq	*%rax
    2e0b:      	testq	%rax, %rax
    2e0e:      	je	0x2e1e <generic_fexit_event+0x2e1e>
    2e10:      	movq	%rax, %r15
    2e13:      	cmpq	$0x0, 0x8(%rax)
    2e18:      	jne	0x2f63 <generic_fexit_event+0x2f63>
    2e1e:      	movl	$0xb00, %edx            # imm = 0xB00
    2e23:      	movq	0x20(%rsp), %rcx
    2e28:      	addq	%rdx, %rcx
    2e2b:      	leaq	0x20(%rsp), %rdi
    2e30:      	movl	$0x8, %esi
    2e35:      	movl	$0x71, %eax
    2e3a:      	addq	0x20(%rsp), %rdx
    2e3f:      	movl	$0x8, %esi
    2e44:      	callq	*%rax
    2e46:      	movq	0x20(%rsp), %rcx
    2e4b:      	testq	%rcx, %rcx
    2e4e:      	je	0x2f60 <generic_fexit_event+0x2f60>
    2e54:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    2e5b:      	leaq	0x90(%rsp), %rdi
    2e63:      	movl	$0x4, %edx
    2e68:      	movl	$0x71, %eax
    2e6d:      	movl	$0xaf4, %edx            # imm = 0xAF4
    2e72:      	addq	0x20(%rsp), %rdx
    2e77:      	movl	$0x4, %esi
    2e7c:      	callq	*%rax
    2e7e:      	movl	0x90(%rsp), %eax
    2e85:      	movl	%eax, 0x68(%rsp)
    2e89:      	movq	(%rip), %rdi            # 0x2e90 <generic_fexit_event+0x2e90>
    2e90:      	leaq	0x68(%rsp), %rsi
    2e95:      	movl	$0x1, %eax
    2e9a:      	callq	*%rax
    2e9c:      	testq	%rax, %rax
    2e9f:      	je	0x2eaf <generic_fexit_event+0x2eaf>
    2ea1:      	movq	%rax, %r15
    2ea4:      	cmpq	$0x0, 0x8(%rax)
    2ea9:      	jne	0x2f63 <generic_fexit_event+0x2f63>
    2eaf:      	movl	$0xb00, %edx            # imm = 0xB00
    2eb4:      	movq	0x20(%rsp), %rcx
    2eb9:      	addq	%rdx, %rcx
    2ebc:      	leaq	0x20(%rsp), %rdi
    2ec1:      	movl	$0x8, %esi
    2ec6:      	movl	$0x71, %eax
    2ecb:      	addq	0x20(%rsp), %rdx
    2ed0:      	movl	$0x8, %esi
    2ed5:      	callq	*%rax
    2ed7:      	movq	0x20(%rsp), %rcx
    2edc:      	testq	%rcx, %rcx
    2edf:      	je	0x2f60 <generic_fexit_event+0x2f60>
    2ee1:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    2ee8:      	leaq	0x90(%rsp), %rdi
    2ef0:      	movl	$0x4, %edx
    2ef5:      	movl	$0x71, %eax
    2efa:      	movl	$0xaf4, %edx            # imm = 0xAF4
    2eff:      	addq	0x20(%rsp), %rdx
    2f04:      	movl	$0x4, %esi
    2f09:      	callq	*%rax
    2f0b:      	movl	0x90(%rsp), %eax
    2f12:      	movl	%eax, 0x68(%rsp)
    2f16:      	movq	(%rip), %rdi            # 0x2f1d <generic_fexit_event+0x2f1d>
    2f1d:      	leaq	0x68(%rsp), %rsi
    2f22:      	movl	$0x1, %eax
    2f27:      	callq	*%rax
    2f29:      	testq	%rax, %rax
    2f2c:      	je	0x2f38 <generic_fexit_event+0x2f38>
    2f2e:      	movq	%rax, %r15
    2f31:      	cmpq	$0x0, 0x8(%rax)
    2f36:      	jne	0x2f63 <generic_fexit_event+0x2f63>
    2f38:      	movl	$0xb00, %edx            # imm = 0xB00
    2f3d:      	movq	0x20(%rsp), %rcx
    2f42:      	addq	%rdx, %rcx
    2f45:      	leaq	0x20(%rsp), %rdi
    2f4a:      	movl	$0x8, %esi
    2f4f:      	movl	$0x71, %eax
    2f54:      	addq	0x20(%rsp), %rdx
    2f59:      	movl	$0x8, %esi
    2f5e:      	callq	*%rax
    2f60:      	xorl	%r15d, %r15d
    2f63:      	movl	$0x10d, (%rbp)          # imm = 0x10D
    2f6a:      	movl	%ebx, 0x4(%rbp)
    2f6d:      	movl	$0x7d, %eax
    2f72:      	callq	*%rax
    2f74:      	movq	%rax, 0x8(%rbp)
    2f78:      	testq	%r15, %r15
    2f7b:      	je	0x2f8b <generic_fexit_event+0x2f8b>
    2f7d:      	movl	(%r15), %eax
    2f80:      	movl	%eax, 0x10(%rbp)
    2f83:      	movq	0x8(%r15), %rax
    2f87:      	movq	%rax, 0x18(%rbp)
    2f8b:      	movl	$0x0, 0x14(%rbp)
    2f92:      	movl	(%r12), %eax
    2f96:      	movq	%rax, 0x60(%rbp)
    2f9a:      	movl	%ebx, 0x4(%rbp)
    2f9d:      	movq	(%rip), %rsi            # 0x2fa4 <generic_fexit_event+0x2fa4>
    2fa4:      	movl	$0x3, %ecx
    2fa9:      	movl	$0xc, %eax
    2fae:      	movq	%r13, %rdi
    2fb1:      	movl	$0x3, %edx
    2fb6:      	callq	*%rax
    2fb8:      	xorl	%eax, %eax
    2fba:      	addq	$0xf8, %rsp
    2fc1:      	popq	%rbx
    2fc2:      	popq	%r12
    2fc4:      	popq	%r13
    2fc6:      	popq	%r14
    2fc8:      	popq	%r15
    2fca:      	popq	%rbp
    2fcb:      	retq
