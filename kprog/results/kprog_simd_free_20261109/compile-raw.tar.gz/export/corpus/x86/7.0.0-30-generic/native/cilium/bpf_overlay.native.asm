
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/cilium/bpf_overlay.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <__check_cluster_id_bits>:
       0:      	movq	(%rip), %rax            # 0x7 <__check_cluster_id_bits+0x7>
       7:      	movl	(%rax), %eax
       9:      	retq
       a:      	nopw	(%rax,%rax)

0000000000000010 <__check_device_mtu>:
      10:      	movq	(%rip), %rax            # 0x17 <__check_device_mtu+0x7>
      17:      	movzwl	(%rax), %eax
      1a:      	retq

Disassembly of section tc/tail:

0000000000000000 <tail_drop_notify>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x58, %rsp
       e:      	movq	%rdi, %rbx
      11:      	movl	0x38(%rdi), %r15d
      15:      	movq	(%rip), %rax            # 0x1c <tail_drop_notify+0x1c>
      1c:      	cmpb	$0x0, (%rax)
      1f:      	je	0x46 <tail_drop_notify+0x46>
      21:      	movl	$0x0, 0x10(%rsp)
      29:      	movl	$0x1, %eax
      2e:      	movq	(%rip), %rdi            # 0x35 <tail_drop_notify+0x35>
      35:      	leaq	0x10(%rsp), %rsi
      3a:      	callq	*%rax
      3c:      	testq	%rax, %rax
      3f:      	je	0x46 <tail_drop_notify+0x46>
      41:      	movq	(%rax), %r12
      44:      	jmp	0x49 <tail_drop_notify+0x49>
      46:      	xorl	%r12d, %r12d
      49:      	movl	0x40(%rbx), %ebp
      4c:      	movl	0x70(%rbx), %r13d
      50:      	movq	$0x2, 0x40(%rsp)
      59:      	movq	(%rip), %rax            # 0x60 <tail_drop_notify+0x60>
      60:      	cmpl	$0x0, (%rax)
      63:      	movl	%r13d, %edi
      66:      	je	0x1c4 <tail_drop_notify+0x1c4>
      6c:      	movq	%r12, 0x8(%rsp)
      71:      	movl	%r15d, (%rsp)
      75:      	movq	(%rip), %rcx            # 0x7c <tail_drop_notify+0x7c>
      7c:      	movl	(%rcx), %ecx
      7e:      	movq	%rcx, 0x48(%rsp)
      83:      	movl	(%rax), %r12d
      86:      	movl	$0x5, %ecx
      8b:      	xorl	%eax, %eax
      8d:      	callq	*%rcx
      8f:      	movq	%rax, %r15
      92:      	movl	$0x2, 0x4(%rsp)
      9a:      	movl	$0x1, %eax
      9f:      	movq	(%rip), %rdi            # 0xa6 <tail_drop_notify+0xa6>
      a6:      	leaq	0x4(%rsp), %rsi
      ab:      	callq	*%rax
      ad:      	movq	%rax, %r14
      b0:      	testq	%rax, %rax
      b3:      	jne	0xe3 <tail_drop_notify+0xe3>
      b5:      	movq	$0x0, 0x50(%rsp)
      be:      	movl	$0x2, %eax
      c3:      	movq	(%rip), %rdi            # 0xca <tail_drop_notify+0xca>
      ca:      	leaq	0x4(%rsp), %rsi
      cf:      	leaq	0x50(%rsp), %r14
      d4:      	movq	%r14, %rdx
      d7:      	xorl	%ecx, %ecx
      d9:      	callq	*%rax
      db:      	testl	%eax, %eax
      dd:      	js	0x2a3 <tail_drop_notify+0x2a3>
      e3:      	movl	$0x1, %eax
      e8:      	movq	(%rip), %rdi            # 0xef <tail_drop_notify+0xef>
      ef:      	leaq	0x40(%rsp), %rsi
      f4:      	callq	*%rax
      f6:      	testq	%rax, %rax
      f9:      	je	0x16b <tail_drop_notify+0x16b>
      fb:      	movq	(%rax), %rcx
      fe:      	movq	%r15, %rsi
     101:      	subq	%rcx, %rsi
     104:      	cmpq	$0x3b9aca00, %rsi       # imm = 0x3B9ACA00
     10b:      	jbe	0x1a4 <tail_drop_notify+0x1a4>
     111:      	movl	$0x3b9aca00, %ecx       # imm = 0x3B9ACA00
     116:      	movq	%rax, %rdi
     119:      	movq	%rsi, %rax
     11c:      	xorl	%edx, %edx
     11e:      	divq	%rcx
     121:      	movq	%rax, %rcx
     124:      	movl	$0x3b9aca00, %r8d       # imm = 0x3B9ACA00
     12a:      	movq	%rsi, %rax
     12d:      	xorl	%edx, %edx
     12f:      	divq	%r8
     132:      	movq	%rdi, %rax
     135:      	imulq	%r12, %rcx
     139:      	addq	0x8(%rdi), %rcx
     13d:      	movq	%rcx, 0x8(%rdi)
     141:      	subq	%rdx, %r15
     144:      	movq	%r15, (%rdi)
     147:      	movq	0x48(%rsp), %rdx
     14c:      	cmpq	%rdx, %rcx
     14f:      	movl	(%rsp), %r15d
     153:      	movq	0x8(%rsp), %r12
     158:      	jbe	0x161 <tail_drop_notify+0x161>
     15a:      	movq	%rdx, 0x8(%rax)
     15e:      	movq	%rdx, %rcx
     161:      	testq	%rcx, %rcx
     164:      	jne	0x1ba <tail_drop_notify+0x1ba>
     166:      	jmp	0x2b6 <tail_drop_notify+0x2b6>
     16b:      	movq	%r15, 0x10(%rsp)
     170:      	decq	%r12
     173:      	movq	%r12, 0x18(%rsp)
     178:      	movl	$0x2, %eax
     17d:      	movq	(%rip), %rdi            # 0x184 <tail_drop_notify+0x184>
     184:      	leaq	0x40(%rsp), %rsi
     189:      	leaq	0x10(%rsp), %rdx
     18e:      	xorl	%ecx, %ecx
     190:      	callq	*%rax
     192:      	testl	%eax, %eax
     194:      	movl	(%rsp), %r15d
     198:      	movq	0x8(%rsp), %r12
     19d:      	jns	0x1c1 <tail_drop_notify+0x1c1>
     19f:      	jmp	0x2b6 <tail_drop_notify+0x2b6>
     1a4:      	movq	0x8(%rax), %rcx
     1a8:      	movl	(%rsp), %r15d
     1ac:      	movq	0x8(%rsp), %r12
     1b1:      	testq	%rcx, %rcx
     1b4:      	je	0x2b6 <tail_drop_notify+0x2b6>
     1ba:      	decq	%rcx
     1bd:      	movq	%rcx, 0x8(%rax)
     1c1:      	movl	0x70(%rbx), %edi
     1c4:      	movl	%ebp, %ecx
     1c6:      	shrl	$0x10, %ecx
     1c9:      	movl	%ebp, %edx
     1cb:      	shrl	$0x8, %edx
     1ce:      	movzwl	0xb4(%rbx), %eax
     1d5:      	cmpl	$0xdd86, %eax           # imm = 0xDD86
     1da:      	sete	%sil
     1de:      	movq	(%rip), %rax            # 0x1e5 <tail_drop_notify+0x1e5>
     1e5:      	movl	(%rax), %eax
     1e7:      	cmpl	%eax, %edi
     1e9:      	cmovbl	%edi, %eax
     1ec:      	movl	0x98(%rbx), %r11d
     1f3:      	movl	0x30(%rbx), %r8d
     1f7:      	movl	0x34(%rbx), %r9d
     1fb:      	movl	0x3c(%rbx), %r10d
     1ff:      	movl	%r15d, %edi
     202:      	shrl	$0x8, %edi
     205:      	movq	0x10(%rbx), %r14
     209:      	testq	%r14, %r14
     20c:      	je	0x217 <tail_drop_notify+0x217>
     20e:      	movl	0xe0(%r14), %r14d
     215:      	jmp	0x21a <tail_drop_notify+0x21a>
     217:      	xorl	%r14d, %r14d
     21a:      	movb	$0x0, 0x37(%rsp)
     21f:      	movw	$0x0, 0x35(%rsp)
     226:      	movb	$0x1, 0x10(%rsp)
     22b:      	movb	%r15b, 0x11(%rsp)
     230:      	movw	$0x0, 0x12(%rsp)
     237:      	movl	%r11d, 0x14(%rsp)
     23c:      	movl	%r13d, 0x18(%rsp)
     241:      	movw	%ax, 0x1c(%rsp)
     246:      	movw	$0x3, 0x1e(%rsp)
     24d:      	movl	%r8d, 0x20(%rsp)
     252:      	movl	%r9d, 0x24(%rsp)
     257:      	movl	%r10d, 0x28(%rsp)
     25c:      	movw	%cx, 0x2c(%rsp)
     261:      	movb	%dl, 0x2e(%rsp)
     265:      	movb	%dil, 0x2f(%rsp)
     26a:      	movl	%r14d, 0x30(%rsp)
     26f:      	movb	%sil, 0x34(%rsp)
     274:      	movq	%r12, 0x38(%rsp)
     279:      	movl	$0x19, %r9d
     27f:      	shlq	$0x20, %rax
     283:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     288:      	orq	%rax, %rdx
     28b:      	movq	(%rip), %rsi            # 0x292 <tail_drop_notify+0x292>
     292:      	leaq	0x10(%rsp), %rcx
     297:      	movq	%rbx, %rdi
     29a:      	movl	$0x30, %r8d
     2a0:      	callq	*%r9
     2a3:      	movzbl	%bpl, %eax
     2a7:      	addq	$0x58, %rsp
     2ab:      	popq	%rbx
     2ac:      	popq	%r12
     2ae:      	popq	%r13
     2b0:      	popq	%r14
     2b2:      	popq	%r15
     2b4:      	popq	%rbp
     2b5:      	retq
     2b6:      	incq	(%r14)
     2b9:      	jmp	0x2a3 <tail_drop_notify+0x2a3>
     2bb:      	nopl	(%rax,%rax)

00000000000002c0 <tail_icmp6_send_time_exceeded>:
     2c0:      	pushq	%rbp
     2c1:      	pushq	%r15
     2c3:      	pushq	%r14
     2c5:      	pushq	%r13
     2c7:      	pushq	%r12
     2c9:      	pushq	%rbx
     2ca:      	subq	$0xc8, %rsp
     2d1:      	movq	%rdi, %rbx
     2d4:      	movl	0x30(%rdi), %r14d
     2d8:      	movl	0x34(%rdi), %r13d
     2dc:      	movl	$0x0, 0x30(%rdi)
     2e3:      	movq	$0x0, 0x78(%rsp)
     2ec:      	movq	$0x0, 0x70(%rsp)
     2f5:      	movq	$0x0, 0x68(%rsp)
     2fe:      	movq	$0x0, 0x60(%rsp)
     307:      	movq	$0x0, 0x58(%rsp)
     310:      	movq	$0x0, 0x50(%rsp)
     319:      	movq	$0x0, 0x48(%rsp)
     322:      	movq	$0x0, 0x40(%rsp)
     32b:      	movq	$0x0, 0x38(%rsp)
     334:      	movq	$0x0, 0x30(%rsp)
     33d:      	movw	$0x0, 0x4(%rsp)
     344:      	movb	$0x3a, 0x7(%rsp)
     349:      	movq	(%rip), %rax            # 0x350 <tail_icmp6_send_time_exceeded+0x90>
     350:      	movq	(%rax), %rcx
     353:      	movq	%rcx, 0x90(%rsp)
     35b:      	movq	0x8(%rax), %rax
     35f:      	movq	%rax, 0x88(%rsp)
     367:      	movq	$0x3, 0x30(%rsp)
     370:      	leaq	0x38(%rsp), %r15
     375:      	movl	$0xe02, 0x8(%rsp)       # imm = 0xE02
     37d:      	movl	0x98(%rdi), %eax
     383:      	movl	%eax, 0xc(%rsp)
     387:      	movq	$0x0, 0x10(%rsp)
     390:      	movl	$0x0, 0x18(%rsp)
     398:      	movl	$0x19, %eax
     39d:      	movq	(%rip), %rsi            # 0x3a4 <tail_icmp6_send_time_exceeded+0xe4>
     3a4:      	leaq	0x8(%rsp), %rcx
     3a9:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     3ae:      	movl	$0x14, %r8d
     3b4:      	callq	*%rax
     3b6:      	movl	$0x1a, %eax
     3bb:      	movq	%rbx, %rdi
     3be:      	movl	%r14d, %esi
     3c1:      	movq	%r15, %rdx
     3c4:      	movl	$0x28, %ecx
     3c9:      	callq	*%rax
     3cb:      	movl	$0xffffff7a, %ebp       # imm = 0xFFFFFF7A
     3d0:      	testl	%eax, %eax
     3d2:      	js	0x8dd <tail_icmp6_send_time_exceeded+0x61d>
     3d8:      	movl	$0x9, %eax
     3dd:      	leal	0x6(%r14), %esi
     3e1:      	leaq	0x7(%rsp), %rdx
     3e6:      	movq	%rbx, %rdi
     3e9:      	movl	$0x1, %ecx
     3ee:      	xorl	%r8d, %r8d
     3f1:      	callq	*%rax
     3f3:      	testl	%eax, %eax
     3f5:      	js	0x8d8 <tail_icmp6_send_time_exceeded+0x618>
     3fb:      	leaq	0x60(%rsp), %rdx
     400:      	movzbl	0x3e(%rsp), %eax
     405:      	cmpl	$0x6, %eax
     408:      	je	0x533 <tail_icmp6_send_time_exceeded+0x273>
     40e:      	cmpl	$0x3a, %eax
     411:      	je	0x421 <tail_icmp6_send_time_exceeded+0x161>
     413:      	movl	$0xffffff72, %ebp       # imm = 0xFFFFFF72
     418:      	cmpl	$0x11, %eax
     41b:      	jne	0x8dd <tail_icmp6_send_time_exceeded+0x61d>
     421:      	movl	$0x1a, %eax
     426:      	leal	0x28(%r14), %r15d
     42a:      	movq	%rbx, %rdi
     42d:      	movl	%r15d, %esi
     430:      	movl	$0x8, %ecx
     435:      	callq	*%rax
     437:      	movl	$0xffffff7a, %ebp       # imm = 0xFFFFFF7A
     43c:      	testl	%eax, %eax
     43e:      	js	0x8dd <tail_icmp6_send_time_exceeded+0x61d>
     444:      	movl	$0x1c, %eax
     449:      	leaq	0x30(%rsp), %rdx
     44e:      	xorl	%edi, %edi
     450:      	xorl	%esi, %esi
     452:      	movl	$0x38, %ecx
     457:      	xorl	%r8d, %r8d
     45a:      	callq	*%rax
     45c:      	movl	$0x38000000, 0x8(%rsp)  # imm = 0x38000000
     464:      	movl	$0x3a000000, 0x20(%rsp) # imm = 0x3A000000
     46c:      	leaq	0x40(%rsp), %rdx
     471:      	movl	$0x1c, %r9d
     477:      	xorl	%edi, %edi
     479:      	xorl	%esi, %esi
     47b:      	movl	$0x10, %ecx
     480:      	movl	%eax, %r8d
     483:      	callq	*%r9
     486:      	leaq	0x50(%rsp), %rdx
     48b:      	movl	$0x1c, %r9d
     491:      	xorl	%edi, %edi
     493:      	xorl	%esi, %esi
     495:      	movl	$0x10, %ecx
     49a:      	movl	%eax, %r8d
     49d:      	callq	*%r9
     4a0:      	movl	$0x1c, %r9d
     4a6:      	leaq	0x8(%rsp), %rdx
     4ab:      	xorl	%edi, %edi
     4ad:      	xorl	%esi, %esi
     4af:      	movl	$0x4, %ecx
     4b4:      	movl	%eax, %r8d
     4b7:      	callq	*%r9
     4ba:      	movl	$0x1c, %r9d
     4c0:      	leaq	0x20(%rsp), %rdx
     4c5:      	xorl	%edi, %edi
     4c7:      	xorl	%esi, %esi
     4c9:      	movl	$0x4, %ecx
     4ce:      	movl	%eax, %r8d
     4d1:      	callq	*%r9
     4d4:      	movl	%eax, %r12d
     4d7:      	movw	$0x3800, 0x4(%rsp)      # imm = 0x3800
     4de:      	movbew	0x3c(%rsp), %ax
     4e5:      	movzwl	%ax, %eax
     4e8:      	movl	$0x26, %ecx
     4ed:      	movl	0x70(%rbx), %edx
     4f0:      	negl	%eax
     4f2:      	leal	(%rdx,%rax), %esi
     4f5:      	addl	$0x38, %esi
     4f8:      	movq	%rbx, %rdi
     4fb:      	xorl	%edx, %edx
     4fd:      	callq	*%rcx
     4ff:      	testl	%eax, %eax
     501:      	js	0x8d8 <tail_icmp6_send_time_exceeded+0x618>
     507:      	movl	$0x9, %eax
     50c:      	leaq	0x30(%rsp), %rdx
     511:      	movq	%rbx, %rdi
     514:      	movl	%r15d, %esi
     517:      	movl	$0x38, %ecx
     51c:      	xorl	%r8d, %r8d
     51f:      	callq	*%rax
     521:      	testl	%eax, %eax
     523:      	js	0x8d8 <tail_icmp6_send_time_exceeded+0x618>
     529:      	movl	$0x9, %eax
     52e:      	jmp	0x63b <tail_icmp6_send_time_exceeded+0x37b>
     533:      	movl	$0x1a, %eax
     538:      	leal	0x28(%r14), %r15d
     53c:      	movq	%rbx, %rdi
     53f:      	movl	%r15d, %esi
     542:      	movl	$0x14, %ecx
     547:      	callq	*%rax
     549:      	testl	%eax, %eax
     54b:      	js	0x8dd <tail_icmp6_send_time_exceeded+0x61d>
     551:      	movl	$0x1c, %eax
     556:      	leaq	0x30(%rsp), %rdx
     55b:      	xorl	%edi, %edi
     55d:      	xorl	%esi, %esi
     55f:      	movl	$0x44, %ecx
     564:      	xorl	%r8d, %r8d
     567:      	callq	*%rax
     569:      	movl	$0x44000000, 0x8(%rsp)  # imm = 0x44000000
     571:      	movl	$0x3a000000, 0x20(%rsp) # imm = 0x3A000000
     579:      	leaq	0x40(%rsp), %rdx
     57e:      	movl	$0x1c, %r9d
     584:      	xorl	%edi, %edi
     586:      	xorl	%esi, %esi
     588:      	movl	$0x10, %ecx
     58d:      	movl	%eax, %r8d
     590:      	callq	*%r9
     593:      	leaq	0x50(%rsp), %rdx
     598:      	movl	$0x1c, %r9d
     59e:      	xorl	%edi, %edi
     5a0:      	xorl	%esi, %esi
     5a2:      	movl	$0x10, %ecx
     5a7:      	movl	%eax, %r8d
     5aa:      	callq	*%r9
     5ad:      	movl	$0x1c, %r9d
     5b3:      	leaq	0x8(%rsp), %rdx
     5b8:      	xorl	%edi, %edi
     5ba:      	xorl	%esi, %esi
     5bc:      	movl	$0x4, %ecx
     5c1:      	movl	%eax, %r8d
     5c4:      	callq	*%r9
     5c7:      	movl	$0x1c, %r9d
     5cd:      	leaq	0x20(%rsp), %rdx
     5d2:      	xorl	%edi, %edi
     5d4:      	xorl	%esi, %esi
     5d6:      	movl	$0x4, %ecx
     5db:      	movl	%eax, %r8d
     5de:      	callq	*%r9
     5e1:      	movl	%eax, %r12d
     5e4:      	movw	$0x4400, 0x4(%rsp)      # imm = 0x4400
     5eb:      	movbew	0x3c(%rsp), %ax
     5f2:      	movzwl	%ax, %eax
     5f5:      	movl	$0x26, %ecx
     5fa:      	movl	0x70(%rbx), %edx
     5fd:      	negl	%eax
     5ff:      	leal	(%rdx,%rax), %esi
     602:      	addl	$0x44, %esi
     605:      	movq	%rbx, %rdi
     608:      	xorl	%edx, %edx
     60a:      	callq	*%rcx
     60c:      	testl	%eax, %eax
     60e:      	js	0x8d8 <tail_icmp6_send_time_exceeded+0x618>
     614:      	movl	$0x9, %eax
     619:      	leaq	0x30(%rsp), %rdx
     61e:      	movq	%rbx, %rdi
     621:      	movl	%r15d, %esi
     624:      	movl	$0x44, %ecx
     629:      	xorl	%r8d, %r8d
     62c:      	callq	*%rax
     62e:      	testl	%eax, %eax
     630:      	js	0x8d8 <tail_icmp6_send_time_exceeded+0x618>
     636:      	movl	$0x9, %eax
     63b:      	leal	0x4(%r14), %esi
     63f:      	leaq	0x4(%rsp), %rdx
     644:      	movq	%rbx, %rdi
     647:      	movl	$0x2, %ecx
     64c:      	xorl	%r8d, %r8d
     64f:      	callq	*%rax
     651:      	movl	$0xffffff73, %ebp       # imm = 0xFFFFFF73
     656:      	testl	%eax, %eax
     658:      	js	0x8dd <tail_icmp6_send_time_exceeded+0x61d>
     65e:      	leal	0x2a(%r14), %r15d
     662:      	movl	$0xb, %eax
     667:      	movq	%rbx, %rdi
     66a:      	movl	%r15d, %esi
     66d:      	xorl	%edx, %edx
     66f:      	movl	%r12d, %ecx
     672:      	movl	$0x10, %r8d
     678:      	callq	*%rax
     67a:      	testl	%eax, %eax
     67c:      	js	0x998 <tail_icmp6_send_time_exceeded+0x6d8>
     682:      	movq	0x90(%rsp), %rax
     68a:      	movq	0x88(%rsp), %rcx
     692:      	movq	%rax, 0x20(%rsp)
     697:      	movq	%rcx, 0x28(%rsp)
     69c:      	movq	(%rip), %rax            # 0x6a3 <tail_icmp6_send_time_exceeded+0x3e3>
     6a3:      	movq	(%rax), %rax
     6a6:      	movq	%rax, 0x98(%rsp)
     6ae:      	movl	$0x1a, %eax
     6b3:      	leal	0x8(%r14), %r12d
     6b7:      	leaq	0xa8(%rsp), %rdx
     6bf:      	movq	%rbx, %rdi
     6c2:      	movl	%r12d, %esi
     6c5:      	movl	$0x10, %ecx
     6ca:      	callq	*%rax
     6cc:      	movl	$0xffffff7a, %ebp       # imm = 0xFFFFFF7A
     6d1:      	testl	%eax, %eax
     6d3:      	js	0x8dd <tail_icmp6_send_time_exceeded+0x61d>
     6d9:      	movl	$0x1a, %eax
     6de:      	addl	$0x18, %r14d
     6e2:      	leaq	0xb8(%rsp), %rdx
     6ea:      	movq	%rbx, %rdi
     6ed:      	movl	%r14d, %esi
     6f0:      	movl	$0x10, %ecx
     6f5:      	callq	*%rax
     6f7:      	testl	%eax, %eax
     6f9:      	js	0x8dd <tail_icmp6_send_time_exceeded+0x61d>
     6ff:      	movl	$0x9, %eax
     704:      	leaq	0x20(%rsp), %rdx
     709:      	movq	%rbx, %rdi
     70c:      	movl	%r12d, %esi
     70f:      	movl	$0x10, %ecx
     714:      	xorl	%r8d, %r8d
     717:      	callq	*%rax
     719:      	testl	%eax, %eax
     71b:      	js	0x8d8 <tail_icmp6_send_time_exceeded+0x618>
     721:      	movl	$0x9, %eax
     726:      	leaq	0xa8(%rsp), %rdx
     72e:      	movq	%rbx, %rdi
     731:      	movl	%r14d, %esi
     734:      	movl	$0x10, %ecx
     739:      	xorl	%r8d, %r8d
     73c:      	callq	*%rax
     73e:      	testl	%eax, %eax
     740:      	js	0x8d8 <tail_icmp6_send_time_exceeded+0x618>
     746:      	movl	$0x1c, %eax
     74b:      	leaq	0xa8(%rsp), %rdi
     753:      	leaq	0x20(%rsp), %rdx
     758:      	movl	$0x10, %esi
     75d:      	movl	$0x10, %ecx
     762:      	xorl	%r8d, %r8d
     765:      	callq	*%rax
     767:      	movl	$0xb, %r14d
     76d:      	movq	%rbx, %rdi
     770:      	movl	%r15d, %esi
     773:      	xorl	%edx, %edx
     775:      	movl	%eax, %ecx
     777:      	movl	$0x10, %r8d
     77d:      	callq	*%r14
     780:      	movl	$0xffffff66, %ebp       # imm = 0xFFFFFF66
     785:      	testl	%eax, %eax
     787:      	js	0x8dd <tail_icmp6_send_time_exceeded+0x61d>
     78d:      	movl	$0x1c, %eax
     792:      	leaq	0xb8(%rsp), %rdi
     79a:      	leaq	0xa8(%rsp), %rdx
     7a2:      	movl	$0x10, %esi
     7a7:      	movl	$0x10, %ecx
     7ac:      	xorl	%r8d, %r8d
     7af:      	callq	*%rax
     7b1:      	movq	%rbx, %rdi
     7b4:      	movl	%r15d, %esi
     7b7:      	xorl	%edx, %edx
     7b9:      	movl	%eax, %ecx
     7bb:      	movl	$0x10, %r8d
     7c1:      	callq	*%r14
     7c4:      	testl	%eax, %eax
     7c6:      	js	0x8dd <tail_icmp6_send_time_exceeded+0x61d>
     7cc:      	movl	$0x1a, %eax
     7d1:      	leaq	0xa0(%rsp), %rdx
     7d9:      	movq	%rbx, %rdi
     7dc:      	movl	$0x6, %esi
     7e1:      	movl	$0x6, %ecx
     7e6:      	callq	*%rax
     7e8:      	movl	$0xffffff7a, %ebp       # imm = 0xFFFFFF7A
     7ed:      	testl	%eax, %eax
     7ef:      	js	0x8dd <tail_icmp6_send_time_exceeded+0x61d>
     7f5:      	movl	$0x9, %eax
     7fa:      	leaq	0xa0(%rsp), %rdx
     802:      	movq	%rbx, %rdi
     805:      	xorl	%esi, %esi
     807:      	movl	$0x6, %ecx
     80c:      	xorl	%r8d, %r8d
     80f:      	callq	*%rax
     811:      	testl	%eax, %eax
     813:      	js	0x8d8 <tail_icmp6_send_time_exceeded+0x618>
     819:      	movl	$0x9, %eax
     81e:      	leaq	0x98(%rsp), %rdx
     826:      	xorl	%r14d, %r14d
     829:      	movq	%rbx, %rdi
     82c:      	movl	$0x6, %esi
     831:      	movl	$0x6, %ecx
     836:      	xorl	%r8d, %r8d
     839:      	callq	*%rax
     83b:      	movl	$0xffffff73, %ebp       # imm = 0xFFFFFF73
     840:      	testl	%eax, %eax
     842:      	js	0x8dd <tail_icmp6_send_time_exceeded+0x61d>
     848:      	movq	0x10(%rbx), %rax
     84c:      	testq	%rax, %rax
     84f:      	je	0x858 <tail_icmp6_send_time_exceeded+0x598>
     851:      	movl	0xe0(%rax), %r14d
     858:      	movl	0x70(%rbx), %eax
     85b:      	movq	(%rip), %rcx            # 0x862 <tail_icmp6_send_time_exceeded+0x5a2>
     862:      	movl	(%rcx), %edx
     864:      	cmpl	%edx, %eax
     866:      	movl	$0x403, 0x8(%rsp)       # imm = 0x403
     86e:      	cmovbl	%eax, %edx
     871:      	movl	0x98(%rbx), %ecx
     877:      	movl	%ecx, 0xc(%rsp)
     87b:      	movl	%eax, 0x10(%rsp)
     87f:      	movw	%dx, 0x14(%rsp)
     884:      	movw	$0x1, 0x16(%rsp)
     88b:      	movl	%r14d, 0x18(%rsp)
     890:      	movl	$0x0, 0x1c(%rsp)
     898:      	movl	$0x19, %eax
     89d:      	shlq	$0x20, %rdx
     8a1:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
     8a6:      	orq	%rcx, %rdx
     8a9:      	movq	(%rip), %rsi            # 0x8b0 <tail_icmp6_send_time_exceeded+0x5f0>
     8b0:      	leaq	0x8(%rsp), %rcx
     8b5:      	movq	%rbx, %rdi
     8b8:      	movl	$0x18, %r8d
     8be:      	callq	*%rax
     8c0:      	movq	0x10(%rbx), %rax
     8c4:      	testq	%rax, %rax
     8c7:      	je	0x9a2 <tail_icmp6_send_time_exceeded+0x6e2>
     8cd:      	movl	0xe0(%rax), %edi
     8d3:      	jmp	0x9a4 <tail_icmp6_send_time_exceeded+0x6e4>
     8d8:      	movl	$0xffffff73, %ebp       # imm = 0xFFFFFF73
     8dd:      	movl	%ebp, %eax
     8df:      	negl	%eax
     8e1:      	cmovsl	%ebp, %eax
     8e4:      	movq	$0x0, 0x30(%rbx)
     8ec:      	movzbl	%al, %eax
     8ef:      	movl	%eax, 0x38(%rbx)
     8f2:      	movabsq	$0x142670200000000, %rcx # imm = 0x142670200000000
     8fc:      	movq	%rcx, 0x3c(%rbx)
     900:      	movl	0x70(%rbx), %r14d
     904:      	movabsq	$0x6701420000, %rcx     # imm = 0x6701420000
     90e:      	movq	%rcx, 0x8(%rsp)
     913:      	movb	%al, 0x8(%rsp)
     917:      	andb	$0x3, %r13b
     91b:      	movb	%r13b, 0x9(%rsp)
     920:      	movl	$0x1, %eax
     925:      	movq	(%rip), %rdi            # 0x92c <tail_icmp6_send_time_exceeded+0x66c>
     92c:      	leaq	0x8(%rsp), %rsi
     931:      	callq	*%rax
     933:      	testq	%rax, %rax
     936:      	je	0x941 <tail_icmp6_send_time_exceeded+0x681>
     938:      	incq	(%rax)
     93b:      	addq	%r14, 0x8(%rax)
     93f:      	jmp	0x969 <tail_icmp6_send_time_exceeded+0x6a9>
     941:      	movq	$0x1, 0x30(%rsp)
     94a:      	movq	%r14, 0x38(%rsp)
     94f:      	movl	$0x2, %eax
     954:      	movq	(%rip), %rdi            # 0x95b <tail_icmp6_send_time_exceeded+0x69b>
     95b:      	leaq	0x8(%rsp), %rsi
     960:      	leaq	0x30(%rsp), %rdx
     965:      	xorl	%ecx, %ecx
     967:      	callq	*%rax
     969:      	movl	$0xc, %eax
     96e:      	movq	(%rip), %rsi            # 0x975 <tail_icmp6_send_time_exceeded+0x6b5>
     975:      	movq	%rbx, %rdi
     978:      	movl	$0x1, %edx
     97d:      	callq	*%rax
     97f:      	movl	$0x2, %ebp
     984:      	movl	%ebp, %eax
     986:      	addq	$0xc8, %rsp
     98d:      	popq	%rbx
     98e:      	popq	%r12
     990:      	popq	%r13
     992:      	popq	%r14
     994:      	popq	%r15
     996:      	popq	%rbp
     997:      	retq
     998:      	movl	$0xffffff66, %ebp       # imm = 0xFFFFFF66
     99d:      	jmp	0x8dd <tail_icmp6_send_time_exceeded+0x61d>
     9a2:      	xorl	%edi, %edi
     9a4:      	movl	$0x17, %eax
     9a9:      	xorl	%esi, %esi
     9ab:      	callq	*%rax
     9ad:      	movl	%eax, %ebp
     9af:      	testl	%eax, %eax
     9b1:      	js	0x8dd <tail_icmp6_send_time_exceeded+0x61d>
     9b7:      	cmpl	$0x2, %ebp
     9ba:      	jne	0x984 <tail_icmp6_send_time_exceeded+0x6c4>
     9bc:      	jmp	0x8dd <tail_icmp6_send_time_exceeded+0x61d>

Disassembly of section tc/entry:

0000000000000000 <cil_from_overlay>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%rbx
       6:      	subq	$0x28, %rsp
       a:      	movq	%rdi, %rbx
       d:      	movl	$0x0, 0x30(%rdi)
      14:      	movl	$0x0, 0x34(%rdi)
      1b:      	movl	$0x0, 0x38(%rdi)
      22:      	movl	$0x0, 0x3c(%rdi)
      29:      	movl	$0x0, 0x40(%rdi)
      30:      	movq	(%rip), %rax            # 0x37 <cil_from_overlay+0x37>
      37:      	cmpb	$0x0, (%rax)
      3a:      	je	0x7e <cil_from_overlay+0x7e>
      3c:      	movzbl	(%rax), %ebp
      3f:      	movq	0x50(%rbx), %rcx
      43:      	movq	0xd0(%rbx), %rdx
      4a:      	leaq	0xe(%rdx), %rax
      4e:      	cmpq	%rcx, %rax
      51:      	jbe	0xf0 <cil_from_overlay+0xf0>
      57:      	movl	$0x0, 0x18(%rsp)
      5f:      	movl	$0x1, %eax
      64:      	movq	(%rip), %rdi            # 0x6b <cil_from_overlay+0x6b>
      6b:      	leaq	0x18(%rsp), %rsi
      70:      	callq	*%rax
      72:      	testq	%rax, %rax
      75:      	je	0x7e <cil_from_overlay+0x7e>
      77:      	movq	$0x0, (%rax)
      7e:      	movq	0xd0(%rbx), %rcx
      85:      	leaq	0xe(%rcx), %rdx
      89:      	xorl	%eax, %eax
      8b:      	cmpq	0x50(%rbx), %rdx
      8f:      	ja	0x2d4 <cil_from_overlay+0x2d4>
      95:      	movzwl	0xc(%rcx), %ebp
      99:      	cmpl	$0x6, %ebp
      9c:      	jb	0x2d4 <cil_from_overlay+0x2d4>
      a2:      	movabsq	$0x302300103, %r14      # imm = 0x302300103
      ac:      	movq	(%rip), %rax            # 0xb3 <cil_from_overlay+0xb3>
      b3:      	movl	(%rax), %eax
      b5:      	movl	0x70(%rbx), %r15d
      b9:      	movq	%r14, 0x10(%rsp)
      be:      	movl	$0x1, %eax
      c3:      	movq	(%rip), %rdi            # 0xca <cil_from_overlay+0xca>
      ca:      	leaq	0x10(%rsp), %rsi
      cf:      	callq	*%rax
      d1:      	testq	%rax, %rax
      d4:      	je	0x149 <cil_from_overlay+0x149>
      d6:      	incq	(%rax)
      d9:      	addq	%r15, 0x8(%rax)
      dd:      	xorl	%eax, %eax
      df:      	cmpl	$0xdd86, %ebp           # imm = 0xDD86
      e5:      	jne	0x17b <cil_from_overlay+0x17b>
      eb:      	jmp	0x184 <cil_from_overlay+0x184>
      f0:      	cmpw	$0x8, 0xc(%rdx)
      f5:      	jne	0x57 <cil_from_overlay+0x57>
      fb:      	addq	$0x22, %rdx
      ff:      	cmpq	%rcx, %rdx
     102:      	ja	0x57 <cil_from_overlay+0x57>
     108:      	movzbl	(%rax), %r15d
     10c:      	andl	$0xf, %r15d
     110:      	cmpb	$0x6, %r15b
     114:      	jae	0x1d3 <cil_from_overlay+0x1d3>
     11a:      	xorl	%r14d, %r14d
     11d:      	movl	$0x0, 0x18(%rsp)
     125:      	movl	$0x1, %eax
     12a:      	movq	(%rip), %rdi            # 0x131 <cil_from_overlay+0x131>
     131:      	leaq	0x18(%rsp), %rsi
     136:      	callq	*%rax
     138:      	testq	%rax, %rax
     13b:      	je	0x7e <cil_from_overlay+0x7e>
     141:      	movq	%r14, (%rax)
     144:      	jmp	0x7e <cil_from_overlay+0x7e>
     149:      	movq	$0x1, 0x18(%rsp)
     152:      	movq	%r15, 0x20(%rsp)
     157:      	movl	$0x2, %eax
     15c:      	movq	(%rip), %rdi            # 0x163 <cil_from_overlay+0x163>
     163:      	leaq	0x10(%rsp), %rsi
     168:      	leaq	0x18(%rsp), %rdx
     16d:      	xorl	%ecx, %ecx
     16f:      	callq	*%rax
     171:      	xorl	%eax, %eax
     173:      	cmpl	$0xdd86, %ebp           # imm = 0xDD86
     179:      	je	0x184 <cil_from_overlay+0x184>
     17b:      	cmpl	$0x8, %ebp
     17e:      	jne	0x2d4 <cil_from_overlay+0x2d4>
     184:      	movq	$0x0, 0x30(%rbx)
     18c:      	movq	$0x8b, 0x38(%rbx)
     194:      	movl	$0x2500302, 0x40(%rbx)  # imm = 0x2500302
     19b:      	movl	0x70(%rbx), %r15d
     19f:      	addq	$0x200088, %r14         # imm = 0x200088
     1a6:      	movq	%r14, 0x10(%rsp)
     1ab:      	movl	$0x1, %eax
     1b0:      	movq	(%rip), %rdi            # 0x1b7 <cil_from_overlay+0x1b7>
     1b7:      	leaq	0x10(%rsp), %rsi
     1bc:      	callq	*%rax
     1be:      	testq	%rax, %rax
     1c1:      	je	0x291 <cil_from_overlay+0x291>
     1c7:      	incq	(%rax)
     1ca:      	addq	%r15, 0x8(%rax)
     1ce:      	jmp	0x2b9 <cil_from_overlay+0x2b9>
     1d3:      	movl	$0x1a, %eax
     1d8:      	leaq	0x10(%rsp), %rdx
     1dd:      	movq	%rbx, %rdi
     1e0:      	movl	$0x22, %esi
     1e5:      	movl	$0x1, %ecx
     1ea:      	callq	*%rax
     1ec:      	testl	%eax, %eax
     1ee:      	js	0x57 <cil_from_overlay+0x57>
     1f4:      	movzbl	0x10(%rsp), %eax
     1f9:      	testl	%eax, %eax
     1fb:      	je	0x11a <cil_from_overlay+0x11a>
     201:      	movl	$0x23, %r14d
     207:      	cmpl	$0x1, %eax
     20a:      	je	0x2e9 <cil_from_overlay+0x2e9>
     210:      	movl	$0x1a, %eax
     215:      	leaq	0xf(%rsp), %rdx
     21a:      	movq	%rbx, %rdi
     21d:      	movl	$0x23, %esi
     222:      	movl	$0x1, %ecx
     227:      	callq	*%rax
     229:      	testl	%eax, %eax
     22b:      	js	0x57 <cil_from_overlay+0x57>
     231:      	movl	$0x22, %r14d
     237:      	cmpb	%bpl, 0x10(%rsp)
     23c:      	jne	0x2df <cil_from_overlay+0x2df>
     242:      	movzbl	0xf(%rsp), %eax
     247:      	cmpl	$0xa, %eax
     24a:      	je	0x3ed <cil_from_overlay+0x3ed>
     250:      	cmpl	$0x6, %eax
     253:      	je	0x3c1 <cil_from_overlay+0x3c1>
     259:      	cmpl	$0x4, %eax
     25c:      	jne	0x57 <cil_from_overlay+0x57>
     262:      	movl	$0x1a, %eax
     267:      	addl	$0x2, %r14d
     26b:      	leaq	0x18(%rsp), %rdx
     270:      	movq	%rbx, %rdi
     273:      	movl	%r14d, %esi
     276:      	movl	$0x2, %ecx
     27b:      	callq	*%rax
     27d:      	xorl	%r14d, %r14d
     280:      	testl	%eax, %eax
     282:      	movbew	0x18(%rsp), %cx
     289:      	movzwl	%cx, %ecx
     28c:      	jmp	0x414 <cil_from_overlay+0x414>
     291:      	movq	$0x1, 0x18(%rsp)
     29a:      	movq	%r15, 0x20(%rsp)
     29f:      	movl	$0x2, %eax
     2a4:      	movq	(%rip), %rdi            # 0x2ab <cil_from_overlay+0x2ab>
     2ab:      	leaq	0x10(%rsp), %rsi
     2b0:      	leaq	0x18(%rsp), %rdx
     2b5:      	xorl	%ecx, %ecx
     2b7:      	callq	*%rax
     2b9:      	movl	$0xc, %eax
     2be:      	movq	(%rip), %rsi            # 0x2c5 <cil_from_overlay+0x2c5>
     2c5:      	movq	%rbx, %rdi
     2c8:      	movl	$0x1, %edx
     2cd:      	callq	*%rax
     2cf:      	movl	$0x2, %eax
     2d4:      	addq	$0x28, %rsp
     2d8:      	popq	%rbx
     2d9:      	popq	%r14
     2db:      	popq	%r15
     2dd:      	popq	%rbp
     2de:      	retq
     2df:      	movzbl	0xf(%rsp), %r14d
     2e5:      	addl	$0x22, %r14d
     2e9:      	leal	0x22(,%r15,4), %r15d
     2f1:      	cmpl	%r15d, %r14d
     2f4:      	jae	0x11a <cil_from_overlay+0x11a>
     2fa:      	movl	$0x1a, %eax
     2ff:      	leaq	0x10(%rsp), %rdx
     304:      	movq	%rbx, %rdi
     307:      	movl	%r14d, %esi
     30a:      	movl	$0x1, %ecx
     30f:      	callq	*%rax
     311:      	testl	%eax, %eax
     313:      	js	0x57 <cil_from_overlay+0x57>
     319:      	movzbl	0x10(%rsp), %eax
     31e:      	testl	%eax, %eax
     320:      	je	0x11a <cil_from_overlay+0x11a>
     326:      	cmpl	$0x1, %eax
     329:      	je	0x35b <cil_from_overlay+0x35b>
     32b:      	movl	$0x1a, %eax
     330:      	leal	0x1(%r14), %esi
     334:      	leaq	0xf(%rsp), %rdx
     339:      	movq	%rbx, %rdi
     33c:      	movl	$0x1, %ecx
     341:      	callq	*%rax
     343:      	testl	%eax, %eax
     345:      	js	0x57 <cil_from_overlay+0x57>
     34b:      	cmpb	%bpl, 0x10(%rsp)
     350:      	je	0x242 <cil_from_overlay+0x242>
     356:      	movzbl	0xf(%rsp), %eax
     35b:      	addl	%eax, %r14d
     35e:      	cmpl	%r15d, %r14d
     361:      	jae	0x11a <cil_from_overlay+0x11a>
     367:      	movl	$0x1a, %eax
     36c:      	leaq	0x10(%rsp), %rdx
     371:      	movq	%rbx, %rdi
     374:      	movl	%r14d, %esi
     377:      	movl	$0x1, %ecx
     37c:      	callq	*%rax
     37e:      	testl	%eax, %eax
     380:      	js	0x57 <cil_from_overlay+0x57>
     386:      	cmpb	$0x2, 0x10(%rsp)
     38b:      	jb	0x11a <cil_from_overlay+0x11a>
     391:      	movl	$0x1a, %eax
     396:      	leal	0x1(%r14), %esi
     39a:      	leaq	0xf(%rsp), %rdx
     39f:      	movq	%rbx, %rdi
     3a2:      	movl	$0x1, %ecx
     3a7:      	callq	*%rax
     3a9:      	testl	%eax, %eax
     3ab:      	js	0x57 <cil_from_overlay+0x57>
     3b1:      	cmpb	%bpl, 0x10(%rsp)
     3b6:      	jne	0x11a <cil_from_overlay+0x11a>
     3bc:      	jmp	0x242 <cil_from_overlay+0x242>
     3c1:      	movl	$0x1a, %eax
     3c6:      	addl	$0x2, %r14d
     3ca:      	leaq	0x18(%rsp), %rdx
     3cf:      	movq	%rbx, %rdi
     3d2:      	movl	%r14d, %esi
     3d5:      	movl	$0x4, %ecx
     3da:      	callq	*%rax
     3dc:      	xorl	%ecx, %ecx
     3de:      	testl	%eax, %eax
     3e0:      	movbel	0x18(%rsp), %r14d
     3e7:      	cmovsl	%ecx, %r14d
     3eb:      	jmp	0x418 <cil_from_overlay+0x418>
     3ed:      	movl	$0x1a, %eax
     3f2:      	addl	$0x2, %r14d
     3f6:      	leaq	0x18(%rsp), %rdx
     3fb:      	movq	%rbx, %rdi
     3fe:      	movl	%r14d, %esi
     401:      	movl	$0x8, %ecx
     406:      	callq	*%rax
     408:      	xorl	%r14d, %r14d
     40b:      	testl	%eax, %eax
     40d:      	movbeq	0x18(%rsp), %rcx
     414:      	cmovnsq	%rcx, %r14
     418:      	testl	%eax, %eax
     41a:      	jns	0x11d <cil_from_overlay+0x11d>
     420:      	jmp	0x57 <cil_from_overlay+0x57>
     425:      	nopw	%cs:(%rax,%rax)

0000000000000430 <cil_to_overlay>:
     430:      	pushq	%rbp
     431:      	pushq	%r15
     433:      	pushq	%r14
     435:      	pushq	%rbx
     436:      	subq	$0x48, %rsp
     43a:      	movq	%rdi, %rbx
     43d:      	movl	$0x0, 0x40(%rsp)
     445:      	movq	$0x0, 0x38(%rsp)
     44e:      	movq	$0x0, 0x30(%rsp)
     457:      	movq	$0x0, 0x28(%rsp)
     460:      	movq	$0x0, 0x20(%rsp)
     469:      	movq	$0x0, 0x18(%rsp)
     472:      	movl	$0x0, 0x30(%rdi)
     479:      	movl	$0x0, 0x34(%rdi)
     480:      	movl	$0x0, 0x38(%rdi)
     487:      	movl	$0x0, 0x3c(%rdi)
     48e:      	movl	$0x0, 0x40(%rdi)
     495:      	movq	(%rip), %rax            # 0x49c <cil_to_overlay+0x6c>
     49c:      	cmpb	$0x0, (%rax)
     49f:      	je	0x4e3 <cil_to_overlay+0xb3>
     4a1:      	movzbl	(%rax), %ebp
     4a4:      	movq	0x50(%rbx), %rcx
     4a8:      	movq	0xd0(%rbx), %rdx
     4af:      	leaq	0xe(%rdx), %rax
     4b3:      	cmpq	%rcx, %rax
     4b6:      	jbe	0x561 <cil_to_overlay+0x131>
     4bc:      	movl	$0x0, 0x10(%rsp)
     4c4:      	movl	$0x1, %eax
     4c9:      	movq	(%rip), %rdi            # 0x4d0 <cil_to_overlay+0xa0>
     4d0:      	leaq	0x10(%rsp), %rsi
     4d5:      	callq	*%rax
     4d7:      	testq	%rax, %rax
     4da:      	je	0x4e3 <cil_to_overlay+0xb3>
     4dc:      	movq	$0x0, (%rax)
     4e3:      	movl	$0x14, %eax
     4e8:      	leaq	0x18(%rsp), %rsi
     4ed:      	movq	%rbx, %rdi
     4f0:      	movl	$0x1c, %edx
     4f5:      	xorl	%ecx, %ecx
     4f7:      	callq	*%rax
     4f9:      	movl	$0x0, %ecx
     4fe:      	testl	%eax, %eax
     500:      	jne	0x506 <cil_to_overlay+0xd6>
     502:      	movl	0x18(%rsp), %ecx
     506:      	movq	(%rip), %rax            # 0x50d <cil_to_overlay+0xdd>
     50d:      	movl	(%rax), %edx
     50f:      	movb	$0x18, %sil
     512:      	movb	$0x18, %dil
     515:      	subb	%dl, %dil
     518:      	shrxl	%edi, %ecx, %edx
     51d:      	movl	(%rax), %edi
     51f:      	bzhil	%edi, %edx, %edx
     524:      	movzbl	%dl, %edi
     527:      	andl	$0x7fffff00, %edx       # imm = 0x7FFFFF00
     52d:      	movl	(%rax), %r8d
     530:      	negb	%r8b
     533:      	shlxl	%r8d, %edx, %edx
     538:      	orl	%edi, %edx
     53a:      	movl	(%rax), %eax
     53c:      	subb	%al, %sil
     53f:      	bzhil	%esi, %ecx, %eax
     544:      	shll	$0x10, %eax
     547:      	orl	%edx, %eax
     549:      	orl	$0x400, %eax            # imm = 0x400
     54e:      	movl	%eax, 0xa8(%rbx)
     554:      	xorl	%eax, %eax
     556:      	addq	$0x48, %rsp
     55a:      	popq	%rbx
     55b:      	popq	%r14
     55d:      	popq	%r15
     55f:      	popq	%rbp
     560:      	retq
     561:      	cmpw	$0x8, 0xc(%rdx)
     566:      	jne	0x4bc <cil_to_overlay+0x8c>
     56c:      	addq	$0x22, %rdx
     570:      	cmpq	%rcx, %rdx
     573:      	ja	0x4bc <cil_to_overlay+0x8c>
     579:      	movzbl	(%rax), %r15d
     57d:      	andl	$0xf, %r15d
     581:      	cmpb	$0x6, %r15b
     585:      	jae	0x5b6 <cil_to_overlay+0x186>
     587:      	xorl	%r14d, %r14d
     58a:      	movl	$0x0, 0x10(%rsp)
     592:      	movl	$0x1, %eax
     597:      	movq	(%rip), %rdi            # 0x59e <cil_to_overlay+0x16e>
     59e:      	leaq	0x10(%rsp), %rsi
     5a3:      	callq	*%rax
     5a5:      	testq	%rax, %rax
     5a8:      	je	0x4e3 <cil_to_overlay+0xb3>
     5ae:      	movq	%r14, (%rax)
     5b1:      	jmp	0x4e3 <cil_to_overlay+0xb3>
     5b6:      	movl	$0x1a, %eax
     5bb:      	leaq	0xe(%rsp), %rdx
     5c0:      	movq	%rbx, %rdi
     5c3:      	movl	$0x22, %esi
     5c8:      	movl	$0x1, %ecx
     5cd:      	callq	*%rax
     5cf:      	testl	%eax, %eax
     5d1:      	js	0x4bc <cil_to_overlay+0x8c>
     5d7:      	movzbl	0xe(%rsp), %eax
     5dc:      	testl	%eax, %eax
     5de:      	je	0x587 <cil_to_overlay+0x157>
     5e0:      	movl	$0x23, %r14d
     5e6:      	cmpl	$0x1, %eax
     5e9:      	je	0x676 <cil_to_overlay+0x246>
     5ef:      	movl	$0x1a, %eax
     5f4:      	leaq	0xf(%rsp), %rdx
     5f9:      	movq	%rbx, %rdi
     5fc:      	movl	$0x23, %esi
     601:      	movl	$0x1, %ecx
     606:      	callq	*%rax
     608:      	testl	%eax, %eax
     60a:      	js	0x4bc <cil_to_overlay+0x8c>
     610:      	movl	$0x22, %r14d
     616:      	cmpb	%bpl, 0xe(%rsp)
     61b:      	jne	0x66c <cil_to_overlay+0x23c>
     61d:      	movzbl	0xf(%rsp), %eax
     622:      	cmpl	$0xa, %eax
     625:      	je	0x77a <cil_to_overlay+0x34a>
     62b:      	cmpl	$0x6, %eax
     62e:      	je	0x74e <cil_to_overlay+0x31e>
     634:      	cmpl	$0x4, %eax
     637:      	jne	0x4bc <cil_to_overlay+0x8c>
     63d:      	movl	$0x1a, %eax
     642:      	addl	$0x2, %r14d
     646:      	leaq	0x10(%rsp), %rdx
     64b:      	movq	%rbx, %rdi
     64e:      	movl	%r14d, %esi
     651:      	movl	$0x2, %ecx
     656:      	callq	*%rax
     658:      	xorl	%r14d, %r14d
     65b:      	testl	%eax, %eax
     65d:      	movbew	0x10(%rsp), %cx
     664:      	movzwl	%cx, %ecx
     667:      	jmp	0x7a1 <cil_to_overlay+0x371>
     66c:      	movzbl	0xf(%rsp), %r14d
     672:      	addl	$0x22, %r14d
     676:      	leal	0x22(,%r15,4), %r15d
     67e:      	cmpl	%r15d, %r14d
     681:      	jae	0x587 <cil_to_overlay+0x157>
     687:      	movl	$0x1a, %eax
     68c:      	leaq	0xe(%rsp), %rdx
     691:      	movq	%rbx, %rdi
     694:      	movl	%r14d, %esi
     697:      	movl	$0x1, %ecx
     69c:      	callq	*%rax
     69e:      	testl	%eax, %eax
     6a0:      	js	0x4bc <cil_to_overlay+0x8c>
     6a6:      	movzbl	0xe(%rsp), %eax
     6ab:      	testl	%eax, %eax
     6ad:      	je	0x587 <cil_to_overlay+0x157>
     6b3:      	cmpl	$0x1, %eax
     6b6:      	je	0x6e8 <cil_to_overlay+0x2b8>
     6b8:      	movl	$0x1a, %eax
     6bd:      	leal	0x1(%r14), %esi
     6c1:      	leaq	0xf(%rsp), %rdx
     6c6:      	movq	%rbx, %rdi
     6c9:      	movl	$0x1, %ecx
     6ce:      	callq	*%rax
     6d0:      	testl	%eax, %eax
     6d2:      	js	0x4bc <cil_to_overlay+0x8c>
     6d8:      	cmpb	%bpl, 0xe(%rsp)
     6dd:      	je	0x61d <cil_to_overlay+0x1ed>
     6e3:      	movzbl	0xf(%rsp), %eax
     6e8:      	addl	%eax, %r14d
     6eb:      	cmpl	%r15d, %r14d
     6ee:      	jae	0x587 <cil_to_overlay+0x157>
     6f4:      	movl	$0x1a, %eax
     6f9:      	leaq	0xe(%rsp), %rdx
     6fe:      	movq	%rbx, %rdi
     701:      	movl	%r14d, %esi
     704:      	movl	$0x1, %ecx
     709:      	callq	*%rax
     70b:      	testl	%eax, %eax
     70d:      	js	0x4bc <cil_to_overlay+0x8c>
     713:      	cmpb	$0x2, 0xe(%rsp)
     718:      	jb	0x587 <cil_to_overlay+0x157>
     71e:      	movl	$0x1a, %eax
     723:      	leal	0x1(%r14), %esi
     727:      	leaq	0xf(%rsp), %rdx
     72c:      	movq	%rbx, %rdi
     72f:      	movl	$0x1, %ecx
     734:      	callq	*%rax
     736:      	testl	%eax, %eax
     738:      	js	0x4bc <cil_to_overlay+0x8c>
     73e:      	cmpb	%bpl, 0xe(%rsp)
     743:      	jne	0x587 <cil_to_overlay+0x157>
     749:      	jmp	0x61d <cil_to_overlay+0x1ed>
     74e:      	movl	$0x1a, %eax
     753:      	addl	$0x2, %r14d
     757:      	leaq	0x10(%rsp), %rdx
     75c:      	movq	%rbx, %rdi
     75f:      	movl	%r14d, %esi
     762:      	movl	$0x4, %ecx
     767:      	callq	*%rax
     769:      	xorl	%ecx, %ecx
     76b:      	testl	%eax, %eax
     76d:      	movbel	0x10(%rsp), %r14d
     774:      	cmovsl	%ecx, %r14d
     778:      	jmp	0x7a5 <cil_to_overlay+0x375>
     77a:      	movl	$0x1a, %eax
     77f:      	addl	$0x2, %r14d
     783:      	leaq	0x10(%rsp), %rdx
     788:      	movq	%rbx, %rdi
     78b:      	movl	%r14d, %esi
     78e:      	movl	$0x8, %ecx
     793:      	callq	*%rax
     795:      	xorl	%r14d, %r14d
     798:      	testl	%eax, %eax
     79a:      	movbeq	0x10(%rsp), %rcx
     7a1:      	cmovnsq	%rcx, %r14
     7a5:      	testl	%eax, %eax
     7a7:      	jns	0x58a <cil_to_overlay+0x15a>
     7ad:      	jmp	0x4bc <cil_to_overlay+0x8c>
