
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/bcc/biosnoop.native.o:	file format elf64-x86-64

Disassembly of section kprobe/blk_account_io_merge_bio:

0000000000000000 <blk_account_io_merge_bio>:
       0:      	pushq	%rbx
       1:      	subq	$0x20, %rsp
       5:      	movq	0x70(%rdi), %rbx
       9:      	movq	(%rip), %rax            # 0x10 <blk_account_io_merge_bio+0x10>
      10:      	cmpb	$0x0, (%rax)
      13:      	je	0x28 <blk_account_io_merge_bio+0x28>
      15:      	movq	(%rip), %rdi            # 0x1c <blk_account_io_merge_bio+0x1c>
      1c:      	xorl	%esi, %esi
      1e:      	callq	0x23 <blk_account_io_merge_bio+0x23>
      23:      	testq	%rax, %rax
      26:      	je	0x71 <blk_account_io_merge_bio+0x71>
      28:      	movq	%rbx, (%rsp)
      2c:      	callq	0x31 <blk_account_io_merge_bio+0x31>
      31:      	movq	$0x0, 0x10(%rsp)
      3a:      	movq	$0x0, 0x8(%rsp)
      43:      	shrq	$0x20, %rax
      47:      	movl	%eax, 0x18(%rsp)
      4b:      	leaq	0x8(%rsp), %rbx
      50:      	movq	%rbx, %rdi
      53:      	movl	$0x8, %esi
      58:      	callq	0x5d <blk_account_io_merge_bio+0x5d>
      5d:      	movq	(%rip), %rdi            # 0x64 <blk_account_io_merge_bio+0x64>
      64:      	movq	%rsp, %rsi
      67:      	movq	%rbx, %rdx
      6a:      	xorl	%ecx, %ecx
      6c:      	callq	0x71 <blk_account_io_merge_bio+0x71>
      71:      	xorl	%eax, %eax
      73:      	addq	$0x20, %rsp
      77:      	popq	%rbx
      78:      	retq

Disassembly of section tp_btf/block_rq_insert:

0000000000000000 <block_rq_insert>:
       0:      	pushq	%rbp
       1:      	pushq	%r14
       3:      	pushq	%rbx
       4:      	subq	$0x30, %rsp
       8:      	movq	%rdi, %rbx
       b:      	movq	(%rip), %rax            # 0x12 <block_rq_insert+0x12>
      12:      	cmpb	$0x0, (%rax)
      15:      	je	0x2e <block_rq_insert+0x2e>
      17:      	movq	(%rip), %rdi            # 0x1e <block_rq_insert+0x1e>
      1e:      	xorl	%esi, %esi
      20:      	callq	0x25 <block_rq_insert+0x25>
      25:      	testq	%rax, %rax
      28:      	je	0x13d <block_rq_insert+0x13d>
      2e:      	movq	(%rip), %rax            # 0x35 <block_rq_insert+0x35>
      35:      	cmpl	$0x50b00, (%rax)        # imm = 0x50B00
      3b:      	jb	0x42 <block_rq_insert+0x42>
      3d:      	movq	(%rbx), %rax
      40:      	jmp	0x46 <block_rq_insert+0x46>
      42:      	movq	0x8(%rbx), %rax
      46:      	movq	%rax, 0x10(%rsp)
      4b:      	movq	$0x0, 0x28(%rsp)
      54:      	movq	$0x0, 0x20(%rsp)
      5d:      	movq	$0x0, 0x18(%rsp)
      66:      	callq	0x6b <block_rq_insert+0x6b>
      6b:      	movq	%rax, %rbx
      6e:      	movq	(%rip), %rdi            # 0x75 <block_rq_insert+0x75>
      75:      	leaq	0x10(%rsp), %rsi
      7a:      	callq	0x7f <block_rq_insert+0x7f>
      7f:      	testq	%rax, %rax
      82:      	je	0x9a <block_rq_insert+0x9a>
      84:      	movq	%rbx, (%rax)
      87:      	leaq	0x18(%rsp), %rcx
      8c:      	cmpq	%rcx, %rax
      8f:      	jne	0x13d <block_rq_insert+0x13d>
      95:      	jmp	0x125 <block_rq_insert+0x125>
      9a:      	movq	0x10(%rsp), %rdx
      9f:      	addq	$0x8, %rdx
      a3:      	leaq	0x8(%rsp), %rdi
      a8:      	movl	$0x8, %esi
      ad:      	callq	0xb2 <block_rq_insert+0xb2>
      b2:      	movq	0x8(%rsp), %r14
      b7:      	testq	%r14, %r14
      ba:      	je	0x101 <block_rq_insert+0x101>
      bc:      	leaq	0x8(%rsp), %rdi
      c1:      	movl	$0x4, %esi
      c6:      	movq	%r14, %rdx
      c9:      	callq	0xce <block_rq_insert+0xce>
      ce:      	movl	0x8(%rsp), %ebp
      d2:      	shll	$0x14, %ebp
      d5:      	addq	$0x4, %r14
      d9:      	leaq	0x8(%rsp), %rdi
      de:      	movl	$0x4, %esi
      e3:      	movq	%r14, %rdx
      e6:      	callq	0xeb <block_rq_insert+0xeb>
      eb:      	orl	0x8(%rsp), %ebp
      ef:      	movl	%ebp, 0x28(%rsp)
      f3:      	movq	(%rip), %rax            # 0xfa <block_rq_insert+0xfa>
      fa:      	cmpb	$0x0, (%rax)
      fd:      	jne	0x113 <block_rq_insert+0x113>
      ff:      	jmp	0x120 <block_rq_insert+0x120>
     101:      	xorl	%ebp, %ebp
     103:      	movl	%ebp, 0x28(%rsp)
     107:      	movq	(%rip), %rax            # 0x10e <block_rq_insert+0x10e>
     10e:      	cmpb	$0x0, (%rax)
     111:      	je	0x120 <block_rq_insert+0x120>
     113:      	movq	(%rip), %rax            # 0x11a <block_rq_insert+0x11a>
     11a:      	movl	(%rax), %eax
     11c:      	cmpl	%ebp, %eax
     11e:      	jne	0x13d <block_rq_insert+0x13d>
     120:      	movq	%rbx, 0x18(%rsp)
     125:      	movq	(%rip), %rdi            # 0x12c <block_rq_insert+0x12c>
     12c:      	leaq	0x10(%rsp), %rsi
     131:      	leaq	0x18(%rsp), %rdx
     136:      	xorl	%ecx, %ecx
     138:      	callq	0x13d <block_rq_insert+0x13d>
     13d:      	xorl	%eax, %eax
     13f:      	addq	$0x30, %rsp
     143:      	popq	%rbx
     144:      	popq	%r14
     146:      	popq	%rbp
     147:      	retq

Disassembly of section tp_btf/block_rq_issue:

0000000000000000 <block_rq_issue>:
       0:      	pushq	%r15
       2:      	pushq	%r14
       4:      	pushq	%rbx
       5:      	subq	$0x30, %rsp
       9:      	movq	%rdi, %rbx
       c:      	movq	(%rip), %rax            # 0x13 <block_rq_issue+0x13>
      13:      	cmpb	$0x0, (%rax)
      16:      	je	0x2f <block_rq_issue+0x2f>
      18:      	movq	(%rip), %rdi            # 0x1f <block_rq_issue+0x1f>
      1f:      	xorl	%esi, %esi
      21:      	callq	0x26 <block_rq_issue+0x26>
      26:      	testq	%rax, %rax
      29:      	je	0x175 <block_rq_issue+0x175>
      2f:      	movq	(%rip), %rax            # 0x36 <block_rq_issue+0x36>
      36:      	xorl	%ecx, %ecx
      38:      	cmpl	$0x50b00, (%rax)        # imm = 0x50B00
      3e:      	setb	%cl
      41:      	movq	(%rbx,%rcx,8), %rbx
      45:      	movq	%rbx, 0x8(%rsp)
      4a:      	callq	0x4f <block_rq_issue+0x4f>
      4f:      	movq	$0x0, 0x20(%rsp)
      58:      	movq	$0x0, 0x18(%rsp)
      61:      	shrq	$0x20, %rax
      65:      	movl	%eax, 0x28(%rsp)
      69:      	leaq	0x18(%rsp), %r14
      6e:      	movq	%r14, %rdi
      71:      	movl	$0x8, %esi
      76:      	callq	0x7b <block_rq_issue+0x7b>
      7b:      	movq	(%rip), %rdi            # 0x82 <block_rq_issue+0x82>
      82:      	xorl	%r15d, %r15d
      85:      	leaq	0x8(%rsp), %rsi
      8a:      	movq	%r14, %rdx
      8d:      	xorl	%ecx, %ecx
      8f:      	callq	0x94 <block_rq_issue+0x94>
      94:      	movq	%rbx, 0x10(%rsp)
      99:      	movq	$0x0, 0x28(%rsp)
      a2:      	movq	$0x0, 0x20(%rsp)
      ab:      	movq	$0x0, 0x18(%rsp)
      b4:      	callq	0xb9 <block_rq_issue+0xb9>
      b9:      	movq	%rax, %rbx
      bc:      	movq	(%rip), %rdi            # 0xc3 <block_rq_issue+0xc3>
      c3:      	leaq	0x10(%rsp), %rsi
      c8:      	callq	0xcd <block_rq_issue+0xcd>
      cd:      	testq	%rax, %rax
      d0:      	je	0xe1 <block_rq_issue+0xe1>
      d2:      	movq	%rbx, 0x8(%rax)
      d6:      	cmpq	%r14, %rax
      d9:      	jne	0x175 <block_rq_issue+0x175>
      df:      	jmp	0x15d <block_rq_issue+0x15d>
      e1:      	movq	0x10(%rsp), %rdx
      e6:      	addq	$0x8, %rdx
      ea:      	leaq	0x8(%rsp), %rdi
      ef:      	movl	$0x8, %esi
      f4:      	callq	0xf9 <block_rq_issue+0xf9>
      f9:      	movq	0x8(%rsp), %r14
      fe:      	testq	%r14, %r14
     101:      	je	0x139 <block_rq_issue+0x139>
     103:      	leaq	0x8(%rsp), %rdi
     108:      	movl	$0x4, %esi
     10d:      	movq	%r14, %rdx
     110:      	callq	0x115 <block_rq_issue+0x115>
     115:      	movl	0x8(%rsp), %r15d
     11a:      	shll	$0x14, %r15d
     11e:      	addq	$0x4, %r14
     122:      	leaq	0x8(%rsp), %rdi
     127:      	movl	$0x4, %esi
     12c:      	movq	%r14, %rdx
     12f:      	callq	0x134 <block_rq_issue+0x134>
     134:      	orl	0x8(%rsp), %r15d
     139:      	movl	%r15d, 0x28(%rsp)
     13e:      	movq	(%rip), %rax            # 0x145 <block_rq_issue+0x145>
     145:      	cmpb	$0x0, (%rax)
     148:      	je	0x158 <block_rq_issue+0x158>
     14a:      	movq	(%rip), %rax            # 0x151 <block_rq_issue+0x151>
     151:      	movl	(%rax), %eax
     153:      	cmpl	%r15d, %eax
     156:      	jne	0x175 <block_rq_issue+0x175>
     158:      	movq	%rbx, 0x20(%rsp)
     15d:      	movq	(%rip), %rdi            # 0x164 <block_rq_issue+0x164>
     164:      	leaq	0x10(%rsp), %rsi
     169:      	leaq	0x18(%rsp), %rdx
     16e:      	xorl	%ecx, %ecx
     170:      	callq	0x175 <block_rq_issue+0x175>
     175:      	xorl	%eax, %eax
     177:      	addq	$0x30, %rsp
     17b:      	popq	%rbx
     17c:      	popq	%r14
     17e:      	popq	%r15
     180:      	retq

Disassembly of section tp_btf/block_rq_complete:

0000000000000000 <block_rq_complete>:
       0:      	pushq	%r15
       2:      	pushq	%r14
       4:      	pushq	%r12
       6:      	pushq	%rbx
       7:      	subq	$0x58, %rsp
       b:      	movq	%rdi, %rbx
       e:      	movq	(%rdi), %rax
      11:      	movq	%rax, (%rsp)
      15:      	movq	(%rip), %rax            # 0x1c <block_rq_complete+0x1c>
      1c:      	cmpb	$0x0, (%rax)
      1f:      	je	0x38 <block_rq_complete+0x38>
      21:      	movq	(%rip), %rdi            # 0x28 <block_rq_complete+0x28>
      28:      	xorl	%esi, %esi
      2a:      	callq	0x2f <block_rq_complete+0x2f>
      2f:      	testq	%rax, %rax
      32:      	je	0x1bd <block_rq_complete+0x1bd>
      38:      	callq	0x3d <block_rq_complete+0x3d>
      3d:      	movq	%rax, %r14
      40:      	movq	$0x0, 0x40(%rsp)
      49:      	movq	$0x0, 0x38(%rsp)
      52:      	movq	$0x0, 0x30(%rsp)
      5b:      	movq	$0x0, 0x28(%rsp)
      64:      	movq	$0x0, 0x20(%rsp)
      6d:      	movq	$0x0, 0x18(%rsp)
      76:      	movq	$0x0, 0x10(%rsp)
      7f:      	movq	$0x0, 0x8(%rsp)
      88:      	movq	(%rip), %rdi            # 0x8f <block_rq_complete+0x8f>
      8f:      	movq	%rsp, %rsi
      92:      	callq	0x97 <block_rq_complete+0x97>
      97:      	testq	%rax, %rax
      9a:      	je	0x1bd <block_rq_complete+0x1bd>
      a0:      	movq	%rax, %r15
      a3:      	movq	%r14, %r12
      a6:      	subq	0x8(%rax), %r12
      aa:      	js	0x19c <block_rq_complete+0x19c>
      b0:      	movq	(%rip), %rdi            # 0xb7 <block_rq_complete+0xb7>
      b7:      	movq	%rsp, %rsi
      ba:      	callq	0xbf <block_rq_complete+0xbf>
      bf:      	testq	%rax, %rax
      c2:      	je	0xef <block_rq_complete+0xef>
      c4:      	movq	(%rax), %rcx
      c7:      	movq	0x8(%rax), %rdx
      cb:      	movq	%rdx, 0x10(%rsp)
      d0:      	movq	%rcx, 0x8(%rsp)
      d5:      	movl	0x10(%rax), %eax
      d8:      	movl	%eax, 0x3c(%rsp)
      dc:      	movq	%r12, 0x18(%rsp)
      e1:      	movq	(%rip), %rax            # 0xe8 <block_rq_complete+0xe8>
      e8:      	cmpb	$0x0, (%rax)
      eb:      	jne	0x105 <block_rq_complete+0x105>
      ed:      	jmp	0x155 <block_rq_complete+0x155>
      ef:      	movb	$0x3f, 0x8(%rsp)
      f4:      	movq	%r12, 0x18(%rsp)
      f9:      	movq	(%rip), %rax            # 0x100 <block_rq_complete+0x100>
     100:      	cmpb	$0x0, (%rax)
     103:      	je	0x155 <block_rq_complete+0x155>
     105:      	movq	(%rsp), %rdx
     109:      	leaq	0x48(%rsp), %rdi
     10e:      	movl	$0x8, %esi
     113:      	callq	0x118 <block_rq_complete+0x118>
     118:      	movq	0x48(%rsp), %rdx
     11d:      	addq	$0x8, %rdx
     121:      	leaq	0x50(%rsp), %rdi
     126:      	movl	$0x8, %esi
     12b:      	callq	0x130 <block_rq_complete+0x130>
     130:      	cmpq	$0x0, 0x50(%rsp)
     136:      	je	0x155 <block_rq_complete+0x155>
     138:      	movq	(%r15), %rcx
     13b:      	testq	%rcx, %rcx
     13e:      	je	0x149 <block_rq_complete+0x149>
     140:      	movq	0x8(%r15), %rax
     144:      	subq	%rcx, %rax
     147:      	jmp	0x150 <block_rq_complete+0x150>
     149:      	movq	$-0x1, %rax
     150:      	movq	%rax, 0x20(%rsp)
     155:      	movq	%r14, 0x28(%rsp)
     15a:      	movq	(%rsp), %rax
     15e:      	movq	0x30(%rax), %rcx
     162:      	movq	%rcx, 0x30(%rsp)
     167:      	movl	0x2c(%rax), %ecx
     16a:      	movl	%ecx, 0x38(%rsp)
     16e:      	movl	0x18(%rax), %eax
     171:      	movl	%eax, 0x40(%rsp)
     175:      	movl	0x10(%r15), %eax
     179:      	movl	%eax, 0x44(%rsp)
     17d:      	movq	(%rip), %rsi            # 0x184 <block_rq_complete+0x184>
     184:      	leaq	0x8(%rsp), %rcx
     189:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     18e:      	movl	$0x40, %r8d
     194:      	movq	%rbx, %rdi
     197:      	callq	0x19c <block_rq_complete+0x19c>
     19c:      	movq	(%rip), %rdi            # 0x1a3 <block_rq_complete+0x1a3>
     1a3:      	movq	%rsp, %rbx
     1a6:      	movq	%rbx, %rsi
     1a9:      	callq	0x1ae <block_rq_complete+0x1ae>
     1ae:      	movq	(%rip), %rdi            # 0x1b5 <block_rq_complete+0x1b5>
     1b5:      	movq	%rbx, %rsi
     1b8:      	callq	0x1bd <block_rq_complete+0x1bd>
     1bd:      	xorl	%eax, %eax
     1bf:      	addq	$0x58, %rsp
     1c3:      	popq	%rbx
     1c4:      	popq	%r12
     1c6:      	popq	%r14
     1c8:      	popq	%r15
     1ca:      	retq
