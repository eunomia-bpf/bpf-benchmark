
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_multi_retkprobe_v511.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <native_bpf_strncasestr>:
       0:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
       5:      	testq	%rdx, %rdx
       8:      	je	0x74 <native_bpf_strncasestr+0x74>
       a:      	pushq	%rbx
       b:      	xorl	%ecx, %ecx
       d:      	jmp	0x1b <native_bpf_strncasestr+0x1b>
       f:      	nop
      10:      	incq	%rcx
      13:      	incq	%rdi
      16:      	cmpq	%rdx, %rcx
      19:      	je	0x73 <native_bpf_strncasestr+0x73>
      1b:      	xorl	%r8d, %r8d
      1e:      	nop
      20:      	leaq	(%rcx,%r8), %r9
      24:      	cmpq	%rdx, %r9
      27:      	jae	0x10 <native_bpf_strncasestr+0x10>
      29:      	movsbl	(%rsi,%r8), %r9d
      2e:      	testl	%r9d, %r9d
      31:      	je	0x71 <native_bpf_strncasestr+0x71>
      33:      	movsbl	(%rdi,%r8), %r10d
      38:      	leal	-0x41(%r10), %r11d
      3c:      	movl	%r10d, %ebx
      3f:      	orl	$0x20, %ebx
      42:      	cmpl	$0x1a, %r11d
      46:      	cmovael	%r10d, %ebx
      4a:      	leal	-0x41(%r9), %r10d
      4e:      	movl	%r9d, %r11d
      51:      	orl	$0x20, %r11d
      55:      	cmpl	$0x1a, %r10d
      59:      	cmovael	%r9d, %r11d
      5d:      	cmpl	%r11d, %ebx
      60:      	jne	0x10 <native_bpf_strncasestr+0x10>
      62:      	leaq	0x1(%r8), %r9
      66:      	cmpq	$0x63, %r8
      6a:      	movq	%r9, %r8
      6d:      	jb	0x20 <native_bpf_strncasestr+0x20>
      6f:      	jmp	0x10 <native_bpf_strncasestr+0x10>
      71:      	movl	%ecx, %eax
      73:      	popq	%rbx
      74:      	retq

Disassembly of section kprobe.multi:

0000000000000000 <generic_retkprobe_filter_arg>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0xb8, %rsp
      11:      	movq	%rdi, %r13
      14:      	movl	$0x0, 0x94(%rsp)
      1f:      	movq	(%rip), %rdi            # 0x26 <generic_retkprobe_filter_arg+0x26>
      26:      	leaq	0x94(%rsp), %rsi
      2e:      	movl	$0x1, %eax
      33:      	callq	*%rax
      35:      	testq	%rax, %rax
      38:      	je	0x179 <generic_retkprobe_filter_arg+0x179>
      3e:      	movq	%rax, %r14
      41:      	movl	0x5f00(%rax), %ebx
      47:      	leaq	0x5ef8(%rax), %rsi
      4e:      	movq	(%rip), %rdi            # 0x55 <generic_retkprobe_filter_arg+0x55>
      55:      	movl	$0x1, %eax
      5a:      	callq	*%rax
      5c:      	testq	%rax, %rax
      5f:      	je	0x15e <generic_retkprobe_filter_arg+0x15e>
      65:      	cmpb	$0x0, 0x5ee0(%r14)
      6d:      	je	0x15e <generic_retkprobe_filter_arg+0x15e>
      73:      	movq	%rax, %rdi
      76:      	movl	%ebx, %eax
      78:      	andl	$0x7, %eax
      7b:      	cmpb	$0x0, 0x5ec1(%r14,%rax)
      84:      	je	0xb8 <generic_retkprobe_filter_arg+0xb8>
      86:      	movl	%eax, %eax
      88:      	movl	0x4(%rdi,%rax,4), %ecx
      8c:      	leaq	(%rcx,%rax,4), %r11
      90:      	addq	$0x8, %r11
      94:      	movl	%r11d, %r9d
      97:      	andl	$0x3ff, %r9d            # imm = 0x3FF
      9e:      	cmpl	$0x19, (%rdi,%r9)
      a3:      	jae	0x104 <generic_retkprobe_filter_arg+0x104>
      a5:      	cmpq	$0x1, %r9
      a9:      	je	0x15e <generic_retkprobe_filter_arg+0x15e>
      af:      	testl	%r9d, %r9d
      b2:      	jne	0x13c <generic_retkprobe_filter_arg+0x13c>
      b8:      	cmpl	$0x1, %ebx
      bb:      	jg	0xd9 <generic_retkprobe_filter_arg+0xd9>
      bd:      	cmpl	$-0x1, %ebx
      c0:      	je	0x18d <generic_retkprobe_filter_arg+0x18d>
      c6:      	testl	%ebx, %ebx
      c8:      	je	0x199 <generic_retkprobe_filter_arg+0x199>
      ce:      	cmpl	$0x1, %ebx
      d1:      	je	0x1a8 <generic_retkprobe_filter_arg+0x1a8>
      d7:      	jmp	0xf4 <generic_retkprobe_filter_arg+0xf4>
      d9:      	cmpl	$0x2, %ebx
      dc:      	je	0x1b7 <generic_retkprobe_filter_arg+0x1b7>
      e2:      	cmpl	$0x3, %ebx
      e5:      	je	0x1c6 <generic_retkprobe_filter_arg+0x1c6>
      eb:      	cmpl	$0x4, %ebx
      ee:      	je	0x1d5 <generic_retkprobe_filter_arg+0x1d5>
      f4:      	cmpl	$0x4, %ebx
      f7:      	jg	0x206 <generic_retkprobe_filter_arg+0x206>
      fd:      	incl	%ebx
      ff:      	jmp	0x1e4 <generic_retkprobe_filter_arg+0x1e4>
     104:      	leaq	(%rdi,%r9), %rax
     108:      	movq	%rax, 0xa8(%rsp)
     110:      	xorl	%ecx, %ecx
     112:      	leaq	0x70(%rsp), %rax
     117:      	movq	%rax, 0x20(%rsp)
     11c:      	movq	%r13, 0x28(%rsp)
     121:      	movq	%rbx, 0xa0(%rsp)
     129:      	movq	%rdi, (%rsp)
     12d:      	movq	%r9, 0x8(%rsp)
     132:      	movq	%r11, 0x10(%rsp)
     137:      	jmp	0x286 <generic_retkprobe_filter_arg+0x286>
     13c:      	movl	%r9d, 0x5f04(%r14)
     143:      	movq	(%rip), %rsi            # 0x14a <generic_retkprobe_filter_arg+0x14a>
     14a:      	movl	$0x4, %ecx
     14f:      	movl	$0xc, %eax
     154:      	movq	%r13, %rdi
     157:      	movl	$0x4, %edx
     15c:      	callq	*%rax
     15e:      	movq	(%rip), %rsi            # 0x165 <generic_retkprobe_filter_arg+0x165>
     165:      	movl	$0x5, %ecx
     16a:      	movl	$0xc, %eax
     16f:      	movq	%r13, %rdi
     172:      	movl	$0x5, %edx
     177:      	callq	*%rax
     179:      	xorl	%eax, %eax
     17b:      	addq	$0xb8, %rsp
     182:      	popq	%rbx
     183:      	popq	%r12
     185:      	popq	%r13
     187:      	popq	%r14
     189:      	popq	%r15
     18b:      	popq	%rbp
     18c:      	retq
     18d:      	xorl	%ebx, %ebx
     18f:      	cmpb	$0x0, 0x5ec1(%r14)
     197:      	jne	0x1e4 <generic_retkprobe_filter_arg+0x1e4>
     199:      	movl	$0x1, %ebx
     19e:      	cmpb	$0x0, 0x5ec2(%r14)
     1a6:      	jne	0x1e4 <generic_retkprobe_filter_arg+0x1e4>
     1a8:      	movl	$0x2, %ebx
     1ad:      	cmpb	$0x0, 0x5ec3(%r14)
     1b5:      	jne	0x1e4 <generic_retkprobe_filter_arg+0x1e4>
     1b7:      	movl	$0x3, %ebx
     1bc:      	cmpb	$0x0, 0x5ec4(%r14)
     1c4:      	jne	0x1e4 <generic_retkprobe_filter_arg+0x1e4>
     1c6:      	movl	$0x4, %ebx
     1cb:      	cmpb	$0x0, 0x5ec5(%r14)
     1d3:      	jne	0x1e4 <generic_retkprobe_filter_arg+0x1e4>
     1d5:      	movl	$0x5, %ebx
     1da:      	cmpb	$0x0, 0x5ec6(%r14)
     1e2:      	je	0x206 <generic_retkprobe_filter_arg+0x206>
     1e4:      	movl	%ebx, 0x5f00(%r14)
     1eb:      	movq	(%rip), %rsi            # 0x1f2 <generic_retkprobe_filter_arg+0x1f2>
     1f2:      	movl	$0x3, %ecx
     1f7:      	movl	$0xc, %eax
     1fc:      	movq	%r13, %rdi
     1ff:      	movl	$0x3, %edx
     204:      	callq	*%rax
     206:      	movq	0x60(%r14), %rbx
     20a:      	movl	$0xe, %eax
     20f:      	callq	*%rax
     211:      	movq	%rbx, 0x38(%rsp)
     216:      	movq	%rax, 0x40(%rsp)
     21b:      	movq	(%rip), %rdi            # 0x222 <generic_retkprobe_filter_arg+0x222>
     222:      	leaq	0x38(%rsp), %rsi
     227:      	movl	$0x1, %eax
     22c:      	callq	*%rax
     22e:      	testq	%rax, %rax
     231:      	je	0x179 <generic_retkprobe_filter_arg+0x179>
     237:      	movq	(%rip), %rdi            # 0x23e <generic_retkprobe_filter_arg+0x23e>
     23e:      	leaq	0x38(%rsp), %rsi
     243:      	movl	$0x3, %eax
     248:      	callq	*%rax
     24a:      	jmp	0x179 <generic_retkprobe_filter_arg+0x179>
     24f:      	xorl	%ebx, %ebx
     251:      	cmpl	$0x3, %eax
     254:      	sete	%bl
     257:      	nopw	(%rax,%rax)
     260:      	testq	%rbx, %rbx
     263:      	movq	0xa0(%rsp), %rbx
     26b:      	je	0xb8 <generic_retkprobe_filter_arg+0xb8>
     271:      	movq	0xb0(%rsp), %rcx
     279:      	incq	%rcx
     27c:      	cmpq	$0x5, %rcx
     280:      	je	0xa5 <generic_retkprobe_filter_arg+0xa5>
     286:      	movq	0xa8(%rsp), %rax
     28e:      	movl	0x4(%rax,%rcx,4), %r12d
     293:      	testl	$0x3ff, %r12d           # imm = 0x3FF
     29a:      	je	0xa5 <generic_retkprobe_filter_arg+0xa5>
     2a0:      	movq	%rcx, 0xb0(%rsp)
     2a8:      	addl	%r11d, %r12d
     2ab:      	andl	$0x3ff, %r12d           # imm = 0x3FF
     2b2:      	movl	0x4(%rdi,%r12), %eax
     2b7:      	cmpl	$0x23, %eax
     2ba:      	je	0xb8 <generic_retkprobe_filter_arg+0xb8>
     2c0:      	addq	%rdi, %r12
     2c3:      	movl	(%r12), %ecx
     2c7:      	cmpq	$0x4, %rcx
     2cb:      	ja	0xb8 <generic_retkprobe_filter_arg+0xb8>
     2d1:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
     2da:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
     2e0:      	movq	0x5e78(%r14,%rcx,8), %rcx
     2e8:      	andl	$0x7ff, %ecx            # imm = 0x7FF
     2ee:      	leaq	(%r14,%rcx), %r15
     2f2:      	addq	$0x90, %r15
     2f9:      	movl	0xc(%r12), %ecx
     2fe:      	cmpl	$0x1b, %ecx
     301:      	jle	0x31e <generic_retkprobe_filter_arg+0x31e>
     303:      	cmpl	$0x25, %ecx
     306:      	jg	0x349 <generic_retkprobe_filter_arg+0x349>
     308:      	leal	-0x1c(%rcx), %edx
     30b:      	cmpl	$0x9, %edx
     30e:      	jb	0x38f <generic_retkprobe_filter_arg+0x38f>
     310:      	cmpl	$0x25, %ecx
     313:      	je	0x5a9 <generic_retkprobe_filter_arg+0x5a9>
     319:      	jmp	0x271 <generic_retkprobe_filter_arg+0x271>
     31e:      	cmpl	$0x9, %ecx
     321:      	jle	0x36f <generic_retkprobe_filter_arg+0x36f>
     323:      	leal	-0xa(%rcx), %edx
     326:      	cmpl	$0x4, %edx
     329:      	jb	0x38f <generic_retkprobe_filter_arg+0x38f>
     32b:      	leal	-0xf(%rcx), %edx
     32e:      	cmpl	$0x2, %edx
     331:      	jb	0x5a9 <generic_retkprobe_filter_arg+0x5a9>
     337:      	cmpl	$0x11, %ecx
     33a:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
     340:      	addq	$0x4, %r15
     344:      	jmp	0x5a9 <generic_retkprobe_filter_arg+0x5a9>
     349:      	cmpl	$0x29, %ecx
     34c:      	jg	0x513 <generic_retkprobe_filter_arg+0x513>
     352:      	leal	-0x26(%rcx), %edx
     355:      	cmpl	$0x2, %edx
     358:      	jb	0x4aa <generic_retkprobe_filter_arg+0x4aa>
     35e:      	leal	-0x28(%rcx), %edx
     361:      	cmpl	$0x2, %edx
     364:      	jb	0x455 <generic_retkprobe_filter_arg+0x455>
     36a:      	jmp	0x271 <generic_retkprobe_filter_arg+0x271>
     36f:      	cmpl	$0x4, %ecx
     372:      	jg	0x442 <generic_retkprobe_filter_arg+0x442>
     378:      	cmpl	$0x1, %ecx
     37b:      	je	0x38f <generic_retkprobe_filter_arg+0x38f>
     37d:      	cmpl	$0x2, %ecx
     380:      	je	0xb43 <generic_retkprobe_filter_arg+0xb43>
     386:      	cmpl	$0x4, %ecx
     389:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
     38f:      	cmpl	$0xb, %ecx
     392:      	jle	0x41f <generic_retkprobe_filter_arg+0x41f>
     398:      	cmpl	$0x24, %ecx
     39b:      	ja	0x6cc <generic_retkprobe_filter_arg+0x6cc>
     3a1:      	movl	%ecx, %edx
     3a3:      	movabsq	$0x1e00000000, %rsi     # imm = 0x1E00000000
     3ad:      	btq	%rdx, %rsi
     3b1:      	jb	0x4e7 <generic_retkprobe_filter_arg+0x4e7>
     3b7:      	movl	$0x60000000, %esi       # imm = 0x60000000
     3bc:      	btq	%rdx, %rsi
     3c0:      	jb	0x918 <generic_retkprobe_filter_arg+0x918>
     3c6:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
     3d0:      	btq	%rdx, %rsi
     3d4:      	jae	0x6cc <generic_retkprobe_filter_arg+0x6cc>
     3da:      	cmpl	$0x20, %eax
     3dd:      	ja	0xb8 <generic_retkprobe_filter_arg+0xb8>
     3e3:      	movl	%eax, %ecx
     3e5:      	movl	$0x101e, %edx           # imm = 0x101E
     3ea:      	btq	%rcx, %rdx
     3ee:      	jae	0x1001 <generic_retkprobe_filter_arg+0x1001>
     3f4:      	movl	0x10(%r12), %ecx
     3f9:      	cmpl	$0x2, %eax
     3fc:      	jle	0x15ba <generic_retkprobe_filter_arg+0x15ba>
     402:      	leal	-0x3(%rax), %edx
     405:      	cmpl	$0x2, %edx
     408:      	jae	0x1d33 <generic_retkprobe_filter_arg+0x1d33>
     40e:      	movzbl	(%r15), %edx
     412:      	cmpl	%edx, %ecx
     414:      	je	0x24f <generic_retkprobe_filter_arg+0x24f>
     41a:      	jmp	0x1e74 <generic_retkprobe_filter_arg+0x1e74>
     41f:      	leal	-0xa(%rcx), %edx
     422:      	cmpl	$0x2, %edx
     425:      	jb	0xbbf <generic_retkprobe_filter_arg+0xbbf>
     42b:      	cmpl	$0x1, %ecx
     42e:      	je	0x6d8 <generic_retkprobe_filter_arg+0x6d8>
     434:      	cmpl	$0x4, %ecx
     437:      	je	0x6d8 <generic_retkprobe_filter_arg+0x6d8>
     43d:      	jmp	0x271 <generic_retkprobe_filter_arg+0x271>
     442:      	cmpl	$0x5, %ecx
     445:      	je	0x455 <generic_retkprobe_filter_arg+0x455>
     447:      	cmpl	$0x6, %ecx
     44a:      	je	0x4aa <generic_retkprobe_filter_arg+0x4aa>
     44c:      	cmpl	$0x7, %ecx
     44f:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
     455:      	movq	$0x0, 0x58(%rsp)
     45e:      	movq	$0x0, 0x50(%rsp)
     467:      	movq	$0x0, 0x48(%rsp)
     470:      	movq	$0x0, 0x40(%rsp)
     479:      	movq	$0x0, 0x38(%rsp)
     482:      	cmpl	$0x27, %ecx
     485:      	jg	0x716 <generic_retkprobe_filter_arg+0x716>
     48b:      	cmpl	$0x5, %ecx
     48e:      	je	0xd25 <generic_retkprobe_filter_arg+0xd25>
     494:      	movq	%r15, %rdx
     497:      	movl	$0x0, %ebx
     49c:      	cmpl	$0x7, %ecx
     49f:      	je	0xd27 <generic_retkprobe_filter_arg+0xd27>
     4a5:      	jmp	0x1bc9 <generic_retkprobe_filter_arg+0x1bc9>
     4aa:      	movl	(%r15), %ebp
     4ad:      	addq	$0x4, %r15
     4b1:      	movq	%r15, 0x18(%rsp)
     4b6:      	cmpl	$0x19, %eax
     4b9:      	jg	0x79a <generic_retkprobe_filter_arg+0x79a>
     4bf:      	leal	-0x3(%rax), %ecx
     4c2:      	cmpl	$0x2, %ecx
     4c5:      	jb	0xf7d <generic_retkprobe_filter_arg+0xf7d>
     4cb:      	cmpl	$0x8, %eax
     4ce:      	je	0xee5 <generic_retkprobe_filter_arg+0xee5>
     4d4:      	movl	$0x0, %ebx
     4d9:      	cmpl	$0x9, %eax
     4dc:      	je	0x7ba <generic_retkprobe_filter_arg+0x7ba>
     4e2:      	jmp	0x3351 <generic_retkprobe_filter_arg+0x3351>
     4e7:      	cmpl	$0x9, %eax
     4ea:      	jle	0xb32 <generic_retkprobe_filter_arg+0xb32>
     4f0:      	cmpl	$0x1d, %eax
     4f3:      	jg	0xe9e <generic_retkprobe_filter_arg+0xe9e>
     4f9:      	leal	-0xa(%rax), %edx
     4fc:      	cmpl	$0x2, %edx
     4ff:      	jb	0xc4b <generic_retkprobe_filter_arg+0xc4b>
     505:      	cmpl	$0xc, %eax
     508:      	je	0xbd5 <generic_retkprobe_filter_arg+0xbd5>
     50e:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
     513:      	cmpl	$0x2a, %ecx
     516:      	je	0x5a9 <generic_retkprobe_filter_arg+0x5a9>
     51c:      	cmpl	$0x2c, %ecx
     51f:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
     525:      	movq	%r15, %rcx
     528:      	leaq	0x4(%r15), %r8
     52c:      	movzbl	0x3(%r15), %ebp
     531:      	movzbl	%bpl, %esi
     535:      	cmpl	$0x19, %eax
     538:      	jg	0x12bf <generic_retkprobe_filter_arg+0x12bf>
     53e:      	leal	-0x3(%rax), %ecx
     541:      	cmpl	$0x2, %ecx
     544:      	jae	0x18b9 <generic_retkprobe_filter_arg+0x18b9>
     54a:      	movl	$0x0, 0x70(%rsp)
     552:      	movl	$0x100, %r13d           # imm = 0x100
     558:      	cmpb	$-0x70, %bpl
     55c:      	ja	0x1589 <generic_retkprobe_filter_arg+0x1589>
     562:      	testb	%bpl, %bpl
     565:      	je	0x578 <generic_retkprobe_filter_arg+0x578>
     567:      	movl	%esi, %eax
     569:      	movl	$0x18, %ecx
     56e:      	cltd
     56f:      	idivl	%ecx
     571:      	movl	%esi, %r13d
     574:      	testl	%edx, %edx
     576:      	je	0x59c <generic_retkprobe_filter_arg+0x59c>
     578:      	movl	%esi, %eax
     57a:      	movl	$0x18, %ecx
     57f:      	cltd
     580:      	idivl	%ecx
     582:      	shll	$0x3, %eax
     585:      	leal	(%rax,%rax,2), %eax
     588:      	addl	$0x18, %eax
     58b:      	movzwl	%ax, %r13d
     58f:      	cmpl	$0x90, %r13d
     596:      	ja	0x1589 <generic_retkprobe_filter_arg+0x1589>
     59c:      	movl	%r13d, %eax
     59f:      	cltd
     5a0:      	idivl	%ecx
     5a2:      	decl	%eax
     5a4:      	jmp	0x2479 <generic_retkprobe_filter_arg+0x2479>
     5a9:      	movl	(%r15), %ebp
     5ac:      	movl	%eax, %ecx
     5ae:      	andl	$-0x2, %ecx
     5b1:      	cmpl	$0x24, %ecx
     5b4:      	je	0x5be <generic_retkprobe_filter_arg+0x5be>
     5b6:      	testl	%ebp, %ebp
     5b8:      	je	0xb8 <generic_retkprobe_filter_arg+0xb8>
     5be:      	cmpl	$0x25, %eax
     5c1:      	ja	0x8f5 <generic_retkprobe_filter_arg+0x8f5>
     5c7:      	movl	%eax, %ecx
     5c9:      	movl	$0x4000100, %edx        # imm = 0x4000100
     5ce:      	btq	%rcx, %rdx
     5d2:      	jb	0xa94 <generic_retkprobe_filter_arg+0xa94>
     5d8:      	movl	$0x8000200, %edx        # imm = 0x8000200
     5dd:      	btq	%rcx, %rdx
     5e1:      	jb	0x95d <generic_retkprobe_filter_arg+0x95d>
     5e7:      	movabsq	$0x3000000000, %rdx     # imm = 0x3000000000
     5f1:      	btq	%rcx, %rdx
     5f5:      	jae	0x8f5 <generic_retkprobe_filter_arg+0x8f5>
     5fb:      	movw	$0x0, 0x38(%rsp)
     602:      	cmpl	$0x1000, %ebp           # imm = 0x1000
     608:      	ja	0x911 <generic_retkprobe_filter_arg+0x911>
     60e:      	leaq	(%r15,%rbp), %rcx
     612:      	addq	$0x8, %rcx
     616:      	movl	$0x4, %eax
     61b:      	leaq	0x38(%rsp), %rdi
     620:      	movl	$0x2, %edx
     625:      	movl	(%r15), %ecx
     628:      	leaq	(%r15,%rcx), %rdx
     62c:      	addq	$0x8, %rdx
     630:      	movl	$0x2, %esi
     635:      	callq	*%rax
     637:      	movl	0x10(%r12), %ecx
     63c:      	testl	%ecx, %ecx
     63e:      	je	0x3153 <generic_retkprobe_filter_arg+0x3153>
     644:      	movzwl	0x38(%rsp), %eax
     649:      	andl	$0xf000, %eax           # imm = 0xF000
     64e:      	movl	$0x1, %ebx
     653:      	cmpl	%eax, %ecx
     655:      	je	0x3155 <generic_retkprobe_filter_arg+0x3155>
     65b:      	movl	0x8(%r12), %ecx
     660:      	cmpl	$0xd, %ecx
     663:      	movq	(%rsp), %rdi
     667:      	movq	0x8(%rsp), %r9
     66c:      	movq	0x10(%rsp), %r11
     671:      	jb	0x911 <generic_retkprobe_filter_arg+0x911>
     677:      	movl	0x14(%r12), %edx
     67c:      	testl	%edx, %edx
     67e:      	je	0x911 <generic_retkprobe_filter_arg+0x911>
     684:      	cmpl	%eax, %edx
     686:      	je	0x3163 <generic_retkprobe_filter_arg+0x3163>
     68c:      	cmpl	$0x11, %ecx
     68f:      	jb	0x911 <generic_retkprobe_filter_arg+0x911>
     695:      	movl	0x18(%r12), %edx
     69a:      	testl	%edx, %edx
     69c:      	je	0x911 <generic_retkprobe_filter_arg+0x911>
     6a2:      	cmpl	%eax, %edx
     6a4:      	je	0x3163 <generic_retkprobe_filter_arg+0x3163>
     6aa:      	cmpl	$0x15, %ecx
     6ad:      	jb	0x3678 <generic_retkprobe_filter_arg+0x3678>
     6b3:      	movl	0x1c(%r12), %ecx
     6b8:      	testl	%ecx, %ecx
     6ba:      	je	0x3678 <generic_retkprobe_filter_arg+0x3678>
     6c0:      	xorl	%ebx, %ebx
     6c2:      	cmpl	%eax, %ecx
     6c4:      	sete	%bl
     6c7:      	jmp	0xa8a <generic_retkprobe_filter_arg+0xa8a>
     6cc:      	leal	-0xc(%rcx), %edx
     6cf:      	cmpl	$0x2, %edx
     6d2:      	jae	0xbb6 <generic_retkprobe_filter_arg+0xbb6>
     6d8:      	cmpl	$0x20, %eax
     6db:      	ja	0xb8 <generic_retkprobe_filter_arg+0xb8>
     6e1:      	movl	%eax, %edx
     6e3:      	movl	$0x101e, %esi           # imm = 0x101E
     6e8:      	btq	%rdx, %rsi
     6ec:      	jae	0x735 <generic_retkprobe_filter_arg+0x735>
     6ee:      	movl	0x10(%r12), %edx
     6f3:      	cmpl	$0x2, %eax
     6f6:      	jle	0xb7f <generic_retkprobe_filter_arg+0xb7f>
     6fc:      	leal	-0x3(%rax), %esi
     6ff:      	cmpl	$0x2, %esi
     702:      	jae	0xfea <generic_retkprobe_filter_arg+0xfea>
     708:      	cmpl	%edx, (%r15)
     70b:      	je	0x24f <generic_retkprobe_filter_arg+0x24f>
     711:      	jmp	0x21da <generic_retkprobe_filter_arg+0x21da>
     716:      	cmpl	$0x28, %ecx
     719:      	je	0xcfb <generic_retkprobe_filter_arg+0xcfb>
     71f:      	movq	%r15, %rdx
     722:      	movl	$0x0, %ebx
     727:      	cmpl	$0x29, %ecx
     72a:      	je	0xd27 <generic_retkprobe_filter_arg+0xd27>
     730:      	jmp	0x1bc9 <generic_retkprobe_filter_arg+0x1bc9>
     735:      	movl	$0xc00, %esi            # imm = 0xC00
     73a:      	btq	%rdx, %rsi
     73e:      	jb	0xcbb <generic_retkprobe_filter_arg+0xcbb>
     744:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
     74e:      	btq	%rdx, %rsi
     752:      	jae	0xb8 <generic_retkprobe_filter_arg+0xb8>
     758:      	cmpl	$0x1f, %eax
     75b:      	jne	0x128b <generic_retkprobe_filter_arg+0x128b>
     761:      	movl	0x10(%r12), %esi
     766:      	movl	0x14(%r12), %edx
     76b:      	cmpl	$0xc, %ecx
     76e:      	ja	0x1ef2 <generic_retkprobe_filter_arg+0x1ef2>
     774:      	movl	$0x1402, %eax           # imm = 0x1402
     779:      	btl	%ecx, %eax
     77c:      	jae	0x1ef2 <generic_retkprobe_filter_arg+0x1ef2>
     782:      	movl	(%r15), %eax
     785:      	cmpl	%eax, %esi
     787:      	jg	0x1f01 <generic_retkprobe_filter_arg+0x1f01>
     78d:      	cmpl	%edx, %eax
     78f:      	jle	0x271 <generic_retkprobe_filter_arg+0x271>
     795:      	jmp	0x1f01 <generic_retkprobe_filter_arg+0x1f01>
     79a:      	cmpl	$0x20, %eax
     79d:      	jg	0xdab <generic_retkprobe_filter_arg+0xdab>
     7a3:      	cmpl	$0x1a, %eax
     7a6:      	je	0xee5 <generic_retkprobe_filter_arg+0xee5>
     7ac:      	movl	$0x0, %ebx
     7b1:      	cmpl	$0x1b, %eax
     7b4:      	jne	0x3351 <generic_retkprobe_filter_arg+0x3351>
     7ba:      	movl	0x10(%r12), %eax
     7bf:      	movl	%eax, 0x38(%rsp)
     7c3:      	movl	$0x0, 0x70(%rsp)
     7cb:      	movl	$0x1, %eax
     7d0:      	leaq	0x38(%rsp), %rsi
     7d5:      	movq	(%rip), %rdi            # 0x7dc <generic_retkprobe_filter_arg+0x7dc>
     7dc:      	callq	*%rax
     7de:      	testl	%ebp, %ebp
     7e0:      	je	0x3341 <generic_retkprobe_filter_arg+0x3341>
     7e6:      	movq	%rax, %r15
     7e9:      	movl	$0x0, %ebx
     7ee:      	testq	%rax, %rax
     7f1:      	je	0x3343 <generic_retkprobe_filter_arg+0x3343>
     7f7:      	movl	$0x1, %eax
     7fc:      	movq	0x20(%rsp), %rsi
     801:      	movq	(%rip), %rdi            # 0x808 <generic_retkprobe_filter_arg+0x808>
     808:      	callq	*%rax
     80a:      	testq	%rax, %rax
     80d:      	je	0x3341 <generic_retkprobe_filter_arg+0x3341>
     813:      	movq	%rax, %rsi
     816:      	movq	%r15, 0x60(%rsp)
     81b:      	cmpl	$0x7f, %ebp
     81e:      	movl	$0x7f, %eax
     823:      	cmovbl	%ebp, %eax
     826:      	shll	$0x3, %eax
     829:      	movl	%eax, (%rsi)
     82b:      	movq	%rbp, %rax
     82e:      	negq	%rax
     831:      	movl	$0x3, %ecx
     836:      	subq	%rbp, %rcx
     839:      	leal	-0x4(%rbp), %edx
     83c:      	movq	%rsi, %rdi
     83f:      	addq	$0x7, %rdi
     843:      	movl	$0x2, %r8d
     849:      	subq	%rbp, %r8
     84c:      	leal	-0x3(%rbp), %r9d
     850:      	movl	$0x1, %r10d
     856:      	subq	%rbp, %r10
     859:      	leal	-0x2(%rbp), %r11d
     85d:      	decl	%ebp
     85f:      	xorl	%ebx, %ebx
     861:      	movq	0x18(%rsp), %r15
     866:      	leal	(%rbx,%rbp), %r13d
     86a:      	andl	$0xfff, %r13d           # imm = 0xFFF
     871:      	movzbl	(%r15,%r13), %r13d
     876:      	movb	%r13b, -0x3(%rdi)
     87a:      	cmpq	%rbx, %r10
     87d:      	je	0x8d7 <generic_retkprobe_filter_arg+0x8d7>
     87f:      	leal	(%r11,%rbx), %r13d
     883:      	andl	$0xfff, %r13d           # imm = 0xFFF
     88a:      	movzbl	(%r15,%r13), %r13d
     88f:      	movb	%r13b, -0x2(%rdi)
     893:      	cmpq	%rbx, %r8
     896:      	je	0x8d7 <generic_retkprobe_filter_arg+0x8d7>
     898:      	leal	(%r9,%rbx), %r13d
     89c:      	andl	$0xfff, %r13d           # imm = 0xFFF
     8a3:      	movzbl	(%r15,%r13), %r13d
     8a8:      	movb	%r13b, -0x1(%rdi)
     8ac:      	cmpq	%rbx, %rcx
     8af:      	je	0x8d7 <generic_retkprobe_filter_arg+0x8d7>
     8b1:      	cmpq	$-0x7c, %rbx
     8b5:      	je	0x8d7 <generic_retkprobe_filter_arg+0x8d7>
     8b7:      	leal	(%rdx,%rbx), %r13d
     8bb:      	andl	$0xfff, %r13d           # imm = 0xFFF
     8c2:      	movzbl	(%r15,%r13), %r13d
     8c7:      	movb	%r13b, (%rdi)
     8ca:      	addq	$-0x4, %rbx
     8ce:      	addq	$0x4, %rdi
     8d2:      	cmpq	%rbx, %rax
     8d5:      	jne	0x866 <generic_retkprobe_filter_arg+0x866>
     8d7:      	movl	$0x1, %eax
     8dc:      	movq	0x60(%rsp), %rdi
     8e1:      	callq	*%rax
     8e3:      	xorl	%ebx, %ebx
     8e5:      	testq	%rax, %rax
     8e8:      	setne	%bl
     8eb:      	movq	0x28(%rsp), %r13
     8f0:      	jmp	0x3343 <generic_retkprobe_filter_arg+0x3343>
     8f5:      	addl	$-0x3, %eax
     8f8:      	cmpl	$0x2, %eax
     8fb:      	jae	0x911 <generic_retkprobe_filter_arg+0x911>
     8fd:      	movl	$0x0, 0x70(%rsp)
     905:      	cmpl	$0x1000, %ebp           # imm = 0x1000
     90b:      	jbe	0x10f0 <generic_retkprobe_filter_arg+0x10f0>
     911:      	xorl	%ebx, %ebx
     913:      	jmp	0x3163 <generic_retkprobe_filter_arg+0x3163>
     918:      	cmpl	$0x20, %eax
     91b:      	ja	0xb8 <generic_retkprobe_filter_arg+0xb8>
     921:      	movl	%eax, %ecx
     923:      	movl	$0x101e, %edx           # imm = 0x101E
     928:      	btq	%rcx, %rdx
     92c:      	jae	0x1033 <generic_retkprobe_filter_arg+0x1033>
     932:      	movl	0x10(%r12), %ecx
     937:      	cmpl	$0x2, %eax
     93a:      	jle	0x15dd <generic_retkprobe_filter_arg+0x15dd>
     940:      	leal	-0x3(%rax), %edx
     943:      	cmpl	$0x2, %edx
     946:      	jae	0x1d4d <generic_retkprobe_filter_arg+0x1d4d>
     94c:      	movzwl	(%r15), %edx
     950:      	cmpl	%edx, %ecx
     952:      	je	0x24f <generic_retkprobe_filter_arg+0x24f>
     958:      	jmp	0x1eb9 <generic_retkprobe_filter_arg+0x1eb9>
     95d:      	movl	0x10(%r12), %eax
     962:      	movl	%eax, 0x38(%rsp)
     966:      	movl	$0x0, 0x70(%rsp)
     96e:      	movl	$0x1, %eax
     973:      	leaq	0x38(%rsp), %rsi
     978:      	movq	(%rip), %rdi            # 0x97f <generic_retkprobe_filter_arg+0x97f>
     97f:      	callq	*%rax
     981:      	testl	%ebp, %ebp
     983:      	je	0x3153 <generic_retkprobe_filter_arg+0x3153>
     989:      	movl	$0x0, %ebx
     98e:      	testq	%rax, %rax
     991:      	je	0x3155 <generic_retkprobe_filter_arg+0x3155>
     997:      	movq	%rax, 0x18(%rsp)
     99c:      	movl	$0x1, %eax
     9a1:      	movq	0x20(%rsp), %rsi
     9a6:      	movq	(%rip), %rdi            # 0x9ad <generic_retkprobe_filter_arg+0x9ad>
     9ad:      	callq	*%rax
     9af:      	testq	%rax, %rax
     9b2:      	je	0x3153 <generic_retkprobe_filter_arg+0x3153>
     9b8:      	movq	%rax, %rsi
     9bb:      	cmpl	$0x7f, %ebp
     9be:      	movl	$0x7f, %eax
     9c3:      	cmovbl	%ebp, %eax
     9c6:      	shll	$0x3, %eax
     9c9:      	movl	%eax, (%rsi)
     9cb:      	movq	%rbp, %rax
     9ce:      	negq	%rax
     9d1:      	movl	$0x3, %ecx
     9d6:      	subq	%rbp, %rcx
     9d9:      	leal	-0x4(%rbp), %edx
     9dc:      	movq	%rsi, %rdi
     9df:      	addq	$0x7, %rdi
     9e3:      	movl	$0x2, %r8d
     9e9:      	subq	%rbp, %r8
     9ec:      	leal	-0x3(%rbp), %r9d
     9f0:      	movl	$0x1, %r10d
     9f6:      	subq	%rbp, %r10
     9f9:      	leal	-0x2(%rbp), %r11d
     9fd:      	decl	%ebp
     9ff:      	xorl	%ebx, %ebx
     a01:      	leal	(%rbx,%rbp), %r13d
     a05:      	andl	$0xfff, %r13d           # imm = 0xFFF
     a0c:      	movzbl	0x4(%r15,%r13), %r13d
     a12:      	movb	%r13b, -0x3(%rdi)
     a16:      	cmpq	%rbx, %r10
     a19:      	je	0xa76 <generic_retkprobe_filter_arg+0xa76>
     a1b:      	leal	(%r11,%rbx), %r13d
     a1f:      	andl	$0xfff, %r13d           # imm = 0xFFF
     a26:      	movzbl	0x4(%r15,%r13), %r13d
     a2c:      	movb	%r13b, -0x2(%rdi)
     a30:      	cmpq	%rbx, %r8
     a33:      	je	0xa76 <generic_retkprobe_filter_arg+0xa76>
     a35:      	leal	(%r9,%rbx), %r13d
     a39:      	andl	$0xfff, %r13d           # imm = 0xFFF
     a40:      	movzbl	0x4(%r15,%r13), %r13d
     a46:      	movb	%r13b, -0x1(%rdi)
     a4a:      	cmpq	%rbx, %rcx
     a4d:      	je	0xa76 <generic_retkprobe_filter_arg+0xa76>
     a4f:      	cmpq	$-0x7c, %rbx
     a53:      	je	0xa76 <generic_retkprobe_filter_arg+0xa76>
     a55:      	leal	(%rdx,%rbx), %r13d
     a59:      	andl	$0xfff, %r13d           # imm = 0xFFF
     a60:      	movzbl	0x4(%r15,%r13), %r13d
     a66:      	movb	%r13b, (%rdi)
     a69:      	addq	$-0x4, %rbx
     a6d:      	addq	$0x4, %rdi
     a71:      	cmpq	%rbx, %rax
     a74:      	jne	0xa01 <generic_retkprobe_filter_arg+0xa01>
     a76:      	movl	$0x1, %eax
     a7b:      	movq	0x18(%rsp), %rdi
     a80:      	callq	*%rax
     a82:      	xorl	%ebx, %ebx
     a84:      	testq	%rax, %rax
     a87:      	setne	%bl
     a8a:      	movq	0x28(%rsp), %r13
     a8f:      	jmp	0x3155 <generic_retkprobe_filter_arg+0x3155>
     a94:      	movl	0x10(%r12), %eax
     a99:      	movl	%eax, 0x38(%rsp)
     a9d:      	movl	$0x0, 0x70(%rsp)
     aa5:      	movl	$0x1, %eax
     aaa:      	leaq	0x38(%rsp), %rsi
     aaf:      	movq	(%rip), %rdi            # 0xab6 <generic_retkprobe_filter_arg+0xab6>
     ab6:      	callq	*%rax
     ab8:      	testl	%ebp, %ebp
     aba:      	je	0x3153 <generic_retkprobe_filter_arg+0x3153>
     ac0:      	movl	$0x0, %ebx
     ac5:      	testq	%rax, %rax
     ac8:      	je	0x3155 <generic_retkprobe_filter_arg+0x3155>
     ace:      	movq	%rax, 0x18(%rsp)
     ad3:      	movl	$0x1, %eax
     ad8:      	movq	0x20(%rsp), %rsi
     add:      	movq	(%rip), %rdi            # 0xae4 <generic_retkprobe_filter_arg+0xae4>
     ae4:      	callq	*%rax
     ae6:      	testq	%rax, %rax
     ae9:      	je	0x3153 <generic_retkprobe_filter_arg+0x3153>
     aef:      	movq	%rax, %rbx
     af2:      	addq	$0x4, %r15
     af6:      	cmpl	$0xff, %ebp
     afc:      	movl	$0xff, %eax
     b01:      	cmovael	%eax, %ebp
     b04:      	leal	(,%rbp,8), %eax
     b0b:      	movl	%eax, (%rbx)
     b0d:      	movq	%rbx, %rdi
     b10:      	addq	$0x4, %rdi
     b14:      	movl	$0x4, %eax
     b19:      	movl	%ebp, %esi
     b1b:      	movq	%r15, %rdx
     b1e:      	callq	*%rax
     b20:      	movl	$0x1, %eax
     b25:      	movq	0x18(%rsp), %rdi
     b2a:      	movq	%rbx, %rsi
     b2d:      	jmp	0x3147 <generic_retkprobe_filter_arg+0x3147>
     b32:      	leal	-0x1(%rax), %edx
     b35:      	cmpl	$0x4, %edx
     b38:      	jb	0xbd5 <generic_retkprobe_filter_arg+0xbd5>
     b3e:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
     b43:      	movq	%r15, %r13
     b46:      	movl	0x4(%r15), %ebp
     b4a:      	addq	$0x8, %r13
     b4e:      	cmpl	$0x19, %eax
     b51:      	jg	0x1141 <generic_retkprobe_filter_arg+0x1141>
     b57:      	leal	-0x3(%rax), %ecx
     b5a:      	cmpl	$0x2, %ecx
     b5d:      	jb	0x1a8b <generic_retkprobe_filter_arg+0x1a8b>
     b63:      	cmpl	$0x8, %eax
     b66:      	je	0x19f5 <generic_retkprobe_filter_arg+0x19f5>
     b6c:      	movl	$0x0, %ebx
     b71:      	cmpl	$0x9, %eax
     b74:      	je	0x1161 <generic_retkprobe_filter_arg+0x1161>
     b7a:      	jmp	0x3640 <generic_retkprobe_filter_arg+0x3640>
     b7f:      	cmpl	$0x1, %eax
     b82:      	je	0x1414 <generic_retkprobe_filter_arg+0x1414>
     b88:      	cmpl	$0x2, %eax
     b8b:      	jne	0x21da <generic_retkprobe_filter_arg+0x21da>
     b91:      	cmpl	$0xc, %ecx
     b94:      	ja	0x21d1 <generic_retkprobe_filter_arg+0x21d1>
     b9a:      	movl	$0x1402, %esi           # imm = 0x1402
     b9f:      	btl	%ecx, %esi
     ba2:      	jae	0x21d1 <generic_retkprobe_filter_arg+0x21d1>
     ba8:      	cmpl	%edx, (%r15)
     bab:      	jl	0x271 <generic_retkprobe_filter_arg+0x271>
     bb1:      	jmp	0x21da <generic_retkprobe_filter_arg+0x21da>
     bb6:      	cmpl	$0x1c, %ecx
     bb9:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
     bbf:      	cmpl	$0x20, %eax
     bc2:      	ja	0xb8 <generic_retkprobe_filter_arg+0xb8>
     bc8:      	movl	%eax, %edx
     bca:      	movl	$0x101e, %esi           # imm = 0x101E
     bcf:      	btq	%rdx, %rsi
     bd3:      	jae	0xbf9 <generic_retkprobe_filter_arg+0xbf9>
     bd5:      	movq	0x10(%r12), %rdx
     bda:      	cmpl	$0x2, %eax
     bdd:      	jle	0xc1d <generic_retkprobe_filter_arg+0xc1d>
     bdf:      	leal	-0x3(%rax), %esi
     be2:      	cmpl	$0x2, %esi
     be5:      	jae	0xe87 <generic_retkprobe_filter_arg+0xe87>
     beb:      	cmpq	%rdx, (%r15)
     bee:      	je	0x24f <generic_retkprobe_filter_arg+0x24f>
     bf4:      	jmp	0x1cb8 <generic_retkprobe_filter_arg+0x1cb8>
     bf9:      	movl	$0xc00, %esi            # imm = 0xC00
     bfe:      	btq	%rdx, %rsi
     c02:      	jb	0xc4b <generic_retkprobe_filter_arg+0xc4b>
     c04:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
     c0e:      	btq	%rdx, %rsi
     c12:      	jb	0xeaa <generic_retkprobe_filter_arg+0xeaa>
     c18:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
     c1d:      	cmpl	$0x1, %eax
     c20:      	je	0x10d4 <generic_retkprobe_filter_arg+0x10d4>
     c26:      	cmpl	$0x2, %eax
     c29:      	jne	0x1cb8 <generic_retkprobe_filter_arg+0x1cb8>
     c2f:      	cmpl	$0xc, %ecx
     c32:      	je	0xc3d <generic_retkprobe_filter_arg+0xc3d>
     c34:      	cmpl	$0xa, %ecx
     c37:      	jne	0x1caf <generic_retkprobe_filter_arg+0x1caf>
     c3d:      	cmpq	%rdx, (%r15)
     c40:      	jl	0x271 <generic_retkprobe_filter_arg+0x271>
     c46:      	jmp	0x1cb8 <generic_retkprobe_filter_arg+0x1cb8>
     c4b:      	movzbl	0x10(%r12), %eax
     c51:      	movl	%eax, 0x70(%rsp)
     c55:      	movl	$0x1, %eax
     c5a:      	movq	0x20(%rsp), %rsi
     c5f:      	movq	(%rip), %rdi            # 0xc66 <generic_retkprobe_filter_arg+0xc66>
     c66:      	callq	*%rax
     c68:      	testq	%rax, %rax
     c6b:      	je	0x19c8 <generic_retkprobe_filter_arg+0x19c8>
     c71:      	movq	%rax, %rdi
     c74:      	movq	(%r15), %rax
     c77:      	movq	%rax, 0x38(%rsp)
     c7c:      	movl	$0x1, %eax
     c81:      	leaq	0x38(%rsp), %rsi
     c86:      	callq	*%rax
     c88:      	movl	0x4(%r12), %ecx
     c8d:      	cmpl	$0xb, %ecx
     c90:      	je	0x16b2 <generic_retkprobe_filter_arg+0x16b2>
     c96:      	cmpl	$0xa, %ecx
     c99:      	movq	(%rsp), %rdi
     c9d:      	movq	0x8(%rsp), %r9
     ca2:      	movq	0x10(%rsp), %r11
     ca7:      	jne	0x16ce <generic_retkprobe_filter_arg+0x16ce>
     cad:      	testq	%rax, %rax
     cb0:      	setne	%al
     cb3:      	movzbl	%al, %ebx
     cb6:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
     cbb:      	movzbl	0x10(%r12), %eax
     cc1:      	movl	%eax, 0x70(%rsp)
     cc5:      	movl	$0x1, %eax
     cca:      	movq	0x20(%rsp), %rsi
     ccf:      	movq	(%rip), %rdi            # 0xcd6 <generic_retkprobe_filter_arg+0xcd6>
     cd6:      	callq	*%rax
     cd8:      	testq	%rax, %rax
     cdb:      	je	0x19c8 <generic_retkprobe_filter_arg+0x19c8>
     ce1:      	movq	%rax, %rdi
     ce4:      	movl	(%r15), %eax
     ce7:      	movq	%rax, 0x38(%rsp)
     cec:      	movl	$0x1, %eax
     cf1:      	leaq	0x38(%rsp), %rsi
     cf6:      	jmp	0x1996 <generic_retkprobe_filter_arg+0x1996>
     cfb:      	movzwl	(%r15), %edx
     cff:      	movw	%dx, 0x5e(%rsp)
     d04:      	movzwl	0x2(%r15), %edx
     d09:      	movw	%dx, 0x58(%rsp)
     d0e:      	movq	0x8(%r15), %rdx
     d12:      	movq	%rdx, 0x38(%rsp)
     d17:      	movq	0x10(%r15), %rdx
     d1b:      	movq	%rdx, 0x40(%rsp)
     d20:      	leaq	0x38(%rsp), %r15
     d25:      	xorl	%edx, %edx
     d27:      	cmpl	$0x13, %eax
     d2a:      	jle	0xd53 <generic_retkprobe_filter_arg+0xd53>
     d2c:      	cmpl	$0x17, %eax
     d2f:      	jg	0xd86 <generic_retkprobe_filter_arg+0xd86>
     d31:      	leal	-0x14(%rax), %ecx
     d34:      	cmpl	$0x2, %ecx
     d37:      	jb	0x12fb <generic_retkprobe_filter_arg+0x12fb>
     d3d:      	leal	-0x16(%rax), %ecx
     d40:      	movl	$0x0, %ebx
     d45:      	cmpl	$0x2, %ecx
     d48:      	jb	0x12f1 <generic_retkprobe_filter_arg+0x12f1>
     d4e:      	jmp	0x1bc9 <generic_retkprobe_filter_arg+0x1bc9>
     d53:      	cmpl	$0xf, %eax
     d56:      	jle	0xf98 <generic_retkprobe_filter_arg+0xf98>
     d5c:      	cmpl	$0x11, %eax
     d5f:      	jg	0x12de <generic_retkprobe_filter_arg+0x12de>
     d65:      	cmpl	$0x10, %eax
     d68:      	je	0x12f1 <generic_retkprobe_filter_arg+0x12f1>
     d6e:      	movl	$0x0, %ebx
     d73:      	cmpl	$0x11, %eax
     d76:      	jne	0x1bc9 <generic_retkprobe_filter_arg+0x1bc9>
     d7c:      	movzwl	0x24(%r15), %ebx
     d81:      	jmp	0x1b49 <generic_retkprobe_filter_arg+0x1b49>
     d86:      	cmpl	$0x1b, %eax
     d89:      	jg	0x1337 <generic_retkprobe_filter_arg+0x1337>
     d8f:      	cmpl	$0x18, %eax
     d92:      	je	0x1374 <generic_retkprobe_filter_arg+0x1374>
     d98:      	movl	$0x0, %ebx
     d9d:      	cmpl	$0x19, %eax
     da0:      	je	0x1367 <generic_retkprobe_filter_arg+0x1367>
     da6:      	jmp	0x1bc9 <generic_retkprobe_filter_arg+0x1bc9>
     dab:      	cmpl	$0x21, %eax
     dae:      	je	0x1439 <generic_retkprobe_filter_arg+0x1439>
     db4:      	movl	$0x0, %ebx
     db9:      	cmpl	$0x22, %eax
     dbc:      	jne	0x3351 <generic_retkprobe_filter_arg+0x3351>
     dc2:      	xorl	%ebx, %ebx
     dc4:      	xorl	%r13d, %r13d
     dc7:      	movl	0x10(%r12,%rbx,4), %eax
     dcc:      	movl	%eax, 0x38(%rsp)
     dd0:      	movl	$0x1, %eax
     dd5:      	leaq	0x38(%rsp), %rsi
     dda:      	movq	(%rip), %rdi            # 0xde1 <generic_retkprobe_filter_arg+0xde1>
     de1:      	callq	*%rax
     de3:      	testq	%rax, %rax
     de6:      	je	0x216c <generic_retkprobe_filter_arg+0x216c>
     dec:      	testl	%ebp, %ebp
     dee:      	movq	0x10(%rsp), %r11
     df3:      	je	0xe64 <generic_retkprobe_filter_arg+0xe64>
     df5:      	movq	0x18(%rsp), %rdx
     dfa:      	xorl	%ecx, %ecx
     dfc:      	jmp	0xe09 <generic_retkprobe_filter_arg+0xe09>
     dfe:      	incq	%rcx
     e01:      	incq	%rdx
     e04:      	cmpq	%rbp, %rcx
     e07:      	je	0xe64 <generic_retkprobe_filter_arg+0xe64>
     e09:      	xorl	%esi, %esi
     e0b:      	nopl	(%rax,%rax)
     e10:      	leaq	(%rcx,%rsi), %rdi
     e14:      	cmpq	%rbp, %rdi
     e17:      	jae	0xdfe <generic_retkprobe_filter_arg+0xdfe>
     e19:      	movsbl	(%rax,%rsi), %edi
     e1d:      	testl	%edi, %edi
     e1f:      	je	0xe5c <generic_retkprobe_filter_arg+0xe5c>
     e21:      	movsbl	(%rdx,%rsi), %r9d
     e26:      	leal	-0x41(%r9), %r10d
     e2a:      	movl	%r9d, %r8d
     e2d:      	orl	$0x20, %r8d
     e31:      	cmpl	$0x1a, %r10d
     e35:      	cmovael	%r9d, %r8d
     e39:      	leal	-0x41(%rdi), %r10d
     e3d:      	movl	%edi, %r9d
     e40:      	orl	$0x20, %r9d
     e44:      	cmpl	$0x1a, %r10d
     e48:      	cmovael	%edi, %r9d
     e4c:      	cmpq	$0x62, %rsi
     e50:      	ja	0xdfe <generic_retkprobe_filter_arg+0xdfe>
     e52:      	incq	%rsi
     e55:      	cmpl	%r9d, %r8d
     e58:      	je	0xe10 <generic_retkprobe_filter_arg+0xe10>
     e5a:      	jmp	0xdfe <generic_retkprobe_filter_arg+0xdfe>
     e5c:      	testl	%ecx, %ecx
     e5e:      	jns	0x261e <generic_retkprobe_filter_arg+0x261e>
     e64:      	leal	0xc(%r13), %eax
     e68:      	cmpl	0x8(%r12), %eax
     e6d:      	jae	0xe80 <generic_retkprobe_filter_arg+0xe80>
     e6f:      	addl	$0x4, %r13d
     e73:      	incq	%rbx
     e76:      	cmpq	$0x64, %rbx
     e7a:      	jne	0xdc7 <generic_retkprobe_filter_arg+0xdc7>
     e80:      	xorl	%ebx, %ebx
     e82:      	jmp	0x2623 <generic_retkprobe_filter_arg+0x2623>
     e87:      	cmpl	$0xc, %eax
     e8a:      	jne	0x1cb8 <generic_retkprobe_filter_arg+0x1cb8>
     e90:      	testq	%rdx, (%r15)
     e93:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
     e99:      	jmp	0x1cb8 <generic_retkprobe_filter_arg+0x1cb8>
     e9e:      	leal	-0x1f(%rax), %edx
     ea1:      	cmpl	$0x2, %edx
     ea4:      	jae	0x17e1 <generic_retkprobe_filter_arg+0x17e1>
     eaa:      	cmpl	$0x1f, %eax
     ead:      	jne	0xfbd <generic_retkprobe_filter_arg+0xfbd>
     eb3:      	movq	0x10(%r12), %rsi
     eb8:      	movq	0x18(%r12), %rdx
     ebd:      	cmpl	$0xa, %ecx
     ec0:      	je	0xecb <generic_retkprobe_filter_arg+0xecb>
     ec2:      	cmpl	$0xc, %ecx
     ec5:      	jne	0x1aa6 <generic_retkprobe_filter_arg+0x1aa6>
     ecb:      	movq	(%r15), %rax
     ece:      	cmpq	%rax, %rsi
     ed1:      	jg	0x1ab7 <generic_retkprobe_filter_arg+0x1ab7>
     ed7:      	cmpq	%rdx, %rax
     eda:      	jle	0x271 <generic_retkprobe_filter_arg+0x271>
     ee0:      	jmp	0x1ab7 <generic_retkprobe_filter_arg+0x1ab7>
     ee5:      	movl	0x10(%r12), %eax
     eea:      	movl	%eax, 0x38(%rsp)
     eee:      	movl	$0x0, 0x70(%rsp)
     ef6:      	movl	$0x1, %eax
     efb:      	leaq	0x38(%rsp), %rsi
     f00:      	movq	(%rip), %rdi            # 0xf07 <generic_retkprobe_filter_arg+0xf07>
     f07:      	callq	*%rax
     f09:      	testl	%ebp, %ebp
     f0b:      	je	0x3341 <generic_retkprobe_filter_arg+0x3341>
     f11:      	movq	%rax, %r15
     f14:      	movl	$0x0, %ebx
     f19:      	testq	%rax, %rax
     f1c:      	je	0x3343 <generic_retkprobe_filter_arg+0x3343>
     f22:      	movl	$0x1, %eax
     f27:      	movq	0x20(%rsp), %rsi
     f2c:      	movq	(%rip), %rdi            # 0xf33 <generic_retkprobe_filter_arg+0xf33>
     f33:      	callq	*%rax
     f35:      	testq	%rax, %rax
     f38:      	je	0x3341 <generic_retkprobe_filter_arg+0x3341>
     f3e:      	cmpl	$0xff, %ebp
     f44:      	movl	$0xff, %ecx
     f49:      	cmovael	%ecx, %ebp
     f4c:      	leal	(,%rbp,8), %ecx
     f53:      	movl	%ecx, (%rax)
     f55:      	movq	%rax, %rdi
     f58:      	addq	$0x4, %rdi
     f5c:      	movq	%rax, %rbx
     f5f:      	movl	$0x4, %eax
     f64:      	movq	0x18(%rsp), %rdx
     f69:      	movl	%ebp, %esi
     f6b:      	callq	*%rax
     f6d:      	movl	$0x1, %eax
     f72:      	movq	%r15, %rdi
     f75:      	movq	%rbx, %rsi
     f78:      	jmp	0x3335 <generic_retkprobe_filter_arg+0x3335>
     f7d:      	movl	$0x0, 0x70(%rsp)
     f85:      	cmpl	$0x1000, %ebp           # imm = 0x1000
     f8b:      	jbe	0x14eb <generic_retkprobe_filter_arg+0x14eb>
     f91:      	xorl	%ebx, %ebx
     f93:      	jmp	0x3351 <generic_retkprobe_filter_arg+0x3351>
     f98:      	cmpl	$0xd, %eax
     f9b:      	je	0x1374 <generic_retkprobe_filter_arg+0x1374>
     fa1:      	cmpl	$0xe, %eax
     fa4:      	je	0x1367 <generic_retkprobe_filter_arg+0x1367>
     faa:      	movl	$0x0, %ebx
     faf:      	cmpl	$0xf, %eax
     fb2:      	je	0x12fb <generic_retkprobe_filter_arg+0x12fb>
     fb8:      	jmp	0x1bc9 <generic_retkprobe_filter_arg+0x1bc9>
     fbd:      	movq	0x10(%r12), %rsi
     fc2:      	movq	0x18(%r12), %rax
     fc7:      	cmpl	$0xc, %ecx
     fca:      	je	0xfd5 <generic_retkprobe_filter_arg+0xfd5>
     fcc:      	cmpl	$0xa, %ecx
     fcf:      	jne	0x1af8 <generic_retkprobe_filter_arg+0x1af8>
     fd5:      	movq	(%r15), %rdx
     fd8:      	cmpq	%rdx, %rsi
     fdb:      	setle	%sil
     fdf:      	cmpq	%rax, %rdx
     fe2:      	setle	%al
     fe5:      	jmp	0x1b08 <generic_retkprobe_filter_arg+0x1b08>
     fea:      	cmpl	$0xc, %eax
     fed:      	jne	0x21da <generic_retkprobe_filter_arg+0x21da>
     ff3:      	testl	%edx, (%r15)
     ff6:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
     ffc:      	jmp	0x21da <generic_retkprobe_filter_arg+0x21da>
    1001:      	movl	$0xc00, %edx            # imm = 0xC00
    1006:      	btq	%rcx, %rdx
    100a:      	jb	0x1600 <generic_retkprobe_filter_arg+0x1600>
    1010:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
    101a:      	btq	%rcx, %rdx
    101e:      	jae	0xb8 <generic_retkprobe_filter_arg+0xb8>
    1024:      	cmpl	$0x1f, %eax
    1027:      	jne	0x1d9f <generic_retkprobe_filter_arg+0x1d9f>
    102d:      	movzbl	(%r15), %eax
    1031:      	jmp	0x1063 <generic_retkprobe_filter_arg+0x1063>
    1033:      	movl	$0xc00, %edx            # imm = 0xC00
    1038:      	btq	%rcx, %rdx
    103c:      	jb	0x1641 <generic_retkprobe_filter_arg+0x1641>
    1042:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
    104c:      	btq	%rcx, %rdx
    1050:      	jae	0xb8 <generic_retkprobe_filter_arg+0xb8>
    1056:      	cmpl	$0x1f, %eax
    1059:      	jne	0x1daa <generic_retkprobe_filter_arg+0x1daa>
    105f:      	movzwl	(%r15), %eax
    1063:      	cmpl	%eax, 0x10(%r12)
    1068:      	ja	0x1075 <generic_retkprobe_filter_arg+0x1075>
    106a:      	cmpl	%eax, 0x14(%r12)
    106f:      	jae	0x271 <generic_retkprobe_filter_arg+0x271>
    1075:      	movl	0x8(%r12), %ecx
    107a:      	cmpl	$0x11, %ecx
    107d:      	jb	0xb8 <generic_retkprobe_filter_arg+0xb8>
    1083:      	cmpl	%eax, 0x18(%r12)
    1088:      	ja	0x1095 <generic_retkprobe_filter_arg+0x1095>
    108a:      	cmpl	%eax, 0x1c(%r12)
    108f:      	jae	0x271 <generic_retkprobe_filter_arg+0x271>
    1095:      	cmpl	$0x19, %ecx
    1098:      	jb	0xb8 <generic_retkprobe_filter_arg+0xb8>
    109e:      	cmpl	%eax, 0x20(%r12)
    10a3:      	ja	0x10b0 <generic_retkprobe_filter_arg+0x10b0>
    10a5:      	cmpl	%eax, 0x24(%r12)
    10aa:      	jae	0x271 <generic_retkprobe_filter_arg+0x271>
    10b0:      	cmpl	$0x21, %ecx
    10b3:      	jb	0xb8 <generic_retkprobe_filter_arg+0xb8>
    10b9:      	cmpl	%eax, 0x28(%r12)
    10be:      	ja	0xb8 <generic_retkprobe_filter_arg+0xb8>
    10c4:      	cmpl	%eax, 0x2c(%r12)
    10c9:      	jae	0x271 <generic_retkprobe_filter_arg+0x271>
    10cf:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
    10d4:      	cmpl	$0xc, %ecx
    10d7:      	je	0x10e2 <generic_retkprobe_filter_arg+0x10e2>
    10d9:      	cmpl	$0xa, %ecx
    10dc:      	jne	0x1ca4 <generic_retkprobe_filter_arg+0x1ca4>
    10e2:      	cmpq	%rdx, (%r15)
    10e5:      	jg	0x271 <generic_retkprobe_filter_arg+0x271>
    10eb:      	jmp	0x1cb8 <generic_retkprobe_filter_arg+0x1cb8>
    10f0:      	movzwl	%bp, %eax
    10f3:      	cmpl	$0x90, %eax
    10f8:      	ja	0x16d8 <generic_retkprobe_filter_arg+0x16d8>
    10fe:      	testw	%bp, %bp
    1101:      	je	0x1113 <generic_retkprobe_filter_arg+0x1113>
    1103:      	movl	%ebp, %eax
    1105:      	movl	$0x18, %ecx
    110a:      	cltd
    110b:      	idivl	%ecx
    110d:      	movl	%ebp, %esi
    110f:      	testl	%edx, %edx
    1111:      	je	0x1135 <generic_retkprobe_filter_arg+0x1135>
    1113:      	movl	%ebp, %eax
    1115:      	movl	$0x18, %ecx
    111a:      	cltd
    111b:      	idivl	%ecx
    111d:      	shll	$0x3, %eax
    1120:      	leal	(%rax,%rax,2), %eax
    1123:      	addl	$0x18, %eax
    1126:      	movzwl	%ax, %esi
    1129:      	cmpl	$0x90, %esi
    112f:      	ja	0x1710 <generic_retkprobe_filter_arg+0x1710>
    1135:      	movl	%esi, %eax
    1137:      	cltd
    1138:      	idivl	%ecx
    113a:      	decl	%eax
    113c:      	jmp	0x22dc <generic_retkprobe_filter_arg+0x22dc>
    1141:      	cmpl	$0x20, %eax
    1144:      	jg	0x1827 <generic_retkprobe_filter_arg+0x1827>
    114a:      	cmpl	$0x1a, %eax
    114d:      	je	0x19f5 <generic_retkprobe_filter_arg+0x19f5>
    1153:      	movl	$0x0, %ebx
    1158:      	cmpl	$0x1b, %eax
    115b:      	jne	0x3640 <generic_retkprobe_filter_arg+0x3640>
    1161:      	movl	0x10(%r12), %eax
    1166:      	movl	%eax, 0x38(%rsp)
    116a:      	movl	$0x0, 0x70(%rsp)
    1172:      	movl	$0x1, %eax
    1177:      	leaq	0x38(%rsp), %rsi
    117c:      	movq	(%rip), %rdi            # 0x1183 <generic_retkprobe_filter_arg+0x1183>
    1183:      	callq	*%rax
    1185:      	testl	%ebp, %ebp
    1187:      	je	0x3630 <generic_retkprobe_filter_arg+0x3630>
    118d:      	movq	%rax, %r15
    1190:      	movl	$0x0, %ebx
    1195:      	testq	%rax, %rax
    1198:      	je	0x3632 <generic_retkprobe_filter_arg+0x3632>
    119e:      	movl	$0x1, %eax
    11a3:      	movq	0x20(%rsp), %rsi
    11a8:      	movq	(%rip), %rdi            # 0x11af <generic_retkprobe_filter_arg+0x11af>
    11af:      	callq	*%rax
    11b1:      	testq	%rax, %rax
    11b4:      	je	0x3630 <generic_retkprobe_filter_arg+0x3630>
    11ba:      	movq	%rax, %rsi
    11bd:      	movq	%r15, 0x18(%rsp)
    11c2:      	cmpl	$0x7f, %ebp
    11c5:      	movl	$0x7f, %eax
    11ca:      	cmovbl	%ebp, %eax
    11cd:      	shll	$0x3, %eax
    11d0:      	movl	%eax, (%rsi)
    11d2:      	movq	%rbp, %rax
    11d5:      	negq	%rax
    11d8:      	movl	$0x3, %ecx
    11dd:      	subq	%rbp, %rcx
    11e0:      	leal	-0x4(%rbp), %edx
    11e3:      	movq	%rsi, %rdi
    11e6:      	addq	$0x7, %rdi
    11ea:      	movl	$0x2, %r8d
    11f0:      	subq	%rbp, %r8
    11f3:      	leal	-0x3(%rbp), %r9d
    11f7:      	movl	$0x1, %r10d
    11fd:      	subq	%rbp, %r10
    1200:      	leal	-0x2(%rbp), %r11d
    1204:      	decl	%ebp
    1206:      	xorl	%ebx, %ebx
    1208:      	movq	%r13, %r15
    120b:      	leal	(%rbx,%rbp), %r13d
    120f:      	andl	$0xfff, %r13d           # imm = 0xFFF
    1216:      	movzbl	(%r15,%r13), %r13d
    121b:      	movb	%r13b, -0x3(%rdi)
    121f:      	cmpq	%rbx, %r10
    1222:      	je	0x127c <generic_retkprobe_filter_arg+0x127c>
    1224:      	leal	(%r11,%rbx), %r13d
    1228:      	andl	$0xfff, %r13d           # imm = 0xFFF
    122f:      	movzbl	(%r15,%r13), %r13d
    1234:      	movb	%r13b, -0x2(%rdi)
    1238:      	cmpq	%rbx, %r8
    123b:      	je	0x127c <generic_retkprobe_filter_arg+0x127c>
    123d:      	leal	(%r9,%rbx), %r13d
    1241:      	andl	$0xfff, %r13d           # imm = 0xFFF
    1248:      	movzbl	(%r15,%r13), %r13d
    124d:      	movb	%r13b, -0x1(%rdi)
    1251:      	cmpq	%rbx, %rcx
    1254:      	je	0x127c <generic_retkprobe_filter_arg+0x127c>
    1256:      	cmpq	$-0x7c, %rbx
    125a:      	je	0x127c <generic_retkprobe_filter_arg+0x127c>
    125c:      	leal	(%rdx,%rbx), %r13d
    1260:      	andl	$0xfff, %r13d           # imm = 0xFFF
    1267:      	movzbl	(%r15,%r13), %r13d
    126c:      	movb	%r13b, (%rdi)
    126f:      	addq	$-0x4, %rbx
    1273:      	addq	$0x4, %rdi
    1277:      	cmpq	%rbx, %rax
    127a:      	jne	0x120b <generic_retkprobe_filter_arg+0x120b>
    127c:      	movl	$0x1, %eax
    1281:      	movq	0x18(%rsp), %rdi
    1286:      	jmp	0x3624 <generic_retkprobe_filter_arg+0x3624>
    128b:      	movl	0x10(%r12), %esi
    1290:      	movl	0x14(%r12), %eax
    1295:      	cmpl	$0xc, %ecx
    1298:      	ja	0x1f4b <generic_retkprobe_filter_arg+0x1f4b>
    129e:      	movl	$0x1402, %edx           # imm = 0x1402
    12a3:      	btl	%ecx, %edx
    12a6:      	jae	0x1f4b <generic_retkprobe_filter_arg+0x1f4b>
    12ac:      	movl	(%r15), %edx
    12af:      	cmpl	%edx, %esi
    12b1:      	setle	%sil
    12b5:      	cmpl	%eax, %edx
    12b7:      	setle	%al
    12ba:      	jmp	0x1f59 <generic_retkprobe_filter_arg+0x1f59>
    12bf:      	cmpl	$0x1c, %eax
    12c2:      	je	0x195e <generic_retkprobe_filter_arg+0x195e>
    12c8:      	movq	%r8, 0x18(%rsp)
    12cd:      	movq	%rsi, %r15
    12d0:      	cmpl	$0x1a, %eax
    12d3:      	je	0x18ca <generic_retkprobe_filter_arg+0x18ca>
    12d9:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
    12de:      	cmpl	$0x12, %eax
    12e1:      	je	0x12fb <generic_retkprobe_filter_arg+0x12fb>
    12e3:      	movl	$0x0, %ebx
    12e8:      	cmpl	$0x13, %eax
    12eb:      	jne	0x1bc9 <generic_retkprobe_filter_arg+0x1bc9>
    12f1:      	movq	%r15, %rdx
    12f4:      	movzwl	0x22(%r15), %r13d
    12f9:      	jmp	0x1303 <generic_retkprobe_filter_arg+0x1303>
    12fb:      	movq	%r15, %rdx
    12fe:      	movzwl	0x20(%r15), %r13d
    1303:      	xorl	%esi, %esi
    1305:      	xorl	%ebp, %ebp
    1307:      	xorl	%r15d, %r15d
    130a:      	xorl	%ebx, %ebx
    130c:      	cmpl	$0x11, %eax
    130f:      	jg	0x138f <generic_retkprobe_filter_arg+0x138f>
    1311:      	leal	-0xd(%rax), %ecx
    1314:      	cmpl	$0x2, %ecx
    1317:      	jb	0x13c2 <generic_retkprobe_filter_arg+0x13c2>
    131d:      	leal	-0xf(%rax), %ecx
    1320:      	cmpl	$0x2, %ecx
    1323:      	jb	0x1548 <generic_retkprobe_filter_arg+0x1548>
    1329:      	cmpl	$0x11, %eax
    132c:      	je	0x1b49 <generic_retkprobe_filter_arg+0x1b49>
    1332:      	jmp	0x1bc9 <generic_retkprobe_filter_arg+0x1bc9>
    1337:      	cmpl	$0x1c, %eax
    133a:      	je	0x1b44 <generic_retkprobe_filter_arg+0x1b44>
    1340:      	movl	$0x0, %ebx
    1345:      	cmpl	$0x1d, %eax
    1348:      	jne	0x1bc9 <generic_retkprobe_filter_arg+0x1bc9>
    134e:      	cmpl	$0x7, %ecx
    1351:      	jne	0x20df <generic_retkprobe_filter_arg+0x20df>
    1357:      	testq	%rdx, %rdx
    135a:      	jne	0x20eb <generic_retkprobe_filter_arg+0x20eb>
    1360:      	xorl	%ebx, %ebx
    1362:      	jmp	0x20fd <generic_retkprobe_filter_arg+0x20fd>
    1367:      	movq	0x10(%r15), %rsi
    136b:      	movq	%r15, %rdx
    136e:      	movq	0x18(%r15), %r15
    1372:      	jmp	0x137e <generic_retkprobe_filter_arg+0x137e>
    1374:      	movq	(%r15), %rsi
    1377:      	movq	%r15, %rdx
    137a:      	movq	0x8(%r15), %r15
    137e:      	movq	%rsi, %rbp
    1381:      	shrq	$0x20, %rbp
    1385:      	xorl	%r13d, %r13d
    1388:      	xorl	%ebx, %ebx
    138a:      	cmpl	$0x11, %eax
    138d:      	jle	0x1311 <generic_retkprobe_filter_arg+0x1311>
    138f:      	cmpl	$0x19, %eax
    1392:      	ja	0x153c <generic_retkprobe_filter_arg+0x153c>
    1398:      	movl	$0x500000, %ecx         # imm = 0x500000
    139d:      	btl	%eax, %ecx
    13a0:      	jb	0x1682 <generic_retkprobe_filter_arg+0x1682>
    13a6:      	movl	$0xa00000, %ecx         # imm = 0xA00000
    13ab:      	btl	%eax, %ecx
    13ae:      	jb	0x169a <generic_retkprobe_filter_arg+0x169a>
    13b4:      	movl	$0x3000000, %ecx        # imm = 0x3000000
    13b9:      	btl	%eax, %ecx
    13bc:      	jae	0x153c <generic_retkprobe_filter_arg+0x153c>
    13c2:      	movzwl	0x26(%rdx), %eax
    13c6:      	cmpl	$0xa, %eax
    13c9:      	je	0x1740 <generic_retkprobe_filter_arg+0x1740>
    13cf:      	cmpl	$0x2, %eax
    13d2:      	jne	0x17d2 <generic_retkprobe_filter_arg+0x17d2>
    13d8:      	movq	%rsi, %rbx
    13db:      	movl	0x10(%r12), %eax
    13e0:      	movl	%eax, 0x34(%rsp)
    13e4:      	movl	$0x1, %eax
    13e9:      	leaq	0x34(%rsp), %rsi
    13ee:      	movq	(%rip), %rdi            # 0x13f5 <generic_retkprobe_filter_arg+0x13f5>
    13f5:      	callq	*%rax
    13f7:      	testq	%rax, %rax
    13fa:      	je	0x1c10 <generic_retkprobe_filter_arg+0x1c10>
    1400:      	movq	%rax, %rdi
    1403:      	movl	$0x20, 0x70(%rsp)
    140b:      	movl	%ebx, 0x74(%rsp)
    140f:      	jmp	0x178c <generic_retkprobe_filter_arg+0x178c>
    1414:      	cmpl	$0xc, %ecx
    1417:      	ja	0x21c6 <generic_retkprobe_filter_arg+0x21c6>
    141d:      	movl	$0x1402, %esi           # imm = 0x1402
    1422:      	btl	%ecx, %esi
    1425:      	jae	0x21c6 <generic_retkprobe_filter_arg+0x21c6>
    142b:      	cmpl	%edx, (%r15)
    142e:      	jg	0x271 <generic_retkprobe_filter_arg+0x271>
    1434:      	jmp	0x21da <generic_retkprobe_filter_arg+0x21da>
    1439:      	xorl	%ebx, %ebx
    143b:      	xorl	%r13d, %r13d
    143e:      	movl	0x10(%r12,%rbx,4), %eax
    1443:      	movl	%eax, 0x38(%rsp)
    1447:      	movl	$0x1, %eax
    144c:      	leaq	0x38(%rsp), %rsi
    1451:      	movq	(%rip), %rdi            # 0x1458 <generic_retkprobe_filter_arg+0x1458>
    1458:      	callq	*%rax
    145a:      	testq	%rax, %rax
    145d:      	je	0x2152 <generic_retkprobe_filter_arg+0x2152>
    1463:      	testl	%ebp, %ebp
    1465:      	movq	0x8(%rsp), %r9
    146a:      	movq	0x10(%rsp), %r11
    146f:      	je	0x14bf <generic_retkprobe_filter_arg+0x14bf>
    1471:      	movq	0x18(%rsp), %rdx
    1476:      	xorl	%ecx, %ecx
    1478:      	jmp	0x1485 <generic_retkprobe_filter_arg+0x1485>
    147a:      	incq	%rcx
    147d:      	incq	%rdx
    1480:      	cmpq	%rbp, %rcx
    1483:      	je	0x14bf <generic_retkprobe_filter_arg+0x14bf>
    1485:      	xorl	%esi, %esi
    1487:      	nopw	(%rax,%rax)
    1490:      	leaq	(%rcx,%rsi), %rdi
    1494:      	cmpq	%rbp, %rdi
    1497:      	jae	0x147a <generic_retkprobe_filter_arg+0x147a>
    1499:      	movzbl	(%rax,%rsi), %edi
    149d:      	testb	%dil, %dil
    14a0:      	je	0x14b7 <generic_retkprobe_filter_arg+0x14b7>
    14a2:      	cmpq	$0x62, %rsi
    14a6:      	ja	0x147a <generic_retkprobe_filter_arg+0x147a>
    14a8:      	leaq	0x1(%rsi), %r8
    14ac:      	cmpb	%dil, (%rdx,%rsi)
    14b0:      	movq	%r8, %rsi
    14b3:      	je	0x1490 <generic_retkprobe_filter_arg+0x1490>
    14b5:      	jmp	0x147a <generic_retkprobe_filter_arg+0x147a>
    14b7:      	testl	%ecx, %ecx
    14b9:      	jns	0x260b <generic_retkprobe_filter_arg+0x260b>
    14bf:      	leal	0xc(%r13), %eax
    14c3:      	cmpl	0x8(%r12), %eax
    14c8:      	jae	0x14db <generic_retkprobe_filter_arg+0x14db>
    14ca:      	addl	$0x4, %r13d
    14ce:      	incq	%rbx
    14d1:      	cmpq	$0x64, %rbx
    14d5:      	jne	0x143e <generic_retkprobe_filter_arg+0x143e>
    14db:      	xorl	%ebx, %ebx
    14dd:      	movq	0x28(%rsp), %r13
    14e2:      	movq	(%rsp), %rdi
    14e6:      	jmp	0x3351 <generic_retkprobe_filter_arg+0x3351>
    14eb:      	movzwl	%bp, %eax
    14ee:      	cmpl	$0x90, %eax
    14f3:      	ja	0x1c3c <generic_retkprobe_filter_arg+0x1c3c>
    14f9:      	testw	%bp, %bp
    14fc:      	je	0x150e <generic_retkprobe_filter_arg+0x150e>
    14fe:      	movl	%ebp, %eax
    1500:      	movl	$0x18, %ecx
    1505:      	cltd
    1506:      	idivl	%ecx
    1508:      	movl	%ebp, %esi
    150a:      	testl	%edx, %edx
    150c:      	je	0x1530 <generic_retkprobe_filter_arg+0x1530>
    150e:      	movl	%ebp, %eax
    1510:      	movl	$0x18, %ecx
    1515:      	cltd
    1516:      	idivl	%ecx
    1518:      	shll	$0x3, %eax
    151b:      	leal	(%rax,%rax,2), %eax
    151e:      	addl	$0x18, %eax
    1521:      	movzwl	%ax, %esi
    1524:      	cmpl	$0x90, %esi
    152a:      	ja	0x1c74 <generic_retkprobe_filter_arg+0x1c74>
    1530:      	movl	%esi, %eax
    1532:      	cltd
    1533:      	idivl	%ecx
    1535:      	decl	%eax
    1537:      	jmp	0x288d <generic_retkprobe_filter_arg+0x288d>
    153c:      	addl	$-0x12, %eax
    153f:      	cmpl	$0x2, %eax
    1542:      	jae	0x1bc9 <generic_retkprobe_filter_arg+0x1bc9>
    1548:      	movzbl	0x10(%r12), %eax
    154e:      	movl	%eax, 0x34(%rsp)
    1552:      	movl	$0x1, %eax
    1557:      	movq	(%rip), %rdi            # 0x155e <generic_retkprobe_filter_arg+0x155e>
    155e:      	leaq	0x34(%rsp), %rsi
    1563:      	callq	*%rax
    1565:      	testq	%rax, %rax
    1568:      	je	0x2138 <generic_retkprobe_filter_arg+0x2138>
    156e:      	movq	%rax, %rdi
    1571:      	movzwl	%r13w, %eax
    1575:      	movq	%rax, 0x70(%rsp)
    157a:      	movl	$0x1, %eax
    157f:      	movq	0x20(%rsp), %rsi
    1584:      	jmp	0x1b84 <generic_retkprobe_filter_arg+0x1b84>
    1589:      	leal	-0x100(%r13), %eax
    1590:      	rorxl	$0x8, %eax, %eax
    1596:      	cmpl	$0x2, %eax
    1599:      	jg	0x1d67 <generic_retkprobe_filter_arg+0x1d67>
    159f:      	testl	%eax, %eax
    15a1:      	je	0x246d <generic_retkprobe_filter_arg+0x246d>
    15a7:      	cmpl	$0x1, %eax
    15aa:      	jne	0x2466 <generic_retkprobe_filter_arg+0x2466>
    15b0:      	movl	$0x7, %eax
    15b5:      	jmp	0x2479 <generic_retkprobe_filter_arg+0x2479>
    15ba:      	cmpl	$0x1, %eax
    15bd:      	je	0x1e68 <generic_retkprobe_filter_arg+0x1e68>
    15c3:      	cmpl	$0x2, %eax
    15c6:      	jne	0x1e74 <generic_retkprobe_filter_arg+0x1e74>
    15cc:      	movzbl	(%r15), %edx
    15d0:      	cmpl	%edx, %ecx
    15d2:      	ja	0x271 <generic_retkprobe_filter_arg+0x271>
    15d8:      	jmp	0x1e74 <generic_retkprobe_filter_arg+0x1e74>
    15dd:      	cmpl	$0x1, %eax
    15e0:      	je	0x1ead <generic_retkprobe_filter_arg+0x1ead>
    15e6:      	cmpl	$0x2, %eax
    15e9:      	jne	0x1eb9 <generic_retkprobe_filter_arg+0x1eb9>
    15ef:      	movzwl	(%r15), %edx
    15f3:      	cmpl	%edx, %ecx
    15f5:      	ja	0x271 <generic_retkprobe_filter_arg+0x271>
    15fb:      	jmp	0x1eb9 <generic_retkprobe_filter_arg+0x1eb9>
    1600:      	movzbl	0x10(%r12), %eax
    1606:      	movl	%eax, 0x70(%rsp)
    160a:      	movl	$0x1, %eax
    160f:      	movq	0x20(%rsp), %rsi
    1614:      	movq	(%rip), %rdi            # 0x161b <generic_retkprobe_filter_arg+0x161b>
    161b:      	callq	*%rax
    161d:      	testq	%rax, %rax
    1620:      	je	0x19c8 <generic_retkprobe_filter_arg+0x19c8>
    1626:      	movq	%rax, %rdi
    1629:      	movzbl	(%r15), %eax
    162d:      	movq	%rax, 0x38(%rsp)
    1632:      	movl	$0x1, %eax
    1637:      	leaq	0x38(%rsp), %rsi
    163c:      	jmp	0x1996 <generic_retkprobe_filter_arg+0x1996>
    1641:      	movzbl	0x10(%r12), %eax
    1647:      	movl	%eax, 0x70(%rsp)
    164b:      	movl	$0x1, %eax
    1650:      	movq	0x20(%rsp), %rsi
    1655:      	movq	(%rip), %rdi            # 0x165c <generic_retkprobe_filter_arg+0x165c>
    165c:      	callq	*%rax
    165e:      	testq	%rax, %rax
    1661:      	je	0x19c8 <generic_retkprobe_filter_arg+0x19c8>
    1667:      	movq	%rax, %rdi
    166a:      	movzwl	(%r15), %eax
    166e:      	movq	%rax, 0x38(%rsp)
    1673:      	movl	$0x1, %eax
    1678:      	leaq	0x38(%rsp), %rsi
    167d:      	jmp	0x1996 <generic_retkprobe_filter_arg+0x1996>
    1682:      	movzwl	%r13w, %eax
    1686:      	xorl	%ebx, %ebx
    1688:      	cmpl	$0x400, %eax            # imm = 0x400
    168d:      	setb	%bl
    1690:      	movq	0x28(%rsp), %r13
    1695:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    169a:      	movzwl	%r13w, %eax
    169e:      	xorl	%ebx, %ebx
    16a0:      	cmpl	$0x400, %eax            # imm = 0x400
    16a5:      	setae	%bl
    16a8:      	movq	0x28(%rsp), %r13
    16ad:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    16b2:      	testq	%rax, %rax
    16b5:      	sete	%al
    16b8:      	movq	(%rsp), %rdi
    16bc:      	movq	0x8(%rsp), %r9
    16c1:      	movq	0x10(%rsp), %r11
    16c6:      	movzbl	%al, %ebx
    16c9:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    16ce:      	xorl	%eax, %eax
    16d0:      	movzbl	%al, %ebx
    16d3:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    16d8:      	movl	$0x100, %esi            # imm = 0x100
    16dd:      	cmpl	$0x101, %eax            # imm = 0x101
    16e2:      	jb	0x1710 <generic_retkprobe_filter_arg+0x1710>
    16e4:      	movl	$0x200, %esi            # imm = 0x200
    16e9:      	cmpl	$0x201, %eax            # imm = 0x201
    16ee:      	jb	0x1710 <generic_retkprobe_filter_arg+0x1710>
    16f0:      	movl	$0x400, %esi            # imm = 0x400
    16f5:      	cmpl	$0x401, %eax            # imm = 0x401
    16fa:      	jb	0x1710 <generic_retkprobe_filter_arg+0x1710>
    16fc:      	xorl	%esi, %esi
    16fe:      	cmpl	$0x801, %eax            # imm = 0x801
    1703:      	setae	%sil
    1707:      	shll	$0xb, %esi
    170a:      	addl	$0x800, %esi            # imm = 0x800
    1710:      	leal	-0x100(%rsi), %eax
    1716:      	rorxl	$0x8, %eax, %eax
    171c:      	cmpl	$0x2, %eax
    171f:      	jg	0x1c20 <generic_retkprobe_filter_arg+0x1c20>
    1725:      	testl	%eax, %eax
    1727:      	je	0x22d0 <generic_retkprobe_filter_arg+0x22d0>
    172d:      	cmpl	$0x1, %eax
    1730:      	jne	0x22c9 <generic_retkprobe_filter_arg+0x22c9>
    1736:      	movl	$0x7, %eax
    173b:      	jmp	0x22dc <generic_retkprobe_filter_arg+0x22dc>
    1740:      	movq	%rsi, %rbx
    1743:      	movl	0x14(%r12), %eax
    1748:      	movl	%eax, 0x34(%rsp)
    174c:      	movl	$0x1, %eax
    1751:      	movq	(%rip), %rdi            # 0x1758 <generic_retkprobe_filter_arg+0x1758>
    1758:      	leaq	0x34(%rsp), %rsi
    175d:      	callq	*%rax
    175f:      	testq	%rax, %rax
    1762:      	je	0x1c10 <generic_retkprobe_filter_arg+0x1c10>
    1768:      	movq	%rax, %rdi
    176b:      	movl	$0x80, 0x70(%rsp)
    1773:      	movl	%ebx, 0x74(%rsp)
    1777:      	movl	%ebp, 0x78(%rsp)
    177b:      	movl	%r15d, 0x7c(%rsp)
    1780:      	shrq	$0x20, %r15
    1784:      	movl	%r15d, 0x80(%rsp)
    178c:      	movl	$0x1, %eax
    1791:      	movq	0x20(%rsp), %rsi
    1796:      	callq	*%rax
    1798:      	movl	0x4(%r12), %ecx
    179d:      	leal	-0x18(%rcx), %edx
    17a0:      	cmpl	$0x2, %edx
    17a3:      	jb	0x1e2b <generic_retkprobe_filter_arg+0x1e2b>
    17a9:      	addl	$-0xd, %ecx
    17ac:      	cmpl	$0x1, %ecx
    17af:      	movq	(%rsp), %rdi
    17b3:      	movq	0x8(%rsp), %r9
    17b8:      	movq	0x10(%rsp), %r11
    17bd:      	ja	0x17d2 <generic_retkprobe_filter_arg+0x17d2>
    17bf:      	testq	%rax, %rax
    17c2:      	setne	%al
    17c5:      	movzbl	%al, %ebx
    17c8:      	movq	0x28(%rsp), %r13
    17cd:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    17d2:      	xorl	%eax, %eax
    17d4:      	movzbl	%al, %ebx
    17d7:      	movq	0x28(%rsp), %r13
    17dc:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    17e1:      	cmpl	$0x1e, %eax
    17e4:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    17ea:      	movl	0x10(%r12), %eax
    17ef:      	andl	$0x7, %eax
    17f2:      	movl	%eax, %ecx
    17f4:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
    17fd:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    1803:      	movq	(%r15), %rcx
    1806:      	movq	0x5e78(%r14,%rax,8), %rax
    180e:      	andl	$0x7ff, %eax            # imm = 0x7FF
    1813:      	xorl	%ebx, %ebx
    1815:      	andnq	0x90(%r14,%rax), %rcx, %rax
    181f:      	setne	%bl
    1822:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    1827:      	movq	%r13, 0x18(%rsp)
    182c:      	cmpl	$0x21, %eax
    182f:      	je	0x1f9f <generic_retkprobe_filter_arg+0x1f9f>
    1835:      	movl	$0x0, %ebx
    183a:      	cmpl	$0x22, %eax
    183d:      	jne	0x3640 <generic_retkprobe_filter_arg+0x3640>
    1843:      	movl	$0x10, %r13d
    1849:      	movl	(%r12,%r13), %eax
    184d:      	movl	%eax, 0x38(%rsp)
    1851:      	movl	$0x1, %eax
    1856:      	leaq	0x38(%rsp), %rsi
    185b:      	movq	(%rip), %rdi            # 0x1862 <generic_retkprobe_filter_arg+0x1862>
    1862:      	callq	*%rax
    1864:      	testq	%rax, %rax
    1867:      	je	0x3630 <generic_retkprobe_filter_arg+0x3630>
    186d:      	movq	0x18(%rsp), %rdi
    1872:      	movq	%rax, %rsi
    1875:      	movq	%rbp, %rdx
    1878:      	callq	0x187d <generic_retkprobe_filter_arg+0x187d>
    187d:      	testl	%eax, %eax
    187f:      	jns	0x2c4c <generic_retkprobe_filter_arg+0x2c4c>
    1885:      	addq	$0x4, %r13
    1889:      	leal	-0x8(%r13), %eax
    188d:      	cmpl	0x8(%r12), %eax
    1892:      	movq	(%rsp), %rdi
    1896:      	movq	0x8(%rsp), %r9
    189b:      	movq	0x10(%rsp), %r11
    18a0:      	jae	0x1a9f <generic_retkprobe_filter_arg+0x1a9f>
    18a6:      	movl	$0x0, %ebx
    18ab:      	cmpq	$0x1a0, %r13            # imm = 0x1A0
    18b2:      	jne	0x1849 <generic_retkprobe_filter_arg+0x1849>
    18b4:      	jmp	0x3640 <generic_retkprobe_filter_arg+0x3640>
    18b9:      	movq	%r8, 0x18(%rsp)
    18be:      	movq	%rsi, %r15
    18c1:      	cmpl	$0x8, %eax
    18c4:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    18ca:      	movl	0x10(%r12), %eax
    18cf:      	movl	%eax, 0x38(%rsp)
    18d3:      	movl	$0x0, 0x70(%rsp)
    18db:      	movl	$0x1, %eax
    18e0:      	leaq	0x38(%rsp), %rsi
    18e5:      	movq	(%rip), %rdi            # 0x18ec <generic_retkprobe_filter_arg+0x18ec>
    18ec:      	callq	*%rax
    18ee:      	testb	%bpl, %bpl
    18f1:      	je	0x1bd3 <generic_retkprobe_filter_arg+0x1bd3>
    18f7:      	movq	%rax, %r13
    18fa:      	movl	$0x0, %ebx
    18ff:      	testq	%rax, %rax
    1902:      	je	0x1bd5 <generic_retkprobe_filter_arg+0x1bd5>
    1908:      	movl	$0x1, %eax
    190d:      	movq	0x20(%rsp), %rsi
    1912:      	movq	(%rip), %rdi            # 0x1919 <generic_retkprobe_filter_arg+0x1919>
    1919:      	callq	*%rax
    191b:      	testq	%rax, %rax
    191e:      	je	0x1bd3 <generic_retkprobe_filter_arg+0x1bd3>
    1924:      	movq	%r15, %rsi
    1927:      	movl	%esi, %ecx
    1929:      	shll	$0x3, %ecx
    192c:      	movl	%ecx, (%rax)
    192e:      	movq	%rax, %rdi
    1931:      	addq	$0x4, %rdi
    1935:      	movq	%rax, %rbx
    1938:      	movl	$0x4, %eax
    193d:      	movq	0x18(%rsp), %rdx
    1942:      	callq	*%rax
    1944:      	movl	$0x1, %eax
    1949:      	movq	%r13, %rdi
    194c:      	movq	%rbx, %rsi
    194f:      	callq	*%rax
    1951:      	xorl	%ebx, %ebx
    1953:      	testq	%rax, %rax
    1956:      	setne	%bl
    1959:      	jmp	0x1bd5 <generic_retkprobe_filter_arg+0x1bd5>
    195e:      	movzwl	(%r15), %ebx
    1962:      	movzbl	0x10(%r12), %eax
    1968:      	movl	%eax, 0x70(%rsp)
    196c:      	movl	$0x1, %eax
    1971:      	movq	0x20(%rsp), %rsi
    1976:      	movq	(%rip), %rdi            # 0x197d <generic_retkprobe_filter_arg+0x197d>
    197d:      	callq	*%rax
    197f:      	testq	%rax, %rax
    1982:      	je	0x19c8 <generic_retkprobe_filter_arg+0x19c8>
    1984:      	movq	%rax, %rdi
    1987:      	movq	%rbx, 0x38(%rsp)
    198c:      	movl	$0x1, %eax
    1991:      	leaq	0x38(%rsp), %rsi
    1996:      	callq	*%rax
    1998:      	movl	0x4(%r12), %edx
    199d:      	xorl	%ecx, %ecx
    199f:      	cmpl	$0x1d, %edx
    19a2:      	ja	0x2793 <generic_retkprobe_filter_arg+0x2793>
    19a8:      	movl	$0x30038400, %esi       # imm = 0x30038400
    19ad:      	btl	%edx, %esi
    19b0:      	movq	(%rsp), %rdi
    19b4:      	movq	0x8(%rsp), %r9
    19b9:      	movq	0x10(%rsp), %r11
    19be:      	jae	0x19dd <generic_retkprobe_filter_arg+0x19dd>
    19c0:      	testq	%rax, %rax
    19c3:      	setne	%cl
    19c6:      	jmp	0x19ed <generic_retkprobe_filter_arg+0x19ed>
    19c8:      	xorl	%ebx, %ebx
    19ca:      	movq	(%rsp), %rdi
    19ce:      	movq	0x8(%rsp), %r9
    19d3:      	movq	0x10(%rsp), %r11
    19d8:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    19dd:      	movl	$0xc0800, %esi          # imm = 0xC0800
    19e2:      	btl	%edx, %esi
    19e5:      	jae	0x19ed <generic_retkprobe_filter_arg+0x19ed>
    19e7:      	testq	%rax, %rax
    19ea:      	sete	%cl
    19ed:      	movzbl	%cl, %ebx
    19f0:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    19f5:      	movl	0x10(%r12), %eax
    19fa:      	movl	%eax, 0x38(%rsp)
    19fe:      	movl	$0x0, 0x70(%rsp)
    1a06:      	movl	$0x1, %eax
    1a0b:      	leaq	0x38(%rsp), %rsi
    1a10:      	movq	(%rip), %rdi            # 0x1a17 <generic_retkprobe_filter_arg+0x1a17>
    1a17:      	callq	*%rax
    1a19:      	testl	%ebp, %ebp
    1a1b:      	je	0x3630 <generic_retkprobe_filter_arg+0x3630>
    1a21:      	movq	%rax, %r15
    1a24:      	movl	$0x0, %ebx
    1a29:      	testq	%rax, %rax
    1a2c:      	je	0x3632 <generic_retkprobe_filter_arg+0x3632>
    1a32:      	movl	$0x1, %eax
    1a37:      	movq	0x20(%rsp), %rsi
    1a3c:      	movq	(%rip), %rdi            # 0x1a43 <generic_retkprobe_filter_arg+0x1a43>
    1a43:      	callq	*%rax
    1a45:      	testq	%rax, %rax
    1a48:      	je	0x3630 <generic_retkprobe_filter_arg+0x3630>
    1a4e:      	cmpl	$0xff, %ebp
    1a54:      	movl	$0xff, %ecx
    1a59:      	cmovael	%ecx, %ebp
    1a5c:      	leal	(,%rbp,8), %ecx
    1a63:      	movl	%ecx, (%rax)
    1a65:      	movq	%rax, %rdi
    1a68:      	addq	$0x4, %rdi
    1a6c:      	movq	%rax, %rbx
    1a6f:      	movl	$0x4, %eax
    1a74:      	movl	%ebp, %esi
    1a76:      	movq	%r13, %rdx
    1a79:      	callq	*%rax
    1a7b:      	movl	$0x1, %eax
    1a80:      	movq	%r15, %rdi
    1a83:      	movq	%rbx, %rsi
    1a86:      	jmp	0x3624 <generic_retkprobe_filter_arg+0x3624>
    1a8b:      	movl	$0x0, 0x70(%rsp)
    1a93:      	cmpl	$0x1000, %ebp           # imm = 0x1000
    1a99:      	jbe	0x2046 <generic_retkprobe_filter_arg+0x2046>
    1a9f:      	xorl	%ebx, %ebx
    1aa1:      	jmp	0x3640 <generic_retkprobe_filter_arg+0x3640>
    1aa6:      	movq	(%r15), %rax
    1aa9:      	cmpq	%rax, %rsi
    1aac:      	ja	0x1ab7 <generic_retkprobe_filter_arg+0x1ab7>
    1aae:      	cmpq	%rdx, %rax
    1ab1:      	jbe	0x271 <generic_retkprobe_filter_arg+0x271>
    1ab7:      	movl	0x8(%r12), %edx
    1abc:      	cmpl	$0x19, %edx
    1abf:      	jb	0xb8 <generic_retkprobe_filter_arg+0xb8>
    1ac5:      	movq	0x20(%r12), %rdi
    1aca:      	movq	0x28(%r12), %rsi
    1acf:      	cmpl	$0xc, %ecx
    1ad2:      	je	0x1add <generic_retkprobe_filter_arg+0x1add>
    1ad4:      	cmpl	$0xa, %ecx
    1ad7:      	jne	0x2178 <generic_retkprobe_filter_arg+0x2178>
    1add:      	cmpq	%rax, %rdi
    1ae0:      	movq	(%rsp), %rdi
    1ae4:      	jg	0x218a <generic_retkprobe_filter_arg+0x218a>
    1aea:      	cmpq	%rsi, %rax
    1aed:      	jle	0x271 <generic_retkprobe_filter_arg+0x271>
    1af3:      	jmp	0x218a <generic_retkprobe_filter_arg+0x218a>
    1af8:      	movq	(%r15), %rdx
    1afb:      	cmpq	%rdx, %rsi
    1afe:      	setbe	%sil
    1b02:      	cmpq	%rax, %rdx
    1b05:      	setbe	%al
    1b08:      	andb	%sil, %al
    1b0b:      	movl	0x8(%r12), %esi
    1b10:      	cmpl	$0x19, %esi
    1b13:      	jb	0x2fe6 <generic_retkprobe_filter_arg+0x2fe6>
    1b19:      	movq	0x20(%r12), %r8
    1b1e:      	movq	0x28(%r12), %rdi
    1b23:      	cmpl	$0xc, %ecx
    1b26:      	je	0x1b31 <generic_retkprobe_filter_arg+0x1b31>
    1b28:      	cmpl	$0xa, %ecx
    1b2b:      	jne	0x2097 <generic_retkprobe_filter_arg+0x2097>
    1b31:      	cmpq	%rdx, %r8
    1b34:      	setle	%r8b
    1b38:      	cmpq	%rdi, %rdx
    1b3b:      	setle	%dil
    1b3f:      	jmp	0x20a5 <generic_retkprobe_filter_arg+0x20a5>
    1b44:      	movzwl	0x26(%r15), %ebx
    1b49:      	movzbl	0x10(%r12), %eax
    1b4f:      	movl	%eax, 0x34(%rsp)
    1b53:      	movl	$0x1, %eax
    1b58:      	movq	(%rip), %rdi            # 0x1b5f <generic_retkprobe_filter_arg+0x1b5f>
    1b5f:      	leaq	0x34(%rsp), %rsi
    1b64:      	callq	*%rax
    1b66:      	testq	%rax, %rax
    1b69:      	je	0x2138 <generic_retkprobe_filter_arg+0x2138>
    1b6f:      	movq	%rax, %rdi
    1b72:      	movzwl	%bx, %eax
    1b75:      	movq	%rax, 0x70(%rsp)
    1b7a:      	movl	$0x1, %eax
    1b7f:      	movq	0x20(%rsp), %rsi
    1b84:      	callq	*%rax
    1b86:      	movl	0x4(%r12), %edx
    1b8b:      	xorl	%ecx, %ecx
    1b8d:      	cmpl	$0x1d, %edx
    1b90:      	ja	0x2a26 <generic_retkprobe_filter_arg+0x2a26>
    1b96:      	movl	$0x30038400, %esi       # imm = 0x30038400
    1b9b:      	btl	%edx, %esi
    1b9e:      	movq	(%rsp), %rdi
    1ba2:      	movq	0x8(%rsp), %r9
    1ba7:      	movq	0x10(%rsp), %r11
    1bac:      	jae	0x1bb6 <generic_retkprobe_filter_arg+0x1bb6>
    1bae:      	testq	%rax, %rax
    1bb1:      	setne	%cl
    1bb4:      	jmp	0x1bc6 <generic_retkprobe_filter_arg+0x1bc6>
    1bb6:      	movl	$0xc0800, %esi          # imm = 0xC0800
    1bbb:      	btl	%edx, %esi
    1bbe:      	jae	0x1bc6 <generic_retkprobe_filter_arg+0x1bc6>
    1bc0:      	testq	%rax, %rax
    1bc3:      	sete	%cl
    1bc6:      	movzbl	%cl, %ebx
    1bc9:      	movq	0x28(%rsp), %r13
    1bce:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    1bd3:      	xorl	%ebx, %ebx
    1bd5:      	movl	0x4(%r12), %eax
    1bda:      	cmpq	$0x25, %rax
    1bde:      	ja	0x2aeb <generic_retkprobe_filter_arg+0x2aeb>
    1be4:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    1bee:      	btq	%rax, %rcx
    1bf2:      	movq	0x28(%rsp), %r13
    1bf7:      	movq	(%rsp), %rdi
    1bfb:      	movq	0x8(%rsp), %r9
    1c00:      	movq	0x10(%rsp), %r11
    1c05:      	jb	0x3186 <generic_retkprobe_filter_arg+0x3186>
    1c0b:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    1c10:      	movl	0x4(%r12), %eax
    1c15:      	andl	$-0x2, %eax
    1c18:      	cmpl	$0x18, %eax
    1c1b:      	jmp	0x1e2e <generic_retkprobe_filter_arg+0x1e2e>
    1c20:      	cmpl	$0x3, %eax
    1c23:      	je	0x22d7 <generic_retkprobe_filter_arg+0x22d7>
    1c29:      	cmpl	$0x7, %eax
    1c2c:      	jne	0x22c9 <generic_retkprobe_filter_arg+0x22c9>
    1c32:      	movl	$0x9, %eax
    1c37:      	jmp	0x22dc <generic_retkprobe_filter_arg+0x22dc>
    1c3c:      	movl	$0x100, %esi            # imm = 0x100
    1c41:      	cmpl	$0x101, %eax            # imm = 0x101
    1c46:      	jb	0x1c74 <generic_retkprobe_filter_arg+0x1c74>
    1c48:      	movl	$0x200, %esi            # imm = 0x200
    1c4d:      	cmpl	$0x201, %eax            # imm = 0x201
    1c52:      	jb	0x1c74 <generic_retkprobe_filter_arg+0x1c74>
    1c54:      	movl	$0x400, %esi            # imm = 0x400
    1c59:      	cmpl	$0x401, %eax            # imm = 0x401
    1c5e:      	jb	0x1c74 <generic_retkprobe_filter_arg+0x1c74>
    1c60:      	xorl	%esi, %esi
    1c62:      	cmpl	$0x801, %eax            # imm = 0x801
    1c67:      	setae	%sil
    1c6b:      	shll	$0xb, %esi
    1c6e:      	addl	$0x800, %esi            # imm = 0x800
    1c74:      	leal	-0x100(%rsi), %eax
    1c7a:      	rorxl	$0x8, %eax, %eax
    1c80:      	cmpl	$0x2, %eax
    1c83:      	jg	0x1e4c <generic_retkprobe_filter_arg+0x1e4c>
    1c89:      	testl	%eax, %eax
    1c8b:      	je	0x2881 <generic_retkprobe_filter_arg+0x2881>
    1c91:      	cmpl	$0x1, %eax
    1c94:      	jne	0x287a <generic_retkprobe_filter_arg+0x287a>
    1c9a:      	movl	$0x7, %eax
    1c9f:      	jmp	0x288d <generic_retkprobe_filter_arg+0x288d>
    1ca4:      	cmpq	%rdx, (%r15)
    1ca7:      	ja	0x271 <generic_retkprobe_filter_arg+0x271>
    1cad:      	jmp	0x1cb8 <generic_retkprobe_filter_arg+0x1cb8>
    1caf:      	cmpq	%rdx, (%r15)
    1cb2:      	jb	0x271 <generic_retkprobe_filter_arg+0x271>
    1cb8:      	movl	0x8(%r12), %edx
    1cbd:      	cmpl	$0x11, %edx
    1cc0:      	jb	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    1cc6:      	movq	0x18(%r12), %rsi
    1ccb:      	cmpl	$0x2, %eax
    1cce:      	jle	0x1cea <generic_retkprobe_filter_arg+0x1cea>
    1cd0:      	leal	-0x3(%rax), %edi
    1cd3:      	cmpl	$0x2, %edi
    1cd6:      	jae	0x1d18 <generic_retkprobe_filter_arg+0x1d18>
    1cd8:      	cmpq	%rsi, (%r15)
    1cdb:      	movq	(%rsp), %rdi
    1cdf:      	je	0x24f <generic_retkprobe_filter_arg+0x24f>
    1ce5:      	jmp	0x2804 <generic_retkprobe_filter_arg+0x2804>
    1cea:      	cmpl	$0x1, %eax
    1ced:      	je	0x1d83 <generic_retkprobe_filter_arg+0x1d83>
    1cf3:      	cmpl	$0x2, %eax
    1cf6:      	jne	0x2804 <generic_retkprobe_filter_arg+0x2804>
    1cfc:      	cmpl	$0xc, %ecx
    1cff:      	je	0x1d0a <generic_retkprobe_filter_arg+0x1d0a>
    1d01:      	cmpl	$0xa, %ecx
    1d04:      	jne	0x27fb <generic_retkprobe_filter_arg+0x27fb>
    1d0a:      	cmpq	%rsi, (%r15)
    1d0d:      	jl	0x271 <generic_retkprobe_filter_arg+0x271>
    1d13:      	jmp	0x2804 <generic_retkprobe_filter_arg+0x2804>
    1d18:      	cmpl	$0xc, %eax
    1d1b:      	movq	(%rsp), %rdi
    1d1f:      	jne	0x2804 <generic_retkprobe_filter_arg+0x2804>
    1d25:      	testq	%rsi, (%r15)
    1d28:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
    1d2e:      	jmp	0x2804 <generic_retkprobe_filter_arg+0x2804>
    1d33:      	cmpl	$0xc, %eax
    1d36:      	jne	0x1e74 <generic_retkprobe_filter_arg+0x1e74>
    1d3c:      	movzbl	(%r15), %edx
    1d40:      	testl	%edx, %ecx
    1d42:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
    1d48:      	jmp	0x1e74 <generic_retkprobe_filter_arg+0x1e74>
    1d4d:      	cmpl	$0xc, %eax
    1d50:      	jne	0x1eb9 <generic_retkprobe_filter_arg+0x1eb9>
    1d56:      	movzwl	(%r15), %edx
    1d5a:      	testl	%edx, %ecx
    1d5c:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
    1d62:      	jmp	0x1eb9 <generic_retkprobe_filter_arg+0x1eb9>
    1d67:      	cmpl	$0x3, %eax
    1d6a:      	je	0x2474 <generic_retkprobe_filter_arg+0x2474>
    1d70:      	cmpl	$0x7, %eax
    1d73:      	jne	0x2466 <generic_retkprobe_filter_arg+0x2466>
    1d79:      	movl	$0x9, %eax
    1d7e:      	jmp	0x2479 <generic_retkprobe_filter_arg+0x2479>
    1d83:      	cmpl	$0xc, %ecx
    1d86:      	je	0x1d91 <generic_retkprobe_filter_arg+0x1d91>
    1d88:      	cmpl	$0xa, %ecx
    1d8b:      	jne	0x27f0 <generic_retkprobe_filter_arg+0x27f0>
    1d91:      	cmpq	%rsi, (%r15)
    1d94:      	jg	0x271 <generic_retkprobe_filter_arg+0x271>
    1d9a:      	jmp	0x2804 <generic_retkprobe_filter_arg+0x2804>
    1d9f:      	movl	0x8(%r12), %edx
    1da4:      	movzbl	(%r15), %ecx
    1da8:      	jmp	0x1db3 <generic_retkprobe_filter_arg+0x1db3>
    1daa:      	movl	0x8(%r12), %edx
    1daf:      	movzwl	(%r15), %ecx
    1db3:      	cmpl	%ecx, 0x10(%r12)
    1db8:      	setbe	%sil
    1dbc:      	cmpl	%ecx, 0x14(%r12)
    1dc1:      	setae	%al
    1dc4:      	andb	%sil, %al
    1dc7:      	cmpl	$0x11, %edx
    1dca:      	jb	0x2fe6 <generic_retkprobe_filter_arg+0x2fe6>
    1dd0:      	cmpl	%ecx, 0x18(%r12)
    1dd5:      	setbe	%sil
    1dd9:      	cmpl	%ecx, 0x1c(%r12)
    1dde:      	setae	%dil
    1de2:      	andb	%sil, %dil
    1de5:      	orb	%dil, %al
    1de8:      	cmpl	$0x19, %edx
    1deb:      	jb	0x2fe2 <generic_retkprobe_filter_arg+0x2fe2>
    1df1:      	cmpl	%ecx, 0x20(%r12)
    1df6:      	setbe	%sil
    1dfa:      	cmpl	%ecx, 0x24(%r12)
    1dff:      	setae	%dil
    1e03:      	andb	%sil, %dil
    1e06:      	orb	%dil, %al
    1e09:      	cmpl	$0x21, %edx
    1e0c:      	jb	0x2fe2 <generic_retkprobe_filter_arg+0x2fe2>
    1e12:      	cmpl	%ecx, 0x28(%r12)
    1e17:      	setbe	%dl
    1e1a:      	cmpl	%ecx, 0x2c(%r12)
    1e1f:      	setae	%cl
    1e22:      	andb	%dl, %cl
    1e24:      	orb	%cl, %al
    1e26:      	jmp	0x2fe2 <generic_retkprobe_filter_arg+0x2fe2>
    1e2b:      	testq	%rax, %rax
    1e2e:      	sete	%al
    1e31:      	movq	(%rsp), %rdi
    1e35:      	movq	0x8(%rsp), %r9
    1e3a:      	movq	0x10(%rsp), %r11
    1e3f:      	movzbl	%al, %ebx
    1e42:      	movq	0x28(%rsp), %r13
    1e47:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    1e4c:      	cmpl	$0x3, %eax
    1e4f:      	je	0x2888 <generic_retkprobe_filter_arg+0x2888>
    1e55:      	cmpl	$0x7, %eax
    1e58:      	jne	0x287a <generic_retkprobe_filter_arg+0x287a>
    1e5e:      	movl	$0x9, %eax
    1e63:      	jmp	0x288d <generic_retkprobe_filter_arg+0x288d>
    1e68:      	movzbl	(%r15), %edx
    1e6c:      	cmpl	%edx, %ecx
    1e6e:      	jb	0x271 <generic_retkprobe_filter_arg+0x271>
    1e74:      	movl	0x8(%r12), %ecx
    1e79:      	cmpl	$0xd, %ecx
    1e7c:      	jb	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    1e82:      	movl	0x14(%r12), %edx
    1e87:      	cmpl	$0x2, %eax
    1e8a:      	jle	0x2283 <generic_retkprobe_filter_arg+0x2283>
    1e90:      	leal	-0x3(%rax), %esi
    1e93:      	cmpl	$0x2, %esi
    1e96:      	jae	0x2a39 <generic_retkprobe_filter_arg+0x2a39>
    1e9c:      	movzbl	(%r15), %esi
    1ea0:      	cmpl	%esi, %edx
    1ea2:      	je	0x24f <generic_retkprobe_filter_arg+0x24f>
    1ea8:      	jmp	0x2b1d <generic_retkprobe_filter_arg+0x2b1d>
    1ead:      	movzwl	(%r15), %edx
    1eb1:      	cmpl	%edx, %ecx
    1eb3:      	jb	0x271 <generic_retkprobe_filter_arg+0x271>
    1eb9:      	movl	0x8(%r12), %ecx
    1ebe:      	cmpl	$0xd, %ecx
    1ec1:      	jb	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    1ec7:      	movl	0x14(%r12), %edx
    1ecc:      	cmpl	$0x2, %eax
    1ecf:      	jle	0x22a6 <generic_retkprobe_filter_arg+0x22a6>
    1ed5:      	leal	-0x3(%rax), %esi
    1ed8:      	cmpl	$0x2, %esi
    1edb:      	jae	0x2a53 <generic_retkprobe_filter_arg+0x2a53>
    1ee1:      	movzwl	(%r15), %esi
    1ee5:      	cmpl	%esi, %edx
    1ee7:      	je	0x24f <generic_retkprobe_filter_arg+0x24f>
    1eed:      	jmp	0x2b5d <generic_retkprobe_filter_arg+0x2b5d>
    1ef2:      	movl	(%r15), %eax
    1ef5:      	cmpl	%eax, %esi
    1ef7:      	ja	0x1f01 <generic_retkprobe_filter_arg+0x1f01>
    1ef9:      	cmpl	%edx, %eax
    1efb:      	jbe	0x271 <generic_retkprobe_filter_arg+0x271>
    1f01:      	movl	0x8(%r12), %edx
    1f06:      	cmpl	$0x11, %edx
    1f09:      	jb	0xb8 <generic_retkprobe_filter_arg+0xb8>
    1f0f:      	movl	0x18(%r12), %edi
    1f14:      	movl	0x1c(%r12), %esi
    1f19:      	cmpl	$0xc, %ecx
    1f1c:      	ja	0x2693 <generic_retkprobe_filter_arg+0x2693>
    1f22:      	movl	$0x1402, %r8d           # imm = 0x1402
    1f28:      	btl	%ecx, %r8d
    1f2c:      	jae	0x2693 <generic_retkprobe_filter_arg+0x2693>
    1f32:      	cmpl	%eax, %edi
    1f34:      	movq	(%rsp), %rdi
    1f38:      	jg	0x26a3 <generic_retkprobe_filter_arg+0x26a3>
    1f3e:      	cmpl	%esi, %eax
    1f40:      	jle	0x271 <generic_retkprobe_filter_arg+0x271>
    1f46:      	jmp	0x26a3 <generic_retkprobe_filter_arg+0x26a3>
    1f4b:      	movl	(%r15), %edx
    1f4e:      	cmpl	%edx, %esi
    1f50:      	setbe	%sil
    1f54:      	cmpl	%eax, %edx
    1f56:      	setbe	%al
    1f59:      	andb	%sil, %al
    1f5c:      	movl	0x8(%r12), %esi
    1f61:      	cmpl	$0x11, %esi
    1f64:      	jb	0x2fe6 <generic_retkprobe_filter_arg+0x2fe6>
    1f6a:      	movl	0x18(%r12), %r8d
    1f6f:      	movl	0x1c(%r12), %edi
    1f74:      	cmpl	$0xc, %ecx
    1f77:      	ja	0x2636 <generic_retkprobe_filter_arg+0x2636>
    1f7d:      	movl	$0x1402, %r10d          # imm = 0x1402
    1f83:      	btl	%ecx, %r10d
    1f87:      	jae	0x2636 <generic_retkprobe_filter_arg+0x2636>
    1f8d:      	cmpl	%edx, %r8d
    1f90:      	setle	%r8b
    1f94:      	cmpl	%edi, %edx
    1f96:      	setle	%dil
    1f9a:      	jmp	0x2643 <generic_retkprobe_filter_arg+0x2643>
    1f9f:      	xorl	%ebx, %ebx
    1fa1:      	xorl	%r13d, %r13d
    1fa4:      	movl	0x10(%r12,%rbx,4), %eax
    1fa9:      	movl	%eax, 0x38(%rsp)
    1fad:      	movl	$0x1, %eax
    1fb2:      	leaq	0x38(%rsp), %rsi
    1fb7:      	movq	(%rip), %rdi            # 0x1fbe <generic_retkprobe_filter_arg+0x1fbe>
    1fbe:      	callq	*%rax
    1fc0:      	testq	%rax, %rax
    1fc3:      	je	0x2b91 <generic_retkprobe_filter_arg+0x2b91>
    1fc9:      	testl	%ebp, %ebp
    1fcb:      	movq	0x8(%rsp), %r9
    1fd0:      	movq	0x10(%rsp), %r11
    1fd5:      	je	0x201f <generic_retkprobe_filter_arg+0x201f>
    1fd7:      	movq	0x18(%rsp), %rdx
    1fdc:      	xorl	%ecx, %ecx
    1fde:      	jmp	0x1feb <generic_retkprobe_filter_arg+0x1feb>
    1fe0:      	incq	%rcx
    1fe3:      	incq	%rdx
    1fe6:      	cmpq	%rbp, %rcx
    1fe9:      	je	0x201f <generic_retkprobe_filter_arg+0x201f>
    1feb:      	xorl	%esi, %esi
    1fed:      	nopl	(%rax)
    1ff0:      	leaq	(%rcx,%rsi), %rdi
    1ff4:      	cmpq	%rbp, %rdi
    1ff7:      	jae	0x1fe0 <generic_retkprobe_filter_arg+0x1fe0>
    1ff9:      	movzbl	(%rax,%rsi), %edi
    1ffd:      	testb	%dil, %dil
    2000:      	je	0x2017 <generic_retkprobe_filter_arg+0x2017>
    2002:      	cmpq	$0x62, %rsi
    2006:      	ja	0x1fe0 <generic_retkprobe_filter_arg+0x1fe0>
    2008:      	leaq	0x1(%rsi), %r8
    200c:      	cmpb	%dil, (%rdx,%rsi)
    2010:      	movq	%r8, %rsi
    2013:      	je	0x1ff0 <generic_retkprobe_filter_arg+0x1ff0>
    2015:      	jmp	0x1fe0 <generic_retkprobe_filter_arg+0x1fe0>
    2017:      	testl	%ecx, %ecx
    2019:      	jns	0x2e31 <generic_retkprobe_filter_arg+0x2e31>
    201f:      	leal	0xc(%r13), %eax
    2023:      	cmpl	0x8(%r12), %eax
    2028:      	jae	0x203b <generic_retkprobe_filter_arg+0x203b>
    202a:      	addl	$0x4, %r13d
    202e:      	incq	%rbx
    2031:      	cmpq	$0x64, %rbx
    2035:      	jne	0x1fa4 <generic_retkprobe_filter_arg+0x1fa4>
    203b:      	xorl	%ebx, %ebx
    203d:      	movq	(%rsp), %rdi
    2041:      	jmp	0x3640 <generic_retkprobe_filter_arg+0x3640>
    2046:      	movzwl	%bp, %eax
    2049:      	cmpl	$0x90, %eax
    204e:      	ja	0x26e8 <generic_retkprobe_filter_arg+0x26e8>
    2054:      	testw	%bp, %bp
    2057:      	je	0x2069 <generic_retkprobe_filter_arg+0x2069>
    2059:      	movl	%ebp, %eax
    205b:      	movl	$0x18, %ecx
    2060:      	cltd
    2061:      	idivl	%ecx
    2063:      	movl	%ebp, %esi
    2065:      	testl	%edx, %edx
    2067:      	je	0x208b <generic_retkprobe_filter_arg+0x208b>
    2069:      	movl	%ebp, %eax
    206b:      	movl	$0x18, %ecx
    2070:      	cltd
    2071:      	idivl	%ecx
    2073:      	shll	$0x3, %eax
    2076:      	leal	(%rax,%rax,2), %eax
    2079:      	addl	$0x18, %eax
    207c:      	movzwl	%ax, %esi
    207f:      	cmpl	$0x90, %esi
    2085:      	ja	0x2720 <generic_retkprobe_filter_arg+0x2720>
    208b:      	movl	%esi, %eax
    208d:      	cltd
    208e:      	idivl	%ecx
    2090:      	decl	%eax
    2092:      	jmp	0x2e52 <generic_retkprobe_filter_arg+0x2e52>
    2097:      	cmpq	%rdx, %r8
    209a:      	setbe	%r8b
    209e:      	cmpq	%rdi, %rdx
    20a1:      	setbe	%dil
    20a5:      	andb	%r8b, %dil
    20a8:      	orb	%dil, %al
    20ab:      	cmpl	$0x29, %esi
    20ae:      	jb	0x2fe2 <generic_retkprobe_filter_arg+0x2fe2>
    20b4:      	movq	0x30(%r12), %r8
    20b9:      	movq	0x38(%r12), %rdi
    20be:      	cmpl	$0xc, %ecx
    20c1:      	je	0x20cc <generic_retkprobe_filter_arg+0x20cc>
    20c3:      	cmpl	$0xa, %ecx
    20c6:      	jne	0x2750 <generic_retkprobe_filter_arg+0x2750>
    20cc:      	cmpq	%rdx, %r8
    20cf:      	setle	%r8b
    20d3:      	cmpq	%rdi, %rdx
    20d6:      	setle	%dil
    20da:      	jmp	0x275e <generic_retkprobe_filter_arg+0x275e>
    20df:      	xorl	%ebx, %ebx
    20e1:      	cmpl	$0x29, %ecx
    20e4:      	jne	0x20ef <generic_retkprobe_filter_arg+0x20ef>
    20e6:      	testq	%rdx, %rdx
    20e9:      	je	0x20ef <generic_retkprobe_filter_arg+0x20ef>
    20eb:      	movzbl	0x3a(%rdx), %ebx
    20ef:      	cmpl	$0x29, %ecx
    20f2:      	je	0x20fd <generic_retkprobe_filter_arg+0x20fd>
    20f4:      	cmpl	$0x7, %ecx
    20f7:      	jne	0x2687 <generic_retkprobe_filter_arg+0x2687>
    20fd:      	movzbl	0x10(%r12), %eax
    2103:      	movl	%eax, 0x34(%rsp)
    2107:      	movl	$0x1, %eax
    210c:      	movq	(%rip), %rdi            # 0x2113 <generic_retkprobe_filter_arg+0x2113>
    2113:      	leaq	0x34(%rsp), %rsi
    2118:      	callq	*%rax
    211a:      	testq	%rax, %rax
    211d:      	je	0x2138 <generic_retkprobe_filter_arg+0x2138>
    211f:      	movq	%rax, %rdi
    2122:      	movl	%ebx, %eax
    2124:      	movq	%rax, 0x70(%rsp)
    2129:      	movl	$0x1, %eax
    212e:      	movq	0x20(%rsp), %rsi
    2133:      	jmp	0x1b84 <generic_retkprobe_filter_arg+0x1b84>
    2138:      	xorl	%ebx, %ebx
    213a:      	movq	(%rsp), %rdi
    213e:      	movq	0x8(%rsp), %r9
    2143:      	movq	0x10(%rsp), %r11
    2148:      	movq	0x28(%rsp), %r13
    214d:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    2152:      	xorl	%ebx, %ebx
    2154:      	movq	0x28(%rsp), %r13
    2159:      	movq	0x8(%rsp), %r9
    215e:      	movq	0x10(%rsp), %r11
    2163:      	movq	(%rsp), %rdi
    2167:      	jmp	0x3351 <generic_retkprobe_filter_arg+0x3351>
    216c:      	xorl	%ebx, %ebx
    216e:      	movq	0x10(%rsp), %r11
    2173:      	jmp	0x2623 <generic_retkprobe_filter_arg+0x2623>
    2178:      	cmpq	%rax, %rdi
    217b:      	movq	(%rsp), %rdi
    217f:      	ja	0x218a <generic_retkprobe_filter_arg+0x218a>
    2181:      	cmpq	%rsi, %rax
    2184:      	jbe	0x271 <generic_retkprobe_filter_arg+0x271>
    218a:      	cmpl	$0x29, %edx
    218d:      	jb	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2193:      	movq	0x30(%r12), %rdi
    2198:      	movq	0x38(%r12), %rsi
    219d:      	cmpl	$0xc, %ecx
    21a0:      	je	0x21ab <generic_retkprobe_filter_arg+0x21ab>
    21a2:      	cmpl	$0xa, %ecx
    21a5:      	jne	0x27a6 <generic_retkprobe_filter_arg+0x27a6>
    21ab:      	cmpq	%rax, %rdi
    21ae:      	movq	(%rsp), %rdi
    21b2:      	jg	0x27b8 <generic_retkprobe_filter_arg+0x27b8>
    21b8:      	cmpq	%rsi, %rax
    21bb:      	jle	0x271 <generic_retkprobe_filter_arg+0x271>
    21c1:      	jmp	0x27b8 <generic_retkprobe_filter_arg+0x27b8>
    21c6:      	cmpl	%edx, (%r15)
    21c9:      	ja	0x271 <generic_retkprobe_filter_arg+0x271>
    21cf:      	jmp	0x21da <generic_retkprobe_filter_arg+0x21da>
    21d1:      	cmpl	%edx, (%r15)
    21d4:      	jb	0x271 <generic_retkprobe_filter_arg+0x271>
    21da:      	movl	0x8(%r12), %edx
    21df:      	cmpl	$0xd, %edx
    21e2:      	jb	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    21e8:      	movl	0x14(%r12), %esi
    21ed:      	cmpl	$0x2, %eax
    21f0:      	jle	0x220c <generic_retkprobe_filter_arg+0x220c>
    21f2:      	leal	-0x3(%rax), %edi
    21f5:      	cmpl	$0x2, %edi
    21f8:      	jae	0x2241 <generic_retkprobe_filter_arg+0x2241>
    21fa:      	cmpl	%esi, (%r15)
    21fd:      	movq	(%rsp), %rdi
    2201:      	je	0x24f <generic_retkprobe_filter_arg+0x24f>
    2207:      	jmp	0x2cbb <generic_retkprobe_filter_arg+0x2cbb>
    220c:      	cmpl	$0x1, %eax
    220f:      	je	0x225c <generic_retkprobe_filter_arg+0x225c>
    2211:      	cmpl	$0x2, %eax
    2214:      	jne	0x2cbb <generic_retkprobe_filter_arg+0x2cbb>
    221a:      	cmpl	$0xc, %ecx
    221d:      	ja	0x2cb2 <generic_retkprobe_filter_arg+0x2cb2>
    2223:      	movl	$0x1402, %r8d           # imm = 0x1402
    2229:      	btl	%ecx, %r8d
    222d:      	jae	0x2cb2 <generic_retkprobe_filter_arg+0x2cb2>
    2233:      	cmpl	%esi, (%r15)
    2236:      	jl	0x271 <generic_retkprobe_filter_arg+0x271>
    223c:      	jmp	0x2cbb <generic_retkprobe_filter_arg+0x2cbb>
    2241:      	cmpl	$0xc, %eax
    2244:      	movq	(%rsp), %rdi
    2248:      	jne	0x2cbb <generic_retkprobe_filter_arg+0x2cbb>
    224e:      	testl	%esi, (%r15)
    2251:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
    2257:      	jmp	0x2cbb <generic_retkprobe_filter_arg+0x2cbb>
    225c:      	cmpl	$0xc, %ecx
    225f:      	ja	0x2ca7 <generic_retkprobe_filter_arg+0x2ca7>
    2265:      	movl	$0x1402, %r8d           # imm = 0x1402
    226b:      	btl	%ecx, %r8d
    226f:      	jae	0x2ca7 <generic_retkprobe_filter_arg+0x2ca7>
    2275:      	cmpl	%esi, (%r15)
    2278:      	jg	0x271 <generic_retkprobe_filter_arg+0x271>
    227e:      	jmp	0x2cbb <generic_retkprobe_filter_arg+0x2cbb>
    2283:      	cmpl	$0x1, %eax
    2286:      	je	0x2b11 <generic_retkprobe_filter_arg+0x2b11>
    228c:      	cmpl	$0x2, %eax
    228f:      	jne	0x2b1d <generic_retkprobe_filter_arg+0x2b1d>
    2295:      	movzbl	(%r15), %esi
    2299:      	cmpl	%esi, %edx
    229b:      	ja	0x271 <generic_retkprobe_filter_arg+0x271>
    22a1:      	jmp	0x2b1d <generic_retkprobe_filter_arg+0x2b1d>
    22a6:      	cmpl	$0x1, %eax
    22a9:      	je	0x2b51 <generic_retkprobe_filter_arg+0x2b51>
    22af:      	cmpl	$0x2, %eax
    22b2:      	jne	0x2b5d <generic_retkprobe_filter_arg+0x2b5d>
    22b8:      	movzwl	(%r15), %esi
    22bc:      	cmpl	%esi, %edx
    22be:      	ja	0x271 <generic_retkprobe_filter_arg+0x271>
    22c4:      	jmp	0x2b5d <generic_retkprobe_filter_arg+0x2b5d>
    22c9:      	movl	$0xa, %eax
    22ce:      	jmp	0x22dc <generic_retkprobe_filter_arg+0x22dc>
    22d0:      	movl	$0x6, %eax
    22d5:      	jmp	0x22dc <generic_retkprobe_filter_arg+0x22dc>
    22d7:      	movl	$0x8, %eax
    22dc:      	movl	%eax, %ecx
    22de:      	andl	$0xf, %ecx
    22e1:      	movl	0x10(%r12,%rcx,4), %ecx
    22e6:      	cmpl	$-0x1, %ecx
    22e9:      	je	0x3153 <generic_retkprobe_filter_arg+0x3153>
    22ef:      	movl	%ecx, 0x6c(%rsp)
    22f3:      	movl	%eax, 0x18(%rsp)
    22f7:      	movq	%rsi, 0x88(%rsp)
    22ff:      	movl	$0x1, %eax
    2304:      	movq	(%rip), %rdi            # 0x230b <generic_retkprobe_filter_arg+0x230b>
    230b:      	movq	0x20(%rsp), %rbx
    2310:      	movq	%rbx, %rsi
    2313:      	callq	*%rax
    2315:      	movq	%rax, 0x60(%rsp)
    231a:      	movl	$0x1, %eax
    231f:      	movq	(%rip), %rdi            # 0x2326 <generic_retkprobe_filter_arg+0x2326>
    2326:      	movq	%rbx, %rsi
    2329:      	callq	*%rax
    232b:      	movq	0x60(%rsp), %rdx
    2330:      	testq	%rdx, %rdx
    2333:      	je	0x3153 <generic_retkprobe_filter_arg+0x3153>
    2339:      	movl	$0x0, %ebx
    233e:      	testq	%rax, %rax
    2341:      	movq	(%rsp), %rdi
    2345:      	movq	0x8(%rsp), %r9
    234a:      	movq	0x10(%rsp), %r11
    234f:      	je	0x3163 <generic_retkprobe_filter_arg+0x3163>
    2355:      	movq	%rdx, %rcx
    2358:      	movq	%rax, %rbx
    235b:      	movq	%r15, %rdx
    235e:      	addq	$0x4, %rdx
    2362:      	cmpl	$0x5, 0x18(%rsp)
    2367:      	jg	0x239c <generic_retkprobe_filter_arg+0x239c>
    2369:      	movq	%rcx, %r15
    236c:      	movb	%bpl, (%rcx)
    236f:      	leaq	0x1(%rcx), %rdi
    2373:      	movl	$0x4, %eax
    2378:      	movl	%ebp, %esi
    237a:      	callq	*%rax
    237c:      	movq	0x88(%rsp), %rsi
    2384:      	subl	%ebp, %esi
    2386:      	jbe	0x23d3 <generic_retkprobe_filter_arg+0x23d3>
    2388:      	leaq	(%r15,%rbp), %rdi
    238c:      	incq	%rdi
    238f:      	andl	$0xfff, %esi            # imm = 0xFFF
    2395:      	movl	$0x4, %eax
    239a:      	jmp	0x23ce <generic_retkprobe_filter_arg+0x23ce>
    239c:      	movq	%rcx, %r15
    239f:      	movw	%bp, (%rcx)
    23a2:      	leaq	0x2(%rcx), %rdi
    23a6:      	movl	$0x4, %eax
    23ab:      	movl	%ebp, %esi
    23ad:      	callq	*%rax
    23af:      	movq	0x88(%rsp), %rsi
    23b7:      	subl	%ebp, %esi
    23b9:      	jbe	0x23d3 <generic_retkprobe_filter_arg+0x23d3>
    23bb:      	leaq	(%r15,%rbp), %rdi
    23bf:      	addq	$0x2, %rdi
    23c3:      	andl	$0xfff, %esi            # imm = 0xFFF
    23c9:      	movl	$0x4, %eax
    23ce:      	movq	%rbx, %rdx
    23d1:      	callq	*%rax
    23d3:      	movl	0x6c(%rsp), %eax
    23d7:      	movl	%eax, 0x38(%rsp)
    23db:      	movl	0x18(%rsp), %eax
    23df:      	cmpl	$0x4, %eax
    23e2:      	movq	(%rsp), %rdi
    23e6:      	movq	0x8(%rsp), %r9
    23eb:      	movq	0x10(%rsp), %r11
    23f0:      	jle	0x242c <generic_retkprobe_filter_arg+0x242c>
    23f2:      	cmpl	$0x7, %eax
    23f5:      	jg	0x2a6d <generic_retkprobe_filter_arg+0x2a6d>
    23fb:      	cmpl	$0x5, %eax
    23fe:      	je	0x3111 <generic_retkprobe_filter_arg+0x3111>
    2404:      	cmpl	$0x6, %eax
    2407:      	je	0x30d8 <generic_retkprobe_filter_arg+0x30d8>
    240d:      	cmpl	$0x7, %eax
    2410:      	jne	0x911 <generic_retkprobe_filter_arg+0x911>
    2416:      	movl	$0x1, %eax
    241b:      	leaq	0x38(%rsp), %rsi
    2420:      	movq	(%rip), %rdi            # 0x2427 <generic_retkprobe_filter_arg+0x2427>
    2427:      	jmp	0x3135 <generic_retkprobe_filter_arg+0x3135>
    242c:      	cmpl	$0x1, %eax
    242f:      	jle	0x2ba6 <generic_retkprobe_filter_arg+0x2ba6>
    2435:      	cmpl	$0x2, %eax
    2438:      	je	0x30fe <generic_retkprobe_filter_arg+0x30fe>
    243e:      	cmpl	$0x3, %eax
    2441:      	je	0x30c5 <generic_retkprobe_filter_arg+0x30c5>
    2447:      	cmpl	$0x4, %eax
    244a:      	jne	0x911 <generic_retkprobe_filter_arg+0x911>
    2450:      	movl	$0x1, %eax
    2455:      	leaq	0x38(%rsp), %rsi
    245a:      	movq	(%rip), %rdi            # 0x2461 <generic_retkprobe_filter_arg+0x2461>
    2461:      	jmp	0x3135 <generic_retkprobe_filter_arg+0x3135>
    2466:      	movl	$0xa, %eax
    246b:      	jmp	0x2479 <generic_retkprobe_filter_arg+0x2479>
    246d:      	movl	$0x6, %eax
    2472:      	jmp	0x2479 <generic_retkprobe_filter_arg+0x2479>
    2474:      	movl	$0x8, %eax
    2479:      	movl	%eax, %ecx
    247b:      	andl	$0xf, %ecx
    247e:      	movl	0x10(%r12,%rcx,4), %ecx
    2483:      	cmpl	$-0x1, %ecx
    2486:      	je	0x2d90 <generic_retkprobe_filter_arg+0x2d90>
    248c:      	movl	%ecx, 0x6c(%rsp)
    2490:      	movl	%eax, 0x60(%rsp)
    2494:      	movq	%r8, 0x18(%rsp)
    2499:      	movq	%rsi, 0x88(%rsp)
    24a1:      	movl	$0x1, %eax
    24a6:      	movq	(%rip), %rdi            # 0x24ad <generic_retkprobe_filter_arg+0x24ad>
    24ad:      	movq	0x20(%rsp), %rbx
    24b2:      	movq	%rbx, %rsi
    24b5:      	callq	*%rax
    24b7:      	movq	%rax, %r15
    24ba:      	movl	$0x1, %eax
    24bf:      	movq	(%rip), %rdi            # 0x24c6 <generic_retkprobe_filter_arg+0x24c6>
    24c6:      	movq	%rbx, %rsi
    24c9:      	callq	*%rax
    24cb:      	testq	%r15, %r15
    24ce:      	je	0x3261 <generic_retkprobe_filter_arg+0x3261>
    24d4:      	movl	$0x0, %ebx
    24d9:      	testq	%rax, %rax
    24dc:      	movq	(%rsp), %rdi
    24e0:      	movq	0x8(%rsp), %r9
    24e5:      	movq	0x10(%rsp), %r11
    24ea:      	je	0x3271 <generic_retkprobe_filter_arg+0x3271>
    24f0:      	movq	%r15, %rcx
    24f3:      	movq	%rax, %r15
    24f6:      	cmpl	$0x5, 0x60(%rsp)
    24fb:      	jg	0x2537 <generic_retkprobe_filter_arg+0x2537>
    24fd:      	movb	%bpl, (%rcx)
    2500:      	movq	%rcx, %rbp
    2503:      	leaq	0x1(%rcx), %rdi
    2507:      	movl	$0x4, %eax
    250c:      	movq	0x88(%rsp), %rbx
    2514:      	movq	0x18(%rsp), %rdx
    2519:      	movl	%ebx, %esi
    251b:      	callq	*%rax
    251d:      	subl	%ebx, %r13d
    2520:      	jbe	0x2578 <generic_retkprobe_filter_arg+0x2578>
    2522:      	leaq	(%rbx,%rbp), %rdi
    2526:      	incq	%rdi
    2529:      	andl	$0xfff, %r13d           # imm = 0xFFF
    2530:      	movl	$0x4, %eax
    2535:      	jmp	0x2570 <generic_retkprobe_filter_arg+0x2570>
    2537:      	movq	0x88(%rsp), %rbx
    253f:      	movq	%rcx, %rbp
    2542:      	movw	%bx, (%rcx)
    2545:      	leaq	0x2(%rcx), %rdi
    2549:      	movl	$0x4, %eax
    254e:      	movq	0x18(%rsp), %rdx
    2553:      	movl	%ebx, %esi
    2555:      	callq	*%rax
    2557:      	subl	%ebx, %r13d
    255a:      	jbe	0x2578 <generic_retkprobe_filter_arg+0x2578>
    255c:      	leaq	(%rbx,%rbp), %rdi
    2560:      	addq	$0x2, %rdi
    2564:      	andl	$0xfff, %r13d           # imm = 0xFFF
    256b:      	movl	$0x4, %eax
    2570:      	movl	%r13d, %esi
    2573:      	movq	%r15, %rdx
    2576:      	callq	*%rax
    2578:      	movl	0x6c(%rsp), %eax
    257c:      	movl	%eax, 0x38(%rsp)
    2580:      	movl	0x60(%rsp), %eax
    2584:      	cmpl	$0x4, %eax
    2587:      	movq	(%rsp), %rdi
    258b:      	movq	0x8(%rsp), %r9
    2590:      	movq	0x10(%rsp), %r11
    2595:      	jle	0x25d1 <generic_retkprobe_filter_arg+0x25d1>
    2597:      	cmpl	$0x7, %eax
    259a:      	jg	0x2aba <generic_retkprobe_filter_arg+0x2aba>
    25a0:      	cmpl	$0x5, %eax
    25a3:      	je	0x321f <generic_retkprobe_filter_arg+0x321f>
    25a9:      	cmpl	$0x6, %eax
    25ac:      	je	0x31e6 <generic_retkprobe_filter_arg+0x31e6>
    25b2:      	cmpl	$0x7, %eax
    25b5:      	jne	0x2d90 <generic_retkprobe_filter_arg+0x2d90>
    25bb:      	movl	$0x1, %eax
    25c0:      	leaq	0x38(%rsp), %rsi
    25c5:      	movq	(%rip), %rdi            # 0x25cc <generic_retkprobe_filter_arg+0x25cc>
    25cc:      	jmp	0x3243 <generic_retkprobe_filter_arg+0x3243>
    25d1:      	cmpl	$0x1, %eax
    25d4:      	jle	0x2d6d <generic_retkprobe_filter_arg+0x2d6d>
    25da:      	cmpl	$0x2, %eax
    25dd:      	je	0x320c <generic_retkprobe_filter_arg+0x320c>
    25e3:      	cmpl	$0x3, %eax
    25e6:      	je	0x31d3 <generic_retkprobe_filter_arg+0x31d3>
    25ec:      	cmpl	$0x4, %eax
    25ef:      	jne	0x2d90 <generic_retkprobe_filter_arg+0x2d90>
    25f5:      	movl	$0x1, %eax
    25fa:      	leaq	0x38(%rsp), %rsi
    25ff:      	movq	(%rip), %rdi            # 0x2606 <generic_retkprobe_filter_arg+0x2606>
    2606:      	jmp	0x3243 <generic_retkprobe_filter_arg+0x3243>
    260b:      	movl	$0x1, %ebx
    2610:      	movq	0x28(%rsp), %r13
    2615:      	movq	(%rsp), %rdi
    2619:      	jmp	0x3351 <generic_retkprobe_filter_arg+0x3351>
    261e:      	movl	$0x1, %ebx
    2623:      	movq	0x28(%rsp), %r13
    2628:      	movq	(%rsp), %rdi
    262c:      	movq	0x8(%rsp), %r9
    2631:      	jmp	0x3351 <generic_retkprobe_filter_arg+0x3351>
    2636:      	cmpl	%edx, %r8d
    2639:      	setbe	%r8b
    263d:      	cmpl	%edi, %edx
    263f:      	setbe	%dil
    2643:      	andb	%r8b, %dil
    2646:      	orb	%dil, %al
    2649:      	cmpl	$0x19, %esi
    264c:      	jb	0x2fe2 <generic_retkprobe_filter_arg+0x2fe2>
    2652:      	movl	0x20(%r12), %r8d
    2657:      	movl	0x24(%r12), %edi
    265c:      	cmpl	$0xc, %ecx
    265f:      	ja	0x2bfe <generic_retkprobe_filter_arg+0x2bfe>
    2665:      	movl	$0x1402, %r10d          # imm = 0x1402
    266b:      	btl	%ecx, %r10d
    266f:      	jae	0x2bfe <generic_retkprobe_filter_arg+0x2bfe>
    2675:      	cmpl	%edx, %r8d
    2678:      	setle	%r8b
    267c:      	cmpl	%edi, %edx
    267e:      	setle	%dil
    2682:      	jmp	0x2c0b <generic_retkprobe_filter_arg+0x2c0b>
    2687:      	xorl	%ebx, %ebx
    2689:      	movq	0x28(%rsp), %r13
    268e:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    2693:      	cmpl	%eax, %edi
    2695:      	movq	(%rsp), %rdi
    2699:      	ja	0x26a3 <generic_retkprobe_filter_arg+0x26a3>
    269b:      	cmpl	%esi, %eax
    269d:      	jbe	0x271 <generic_retkprobe_filter_arg+0x271>
    26a3:      	cmpl	$0x19, %edx
    26a6:      	jb	0xb8 <generic_retkprobe_filter_arg+0xb8>
    26ac:      	movl	0x20(%r12), %edi
    26b1:      	movl	0x24(%r12), %esi
    26b6:      	cmpl	$0xc, %ecx
    26b9:      	ja	0x2c56 <generic_retkprobe_filter_arg+0x2c56>
    26bf:      	movl	$0x1402, %r8d           # imm = 0x1402
    26c5:      	btl	%ecx, %r8d
    26c9:      	jae	0x2c56 <generic_retkprobe_filter_arg+0x2c56>
    26cf:      	cmpl	%eax, %edi
    26d1:      	movq	(%rsp), %rdi
    26d5:      	jg	0x2c66 <generic_retkprobe_filter_arg+0x2c66>
    26db:      	cmpl	%esi, %eax
    26dd:      	jle	0x271 <generic_retkprobe_filter_arg+0x271>
    26e3:      	jmp	0x2c66 <generic_retkprobe_filter_arg+0x2c66>
    26e8:      	movl	$0x100, %esi            # imm = 0x100
    26ed:      	cmpl	$0x101, %eax            # imm = 0x101
    26f2:      	jb	0x2720 <generic_retkprobe_filter_arg+0x2720>
    26f4:      	movl	$0x200, %esi            # imm = 0x200
    26f9:      	cmpl	$0x201, %eax            # imm = 0x201
    26fe:      	jb	0x2720 <generic_retkprobe_filter_arg+0x2720>
    2700:      	movl	$0x400, %esi            # imm = 0x400
    2705:      	cmpl	$0x401, %eax            # imm = 0x401
    270a:      	jb	0x2720 <generic_retkprobe_filter_arg+0x2720>
    270c:      	xorl	%esi, %esi
    270e:      	cmpl	$0x801, %eax            # imm = 0x801
    2713:      	setae	%sil
    2717:      	shll	$0xb, %esi
    271a:      	addl	$0x800, %esi            # imm = 0x800
    2720:      	leal	-0x100(%rsi), %eax
    2726:      	rorxl	$0x8, %eax, %eax
    272c:      	cmpl	$0x2, %eax
    272f:      	jg	0x2af5 <generic_retkprobe_filter_arg+0x2af5>
    2735:      	testl	%eax, %eax
    2737:      	je	0x2e46 <generic_retkprobe_filter_arg+0x2e46>
    273d:      	cmpl	$0x1, %eax
    2740:      	jne	0x2e3f <generic_retkprobe_filter_arg+0x2e3f>
    2746:      	movl	$0x7, %eax
    274b:      	jmp	0x2e52 <generic_retkprobe_filter_arg+0x2e52>
    2750:      	cmpq	%rdx, %r8
    2753:      	setbe	%r8b
    2757:      	cmpq	%rdi, %rdx
    275a:      	setbe	%dil
    275e:      	andb	%r8b, %dil
    2761:      	orb	%dil, %al
    2764:      	cmpl	$0x39, %esi
    2767:      	jb	0x2fe2 <generic_retkprobe_filter_arg+0x2fe2>
    276d:      	movq	0x40(%r12), %rdi
    2772:      	movq	0x48(%r12), %rsi
    2777:      	cmpl	$0xc, %ecx
    277a:      	je	0x2785 <generic_retkprobe_filter_arg+0x2785>
    277c:      	cmpl	$0xa, %ecx
    277f:      	jne	0x2d5f <generic_retkprobe_filter_arg+0x2d5f>
    2785:      	cmpq	%rdx, %rdi
    2788:      	setle	%cl
    278b:      	cmpq	%rsi, %rdx
    278e:      	jmp	0x2c44 <generic_retkprobe_filter_arg+0x2c44>
    2793:      	movq	(%rsp), %rdi
    2797:      	movq	0x8(%rsp), %r9
    279c:      	movq	0x10(%rsp), %r11
    27a1:      	jmp	0x19ed <generic_retkprobe_filter_arg+0x19ed>
    27a6:      	cmpq	%rax, %rdi
    27a9:      	movq	(%rsp), %rdi
    27ad:      	ja	0x27b8 <generic_retkprobe_filter_arg+0x27b8>
    27af:      	cmpq	%rsi, %rax
    27b2:      	jbe	0x271 <generic_retkprobe_filter_arg+0x271>
    27b8:      	cmpl	$0x39, %edx
    27bb:      	jb	0xb8 <generic_retkprobe_filter_arg+0xb8>
    27c1:      	movq	0x40(%r12), %rsi
    27c6:      	movq	0x48(%r12), %rdx
    27cb:      	cmpl	$0xc, %ecx
    27ce:      	je	0x27d9 <generic_retkprobe_filter_arg+0x27d9>
    27d0:      	cmpl	$0xa, %ecx
    27d3:      	jne	0x2da6 <generic_retkprobe_filter_arg+0x2da6>
    27d9:      	cmpq	%rax, %rsi
    27dc:      	jg	0xb8 <generic_retkprobe_filter_arg+0xb8>
    27e2:      	cmpq	%rdx, %rax
    27e5:      	jle	0x271 <generic_retkprobe_filter_arg+0x271>
    27eb:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
    27f0:      	cmpq	%rsi, (%r15)
    27f3:      	ja	0x271 <generic_retkprobe_filter_arg+0x271>
    27f9:      	jmp	0x2804 <generic_retkprobe_filter_arg+0x2804>
    27fb:      	cmpq	%rsi, (%r15)
    27fe:      	jb	0x271 <generic_retkprobe_filter_arg+0x271>
    2804:      	cmpl	$0x19, %edx
    2807:      	jb	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    280d:      	movq	0x20(%r12), %rsi
    2812:      	cmpl	$0x2, %eax
    2815:      	jle	0x2831 <generic_retkprobe_filter_arg+0x2831>
    2817:      	leal	-0x3(%rax), %edi
    281a:      	cmpl	$0x2, %edi
    281d:      	jae	0x285f <generic_retkprobe_filter_arg+0x285f>
    281f:      	cmpq	%rsi, (%r15)
    2822:      	movq	(%rsp), %rdi
    2826:      	je	0x24f <generic_retkprobe_filter_arg+0x24f>
    282c:      	jmp	0x3007 <generic_retkprobe_filter_arg+0x3007>
    2831:      	cmpl	$0x1, %eax
    2834:      	je	0x2a9e <generic_retkprobe_filter_arg+0x2a9e>
    283a:      	cmpl	$0x2, %eax
    283d:      	jne	0x3007 <generic_retkprobe_filter_arg+0x3007>
    2843:      	cmpl	$0xc, %ecx
    2846:      	je	0x2851 <generic_retkprobe_filter_arg+0x2851>
    2848:      	cmpl	$0xa, %ecx
    284b:      	jne	0x2ffe <generic_retkprobe_filter_arg+0x2ffe>
    2851:      	cmpq	%rsi, (%r15)
    2854:      	jl	0x271 <generic_retkprobe_filter_arg+0x271>
    285a:      	jmp	0x3007 <generic_retkprobe_filter_arg+0x3007>
    285f:      	cmpl	$0xc, %eax
    2862:      	movq	(%rsp), %rdi
    2866:      	jne	0x3007 <generic_retkprobe_filter_arg+0x3007>
    286c:      	testq	%rsi, (%r15)
    286f:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
    2875:      	jmp	0x3007 <generic_retkprobe_filter_arg+0x3007>
    287a:      	movl	$0xa, %eax
    287f:      	jmp	0x288d <generic_retkprobe_filter_arg+0x288d>
    2881:      	movl	$0x6, %eax
    2886:      	jmp	0x288d <generic_retkprobe_filter_arg+0x288d>
    2888:      	movl	$0x8, %eax
    288d:      	movl	%eax, %ecx
    288f:      	andl	$0xf, %ecx
    2892:      	movl	0x10(%r12,%rcx,4), %ecx
    2897:      	cmpl	$-0x1, %ecx
    289a:      	je	0x2e26 <generic_retkprobe_filter_arg+0x2e26>
    28a0:      	movl	%ecx, 0x6c(%rsp)
    28a4:      	movl	%eax, 0x88(%rsp)
    28ab:      	movq	%rsi, 0x98(%rsp)
    28b3:      	movl	$0x1, %eax
    28b8:      	movq	(%rip), %rdi            # 0x28bf <generic_retkprobe_filter_arg+0x28bf>
    28bf:      	movq	0x20(%rsp), %rbx
    28c4:      	movq	%rbx, %rsi
    28c7:      	callq	*%rax
    28c9:      	movq	%rax, %r15
    28cc:      	movl	$0x1, %eax
    28d1:      	movq	(%rip), %rdi            # 0x28d8 <generic_retkprobe_filter_arg+0x28d8>
    28d8:      	movq	%rbx, %rsi
    28db:      	callq	*%rax
    28dd:      	movq	%r15, 0x60(%rsp)
    28e2:      	testq	%r15, %r15
    28e5:      	je	0x3341 <generic_retkprobe_filter_arg+0x3341>
    28eb:      	movl	$0x0, %ebx
    28f0:      	testq	%rax, %rax
    28f3:      	movq	(%rsp), %rdi
    28f7:      	movq	0x8(%rsp), %r9
    28fc:      	movq	0x10(%rsp), %r11
    2901:      	je	0x3351 <generic_retkprobe_filter_arg+0x3351>
    2907:      	movq	%rax, %r15
    290a:      	movl	0x88(%rsp), %ebx
    2911:      	cmpl	$0x5, %ebx
    2914:      	jg	0x2958 <generic_retkprobe_filter_arg+0x2958>
    2916:      	movq	0x60(%rsp), %rax
    291b:      	movb	%bpl, (%rax)
    291e:      	leaq	0x1(%rax), %rdi
    2922:      	movl	$0x4, %eax
    2927:      	movq	0x18(%rsp), %rdx
    292c:      	movl	%ebp, %esi
    292e:      	callq	*%rax
    2930:      	movq	0x98(%rsp), %rsi
    2938:      	subl	%ebp, %esi
    293a:      	jbe	0x299b <generic_retkprobe_filter_arg+0x299b>
    293c:      	movq	0x60(%rsp), %rax
    2941:      	leaq	(%rax,%rbp), %rdi
    2945:      	incq	%rdi
    2948:      	andl	$0xfff, %esi            # imm = 0xFFF
    294e:      	movl	$0x4, %eax
    2953:      	movq	%r15, %rdx
    2956:      	jmp	0x2999 <generic_retkprobe_filter_arg+0x2999>
    2958:      	movq	0x60(%rsp), %rax
    295d:      	movw	%bp, (%rax)
    2960:      	leaq	0x2(%rax), %rdi
    2964:      	movl	$0x4, %eax
    2969:      	movq	0x18(%rsp), %rdx
    296e:      	movl	%ebp, %esi
    2970:      	callq	*%rax
    2972:      	movq	0x98(%rsp), %rsi
    297a:      	subl	%ebp, %esi
    297c:      	jbe	0x299b <generic_retkprobe_filter_arg+0x299b>
    297e:      	movq	0x60(%rsp), %rax
    2983:      	leaq	(%rax,%rbp), %rdi
    2987:      	addq	$0x2, %rdi
    298b:      	andl	$0xfff, %esi            # imm = 0xFFF
    2991:      	movl	$0x4, %eax
    2996:      	movq	%r15, %rdx
    2999:      	callq	*%rax
    299b:      	movl	0x6c(%rsp), %eax
    299f:      	movl	%eax, 0x38(%rsp)
    29a3:      	cmpl	$0x4, %ebx
    29a6:      	movq	0x8(%rsp), %r9
    29ab:      	movq	0x10(%rsp), %r11
    29b0:      	jle	0x29ec <generic_retkprobe_filter_arg+0x29ec>
    29b2:      	cmpl	$0x7, %ebx
    29b5:      	jg	0x2bcd <generic_retkprobe_filter_arg+0x2bcd>
    29bb:      	cmpl	$0x5, %ebx
    29be:      	je	0x32fd <generic_retkprobe_filter_arg+0x32fd>
    29c4:      	cmpl	$0x6, %ebx
    29c7:      	je	0x32c4 <generic_retkprobe_filter_arg+0x32c4>
    29cd:      	cmpl	$0x7, %ebx
    29d0:      	jne	0x2e26 <generic_retkprobe_filter_arg+0x2e26>
    29d6:      	movl	$0x1, %eax
    29db:      	leaq	0x38(%rsp), %rsi
    29e0:      	movq	(%rip), %rdi            # 0x29e7 <generic_retkprobe_filter_arg+0x29e7>
    29e7:      	jmp	0x3321 <generic_retkprobe_filter_arg+0x3321>
    29ec:      	cmpl	$0x1, %ebx
    29ef:      	jle	0x2e03 <generic_retkprobe_filter_arg+0x2e03>
    29f5:      	cmpl	$0x2, %ebx
    29f8:      	je	0x32ea <generic_retkprobe_filter_arg+0x32ea>
    29fe:      	cmpl	$0x3, %ebx
    2a01:      	je	0x32b1 <generic_retkprobe_filter_arg+0x32b1>
    2a07:      	cmpl	$0x4, %ebx
    2a0a:      	jne	0x2e26 <generic_retkprobe_filter_arg+0x2e26>
    2a10:      	movl	$0x1, %eax
    2a15:      	leaq	0x38(%rsp), %rsi
    2a1a:      	movq	(%rip), %rdi            # 0x2a21 <generic_retkprobe_filter_arg+0x2a21>
    2a21:      	jmp	0x3321 <generic_retkprobe_filter_arg+0x3321>
    2a26:      	movq	(%rsp), %rdi
    2a2a:      	movq	0x8(%rsp), %r9
    2a2f:      	movq	0x10(%rsp), %r11
    2a34:      	jmp	0x1bc6 <generic_retkprobe_filter_arg+0x1bc6>
    2a39:      	cmpl	$0xc, %eax
    2a3c:      	jne	0x2b1d <generic_retkprobe_filter_arg+0x2b1d>
    2a42:      	movzbl	(%r15), %esi
    2a46:      	testl	%esi, %edx
    2a48:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
    2a4e:      	jmp	0x2b1d <generic_retkprobe_filter_arg+0x2b1d>
    2a53:      	cmpl	$0xc, %eax
    2a56:      	jne	0x2b5d <generic_retkprobe_filter_arg+0x2b5d>
    2a5c:      	movzwl	(%r15), %esi
    2a60:      	testl	%esi, %edx
    2a62:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
    2a68:      	jmp	0x2b5d <generic_retkprobe_filter_arg+0x2b5d>
    2a6d:      	cmpl	$0x8, %eax
    2a70:      	je	0x3124 <generic_retkprobe_filter_arg+0x3124>
    2a76:      	cmpl	$0x9, %eax
    2a79:      	je	0x30eb <generic_retkprobe_filter_arg+0x30eb>
    2a7f:      	cmpl	$0xa, %eax
    2a82:      	jne	0x911 <generic_retkprobe_filter_arg+0x911>
    2a88:      	movl	$0x1, %eax
    2a8d:      	leaq	0x38(%rsp), %rsi
    2a92:      	movq	(%rip), %rdi            # 0x2a99 <generic_retkprobe_filter_arg+0x2a99>
    2a99:      	jmp	0x3135 <generic_retkprobe_filter_arg+0x3135>
    2a9e:      	cmpl	$0xc, %ecx
    2aa1:      	je	0x2aac <generic_retkprobe_filter_arg+0x2aac>
    2aa3:      	cmpl	$0xa, %ecx
    2aa6:      	jne	0x2ff3 <generic_retkprobe_filter_arg+0x2ff3>
    2aac:      	cmpq	%rsi, (%r15)
    2aaf:      	jg	0x271 <generic_retkprobe_filter_arg+0x271>
    2ab5:      	jmp	0x3007 <generic_retkprobe_filter_arg+0x3007>
    2aba:      	cmpl	$0x8, %eax
    2abd:      	je	0x3232 <generic_retkprobe_filter_arg+0x3232>
    2ac3:      	cmpl	$0x9, %eax
    2ac6:      	je	0x31f9 <generic_retkprobe_filter_arg+0x31f9>
    2acc:      	cmpl	$0xa, %eax
    2acf:      	jne	0x2d90 <generic_retkprobe_filter_arg+0x2d90>
    2ad5:      	movl	$0x1, %eax
    2ada:      	leaq	0x38(%rsp), %rsi
    2adf:      	movq	(%rip), %rdi            # 0x2ae6 <generic_retkprobe_filter_arg+0x2ae6>
    2ae6:      	jmp	0x3243 <generic_retkprobe_filter_arg+0x3243>
    2aeb:      	movq	0x28(%rsp), %r13
    2af0:      	jmp	0x19ca <generic_retkprobe_filter_arg+0x19ca>
    2af5:      	cmpl	$0x3, %eax
    2af8:      	je	0x2e4d <generic_retkprobe_filter_arg+0x2e4d>
    2afe:      	cmpl	$0x7, %eax
    2b01:      	jne	0x2e3f <generic_retkprobe_filter_arg+0x2e3f>
    2b07:      	movl	$0x9, %eax
    2b0c:      	jmp	0x2e52 <generic_retkprobe_filter_arg+0x2e52>
    2b11:      	movzbl	(%r15), %esi
    2b15:      	cmpl	%esi, %edx
    2b17:      	jb	0x271 <generic_retkprobe_filter_arg+0x271>
    2b1d:      	cmpl	$0x11, %ecx
    2b20:      	jb	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    2b26:      	movl	0x18(%r12), %edx
    2b2b:      	cmpl	$0x2, %eax
    2b2e:      	jle	0x2dbd <generic_retkprobe_filter_arg+0x2dbd>
    2b34:      	leal	-0x3(%rax), %esi
    2b37:      	cmpl	$0x2, %esi
    2b3a:      	jae	0x307e <generic_retkprobe_filter_arg+0x307e>
    2b40:      	movzbl	(%r15), %esi
    2b44:      	cmpl	%esi, %edx
    2b46:      	je	0x24f <generic_retkprobe_filter_arg+0x24f>
    2b4c:      	jmp	0x3385 <generic_retkprobe_filter_arg+0x3385>
    2b51:      	movzwl	(%r15), %esi
    2b55:      	cmpl	%esi, %edx
    2b57:      	jb	0x271 <generic_retkprobe_filter_arg+0x271>
    2b5d:      	cmpl	$0x11, %ecx
    2b60:      	jb	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    2b66:      	movl	0x18(%r12), %edx
    2b6b:      	cmpl	$0x2, %eax
    2b6e:      	jle	0x2de0 <generic_retkprobe_filter_arg+0x2de0>
    2b74:      	leal	-0x3(%rax), %esi
    2b77:      	cmpl	$0x2, %esi
    2b7a:      	jae	0x3098 <generic_retkprobe_filter_arg+0x3098>
    2b80:      	movzwl	(%r15), %esi
    2b84:      	cmpl	%esi, %edx
    2b86:      	je	0x24f <generic_retkprobe_filter_arg+0x24f>
    2b8c:      	jmp	0x33cc <generic_retkprobe_filter_arg+0x33cc>
    2b91:      	xorl	%ebx, %ebx
    2b93:      	movq	0x8(%rsp), %r9
    2b98:      	movq	0x10(%rsp), %r11
    2b9d:      	movq	(%rsp), %rdi
    2ba1:      	jmp	0x3640 <generic_retkprobe_filter_arg+0x3640>
    2ba6:      	testl	%eax, %eax
    2ba8:      	je	0x30b2 <generic_retkprobe_filter_arg+0x30b2>
    2bae:      	cmpl	$0x1, %eax
    2bb1:      	jne	0x911 <generic_retkprobe_filter_arg+0x911>
    2bb7:      	movl	$0x1, %eax
    2bbc:      	leaq	0x38(%rsp), %rsi
    2bc1:      	movq	(%rip), %rdi            # 0x2bc8 <generic_retkprobe_filter_arg+0x2bc8>
    2bc8:      	jmp	0x3135 <generic_retkprobe_filter_arg+0x3135>
    2bcd:      	cmpl	$0x8, %ebx
    2bd0:      	je	0x3310 <generic_retkprobe_filter_arg+0x3310>
    2bd6:      	cmpl	$0x9, %ebx
    2bd9:      	je	0x32d7 <generic_retkprobe_filter_arg+0x32d7>
    2bdf:      	cmpl	$0xa, %ebx
    2be2:      	jne	0x2e26 <generic_retkprobe_filter_arg+0x2e26>
    2be8:      	movl	$0x1, %eax
    2bed:      	leaq	0x38(%rsp), %rsi
    2bf2:      	movq	(%rip), %rdi            # 0x2bf9 <generic_retkprobe_filter_arg+0x2bf9>
    2bf9:      	jmp	0x3321 <generic_retkprobe_filter_arg+0x3321>
    2bfe:      	cmpl	%edx, %r8d
    2c01:      	setbe	%r8b
    2c05:      	cmpl	%edi, %edx
    2c07:      	setbe	%dil
    2c0b:      	andb	%r8b, %dil
    2c0e:      	orb	%dil, %al
    2c11:      	cmpl	$0x21, %esi
    2c14:      	jb	0x2fe2 <generic_retkprobe_filter_arg+0x2fe2>
    2c1a:      	movl	0x28(%r12), %edi
    2c1f:      	movl	0x2c(%r12), %esi
    2c24:      	cmpl	$0xc, %ecx
    2c27:      	ja	0x2fd4 <generic_retkprobe_filter_arg+0x2fd4>
    2c2d:      	movl	$0x1402, %r8d           # imm = 0x1402
    2c33:      	btl	%ecx, %r8d
    2c37:      	jae	0x2fd4 <generic_retkprobe_filter_arg+0x2fd4>
    2c3d:      	cmpl	%edx, %edi
    2c3f:      	setle	%cl
    2c42:      	cmpl	%esi, %edx
    2c44:      	setle	%dl
    2c47:      	jmp	0x2fde <generic_retkprobe_filter_arg+0x2fde>
    2c4c:      	movl	$0x1, %ebx
    2c51:      	jmp	0x3632 <generic_retkprobe_filter_arg+0x3632>
    2c56:      	cmpl	%eax, %edi
    2c58:      	movq	(%rsp), %rdi
    2c5c:      	ja	0x2c66 <generic_retkprobe_filter_arg+0x2c66>
    2c5e:      	cmpl	%esi, %eax
    2c60:      	jbe	0x271 <generic_retkprobe_filter_arg+0x271>
    2c66:      	cmpl	$0x21, %edx
    2c69:      	jb	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2c6f:      	movl	0x28(%r12), %esi
    2c74:      	movl	0x2c(%r12), %edx
    2c79:      	cmpl	$0xc, %ecx
    2c7c:      	ja	0x318f <generic_retkprobe_filter_arg+0x318f>
    2c82:      	movl	$0x1402, %r8d           # imm = 0x1402
    2c88:      	btl	%ecx, %r8d
    2c8c:      	jae	0x318f <generic_retkprobe_filter_arg+0x318f>
    2c92:      	cmpl	%eax, %esi
    2c94:      	jg	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2c9a:      	cmpl	%edx, %eax
    2c9c:      	jle	0x271 <generic_retkprobe_filter_arg+0x271>
    2ca2:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2ca7:      	cmpl	%esi, (%r15)
    2caa:      	ja	0x271 <generic_retkprobe_filter_arg+0x271>
    2cb0:      	jmp	0x2cbb <generic_retkprobe_filter_arg+0x2cbb>
    2cb2:      	cmpl	%esi, (%r15)
    2cb5:      	jb	0x271 <generic_retkprobe_filter_arg+0x271>
    2cbb:      	cmpl	$0x11, %edx
    2cbe:      	jb	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    2cc4:      	movl	0x18(%r12), %esi
    2cc9:      	cmpl	$0x2, %eax
    2ccc:      	jle	0x2ce8 <generic_retkprobe_filter_arg+0x2ce8>
    2cce:      	leal	-0x3(%rax), %edi
    2cd1:      	cmpl	$0x2, %edi
    2cd4:      	jae	0x2d1d <generic_retkprobe_filter_arg+0x2d1d>
    2cd6:      	cmpl	%esi, (%r15)
    2cd9:      	movq	(%rsp), %rdi
    2cdd:      	je	0x24f <generic_retkprobe_filter_arg+0x24f>
    2ce3:      	jmp	0x3457 <generic_retkprobe_filter_arg+0x3457>
    2ce8:      	cmpl	$0x1, %eax
    2ceb:      	je	0x2d38 <generic_retkprobe_filter_arg+0x2d38>
    2ced:      	cmpl	$0x2, %eax
    2cf0:      	jne	0x3457 <generic_retkprobe_filter_arg+0x3457>
    2cf6:      	cmpl	$0xc, %ecx
    2cf9:      	ja	0x344e <generic_retkprobe_filter_arg+0x344e>
    2cff:      	movl	$0x1402, %r8d           # imm = 0x1402
    2d05:      	btl	%ecx, %r8d
    2d09:      	jae	0x344e <generic_retkprobe_filter_arg+0x344e>
    2d0f:      	cmpl	%esi, (%r15)
    2d12:      	jl	0x271 <generic_retkprobe_filter_arg+0x271>
    2d18:      	jmp	0x3457 <generic_retkprobe_filter_arg+0x3457>
    2d1d:      	cmpl	$0xc, %eax
    2d20:      	movq	(%rsp), %rdi
    2d24:      	jne	0x3457 <generic_retkprobe_filter_arg+0x3457>
    2d2a:      	testl	%esi, (%r15)
    2d2d:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
    2d33:      	jmp	0x3457 <generic_retkprobe_filter_arg+0x3457>
    2d38:      	cmpl	$0xc, %ecx
    2d3b:      	ja	0x3443 <generic_retkprobe_filter_arg+0x3443>
    2d41:      	movl	$0x1402, %r8d           # imm = 0x1402
    2d47:      	btl	%ecx, %r8d
    2d4b:      	jae	0x3443 <generic_retkprobe_filter_arg+0x3443>
    2d51:      	cmpl	%esi, (%r15)
    2d54:      	jg	0x271 <generic_retkprobe_filter_arg+0x271>
    2d5a:      	jmp	0x3457 <generic_retkprobe_filter_arg+0x3457>
    2d5f:      	cmpq	%rdx, %rdi
    2d62:      	setbe	%cl
    2d65:      	cmpq	%rsi, %rdx
    2d68:      	jmp	0x2fdb <generic_retkprobe_filter_arg+0x2fdb>
    2d6d:      	testl	%eax, %eax
    2d6f:      	je	0x31c0 <generic_retkprobe_filter_arg+0x31c0>
    2d75:      	cmpl	$0x1, %eax
    2d78:      	jne	0x2d90 <generic_retkprobe_filter_arg+0x2d90>
    2d7a:      	movl	$0x1, %eax
    2d7f:      	leaq	0x38(%rsp), %rsi
    2d84:      	movq	(%rip), %rdi            # 0x2d8b <generic_retkprobe_filter_arg+0x2d8b>
    2d8b:      	jmp	0x3243 <generic_retkprobe_filter_arg+0x3243>
    2d90:      	xorl	%ebx, %ebx
    2d92:      	movl	0x4(%r12), %eax
    2d97:      	cmpq	$0x25, %rax
    2d9b:      	jbe	0x3280 <generic_retkprobe_filter_arg+0x3280>
    2da1:      	jmp	0x1bc9 <generic_retkprobe_filter_arg+0x1bc9>
    2da6:      	cmpq	%rax, %rsi
    2da9:      	ja	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2daf:      	cmpq	%rdx, %rax
    2db2:      	jbe	0x271 <generic_retkprobe_filter_arg+0x271>
    2db8:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2dbd:      	cmpl	$0x1, %eax
    2dc0:      	je	0x3379 <generic_retkprobe_filter_arg+0x3379>
    2dc6:      	cmpl	$0x2, %eax
    2dc9:      	jne	0x3385 <generic_retkprobe_filter_arg+0x3385>
    2dcf:      	movzbl	(%r15), %esi
    2dd3:      	cmpl	%esi, %edx
    2dd5:      	ja	0x271 <generic_retkprobe_filter_arg+0x271>
    2ddb:      	jmp	0x3385 <generic_retkprobe_filter_arg+0x3385>
    2de0:      	cmpl	$0x1, %eax
    2de3:      	je	0x33c0 <generic_retkprobe_filter_arg+0x33c0>
    2de9:      	cmpl	$0x2, %eax
    2dec:      	jne	0x33cc <generic_retkprobe_filter_arg+0x33cc>
    2df2:      	movzwl	(%r15), %esi
    2df6:      	cmpl	%esi, %edx
    2df8:      	ja	0x271 <generic_retkprobe_filter_arg+0x271>
    2dfe:      	jmp	0x33cc <generic_retkprobe_filter_arg+0x33cc>
    2e03:      	testl	%ebx, %ebx
    2e05:      	je	0x329e <generic_retkprobe_filter_arg+0x329e>
    2e0b:      	cmpl	$0x1, %ebx
    2e0e:      	jne	0x2e26 <generic_retkprobe_filter_arg+0x2e26>
    2e10:      	movl	$0x1, %eax
    2e15:      	leaq	0x38(%rsp), %rsi
    2e1a:      	movq	(%rip), %rdi            # 0x2e21 <generic_retkprobe_filter_arg+0x2e21>
    2e21:      	jmp	0x3321 <generic_retkprobe_filter_arg+0x3321>
    2e26:      	xorl	%ebx, %ebx
    2e28:      	movq	(%rsp), %rdi
    2e2c:      	jmp	0x3351 <generic_retkprobe_filter_arg+0x3351>
    2e31:      	movl	$0x1, %ebx
    2e36:      	movq	(%rsp), %rdi
    2e3a:      	jmp	0x3640 <generic_retkprobe_filter_arg+0x3640>
    2e3f:      	movl	$0xa, %eax
    2e44:      	jmp	0x2e52 <generic_retkprobe_filter_arg+0x2e52>
    2e46:      	movl	$0x6, %eax
    2e4b:      	jmp	0x2e52 <generic_retkprobe_filter_arg+0x2e52>
    2e4d:      	movl	$0x8, %eax
    2e52:      	movl	%eax, %ecx
    2e54:      	andl	$0xf, %ecx
    2e57:      	movl	0x10(%r12,%rcx,4), %ecx
    2e5c:      	cmpl	$-0x1, %ecx
    2e5f:      	je	0x3630 <generic_retkprobe_filter_arg+0x3630>
    2e65:      	movl	%ecx, 0x6c(%rsp)
    2e69:      	movl	%eax, 0x88(%rsp)
    2e70:      	movq	%rsi, 0x60(%rsp)
    2e75:      	movl	$0x1, %eax
    2e7a:      	movq	(%rip), %rdi            # 0x2e81 <generic_retkprobe_filter_arg+0x2e81>
    2e81:      	movq	0x20(%rsp), %rbx
    2e86:      	movq	%rbx, %rsi
    2e89:      	callq	*%rax
    2e8b:      	movq	%rax, %r15
    2e8e:      	movl	$0x1, %eax
    2e93:      	movq	(%rip), %rdi            # 0x2e9a <generic_retkprobe_filter_arg+0x2e9a>
    2e9a:      	movq	%rbx, %rsi
    2e9d:      	callq	*%rax
    2e9f:      	movq	%r15, 0x18(%rsp)
    2ea4:      	testq	%r15, %r15
    2ea7:      	je	0x3630 <generic_retkprobe_filter_arg+0x3630>
    2ead:      	movl	$0x0, %ebx
    2eb2:      	testq	%rax, %rax
    2eb5:      	movq	(%rsp), %rdi
    2eb9:      	movq	0x8(%rsp), %r9
    2ebe:      	movq	0x10(%rsp), %r11
    2ec3:      	je	0x3640 <generic_retkprobe_filter_arg+0x3640>
    2ec9:      	movq	%rax, %r15
    2ecc:      	movl	0x88(%rsp), %ebx
    2ed3:      	cmpl	$0x5, %ebx
    2ed6:      	jg	0x2f15 <generic_retkprobe_filter_arg+0x2f15>
    2ed8:      	movq	0x18(%rsp), %rax
    2edd:      	movb	%bpl, (%rax)
    2ee0:      	leaq	0x1(%rax), %rdi
    2ee4:      	movl	$0x4, %eax
    2ee9:      	movl	%ebp, %esi
    2eeb:      	movq	%r13, %rdx
    2eee:      	callq	*%rax
    2ef0:      	movq	0x60(%rsp), %rsi
    2ef5:      	subl	%ebp, %esi
    2ef7:      	jbe	0x2f53 <generic_retkprobe_filter_arg+0x2f53>
    2ef9:      	movq	0x18(%rsp), %rax
    2efe:      	leaq	(%rax,%rbp), %rdi
    2f02:      	incq	%rdi
    2f05:      	andl	$0xfff, %esi            # imm = 0xFFF
    2f0b:      	movl	$0x4, %eax
    2f10:      	movq	%r15, %rdx
    2f13:      	jmp	0x2f51 <generic_retkprobe_filter_arg+0x2f51>
    2f15:      	movq	0x18(%rsp), %rax
    2f1a:      	movw	%bp, (%rax)
    2f1d:      	leaq	0x2(%rax), %rdi
    2f21:      	movl	$0x4, %eax
    2f26:      	movl	%ebp, %esi
    2f28:      	movq	%r13, %rdx
    2f2b:      	callq	*%rax
    2f2d:      	movq	0x60(%rsp), %rsi
    2f32:      	subl	%ebp, %esi
    2f34:      	jbe	0x2f53 <generic_retkprobe_filter_arg+0x2f53>
    2f36:      	movq	0x18(%rsp), %rax
    2f3b:      	leaq	(%rax,%rbp), %rdi
    2f3f:      	addq	$0x2, %rdi
    2f43:      	andl	$0xfff, %esi            # imm = 0xFFF
    2f49:      	movl	$0x4, %eax
    2f4e:      	movq	%r15, %rdx
    2f51:      	callq	*%rax
    2f53:      	movl	0x6c(%rsp), %eax
    2f57:      	movl	%eax, 0x38(%rsp)
    2f5b:      	cmpl	$0x4, %ebx
    2f5e:      	jle	0x2f9a <generic_retkprobe_filter_arg+0x2f9a>
    2f60:      	cmpl	$0x7, %ebx
    2f63:      	jg	0x3412 <generic_retkprobe_filter_arg+0x3412>
    2f69:      	cmpl	$0x5, %ebx
    2f6c:      	je	0x35ec <generic_retkprobe_filter_arg+0x35ec>
    2f72:      	cmpl	$0x6, %ebx
    2f75:      	je	0x35b3 <generic_retkprobe_filter_arg+0x35b3>
    2f7b:      	cmpl	$0x7, %ebx
    2f7e:      	jne	0x3630 <generic_retkprobe_filter_arg+0x3630>
    2f84:      	movl	$0x1, %eax
    2f89:      	leaq	0x38(%rsp), %rsi
    2f8e:      	movq	(%rip), %rdi            # 0x2f95 <generic_retkprobe_filter_arg+0x2f95>
    2f95:      	jmp	0x3610 <generic_retkprobe_filter_arg+0x3610>
    2f9a:      	cmpl	$0x1, %ebx
    2f9d:      	jle	0x34f8 <generic_retkprobe_filter_arg+0x34f8>
    2fa3:      	cmpl	$0x2, %ebx
    2fa6:      	je	0x35d9 <generic_retkprobe_filter_arg+0x35d9>
    2fac:      	cmpl	$0x3, %ebx
    2faf:      	je	0x35a0 <generic_retkprobe_filter_arg+0x35a0>
    2fb5:      	cmpl	$0x4, %ebx
    2fb8:      	jne	0x3630 <generic_retkprobe_filter_arg+0x3630>
    2fbe:      	movl	$0x1, %eax
    2fc3:      	leaq	0x38(%rsp), %rsi
    2fc8:      	movq	(%rip), %rdi            # 0x2fcf <generic_retkprobe_filter_arg+0x2fcf>
    2fcf:      	jmp	0x3610 <generic_retkprobe_filter_arg+0x3610>
    2fd4:      	cmpl	%edx, %edi
    2fd6:      	setbe	%cl
    2fd9:      	cmpl	%esi, %edx
    2fdb:      	setbe	%dl
    2fde:      	andb	%cl, %dl
    2fe0:      	orb	%dl, %al
    2fe2:      	movq	(%rsp), %rdi
    2fe6:      	testb	%al, %al
    2fe8:      	je	0x271 <generic_retkprobe_filter_arg+0x271>
    2fee:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2ff3:      	cmpq	%rsi, (%r15)
    2ff6:      	ja	0x271 <generic_retkprobe_filter_arg+0x271>
    2ffc:      	jmp	0x3007 <generic_retkprobe_filter_arg+0x3007>
    2ffe:      	cmpq	%rsi, (%r15)
    3001:      	jb	0x271 <generic_retkprobe_filter_arg+0x271>
    3007:      	cmpl	$0x21, %edx
    300a:      	jb	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    3010:      	movq	0x28(%r12), %rdx
    3015:      	cmpl	$0x2, %eax
    3018:      	jle	0x3042 <generic_retkprobe_filter_arg+0x3042>
    301a:      	leal	-0x3(%rax), %ecx
    301d:      	cmpl	$0x2, %ecx
    3020:      	jb	0x3070 <generic_retkprobe_filter_arg+0x3070>
    3022:      	cmpl	$0x6, %eax
    3025:      	je	0x271 <generic_retkprobe_filter_arg+0x271>
    302b:      	cmpl	$0xc, %eax
    302e:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    3034:      	testq	%rdx, (%r15)
    3037:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
    303d:      	jmp	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    3042:      	cmpl	$0x1, %eax
    3045:      	je	0x31a4 <generic_retkprobe_filter_arg+0x31a4>
    304b:      	cmpl	$0x2, %eax
    304e:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    3054:      	cmpl	$0xc, %ecx
    3057:      	je	0x3062 <generic_retkprobe_filter_arg+0x3062>
    3059:      	cmpl	$0xa, %ecx
    305c:      	jne	0x3571 <generic_retkprobe_filter_arg+0x3571>
    3062:      	cmpq	%rdx, (%r15)
    3065:      	jl	0x271 <generic_retkprobe_filter_arg+0x271>
    306b:      	jmp	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    3070:      	cmpq	%rdx, (%r15)
    3073:      	jne	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    3079:      	jmp	0x24f <generic_retkprobe_filter_arg+0x24f>
    307e:      	cmpl	$0xc, %eax
    3081:      	jne	0x3385 <generic_retkprobe_filter_arg+0x3385>
    3087:      	movzbl	(%r15), %esi
    308b:      	testl	%esi, %edx
    308d:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
    3093:      	jmp	0x3385 <generic_retkprobe_filter_arg+0x3385>
    3098:      	cmpl	$0xc, %eax
    309b:      	jne	0x33cc <generic_retkprobe_filter_arg+0x33cc>
    30a1:      	movzwl	(%r15), %esi
    30a5:      	testl	%esi, %edx
    30a7:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
    30ad:      	jmp	0x33cc <generic_retkprobe_filter_arg+0x33cc>
    30b2:      	movl	$0x1, %eax
    30b7:      	movq	(%rip), %rdi            # 0x30be <generic_retkprobe_filter_arg+0x30be>
    30be:      	leaq	0x38(%rsp), %rsi
    30c3:      	jmp	0x3135 <generic_retkprobe_filter_arg+0x3135>
    30c5:      	movl	$0x1, %eax
    30ca:      	leaq	0x38(%rsp), %rsi
    30cf:      	movq	(%rip), %rdi            # 0x30d6 <generic_retkprobe_filter_arg+0x30d6>
    30d6:      	jmp	0x3135 <generic_retkprobe_filter_arg+0x3135>
    30d8:      	movl	$0x1, %eax
    30dd:      	leaq	0x38(%rsp), %rsi
    30e2:      	movq	(%rip), %rdi            # 0x30e9 <generic_retkprobe_filter_arg+0x30e9>
    30e9:      	jmp	0x3135 <generic_retkprobe_filter_arg+0x3135>
    30eb:      	movl	$0x1, %eax
    30f0:      	leaq	0x38(%rsp), %rsi
    30f5:      	movq	(%rip), %rdi            # 0x30fc <generic_retkprobe_filter_arg+0x30fc>
    30fc:      	jmp	0x3135 <generic_retkprobe_filter_arg+0x3135>
    30fe:      	movl	$0x1, %eax
    3103:      	leaq	0x38(%rsp), %rsi
    3108:      	movq	(%rip), %rdi            # 0x310f <generic_retkprobe_filter_arg+0x310f>
    310f:      	jmp	0x3135 <generic_retkprobe_filter_arg+0x3135>
    3111:      	movl	$0x1, %eax
    3116:      	leaq	0x38(%rsp), %rsi
    311b:      	movq	(%rip), %rdi            # 0x3122 <generic_retkprobe_filter_arg+0x3122>
    3122:      	jmp	0x3135 <generic_retkprobe_filter_arg+0x3135>
    3124:      	movl	$0x1, %eax
    3129:      	leaq	0x38(%rsp), %rsi
    312e:      	movq	(%rip), %rdi            # 0x3135 <generic_retkprobe_filter_arg+0x3135>
    3135:      	callq	*%rax
    3137:      	testq	%rax, %rax
    313a:      	je	0x3153 <generic_retkprobe_filter_arg+0x3153>
    313c:      	movq	%rax, %rdi
    313f:      	movl	$0x1, %eax
    3144:      	movq	%r15, %rsi
    3147:      	callq	*%rax
    3149:      	xorl	%ebx, %ebx
    314b:      	testq	%rax, %rax
    314e:      	setne	%bl
    3151:      	jmp	0x3155 <generic_retkprobe_filter_arg+0x3155>
    3153:      	xorl	%ebx, %ebx
    3155:      	movq	(%rsp), %rdi
    3159:      	movq	0x8(%rsp), %r9
    315e:      	movq	0x10(%rsp), %r11
    3163:      	movl	0x4(%r12), %eax
    3168:      	cmpq	$0x25, %rax
    316c:      	ja	0x260 <generic_retkprobe_filter_arg+0x260>
    3172:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    317c:      	btq	%rax, %rcx
    3180:      	jae	0x260 <generic_retkprobe_filter_arg+0x260>
    3186:      	xorq	$0x1, %rbx
    318a:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    318f:      	cmpl	%eax, %esi
    3191:      	ja	0xb8 <generic_retkprobe_filter_arg+0xb8>
    3197:      	cmpl	%edx, %eax
    3199:      	jbe	0x271 <generic_retkprobe_filter_arg+0x271>
    319f:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
    31a4:      	cmpl	$0xc, %ecx
    31a7:      	je	0x31b2 <generic_retkprobe_filter_arg+0x31b2>
    31a9:      	cmpl	$0xa, %ecx
    31ac:      	jne	0x357f <generic_retkprobe_filter_arg+0x357f>
    31b2:      	cmpq	%rdx, (%r15)
    31b5:      	jg	0x271 <generic_retkprobe_filter_arg+0x271>
    31bb:      	jmp	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    31c0:      	movl	$0x1, %eax
    31c5:      	movq	(%rip), %rdi            # 0x31cc <generic_retkprobe_filter_arg+0x31cc>
    31cc:      	leaq	0x38(%rsp), %rsi
    31d1:      	jmp	0x3243 <generic_retkprobe_filter_arg+0x3243>
    31d3:      	movl	$0x1, %eax
    31d8:      	leaq	0x38(%rsp), %rsi
    31dd:      	movq	(%rip), %rdi            # 0x31e4 <generic_retkprobe_filter_arg+0x31e4>
    31e4:      	jmp	0x3243 <generic_retkprobe_filter_arg+0x3243>
    31e6:      	movl	$0x1, %eax
    31eb:      	leaq	0x38(%rsp), %rsi
    31f0:      	movq	(%rip), %rdi            # 0x31f7 <generic_retkprobe_filter_arg+0x31f7>
    31f7:      	jmp	0x3243 <generic_retkprobe_filter_arg+0x3243>
    31f9:      	movl	$0x1, %eax
    31fe:      	leaq	0x38(%rsp), %rsi
    3203:      	movq	(%rip), %rdi            # 0x320a <generic_retkprobe_filter_arg+0x320a>
    320a:      	jmp	0x3243 <generic_retkprobe_filter_arg+0x3243>
    320c:      	movl	$0x1, %eax
    3211:      	leaq	0x38(%rsp), %rsi
    3216:      	movq	(%rip), %rdi            # 0x321d <generic_retkprobe_filter_arg+0x321d>
    321d:      	jmp	0x3243 <generic_retkprobe_filter_arg+0x3243>
    321f:      	movl	$0x1, %eax
    3224:      	leaq	0x38(%rsp), %rsi
    3229:      	movq	(%rip), %rdi            # 0x3230 <generic_retkprobe_filter_arg+0x3230>
    3230:      	jmp	0x3243 <generic_retkprobe_filter_arg+0x3243>
    3232:      	movl	$0x1, %eax
    3237:      	leaq	0x38(%rsp), %rsi
    323c:      	movq	(%rip), %rdi            # 0x3243 <generic_retkprobe_filter_arg+0x3243>
    3243:      	callq	*%rax
    3245:      	testq	%rax, %rax
    3248:      	je	0x3261 <generic_retkprobe_filter_arg+0x3261>
    324a:      	movq	%rax, %rdi
    324d:      	movl	$0x1, %eax
    3252:      	movq	%rbp, %rsi
    3255:      	callq	*%rax
    3257:      	xorl	%ebx, %ebx
    3259:      	testq	%rax, %rax
    325c:      	setne	%bl
    325f:      	jmp	0x3263 <generic_retkprobe_filter_arg+0x3263>
    3261:      	xorl	%ebx, %ebx
    3263:      	movq	(%rsp), %rdi
    3267:      	movq	0x8(%rsp), %r9
    326c:      	movq	0x10(%rsp), %r11
    3271:      	movl	0x4(%r12), %eax
    3276:      	cmpq	$0x25, %rax
    327a:      	ja	0x1bc9 <generic_retkprobe_filter_arg+0x1bc9>
    3280:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    328a:      	btq	%rax, %rcx
    328e:      	movq	0x28(%rsp), %r13
    3293:      	jb	0x3186 <generic_retkprobe_filter_arg+0x3186>
    3299:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    329e:      	movl	$0x1, %eax
    32a3:      	movq	(%rip), %rdi            # 0x32aa <generic_retkprobe_filter_arg+0x32aa>
    32aa:      	leaq	0x38(%rsp), %rsi
    32af:      	jmp	0x3321 <generic_retkprobe_filter_arg+0x3321>
    32b1:      	movl	$0x1, %eax
    32b6:      	leaq	0x38(%rsp), %rsi
    32bb:      	movq	(%rip), %rdi            # 0x32c2 <generic_retkprobe_filter_arg+0x32c2>
    32c2:      	jmp	0x3321 <generic_retkprobe_filter_arg+0x3321>
    32c4:      	movl	$0x1, %eax
    32c9:      	leaq	0x38(%rsp), %rsi
    32ce:      	movq	(%rip), %rdi            # 0x32d5 <generic_retkprobe_filter_arg+0x32d5>
    32d5:      	jmp	0x3321 <generic_retkprobe_filter_arg+0x3321>
    32d7:      	movl	$0x1, %eax
    32dc:      	leaq	0x38(%rsp), %rsi
    32e1:      	movq	(%rip), %rdi            # 0x32e8 <generic_retkprobe_filter_arg+0x32e8>
    32e8:      	jmp	0x3321 <generic_retkprobe_filter_arg+0x3321>
    32ea:      	movl	$0x1, %eax
    32ef:      	leaq	0x38(%rsp), %rsi
    32f4:      	movq	(%rip), %rdi            # 0x32fb <generic_retkprobe_filter_arg+0x32fb>
    32fb:      	jmp	0x3321 <generic_retkprobe_filter_arg+0x3321>
    32fd:      	movl	$0x1, %eax
    3302:      	leaq	0x38(%rsp), %rsi
    3307:      	movq	(%rip), %rdi            # 0x330e <generic_retkprobe_filter_arg+0x330e>
    330e:      	jmp	0x3321 <generic_retkprobe_filter_arg+0x3321>
    3310:      	movl	$0x1, %eax
    3315:      	leaq	0x38(%rsp), %rsi
    331a:      	movq	(%rip), %rdi            # 0x3321 <generic_retkprobe_filter_arg+0x3321>
    3321:      	callq	*%rax
    3323:      	testq	%rax, %rax
    3326:      	je	0x3341 <generic_retkprobe_filter_arg+0x3341>
    3328:      	movq	%rax, %rdi
    332b:      	movl	$0x1, %eax
    3330:      	movq	0x60(%rsp), %rsi
    3335:      	callq	*%rax
    3337:      	xorl	%ebx, %ebx
    3339:      	testq	%rax, %rax
    333c:      	setne	%bl
    333f:      	jmp	0x3343 <generic_retkprobe_filter_arg+0x3343>
    3341:      	xorl	%ebx, %ebx
    3343:      	movq	(%rsp), %rdi
    3347:      	movq	0x8(%rsp), %r9
    334c:      	movq	0x10(%rsp), %r11
    3351:      	movl	0x4(%r12), %eax
    3356:      	cmpq	$0x25, %rax
    335a:      	ja	0x260 <generic_retkprobe_filter_arg+0x260>
    3360:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    336a:      	btq	%rax, %rcx
    336e:      	jb	0x3668 <generic_retkprobe_filter_arg+0x3668>
    3374:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    3379:      	movzbl	(%r15), %esi
    337d:      	cmpl	%esi, %edx
    337f:      	jb	0x271 <generic_retkprobe_filter_arg+0x271>
    3385:      	cmpl	$0x15, %ecx
    3388:      	jb	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    338e:      	movl	0x1c(%r12), %ecx
    3393:      	cmpl	$0x2, %eax
    3396:      	jle	0x351f <generic_retkprobe_filter_arg+0x351f>
    339c:      	leal	-0x3(%rax), %edx
    339f:      	cmpl	$0x2, %edx
    33a2:      	jb	0x355a <generic_retkprobe_filter_arg+0x355a>
    33a8:      	cmpl	$0x6, %eax
    33ab:      	je	0x271 <generic_retkprobe_filter_arg+0x271>
    33b1:      	cmpl	$0xc, %eax
    33b4:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    33ba:      	movzbl	(%r15), %edx
    33be:      	jmp	0x3405 <generic_retkprobe_filter_arg+0x3405>
    33c0:      	movzwl	(%r15), %esi
    33c4:      	cmpl	%esi, %edx
    33c6:      	jb	0x271 <generic_retkprobe_filter_arg+0x271>
    33cc:      	cmpl	$0x15, %ecx
    33cf:      	jb	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    33d5:      	movl	0x1c(%r12), %ecx
    33da:      	cmpl	$0x2, %eax
    33dd:      	jle	0x3537 <generic_retkprobe_filter_arg+0x3537>
    33e3:      	leal	-0x3(%rax), %edx
    33e6:      	cmpl	$0x2, %edx
    33e9:      	jb	0x3560 <generic_retkprobe_filter_arg+0x3560>
    33ef:      	cmpl	$0x6, %eax
    33f2:      	je	0x271 <generic_retkprobe_filter_arg+0x271>
    33f8:      	cmpl	$0xc, %eax
    33fb:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    3401:      	movzwl	(%r15), %edx
    3405:      	testl	%edx, %ecx
    3407:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
    340d:      	jmp	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    3412:      	cmpl	$0x8, %ebx
    3415:      	je	0x35ff <generic_retkprobe_filter_arg+0x35ff>
    341b:      	cmpl	$0x9, %ebx
    341e:      	je	0x35c6 <generic_retkprobe_filter_arg+0x35c6>
    3424:      	cmpl	$0xa, %ebx
    3427:      	jne	0x3630 <generic_retkprobe_filter_arg+0x3630>
    342d:      	movl	$0x1, %eax
    3432:      	leaq	0x38(%rsp), %rsi
    3437:      	movq	(%rip), %rdi            # 0x343e <generic_retkprobe_filter_arg+0x343e>
    343e:      	jmp	0x3610 <generic_retkprobe_filter_arg+0x3610>
    3443:      	cmpl	%esi, (%r15)
    3446:      	ja	0x271 <generic_retkprobe_filter_arg+0x271>
    344c:      	jmp	0x3457 <generic_retkprobe_filter_arg+0x3457>
    344e:      	cmpl	%esi, (%r15)
    3451:      	jb	0x271 <generic_retkprobe_filter_arg+0x271>
    3457:      	cmpl	$0x15, %edx
    345a:      	jb	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    3460:      	movl	0x1c(%r12), %edx
    3465:      	cmpl	$0x2, %eax
    3468:      	jle	0x3492 <generic_retkprobe_filter_arg+0x3492>
    346a:      	leal	-0x3(%rax), %ecx
    346d:      	cmpl	$0x2, %ecx
    3470:      	jb	0x34c5 <generic_retkprobe_filter_arg+0x34c5>
    3472:      	cmpl	$0x6, %eax
    3475:      	je	0x271 <generic_retkprobe_filter_arg+0x271>
    347b:      	cmpl	$0xc, %eax
    347e:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    3484:      	testl	%edx, (%r15)
    3487:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
    348d:      	jmp	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    3492:      	cmpl	$0x1, %eax
    3495:      	je	0x34d3 <generic_retkprobe_filter_arg+0x34d3>
    3497:      	cmpl	$0x2, %eax
    349a:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    34a0:      	cmpl	$0xc, %ecx
    34a3:      	ja	0x3693 <generic_retkprobe_filter_arg+0x3693>
    34a9:      	movl	$0x1402, %esi           # imm = 0x1402
    34ae:      	btl	%ecx, %esi
    34b1:      	jae	0x3693 <generic_retkprobe_filter_arg+0x3693>
    34b7:      	cmpl	%edx, (%r15)
    34ba:      	jl	0x271 <generic_retkprobe_filter_arg+0x271>
    34c0:      	jmp	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    34c5:      	cmpl	%edx, (%r15)
    34c8:      	je	0x24f <generic_retkprobe_filter_arg+0x24f>
    34ce:      	jmp	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    34d3:      	cmpl	$0xc, %ecx
    34d6:      	ja	0x369e <generic_retkprobe_filter_arg+0x369e>
    34dc:      	movl	$0x1402, %esi           # imm = 0x1402
    34e1:      	btl	%ecx, %esi
    34e4:      	jae	0x369e <generic_retkprobe_filter_arg+0x369e>
    34ea:      	cmpl	%edx, (%r15)
    34ed:      	jg	0x271 <generic_retkprobe_filter_arg+0x271>
    34f3:      	jmp	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    34f8:      	testl	%ebx, %ebx
    34fa:      	je	0x358d <generic_retkprobe_filter_arg+0x358d>
    3500:      	cmpl	$0x1, %ebx
    3503:      	jne	0x3630 <generic_retkprobe_filter_arg+0x3630>
    3509:      	movl	$0x1, %eax
    350e:      	leaq	0x38(%rsp), %rsi
    3513:      	movq	(%rip), %rdi            # 0x351a <generic_retkprobe_filter_arg+0x351a>
    351a:      	jmp	0x3610 <generic_retkprobe_filter_arg+0x3610>
    351f:      	cmpl	$0x1, %eax
    3522:      	je	0x367f <generic_retkprobe_filter_arg+0x367f>
    3528:      	cmpl	$0x2, %eax
    352b:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    3531:      	movzbl	(%r15), %edx
    3535:      	jmp	0x354d <generic_retkprobe_filter_arg+0x354d>
    3537:      	cmpl	$0x1, %eax
    353a:      	je	0x3685 <generic_retkprobe_filter_arg+0x3685>
    3540:      	cmpl	$0x2, %eax
    3543:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    3549:      	movzwl	(%r15), %edx
    354d:      	cmpl	%edx, %ecx
    354f:      	ja	0x271 <generic_retkprobe_filter_arg+0x271>
    3555:      	jmp	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    355a:      	movzbl	(%r15), %edx
    355e:      	jmp	0x3564 <generic_retkprobe_filter_arg+0x3564>
    3560:      	movzwl	(%r15), %edx
    3564:      	cmpl	%edx, %ecx
    3566:      	je	0x24f <generic_retkprobe_filter_arg+0x24f>
    356c:      	jmp	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    3571:      	cmpq	%rdx, (%r15)
    3574:      	jb	0x271 <generic_retkprobe_filter_arg+0x271>
    357a:      	jmp	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    357f:      	cmpq	%rdx, (%r15)
    3582:      	ja	0x271 <generic_retkprobe_filter_arg+0x271>
    3588:      	jmp	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    358d:      	movl	$0x1, %eax
    3592:      	movq	(%rip), %rdi            # 0x3599 <generic_retkprobe_filter_arg+0x3599>
    3599:      	leaq	0x38(%rsp), %rsi
    359e:      	jmp	0x3610 <generic_retkprobe_filter_arg+0x3610>
    35a0:      	movl	$0x1, %eax
    35a5:      	leaq	0x38(%rsp), %rsi
    35aa:      	movq	(%rip), %rdi            # 0x35b1 <generic_retkprobe_filter_arg+0x35b1>
    35b1:      	jmp	0x3610 <generic_retkprobe_filter_arg+0x3610>
    35b3:      	movl	$0x1, %eax
    35b8:      	leaq	0x38(%rsp), %rsi
    35bd:      	movq	(%rip), %rdi            # 0x35c4 <generic_retkprobe_filter_arg+0x35c4>
    35c4:      	jmp	0x3610 <generic_retkprobe_filter_arg+0x3610>
    35c6:      	movl	$0x1, %eax
    35cb:      	leaq	0x38(%rsp), %rsi
    35d0:      	movq	(%rip), %rdi            # 0x35d7 <generic_retkprobe_filter_arg+0x35d7>
    35d7:      	jmp	0x3610 <generic_retkprobe_filter_arg+0x3610>
    35d9:      	movl	$0x1, %eax
    35de:      	leaq	0x38(%rsp), %rsi
    35e3:      	movq	(%rip), %rdi            # 0x35ea <generic_retkprobe_filter_arg+0x35ea>
    35ea:      	jmp	0x3610 <generic_retkprobe_filter_arg+0x3610>
    35ec:      	movl	$0x1, %eax
    35f1:      	leaq	0x38(%rsp), %rsi
    35f6:      	movq	(%rip), %rdi            # 0x35fd <generic_retkprobe_filter_arg+0x35fd>
    35fd:      	jmp	0x3610 <generic_retkprobe_filter_arg+0x3610>
    35ff:      	movl	$0x1, %eax
    3604:      	leaq	0x38(%rsp), %rsi
    3609:      	movq	(%rip), %rdi            # 0x3610 <generic_retkprobe_filter_arg+0x3610>
    3610:      	callq	*%rax
    3612:      	testq	%rax, %rax
    3615:      	je	0x3630 <generic_retkprobe_filter_arg+0x3630>
    3617:      	movq	%rax, %rdi
    361a:      	movl	$0x1, %eax
    361f:      	movq	0x18(%rsp), %rsi
    3624:      	callq	*%rax
    3626:      	xorl	%ebx, %ebx
    3628:      	testq	%rax, %rax
    362b:      	setne	%bl
    362e:      	jmp	0x3632 <generic_retkprobe_filter_arg+0x3632>
    3630:      	xorl	%ebx, %ebx
    3632:      	movq	(%rsp), %rdi
    3636:      	movq	0x8(%rsp), %r9
    363b:      	movq	0x10(%rsp), %r11
    3640:      	movl	0x4(%r12), %eax
    3645:      	cmpq	$0x25, %rax
    3649:      	ja	0x1bc9 <generic_retkprobe_filter_arg+0x1bc9>
    364f:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    3659:      	btq	%rax, %rcx
    365d:      	movq	0x28(%rsp), %r13
    3662:      	jae	0x260 <generic_retkprobe_filter_arg+0x260>
    3668:      	xorl	%eax, %eax
    366a:      	testq	%rbx, %rbx
    366d:      	sete	%al
    3670:      	movq	%rax, %rbx
    3673:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    3678:      	xorl	%ebx, %ebx
    367a:      	jmp	0xa8a <generic_retkprobe_filter_arg+0xa8a>
    367f:      	movzbl	(%r15), %edx
    3683:      	jmp	0x3689 <generic_retkprobe_filter_arg+0x3689>
    3685:      	movzwl	(%r15), %edx
    3689:      	cmpl	%edx, %ecx
    368b:      	jb	0x271 <generic_retkprobe_filter_arg+0x271>
    3691:      	jmp	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    3693:      	cmpl	%edx, (%r15)
    3696:      	jb	0x271 <generic_retkprobe_filter_arg+0x271>
    369c:      	jmp	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    369e:      	cmpl	%edx, (%r15)
    36a1:      	ja	0x271 <generic_retkprobe_filter_arg+0x271>
    36a7:      	orl	$0x2, %eax
    36aa:      	cmpl	$0x6, %eax
    36ad:      	je	0x271 <generic_retkprobe_filter_arg+0x271>
    36b3:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
    36b8:      	nopl	(%rax,%rax)

00000000000036c0 <generic_retkprobe_actions>:
    36c0:      	pushq	%rbp
    36c1:      	pushq	%r15
    36c3:      	pushq	%r14
    36c5:      	pushq	%r13
    36c7:      	pushq	%r12
    36c9:      	pushq	%rbx
    36ca:      	subq	$0xa8, %rsp
    36d1:      	movq	%rdi, 0x80(%rsp)
    36d9:      	movl	$0x0, 0x88(%rsp)
    36e4:      	movq	(%rip), %rdi            # 0x36eb <generic_retkprobe_actions+0x2b>
    36eb:      	leaq	0x88(%rsp), %rsi
    36f3:      	movl	$0x1, %eax
    36f8:      	callq	*%rax
    36fa:      	testq	%rax, %rax
    36fd:      	je	0x41f8 <generic_retkprobe_actions+0xb38>
    3703:      	movq	%rax, %rsi
    3706:      	movl	0x5f04(%rax), %ebx
    370c:      	cmpl	$0x2, %ebx
    370f:      	jl	0x41f8 <generic_retkprobe_actions+0xb38>
    3715:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    371c:      	movq	(%rip), %rdi            # 0x3723 <generic_retkprobe_actions+0x63>
    3723:      	movl	$0x1, %eax
    3728:      	callq	*%rax
    372a:      	testq	%rax, %rax
    372d:      	je	0x41f8 <generic_retkprobe_actions+0xb38>
    3733:      	movq	%rax, %r14
    3736:      	movl	%ebx, %eax
    3738:      	andl	$0x7ff, %eax            # imm = 0x7FF
    373d:      	addl	(%r14,%rax), %ebx
    3741:      	movl	$0x0, 0x8c(%rsp)
    374c:      	movq	(%rip), %rdi            # 0x3753 <generic_retkprobe_actions+0x93>
    3753:      	leaq	0x8c(%rsp), %rsi
    375b:      	movl	$0x1, %eax
    3760:      	andl	$0x7ff, %ebx            # imm = 0x7FF
    3766:      	callq	*%rax
    3768:      	testq	%rax, %rax
    376b:      	je	0x3792 <generic_retkprobe_actions+0xd2>
    376d:      	cmpb	$0x0, (%rax)
    3770:      	sete	0x17(%rsp)
    3775:      	je	0x37ad <generic_retkprobe_actions+0xed>
    3777:      	movl	$0x5, %eax
    377c:      	movq	%rax, 0x78(%rsp)
    3781:      	movl	$0x9, %eax
    3786:      	movq	%rax, 0x70(%rsp)
    378b:      	movl	$0x7, %eax
    3790:      	jmp	0x37c6 <generic_retkprobe_actions+0x106>
    3792:      	movl	$0x4, %eax
    3797:      	movq	%rax, 0x78(%rsp)
    379c:      	movl	$0x8, %eax
    37a1:      	movq	%rax, 0x70(%rsp)
    37a6:      	movb	$0x1, 0x17(%rsp)
    37ab:      	jmp	0x37c1 <generic_retkprobe_actions+0x101>
    37ad:      	movl	$0x4, %eax
    37b2:      	movq	%rax, 0x78(%rsp)
    37b7:      	movl	$0x8, %eax
    37bc:      	movq	%rax, 0x70(%rsp)
    37c1:      	movl	$0x6, %eax
    37c6:      	movq	%rax, 0x68(%rsp)
    37cb:      	addq	%rbx, %r14
    37ce:      	movb	$0x1, %al
    37d0:      	movl	%eax, 0x44(%rsp)
    37d4:      	movq	(%rip), %rbp            # 0x37db <generic_retkprobe_actions+0x11b>
    37db:      	xorl	%r12d, %r12d
    37de:      	xorl	%r15d, %r15d
    37e1:      	jmp	0x380a <generic_retkprobe_actions+0x14a>
    37e3:      	incl	%r15d
    37e6:      	movl	0x4(%r14,%r15,4), %eax
    37eb:      	movl	%eax, 0x78(%rdx)
    37ee:      	nop
    37f0:      	movq	%r13, 0x70(%rdx)
    37f4:      	incl	%r15d
    37f7:      	movl	%r15d, %ebx
    37fa:      	incl	%r12d
    37fd:      	movl	%ebx, %r15d
    3800:      	cmpl	$0x3, %r12d
    3804:      	je	0x41d1 <generic_retkprobe_actions+0xb11>
    380a:      	leal	0x4(,%r15,4), %eax
    3812:      	cmpl	(%r14), %eax
    3815:      	jae	0x41d1 <generic_retkprobe_actions+0xb11>
    381b:      	movl	%r15d, %eax
    381e:      	movslq	0x4(%r14,%rax,4), %r13
    3823:      	movl	$0x0, 0x90(%rsp)
    382e:      	movl	$0x1, %eax
    3833:      	leaq	0x90(%rsp), %rsi
    383b:      	movq	%rbp, %rdi
    383e:      	callq	*%rax
    3840:      	xorl	%ebx, %ebx
    3842:      	testq	%rax, %rax
    3845:      	je	0x37fa <generic_retkprobe_actions+0x13a>
    3847:      	movq	%rax, %rdx
    384a:      	cmpl	$0x7, %r13d
    384e:      	jg	0x3880 <generic_retkprobe_actions+0x1c0>
    3850:      	cmpl	$0x3, %r13d
    3854:      	jg	0x38d6 <generic_retkprobe_actions+0x216>
    385a:      	cmpl	$0x1, %r13d
    385e:      	jg	0x3a27 <generic_retkprobe_actions+0x367>
    3864:      	testl	%r13d, %r13d
    3867:      	je	0x3c37 <generic_retkprobe_actions+0x577>
    386d:      	cmpl	$0x1, %r13d
    3871:      	je	0x3a40 <generic_retkprobe_actions+0x380>
    3877:      	jmp	0x37f0 <generic_retkprobe_actions+0x130>
    387c:      	nopl	(%rax)
    3880:      	cmpl	$0xb, %r13d
    3884:      	jg	0x39f0 <generic_retkprobe_actions+0x330>
    388a:      	leal	-0xa(%r13), %eax
    388e:      	cmpl	$0x2, %eax
    3891:      	jb	0x3acf <generic_retkprobe_actions+0x40f>
    3897:      	cmpl	$0x8, %r13d
    389b:      	je	0x3b91 <generic_retkprobe_actions+0x4d1>
    38a1:      	cmpl	$0x9, %r13d
    38a5:      	jne	0x37f0 <generic_retkprobe_actions+0x130>
    38ab:      	movq	%r13, 0x8(%rsp)
    38b0:      	movq	%r14, %rax
    38b3:      	movq	%rbp, %r13
    38b6:      	incl	%r15d
    38b9:      	movl	0x4(%r14,%r15,4), %eax
    38be:      	movq	%rdx, %rbp
    38c1:      	movl	$0x3, %ebx
    38c6:      	cmpb	$0x0, 0x17(%rsp)
    38cb:      	jne	0x3d13 <generic_retkprobe_actions+0x653>
    38d1:      	jmp	0x3d38 <generic_retkprobe_actions+0x678>
    38d6:      	leal	-0x6(%r13), %eax
    38da:      	cmpl	$0x2, %eax
    38dd:      	jb	0x37e3 <generic_retkprobe_actions+0x123>
    38e3:      	cmpl	$0x4, %r13d
    38e7:      	je	0x3b9e <generic_retkprobe_actions+0x4de>
    38ed:      	cmpl	$0x5, %r13d
    38f1:      	jne	0x37f0 <generic_retkprobe_actions+0x130>
    38f7:      	leal	0x1(%r15), %eax
    38fb:      	movl	0x4(%r14,%rax,4), %eax
    3900:      	addl	$0x2, %r15d
    3904:      	movl	0x4(%r14,%r15,4), %ebx
    3909:      	movq	$0x0, 0x20(%rsp)
    3912:      	movq	$0x0, 0x18(%rsp)
    391b:      	andl	$0x7, %eax
    391e:      	cmpl	$0x4, %eax
    3921:      	ja	0x37f0 <generic_retkprobe_actions+0x130>
    3927:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    392f:      	jne	0x37f0 <generic_retkprobe_actions+0x130>
    3935:      	movq	0x5e78(%rdx,%rax,8), %rax
    393d:      	andl	$0x7ff, %eax            # imm = 0x7FF
    3942:      	movl	0x90(%rdx,%rax), %eax
    3949:      	movl	%eax, 0x20(%rsp)
    394d:      	movl	$0xe, %eax
    3952:      	movq	%rdx, 0x8(%rsp)
    3957:      	callq	*%rax
    3959:      	shrq	$0x20, %rax
    395d:      	movq	%rax, 0x18(%rsp)
    3962:      	movl	$0x1, %eax
    3967:      	leaq	0x18(%rsp), %rsi
    396c:      	movq	(%rip), %rdi            # 0x3973 <generic_retkprobe_actions+0x2b3>
    3973:      	callq	*%rax
    3975:      	movq	0x8(%rsp), %rdx
    397a:      	testq	%rax, %rax
    397d:      	je	0x37f0 <generic_retkprobe_actions+0x130>
    3983:      	andl	$0x7, %ebx
    3986:      	cmpl	$0x4, %ebx
    3989:      	ja	0x37f0 <generic_retkprobe_actions+0x130>
    398f:      	cmpl	$0x0, 0x5ea0(%rdx,%rbx,4)
    3997:      	jne	0x37f0 <generic_retkprobe_actions+0x130>
    399d:      	movq	0x5e78(%rdx,%rbx,8), %rcx
    39a5:      	movl	$0x0, 0x24(%rsp)
    39ad:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    39b3:      	movl	0x90(%rdx,%rcx), %ecx
    39ba:      	movl	%ecx, 0x20(%rsp)
    39be:      	movq	%rax, %rbx
    39c1:      	movl	$0xe, %eax
    39c6:      	callq	*%rax
    39c8:      	shrq	$0x20, %rax
    39cc:      	movq	%rax, 0x18(%rsp)
    39d1:      	movl	$0x2, %eax
    39d6:      	xorl	%ecx, %ecx
    39d8:      	leaq	0x18(%rsp), %rsi
    39dd:      	movq	(%rip), %rdi            # 0x39e4 <generic_retkprobe_actions+0x324>
    39e4:      	movq	%rbx, %rdx
    39e7:      	xorl	%ecx, %ecx
    39e9:      	callq	*%rax
    39eb:      	jmp	0x3c2d <generic_retkprobe_actions+0x56d>
    39f0:      	cmpl	$0xc, %r13d
    39f4:      	je	0x3d24 <generic_retkprobe_actions+0x664>
    39fa:      	cmpl	$0xd, %r13d
    39fe:      	je	0x3bb6 <generic_retkprobe_actions+0x4f6>
    3a04:      	cmpl	$0xe, %r13d
    3a08:      	jne	0x37f0 <generic_retkprobe_actions+0x130>
    3a0e:      	movq	%r13, 0x8(%rsp)
    3a13:      	movq	%rbp, %r13
    3a16:      	movq	%rdx, %rbp
    3a19:      	addl	$0x2, %r15d
    3a1d:      	movq	0x70(%rsp), %rbx
    3a22:      	jmp	0x3d38 <generic_retkprobe_actions+0x678>
    3a27:      	movl	$0x9, %eax
    3a2c:      	cmpl	$0x2, %r13d
    3a30:      	je	0x3cfc <generic_retkprobe_actions+0x63c>
    3a36:      	cmpl	$0x3, %r13d
    3a3a:      	jne	0x37f0 <generic_retkprobe_actions+0x130>
    3a40:      	movq	%rdx, 0x8(%rsp)
    3a45:      	leal	0x1(%r15), %eax
    3a49:      	movq	%r14, %rcx
    3a4c:      	movl	0x4(%r14,%rax,4), %r14d
    3a51:      	addl	$0x2, %r15d
    3a55:      	movq	%rcx, %rbp
    3a58:      	movl	0x4(%rcx,%r15,4), %eax
    3a5d:      	movq	%rax, 0x38(%rsp)
    3a62:      	movq	$0x0, 0x20(%rsp)
    3a6b:      	movq	$0x0, 0x18(%rsp)
    3a74:      	movl	$0x0, 0x28(%rsp)
    3a7c:      	movl	$0x1, %eax
    3a81:      	leaq	0x28(%rsp), %rsi
    3a86:      	movq	(%rip), %rdi            # 0x3a8d <generic_retkprobe_actions+0x3cd>
    3a8d:      	callq	*%rax
    3a8f:      	xorl	%ecx, %ecx
    3a91:      	testq	%rax, %rax
    3a94:      	je	0x3ec8 <generic_retkprobe_actions+0x808>
    3a9a:      	andl	$0x7, %r14d
    3a9e:      	cmpl	$0x4, %r14d
    3aa2:      	movq	0x8(%rsp), %rdx
    3aa7:      	ja	0x3ab8 <generic_retkprobe_actions+0x3f8>
    3aa9:      	cmpl	$0x0, 0x5ea0(%rdx,%r14,4)
    3ab2:      	je	0x3d6d <generic_retkprobe_actions+0x6ad>
    3ab8:      	movq	%rbp, %r14
    3abb:      	movq	(%rip), %rbp            # 0x3ac2 <generic_retkprobe_actions+0x402>
    3ac2:      	testl	%ecx, %ecx
    3ac4:      	jne	0x37fa <generic_retkprobe_actions+0x13a>
    3aca:      	jmp	0x37f0 <generic_retkprobe_actions+0x130>
    3acf:      	incl	%r15d
    3ad2:      	movl	0x4(%r14,%r15,4), %eax
    3ad7:      	andl	$0x7, %eax
    3ada:      	xorl	%ecx, %ecx
    3adc:      	cmpl	$0x4, %eax
    3adf:      	ja	0x3ed7 <generic_retkprobe_actions+0x817>
    3ae5:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    3aed:      	jne	0x3ed7 <generic_retkprobe_actions+0x817>
    3af3:      	movq	0x5e78(%rdx,%rax,8), %rax
    3afb:      	andl	$0x7ff, %eax            # imm = 0x7FF
    3b00:      	movq	0xb8(%rdx,%rax), %rax
    3b08:      	movq	%rax, 0x28(%rsp)
    3b0d:      	testq	%rax, %rax
    3b10:      	je	0x3ed7 <generic_retkprobe_actions+0x817>
    3b16:      	movq	%rdx, 0x8(%rsp)
    3b1b:      	cmpl	$0xa, %r13d
    3b1f:      	jne	0x3ee4 <generic_retkprobe_actions+0x824>
    3b25:      	movl	$0xe, %eax
    3b2a:      	callq	*%rax
    3b2c:      	movq	%rax, 0x38(%rsp)
    3b31:      	shrq	$0x20, %rax
    3b35:      	movl	%eax, 0x18(%rsp)
    3b39:      	movl	$0x1, %eax
    3b3e:      	leaq	0x18(%rsp), %rsi
    3b43:      	movq	(%rip), %rdi            # 0x3b4a <generic_retkprobe_actions+0x48a>
    3b4a:      	callq	*%rax
    3b4c:      	xorl	%ecx, %ecx
    3b4e:      	testq	%rax, %rax
    3b51:      	movq	0x8(%rsp), %rdx
    3b56:      	je	0x3ed7 <generic_retkprobe_actions+0x817>
    3b5c:      	movl	(%rax), %ecx
    3b5e:      	movl	%ecx, 0x18(%rsp)
    3b62:      	movq	0x38(%rsp), %rcx
    3b67:      	movl	%ecx, 0x1c(%rsp)
    3b6b:      	movq	0x8(%rax), %rax
    3b6f:      	movq	%rax, 0x20(%rsp)
    3b74:      	xorl	%ecx, %ecx
    3b76:      	movl	$0x2, %eax
    3b7b:      	leaq	0x28(%rsp), %rsi
    3b80:      	leaq	0x18(%rsp), %rdx
    3b85:      	movq	(%rip), %rdi            # 0x3b8c <generic_retkprobe_actions+0x4cc>
    3b8c:      	jmp	0x3e30 <generic_retkprobe_actions+0x770>
    3b91:      	movl	$0x0, 0x44(%rsp)
    3b99:      	jmp	0x37f0 <generic_retkprobe_actions+0x130>
    3b9e:      	movq	%r13, 0x8(%rsp)
    3ba3:      	movq	%rbp, %r13
    3ba6:      	movq	%rdx, %rbp
    3ba9:      	incl	%r15d
    3bac:      	movq	0x78(%rsp), %rbx
    3bb1:      	jmp	0x3d38 <generic_retkprobe_actions+0x678>
    3bb6:      	movq	%rdx, 0x8(%rsp)
    3bbb:      	movl	$0xe, %eax
    3bc0:      	callq	*%rax
    3bc2:      	movq	%rax, 0x50(%rsp)
    3bc7:      	movl	$0x1, %eax
    3bcc:      	leaq	0x50(%rsp), %rsi
    3bd1:      	movq	(%rip), %rdi            # 0x3bd8 <generic_retkprobe_actions+0x518>
    3bd8:      	callq	*%rax
    3bda:      	testq	%rax, %rax
    3bdd:      	je	0x3c2d <generic_retkprobe_actions+0x56d>
    3bdf:      	movq	0x4(%rax), %rax
    3be3:      	movq	%rax, 0x28(%rsp)
    3be8:      	movl	$0x2, 0x30(%rsp)
    3bf0:      	movl	$0x1, %eax
    3bf5:      	leaq	0x28(%rsp), %rsi
    3bfa:      	movq	(%rip), %rbx            # 0x3c01 <generic_retkprobe_actions+0x541>
    3c01:      	movq	%rbx, %rdi
    3c04:      	callq	*%rax
    3c06:      	movl	$0x1, 0x5c(%rsp)
    3c0e:      	testq	%rax, %rax
    3c11:      	je	0x3e48 <generic_retkprobe_actions+0x788>
    3c17:      	lock
    3c18:      	incl	(%rax)
    3c1a:      	movl	$0x3, %eax
    3c1f:      	leaq	0x50(%rsp), %rsi
    3c24:      	movq	(%rip), %rdi            # 0x3c2b <generic_retkprobe_actions+0x56b>
    3c2b:      	callq	*%rax
    3c2d:      	movq	0x8(%rsp), %rdx
    3c32:      	jmp	0x37f0 <generic_retkprobe_actions+0x130>
    3c37:      	movq	%rdx, 0x8(%rsp)
    3c3c:      	leal	0x1(%r15), %eax
    3c40:      	movl	0x4(%r14,%rax,4), %ebx
    3c45:      	leal	0x2(%r15), %eax
    3c49:      	movl	0x4(%r14,%rax,4), %eax
    3c4e:      	movl	%eax, 0x60(%rsp)
    3c52:      	movl	$0x7d, %eax
    3c57:      	callq	*%rax
    3c59:      	movq	%rax, 0x18(%rsp)
    3c5e:      	movl	$0x0, 0x50(%rsp)
    3c66:      	movq	%rbx, 0xa0(%rsp)
    3c6e:      	testq	%rbx, %rbx
    3c71:      	je	0x40e8 <generic_retkprobe_actions+0xa28>
    3c77:      	movl	$0x1, %eax
    3c7c:      	movq	(%rip), %rdi            # 0x3c83 <generic_retkprobe_actions+0x5c3>
    3c83:      	leaq	0x50(%rsp), %rsi
    3c88:      	callq	*%rax
    3c8a:      	testq	%rax, %rax
    3c8d:      	je	0x40e8 <generic_retkprobe_actions+0xa28>
    3c93:      	movq	%rax, 0x48(%rsp)
    3c98:      	movq	%rax, %rbx
    3c9b:      	movl	$0x1, %eax
    3ca0:      	leaq	0x50(%rsp), %rsi
    3ca5:      	movq	(%rip), %rdi            # 0x3cac <generic_retkprobe_actions+0x5ec>
    3cac:      	callq	*%rax
    3cae:      	movq	%rax, %rdx
    3cb1:      	movq	0x8(%rsp), %rcx
    3cb6:      	movq	0x60(%rcx), %rax
    3cba:      	movq	%rax, (%rbx)
    3cbd:      	movq	0x70(%rcx), %rax
    3cc1:      	movq	%rax, 0x8(%rbx)
    3cc5:      	xorl	%eax, %eax
    3cc7:      	movq	%rax, 0x38(%rsp)
    3ccc:      	movl	$0x0, %eax
    3cd1:      	movl	0x60(%rsp), %esi
    3cd5:      	cmpl	$0x2, %esi
    3cd8:      	je	0x3f0f <generic_retkprobe_actions+0x84f>
    3cde:      	cmpl	$0x1, %esi
    3ce1:      	je	0x3f0c <generic_retkprobe_actions+0x84c>
    3ce7:      	testl	%esi, %esi
    3ce9:      	jne	0x40e8 <generic_retkprobe_actions+0xa28>
    3cef:      	movq	0x8(%rsp), %rax
    3cf4:      	movl	0x7c(%rax), %eax
    3cf7:      	jmp	0x3f0f <generic_retkprobe_actions+0x84f>
    3cfc:      	movq	%r13, 0x8(%rsp)
    3d01:      	movq	%rbp, %r13
    3d04:      	movq	%rdx, %rbp
    3d07:      	movl	$0x3, %ebx
    3d0c:      	cmpb	$0x0, 0x17(%rsp)
    3d11:      	je	0x3d38 <generic_retkprobe_actions+0x678>
    3d13:      	movslq	%eax, %rdi
    3d16:      	movl	$0x6d, %eax
    3d1b:      	callq	*%rax
    3d1d:      	movl	$0x2, %ebx
    3d22:      	jmp	0x3d38 <generic_retkprobe_actions+0x678>
    3d24:      	movq	%r13, 0x8(%rsp)
    3d29:      	movq	%rbp, %r13
    3d2c:      	movq	%rdx, %rbp
    3d2f:      	addl	$0x3, %r15d
    3d33:      	movq	0x68(%rsp), %rbx
    3d38:      	movl	$0x0, 0x18(%rsp)
    3d40:      	movl	$0x1, %eax
    3d45:      	leaq	0x18(%rsp), %rsi
    3d4a:      	movq	(%rip), %rdi            # 0x3d51 <generic_retkprobe_actions+0x691>
    3d51:      	callq	*%rax
    3d53:      	testq	%rax, %rax
    3d56:      	je	0x3d5d <generic_retkprobe_actions+0x69d>
    3d58:      	lock
    3d59:      	incq	(%rax,%rbx,8)
    3d5d:      	movq	%rbp, %rdx
    3d60:      	movq	%r13, %rbp
    3d63:      	movq	0x8(%rsp), %r13
    3d68:      	jmp	0x37f0 <generic_retkprobe_actions+0x130>
    3d6d:      	movq	%rax, 0x48(%rsp)
    3d72:      	movq	0x5e78(%rdx,%r14,8), %rax
    3d7a:      	movl	$0x0, 0x24(%rsp)
    3d82:      	andl	$0x7ff, %eax            # imm = 0x7FF
    3d87:      	movl	0x90(%rdx,%rax), %eax
    3d8e:      	movl	%eax, 0x20(%rsp)
    3d92:      	movl	$0xe, %eax
    3d97:      	callq	*%rax
    3d99:      	shrq	$0x20, %rax
    3d9d:      	movq	%rax, 0x18(%rsp)
    3da2:      	cmpl	$0x1, %r13d
    3da6:      	jne	0x3eb2 <generic_retkprobe_actions+0x7f2>
    3dac:      	movq	0x38(%rsp), %rax
    3db1:      	andl	$0x7, %eax
    3db4:      	cmpl	$0x4, %eax
    3db7:      	movq	%rbp, %r14
    3dba:      	movl	$0x0, %ecx
    3dbf:      	ja	0x3ecb <generic_retkprobe_actions+0x80b>
    3dc5:      	movq	0x8(%rsp), %rdx
    3dca:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    3dd2:      	movq	(%rip), %rbp            # 0x3dd9 <generic_retkprobe_actions+0x719>
    3dd9:      	jne	0x3ed7 <generic_retkprobe_actions+0x817>
    3ddf:      	movq	0x5e78(%rdx,%rax,8), %rax
    3de7:      	andl	$0x7ff, %eax            # imm = 0x7FF
    3dec:      	addq	%rax, %rdx
    3def:      	addq	$0x90, %rdx
    3df6:      	movq	0x8(%rsp), %rcx
    3dfb:      	movl	0x90(%rcx,%rax), %esi
    3e02:      	andl	$0xfff, %esi            # imm = 0xFFF
    3e08:      	addq	$0x8, %rsi
    3e0c:      	movl	$0x4, %eax
    3e11:      	movq	0x48(%rsp), %rdi
    3e16:      	callq	*%rax
    3e18:      	xorl	%ecx, %ecx
    3e1a:      	movl	$0x2, %eax
    3e1f:      	leaq	0x18(%rsp), %rsi
    3e24:      	movq	(%rip), %rdi            # 0x3e2b <generic_retkprobe_actions+0x76b>
    3e2b:      	movq	0x48(%rsp), %rdx
    3e30:      	xorl	%ecx, %ecx
    3e32:      	callq	*%rax
    3e34:      	xorl	%ecx, %ecx
    3e36:      	movq	0x8(%rsp), %rdx
    3e3b:      	testl	%ecx, %ecx
    3e3d:      	jne	0x37fa <generic_retkprobe_actions+0x13a>
    3e43:      	jmp	0x37f0 <generic_retkprobe_actions+0x130>
    3e48:      	movl	$0x2, %eax
    3e4d:      	movl	$0x1, %ecx
    3e52:      	leaq	0x5c(%rsp), %rdx
    3e57:      	leaq	0x28(%rsp), %rsi
    3e5c:      	movq	%rbx, %rdi
    3e5f:      	callq	*%rax
    3e61:      	testq	%rax, %rax
    3e64:      	je	0x3c1a <generic_retkprobe_actions+0x55a>
    3e6a:      	movq	%rax, 0x38(%rsp)
    3e6f:      	negl	%eax
    3e71:      	movw	%ax, 0x18(%rsp)
    3e76:      	movw	$0x3, 0x1a(%rsp)
    3e7d:      	movabsq	$0x20000003b, %rax      # imm = 0x20000003B
    3e87:      	movq	%rax, 0x1c(%rsp)
    3e8c:      	movl	$0x1, %eax
    3e91:      	leaq	0x18(%rsp), %rsi
    3e96:      	movq	(%rip), %rbx            # 0x3e9d <generic_retkprobe_actions+0x7dd>
    3e9d:      	movq	%rbx, %rdi
    3ea0:      	callq	*%rax
    3ea2:      	testq	%rax, %rax
    3ea5:      	je	0x4178 <generic_retkprobe_actions+0xab8>
    3eab:      	incl	(%rax)
    3ead:      	jmp	0x419e <generic_retkprobe_actions+0xade>
    3eb2:      	movl	$0x3, %eax
    3eb7:      	leaq	0x18(%rsp), %rsi
    3ebc:      	movq	(%rip), %rdi            # 0x3ec3 <generic_retkprobe_actions+0x803>
    3ec3:      	callq	*%rax
    3ec5:      	movq	%rax, %rcx
    3ec8:      	movq	%rbp, %r14
    3ecb:      	movq	(%rip), %rbp            # 0x3ed2 <generic_retkprobe_actions+0x812>
    3ed2:      	movq	0x8(%rsp), %rdx
    3ed7:      	testl	%ecx, %ecx
    3ed9:      	jne	0x37fa <generic_retkprobe_actions+0x13a>
    3edf:      	jmp	0x37f0 <generic_retkprobe_actions+0x130>
    3ee4:      	movl	$0x3, %eax
    3ee9:      	leaq	0x28(%rsp), %rsi
    3eee:      	movq	(%rip), %rdi            # 0x3ef5 <generic_retkprobe_actions+0x835>
    3ef5:      	callq	*%rax
    3ef7:      	movq	%rax, %rcx
    3efa:      	movq	0x8(%rsp), %rdx
    3eff:      	testl	%ecx, %ecx
    3f01:      	jne	0x37fa <generic_retkprobe_actions+0x13a>
    3f07:      	jmp	0x37f0 <generic_retkprobe_actions+0x130>
    3f0c:      	movl	0x10(%rcx), %eax
    3f0f:      	movq	%r14, 0x60(%rsp)
    3f14:      	movl	%eax, %eax
    3f16:      	movq	%rbx, 0x98(%rsp)
    3f1e:      	movq	%rax, 0x10(%rbx)
    3f22:      	movq	0x48(%rsp), %rdi
    3f27:      	addq	$0x18, %rdi
    3f2b:      	movl	$0x4, %eax
    3f30:      	movl	$0xc8, %ecx
    3f35:      	movq	%rdi, 0x48(%rsp)
    3f3a:      	movl	$0xc8, %esi
    3f3f:      	callq	*%rax
    3f41:      	xorl	%r14d, %r14d
    3f44:      	leaq	0x28(%rsp), %rbx
    3f49:      	jmp	0x3f63 <generic_retkprobe_actions+0x8a3>
    3f4b:      	nopl	(%rax,%rax)
    3f50:      	leaq	0x28(%rsp), %rbx
    3f55:      	addq	$0x4, %r14
    3f59:      	cmpq	$0x14, %r14
    3f5d:      	je	0x408b <generic_retkprobe_actions+0x9cb>
    3f63:      	movl	$0x0, 0x28(%rsp)
    3f6b:      	movl	$0x1, %eax
    3f70:      	movq	%rbp, %rdi
    3f73:      	movq	%rbx, %rsi
    3f76:      	callq	*%rax
    3f78:      	testq	%rax, %rax
    3f7b:      	je	0x408b <generic_retkprobe_actions+0x9cb>
    3f81:      	movq	%rax, %rsi
    3f84:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    3f8b:      	movl	$0x1, %eax
    3f90:      	movq	(%rip), %rdi            # 0x3f97 <generic_retkprobe_actions+0x8d7>
    3f97:      	callq	*%rax
    3f99:      	testq	%rax, %rax
    3f9c:      	je	0x408b <generic_retkprobe_actions+0x9cb>
    3fa2:      	cmpl	$-0x1, 0x40(%rax,%r14)
    3fa8:      	movq	0x8(%rsp), %rdx
    3fad:      	je	0x408b <generic_retkprobe_actions+0x9cb>
    3fb3:      	movq	0x5e78(%rdx,%r14,2), %rax
    3fbb:      	movl	0x4(%rdx), %ecx
    3fbe:      	cmpq	%rcx, %rax
    3fc1:      	jge	0x408b <generic_retkprobe_actions+0x9cb>
    3fc7:      	cmpq	$0x10, %r14
    3fcb:      	je	0x4032 <generic_retkprobe_actions+0x972>
    3fcd:      	movl	$0x0, 0x28(%rsp)
    3fd5:      	movl	$0x1, %eax
    3fda:      	movq	%rbp, %rdi
    3fdd:      	movq	%rbx, %rsi
    3fe0:      	callq	*%rax
    3fe2:      	testq	%rax, %rax
    3fe5:      	je	0x4025 <generic_retkprobe_actions+0x965>
    3fe7:      	movq	%rax, %rsi
    3fea:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    3ff1:      	movl	$0x1, %eax
    3ff6:      	movq	(%rip), %rdi            # 0x3ffd <generic_retkprobe_actions+0x93d>
    3ffd:      	callq	*%rax
    3fff:      	testq	%rax, %rax
    4002:      	je	0x4025 <generic_retkprobe_actions+0x965>
    4004:      	cmpl	$-0x1, 0x44(%rax,%r14)
    400a:      	movq	0x8(%rsp), %rdx
    400f:      	movq	0x5e78(%rdx,%r14,2), %rax
    4017:      	je	0x4032 <generic_retkprobe_actions+0x972>
    4019:      	movl	0x5e80(%rdx,%r14,2), %ebx
    4021:      	subl	%eax, %ebx
    4023:      	jmp	0x403a <generic_retkprobe_actions+0x97a>
    4025:      	movq	0x8(%rsp), %rdx
    402a:      	movq	0x5e78(%rdx,%r14,2), %rax
    4032:      	movl	0x4(%rdx), %ebx
    4035:      	subl	%eax, %ebx
    4037:      	addl	$0x4, %ebx
    403a:      	testl	%ebx, %ebx
    403c:      	jle	0x3f50 <generic_retkprobe_actions+0x890>
    4042:      	addl	$0x3ffc, %eax           # imm = 0x3FFC
    4047:      	andl	$0x3fff, %eax           # imm = 0x3FFF
    404c:      	cmpl	$0x28, %ebx
    404f:      	movl	$0x28, %ecx
    4054:      	cmovgel	%ecx, %ebx
    4057:      	movzbl	0x38(%rsp), %ebp
    405c:      	movq	0x48(%rsp), %rcx
    4061:      	leaq	(%rcx,%rbp), %rdi
    4065:      	addq	%rax, %rdx
    4068:      	addq	$0x90, %rdx
    406f:      	movl	$0x4, %eax
    4074:      	movl	%ebx, %esi
    4076:      	callq	*%rax
    4078:      	addl	%ebp, %ebx
    407a:      	movq	(%rip), %rbp            # 0x4081 <generic_retkprobe_actions+0x9c1>
    4081:      	movq	%rbx, 0x38(%rsp)
    4086:      	jmp	0x3f50 <generic_retkprobe_actions+0x890>
    408b:      	movl	$0x1, %eax
    4090:      	movq	(%rip), %rdi            # 0x4097 <generic_retkprobe_actions+0x9d7>
    4097:      	movq	0x98(%rsp), %rbx
    409f:      	movq	%rbx, %rsi
    40a2:      	callq	*%rax
    40a4:      	testq	%rax, %rax
    40a7:      	movq	0x60(%rsp), %r14
    40ac:      	je	0x40ce <generic_retkprobe_actions+0xa0e>
    40ae:      	imulq	$-0xf4240, 0xa0(%rsp), %rcx # imm = 0xFFF0BDC0
    40ba:      	addq	0x18(%rsp), %rcx
    40bf:      	cmpq	%rcx, (%rax)
    40c2:      	jbe	0x40ce <generic_retkprobe_actions+0xa0e>
    40c4:      	movl	$0x0, 0x44(%rsp)
    40cc:      	jmp	0x40e8 <generic_retkprobe_actions+0xa28>
    40ce:      	movl	$0x2, %eax
    40d3:      	xorl	%ecx, %ecx
    40d5:      	movq	(%rip), %rdi            # 0x40dc <generic_retkprobe_actions+0xa1c>
    40dc:      	leaq	0x18(%rsp), %rdx
    40e1:      	movq	%rbx, %rsi
    40e4:      	xorl	%ecx, %ecx
    40e6:      	callq	*%rax
    40e8:      	leal	0x3(%r15), %eax
    40ec:      	cmpl	$0x0, 0x4(%r14,%rax,4)
    40f2:      	movq	0x8(%rsp), %rdx
    40f7:      	je	0x4123 <generic_retkprobe_actions+0xa63>
    40f9:      	orb	$0x2, 0x1(%rdx)
    40fd:      	movl	$0x1b, %eax
    4102:      	movq	0x80(%rsp), %rdi
    410a:      	xorl	%ecx, %ecx
    410c:      	movq	(%rip), %rsi            # 0x4113 <generic_retkprobe_actions+0xa53>
    4113:      	xorl	%edx, %edx
    4115:      	callq	*%rax
    4117:      	movq	0x8(%rsp), %rdx
    411c:      	movq	%rax, 0x80(%rdx)
    4123:      	leal	0x4(%r15), %eax
    4127:      	cmpl	$0x0, 0x4(%r14,%rax,4)
    412d:      	je	0x415f <generic_retkprobe_actions+0xa9f>
    412f:      	orb	$0x4, 0x1(%rdx)
    4133:      	movl	$0x1b, %eax
    4138:      	movq	0x80(%rsp), %rdi
    4140:      	movq	(%rip), %rsi            # 0x4147 <generic_retkprobe_actions+0xa87>
    4147:      	movl	$0x100, %ecx            # imm = 0x100
    414c:      	movl	$0x100, %edx            # imm = 0x100
    4151:      	callq	*%rax
    4153:      	movq	0x8(%rsp), %rdx
    4158:      	movq	%rax, 0x88(%rdx)
    415f:      	addl	$0x5, %r15d
    4163:      	cmpl	$0x0, 0x4(%r14,%r15,4)
    4169:      	je	0x37f0 <generic_retkprobe_actions+0x130>
    416f:      	orb	$0x8, 0x1(%rdx)
    4173:      	jmp	0x37f0 <generic_retkprobe_actions+0x130>
    4178:      	movl	$0x1, 0x94(%rsp)
    4183:      	movl	$0x2, %eax
    4188:      	xorl	%ecx, %ecx
    418a:      	leaq	0x94(%rsp), %rdx
    4192:      	leaq	0x18(%rsp), %rsi
    4197:      	movq	%rbx, %rdi
    419a:      	xorl	%ecx, %ecx
    419c:      	callq	*%rax
    419e:      	cmpl	$0x0, 0x38(%rsp)
    41a3:      	je	0x3c1a <generic_retkprobe_actions+0x55a>
    41a9:      	movl	$0x1, %eax
    41ae:      	leaq	0x28(%rsp), %rsi
    41b3:      	movq	(%rip), %rdi            # 0x41ba <generic_retkprobe_actions+0xafa>
    41ba:      	callq	*%rax
    41bc:      	testq	%rax, %rax
    41bf:      	je	0x3c1a <generic_retkprobe_actions+0x55a>
    41c5:      	movl	0x5c(%rsp), %ecx
    41c9:      	lock
    41ca:      	addl	%ecx, (%rax)
    41cc:      	jmp	0x3c1a <generic_retkprobe_actions+0x55a>
    41d1:      	cmpb	$0x0, 0x44(%rsp)
    41d6:      	je	0x41f8 <generic_retkprobe_actions+0xb38>
    41d8:      	movq	(%rip), %rsi            # 0x41df <generic_retkprobe_actions+0xb1f>
    41df:      	movl	$0x5, %ecx
    41e4:      	movl	$0xc, %eax
    41e9:      	movq	0x80(%rsp), %rdi
    41f1:      	movl	$0x5, %edx
    41f6:      	callq	*%rax
    41f8:      	xorl	%eax, %eax
    41fa:      	addq	$0xa8, %rsp
    4201:      	popq	%rbx
    4202:      	popq	%r12
    4204:      	popq	%r13
    4206:      	popq	%r14
    4208:      	popq	%r15
    420a:      	popq	%rbp
    420b:      	retq
    420c:      	nopl	(%rax)

0000000000004210 <generic_retkprobe_output>:
    4210:      	pushq	%r15
    4212:      	pushq	%r14
    4214:      	pushq	%rbx
    4215:      	subq	$0x10, %rsp
    4219:      	movq	%rdi, %r14
    421c:      	movl	$0x0, 0x8(%rsp)
    4224:      	movq	(%rip), %rdi            # 0x422b <generic_retkprobe_output+0x1b>
    422b:      	leaq	0x8(%rsp), %rsi
    4230:      	movl	$0x1, %eax
    4235:      	callq	*%rax
    4237:      	testq	%rax, %rax
    423a:      	je	0x4313 <generic_retkprobe_output+0x103>
    4240:      	movq	%rax, %rbx
    4243:      	movl	$0x90, %eax
    4248:      	addl	0x4(%rbx), %eax
    424b:      	andl	$0x7fff, %eax           # imm = 0x7FFF
    4250:      	cmpl	$0x2328, %eax           # imm = 0x2328
    4255:      	movl	$0x2328, %r15d          # imm = 0x2328
    425b:      	cmovbl	%eax, %r15d
    425f:      	movl	$0x0, 0xc(%rsp)
    4267:      	movq	(%rip), %rdi            # 0x426e <generic_retkprobe_output+0x5e>
    426e:      	leaq	0xc(%rsp), %rsi
    4273:      	movl	$0x1, %eax
    4278:      	callq	*%rax
    427a:      	testq	%rax, %rax
    427d:      	je	0x42d1 <generic_retkprobe_output+0xc1>
    427f:      	cmpb	$0x0, 0x28(%rax)
    4283:      	je	0x42d1 <generic_retkprobe_output+0xc1>
    4285:      	movq	(%rip), %rsi            # 0x428c <generic_retkprobe_output+0x7c>
    428c:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    4291:      	movl	$0x19, %eax
    4296:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    429b:      	movq	%r14, %rdi
    429e:      	movq	%rbx, %rcx
    42a1:      	movq	%r15, %r8
    42a4:      	callq	*%rax
    42a6:      	testq	%rax, %rax
    42a9:      	js	0x436e <generic_retkprobe_output+0x15e>
    42af:      	movl	$0x0, 0x4(%rsp)
    42b7:      	movq	(%rip), %rdi            # 0x42be <generic_retkprobe_output+0xae>
    42be:      	leaq	0x4(%rsp), %rsi
    42c3:      	movl	$0x1, %eax
    42c8:      	callq	*%rax
    42ca:      	testq	%rax, %rax
    42cd:      	jne	0x430e <generic_retkprobe_output+0xfe>
    42cf:      	jmp	0x4313 <generic_retkprobe_output+0x103>
    42d1:      	movq	(%rip), %rdi            # 0x42d8 <generic_retkprobe_output+0xc8>
    42d8:      	xorl	%ecx, %ecx
    42da:      	movl	$0x82, %eax
    42df:      	movq	%rbx, %rsi
    42e2:      	movq	%r15, %rdx
    42e5:      	xorl	%ecx, %ecx
    42e7:      	callq	*%rax
    42e9:      	testq	%rax, %rax
    42ec:      	js	0x431f <generic_retkprobe_output+0x10f>
    42ee:      	movl	$0x0, 0x4(%rsp)
    42f6:      	movq	(%rip), %rdi            # 0x42fd <generic_retkprobe_output+0xed>
    42fd:      	leaq	0x4(%rsp), %rsi
    4302:      	movl	$0x1, %eax
    4307:      	callq	*%rax
    4309:      	testq	%rax, %rax
    430c:      	je	0x4313 <generic_retkprobe_output+0x103>
    430e:      	lock
    430f:      	incq	0x8(%rax)
    4313:      	xorl	%eax, %eax
    4315:      	addq	$0x10, %rsp
    4319:      	popq	%rbx
    431a:      	popq	%r14
    431c:      	popq	%r15
    431e:      	retq
    431f:      	movq	%rax, %rbx
    4322:      	movl	$0x0, 0x4(%rsp)
    432a:      	movq	(%rip), %rdi            # 0x4331 <generic_retkprobe_output+0x121>
    4331:      	leaq	0x4(%rsp), %rsi
    4336:      	movl	$0x1, %eax
    433b:      	callq	*%rax
    433d:      	testq	%rax, %rax
    4340:      	je	0x4313 <generic_retkprobe_output+0x103>
    4342:      	cmpq	$-0xc, %rbx
    4346:      	jg	0x43b2 <generic_retkprobe_output+0x1a2>
    4348:      	cmpq	$-0x1c, %rbx
    434c:      	je	0x43f4 <generic_retkprobe_output+0x1e4>
    4352:      	cmpq	$-0x16, %rbx
    4356:      	je	0x43a3 <generic_retkprobe_output+0x193>
    4358:      	cmpq	$-0x10, %rbx
    435c:      	jne	0x43e5 <generic_retkprobe_output+0x1d5>
    4362:      	addq	$0x2f0, %rax            # imm = 0x2F0
    4368:      	lock
    4369:      	incq	(%rax)
    436c:      	jmp	0x4313 <generic_retkprobe_output+0x103>
    436e:      	movq	%rax, %rbx
    4371:      	movl	$0x0, 0x4(%rsp)
    4379:      	movq	(%rip), %rdi            # 0x4380 <generic_retkprobe_output+0x170>
    4380:      	leaq	0x4(%rsp), %rsi
    4385:      	movl	$0x1, %eax
    438a:      	callq	*%rax
    438c:      	testq	%rax, %rax
    438f:      	je	0x4313 <generic_retkprobe_output+0x103>
    4391:      	cmpq	$-0xc, %rbx
    4395:      	jg	0x43d3 <generic_retkprobe_output+0x1c3>
    4397:      	cmpq	$-0x1c, %rbx
    439b:      	je	0x43f4 <generic_retkprobe_output+0x1e4>
    439d:      	cmpq	$-0x16, %rbx
    43a1:      	jne	0x4358 <generic_retkprobe_output+0x148>
    43a3:      	addq	$0x2f8, %rax            # imm = 0x2F8
    43a9:      	lock
    43aa:      	incq	(%rax)
    43ad:      	jmp	0x4313 <generic_retkprobe_output+0x103>
    43b2:      	cmpq	$-0xb, %rbx
    43b6:      	je	0x4403 <generic_retkprobe_output+0x1f3>
    43b8:      	cmpq	$-0x7, %rbx
    43bc:      	je	0x4412 <generic_retkprobe_output+0x202>
    43be:      	cmpq	$-0x2, %rbx
    43c2:      	jne	0x43e5 <generic_retkprobe_output+0x1d5>
    43c4:      	addq	$0x2e0, %rax            # imm = 0x2E0
    43ca:      	lock
    43cb:      	incq	(%rax)
    43ce:      	jmp	0x4313 <generic_retkprobe_output+0x103>
    43d3:      	cmpq	$-0xb, %rbx
    43d7:      	je	0x4403 <generic_retkprobe_output+0x1f3>
    43d9:      	cmpq	$-0x7, %rbx
    43dd:      	je	0x4412 <generic_retkprobe_output+0x202>
    43df:      	cmpq	$-0x2, %rbx
    43e3:      	je	0x43c4 <generic_retkprobe_output+0x1b4>
    43e5:      	addq	$0x2d8, %rax            # imm = 0x2D8
    43eb:      	lock
    43ec:      	incq	(%rax)
    43ef:      	jmp	0x4313 <generic_retkprobe_output+0x103>
    43f4:      	addq	$0x300, %rax            # imm = 0x300
    43fa:      	lock
    43fb:      	incq	(%rax)
    43fe:      	jmp	0x4313 <generic_retkprobe_output+0x103>
    4403:      	addq	$0x308, %rax            # imm = 0x308
    4409:      	lock
    440a:      	incq	(%rax)
    440d:      	jmp	0x4313 <generic_retkprobe_output+0x103>
    4412:      	addq	$0x2e8, %rax            # imm = 0x2E8
    4418:      	lock
    4419:      	incq	(%rax)
    441c:      	jmp	0x4313 <generic_retkprobe_output+0x103>

Disassembly of section kprobe.multi/generic_retkprobe:

0000000000000000 <generic_retkprobe_event>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0xf8, %rsp
      11:      	movq	%rdi, %r12
      14:      	movq	0x50(%rdi), %rax
      18:      	movq	%rax, 0xc0(%rsp)
      20:      	movl	$0x0, 0xe0(%rsp)
      2b:      	movq	(%rip), %rdi            # 0x32 <generic_retkprobe_event+0x32>
      32:      	leaq	0xe0(%rsp), %rsi
      3a:      	movl	$0x1, %eax
      3f:      	callq	*%rax
      41:      	xorl	%ebp, %ebp
      43:      	testq	%rax, %rax
      46:      	je	0x1dcf <generic_retkprobe_event+0x1dcf>
      4c:      	movq	%rax, %r15
      4f:      	movq	%rax, %rbx
      52:      	movl	$0xae, %eax
      57:      	movq	%r12, %rdi
      5a:      	callq	*%rax
      5c:      	leaq	0x5ef8(%r15), %rsi
      63:      	movl	%eax, 0x5ef8(%r15)
      6a:      	movq	(%rip), %rdi            # 0x71 <generic_retkprobe_event+0x71>
      71:      	movl	$0x1, %eax
      76:      	callq	*%rax
      78:      	testq	%rax, %rax
      7b:      	je	0x1dcf <generic_retkprobe_event+0x1dcf>
      81:      	movq	%rax, %r13
      84:      	movl	(%rax), %eax
      86:      	movq	%rax, 0x60(%rbx)
      8a:      	movl	$0xe, %eax
      8f:      	callq	*%rax
      91:      	cmpq	$-0x16, %rax
      95:      	jne	0xb7 <generic_retkprobe_event+0xb7>
      97:      	leaq	0x20(%r12), %rdx
      9c:      	leaq	0x30(%rsp), %rdi
      a1:      	movl	$0x8, %ecx
      a6:      	movl	$0x4, %eax
      ab:      	movl	$0x8, %esi
      b0:      	callq	*%rax
      b2:      	movq	0x30(%rsp), %rax
      b7:      	movq	%rax, 0x68(%rbx)
      bb:      	movl	$0xe, %eax
      c0:      	callq	*%rax
      c2:      	movl	%eax, 0x7c(%rbx)
      c5:      	movq	0x60(%rbx), %rax
      c9:      	movq	0x68(%rbx), %rcx
      cd:      	movq	%rax, 0x30(%rsp)
      d2:      	movq	%rcx, 0x38(%rsp)
      d7:      	movq	(%rip), %rdi            # 0xde <generic_retkprobe_event+0xde>
      de:      	leaq	0x30(%rsp), %rsi
      e3:      	movl	$0x1, %eax
      e8:      	callq	*%rax
      ea:      	testq	%rax, %rax
      ed:      	je	0x1dcf <generic_retkprobe_event+0x1dcf>
      f3:      	movq	(%rax), %r14
      f6:      	movq	0x8(%rax), %rcx
      fa:      	movq	%rcx, 0x90(%rsp)
     102:      	movq	0x10(%rax), %rax
     106:      	movq	%rax, 0x88(%rsp)
     10e:      	movq	(%rip), %rdi            # 0x115 <generic_retkprobe_event+0x115>
     115:      	leaq	0x30(%rsp), %rsi
     11a:      	movl	$0x3, %eax
     11f:      	callq	*%rax
     121:      	movq	%r14, 0x90(%rbx)
     128:      	movl	0x58(%r13), %eax
     12c:      	movl	0x5c(%r13), %r14d
     130:      	testl	%r14d, %r14d
     133:      	movq	%r13, 0x20(%rsp)
     138:      	je	0x1f7 <generic_retkprobe_event+0x1f7>
     13e:      	movl	%eax, 0x28(%rsp)
     142:      	movl	$0x0, 0x5ea0(%rbx)
     14c:      	movq	0xc0(%rsp), %rbp
     154:      	movl	$0x0, 0xe4(%rsp)
     15f:      	movq	(%rip), %rdi            # 0x166 <generic_retkprobe_event+0x166>
     166:      	leaq	0xe4(%rsp), %rsi
     16e:      	movl	$0x1, %eax
     173:      	callq	*%rax
     175:      	testq	%rax, %rax
     178:      	je	0x2ea <generic_retkprobe_event+0x2ea>
     17e:      	movl	0x5ea0(%rax), %ecx
     184:      	movl	%ecx, 0x98(%rax)
     18a:      	movq	$0xc, 0x5e78(%rax)
     195:      	testl	%ecx, %ecx
     197:      	je	0x3be <generic_retkprobe_event+0x3be>
     19d:      	movl	$0x4, %ebp
     1a2:      	addq	$0x8, %rbp
     1a6:      	movl	0x60(%r13), %eax
     1aa:      	cmpl	$0xb, %eax
     1ad:      	je	0x2fd <generic_retkprobe_event+0x2fd>
     1b3:      	cmpl	$0xa, %eax
     1b6:      	jne	0x313 <generic_retkprobe_event+0x313>
     1bc:      	movl	0x10(%rbx), %eax
     1bf:      	movl	%eax, 0x30(%rsp)
     1c3:      	movl	0x7c(%rbx), %eax
     1c6:      	movl	%eax, 0x34(%rsp)
     1ca:      	movq	0x18(%rbx), %rax
     1ce:      	movq	%rax, 0x38(%rsp)
     1d3:      	movq	(%rip), %rdi            # 0x1da <generic_retkprobe_event+0x1da>
     1da:      	xorl	%ecx, %ecx
     1dc:      	leaq	0xc0(%rsp), %rsi
     1e4:      	leaq	0x30(%rsp), %rdx
     1e9:      	movl	$0x2, %eax
     1ee:      	xorl	%ecx, %ecx
     1f0:      	callq	*%rax
     1f2:      	jmp	0x313 <generic_retkprobe_event+0x313>
     1f7:      	movl	$0x8, %ebp
     1fc:      	addq	$0x90, %r15
     203:      	cmpl	$0x3, %eax
     206:      	jne	0x32d <generic_retkprobe_event+0x32d>
     20c:      	movl	$0x0, (%r15,%rbp)
     214:      	leaq	0x4(%rbp), %r14
     218:      	cmpq	$0x0, 0x88(%rsp)
     221:      	movq	%r12, 0xb8(%rsp)
     229:      	je	0x425 <generic_retkprobe_event+0x425>
     22f:      	movq	%r14, 0x28(%rsp)
     234:      	movq	0xc0(%rsp), %r14
     23c:      	leaq	0x30(%rsp), %rdi
     241:      	movl	$0x4, %r12d
     247:      	movl	$0x10, %ecx
     24c:      	movl	$0x4, %eax
     251:      	movq	0x90(%rsp), %rdx
     259:      	movl	$0x10, %esi
     25e:      	callq	*%rax
     260:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     265:      	testl	%eax, %eax
     267:      	js	0x1b1a <generic_retkprobe_event+0x1b1a>
     26d:      	movq	0x38(%rsp), %rsi
     272:      	cmpq	%r14, %rsi
     275:      	movq	%r14, %rax
     278:      	movq	%r14, %r13
     27b:      	cmovbq	%rsi, %r13
     27f:      	testq	%r14, %r14
     282:      	cmovneq	%r13, %rsi
     286:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
     28b:      	cmpq	$0xffe, %rsi            # imm = 0xFFE
     292:      	ja	0x1b1a <generic_retkprobe_event+0x1b1a>
     298:      	addq	$0xc, %rbp
     29c:      	movq	%rbp, 0x18(%rsp)
     2a1:      	leaq	(%r15,%rbp), %rdi
     2a5:      	movq	0x30(%rsp), %rcx
     2aa:      	movl	$0x4, %eax
     2af:      	movq	0x30(%rsp), %rdx
     2b4:      	movq	%rsi, %rbp
     2b7:      	callq	*%rax
     2b9:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     2be:      	testl	%eax, %eax
     2c0:      	js	0x1b1a <generic_retkprobe_event+0x1b1a>
     2c6:      	movq	%rbp, %rdx
     2c9:      	testq	%r14, %r14
     2cc:      	je	0xcf0 <generic_retkprobe_event+0xcf0>
     2d2:      	subq	%r13, %r14
     2d5:      	movq	%r14, 0x8(%rsp)
     2da:      	movq	0x28(%rsp), %r14
     2df:      	jne	0xcfc <generic_retkprobe_event+0xcfc>
     2e5:      	jmp	0x428 <generic_retkprobe_event+0x428>
     2ea:      	xorl	%ebp, %ebp
     2ec:      	addq	$0x8, %rbp
     2f0:      	movl	0x60(%r13), %eax
     2f4:      	cmpl	$0xb, %eax
     2f7:      	jne	0x1b3 <generic_retkprobe_event+0x1b3>
     2fd:      	movq	(%rip), %rdi            # 0x304 <generic_retkprobe_event+0x304>
     304:      	leaq	0xc0(%rsp), %rsi
     30c:      	movl	$0x3, %eax
     311:      	callq	*%rax
     313:      	andl	$0x1fff, %ebp           # imm = 0x1FFF
     319:      	movl	0x28(%rsp), %eax
     31d:      	addq	$0x90, %r15
     324:      	cmpl	$0x3, %eax
     327:      	je	0x20c <generic_retkprobe_event+0x20c>
     32d:      	cmpl	$0x2, %eax
     330:      	jne	0x1b36 <generic_retkprobe_event+0x1b36>
     336:      	movq	%rbx, 0x88(%rsp)
     33e:      	movq	%r12, %rbx
     341:      	movl	$0x0, (%r15,%rbp)
     349:      	movq	0xc0(%rsp), %r14
     351:      	cmpq	$0xfff, %r14            # imm = 0xFFF
     358:      	movl	$0xfff, %r12d           # imm = 0xFFF
     35e:      	cmovbq	%r14, %r12
     362:      	leaq	(%r15,%rbp), %rdi
     366:      	addq	$0xc, %rdi
     36a:      	movl	$0x4, %eax
     36f:      	movq	0x90(%rsp), %rdx
     377:      	leaq	0x4(%rbp), %r13
     37b:      	addq	%rbp, %r15
     37e:      	addq	$0x4, %r15
     382:      	movl	$0x4, %ebp
     387:      	movl	%r12d, %esi
     38a:      	callq	*%rax
     38c:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     391:      	testl	%eax, %eax
     393:      	js	0x3a3 <generic_retkprobe_event+0x3a3>
     395:      	movl	%r12d, 0x4(%r15)
     399:      	addq	$0x8, %r12
     39d:      	movl	%r14d, %ecx
     3a0:      	movq	%r12, %rbp
     3a3:      	addq	%r13, %rbp
     3a6:      	movl	%ecx, (%r15)
     3a9:      	movq	%rbx, %r12
     3ac:      	movq	0x20(%rsp), %r13
     3b1:      	movq	0x88(%rsp), %rbx
     3b9:      	jmp	0x1b36 <generic_retkprobe_event+0x1b36>
     3be:      	leaq	0x9c(%rax), %r13
     3c5:      	movq	%rbp, 0x30(%rsp)
     3ca:      	movq	$0x0, 0x70(%rsp)
     3d3:      	cmpl	$0x17, %r14d
     3d7:      	movq	%rax, (%rsp)
     3db:      	movq	%r15, 0x18(%rsp)
     3e0:      	movq	%r12, 0xb8(%rsp)
     3e8:      	jle	0x43d <generic_retkprobe_event+0x43d>
     3ea:      	cmpl	$0x18, %r14d
     3ee:      	je	0x458 <generic_retkprobe_event+0x458>
     3f0:      	cmpl	$0x25, %r14d
     3f4:      	je	0x496 <generic_retkprobe_event+0x496>
     3fa:      	cmpl	$0x2a, %r14d
     3fe:      	jne	0xb39 <generic_retkprobe_event+0xb39>
     404:      	movq	$0x0, 0xa0(%rsp)
     410:      	movq	%rbp, 0xa8(%rsp)
     418:      	leaq	0xa0(%rsp), %rax
     420:      	jmp	0x4c3 <generic_retkprobe_event+0x4c3>
     425:      	xorl	%r13d, %r13d
     428:      	movl	%r13d, (%r15,%r14)
     42c:      	movl	%r13d, 0x4(%r15,%r14)
     431:      	addq	$0x8, %r13
     435:      	movq	%r13, %r12
     438:      	jmp	0x1b23 <generic_retkprobe_event+0x1b23>
     43d:      	cmpl	$0xf, %r14d
     441:      	je	0xa76 <generic_retkprobe_event+0xa76>
     447:      	cmpl	$0x10, %r14d
     44b:      	jne	0xb39 <generic_retkprobe_event+0xb39>
     451:      	leaq	0x10(%rsp), %r12
     456:      	jmp	0x480 <generic_retkprobe_event+0x480>
     458:      	leaq	0x10(%rsp), %r12
     45d:      	movl	$0x8, %ecx
     462:      	movl	$0x4, %eax
     467:      	movq	0x30(%rsp), %rdx
     46c:      	movq	%r12, %rdi
     46f:      	movl	$0x8, %esi
     474:      	callq	*%rax
     476:      	movq	0x10(%rsp), %rax
     47b:      	movq	%rax, 0x30(%rsp)
     480:      	leaq	0x30(%rsp), %rdx
     485:      	movl	$0x8, %ecx
     48a:      	movl	$0x4, %eax
     48f:      	leaq	0x10(%rsp), %rdi
     494:      	jmp	0x4b3 <generic_retkprobe_event+0x4b3>
     496:      	addq	$0x40, %rbp
     49a:      	movq	%rbp, 0x30(%rsp)
     49f:      	leaq	0x10(%rsp), %rdi
     4a4:      	movl	$0x8, %ecx
     4a9:      	movl	$0x4, %eax
     4ae:      	movq	0x30(%rsp), %rdx
     4b3:      	movl	$0x8, %esi
     4b8:      	callq	*%rax
     4ba:      	movq	0x10(%rsp), %rax
     4bf:      	addq	$0x40, %rax
     4c3:      	movq	%rax, 0x80(%rsp)
     4cb:      	movl	$0x0, 0xb4(%rsp)
     4d6:      	movq	(%rip), %rdi            # 0x4dd <generic_retkprobe_event+0x4dd>
     4dd:      	leaq	0xb4(%rsp), %rsi
     4e5:      	movl	$0x1, %eax
     4ea:      	callq	*%rax
     4ec:      	testq	%rax, %rax
     4ef:      	je	0x5a2 <generic_retkprobe_event+0x5a2>
     4f5:      	movq	%rax, %r12
     4f8:      	addq	$0x1000, %rax           # imm = 0x1000
     4fe:      	movq	%rax, 0x8(%rsp)
     503:      	movl	$0x23, %eax
     508:      	callq	*%rax
     50a:      	leaq	0xd50(%rax), %rdx
     511:      	leaq	0xc8(%rsp), %rdi
     519:      	movl	$0x8, %ecx
     51e:      	movl	$0x4, %eax
     523:      	movl	$0x8, %esi
     528:      	callq	*%rax
     52a:      	movq	0xc8(%rsp), %rbp
     532:      	movq	0x80(%rsp), %rax
     53a:      	leaq	0x8(%rax), %rdx
     53e:      	leaq	0xd0(%rsp), %rdi
     546:      	movl	$0x8, %ecx
     54b:      	movl	$0x4, %eax
     550:      	leaq	0x18(%rbp), %rcx
     554:      	movq	%rcx, 0xf0(%rsp)
     55c:      	movl	$0x8, %esi
     561:      	movq	%rdx, 0xe8(%rsp)
     569:      	callq	*%rax
     56b:      	movq	0xd0(%rsp), %r13
     573:      	leaq	0x10(%r13), %rdx
     577:      	leaq	0x30(%rsp), %rdi
     57c:      	movl	$0x8, %ecx
     581:      	movl	$0x4, %eax
     586:      	movl	$0x8, %esi
     58b:      	callq	*%rax
     58d:      	cmpq	$0x0, 0x30(%rsp)
     593:      	movl	$0x1000, %r14d          # imm = 0x1000
     599:      	je	0x5af <generic_retkprobe_event+0x5af>
     59b:      	movq	0x8(%rsp), %rcx
     5a0:      	jmp	0x602 <generic_retkprobe_event+0x602>
     5a2:      	xorl	%r12d, %r12d
     5a5:      	movq	0x20(%rsp), %r13
     5aa:      	jmp	0x1495 <generic_retkprobe_event+0x1495>
     5af:      	leaq	0x18(%r13), %rdx
     5b3:      	leaq	0x30(%rsp), %rdi
     5b8:      	movl	$0x8, %ecx
     5bd:      	movl	$0x4, %eax
     5c2:      	movl	$0x8, %esi
     5c7:      	callq	*%rax
     5c9:      	cmpq	%r13, 0x30(%rsp)
     5ce:      	movq	0x8(%rsp), %rcx
     5d3:      	je	0x602 <generic_retkprobe_event+0x602>
     5d5:      	movq	%r12, %rcx
     5d8:      	addq	$0xff6, %rcx            # imm = 0xFF6
     5df:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
     5e9:      	movq	%rax, 0xff6(%r12)
     5f1:      	movw	$0x2964, 0xffe(%r12)    # imm = 0x2964
     5fc:      	movl	$0xff6, %r14d           # imm = 0xFF6
     602:      	movq	$0x0, 0x38(%rsp)
     60b:      	movq	$0x0, 0x30(%rsp)
     614:      	movq	%r12, 0x40(%rsp)
     619:      	movq	$0x0, 0x48(%rsp)
     622:      	movq	$0x0, 0x50(%rsp)
     62b:      	movq	$0x0, 0x58(%rsp)
     634:      	movq	%rcx, 0x8(%rsp)
     639:      	movq	%rcx, 0x60(%rsp)
     63e:      	movl	%r14d, 0x68(%rsp)
     643:      	movb	$0x0, 0x6c(%rsp)
     648:      	addq	$0x20, %rbp
     64c:      	leaq	0x30(%rsp), %rdi
     651:      	movl	$0x8, %ecx
     656:      	movl	$0x4, %eax
     65b:      	leaq	0x38(%rsp), %r14
     660:      	leaq	0x48(%rsp), %r13
     665:      	leaq	0x50(%rsp), %r12
     66a:      	movl	$0x8, %esi
     66f:      	movq	%rbp, %rdx
     672:      	callq	*%rax
     674:      	movl	$0x8, %ecx
     679:      	movl	$0x4, %eax
     67e:      	movq	0xf0(%rsp), %rdx
     686:      	movq	%r14, %rdi
     689:      	movl	$0x8, %esi
     68e:      	callq	*%rax
     690:      	movl	$0x8, %ecx
     695:      	movl	$0x4, %eax
     69a:      	movq	0xe8(%rsp), %rdx
     6a2:      	movq	%r13, %rdi
     6a5:      	movl	$0x8, %esi
     6aa:      	callq	*%rax
     6ac:      	movl	$0x8, %ecx
     6b1:      	movl	$0x4, %eax
     6b6:      	movq	0x80(%rsp), %rdx
     6be:      	movq	%r12, %rdi
     6c1:      	movl	$0x8, %esi
     6c6:      	callq	*%rax
     6c8:      	movq	0x50(%rsp), %rax
     6cd:      	addq	$-0x20, %rax
     6d1:      	movq	%rax, 0x58(%rsp)
     6d6:      	movq	(%rip), %rax            # 0x6dd <generic_retkprobe_event+0x6dd>
     6dd:      	cmpb	$0x0, (%rax)
     6e0:      	je	0x8b4 <generic_retkprobe_event+0x8b4>
     6e6:      	movl	$0x80, %ebp
     6eb:      	movl	$0x8, %r14d
     6f1:      	movq	0x48(%rsp), %r13
     6f6:      	movq	0x50(%rsp), %rdx
     6fb:      	movq	0x58(%rsp), %r12
     700:      	cmpq	0x30(%rsp), %r13
     705:      	jne	0x712 <generic_retkprobe_event+0x712>
     707:      	cmpq	0x38(%rsp), %rdx
     70c:      	je	0xbe1 <generic_retkprobe_event+0xbe1>
     712:      	movl	$0x4, %eax
     717:      	leaq	0x98(%rsp), %rdi
     71f:      	movl	$0x8, %esi
     724:      	callq	*%rax
     726:      	cmpq	0x98(%rsp), %r13
     72e:      	movl	$0x8, %r15d
     734:      	je	0x846 <generic_retkprobe_event+0x846>
     73a:      	leaq	0x18(%r13), %r14
     73e:      	movl	$0x4, %eax
     743:      	leaq	0x10(%rsp), %rdi
     748:      	movl	$0x8, %esi
     74d:      	movq	%r14, %rdx
     750:      	callq	*%rax
     752:      	cmpq	%r13, 0x10(%rsp)
     757:      	je	0x846 <generic_retkprobe_event+0x846>
     75d:      	movl	$0x4, %eax
     762:      	leaq	0xd8(%rsp), %rdi
     76a:      	movl	$0x8, %esi
     76f:      	movq	%r14, %rdx
     772:      	callq	*%rax
     774:      	addq	$0x20, %r13
     778:      	movl	$0x4, %eax
     77d:      	leaq	0x70(%rsp), %rdi
     782:      	movl	$0x10, %ecx
     787:      	movl	$0x10, %esi
     78c:      	movq	%r13, %rdx
     78f:      	callq	*%rax
     791:      	movq	0x40(%rsp), %r14
     796:      	movq	0x60(%rsp), %rax
     79b:      	movl	0x74(%rsp), %r12d
     7a0:      	subq	%r14, %rax
     7a3:      	movl	0x68(%rsp), %r13d
     7a8:      	movl	%r12d, %edx
     7ab:      	subl	%r13d, %edx
     7ae:      	movl	$0x0, %ecx
     7b3:      	cmovbl	%ecx, %edx
     7b6:      	addq	0x78(%rsp), %rdx
     7bb:      	xorl	%esi, %esi
     7bd:      	cmpl	%r12d, %r13d
     7c0:      	seta	%sil
     7c4:      	movl	%r12d, %ecx
     7c7:      	cmovbl	%r13d, %ecx
     7cb:      	addl	%ecx, %esi
     7cd:      	movl	%r13d, %edi
     7d0:      	subl	%esi, %edi
     7d2:      	movl	%edi, 0x68(%rsp)
     7d6:      	subq	%rsi, %rax
     7d9:      	movq	0x18(%rsp), %r15
     7de:      	jb	0xbe6 <generic_retkprobe_event+0xbe6>
     7e4:      	cmpq	$0xfff, %rax            # imm = 0xFFF
     7ea:      	ja	0xbe6 <generic_retkprobe_event+0xbe6>
     7f0:      	cmpl	%r12d, %r13d
     7f3:      	jbe	0x7fa <generic_retkprobe_event+0x7fa>
     7f5:      	movb	$0x2f, (%r14,%rax)
     7fa:      	xorl	%edi, %edi
     7fc:      	cmpl	%r12d, %r13d
     7ff:      	seta	%dil
     803:      	movzbl	%cl, %esi
     806:      	addq	%rax, %r14
     809:      	addq	%r14, %rdi
     80c:      	movl	$0x4, %eax
     811:      	callq	*%rax
     813:      	movq	%r14, 0x60(%rsp)
     818:      	cmpl	%r12d, %r13d
     81b:      	jbe	0xbe6 <generic_retkprobe_event+0xbe6>
     821:      	movq	0xd8(%rsp), %rax
     829:      	movq	%rax, 0x48(%rsp)
     82e:      	movq	0x20(%rsp), %r13
     833:      	movl	$0x8, %r14d
     839:      	decl	%ebp
     83b:      	jne	0x6f1 <generic_retkprobe_event+0x6f1>
     841:      	jmp	0xbeb <generic_retkprobe_event+0xbeb>
     846:      	leaq	0x10(%r12), %rdx
     84b:      	movl	$0x4, %eax
     850:      	leaq	0x10(%rsp), %rdi
     855:      	movl	$0x8, %esi
     85a:      	callq	*%rax
     85c:      	movq	0x58(%rsp), %rax
     861:      	cmpq	0x10(%rsp), %rax
     866:      	movl	$0x8, %r14d
     86c:      	je	0xdcb <generic_retkprobe_event+0xdcb>
     872:      	addq	$0x18, %r12
     876:      	movl	$0x4, %eax
     87b:      	leaq	0x48(%rsp), %rdi
     880:      	movl	$0x8, %esi
     885:      	movq	%r12, %rdx
     888:      	callq	*%rax
     88a:      	movq	0x10(%rsp), %rax
     88f:      	movq	%rax, 0x58(%rsp)
     894:      	addq	$0x20, %rax
     898:      	movq	%rax, 0x50(%rsp)
     89d:      	movq	0x20(%rsp), %r13
     8a2:      	movq	0x18(%rsp), %r15
     8a7:      	decl	%ebp
     8a9:      	jne	0x6f1 <generic_retkprobe_event+0x6f1>
     8af:      	jmp	0xbeb <generic_retkprobe_event+0xbeb>
     8b4:      	movl	$0x80, %ebp
     8b9:      	movl	$0x8, %r14d
     8bf:      	jmp	0x8c9 <generic_retkprobe_event+0x8c9>
     8c1:      	decl	%ebp
     8c3:      	je	0xbeb <generic_retkprobe_event+0xbeb>
     8c9:      	movq	0x48(%rsp), %r13
     8ce:      	movq	0x50(%rsp), %rdx
     8d3:      	movq	0x58(%rsp), %r12
     8d8:      	cmpq	0x30(%rsp), %r13
     8dd:      	jne	0x8ea <generic_retkprobe_event+0x8ea>
     8df:      	cmpq	0x38(%rsp), %rdx
     8e4:      	je	0xbe1 <generic_retkprobe_event+0xbe1>
     8ea:      	movl	$0x4, %eax
     8ef:      	leaq	0x98(%rsp), %rdi
     8f7:      	movl	$0x8, %esi
     8fc:      	callq	*%rax
     8fe:      	cmpq	0x98(%rsp), %r13
     906:      	movl	$0x8, %ecx
     90b:      	je	0xa15 <generic_retkprobe_event+0xa15>
     911:      	leaq	0x18(%r13), %r14
     915:      	movl	$0x4, %eax
     91a:      	leaq	0x10(%rsp), %rdi
     91f:      	movl	$0x8, %esi
     924:      	movq	%r14, %rdx
     927:      	callq	*%rax
     929:      	movl	$0x8, %ecx
     92e:      	cmpq	%r13, 0x10(%rsp)
     933:      	je	0xa15 <generic_retkprobe_event+0xa15>
     939:      	movl	$0x4, %eax
     93e:      	leaq	0xd8(%rsp), %rdi
     946:      	movl	$0x8, %esi
     94b:      	movq	%r14, %rdx
     94e:      	callq	*%rax
     950:      	addq	$0x20, %r13
     954:      	movl	$0x4, %eax
     959:      	leaq	0x70(%rsp), %rdi
     95e:      	movl	$0x10, %ecx
     963:      	movl	$0x10, %esi
     968:      	movq	%r13, %rdx
     96b:      	callq	*%rax
     96d:      	movq	0x40(%rsp), %r14
     972:      	movq	0x60(%rsp), %rax
     977:      	movl	0x74(%rsp), %r12d
     97c:      	subq	%r14, %rax
     97f:      	movl	0x68(%rsp), %r13d
     984:      	movl	%r12d, %edx
     987:      	subl	%r13d, %edx
     98a:      	movl	$0x0, %ecx
     98f:      	cmovbl	%ecx, %edx
     992:      	addq	0x78(%rsp), %rdx
     997:      	xorl	%esi, %esi
     999:      	cmpl	%r12d, %r13d
     99c:      	seta	%sil
     9a0:      	movl	%r12d, %ecx
     9a3:      	cmovbl	%r13d, %ecx
     9a7:      	addl	%ecx, %esi
     9a9:      	movl	%r13d, %edi
     9ac:      	subl	%esi, %edi
     9ae:      	movl	%edi, 0x68(%rsp)
     9b2:      	subq	%rsi, %rax
     9b5:      	jb	0xbe6 <generic_retkprobe_event+0xbe6>
     9bb:      	cmpq	$0xfff, %rax            # imm = 0xFFF
     9c1:      	ja	0xbe6 <generic_retkprobe_event+0xbe6>
     9c7:      	cmpl	%r12d, %r13d
     9ca:      	jbe	0x9d1 <generic_retkprobe_event+0x9d1>
     9cc:      	movb	$0x2f, (%r14,%rax)
     9d1:      	xorl	%edi, %edi
     9d3:      	cmpl	%r12d, %r13d
     9d6:      	seta	%dil
     9da:      	movzbl	%cl, %esi
     9dd:      	addq	%rax, %r14
     9e0:      	addq	%r14, %rdi
     9e3:      	movl	$0x4, %eax
     9e8:      	callq	*%rax
     9ea:      	movq	%r14, 0x60(%rsp)
     9ef:      	cmpl	%r12d, %r13d
     9f2:      	jbe	0xbe6 <generic_retkprobe_event+0xbe6>
     9f8:      	movq	0xd8(%rsp), %rax
     a00:      	movq	%rax, 0x48(%rsp)
     a05:      	movq	0x20(%rsp), %r13
     a0a:      	movl	$0x8, %r14d
     a10:      	jmp	0x8c1 <generic_retkprobe_event+0x8c1>
     a15:      	leaq	0x10(%r12), %rdx
     a1a:      	movl	$0x4, %eax
     a1f:      	leaq	0x10(%rsp), %rdi
     a24:      	movl	$0x8, %esi
     a29:      	callq	*%rax
     a2b:      	movq	0x58(%rsp), %rax
     a30:      	cmpq	0x10(%rsp), %rax
     a35:      	movl	$0x8, %r14d
     a3b:      	je	0xbe1 <generic_retkprobe_event+0xbe1>
     a41:      	addq	$0x18, %r12
     a45:      	movl	$0x4, %eax
     a4a:      	leaq	0x48(%rsp), %rdi
     a4f:      	movl	$0x8, %esi
     a54:      	movq	%r12, %rdx
     a57:      	callq	*%rax
     a59:      	movq	0x10(%rsp), %rax
     a5e:      	movq	%rax, 0x58(%rsp)
     a63:      	addq	$0x20, %rax
     a67:      	movq	%rax, 0x50(%rsp)
     a6c:      	movq	0x20(%rsp), %r13
     a71:      	jmp	0x8c1 <generic_retkprobe_event+0x8c1>
     a76:      	leaq	0x70(%rsp), %rdi
     a7b:      	leaq	0x30(%rsp), %rdx
     a80:      	movl	$0x8, %ecx
     a85:      	movl	$0x4, %eax
     a8a:      	movl	$0x8, %esi
     a8f:      	callq	*%rax
     a91:      	movq	0x70(%rsp), %rax
     a96:      	movq	%rax, 0x80(%rsp)
     a9e:      	testq	%rax, %rax
     aa1:      	jne	0x4cb <generic_retkprobe_event+0x4cb>
     aa7:      	movl	$0x0, 0xa0(%rsp)
     ab2:      	movq	(%rip), %rdi            # 0xab9 <generic_retkprobe_event+0xab9>
     ab9:      	leaq	0xa0(%rsp), %rsi
     ac1:      	movl	$0x1, %eax
     ac6:      	callq	*%rax
     ac8:      	testq	%rax, %rax
     acb:      	je	0xce3 <generic_retkprobe_event+0xce3>
     ad1:      	movq	%r13, 0x8(%rsp)
     ad6:      	xorl	%r12d, %r12d
     ad9:      	cmpl	$0x19, %r14d
     add:      	movq	0x20(%rsp), %r13
     ae2:      	movq	(%rsp), %rcx
     ae6:      	jg	0x101b <generic_retkprobe_event+0x101b>
     aec:      	cmpl	$0x12, %r14d
     af0:      	jle	0x1177 <generic_retkprobe_event+0x1177>
     af6:      	cmpl	$0x14, %r14d
     afa:      	jle	0x14d7 <generic_retkprobe_event+0x14d7>
     b00:      	cmpl	$0x15, %r14d
     b04:      	je	0x2183 <generic_retkprobe_event+0x2183>
     b0a:      	cmpl	$0x16, %r14d
     b0e:      	je	0x20eb <generic_retkprobe_event+0x20eb>
     b14:      	cmpl	$0x17, %r14d
     b18:      	jne	0x148b <generic_retkprobe_event+0x148b>
     b1e:      	movl	$0x0, 0xa0(%rcx)
     b28:      	movl	%ebp, 0x9c(%rcx)
     b2e:      	movl	$0x8, %r12d
     b34:      	jmp	0x148b <generic_retkprobe_event+0x148b>
     b39:      	cmpl	$0x2c, %r14d
     b3d:      	ja	0xaa7 <generic_retkprobe_event+0xaa7>
     b43:      	movl	%r14d, %eax
     b46:      	movabsq	$0x11c1f2027cf2, %rcx   # imm = 0x11C1F2027CF2
     b50:      	btq	%rax, %rcx
     b54:      	jae	0xaa7 <generic_retkprobe_event+0xaa7>
     b5a:      	movq	%rbp, 0x10(%rsp)
     b5f:      	movl	$0x0, 0xd8(%rsp)
     b6a:      	movq	(%rip), %rdi            # 0xb71 <generic_retkprobe_event+0xb71>
     b71:      	leaq	0xd8(%rsp), %rsi
     b79:      	movl	$0x1, %eax
     b7e:      	callq	*%rax
     b80:      	testq	%rax, %rax
     b83:      	je	0xce3 <generic_retkprobe_event+0xce3>
     b89:      	movq	%r13, %rbp
     b8c:      	xorl	%r12d, %r12d
     b8f:      	cmpl	$0x10, %r14d
     b93:      	jle	0xddf <generic_retkprobe_event+0xddf>
     b99:      	cmpl	$0x1e, %r14d
     b9d:      	movq	0x20(%rsp), %r13
     ba2:      	jle	0xf5f <generic_retkprobe_event+0xf5f>
     ba8:      	cmpl	$0x26, %r14d
     bac:      	jg	0x1051 <generic_retkprobe_event+0x1051>
     bb2:      	leal	-0x1f(%r14), %eax
     bb6:      	cmpl	$0x2, %eax
     bb9:      	jae	0x15ab <generic_retkprobe_event+0x15ab>
     bbf:      	leaq	0x10(%rsp), %rdx
     bc4:      	movl	$0x4, %r12d
     bca:      	movl	$0x1, %ecx
     bcf:      	movl	$0x4, %eax
     bd4:      	movq	%rbp, %rdi
     bd7:      	movl	$0x1, %esi
     bdc:      	jmp	0x1485 <generic_retkprobe_event+0x1485>
     be1:      	movb	$0x1, 0x6c(%rsp)
     be6:      	movq	0x20(%rsp), %r13
     beb:      	movq	0x60(%rsp), %rax
     bf0:      	movq	0x8(%rsp), %rdx
     bf5:      	xorl	%ebp, %ebp
     bf7:      	cmpq	%rdx, %rax
     bfa:      	je	0xc2a <generic_retkprobe_event+0xc2a>
     bfc:      	cmpb	$0x0, 0x6c(%rsp)
     c01:      	sete	%cl
     c04:      	movl	0x68(%rsp), %edx
     c08:      	movl	$0x1000, %r12d          # imm = 0x1000
     c0e:      	subl	%edx, %r12d
     c11:      	testl	%edx, %edx
     c13:      	cmovlel	%edx, %r12d
     c17:      	testq	%rax, %rax
     c1a:      	je	0xcdb <generic_retkprobe_event+0xcdb>
     c20:      	movb	%cl, %bpl
     c23:      	addl	%ebp, %ebp
     c25:      	movq	%rax, %rdx
     c28:      	jmp	0xc2d <generic_retkprobe_event+0xc2d>
     c2a:      	xorl	%r12d, %r12d
     c2d:      	movq	(%rsp), %r14
     c31:      	movq	%r14, %rdi
     c34:      	addq	$0xa0, %rdi
     c3b:      	andl	$0xfff, %r12d           # imm = 0xFFF
     c42:      	movl	$0x4, %eax
     c47:      	movl	%r12d, %esi
     c4a:      	callq	*%rax
     c4c:      	movl	%r12d, 0x9c(%r14)
     c53:      	leaq	0x30(%rsp), %rdi
     c58:      	movl	$0x8, %ecx
     c5d:      	movl	$0x4, %eax
     c62:      	movq	0xe8(%rsp), %rdx
     c6a:      	movl	$0x8, %esi
     c6f:      	callq	*%rax
     c71:      	movq	0x30(%rsp), %rcx
     c76:      	addq	$0x30, %rcx
     c7a:      	leaq	0x70(%rsp), %rdi
     c7f:      	movl	$0x8, %edx
     c84:      	movl	$0x4, %eax
     c89:      	movq	0x30(%rsp), %rdx
     c8e:      	addq	$0x30, %rdx
     c92:      	movl	$0x8, %esi
     c97:      	callq	*%rax
     c99:      	movq	0x70(%rsp), %rcx
     c9e:      	leaq	0x10(%rsp), %rdi
     ca3:      	movl	$0x2, %edx
     ca8:      	movl	$0x4, %eax
     cad:      	movq	0x70(%rsp), %rdx
     cb2:      	movl	$0x2, %esi
     cb7:      	callq	*%rax
     cb9:      	movq	%r14, %rcx
     cbc:      	movl	%ebp, 0xa0(%r14,%r12)
     cc4:      	movzwl	0x10(%rsp), %eax
     cc9:      	movw	%ax, 0xa4(%r14,%r12)
     cd2:      	addl	$0xa, %r12d
     cd6:      	jmp	0x148b <generic_retkprobe_event+0x148b>
     cdb:      	xorl	%r12d, %r12d
     cde:      	jmp	0x1495 <generic_retkprobe_event+0x1495>
     ce3:      	xorl	%r12d, %r12d
     ce6:      	movq	0x20(%rsp), %r13
     ceb:      	jmp	0x1487 <generic_retkprobe_event+0x1487>
     cf0:      	xorl	%eax, %eax
     cf2:      	movq	%rax, 0x8(%rsp)
     cf7:      	movq	0x28(%rsp), %r14
     cfc:      	cmpq	$0x1, 0x88(%rsp)
     d05:      	jne	0xd0f <generic_retkprobe_event+0xd0f>
     d07:      	movq	%rdx, %r13
     d0a:      	jmp	0x428 <generic_retkprobe_event+0x428>
     d0f:      	movq	0x90(%rsp), %rax
     d17:      	leaq	0x10(%rax), %rdx
     d1b:      	leaq	0x30(%rsp), %rdi
     d20:      	movl	$0x4, %r12d
     d26:      	movl	$0x10, %ecx
     d2b:      	movl	$0x4, %eax
     d30:      	movl	$0x10, %esi
     d35:      	callq	*%rax
     d37:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     d3c:      	testl	%eax, %eax
     d3e:      	js	0x1b1f <generic_retkprobe_event+0x1b1f>
     d44:      	movq	0x38(%rsp), %rsi
     d49:      	movq	0x8(%rsp), %rax
     d4e:      	cmpq	%rax, %rsi
     d51:      	movq	%rax, %r13
     d54:      	cmovbq	%rsi, %r13
     d58:      	testq	%rax, %rax
     d5b:      	cmovneq	%r13, %rsi
     d5f:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
     d64:      	cmpq	$0xffe, %rsi            # imm = 0xFFE
     d6b:      	ja	0x1b1f <generic_retkprobe_event+0x1b1f>
     d71:      	movq	0x18(%rsp), %rax
     d76:      	addq	%rbp, %rax
     d79:      	movq	%rax, 0x18(%rsp)
     d7e:      	leaq	(%r15,%rax), %rdi
     d82:      	movq	0x30(%rsp), %rcx
     d87:      	movl	$0x4, %eax
     d8c:      	movq	0x30(%rsp), %rdx
     d91:      	movq	%rsi, (%rsp)
     d95:      	movq	(%rsp), %rsi
     d99:      	callq	*%rax
     d9b:      	movq	(%rsp), %rdx
     d9f:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     da4:      	testl	%eax, %eax
     da6:      	js	0x1b1f <generic_retkprobe_event+0x1b1f>
     dac:      	addq	%rdx, %rbp
     daf:      	movq	0x8(%rsp), %r14
     db4:      	testq	%r14, %r14
     db7:      	je	0x1a4a <generic_retkprobe_event+0x1a4a>
     dbd:      	subq	%r13, %r14
     dc0:      	jne	0x1a4d <generic_retkprobe_event+0x1a4d>
     dc6:      	jmp	0x1de3 <generic_retkprobe_event+0x1de3>
     dcb:      	movb	$0x1, 0x6c(%rsp)
     dd0:      	movq	0x20(%rsp), %r13
     dd5:      	movq	0x18(%rsp), %r15
     dda:      	jmp	0xbeb <generic_retkprobe_event+0xbeb>
     ddf:      	cmpl	$0x9, %r14d
     de3:      	movq	0x20(%rsp), %r13
     de8:      	jg	0xf90 <generic_retkprobe_event+0xf90>
     dee:      	cmpl	$0x4, %r14d
     df2:      	movq	(%rsp), %rcx
     df6:      	jle	0x11cd <generic_retkprobe_event+0x11cd>
     dfc:      	cmpl	$0x5, %r14d
     e00:      	je	0x1796 <generic_retkprobe_event+0x1796>
     e06:      	cmpl	$0x6, %r14d
     e0a:      	je	0xff8 <generic_retkprobe_event+0xff8>
     e10:      	movq	%rax, 0x18(%rsp)
     e15:      	cmpl	$0x7, %r14d
     e19:      	jne	0x148b <generic_retkprobe_event+0x148b>
     e1f:      	movq	0x10(%rsp), %r12
     e24:      	movq	%r12, 0xc4(%rcx)
     e2b:      	leaq	0xc2(%rcx), %rdi
     e32:      	leaq	0x10(%r12), %rdx
     e37:      	movq	%rcx, %r14
     e3a:      	movl	$0x2, %ecx
     e3f:      	movl	$0x4, %eax
     e44:      	movl	$0x2, %esi
     e49:      	callq	*%rax
     e4b:      	leaq	0xd6(%r14), %rdi
     e52:      	leaq	0x12(%r12), %rdx
     e57:      	movl	$0x1, %ecx
     e5c:      	movl	$0x4, %eax
     e61:      	movl	$0x1, %esi
     e66:      	callq	*%rax
     e68:      	leaq	0xd4(%r14), %rdi
     e6f:      	leaq	0x226(%r12), %rdx
     e77:      	movl	$0x2, %ecx
     e7c:      	movl	$0x4, %eax
     e81:      	movl	$0x2, %esi
     e86:      	callq	*%rax
     e88:      	leaq	0xc0(%r14), %rdi
     e8f:      	leaq	0x224(%r12), %rdx
     e97:      	movl	$0x2, %ecx
     e9c:      	movl	$0x4, %eax
     ea1:      	movl	$0x2, %esi
     ea6:      	callq	*%rax
     ea8:      	leaq	0xcc(%r14), %rdi
     eaf:      	leaq	0x21c(%r12), %rdx
     eb7:      	movl	$0x4, %ecx
     ebc:      	movl	$0x4, %eax
     ec1:      	movl	$0x4, %esi
     ec6:      	callq	*%rax
     ec8:      	leaq	0xd0(%r14), %rdi
     ecf:      	leaq	0x218(%r12), %rdx
     ed7:      	movl	$0x4, %ecx
     edc:      	movl	$0x4, %eax
     ee1:      	movl	$0x4, %esi
     ee6:      	callq	*%rax
     ee8:      	leaq	0xac(%r14), %r13
     eef:      	movq	%rbp, %rax
     ef2:      	movq	$0x0, (%rbp)
     efa:      	movq	$0x0, 0x8(%rbp)
     f02:      	movq	$0x0, 0x10(%rbp)
     f0a:      	movq	$0x0, 0x18(%rbp)
     f12:      	movzwl	0xc2(%r14), %eax
     f1a:      	cmpl	$0xa, %eax
     f1d:      	je	0x2492 <generic_retkprobe_event+0x2492>
     f23:      	cmpl	$0x2, %eax
     f26:      	jne	0x24c4 <generic_retkprobe_event+0x24c4>
     f2c:      	leaq	0x4(%r12), %rdx
     f31:      	movl	$0x4, %ecx
     f36:      	movl	$0x4, %eax
     f3b:      	movq	%rbp, %rdi
     f3e:      	movl	$0x4, %esi
     f43:      	callq	*%rax
     f45:      	movl	$0x4, %ecx
     f4a:      	movl	$0x4, %eax
     f4f:      	movq	%r13, %rdi
     f52:      	movl	$0x4, %esi
     f57:      	movq	%r12, %rdx
     f5a:      	jmp	0x24c2 <generic_retkprobe_event+0x24c2>
     f5f:      	cmpl	$0x1c, %r14d
     f63:      	jg	0x11ab <generic_retkprobe_event+0x11ab>
     f69:      	cmpl	$0x11, %r14d
     f6d:      	je	0x15e8 <generic_retkprobe_event+0x15e8>
     f73:      	cmpl	$0x19, %r14d
     f77:      	je	0x16b4 <generic_retkprobe_event+0x16b4>
     f7d:      	cmpl	$0x1c, %r14d
     f81:      	movq	(%rsp), %rcx
     f85:      	je	0x11dd <generic_retkprobe_event+0x11dd>
     f8b:      	jmp	0x148b <generic_retkprobe_event+0x148b>
     f90:      	leal	-0xa(%r14), %eax
     f94:      	cmpl	$0x2, %eax
     f97:      	movq	(%rsp), %rcx
     f9b:      	jb	0x11dd <generic_retkprobe_event+0x11dd>
     fa1:      	leal	-0xc(%r14), %eax
     fa5:      	cmpl	$0x2, %eax
     fa8:      	jb	0x11ff <generic_retkprobe_event+0x11ff>
     fae:      	cmpl	$0xe, %r14d
     fb2:      	jne	0x148b <generic_retkprobe_event+0x148b>
     fb8:      	leaq	0x30(%rsp), %rdi
     fbd:      	leaq	0x10(%rsp), %r14
     fc2:      	movl	$0x8, %ecx
     fc7:      	movl	$0x4, %eax
     fcc:      	movl	$0x8, %esi
     fd1:      	movq	%r14, %rdx
     fd4:      	callq	*%rax
     fd6:      	movq	0x30(%rsp), %rcx
     fdb:      	movl	$0x8, %edx
     fe0:      	movl	$0x4, %eax
     fe5:      	movq	0x30(%rsp), %rdx
     fea:      	movq	%r14, %rdi
     fed:      	movl	$0x8, %esi
     ff2:      	callq	*%rax
     ff4:      	movq	(%rsp), %rcx
     ff8:      	movq	0x10(%rsp), %rdx
     ffd:      	movq	%rcx, %rdi
    1000:      	addq	$0xa0, %rdi
    1007:      	movl	$0x1001, %ecx           # imm = 0x1001
    100c:      	movl	$0x2d, %eax
    1011:      	movl	$0x1001, %esi           # imm = 0x1001
    1016:      	jmp	0x1990 <generic_retkprobe_event+0x1990>
    101b:      	cmpl	$0x20, %r14d
    101f:      	jle	0x13a2 <generic_retkprobe_event+0x13a2>
    1025:      	leal	-0x21(%r14), %edx
    1029:      	cmpl	$0x4, %edx
    102c:      	jae	0x1221 <generic_retkprobe_event+0x1221>
    1032:      	movl	$0x8, %r12d
    1038:      	movl	$0x8, %ecx
    103d:      	movl	$0x4, %eax
    1042:      	movq	0x8(%rsp), %rdi
    1047:      	movl	$0x8, %esi
    104c:      	jmp	0x1482 <generic_retkprobe_event+0x1482>
    1051:      	cmpl	$0x27, %r14d
    1055:      	je	0x196c <generic_retkprobe_event+0x196c>
    105b:      	cmpl	$0x28, %r14d
    105f:      	je	0x19af <generic_retkprobe_event+0x19af>
    1065:      	cmpl	$0x2c, %r14d
    1069:      	movq	(%rsp), %rcx
    106d:      	jne	0x148b <generic_retkprobe_event+0x148b>
    1073:      	movq	0x10(%rsp), %r12
    1078:      	movb	$0x0, 0x30(%rsp)
    107d:      	movq	$0x0, 0x68(%rbp)
    1085:      	movq	$0x0, 0x60(%rbp)
    108d:      	movq	$0x0, 0x58(%rbp)
    1095:      	movq	$0x0, 0x50(%rbp)
    109d:      	movq	$0x0, 0x48(%rbp)
    10a5:      	movq	$0x0, 0x40(%rbp)
    10ad:      	movq	$0x0, 0x38(%rbp)
    10b5:      	movq	$0x0, 0x30(%rbp)
    10bd:      	movq	$0x0, 0x28(%rbp)
    10c5:      	movq	$0x0, 0x20(%rbp)
    10cd:      	movq	$0x0, 0x18(%rbp)
    10d5:      	movq	$0x0, 0x10(%rbp)
    10dd:      	movq	$0x0, 0x8(%rbp)
    10e5:      	movq	$0x0, (%rbp)
    10ed:      	movl	$0x2, %ecx
    10f2:      	movl	$0x4, %eax
    10f7:      	movq	%rbp, %rdi
    10fa:      	movl	$0x2, %esi
    10ff:      	movq	%r12, %rdx
    1102:      	callq	*%rax
    1104:      	testq	%rax, %rax
    1107:      	js	0x26d8 <generic_retkprobe_event+0x26d8>
    110d:      	leaq	0x2(%r12), %r13
    1112:      	leaq	0x30(%rsp), %rdi
    1117:      	movl	$0x1, %ecx
    111c:      	movl	$0x4, %eax
    1121:      	movl	$0x1, %esi
    1126:      	movq	%r13, %rdx
    1129:      	callq	*%rax
    112b:      	testq	%rax, %rax
    112e:      	js	0x26d8 <generic_retkprobe_event+0x26d8>
    1134:      	movq	(%rsp), %rax
    1138:      	movq	%rax, %rdi
    113b:      	addq	$0xa0, %rdi
    1142:      	cmpb	$0x0, 0x30(%rsp)
    1147:      	sete	0x9e(%rax)
    114e:      	je	0x26ad <generic_retkprobe_event+0x26ad>
    1154:      	movl	$0x6c, %ecx
    1159:      	movl	$0x2d, %eax
    115e:      	movl	$0x6c, %esi
    1163:      	movq	%r13, %rdx
    1166:      	callq	*%rax
    1168:      	testl	%eax, %eax
    116a:      	js	0x26d8 <generic_retkprobe_event+0x26d8>
    1170:      	decb	%al
    1172:      	jmp	0x26ce <generic_retkprobe_event+0x26ce>
    1177:      	cmpl	$0x7, %r14d
    117b:      	jg	0x1463 <generic_retkprobe_event+0x1463>
    1181:      	cmpl	$0x2, %r14d
    1185:      	je	0x1df0 <generic_retkprobe_event+0x1df0>
    118b:      	cmpl	$0x3, %r14d
    118f:      	jne	0x148b <generic_retkprobe_event+0x148b>
    1195:      	movq	$0x0, 0x9c(%rax)
    11a0:      	movl	$0x8, %r12d
    11a6:      	jmp	0x148b <generic_retkprobe_event+0x148b>
    11ab:      	leaq	0x10(%rsp), %rdx
    11b0:      	movl	$0x4, %r12d
    11b6:      	movl	$0x2, %ecx
    11bb:      	movl	$0x4, %eax
    11c0:      	movq	%rbp, %rdi
    11c3:      	movl	$0x2, %esi
    11c8:      	jmp	0x1485 <generic_retkprobe_event+0x1485>
    11cd:      	cmpl	$0x1, %r14d
    11d1:      	je	0x11ff <generic_retkprobe_event+0x11ff>
    11d3:      	cmpl	$0x4, %r14d
    11d7:      	jne	0x148b <generic_retkprobe_event+0x148b>
    11dd:      	movl	$0x8, %r12d
    11e3:      	leaq	0x10(%rsp), %rdx
    11e8:      	movl	$0x8, %ecx
    11ed:      	movl	$0x4, %eax
    11f2:      	movq	%rbp, %rdi
    11f5:      	movl	$0x8, %esi
    11fa:      	jmp	0x1485 <generic_retkprobe_event+0x1485>
    11ff:      	leaq	0x10(%rsp), %rdx
    1204:      	movl	$0x4, %r12d
    120a:      	movl	$0x4, %ecx
    120f:      	movl	$0x4, %eax
    1214:      	movq	%rbp, %rdi
    1217:      	movl	$0x4, %esi
    121c:      	jmp	0x1485 <generic_retkprobe_event+0x1485>
    1221:      	cmpl	$0x2b, %r14d
    1225:      	je	0x228e <generic_retkprobe_event+0x228e>
    122b:      	cmpl	$0x29, %r14d
    122f:      	jne	0x148b <generic_retkprobe_event+0x148b>
    1235:      	movq	%rax, 0x80(%rsp)
    123d:      	addq	$0x18, %rbp
    1241:      	leaq	0x30(%rsp), %rdi
    1246:      	movl	$0x4, %r14d
    124c:      	movl	$0x8, %ecx
    1251:      	movl	$0x4, %eax
    1256:      	movl	$0x8, %esi
    125b:      	movq	%rbp, %rdx
    125e:      	callq	*%rax
    1260:      	movq	0x30(%rsp), %r12
    1265:      	testq	%r12, %r12
    1268:      	je	0x2774 <generic_retkprobe_event+0x2774>
    126e:      	movq	(%rsp), %rbp
    1272:      	movq	%r12, 0xc4(%rbp)
    1279:      	leaq	0xc2(%rbp), %rdi
    1280:      	leaq	0x10(%r12), %rdx
    1285:      	movl	$0x2, %ecx
    128a:      	movl	$0x4, %eax
    128f:      	movl	$0x2, %esi
    1294:      	callq	*%rax
    1296:      	leaq	0xd6(%rbp), %rdi
    129d:      	leaq	0x12(%r12), %rdx
    12a2:      	movl	$0x1, %ecx
    12a7:      	movl	$0x4, %eax
    12ac:      	movl	$0x1, %esi
    12b1:      	callq	*%rax
    12b3:      	leaq	0xd4(%rbp), %rdi
    12ba:      	leaq	0x226(%r12), %rdx
    12c2:      	movl	$0x2, %ecx
    12c7:      	movl	$0x4, %eax
    12cc:      	movl	$0x2, %esi
    12d1:      	callq	*%rax
    12d3:      	leaq	0xc0(%rbp), %rdi
    12da:      	leaq	0x224(%r12), %rdx
    12e2:      	movl	$0x2, %ecx
    12e7:      	movl	$0x4, %eax
    12ec:      	movl	$0x2, %esi
    12f1:      	callq	*%rax
    12f3:      	leaq	0xcc(%rbp), %rdi
    12fa:      	leaq	0x21c(%r12), %rdx
    1302:      	movl	$0x4, %eax
    1307:      	movl	$0x4, %esi
    130c:      	callq	*%rax
    130e:      	leaq	0xd0(%rbp), %rdi
    1315:      	leaq	0x218(%r12), %rdx
    131d:      	movl	$0x4, %eax
    1322:      	movl	$0x4, %esi
    1327:      	callq	*%rax
    1329:      	leaq	0xac(%rbp), %r13
    1330:      	movq	0x8(%rsp), %rax
    1335:      	movq	$0x0, (%rax)
    133c:      	movq	$0x0, 0x8(%rax)
    1344:      	movq	$0x0, 0x10(%rax)
    134c:      	movq	$0x0, 0x18(%rax)
    1354:      	movzwl	0xc2(%rbp), %eax
    135b:      	cmpl	$0xa, %eax
    135e:      	je	0x26e8 <generic_retkprobe_event+0x26e8>
    1364:      	cmpl	$0x2, %eax
    1367:      	jne	0x271c <generic_retkprobe_event+0x271c>
    136d:      	leaq	0x4(%r12), %rdx
    1372:      	movl	$0x4, %ecx
    1377:      	movl	$0x4, %eax
    137c:      	movq	0x8(%rsp), %rdi
    1381:      	movl	$0x4, %esi
    1386:      	callq	*%rax
    1388:      	movl	$0x4, %ecx
    138d:      	movl	$0x4, %eax
    1392:      	movq	%r13, %rdi
    1395:      	movl	$0x4, %esi
    139a:      	movq	%r12, %rdx
    139d:      	jmp	0x271a <generic_retkprobe_event+0x271a>
    13a2:      	cmpl	$0x1a, %r14d
    13a6:      	je	0x2338 <generic_retkprobe_event+0x2338>
    13ac:      	cmpl	$0x1b, %r14d
    13b0:      	jne	0x148b <generic_retkprobe_event+0x148b>
    13b6:      	movq	0x8(%rsp), %rax
    13bb:      	movq	$0x0, 0x48(%rax)
    13c3:      	movq	$0x0, 0x40(%rax)
    13cb:      	movq	$0x0, 0x38(%rax)
    13d3:      	movq	$0x0, 0x30(%rax)
    13db:      	movq	$0x0, 0x28(%rax)
    13e3:      	movq	$0x0, 0x20(%rax)
    13eb:      	movq	$0x0, 0x18(%rax)
    13f3:      	movq	$0x0, 0x10(%rax)
    13fb:      	movq	$0x0, 0x8(%rax)
    1403:      	movq	$0x0, (%rax)
    140a:      	leaq	0xac(%rcx), %rdi
    1411:      	leaq	0x18(%rbp), %rdx
    1415:      	movl	$0x3f, %ecx
    141a:      	movl	$0x2d, %eax
    141f:      	movl	$0x3f, %esi
    1424:      	callq	*%rax
    1426:      	testq	%rax, %rax
    1429:      	js	0x26a5 <generic_retkprobe_event+0x26a5>
    142f:      	movq	(%rsp), %r14
    1433:      	movq	%r14, %rdi
    1436:      	addq	$0xa4, %rdi
    143d:      	addq	$0x348, %rbp            # imm = 0x348
    1444:      	movl	$0x8, %ecx
    1449:      	movl	$0x4, %eax
    144e:      	movl	$0x8, %esi
    1453:      	movq	%rbp, %rdx
    1456:      	callq	*%rax
    1458:      	movq	%r14, %rcx
    145b:      	movl	$0x50, %r12d
    1461:      	jmp	0x148b <generic_retkprobe_event+0x148b>
    1463:      	cmpl	$0x8, %r14d
    1467:      	je	0x1e9d <generic_retkprobe_event+0x1e9d>
    146d:      	cmpl	$0x12, %r14d
    1471:      	jne	0x148b <generic_retkprobe_event+0x148b>
    1473:      	xorl	%r12d, %r12d
    1476:      	movl	$0x4, %eax
    147b:      	movq	0x8(%rsp), %rdi
    1480:      	xorl	%esi, %esi
    1482:      	movq	%rbp, %rdx
    1485:      	callq	*%rax
    1487:      	movq	(%rsp), %rcx
    148b:      	testl	%r12d, %r12d
    148e:      	movl	$0x4, %ebp
    1493:      	js	0x14a5 <generic_retkprobe_event+0x14a5>
    1495:      	andl	$0x7fffffff, %r12d      # imm = 0x7FFFFFFF
    149c:      	addq	$0x4, %r12
    14a0:      	movq	%r12, %rbp
    14a3:      	jmp	0x14b9 <generic_retkprobe_event+0x14b9>
    14a5:      	movl	$0xffffffff, 0x5ea0(%rcx) # imm = 0xFFFFFFFF
    14af:      	movl	$0xffffffff, 0x98(%rcx) # imm = 0xFFFFFFFF
    14b9:      	movq	0xb8(%rsp), %r12
    14c1:      	addq	$0x8, %rbp
    14c5:      	movl	0x60(%r13), %eax
    14c9:      	cmpl	$0xb, %eax
    14cc:      	jne	0x1b3 <generic_retkprobe_event+0x1b3>
    14d2:      	jmp	0x2fd <generic_retkprobe_event+0x2fd>
    14d7:      	cmpl	$0x13, %r14d
    14db:      	je	0x222f <generic_retkprobe_event+0x222f>
    14e1:      	cmpl	$0x14, %r14d
    14e5:      	jne	0x148b <generic_retkprobe_event+0x148b>
    14e7:      	movq	$0x0, 0x30(%rsp)
    14f0:      	leaq	0x110(%rbp), %rdx
    14f7:      	leaq	0x30(%rsp), %rdi
    14fc:      	movl	$0x8, %ecx
    1501:      	movl	$0x4, %eax
    1506:      	leaq	0xd8(%rbp), %r12
    150d:      	movl	$0x8, %esi
    1512:      	callq	*%rax
    1514:      	movq	0x30(%rsp), %rcx
    1519:      	movl	$0x80, %edx
    151e:      	movl	$0x2d, %eax
    1523:      	movq	0x8(%rsp), %rdi
    1528:      	movq	0x30(%rsp), %rdx
    152d:      	movl	$0x80, %esi
    1532:      	callq	*%rax
    1534:      	movq	(%rsp), %rax
    1538:      	leaq	0x12c(%rax), %rdi
    153f:      	movl	$0x4, %ecx
    1544:      	movl	$0x4, %eax
    1549:      	movl	$0x4, %esi
    154e:      	movq	%r12, %rdx
    1551:      	callq	*%rax
    1553:      	movq	(%rsp), %rax
    1557:      	leaq	0x11c(%rax), %rdi
    155e:      	leaq	0xe0(%rbp), %rdx
    1565:      	movl	$0x8, %ecx
    156a:      	movl	$0x4, %eax
    156f:      	movl	$0x8, %esi
    1574:      	callq	*%rax
    1576:      	movq	(%rsp), %rdi
    157a:      	addq	$0x124, %rdi            # imm = 0x124
    1581:      	addq	$0x118, %rbp            # imm = 0x118
    1588:      	movl	$0x8, %ecx
    158d:      	movl	$0x4, %eax
    1592:      	movl	$0x8, %esi
    1597:      	movq	%rbp, %rdx
    159a:      	callq	*%rax
    159c:      	movq	(%rsp), %rcx
    15a0:      	movl	$0x98, %r12d
    15a6:      	jmp	0x148b <generic_retkprobe_event+0x148b>
    15ab:      	cmpl	$0x26, %r14d
    15af:      	movq	(%rsp), %rcx
    15b3:      	jne	0x148b <generic_retkprobe_event+0x148b>
    15b9:      	movq	0x10(%rsp), %rsi
    15be:      	movzwl	%si, %edx
    15c1:      	addq	0xb8(%rsp), %rdx
    15c9:      	shrl	$0x10, %esi
    15cc:      	andl	$0xfff, %esi            # imm = 0xFFF
    15d2:      	movq	%rcx, %rdi
    15d5:      	addq	$0xa0, %rdi
    15dc:      	incl	%esi
    15de:      	movl	$0x2d, %eax
    15e3:      	jmp	0x1990 <generic_retkprobe_event+0x1990>
    15e8:      	movq	$0x0, 0x38(%rsp)
    15f1:      	movq	$0x0, 0x30(%rsp)
    15fa:      	movl	$0xe, %eax
    15ff:      	callq	*%rax
    1601:      	shrq	$0x20, %rax
    1605:      	movq	%rax, 0x30(%rsp)
    160a:      	leaq	0x70(%rsp), %rdi
    160f:      	leaq	0x10(%rsp), %rdx
    1614:      	movl	$0x4, %ecx
    1619:      	movl	$0x4, %eax
    161e:      	movl	$0x4, %r14d
    1624:      	movl	$0x4, %esi
    1629:      	callq	*%rax
    162b:      	movl	0x70(%rsp), %eax
    162f:      	movl	%eax, 0x38(%rsp)
    1633:      	movq	(%rip), %rdi            # 0x163a <generic_retkprobe_event+0x163a>
    163a:      	leaq	0x30(%rsp), %rsi
    163f:      	movl	$0x1, %eax
    1644:      	callq	*%rax
    1646:      	testq	%rax, %rax
    1649:      	je	0x23cc <generic_retkprobe_event+0x23cc>
    164f:      	movl	(%rax), %r12d
    1652:      	leaq	0x70(%rsp), %rdx
    1657:      	movq	%rax, %r13
    165a:      	movl	$0x4, %eax
    165f:      	movq	%rbp, %rdi
    1662:      	movl	$0x4, %esi
    1667:      	callq	*%rax
    1669:      	andl	$0xfff, %r12d           # imm = 0xFFF
    1670:      	movq	(%rsp), %rdi
    1674:      	addq	$0xa0, %rdi
    167b:      	leaq	0x4(%r12), %rsi
    1680:      	movl	$0x4, %eax
    1685:      	movq	%r13, %rdx
    1688:      	callq	*%rax
    168a:      	leaq	(%r12,%rbp), %rdi
    168e:      	addq	$0x8, %rdi
    1692:      	leaq	(%r12,%r13), %rdx
    1696:      	addq	$0x4, %rdx
    169a:      	movl	$0x4, %eax
    169f:      	movl	$0x4, %esi
    16a4:      	callq	*%rax
    16a6:      	addq	$0xc, %r12
    16aa:      	movq	0x20(%rsp), %r13
    16af:      	jmp	0x1487 <generic_retkprobe_event+0x1487>
    16b4:      	movq	%rax, %r14
    16b7:      	movq	0x10(%rsp), %r12
    16bc:      	leaq	0x98(%rsp), %rdi
    16c4:      	movl	$0x1, %ecx
    16c9:      	movl	$0x4, %eax
    16ce:      	movl	$0x1, %esi
    16d3:      	movq	%r12, %rdx
    16d6:      	callq	*%rax
    16d8:      	cmpb	$0x1, 0x98(%rsp)
    16e0:      	jne	0x23b6 <generic_retkprobe_event+0x23b6>
    16e6:      	addq	$0x10, %r12
    16ea:      	leaq	0x30(%rsp), %rdi
    16ef:      	movl	$0x8, %ecx
    16f4:      	movl	$0x4, %eax
    16f9:      	movl	$0x8, %esi
    16fe:      	movq	%r12, %rdx
    1701:      	callq	*%rax
    1703:      	movq	0x30(%rsp), %rdx
    1708:      	leaq	0x70(%rsp), %rdi
    170d:      	movl	$0x8, %ecx
    1712:      	movl	$0x4, %eax
    1717:      	movl	$0x8, %esi
    171c:      	callq	*%rax
    171e:      	movq	0x30(%rsp), %rdx
    1723:      	addq	$0x8, %rdx
    1727:      	leaq	0xa0(%rsp), %rdi
    172f:      	movl	$0x8, %ecx
    1734:      	movl	$0x4, %eax
    1739:      	movl	$0x8, %esi
    173e:      	callq	*%rax
    1740:      	movq	0x70(%rsp), %rdx
    1745:      	movq	0xa0(%rsp), %r13
    174d:      	cmpq	$0xfff, %r13            # imm = 0xFFF
    1754:      	movl	$0xfff, %r12d           # imm = 0xFFF
    175a:      	cmovbq	%r13, %r12
    175e:      	movq	%r14, %rdi
    1761:      	addq	$0xa4, %rdi
    1768:      	movl	$0x4, %eax
    176d:      	movl	%r12d, %esi
    1770:      	callq	*%rax
    1772:      	testl	%eax, %eax
    1774:      	js	0x2566 <generic_retkprobe_event+0x2566>
    177a:      	movl	%r13d, 0x9c(%r14)
    1781:      	movl	%r12d, 0xa0(%r14)
    1788:      	addq	$0x8, %r12
    178c:      	movq	0x20(%rsp), %r13
    1791:      	jmp	0x1487 <generic_retkprobe_event+0x1487>
    1796:      	movq	0x10(%rsp), %r12
    179b:      	leaq	0xc4(%rcx), %rdi
    17a2:      	leaq	0x98(%r12), %rdx
    17aa:      	movq	%rcx, %r14
    17ad:      	movl	$0x4, %ecx
    17b2:      	movl	$0x4, %eax
    17b7:      	movl	$0x4, %esi
    17bc:      	callq	*%rax
    17be:      	leaq	0xc8(%r14), %rdi
    17c5:      	leaq	0x70(%r12), %rdx
    17ca:      	movl	$0x4, %ecx
    17cf:      	movl	$0x4, %eax
    17d4:      	movl	$0x4, %esi
    17d9:      	callq	*%rax
    17db:      	leaq	0xcc(%r14), %rdi
    17e2:      	leaq	0x90(%r12), %rdx
    17ea:      	movl	$0x4, %ecx
    17ef:      	movl	$0x4, %eax
    17f4:      	movl	$0x4, %esi
    17f9:      	callq	*%rax
    17fb:      	leaq	0xd0(%r14), %rdi
    1802:      	leaq	0xa8(%r12), %rdx
    180a:      	movl	$0x4, %ecx
    180f:      	movl	$0x4, %eax
    1814:      	movl	$0x4, %esi
    1819:      	callq	*%rax
    181b:      	movq	$0x0, 0x30(%rsp)
    1824:      	leaq	0xc8(%r12), %rdx
    182c:      	leaq	0x30(%rsp), %rdi
    1831:      	movl	$0x8, %ecx
    1836:      	movl	$0x4, %eax
    183b:      	movl	$0x8, %esi
    1840:      	callq	*%rax
    1842:      	movq	%r12, 0x8(%rsp)
    1847:      	leaq	0xb8(%r12), %rdx
    184f:      	leaq	0x98(%rsp), %rdi
    1857:      	movl	$0x2, %ecx
    185c:      	movl	$0x4, %eax
    1861:      	movl	$0x2, %esi
    1866:      	callq	*%rax
    1868:      	movzwl	0x98(%rsp), %r12d
    1871:      	addq	0x30(%rsp), %r12
    1876:      	leaq	0xb4(%rsp), %rdi
    187e:      	movl	$0x1, %ecx
    1883:      	movl	$0x4, %eax
    1888:      	movl	$0x1, %esi
    188d:      	movq	%r12, %rdx
    1890:      	callq	*%rax
    1892:      	movzbl	0xb4(%rsp), %eax
    189a:      	shrl	$0x4, %eax
    189d:      	cmpl	$0x6, %eax
    18a0:      	je	0x23dd <generic_retkprobe_event+0x23dd>
    18a6:      	cmpl	$0x4, %eax
    18a9:      	jne	0x30e9 <generic_retkprobe_event+0x30e9>
    18af:      	leaq	0x9(%r12), %rdx
    18b4:      	leaq	0xc8(%rsp), %rdi
    18bc:      	movl	$0x1, %ecx
    18c1:      	movl	$0x4, %eax
    18c6:      	movl	$0x1, %esi
    18cb:      	callq	*%rax
    18cd:      	movzbl	0xc8(%rsp), %eax
    18d5:      	movq	(%rsp), %rsi
    18d9:      	movw	%ax, 0xc0(%rsi)
    18e0:      	movw	$0x2, 0xc2(%rsi)
    18e9:      	leaq	0xc(%r12), %rdx
    18ee:      	movq	$0x0, (%rbp)
    18f6:      	movq	$0x0, 0x8(%rbp)
    18fe:      	movq	$0x0, 0x10(%rbp)
    1906:      	movq	$0x0, 0x18(%rbp)
    190e:      	movl	$0x4, %ecx
    1913:      	movl	$0x4, %eax
    1918:      	leaq	0xac(%rsi), %r14
    191f:      	movq	%rbp, %rdi
    1922:      	movl	$0x4, %esi
    1927:      	callq	*%rax
    1929:      	addq	$0x10, %r12
    192d:      	movl	$0x4, %ecx
    1932:      	movl	$0x4, %eax
    1937:      	movq	%r14, %rdi
    193a:      	movl	$0x4, %esi
    193f:      	movq	%r12, %rdx
    1942:      	callq	*%rax
    1944:      	movq	0x8(%rsp), %rax
    1949:      	leaq	0xb6(%rax), %rdx
    1950:      	leaq	0xd0(%rsp), %rdi
    1958:      	movl	$0x2, %ecx
    195d:      	movl	$0x4, %eax
    1962:      	movl	$0x2, %esi
    1967:      	jmp	0x2f59 <generic_retkprobe_event+0x2f59>
    196c:      	movl	$0x120, %edx            # imm = 0x120
    1971:      	addq	0x10(%rsp), %rdx
    1976:      	movq	(%rsp), %rdi
    197a:      	addq	$0xa0, %rdi
    1981:      	movl	$0x11, %ecx
    1986:      	movl	$0x2d, %eax
    198b:      	movl	$0x11, %esi
    1990:      	callq	*%rax
    1992:      	movq	%rax, %r12
    1995:      	testq	%rax, %rax
    1998:      	js	0x1487 <generic_retkprobe_event+0x1487>
    199e:      	leal	-0x1(%r12), %eax
    19a3:      	movl	%eax, (%rbp)
    19a6:      	addq	$0x3, %r12
    19aa:      	jmp	0x1487 <generic_retkprobe_event+0x1487>
    19af:      	movq	0x10(%rsp), %r12
    19b4:      	movq	$0x0, 0x10(%rbp)
    19bc:      	movq	$0x0, 0x8(%rbp)
    19c4:      	movq	$0x0, (%rbp)
    19cc:      	movl	$0x2, %ecx
    19d1:      	movl	$0x4, %eax
    19d6:      	movq	%rbp, %rdi
    19d9:      	movl	$0x2, %esi
    19de:      	movq	%r12, %rdx
    19e1:      	callq	*%rax
    19e3:      	testq	%rax, %rax
    19e6:      	movq	(%rsp), %rcx
    19ea:      	js	0x25e1 <generic_retkprobe_event+0x25e1>
    19f0:      	movzwl	(%rbp), %eax
    19f4:      	cmpl	$0xa, %eax
    19f7:      	je	0x2581 <generic_retkprobe_event+0x2581>
    19fd:      	cmpl	$0x2, %eax
    1a00:      	jne	0x25c3 <generic_retkprobe_event+0x25c3>
    1a06:      	leaq	0x4(%r12), %rdx
    1a0b:      	leaq	0x30(%rsp), %rdi
    1a10:      	movl	$0x4, %ecx
    1a15:      	movl	$0x4, %eax
    1a1a:      	movl	$0x4, %esi
    1a1f:      	callq	*%rax
    1a21:      	movl	0x30(%rsp), %eax
    1a25:      	movq	(%rsp), %rdi
    1a29:      	movq	%rax, 0xa4(%rdi)
    1a30:      	addq	$0x9e, %rdi
    1a37:      	addq	$0x2, %r12
    1a3b:      	movl	$0x2, %ecx
    1a40:      	movl	$0x4, %eax
    1a45:      	jmp	0x25b9 <generic_retkprobe_event+0x25b9>
    1a4a:      	xorl	%r14d, %r14d
    1a4d:      	cmpq	$0x3, 0x88(%rsp)
    1a56:      	jb	0x1de3 <generic_retkprobe_event+0x1de3>
    1a5c:      	movq	0x90(%rsp), %rax
    1a64:      	leaq	0x20(%rax), %rdx
    1a68:      	leaq	0x30(%rsp), %rdi
    1a6d:      	movl	$0x4, %r12d
    1a73:      	movl	$0x10, %ecx
    1a78:      	movl	$0x4, %eax
    1a7d:      	movl	$0x10, %esi
    1a82:      	callq	*%rax
    1a84:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    1a89:      	testl	%eax, %eax
    1a8b:      	js	0x1b1a <generic_retkprobe_event+0x1b1a>
    1a91:      	movq	0x38(%rsp), %rax
    1a96:      	cmpq	%r14, %rax
    1a99:      	movq	%r14, %rcx
    1a9c:      	cmovbq	%rax, %rcx
    1aa0:      	movq	%r14, 0x8(%rsp)
    1aa5:      	testq	%r14, %r14
    1aa8:      	movq	%rax, %r14
    1aab:      	movq	%rcx, %r13
    1aae:      	cmovneq	%rcx, %r14
    1ab2:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    1ab7:      	cmpq	$0xffe, %r14            # imm = 0xFFE
    1abe:      	ja	0x1b1a <generic_retkprobe_event+0x1b1a>
    1ac0:      	movq	(%rsp), %rdi
    1ac4:      	addq	0x18(%rsp), %rdi
    1ac9:      	movq	%rdi, (%rsp)
    1acd:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    1ad3:      	addq	%r15, %rdi
    1ad6:      	movq	0x30(%rsp), %rcx
    1adb:      	movl	$0x4, %eax
    1ae0:      	movq	0x30(%rsp), %rdx
    1ae5:      	movl	%r14d, %esi
    1ae8:      	callq	*%rax
    1aea:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    1aef:      	testl	%eax, %eax
    1af1:      	js	0x1b1a <generic_retkprobe_event+0x1b1a>
    1af3:      	movq	%r15, 0x18(%rsp)
    1af8:      	movq	%r14, %r15
    1afb:      	addq	%r14, %rbp
    1afe:      	cmpq	$0x0, 0x8(%rsp)
    1b04:      	je	0x280a <generic_retkprobe_event+0x280a>
    1b0a:      	subq	%r13, 0x8(%rsp)
    1b0f:      	jne	0x2811 <generic_retkprobe_event+0x2811>
    1b15:      	jmp	0x281c <generic_retkprobe_event+0x281c>
    1b1a:      	movq	0x28(%rsp), %r14
    1b1f:      	movl	%ecx, (%r15,%r14)
    1b23:      	addq	%r14, %r12
    1b26:      	movq	%r12, %rbp
    1b29:      	movq	0xb8(%rsp), %r12
    1b31:      	movq	0x20(%rsp), %r13
    1b36:      	movl	$0x23, %eax
    1b3b:      	callq	*%rax
    1b3d:      	movq	%rax, %rcx
    1b40:      	movq	%rax, 0x30(%rsp)
    1b45:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    1b4c:      	leaq	0xa0(%rsp), %rdi
    1b54:      	movl	$0x4, %edx
    1b59:      	movl	$0x71, %eax
    1b5e:      	movl	$0xaf4, %edx            # imm = 0xAF4
    1b63:      	addq	0x30(%rsp), %rdx
    1b68:      	movl	$0x4, %esi
    1b6d:      	callq	*%rax
    1b6f:      	movl	0xa0(%rsp), %eax
    1b76:      	movl	%eax, 0x70(%rsp)
    1b7a:      	movq	(%rip), %rdi            # 0x1b81 <generic_retkprobe_event+0x1b81>
    1b81:      	leaq	0x70(%rsp), %rsi
    1b86:      	movl	$0x1, %eax
    1b8b:      	callq	*%rax
    1b8d:      	testq	%rax, %rax
    1b90:      	je	0x1ba0 <generic_retkprobe_event+0x1ba0>
    1b92:      	movq	%rax, %r15
    1b95:      	cmpq	$0x0, 0x8(%rax)
    1b9a:      	jne	0x1d76 <generic_retkprobe_event+0x1d76>
    1ba0:      	movl	$0xb00, %edx            # imm = 0xB00
    1ba5:      	movq	0x30(%rsp), %rcx
    1baa:      	addq	%rdx, %rcx
    1bad:      	leaq	0x30(%rsp), %rdi
    1bb2:      	movl	$0x8, %esi
    1bb7:      	movl	$0x71, %eax
    1bbc:      	addq	0x30(%rsp), %rdx
    1bc1:      	movl	$0x8, %esi
    1bc6:      	callq	*%rax
    1bc8:      	movq	0x30(%rsp), %rcx
    1bcd:      	testq	%rcx, %rcx
    1bd0:      	je	0x1d73 <generic_retkprobe_event+0x1d73>
    1bd6:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    1bdd:      	leaq	0xa0(%rsp), %rdi
    1be5:      	movl	$0x4, %edx
    1bea:      	movl	$0x71, %eax
    1bef:      	movl	$0xaf4, %edx            # imm = 0xAF4
    1bf4:      	addq	0x30(%rsp), %rdx
    1bf9:      	movl	$0x4, %esi
    1bfe:      	callq	*%rax
    1c00:      	movl	0xa0(%rsp), %eax
    1c07:      	movl	%eax, 0x70(%rsp)
    1c0b:      	movq	(%rip), %rdi            # 0x1c12 <generic_retkprobe_event+0x1c12>
    1c12:      	leaq	0x70(%rsp), %rsi
    1c17:      	movl	$0x1, %eax
    1c1c:      	callq	*%rax
    1c1e:      	testq	%rax, %rax
    1c21:      	je	0x1c31 <generic_retkprobe_event+0x1c31>
    1c23:      	movq	%rax, %r15
    1c26:      	cmpq	$0x0, 0x8(%rax)
    1c2b:      	jne	0x1d76 <generic_retkprobe_event+0x1d76>
    1c31:      	movl	$0xb00, %edx            # imm = 0xB00
    1c36:      	movq	0x30(%rsp), %rcx
    1c3b:      	addq	%rdx, %rcx
    1c3e:      	leaq	0x30(%rsp), %rdi
    1c43:      	movl	$0x8, %esi
    1c48:      	movl	$0x71, %eax
    1c4d:      	addq	0x30(%rsp), %rdx
    1c52:      	movl	$0x8, %esi
    1c57:      	callq	*%rax
    1c59:      	movq	0x30(%rsp), %rcx
    1c5e:      	testq	%rcx, %rcx
    1c61:      	je	0x1d73 <generic_retkprobe_event+0x1d73>
    1c67:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    1c6e:      	leaq	0xa0(%rsp), %rdi
    1c76:      	movl	$0x4, %edx
    1c7b:      	movl	$0x71, %eax
    1c80:      	movl	$0xaf4, %edx            # imm = 0xAF4
    1c85:      	addq	0x30(%rsp), %rdx
    1c8a:      	movl	$0x4, %esi
    1c8f:      	callq	*%rax
    1c91:      	movl	0xa0(%rsp), %eax
    1c98:      	movl	%eax, 0x70(%rsp)
    1c9c:      	movq	(%rip), %rdi            # 0x1ca3 <generic_retkprobe_event+0x1ca3>
    1ca3:      	leaq	0x70(%rsp), %rsi
    1ca8:      	movl	$0x1, %eax
    1cad:      	callq	*%rax
    1caf:      	testq	%rax, %rax
    1cb2:      	je	0x1cc2 <generic_retkprobe_event+0x1cc2>
    1cb4:      	movq	%rax, %r15
    1cb7:      	cmpq	$0x0, 0x8(%rax)
    1cbc:      	jne	0x1d76 <generic_retkprobe_event+0x1d76>
    1cc2:      	movl	$0xb00, %edx            # imm = 0xB00
    1cc7:      	movq	0x30(%rsp), %rcx
    1ccc:      	addq	%rdx, %rcx
    1ccf:      	leaq	0x30(%rsp), %rdi
    1cd4:      	movl	$0x8, %esi
    1cd9:      	movl	$0x71, %eax
    1cde:      	addq	0x30(%rsp), %rdx
    1ce3:      	movl	$0x8, %esi
    1ce8:      	callq	*%rax
    1cea:      	movq	0x30(%rsp), %rcx
    1cef:      	testq	%rcx, %rcx
    1cf2:      	je	0x1d73 <generic_retkprobe_event+0x1d73>
    1cf4:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    1cfb:      	leaq	0xa0(%rsp), %rdi
    1d03:      	movl	$0x4, %edx
    1d08:      	movl	$0x71, %eax
    1d0d:      	movl	$0xaf4, %edx            # imm = 0xAF4
    1d12:      	addq	0x30(%rsp), %rdx
    1d17:      	movl	$0x4, %esi
    1d1c:      	callq	*%rax
    1d1e:      	movl	0xa0(%rsp), %eax
    1d25:      	movl	%eax, 0x70(%rsp)
    1d29:      	movq	(%rip), %rdi            # 0x1d30 <generic_retkprobe_event+0x1d30>
    1d30:      	leaq	0x70(%rsp), %rsi
    1d35:      	movl	$0x1, %eax
    1d3a:      	callq	*%rax
    1d3c:      	testq	%rax, %rax
    1d3f:      	je	0x1d4b <generic_retkprobe_event+0x1d4b>
    1d41:      	movq	%rax, %r15
    1d44:      	cmpq	$0x0, 0x8(%rax)
    1d49:      	jne	0x1d76 <generic_retkprobe_event+0x1d76>
    1d4b:      	movl	$0xb00, %edx            # imm = 0xB00
    1d50:      	movq	0x30(%rsp), %rcx
    1d55:      	addq	%rdx, %rcx
    1d58:      	leaq	0x30(%rsp), %rdi
    1d5d:      	movl	$0x8, %esi
    1d62:      	movl	$0x71, %eax
    1d67:      	addq	0x30(%rsp), %rdx
    1d6c:      	movl	$0x8, %esi
    1d71:      	callq	*%rax
    1d73:      	xorl	%r15d, %r15d
    1d76:      	movl	$0x10d, (%rbx)          # imm = 0x10D
    1d7c:      	movl	%ebp, 0x4(%rbx)
    1d7f:      	movl	$0x7d, %eax
    1d84:      	callq	*%rax
    1d86:      	movq	%rax, 0x8(%rbx)
    1d8a:      	testq	%r15, %r15
    1d8d:      	je	0x1d9d <generic_retkprobe_event+0x1d9d>
    1d8f:      	movl	(%r15), %eax
    1d92:      	movl	%eax, 0x10(%rbx)
    1d95:      	movq	0x8(%r15), %rax
    1d99:      	movq	%rax, 0x18(%rbx)
    1d9d:      	movl	$0x0, 0x14(%rbx)
    1da4:      	movl	(%r13), %eax
    1da8:      	movq	%rax, 0x60(%rbx)
    1dac:      	movl	%ebp, 0x4(%rbx)
    1daf:      	movq	(%rip), %rsi            # 0x1db6 <generic_retkprobe_event+0x1db6>
    1db6:      	movl	$0x3, %ecx
    1dbb:      	movl	$0xc, %eax
    1dc0:      	movq	%r12, %rdi
    1dc3:      	movl	$0x3, %edx
    1dc8:      	callq	*%rax
    1dca:      	movl	$0x1, %ebp
    1dcf:      	movl	%ebp, %eax
    1dd1:      	addq	$0xf8, %rsp
    1dd8:      	popq	%rbx
    1dd9:      	popq	%r12
    1ddb:      	popq	%r13
    1ddd:      	popq	%r14
    1ddf:      	popq	%r15
    1de1:      	popq	%rbp
    1de2:      	retq
    1de3:      	movq	%rbp, %r13
    1de6:      	movq	0x28(%rsp), %r14
    1deb:      	jmp	0x428 <generic_retkprobe_event+0x428>
    1df0:      	movq	$0x0, 0x70(%rsp)
    1df9:      	movq	$0x0, 0x30(%rsp)
    1e02:      	movq	%rax, %r14
    1e05:      	leaq	0x70(%rsp), %rdi
    1e0a:      	leaq	0x30(%rsp), %rdx
    1e0f:      	movl	$0x8, %ecx
    1e14:      	movl	$0x4, %eax
    1e19:      	movl	$0x4, %r12d
    1e1f:      	movl	$0x8, %esi
    1e24:      	callq	*%rax
    1e26:      	movq	0x70(%rsp), %rax
    1e2b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    1e31:      	movl	$0xfff, %r13d           # imm = 0xFFF
    1e37:      	movq	%rax, 0x18(%rsp)
    1e3c:      	cmovbq	%rax, %r13
    1e40:      	movq	%r14, 0x80(%rsp)
    1e48:      	addq	$0xa4, %r14
    1e4f:      	movl	$0x4, %eax
    1e54:      	movq	%r14, %rdi
    1e57:      	movl	%r13d, %esi
    1e5a:      	movq	%rbp, %rdx
    1e5d:      	callq	*%rax
    1e5f:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    1e64:      	testl	%eax, %eax
    1e66:      	js	0x1e85 <generic_retkprobe_event+0x1e85>
    1e68:      	movq	0x80(%rsp), %rax
    1e70:      	movl	%r13d, 0xa0(%rax)
    1e77:      	addq	$0x8, %r13
    1e7b:      	movq	0x18(%rsp), %rax
    1e80:      	movl	%eax, %ecx
    1e82:      	movq	%r13, %r12
    1e85:      	movq	0x80(%rsp), %rax
    1e8d:      	movl	%ecx, 0x9c(%rax)
    1e93:      	movq	0x20(%rsp), %r13
    1e98:      	jmp	0x1487 <generic_retkprobe_event+0x1487>
    1e9d:      	leaq	0xc4(%rcx), %r13
    1ea4:      	leaq	0xdc(%rcx), %r12
    1eab:      	leaq	0x8(%rbp), %rdx
    1eaf:      	movl	$0x4, %ecx
    1eb4:      	movl	$0x4, %eax
    1eb9:      	movq	0x8(%rsp), %rdi
    1ebe:      	movl	$0x4, %esi
    1ec3:      	callq	*%rax
    1ec5:      	movq	(%rsp), %rax
    1ec9:      	leaq	0xa0(%rax), %rdi
    1ed0:      	leaq	0xc(%rbp), %rdx
    1ed4:      	movl	$0x4, %ecx
    1ed9:      	movl	$0x4, %eax
    1ede:      	movl	$0x4, %esi
    1ee3:      	callq	*%rax
    1ee5:      	movq	(%rsp), %rax
    1ee9:      	leaq	0xac(%rax), %rdi
    1ef0:      	leaq	0x18(%rbp), %rdx
    1ef4:      	movl	$0x4, %ecx
    1ef9:      	movl	$0x4, %eax
    1efe:      	movl	$0x4, %esi
    1f03:      	callq	*%rax
    1f05:      	movq	(%rsp), %rax
    1f09:      	leaq	0xb0(%rax), %rdi
    1f10:      	leaq	0x1c(%rbp), %rdx
    1f14:      	movl	$0x4, %ecx
    1f19:      	movl	$0x4, %eax
    1f1e:      	movl	$0x4, %esi
    1f23:      	callq	*%rax
    1f25:      	movq	(%rsp), %rax
    1f29:      	leaq	0xa4(%rax), %rdi
    1f30:      	leaq	0x10(%rbp), %rdx
    1f34:      	movl	$0x4, %ecx
    1f39:      	movl	$0x4, %eax
    1f3e:      	movl	$0x4, %esi
    1f43:      	callq	*%rax
    1f45:      	movq	(%rsp), %rax
    1f49:      	leaq	0xa8(%rax), %rdi
    1f50:      	leaq	0x14(%rbp), %rdx
    1f54:      	movl	$0x4, %ecx
    1f59:      	movl	$0x4, %eax
    1f5e:      	movl	$0x4, %esi
    1f63:      	callq	*%rax
    1f65:      	movq	(%rsp), %rax
    1f69:      	leaq	0xb4(%rax), %rdi
    1f70:      	leaq	0x20(%rbp), %rdx
    1f74:      	movl	$0x4, %ecx
    1f79:      	movl	$0x4, %eax
    1f7e:      	movl	$0x4, %esi
    1f83:      	callq	*%rax
    1f85:      	movq	(%rsp), %rax
    1f89:      	leaq	0xb8(%rax), %rdi
    1f90:      	leaq	0x24(%rbp), %rdx
    1f94:      	movl	$0x4, %ecx
    1f99:      	movl	$0x4, %eax
    1f9e:      	movl	$0x4, %esi
    1fa3:      	callq	*%rax
    1fa5:      	movq	(%rsp), %rax
    1fa9:      	movl	$0x0, 0xc0(%rax)
    1fb3:      	movq	(%rsp), %rax
    1fb7:      	leaq	0xbc(%rax), %rdi
    1fbe:      	leaq	0x28(%rbp), %rdx
    1fc2:      	movl	$0x4, %ecx
    1fc7:      	movl	$0x4, %eax
    1fcc:      	movl	$0x4, %esi
    1fd1:      	callq	*%rax
    1fd3:      	movq	(%rsp), %rax
    1fd7:      	leaq	0xcc(%rax), %rdi
    1fde:      	leaq	0x40(%rbp), %rdx
    1fe2:      	movl	$0x8, %ecx
    1fe7:      	movl	$0x4, %eax
    1fec:      	movl	$0x8, %esi
    1ff1:      	callq	*%rax
    1ff3:      	movq	(%rsp), %rax
    1ff7:      	leaq	0xd4(%rax), %rdi
    1ffe:      	leaq	0x30(%rbp), %rdx
    2002:      	movl	$0x8, %ecx
    2007:      	movl	$0x4, %eax
    200c:      	movl	$0x8, %esi
    2011:      	callq	*%rax
    2013:      	leaq	0x38(%rbp), %rdx
    2017:      	movl	$0x8, %ecx
    201c:      	movl	$0x4, %eax
    2021:      	movq	%r13, %rdi
    2024:      	movl	$0x8, %esi
    2029:      	callq	*%rax
    202b:      	addq	$0x90, %rbp
    2032:      	leaq	0x30(%rsp), %rdi
    2037:      	movl	$0x8, %ecx
    203c:      	movl	$0x4, %eax
    2041:      	movl	$0x8, %esi
    2046:      	movq	%rbp, %rdx
    2049:      	callq	*%rax
    204b:      	movq	0x30(%rsp), %r13
    2050:      	leaq	0xc8(%r13), %rdx
    2057:      	movl	$0x4, %ecx
    205c:      	movl	$0x4, %eax
    2061:      	movq	%r12, %rdi
    2064:      	movl	$0x4, %esi
    2069:      	callq	*%rax
    206b:      	movq	(%rsp), %rax
    206f:      	leaq	0xe0(%rax), %rdi
    2076:      	leaq	0xcc(%r13), %rdx
    207d:      	movl	$0x4, %ecx
    2082:      	movl	$0x4, %eax
    2087:      	movl	$0x4, %esi
    208c:      	callq	*%rax
    208e:      	movq	(%rsp), %rax
    2092:      	leaq	0xe4(%rax), %rdi
    2099:      	leaq	0xd0(%r13), %rdx
    20a0:      	movl	$0x4, %ecx
    20a5:      	movl	$0x4, %eax
    20aa:      	movl	$0x4, %esi
    20af:      	callq	*%rax
    20b1:      	movq	(%rsp), %rdi
    20b5:      	addq	$0xe8, %rdi
    20bc:      	addq	$0x158, %r13            # imm = 0x158
    20c3:      	movl	$0x4, %ecx
    20c8:      	movl	$0x4, %eax
    20cd:      	movl	$0x4, %esi
    20d2:      	movq	%r13, %rdx
    20d5:      	movq	0x20(%rsp), %r13
    20da:      	callq	*%rax
    20dc:      	movq	(%rsp), %rcx
    20e0:      	movl	$0x50, %r12d
    20e6:      	jmp	0x148b <generic_retkprobe_event+0x148b>
    20eb:      	leaq	0xc8(%rbp), %rdx
    20f2:      	movl	$0x4, %ecx
    20f7:      	movl	$0x4, %eax
    20fc:      	movq	0x8(%rsp), %rdi
    2101:      	movl	$0x4, %esi
    2106:      	callq	*%rax
    2108:      	movq	(%rsp), %rax
    210c:      	leaq	0xa0(%rax), %rdi
    2113:      	leaq	0xcc(%rbp), %rdx
    211a:      	movl	$0x4, %ecx
    211f:      	movl	$0x4, %eax
    2124:      	movl	$0x4, %esi
    2129:      	callq	*%rax
    212b:      	movq	(%rsp), %rax
    212f:      	leaq	0xa4(%rax), %rdi
    2136:      	leaq	0xd0(%rbp), %rdx
    213d:      	movl	$0x4, %ecx
    2142:      	movl	$0x4, %eax
    2147:      	movl	$0x4, %esi
    214c:      	callq	*%rax
    214e:      	movq	(%rsp), %rdi
    2152:      	addq	$0xa8, %rdi
    2159:      	addq	$0x158, %rbp            # imm = 0x158
    2160:      	movl	$0x4, %ecx
    2165:      	movl	$0x4, %eax
    216a:      	movl	$0x4, %esi
    216f:      	movq	%rbp, %rdx
    2172:      	callq	*%rax
    2174:      	movq	(%rsp), %rcx
    2178:      	movl	$0x10, %r12d
    217e:      	jmp	0x148b <generic_retkprobe_event+0x148b>
    2183:      	leaq	0x38(%rbp), %rdx
    2187:      	movl	$0x4, %ecx
    218c:      	movl	$0x4, %eax
    2191:      	movq	0x8(%rsp), %rdi
    2196:      	movl	$0x4, %esi
    219b:      	callq	*%rax
    219d:      	movq	(%rsp), %rax
    21a1:      	leaq	0xa0(%rax), %rdi
    21a8:      	leaq	0x3c(%rbp), %rdx
    21ac:      	movl	$0x4, %ecx
    21b1:      	movl	$0x4, %eax
    21b6:      	movl	$0x4, %esi
    21bb:      	callq	*%rax
    21bd:      	movq	(%rsp), %rax
    21c1:      	leaq	0xa4(%rax), %rdi
    21c8:      	leaq	0x40(%rbp), %rdx
    21cc:      	movl	$0x4, %ecx
    21d1:      	movl	$0x4, %eax
    21d6:      	movl	$0x4, %esi
    21db:      	callq	*%rax
    21dd:      	movq	(%rsp), %rax
    21e1:      	leaq	0xa8(%rax), %rdi
    21e8:      	leaq	0x44(%rbp), %rdx
    21ec:      	movl	$0x4, %ecx
    21f1:      	movl	$0x4, %eax
    21f6:      	movl	$0x4, %esi
    21fb:      	callq	*%rax
    21fd:      	movq	(%rsp), %rdi
    2201:      	addq	$0xac, %rdi
    2208:      	subq	$-0x80, %rbp
    220c:      	movl	$0x10, %ecx
    2211:      	movl	$0x4, %eax
    2216:      	movl	$0x10, %esi
    221b:      	movq	%rbp, %rdx
    221e:      	callq	*%rax
    2220:      	movq	(%rsp), %rcx
    2224:      	movl	$0x20, %r12d
    222a:      	jmp	0x148b <generic_retkprobe_event+0x148b>
    222f:      	movl	$0x4, %ecx
    2234:      	movl	$0x4, %eax
    2239:      	movq	0x8(%rsp), %rdi
    223e:      	movl	$0x4, %esi
    2243:      	movq	%rbp, %rdx
    2246:      	callq	*%rax
    2248:      	movq	(%rsp), %rax
    224c:      	leaq	0xa0(%rax), %rdi
    2253:      	leaq	0x4(%rbp), %rdx
    2257:      	movl	$0x4, %ecx
    225c:      	movl	$0x4, %eax
    2261:      	movl	$0x4, %esi
    2266:      	callq	*%rax
    2268:      	movq	(%rsp), %rdi
    226c:      	addq	$0xa4, %rdi
    2273:      	addq	$0x30, %rbp
    2277:      	movl	$0x10, %ecx
    227c:      	movl	$0x4, %eax
    2281:      	movl	$0x10, %esi
    2286:      	movq	%rbp, %rdx
    2289:      	jmp	0x2327 <generic_retkprobe_event+0x2327>
    228e:      	leaq	0x4(%rbp), %rdx
    2292:      	leaq	0x30(%rsp), %rdi
    2297:      	movl	$0x4, %ecx
    229c:      	movl	$0x4, %eax
    22a1:      	movl	$0x4, %esi
    22a6:      	callq	*%rax
    22a8:      	movl	0x30(%rsp), %eax
    22ac:      	movq	(%rsp), %rcx
    22b0:      	movl	%eax, 0x9c(%rcx)
    22b6:      	leaq	0xc(%rbp), %rdx
    22ba:      	leaq	0x30(%rsp), %rdi
    22bf:      	movl	$0x4, %ecx
    22c4:      	movl	$0x4, %eax
    22c9:      	movl	$0x4, %esi
    22ce:      	callq	*%rax
    22d0:      	movl	0x30(%rsp), %eax
    22d4:      	movq	(%rsp), %rcx
    22d8:      	movl	%eax, 0xa0(%rcx)
    22de:      	addq	$0x50, %rbp
    22e2:      	leaq	0x30(%rsp), %rdi
    22e7:      	movl	$0x8, %ecx
    22ec:      	movl	$0x2d, %eax
    22f1:      	movl	$0x8, %esi
    22f6:      	movq	%rbp, %rdx
    22f9:      	callq	*%rax
    22fb:      	movq	(%rsp), %rdi
    22ff:      	addq	$0xa4, %rdi
    2306:      	movl	$0x3f8, %edx            # imm = 0x3F8
    230b:      	movq	0x30(%rsp), %rcx
    2310:      	addq	%rdx, %rcx
    2313:      	movl	$0x10, %esi
    2318:      	movl	$0x2d, %eax
    231d:      	addq	0x30(%rsp), %rdx
    2322:      	movl	$0x10, %esi
    2327:      	callq	*%rax
    2329:      	movq	(%rsp), %rcx
    232d:      	movl	$0x18, %r12d
    2333:      	jmp	0x148b <generic_retkprobe_event+0x148b>
    2338:      	movq	0x8(%rsp), %rax
    233d:      	movq	$0x0, 0x48(%rax)
    2345:      	movq	$0x0, 0x40(%rax)
    234d:      	movq	$0x0, 0x38(%rax)
    2355:      	movq	$0x0, 0x30(%rax)
    235d:      	movq	$0x0, 0x28(%rax)
    2365:      	movq	$0x0, 0x20(%rax)
    236d:      	movq	$0x0, 0x18(%rax)
    2375:      	movq	$0x0, 0x10(%rax)
    237d:      	movq	$0x0, 0x8(%rax)
    2385:      	movq	$0x0, (%rax)
    238c:      	leaq	0x30(%rsp), %rdi
    2391:      	movl	$0x8, %ecx
    2396:      	movl	$0x4, %eax
    239b:      	movl	$0x8, %esi
    23a0:      	movq	%rbp, %rdx
    23a3:      	callq	*%rax
    23a5:      	testq	%rax, %rax
    23a8:      	je	0x25ec <generic_retkprobe_event+0x25ec>
    23ae:      	xorl	%r12d, %r12d
    23b1:      	jmp	0x27bd <generic_retkprobe_event+0x27bd>
    23b6:      	movq	$0x0, 0x9c(%r14)
    23c1:      	movl	$0x8, %r12d
    23c7:      	jmp	0x1487 <generic_retkprobe_event+0x1487>
    23cc:      	movq	$-0x1, %r12
    23d3:      	movq	0x20(%rsp), %r13
    23d8:      	jmp	0x1487 <generic_retkprobe_event+0x1487>
    23dd:      	movq	0x30(%rsp), %r14
    23e2:      	movl	$0x0, 0x70(%rsp)
    23ea:      	movzwl	0x98(%rsp), %r12d
    23f3:      	movq	(%rip), %rdi            # 0x23fa <generic_retkprobe_event+0x23fa>
    23fa:      	leaq	0x70(%rsp), %rsi
    23ff:      	movl	$0x1, %eax
    2404:      	leaq	(%r14,%r12), %rcx
    2408:      	movq	%rcx, 0x80(%rsp)
    2410:      	callq	*%rax
    2412:      	testq	%rax, %rax
    2415:      	je	0x2ef9 <generic_retkprobe_event+0x2ef9>
    241b:      	movq	%rax, %r13
    241e:      	movw	%r12w, (%rax)
    2422:      	movb	$-0x1, 0x5(%rax)
    2426:      	movb	$0x0, 0x7(%rax)
    242a:      	movq	%rax, %rdi
    242d:      	addq	$0x6, %rdi
    2431:      	movq	0x80(%rsp), %rax
    2439:      	leaq	0x6(%rax), %rdx
    243d:      	movl	$0x1, %ecx
    2442:      	movl	$0x4, %eax
    2447:      	movq	%rdi, %r12
    244a:      	movl	$0x1, %esi
    244f:      	callq	*%rax
    2451:      	testq	%rax, %rax
    2454:      	js	0x2ef9 <generic_retkprobe_event+0x2ef9>
    245a:      	movzbl	0x5(%r13), %eax
    245f:      	cmpl	$0x32, %eax
    2462:      	jg	0x27d0 <generic_retkprobe_event+0x27d0>
    2468:      	testl	%eax, %eax
    246a:      	je	0x27f9 <generic_retkprobe_event+0x27f9>
    2470:      	cmpl	$0x2b, %eax
    2473:      	je	0x27f9 <generic_retkprobe_event+0x27f9>
    2479:      	cmpl	$0x2c, %eax
    247c:      	jne	0x29ab <generic_retkprobe_event+0x29ab>
    2482:      	movw	$0x8, 0x2(%r13)
    2489:      	movw	$0x8, %ax
    248d:      	jmp	0x28f9 <generic_retkprobe_event+0x28f9>
    2492:      	leaq	0x48(%r12), %rdx
    2497:      	movl	$0x10, %ecx
    249c:      	movl	$0x4, %eax
    24a1:      	movq	%rbp, %rdi
    24a4:      	movl	$0x10, %esi
    24a9:      	callq	*%rax
    24ab:      	leaq	0x38(%r12), %rdx
    24b0:      	movl	$0x10, %ecx
    24b5:      	movl	$0x4, %eax
    24ba:      	movq	%r13, %rdi
    24bd:      	movl	$0x10, %esi
    24c2:      	callq	*%rax
    24c4:      	movq	(%rsp), %r13
    24c8:      	leaq	0xbc(%r13), %rdi
    24cf:      	leaq	0xc(%r12), %r14
    24d4:      	addq	$0xe, %r12
    24d8:      	movl	$0x2, %ecx
    24dd:      	movl	$0x4, %eax
    24e2:      	movl	$0x2, %esi
    24e7:      	movq	%r12, %rdx
    24ea:      	callq	*%rax
    24ec:      	movq	%r13, %rdi
    24ef:      	addq	$0xbe, %rdi
    24f6:      	movl	$0x2, %ecx
    24fb:      	movl	$0x4, %eax
    2500:      	movl	$0x2, %esi
    2505:      	movq	%r14, %rdx
    2508:      	callq	*%rax
    250a:      	movzwl	0xbe(%r13), %eax
    2512:      	movbew	%ax, 0xbe(%r13)
    251c:      	movq	0x10(%rsp), %rax
    2521:      	movq	%rax, 0x30(%rsp)
    2526:      	movq	(%rip), %rdi            # 0x252d <generic_retkprobe_event+0x252d>
    252d:      	leaq	0x30(%rsp), %rsi
    2532:      	movl	$0x1, %eax
    2537:      	callq	*%rax
    2539:      	testq	%rax, %rax
    253c:      	je	0x2556 <generic_retkprobe_event+0x2556>
    253e:      	movl	(%rax), %ecx
    2540:      	movq	0x18(%rsp), %rbp
    2545:      	movl	%ecx, 0x10(%rbp)
    2548:      	movq	0x8(%rax), %rcx
    254c:      	movq	%rcx, 0x18(%rbp)
    2550:      	movl	0x4(%rax), %eax
    2553:      	movl	%eax, 0x7c(%rbp)
    2556:      	movl	$0x40, %r12d
    255c:      	movq	0x20(%rsp), %r13
    2561:      	jmp	0x1487 <generic_retkprobe_event+0x1487>
    2566:      	movl	$0xfffffffe, 0x9c(%r14) # imm = 0xFFFFFFFE
    2571:      	movl	$0x4, %r12d
    2577:      	movq	0x20(%rsp), %r13
    257c:      	jmp	0x1487 <generic_retkprobe_event+0x1487>
    2581:      	leaq	0xa4(%rcx), %rdi
    2588:      	leaq	0x8(%r12), %rdx
    258d:      	movq	%rcx, %r14
    2590:      	movl	$0x10, %ecx
    2595:      	movl	$0x4, %eax
    259a:      	movl	$0x10, %esi
    259f:      	callq	*%rax
    25a1:      	movq	%r14, %rdi
    25a4:      	addq	$0x9e, %rdi
    25ab:      	addq	$0x2, %r12
    25af:      	movl	$0x2, %ecx
    25b4:      	movl	$0x4, %eax
    25b9:      	movl	$0x2, %esi
    25be:      	movq	%r12, %rdx
    25c1:      	callq	*%rax
    25c3:      	movq	(%rsp), %rcx
    25c7:      	movzwl	0x9e(%rcx), %eax
    25ce:      	movbew	%ax, 0x9e(%rcx)
    25d7:      	movq	0x20(%rsp), %r13
    25dc:      	movq	0x18(%rsp), %r15
    25e1:      	movl	$0x18, %r12d
    25e7:      	jmp	0x148b <generic_retkprobe_event+0x148b>
    25ec:      	movq	(%rsp), %rax
    25f0:      	leaq	0xac(%rax), %rdi
    25f7:      	movq	0x30(%rsp), %rcx
    25fc:      	movl	$0x3f, %edx
    2601:      	movl	$0x2d, %eax
    2606:      	movq	0x30(%rsp), %rdx
    260b:      	movl	$0x3f, %esi
    2610:      	callq	*%rax
    2612:      	testq	%rax, %rax
    2615:      	js	0x23ae <generic_retkprobe_event+0x23ae>
    261b:      	leaq	0x8(%rbp), %rdx
    261f:      	leaq	0x70(%rsp), %rdi
    2624:      	movl	$0x8, %ecx
    2629:      	movl	$0x4, %eax
    262e:      	movl	$0x8, %esi
    2633:      	callq	*%rax
    2635:      	movq	(%rsp), %rdi
    2639:      	addq	$0xa4, %rdi
    2640:      	movl	$0x348, %edx            # imm = 0x348
    2645:      	movq	0x70(%rsp), %rcx
    264a:      	addq	%rdx, %rcx
    264d:      	movl	$0x8, %esi
    2652:      	movl	$0x4, %eax
    2657:      	addq	0x70(%rsp), %rdx
    265c:      	movl	$0x8, %esi
    2661:      	callq	*%rax
    2663:      	addq	$0x58, %rbp
    2667:      	leaq	0x70(%rsp), %rdi
    266c:      	movl	$0x4, %ecx
    2671:      	movl	$0x4, %eax
    2676:      	movl	$0x4, %esi
    267b:      	movq	%rbp, %rdx
    267e:      	callq	*%rax
    2680:      	movl	$0x50, %r12d
    2686:      	testq	%rax, %rax
    2689:      	jne	0x27bd <generic_retkprobe_event+0x27bd>
    268f:      	xorl	%eax, %eax
    2691:      	cmpl	$0x0, 0x70(%rsp)
    2696:      	setne	%al
    2699:      	movq	0x8(%rsp), %rcx
    269e:      	movl	%eax, (%rcx)
    26a0:      	jmp	0x27bd <generic_retkprobe_event+0x27bd>
    26a5:      	xorl	%r12d, %r12d
    26a8:      	jmp	0x1487 <generic_retkprobe_event+0x1487>
    26ad:      	addq	$0x3, %r12
    26b1:      	movl	$0x6b, %ecx
    26b6:      	movl	$0x71, %eax
    26bb:      	movl	$0x6b, %esi
    26c0:      	movq	%r12, %rdx
    26c3:      	callq	*%rax
    26c5:      	movq	%rax, %rcx
    26c8:      	movb	$0x6b, %al
    26ca:      	testl	%ecx, %ecx
    26cc:      	js	0x26d8 <generic_retkprobe_event+0x26d8>
    26ce:      	movq	(%rsp), %rcx
    26d2:      	movb	%al, 0x9f(%rcx)
    26d8:      	movl	$0x70, %r12d
    26de:      	movq	0x20(%rsp), %r13
    26e3:      	jmp	0x1487 <generic_retkprobe_event+0x1487>
    26e8:      	leaq	0x48(%r12), %rdx
    26ed:      	movl	$0x10, %ecx
    26f2:      	movl	$0x4, %eax
    26f7:      	movq	0x8(%rsp), %rdi
    26fc:      	movl	$0x10, %esi
    2701:      	callq	*%rax
    2703:      	leaq	0x38(%r12), %rdx
    2708:      	movl	$0x10, %ecx
    270d:      	movl	$0x4, %eax
    2712:      	movq	%r13, %rdi
    2715:      	movl	$0x10, %esi
    271a:      	callq	*%rax
    271c:      	movq	(%rsp), %r13
    2720:      	leaq	0xbc(%r13), %rdi
    2727:      	leaq	0xc(%r12), %r14
    272c:      	addq	$0xe, %r12
    2730:      	movl	$0x2, %ecx
    2735:      	movl	$0x4, %eax
    273a:      	movl	$0x2, %esi
    273f:      	movq	%r12, %rdx
    2742:      	callq	*%rax
    2744:      	movq	%r13, %rdi
    2747:      	addq	$0xbe, %rdi
    274e:      	movl	$0x2, %ecx
    2753:      	movl	$0x4, %eax
    2758:      	movl	$0x2, %esi
    275d:      	movq	%r14, %rdx
    2760:      	callq	*%rax
    2762:      	movzwl	0xbe(%r13), %eax
    276a:      	movbew	%ax, 0xbe(%r13)
    2774:      	movq	(%rsp), %rax
    2778:      	movq	0xc4(%rax), %rax
    277f:      	movq	%rax, 0x30(%rsp)
    2784:      	movq	(%rip), %rdi            # 0x278b <generic_retkprobe_event+0x278b>
    278b:      	leaq	0x30(%rsp), %rsi
    2790:      	movl	$0x1, %eax
    2795:      	callq	*%rax
    2797:      	testq	%rax, %rax
    279a:      	je	0x27b7 <generic_retkprobe_event+0x27b7>
    279c:      	movl	(%rax), %ecx
    279e:      	movq	0x80(%rsp), %rdx
    27a6:      	movl	%ecx, 0x10(%rdx)
    27a9:      	movq	0x8(%rax), %rcx
    27ad:      	movq	%rcx, 0x18(%rdx)
    27b1:      	movl	0x4(%rax), %eax
    27b4:      	movl	%eax, 0x7c(%rdx)
    27b7:      	movl	$0x40, %r12d
    27bd:      	movq	0x20(%rsp), %r13
    27c2:      	movq	(%rsp), %rcx
    27c6:      	movq	0x18(%rsp), %r15
    27cb:      	jmp	0x148b <generic_retkprobe_event+0x148b>
    27d0:      	cmpl	$0x33, %eax
    27d3:      	je	0x28e8 <generic_retkprobe_event+0x28e8>
    27d9:      	cmpl	$0x3c, %eax
    27dc:      	je	0x27f9 <generic_retkprobe_event+0x27f9>
    27de:      	cmpl	$0xff, %eax
    27e3:      	jne	0x29ab <generic_retkprobe_event+0x29ab>
    27e9:      	movw	$0x28, 0x2(%r13)
    27f0:      	movw	$0x28, %ax
    27f4:      	jmp	0x28f9 <generic_retkprobe_event+0x28f9>
    27f9:      	movzbl	0x7(%r13), %eax
    27fe:      	leal	0x8(,%rax,8), %eax
    2805:      	jmp	0x28f4 <generic_retkprobe_event+0x28f4>
    280a:      	xorl	%eax, %eax
    280c:      	movq	%rax, 0x8(%rsp)
    2811:      	cmpq	$0x3, 0x88(%rsp)
    281a:      	jne	0x282e <generic_retkprobe_event+0x282e>
    281c:      	movq	%rbp, %r13
    281f:      	movq	0x28(%rsp), %r14
    2824:      	movq	0x18(%rsp), %r15
    2829:      	jmp	0x428 <generic_retkprobe_event+0x428>
    282e:      	movq	0x90(%rsp), %rax
    2836:      	leaq	0x30(%rax), %rdx
    283a:      	leaq	0x30(%rsp), %rdi
    283f:      	movl	$0x4, %r12d
    2845:      	movl	$0x10, %ecx
    284a:      	movl	$0x4, %eax
    284f:      	movl	$0x10, %esi
    2854:      	callq	*%rax
    2856:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    285b:      	testl	%eax, %eax
    285d:      	js	0x326d <generic_retkprobe_event+0x326d>
    2863:      	movq	0x38(%rsp), %rdx
    2868:      	movq	0x8(%rsp), %rax
    286d:      	cmpq	%rax, %rdx
    2870:      	movq	%rax, %r13
    2873:      	cmovbq	%rdx, %r13
    2877:      	testq	%rax, %rax
    287a:      	cmovneq	%r13, %rdx
    287e:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2883:      	cmpq	$0xffe, %rdx            # imm = 0xFFE
    288a:      	ja	0x326d <generic_retkprobe_event+0x326d>
    2890:      	movq	%rdx, %r14
    2893:      	movq	%r15, %rdi
    2896:      	addq	(%rsp), %rdi
    289a:      	movq	%rdi, %r15
    289d:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    28a3:      	addq	0x18(%rsp), %rdi
    28a8:      	movq	0x30(%rsp), %rcx
    28ad:      	movl	$0x4, %eax
    28b2:      	movq	%rdx, %rsi
    28b5:      	movq	0x30(%rsp), %rdx
    28ba:      	callq	*%rax
    28bc:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    28c1:      	testl	%eax, %eax
    28c3:      	js	0x326d <generic_retkprobe_event+0x326d>
    28c9:      	addq	%r14, %rbp
    28cc:      	cmpq	$0x0, 0x8(%rsp)
    28d2:      	je	0x2c28 <generic_retkprobe_event+0x2c28>
    28d8:      	subq	%r13, 0x8(%rsp)
    28dd:      	jne	0x2c2f <generic_retkprobe_event+0x2c2f>
    28e3:      	jmp	0x281c <generic_retkprobe_event+0x281c>
    28e8:      	movzbl	0x7(%r13), %eax
    28ed:      	leal	0x8(,%rax,4), %eax
    28f4:      	movw	%ax, 0x2(%r13)
    28f9:      	addw	(%r13), %ax
    28fe:      	movw	%ax, (%r13)
    2903:      	movzbl	0x6(%r13), %ecx
    2908:      	cmpq	$0x3c, %rcx
    290c:      	ja	0x30f4 <generic_retkprobe_event+0x30f4>
    2912:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    291c:      	btq	%rcx, %rdx
    2920:      	jae	0x30f4 <generic_retkprobe_event+0x30f4>
    2926:      	movb	%cl, 0x5(%r13)
    292a:      	movzwl	%ax, %ecx
    292d:      	addq	%r14, %rcx
    2930:      	movl	$0x2, %edx
    2935:      	movl	$0x4, %eax
    293a:      	movq	%r12, %rdi
    293d:      	movzwl	(%r13), %edx
    2942:      	addq	%r14, %rdx
    2945:      	movl	$0x2, %esi
    294a:      	callq	*%rax
    294c:      	testq	%rax, %rax
    294f:      	js	0x2ef9 <generic_retkprobe_event+0x2ef9>
    2955:      	movzbl	0x5(%r13), %eax
    295a:      	cmpl	$0x32, %eax
    295d:      	jg	0x297a <generic_retkprobe_event+0x297a>
    295f:      	testl	%eax, %eax
    2961:      	je	0x2998 <generic_retkprobe_event+0x2998>
    2963:      	cmpl	$0x2b, %eax
    2966:      	je	0x2998 <generic_retkprobe_event+0x2998>
    2968:      	cmpl	$0x2c, %eax
    296b:      	jne	0x29c8 <generic_retkprobe_event+0x29c8>
    296d:      	movw	$0x8, 0x2(%r13)
    2974:      	movw	$0x8, %ax
    2978:      	jmp	0x29cd <generic_retkprobe_event+0x29cd>
    297a:      	cmpl	$0x33, %eax
    297d:      	je	0x29b5 <generic_retkprobe_event+0x29b5>
    297f:      	cmpl	$0x3c, %eax
    2982:      	je	0x2998 <generic_retkprobe_event+0x2998>
    2984:      	cmpl	$0xff, %eax
    2989:      	jne	0x29c8 <generic_retkprobe_event+0x29c8>
    298b:      	movw	$0x28, 0x2(%r13)
    2992:      	movw	$0x28, %ax
    2996:      	jmp	0x29cd <generic_retkprobe_event+0x29cd>
    2998:      	movzbl	0x7(%r13), %eax
    299d:      	leal	0x8(,%rax,8), %eax
    29a4:      	movw	%ax, 0x2(%r13)
    29a9:      	jmp	0x29cd <generic_retkprobe_event+0x29cd>
    29ab:      	movzwl	0x2(%r13), %eax
    29b0:      	jmp	0x28f9 <generic_retkprobe_event+0x28f9>
    29b5:      	movzbl	0x7(%r13), %eax
    29ba:      	leal	0x8(,%rax,4), %eax
    29c1:      	movw	%ax, 0x2(%r13)
    29c6:      	jmp	0x29cd <generic_retkprobe_event+0x29cd>
    29c8:      	movzwl	0x2(%r13), %eax
    29cd:      	addw	(%r13), %ax
    29d2:      	movw	%ax, (%r13)
    29d7:      	movzbl	0x6(%r13), %ecx
    29dc:      	cmpq	$0x3c, %rcx
    29e0:      	ja	0x30f4 <generic_retkprobe_event+0x30f4>
    29e6:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    29f0:      	btq	%rcx, %rdx
    29f4:      	jae	0x30f4 <generic_retkprobe_event+0x30f4>
    29fa:      	movb	%cl, 0x5(%r13)
    29fe:      	movzwl	%ax, %ecx
    2a01:      	addq	%r14, %rcx
    2a04:      	movl	$0x2, %edx
    2a09:      	movl	$0x4, %eax
    2a0e:      	movq	%r12, %rdi
    2a11:      	movzwl	(%r13), %edx
    2a16:      	addq	%r14, %rdx
    2a19:      	movl	$0x2, %esi
    2a1e:      	callq	*%rax
    2a20:      	testq	%rax, %rax
    2a23:      	js	0x2ef9 <generic_retkprobe_event+0x2ef9>
    2a29:      	movzbl	0x5(%r13), %eax
    2a2e:      	cmpl	$0x32, %eax
    2a31:      	jg	0x2a4e <generic_retkprobe_event+0x2a4e>
    2a33:      	testl	%eax, %eax
    2a35:      	je	0x2a6c <generic_retkprobe_event+0x2a6c>
    2a37:      	cmpl	$0x2b, %eax
    2a3a:      	je	0x2a6c <generic_retkprobe_event+0x2a6c>
    2a3c:      	cmpl	$0x2c, %eax
    2a3f:      	jne	0x2a92 <generic_retkprobe_event+0x2a92>
    2a41:      	movw	$0x8, 0x2(%r13)
    2a48:      	movw	$0x8, %ax
    2a4c:      	jmp	0x2a97 <generic_retkprobe_event+0x2a97>
    2a4e:      	cmpl	$0x33, %eax
    2a51:      	je	0x2a7f <generic_retkprobe_event+0x2a7f>
    2a53:      	cmpl	$0x3c, %eax
    2a56:      	je	0x2a6c <generic_retkprobe_event+0x2a6c>
    2a58:      	cmpl	$0xff, %eax
    2a5d:      	jne	0x2a92 <generic_retkprobe_event+0x2a92>
    2a5f:      	movw	$0x28, 0x2(%r13)
    2a66:      	movw	$0x28, %ax
    2a6a:      	jmp	0x2a97 <generic_retkprobe_event+0x2a97>
    2a6c:      	movzbl	0x7(%r13), %eax
    2a71:      	leal	0x8(,%rax,8), %eax
    2a78:      	movw	%ax, 0x2(%r13)
    2a7d:      	jmp	0x2a97 <generic_retkprobe_event+0x2a97>
    2a7f:      	movzbl	0x7(%r13), %eax
    2a84:      	leal	0x8(,%rax,4), %eax
    2a8b:      	movw	%ax, 0x2(%r13)
    2a90:      	jmp	0x2a97 <generic_retkprobe_event+0x2a97>
    2a92:      	movzwl	0x2(%r13), %eax
    2a97:      	addw	(%r13), %ax
    2a9c:      	movw	%ax, (%r13)
    2aa1:      	movzbl	0x6(%r13), %ecx
    2aa6:      	cmpq	$0x3c, %rcx
    2aaa:      	ja	0x30f4 <generic_retkprobe_event+0x30f4>
    2ab0:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2aba:      	btq	%rcx, %rdx
    2abe:      	jae	0x30f4 <generic_retkprobe_event+0x30f4>
    2ac4:      	movb	%cl, 0x5(%r13)
    2ac8:      	movzwl	%ax, %ecx
    2acb:      	addq	%r14, %rcx
    2ace:      	movl	$0x2, %edx
    2ad3:      	movl	$0x4, %eax
    2ad8:      	movq	%r12, %rdi
    2adb:      	movzwl	(%r13), %edx
    2ae0:      	addq	%r14, %rdx
    2ae3:      	movl	$0x2, %esi
    2ae8:      	callq	*%rax
    2aea:      	testq	%rax, %rax
    2aed:      	js	0x2ef9 <generic_retkprobe_event+0x2ef9>
    2af3:      	movzbl	0x5(%r13), %eax
    2af8:      	cmpl	$0x32, %eax
    2afb:      	jg	0x2b18 <generic_retkprobe_event+0x2b18>
    2afd:      	testl	%eax, %eax
    2aff:      	je	0x2b36 <generic_retkprobe_event+0x2b36>
    2b01:      	cmpl	$0x2b, %eax
    2b04:      	je	0x2b36 <generic_retkprobe_event+0x2b36>
    2b06:      	cmpl	$0x2c, %eax
    2b09:      	jne	0x2b5c <generic_retkprobe_event+0x2b5c>
    2b0b:      	movw	$0x8, 0x2(%r13)
    2b12:      	movw	$0x8, %ax
    2b16:      	jmp	0x2b61 <generic_retkprobe_event+0x2b61>
    2b18:      	cmpl	$0x33, %eax
    2b1b:      	je	0x2b49 <generic_retkprobe_event+0x2b49>
    2b1d:      	cmpl	$0x3c, %eax
    2b20:      	je	0x2b36 <generic_retkprobe_event+0x2b36>
    2b22:      	cmpl	$0xff, %eax
    2b27:      	jne	0x2b5c <generic_retkprobe_event+0x2b5c>
    2b29:      	movw	$0x28, 0x2(%r13)
    2b30:      	movw	$0x28, %ax
    2b34:      	jmp	0x2b61 <generic_retkprobe_event+0x2b61>
    2b36:      	movzbl	0x7(%r13), %eax
    2b3b:      	leal	0x8(,%rax,8), %eax
    2b42:      	movw	%ax, 0x2(%r13)
    2b47:      	jmp	0x2b61 <generic_retkprobe_event+0x2b61>
    2b49:      	movzbl	0x7(%r13), %eax
    2b4e:      	leal	0x8(,%rax,4), %eax
    2b55:      	movw	%ax, 0x2(%r13)
    2b5a:      	jmp	0x2b61 <generic_retkprobe_event+0x2b61>
    2b5c:      	movzwl	0x2(%r13), %eax
    2b61:      	addw	(%r13), %ax
    2b66:      	movw	%ax, (%r13)
    2b6b:      	movzbl	0x6(%r13), %ecx
    2b70:      	cmpq	$0x3c, %rcx
    2b74:      	ja	0x30f4 <generic_retkprobe_event+0x30f4>
    2b7a:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2b84:      	btq	%rcx, %rdx
    2b88:      	jae	0x30f4 <generic_retkprobe_event+0x30f4>
    2b8e:      	movb	%cl, 0x5(%r13)
    2b92:      	movzwl	%ax, %ecx
    2b95:      	addq	%r14, %rcx
    2b98:      	movl	$0x2, %edx
    2b9d:      	movl	$0x4, %eax
    2ba2:      	movq	%r12, %rdi
    2ba5:      	movzwl	(%r13), %edx
    2baa:      	addq	%r14, %rdx
    2bad:      	movl	$0x2, %esi
    2bb2:      	callq	*%rax
    2bb4:      	testq	%rax, %rax
    2bb7:      	js	0x2ef9 <generic_retkprobe_event+0x2ef9>
    2bbd:      	movzbl	0x5(%r13), %eax
    2bc2:      	cmpl	$0x32, %eax
    2bc5:      	jg	0x2be9 <generic_retkprobe_event+0x2be9>
    2bc7:      	testl	%eax, %eax
    2bc9:      	je	0x2c12 <generic_retkprobe_event+0x2c12>
    2bcb:      	cmpl	$0x2b, %eax
    2bce:      	je	0x2c12 <generic_retkprobe_event+0x2c12>
    2bd0:      	cmpl	$0x2c, %eax
    2bd3:      	jne	0x2d0d <generic_retkprobe_event+0x2d0d>
    2bd9:      	movw	$0x8, 0x2(%r13)
    2be0:      	movw	$0x8, %ax
    2be4:      	jmp	0x2d12 <generic_retkprobe_event+0x2d12>
    2be9:      	cmpl	$0x33, %eax
    2bec:      	je	0x2cfa <generic_retkprobe_event+0x2cfa>
    2bf2:      	cmpl	$0x3c, %eax
    2bf5:      	je	0x2c12 <generic_retkprobe_event+0x2c12>
    2bf7:      	cmpl	$0xff, %eax
    2bfc:      	jne	0x2d0d <generic_retkprobe_event+0x2d0d>
    2c02:      	movw	$0x28, 0x2(%r13)
    2c09:      	movw	$0x28, %ax
    2c0d:      	jmp	0x2d12 <generic_retkprobe_event+0x2d12>
    2c12:      	movzbl	0x7(%r13), %eax
    2c17:      	leal	0x8(,%rax,8), %eax
    2c1e:      	movw	%ax, 0x2(%r13)
    2c23:      	jmp	0x2d12 <generic_retkprobe_event+0x2d12>
    2c28:      	xorl	%eax, %eax
    2c2a:      	movq	%rax, 0x8(%rsp)
    2c2f:      	cmpq	$0x5, 0x88(%rsp)
    2c38:      	jb	0x281c <generic_retkprobe_event+0x281c>
    2c3e:      	movq	0x90(%rsp), %rax
    2c46:      	leaq	0x40(%rax), %rdx
    2c4a:      	leaq	0x30(%rsp), %rdi
    2c4f:      	movl	$0x4, %r12d
    2c55:      	movl	$0x10, %ecx
    2c5a:      	movl	$0x4, %eax
    2c5f:      	movl	$0x10, %esi
    2c64:      	callq	*%rax
    2c66:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2c6b:      	testl	%eax, %eax
    2c6d:      	js	0x326d <generic_retkprobe_event+0x326d>
    2c73:      	movq	0x38(%rsp), %rdx
    2c78:      	movq	0x8(%rsp), %rax
    2c7d:      	cmpq	%rax, %rdx
    2c80:      	movq	%rax, %r13
    2c83:      	cmovbq	%rdx, %r13
    2c87:      	testq	%rax, %rax
    2c8a:      	cmovneq	%r13, %rdx
    2c8e:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2c93:      	movq	%rdx, (%rsp)
    2c97:      	cmpq	$0xffe, %rdx            # imm = 0xFFE
    2c9e:      	ja	0x326d <generic_retkprobe_event+0x326d>
    2ca4:      	movq	%r14, %rdi
    2ca7:      	addq	%r15, %rdi
    2caa:      	movq	%rdi, %r14
    2cad:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2cb3:      	addq	0x18(%rsp), %rdi
    2cb8:      	movq	0x30(%rsp), %rcx
    2cbd:      	movl	$0x4, %eax
    2cc2:      	movq	(%rsp), %rsi
    2cc6:      	movq	0x30(%rsp), %rdx
    2ccb:      	callq	*%rax
    2ccd:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2cd2:      	testl	%eax, %eax
    2cd4:      	js	0x326d <generic_retkprobe_event+0x326d>
    2cda:      	addq	(%rsp), %rbp
    2cde:      	cmpq	$0x0, 0x8(%rsp)
    2ce4:      	je	0x3101 <generic_retkprobe_event+0x3101>
    2cea:      	subq	%r13, 0x8(%rsp)
    2cef:      	jne	0x3108 <generic_retkprobe_event+0x3108>
    2cf5:      	jmp	0x281c <generic_retkprobe_event+0x281c>
    2cfa:      	movzbl	0x7(%r13), %eax
    2cff:      	leal	0x8(,%rax,4), %eax
    2d06:      	movw	%ax, 0x2(%r13)
    2d0b:      	jmp	0x2d12 <generic_retkprobe_event+0x2d12>
    2d0d:      	movzwl	0x2(%r13), %eax
    2d12:      	addw	(%r13), %ax
    2d17:      	movw	%ax, (%r13)
    2d1c:      	movzbl	0x6(%r13), %ecx
    2d21:      	cmpq	$0x3c, %rcx
    2d25:      	ja	0x30f4 <generic_retkprobe_event+0x30f4>
    2d2b:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2d35:      	btq	%rcx, %rdx
    2d39:      	jae	0x30f4 <generic_retkprobe_event+0x30f4>
    2d3f:      	movb	%cl, 0x5(%r13)
    2d43:      	movzwl	%ax, %ecx
    2d46:      	addq	%r14, %rcx
    2d49:      	movl	$0x2, %edx
    2d4e:      	movl	$0x4, %eax
    2d53:      	movq	%r12, %rdi
    2d56:      	movzwl	(%r13), %edx
    2d5b:      	addq	%r14, %rdx
    2d5e:      	movl	$0x2, %esi
    2d63:      	callq	*%rax
    2d65:      	testq	%rax, %rax
    2d68:      	js	0x2ef9 <generic_retkprobe_event+0x2ef9>
    2d6e:      	movzbl	0x5(%r13), %eax
    2d73:      	cmpl	$0x32, %eax
    2d76:      	jg	0x2d93 <generic_retkprobe_event+0x2d93>
    2d78:      	testl	%eax, %eax
    2d7a:      	je	0x2db1 <generic_retkprobe_event+0x2db1>
    2d7c:      	cmpl	$0x2b, %eax
    2d7f:      	je	0x2db1 <generic_retkprobe_event+0x2db1>
    2d81:      	cmpl	$0x2c, %eax
    2d84:      	jne	0x2dd7 <generic_retkprobe_event+0x2dd7>
    2d86:      	movw	$0x8, 0x2(%r13)
    2d8d:      	movw	$0x8, %ax
    2d91:      	jmp	0x2ddc <generic_retkprobe_event+0x2ddc>
    2d93:      	cmpl	$0x33, %eax
    2d96:      	je	0x2dc4 <generic_retkprobe_event+0x2dc4>
    2d98:      	cmpl	$0x3c, %eax
    2d9b:      	je	0x2db1 <generic_retkprobe_event+0x2db1>
    2d9d:      	cmpl	$0xff, %eax
    2da2:      	jne	0x2dd7 <generic_retkprobe_event+0x2dd7>
    2da4:      	movw	$0x28, 0x2(%r13)
    2dab:      	movw	$0x28, %ax
    2daf:      	jmp	0x2ddc <generic_retkprobe_event+0x2ddc>
    2db1:      	movzbl	0x7(%r13), %eax
    2db6:      	leal	0x8(,%rax,8), %eax
    2dbd:      	movw	%ax, 0x2(%r13)
    2dc2:      	jmp	0x2ddc <generic_retkprobe_event+0x2ddc>
    2dc4:      	movzbl	0x7(%r13), %eax
    2dc9:      	leal	0x8(,%rax,4), %eax
    2dd0:      	movw	%ax, 0x2(%r13)
    2dd5:      	jmp	0x2ddc <generic_retkprobe_event+0x2ddc>
    2dd7:      	movzwl	0x2(%r13), %eax
    2ddc:      	addw	(%r13), %ax
    2de1:      	movw	%ax, (%r13)
    2de6:      	movzbl	0x6(%r13), %ecx
    2deb:      	cmpq	$0x3c, %rcx
    2def:      	ja	0x30f4 <generic_retkprobe_event+0x30f4>
    2df5:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2dff:      	btq	%rcx, %rdx
    2e03:      	jae	0x30f4 <generic_retkprobe_event+0x30f4>
    2e09:      	movb	%cl, 0x5(%r13)
    2e0d:      	movzwl	%ax, %ecx
    2e10:      	addq	%r14, %rcx
    2e13:      	movl	$0x2, %edx
    2e18:      	movl	$0x4, %eax
    2e1d:      	movq	%r12, %rdi
    2e20:      	movzwl	(%r13), %edx
    2e25:      	addq	%r14, %rdx
    2e28:      	movl	$0x2, %esi
    2e2d:      	callq	*%rax
    2e2f:      	testq	%rax, %rax
    2e32:      	js	0x2ef9 <generic_retkprobe_event+0x2ef9>
    2e38:      	movzbl	0x5(%r13), %eax
    2e3d:      	cmpl	$0x32, %eax
    2e40:      	jg	0x2e5d <generic_retkprobe_event+0x2e5d>
    2e42:      	testl	%eax, %eax
    2e44:      	je	0x2e7b <generic_retkprobe_event+0x2e7b>
    2e46:      	cmpl	$0x2b, %eax
    2e49:      	je	0x2e7b <generic_retkprobe_event+0x2e7b>
    2e4b:      	cmpl	$0x2c, %eax
    2e4e:      	jne	0x2ea1 <generic_retkprobe_event+0x2ea1>
    2e50:      	movw	$0x8, 0x2(%r13)
    2e57:      	movw	$0x8, %ax
    2e5b:      	jmp	0x2ea6 <generic_retkprobe_event+0x2ea6>
    2e5d:      	cmpl	$0x33, %eax
    2e60:      	je	0x2e8e <generic_retkprobe_event+0x2e8e>
    2e62:      	cmpl	$0x3c, %eax
    2e65:      	je	0x2e7b <generic_retkprobe_event+0x2e7b>
    2e67:      	cmpl	$0xff, %eax
    2e6c:      	jne	0x2ea1 <generic_retkprobe_event+0x2ea1>
    2e6e:      	movw	$0x28, 0x2(%r13)
    2e75:      	movw	$0x28, %ax
    2e79:      	jmp	0x2ea6 <generic_retkprobe_event+0x2ea6>
    2e7b:      	movzbl	0x7(%r13), %eax
    2e80:      	leal	0x8(,%rax,8), %eax
    2e87:      	movw	%ax, 0x2(%r13)
    2e8c:      	jmp	0x2ea6 <generic_retkprobe_event+0x2ea6>
    2e8e:      	movzbl	0x7(%r13), %eax
    2e93:      	leal	0x8(,%rax,4), %eax
    2e9a:      	movw	%ax, 0x2(%r13)
    2e9f:      	jmp	0x2ea6 <generic_retkprobe_event+0x2ea6>
    2ea1:      	movzwl	0x2(%r13), %eax
    2ea6:      	addw	(%r13), %ax
    2eab:      	movw	%ax, (%r13)
    2eb0:      	movzbl	0x6(%r13), %ecx
    2eb5:      	cmpq	$0x3c, %rcx
    2eb9:      	ja	0x30f4 <generic_retkprobe_event+0x30f4>
    2ebf:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2ec9:      	btq	%rcx, %rdx
    2ecd:      	jae	0x30f4 <generic_retkprobe_event+0x30f4>
    2ed3:      	movb	%cl, 0x5(%r13)
    2ed7:      	movzwl	%ax, %ecx
    2eda:      	addq	%r14, %rcx
    2edd:      	movl	$0x2, %edx
    2ee2:      	movl	$0x4, %eax
    2ee7:      	movzwl	(%r13), %edx
    2eec:      	addq	%r14, %rdx
    2eef:      	movq	%r12, %rdi
    2ef2:      	movl	$0x2, %esi
    2ef7:      	callq	*%rax
    2ef9:      	xorl	%ecx, %ecx
    2efb:      	movb	%cl, 0xc8(%rsp)
    2f02:      	movzbl	%cl, %eax
    2f05:      	movq	(%rsp), %r14
    2f09:      	movw	%ax, 0xc0(%r14)
    2f11:      	movw	$0xa, 0xc2(%r14)
    2f1b:      	movq	0x80(%rsp), %r12
    2f23:      	leaq	0x8(%r12), %rdx
    2f28:      	movl	$0x10, %ecx
    2f2d:      	movl	$0x4, %eax
    2f32:      	movq	%rbp, %rdi
    2f35:      	movl	$0x10, %esi
    2f3a:      	callq	*%rax
    2f3c:      	leaq	0xac(%r14), %rdi
    2f43:      	addq	$0x18, %r12
    2f47:      	movl	$0x10, %ecx
    2f4c:      	movl	$0x4, %eax
    2f51:      	movl	$0x10, %esi
    2f56:      	movq	%r12, %rdx
    2f59:      	callq	*%rax
    2f5b:      	movzbl	0xc8(%rsp), %eax
    2f63:      	cmpl	$0x11, %eax
    2f66:      	je	0x2fba <generic_retkprobe_event+0x2fba>
    2f68:      	cmpl	$0x6, %eax
    2f6b:      	jne	0x300a <generic_retkprobe_event+0x300a>
    2f71:      	movq	0x30(%rsp), %r14
    2f76:      	movzwl	0xd0(%rsp), %r12d
    2f7f:      	leaq	(%r14,%r12), %rdx
    2f83:      	movq	(%rsp), %r13
    2f87:      	leaq	0xbc(%r13), %rdi
    2f8e:      	movl	$0x2, %ecx
    2f93:      	movl	$0x4, %eax
    2f98:      	movl	$0x2, %esi
    2f9d:      	callq	*%rax
    2f9f:      	leaq	0xbe(%r13), %rdi
    2fa6:      	leaq	(%r14,%r12), %rdx
    2faa:      	addq	$0x2, %rdx
    2fae:      	movl	$0x2, %ecx
    2fb3:      	movl	$0x4, %eax
    2fb8:      	jmp	0x3001 <generic_retkprobe_event+0x3001>
    2fba:      	movq	0x30(%rsp), %r14
    2fbf:      	movzwl	0xd0(%rsp), %r12d
    2fc8:      	leaq	(%r14,%r12), %rdx
    2fcc:      	movq	(%rsp), %r13
    2fd0:      	leaq	0xbc(%r13), %rdi
    2fd7:      	movl	$0x2, %ecx
    2fdc:      	movl	$0x4, %eax
    2fe1:      	movl	$0x2, %esi
    2fe6:      	callq	*%rax
    2fe8:      	leaq	0xbe(%r13), %rdi
    2fef:      	leaq	(%r14,%r12), %rdx
    2ff3:      	addq	$0x2, %rdx
    2ff7:      	movl	$0x2, %ecx
    2ffc:      	movl	$0x4, %eax
    3001:      	movl	$0x2, %esi
    3006:      	callq	*%rax
    3008:      	jmp	0x3019 <generic_retkprobe_event+0x3019>
    300a:      	movq	(%rsp), %r13
    300e:      	movl	$0x0, 0xbc(%r13)
    3019:      	movzwl	0xbc(%r13), %eax
    3021:      	movzwl	0xbe(%r13), %ecx
    3029:      	movbew	%ax, 0xbc(%r13)
    3033:      	movbew	%cx, 0xbe(%r13)
    303d:      	movq	0x8(%rsp), %rdx
    3042:      	addq	$0xe0, %rdx
    3049:      	leaq	0x70(%rsp), %rdi
    304e:      	movl	$0x8, %ecx
    3053:      	movl	$0x4, %eax
    3058:      	movl	$0x4, %r14d
    305e:      	movl	$0x8, %esi
    3063:      	callq	*%rax
    3065:      	movq	0x70(%rsp), %rcx
    306a:      	testq	%rcx, %rcx
    306d:      	je	0x30df <generic_retkprobe_event+0x30df>
    306f:      	addq	$0x5, %rcx
    3073:      	leaq	0xa0(%rsp), %rdi
    307b:      	movl	$0x8, %edx
    3080:      	movl	$0x4, %eax
    3085:      	movq	0x70(%rsp), %rdx
    308a:      	addq	$0x5, %rdx
    308e:      	movl	$0x8, %esi
    3093:      	callq	*%rax
    3095:      	movq	0x70(%rsp), %r12
    309a:      	movq	0xa0(%rsp), %r13
    30a2:      	movq	(%rsp), %rbp
    30a6:      	leaq	0xd4(%rbp), %rdi
    30ad:      	leaq	(%r12,%r13,8), %rdx
    30b1:      	addq	$0x44, %rdx
    30b5:      	movl	$0x4, %eax
    30ba:      	movl	$0x4, %esi
    30bf:      	callq	*%rax
    30c1:      	movq	%rbp, %rdi
    30c4:      	addq	$0xd8, %rdi
    30cb:      	leaq	(%r12,%r13,8), %rdx
    30cf:      	addq	$0x45, %rdx
    30d3:      	movl	$0x4, %eax
    30d8:      	movl	$0x4, %esi
    30dd:      	callq	*%rax
    30df:      	movq	0x20(%rsp), %r13
    30e4:      	movq	0x18(%rsp), %r15
    30e9:      	movl	$0x40, %r12d
    30ef:      	jmp	0x1487 <generic_retkprobe_event+0x1487>
    30f4:      	movw	%ax, 0xd0(%rsp)
    30fc:      	jmp	0x2efb <generic_retkprobe_event+0x2efb>
    3101:      	xorl	%eax, %eax
    3103:      	movq	%rax, 0x8(%rsp)
    3108:      	cmpq	$0x5, 0x88(%rsp)
    3111:      	je	0x281c <generic_retkprobe_event+0x281c>
    3117:      	movq	0x90(%rsp), %rax
    311f:      	leaq	0x50(%rax), %rdx
    3123:      	leaq	0x30(%rsp), %rdi
    3128:      	movl	$0x4, %r12d
    312e:      	movl	$0x10, %ecx
    3133:      	movl	$0x4, %eax
    3138:      	movl	$0x10, %esi
    313d:      	callq	*%rax
    313f:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3144:      	testl	%eax, %eax
    3146:      	js	0x326d <generic_retkprobe_event+0x326d>
    314c:      	movq	0x38(%rsp), %r15
    3151:      	movq	0x8(%rsp), %rax
    3156:      	cmpq	%rax, %r15
    3159:      	movq	%rax, %r13
    315c:      	cmovbq	%r15, %r13
    3160:      	testq	%rax, %rax
    3163:      	cmovneq	%r13, %r15
    3167:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    316c:      	cmpq	$0xffe, %r15            # imm = 0xFFE
    3173:      	ja	0x326d <generic_retkprobe_event+0x326d>
    3179:      	movq	(%rsp), %rdi
    317d:      	addq	%r14, %rdi
    3180:      	movq	%rdi, %r14
    3183:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    3189:      	addq	0x18(%rsp), %rdi
    318e:      	movq	0x30(%rsp), %rcx
    3193:      	movl	$0x4, %eax
    3198:      	movq	0x30(%rsp), %rdx
    319d:      	movl	%r15d, %esi
    31a0:      	callq	*%rax
    31a2:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    31a7:      	testl	%eax, %eax
    31a9:      	js	0x326d <generic_retkprobe_event+0x326d>
    31af:      	addq	%r15, %rbp
    31b2:      	cmpq	$0x0, 0x8(%rsp)
    31b8:      	je	0x31c6 <generic_retkprobe_event+0x31c6>
    31ba:      	subq	%r13, 0x8(%rsp)
    31bf:      	jne	0x31cd <generic_retkprobe_event+0x31cd>
    31c1:      	jmp	0x281c <generic_retkprobe_event+0x281c>
    31c6:      	xorl	%eax, %eax
    31c8:      	movq	%rax, 0x8(%rsp)
    31cd:      	cmpq	$0x7, 0x88(%rsp)
    31d6:      	jb	0x281c <generic_retkprobe_event+0x281c>
    31dc:      	movq	0x90(%rsp), %rdx
    31e4:      	addq	$0x60, %rdx
    31e8:      	leaq	0x30(%rsp), %rdi
    31ed:      	movl	$0x4, %r12d
    31f3:      	movl	$0x10, %ecx
    31f8:      	movl	$0x4, %eax
    31fd:      	movl	$0x10, %esi
    3202:      	callq	*%rax
    3204:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3209:      	testl	%eax, %eax
    320b:      	js	0x326d <generic_retkprobe_event+0x326d>
    320d:      	movq	0x38(%rsp), %rax
    3212:      	movq	0x8(%rsp), %rcx
    3217:      	cmpq	%rcx, %rax
    321a:      	movq	%rcx, %r13
    321d:      	cmovbq	%rax, %r13
    3221:      	testq	%rcx, %rcx
    3224:      	cmoveq	%rax, %r13
    3228:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    322d:      	cmpq	$0xffe, %r13            # imm = 0xFFE
    3234:      	ja	0x326d <generic_retkprobe_event+0x326d>
    3236:      	addq	%r14, %r15
    3239:      	andl	$0x3fff, %r15d          # imm = 0x3FFF
    3240:      	addq	0x18(%rsp), %r15
    3245:      	movq	0x30(%rsp), %rcx
    324a:      	movl	$0x4, %eax
    324f:      	movq	0x30(%rsp), %rdx
    3254:      	movq	%r15, %rdi
    3257:      	movl	%r13d, %esi
    325a:      	callq	*%rax
    325c:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3261:      	testl	%eax, %eax
    3263:      	js	0x326d <generic_retkprobe_event+0x326d>
    3265:      	addq	%rbp, %r13
    3268:      	jmp	0x281f <generic_retkprobe_event+0x281f>
    326d:      	movq	0x28(%rsp), %r14
    3272:      	movq	0x18(%rsp), %rax
    3277:      	movl	%ecx, (%rax,%r14)
    327b:      	jmp	0x1b23 <generic_retkprobe_event+0x1b23>
