
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/katran/healthchecking_ipip.native.o:	file format elf64-x86-64

Disassembly of section tc:

0000000000000000 <healthcheck_encap>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x38, %rsp
       e:      	movq	%rdi, %rbx
      11:      	movl	0xa8(%rdi), %eax
      17:      	movl	%eax, 0x14(%rsp)
      1b:      	movl	$0x1, 0x10(%rsp)
      23:      	movl	$0x2, 0xc(%rsp)
      2b:      	movl	$0x0, 0x30(%rsp)
      33:      	movq	$0x0, 0x28(%rsp)
      3c:      	movq	$0x0, 0x20(%rsp)
      45:      	movq	$0x0, 0x18(%rsp)
      4e:      	movl	$0x0, 0x8(%rsp)
      56:      	movq	(%rip), %rdi            # 0x5d <healthcheck_encap+0x5d>
      5d:      	leaq	0x8(%rsp), %rsi
      62:      	movl	$0x1, %eax
      67:      	callq	*%rax
      69:      	movq	%rax, %r14
      6c:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
      71:      	testq	%r14, %r14
      74:      	je	0x16e <healthcheck_encap+0x16e>
      7a:      	cmpl	$0x0, 0xa8(%rbx)
      81:      	je	0xb6 <healthcheck_encap+0xb6>
      83:      	movq	(%rip), %rdi            # 0x8a <healthcheck_encap+0x8a>
      8a:      	leaq	0x14(%rsp), %rsi
      8f:      	movl	$0x1, %eax
      94:      	callq	*%rax
      96:      	testq	%rax, %rax
      99:      	je	0xbf <healthcheck_encap+0xbf>
      9b:      	cmpl	$0x5c3, 0x70(%rbx)      # imm = 0x5C3
      a2:      	jb	0xcd <healthcheck_encap+0xcd>
      a4:      	incq	0x8(%r14)
      a8:      	incq	0x18(%r14)
      ac:      	movl	$0x2, %eax
      b1:      	jmp	0x16e <healthcheck_encap+0x16e>
      b6:      	incq	0x10(%r14)
      ba:      	jmp	0x16e <healthcheck_encap+0x16e>
      bf:      	incq	0x10(%r14)
      c3:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
      c8:      	jmp	0x16e <healthcheck_encap+0x16e>
      cd:      	movq	%rax, %r12
      d0:      	movq	(%rip), %rdi            # 0xd7 <healthcheck_encap+0xd7>
      d7:      	leaq	0x10(%rsp), %rsi
      dc:      	movl	$0x1, %r13d
      e2:      	callq	*%r13
      e5:      	testq	%rax, %rax
      e8:      	je	0x132 <healthcheck_encap+0x132>
      ea:      	movq	%rax, %r15
      ed:      	movq	(%rip), %rdi            # 0xf4 <healthcheck_encap+0xf4>
      f4:      	leaq	0xc(%rsp), %rsi
      f9:      	callq	*%r13
      fc:      	testq	%rax, %rax
      ff:      	je	0x132 <healthcheck_encap+0x132>
     101:      	movb	$0x40, 0x2d(%rsp)
     106:      	movl	$0x0, 0xa8(%rbx)
     110:      	cmpb	$0x1, 0x10(%r12)
     116:      	jne	0x13d <healthcheck_encap+0x13d>
     118:      	movq	(%r12), %rcx
     11c:      	movq	0x8(%r12), %rdx
     121:      	movq	%rdx, 0x24(%rsp)
     126:      	movq	%rcx, 0x1c(%rsp)
     12b:      	movl	$0x1, %ecx
     130:      	jmp	0x14a <healthcheck_encap+0x14a>
     132:      	incq	0x8(%r14)
     136:      	movl	$0x2, %eax
     13b:      	jmp	0x16e <healthcheck_encap+0x16e>
     13d:      	movl	(%r12), %eax
     141:      	movl	%eax, 0x1c(%rsp)
     145:      	xorl	%ecx, %ecx
     147:      	movq	%r15, %rax
     14a:      	movl	(%rax), %ebp
     14c:      	incq	(%r14)
     14f:      	leaq	0x18(%rsp), %rsi
     154:      	movl	$0x15, %eax
     159:      	movq	%rbx, %rdi
     15c:      	movl	$0x1c, %edx
     161:      	callq	*%rax
     163:      	movl	$0x17, %eax
     168:      	movl	%ebp, %edi
     16a:      	xorl	%esi, %esi
     16c:      	callq	*%rax
     16e:      	addq	$0x38, %rsp
     172:      	popq	%rbx
     173:      	popq	%r12
     175:      	popq	%r13
     177:      	popq	%r14
     179:      	popq	%r15
     17b:      	popq	%rbp
     17c:      	retq
