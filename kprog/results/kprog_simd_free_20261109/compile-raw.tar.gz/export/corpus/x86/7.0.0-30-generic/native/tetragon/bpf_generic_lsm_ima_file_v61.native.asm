
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_generic_lsm_ima_file_v61.native.o:	file format elf64-x86-64

Disassembly of section lsm.s/generic_lsm_ima_file:

0000000000000000 <ima_file>:
       0:      	pushq	%rbx
       1:      	subq	$0x50, %rsp
       5:      	movq	(%rdi), %rbx
       8:      	movl	$0xe, %eax
       d:      	callq	*%rax
       f:      	movq	%rax, (%rsp)
      13:      	movq	(%rip), %rdi            # 0x1a <ima_file+0x1a>
      1a:      	movq	%rsp, %rsi
      1d:      	movl	$0x1, %eax
      22:      	callq	*%rax
      24:      	testq	%rax, %rax
      27:      	je	0x6a <ima_file+0x6a>
      29:      	cmpb	$0x1, (%rax)
      2c:      	jne	0x6a <ima_file+0x6a>
      2e:      	leaq	0x10(%rsp), %rsi
      33:      	movl	$0x40, %ecx
      38:      	movl	$0xc1, %eax
      3d:      	movq	%rbx, %rdi
      40:      	movl	$0x40, %edx
      45:      	callq	*%rax
      47:      	movb	%al, 0xf(%rsp)
      4b:      	movb	$0x2, 0xe(%rsp)
      50:      	movq	(%rip), %rdi            # 0x57 <ima_file+0x57>
      57:      	xorl	%ecx, %ecx
      59:      	movq	%rsp, %rsi
      5c:      	leaq	0xe(%rsp), %rdx
      61:      	movl	$0x2, %eax
      66:      	xorl	%ecx, %ecx
      68:      	callq	*%rax
      6a:      	xorl	%eax, %eax
      6c:      	addq	$0x50, %rsp
      70:      	popq	%rbx
      71:      	retq
