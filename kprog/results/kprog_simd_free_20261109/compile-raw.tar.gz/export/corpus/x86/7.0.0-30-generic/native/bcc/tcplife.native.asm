
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/bcc/tcplife.native.o:	file format elf64-x86-64

Disassembly of section tracepoint/sock/inet_sock_set_state:

0000000000000000 <inet_sock_set_state>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0xb8, %rsp
      11:      	movl	$0x0, 0x38(%rsp)
      19:      	movq	$0x0, 0x30(%rsp)
      22:      	movq	$0x0, 0x28(%rsp)
      2b:      	movq	$0x0, 0x98(%rsp)
      37:      	movq	$0x0, 0x90(%rsp)
      43:      	movq	$0x0, 0x88(%rsp)
      4f:      	movq	$0x0, 0x80(%rsp)
      5b:      	movq	$0x0, 0x78(%rsp)
      64:      	movq	$0x0, 0x70(%rsp)
      6d:      	movq	$0x0, 0x68(%rsp)
      76:      	movq	$0x0, 0x60(%rsp)
      7f:      	movq	$0x0, 0x58(%rsp)
      88:      	movq	$0x0, 0x50(%rsp)
      91:      	movq	%rdi, %rbx
      94:      	movq	$0x0, 0x48(%rsp)
      9d:      	movq	$0x0, 0x40(%rsp)
      a6:      	leaq	0x1e(%rdi), %rdx
      aa:      	movq	%rsp, %rdi
      ad:      	movl	$0x2, %esi
      b2:      	callq	0xb7 <inet_sock_set_state+0xb7>
      b7:      	cmpw	$0x6, (%rsp)
      bc:      	jne	0x5c2 <inet_sock_set_state+0x5c2>
      c2:      	leaq	0x1c(%rbx), %rdx
      c6:      	movq	%rsp, %rdi
      c9:      	movl	$0x2, %esi
      ce:      	callq	0xd3 <inet_sock_set_state+0xd3>
      d3:      	movzwl	(%rsp), %ebp
      d7:      	movq	(%rip), %rax            # 0xde <inet_sock_set_state+0xde>
      de:      	cmpw	$0x0, (%rax)
      e2:      	je	0xed <inet_sock_set_state+0xed>
      e4:      	cmpw	(%rax), %bp
      e7:      	jne	0x5c2 <inet_sock_set_state+0x5c2>
      ed:      	leaq	0x18(%rbx), %rdx
      f1:      	movq	%rsp, %rdi
      f4:      	movl	$0x2, %esi
      f9:      	callq	0xfe <inet_sock_set_state+0xfe>
      fe:      	movzwl	(%rsp), %r15d
     103:      	movq	(%rip), %rax            # 0x10a <inet_sock_set_state+0x10a>
     10a:      	cmpb	$0x0, (%rax)
     10d:      	je	0x1d7 <inet_sock_set_state+0x1d7>
     113:      	xorl	%eax, %eax
     115:      	movq	(%rip), %rcx            # 0x11c <inet_sock_set_state+0x11c>
     11c:      	cmpw	$0x0, (%rcx,%rax,2)
     121:      	je	0x5c2 <inet_sock_set_state+0x5c2>
     127:      	cmpw	(%rcx,%rax,2), %r15w
     12c:      	je	0x1d7 <inet_sock_set_state+0x1d7>
     132:      	cmpw	$0x0, 0x2(%rcx,%rax,2)
     138:      	je	0x5c2 <inet_sock_set_state+0x5c2>
     13e:      	cmpw	0x2(%rcx,%rax,2), %r15w
     144:      	je	0x1d7 <inet_sock_set_state+0x1d7>
     14a:      	cmpw	$0x0, 0x4(%rcx,%rax,2)
     150:      	je	0x5c2 <inet_sock_set_state+0x5c2>
     156:      	cmpw	0x4(%rcx,%rax,2), %r15w
     15c:      	je	0x1d7 <inet_sock_set_state+0x1d7>
     15e:      	cmpw	$0x0, 0x6(%rcx,%rax,2)
     164:      	je	0x5c2 <inet_sock_set_state+0x5c2>
     16a:      	cmpw	0x6(%rcx,%rax,2), %r15w
     170:      	je	0x1d7 <inet_sock_set_state+0x1d7>
     172:      	cmpw	$0x0, 0x8(%rcx,%rax,2)
     178:      	je	0x5c2 <inet_sock_set_state+0x5c2>
     17e:      	cmpw	0x8(%rcx,%rax,2), %r15w
     184:      	je	0x1d7 <inet_sock_set_state+0x1d7>
     186:      	cmpw	$0x0, 0xa(%rcx,%rax,2)
     18c:      	je	0x5c2 <inet_sock_set_state+0x5c2>
     192:      	cmpw	0xa(%rcx,%rax,2), %r15w
     198:      	je	0x1d7 <inet_sock_set_state+0x1d7>
     19a:      	cmpw	$0x0, 0xc(%rcx,%rax,2)
     1a0:      	je	0x5c2 <inet_sock_set_state+0x5c2>
     1a6:      	cmpw	0xc(%rcx,%rax,2), %r15w
     1ac:      	je	0x1d7 <inet_sock_set_state+0x1d7>
     1ae:      	cmpw	$0x0, 0xe(%rcx,%rax,2)
     1b4:      	je	0x5c2 <inet_sock_set_state+0x5c2>
     1ba:      	cmpw	0xe(%rcx,%rax,2), %r15w
     1c0:      	je	0x1d7 <inet_sock_set_state+0x1d7>
     1c2:      	addq	$0x8, %rax
     1c6:      	cmpq	$0x400, %rax            # imm = 0x400
     1cc:      	jne	0x11c <inet_sock_set_state+0x11c>
     1d2:      	jmp	0x5c2 <inet_sock_set_state+0x5c2>
     1d7:      	leaq	0x1a(%rbx), %rdx
     1db:      	movq	%rsp, %rdi
     1de:      	movl	$0x2, %esi
     1e3:      	callq	0x1e8 <inet_sock_set_state+0x1e8>
     1e8:      	movzwl	(%rsp), %r12d
     1ed:      	movq	(%rip), %rax            # 0x1f4 <inet_sock_set_state+0x1f4>
     1f4:      	cmpb	$0x0, (%rax)
     1f7:      	je	0x2c1 <inet_sock_set_state+0x2c1>
     1fd:      	xorl	%eax, %eax
     1ff:      	movq	(%rip), %rcx            # 0x206 <inet_sock_set_state+0x206>
     206:      	cmpw	$0x0, (%rcx,%rax,2)
     20b:      	je	0x5c2 <inet_sock_set_state+0x5c2>
     211:      	cmpw	(%rcx,%rax,2), %r12w
     216:      	je	0x2c1 <inet_sock_set_state+0x2c1>
     21c:      	cmpw	$0x0, 0x2(%rcx,%rax,2)
     222:      	je	0x5c2 <inet_sock_set_state+0x5c2>
     228:      	cmpw	0x2(%rcx,%rax,2), %r12w
     22e:      	je	0x2c1 <inet_sock_set_state+0x2c1>
     234:      	cmpw	$0x0, 0x4(%rcx,%rax,2)
     23a:      	je	0x5c2 <inet_sock_set_state+0x5c2>
     240:      	cmpw	0x4(%rcx,%rax,2), %r12w
     246:      	je	0x2c1 <inet_sock_set_state+0x2c1>
     248:      	cmpw	$0x0, 0x6(%rcx,%rax,2)
     24e:      	je	0x5c2 <inet_sock_set_state+0x5c2>
     254:      	cmpw	0x6(%rcx,%rax,2), %r12w
     25a:      	je	0x2c1 <inet_sock_set_state+0x2c1>
     25c:      	cmpw	$0x0, 0x8(%rcx,%rax,2)
     262:      	je	0x5c2 <inet_sock_set_state+0x5c2>
     268:      	cmpw	0x8(%rcx,%rax,2), %r12w
     26e:      	je	0x2c1 <inet_sock_set_state+0x2c1>
     270:      	cmpw	$0x0, 0xa(%rcx,%rax,2)
     276:      	je	0x5c2 <inet_sock_set_state+0x5c2>
     27c:      	cmpw	0xa(%rcx,%rax,2), %r12w
     282:      	je	0x2c1 <inet_sock_set_state+0x2c1>
     284:      	cmpw	$0x0, 0xc(%rcx,%rax,2)
     28a:      	je	0x5c2 <inet_sock_set_state+0x5c2>
     290:      	cmpw	0xc(%rcx,%rax,2), %r12w
     296:      	je	0x2c1 <inet_sock_set_state+0x2c1>
     298:      	cmpw	$0x0, 0xe(%rcx,%rax,2)
     29e:      	je	0x5c2 <inet_sock_set_state+0x5c2>
     2a4:      	cmpw	0xe(%rcx,%rax,2), %r12w
     2aa:      	je	0x2c1 <inet_sock_set_state+0x2c1>
     2ac:      	addq	$0x8, %rax
     2b0:      	cmpq	$0x400, %rax            # imm = 0x400
     2b6:      	jne	0x206 <inet_sock_set_state+0x206>
     2bc:      	jmp	0x5c2 <inet_sock_set_state+0x5c2>
     2c1:      	leaq	0x8(%rbx), %rdx
     2c5:      	leaq	0x18(%rsp), %rdi
     2ca:      	movl	$0x8, %esi
     2cf:      	callq	0x2d4 <inet_sock_set_state+0x2d4>
     2d4:      	leaq	0x14(%rbx), %r14
     2d8:      	movq	%rsp, %rdi
     2db:      	movl	$0x4, %esi
     2e0:      	movq	%r14, %rdx
     2e3:      	callq	0x2e8 <inet_sock_set_state+0x2e8>
     2e8:      	cmpl	$0x3, (%rsp)
     2ec:      	jg	0x310 <inet_sock_set_state+0x310>
     2ee:      	callq	0x2f3 <inet_sock_set_state+0x2f3>
     2f3:      	movq	%rax, 0x20(%rsp)
     2f8:      	movq	(%rip), %rdi            # 0x2ff <inet_sock_set_state+0x2ff>
     2ff:      	leaq	0x18(%rsp), %rsi
     304:      	leaq	0x20(%rsp), %rdx
     309:      	xorl	%ecx, %ecx
     30b:      	callq	0x310 <inet_sock_set_state+0x310>
     310:      	movq	%rsp, %rdi
     313:      	movl	$0x4, %esi
     318:      	movq	%r14, %rdx
     31b:      	callq	0x320 <inet_sock_set_state+0x320>
     320:      	cmpl	$0x2, (%rsp)
     324:      	je	0x33c <inet_sock_set_state+0x33c>
     326:      	movq	%rsp, %rdi
     329:      	movl	$0x4, %esi
     32e:      	movq	%r14, %rdx
     331:      	callq	0x336 <inet_sock_set_state+0x336>
     336:      	cmpl	$0x9, (%rsp)
     33a:      	jne	0x386 <inet_sock_set_state+0x386>
     33c:      	callq	0x341 <inet_sock_set_state+0x341>
     341:      	shrq	$0x20, %rax
     345:      	movq	(%rip), %rcx            # 0x34c <inet_sock_set_state+0x34c>
     34c:      	cmpl	$0x0, (%rcx)
     34f:      	je	0x35b <inet_sock_set_state+0x35b>
     351:      	movl	(%rcx), %ecx
     353:      	cmpl	%eax, %ecx
     355:      	jne	0x5c2 <inet_sock_set_state+0x5c2>
     35b:      	movl	%eax, 0x28(%rsp)
     35f:      	leaq	0x2c(%rsp), %rdi
     364:      	movl	$0x10, %esi
     369:      	callq	0x36e <inet_sock_set_state+0x36e>
     36e:      	movq	(%rip), %rdi            # 0x375 <inet_sock_set_state+0x375>
     375:      	leaq	0x18(%rsp), %rsi
     37a:      	leaq	0x28(%rsp), %rdx
     37f:      	xorl	%ecx, %ecx
     381:      	callq	0x386 <inet_sock_set_state+0x386>
     386:      	movq	%rsp, %rdi
     389:      	movl	$0x4, %esi
     38e:      	movq	%r14, %rdx
     391:      	callq	0x396 <inet_sock_set_state+0x396>
     396:      	cmpl	$0x7, (%rsp)
     39a:      	jne	0x5c2 <inet_sock_set_state+0x5c2>
     3a0:      	movq	(%rip), %rdi            # 0x3a7 <inet_sock_set_state+0x3a7>
     3a7:      	leaq	0x18(%rsp), %rsi
     3ac:      	callq	0x3b1 <inet_sock_set_state+0x3b1>
     3b1:      	testq	%rax, %rax
     3b4:      	je	0x5b1 <inet_sock_set_state+0x5b1>
     3ba:      	movq	%rax, %r14
     3bd:      	callq	0x3c2 <inet_sock_set_state+0x3c2>
     3c2:      	movq	%rax, 0x20(%rsp)
     3c7:      	subq	(%r14), %rax
     3ca:      	movl	$0x3e8, %ecx            # imm = 0x3E8
     3cf:      	xorl	%edx, %edx
     3d1:      	divq	%rcx
     3d4:      	movq	%rax, %r13
     3d7:      	movq	(%rip), %rdi            # 0x3de <inet_sock_set_state+0x3de>
     3de:      	leaq	0x18(%rsp), %rsi
     3e3:      	callq	0x3e8 <inet_sock_set_state+0x3e8>
     3e8:      	movq	%rax, %r14
     3eb:      	testq	%rax, %rax
     3ee:      	je	0x3f5 <inet_sock_set_state+0x3f5>
     3f0:      	movl	(%r14), %eax
     3f3:      	jmp	0x3fe <inet_sock_set_state+0x3fe>
     3f5:      	callq	0x3fa <inet_sock_set_state+0x3fa>
     3fa:      	shrq	$0x20, %rax
     3fe:      	movq	(%rip), %rcx            # 0x405 <inet_sock_set_state+0x405>
     405:      	cmpl	$0x0, (%rcx)
     408:      	je	0x412 <inet_sock_set_state+0x412>
     40a:      	cmpl	(%rcx), %eax
     40c:      	jne	0x5a0 <inet_sock_set_state+0x5a0>
     412:      	movq	%r13, 0xb0(%rsp)
     41a:      	movq	0x18(%rsp), %r13
     41f:      	leaq	0x718(%r13), %rdx
     426:      	movq	%rsp, %rdi
     429:      	movl	$0x8, %esi
     42e:      	movq	%rax, 0xa8(%rsp)
     436:      	callq	0x43b <inet_sock_set_state+0x43b>
     43b:      	movq	(%rsp), %rax
     43f:      	movq	%rax, 0xa0(%rsp)
     447:      	addq	$0x760, %r13            # imm = 0x760
     44e:      	movq	%rsp, %rdi
     451:      	movl	$0x8, %esi
     456:      	movq	%r13, %rdx
     459:      	callq	0x45e <inet_sock_set_state+0x45e>
     45e:      	movq	(%rsp), %rcx
     462:      	movq	0x20(%rsp), %rax
     467:      	movl	$0x3e8, %esi            # imm = 0x3E8
     46c:      	xorl	%edx, %edx
     46e:      	divq	%rsi
     471:      	movq	%rax, 0x60(%rsp)
     476:      	movq	0xb0(%rsp), %rax
     47e:      	movq	%rax, 0x68(%rsp)
     483:      	movq	0xa0(%rsp), %rax
     48b:      	movq	%rax, 0x70(%rsp)
     490:      	movq	%rcx, 0x78(%rsp)
     495:      	movq	0xa8(%rsp), %rax
     49d:      	movl	%eax, 0x80(%rsp)
     4a4:      	movw	%r15w, 0x84(%rsp)
     4ad:      	movw	%r12w, 0x86(%rsp)
     4b6:      	movw	%bp, 0x88(%rsp)
     4be:      	leaq	0x8a(%rsp), %rdi
     4c6:      	testq	%r14, %r14
     4c9:      	je	0x4de <inet_sock_set_state+0x4de>
     4cb:      	addq	$0x4, %r14
     4cf:      	movl	$0x10, %esi
     4d4:      	movq	%r14, %rdx
     4d7:      	callq	0x4dc <inet_sock_set_state+0x4dc>
     4dc:      	jmp	0x4e8 <inet_sock_set_state+0x4e8>
     4de:      	movl	$0x10, %esi
     4e3:      	callq	0x4e8 <inet_sock_set_state+0x4e8>
     4e8:      	leaq	0x50(%rsp), %r14
     4ed:      	cmpw	$0x2, %bp
     4f1:      	jne	0x537 <inet_sock_set_state+0x537>
     4f3:      	leaq	0x20(%rbx), %rdx
     4f7:      	movq	%rsp, %r15
     4fa:      	movq	%r15, %rdi
     4fd:      	movl	$0x4, %esi
     502:      	callq	0x507 <inet_sock_set_state+0x507>
     507:      	leaq	0x40(%rsp), %rdi
     50c:      	movl	$0x4, %esi
     511:      	movq	%r15, %rdx
     514:      	callq	0x519 <inet_sock_set_state+0x519>
     519:      	leaq	0x24(%rbx), %rdx
     51d:      	movq	%rsp, %r15
     520:      	movq	%r15, %rdi
     523:      	movl	$0x4, %esi
     528:      	callq	0x52d <inet_sock_set_state+0x52d>
     52d:      	movq	%r14, %rdi
     530:      	movl	$0x4, %esi
     535:      	jmp	0x579 <inet_sock_set_state+0x579>
     537:      	leaq	0x28(%rbx), %rdx
     53b:      	movq	%rsp, %r15
     53e:      	movq	%r15, %rdi
     541:      	movl	$0x10, %esi
     546:      	callq	0x54b <inet_sock_set_state+0x54b>
     54b:      	leaq	0x40(%rsp), %rdi
     550:      	movl	$0x10, %esi
     555:      	movq	%r15, %rdx
     558:      	callq	0x55d <inet_sock_set_state+0x55d>
     55d:      	leaq	0x38(%rbx), %rdx
     561:      	movq	%rsp, %r15
     564:      	movq	%r15, %rdi
     567:      	movl	$0x10, %esi
     56c:      	callq	0x571 <inet_sock_set_state+0x571>
     571:      	movq	%r14, %rdi
     574:      	movl	$0x10, %esi
     579:      	movq	%r15, %rdx
     57c:      	callq	0x581 <inet_sock_set_state+0x581>
     581:      	movq	(%rip), %rsi            # 0x588 <inet_sock_set_state+0x588>
     588:      	leaq	0x40(%rsp), %rcx
     58d:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     592:      	movl	$0x60, %r8d
     598:      	movq	%rbx, %rdi
     59b:      	callq	0x5a0 <inet_sock_set_state+0x5a0>
     5a0:      	movq	(%rip), %rdi            # 0x5a7 <inet_sock_set_state+0x5a7>
     5a7:      	leaq	0x18(%rsp), %rsi
     5ac:      	callq	0x5b1 <inet_sock_set_state+0x5b1>
     5b1:      	movq	(%rip), %rdi            # 0x5b8 <inet_sock_set_state+0x5b8>
     5b8:      	leaq	0x18(%rsp), %rsi
     5bd:      	callq	0x5c2 <inet_sock_set_state+0x5c2>
     5c2:      	xorl	%eax, %eax
     5c4:      	addq	$0xb8, %rsp
     5cb:      	popq	%rbx
     5cc:      	popq	%r12
     5ce:      	popq	%r13
     5d0:      	popq	%r14
     5d2:      	popq	%r15
     5d4:      	popq	%rbp
     5d5:      	retq
