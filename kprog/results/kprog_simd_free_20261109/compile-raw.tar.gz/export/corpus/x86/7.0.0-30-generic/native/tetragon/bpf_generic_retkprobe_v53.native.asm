
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_generic_retkprobe_v53.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <native_bpf_strncasestr>:
       0:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
       5:      	testq	%rdx, %rdx
       8:      	je	0x74 <native_bpf_strncasestr+0x74>
       a:      	pushq	%rbx
       b:      	xorl	%ecx, %ecx
       d:      	jmp	0x1b <native_bpf_strncasestr+0x1b>
       f:      	nop
      10:      	incq	%rcx
      13:      	incq	%rdi
      16:      	cmpq	%rdx, %rcx
      19:      	je	0x73 <native_bpf_strncasestr+0x73>
      1b:      	xorl	%r8d, %r8d
      1e:      	nop
      20:      	leaq	(%rcx,%r8), %r9
      24:      	cmpq	%rdx, %r9
      27:      	jae	0x10 <native_bpf_strncasestr+0x10>
      29:      	movsbl	(%rsi,%r8), %r9d
      2e:      	testl	%r9d, %r9d
      31:      	je	0x71 <native_bpf_strncasestr+0x71>
      33:      	movsbl	(%rdi,%r8), %r10d
      38:      	leal	-0x41(%r10), %r11d
      3c:      	movl	%r10d, %ebx
      3f:      	orl	$0x20, %ebx
      42:      	cmpl	$0x1a, %r11d
      46:      	cmovael	%r10d, %ebx
      4a:      	leal	-0x41(%r9), %r10d
      4e:      	movl	%r9d, %r11d
      51:      	orl	$0x20, %r11d
      55:      	cmpl	$0x1a, %r10d
      59:      	cmovael	%r9d, %r11d
      5d:      	cmpl	%r11d, %ebx
      60:      	jne	0x10 <native_bpf_strncasestr+0x10>
      62:      	leaq	0x1(%r8), %r9
      66:      	cmpq	$0x63, %r8
      6a:      	movq	%r9, %r8
      6d:      	jb	0x20 <native_bpf_strncasestr+0x20>
      6f:      	jmp	0x10 <native_bpf_strncasestr+0x10>
      71:      	movl	%ecx, %eax
      73:      	popq	%rbx
      74:      	retq

Disassembly of section kprobe:

0000000000000000 <generic_retkprobe_filter_arg>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0xb8, %rsp
      11:      	movq	%rdi, %r12
      14:      	movl	$0x0, 0xa4(%rsp)
      1f:      	movq	(%rip), %rdi            # 0x26 <generic_retkprobe_filter_arg+0x26>
      26:      	leaq	0xa4(%rsp), %rsi
      2e:      	movl	$0x1, %eax
      33:      	callq	*%rax
      35:      	testq	%rax, %rax
      38:      	je	0x17a <generic_retkprobe_filter_arg+0x17a>
      3e:      	movq	%rax, %r14
      41:      	movl	0x5f00(%rax), %ebx
      47:      	leaq	0x5ef8(%rax), %rsi
      4e:      	movq	(%rip), %rdi            # 0x55 <generic_retkprobe_filter_arg+0x55>
      55:      	movl	$0x1, %eax
      5a:      	callq	*%rax
      5c:      	testq	%rax, %rax
      5f:      	je	0x15f <generic_retkprobe_filter_arg+0x15f>
      65:      	cmpb	$0x0, 0x5ee0(%r14)
      6d:      	je	0x15f <generic_retkprobe_filter_arg+0x15f>
      73:      	movq	%rax, %rdi
      76:      	movl	%ebx, %eax
      78:      	andl	$0x7, %eax
      7b:      	cmpb	$0x0, 0x5ec1(%r14,%rax)
      84:      	je	0xb8 <generic_retkprobe_filter_arg+0xb8>
      86:      	movl	%eax, %eax
      88:      	movl	0x4(%rdi,%rax,4), %ecx
      8c:      	leaq	(%rcx,%rax,4), %r11
      90:      	addq	$0x8, %r11
      94:      	movl	%r11d, %r9d
      97:      	andl	$0x3ff, %r9d            # imm = 0x3FF
      9e:      	cmpl	$0x19, (%rdi,%r9)
      a3:      	jae	0x104 <generic_retkprobe_filter_arg+0x104>
      a5:      	cmpq	$0x1, %r9
      a9:      	je	0x15f <generic_retkprobe_filter_arg+0x15f>
      af:      	testl	%r9d, %r9d
      b2:      	jne	0x13d <generic_retkprobe_filter_arg+0x13d>
      b8:      	cmpl	$0x1, %ebx
      bb:      	jg	0xd9 <generic_retkprobe_filter_arg+0xd9>
      bd:      	cmpl	$-0x1, %ebx
      c0:      	je	0x18e <generic_retkprobe_filter_arg+0x18e>
      c6:      	testl	%ebx, %ebx
      c8:      	je	0x19a <generic_retkprobe_filter_arg+0x19a>
      ce:      	cmpl	$0x1, %ebx
      d1:      	je	0x1a9 <generic_retkprobe_filter_arg+0x1a9>
      d7:      	jmp	0xf4 <generic_retkprobe_filter_arg+0xf4>
      d9:      	cmpl	$0x2, %ebx
      dc:      	je	0x1b8 <generic_retkprobe_filter_arg+0x1b8>
      e2:      	cmpl	$0x3, %ebx
      e5:      	je	0x1c7 <generic_retkprobe_filter_arg+0x1c7>
      eb:      	cmpl	$0x4, %ebx
      ee:      	je	0x1d6 <generic_retkprobe_filter_arg+0x1d6>
      f4:      	cmpl	$0x4, %ebx
      f7:      	jg	0x207 <generic_retkprobe_filter_arg+0x207>
      fd:      	incl	%ebx
      ff:      	jmp	0x1e5 <generic_retkprobe_filter_arg+0x1e5>
     104:      	leaq	(%rdi,%r9), %rax
     108:      	movq	%rax, 0xb0(%rsp)
     110:      	xorl	%r13d, %r13d
     113:      	leaq	0x70(%rsp), %rax
     118:      	movq	%rax, 0x30(%rsp)
     11d:      	movq	%rbx, 0xa8(%rsp)
     125:      	movq	%rdi, (%rsp)
     129:      	movq	%r9, 0x8(%rsp)
     12e:      	movq	%r11, 0x10(%rsp)
     133:      	movq	%r12, 0x68(%rsp)
     138:      	jmp	0x283 <generic_retkprobe_filter_arg+0x283>
     13d:      	movl	%r9d, 0x5f04(%r14)
     144:      	movq	(%rip), %rsi            # 0x14b <generic_retkprobe_filter_arg+0x14b>
     14b:      	movl	$0x4, %ecx
     150:      	movl	$0xc, %eax
     155:      	movq	%r12, %rdi
     158:      	movl	$0x4, %edx
     15d:      	callq	*%rax
     15f:      	movq	(%rip), %rsi            # 0x166 <generic_retkprobe_filter_arg+0x166>
     166:      	movl	$0x5, %ecx
     16b:      	movl	$0xc, %eax
     170:      	movq	%r12, %rdi
     173:      	movl	$0x5, %edx
     178:      	callq	*%rax
     17a:      	xorl	%eax, %eax
     17c:      	addq	$0xb8, %rsp
     183:      	popq	%rbx
     184:      	popq	%r12
     186:      	popq	%r13
     188:      	popq	%r14
     18a:      	popq	%r15
     18c:      	popq	%rbp
     18d:      	retq
     18e:      	xorl	%ebx, %ebx
     190:      	cmpb	$0x0, 0x5ec1(%r14)
     198:      	jne	0x1e5 <generic_retkprobe_filter_arg+0x1e5>
     19a:      	movl	$0x1, %ebx
     19f:      	cmpb	$0x0, 0x5ec2(%r14)
     1a7:      	jne	0x1e5 <generic_retkprobe_filter_arg+0x1e5>
     1a9:      	movl	$0x2, %ebx
     1ae:      	cmpb	$0x0, 0x5ec3(%r14)
     1b6:      	jne	0x1e5 <generic_retkprobe_filter_arg+0x1e5>
     1b8:      	movl	$0x3, %ebx
     1bd:      	cmpb	$0x0, 0x5ec4(%r14)
     1c5:      	jne	0x1e5 <generic_retkprobe_filter_arg+0x1e5>
     1c7:      	movl	$0x4, %ebx
     1cc:      	cmpb	$0x0, 0x5ec5(%r14)
     1d4:      	jne	0x1e5 <generic_retkprobe_filter_arg+0x1e5>
     1d6:      	movl	$0x5, %ebx
     1db:      	cmpb	$0x0, 0x5ec6(%r14)
     1e3:      	je	0x207 <generic_retkprobe_filter_arg+0x207>
     1e5:      	movl	%ebx, 0x5f00(%r14)
     1ec:      	movq	(%rip), %rsi            # 0x1f3 <generic_retkprobe_filter_arg+0x1f3>
     1f3:      	movl	$0x3, %ecx
     1f8:      	movl	$0xc, %eax
     1fd:      	movq	%r12, %rdi
     200:      	movl	$0x3, %edx
     205:      	callq	*%rax
     207:      	movq	0x60(%r14), %rbx
     20b:      	movl	$0xe, %eax
     210:      	callq	*%rax
     212:      	movq	%rbx, 0x38(%rsp)
     217:      	movq	%rax, 0x40(%rsp)
     21c:      	movq	(%rip), %rdi            # 0x223 <generic_retkprobe_filter_arg+0x223>
     223:      	leaq	0x38(%rsp), %rsi
     228:      	movl	$0x1, %eax
     22d:      	callq	*%rax
     22f:      	testq	%rax, %rax
     232:      	je	0x17a <generic_retkprobe_filter_arg+0x17a>
     238:      	movq	(%rip), %rdi            # 0x23f <generic_retkprobe_filter_arg+0x23f>
     23f:      	leaq	0x38(%rsp), %rsi
     244:      	movl	$0x3, %eax
     249:      	callq	*%rax
     24b:      	jmp	0x17a <generic_retkprobe_filter_arg+0x17a>
     250:      	xorl	%ebx, %ebx
     252:      	movq	(%rsp), %rdi
     256:      	movq	0x8(%rsp), %r9
     25b:      	movq	0x10(%rsp), %r11
     260:      	movq	0x68(%rsp), %r12
     265:      	testq	%rbx, %rbx
     268:      	movq	0xa8(%rsp), %rbx
     270:      	je	0xb8 <generic_retkprobe_filter_arg+0xb8>
     276:      	incq	%r13
     279:      	cmpq	$0x5, %r13
     27d:      	je	0xa5 <generic_retkprobe_filter_arg+0xa5>
     283:      	movq	0xb0(%rsp), %rax
     28b:      	movl	0x4(%rax,%r13,4), %r15d
     290:      	testl	$0x3ff, %r15d           # imm = 0x3FF
     297:      	je	0xa5 <generic_retkprobe_filter_arg+0xa5>
     29d:      	addl	%r11d, %r15d
     2a0:      	andl	$0x3ff, %r15d           # imm = 0x3FF
     2a7:      	movl	0x4(%rdi,%r15), %eax
     2ac:      	cmpl	$0x23, %eax
     2af:      	je	0xb8 <generic_retkprobe_filter_arg+0xb8>
     2b5:      	addq	%rdi, %r15
     2b8:      	movl	(%r15), %ecx
     2bb:      	cmpq	$0x4, %rcx
     2bf:      	ja	0xb8 <generic_retkprobe_filter_arg+0xb8>
     2c5:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
     2ce:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
     2d4:      	movq	0x5e78(%r14,%rcx,8), %rcx
     2dc:      	andl	$0x7ff, %ecx            # imm = 0x7FF
     2e2:      	leaq	(%r14,%rcx), %rbp
     2e6:      	addq	$0x90, %rbp
     2ed:      	movl	0xc(%r15), %ecx
     2f1:      	cmpl	$0x10, %ecx
     2f4:      	jle	0x350 <generic_retkprobe_filter_arg+0x350>
     2f6:      	leal	-0x1c(%rcx), %edx
     2f9:      	cmpl	$0x9, %edx
     2fc:      	jb	0x541 <generic_retkprobe_filter_arg+0x541>
     302:      	cmpl	$0x2a, %ecx
     305:      	ja	0x341 <generic_retkprobe_filter_arg+0x341>
     307:      	movl	%ecx, %edx
     309:      	movabsq	$0xc000000000, %rsi     # imm = 0xC000000000
     313:      	btq	%rdx, %rsi
     317:      	jb	0x379 <generic_retkprobe_filter_arg+0x379>
     319:      	movabsq	$0x30000000000, %rsi    # imm = 0x30000000000
     323:      	btq	%rdx, %rsi
     327:      	jb	0x89c <generic_retkprobe_filter_arg+0x89c>
     32d:      	movabsq	$0x42000000000, %rsi    # imm = 0x42000000000
     337:      	btq	%rdx, %rsi
     33b:      	jb	0x3cc <generic_retkprobe_filter_arg+0x3cc>
     341:      	cmpl	$0x11, %ecx
     344:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
     34a:      	addq	$0x4, %rbp
     34e:      	jmp	0x3cc <generic_retkprobe_filter_arg+0x3cc>
     350:      	cmpl	$0x6, %ecx
     353:      	jg	0x3b4 <generic_retkprobe_filter_arg+0x3b4>
     355:      	cmpl	$0x3, %ecx
     358:      	jle	0x4f3 <generic_retkprobe_filter_arg+0x4f3>
     35e:      	cmpl	$0x4, %ecx
     361:      	je	0x541 <generic_retkprobe_filter_arg+0x541>
     367:      	cmpl	$0x5, %ecx
     36a:      	je	0x89c <generic_retkprobe_filter_arg+0x89c>
     370:      	cmpl	$0x6, %ecx
     373:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
     379:      	movq	%rbp, %rsi
     37c:      	movl	(%rbp), %ebp
     37f:      	addq	$0x4, %rsi
     383:      	cmpl	$0x19, %eax
     386:      	jg	0x6c6 <generic_retkprobe_filter_arg+0x6c6>
     38c:      	leal	-0x3(%rax), %ecx
     38f:      	cmpl	$0x2, %ecx
     392:      	jb	0xf07 <generic_retkprobe_filter_arg+0xf07>
     398:      	cmpl	$0x8, %eax
     39b:      	je	0xe67 <generic_retkprobe_filter_arg+0xe67>
     3a1:      	movl	$0x0, %ebx
     3a6:      	cmpl	$0x9, %eax
     3a9:      	je	0x6e6 <generic_retkprobe_filter_arg+0x6e6>
     3af:      	jmp	0x2c6b <generic_retkprobe_filter_arg+0x2c6b>
     3b4:      	leal	-0xa(%rcx), %edx
     3b7:      	cmpl	$0x4, %edx
     3ba:      	jb	0x541 <generic_retkprobe_filter_arg+0x541>
     3c0:      	leal	-0xf(%rcx), %edx
     3c3:      	cmpl	$0x2, %edx
     3c6:      	jae	0x893 <generic_retkprobe_filter_arg+0x893>
     3cc:      	movq	%rbp, 0x20(%rsp)
     3d1:      	movl	(%rbp), %ebp
     3d4:      	movl	%eax, %ecx
     3d6:      	andl	$-0x2, %ecx
     3d9:      	cmpl	$0x24, %ecx
     3dc:      	je	0x3e6 <generic_retkprobe_filter_arg+0x3e6>
     3de:      	testl	%ebp, %ebp
     3e0:      	je	0xb8 <generic_retkprobe_filter_arg+0xb8>
     3e6:      	cmpl	$0x25, %eax
     3e9:      	movq	0x20(%rsp), %rsi
     3ee:      	ja	0x829 <generic_retkprobe_filter_arg+0x829>
     3f4:      	movl	%eax, %ecx
     3f6:      	movl	$0x4000100, %edx        # imm = 0x4000100
     3fb:      	btq	%rcx, %rdx
     3ff:      	jb	0xb9d <generic_retkprobe_filter_arg+0xb9d>
     405:      	movl	$0x8000200, %edx        # imm = 0x8000200
     40a:      	btq	%rcx, %rdx
     40e:      	jb	0xa5b <generic_retkprobe_filter_arg+0xa5b>
     414:      	movabsq	$0x3000000000, %rdx     # imm = 0x3000000000
     41e:      	btq	%rcx, %rdx
     422:      	jae	0x829 <generic_retkprobe_filter_arg+0x829>
     428:      	movw	$0x0, 0x38(%rsp)
     42f:      	cmpl	$0x1fe, %ebp            # imm = 0x1FE
     435:      	ja	0x845 <generic_retkprobe_filter_arg+0x845>
     43b:      	leaq	(%rsi,%rbp), %rcx
     43f:      	addq	$0x8, %rcx
     443:      	movl	$0x4, %eax
     448:      	leaq	0x38(%rsp), %rdi
     44d:      	movl	$0x2, %edx
     452:      	movl	(%rsi), %ecx
     454:      	leaq	(%rsi,%rcx), %rdx
     458:      	addq	$0x8, %rdx
     45c:      	movl	$0x2, %esi
     461:      	callq	*%rax
     463:      	movl	0x10(%r15), %ecx
     467:      	testl	%ecx, %ecx
     469:      	je	0x2aa6 <generic_retkprobe_filter_arg+0x2aa6>
     46f:      	movzwl	0x38(%rsp), %eax
     474:      	andl	$0xf000, %eax           # imm = 0xF000
     479:      	movl	$0x1, %ebx
     47e:      	cmpl	%eax, %ecx
     480:      	je	0x2aa8 <generic_retkprobe_filter_arg+0x2aa8>
     486:      	movl	0x8(%r15), %ecx
     48a:      	cmpl	$0xd, %ecx
     48d:      	movq	(%rsp), %rdi
     491:      	movq	0x8(%rsp), %r9
     496:      	movq	0x10(%rsp), %r11
     49b:      	jb	0x845 <generic_retkprobe_filter_arg+0x845>
     4a1:      	movl	0x14(%r15), %edx
     4a5:      	testl	%edx, %edx
     4a7:      	je	0x845 <generic_retkprobe_filter_arg+0x845>
     4ad:      	cmpl	%eax, %edx
     4af:      	je	0x2ab6 <generic_retkprobe_filter_arg+0x2ab6>
     4b5:      	cmpl	$0x11, %ecx
     4b8:      	jb	0x845 <generic_retkprobe_filter_arg+0x845>
     4be:      	movl	0x18(%r15), %edx
     4c2:      	testl	%edx, %edx
     4c4:      	je	0x845 <generic_retkprobe_filter_arg+0x845>
     4ca:      	cmpl	%eax, %edx
     4cc:      	je	0x2ab6 <generic_retkprobe_filter_arg+0x2ab6>
     4d2:      	cmpl	$0x15, %ecx
     4d5:      	jb	0x2aa6 <generic_retkprobe_filter_arg+0x2aa6>
     4db:      	movl	0x1c(%r15), %ecx
     4df:      	testl	%ecx, %ecx
     4e1:      	je	0x2aa6 <generic_retkprobe_filter_arg+0x2aa6>
     4e7:      	xorl	%ebx, %ebx
     4e9:      	cmpl	%eax, %ecx
     4eb:      	sete	%bl
     4ee:      	jmp	0x2aa8 <generic_retkprobe_filter_arg+0x2aa8>
     4f3:      	cmpl	$0x1, %ecx
     4f6:      	je	0x541 <generic_retkprobe_filter_arg+0x541>
     4f8:      	cmpl	$0x2, %ecx
     4fb:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
     501:      	movq	%rbp, %rsi
     504:      	movl	0x4(%rbp), %ebp
     507:      	addq	$0x8, %rsi
     50b:      	cmpl	$0x19, %eax
     50e:      	jg	0xf81 <generic_retkprobe_filter_arg+0xf81>
     514:      	leal	-0x3(%rax), %ecx
     517:      	cmpl	$0x2, %ecx
     51a:      	jb	0x1754 <generic_retkprobe_filter_arg+0x1754>
     520:      	movq	%rsi, 0x20(%rsp)
     525:      	cmpl	$0x8, %eax
     528:      	je	0x16c0 <generic_retkprobe_filter_arg+0x16c0>
     52e:      	movl	$0x0, %ebx
     533:      	cmpl	$0x9, %eax
     536:      	je	0xfa6 <generic_retkprobe_filter_arg+0xfa6>
     53c:      	jmp	0x2ef2 <generic_retkprobe_filter_arg+0x2ef2>
     541:      	cmpl	$0xb, %ecx
     544:      	jle	0x5d3 <generic_retkprobe_filter_arg+0x5d3>
     54a:      	cmpl	$0x24, %ecx
     54d:      	ja	0x61a <generic_retkprobe_filter_arg+0x61a>
     553:      	movl	%ecx, %edx
     555:      	movabsq	$0x1e00000000, %rsi     # imm = 0x1E00000000
     55f:      	btq	%rdx, %rsi
     563:      	jb	0x5ee <generic_retkprobe_filter_arg+0x5ee>
     569:      	movl	$0x60000000, %esi       # imm = 0x60000000
     56e:      	btq	%rdx, %rsi
     572:      	jb	0x84c <generic_retkprobe_filter_arg+0x84c>
     578:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
     582:      	btq	%rdx, %rsi
     586:      	jae	0x61a <generic_retkprobe_filter_arg+0x61a>
     58c:      	cmpl	$0x20, %eax
     58f:      	ja	0xb8 <generic_retkprobe_filter_arg+0xb8>
     595:      	movl	%eax, %ecx
     597:      	movl	$0x101e, %edx           # imm = 0x101E
     59c:      	btq	%rcx, %rdx
     5a0:      	jae	0x10ef <generic_retkprobe_filter_arg+0x10ef>
     5a6:      	movl	0x10(%r15), %ecx
     5aa:      	cmpl	$0x2, %eax
     5ad:      	jle	0x157c <generic_retkprobe_filter_arg+0x157c>
     5b3:      	leal	-0x3(%rax), %edx
     5b6:      	cmpl	$0x2, %edx
     5b9:      	jae	0x1b2c <generic_retkprobe_filter_arg+0x1b2c>
     5bf:      	movq	%rbp, %rdx
     5c2:      	movzbl	(%rbp), %edx
     5c6:      	cmpl	%edx, %ecx
     5c8:      	jne	0x1e23 <generic_retkprobe_filter_arg+0x1e23>
     5ce:      	jmp	0x2e81 <generic_retkprobe_filter_arg+0x2e81>
     5d3:      	leal	-0xa(%rcx), %edx
     5d6:      	cmpl	$0x2, %edx
     5d9:      	jb	0x95f <generic_retkprobe_filter_arg+0x95f>
     5df:      	cmpl	$0x1, %ecx
     5e2:      	je	0x626 <generic_retkprobe_filter_arg+0x626>
     5e4:      	cmpl	$0x4, %ecx
     5e7:      	je	0x626 <generic_retkprobe_filter_arg+0x626>
     5e9:      	jmp	0x276 <generic_retkprobe_filter_arg+0x276>
     5ee:      	cmpl	$0x9, %eax
     5f1:      	jle	0x912 <generic_retkprobe_filter_arg+0x912>
     5f7:      	cmpl	$0x1d, %eax
     5fa:      	jg	0xd40 <generic_retkprobe_filter_arg+0xd40>
     600:      	leal	-0xa(%rax), %edx
     603:      	cmpl	$0x2, %edx
     606:      	jb	0x9ec <generic_retkprobe_filter_arg+0x9ec>
     60c:      	cmpl	$0xc, %eax
     60f:      	je	0x975 <generic_retkprobe_filter_arg+0x975>
     615:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
     61a:      	leal	-0xc(%rcx), %edx
     61d:      	cmpl	$0x2, %edx
     620:      	jae	0x956 <generic_retkprobe_filter_arg+0x956>
     626:      	cmpl	$0x20, %eax
     629:      	ja	0xb8 <generic_retkprobe_filter_arg+0xb8>
     62f:      	movl	%eax, %edx
     631:      	movl	$0x101e, %esi           # imm = 0x101E
     636:      	btq	%rdx, %rsi
     63a:      	jae	0x663 <generic_retkprobe_filter_arg+0x663>
     63c:      	movl	0x10(%r15), %edx
     640:      	cmpl	$0x2, %eax
     643:      	jle	0x91f <generic_retkprobe_filter_arg+0x91f>
     649:      	leal	-0x3(%rax), %esi
     64c:      	cmpl	$0x2, %esi
     64f:      	jae	0x10d8 <generic_retkprobe_filter_arg+0x10d8>
     655:      	cmpl	%edx, (%rbp)
     658:      	jne	0x2062 <generic_retkprobe_filter_arg+0x2062>
     65e:      	jmp	0x2e81 <generic_retkprobe_filter_arg+0x2e81>
     663:      	movl	$0xc00, %esi            # imm = 0xC00
     668:      	btq	%rdx, %rsi
     66c:      	jb	0xc3c <generic_retkprobe_filter_arg+0xc3c>
     672:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
     67c:      	btq	%rdx, %rsi
     680:      	jae	0xb8 <generic_retkprobe_filter_arg+0xb8>
     686:      	cmpl	$0x1f, %eax
     689:      	jne	0x1227 <generic_retkprobe_filter_arg+0x1227>
     68f:      	movl	0x10(%r15), %esi
     693:      	movl	0x14(%r15), %edx
     697:      	cmpl	$0xc, %ecx
     69a:      	ja	0x1eb9 <generic_retkprobe_filter_arg+0x1eb9>
     6a0:      	movl	$0x1402, %eax           # imm = 0x1402
     6a5:      	btl	%ecx, %eax
     6a8:      	jae	0x1eb9 <generic_retkprobe_filter_arg+0x1eb9>
     6ae:      	movl	(%rbp), %eax
     6b1:      	cmpl	%eax, %esi
     6b3:      	jg	0x1ec8 <generic_retkprobe_filter_arg+0x1ec8>
     6b9:      	cmpl	%edx, %eax
     6bb:      	jle	0x276 <generic_retkprobe_filter_arg+0x276>
     6c1:      	jmp	0x1ec8 <generic_retkprobe_filter_arg+0x1ec8>
     6c6:      	cmpl	$0x20, %eax
     6c9:      	jg	0xd86 <generic_retkprobe_filter_arg+0xd86>
     6cf:      	cmpl	$0x1a, %eax
     6d2:      	je	0xe67 <generic_retkprobe_filter_arg+0xe67>
     6d8:      	movl	$0x0, %ebx
     6dd:      	cmpl	$0x1b, %eax
     6e0:      	jne	0x2c6b <generic_retkprobe_filter_arg+0x2c6b>
     6e6:      	movq	%rsi, 0x20(%rsp)
     6eb:      	movl	0x10(%r15), %eax
     6ef:      	movl	%eax, 0x38(%rsp)
     6f3:      	movl	$0x0, 0x70(%rsp)
     6fb:      	movl	$0x1, %eax
     700:      	leaq	0x38(%rsp), %rsi
     705:      	movq	(%rip), %rdi            # 0x70c <generic_retkprobe_filter_arg+0x70c>
     70c:      	callq	*%rax
     70e:      	testl	%ebp, %ebp
     710:      	je	0x2c5b <generic_retkprobe_filter_arg+0x2c5b>
     716:      	movl	$0x0, %ebx
     71b:      	testq	%rax, %rax
     71e:      	je	0x2c5d <generic_retkprobe_filter_arg+0x2c5d>
     724:      	movq	%rax, 0x18(%rsp)
     729:      	movl	$0x1, %eax
     72e:      	movq	0x30(%rsp), %rsi
     733:      	movq	(%rip), %rdi            # 0x73a <generic_retkprobe_filter_arg+0x73a>
     73a:      	callq	*%rax
     73c:      	testq	%rax, %rax
     73f:      	je	0x2c5b <generic_retkprobe_filter_arg+0x2c5b>
     745:      	movq	%rax, %rdi
     748:      	cmpl	$0x7f, %ebp
     74b:      	movl	$0x7f, %eax
     750:      	cmovbl	%ebp, %eax
     753:      	shll	$0x3, %eax
     756:      	movl	%eax, (%rdi)
     758:      	movq	%rbp, %rax
     75b:      	negq	%rax
     75e:      	movl	$0x3, %ecx
     763:      	subq	%rbp, %rcx
     766:      	leal	-0x4(%rbp), %edx
     769:      	movq	%rdi, 0x60(%rsp)
     76e:      	addq	$0x7, %rdi
     772:      	movl	$0x2, %r8d
     778:      	subq	%rbp, %r8
     77b:      	leal	-0x3(%rbp), %r9d
     77f:      	movl	$0x1, %r10d
     785:      	subq	%rbp, %r10
     788:      	leal	-0x2(%rbp), %r11d
     78c:      	decl	%ebp
     78e:      	xorl	%ebx, %ebx
     790:      	movq	0x20(%rsp), %rsi
     795:      	leal	(%rbx,%rbp), %r12d
     799:      	andl	$0xfff, %r12d           # imm = 0xFFF
     7a0:      	movzbl	(%rsi,%r12), %r12d
     7a5:      	movb	%r12b, -0x3(%rdi)
     7a9:      	cmpq	%rbx, %r10
     7ac:      	je	0x806 <generic_retkprobe_filter_arg+0x806>
     7ae:      	leal	(%r11,%rbx), %r12d
     7b2:      	andl	$0xfff, %r12d           # imm = 0xFFF
     7b9:      	movzbl	(%rsi,%r12), %r12d
     7be:      	movb	%r12b, -0x2(%rdi)
     7c2:      	cmpq	%rbx, %r8
     7c5:      	je	0x806 <generic_retkprobe_filter_arg+0x806>
     7c7:      	leal	(%r9,%rbx), %r12d
     7cb:      	andl	$0xfff, %r12d           # imm = 0xFFF
     7d2:      	movzbl	(%rsi,%r12), %r12d
     7d7:      	movb	%r12b, -0x1(%rdi)
     7db:      	cmpq	%rbx, %rcx
     7de:      	je	0x806 <generic_retkprobe_filter_arg+0x806>
     7e0:      	cmpq	$-0x7c, %rbx
     7e4:      	je	0x806 <generic_retkprobe_filter_arg+0x806>
     7e6:      	leal	(%rdx,%rbx), %r12d
     7ea:      	andl	$0xfff, %r12d           # imm = 0xFFF
     7f1:      	movzbl	(%rsi,%r12), %r12d
     7f6:      	movb	%r12b, (%rdi)
     7f9:      	addq	$-0x4, %rbx
     7fd:      	addq	$0x4, %rdi
     801:      	cmpq	%rbx, %rax
     804:      	jne	0x795 <generic_retkprobe_filter_arg+0x795>
     806:      	movl	$0x1, %eax
     80b:      	movq	0x18(%rsp), %rdi
     810:      	movq	0x60(%rsp), %rsi
     815:      	callq	*%rax
     817:      	xorl	%ebx, %ebx
     819:      	testq	%rax, %rax
     81c:      	setne	%bl
     81f:      	movq	0x68(%rsp), %r12
     824:      	jmp	0x2c5d <generic_retkprobe_filter_arg+0x2c5d>
     829:      	addl	$-0x3, %eax
     82c:      	cmpl	$0x2, %eax
     82f:      	jae	0x845 <generic_retkprobe_filter_arg+0x845>
     831:      	movl	$0x0, 0x70(%rsp)
     839:      	cmpl	$0x1fe, %ebp            # imm = 0x1FE
     83f:      	jbe	0x11d6 <generic_retkprobe_filter_arg+0x11d6>
     845:      	xorl	%ebx, %ebx
     847:      	jmp	0x2ab6 <generic_retkprobe_filter_arg+0x2ab6>
     84c:      	cmpl	$0x20, %eax
     84f:      	ja	0xb8 <generic_retkprobe_filter_arg+0xb8>
     855:      	movl	%eax, %ecx
     857:      	movl	$0x101e, %edx           # imm = 0x101E
     85c:      	btq	%rcx, %rdx
     860:      	jae	0x1121 <generic_retkprobe_filter_arg+0x1121>
     866:      	movl	0x10(%r15), %ecx
     86a:      	cmpl	$0x2, %eax
     86d:      	jle	0x159f <generic_retkprobe_filter_arg+0x159f>
     873:      	leal	-0x3(%rax), %edx
     876:      	cmpl	$0x2, %edx
     879:      	jae	0x1b46 <generic_retkprobe_filter_arg+0x1b46>
     87f:      	movq	%rbp, %rdx
     882:      	movzwl	(%rbp), %edx
     886:      	cmpl	%edx, %ecx
     888:      	jne	0x1e66 <generic_retkprobe_filter_arg+0x1e66>
     88e:      	jmp	0x2e81 <generic_retkprobe_filter_arg+0x2e81>
     893:      	cmpl	$0x7, %ecx
     896:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
     89c:      	movq	$0x0, 0x58(%rsp)
     8a5:      	movq	$0x0, 0x50(%rsp)
     8ae:      	movq	$0x0, 0x48(%rsp)
     8b7:      	movq	$0x0, 0x40(%rsp)
     8c0:      	movq	$0x0, 0x38(%rsp)
     8c9:      	cmpl	$0x27, %ecx
     8cc:      	jg	0x8f0 <generic_retkprobe_filter_arg+0x8f0>
     8ce:      	cmpl	$0x5, %ecx
     8d1:      	movq	%rbp, %rsi
     8d4:      	je	0xcbb <generic_retkprobe_filter_arg+0xcbb>
     8da:      	movq	%rsi, %rdx
     8dd:      	movl	$0x0, %ebx
     8e2:      	cmpl	$0x7, %ecx
     8e5:      	je	0xcbd <generic_retkprobe_filter_arg+0xcbd>
     8eb:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
     8f0:      	cmpl	$0x28, %ecx
     8f3:      	movq	%rbp, %rsi
     8f6:      	je	0xc93 <generic_retkprobe_filter_arg+0xc93>
     8fc:      	movq	%rsi, %rdx
     8ff:      	movl	$0x0, %ebx
     904:      	cmpl	$0x29, %ecx
     907:      	je	0xcbd <generic_retkprobe_filter_arg+0xcbd>
     90d:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
     912:      	leal	-0x1(%rax), %edx
     915:      	cmpl	$0x4, %edx
     918:      	jb	0x975 <generic_retkprobe_filter_arg+0x975>
     91a:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
     91f:      	cmpl	$0x1, %eax
     922:      	je	0x1382 <generic_retkprobe_filter_arg+0x1382>
     928:      	cmpl	$0x2, %eax
     92b:      	jne	0x2062 <generic_retkprobe_filter_arg+0x2062>
     931:      	cmpl	$0xc, %ecx
     934:      	ja	0x2059 <generic_retkprobe_filter_arg+0x2059>
     93a:      	movl	$0x1402, %esi           # imm = 0x1402
     93f:      	btl	%ecx, %esi
     942:      	jae	0x2059 <generic_retkprobe_filter_arg+0x2059>
     948:      	cmpl	%edx, (%rbp)
     94b:      	jl	0x276 <generic_retkprobe_filter_arg+0x276>
     951:      	jmp	0x2062 <generic_retkprobe_filter_arg+0x2062>
     956:      	cmpl	$0x1c, %ecx
     959:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
     95f:      	cmpl	$0x20, %eax
     962:      	ja	0xb8 <generic_retkprobe_filter_arg+0xb8>
     968:      	movl	%eax, %edx
     96a:      	movl	$0x101e, %esi           # imm = 0x101E
     96f:      	btq	%rdx, %rsi
     973:      	jae	0x999 <generic_retkprobe_filter_arg+0x999>
     975:      	movq	0x10(%r15), %rdx
     979:      	cmpl	$0x2, %eax
     97c:      	jle	0x9bd <generic_retkprobe_filter_arg+0x9bd>
     97e:      	leal	-0x3(%rax), %esi
     981:      	cmpl	$0x2, %esi
     984:      	jae	0xc7b <generic_retkprobe_filter_arg+0xc7b>
     98a:      	cmpq	%rdx, (%rbp)
     98e:      	jne	0x1ab0 <generic_retkprobe_filter_arg+0x1ab0>
     994:      	jmp	0x2e81 <generic_retkprobe_filter_arg+0x2e81>
     999:      	movl	$0xc00, %esi            # imm = 0xC00
     99e:      	btq	%rdx, %rsi
     9a2:      	jb	0x9ec <generic_retkprobe_filter_arg+0x9ec>
     9a4:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
     9ae:      	btq	%rdx, %rsi
     9b2:      	jb	0xd4c <generic_retkprobe_filter_arg+0xd4c>
     9b8:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
     9bd:      	cmpl	$0x1, %eax
     9c0:      	je	0x11b9 <generic_retkprobe_filter_arg+0x11b9>
     9c6:      	cmpl	$0x2, %eax
     9c9:      	jne	0x1ab0 <generic_retkprobe_filter_arg+0x1ab0>
     9cf:      	cmpl	$0xc, %ecx
     9d2:      	je	0x9dd <generic_retkprobe_filter_arg+0x9dd>
     9d4:      	cmpl	$0xa, %ecx
     9d7:      	jne	0x1aa6 <generic_retkprobe_filter_arg+0x1aa6>
     9dd:      	cmpq	%rdx, (%rbp)
     9e1:      	jl	0x276 <generic_retkprobe_filter_arg+0x276>
     9e7:      	jmp	0x1ab0 <generic_retkprobe_filter_arg+0x1ab0>
     9ec:      	movzbl	0x10(%r15), %eax
     9f1:      	movl	%eax, 0x70(%rsp)
     9f5:      	movl	$0x1, %eax
     9fa:      	movq	0x30(%rsp), %rsi
     9ff:      	movq	(%rip), %rdi            # 0xa06 <generic_retkprobe_filter_arg+0xa06>
     a06:      	callq	*%rax
     a08:      	testq	%rax, %rax
     a0b:      	je	0x166d <generic_retkprobe_filter_arg+0x166d>
     a11:      	movq	%rax, %rdi
     a14:      	movq	(%rbp), %rax
     a18:      	movq	%rax, 0x38(%rsp)
     a1d:      	movl	$0x1, %eax
     a22:      	leaq	0x38(%rsp), %rsi
     a27:      	callq	*%rax
     a29:      	movl	0x4(%r15), %ecx
     a2d:      	cmpl	$0xb, %ecx
     a30:      	je	0x169a <generic_retkprobe_filter_arg+0x169a>
     a36:      	cmpl	$0xa, %ecx
     a39:      	movq	(%rsp), %rdi
     a3d:      	movq	0x8(%rsp), %r9
     a42:      	movq	0x10(%rsp), %r11
     a47:      	jne	0x16b6 <generic_retkprobe_filter_arg+0x16b6>
     a4d:      	testq	%rax, %rax
     a50:      	setne	%al
     a53:      	movzbl	%al, %ebx
     a56:      	jmp	0x265 <generic_retkprobe_filter_arg+0x265>
     a5b:      	movl	0x10(%r15), %eax
     a5f:      	movl	%eax, 0x38(%rsp)
     a63:      	movl	$0x0, 0x70(%rsp)
     a6b:      	movl	$0x1, %eax
     a70:      	leaq	0x38(%rsp), %rsi
     a75:      	movq	(%rip), %rdi            # 0xa7c <generic_retkprobe_filter_arg+0xa7c>
     a7c:      	callq	*%rax
     a7e:      	testl	%ebp, %ebp
     a80:      	je	0x2aa6 <generic_retkprobe_filter_arg+0x2aa6>
     a86:      	movl	$0x0, %ebx
     a8b:      	testq	%rax, %rax
     a8e:      	je	0x2aa8 <generic_retkprobe_filter_arg+0x2aa8>
     a94:      	movq	%rax, 0x18(%rsp)
     a99:      	movl	$0x1, %eax
     a9e:      	movq	0x30(%rsp), %rsi
     aa3:      	movq	(%rip), %rdi            # 0xaaa <generic_retkprobe_filter_arg+0xaaa>
     aaa:      	callq	*%rax
     aac:      	testq	%rax, %rax
     aaf:      	je	0x2aa6 <generic_retkprobe_filter_arg+0x2aa6>
     ab5:      	movq	%rax, %rdi
     ab8:      	cmpl	$0x7f, %ebp
     abb:      	movl	$0x7f, %eax
     ac0:      	cmovbl	%ebp, %eax
     ac3:      	shll	$0x3, %eax
     ac6:      	movl	%eax, (%rdi)
     ac8:      	movq	%rbp, %rax
     acb:      	negq	%rax
     ace:      	movl	$0x3, %ecx
     ad3:      	subq	%rbp, %rcx
     ad6:      	leal	-0x4(%rbp), %edx
     ad9:      	movq	%rdi, 0x60(%rsp)
     ade:      	addq	$0x7, %rdi
     ae2:      	movl	$0x2, %r8d
     ae8:      	subq	%rbp, %r8
     aeb:      	leal	-0x3(%rbp), %r9d
     aef:      	movl	$0x1, %r10d
     af5:      	subq	%rbp, %r10
     af8:      	leal	-0x2(%rbp), %r11d
     afc:      	decl	%ebp
     afe:      	xorl	%ebx, %ebx
     b00:      	movq	0x20(%rsp), %rsi
     b05:      	leal	(%rbx,%rbp), %r12d
     b09:      	andl	$0xfff, %r12d           # imm = 0xFFF
     b10:      	movzbl	0x4(%rsi,%r12), %r12d
     b16:      	movb	%r12b, -0x3(%rdi)
     b1a:      	cmpq	%rbx, %r10
     b1d:      	je	0xb7a <generic_retkprobe_filter_arg+0xb7a>
     b1f:      	leal	(%r11,%rbx), %r12d
     b23:      	andl	$0xfff, %r12d           # imm = 0xFFF
     b2a:      	movzbl	0x4(%rsi,%r12), %r12d
     b30:      	movb	%r12b, -0x2(%rdi)
     b34:      	cmpq	%rbx, %r8
     b37:      	je	0xb7a <generic_retkprobe_filter_arg+0xb7a>
     b39:      	leal	(%r9,%rbx), %r12d
     b3d:      	andl	$0xfff, %r12d           # imm = 0xFFF
     b44:      	movzbl	0x4(%rsi,%r12), %r12d
     b4a:      	movb	%r12b, -0x1(%rdi)
     b4e:      	cmpq	%rbx, %rcx
     b51:      	je	0xb7a <generic_retkprobe_filter_arg+0xb7a>
     b53:      	cmpq	$-0x7c, %rbx
     b57:      	je	0xb7a <generic_retkprobe_filter_arg+0xb7a>
     b59:      	leal	(%rdx,%rbx), %r12d
     b5d:      	andl	$0xfff, %r12d           # imm = 0xFFF
     b64:      	movzbl	0x4(%rsi,%r12), %r12d
     b6a:      	movb	%r12b, (%rdi)
     b6d:      	addq	$-0x4, %rbx
     b71:      	addq	$0x4, %rdi
     b75:      	cmpq	%rbx, %rax
     b78:      	jne	0xb05 <generic_retkprobe_filter_arg+0xb05>
     b7a:      	movl	$0x1, %eax
     b7f:      	movq	0x18(%rsp), %rdi
     b84:      	movq	0x60(%rsp), %rsi
     b89:      	callq	*%rax
     b8b:      	xorl	%ebx, %ebx
     b8d:      	testq	%rax, %rax
     b90:      	setne	%bl
     b93:      	movq	0x68(%rsp), %r12
     b98:      	jmp	0x2aa8 <generic_retkprobe_filter_arg+0x2aa8>
     b9d:      	movl	0x10(%r15), %eax
     ba1:      	movl	%eax, 0x38(%rsp)
     ba5:      	movl	$0x0, 0x70(%rsp)
     bad:      	movl	$0x1, %eax
     bb2:      	leaq	0x38(%rsp), %rsi
     bb7:      	movq	(%rip), %rdi            # 0xbbe <generic_retkprobe_filter_arg+0xbbe>
     bbe:      	callq	*%rax
     bc0:      	testl	%ebp, %ebp
     bc2:      	je	0x2aa6 <generic_retkprobe_filter_arg+0x2aa6>
     bc8:      	movl	$0x0, %ebx
     bcd:      	testq	%rax, %rax
     bd0:      	je	0x2aa8 <generic_retkprobe_filter_arg+0x2aa8>
     bd6:      	movq	%rax, 0x18(%rsp)
     bdb:      	movl	$0x1, %eax
     be0:      	movq	0x30(%rsp), %rsi
     be5:      	movq	(%rip), %rdi            # 0xbec <generic_retkprobe_filter_arg+0xbec>
     bec:      	callq	*%rax
     bee:      	testq	%rax, %rax
     bf1:      	je	0x2aa6 <generic_retkprobe_filter_arg+0x2aa6>
     bf7:      	movq	%rax, %rbx
     bfa:      	movq	0x20(%rsp), %rdx
     bff:      	addq	$0x4, %rdx
     c03:      	cmpl	$0xff, %ebp
     c09:      	movl	$0xff, %eax
     c0e:      	cmovael	%eax, %ebp
     c11:      	leal	(,%rbp,8), %eax
     c18:      	movl	%eax, (%rbx)
     c1a:      	movq	%rbx, %rdi
     c1d:      	addq	$0x4, %rdi
     c21:      	movl	$0x4, %eax
     c26:      	movl	%ebp, %esi
     c28:      	callq	*%rax
     c2a:      	movl	$0x1, %eax
     c2f:      	movq	0x18(%rsp), %rdi
     c34:      	movq	%rbx, %rsi
     c37:      	jmp	0x2a9a <generic_retkprobe_filter_arg+0x2a9a>
     c3c:      	movzbl	0x10(%r15), %eax
     c41:      	movl	%eax, 0x70(%rsp)
     c45:      	movl	$0x1, %eax
     c4a:      	movq	0x30(%rsp), %rsi
     c4f:      	movq	(%rip), %rdi            # 0xc56 <generic_retkprobe_filter_arg+0xc56>
     c56:      	callq	*%rax
     c58:      	testq	%rax, %rax
     c5b:      	je	0x166d <generic_retkprobe_filter_arg+0x166d>
     c61:      	movq	%rax, %rdi
     c64:      	movl	(%rbp), %eax
     c67:      	movq	%rax, 0x38(%rsp)
     c6c:      	movl	$0x1, %eax
     c71:      	leaq	0x38(%rsp), %rsi
     c76:      	jmp	0x1636 <generic_retkprobe_filter_arg+0x1636>
     c7b:      	cmpl	$0xc, %eax
     c7e:      	jne	0x1ab0 <generic_retkprobe_filter_arg+0x1ab0>
     c84:      	testq	%rdx, (%rbp)
     c88:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
     c8e:      	jmp	0x1ab0 <generic_retkprobe_filter_arg+0x1ab0>
     c93:      	movzwl	(%rsi), %edx
     c96:      	movw	%dx, 0x5e(%rsp)
     c9b:      	movzwl	0x2(%rsi), %edx
     c9f:      	movw	%dx, 0x58(%rsp)
     ca4:      	movq	0x8(%rsi), %rdx
     ca8:      	movq	%rdx, 0x38(%rsp)
     cad:      	movq	0x10(%rsi), %rdx
     cb1:      	movq	%rdx, 0x40(%rsp)
     cb6:      	leaq	0x38(%rsp), %rsi
     cbb:      	xorl	%edx, %edx
     cbd:      	cmpl	$0x13, %eax
     cc0:      	jle	0xce9 <generic_retkprobe_filter_arg+0xce9>
     cc2:      	cmpl	$0x17, %eax
     cc5:      	jg	0xd1b <generic_retkprobe_filter_arg+0xd1b>
     cc7:      	leal	-0x14(%rax), %ecx
     cca:      	cmpl	$0x2, %ecx
     ccd:      	jb	0x1273 <generic_retkprobe_filter_arg+0x1273>
     cd3:      	leal	-0x16(%rax), %ecx
     cd6:      	movl	$0x0, %ebx
     cdb:      	cmpl	$0x2, %ecx
     cde:      	jb	0x126c <generic_retkprobe_filter_arg+0x126c>
     ce4:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
     ce9:      	cmpl	$0xf, %eax
     cec:      	jle	0xf5c <generic_retkprobe_filter_arg+0xf5c>
     cf2:      	cmpl	$0x11, %eax
     cf5:      	jg	0x1259 <generic_retkprobe_filter_arg+0x1259>
     cfb:      	cmpl	$0x10, %eax
     cfe:      	je	0x126c <generic_retkprobe_filter_arg+0x126c>
     d04:      	movl	$0x0, %ebx
     d09:      	cmpl	$0x11, %eax
     d0c:      	jne	0x260 <generic_retkprobe_filter_arg+0x260>
     d12:      	movzwl	0x24(%rsi), %ebx
     d16:      	jmp	0x1a17 <generic_retkprobe_filter_arg+0x1a17>
     d1b:      	cmpl	$0x1b, %eax
     d1e:      	jg	0x12ac <generic_retkprobe_filter_arg+0x12ac>
     d24:      	cmpl	$0x18, %eax
     d27:      	je	0x12e6 <generic_retkprobe_filter_arg+0x12e6>
     d2d:      	movl	$0x0, %ebx
     d32:      	cmpl	$0x19, %eax
     d35:      	je	0x12dc <generic_retkprobe_filter_arg+0x12dc>
     d3b:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
     d40:      	leal	-0x1f(%rax), %edx
     d43:      	cmpl	$0x2, %edx
     d46:      	jae	0x176f <generic_retkprobe_filter_arg+0x176f>
     d4c:      	cmpl	$0x1f, %eax
     d4f:      	jne	0xf30 <generic_retkprobe_filter_arg+0xf30>
     d55:      	movq	0x10(%r15), %rsi
     d59:      	movq	0x18(%r15), %rdx
     d5d:      	cmpl	$0xa, %ecx
     d60:      	je	0xd6b <generic_retkprobe_filter_arg+0xd6b>
     d62:      	cmpl	$0xc, %ecx
     d65:      	jne	0x1979 <generic_retkprobe_filter_arg+0x1979>
     d6b:      	movq	(%rbp), %rax
     d6f:      	cmpq	%rax, %rsi
     d72:      	jg	0x198b <generic_retkprobe_filter_arg+0x198b>
     d78:      	cmpq	%rdx, %rax
     d7b:      	jle	0x276 <generic_retkprobe_filter_arg+0x276>
     d81:      	jmp	0x198b <generic_retkprobe_filter_arg+0x198b>
     d86:      	cmpl	$0x21, %eax
     d89:      	je	0x13a7 <generic_retkprobe_filter_arg+0x13a7>
     d8f:      	movl	$0x0, %ebx
     d94:      	cmpl	$0x22, %eax
     d97:      	jne	0x2c6b <generic_retkprobe_filter_arg+0x2c6b>
     d9d:      	movq	%rsi, 0x20(%rsp)
     da2:      	xorl	%ebx, %ebx
     da4:      	xorl	%r12d, %r12d
     da7:      	movl	0x10(%r15,%rbx,4), %eax
     dac:      	movl	%eax, 0x38(%rsp)
     db0:      	movl	$0x1, %eax
     db5:      	leaq	0x38(%rsp), %rsi
     dba:      	movq	(%rip), %rdi            # 0xdc1 <generic_retkprobe_filter_arg+0xdc1>
     dc1:      	callq	*%rax
     dc3:      	testq	%rax, %rax
     dc6:      	je	0x211a <generic_retkprobe_filter_arg+0x211a>
     dcc:      	testl	%ebp, %ebp
     dce:      	movq	0x10(%rsp), %r11
     dd3:      	je	0xe44 <generic_retkprobe_filter_arg+0xe44>
     dd5:      	movq	0x20(%rsp), %rdx
     dda:      	xorl	%ecx, %ecx
     ddc:      	jmp	0xde9 <generic_retkprobe_filter_arg+0xde9>
     dde:      	incq	%rcx
     de1:      	incq	%rdx
     de4:      	cmpq	%rbp, %rcx
     de7:      	je	0xe44 <generic_retkprobe_filter_arg+0xe44>
     de9:      	xorl	%esi, %esi
     deb:      	nopl	(%rax,%rax)
     df0:      	leaq	(%rcx,%rsi), %rdi
     df4:      	cmpq	%rbp, %rdi
     df7:      	jae	0xdde <generic_retkprobe_filter_arg+0xdde>
     df9:      	movsbl	(%rax,%rsi), %edi
     dfd:      	testl	%edi, %edi
     dff:      	je	0xe3c <generic_retkprobe_filter_arg+0xe3c>
     e01:      	movsbl	(%rdx,%rsi), %r9d
     e06:      	leal	-0x41(%r9), %r10d
     e0a:      	movl	%r9d, %r8d
     e0d:      	orl	$0x20, %r8d
     e11:      	cmpl	$0x1a, %r10d
     e15:      	cmovael	%r9d, %r8d
     e19:      	leal	-0x41(%rdi), %r10d
     e1d:      	movl	%edi, %r9d
     e20:      	orl	$0x20, %r9d
     e24:      	cmpl	$0x1a, %r10d
     e28:      	cmovael	%edi, %r9d
     e2c:      	cmpq	$0x62, %rsi
     e30:      	ja	0xdde <generic_retkprobe_filter_arg+0xdde>
     e32:      	incq	%rsi
     e35:      	cmpl	%r9d, %r8d
     e38:      	je	0xdf0 <generic_retkprobe_filter_arg+0xdf0>
     e3a:      	jmp	0xdde <generic_retkprobe_filter_arg+0xdde>
     e3c:      	testl	%ecx, %ecx
     e3e:      	jns	0x23f8 <generic_retkprobe_filter_arg+0x23f8>
     e44:      	leal	0xc(%r12), %eax
     e49:      	cmpl	0x8(%r15), %eax
     e4d:      	jae	0xe60 <generic_retkprobe_filter_arg+0xe60>
     e4f:      	addl	$0x4, %r12d
     e53:      	incq	%rbx
     e56:      	cmpq	$0x64, %rbx
     e5a:      	jne	0xda7 <generic_retkprobe_filter_arg+0xda7>
     e60:      	xorl	%ebx, %ebx
     e62:      	jmp	0x23fd <generic_retkprobe_filter_arg+0x23fd>
     e67:      	movq	%rsi, 0x20(%rsp)
     e6c:      	movl	0x10(%r15), %eax
     e70:      	movl	%eax, 0x38(%rsp)
     e74:      	movl	$0x0, 0x70(%rsp)
     e7c:      	movl	$0x1, %eax
     e81:      	leaq	0x38(%rsp), %rsi
     e86:      	movq	(%rip), %rdi            # 0xe8d <generic_retkprobe_filter_arg+0xe8d>
     e8d:      	callq	*%rax
     e8f:      	testl	%ebp, %ebp
     e91:      	je	0x2c5b <generic_retkprobe_filter_arg+0x2c5b>
     e97:      	movl	$0x0, %ebx
     e9c:      	testq	%rax, %rax
     e9f:      	je	0x2c5d <generic_retkprobe_filter_arg+0x2c5d>
     ea5:      	movq	%rax, 0x18(%rsp)
     eaa:      	movl	$0x1, %eax
     eaf:      	movq	0x30(%rsp), %rsi
     eb4:      	movq	(%rip), %rdi            # 0xebb <generic_retkprobe_filter_arg+0xebb>
     ebb:      	callq	*%rax
     ebd:      	testq	%rax, %rax
     ec0:      	je	0x2c5b <generic_retkprobe_filter_arg+0x2c5b>
     ec6:      	cmpl	$0xff, %ebp
     ecc:      	movl	$0xff, %ecx
     ed1:      	cmovael	%ecx, %ebp
     ed4:      	leal	(,%rbp,8), %ecx
     edb:      	movl	%ecx, (%rax)
     edd:      	movq	%rax, %rdi
     ee0:      	addq	$0x4, %rdi
     ee4:      	movq	%rax, %rbx
     ee7:      	movl	$0x4, %eax
     eec:      	movq	0x20(%rsp), %rdx
     ef1:      	movl	%ebp, %esi
     ef3:      	callq	*%rax
     ef5:      	movl	$0x1, %eax
     efa:      	movq	0x18(%rsp), %rdi
     eff:      	movq	%rbx, %rsi
     f02:      	jmp	0x2c4f <generic_retkprobe_filter_arg+0x2c4f>
     f07:      	movl	$0x0, 0x70(%rsp)
     f0f:      	cmpl	$0x1fe, %ebp            # imm = 0x1FE
     f15:      	jbe	0x1452 <generic_retkprobe_filter_arg+0x1452>
     f1b:      	xorl	%ebx, %ebx
     f1d:      	movl	0x4(%r15), %eax
     f21:      	cmpq	$0x25, %rax
     f25:      	jbe	0x2c79 <generic_retkprobe_filter_arg+0x2c79>
     f2b:      	jmp	0x265 <generic_retkprobe_filter_arg+0x265>
     f30:      	movq	0x10(%r15), %rsi
     f34:      	movq	0x18(%r15), %rax
     f38:      	cmpl	$0xc, %ecx
     f3b:      	je	0xf46 <generic_retkprobe_filter_arg+0xf46>
     f3d:      	cmpl	$0xa, %ecx
     f40:      	jne	0x19c9 <generic_retkprobe_filter_arg+0x19c9>
     f46:      	movq	(%rbp), %rdx
     f4a:      	cmpq	%rdx, %rsi
     f4d:      	setle	%sil
     f51:      	cmpq	%rax, %rdx
     f54:      	setle	%al
     f57:      	jmp	0x19da <generic_retkprobe_filter_arg+0x19da>
     f5c:      	cmpl	$0xd, %eax
     f5f:      	je	0x12e6 <generic_retkprobe_filter_arg+0x12e6>
     f65:      	cmpl	$0xe, %eax
     f68:      	je	0x12dc <generic_retkprobe_filter_arg+0x12dc>
     f6e:      	movl	$0x0, %ebx
     f73:      	cmpl	$0xf, %eax
     f76:      	je	0x1273 <generic_retkprobe_filter_arg+0x1273>
     f7c:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
     f81:      	cmpl	$0x20, %eax
     f84:      	movq	%rsi, 0x20(%rsp)
     f89:      	jg	0x14ef <generic_retkprobe_filter_arg+0x14ef>
     f8f:      	cmpl	$0x1a, %eax
     f92:      	je	0x16c0 <generic_retkprobe_filter_arg+0x16c0>
     f98:      	movl	$0x0, %ebx
     f9d:      	cmpl	$0x1b, %eax
     fa0:      	jne	0x2ef2 <generic_retkprobe_filter_arg+0x2ef2>
     fa6:      	movl	0x10(%r15), %eax
     faa:      	movl	%eax, 0x38(%rsp)
     fae:      	movl	$0x0, 0x70(%rsp)
     fb6:      	movl	$0x1, %eax
     fbb:      	leaq	0x38(%rsp), %rsi
     fc0:      	movq	(%rip), %rdi            # 0xfc7 <generic_retkprobe_filter_arg+0xfc7>
     fc7:      	callq	*%rax
     fc9:      	testl	%ebp, %ebp
     fcb:      	je	0x2ee2 <generic_retkprobe_filter_arg+0x2ee2>
     fd1:      	movq	%rax, %r12
     fd4:      	movl	$0x0, %ebx
     fd9:      	testq	%rax, %rax
     fdc:      	je	0x2ee4 <generic_retkprobe_filter_arg+0x2ee4>
     fe2:      	movl	$0x1, %eax
     fe7:      	movq	0x30(%rsp), %rsi
     fec:      	movq	(%rip), %rdi            # 0xff3 <generic_retkprobe_filter_arg+0xff3>
     ff3:      	callq	*%rax
     ff5:      	testq	%rax, %rax
     ff8:      	je	0x2ee2 <generic_retkprobe_filter_arg+0x2ee2>
     ffe:      	movq	%rax, %rdi
    1001:      	movq	%r12, 0x18(%rsp)
    1006:      	cmpl	$0x7f, %ebp
    1009:      	movl	$0x7f, %eax
    100e:      	cmovbl	%ebp, %eax
    1011:      	shll	$0x3, %eax
    1014:      	movl	%eax, (%rdi)
    1016:      	movq	%rbp, %rax
    1019:      	negq	%rax
    101c:      	movl	$0x3, %ecx
    1021:      	subq	%rbp, %rcx
    1024:      	leal	-0x4(%rbp), %edx
    1027:      	movq	%rdi, 0x60(%rsp)
    102c:      	addq	$0x7, %rdi
    1030:      	movl	$0x2, %r8d
    1036:      	subq	%rbp, %r8
    1039:      	leal	-0x3(%rbp), %r9d
    103d:      	movl	$0x1, %r10d
    1043:      	subq	%rbp, %r10
    1046:      	leal	-0x2(%rbp), %r11d
    104a:      	decl	%ebp
    104c:      	xorl	%ebx, %ebx
    104e:      	movq	0x20(%rsp), %rsi
    1053:      	leal	(%rbx,%rbp), %r12d
    1057:      	andl	$0xfff, %r12d           # imm = 0xFFF
    105e:      	movzbl	(%rsi,%r12), %r12d
    1063:      	movb	%r12b, -0x3(%rdi)
    1067:      	cmpq	%rbx, %r10
    106a:      	je	0x10c4 <generic_retkprobe_filter_arg+0x10c4>
    106c:      	leal	(%r11,%rbx), %r12d
    1070:      	andl	$0xfff, %r12d           # imm = 0xFFF
    1077:      	movzbl	(%rsi,%r12), %r12d
    107c:      	movb	%r12b, -0x2(%rdi)
    1080:      	cmpq	%rbx, %r8
    1083:      	je	0x10c4 <generic_retkprobe_filter_arg+0x10c4>
    1085:      	leal	(%r9,%rbx), %r12d
    1089:      	andl	$0xfff, %r12d           # imm = 0xFFF
    1090:      	movzbl	(%rsi,%r12), %r12d
    1095:      	movb	%r12b, -0x1(%rdi)
    1099:      	cmpq	%rbx, %rcx
    109c:      	je	0x10c4 <generic_retkprobe_filter_arg+0x10c4>
    109e:      	cmpq	$-0x7c, %rbx
    10a2:      	je	0x10c4 <generic_retkprobe_filter_arg+0x10c4>
    10a4:      	leal	(%rdx,%rbx), %r12d
    10a8:      	andl	$0xfff, %r12d           # imm = 0xFFF
    10af:      	movzbl	(%rsi,%r12), %r12d
    10b4:      	movb	%r12b, (%rdi)
    10b7:      	addq	$-0x4, %rbx
    10bb:      	addq	$0x4, %rdi
    10bf:      	cmpq	%rbx, %rax
    10c2:      	jne	0x1053 <generic_retkprobe_filter_arg+0x1053>
    10c4:      	movl	$0x1, %eax
    10c9:      	movq	0x18(%rsp), %rdi
    10ce:      	movq	0x60(%rsp), %rsi
    10d3:      	jmp	0x2ed6 <generic_retkprobe_filter_arg+0x2ed6>
    10d8:      	cmpl	$0xc, %eax
    10db:      	jne	0x2062 <generic_retkprobe_filter_arg+0x2062>
    10e1:      	testl	%edx, (%rbp)
    10e4:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
    10ea:      	jmp	0x2062 <generic_retkprobe_filter_arg+0x2062>
    10ef:      	movl	$0xc00, %edx            # imm = 0xC00
    10f4:      	btq	%rcx, %rdx
    10f8:      	jb	0x15c2 <generic_retkprobe_filter_arg+0x15c2>
    10fe:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
    1108:      	btq	%rcx, %rdx
    110c:      	jae	0xb8 <generic_retkprobe_filter_arg+0xb8>
    1112:      	cmpl	$0x1f, %eax
    1115:      	jne	0x1c93 <generic_retkprobe_filter_arg+0x1c93>
    111b:      	movzbl	(%rbp), %eax
    111f:      	jmp	0x1151 <generic_retkprobe_filter_arg+0x1151>
    1121:      	movl	$0xc00, %edx            # imm = 0xC00
    1126:      	btq	%rcx, %rdx
    112a:      	jb	0x15ff <generic_retkprobe_filter_arg+0x15ff>
    1130:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
    113a:      	btq	%rcx, %rdx
    113e:      	jae	0xb8 <generic_retkprobe_filter_arg+0xb8>
    1144:      	cmpl	$0x1f, %eax
    1147:      	jne	0x1c9d <generic_retkprobe_filter_arg+0x1c9d>
    114d:      	movzwl	(%rbp), %eax
    1151:      	cmpl	%eax, 0x10(%r15)
    1155:      	ja	0x1161 <generic_retkprobe_filter_arg+0x1161>
    1157:      	cmpl	%eax, 0x14(%r15)
    115b:      	jae	0x276 <generic_retkprobe_filter_arg+0x276>
    1161:      	movl	0x8(%r15), %ecx
    1165:      	cmpl	$0x11, %ecx
    1168:      	jb	0xb8 <generic_retkprobe_filter_arg+0xb8>
    116e:      	cmpl	%eax, 0x18(%r15)
    1172:      	ja	0x117e <generic_retkprobe_filter_arg+0x117e>
    1174:      	cmpl	%eax, 0x1c(%r15)
    1178:      	jae	0x276 <generic_retkprobe_filter_arg+0x276>
    117e:      	cmpl	$0x19, %ecx
    1181:      	jb	0xb8 <generic_retkprobe_filter_arg+0xb8>
    1187:      	cmpl	%eax, 0x20(%r15)
    118b:      	ja	0x1197 <generic_retkprobe_filter_arg+0x1197>
    118d:      	cmpl	%eax, 0x24(%r15)
    1191:      	jae	0x276 <generic_retkprobe_filter_arg+0x276>
    1197:      	cmpl	$0x21, %ecx
    119a:      	jb	0xb8 <generic_retkprobe_filter_arg+0xb8>
    11a0:      	cmpl	%eax, 0x28(%r15)
    11a4:      	ja	0xb8 <generic_retkprobe_filter_arg+0xb8>
    11aa:      	cmpl	%eax, 0x2c(%r15)
    11ae:      	jae	0x276 <generic_retkprobe_filter_arg+0x276>
    11b4:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
    11b9:      	cmpl	$0xc, %ecx
    11bc:      	je	0x11c7 <generic_retkprobe_filter_arg+0x11c7>
    11be:      	cmpl	$0xa, %ecx
    11c1:      	jne	0x1a9a <generic_retkprobe_filter_arg+0x1a9a>
    11c7:      	cmpq	%rdx, (%rbp)
    11cb:      	jg	0x276 <generic_retkprobe_filter_arg+0x276>
    11d1:      	jmp	0x1ab0 <generic_retkprobe_filter_arg+0x1ab0>
    11d6:      	movzwl	%bp, %eax
    11d9:      	cmpl	$0x90, %eax
    11de:      	ja	0x17db <generic_retkprobe_filter_arg+0x17db>
    11e4:      	testw	%bp, %bp
    11e7:      	je	0x11f9 <generic_retkprobe_filter_arg+0x11f9>
    11e9:      	movl	%ebp, %eax
    11eb:      	movl	$0x18, %ecx
    11f0:      	cltd
    11f1:      	idivl	%ecx
    11f3:      	movl	%ebp, %esi
    11f5:      	testl	%edx, %edx
    11f7:      	je	0x121b <generic_retkprobe_filter_arg+0x121b>
    11f9:      	movl	%ebp, %eax
    11fb:      	movl	$0x18, %ecx
    1200:      	cltd
    1201:      	idivl	%ecx
    1203:      	shll	$0x3, %eax
    1206:      	leal	(%rax,%rax,2), %eax
    1209:      	addl	$0x18, %eax
    120c:      	movzwl	%ax, %esi
    120f:      	cmpl	$0x90, %esi
    1215:      	ja	0x17ef <generic_retkprobe_filter_arg+0x17ef>
    121b:      	movl	%esi, %eax
    121d:      	cltd
    121e:      	idivl	%ecx
    1220:      	decl	%eax
    1222:      	jmp	0x1800 <generic_retkprobe_filter_arg+0x1800>
    1227:      	movl	0x10(%r15), %esi
    122b:      	movl	0x14(%r15), %eax
    122f:      	cmpl	$0xc, %ecx
    1232:      	ja	0x1f0f <generic_retkprobe_filter_arg+0x1f0f>
    1238:      	movl	$0x1402, %edx           # imm = 0x1402
    123d:      	btl	%ecx, %edx
    1240:      	jae	0x1f0f <generic_retkprobe_filter_arg+0x1f0f>
    1246:      	movl	(%rbp), %edx
    1249:      	cmpl	%edx, %esi
    124b:      	setle	%sil
    124f:      	cmpl	%eax, %edx
    1251:      	setle	%al
    1254:      	jmp	0x1f1d <generic_retkprobe_filter_arg+0x1f1d>
    1259:      	cmpl	$0x12, %eax
    125c:      	je	0x1273 <generic_retkprobe_filter_arg+0x1273>
    125e:      	movl	$0x0, %ebx
    1263:      	cmpl	$0x13, %eax
    1266:      	jne	0x260 <generic_retkprobe_filter_arg+0x260>
    126c:      	movzwl	0x22(%rsi), %r12d
    1271:      	jmp	0x1278 <generic_retkprobe_filter_arg+0x1278>
    1273:      	movzwl	0x20(%rsi), %r12d
    1278:      	xorl	%edx, %edx
    127a:      	xorl	%ebp, %ebp
    127c:      	xorl	%r8d, %r8d
    127f:      	xorl	%ebx, %ebx
    1281:      	cmpl	$0x11, %eax
    1284:      	jg	0x12fe <generic_retkprobe_filter_arg+0x12fe>
    1286:      	leal	-0xd(%rax), %ecx
    1289:      	cmpl	$0x2, %ecx
    128c:      	jb	0x1331 <generic_retkprobe_filter_arg+0x1331>
    1292:      	leal	-0xf(%rax), %ecx
    1295:      	cmpl	$0x2, %ecx
    1298:      	jb	0x14af <generic_retkprobe_filter_arg+0x14af>
    129e:      	cmpl	$0x11, %eax
    12a1:      	je	0x1a17 <generic_retkprobe_filter_arg+0x1a17>
    12a7:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    12ac:      	cmpl	$0x1c, %eax
    12af:      	je	0x1a13 <generic_retkprobe_filter_arg+0x1a13>
    12b5:      	movl	$0x0, %ebx
    12ba:      	cmpl	$0x1d, %eax
    12bd:      	jne	0x260 <generic_retkprobe_filter_arg+0x260>
    12c3:      	cmpl	$0x7, %ecx
    12c6:      	jne	0x1ff2 <generic_retkprobe_filter_arg+0x1ff2>
    12cc:      	testq	%rdx, %rdx
    12cf:      	jne	0x1ffe <generic_retkprobe_filter_arg+0x1ffe>
    12d5:      	xorl	%ebx, %ebx
    12d7:      	jmp	0x2010 <generic_retkprobe_filter_arg+0x2010>
    12dc:      	movq	0x10(%rsi), %rdx
    12e0:      	movq	0x18(%rsi), %r8
    12e4:      	jmp	0x12ed <generic_retkprobe_filter_arg+0x12ed>
    12e6:      	movq	(%rsi), %rdx
    12e9:      	movq	0x8(%rsi), %r8
    12ed:      	movq	%rdx, %rbp
    12f0:      	shrq	$0x20, %rbp
    12f4:      	xorl	%r12d, %r12d
    12f7:      	xorl	%ebx, %ebx
    12f9:      	cmpl	$0x11, %eax
    12fc:      	jle	0x1286 <generic_retkprobe_filter_arg+0x1286>
    12fe:      	cmpl	$0x19, %eax
    1301:      	ja	0x14a3 <generic_retkprobe_filter_arg+0x14a3>
    1307:      	movl	$0x500000, %ecx         # imm = 0x500000
    130c:      	btl	%eax, %ecx
    130f:      	jb	0x17b5 <generic_retkprobe_filter_arg+0x17b5>
    1315:      	movl	$0xa00000, %ecx         # imm = 0xA00000
    131a:      	btl	%eax, %ecx
    131d:      	jb	0x17c8 <generic_retkprobe_filter_arg+0x17c8>
    1323:      	movl	$0x3000000, %ecx        # imm = 0x3000000
    1328:      	btl	%eax, %ecx
    132b:      	jae	0x14a3 <generic_retkprobe_filter_arg+0x14a3>
    1331:      	movzwl	0x26(%rsi), %eax
    1335:      	cmpl	$0xa, %eax
    1338:      	je	0x18e1 <generic_retkprobe_filter_arg+0x18e1>
    133e:      	cmpl	$0x2, %eax
    1341:      	jne	0x196f <generic_retkprobe_filter_arg+0x196f>
    1347:      	movq	%rdx, %rbx
    134a:      	movl	0x10(%r15), %eax
    134e:      	movl	%eax, 0x2c(%rsp)
    1352:      	movl	$0x1, %eax
    1357:      	leaq	0x2c(%rsp), %rsi
    135c:      	movq	(%rip), %rdi            # 0x1363 <generic_retkprobe_filter_arg+0x1363>
    1363:      	callq	*%rax
    1365:      	testq	%rax, %rax
    1368:      	je	0x1b60 <generic_retkprobe_filter_arg+0x1b60>
    136e:      	movq	%rax, %rdi
    1371:      	movl	$0x20, 0x70(%rsp)
    1379:      	movl	%ebx, 0x74(%rsp)
    137d:      	jmp	0x192f <generic_retkprobe_filter_arg+0x192f>
    1382:      	cmpl	$0xc, %ecx
    1385:      	ja	0x204e <generic_retkprobe_filter_arg+0x204e>
    138b:      	movl	$0x1402, %esi           # imm = 0x1402
    1390:      	btl	%ecx, %esi
    1393:      	jae	0x204e <generic_retkprobe_filter_arg+0x204e>
    1399:      	cmpl	%edx, (%rbp)
    139c:      	jg	0x276 <generic_retkprobe_filter_arg+0x276>
    13a2:      	jmp	0x2062 <generic_retkprobe_filter_arg+0x2062>
    13a7:      	movq	%rsi, 0x20(%rsp)
    13ac:      	xorl	%ebx, %ebx
    13ae:      	xorl	%r12d, %r12d
    13b1:      	movl	0x10(%r15,%rbx,4), %eax
    13b6:      	movl	%eax, 0x38(%rsp)
    13ba:      	movl	$0x1, %eax
    13bf:      	leaq	0x38(%rsp), %rsi
    13c4:      	movq	(%rip), %rdi            # 0x13cb <generic_retkprobe_filter_arg+0x13cb>
    13cb:      	callq	*%rax
    13cd:      	testq	%rax, %rax
    13d0:      	je	0x2109 <generic_retkprobe_filter_arg+0x2109>
    13d6:      	testl	%ebp, %ebp
    13d8:      	movq	0x8(%rsp), %r9
    13dd:      	movq	0x10(%rsp), %r11
    13e2:      	je	0x142f <generic_retkprobe_filter_arg+0x142f>
    13e4:      	movq	0x20(%rsp), %rdx
    13e9:      	xorl	%ecx, %ecx
    13eb:      	jmp	0x13f8 <generic_retkprobe_filter_arg+0x13f8>
    13ed:      	incq	%rcx
    13f0:      	incq	%rdx
    13f3:      	cmpq	%rbp, %rcx
    13f6:      	je	0x142f <generic_retkprobe_filter_arg+0x142f>
    13f8:      	xorl	%esi, %esi
    13fa:      	nopw	(%rax,%rax)
    1400:      	leaq	(%rcx,%rsi), %rdi
    1404:      	cmpq	%rbp, %rdi
    1407:      	jae	0x13ed <generic_retkprobe_filter_arg+0x13ed>
    1409:      	movzbl	(%rax,%rsi), %edi
    140d:      	testb	%dil, %dil
    1410:      	je	0x1427 <generic_retkprobe_filter_arg+0x1427>
    1412:      	cmpq	$0x62, %rsi
    1416:      	ja	0x13ed <generic_retkprobe_filter_arg+0x13ed>
    1418:      	leaq	0x1(%rsi), %r8
    141c:      	cmpb	%dil, (%rdx,%rsi)
    1420:      	movq	%r8, %rsi
    1423:      	je	0x1400 <generic_retkprobe_filter_arg+0x1400>
    1425:      	jmp	0x13ed <generic_retkprobe_filter_arg+0x13ed>
    1427:      	testl	%ecx, %ecx
    1429:      	jns	0x23d7 <generic_retkprobe_filter_arg+0x23d7>
    142f:      	leal	0xc(%r12), %eax
    1434:      	cmpl	0x8(%r15), %eax
    1438:      	jae	0x144b <generic_retkprobe_filter_arg+0x144b>
    143a:      	addl	$0x4, %r12d
    143e:      	incq	%rbx
    1441:      	cmpq	$0x64, %rbx
    1445:      	jne	0x13b1 <generic_retkprobe_filter_arg+0x13b1>
    144b:      	xorl	%ebx, %ebx
    144d:      	jmp	0x23dc <generic_retkprobe_filter_arg+0x23dc>
    1452:      	movzwl	%bp, %eax
    1455:      	cmpl	$0x90, %eax
    145a:      	ja	0x1b6f <generic_retkprobe_filter_arg+0x1b6f>
    1460:      	testw	%bp, %bp
    1463:      	je	0x1475 <generic_retkprobe_filter_arg+0x1475>
    1465:      	movl	%ebp, %eax
    1467:      	movl	$0x18, %ecx
    146c:      	cltd
    146d:      	idivl	%ecx
    146f:      	movl	%ebp, %edi
    1471:      	testl	%edx, %edx
    1473:      	je	0x1497 <generic_retkprobe_filter_arg+0x1497>
    1475:      	movl	%ebp, %eax
    1477:      	movl	$0x18, %ecx
    147c:      	cltd
    147d:      	idivl	%ecx
    147f:      	shll	$0x3, %eax
    1482:      	leal	(%rax,%rax,2), %eax
    1485:      	addl	$0x18, %eax
    1488:      	movzwl	%ax, %edi
    148b:      	cmpl	$0x90, %edi
    1491:      	ja	0x1b83 <generic_retkprobe_filter_arg+0x1b83>
    1497:      	movl	%edi, %eax
    1499:      	cltd
    149a:      	idivl	%ecx
    149c:      	decl	%eax
    149e:      	jmp	0x1b94 <generic_retkprobe_filter_arg+0x1b94>
    14a3:      	addl	$-0x12, %eax
    14a6:      	cmpl	$0x2, %eax
    14a9:      	jae	0x260 <generic_retkprobe_filter_arg+0x260>
    14af:      	movzbl	0x10(%r15), %eax
    14b4:      	movl	%eax, 0x2c(%rsp)
    14b8:      	movl	$0x1, %eax
    14bd:      	movq	(%rip), %rdi            # 0x14c4 <generic_retkprobe_filter_arg+0x14c4>
    14c4:      	leaq	0x2c(%rsp), %rsi
    14c9:      	callq	*%rax
    14cb:      	testq	%rax, %rax
    14ce:      	je	0x250 <generic_retkprobe_filter_arg+0x250>
    14d4:      	movq	%rax, %rdi
    14d7:      	movzwl	%r12w, %eax
    14db:      	movq	%rax, 0x70(%rsp)
    14e0:      	movl	$0x1, %eax
    14e5:      	movq	0x30(%rsp), %rsi
    14ea:      	jmp	0x1a51 <generic_retkprobe_filter_arg+0x1a51>
    14ef:      	cmpl	$0x21, %eax
    14f2:      	je	0x1d15 <generic_retkprobe_filter_arg+0x1d15>
    14f8:      	movl	$0x0, %ebx
    14fd:      	cmpl	$0x22, %eax
    1500:      	jne	0x2ef2 <generic_retkprobe_filter_arg+0x2ef2>
    1506:      	movl	$0x10, %r12d
    150c:      	movl	(%r15,%r12), %eax
    1510:      	movl	%eax, 0x38(%rsp)
    1514:      	movl	$0x1, %eax
    1519:      	leaq	0x38(%rsp), %rsi
    151e:      	movq	(%rip), %rdi            # 0x1525 <generic_retkprobe_filter_arg+0x1525>
    1525:      	callq	*%rax
    1527:      	testq	%rax, %rax
    152a:      	je	0x2ee2 <generic_retkprobe_filter_arg+0x2ee2>
    1530:      	movq	0x20(%rsp), %rdi
    1535:      	movq	%rax, %rsi
    1538:      	movq	%rbp, %rdx
    153b:      	callq	0x1540 <generic_retkprobe_filter_arg+0x1540>
    1540:      	testl	%eax, %eax
    1542:      	jns	0x26e8 <generic_retkprobe_filter_arg+0x26e8>
    1548:      	addq	$0x4, %r12
    154c:      	leal	-0x8(%r12), %eax
    1551:      	cmpl	0x8(%r15), %eax
    1555:      	movq	(%rsp), %rdi
    1559:      	movq	0x8(%rsp), %r9
    155e:      	movq	0x10(%rsp), %r11
    1563:      	jae	0x1768 <generic_retkprobe_filter_arg+0x1768>
    1569:      	movl	$0x0, %ebx
    156e:      	cmpq	$0x1a0, %r12            # imm = 0x1A0
    1575:      	jne	0x150c <generic_retkprobe_filter_arg+0x150c>
    1577:      	jmp	0x2ef2 <generic_retkprobe_filter_arg+0x2ef2>
    157c:      	cmpl	$0x1, %eax
    157f:      	je	0x1e17 <generic_retkprobe_filter_arg+0x1e17>
    1585:      	cmpl	$0x2, %eax
    1588:      	jne	0x1e23 <generic_retkprobe_filter_arg+0x1e23>
    158e:      	movzbl	(%rbp), %edx
    1592:      	cmpl	%edx, %ecx
    1594:      	ja	0x276 <generic_retkprobe_filter_arg+0x276>
    159a:      	jmp	0x1e23 <generic_retkprobe_filter_arg+0x1e23>
    159f:      	cmpl	$0x1, %eax
    15a2:      	je	0x1e5a <generic_retkprobe_filter_arg+0x1e5a>
    15a8:      	cmpl	$0x2, %eax
    15ab:      	jne	0x1e66 <generic_retkprobe_filter_arg+0x1e66>
    15b1:      	movzwl	(%rbp), %edx
    15b5:      	cmpl	%edx, %ecx
    15b7:      	ja	0x276 <generic_retkprobe_filter_arg+0x276>
    15bd:      	jmp	0x1e66 <generic_retkprobe_filter_arg+0x1e66>
    15c2:      	movzbl	0x10(%r15), %eax
    15c7:      	movl	%eax, 0x70(%rsp)
    15cb:      	movl	$0x1, %eax
    15d0:      	movq	0x30(%rsp), %rsi
    15d5:      	movq	(%rip), %rdi            # 0x15dc <generic_retkprobe_filter_arg+0x15dc>
    15dc:      	callq	*%rax
    15de:      	testq	%rax, %rax
    15e1:      	je	0x166d <generic_retkprobe_filter_arg+0x166d>
    15e7:      	movq	%rax, %rdi
    15ea:      	movzbl	(%rbp), %eax
    15ee:      	movq	%rax, 0x38(%rsp)
    15f3:      	movl	$0x1, %eax
    15f8:      	leaq	0x38(%rsp), %rsi
    15fd:      	jmp	0x1636 <generic_retkprobe_filter_arg+0x1636>
    15ff:      	movzbl	0x10(%r15), %eax
    1604:      	movl	%eax, 0x70(%rsp)
    1608:      	movl	$0x1, %eax
    160d:      	movq	0x30(%rsp), %rsi
    1612:      	movq	(%rip), %rdi            # 0x1619 <generic_retkprobe_filter_arg+0x1619>
    1619:      	callq	*%rax
    161b:      	testq	%rax, %rax
    161e:      	je	0x166d <generic_retkprobe_filter_arg+0x166d>
    1620:      	movq	%rax, %rdi
    1623:      	movzwl	(%rbp), %eax
    1627:      	movq	%rax, 0x38(%rsp)
    162c:      	movl	$0x1, %eax
    1631:      	leaq	0x38(%rsp), %rsi
    1636:      	callq	*%rax
    1638:      	movl	0x4(%r15), %edx
    163c:      	xorl	%ecx, %ecx
    163e:      	cmpl	$0x1d, %edx
    1641:      	ja	0x263d <generic_retkprobe_filter_arg+0x263d>
    1647:      	movl	$0x30038400, %esi       # imm = 0x30038400
    164c:      	btl	%edx, %esi
    164f:      	movq	(%rsp), %rdi
    1653:      	movq	0x8(%rsp), %r9
    1658:      	movq	0x10(%rsp), %r11
    165d:      	jae	0x1682 <generic_retkprobe_filter_arg+0x1682>
    165f:      	testq	%rax, %rax
    1662:      	setne	%cl
    1665:      	movzbl	%cl, %ebx
    1668:      	jmp	0x265 <generic_retkprobe_filter_arg+0x265>
    166d:      	xorl	%ebx, %ebx
    166f:      	movq	(%rsp), %rdi
    1673:      	movq	0x8(%rsp), %r9
    1678:      	movq	0x10(%rsp), %r11
    167d:      	jmp	0x265 <generic_retkprobe_filter_arg+0x265>
    1682:      	movl	$0xc0800, %esi          # imm = 0xC0800
    1687:      	btl	%edx, %esi
    168a:      	jae	0x1692 <generic_retkprobe_filter_arg+0x1692>
    168c:      	testq	%rax, %rax
    168f:      	sete	%cl
    1692:      	movzbl	%cl, %ebx
    1695:      	jmp	0x265 <generic_retkprobe_filter_arg+0x265>
    169a:      	testq	%rax, %rax
    169d:      	sete	%al
    16a0:      	movq	(%rsp), %rdi
    16a4:      	movq	0x8(%rsp), %r9
    16a9:      	movq	0x10(%rsp), %r11
    16ae:      	movzbl	%al, %ebx
    16b1:      	jmp	0x265 <generic_retkprobe_filter_arg+0x265>
    16b6:      	xorl	%eax, %eax
    16b8:      	movzbl	%al, %ebx
    16bb:      	jmp	0x265 <generic_retkprobe_filter_arg+0x265>
    16c0:      	movl	0x10(%r15), %eax
    16c4:      	movl	%eax, 0x38(%rsp)
    16c8:      	movl	$0x0, 0x70(%rsp)
    16d0:      	movl	$0x1, %eax
    16d5:      	leaq	0x38(%rsp), %rsi
    16da:      	movq	(%rip), %rdi            # 0x16e1 <generic_retkprobe_filter_arg+0x16e1>
    16e1:      	callq	*%rax
    16e3:      	testl	%ebp, %ebp
    16e5:      	je	0x2ee2 <generic_retkprobe_filter_arg+0x2ee2>
    16eb:      	movq	%rax, %r12
    16ee:      	movl	$0x0, %ebx
    16f3:      	testq	%rax, %rax
    16f6:      	je	0x2ee4 <generic_retkprobe_filter_arg+0x2ee4>
    16fc:      	movl	$0x1, %eax
    1701:      	movq	0x30(%rsp), %rsi
    1706:      	movq	(%rip), %rdi            # 0x170d <generic_retkprobe_filter_arg+0x170d>
    170d:      	callq	*%rax
    170f:      	testq	%rax, %rax
    1712:      	je	0x2ee2 <generic_retkprobe_filter_arg+0x2ee2>
    1718:      	cmpl	$0xff, %ebp
    171e:      	movl	$0xff, %ecx
    1723:      	cmovael	%ecx, %ebp
    1726:      	leal	(,%rbp,8), %ecx
    172d:      	movl	%ecx, (%rax)
    172f:      	movq	%rax, %rdi
    1732:      	addq	$0x4, %rdi
    1736:      	movq	%rax, %rbx
    1739:      	movl	$0x4, %eax
    173e:      	movq	0x20(%rsp), %rdx
    1743:      	movl	%ebp, %esi
    1745:      	callq	*%rax
    1747:      	movl	$0x1, %eax
    174c:      	movq	%r12, %rdi
    174f:      	jmp	0x2ed3 <generic_retkprobe_filter_arg+0x2ed3>
    1754:      	movl	$0x0, 0x70(%rsp)
    175c:      	cmpl	$0x1fe, %ebp            # imm = 0x1FE
    1762:      	jbe	0x1dc6 <generic_retkprobe_filter_arg+0x1dc6>
    1768:      	xorl	%ebx, %ebx
    176a:      	jmp	0x2ef2 <generic_retkprobe_filter_arg+0x2ef2>
    176f:      	cmpl	$0x1e, %eax
    1772:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    1778:      	movl	0x10(%r15), %eax
    177c:      	andl	$0x7, %eax
    177f:      	movl	%eax, %ecx
    1781:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
    178a:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    1790:      	movq	(%rbp), %rcx
    1794:      	movq	0x5e78(%r14,%rax,8), %rax
    179c:      	andl	$0x7ff, %eax            # imm = 0x7FF
    17a1:      	xorl	%ebx, %ebx
    17a3:      	andnq	0x90(%r14,%rax), %rcx, %rax
    17ad:      	setne	%bl
    17b0:      	jmp	0x265 <generic_retkprobe_filter_arg+0x265>
    17b5:      	movzwl	%r12w, %eax
    17b9:      	xorl	%ebx, %ebx
    17bb:      	cmpl	$0x400, %eax            # imm = 0x400
    17c0:      	setb	%bl
    17c3:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    17c8:      	movzwl	%r12w, %eax
    17cc:      	xorl	%ebx, %ebx
    17ce:      	cmpl	$0x400, %eax            # imm = 0x400
    17d3:      	setae	%bl
    17d6:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    17db:      	cmpl	$0x101, %eax            # imm = 0x101
    17e0:      	movl	$0x100, %esi            # imm = 0x100
    17e5:      	movl	$0x1fe, %eax            # imm = 0x1FE
    17ea:      	cmovael	%eax, %esi
    17ed:      	movl	%esi, %eax
    17ef:      	movzwl	%ax, %ecx
    17f2:      	xorl	%eax, %eax
    17f4:      	cmpl	$0x100, %ecx            # imm = 0x100
    17fa:      	sete	%al
    17fd:      	xorl	$0x7, %eax
    1800:      	movl	%eax, %ecx
    1802:      	andl	$0xf, %ecx
    1805:      	movl	0x10(%r15,%rcx,4), %ecx
    180a:      	cmpl	$-0x1, %ecx
    180d:      	je	0x2aa6 <generic_retkprobe_filter_arg+0x2aa6>
    1813:      	movl	%ecx, 0x90(%rsp)
    181a:      	movq	%rsi, 0x88(%rsp)
    1822:      	movl	%eax, 0x60(%rsp)
    1826:      	movl	$0x1, %eax
    182b:      	movq	(%rip), %rdi            # 0x1832 <generic_retkprobe_filter_arg+0x1832>
    1832:      	movq	0x30(%rsp), %rbx
    1837:      	movq	%rbx, %rsi
    183a:      	callq	*%rax
    183c:      	movq	%rax, 0x18(%rsp)
    1841:      	movl	$0x1, %eax
    1846:      	movq	(%rip), %rdi            # 0x184d <generic_retkprobe_filter_arg+0x184d>
    184d:      	movq	%rbx, %rsi
    1850:      	callq	*%rax
    1852:      	cmpq	$0x0, 0x18(%rsp)
    1858:      	je	0x2aa6 <generic_retkprobe_filter_arg+0x2aa6>
    185e:      	movl	$0x0, %ebx
    1863:      	testq	%rax, %rax
    1866:      	movq	(%rsp), %rdi
    186a:      	movq	0x8(%rsp), %r9
    186f:      	movq	0x10(%rsp), %r11
    1874:      	je	0x2ab6 <generic_retkprobe_filter_arg+0x2ab6>
    187a:      	movq	%rax, 0x98(%rsp)
    1882:      	movq	0x20(%rsp), %rdx
    1887:      	addq	$0x4, %rdx
    188b:      	movl	0x60(%rsp), %ebx
    188f:      	cmpl	$0x5, %ebx
    1892:      	jg	0x216c <generic_retkprobe_filter_arg+0x216c>
    1898:      	movq	0x18(%rsp), %rax
    189d:      	movb	%bpl, (%rax)
    18a0:      	leaq	0x1(%rax), %rdi
    18a4:      	movl	$0x4, %eax
    18a9:      	movl	%ebp, %esi
    18ab:      	callq	*%rax
    18ad:      	movq	0x88(%rsp), %rsi
    18b5:      	subl	%ebp, %esi
    18b7:      	jbe	0x21af <generic_retkprobe_filter_arg+0x21af>
    18bd:      	movq	0x18(%rsp), %rax
    18c2:      	leaq	(%rax,%rbp), %rdi
    18c6:      	incq	%rdi
    18c9:      	andl	$0xfff, %esi            # imm = 0xFFF
    18cf:      	movl	$0x4, %eax
    18d4:      	movq	0x98(%rsp), %rdx
    18dc:      	jmp	0x21ad <generic_retkprobe_filter_arg+0x21ad>
    18e1:      	movq	%r8, %r12
    18e4:      	movq	%rdx, %rbx
    18e7:      	movl	0x14(%r15), %eax
    18eb:      	movl	%eax, 0x2c(%rsp)
    18ef:      	movl	$0x1, %eax
    18f4:      	movq	(%rip), %rdi            # 0x18fb <generic_retkprobe_filter_arg+0x18fb>
    18fb:      	leaq	0x2c(%rsp), %rsi
    1900:      	callq	*%rax
    1902:      	testq	%rax, %rax
    1905:      	je	0x1b60 <generic_retkprobe_filter_arg+0x1b60>
    190b:      	movq	%rax, %rdi
    190e:      	movl	$0x80, 0x70(%rsp)
    1916:      	movl	%ebx, 0x74(%rsp)
    191a:      	movl	%ebp, 0x78(%rsp)
    191e:      	movl	%r12d, 0x7c(%rsp)
    1923:      	shrq	$0x20, %r12
    1927:      	movl	%r12d, 0x80(%rsp)
    192f:      	movl	$0x1, %eax
    1934:      	movq	0x30(%rsp), %rsi
    1939:      	callq	*%rax
    193b:      	movl	0x4(%r15), %ecx
    193f:      	leal	-0x18(%rcx), %edx
    1942:      	cmpl	$0x2, %edx
    1945:      	jb	0x1e9d <generic_retkprobe_filter_arg+0x1e9d>
    194b:      	addl	$-0xd, %ecx
    194e:      	cmpl	$0x1, %ecx
    1951:      	movq	(%rsp), %rdi
    1955:      	movq	0x8(%rsp), %r9
    195a:      	movq	0x10(%rsp), %r11
    195f:      	ja	0x196f <generic_retkprobe_filter_arg+0x196f>
    1961:      	testq	%rax, %rax
    1964:      	setne	%al
    1967:      	movzbl	%al, %ebx
    196a:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    196f:      	xorl	%eax, %eax
    1971:      	movzbl	%al, %ebx
    1974:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    1979:      	movq	(%rbp), %rax
    197d:      	cmpq	%rax, %rsi
    1980:      	ja	0x198b <generic_retkprobe_filter_arg+0x198b>
    1982:      	cmpq	%rdx, %rax
    1985:      	jbe	0x276 <generic_retkprobe_filter_arg+0x276>
    198b:      	movl	0x8(%r15), %edx
    198f:      	cmpl	$0x19, %edx
    1992:      	jb	0xb8 <generic_retkprobe_filter_arg+0xb8>
    1998:      	movq	0x20(%r15), %rdi
    199c:      	movq	0x28(%r15), %rsi
    19a0:      	cmpl	$0xc, %ecx
    19a3:      	je	0x19ae <generic_retkprobe_filter_arg+0x19ae>
    19a5:      	cmpl	$0xa, %ecx
    19a8:      	jne	0x1fa6 <generic_retkprobe_filter_arg+0x1fa6>
    19ae:      	cmpq	%rax, %rdi
    19b1:      	movq	(%rsp), %rdi
    19b5:      	jg	0x1fb8 <generic_retkprobe_filter_arg+0x1fb8>
    19bb:      	cmpq	%rsi, %rax
    19be:      	jle	0x276 <generic_retkprobe_filter_arg+0x276>
    19c4:      	jmp	0x1fb8 <generic_retkprobe_filter_arg+0x1fb8>
    19c9:      	movq	(%rbp), %rdx
    19cd:      	cmpq	%rdx, %rsi
    19d0:      	setbe	%sil
    19d4:      	cmpq	%rax, %rdx
    19d7:      	setbe	%al
    19da:      	andb	%sil, %al
    19dd:      	movl	0x8(%r15), %esi
    19e1:      	cmpl	$0x19, %esi
    19e4:      	jb	0x2af3 <generic_retkprobe_filter_arg+0x2af3>
    19ea:      	movq	0x20(%r15), %r8
    19ee:      	movq	0x28(%r15), %rdi
    19f2:      	cmpl	$0xc, %ecx
    19f5:      	je	0x1a00 <generic_retkprobe_filter_arg+0x1a00>
    19f7:      	cmpl	$0xa, %ecx
    19fa:      	jne	0x1f60 <generic_retkprobe_filter_arg+0x1f60>
    1a00:      	cmpq	%rdx, %r8
    1a03:      	setle	%r8b
    1a07:      	cmpq	%rdi, %rdx
    1a0a:      	setle	%dil
    1a0e:      	jmp	0x1f6e <generic_retkprobe_filter_arg+0x1f6e>
    1a13:      	movzwl	0x26(%rsi), %ebx
    1a17:      	movzbl	0x10(%r15), %eax
    1a1c:      	movl	%eax, 0x2c(%rsp)
    1a20:      	movl	$0x1, %eax
    1a25:      	movq	(%rip), %rdi            # 0x1a2c <generic_retkprobe_filter_arg+0x1a2c>
    1a2c:      	leaq	0x2c(%rsp), %rsi
    1a31:      	callq	*%rax
    1a33:      	testq	%rax, %rax
    1a36:      	je	0x250 <generic_retkprobe_filter_arg+0x250>
    1a3c:      	movq	%rax, %rdi
    1a3f:      	movzwl	%bx, %eax
    1a42:      	movq	%rax, 0x70(%rsp)
    1a47:      	movl	$0x1, %eax
    1a4c:      	movq	0x30(%rsp), %rsi
    1a51:      	callq	*%rax
    1a53:      	movl	0x4(%r15), %edx
    1a57:      	xorl	%ecx, %ecx
    1a59:      	cmpl	$0x1d, %edx
    1a5c:      	ja	0x2653 <generic_retkprobe_filter_arg+0x2653>
    1a62:      	movl	$0x30038400, %esi       # imm = 0x30038400
    1a67:      	btl	%edx, %esi
    1a6a:      	movq	(%rsp), %rdi
    1a6e:      	movq	0x8(%rsp), %r9
    1a73:      	movq	0x10(%rsp), %r11
    1a78:      	jae	0x1a82 <generic_retkprobe_filter_arg+0x1a82>
    1a7a:      	testq	%rax, %rax
    1a7d:      	setne	%cl
    1a80:      	jmp	0x1a92 <generic_retkprobe_filter_arg+0x1a92>
    1a82:      	movl	$0xc0800, %esi          # imm = 0xC0800
    1a87:      	btl	%edx, %esi
    1a8a:      	jae	0x1a92 <generic_retkprobe_filter_arg+0x1a92>
    1a8c:      	testq	%rax, %rax
    1a8f:      	sete	%cl
    1a92:      	movzbl	%cl, %ebx
    1a95:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    1a9a:      	cmpq	%rdx, (%rbp)
    1a9e:      	ja	0x276 <generic_retkprobe_filter_arg+0x276>
    1aa4:      	jmp	0x1ab0 <generic_retkprobe_filter_arg+0x1ab0>
    1aa6:      	cmpq	%rdx, (%rbp)
    1aaa:      	jb	0x276 <generic_retkprobe_filter_arg+0x276>
    1ab0:      	movl	0x8(%r15), %edx
    1ab4:      	cmpl	$0x11, %edx
    1ab7:      	jb	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    1abd:      	movq	0x18(%r15), %rsi
    1ac1:      	cmpl	$0x2, %eax
    1ac4:      	jle	0x1ae1 <generic_retkprobe_filter_arg+0x1ae1>
    1ac6:      	leal	-0x3(%rax), %edi
    1ac9:      	cmpl	$0x2, %edi
    1acc:      	jae	0x1b10 <generic_retkprobe_filter_arg+0x1b10>
    1ace:      	cmpq	%rsi, (%rbp)
    1ad2:      	movq	(%rsp), %rdi
    1ad6:      	jne	0x2591 <generic_retkprobe_filter_arg+0x2591>
    1adc:      	jmp	0x2e81 <generic_retkprobe_filter_arg+0x2e81>
    1ae1:      	cmpl	$0x1, %eax
    1ae4:      	je	0x1c76 <generic_retkprobe_filter_arg+0x1c76>
    1aea:      	cmpl	$0x2, %eax
    1aed:      	jne	0x2591 <generic_retkprobe_filter_arg+0x2591>
    1af3:      	cmpl	$0xc, %ecx
    1af6:      	je	0x1b01 <generic_retkprobe_filter_arg+0x1b01>
    1af8:      	cmpl	$0xa, %ecx
    1afb:      	jne	0x2587 <generic_retkprobe_filter_arg+0x2587>
    1b01:      	cmpq	%rsi, (%rbp)
    1b05:      	jl	0x276 <generic_retkprobe_filter_arg+0x276>
    1b0b:      	jmp	0x2591 <generic_retkprobe_filter_arg+0x2591>
    1b10:      	cmpl	$0xc, %eax
    1b13:      	movq	(%rsp), %rdi
    1b17:      	jne	0x2591 <generic_retkprobe_filter_arg+0x2591>
    1b1d:      	testq	%rsi, (%rbp)
    1b21:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
    1b27:      	jmp	0x2591 <generic_retkprobe_filter_arg+0x2591>
    1b2c:      	cmpl	$0xc, %eax
    1b2f:      	jne	0x1e23 <generic_retkprobe_filter_arg+0x1e23>
    1b35:      	movzbl	(%rbp), %edx
    1b39:      	testl	%edx, %ecx
    1b3b:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
    1b41:      	jmp	0x1e23 <generic_retkprobe_filter_arg+0x1e23>
    1b46:      	cmpl	$0xc, %eax
    1b49:      	jne	0x1e66 <generic_retkprobe_filter_arg+0x1e66>
    1b4f:      	movzwl	(%rbp), %edx
    1b53:      	testl	%edx, %ecx
    1b55:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
    1b5b:      	jmp	0x1e66 <generic_retkprobe_filter_arg+0x1e66>
    1b60:      	movl	0x4(%r15), %eax
    1b64:      	andl	$-0x2, %eax
    1b67:      	cmpl	$0x18, %eax
    1b6a:      	jmp	0x1ea0 <generic_retkprobe_filter_arg+0x1ea0>
    1b6f:      	cmpl	$0x101, %eax            # imm = 0x101
    1b74:      	movl	$0x100, %edi            # imm = 0x100
    1b79:      	movl	$0x1fe, %eax            # imm = 0x1FE
    1b7e:      	cmovael	%eax, %edi
    1b81:      	movl	%edi, %eax
    1b83:      	movzwl	%ax, %ecx
    1b86:      	xorl	%eax, %eax
    1b88:      	cmpl	$0x100, %ecx            # imm = 0x100
    1b8e:      	sete	%al
    1b91:      	xorl	$0x7, %eax
    1b94:      	movl	%eax, %ecx
    1b96:      	andl	$0xf, %ecx
    1b99:      	movl	0x10(%r15,%rcx,4), %ecx
    1b9e:      	cmpl	$-0x1, %ecx
    1ba1:      	je	0x2c5b <generic_retkprobe_filter_arg+0x2c5b>
    1ba7:      	movl	%ecx, 0x90(%rsp)
    1bae:      	movq	%rdi, 0x88(%rsp)
    1bb6:      	movl	%eax, 0x60(%rsp)
    1bba:      	movq	%rsi, 0x20(%rsp)
    1bbf:      	movl	$0x1, %eax
    1bc4:      	movq	(%rip), %rdi            # 0x1bcb <generic_retkprobe_filter_arg+0x1bcb>
    1bcb:      	movq	0x30(%rsp), %rbx
    1bd0:      	movq	%rbx, %rsi
    1bd3:      	callq	*%rax
    1bd5:      	movq	%rax, 0x18(%rsp)
    1bda:      	movl	$0x1, %eax
    1bdf:      	movq	(%rip), %rdi            # 0x1be6 <generic_retkprobe_filter_arg+0x1be6>
    1be6:      	movq	%rbx, %rsi
    1be9:      	callq	*%rax
    1beb:      	cmpq	$0x0, 0x18(%rsp)
    1bf1:      	je	0x2c5b <generic_retkprobe_filter_arg+0x2c5b>
    1bf7:      	movl	$0x0, %ebx
    1bfc:      	testq	%rax, %rax
    1bff:      	movq	(%rsp), %rdi
    1c03:      	movq	0x8(%rsp), %r9
    1c08:      	movq	0x10(%rsp), %r11
    1c0d:      	je	0x2c6b <generic_retkprobe_filter_arg+0x2c6b>
    1c13:      	movq	%rax, 0x98(%rsp)
    1c1b:      	movl	0x60(%rsp), %ebx
    1c1f:      	cmpl	$0x5, %ebx
    1c22:      	jg	0x2466 <generic_retkprobe_filter_arg+0x2466>
    1c28:      	movq	0x18(%rsp), %rax
    1c2d:      	movb	%bpl, (%rax)
    1c30:      	leaq	0x1(%rax), %rdi
    1c34:      	movl	$0x4, %eax
    1c39:      	movq	0x20(%rsp), %rdx
    1c3e:      	movl	%ebp, %esi
    1c40:      	callq	*%rax
    1c42:      	movq	0x88(%rsp), %rsi
    1c4a:      	subl	%ebp, %esi
    1c4c:      	jbe	0x24ae <generic_retkprobe_filter_arg+0x24ae>
    1c52:      	movq	0x18(%rsp), %rax
    1c57:      	leaq	(%rax,%rbp), %rdi
    1c5b:      	incq	%rdi
    1c5e:      	andl	$0xfff, %esi            # imm = 0xFFF
    1c64:      	movl	$0x4, %eax
    1c69:      	movq	0x98(%rsp), %rdx
    1c71:      	jmp	0x24ac <generic_retkprobe_filter_arg+0x24ac>
    1c76:      	cmpl	$0xc, %ecx
    1c79:      	je	0x1c84 <generic_retkprobe_filter_arg+0x1c84>
    1c7b:      	cmpl	$0xa, %ecx
    1c7e:      	jne	0x257b <generic_retkprobe_filter_arg+0x257b>
    1c84:      	cmpq	%rsi, (%rbp)
    1c88:      	jg	0x276 <generic_retkprobe_filter_arg+0x276>
    1c8e:      	jmp	0x2591 <generic_retkprobe_filter_arg+0x2591>
    1c93:      	movl	0x8(%r15), %edx
    1c97:      	movzbl	(%rbp), %ecx
    1c9b:      	jmp	0x1ca5 <generic_retkprobe_filter_arg+0x1ca5>
    1c9d:      	movl	0x8(%r15), %edx
    1ca1:      	movzwl	(%rbp), %ecx
    1ca5:      	cmpl	%ecx, 0x10(%r15)
    1ca9:      	setbe	%sil
    1cad:      	cmpl	%ecx, 0x14(%r15)
    1cb1:      	setae	%al
    1cb4:      	andb	%sil, %al
    1cb7:      	cmpl	$0x11, %edx
    1cba:      	jb	0x2af3 <generic_retkprobe_filter_arg+0x2af3>
    1cc0:      	cmpl	%ecx, 0x18(%r15)
    1cc4:      	setbe	%sil
    1cc8:      	cmpl	%ecx, 0x1c(%r15)
    1ccc:      	setae	%dil
    1cd0:      	andb	%sil, %dil
    1cd3:      	orb	%dil, %al
    1cd6:      	cmpl	$0x19, %edx
    1cd9:      	jb	0x2aef <generic_retkprobe_filter_arg+0x2aef>
    1cdf:      	cmpl	%ecx, 0x20(%r15)
    1ce3:      	setbe	%sil
    1ce7:      	cmpl	%ecx, 0x24(%r15)
    1ceb:      	setae	%dil
    1cef:      	andb	%sil, %dil
    1cf2:      	orb	%dil, %al
    1cf5:      	cmpl	$0x21, %edx
    1cf8:      	jb	0x2aef <generic_retkprobe_filter_arg+0x2aef>
    1cfe:      	cmpl	%ecx, 0x28(%r15)
    1d02:      	setbe	%dl
    1d05:      	cmpl	%ecx, 0x2c(%r15)
    1d09:      	setae	%cl
    1d0c:      	andb	%dl, %cl
    1d0e:      	orb	%cl, %al
    1d10:      	jmp	0x2aef <generic_retkprobe_filter_arg+0x2aef>
    1d15:      	xorl	%ebx, %ebx
    1d17:      	xorl	%r12d, %r12d
    1d1a:      	movl	0x10(%r15,%rbx,4), %eax
    1d1f:      	movl	%eax, 0x38(%rsp)
    1d23:      	movl	$0x1, %eax
    1d28:      	leaq	0x38(%rsp), %rsi
    1d2d:      	movq	(%rip), %rdi            # 0x1d34 <generic_retkprobe_filter_arg+0x1d34>
    1d34:      	callq	*%rax
    1d36:      	testq	%rax, %rax
    1d39:      	je	0x2683 <generic_retkprobe_filter_arg+0x2683>
    1d3f:      	testl	%ebp, %ebp
    1d41:      	movq	0x8(%rsp), %r9
    1d46:      	movq	0x10(%rsp), %r11
    1d4b:      	je	0x1d9f <generic_retkprobe_filter_arg+0x1d9f>
    1d4d:      	movq	0x20(%rsp), %rdx
    1d52:      	xorl	%ecx, %ecx
    1d54:      	jmp	0x1d61 <generic_retkprobe_filter_arg+0x1d61>
    1d56:      	incq	%rcx
    1d59:      	incq	%rdx
    1d5c:      	cmpq	%rbp, %rcx
    1d5f:      	je	0x1d9f <generic_retkprobe_filter_arg+0x1d9f>
    1d61:      	xorl	%esi, %esi
    1d63:      	nopw	%cs:(%rax,%rax)
    1d70:      	leaq	(%rcx,%rsi), %rdi
    1d74:      	cmpq	%rbp, %rdi
    1d77:      	jae	0x1d56 <generic_retkprobe_filter_arg+0x1d56>
    1d79:      	movzbl	(%rax,%rsi), %edi
    1d7d:      	testb	%dil, %dil
    1d80:      	je	0x1d97 <generic_retkprobe_filter_arg+0x1d97>
    1d82:      	cmpq	$0x62, %rsi
    1d86:      	ja	0x1d56 <generic_retkprobe_filter_arg+0x1d56>
    1d88:      	leaq	0x1(%rsi), %r8
    1d8c:      	cmpb	%dil, (%rdx,%rsi)
    1d90:      	movq	%r8, %rsi
    1d93:      	je	0x1d70 <generic_retkprobe_filter_arg+0x1d70>
    1d95:      	jmp	0x1d56 <generic_retkprobe_filter_arg+0x1d56>
    1d97:      	testl	%ecx, %ecx
    1d99:      	jns	0x297d <generic_retkprobe_filter_arg+0x297d>
    1d9f:      	leal	0xc(%r12), %eax
    1da4:      	cmpl	0x8(%r15), %eax
    1da8:      	jae	0x1dbb <generic_retkprobe_filter_arg+0x1dbb>
    1daa:      	addl	$0x4, %r12d
    1dae:      	incq	%rbx
    1db1:      	cmpq	$0x64, %rbx
    1db5:      	jne	0x1d1a <generic_retkprobe_filter_arg+0x1d1a>
    1dbb:      	xorl	%ebx, %ebx
    1dbd:      	movq	(%rsp), %rdi
    1dc1:      	jmp	0x2ef2 <generic_retkprobe_filter_arg+0x2ef2>
    1dc6:      	movzwl	%bp, %eax
    1dc9:      	cmpl	$0x90, %eax
    1dce:      	ja	0x223c <generic_retkprobe_filter_arg+0x223c>
    1dd4:      	testw	%bp, %bp
    1dd7:      	je	0x1de9 <generic_retkprobe_filter_arg+0x1de9>
    1dd9:      	movl	%ebp, %eax
    1ddb:      	movl	$0x18, %ecx
    1de0:      	cltd
    1de1:      	idivl	%ecx
    1de3:      	movl	%ebp, %edi
    1de5:      	testl	%edx, %edx
    1de7:      	je	0x1e0b <generic_retkprobe_filter_arg+0x1e0b>
    1de9:      	movl	%ebp, %eax
    1deb:      	movl	$0x18, %ecx
    1df0:      	cltd
    1df1:      	idivl	%ecx
    1df3:      	shll	$0x3, %eax
    1df6:      	leal	(%rax,%rax,2), %eax
    1df9:      	addl	$0x18, %eax
    1dfc:      	movzwl	%ax, %edi
    1dff:      	cmpl	$0x90, %edi
    1e05:      	ja	0x2250 <generic_retkprobe_filter_arg+0x2250>
    1e0b:      	movl	%edi, %eax
    1e0d:      	cltd
    1e0e:      	idivl	%ecx
    1e10:      	decl	%eax
    1e12:      	jmp	0x2261 <generic_retkprobe_filter_arg+0x2261>
    1e17:      	movzbl	(%rbp), %edx
    1e1b:      	cmpl	%edx, %ecx
    1e1d:      	jb	0x276 <generic_retkprobe_filter_arg+0x276>
    1e23:      	movl	0x8(%r15), %ecx
    1e27:      	cmpl	$0xd, %ecx
    1e2a:      	jb	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    1e30:      	movl	0x14(%r15), %edx
    1e34:      	cmpl	$0x2, %eax
    1e37:      	jle	0x2126 <generic_retkprobe_filter_arg+0x2126>
    1e3d:      	leal	-0x3(%rax), %esi
    1e40:      	cmpl	$0x2, %esi
    1e43:      	jae	0x2609 <generic_retkprobe_filter_arg+0x2609>
    1e49:      	movzbl	(%rbp), %esi
    1e4d:      	cmpl	%esi, %edx
    1e4f:      	jne	0x26fe <generic_retkprobe_filter_arg+0x26fe>
    1e55:      	jmp	0x2e81 <generic_retkprobe_filter_arg+0x2e81>
    1e5a:      	movzwl	(%rbp), %edx
    1e5e:      	cmpl	%edx, %ecx
    1e60:      	jb	0x276 <generic_retkprobe_filter_arg+0x276>
    1e66:      	movl	0x8(%r15), %ecx
    1e6a:      	cmpl	$0xd, %ecx
    1e6d:      	jb	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    1e73:      	movl	0x14(%r15), %edx
    1e77:      	cmpl	$0x2, %eax
    1e7a:      	jle	0x2149 <generic_retkprobe_filter_arg+0x2149>
    1e80:      	leal	-0x3(%rax), %esi
    1e83:      	cmpl	$0x2, %esi
    1e86:      	jae	0x2623 <generic_retkprobe_filter_arg+0x2623>
    1e8c:      	movzwl	(%rbp), %esi
    1e90:      	cmpl	%esi, %edx
    1e92:      	jne	0x273d <generic_retkprobe_filter_arg+0x273d>
    1e98:      	jmp	0x2e81 <generic_retkprobe_filter_arg+0x2e81>
    1e9d:      	testq	%rax, %rax
    1ea0:      	sete	%al
    1ea3:      	movq	(%rsp), %rdi
    1ea7:      	movq	0x8(%rsp), %r9
    1eac:      	movq	0x10(%rsp), %r11
    1eb1:      	movzbl	%al, %ebx
    1eb4:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    1eb9:      	movl	(%rbp), %eax
    1ebc:      	cmpl	%eax, %esi
    1ebe:      	ja	0x1ec8 <generic_retkprobe_filter_arg+0x1ec8>
    1ec0:      	cmpl	%edx, %eax
    1ec2:      	jbe	0x276 <generic_retkprobe_filter_arg+0x276>
    1ec8:      	movl	0x8(%r15), %edx
    1ecc:      	cmpl	$0x11, %edx
    1ecf:      	jb	0xb8 <generic_retkprobe_filter_arg+0xb8>
    1ed5:      	movl	0x18(%r15), %edi
    1ed9:      	movl	0x1c(%r15), %esi
    1edd:      	cmpl	$0xc, %ecx
    1ee0:      	ja	0x2384 <generic_retkprobe_filter_arg+0x2384>
    1ee6:      	movl	$0x1402, %r8d           # imm = 0x1402
    1eec:      	btl	%ecx, %r8d
    1ef0:      	jae	0x2384 <generic_retkprobe_filter_arg+0x2384>
    1ef6:      	cmpl	%eax, %edi
    1ef8:      	movq	(%rsp), %rdi
    1efc:      	jg	0x2394 <generic_retkprobe_filter_arg+0x2394>
    1f02:      	cmpl	%esi, %eax
    1f04:      	jle	0x276 <generic_retkprobe_filter_arg+0x276>
    1f0a:      	jmp	0x2394 <generic_retkprobe_filter_arg+0x2394>
    1f0f:      	movl	(%rbp), %edx
    1f12:      	cmpl	%edx, %esi
    1f14:      	setbe	%sil
    1f18:      	cmpl	%eax, %edx
    1f1a:      	setbe	%al
    1f1d:      	andb	%sil, %al
    1f20:      	movl	0x8(%r15), %esi
    1f24:      	cmpl	$0x11, %esi
    1f27:      	jb	0x2af3 <generic_retkprobe_filter_arg+0x2af3>
    1f2d:      	movl	0x18(%r15), %r8d
    1f31:      	movl	0x1c(%r15), %edi
    1f35:      	cmpl	$0xc, %ecx
    1f38:      	ja	0x2335 <generic_retkprobe_filter_arg+0x2335>
    1f3e:      	movl	$0x1402, %r10d          # imm = 0x1402
    1f44:      	btl	%ecx, %r10d
    1f48:      	jae	0x2335 <generic_retkprobe_filter_arg+0x2335>
    1f4e:      	cmpl	%edx, %r8d
    1f51:      	setle	%r8b
    1f55:      	cmpl	%edi, %edx
    1f57:      	setle	%dil
    1f5b:      	jmp	0x2342 <generic_retkprobe_filter_arg+0x2342>
    1f60:      	cmpq	%rdx, %r8
    1f63:      	setbe	%r8b
    1f67:      	cmpq	%rdi, %rdx
    1f6a:      	setbe	%dil
    1f6e:      	andb	%r8b, %dil
    1f71:      	orb	%dil, %al
    1f74:      	cmpl	$0x29, %esi
    1f77:      	jb	0x2aef <generic_retkprobe_filter_arg+0x2aef>
    1f7d:      	movq	0x30(%r15), %r8
    1f81:      	movq	0x38(%r15), %rdi
    1f85:      	cmpl	$0xc, %ecx
    1f88:      	je	0x1f93 <generic_retkprobe_filter_arg+0x1f93>
    1f8a:      	cmpl	$0xa, %ecx
    1f8d:      	jne	0x241e <generic_retkprobe_filter_arg+0x241e>
    1f93:      	cmpq	%rdx, %r8
    1f96:      	setle	%r8b
    1f9a:      	cmpq	%rdi, %rdx
    1f9d:      	setle	%dil
    1fa1:      	jmp	0x242c <generic_retkprobe_filter_arg+0x242c>
    1fa6:      	cmpq	%rax, %rdi
    1fa9:      	movq	(%rsp), %rdi
    1fad:      	ja	0x1fb8 <generic_retkprobe_filter_arg+0x1fb8>
    1faf:      	cmpq	%rsi, %rax
    1fb2:      	jbe	0x276 <generic_retkprobe_filter_arg+0x276>
    1fb8:      	cmpl	$0x29, %edx
    1fbb:      	jb	0xb8 <generic_retkprobe_filter_arg+0xb8>
    1fc1:      	movq	0x30(%r15), %rdi
    1fc5:      	movq	0x38(%r15), %rsi
    1fc9:      	cmpl	$0xc, %ecx
    1fcc:      	je	0x1fd7 <generic_retkprobe_filter_arg+0x1fd7>
    1fce:      	cmpl	$0xa, %ecx
    1fd1:      	jne	0x2533 <generic_retkprobe_filter_arg+0x2533>
    1fd7:      	cmpq	%rax, %rdi
    1fda:      	movq	(%rsp), %rdi
    1fde:      	jg	0x2545 <generic_retkprobe_filter_arg+0x2545>
    1fe4:      	cmpq	%rsi, %rax
    1fe7:      	jle	0x276 <generic_retkprobe_filter_arg+0x276>
    1fed:      	jmp	0x2545 <generic_retkprobe_filter_arg+0x2545>
    1ff2:      	xorl	%ebx, %ebx
    1ff4:      	cmpl	$0x29, %ecx
    1ff7:      	jne	0x2002 <generic_retkprobe_filter_arg+0x2002>
    1ff9:      	testq	%rdx, %rdx
    1ffc:      	je	0x2002 <generic_retkprobe_filter_arg+0x2002>
    1ffe:      	movzbl	0x3a(%rdx), %ebx
    2002:      	cmpl	$0x29, %ecx
    2005:      	je	0x2010 <generic_retkprobe_filter_arg+0x2010>
    2007:      	cmpl	$0x7, %ecx
    200a:      	jne	0x245f <generic_retkprobe_filter_arg+0x245f>
    2010:      	movzbl	0x10(%r15), %eax
    2015:      	movl	%eax, 0x2c(%rsp)
    2019:      	movl	$0x1, %eax
    201e:      	movq	(%rip), %rdi            # 0x2025 <generic_retkprobe_filter_arg+0x2025>
    2025:      	leaq	0x2c(%rsp), %rsi
    202a:      	callq	*%rax
    202c:      	testq	%rax, %rax
    202f:      	je	0x250 <generic_retkprobe_filter_arg+0x250>
    2035:      	movq	%rax, %rdi
    2038:      	movl	%ebx, %eax
    203a:      	movq	%rax, 0x70(%rsp)
    203f:      	movl	$0x1, %eax
    2044:      	movq	0x30(%rsp), %rsi
    2049:      	jmp	0x1a51 <generic_retkprobe_filter_arg+0x1a51>
    204e:      	cmpl	%edx, (%rbp)
    2051:      	ja	0x276 <generic_retkprobe_filter_arg+0x276>
    2057:      	jmp	0x2062 <generic_retkprobe_filter_arg+0x2062>
    2059:      	cmpl	%edx, (%rbp)
    205c:      	jb	0x276 <generic_retkprobe_filter_arg+0x276>
    2062:      	movl	0x8(%r15), %edx
    2066:      	cmpl	$0xd, %edx
    2069:      	jb	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    206f:      	movl	0x14(%r15), %esi
    2073:      	cmpl	$0x2, %eax
    2076:      	jle	0x2092 <generic_retkprobe_filter_arg+0x2092>
    2078:      	leal	-0x3(%rax), %edi
    207b:      	cmpl	$0x2, %edi
    207e:      	jae	0x20c7 <generic_retkprobe_filter_arg+0x20c7>
    2080:      	cmpl	%esi, (%rbp)
    2083:      	movq	(%rsp), %rdi
    2087:      	jne	0x281f <generic_retkprobe_filter_arg+0x281f>
    208d:      	jmp	0x2e81 <generic_retkprobe_filter_arg+0x2e81>
    2092:      	cmpl	$0x1, %eax
    2095:      	je	0x20e2 <generic_retkprobe_filter_arg+0x20e2>
    2097:      	cmpl	$0x2, %eax
    209a:      	jne	0x281f <generic_retkprobe_filter_arg+0x281f>
    20a0:      	cmpl	$0xc, %ecx
    20a3:      	ja	0x2816 <generic_retkprobe_filter_arg+0x2816>
    20a9:      	movl	$0x1402, %r8d           # imm = 0x1402
    20af:      	btl	%ecx, %r8d
    20b3:      	jae	0x2816 <generic_retkprobe_filter_arg+0x2816>
    20b9:      	cmpl	%esi, (%rbp)
    20bc:      	jl	0x276 <generic_retkprobe_filter_arg+0x276>
    20c2:      	jmp	0x281f <generic_retkprobe_filter_arg+0x281f>
    20c7:      	cmpl	$0xc, %eax
    20ca:      	movq	(%rsp), %rdi
    20ce:      	jne	0x281f <generic_retkprobe_filter_arg+0x281f>
    20d4:      	testl	%esi, (%rbp)
    20d7:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
    20dd:      	jmp	0x281f <generic_retkprobe_filter_arg+0x281f>
    20e2:      	cmpl	$0xc, %ecx
    20e5:      	ja	0x280b <generic_retkprobe_filter_arg+0x280b>
    20eb:      	movl	$0x1402, %r8d           # imm = 0x1402
    20f1:      	btl	%ecx, %r8d
    20f5:      	jae	0x280b <generic_retkprobe_filter_arg+0x280b>
    20fb:      	cmpl	%esi, (%rbp)
    20fe:      	jg	0x276 <generic_retkprobe_filter_arg+0x276>
    2104:      	jmp	0x281f <generic_retkprobe_filter_arg+0x281f>
    2109:      	xorl	%ebx, %ebx
    210b:      	movq	0x8(%rsp), %r9
    2110:      	movq	0x10(%rsp), %r11
    2115:      	jmp	0x23dc <generic_retkprobe_filter_arg+0x23dc>
    211a:      	xorl	%ebx, %ebx
    211c:      	movq	0x10(%rsp), %r11
    2121:      	jmp	0x23fd <generic_retkprobe_filter_arg+0x23fd>
    2126:      	cmpl	$0x1, %eax
    2129:      	je	0x26f2 <generic_retkprobe_filter_arg+0x26f2>
    212f:      	cmpl	$0x2, %eax
    2132:      	jne	0x26fe <generic_retkprobe_filter_arg+0x26fe>
    2138:      	movzbl	(%rbp), %esi
    213c:      	cmpl	%esi, %edx
    213e:      	ja	0x276 <generic_retkprobe_filter_arg+0x276>
    2144:      	jmp	0x26fe <generic_retkprobe_filter_arg+0x26fe>
    2149:      	cmpl	$0x1, %eax
    214c:      	je	0x2731 <generic_retkprobe_filter_arg+0x2731>
    2152:      	cmpl	$0x2, %eax
    2155:      	jne	0x273d <generic_retkprobe_filter_arg+0x273d>
    215b:      	movzwl	(%rbp), %esi
    215f:      	cmpl	%esi, %edx
    2161:      	ja	0x276 <generic_retkprobe_filter_arg+0x276>
    2167:      	jmp	0x273d <generic_retkprobe_filter_arg+0x273d>
    216c:      	movq	0x18(%rsp), %rax
    2171:      	movw	%bp, (%rax)
    2174:      	leaq	0x2(%rax), %rdi
    2178:      	movl	$0x4, %eax
    217d:      	movl	%ebp, %esi
    217f:      	callq	*%rax
    2181:      	movq	0x88(%rsp), %rsi
    2189:      	subl	%ebp, %esi
    218b:      	jbe	0x21af <generic_retkprobe_filter_arg+0x21af>
    218d:      	movq	0x18(%rsp), %rax
    2192:      	leaq	(%rax,%rbp), %rdi
    2196:      	addq	$0x2, %rdi
    219a:      	andl	$0xfff, %esi            # imm = 0xFFF
    21a0:      	movl	$0x4, %eax
    21a5:      	movq	0x98(%rsp), %rdx
    21ad:      	callq	*%rax
    21af:      	movl	0x90(%rsp), %eax
    21b6:      	movl	%eax, 0x38(%rsp)
    21ba:      	cmpl	$0x3, %ebx
    21bd:      	jg	0x21fd <generic_retkprobe_filter_arg+0x21fd>
    21bf:      	cmpl	$0x1, %ebx
    21c2:      	movq	(%rsp), %rdi
    21c6:      	movq	0x8(%rsp), %r9
    21cb:      	movq	0x10(%rsp), %r11
    21d0:      	jg	0x2698 <generic_retkprobe_filter_arg+0x2698>
    21d6:      	testl	%ebx, %ebx
    21d8:      	je	0x2a3c <generic_retkprobe_filter_arg+0x2a3c>
    21de:      	cmpl	$0x1, %ebx
    21e1:      	jne	0x845 <generic_retkprobe_filter_arg+0x845>
    21e7:      	movl	$0x1, %eax
    21ec:      	leaq	0x38(%rsp), %rsi
    21f1:      	movq	(%rip), %rdi            # 0x21f8 <generic_retkprobe_filter_arg+0x21f8>
    21f8:      	jmp	0x2a86 <generic_retkprobe_filter_arg+0x2a86>
    21fd:      	cmpl	$0x5, %ebx
    2200:      	movq	(%rsp), %rdi
    2204:      	movq	0x8(%rsp), %r9
    2209:      	movq	0x10(%rsp), %r11
    220e:      	jg	0x26c0 <generic_retkprobe_filter_arg+0x26c0>
    2214:      	cmpl	$0x4, %ebx
    2217:      	je	0x2a4f <generic_retkprobe_filter_arg+0x2a4f>
    221d:      	cmpl	$0x5, %ebx
    2220:      	jne	0x845 <generic_retkprobe_filter_arg+0x845>
    2226:      	movl	$0x1, %eax
    222b:      	leaq	0x38(%rsp), %rsi
    2230:      	movq	(%rip), %rdi            # 0x2237 <generic_retkprobe_filter_arg+0x2237>
    2237:      	jmp	0x2a86 <generic_retkprobe_filter_arg+0x2a86>
    223c:      	cmpl	$0x101, %eax            # imm = 0x101
    2241:      	movl	$0x100, %edi            # imm = 0x100
    2246:      	movl	$0x1fe, %eax            # imm = 0x1FE
    224b:      	cmovael	%eax, %edi
    224e:      	movl	%edi, %eax
    2250:      	movzwl	%ax, %ecx
    2253:      	xorl	%eax, %eax
    2255:      	cmpl	$0x100, %ecx            # imm = 0x100
    225b:      	sete	%al
    225e:      	xorl	$0x7, %eax
    2261:      	movl	%eax, %ecx
    2263:      	andl	$0xf, %ecx
    2266:      	movl	0x10(%r15,%rcx,4), %ecx
    226b:      	cmpl	$-0x1, %ecx
    226e:      	je	0x2ee2 <generic_retkprobe_filter_arg+0x2ee2>
    2274:      	movl	%ecx, 0x88(%rsp)
    227b:      	movq	%rdi, 0x90(%rsp)
    2283:      	movl	%eax, 0x18(%rsp)
    2287:      	movq	%rsi, 0x20(%rsp)
    228c:      	movl	$0x1, %eax
    2291:      	movq	(%rip), %rdi            # 0x2298 <generic_retkprobe_filter_arg+0x2298>
    2298:      	movq	0x30(%rsp), %rbx
    229d:      	movq	%rbx, %rsi
    22a0:      	callq	*%rax
    22a2:      	movq	%rax, 0x60(%rsp)
    22a7:      	movl	$0x1, %eax
    22ac:      	movq	(%rip), %rdi            # 0x22b3 <generic_retkprobe_filter_arg+0x22b3>
    22b3:      	movq	%rbx, %rsi
    22b6:      	callq	*%rax
    22b8:      	movq	0x60(%rsp), %rdx
    22bd:      	testq	%rdx, %rdx
    22c0:      	je	0x2ee2 <generic_retkprobe_filter_arg+0x2ee2>
    22c6:      	movl	$0x0, %ebx
    22cb:      	testq	%rax, %rax
    22ce:      	movq	(%rsp), %rdi
    22d2:      	movq	0x8(%rsp), %r9
    22d7:      	movq	0x10(%rsp), %r11
    22dc:      	je	0x2ef2 <generic_retkprobe_filter_arg+0x2ef2>
    22e2:      	movq	%rdx, %rcx
    22e5:      	movq	%rax, %r12
    22e8:      	cmpl	$0x5, 0x18(%rsp)
    22ed:      	jg	0x298b <generic_retkprobe_filter_arg+0x298b>
    22f3:      	movq	%rcx, %rbx
    22f6:      	movb	%bpl, (%rcx)
    22f9:      	leaq	0x1(%rcx), %rdi
    22fd:      	movl	$0x4, %eax
    2302:      	movq	0x20(%rsp), %rdx
    2307:      	movl	%ebp, %esi
    2309:      	callq	*%rax
    230b:      	movq	0x90(%rsp), %rsi
    2313:      	subl	%ebp, %esi
    2315:      	jbe	0x29c7 <generic_retkprobe_filter_arg+0x29c7>
    231b:      	leaq	(%rbx,%rbp), %rdi
    231f:      	incq	%rdi
    2322:      	andl	$0xfff, %esi            # imm = 0xFFF
    2328:      	movl	$0x4, %eax
    232d:      	movq	%r12, %rdx
    2330:      	jmp	0x29c5 <generic_retkprobe_filter_arg+0x29c5>
    2335:      	cmpl	%edx, %r8d
    2338:      	setbe	%r8b
    233c:      	cmpl	%edi, %edx
    233e:      	setbe	%dil
    2342:      	andb	%r8b, %dil
    2345:      	orb	%dil, %al
    2348:      	cmpl	$0x19, %esi
    234b:      	jb	0x2aef <generic_retkprobe_filter_arg+0x2aef>
    2351:      	movl	0x20(%r15), %r8d
    2355:      	movl	0x24(%r15), %edi
    2359:      	cmpl	$0xc, %ecx
    235c:      	ja	0x2770 <generic_retkprobe_filter_arg+0x2770>
    2362:      	movl	$0x1402, %r10d          # imm = 0x1402
    2368:      	btl	%ecx, %r10d
    236c:      	jae	0x2770 <generic_retkprobe_filter_arg+0x2770>
    2372:      	cmpl	%edx, %r8d
    2375:      	setle	%r8b
    2379:      	cmpl	%edi, %edx
    237b:      	setle	%dil
    237f:      	jmp	0x277d <generic_retkprobe_filter_arg+0x277d>
    2384:      	cmpl	%eax, %edi
    2386:      	movq	(%rsp), %rdi
    238a:      	ja	0x2394 <generic_retkprobe_filter_arg+0x2394>
    238c:      	cmpl	%esi, %eax
    238e:      	jbe	0x276 <generic_retkprobe_filter_arg+0x276>
    2394:      	cmpl	$0x19, %edx
    2397:      	jb	0xb8 <generic_retkprobe_filter_arg+0xb8>
    239d:      	movl	0x20(%r15), %edi
    23a1:      	movl	0x24(%r15), %esi
    23a5:      	cmpl	$0xc, %ecx
    23a8:      	ja	0x27bc <generic_retkprobe_filter_arg+0x27bc>
    23ae:      	movl	$0x1402, %r8d           # imm = 0x1402
    23b4:      	btl	%ecx, %r8d
    23b8:      	jae	0x27bc <generic_retkprobe_filter_arg+0x27bc>
    23be:      	cmpl	%eax, %edi
    23c0:      	movq	(%rsp), %rdi
    23c4:      	jg	0x27cc <generic_retkprobe_filter_arg+0x27cc>
    23ca:      	cmpl	%esi, %eax
    23cc:      	jle	0x276 <generic_retkprobe_filter_arg+0x276>
    23d2:      	jmp	0x27cc <generic_retkprobe_filter_arg+0x27cc>
    23d7:      	movl	$0x1, %ebx
    23dc:      	movq	0x68(%rsp), %r12
    23e1:      	movq	(%rsp), %rdi
    23e5:      	movl	0x4(%r15), %eax
    23e9:      	cmpq	$0x25, %rax
    23ed:      	jbe	0x2c79 <generic_retkprobe_filter_arg+0x2c79>
    23f3:      	jmp	0x265 <generic_retkprobe_filter_arg+0x265>
    23f8:      	movl	$0x1, %ebx
    23fd:      	movq	0x68(%rsp), %r12
    2402:      	movq	(%rsp), %rdi
    2406:      	movq	0x8(%rsp), %r9
    240b:      	movl	0x4(%r15), %eax
    240f:      	cmpq	$0x25, %rax
    2413:      	jbe	0x2c79 <generic_retkprobe_filter_arg+0x2c79>
    2419:      	jmp	0x265 <generic_retkprobe_filter_arg+0x265>
    241e:      	cmpq	%rdx, %r8
    2421:      	setbe	%r8b
    2425:      	cmpq	%rdi, %rdx
    2428:      	setbe	%dil
    242c:      	andb	%r8b, %dil
    242f:      	orb	%dil, %al
    2432:      	cmpl	$0x39, %esi
    2435:      	jb	0x2aef <generic_retkprobe_filter_arg+0x2aef>
    243b:      	movq	0x40(%r15), %rdi
    243f:      	movq	0x48(%r15), %rsi
    2443:      	cmpl	$0xc, %ecx
    2446:      	je	0x2451 <generic_retkprobe_filter_arg+0x2451>
    2448:      	cmpl	$0xa, %ecx
    244b:      	jne	0x28c2 <generic_retkprobe_filter_arg+0x28c2>
    2451:      	cmpq	%rdx, %rdi
    2454:      	setle	%cl
    2457:      	cmpq	%rsi, %rdx
    245a:      	jmp	0x27b4 <generic_retkprobe_filter_arg+0x27b4>
    245f:      	xorl	%ebx, %ebx
    2461:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    2466:      	movq	0x18(%rsp), %rax
    246b:      	movw	%bp, (%rax)
    246e:      	leaq	0x2(%rax), %rdi
    2472:      	movl	$0x4, %eax
    2477:      	movq	0x20(%rsp), %rdx
    247c:      	movl	%ebp, %esi
    247e:      	callq	*%rax
    2480:      	movq	0x88(%rsp), %rsi
    2488:      	subl	%ebp, %esi
    248a:      	jbe	0x24ae <generic_retkprobe_filter_arg+0x24ae>
    248c:      	movq	0x18(%rsp), %rax
    2491:      	leaq	(%rax,%rbp), %rdi
    2495:      	addq	$0x2, %rdi
    2499:      	andl	$0xfff, %esi            # imm = 0xFFF
    249f:      	movl	$0x4, %eax
    24a4:      	movq	0x98(%rsp), %rdx
    24ac:      	callq	*%rax
    24ae:      	movl	0x90(%rsp), %eax
    24b5:      	movl	%eax, 0x38(%rsp)
    24b9:      	cmpl	$0x3, %ebx
    24bc:      	jg	0x24f8 <generic_retkprobe_filter_arg+0x24f8>
    24be:      	cmpl	$0x1, %ebx
    24c1:      	movq	0x8(%rsp), %r9
    24c6:      	movq	0x10(%rsp), %r11
    24cb:      	jg	0x28d0 <generic_retkprobe_filter_arg+0x28d0>
    24d1:      	testl	%ebx, %ebx
    24d3:      	je	0x2bf1 <generic_retkprobe_filter_arg+0x2bf1>
    24d9:      	cmpl	$0x1, %ebx
    24dc:      	jne	0x2c92 <generic_retkprobe_filter_arg+0x2c92>
    24e2:      	movl	$0x1, %eax
    24e7:      	leaq	0x38(%rsp), %rsi
    24ec:      	movq	(%rip), %rdi            # 0x24f3 <generic_retkprobe_filter_arg+0x24f3>
    24f3:      	jmp	0x2c3b <generic_retkprobe_filter_arg+0x2c3b>
    24f8:      	cmpl	$0x5, %ebx
    24fb:      	movq	0x8(%rsp), %r9
    2500:      	movq	0x10(%rsp), %r11
    2505:      	jg	0x28f8 <generic_retkprobe_filter_arg+0x28f8>
    250b:      	cmpl	$0x4, %ebx
    250e:      	je	0x2c04 <generic_retkprobe_filter_arg+0x2c04>
    2514:      	cmpl	$0x5, %ebx
    2517:      	jne	0x2c92 <generic_retkprobe_filter_arg+0x2c92>
    251d:      	movl	$0x1, %eax
    2522:      	leaq	0x38(%rsp), %rsi
    2527:      	movq	(%rip), %rdi            # 0x252e <generic_retkprobe_filter_arg+0x252e>
    252e:      	jmp	0x2c3b <generic_retkprobe_filter_arg+0x2c3b>
    2533:      	cmpq	%rax, %rdi
    2536:      	movq	(%rsp), %rdi
    253a:      	ja	0x2545 <generic_retkprobe_filter_arg+0x2545>
    253c:      	cmpq	%rsi, %rax
    253f:      	jbe	0x276 <generic_retkprobe_filter_arg+0x276>
    2545:      	cmpl	$0x39, %edx
    2548:      	jb	0xb8 <generic_retkprobe_filter_arg+0xb8>
    254e:      	movq	0x40(%r15), %rsi
    2552:      	movq	0x48(%r15), %rdx
    2556:      	cmpl	$0xc, %ecx
    2559:      	je	0x2564 <generic_retkprobe_filter_arg+0x2564>
    255b:      	cmpl	$0xa, %ecx
    255e:      	jne	0x2920 <generic_retkprobe_filter_arg+0x2920>
    2564:      	cmpq	%rax, %rsi
    2567:      	jg	0xb8 <generic_retkprobe_filter_arg+0xb8>
    256d:      	cmpq	%rdx, %rax
    2570:      	jle	0x276 <generic_retkprobe_filter_arg+0x276>
    2576:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
    257b:      	cmpq	%rsi, (%rbp)
    257f:      	ja	0x276 <generic_retkprobe_filter_arg+0x276>
    2585:      	jmp	0x2591 <generic_retkprobe_filter_arg+0x2591>
    2587:      	cmpq	%rsi, (%rbp)
    258b:      	jb	0x276 <generic_retkprobe_filter_arg+0x276>
    2591:      	cmpl	$0x19, %edx
    2594:      	jb	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    259a:      	movq	0x20(%r15), %rsi
    259e:      	cmpl	$0x2, %eax
    25a1:      	jle	0x25be <generic_retkprobe_filter_arg+0x25be>
    25a3:      	leal	-0x3(%rax), %edi
    25a6:      	cmpl	$0x2, %edi
    25a9:      	jae	0x25ed <generic_retkprobe_filter_arg+0x25ed>
    25ab:      	cmpq	%rsi, (%rbp)
    25af:      	movq	(%rsp), %rdi
    25b3:      	jne	0x2b16 <generic_retkprobe_filter_arg+0x2b16>
    25b9:      	jmp	0x2e81 <generic_retkprobe_filter_arg+0x2e81>
    25be:      	cmpl	$0x1, %eax
    25c1:      	je	0x2666 <generic_retkprobe_filter_arg+0x2666>
    25c7:      	cmpl	$0x2, %eax
    25ca:      	jne	0x2b16 <generic_retkprobe_filter_arg+0x2b16>
    25d0:      	cmpl	$0xc, %ecx
    25d3:      	je	0x25de <generic_retkprobe_filter_arg+0x25de>
    25d5:      	cmpl	$0xa, %ecx
    25d8:      	jne	0x2b0c <generic_retkprobe_filter_arg+0x2b0c>
    25de:      	cmpq	%rsi, (%rbp)
    25e2:      	jl	0x276 <generic_retkprobe_filter_arg+0x276>
    25e8:      	jmp	0x2b16 <generic_retkprobe_filter_arg+0x2b16>
    25ed:      	cmpl	$0xc, %eax
    25f0:      	movq	(%rsp), %rdi
    25f4:      	jne	0x2b16 <generic_retkprobe_filter_arg+0x2b16>
    25fa:      	testq	%rsi, (%rbp)
    25fe:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
    2604:      	jmp	0x2b16 <generic_retkprobe_filter_arg+0x2b16>
    2609:      	cmpl	$0xc, %eax
    260c:      	jne	0x26fe <generic_retkprobe_filter_arg+0x26fe>
    2612:      	movzbl	(%rbp), %esi
    2616:      	testl	%esi, %edx
    2618:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
    261e:      	jmp	0x26fe <generic_retkprobe_filter_arg+0x26fe>
    2623:      	cmpl	$0xc, %eax
    2626:      	jne	0x273d <generic_retkprobe_filter_arg+0x273d>
    262c:      	movzwl	(%rbp), %esi
    2630:      	testl	%esi, %edx
    2632:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
    2638:      	jmp	0x273d <generic_retkprobe_filter_arg+0x273d>
    263d:      	movq	(%rsp), %rdi
    2641:      	movq	0x8(%rsp), %r9
    2646:      	movq	0x10(%rsp), %r11
    264b:      	movzbl	%cl, %ebx
    264e:      	jmp	0x265 <generic_retkprobe_filter_arg+0x265>
    2653:      	movq	(%rsp), %rdi
    2657:      	movq	0x8(%rsp), %r9
    265c:      	movq	0x10(%rsp), %r11
    2661:      	jmp	0x1a92 <generic_retkprobe_filter_arg+0x1a92>
    2666:      	cmpl	$0xc, %ecx
    2669:      	je	0x2674 <generic_retkprobe_filter_arg+0x2674>
    266b:      	cmpl	$0xa, %ecx
    266e:      	jne	0x2b00 <generic_retkprobe_filter_arg+0x2b00>
    2674:      	cmpq	%rsi, (%rbp)
    2678:      	jg	0x276 <generic_retkprobe_filter_arg+0x276>
    267e:      	jmp	0x2b16 <generic_retkprobe_filter_arg+0x2b16>
    2683:      	xorl	%ebx, %ebx
    2685:      	movq	0x8(%rsp), %r9
    268a:      	movq	0x10(%rsp), %r11
    268f:      	movq	(%rsp), %rdi
    2693:      	jmp	0x2ef2 <generic_retkprobe_filter_arg+0x2ef2>
    2698:      	cmpl	$0x2, %ebx
    269b:      	je	0x2a62 <generic_retkprobe_filter_arg+0x2a62>
    26a1:      	cmpl	$0x3, %ebx
    26a4:      	jne	0x845 <generic_retkprobe_filter_arg+0x845>
    26aa:      	movl	$0x1, %eax
    26af:      	leaq	0x38(%rsp), %rsi
    26b4:      	movq	(%rip), %rdi            # 0x26bb <generic_retkprobe_filter_arg+0x26bb>
    26bb:      	jmp	0x2a86 <generic_retkprobe_filter_arg+0x2a86>
    26c0:      	cmpl	$0x6, %ebx
    26c3:      	je	0x2a75 <generic_retkprobe_filter_arg+0x2a75>
    26c9:      	cmpl	$0x7, %ebx
    26cc:      	jne	0x845 <generic_retkprobe_filter_arg+0x845>
    26d2:      	movl	$0x1, %eax
    26d7:      	leaq	0x38(%rsp), %rsi
    26dc:      	movq	(%rip), %rdi            # 0x26e3 <generic_retkprobe_filter_arg+0x26e3>
    26e3:      	jmp	0x2a86 <generic_retkprobe_filter_arg+0x2a86>
    26e8:      	movl	$0x1, %ebx
    26ed:      	jmp	0x2ee4 <generic_retkprobe_filter_arg+0x2ee4>
    26f2:      	movzbl	(%rbp), %esi
    26f6:      	cmpl	%esi, %edx
    26f8:      	jb	0x276 <generic_retkprobe_filter_arg+0x276>
    26fe:      	cmpl	$0x11, %ecx
    2701:      	jb	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2707:      	movl	0x18(%r15), %edx
    270b:      	cmpl	$0x2, %eax
    270e:      	jle	0x2937 <generic_retkprobe_filter_arg+0x2937>
    2714:      	leal	-0x3(%rax), %esi
    2717:      	cmpl	$0x2, %esi
    271a:      	jae	0x2b8b <generic_retkprobe_filter_arg+0x2b8b>
    2720:      	movzbl	(%rbp), %esi
    2724:      	cmpl	%esi, %edx
    2726:      	jne	0x2cf9 <generic_retkprobe_filter_arg+0x2cf9>
    272c:      	jmp	0x2e81 <generic_retkprobe_filter_arg+0x2e81>
    2731:      	movzwl	(%rbp), %esi
    2735:      	cmpl	%esi, %edx
    2737:      	jb	0x276 <generic_retkprobe_filter_arg+0x276>
    273d:      	cmpl	$0x11, %ecx
    2740:      	jb	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2746:      	movl	0x18(%r15), %edx
    274a:      	cmpl	$0x2, %eax
    274d:      	jle	0x295a <generic_retkprobe_filter_arg+0x295a>
    2753:      	leal	-0x3(%rax), %esi
    2756:      	cmpl	$0x2, %esi
    2759:      	jae	0x2ba5 <generic_retkprobe_filter_arg+0x2ba5>
    275f:      	movzwl	(%rbp), %esi
    2763:      	cmpl	%esi, %edx
    2765:      	jne	0x2d3f <generic_retkprobe_filter_arg+0x2d3f>
    276b:      	jmp	0x2e81 <generic_retkprobe_filter_arg+0x2e81>
    2770:      	cmpl	%edx, %r8d
    2773:      	setbe	%r8b
    2777:      	cmpl	%edi, %edx
    2779:      	setbe	%dil
    277d:      	andb	%r8b, %dil
    2780:      	orb	%dil, %al
    2783:      	cmpl	$0x21, %esi
    2786:      	jb	0x2aef <generic_retkprobe_filter_arg+0x2aef>
    278c:      	movl	0x28(%r15), %edi
    2790:      	movl	0x2c(%r15), %esi
    2794:      	cmpl	$0xc, %ecx
    2797:      	ja	0x2ae1 <generic_retkprobe_filter_arg+0x2ae1>
    279d:      	movl	$0x1402, %r8d           # imm = 0x1402
    27a3:      	btl	%ecx, %r8d
    27a7:      	jae	0x2ae1 <generic_retkprobe_filter_arg+0x2ae1>
    27ad:      	cmpl	%edx, %edi
    27af:      	setle	%cl
    27b2:      	cmpl	%esi, %edx
    27b4:      	setle	%dl
    27b7:      	jmp	0x2aeb <generic_retkprobe_filter_arg+0x2aeb>
    27bc:      	cmpl	%eax, %edi
    27be:      	movq	(%rsp), %rdi
    27c2:      	ja	0x27cc <generic_retkprobe_filter_arg+0x27cc>
    27c4:      	cmpl	%esi, %eax
    27c6:      	jbe	0x276 <generic_retkprobe_filter_arg+0x276>
    27cc:      	cmpl	$0x21, %edx
    27cf:      	jb	0xb8 <generic_retkprobe_filter_arg+0xb8>
    27d5:      	movl	0x28(%r15), %esi
    27d9:      	movl	0x2c(%r15), %edx
    27dd:      	cmpl	$0xc, %ecx
    27e0:      	ja	0x2bbf <generic_retkprobe_filter_arg+0x2bbf>
    27e6:      	movl	$0x1402, %r8d           # imm = 0x1402
    27ec:      	btl	%ecx, %r8d
    27f0:      	jae	0x2bbf <generic_retkprobe_filter_arg+0x2bbf>
    27f6:      	cmpl	%eax, %esi
    27f8:      	jg	0xb8 <generic_retkprobe_filter_arg+0xb8>
    27fe:      	cmpl	%edx, %eax
    2800:      	jle	0x276 <generic_retkprobe_filter_arg+0x276>
    2806:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
    280b:      	cmpl	%esi, (%rbp)
    280e:      	ja	0x276 <generic_retkprobe_filter_arg+0x276>
    2814:      	jmp	0x281f <generic_retkprobe_filter_arg+0x281f>
    2816:      	cmpl	%esi, (%rbp)
    2819:      	jb	0x276 <generic_retkprobe_filter_arg+0x276>
    281f:      	cmpl	$0x11, %edx
    2822:      	jb	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2828:      	movl	0x18(%r15), %esi
    282c:      	cmpl	$0x2, %eax
    282f:      	jle	0x284b <generic_retkprobe_filter_arg+0x284b>
    2831:      	leal	-0x3(%rax), %edi
    2834:      	cmpl	$0x2, %edi
    2837:      	jae	0x2880 <generic_retkprobe_filter_arg+0x2880>
    2839:      	cmpl	%esi, (%rbp)
    283c:      	movq	(%rsp), %rdi
    2840:      	jne	0x2d98 <generic_retkprobe_filter_arg+0x2d98>
    2846:      	jmp	0x2e81 <generic_retkprobe_filter_arg+0x2e81>
    284b:      	cmpl	$0x1, %eax
    284e:      	je	0x289b <generic_retkprobe_filter_arg+0x289b>
    2850:      	cmpl	$0x2, %eax
    2853:      	jne	0x2d98 <generic_retkprobe_filter_arg+0x2d98>
    2859:      	cmpl	$0xc, %ecx
    285c:      	ja	0x2d8f <generic_retkprobe_filter_arg+0x2d8f>
    2862:      	movl	$0x1402, %r8d           # imm = 0x1402
    2868:      	btl	%ecx, %r8d
    286c:      	jae	0x2d8f <generic_retkprobe_filter_arg+0x2d8f>
    2872:      	cmpl	%esi, (%rbp)
    2875:      	jl	0x276 <generic_retkprobe_filter_arg+0x276>
    287b:      	jmp	0x2d98 <generic_retkprobe_filter_arg+0x2d98>
    2880:      	cmpl	$0xc, %eax
    2883:      	movq	(%rsp), %rdi
    2887:      	jne	0x2d98 <generic_retkprobe_filter_arg+0x2d98>
    288d:      	testl	%esi, (%rbp)
    2890:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
    2896:      	jmp	0x2d98 <generic_retkprobe_filter_arg+0x2d98>
    289b:      	cmpl	$0xc, %ecx
    289e:      	ja	0x2d84 <generic_retkprobe_filter_arg+0x2d84>
    28a4:      	movl	$0x1402, %r8d           # imm = 0x1402
    28aa:      	btl	%ecx, %r8d
    28ae:      	jae	0x2d84 <generic_retkprobe_filter_arg+0x2d84>
    28b4:      	cmpl	%esi, (%rbp)
    28b7:      	jg	0x276 <generic_retkprobe_filter_arg+0x276>
    28bd:      	jmp	0x2d98 <generic_retkprobe_filter_arg+0x2d98>
    28c2:      	cmpq	%rdx, %rdi
    28c5:      	setbe	%cl
    28c8:      	cmpq	%rsi, %rdx
    28cb:      	jmp	0x2ae8 <generic_retkprobe_filter_arg+0x2ae8>
    28d0:      	cmpl	$0x2, %ebx
    28d3:      	je	0x2c17 <generic_retkprobe_filter_arg+0x2c17>
    28d9:      	cmpl	$0x3, %ebx
    28dc:      	jne	0x2c92 <generic_retkprobe_filter_arg+0x2c92>
    28e2:      	movl	$0x1, %eax
    28e7:      	leaq	0x38(%rsp), %rsi
    28ec:      	movq	(%rip), %rdi            # 0x28f3 <generic_retkprobe_filter_arg+0x28f3>
    28f3:      	jmp	0x2c3b <generic_retkprobe_filter_arg+0x2c3b>
    28f8:      	cmpl	$0x6, %ebx
    28fb:      	je	0x2c2a <generic_retkprobe_filter_arg+0x2c2a>
    2901:      	cmpl	$0x7, %ebx
    2904:      	jne	0x2c92 <generic_retkprobe_filter_arg+0x2c92>
    290a:      	movl	$0x1, %eax
    290f:      	leaq	0x38(%rsp), %rsi
    2914:      	movq	(%rip), %rdi            # 0x291b <generic_retkprobe_filter_arg+0x291b>
    291b:      	jmp	0x2c3b <generic_retkprobe_filter_arg+0x2c3b>
    2920:      	cmpq	%rax, %rsi
    2923:      	ja	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2929:      	cmpq	%rdx, %rax
    292c:      	jbe	0x276 <generic_retkprobe_filter_arg+0x276>
    2932:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2937:      	cmpl	$0x1, %eax
    293a:      	je	0x2ced <generic_retkprobe_filter_arg+0x2ced>
    2940:      	cmpl	$0x2, %eax
    2943:      	jne	0x2cf9 <generic_retkprobe_filter_arg+0x2cf9>
    2949:      	movzbl	(%rbp), %esi
    294d:      	cmpl	%esi, %edx
    294f:      	ja	0x276 <generic_retkprobe_filter_arg+0x276>
    2955:      	jmp	0x2cf9 <generic_retkprobe_filter_arg+0x2cf9>
    295a:      	cmpl	$0x1, %eax
    295d:      	je	0x2d33 <generic_retkprobe_filter_arg+0x2d33>
    2963:      	cmpl	$0x2, %eax
    2966:      	jne	0x2d3f <generic_retkprobe_filter_arg+0x2d3f>
    296c:      	movzwl	(%rbp), %esi
    2970:      	cmpl	%esi, %edx
    2972:      	ja	0x276 <generic_retkprobe_filter_arg+0x276>
    2978:      	jmp	0x2d3f <generic_retkprobe_filter_arg+0x2d3f>
    297d:      	movl	$0x1, %ebx
    2982:      	movq	(%rsp), %rdi
    2986:      	jmp	0x2ef2 <generic_retkprobe_filter_arg+0x2ef2>
    298b:      	movq	%rcx, %rbx
    298e:      	movw	%bp, (%rcx)
    2991:      	leaq	0x2(%rcx), %rdi
    2995:      	movl	$0x4, %eax
    299a:      	movq	0x20(%rsp), %rdx
    299f:      	movl	%ebp, %esi
    29a1:      	callq	*%rax
    29a3:      	movq	0x90(%rsp), %rsi
    29ab:      	subl	%ebp, %esi
    29ad:      	jbe	0x29c7 <generic_retkprobe_filter_arg+0x29c7>
    29af:      	leaq	(%rbx,%rbp), %rdi
    29b3:      	addq	$0x2, %rdi
    29b7:      	andl	$0xfff, %esi            # imm = 0xFFF
    29bd:      	movl	$0x4, %eax
    29c2:      	movq	%r12, %rdx
    29c5:      	callq	*%rax
    29c7:      	movl	0x88(%rsp), %eax
    29ce:      	movl	%eax, 0x38(%rsp)
    29d2:      	movl	0x18(%rsp), %eax
    29d6:      	cmpl	$0x3, %eax
    29d9:      	jg	0x2a0b <generic_retkprobe_filter_arg+0x2a0b>
    29db:      	cmpl	$0x1, %eax
    29de:      	leaq	0x38(%rsp), %rsi
    29e3:      	jg	0x2ca7 <generic_retkprobe_filter_arg+0x2ca7>
    29e9:      	testl	%eax, %eax
    29eb:      	je	0x2e8e <generic_retkprobe_filter_arg+0x2e8e>
    29f1:      	cmpl	$0x1, %eax
    29f4:      	jne	0x2ee2 <generic_retkprobe_filter_arg+0x2ee2>
    29fa:      	movl	$0x1, %eax
    29ff:      	movq	(%rip), %rdi            # 0x2a06 <generic_retkprobe_filter_arg+0x2a06>
    2a06:      	jmp	0x2ec4 <generic_retkprobe_filter_arg+0x2ec4>
    2a0b:      	cmpl	$0x5, %eax
    2a0e:      	leaq	0x38(%rsp), %rsi
    2a13:      	jg	0x2cca <generic_retkprobe_filter_arg+0x2cca>
    2a19:      	cmpl	$0x4, %eax
    2a1c:      	je	0x2e9c <generic_retkprobe_filter_arg+0x2e9c>
    2a22:      	cmpl	$0x5, %eax
    2a25:      	jne	0x2ee2 <generic_retkprobe_filter_arg+0x2ee2>
    2a2b:      	movl	$0x1, %eax
    2a30:      	movq	(%rip), %rdi            # 0x2a37 <generic_retkprobe_filter_arg+0x2a37>
    2a37:      	jmp	0x2ec4 <generic_retkprobe_filter_arg+0x2ec4>
    2a3c:      	movl	$0x1, %eax
    2a41:      	movq	(%rip), %rdi            # 0x2a48 <generic_retkprobe_filter_arg+0x2a48>
    2a48:      	leaq	0x38(%rsp), %rsi
    2a4d:      	jmp	0x2a86 <generic_retkprobe_filter_arg+0x2a86>
    2a4f:      	movl	$0x1, %eax
    2a54:      	leaq	0x38(%rsp), %rsi
    2a59:      	movq	(%rip), %rdi            # 0x2a60 <generic_retkprobe_filter_arg+0x2a60>
    2a60:      	jmp	0x2a86 <generic_retkprobe_filter_arg+0x2a86>
    2a62:      	movl	$0x1, %eax
    2a67:      	leaq	0x38(%rsp), %rsi
    2a6c:      	movq	(%rip), %rdi            # 0x2a73 <generic_retkprobe_filter_arg+0x2a73>
    2a73:      	jmp	0x2a86 <generic_retkprobe_filter_arg+0x2a86>
    2a75:      	movl	$0x1, %eax
    2a7a:      	leaq	0x38(%rsp), %rsi
    2a7f:      	movq	(%rip), %rdi            # 0x2a86 <generic_retkprobe_filter_arg+0x2a86>
    2a86:      	callq	*%rax
    2a88:      	testq	%rax, %rax
    2a8b:      	je	0x2aa6 <generic_retkprobe_filter_arg+0x2aa6>
    2a8d:      	movq	%rax, %rdi
    2a90:      	movl	$0x1, %eax
    2a95:      	movq	0x18(%rsp), %rsi
    2a9a:      	callq	*%rax
    2a9c:      	xorl	%ebx, %ebx
    2a9e:      	testq	%rax, %rax
    2aa1:      	setne	%bl
    2aa4:      	jmp	0x2aa8 <generic_retkprobe_filter_arg+0x2aa8>
    2aa6:      	xorl	%ebx, %ebx
    2aa8:      	movq	(%rsp), %rdi
    2aac:      	movq	0x8(%rsp), %r9
    2ab1:      	movq	0x10(%rsp), %r11
    2ab6:      	movl	0x4(%r15), %eax
    2aba:      	cmpq	$0x25, %rax
    2abe:      	ja	0x265 <generic_retkprobe_filter_arg+0x265>
    2ac4:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    2ace:      	btq	%rax, %rcx
    2ad2:      	jae	0x265 <generic_retkprobe_filter_arg+0x265>
    2ad8:      	xorq	$0x1, %rbx
    2adc:      	jmp	0x265 <generic_retkprobe_filter_arg+0x265>
    2ae1:      	cmpl	%edx, %edi
    2ae3:      	setbe	%cl
    2ae6:      	cmpl	%esi, %edx
    2ae8:      	setbe	%dl
    2aeb:      	andb	%cl, %dl
    2aed:      	orb	%dl, %al
    2aef:      	movq	(%rsp), %rdi
    2af3:      	testb	%al, %al
    2af5:      	je	0x276 <generic_retkprobe_filter_arg+0x276>
    2afb:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2b00:      	cmpq	%rsi, (%rbp)
    2b04:      	ja	0x276 <generic_retkprobe_filter_arg+0x276>
    2b0a:      	jmp	0x2b16 <generic_retkprobe_filter_arg+0x2b16>
    2b0c:      	cmpq	%rsi, (%rbp)
    2b10:      	jb	0x276 <generic_retkprobe_filter_arg+0x276>
    2b16:      	cmpl	$0x21, %edx
    2b19:      	jb	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2b1f:      	movq	0x28(%r15), %rdx
    2b23:      	cmpl	$0x2, %eax
    2b26:      	jle	0x2b51 <generic_retkprobe_filter_arg+0x2b51>
    2b28:      	leal	-0x3(%rax), %ecx
    2b2b:      	cmpl	$0x2, %ecx
    2b2e:      	jb	0x2b7c <generic_retkprobe_filter_arg+0x2b7c>
    2b30:      	cmpl	$0x6, %eax
    2b33:      	je	0x276 <generic_retkprobe_filter_arg+0x276>
    2b39:      	cmpl	$0xc, %eax
    2b3c:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2b42:      	testq	%rdx, (%rbp)
    2b46:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
    2b4c:      	jmp	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2b51:      	cmpl	$0x1, %eax
    2b54:      	je	0x2bd4 <generic_retkprobe_filter_arg+0x2bd4>
    2b56:      	cmpl	$0x2, %eax
    2b59:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2b5f:      	cmpl	$0xc, %ecx
    2b62:      	je	0x2b6d <generic_retkprobe_filter_arg+0x2b6d>
    2b64:      	cmpl	$0xa, %ecx
    2b67:      	jne	0x2f29 <generic_retkprobe_filter_arg+0x2f29>
    2b6d:      	cmpq	%rdx, (%rbp)
    2b71:      	jl	0x276 <generic_retkprobe_filter_arg+0x276>
    2b77:      	jmp	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2b7c:      	cmpq	%rdx, (%rbp)
    2b80:      	je	0x2e81 <generic_retkprobe_filter_arg+0x2e81>
    2b86:      	jmp	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2b8b:      	cmpl	$0xc, %eax
    2b8e:      	jne	0x2cf9 <generic_retkprobe_filter_arg+0x2cf9>
    2b94:      	movzbl	(%rbp), %esi
    2b98:      	testl	%esi, %edx
    2b9a:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
    2ba0:      	jmp	0x2cf9 <generic_retkprobe_filter_arg+0x2cf9>
    2ba5:      	cmpl	$0xc, %eax
    2ba8:      	jne	0x2d3f <generic_retkprobe_filter_arg+0x2d3f>
    2bae:      	movzwl	(%rbp), %esi
    2bb2:      	testl	%esi, %edx
    2bb4:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
    2bba:      	jmp	0x2d3f <generic_retkprobe_filter_arg+0x2d3f>
    2bbf:      	cmpl	%eax, %esi
    2bc1:      	ja	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2bc7:      	cmpl	%edx, %eax
    2bc9:      	jbe	0x276 <generic_retkprobe_filter_arg+0x276>
    2bcf:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2bd4:      	cmpl	$0xc, %ecx
    2bd7:      	je	0x2be2 <generic_retkprobe_filter_arg+0x2be2>
    2bd9:      	cmpl	$0xa, %ecx
    2bdc:      	jne	0x2f35 <generic_retkprobe_filter_arg+0x2f35>
    2be2:      	cmpq	%rdx, (%rbp)
    2be6:      	jg	0x276 <generic_retkprobe_filter_arg+0x276>
    2bec:      	jmp	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2bf1:      	movl	$0x1, %eax
    2bf6:      	movq	(%rip), %rdi            # 0x2bfd <generic_retkprobe_filter_arg+0x2bfd>
    2bfd:      	leaq	0x38(%rsp), %rsi
    2c02:      	jmp	0x2c3b <generic_retkprobe_filter_arg+0x2c3b>
    2c04:      	movl	$0x1, %eax
    2c09:      	leaq	0x38(%rsp), %rsi
    2c0e:      	movq	(%rip), %rdi            # 0x2c15 <generic_retkprobe_filter_arg+0x2c15>
    2c15:      	jmp	0x2c3b <generic_retkprobe_filter_arg+0x2c3b>
    2c17:      	movl	$0x1, %eax
    2c1c:      	leaq	0x38(%rsp), %rsi
    2c21:      	movq	(%rip), %rdi            # 0x2c28 <generic_retkprobe_filter_arg+0x2c28>
    2c28:      	jmp	0x2c3b <generic_retkprobe_filter_arg+0x2c3b>
    2c2a:      	movl	$0x1, %eax
    2c2f:      	leaq	0x38(%rsp), %rsi
    2c34:      	movq	(%rip), %rdi            # 0x2c3b <generic_retkprobe_filter_arg+0x2c3b>
    2c3b:      	callq	*%rax
    2c3d:      	testq	%rax, %rax
    2c40:      	je	0x2c5b <generic_retkprobe_filter_arg+0x2c5b>
    2c42:      	movq	%rax, %rdi
    2c45:      	movl	$0x1, %eax
    2c4a:      	movq	0x18(%rsp), %rsi
    2c4f:      	callq	*%rax
    2c51:      	xorl	%ebx, %ebx
    2c53:      	testq	%rax, %rax
    2c56:      	setne	%bl
    2c59:      	jmp	0x2c5d <generic_retkprobe_filter_arg+0x2c5d>
    2c5b:      	xorl	%ebx, %ebx
    2c5d:      	movq	(%rsp), %rdi
    2c61:      	movq	0x8(%rsp), %r9
    2c66:      	movq	0x10(%rsp), %r11
    2c6b:      	movl	0x4(%r15), %eax
    2c6f:      	cmpq	$0x25, %rax
    2c73:      	ja	0x265 <generic_retkprobe_filter_arg+0x265>
    2c79:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    2c83:      	btq	%rax, %rcx
    2c87:      	jb	0x2f19 <generic_retkprobe_filter_arg+0x2f19>
    2c8d:      	jmp	0x265 <generic_retkprobe_filter_arg+0x265>
    2c92:      	xorl	%ebx, %ebx
    2c94:      	movq	(%rsp), %rdi
    2c98:      	movl	0x4(%r15), %eax
    2c9c:      	cmpq	$0x25, %rax
    2ca0:      	jbe	0x2c79 <generic_retkprobe_filter_arg+0x2c79>
    2ca2:      	jmp	0x265 <generic_retkprobe_filter_arg+0x265>
    2ca7:      	cmpl	$0x2, %eax
    2caa:      	je	0x2eaa <generic_retkprobe_filter_arg+0x2eaa>
    2cb0:      	cmpl	$0x3, %eax
    2cb3:      	jne	0x2ee2 <generic_retkprobe_filter_arg+0x2ee2>
    2cb9:      	movl	$0x1, %eax
    2cbe:      	movq	(%rip), %rdi            # 0x2cc5 <generic_retkprobe_filter_arg+0x2cc5>
    2cc5:      	jmp	0x2ec4 <generic_retkprobe_filter_arg+0x2ec4>
    2cca:      	cmpl	$0x6, %eax
    2ccd:      	je	0x2eb8 <generic_retkprobe_filter_arg+0x2eb8>
    2cd3:      	cmpl	$0x7, %eax
    2cd6:      	jne	0x2ee2 <generic_retkprobe_filter_arg+0x2ee2>
    2cdc:      	movl	$0x1, %eax
    2ce1:      	movq	(%rip), %rdi            # 0x2ce8 <generic_retkprobe_filter_arg+0x2ce8>
    2ce8:      	jmp	0x2ec4 <generic_retkprobe_filter_arg+0x2ec4>
    2ced:      	movzbl	(%rbp), %esi
    2cf1:      	cmpl	%esi, %edx
    2cf3:      	jb	0x276 <generic_retkprobe_filter_arg+0x276>
    2cf9:      	cmpl	$0x15, %ecx
    2cfc:      	jb	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2d02:      	movl	0x1c(%r15), %ecx
    2d06:      	cmpl	$0x2, %eax
    2d09:      	jle	0x2e34 <generic_retkprobe_filter_arg+0x2e34>
    2d0f:      	leal	-0x3(%rax), %edx
    2d12:      	cmpl	$0x2, %edx
    2d15:      	jb	0x2e6f <generic_retkprobe_filter_arg+0x2e6f>
    2d1b:      	cmpl	$0x6, %eax
    2d1e:      	je	0x276 <generic_retkprobe_filter_arg+0x276>
    2d24:      	cmpl	$0xc, %eax
    2d27:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2d2d:      	movzbl	(%rbp), %edx
    2d31:      	jmp	0x2d77 <generic_retkprobe_filter_arg+0x2d77>
    2d33:      	movzwl	(%rbp), %esi
    2d37:      	cmpl	%esi, %edx
    2d39:      	jb	0x276 <generic_retkprobe_filter_arg+0x276>
    2d3f:      	cmpl	$0x15, %ecx
    2d42:      	jb	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2d48:      	movl	0x1c(%r15), %ecx
    2d4c:      	cmpl	$0x2, %eax
    2d4f:      	jle	0x2e4c <generic_retkprobe_filter_arg+0x2e4c>
    2d55:      	leal	-0x3(%rax), %edx
    2d58:      	cmpl	$0x2, %edx
    2d5b:      	jb	0x2e75 <generic_retkprobe_filter_arg+0x2e75>
    2d61:      	cmpl	$0x6, %eax
    2d64:      	je	0x276 <generic_retkprobe_filter_arg+0x276>
    2d6a:      	cmpl	$0xc, %eax
    2d6d:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2d73:      	movzwl	(%rbp), %edx
    2d77:      	testl	%edx, %ecx
    2d79:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
    2d7f:      	jmp	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2d84:      	cmpl	%esi, (%rbp)
    2d87:      	ja	0x276 <generic_retkprobe_filter_arg+0x276>
    2d8d:      	jmp	0x2d98 <generic_retkprobe_filter_arg+0x2d98>
    2d8f:      	cmpl	%esi, (%rbp)
    2d92:      	jb	0x276 <generic_retkprobe_filter_arg+0x276>
    2d98:      	cmpl	$0x15, %edx
    2d9b:      	jb	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2da1:      	movl	0x1c(%r15), %edx
    2da5:      	cmpl	$0x2, %eax
    2da8:      	jle	0x2dd2 <generic_retkprobe_filter_arg+0x2dd2>
    2daa:      	leal	-0x3(%rax), %ecx
    2dad:      	cmpl	$0x2, %ecx
    2db0:      	jb	0x2e05 <generic_retkprobe_filter_arg+0x2e05>
    2db2:      	cmpl	$0x6, %eax
    2db5:      	je	0x276 <generic_retkprobe_filter_arg+0x276>
    2dbb:      	cmpl	$0xc, %eax
    2dbe:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2dc4:      	testl	%edx, (%rbp)
    2dc7:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
    2dcd:      	jmp	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2dd2:      	cmpl	$0x1, %eax
    2dd5:      	je	0x2e0f <generic_retkprobe_filter_arg+0x2e0f>
    2dd7:      	cmpl	$0x2, %eax
    2dda:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2de0:      	cmpl	$0xc, %ecx
    2de3:      	ja	0x2f55 <generic_retkprobe_filter_arg+0x2f55>
    2de9:      	movl	$0x1402, %esi           # imm = 0x1402
    2dee:      	btl	%ecx, %esi
    2df1:      	jae	0x2f55 <generic_retkprobe_filter_arg+0x2f55>
    2df7:      	cmpl	%edx, (%rbp)
    2dfa:      	jl	0x276 <generic_retkprobe_filter_arg+0x276>
    2e00:      	jmp	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2e05:      	cmpl	%edx, (%rbp)
    2e08:      	je	0x2e81 <generic_retkprobe_filter_arg+0x2e81>
    2e0a:      	jmp	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2e0f:      	cmpl	$0xc, %ecx
    2e12:      	ja	0x2f60 <generic_retkprobe_filter_arg+0x2f60>
    2e18:      	movl	$0x1402, %esi           # imm = 0x1402
    2e1d:      	btl	%ecx, %esi
    2e20:      	jae	0x2f60 <generic_retkprobe_filter_arg+0x2f60>
    2e26:      	cmpl	%edx, (%rbp)
    2e29:      	jg	0x276 <generic_retkprobe_filter_arg+0x276>
    2e2f:      	jmp	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2e34:      	cmpl	$0x1, %eax
    2e37:      	je	0x2f41 <generic_retkprobe_filter_arg+0x2f41>
    2e3d:      	cmpl	$0x2, %eax
    2e40:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2e46:      	movzbl	(%rbp), %edx
    2e4a:      	jmp	0x2e62 <generic_retkprobe_filter_arg+0x2e62>
    2e4c:      	cmpl	$0x1, %eax
    2e4f:      	je	0x2f47 <generic_retkprobe_filter_arg+0x2f47>
    2e55:      	cmpl	$0x2, %eax
    2e58:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2e5e:      	movzwl	(%rbp), %edx
    2e62:      	cmpl	%edx, %ecx
    2e64:      	ja	0x276 <generic_retkprobe_filter_arg+0x276>
    2e6a:      	jmp	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2e6f:      	movzbl	(%rbp), %edx
    2e73:      	jmp	0x2e79 <generic_retkprobe_filter_arg+0x2e79>
    2e75:      	movzwl	(%rbp), %edx
    2e79:      	cmpl	%edx, %ecx
    2e7b:      	jne	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2e81:      	xorl	%ebx, %ebx
    2e83:      	cmpl	$0x3, %eax
    2e86:      	sete	%bl
    2e89:      	jmp	0x265 <generic_retkprobe_filter_arg+0x265>
    2e8e:      	movl	$0x1, %eax
    2e93:      	movq	(%rip), %rdi            # 0x2e9a <generic_retkprobe_filter_arg+0x2e9a>
    2e9a:      	jmp	0x2ec4 <generic_retkprobe_filter_arg+0x2ec4>
    2e9c:      	movl	$0x1, %eax
    2ea1:      	movq	(%rip), %rdi            # 0x2ea8 <generic_retkprobe_filter_arg+0x2ea8>
    2ea8:      	jmp	0x2ec4 <generic_retkprobe_filter_arg+0x2ec4>
    2eaa:      	movl	$0x1, %eax
    2eaf:      	movq	(%rip), %rdi            # 0x2eb6 <generic_retkprobe_filter_arg+0x2eb6>
    2eb6:      	jmp	0x2ec4 <generic_retkprobe_filter_arg+0x2ec4>
    2eb8:      	movl	$0x1, %eax
    2ebd:      	movq	(%rip), %rdi            # 0x2ec4 <generic_retkprobe_filter_arg+0x2ec4>
    2ec4:      	callq	*%rax
    2ec6:      	testq	%rax, %rax
    2ec9:      	je	0x2ee2 <generic_retkprobe_filter_arg+0x2ee2>
    2ecb:      	movq	%rax, %rdi
    2ece:      	movl	$0x1, %eax
    2ed3:      	movq	%rbx, %rsi
    2ed6:      	callq	*%rax
    2ed8:      	xorl	%ebx, %ebx
    2eda:      	testq	%rax, %rax
    2edd:      	setne	%bl
    2ee0:      	jmp	0x2ee4 <generic_retkprobe_filter_arg+0x2ee4>
    2ee2:      	xorl	%ebx, %ebx
    2ee4:      	movq	(%rsp), %rdi
    2ee8:      	movq	0x8(%rsp), %r9
    2eed:      	movq	0x10(%rsp), %r11
    2ef2:      	movl	0x4(%r15), %eax
    2ef6:      	cmpq	$0x25, %rax
    2efa:      	ja	0x260 <generic_retkprobe_filter_arg+0x260>
    2f00:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    2f0a:      	btq	%rax, %rcx
    2f0e:      	movq	0x68(%rsp), %r12
    2f13:      	jae	0x265 <generic_retkprobe_filter_arg+0x265>
    2f19:      	xorl	%eax, %eax
    2f1b:      	testq	%rbx, %rbx
    2f1e:      	sete	%al
    2f21:      	movq	%rax, %rbx
    2f24:      	jmp	0x265 <generic_retkprobe_filter_arg+0x265>
    2f29:      	cmpq	%rdx, (%rbp)
    2f2d:      	jb	0x276 <generic_retkprobe_filter_arg+0x276>
    2f33:      	jmp	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2f35:      	cmpq	%rdx, (%rbp)
    2f39:      	ja	0x276 <generic_retkprobe_filter_arg+0x276>
    2f3f:      	jmp	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2f41:      	movzbl	(%rbp), %edx
    2f45:      	jmp	0x2f4b <generic_retkprobe_filter_arg+0x2f4b>
    2f47:      	movzwl	(%rbp), %edx
    2f4b:      	cmpl	%edx, %ecx
    2f4d:      	jb	0x276 <generic_retkprobe_filter_arg+0x276>
    2f53:      	jmp	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2f55:      	cmpl	%edx, (%rbp)
    2f58:      	jb	0x276 <generic_retkprobe_filter_arg+0x276>
    2f5e:      	jmp	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2f60:      	cmpl	%edx, (%rbp)
    2f63:      	ja	0x276 <generic_retkprobe_filter_arg+0x276>
    2f69:      	orl	$0x2, %eax
    2f6c:      	cmpl	$0x6, %eax
    2f6f:      	je	0x276 <generic_retkprobe_filter_arg+0x276>
    2f75:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2f7a:      	nopw	(%rax,%rax)

0000000000002f80 <generic_retkprobe_actions>:
    2f80:      	pushq	%rbp
    2f81:      	pushq	%r15
    2f83:      	pushq	%r14
    2f85:      	pushq	%r13
    2f87:      	pushq	%r12
    2f89:      	pushq	%rbx
    2f8a:      	subq	$0xa8, %rsp
    2f91:      	movq	%rdi, 0x80(%rsp)
    2f99:      	movl	$0x0, 0x88(%rsp)
    2fa4:      	movq	(%rip), %rdi            # 0x2fab <generic_retkprobe_actions+0x2b>
    2fab:      	leaq	0x88(%rsp), %rsi
    2fb3:      	movl	$0x1, %eax
    2fb8:      	callq	*%rax
    2fba:      	testq	%rax, %rax
    2fbd:      	je	0x3aa8 <generic_retkprobe_actions+0xb28>
    2fc3:      	movq	%rax, %rsi
    2fc6:      	movl	0x5f04(%rax), %ebx
    2fcc:      	cmpl	$0x2, %ebx
    2fcf:      	jl	0x3aa8 <generic_retkprobe_actions+0xb28>
    2fd5:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    2fdc:      	movq	(%rip), %rdi            # 0x2fe3 <generic_retkprobe_actions+0x63>
    2fe3:      	movl	$0x1, %eax
    2fe8:      	callq	*%rax
    2fea:      	testq	%rax, %rax
    2fed:      	je	0x3aa8 <generic_retkprobe_actions+0xb28>
    2ff3:      	movq	%rax, %r14
    2ff6:      	movl	%ebx, %eax
    2ff8:      	andl	$0x7ff, %eax            # imm = 0x7FF
    2ffd:      	addl	(%r14,%rax), %ebx
    3001:      	movl	$0x0, 0x8c(%rsp)
    300c:      	movq	(%rip), %rdi            # 0x3013 <generic_retkprobe_actions+0x93>
    3013:      	leaq	0x8c(%rsp), %rsi
    301b:      	movl	$0x1, %eax
    3020:      	andl	$0x7ff, %ebx            # imm = 0x7FF
    3026:      	callq	*%rax
    3028:      	testq	%rax, %rax
    302b:      	je	0x3052 <generic_retkprobe_actions+0xd2>
    302d:      	cmpb	$0x0, (%rax)
    3030:      	sete	0x17(%rsp)
    3035:      	je	0x306d <generic_retkprobe_actions+0xed>
    3037:      	movl	$0x5, %eax
    303c:      	movq	%rax, 0x78(%rsp)
    3041:      	movl	$0x9, %eax
    3046:      	movq	%rax, 0x70(%rsp)
    304b:      	movl	$0x7, %eax
    3050:      	jmp	0x3086 <generic_retkprobe_actions+0x106>
    3052:      	movl	$0x4, %eax
    3057:      	movq	%rax, 0x78(%rsp)
    305c:      	movl	$0x8, %eax
    3061:      	movq	%rax, 0x70(%rsp)
    3066:      	movb	$0x1, 0x17(%rsp)
    306b:      	jmp	0x3081 <generic_retkprobe_actions+0x101>
    306d:      	movl	$0x4, %eax
    3072:      	movq	%rax, 0x78(%rsp)
    3077:      	movl	$0x8, %eax
    307c:      	movq	%rax, 0x70(%rsp)
    3081:      	movl	$0x6, %eax
    3086:      	movq	%rax, 0x68(%rsp)
    308b:      	addq	%rbx, %r14
    308e:      	movb	$0x1, %al
    3090:      	movl	%eax, 0x44(%rsp)
    3094:      	movq	(%rip), %rbp            # 0x309b <generic_retkprobe_actions+0x11b>
    309b:      	xorl	%r12d, %r12d
    309e:      	xorl	%r15d, %r15d
    30a1:      	jmp	0x30ca <generic_retkprobe_actions+0x14a>
    30a3:      	incl	%r15d
    30a6:      	movl	0x4(%r14,%r15,4), %eax
    30ab:      	movl	%eax, 0x78(%rdx)
    30ae:      	nop
    30b0:      	movq	%r13, 0x70(%rdx)
    30b4:      	incl	%r15d
    30b7:      	movl	%r15d, %ebx
    30ba:      	incl	%r12d
    30bd:      	movl	%ebx, %r15d
    30c0:      	cmpl	$0x3, %r12d
    30c4:      	je	0x3a81 <generic_retkprobe_actions+0xb01>
    30ca:      	leal	0x4(,%r15,4), %eax
    30d2:      	cmpl	(%r14), %eax
    30d5:      	jae	0x3a81 <generic_retkprobe_actions+0xb01>
    30db:      	movl	%r15d, %eax
    30de:      	movslq	0x4(%r14,%rax,4), %r13
    30e3:      	movl	$0x0, 0x90(%rsp)
    30ee:      	movl	$0x1, %eax
    30f3:      	leaq	0x90(%rsp), %rsi
    30fb:      	movq	%rbp, %rdi
    30fe:      	callq	*%rax
    3100:      	xorl	%ebx, %ebx
    3102:      	testq	%rax, %rax
    3105:      	je	0x30ba <generic_retkprobe_actions+0x13a>
    3107:      	movq	%rax, %rdx
    310a:      	cmpl	$0x7, %r13d
    310e:      	jg	0x3140 <generic_retkprobe_actions+0x1c0>
    3110:      	cmpl	$0x3, %r13d
    3114:      	jg	0x3196 <generic_retkprobe_actions+0x216>
    311a:      	cmpl	$0x1, %r13d
    311e:      	jg	0x32e7 <generic_retkprobe_actions+0x367>
    3124:      	testl	%r13d, %r13d
    3127:      	je	0x34f7 <generic_retkprobe_actions+0x577>
    312d:      	cmpl	$0x1, %r13d
    3131:      	je	0x3300 <generic_retkprobe_actions+0x380>
    3137:      	jmp	0x30b0 <generic_retkprobe_actions+0x130>
    313c:      	nopl	(%rax)
    3140:      	cmpl	$0xb, %r13d
    3144:      	jg	0x32b0 <generic_retkprobe_actions+0x330>
    314a:      	leal	-0xa(%r13), %eax
    314e:      	cmpl	$0x2, %eax
    3151:      	jb	0x338f <generic_retkprobe_actions+0x40f>
    3157:      	cmpl	$0x8, %r13d
    315b:      	je	0x3451 <generic_retkprobe_actions+0x4d1>
    3161:      	cmpl	$0x9, %r13d
    3165:      	jne	0x30b0 <generic_retkprobe_actions+0x130>
    316b:      	movq	%r13, 0x8(%rsp)
    3170:      	movq	%r14, %rax
    3173:      	movq	%rbp, %r13
    3176:      	incl	%r15d
    3179:      	movl	0x4(%r14,%r15,4), %eax
    317e:      	movq	%rdx, %rbp
    3181:      	movl	$0x3, %ebx
    3186:      	cmpb	$0x0, 0x17(%rsp)
    318b:      	jne	0x35d3 <generic_retkprobe_actions+0x653>
    3191:      	jmp	0x35f8 <generic_retkprobe_actions+0x678>
    3196:      	leal	-0x6(%r13), %eax
    319a:      	cmpl	$0x2, %eax
    319d:      	jb	0x30a3 <generic_retkprobe_actions+0x123>
    31a3:      	cmpl	$0x4, %r13d
    31a7:      	je	0x345e <generic_retkprobe_actions+0x4de>
    31ad:      	cmpl	$0x5, %r13d
    31b1:      	jne	0x30b0 <generic_retkprobe_actions+0x130>
    31b7:      	leal	0x1(%r15), %eax
    31bb:      	movl	0x4(%r14,%rax,4), %eax
    31c0:      	addl	$0x2, %r15d
    31c4:      	movl	0x4(%r14,%r15,4), %ebx
    31c9:      	movq	$0x0, 0x20(%rsp)
    31d2:      	movq	$0x0, 0x18(%rsp)
    31db:      	andl	$0x7, %eax
    31de:      	cmpl	$0x4, %eax
    31e1:      	ja	0x30b0 <generic_retkprobe_actions+0x130>
    31e7:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    31ef:      	jne	0x30b0 <generic_retkprobe_actions+0x130>
    31f5:      	movq	0x5e78(%rdx,%rax,8), %rax
    31fd:      	andl	$0x7ff, %eax            # imm = 0x7FF
    3202:      	movl	0x90(%rdx,%rax), %eax
    3209:      	movl	%eax, 0x20(%rsp)
    320d:      	movl	$0xe, %eax
    3212:      	movq	%rdx, 0x8(%rsp)
    3217:      	callq	*%rax
    3219:      	shrq	$0x20, %rax
    321d:      	movq	%rax, 0x18(%rsp)
    3222:      	movl	$0x1, %eax
    3227:      	leaq	0x18(%rsp), %rsi
    322c:      	movq	(%rip), %rdi            # 0x3233 <generic_retkprobe_actions+0x2b3>
    3233:      	callq	*%rax
    3235:      	movq	0x8(%rsp), %rdx
    323a:      	testq	%rax, %rax
    323d:      	je	0x30b0 <generic_retkprobe_actions+0x130>
    3243:      	andl	$0x7, %ebx
    3246:      	cmpl	$0x4, %ebx
    3249:      	ja	0x30b0 <generic_retkprobe_actions+0x130>
    324f:      	cmpl	$0x0, 0x5ea0(%rdx,%rbx,4)
    3257:      	jne	0x30b0 <generic_retkprobe_actions+0x130>
    325d:      	movq	0x5e78(%rdx,%rbx,8), %rcx
    3265:      	movl	$0x0, 0x24(%rsp)
    326d:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    3273:      	movl	0x90(%rdx,%rcx), %ecx
    327a:      	movl	%ecx, 0x20(%rsp)
    327e:      	movq	%rax, %rbx
    3281:      	movl	$0xe, %eax
    3286:      	callq	*%rax
    3288:      	shrq	$0x20, %rax
    328c:      	movq	%rax, 0x18(%rsp)
    3291:      	movl	$0x2, %eax
    3296:      	xorl	%ecx, %ecx
    3298:      	leaq	0x18(%rsp), %rsi
    329d:      	movq	(%rip), %rdi            # 0x32a4 <generic_retkprobe_actions+0x324>
    32a4:      	movq	%rbx, %rdx
    32a7:      	xorl	%ecx, %ecx
    32a9:      	callq	*%rax
    32ab:      	jmp	0x34ed <generic_retkprobe_actions+0x56d>
    32b0:      	cmpl	$0xc, %r13d
    32b4:      	je	0x35e4 <generic_retkprobe_actions+0x664>
    32ba:      	cmpl	$0xd, %r13d
    32be:      	je	0x3476 <generic_retkprobe_actions+0x4f6>
    32c4:      	cmpl	$0xe, %r13d
    32c8:      	jne	0x30b0 <generic_retkprobe_actions+0x130>
    32ce:      	movq	%r13, 0x8(%rsp)
    32d3:      	movq	%rbp, %r13
    32d6:      	movq	%rdx, %rbp
    32d9:      	addl	$0x2, %r15d
    32dd:      	movq	0x70(%rsp), %rbx
    32e2:      	jmp	0x35f8 <generic_retkprobe_actions+0x678>
    32e7:      	movl	$0x9, %eax
    32ec:      	cmpl	$0x2, %r13d
    32f0:      	je	0x35bc <generic_retkprobe_actions+0x63c>
    32f6:      	cmpl	$0x3, %r13d
    32fa:      	jne	0x30b0 <generic_retkprobe_actions+0x130>
    3300:      	movq	%rdx, 0x8(%rsp)
    3305:      	leal	0x1(%r15), %eax
    3309:      	movq	%r14, %rcx
    330c:      	movl	0x4(%r14,%rax,4), %r14d
    3311:      	addl	$0x2, %r15d
    3315:      	movq	%rcx, %rbp
    3318:      	movl	0x4(%rcx,%r15,4), %eax
    331d:      	movq	%rax, 0x38(%rsp)
    3322:      	movq	$0x0, 0x20(%rsp)
    332b:      	movq	$0x0, 0x18(%rsp)
    3334:      	movl	$0x0, 0x28(%rsp)
    333c:      	movl	$0x1, %eax
    3341:      	leaq	0x28(%rsp), %rsi
    3346:      	movq	(%rip), %rdi            # 0x334d <generic_retkprobe_actions+0x3cd>
    334d:      	callq	*%rax
    334f:      	xorl	%ecx, %ecx
    3351:      	testq	%rax, %rax
    3354:      	je	0x3788 <generic_retkprobe_actions+0x808>
    335a:      	andl	$0x7, %r14d
    335e:      	cmpl	$0x4, %r14d
    3362:      	movq	0x8(%rsp), %rdx
    3367:      	ja	0x3378 <generic_retkprobe_actions+0x3f8>
    3369:      	cmpl	$0x0, 0x5ea0(%rdx,%r14,4)
    3372:      	je	0x362d <generic_retkprobe_actions+0x6ad>
    3378:      	movq	%rbp, %r14
    337b:      	movq	(%rip), %rbp            # 0x3382 <generic_retkprobe_actions+0x402>
    3382:      	testl	%ecx, %ecx
    3384:      	jne	0x30ba <generic_retkprobe_actions+0x13a>
    338a:      	jmp	0x30b0 <generic_retkprobe_actions+0x130>
    338f:      	incl	%r15d
    3392:      	movl	0x4(%r14,%r15,4), %eax
    3397:      	andl	$0x7, %eax
    339a:      	xorl	%ecx, %ecx
    339c:      	cmpl	$0x4, %eax
    339f:      	ja	0x3797 <generic_retkprobe_actions+0x817>
    33a5:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    33ad:      	jne	0x3797 <generic_retkprobe_actions+0x817>
    33b3:      	movq	0x5e78(%rdx,%rax,8), %rax
    33bb:      	andl	$0x7ff, %eax            # imm = 0x7FF
    33c0:      	movq	0xb8(%rdx,%rax), %rax
    33c8:      	movq	%rax, 0x28(%rsp)
    33cd:      	testq	%rax, %rax
    33d0:      	je	0x3797 <generic_retkprobe_actions+0x817>
    33d6:      	movq	%rdx, 0x8(%rsp)
    33db:      	cmpl	$0xa, %r13d
    33df:      	jne	0x37a4 <generic_retkprobe_actions+0x824>
    33e5:      	movl	$0xe, %eax
    33ea:      	callq	*%rax
    33ec:      	movq	%rax, 0x38(%rsp)
    33f1:      	shrq	$0x20, %rax
    33f5:      	movl	%eax, 0x18(%rsp)
    33f9:      	movl	$0x1, %eax
    33fe:      	leaq	0x18(%rsp), %rsi
    3403:      	movq	(%rip), %rdi            # 0x340a <generic_retkprobe_actions+0x48a>
    340a:      	callq	*%rax
    340c:      	xorl	%ecx, %ecx
    340e:      	testq	%rax, %rax
    3411:      	movq	0x8(%rsp), %rdx
    3416:      	je	0x3797 <generic_retkprobe_actions+0x817>
    341c:      	movl	(%rax), %ecx
    341e:      	movl	%ecx, 0x18(%rsp)
    3422:      	movq	0x38(%rsp), %rcx
    3427:      	movl	%ecx, 0x1c(%rsp)
    342b:      	movq	0x8(%rax), %rax
    342f:      	movq	%rax, 0x20(%rsp)
    3434:      	xorl	%ecx, %ecx
    3436:      	movl	$0x2, %eax
    343b:      	leaq	0x28(%rsp), %rsi
    3440:      	leaq	0x18(%rsp), %rdx
    3445:      	movq	(%rip), %rdi            # 0x344c <generic_retkprobe_actions+0x4cc>
    344c:      	jmp	0x36f0 <generic_retkprobe_actions+0x770>
    3451:      	movl	$0x0, 0x44(%rsp)
    3459:      	jmp	0x30b0 <generic_retkprobe_actions+0x130>
    345e:      	movq	%r13, 0x8(%rsp)
    3463:      	movq	%rbp, %r13
    3466:      	movq	%rdx, %rbp
    3469:      	incl	%r15d
    346c:      	movq	0x78(%rsp), %rbx
    3471:      	jmp	0x35f8 <generic_retkprobe_actions+0x678>
    3476:      	movq	%rdx, 0x8(%rsp)
    347b:      	movl	$0xe, %eax
    3480:      	callq	*%rax
    3482:      	movq	%rax, 0x50(%rsp)
    3487:      	movl	$0x1, %eax
    348c:      	leaq	0x50(%rsp), %rsi
    3491:      	movq	(%rip), %rdi            # 0x3498 <generic_retkprobe_actions+0x518>
    3498:      	callq	*%rax
    349a:      	testq	%rax, %rax
    349d:      	je	0x34ed <generic_retkprobe_actions+0x56d>
    349f:      	movq	0x4(%rax), %rax
    34a3:      	movq	%rax, 0x28(%rsp)
    34a8:      	movl	$0x2, 0x30(%rsp)
    34b0:      	movl	$0x1, %eax
    34b5:      	leaq	0x28(%rsp), %rsi
    34ba:      	movq	(%rip), %rbx            # 0x34c1 <generic_retkprobe_actions+0x541>
    34c1:      	movq	%rbx, %rdi
    34c4:      	callq	*%rax
    34c6:      	movl	$0x1, 0x5c(%rsp)
    34ce:      	testq	%rax, %rax
    34d1:      	je	0x3708 <generic_retkprobe_actions+0x788>
    34d7:      	lock
    34d8:      	incl	(%rax)
    34da:      	movl	$0x3, %eax
    34df:      	leaq	0x50(%rsp), %rsi
    34e4:      	movq	(%rip), %rdi            # 0x34eb <generic_retkprobe_actions+0x56b>
    34eb:      	callq	*%rax
    34ed:      	movq	0x8(%rsp), %rdx
    34f2:      	jmp	0x30b0 <generic_retkprobe_actions+0x130>
    34f7:      	movq	%rdx, 0x8(%rsp)
    34fc:      	leal	0x1(%r15), %eax
    3500:      	movl	0x4(%r14,%rax,4), %ebx
    3505:      	leal	0x2(%r15), %eax
    3509:      	movl	0x4(%r14,%rax,4), %eax
    350e:      	movl	%eax, 0x60(%rsp)
    3512:      	movl	$0x7d, %eax
    3517:      	callq	*%rax
    3519:      	movq	%rax, 0x18(%rsp)
    351e:      	movl	$0x0, 0x50(%rsp)
    3526:      	movq	%rbx, 0xa0(%rsp)
    352e:      	testq	%rbx, %rbx
    3531:      	je	0x39a8 <generic_retkprobe_actions+0xa28>
    3537:      	movl	$0x1, %eax
    353c:      	movq	(%rip), %rdi            # 0x3543 <generic_retkprobe_actions+0x5c3>
    3543:      	leaq	0x50(%rsp), %rsi
    3548:      	callq	*%rax
    354a:      	testq	%rax, %rax
    354d:      	je	0x39a8 <generic_retkprobe_actions+0xa28>
    3553:      	movq	%rax, 0x48(%rsp)
    3558:      	movq	%rax, %rbx
    355b:      	movl	$0x1, %eax
    3560:      	leaq	0x50(%rsp), %rsi
    3565:      	movq	(%rip), %rdi            # 0x356c <generic_retkprobe_actions+0x5ec>
    356c:      	callq	*%rax
    356e:      	movq	%rax, %rdx
    3571:      	movq	0x8(%rsp), %rcx
    3576:      	movq	0x60(%rcx), %rax
    357a:      	movq	%rax, (%rbx)
    357d:      	movq	0x70(%rcx), %rax
    3581:      	movq	%rax, 0x8(%rbx)
    3585:      	xorl	%eax, %eax
    3587:      	movq	%rax, 0x38(%rsp)
    358c:      	movl	$0x0, %eax
    3591:      	movl	0x60(%rsp), %esi
    3595:      	cmpl	$0x2, %esi
    3598:      	je	0x37cf <generic_retkprobe_actions+0x84f>
    359e:      	cmpl	$0x1, %esi
    35a1:      	je	0x37cc <generic_retkprobe_actions+0x84c>
    35a7:      	testl	%esi, %esi
    35a9:      	jne	0x39a8 <generic_retkprobe_actions+0xa28>
    35af:      	movq	0x8(%rsp), %rax
    35b4:      	movl	0x7c(%rax), %eax
    35b7:      	jmp	0x37cf <generic_retkprobe_actions+0x84f>
    35bc:      	movq	%r13, 0x8(%rsp)
    35c1:      	movq	%rbp, %r13
    35c4:      	movq	%rdx, %rbp
    35c7:      	movl	$0x3, %ebx
    35cc:      	cmpb	$0x0, 0x17(%rsp)
    35d1:      	je	0x35f8 <generic_retkprobe_actions+0x678>
    35d3:      	movslq	%eax, %rdi
    35d6:      	movl	$0x6d, %eax
    35db:      	callq	*%rax
    35dd:      	movl	$0x2, %ebx
    35e2:      	jmp	0x35f8 <generic_retkprobe_actions+0x678>
    35e4:      	movq	%r13, 0x8(%rsp)
    35e9:      	movq	%rbp, %r13
    35ec:      	movq	%rdx, %rbp
    35ef:      	addl	$0x3, %r15d
    35f3:      	movq	0x68(%rsp), %rbx
    35f8:      	movl	$0x0, 0x18(%rsp)
    3600:      	movl	$0x1, %eax
    3605:      	leaq	0x18(%rsp), %rsi
    360a:      	movq	(%rip), %rdi            # 0x3611 <generic_retkprobe_actions+0x691>
    3611:      	callq	*%rax
    3613:      	testq	%rax, %rax
    3616:      	je	0x361d <generic_retkprobe_actions+0x69d>
    3618:      	lock
    3619:      	incq	(%rax,%rbx,8)
    361d:      	movq	%rbp, %rdx
    3620:      	movq	%r13, %rbp
    3623:      	movq	0x8(%rsp), %r13
    3628:      	jmp	0x30b0 <generic_retkprobe_actions+0x130>
    362d:      	movq	%rax, 0x48(%rsp)
    3632:      	movq	0x5e78(%rdx,%r14,8), %rax
    363a:      	movl	$0x0, 0x24(%rsp)
    3642:      	andl	$0x7ff, %eax            # imm = 0x7FF
    3647:      	movl	0x90(%rdx,%rax), %eax
    364e:      	movl	%eax, 0x20(%rsp)
    3652:      	movl	$0xe, %eax
    3657:      	callq	*%rax
    3659:      	shrq	$0x20, %rax
    365d:      	movq	%rax, 0x18(%rsp)
    3662:      	cmpl	$0x1, %r13d
    3666:      	jne	0x3772 <generic_retkprobe_actions+0x7f2>
    366c:      	movq	0x38(%rsp), %rax
    3671:      	andl	$0x7, %eax
    3674:      	cmpl	$0x4, %eax
    3677:      	movq	%rbp, %r14
    367a:      	movl	$0x0, %ecx
    367f:      	ja	0x378b <generic_retkprobe_actions+0x80b>
    3685:      	movq	0x8(%rsp), %rdx
    368a:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    3692:      	movq	(%rip), %rbp            # 0x3699 <generic_retkprobe_actions+0x719>
    3699:      	jne	0x3797 <generic_retkprobe_actions+0x817>
    369f:      	movq	0x5e78(%rdx,%rax,8), %rax
    36a7:      	andl	$0x7ff, %eax            # imm = 0x7FF
    36ac:      	addq	%rax, %rdx
    36af:      	addq	$0x90, %rdx
    36b6:      	movq	0x8(%rsp), %rcx
    36bb:      	movl	0x90(%rcx,%rax), %esi
    36c2:      	andl	$0xfff, %esi            # imm = 0xFFF
    36c8:      	addq	$0x8, %rsi
    36cc:      	movl	$0x4, %eax
    36d1:      	movq	0x48(%rsp), %rdi
    36d6:      	callq	*%rax
    36d8:      	xorl	%ecx, %ecx
    36da:      	movl	$0x2, %eax
    36df:      	leaq	0x18(%rsp), %rsi
    36e4:      	movq	(%rip), %rdi            # 0x36eb <generic_retkprobe_actions+0x76b>
    36eb:      	movq	0x48(%rsp), %rdx
    36f0:      	xorl	%ecx, %ecx
    36f2:      	callq	*%rax
    36f4:      	xorl	%ecx, %ecx
    36f6:      	movq	0x8(%rsp), %rdx
    36fb:      	testl	%ecx, %ecx
    36fd:      	jne	0x30ba <generic_retkprobe_actions+0x13a>
    3703:      	jmp	0x30b0 <generic_retkprobe_actions+0x130>
    3708:      	movl	$0x2, %eax
    370d:      	movl	$0x1, %ecx
    3712:      	leaq	0x5c(%rsp), %rdx
    3717:      	leaq	0x28(%rsp), %rsi
    371c:      	movq	%rbx, %rdi
    371f:      	callq	*%rax
    3721:      	testq	%rax, %rax
    3724:      	je	0x34da <generic_retkprobe_actions+0x55a>
    372a:      	movq	%rax, 0x38(%rsp)
    372f:      	negl	%eax
    3731:      	movw	%ax, 0x18(%rsp)
    3736:      	movw	$0x3, 0x1a(%rsp)
    373d:      	movabsq	$0x20000003b, %rax      # imm = 0x20000003B
    3747:      	movq	%rax, 0x1c(%rsp)
    374c:      	movl	$0x1, %eax
    3751:      	leaq	0x18(%rsp), %rsi
    3756:      	movq	(%rip), %rbx            # 0x375d <generic_retkprobe_actions+0x7dd>
    375d:      	movq	%rbx, %rdi
    3760:      	callq	*%rax
    3762:      	testq	%rax, %rax
    3765:      	je	0x3a28 <generic_retkprobe_actions+0xaa8>
    376b:      	incl	(%rax)
    376d:      	jmp	0x3a4e <generic_retkprobe_actions+0xace>
    3772:      	movl	$0x3, %eax
    3777:      	leaq	0x18(%rsp), %rsi
    377c:      	movq	(%rip), %rdi            # 0x3783 <generic_retkprobe_actions+0x803>
    3783:      	callq	*%rax
    3785:      	movq	%rax, %rcx
    3788:      	movq	%rbp, %r14
    378b:      	movq	(%rip), %rbp            # 0x3792 <generic_retkprobe_actions+0x812>
    3792:      	movq	0x8(%rsp), %rdx
    3797:      	testl	%ecx, %ecx
    3799:      	jne	0x30ba <generic_retkprobe_actions+0x13a>
    379f:      	jmp	0x30b0 <generic_retkprobe_actions+0x130>
    37a4:      	movl	$0x3, %eax
    37a9:      	leaq	0x28(%rsp), %rsi
    37ae:      	movq	(%rip), %rdi            # 0x37b5 <generic_retkprobe_actions+0x835>
    37b5:      	callq	*%rax
    37b7:      	movq	%rax, %rcx
    37ba:      	movq	0x8(%rsp), %rdx
    37bf:      	testl	%ecx, %ecx
    37c1:      	jne	0x30ba <generic_retkprobe_actions+0x13a>
    37c7:      	jmp	0x30b0 <generic_retkprobe_actions+0x130>
    37cc:      	movl	0x10(%rcx), %eax
    37cf:      	movq	%r14, 0x60(%rsp)
    37d4:      	movl	%eax, %eax
    37d6:      	movq	%rbx, 0x98(%rsp)
    37de:      	movq	%rax, 0x10(%rbx)
    37e2:      	movq	0x48(%rsp), %rdi
    37e7:      	addq	$0x18, %rdi
    37eb:      	movl	$0x4, %eax
    37f0:      	movl	$0xc8, %ecx
    37f5:      	movq	%rdi, 0x48(%rsp)
    37fa:      	movl	$0xc8, %esi
    37ff:      	callq	*%rax
    3801:      	xorl	%r14d, %r14d
    3804:      	leaq	0x28(%rsp), %rbx
    3809:      	jmp	0x3823 <generic_retkprobe_actions+0x8a3>
    380b:      	nopl	(%rax,%rax)
    3810:      	leaq	0x28(%rsp), %rbx
    3815:      	addq	$0x4, %r14
    3819:      	cmpq	$0x14, %r14
    381d:      	je	0x394b <generic_retkprobe_actions+0x9cb>
    3823:      	movl	$0x0, 0x28(%rsp)
    382b:      	movl	$0x1, %eax
    3830:      	movq	%rbp, %rdi
    3833:      	movq	%rbx, %rsi
    3836:      	callq	*%rax
    3838:      	testq	%rax, %rax
    383b:      	je	0x394b <generic_retkprobe_actions+0x9cb>
    3841:      	movq	%rax, %rsi
    3844:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    384b:      	movl	$0x1, %eax
    3850:      	movq	(%rip), %rdi            # 0x3857 <generic_retkprobe_actions+0x8d7>
    3857:      	callq	*%rax
    3859:      	testq	%rax, %rax
    385c:      	je	0x394b <generic_retkprobe_actions+0x9cb>
    3862:      	cmpl	$-0x1, 0x40(%rax,%r14)
    3868:      	movq	0x8(%rsp), %rdx
    386d:      	je	0x394b <generic_retkprobe_actions+0x9cb>
    3873:      	movq	0x5e78(%rdx,%r14,2), %rax
    387b:      	movl	0x4(%rdx), %ecx
    387e:      	cmpq	%rcx, %rax
    3881:      	jge	0x394b <generic_retkprobe_actions+0x9cb>
    3887:      	cmpq	$0x10, %r14
    388b:      	je	0x38f2 <generic_retkprobe_actions+0x972>
    388d:      	movl	$0x0, 0x28(%rsp)
    3895:      	movl	$0x1, %eax
    389a:      	movq	%rbp, %rdi
    389d:      	movq	%rbx, %rsi
    38a0:      	callq	*%rax
    38a2:      	testq	%rax, %rax
    38a5:      	je	0x38e5 <generic_retkprobe_actions+0x965>
    38a7:      	movq	%rax, %rsi
    38aa:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    38b1:      	movl	$0x1, %eax
    38b6:      	movq	(%rip), %rdi            # 0x38bd <generic_retkprobe_actions+0x93d>
    38bd:      	callq	*%rax
    38bf:      	testq	%rax, %rax
    38c2:      	je	0x38e5 <generic_retkprobe_actions+0x965>
    38c4:      	cmpl	$-0x1, 0x44(%rax,%r14)
    38ca:      	movq	0x8(%rsp), %rdx
    38cf:      	movq	0x5e78(%rdx,%r14,2), %rax
    38d7:      	je	0x38f2 <generic_retkprobe_actions+0x972>
    38d9:      	movl	0x5e80(%rdx,%r14,2), %ebx
    38e1:      	subl	%eax, %ebx
    38e3:      	jmp	0x38fa <generic_retkprobe_actions+0x97a>
    38e5:      	movq	0x8(%rsp), %rdx
    38ea:      	movq	0x5e78(%rdx,%r14,2), %rax
    38f2:      	movl	0x4(%rdx), %ebx
    38f5:      	subl	%eax, %ebx
    38f7:      	addl	$0x4, %ebx
    38fa:      	testl	%ebx, %ebx
    38fc:      	jle	0x3810 <generic_retkprobe_actions+0x890>
    3902:      	addl	$0x3ffc, %eax           # imm = 0x3FFC
    3907:      	andl	$0x3fff, %eax           # imm = 0x3FFF
    390c:      	cmpl	$0x28, %ebx
    390f:      	movl	$0x28, %ecx
    3914:      	cmovgel	%ecx, %ebx
    3917:      	movzbl	0x38(%rsp), %ebp
    391c:      	movq	0x48(%rsp), %rcx
    3921:      	leaq	(%rcx,%rbp), %rdi
    3925:      	addq	%rax, %rdx
    3928:      	addq	$0x90, %rdx
    392f:      	movl	$0x4, %eax
    3934:      	movl	%ebx, %esi
    3936:      	callq	*%rax
    3938:      	addl	%ebp, %ebx
    393a:      	movq	(%rip), %rbp            # 0x3941 <generic_retkprobe_actions+0x9c1>
    3941:      	movq	%rbx, 0x38(%rsp)
    3946:      	jmp	0x3810 <generic_retkprobe_actions+0x890>
    394b:      	movl	$0x1, %eax
    3950:      	movq	(%rip), %rdi            # 0x3957 <generic_retkprobe_actions+0x9d7>
    3957:      	movq	0x98(%rsp), %rbx
    395f:      	movq	%rbx, %rsi
    3962:      	callq	*%rax
    3964:      	testq	%rax, %rax
    3967:      	movq	0x60(%rsp), %r14
    396c:      	je	0x398e <generic_retkprobe_actions+0xa0e>
    396e:      	imulq	$-0xf4240, 0xa0(%rsp), %rcx # imm = 0xFFF0BDC0
    397a:      	addq	0x18(%rsp), %rcx
    397f:      	cmpq	%rcx, (%rax)
    3982:      	jbe	0x398e <generic_retkprobe_actions+0xa0e>
    3984:      	movl	$0x0, 0x44(%rsp)
    398c:      	jmp	0x39a8 <generic_retkprobe_actions+0xa28>
    398e:      	movl	$0x2, %eax
    3993:      	xorl	%ecx, %ecx
    3995:      	movq	(%rip), %rdi            # 0x399c <generic_retkprobe_actions+0xa1c>
    399c:      	leaq	0x18(%rsp), %rdx
    39a1:      	movq	%rbx, %rsi
    39a4:      	xorl	%ecx, %ecx
    39a6:      	callq	*%rax
    39a8:      	leal	0x3(%r15), %eax
    39ac:      	cmpl	$0x0, 0x4(%r14,%rax,4)
    39b2:      	movq	0x8(%rsp), %rdx
    39b7:      	je	0x39e3 <generic_retkprobe_actions+0xa63>
    39b9:      	orb	$0x2, 0x1(%rdx)
    39bd:      	movl	$0x1b, %eax
    39c2:      	movq	0x80(%rsp), %rdi
    39ca:      	xorl	%ecx, %ecx
    39cc:      	movq	(%rip), %rsi            # 0x39d3 <generic_retkprobe_actions+0xa53>
    39d3:      	xorl	%edx, %edx
    39d5:      	callq	*%rax
    39d7:      	movq	0x8(%rsp), %rdx
    39dc:      	movq	%rax, 0x80(%rdx)
    39e3:      	addl	$0x4, %r15d
    39e7:      	cmpl	$0x0, 0x4(%r14,%r15,4)
    39ed:      	je	0x30b0 <generic_retkprobe_actions+0x130>
    39f3:      	orb	$0x4, 0x1(%rdx)
    39f7:      	movl	$0x1b, %eax
    39fc:      	movq	0x80(%rsp), %rdi
    3a04:      	movq	(%rip), %rsi            # 0x3a0b <generic_retkprobe_actions+0xa8b>
    3a0b:      	movl	$0x100, %ecx            # imm = 0x100
    3a10:      	movl	$0x100, %edx            # imm = 0x100
    3a15:      	callq	*%rax
    3a17:      	movq	0x8(%rsp), %rdx
    3a1c:      	movq	%rax, 0x88(%rdx)
    3a23:      	jmp	0x30b0 <generic_retkprobe_actions+0x130>
    3a28:      	movl	$0x1, 0x94(%rsp)
    3a33:      	movl	$0x2, %eax
    3a38:      	xorl	%ecx, %ecx
    3a3a:      	leaq	0x94(%rsp), %rdx
    3a42:      	leaq	0x18(%rsp), %rsi
    3a47:      	movq	%rbx, %rdi
    3a4a:      	xorl	%ecx, %ecx
    3a4c:      	callq	*%rax
    3a4e:      	cmpl	$0x0, 0x38(%rsp)
    3a53:      	je	0x34da <generic_retkprobe_actions+0x55a>
    3a59:      	movl	$0x1, %eax
    3a5e:      	leaq	0x28(%rsp), %rsi
    3a63:      	movq	(%rip), %rdi            # 0x3a6a <generic_retkprobe_actions+0xaea>
    3a6a:      	callq	*%rax
    3a6c:      	testq	%rax, %rax
    3a6f:      	je	0x34da <generic_retkprobe_actions+0x55a>
    3a75:      	movl	0x5c(%rsp), %ecx
    3a79:      	lock
    3a7a:      	addl	%ecx, (%rax)
    3a7c:      	jmp	0x34da <generic_retkprobe_actions+0x55a>
    3a81:      	cmpb	$0x0, 0x44(%rsp)
    3a86:      	je	0x3aa8 <generic_retkprobe_actions+0xb28>
    3a88:      	movq	(%rip), %rsi            # 0x3a8f <generic_retkprobe_actions+0xb0f>
    3a8f:      	movl	$0x5, %ecx
    3a94:      	movl	$0xc, %eax
    3a99:      	movq	0x80(%rsp), %rdi
    3aa1:      	movl	$0x5, %edx
    3aa6:      	callq	*%rax
    3aa8:      	xorl	%eax, %eax
    3aaa:      	addq	$0xa8, %rsp
    3ab1:      	popq	%rbx
    3ab2:      	popq	%r12
    3ab4:      	popq	%r13
    3ab6:      	popq	%r14
    3ab8:      	popq	%r15
    3aba:      	popq	%rbp
    3abb:      	retq
    3abc:      	nopl	(%rax)

0000000000003ac0 <generic_retkprobe_output>:
    3ac0:      	pushq	%rbx
    3ac1:      	subq	$0x10, %rsp
    3ac5:      	movq	%rdi, %rbx
    3ac8:      	movl	$0x0, 0x4(%rsp)
    3ad0:      	movq	(%rip), %rdi            # 0x3ad7 <generic_retkprobe_output+0x17>
    3ad7:      	leaq	0x4(%rsp), %rsi
    3adc:      	movl	$0x1, %eax
    3ae1:      	callq	*%rax
    3ae3:      	testq	%rax, %rax
    3ae6:      	je	0x3b90 <generic_retkprobe_output+0xd0>
    3aec:      	movq	%rax, %rcx
    3aef:      	movl	$0x90, %eax
    3af4:      	addl	0x4(%rcx), %eax
    3af7:      	andl	$0x7fff, %eax           # imm = 0x7FFF
    3afc:      	cmpl	$0x2328, %eax           # imm = 0x2328
    3b01:      	movl	$0x2328, %r8d           # imm = 0x2328
    3b07:      	cmovbl	%eax, %r8d
    3b0b:      	movq	(%rip), %rsi            # 0x3b12 <generic_retkprobe_output+0x52>
    3b12:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    3b17:      	movl	$0x19, %eax
    3b1c:      	movq	%rbx, %rdi
    3b1f:      	callq	*%rax
    3b21:      	testq	%rax, %rax
    3b24:      	js	0x3b4d <generic_retkprobe_output+0x8d>
    3b26:      	movl	$0x0, 0xc(%rsp)
    3b2e:      	movq	(%rip), %rdi            # 0x3b35 <generic_retkprobe_output+0x75>
    3b35:      	leaq	0xc(%rsp), %rsi
    3b3a:      	movl	$0x1, %eax
    3b3f:      	callq	*%rax
    3b41:      	testq	%rax, %rax
    3b44:      	je	0x3b90 <generic_retkprobe_output+0xd0>
    3b46:      	lock
    3b47:      	incq	0x8(%rax)
    3b4b:      	jmp	0x3b90 <generic_retkprobe_output+0xd0>
    3b4d:      	movq	%rax, %rbx
    3b50:      	movl	$0x0, 0x8(%rsp)
    3b58:      	movq	(%rip), %rdi            # 0x3b5f <generic_retkprobe_output+0x9f>
    3b5f:      	leaq	0x8(%rsp), %rsi
    3b64:      	movl	$0x1, %eax
    3b69:      	callq	*%rax
    3b6b:      	testq	%rax, %rax
    3b6e:      	je	0x3b90 <generic_retkprobe_output+0xd0>
    3b70:      	cmpq	$-0xc, %rbx
    3b74:      	jg	0x3b98 <generic_retkprobe_output+0xd8>
    3b76:      	cmpq	$-0x1c, %rbx
    3b7a:      	je	0x3bb2 <generic_retkprobe_output+0xf2>
    3b7c:      	cmpq	$-0x16, %rbx
    3b80:      	je	0x3bca <generic_retkprobe_output+0x10a>
    3b82:      	cmpq	$-0x10, %rbx
    3b86:      	jne	0x3bc2 <generic_retkprobe_output+0x102>
    3b88:      	addq	$0x2f0, %rax            # imm = 0x2F0
    3b8e:      	jmp	0x3bd8 <generic_retkprobe_output+0x118>
    3b90:      	xorl	%eax, %eax
    3b92:      	addq	$0x10, %rsp
    3b96:      	popq	%rbx
    3b97:      	retq
    3b98:      	cmpq	$-0xb, %rbx
    3b9c:      	je	0x3bba <generic_retkprobe_output+0xfa>
    3b9e:      	cmpq	$-0x7, %rbx
    3ba2:      	je	0x3bd2 <generic_retkprobe_output+0x112>
    3ba4:      	cmpq	$-0x2, %rbx
    3ba8:      	jne	0x3bc2 <generic_retkprobe_output+0x102>
    3baa:      	addq	$0x2e0, %rax            # imm = 0x2E0
    3bb0:      	jmp	0x3bd8 <generic_retkprobe_output+0x118>
    3bb2:      	addq	$0x300, %rax            # imm = 0x300
    3bb8:      	jmp	0x3bd8 <generic_retkprobe_output+0x118>
    3bba:      	addq	$0x308, %rax            # imm = 0x308
    3bc0:      	jmp	0x3bd8 <generic_retkprobe_output+0x118>
    3bc2:      	addq	$0x2d8, %rax            # imm = 0x2D8
    3bc8:      	jmp	0x3bd8 <generic_retkprobe_output+0x118>
    3bca:      	addq	$0x2f8, %rax            # imm = 0x2F8
    3bd0:      	jmp	0x3bd8 <generic_retkprobe_output+0x118>
    3bd2:      	addq	$0x2e8, %rax            # imm = 0x2E8
    3bd8:      	lock
    3bd9:      	incq	(%rax)
    3bdc:      	xorl	%eax, %eax
    3bde:      	addq	$0x10, %rsp
    3be2:      	popq	%rbx
    3be3:      	retq

Disassembly of section kprobe/generic_retkprobe:

0000000000000000 <generic_retkprobe_event>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0xf8, %rsp
      11:      	movq	%rdi, %r13
      14:      	movq	0x50(%rdi), %rax
      18:      	movq	%rax, 0xc0(%rsp)
      20:      	movl	$0x0, 0xe0(%rsp)
      2b:      	movq	(%rip), %rdi            # 0x32 <generic_retkprobe_event+0x32>
      32:      	leaq	0xe0(%rsp), %rsi
      3a:      	movl	$0x1, %eax
      3f:      	callq	*%rax
      41:      	xorl	%ebp, %ebp
      43:      	testq	%rax, %rax
      46:      	je	0x2eeb <generic_retkprobe_event+0x2eeb>
      4c:      	movq	%rax, %r15
      4f:      	movq	%rax, %r12
      52:      	leaq	0x5ef8(%rax), %rsi
      59:      	movl	$0x0, 0x5ef8(%r15)
      64:      	movq	(%rip), %rdi            # 0x6b <generic_retkprobe_event+0x6b>
      6b:      	movl	$0x1, %eax
      70:      	callq	*%rax
      72:      	testq	%rax, %rax
      75:      	je	0x2eeb <generic_retkprobe_event+0x2eeb>
      7b:      	movq	%rax, %r14
      7e:      	movl	(%rax), %eax
      80:      	movq	%rax, 0x60(%r12)
      85:      	movl	$0xe, %eax
      8a:      	callq	*%rax
      8c:      	cmpq	$-0x16, %rax
      90:      	jne	0xb1 <generic_retkprobe_event+0xb1>
      92:      	leaq	0x20(%r13), %rdx
      96:      	leaq	0x28(%rsp), %rdi
      9b:      	movl	$0x8, %ecx
      a0:      	movl	$0x4, %eax
      a5:      	movl	$0x8, %esi
      aa:      	callq	*%rax
      ac:      	movq	0x28(%rsp), %rax
      b1:      	movq	%rax, 0x68(%r12)
      b6:      	movl	$0xe, %eax
      bb:      	callq	*%rax
      bd:      	movl	%eax, 0x7c(%r12)
      c2:      	movq	0x60(%r12), %rax
      c7:      	movq	0x68(%r12), %rcx
      cc:      	movq	%rax, 0x28(%rsp)
      d1:      	movq	%rcx, 0x30(%rsp)
      d6:      	movq	(%rip), %rdi            # 0xdd <generic_retkprobe_event+0xdd>
      dd:      	leaq	0x28(%rsp), %rsi
      e2:      	movl	$0x1, %eax
      e7:      	callq	*%rax
      e9:      	testq	%rax, %rax
      ec:      	je	0x2eeb <generic_retkprobe_event+0x2eeb>
      f2:      	movq	(%rax), %rbx
      f5:      	movq	0x8(%rax), %rcx
      f9:      	movq	%rcx, 0x88(%rsp)
     101:      	movq	0x10(%rax), %rax
     105:      	movq	%rax, 0xa0(%rsp)
     10d:      	movq	(%rip), %rdi            # 0x114 <generic_retkprobe_event+0x114>
     114:      	leaq	0x28(%rsp), %rsi
     119:      	movl	$0x3, %eax
     11e:      	callq	*%rax
     120:      	movq	%rbx, 0x90(%r12)
     128:      	movl	0x58(%r14), %ebp
     12c:      	movl	0x5c(%r14), %ebx
     130:      	testl	%ebx, %ebx
     132:      	je	0x19f <generic_retkprobe_event+0x19f>
     134:      	movl	%ebp, 0x20(%rsp)
     138:      	movl	$0x0, 0x5ea0(%r12)
     144:      	movq	0xc0(%rsp), %rbp
     14c:      	movl	$0x0, 0xe4(%rsp)
     157:      	movq	(%rip), %rdi            # 0x15e <generic_retkprobe_event+0x15e>
     15e:      	leaq	0xe4(%rsp), %rsi
     166:      	movl	$0x1, %eax
     16b:      	callq	*%rax
     16d:      	testq	%rax, %rax
     170:      	je	0x296 <generic_retkprobe_event+0x296>
     176:      	movl	0x5ea0(%rax), %ecx
     17c:      	movl	%ecx, 0x98(%rax)
     182:      	movq	$0xc, 0x5e78(%rax)
     18d:      	testl	%ecx, %ecx
     18f:      	je	0x2f6 <generic_retkprobe_event+0x2f6>
     195:      	movl	$0x4, %ebx
     19a:      	jmp	0x298 <generic_retkprobe_event+0x298>
     19f:      	movl	$0x8, %ebx
     1a4:      	addq	$0x90, %r15
     1ab:      	cmpl	$0x3, %ebp
     1ae:      	jne	0x11db <generic_retkprobe_event+0x11db>
     1b4:      	movq	%r14, 0x78(%rsp)
     1b9:      	movq	%r15, 0x10(%rsp)
     1be:      	movl	$0x0, (%r15,%rbx)
     1c6:      	movq	%rbx, %r15
     1c9:      	addq	$0x4, %rbx
     1cd:      	cmpq	$0x0, 0xa0(%rsp)
     1d6:      	movq	%r13, 0xb8(%rsp)
     1de:      	movq	%r12, 0x80(%rsp)
     1e6:      	je	0x359 <generic_retkprobe_event+0x359>
     1ec:      	movq	0xc0(%rsp), %r14
     1f4:      	leaq	0x28(%rsp), %rdi
     1f9:      	movl	$0x4, %ebp
     1fe:      	movl	$0x10, %ecx
     203:      	movl	$0x4, %eax
     208:      	movq	0x88(%rsp), %rdx
     210:      	movl	$0x10, %esi
     215:      	callq	*%rax
     217:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     21c:      	testl	%eax, %eax
     21e:      	js	0x2c23 <generic_retkprobe_event+0x2c23>
     224:      	movq	0x30(%rsp), %r13
     229:      	cmpq	%r14, %r13
     22c:      	movq	%r14, %r12
     22f:      	cmovbq	%r13, %r12
     233:      	testq	%r14, %r14
     236:      	cmovneq	%r12, %r13
     23a:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
     23f:      	cmpq	$0xffe, %r13            # imm = 0xFFE
     246:      	ja	0x2c23 <generic_retkprobe_event+0x2c23>
     24c:      	addq	$0xc, %r15
     250:      	movq	0x10(%rsp), %rax
     255:      	movq	%r15, 0x20(%rsp)
     25a:      	leaq	(%rax,%r15), %rdi
     25e:      	movq	0x28(%rsp), %rcx
     263:      	movl	$0x4, %eax
     268:      	movq	0x28(%rsp), %rdx
     26d:      	movl	%r13d, %esi
     270:      	callq	*%rax
     272:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     277:      	testl	%eax, %eax
     279:      	js	0x2c23 <generic_retkprobe_event+0x2c23>
     27f:      	testq	%r14, %r14
     282:      	je	0xb6b <generic_retkprobe_event+0xb6b>
     288:      	subq	%r12, %r14
     28b:      	jne	0xb6e <generic_retkprobe_event+0xb6e>
     291:      	jmp	0x35c <generic_retkprobe_event+0x35c>
     296:      	xorl	%ebx, %ebx
     298:      	movl	0x20(%rsp), %ebp
     29c:      	addq	$0x8, %rbx
     2a0:      	movl	0x60(%r14), %eax
     2a4:      	cmpl	$0xb, %eax
     2a7:      	je	0x11af <generic_retkprobe_event+0x11af>
     2ad:      	cmpl	$0xa, %eax
     2b0:      	jne	0x11c5 <generic_retkprobe_event+0x11c5>
     2b6:      	movl	0x10(%r12), %eax
     2bb:      	movl	%eax, 0x28(%rsp)
     2bf:      	movl	0x7c(%r12), %eax
     2c4:      	movl	%eax, 0x2c(%rsp)
     2c8:      	movq	0x18(%r12), %rax
     2cd:      	movq	%rax, 0x30(%rsp)
     2d2:      	movq	(%rip), %rdi            # 0x2d9 <generic_retkprobe_event+0x2d9>
     2d9:      	xorl	%ecx, %ecx
     2db:      	leaq	0xc0(%rsp), %rsi
     2e3:      	leaq	0x28(%rsp), %rdx
     2e8:      	movl	$0x2, %eax
     2ed:      	xorl	%ecx, %ecx
     2ef:      	callq	*%rax
     2f1:      	jmp	0x11c5 <generic_retkprobe_event+0x11c5>
     2f6:      	leaq	0x9c(%rax), %rcx
     2fd:      	movq	%rbp, 0x28(%rsp)
     302:      	movq	$0x0, 0x68(%rsp)
     30b:      	cmpl	$0x17, %ebx
     30e:      	movq	%rax, (%rsp)
     312:      	movq	%r13, 0xb8(%rsp)
     31a:      	movq	%r14, 0x78(%rsp)
     31f:      	jle	0x376 <generic_retkprobe_event+0x376>
     321:      	cmpl	$0x18, %ebx
     324:      	je	0x38f <generic_retkprobe_event+0x38f>
     326:      	cmpl	$0x25, %ebx
     329:      	je	0x3cd <generic_retkprobe_event+0x3cd>
     32f:      	cmpl	$0x2a, %ebx
     332:      	jne	0x973 <generic_retkprobe_event+0x973>
     338:      	movq	$0x0, 0x90(%rsp)
     344:      	movq	%rbp, 0x98(%rsp)
     34c:      	leaq	0x90(%rsp), %r14
     354:      	jmp	0x3fa <generic_retkprobe_event+0x3fa>
     359:      	xorl	%r12d, %r12d
     35c:      	movq	0x10(%rsp), %rax
     361:      	movl	%r12d, (%rax,%rbx)
     365:      	movl	%r12d, 0x4(%rax,%rbx)
     36a:      	addq	$0x8, %r12
     36e:      	movq	%r12, %rbp
     371:      	jmp	0x2c2b <generic_retkprobe_event+0x2c2b>
     376:      	cmpl	$0xf, %ebx
     379:      	je	0x8be <generic_retkprobe_event+0x8be>
     37f:      	cmpl	$0x10, %ebx
     382:      	jne	0x973 <generic_retkprobe_event+0x973>
     388:      	leaq	0x18(%rsp), %r14
     38d:      	jmp	0x3b7 <generic_retkprobe_event+0x3b7>
     38f:      	leaq	0x18(%rsp), %r14
     394:      	movl	$0x8, %ecx
     399:      	movl	$0x4, %eax
     39e:      	movq	0x28(%rsp), %rdx
     3a3:      	movq	%r14, %rdi
     3a6:      	movl	$0x8, %esi
     3ab:      	callq	*%rax
     3ad:      	movq	0x18(%rsp), %rax
     3b2:      	movq	%rax, 0x28(%rsp)
     3b7:      	leaq	0x28(%rsp), %rdx
     3bc:      	movl	$0x8, %ecx
     3c1:      	movl	$0x4, %eax
     3c6:      	leaq	0x18(%rsp), %rdi
     3cb:      	jmp	0x3ea <generic_retkprobe_event+0x3ea>
     3cd:      	addq	$0x40, %rbp
     3d1:      	movq	%rbp, 0x28(%rsp)
     3d6:      	leaq	0x18(%rsp), %rdi
     3db:      	movl	$0x8, %ecx
     3e0:      	movl	$0x4, %eax
     3e5:      	movq	0x28(%rsp), %rdx
     3ea:      	movl	$0x8, %esi
     3ef:      	callq	*%rax
     3f1:      	movq	0x18(%rsp), %r14
     3f6:      	addq	$0x40, %r14
     3fa:      	movl	$0x0, 0xac(%rsp)
     405:      	movq	(%rip), %rdi            # 0x40c <generic_retkprobe_event+0x40c>
     40c:      	leaq	0xac(%rsp), %rsi
     414:      	movl	$0x1, %eax
     419:      	callq	*%rax
     41b:      	testq	%rax, %rax
     41e:      	je	0x4d5 <generic_retkprobe_event+0x4d5>
     424:      	movq	%rax, %r13
     427:      	movq	%r15, 0x10(%rsp)
     42c:      	addq	$0x1000, %rax           # imm = 0x1000
     432:      	movq	%rax, 0x8(%rsp)
     437:      	movl	$0x23, %eax
     43c:      	callq	*%rax
     43e:      	leaq	0xd50(%rax), %rdx
     445:      	leaq	0xc8(%rsp), %rdi
     44d:      	movl	$0x8, %ecx
     452:      	movl	$0x4, %eax
     457:      	movl	$0x8, %esi
     45c:      	callq	*%rax
     45e:      	movq	0xc8(%rsp), %rbp
     466:      	leaq	0x8(%r14), %rdx
     46a:      	leaq	0xd0(%rsp), %rdi
     472:      	movl	$0x8, %ecx
     477:      	movl	$0x4, %eax
     47c:      	leaq	0x18(%rbp), %rcx
     480:      	movq	%rcx, 0xf0(%rsp)
     488:      	movl	$0x8, %esi
     48d:      	movq	%rdx, 0xe8(%rsp)
     495:      	callq	*%rax
     497:      	movq	0xd0(%rsp), %r15
     49f:      	leaq	0x10(%r15), %rdx
     4a3:      	leaq	0x28(%rsp), %rdi
     4a8:      	movl	$0x8, %ecx
     4ad:      	movl	$0x4, %eax
     4b2:      	movl	$0x8, %esi
     4b7:      	callq	*%rax
     4b9:      	cmpq	$0x0, 0x28(%rsp)
     4bf:      	movl	$0x1000, %ebx           # imm = 0x1000
     4c4:      	movq	%r12, 0x80(%rsp)
     4cc:      	je	0x4e6 <generic_retkprobe_event+0x4e6>
     4ce:      	movq	0x8(%rsp), %rcx
     4d3:      	jmp	0x536 <generic_retkprobe_event+0x536>
     4d5:      	xorl	%r13d, %r13d
     4d8:      	movq	0x78(%rsp), %r14
     4dd:      	movl	0x20(%rsp), %ebp
     4e1:      	jmp	0x1172 <generic_retkprobe_event+0x1172>
     4e6:      	leaq	0x18(%r15), %rdx
     4ea:      	leaq	0x28(%rsp), %rdi
     4ef:      	movl	$0x8, %ecx
     4f4:      	movl	$0x4, %eax
     4f9:      	movl	$0x8, %esi
     4fe:      	callq	*%rax
     500:      	cmpq	%r15, 0x28(%rsp)
     505:      	movq	0x8(%rsp), %rcx
     50a:      	je	0x536 <generic_retkprobe_event+0x536>
     50c:      	movq	%r13, %rcx
     50f:      	addq	$0xff6, %rcx            # imm = 0xFF6
     516:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
     520:      	movq	%rax, 0xff6(%r13)
     527:      	movw	$0x2964, 0xffe(%r13)    # imm = 0x2964
     531:      	movl	$0xff6, %ebx            # imm = 0xFF6
     536:      	movq	$0x0, 0x30(%rsp)
     53f:      	movq	$0x0, 0x28(%rsp)
     548:      	movq	%r13, 0x38(%rsp)
     54d:      	movq	$0x0, 0x40(%rsp)
     556:      	movq	$0x0, 0x48(%rsp)
     55f:      	movq	$0x0, 0x50(%rsp)
     568:      	movq	%rcx, 0x8(%rsp)
     56d:      	movq	%rcx, 0x58(%rsp)
     572:      	movl	%ebx, 0x60(%rsp)
     576:      	movb	$0x0, 0x64(%rsp)
     57b:      	addq	$0x20, %rbp
     57f:      	leaq	0x28(%rsp), %rdi
     584:      	movl	$0x8, %r12d
     58a:      	movl	$0x4, %eax
     58f:      	leaq	0x30(%rsp), %rbx
     594:      	leaq	0x40(%rsp), %r15
     599:      	leaq	0x48(%rsp), %r13
     59e:      	movl	$0x8, %esi
     5a3:      	movq	%rbp, %rdx
     5a6:      	callq	*%rax
     5a8:      	movl	$0x8, %ecx
     5ad:      	movl	$0x4, %eax
     5b2:      	movq	0xf0(%rsp), %rdx
     5ba:      	movq	%rbx, %rdi
     5bd:      	movl	$0x8, %esi
     5c2:      	callq	*%rax
     5c4:      	movl	$0x8, %ecx
     5c9:      	movl	$0x4, %eax
     5ce:      	movq	0xe8(%rsp), %rdx
     5d6:      	movq	%r15, %rdi
     5d9:      	movl	$0x8, %esi
     5de:      	callq	*%rax
     5e0:      	movl	$0x8, %ecx
     5e5:      	movl	$0x4, %eax
     5ea:      	movq	%r13, %rdi
     5ed:      	movl	$0x8, %esi
     5f2:      	movq	%r14, %rdx
     5f5:      	callq	*%rax
     5f7:      	movq	0x48(%rsp), %rax
     5fc:      	addq	$-0x20, %rax
     600:      	movq	%rax, 0x50(%rsp)
     605:      	movl	$0x80, %r15d
     60b:      	leaq	0x18(%rsp), %rbp
     610:      	movq	0x40(%rsp), %r14
     615:      	movq	0x48(%rsp), %rdx
     61a:      	movq	0x50(%rsp), %r13
     61f:      	cmpq	0x28(%rsp), %r14
     624:      	jne	0x631 <generic_retkprobe_event+0x631>
     626:      	cmpq	0x30(%rsp), %rdx
     62b:      	je	0x79b <generic_retkprobe_event+0x79b>
     631:      	movl	$0x4, %eax
     636:      	leaq	0xb0(%rsp), %rdi
     63e:      	movl	$0x8, %esi
     643:      	callq	*%rax
     645:      	cmpq	0xb0(%rsp), %r14
     64d:      	je	0x746 <generic_retkprobe_event+0x746>
     653:      	leaq	0x18(%r14), %rbx
     657:      	movl	$0x4, %eax
     65c:      	movq	%rbp, %rdi
     65f:      	movl	$0x8, %esi
     664:      	movq	%rbx, %rdx
     667:      	callq	*%rax
     669:      	cmpq	%r14, 0x18(%rsp)
     66e:      	je	0x746 <generic_retkprobe_event+0x746>
     674:      	movl	$0x4, %eax
     679:      	leaq	0xd8(%rsp), %rdi
     681:      	movl	$0x8, %esi
     686:      	movq	%rbx, %rdx
     689:      	callq	*%rax
     68b:      	addq	$0x20, %r14
     68f:      	movl	$0x4, %eax
     694:      	leaq	0x68(%rsp), %rdi
     699:      	movl	$0x10, %ecx
     69e:      	movl	$0x10, %esi
     6a3:      	movq	%r14, %rdx
     6a6:      	callq	*%rax
     6a8:      	movq	0x38(%rsp), %rbx
     6ad:      	movq	0x58(%rsp), %rax
     6b2:      	movl	0x6c(%rsp), %r14d
     6b7:      	subq	%rbx, %rax
     6ba:      	movl	0x60(%rsp), %r13d
     6bf:      	movl	%r14d, %edx
     6c2:      	subl	%r13d, %edx
     6c5:      	movl	$0x0, %ecx
     6ca:      	cmovbl	%ecx, %edx
     6cd:      	addq	0x70(%rsp), %rdx
     6d2:      	xorl	%esi, %esi
     6d4:      	cmpl	%r14d, %r13d
     6d7:      	seta	%sil
     6db:      	movl	%r14d, %ecx
     6de:      	cmovbl	%r13d, %ecx
     6e2:      	addl	%ecx, %esi
     6e4:      	movl	%r13d, %edi
     6e7:      	subl	%esi, %edi
     6e9:      	movl	%edi, 0x60(%rsp)
     6ed:      	subq	%rsi, %rax
     6f0:      	jb	0x7a0 <generic_retkprobe_event+0x7a0>
     6f6:      	cmpq	$0xfff, %rax            # imm = 0xFFF
     6fc:      	ja	0x7a0 <generic_retkprobe_event+0x7a0>
     702:      	cmpl	%r14d, %r13d
     705:      	jbe	0x70b <generic_retkprobe_event+0x70b>
     707:      	movb	$0x2f, (%rbx,%rax)
     70b:      	xorl	%edi, %edi
     70d:      	cmpl	%r14d, %r13d
     710:      	seta	%dil
     714:      	movzbl	%cl, %esi
     717:      	addq	%rax, %rbx
     71a:      	addq	%rbx, %rdi
     71d:      	movl	$0x4, %eax
     722:      	callq	*%rax
     724:      	movq	%rbx, 0x58(%rsp)
     729:      	cmpl	%r14d, %r13d
     72c:      	jbe	0x7a0 <generic_retkprobe_event+0x7a0>
     72e:      	movq	0xd8(%rsp), %rax
     736:      	movq	%rax, 0x40(%rsp)
     73b:      	decl	%r15d
     73e:      	jne	0x610 <generic_retkprobe_event+0x610>
     744:      	jmp	0x7a0 <generic_retkprobe_event+0x7a0>
     746:      	leaq	0x10(%r13), %rdx
     74a:      	movl	$0x4, %eax
     74f:      	movq	%rbp, %rdi
     752:      	movl	$0x8, %esi
     757:      	callq	*%rax
     759:      	movq	0x50(%rsp), %rax
     75e:      	cmpq	0x18(%rsp), %rax
     763:      	je	0x79b <generic_retkprobe_event+0x79b>
     765:      	addq	$0x18, %r13
     769:      	movl	$0x4, %eax
     76e:      	leaq	0x40(%rsp), %rdi
     773:      	movl	$0x8, %esi
     778:      	movq	%r13, %rdx
     77b:      	callq	*%rax
     77d:      	movq	0x18(%rsp), %rax
     782:      	movq	%rax, 0x50(%rsp)
     787:      	addq	$0x20, %rax
     78b:      	movq	%rax, 0x48(%rsp)
     790:      	decl	%r15d
     793:      	jne	0x610 <generic_retkprobe_event+0x610>
     799:      	jmp	0x7a0 <generic_retkprobe_event+0x7a0>
     79b:      	movb	$0x1, 0x64(%rsp)
     7a0:      	movq	0x58(%rsp), %rax
     7a5:      	movq	0x8(%rsp), %rdx
     7aa:      	cmpq	%rdx, %rax
     7ad:      	movq	0x78(%rsp), %r14
     7b2:      	je	0x7f8 <generic_retkprobe_event+0x7f8>
     7b4:      	xorl	%ebx, %ebx
     7b6:      	cmpb	$0x0, 0x64(%rsp)
     7bb:      	sete	%cl
     7be:      	movl	0x60(%rsp), %edx
     7c2:      	movl	$0x1000, %r13d          # imm = 0x1000
     7c8:      	subl	%edx, %r13d
     7cb:      	testl	%edx, %edx
     7cd:      	cmovlel	%edx, %r13d
     7d1:      	testq	%rax, %rax
     7d4:      	movq	(%rsp), %rdi
     7d8:      	movq	0x80(%rsp), %r12
     7e0:      	movq	0x10(%rsp), %r15
     7e5:      	movl	0x20(%rsp), %ebp
     7e9:      	je	0xb55 <generic_retkprobe_event+0xb55>
     7ef:      	movb	%cl, %bl
     7f1:      	addl	%ebx, %ebx
     7f3:      	movq	%rax, %rdx
     7f6:      	jmp	0x812 <generic_retkprobe_event+0x812>
     7f8:      	xorl	%ebx, %ebx
     7fa:      	xorl	%r13d, %r13d
     7fd:      	movq	(%rsp), %rdi
     801:      	movq	0x80(%rsp), %r12
     809:      	movq	0x10(%rsp), %r15
     80e:      	movl	0x20(%rsp), %ebp
     812:      	addq	$0xa0, %rdi
     819:      	andl	$0xfff, %r13d           # imm = 0xFFF
     820:      	movl	$0x4, %eax
     825:      	movl	%r13d, %esi
     828:      	callq	*%rax
     82a:      	movq	(%rsp), %rax
     82e:      	movl	%r13d, 0x9c(%rax)
     835:      	leaq	0x28(%rsp), %rdi
     83a:      	movl	$0x8, %ecx
     83f:      	movl	$0x4, %eax
     844:      	movq	0xe8(%rsp), %rdx
     84c:      	movl	$0x8, %esi
     851:      	callq	*%rax
     853:      	movq	0x28(%rsp), %rcx
     858:      	addq	$0x30, %rcx
     85c:      	leaq	0x68(%rsp), %rdi
     861:      	movl	$0x8, %edx
     866:      	movl	$0x4, %eax
     86b:      	movq	0x28(%rsp), %rdx
     870:      	addq	$0x30, %rdx
     874:      	movl	$0x8, %esi
     879:      	callq	*%rax
     87b:      	movq	0x68(%rsp), %rcx
     880:      	leaq	0x18(%rsp), %rdi
     885:      	movl	$0x2, %edx
     88a:      	movl	$0x4, %eax
     88f:      	movq	0x68(%rsp), %rdx
     894:      	movl	$0x2, %esi
     899:      	callq	*%rax
     89b:      	movq	(%rsp), %rcx
     89f:      	movl	%ebx, 0xa0(%rcx,%r13)
     8a7:      	movzwl	0x18(%rsp), %eax
     8ac:      	movw	%ax, 0xa4(%rcx,%r13)
     8b5:      	addl	$0xa, %r13d
     8b9:      	jmp	0x1168 <generic_retkprobe_event+0x1168>
     8be:      	movq	%rcx, 0x8(%rsp)
     8c3:      	leaq	0x68(%rsp), %rdi
     8c8:      	leaq	0x28(%rsp), %rdx
     8cd:      	movl	$0x8, %ecx
     8d2:      	movl	$0x4, %eax
     8d7:      	movl	$0x8, %esi
     8dc:      	callq	*%rax
     8de:      	movq	0x68(%rsp), %r14
     8e3:      	testq	%r14, %r14
     8e6:      	jne	0x3fa <generic_retkprobe_event+0x3fa>
     8ec:      	movl	$0x0, 0x90(%rsp)
     8f7:      	movq	(%rip), %rdi            # 0x8fe <generic_retkprobe_event+0x8fe>
     8fe:      	leaq	0x90(%rsp), %rsi
     906:      	movl	$0x1, %eax
     90b:      	callq	*%rax
     90d:      	xorl	%r13d, %r13d
     910:      	testq	%rax, %rax
     913:      	je	0xb5d <generic_retkprobe_event+0xb5d>
     919:      	cmpl	$0x19, %ebx
     91c:      	movq	(%rsp), %rcx
     920:      	movq	0x78(%rsp), %r14
     925:      	jg	0xd2a <generic_retkprobe_event+0xd2a>
     92b:      	cmpl	$0x12, %ebx
     92e:      	jle	0xd5e <generic_retkprobe_event+0xd5e>
     934:      	cmpl	$0x14, %ebx
     937:      	jle	0x1263 <generic_retkprobe_event+0x1263>
     93d:      	cmpl	$0x15, %ebx
     940:      	je	0x1b6c <generic_retkprobe_event+0x1b6c>
     946:      	cmpl	$0x16, %ebx
     949:      	je	0x1ad4 <generic_retkprobe_event+0x1ad4>
     94f:      	cmpl	$0x17, %ebx
     952:      	jne	0x1164 <generic_retkprobe_event+0x1164>
     958:      	movl	$0x0, 0xa0(%rcx)
     962:      	movl	%ebp, 0x9c(%rcx)
     968:      	movl	$0x8, %r13d
     96e:      	jmp	0x1164 <generic_retkprobe_event+0x1164>
     973:      	movq	%rcx, 0x8(%rsp)
     978:      	cmpl	$0x28, %ebx
     97b:      	ja	0x8ec <generic_retkprobe_event+0x8ec>
     981:      	movl	%ebx, %eax
     983:      	movabsq	$0x1c1f2027cf2, %rcx    # imm = 0x1C1F2027CF2
     98d:      	btq	%rax, %rcx
     991:      	jae	0x8ec <generic_retkprobe_event+0x8ec>
     997:      	movq	%rbp, 0x18(%rsp)
     99c:      	movl	$0x0, 0xd8(%rsp)
     9a7:      	movq	(%rip), %rdi            # 0x9ae <generic_retkprobe_event+0x9ae>
     9ae:      	leaq	0xd8(%rsp), %rsi
     9b6:      	movl	$0x1, %eax
     9bb:      	callq	*%rax
     9bd:      	xorl	%r13d, %r13d
     9c0:      	testq	%rax, %rax
     9c3:      	je	0xb5d <generic_retkprobe_event+0xb5d>
     9c9:      	cmpl	$0x10, %ebx
     9cc:      	jg	0xc2e <generic_retkprobe_event+0xc2e>
     9d2:      	cmpl	$0x9, %ebx
     9d5:      	movq	0x78(%rsp), %r14
     9da:      	jg	0xc69 <generic_retkprobe_event+0xc69>
     9e0:      	cmpl	$0x4, %ebx
     9e3:      	movq	(%rsp), %rcx
     9e7:      	jle	0xd8f <generic_retkprobe_event+0xd8f>
     9ed:      	cmpl	$0x5, %ebx
     9f0:      	je	0x1426 <generic_retkprobe_event+0x1426>
     9f6:      	cmpl	$0x6, %ebx
     9f9:      	je	0xcce <generic_retkprobe_event+0xcce>
     9ff:      	cmpl	$0x7, %ebx
     a02:      	jne	0x1164 <generic_retkprobe_event+0x1164>
     a08:      	movq	%rax, %rbp
     a0b:      	movq	%r15, 0x10(%rsp)
     a10:      	movq	%r12, %r15
     a13:      	movq	0x18(%rsp), %r12
     a18:      	movq	%r12, 0xc4(%rcx)
     a1f:      	leaq	0xc2(%rcx), %rdi
     a26:      	leaq	0x10(%r12), %rdx
     a2b:      	movl	$0x2, %esi
     a30:      	movq	%rcx, %rbx
     a33:      	movl	$0x4, %eax
     a38:      	movl	$0x2, %esi
     a3d:      	callq	*%rax
     a3f:      	leaq	0xd6(%rbx), %rdi
     a46:      	leaq	0x12(%r12), %rdx
     a4b:      	movl	$0x1, %ecx
     a50:      	movl	$0x4, %eax
     a55:      	movl	$0x1, %esi
     a5a:      	callq	*%rax
     a5c:      	leaq	0xd4(%rbx), %rdi
     a63:      	leaq	0x226(%r12), %rdx
     a6b:      	movl	$0x2, %ecx
     a70:      	movl	$0x4, %eax
     a75:      	movl	$0x2, %esi
     a7a:      	callq	*%rax
     a7c:      	leaq	0xc0(%rbx), %rdi
     a83:      	leaq	0x224(%r12), %rdx
     a8b:      	movl	$0x2, %ecx
     a90:      	movl	$0x4, %eax
     a95:      	movl	$0x2, %esi
     a9a:      	callq	*%rax
     a9c:      	leaq	0xcc(%rbx), %rdi
     aa3:      	leaq	0x21c(%r12), %rdx
     aab:      	movl	$0x4, %ecx
     ab0:      	movl	$0x4, %eax
     ab5:      	movl	$0x4, %esi
     aba:      	callq	*%rax
     abc:      	leaq	0xd0(%rbx), %rdi
     ac3:      	leaq	0x218(%r12), %rdx
     acb:      	movl	$0x4, %ecx
     ad0:      	movl	$0x4, %eax
     ad5:      	movl	$0x4, %esi
     ada:      	callq	*%rax
     adc:      	leaq	0xac(%rbx), %r14
     ae3:      	movq	0x8(%rsp), %rax
     ae8:      	movq	$0x0, (%rax)
     aef:      	movq	$0x0, 0x8(%rax)
     af7:      	movq	$0x0, 0x10(%rax)
     aff:      	movq	$0x0, 0x18(%rax)
     b07:      	movzwl	0xc2(%rbx), %eax
     b0e:      	cmpl	$0xa, %eax
     b11:      	je	0x1e83 <generic_retkprobe_event+0x1e83>
     b17:      	cmpl	$0x2, %eax
     b1a:      	jne	0x1eb7 <generic_retkprobe_event+0x1eb7>
     b20:      	leaq	0x4(%r12), %rdx
     b25:      	movl	$0x4, %ecx
     b2a:      	movl	$0x4, %eax
     b2f:      	movq	0x8(%rsp), %rdi
     b34:      	movl	$0x4, %esi
     b39:      	callq	*%rax
     b3b:      	movl	$0x4, %ecx
     b40:      	movl	$0x4, %eax
     b45:      	movq	%r14, %rdi
     b48:      	movl	$0x4, %esi
     b4d:      	movq	%r12, %rdx
     b50:      	jmp	0x1eb5 <generic_retkprobe_event+0x1eb5>
     b55:      	xorl	%r13d, %r13d
     b58:      	jmp	0x1172 <generic_retkprobe_event+0x1172>
     b5d:      	movq	(%rsp), %rcx
     b61:      	movq	0x78(%rsp), %r14
     b66:      	jmp	0x1164 <generic_retkprobe_event+0x1164>
     b6b:      	xorl	%r14d, %r14d
     b6e:      	cmpq	$0x1, 0xa0(%rsp)
     b77:      	jne	0xb81 <generic_retkprobe_event+0xb81>
     b79:      	movq	%r13, %r12
     b7c:      	jmp	0x35c <generic_retkprobe_event+0x35c>
     b81:      	movq	0x88(%rsp), %rax
     b89:      	leaq	0x10(%rax), %rdx
     b8d:      	leaq	0x28(%rsp), %rdi
     b92:      	movl	$0x4, %ebp
     b97:      	movl	$0x10, %ecx
     b9c:      	movl	$0x4, %eax
     ba1:      	movl	$0x10, %esi
     ba6:      	callq	*%rax
     ba8:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     bad:      	testl	%eax, %eax
     baf:      	js	0x2c23 <generic_retkprobe_event+0x2c23>
     bb5:      	movq	0x30(%rsp), %r15
     bba:      	cmpq	%r14, %r15
     bbd:      	movq	%r14, %r12
     bc0:      	cmovbq	%r15, %r12
     bc4:      	testq	%r14, %r14
     bc7:      	cmovneq	%r12, %r15
     bcb:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
     bd0:      	cmpq	$0xffe, %r15            # imm = 0xFFE
     bd7:      	ja	0x2c23 <generic_retkprobe_event+0x2c23>
     bdd:      	movq	0x20(%rsp), %rcx
     be2:      	addq	%r13, %rcx
     be5:      	movq	0x10(%rsp), %rax
     bea:      	movq	%rcx, 0x20(%rsp)
     bef:      	leaq	(%rax,%rcx), %rdi
     bf3:      	movq	0x28(%rsp), %rcx
     bf8:      	movl	$0x4, %eax
     bfd:      	movq	0x28(%rsp), %rdx
     c02:      	movl	%r15d, %esi
     c05:      	callq	*%rax
     c07:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     c0c:      	testl	%eax, %eax
     c0e:      	js	0x2c23 <generic_retkprobe_event+0x2c23>
     c14:      	addq	%r15, %r13
     c17:      	testq	%r14, %r14
     c1a:      	je	0x1715 <generic_retkprobe_event+0x1715>
     c20:      	subq	%r12, %r14
     c23:      	jne	0x1718 <generic_retkprobe_event+0x1718>
     c29:      	jmp	0xb79 <generic_retkprobe_event+0xb79>
     c2e:      	cmpl	$0x1e, %ebx
     c31:      	movq	0x78(%rsp), %r14
     c36:      	jg	0xcf1 <generic_retkprobe_event+0xcf1>
     c3c:      	cmpl	$0x1c, %ebx
     c3f:      	jg	0xde5 <generic_retkprobe_event+0xde5>
     c45:      	cmpl	$0x11, %ebx
     c48:      	je	0x15fd <generic_retkprobe_event+0x15fd>
     c4e:      	cmpl	$0x19, %ebx
     c51:      	je	0x133f <generic_retkprobe_event+0x133f>
     c57:      	cmpl	$0x1c, %ebx
     c5a:      	movq	(%rsp), %rcx
     c5e:      	je	0xd9d <generic_retkprobe_event+0xd9d>
     c64:      	jmp	0x1164 <generic_retkprobe_event+0x1164>
     c69:      	leal	-0xa(%rbx), %eax
     c6c:      	cmpl	$0x2, %eax
     c6f:      	movq	(%rsp), %rcx
     c73:      	jb	0xd9d <generic_retkprobe_event+0xd9d>
     c79:      	leal	-0xc(%rbx), %eax
     c7c:      	cmpl	$0x2, %eax
     c7f:      	jb	0xdc1 <generic_retkprobe_event+0xdc1>
     c85:      	cmpl	$0xe, %ebx
     c88:      	jne	0x1164 <generic_retkprobe_event+0x1164>
     c8e:      	leaq	0x28(%rsp), %rdi
     c93:      	leaq	0x18(%rsp), %rbx
     c98:      	movl	$0x8, %ecx
     c9d:      	movl	$0x4, %eax
     ca2:      	movl	$0x8, %esi
     ca7:      	movq	%rbx, %rdx
     caa:      	callq	*%rax
     cac:      	movq	0x28(%rsp), %rcx
     cb1:      	movl	$0x8, %edx
     cb6:      	movl	$0x4, %eax
     cbb:      	movq	0x28(%rsp), %rdx
     cc0:      	movq	%rbx, %rdi
     cc3:      	movl	$0x8, %esi
     cc8:      	callq	*%rax
     cca:      	movq	(%rsp), %rcx
     cce:      	movq	0x18(%rsp), %rdx
     cd3:      	movq	%rcx, %rdi
     cd6:      	addq	$0xa0, %rdi
     cdd:      	movl	$0x1ff, %ecx            # imm = 0x1FF
     ce2:      	movl	$0x2d, %eax
     ce7:      	movl	$0x1ff, %esi            # imm = 0x1FF
     cec:      	jmp	0x16f3 <generic_retkprobe_event+0x16f3>
     cf1:      	cmpl	$0x26, %ebx
     cf4:      	jg	0xe09 <generic_retkprobe_event+0xe09>
     cfa:      	leal	-0x1f(%rbx), %eax
     cfd:      	cmpl	$0x2, %eax
     d00:      	jae	0x1106 <generic_retkprobe_event+0x1106>
     d06:      	leaq	0x18(%rsp), %rdx
     d0b:      	movl	$0x4, %r13d
     d11:      	movl	$0x1, %ecx
     d16:      	movl	$0x4, %eax
     d1b:      	movq	0x8(%rsp), %rdi
     d20:      	movl	$0x1, %esi
     d25:      	jmp	0x115e <generic_retkprobe_event+0x115e>
     d2a:      	cmpl	$0x20, %ebx
     d2d:      	jle	0x1047 <generic_retkprobe_event+0x1047>
     d33:      	leal	-0x21(%rbx), %edx
     d36:      	cmpl	$0x4, %edx
     d39:      	jae	0xec2 <generic_retkprobe_event+0xec2>
     d3f:      	movl	$0x8, %r13d
     d45:      	movl	$0x8, %ecx
     d4a:      	movl	$0x4, %eax
     d4f:      	movq	0x8(%rsp), %rdi
     d54:      	movl	$0x8, %esi
     d59:      	jmp	0x115b <generic_retkprobe_event+0x115b>
     d5e:      	cmpl	$0x7, %ebx
     d61:      	jg	0x113e <generic_retkprobe_event+0x113e>
     d67:      	cmpl	$0x2, %ebx
     d6a:      	je	0x17e1 <generic_retkprobe_event+0x17e1>
     d70:      	cmpl	$0x3, %ebx
     d73:      	jne	0x1164 <generic_retkprobe_event+0x1164>
     d79:      	movq	$0x0, 0x9c(%rax)
     d84:      	movl	$0x8, %r13d
     d8a:      	jmp	0x1164 <generic_retkprobe_event+0x1164>
     d8f:      	cmpl	$0x1, %ebx
     d92:      	je	0xdc1 <generic_retkprobe_event+0xdc1>
     d94:      	cmpl	$0x4, %ebx
     d97:      	jne	0x1164 <generic_retkprobe_event+0x1164>
     d9d:      	movl	$0x8, %r13d
     da3:      	leaq	0x18(%rsp), %rdx
     da8:      	movl	$0x8, %ecx
     dad:      	movl	$0x4, %eax
     db2:      	movq	0x8(%rsp), %rdi
     db7:      	movl	$0x8, %esi
     dbc:      	jmp	0x115e <generic_retkprobe_event+0x115e>
     dc1:      	leaq	0x18(%rsp), %rdx
     dc6:      	movl	$0x4, %r13d
     dcc:      	movl	$0x4, %ecx
     dd1:      	movl	$0x4, %eax
     dd6:      	movq	0x8(%rsp), %rdi
     ddb:      	movl	$0x4, %esi
     de0:      	jmp	0x115e <generic_retkprobe_event+0x115e>
     de5:      	leaq	0x18(%rsp), %rdx
     dea:      	movl	$0x4, %r13d
     df0:      	movl	$0x2, %ecx
     df5:      	movl	$0x4, %eax
     dfa:      	movq	0x8(%rsp), %rdi
     dff:      	movl	$0x2, %esi
     e04:      	jmp	0x115e <generic_retkprobe_event+0x115e>
     e09:      	cmpl	$0x27, %ebx
     e0c:      	je	0x16cf <generic_retkprobe_event+0x16cf>
     e12:      	cmpl	$0x28, %ebx
     e15:      	movq	(%rsp), %rcx
     e19:      	jne	0x1164 <generic_retkprobe_event+0x1164>
     e1f:      	movq	%r15, %rbp
     e22:      	movq	%r14, %r15
     e25:      	movq	%r12, %r14
     e28:      	movq	0x18(%rsp), %r12
     e2d:      	movq	0x8(%rsp), %rbx
     e32:      	movq	$0x0, 0x10(%rbx)
     e3a:      	movq	$0x0, 0x8(%rbx)
     e42:      	movq	$0x0, (%rbx)
     e49:      	movl	$0x2, %ecx
     e4e:      	movl	$0x4, %eax
     e53:      	movq	%rbx, %rdi
     e56:      	movl	$0x2, %esi
     e5b:      	movq	%r12, %rdx
     e5e:      	callq	*%rax
     e60:      	testq	%rax, %rax
     e63:      	js	0x1fc3 <generic_retkprobe_event+0x1fc3>
     e69:      	movzwl	(%rbx), %eax
     e6c:      	cmpl	$0xa, %eax
     e6f:      	je	0x1f6c <generic_retkprobe_event+0x1f6c>
     e75:      	cmpl	$0x2, %eax
     e78:      	jne	0x1faf <generic_retkprobe_event+0x1faf>
     e7e:      	leaq	0x4(%r12), %rdx
     e83:      	leaq	0x28(%rsp), %rdi
     e88:      	movl	$0x4, %ecx
     e8d:      	movl	$0x4, %eax
     e92:      	movl	$0x4, %esi
     e97:      	callq	*%rax
     e99:      	movl	0x28(%rsp), %eax
     e9d:      	movq	(%rsp), %rdi
     ea1:      	movq	%rax, 0xa4(%rdi)
     ea8:      	addq	$0x9e, %rdi
     eaf:      	addq	$0x2, %r12
     eb3:      	movl	$0x2, %ecx
     eb8:      	movl	$0x4, %eax
     ebd:      	jmp	0x1fa5 <generic_retkprobe_event+0x1fa5>
     ec2:      	cmpl	$0x2b, %ebx
     ec5:      	je	0x1c77 <generic_retkprobe_event+0x1c77>
     ecb:      	cmpl	$0x29, %ebx
     ece:      	jne	0x1164 <generic_retkprobe_event+0x1164>
     ed4:      	movq	%r15, 0x10(%rsp)
     ed9:      	movq	%r12, 0x80(%rsp)
     ee1:      	movq	%rax, %r13
     ee4:      	addq	$0x18, %rbp
     ee8:      	leaq	0x28(%rsp), %rdi
     eed:      	movl	$0x4, %ebx
     ef2:      	movl	$0x8, %ecx
     ef7:      	movl	$0x4, %eax
     efc:      	movl	$0x8, %esi
     f01:      	movq	%rbp, %rdx
     f04:      	callq	*%rax
     f06:      	movq	0x28(%rsp), %r12
     f0b:      	testq	%r12, %r12
     f0e:      	je	0x2116 <generic_retkprobe_event+0x2116>
     f14:      	movq	(%rsp), %r15
     f18:      	movq	%r12, 0xc4(%r15)
     f1f:      	leaq	0xc2(%r15), %rdi
     f26:      	leaq	0x10(%r12), %rdx
     f2b:      	movl	$0x2, %ecx
     f30:      	movl	$0x4, %eax
     f35:      	movl	$0x2, %esi
     f3a:      	callq	*%rax
     f3c:      	leaq	0xd6(%r15), %rdi
     f43:      	leaq	0x12(%r12), %rdx
     f48:      	movl	$0x1, %ecx
     f4d:      	movl	$0x4, %eax
     f52:      	movl	$0x1, %esi
     f57:      	callq	*%rax
     f59:      	leaq	0xd4(%r15), %rdi
     f60:      	leaq	0x226(%r12), %rdx
     f68:      	movl	$0x2, %ecx
     f6d:      	movl	$0x4, %eax
     f72:      	movl	$0x2, %esi
     f77:      	callq	*%rax
     f79:      	leaq	0xc0(%r15), %rdi
     f80:      	leaq	0x224(%r12), %rdx
     f88:      	movl	$0x2, %ecx
     f8d:      	movl	$0x4, %eax
     f92:      	movl	$0x2, %esi
     f97:      	callq	*%rax
     f99:      	leaq	0xcc(%r15), %rdi
     fa0:      	leaq	0x21c(%r12), %rdx
     fa8:      	movl	$0x4, %eax
     fad:      	movl	$0x4, %esi
     fb2:      	callq	*%rax
     fb4:      	leaq	0xd0(%r15), %rdi
     fbb:      	leaq	0x218(%r12), %rdx
     fc3:      	movl	$0x4, %eax
     fc8:      	movl	$0x4, %esi
     fcd:      	callq	*%rax
     fcf:      	leaq	0xac(%r15), %r14
     fd6:      	movq	0x8(%rsp), %rax
     fdb:      	movq	$0x0, (%rax)
     fe2:      	movq	$0x0, 0x8(%rax)
     fea:      	movq	$0x0, 0x10(%rax)
     ff2:      	movq	%rax, %rdi
     ff5:      	movq	$0x0, 0x18(%rax)
     ffd:      	movzwl	0xc2(%r15), %eax
    1005:      	cmpl	$0xa, %eax
    1008:      	je	0x208f <generic_retkprobe_event+0x208f>
    100e:      	cmpl	$0x2, %eax
    1011:      	jne	0x20be <generic_retkprobe_event+0x20be>
    1017:      	leaq	0x4(%r12), %rdx
    101c:      	movl	$0x4, %ecx
    1021:      	movl	$0x4, %eax
    1026:      	movl	$0x4, %esi
    102b:      	callq	*%rax
    102d:      	movl	$0x4, %ecx
    1032:      	movl	$0x4, %eax
    1037:      	movq	%r14, %rdi
    103a:      	movl	$0x4, %esi
    103f:      	movq	%r12, %rdx
    1042:      	jmp	0x20bc <generic_retkprobe_event+0x20bc>
    1047:      	cmpl	$0x1a, %ebx
    104a:      	je	0x1d21 <generic_retkprobe_event+0x1d21>
    1050:      	cmpl	$0x1b, %ebx
    1053:      	jne	0x1164 <generic_retkprobe_event+0x1164>
    1059:      	movq	0x8(%rsp), %rax
    105e:      	movq	$0x0, 0x48(%rax)
    1066:      	movq	$0x0, 0x40(%rax)
    106e:      	movq	$0x0, 0x38(%rax)
    1076:      	movq	$0x0, 0x30(%rax)
    107e:      	movq	$0x0, 0x28(%rax)
    1086:      	movq	$0x0, 0x20(%rax)
    108e:      	movq	$0x0, 0x18(%rax)
    1096:      	movq	$0x0, 0x10(%rax)
    109e:      	movq	$0x0, 0x8(%rax)
    10a6:      	movq	$0x0, (%rax)
    10ad:      	leaq	0xac(%rcx), %rdi
    10b4:      	leaq	0x18(%rbp), %rdx
    10b8:      	movl	$0x3f, %ecx
    10bd:      	movl	$0x2d, %eax
    10c2:      	movl	$0x3f, %esi
    10c7:      	callq	*%rax
    10c9:      	testq	%rax, %rax
    10cc:      	js	0x1d9a <generic_retkprobe_event+0x1d9a>
    10d2:      	movq	(%rsp), %rbx
    10d6:      	movq	%rbx, %rdi
    10d9:      	addq	$0xa4, %rdi
    10e0:      	addq	$0x348, %rbp            # imm = 0x348
    10e7:      	movl	$0x8, %ecx
    10ec:      	movl	$0x4, %eax
    10f1:      	movl	$0x8, %esi
    10f6:      	movq	%rbp, %rdx
    10f9:      	callq	*%rax
    10fb:      	movq	%rbx, %rcx
    10fe:      	movl	$0x50, %r13d
    1104:      	jmp	0x1164 <generic_retkprobe_event+0x1164>
    1106:      	cmpl	$0x26, %ebx
    1109:      	movq	(%rsp), %rcx
    110d:      	jne	0x1164 <generic_retkprobe_event+0x1164>
    110f:      	movq	0x18(%rsp), %rsi
    1114:      	movzwl	%si, %edx
    1117:      	addq	0xb8(%rsp), %rdx
    111f:      	shrl	$0x10, %esi
    1122:      	andl	$0xfff, %esi            # imm = 0xFFF
    1128:      	movq	%rcx, %rdi
    112b:      	addq	$0xa0, %rdi
    1132:      	incl	%esi
    1134:      	movl	$0x2d, %eax
    1139:      	jmp	0x16f3 <generic_retkprobe_event+0x16f3>
    113e:      	cmpl	$0x8, %ebx
    1141:      	je	0x1879 <generic_retkprobe_event+0x1879>
    1147:      	cmpl	$0x12, %ebx
    114a:      	jne	0x1164 <generic_retkprobe_event+0x1164>
    114c:      	xorl	%r13d, %r13d
    114f:      	movl	$0x4, %eax
    1154:      	movq	0x8(%rsp), %rdi
    1159:      	xorl	%esi, %esi
    115b:      	movq	%rbp, %rdx
    115e:      	callq	*%rax
    1160:      	movq	(%rsp), %rcx
    1164:      	movl	0x20(%rsp), %ebp
    1168:      	testl	%r13d, %r13d
    116b:      	movl	$0x4, %ebx
    1170:      	js	0x1182 <generic_retkprobe_event+0x1182>
    1172:      	andl	$0x7fffffff, %r13d      # imm = 0x7FFFFFFF
    1179:      	addq	$0x4, %r13
    117d:      	movq	%r13, %rbx
    1180:      	jmp	0x1196 <generic_retkprobe_event+0x1196>
    1182:      	movl	$0xffffffff, 0x5ea0(%rcx) # imm = 0xFFFFFFFF
    118c:      	movl	$0xffffffff, 0x98(%rcx) # imm = 0xFFFFFFFF
    1196:      	movq	0xb8(%rsp), %r13
    119e:      	addq	$0x8, %rbx
    11a2:      	movl	0x60(%r14), %eax
    11a6:      	cmpl	$0xb, %eax
    11a9:      	jne	0x2ad <generic_retkprobe_event+0x2ad>
    11af:      	movq	(%rip), %rdi            # 0x11b6 <generic_retkprobe_event+0x11b6>
    11b6:      	leaq	0xc0(%rsp), %rsi
    11be:      	movl	$0x3, %eax
    11c3:      	callq	*%rax
    11c5:      	andl	$0x1fff, %ebx           # imm = 0x1FFF
    11cb:      	addq	$0x90, %r15
    11d2:      	cmpl	$0x3, %ebp
    11d5:      	je	0x1b4 <generic_retkprobe_event+0x1b4>
    11db:      	cmpl	$0x2, %ebp
    11de:      	jne	0x2c46 <generic_retkprobe_event+0x2c46>
    11e4:      	movq	%r14, 0x78(%rsp)
    11e9:      	movq	%r12, 0x80(%rsp)
    11f1:      	movl	$0x0, (%r15,%rbx)
    11f9:      	movq	0xc0(%rsp), %rbp
    1201:      	cmpq	$0xfff, %rbp            # imm = 0xFFF
    1208:      	movl	$0xfff, %r14d           # imm = 0xFFF
    120e:      	cmovbq	%rbp, %r14
    1212:      	leaq	(%r15,%rbx), %rdi
    1216:      	addq	$0xc, %rdi
    121a:      	movl	$0x4, %eax
    121f:      	movq	0x88(%rsp), %rdx
    1227:      	movq	%r15, %rcx
    122a:      	leaq	0x4(%rbx), %r15
    122e:      	leaq	(%rcx,%rbx), %r12
    1232:      	addq	$0x4, %r12
    1236:      	movl	$0x4, %ebx
    123b:      	movl	%r14d, %esi
    123e:      	callq	*%rax
    1240:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    1245:      	testl	%eax, %eax
    1247:      	js	0x1257 <generic_retkprobe_event+0x1257>
    1249:      	movl	%r14d, 0x4(%r12)
    124e:      	addq	$0x8, %r14
    1252:      	movl	%ebp, %ecx
    1254:      	movq	%r14, %rbx
    1257:      	addq	%r15, %rbx
    125a:      	movl	%ecx, (%r12)
    125e:      	jmp	0x2c39 <generic_retkprobe_event+0x2c39>
    1263:      	cmpl	$0x13, %ebx
    1266:      	je	0x1c18 <generic_retkprobe_event+0x1c18>
    126c:      	cmpl	$0x14, %ebx
    126f:      	jne	0x1164 <generic_retkprobe_event+0x1164>
    1275:      	movq	$0x0, 0x28(%rsp)
    127e:      	leaq	0x110(%rbp), %rdx
    1285:      	leaq	0x28(%rsp), %rdi
    128a:      	movl	$0x8, %ecx
    128f:      	movl	$0x4, %eax
    1294:      	movq	%r14, %rbx
    1297:      	leaq	0xd8(%rbp), %r14
    129e:      	movl	$0x8, %esi
    12a3:      	callq	*%rax
    12a5:      	movq	0x28(%rsp), %rcx
    12aa:      	movl	$0x80, %edx
    12af:      	movl	$0x2d, %eax
    12b4:      	movq	0x8(%rsp), %rdi
    12b9:      	movq	0x28(%rsp), %rdx
    12be:      	movl	$0x80, %esi
    12c3:      	callq	*%rax
    12c5:      	movq	(%rsp), %rax
    12c9:      	leaq	0x12c(%rax), %rdi
    12d0:      	movl	$0x4, %ecx
    12d5:      	movl	$0x4, %eax
    12da:      	movl	$0x4, %esi
    12df:      	movq	%r14, %rdx
    12e2:      	movq	%rbx, %r14
    12e5:      	callq	*%rax
    12e7:      	movq	(%rsp), %rax
    12eb:      	leaq	0x11c(%rax), %rdi
    12f2:      	leaq	0xe0(%rbp), %rdx
    12f9:      	movl	$0x8, %ecx
    12fe:      	movl	$0x4, %eax
    1303:      	movl	$0x8, %esi
    1308:      	callq	*%rax
    130a:      	movq	(%rsp), %rdi
    130e:      	addq	$0x124, %rdi            # imm = 0x124
    1315:      	addq	$0x118, %rbp            # imm = 0x118
    131c:      	movl	$0x8, %ecx
    1321:      	movl	$0x4, %eax
    1326:      	movl	$0x8, %esi
    132b:      	movq	%rbp, %rdx
    132e:      	callq	*%rax
    1330:      	movq	(%rsp), %rcx
    1334:      	movl	$0x98, %r13d
    133a:      	jmp	0x1164 <generic_retkprobe_event+0x1164>
    133f:      	movq	%r15, %rbp
    1342:      	movq	%r14, %r15
    1345:      	movq	%rax, %rbx
    1348:      	movq	0x18(%rsp), %r14
    134d:      	leaq	0xb0(%rsp), %rdi
    1355:      	movl	$0x1, %ecx
    135a:      	movl	$0x4, %eax
    135f:      	movl	$0x1, %esi
    1364:      	movq	%r14, %rdx
    1367:      	callq	*%rax
    1369:      	cmpb	$0x1, 0xb0(%rsp)
    1371:      	jne	0x1da2 <generic_retkprobe_event+0x1da2>
    1377:      	addq	$0x10, %r14
    137b:      	leaq	0x28(%rsp), %rdi
    1380:      	movl	$0x8, %ecx
    1385:      	movl	$0x4, %eax
    138a:      	movl	$0x8, %esi
    138f:      	movq	%r14, %rdx
    1392:      	callq	*%rax
    1394:      	movq	0x28(%rsp), %rdx
    1399:      	leaq	0x68(%rsp), %rdi
    139e:      	movl	$0x8, %ecx
    13a3:      	movl	$0x4, %eax
    13a8:      	movl	$0x8, %esi
    13ad:      	callq	*%rax
    13af:      	movq	0x28(%rsp), %rdx
    13b4:      	addq	$0x8, %rdx
    13b8:      	leaq	0x90(%rsp), %rdi
    13c0:      	movl	$0x8, %ecx
    13c5:      	movl	$0x4, %eax
    13ca:      	movl	$0x8, %esi
    13cf:      	callq	*%rax
    13d1:      	movq	0x68(%rsp), %rdx
    13d6:      	movq	0x90(%rsp), %r14
    13de:      	cmpq	$0xfff, %r14            # imm = 0xFFF
    13e5:      	movl	$0xfff, %r13d           # imm = 0xFFF
    13eb:      	cmovbq	%r14, %r13
    13ef:      	movq	%rbx, %rdi
    13f2:      	addq	$0xa4, %rdi
    13f9:      	movl	$0x4, %eax
    13fe:      	movl	%r13d, %esi
    1401:      	callq	*%rax
    1403:      	testl	%eax, %eax
    1405:      	js	0x1f56 <generic_retkprobe_event+0x1f56>
    140b:      	movl	%r14d, 0x9c(%rbx)
    1412:      	movl	%r13d, 0xa0(%rbx)
    1419:      	addq	$0x8, %r13
    141d:      	movq	(%rsp), %rcx
    1421:      	jmp	0x1fd0 <generic_retkprobe_event+0x1fd0>
    1426:      	movq	%r12, 0x80(%rsp)
    142e:      	movq	0x18(%rsp), %rbp
    1433:      	leaq	0xc4(%rcx), %rdi
    143a:      	leaq	0x98(%rbp), %rdx
    1441:      	movl	$0x4, %esi
    1446:      	movq	%rcx, %rbx
    1449:      	movl	$0x4, %eax
    144e:      	movl	$0x4, %esi
    1453:      	callq	*%rax
    1455:      	leaq	0xc8(%rbx), %rdi
    145c:      	leaq	0x70(%rbp), %rdx
    1460:      	movl	$0x4, %ecx
    1465:      	movl	$0x4, %eax
    146a:      	movl	$0x4, %esi
    146f:      	callq	*%rax
    1471:      	leaq	0xcc(%rbx), %rdi
    1478:      	leaq	0x90(%rbp), %rdx
    147f:      	movl	$0x4, %ecx
    1484:      	movl	$0x4, %eax
    1489:      	movl	$0x4, %esi
    148e:      	callq	*%rax
    1490:      	leaq	0xd0(%rbx), %rdi
    1497:      	leaq	0xa8(%rbp), %rdx
    149e:      	movl	$0x4, %ecx
    14a3:      	movl	$0x4, %eax
    14a8:      	movl	$0x4, %esi
    14ad:      	callq	*%rax
    14af:      	movq	$0x0, 0x28(%rsp)
    14b8:      	leaq	0xc8(%rbp), %rdx
    14bf:      	leaq	0x28(%rsp), %rdi
    14c4:      	movl	$0x8, %ecx
    14c9:      	movl	$0x4, %eax
    14ce:      	movl	$0x8, %esi
    14d3:      	callq	*%rax
    14d5:      	leaq	0xb8(%rbp), %rdx
    14dc:      	leaq	0xb0(%rsp), %rdi
    14e4:      	movl	$0x2, %ecx
    14e9:      	movl	$0x4, %eax
    14ee:      	movl	$0x2, %esi
    14f3:      	callq	*%rax
    14f5:      	movzwl	0xb0(%rsp), %r12d
    14fe:      	addq	0x28(%rsp), %r12
    1503:      	leaq	0xac(%rsp), %rdi
    150b:      	movl	$0x1, %ecx
    1510:      	movl	$0x4, %eax
    1515:      	movl	$0x1, %esi
    151a:      	movq	%r12, %rdx
    151d:      	callq	*%rax
    151f:      	movzbl	0xac(%rsp), %eax
    1527:      	shrl	$0x4, %eax
    152a:      	cmpl	$0x6, %eax
    152d:      	je	0x1dd4 <generic_retkprobe_event+0x1dd4>
    1533:      	cmpl	$0x4, %eax
    1536:      	jne	0x2aa2 <generic_retkprobe_event+0x2aa2>
    153c:      	movq	%r15, 0x10(%rsp)
    1541:      	movq	%r14, %r13
    1544:      	leaq	0x9(%r12), %rdx
    1549:      	leaq	0xc8(%rsp), %rdi
    1551:      	movl	$0x1, %ecx
    1556:      	movl	$0x4, %eax
    155b:      	movl	$0x1, %esi
    1560:      	callq	*%rax
    1562:      	movzbl	0xc8(%rsp), %eax
    156a:      	movq	(%rsp), %rcx
    156e:      	movw	%ax, 0xc0(%rcx)
    1575:      	movw	$0x2, 0xc2(%rcx)
    157e:      	leaq	0xc(%r12), %rdx
    1583:      	movq	0x8(%rsp), %rdi
    1588:      	movq	$0x0, (%rdi)
    158f:      	movq	$0x0, 0x8(%rdi)
    1597:      	movq	$0x0, 0x10(%rdi)
    159f:      	movq	$0x0, 0x18(%rdi)
    15a7:      	movl	$0x4, %esi
    15ac:      	movl	$0x4, %eax
    15b1:      	leaq	0xac(%rcx), %rbx
    15b8:      	movl	$0x4, %esi
    15bd:      	callq	*%rax
    15bf:      	addq	$0x10, %r12
    15c3:      	movl	$0x4, %ecx
    15c8:      	movl	$0x4, %eax
    15cd:      	movq	%rbx, %rdi
    15d0:      	movl	$0x4, %esi
    15d5:      	movq	%r12, %rdx
    15d8:      	callq	*%rax
    15da:      	leaq	0xb6(%rbp), %rdx
    15e1:      	leaq	0xd0(%rsp), %rdi
    15e9:      	movl	$0x2, %ecx
    15ee:      	movl	$0x4, %eax
    15f3:      	movl	$0x2, %esi
    15f8:      	jmp	0x2917 <generic_retkprobe_event+0x2917>
    15fd:      	movq	%r15, 0x10(%rsp)
    1602:      	movq	%r14, %r15
    1605:      	movq	$0x0, 0x30(%rsp)
    160e:      	movq	$0x0, 0x28(%rsp)
    1617:      	movl	$0xe, %eax
    161c:      	callq	*%rax
    161e:      	shrq	$0x20, %rax
    1622:      	movq	%rax, 0x28(%rsp)
    1627:      	leaq	0x68(%rsp), %rdi
    162c:      	leaq	0x18(%rsp), %rdx
    1631:      	movl	$0x4, %ecx
    1636:      	movl	$0x4, %eax
    163b:      	movl	$0x4, %esi
    1640:      	callq	*%rax
    1642:      	movl	0x68(%rsp), %eax
    1646:      	movl	%eax, 0x30(%rsp)
    164a:      	movq	(%rip), %rdi            # 0x1651 <generic_retkprobe_event+0x1651>
    1651:      	leaq	0x28(%rsp), %rsi
    1656:      	movl	$0x1, %eax
    165b:      	callq	*%rax
    165d:      	testq	%rax, %rax
    1660:      	je	0x1dbc <generic_retkprobe_event+0x1dbc>
    1666:      	movl	(%rax), %r13d
    1669:      	leaq	0x68(%rsp), %rdx
    166e:      	movq	%rax, %r14
    1671:      	movl	$0x4, %eax
    1676:      	movq	0x8(%rsp), %rbx
    167b:      	movl	$0x4, %ebp
    1680:      	movq	%rbx, %rdi
    1683:      	movl	$0x4, %esi
    1688:      	callq	*%rax
    168a:      	andl	$0xfff, %r13d           # imm = 0xFFF
    1691:      	movq	(%rsp), %rdi
    1695:      	addq	$0xa0, %rdi
    169c:      	leaq	0x4(%r13), %rsi
    16a0:      	movl	$0x4, %eax
    16a5:      	movq	%r14, %rdx
    16a8:      	callq	*%rax
    16aa:      	leaq	(%rbx,%r13), %rdi
    16ae:      	addq	$0x8, %rdi
    16b2:      	leaq	(%r14,%r13), %rdx
    16b6:      	addq	$0x4, %rdx
    16ba:      	movl	$0x4, %eax
    16bf:      	movl	$0x4, %esi
    16c4:      	callq	*%rax
    16c6:      	addq	$0xc, %r13
    16ca:      	jmp	0x1dc3 <generic_retkprobe_event+0x1dc3>
    16cf:      	movl	$0x120, %edx            # imm = 0x120
    16d4:      	addq	0x18(%rsp), %rdx
    16d9:      	movq	(%rsp), %rdi
    16dd:      	addq	$0xa0, %rdi
    16e4:      	movl	$0x11, %ecx
    16e9:      	movl	$0x2d, %eax
    16ee:      	movl	$0x11, %esi
    16f3:      	callq	*%rax
    16f5:      	movq	%rax, %r13
    16f8:      	testq	%rax, %rax
    16fb:      	js	0x1160 <generic_retkprobe_event+0x1160>
    1701:      	leal	-0x1(%r13), %eax
    1705:      	movq	0x8(%rsp), %rcx
    170a:      	movl	%eax, (%rcx)
    170c:      	addq	$0x3, %r13
    1710:      	jmp	0x1160 <generic_retkprobe_event+0x1160>
    1715:      	xorl	%r14d, %r14d
    1718:      	cmpq	$0x3, 0xa0(%rsp)
    1721:      	jb	0xb79 <generic_retkprobe_event+0xb79>
    1727:      	movq	%r15, %r12
    172a:      	movq	0x88(%rsp), %rax
    1732:      	leaq	0x20(%rax), %rdx
    1736:      	leaq	0x28(%rsp), %rdi
    173b:      	movl	$0x4, %ebp
    1740:      	movl	$0x10, %ecx
    1745:      	movl	$0x4, %eax
    174a:      	movl	$0x10, %esi
    174f:      	callq	*%rax
    1751:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    1756:      	testl	%eax, %eax
    1758:      	js	0x2c23 <generic_retkprobe_event+0x2c23>
    175e:      	movq	0x30(%rsp), %r15
    1763:      	cmpq	%r14, %r15
    1766:      	movq	%r14, %rax
    1769:      	cmovbq	%r15, %rax
    176d:      	testq	%r14, %r14
    1770:      	movq	%rax, (%rsp)
    1774:      	cmovneq	%rax, %r15
    1778:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    177d:      	cmpq	$0xffe, %r15            # imm = 0xFFE
    1784:      	ja	0x2c23 <generic_retkprobe_event+0x2c23>
    178a:      	movq	%r12, %rdi
    178d:      	addq	0x20(%rsp), %rdi
    1792:      	movq	%rdi, %r12
    1795:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    179b:      	addq	0x10(%rsp), %rdi
    17a0:      	movq	0x28(%rsp), %rcx
    17a5:      	movl	$0x4, %eax
    17aa:      	movq	0x28(%rsp), %rdx
    17af:      	movl	%r15d, %esi
    17b2:      	callq	*%rax
    17b4:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    17b9:      	testl	%eax, %eax
    17bb:      	js	0x2c23 <generic_retkprobe_event+0x2c23>
    17c1:      	movq	%r15, 0x20(%rsp)
    17c6:      	addq	%r15, %r13
    17c9:      	testq	%r14, %r14
    17cc:      	je	0x21b0 <generic_retkprobe_event+0x21b0>
    17d2:      	subq	(%rsp), %r14
    17d6:      	jne	0x21b3 <generic_retkprobe_event+0x21b3>
    17dc:      	jmp	0xb79 <generic_retkprobe_event+0xb79>
    17e1:      	movq	%r15, 0x10(%rsp)
    17e6:      	movq	%r12, 0x80(%rsp)
    17ee:      	movq	$0x0, 0x68(%rsp)
    17f7:      	movq	$0x0, 0x28(%rsp)
    1800:      	leaq	0x68(%rsp), %rdi
    1805:      	leaq	0x28(%rsp), %rdx
    180a:      	movl	$0x8, %ecx
    180f:      	movq	%rax, %r12
    1812:      	movl	$0x4, %eax
    1817:      	movl	$0x4, %r13d
    181d:      	movl	$0x8, %esi
    1822:      	callq	*%rax
    1824:      	movq	0x68(%rsp), %r15
    1829:      	cmpq	$0xfff, %r15            # imm = 0xFFF
    1830:      	movl	$0xfff, %r14d           # imm = 0xFFF
    1836:      	cmovbq	%r15, %r14
    183a:      	movq	%r12, %rbx
    183d:      	movq	%r12, %rdi
    1840:      	addq	$0xa4, %rdi
    1847:      	movl	$0x4, %eax
    184c:      	movl	%r14d, %esi
    184f:      	movq	%rbp, %rdx
    1852:      	callq	*%rax
    1854:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    1859:      	testl	%eax, %eax
    185b:      	js	0x186e <generic_retkprobe_event+0x186e>
    185d:      	movl	%r14d, 0xa0(%rbx)
    1864:      	addq	$0x8, %r14
    1868:      	movl	%r15d, %ecx
    186b:      	movq	%r14, %r13
    186e:      	movl	%ecx, 0x9c(%rbx)
    1874:      	jmp	0x2159 <generic_retkprobe_event+0x2159>
    1879:      	leaq	0xc4(%rcx), %r13
    1880:      	movq	%r12, %rbx
    1883:      	leaq	0xdc(%rcx), %r12
    188a:      	leaq	0x8(%rbp), %rdx
    188e:      	movl	$0x4, %ecx
    1893:      	movl	$0x4, %eax
    1898:      	movq	0x8(%rsp), %rdi
    189d:      	movl	$0x4, %esi
    18a2:      	callq	*%rax
    18a4:      	movq	(%rsp), %rax
    18a8:      	leaq	0xa0(%rax), %rdi
    18af:      	leaq	0xc(%rbp), %rdx
    18b3:      	movl	$0x4, %ecx
    18b8:      	movl	$0x4, %eax
    18bd:      	movl	$0x4, %esi
    18c2:      	callq	*%rax
    18c4:      	movq	(%rsp), %rax
    18c8:      	leaq	0xac(%rax), %rdi
    18cf:      	leaq	0x18(%rbp), %rdx
    18d3:      	movl	$0x4, %ecx
    18d8:      	movl	$0x4, %eax
    18dd:      	movl	$0x4, %esi
    18e2:      	callq	*%rax
    18e4:      	movq	(%rsp), %rax
    18e8:      	leaq	0xb0(%rax), %rdi
    18ef:      	leaq	0x1c(%rbp), %rdx
    18f3:      	movl	$0x4, %ecx
    18f8:      	movl	$0x4, %eax
    18fd:      	movl	$0x4, %esi
    1902:      	callq	*%rax
    1904:      	movq	(%rsp), %rax
    1908:      	leaq	0xa4(%rax), %rdi
    190f:      	leaq	0x10(%rbp), %rdx
    1913:      	movl	$0x4, %ecx
    1918:      	movl	$0x4, %eax
    191d:      	movl	$0x4, %esi
    1922:      	callq	*%rax
    1924:      	movq	(%rsp), %rax
    1928:      	leaq	0xa8(%rax), %rdi
    192f:      	leaq	0x14(%rbp), %rdx
    1933:      	movl	$0x4, %ecx
    1938:      	movl	$0x4, %eax
    193d:      	movl	$0x4, %esi
    1942:      	callq	*%rax
    1944:      	movq	(%rsp), %rax
    1948:      	leaq	0xb4(%rax), %rdi
    194f:      	leaq	0x20(%rbp), %rdx
    1953:      	movl	$0x4, %ecx
    1958:      	movl	$0x4, %eax
    195d:      	movl	$0x4, %esi
    1962:      	callq	*%rax
    1964:      	movq	(%rsp), %rax
    1968:      	leaq	0xb8(%rax), %rdi
    196f:      	leaq	0x24(%rbp), %rdx
    1973:      	movl	$0x4, %ecx
    1978:      	movl	$0x4, %eax
    197d:      	movl	$0x4, %esi
    1982:      	callq	*%rax
    1984:      	movq	(%rsp), %rax
    1988:      	movl	$0x0, 0xc0(%rax)
    1992:      	movq	(%rsp), %rax
    1996:      	leaq	0xbc(%rax), %rdi
    199d:      	leaq	0x28(%rbp), %rdx
    19a1:      	movl	$0x4, %ecx
    19a6:      	movl	$0x4, %eax
    19ab:      	movl	$0x4, %esi
    19b0:      	callq	*%rax
    19b2:      	movq	(%rsp), %rax
    19b6:      	leaq	0xcc(%rax), %rdi
    19bd:      	leaq	0x40(%rbp), %rdx
    19c1:      	movl	$0x8, %ecx
    19c6:      	movl	$0x4, %eax
    19cb:      	movl	$0x8, %esi
    19d0:      	callq	*%rax
    19d2:      	movq	(%rsp), %rax
    19d6:      	leaq	0xd4(%rax), %rdi
    19dd:      	leaq	0x30(%rbp), %rdx
    19e1:      	movl	$0x8, %ecx
    19e6:      	movl	$0x4, %eax
    19eb:      	movl	$0x8, %esi
    19f0:      	callq	*%rax
    19f2:      	leaq	0x38(%rbp), %rdx
    19f6:      	movl	$0x8, %ecx
    19fb:      	movl	$0x4, %eax
    1a00:      	movq	%r13, %rdi
    1a03:      	movl	$0x8, %esi
    1a08:      	callq	*%rax
    1a0a:      	addq	$0x90, %rbp
    1a11:      	leaq	0x28(%rsp), %rdi
    1a16:      	movl	$0x8, %ecx
    1a1b:      	movl	$0x4, %eax
    1a20:      	movl	$0x8, %esi
    1a25:      	movq	%rbp, %rdx
    1a28:      	callq	*%rax
    1a2a:      	movq	%r15, %r13
    1a2d:      	movq	%r14, %r15
    1a30:      	movq	0x28(%rsp), %r14
    1a35:      	leaq	0xc8(%r14), %rdx
    1a3c:      	movl	$0x4, %ecx
    1a41:      	movl	$0x4, %eax
    1a46:      	movq	%r12, %rdi
    1a49:      	movq	%rbx, %r12
    1a4c:      	movl	$0x4, %esi
    1a51:      	callq	*%rax
    1a53:      	movq	(%rsp), %rax
    1a57:      	leaq	0xe0(%rax), %rdi
    1a5e:      	leaq	0xcc(%r14), %rdx
    1a65:      	movl	$0x4, %ecx
    1a6a:      	movl	$0x4, %eax
    1a6f:      	movl	$0x4, %esi
    1a74:      	callq	*%rax
    1a76:      	movq	(%rsp), %rax
    1a7a:      	leaq	0xe4(%rax), %rdi
    1a81:      	leaq	0xd0(%r14), %rdx
    1a88:      	movl	$0x4, %ecx
    1a8d:      	movl	$0x4, %eax
    1a92:      	movl	$0x4, %esi
    1a97:      	callq	*%rax
    1a99:      	movq	(%rsp), %rdi
    1a9d:      	addq	$0xe8, %rdi
    1aa4:      	addq	$0x158, %r14            # imm = 0x158
    1aab:      	movl	$0x4, %ecx
    1ab0:      	movl	$0x4, %eax
    1ab5:      	movl	$0x4, %esi
    1aba:      	movq	%r14, %rdx
    1abd:      	movq	%r15, %r14
    1ac0:      	movq	%r13, %r15
    1ac3:      	callq	*%rax
    1ac5:      	movq	(%rsp), %rcx
    1ac9:      	movl	$0x50, %r13d
    1acf:      	jmp	0x1164 <generic_retkprobe_event+0x1164>
    1ad4:      	leaq	0xc8(%rbp), %rdx
    1adb:      	movl	$0x4, %ecx
    1ae0:      	movl	$0x4, %eax
    1ae5:      	movq	0x8(%rsp), %rdi
    1aea:      	movl	$0x4, %esi
    1aef:      	callq	*%rax
    1af1:      	movq	(%rsp), %rax
    1af5:      	leaq	0xa0(%rax), %rdi
    1afc:      	leaq	0xcc(%rbp), %rdx
    1b03:      	movl	$0x4, %ecx
    1b08:      	movl	$0x4, %eax
    1b0d:      	movl	$0x4, %esi
    1b12:      	callq	*%rax
    1b14:      	movq	(%rsp), %rax
    1b18:      	leaq	0xa4(%rax), %rdi
    1b1f:      	leaq	0xd0(%rbp), %rdx
    1b26:      	movl	$0x4, %ecx
    1b2b:      	movl	$0x4, %eax
    1b30:      	movl	$0x4, %esi
    1b35:      	callq	*%rax
    1b37:      	movq	(%rsp), %rdi
    1b3b:      	addq	$0xa8, %rdi
    1b42:      	addq	$0x158, %rbp            # imm = 0x158
    1b49:      	movl	$0x4, %ecx
    1b4e:      	movl	$0x4, %eax
    1b53:      	movl	$0x4, %esi
    1b58:      	movq	%rbp, %rdx
    1b5b:      	callq	*%rax
    1b5d:      	movq	(%rsp), %rcx
    1b61:      	movl	$0x10, %r13d
    1b67:      	jmp	0x1164 <generic_retkprobe_event+0x1164>
    1b6c:      	leaq	0x38(%rbp), %rdx
    1b70:      	movl	$0x4, %ecx
    1b75:      	movl	$0x4, %eax
    1b7a:      	movq	0x8(%rsp), %rdi
    1b7f:      	movl	$0x4, %esi
    1b84:      	callq	*%rax
    1b86:      	movq	(%rsp), %rax
    1b8a:      	leaq	0xa0(%rax), %rdi
    1b91:      	leaq	0x3c(%rbp), %rdx
    1b95:      	movl	$0x4, %ecx
    1b9a:      	movl	$0x4, %eax
    1b9f:      	movl	$0x4, %esi
    1ba4:      	callq	*%rax
    1ba6:      	movq	(%rsp), %rax
    1baa:      	leaq	0xa4(%rax), %rdi
    1bb1:      	leaq	0x40(%rbp), %rdx
    1bb5:      	movl	$0x4, %ecx
    1bba:      	movl	$0x4, %eax
    1bbf:      	movl	$0x4, %esi
    1bc4:      	callq	*%rax
    1bc6:      	movq	(%rsp), %rax
    1bca:      	leaq	0xa8(%rax), %rdi
    1bd1:      	leaq	0x44(%rbp), %rdx
    1bd5:      	movl	$0x4, %ecx
    1bda:      	movl	$0x4, %eax
    1bdf:      	movl	$0x4, %esi
    1be4:      	callq	*%rax
    1be6:      	movq	(%rsp), %rdi
    1bea:      	addq	$0xac, %rdi
    1bf1:      	subq	$-0x80, %rbp
    1bf5:      	movl	$0x10, %ecx
    1bfa:      	movl	$0x4, %eax
    1bff:      	movl	$0x10, %esi
    1c04:      	movq	%rbp, %rdx
    1c07:      	callq	*%rax
    1c09:      	movq	(%rsp), %rcx
    1c0d:      	movl	$0x20, %r13d
    1c13:      	jmp	0x1164 <generic_retkprobe_event+0x1164>
    1c18:      	movl	$0x4, %ecx
    1c1d:      	movl	$0x4, %eax
    1c22:      	movq	0x8(%rsp), %rdi
    1c27:      	movl	$0x4, %esi
    1c2c:      	movq	%rbp, %rdx
    1c2f:      	callq	*%rax
    1c31:      	movq	(%rsp), %rax
    1c35:      	leaq	0xa0(%rax), %rdi
    1c3c:      	leaq	0x4(%rbp), %rdx
    1c40:      	movl	$0x4, %ecx
    1c45:      	movl	$0x4, %eax
    1c4a:      	movl	$0x4, %esi
    1c4f:      	callq	*%rax
    1c51:      	movq	(%rsp), %rdi
    1c55:      	addq	$0xa4, %rdi
    1c5c:      	addq	$0x30, %rbp
    1c60:      	movl	$0x10, %ecx
    1c65:      	movl	$0x4, %eax
    1c6a:      	movl	$0x10, %esi
    1c6f:      	movq	%rbp, %rdx
    1c72:      	jmp	0x1d10 <generic_retkprobe_event+0x1d10>
    1c77:      	leaq	0x4(%rbp), %rdx
    1c7b:      	leaq	0x28(%rsp), %rdi
    1c80:      	movl	$0x4, %ecx
    1c85:      	movl	$0x4, %eax
    1c8a:      	movl	$0x4, %esi
    1c8f:      	callq	*%rax
    1c91:      	movl	0x28(%rsp), %ecx
    1c95:      	movq	(%rsp), %rax
    1c99:      	movl	%ecx, 0x9c(%rax)
    1c9f:      	leaq	0xc(%rbp), %rdx
    1ca3:      	leaq	0x28(%rsp), %rdi
    1ca8:      	movl	$0x4, %ecx
    1cad:      	movl	$0x4, %eax
    1cb2:      	movl	$0x4, %esi
    1cb7:      	callq	*%rax
    1cb9:      	movl	0x28(%rsp), %ecx
    1cbd:      	movq	(%rsp), %rax
    1cc1:      	movl	%ecx, 0xa0(%rax)
    1cc7:      	addq	$0x50, %rbp
    1ccb:      	leaq	0x28(%rsp), %rdi
    1cd0:      	movl	$0x8, %ecx
    1cd5:      	movl	$0x2d, %eax
    1cda:      	movl	$0x8, %esi
    1cdf:      	movq	%rbp, %rdx
    1ce2:      	callq	*%rax
    1ce4:      	movq	(%rsp), %rdi
    1ce8:      	addq	$0xa4, %rdi
    1cef:      	movl	$0x3f8, %edx            # imm = 0x3F8
    1cf4:      	movq	0x28(%rsp), %rcx
    1cf9:      	addq	%rdx, %rcx
    1cfc:      	movl	$0x10, %esi
    1d01:      	movl	$0x2d, %eax
    1d06:      	addq	0x28(%rsp), %rdx
    1d0b:      	movl	$0x10, %esi
    1d10:      	callq	*%rax
    1d12:      	movq	(%rsp), %rcx
    1d16:      	movl	$0x18, %r13d
    1d1c:      	jmp	0x1164 <generic_retkprobe_event+0x1164>
    1d21:      	movq	0x8(%rsp), %rax
    1d26:      	movq	$0x0, 0x48(%rax)
    1d2e:      	movq	$0x0, 0x40(%rax)
    1d36:      	movq	$0x0, 0x38(%rax)
    1d3e:      	movq	$0x0, 0x30(%rax)
    1d46:      	movq	$0x0, 0x28(%rax)
    1d4e:      	movq	$0x0, 0x20(%rax)
    1d56:      	movq	$0x0, 0x18(%rax)
    1d5e:      	movq	$0x0, 0x10(%rax)
    1d66:      	movq	$0x0, 0x8(%rax)
    1d6e:      	movq	%rax, %rbx
    1d71:      	movq	$0x0, (%rax)
    1d78:      	leaq	0x28(%rsp), %rdi
    1d7d:      	movl	$0x8, %ecx
    1d82:      	movl	$0x4, %eax
    1d87:      	movl	$0x8, %esi
    1d8c:      	movq	%rbp, %rdx
    1d8f:      	callq	*%rax
    1d91:      	testq	%rax, %rax
    1d94:      	je	0x1fdb <generic_retkprobe_event+0x1fdb>
    1d9a:      	xorl	%r13d, %r13d
    1d9d:      	jmp	0x1160 <generic_retkprobe_event+0x1160>
    1da2:      	movq	$0x0, 0x9c(%rbx)
    1dad:      	movl	$0x8, %r13d
    1db3:      	movq	(%rsp), %rcx
    1db7:      	jmp	0x1fd0 <generic_retkprobe_event+0x1fd0>
    1dbc:      	movq	$-0x1, %r13
    1dc3:      	movq	(%rsp), %rcx
    1dc7:      	movq	%r15, %r14
    1dca:      	movq	0x10(%rsp), %r15
    1dcf:      	jmp	0x1164 <generic_retkprobe_event+0x1164>
    1dd4:      	movq	%r15, 0x10(%rsp)
    1dd9:      	movq	%r14, %r13
    1ddc:      	movq	0x28(%rsp), %rbx
    1de1:      	movl	$0x0, 0x68(%rsp)
    1de9:      	movzwl	0xb0(%rsp), %r14d
    1df2:      	movq	(%rip), %rdi            # 0x1df9 <generic_retkprobe_event+0x1df9>
    1df9:      	leaq	0x68(%rsp), %rsi
    1dfe:      	movl	$0x1, %eax
    1e03:      	leaq	(%rbx,%r14), %r15
    1e07:      	callq	*%rax
    1e09:      	testq	%rax, %rax
    1e0c:      	je	0x28c0 <generic_retkprobe_event+0x28c0>
    1e12:      	movq	%rax, %r12
    1e15:      	movw	%r14w, (%rax)
    1e19:      	movb	$-0x1, 0x5(%rax)
    1e1d:      	movb	$0x0, 0x7(%rax)
    1e21:      	movq	%rax, %rdi
    1e24:      	addq	$0x6, %rdi
    1e28:      	leaq	0x6(%r15), %rdx
    1e2c:      	movl	$0x1, %ecx
    1e31:      	movl	$0x4, %eax
    1e36:      	movq	%rdi, %r14
    1e39:      	movl	$0x1, %esi
    1e3e:      	callq	*%rax
    1e40:      	testq	%rax, %rax
    1e43:      	js	0x28c0 <generic_retkprobe_event+0x28c0>
    1e49:      	movzbl	0x5(%r12), %eax
    1e4f:      	cmpl	$0x32, %eax
    1e52:      	jg	0x2174 <generic_retkprobe_event+0x2174>
    1e58:      	testl	%eax, %eax
    1e5a:      	je	0x219e <generic_retkprobe_event+0x219e>
    1e60:      	cmpl	$0x2b, %eax
    1e63:      	je	0x219e <generic_retkprobe_event+0x219e>
    1e69:      	cmpl	$0x2c, %eax
    1e6c:      	jne	0x2343 <generic_retkprobe_event+0x2343>
    1e72:      	movw	$0x8, 0x2(%r12)
    1e7a:      	movw	$0x8, %ax
    1e7e:      	jmp	0x228a <generic_retkprobe_event+0x228a>
    1e83:      	leaq	0x48(%r12), %rdx
    1e88:      	movl	$0x10, %ecx
    1e8d:      	movl	$0x4, %eax
    1e92:      	movq	0x8(%rsp), %rdi
    1e97:      	movl	$0x10, %esi
    1e9c:      	callq	*%rax
    1e9e:      	leaq	0x38(%r12), %rdx
    1ea3:      	movl	$0x10, %ecx
    1ea8:      	movl	$0x4, %eax
    1ead:      	movq	%r14, %rdi
    1eb0:      	movl	$0x10, %esi
    1eb5:      	callq	*%rax
    1eb7:      	movq	(%rsp), %r14
    1ebb:      	leaq	0xbc(%r14), %rdi
    1ec2:      	leaq	0xc(%r12), %rbx
    1ec7:      	addq	$0xe, %r12
    1ecb:      	movl	$0x2, %ecx
    1ed0:      	movl	$0x4, %eax
    1ed5:      	movl	$0x2, %esi
    1eda:      	movq	%r12, %rdx
    1edd:      	callq	*%rax
    1edf:      	movq	%r14, %rdi
    1ee2:      	addq	$0xbe, %rdi
    1ee9:      	movl	$0x2, %ecx
    1eee:      	movl	$0x4, %eax
    1ef3:      	movl	$0x2, %esi
    1ef8:      	movq	%rbx, %rdx
    1efb:      	callq	*%rax
    1efd:      	movzwl	0xbe(%r14), %eax
    1f05:      	movbew	%ax, 0xbe(%r14)
    1f0f:      	movq	0x18(%rsp), %rax
    1f14:      	movq	%rax, 0x28(%rsp)
    1f19:      	movq	(%rip), %rdi            # 0x1f20 <generic_retkprobe_event+0x1f20>
    1f20:      	leaq	0x28(%rsp), %rsi
    1f25:      	movl	$0x1, %eax
    1f2a:      	callq	*%rax
    1f2c:      	testq	%rax, %rax
    1f2f:      	je	0x1f44 <generic_retkprobe_event+0x1f44>
    1f31:      	movl	(%rax), %ecx
    1f33:      	movl	%ecx, 0x10(%rbp)
    1f36:      	movq	0x8(%rax), %rcx
    1f3a:      	movq	%rcx, 0x18(%rbp)
    1f3e:      	movl	0x4(%rax), %eax
    1f41:      	movl	%eax, 0x7c(%rbp)
    1f44:      	movl	$0x40, %r13d
    1f4a:      	movq	(%rsp), %rcx
    1f4e:      	movq	%r15, %r12
    1f51:      	jmp	0x2165 <generic_retkprobe_event+0x2165>
    1f56:      	movl	$0xfffffffe, 0x9c(%rbx) # imm = 0xFFFFFFFE
    1f60:      	movl	$0x4, %r13d
    1f66:      	movq	(%rsp), %rcx
    1f6a:      	jmp	0x1fd0 <generic_retkprobe_event+0x1fd0>
    1f6c:      	movq	(%rsp), %rbx
    1f70:      	leaq	0xa4(%rbx), %rdi
    1f77:      	leaq	0x8(%r12), %rdx
    1f7c:      	movl	$0x10, %ecx
    1f81:      	movl	$0x4, %eax
    1f86:      	movl	$0x10, %esi
    1f8b:      	callq	*%rax
    1f8d:      	movq	%rbx, %rdi
    1f90:      	addq	$0x9e, %rdi
    1f97:      	addq	$0x2, %r12
    1f9b:      	movl	$0x2, %ecx
    1fa0:      	movl	$0x4, %eax
    1fa5:      	movl	$0x2, %esi
    1faa:      	movq	%r12, %rdx
    1fad:      	callq	*%rax
    1faf:      	movq	(%rsp), %rax
    1fb3:      	movzwl	0x9e(%rax), %ecx
    1fba:      	movbew	%cx, 0x9e(%rax)
    1fc3:      	movl	$0x18, %r13d
    1fc9:      	movq	(%rsp), %rcx
    1fcd:      	movq	%r14, %r12
    1fd0:      	movq	%r15, %r14
    1fd3:      	movq	%rbp, %r15
    1fd6:      	jmp	0x1164 <generic_retkprobe_event+0x1164>
    1fdb:      	movq	(%rsp), %rax
    1fdf:      	leaq	0xac(%rax), %rdi
    1fe6:      	movq	0x28(%rsp), %rcx
    1feb:      	movl	$0x3f, %edx
    1ff0:      	movl	$0x2d, %eax
    1ff5:      	movq	0x28(%rsp), %rdx
    1ffa:      	movl	$0x3f, %esi
    1fff:      	callq	*%rax
    2001:      	testq	%rax, %rax
    2004:      	js	0x1d9a <generic_retkprobe_event+0x1d9a>
    200a:      	leaq	0x8(%rbp), %rdx
    200e:      	leaq	0x68(%rsp), %rdi
    2013:      	movl	$0x8, %ecx
    2018:      	movl	$0x4, %eax
    201d:      	movl	$0x8, %esi
    2022:      	callq	*%rax
    2024:      	movq	(%rsp), %rdi
    2028:      	addq	$0xa4, %rdi
    202f:      	movl	$0x348, %edx            # imm = 0x348
    2034:      	movq	0x68(%rsp), %rcx
    2039:      	addq	%rdx, %rcx
    203c:      	movl	$0x8, %esi
    2041:      	movl	$0x4, %eax
    2046:      	addq	0x68(%rsp), %rdx
    204b:      	movl	$0x8, %esi
    2050:      	callq	*%rax
    2052:      	addq	$0x58, %rbp
    2056:      	leaq	0x68(%rsp), %rdi
    205b:      	movl	$0x4, %ecx
    2060:      	movl	$0x4, %eax
    2065:      	movl	$0x4, %esi
    206a:      	movq	%rbp, %rdx
    206d:      	callq	*%rax
    206f:      	movl	$0x50, %r13d
    2075:      	testq	%rax, %rax
    2078:      	jne	0x1160 <generic_retkprobe_event+0x1160>
    207e:      	xorl	%eax, %eax
    2080:      	cmpl	$0x0, 0x68(%rsp)
    2085:      	setne	%al
    2088:      	movl	%eax, (%rbx)
    208a:      	jmp	0x1160 <generic_retkprobe_event+0x1160>
    208f:      	leaq	0x48(%r12), %rdx
    2094:      	movl	$0x10, %ecx
    2099:      	movl	$0x4, %eax
    209e:      	movl	$0x10, %esi
    20a3:      	callq	*%rax
    20a5:      	leaq	0x38(%r12), %rdx
    20aa:      	movl	$0x10, %ecx
    20af:      	movl	$0x4, %eax
    20b4:      	movq	%r14, %rdi
    20b7:      	movl	$0x10, %esi
    20bc:      	callq	*%rax
    20be:      	movq	(%rsp), %r14
    20c2:      	leaq	0xbc(%r14), %rdi
    20c9:      	leaq	0xc(%r12), %rbx
    20ce:      	addq	$0xe, %r12
    20d2:      	movl	$0x2, %ecx
    20d7:      	movl	$0x4, %eax
    20dc:      	movl	$0x2, %esi
    20e1:      	movq	%r12, %rdx
    20e4:      	callq	*%rax
    20e6:      	movq	%r14, %rdi
    20e9:      	addq	$0xbe, %rdi
    20f0:      	movl	$0x2, %ecx
    20f5:      	movl	$0x4, %eax
    20fa:      	movl	$0x2, %esi
    20ff:      	movq	%rbx, %rdx
    2102:      	callq	*%rax
    2104:      	movzwl	0xbe(%r14), %eax
    210c:      	movbew	%ax, 0xbe(%r14)
    2116:      	movq	(%rsp), %rax
    211a:      	movq	0xc4(%rax), %rax
    2121:      	movq	%rax, 0x28(%rsp)
    2126:      	movq	(%rip), %rdi            # 0x212d <generic_retkprobe_event+0x212d>
    212d:      	leaq	0x28(%rsp), %rsi
    2132:      	movl	$0x1, %eax
    2137:      	callq	*%rax
    2139:      	testq	%rax, %rax
    213c:      	je	0x2153 <generic_retkprobe_event+0x2153>
    213e:      	movl	(%rax), %ecx
    2140:      	movl	%ecx, 0x10(%r13)
    2144:      	movq	0x8(%rax), %rcx
    2148:      	movq	%rcx, 0x18(%r13)
    214c:      	movl	0x4(%rax), %eax
    214f:      	movl	%eax, 0x7c(%r13)
    2153:      	movl	$0x40, %r13d
    2159:      	movq	(%rsp), %rcx
    215d:      	movq	0x80(%rsp), %r12
    2165:      	movq	0x78(%rsp), %r14
    216a:      	movq	0x10(%rsp), %r15
    216f:      	jmp	0x1164 <generic_retkprobe_event+0x1164>
    2174:      	cmpl	$0x33, %eax
    2177:      	je	0x2277 <generic_retkprobe_event+0x2277>
    217d:      	cmpl	$0x3c, %eax
    2180:      	je	0x219e <generic_retkprobe_event+0x219e>
    2182:      	cmpl	$0xff, %eax
    2187:      	jne	0x2343 <generic_retkprobe_event+0x2343>
    218d:      	movw	$0x28, 0x2(%r12)
    2195:      	movw	$0x28, %ax
    2199:      	jmp	0x228a <generic_retkprobe_event+0x228a>
    219e:      	movzbl	0x7(%r12), %eax
    21a4:      	leal	0x8(,%rax,8), %eax
    21ab:      	jmp	0x2284 <generic_retkprobe_event+0x2284>
    21b0:      	xorl	%r14d, %r14d
    21b3:      	cmpq	$0x3, 0xa0(%rsp)
    21bc:      	je	0xb79 <generic_retkprobe_event+0xb79>
    21c2:      	movq	0x88(%rsp), %rax
    21ca:      	leaq	0x30(%rax), %rdx
    21ce:      	leaq	0x28(%rsp), %rdi
    21d3:      	movl	$0x4, %ebp
    21d8:      	movl	$0x10, %ecx
    21dd:      	movl	$0x4, %eax
    21e2:      	movl	$0x10, %esi
    21e7:      	callq	*%rax
    21e9:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    21ee:      	testl	%eax, %eax
    21f0:      	js	0x2c23 <generic_retkprobe_event+0x2c23>
    21f6:      	movq	0x30(%rsp), %rax
    21fb:      	cmpq	%r14, %rax
    21fe:      	movq	%r14, %rcx
    2201:      	cmovbq	%rax, %rcx
    2205:      	testq	%r14, %r14
    2208:      	movq	%rcx, %r15
    220b:      	cmovneq	%rcx, %rax
    220f:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2214:      	movq	%rax, (%rsp)
    2218:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    221e:      	ja	0x2c23 <generic_retkprobe_event+0x2c23>
    2224:      	movq	0x20(%rsp), %rdi
    2229:      	addq	%r12, %rdi
    222c:      	movq	%rdi, %r12
    222f:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2235:      	addq	0x10(%rsp), %rdi
    223a:      	movq	0x28(%rsp), %rcx
    223f:      	movl	$0x4, %eax
    2244:      	movq	(%rsp), %rsi
    2248:      	movq	0x28(%rsp), %rdx
    224d:      	callq	*%rax
    224f:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2254:      	testl	%eax, %eax
    2256:      	js	0x2c23 <generic_retkprobe_event+0x2c23>
    225c:      	addq	(%rsp), %r13
    2260:      	testq	%r14, %r14
    2263:      	je	0x25df <generic_retkprobe_event+0x25df>
    2269:      	subq	%r15, %r14
    226c:      	jne	0x25e2 <generic_retkprobe_event+0x25e2>
    2272:      	jmp	0xb79 <generic_retkprobe_event+0xb79>
    2277:      	movzbl	0x7(%r12), %eax
    227d:      	leal	0x8(,%rax,4), %eax
    2284:      	movw	%ax, 0x2(%r12)
    228a:      	addw	(%r12), %ax
    228f:      	movw	%ax, (%r12)
    2294:      	movzbl	0x6(%r12), %ecx
    229a:      	cmpq	$0x3c, %rcx
    229e:      	ja	0x2ab9 <generic_retkprobe_event+0x2ab9>
    22a4:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    22ae:      	btq	%rcx, %rdx
    22b2:      	jae	0x2ab9 <generic_retkprobe_event+0x2ab9>
    22b8:      	movb	%cl, 0x5(%r12)
    22bd:      	movzwl	%ax, %ecx
    22c0:      	addq	%rbx, %rcx
    22c3:      	movl	$0x2, %edx
    22c8:      	movl	$0x4, %eax
    22cd:      	movq	%r14, %rdi
    22d0:      	movzwl	(%r12), %edx
    22d5:      	addq	%rbx, %rdx
    22d8:      	movl	$0x2, %esi
    22dd:      	callq	*%rax
    22df:      	testq	%rax, %rax
    22e2:      	js	0x28c0 <generic_retkprobe_event+0x28c0>
    22e8:      	movzbl	0x5(%r12), %eax
    22ee:      	cmpl	$0x32, %eax
    22f1:      	jg	0x230f <generic_retkprobe_event+0x230f>
    22f3:      	testl	%eax, %eax
    22f5:      	je	0x232e <generic_retkprobe_event+0x232e>
    22f7:      	cmpl	$0x2b, %eax
    22fa:      	je	0x232e <generic_retkprobe_event+0x232e>
    22fc:      	cmpl	$0x2c, %eax
    22ff:      	jne	0x2363 <generic_retkprobe_event+0x2363>
    2301:      	movw	$0x8, 0x2(%r12)
    2309:      	movw	$0x8, %ax
    230d:      	jmp	0x2369 <generic_retkprobe_event+0x2369>
    230f:      	cmpl	$0x33, %eax
    2312:      	je	0x234e <generic_retkprobe_event+0x234e>
    2314:      	cmpl	$0x3c, %eax
    2317:      	je	0x232e <generic_retkprobe_event+0x232e>
    2319:      	cmpl	$0xff, %eax
    231e:      	jne	0x2363 <generic_retkprobe_event+0x2363>
    2320:      	movw	$0x28, 0x2(%r12)
    2328:      	movw	$0x28, %ax
    232c:      	jmp	0x2369 <generic_retkprobe_event+0x2369>
    232e:      	movzbl	0x7(%r12), %eax
    2334:      	leal	0x8(,%rax,8), %eax
    233b:      	movw	%ax, 0x2(%r12)
    2341:      	jmp	0x2369 <generic_retkprobe_event+0x2369>
    2343:      	movzwl	0x2(%r12), %eax
    2349:      	jmp	0x228a <generic_retkprobe_event+0x228a>
    234e:      	movzbl	0x7(%r12), %eax
    2354:      	leal	0x8(,%rax,4), %eax
    235b:      	movw	%ax, 0x2(%r12)
    2361:      	jmp	0x2369 <generic_retkprobe_event+0x2369>
    2363:      	movzwl	0x2(%r12), %eax
    2369:      	addw	(%r12), %ax
    236e:      	movw	%ax, (%r12)
    2373:      	movzbl	0x6(%r12), %ecx
    2379:      	cmpq	$0x3c, %rcx
    237d:      	ja	0x2ab9 <generic_retkprobe_event+0x2ab9>
    2383:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    238d:      	btq	%rcx, %rdx
    2391:      	jae	0x2ab9 <generic_retkprobe_event+0x2ab9>
    2397:      	movb	%cl, 0x5(%r12)
    239c:      	movzwl	%ax, %ecx
    239f:      	addq	%rbx, %rcx
    23a2:      	movl	$0x2, %edx
    23a7:      	movl	$0x4, %eax
    23ac:      	movq	%r14, %rdi
    23af:      	movzwl	(%r12), %edx
    23b4:      	addq	%rbx, %rdx
    23b7:      	movl	$0x2, %esi
    23bc:      	callq	*%rax
    23be:      	testq	%rax, %rax
    23c1:      	js	0x28c0 <generic_retkprobe_event+0x28c0>
    23c7:      	movzbl	0x5(%r12), %eax
    23cd:      	cmpl	$0x32, %eax
    23d0:      	jg	0x23ee <generic_retkprobe_event+0x23ee>
    23d2:      	testl	%eax, %eax
    23d4:      	je	0x240d <generic_retkprobe_event+0x240d>
    23d6:      	cmpl	$0x2b, %eax
    23d9:      	je	0x240d <generic_retkprobe_event+0x240d>
    23db:      	cmpl	$0x2c, %eax
    23de:      	jne	0x2437 <generic_retkprobe_event+0x2437>
    23e0:      	movw	$0x8, 0x2(%r12)
    23e8:      	movw	$0x8, %ax
    23ec:      	jmp	0x243d <generic_retkprobe_event+0x243d>
    23ee:      	cmpl	$0x33, %eax
    23f1:      	je	0x2422 <generic_retkprobe_event+0x2422>
    23f3:      	cmpl	$0x3c, %eax
    23f6:      	je	0x240d <generic_retkprobe_event+0x240d>
    23f8:      	cmpl	$0xff, %eax
    23fd:      	jne	0x2437 <generic_retkprobe_event+0x2437>
    23ff:      	movw	$0x28, 0x2(%r12)
    2407:      	movw	$0x28, %ax
    240b:      	jmp	0x243d <generic_retkprobe_event+0x243d>
    240d:      	movzbl	0x7(%r12), %eax
    2413:      	leal	0x8(,%rax,8), %eax
    241a:      	movw	%ax, 0x2(%r12)
    2420:      	jmp	0x243d <generic_retkprobe_event+0x243d>
    2422:      	movzbl	0x7(%r12), %eax
    2428:      	leal	0x8(,%rax,4), %eax
    242f:      	movw	%ax, 0x2(%r12)
    2435:      	jmp	0x243d <generic_retkprobe_event+0x243d>
    2437:      	movzwl	0x2(%r12), %eax
    243d:      	addw	(%r12), %ax
    2442:      	movw	%ax, (%r12)
    2447:      	movzbl	0x6(%r12), %ecx
    244d:      	cmpq	$0x3c, %rcx
    2451:      	ja	0x2ab9 <generic_retkprobe_event+0x2ab9>
    2457:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2461:      	btq	%rcx, %rdx
    2465:      	jae	0x2ab9 <generic_retkprobe_event+0x2ab9>
    246b:      	movb	%cl, 0x5(%r12)
    2470:      	movzwl	%ax, %ecx
    2473:      	addq	%rbx, %rcx
    2476:      	movl	$0x2, %edx
    247b:      	movl	$0x4, %eax
    2480:      	movq	%r14, %rdi
    2483:      	movzwl	(%r12), %edx
    2488:      	addq	%rbx, %rdx
    248b:      	movl	$0x2, %esi
    2490:      	callq	*%rax
    2492:      	testq	%rax, %rax
    2495:      	js	0x28c0 <generic_retkprobe_event+0x28c0>
    249b:      	movzbl	0x5(%r12), %eax
    24a1:      	cmpl	$0x32, %eax
    24a4:      	jg	0x24c2 <generic_retkprobe_event+0x24c2>
    24a6:      	testl	%eax, %eax
    24a8:      	je	0x24e1 <generic_retkprobe_event+0x24e1>
    24aa:      	cmpl	$0x2b, %eax
    24ad:      	je	0x24e1 <generic_retkprobe_event+0x24e1>
    24af:      	cmpl	$0x2c, %eax
    24b2:      	jne	0x250b <generic_retkprobe_event+0x250b>
    24b4:      	movw	$0x8, 0x2(%r12)
    24bc:      	movw	$0x8, %ax
    24c0:      	jmp	0x2511 <generic_retkprobe_event+0x2511>
    24c2:      	cmpl	$0x33, %eax
    24c5:      	je	0x24f6 <generic_retkprobe_event+0x24f6>
    24c7:      	cmpl	$0x3c, %eax
    24ca:      	je	0x24e1 <generic_retkprobe_event+0x24e1>
    24cc:      	cmpl	$0xff, %eax
    24d1:      	jne	0x250b <generic_retkprobe_event+0x250b>
    24d3:      	movw	$0x28, 0x2(%r12)
    24db:      	movw	$0x28, %ax
    24df:      	jmp	0x2511 <generic_retkprobe_event+0x2511>
    24e1:      	movzbl	0x7(%r12), %eax
    24e7:      	leal	0x8(,%rax,8), %eax
    24ee:      	movw	%ax, 0x2(%r12)
    24f4:      	jmp	0x2511 <generic_retkprobe_event+0x2511>
    24f6:      	movzbl	0x7(%r12), %eax
    24fc:      	leal	0x8(,%rax,4), %eax
    2503:      	movw	%ax, 0x2(%r12)
    2509:      	jmp	0x2511 <generic_retkprobe_event+0x2511>
    250b:      	movzwl	0x2(%r12), %eax
    2511:      	addw	(%r12), %ax
    2516:      	movw	%ax, (%r12)
    251b:      	movzbl	0x6(%r12), %ecx
    2521:      	cmpq	$0x3c, %rcx
    2525:      	ja	0x2ab9 <generic_retkprobe_event+0x2ab9>
    252b:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2535:      	btq	%rcx, %rdx
    2539:      	jae	0x2ab9 <generic_retkprobe_event+0x2ab9>
    253f:      	movb	%cl, 0x5(%r12)
    2544:      	movzwl	%ax, %ecx
    2547:      	addq	%rbx, %rcx
    254a:      	movl	$0x2, %edx
    254f:      	movl	$0x4, %eax
    2554:      	movq	%r14, %rdi
    2557:      	movzwl	(%r12), %edx
    255c:      	addq	%rbx, %rdx
    255f:      	movl	$0x2, %esi
    2564:      	callq	*%rax
    2566:      	testq	%rax, %rax
    2569:      	js	0x28c0 <generic_retkprobe_event+0x28c0>
    256f:      	movzbl	0x5(%r12), %eax
    2575:      	cmpl	$0x32, %eax
    2578:      	jg	0x259d <generic_retkprobe_event+0x259d>
    257a:      	testl	%eax, %eax
    257c:      	je	0x25c7 <generic_retkprobe_event+0x25c7>
    257e:      	cmpl	$0x2b, %eax
    2581:      	je	0x25c7 <generic_retkprobe_event+0x25c7>
    2583:      	cmpl	$0x2c, %eax
    2586:      	jne	0x26bd <generic_retkprobe_event+0x26bd>
    258c:      	movw	$0x8, 0x2(%r12)
    2594:      	movw	$0x8, %ax
    2598:      	jmp	0x26c3 <generic_retkprobe_event+0x26c3>
    259d:      	cmpl	$0x33, %eax
    25a0:      	je	0x26a8 <generic_retkprobe_event+0x26a8>
    25a6:      	cmpl	$0x3c, %eax
    25a9:      	je	0x25c7 <generic_retkprobe_event+0x25c7>
    25ab:      	cmpl	$0xff, %eax
    25b0:      	jne	0x26bd <generic_retkprobe_event+0x26bd>
    25b6:      	movw	$0x28, 0x2(%r12)
    25be:      	movw	$0x28, %ax
    25c2:      	jmp	0x26c3 <generic_retkprobe_event+0x26c3>
    25c7:      	movzbl	0x7(%r12), %eax
    25cd:      	leal	0x8(,%rax,8), %eax
    25d4:      	movw	%ax, 0x2(%r12)
    25da:      	jmp	0x26c3 <generic_retkprobe_event+0x26c3>
    25df:      	xorl	%r14d, %r14d
    25e2:      	cmpq	$0x5, 0xa0(%rsp)
    25eb:      	jb	0xb79 <generic_retkprobe_event+0xb79>
    25f1:      	movq	0x88(%rsp), %rax
    25f9:      	leaq	0x40(%rax), %rdx
    25fd:      	leaq	0x28(%rsp), %rdi
    2602:      	movl	$0x4, %ebp
    2607:      	movl	$0x10, %ecx
    260c:      	movl	$0x4, %eax
    2611:      	movl	$0x10, %esi
    2616:      	callq	*%rax
    2618:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    261d:      	testl	%eax, %eax
    261f:      	js	0x2c23 <generic_retkprobe_event+0x2c23>
    2625:      	movq	0x30(%rsp), %rax
    262a:      	cmpq	%r14, %rax
    262d:      	movq	%r14, %rcx
    2630:      	cmovbq	%rax, %rcx
    2634:      	testq	%r14, %r14
    2637:      	movq	%rcx, %r15
    263a:      	cmovneq	%rcx, %rax
    263e:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2643:      	movq	%rax, 0x20(%rsp)
    2648:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    264e:      	ja	0x2c23 <generic_retkprobe_event+0x2c23>
    2654:      	movq	(%rsp), %rdi
    2658:      	addq	%r12, %rdi
    265b:      	movq	%rdi, %r12
    265e:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2664:      	addq	0x10(%rsp), %rdi
    2669:      	movq	0x28(%rsp), %rcx
    266e:      	movl	$0x4, %eax
    2673:      	movq	0x20(%rsp), %rsi
    2678:      	movq	0x28(%rsp), %rdx
    267d:      	callq	*%rax
    267f:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2684:      	testl	%eax, %eax
    2686:      	js	0x2c23 <generic_retkprobe_event+0x2c23>
    268c:      	addq	0x20(%rsp), %r13
    2691:      	testq	%r14, %r14
    2694:      	je	0x2ac6 <generic_retkprobe_event+0x2ac6>
    269a:      	subq	%r15, %r14
    269d:      	jne	0x2ac9 <generic_retkprobe_event+0x2ac9>
    26a3:      	jmp	0xb79 <generic_retkprobe_event+0xb79>
    26a8:      	movzbl	0x7(%r12), %eax
    26ae:      	leal	0x8(,%rax,4), %eax
    26b5:      	movw	%ax, 0x2(%r12)
    26bb:      	jmp	0x26c3 <generic_retkprobe_event+0x26c3>
    26bd:      	movzwl	0x2(%r12), %eax
    26c3:      	addw	(%r12), %ax
    26c8:      	movw	%ax, (%r12)
    26cd:      	movzbl	0x6(%r12), %ecx
    26d3:      	cmpq	$0x3c, %rcx
    26d7:      	ja	0x2ab9 <generic_retkprobe_event+0x2ab9>
    26dd:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    26e7:      	btq	%rcx, %rdx
    26eb:      	jae	0x2ab9 <generic_retkprobe_event+0x2ab9>
    26f1:      	movb	%cl, 0x5(%r12)
    26f6:      	movzwl	%ax, %ecx
    26f9:      	addq	%rbx, %rcx
    26fc:      	movl	$0x2, %edx
    2701:      	movl	$0x4, %eax
    2706:      	movq	%r14, %rdi
    2709:      	movzwl	(%r12), %edx
    270e:      	addq	%rbx, %rdx
    2711:      	movl	$0x2, %esi
    2716:      	callq	*%rax
    2718:      	testq	%rax, %rax
    271b:      	js	0x28c0 <generic_retkprobe_event+0x28c0>
    2721:      	movzbl	0x5(%r12), %eax
    2727:      	cmpl	$0x32, %eax
    272a:      	jg	0x2748 <generic_retkprobe_event+0x2748>
    272c:      	testl	%eax, %eax
    272e:      	je	0x2767 <generic_retkprobe_event+0x2767>
    2730:      	cmpl	$0x2b, %eax
    2733:      	je	0x2767 <generic_retkprobe_event+0x2767>
    2735:      	cmpl	$0x2c, %eax
    2738:      	jne	0x2791 <generic_retkprobe_event+0x2791>
    273a:      	movw	$0x8, 0x2(%r12)
    2742:      	movw	$0x8, %ax
    2746:      	jmp	0x2797 <generic_retkprobe_event+0x2797>
    2748:      	cmpl	$0x33, %eax
    274b:      	je	0x277c <generic_retkprobe_event+0x277c>
    274d:      	cmpl	$0x3c, %eax
    2750:      	je	0x2767 <generic_retkprobe_event+0x2767>
    2752:      	cmpl	$0xff, %eax
    2757:      	jne	0x2791 <generic_retkprobe_event+0x2791>
    2759:      	movw	$0x28, 0x2(%r12)
    2761:      	movw	$0x28, %ax
    2765:      	jmp	0x2797 <generic_retkprobe_event+0x2797>
    2767:      	movzbl	0x7(%r12), %eax
    276d:      	leal	0x8(,%rax,8), %eax
    2774:      	movw	%ax, 0x2(%r12)
    277a:      	jmp	0x2797 <generic_retkprobe_event+0x2797>
    277c:      	movzbl	0x7(%r12), %eax
    2782:      	leal	0x8(,%rax,4), %eax
    2789:      	movw	%ax, 0x2(%r12)
    278f:      	jmp	0x2797 <generic_retkprobe_event+0x2797>
    2791:      	movzwl	0x2(%r12), %eax
    2797:      	addw	(%r12), %ax
    279c:      	movw	%ax, (%r12)
    27a1:      	movzbl	0x6(%r12), %ecx
    27a7:      	cmpq	$0x3c, %rcx
    27ab:      	ja	0x2ab9 <generic_retkprobe_event+0x2ab9>
    27b1:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    27bb:      	btq	%rcx, %rdx
    27bf:      	jae	0x2ab9 <generic_retkprobe_event+0x2ab9>
    27c5:      	movb	%cl, 0x5(%r12)
    27ca:      	movzwl	%ax, %ecx
    27cd:      	addq	%rbx, %rcx
    27d0:      	movl	$0x2, %edx
    27d5:      	movl	$0x4, %eax
    27da:      	movq	%r14, %rdi
    27dd:      	movzwl	(%r12), %edx
    27e2:      	addq	%rbx, %rdx
    27e5:      	movl	$0x2, %esi
    27ea:      	callq	*%rax
    27ec:      	testq	%rax, %rax
    27ef:      	js	0x28c0 <generic_retkprobe_event+0x28c0>
    27f5:      	movzbl	0x5(%r12), %eax
    27fb:      	cmpl	$0x32, %eax
    27fe:      	jg	0x281c <generic_retkprobe_event+0x281c>
    2800:      	testl	%eax, %eax
    2802:      	je	0x283b <generic_retkprobe_event+0x283b>
    2804:      	cmpl	$0x2b, %eax
    2807:      	je	0x283b <generic_retkprobe_event+0x283b>
    2809:      	cmpl	$0x2c, %eax
    280c:      	jne	0x2865 <generic_retkprobe_event+0x2865>
    280e:      	movw	$0x8, 0x2(%r12)
    2816:      	movw	$0x8, %ax
    281a:      	jmp	0x286b <generic_retkprobe_event+0x286b>
    281c:      	cmpl	$0x33, %eax
    281f:      	je	0x2850 <generic_retkprobe_event+0x2850>
    2821:      	cmpl	$0x3c, %eax
    2824:      	je	0x283b <generic_retkprobe_event+0x283b>
    2826:      	cmpl	$0xff, %eax
    282b:      	jne	0x2865 <generic_retkprobe_event+0x2865>
    282d:      	movw	$0x28, 0x2(%r12)
    2835:      	movw	$0x28, %ax
    2839:      	jmp	0x286b <generic_retkprobe_event+0x286b>
    283b:      	movzbl	0x7(%r12), %eax
    2841:      	leal	0x8(,%rax,8), %eax
    2848:      	movw	%ax, 0x2(%r12)
    284e:      	jmp	0x286b <generic_retkprobe_event+0x286b>
    2850:      	movzbl	0x7(%r12), %eax
    2856:      	leal	0x8(,%rax,4), %eax
    285d:      	movw	%ax, 0x2(%r12)
    2863:      	jmp	0x286b <generic_retkprobe_event+0x286b>
    2865:      	movzwl	0x2(%r12), %eax
    286b:      	addw	(%r12), %ax
    2870:      	movw	%ax, (%r12)
    2875:      	movzbl	0x6(%r12), %ecx
    287b:      	cmpq	$0x3c, %rcx
    287f:      	ja	0x2ab9 <generic_retkprobe_event+0x2ab9>
    2885:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    288f:      	btq	%rcx, %rdx
    2893:      	jae	0x2ab9 <generic_retkprobe_event+0x2ab9>
    2899:      	movb	%cl, 0x5(%r12)
    289e:      	movzwl	%ax, %ecx
    28a1:      	addq	%rbx, %rcx
    28a4:      	movl	$0x2, %edx
    28a9:      	movl	$0x4, %eax
    28ae:      	movzwl	(%r12), %edx
    28b3:      	addq	%rbx, %rdx
    28b6:      	movq	%r14, %rdi
    28b9:      	movl	$0x2, %esi
    28be:      	callq	*%rax
    28c0:      	xorl	%ecx, %ecx
    28c2:      	movb	%cl, 0xc8(%rsp)
    28c9:      	movzbl	%cl, %eax
    28cc:      	movq	(%rsp), %rbx
    28d0:      	movw	%ax, 0xc0(%rbx)
    28d7:      	movw	$0xa, 0xc2(%rbx)
    28e0:      	leaq	0x8(%r15), %rdx
    28e4:      	movl	$0x10, %ecx
    28e9:      	movl	$0x4, %eax
    28ee:      	movq	0x8(%rsp), %rdi
    28f3:      	movl	$0x10, %esi
    28f8:      	callq	*%rax
    28fa:      	leaq	0xac(%rbx), %rdi
    2901:      	addq	$0x18, %r15
    2905:      	movl	$0x10, %ecx
    290a:      	movl	$0x4, %eax
    290f:      	movl	$0x10, %esi
    2914:      	movq	%r15, %rdx
    2917:      	callq	*%rax
    2919:      	movzbl	0xc8(%rsp), %eax
    2921:      	cmpl	$0x11, %eax
    2924:      	je	0x2978 <generic_retkprobe_event+0x2978>
    2926:      	cmpl	$0x6, %eax
    2929:      	jne	0x29c8 <generic_retkprobe_event+0x29c8>
    292f:      	movq	0x28(%rsp), %rbx
    2934:      	movzwl	0xd0(%rsp), %r14d
    293d:      	leaq	(%rbx,%r14), %rdx
    2941:      	movq	(%rsp), %r15
    2945:      	leaq	0xbc(%r15), %rdi
    294c:      	movl	$0x2, %ecx
    2951:      	movl	$0x4, %eax
    2956:      	movl	$0x2, %esi
    295b:      	callq	*%rax
    295d:      	leaq	0xbe(%r15), %rdi
    2964:      	leaq	(%rbx,%r14), %rdx
    2968:      	addq	$0x2, %rdx
    296c:      	movl	$0x2, %ecx
    2971:      	movl	$0x4, %eax
    2976:      	jmp	0x29bf <generic_retkprobe_event+0x29bf>
    2978:      	movq	0x28(%rsp), %rbx
    297d:      	movzwl	0xd0(%rsp), %r14d
    2986:      	leaq	(%rbx,%r14), %rdx
    298a:      	movq	(%rsp), %r15
    298e:      	leaq	0xbc(%r15), %rdi
    2995:      	movl	$0x2, %ecx
    299a:      	movl	$0x4, %eax
    299f:      	movl	$0x2, %esi
    29a4:      	callq	*%rax
    29a6:      	leaq	0xbe(%r15), %rdi
    29ad:      	leaq	(%rbx,%r14), %rdx
    29b1:      	addq	$0x2, %rdx
    29b5:      	movl	$0x2, %ecx
    29ba:      	movl	$0x4, %eax
    29bf:      	movl	$0x2, %esi
    29c4:      	callq	*%rax
    29c6:      	jmp	0x29d6 <generic_retkprobe_event+0x29d6>
    29c8:      	movq	(%rsp), %rax
    29cc:      	movl	$0x0, 0xbc(%rax)
    29d6:      	movq	(%rsp), %rax
    29da:      	movzwl	0xbc(%rax), %ecx
    29e1:      	movzwl	0xbe(%rax), %edx
    29e8:      	movbew	%cx, 0xbc(%rax)
    29f1:      	movbew	%dx, 0xbe(%rax)
    29fa:      	addq	$0xe0, %rbp
    2a01:      	leaq	0x68(%rsp), %rdi
    2a06:      	movl	$0x8, %ecx
    2a0b:      	movl	$0x4, %eax
    2a10:      	movl	$0x4, %ebx
    2a15:      	movl	$0x8, %esi
    2a1a:      	movq	%rbp, %rdx
    2a1d:      	callq	*%rax
    2a1f:      	movq	0x68(%rsp), %rcx
    2a24:      	testq	%rcx, %rcx
    2a27:      	je	0x2a9a <generic_retkprobe_event+0x2a9a>
    2a29:      	addq	$0x5, %rcx
    2a2d:      	leaq	0x90(%rsp), %rdi
    2a35:      	movl	$0x8, %edx
    2a3a:      	movl	$0x4, %eax
    2a3f:      	movq	0x68(%rsp), %rdx
    2a44:      	addq	$0x5, %rdx
    2a48:      	movl	$0x8, %esi
    2a4d:      	callq	*%rax
    2a4f:      	movq	0x68(%rsp), %r14
    2a54:      	movq	0x90(%rsp), %r15
    2a5c:      	movq	(%rsp), %r12
    2a60:      	leaq	0xd4(%r12), %rdi
    2a68:      	leaq	(%r14,%r15,8), %rdx
    2a6c:      	addq	$0x44, %rdx
    2a70:      	movl	$0x4, %eax
    2a75:      	movl	$0x4, %esi
    2a7a:      	callq	*%rax
    2a7c:      	movq	%r12, %rdi
    2a7f:      	addq	$0xd8, %rdi
    2a86:      	leaq	(%r14,%r15,8), %rdx
    2a8a:      	addq	$0x45, %rdx
    2a8e:      	movl	$0x4, %eax
    2a93:      	movl	$0x4, %esi
    2a98:      	callq	*%rax
    2a9a:      	movq	%r13, %r14
    2a9d:      	movq	0x10(%rsp), %r15
    2aa2:      	movl	$0x40, %r13d
    2aa8:      	movq	(%rsp), %rcx
    2aac:      	movq	0x80(%rsp), %r12
    2ab4:      	jmp	0x1164 <generic_retkprobe_event+0x1164>
    2ab9:      	movw	%ax, 0xd0(%rsp)
    2ac1:      	jmp	0x28c2 <generic_retkprobe_event+0x28c2>
    2ac6:      	xorl	%r14d, %r14d
    2ac9:      	cmpq	$0x5, 0xa0(%rsp)
    2ad2:      	je	0xb79 <generic_retkprobe_event+0xb79>
    2ad8:      	movq	0x88(%rsp), %rax
    2ae0:      	leaq	0x50(%rax), %rdx
    2ae4:      	leaq	0x28(%rsp), %rdi
    2ae9:      	movl	$0x4, %ebp
    2aee:      	movl	$0x10, %ecx
    2af3:      	movl	$0x4, %eax
    2af8:      	movl	$0x10, %esi
    2afd:      	callq	*%rax
    2aff:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2b04:      	testl	%eax, %eax
    2b06:      	js	0x2c23 <generic_retkprobe_event+0x2c23>
    2b0c:      	movq	0x30(%rsp), %rax
    2b11:      	cmpq	%r14, %rax
    2b14:      	movq	%r14, %r15
    2b17:      	cmovbq	%rax, %r15
    2b1b:      	testq	%r14, %r14
    2b1e:      	cmovneq	%r15, %rax
    2b22:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2b27:      	movq	%rax, (%rsp)
    2b2b:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    2b31:      	ja	0x2c23 <generic_retkprobe_event+0x2c23>
    2b37:      	movq	0x20(%rsp), %rdi
    2b3c:      	addq	%r12, %rdi
    2b3f:      	movq	%rdi, 0x20(%rsp)
    2b44:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2b4a:      	addq	0x10(%rsp), %rdi
    2b4f:      	movq	0x28(%rsp), %rcx
    2b54:      	movl	$0x4, %eax
    2b59:      	movq	(%rsp), %rsi
    2b5d:      	movq	0x28(%rsp), %rdx
    2b62:      	callq	*%rax
    2b64:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2b69:      	testl	%eax, %eax
    2b6b:      	js	0x2c23 <generic_retkprobe_event+0x2c23>
    2b71:      	addq	(%rsp), %r13
    2b75:      	testq	%r14, %r14
    2b78:      	je	0x2b84 <generic_retkprobe_event+0x2b84>
    2b7a:      	subq	%r15, %r14
    2b7d:      	jne	0x2b87 <generic_retkprobe_event+0x2b87>
    2b7f:      	jmp	0xb79 <generic_retkprobe_event+0xb79>
    2b84:      	xorl	%r14d, %r14d
    2b87:      	cmpq	$0x7, 0xa0(%rsp)
    2b90:      	jb	0xb79 <generic_retkprobe_event+0xb79>
    2b96:      	movq	0x88(%rsp), %rdx
    2b9e:      	addq	$0x60, %rdx
    2ba2:      	leaq	0x28(%rsp), %rdi
    2ba7:      	movl	$0x4, %ebp
    2bac:      	movl	$0x10, %ecx
    2bb1:      	movl	$0x4, %eax
    2bb6:      	movl	$0x10, %esi
    2bbb:      	callq	*%rax
    2bbd:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2bc2:      	testl	%eax, %eax
    2bc4:      	js	0x2c23 <generic_retkprobe_event+0x2c23>
    2bc6:      	movq	0x30(%rsp), %rax
    2bcb:      	cmpq	%r14, %rax
    2bce:      	movq	%r14, %r12
    2bd1:      	cmovbq	%rax, %r12
    2bd5:      	testq	%r14, %r14
    2bd8:      	cmoveq	%rax, %r12
    2bdc:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2be1:      	cmpq	$0xffe, %r12            # imm = 0xFFE
    2be8:      	ja	0x2c23 <generic_retkprobe_event+0x2c23>
    2bea:      	movq	(%rsp), %rdi
    2bee:      	addq	0x20(%rsp), %rdi
    2bf3:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2bf9:      	addq	0x10(%rsp), %rdi
    2bfe:      	movq	0x28(%rsp), %rcx
    2c03:      	movl	$0x4, %eax
    2c08:      	movq	0x28(%rsp), %rdx
    2c0d:      	movl	%r12d, %esi
    2c10:      	callq	*%rax
    2c12:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2c17:      	testl	%eax, %eax
    2c19:      	js	0x2c23 <generic_retkprobe_event+0x2c23>
    2c1b:      	addq	%r13, %r12
    2c1e:      	jmp	0x35c <generic_retkprobe_event+0x35c>
    2c23:      	movq	0x10(%rsp), %rax
    2c28:      	movl	%ecx, (%rax,%rbx)
    2c2b:      	addq	%rbx, %rbp
    2c2e:      	movq	%rbp, %rbx
    2c31:      	movq	0xb8(%rsp), %r13
    2c39:      	movq	0x80(%rsp), %r12
    2c41:      	movq	0x78(%rsp), %r14
    2c46:      	movl	$0x23, %eax
    2c4b:      	callq	*%rax
    2c4d:      	movq	%rax, %rcx
    2c50:      	movq	%rax, 0x28(%rsp)
    2c55:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    2c5c:      	leaq	0x90(%rsp), %rdi
    2c64:      	movl	$0x4, %edx
    2c69:      	movl	$0x71, %eax
    2c6e:      	movl	$0xaf4, %edx            # imm = 0xAF4
    2c73:      	addq	0x28(%rsp), %rdx
    2c78:      	movl	$0x4, %esi
    2c7d:      	callq	*%rax
    2c7f:      	movl	0x90(%rsp), %eax
    2c86:      	movl	%eax, 0x68(%rsp)
    2c8a:      	movq	(%rip), %rdi            # 0x2c91 <generic_retkprobe_event+0x2c91>
    2c91:      	leaq	0x68(%rsp), %rsi
    2c96:      	movl	$0x1, %eax
    2c9b:      	callq	*%rax
    2c9d:      	testq	%rax, %rax
    2ca0:      	je	0x2cb0 <generic_retkprobe_event+0x2cb0>
    2ca2:      	movq	%rax, %r15
    2ca5:      	cmpq	$0x0, 0x8(%rax)
    2caa:      	jne	0x2e86 <generic_retkprobe_event+0x2e86>
    2cb0:      	movl	$0xb00, %edx            # imm = 0xB00
    2cb5:      	movq	0x28(%rsp), %rcx
    2cba:      	addq	%rdx, %rcx
    2cbd:      	leaq	0x28(%rsp), %rdi
    2cc2:      	movl	$0x8, %esi
    2cc7:      	movl	$0x71, %eax
    2ccc:      	addq	0x28(%rsp), %rdx
    2cd1:      	movl	$0x8, %esi
    2cd6:      	callq	*%rax
    2cd8:      	movq	0x28(%rsp), %rcx
    2cdd:      	testq	%rcx, %rcx
    2ce0:      	je	0x2e83 <generic_retkprobe_event+0x2e83>
    2ce6:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    2ced:      	leaq	0x90(%rsp), %rdi
    2cf5:      	movl	$0x4, %edx
    2cfa:      	movl	$0x71, %eax
    2cff:      	movl	$0xaf4, %edx            # imm = 0xAF4
    2d04:      	addq	0x28(%rsp), %rdx
    2d09:      	movl	$0x4, %esi
    2d0e:      	callq	*%rax
    2d10:      	movl	0x90(%rsp), %eax
    2d17:      	movl	%eax, 0x68(%rsp)
    2d1b:      	movq	(%rip), %rdi            # 0x2d22 <generic_retkprobe_event+0x2d22>
    2d22:      	leaq	0x68(%rsp), %rsi
    2d27:      	movl	$0x1, %eax
    2d2c:      	callq	*%rax
    2d2e:      	testq	%rax, %rax
    2d31:      	je	0x2d41 <generic_retkprobe_event+0x2d41>
    2d33:      	movq	%rax, %r15
    2d36:      	cmpq	$0x0, 0x8(%rax)
    2d3b:      	jne	0x2e86 <generic_retkprobe_event+0x2e86>
    2d41:      	movl	$0xb00, %edx            # imm = 0xB00
    2d46:      	movq	0x28(%rsp), %rcx
    2d4b:      	addq	%rdx, %rcx
    2d4e:      	leaq	0x28(%rsp), %rdi
    2d53:      	movl	$0x8, %esi
    2d58:      	movl	$0x71, %eax
    2d5d:      	addq	0x28(%rsp), %rdx
    2d62:      	movl	$0x8, %esi
    2d67:      	callq	*%rax
    2d69:      	movq	0x28(%rsp), %rcx
    2d6e:      	testq	%rcx, %rcx
    2d71:      	je	0x2e83 <generic_retkprobe_event+0x2e83>
    2d77:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    2d7e:      	leaq	0x90(%rsp), %rdi
    2d86:      	movl	$0x4, %edx
    2d8b:      	movl	$0x71, %eax
    2d90:      	movl	$0xaf4, %edx            # imm = 0xAF4
    2d95:      	addq	0x28(%rsp), %rdx
    2d9a:      	movl	$0x4, %esi
    2d9f:      	callq	*%rax
    2da1:      	movl	0x90(%rsp), %eax
    2da8:      	movl	%eax, 0x68(%rsp)
    2dac:      	movq	(%rip), %rdi            # 0x2db3 <generic_retkprobe_event+0x2db3>
    2db3:      	leaq	0x68(%rsp), %rsi
    2db8:      	movl	$0x1, %eax
    2dbd:      	callq	*%rax
    2dbf:      	testq	%rax, %rax
    2dc2:      	je	0x2dd2 <generic_retkprobe_event+0x2dd2>
    2dc4:      	movq	%rax, %r15
    2dc7:      	cmpq	$0x0, 0x8(%rax)
    2dcc:      	jne	0x2e86 <generic_retkprobe_event+0x2e86>
    2dd2:      	movl	$0xb00, %edx            # imm = 0xB00
    2dd7:      	movq	0x28(%rsp), %rcx
    2ddc:      	addq	%rdx, %rcx
    2ddf:      	leaq	0x28(%rsp), %rdi
    2de4:      	movl	$0x8, %esi
    2de9:      	movl	$0x71, %eax
    2dee:      	addq	0x28(%rsp), %rdx
    2df3:      	movl	$0x8, %esi
    2df8:      	callq	*%rax
    2dfa:      	movq	0x28(%rsp), %rcx
    2dff:      	testq	%rcx, %rcx
    2e02:      	je	0x2e83 <generic_retkprobe_event+0x2e83>
    2e04:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    2e0b:      	leaq	0x90(%rsp), %rdi
    2e13:      	movl	$0x4, %edx
    2e18:      	movl	$0x71, %eax
    2e1d:      	movl	$0xaf4, %edx            # imm = 0xAF4
    2e22:      	addq	0x28(%rsp), %rdx
    2e27:      	movl	$0x4, %esi
    2e2c:      	callq	*%rax
    2e2e:      	movl	0x90(%rsp), %eax
    2e35:      	movl	%eax, 0x68(%rsp)
    2e39:      	movq	(%rip), %rdi            # 0x2e40 <generic_retkprobe_event+0x2e40>
    2e40:      	leaq	0x68(%rsp), %rsi
    2e45:      	movl	$0x1, %eax
    2e4a:      	callq	*%rax
    2e4c:      	testq	%rax, %rax
    2e4f:      	je	0x2e5b <generic_retkprobe_event+0x2e5b>
    2e51:      	movq	%rax, %r15
    2e54:      	cmpq	$0x0, 0x8(%rax)
    2e59:      	jne	0x2e86 <generic_retkprobe_event+0x2e86>
    2e5b:      	movl	$0xb00, %edx            # imm = 0xB00
    2e60:      	movq	0x28(%rsp), %rcx
    2e65:      	addq	%rdx, %rcx
    2e68:      	leaq	0x28(%rsp), %rdi
    2e6d:      	movl	$0x8, %esi
    2e72:      	movl	$0x71, %eax
    2e77:      	addq	0x28(%rsp), %rdx
    2e7c:      	movl	$0x8, %esi
    2e81:      	callq	*%rax
    2e83:      	xorl	%r15d, %r15d
    2e86:      	movl	$0x10d, (%r12)          # imm = 0x10D
    2e8e:      	movl	%ebx, 0x4(%r12)
    2e93:      	movl	$0x7d, %eax
    2e98:      	callq	*%rax
    2e9a:      	movq	%rax, 0x8(%r12)
    2e9f:      	testq	%r15, %r15
    2ea2:      	je	0x2eb5 <generic_retkprobe_event+0x2eb5>
    2ea4:      	movl	(%r15), %eax
    2ea7:      	movl	%eax, 0x10(%r12)
    2eac:      	movq	0x8(%r15), %rax
    2eb0:      	movq	%rax, 0x18(%r12)
    2eb5:      	movl	$0x0, 0x14(%r12)
    2ebe:      	movl	(%r14), %eax
    2ec1:      	movq	%rax, 0x60(%r12)
    2ec6:      	movl	%ebx, 0x4(%r12)
    2ecb:      	movq	(%rip), %rsi            # 0x2ed2 <generic_retkprobe_event+0x2ed2>
    2ed2:      	movl	$0x3, %ecx
    2ed7:      	movl	$0xc, %eax
    2edc:      	movq	%r13, %rdi
    2edf:      	movl	$0x3, %edx
    2ee4:      	callq	*%rax
    2ee6:      	movl	$0x1, %ebp
    2eeb:      	movl	%ebp, %eax
    2eed:      	addq	$0xf8, %rsp
    2ef4:      	popq	%rbx
    2ef5:      	popq	%r12
    2ef7:      	popq	%r13
    2ef9:      	popq	%r14
    2efb:      	popq	%r15
    2efd:      	popq	%rbp
    2efe:      	retq
