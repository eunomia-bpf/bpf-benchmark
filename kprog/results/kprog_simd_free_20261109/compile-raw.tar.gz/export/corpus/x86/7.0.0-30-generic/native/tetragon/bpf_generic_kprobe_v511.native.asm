
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_generic_kprobe_v511.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <native_bpf_strncasestr>:
       0:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
       5:      	testq	%rdx, %rdx
       8:      	je	0x74 <native_bpf_strncasestr+0x74>
       a:      	pushq	%rbx
       b:      	xorl	%ecx, %ecx
       d:      	jmp	0x1b <native_bpf_strncasestr+0x1b>
       f:      	nop
      10:      	incq	%rcx
      13:      	incq	%rdi
      16:      	cmpq	%rdx, %rcx
      19:      	je	0x73 <native_bpf_strncasestr+0x73>
      1b:      	xorl	%r8d, %r8d
      1e:      	nop
      20:      	leaq	(%rcx,%r8), %r9
      24:      	cmpq	%rdx, %r9
      27:      	jae	0x10 <native_bpf_strncasestr+0x10>
      29:      	movsbl	(%rsi,%r8), %r9d
      2e:      	testl	%r9d, %r9d
      31:      	je	0x71 <native_bpf_strncasestr+0x71>
      33:      	movsbl	(%rdi,%r8), %r10d
      38:      	leal	-0x41(%r10), %r11d
      3c:      	movl	%r10d, %ebx
      3f:      	orl	$0x20, %ebx
      42:      	cmpl	$0x1a, %r11d
      46:      	cmovael	%r10d, %ebx
      4a:      	leal	-0x41(%r9), %r10d
      4e:      	movl	%r9d, %r11d
      51:      	orl	$0x20, %r11d
      55:      	cmpl	$0x1a, %r10d
      59:      	cmovael	%r9d, %r11d
      5d:      	cmpl	%r11d, %ebx
      60:      	jne	0x10 <native_bpf_strncasestr+0x10>
      62:      	leaq	0x1(%r8), %r9
      66:      	cmpq	$0x63, %r8
      6a:      	movq	%r9, %r8
      6d:      	jb	0x20 <native_bpf_strncasestr+0x20>
      6f:      	jmp	0x10 <native_bpf_strncasestr+0x10>
      71:      	movl	%ecx, %eax
      73:      	popq	%rbx
      74:      	retq

Disassembly of section kprobe:

0000000000000000 <generic_kprobe_setup_event>:
       0:      	pushq	%r15
       2:      	pushq	%r14
       4:      	pushq	%rbx
       5:      	subq	$0x40, %rsp
       9:      	movq	%rdi, %rbx
       c:      	movl	$0x0, 0x1c(%rsp)
      14:      	movq	(%rip), %rdi            # 0x1b <generic_kprobe_setup_event+0x1b>
      1b:      	leaq	0x1c(%rsp), %rsi
      20:      	movl	$0x1, %eax
      25:      	callq	*%rax
      27:      	testq	%rax, %rax
      2a:      	je	0x343 <generic_kprobe_setup_event+0x343>
      30:      	movq	%rax, %r14
      33:      	leaq	0x5ef8(%rax), %rsi
      3a:      	movq	(%rip), %rdi            # 0x41 <generic_kprobe_setup_event+0x41>
      41:      	movl	$0x1, %eax
      46:      	callq	*%rax
      48:      	testq	%rax, %rax
      4b:      	je	0x343 <generic_kprobe_setup_event+0x343>
      51:      	movq	%rax, %r15
      54:      	cmpl	$0x0, 0x54(%rax)
      58:      	je	0x109 <generic_kprobe_setup_event+0x109>
      5e:      	testq	%rbx, %rbx
      61:      	je	0x343 <generic_kprobe_setup_event+0x343>
      67:      	leaq	0x70(%rbx), %rdx
      6b:      	movq	%rsp, %rdi
      6e:      	movl	$0x8, %ecx
      73:      	movl	$0x4, %eax
      78:      	movl	$0x8, %esi
      7d:      	callq	*%rax
      7f:      	movq	(%rsp), %rax
      83:      	movq	%rax, 0x5e50(%r14)
      8a:      	leaq	0x68(%rbx), %rdx
      8e:      	movq	%rsp, %rdi
      91:      	movl	$0x8, %ecx
      96:      	movl	$0x4, %eax
      9b:      	movl	$0x8, %esi
      a0:      	callq	*%rax
      a2:      	movq	(%rsp), %rax
      a6:      	movq	%rax, 0x5e58(%r14)
      ad:      	leaq	0x60(%rbx), %rdx
      b1:      	movq	%rsp, %rdi
      b4:      	movl	$0x8, %ecx
      b9:      	movl	$0x4, %eax
      be:      	movl	$0x8, %esi
      c3:      	callq	*%rax
      c5:      	movq	(%rsp), %rax
      c9:      	movq	%rax, 0x5e60(%r14)
      d0:      	leaq	0x38(%rbx), %rdx
      d4:      	movq	%rsp, %rdi
      d7:      	movl	$0x8, %ecx
      dc:      	movl	$0x4, %eax
      e1:      	movl	$0x8, %esi
      e6:      	callq	*%rax
      e8:      	movq	(%rsp), %rax
      ec:      	movq	%rax, 0x5e68(%r14)
      f3:      	leaq	0x48(%rbx), %rdx
      f7:      	movq	%rsp, %rdi
      fa:      	movl	$0x8, %ecx
      ff:      	movl	$0x4, %eax
     104:      	jmp	0x1a6 <generic_kprobe_setup_event+0x1a6>
     109:      	leaq	0x70(%rbx), %rdx
     10d:      	movq	%rsp, %rdi
     110:      	movl	$0x8, %ecx
     115:      	movl	$0x4, %eax
     11a:      	movl	$0x8, %esi
     11f:      	callq	*%rax
     121:      	movq	(%rsp), %rax
     125:      	movq	%rax, 0x5e50(%r14)
     12c:      	leaq	0x68(%rbx), %rdx
     130:      	movq	%rsp, %rdi
     133:      	movl	$0x8, %ecx
     138:      	movl	$0x4, %eax
     13d:      	movl	$0x8, %esi
     142:      	callq	*%rax
     144:      	movq	(%rsp), %rax
     148:      	movq	%rax, 0x5e58(%r14)
     14f:      	leaq	0x60(%rbx), %rdx
     153:      	movq	%rsp, %rdi
     156:      	movl	$0x8, %ecx
     15b:      	movl	$0x4, %eax
     160:      	movl	$0x8, %esi
     165:      	callq	*%rax
     167:      	movq	(%rsp), %rax
     16b:      	movq	%rax, 0x5e60(%r14)
     172:      	leaq	0x58(%rbx), %rdx
     176:      	movq	%rsp, %rdi
     179:      	movl	$0x8, %ecx
     17e:      	movl	$0x4, %eax
     183:      	movl	$0x8, %esi
     188:      	callq	*%rax
     18a:      	movq	(%rsp), %rax
     18e:      	movq	%rax, 0x5e68(%r14)
     195:      	leaq	0x48(%rbx), %rdx
     199:      	movq	%rsp, %rdi
     19c:      	movl	$0x8, %ecx
     1a1:      	movl	$0x4, %eax
     1a6:      	movl	$0x8, %esi
     1ab:      	callq	*%rax
     1ad:      	movq	(%rsp), %rax
     1b1:      	movq	%rax, 0x5e70(%r14)
     1b8:      	movb	$0xd, (%r14)
     1bc:      	movw	$0x0, 0x2(%r14)
     1c3:      	movl	$0x0, 0x4(%r14)
     1cb:      	movl	$0x7d, %eax
     1d0:      	callq	*%rax
     1d2:      	movq	%rax, 0x8(%r14)
     1d6:      	movq	$0x0, 0x70(%r14)
     1de:      	movl	$0x0, 0x14(%r14)
     1e6:      	movl	$0xe, %eax
     1eb:      	callq	*%rax
     1ed:      	movl	%eax, 0x7c(%r14)
     1f1:      	movl	$0xe, %eax
     1f6:      	callq	*%rax
     1f8:      	cmpq	$-0x16, %rax
     1fc:      	jne	0x21a <generic_kprobe_setup_event+0x21a>
     1fe:      	leaq	0x20(%rbx), %rdx
     202:      	movq	%rsp, %rdi
     205:      	movl	$0x8, %ecx
     20a:      	movl	$0x4, %eax
     20f:      	movl	$0x8, %esi
     214:      	callq	*%rax
     216:      	movq	(%rsp), %rax
     21a:      	movq	%rax, 0x68(%r14)
     21e:      	cmpl	$0x0, 0x5c(%r15)
     223:      	jle	0x2cd <generic_kprobe_setup_event+0x2cd>
     229:      	movq	0x8(%r14), %rcx
     22d:      	movq	0x60(%r14), %rdx
     231:      	movq	%rcx, (%rsp)
     235:      	movq	$0x1, 0x8(%rsp)
     23e:      	movq	$0x0, 0x10(%rsp)
     247:      	movq	%rdx, 0x30(%rsp)
     24c:      	movq	%rax, 0x38(%rsp)
     251:      	movq	(%rip), %rdi            # 0x258 <generic_kprobe_setup_event+0x258>
     258:      	xorl	%ecx, %ecx
     25a:      	leaq	0x30(%rsp), %rsi
     25f:      	movq	%rsp, %rdx
     262:      	movl	$0x2, %eax
     267:      	xorl	%ecx, %ecx
     269:      	callq	*%rax
     26b:      	testq	%rax, %rax
     26e:      	je	0x2cd <generic_kprobe_setup_event+0x2cd>
     270:      	negl	%eax
     272:      	movw	%ax, 0x24(%rsp)
     277:      	movw	$0x5, 0x26(%rsp)
     27e:      	movabsq	$0x200000046, %rax      # imm = 0x200000046
     288:      	movq	%rax, 0x28(%rsp)
     28d:      	movq	(%rip), %rdi            # 0x294 <generic_kprobe_setup_event+0x294>
     294:      	leaq	0x24(%rsp), %rsi
     299:      	movl	$0x1, %eax
     29e:      	callq	*%rax
     2a0:      	testq	%rax, %rax
     2a3:      	je	0x2a9 <generic_kprobe_setup_event+0x2a9>
     2a5:      	incl	(%rax)
     2a7:      	jmp	0x2cd <generic_kprobe_setup_event+0x2cd>
     2a9:      	movl	$0x1, 0x20(%rsp)
     2b1:      	movq	(%rip), %rdi            # 0x2b8 <generic_kprobe_setup_event+0x2b8>
     2b8:      	xorl	%ecx, %ecx
     2ba:      	leaq	0x24(%rsp), %rsi
     2bf:      	leaq	0x20(%rsp), %rdx
     2c4:      	movl	$0x2, %eax
     2c9:      	xorl	%ecx, %ecx
     2cb:      	callq	*%rax
     2cd:      	movl	$0x0, (%rsp)
     2d4:      	movq	(%rip), %rdi            # 0x2db <generic_kprobe_setup_event+0x2db>
     2db:      	movq	%rsp, %rsi
     2de:      	movl	$0x1, %eax
     2e3:      	callq	*%rax
     2e5:      	testq	%rax, %rax
     2e8:      	je	0x30d <generic_kprobe_setup_event+0x30d>
     2ea:      	movq	%rax, %rsi
     2ed:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
     2f4:      	movq	(%rip), %rdi            # 0x2fb <generic_kprobe_setup_event+0x2fb>
     2fb:      	movl	$0x1, %eax
     300:      	callq	*%rax
     302:      	testq	%rax, %rax
     305:      	je	0x30d <generic_kprobe_setup_event+0x30d>
     307:      	cmpl	$-0x1, 0x40(%rax)
     30b:      	jne	0x328 <generic_kprobe_setup_event+0x328>
     30d:      	movq	(%rip), %rsi            # 0x314 <generic_kprobe_setup_event+0x314>
     314:      	movl	$0x3, %ecx
     319:      	movl	$0xc, %eax
     31e:      	movq	%rbx, %rdi
     321:      	movl	$0x3, %edx
     326:      	callq	*%rax
     328:      	movq	(%rip), %rsi            # 0x32f <generic_kprobe_setup_event+0x32f>
     32f:      	movl	$0x1, %ecx
     334:      	movl	$0xc, %eax
     339:      	movq	%rbx, %rdi
     33c:      	movl	$0x1, %edx
     341:      	callq	*%rax
     343:      	xorl	%eax, %eax
     345:      	addq	$0x40, %rsp
     349:      	popq	%rbx
     34a:      	popq	%r14
     34c:      	popq	%r15
     34e:      	retq
     34f:      	nop

0000000000000350 <generic_kprobe_process_event>:
     350:      	pushq	%rbp
     351:      	pushq	%r15
     353:      	pushq	%r14
     355:      	pushq	%r13
     357:      	pushq	%r12
     359:      	pushq	%rbx
     35a:      	subq	$0x108, %rsp            # imm = 0x108
     361:      	movq	%rdi, %rbx
     364:      	movl	$0x0, 0xf4(%rsp)
     36f:      	movq	(%rip), %rdi            # 0x376 <generic_kprobe_process_event+0x26>
     376:      	leaq	0xf4(%rsp), %rsi
     37e:      	movl	$0x1, %eax
     383:      	callq	*%rax
     385:      	testq	%rax, %rax
     388:      	je	0x11e1 <generic_kprobe_process_event+0xe91>
     38e:      	movq	%rax, %r14
     391:      	movl	0x5efc(%rax), %r12d
     398:      	movl	0x4(%rax), %ebp
     39b:      	cmpq	$0x2327, %rbp           # imm = 0x2327
     3a2:      	ja	0x1142 <generic_kprobe_process_event+0xdf2>
     3a8:      	movl	$0x0, 0xf8(%rsp)
     3b3:      	movq	(%rip), %rdi            # 0x3ba <generic_kprobe_process_event+0x6a>
     3ba:      	leaq	0xf8(%rsp), %rsi
     3c2:      	movl	$0x1, %eax
     3c7:      	callq	*%rax
     3c9:      	testq	%rax, %rax
     3cc:      	je	0x1142 <generic_kprobe_process_event+0xdf2>
     3d2:      	movq	%rax, %r15
     3d5:      	leaq	0x5ef8(%rax), %rsi
     3dc:      	movq	(%rip), %rdi            # 0x3e3 <generic_kprobe_process_event+0x93>
     3e3:      	movl	$0x1, %eax
     3e8:      	callq	*%rax
     3ea:      	cmpl	$0x4, %r12d
     3ee:      	jg	0x1142 <generic_kprobe_process_event+0xdf2>
     3f4:      	testq	%rax, %rax
     3f7:      	je	0x1142 <generic_kprobe_process_event+0xdf2>
     3fd:      	movl	%r12d, %esi
     400:      	andl	$0x7, %esi
     403:      	movl	%esi, %ecx
     405:      	movl	0x4(%rax,%rcx,4), %r13d
     40a:      	movslq	0x18(%rax,%rcx,4), %rdi
     40f:      	movl	%edi, %r8d
     412:      	movl	$0x0, 0x5ea0(%r15,%rcx,4)
     41e:      	testl	$0x100, %edi            # imm = 0x100
     424:      	movq	%rbp, 0xc8(%rsp)
     42c:      	movq	%rsi, 0x20(%rsp)
     431:      	movq	%r12, 0x100(%rsp)
     439:      	jne	0x45e <generic_kprobe_process_event+0x10e>
     43b:      	testb	%dil, %dil
     43e:      	js	0x46c <generic_kprobe_process_event+0x11c>
     440:      	testb	$0x40, %r8b
     444:      	jne	0x4f3 <generic_kprobe_process_event+0x1a3>
     44a:      	movl	0x40(%rax,%rsi,4), %ecx
     44e:      	andl	$0x7, %ecx
     451:      	movq	0x5e50(%r15,%rcx,8), %rcx
     459:      	jmp	0x575 <generic_kprobe_process_event+0x225>
     45e:      	movq	$0x0, 0x8(%rsp)
     467:      	jmp	0xd21 <generic_kprobe_process_event+0x9d1>
     46c:      	movzbl	0x2c2(%rax,%rsi,4), %ecx
     474:      	shlb	$0x3, %cl
     477:      	movb	$0x40, %r9b
     47a:      	subb	%cl, %r9b
     47d:      	cmpl	$0x0, 0x54(%rax)
     481:      	movzwl	0x2c0(%rax,%rsi,4), %edx
     489:      	je	0x526 <generic_kprobe_process_event+0x1d6>
     48f:      	testq	%rbx, %rbx
     492:      	je	0x573 <generic_kprobe_process_event+0x223>
     498:      	addq	%rbx, %rdx
     49b:      	movq	%r13, 0x30(%rsp)
     4a0:      	movq	%rdi, 0x10(%rsp)
     4a5:      	leaq	0x50(%rsp), %rdi
     4aa:      	movl	$0x8, %ecx
     4af:      	movq	%rax, %r12
     4b2:      	movl	$0x4, %eax
     4b7:      	movl	$0x8, %esi
     4bc:      	movq	%r14, %rbp
     4bf:      	movq	%r8, %r14
     4c2:      	movq	%r9, %r13
     4c5:      	callq	*%rax
     4c7:      	movq	%r14, %r8
     4ca:      	movq	%rbp, %r14
     4cd:      	movq	0x10(%rsp), %rdi
     4d2:      	movq	0x30(%rsp), %rdx
     4d7:      	movq	0x20(%rsp), %rsi
     4dc:      	movq	%r12, %rax
     4df:      	shlxq	%r13, 0x50(%rsp), %rcx
     4e6:      	sarxq	%r13, %rcx, %rcx
     4eb:      	movq	%rdx, %r13
     4ee:      	jmp	0x575 <generic_kprobe_process_event+0x225>
     4f3:      	movq	%rax, 0x30(%rsp)
     4f8:      	movl	$0x23, %eax
     4fd:      	movq	%r13, %rbp
     500:      	movq	%rdi, %r13
     503:      	movq	%r14, %r12
     506:      	movq	%r8, %r14
     509:      	callq	*%rax
     50b:      	movq	%r14, %r8
     50e:      	movq	%r12, %r14
     511:      	movq	%r13, %rdi
     514:      	movq	%rbp, %r13
     517:      	movq	0x20(%rsp), %rsi
     51c:      	movq	%rax, %rcx
     51f:      	movq	0x30(%rsp), %rax
     524:      	jmp	0x575 <generic_kprobe_process_event+0x225>
     526:      	rorxl	$0x3, %edx, %edx
     52c:      	xorl	%ecx, %ecx
     52e:      	cmpl	$0x7, %edx
     531:      	jle	0xfd0 <generic_kprobe_process_event+0xc80>
     537:      	cmpl	$0xb, %edx
     53a:      	jle	0x11f5 <generic_kprobe_process_event+0xea5>
     540:      	cmpl	$0xd, %edx
     543:      	jle	0x1340 <generic_kprobe_process_event+0xff0>
     549:      	cmpl	$0xe, %edx
     54c:      	je	0x145f <generic_kprobe_process_event+0x110f>
     552:      	cmpl	$0x10, %edx
     555:      	je	0x13fe <generic_kprobe_process_event+0x10ae>
     55b:      	cmpl	$0x13, %edx
     55e:      	jne	0x575 <generic_kprobe_process_event+0x225>
     560:      	movl	$0x40, %ecx
     565:      	subl	%r9d, %ecx
     568:      	bzhiq	%rcx, 0x98(%rbx), %rcx
     571:      	jmp	0x575 <generic_kprobe_process_event+0x225>
     573:      	xorl	%ecx, %ecx
     575:      	movq	%rcx, 0x8(%rsp)
     57a:      	cmpl	$0x4, %esi
     57d:      	ja	0xd21 <generic_kprobe_process_event+0x9d1>
     583:      	leaq	(%rsi,%rsi,4), %rdx
     587:      	shll	$0x4, %edx
     58a:      	cmpw	$0x0, 0x76(%rax,%rdx)
     590:      	je	0xd21 <generic_kprobe_process_event+0x9d1>
     596:      	leaq	(%rax,%rdx), %rsi
     59a:      	addq	$0x70, %rsi
     59e:      	movq	(%rip), %rax            # 0x5a5 <generic_kprobe_process_event+0x255>
     5a5:      	movzbl	(%rax), %edx
     5a8:      	movl	(%rsi), %eax
     5aa:      	addq	%rax, %rcx
     5ad:      	movq	%rcx, 0x8(%rsp)
     5b2:      	movzwl	0x4(%rsi), %eax
     5b6:      	testb	%dl, %dl
     5b8:      	movq	%rdi, 0x10(%rsp)
     5bd:      	je	0x962 <generic_kprobe_process_event+0x612>
     5c3:      	testw	%ax, %ax
     5c6:      	je	0x60c <generic_kprobe_process_event+0x2bc>
     5c8:      	leaq	0x8(%rsp), %rdi
     5cd:      	movl	$0x8, %edx
     5d2:      	movl	$0x4, %eax
     5d7:      	movq	0x8(%rsp), %rdx
     5dc:      	movq	%rsi, %r12
     5df:      	movl	$0x8, %esi
     5e4:      	movq	%r14, %rbp
     5e7:      	movq	%r8, %r14
     5ea:      	callq	*%rax
     5ec:      	movq	%r12, %rsi
     5ef:      	movq	%r14, %r8
     5f2:      	movq	%rbp, %r14
     5f5:      	movq	0x10(%rsp), %rdi
     5fa:      	movq	0x20(%rsp), %rcx
     5ff:      	movl	$0x1, %ebp
     604:      	testl	%eax, %eax
     606:      	js	0xd19 <generic_kprobe_process_event+0x9c9>
     60c:      	cmpw	$0x0, 0xe(%rsi)
     611:      	je	0xd21 <generic_kprobe_process_event+0x9d1>
     617:      	movl	0x8(%rsi), %ecx
     61a:      	addq	0x8(%rsp), %rcx
     61f:      	movq	%rcx, 0x8(%rsp)
     624:      	cmpw	$0x0, 0xc(%rsi)
     629:      	je	0x66f <generic_kprobe_process_event+0x31f>
     62b:      	leaq	0x8(%rsp), %rdi
     630:      	movl	$0x8, %edx
     635:      	movl	$0x4, %eax
     63a:      	movq	0x8(%rsp), %rdx
     63f:      	movq	%rsi, %r12
     642:      	movl	$0x8, %esi
     647:      	movq	%r14, %rbp
     64a:      	movq	%r8, %r14
     64d:      	callq	*%rax
     64f:      	movq	%r12, %rsi
     652:      	movq	%r14, %r8
     655:      	movq	%rbp, %r14
     658:      	movq	0x10(%rsp), %rdi
     65d:      	movq	0x20(%rsp), %rcx
     662:      	movl	$0x2, %ebp
     667:      	testl	%eax, %eax
     669:      	js	0xd19 <generic_kprobe_process_event+0x9c9>
     66f:      	cmpw	$0x0, 0x16(%rsi)
     674:      	je	0xd21 <generic_kprobe_process_event+0x9d1>
     67a:      	movl	0x10(%rsi), %ecx
     67d:      	addq	0x8(%rsp), %rcx
     682:      	movq	%rcx, 0x8(%rsp)
     687:      	cmpw	$0x0, 0x14(%rsi)
     68c:      	je	0x6d2 <generic_kprobe_process_event+0x382>
     68e:      	leaq	0x8(%rsp), %rdi
     693:      	movl	$0x8, %edx
     698:      	movl	$0x4, %eax
     69d:      	movq	0x8(%rsp), %rdx
     6a2:      	movq	%rsi, %r12
     6a5:      	movl	$0x8, %esi
     6aa:      	movq	%r14, %rbp
     6ad:      	movq	%r8, %r14
     6b0:      	callq	*%rax
     6b2:      	movq	%r12, %rsi
     6b5:      	movq	%r14, %r8
     6b8:      	movq	%rbp, %r14
     6bb:      	movq	0x10(%rsp), %rdi
     6c0:      	movq	0x20(%rsp), %rcx
     6c5:      	movl	$0x3, %ebp
     6ca:      	testl	%eax, %eax
     6cc:      	js	0xd19 <generic_kprobe_process_event+0x9c9>
     6d2:      	cmpw	$0x0, 0x1e(%rsi)
     6d7:      	je	0xd21 <generic_kprobe_process_event+0x9d1>
     6dd:      	movl	0x18(%rsi), %ecx
     6e0:      	addq	0x8(%rsp), %rcx
     6e5:      	movq	%rcx, 0x8(%rsp)
     6ea:      	cmpw	$0x0, 0x1c(%rsi)
     6ef:      	je	0x735 <generic_kprobe_process_event+0x3e5>
     6f1:      	leaq	0x8(%rsp), %rdi
     6f6:      	movl	$0x8, %edx
     6fb:      	movl	$0x4, %eax
     700:      	movq	0x8(%rsp), %rdx
     705:      	movq	%rsi, %r12
     708:      	movl	$0x8, %esi
     70d:      	movq	%r14, %rbp
     710:      	movq	%r8, %r14
     713:      	callq	*%rax
     715:      	movq	%r12, %rsi
     718:      	movq	%r14, %r8
     71b:      	movq	%rbp, %r14
     71e:      	movq	0x10(%rsp), %rdi
     723:      	movq	0x20(%rsp), %rcx
     728:      	movl	$0x4, %ebp
     72d:      	testl	%eax, %eax
     72f:      	js	0xd19 <generic_kprobe_process_event+0x9c9>
     735:      	cmpw	$0x0, 0x26(%rsi)
     73a:      	je	0xd21 <generic_kprobe_process_event+0x9d1>
     740:      	movl	0x20(%rsi), %ecx
     743:      	addq	0x8(%rsp), %rcx
     748:      	movq	%rcx, 0x8(%rsp)
     74d:      	cmpw	$0x0, 0x24(%rsi)
     752:      	je	0x798 <generic_kprobe_process_event+0x448>
     754:      	leaq	0x8(%rsp), %rdi
     759:      	movl	$0x8, %edx
     75e:      	movl	$0x4, %eax
     763:      	movq	0x8(%rsp), %rdx
     768:      	movq	%rsi, %r12
     76b:      	movl	$0x8, %esi
     770:      	movq	%r14, %rbp
     773:      	movq	%r8, %r14
     776:      	callq	*%rax
     778:      	movq	%r12, %rsi
     77b:      	movq	%r14, %r8
     77e:      	movq	%rbp, %r14
     781:      	movq	0x10(%rsp), %rdi
     786:      	movq	0x20(%rsp), %rcx
     78b:      	movl	$0x5, %ebp
     790:      	testl	%eax, %eax
     792:      	js	0xd19 <generic_kprobe_process_event+0x9c9>
     798:      	cmpw	$0x0, 0x2e(%rsi)
     79d:      	je	0xd21 <generic_kprobe_process_event+0x9d1>
     7a3:      	movl	0x28(%rsi), %ecx
     7a6:      	addq	0x8(%rsp), %rcx
     7ab:      	movq	%rcx, 0x8(%rsp)
     7b0:      	cmpw	$0x0, 0x2c(%rsi)
     7b5:      	je	0x7fb <generic_kprobe_process_event+0x4ab>
     7b7:      	leaq	0x8(%rsp), %rdi
     7bc:      	movl	$0x8, %edx
     7c1:      	movl	$0x4, %eax
     7c6:      	movq	0x8(%rsp), %rdx
     7cb:      	movq	%rsi, %r12
     7ce:      	movl	$0x8, %esi
     7d3:      	movq	%r14, %rbp
     7d6:      	movq	%r8, %r14
     7d9:      	callq	*%rax
     7db:      	movq	%r12, %rsi
     7de:      	movq	%r14, %r8
     7e1:      	movq	%rbp, %r14
     7e4:      	movq	0x10(%rsp), %rdi
     7e9:      	movq	0x20(%rsp), %rcx
     7ee:      	movl	$0x6, %ebp
     7f3:      	testl	%eax, %eax
     7f5:      	js	0xd19 <generic_kprobe_process_event+0x9c9>
     7fb:      	cmpw	$0x0, 0x36(%rsi)
     800:      	je	0xd21 <generic_kprobe_process_event+0x9d1>
     806:      	movl	0x30(%rsi), %ecx
     809:      	addq	0x8(%rsp), %rcx
     80e:      	movq	%rcx, 0x8(%rsp)
     813:      	cmpw	$0x0, 0x34(%rsi)
     818:      	je	0x85e <generic_kprobe_process_event+0x50e>
     81a:      	leaq	0x8(%rsp), %rdi
     81f:      	movl	$0x8, %edx
     824:      	movl	$0x4, %eax
     829:      	movq	0x8(%rsp), %rdx
     82e:      	movq	%rsi, %r12
     831:      	movl	$0x8, %esi
     836:      	movq	%r14, %rbp
     839:      	movq	%r8, %r14
     83c:      	callq	*%rax
     83e:      	movq	%r12, %rsi
     841:      	movq	%r14, %r8
     844:      	movq	%rbp, %r14
     847:      	movq	0x10(%rsp), %rdi
     84c:      	movq	0x20(%rsp), %rcx
     851:      	movl	$0x7, %ebp
     856:      	testl	%eax, %eax
     858:      	js	0xd19 <generic_kprobe_process_event+0x9c9>
     85e:      	cmpw	$0x0, 0x3e(%rsi)
     863:      	je	0xd21 <generic_kprobe_process_event+0x9d1>
     869:      	movl	0x38(%rsi), %ecx
     86c:      	addq	0x8(%rsp), %rcx
     871:      	movq	%rcx, 0x8(%rsp)
     876:      	cmpw	$0x0, 0x3c(%rsi)
     87b:      	je	0x8c5 <generic_kprobe_process_event+0x575>
     87d:      	leaq	0x8(%rsp), %rdi
     882:      	movl	$0x8, %edx
     887:      	movl	$0x4, %eax
     88c:      	movq	0x8(%rsp), %rdx
     891:      	movl	$0x8, %ebp
     896:      	movq	%rsi, 0x30(%rsp)
     89b:      	movl	$0x8, %esi
     8a0:      	movq	%r14, %r12
     8a3:      	movq	%r8, %r14
     8a6:      	callq	*%rax
     8a8:      	movq	0x30(%rsp), %rsi
     8ad:      	movq	%r14, %r8
     8b0:      	movq	%r12, %r14
     8b3:      	movq	0x10(%rsp), %rdi
     8b8:      	movq	0x20(%rsp), %rcx
     8bd:      	testl	%eax, %eax
     8bf:      	js	0xd19 <generic_kprobe_process_event+0x9c9>
     8c5:      	cmpw	$0x0, 0x46(%rsi)
     8ca:      	je	0xd21 <generic_kprobe_process_event+0x9d1>
     8d0:      	movl	0x40(%rsi), %ecx
     8d3:      	addq	0x8(%rsp), %rcx
     8d8:      	movq	%rcx, 0x8(%rsp)
     8dd:      	cmpw	$0x0, 0x44(%rsi)
     8e2:      	je	0x928 <generic_kprobe_process_event+0x5d8>
     8e4:      	leaq	0x8(%rsp), %rdi
     8e9:      	movl	$0x8, %edx
     8ee:      	movl	$0x4, %eax
     8f3:      	movq	0x8(%rsp), %rdx
     8f8:      	movq	%rsi, %r12
     8fb:      	movl	$0x8, %esi
     900:      	movq	%r14, %rbp
     903:      	movq	%r8, %r14
     906:      	callq	*%rax
     908:      	movq	%r12, %rsi
     90b:      	movq	%r14, %r8
     90e:      	movq	%rbp, %r14
     911:      	movq	0x10(%rsp), %rdi
     916:      	movq	0x20(%rsp), %rcx
     91b:      	movl	$0x9, %ebp
     920:      	testl	%eax, %eax
     922:      	js	0xd19 <generic_kprobe_process_event+0x9c9>
     928:      	cmpw	$0x0, 0x4e(%rsi)
     92d:      	je	0xd21 <generic_kprobe_process_event+0x9d1>
     933:      	movl	0x48(%rsi), %ecx
     936:      	addq	0x8(%rsp), %rcx
     93b:      	movq	%rcx, 0x8(%rsp)
     940:      	cmpw	$0x0, 0x4c(%rsi)
     945:      	je	0xd21 <generic_kprobe_process_event+0x9d1>
     94b:      	movq	%rdi, %r12
     94e:      	leaq	0x8(%rsp), %rdi
     953:      	movl	$0x8, %edx
     958:      	movl	$0x4, %eax
     95d:      	jmp	0xcf0 <generic_kprobe_process_event+0x9a0>
     962:      	testw	%ax, %ax
     965:      	je	0x9ab <generic_kprobe_process_event+0x65b>
     967:      	leaq	0x8(%rsp), %rdi
     96c:      	movl	$0x8, %edx
     971:      	movl	$0x4, %eax
     976:      	movq	0x8(%rsp), %rdx
     97b:      	movq	%rsi, %r12
     97e:      	movl	$0x8, %esi
     983:      	movq	%r14, %rbp
     986:      	movq	%r8, %r14
     989:      	callq	*%rax
     98b:      	movq	%r12, %rsi
     98e:      	movq	%r14, %r8
     991:      	movq	%rbp, %r14
     994:      	movq	0x10(%rsp), %rdi
     999:      	movq	0x20(%rsp), %rcx
     99e:      	movl	$0x1, %ebp
     9a3:      	testl	%eax, %eax
     9a5:      	js	0xd19 <generic_kprobe_process_event+0x9c9>
     9ab:      	cmpw	$0x0, 0xe(%rsi)
     9b0:      	je	0xd21 <generic_kprobe_process_event+0x9d1>
     9b6:      	movl	0x8(%rsi), %ecx
     9b9:      	addq	0x8(%rsp), %rcx
     9be:      	movq	%rcx, 0x8(%rsp)
     9c3:      	cmpw	$0x0, 0xc(%rsi)
     9c8:      	je	0xa0e <generic_kprobe_process_event+0x6be>
     9ca:      	leaq	0x8(%rsp), %rdi
     9cf:      	movl	$0x8, %edx
     9d4:      	movl	$0x4, %eax
     9d9:      	movq	0x8(%rsp), %rdx
     9de:      	movq	%rsi, %r12
     9e1:      	movl	$0x8, %esi
     9e6:      	movq	%r14, %rbp
     9e9:      	movq	%r8, %r14
     9ec:      	callq	*%rax
     9ee:      	movq	%r12, %rsi
     9f1:      	movq	%r14, %r8
     9f4:      	movq	%rbp, %r14
     9f7:      	movq	0x10(%rsp), %rdi
     9fc:      	movq	0x20(%rsp), %rcx
     a01:      	movl	$0x2, %ebp
     a06:      	testl	%eax, %eax
     a08:      	js	0xd19 <generic_kprobe_process_event+0x9c9>
     a0e:      	cmpw	$0x0, 0x16(%rsi)
     a13:      	je	0xd21 <generic_kprobe_process_event+0x9d1>
     a19:      	movl	0x10(%rsi), %ecx
     a1c:      	addq	0x8(%rsp), %rcx
     a21:      	movq	%rcx, 0x8(%rsp)
     a26:      	cmpw	$0x0, 0x14(%rsi)
     a2b:      	je	0xa71 <generic_kprobe_process_event+0x721>
     a2d:      	leaq	0x8(%rsp), %rdi
     a32:      	movl	$0x8, %edx
     a37:      	movl	$0x4, %eax
     a3c:      	movq	0x8(%rsp), %rdx
     a41:      	movq	%rsi, %r12
     a44:      	movl	$0x8, %esi
     a49:      	movq	%r14, %rbp
     a4c:      	movq	%r8, %r14
     a4f:      	callq	*%rax
     a51:      	movq	%r12, %rsi
     a54:      	movq	%r14, %r8
     a57:      	movq	%rbp, %r14
     a5a:      	movq	0x10(%rsp), %rdi
     a5f:      	movq	0x20(%rsp), %rcx
     a64:      	movl	$0x3, %ebp
     a69:      	testl	%eax, %eax
     a6b:      	js	0xd19 <generic_kprobe_process_event+0x9c9>
     a71:      	cmpw	$0x0, 0x1e(%rsi)
     a76:      	je	0xd21 <generic_kprobe_process_event+0x9d1>
     a7c:      	movl	0x18(%rsi), %ecx
     a7f:      	addq	0x8(%rsp), %rcx
     a84:      	movq	%rcx, 0x8(%rsp)
     a89:      	cmpw	$0x0, 0x1c(%rsi)
     a8e:      	je	0xad4 <generic_kprobe_process_event+0x784>
     a90:      	leaq	0x8(%rsp), %rdi
     a95:      	movl	$0x8, %edx
     a9a:      	movl	$0x4, %eax
     a9f:      	movq	0x8(%rsp), %rdx
     aa4:      	movq	%rsi, %r12
     aa7:      	movl	$0x8, %esi
     aac:      	movq	%r14, %rbp
     aaf:      	movq	%r8, %r14
     ab2:      	callq	*%rax
     ab4:      	movq	%r12, %rsi
     ab7:      	movq	%r14, %r8
     aba:      	movq	%rbp, %r14
     abd:      	movq	0x10(%rsp), %rdi
     ac2:      	movq	0x20(%rsp), %rcx
     ac7:      	movl	$0x4, %ebp
     acc:      	testl	%eax, %eax
     ace:      	js	0xd19 <generic_kprobe_process_event+0x9c9>
     ad4:      	cmpw	$0x0, 0x26(%rsi)
     ad9:      	je	0xd21 <generic_kprobe_process_event+0x9d1>
     adf:      	movl	0x20(%rsi), %ecx
     ae2:      	addq	0x8(%rsp), %rcx
     ae7:      	movq	%rcx, 0x8(%rsp)
     aec:      	cmpw	$0x0, 0x24(%rsi)
     af1:      	je	0xb37 <generic_kprobe_process_event+0x7e7>
     af3:      	leaq	0x8(%rsp), %rdi
     af8:      	movl	$0x8, %edx
     afd:      	movl	$0x4, %eax
     b02:      	movq	0x8(%rsp), %rdx
     b07:      	movq	%rsi, %r12
     b0a:      	movl	$0x8, %esi
     b0f:      	movq	%r14, %rbp
     b12:      	movq	%r8, %r14
     b15:      	callq	*%rax
     b17:      	movq	%r12, %rsi
     b1a:      	movq	%r14, %r8
     b1d:      	movq	%rbp, %r14
     b20:      	movq	0x10(%rsp), %rdi
     b25:      	movq	0x20(%rsp), %rcx
     b2a:      	movl	$0x5, %ebp
     b2f:      	testl	%eax, %eax
     b31:      	js	0xd19 <generic_kprobe_process_event+0x9c9>
     b37:      	cmpw	$0x0, 0x2e(%rsi)
     b3c:      	je	0xd21 <generic_kprobe_process_event+0x9d1>
     b42:      	movl	0x28(%rsi), %ecx
     b45:      	addq	0x8(%rsp), %rcx
     b4a:      	movq	%rcx, 0x8(%rsp)
     b4f:      	cmpw	$0x0, 0x2c(%rsi)
     b54:      	je	0xb9a <generic_kprobe_process_event+0x84a>
     b56:      	leaq	0x8(%rsp), %rdi
     b5b:      	movl	$0x8, %edx
     b60:      	movl	$0x4, %eax
     b65:      	movq	0x8(%rsp), %rdx
     b6a:      	movq	%rsi, %r12
     b6d:      	movl	$0x8, %esi
     b72:      	movq	%r14, %rbp
     b75:      	movq	%r8, %r14
     b78:      	callq	*%rax
     b7a:      	movq	%r12, %rsi
     b7d:      	movq	%r14, %r8
     b80:      	movq	%rbp, %r14
     b83:      	movq	0x10(%rsp), %rdi
     b88:      	movq	0x20(%rsp), %rcx
     b8d:      	movl	$0x6, %ebp
     b92:      	testl	%eax, %eax
     b94:      	js	0xd19 <generic_kprobe_process_event+0x9c9>
     b9a:      	cmpw	$0x0, 0x36(%rsi)
     b9f:      	je	0xd21 <generic_kprobe_process_event+0x9d1>
     ba5:      	movl	0x30(%rsi), %ecx
     ba8:      	addq	0x8(%rsp), %rcx
     bad:      	movq	%rcx, 0x8(%rsp)
     bb2:      	cmpw	$0x0, 0x34(%rsi)
     bb7:      	je	0xbfd <generic_kprobe_process_event+0x8ad>
     bb9:      	leaq	0x8(%rsp), %rdi
     bbe:      	movl	$0x8, %edx
     bc3:      	movl	$0x4, %eax
     bc8:      	movq	0x8(%rsp), %rdx
     bcd:      	movq	%rsi, %r12
     bd0:      	movl	$0x8, %esi
     bd5:      	movq	%r14, %rbp
     bd8:      	movq	%r8, %r14
     bdb:      	callq	*%rax
     bdd:      	movq	%r12, %rsi
     be0:      	movq	%r14, %r8
     be3:      	movq	%rbp, %r14
     be6:      	movq	0x10(%rsp), %rdi
     beb:      	movq	0x20(%rsp), %rcx
     bf0:      	movl	$0x7, %ebp
     bf5:      	testl	%eax, %eax
     bf7:      	js	0xd19 <generic_kprobe_process_event+0x9c9>
     bfd:      	cmpw	$0x0, 0x3e(%rsi)
     c02:      	je	0xd21 <generic_kprobe_process_event+0x9d1>
     c08:      	movl	0x38(%rsi), %ecx
     c0b:      	addq	0x8(%rsp), %rcx
     c10:      	movq	%rcx, 0x8(%rsp)
     c15:      	cmpw	$0x0, 0x3c(%rsi)
     c1a:      	je	0xc64 <generic_kprobe_process_event+0x914>
     c1c:      	leaq	0x8(%rsp), %rdi
     c21:      	movl	$0x8, %edx
     c26:      	movl	$0x4, %eax
     c2b:      	movq	0x8(%rsp), %rdx
     c30:      	movl	$0x8, %ebp
     c35:      	movq	%rsi, 0x30(%rsp)
     c3a:      	movl	$0x8, %esi
     c3f:      	movq	%r14, %r12
     c42:      	movq	%r8, %r14
     c45:      	callq	*%rax
     c47:      	movq	0x30(%rsp), %rsi
     c4c:      	movq	%r14, %r8
     c4f:      	movq	%r12, %r14
     c52:      	movq	0x10(%rsp), %rdi
     c57:      	movq	0x20(%rsp), %rcx
     c5c:      	testl	%eax, %eax
     c5e:      	js	0xd19 <generic_kprobe_process_event+0x9c9>
     c64:      	cmpw	$0x0, 0x46(%rsi)
     c69:      	je	0xd21 <generic_kprobe_process_event+0x9d1>
     c6f:      	movl	0x40(%rsi), %ecx
     c72:      	addq	0x8(%rsp), %rcx
     c77:      	movq	%rcx, 0x8(%rsp)
     c7c:      	cmpw	$0x0, 0x44(%rsi)
     c81:      	je	0xcc3 <generic_kprobe_process_event+0x973>
     c83:      	leaq	0x8(%rsp), %rdi
     c88:      	movl	$0x8, %edx
     c8d:      	movl	$0x4, %eax
     c92:      	movq	0x8(%rsp), %rdx
     c97:      	movq	%rsi, %r12
     c9a:      	movl	$0x8, %esi
     c9f:      	movq	%r14, %rbp
     ca2:      	movq	%r8, %r14
     ca5:      	callq	*%rax
     ca7:      	movq	%r12, %rsi
     caa:      	movq	%r14, %r8
     cad:      	movq	%rbp, %r14
     cb0:      	movq	0x10(%rsp), %rdi
     cb5:      	movq	0x20(%rsp), %rcx
     cba:      	movl	$0x9, %ebp
     cbf:      	testl	%eax, %eax
     cc1:      	js	0xd19 <generic_kprobe_process_event+0x9c9>
     cc3:      	cmpw	$0x0, 0x4e(%rsi)
     cc8:      	je	0xd21 <generic_kprobe_process_event+0x9d1>
     cca:      	movl	0x48(%rsi), %ecx
     ccd:      	addq	0x8(%rsp), %rcx
     cd2:      	movq	%rcx, 0x8(%rsp)
     cd7:      	cmpw	$0x0, 0x4c(%rsi)
     cdc:      	je	0xd21 <generic_kprobe_process_event+0x9d1>
     cde:      	movq	%rdi, %r12
     ce1:      	leaq	0x8(%rsp), %rdi
     ce6:      	movl	$0x8, %edx
     ceb:      	movl	$0x4, %eax
     cf0:      	movq	0x8(%rsp), %rdx
     cf5:      	movl	$0x8, %esi
     cfa:      	movq	%r14, %rbp
     cfd:      	movq	%r8, %r14
     d00:      	callq	*%rax
     d02:      	movq	%r14, %r8
     d05:      	movq	%rbp, %r14
     d08:      	movq	%r12, %rdi
     d0b:      	movq	0x20(%rsp), %rcx
     d10:      	movl	$0xa, %ebp
     d15:      	testl	%eax, %eax
     d17:      	jns	0xd21 <generic_kprobe_process_event+0x9d1>
     d19:      	movl	%ebp, 0x5ea0(%r15,%rcx,4)
     d21:      	movl	%r13d, %ebp
     d24:      	cmpl	$0x2a, %r13d
     d28:      	ja	0xf1f <generic_kprobe_process_event+0xbcf>
     d2e:      	movabsq	$0x42001018000, %rax    # imm = 0x42001018000
     d38:      	btq	%rbp, %rax
     d3c:      	jae	0xf1f <generic_kprobe_process_event+0xbcf>
     d42:      	movq	0x8(%rsp), %rbp
     d47:      	movl	$0x0, 0x38(%rsp)
     d4f:      	movq	(%rip), %rdi            # 0xd56 <generic_kprobe_process_event+0xa06>
     d56:      	leaq	0x38(%rsp), %rsi
     d5b:      	movl	$0x1, %eax
     d60:      	callq	*%rax
     d62:      	testq	%rax, %rax
     d65:      	je	0x112f <generic_kprobe_process_event+0xddf>
     d6b:      	movq	%rax, %r12
     d6e:      	cmpl	$0x0, 0x6420(%rax)
     d75:      	je	0xec4 <generic_kprobe_process_event+0xb74>
     d7b:      	movl	$0x0, 0x6420(%r12)
     d87:      	movq	(%rip), %rdi            # 0xd8e <generic_kprobe_process_event+0xa3e>
     d8e:      	leaq	0x38(%rsp), %rsi
     d93:      	movl	$0x1, %eax
     d98:      	callq	*%rax
     d9a:      	testq	%rax, %rax
     d9d:      	je	0x112f <generic_kprobe_process_event+0xddf>
     da3:      	movq	%rax, %rdx
     da6:      	movq	0x20(%rsp), %rcx
     dab:      	movl	0x5ea0(%r12,%rcx,4), %eax
     db3:      	movq	0xc8(%rsp), %rbp
     dbb:      	movl	%eax, 0x90(%r12,%rbp)
     dc3:      	addq	$0x4, %rbp
     dc7:      	movq	%rbp, 0x5e78(%r12,%rcx,8)
     dcf:      	movl	$0x4, %esi
     dd4:      	testl	%eax, %eax
     dd6:      	jne	0x1131 <generic_kprobe_process_event+0xde1>
     ddc:      	movq	%r12, %r15
     ddf:      	addq	$0x90, %r15
     de6:      	movl	0x6424(%r12), %eax
     dee:      	movq	%rbx, 0x18(%rsp)
     df3:      	movl	$0xfff, %ebx            # imm = 0xFFF
     df8:      	subl	%eax, %ebx
     dfa:      	andl	$0xfff, %eax            # imm = 0xFFF
     dff:      	addq	%rax, %rdx
     e02:      	movq	0x6440(%r12), %r13
     e0a:      	leaq	(%r15,%rbp), %rdi
     e0e:      	addq	$0x4, %rdi
     e12:      	andl	$0xfff, %ebx            # imm = 0xFFF
     e18:      	movl	$0x4, %eax
     e1d:      	addq	%rbp, %r15
     e20:      	movl	%ebx, %esi
     e22:      	callq	*%rax
     e24:      	movl	%ebx, 0x90(%r12,%rbp)
     e2c:      	addq	$0x8, %r13
     e30:      	leaq	0x50(%rsp), %rdi
     e35:      	movl	$0x8, %ecx
     e3a:      	movl	$0x4, %eax
     e3f:      	movl	$0x8, %esi
     e44:      	movq	%r13, %rdx
     e47:      	callq	*%rax
     e49:      	movq	0x50(%rsp), %rcx
     e4e:      	addq	$0x30, %rcx
     e52:      	leaq	0x90(%rsp), %rdi
     e5a:      	movl	$0x8, %edx
     e5f:      	movl	$0x4, %eax
     e64:      	movq	0x50(%rsp), %rdx
     e69:      	addq	$0x30, %rdx
     e6d:      	movl	$0x8, %esi
     e72:      	callq	*%rax
     e74:      	movq	0x90(%rsp), %rcx
     e7c:      	leaq	0xb0(%rsp), %rdi
     e84:      	movl	$0x2, %edx
     e89:      	movl	$0x4, %eax
     e8e:      	movq	0x90(%rsp), %rdx
     e96:      	movl	$0x2, %esi
     e9b:      	callq	*%rax
     e9d:      	movq	%rbx, %rsi
     ea0:      	movq	0x18(%rsp), %rbx
     ea5:      	movl	$0x0, 0x4(%rsi,%r15)
     eae:      	movzwl	0xb0(%rsp), %eax
     eb6:      	movw	%ax, 0x8(%rsi,%r15)
     ebc:      	addl	$0xe, %esi
     ebf:      	jmp	0x1131 <generic_kprobe_process_event+0xde1>
     ec4:      	movq	%rbp, 0x50(%rsp)
     ec9:      	movq	$0x0, 0x90(%rsp)
     ed5:      	cmpl	$0x17, %r13d
     ed9:      	jle	0xfaf <generic_kprobe_process_event+0xc5f>
     edf:      	cmpl	$0x18, %r13d
     ee3:      	je	0x1063 <generic_kprobe_process_event+0xd13>
     ee9:      	cmpl	$0x25, %r13d
     eed:      	je	0x10aa <generic_kprobe_process_event+0xd5a>
     ef3:      	cmpl	$0x2a, %r13d
     ef7:      	jne	0x112f <generic_kprobe_process_event+0xddf>
     efd:      	movq	%r12, %rax
     f00:      	addq	$0x6430, %rax           # imm = 0x6430
     f06:      	movq	$0x0, 0x6430(%r12)
     f12:      	movq	%rbp, 0x6438(%r12)
     f1a:      	jmp	0x10dd <generic_kprobe_process_event+0xd8d>
     f1f:      	movq	0x8(%rsp), %r12
     f24:      	cmpl	$0x15, %r13d
     f28:      	movq	%r8, 0xa0(%rsp)
     f30:      	jg	0xf7f <generic_kprobe_process_event+0xc2f>
     f32:      	movl	$0x1000, %r15d          # imm = 0x1000
     f38:      	cmpl	$0x9, %r13d
     f3c:      	jle	0x1006 <generic_kprobe_process_event+0xcb6>
     f42:      	cmpl	$0x10, %r13d
     f46:      	jle	0x1251 <generic_kprobe_process_event+0xf01>
     f4c:      	cmpl	$0x12, %r13d
     f50:      	jle	0x1396 <generic_kprobe_process_event+0x1046>
     f56:      	cmpl	$0x13, %r13d
     f5a:      	je	0x138b <generic_kprobe_process_event+0x103b>
     f60:      	cmpl	$0x14, %r13d
     f64:      	je	0x1485 <generic_kprobe_process_event+0x1135>
     f6a:      	cmpl	$0x15, %r13d
     f6e:      	jne	0x1497 <generic_kprobe_process_event+0x1147>
     f74:      	movl	$0x20, %r15d
     f7a:      	jmp	0x149a <generic_kprobe_process_event+0x114a>
     f7f:      	cmpl	$0x20, %r13d
     f83:      	jle	0x1036 <generic_kprobe_process_event+0xce6>
     f89:      	cmpl	$0x27, %r13d
     f8d:      	jg	0x1273 <generic_kprobe_process_event+0xf23>
     f93:      	leal	-0x21(%r13), %eax
     f97:      	cmpl	$0x4, %eax
     f9a:      	jb	0x1268 <generic_kprobe_process_event+0xf18>
     fa0:      	cmpl	$0x27, %r13d
     fa4:      	je	0x1365 <generic_kprobe_process_event+0x1015>
     faa:      	jmp	0x1497 <generic_kprobe_process_event+0x1147>
     faf:      	cmpl	$0xf, %r13d
     fb3:      	je	0x1104 <generic_kprobe_process_event+0xdb4>
     fb9:      	cmpl	$0x10, %r13d
     fbd:      	jne	0x112f <generic_kprobe_process_event+0xddf>
     fc3:      	leaq	0xb0(%rsp), %r15
     fcb:      	jmp	0x1091 <generic_kprobe_process_event+0xd41>
     fd0:      	cmpl	$0x3, %edx
     fd3:      	jg	0x1223 <generic_kprobe_process_event+0xed3>
     fd9:      	cmpl	$0x1, %edx
     fdc:      	jg	0x12f6 <generic_kprobe_process_event+0xfa6>
     fe2:      	testl	%edx, %edx
     fe4:      	je	0x1414 <generic_kprobe_process_event+0x10c4>
     fea:      	cmpl	$0x1, %edx
     fed:      	jne	0x575 <generic_kprobe_process_event+0x225>
     ff3:      	movl	$0x40, %ecx
     ff8:      	subl	%r9d, %ecx
     ffb:      	bzhiq	%rcx, 0x8(%rbx), %rcx
    1001:      	jmp	0x575 <generic_kprobe_process_event+0x225>
    1006:      	cmpl	$0x4, %r13d
    100a:      	jg	0x1296 <generic_kprobe_process_event+0xf46>
    1010:      	leal	-0x2(%r13), %eax
    1014:      	cmpl	$0x2, %eax
    1017:      	jb	0x12c6 <generic_kprobe_process_event+0xf76>
    101d:      	cmpl	$0x1, %r13d
    1021:      	je	0x12c6 <generic_kprobe_process_event+0xf76>
    1027:      	cmpl	$0x4, %r13d
    102b:      	je	0x1268 <generic_kprobe_process_event+0xf18>
    1031:      	jmp	0x1497 <generic_kprobe_process_event+0x1147>
    1036:      	cmpl	$0x1a, %r13d
    103a:      	jg	0x12b9 <generic_kprobe_process_event+0xf69>
    1040:      	cmpl	$0x16, %r13d
    1044:      	je	0x1365 <generic_kprobe_process_event+0x1015>
    104a:      	cmpl	$0x17, %r13d
    104e:      	je	0x1268 <generic_kprobe_process_event+0xf18>
    1054:      	cmpl	$0x1a, %r13d
    1058:      	je	0x13c2 <generic_kprobe_process_event+0x1072>
    105e:      	jmp	0x1497 <generic_kprobe_process_event+0x1147>
    1063:      	leaq	0xb0(%rsp), %r15
    106b:      	movl	$0x8, %ecx
    1070:      	movl	$0x4, %eax
    1075:      	movq	0x50(%rsp), %rdx
    107a:      	movq	%r15, %rdi
    107d:      	movl	$0x8, %esi
    1082:      	callq	*%rax
    1084:      	movq	0xb0(%rsp), %rax
    108c:      	movq	%rax, 0x50(%rsp)
    1091:      	leaq	0x50(%rsp), %rdx
    1096:      	movl	$0x8, %ecx
    109b:      	movl	$0x4, %eax
    10a0:      	leaq	0xb0(%rsp), %rdi
    10a8:      	jmp	0x10ca <generic_kprobe_process_event+0xd7a>
    10aa:      	addq	$0x40, %rbp
    10ae:      	movq	%rbp, 0x50(%rsp)
    10b3:      	leaq	0xb0(%rsp), %rdi
    10bb:      	movl	$0x8, %ecx
    10c0:      	movl	$0x4, %eax
    10c5:      	movq	0x50(%rsp), %rdx
    10ca:      	movl	$0x8, %esi
    10cf:      	callq	*%rax
    10d1:      	movq	0xb0(%rsp), %rax
    10d9:      	addq	$0x40, %rax
    10dd:      	movq	%rax, 0x6440(%r12)
    10e5:      	movq	(%rip), %rsi            # 0x10ec <generic_kprobe_process_event+0xd9c>
    10ec:      	movl	$0x6, %ecx
    10f1:      	movl	$0xc, %eax
    10f6:      	movq	%rbx, %rdi
    10f9:      	movl	$0x6, %edx
    10fe:      	callq	*%rax
    1100:      	xorl	%esi, %esi
    1102:      	jmp	0x1131 <generic_kprobe_process_event+0xde1>
    1104:      	leaq	0x90(%rsp), %rdi
    110c:      	leaq	0x50(%rsp), %rdx
    1111:      	movl	$0x8, %ecx
    1116:      	movl	$0x4, %eax
    111b:      	movl	$0x8, %esi
    1120:      	callq	*%rax
    1122:      	movq	0x90(%rsp), %rax
    112a:      	testq	%rax, %rax
    112d:      	jne	0x10dd <generic_kprobe_process_event+0xd8d>
    112f:      	xorl	%esi, %esi
    1131:      	addl	0xc8(%rsp), %esi
    1138:      	movl	%esi, %ebp
    113a:      	movq	0x100(%rsp), %r12
    1142:      	movl	%ebp, 0x4(%r14)
    1146:      	cmpl	$0x3, %r12d
    114a:      	jg	0x11bb <generic_kprobe_process_event+0xe6b>
    114c:      	movl	$0x0, 0x50(%rsp)
    1154:      	movq	(%rip), %rdi            # 0x115b <generic_kprobe_process_event+0xe0b>
    115b:      	leaq	0x50(%rsp), %rsi
    1160:      	movl	$0x1, %eax
    1165:      	callq	*%rax
    1167:      	testq	%rax, %rax
    116a:      	je	0x11bb <generic_kprobe_process_event+0xe6b>
    116c:      	movq	%rax, %rsi
    116f:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    1176:      	movq	(%rip), %rdi            # 0x117d <generic_kprobe_process_event+0xe2d>
    117d:      	movl	$0x1, %eax
    1182:      	callq	*%rax
    1184:      	testq	%rax, %rax
    1187:      	je	0x11bb <generic_kprobe_process_event+0xe6b>
    1189:      	incl	%r12d
    118c:      	movl	%r12d, %ecx
    118f:      	andl	$0x7, %ecx
    1192:      	cmpl	$-0x1, 0x40(%rax,%rcx,4)
    1197:      	je	0x11bb <generic_kprobe_process_event+0xe6b>
    1199:      	movl	%r12d, 0x5efc(%r14)
    11a0:      	movq	(%rip), %rsi            # 0x11a7 <generic_kprobe_process_event+0xe57>
    11a7:      	movl	$0x1, %ecx
    11ac:      	movl	$0xc, %eax
    11b1:      	movq	%rbx, %rdi
    11b4:      	movl	$0x1, %edx
    11b9:      	callq	*%rax
    11bb:      	movl	$0x0, 0x5efc(%r14)
    11c6:      	movq	(%rip), %rsi            # 0x11cd <generic_kprobe_process_event+0xe7d>
    11cd:      	movl	$0x3, %ecx
    11d2:      	movl	$0xc, %eax
    11d7:      	movq	%rbx, %rdi
    11da:      	movl	$0x3, %edx
    11df:      	callq	*%rax
    11e1:      	xorl	%eax, %eax
    11e3:      	addq	$0x108, %rsp            # imm = 0x108
    11ea:      	popq	%rbx
    11eb:      	popq	%r12
    11ed:      	popq	%r13
    11ef:      	popq	%r14
    11f1:      	popq	%r15
    11f3:      	popq	%rbp
    11f4:      	retq
    11f5:      	cmpl	$0x9, %edx
    11f8:      	jg	0x12d1 <generic_kprobe_process_event+0xf81>
    11fe:      	cmpl	$0x8, %edx
    1201:      	je	0x13d8 <generic_kprobe_process_event+0x1088>
    1207:      	cmpl	$0x9, %edx
    120a:      	jne	0x575 <generic_kprobe_process_event+0x225>
    1210:      	movl	$0x40, %ecx
    1215:      	subl	%r9d, %ecx
    1218:      	bzhiq	%rcx, 0x48(%rbx), %rcx
    121e:      	jmp	0x575 <generic_kprobe_process_event+0x225>
    1223:      	cmpl	$0x5, %edx
    1226:      	jg	0x131b <generic_kprobe_process_event+0xfcb>
    122c:      	cmpl	$0x4, %edx
    122f:      	je	0x1426 <generic_kprobe_process_event+0x10d6>
    1235:      	cmpl	$0x5, %edx
    1238:      	jne	0x575 <generic_kprobe_process_event+0x225>
    123e:      	movl	$0x40, %ecx
    1243:      	subl	%r9d, %ecx
    1246:      	bzhiq	%rcx, 0x28(%rbx), %rcx
    124c:      	jmp	0x575 <generic_kprobe_process_event+0x225>
    1251:      	leal	-0xa(%r13), %eax
    1255:      	cmpl	$0x2, %eax
    1258:      	jb	0x1268 <generic_kprobe_process_event+0xf18>
    125a:      	leal	-0xc(%r13), %eax
    125e:      	cmpl	$0x2, %eax
    1261:      	jb	0x12c6 <generic_kprobe_process_event+0xf76>
    1263:      	jmp	0x1497 <generic_kprobe_process_event+0x1147>
    1268:      	movl	$0x8, %r15d
    126e:      	jmp	0x149a <generic_kprobe_process_event+0x114a>
    1273:      	cmpl	$0x2a, %r13d
    1277:      	jg	0x1370 <generic_kprobe_process_event+0x1020>
    127d:      	cmpl	$0x28, %r13d
    1281:      	je	0x138b <generic_kprobe_process_event+0x103b>
    1287:      	cmpl	$0x29, %r13d
    128b:      	je	0x13cd <generic_kprobe_process_event+0x107d>
    1291:      	jmp	0x1497 <generic_kprobe_process_event+0x1147>
    1296:      	cmpl	$0x6, %r13d
    129a:      	jg	0x13b2 <generic_kprobe_process_event+0x1062>
    12a0:      	cmpl	$0x5, %r13d
    12a4:      	je	0x13cd <generic_kprobe_process_event+0x107d>
    12aa:      	cmpl	$0x6, %r13d
    12ae:      	je	0x149a <generic_kprobe_process_event+0x114a>
    12b4:      	jmp	0x1497 <generic_kprobe_process_event+0x1147>
    12b9:      	leal	-0x1d(%r13), %eax
    12bd:      	cmpl	$0x4, %eax
    12c0:      	jae	0x148d <generic_kprobe_process_event+0x113d>
    12c6:      	movl	$0x4, %r15d
    12cc:      	jmp	0x149a <generic_kprobe_process_event+0x114a>
    12d1:      	cmpl	$0xa, %edx
    12d4:      	je	0x13eb <generic_kprobe_process_event+0x109b>
    12da:      	cmpl	$0xb, %edx
    12dd:      	jne	0x575 <generic_kprobe_process_event+0x225>
    12e3:      	movl	$0x40, %ecx
    12e8:      	subl	%r9d, %ecx
    12eb:      	bzhiq	%rcx, 0x58(%rbx), %rcx
    12f1:      	jmp	0x575 <generic_kprobe_process_event+0x225>
    12f6:      	cmpl	$0x2, %edx
    12f9:      	je	0x1439 <generic_kprobe_process_event+0x10e9>
    12ff:      	cmpl	$0x3, %edx
    1302:      	jne	0x575 <generic_kprobe_process_event+0x225>
    1308:      	movl	$0x40, %ecx
    130d:      	subl	%r9d, %ecx
    1310:      	bzhiq	%rcx, 0x18(%rbx), %rcx
    1316:      	jmp	0x575 <generic_kprobe_process_event+0x225>
    131b:      	cmpl	$0x6, %edx
    131e:      	je	0x144c <generic_kprobe_process_event+0x10fc>
    1324:      	cmpl	$0x7, %edx
    1327:      	jne	0x575 <generic_kprobe_process_event+0x225>
    132d:      	movl	$0x40, %ecx
    1332:      	subl	%r9d, %ecx
    1335:      	bzhiq	%rcx, 0x38(%rbx), %rcx
    133b:      	jmp	0x575 <generic_kprobe_process_event+0x225>
    1340:      	cmpl	$0xc, %edx
    1343:      	je	0x1472 <generic_kprobe_process_event+0x1122>
    1349:      	cmpl	$0xd, %edx
    134c:      	jne	0x575 <generic_kprobe_process_event+0x225>
    1352:      	movl	$0x40, %ecx
    1357:      	subl	%r9d, %ecx
    135a:      	bzhiq	%rcx, 0x68(%rbx), %rcx
    1360:      	jmp	0x575 <generic_kprobe_process_event+0x225>
    1365:      	movl	$0x10, %r15d
    136b:      	jmp	0x149a <generic_kprobe_process_event+0x114a>
    1370:      	cmpl	$0x2b, %r13d
    1374:      	je	0x138b <generic_kprobe_process_event+0x103b>
    1376:      	cmpl	$0x2c, %r13d
    137a:      	jne	0x1497 <generic_kprobe_process_event+0x1147>
    1380:      	movl	$0x70, %r15d
    1386:      	jmp	0x149a <generic_kprobe_process_event+0x114a>
    138b:      	movl	$0x18, %r15d
    1391:      	jmp	0x149a <generic_kprobe_process_event+0x114a>
    1396:      	cmpl	$0x11, %r13d
    139a:      	je	0x149a <generic_kprobe_process_event+0x114a>
    13a0:      	movq	%rdi, %r15
    13a3:      	cmpl	$0x12, %r13d
    13a7:      	je	0x149a <generic_kprobe_process_event+0x114a>
    13ad:      	jmp	0x1497 <generic_kprobe_process_event+0x1147>
    13b2:      	cmpl	$0x7, %r13d
    13b6:      	je	0x13cd <generic_kprobe_process_event+0x107d>
    13b8:      	cmpl	$0x8, %r13d
    13bc:      	jne	0x1497 <generic_kprobe_process_event+0x1147>
    13c2:      	movl	$0x50, %r15d
    13c8:      	jmp	0x149a <generic_kprobe_process_event+0x114a>
    13cd:      	movl	$0x40, %r15d
    13d3:      	jmp	0x149a <generic_kprobe_process_event+0x114a>
    13d8:      	movl	$0x40, %ecx
    13dd:      	subl	%r9d, %ecx
    13e0:      	bzhiq	%rcx, 0x40(%rbx), %rcx
    13e6:      	jmp	0x575 <generic_kprobe_process_event+0x225>
    13eb:      	movl	$0x40, %ecx
    13f0:      	subl	%r9d, %ecx
    13f3:      	bzhiq	%rcx, 0x50(%rbx), %rcx
    13f9:      	jmp	0x575 <generic_kprobe_process_event+0x225>
    13fe:      	movl	$0x40, %ecx
    1403:      	subl	%r9d, %ecx
    1406:      	bzhiq	%rcx, 0x80(%rbx), %rcx
    140f:      	jmp	0x575 <generic_kprobe_process_event+0x225>
    1414:      	movl	$0x40, %ecx
    1419:      	subl	%r9d, %ecx
    141c:      	bzhiq	%rcx, (%rbx), %rcx
    1421:      	jmp	0x575 <generic_kprobe_process_event+0x225>
    1426:      	movl	$0x40, %ecx
    142b:      	subl	%r9d, %ecx
    142e:      	bzhiq	%rcx, 0x20(%rbx), %rcx
    1434:      	jmp	0x575 <generic_kprobe_process_event+0x225>
    1439:      	movl	$0x40, %ecx
    143e:      	subl	%r9d, %ecx
    1441:      	bzhiq	%rcx, 0x10(%rbx), %rcx
    1447:      	jmp	0x575 <generic_kprobe_process_event+0x225>
    144c:      	movl	$0x40, %ecx
    1451:      	subl	%r9d, %ecx
    1454:      	bzhiq	%rcx, 0x30(%rbx), %rcx
    145a:      	jmp	0x575 <generic_kprobe_process_event+0x225>
    145f:      	movl	$0x40, %ecx
    1464:      	subl	%r9d, %ecx
    1467:      	bzhiq	%rcx, 0x70(%rbx), %rcx
    146d:      	jmp	0x575 <generic_kprobe_process_event+0x225>
    1472:      	movl	$0x40, %ecx
    1477:      	subl	%r9d, %ecx
    147a:      	bzhiq	%rcx, 0x60(%rbx), %rcx
    1480:      	jmp	0x575 <generic_kprobe_process_event+0x225>
    1485:      	movl	$0x98, %r15d
    148b:      	jmp	0x149a <generic_kprobe_process_event+0x114a>
    148d:      	cmpl	$0x1b, %r13d
    1491:      	je	0x13c2 <generic_kprobe_process_event+0x1072>
    1497:      	xorl	%r15d, %r15d
    149a:      	movq	%rdi, 0x10(%rsp)
    149f:      	movl	$0x0, 0xfc(%rsp)
    14aa:      	movq	(%rip), %rdi            # 0x14b1 <generic_kprobe_process_event+0x1161>
    14b1:      	leaq	0xfc(%rsp), %rsi
    14b9:      	movl	$0x1, %eax
    14be:      	callq	*%rax
    14c0:      	xorl	%esi, %esi
    14c2:      	testq	%rax, %rax
    14c5:      	je	0x1131 <generic_kprobe_process_event+0xde1>
    14cb:      	movl	$0x3ffb, %ecx           # imm = 0x3FFB
    14d0:      	subq	%r15, %rcx
    14d3:      	cmpq	0xc8(%rsp), %rcx
    14db:      	jbe	0x1131 <generic_kprobe_process_event+0xde1>
    14e1:      	movq	0x20(%rsp), %rsi
    14e6:      	movl	0x5ea0(%rax,%rsi,4), %ecx
    14ed:      	movq	0xc8(%rsp), %rdx
    14f5:      	movl	%ecx, 0x90(%rax,%rdx)
    14fc:      	addq	$0x4, %rdx
    1500:      	movq	%rdx, 0x5e78(%rax,%rsi,8)
    1508:      	movl	$0x4, %esi
    150d:      	testl	%ecx, %ecx
    150f:      	jne	0x1131 <generic_kprobe_process_event+0xde1>
    1515:      	movq	%rax, %r15
    1518:      	addq	$0x90, %r15
    151f:      	addq	%rdx, %r15
    1522:      	movq	%r12, 0x50(%rsp)
    1527:      	movq	$0x0, 0x90(%rsp)
    1533:      	cmpl	$0x17, %r13d
    1537:      	movq	%rax, 0x40(%rsp)
    153c:      	jle	0x1579 <generic_kprobe_process_event+0x1229>
    153e:      	cmpl	$0x18, %r13d
    1542:      	je	0x1594 <generic_kprobe_process_event+0x1244>
    1544:      	cmpl	$0x25, %r13d
    1548:      	je	0x15d5 <generic_kprobe_process_event+0x1285>
    154e:      	cmpl	$0x2a, %r13d
    1552:      	jne	0x1dc9 <generic_kprobe_process_event+0x1a79>
    1558:      	movq	$0x0, 0xb0(%rsp)
    1564:      	movq	%r12, 0xb8(%rsp)
    156c:      	leaq	0xb0(%rsp), %rax
    1574:      	jmp	0x1602 <generic_kprobe_process_event+0x12b2>
    1579:      	cmpl	$0xf, %r13d
    157d:      	je	0x1cf7 <generic_kprobe_process_event+0x19a7>
    1583:      	cmpl	$0x10, %r13d
    1587:      	jne	0x1dc9 <generic_kprobe_process_event+0x1a79>
    158d:      	leaq	0x38(%rsp), %r12
    1592:      	jmp	0x15bf <generic_kprobe_process_event+0x126f>
    1594:      	movq	%r12, %rdx
    1597:      	leaq	0x38(%rsp), %r12
    159c:      	movl	$0x8, %ecx
    15a1:      	movl	$0x4, %eax
    15a6:      	movq	0x50(%rsp), %rdx
    15ab:      	movq	%r12, %rdi
    15ae:      	movl	$0x8, %esi
    15b3:      	callq	*%rax
    15b5:      	movq	0x38(%rsp), %rax
    15ba:      	movq	%rax, 0x50(%rsp)
    15bf:      	leaq	0x50(%rsp), %rdx
    15c4:      	movl	$0x8, %ecx
    15c9:      	movl	$0x4, %eax
    15ce:      	leaq	0x38(%rsp), %rdi
    15d3:      	jmp	0x15f2 <generic_kprobe_process_event+0x12a2>
    15d5:      	addq	$0x40, %r12
    15d9:      	movq	%r12, 0x50(%rsp)
    15de:      	leaq	0x38(%rsp), %rdi
    15e3:      	movl	$0x8, %ecx
    15e8:      	movl	$0x4, %eax
    15ed:      	movq	0x50(%rsp), %rdx
    15f2:      	movl	$0x8, %esi
    15f7:      	callq	*%rax
    15f9:      	movq	0x38(%rsp), %rax
    15fe:      	addq	$0x40, %rax
    1602:      	movq	%rax, 0x30(%rsp)
    1607:      	movl	$0x0, 0xdc(%rsp)
    1612:      	movq	(%rip), %rdi            # 0x1619 <generic_kprobe_process_event+0x12c9>
    1619:      	leaq	0xdc(%rsp), %rsi
    1621:      	movl	$0x1, %eax
    1626:      	callq	*%rax
    1628:      	testq	%rax, %rax
    162b:      	je	0x1bfd <generic_kprobe_process_event+0x18ad>
    1631:      	movq	%rax, %r12
    1634:      	movq	%r15, 0xa8(%rsp)
    163c:      	addq	$0x1000, %rax           # imm = 0x1000
    1642:      	movq	%rax, 0x10(%rsp)
    1647:      	movl	$0x23, %eax
    164c:      	callq	*%rax
    164e:      	leaq	0xd50(%rax), %rdx
    1655:      	leaq	0xd0(%rsp), %rdi
    165d:      	movl	$0x8, %ecx
    1662:      	movl	$0x4, %eax
    1667:      	movl	$0x8, %esi
    166c:      	callq	*%rax
    166e:      	movq	0xd0(%rsp), %rbp
    1676:      	movq	0x30(%rsp), %rax
    167b:      	leaq	0x8(%rax), %rdx
    167f:      	leaq	0xe0(%rsp), %rdi
    1687:      	movl	$0x8, %ecx
    168c:      	movl	$0x4, %eax
    1691:      	leaq	0x18(%rbp), %rcx
    1695:      	movq	%rcx, 0xe8(%rsp)
    169d:      	movl	$0x8, %esi
    16a2:      	movq	%rdx, 0xa0(%rsp)
    16aa:      	callq	*%rax
    16ac:      	movq	0xe0(%rsp), %r13
    16b4:      	leaq	0x10(%r13), %rdx
    16b8:      	leaq	0x50(%rsp), %rdi
    16bd:      	movl	$0x8, %ecx
    16c2:      	movl	$0x4, %eax
    16c7:      	movl	$0x8, %esi
    16cc:      	callq	*%rax
    16ce:      	cmpq	$0x0, 0x50(%rsp)
    16d4:      	movl	$0x1000, %r15d          # imm = 0x1000
    16da:      	je	0x16e3 <generic_kprobe_process_event+0x1393>
    16dc:      	movq	0x10(%rsp), %rcx
    16e1:      	jmp	0x1736 <generic_kprobe_process_event+0x13e6>
    16e3:      	leaq	0x18(%r13), %rdx
    16e7:      	leaq	0x50(%rsp), %rdi
    16ec:      	movl	$0x8, %ecx
    16f1:      	movl	$0x4, %eax
    16f6:      	movl	$0x8, %esi
    16fb:      	callq	*%rax
    16fd:      	cmpq	%r13, 0x50(%rsp)
    1702:      	movq	0x10(%rsp), %rcx
    1707:      	je	0x1736 <generic_kprobe_process_event+0x13e6>
    1709:      	movq	%r12, %rcx
    170c:      	addq	$0xff6, %rcx            # imm = 0xFF6
    1713:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
    171d:      	movq	%rax, 0xff6(%r12)
    1725:      	movw	$0x2964, 0xffe(%r12)    # imm = 0x2964
    1730:      	movl	$0xff6, %r15d           # imm = 0xFF6
    1736:      	movq	$0x0, 0x58(%rsp)
    173f:      	movq	$0x0, 0x50(%rsp)
    1748:      	movq	%r12, 0x60(%rsp)
    174d:      	movq	$0x0, 0x68(%rsp)
    1756:      	movq	$0x0, 0x70(%rsp)
    175f:      	movq	$0x0, 0x78(%rsp)
    1768:      	movq	%rcx, 0x10(%rsp)
    176d:      	movq	%rcx, 0x80(%rsp)
    1775:      	movl	%r15d, 0x88(%rsp)
    177d:      	movb	$0x0, 0x8c(%rsp)
    1785:      	addq	$0x20, %rbp
    1789:      	leaq	0x50(%rsp), %rdi
    178e:      	movl	$0x8, %ecx
    1793:      	movl	$0x4, %eax
    1798:      	leaq	0x58(%rsp), %r12
    179d:      	leaq	0x68(%rsp), %r15
    17a2:      	leaq	0x70(%rsp), %r13
    17a7:      	movl	$0x8, %esi
    17ac:      	movq	%rbp, %rdx
    17af:      	callq	*%rax
    17b1:      	movl	$0x8, %ecx
    17b6:      	movl	$0x4, %eax
    17bb:      	movq	0xe8(%rsp), %rdx
    17c3:      	movq	%r12, %rdi
    17c6:      	movl	$0x8, %esi
    17cb:      	callq	*%rax
    17cd:      	movl	$0x8, %ecx
    17d2:      	movl	$0x4, %eax
    17d7:      	movq	0xa0(%rsp), %rdx
    17df:      	movq	%r15, %rdi
    17e2:      	movl	$0x8, %esi
    17e7:      	callq	*%rax
    17e9:      	movl	$0x8, %ecx
    17ee:      	movl	$0x4, %eax
    17f3:      	movq	0x30(%rsp), %rdx
    17f8:      	movq	%r13, %rdi
    17fb:      	movl	$0x8, %esi
    1800:      	callq	*%rax
    1802:      	movq	0x70(%rsp), %rax
    1807:      	addq	$-0x20, %rax
    180b:      	movq	%rax, 0x78(%rsp)
    1810:      	movq	(%rip), %rax            # 0x1817 <generic_kprobe_process_event+0x14c7>
    1817:      	cmpb	$0x0, (%rax)
    181a:      	je	0x19e6 <generic_kprobe_process_event+0x1696>
    1820:      	movl	$0x80, %r15d
    1826:      	movl	$0x8, %r13d
    182c:      	jmp	0x1837 <generic_kprobe_process_event+0x14e7>
    182e:      	decl	%r15d
    1831:      	je	0x1bb1 <generic_kprobe_process_event+0x1861>
    1837:      	movq	0x68(%rsp), %rbp
    183c:      	movq	0x70(%rsp), %rdx
    1841:      	movq	0x78(%rsp), %r12
    1846:      	cmpq	0x50(%rsp), %rbp
    184b:      	jne	0x1858 <generic_kprobe_process_event+0x1508>
    184d:      	cmpq	0x58(%rsp), %rdx
    1852:      	je	0x1ba9 <generic_kprobe_process_event+0x1859>
    1858:      	movl	$0x4, %eax
    185d:      	leaq	0xc0(%rsp), %rdi
    1865:      	movl	$0x8, %esi
    186a:      	callq	*%rax
    186c:      	cmpq	0xc0(%rsp), %rbp
    1874:      	movl	$0x8, %ecx
    1879:      	je	0x198a <generic_kprobe_process_event+0x163a>
    187f:      	leaq	0x18(%rbp), %r13
    1883:      	movl	$0x4, %eax
    1888:      	leaq	0x38(%rsp), %rdi
    188d:      	movl	$0x8, %esi
    1892:      	movq	%r13, %rdx
    1895:      	callq	*%rax
    1897:      	movl	$0x8, %ecx
    189c:      	cmpq	%rbp, 0x38(%rsp)
    18a1:      	je	0x198a <generic_kprobe_process_event+0x163a>
    18a7:      	movl	$0x4, %eax
    18ac:      	leaq	0x48(%rsp), %rdi
    18b1:      	movl	$0x8, %esi
    18b6:      	movq	%r13, %rdx
    18b9:      	callq	*%rax
    18bb:      	addq	$0x20, %rbp
    18bf:      	movl	$0x4, %eax
    18c4:      	leaq	0x90(%rsp), %rdi
    18cc:      	movl	$0x10, %ecx
    18d1:      	movl	$0x10, %esi
    18d6:      	movq	%rbp, %rdx
    18d9:      	callq	*%rax
    18db:      	movq	0x60(%rsp), %r12
    18e0:      	movq	0x80(%rsp), %rax
    18e8:      	movl	0x94(%rsp), %ebp
    18ef:      	subq	%r12, %rax
    18f2:      	movl	0x88(%rsp), %r13d
    18fa:      	movl	%ebp, %edx
    18fc:      	subl	%r13d, %edx
    18ff:      	movl	$0x0, %ecx
    1904:      	cmovbl	%ecx, %edx
    1907:      	addq	0x98(%rsp), %rdx
    190f:      	xorl	%esi, %esi
    1911:      	cmpl	%ebp, %r13d
    1914:      	seta	%sil
    1918:      	movl	%ebp, %ecx
    191a:      	cmovbl	%r13d, %ecx
    191e:      	addl	%ecx, %esi
    1920:      	movl	%r13d, %edi
    1923:      	subl	%esi, %edi
    1925:      	movl	%edi, 0x88(%rsp)
    192c:      	subq	%rsi, %rax
    192f:      	jb	0x1bb1 <generic_kprobe_process_event+0x1861>
    1935:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    193b:      	ja	0x1bb1 <generic_kprobe_process_event+0x1861>
    1941:      	cmpl	%ebp, %r13d
    1944:      	jbe	0x194b <generic_kprobe_process_event+0x15fb>
    1946:      	movb	$0x2f, (%r12,%rax)
    194b:      	xorl	%edi, %edi
    194d:      	cmpl	%ebp, %r13d
    1950:      	seta	%dil
    1954:      	movzbl	%cl, %esi
    1957:      	addq	%rax, %r12
    195a:      	addq	%r12, %rdi
    195d:      	movl	$0x4, %eax
    1962:      	callq	*%rax
    1964:      	movq	%r12, 0x80(%rsp)
    196c:      	cmpl	%ebp, %r13d
    196f:      	jbe	0x1bb1 <generic_kprobe_process_event+0x1861>
    1975:      	movq	0x48(%rsp), %rax
    197a:      	movq	%rax, 0x68(%rsp)
    197f:      	movl	$0x8, %r13d
    1985:      	jmp	0x182e <generic_kprobe_process_event+0x14de>
    198a:      	leaq	0x10(%r12), %rdx
    198f:      	movl	$0x4, %eax
    1994:      	leaq	0x38(%rsp), %rdi
    1999:      	movl	$0x8, %esi
    199e:      	callq	*%rax
    19a0:      	movq	0x78(%rsp), %rax
    19a5:      	cmpq	0x38(%rsp), %rax
    19aa:      	movl	$0x8, %r13d
    19b0:      	je	0x1ba9 <generic_kprobe_process_event+0x1859>
    19b6:      	addq	$0x18, %r12
    19ba:      	movl	$0x4, %eax
    19bf:      	leaq	0x68(%rsp), %rdi
    19c4:      	movl	$0x8, %esi
    19c9:      	movq	%r12, %rdx
    19cc:      	callq	*%rax
    19ce:      	movq	0x38(%rsp), %rax
    19d3:      	movq	%rax, 0x78(%rsp)
    19d8:      	addq	$0x20, %rax
    19dc:      	movq	%rax, 0x70(%rsp)
    19e1:      	jmp	0x182e <generic_kprobe_process_event+0x14de>
    19e6:      	movl	$0x80, %r15d
    19ec:      	movl	$0x8, %r13d
    19f2:      	movq	0x68(%rsp), %rbp
    19f7:      	movq	0x70(%rsp), %rdx
    19fc:      	movq	0x78(%rsp), %r12
    1a01:      	cmpq	0x50(%rsp), %rbp
    1a06:      	jne	0x1a13 <generic_kprobe_process_event+0x16c3>
    1a08:      	cmpq	0x58(%rsp), %rdx
    1a0d:      	je	0x1ba9 <generic_kprobe_process_event+0x1859>
    1a13:      	movl	$0x4, %eax
    1a18:      	leaq	0xc0(%rsp), %rdi
    1a20:      	movl	$0x8, %esi
    1a25:      	callq	*%rax
    1a27:      	cmpq	0xc0(%rsp), %rbp
    1a2f:      	movl	$0x8, %ecx
    1a34:      	je	0x1b4b <generic_kprobe_process_event+0x17fb>
    1a3a:      	leaq	0x18(%rbp), %r13
    1a3e:      	movl	$0x4, %eax
    1a43:      	leaq	0x38(%rsp), %rdi
    1a48:      	movl	$0x8, %esi
    1a4d:      	movq	%r13, %rdx
    1a50:      	callq	*%rax
    1a52:      	movl	$0x8, %ecx
    1a57:      	cmpq	%rbp, 0x38(%rsp)
    1a5c:      	je	0x1b4b <generic_kprobe_process_event+0x17fb>
    1a62:      	movl	$0x4, %eax
    1a67:      	leaq	0x48(%rsp), %rdi
    1a6c:      	movl	$0x8, %esi
    1a71:      	movq	%r13, %rdx
    1a74:      	callq	*%rax
    1a76:      	addq	$0x20, %rbp
    1a7a:      	movl	$0x4, %eax
    1a7f:      	leaq	0x90(%rsp), %rdi
    1a87:      	movl	$0x10, %ecx
    1a8c:      	movl	$0x10, %esi
    1a91:      	movq	%rbp, %rdx
    1a94:      	callq	*%rax
    1a96:      	movq	0x60(%rsp), %r12
    1a9b:      	movq	0x80(%rsp), %rax
    1aa3:      	movl	0x94(%rsp), %ebp
    1aaa:      	subq	%r12, %rax
    1aad:      	movl	0x88(%rsp), %r13d
    1ab5:      	movl	%ebp, %edx
    1ab7:      	subl	%r13d, %edx
    1aba:      	movl	$0x0, %ecx
    1abf:      	cmovbl	%ecx, %edx
    1ac2:      	addq	0x98(%rsp), %rdx
    1aca:      	xorl	%esi, %esi
    1acc:      	cmpl	%ebp, %r13d
    1acf:      	seta	%sil
    1ad3:      	movl	%ebp, %ecx
    1ad5:      	cmovbl	%r13d, %ecx
    1ad9:      	addl	%ecx, %esi
    1adb:      	movl	%r13d, %edi
    1ade:      	subl	%esi, %edi
    1ae0:      	movl	%edi, 0x88(%rsp)
    1ae7:      	subq	%rsi, %rax
    1aea:      	jb	0x1bb1 <generic_kprobe_process_event+0x1861>
    1af0:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    1af6:      	ja	0x1bb1 <generic_kprobe_process_event+0x1861>
    1afc:      	cmpl	%ebp, %r13d
    1aff:      	jbe	0x1b06 <generic_kprobe_process_event+0x17b6>
    1b01:      	movb	$0x2f, (%r12,%rax)
    1b06:      	xorl	%edi, %edi
    1b08:      	cmpl	%ebp, %r13d
    1b0b:      	seta	%dil
    1b0f:      	movzbl	%cl, %esi
    1b12:      	addq	%rax, %r12
    1b15:      	addq	%r12, %rdi
    1b18:      	movl	$0x4, %eax
    1b1d:      	callq	*%rax
    1b1f:      	movq	%r12, 0x80(%rsp)
    1b27:      	cmpl	%ebp, %r13d
    1b2a:      	jbe	0x1bb1 <generic_kprobe_process_event+0x1861>
    1b30:      	movq	0x48(%rsp), %rax
    1b35:      	movq	%rax, 0x68(%rsp)
    1b3a:      	movl	$0x8, %r13d
    1b40:      	decl	%r15d
    1b43:      	jne	0x19f2 <generic_kprobe_process_event+0x16a2>
    1b49:      	jmp	0x1bb1 <generic_kprobe_process_event+0x1861>
    1b4b:      	leaq	0x10(%r12), %rdx
    1b50:      	movl	$0x4, %eax
    1b55:      	leaq	0x38(%rsp), %rdi
    1b5a:      	movl	$0x8, %esi
    1b5f:      	callq	*%rax
    1b61:      	movq	0x78(%rsp), %rax
    1b66:      	cmpq	0x38(%rsp), %rax
    1b6b:      	movl	$0x8, %r13d
    1b71:      	je	0x1ba9 <generic_kprobe_process_event+0x1859>
    1b73:      	addq	$0x18, %r12
    1b77:      	movl	$0x4, %eax
    1b7c:      	leaq	0x68(%rsp), %rdi
    1b81:      	movl	$0x8, %esi
    1b86:      	movq	%r12, %rdx
    1b89:      	callq	*%rax
    1b8b:      	movq	0x38(%rsp), %rax
    1b90:      	movq	%rax, 0x78(%rsp)
    1b95:      	addq	$0x20, %rax
    1b99:      	movq	%rax, 0x70(%rsp)
    1b9e:      	decl	%r15d
    1ba1:      	jne	0x19f2 <generic_kprobe_process_event+0x16a2>
    1ba7:      	jmp	0x1bb1 <generic_kprobe_process_event+0x1861>
    1ba9:      	movb	$0x1, 0x8c(%rsp)
    1bb1:      	movq	0x80(%rsp), %rax
    1bb9:      	movq	0x10(%rsp), %rdx
    1bbe:      	cmpq	%rdx, %rax
    1bc1:      	je	0x1c05 <generic_kprobe_process_event+0x18b5>
    1bc3:      	xorl	%ebp, %ebp
    1bc5:      	cmpb	$0x0, 0x8c(%rsp)
    1bcd:      	sete	%cl
    1bd0:      	movl	0x88(%rsp), %edx
    1bd7:      	movl	$0x1000, %r13d          # imm = 0x1000
    1bdd:      	subl	%edx, %r13d
    1be0:      	testl	%edx, %edx
    1be2:      	cmovlel	%edx, %r13d
    1be6:      	testq	%rax, %rax
    1be9:      	movq	0xa8(%rsp), %r15
    1bf1:      	je	0x1bfd <generic_kprobe_process_event+0x18ad>
    1bf3:      	movb	%cl, %bpl
    1bf6:      	addl	%ebp, %ebp
    1bf8:      	movq	%rax, %rdx
    1bfb:      	jmp	0x1c12 <generic_kprobe_process_event+0x18c2>
    1bfd:      	xorl	%r13d, %r13d
    1c00:      	jmp	0x1cc1 <generic_kprobe_process_event+0x1971>
    1c05:      	xorl	%r13d, %r13d
    1c08:      	xorl	%ebp, %ebp
    1c0a:      	movq	0xa8(%rsp), %r15
    1c12:      	leaq	0x4(%r15), %rdi
    1c16:      	andl	$0xfff, %r13d           # imm = 0xFFF
    1c1d:      	movl	$0x4, %eax
    1c22:      	movl	%r13d, %esi
    1c25:      	callq	*%rax
    1c27:      	movl	%r13d, (%r15)
    1c2a:      	leaq	0x50(%rsp), %rdi
    1c2f:      	movl	$0x8, %ecx
    1c34:      	movl	$0x4, %eax
    1c39:      	movq	0xa0(%rsp), %rdx
    1c41:      	movl	$0x8, %esi
    1c46:      	callq	*%rax
    1c48:      	movq	0x50(%rsp), %rcx
    1c4d:      	addq	$0x30, %rcx
    1c51:      	leaq	0x90(%rsp), %rdi
    1c59:      	movl	$0x8, %edx
    1c5e:      	movl	$0x4, %eax
    1c63:      	movq	0x50(%rsp), %rdx
    1c68:      	addq	$0x30, %rdx
    1c6c:      	movl	$0x8, %esi
    1c71:      	callq	*%rax
    1c73:      	movq	0x90(%rsp), %rcx
    1c7b:      	leaq	0x38(%rsp), %rdi
    1c80:      	movl	$0x2, %edx
    1c85:      	movl	$0x4, %eax
    1c8a:      	movq	0x90(%rsp), %rdx
    1c92:      	movl	$0x2, %esi
    1c97:      	callq	*%rax
    1c99:      	movl	%ebp, 0x4(%r15,%r13)
    1c9e:      	movzwl	0x38(%rsp), %eax
    1ca3:      	movw	%ax, 0x8(%r15,%r13)
    1ca9:      	addl	$0xa, %r13d
    1cad:      	movq	0x40(%rsp), %rax
    1cb2:      	movq	0x20(%rsp), %rcx
    1cb7:      	movl	$0x4, %esi
    1cbc:      	testl	%r13d, %r13d
    1cbf:      	js	0x1cd4 <generic_kprobe_process_event+0x1984>
    1cc1:      	andl	$0x7fffffff, %r13d      # imm = 0x7FFFFFFF
    1cc8:      	addq	$0x4, %r13
    1ccc:      	movq	%r13, %rsi
    1ccf:      	jmp	0x1131 <generic_kprobe_process_event+0xde1>
    1cd4:      	movl	$0xffffffff, 0x5ea0(%rax,%rcx,4) # imm = 0xFFFFFFFF
    1cdf:      	movq	0xc8(%rsp), %rcx
    1ce7:      	movl	$0xffffffff, 0x90(%rax,%rcx) # imm = 0xFFFFFFFF
    1cf2:      	jmp	0x1131 <generic_kprobe_process_event+0xde1>
    1cf7:      	movq	%rdx, 0xa8(%rsp)
    1cff:      	leaq	0x90(%rsp), %rdi
    1d07:      	leaq	0x50(%rsp), %rdx
    1d0c:      	movl	$0x8, %ecx
    1d11:      	movl	$0x4, %eax
    1d16:      	movl	$0x8, %esi
    1d1b:      	callq	*%rax
    1d1d:      	movq	0x90(%rsp), %rax
    1d25:      	movq	%rax, 0x30(%rsp)
    1d2a:      	testq	%rax, %rax
    1d2d:      	jne	0x1607 <generic_kprobe_process_event+0x12b7>
    1d33:      	movl	$0x0, 0xe0(%rsp)
    1d3e:      	movq	(%rip), %rdi            # 0x1d45 <generic_kprobe_process_event+0x19f5>
    1d45:      	leaq	0xe0(%rsp), %rsi
    1d4d:      	movl	$0x1, %eax
    1d52:      	callq	*%rax
    1d54:      	testq	%rax, %rax
    1d57:      	je	0x1e70 <generic_kprobe_process_event+0x1b20>
    1d5d:      	cmpl	$0x19, %r13d
    1d61:      	movq	%rbx, 0x18(%rsp)
    1d66:      	movq	%r14, 0x28(%rsp)
    1d6b:      	jg	0x20f2 <generic_kprobe_process_event+0x1da2>
    1d71:      	cmpl	$0x12, %r13d
    1d75:      	jle	0x2269 <generic_kprobe_process_event+0x1f19>
    1d7b:      	movq	%r13, %rax
    1d7e:      	cmpl	$0x14, %r13d
    1d82:      	jle	0x25f6 <generic_kprobe_process_event+0x22a6>
    1d88:      	cmpl	$0x15, %eax
    1d8b:      	je	0x2fbf <generic_kprobe_process_event+0x2c6f>
    1d91:      	cmpl	$0x16, %eax
    1d94:      	je	0x2f3c <generic_kprobe_process_event+0x2bec>
    1d9a:      	cmpl	$0x17, %eax
    1d9d:      	movq	0x18(%rsp), %rbx
    1da2:      	movq	0x28(%rsp), %r14
    1da7:      	movl	$0x0, %r13d
    1dad:      	jne	0x1cad <generic_kprobe_process_event+0x195d>
    1db3:      	movl	$0x0, 0x4(%r15)
    1dbb:      	movl	%r12d, (%r15)
    1dbe:      	movl	$0x8, %r13d
    1dc4:      	jmp	0x1cad <generic_kprobe_process_event+0x195d>
    1dc9:      	movq	%rdx, 0xa8(%rsp)
    1dd1:      	cmpl	$0x2c, %r13d
    1dd5:      	ja	0x1d33 <generic_kprobe_process_event+0x19e3>
    1ddb:      	movabsq	$0x11c1f2027cf2, %rax   # imm = 0x11C1F2027CF2
    1de5:      	btq	%rbp, %rax
    1de9:      	jae	0x1d33 <generic_kprobe_process_event+0x19e3>
    1def:      	movq	%r12, 0x48(%rsp)
    1df4:      	movl	$0x0, 0xe0(%rsp)
    1dff:      	movq	(%rip), %rdi            # 0x1e06 <generic_kprobe_process_event+0x1ab6>
    1e06:      	leaq	0xe0(%rsp), %rsi
    1e0e:      	movl	$0x1, %eax
    1e13:      	callq	*%rax
    1e15:      	testq	%rax, %rax
    1e18:      	je	0x1e70 <generic_kprobe_process_event+0x1b20>
    1e1a:      	movq	%r15, %rbp
    1e1d:      	cmpl	$0x10, %r13d
    1e21:      	jle	0x1e78 <generic_kprobe_process_event+0x1b28>
    1e23:      	cmpl	$0x1e, %r13d
    1e27:      	jle	0x1ff8 <generic_kprobe_process_event+0x1ca8>
    1e2d:      	movq	%r14, %r15
    1e30:      	movq	%rbx, 0x18(%rsp)
    1e35:      	cmpl	$0x26, %r13d
    1e39:      	jg	0x2133 <generic_kprobe_process_event+0x1de3>
    1e3f:      	leal	-0x1f(%r13), %eax
    1e43:      	cmpl	$0x2, %eax
    1e46:      	jae	0x26d1 <generic_kprobe_process_event+0x2381>
    1e4c:      	leaq	0x48(%rsp), %rdx
    1e51:      	movl	$0x4, %r13d
    1e57:      	movl	$0x1, %ecx
    1e5c:      	movl	$0x4, %eax
    1e61:      	movq	%rbp, %rdi
    1e64:      	movl	$0x1, %esi
    1e69:      	callq	*%rax
    1e6b:      	jmp	0x3561 <generic_kprobe_process_event+0x3211>
    1e70:      	xorl	%r13d, %r13d
    1e73:      	jmp	0x1cad <generic_kprobe_process_event+0x195d>
    1e78:      	cmpl	$0x9, %r13d
    1e7c:      	jg	0x2031 <generic_kprobe_process_event+0x1ce1>
    1e82:      	movq	%r14, 0x28(%rsp)
    1e87:      	movq	%rbx, 0x18(%rsp)
    1e8c:      	cmpl	$0x4, %r13d
    1e90:      	jle	0x2303 <generic_kprobe_process_event+0x1fb3>
    1e96:      	cmpl	$0x5, %r13d
    1e9a:      	je	0x2a65 <generic_kprobe_process_event+0x2715>
    1ea0:      	movq	%rax, %r15
    1ea3:      	movq	%r13, %rax
    1ea6:      	cmpl	$0x6, %eax
    1ea9:      	je	0x20bc <generic_kprobe_process_event+0x1d6c>
    1eaf:      	cmpl	$0x7, %eax
    1eb2:      	movq	0x40(%rsp), %rax
    1eb7:      	movq	0x20(%rsp), %rcx
    1ebc:      	movl	$0x4, %esi
    1ec1:      	movq	0x18(%rsp), %rbx
    1ec6:      	movq	0x28(%rsp), %r14
    1ecb:      	movl	$0x0, %r13d
    1ed1:      	jne	0x1cbc <generic_kprobe_process_event+0x196c>
    1ed7:      	movq	0x48(%rsp), %r12
    1edc:      	movq	%rbp, %rbx
    1edf:      	movq	%r12, 0x28(%rbp)
    1ee3:      	leaq	0x26(%rbp), %rdi
    1ee7:      	leaq	0x10(%r12), %rdx
    1eec:      	movl	$0x2, %ecx
    1ef1:      	movl	$0x4, %eax
    1ef6:      	movl	$0x2, %esi
    1efb:      	callq	*%rax
    1efd:      	leaq	0x3a(%rbp), %rdi
    1f01:      	leaq	0x12(%r12), %rdx
    1f06:      	movl	$0x1, %ecx
    1f0b:      	movl	$0x4, %eax
    1f10:      	movl	$0x1, %esi
    1f15:      	callq	*%rax
    1f17:      	leaq	0x38(%rbp), %rdi
    1f1b:      	leaq	0x226(%r12), %rdx
    1f23:      	movl	$0x2, %ecx
    1f28:      	movl	$0x4, %eax
    1f2d:      	movl	$0x2, %esi
    1f32:      	callq	*%rax
    1f34:      	leaq	0x24(%rbp), %rdi
    1f38:      	leaq	0x224(%r12), %rdx
    1f40:      	movl	$0x2, %ecx
    1f45:      	movl	$0x4, %eax
    1f4a:      	movl	$0x2, %esi
    1f4f:      	callq	*%rax
    1f51:      	leaq	0x30(%rbp), %rdi
    1f55:      	leaq	0x21c(%r12), %rdx
    1f5d:      	movl	$0x4, %ecx
    1f62:      	movl	$0x4, %eax
    1f67:      	movl	$0x4, %esi
    1f6c:      	callq	*%rax
    1f6e:      	leaq	0x34(%rbp), %rdi
    1f72:      	leaq	0x218(%r12), %rdx
    1f7a:      	movl	$0x4, %ecx
    1f7f:      	movl	$0x4, %eax
    1f84:      	movl	$0x4, %esi
    1f89:      	callq	*%rax
    1f8b:      	leaq	0x10(%rbp), %r13
    1f8f:      	movq	$0x0, (%rbp)
    1f97:      	movq	$0x0, 0x8(%rbp)
    1f9f:      	movq	$0x0, 0x10(%rbp)
    1fa7:      	movq	$0x0, 0x18(%rbp)
    1faf:      	movzwl	0x26(%rbp), %eax
    1fb3:      	cmpl	$0xa, %eax
    1fb6:      	je	0x328a <generic_kprobe_process_event+0x2f3a>
    1fbc:      	cmpl	$0x2, %eax
    1fbf:      	jne	0x32bc <generic_kprobe_process_event+0x2f6c>
    1fc5:      	leaq	0x4(%r12), %rdx
    1fca:      	movl	$0x4, %ecx
    1fcf:      	movl	$0x4, %eax
    1fd4:      	movq	%rbp, %rdi
    1fd7:      	movl	$0x4, %esi
    1fdc:      	callq	*%rax
    1fde:      	movl	$0x4, %ecx
    1fe3:      	movl	$0x4, %eax
    1fe8:      	movq	%r13, %rdi
    1feb:      	movl	$0x4, %esi
    1ff0:      	movq	%r12, %rdx
    1ff3:      	jmp	0x32ba <generic_kprobe_process_event+0x2f6a>
    1ff8:      	cmpl	$0x1c, %r13d
    1ffc:      	jg	0x22df <generic_kprobe_process_event+0x1f8f>
    2002:      	movq	%rax, %r15
    2005:      	movq	%r13, %rax
    2008:      	cmpl	$0x11, %eax
    200b:      	je	0x271e <generic_kprobe_process_event+0x23ce>
    2011:      	cmpl	$0x19, %eax
    2014:      	je	0x27e3 <generic_kprobe_process_event+0x2493>
    201a:      	cmpl	$0x1c, %eax
    201d:      	movq	0x40(%rsp), %rax
    2022:      	movq	0x20(%rsp), %rcx
    2027:      	movl	$0x4, %esi
    202c:      	jmp	0x2328 <generic_kprobe_process_event+0x1fd8>
    2031:      	leal	-0xa(%r13), %eax
    2035:      	cmpl	$0x2, %eax
    2038:      	jb	0x2334 <generic_kprobe_process_event+0x1fe4>
    203e:      	movq	%r13, %rcx
    2041:      	movq	%r14, 0x28(%rsp)
    2046:      	movq	%rbx, 0x18(%rsp)
    204b:      	leal	-0xc(%r13), %eax
    204f:      	cmpl	$0x2, %eax
    2052:      	jb	0x2367 <generic_kprobe_process_event+0x2017>
    2058:      	cmpl	$0xe, %ecx
    205b:      	movq	0x40(%rsp), %rax
    2060:      	movq	0x20(%rsp), %rcx
    2065:      	movl	$0x4, %esi
    206a:      	movq	0x18(%rsp), %rbx
    206f:      	movq	0x28(%rsp), %r14
    2074:      	movl	$0x0, %r13d
    207a:      	jne	0x1cbc <generic_kprobe_process_event+0x196c>
    2080:      	leaq	0x50(%rsp), %rdi
    2085:      	leaq	0x48(%rsp), %r12
    208a:      	movl	$0x8, %ecx
    208f:      	movl	$0x4, %eax
    2094:      	movl	$0x8, %esi
    2099:      	movq	%r12, %rdx
    209c:      	callq	*%rax
    209e:      	movq	0x50(%rsp), %rcx
    20a3:      	movl	$0x8, %edx
    20a8:      	movl	$0x4, %eax
    20ad:      	movq	0x50(%rsp), %rdx
    20b2:      	movq	%r12, %rdi
    20b5:      	movl	$0x8, %esi
    20ba:      	callq	*%rax
    20bc:      	movq	0x48(%rsp), %rdx
    20c1:      	leaq	0x4(%rbp), %rdi
    20c5:      	movl	$0x1001, %ecx           # imm = 0x1001
    20ca:      	movl	$0x2d, %eax
    20cf:      	movl	$0x1001, %esi           # imm = 0x1001
    20d4:      	callq	*%rax
    20d6:      	movq	%rax, %r13
    20d9:      	testq	%rax, %rax
    20dc:      	js	0x47f1 <generic_kprobe_process_event+0x44a1>
    20e2:      	leal	-0x1(%r13), %eax
    20e6:      	movl	%eax, (%rbp)
    20e9:      	addq	$0x3, %r13
    20ed:      	jmp	0x47f1 <generic_kprobe_process_event+0x44a1>
    20f2:      	movq	%rax, 0x10(%rsp)
    20f7:      	movq	%r15, %rbp
    20fa:      	cmpl	$0x20, %r13d
    20fe:      	jle	0x24f2 <generic_kprobe_process_event+0x21a2>
    2104:      	leal	-0x21(%r13), %eax
    2108:      	cmpl	$0x4, %eax
    210b:      	jae	0x238b <generic_kprobe_process_event+0x203b>
    2111:      	movl	$0x8, %r13d
    2117:      	movl	$0x8, %ecx
    211c:      	movl	$0x4, %eax
    2121:      	movq	%rbp, %rdi
    2124:      	movl	$0x8, %esi
    2129:      	movq	%r12, %rdx
    212c:      	callq	*%rax
    212e:      	jmp	0x4450 <generic_kprobe_process_event+0x4100>
    2133:      	cmpl	$0x27, %r13d
    2137:      	je	0x2c17 <generic_kprobe_process_event+0x28c7>
    213d:      	movq	%r13, %rax
    2140:      	cmpl	$0x28, %eax
    2143:      	je	0x2c52 <generic_kprobe_process_event+0x2902>
    2149:      	cmpl	$0x2c, %eax
    214c:      	movq	0x40(%rsp), %rax
    2151:      	movq	0x20(%rsp), %rcx
    2156:      	movl	$0x4, %esi
    215b:      	movq	0x18(%rsp), %rbx
    2160:      	movq	%r15, %r14
    2163:      	movl	$0x0, %r13d
    2169:      	jne	0x1cbc <generic_kprobe_process_event+0x196c>
    216f:      	movq	0x48(%rsp), %r12
    2174:      	movb	$0x0, 0x50(%rsp)
    2179:      	movq	%rbp, %rdi
    217c:      	movq	$0x0, 0x68(%rbp)
    2184:      	movq	$0x0, 0x60(%rbp)
    218c:      	movq	$0x0, 0x58(%rbp)
    2194:      	movq	$0x0, 0x50(%rbp)
    219c:      	movq	$0x0, 0x48(%rbp)
    21a4:      	movq	$0x0, 0x40(%rbp)
    21ac:      	movq	$0x0, 0x38(%rbp)
    21b4:      	movq	$0x0, 0x30(%rbp)
    21bc:      	movq	$0x0, 0x28(%rbp)
    21c4:      	movq	$0x0, 0x20(%rbp)
    21cc:      	movq	$0x0, 0x18(%rbp)
    21d4:      	movq	$0x0, 0x10(%rbp)
    21dc:      	movq	$0x0, 0x8(%rbp)
    21e4:      	movq	$0x0, (%rbp)
    21ec:      	movl	$0x2, %ecx
    21f1:      	movl	$0x4, %eax
    21f6:      	movl	$0x2, %esi
    21fb:      	movq	%r12, %rdx
    21fe:      	callq	*%rax
    2200:      	testq	%rax, %rax
    2203:      	js	0x355b <generic_kprobe_process_event+0x320b>
    2209:      	leaq	0x2(%r12), %r13
    220e:      	leaq	0x50(%rsp), %rdi
    2213:      	movl	$0x1, %ecx
    2218:      	movl	$0x4, %eax
    221d:      	movl	$0x1, %esi
    2222:      	movq	%r13, %rdx
    2225:      	callq	*%rax
    2227:      	testq	%rax, %rax
    222a:      	js	0x355b <generic_kprobe_process_event+0x320b>
    2230:      	movq	%rbp, %rax
    2233:      	leaq	0x4(%rbp), %rdi
    2237:      	cmpb	$0x0, 0x50(%rsp)
    223c:      	sete	0x2(%rbp)
    2240:      	je	0x3537 <generic_kprobe_process_event+0x31e7>
    2246:      	movl	$0x6c, %ecx
    224b:      	movl	$0x2d, %eax
    2250:      	movl	$0x6c, %esi
    2255:      	movq	%r13, %rdx
    2258:      	callq	*%rax
    225a:      	testl	%eax, %eax
    225c:      	js	0x355b <generic_kprobe_process_event+0x320b>
    2262:      	decb	%al
    2264:      	jmp	0x3558 <generic_kprobe_process_event+0x3208>
    2269:      	movq	%rax, %rbp
    226c:      	movq	%r13, %rax
    226f:      	cmpl	$0x7, %r13d
    2273:      	jg	0x25b0 <generic_kprobe_process_event+0x2260>
    2279:      	cmpl	$0x2, %eax
    227c:      	je	0x2cdf <generic_kprobe_process_event+0x298f>
    2282:      	cmpl	$0x3, %eax
    2285:      	movq	0x18(%rsp), %rbx
    228a:      	movq	0x28(%rsp), %r14
    228f:      	movl	$0x0, %r13d
    2295:      	jne	0x1cad <generic_kprobe_process_event+0x195d>
    229b:      	leaq	0x90(%rbp), %r13
    22a2:      	movq	0x10(%rsp), %rcx
    22a7:      	andl	$0xf, %ecx
    22aa:      	movq	%rcx, %rax
    22ad:      	cmpl	$0x2, %ecx
    22b0:      	jle	0x3412 <generic_kprobe_process_event+0x30c2>
    22b6:      	cmpl	$0x3, %eax
    22b9:      	je	0x3700 <generic_kprobe_process_event+0x33b0>
    22bf:      	cmpl	$0x4, %eax
    22c2:      	je	0x370b <generic_kprobe_process_event+0x33bb>
    22c8:      	cmpl	$0x5, %eax
    22cb:      	jne	0x3ac0 <generic_kprobe_process_event+0x3770>
    22d1:      	movq	%rbp, %rax
    22d4:      	addq	$0x5e70, %rax           # imm = 0x5E70
    22da:      	jmp	0x371f <generic_kprobe_process_event+0x33cf>
    22df:      	leaq	0x48(%rsp), %rdx
    22e4:      	movl	$0x4, %r13d
    22ea:      	movl	$0x2, %ecx
    22ef:      	movl	$0x4, %eax
    22f4:      	movq	%rbp, %rdi
    22f7:      	movl	$0x2, %esi
    22fc:      	callq	*%rax
    22fe:      	jmp	0x1cad <generic_kprobe_process_event+0x195d>
    2303:      	cmpl	$0x1, %r13d
    2307:      	je	0x2367 <generic_kprobe_process_event+0x2017>
    2309:      	movq	%r13, %rax
    230c:      	cmpl	$0x4, %eax
    230f:      	movq	0x40(%rsp), %rax
    2314:      	movq	0x20(%rsp), %rcx
    2319:      	movl	$0x4, %esi
    231e:      	movq	0x18(%rsp), %rbx
    2323:      	movq	0x28(%rsp), %r14
    2328:      	movl	$0x0, %r13d
    232e:      	jne	0x1cbc <generic_kprobe_process_event+0x196c>
    2334:      	movl	$0x8, %r13d
    233a:      	leaq	0x48(%rsp), %rdx
    233f:      	movl	$0x8, %ecx
    2344:      	movl	$0x4, %eax
    2349:      	movq	%rbp, %rdi
    234c:      	movl	$0x8, %esi
    2351:      	callq	*%rax
    2353:      	movl	$0x4, %esi
    2358:      	movq	0x20(%rsp), %rcx
    235d:      	movq	0x40(%rsp), %rax
    2362:      	jmp	0x1cbc <generic_kprobe_process_event+0x196c>
    2367:      	leaq	0x48(%rsp), %rdx
    236c:      	movl	$0x4, %r13d
    2372:      	movl	$0x4, %ecx
    2377:      	movl	$0x4, %eax
    237c:      	movq	%rbp, %rdi
    237f:      	movl	$0x4, %esi
    2384:      	callq	*%rax
    2386:      	jmp	0x47f1 <generic_kprobe_process_event+0x44a1>
    238b:      	movq	%r13, %rcx
    238e:      	cmpl	$0x2b, %ecx
    2391:      	je	0x30a6 <generic_kprobe_process_event+0x2d56>
    2397:      	cmpl	$0x29, %ecx
    239a:      	movq	0x18(%rsp), %rbx
    239f:      	movq	0x28(%rsp), %r14
    23a4:      	movl	$0x0, %r13d
    23aa:      	jne	0x1cad <generic_kprobe_process_event+0x195d>
    23b0:      	addq	$0x18, %r12
    23b4:      	leaq	0x50(%rsp), %rdi
    23b9:      	movl	$0x4, %ebx
    23be:      	movl	$0x8, %ecx
    23c3:      	movl	$0x4, %eax
    23c8:      	movl	$0x8, %esi
    23cd:      	movq	%r12, %rdx
    23d0:      	callq	*%rax
    23d2:      	movq	0x50(%rsp), %r12
    23d7:      	testq	%r12, %r12
    23da:      	je	0x36bc <generic_kprobe_process_event+0x336c>
    23e0:      	movq	%rbp, %r15
    23e3:      	movq	%r12, 0x28(%rbp)
    23e7:      	leaq	0x26(%rbp), %rdi
    23eb:      	leaq	0x10(%r12), %rdx
    23f0:      	movl	$0x2, %ecx
    23f5:      	movl	$0x4, %eax
    23fa:      	movl	$0x2, %esi
    23ff:      	callq	*%rax
    2401:      	leaq	0x3a(%rbp), %rdi
    2405:      	leaq	0x12(%r12), %rdx
    240a:      	movl	$0x1, %ecx
    240f:      	movl	$0x4, %eax
    2414:      	movl	$0x1, %esi
    2419:      	callq	*%rax
    241b:      	leaq	0x38(%rbp), %rdi
    241f:      	leaq	0x226(%r12), %rdx
    2427:      	movl	$0x2, %ecx
    242c:      	movl	$0x4, %eax
    2431:      	movl	$0x2, %esi
    2436:      	callq	*%rax
    2438:      	leaq	0x24(%rbp), %rdi
    243c:      	leaq	0x224(%r12), %rdx
    2444:      	movl	$0x2, %ecx
    2449:      	movl	$0x4, %eax
    244e:      	movl	$0x2, %esi
    2453:      	callq	*%rax
    2455:      	leaq	0x30(%rbp), %rdi
    2459:      	leaq	0x21c(%r12), %rdx
    2461:      	movl	$0x4, %eax
    2466:      	movl	$0x4, %esi
    246b:      	callq	*%rax
    246d:      	leaq	0x34(%rbp), %rdi
    2471:      	leaq	0x218(%r12), %rdx
    2479:      	movl	$0x4, %eax
    247e:      	movl	$0x4, %esi
    2483:      	callq	*%rax
    2485:      	leaq	0x10(%rbp), %r13
    2489:      	movq	$0x0, (%rbp)
    2491:      	movq	$0x0, 0x8(%rbp)
    2499:      	movq	$0x0, 0x10(%rbp)
    24a1:      	movq	$0x0, 0x18(%rbp)
    24a9:      	movzwl	0x26(%rbp), %eax
    24ad:      	cmpl	$0xa, %eax
    24b0:      	je	0x3644 <generic_kprobe_process_event+0x32f4>
    24b6:      	cmpl	$0x2, %eax
    24b9:      	jne	0x3676 <generic_kprobe_process_event+0x3326>
    24bf:      	leaq	0x4(%r12), %rdx
    24c4:      	movl	$0x4, %ecx
    24c9:      	movl	$0x4, %eax
    24ce:      	movq	%rbp, %rdi
    24d1:      	movl	$0x4, %esi
    24d6:      	callq	*%rax
    24d8:      	movl	$0x4, %ecx
    24dd:      	movl	$0x4, %eax
    24e2:      	movq	%r13, %rdi
    24e5:      	movl	$0x4, %esi
    24ea:      	movq	%r12, %rdx
    24ed:      	jmp	0x3674 <generic_kprobe_process_event+0x3324>
    24f2:      	cmpl	$0x1a, %r13d
    24f6:      	je	0x313c <generic_kprobe_process_event+0x2dec>
    24fc:      	movq	%r13, %rax
    24ff:      	cmpl	$0x1b, %eax
    2502:      	movq	0x18(%rsp), %rbx
    2507:      	movq	0x28(%rsp), %r14
    250c:      	movl	$0x0, %r13d
    2512:      	jne	0x1cad <generic_kprobe_process_event+0x195d>
    2518:      	movq	$0x0, 0x48(%rbp)
    2520:      	movq	$0x0, 0x40(%rbp)
    2528:      	movq	$0x0, 0x38(%rbp)
    2530:      	movq	$0x0, 0x30(%rbp)
    2538:      	movq	$0x0, 0x28(%rbp)
    2540:      	movq	$0x0, 0x20(%rbp)
    2548:      	movq	$0x0, 0x18(%rbp)
    2550:      	movq	$0x0, 0x10(%rbp)
    2558:      	movq	$0x0, 0x8(%rbp)
    2560:      	movq	$0x0, (%rbp)
    2568:      	leaq	0x10(%rbp), %rdi
    256c:      	leaq	0x18(%r12), %rdx
    2571:      	movl	$0x3f, %ecx
    2576:      	movl	$0x2d, %eax
    257b:      	movl	$0x3f, %esi
    2580:      	callq	*%rax
    2582:      	testq	%rax, %rax
    2585:      	js	0x31ae <generic_kprobe_process_event+0x2e5e>
    258b:      	addq	$0x8, %rbp
    258f:      	addq	$0x348, %r12            # imm = 0x348
    2596:      	movl	$0x8, %ecx
    259b:      	movl	$0x4, %eax
    25a0:      	movq	%rbp, %rdi
    25a3:      	movl	$0x8, %esi
    25a8:      	movq	%r12, %rdx
    25ab:      	jmp	0x2f2f <generic_kprobe_process_event+0x2bdf>
    25b0:      	cmpl	$0x8, %eax
    25b3:      	je	0x2d4e <generic_kprobe_process_event+0x29fe>
    25b9:      	cmpl	$0x12, %eax
    25bc:      	movq	0x18(%rsp), %rbx
    25c1:      	movq	0x28(%rsp), %r14
    25c6:      	movl	$0x0, %r13d
    25cc:      	jne	0x1cad <generic_kprobe_process_event+0x195d>
    25d2:      	movq	0xa0(%rsp), %r13
    25da:      	andl	$0x3ff, %r13d           # imm = 0x3FF
    25e1:      	movl	$0x4, %eax
    25e6:      	movq	%r15, %rdi
    25e9:      	movl	%r13d, %esi
    25ec:      	movq	%r12, %rdx
    25ef:      	callq	*%rax
    25f1:      	jmp	0x1cad <generic_kprobe_process_event+0x195d>
    25f6:      	cmpl	$0x13, %eax
    25f9:      	je	0x3050 <generic_kprobe_process_event+0x2d00>
    25ff:      	cmpl	$0x14, %eax
    2602:      	movq	0x18(%rsp), %rbx
    2607:      	movq	0x28(%rsp), %r14
    260c:      	movl	$0x0, %r13d
    2612:      	jne	0x1cad <generic_kprobe_process_event+0x195d>
    2618:      	movq	$0x0, 0x50(%rsp)
    2621:      	movq	%r12, %r13
    2624:      	leaq	0x110(%r12), %rdx
    262c:      	leaq	0x50(%rsp), %rdi
    2631:      	movl	$0x8, %ecx
    2636:      	movl	$0x4, %eax
    263b:      	addq	$0xd8, %r12
    2642:      	movl	$0x8, %esi
    2647:      	callq	*%rax
    2649:      	movq	0x50(%rsp), %rcx
    264e:      	movl	$0x80, %edx
    2653:      	movl	$0x2d, %eax
    2658:      	movq	0x50(%rsp), %rdx
    265d:      	movq	%r15, %rdi
    2660:      	movl	$0x80, %esi
    2665:      	callq	*%rax
    2667:      	leaq	0x90(%r15), %rdi
    266e:      	movl	$0x4, %ecx
    2673:      	movl	$0x4, %eax
    2678:      	movl	$0x4, %esi
    267d:      	movq	%r12, %rdx
    2680:      	callq	*%rax
    2682:      	leaq	0x80(%r15), %rdi
    2689:      	leaq	0xe0(%r13), %rdx
    2690:      	movl	$0x8, %ecx
    2695:      	movl	$0x4, %eax
    269a:      	movl	$0x8, %esi
    269f:      	callq	*%rax
    26a1:      	addq	$0x88, %r15
    26a8:      	addq	$0x118, %r13            # imm = 0x118
    26af:      	movl	$0x8, %ecx
    26b4:      	movl	$0x4, %eax
    26b9:      	movq	%r15, %rdi
    26bc:      	movl	$0x8, %esi
    26c1:      	movq	%r13, %rdx
    26c4:      	callq	*%rax
    26c6:      	movl	$0x98, %r13d
    26cc:      	jmp	0x1cad <generic_kprobe_process_event+0x195d>
    26d1:      	movq	%r13, %rcx
    26d4:      	cmpl	$0x26, %ecx
    26d7:      	movq	0x40(%rsp), %rax
    26dc:      	movq	0x20(%rsp), %rcx
    26e1:      	movl	$0x4, %esi
    26e6:      	movq	0x18(%rsp), %rbx
    26eb:      	movq	%r15, %r14
    26ee:      	movl	$0x0, %r13d
    26f4:      	jne	0x1cbc <generic_kprobe_process_event+0x196c>
    26fa:      	movq	0x48(%rsp), %rsi
    26ff:      	movzwl	%si, %edx
    2702:      	addq	%rbx, %rdx
    2705:      	shrl	$0x10, %esi
    2708:      	andl	$0xfff, %esi            # imm = 0xFFF
    270e:      	leaq	0x4(%rbp), %rdi
    2712:      	incl	%esi
    2714:      	movl	$0x2d, %eax
    2719:      	jmp	0x2c34 <generic_kprobe_process_event+0x28e4>
    271e:      	movq	$0x0, 0x58(%rsp)
    2727:      	movl	$0xe, %eax
    272c:      	callq	*%rax
    272e:      	shrq	$0x20, %rax
    2732:      	movq	%rax, 0x50(%rsp)
    2737:      	leaq	0x90(%rsp), %rdi
    273f:      	leaq	0x48(%rsp), %rdx
    2744:      	movl	$0x4, %ecx
    2749:      	movl	$0x4, %eax
    274e:      	movl	$0x4, %esi
    2753:      	callq	*%rax
    2755:      	movl	0x90(%rsp), %eax
    275c:      	movl	%eax, 0x58(%rsp)
    2760:      	movq	(%rip), %rdi            # 0x2767 <generic_kprobe_process_event+0x2417>
    2767:      	leaq	0x50(%rsp), %rsi
    276c:      	movl	$0x1, %eax
    2771:      	callq	*%rax
    2773:      	testq	%rax, %rax
    2776:      	je	0x31d5 <generic_kprobe_process_event+0x2e85>
    277c:      	movq	%rax, %r13
    277f:      	movl	(%rax), %r15d
    2782:      	leaq	0x90(%rsp), %rdx
    278a:      	movl	$0x4, %eax
    278f:      	movq	%rbp, %r12
    2792:      	movl	$0x4, %ebp
    2797:      	movq	%r12, %rdi
    279a:      	movl	$0x4, %esi
    279f:      	callq	*%rax
    27a1:      	andl	$0xfff, %r15d           # imm = 0xFFF
    27a8:      	leaq	0x4(%r12), %rdi
    27ad:      	leaq	0x4(%r15), %rsi
    27b1:      	movl	$0x4, %eax
    27b6:      	movq	%r13, %rdx
    27b9:      	callq	*%rax
    27bb:      	leaq	(%r12,%r15), %rdi
    27bf:      	addq	$0x8, %rdi
    27c3:      	leaq	(%r15,%r13), %rdx
    27c7:      	addq	$0x4, %rdx
    27cb:      	movl	$0x4, %eax
    27d0:      	movl	$0x4, %esi
    27d5:      	callq	*%rax
    27d7:      	addq	$0xc, %r15
    27db:      	movq	%r15, %r13
    27de:      	jmp	0x1cad <generic_kprobe_process_event+0x195d>
    27e3:      	movq	0x48(%rsp), %r13
    27e8:      	leaq	0xd0(%rsp), %rdi
    27f0:      	movl	$0x1, %ecx
    27f5:      	movl	$0x4, %eax
    27fa:      	movl	$0x1, %esi
    27ff:      	movq	%r13, %rdx
    2802:      	callq	*%rax
    2804:      	cmpb	$0x1, 0xd0(%rsp)
    280c:      	jne	0x31b6 <generic_kprobe_process_event+0x2e66>
    2812:      	addq	$0x10, %r13
    2816:      	leaq	0x90(%rsp), %rdi
    281e:      	movl	$0x8, %ebp
    2823:      	movl	$0x8, %ecx
    2828:      	movl	$0x4, %eax
    282d:      	movl	$0x8, %esi
    2832:      	movq	%r13, %rdx
    2835:      	callq	*%rax
    2837:      	movq	0x90(%rsp), %rdx
    283f:      	leaq	0xb0(%rsp), %rdi
    2847:      	movl	$0x8, %ecx
    284c:      	movl	$0x4, %eax
    2851:      	movl	$0x8, %esi
    2856:      	callq	*%rax
    2858:      	movq	0x90(%rsp), %rdx
    2860:      	addq	$0x8, %rdx
    2864:      	leaq	0x38(%rsp), %rdi
    2869:      	movl	$0x8, %ecx
    286e:      	movl	$0x4, %eax
    2873:      	movl	$0x8, %esi
    2878:      	callq	*%rax
    287a:      	movq	0xb0(%rsp), %rax
    2882:      	movq	%rax, 0xe8(%rsp)
    288a:      	movq	0x38(%rsp), %rax
    288f:      	movq	%rax, 0x30(%rsp)
    2894:      	movq	0xa8(%rsp), %rax
    289c:      	addq	%r15, %rax
    289f:      	addq	$0x90, %rax
    28a5:      	movq	%rax, 0xa0(%rsp)
    28ad:      	testb	$0x20, 0x10(%rsp)
    28b2:      	je	0x35a9 <generic_kprobe_process_event+0x3259>
    28b8:      	cmpq	$0x1000, 0x30(%rsp)     # imm = 0x1000
    28c1:      	jb	0x357d <generic_kprobe_process_event+0x322d>
    28c7:      	movq	0xa0(%rsp), %rax
    28cf:      	movl	$0x1, (%rax)
    28d5:      	movl	$0x0, 0xc0(%rsp)
    28e0:      	movq	(%rip), %rdi            # 0x28e7 <generic_kprobe_process_event+0x2597>
    28e7:      	leaq	0xc0(%rsp), %rsi
    28ef:      	movl	$0x1, %eax
    28f4:      	callq	*%rax
    28f6:      	movq	%rax, 0x10(%rsp)
    28fb:      	testq	%rax, %rax
    28fe:      	je	0x3c84 <generic_kprobe_process_event+0x3934>
    2904:      	movq	0x10(%rsp), %r12
    2909:      	movl	$0x18, (%r12)
    2911:      	movl	$0xe, %eax
    2916:      	callq	*%rax
    2918:      	leaq	0x10(%r12), %r15
    291d:      	movq	%rax, 0x10(%r12)
    2922:      	cmpq	$-0x16, %rax
    2926:      	jne	0x294a <generic_kprobe_process_event+0x25fa>
    2928:      	leaq	0x20(%rbx), %rdx
    292c:      	leaq	0x50(%rsp), %rdi
    2931:      	movl	$0x8, %ecx
    2936:      	movl	$0x4, %eax
    293b:      	movl	$0x8, %esi
    2940:      	callq	*%rax
    2942:      	movq	0x50(%rsp), %rax
    2947:      	movq	%rax, (%r15)
    294a:      	movl	$0x7d, %eax
    294f:      	callq	*%rax
    2951:      	movq	0x10(%rsp), %rsi
    2956:      	movq	%rax, 0x18(%rsi)
    295a:      	movq	(%r15), %rax
    295d:      	movq	0x8(%r15), %rcx
    2961:      	movq	0xa0(%rsp), %rdx
    2969:      	movq	%rax, 0x14(%rdx)
    296d:      	movq	%rcx, 0x1c(%rdx)
    2971:      	addq	$0x20, %rsi
    2975:      	movq	%rsi, 0xa8(%rsp)
    297d:      	movl	$0xa, %r15d
    2983:      	xorl	%ebp, %ebp
    2985:      	movq	0x30(%rsp), %r13
    298a:      	subq	%rbp, %r13
    298d:      	js	0x3ef7 <generic_kprobe_process_event+0x3ba7>
    2993:      	movq	0xe8(%rsp), %rax
    299b:      	leaq	(%rax,%rbp), %rdx
    299f:      	cmpq	$0x7fe0, %r13           # imm = 0x7FE0
    29a6:      	movl	$0x7fe0, %eax           # imm = 0x7FE0
    29ab:      	cmovaeq	%rax, %r13
    29af:      	movl	$0x4, %eax
    29b4:      	movq	0xa8(%rsp), %rdi
    29bc:      	movl	%r13d, %esi
    29bf:      	callq	*%rax
    29c1:      	testl	%eax, %eax
    29c3:      	js	0x2a36 <generic_kprobe_process_event+0x26e6>
    29c5:      	leal	0x20(%r13), %r12d
    29c9:      	movq	0x10(%rsp), %rax
    29ce:      	movl	%r12d, 0x4(%rax)
    29d2:      	movl	$0x0, 0x50(%rsp)
    29da:      	movl	$0x1, %eax
    29df:      	movq	(%rip), %rdi            # 0x29e6 <generic_kprobe_process_event+0x2696>
    29e6:      	leaq	0x50(%rsp), %rsi
    29eb:      	callq	*%rax
    29ed:      	testq	%rax, %rax
    29f0:      	je	0x2a18 <generic_kprobe_process_event+0x26c8>
    29f2:      	cmpb	$0x0, 0x28(%rax)
    29f6:      	je	0x2a18 <generic_kprobe_process_event+0x26c8>
    29f8:      	movl	$0x19, %eax
    29fd:      	movq	%rbx, %rdi
    2a00:      	movq	0x10(%rsp), %rcx
    2a05:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    2a0a:      	movq	(%rip), %rsi            # 0x2a11 <generic_kprobe_process_event+0x26c1>
    2a11:      	movq	%r12, %r8
    2a14:      	callq	*%rax
    2a16:      	jmp	0x2a32 <generic_kprobe_process_event+0x26e2>
    2a18:      	movl	$0x82, %eax
    2a1d:      	movq	0x10(%rsp), %rsi
    2a22:      	xorl	%ecx, %ecx
    2a24:      	movq	(%rip), %rdi            # 0x2a2b <generic_kprobe_process_event+0x26db>
    2a2b:      	movq	%r12, %rdx
    2a2e:      	xorl	%ecx, %ecx
    2a30:      	callq	*%rax
    2a32:      	testl	%eax, %eax
    2a34:      	jns	0x2a39 <generic_kprobe_process_event+0x26e9>
    2a36:      	movslq	%eax, %r13
    2a39:      	testl	%r13d, %r13d
    2a3c:      	js	0x3f00 <generic_kprobe_process_event+0x3bb0>
    2a42:      	andl	$0x7fffffff, %r13d      # imm = 0x7FFFFFFF
    2a49:      	addq	%r13, %rbp
    2a4c:      	cmpq	0x30(%rsp), %rbp
    2a51:      	je	0x3f5a <generic_kprobe_process_event+0x3c0a>
    2a57:      	decl	%r15d
    2a5a:      	jne	0x2985 <generic_kprobe_process_event+0x2635>
    2a60:      	jmp	0x42b2 <generic_kprobe_process_event+0x3f62>
    2a65:      	movq	0x48(%rsp), %r13
    2a6a:      	movq	%rbp, %rbx
    2a6d:      	leaq	0x28(%rbp), %rdi
    2a71:      	leaq	0x98(%r13), %rdx
    2a78:      	movl	$0x4, %ecx
    2a7d:      	movl	$0x4, %eax
    2a82:      	movl	$0x4, %esi
    2a87:      	callq	*%rax
    2a89:      	leaq	0x2c(%rbp), %rdi
    2a8d:      	leaq	0x70(%r13), %rdx
    2a91:      	movl	$0x4, %ecx
    2a96:      	movl	$0x4, %eax
    2a9b:      	movl	$0x4, %esi
    2aa0:      	callq	*%rax
    2aa2:      	leaq	0x30(%rbp), %rdi
    2aa6:      	leaq	0x90(%r13), %rdx
    2aad:      	movl	$0x4, %ecx
    2ab2:      	movl	$0x4, %eax
    2ab7:      	movl	$0x4, %esi
    2abc:      	callq	*%rax
    2abe:      	leaq	0x34(%rbp), %rdi
    2ac2:      	leaq	0xa8(%r13), %rdx
    2ac9:      	movl	$0x4, %ecx
    2ace:      	movl	$0x4, %eax
    2ad3:      	movl	$0x4, %esi
    2ad8:      	callq	*%rax
    2ada:      	movq	$0x0, 0x50(%rsp)
    2ae3:      	leaq	0xc8(%r13), %rdx
    2aea:      	leaq	0x50(%rsp), %rdi
    2aef:      	movl	$0x8, %ecx
    2af4:      	movl	$0x4, %eax
    2af9:      	movl	$0x8, %esi
    2afe:      	callq	*%rax
    2b00:      	leaq	0xb8(%r13), %rdx
    2b07:      	leaq	0x38(%rsp), %rdi
    2b0c:      	movl	$0x2, %ecx
    2b11:      	movl	$0x4, %eax
    2b16:      	movl	$0x2, %esi
    2b1b:      	callq	*%rax
    2b1d:      	movzwl	0x38(%rsp), %r12d
    2b23:      	addq	0x50(%rsp), %r12
    2b28:      	leaq	0xdc(%rsp), %rdi
    2b30:      	movl	$0x1, %ecx
    2b35:      	movl	$0x4, %eax
    2b3a:      	movl	$0x1, %esi
    2b3f:      	movq	%r12, %rdx
    2b42:      	callq	*%rax
    2b44:      	movzbl	0xdc(%rsp), %eax
    2b4c:      	shrl	$0x4, %eax
    2b4f:      	cmpl	$0x6, %eax
    2b52:      	je	0x31e1 <generic_kprobe_process_event+0x2e91>
    2b58:      	cmpl	$0x4, %eax
    2b5b:      	jne	0x47eb <generic_kprobe_process_event+0x449b>
    2b61:      	leaq	0x9(%r12), %rdx
    2b66:      	leaq	0xd0(%rsp), %rdi
    2b6e:      	movl	$0x1, %ecx
    2b73:      	movl	$0x4, %eax
    2b78:      	movl	$0x1, %esi
    2b7d:      	callq	*%rax
    2b7f:      	movzbl	0xd0(%rsp), %eax
    2b87:      	movq	%rbp, %rdi
    2b8a:      	movw	%ax, 0x24(%rbp)
    2b8e:      	movw	$0x2, 0x26(%rbp)
    2b94:      	leaq	0xc(%r12), %rdx
    2b99:      	movq	$0x0, (%rbp)
    2ba1:      	movq	$0x0, 0x8(%rbp)
    2ba9:      	movq	$0x0, 0x10(%rbp)
    2bb1:      	movq	$0x0, 0x18(%rbp)
    2bb9:      	movl	$0x4, %ecx
    2bbe:      	movl	$0x4, %eax
    2bc3:      	leaq	0x10(%rbp), %rbx
    2bc7:      	movl	$0x4, %esi
    2bcc:      	callq	*%rax
    2bce:      	addq	$0x10, %r12
    2bd2:      	movl	$0x4, %ecx
    2bd7:      	movl	$0x4, %eax
    2bdc:      	movq	%rbx, %rdi
    2bdf:      	movl	$0x4, %esi
    2be4:      	movq	%r12, %rdx
    2be7:      	callq	*%rax
    2be9:      	leaq	0xb6(%r13), %rdx
    2bf0:      	leaq	0xc0(%rsp), %rdi
    2bf8:      	movl	$0x2, %ecx
    2bfd:      	movl	$0x4, %eax
    2c02:      	movl	$0x2, %esi
    2c07:      	callq	*%rax
    2c09:      	movzbl	0xd0(%rsp), %r15d
    2c12:      	jmp	0x4690 <generic_kprobe_process_event+0x4340>
    2c17:      	movl	$0x120, %edx            # imm = 0x120
    2c1c:      	addq	0x48(%rsp), %rdx
    2c21:      	leaq	0x4(%rbp), %rdi
    2c25:      	movl	$0x11, %ecx
    2c2a:      	movl	$0x2d, %eax
    2c2f:      	movl	$0x11, %esi
    2c34:      	callq	*%rax
    2c36:      	movq	%rax, %r13
    2c39:      	testq	%rax, %rax
    2c3c:      	js	0x3561 <generic_kprobe_process_event+0x3211>
    2c42:      	leal	-0x1(%r13), %eax
    2c46:      	movl	%eax, (%rbp)
    2c49:      	addq	$0x3, %r13
    2c4d:      	jmp	0x3561 <generic_kprobe_process_event+0x3211>
    2c52:      	movq	0x48(%rsp), %r12
    2c57:      	movq	%rbp, %rdi
    2c5a:      	movq	$0x0, 0x10(%rbp)
    2c62:      	movq	$0x0, 0x8(%rbp)
    2c6a:      	movq	$0x0, (%rbp)
    2c72:      	movl	$0x2, %ecx
    2c77:      	movl	$0x4, %eax
    2c7c:      	movl	$0x2, %esi
    2c81:      	movq	%r12, %rdx
    2c84:      	callq	*%rax
    2c86:      	testq	%rax, %rax
    2c89:      	js	0x3475 <generic_kprobe_process_event+0x3125>
    2c8f:      	movzwl	(%rbp), %eax
    2c93:      	cmpl	$0xa, %eax
    2c96:      	je	0x3432 <generic_kprobe_process_event+0x30e2>
    2c9c:      	cmpl	$0x2, %eax
    2c9f:      	jne	0x346b <generic_kprobe_process_event+0x311b>
    2ca5:      	leaq	0x4(%r12), %rdx
    2caa:      	leaq	0x50(%rsp), %rdi
    2caf:      	movl	$0x4, %ecx
    2cb4:      	movl	$0x4, %eax
    2cb9:      	movl	$0x4, %esi
    2cbe:      	callq	*%rax
    2cc0:      	movl	0x50(%rsp), %eax
    2cc4:      	movq	%rax, 0x8(%rbp)
    2cc8:      	leaq	0x2(%rbp), %rdi
    2ccc:      	addq	$0x2, %r12
    2cd0:      	movl	$0x2, %ecx
    2cd5:      	movl	$0x4, %eax
    2cda:      	jmp	0x3461 <generic_kprobe_process_event+0x3111>
    2cdf:      	movq	0xa8(%rsp), %rax
    2ce7:      	addq	%rbp, %rax
    2cea:      	addq	$0x90, %rax
    2cf0:      	movq	%rax, 0x30(%rsp)
    2cf5:      	movq	$0x0, 0x48(%rsp)
    2cfe:      	testb	$0x10, 0x10(%rsp)
    2d03:      	jne	0x3342 <generic_kprobe_process_event+0x2ff2>
    2d09:      	movl	0x10(%rsp), %r15d
    2d0e:      	movq	0xa0(%rsp), %rdx
    2d16:      	andl	$0xf, %edx
    2d19:      	xorl	%eax, %eax
    2d1b:      	movq	%rdx, %rcx
    2d1e:      	cmpl	$0x2, %edx
    2d21:      	jle	0x3626 <generic_kprobe_process_event+0x32d6>
    2d27:      	cmpl	$0x3, %ecx
    2d2a:      	je	0x3c8f <generic_kprobe_process_event+0x393f>
    2d30:      	cmpl	$0x4, %ecx
    2d33:      	je	0x3c98 <generic_kprobe_process_event+0x3948>
    2d39:      	cmpl	$0x5, %ecx
    2d3c:      	jne	0x3cab <generic_kprobe_process_event+0x395b>
    2d42:      	leaq	0x5e70(%rbp), %rax
    2d49:      	jmp	0x3ca8 <generic_kprobe_process_event+0x3958>
    2d4e:      	movq	%r15, %rbx
    2d51:      	leaq	0x28(%r15), %r13
    2d55:      	leaq	0x40(%r15), %rbp
    2d59:      	leaq	0x8(%r12), %rdx
    2d5e:      	movl	$0x4, %ecx
    2d63:      	movl	$0x4, %eax
    2d68:      	movq	%r15, %rdi
    2d6b:      	movl	$0x4, %esi
    2d70:      	callq	*%rax
    2d72:      	leaq	0x4(%r15), %rdi
    2d76:      	leaq	0xc(%r12), %rdx
    2d7b:      	movl	$0x4, %ecx
    2d80:      	movl	$0x4, %eax
    2d85:      	movl	$0x4, %esi
    2d8a:      	callq	*%rax
    2d8c:      	leaq	0x10(%r15), %rdi
    2d90:      	leaq	0x18(%r12), %rdx
    2d95:      	movl	$0x4, %ecx
    2d9a:      	movl	$0x4, %eax
    2d9f:      	movl	$0x4, %esi
    2da4:      	callq	*%rax
    2da6:      	leaq	0x14(%r15), %rdi
    2daa:      	leaq	0x1c(%r12), %rdx
    2daf:      	movl	$0x4, %ecx
    2db4:      	movl	$0x4, %eax
    2db9:      	movl	$0x4, %esi
    2dbe:      	callq	*%rax
    2dc0:      	leaq	0x8(%r15), %rdi
    2dc4:      	leaq	0x10(%r12), %rdx
    2dc9:      	movl	$0x4, %ecx
    2dce:      	movl	$0x4, %eax
    2dd3:      	movl	$0x4, %esi
    2dd8:      	callq	*%rax
    2dda:      	leaq	0xc(%r15), %rdi
    2dde:      	leaq	0x14(%r12), %rdx
    2de3:      	movl	$0x4, %ecx
    2de8:      	movl	$0x4, %eax
    2ded:      	movl	$0x4, %esi
    2df2:      	callq	*%rax
    2df4:      	leaq	0x18(%r15), %rdi
    2df8:      	leaq	0x20(%r12), %rdx
    2dfd:      	movl	$0x4, %ecx
    2e02:      	movl	$0x4, %eax
    2e07:      	movl	$0x4, %esi
    2e0c:      	callq	*%rax
    2e0e:      	leaq	0x1c(%r15), %rdi
    2e12:      	leaq	0x24(%r12), %rdx
    2e17:      	movl	$0x4, %ecx
    2e1c:      	movl	$0x4, %eax
    2e21:      	movl	$0x4, %esi
    2e26:      	callq	*%rax
    2e28:      	movl	$0x0, 0x24(%r15)
    2e30:      	leaq	0x20(%r15), %rdi
    2e34:      	leaq	0x28(%r12), %rdx
    2e39:      	movl	$0x4, %ecx
    2e3e:      	movl	$0x4, %eax
    2e43:      	movl	$0x4, %esi
    2e48:      	callq	*%rax
    2e4a:      	leaq	0x30(%r15), %rdi
    2e4e:      	leaq	0x40(%r12), %rdx
    2e53:      	movl	$0x8, %ecx
    2e58:      	movl	$0x4, %eax
    2e5d:      	movl	$0x8, %esi
    2e62:      	callq	*%rax
    2e64:      	leaq	0x38(%r15), %rdi
    2e68:      	leaq	0x30(%r12), %rdx
    2e6d:      	movl	$0x8, %ecx
    2e72:      	movl	$0x4, %eax
    2e77:      	movl	$0x8, %esi
    2e7c:      	callq	*%rax
    2e7e:      	leaq	0x38(%r12), %rdx
    2e83:      	movl	$0x8, %ecx
    2e88:      	movl	$0x4, %eax
    2e8d:      	movq	%r13, %rdi
    2e90:      	movl	$0x8, %esi
    2e95:      	callq	*%rax
    2e97:      	addq	$0x90, %r12
    2e9e:      	leaq	0x50(%rsp), %rdi
    2ea3:      	movl	$0x8, %ecx
    2ea8:      	movl	$0x4, %eax
    2ead:      	movl	$0x8, %esi
    2eb2:      	movq	%r12, %rdx
    2eb5:      	callq	*%rax
    2eb7:      	movq	0x50(%rsp), %r13
    2ebc:      	leaq	0xc8(%r13), %rdx
    2ec3:      	movl	$0x4, %ecx
    2ec8:      	movl	$0x4, %eax
    2ecd:      	movq	%rbp, %rdi
    2ed0:      	movl	$0x4, %esi
    2ed5:      	callq	*%rax
    2ed7:      	leaq	0x44(%r15), %rdi
    2edb:      	leaq	0xcc(%r13), %rdx
    2ee2:      	movl	$0x4, %ecx
    2ee7:      	movl	$0x4, %eax
    2eec:      	movl	$0x4, %esi
    2ef1:      	callq	*%rax
    2ef3:      	leaq	0x48(%r15), %rdi
    2ef7:      	leaq	0xd0(%r13), %rdx
    2efe:      	movl	$0x4, %ecx
    2f03:      	movl	$0x4, %eax
    2f08:      	movl	$0x4, %esi
    2f0d:      	callq	*%rax
    2f0f:      	addq	$0x4c, %rbx
    2f13:      	addq	$0x158, %r13            # imm = 0x158
    2f1a:      	movl	$0x4, %ecx
    2f1f:      	movl	$0x4, %eax
    2f24:      	movq	%rbx, %rdi
    2f27:      	movl	$0x4, %esi
    2f2c:      	movq	%r13, %rdx
    2f2f:      	callq	*%rax
    2f31:      	movl	$0x50, %r13d
    2f37:      	jmp	0x4450 <generic_kprobe_process_event+0x4100>
    2f3c:      	leaq	0xc8(%r12), %rdx
    2f44:      	movl	$0x4, %ecx
    2f49:      	movl	$0x4, %eax
    2f4e:      	movq	%r15, %rdi
    2f51:      	movl	$0x4, %esi
    2f56:      	callq	*%rax
    2f58:      	leaq	0x4(%r15), %rdi
    2f5c:      	leaq	0xcc(%r12), %rdx
    2f64:      	movl	$0x4, %ecx
    2f69:      	movl	$0x4, %eax
    2f6e:      	movl	$0x4, %esi
    2f73:      	callq	*%rax
    2f75:      	leaq	0x8(%r15), %rdi
    2f79:      	leaq	0xd0(%r12), %rdx
    2f81:      	movl	$0x4, %ecx
    2f86:      	movl	$0x4, %eax
    2f8b:      	movl	$0x4, %esi
    2f90:      	callq	*%rax
    2f92:      	addq	$0xc, %r15
    2f96:      	addq	$0x158, %r12            # imm = 0x158
    2f9d:      	movl	$0x4, %ecx
    2fa2:      	movl	$0x4, %eax
    2fa7:      	movq	%r15, %rdi
    2faa:      	movl	$0x4, %esi
    2faf:      	movq	%r12, %rdx
    2fb2:      	callq	*%rax
    2fb4:      	movl	$0x10, %r13d
    2fba:      	jmp	0x4450 <generic_kprobe_process_event+0x4100>
    2fbf:      	leaq	0x38(%r12), %rdx
    2fc4:      	movl	$0x4, %ecx
    2fc9:      	movl	$0x4, %eax
    2fce:      	movq	%r15, %rdi
    2fd1:      	movl	$0x4, %esi
    2fd6:      	callq	*%rax
    2fd8:      	leaq	0x4(%r15), %rdi
    2fdc:      	leaq	0x3c(%r12), %rdx
    2fe1:      	movl	$0x4, %ecx
    2fe6:      	movl	$0x4, %eax
    2feb:      	movl	$0x4, %esi
    2ff0:      	callq	*%rax
    2ff2:      	leaq	0x8(%r15), %rdi
    2ff6:      	leaq	0x40(%r12), %rdx
    2ffb:      	movl	$0x4, %ecx
    3000:      	movl	$0x4, %eax
    3005:      	movl	$0x4, %esi
    300a:      	callq	*%rax
    300c:      	leaq	0xc(%r15), %rdi
    3010:      	leaq	0x44(%r12), %rdx
    3015:      	movl	$0x4, %ecx
    301a:      	movl	$0x4, %eax
    301f:      	movl	$0x4, %esi
    3024:      	callq	*%rax
    3026:      	addq	$0x10, %r15
    302a:      	subq	$-0x80, %r12
    302e:      	movl	$0x10, %ecx
    3033:      	movl	$0x4, %eax
    3038:      	movq	%r15, %rdi
    303b:      	movl	$0x10, %esi
    3040:      	movq	%r12, %rdx
    3043:      	callq	*%rax
    3045:      	movl	$0x20, %r13d
    304b:      	jmp	0x4450 <generic_kprobe_process_event+0x4100>
    3050:      	movl	$0x4, %ecx
    3055:      	movl	$0x4, %eax
    305a:      	movq	%r15, %rbx
    305d:      	movq	%r15, %rdi
    3060:      	movl	$0x4, %esi
    3065:      	movq	%r12, %rdx
    3068:      	callq	*%rax
    306a:      	leaq	0x4(%r15), %rdi
    306e:      	leaq	0x4(%r12), %rdx
    3073:      	movl	$0x4, %ecx
    3078:      	movl	$0x4, %eax
    307d:      	movl	$0x4, %esi
    3082:      	callq	*%rax
    3084:      	addq	$0x8, %rbx
    3088:      	addq	$0x30, %r12
    308c:      	movl	$0x10, %ecx
    3091:      	movl	$0x4, %eax
    3096:      	movq	%rbx, %rdi
    3099:      	movl	$0x10, %esi
    309e:      	movq	%r12, %rdx
    30a1:      	jmp	0x312f <generic_kprobe_process_event+0x2ddf>
    30a6:      	leaq	0x4(%r12), %rdx
    30ab:      	leaq	0x50(%rsp), %rdi
    30b0:      	movl	$0x4, %ecx
    30b5:      	movl	$0x4, %eax
    30ba:      	movl	$0x4, %esi
    30bf:      	callq	*%rax
    30c1:      	movl	0x50(%rsp), %eax
    30c5:      	movl	%eax, (%rbp)
    30c8:      	leaq	0xc(%r12), %rdx
    30cd:      	leaq	0x50(%rsp), %rdi
    30d2:      	movl	$0x4, %ecx
    30d7:      	movl	$0x4, %eax
    30dc:      	movl	$0x4, %esi
    30e1:      	callq	*%rax
    30e3:      	movl	0x50(%rsp), %eax
    30e7:      	movl	%eax, 0x4(%rbp)
    30ea:      	addq	$0x50, %r12
    30ee:      	leaq	0x50(%rsp), %rdi
    30f3:      	movl	$0x8, %ecx
    30f8:      	movl	$0x2d, %eax
    30fd:      	movl	$0x8, %esi
    3102:      	movq	%r12, %rdx
    3105:      	callq	*%rax
    3107:      	addq	$0x8, %rbp
    310b:      	movl	$0x3f8, %edx            # imm = 0x3F8
    3110:      	movq	0x50(%rsp), %rcx
    3115:      	addq	%rdx, %rcx
    3118:      	movl	$0x10, %esi
    311d:      	movl	$0x2d, %eax
    3122:      	addq	0x50(%rsp), %rdx
    3127:      	movq	%rbp, %rdi
    312a:      	movl	$0x10, %esi
    312f:      	callq	*%rax
    3131:      	movl	$0x18, %r13d
    3137:      	jmp	0x4450 <generic_kprobe_process_event+0x4100>
    313c:      	movq	$0x0, 0x48(%rbp)
    3144:      	movq	$0x0, 0x40(%rbp)
    314c:      	movq	$0x0, 0x38(%rbp)
    3154:      	movq	$0x0, 0x30(%rbp)
    315c:      	movq	$0x0, 0x28(%rbp)
    3164:      	movq	$0x0, 0x20(%rbp)
    316c:      	movq	$0x0, 0x18(%rbp)
    3174:      	movq	$0x0, 0x10(%rbp)
    317c:      	movq	$0x0, 0x8(%rbp)
    3184:      	movq	$0x0, (%rbp)
    318c:      	leaq	0x50(%rsp), %rdi
    3191:      	movl	$0x8, %ecx
    3196:      	movl	$0x4, %eax
    319b:      	movq	%r12, %rdx
    319e:      	movl	$0x8, %esi
    31a3:      	callq	*%rax
    31a5:      	testq	%rax, %rax
    31a8:      	je	0x3480 <generic_kprobe_process_event+0x3130>
    31ae:      	xorl	%r13d, %r13d
    31b1:      	jmp	0x4450 <generic_kprobe_process_event+0x4100>
    31b6:      	movq	0xa8(%rsp), %rax
    31be:      	movq	$0x0, 0x90(%r15,%rax)
    31ca:      	movl	$0x8, %r13d
    31d0:      	jmp	0x1cad <generic_kprobe_process_event+0x195d>
    31d5:      	movq	$-0x1, %r13
    31dc:      	jmp	0x1cad <generic_kprobe_process_event+0x195d>
    31e1:      	movq	0x50(%rsp), %r14
    31e6:      	movl	$0x0, 0x90(%rsp)
    31f1:      	movzwl	0x38(%rsp), %r15d
    31f7:      	movq	(%rip), %rdi            # 0x31fe <generic_kprobe_process_event+0x2eae>
    31fe:      	leaq	0x90(%rsp), %rsi
    3206:      	movl	$0x1, %eax
    320b:      	leaq	(%r14,%r15), %r12
    320f:      	callq	*%rax
    3211:      	testq	%rax, %rax
    3214:      	je	0x463f <generic_kprobe_process_event+0x42ef>
    321a:      	movq	%rax, %rbx
    321d:      	movw	%r15w, (%rax)
    3221:      	movb	$-0x1, 0x5(%rax)
    3225:      	movb	$0x0, 0x7(%rax)
    3229:      	movq	%rax, %rdi
    322c:      	addq	$0x6, %rdi
    3230:      	leaq	0x6(%r12), %rdx
    3235:      	movl	$0x1, %ecx
    323a:      	movl	$0x4, %eax
    323f:      	movq	%rdi, 0x10(%rsp)
    3244:      	movl	$0x1, %esi
    3249:      	callq	*%rax
    324b:      	testq	%rax, %rax
    324e:      	js	0x463f <generic_kprobe_process_event+0x42ef>
    3254:      	movzbl	0x5(%rbx), %eax
    3258:      	cmpl	$0x32, %eax
    325b:      	jg	0x3bc2 <generic_kprobe_process_event+0x3872>
    3261:      	testl	%eax, %eax
    3263:      	je	0x3c74 <generic_kprobe_process_event+0x3924>
    3269:      	cmpl	$0x2b, %eax
    326c:      	je	0x3c74 <generic_kprobe_process_event+0x3924>
    3272:      	cmpl	$0x2c, %eax
    3275:      	jne	0x4031 <generic_kprobe_process_event+0x3ce1>
    327b:      	movw	$0x8, 0x2(%rbx)
    3281:      	movw	$0x8, %ax
    3285:      	jmp	0x3f73 <generic_kprobe_process_event+0x3c23>
    328a:      	leaq	0x48(%r12), %rdx
    328f:      	movl	$0x10, %ecx
    3294:      	movl	$0x4, %eax
    3299:      	movq	%rbp, %rdi
    329c:      	movl	$0x10, %esi
    32a1:      	callq	*%rax
    32a3:      	leaq	0x38(%r12), %rdx
    32a8:      	movl	$0x10, %ecx
    32ad:      	movl	$0x4, %eax
    32b2:      	movq	%r13, %rdi
    32b5:      	movl	$0x10, %esi
    32ba:      	callq	*%rax
    32bc:      	leaq	0x20(%rbp), %rdi
    32c0:      	leaq	0xc(%r12), %r13
    32c5:      	addq	$0xe, %r12
    32c9:      	movl	$0x2, %ecx
    32ce:      	movl	$0x4, %eax
    32d3:      	movl	$0x2, %esi
    32d8:      	movq	%r12, %rdx
    32db:      	callq	*%rax
    32dd:      	leaq	0x22(%rbp), %rdi
    32e1:      	movl	$0x2, %ecx
    32e6:      	movl	$0x4, %eax
    32eb:      	movl	$0x2, %esi
    32f0:      	movq	%r13, %rdx
    32f3:      	callq	*%rax
    32f5:      	movzwl	0x22(%rbp), %eax
    32f9:      	movbew	%ax, 0x22(%rbp)
    32ff:      	movq	0x48(%rsp), %rax
    3304:      	movq	%rax, 0x50(%rsp)
    3309:      	movq	(%rip), %rdi            # 0x3310 <generic_kprobe_process_event+0x2fc0>
    3310:      	leaq	0x50(%rsp), %rsi
    3315:      	movl	$0x1, %eax
    331a:      	callq	*%rax
    331c:      	testq	%rax, %rax
    331f:      	je	0x47eb <generic_kprobe_process_event+0x449b>
    3325:      	movl	(%rax), %ecx
    3327:      	movq	%r15, %rbp
    332a:      	movl	%ecx, 0x10(%r15)
    332e:      	movq	0x8(%rax), %rcx
    3332:      	movq	%rcx, 0x18(%r15)
    3336:      	movl	0x4(%rax), %eax
    3339:      	movl	%eax, 0x7c(%r15)
    333d:      	jmp	0x47eb <generic_kprobe_process_event+0x449b>
    3342:      	movl	$0xe, %eax
    3347:      	callq	*%rax
    3349:      	cmpq	$-0x16, %rax
    334d:      	jne	0x3373 <generic_kprobe_process_event+0x3023>
    334f:      	movq	0x18(%rsp), %rax
    3354:      	leaq	0x20(%rax), %rdx
    3358:      	leaq	0x50(%rsp), %rdi
    335d:      	movl	$0x8, %ecx
    3362:      	movl	$0x4, %eax
    3367:      	movl	$0x8, %esi
    336c:      	callq	*%rax
    336e:      	movq	0x50(%rsp), %rax
    3373:      	movq	0x8(%rbp), %rcx
    3377:      	movq	0x60(%rbp), %rdx
    337b:      	movq	%rcx, 0x50(%rsp)
    3380:      	movq	%r12, 0x58(%rsp)
    3385:      	movq	$0x0, 0x60(%rsp)
    338e:      	movq	%rdx, 0x90(%rsp)
    3396:      	movq	%rax, 0x98(%rsp)
    339e:      	movq	(%rip), %rdi            # 0x33a5 <generic_kprobe_process_event+0x3055>
    33a5:      	xorl	%ecx, %ecx
    33a7:      	leaq	0x90(%rsp), %rsi
    33af:      	leaq	0x50(%rsp), %rdx
    33b4:      	movl	$0x2, %eax
    33b9:      	xorl	%ecx, %ecx
    33bb:      	callq	*%rax
    33bd:      	testq	%rax, %rax
    33c0:      	je	0x3c1b <generic_kprobe_process_event+0x38cb>
    33c6:      	negl	%eax
    33c8:      	movw	%ax, 0xb0(%rsp)
    33d0:      	movw	$0x5, 0xb2(%rsp)
    33da:      	movabsq	$0x200000046, %rax      # imm = 0x200000046
    33e4:      	movq	%rax, 0xb4(%rsp)
    33ec:      	movq	(%rip), %rdi            # 0x33f3 <generic_kprobe_process_event+0x30a3>
    33f3:      	leaq	0xb0(%rsp), %rsi
    33fb:      	movl	$0x1, %eax
    3400:      	callq	*%rax
    3402:      	testq	%rax, %rax
    3405:      	je	0x3bee <generic_kprobe_process_event+0x389e>
    340b:      	incl	(%rax)
    340d:      	jmp	0x3c1b <generic_kprobe_process_event+0x38cb>
    3412:      	cmpl	$0x1, %eax
    3415:      	je	0x3716 <generic_kprobe_process_event+0x33c6>
    341b:      	cmpl	$0x2, %eax
    341e:      	jne	0x3ac0 <generic_kprobe_process_event+0x3770>
    3424:      	movq	%rbp, %rax
    3427:      	addq	$0x5e58, %rax           # imm = 0x5E58
    342d:      	jmp	0x371f <generic_kprobe_process_event+0x33cf>
    3432:      	movq	%rbp, %rbx
    3435:      	leaq	0x8(%rbp), %rdi
    3439:      	leaq	0x8(%r12), %rdx
    343e:      	movl	$0x10, %ecx
    3443:      	movl	$0x4, %eax
    3448:      	movl	$0x10, %esi
    344d:      	callq	*%rax
    344f:      	leaq	0x2(%rbp), %rdi
    3453:      	addq	$0x2, %r12
    3457:      	movl	$0x2, %ecx
    345c:      	movl	$0x4, %eax
    3461:      	movl	$0x2, %esi
    3466:      	movq	%r12, %rdx
    3469:      	callq	*%rax
    346b:      	movzwl	0x2(%rbp), %eax
    346f:      	movbew	%ax, 0x2(%rbp)
    3475:      	movl	$0x18, %r13d
    347b:      	jmp	0x3561 <generic_kprobe_process_event+0x3211>
    3480:      	leaq	0x10(%rbp), %rdi
    3484:      	movq	0x50(%rsp), %rcx
    3489:      	movl	$0x3f, %edx
    348e:      	movl	$0x2d, %eax
    3493:      	movq	0x50(%rsp), %rdx
    3498:      	movl	$0x3f, %esi
    349d:      	callq	*%rax
    349f:      	testq	%rax, %rax
    34a2:      	js	0x31ae <generic_kprobe_process_event+0x2e5e>
    34a8:      	leaq	0x8(%r12), %rdx
    34ad:      	leaq	0x90(%rsp), %rdi
    34b5:      	movl	$0x8, %ecx
    34ba:      	movl	$0x4, %eax
    34bf:      	movl	$0x8, %esi
    34c4:      	callq	*%rax
    34c6:      	leaq	0x8(%rbp), %rdi
    34ca:      	movl	$0x348, %edx            # imm = 0x348
    34cf:      	movq	0x90(%rsp), %rcx
    34d7:      	addq	%rdx, %rcx
    34da:      	movl	$0x8, %esi
    34df:      	movl	$0x4, %eax
    34e4:      	addq	0x90(%rsp), %rdx
    34ec:      	movl	$0x8, %esi
    34f1:      	callq	*%rax
    34f3:      	addq	$0x58, %r12
    34f7:      	leaq	0x90(%rsp), %rdi
    34ff:      	movl	$0x4, %ecx
    3504:      	movl	$0x4, %eax
    3509:      	movl	$0x4, %esi
    350e:      	movq	%r12, %rdx
    3511:      	callq	*%rax
    3513:      	movl	$0x50, %r13d
    3519:      	testq	%rax, %rax
    351c:      	jne	0x4450 <generic_kprobe_process_event+0x4100>
    3522:      	xorl	%eax, %eax
    3524:      	cmpl	$0x0, 0x90(%rsp)
    352c:      	setne	%al
    352f:      	movl	%eax, (%rbp)
    3532:      	jmp	0x4450 <generic_kprobe_process_event+0x4100>
    3537:      	addq	$0x3, %r12
    353b:      	movl	$0x6b, %ecx
    3540:      	movl	$0x71, %eax
    3545:      	movl	$0x6b, %esi
    354a:      	movq	%r12, %rdx
    354d:      	callq	*%rax
    354f:      	movq	%rax, %rcx
    3552:      	movb	$0x6b, %al
    3554:      	testl	%ecx, %ecx
    3556:      	js	0x355b <generic_kprobe_process_event+0x320b>
    3558:      	movb	%al, 0x3(%rbp)
    355b:      	movl	$0x70, %r13d
    3561:      	movq	0x40(%rsp), %rax
    3566:      	movq	0x20(%rsp), %rcx
    356b:      	movl	$0x4, %esi
    3570:      	movq	0x18(%rsp), %rbx
    3575:      	movq	%r15, %r14
    3578:      	jmp	0x1cbc <generic_kprobe_process_event+0x196c>
    357d:      	addq	$0x90, %r15
    3584:      	movq	0xc8(%rsp), %rax
    358c:      	movl	$0x0, 0x4(%r15,%rax)
    3595:      	addq	%r15, %rax
    3598:      	addq	$0x8, %rax
    359c:      	movq	%rax, 0xa0(%rsp)
    35a4:      	movl	$0xc, %ebp
    35a9:      	movq	0x30(%rsp), %rax
    35ae:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    35b4:      	movl	$0xfff, %r13d           # imm = 0xFFF
    35ba:      	cmovbq	%rax, %r13
    35be:      	movq	0xa0(%rsp), %rax
    35c6:      	leaq	0x8(%rax), %rdi
    35ca:      	movl	$0x4, %eax
    35cf:      	movq	0xe8(%rsp), %rdx
    35d7:      	movl	%r13d, %esi
    35da:      	callq	*%rax
    35dc:      	testl	%eax, %eax
    35de:      	js	0x35fe <generic_kprobe_process_event+0x32ae>
    35e0:      	movq	0xa0(%rsp), %rax
    35e8:      	movq	0x30(%rsp), %rcx
    35ed:      	movl	%ecx, (%rax)
    35ef:      	movl	%r13d, 0x4(%rax)
    35f3:      	addq	%r13, %rbp
    35f6:      	movq	%rbp, %r13
    35f9:      	jmp	0x1cad <generic_kprobe_process_event+0x195d>
    35fe:      	movq	0xa0(%rsp), %rax
    3606:      	movl	$0xfffffffe, (%rax)     # imm = 0xFFFFFFFE
    360c:      	movq	0x40(%rsp), %rax
    3611:      	movq	0x20(%rsp), %rcx
    3616:      	movl	$0x4, %esi
    361b:      	movl	$0x4, %r13d
    3621:      	jmp	0x1cbc <generic_kprobe_process_event+0x196c>
    3626:      	cmpl	$0x1, %ecx
    3629:      	je	0x3ca1 <generic_kprobe_process_event+0x3951>
    362f:      	cmpl	$0x2, %ecx
    3632:      	jne	0x3cab <generic_kprobe_process_event+0x395b>
    3638:      	leaq	0x5e58(%rbp), %rax
    363f:      	jmp	0x3ca8 <generic_kprobe_process_event+0x3958>
    3644:      	leaq	0x48(%r12), %rdx
    3649:      	movl	$0x10, %ecx
    364e:      	movl	$0x4, %eax
    3653:      	movq	%rbp, %rdi
    3656:      	movl	$0x10, %esi
    365b:      	callq	*%rax
    365d:      	leaq	0x38(%r12), %rdx
    3662:      	movl	$0x10, %ecx
    3667:      	movl	$0x4, %eax
    366c:      	movq	%r13, %rdi
    366f:      	movl	$0x10, %esi
    3674:      	callq	*%rax
    3676:      	movq	%rbp, %rbx
    3679:      	leaq	0x20(%rbp), %rdi
    367d:      	leaq	0xc(%r12), %r13
    3682:      	addq	$0xe, %r12
    3686:      	movl	$0x2, %ecx
    368b:      	movl	$0x4, %eax
    3690:      	movl	$0x2, %esi
    3695:      	movq	%r12, %rdx
    3698:      	callq	*%rax
    369a:      	leaq	0x22(%rbp), %rdi
    369e:      	movl	$0x2, %ecx
    36a3:      	movl	$0x4, %eax
    36a8:      	movl	$0x2, %esi
    36ad:      	movq	%r13, %rdx
    36b0:      	callq	*%rax
    36b2:      	movzwl	0x22(%rbp), %eax
    36b6:      	movbew	%ax, 0x22(%rbp)
    36bc:      	movq	0x28(%rbp), %rax
    36c0:      	movq	%rax, 0x50(%rsp)
    36c5:      	movq	(%rip), %rdi            # 0x36cc <generic_kprobe_process_event+0x337c>
    36cc:      	leaq	0x50(%rsp), %rsi
    36d1:      	movl	$0x1, %eax
    36d6:      	callq	*%rax
    36d8:      	testq	%rax, %rax
    36db:      	je	0x36f5 <generic_kprobe_process_event+0x33a5>
    36dd:      	movl	(%rax), %ecx
    36df:      	movq	0x10(%rsp), %rdx
    36e4:      	movl	%ecx, 0x10(%rdx)
    36e7:      	movq	0x8(%rax), %rcx
    36eb:      	movq	%rcx, 0x18(%rdx)
    36ef:      	movl	0x4(%rax), %eax
    36f2:      	movl	%eax, 0x7c(%rdx)
    36f5:      	movl	$0x40, %r13d
    36fb:      	jmp	0x4450 <generic_kprobe_process_event+0x4100>
    3700:      	movq	%rbp, %rax
    3703:      	addq	$0x5e60, %rax           # imm = 0x5E60
    3709:      	jmp	0x371f <generic_kprobe_process_event+0x33cf>
    370b:      	movq	%rbp, %rax
    370e:      	addq	$0x5e68, %rax           # imm = 0x5E68
    3714:      	jmp	0x371f <generic_kprobe_process_event+0x33cf>
    3716:      	movq	%rbp, %rax
    3719:      	addq	$0x5e50, %rax           # imm = 0x5E50
    371f:      	movq	(%rax), %r14
    3722:      	testb	$0x10, 0xa0(%rsp)
    372a:      	jne	0x3ad6 <generic_kprobe_process_event+0x3786>
    3730:      	testq	%r14, %r14
    3733:      	je	0x3ba2 <generic_kprobe_process_event+0x3852>
    3739:      	leaq	0x50(%rsp), %rdi
    373e:      	movl	$0x10, %ecx
    3743:      	movl	$0x4, %eax
    3748:      	movq	%r12, %rdx
    374b:      	movl	$0x10, %esi
    3750:      	callq	*%rax
    3752:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3757:      	testl	%eax, %eax
    3759:      	js	0x3a9e <generic_kprobe_process_event+0x374e>
    375f:      	movq	0x58(%rsp), %rax
    3764:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    3769:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    376f:      	ja	0x3a9e <generic_kprobe_process_event+0x374e>
    3775:      	movq	%rax, %rbx
    3778:      	movq	0xc8(%rsp), %rax
    3780:      	leaq	0xc(%rax), %r15
    3784:      	leaq	(%r15,%r13), %rdi
    3788:      	movq	0x50(%rsp), %rcx
    378d:      	movl	$0x4, %eax
    3792:      	movq	%rbx, %rsi
    3795:      	movq	0x50(%rsp), %rdx
    379a:      	callq	*%rax
    379c:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    37a1:      	testl	%eax, %eax
    37a3:      	js	0x3a9e <generic_kprobe_process_event+0x374e>
    37a9:      	cmpq	$0x1, %r14
    37ad:      	je	0x3ba4 <generic_kprobe_process_event+0x3854>
    37b3:      	leaq	0x10(%r12), %rdx
    37b8:      	leaq	0x50(%rsp), %rdi
    37bd:      	movl	$0x10, %ecx
    37c2:      	movl	$0x4, %eax
    37c7:      	movl	$0x10, %esi
    37cc:      	callq	*%rax
    37ce:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    37d3:      	testl	%eax, %eax
    37d5:      	js	0x3a9e <generic_kprobe_process_event+0x374e>
    37db:      	movq	0x58(%rsp), %rbp
    37e0:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    37e5:      	cmpq	$0xffe, %rbp            # imm = 0xFFE
    37ec:      	ja	0x3a9e <generic_kprobe_process_event+0x374e>
    37f2:      	addq	%rbx, %r15
    37f5:      	leaq	(%r15,%r13), %rdi
    37f9:      	movq	0x50(%rsp), %rcx
    37fe:      	movl	$0x4, %eax
    3803:      	movq	0x50(%rsp), %rdx
    3808:      	movl	%ebp, %esi
    380a:      	callq	*%rax
    380c:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3811:      	testl	%eax, %eax
    3813:      	js	0x3a9e <generic_kprobe_process_event+0x374e>
    3819:      	addq	%rbp, %rbx
    381c:      	cmpq	$0x3, %r14
    3820:      	jb	0x3ba4 <generic_kprobe_process_event+0x3854>
    3826:      	leaq	0x20(%r12), %rdx
    382b:      	leaq	0x50(%rsp), %rdi
    3830:      	movl	$0x10, %ecx
    3835:      	movl	$0x4, %eax
    383a:      	movl	$0x10, %esi
    383f:      	callq	*%rax
    3841:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3846:      	testl	%eax, %eax
    3848:      	js	0x3a9e <generic_kprobe_process_event+0x374e>
    384e:      	movq	0x58(%rsp), %rax
    3853:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    3858:      	movq	%rax, 0x10(%rsp)
    385d:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    3863:      	ja	0x3a9e <generic_kprobe_process_event+0x374e>
    3869:      	addq	%r15, %rbp
    386c:      	movl	%ebp, %edi
    386e:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    3874:      	addq	%r13, %rdi
    3877:      	movq	0x50(%rsp), %rcx
    387c:      	movl	$0x4, %eax
    3881:      	movq	0x10(%rsp), %rsi
    3886:      	movq	0x50(%rsp), %rdx
    388b:      	callq	*%rax
    388d:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3892:      	testl	%eax, %eax
    3894:      	js	0x3a9e <generic_kprobe_process_event+0x374e>
    389a:      	addq	0x10(%rsp), %rbx
    389f:      	cmpq	$0x3, %r14
    38a3:      	je	0x3ba4 <generic_kprobe_process_event+0x3854>
    38a9:      	leaq	0x30(%r12), %rdx
    38ae:      	leaq	0x50(%rsp), %rdi
    38b3:      	movl	$0x10, %ecx
    38b8:      	movl	$0x4, %eax
    38bd:      	movl	$0x10, %esi
    38c2:      	callq	*%rax
    38c4:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    38c9:      	testl	%eax, %eax
    38cb:      	js	0x3a9e <generic_kprobe_process_event+0x374e>
    38d1:      	movq	0x58(%rsp), %rax
    38d6:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    38db:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    38e1:      	ja	0x3a9e <generic_kprobe_process_event+0x374e>
    38e7:      	movq	%rax, %r15
    38ea:      	movq	0x10(%rsp), %rdi
    38ef:      	addq	%rbp, %rdi
    38f2:      	movq	%rdi, %rbp
    38f5:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    38fb:      	addq	%r13, %rdi
    38fe:      	movq	0x50(%rsp), %rcx
    3903:      	movl	$0x4, %eax
    3908:      	movq	%r15, %rsi
    390b:      	movq	0x50(%rsp), %rdx
    3910:      	callq	*%rax
    3912:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3917:      	testl	%eax, %eax
    3919:      	js	0x3a9e <generic_kprobe_process_event+0x374e>
    391f:      	addq	%r15, %rbx
    3922:      	cmpq	$0x5, %r14
    3926:      	jb	0x3ba4 <generic_kprobe_process_event+0x3854>
    392c:      	leaq	0x40(%r12), %rdx
    3931:      	leaq	0x50(%rsp), %rdi
    3936:      	movl	$0x10, %ecx
    393b:      	movl	$0x4, %eax
    3940:      	movl	$0x10, %esi
    3945:      	callq	*%rax
    3947:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    394c:      	testl	%eax, %eax
    394e:      	js	0x3a9e <generic_kprobe_process_event+0x374e>
    3954:      	movq	0x58(%rsp), %rax
    3959:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    395e:      	movq	%rax, 0x10(%rsp)
    3963:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    3969:      	ja	0x3a9e <generic_kprobe_process_event+0x374e>
    396f:      	addq	%rbp, %r15
    3972:      	movq	%r15, %rbp
    3975:      	movl	%r15d, %edi
    3978:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    397e:      	addq	%r13, %rdi
    3981:      	movq	0x50(%rsp), %rcx
    3986:      	movl	$0x4, %eax
    398b:      	movq	0x10(%rsp), %rsi
    3990:      	movq	0x50(%rsp), %rdx
    3995:      	callq	*%rax
    3997:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    399c:      	testl	%eax, %eax
    399e:      	js	0x3a9e <generic_kprobe_process_event+0x374e>
    39a4:      	addq	0x10(%rsp), %rbx
    39a9:      	cmpq	$0x5, %r14
    39ad:      	je	0x3ba4 <generic_kprobe_process_event+0x3854>
    39b3:      	leaq	0x50(%r12), %rdx
    39b8:      	leaq	0x50(%rsp), %rdi
    39bd:      	movl	$0x10, %ecx
    39c2:      	movl	$0x4, %eax
    39c7:      	movl	$0x10, %esi
    39cc:      	callq	*%rax
    39ce:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    39d3:      	testl	%eax, %eax
    39d5:      	js	0x3a9e <generic_kprobe_process_event+0x374e>
    39db:      	movq	0x58(%rsp), %r15
    39e0:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    39e5:      	cmpq	$0xffe, %r15            # imm = 0xFFE
    39ec:      	ja	0x3a9e <generic_kprobe_process_event+0x374e>
    39f2:      	movq	0x10(%rsp), %rdi
    39f7:      	addq	%rbp, %rdi
    39fa:      	movq	%rdi, %rbp
    39fd:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    3a03:      	addq	%r13, %rdi
    3a06:      	movq	0x50(%rsp), %rcx
    3a0b:      	movl	$0x4, %eax
    3a10:      	movq	0x50(%rsp), %rdx
    3a15:      	movl	%r15d, %esi
    3a18:      	callq	*%rax
    3a1a:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3a1f:      	testl	%eax, %eax
    3a21:      	js	0x3a9e <generic_kprobe_process_event+0x374e>
    3a23:      	addq	%r15, %rbx
    3a26:      	cmpq	$0x7, %r14
    3a2a:      	jb	0x3ba4 <generic_kprobe_process_event+0x3854>
    3a30:      	addq	$0x60, %r12
    3a34:      	leaq	0x50(%rsp), %rdi
    3a39:      	movl	$0x10, %ecx
    3a3e:      	movl	$0x4, %eax
    3a43:      	movl	$0x10, %esi
    3a48:      	movq	%r12, %rdx
    3a4b:      	callq	*%rax
    3a4d:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3a52:      	testl	%eax, %eax
    3a54:      	js	0x3a9e <generic_kprobe_process_event+0x374e>
    3a56:      	movq	0x58(%rsp), %r14
    3a5b:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    3a60:      	cmpq	$0xffe, %r14            # imm = 0xFFE
    3a67:      	ja	0x3a9e <generic_kprobe_process_event+0x374e>
    3a69:      	addq	%rbp, %r15
    3a6c:      	andl	$0x3fff, %r15d          # imm = 0x3FFF
    3a73:      	addq	%r13, %r15
    3a76:      	movq	0x50(%rsp), %rcx
    3a7b:      	movl	$0x4, %eax
    3a80:      	movq	0x50(%rsp), %rdx
    3a85:      	movq	%r15, %rdi
    3a88:      	movl	%r14d, %esi
    3a8b:      	callq	*%rax
    3a8d:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3a92:      	testl	%eax, %eax
    3a94:      	js	0x3a9e <generic_kprobe_process_event+0x374e>
    3a96:      	addq	%r14, %rbx
    3a99:      	jmp	0x3ba4 <generic_kprobe_process_event+0x3854>
    3a9e:      	movq	0xa8(%rsp), %rax
    3aa6:      	movl	%ecx, (%r13,%rax)
    3aab:      	movq	0x18(%rsp), %rbx
    3ab0:      	movq	0x28(%rsp), %r14
    3ab5:      	movl	$0x4, %r13d
    3abb:      	jmp	0x1cad <generic_kprobe_process_event+0x195d>
    3ac0:      	xorl	%r14d, %r14d
    3ac3:      	movl	$0x0, %ebx
    3ac8:      	testb	$0x10, 0xa0(%rsp)
    3ad0:      	je	0x3ba4 <generic_kprobe_process_event+0x3854>
    3ad6:      	movl	$0xe, %eax
    3adb:      	callq	*%rax
    3add:      	cmpq	$-0x16, %rax
    3ae1:      	jne	0x3b07 <generic_kprobe_process_event+0x37b7>
    3ae3:      	movq	0x18(%rsp), %rax
    3ae8:      	leaq	0x20(%rax), %rdx
    3aec:      	leaq	0x50(%rsp), %rdi
    3af1:      	movl	$0x8, %ecx
    3af6:      	movl	$0x4, %eax
    3afb:      	movl	$0x8, %esi
    3b00:      	callq	*%rax
    3b02:      	movq	0x50(%rsp), %rax
    3b07:      	movq	0x8(%rbp), %rcx
    3b0b:      	movq	0x60(%rbp), %rdx
    3b0f:      	movq	%rcx, 0x50(%rsp)
    3b14:      	movq	%r12, 0x58(%rsp)
    3b19:      	movq	%r14, 0x60(%rsp)
    3b1e:      	movq	%rdx, 0x90(%rsp)
    3b26:      	movq	%rax, 0x98(%rsp)
    3b2e:      	movq	(%rip), %rdi            # 0x3b35 <generic_kprobe_process_event+0x37e5>
    3b35:      	xorl	%ecx, %ecx
    3b37:      	leaq	0x90(%rsp), %rsi
    3b3f:      	leaq	0x50(%rsp), %rdx
    3b44:      	movl	$0x2, %eax
    3b49:      	xorl	%ecx, %ecx
    3b4b:      	callq	*%rax
    3b4d:      	testq	%rax, %rax
    3b50:      	je	0x3c58 <generic_kprobe_process_event+0x3908>
    3b56:      	negl	%eax
    3b58:      	movw	%ax, 0xb0(%rsp)
    3b60:      	movw	$0x5, 0xb2(%rsp)
    3b6a:      	movabsq	$0x200000057, %rax      # imm = 0x200000057
    3b74:      	movq	%rax, 0xb4(%rsp)
    3b7c:      	movq	(%rip), %rdi            # 0x3b83 <generic_kprobe_process_event+0x3833>
    3b83:      	leaq	0xb0(%rsp), %rsi
    3b8b:      	movl	$0x1, %eax
    3b90:      	callq	*%rax
    3b92:      	testq	%rax, %rax
    3b95:      	je	0x3c31 <generic_kprobe_process_event+0x38e1>
    3b9b:      	incl	(%rax)
    3b9d:      	jmp	0x3c58 <generic_kprobe_process_event+0x3908>
    3ba2:      	xorl	%ebx, %ebx
    3ba4:      	movq	0xa8(%rsp), %rax
    3bac:      	movl	%ebx, (%r13,%rax)
    3bb1:      	movl	%ebx, 0x4(%r13,%rax)
    3bb6:      	addq	$0x8, %rbx
    3bba:      	movq	%rbx, %r13
    3bbd:      	jmp	0x4450 <generic_kprobe_process_event+0x4100>
    3bc2:      	cmpl	$0x33, %eax
    3bc5:      	je	0x3f64 <generic_kprobe_process_event+0x3c14>
    3bcb:      	cmpl	$0x3c, %eax
    3bce:      	je	0x3c74 <generic_kprobe_process_event+0x3924>
    3bd4:      	cmpl	$0xff, %eax
    3bd9:      	jne	0x4031 <generic_kprobe_process_event+0x3ce1>
    3bdf:      	movw	$0x28, 0x2(%rbx)
    3be5:      	movw	$0x28, %ax
    3be9:      	jmp	0x3f73 <generic_kprobe_process_event+0x3c23>
    3bee:      	movl	$0x1, 0xc0(%rsp)
    3bf9:      	movq	(%rip), %rdi            # 0x3c00 <generic_kprobe_process_event+0x38b0>
    3c00:      	xorl	%ecx, %ecx
    3c02:      	leaq	0xb0(%rsp), %rsi
    3c0a:      	leaq	0xc0(%rsp), %rdx
    3c12:      	movl	$0x2, %eax
    3c17:      	xorl	%ecx, %ecx
    3c19:      	callq	*%rax
    3c1b:      	movq	0x30(%rsp), %rax
    3c20:      	movl	$0xfffffffc, (%rax)     # imm = 0xFFFFFFFC
    3c26:      	movl	$0x4, %r13d
    3c2c:      	jmp	0x4450 <generic_kprobe_process_event+0x4100>
    3c31:      	movl	$0x1, 0x38(%rsp)
    3c39:      	movq	(%rip), %rdi            # 0x3c40 <generic_kprobe_process_event+0x38f0>
    3c40:      	xorl	%ecx, %ecx
    3c42:      	leaq	0xb0(%rsp), %rsi
    3c4a:      	leaq	0x38(%rsp), %rdx
    3c4f:      	movl	$0x2, %eax
    3c54:      	xorl	%ecx, %ecx
    3c56:      	callq	*%rax
    3c58:      	movq	0xa8(%rsp), %rax
    3c60:      	movl	$0xfffffffc, (%r13,%rax) # imm = 0xFFFFFFFC
    3c69:      	movl	$0x4, %r13d
    3c6f:      	jmp	0x4450 <generic_kprobe_process_event+0x4100>
    3c74:      	movzbl	0x7(%rbx), %eax
    3c78:      	leal	0x8(,%rax,8), %eax
    3c7f:      	jmp	0x3f6f <generic_kprobe_process_event+0x3c1f>
    3c84:      	movl	$0x4, %r13d
    3c8a:      	jmp	0x1cad <generic_kprobe_process_event+0x195d>
    3c8f:      	leaq	0x5e60(%rbp), %rax
    3c96:      	jmp	0x3ca8 <generic_kprobe_process_event+0x3958>
    3c98:      	leaq	0x5e68(%rbp), %rax
    3c9f:      	jmp	0x3ca8 <generic_kprobe_process_event+0x3958>
    3ca1:      	leaq	0x5e50(%rbp), %rax
    3ca8:      	movq	(%rax), %rax
    3cab:      	movq	%rax, 0x38(%rsp)
    3cb0:      	leaq	0x48(%rsp), %rdi
    3cb5:      	leaq	0x38(%rsp), %rdx
    3cba:      	movl	$0x8, %ecx
    3cbf:      	movl	$0x4, %eax
    3cc4:      	movl	$0x8, %ebx
    3cc9:      	movl	$0x8, %esi
    3cce:      	callq	*%rax
    3cd0:      	movq	0x48(%rsp), %r14
    3cd5:      	testb	$0x20, %r15b
    3cd9:      	je	0x3e9f <generic_kprobe_process_event+0x3b4f>
    3cdf:      	cmpq	$0x1000, %r14           # imm = 0x1000
    3ce6:      	jb	0x3e77 <generic_kprobe_process_event+0x3b27>
    3cec:      	movq	0x30(%rsp), %rax
    3cf1:      	movl	$0x1, (%rax)
    3cf7:      	movl	$0x0, 0x90(%rsp)
    3d02:      	movq	(%rip), %rdi            # 0x3d09 <generic_kprobe_process_event+0x39b9>
    3d09:      	leaq	0x90(%rsp), %rsi
    3d11:      	movl	$0x1, %eax
    3d16:      	callq	*%rax
    3d18:      	movq	%rax, 0x10(%rsp)
    3d1d:      	testq	%rax, %rax
    3d20:      	je	0x3eec <generic_kprobe_process_event+0x3b9c>
    3d26:      	movq	0x10(%rsp), %rbx
    3d2b:      	movl	$0x18, (%rbx)
    3d31:      	movl	$0xe, %eax
    3d36:      	callq	*%rax
    3d38:      	leaq	0x10(%rbx), %r15
    3d3c:      	movq	%rax, 0x10(%rbx)
    3d40:      	cmpq	$-0x16, %rax
    3d44:      	jne	0x3d6d <generic_kprobe_process_event+0x3a1d>
    3d46:      	movq	0x18(%rsp), %rax
    3d4b:      	leaq	0x20(%rax), %rdx
    3d4f:      	leaq	0x50(%rsp), %rdi
    3d54:      	movl	$0x8, %ecx
    3d59:      	movl	$0x4, %eax
    3d5e:      	movl	$0x8, %esi
    3d63:      	callq	*%rax
    3d65:      	movq	0x50(%rsp), %rax
    3d6a:      	movq	%rax, (%r15)
    3d6d:      	movl	$0x7d, %eax
    3d72:      	callq	*%rax
    3d74:      	movq	0x10(%rsp), %rsi
    3d79:      	movq	%rax, 0x18(%rsi)
    3d7d:      	movq	(%r15), %rax
    3d80:      	movq	0x8(%r15), %rcx
    3d84:      	movq	0x30(%rsp), %rdx
    3d89:      	movq	%rax, 0x14(%rdx)
    3d8d:      	movq	%rcx, 0x1c(%rdx)
    3d91:      	addq	$0x20, %rsi
    3d95:      	movq	%rsi, 0xa0(%rsp)
    3d9d:      	movl	$0xa, %r15d
    3da3:      	xorl	%r13d, %r13d
    3da6:      	movq	%r14, %rbp
    3da9:      	subq	%r13, %rbp
    3dac:      	js	0x4063 <generic_kprobe_process_event+0x3d13>
    3db2:      	leaq	(%r12,%r13), %rdx
    3db6:      	cmpq	$0x7fe0, %rbp           # imm = 0x7FE0
    3dbd:      	movl	$0x7fe0, %eax           # imm = 0x7FE0
    3dc2:      	cmovaeq	%rax, %rbp
    3dc6:      	movl	$0x4, %eax
    3dcb:      	movq	0xa0(%rsp), %rdi
    3dd3:      	movl	%ebp, %esi
    3dd5:      	callq	*%rax
    3dd7:      	testl	%eax, %eax
    3dd9:      	js	0x3e4c <generic_kprobe_process_event+0x3afc>
    3ddb:      	leal	0x20(%rbp), %ebx
    3dde:      	movq	0x10(%rsp), %rax
    3de3:      	movl	%ebx, 0x4(%rax)
    3de6:      	movl	$0x0, 0x50(%rsp)
    3dee:      	movl	$0x1, %eax
    3df3:      	movq	(%rip), %rdi            # 0x3dfa <generic_kprobe_process_event+0x3aaa>
    3dfa:      	leaq	0x50(%rsp), %rsi
    3dff:      	callq	*%rax
    3e01:      	testq	%rax, %rax
    3e04:      	je	0x3e2e <generic_kprobe_process_event+0x3ade>
    3e06:      	cmpb	$0x0, 0x28(%rax)
    3e0a:      	je	0x3e2e <generic_kprobe_process_event+0x3ade>
    3e0c:      	movl	$0x19, %eax
    3e11:      	movq	0x18(%rsp), %rdi
    3e16:      	movq	0x10(%rsp), %rcx
    3e1b:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    3e20:      	movq	(%rip), %rsi            # 0x3e27 <generic_kprobe_process_event+0x3ad7>
    3e27:      	movq	%rbx, %r8
    3e2a:      	callq	*%rax
    3e2c:      	jmp	0x3e48 <generic_kprobe_process_event+0x3af8>
    3e2e:      	movl	$0x82, %eax
    3e33:      	movq	0x10(%rsp), %rsi
    3e38:      	xorl	%ecx, %ecx
    3e3a:      	movq	(%rip), %rdi            # 0x3e41 <generic_kprobe_process_event+0x3af1>
    3e41:      	movq	%rbx, %rdx
    3e44:      	xorl	%ecx, %ecx
    3e46:      	callq	*%rax
    3e48:      	testl	%eax, %eax
    3e4a:      	jns	0x3e4f <generic_kprobe_process_event+0x3aff>
    3e4c:      	movslq	%eax, %rbp
    3e4f:      	testl	%ebp, %ebp
    3e51:      	js	0x406c <generic_kprobe_process_event+0x3d1c>
    3e57:      	andl	$0x7fffffff, %ebp       # imm = 0x7FFFFFFF
    3e5d:      	addq	%rbp, %r13
    3e60:      	cmpq	%r14, %r13
    3e63:      	je	0x40c6 <generic_kprobe_process_event+0x3d76>
    3e69:      	decl	%r15d
    3e6c:      	jne	0x3da6 <generic_kprobe_process_event+0x3a56>
    3e72:      	jmp	0x4406 <generic_kprobe_process_event+0x40b6>
    3e77:      	addq	$0x90, %rbp
    3e7e:      	movq	0xc8(%rsp), %rax
    3e86:      	movl	$0x0, 0x4(%rbp,%rax)
    3e8e:      	addq	%rbp, %rax
    3e91:      	addq	$0x8, %rax
    3e95:      	movq	%rax, 0x30(%rsp)
    3e9a:      	movl	$0xc, %ebx
    3e9f:      	cmpq	$0xfff, %r14            # imm = 0xFFF
    3ea6:      	movl	$0xfff, %r13d           # imm = 0xFFF
    3eac:      	cmovbq	%r14, %r13
    3eb0:      	movq	0x30(%rsp), %rax
    3eb5:      	leaq	0x8(%rax), %rdi
    3eb9:      	movl	$0x4, %eax
    3ebe:      	movl	%r13d, %esi
    3ec1:      	movq	%r12, %rdx
    3ec4:      	callq	*%rax
    3ec6:      	testl	%eax, %eax
    3ec8:      	js	0x3ee1 <generic_kprobe_process_event+0x3b91>
    3eca:      	movq	0x30(%rsp), %rax
    3ecf:      	movl	%r14d, (%rax)
    3ed2:      	movl	%r13d, 0x4(%rax)
    3ed6:      	addq	%r13, %rbx
    3ed9:      	movq	%rbx, %r13
    3edc:      	jmp	0x4450 <generic_kprobe_process_event+0x4100>
    3ee1:      	movq	0x30(%rsp), %rax
    3ee6:      	movl	$0xfffffffe, (%rax)     # imm = 0xFFFFFFFE
    3eec:      	movl	$0x4, %r13d
    3ef2:      	jmp	0x4450 <generic_kprobe_process_event+0x4100>
    3ef7:      	movq	$-0x1, %rbp
    3efe:      	jmp	0x3f03 <generic_kprobe_process_event+0x3bb3>
    3f00:      	movq	%r13, %rbp
    3f03:      	movl	$0x0, 0x50(%rsp)
    3f0b:      	movq	(%rip), %rdi            # 0x3f12 <generic_kprobe_process_event+0x3bc2>
    3f12:      	leaq	0x50(%rsp), %rsi
    3f17:      	movl	$0x1, %eax
    3f1c:      	callq	*%rax
    3f1e:      	testq	%rax, %rax
    3f21:      	je	0x42b2 <generic_kprobe_process_event+0x3f62>
    3f27:      	cmpq	$-0xc, %rbp
    3f2b:      	jg	0x403a <generic_kprobe_process_event+0x3cea>
    3f31:      	cmpq	$-0x1c, %rbp
    3f35:      	je	0x4288 <generic_kprobe_process_event+0x3f38>
    3f3b:      	cmpq	$-0x16, %rbp
    3f3f:      	je	0x42a0 <generic_kprobe_process_event+0x3f50>
    3f45:      	cmpq	$-0x10, %rbp
    3f49:      	jne	0x4298 <generic_kprobe_process_event+0x3f48>
    3f4f:      	addq	$0x558, %rax            # imm = 0x558
    3f55:      	jmp	0x42ae <generic_kprobe_process_event+0x3f5e>
    3f5a:      	movq	0x30(%rsp), %rbp
    3f5f:      	jmp	0x42b2 <generic_kprobe_process_event+0x3f62>
    3f64:      	movzbl	0x7(%rbx), %eax
    3f68:      	leal	0x8(,%rax,4), %eax
    3f6f:      	movw	%ax, 0x2(%rbx)
    3f73:      	addw	(%rbx), %ax
    3f76:      	movw	%ax, (%rbx)
    3f79:      	movzbl	0x6(%rbx), %r15d
    3f7e:      	cmpq	$0x3c, %r15
    3f82:      	ja	0x480f <generic_kprobe_process_event+0x44bf>
    3f88:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3f92:      	btq	%r15, %rcx
    3f96:      	jae	0x480f <generic_kprobe_process_event+0x44bf>
    3f9c:      	movb	%r15b, 0x5(%rbx)
    3fa0:      	movzwl	%ax, %ecx
    3fa3:      	addq	%r14, %rcx
    3fa6:      	movl	$0x2, %edx
    3fab:      	movl	$0x4, %eax
    3fb0:      	movq	0x10(%rsp), %rdi
    3fb5:      	movzwl	(%rbx), %edx
    3fb8:      	addq	%r14, %rdx
    3fbb:      	movl	$0x2, %esi
    3fc0:      	callq	*%rax
    3fc2:      	testq	%rax, %rax
    3fc5:      	js	0x463f <generic_kprobe_process_event+0x42ef>
    3fcb:      	movzbl	0x5(%rbx), %eax
    3fcf:      	cmpl	$0x32, %eax
    3fd2:      	jg	0x3ff5 <generic_kprobe_process_event+0x3ca5>
    3fd4:      	testl	%eax, %eax
    3fd6:      	je	0x401d <generic_kprobe_process_event+0x3ccd>
    3fd8:      	cmpl	$0x2b, %eax
    3fdb:      	je	0x401d <generic_kprobe_process_event+0x3ccd>
    3fdd:      	cmpl	$0x2c, %eax
    3fe0:      	jne	0x40df <generic_kprobe_process_event+0x3d8f>
    3fe6:      	movw	$0x8, 0x2(%rbx)
    3fec:      	movw	$0x8, %ax
    3ff0:      	jmp	0x40e3 <generic_kprobe_process_event+0x3d93>
    3ff5:      	cmpl	$0x33, %eax
    3ff8:      	je	0x40ce <generic_kprobe_process_event+0x3d7e>
    3ffe:      	cmpl	$0x3c, %eax
    4001:      	je	0x401d <generic_kprobe_process_event+0x3ccd>
    4003:      	cmpl	$0xff, %eax
    4008:      	jne	0x40df <generic_kprobe_process_event+0x3d8f>
    400e:      	movw	$0x28, 0x2(%rbx)
    4014:      	movw	$0x28, %ax
    4018:      	jmp	0x40e3 <generic_kprobe_process_event+0x3d93>
    401d:      	movzbl	0x7(%rbx), %eax
    4021:      	leal	0x8(,%rax,8), %eax
    4028:      	movw	%ax, 0x2(%rbx)
    402c:      	jmp	0x40e3 <generic_kprobe_process_event+0x3d93>
    4031:      	movzwl	0x2(%rbx), %eax
    4035:      	jmp	0x3f73 <generic_kprobe_process_event+0x3c23>
    403a:      	cmpq	$-0xb, %rbp
    403e:      	je	0x4290 <generic_kprobe_process_event+0x3f40>
    4044:      	cmpq	$-0x7, %rbp
    4048:      	je	0x42a8 <generic_kprobe_process_event+0x3f58>
    404e:      	cmpq	$-0x2, %rbp
    4052:      	jne	0x4298 <generic_kprobe_process_event+0x3f48>
    4058:      	addq	$0x548, %rax            # imm = 0x548
    405e:      	jmp	0x42ae <generic_kprobe_process_event+0x3f5e>
    4063:      	movq	$-0x1, %r13
    406a:      	jmp	0x406f <generic_kprobe_process_event+0x3d1f>
    406c:      	movq	%rbp, %r13
    406f:      	movl	$0x0, 0x50(%rsp)
    4077:      	movq	(%rip), %rdi            # 0x407e <generic_kprobe_process_event+0x3d2e>
    407e:      	leaq	0x50(%rsp), %rsi
    4083:      	movl	$0x1, %eax
    4088:      	callq	*%rax
    408a:      	testq	%rax, %rax
    408d:      	je	0x4406 <generic_kprobe_process_event+0x40b6>
    4093:      	cmpq	$-0xc, %r13
    4097:      	jg	0x418c <generic_kprobe_process_event+0x3e3c>
    409d:      	cmpq	$-0x1c, %r13
    40a1:      	je	0x43dc <generic_kprobe_process_event+0x408c>
    40a7:      	cmpq	$-0x16, %r13
    40ab:      	je	0x43e4 <generic_kprobe_process_event+0x4094>
    40b1:      	cmpq	$-0x10, %r13
    40b5:      	jne	0x43fc <generic_kprobe_process_event+0x40ac>
    40bb:      	addq	$0x558, %rax            # imm = 0x558
    40c1:      	jmp	0x4402 <generic_kprobe_process_event+0x40b2>
    40c6:      	movq	%r14, %r13
    40c9:      	jmp	0x4406 <generic_kprobe_process_event+0x40b6>
    40ce:      	movzbl	0x7(%rbx), %eax
    40d2:      	leal	0x8(,%rax,4), %eax
    40d9:      	movw	%ax, 0x2(%rbx)
    40dd:      	jmp	0x40e3 <generic_kprobe_process_event+0x3d93>
    40df:      	movzwl	0x2(%rbx), %eax
    40e3:      	addw	(%rbx), %ax
    40e6:      	movw	%ax, (%rbx)
    40e9:      	movzbl	0x6(%rbx), %r15d
    40ee:      	cmpq	$0x3c, %r15
    40f2:      	ja	0x480f <generic_kprobe_process_event+0x44bf>
    40f8:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    4102:      	btq	%r15, %rcx
    4106:      	jae	0x480f <generic_kprobe_process_event+0x44bf>
    410c:      	movb	%r15b, 0x5(%rbx)
    4110:      	movzwl	%ax, %ecx
    4113:      	addq	%r14, %rcx
    4116:      	movl	$0x2, %edx
    411b:      	movl	$0x4, %eax
    4120:      	movq	0x10(%rsp), %rdi
    4125:      	movzwl	(%rbx), %edx
    4128:      	addq	%r14, %rdx
    412b:      	movl	$0x2, %esi
    4130:      	callq	*%rax
    4132:      	testq	%rax, %rax
    4135:      	js	0x463f <generic_kprobe_process_event+0x42ef>
    413b:      	movzbl	0x5(%rbx), %eax
    413f:      	cmpl	$0x32, %eax
    4142:      	jg	0x415e <generic_kprobe_process_event+0x3e0e>
    4144:      	testl	%eax, %eax
    4146:      	je	0x417b <generic_kprobe_process_event+0x3e2b>
    4148:      	cmpl	$0x2b, %eax
    414b:      	je	0x417b <generic_kprobe_process_event+0x3e2b>
    414d:      	cmpl	$0x2c, %eax
    4150:      	jne	0x41c6 <generic_kprobe_process_event+0x3e76>
    4152:      	movw	$0x8, 0x2(%rbx)
    4158:      	movw	$0x8, %ax
    415c:      	jmp	0x41ca <generic_kprobe_process_event+0x3e7a>
    415e:      	cmpl	$0x33, %eax
    4161:      	je	0x41b5 <generic_kprobe_process_event+0x3e65>
    4163:      	cmpl	$0x3c, %eax
    4166:      	je	0x417b <generic_kprobe_process_event+0x3e2b>
    4168:      	cmpl	$0xff, %eax
    416d:      	jne	0x41c6 <generic_kprobe_process_event+0x3e76>
    416f:      	movw	$0x28, 0x2(%rbx)
    4175:      	movw	$0x28, %ax
    4179:      	jmp	0x41ca <generic_kprobe_process_event+0x3e7a>
    417b:      	movzbl	0x7(%rbx), %eax
    417f:      	leal	0x8(,%rax,8), %eax
    4186:      	movw	%ax, 0x2(%rbx)
    418a:      	jmp	0x41ca <generic_kprobe_process_event+0x3e7a>
    418c:      	cmpq	$-0xb, %r13
    4190:      	je	0x43ec <generic_kprobe_process_event+0x409c>
    4196:      	cmpq	$-0x7, %r13
    419a:      	je	0x43f4 <generic_kprobe_process_event+0x40a4>
    41a0:      	cmpq	$-0x2, %r13
    41a4:      	jne	0x43fc <generic_kprobe_process_event+0x40ac>
    41aa:      	addq	$0x548, %rax            # imm = 0x548
    41b0:      	jmp	0x4402 <generic_kprobe_process_event+0x40b2>
    41b5:      	movzbl	0x7(%rbx), %eax
    41b9:      	leal	0x8(,%rax,4), %eax
    41c0:      	movw	%ax, 0x2(%rbx)
    41c4:      	jmp	0x41ca <generic_kprobe_process_event+0x3e7a>
    41c6:      	movzwl	0x2(%rbx), %eax
    41ca:      	addw	(%rbx), %ax
    41cd:      	movw	%ax, (%rbx)
    41d0:      	movzbl	0x6(%rbx), %r15d
    41d5:      	cmpq	$0x3c, %r15
    41d9:      	ja	0x480f <generic_kprobe_process_event+0x44bf>
    41df:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    41e9:      	btq	%r15, %rcx
    41ed:      	jae	0x480f <generic_kprobe_process_event+0x44bf>
    41f3:      	movb	%r15b, 0x5(%rbx)
    41f7:      	movzwl	%ax, %ecx
    41fa:      	addq	%r14, %rcx
    41fd:      	movl	$0x2, %edx
    4202:      	movl	$0x4, %eax
    4207:      	movq	0x10(%rsp), %rdi
    420c:      	movzwl	(%rbx), %edx
    420f:      	addq	%r14, %rdx
    4212:      	movl	$0x2, %esi
    4217:      	callq	*%rax
    4219:      	testq	%rax, %rax
    421c:      	js	0x463f <generic_kprobe_process_event+0x42ef>
    4222:      	movzbl	0x5(%rbx), %eax
    4226:      	cmpl	$0x32, %eax
    4229:      	jg	0x424c <generic_kprobe_process_event+0x3efc>
    422b:      	testl	%eax, %eax
    422d:      	je	0x4274 <generic_kprobe_process_event+0x3f24>
    422f:      	cmpl	$0x2b, %eax
    4232:      	je	0x4274 <generic_kprobe_process_event+0x3f24>
    4234:      	cmpl	$0x2c, %eax
    4237:      	jne	0x431a <generic_kprobe_process_event+0x3fca>
    423d:      	movw	$0x8, 0x2(%rbx)
    4243:      	movw	$0x8, %ax
    4247:      	jmp	0x431e <generic_kprobe_process_event+0x3fce>
    424c:      	cmpl	$0x33, %eax
    424f:      	je	0x4309 <generic_kprobe_process_event+0x3fb9>
    4255:      	cmpl	$0x3c, %eax
    4258:      	je	0x4274 <generic_kprobe_process_event+0x3f24>
    425a:      	cmpl	$0xff, %eax
    425f:      	jne	0x431a <generic_kprobe_process_event+0x3fca>
    4265:      	movw	$0x28, 0x2(%rbx)
    426b:      	movw	$0x28, %ax
    426f:      	jmp	0x431e <generic_kprobe_process_event+0x3fce>
    4274:      	movzbl	0x7(%rbx), %eax
    4278:      	leal	0x8(,%rax,8), %eax
    427f:      	movw	%ax, 0x2(%rbx)
    4283:      	jmp	0x431e <generic_kprobe_process_event+0x3fce>
    4288:      	addq	$0x568, %rax            # imm = 0x568
    428e:      	jmp	0x42ae <generic_kprobe_process_event+0x3f5e>
    4290:      	addq	$0x570, %rax            # imm = 0x570
    4296:      	jmp	0x42ae <generic_kprobe_process_event+0x3f5e>
    4298:      	addq	$0x540, %rax            # imm = 0x540
    429e:      	jmp	0x42ae <generic_kprobe_process_event+0x3f5e>
    42a0:      	addq	$0x560, %rax            # imm = 0x560
    42a6:      	jmp	0x42ae <generic_kprobe_process_event+0x3f5e>
    42a8:      	addq	$0x550, %rax            # imm = 0x550
    42ae:      	lock
    42af:      	incq	(%rax)
    42b2:      	testl	%ebp, %ebp
    42b4:      	js	0x42da <generic_kprobe_process_event+0x3f8a>
    42b6:      	movq	0xa0(%rsp), %rax
    42be:      	movq	$0x0, 0x4(%rax)
    42c6:      	movq	0x30(%rsp), %rdx
    42cb:      	movl	%edx, %ecx
    42cd:      	subl	%ebp, %ecx
    42cf:      	xorl	%eax, %eax
    42d1:      	cmpq	$-0x1, %rdx
    42d5:      	cmovnel	%ecx, %eax
    42d8:      	jmp	0x42f0 <generic_kprobe_process_event+0x3fa0>
    42da:      	movq	0xa0(%rsp), %rax
    42e2:      	movl	%ebp, 0x4(%rax)
    42e5:      	movl	$0x0, 0x8(%rax)
    42ec:      	xorl	%eax, %eax
    42ee:      	xorl	%ebp, %ebp
    42f0:      	movq	0xa0(%rsp), %rcx
    42f8:      	movl	%eax, 0xc(%rcx)
    42fb:      	movl	%ebp, 0x10(%rcx)
    42fe:      	movl	$0x24, %r13d
    4304:      	jmp	0x1cad <generic_kprobe_process_event+0x195d>
    4309:      	movzbl	0x7(%rbx), %eax
    430d:      	leal	0x8(,%rax,4), %eax
    4314:      	movw	%ax, 0x2(%rbx)
    4318:      	jmp	0x431e <generic_kprobe_process_event+0x3fce>
    431a:      	movzwl	0x2(%rbx), %eax
    431e:      	addw	(%rbx), %ax
    4321:      	movw	%ax, (%rbx)
    4324:      	movzbl	0x6(%rbx), %r15d
    4329:      	cmpq	$0x3c, %r15
    432d:      	ja	0x480f <generic_kprobe_process_event+0x44bf>
    4333:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    433d:      	btq	%r15, %rcx
    4341:      	jae	0x480f <generic_kprobe_process_event+0x44bf>
    4347:      	movb	%r15b, 0x5(%rbx)
    434b:      	movzwl	%ax, %ecx
    434e:      	addq	%r14, %rcx
    4351:      	movl	$0x2, %edx
    4356:      	movl	$0x4, %eax
    435b:      	movq	0x10(%rsp), %rdi
    4360:      	movzwl	(%rbx), %edx
    4363:      	addq	%r14, %rdx
    4366:      	movl	$0x2, %esi
    436b:      	callq	*%rax
    436d:      	testq	%rax, %rax
    4370:      	js	0x463f <generic_kprobe_process_event+0x42ef>
    4376:      	movzbl	0x5(%rbx), %eax
    437a:      	cmpl	$0x32, %eax
    437d:      	jg	0x43a0 <generic_kprobe_process_event+0x4050>
    437f:      	testl	%eax, %eax
    4381:      	je	0x43c8 <generic_kprobe_process_event+0x4078>
    4383:      	cmpl	$0x2b, %eax
    4386:      	je	0x43c8 <generic_kprobe_process_event+0x4078>
    4388:      	cmpl	$0x2c, %eax
    438b:      	jne	0x4470 <generic_kprobe_process_event+0x4120>
    4391:      	movw	$0x8, 0x2(%rbx)
    4397:      	movw	$0x8, %ax
    439b:      	jmp	0x4474 <generic_kprobe_process_event+0x4124>
    43a0:      	cmpl	$0x33, %eax
    43a3:      	je	0x445f <generic_kprobe_process_event+0x410f>
    43a9:      	cmpl	$0x3c, %eax
    43ac:      	je	0x43c8 <generic_kprobe_process_event+0x4078>
    43ae:      	cmpl	$0xff, %eax
    43b3:      	jne	0x4470 <generic_kprobe_process_event+0x4120>
    43b9:      	movw	$0x28, 0x2(%rbx)
    43bf:      	movw	$0x28, %ax
    43c3:      	jmp	0x4474 <generic_kprobe_process_event+0x4124>
    43c8:      	movzbl	0x7(%rbx), %eax
    43cc:      	leal	0x8(,%rax,8), %eax
    43d3:      	movw	%ax, 0x2(%rbx)
    43d7:      	jmp	0x4474 <generic_kprobe_process_event+0x4124>
    43dc:      	addq	$0x568, %rax            # imm = 0x568
    43e2:      	jmp	0x4402 <generic_kprobe_process_event+0x40b2>
    43e4:      	addq	$0x560, %rax            # imm = 0x560
    43ea:      	jmp	0x4402 <generic_kprobe_process_event+0x40b2>
    43ec:      	addq	$0x570, %rax            # imm = 0x570
    43f2:      	jmp	0x4402 <generic_kprobe_process_event+0x40b2>
    43f4:      	addq	$0x550, %rax            # imm = 0x550
    43fa:      	jmp	0x4402 <generic_kprobe_process_event+0x40b2>
    43fc:      	addq	$0x540, %rax            # imm = 0x540
    4402:      	lock
    4403:      	incq	(%rax)
    4406:      	testl	%r13d, %r13d
    4409:      	js	0x4429 <generic_kprobe_process_event+0x40d9>
    440b:      	movq	0x30(%rsp), %rax
    4410:      	movq	$0x0, 0x4(%rax)
    4418:      	movl	%r14d, %ecx
    441b:      	subl	%r13d, %ecx
    441e:      	xorl	%eax, %eax
    4420:      	cmpq	$-0x1, %r14
    4424:      	cmovnel	%ecx, %eax
    4427:      	jmp	0x443e <generic_kprobe_process_event+0x40ee>
    4429:      	movq	0x30(%rsp), %rax
    442e:      	movl	%r13d, 0x4(%rax)
    4432:      	movl	$0x0, 0x8(%rax)
    4439:      	xorl	%eax, %eax
    443b:      	xorl	%r13d, %r13d
    443e:      	movq	0x30(%rsp), %rcx
    4443:      	movl	%eax, 0xc(%rcx)
    4446:      	movl	%r13d, 0x10(%rcx)
    444a:      	movl	$0x24, %r13d
    4450:      	movq	0x18(%rsp), %rbx
    4455:      	movq	0x28(%rsp), %r14
    445a:      	jmp	0x1cad <generic_kprobe_process_event+0x195d>
    445f:      	movzbl	0x7(%rbx), %eax
    4463:      	leal	0x8(,%rax,4), %eax
    446a:      	movw	%ax, 0x2(%rbx)
    446e:      	jmp	0x4474 <generic_kprobe_process_event+0x4124>
    4470:      	movzwl	0x2(%rbx), %eax
    4474:      	addw	(%rbx), %ax
    4477:      	movw	%ax, (%rbx)
    447a:      	movzbl	0x6(%rbx), %r15d
    447f:      	cmpq	$0x3c, %r15
    4483:      	ja	0x480f <generic_kprobe_process_event+0x44bf>
    4489:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    4493:      	btq	%r15, %rcx
    4497:      	jae	0x480f <generic_kprobe_process_event+0x44bf>
    449d:      	movb	%r15b, 0x5(%rbx)
    44a1:      	movzwl	%ax, %ecx
    44a4:      	addq	%r14, %rcx
    44a7:      	movl	$0x2, %edx
    44ac:      	movl	$0x4, %eax
    44b1:      	movq	0x10(%rsp), %rdi
    44b6:      	movzwl	(%rbx), %edx
    44b9:      	addq	%r14, %rdx
    44bc:      	movl	$0x2, %esi
    44c1:      	callq	*%rax
    44c3:      	testq	%rax, %rax
    44c6:      	js	0x463f <generic_kprobe_process_event+0x42ef>
    44cc:      	movzbl	0x5(%rbx), %eax
    44d0:      	cmpl	$0x32, %eax
    44d3:      	jg	0x44ef <generic_kprobe_process_event+0x419f>
    44d5:      	testl	%eax, %eax
    44d7:      	je	0x450c <generic_kprobe_process_event+0x41bc>
    44d9:      	cmpl	$0x2b, %eax
    44dc:      	je	0x450c <generic_kprobe_process_event+0x41bc>
    44de:      	cmpl	$0x2c, %eax
    44e1:      	jne	0x452e <generic_kprobe_process_event+0x41de>
    44e3:      	movw	$0x8, 0x2(%rbx)
    44e9:      	movw	$0x8, %ax
    44ed:      	jmp	0x4532 <generic_kprobe_process_event+0x41e2>
    44ef:      	cmpl	$0x33, %eax
    44f2:      	je	0x451d <generic_kprobe_process_event+0x41cd>
    44f4:      	cmpl	$0x3c, %eax
    44f7:      	je	0x450c <generic_kprobe_process_event+0x41bc>
    44f9:      	cmpl	$0xff, %eax
    44fe:      	jne	0x452e <generic_kprobe_process_event+0x41de>
    4500:      	movw	$0x28, 0x2(%rbx)
    4506:      	movw	$0x28, %ax
    450a:      	jmp	0x4532 <generic_kprobe_process_event+0x41e2>
    450c:      	movzbl	0x7(%rbx), %eax
    4510:      	leal	0x8(,%rax,8), %eax
    4517:      	movw	%ax, 0x2(%rbx)
    451b:      	jmp	0x4532 <generic_kprobe_process_event+0x41e2>
    451d:      	movzbl	0x7(%rbx), %eax
    4521:      	leal	0x8(,%rax,4), %eax
    4528:      	movw	%ax, 0x2(%rbx)
    452c:      	jmp	0x4532 <generic_kprobe_process_event+0x41e2>
    452e:      	movzwl	0x2(%rbx), %eax
    4532:      	addw	(%rbx), %ax
    4535:      	movw	%ax, (%rbx)
    4538:      	movzbl	0x6(%rbx), %r15d
    453d:      	cmpq	$0x3c, %r15
    4541:      	ja	0x480f <generic_kprobe_process_event+0x44bf>
    4547:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    4551:      	btq	%r15, %rcx
    4555:      	jae	0x480f <generic_kprobe_process_event+0x44bf>
    455b:      	movb	%r15b, 0x5(%rbx)
    455f:      	movzwl	%ax, %ecx
    4562:      	addq	%r14, %rcx
    4565:      	movl	$0x2, %edx
    456a:      	movl	$0x4, %eax
    456f:      	movq	0x10(%rsp), %rdi
    4574:      	movzwl	(%rbx), %edx
    4577:      	addq	%r14, %rdx
    457a:      	movl	$0x2, %esi
    457f:      	callq	*%rax
    4581:      	testq	%rax, %rax
    4584:      	js	0x463f <generic_kprobe_process_event+0x42ef>
    458a:      	movzbl	0x5(%rbx), %eax
    458e:      	cmpl	$0x32, %eax
    4591:      	jg	0x45ad <generic_kprobe_process_event+0x425d>
    4593:      	testl	%eax, %eax
    4595:      	je	0x45ca <generic_kprobe_process_event+0x427a>
    4597:      	cmpl	$0x2b, %eax
    459a:      	je	0x45ca <generic_kprobe_process_event+0x427a>
    459c:      	cmpl	$0x2c, %eax
    459f:      	jne	0x45ec <generic_kprobe_process_event+0x429c>
    45a1:      	movw	$0x8, 0x2(%rbx)
    45a7:      	movw	$0x8, %ax
    45ab:      	jmp	0x45f0 <generic_kprobe_process_event+0x42a0>
    45ad:      	cmpl	$0x33, %eax
    45b0:      	je	0x45db <generic_kprobe_process_event+0x428b>
    45b2:      	cmpl	$0x3c, %eax
    45b5:      	je	0x45ca <generic_kprobe_process_event+0x427a>
    45b7:      	cmpl	$0xff, %eax
    45bc:      	jne	0x45ec <generic_kprobe_process_event+0x429c>
    45be:      	movw	$0x28, 0x2(%rbx)
    45c4:      	movw	$0x28, %ax
    45c8:      	jmp	0x45f0 <generic_kprobe_process_event+0x42a0>
    45ca:      	movzbl	0x7(%rbx), %eax
    45ce:      	leal	0x8(,%rax,8), %eax
    45d5:      	movw	%ax, 0x2(%rbx)
    45d9:      	jmp	0x45f0 <generic_kprobe_process_event+0x42a0>
    45db:      	movzbl	0x7(%rbx), %eax
    45df:      	leal	0x8(,%rax,4), %eax
    45e6:      	movw	%ax, 0x2(%rbx)
    45ea:      	jmp	0x45f0 <generic_kprobe_process_event+0x42a0>
    45ec:      	movzwl	0x2(%rbx), %eax
    45f0:      	addw	(%rbx), %ax
    45f3:      	movw	%ax, (%rbx)
    45f6:      	movzbl	0x6(%rbx), %r15d
    45fb:      	cmpq	$0x3c, %r15
    45ff:      	ja	0x480f <generic_kprobe_process_event+0x44bf>
    4605:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    460f:      	btq	%r15, %rcx
    4613:      	jae	0x480f <generic_kprobe_process_event+0x44bf>
    4619:      	movb	%r15b, 0x5(%rbx)
    461d:      	movzwl	%ax, %ecx
    4620:      	addq	%r14, %rcx
    4623:      	movl	$0x2, %edx
    4628:      	movl	$0x4, %eax
    462d:      	movq	0x10(%rsp), %rdi
    4632:      	movzwl	(%rbx), %edx
    4635:      	addq	%r14, %rdx
    4638:      	movl	$0x2, %esi
    463d:      	callq	*%rax
    463f:      	xorl	%r15d, %r15d
    4642:      	movb	%r15b, 0xd0(%rsp)
    464a:      	movzbl	%r15b, %eax
    464e:      	movq	%rbp, %rbx
    4651:      	movw	%ax, 0x24(%rbp)
    4655:      	movw	$0xa, 0x26(%rbp)
    465b:      	leaq	0x8(%r12), %rdx
    4660:      	movl	$0x10, %ecx
    4665:      	movl	$0x4, %eax
    466a:      	movq	%rbp, %rdi
    466d:      	movl	$0x10, %esi
    4672:      	callq	*%rax
    4674:      	leaq	0x10(%rbp), %rdi
    4678:      	addq	$0x18, %r12
    467c:      	movl	$0x10, %ecx
    4681:      	movl	$0x4, %eax
    4686:      	movl	$0x10, %esi
    468b:      	movq	%r12, %rdx
    468e:      	callq	*%rax
    4690:      	cmpb	$0x11, %r15b
    4694:      	je	0x46e5 <generic_kprobe_process_event+0x4395>
    4696:      	movzbl	%r15b, %eax
    469a:      	cmpl	$0x6, %eax
    469d:      	jne	0x472e <generic_kprobe_process_event+0x43de>
    46a3:      	movq	0x50(%rsp), %r15
    46a8:      	movzwl	0xc0(%rsp), %r12d
    46b1:      	leaq	(%r15,%r12), %rdx
    46b5:      	movq	%rbp, %rbx
    46b8:      	leaq	0x20(%rbp), %rdi
    46bc:      	movl	$0x2, %ecx
    46c1:      	movl	$0x4, %eax
    46c6:      	movl	$0x2, %esi
    46cb:      	callq	*%rax
    46cd:      	leaq	0x22(%rbp), %rdi
    46d1:      	leaq	(%r15,%r12), %rdx
    46d5:      	addq	$0x2, %rdx
    46d9:      	movl	$0x2, %ecx
    46de:      	movl	$0x4, %eax
    46e3:      	jmp	0x4725 <generic_kprobe_process_event+0x43d5>
    46e5:      	movq	0x50(%rsp), %r15
    46ea:      	movzwl	0xc0(%rsp), %r12d
    46f3:      	leaq	(%r15,%r12), %rdx
    46f7:      	movq	%rbp, %rbx
    46fa:      	leaq	0x20(%rbp), %rdi
    46fe:      	movl	$0x2, %ecx
    4703:      	movl	$0x4, %eax
    4708:      	movl	$0x2, %esi
    470d:      	callq	*%rax
    470f:      	leaq	0x22(%rbp), %rdi
    4713:      	leaq	(%r15,%r12), %rdx
    4717:      	addq	$0x2, %rdx
    471b:      	movl	$0x2, %ecx
    4720:      	movl	$0x4, %eax
    4725:      	movl	$0x2, %esi
    472a:      	callq	*%rax
    472c:      	jmp	0x4735 <generic_kprobe_process_event+0x43e5>
    472e:      	movl	$0x0, 0x20(%rbp)
    4735:      	movzwl	0x20(%rbp), %eax
    4739:      	movzwl	0x22(%rbp), %ecx
    473d:      	movbew	%ax, 0x20(%rbp)
    4743:      	movbew	%cx, 0x22(%rbp)
    4749:      	addq	$0xe0, %r13
    4750:      	leaq	0x90(%rsp), %rdi
    4758:      	movl	$0x8, %ecx
    475d:      	movl	$0x4, %eax
    4762:      	movl	$0x4, %r15d
    4768:      	movl	$0x8, %esi
    476d:      	movq	%r13, %rdx
    4770:      	callq	*%rax
    4772:      	movq	0x90(%rsp), %rcx
    477a:      	testq	%rcx, %rcx
    477d:      	je	0x47eb <generic_kprobe_process_event+0x449b>
    477f:      	addq	$0x5, %rcx
    4783:      	leaq	0xb0(%rsp), %rdi
    478b:      	movl	$0x8, %edx
    4790:      	movl	$0x4, %eax
    4795:      	movq	0x90(%rsp), %rdx
    479d:      	addq	$0x5, %rdx
    47a1:      	movl	$0x8, %esi
    47a6:      	callq	*%rax
    47a8:      	movq	0x90(%rsp), %r12
    47b0:      	movq	0xb0(%rsp), %r13
    47b8:      	leaq	0x38(%rbp), %rdi
    47bc:      	leaq	(%r12,%r13,8), %rdx
    47c0:      	addq	$0x44, %rdx
    47c4:      	movl	$0x4, %eax
    47c9:      	movl	$0x4, %esi
    47ce:      	callq	*%rax
    47d0:      	addq	$0x3c, %rbp
    47d4:      	leaq	(%r12,%r13,8), %rdx
    47d8:      	addq	$0x45, %rdx
    47dc:      	movl	$0x4, %eax
    47e1:      	movq	%rbp, %rdi
    47e4:      	movl	$0x4, %esi
    47e9:      	callq	*%rax
    47eb:      	movl	$0x40, %r13d
    47f1:      	movq	0x40(%rsp), %rax
    47f6:      	movq	0x20(%rsp), %rcx
    47fb:      	movl	$0x4, %esi
    4800:      	movq	0x18(%rsp), %rbx
    4805:      	movq	0x28(%rsp), %r14
    480a:      	jmp	0x1cbc <generic_kprobe_process_event+0x196c>
    480f:      	movw	%ax, 0xc0(%rsp)
    4817:      	jmp	0x4642 <generic_kprobe_process_event+0x42f2>
    481c:      	nopl	(%rax)

0000000000004820 <generic_kprobe_process_filter>:
    4820:      	pushq	%rbp
    4821:      	pushq	%r15
    4823:      	pushq	%r14
    4825:      	pushq	%r13
    4827:      	pushq	%r12
    4829:      	pushq	%rbx
    482a:      	subq	$0xe8, %rsp
    4831:      	movq	%rdi, %rbx
    4834:      	movl	$0x0, 0xc8(%rsp)
    483f:      	movq	(%rip), %rdi            # 0x4846 <generic_kprobe_process_filter+0x26>
    4846:      	leaq	0xc8(%rsp), %rsi
    484e:      	movl	$0x1, %eax
    4853:      	callq	*%rax
    4855:      	testq	%rax, %rax
    4858:      	je	0x6e43 <generic_kprobe_process_filter+0x2623>
    485e:      	movq	%rax, %r14
    4861:      	movl	$0x23, %eax
    4866:      	callq	*%rax
    4868:      	movq	%rax, %rcx
    486b:      	movq	%rax, 0x60(%rsp)
    4870:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    4877:      	leaq	0x10(%rsp), %rdi
    487c:      	movl	$0x4, %edx
    4881:      	movl	$0x71, %eax
    4886:      	movl	$0xaf4, %edx            # imm = 0xAF4
    488b:      	addq	0x60(%rsp), %rdx
    4890:      	movl	$0x4, %esi
    4895:      	callq	*%rax
    4897:      	movl	0x10(%rsp), %eax
    489b:      	movl	%eax, 0x40(%rsp)
    489f:      	movq	(%rip), %rdi            # 0x48a6 <generic_kprobe_process_filter+0x86>
    48a6:      	leaq	0x40(%rsp), %rsi
    48ab:      	movl	$0x1, %eax
    48b0:      	callq	*%rax
    48b2:      	testq	%rax, %rax
    48b5:      	movq	%r14, 0x50(%rsp)
    48ba:      	je	0x48ca <generic_kprobe_process_filter+0xaa>
    48bc:      	movq	%rax, %r15
    48bf:      	cmpq	$0x0, 0x8(%rax)
    48c4:      	jne	0x584f <generic_kprobe_process_filter+0x102f>
    48ca:      	movl	$0xb00, %edx            # imm = 0xB00
    48cf:      	movq	0x60(%rsp), %rcx
    48d4:      	addq	%rdx, %rcx
    48d7:      	leaq	0x60(%rsp), %rdi
    48dc:      	movl	$0x8, %esi
    48e1:      	movl	$0x71, %eax
    48e6:      	addq	0x60(%rsp), %rdx
    48eb:      	movl	$0x8, %esi
    48f0:      	callq	*%rax
    48f2:      	movq	0x60(%rsp), %rcx
    48f7:      	testq	%rcx, %rcx
    48fa:      	je	0x4a8f <generic_kprobe_process_filter+0x26f>
    4900:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    4907:      	leaq	0x10(%rsp), %rdi
    490c:      	movl	$0x4, %edx
    4911:      	movl	$0x71, %eax
    4916:      	movl	$0xaf4, %edx            # imm = 0xAF4
    491b:      	addq	0x60(%rsp), %rdx
    4920:      	movl	$0x4, %esi
    4925:      	callq	*%rax
    4927:      	movl	0x10(%rsp), %eax
    492b:      	movl	%eax, 0x40(%rsp)
    492f:      	movq	(%rip), %rdi            # 0x4936 <generic_kprobe_process_filter+0x116>
    4936:      	leaq	0x40(%rsp), %rsi
    493b:      	movl	$0x1, %eax
    4940:      	callq	*%rax
    4942:      	testq	%rax, %rax
    4945:      	je	0x4955 <generic_kprobe_process_filter+0x135>
    4947:      	movq	%rax, %r15
    494a:      	cmpq	$0x0, 0x8(%rax)
    494f:      	jne	0x584f <generic_kprobe_process_filter+0x102f>
    4955:      	movl	$0xb00, %edx            # imm = 0xB00
    495a:      	movq	0x60(%rsp), %rcx
    495f:      	addq	%rdx, %rcx
    4962:      	leaq	0x60(%rsp), %rdi
    4967:      	movl	$0x8, %esi
    496c:      	movl	$0x71, %eax
    4971:      	addq	0x60(%rsp), %rdx
    4976:      	movl	$0x8, %esi
    497b:      	callq	*%rax
    497d:      	movq	0x60(%rsp), %rcx
    4982:      	testq	%rcx, %rcx
    4985:      	je	0x4a8f <generic_kprobe_process_filter+0x26f>
    498b:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    4992:      	leaq	0x10(%rsp), %rdi
    4997:      	movl	$0x4, %edx
    499c:      	movl	$0x71, %eax
    49a1:      	movl	$0xaf4, %edx            # imm = 0xAF4
    49a6:      	addq	0x60(%rsp), %rdx
    49ab:      	movl	$0x4, %esi
    49b0:      	callq	*%rax
    49b2:      	movl	0x10(%rsp), %eax
    49b6:      	movl	%eax, 0x40(%rsp)
    49ba:      	movq	(%rip), %rdi            # 0x49c1 <generic_kprobe_process_filter+0x1a1>
    49c1:      	leaq	0x40(%rsp), %rsi
    49c6:      	movl	$0x1, %eax
    49cb:      	callq	*%rax
    49cd:      	testq	%rax, %rax
    49d0:      	je	0x49e0 <generic_kprobe_process_filter+0x1c0>
    49d2:      	movq	%rax, %r15
    49d5:      	cmpq	$0x0, 0x8(%rax)
    49da:      	jne	0x584f <generic_kprobe_process_filter+0x102f>
    49e0:      	movl	$0xb00, %edx            # imm = 0xB00
    49e5:      	movq	0x60(%rsp), %rcx
    49ea:      	addq	%rdx, %rcx
    49ed:      	leaq	0x60(%rsp), %rdi
    49f2:      	movl	$0x8, %esi
    49f7:      	movl	$0x71, %eax
    49fc:      	addq	0x60(%rsp), %rdx
    4a01:      	movl	$0x8, %esi
    4a06:      	callq	*%rax
    4a08:      	movq	0x60(%rsp), %rcx
    4a0d:      	testq	%rcx, %rcx
    4a10:      	je	0x4a8f <generic_kprobe_process_filter+0x26f>
    4a12:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    4a19:      	leaq	0x10(%rsp), %rdi
    4a1e:      	movl	$0x4, %edx
    4a23:      	movl	$0x71, %eax
    4a28:      	movl	$0xaf4, %edx            # imm = 0xAF4
    4a2d:      	addq	0x60(%rsp), %rdx
    4a32:      	movl	$0x4, %esi
    4a37:      	callq	*%rax
    4a39:      	movl	0x10(%rsp), %eax
    4a3d:      	movl	%eax, 0x40(%rsp)
    4a41:      	movq	(%rip), %rdi            # 0x4a48 <generic_kprobe_process_filter+0x228>
    4a48:      	leaq	0x40(%rsp), %rsi
    4a4d:      	movl	$0x1, %eax
    4a52:      	callq	*%rax
    4a54:      	testq	%rax, %rax
    4a57:      	je	0x4a67 <generic_kprobe_process_filter+0x247>
    4a59:      	movq	%rax, %r15
    4a5c:      	cmpq	$0x0, 0x8(%rax)
    4a61:      	jne	0x584f <generic_kprobe_process_filter+0x102f>
    4a67:      	movl	$0xb00, %edx            # imm = 0xB00
    4a6c:      	movq	0x60(%rsp), %rcx
    4a71:      	addq	%rdx, %rcx
    4a74:      	leaq	0x60(%rsp), %rdi
    4a79:      	movl	$0x8, %esi
    4a7e:      	movl	$0x71, %eax
    4a83:      	addq	0x60(%rsp), %rdx
    4a88:      	movl	$0x8, %esi
    4a8d:      	callq	*%rax
    4a8f:      	movq	%rbx, 0xb8(%rsp)
    4a97:      	movl	$0x23, %eax
    4a9c:      	callq	*%rax
    4a9e:      	movq	%rax, %r13
    4aa1:      	leaq	0xaf4(%rax), %rdx
    4aa8:      	leaq	0x60(%rsp), %rdi
    4aad:      	movl	$0x4, %ecx
    4ab2:      	movl	$0x4, %eax
    4ab7:      	movl	$0x4, %ebp
    4abc:      	movl	$0x4, %esi
    4ac1:      	callq	*%rax
    4ac3:      	movl	0x60(%rsp), %eax
    4ac7:      	movl	%eax, 0x5f10(%r14)
    4ace:      	movl	$0x7d, %eax
    4ad3:      	callq	*%rax
    4ad5:      	movq	%rax, 0x5f18(%r14)
    4adc:      	movl	$0x0, 0x5f20(%r14)
    4ae7:      	movq	$0x0, 0x5f28(%r14)
    4af2:      	movl	$0x0, 0x5f30(%r14)
    4afd:      	leaq	0x60(%r13), %rdx
    4b01:      	leaq	0x40(%rsp), %rdi
    4b06:      	movl	$0x8, %ecx
    4b0b:      	movl	$0x71, %eax
    4b10:      	movl	$0x8, %esi
    4b15:      	callq	*%rax
    4b17:      	movq	0x40(%rsp), %rcx
    4b1c:      	xorl	%ebx, %ebx
    4b1e:      	testq	%rcx, %rcx
    4b21:      	je	0x4b90 <generic_kprobe_process_filter+0x370>
    4b23:      	addq	$0x4, %rcx
    4b27:      	leaq	0x10(%rsp), %rdi
    4b2c:      	movl	$0x4, %edx
    4b31:      	movl	$0x71, %eax
    4b36:      	movq	0x40(%rsp), %rdx
    4b3b:      	addq	$0x4, %rdx
    4b3f:      	movl	$0x4, %esi
    4b44:      	callq	*%rax
    4b46:      	movl	0x10(%rsp), %eax
    4b4a:      	testl	%eax, %eax
    4b4c:      	je	0x4b90 <generic_kprobe_process_filter+0x370>
    4b4e:      	movq	0x40(%rsp), %rcx
    4b53:      	shll	$0x4, %eax
    4b56:      	addq	%rax, %rcx
    4b59:      	addq	$0x80, %rcx
    4b60:      	leaq	0x60(%rsp), %rdi
    4b65:      	movl	$0x10, %edx
    4b6a:      	movl	$0x71, %eax
    4b6f:      	movq	0x40(%rsp), %rcx
    4b74:      	movl	0x10(%rsp), %edx
    4b78:      	shll	$0x4, %edx
    4b7b:      	addq	%rcx, %rdx
    4b7e:      	addq	$0x80, %rdx
    4b85:      	movl	$0x10, %esi
    4b8a:      	callq	*%rax
    4b8c:      	movl	0x60(%rsp), %ebx
    4b90:      	movl	%ebx, 0x5f34(%r14)
    4b97:      	leaq	0xd00(%r13), %r15
    4b9e:      	leaq	0x60(%rsp), %rdi
    4ba3:      	movl	$0x8, %ecx
    4ba8:      	movl	$0x4, %eax
    4bad:      	leaq	0x5f60(%r14), %rbx
    4bb4:      	movl	$0x8, %esi
    4bb9:      	movq	%r15, %rdx
    4bbc:      	callq	*%rax
    4bbe:      	movq	0x60(%rsp), %r12
    4bc3:      	leaq	0x5f68(%r14), %rdi
    4bca:      	leaq	0x40(%r12), %rdx
    4bcf:      	movl	$0x8, %ecx
    4bd4:      	movl	$0x4, %eax
    4bd9:      	movl	$0x8, %esi
    4bde:      	callq	*%rax
    4be0:      	leaq	0x5f70(%r14), %rdi
    4be7:      	leaq	0x30(%r12), %rdx
    4bec:      	movl	$0x8, %ecx
    4bf1:      	movl	$0x4, %eax
    4bf6:      	movl	$0x8, %esi
    4bfb:      	callq	*%rax
    4bfd:      	addq	$0x38, %r12
    4c01:      	movl	$0x8, %ecx
    4c06:      	movl	$0x4, %eax
    4c0b:      	movq	%rbx, %rdi
    4c0e:      	movl	$0x8, %esi
    4c13:      	movq	%r12, %rdx
    4c16:      	callq	*%rax
    4c18:      	leaq	0x5f38(%r14), %rbx
    4c1f:      	leaq	0xd70(%r13), %rdx
    4c26:      	leaq	0x10(%rsp), %rdi
    4c2b:      	movl	$0x8, %ecx
    4c30:      	movl	$0x4, %eax
    4c35:      	movl	$0x8, %esi
    4c3a:      	callq	*%rax
    4c3c:      	movq	0x10(%rsp), %rcx
    4c41:      	leaq	0x60(%rsp), %rdi
    4c46:      	movl	$0x48, %edx
    4c4b:      	movl	$0x4, %eax
    4c50:      	movq	0x10(%rsp), %rdx
    4c55:      	movl	$0x48, %esi
    4c5a:      	callq	*%rax
    4c5c:      	movl	$0x218, %edx            # imm = 0x218
    4c61:      	movq	0x68(%rsp), %rcx
    4c66:      	addq	%rdx, %rcx
    4c69:      	movl	$0x4, %eax
    4c6e:      	addq	0x68(%rsp), %rdx
    4c73:      	movq	%rbx, %rdi
    4c76:      	movl	$0x4, %esi
    4c7b:      	callq	*%rax
    4c7d:      	leaq	0x5f3c(%r14), %rdi
    4c84:      	movl	$0x4d8, %edx            # imm = 0x4D8
    4c89:      	movq	0x70(%rsp), %rcx
    4c8e:      	addq	%rdx, %rcx
    4c91:      	movl	$0x4, %eax
    4c96:      	addq	0x70(%rsp), %rdx
    4c9b:      	movl	$0x4, %esi
    4ca0:      	callq	*%rax
    4ca2:      	leaq	0x5f40(%r14), %rdi
    4ca9:      	movq	0x78(%rsp), %rcx
    4cae:      	addq	$0x58, %rcx
    4cb2:      	movl	$0x4, %eax
    4cb7:      	movq	0x78(%rsp), %rdx
    4cbc:      	addq	$0x58, %rdx
    4cc0:      	movl	$0x4, %esi
    4cc5:      	callq	*%rax
    4cc7:      	movq	$0x0, 0x58(%rsp)
    4cd0:      	leaq	0xb58(%r13), %rdx
    4cd7:      	leaq	0x58(%rsp), %rdi
    4cdc:      	movl	$0x8, %ecx
    4ce1:      	movl	$0x4, %eax
    4ce6:      	movl	$0x8, %esi
    4ceb:      	callq	*%rax
    4ced:      	movq	0x58(%rsp), %rcx
    4cf2:      	testq	%rcx, %rcx
    4cf5:      	je	0x4da4 <generic_kprobe_process_filter+0x584>
    4cfb:      	movl	$0x0, 0xa8(%rsp)
    4d06:      	addq	$0x4, %rcx
    4d0a:      	leaq	0xa8(%rsp), %rdi
    4d12:      	movl	$0x4, %edx
    4d17:      	movl	$0x4, %eax
    4d1c:      	movq	0x58(%rsp), %rdx
    4d21:      	addq	$0x4, %rdx
    4d25:      	movl	$0x4, %esi
    4d2a:      	callq	*%rax
    4d2c:      	movq	0x58(%rsp), %rax
    4d31:      	movslq	0xa8(%rsp), %rcx
    4d39:      	shlq	$0x4, %rcx
    4d3d:      	addq	%rax, %rcx
    4d40:      	addq	$0x80, %rcx
    4d47:      	leaq	0x40(%rsp), %rdi
    4d4c:      	movl	$0x10, %edx
    4d51:      	movl	$0x4, %eax
    4d56:      	movq	0x58(%rsp), %rcx
    4d5b:      	movslq	0xa8(%rsp), %rdx
    4d63:      	shlq	$0x4, %rdx
    4d67:      	addq	%rcx, %rdx
    4d6a:      	addq	$0x80, %rdx
    4d71:      	movl	$0x10, %esi
    4d76:      	callq	*%rax
    4d78:      	leaq	0x5f44(%r14), %rdi
    4d7f:      	movl	$0x158, %edx            # imm = 0x158
    4d84:      	movq	0x48(%rsp), %rcx
    4d89:      	addq	%rdx, %rcx
    4d8c:      	movl	$0x4, %esi
    4d91:      	movl	$0x4, %eax
    4d96:      	addq	0x48(%rsp), %rdx
    4d9b:      	movl	$0x4, %esi
    4da0:      	callq	*%rax
    4da2:      	jmp	0x4daf <generic_kprobe_process_filter+0x58f>
    4da4:      	movl	$0x0, 0x5f44(%r14)
    4daf:      	leaq	0x5f48(%r14), %rdi
    4db6:      	movl	$0x158, %ebx            # imm = 0x158
    4dbb:      	movq	0x80(%rsp), %rcx
    4dc3:      	addq	%rbx, %rcx
    4dc6:      	movl	$0x4, %edx
    4dcb:      	movl	$0x4, %eax
    4dd0:      	movq	0x80(%rsp), %rdx
    4dd8:      	addq	%rbx, %rdx
    4ddb:      	movl	$0x4, %esi
    4de0:      	callq	*%rax
    4de2:      	leaq	0x5f4c(%r14), %rdi
    4de9:      	movl	$0x118, %edx            # imm = 0x118
    4dee:      	movq	0x88(%rsp), %rcx
    4df6:      	addq	%rdx, %rcx
    4df9:      	movl	$0x4, %esi
    4dfe:      	movl	$0x4, %eax
    4e03:      	addq	0x88(%rsp), %rdx
    4e0b:      	movl	$0x4, %esi
    4e10:      	callq	*%rax
    4e12:      	leaq	0x5f50(%r14), %rdi
    4e19:      	movl	$0x98, %r12d
    4e1f:      	movq	0x90(%rsp), %rcx
    4e27:      	addq	%r12, %rcx
    4e2a:      	movl	$0x4, %edx
    4e2f:      	movl	$0x4, %eax
    4e34:      	movq	0x90(%rsp), %rdx
    4e3c:      	addq	%r12, %rdx
    4e3f:      	movl	$0x4, %esi
    4e44:      	callq	*%rax
    4e46:      	leaq	0x5f54(%r14), %rdi
    4e4d:      	movq	0x98(%rsp), %rcx
    4e55:      	addq	%r12, %rcx
    4e58:      	movl	$0x4, %edx
    4e5d:      	movl	$0x4, %eax
    4e62:      	addq	0x98(%rsp), %r12
    4e6a:      	movl	$0x4, %esi
    4e6f:      	movq	%r12, %rdx
    4e72:      	callq	*%rax
    4e74:      	leaq	0x5f58(%r14), %rdi
    4e7b:      	movq	0xa0(%rsp), %rcx
    4e83:      	addq	$0x58, %rcx
    4e87:      	movl	$0x4, %edx
    4e8c:      	movl	$0x4, %eax
    4e91:      	movq	0xa0(%rsp), %rdx
    4e99:      	addq	$0x58, %rdx
    4e9d:      	movl	$0x4, %esi
    4ea2:      	callq	*%rax
    4ea4:      	movq	$0x0, 0x40(%rsp)
    4ead:      	movq	$0x0, 0x58(%rsp)
    4eb6:      	leaq	0x40(%rsp), %rdi
    4ebb:      	movl	$0x8, %ecx
    4ec0:      	movl	$0x4, %eax
    4ec5:      	movl	$0x8, %esi
    4eca:      	movq	%r15, %rdx
    4ecd:      	callq	*%rax
    4ecf:      	movl	$0x90, %edx
    4ed4:      	movq	0x40(%rsp), %rcx
    4ed9:      	addq	%rdx, %rcx
    4edc:      	leaq	0x58(%rsp), %rdi
    4ee1:      	movl	$0x8, %esi
    4ee6:      	movl	$0x4, %eax
    4eeb:      	addq	0x40(%rsp), %rdx
    4ef0:      	movl	$0x8, %esi
    4ef5:      	callq	*%rax
    4ef7:      	leaq	0x5f5c(%r14), %rdi
    4efe:      	movq	0x58(%rsp), %rcx
    4f03:      	addq	%rbx, %rcx
    4f06:      	movl	$0x4, %edx
    4f0b:      	movl	$0x4, %eax
    4f10:      	addq	0x58(%rsp), %rbx
    4f15:      	movl	$0x4, %esi
    4f1a:      	movq	%rbx, %rdx
    4f1d:      	callq	*%rax
    4f1f:      	cmpl	$0x1, 0x5f34(%r14)
    4f27:      	jne	0x4f31 <generic_kprobe_process_filter+0x711>
    4f29:      	orb	$0x2, 0x5f33(%r14)
    4f31:      	leaq	0x5f78(%r14), %rdi
    4f38:      	movl	$0x308, %edx            # imm = 0x308
    4f3d:      	movq	%rdi, 0x8(%rsp)
    4f42:      	xorl	%esi, %esi
    4f44:      	callq	0x4f49 <generic_kprobe_process_filter+0x729>
    4f49:      	leaq	0x6290(%r14), %rbp
    4f50:      	addq	$0xa78, %r13            # imm = 0xA78
    4f57:      	leaq	0x40(%rsp), %rdi
    4f5c:      	movl	$0x8, %ecx
    4f61:      	movl	$0x4, %eax
    4f66:      	movl	$0x8, %esi
    4f6b:      	movq	%r13, %rdx
    4f6e:      	callq	*%rax
    4f70:      	movl	$0x5f8, %edx            # imm = 0x5F8
    4f75:      	movq	0x40(%rsp), %rcx
    4f7a:      	addq	%rdx, %rcx
    4f7d:      	leaq	0x60(%rsp), %rdi
    4f82:      	movl	$0x8, %esi
    4f87:      	movl	$0x4, %eax
    4f8c:      	addq	0x40(%rsp), %rdx
    4f91:      	movl	$0x8, %esi
    4f96:      	callq	*%rax
    4f98:      	movq	0x60(%rsp), %rbx
    4f9d:      	movl	$0x0, 0xcc(%rsp)
    4fa8:      	movq	(%rip), %rdi            # 0x4faf <generic_kprobe_process_filter+0x78f>
    4faf:      	leaq	0xcc(%rsp), %rsi
    4fb7:      	movl	$0x1, %eax
    4fbc:      	callq	*%rax
    4fbe:      	testq	%rax, %rax
    4fc1:      	je	0x56c7 <generic_kprobe_process_filter+0xea7>
    4fc7:      	movq	%rax, %r12
    4fca:      	movq	%rbp, 0x38(%rsp)
    4fcf:      	movl	$0x1000, 0x6410(%r14)   # imm = 0x1000
    4fda:      	leaq	0x1000(%rax), %r13
    4fe1:      	movl	$0x23, %eax
    4fe6:      	callq	*%rax
    4fe8:      	leaq	0xd50(%rax), %rdx
    4fef:      	leaq	0xd8(%rsp), %rdi
    4ff7:      	movl	$0x8, %ecx
    4ffc:      	movl	$0x4, %eax
    5001:      	movl	$0x8, %esi
    5006:      	callq	*%rax
    5008:      	movq	0xd8(%rsp), %rbp
    5010:      	leaq	0x48(%rbx), %r15
    5014:      	leaq	0xe0(%rsp), %rdi
    501c:      	movl	$0x8, %ecx
    5021:      	movl	$0x4, %eax
    5026:      	movl	$0x8, %esi
    502b:      	movq	%r15, %rdx
    502e:      	callq	*%rax
    5030:      	movq	0xe0(%rsp), %r14
    5038:      	leaq	0x10(%r14), %rdx
    503c:      	leaq	0x60(%rsp), %rdi
    5041:      	movl	$0x8, %ecx
    5046:      	movl	$0x4, %eax
    504b:      	movl	$0x8, %esi
    5050:      	callq	*%rax
    5052:      	cmpq	$0x0, 0x60(%rsp)
    5058:      	je	0x5326 <generic_kprobe_process_filter+0xb06>
    505e:      	movq	0x50(%rsp), %r14
    5063:      	movq	$0x0, 0x68(%rsp)
    506c:      	movq	$0x0, 0x60(%rsp)
    5075:      	movq	%r12, 0x70(%rsp)
    507a:      	movq	$0x0, 0x78(%rsp)
    5083:      	movq	$0x0, 0x80(%rsp)
    508f:      	movq	$0x0, 0x88(%rsp)
    509b:      	movq	%r13, 0xc0(%rsp)
    50a3:      	movq	%r13, 0x90(%rsp)
    50ab:      	movl	0x6410(%r14), %eax
    50b2:      	movl	%eax, 0x98(%rsp)
    50b9:      	leaq	0x18(%rbp), %r13
    50bd:      	movb	$0x0, 0x9c(%rsp)
    50c5:      	addq	$0x20, %rbp
    50c9:      	leaq	0x60(%rsp), %rdi
    50ce:      	movl	$0x8, %ecx
    50d3:      	movl	$0x4, %eax
    50d8:      	addq	$0x40, %rbx
    50dc:      	leaq	0x68(%rsp), %r12
    50e1:      	leaq	0x78(%rsp), %r14
    50e6:      	movl	$0x8, %esi
    50eb:      	movq	%rbp, %rdx
    50ee:      	callq	*%rax
    50f0:      	movl	$0x8, %ecx
    50f5:      	movl	$0x4, %eax
    50fa:      	movq	%r12, %rdi
    50fd:      	movl	$0x8, %esi
    5102:      	movq	%r13, %rdx
    5105:      	callq	*%rax
    5107:      	movl	$0x8, %ecx
    510c:      	movl	$0x4, %eax
    5111:      	movq	%r14, %rdi
    5114:      	movl	$0x8, %esi
    5119:      	movq	%r15, %rdx
    511c:      	callq	*%rax
    511e:      	movl	$0x8, %ecx
    5123:      	movl	$0x4, %eax
    5128:      	leaq	0x80(%rsp), %rdi
    5130:      	movl	$0x8, %esi
    5135:      	movq	%rbx, %rdx
    5138:      	callq	*%rax
    513a:      	movq	0x80(%rsp), %rax
    5142:      	addq	$-0x20, %rax
    5146:      	movq	%rax, 0x88(%rsp)
    514e:      	movq	(%rip), %rax            # 0x5155 <generic_kprobe_process_filter+0x935>
    5155:      	cmpb	$0x0, (%rax)
    5158:      	je	0x537d <generic_kprobe_process_filter+0xb5d>
    515e:      	movl	$0x80, %r14d
    5164:      	movl	$0x8, %ebp
    5169:      	leaq	0x10(%rsp), %rbx
    516e:      	nop
    5170:      	movq	0x78(%rsp), %r15
    5175:      	movq	0x80(%rsp), %rdx
    517d:      	movq	0x88(%rsp), %r12
    5185:      	cmpq	0x60(%rsp), %r15
    518a:      	jne	0x5197 <generic_kprobe_process_filter+0x977>
    518c:      	cmpq	0x68(%rsp), %rdx
    5191:      	je	0x553f <generic_kprobe_process_filter+0xd1f>
    5197:      	movl	$0x4, %eax
    519c:      	leaq	0xa8(%rsp), %rdi
    51a4:      	movl	$0x8, %esi
    51a9:      	callq	*%rax
    51ab:      	cmpq	0xa8(%rsp), %r15
    51b3:      	je	0x52c0 <generic_kprobe_process_filter+0xaa0>
    51b9:      	leaq	0x18(%r15), %r13
    51bd:      	movl	$0x4, %eax
    51c2:      	movq	%rbx, %rdi
    51c5:      	movl	$0x8, %esi
    51ca:      	movq	%r13, %rdx
    51cd:      	callq	*%rax
    51cf:      	cmpq	%r15, 0x10(%rsp)
    51d4:      	je	0x52c0 <generic_kprobe_process_filter+0xaa0>
    51da:      	movl	$0x4, %eax
    51df:      	leaq	0x58(%rsp), %rdi
    51e4:      	movl	$0x8, %esi
    51e9:      	movq	%r13, %rdx
    51ec:      	callq	*%rax
    51ee:      	addq	$0x20, %r15
    51f2:      	movl	$0x4, %eax
    51f7:      	leaq	0x40(%rsp), %rdi
    51fc:      	movl	$0x10, %ecx
    5201:      	movl	$0x10, %esi
    5206:      	movq	%r15, %rdx
    5209:      	callq	*%rax
    520b:      	movq	0x70(%rsp), %r15
    5210:      	movq	0x90(%rsp), %rax
    5218:      	movl	0x44(%rsp), %r12d
    521d:      	subq	%r15, %rax
    5220:      	movl	0x98(%rsp), %r13d
    5228:      	movl	%r12d, %edx
    522b:      	subl	%r13d, %edx
    522e:      	movl	$0x0, %ecx
    5233:      	cmovbl	%ecx, %edx
    5236:      	addq	0x48(%rsp), %rdx
    523b:      	xorl	%esi, %esi
    523d:      	cmpl	%r12d, %r13d
    5240:      	seta	%sil
    5244:      	movl	%r12d, %ecx
    5247:      	cmovbl	%r13d, %ecx
    524b:      	addl	%ecx, %esi
    524d:      	movl	%r13d, %edi
    5250:      	subl	%esi, %edi
    5252:      	movl	%edi, 0x98(%rsp)
    5259:      	subq	%rsi, %rax
    525c:      	jb	0x5547 <generic_kprobe_process_filter+0xd27>
    5262:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    5268:      	ja	0x5547 <generic_kprobe_process_filter+0xd27>
    526e:      	cmpl	%r12d, %r13d
    5271:      	jbe	0x5278 <generic_kprobe_process_filter+0xa58>
    5273:      	movb	$0x2f, (%r15,%rax)
    5278:      	xorl	%edi, %edi
    527a:      	cmpl	%r12d, %r13d
    527d:      	seta	%dil
    5281:      	movzbl	%cl, %esi
    5284:      	addq	%rax, %r15
    5287:      	addq	%r15, %rdi
    528a:      	movl	$0x4, %eax
    528f:      	callq	*%rax
    5291:      	movq	%r15, 0x90(%rsp)
    5299:      	cmpl	%r12d, %r13d
    529c:      	jbe	0x5547 <generic_kprobe_process_filter+0xd27>
    52a2:      	movq	0x58(%rsp), %rax
    52a7:      	movq	%rax, 0x78(%rsp)
    52ac:      	decl	%r14d
    52af:      	jne	0x5170 <generic_kprobe_process_filter+0x950>
    52b5:      	jmp	0x5547 <generic_kprobe_process_filter+0xd27>
    52ba:      	nopw	(%rax,%rax)
    52c0:      	leaq	0x10(%r12), %rdx
    52c5:      	movl	$0x4, %eax
    52ca:      	movq	%rbx, %rdi
    52cd:      	movl	$0x8, %esi
    52d2:      	callq	*%rax
    52d4:      	movq	0x88(%rsp), %rax
    52dc:      	cmpq	0x10(%rsp), %rax
    52e1:      	je	0x553f <generic_kprobe_process_filter+0xd1f>
    52e7:      	addq	$0x18, %r12
    52eb:      	movl	$0x4, %eax
    52f0:      	leaq	0x78(%rsp), %rdi
    52f5:      	movl	$0x8, %esi
    52fa:      	movq	%r12, %rdx
    52fd:      	callq	*%rax
    52ff:      	movq	0x10(%rsp), %rax
    5304:      	movq	%rax, 0x88(%rsp)
    530c:      	addq	$0x20, %rax
    5310:      	movq	%rax, 0x80(%rsp)
    5318:      	decl	%r14d
    531b:      	jne	0x5170 <generic_kprobe_process_filter+0x950>
    5321:      	jmp	0x5547 <generic_kprobe_process_filter+0xd27>
    5326:      	leaq	0x18(%r14), %rdx
    532a:      	leaq	0x60(%rsp), %rdi
    532f:      	movl	$0x8, %ecx
    5334:      	movl	$0x4, %eax
    5339:      	movl	$0x8, %esi
    533e:      	callq	*%rax
    5340:      	cmpq	%r14, 0x60(%rsp)
    5345:      	je	0x505e <generic_kprobe_process_filter+0x83e>
    534b:      	movq	0x50(%rsp), %r14
    5350:      	movl	0x6410(%r14), %ecx
    5357:      	leal	-0xa(%rcx), %eax
    535a:      	movl	%eax, 0x6410(%r14)
    5361:      	cmpl	$0x9, %ecx
    5364:      	jg	0x5d04 <generic_kprobe_process_filter+0x14e4>
    536a:      	movl	$0xffffffdc, 0x6414(%r14) # imm = 0xFFFFFFDC
    5375:      	movq	%r13, %rbx
    5378:      	jmp	0x55c8 <generic_kprobe_process_filter+0xda8>
    537d:      	movl	$0x80, %r14d
    5383:      	movl	$0x8, %ebp
    5388:      	leaq	0x10(%rsp), %rbx
    538d:      	nopl	(%rax)
    5390:      	movq	0x78(%rsp), %r15
    5395:      	movq	0x80(%rsp), %rdx
    539d:      	movq	0x88(%rsp), %r12
    53a5:      	cmpq	0x60(%rsp), %r15
    53aa:      	jne	0x53b7 <generic_kprobe_process_filter+0xb97>
    53ac:      	cmpq	0x68(%rsp), %rdx
    53b1:      	je	0x553f <generic_kprobe_process_filter+0xd1f>
    53b7:      	movl	$0x4, %eax
    53bc:      	leaq	0xa8(%rsp), %rdi
    53c4:      	movl	$0x8, %esi
    53c9:      	callq	*%rax
    53cb:      	cmpq	0xa8(%rsp), %r15
    53d3:      	je	0x54e0 <generic_kprobe_process_filter+0xcc0>
    53d9:      	leaq	0x18(%r15), %r13
    53dd:      	movl	$0x4, %eax
    53e2:      	movq	%rbx, %rdi
    53e5:      	movl	$0x8, %esi
    53ea:      	movq	%r13, %rdx
    53ed:      	callq	*%rax
    53ef:      	cmpq	%r15, 0x10(%rsp)
    53f4:      	je	0x54e0 <generic_kprobe_process_filter+0xcc0>
    53fa:      	movl	$0x4, %eax
    53ff:      	leaq	0x58(%rsp), %rdi
    5404:      	movl	$0x8, %esi
    5409:      	movq	%r13, %rdx
    540c:      	callq	*%rax
    540e:      	addq	$0x20, %r15
    5412:      	movl	$0x4, %eax
    5417:      	leaq	0x40(%rsp), %rdi
    541c:      	movl	$0x10, %ecx
    5421:      	movl	$0x10, %esi
    5426:      	movq	%r15, %rdx
    5429:      	callq	*%rax
    542b:      	movq	0x70(%rsp), %r15
    5430:      	movq	0x90(%rsp), %rax
    5438:      	movl	0x44(%rsp), %r12d
    543d:      	subq	%r15, %rax
    5440:      	movl	0x98(%rsp), %r13d
    5448:      	movl	%r12d, %edx
    544b:      	subl	%r13d, %edx
    544e:      	movl	$0x0, %ecx
    5453:      	cmovbl	%ecx, %edx
    5456:      	addq	0x48(%rsp), %rdx
    545b:      	xorl	%esi, %esi
    545d:      	cmpl	%r12d, %r13d
    5460:      	seta	%sil
    5464:      	movl	%r12d, %ecx
    5467:      	cmovbl	%r13d, %ecx
    546b:      	addl	%ecx, %esi
    546d:      	movl	%r13d, %edi
    5470:      	subl	%esi, %edi
    5472:      	movl	%edi, 0x98(%rsp)
    5479:      	subq	%rsi, %rax
    547c:      	jb	0x5547 <generic_kprobe_process_filter+0xd27>
    5482:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    5488:      	ja	0x5547 <generic_kprobe_process_filter+0xd27>
    548e:      	cmpl	%r12d, %r13d
    5491:      	jbe	0x5498 <generic_kprobe_process_filter+0xc78>
    5493:      	movb	$0x2f, (%r15,%rax)
    5498:      	xorl	%edi, %edi
    549a:      	cmpl	%r12d, %r13d
    549d:      	seta	%dil
    54a1:      	movzbl	%cl, %esi
    54a4:      	addq	%rax, %r15
    54a7:      	addq	%r15, %rdi
    54aa:      	movl	$0x4, %eax
    54af:      	callq	*%rax
    54b1:      	movq	%r15, 0x90(%rsp)
    54b9:      	cmpl	%r12d, %r13d
    54bc:      	jbe	0x5547 <generic_kprobe_process_filter+0xd27>
    54c2:      	movq	0x58(%rsp), %rax
    54c7:      	movq	%rax, 0x78(%rsp)
    54cc:      	decl	%r14d
    54cf:      	jne	0x5390 <generic_kprobe_process_filter+0xb70>
    54d5:      	jmp	0x5547 <generic_kprobe_process_filter+0xd27>
    54d7:      	nopw	(%rax,%rax)
    54e0:      	leaq	0x10(%r12), %rdx
    54e5:      	movl	$0x4, %eax
    54ea:      	movq	%rbx, %rdi
    54ed:      	movl	$0x8, %esi
    54f2:      	callq	*%rax
    54f4:      	movq	0x88(%rsp), %rax
    54fc:      	cmpq	0x10(%rsp), %rax
    5501:      	je	0x553f <generic_kprobe_process_filter+0xd1f>
    5503:      	addq	$0x18, %r12
    5507:      	movl	$0x4, %eax
    550c:      	leaq	0x78(%rsp), %rdi
    5511:      	movl	$0x8, %esi
    5516:      	movq	%r12, %rdx
    5519:      	callq	*%rax
    551b:      	movq	0x10(%rsp), %rax
    5520:      	movq	%rax, 0x88(%rsp)
    5528:      	addq	$0x20, %rax
    552c:      	movq	%rax, 0x80(%rsp)
    5534:      	decl	%r14d
    5537:      	jne	0x5390 <generic_kprobe_process_filter+0xb70>
    553d:      	jmp	0x5547 <generic_kprobe_process_filter+0xd27>
    553f:      	movb	$0x1, 0x9c(%rsp)
    5547:      	movq	0x90(%rsp), %rbx
    554f:      	movq	0xc0(%rsp), %rcx
    5557:      	cmpq	%rcx, %rbx
    555a:      	je	0x55a8 <generic_kprobe_process_filter+0xd88>
    555c:      	xorl	%ecx, %ecx
    555e:      	cmpb	$0x0, 0x9c(%rsp)
    5566:      	sete	%cl
    5569:      	addl	%ecx, %ecx
    556b:      	movl	0x98(%rsp), %eax
    5572:      	movq	0x50(%rsp), %r14
    5577:      	movl	%eax, 0x6410(%r14)
    557e:      	movl	%ecx, 0x6414(%r14)
    5585:      	testl	%eax, %eax
    5587:      	movq	0x38(%rsp), %rbp
    558c:      	jle	0x559e <generic_kprobe_process_filter+0xd7e>
    558e:      	movl	$0x1000, %ecx           # imm = 0x1000
    5593:      	subl	%eax, %ecx
    5595:      	movl	%ecx, 0x6410(%r14)
    559c:      	movl	%ecx, %eax
    559e:      	testq	%rbx, %rbx
    55a1:      	jne	0x55cd <generic_kprobe_process_filter+0xdad>
    55a3:      	jmp	0x56c7 <generic_kprobe_process_filter+0xea7>
    55a8:      	movq	0x50(%rsp), %r14
    55ad:      	movl	$0x0, 0x6410(%r14)
    55b8:      	movl	$0x0, 0x6414(%r14)
    55c3:      	xorl	%eax, %eax
    55c5:      	movq	%rcx, %rbx
    55c8:      	movq	0x38(%rsp), %rbp
    55cd:      	xorl	%ecx, %ecx
    55cf:      	movq	%r14, %rdx
    55d2:      	movl	%eax, %r14d
    55d5:      	subl	$0x7f, %r14d
    55d9:      	movl	$0x7f, %r15d
    55df:      	cmovbl	%eax, %r15d
    55e3:      	cmovbl	%ecx, %r14d
    55e7:      	cmpl	$0xff, %eax
    55ec:      	movl	$0xff, %ecx
    55f1:      	cmovbl	%eax, %ecx
    55f4:      	movzbl	%cl, %esi
    55f7:      	movl	%esi, 0x6410(%rdx)
    55fd:      	movl	$0x4, %eax
    5602:      	movq	%rbp, %rdi
    5605:      	movq	%rbx, %rdx
    5608:      	callq	*%rax
    560a:      	testq	%rax, %rax
    560d:      	je	0x566c <generic_kprobe_process_filter+0xe4c>
    560f:      	negl	%eax
    5611:      	movw	%ax, 0x60(%rsp)
    5616:      	movw	$0x8, 0x62(%rsp)
    561d:      	movabsq	$0x4000002de, %rax      # imm = 0x4000002DE
    5627:      	movq	%rax, 0x64(%rsp)
    562c:      	movq	(%rip), %rdi            # 0x5633 <generic_kprobe_process_filter+0xe13>
    5633:      	leaq	0x60(%rsp), %rsi
    5638:      	movl	$0x1, %eax
    563d:      	callq	*%rax
    563f:      	testq	%rax, %rax
    5642:      	je	0x5648 <generic_kprobe_process_filter+0xe28>
    5644:      	incl	(%rax)
    5646:      	jmp	0x566c <generic_kprobe_process_filter+0xe4c>
    5648:      	movl	$0x1, 0x40(%rsp)
    5650:      	movq	(%rip), %rdi            # 0x5657 <generic_kprobe_process_filter+0xe37>
    5657:      	xorl	%ecx, %ecx
    5659:      	leaq	0x60(%rsp), %rsi
    565e:      	leaq	0x40(%rsp), %rdx
    5663:      	movl	$0x2, %eax
    5668:      	xorl	%ecx, %ecx
    566a:      	callq	*%rax
    566c:      	movq	0x50(%rsp), %rax
    5671:      	leaq	0x6390(%rax), %rdi
    5678:      	addq	%r14, %rbx
    567b:      	movq	%rax, %r14
    567e:      	movl	$0x4, %eax
    5683:      	movl	%r15d, %esi
    5686:      	movq	%rbx, %rdx
    5689:      	callq	*%rax
    568b:      	testq	%rax, %rax
    568e:      	je	0x56c7 <generic_kprobe_process_filter+0xea7>
    5690:      	negl	%eax
    5692:      	movw	%ax, 0x60(%rsp)
    5697:      	movw	$0x8, 0x62(%rsp)
    569e:      	movabsq	$0x4000002e0, %rax      # imm = 0x4000002E0
    56a8:      	movq	%rax, 0x64(%rsp)
    56ad:      	movq	(%rip), %rdi            # 0x56b4 <generic_kprobe_process_filter+0xe94>
    56b4:      	leaq	0x60(%rsp), %rsi
    56b9:      	movl	$0x1, %eax
    56be:      	callq	*%rax
    56c0:      	testq	%rax, %rax
    56c3:      	je	0x56f4 <generic_kprobe_process_filter+0xed4>
    56c5:      	incl	(%rax)
    56c7:      	movl	0x6410(%r14), %eax
    56ce:      	leal	-0x101(%rax), %ecx
    56d4:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
    56da:      	ja	0x572d <generic_kprobe_process_filter+0xf0d>
    56dc:      	movq	0x8(%rsp), %rax
    56e1:      	movl	$0xffffffff, (%rax)     # imm = 0xFFFFFFFF
    56e7:      	movq	0xb8(%rsp), %rbx
    56ef:      	jmp	0x5843 <generic_kprobe_process_filter+0x1023>
    56f4:      	movl	$0x1, 0x40(%rsp)
    56fc:      	movq	(%rip), %rdi            # 0x5703 <generic_kprobe_process_filter+0xee3>
    5703:      	xorl	%ecx, %ecx
    5705:      	leaq	0x60(%rsp), %rsi
    570a:      	leaq	0x40(%rsp), %rdx
    570f:      	movl	$0x2, %eax
    5714:      	xorl	%ecx, %ecx
    5716:      	callq	*%rax
    5718:      	movl	0x6410(%r14), %eax
    571f:      	leal	-0x101(%rax), %ecx
    5725:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
    572b:      	jbe	0x56dc <generic_kprobe_process_filter+0xebc>
    572d:      	movzbl	%al, %ebx
    5730:      	leaq	0x5f80(%r14), %rdi
    5737:      	movl	$0x4, %eax
    573c:      	movl	%ebx, %esi
    573e:      	movq	%rbp, %rdx
    5741:      	callq	*%rax
    5743:      	movq	%rax, %r15
    5746:      	testq	%rax, %rax
    5749:      	je	0x57ab <generic_kprobe_process_filter+0xf8b>
    574b:      	movl	%r15d, %eax
    574e:      	negl	%eax
    5750:      	movw	%ax, 0x60(%rsp)
    5755:      	movw	$0xf, 0x62(%rsp)
    575c:      	movabsq	$0x400000164, %rax      # imm = 0x400000164
    5766:      	movq	%rax, 0x64(%rsp)
    576b:      	movq	(%rip), %rdi            # 0x5772 <generic_kprobe_process_filter+0xf52>
    5772:      	leaq	0x60(%rsp), %rsi
    5777:      	movl	$0x1, %eax
    577c:      	callq	*%rax
    577e:      	testq	%rax, %rax
    5781:      	je	0x5787 <generic_kprobe_process_filter+0xf67>
    5783:      	incl	(%rax)
    5785:      	jmp	0x57ab <generic_kprobe_process_filter+0xf8b>
    5787:      	movl	$0x1, 0x40(%rsp)
    578f:      	movq	(%rip), %rdi            # 0x5796 <generic_kprobe_process_filter+0xf76>
    5796:      	xorl	%ecx, %ecx
    5798:      	leaq	0x60(%rsp), %rsi
    579d:      	leaq	0x40(%rsp), %rdx
    57a2:      	movl	$0x2, %eax
    57a7:      	xorl	%ecx, %ecx
    57a9:      	callq	*%rax
    57ab:      	testl	%r15d, %r15d
    57ae:      	cmovel	%ebx, %r15d
    57b2:      	movl	%r15d, 0x5f78(%r14)
    57b9:      	cmpl	$0x7f, %ebx
    57bc:      	movl	$0x7f, %esi
    57c1:      	cmovbl	%ebx, %esi
    57c4:      	leaq	0x6080(%r14), %rdi
    57cb:      	leaq	0x6390(%r14), %rdx
    57d2:      	movl	$0x4, %eax
    57d7:      	callq	*%rax
    57d9:      	testq	%rax, %rax
    57dc:      	movq	0xb8(%rsp), %rbx
    57e4:      	je	0x5843 <generic_kprobe_process_filter+0x1023>
    57e6:      	negl	%eax
    57e8:      	movw	%ax, 0x60(%rsp)
    57ed:      	movw	$0xf, 0x62(%rsp)
    57f4:      	movabsq	$0x40000016a, %rax      # imm = 0x40000016A
    57fe:      	movq	%rax, 0x64(%rsp)
    5803:      	movq	(%rip), %rdi            # 0x580a <generic_kprobe_process_filter+0xfea>
    580a:      	leaq	0x60(%rsp), %rsi
    580f:      	movl	$0x1, %eax
    5814:      	callq	*%rax
    5816:      	testq	%rax, %rax
    5819:      	je	0x581f <generic_kprobe_process_filter+0xfff>
    581b:      	incl	(%rax)
    581d:      	jmp	0x5843 <generic_kprobe_process_filter+0x1023>
    581f:      	movl	$0x1, 0x40(%rsp)
    5827:      	movq	(%rip), %rdi            # 0x582e <generic_kprobe_process_filter+0x100e>
    582e:      	xorl	%ecx, %ecx
    5830:      	leaq	0x60(%rsp), %rsi
    5835:      	leaq	0x40(%rsp), %rdx
    583a:      	movl	$0x2, %eax
    583f:      	xorl	%ecx, %ecx
    5841:      	callq	*%rax
    5843:      	leaq	0x5f10(%r14), %r15
    584a:      	orb	$0x10, 0x1(%r14)
    584f:      	leaq	0x5ef8(%r14), %rsi
    5856:      	movq	(%rip), %rdi            # 0x585d <generic_kprobe_process_filter+0x103d>
    585d:      	movl	$0x1, %eax
    5862:      	callq	*%rax
    5864:      	testq	%rax, %rax
    5867:      	je	0x6e43 <generic_kprobe_process_filter+0x2623>
    586d:      	movq	0x5eb8(%r14), %r13
    5874:      	cmpq	$0x6, %r13
    5878:      	jae	0x5aa6 <generic_kprobe_process_filter+0x1286>
    587e:      	movslq	(%rax), %rcx
    5881:      	testq	%rcx, %rcx
    5884:      	je	0x5ac8 <generic_kprobe_process_filter+0x12a8>
    588a:      	cmpq	%rcx, %r13
    588d:      	jae	0x5aa6 <generic_kprobe_process_filter+0x1286>
    5893:      	movq	%rax, 0x8(%rsp)
    5898:      	movq	%rcx, 0xc0(%rsp)
    58a0:      	movq	%rbx, 0xb8(%rsp)
    58a8:      	movl	%r13d, 0x10(%rsp)
    58ad:      	movl	$0x0, 0x58(%rsp)
    58b5:      	movq	(%rip), %rdi            # 0x58bc <generic_kprobe_process_filter+0x109c>
    58bc:      	leaq	0x10(%rsp), %rsi
    58c1:      	movl	$0x1, %eax
    58c6:      	callq	*%rax
    58c8:      	testq	%rax, %rax
    58cb:      	movq	%r15, 0x38(%rsp)
    58d0:      	je	0x5ae4 <generic_kprobe_process_filter+0x12c4>
    58d6:      	movq	%rax, %rbx
    58d9:      	movl	(%rax), %eax
    58db:      	testl	%eax, %eax
    58dd:      	je	0x5ae4 <generic_kprobe_process_filter+0x12c4>
    58e3:      	cmpl	$0x0, 0x68(%r15)
    58e8:      	js	0x6deb <generic_kprobe_process_filter+0x25cb>
    58ee:      	cmpl	$0x1b, %eax
    58f1:      	ja	0x6deb <generic_kprobe_process_filter+0x25cb>
    58f7:      	movl	$0x60, %ecx
    58fc:      	btl	%eax, %ecx
    58ff:      	jb	0x657c <generic_kprobe_process_filter+0x1d5c>
    5905:      	movl	$0x4000100, %ecx        # imm = 0x4000100
    590a:      	btl	%eax, %ecx
    590d:      	jb	0x64e9 <generic_kprobe_process_filter+0x1cc9>
    5913:      	movl	$0x8000200, %ecx        # imm = 0x8000200
    5918:      	btl	%eax, %ecx
    591b:      	jae	0x6deb <generic_kprobe_process_filter+0x25cb>
    5921:      	movq	%rbx, %rsi
    5924:      	addq	$0x4, %rsi
    5928:      	movq	(%rip), %rdi            # 0x592f <generic_kprobe_process_filter+0x110f>
    592f:      	movl	$0x1, %eax
    5934:      	callq	*%rax
    5936:      	testq	%rax, %rax
    5939:      	je	0x6deb <generic_kprobe_process_filter+0x25cb>
    593f:      	movq	%rax, %r12
    5942:      	movq	0x38(%rsp), %rax
    5947:      	movl	0x68(%rax), %eax
    594a:      	cmpl	$0x7f, %eax
    594d:      	movl	$0x7f, %r14d
    5953:      	cmovll	%eax, %r14d
    5957:      	movq	(%rip), %rdi            # 0x595e <generic_kprobe_process_filter+0x113e>
    595e:      	leaq	0x58(%rsp), %rsi
    5963:      	movl	$0x1, %eax
    5968:      	callq	*%rax
    596a:      	testq	%rax, %rax
    596d:      	je	0x6deb <generic_kprobe_process_filter+0x25cb>
    5973:      	movq	%rax, %rbp
    5976:      	leal	(,%r14,8), %eax
    597e:      	movl	%eax, (%rbp)
    5981:      	movq	0x38(%rsp), %rax
    5986:      	cmpl	$0x0, 0x6c(%rax)
    598a:      	jne	0x5a6d <generic_kprobe_process_filter+0x124d>
    5990:      	movq	0x38(%rsp), %r15
    5995:      	movl	0x68(%r15), %ecx
    5999:      	movl	%ecx, %eax
    599b:      	subl	%r14d, %eax
    599e:      	movl	%r14d, %edx
    59a1:      	andl	$0x7f, %edx
    59a4:      	addl	%edx, %eax
    59a6:      	addl	%ecx, %edx
    59a8:      	movl	%r14d, %ecx
    59ab:      	notl	%ecx
    59ad:      	addl	%edx, %ecx
    59af:      	subl	%r14d, %edx
    59b2:      	leal	-0x4(%rdx), %esi
    59b5:      	leaq	0x1f3(%r15), %rdi
    59bc:      	leal	-0x3(%rdx), %r8d
    59c0:      	addl	$-0x2, %edx
    59c3:      	movq	$-0x3, %r9
    59ca:      	leal	(%rcx,%r9), %r10d
    59ce:      	addl	$0x3, %r10d
    59d2:      	andl	$0x7f, %r10d
    59d6:      	movzbl	0x170(%r15,%r10), %r10d
    59df:      	movb	%r10b, -0x3(%rdi)
    59e3:      	leaq	(%rax,%r9), %r10
    59e7:      	cmpq	$-0x2, %r10
    59eb:      	je	0x5a65 <generic_kprobe_process_filter+0x1245>
    59ed:      	leal	(%rdx,%r9), %r11d
    59f1:      	addl	$0x3, %r11d
    59f5:      	andl	$0x7f, %r11d
    59f9:      	movzbl	0x170(%r15,%r11), %r11d
    5a02:      	movb	%r11b, -0x2(%rdi)
    5a06:      	cmpq	$-0x1, %r10
    5a0a:      	je	0x5a65 <generic_kprobe_process_filter+0x1245>
    5a0c:      	leal	(%r8,%r9), %r10d
    5a10:      	addl	$0x3, %r10d
    5a14:      	andl	$0x7f, %r10d
    5a18:      	movzbl	0x170(%r15,%r10), %r10d
    5a21:      	movb	%r10b, -0x1(%rdi)
    5a25:      	movq	%rax, %r10
    5a28:      	addq	%r9, %r10
    5a2b:      	je	0x5a65 <generic_kprobe_process_filter+0x1245>
    5a2d:      	cmpq	$-0x7f, %r9
    5a31:      	je	0x5a65 <generic_kprobe_process_filter+0x1245>
    5a33:      	leal	(%rsi,%r9), %r10d
    5a37:      	addl	$0x3, %r10d
    5a3b:      	andl	$0x7f, %r10d
    5a3f:      	movzbl	0x170(%r15,%r10), %r10d
    5a48:      	movb	%r10b, (%rdi)
    5a4b:      	addq	$0x4, %rdi
    5a4f:      	leaq	(%rax,%r9), %r10
    5a53:      	addq	$-0x4, %r10
    5a57:      	addq	$-0x4, %r9
    5a5b:      	cmpq	$-0x3, %r10
    5a5f:      	jne	0x59ca <generic_kprobe_process_filter+0x11aa>
    5a65:      	movl	$0x1, 0x6c(%r15)
    5a6d:      	cmpl	$0x7f, %r14d
    5a71:      	ja	0x5a99 <generic_kprobe_process_filter+0x1279>
    5a73:      	movslq	%r14d, %rsi
    5a76:      	movq	%rbp, %rdi
    5a79:      	addq	$0x4, %rdi
    5a7d:      	movq	0x38(%rsp), %rax
    5a82:      	leaq	0x1f0(%rax), %rdx
    5a89:      	movl	$0x4, %eax
    5a8e:      	callq	*%rax
    5a90:      	testq	%rax, %rax
    5a93:      	js	0x6deb <generic_kprobe_process_filter+0x25cb>
    5a99:      	movl	$0x1, %eax
    5a9e:      	movq	%r12, %rdi
    5aa1:      	jmp	0x6574 <generic_kprobe_process_filter+0x1d54>
    5aa6:      	movl	(%r15), %eax
    5aa9:      	movl	%eax, 0x10(%r14)
    5aad:      	movq	0x8(%r15), %rax
    5ab1:      	movq	%rax, 0x18(%r14)
    5ab5:      	cmpb	$0x0, 0x5ec0(%r14)
    5abd:      	jne	0x6e2e <generic_kprobe_process_filter+0x260e>
    5ac3:      	jmp	0x6e43 <generic_kprobe_process_filter+0x2623>
    5ac8:      	movb	$0x1, 0x5ec0(%r14)
    5ad0:      	movl	(%r15), %eax
    5ad3:      	movl	%eax, 0x10(%r14)
    5ad7:      	movq	0x8(%r15), %rax
    5adb:      	movq	%rax, 0x18(%r14)
    5adf:      	jmp	0x6e2e <generic_kprobe_process_filter+0x260e>
    5ae4:      	movq	0x8(%rsp), %r10
    5ae9:      	movq	(%rip), %rax            # 0x5af0 <generic_kprobe_process_filter+0x12d0>
    5af0:      	cmpb	$0x0, (%rax)
    5af3:      	je	0x5d35 <generic_kprobe_process_filter+0x1515>
    5af9:      	movq	(%rip), %rdi            # 0x5b00 <generic_kprobe_process_filter+0x12e0>
    5b00:      	movl	$0x1, %eax
    5b05:      	movq	0x38(%rsp), %rsi
    5b0a:      	callq	*%rax
    5b0c:      	movq	0x8(%rsp), %r10
    5b11:      	testq	%rax, %rax
    5b14:      	je	0x5d35 <generic_kprobe_process_filter+0x1515>
    5b1a:      	movq	%rax, %rbp
    5b1d:      	leal	0x5(%r13), %eax
    5b21:      	movl	%eax, 0x10(%rsp)
    5b25:      	movl	$0x0, 0x58(%rsp)
    5b2d:      	movq	(%rip), %rdi            # 0x5b34 <generic_kprobe_process_filter+0x1314>
    5b34:      	leaq	0x10(%rsp), %rsi
    5b39:      	movl	$0x1, %eax
    5b3e:      	callq	*%rax
    5b40:      	testq	%rax, %rax
    5b43:      	je	0x5d30 <generic_kprobe_process_filter+0x1510>
    5b49:      	movq	%rax, %r12
    5b4c:      	movl	(%rax), %eax
    5b4e:      	testl	%eax, %eax
    5b50:      	je	0x5d30 <generic_kprobe_process_filter+0x1510>
    5b56:      	cmpl	$0x0, (%rbp)
    5b5a:      	js	0x6deb <generic_kprobe_process_filter+0x25cb>
    5b60:      	cmpl	$0x1b, %eax
    5b63:      	ja	0x6deb <generic_kprobe_process_filter+0x25cb>
    5b69:      	movl	$0x60, %ecx
    5b6e:      	btl	%eax, %ecx
    5b71:      	jb	0x67d8 <generic_kprobe_process_filter+0x1fb8>
    5b77:      	movl	$0x4000100, %ecx        # imm = 0x4000100
    5b7c:      	btl	%eax, %ecx
    5b7f:      	jb	0x6748 <generic_kprobe_process_filter+0x1f28>
    5b85:      	movl	$0x8000200, %ecx        # imm = 0x8000200
    5b8a:      	btl	%eax, %ecx
    5b8d:      	jae	0x6deb <generic_kprobe_process_filter+0x25cb>
    5b93:      	movq	%r12, %rsi
    5b96:      	addq	$0x4, %rsi
    5b9a:      	movq	(%rip), %rdi            # 0x5ba1 <generic_kprobe_process_filter+0x1381>
    5ba1:      	movl	$0x1, %eax
    5ba6:      	callq	*%rax
    5ba8:      	testq	%rax, %rax
    5bab:      	je	0x6deb <generic_kprobe_process_filter+0x25cb>
    5bb1:      	movq	%rax, %r15
    5bb4:      	movl	(%rbp), %eax
    5bb7:      	cmpl	$0x7f, %eax
    5bba:      	movl	$0x7f, %r14d
    5bc0:      	cmovll	%eax, %r14d
    5bc4:      	movq	(%rip), %rdi            # 0x5bcb <generic_kprobe_process_filter+0x13ab>
    5bcb:      	leaq	0x58(%rsp), %rsi
    5bd0:      	movl	$0x1, %eax
    5bd5:      	callq	*%rax
    5bd7:      	testq	%rax, %rax
    5bda:      	je	0x6deb <generic_kprobe_process_filter+0x25cb>
    5be0:      	movq	%rax, %rbx
    5be3:      	leal	(,%r14,8), %eax
    5beb:      	movl	%eax, (%rbx)
    5bed:      	cmpl	$0x0, 0x4(%rbp)
    5bf1:      	jne	0x5ccd <generic_kprobe_process_filter+0x14ad>
    5bf7:      	movl	(%rbp), %ecx
    5bfa:      	movl	%ecx, %eax
    5bfc:      	subl	%r14d, %eax
    5bff:      	movl	%r14d, %edx
    5c02:      	andl	$0x7f, %edx
    5c05:      	addl	%edx, %eax
    5c07:      	addl	%ecx, %edx
    5c09:      	movl	%r14d, %ecx
    5c0c:      	notl	%ecx
    5c0e:      	addl	%edx, %ecx
    5c10:      	subl	%r14d, %edx
    5c13:      	leal	-0x4(%rdx), %esi
    5c16:      	leaq	0x18b(%rbp), %rdi
    5c1d:      	leal	-0x3(%rdx), %r8d
    5c21:      	addl	$-0x2, %edx
    5c24:      	movq	$-0x3, %r9
    5c2b:      	leal	(%rcx,%r9), %r10d
    5c2f:      	addl	$0x3, %r10d
    5c33:      	andl	$0x7f, %r10d
    5c37:      	movzbl	0x108(%rbp,%r10), %r10d
    5c40:      	movb	%r10b, -0x3(%rdi)
    5c44:      	leaq	(%rax,%r9), %r10
    5c48:      	cmpq	$-0x2, %r10
    5c4c:      	je	0x5cc6 <generic_kprobe_process_filter+0x14a6>
    5c4e:      	leal	(%rdx,%r9), %r11d
    5c52:      	addl	$0x3, %r11d
    5c56:      	andl	$0x7f, %r11d
    5c5a:      	movzbl	0x108(%rbp,%r11), %r11d
    5c63:      	movb	%r11b, -0x2(%rdi)
    5c67:      	cmpq	$-0x1, %r10
    5c6b:      	je	0x5cc6 <generic_kprobe_process_filter+0x14a6>
    5c6d:      	leal	(%r8,%r9), %r10d
    5c71:      	addl	$0x3, %r10d
    5c75:      	andl	$0x7f, %r10d
    5c79:      	movzbl	0x108(%rbp,%r10), %r10d
    5c82:      	movb	%r10b, -0x1(%rdi)
    5c86:      	movq	%rax, %r10
    5c89:      	addq	%r9, %r10
    5c8c:      	je	0x5cc6 <generic_kprobe_process_filter+0x14a6>
    5c8e:      	cmpq	$-0x7f, %r9
    5c92:      	je	0x5cc6 <generic_kprobe_process_filter+0x14a6>
    5c94:      	leal	(%rsi,%r9), %r10d
    5c98:      	addl	$0x3, %r10d
    5c9c:      	andl	$0x7f, %r10d
    5ca0:      	movzbl	0x108(%rbp,%r10), %r10d
    5ca9:      	movb	%r10b, (%rdi)
    5cac:      	addq	$0x4, %rdi
    5cb0:      	leaq	(%rax,%r9), %r10
    5cb4:      	addq	$-0x4, %r10
    5cb8:      	addq	$-0x4, %r9
    5cbc:      	cmpq	$-0x3, %r10
    5cc0:      	jne	0x5c2b <generic_kprobe_process_filter+0x140b>
    5cc6:      	movl	$0x1, 0x4(%rbp)
    5ccd:      	cmpl	$0x7f, %r14d
    5cd1:      	ja	0x5cf7 <generic_kprobe_process_filter+0x14d7>
    5cd3:      	movslq	%r14d, %rsi
    5cd6:      	movq	%rbx, %rdi
    5cd9:      	addq	$0x4, %rdi
    5cdd:      	addq	$0x188, %rbp            # imm = 0x188
    5ce4:      	movl	$0x4, %eax
    5ce9:      	movq	%rbp, %rdx
    5cec:      	callq	*%rax
    5cee:      	testq	%rax, %rax
    5cf1:      	js	0x6deb <generic_kprobe_process_filter+0x25cb>
    5cf7:      	movl	$0x1, %eax
    5cfc:      	movq	%r15, %rdi
    5cff:      	jmp	0x67d0 <generic_kprobe_process_filter+0x1fb0>
    5d04:      	movq	%r12, %r13
    5d07:      	addq	$0xff6, %r13            # imm = 0xFF6
    5d0e:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
    5d18:      	movq	%rax, 0xff6(%r12)
    5d20:      	movw	$0x2964, 0xffe(%r12)    # imm = 0x2964
    5d2b:      	jmp	0x5063 <generic_kprobe_process_filter+0x843>
    5d30:      	movq	0x8(%rsp), %r10
    5d35:      	movl	%r13d, %eax
    5d38:      	leaq	0x4(,%rax,4), %rcx
    5d40:      	movl	0x4(%r10,%rax,4), %eax
    5d45:      	leal	(%rax,%rcx), %r14d
    5d49:      	andl	$0x3ff, %r14d           # imm = 0x3FF
    5d50:      	addl	%eax, %ecx
    5d52:      	addl	$0x4, %ecx
    5d55:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5d5b:      	leaq	0x8(%r14), %rbp
    5d5f:      	cmpl	$0x5, (%rcx,%r10)
    5d64:      	jb	0x628e <generic_kprobe_process_filter+0x1a6e>
    5d6a:      	movl	(%rbp,%r10), %r12d
    5d6f:      	movl	0x4(%rbp,%r10), %edi
    5d74:      	movl	0x8(%rbp,%r10), %edx
    5d79:      	movq	$0x0, 0x68(%rsp)
    5d82:      	movq	$0x0, 0x60(%rsp)
    5d8b:      	cmpl	$0x4, %edx
    5d8e:      	movl	$0x4, %ecx
    5d93:      	cmovbl	%edx, %ecx
    5d96:      	cmpl	$0x6, %r12d
    5d9a:      	jne	0x5db0 <generic_kprobe_process_filter+0x1590>
    5d9c:      	movabsq	$0x100000001, %rsi      # imm = 0x100000001
    5da6:      	movq	%rsi, 0x60(%rsp)
    5dab:      	movq	%rsi, 0x68(%rsp)
    5db0:      	testl	%edx, %edx
    5db2:      	je	0x6295 <generic_kprobe_process_filter+0x1a75>
    5db8:      	movq	0x38(%rsp), %rdx
    5dbd:      	leaq	0x24(%rdx), %rsi
    5dc1:      	testb	$0x1, %dil
    5dc5:      	movq	%rsi, 0xb0(%rsp)
    5dcd:      	movq	%rsi, %r8
    5dd0:      	cmoveq	%rdx, %r8
    5dd4:      	addq	$0x10, %rdx
    5dd8:      	movq	%rdx, 0xd0(%rsp)
    5de0:      	leal	(%rax,%r13,4), %r9d
    5de4:      	addl	$0x4, %r9d
    5de8:      	andl	$0x3ff, %r9d            # imm = 0x3FF
    5def:      	addq	$0x14, %r9
    5df3:      	decq	%rcx
    5df6:      	cmpq	$0x3, %rcx
    5dfa:      	movl	$0x3, %eax
    5dff:      	cmovbq	%rcx, %rax
    5e03:      	movl	%eax, %eax
    5e05:      	leaq	0x4(,%rax,4), %r11
    5e0d:      	xorl	%r13d, %r13d
    5e10:      	movq	%rdi, 0x30(%rsp)
    5e15:      	movq	%r8, 0x28(%rsp)
    5e1a:      	movq	%r9, 0x20(%rsp)
    5e1f:      	movq	%r11, 0x18(%rsp)
    5e24:      	jmp	0x5e60 <generic_kprobe_process_filter+0x1640>
    5e26:      	movq	0x8(%rsp), %r10
    5e2b:      	movq	0x30(%rsp), %rdi
    5e30:      	movq	0x28(%rsp), %r8
    5e35:      	movq	0x20(%rsp), %r9
    5e3a:      	movq	0x18(%rsp), %r11
    5e3f:      	cmpl	$0x6, %r12d
    5e43:      	setne	%al
    5e46:      	xorb	$0x1, %bl
    5e49:      	orb	%al, %bl
    5e4b:      	movzbl	%bl, %eax
    5e4e:      	movl	%eax, 0x60(%rsp,%r13)
    5e53:      	addq	$0x4, %r13
    5e57:      	cmpq	%r13, %r11
    5e5a:      	je	0x6295 <generic_kprobe_process_filter+0x1a75>
    5e60:      	leaq	(%r9,%r13), %rax
    5e64:      	movl	(%r8), %ecx
    5e67:      	cmpq	$0x3e8, %rax            # imm = 0x3E8
    5e6d:      	jbe	0x607a <generic_kprobe_process_filter+0x185a>
    5e73:      	xorl	%r15d, %r15d
    5e76:      	testb	$0x2, %dil
    5e7a:      	je	0x6097 <generic_kprobe_process_filter+0x1877>
    5e80:      	testb	$0x1, %dil
    5e84:      	jne	0x60b8 <generic_kprobe_process_filter+0x1898>
    5e8a:      	movq	0x38(%rsp), %rcx
    5e8f:      	movl	(%rcx), %eax
    5e91:      	movb	$0x1, %bl
    5e93:      	cmpq	%rax, %r15
    5e96:      	je	0x5e3f <generic_kprobe_process_filter+0x161f>
    5e98:      	movl	0x10(%rcx), %eax
    5e9b:      	cmpq	%rax, %r15
    5e9e:      	je	0x5e3f <generic_kprobe_process_filter+0x161f>
    5ea0:      	movl	$0x1, %eax
    5ea5:      	movq	0xd0(%rsp), %rsi
    5ead:      	movq	(%rip), %rdi            # 0x5eb4 <generic_kprobe_process_filter+0x1694>
    5eb4:      	callq	*%rax
    5eb6:      	testq	%rax, %rax
    5eb9:      	je	0x625d <generic_kprobe_process_filter+0x1a3d>
    5ebf:      	movq	%rax, %rsi
    5ec2:      	movl	(%rax), %eax
    5ec4:      	cmpq	%rax, %r15
    5ec7:      	je	0x5e26 <generic_kprobe_process_filter+0x1606>
    5ecd:      	movl	0x10(%rsi), %eax
    5ed0:      	cmpq	%rax, %r15
    5ed3:      	je	0x5e26 <generic_kprobe_process_filter+0x1606>
    5ed9:      	addq	$0x10, %rsi
    5edd:      	movl	$0x1, %eax
    5ee2:      	movq	(%rip), %rdi            # 0x5ee9 <generic_kprobe_process_filter+0x16c9>
    5ee9:      	callq	*%rax
    5eeb:      	testq	%rax, %rax
    5eee:      	je	0x625d <generic_kprobe_process_filter+0x1a3d>
    5ef4:      	movq	%rax, %rsi
    5ef7:      	movl	(%rax), %eax
    5ef9:      	cmpq	%rax, %r15
    5efc:      	je	0x5e26 <generic_kprobe_process_filter+0x1606>
    5f02:      	movl	0x10(%rsi), %eax
    5f05:      	cmpq	%rax, %r15
    5f08:      	je	0x5e26 <generic_kprobe_process_filter+0x1606>
    5f0e:      	addq	$0x10, %rsi
    5f12:      	movl	$0x1, %eax
    5f17:      	movq	(%rip), %rdi            # 0x5f1e <generic_kprobe_process_filter+0x16fe>
    5f1e:      	callq	*%rax
    5f20:      	testq	%rax, %rax
    5f23:      	je	0x625d <generic_kprobe_process_filter+0x1a3d>
    5f29:      	movq	%rax, %rsi
    5f2c:      	movl	(%rax), %eax
    5f2e:      	cmpq	%rax, %r15
    5f31:      	je	0x5e26 <generic_kprobe_process_filter+0x1606>
    5f37:      	movl	0x10(%rsi), %eax
    5f3a:      	cmpq	%rax, %r15
    5f3d:      	je	0x5e26 <generic_kprobe_process_filter+0x1606>
    5f43:      	addq	$0x10, %rsi
    5f47:      	movl	$0x1, %eax
    5f4c:      	movq	(%rip), %rdi            # 0x5f53 <generic_kprobe_process_filter+0x1733>
    5f53:      	callq	*%rax
    5f55:      	testq	%rax, %rax
    5f58:      	je	0x625d <generic_kprobe_process_filter+0x1a3d>
    5f5e:      	movq	%rax, %rsi
    5f61:      	movl	(%rax), %eax
    5f63:      	cmpq	%rax, %r15
    5f66:      	je	0x5e26 <generic_kprobe_process_filter+0x1606>
    5f6c:      	movl	0x10(%rsi), %eax
    5f6f:      	cmpq	%rax, %r15
    5f72:      	je	0x5e26 <generic_kprobe_process_filter+0x1606>
    5f78:      	addq	$0x10, %rsi
    5f7c:      	movl	$0x1, %eax
    5f81:      	movq	(%rip), %rdi            # 0x5f88 <generic_kprobe_process_filter+0x1768>
    5f88:      	callq	*%rax
    5f8a:      	testq	%rax, %rax
    5f8d:      	je	0x625d <generic_kprobe_process_filter+0x1a3d>
    5f93:      	movq	%rax, %rsi
    5f96:      	movl	(%rax), %eax
    5f98:      	cmpq	%rax, %r15
    5f9b:      	je	0x5e26 <generic_kprobe_process_filter+0x1606>
    5fa1:      	movl	0x10(%rsi), %eax
    5fa4:      	cmpq	%rax, %r15
    5fa7:      	je	0x5e26 <generic_kprobe_process_filter+0x1606>
    5fad:      	addq	$0x10, %rsi
    5fb1:      	movl	$0x1, %eax
    5fb6:      	movq	(%rip), %rdi            # 0x5fbd <generic_kprobe_process_filter+0x179d>
    5fbd:      	callq	*%rax
    5fbf:      	testq	%rax, %rax
    5fc2:      	je	0x625d <generic_kprobe_process_filter+0x1a3d>
    5fc8:      	movq	%rax, %rsi
    5fcb:      	movl	(%rax), %eax
    5fcd:      	cmpq	%rax, %r15
    5fd0:      	je	0x5e26 <generic_kprobe_process_filter+0x1606>
    5fd6:      	movl	0x10(%rsi), %eax
    5fd9:      	cmpq	%rax, %r15
    5fdc:      	je	0x5e26 <generic_kprobe_process_filter+0x1606>
    5fe2:      	addq	$0x10, %rsi
    5fe6:      	movl	$0x1, %eax
    5feb:      	movq	(%rip), %rdi            # 0x5ff2 <generic_kprobe_process_filter+0x17d2>
    5ff2:      	callq	*%rax
    5ff4:      	testq	%rax, %rax
    5ff7:      	je	0x625d <generic_kprobe_process_filter+0x1a3d>
    5ffd:      	movq	%rax, %rsi
    6000:      	movl	(%rax), %eax
    6002:      	cmpq	%rax, %r15
    6005:      	je	0x5e26 <generic_kprobe_process_filter+0x1606>
    600b:      	movl	0x10(%rsi), %eax
    600e:      	cmpq	%rax, %r15
    6011:      	je	0x5e26 <generic_kprobe_process_filter+0x1606>
    6017:      	addq	$0x10, %rsi
    601b:      	movl	$0x1, %eax
    6020:      	movq	(%rip), %rdi            # 0x6027 <generic_kprobe_process_filter+0x1807>
    6027:      	callq	*%rax
    6029:      	testq	%rax, %rax
    602c:      	je	0x625d <generic_kprobe_process_filter+0x1a3d>
    6032:      	movq	%rax, %rsi
    6035:      	movl	(%rax), %eax
    6037:      	cmpq	%rax, %r15
    603a:      	je	0x5e26 <generic_kprobe_process_filter+0x1606>
    6040:      	movl	0x10(%rsi), %eax
    6043:      	cmpq	%rax, %r15
    6046:      	movq	0x8(%rsp), %r10
    604b:      	movq	0x30(%rsp), %rdi
    6050:      	movq	0x28(%rsp), %r8
    6055:      	movq	0x20(%rsp), %r9
    605a:      	movq	0x18(%rsp), %r11
    605f:      	je	0x5e3f <generic_kprobe_process_filter+0x161f>
    6065:      	addq	$0x10, %rsi
    6069:      	movl	$0x1, %eax
    606e:      	movq	(%rip), %rcx            # 0x6075 <generic_kprobe_process_filter+0x1855>
    6075:      	jmp	0x6254 <generic_kprobe_process_filter+0x1a34>
    607a:      	movl	$0x4, %esi
    607f:      	xorl	%edx, %edx
    6081:      	divq	%rsi
    6084:      	andl	$0x3ff, %eax            # imm = 0x3FF
    6089:      	movl	(%r10,%rax,4), %r15d
    608d:      	testb	$0x2, %dil
    6091:      	jne	0x5e80 <generic_kprobe_process_filter+0x1660>
    6097:      	cmpl	$0x5, %r12d
    609b:      	jne	0x60a6 <generic_kprobe_process_filter+0x1886>
    609d:      	cmpq	%rcx, %r15
    60a0:      	jne	0x6287 <generic_kprobe_process_filter+0x1a67>
    60a6:      	cmpq	%rcx, %r15
    60a9:      	setne	%al
    60ac:      	cmpl	$0x6, %r12d
    60b0:      	setne	%bl
    60b3:      	jmp	0x5e49 <generic_kprobe_process_filter+0x1629>
    60b8:      	movq	0xb0(%rsp), %rax
    60c0:      	movl	(%rax), %eax
    60c2:      	testq	%rax, %rax
    60c5:      	je	0x6287 <generic_kprobe_process_filter+0x1a67>
    60cb:      	movb	$0x1, %bl
    60cd:      	testq	%r15, %r15
    60d0:      	je	0x5e3f <generic_kprobe_process_filter+0x161f>
    60d6:      	cmpq	%rax, %r15
    60d9:      	je	0x5e3f <generic_kprobe_process_filter+0x161f>
    60df:      	movl	$0x1, %eax
    60e4:      	movq	0xd0(%rsp), %rsi
    60ec:      	movq	(%rip), %rdi            # 0x60f3 <generic_kprobe_process_filter+0x18d3>
    60f3:      	callq	*%rax
    60f5:      	testq	%rax, %rax
    60f8:      	je	0x625d <generic_kprobe_process_filter+0x1a3d>
    60fe:      	movq	%rax, %rsi
    6101:      	movl	0x24(%rax), %eax
    6104:      	cmpq	%rax, %r15
    6107:      	je	0x5e26 <generic_kprobe_process_filter+0x1606>
    610d:      	addq	$0x10, %rsi
    6111:      	movl	$0x1, %eax
    6116:      	movq	(%rip), %rdi            # 0x611d <generic_kprobe_process_filter+0x18fd>
    611d:      	callq	*%rax
    611f:      	testq	%rax, %rax
    6122:      	je	0x625d <generic_kprobe_process_filter+0x1a3d>
    6128:      	movq	%rax, %rsi
    612b:      	movl	0x24(%rax), %eax
    612e:      	cmpq	%rax, %r15
    6131:      	je	0x5e26 <generic_kprobe_process_filter+0x1606>
    6137:      	addq	$0x10, %rsi
    613b:      	movl	$0x1, %eax
    6140:      	movq	(%rip), %rdi            # 0x6147 <generic_kprobe_process_filter+0x1927>
    6147:      	callq	*%rax
    6149:      	testq	%rax, %rax
    614c:      	je	0x625d <generic_kprobe_process_filter+0x1a3d>
    6152:      	movq	%rax, %rsi
    6155:      	movl	0x24(%rax), %eax
    6158:      	cmpq	%rax, %r15
    615b:      	je	0x5e26 <generic_kprobe_process_filter+0x1606>
    6161:      	addq	$0x10, %rsi
    6165:      	movl	$0x1, %eax
    616a:      	movq	(%rip), %rdi            # 0x6171 <generic_kprobe_process_filter+0x1951>
    6171:      	callq	*%rax
    6173:      	testq	%rax, %rax
    6176:      	je	0x625d <generic_kprobe_process_filter+0x1a3d>
    617c:      	movq	%rax, %rsi
    617f:      	movl	0x24(%rax), %eax
    6182:      	cmpq	%rax, %r15
    6185:      	je	0x5e26 <generic_kprobe_process_filter+0x1606>
    618b:      	addq	$0x10, %rsi
    618f:      	movl	$0x1, %eax
    6194:      	movq	(%rip), %rdi            # 0x619b <generic_kprobe_process_filter+0x197b>
    619b:      	callq	*%rax
    619d:      	testq	%rax, %rax
    61a0:      	je	0x625d <generic_kprobe_process_filter+0x1a3d>
    61a6:      	movq	%rax, %rsi
    61a9:      	movl	0x24(%rax), %eax
    61ac:      	cmpq	%rax, %r15
    61af:      	je	0x5e26 <generic_kprobe_process_filter+0x1606>
    61b5:      	addq	$0x10, %rsi
    61b9:      	movl	$0x1, %eax
    61be:      	movq	(%rip), %rdi            # 0x61c5 <generic_kprobe_process_filter+0x19a5>
    61c5:      	callq	*%rax
    61c7:      	testq	%rax, %rax
    61ca:      	je	0x625d <generic_kprobe_process_filter+0x1a3d>
    61d0:      	movq	%rax, %rsi
    61d3:      	movl	0x24(%rax), %eax
    61d6:      	cmpq	%rax, %r15
    61d9:      	je	0x5e26 <generic_kprobe_process_filter+0x1606>
    61df:      	addq	$0x10, %rsi
    61e3:      	movl	$0x1, %eax
    61e8:      	movq	(%rip), %rdi            # 0x61ef <generic_kprobe_process_filter+0x19cf>
    61ef:      	callq	*%rax
    61f1:      	testq	%rax, %rax
    61f4:      	je	0x625d <generic_kprobe_process_filter+0x1a3d>
    61f6:      	movq	%rax, %rsi
    61f9:      	movl	0x24(%rax), %eax
    61fc:      	cmpq	%rax, %r15
    61ff:      	je	0x5e26 <generic_kprobe_process_filter+0x1606>
    6205:      	addq	$0x10, %rsi
    6209:      	movl	$0x1, %eax
    620e:      	movq	(%rip), %rdi            # 0x6215 <generic_kprobe_process_filter+0x19f5>
    6215:      	callq	*%rax
    6217:      	testq	%rax, %rax
    621a:      	je	0x625d <generic_kprobe_process_filter+0x1a3d>
    621c:      	movq	%rax, %rsi
    621f:      	movl	0x24(%rax), %eax
    6222:      	cmpq	%rax, %r15
    6225:      	movq	0x8(%rsp), %r10
    622a:      	movq	0x30(%rsp), %rdi
    622f:      	movq	0x28(%rsp), %r8
    6234:      	movq	0x20(%rsp), %r9
    6239:      	movq	0x18(%rsp), %r11
    623e:      	je	0x5e3f <generic_kprobe_process_filter+0x161f>
    6244:      	addq	$0x10, %rsi
    6248:      	movl	$0x1, %eax
    624d:      	movq	(%rip), %rcx            # 0x6254 <generic_kprobe_process_filter+0x1a34>
    6254:      	movq	(%rip), %rdi            # 0x625b <generic_kprobe_process_filter+0x1a3b>
    625b:      	callq	*%rax
    625d:      	xorl	%ebx, %ebx
    625f:      	cmpl	$0x5, %r12d
    6263:      	movq	0x8(%rsp), %r10
    6268:      	movq	0x30(%rsp), %rdi
    626d:      	movq	0x28(%rsp), %r8
    6272:      	movq	0x20(%rsp), %r9
    6277:      	movq	0x18(%rsp), %r11
    627c:      	jne	0x5e3f <generic_kprobe_process_filter+0x161f>
    6282:      	jmp	0x5e4b <generic_kprobe_process_filter+0x162b>
    6287:      	xorl	%ebx, %ebx
    6289:      	jmp	0x5e4b <generic_kprobe_process_filter+0x162b>
    628e:      	movl	$0x1, %eax
    6293:      	jmp	0x62d1 <generic_kprobe_process_filter+0x1ab1>
    6295:      	movl	0x60(%rsp), %esi
    6299:      	movl	0x64(%rsp), %ecx
    629d:      	movl	0x68(%rsp), %eax
    62a1:      	movl	0x6c(%rsp), %edx
    62a5:      	cmpl	$0x6, %r12d
    62a9:      	jne	0x62b3 <generic_kprobe_process_filter+0x1a93>
    62ab:      	andl	%esi, %ecx
    62ad:      	andl	%edx, %eax
    62af:      	andl	%ecx, %eax
    62b1:      	jmp	0x62b9 <generic_kprobe_process_filter+0x1a99>
    62b3:      	orl	%esi, %ecx
    62b5:      	orl	%edx, %eax
    62b7:      	orl	%ecx, %eax
    62b9:      	testl	%eax, %eax
    62bb:      	je	0x6deb <generic_kprobe_process_filter+0x25cb>
    62c1:      	addl	$0x14, %r14d
    62c5:      	movl	0x8(%r10,%rbp), %ecx
    62ca:      	andl	$0x7, %ecx
    62cd:      	leal	(%r14,%rcx,4), %ebp
    62d1:      	movq	0x50(%rsp), %r9
    62d6:      	movl	%ebp, %ecx
    62d8:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    62de:      	movl	(%rcx,%r10), %ecx
    62e2:      	addl	$0x4, %ebp
    62e5:      	addl	$-0x4, %ecx
    62e8:      	xorl	%esi, %esi
    62ea:      	movl	$0x4, %r8d
    62f0:      	jmp	0x630f <generic_kprobe_process_filter+0x1aef>
    62f2:      	nopw	%cs:(%rax,%rax)
    6300:      	xorl	%ecx, %ecx
    6302:      	incq	%rsi
    6305:      	cmpq	$0xa, %rsi
    6309:      	je	0x6498 <generic_kprobe_process_filter+0x1c78>
    630f:      	testl	%ecx, %ecx
    6311:      	je	0x6300 <generic_kprobe_process_filter+0x1ae0>
    6313:      	movl	%ebp, %r9d
    6316:      	andl	$0x3ff, %r9d            # imm = 0x3FF
    631d:      	movl	(%r9,%r10), %r11d
    6321:      	movq	%r10, %rax
    6324:      	movl	0x4(%r9,%r10), %r10d
    6329:      	movl	0x8(%r9,%rax), %edx
    632e:      	movq	$0x0, 0x68(%rsp)
    6337:      	movq	$0x0, 0x60(%rsp)
    6340:      	cmpl	$0x4, %edx
    6343:      	movl	$0x4, %eax
    6348:      	cmovbl	%edx, %eax
    634b:      	cmpl	$0x6, %r10d
    634f:      	jne	0x6365 <generic_kprobe_process_filter+0x1b45>
    6351:      	movabsq	$0x100000001, %rdi      # imm = 0x100000001
    635b:      	movq	%rdi, 0x60(%rsp)
    6360:      	movq	%rdi, 0x68(%rsp)
    6365:      	addl	$0xc, %ebp
    6368:      	testl	%edx, %edx
    636a:      	je	0x6440 <generic_kprobe_process_filter+0x1c20>
    6370:      	andl	$0xf, %r11d
    6374:      	decq	%rax
    6377:      	cmpq	$0x3, %rax
    637b:      	movl	$0x3, %edx
    6380:      	cmovaeq	%rdx, %rax
    6384:      	leaq	0x4(,%rax,4), %rbx
    638c:      	movl	%ebp, %r14d
    638f:      	cmpl	$0x9, %r11d
    6393:      	jbe	0x63ca <generic_kprobe_process_filter+0x1baa>
    6395:      	xorl	%r11d, %r11d
    6398:      	jmp	0x63b6 <generic_kprobe_process_filter+0x1b96>
    639a:      	nopw	(%rax,%rax)
    63a0:      	movl	$0x0, 0x60(%rsp,%r11)
    63a9:      	addq	$0x4, %r11
    63ad:      	cmpq	%r11, %rbx
    63b0:      	je	0x6440 <generic_kprobe_process_filter+0x1c20>
    63b6:      	leaq	(%r14,%r11), %rax
    63ba:      	cmpl	$0x3e8, %eax            # imm = 0x3E8
    63bf:      	ja	0x63a0 <generic_kprobe_process_filter+0x1b80>
    63c1:      	movl	%eax, %eax
    63c3:      	xorl	%edx, %edx
    63c5:      	divq	%r8
    63c8:      	jmp	0x63a0 <generic_kprobe_process_filter+0x1b80>
    63ca:      	xorl	%r15d, %r15d
    63cd:      	jmp	0x6411 <generic_kprobe_process_filter+0x1bf1>
    63cf:      	nop
    63d0:      	cmpl	$0x5, %r10d
    63d4:      	setne	%dl
    63d7:      	movl	%r10d, %r13d
    63da:      	xorl	$0x6, %r13d
    63de:      	movq	0x50(%rsp), %rax
    63e3:      	movl	0x20(%rax,%r11,4), %edi
    63e8:      	movl	%r12d, %eax
    63eb:      	xorl	%edi, %eax
    63ed:      	cmpl	%edi, %r12d
    63f0:      	sete	%dil
    63f4:      	orb	%dl, %dil
    63f7:      	orl	%r13d, %eax
    63fa:      	setne	%al
    63fd:      	andb	%dil, %al
    6400:      	movzbl	%al, %eax
    6403:      	movl	%eax, 0x60(%rsp,%r15)
    6408:      	addq	$0x4, %r15
    640c:      	cmpq	%r15, %rbx
    640f:      	je	0x6440 <generic_kprobe_process_filter+0x1c20>
    6411:      	leaq	(%r14,%r15), %rdx
    6415:      	xorl	%r12d, %r12d
    6418:      	cmpl	$0x3e8, %edx            # imm = 0x3E8
    641e:      	ja	0x63d0 <generic_kprobe_process_filter+0x1bb0>
    6420:      	movl	%edx, %eax
    6422:      	xorl	%edx, %edx
    6424:      	divq	%r8
    6427:      	andl	$0x3ff, %eax            # imm = 0x3FF
    642c:      	movq	0x8(%rsp), %rdx
    6431:      	movl	(%rdx,%rax,4), %r12d
    6435:      	jmp	0x63d0 <generic_kprobe_process_filter+0x1bb0>
    6437:      	nopw	(%rax,%rax)
    6440:      	movl	0x60(%rsp), %ebx
    6444:      	movl	0x64(%rsp), %edx
    6448:      	movl	0x68(%rsp), %eax
    644c:      	movl	0x6c(%rsp), %r11d
    6451:      	cmpl	$0x6, %r10d
    6455:      	jne	0x6460 <generic_kprobe_process_filter+0x1c40>
    6457:      	andl	%ebx, %edx
    6459:      	andl	%r11d, %eax
    645c:      	andl	%edx, %eax
    645e:      	jmp	0x6467 <generic_kprobe_process_filter+0x1c47>
    6460:      	orl	%ebx, %edx
    6462:      	orl	%r11d, %eax
    6465:      	orl	%edx, %eax
    6467:      	movq	0x8(%rsp), %r10
    646c:      	testl	%eax, %eax
    646e:      	je	0x6deb <generic_kprobe_process_filter+0x25cb>
    6474:      	movl	0x8(%r10,%r9), %edx
    6479:      	shll	$0x2, %edx
    647c:      	subl	%edx, %ecx
    647e:      	andl	$0x1c, %edx
    6481:      	addl	%edx, %ebp
    6483:      	addl	$-0xc, %ecx
    6486:      	movq	0x50(%rsp), %r9
    648b:      	incq	%rsi
    648e:      	cmpq	$0xa, %rsi
    6492:      	jne	0x630f <generic_kprobe_process_filter+0x1aef>
    6498:      	movl	%ebp, %ecx
    649a:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    64a0:      	leal	0x4(%rbp), %ebx
    64a3:      	cmpl	$0x4, (%rcx,%r10)
    64a8:      	je	0x6678 <generic_kprobe_process_filter+0x1e58>
    64ae:      	andl	$0x3ff, %ebx            # imm = 0x3FF
    64b4:      	movl	(%rbx,%r10), %ecx
    64b8:      	movl	0x4(%rbx,%r10), %edx
    64bd:      	movl	0x8(%rbx,%r10), %edi
    64c2:      	movq	0xc(%rbx,%r10), %rax
    64c7:      	testl	%edi, %edi
    64c9:      	je	0x664c <generic_kprobe_process_filter+0x1e2c>
    64cf:      	xorl	%esi, %esi
    64d1:      	cmpl	$0x2, %ecx
    64d4:      	ja	0x666f <generic_kprobe_process_filter+0x1e4f>
    64da:      	cmpl	%edi, 0x44(%r9)
    64de:      	jne	0x6655 <generic_kprobe_process_filter+0x1e35>
    64e4:      	jmp	0x666f <generic_kprobe_process_filter+0x1e4f>
    64e9:      	movq	%rbx, %rsi
    64ec:      	addq	$0x4, %rsi
    64f0:      	movq	(%rip), %rdi            # 0x64f7 <generic_kprobe_process_filter+0x1cd7>
    64f7:      	movl	$0x1, %eax
    64fc:      	callq	*%rax
    64fe:      	testq	%rax, %rax
    6501:      	je	0x6deb <generic_kprobe_process_filter+0x25cb>
    6507:      	movq	%rax, %r14
    650a:      	movq	(%rip), %rdi            # 0x6511 <generic_kprobe_process_filter+0x1cf1>
    6511:      	leaq	0x58(%rsp), %rsi
    6516:      	movl	$0x1, %eax
    651b:      	callq	*%rax
    651d:      	testq	%rax, %rax
    6520:      	je	0x6deb <generic_kprobe_process_filter+0x25cb>
    6526:      	movq	%rax, %rbp
    6529:      	movl	$0x104, %edx            # imm = 0x104
    652e:      	movq	%rax, %rdi
    6531:      	xorl	%esi, %esi
    6533:      	callq	0x6538 <generic_kprobe_process_filter+0x1d18>
    6538:      	movq	0x38(%rsp), %rsi
    653d:      	movl	0x68(%rsi), %eax
    6540:      	leal	(,%rax,8), %ecx
    6547:      	movl	%ecx, (%rbp)
    654a:      	movq	%rbp, %rdi
    654d:      	addq	$0x4, %rdi
    6551:      	movzbl	%al, %ecx
    6554:      	leaq	0x70(%rsi), %rdx
    6558:      	movl	$0x4, %eax
    655d:      	movzbl	0x68(%rsi), %esi
    6561:      	callq	*%rax
    6563:      	testq	%rax, %rax
    6566:      	js	0x6deb <generic_kprobe_process_filter+0x25cb>
    656c:      	movl	$0x1, %eax
    6571:      	movq	%r14, %rdi
    6574:      	movq	%rbp, %rsi
    6577:      	jmp	0x6977 <generic_kprobe_process_filter+0x2157>
    657c:      	movl	$0x0, 0x40(%rsp)
    6584:      	movq	(%rip), %rdi            # 0x658b <generic_kprobe_process_filter+0x1d6b>
    658b:      	leaq	0x40(%rsp), %rsi
    6590:      	movl	$0x1, %eax
    6595:      	callq	*%rax
    6597:      	testq	%rax, %rax
    659a:      	movq	0x38(%rsp), %rdx
    659f:      	je	0x6924 <generic_kprobe_process_filter+0x2104>
    65a5:      	movq	(%rax), %rcx
    65a8:      	cmpq	0x378(%rdx), %rcx
    65af:      	je	0x6924 <generic_kprobe_process_filter+0x2104>
    65b5:      	movq	%rax, 0xb0(%rsp)
    65bd:      	movq	(%rip), %rax            # 0x65c4 <generic_kprobe_process_filter+0x1da4>
    65c4:      	cmpb	$0x0, (%rax)
    65c7:      	je	0x689b <generic_kprobe_process_filter+0x207b>
    65cd:      	movl	$0x1869f, %r15d         # imm = 0x1869F
    65d3:      	xorl	%r14d, %r14d
    65d6:      	movq	(%rip), %r12            # 0x65dd <generic_kprobe_process_filter+0x1dbd>
    65dd:      	movq	0x38(%rsp), %rax
    65e2:      	movl	0x10(%rax), %eax
    65e5:      	movl	%eax, 0x60(%rsp)
    65e9:      	movl	$0x1, %eax
    65ee:      	leaq	0x60(%rsp), %rsi
    65f3:      	movq	%r12, %rdi
    65f6:      	callq	*%rax
    65f8:      	testq	%rax, %rax
    65fb:      	je	0x690d <generic_kprobe_process_filter+0x20ed>
    6601:      	movq	%rax, %rbp
    6604:      	leaq	0x70(%rax), %rsi
    6608:      	movl	$0x1, %eax
    660d:      	movq	(%rip), %rdi            # 0x6614 <generic_kprobe_process_filter+0x1df4>
    6614:      	callq	*%rax
    6616:      	testq	%rax, %rax
    6619:      	je	0x6630 <generic_kprobe_process_filter+0x1e10>
    661b:      	movq	(%rax), %rax
    661e:      	testq	%rax, %rax
    6621:      	je	0x6630 <generic_kprobe_process_filter+0x1e10>
    6623:      	movq	0x38(%rsp), %rcx
    6628:      	lock
    6629:      	orq	%rax, 0x370(%rcx)
    6630:      	subl	$0x1, %r15d
    6634:      	setb	%al
    6637:      	cmpq	%r14, %rbp
    663a:      	je	0x690d <generic_kprobe_process_filter+0x20ed>
    6640:      	movq	%rbp, %r14
    6643:      	testb	%al, %al
    6645:      	je	0x65dd <generic_kprobe_process_filter+0x1dbd>
    6647:      	jmp	0x690d <generic_kprobe_process_filter+0x20ed>
    664c:      	cmpl	$0x2, %ecx
    664f:      	jbe	0x6655 <generic_kprobe_process_filter+0x1e35>
    6651:      	xorl	%esi, %esi
    6653:      	jmp	0x666f <generic_kprobe_process_filter+0x1e4f>
    6655:      	andq	0x48(%r9,%rcx,8), %rax
    665a:      	cmpl	$0x5, %edx
    665d:      	jne	0x6668 <generic_kprobe_process_filter+0x1e48>
    665f:      	testq	%rax, %rax
    6662:      	setne	%sil
    6666:      	jmp	0x666f <generic_kprobe_process_filter+0x1e4f>
    6668:      	testq	%rax, %rax
    666b:      	sete	%sil
    666f:      	addl	$0x18, %ebp
    6672:      	movzbl	%sil, %eax
    6676:      	movl	%ebp, %ebx
    6678:      	testl	%eax, %eax
    667a:      	je	0x6deb <generic_kprobe_process_filter+0x25cb>
    6680:      	movl	%ebx, %ecx
    6682:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    6688:      	leal	0x4(%rbx), %eax
    668b:      	cmpl	$0x4, (%rcx,%r10)
    6690:      	je	0x6cf3 <generic_kprobe_process_filter+0x24d3>
    6696:      	andl	$0x3ff, %eax            # imm = 0x3FF
    669b:      	movl	(%rax,%r10), %r14d
    669f:      	movl	0x4(%rax,%r10), %ebp
    66a4:      	movl	$0xe, %eax
    66a9:      	callq	*%rax
    66ab:      	shrq	$0x20, %rax
    66af:      	movl	%eax, 0x60(%rsp)
    66b3:      	movq	(%rip), %rdi            # 0x66ba <generic_kprobe_process_filter+0x1e9a>
    66ba:      	leaq	0x60(%rsp), %rsi
    66bf:      	movl	$0x1, %eax
    66c4:      	callq	*%rax
    66c6:      	movq	0x8(%rsp), %r10
    66cb:      	testq	%rax, %rax
    66ce:      	je	0x6deb <generic_kprobe_process_filter+0x25cb>
    66d4:      	cmpl	$0x5, %r14d
    66d8:      	je	0x6716 <generic_kprobe_process_filter+0x1ef6>
    66da:      	cmpl	$0x6, %r14d
    66de:      	jne	0x6deb <generic_kprobe_process_filter+0x25cb>
    66e4:      	movq	0x50(%rsp), %rsi
    66e9:      	movq	%rsi, %rcx
    66ec:      	addq	$0x5ee8, %rcx           # imm = 0x5EE8
    66f3:      	testb	$0x1, %bpl
    66f7:      	jne	0x69b9 <generic_kprobe_process_filter+0x2199>
    66fd:      	movl	0x28(%rax), %edx
    6700:      	testl	%edx, %edx
    6702:      	je	0x69b2 <generic_kprobe_process_filter+0x2192>
    6708:      	cmpl	0x20(%rsi), %edx
    670b:      	je	0x69b9 <generic_kprobe_process_filter+0x2199>
    6711:      	jmp	0x6ce7 <generic_kprobe_process_filter+0x24c7>
    6716:      	movq	0x50(%rsp), %rsi
    671b:      	movq	%rsi, %rcx
    671e:      	addq	$0x5ee8, %rcx           # imm = 0x5EE8
    6725:      	testb	$0x1, %bpl
    6729:      	je	0x69d7 <generic_kprobe_process_filter+0x21b7>
    672f:      	movl	0x28(%rax), %edx
    6732:      	testl	%edx, %edx
    6734:      	je	0x69d0 <generic_kprobe_process_filter+0x21b0>
    673a:      	cmpl	0x20(%rsi), %edx
    673d:      	je	0x69d7 <generic_kprobe_process_filter+0x21b7>
    6743:      	jmp	0x6ce7 <generic_kprobe_process_filter+0x24c7>
    6748:      	movq	%r12, %rsi
    674b:      	addq	$0x4, %rsi
    674f:      	movq	(%rip), %rdi            # 0x6756 <generic_kprobe_process_filter+0x1f36>
    6756:      	movl	$0x1, %eax
    675b:      	callq	*%rax
    675d:      	testq	%rax, %rax
    6760:      	je	0x6deb <generic_kprobe_process_filter+0x25cb>
    6766:      	movq	%rax, %r14
    6769:      	movq	(%rip), %rdi            # 0x6770 <generic_kprobe_process_filter+0x1f50>
    6770:      	leaq	0x58(%rsp), %rsi
    6775:      	movl	$0x1, %eax
    677a:      	callq	*%rax
    677c:      	testq	%rax, %rax
    677f:      	je	0x6deb <generic_kprobe_process_filter+0x25cb>
    6785:      	movq	%rax, %rbx
    6788:      	movl	$0x104, %edx            # imm = 0x104
    678d:      	movq	%rax, %rdi
    6790:      	xorl	%esi, %esi
    6792:      	callq	0x6797 <generic_kprobe_process_filter+0x1f77>
    6797:      	movl	(%rbp), %eax
    679a:      	leal	(,%rax,8), %ecx
    67a1:      	movl	%ecx, (%rbx)
    67a3:      	movq	%rbx, %rdi
    67a6:      	addq	$0x4, %rdi
    67aa:      	movzbl	%al, %ecx
    67ad:      	movq	%rbp, %rdx
    67b0:      	addq	$0x8, %rdx
    67b4:      	movl	$0x4, %eax
    67b9:      	movzbl	(%rbp), %esi
    67bd:      	callq	*%rax
    67bf:      	testq	%rax, %rax
    67c2:      	js	0x6deb <generic_kprobe_process_filter+0x25cb>
    67c8:      	movl	$0x1, %eax
    67cd:      	movq	%r14, %rdi
    67d0:      	movq	%rbx, %rsi
    67d3:      	jmp	0x6b4d <generic_kprobe_process_filter+0x232d>
    67d8:      	movl	$0x0, 0x40(%rsp)
    67e0:      	movq	(%rip), %rdi            # 0x67e7 <generic_kprobe_process_filter+0x1fc7>
    67e7:      	leaq	0x40(%rsp), %rsi
    67ec:      	movl	$0x1, %eax
    67f1:      	callq	*%rax
    67f3:      	testq	%rax, %rax
    67f6:      	je	0x6afa <generic_kprobe_process_filter+0x22da>
    67fc:      	movq	(%rax), %rcx
    67ff:      	cmpq	0x310(%rbp), %rcx
    6806:      	je	0x6afa <generic_kprobe_process_filter+0x22da>
    680c:      	movq	%rax, 0xb0(%rsp)
    6814:      	movq	(%rip), %rax            # 0x681b <generic_kprobe_process_filter+0x1ffb>
    681b:      	cmpb	$0x0, (%rax)
    681e:      	je	0x6a7e <generic_kprobe_process_filter+0x225e>
    6824:      	movl	$0x1869f, %r15d         # imm = 0x1869F
    682a:      	xorl	%r14d, %r14d
    682d:      	movq	0x38(%rsp), %rax
    6832:      	movl	0x10(%rax), %eax
    6835:      	movl	%eax, 0x60(%rsp)
    6839:      	movl	$0x1, %eax
    683e:      	movq	(%rip), %rdi            # 0x6845 <generic_kprobe_process_filter+0x2025>
    6845:      	leaq	0x60(%rsp), %rsi
    684a:      	callq	*%rax
    684c:      	testq	%rax, %rax
    684f:      	je	0x6ae8 <generic_kprobe_process_filter+0x22c8>
    6855:      	movq	%rax, %rbx
    6858:      	leaq	0x70(%rax), %rsi
    685c:      	movl	$0x1, %eax
    6861:      	movq	(%rip), %rdi            # 0x6868 <generic_kprobe_process_filter+0x2048>
    6868:      	callq	*%rax
    686a:      	testq	%rax, %rax
    686d:      	je	0x687f <generic_kprobe_process_filter+0x205f>
    686f:      	movq	(%rax), %rax
    6872:      	testq	%rax, %rax
    6875:      	je	0x687f <generic_kprobe_process_filter+0x205f>
    6877:      	lock
    6878:      	orq	%rax, 0x308(%rbp)
    687f:      	subl	$0x1, %r15d
    6883:      	setb	%al
    6886:      	cmpq	%r14, %rbx
    6889:      	je	0x6ae8 <generic_kprobe_process_filter+0x22c8>
    688f:      	movq	%rbx, %r14
    6892:      	testb	%al, %al
    6894:      	je	0x682d <generic_kprobe_process_filter+0x200d>
    6896:      	jmp	0x6ae8 <generic_kprobe_process_filter+0x22c8>
    689b:      	movl	$0x3ff, %r15d           # imm = 0x3FF
    68a1:      	xorl	%r14d, %r14d
    68a4:      	movq	(%rip), %r12            # 0x68ab <generic_kprobe_process_filter+0x208b>
    68ab:      	movq	0x38(%rsp), %rax
    68b0:      	movl	0x10(%rax), %eax
    68b3:      	movl	%eax, 0x60(%rsp)
    68b7:      	movl	$0x1, %eax
    68bc:      	leaq	0x60(%rsp), %rsi
    68c1:      	movq	%r12, %rdi
    68c4:      	callq	*%rax
    68c6:      	testq	%rax, %rax
    68c9:      	je	0x690d <generic_kprobe_process_filter+0x20ed>
    68cb:      	movq	%rax, %rbp
    68ce:      	leaq	0x70(%rax), %rsi
    68d2:      	movl	$0x1, %eax
    68d7:      	movq	(%rip), %rdi            # 0x68de <generic_kprobe_process_filter+0x20be>
    68de:      	callq	*%rax
    68e0:      	testq	%rax, %rax
    68e3:      	je	0x68fa <generic_kprobe_process_filter+0x20da>
    68e5:      	movq	(%rax), %rax
    68e8:      	testq	%rax, %rax
    68eb:      	je	0x68fa <generic_kprobe_process_filter+0x20da>
    68ed:      	movq	0x38(%rsp), %rcx
    68f2:      	lock
    68f3:      	orq	%rax, 0x370(%rcx)
    68fa:      	subl	$0x1, %r15d
    68fe:      	setb	%al
    6901:      	cmpq	%r14, %rbp
    6904:      	je	0x690d <generic_kprobe_process_filter+0x20ed>
    6906:      	movq	%rbp, %r14
    6909:      	testb	%al, %al
    690b:      	je	0x68ab <generic_kprobe_process_filter+0x208b>
    690d:      	movq	0xb0(%rsp), %rax
    6915:      	movq	(%rax), %rax
    6918:      	movq	0x38(%rsp), %rdx
    691d:      	movq	%rax, 0x378(%rdx)
    6924:      	movl	0x8(%rbx), %eax
    6927:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    692c:      	cmpq	%rcx, %rax
    692f:      	je	0x694a <generic_kprobe_process_filter+0x212a>
    6931:      	movq	0x370(%rdx), %rcx
    6938:      	btq	%rax, %rcx
    693c:      	jae	0x694a <generic_kprobe_process_filter+0x212a>
    693e:      	movabsq	$0xbadc0ffee, %rax      # imm = 0xBADC0FFEE
    6948:      	jmp	0x6979 <generic_kprobe_process_filter+0x2159>
    694a:      	movq	(%rip), %rdi            # 0x6951 <generic_kprobe_process_filter+0x2131>
    6951:      	leaq	0x10(%rsp), %rsi
    6956:      	movl	$0x1, %eax
    695b:      	callq	*%rax
    695d:      	testq	%rax, %rax
    6960:      	je	0x6deb <generic_kprobe_process_filter+0x25cb>
    6966:      	movq	%rax, %rdi
    6969:      	movq	0x38(%rsp), %rax
    696e:      	leaq	0x70(%rax), %rsi
    6972:      	movl	$0x1, %eax
    6977:      	callq	*%rax
    6979:      	movl	(%rbx), %ecx
    697b:      	cmpq	$0x25, %rcx
    697f:      	movq	0x8(%rsp), %r10
    6984:      	ja	0x69a4 <generic_kprobe_process_filter+0x2184>
    6986:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    6990:      	btq	%rcx, %rdx
    6994:      	jae	0x69a4 <generic_kprobe_process_filter+0x2184>
    6996:      	testq	%rax, %rax
    6999:      	jne	0x6deb <generic_kprobe_process_filter+0x25cb>
    699f:      	jmp	0x5ae9 <generic_kprobe_process_filter+0x12c9>
    69a4:      	testq	%rax, %rax
    69a7:      	jne	0x5ae9 <generic_kprobe_process_filter+0x12c9>
    69ad:      	jmp	0x6deb <generic_kprobe_process_filter+0x25cb>
    69b2:      	movq	$0x1, (%rcx)
    69b9:      	testb	$0x2, %bpl
    69bd:      	jne	0x69f5 <generic_kprobe_process_filter+0x21d5>
    69bf:      	movl	0x2c(%rax), %edx
    69c2:      	testl	%edx, %edx
    69c4:      	je	0x69ee <generic_kprobe_process_filter+0x21ce>
    69c6:      	cmpl	0x24(%rsi), %edx
    69c9:      	je	0x69f5 <generic_kprobe_process_filter+0x21d5>
    69cb:      	jmp	0x6ce7 <generic_kprobe_process_filter+0x24c7>
    69d0:      	movq	$0x1, (%rcx)
    69d7:      	testb	$0x2, %bpl
    69db:      	je	0x6a13 <generic_kprobe_process_filter+0x21f3>
    69dd:      	movl	0x2c(%rax), %edx
    69e0:      	testl	%edx, %edx
    69e2:      	je	0x6a0c <generic_kprobe_process_filter+0x21ec>
    69e4:      	cmpl	0x24(%rsi), %edx
    69e7:      	je	0x6a13 <generic_kprobe_process_filter+0x21f3>
    69e9:      	jmp	0x6ce7 <generic_kprobe_process_filter+0x24c7>
    69ee:      	movq	$0x1, (%rcx)
    69f5:      	testb	$0x4, %bpl
    69f9:      	jne	0x6a31 <generic_kprobe_process_filter+0x2211>
    69fb:      	movl	0x30(%rax), %edx
    69fe:      	testl	%edx, %edx
    6a00:      	je	0x6a2a <generic_kprobe_process_filter+0x220a>
    6a02:      	cmpl	0x28(%rsi), %edx
    6a05:      	je	0x6a31 <generic_kprobe_process_filter+0x2211>
    6a07:      	jmp	0x6ce7 <generic_kprobe_process_filter+0x24c7>
    6a0c:      	movq	$0x1, (%rcx)
    6a13:      	testb	$0x4, %bpl
    6a17:      	je	0x6a5b <generic_kprobe_process_filter+0x223b>
    6a19:      	movl	0x30(%rax), %edx
    6a1c:      	testl	%edx, %edx
    6a1e:      	je	0x6a54 <generic_kprobe_process_filter+0x2234>
    6a20:      	cmpl	0x28(%rsi), %edx
    6a23:      	je	0x6a5b <generic_kprobe_process_filter+0x223b>
    6a25:      	jmp	0x6ce7 <generic_kprobe_process_filter+0x24c7>
    6a2a:      	movq	$0x1, (%rcx)
    6a31:      	testb	$0x8, %bpl
    6a35:      	jne	0x6b91 <generic_kprobe_process_filter+0x2371>
    6a3b:      	movl	0x34(%rax), %edx
    6a3e:      	testl	%edx, %edx
    6a40:      	je	0x6b8a <generic_kprobe_process_filter+0x236a>
    6a46:      	cmpl	0x2c(%rsi), %edx
    6a49:      	je	0x6b91 <generic_kprobe_process_filter+0x2371>
    6a4f:      	jmp	0x6ce7 <generic_kprobe_process_filter+0x24c7>
    6a54:      	movq	$0x1, (%rcx)
    6a5b:      	testb	$0x8, %bpl
    6a5f:      	je	0x6baf <generic_kprobe_process_filter+0x238f>
    6a65:      	movl	0x34(%rax), %edx
    6a68:      	testl	%edx, %edx
    6a6a:      	je	0x6ba8 <generic_kprobe_process_filter+0x2388>
    6a70:      	cmpl	0x2c(%rsi), %edx
    6a73:      	je	0x6baf <generic_kprobe_process_filter+0x238f>
    6a79:      	jmp	0x6ce7 <generic_kprobe_process_filter+0x24c7>
    6a7e:      	movl	$0x3ff, %r15d           # imm = 0x3FF
    6a84:      	xorl	%r14d, %r14d
    6a87:      	movq	0x38(%rsp), %rax
    6a8c:      	movl	0x10(%rax), %eax
    6a8f:      	movl	%eax, 0x60(%rsp)
    6a93:      	movl	$0x1, %eax
    6a98:      	movq	(%rip), %rdi            # 0x6a9f <generic_kprobe_process_filter+0x227f>
    6a9f:      	leaq	0x60(%rsp), %rsi
    6aa4:      	callq	*%rax
    6aa6:      	testq	%rax, %rax
    6aa9:      	je	0x6ae8 <generic_kprobe_process_filter+0x22c8>
    6aab:      	movq	%rax, %rbx
    6aae:      	leaq	0x70(%rax), %rsi
    6ab2:      	movl	$0x1, %eax
    6ab7:      	movq	(%rip), %rdi            # 0x6abe <generic_kprobe_process_filter+0x229e>
    6abe:      	callq	*%rax
    6ac0:      	testq	%rax, %rax
    6ac3:      	je	0x6ad5 <generic_kprobe_process_filter+0x22b5>
    6ac5:      	movq	(%rax), %rax
    6ac8:      	testq	%rax, %rax
    6acb:      	je	0x6ad5 <generic_kprobe_process_filter+0x22b5>
    6acd:      	lock
    6ace:      	orq	%rax, 0x308(%rbp)
    6ad5:      	subl	$0x1, %r15d
    6ad9:      	setb	%al
    6adc:      	cmpq	%r14, %rbx
    6adf:      	je	0x6ae8 <generic_kprobe_process_filter+0x22c8>
    6ae1:      	movq	%rbx, %r14
    6ae4:      	testb	%al, %al
    6ae6:      	je	0x6a87 <generic_kprobe_process_filter+0x2267>
    6ae8:      	movq	0xb0(%rsp), %rax
    6af0:      	movq	(%rax), %rax
    6af3:      	movq	%rax, 0x310(%rbp)
    6afa:      	movl	0x8(%r12), %eax
    6aff:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    6b04:      	cmpq	%rcx, %rax
    6b07:      	je	0x6b22 <generic_kprobe_process_filter+0x2302>
    6b09:      	movq	0x308(%rbp), %rcx
    6b10:      	btq	%rax, %rcx
    6b14:      	jae	0x6b22 <generic_kprobe_process_filter+0x2302>
    6b16:      	movabsq	$0xbadc0ffee, %rax      # imm = 0xBADC0FFEE
    6b20:      	jmp	0x6b4f <generic_kprobe_process_filter+0x232f>
    6b22:      	movq	(%rip), %rdi            # 0x6b29 <generic_kprobe_process_filter+0x2309>
    6b29:      	leaq	0x10(%rsp), %rsi
    6b2e:      	movl	$0x1, %eax
    6b33:      	callq	*%rax
    6b35:      	testq	%rax, %rax
    6b38:      	je	0x6deb <generic_kprobe_process_filter+0x25cb>
    6b3e:      	movq	%rax, %rdi
    6b41:      	addq	$0x8, %rbp
    6b45:      	movl	$0x1, %eax
    6b4a:      	movq	%rbp, %rsi
    6b4d:      	callq	*%rax
    6b4f:      	movl	(%r12), %ecx
    6b53:      	cmpq	$0x25, %rcx
    6b57:      	movq	0x8(%rsp), %r10
    6b5c:      	ja	0x6b7c <generic_kprobe_process_filter+0x235c>
    6b5e:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    6b68:      	btq	%rcx, %rdx
    6b6c:      	jae	0x6b7c <generic_kprobe_process_filter+0x235c>
    6b6e:      	testq	%rax, %rax
    6b71:      	jne	0x6deb <generic_kprobe_process_filter+0x25cb>
    6b77:      	jmp	0x5d35 <generic_kprobe_process_filter+0x1515>
    6b7c:      	testq	%rax, %rax
    6b7f:      	jne	0x5d35 <generic_kprobe_process_filter+0x1515>
    6b85:      	jmp	0x6deb <generic_kprobe_process_filter+0x25cb>
    6b8a:      	movq	$0x1, (%rcx)
    6b91:      	testb	$0x10, %bpl
    6b95:      	jne	0x6bcd <generic_kprobe_process_filter+0x23ad>
    6b97:      	movl	0x38(%rax), %edx
    6b9a:      	testl	%edx, %edx
    6b9c:      	je	0x6bc6 <generic_kprobe_process_filter+0x23a6>
    6b9e:      	cmpl	0x30(%rsi), %edx
    6ba1:      	je	0x6bcd <generic_kprobe_process_filter+0x23ad>
    6ba3:      	jmp	0x6ce7 <generic_kprobe_process_filter+0x24c7>
    6ba8:      	movq	$0x1, (%rcx)
    6baf:      	testb	$0x10, %bpl
    6bb3:      	je	0x6beb <generic_kprobe_process_filter+0x23cb>
    6bb5:      	movl	0x38(%rax), %edx
    6bb8:      	testl	%edx, %edx
    6bba:      	je	0x6be4 <generic_kprobe_process_filter+0x23c4>
    6bbc:      	cmpl	0x30(%rsi), %edx
    6bbf:      	je	0x6beb <generic_kprobe_process_filter+0x23cb>
    6bc1:      	jmp	0x6ce7 <generic_kprobe_process_filter+0x24c7>
    6bc6:      	movq	$0x1, (%rcx)
    6bcd:      	testb	$0x20, %bpl
    6bd1:      	jne	0x6c09 <generic_kprobe_process_filter+0x23e9>
    6bd3:      	movl	0x3c(%rax), %edx
    6bd6:      	testl	%edx, %edx
    6bd8:      	je	0x6c02 <generic_kprobe_process_filter+0x23e2>
    6bda:      	cmpl	0x34(%rsi), %edx
    6bdd:      	je	0x6c09 <generic_kprobe_process_filter+0x23e9>
    6bdf:      	jmp	0x6ce7 <generic_kprobe_process_filter+0x24c7>
    6be4:      	movq	$0x1, (%rcx)
    6beb:      	testb	$0x20, %bpl
    6bef:      	je	0x6c27 <generic_kprobe_process_filter+0x2407>
    6bf1:      	movl	0x3c(%rax), %edx
    6bf4:      	testl	%edx, %edx
    6bf6:      	je	0x6c20 <generic_kprobe_process_filter+0x2400>
    6bf8:      	cmpl	0x34(%rsi), %edx
    6bfb:      	je	0x6c27 <generic_kprobe_process_filter+0x2407>
    6bfd:      	jmp	0x6ce7 <generic_kprobe_process_filter+0x24c7>
    6c02:      	movq	$0x1, (%rcx)
    6c09:      	testb	$0x40, %bpl
    6c0d:      	jne	0x6c45 <generic_kprobe_process_filter+0x2425>
    6c0f:      	movl	0x40(%rax), %edx
    6c12:      	testl	%edx, %edx
    6c14:      	je	0x6c3e <generic_kprobe_process_filter+0x241e>
    6c16:      	cmpl	0x38(%rsi), %edx
    6c19:      	je	0x6c45 <generic_kprobe_process_filter+0x2425>
    6c1b:      	jmp	0x6ce7 <generic_kprobe_process_filter+0x24c7>
    6c20:      	movq	$0x1, (%rcx)
    6c27:      	testb	$0x40, %bpl
    6c2b:      	je	0x6c62 <generic_kprobe_process_filter+0x2442>
    6c2d:      	movl	0x40(%rax), %edx
    6c30:      	testl	%edx, %edx
    6c32:      	je	0x6c5b <generic_kprobe_process_filter+0x243b>
    6c34:      	cmpl	0x38(%rsi), %edx
    6c37:      	je	0x6c62 <generic_kprobe_process_filter+0x2442>
    6c39:      	jmp	0x6ce7 <generic_kprobe_process_filter+0x24c7>
    6c3e:      	movq	$0x1, (%rcx)
    6c45:      	testb	%bpl, %bpl
    6c48:      	js	0x6c7c <generic_kprobe_process_filter+0x245c>
    6c4a:      	movl	0x44(%rax), %edx
    6c4d:      	testl	%edx, %edx
    6c4f:      	je	0x6c75 <generic_kprobe_process_filter+0x2455>
    6c51:      	cmpl	0x3c(%rsi), %edx
    6c54:      	je	0x6c7c <generic_kprobe_process_filter+0x245c>
    6c56:      	jmp	0x6ce7 <generic_kprobe_process_filter+0x24c7>
    6c5b:      	movq	$0x1, (%rcx)
    6c62:      	testb	%bpl, %bpl
    6c65:      	jns	0x6c99 <generic_kprobe_process_filter+0x2479>
    6c67:      	movl	0x44(%rax), %edx
    6c6a:      	testl	%edx, %edx
    6c6c:      	je	0x6c92 <generic_kprobe_process_filter+0x2472>
    6c6e:      	cmpl	0x3c(%rsi), %edx
    6c71:      	je	0x6c99 <generic_kprobe_process_filter+0x2479>
    6c73:      	jmp	0x6ce7 <generic_kprobe_process_filter+0x24c7>
    6c75:      	movq	$0x1, (%rcx)
    6c7c:      	testl	$0x100, %ebp            # imm = 0x100
    6c82:      	jne	0x6cc2 <generic_kprobe_process_filter+0x24a2>
    6c84:      	movl	0x48(%rax), %edx
    6c87:      	testl	%edx, %edx
    6c89:      	je	0x6cbb <generic_kprobe_process_filter+0x249b>
    6c8b:      	cmpl	0x40(%rsi), %edx
    6c8e:      	je	0x6cc2 <generic_kprobe_process_filter+0x24a2>
    6c90:      	jmp	0x6ce7 <generic_kprobe_process_filter+0x24c7>
    6c92:      	movq	$0x1, (%rcx)
    6c99:      	testl	$0x100, %ebp            # imm = 0x100
    6c9f:      	je	0x6dd1 <generic_kprobe_process_filter+0x25b1>
    6ca5:      	movl	0x48(%rax), %edx
    6ca8:      	testl	%edx, %edx
    6caa:      	je	0x6dca <generic_kprobe_process_filter+0x25aa>
    6cb0:      	cmpl	0x40(%rsi), %edx
    6cb3:      	je	0x6dd1 <generic_kprobe_process_filter+0x25b1>
    6cb9:      	jmp	0x6ce7 <generic_kprobe_process_filter+0x24c7>
    6cbb:      	movq	$0x1, (%rcx)
    6cc2:      	testl	$0x200, %ebp            # imm = 0x200
    6cc8:      	jne	0x6deb <generic_kprobe_process_filter+0x25cb>
    6cce:      	movl	0x4c(%rax), %eax
    6cd1:      	testl	%eax, %eax
    6cd3:      	je	0x6de4 <generic_kprobe_process_filter+0x25c4>
    6cd9:      	movq	0x50(%rsp), %rdx
    6cde:      	cmpl	0x44(%rdx), %eax
    6ce1:      	je	0x6deb <generic_kprobe_process_filter+0x25cb>
    6ce7:      	addl	$0xc, %ebx
    6cea:      	movq	$0x1, (%rcx)
    6cf1:      	movl	%ebx, %eax
    6cf3:      	movl	%eax, %ecx
    6cf5:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    6cfb:      	cmpl	$0x4, (%rcx,%r10)
    6d00:      	movq	0x50(%rsp), %rcx
    6d05:      	jne	0x6d2c <generic_kprobe_process_filter+0x250c>
    6d07:      	movq	0x5eb8(%rcx), %rax
    6d0e:      	andl	$0x1f, %eax
    6d11:      	movb	$0x1, 0x5ec1(%rcx,%rax)
    6d19:      	movb	$0x1, 0x5ee0(%rcx)
    6d20:      	movb	$0x1, 0x5ec0(%rcx)
    6d27:      	jmp	0x6deb <generic_kprobe_process_filter+0x25cb>
    6d2c:      	addl	$0x4, %eax
    6d2f:      	andl	$0x3ff, %eax            # imm = 0x3FF
    6d34:      	movl	(%rax,%r10), %r14d
    6d38:      	movl	0x4(%rax,%r10), %ebx
    6d3d:      	movl	0x8(%rax,%r10), %ebp
    6d42:      	movq	0xc(%rax,%r10), %r15
    6d47:      	movl	$0xe, %eax
    6d4c:      	callq	*%rax
    6d4e:      	shrq	$0x20, %rax
    6d52:      	movl	%eax, 0x60(%rsp)
    6d56:      	movq	(%rip), %rdi            # 0x6d5d <generic_kprobe_process_filter+0x253d>
    6d5d:      	leaq	0x60(%rsp), %rsi
    6d62:      	movl	$0x1, %eax
    6d67:      	callq	*%rax
    6d69:      	testq	%rax, %rax
    6d6c:      	je	0x6deb <generic_kprobe_process_filter+0x25cb>
    6d6e:      	testl	%ebp, %ebp
    6d70:      	je	0x6d84 <generic_kprobe_process_filter+0x2564>
    6d72:      	cmpl	$0x2, %r14d
    6d76:      	ja	0x6deb <generic_kprobe_process_filter+0x25cb>
    6d78:      	movq	0x50(%rsp), %rcx
    6d7d:      	cmpl	%ebp, 0x44(%rcx)
    6d80:      	jne	0x6d8a <generic_kprobe_process_filter+0x256a>
    6d82:      	jmp	0x6deb <generic_kprobe_process_filter+0x25cb>
    6d84:      	cmpl	$0x2, %r14d
    6d88:      	ja	0x6deb <generic_kprobe_process_filter+0x25cb>
    6d8a:      	movq	0x50(%rax,%r14,8), %rax
    6d8f:      	movq	0x50(%rsp), %rcx
    6d94:      	movq	0x48(%rcx,%r14,8), %rcx
    6d99:      	movq	%rcx, %rdx
    6d9c:      	xorq	%rax, %rdx
    6d9f:      	testq	%r15, %rdx
    6da2:      	je	0x6dab <generic_kprobe_process_filter+0x258b>
    6da4:      	cmpl	$0x5, %ebx
    6da7:      	jne	0x6deb <generic_kprobe_process_filter+0x25cb>
    6da9:      	jmp	0x6db5 <generic_kprobe_process_filter+0x2595>
    6dab:      	cmpq	%rcx, %rax
    6dae:      	je	0x6deb <generic_kprobe_process_filter+0x25cb>
    6db0:      	cmpl	$0x6, %ebx
    6db3:      	jne	0x6deb <generic_kprobe_process_filter+0x25cb>
    6db5:      	movq	0x50(%rsp), %rcx
    6dba:      	movq	$0x1, 0x5ef0(%rcx)
    6dc5:      	jmp	0x6d07 <generic_kprobe_process_filter+0x24e7>
    6dca:      	movq	$0x1, (%rcx)
    6dd1:      	testl	$0x200, %ebp            # imm = 0x200
    6dd7:      	je	0x6deb <generic_kprobe_process_filter+0x25cb>
    6dd9:      	movl	0x4c(%rax), %eax
    6ddc:      	testl	%eax, %eax
    6dde:      	jne	0x6cd9 <generic_kprobe_process_filter+0x24b9>
    6de4:      	movq	$0x1, (%rcx)
    6deb:      	movq	0x50(%rsp), %rcx
    6df0:      	movq	0x5eb8(%rcx), %rax
    6df7:      	incq	%rax
    6dfa:      	movq	%rax, 0x5eb8(%rcx)
    6e01:      	cmpq	0xc0(%rsp), %rax
    6e09:      	jbe	0x6e57 <generic_kprobe_process_filter+0x2637>
    6e0b:      	movq	0x38(%rsp), %rdx
    6e10:      	movl	(%rdx), %eax
    6e12:      	movl	%eax, 0x10(%rcx)
    6e15:      	movq	0x8(%rdx), %rax
    6e19:      	movq	%rax, 0x18(%rcx)
    6e1d:      	cmpb	$0x0, 0x5ec0(%rcx)
    6e24:      	movq	0xb8(%rsp), %rbx
    6e2c:      	je	0x6e43 <generic_kprobe_process_filter+0x2623>
    6e2e:      	movq	(%rip), %rsi            # 0x6e35 <generic_kprobe_process_filter+0x2615>
    6e35:      	xorl	%ecx, %ecx
    6e37:      	movl	$0xc, %eax
    6e3c:      	movq	%rbx, %rdi
    6e3f:      	xorl	%edx, %edx
    6e41:      	callq	*%rax
    6e43:      	xorl	%eax, %eax
    6e45:      	addq	$0xe8, %rsp
    6e4c:      	popq	%rbx
    6e4d:      	popq	%r12
    6e4f:      	popq	%r13
    6e51:      	popq	%r14
    6e53:      	popq	%r15
    6e55:      	popq	%rbp
    6e56:      	retq
    6e57:      	movq	(%rip), %rsi            # 0x6e5e <generic_kprobe_process_filter+0x263e>
    6e5e:      	movl	$0x2, %ecx
    6e63:      	movl	$0xc, %eax
    6e68:      	movq	0xb8(%rsp), %rdi
    6e70:      	movl	$0x2, %edx
    6e75:      	jmp	0x6e41 <generic_kprobe_process_filter+0x2621>
    6e77:      	nopw	(%rax,%rax)

0000000000006e80 <generic_kprobe_filter_arg>:
    6e80:      	pushq	%rbp
    6e81:      	pushq	%r15
    6e83:      	pushq	%r14
    6e85:      	pushq	%r13
    6e87:      	pushq	%r12
    6e89:      	pushq	%rbx
    6e8a:      	subq	$0xb8, %rsp
    6e91:      	movq	%rdi, %r12
    6e94:      	movl	$0x0, 0xa4(%rsp)
    6e9f:      	movq	(%rip), %rdi            # 0x6ea6 <generic_kprobe_filter_arg+0x26>
    6ea6:      	leaq	0xa4(%rsp), %rsi
    6eae:      	movl	$0x1, %eax
    6eb3:      	callq	*%rax
    6eb5:      	testq	%rax, %rax
    6eb8:      	je	0x7072 <generic_kprobe_filter_arg+0x1f2>
    6ebe:      	movq	%rax, %r14
    6ec1:      	movl	0x5f00(%rax), %ebx
    6ec7:      	leaq	0x5ef8(%rax), %rsi
    6ece:      	movq	(%rip), %rdi            # 0x6ed5 <generic_kprobe_filter_arg+0x55>
    6ed5:      	movl	$0x1, %eax
    6eda:      	callq	*%rax
    6edc:      	testq	%rax, %rax
    6edf:      	je	0x7057 <generic_kprobe_filter_arg+0x1d7>
    6ee5:      	cmpb	$0x0, 0x5ee0(%r14)
    6eed:      	je	0x7057 <generic_kprobe_filter_arg+0x1d7>
    6ef3:      	movq	%rax, %r15
    6ef6:      	movq	%r12, 0x98(%rsp)
    6efe:      	movl	%ebx, %eax
    6f00:      	andl	$0x7, %eax
    6f03:      	cmpb	$0x0, 0x5ec1(%r14,%rax)
    6f0c:      	je	0x6f9d <generic_kprobe_filter_arg+0x11d>
    6f12:      	movl	%eax, %eax
    6f14:      	movl	0x4(%r15,%rax,4), %ecx
    6f19:      	leaq	(%rcx,%rax,4), %rdx
    6f1d:      	addq	$0x4, %rdx
    6f21:      	leaq	(%rcx,%rax,4), %rax
    6f25:      	addq	$0x8, %rax
    6f29:      	andl	$0x3ff, %eax            # imm = 0x3FF
    6f2e:      	movl	(%rax,%r15), %eax
    6f32:      	addq	%rdx, %rax
    6f35:      	addq	$0x4, %rax
    6f39:      	movl	%eax, %ecx
    6f3b:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    6f41:      	movl	(%rcx,%r15), %ecx
    6f45:      	addq	%rax, %rcx
    6f48:      	movl	%ecx, %eax
    6f4a:      	andl	$0x3ff, %eax            # imm = 0x3FF
    6f4f:      	movl	(%rax,%r15), %eax
    6f53:      	addq	%rcx, %rax
    6f56:      	movl	%eax, %ecx
    6f58:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    6f5e:      	movl	(%rcx,%r15), %ecx
    6f62:      	addq	%rax, %rcx
    6f65:      	movl	%ecx, %eax
    6f67:      	andl	$0x3ff, %eax            # imm = 0x3FF
    6f6c:      	movl	(%rax,%r15), %r9d
    6f70:      	addq	%rcx, %r9
    6f73:      	movl	%r9d, %edi
    6f76:      	andl	$0x3ff, %edi            # imm = 0x3FF
    6f7c:      	cmpl	$0x19, (%r15,%rdi)
    6f81:      	jae	0x6ff9 <generic_kprobe_filter_arg+0x179>
    6f83:      	cmpq	$0x1, %rdi
    6f87:      	movq	0x98(%rsp), %r12
    6f8f:      	je	0x7057 <generic_kprobe_filter_arg+0x1d7>
    6f95:      	testl	%edi, %edi
    6f97:      	jne	0x702d <generic_kprobe_filter_arg+0x1ad>
    6f9d:      	cmpl	$0x1, %ebx
    6fa0:      	jg	0x6fc6 <generic_kprobe_filter_arg+0x146>
    6fa2:      	cmpl	$-0x1, %ebx
    6fa5:      	movq	0x98(%rsp), %rdi
    6fad:      	je	0x7086 <generic_kprobe_filter_arg+0x206>
    6fb3:      	testl	%ebx, %ebx
    6fb5:      	je	0x7092 <generic_kprobe_filter_arg+0x212>
    6fbb:      	cmpl	$0x1, %ebx
    6fbe:      	je	0x70a1 <generic_kprobe_filter_arg+0x221>
    6fc4:      	jmp	0x6fe9 <generic_kprobe_filter_arg+0x169>
    6fc6:      	cmpl	$0x2, %ebx
    6fc9:      	movq	0x98(%rsp), %rdi
    6fd1:      	je	0x70b0 <generic_kprobe_filter_arg+0x230>
    6fd7:      	cmpl	$0x3, %ebx
    6fda:      	je	0x70bf <generic_kprobe_filter_arg+0x23f>
    6fe0:      	cmpl	$0x4, %ebx
    6fe3:      	je	0x70ce <generic_kprobe_filter_arg+0x24e>
    6fe9:      	cmpl	$0x4, %ebx
    6fec:      	jg	0x70fc <generic_kprobe_filter_arg+0x27c>
    6ff2:      	incl	%ebx
    6ff4:      	jmp	0x70dd <generic_kprobe_filter_arg+0x25d>
    6ff9:      	leaq	(%r15,%rdi), %rax
    6ffd:      	movq	%rax, 0xb0(%rsp)
    7005:      	xorl	%r11d, %r11d
    7008:      	leaq	0x70(%rsp), %rax
    700d:      	movq	%rax, 0x28(%rsp)
    7012:      	movq	%rbx, 0xa8(%rsp)
    701a:      	movq	%rdi, (%rsp)
    701e:      	movq	%r9, 0x8(%rsp)
    7023:      	movq	%r15, 0x68(%rsp)
    7028:      	jmp	0x716e <generic_kprobe_filter_arg+0x2ee>
    702d:      	movl	%edi, 0x5f04(%r14)
    7034:      	movq	(%rip), %rsi            # 0x703b <generic_kprobe_filter_arg+0x1bb>
    703b:      	movl	$0x4, %ecx
    7040:      	movl	$0xc, %eax
    7045:      	movq	0x98(%rsp), %r12
    704d:      	movq	%r12, %rdi
    7050:      	movl	$0x4, %edx
    7055:      	callq	*%rax
    7057:      	movq	(%rip), %rsi            # 0x705e <generic_kprobe_filter_arg+0x1de>
    705e:      	movl	$0x5, %ecx
    7063:      	movl	$0xc, %eax
    7068:      	movq	%r12, %rdi
    706b:      	movl	$0x5, %edx
    7070:      	callq	*%rax
    7072:      	xorl	%eax, %eax
    7074:      	addq	$0xb8, %rsp
    707b:      	popq	%rbx
    707c:      	popq	%r12
    707e:      	popq	%r13
    7080:      	popq	%r14
    7082:      	popq	%r15
    7084:      	popq	%rbp
    7085:      	retq
    7086:      	xorl	%ebx, %ebx
    7088:      	cmpb	$0x0, 0x5ec1(%r14)
    7090:      	jne	0x70dd <generic_kprobe_filter_arg+0x25d>
    7092:      	movl	$0x1, %ebx
    7097:      	cmpb	$0x0, 0x5ec2(%r14)
    709f:      	jne	0x70dd <generic_kprobe_filter_arg+0x25d>
    70a1:      	movl	$0x2, %ebx
    70a6:      	cmpb	$0x0, 0x5ec3(%r14)
    70ae:      	jne	0x70dd <generic_kprobe_filter_arg+0x25d>
    70b0:      	movl	$0x3, %ebx
    70b5:      	cmpb	$0x0, 0x5ec4(%r14)
    70bd:      	jne	0x70dd <generic_kprobe_filter_arg+0x25d>
    70bf:      	movl	$0x4, %ebx
    70c4:      	cmpb	$0x0, 0x5ec5(%r14)
    70cc:      	jne	0x70dd <generic_kprobe_filter_arg+0x25d>
    70ce:      	movl	$0x5, %ebx
    70d3:      	cmpb	$0x0, 0x5ec6(%r14)
    70db:      	je	0x70fc <generic_kprobe_filter_arg+0x27c>
    70dd:      	movl	%ebx, 0x5f00(%r14)
    70e4:      	movq	(%rip), %rsi            # 0x70eb <generic_kprobe_filter_arg+0x26b>
    70eb:      	movl	$0x3, %ecx
    70f0:      	movl	$0xc, %eax
    70f5:      	movl	$0x3, %edx
    70fa:      	callq	*%rax
    70fc:      	movq	0x60(%r14), %rbx
    7100:      	movl	$0xe, %eax
    7105:      	callq	*%rax
    7107:      	movq	%rbx, 0x38(%rsp)
    710c:      	movq	%rax, 0x40(%rsp)
    7111:      	movq	(%rip), %rdi            # 0x7118 <generic_kprobe_filter_arg+0x298>
    7118:      	leaq	0x38(%rsp), %rsi
    711d:      	movl	$0x1, %eax
    7122:      	callq	*%rax
    7124:      	testq	%rax, %rax
    7127:      	je	0x7072 <generic_kprobe_filter_arg+0x1f2>
    712d:      	movq	(%rip), %rdi            # 0x7134 <generic_kprobe_filter_arg+0x2b4>
    7134:      	leaq	0x38(%rsp), %rsi
    7139:      	movl	$0x3, %eax
    713e:      	callq	*%rax
    7140:      	jmp	0x7072 <generic_kprobe_filter_arg+0x1f2>
    7145:      	xorl	%ebx, %ebx
    7147:      	cmpl	$0x3, %eax
    714a:      	sete	%bl
    714d:      	nopl	(%rax)
    7150:      	testq	%rbx, %rbx
    7153:      	movq	0xa8(%rsp), %rbx
    715b:      	je	0x6f9d <generic_kprobe_filter_arg+0x11d>
    7161:      	incq	%r11
    7164:      	cmpq	$0x5, %r11
    7168:      	je	0x6f83 <generic_kprobe_filter_arg+0x103>
    716e:      	movq	0xb0(%rsp), %rax
    7176:      	movl	0x4(%rax,%r11,4), %r13d
    717b:      	testl	$0x3ff, %r13d           # imm = 0x3FF
    7182:      	je	0x6f83 <generic_kprobe_filter_arg+0x103>
    7188:      	addl	%r9d, %r13d
    718b:      	andl	$0x3ff, %r13d           # imm = 0x3FF
    7192:      	movl	0x4(%r15,%r13), %eax
    7197:      	cmpl	$0x23, %eax
    719a:      	je	0x6f9d <generic_kprobe_filter_arg+0x11d>
    71a0:      	addq	%r15, %r13
    71a3:      	movl	(%r13), %ecx
    71a7:      	cmpq	$0x4, %rcx
    71ab:      	ja	0x6f9d <generic_kprobe_filter_arg+0x11d>
    71b1:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
    71ba:      	jne	0x6f9d <generic_kprobe_filter_arg+0x11d>
    71c0:      	movq	0x5e78(%r14,%rcx,8), %rcx
    71c8:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    71ce:      	leaq	(%r14,%rcx), %r12
    71d2:      	addq	$0x90, %r12
    71d9:      	movl	0xc(%r13), %ecx
    71dd:      	cmpl	$0x1b, %ecx
    71e0:      	jle	0x71fd <generic_kprobe_filter_arg+0x37d>
    71e2:      	cmpl	$0x25, %ecx
    71e5:      	jg	0x7228 <generic_kprobe_filter_arg+0x3a8>
    71e7:      	leal	-0x1c(%rcx), %edx
    71ea:      	cmpl	$0x9, %edx
    71ed:      	jb	0x726e <generic_kprobe_filter_arg+0x3ee>
    71ef:      	cmpl	$0x25, %ecx
    71f2:      	je	0x7486 <generic_kprobe_filter_arg+0x606>
    71f8:      	jmp	0x7161 <generic_kprobe_filter_arg+0x2e1>
    71fd:      	cmpl	$0x9, %ecx
    7200:      	jle	0x724e <generic_kprobe_filter_arg+0x3ce>
    7202:      	leal	-0xa(%rcx), %edx
    7205:      	cmpl	$0x4, %edx
    7208:      	jb	0x726e <generic_kprobe_filter_arg+0x3ee>
    720a:      	leal	-0xf(%rcx), %edx
    720d:      	cmpl	$0x2, %edx
    7210:      	jb	0x7486 <generic_kprobe_filter_arg+0x606>
    7216:      	cmpl	$0x11, %ecx
    7219:      	jne	0x7161 <generic_kprobe_filter_arg+0x2e1>
    721f:      	addq	$0x4, %r12
    7223:      	jmp	0x7486 <generic_kprobe_filter_arg+0x606>
    7228:      	cmpl	$0x29, %ecx
    722b:      	jg	0x73f3 <generic_kprobe_filter_arg+0x573>
    7231:      	leal	-0x26(%rcx), %edx
    7234:      	cmpl	$0x2, %edx
    7237:      	jb	0x7389 <generic_kprobe_filter_arg+0x509>
    723d:      	leal	-0x28(%rcx), %edx
    7240:      	cmpl	$0x2, %edx
    7243:      	jb	0x7334 <generic_kprobe_filter_arg+0x4b4>
    7249:      	jmp	0x7161 <generic_kprobe_filter_arg+0x2e1>
    724e:      	cmpl	$0x4, %ecx
    7251:      	jg	0x7321 <generic_kprobe_filter_arg+0x4a1>
    7257:      	cmpl	$0x1, %ecx
    725a:      	je	0x726e <generic_kprobe_filter_arg+0x3ee>
    725c:      	cmpl	$0x2, %ecx
    725f:      	je	0x7a73 <generic_kprobe_filter_arg+0xbf3>
    7265:      	cmpl	$0x4, %ecx
    7268:      	jne	0x7161 <generic_kprobe_filter_arg+0x2e1>
    726e:      	cmpl	$0xb, %ecx
    7271:      	jle	0x72fe <generic_kprobe_filter_arg+0x47e>
    7277:      	cmpl	$0x24, %ecx
    727a:      	ja	0x75ab <generic_kprobe_filter_arg+0x72b>
    7280:      	movl	%ecx, %edx
    7282:      	movabsq	$0x1e00000000, %rsi     # imm = 0x1E00000000
    728c:      	btq	%rdx, %rsi
    7290:      	jb	0x73c7 <generic_kprobe_filter_arg+0x547>
    7296:      	movl	$0x60000000, %esi       # imm = 0x60000000
    729b:      	btq	%rdx, %rsi
    729f:      	jb	0x7845 <generic_kprobe_filter_arg+0x9c5>
    72a5:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
    72af:      	btq	%rdx, %rsi
    72b3:      	jae	0x75ab <generic_kprobe_filter_arg+0x72b>
    72b9:      	cmpl	$0x20, %eax
    72bc:      	ja	0x6f9d <generic_kprobe_filter_arg+0x11d>
    72c2:      	movl	%eax, %ecx
    72c4:      	movl	$0x101e, %edx           # imm = 0x101E
    72c9:      	btq	%rcx, %rdx
    72cd:      	jae	0x7f89 <generic_kprobe_filter_arg+0x1109>
    72d3:      	movl	0x10(%r13), %ecx
    72d7:      	cmpl	$0x2, %eax
    72da:      	jle	0x84b3 <generic_kprobe_filter_arg+0x1633>
    72e0:      	leal	-0x3(%rax), %edx
    72e3:      	cmpl	$0x2, %edx
    72e6:      	jae	0x8c0e <generic_kprobe_filter_arg+0x1d8e>
    72ec:      	movzbl	(%r12), %edx
    72f1:      	cmpl	%edx, %ecx
    72f3:      	je	0x7145 <generic_kprobe_filter_arg+0x2c5>
    72f9:      	jmp	0x8d46 <generic_kprobe_filter_arg+0x1ec6>
    72fe:      	leal	-0xa(%rcx), %edx
    7301:      	cmpl	$0x2, %edx
    7304:      	jb	0x7af3 <generic_kprobe_filter_arg+0xc73>
    730a:      	cmpl	$0x1, %ecx
    730d:      	je	0x75b7 <generic_kprobe_filter_arg+0x737>
    7313:      	cmpl	$0x4, %ecx
    7316:      	je	0x75b7 <generic_kprobe_filter_arg+0x737>
    731c:      	jmp	0x7161 <generic_kprobe_filter_arg+0x2e1>
    7321:      	cmpl	$0x5, %ecx
    7324:      	je	0x7334 <generic_kprobe_filter_arg+0x4b4>
    7326:      	cmpl	$0x6, %ecx
    7329:      	je	0x7389 <generic_kprobe_filter_arg+0x509>
    732b:      	cmpl	$0x7, %ecx
    732e:      	jne	0x7161 <generic_kprobe_filter_arg+0x2e1>
    7334:      	movq	$0x0, 0x58(%rsp)
    733d:      	movq	$0x0, 0x50(%rsp)
    7346:      	movq	$0x0, 0x48(%rsp)
    734f:      	movq	$0x0, 0x40(%rsp)
    7358:      	movq	$0x0, 0x38(%rsp)
    7361:      	cmpl	$0x27, %ecx
    7364:      	jg	0x75f5 <generic_kprobe_filter_arg+0x775>
    736a:      	cmpl	$0x5, %ecx
    736d:      	je	0x7c58 <generic_kprobe_filter_arg+0xdd8>
    7373:      	movq	%r12, %rdx
    7376:      	movl	$0x0, %ebx
    737b:      	cmpl	$0x7, %ecx
    737e:      	je	0x7c5a <generic_kprobe_filter_arg+0xdda>
    7384:      	jmp	0x7150 <generic_kprobe_filter_arg+0x2d0>
    7389:      	movl	(%r12), %ebp
    738d:      	addq	$0x4, %r12
    7391:      	movq	%r12, 0x18(%rsp)
    7396:      	cmpl	$0x19, %eax
    7399:      	jg	0x7678 <generic_kprobe_filter_arg+0x7f8>
    739f:      	leal	-0x3(%rax), %ecx
    73a2:      	cmpl	$0x2, %ecx
    73a5:      	jb	0x7ebb <generic_kprobe_filter_arg+0x103b>
    73ab:      	cmpl	$0x8, %eax
    73ae:      	je	0x7e25 <generic_kprobe_filter_arg+0xfa5>
    73b4:      	movl	$0x0, %ebx
    73b9:      	cmpl	$0x9, %eax
    73bc:      	je	0x7698 <generic_kprobe_filter_arg+0x818>
    73c2:      	jmp	0xa4bb <generic_kprobe_filter_arg+0x363b>
    73c7:      	cmpl	$0x9, %eax
    73ca:      	jle	0x7a62 <generic_kprobe_filter_arg+0xbe2>
    73d0:      	cmpl	$0x1d, %eax
    73d3:      	jg	0x7ddf <generic_kprobe_filter_arg+0xf5f>
    73d9:      	leal	-0xa(%rax), %edx
    73dc:      	cmpl	$0x2, %edx
    73df:      	jb	0x7b80 <generic_kprobe_filter_arg+0xd00>
    73e5:      	cmpl	$0xc, %eax
    73e8:      	je	0x7b09 <generic_kprobe_filter_arg+0xc89>
    73ee:      	jmp	0x6f9d <generic_kprobe_filter_arg+0x11d>
    73f3:      	cmpl	$0x2a, %ecx
    73f6:      	je	0x7486 <generic_kprobe_filter_arg+0x606>
    73fc:      	cmpl	$0x2c, %ecx
    73ff:      	jne	0x7161 <generic_kprobe_filter_arg+0x2e1>
    7405:      	movq	%r12, %rcx
    7408:      	leaq	0x4(%r12), %r8
    740d:      	movzbl	0x3(%r12), %ebp
    7413:      	movzbl	%bpl, %esi
    7417:      	cmpl	$0x19, %eax
    741a:      	jg	0x81fc <generic_kprobe_filter_arg+0x137c>
    7420:      	leal	-0x3(%rax), %ecx
    7423:      	cmpl	$0x2, %ecx
    7426:      	jae	0x87a1 <generic_kprobe_filter_arg+0x1921>
    742c:      	movl	$0x0, 0x70(%rsp)
    7434:      	movl	$0x100, %ebx            # imm = 0x100
    7439:      	cmpb	$-0x70, %bpl
    743d:      	ja	0x8483 <generic_kprobe_filter_arg+0x1603>
    7443:      	testb	%bpl, %bpl
    7446:      	je	0x7458 <generic_kprobe_filter_arg+0x5d8>
    7448:      	movl	%esi, %eax
    744a:      	movl	$0x18, %ecx
    744f:      	cltd
    7450:      	idivl	%ecx
    7452:      	movl	%esi, %ebx
    7454:      	testl	%edx, %edx
    7456:      	je	0x747a <generic_kprobe_filter_arg+0x5fa>
    7458:      	movl	%esi, %eax
    745a:      	movl	$0x18, %ecx
    745f:      	cltd
    7460:      	idivl	%ecx
    7462:      	shll	$0x3, %eax
    7465:      	leal	(%rax,%rax,2), %eax
    7468:      	addl	$0x18, %eax
    746b:      	movzwl	%ax, %ebx
    746e:      	cmpl	$0x90, %ebx
    7474:      	ja	0x8483 <generic_kprobe_filter_arg+0x1603>
    747a:      	movl	%ebx, %eax
    747c:      	cltd
    747d:      	idivl	%ecx
    747f:      	decl	%eax
    7481:      	jmp	0x9369 <generic_kprobe_filter_arg+0x24e9>
    7486:      	movl	(%r12), %ebp
    748a:      	movl	%eax, %ecx
    748c:      	andl	$-0x2, %ecx
    748f:      	cmpl	$0x24, %ecx
    7492:      	je	0x749c <generic_kprobe_filter_arg+0x61c>
    7494:      	testl	%ebp, %ebp
    7496:      	je	0x6f9d <generic_kprobe_filter_arg+0x11d>
    749c:      	cmpl	$0x25, %eax
    749f:      	ja	0x77cf <generic_kprobe_filter_arg+0x94f>
    74a5:      	movl	%eax, %ecx
    74a7:      	movl	$0x4000100, %edx        # imm = 0x4000100
    74ac:      	btq	%rcx, %rdx
    74b0:      	jb	0x79c0 <generic_kprobe_filter_arg+0xb40>
    74b6:      	movl	$0x8000200, %edx        # imm = 0x8000200
    74bb:      	btq	%rcx, %rdx
    74bf:      	jb	0x788a <generic_kprobe_filter_arg+0xa0a>
    74c5:      	movabsq	$0x3000000000, %rdx     # imm = 0x3000000000
    74cf:      	btq	%rcx, %rdx
    74d3:      	jae	0x77cf <generic_kprobe_filter_arg+0x94f>
    74d9:      	movw	$0x0, 0x38(%rsp)
    74e0:      	cmpl	$0x1000, %ebp           # imm = 0x1000
    74e6:      	ja	0x9c6c <generic_kprobe_filter_arg+0x2dec>
    74ec:      	movq	%r11, 0x10(%rsp)
    74f1:      	leaq	(%r12,%rbp), %rcx
    74f5:      	addq	$0x8, %rcx
    74f9:      	movl	$0x4, %eax
    74fe:      	leaq	0x38(%rsp), %rdi
    7503:      	movl	$0x2, %edx
    7508:      	movl	(%r12), %ecx
    750c:      	leaq	(%r12,%rcx), %rdx
    7510:      	addq	$0x8, %rdx
    7514:      	movl	$0x2, %esi
    7519:      	callq	*%rax
    751b:      	movl	0x10(%r13), %ecx
    751f:      	testl	%ecx, %ecx
    7521:      	je	0xa113 <generic_kprobe_filter_arg+0x3293>
    7527:      	movzwl	0x38(%rsp), %eax
    752c:      	andl	$0xf000, %eax           # imm = 0xF000
    7531:      	movl	$0x1, %ebx
    7536:      	cmpl	%eax, %ecx
    7538:      	je	0xa115 <generic_kprobe_filter_arg+0x3295>
    753e:      	movl	0x8(%r13), %ecx
    7542:      	cmpl	$0xd, %ecx
    7545:      	movq	(%rsp), %rdi
    7549:      	movq	0x8(%rsp), %r9
    754e:      	movq	0x10(%rsp), %r11
    7553:      	jb	0x9c6c <generic_kprobe_filter_arg+0x2dec>
    7559:      	movl	0x14(%r13), %edx
    755d:      	testl	%edx, %edx
    755f:      	je	0x9c6c <generic_kprobe_filter_arg+0x2dec>
    7565:      	cmpl	%eax, %edx
    7567:      	je	0xa123 <generic_kprobe_filter_arg+0x32a3>
    756d:      	cmpl	$0x11, %ecx
    7570:      	jb	0x9c6c <generic_kprobe_filter_arg+0x2dec>
    7576:      	movl	0x18(%r13), %edx
    757a:      	testl	%edx, %edx
    757c:      	je	0x9c6c <generic_kprobe_filter_arg+0x2dec>
    7582:      	cmpl	%eax, %edx
    7584:      	je	0xa123 <generic_kprobe_filter_arg+0x32a3>
    758a:      	cmpl	$0x15, %ecx
    758d:      	jb	0xa4ed <generic_kprobe_filter_arg+0x366d>
    7593:      	movl	0x1c(%r13), %ecx
    7597:      	testl	%ecx, %ecx
    7599:      	je	0xa4ed <generic_kprobe_filter_arg+0x366d>
    759f:      	xorl	%ebx, %ebx
    75a1:      	cmpl	%eax, %ecx
    75a3:      	sete	%bl
    75a6:      	jmp	0xa4ef <generic_kprobe_filter_arg+0x366f>
    75ab:      	leal	-0xc(%rcx), %edx
    75ae:      	cmpl	$0x2, %edx
    75b1:      	jae	0x7aea <generic_kprobe_filter_arg+0xc6a>
    75b7:      	cmpl	$0x20, %eax
    75ba:      	ja	0x6f9d <generic_kprobe_filter_arg+0x11d>
    75c0:      	movl	%eax, %edx
    75c2:      	movl	$0x101e, %esi           # imm = 0x101E
    75c7:      	btq	%rdx, %rsi
    75cb:      	jae	0x7614 <generic_kprobe_filter_arg+0x794>
    75cd:      	movl	0x10(%r13), %edx
    75d1:      	cmpl	$0x2, %eax
    75d4:      	jle	0x7ab2 <generic_kprobe_filter_arg+0xc32>
    75da:      	leal	-0x3(%rax), %esi
    75dd:      	cmpl	$0x2, %esi
    75e0:      	jae	0x7f71 <generic_kprobe_filter_arg+0x10f1>
    75e6:      	cmpl	%edx, (%r12)
    75ea:      	je	0x7145 <generic_kprobe_filter_arg+0x2c5>
    75f0:      	jmp	0x90a7 <generic_kprobe_filter_arg+0x2227>
    75f5:      	cmpl	$0x28, %ecx
    75f8:      	je	0x7c2a <generic_kprobe_filter_arg+0xdaa>
    75fe:      	movq	%r12, %rdx
    7601:      	movl	$0x0, %ebx
    7606:      	cmpl	$0x29, %ecx
    7609:      	je	0x7c5a <generic_kprobe_filter_arg+0xdda>
    760f:      	jmp	0x7150 <generic_kprobe_filter_arg+0x2d0>
    7614:      	movl	$0xc00, %esi            # imm = 0xC00
    7619:      	btq	%rdx, %rsi
    761d:      	jb	0x7be7 <generic_kprobe_filter_arg+0xd67>
    7623:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
    762d:      	btq	%rdx, %rsi
    7631:      	jae	0x6f9d <generic_kprobe_filter_arg+0x11d>
    7637:      	cmpl	$0x1f, %eax
    763a:      	jne	0x81c9 <generic_kprobe_filter_arg+0x1349>
    7640:      	movl	0x10(%r13), %esi
    7644:      	movl	0x14(%r13), %edx
    7648:      	cmpl	$0xc, %ecx
    764b:      	ja	0x8dc3 <generic_kprobe_filter_arg+0x1f43>
    7651:      	movl	$0x1402, %eax           # imm = 0x1402
    7656:      	btl	%ecx, %eax
    7659:      	jae	0x8dc3 <generic_kprobe_filter_arg+0x1f43>
    765f:      	movl	(%r12), %eax
    7663:      	cmpl	%eax, %esi
    7665:      	jg	0x8dd3 <generic_kprobe_filter_arg+0x1f53>
    766b:      	cmpl	%edx, %eax
    766d:      	jle	0x7161 <generic_kprobe_filter_arg+0x2e1>
    7673:      	jmp	0x8dd3 <generic_kprobe_filter_arg+0x1f53>
    7678:      	cmpl	$0x20, %eax
    767b:      	jg	0x7cdf <generic_kprobe_filter_arg+0xe5f>
    7681:      	cmpl	$0x1a, %eax
    7684:      	je	0x7e25 <generic_kprobe_filter_arg+0xfa5>
    768a:      	movl	$0x0, %ebx
    768f:      	cmpl	$0x1b, %eax
    7692:      	jne	0xa4bb <generic_kprobe_filter_arg+0x363b>
    7698:      	movq	%r11, 0x10(%rsp)
    769d:      	movl	0x10(%r13), %eax
    76a1:      	movl	%eax, 0x38(%rsp)
    76a5:      	movl	$0x0, 0x70(%rsp)
    76ad:      	movl	$0x1, %eax
    76b2:      	leaq	0x38(%rsp), %rsi
    76b7:      	movq	(%rip), %rdi            # 0x76be <generic_kprobe_filter_arg+0x83e>
    76be:      	callq	*%rax
    76c0:      	testl	%ebp, %ebp
    76c2:      	je	0xa4ab <generic_kprobe_filter_arg+0x362b>
    76c8:      	movq	%rax, %r12
    76cb:      	movl	$0x0, %ebx
    76d0:      	testq	%rax, %rax
    76d3:      	je	0xa4ad <generic_kprobe_filter_arg+0x362d>
    76d9:      	movl	$0x1, %eax
    76de:      	movq	0x28(%rsp), %rsi
    76e3:      	movq	(%rip), %rdi            # 0x76ea <generic_kprobe_filter_arg+0x86a>
    76ea:      	callq	*%rax
    76ec:      	testq	%rax, %rax
    76ef:      	je	0xa4ab <generic_kprobe_filter_arg+0x362b>
    76f5:      	movq	%rax, %rdi
    76f8:      	movq	%r12, 0x20(%rsp)
    76fd:      	cmpl	$0x7f, %ebp
    7700:      	movl	$0x7f, %eax
    7705:      	cmovbl	%ebp, %eax
    7708:      	shll	$0x3, %eax
    770b:      	movl	%eax, (%rdi)
    770d:      	movq	%rbp, %rax
    7710:      	negq	%rax
    7713:      	movl	$0x3, %ecx
    7718:      	subq	%rbp, %rcx
    771b:      	leal	-0x4(%rbp), %edx
    771e:      	movq	%rdi, 0x60(%rsp)
    7723:      	addq	$0x7, %rdi
    7727:      	movl	$0x2, %r8d
    772d:      	subq	%rbp, %r8
    7730:      	leal	-0x3(%rbp), %r9d
    7734:      	movl	$0x1, %r10d
    773a:      	subq	%rbp, %r10
    773d:      	leal	-0x2(%rbp), %r11d
    7741:      	decl	%ebp
    7743:      	xorl	%ebx, %ebx
    7745:      	movq	0x18(%rsp), %rsi
    774a:      	leal	(%rbx,%rbp), %r12d
    774e:      	andl	$0xfff, %r12d           # imm = 0xFFF
    7755:      	movzbl	(%rsi,%r12), %r12d
    775a:      	movb	%r12b, -0x3(%rdi)
    775e:      	cmpq	%rbx, %r10
    7761:      	je	0x77bb <generic_kprobe_filter_arg+0x93b>
    7763:      	leal	(%r11,%rbx), %r12d
    7767:      	andl	$0xfff, %r12d           # imm = 0xFFF
    776e:      	movzbl	(%rsi,%r12), %r12d
    7773:      	movb	%r12b, -0x2(%rdi)
    7777:      	cmpq	%rbx, %r8
    777a:      	je	0x77bb <generic_kprobe_filter_arg+0x93b>
    777c:      	leal	(%r9,%rbx), %r12d
    7780:      	andl	$0xfff, %r12d           # imm = 0xFFF
    7787:      	movzbl	(%rsi,%r12), %r12d
    778c:      	movb	%r12b, -0x1(%rdi)
    7790:      	cmpq	%rbx, %rcx
    7793:      	je	0x77bb <generic_kprobe_filter_arg+0x93b>
    7795:      	cmpq	$-0x7c, %rbx
    7799:      	je	0x77bb <generic_kprobe_filter_arg+0x93b>
    779b:      	leal	(%rdx,%rbx), %r12d
    779f:      	andl	$0xfff, %r12d           # imm = 0xFFF
    77a6:      	movzbl	(%rsi,%r12), %r12d
    77ab:      	movb	%r12b, (%rdi)
    77ae:      	addq	$-0x4, %rbx
    77b2:      	addq	$0x4, %rdi
    77b6:      	cmpq	%rbx, %rax
    77b9:      	jne	0x774a <generic_kprobe_filter_arg+0x8ca>
    77bb:      	movl	$0x1, %eax
    77c0:      	movq	0x20(%rsp), %rdi
    77c5:      	movq	0x60(%rsp), %rsi
    77ca:      	jmp	0x8968 <generic_kprobe_filter_arg+0x1ae8>
    77cf:      	addl	$-0x3, %eax
    77d2:      	cmpl	$0x2, %eax
    77d5:      	jae	0x9c6c <generic_kprobe_filter_arg+0x2dec>
    77db:      	movl	$0x0, 0x70(%rsp)
    77e3:      	cmpl	$0x1000, %ebp           # imm = 0x1000
    77e9:      	ja	0x9c6c <generic_kprobe_filter_arg+0x2dec>
    77ef:      	movzwl	%bp, %eax
    77f2:      	cmpl	$0x90, %eax
    77f7:      	movq	%r11, 0x10(%rsp)
    77fc:      	ja	0x85c3 <generic_kprobe_filter_arg+0x1743>
    7802:      	testw	%bp, %bp
    7805:      	je	0x7817 <generic_kprobe_filter_arg+0x997>
    7807:      	movl	%ebp, %eax
    7809:      	movl	$0x18, %ecx
    780e:      	cltd
    780f:      	idivl	%ecx
    7811:      	movl	%ebp, %esi
    7813:      	testl	%edx, %edx
    7815:      	je	0x7839 <generic_kprobe_filter_arg+0x9b9>
    7817:      	movl	%ebp, %eax
    7819:      	movl	$0x18, %ecx
    781e:      	cltd
    781f:      	idivl	%ecx
    7821:      	shll	$0x3, %eax
    7824:      	leal	(%rax,%rax,2), %eax
    7827:      	addl	$0x18, %eax
    782a:      	movzwl	%ax, %esi
    782d:      	cmpl	$0x90, %esi
    7833:      	ja	0x85fb <generic_kprobe_filter_arg+0x177b>
    7839:      	movl	%esi, %eax
    783b:      	cltd
    783c:      	idivl	%ecx
    783e:      	decl	%eax
    7840:      	jmp	0x91cf <generic_kprobe_filter_arg+0x234f>
    7845:      	cmpl	$0x20, %eax
    7848:      	ja	0x6f9d <generic_kprobe_filter_arg+0x11d>
    784e:      	movl	%eax, %ecx
    7850:      	movl	$0x101e, %edx           # imm = 0x101E
    7855:      	btq	%rcx, %rdx
    7859:      	jae	0x7fbc <generic_kprobe_filter_arg+0x113c>
    785f:      	movl	0x10(%r13), %ecx
    7863:      	cmpl	$0x2, %eax
    7866:      	jle	0x84d7 <generic_kprobe_filter_arg+0x1657>
    786c:      	leal	-0x3(%rax), %edx
    786f:      	cmpl	$0x2, %edx
    7872:      	jae	0x8c29 <generic_kprobe_filter_arg+0x1da9>
    7878:      	movzwl	(%r12), %edx
    787d:      	cmpl	%edx, %ecx
    787f:      	je	0x7145 <generic_kprobe_filter_arg+0x2c5>
    7885:      	jmp	0x8d8b <generic_kprobe_filter_arg+0x1f0b>
    788a:      	movq	%r11, 0x10(%rsp)
    788f:      	movl	0x10(%r13), %eax
    7893:      	movl	%eax, 0x38(%rsp)
    7897:      	movl	$0x0, 0x70(%rsp)
    789f:      	movl	$0x1, %eax
    78a4:      	leaq	0x38(%rsp), %rsi
    78a9:      	movq	(%rip), %rdi            # 0x78b0 <generic_kprobe_filter_arg+0xa30>
    78b0:      	callq	*%rax
    78b2:      	testl	%ebp, %ebp
    78b4:      	je	0xa113 <generic_kprobe_filter_arg+0x3293>
    78ba:      	movl	$0x0, %ebx
    78bf:      	testq	%rax, %rax
    78c2:      	je	0xa115 <generic_kprobe_filter_arg+0x3295>
    78c8:      	movq	%rax, 0x18(%rsp)
    78cd:      	movl	$0x1, %eax
    78d2:      	movq	0x28(%rsp), %rsi
    78d7:      	movq	(%rip), %rdi            # 0x78de <generic_kprobe_filter_arg+0xa5e>
    78de:      	callq	*%rax
    78e0:      	testq	%rax, %rax
    78e3:      	je	0xa113 <generic_kprobe_filter_arg+0x3293>
    78e9:      	movq	%rax, %rdi
    78ec:      	cmpl	$0x7f, %ebp
    78ef:      	movl	$0x7f, %eax
    78f4:      	cmovbl	%ebp, %eax
    78f7:      	shll	$0x3, %eax
    78fa:      	movl	%eax, (%rdi)
    78fc:      	movq	%rbp, %rax
    78ff:      	negq	%rax
    7902:      	movl	$0x3, %ecx
    7907:      	subq	%rbp, %rcx
    790a:      	leal	-0x4(%rbp), %edx
    790d:      	movq	%rdi, 0x20(%rsp)
    7912:      	addq	$0x7, %rdi
    7916:      	movl	$0x2, %r8d
    791c:      	subq	%rbp, %r8
    791f:      	leal	-0x3(%rbp), %r9d
    7923:      	movl	$0x1, %r10d
    7929:      	subq	%rbp, %r10
    792c:      	leal	-0x2(%rbp), %r11d
    7930:      	decl	%ebp
    7932:      	xorl	%ebx, %ebx
    7934:      	movq	%r12, %rsi
    7937:      	leal	(%rbx,%rbp), %r12d
    793b:      	andl	$0xfff, %r12d           # imm = 0xFFF
    7942:      	movzbl	0x4(%rsi,%r12), %r12d
    7948:      	movb	%r12b, -0x3(%rdi)
    794c:      	cmpq	%rbx, %r10
    794f:      	je	0x79ac <generic_kprobe_filter_arg+0xb2c>
    7951:      	leal	(%r11,%rbx), %r12d
    7955:      	andl	$0xfff, %r12d           # imm = 0xFFF
    795c:      	movzbl	0x4(%rsi,%r12), %r12d
    7962:      	movb	%r12b, -0x2(%rdi)
    7966:      	cmpq	%rbx, %r8
    7969:      	je	0x79ac <generic_kprobe_filter_arg+0xb2c>
    796b:      	leal	(%r9,%rbx), %r12d
    796f:      	andl	$0xfff, %r12d           # imm = 0xFFF
    7976:      	movzbl	0x4(%rsi,%r12), %r12d
    797c:      	movb	%r12b, -0x1(%rdi)
    7980:      	cmpq	%rbx, %rcx
    7983:      	je	0x79ac <generic_kprobe_filter_arg+0xb2c>
    7985:      	cmpq	$-0x7c, %rbx
    7989:      	je	0x79ac <generic_kprobe_filter_arg+0xb2c>
    798b:      	leal	(%rdx,%rbx), %r12d
    798f:      	andl	$0xfff, %r12d           # imm = 0xFFF
    7996:      	movzbl	0x4(%rsi,%r12), %r12d
    799c:      	movb	%r12b, (%rdi)
    799f:      	addq	$-0x4, %rbx
    79a3:      	addq	$0x4, %rdi
    79a7:      	cmpq	%rbx, %rax
    79aa:      	jne	0x7937 <generic_kprobe_filter_arg+0xab7>
    79ac:      	movl	$0x1, %eax
    79b1:      	movq	0x18(%rsp), %rdi
    79b6:      	movq	0x20(%rsp), %rsi
    79bb:      	jmp	0xa107 <generic_kprobe_filter_arg+0x3287>
    79c0:      	movq	%r11, 0x10(%rsp)
    79c5:      	movl	0x10(%r13), %eax
    79c9:      	movl	%eax, 0x38(%rsp)
    79cd:      	movl	$0x0, 0x70(%rsp)
    79d5:      	movl	$0x1, %eax
    79da:      	leaq	0x38(%rsp), %rsi
    79df:      	movq	(%rip), %rdi            # 0x79e6 <generic_kprobe_filter_arg+0xb66>
    79e6:      	callq	*%rax
    79e8:      	testl	%ebp, %ebp
    79ea:      	je	0xa113 <generic_kprobe_filter_arg+0x3293>
    79f0:      	movl	$0x0, %ebx
    79f5:      	testq	%rax, %rax
    79f8:      	je	0xa115 <generic_kprobe_filter_arg+0x3295>
    79fe:      	movq	%rax, 0x18(%rsp)
    7a03:      	movl	$0x1, %eax
    7a08:      	movq	0x28(%rsp), %rsi
    7a0d:      	movq	(%rip), %rdi            # 0x7a14 <generic_kprobe_filter_arg+0xb94>
    7a14:      	callq	*%rax
    7a16:      	testq	%rax, %rax
    7a19:      	je	0xa113 <generic_kprobe_filter_arg+0x3293>
    7a1f:      	movq	%rax, %rbx
    7a22:      	addq	$0x4, %r12
    7a26:      	cmpl	$0xff, %ebp
    7a2c:      	movl	$0xff, %eax
    7a31:      	cmovael	%eax, %ebp
    7a34:      	leal	(,%rbp,8), %eax
    7a3b:      	movl	%eax, (%rbx)
    7a3d:      	movq	%rbx, %rdi
    7a40:      	addq	$0x4, %rdi
    7a44:      	movl	$0x4, %eax
    7a49:      	movl	%ebp, %esi
    7a4b:      	movq	%r12, %rdx
    7a4e:      	callq	*%rax
    7a50:      	movl	$0x1, %eax
    7a55:      	movq	0x18(%rsp), %rdi
    7a5a:      	movq	%rbx, %rsi
    7a5d:      	jmp	0xa107 <generic_kprobe_filter_arg+0x3287>
    7a62:      	leal	-0x1(%rax), %edx
    7a65:      	cmpl	$0x4, %edx
    7a68:      	jb	0x7b09 <generic_kprobe_filter_arg+0xc89>
    7a6e:      	jmp	0x6f9d <generic_kprobe_filter_arg+0x11d>
    7a73:      	movl	0x4(%r12), %ebp
    7a78:      	addq	$0x8, %r12
    7a7c:      	movq	%r12, 0x18(%rsp)
    7a81:      	cmpl	$0x19, %eax
    7a84:      	jg	0x8072 <generic_kprobe_filter_arg+0x11f2>
    7a8a:      	leal	-0x3(%rax), %ecx
    7a8d:      	cmpl	$0x2, %ecx
    7a90:      	jb	0x8977 <generic_kprobe_filter_arg+0x1af7>
    7a96:      	cmpl	$0x8, %eax
    7a99:      	je	0x88d1 <generic_kprobe_filter_arg+0x1a51>
    7a9f:      	movl	$0x0, %ebx
    7aa4:      	cmpl	$0x9, %eax
    7aa7:      	je	0x8092 <generic_kprobe_filter_arg+0x1212>
    7aad:      	jmp	0xa4bb <generic_kprobe_filter_arg+0x363b>
    7ab2:      	cmpl	$0x1, %eax
    7ab5:      	je	0x8364 <generic_kprobe_filter_arg+0x14e4>
    7abb:      	cmpl	$0x2, %eax
    7abe:      	jne	0x90a7 <generic_kprobe_filter_arg+0x2227>
    7ac4:      	cmpl	$0xc, %ecx
    7ac7:      	ja	0x909d <generic_kprobe_filter_arg+0x221d>
    7acd:      	movl	$0x1402, %esi           # imm = 0x1402
    7ad2:      	btl	%ecx, %esi
    7ad5:      	jae	0x909d <generic_kprobe_filter_arg+0x221d>
    7adb:      	cmpl	%edx, (%r12)
    7adf:      	jl	0x7161 <generic_kprobe_filter_arg+0x2e1>
    7ae5:      	jmp	0x90a7 <generic_kprobe_filter_arg+0x2227>
    7aea:      	cmpl	$0x1c, %ecx
    7aed:      	jne	0x7161 <generic_kprobe_filter_arg+0x2e1>
    7af3:      	cmpl	$0x20, %eax
    7af6:      	ja	0x6f9d <generic_kprobe_filter_arg+0x11d>
    7afc:      	movl	%eax, %edx
    7afe:      	movl	$0x101e, %esi           # imm = 0x101E
    7b03:      	btq	%rdx, %rsi
    7b07:      	jae	0x7b2d <generic_kprobe_filter_arg+0xcad>
    7b09:      	movq	0x10(%r13), %rdx
    7b0d:      	cmpl	$0x2, %eax
    7b10:      	jle	0x7b51 <generic_kprobe_filter_arg+0xcd1>
    7b12:      	leal	-0x3(%rax), %esi
    7b15:      	cmpl	$0x2, %esi
    7b18:      	jae	0x7dc7 <generic_kprobe_filter_arg+0xf47>
    7b1e:      	cmpq	%rdx, (%r12)
    7b22:      	je	0x7145 <generic_kprobe_filter_arg+0x2c5>
    7b28:      	jmp	0x8b92 <generic_kprobe_filter_arg+0x1d12>
    7b2d:      	movl	$0xc00, %esi            # imm = 0xC00
    7b32:      	btq	%rdx, %rsi
    7b36:      	jb	0x7b80 <generic_kprobe_filter_arg+0xd00>
    7b38:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
    7b42:      	btq	%rdx, %rsi
    7b46:      	jb	0x7deb <generic_kprobe_filter_arg+0xf6b>
    7b4c:      	jmp	0x6f9d <generic_kprobe_filter_arg+0x11d>
    7b51:      	cmpl	$0x1, %eax
    7b54:      	je	0x8055 <generic_kprobe_filter_arg+0x11d5>
    7b5a:      	cmpl	$0x2, %eax
    7b5d:      	jne	0x8b92 <generic_kprobe_filter_arg+0x1d12>
    7b63:      	cmpl	$0xc, %ecx
    7b66:      	je	0x7b71 <generic_kprobe_filter_arg+0xcf1>
    7b68:      	cmpl	$0xa, %ecx
    7b6b:      	jne	0x8b88 <generic_kprobe_filter_arg+0x1d08>
    7b71:      	cmpq	%rdx, (%r12)
    7b75:      	jl	0x7161 <generic_kprobe_filter_arg+0x2e1>
    7b7b:      	jmp	0x8b92 <generic_kprobe_filter_arg+0x1d12>
    7b80:      	movq	%r11, %rbp
    7b83:      	movzbl	0x10(%r13), %eax
    7b88:      	movl	%eax, 0x70(%rsp)
    7b8c:      	movl	$0x1, %eax
    7b91:      	movq	0x28(%rsp), %rsi
    7b96:      	movq	(%rip), %rdi            # 0x7b9d <generic_kprobe_filter_arg+0xd1d>
    7b9d:      	callq	*%rax
    7b9f:      	testq	%rax, %rax
    7ba2:      	je	0x88be <generic_kprobe_filter_arg+0x1a3e>
    7ba8:      	movq	%rax, %rdi
    7bab:      	movq	(%r12), %rax
    7baf:      	movq	%rax, 0x38(%rsp)
    7bb4:      	movl	$0x1, %eax
    7bb9:      	leaq	0x38(%rsp), %rsi
    7bbe:      	callq	*%rax
    7bc0:      	movl	0x4(%r13), %ecx
    7bc4:      	cmpl	$0xb, %ecx
    7bc7:      	je	0x85a9 <generic_kprobe_filter_arg+0x1729>
    7bcd:      	cmpl	$0xa, %ecx
    7bd0:      	movq	(%rsp), %rdi
    7bd4:      	movq	0x8(%rsp), %r9
    7bd9:      	movq	%rbp, %r11
    7bdc:      	je	0x86af <generic_kprobe_filter_arg+0x182f>
    7be2:      	jmp	0x86bd <generic_kprobe_filter_arg+0x183d>
    7be7:      	movq	%r11, %rbp
    7bea:      	movzbl	0x10(%r13), %eax
    7bef:      	movl	%eax, 0x70(%rsp)
    7bf3:      	movl	$0x1, %eax
    7bf8:      	movq	0x28(%rsp), %rsi
    7bfd:      	movq	(%rip), %rdi            # 0x7c04 <generic_kprobe_filter_arg+0xd84>
    7c04:      	callq	*%rax
    7c06:      	testq	%rax, %rax
    7c09:      	je	0x88be <generic_kprobe_filter_arg+0x1a3e>
    7c0f:      	movq	%rax, %rdi
    7c12:      	movl	(%r12), %eax
    7c16:      	movq	%rax, 0x38(%rsp)
    7c1b:      	movl	$0x1, %eax
    7c20:      	leaq	0x38(%rsp), %rsi
    7c25:      	jmp	0x8885 <generic_kprobe_filter_arg+0x1a05>
    7c2a:      	movzwl	(%r12), %edx
    7c2f:      	movw	%dx, 0x5e(%rsp)
    7c34:      	movzwl	0x2(%r12), %edx
    7c3a:      	movw	%dx, 0x58(%rsp)
    7c3f:      	movq	0x8(%r12), %rdx
    7c44:      	movq	%rdx, 0x38(%rsp)
    7c49:      	movq	0x10(%r12), %rdx
    7c4e:      	movq	%rdx, 0x40(%rsp)
    7c53:      	leaq	0x38(%rsp), %r12
    7c58:      	xorl	%edx, %edx
    7c5a:      	cmpl	$0x13, %eax
    7c5d:      	jle	0x7c86 <generic_kprobe_filter_arg+0xe06>
    7c5f:      	cmpl	$0x17, %eax
    7c62:      	jg	0x7cba <generic_kprobe_filter_arg+0xe3a>
    7c64:      	leal	-0x14(%rax), %ecx
    7c67:      	cmpl	$0x2, %ecx
    7c6a:      	jb	0x8239 <generic_kprobe_filter_arg+0x13b9>
    7c70:      	leal	-0x16(%rax), %ecx
    7c73:      	movl	$0x0, %ebx
    7c78:      	cmpl	$0x2, %ecx
    7c7b:      	jb	0x822e <generic_kprobe_filter_arg+0x13ae>
    7c81:      	jmp	0x7150 <generic_kprobe_filter_arg+0x2d0>
    7c86:      	cmpl	$0xf, %eax
    7c89:      	jle	0x7f20 <generic_kprobe_filter_arg+0x10a0>
    7c8f:      	cmpl	$0x11, %eax
    7c92:      	jg	0x821b <generic_kprobe_filter_arg+0x139b>
    7c98:      	cmpl	$0x10, %eax
    7c9b:      	je	0x822e <generic_kprobe_filter_arg+0x13ae>
    7ca1:      	movl	$0x0, %ebx
    7ca6:      	cmpl	$0x11, %eax
    7ca9:      	jne	0x7150 <generic_kprobe_filter_arg+0x2d0>
    7caf:      	movzwl	0x24(%r12), %ebx
    7cb5:      	jmp	0x8a32 <generic_kprobe_filter_arg+0x1bb2>
    7cba:      	cmpl	$0x1b, %eax
    7cbd:      	jg	0x827a <generic_kprobe_filter_arg+0x13fa>
    7cc3:      	cmpl	$0x18, %eax
    7cc6:      	je	0x82b9 <generic_kprobe_filter_arg+0x1439>
    7ccc:      	movl	$0x0, %ebx
    7cd1:      	cmpl	$0x19, %eax
    7cd4:      	je	0x82aa <generic_kprobe_filter_arg+0x142a>
    7cda:      	jmp	0x7150 <generic_kprobe_filter_arg+0x2d0>
    7cdf:      	cmpl	$0x21, %eax
    7ce2:      	je	0x838a <generic_kprobe_filter_arg+0x150a>
    7ce8:      	movl	$0x0, %ebx
    7ced:      	cmpl	$0x22, %eax
    7cf0:      	jne	0xa4bb <generic_kprobe_filter_arg+0x363b>
    7cf6:      	xorl	%ebx, %ebx
    7cf8:      	xorl	%r12d, %r12d
    7cfb:      	movq	%r11, %r15
    7cfe:      	movl	0x10(%r13,%rbx,4), %eax
    7d03:      	movl	%eax, 0x38(%rsp)
    7d07:      	movl	$0x1, %eax
    7d0c:      	leaq	0x38(%rsp), %rsi
    7d11:      	movq	(%rip), %rdi            # 0x7d18 <generic_kprobe_filter_arg+0xe98>
    7d18:      	callq	*%rax
    7d1a:      	testq	%rax, %rax
    7d1d:      	je	0x9036 <generic_kprobe_filter_arg+0x21b6>
    7d23:      	testl	%ebp, %ebp
    7d25:      	movq	%r15, %r11
    7d28:      	movq	0x68(%rsp), %r15
    7d2d:      	je	0x7da4 <generic_kprobe_filter_arg+0xf24>
    7d2f:      	movq	0x18(%rsp), %rdx
    7d34:      	xorl	%ecx, %ecx
    7d36:      	jmp	0x7d43 <generic_kprobe_filter_arg+0xec3>
    7d38:      	incq	%rcx
    7d3b:      	incq	%rdx
    7d3e:      	cmpq	%rbp, %rcx
    7d41:      	je	0x7da4 <generic_kprobe_filter_arg+0xf24>
    7d43:      	xorl	%esi, %esi
    7d45:      	nopw	%cs:(%rax,%rax)
    7d50:      	leaq	(%rcx,%rsi), %rdi
    7d54:      	cmpq	%rbp, %rdi
    7d57:      	jae	0x7d38 <generic_kprobe_filter_arg+0xeb8>
    7d59:      	movsbl	(%rax,%rsi), %edi
    7d5d:      	testl	%edi, %edi
    7d5f:      	je	0x7d9c <generic_kprobe_filter_arg+0xf1c>
    7d61:      	movsbl	(%rdx,%rsi), %r9d
    7d66:      	leal	-0x41(%r9), %r10d
    7d6a:      	movl	%r9d, %r8d
    7d6d:      	orl	$0x20, %r8d
    7d71:      	cmpl	$0x1a, %r10d
    7d75:      	cmovael	%r9d, %r8d
    7d79:      	leal	-0x41(%rdi), %r10d
    7d7d:      	movl	%edi, %r9d
    7d80:      	orl	$0x20, %r9d
    7d84:      	cmpl	$0x1a, %r10d
    7d88:      	cmovael	%edi, %r9d
    7d8c:      	cmpq	$0x62, %rsi
    7d90:      	ja	0x7d38 <generic_kprobe_filter_arg+0xeb8>
    7d92:      	incq	%rsi
    7d95:      	cmpl	%r9d, %r8d
    7d98:      	je	0x7d50 <generic_kprobe_filter_arg+0xed0>
    7d9a:      	jmp	0x7d38 <generic_kprobe_filter_arg+0xeb8>
    7d9c:      	testl	%ecx, %ecx
    7d9e:      	jns	0x950e <generic_kprobe_filter_arg+0x268e>
    7da4:      	leal	0xc(%r12), %eax
    7da9:      	cmpl	0x8(%r13), %eax
    7dad:      	jae	0x7dc0 <generic_kprobe_filter_arg+0xf40>
    7daf:      	addl	$0x4, %r12d
    7db3:      	incq	%rbx
    7db6:      	cmpq	$0x64, %rbx
    7dba:      	jne	0x7cfb <generic_kprobe_filter_arg+0xe7b>
    7dc0:      	xorl	%ebx, %ebx
    7dc2:      	jmp	0x9513 <generic_kprobe_filter_arg+0x2693>
    7dc7:      	cmpl	$0xc, %eax
    7dca:      	jne	0x8b92 <generic_kprobe_filter_arg+0x1d12>
    7dd0:      	testq	%rdx, (%r12)
    7dd4:      	jne	0x7161 <generic_kprobe_filter_arg+0x2e1>
    7dda:      	jmp	0x8b92 <generic_kprobe_filter_arg+0x1d12>
    7ddf:      	leal	-0x1f(%rax), %edx
    7de2:      	cmpl	$0x2, %edx
    7de5:      	jae	0x86c7 <generic_kprobe_filter_arg+0x1847>
    7deb:      	cmpl	$0x1f, %eax
    7dee:      	jne	0x7f45 <generic_kprobe_filter_arg+0x10c5>
    7df4:      	movq	0x10(%r13), %rsi
    7df8:      	movq	0x18(%r13), %rdx
    7dfc:      	cmpl	$0xa, %ecx
    7dff:      	je	0x7e0a <generic_kprobe_filter_arg+0xf8a>
    7e01:      	cmpl	$0xc, %ecx
    7e04:      	jne	0x8992 <generic_kprobe_filter_arg+0x1b12>
    7e0a:      	movq	(%r12), %rax
    7e0e:      	cmpq	%rax, %rsi
    7e11:      	jg	0x89a4 <generic_kprobe_filter_arg+0x1b24>
    7e17:      	cmpq	%rdx, %rax
    7e1a:      	jle	0x7161 <generic_kprobe_filter_arg+0x2e1>
    7e20:      	jmp	0x89a4 <generic_kprobe_filter_arg+0x1b24>
    7e25:      	movq	%r11, 0x10(%rsp)
    7e2a:      	movl	0x10(%r13), %eax
    7e2e:      	movl	%eax, 0x38(%rsp)
    7e32:      	movl	$0x0, 0x70(%rsp)
    7e3a:      	movl	$0x1, %eax
    7e3f:      	leaq	0x38(%rsp), %rsi
    7e44:      	movq	(%rip), %rdi            # 0x7e4b <generic_kprobe_filter_arg+0xfcb>
    7e4b:      	callq	*%rax
    7e4d:      	testl	%ebp, %ebp
    7e4f:      	je	0xa4ab <generic_kprobe_filter_arg+0x362b>
    7e55:      	movq	%rax, %r12
    7e58:      	movl	$0x0, %ebx
    7e5d:      	testq	%rax, %rax
    7e60:      	je	0xa4ad <generic_kprobe_filter_arg+0x362d>
    7e66:      	movl	$0x1, %eax
    7e6b:      	movq	0x28(%rsp), %rsi
    7e70:      	movq	(%rip), %rdi            # 0x7e77 <generic_kprobe_filter_arg+0xff7>
    7e77:      	callq	*%rax
    7e79:      	testq	%rax, %rax
    7e7c:      	je	0xa4ab <generic_kprobe_filter_arg+0x362b>
    7e82:      	cmpl	$0xff, %ebp
    7e88:      	movl	$0xff, %ecx
    7e8d:      	cmovael	%ecx, %ebp
    7e90:      	leal	(,%rbp,8), %ecx
    7e97:      	movl	%ecx, (%rax)
    7e99:      	movq	%rax, %rdi
    7e9c:      	addq	$0x4, %rdi
    7ea0:      	movq	%rax, %rbx
    7ea3:      	movl	$0x4, %eax
    7ea8:      	movq	0x18(%rsp), %rdx
    7ead:      	movl	%ebp, %esi
    7eaf:      	callq	*%rax
    7eb1:      	movl	$0x1, %eax
    7eb6:      	jmp	0x8962 <generic_kprobe_filter_arg+0x1ae2>
    7ebb:      	movl	$0x0, 0x70(%rsp)
    7ec3:      	cmpl	$0x1000, %ebp           # imm = 0x1000
    7ec9:      	ja	0x898b <generic_kprobe_filter_arg+0x1b0b>
    7ecf:      	movzwl	%bp, %eax
    7ed2:      	cmpl	$0x90, %eax
    7ed7:      	ja	0x8b14 <generic_kprobe_filter_arg+0x1c94>
    7edd:      	testw	%bp, %bp
    7ee0:      	je	0x7ef2 <generic_kprobe_filter_arg+0x1072>
    7ee2:      	movl	%ebp, %eax
    7ee4:      	movl	$0x18, %ecx
    7ee9:      	cltd
    7eea:      	idivl	%ecx
    7eec:      	movl	%ebp, %esi
    7eee:      	testl	%edx, %edx
    7ef0:      	je	0x7f14 <generic_kprobe_filter_arg+0x1094>
    7ef2:      	movl	%ebp, %eax
    7ef4:      	movl	$0x18, %ecx
    7ef9:      	cltd
    7efa:      	idivl	%ecx
    7efc:      	shll	$0x3, %eax
    7eff:      	leal	(%rax,%rax,2), %eax
    7f02:      	addl	$0x18, %eax
    7f05:      	movzwl	%ax, %esi
    7f08:      	cmpl	$0x90, %esi
    7f0e:      	ja	0x8b4c <generic_kprobe_filter_arg+0x1ccc>
    7f14:      	movl	%esi, %eax
    7f16:      	cltd
    7f17:      	idivl	%ecx
    7f19:      	decl	%eax
    7f1b:      	jmp	0x975c <generic_kprobe_filter_arg+0x28dc>
    7f20:      	cmpl	$0xd, %eax
    7f23:      	je	0x82b9 <generic_kprobe_filter_arg+0x1439>
    7f29:      	cmpl	$0xe, %eax
    7f2c:      	je	0x82aa <generic_kprobe_filter_arg+0x142a>
    7f32:      	movl	$0x0, %ebx
    7f37:      	cmpl	$0xf, %eax
    7f3a:      	je	0x8239 <generic_kprobe_filter_arg+0x13b9>
    7f40:      	jmp	0x7150 <generic_kprobe_filter_arg+0x2d0>
    7f45:      	movq	0x10(%r13), %rsi
    7f49:      	movq	0x18(%r13), %rax
    7f4d:      	cmpl	$0xc, %ecx
    7f50:      	je	0x7f5b <generic_kprobe_filter_arg+0x10db>
    7f52:      	cmpl	$0xa, %ecx
    7f55:      	jne	0x89e2 <generic_kprobe_filter_arg+0x1b62>
    7f5b:      	movq	(%r12), %rdx
    7f5f:      	cmpq	%rdx, %rsi
    7f62:      	setle	%sil
    7f66:      	cmpq	%rax, %rdx
    7f69:      	setle	%al
    7f6c:      	jmp	0x89f3 <generic_kprobe_filter_arg+0x1b73>
    7f71:      	cmpl	$0xc, %eax
    7f74:      	jne	0x90a7 <generic_kprobe_filter_arg+0x2227>
    7f7a:      	testl	%edx, (%r12)
    7f7e:      	jne	0x7161 <generic_kprobe_filter_arg+0x2e1>
    7f84:      	jmp	0x90a7 <generic_kprobe_filter_arg+0x2227>
    7f89:      	movl	$0xc00, %edx            # imm = 0xC00
    7f8e:      	btq	%rcx, %rdx
    7f92:      	jb	0x84fb <generic_kprobe_filter_arg+0x167b>
    7f98:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
    7fa2:      	btq	%rcx, %rdx
    7fa6:      	jae	0x6f9d <generic_kprobe_filter_arg+0x11d>
    7fac:      	cmpl	$0x1f, %eax
    7faf:      	jne	0x8c7d <generic_kprobe_filter_arg+0x1dfd>
    7fb5:      	movzbl	(%r12), %eax
    7fba:      	jmp	0x7fed <generic_kprobe_filter_arg+0x116d>
    7fbc:      	movl	$0xc00, %edx            # imm = 0xC00
    7fc1:      	btq	%rcx, %rdx
    7fc5:      	jb	0x853f <generic_kprobe_filter_arg+0x16bf>
    7fcb:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
    7fd5:      	btq	%rcx, %rdx
    7fd9:      	jae	0x6f9d <generic_kprobe_filter_arg+0x11d>
    7fdf:      	cmpl	$0x1f, %eax
    7fe2:      	jne	0x8c88 <generic_kprobe_filter_arg+0x1e08>
    7fe8:      	movzwl	(%r12), %eax
    7fed:      	cmpl	%eax, 0x10(%r13)
    7ff1:      	ja	0x7ffd <generic_kprobe_filter_arg+0x117d>
    7ff3:      	cmpl	%eax, 0x14(%r13)
    7ff7:      	jae	0x7161 <generic_kprobe_filter_arg+0x2e1>
    7ffd:      	movl	0x8(%r13), %ecx
    8001:      	cmpl	$0x11, %ecx
    8004:      	jb	0x6f9d <generic_kprobe_filter_arg+0x11d>
    800a:      	cmpl	%eax, 0x18(%r13)
    800e:      	ja	0x801a <generic_kprobe_filter_arg+0x119a>
    8010:      	cmpl	%eax, 0x1c(%r13)
    8014:      	jae	0x7161 <generic_kprobe_filter_arg+0x2e1>
    801a:      	cmpl	$0x19, %ecx
    801d:      	jb	0x6f9d <generic_kprobe_filter_arg+0x11d>
    8023:      	cmpl	%eax, 0x20(%r13)
    8027:      	ja	0x8033 <generic_kprobe_filter_arg+0x11b3>
    8029:      	cmpl	%eax, 0x24(%r13)
    802d:      	jae	0x7161 <generic_kprobe_filter_arg+0x2e1>
    8033:      	cmpl	$0x21, %ecx
    8036:      	jb	0x6f9d <generic_kprobe_filter_arg+0x11d>
    803c:      	cmpl	%eax, 0x28(%r13)
    8040:      	ja	0x6f9d <generic_kprobe_filter_arg+0x11d>
    8046:      	cmpl	%eax, 0x2c(%r13)
    804a:      	jae	0x7161 <generic_kprobe_filter_arg+0x2e1>
    8050:      	jmp	0x6f9d <generic_kprobe_filter_arg+0x11d>
    8055:      	cmpl	$0xc, %ecx
    8058:      	je	0x8063 <generic_kprobe_filter_arg+0x11e3>
    805a:      	cmpl	$0xa, %ecx
    805d:      	jne	0x8b7c <generic_kprobe_filter_arg+0x1cfc>
    8063:      	cmpq	%rdx, (%r12)
    8067:      	jg	0x7161 <generic_kprobe_filter_arg+0x2e1>
    806d:      	jmp	0x8b92 <generic_kprobe_filter_arg+0x1d12>
    8072:      	cmpl	$0x20, %eax
    8075:      	jg	0x870d <generic_kprobe_filter_arg+0x188d>
    807b:      	cmpl	$0x1a, %eax
    807e:      	je	0x88d1 <generic_kprobe_filter_arg+0x1a51>
    8084:      	movl	$0x0, %ebx
    8089:      	cmpl	$0x1b, %eax
    808c:      	jne	0xa4bb <generic_kprobe_filter_arg+0x363b>
    8092:      	movq	%r11, 0x10(%rsp)
    8097:      	movl	0x10(%r13), %eax
    809b:      	movl	%eax, 0x38(%rsp)
    809f:      	movl	$0x0, 0x70(%rsp)
    80a7:      	movl	$0x1, %eax
    80ac:      	leaq	0x38(%rsp), %rsi
    80b1:      	movq	(%rip), %rdi            # 0x80b8 <generic_kprobe_filter_arg+0x1238>
    80b8:      	callq	*%rax
    80ba:      	testl	%ebp, %ebp
    80bc:      	je	0xa4ab <generic_kprobe_filter_arg+0x362b>
    80c2:      	movq	%rax, %r12
    80c5:      	movl	$0x0, %ebx
    80ca:      	testq	%rax, %rax
    80cd:      	je	0xa4ad <generic_kprobe_filter_arg+0x362d>
    80d3:      	movl	$0x1, %eax
    80d8:      	movq	0x28(%rsp), %rsi
    80dd:      	movq	(%rip), %rdi            # 0x80e4 <generic_kprobe_filter_arg+0x1264>
    80e4:      	callq	*%rax
    80e6:      	testq	%rax, %rax
    80e9:      	je	0xa4ab <generic_kprobe_filter_arg+0x362b>
    80ef:      	movq	%rax, %rdi
    80f2:      	movq	%r12, 0x20(%rsp)
    80f7:      	cmpl	$0x7f, %ebp
    80fa:      	movl	$0x7f, %eax
    80ff:      	cmovbl	%ebp, %eax
    8102:      	shll	$0x3, %eax
    8105:      	movl	%eax, (%rdi)
    8107:      	movq	%rbp, %rax
    810a:      	negq	%rax
    810d:      	movl	$0x3, %ecx
    8112:      	subq	%rbp, %rcx
    8115:      	leal	-0x4(%rbp), %edx
    8118:      	movq	%rdi, 0x60(%rsp)
    811d:      	addq	$0x7, %rdi
    8121:      	movl	$0x2, %r8d
    8127:      	subq	%rbp, %r8
    812a:      	leal	-0x3(%rbp), %r9d
    812e:      	movl	$0x1, %r10d
    8134:      	subq	%rbp, %r10
    8137:      	leal	-0x2(%rbp), %r11d
    813b:      	decl	%ebp
    813d:      	xorl	%ebx, %ebx
    813f:      	movq	0x18(%rsp), %rsi
    8144:      	leal	(%rbx,%rbp), %r12d
    8148:      	andl	$0xfff, %r12d           # imm = 0xFFF
    814f:      	movzbl	(%rsi,%r12), %r12d
    8154:      	movb	%r12b, -0x3(%rdi)
    8158:      	cmpq	%rbx, %r10
    815b:      	je	0x81b5 <generic_kprobe_filter_arg+0x1335>
    815d:      	leal	(%r11,%rbx), %r12d
    8161:      	andl	$0xfff, %r12d           # imm = 0xFFF
    8168:      	movzbl	(%rsi,%r12), %r12d
    816d:      	movb	%r12b, -0x2(%rdi)
    8171:      	cmpq	%rbx, %r8
    8174:      	je	0x81b5 <generic_kprobe_filter_arg+0x1335>
    8176:      	leal	(%r9,%rbx), %r12d
    817a:      	andl	$0xfff, %r12d           # imm = 0xFFF
    8181:      	movzbl	(%rsi,%r12), %r12d
    8186:      	movb	%r12b, -0x1(%rdi)
    818a:      	cmpq	%rbx, %rcx
    818d:      	je	0x81b5 <generic_kprobe_filter_arg+0x1335>
    818f:      	cmpq	$-0x7c, %rbx
    8193:      	je	0x81b5 <generic_kprobe_filter_arg+0x1335>
    8195:      	leal	(%rdx,%rbx), %r12d
    8199:      	andl	$0xfff, %r12d           # imm = 0xFFF
    81a0:      	movzbl	(%rsi,%r12), %r12d
    81a5:      	movb	%r12b, (%rdi)
    81a8:      	addq	$-0x4, %rbx
    81ac:      	addq	$0x4, %rdi
    81b0:      	cmpq	%rbx, %rax
    81b3:      	jne	0x8144 <generic_kprobe_filter_arg+0x12c4>
    81b5:      	movl	$0x1, %eax
    81ba:      	movq	0x20(%rsp), %rdi
    81bf:      	movq	0x60(%rsp), %rsi
    81c4:      	jmp	0x8968 <generic_kprobe_filter_arg+0x1ae8>
    81c9:      	movl	0x10(%r13), %esi
    81cd:      	movl	0x14(%r13), %eax
    81d1:      	cmpl	$0xc, %ecx
    81d4:      	ja	0x8e1a <generic_kprobe_filter_arg+0x1f9a>
    81da:      	movl	$0x1402, %edx           # imm = 0x1402
    81df:      	btl	%ecx, %edx
    81e2:      	jae	0x8e1a <generic_kprobe_filter_arg+0x1f9a>
    81e8:      	movl	(%r12), %edx
    81ec:      	cmpl	%edx, %esi
    81ee:      	setle	%sil
    81f2:      	cmpl	%eax, %edx
    81f4:      	setle	%al
    81f7:      	jmp	0x8e29 <generic_kprobe_filter_arg+0x1fa9>
    81fc:      	cmpl	$0x1c, %eax
    81ff:      	je	0x884a <generic_kprobe_filter_arg+0x19ca>
    8205:      	movq	%r8, 0x18(%rsp)
    820a:      	movq	%rsi, %r12
    820d:      	cmpl	$0x1a, %eax
    8210:      	je	0x87b2 <generic_kprobe_filter_arg+0x1932>
    8216:      	jmp	0x6f9d <generic_kprobe_filter_arg+0x11d>
    821b:      	cmpl	$0x12, %eax
    821e:      	je	0x8239 <generic_kprobe_filter_arg+0x13b9>
    8220:      	movl	$0x0, %ebx
    8225:      	cmpl	$0x13, %eax
    8228:      	jne	0x7150 <generic_kprobe_filter_arg+0x2d0>
    822e:      	movq	%r12, %rdx
    8231:      	movzwl	0x22(%r12), %r12d
    8237:      	jmp	0x8242 <generic_kprobe_filter_arg+0x13c2>
    8239:      	movq	%r12, %rdx
    823c:      	movzwl	0x20(%r12), %r12d
    8242:      	xorl	%esi, %esi
    8244:      	xorl	%ebp, %ebp
    8246:      	xorl	%r8d, %r8d
    8249:      	xorl	%ebx, %ebx
    824b:      	cmpl	$0x11, %eax
    824e:      	jg	0x82da <generic_kprobe_filter_arg+0x145a>
    8254:      	leal	-0xd(%rax), %ecx
    8257:      	cmpl	$0x2, %ecx
    825a:      	jb	0x830d <generic_kprobe_filter_arg+0x148d>
    8260:      	leal	-0xf(%rax), %ecx
    8263:      	cmpl	$0x2, %ecx
    8266:      	jb	0x8440 <generic_kprobe_filter_arg+0x15c0>
    826c:      	cmpl	$0x11, %eax
    826f:      	je	0x8a32 <generic_kprobe_filter_arg+0x1bb2>
    8275:      	jmp	0x7150 <generic_kprobe_filter_arg+0x2d0>
    827a:      	cmpl	$0x1c, %eax
    827d:      	je	0x8a2c <generic_kprobe_filter_arg+0x1bac>
    8283:      	movl	$0x0, %ebx
    8288:      	cmpl	$0x1d, %eax
    828b:      	jne	0x7150 <generic_kprobe_filter_arg+0x2d0>
    8291:      	cmpl	$0x7, %ecx
    8294:      	jne	0x8fc8 <generic_kprobe_filter_arg+0x2148>
    829a:      	testq	%rdx, %rdx
    829d:      	jne	0x8fd4 <generic_kprobe_filter_arg+0x2154>
    82a3:      	xorl	%ebx, %ebx
    82a5:      	jmp	0x8fe6 <generic_kprobe_filter_arg+0x2166>
    82aa:      	movq	0x10(%r12), %rsi
    82af:      	movq	%r12, %rdx
    82b2:      	movq	0x18(%r12), %r8
    82b7:      	jmp	0x82c5 <generic_kprobe_filter_arg+0x1445>
    82b9:      	movq	(%r12), %rsi
    82bd:      	movq	%r12, %rdx
    82c0:      	movq	0x8(%r12), %r8
    82c5:      	movq	%rsi, %rbp
    82c8:      	shrq	$0x20, %rbp
    82cc:      	xorl	%r12d, %r12d
    82cf:      	xorl	%ebx, %ebx
    82d1:      	cmpl	$0x11, %eax
    82d4:      	jle	0x8254 <generic_kprobe_filter_arg+0x13d4>
    82da:      	cmpl	$0x19, %eax
    82dd:      	ja	0x8434 <generic_kprobe_filter_arg+0x15b4>
    82e3:      	movl	$0x500000, %ecx         # imm = 0x500000
    82e8:      	btl	%eax, %ecx
    82eb:      	jb	0x8583 <generic_kprobe_filter_arg+0x1703>
    82f1:      	movl	$0xa00000, %ecx         # imm = 0xA00000
    82f6:      	btl	%eax, %ecx
    82f9:      	jb	0x8596 <generic_kprobe_filter_arg+0x1716>
    82ff:      	movl	$0x3000000, %ecx        # imm = 0x3000000
    8304:      	btl	%eax, %ecx
    8307:      	jae	0x8434 <generic_kprobe_filter_arg+0x15b4>
    830d:      	movzwl	0x26(%rdx), %eax
    8311:      	cmpl	$0xa, %eax
    8314:      	je	0x862b <generic_kprobe_filter_arg+0x17ab>
    831a:      	cmpl	$0x2, %eax
    831d:      	jne	0x86bd <generic_kprobe_filter_arg+0x183d>
    8323:      	movq	%rsi, %r12
    8326:      	movq	%r11, 0x10(%rsp)
    832b:      	movl	0x10(%r13), %eax
    832f:      	movl	%eax, 0x34(%rsp)
    8333:      	movl	$0x1, %eax
    8338:      	leaq	0x34(%rsp), %rsi
    833d:      	movq	(%rip), %rdi            # 0x8344 <generic_kprobe_filter_arg+0x14c4>
    8344:      	callq	*%rax
    8346:      	testq	%rax, %rax
    8349:      	je	0x8ae9 <generic_kprobe_filter_arg+0x1c69>
    834f:      	movq	%rax, %rdi
    8352:      	movl	$0x20, 0x70(%rsp)
    835a:      	movl	%r12d, 0x74(%rsp)
    835f:      	jmp	0x867d <generic_kprobe_filter_arg+0x17fd>
    8364:      	cmpl	$0xc, %ecx
    8367:      	ja	0x9091 <generic_kprobe_filter_arg+0x2211>
    836d:      	movl	$0x1402, %esi           # imm = 0x1402
    8372:      	btl	%ecx, %esi
    8375:      	jae	0x9091 <generic_kprobe_filter_arg+0x2211>
    837b:      	cmpl	%edx, (%r12)
    837f:      	jg	0x7161 <generic_kprobe_filter_arg+0x2e1>
    8385:      	jmp	0x90a7 <generic_kprobe_filter_arg+0x2227>
    838a:      	xorl	%ebx, %ebx
    838c:      	xorl	%r12d, %r12d
    838f:      	movq	%r11, %r15
    8392:      	movl	0x10(%r13,%rbx,4), %eax
    8397:      	movl	%eax, 0x38(%rsp)
    839b:      	movl	$0x1, %eax
    83a0:      	leaq	0x38(%rsp), %rsi
    83a5:      	movq	(%rip), %rdi            # 0x83ac <generic_kprobe_filter_arg+0x152c>
    83ac:      	callq	*%rax
    83ae:      	testq	%rax, %rax
    83b1:      	je	0x8f14 <generic_kprobe_filter_arg+0x2094>
    83b7:      	testl	%ebp, %ebp
    83b9:      	movq	0x8(%rsp), %r9
    83be:      	movq	%r15, %r11
    83c1:      	movq	0x68(%rsp), %r15
    83c6:      	je	0x840f <generic_kprobe_filter_arg+0x158f>
    83c8:      	movq	0x18(%rsp), %rdx
    83cd:      	xorl	%ecx, %ecx
    83cf:      	jmp	0x83dc <generic_kprobe_filter_arg+0x155c>
    83d1:      	incq	%rcx
    83d4:      	incq	%rdx
    83d7:      	cmpq	%rbp, %rcx
    83da:      	je	0x840f <generic_kprobe_filter_arg+0x158f>
    83dc:      	xorl	%esi, %esi
    83de:      	nop
    83e0:      	leaq	(%rcx,%rsi), %rdi
    83e4:      	cmpq	%rbp, %rdi
    83e7:      	jae	0x83d1 <generic_kprobe_filter_arg+0x1551>
    83e9:      	movzbl	(%rax,%rsi), %edi
    83ed:      	testb	%dil, %dil
    83f0:      	je	0x8407 <generic_kprobe_filter_arg+0x1587>
    83f2:      	cmpq	$0x62, %rsi
    83f6:      	ja	0x83d1 <generic_kprobe_filter_arg+0x1551>
    83f8:      	leaq	0x1(%rsi), %r8
    83fc:      	cmpb	%dil, (%rdx,%rsi)
    8400:      	movq	%r8, %rsi
    8403:      	je	0x83e0 <generic_kprobe_filter_arg+0x1560>
    8405:      	jmp	0x83d1 <generic_kprobe_filter_arg+0x1551>
    8407:      	testl	%ecx, %ecx
    8409:      	jns	0x919a <generic_kprobe_filter_arg+0x231a>
    840f:      	leal	0xc(%r12), %eax
    8414:      	cmpl	0x8(%r13), %eax
    8418:      	jae	0x9d17 <generic_kprobe_filter_arg+0x2e97>
    841e:      	addl	$0x4, %r12d
    8422:      	incq	%rbx
    8425:      	cmpq	$0x64, %rbx
    8429:      	jne	0x838f <generic_kprobe_filter_arg+0x150f>
    842f:      	jmp	0x9d17 <generic_kprobe_filter_arg+0x2e97>
    8434:      	addl	$-0x12, %eax
    8437:      	cmpl	$0x2, %eax
    843a:      	jae	0x7150 <generic_kprobe_filter_arg+0x2d0>
    8440:      	movq	%r11, %rbp
    8443:      	movzbl	0x10(%r13), %eax
    8448:      	movl	%eax, 0x34(%rsp)
    844c:      	movl	$0x1, %eax
    8451:      	movq	(%rip), %rdi            # 0x8458 <generic_kprobe_filter_arg+0x15d8>
    8458:      	leaq	0x34(%rsp), %rsi
    845d:      	callq	*%rax
    845f:      	testq	%rax, %rax
    8462:      	je	0x88be <generic_kprobe_filter_arg+0x1a3e>
    8468:      	movq	%rax, %rdi
    846b:      	movzwl	%r12w, %eax
    846f:      	movq	%rax, 0x70(%rsp)
    8474:      	movl	$0x1, %eax
    8479:      	movq	0x28(%rsp), %rsi
    847e:      	jmp	0x8885 <generic_kprobe_filter_arg+0x1a05>
    8483:      	leal	-0x100(%rbx), %eax
    8489:      	rorxl	$0x8, %eax, %eax
    848f:      	cmpl	$0x2, %eax
    8492:      	jg	0x8c44 <generic_kprobe_filter_arg+0x1dc4>
    8498:      	testl	%eax, %eax
    849a:      	je	0x935d <generic_kprobe_filter_arg+0x24dd>
    84a0:      	cmpl	$0x1, %eax
    84a3:      	jne	0x9356 <generic_kprobe_filter_arg+0x24d6>
    84a9:      	movl	$0x7, %eax
    84ae:      	jmp	0x9369 <generic_kprobe_filter_arg+0x24e9>
    84b3:      	cmpl	$0x1, %eax
    84b6:      	je	0x8d39 <generic_kprobe_filter_arg+0x1eb9>
    84bc:      	cmpl	$0x2, %eax
    84bf:      	jne	0x8d46 <generic_kprobe_filter_arg+0x1ec6>
    84c5:      	movzbl	(%r12), %edx
    84ca:      	cmpl	%edx, %ecx
    84cc:      	ja	0x7161 <generic_kprobe_filter_arg+0x2e1>
    84d2:      	jmp	0x8d46 <generic_kprobe_filter_arg+0x1ec6>
    84d7:      	cmpl	$0x1, %eax
    84da:      	je	0x8d7e <generic_kprobe_filter_arg+0x1efe>
    84e0:      	cmpl	$0x2, %eax
    84e3:      	jne	0x8d8b <generic_kprobe_filter_arg+0x1f0b>
    84e9:      	movzwl	(%r12), %edx
    84ee:      	cmpl	%edx, %ecx
    84f0:      	ja	0x7161 <generic_kprobe_filter_arg+0x2e1>
    84f6:      	jmp	0x8d8b <generic_kprobe_filter_arg+0x1f0b>
    84fb:      	movq	%r11, %rbp
    84fe:      	movzbl	0x10(%r13), %eax
    8503:      	movl	%eax, 0x70(%rsp)
    8507:      	movl	$0x1, %eax
    850c:      	movq	0x28(%rsp), %rsi
    8511:      	movq	(%rip), %rdi            # 0x8518 <generic_kprobe_filter_arg+0x1698>
    8518:      	callq	*%rax
    851a:      	testq	%rax, %rax
    851d:      	je	0x88be <generic_kprobe_filter_arg+0x1a3e>
    8523:      	movq	%rax, %rdi
    8526:      	movzbl	(%r12), %eax
    852b:      	movq	%rax, 0x38(%rsp)
    8530:      	movl	$0x1, %eax
    8535:      	leaq	0x38(%rsp), %rsi
    853a:      	jmp	0x8885 <generic_kprobe_filter_arg+0x1a05>
    853f:      	movq	%r11, %rbp
    8542:      	movzbl	0x10(%r13), %eax
    8547:      	movl	%eax, 0x70(%rsp)
    854b:      	movl	$0x1, %eax
    8550:      	movq	0x28(%rsp), %rsi
    8555:      	movq	(%rip), %rdi            # 0x855c <generic_kprobe_filter_arg+0x16dc>
    855c:      	callq	*%rax
    855e:      	testq	%rax, %rax
    8561:      	je	0x88be <generic_kprobe_filter_arg+0x1a3e>
    8567:      	movq	%rax, %rdi
    856a:      	movzwl	(%r12), %eax
    856f:      	movq	%rax, 0x38(%rsp)
    8574:      	movl	$0x1, %eax
    8579:      	leaq	0x38(%rsp), %rsi
    857e:      	jmp	0x8885 <generic_kprobe_filter_arg+0x1a05>
    8583:      	movzwl	%r12w, %eax
    8587:      	xorl	%ebx, %ebx
    8589:      	cmpl	$0x400, %eax            # imm = 0x400
    858e:      	setb	%bl
    8591:      	jmp	0x7150 <generic_kprobe_filter_arg+0x2d0>
    8596:      	movzwl	%r12w, %eax
    859a:      	xorl	%ebx, %ebx
    859c:      	cmpl	$0x400, %eax            # imm = 0x400
    85a1:      	setae	%bl
    85a4:      	jmp	0x7150 <generic_kprobe_filter_arg+0x2d0>
    85a9:      	testq	%rax, %rax
    85ac:      	sete	%al
    85af:      	movq	(%rsp), %rdi
    85b3:      	movq	0x8(%rsp), %r9
    85b8:      	movq	%rbp, %r11
    85bb:      	movzbl	%al, %ebx
    85be:      	jmp	0x7150 <generic_kprobe_filter_arg+0x2d0>
    85c3:      	movl	$0x100, %esi            # imm = 0x100
    85c8:      	cmpl	$0x101, %eax            # imm = 0x101
    85cd:      	jb	0x85fb <generic_kprobe_filter_arg+0x177b>
    85cf:      	movl	$0x200, %esi            # imm = 0x200
    85d4:      	cmpl	$0x201, %eax            # imm = 0x201
    85d9:      	jb	0x85fb <generic_kprobe_filter_arg+0x177b>
    85db:      	movl	$0x400, %esi            # imm = 0x400
    85e0:      	cmpl	$0x401, %eax            # imm = 0x401
    85e5:      	jb	0x85fb <generic_kprobe_filter_arg+0x177b>
    85e7:      	xorl	%esi, %esi
    85e9:      	cmpl	$0x801, %eax            # imm = 0x801
    85ee:      	setae	%sil
    85f2:      	shll	$0xb, %esi
    85f5:      	addl	$0x800, %esi            # imm = 0x800
    85fb:      	leal	-0x100(%rsi), %eax
    8601:      	rorxl	$0x8, %eax, %eax
    8607:      	cmpl	$0x2, %eax
    860a:      	jg	0x8af8 <generic_kprobe_filter_arg+0x1c78>
    8610:      	testl	%eax, %eax
    8612:      	je	0x91c3 <generic_kprobe_filter_arg+0x2343>
    8618:      	cmpl	$0x1, %eax
    861b:      	jne	0x91bc <generic_kprobe_filter_arg+0x233c>
    8621:      	movl	$0x7, %eax
    8626:      	jmp	0x91cf <generic_kprobe_filter_arg+0x234f>
    862b:      	movq	%r8, %rbx
    862e:      	movq	%rsi, %r12
    8631:      	movq	%r11, 0x10(%rsp)
    8636:      	movl	0x14(%r13), %eax
    863a:      	movl	%eax, 0x34(%rsp)
    863e:      	movl	$0x1, %eax
    8643:      	movq	(%rip), %rdi            # 0x864a <generic_kprobe_filter_arg+0x17ca>
    864a:      	leaq	0x34(%rsp), %rsi
    864f:      	callq	*%rax
    8651:      	testq	%rax, %rax
    8654:      	je	0x8ae9 <generic_kprobe_filter_arg+0x1c69>
    865a:      	movq	%rax, %rdi
    865d:      	movl	$0x80, 0x70(%rsp)
    8665:      	movl	%r12d, 0x74(%rsp)
    866a:      	movl	%ebp, 0x78(%rsp)
    866e:      	movl	%ebx, 0x7c(%rsp)
    8672:      	shrq	$0x20, %rbx
    8676:      	movl	%ebx, 0x80(%rsp)
    867d:      	movl	$0x1, %eax
    8682:      	movq	0x28(%rsp), %rsi
    8687:      	callq	*%rax
    8689:      	movl	0x4(%r13), %ecx
    868d:      	leal	-0x18(%rcx), %edx
    8690:      	cmpl	$0x2, %edx
    8693:      	jb	0x8d01 <generic_kprobe_filter_arg+0x1e81>
    8699:      	addl	$-0xd, %ecx
    869c:      	cmpl	$0x1, %ecx
    869f:      	movq	(%rsp), %rdi
    86a3:      	movq	0x8(%rsp), %r9
    86a8:      	movq	0x10(%rsp), %r11
    86ad:      	ja	0x86bd <generic_kprobe_filter_arg+0x183d>
    86af:      	testq	%rax, %rax
    86b2:      	setne	%al
    86b5:      	movzbl	%al, %ebx
    86b8:      	jmp	0x7150 <generic_kprobe_filter_arg+0x2d0>
    86bd:      	xorl	%eax, %eax
    86bf:      	movzbl	%al, %ebx
    86c2:      	jmp	0x7150 <generic_kprobe_filter_arg+0x2d0>
    86c7:      	cmpl	$0x1e, %eax
    86ca:      	jne	0x6f9d <generic_kprobe_filter_arg+0x11d>
    86d0:      	movl	0x10(%r13), %eax
    86d4:      	andl	$0x7, %eax
    86d7:      	movl	%eax, %ecx
    86d9:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
    86e2:      	jne	0x6f9d <generic_kprobe_filter_arg+0x11d>
    86e8:      	movq	(%r12), %rcx
    86ec:      	movq	0x5e78(%r14,%rax,8), %rax
    86f4:      	andl	$0x7ff, %eax            # imm = 0x7FF
    86f9:      	xorl	%ebx, %ebx
    86fb:      	andnq	0x90(%r14,%rax), %rcx, %rax
    8705:      	setne	%bl
    8708:      	jmp	0x7150 <generic_kprobe_filter_arg+0x2d0>
    870d:      	cmpl	$0x21, %eax
    8710:      	je	0x8e6c <generic_kprobe_filter_arg+0x1fec>
    8716:      	movl	$0x0, %ebx
    871b:      	cmpl	$0x22, %eax
    871e:      	jne	0xa4bb <generic_kprobe_filter_arg+0x363b>
    8724:      	movl	$0x10, %r12d
    872a:      	movq	%r11, %r15
    872d:      	movl	(%r13,%r12), %eax
    8732:      	movl	%eax, 0x38(%rsp)
    8736:      	movl	$0x1, %eax
    873b:      	leaq	0x38(%rsp), %rsi
    8740:      	movq	(%rip), %rdi            # 0x8747 <generic_kprobe_filter_arg+0x18c7>
    8747:      	callq	*%rax
    8749:      	testq	%rax, %rax
    874c:      	je	0x9b04 <generic_kprobe_filter_arg+0x2c84>
    8752:      	movq	0x18(%rsp), %rdi
    8757:      	movq	%rax, %rsi
    875a:      	movq	%rbp, %rdx
    875d:      	callq	0x8762 <generic_kprobe_filter_arg+0x18e2>
    8762:      	testl	%eax, %eax
    8764:      	jns	0x9b08 <generic_kprobe_filter_arg+0x2c88>
    876a:      	addq	$0x4, %r12
    876e:      	leal	-0x8(%r12), %eax
    8773:      	cmpl	0x8(%r13), %eax
    8777:      	movq	(%rsp), %rdi
    877b:      	movq	0x8(%rsp), %r9
    8780:      	movq	%r15, %r11
    8783:      	jae	0x9c3d <generic_kprobe_filter_arg+0x2dbd>
    8789:      	movl	$0x0, %ebx
    878e:      	cmpq	$0x1a0, %r12            # imm = 0x1A0
    8795:      	movq	0x68(%rsp), %r15
    879a:      	jne	0x872a <generic_kprobe_filter_arg+0x18aa>
    879c:      	jmp	0xa4bb <generic_kprobe_filter_arg+0x363b>
    87a1:      	movq	%r8, 0x18(%rsp)
    87a6:      	movq	%rsi, %r12
    87a9:      	cmpl	$0x8, %eax
    87ac:      	jne	0x6f9d <generic_kprobe_filter_arg+0x11d>
    87b2:      	movq	%r11, 0x10(%rsp)
    87b7:      	movl	0x10(%r13), %eax
    87bb:      	movl	%eax, 0x38(%rsp)
    87bf:      	movl	$0x0, 0x70(%rsp)
    87c7:      	movl	$0x1, %eax
    87cc:      	leaq	0x38(%rsp), %rsi
    87d1:      	movq	(%rip), %rdi            # 0x87d8 <generic_kprobe_filter_arg+0x1958>
    87d8:      	callq	*%rax
    87da:      	testb	%bpl, %bpl
    87dd:      	je	0x8ab2 <generic_kprobe_filter_arg+0x1c32>
    87e3:      	movl	$0x0, %ebx
    87e8:      	testq	%rax, %rax
    87eb:      	je	0x8ab4 <generic_kprobe_filter_arg+0x1c34>
    87f1:      	movq	%rax, %rbp
    87f4:      	movl	$0x1, %eax
    87f9:      	movq	0x28(%rsp), %rsi
    87fe:      	movq	(%rip), %rdi            # 0x8805 <generic_kprobe_filter_arg+0x1985>
    8805:      	callq	*%rax
    8807:      	testq	%rax, %rax
    880a:      	je	0x8ab2 <generic_kprobe_filter_arg+0x1c32>
    8810:      	movq	%r12, %rsi
    8813:      	movl	%esi, %ecx
    8815:      	shll	$0x3, %ecx
    8818:      	movl	%ecx, (%rax)
    881a:      	movq	%rax, %rdi
    881d:      	addq	$0x4, %rdi
    8821:      	movq	%rax, %rbx
    8824:      	movl	$0x4, %eax
    8829:      	movq	0x18(%rsp), %rdx
    882e:      	callq	*%rax
    8830:      	movl	$0x1, %eax
    8835:      	movq	%rbp, %rdi
    8838:      	movq	%rbx, %rsi
    883b:      	callq	*%rax
    883d:      	xorl	%ebx, %ebx
    883f:      	testq	%rax, %rax
    8842:      	setne	%bl
    8845:      	jmp	0x8ab4 <generic_kprobe_filter_arg+0x1c34>
    884a:      	movq	%r11, %rbp
    884d:      	movzwl	(%r12), %ebx
    8852:      	movzbl	0x10(%r13), %eax
    8857:      	movl	%eax, 0x70(%rsp)
    885b:      	movl	$0x1, %eax
    8860:      	movq	0x28(%rsp), %rsi
    8865:      	movq	(%rip), %rdi            # 0x886c <generic_kprobe_filter_arg+0x19ec>
    886c:      	callq	*%rax
    886e:      	testq	%rax, %rax
    8871:      	je	0x88be <generic_kprobe_filter_arg+0x1a3e>
    8873:      	movq	%rax, %rdi
    8876:      	movq	%rbx, 0x38(%rsp)
    887b:      	movl	$0x1, %eax
    8880:      	leaq	0x38(%rsp), %rsi
    8885:      	callq	*%rax
    8887:      	movl	0x4(%r13), %edx
    888b:      	xorl	%ecx, %ecx
    888d:      	cmpl	$0x1d, %edx
    8890:      	ja	0x91a8 <generic_kprobe_filter_arg+0x2328>
    8896:      	movl	$0x30038400, %esi       # imm = 0x30038400
    889b:      	btl	%edx, %esi
    889e:      	movq	(%rsp), %rdi
    88a2:      	movq	0x8(%rsp), %r9
    88a7:      	movq	%rbp, %r11
    88aa:      	jae	0x8a9a <generic_kprobe_filter_arg+0x1c1a>
    88b0:      	testq	%rax, %rax
    88b3:      	setne	%cl
    88b6:      	movzbl	%cl, %ebx
    88b9:      	jmp	0x7150 <generic_kprobe_filter_arg+0x2d0>
    88be:      	xorl	%ebx, %ebx
    88c0:      	movq	(%rsp), %rdi
    88c4:      	movq	0x8(%rsp), %r9
    88c9:      	movq	%rbp, %r11
    88cc:      	jmp	0x7150 <generic_kprobe_filter_arg+0x2d0>
    88d1:      	movq	%r11, 0x10(%rsp)
    88d6:      	movl	0x10(%r13), %eax
    88da:      	movl	%eax, 0x38(%rsp)
    88de:      	movl	$0x0, 0x70(%rsp)
    88e6:      	movl	$0x1, %eax
    88eb:      	leaq	0x38(%rsp), %rsi
    88f0:      	movq	(%rip), %rdi            # 0x88f7 <generic_kprobe_filter_arg+0x1a77>
    88f7:      	callq	*%rax
    88f9:      	testl	%ebp, %ebp
    88fb:      	je	0xa4ab <generic_kprobe_filter_arg+0x362b>
    8901:      	movq	%rax, %r12
    8904:      	movl	$0x0, %ebx
    8909:      	testq	%rax, %rax
    890c:      	je	0xa4ad <generic_kprobe_filter_arg+0x362d>
    8912:      	movl	$0x1, %eax
    8917:      	movq	0x28(%rsp), %rsi
    891c:      	movq	(%rip), %rdi            # 0x8923 <generic_kprobe_filter_arg+0x1aa3>
    8923:      	callq	*%rax
    8925:      	testq	%rax, %rax
    8928:      	je	0xa4ab <generic_kprobe_filter_arg+0x362b>
    892e:      	cmpl	$0xff, %ebp
    8934:      	movl	$0xff, %ecx
    8939:      	cmovael	%ecx, %ebp
    893c:      	leal	(,%rbp,8), %ecx
    8943:      	movl	%ecx, (%rax)
    8945:      	movq	%rax, %rdi
    8948:      	addq	$0x4, %rdi
    894c:      	movq	%rax, %rbx
    894f:      	movl	$0x4, %eax
    8954:      	movq	0x18(%rsp), %rdx
    8959:      	movl	%ebp, %esi
    895b:      	callq	*%rax
    895d:      	movl	$0x1, %eax
    8962:      	movq	%r12, %rdi
    8965:      	movq	%rbx, %rsi
    8968:      	callq	*%rax
    896a:      	xorl	%ebx, %ebx
    896c:      	testq	%rax, %rax
    896f:      	setne	%bl
    8972:      	jmp	0xa4ad <generic_kprobe_filter_arg+0x362d>
    8977:      	movl	$0x0, 0x70(%rsp)
    897f:      	cmpl	$0x1000, %ebp           # imm = 0x1000
    8985:      	jbe	0x8f2c <generic_kprobe_filter_arg+0x20ac>
    898b:      	xorl	%ebx, %ebx
    898d:      	jmp	0xa4bb <generic_kprobe_filter_arg+0x363b>
    8992:      	movq	(%r12), %rax
    8996:      	cmpq	%rax, %rsi
    8999:      	ja	0x89a4 <generic_kprobe_filter_arg+0x1b24>
    899b:      	cmpq	%rdx, %rax
    899e:      	jbe	0x7161 <generic_kprobe_filter_arg+0x2e1>
    89a4:      	movl	0x8(%r13), %edx
    89a8:      	cmpl	$0x19, %edx
    89ab:      	jb	0x6f9d <generic_kprobe_filter_arg+0x11d>
    89b1:      	movq	0x20(%r13), %rdi
    89b5:      	movq	0x28(%r13), %rsi
    89b9:      	cmpl	$0xc, %ecx
    89bc:      	je	0x89c7 <generic_kprobe_filter_arg+0x1b47>
    89be:      	cmpl	$0xa, %ecx
    89c1:      	jne	0x9045 <generic_kprobe_filter_arg+0x21c5>
    89c7:      	cmpq	%rax, %rdi
    89ca:      	movq	(%rsp), %rdi
    89ce:      	jg	0x9057 <generic_kprobe_filter_arg+0x21d7>
    89d4:      	cmpq	%rsi, %rax
    89d7:      	jle	0x7161 <generic_kprobe_filter_arg+0x2e1>
    89dd:      	jmp	0x9057 <generic_kprobe_filter_arg+0x21d7>
    89e2:      	movq	(%r12), %rdx
    89e6:      	cmpq	%rdx, %rsi
    89e9:      	setbe	%sil
    89ed:      	cmpq	%rax, %rdx
    89f0:      	setbe	%al
    89f3:      	andb	%sil, %al
    89f6:      	movl	0x8(%r13), %esi
    89fa:      	cmpl	$0x19, %esi
    89fd:      	jb	0x9ed0 <generic_kprobe_filter_arg+0x3050>
    8a03:      	movq	0x20(%r13), %r8
    8a07:      	movq	0x28(%r13), %rdi
    8a0b:      	cmpl	$0xc, %ecx
    8a0e:      	je	0x8a19 <generic_kprobe_filter_arg+0x1b99>
    8a10:      	cmpl	$0xa, %ecx
    8a13:      	jne	0x8f82 <generic_kprobe_filter_arg+0x2102>
    8a19:      	cmpq	%rdx, %r8
    8a1c:      	setle	%r8b
    8a20:      	cmpq	%rdi, %rdx
    8a23:      	setle	%dil
    8a27:      	jmp	0x8f90 <generic_kprobe_filter_arg+0x2110>
    8a2c:      	movzwl	0x26(%r12), %ebx
    8a32:      	movq	%r11, %r12
    8a35:      	movzbl	0x10(%r13), %eax
    8a3a:      	movl	%eax, 0x34(%rsp)
    8a3e:      	movl	$0x1, %eax
    8a43:      	movq	(%rip), %rdi            # 0x8a4a <generic_kprobe_filter_arg+0x1bca>
    8a4a:      	leaq	0x34(%rsp), %rsi
    8a4f:      	callq	*%rax
    8a51:      	testq	%rax, %rax
    8a54:      	je	0x9023 <generic_kprobe_filter_arg+0x21a3>
    8a5a:      	movq	%rax, %rdi
    8a5d:      	movzwl	%bx, %eax
    8a60:      	movq	%rax, 0x70(%rsp)
    8a65:      	movl	$0x1, %eax
    8a6a:      	movq	0x28(%rsp), %rsi
    8a6f:      	callq	*%rax
    8a71:      	movl	0x4(%r13), %edx
    8a75:      	xorl	%ecx, %ecx
    8a77:      	cmpl	$0x1d, %edx
    8a7a:      	ja	0x9c81 <generic_kprobe_filter_arg+0x2e01>
    8a80:      	movl	$0x30038400, %esi       # imm = 0x30038400
    8a85:      	btl	%edx, %esi
    8a88:      	movq	(%rsp), %rdi
    8a8c:      	movq	0x8(%rsp), %r9
    8a91:      	movq	%r12, %r11
    8a94:      	jb	0x88b0 <generic_kprobe_filter_arg+0x1a30>
    8a9a:      	movl	$0xc0800, %esi          # imm = 0xC0800
    8a9f:      	btl	%edx, %esi
    8aa2:      	jae	0x8aaa <generic_kprobe_filter_arg+0x1c2a>
    8aa4:      	testq	%rax, %rax
    8aa7:      	sete	%cl
    8aaa:      	movzbl	%cl, %ebx
    8aad:      	jmp	0x7150 <generic_kprobe_filter_arg+0x2d0>
    8ab2:      	xorl	%ebx, %ebx
    8ab4:      	movl	0x4(%r13), %eax
    8ab8:      	cmpq	$0x25, %rax
    8abc:      	ja	0x99af <generic_kprobe_filter_arg+0x2b2f>
    8ac2:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    8acc:      	btq	%rax, %rcx
    8ad0:      	movq	(%rsp), %rdi
    8ad4:      	movq	0x8(%rsp), %r9
    8ad9:      	movq	0x10(%rsp), %r11
    8ade:      	jb	0xa145 <generic_kprobe_filter_arg+0x32c5>
    8ae4:      	jmp	0x7150 <generic_kprobe_filter_arg+0x2d0>
    8ae9:      	movl	0x4(%r13), %eax
    8aed:      	andl	$-0x2, %eax
    8af0:      	cmpl	$0x18, %eax
    8af3:      	jmp	0x8d04 <generic_kprobe_filter_arg+0x1e84>
    8af8:      	cmpl	$0x3, %eax
    8afb:      	je	0x91ca <generic_kprobe_filter_arg+0x234a>
    8b01:      	cmpl	$0x7, %eax
    8b04:      	jne	0x91bc <generic_kprobe_filter_arg+0x233c>
    8b0a:      	movl	$0x9, %eax
    8b0f:      	jmp	0x91cf <generic_kprobe_filter_arg+0x234f>
    8b14:      	movl	$0x100, %esi            # imm = 0x100
    8b19:      	cmpl	$0x101, %eax            # imm = 0x101
    8b1e:      	jb	0x8b4c <generic_kprobe_filter_arg+0x1ccc>
    8b20:      	movl	$0x200, %esi            # imm = 0x200
    8b25:      	cmpl	$0x201, %eax            # imm = 0x201
    8b2a:      	jb	0x8b4c <generic_kprobe_filter_arg+0x1ccc>
    8b2c:      	movl	$0x400, %esi            # imm = 0x400
    8b31:      	cmpl	$0x401, %eax            # imm = 0x401
    8b36:      	jb	0x8b4c <generic_kprobe_filter_arg+0x1ccc>
    8b38:      	xorl	%esi, %esi
    8b3a:      	cmpl	$0x801, %eax            # imm = 0x801
    8b3f:      	setae	%sil
    8b43:      	shll	$0xb, %esi
    8b46:      	addl	$0x800, %esi            # imm = 0x800
    8b4c:      	leal	-0x100(%rsi), %eax
    8b52:      	rorxl	$0x8, %eax, %eax
    8b58:      	cmpl	$0x2, %eax
    8b5b:      	jg	0x8d1d <generic_kprobe_filter_arg+0x1e9d>
    8b61:      	testl	%eax, %eax
    8b63:      	je	0x9750 <generic_kprobe_filter_arg+0x28d0>
    8b69:      	cmpl	$0x1, %eax
    8b6c:      	jne	0x9749 <generic_kprobe_filter_arg+0x28c9>
    8b72:      	movl	$0x7, %eax
    8b77:      	jmp	0x975c <generic_kprobe_filter_arg+0x28dc>
    8b7c:      	cmpq	%rdx, (%r12)
    8b80:      	ja	0x7161 <generic_kprobe_filter_arg+0x2e1>
    8b86:      	jmp	0x8b92 <generic_kprobe_filter_arg+0x1d12>
    8b88:      	cmpq	%rdx, (%r12)
    8b8c:      	jb	0x7161 <generic_kprobe_filter_arg+0x2e1>
    8b92:      	movl	0x8(%r13), %edx
    8b96:      	cmpl	$0x11, %edx
    8b99:      	jb	0xa541 <generic_kprobe_filter_arg+0x36c1>
    8b9f:      	movq	0x18(%r13), %rsi
    8ba3:      	cmpl	$0x2, %eax
    8ba6:      	jle	0x8bc3 <generic_kprobe_filter_arg+0x1d43>
    8ba8:      	leal	-0x3(%rax), %edi
    8bab:      	cmpl	$0x2, %edi
    8bae:      	jae	0x8bf2 <generic_kprobe_filter_arg+0x1d72>
    8bb0:      	cmpq	%rsi, (%r12)
    8bb4:      	movq	(%rsp), %rdi
    8bb8:      	je	0x7145 <generic_kprobe_filter_arg+0x2c5>
    8bbe:      	jmp	0x96d1 <generic_kprobe_filter_arg+0x2851>
    8bc3:      	cmpl	$0x1, %eax
    8bc6:      	je	0x8c60 <generic_kprobe_filter_arg+0x1de0>
    8bcc:      	cmpl	$0x2, %eax
    8bcf:      	jne	0x96d1 <generic_kprobe_filter_arg+0x2851>
    8bd5:      	cmpl	$0xc, %ecx
    8bd8:      	je	0x8be3 <generic_kprobe_filter_arg+0x1d63>
    8bda:      	cmpl	$0xa, %ecx
    8bdd:      	jne	0x96c7 <generic_kprobe_filter_arg+0x2847>
    8be3:      	cmpq	%rsi, (%r12)
    8be7:      	jl	0x7161 <generic_kprobe_filter_arg+0x2e1>
    8bed:      	jmp	0x96d1 <generic_kprobe_filter_arg+0x2851>
    8bf2:      	cmpl	$0xc, %eax
    8bf5:      	movq	(%rsp), %rdi
    8bf9:      	jne	0x96d1 <generic_kprobe_filter_arg+0x2851>
    8bff:      	testq	%rsi, (%r12)
    8c03:      	jne	0x7161 <generic_kprobe_filter_arg+0x2e1>
    8c09:      	jmp	0x96d1 <generic_kprobe_filter_arg+0x2851>
    8c0e:      	cmpl	$0xc, %eax
    8c11:      	jne	0x8d46 <generic_kprobe_filter_arg+0x1ec6>
    8c17:      	movzbl	(%r12), %edx
    8c1c:      	testl	%edx, %ecx
    8c1e:      	jne	0x7161 <generic_kprobe_filter_arg+0x2e1>
    8c24:      	jmp	0x8d46 <generic_kprobe_filter_arg+0x1ec6>
    8c29:      	cmpl	$0xc, %eax
    8c2c:      	jne	0x8d8b <generic_kprobe_filter_arg+0x1f0b>
    8c32:      	movzwl	(%r12), %edx
    8c37:      	testl	%edx, %ecx
    8c39:      	jne	0x7161 <generic_kprobe_filter_arg+0x2e1>
    8c3f:      	jmp	0x8d8b <generic_kprobe_filter_arg+0x1f0b>
    8c44:      	cmpl	$0x3, %eax
    8c47:      	je	0x9364 <generic_kprobe_filter_arg+0x24e4>
    8c4d:      	cmpl	$0x7, %eax
    8c50:      	jne	0x9356 <generic_kprobe_filter_arg+0x24d6>
    8c56:      	movl	$0x9, %eax
    8c5b:      	jmp	0x9369 <generic_kprobe_filter_arg+0x24e9>
    8c60:      	cmpl	$0xc, %ecx
    8c63:      	je	0x8c6e <generic_kprobe_filter_arg+0x1dee>
    8c65:      	cmpl	$0xa, %ecx
    8c68:      	jne	0x96bb <generic_kprobe_filter_arg+0x283b>
    8c6e:      	cmpq	%rsi, (%r12)
    8c72:      	jg	0x7161 <generic_kprobe_filter_arg+0x2e1>
    8c78:      	jmp	0x96d1 <generic_kprobe_filter_arg+0x2851>
    8c7d:      	movl	0x8(%r13), %edx
    8c81:      	movzbl	(%r12), %ecx
    8c86:      	jmp	0x8c91 <generic_kprobe_filter_arg+0x1e11>
    8c88:      	movl	0x8(%r13), %edx
    8c8c:      	movzwl	(%r12), %ecx
    8c91:      	cmpl	%ecx, 0x10(%r13)
    8c95:      	setbe	%sil
    8c99:      	cmpl	%ecx, 0x14(%r13)
    8c9d:      	setae	%al
    8ca0:      	andb	%sil, %al
    8ca3:      	cmpl	$0x11, %edx
    8ca6:      	jb	0x9ed0 <generic_kprobe_filter_arg+0x3050>
    8cac:      	cmpl	%ecx, 0x18(%r13)
    8cb0:      	setbe	%sil
    8cb4:      	cmpl	%ecx, 0x1c(%r13)
    8cb8:      	setae	%dil
    8cbc:      	andb	%sil, %dil
    8cbf:      	orb	%dil, %al
    8cc2:      	cmpl	$0x19, %edx
    8cc5:      	jb	0x9ecc <generic_kprobe_filter_arg+0x304c>
    8ccb:      	cmpl	%ecx, 0x20(%r13)
    8ccf:      	setbe	%sil
    8cd3:      	cmpl	%ecx, 0x24(%r13)
    8cd7:      	setae	%dil
    8cdb:      	andb	%sil, %dil
    8cde:      	orb	%dil, %al
    8ce1:      	cmpl	$0x21, %edx
    8ce4:      	jb	0x9ecc <generic_kprobe_filter_arg+0x304c>
    8cea:      	cmpl	%ecx, 0x28(%r13)
    8cee:      	setbe	%dl
    8cf1:      	cmpl	%ecx, 0x2c(%r13)
    8cf5:      	setae	%cl
    8cf8:      	andb	%dl, %cl
    8cfa:      	orb	%cl, %al
    8cfc:      	jmp	0x9ecc <generic_kprobe_filter_arg+0x304c>
    8d01:      	testq	%rax, %rax
    8d04:      	sete	%al
    8d07:      	movq	(%rsp), %rdi
    8d0b:      	movq	0x8(%rsp), %r9
    8d10:      	movq	0x10(%rsp), %r11
    8d15:      	movzbl	%al, %ebx
    8d18:      	jmp	0x7150 <generic_kprobe_filter_arg+0x2d0>
    8d1d:      	cmpl	$0x3, %eax
    8d20:      	je	0x9757 <generic_kprobe_filter_arg+0x28d7>
    8d26:      	cmpl	$0x7, %eax
    8d29:      	jne	0x9749 <generic_kprobe_filter_arg+0x28c9>
    8d2f:      	movl	$0x9, %eax
    8d34:      	jmp	0x975c <generic_kprobe_filter_arg+0x28dc>
    8d39:      	movzbl	(%r12), %edx
    8d3e:      	cmpl	%edx, %ecx
    8d40:      	jb	0x7161 <generic_kprobe_filter_arg+0x2e1>
    8d46:      	movl	0x8(%r13), %ecx
    8d4a:      	cmpl	$0xd, %ecx
    8d4d:      	jb	0xa541 <generic_kprobe_filter_arg+0x36c1>
    8d53:      	movl	0x14(%r13), %edx
    8d57:      	cmpl	$0x2, %eax
    8d5a:      	jle	0x9152 <generic_kprobe_filter_arg+0x22d2>
    8d60:      	leal	-0x3(%rax), %esi
    8d63:      	cmpl	$0x2, %esi
    8d66:      	jae	0x98fa <generic_kprobe_filter_arg+0x2a7a>
    8d6c:      	movzbl	(%r12), %esi
    8d71:      	cmpl	%esi, %edx
    8d73:      	je	0x7145 <generic_kprobe_filter_arg+0x2c5>
    8d79:      	jmp	0x99eb <generic_kprobe_filter_arg+0x2b6b>
    8d7e:      	movzwl	(%r12), %edx
    8d83:      	cmpl	%edx, %ecx
    8d85:      	jb	0x7161 <generic_kprobe_filter_arg+0x2e1>
    8d8b:      	movl	0x8(%r13), %ecx
    8d8f:      	cmpl	$0xd, %ecx
    8d92:      	jb	0xa541 <generic_kprobe_filter_arg+0x36c1>
    8d98:      	movl	0x14(%r13), %edx
    8d9c:      	cmpl	$0x2, %eax
    8d9f:      	jle	0x9176 <generic_kprobe_filter_arg+0x22f6>
    8da5:      	leal	-0x3(%rax), %esi
    8da8:      	cmpl	$0x2, %esi
    8dab:      	jae	0x9915 <generic_kprobe_filter_arg+0x2a95>
    8db1:      	movzwl	(%r12), %esi
    8db6:      	cmpl	%esi, %edx
    8db8:      	je	0x7145 <generic_kprobe_filter_arg+0x2c5>
    8dbe:      	jmp	0x9a2c <generic_kprobe_filter_arg+0x2bac>
    8dc3:      	movl	(%r12), %eax
    8dc7:      	cmpl	%eax, %esi
    8dc9:      	ja	0x8dd3 <generic_kprobe_filter_arg+0x1f53>
    8dcb:      	cmpl	%edx, %eax
    8dcd:      	jbe	0x7161 <generic_kprobe_filter_arg+0x2e1>
    8dd3:      	movl	0x8(%r13), %edx
    8dd7:      	cmpl	$0x11, %edx
    8dda:      	jb	0x6f9d <generic_kprobe_filter_arg+0x11d>
    8de0:      	movl	0x18(%r13), %edi
    8de4:      	movl	0x1c(%r13), %esi
    8de8:      	cmpl	$0xc, %ecx
    8deb:      	ja	0x9577 <generic_kprobe_filter_arg+0x26f7>
    8df1:      	movl	$0x1402, %r8d           # imm = 0x1402
    8df7:      	btl	%ecx, %r8d
    8dfb:      	jae	0x9577 <generic_kprobe_filter_arg+0x26f7>
    8e01:      	cmpl	%eax, %edi
    8e03:      	movq	(%rsp), %rdi
    8e07:      	jg	0x9587 <generic_kprobe_filter_arg+0x2707>
    8e0d:      	cmpl	%esi, %eax
    8e0f:      	jle	0x7161 <generic_kprobe_filter_arg+0x2e1>
    8e15:      	jmp	0x9587 <generic_kprobe_filter_arg+0x2707>
    8e1a:      	movl	(%r12), %edx
    8e1e:      	cmpl	%edx, %esi
    8e20:      	setbe	%sil
    8e24:      	cmpl	%eax, %edx
    8e26:      	setbe	%al
    8e29:      	andb	%sil, %al
    8e2c:      	movl	0x8(%r13), %esi
    8e30:      	cmpl	$0x11, %esi
    8e33:      	jb	0x9ed0 <generic_kprobe_filter_arg+0x3050>
    8e39:      	movl	0x18(%r13), %r8d
    8e3d:      	movl	0x1c(%r13), %edi
    8e41:      	cmpl	$0xc, %ecx
    8e44:      	ja	0x9521 <generic_kprobe_filter_arg+0x26a1>
    8e4a:      	movl	$0x1402, %r10d          # imm = 0x1402
    8e50:      	btl	%ecx, %r10d
    8e54:      	jae	0x9521 <generic_kprobe_filter_arg+0x26a1>
    8e5a:      	cmpl	%edx, %r8d
    8e5d:      	setle	%r8b
    8e61:      	cmpl	%edi, %edx
    8e63:      	setle	%dil
    8e67:      	jmp	0x952e <generic_kprobe_filter_arg+0x26ae>
    8e6c:      	xorl	%ebx, %ebx
    8e6e:      	xorl	%r12d, %r12d
    8e71:      	movq	%r11, %r15
    8e74:      	movl	0x10(%r13,%rbx,4), %eax
    8e79:      	movl	%eax, 0x38(%rsp)
    8e7d:      	movl	$0x1, %eax
    8e82:      	leaq	0x38(%rsp), %rsi
    8e87:      	movq	(%rip), %rdi            # 0x8e8e <generic_kprobe_filter_arg+0x200e>
    8e8e:      	callq	*%rax
    8e90:      	testq	%rax, %rax
    8e93:      	je	0x8f14 <generic_kprobe_filter_arg+0x2094>
    8e99:      	testl	%ebp, %ebp
    8e9b:      	movq	0x8(%rsp), %r9
    8ea0:      	movq	%r15, %r11
    8ea3:      	movq	0x68(%rsp), %r15
    8ea8:      	je	0x8eef <generic_kprobe_filter_arg+0x206f>
    8eaa:      	movq	0x18(%rsp), %rdx
    8eaf:      	xorl	%ecx, %ecx
    8eb1:      	jmp	0x8ebe <generic_kprobe_filter_arg+0x203e>
    8eb3:      	incq	%rcx
    8eb6:      	incq	%rdx
    8eb9:      	cmpq	%rbp, %rcx
    8ebc:      	je	0x8eef <generic_kprobe_filter_arg+0x206f>
    8ebe:      	xorl	%esi, %esi
    8ec0:      	leaq	(%rcx,%rsi), %rdi
    8ec4:      	cmpq	%rbp, %rdi
    8ec7:      	jae	0x8eb3 <generic_kprobe_filter_arg+0x2033>
    8ec9:      	movzbl	(%rax,%rsi), %edi
    8ecd:      	testb	%dil, %dil
    8ed0:      	je	0x8ee7 <generic_kprobe_filter_arg+0x2067>
    8ed2:      	cmpq	$0x62, %rsi
    8ed6:      	ja	0x8eb3 <generic_kprobe_filter_arg+0x2033>
    8ed8:      	leaq	0x1(%rsi), %r8
    8edc:      	cmpb	%dil, (%rdx,%rsi)
    8ee0:      	movq	%r8, %rsi
    8ee3:      	je	0x8ec0 <generic_kprobe_filter_arg+0x2040>
    8ee5:      	jmp	0x8eb3 <generic_kprobe_filter_arg+0x2033>
    8ee7:      	testl	%ecx, %ecx
    8ee9:      	jns	0x919a <generic_kprobe_filter_arg+0x231a>
    8eef:      	leal	0xc(%r12), %eax
    8ef4:      	cmpl	0x8(%r13), %eax
    8ef8:      	jae	0x9d17 <generic_kprobe_filter_arg+0x2e97>
    8efe:      	addl	$0x4, %r12d
    8f02:      	incq	%rbx
    8f05:      	cmpq	$0x64, %rbx
    8f09:      	jne	0x8e71 <generic_kprobe_filter_arg+0x1ff1>
    8f0f:      	jmp	0x9d17 <generic_kprobe_filter_arg+0x2e97>
    8f14:      	xorl	%ebx, %ebx
    8f16:      	movq	0x8(%rsp), %r9
    8f1b:      	movq	%r15, %r11
    8f1e:      	movq	0x68(%rsp), %r15
    8f23:      	movq	(%rsp), %rdi
    8f27:      	jmp	0xa4bb <generic_kprobe_filter_arg+0x363b>
    8f2c:      	movzwl	%bp, %eax
    8f2f:      	cmpl	$0x90, %eax
    8f34:      	movq	%r11, 0x10(%rsp)
    8f39:      	ja	0x95ca <generic_kprobe_filter_arg+0x274a>
    8f3f:      	testw	%bp, %bp
    8f42:      	je	0x8f54 <generic_kprobe_filter_arg+0x20d4>
    8f44:      	movl	%ebp, %eax
    8f46:      	movl	$0x18, %ecx
    8f4b:      	cltd
    8f4c:      	idivl	%ecx
    8f4e:      	movl	%ebp, %esi
    8f50:      	testl	%edx, %edx
    8f52:      	je	0x8f76 <generic_kprobe_filter_arg+0x20f6>
    8f54:      	movl	%ebp, %eax
    8f56:      	movl	$0x18, %ecx
    8f5b:      	cltd
    8f5c:      	idivl	%ecx
    8f5e:      	shll	$0x3, %eax
    8f61:      	leal	(%rax,%rax,2), %eax
    8f64:      	addl	$0x18, %eax
    8f67:      	movzwl	%ax, %esi
    8f6a:      	cmpl	$0x90, %esi
    8f70:      	ja	0x9602 <generic_kprobe_filter_arg+0x2782>
    8f76:      	movl	%esi, %eax
    8f78:      	cltd
    8f79:      	idivl	%ecx
    8f7b:      	decl	%eax
    8f7d:      	jmp	0x9d35 <generic_kprobe_filter_arg+0x2eb5>
    8f82:      	cmpq	%rdx, %r8
    8f85:      	setbe	%r8b
    8f89:      	cmpq	%rdi, %rdx
    8f8c:      	setbe	%dil
    8f90:      	andb	%r8b, %dil
    8f93:      	orb	%dil, %al
    8f96:      	cmpl	$0x29, %esi
    8f99:      	jb	0x9ecc <generic_kprobe_filter_arg+0x304c>
    8f9f:      	movq	0x30(%r13), %r8
    8fa3:      	movq	0x38(%r13), %rdi
    8fa7:      	cmpl	$0xc, %ecx
    8faa:      	je	0x8fb5 <generic_kprobe_filter_arg+0x2135>
    8fac:      	cmpl	$0xa, %ecx
    8faf:      	jne	0x9632 <generic_kprobe_filter_arg+0x27b2>
    8fb5:      	cmpq	%rdx, %r8
    8fb8:      	setle	%r8b
    8fbc:      	cmpq	%rdi, %rdx
    8fbf:      	setle	%dil
    8fc3:      	jmp	0x9640 <generic_kprobe_filter_arg+0x27c0>
    8fc8:      	xorl	%ebx, %ebx
    8fca:      	cmpl	$0x29, %ecx
    8fcd:      	jne	0x8fd8 <generic_kprobe_filter_arg+0x2158>
    8fcf:      	testq	%rdx, %rdx
    8fd2:      	je	0x8fd8 <generic_kprobe_filter_arg+0x2158>
    8fd4:      	movzbl	0x3a(%rdx), %ebx
    8fd8:      	cmpl	$0x29, %ecx
    8fdb:      	je	0x8fe6 <generic_kprobe_filter_arg+0x2166>
    8fdd:      	cmpl	$0x7, %ecx
    8fe0:      	jne	0x9570 <generic_kprobe_filter_arg+0x26f0>
    8fe6:      	movq	%r11, %r12
    8fe9:      	movzbl	0x10(%r13), %eax
    8fee:      	movl	%eax, 0x34(%rsp)
    8ff2:      	movl	$0x1, %eax
    8ff7:      	movq	(%rip), %rdi            # 0x8ffe <generic_kprobe_filter_arg+0x217e>
    8ffe:      	leaq	0x34(%rsp), %rsi
    9003:      	callq	*%rax
    9005:      	testq	%rax, %rax
    9008:      	je	0x9023 <generic_kprobe_filter_arg+0x21a3>
    900a:      	movq	%rax, %rdi
    900d:      	movl	%ebx, %eax
    900f:      	movq	%rax, 0x70(%rsp)
    9014:      	movl	$0x1, %eax
    9019:      	movq	0x28(%rsp), %rsi
    901e:      	jmp	0x8a6f <generic_kprobe_filter_arg+0x1bef>
    9023:      	xorl	%ebx, %ebx
    9025:      	movq	(%rsp), %rdi
    9029:      	movq	0x8(%rsp), %r9
    902e:      	movq	%r12, %r11
    9031:      	jmp	0x7150 <generic_kprobe_filter_arg+0x2d0>
    9036:      	xorl	%ebx, %ebx
    9038:      	movq	%r15, %r11
    903b:      	movq	0x68(%rsp), %r15
    9040:      	jmp	0x9513 <generic_kprobe_filter_arg+0x2693>
    9045:      	cmpq	%rax, %rdi
    9048:      	movq	(%rsp), %rdi
    904c:      	ja	0x9057 <generic_kprobe_filter_arg+0x21d7>
    904e:      	cmpq	%rsi, %rax
    9051:      	jbe	0x7161 <generic_kprobe_filter_arg+0x2e1>
    9057:      	cmpl	$0x29, %edx
    905a:      	jb	0x6f9d <generic_kprobe_filter_arg+0x11d>
    9060:      	movq	0x30(%r13), %rdi
    9064:      	movq	0x38(%r13), %rsi
    9068:      	cmpl	$0xc, %ecx
    906b:      	je	0x9076 <generic_kprobe_filter_arg+0x21f6>
    906d:      	cmpl	$0xa, %ecx
    9070:      	jne	0x9673 <generic_kprobe_filter_arg+0x27f3>
    9076:      	cmpq	%rax, %rdi
    9079:      	movq	(%rsp), %rdi
    907d:      	jg	0x9685 <generic_kprobe_filter_arg+0x2805>
    9083:      	cmpq	%rsi, %rax
    9086:      	jle	0x7161 <generic_kprobe_filter_arg+0x2e1>
    908c:      	jmp	0x9685 <generic_kprobe_filter_arg+0x2805>
    9091:      	cmpl	%edx, (%r12)
    9095:      	ja	0x7161 <generic_kprobe_filter_arg+0x2e1>
    909b:      	jmp	0x90a7 <generic_kprobe_filter_arg+0x2227>
    909d:      	cmpl	%edx, (%r12)
    90a1:      	jb	0x7161 <generic_kprobe_filter_arg+0x2e1>
    90a7:      	movl	0x8(%r13), %edx
    90ab:      	cmpl	$0xd, %edx
    90ae:      	jb	0xa541 <generic_kprobe_filter_arg+0x36c1>
    90b4:      	movl	0x14(%r13), %esi
    90b8:      	cmpl	$0x2, %eax
    90bb:      	jle	0x90d8 <generic_kprobe_filter_arg+0x2258>
    90bd:      	leal	-0x3(%rax), %edi
    90c0:      	cmpl	$0x2, %edi
    90c3:      	jae	0x910e <generic_kprobe_filter_arg+0x228e>
    90c5:      	cmpl	%esi, (%r12)
    90c9:      	movq	(%rsp), %rdi
    90cd:      	je	0x7145 <generic_kprobe_filter_arg+0x2c5>
    90d3:      	jmp	0x9b88 <generic_kprobe_filter_arg+0x2d08>
    90d8:      	cmpl	$0x1, %eax
    90db:      	je	0x912a <generic_kprobe_filter_arg+0x22aa>
    90dd:      	cmpl	$0x2, %eax
    90e0:      	jne	0x9b88 <generic_kprobe_filter_arg+0x2d08>
    90e6:      	cmpl	$0xc, %ecx
    90e9:      	ja	0x9b7e <generic_kprobe_filter_arg+0x2cfe>
    90ef:      	movl	$0x1402, %r8d           # imm = 0x1402
    90f5:      	btl	%ecx, %r8d
    90f9:      	jae	0x9b7e <generic_kprobe_filter_arg+0x2cfe>
    90ff:      	cmpl	%esi, (%r12)
    9103:      	jl	0x7161 <generic_kprobe_filter_arg+0x2e1>
    9109:      	jmp	0x9b88 <generic_kprobe_filter_arg+0x2d08>
    910e:      	cmpl	$0xc, %eax
    9111:      	movq	(%rsp), %rdi
    9115:      	jne	0x9b88 <generic_kprobe_filter_arg+0x2d08>
    911b:      	testl	%esi, (%r12)
    911f:      	jne	0x7161 <generic_kprobe_filter_arg+0x2e1>
    9125:      	jmp	0x9b88 <generic_kprobe_filter_arg+0x2d08>
    912a:      	cmpl	$0xc, %ecx
    912d:      	ja	0x9b72 <generic_kprobe_filter_arg+0x2cf2>
    9133:      	movl	$0x1402, %r8d           # imm = 0x1402
    9139:      	btl	%ecx, %r8d
    913d:      	jae	0x9b72 <generic_kprobe_filter_arg+0x2cf2>
    9143:      	cmpl	%esi, (%r12)
    9147:      	jg	0x7161 <generic_kprobe_filter_arg+0x2e1>
    914d:      	jmp	0x9b88 <generic_kprobe_filter_arg+0x2d08>
    9152:      	cmpl	$0x1, %eax
    9155:      	je	0x99de <generic_kprobe_filter_arg+0x2b5e>
    915b:      	cmpl	$0x2, %eax
    915e:      	jne	0x99eb <generic_kprobe_filter_arg+0x2b6b>
    9164:      	movzbl	(%r12), %esi
    9169:      	cmpl	%esi, %edx
    916b:      	ja	0x7161 <generic_kprobe_filter_arg+0x2e1>
    9171:      	jmp	0x99eb <generic_kprobe_filter_arg+0x2b6b>
    9176:      	cmpl	$0x1, %eax
    9179:      	je	0x9a1f <generic_kprobe_filter_arg+0x2b9f>
    917f:      	cmpl	$0x2, %eax
    9182:      	jne	0x9a2c <generic_kprobe_filter_arg+0x2bac>
    9188:      	movzwl	(%r12), %esi
    918d:      	cmpl	%esi, %edx
    918f:      	ja	0x7161 <generic_kprobe_filter_arg+0x2e1>
    9195:      	jmp	0x9a2c <generic_kprobe_filter_arg+0x2bac>
    919a:      	movl	$0x1, %ebx
    919f:      	movq	(%rsp), %rdi
    91a3:      	jmp	0xa4bb <generic_kprobe_filter_arg+0x363b>
    91a8:      	movq	(%rsp), %rdi
    91ac:      	movq	0x8(%rsp), %r9
    91b1:      	movq	%rbp, %r11
    91b4:      	movzbl	%cl, %ebx
    91b7:      	jmp	0x7150 <generic_kprobe_filter_arg+0x2d0>
    91bc:      	movl	$0xa, %eax
    91c1:      	jmp	0x91cf <generic_kprobe_filter_arg+0x234f>
    91c3:      	movl	$0x6, %eax
    91c8:      	jmp	0x91cf <generic_kprobe_filter_arg+0x234f>
    91ca:      	movl	$0x8, %eax
    91cf:      	movl	%eax, %ecx
    91d1:      	andl	$0xf, %ecx
    91d4:      	movl	0x10(%r13,%rcx,4), %ecx
    91d9:      	cmpl	$-0x1, %ecx
    91dc:      	je	0xa113 <generic_kprobe_filter_arg+0x3293>
    91e2:      	movl	%ecx, 0x88(%rsp)
    91e9:      	movl	%eax, 0x18(%rsp)
    91ed:      	movq	%rsi, 0x60(%rsp)
    91f2:      	movl	$0x1, %eax
    91f7:      	movq	(%rip), %rdi            # 0x91fe <generic_kprobe_filter_arg+0x237e>
    91fe:      	movq	0x28(%rsp), %rbx
    9203:      	movq	%rbx, %rsi
    9206:      	callq	*%rax
    9208:      	movq	%rax, 0x20(%rsp)
    920d:      	movl	$0x1, %eax
    9212:      	movq	(%rip), %rdi            # 0x9219 <generic_kprobe_filter_arg+0x2399>
    9219:      	movq	%rbx, %rsi
    921c:      	callq	*%rax
    921e:      	movq	0x20(%rsp), %rdx
    9223:      	testq	%rdx, %rdx
    9226:      	je	0xa113 <generic_kprobe_filter_arg+0x3293>
    922c:      	movl	$0x0, %ebx
    9231:      	testq	%rax, %rax
    9234:      	movq	(%rsp), %rdi
    9238:      	movq	0x8(%rsp), %r9
    923d:      	movq	0x10(%rsp), %r11
    9242:      	je	0xa123 <generic_kprobe_filter_arg+0x32a3>
    9248:      	movq	%rdx, %rcx
    924b:      	movq	%rax, %rbx
    924e:      	movq	%r12, %rdx
    9251:      	addq	$0x4, %rdx
    9255:      	cmpl	$0x5, 0x18(%rsp)
    925a:      	jg	0x928c <generic_kprobe_filter_arg+0x240c>
    925c:      	movq	%rcx, %r12
    925f:      	movb	%bpl, (%rcx)
    9262:      	leaq	0x1(%rcx), %rdi
    9266:      	movl	$0x4, %eax
    926b:      	movl	%ebp, %esi
    926d:      	callq	*%rax
    926f:      	movq	0x60(%rsp), %rsi
    9274:      	subl	%ebp, %esi
    9276:      	jbe	0x92c0 <generic_kprobe_filter_arg+0x2440>
    9278:      	leaq	(%r12,%rbp), %rdi
    927c:      	incq	%rdi
    927f:      	andl	$0xfff, %esi            # imm = 0xFFF
    9285:      	movl	$0x4, %eax
    928a:      	jmp	0x92bb <generic_kprobe_filter_arg+0x243b>
    928c:      	movq	%rcx, %r12
    928f:      	movw	%bp, (%rcx)
    9292:      	leaq	0x2(%rcx), %rdi
    9296:      	movl	$0x4, %eax
    929b:      	movl	%ebp, %esi
    929d:      	callq	*%rax
    929f:      	movq	0x60(%rsp), %rsi
    92a4:      	subl	%ebp, %esi
    92a6:      	jbe	0x92c0 <generic_kprobe_filter_arg+0x2440>
    92a8:      	leaq	(%r12,%rbp), %rdi
    92ac:      	addq	$0x2, %rdi
    92b0:      	andl	$0xfff, %esi            # imm = 0xFFF
    92b6:      	movl	$0x4, %eax
    92bb:      	movq	%rbx, %rdx
    92be:      	callq	*%rax
    92c0:      	movl	0x88(%rsp), %eax
    92c7:      	movl	%eax, 0x38(%rsp)
    92cb:      	movl	0x18(%rsp), %eax
    92cf:      	cmpl	$0x4, %eax
    92d2:      	movq	(%rsp), %rdi
    92d6:      	movq	0x8(%rsp), %r9
    92db:      	movq	0x10(%rsp), %r11
    92e0:      	jle	0x931c <generic_kprobe_filter_arg+0x249c>
    92e2:      	cmpl	$0x7, %eax
    92e5:      	jg	0x9930 <generic_kprobe_filter_arg+0x2ab0>
    92eb:      	cmpl	$0x5, %eax
    92ee:      	je	0xa001 <generic_kprobe_filter_arg+0x3181>
    92f4:      	cmpl	$0x6, %eax
    92f7:      	je	0x9fc8 <generic_kprobe_filter_arg+0x3148>
    92fd:      	cmpl	$0x7, %eax
    9300:      	jne	0x9c6c <generic_kprobe_filter_arg+0x2dec>
    9306:      	movl	$0x1, %eax
    930b:      	leaq	0x38(%rsp), %rsi
    9310:      	movq	(%rip), %rdi            # 0x9317 <generic_kprobe_filter_arg+0x2497>
    9317:      	jmp	0xa025 <generic_kprobe_filter_arg+0x31a5>
    931c:      	cmpl	$0x1, %eax
    931f:      	jle	0x9a60 <generic_kprobe_filter_arg+0x2be0>
    9325:      	cmpl	$0x2, %eax
    9328:      	je	0x9fee <generic_kprobe_filter_arg+0x316e>
    932e:      	cmpl	$0x3, %eax
    9331:      	je	0x9fb5 <generic_kprobe_filter_arg+0x3135>
    9337:      	cmpl	$0x4, %eax
    933a:      	jne	0x9c6c <generic_kprobe_filter_arg+0x2dec>
    9340:      	movl	$0x1, %eax
    9345:      	leaq	0x38(%rsp), %rsi
    934a:      	movq	(%rip), %rdi            # 0x9351 <generic_kprobe_filter_arg+0x24d1>
    9351:      	jmp	0xa025 <generic_kprobe_filter_arg+0x31a5>
    9356:      	movl	$0xa, %eax
    935b:      	jmp	0x9369 <generic_kprobe_filter_arg+0x24e9>
    935d:      	movl	$0x6, %eax
    9362:      	jmp	0x9369 <generic_kprobe_filter_arg+0x24e9>
    9364:      	movl	$0x8, %eax
    9369:      	movl	%eax, %ecx
    936b:      	andl	$0xf, %ecx
    936e:      	movl	0x10(%r13,%rcx,4), %ecx
    9373:      	cmpl	$-0x1, %ecx
    9376:      	je	0x9c6c <generic_kprobe_filter_arg+0x2dec>
    937c:      	movl	%ecx, 0x90(%rsp)
    9383:      	movq	%rbx, 0x88(%rsp)
    938b:      	movl	%eax, 0x20(%rsp)
    938f:      	movq	%r8, 0x18(%rsp)
    9394:      	movq	%rsi, 0x60(%rsp)
    9399:      	movq	%r11, 0x10(%rsp)
    939e:      	movl	$0x1, %eax
    93a3:      	movq	(%rip), %rdi            # 0x93aa <generic_kprobe_filter_arg+0x252a>
    93aa:      	movq	0x28(%rsp), %rbx
    93af:      	movq	%rbx, %rsi
    93b2:      	callq	*%rax
    93b4:      	movq	%rax, %r12
    93b7:      	movl	$0x1, %eax
    93bc:      	movq	(%rip), %rdi            # 0x93c3 <generic_kprobe_filter_arg+0x2543>
    93c3:      	movq	%rbx, %rsi
    93c6:      	callq	*%rax
    93c8:      	testq	%r12, %r12
    93cb:      	je	0xa113 <generic_kprobe_filter_arg+0x3293>
    93d1:      	movl	$0x0, %ebx
    93d6:      	testq	%rax, %rax
    93d9:      	movq	(%rsp), %rdi
    93dd:      	movq	0x8(%rsp), %r9
    93e2:      	movq	0x10(%rsp), %r11
    93e7:      	je	0xa123 <generic_kprobe_filter_arg+0x32a3>
    93ed:      	movq	%r12, %rcx
    93f0:      	movq	%rax, %r12
    93f3:      	cmpl	$0x5, 0x20(%rsp)
    93f8:      	jg	0x9437 <generic_kprobe_filter_arg+0x25b7>
    93fa:      	movb	%bpl, (%rcx)
    93fd:      	movq	%rcx, %rbp
    9400:      	leaq	0x1(%rcx), %rdi
    9404:      	movl	$0x4, %eax
    9409:      	movq	0x60(%rsp), %rbx
    940e:      	movq	0x18(%rsp), %rdx
    9413:      	movl	%ebx, %esi
    9415:      	callq	*%rax
    9417:      	movq	0x88(%rsp), %rsi
    941f:      	subl	%ebx, %esi
    9421:      	jbe	0x9478 <generic_kprobe_filter_arg+0x25f8>
    9423:      	leaq	(%rbx,%rbp), %rdi
    9427:      	incq	%rdi
    942a:      	andl	$0xfff, %esi            # imm = 0xFFF
    9430:      	movl	$0x4, %eax
    9435:      	jmp	0x9473 <generic_kprobe_filter_arg+0x25f3>
    9437:      	movq	0x60(%rsp), %rbx
    943c:      	movq	%rcx, %rbp
    943f:      	movw	%bx, (%rcx)
    9442:      	leaq	0x2(%rcx), %rdi
    9446:      	movl	$0x4, %eax
    944b:      	movq	0x18(%rsp), %rdx
    9450:      	movl	%ebx, %esi
    9452:      	callq	*%rax
    9454:      	movq	0x88(%rsp), %rsi
    945c:      	subl	%ebx, %esi
    945e:      	jbe	0x9478 <generic_kprobe_filter_arg+0x25f8>
    9460:      	leaq	(%rbx,%rbp), %rdi
    9464:      	addq	$0x2, %rdi
    9468:      	andl	$0xfff, %esi            # imm = 0xFFF
    946e:      	movl	$0x4, %eax
    9473:      	movq	%r12, %rdx
    9476:      	callq	*%rax
    9478:      	movl	0x90(%rsp), %eax
    947f:      	movl	%eax, 0x38(%rsp)
    9483:      	movl	0x20(%rsp), %eax
    9487:      	cmpl	$0x4, %eax
    948a:      	movq	(%rsp), %rdi
    948e:      	movq	0x8(%rsp), %r9
    9493:      	movq	0x10(%rsp), %r11
    9498:      	jle	0x94d4 <generic_kprobe_filter_arg+0x2654>
    949a:      	cmpl	$0x7, %eax
    949d:      	jg	0x997e <generic_kprobe_filter_arg+0x2afe>
    94a3:      	cmpl	$0x5, %eax
    94a6:      	je	0xa0d1 <generic_kprobe_filter_arg+0x3251>
    94ac:      	cmpl	$0x6, %eax
    94af:      	je	0xa098 <generic_kprobe_filter_arg+0x3218>
    94b5:      	cmpl	$0x7, %eax
    94b8:      	jne	0x9c6c <generic_kprobe_filter_arg+0x2dec>
    94be:      	movl	$0x1, %eax
    94c3:      	leaq	0x38(%rsp), %rsi
    94c8:      	movq	(%rip), %rdi            # 0x94cf <generic_kprobe_filter_arg+0x264f>
    94cf:      	jmp	0xa0f5 <generic_kprobe_filter_arg+0x3275>
    94d4:      	cmpl	$0x1, %eax
    94d7:      	jle	0x9c49 <generic_kprobe_filter_arg+0x2dc9>
    94dd:      	cmpl	$0x2, %eax
    94e0:      	je	0xa0be <generic_kprobe_filter_arg+0x323e>
    94e6:      	cmpl	$0x3, %eax
    94e9:      	je	0xa085 <generic_kprobe_filter_arg+0x3205>
    94ef:      	cmpl	$0x4, %eax
    94f2:      	jne	0x9c6c <generic_kprobe_filter_arg+0x2dec>
    94f8:      	movl	$0x1, %eax
    94fd:      	leaq	0x38(%rsp), %rsi
    9502:      	movq	(%rip), %rdi            # 0x9509 <generic_kprobe_filter_arg+0x2689>
    9509:      	jmp	0xa0f5 <generic_kprobe_filter_arg+0x3275>
    950e:      	movl	$0x1, %ebx
    9513:      	movq	(%rsp), %rdi
    9517:      	movq	0x8(%rsp), %r9
    951c:      	jmp	0xa4bb <generic_kprobe_filter_arg+0x363b>
    9521:      	cmpl	%edx, %r8d
    9524:      	setbe	%r8b
    9528:      	cmpl	%edi, %edx
    952a:      	setbe	%dil
    952e:      	andb	%r8b, %dil
    9531:      	orb	%dil, %al
    9534:      	cmpl	$0x19, %esi
    9537:      	jb	0x9ecc <generic_kprobe_filter_arg+0x304c>
    953d:      	movl	0x20(%r13), %r8d
    9541:      	movl	0x24(%r13), %edi
    9545:      	cmpl	$0xc, %ecx
    9548:      	ja	0x9ab8 <generic_kprobe_filter_arg+0x2c38>
    954e:      	movl	$0x1402, %r10d          # imm = 0x1402
    9554:      	btl	%ecx, %r10d
    9558:      	jae	0x9ab8 <generic_kprobe_filter_arg+0x2c38>
    955e:      	cmpl	%edx, %r8d
    9561:      	setle	%r8b
    9565:      	cmpl	%edi, %edx
    9567:      	setle	%dil
    956b:      	jmp	0x9ac5 <generic_kprobe_filter_arg+0x2c45>
    9570:      	xorl	%ebx, %ebx
    9572:      	jmp	0x7150 <generic_kprobe_filter_arg+0x2d0>
    9577:      	cmpl	%eax, %edi
    9579:      	movq	(%rsp), %rdi
    957d:      	ja	0x9587 <generic_kprobe_filter_arg+0x2707>
    957f:      	cmpl	%esi, %eax
    9581:      	jbe	0x7161 <generic_kprobe_filter_arg+0x2e1>
    9587:      	cmpl	$0x19, %edx
    958a:      	jb	0x6f9d <generic_kprobe_filter_arg+0x11d>
    9590:      	movl	0x20(%r13), %edi
    9594:      	movl	0x24(%r13), %esi
    9598:      	cmpl	$0xc, %ecx
    959b:      	ja	0x9b23 <generic_kprobe_filter_arg+0x2ca3>
    95a1:      	movl	$0x1402, %r8d           # imm = 0x1402
    95a7:      	btl	%ecx, %r8d
    95ab:      	jae	0x9b23 <generic_kprobe_filter_arg+0x2ca3>
    95b1:      	cmpl	%eax, %edi
    95b3:      	movq	(%rsp), %rdi
    95b7:      	jg	0x9b33 <generic_kprobe_filter_arg+0x2cb3>
    95bd:      	cmpl	%esi, %eax
    95bf:      	jle	0x7161 <generic_kprobe_filter_arg+0x2e1>
    95c5:      	jmp	0x9b33 <generic_kprobe_filter_arg+0x2cb3>
    95ca:      	movl	$0x100, %esi            # imm = 0x100
    95cf:      	cmpl	$0x101, %eax            # imm = 0x101
    95d4:      	jb	0x9602 <generic_kprobe_filter_arg+0x2782>
    95d6:      	movl	$0x200, %esi            # imm = 0x200
    95db:      	cmpl	$0x201, %eax            # imm = 0x201
    95e0:      	jb	0x9602 <generic_kprobe_filter_arg+0x2782>
    95e2:      	movl	$0x400, %esi            # imm = 0x400
    95e7:      	cmpl	$0x401, %eax            # imm = 0x401
    95ec:      	jb	0x9602 <generic_kprobe_filter_arg+0x2782>
    95ee:      	xorl	%esi, %esi
    95f0:      	cmpl	$0x801, %eax            # imm = 0x801
    95f5:      	setae	%sil
    95f9:      	shll	$0xb, %esi
    95fc:      	addl	$0x800, %esi            # imm = 0x800
    9602:      	leal	-0x100(%rsi), %eax
    9608:      	rorxl	$0x8, %eax, %eax
    960e:      	cmpl	$0x2, %eax
    9611:      	jg	0x99c2 <generic_kprobe_filter_arg+0x2b42>
    9617:      	testl	%eax, %eax
    9619:      	je	0x9d29 <generic_kprobe_filter_arg+0x2ea9>
    961f:      	cmpl	$0x1, %eax
    9622:      	jne	0x9d22 <generic_kprobe_filter_arg+0x2ea2>
    9628:      	movl	$0x7, %eax
    962d:      	jmp	0x9d35 <generic_kprobe_filter_arg+0x2eb5>
    9632:      	cmpq	%rdx, %r8
    9635:      	setbe	%r8b
    9639:      	cmpq	%rdi, %rdx
    963c:      	setbe	%dil
    9640:      	andb	%r8b, %dil
    9643:      	orb	%dil, %al
    9646:      	cmpl	$0x39, %esi
    9649:      	jb	0x9ecc <generic_kprobe_filter_arg+0x304c>
    964f:      	movq	0x40(%r13), %rdi
    9653:      	movq	0x48(%r13), %rsi
    9657:      	cmpl	$0xc, %ecx
    965a:      	je	0x9665 <generic_kprobe_filter_arg+0x27e5>
    965c:      	cmpl	$0xa, %ecx
    965f:      	jne	0x9c2f <generic_kprobe_filter_arg+0x2daf>
    9665:      	cmpq	%rdx, %rdi
    9668:      	setle	%cl
    966b:      	cmpq	%rsi, %rdx
    966e:      	jmp	0x9afc <generic_kprobe_filter_arg+0x2c7c>
    9673:      	cmpq	%rax, %rdi
    9676:      	movq	(%rsp), %rdi
    967a:      	ja	0x9685 <generic_kprobe_filter_arg+0x2805>
    967c:      	cmpq	%rsi, %rax
    967f:      	jbe	0x7161 <generic_kprobe_filter_arg+0x2e1>
    9685:      	cmpl	$0x39, %edx
    9688:      	jb	0x6f9d <generic_kprobe_filter_arg+0x11d>
    968e:      	movq	0x40(%r13), %rsi
    9692:      	movq	0x48(%r13), %rdx
    9696:      	cmpl	$0xc, %ecx
    9699:      	je	0x96a4 <generic_kprobe_filter_arg+0x2824>
    969b:      	cmpl	$0xa, %ecx
    969e:      	jne	0x9c95 <generic_kprobe_filter_arg+0x2e15>
    96a4:      	cmpq	%rax, %rsi
    96a7:      	jg	0x6f9d <generic_kprobe_filter_arg+0x11d>
    96ad:      	cmpq	%rdx, %rax
    96b0:      	jle	0x7161 <generic_kprobe_filter_arg+0x2e1>
    96b6:      	jmp	0x6f9d <generic_kprobe_filter_arg+0x11d>
    96bb:      	cmpq	%rsi, (%r12)
    96bf:      	ja	0x7161 <generic_kprobe_filter_arg+0x2e1>
    96c5:      	jmp	0x96d1 <generic_kprobe_filter_arg+0x2851>
    96c7:      	cmpq	%rsi, (%r12)
    96cb:      	jb	0x7161 <generic_kprobe_filter_arg+0x2e1>
    96d1:      	cmpl	$0x19, %edx
    96d4:      	jb	0xa541 <generic_kprobe_filter_arg+0x36c1>
    96da:      	movq	0x20(%r13), %rsi
    96de:      	cmpl	$0x2, %eax
    96e1:      	jle	0x96fe <generic_kprobe_filter_arg+0x287e>
    96e3:      	leal	-0x3(%rax), %edi
    96e6:      	cmpl	$0x2, %edi
    96e9:      	jae	0x972d <generic_kprobe_filter_arg+0x28ad>
    96eb:      	cmpq	%rsi, (%r12)
    96ef:      	movq	(%rsp), %rdi
    96f3:      	je	0x7145 <generic_kprobe_filter_arg+0x2c5>
    96f9:      	jmp	0x9ef3 <generic_kprobe_filter_arg+0x3073>
    96fe:      	cmpl	$0x1, %eax
    9701:      	je	0x9961 <generic_kprobe_filter_arg+0x2ae1>
    9707:      	cmpl	$0x2, %eax
    970a:      	jne	0x9ef3 <generic_kprobe_filter_arg+0x3073>
    9710:      	cmpl	$0xc, %ecx
    9713:      	je	0x971e <generic_kprobe_filter_arg+0x289e>
    9715:      	cmpl	$0xa, %ecx
    9718:      	jne	0x9ee9 <generic_kprobe_filter_arg+0x3069>
    971e:      	cmpq	%rsi, (%r12)
    9722:      	jl	0x7161 <generic_kprobe_filter_arg+0x2e1>
    9728:      	jmp	0x9ef3 <generic_kprobe_filter_arg+0x3073>
    972d:      	cmpl	$0xc, %eax
    9730:      	movq	(%rsp), %rdi
    9734:      	jne	0x9ef3 <generic_kprobe_filter_arg+0x3073>
    973a:      	testq	%rsi, (%r12)
    973e:      	jne	0x7161 <generic_kprobe_filter_arg+0x2e1>
    9744:      	jmp	0x9ef3 <generic_kprobe_filter_arg+0x3073>
    9749:      	movl	$0xa, %eax
    974e:      	jmp	0x975c <generic_kprobe_filter_arg+0x28dc>
    9750:      	movl	$0x6, %eax
    9755:      	jmp	0x975c <generic_kprobe_filter_arg+0x28dc>
    9757:      	movl	$0x8, %eax
    975c:      	movl	%eax, %ecx
    975e:      	andl	$0xf, %ecx
    9761:      	movl	0x10(%r13,%rcx,4), %ecx
    9766:      	cmpl	$-0x1, %ecx
    9769:      	je	0x9d17 <generic_kprobe_filter_arg+0x2e97>
    976f:      	movl	%ecx, 0x88(%rsp)
    9776:      	movl	%eax, 0x60(%rsp)
    977a:      	movq	%rsi, 0x90(%rsp)
    9782:      	movq	%r11, 0x10(%rsp)
    9787:      	movl	$0x1, %eax
    978c:      	movq	(%rip), %rdi            # 0x9793 <generic_kprobe_filter_arg+0x2913>
    9793:      	movq	0x28(%rsp), %rbx
    9798:      	movq	%rbx, %rsi
    979b:      	callq	*%rax
    979d:      	movq	%rax, %r12
    97a0:      	movl	$0x1, %eax
    97a5:      	movq	(%rip), %rdi            # 0x97ac <generic_kprobe_filter_arg+0x292c>
    97ac:      	movq	%rbx, %rsi
    97af:      	callq	*%rax
    97b1:      	movq	%r12, 0x20(%rsp)
    97b6:      	testq	%r12, %r12
    97b9:      	je	0xa4ab <generic_kprobe_filter_arg+0x362b>
    97bf:      	movl	$0x0, %ebx
    97c4:      	testq	%rax, %rax
    97c7:      	movq	(%rsp), %rdi
    97cb:      	movq	0x8(%rsp), %r9
    97d0:      	movq	0x10(%rsp), %r11
    97d5:      	je	0xa4bb <generic_kprobe_filter_arg+0x363b>
    97db:      	movq	%rax, %r12
    97de:      	movl	0x60(%rsp), %ebx
    97e2:      	cmpl	$0x5, %ebx
    97e5:      	jg	0x9829 <generic_kprobe_filter_arg+0x29a9>
    97e7:      	movq	0x20(%rsp), %rax
    97ec:      	movb	%bpl, (%rax)
    97ef:      	leaq	0x1(%rax), %rdi
    97f3:      	movl	$0x4, %eax
    97f8:      	movq	0x18(%rsp), %rdx
    97fd:      	movl	%ebp, %esi
    97ff:      	callq	*%rax
    9801:      	movq	0x90(%rsp), %rsi
    9809:      	subl	%ebp, %esi
    980b:      	jbe	0x986c <generic_kprobe_filter_arg+0x29ec>
    980d:      	movq	0x20(%rsp), %rax
    9812:      	leaq	(%rax,%rbp), %rdi
    9816:      	incq	%rdi
    9819:      	andl	$0xfff, %esi            # imm = 0xFFF
    981f:      	movl	$0x4, %eax
    9824:      	movq	%r12, %rdx
    9827:      	jmp	0x986a <generic_kprobe_filter_arg+0x29ea>
    9829:      	movq	0x20(%rsp), %rax
    982e:      	movw	%bp, (%rax)
    9831:      	leaq	0x2(%rax), %rdi
    9835:      	movl	$0x4, %eax
    983a:      	movq	0x18(%rsp), %rdx
    983f:      	movl	%ebp, %esi
    9841:      	callq	*%rax
    9843:      	movq	0x90(%rsp), %rsi
    984b:      	subl	%ebp, %esi
    984d:      	jbe	0x986c <generic_kprobe_filter_arg+0x29ec>
    984f:      	movq	0x20(%rsp), %rax
    9854:      	leaq	(%rax,%rbp), %rdi
    9858:      	addq	$0x2, %rdi
    985c:      	andl	$0xfff, %esi            # imm = 0xFFF
    9862:      	movl	$0x4, %eax
    9867:      	movq	%r12, %rdx
    986a:      	callq	*%rax
    986c:      	movl	0x88(%rsp), %eax
    9873:      	movl	%eax, 0x38(%rsp)
    9877:      	cmpl	$0x4, %ebx
    987a:      	movq	0x8(%rsp), %r9
    987f:      	movq	0x10(%rsp), %r11
    9884:      	jle	0x98c0 <generic_kprobe_filter_arg+0x2a40>
    9886:      	cmpl	$0x7, %ebx
    9889:      	jg	0x9a87 <generic_kprobe_filter_arg+0x2c07>
    988f:      	cmpl	$0x5, %ebx
    9892:      	je	0xa1ad <generic_kprobe_filter_arg+0x332d>
    9898:      	cmpl	$0x6, %ebx
    989b:      	je	0xa174 <generic_kprobe_filter_arg+0x32f4>
    98a1:      	cmpl	$0x7, %ebx
    98a4:      	jne	0x9d17 <generic_kprobe_filter_arg+0x2e97>
    98aa:      	movl	$0x1, %eax
    98af:      	leaq	0x38(%rsp), %rsi
    98b4:      	movq	(%rip), %rdi            # 0x98bb <generic_kprobe_filter_arg+0x2a3b>
    98bb:      	jmp	0xa1d1 <generic_kprobe_filter_arg+0x3351>
    98c0:      	cmpl	$0x1, %ebx
    98c3:      	jle	0x9cf4 <generic_kprobe_filter_arg+0x2e74>
    98c9:      	cmpl	$0x2, %ebx
    98cc:      	je	0xa19a <generic_kprobe_filter_arg+0x331a>
    98d2:      	cmpl	$0x3, %ebx
    98d5:      	je	0xa161 <generic_kprobe_filter_arg+0x32e1>
    98db:      	cmpl	$0x4, %ebx
    98de:      	jne	0x9d17 <generic_kprobe_filter_arg+0x2e97>
    98e4:      	movl	$0x1, %eax
    98e9:      	leaq	0x38(%rsp), %rsi
    98ee:      	movq	(%rip), %rdi            # 0x98f5 <generic_kprobe_filter_arg+0x2a75>
    98f5:      	jmp	0xa1d1 <generic_kprobe_filter_arg+0x3351>
    98fa:      	cmpl	$0xc, %eax
    98fd:      	jne	0x99eb <generic_kprobe_filter_arg+0x2b6b>
    9903:      	movzbl	(%r12), %esi
    9908:      	testl	%esi, %edx
    990a:      	jne	0x7161 <generic_kprobe_filter_arg+0x2e1>
    9910:      	jmp	0x99eb <generic_kprobe_filter_arg+0x2b6b>
    9915:      	cmpl	$0xc, %eax
    9918:      	jne	0x9a2c <generic_kprobe_filter_arg+0x2bac>
    991e:      	movzwl	(%r12), %esi
    9923:      	testl	%esi, %edx
    9925:      	jne	0x7161 <generic_kprobe_filter_arg+0x2e1>
    992b:      	jmp	0x9a2c <generic_kprobe_filter_arg+0x2bac>
    9930:      	cmpl	$0x8, %eax
    9933:      	je	0xa014 <generic_kprobe_filter_arg+0x3194>
    9939:      	cmpl	$0x9, %eax
    993c:      	je	0x9fdb <generic_kprobe_filter_arg+0x315b>
    9942:      	cmpl	$0xa, %eax
    9945:      	jne	0x9c6c <generic_kprobe_filter_arg+0x2dec>
    994b:      	movl	$0x1, %eax
    9950:      	leaq	0x38(%rsp), %rsi
    9955:      	movq	(%rip), %rdi            # 0x995c <generic_kprobe_filter_arg+0x2adc>
    995c:      	jmp	0xa025 <generic_kprobe_filter_arg+0x31a5>
    9961:      	cmpl	$0xc, %ecx
    9964:      	je	0x996f <generic_kprobe_filter_arg+0x2aef>
    9966:      	cmpl	$0xa, %ecx
    9969:      	jne	0x9edd <generic_kprobe_filter_arg+0x305d>
    996f:      	cmpq	%rsi, (%r12)
    9973:      	jg	0x7161 <generic_kprobe_filter_arg+0x2e1>
    9979:      	jmp	0x9ef3 <generic_kprobe_filter_arg+0x3073>
    997e:      	cmpl	$0x8, %eax
    9981:      	je	0xa0e4 <generic_kprobe_filter_arg+0x3264>
    9987:      	cmpl	$0x9, %eax
    998a:      	je	0xa0ab <generic_kprobe_filter_arg+0x322b>
    9990:      	cmpl	$0xa, %eax
    9993:      	jne	0x9c6c <generic_kprobe_filter_arg+0x2dec>
    9999:      	movl	$0x1, %eax
    999e:      	leaq	0x38(%rsp), %rsi
    99a3:      	movq	(%rip), %rdi            # 0x99aa <generic_kprobe_filter_arg+0x2b2a>
    99aa:      	jmp	0xa0f5 <generic_kprobe_filter_arg+0x3275>
    99af:      	movq	(%rsp), %rdi
    99b3:      	movq	0x8(%rsp), %r9
    99b8:      	movq	0x10(%rsp), %r11
    99bd:      	jmp	0x7150 <generic_kprobe_filter_arg+0x2d0>
    99c2:      	cmpl	$0x3, %eax
    99c5:      	je	0x9d30 <generic_kprobe_filter_arg+0x2eb0>
    99cb:      	cmpl	$0x7, %eax
    99ce:      	jne	0x9d22 <generic_kprobe_filter_arg+0x2ea2>
    99d4:      	movl	$0x9, %eax
    99d9:      	jmp	0x9d35 <generic_kprobe_filter_arg+0x2eb5>
    99de:      	movzbl	(%r12), %esi
    99e3:      	cmpl	%esi, %edx
    99e5:      	jb	0x7161 <generic_kprobe_filter_arg+0x2e1>
    99eb:      	cmpl	$0x11, %ecx
    99ee:      	jb	0xa541 <generic_kprobe_filter_arg+0x36c1>
    99f4:      	movl	0x18(%r13), %edx
    99f8:      	cmpl	$0x2, %eax
    99fb:      	jle	0x9cac <generic_kprobe_filter_arg+0x2e2c>
    9a01:      	leal	-0x3(%rax), %esi
    9a04:      	cmpl	$0x2, %esi
    9a07:      	jae	0x9f6c <generic_kprobe_filter_arg+0x30ec>
    9a0d:      	movzbl	(%r12), %esi
    9a12:      	cmpl	%esi, %edx
    9a14:      	je	0x7145 <generic_kprobe_filter_arg+0x2c5>
    9a1a:      	jmp	0xa1fb <generic_kprobe_filter_arg+0x337b>
    9a1f:      	movzwl	(%r12), %esi
    9a24:      	cmpl	%esi, %edx
    9a26:      	jb	0x7161 <generic_kprobe_filter_arg+0x2e1>
    9a2c:      	cmpl	$0x11, %ecx
    9a2f:      	jb	0xa541 <generic_kprobe_filter_arg+0x36c1>
    9a35:      	movl	0x18(%r13), %edx
    9a39:      	cmpl	$0x2, %eax
    9a3c:      	jle	0x9cd0 <generic_kprobe_filter_arg+0x2e50>
    9a42:      	leal	-0x3(%rax), %esi
    9a45:      	cmpl	$0x2, %esi
    9a48:      	jae	0x9f87 <generic_kprobe_filter_arg+0x3107>
    9a4e:      	movzwl	(%r12), %esi
    9a53:      	cmpl	%esi, %edx
    9a55:      	je	0x7145 <generic_kprobe_filter_arg+0x2c5>
    9a5b:      	jmp	0xa243 <generic_kprobe_filter_arg+0x33c3>
    9a60:      	testl	%eax, %eax
    9a62:      	je	0x9fa2 <generic_kprobe_filter_arg+0x3122>
    9a68:      	cmpl	$0x1, %eax
    9a6b:      	jne	0x9c6c <generic_kprobe_filter_arg+0x2dec>
    9a71:      	movl	$0x1, %eax
    9a76:      	leaq	0x38(%rsp), %rsi
    9a7b:      	movq	(%rip), %rdi            # 0x9a82 <generic_kprobe_filter_arg+0x2c02>
    9a82:      	jmp	0xa025 <generic_kprobe_filter_arg+0x31a5>
    9a87:      	cmpl	$0x8, %ebx
    9a8a:      	je	0xa1c0 <generic_kprobe_filter_arg+0x3340>
    9a90:      	cmpl	$0x9, %ebx
    9a93:      	je	0xa187 <generic_kprobe_filter_arg+0x3307>
    9a99:      	cmpl	$0xa, %ebx
    9a9c:      	jne	0x9d17 <generic_kprobe_filter_arg+0x2e97>
    9aa2:      	movl	$0x1, %eax
    9aa7:      	leaq	0x38(%rsp), %rsi
    9aac:      	movq	(%rip), %rdi            # 0x9ab3 <generic_kprobe_filter_arg+0x2c33>
    9ab3:      	jmp	0xa1d1 <generic_kprobe_filter_arg+0x3351>
    9ab8:      	cmpl	%edx, %r8d
    9abb:      	setbe	%r8b
    9abf:      	cmpl	%edi, %edx
    9ac1:      	setbe	%dil
    9ac5:      	andb	%r8b, %dil
    9ac8:      	orb	%dil, %al
    9acb:      	cmpl	$0x21, %esi
    9ace:      	jb	0x9ecc <generic_kprobe_filter_arg+0x304c>
    9ad4:      	movl	0x28(%r13), %edi
    9ad8:      	movl	0x2c(%r13), %esi
    9adc:      	cmpl	$0xc, %ecx
    9adf:      	ja	0x9ebe <generic_kprobe_filter_arg+0x303e>
    9ae5:      	movl	$0x1402, %r8d           # imm = 0x1402
    9aeb:      	btl	%ecx, %r8d
    9aef:      	jae	0x9ebe <generic_kprobe_filter_arg+0x303e>
    9af5:      	cmpl	%edx, %edi
    9af7:      	setle	%cl
    9afa:      	cmpl	%esi, %edx
    9afc:      	setle	%dl
    9aff:      	jmp	0x9ec8 <generic_kprobe_filter_arg+0x3048>
    9b04:      	xorl	%ebx, %ebx
    9b06:      	jmp	0x9b0d <generic_kprobe_filter_arg+0x2c8d>
    9b08:      	movl	$0x1, %ebx
    9b0d:      	movq	(%rsp), %rdi
    9b11:      	movq	0x8(%rsp), %r9
    9b16:      	movq	%r15, %r11
    9b19:      	movq	0x68(%rsp), %r15
    9b1e:      	jmp	0xa4bb <generic_kprobe_filter_arg+0x363b>
    9b23:      	cmpl	%eax, %edi
    9b25:      	movq	(%rsp), %rdi
    9b29:      	ja	0x9b33 <generic_kprobe_filter_arg+0x2cb3>
    9b2b:      	cmpl	%esi, %eax
    9b2d:      	jbe	0x7161 <generic_kprobe_filter_arg+0x2e1>
    9b33:      	cmpl	$0x21, %edx
    9b36:      	jb	0x6f9d <generic_kprobe_filter_arg+0x11d>
    9b3c:      	movl	0x28(%r13), %esi
    9b40:      	movl	0x2c(%r13), %edx
    9b44:      	cmpl	$0xc, %ecx
    9b47:      	ja	0xa040 <generic_kprobe_filter_arg+0x31c0>
    9b4d:      	movl	$0x1402, %r8d           # imm = 0x1402
    9b53:      	btl	%ecx, %r8d
    9b57:      	jae	0xa040 <generic_kprobe_filter_arg+0x31c0>
    9b5d:      	cmpl	%eax, %esi
    9b5f:      	jg	0x6f9d <generic_kprobe_filter_arg+0x11d>
    9b65:      	cmpl	%edx, %eax
    9b67:      	jle	0x7161 <generic_kprobe_filter_arg+0x2e1>
    9b6d:      	jmp	0x6f9d <generic_kprobe_filter_arg+0x11d>
    9b72:      	cmpl	%esi, (%r12)
    9b76:      	ja	0x7161 <generic_kprobe_filter_arg+0x2e1>
    9b7c:      	jmp	0x9b88 <generic_kprobe_filter_arg+0x2d08>
    9b7e:      	cmpl	%esi, (%r12)
    9b82:      	jb	0x7161 <generic_kprobe_filter_arg+0x2e1>
    9b88:      	cmpl	$0x11, %edx
    9b8b:      	jb	0xa541 <generic_kprobe_filter_arg+0x36c1>
    9b91:      	movl	0x18(%r13), %esi
    9b95:      	cmpl	$0x2, %eax
    9b98:      	jle	0x9bb5 <generic_kprobe_filter_arg+0x2d35>
    9b9a:      	leal	-0x3(%rax), %edi
    9b9d:      	cmpl	$0x2, %edi
    9ba0:      	jae	0x9beb <generic_kprobe_filter_arg+0x2d6b>
    9ba2:      	cmpl	%esi, (%r12)
    9ba6:      	movq	(%rsp), %rdi
    9baa:      	je	0x7145 <generic_kprobe_filter_arg+0x2c5>
    9bb0:      	jmp	0xa2d0 <generic_kprobe_filter_arg+0x3450>
    9bb5:      	cmpl	$0x1, %eax
    9bb8:      	je	0x9c07 <generic_kprobe_filter_arg+0x2d87>
    9bba:      	cmpl	$0x2, %eax
    9bbd:      	jne	0xa2d0 <generic_kprobe_filter_arg+0x3450>
    9bc3:      	cmpl	$0xc, %ecx
    9bc6:      	ja	0xa2c6 <generic_kprobe_filter_arg+0x3446>
    9bcc:      	movl	$0x1402, %r8d           # imm = 0x1402
    9bd2:      	btl	%ecx, %r8d
    9bd6:      	jae	0xa2c6 <generic_kprobe_filter_arg+0x3446>
    9bdc:      	cmpl	%esi, (%r12)
    9be0:      	jl	0x7161 <generic_kprobe_filter_arg+0x2e1>
    9be6:      	jmp	0xa2d0 <generic_kprobe_filter_arg+0x3450>
    9beb:      	cmpl	$0xc, %eax
    9bee:      	movq	(%rsp), %rdi
    9bf2:      	jne	0xa2d0 <generic_kprobe_filter_arg+0x3450>
    9bf8:      	testl	%esi, (%r12)
    9bfc:      	jne	0x7161 <generic_kprobe_filter_arg+0x2e1>
    9c02:      	jmp	0xa2d0 <generic_kprobe_filter_arg+0x3450>
    9c07:      	cmpl	$0xc, %ecx
    9c0a:      	ja	0xa2ba <generic_kprobe_filter_arg+0x343a>
    9c10:      	movl	$0x1402, %r8d           # imm = 0x1402
    9c16:      	btl	%ecx, %r8d
    9c1a:      	jae	0xa2ba <generic_kprobe_filter_arg+0x343a>
    9c20:      	cmpl	%esi, (%r12)
    9c24:      	jg	0x7161 <generic_kprobe_filter_arg+0x2e1>
    9c2a:      	jmp	0xa2d0 <generic_kprobe_filter_arg+0x3450>
    9c2f:      	cmpq	%rdx, %rdi
    9c32:      	setbe	%cl
    9c35:      	cmpq	%rsi, %rdx
    9c38:      	jmp	0x9ec5 <generic_kprobe_filter_arg+0x3045>
    9c3d:      	xorl	%ebx, %ebx
    9c3f:      	movq	0x68(%rsp), %r15
    9c44:      	jmp	0xa4bb <generic_kprobe_filter_arg+0x363b>
    9c49:      	testl	%eax, %eax
    9c4b:      	je	0xa072 <generic_kprobe_filter_arg+0x31f2>
    9c51:      	cmpl	$0x1, %eax
    9c54:      	jne	0x9c6c <generic_kprobe_filter_arg+0x2dec>
    9c56:      	movl	$0x1, %eax
    9c5b:      	leaq	0x38(%rsp), %rsi
    9c60:      	movq	(%rip), %rdi            # 0x9c67 <generic_kprobe_filter_arg+0x2de7>
    9c67:      	jmp	0xa0f5 <generic_kprobe_filter_arg+0x3275>
    9c6c:      	xorl	%ebx, %ebx
    9c6e:      	movl	0x4(%r13), %eax
    9c72:      	cmpq	$0x25, %rax
    9c76:      	jbe	0xa131 <generic_kprobe_filter_arg+0x32b1>
    9c7c:      	jmp	0x7150 <generic_kprobe_filter_arg+0x2d0>
    9c81:      	movq	(%rsp), %rdi
    9c85:      	movq	0x8(%rsp), %r9
    9c8a:      	movq	%r12, %r11
    9c8d:      	movzbl	%cl, %ebx
    9c90:      	jmp	0x7150 <generic_kprobe_filter_arg+0x2d0>
    9c95:      	cmpq	%rax, %rsi
    9c98:      	ja	0x6f9d <generic_kprobe_filter_arg+0x11d>
    9c9e:      	cmpq	%rdx, %rax
    9ca1:      	jbe	0x7161 <generic_kprobe_filter_arg+0x2e1>
    9ca7:      	jmp	0x6f9d <generic_kprobe_filter_arg+0x11d>
    9cac:      	cmpl	$0x1, %eax
    9caf:      	je	0xa1ee <generic_kprobe_filter_arg+0x336e>
    9cb5:      	cmpl	$0x2, %eax
    9cb8:      	jne	0xa1fb <generic_kprobe_filter_arg+0x337b>
    9cbe:      	movzbl	(%r12), %esi
    9cc3:      	cmpl	%esi, %edx
    9cc5:      	ja	0x7161 <generic_kprobe_filter_arg+0x2e1>
    9ccb:      	jmp	0xa1fb <generic_kprobe_filter_arg+0x337b>
    9cd0:      	cmpl	$0x1, %eax
    9cd3:      	je	0xa236 <generic_kprobe_filter_arg+0x33b6>
    9cd9:      	cmpl	$0x2, %eax
    9cdc:      	jne	0xa243 <generic_kprobe_filter_arg+0x33c3>
    9ce2:      	movzwl	(%r12), %esi
    9ce7:      	cmpl	%esi, %edx
    9ce9:      	ja	0x7161 <generic_kprobe_filter_arg+0x2e1>
    9cef:      	jmp	0xa243 <generic_kprobe_filter_arg+0x33c3>
    9cf4:      	testl	%ebx, %ebx
    9cf6:      	je	0xa14e <generic_kprobe_filter_arg+0x32ce>
    9cfc:      	cmpl	$0x1, %ebx
    9cff:      	jne	0x9d17 <generic_kprobe_filter_arg+0x2e97>
    9d01:      	movl	$0x1, %eax
    9d06:      	leaq	0x38(%rsp), %rsi
    9d0b:      	movq	(%rip), %rdi            # 0x9d12 <generic_kprobe_filter_arg+0x2e92>
    9d12:      	jmp	0xa1d1 <generic_kprobe_filter_arg+0x3351>
    9d17:      	xorl	%ebx, %ebx
    9d19:      	movq	(%rsp), %rdi
    9d1d:      	jmp	0xa4bb <generic_kprobe_filter_arg+0x363b>
    9d22:      	movl	$0xa, %eax
    9d27:      	jmp	0x9d35 <generic_kprobe_filter_arg+0x2eb5>
    9d29:      	movl	$0x6, %eax
    9d2e:      	jmp	0x9d35 <generic_kprobe_filter_arg+0x2eb5>
    9d30:      	movl	$0x8, %eax
    9d35:      	movl	%eax, %ecx
    9d37:      	andl	$0xf, %ecx
    9d3a:      	movl	0x10(%r13,%rcx,4), %ecx
    9d3f:      	cmpl	$-0x1, %ecx
    9d42:      	je	0xa4ab <generic_kprobe_filter_arg+0x362b>
    9d48:      	movl	%ecx, 0x90(%rsp)
    9d4f:      	movl	%eax, 0x88(%rsp)
    9d56:      	movq	%rsi, 0x60(%rsp)
    9d5b:      	movl	$0x1, %eax
    9d60:      	movq	(%rip), %rdi            # 0x9d67 <generic_kprobe_filter_arg+0x2ee7>
    9d67:      	movq	0x28(%rsp), %rbx
    9d6c:      	movq	%rbx, %rsi
    9d6f:      	callq	*%rax
    9d71:      	movq	%rax, %r12
    9d74:      	movl	$0x1, %eax
    9d79:      	movq	(%rip), %rdi            # 0x9d80 <generic_kprobe_filter_arg+0x2f00>
    9d80:      	movq	%rbx, %rsi
    9d83:      	callq	*%rax
    9d85:      	movq	%r12, 0x20(%rsp)
    9d8a:      	testq	%r12, %r12
    9d8d:      	je	0xa4ab <generic_kprobe_filter_arg+0x362b>
    9d93:      	movl	$0x0, %ebx
    9d98:      	testq	%rax, %rax
    9d9b:      	movq	(%rsp), %rdi
    9d9f:      	movq	0x8(%rsp), %r9
    9da4:      	movq	0x10(%rsp), %r11
    9da9:      	je	0xa4bb <generic_kprobe_filter_arg+0x363b>
    9daf:      	movq	%rax, %r12
    9db2:      	movl	0x88(%rsp), %ebx
    9db9:      	cmpl	$0x5, %ebx
    9dbc:      	jg	0x9dfa <generic_kprobe_filter_arg+0x2f7a>
    9dbe:      	movq	0x20(%rsp), %rax
    9dc3:      	movb	%bpl, (%rax)
    9dc6:      	leaq	0x1(%rax), %rdi
    9dca:      	movl	$0x4, %eax
    9dcf:      	movq	0x18(%rsp), %rdx
    9dd4:      	movl	%ebp, %esi
    9dd6:      	callq	*%rax
    9dd8:      	movq	0x60(%rsp), %rsi
    9ddd:      	subl	%ebp, %esi
    9ddf:      	jbe	0x9e3a <generic_kprobe_filter_arg+0x2fba>
    9de1:      	movq	0x20(%rsp), %rax
    9de6:      	leaq	(%rax,%rbp), %rdi
    9dea:      	incq	%rdi
    9ded:      	andl	$0xfff, %esi            # imm = 0xFFF
    9df3:      	movl	$0x4, %eax
    9df8:      	jmp	0x9e35 <generic_kprobe_filter_arg+0x2fb5>
    9dfa:      	movq	0x20(%rsp), %rax
    9dff:      	movw	%bp, (%rax)
    9e02:      	leaq	0x2(%rax), %rdi
    9e06:      	movl	$0x4, %eax
    9e0b:      	movq	0x18(%rsp), %rdx
    9e10:      	movl	%ebp, %esi
    9e12:      	callq	*%rax
    9e14:      	movq	0x60(%rsp), %rsi
    9e19:      	subl	%ebp, %esi
    9e1b:      	jbe	0x9e3a <generic_kprobe_filter_arg+0x2fba>
    9e1d:      	movq	0x20(%rsp), %rax
    9e22:      	leaq	(%rax,%rbp), %rdi
    9e26:      	addq	$0x2, %rdi
    9e2a:      	andl	$0xfff, %esi            # imm = 0xFFF
    9e30:      	movl	$0x4, %eax
    9e35:      	movq	%r12, %rdx
    9e38:      	callq	*%rax
    9e3a:      	movl	0x90(%rsp), %eax
    9e41:      	movl	%eax, 0x38(%rsp)
    9e45:      	cmpl	$0x4, %ebx
    9e48:      	jle	0x9e84 <generic_kprobe_filter_arg+0x3004>
    9e4a:      	cmpl	$0x7, %ebx
    9e4d:      	jg	0xa289 <generic_kprobe_filter_arg+0x3409>
    9e53:      	cmpl	$0x5, %ebx
    9e56:      	je	0xa46e <generic_kprobe_filter_arg+0x35ee>
    9e5c:      	cmpl	$0x6, %ebx
    9e5f:      	je	0xa435 <generic_kprobe_filter_arg+0x35b5>
    9e65:      	cmpl	$0x7, %ebx
    9e68:      	jne	0xa4ab <generic_kprobe_filter_arg+0x362b>
    9e6e:      	movl	$0x1, %eax
    9e73:      	leaq	0x38(%rsp), %rsi
    9e78:      	movq	(%rip), %rdi            # 0x9e7f <generic_kprobe_filter_arg+0x2fff>
    9e7f:      	jmp	0xa492 <generic_kprobe_filter_arg+0x3612>
    9e84:      	cmpl	$0x1, %ebx
    9e87:      	jle	0xa374 <generic_kprobe_filter_arg+0x34f4>
    9e8d:      	cmpl	$0x2, %ebx
    9e90:      	je	0xa45b <generic_kprobe_filter_arg+0x35db>
    9e96:      	cmpl	$0x3, %ebx
    9e99:      	je	0xa422 <generic_kprobe_filter_arg+0x35a2>
    9e9f:      	cmpl	$0x4, %ebx
    9ea2:      	jne	0xa4ab <generic_kprobe_filter_arg+0x362b>
    9ea8:      	movl	$0x1, %eax
    9ead:      	leaq	0x38(%rsp), %rsi
    9eb2:      	movq	(%rip), %rdi            # 0x9eb9 <generic_kprobe_filter_arg+0x3039>
    9eb9:      	jmp	0xa492 <generic_kprobe_filter_arg+0x3612>
    9ebe:      	cmpl	%edx, %edi
    9ec0:      	setbe	%cl
    9ec3:      	cmpl	%esi, %edx
    9ec5:      	setbe	%dl
    9ec8:      	andb	%cl, %dl
    9eca:      	orb	%dl, %al
    9ecc:      	movq	(%rsp), %rdi
    9ed0:      	testb	%al, %al
    9ed2:      	je	0x7161 <generic_kprobe_filter_arg+0x2e1>
    9ed8:      	jmp	0x6f9d <generic_kprobe_filter_arg+0x11d>
    9edd:      	cmpq	%rsi, (%r12)
    9ee1:      	ja	0x7161 <generic_kprobe_filter_arg+0x2e1>
    9ee7:      	jmp	0x9ef3 <generic_kprobe_filter_arg+0x3073>
    9ee9:      	cmpq	%rsi, (%r12)
    9eed:      	jb	0x7161 <generic_kprobe_filter_arg+0x2e1>
    9ef3:      	cmpl	$0x21, %edx
    9ef6:      	jb	0xa541 <generic_kprobe_filter_arg+0x36c1>
    9efc:      	movq	0x28(%r13), %rdx
    9f00:      	cmpl	$0x2, %eax
    9f03:      	jle	0x9f2e <generic_kprobe_filter_arg+0x30ae>
    9f05:      	leal	-0x3(%rax), %ecx
    9f08:      	cmpl	$0x2, %ecx
    9f0b:      	jb	0x9f5d <generic_kprobe_filter_arg+0x30dd>
    9f0d:      	cmpl	$0x6, %eax
    9f10:      	je	0x7161 <generic_kprobe_filter_arg+0x2e1>
    9f16:      	cmpl	$0xc, %eax
    9f19:      	jne	0x6f9d <generic_kprobe_filter_arg+0x11d>
    9f1f:      	testq	%rdx, (%r12)
    9f23:      	jne	0x7161 <generic_kprobe_filter_arg+0x2e1>
    9f29:      	jmp	0xa541 <generic_kprobe_filter_arg+0x36c1>
    9f2e:      	cmpl	$0x1, %eax
    9f31:      	je	0xa055 <generic_kprobe_filter_arg+0x31d5>
    9f37:      	cmpl	$0x2, %eax
    9f3a:      	jne	0x6f9d <generic_kprobe_filter_arg+0x11d>
    9f40:      	cmpl	$0xc, %ecx
    9f43:      	je	0x9f4e <generic_kprobe_filter_arg+0x30ce>
    9f45:      	cmpl	$0xa, %ecx
    9f48:      	jne	0xa3f1 <generic_kprobe_filter_arg+0x3571>
    9f4e:      	cmpq	%rdx, (%r12)
    9f52:      	jl	0x7161 <generic_kprobe_filter_arg+0x2e1>
    9f58:      	jmp	0xa541 <generic_kprobe_filter_arg+0x36c1>
    9f5d:      	cmpq	%rdx, (%r12)
    9f61:      	jne	0xa541 <generic_kprobe_filter_arg+0x36c1>
    9f67:      	jmp	0x7145 <generic_kprobe_filter_arg+0x2c5>
    9f6c:      	cmpl	$0xc, %eax
    9f6f:      	jne	0xa1fb <generic_kprobe_filter_arg+0x337b>
    9f75:      	movzbl	(%r12), %esi
    9f7a:      	testl	%esi, %edx
    9f7c:      	jne	0x7161 <generic_kprobe_filter_arg+0x2e1>
    9f82:      	jmp	0xa1fb <generic_kprobe_filter_arg+0x337b>
    9f87:      	cmpl	$0xc, %eax
    9f8a:      	jne	0xa243 <generic_kprobe_filter_arg+0x33c3>
    9f90:      	movzwl	(%r12), %esi
    9f95:      	testl	%esi, %edx
    9f97:      	jne	0x7161 <generic_kprobe_filter_arg+0x2e1>
    9f9d:      	jmp	0xa243 <generic_kprobe_filter_arg+0x33c3>
    9fa2:      	movl	$0x1, %eax
    9fa7:      	movq	(%rip), %rdi            # 0x9fae <generic_kprobe_filter_arg+0x312e>
    9fae:      	leaq	0x38(%rsp), %rsi
    9fb3:      	jmp	0xa025 <generic_kprobe_filter_arg+0x31a5>
    9fb5:      	movl	$0x1, %eax
    9fba:      	leaq	0x38(%rsp), %rsi
    9fbf:      	movq	(%rip), %rdi            # 0x9fc6 <generic_kprobe_filter_arg+0x3146>
    9fc6:      	jmp	0xa025 <generic_kprobe_filter_arg+0x31a5>
    9fc8:      	movl	$0x1, %eax
    9fcd:      	leaq	0x38(%rsp), %rsi
    9fd2:      	movq	(%rip), %rdi            # 0x9fd9 <generic_kprobe_filter_arg+0x3159>
    9fd9:      	jmp	0xa025 <generic_kprobe_filter_arg+0x31a5>
    9fdb:      	movl	$0x1, %eax
    9fe0:      	leaq	0x38(%rsp), %rsi
    9fe5:      	movq	(%rip), %rdi            # 0x9fec <generic_kprobe_filter_arg+0x316c>
    9fec:      	jmp	0xa025 <generic_kprobe_filter_arg+0x31a5>
    9fee:      	movl	$0x1, %eax
    9ff3:      	leaq	0x38(%rsp), %rsi
    9ff8:      	movq	(%rip), %rdi            # 0x9fff <generic_kprobe_filter_arg+0x317f>
    9fff:      	jmp	0xa025 <generic_kprobe_filter_arg+0x31a5>
    a001:      	movl	$0x1, %eax
    a006:      	leaq	0x38(%rsp), %rsi
    a00b:      	movq	(%rip), %rdi            # 0xa012 <generic_kprobe_filter_arg+0x3192>
    a012:      	jmp	0xa025 <generic_kprobe_filter_arg+0x31a5>
    a014:      	movl	$0x1, %eax
    a019:      	leaq	0x38(%rsp), %rsi
    a01e:      	movq	(%rip), %rdi            # 0xa025 <generic_kprobe_filter_arg+0x31a5>
    a025:      	callq	*%rax
    a027:      	testq	%rax, %rax
    a02a:      	je	0xa113 <generic_kprobe_filter_arg+0x3293>
    a030:      	movq	%rax, %rdi
    a033:      	movl	$0x1, %eax
    a038:      	movq	%r12, %rsi
    a03b:      	jmp	0xa107 <generic_kprobe_filter_arg+0x3287>
    a040:      	cmpl	%eax, %esi
    a042:      	ja	0x6f9d <generic_kprobe_filter_arg+0x11d>
    a048:      	cmpl	%edx, %eax
    a04a:      	jbe	0x7161 <generic_kprobe_filter_arg+0x2e1>
    a050:      	jmp	0x6f9d <generic_kprobe_filter_arg+0x11d>
    a055:      	cmpl	$0xc, %ecx
    a058:      	je	0xa063 <generic_kprobe_filter_arg+0x31e3>
    a05a:      	cmpl	$0xa, %ecx
    a05d:      	jne	0xa400 <generic_kprobe_filter_arg+0x3580>
    a063:      	cmpq	%rdx, (%r12)
    a067:      	jg	0x7161 <generic_kprobe_filter_arg+0x2e1>
    a06d:      	jmp	0xa541 <generic_kprobe_filter_arg+0x36c1>
    a072:      	movl	$0x1, %eax
    a077:      	movq	(%rip), %rdi            # 0xa07e <generic_kprobe_filter_arg+0x31fe>
    a07e:      	leaq	0x38(%rsp), %rsi
    a083:      	jmp	0xa0f5 <generic_kprobe_filter_arg+0x3275>
    a085:      	movl	$0x1, %eax
    a08a:      	leaq	0x38(%rsp), %rsi
    a08f:      	movq	(%rip), %rdi            # 0xa096 <generic_kprobe_filter_arg+0x3216>
    a096:      	jmp	0xa0f5 <generic_kprobe_filter_arg+0x3275>
    a098:      	movl	$0x1, %eax
    a09d:      	leaq	0x38(%rsp), %rsi
    a0a2:      	movq	(%rip), %rdi            # 0xa0a9 <generic_kprobe_filter_arg+0x3229>
    a0a9:      	jmp	0xa0f5 <generic_kprobe_filter_arg+0x3275>
    a0ab:      	movl	$0x1, %eax
    a0b0:      	leaq	0x38(%rsp), %rsi
    a0b5:      	movq	(%rip), %rdi            # 0xa0bc <generic_kprobe_filter_arg+0x323c>
    a0bc:      	jmp	0xa0f5 <generic_kprobe_filter_arg+0x3275>
    a0be:      	movl	$0x1, %eax
    a0c3:      	leaq	0x38(%rsp), %rsi
    a0c8:      	movq	(%rip), %rdi            # 0xa0cf <generic_kprobe_filter_arg+0x324f>
    a0cf:      	jmp	0xa0f5 <generic_kprobe_filter_arg+0x3275>
    a0d1:      	movl	$0x1, %eax
    a0d6:      	leaq	0x38(%rsp), %rsi
    a0db:      	movq	(%rip), %rdi            # 0xa0e2 <generic_kprobe_filter_arg+0x3262>
    a0e2:      	jmp	0xa0f5 <generic_kprobe_filter_arg+0x3275>
    a0e4:      	movl	$0x1, %eax
    a0e9:      	leaq	0x38(%rsp), %rsi
    a0ee:      	movq	(%rip), %rdi            # 0xa0f5 <generic_kprobe_filter_arg+0x3275>
    a0f5:      	callq	*%rax
    a0f7:      	testq	%rax, %rax
    a0fa:      	je	0xa113 <generic_kprobe_filter_arg+0x3293>
    a0fc:      	movq	%rax, %rdi
    a0ff:      	movl	$0x1, %eax
    a104:      	movq	%rbp, %rsi
    a107:      	callq	*%rax
    a109:      	xorl	%ebx, %ebx
    a10b:      	testq	%rax, %rax
    a10e:      	setne	%bl
    a111:      	jmp	0xa115 <generic_kprobe_filter_arg+0x3295>
    a113:      	xorl	%ebx, %ebx
    a115:      	movq	(%rsp), %rdi
    a119:      	movq	0x8(%rsp), %r9
    a11e:      	movq	0x10(%rsp), %r11
    a123:      	movl	0x4(%r13), %eax
    a127:      	cmpq	$0x25, %rax
    a12b:      	ja	0x7150 <generic_kprobe_filter_arg+0x2d0>
    a131:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    a13b:      	btq	%rax, %rcx
    a13f:      	jae	0x7150 <generic_kprobe_filter_arg+0x2d0>
    a145:      	xorq	$0x1, %rbx
    a149:      	jmp	0x7150 <generic_kprobe_filter_arg+0x2d0>
    a14e:      	movl	$0x1, %eax
    a153:      	movq	(%rip), %rdi            # 0xa15a <generic_kprobe_filter_arg+0x32da>
    a15a:      	leaq	0x38(%rsp), %rsi
    a15f:      	jmp	0xa1d1 <generic_kprobe_filter_arg+0x3351>
    a161:      	movl	$0x1, %eax
    a166:      	leaq	0x38(%rsp), %rsi
    a16b:      	movq	(%rip), %rdi            # 0xa172 <generic_kprobe_filter_arg+0x32f2>
    a172:      	jmp	0xa1d1 <generic_kprobe_filter_arg+0x3351>
    a174:      	movl	$0x1, %eax
    a179:      	leaq	0x38(%rsp), %rsi
    a17e:      	movq	(%rip), %rdi            # 0xa185 <generic_kprobe_filter_arg+0x3305>
    a185:      	jmp	0xa1d1 <generic_kprobe_filter_arg+0x3351>
    a187:      	movl	$0x1, %eax
    a18c:      	leaq	0x38(%rsp), %rsi
    a191:      	movq	(%rip), %rdi            # 0xa198 <generic_kprobe_filter_arg+0x3318>
    a198:      	jmp	0xa1d1 <generic_kprobe_filter_arg+0x3351>
    a19a:      	movl	$0x1, %eax
    a19f:      	leaq	0x38(%rsp), %rsi
    a1a4:      	movq	(%rip), %rdi            # 0xa1ab <generic_kprobe_filter_arg+0x332b>
    a1ab:      	jmp	0xa1d1 <generic_kprobe_filter_arg+0x3351>
    a1ad:      	movl	$0x1, %eax
    a1b2:      	leaq	0x38(%rsp), %rsi
    a1b7:      	movq	(%rip), %rdi            # 0xa1be <generic_kprobe_filter_arg+0x333e>
    a1be:      	jmp	0xa1d1 <generic_kprobe_filter_arg+0x3351>
    a1c0:      	movl	$0x1, %eax
    a1c5:      	leaq	0x38(%rsp), %rsi
    a1ca:      	movq	(%rip), %rdi            # 0xa1d1 <generic_kprobe_filter_arg+0x3351>
    a1d1:      	callq	*%rax
    a1d3:      	testq	%rax, %rax
    a1d6:      	je	0xa4ab <generic_kprobe_filter_arg+0x362b>
    a1dc:      	movq	%rax, %rdi
    a1df:      	movl	$0x1, %eax
    a1e4:      	movq	0x20(%rsp), %rsi
    a1e9:      	jmp	0x8968 <generic_kprobe_filter_arg+0x1ae8>
    a1ee:      	movzbl	(%r12), %esi
    a1f3:      	cmpl	%esi, %edx
    a1f5:      	jb	0x7161 <generic_kprobe_filter_arg+0x2e1>
    a1fb:      	cmpl	$0x15, %ecx
    a1fe:      	jb	0xa541 <generic_kprobe_filter_arg+0x36c1>
    a204:      	movl	0x1c(%r13), %ecx
    a208:      	cmpl	$0x2, %eax
    a20b:      	jle	0xa39b <generic_kprobe_filter_arg+0x351b>
    a211:      	leal	-0x3(%rax), %edx
    a214:      	cmpl	$0x2, %edx
    a217:      	jb	0xa3d8 <generic_kprobe_filter_arg+0x3558>
    a21d:      	cmpl	$0x6, %eax
    a220:      	je	0x7161 <generic_kprobe_filter_arg+0x2e1>
    a226:      	cmpl	$0xc, %eax
    a229:      	jne	0x6f9d <generic_kprobe_filter_arg+0x11d>
    a22f:      	movzbl	(%r12), %edx
    a234:      	jmp	0xa27c <generic_kprobe_filter_arg+0x33fc>
    a236:      	movzwl	(%r12), %esi
    a23b:      	cmpl	%esi, %edx
    a23d:      	jb	0x7161 <generic_kprobe_filter_arg+0x2e1>
    a243:      	cmpl	$0x15, %ecx
    a246:      	jb	0xa541 <generic_kprobe_filter_arg+0x36c1>
    a24c:      	movl	0x1c(%r13), %ecx
    a250:      	cmpl	$0x2, %eax
    a253:      	jle	0xa3b4 <generic_kprobe_filter_arg+0x3534>
    a259:      	leal	-0x3(%rax), %edx
    a25c:      	cmpl	$0x2, %edx
    a25f:      	jb	0xa3df <generic_kprobe_filter_arg+0x355f>
    a265:      	cmpl	$0x6, %eax
    a268:      	je	0x7161 <generic_kprobe_filter_arg+0x2e1>
    a26e:      	cmpl	$0xc, %eax
    a271:      	jne	0x6f9d <generic_kprobe_filter_arg+0x11d>
    a277:      	movzwl	(%r12), %edx
    a27c:      	testl	%edx, %ecx
    a27e:      	jne	0x7161 <generic_kprobe_filter_arg+0x2e1>
    a284:      	jmp	0xa541 <generic_kprobe_filter_arg+0x36c1>
    a289:      	cmpl	$0x8, %ebx
    a28c:      	je	0xa481 <generic_kprobe_filter_arg+0x3601>
    a292:      	cmpl	$0x9, %ebx
    a295:      	je	0xa448 <generic_kprobe_filter_arg+0x35c8>
    a29b:      	cmpl	$0xa, %ebx
    a29e:      	jne	0xa4ab <generic_kprobe_filter_arg+0x362b>
    a2a4:      	movl	$0x1, %eax
    a2a9:      	leaq	0x38(%rsp), %rsi
    a2ae:      	movq	(%rip), %rdi            # 0xa2b5 <generic_kprobe_filter_arg+0x3435>
    a2b5:      	jmp	0xa492 <generic_kprobe_filter_arg+0x3612>
    a2ba:      	cmpl	%esi, (%r12)
    a2be:      	ja	0x7161 <generic_kprobe_filter_arg+0x2e1>
    a2c4:      	jmp	0xa2d0 <generic_kprobe_filter_arg+0x3450>
    a2c6:      	cmpl	%esi, (%r12)
    a2ca:      	jb	0x7161 <generic_kprobe_filter_arg+0x2e1>
    a2d0:      	cmpl	$0x15, %edx
    a2d3:      	jb	0xa541 <generic_kprobe_filter_arg+0x36c1>
    a2d9:      	movl	0x1c(%r13), %edx
    a2dd:      	cmpl	$0x2, %eax
    a2e0:      	jle	0xa30b <generic_kprobe_filter_arg+0x348b>
    a2e2:      	leal	-0x3(%rax), %ecx
    a2e5:      	cmpl	$0x2, %ecx
    a2e8:      	jb	0xa33f <generic_kprobe_filter_arg+0x34bf>
    a2ea:      	cmpl	$0x6, %eax
    a2ed:      	je	0x7161 <generic_kprobe_filter_arg+0x2e1>
    a2f3:      	cmpl	$0xc, %eax
    a2f6:      	jne	0x6f9d <generic_kprobe_filter_arg+0x11d>
    a2fc:      	testl	%edx, (%r12)
    a300:      	jne	0x7161 <generic_kprobe_filter_arg+0x2e1>
    a306:      	jmp	0xa541 <generic_kprobe_filter_arg+0x36c1>
    a30b:      	cmpl	$0x1, %eax
    a30e:      	je	0xa34e <generic_kprobe_filter_arg+0x34ce>
    a310:      	cmpl	$0x2, %eax
    a313:      	jne	0x6f9d <generic_kprobe_filter_arg+0x11d>
    a319:      	cmpl	$0xc, %ecx
    a31c:      	ja	0xa52b <generic_kprobe_filter_arg+0x36ab>
    a322:      	movl	$0x1402, %esi           # imm = 0x1402
    a327:      	btl	%ecx, %esi
    a32a:      	jae	0xa52b <generic_kprobe_filter_arg+0x36ab>
    a330:      	cmpl	%edx, (%r12)
    a334:      	jl	0x7161 <generic_kprobe_filter_arg+0x2e1>
    a33a:      	jmp	0xa541 <generic_kprobe_filter_arg+0x36c1>
    a33f:      	cmpl	%edx, (%r12)
    a343:      	je	0x7145 <generic_kprobe_filter_arg+0x2c5>
    a349:      	jmp	0xa541 <generic_kprobe_filter_arg+0x36c1>
    a34e:      	cmpl	$0xc, %ecx
    a351:      	ja	0xa537 <generic_kprobe_filter_arg+0x36b7>
    a357:      	movl	$0x1402, %esi           # imm = 0x1402
    a35c:      	btl	%ecx, %esi
    a35f:      	jae	0xa537 <generic_kprobe_filter_arg+0x36b7>
    a365:      	cmpl	%edx, (%r12)
    a369:      	jg	0x7161 <generic_kprobe_filter_arg+0x2e1>
    a36f:      	jmp	0xa541 <generic_kprobe_filter_arg+0x36c1>
    a374:      	testl	%ebx, %ebx
    a376:      	je	0xa40f <generic_kprobe_filter_arg+0x358f>
    a37c:      	cmpl	$0x1, %ebx
    a37f:      	jne	0xa4ab <generic_kprobe_filter_arg+0x362b>
    a385:      	movl	$0x1, %eax
    a38a:      	leaq	0x38(%rsp), %rsi
    a38f:      	movq	(%rip), %rdi            # 0xa396 <generic_kprobe_filter_arg+0x3516>
    a396:      	jmp	0xa492 <generic_kprobe_filter_arg+0x3612>
    a39b:      	cmpl	$0x1, %eax
    a39e:      	je	0xa515 <generic_kprobe_filter_arg+0x3695>
    a3a4:      	cmpl	$0x2, %eax
    a3a7:      	jne	0x6f9d <generic_kprobe_filter_arg+0x11d>
    a3ad:      	movzbl	(%r12), %edx
    a3b2:      	jmp	0xa3cb <generic_kprobe_filter_arg+0x354b>
    a3b4:      	cmpl	$0x1, %eax
    a3b7:      	je	0xa51c <generic_kprobe_filter_arg+0x369c>
    a3bd:      	cmpl	$0x2, %eax
    a3c0:      	jne	0x6f9d <generic_kprobe_filter_arg+0x11d>
    a3c6:      	movzwl	(%r12), %edx
    a3cb:      	cmpl	%edx, %ecx
    a3cd:      	ja	0x7161 <generic_kprobe_filter_arg+0x2e1>
    a3d3:      	jmp	0xa541 <generic_kprobe_filter_arg+0x36c1>
    a3d8:      	movzbl	(%r12), %edx
    a3dd:      	jmp	0xa3e4 <generic_kprobe_filter_arg+0x3564>
    a3df:      	movzwl	(%r12), %edx
    a3e4:      	cmpl	%edx, %ecx
    a3e6:      	je	0x7145 <generic_kprobe_filter_arg+0x2c5>
    a3ec:      	jmp	0xa541 <generic_kprobe_filter_arg+0x36c1>
    a3f1:      	cmpq	%rdx, (%r12)
    a3f5:      	jb	0x7161 <generic_kprobe_filter_arg+0x2e1>
    a3fb:      	jmp	0xa541 <generic_kprobe_filter_arg+0x36c1>
    a400:      	cmpq	%rdx, (%r12)
    a404:      	ja	0x7161 <generic_kprobe_filter_arg+0x2e1>
    a40a:      	jmp	0xa541 <generic_kprobe_filter_arg+0x36c1>
    a40f:      	movl	$0x1, %eax
    a414:      	movq	(%rip), %rdi            # 0xa41b <generic_kprobe_filter_arg+0x359b>
    a41b:      	leaq	0x38(%rsp), %rsi
    a420:      	jmp	0xa492 <generic_kprobe_filter_arg+0x3612>
    a422:      	movl	$0x1, %eax
    a427:      	leaq	0x38(%rsp), %rsi
    a42c:      	movq	(%rip), %rdi            # 0xa433 <generic_kprobe_filter_arg+0x35b3>
    a433:      	jmp	0xa492 <generic_kprobe_filter_arg+0x3612>
    a435:      	movl	$0x1, %eax
    a43a:      	leaq	0x38(%rsp), %rsi
    a43f:      	movq	(%rip), %rdi            # 0xa446 <generic_kprobe_filter_arg+0x35c6>
    a446:      	jmp	0xa492 <generic_kprobe_filter_arg+0x3612>
    a448:      	movl	$0x1, %eax
    a44d:      	leaq	0x38(%rsp), %rsi
    a452:      	movq	(%rip), %rdi            # 0xa459 <generic_kprobe_filter_arg+0x35d9>
    a459:      	jmp	0xa492 <generic_kprobe_filter_arg+0x3612>
    a45b:      	movl	$0x1, %eax
    a460:      	leaq	0x38(%rsp), %rsi
    a465:      	movq	(%rip), %rdi            # 0xa46c <generic_kprobe_filter_arg+0x35ec>
    a46c:      	jmp	0xa492 <generic_kprobe_filter_arg+0x3612>
    a46e:      	movl	$0x1, %eax
    a473:      	leaq	0x38(%rsp), %rsi
    a478:      	movq	(%rip), %rdi            # 0xa47f <generic_kprobe_filter_arg+0x35ff>
    a47f:      	jmp	0xa492 <generic_kprobe_filter_arg+0x3612>
    a481:      	movl	$0x1, %eax
    a486:      	leaq	0x38(%rsp), %rsi
    a48b:      	movq	(%rip), %rdi            # 0xa492 <generic_kprobe_filter_arg+0x3612>
    a492:      	callq	*%rax
    a494:      	testq	%rax, %rax
    a497:      	je	0xa4ab <generic_kprobe_filter_arg+0x362b>
    a499:      	movq	%rax, %rdi
    a49c:      	movl	$0x1, %eax
    a4a1:      	movq	0x20(%rsp), %rsi
    a4a6:      	jmp	0x8968 <generic_kprobe_filter_arg+0x1ae8>
    a4ab:      	xorl	%ebx, %ebx
    a4ad:      	movq	(%rsp), %rdi
    a4b1:      	movq	0x8(%rsp), %r9
    a4b6:      	movq	0x10(%rsp), %r11
    a4bb:      	movl	0x4(%r13), %eax
    a4bf:      	cmpq	$0x25, %rax
    a4c3:      	ja	0x7150 <generic_kprobe_filter_arg+0x2d0>
    a4c9:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    a4d3:      	btq	%rax, %rcx
    a4d7:      	jae	0x7150 <generic_kprobe_filter_arg+0x2d0>
    a4dd:      	xorl	%eax, %eax
    a4df:      	testq	%rbx, %rbx
    a4e2:      	sete	%al
    a4e5:      	movq	%rax, %rbx
    a4e8:      	jmp	0x7150 <generic_kprobe_filter_arg+0x2d0>
    a4ed:      	xorl	%ebx, %ebx
    a4ef:      	movq	(%rsp), %rdi
    a4f3:      	movq	0x8(%rsp), %r9
    a4f8:      	movq	0x10(%rsp), %r11
    a4fd:      	movq	0x68(%rsp), %r15
    a502:      	movl	0x4(%r13), %eax
    a506:      	cmpq	$0x25, %rax
    a50a:      	jbe	0xa131 <generic_kprobe_filter_arg+0x32b1>
    a510:      	jmp	0x7150 <generic_kprobe_filter_arg+0x2d0>
    a515:      	movzbl	(%r12), %edx
    a51a:      	jmp	0xa521 <generic_kprobe_filter_arg+0x36a1>
    a51c:      	movzwl	(%r12), %edx
    a521:      	cmpl	%edx, %ecx
    a523:      	jb	0x7161 <generic_kprobe_filter_arg+0x2e1>
    a529:      	jmp	0xa541 <generic_kprobe_filter_arg+0x36c1>
    a52b:      	cmpl	%edx, (%r12)
    a52f:      	jb	0x7161 <generic_kprobe_filter_arg+0x2e1>
    a535:      	jmp	0xa541 <generic_kprobe_filter_arg+0x36c1>
    a537:      	cmpl	%edx, (%r12)
    a53b:      	ja	0x7161 <generic_kprobe_filter_arg+0x2e1>
    a541:      	orl	$0x2, %eax
    a544:      	cmpl	$0x6, %eax
    a547:      	je	0x7161 <generic_kprobe_filter_arg+0x2e1>
    a54d:      	jmp	0x6f9d <generic_kprobe_filter_arg+0x11d>
    a552:      	nopw	%cs:(%rax,%rax)

000000000000a560 <generic_kprobe_actions>:
    a560:      	pushq	%rbp
    a561:      	pushq	%r15
    a563:      	pushq	%r14
    a565:      	pushq	%r13
    a567:      	pushq	%r12
    a569:      	pushq	%rbx
    a56a:      	subq	$0xa8, %rsp
    a571:      	movq	%rdi, 0x88(%rsp)
    a579:      	movl	$0x0, 0x94(%rsp)
    a584:      	movq	(%rip), %rdi            # 0xa58b <generic_kprobe_actions+0x2b>
    a58b:      	leaq	0x94(%rsp), %rsi
    a593:      	movl	$0x1, %eax
    a598:      	callq	*%rax
    a59a:      	testq	%rax, %rax
    a59d:      	je	0xb313 <generic_kprobe_actions+0xdb3>
    a5a3:      	movq	%rax, %rsi
    a5a6:      	movl	0x5f04(%rax), %ebx
    a5ac:      	cmpl	$0x2, %ebx
    a5af:      	jl	0xb313 <generic_kprobe_actions+0xdb3>
    a5b5:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    a5bc:      	movq	(%rip), %rdi            # 0xa5c3 <generic_kprobe_actions+0x63>
    a5c3:      	movl	$0x1, %eax
    a5c8:      	callq	*%rax
    a5ca:      	testq	%rax, %rax
    a5cd:      	je	0xb313 <generic_kprobe_actions+0xdb3>
    a5d3:      	movq	%rax, %r14
    a5d6:      	movl	%ebx, %eax
    a5d8:      	andl	$0x7ff, %eax            # imm = 0x7FF
    a5dd:      	addl	(%r14,%rax), %ebx
    a5e1:      	movl	$0x0, 0x98(%rsp)
    a5ec:      	movq	(%rip), %rdi            # 0xa5f3 <generic_kprobe_actions+0x93>
    a5f3:      	leaq	0x98(%rsp), %rsi
    a5fb:      	movl	$0x1, %eax
    a600:      	andl	$0x7ff, %ebx            # imm = 0x7FF
    a606:      	callq	*%rax
    a608:      	movb	$0x1, %cl
    a60a:      	movl	%ecx, 0x5c(%rsp)
    a60e:      	testq	%rax, %rax
    a611:      	je	0xa62e <generic_kprobe_actions+0xce>
    a613:      	xorl	%ecx, %ecx
    a615:      	cmpb	$0x0, (%rax)
    a618:      	sete	%cl
    a61b:      	movq	%rcx, 0x78(%rsp)
    a620:      	xorq	$0x9, %rcx
    a624:      	movq	%rcx, 0xa0(%rsp)
    a62c:      	jmp	0xa642 <generic_kprobe_actions+0xe2>
    a62e:      	movl	$0x8, %eax
    a633:      	movq	%rax, 0xa0(%rsp)
    a63b:      	movb	$0x1, %al
    a63d:      	movq	%rax, 0x78(%rsp)
    a642:      	addq	%rbx, %r14
    a645:      	xorl	%r13d, %r13d
    a648:      	xorl	%r15d, %r15d
    a64b:      	movq	%r14, 0x30(%rsp)
    a650:      	jmp	0xa67a <generic_kprobe_actions+0x11a>
    a652:      	incl	%r15d
    a655:      	movl	0x4(%r14,%r15,4), %eax
    a65a:      	movl	%eax, 0x78(%rdx)
    a65d:      	nopl	(%rax)
    a660:      	movq	%r12, 0x70(%rdx)
    a664:      	incl	%r15d
    a667:      	movl	%r15d, %ebx
    a66a:      	incl	%r13d
    a66d:      	movl	%ebx, %r15d
    a670:      	cmpl	$0x3, %r13d
    a674:      	je	0xb2ec <generic_kprobe_actions+0xd8c>
    a67a:      	leal	0x4(,%r15,4), %eax
    a682:      	cmpl	(%r14), %eax
    a685:      	jae	0xb2ec <generic_kprobe_actions+0xd8c>
    a68b:      	movl	%r15d, %eax
    a68e:      	movslq	0x4(%r14,%rax,4), %r12
    a693:      	movl	$0x0, 0x9c(%rsp)
    a69e:      	movl	$0x1, %eax
    a6a3:      	movq	(%rip), %rdi            # 0xa6aa <generic_kprobe_actions+0x14a>
    a6aa:      	leaq	0x9c(%rsp), %rsi
    a6b2:      	callq	*%rax
    a6b4:      	xorl	%ebx, %ebx
    a6b6:      	testq	%rax, %rax
    a6b9:      	je	0xa66a <generic_kprobe_actions+0x10a>
    a6bb:      	movq	%rax, %rdx
    a6be:      	cmpl	$0x7, %r12d
    a6c2:      	jg	0xa6f0 <generic_kprobe_actions+0x190>
    a6c4:      	cmpl	$0x3, %r12d
    a6c8:      	jg	0xa72e <generic_kprobe_actions+0x1ce>
    a6ca:      	cmpl	$0x1, %r12d
    a6ce:      	jg	0xa87c <generic_kprobe_actions+0x31c>
    a6d4:      	testl	%r12d, %r12d
    a6d7:      	je	0xaaf5 <generic_kprobe_actions+0x595>
    a6dd:      	cmpl	$0x1, %r12d
    a6e1:      	je	0xa895 <generic_kprobe_actions+0x335>
    a6e7:      	jmp	0xa660 <generic_kprobe_actions+0x100>
    a6ec:      	nopl	(%rax)
    a6f0:      	cmpl	$0xb, %r12d
    a6f4:      	jg	0xa848 <generic_kprobe_actions+0x2e8>
    a6fa:      	leal	-0xa(%r12), %eax
    a6ff:      	cmpl	$0x2, %eax
    a702:      	jb	0xa918 <generic_kprobe_actions+0x3b8>
    a708:      	cmpl	$0x8, %r12d
    a70c:      	je	0xa9d6 <generic_kprobe_actions+0x476>
    a712:      	cmpl	$0x9, %r12d
    a716:      	jne	0xa660 <generic_kprobe_actions+0x100>
    a71c:      	movq	%rdx, 0x18(%rsp)
    a721:      	incl	%r15d
    a724:      	movl	0x4(%r14,%r15,4), %eax
    a729:      	jmp	0xabb8 <generic_kprobe_actions+0x658>
    a72e:      	leal	-0x6(%r12), %eax
    a733:      	cmpl	$0x2, %eax
    a736:      	jb	0xa652 <generic_kprobe_actions+0xf2>
    a73c:      	cmpl	$0x4, %r12d
    a740:      	je	0xa9e3 <generic_kprobe_actions+0x483>
    a746:      	cmpl	$0x5, %r12d
    a74a:      	jne	0xa660 <generic_kprobe_actions+0x100>
    a750:      	leal	0x1(%r15), %eax
    a754:      	movl	0x4(%r14,%rax,4), %eax
    a759:      	addl	$0x2, %r15d
    a75d:      	movl	0x4(%r14,%r15,4), %ebx
    a762:      	movq	$0x0, 0x10(%rsp)
    a76b:      	movq	$0x0, 0x8(%rsp)
    a774:      	andl	$0x7, %eax
    a777:      	cmpl	$0x4, %eax
    a77a:      	ja	0xa660 <generic_kprobe_actions+0x100>
    a780:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    a788:      	jne	0xa660 <generic_kprobe_actions+0x100>
    a78e:      	movq	0x5e78(%rdx,%rax,8), %rax
    a796:      	andl	$0x7ff, %eax            # imm = 0x7FF
    a79b:      	movl	0x90(%rdx,%rax), %eax
    a7a2:      	movl	%eax, 0x10(%rsp)
    a7a6:      	movl	$0xe, %eax
    a7ab:      	movq	%rdx, %rbp
    a7ae:      	callq	*%rax
    a7b0:      	shrq	$0x20, %rax
    a7b4:      	movq	%rax, 0x8(%rsp)
    a7b9:      	movl	$0x1, %eax
    a7be:      	leaq	0x8(%rsp), %rsi
    a7c3:      	movq	(%rip), %rdi            # 0xa7ca <generic_kprobe_actions+0x26a>
    a7ca:      	callq	*%rax
    a7cc:      	movq	%rbp, %rdx
    a7cf:      	testq	%rax, %rax
    a7d2:      	je	0xa660 <generic_kprobe_actions+0x100>
    a7d8:      	andl	$0x7, %ebx
    a7db:      	cmpl	$0x4, %ebx
    a7de:      	ja	0xa660 <generic_kprobe_actions+0x100>
    a7e4:      	cmpl	$0x0, 0x5ea0(%rdx,%rbx,4)
    a7ec:      	jne	0xa660 <generic_kprobe_actions+0x100>
    a7f2:      	movq	0x5e78(%rdx,%rbx,8), %rcx
    a7fa:      	movl	$0x0, 0x14(%rsp)
    a802:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    a808:      	movl	0x90(%rdx,%rcx), %ecx
    a80f:      	movl	%ecx, 0x10(%rsp)
    a813:      	movq	%rax, %rbx
    a816:      	movl	$0xe, %eax
    a81b:      	callq	*%rax
    a81d:      	shrq	$0x20, %rax
    a821:      	movq	%rax, 0x8(%rsp)
    a826:      	movl	$0x2, %eax
    a82b:      	xorl	%ecx, %ecx
    a82d:      	leaq	0x8(%rsp), %rsi
    a832:      	movq	(%rip), %rdi            # 0xa839 <generic_kprobe_actions+0x2d9>
    a839:      	movq	%rbx, %rdx
    a83c:      	xorl	%ecx, %ecx
    a83e:      	callq	*%rax
    a840:      	movq	%rbp, %rdx
    a843:      	jmp	0xa660 <generic_kprobe_actions+0x100>
    a848:      	cmpl	$0xc, %r12d
    a84c:      	movq	%rdx, 0x18(%rsp)
    a851:      	je	0xabec <generic_kprobe_actions+0x68c>
    a857:      	cmpl	$0xd, %r12d
    a85b:      	je	0xaa77 <generic_kprobe_actions+0x517>
    a861:      	cmpl	$0xe, %r12d
    a865:      	jne	0xa660 <generic_kprobe_actions+0x100>
    a86b:      	addl	$0x2, %r15d
    a86f:      	movq	0xa0(%rsp), %r14
    a877:      	jmp	0xaebd <generic_kprobe_actions+0x95d>
    a87c:      	movl	$0x9, %eax
    a881:      	cmpl	$0x2, %r12d
    a885:      	je	0xabb3 <generic_kprobe_actions+0x653>
    a88b:      	cmpl	$0x3, %r12d
    a88f:      	jne	0xa660 <generic_kprobe_actions+0x100>
    a895:      	movq	%rdx, %rbp
    a898:      	leal	0x1(%r15), %eax
    a89c:      	movq	%r14, %rcx
    a89f:      	movl	0x4(%r14,%rax,4), %r14d
    a8a4:      	addl	$0x2, %r15d
    a8a8:      	movl	0x4(%rcx,%r15,4), %eax
    a8ad:      	movq	%rax, 0x50(%rsp)
    a8b2:      	movq	$0x0, 0x10(%rsp)
    a8bb:      	movq	$0x0, 0x8(%rsp)
    a8c4:      	movl	$0x0, 0x20(%rsp)
    a8cc:      	movl	$0x1, %eax
    a8d1:      	leaq	0x20(%rsp), %rsi
    a8d6:      	movq	(%rip), %rdi            # 0xa8dd <generic_kprobe_actions+0x37d>
    a8dd:      	callq	*%rax
    a8df:      	xorl	%ecx, %ecx
    a8e1:      	testq	%rax, %rax
    a8e4:      	je	0xaf0d <generic_kprobe_actions+0x9ad>
    a8ea:      	andl	$0x7, %r14d
    a8ee:      	cmpl	$0x4, %r14d
    a8f2:      	movq	%rbp, %rdx
    a8f5:      	ja	0xa906 <generic_kprobe_actions+0x3a6>
    a8f7:      	cmpl	$0x0, 0x5ea0(%rdx,%r14,4)
    a900:      	je	0xacdb <generic_kprobe_actions+0x77b>
    a906:      	movq	0x30(%rsp), %r14
    a90b:      	testl	%ecx, %ecx
    a90d:      	jne	0xa66a <generic_kprobe_actions+0x10a>
    a913:      	jmp	0xa660 <generic_kprobe_actions+0x100>
    a918:      	incl	%r15d
    a91b:      	movl	0x4(%r14,%r15,4), %eax
    a920:      	andl	$0x7, %eax
    a923:      	xorl	%ecx, %ecx
    a925:      	cmpl	$0x4, %eax
    a928:      	ja	0xaf15 <generic_kprobe_actions+0x9b5>
    a92e:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    a936:      	jne	0xaf15 <generic_kprobe_actions+0x9b5>
    a93c:      	movq	0x5e78(%rdx,%rax,8), %rax
    a944:      	andl	$0x7ff, %eax            # imm = 0x7FF
    a949:      	movq	0xb8(%rdx,%rax), %rax
    a951:      	movq	%rax, 0x20(%rsp)
    a956:      	testq	%rax, %rax
    a959:      	je	0xaf15 <generic_kprobe_actions+0x9b5>
    a95f:      	movq	%rdx, %rbp
    a962:      	cmpl	$0xa, %r12d
    a966:      	jne	0xaf22 <generic_kprobe_actions+0x9c2>
    a96c:      	movl	$0xe, %eax
    a971:      	callq	*%rax
    a973:      	movq	%rax, 0x50(%rsp)
    a978:      	shrq	$0x20, %rax
    a97c:      	movl	%eax, 0x8(%rsp)
    a980:      	movl	$0x1, %eax
    a985:      	leaq	0x8(%rsp), %rsi
    a98a:      	movq	(%rip), %rdi            # 0xa991 <generic_kprobe_actions+0x431>
    a991:      	callq	*%rax
    a993:      	xorl	%ecx, %ecx
    a995:      	testq	%rax, %rax
    a998:      	movq	%rbp, %rdx
    a99b:      	je	0xaf15 <generic_kprobe_actions+0x9b5>
    a9a1:      	movl	(%rax), %ecx
    a9a3:      	movl	%ecx, 0x8(%rsp)
    a9a7:      	movq	0x50(%rsp), %rcx
    a9ac:      	movl	%ecx, 0xc(%rsp)
    a9b0:      	movq	0x8(%rax), %rax
    a9b4:      	movq	%rax, 0x10(%rsp)
    a9b9:      	xorl	%ecx, %ecx
    a9bb:      	movl	$0x2, %eax
    a9c0:      	leaq	0x20(%rsp), %rsi
    a9c5:      	leaq	0x8(%rsp), %rdx
    a9ca:      	movq	(%rip), %rdi            # 0xa9d1 <generic_kprobe_actions+0x471>
    a9d1:      	jmp	0xad92 <generic_kprobe_actions+0x832>
    a9d6:      	movl	$0x0, 0x5c(%rsp)
    a9de:      	jmp	0xa660 <generic_kprobe_actions+0x100>
    a9e3:      	movq	%rdx, 0x18(%rsp)
    a9e8:      	incl	%r15d
    a9eb:      	movl	$0x5, %r14d
    a9f1:      	cmpb	$0x0, 0x78(%rsp)
    a9f6:      	je	0xaebd <generic_kprobe_actions+0x95d>
    a9fc:      	movl	%r15d, %eax
    a9ff:      	movq	0x30(%rsp), %rcx
    aa04:      	movl	0x4(%rcx,%rax,4), %eax
    aa08:      	movl	%eax, 0x60(%rsp)
    aa0c:      	movl	$0xe, %eax
    aa11:      	callq	*%rax
    aa13:      	movq	%rax, 0x20(%rsp)
    aa18:      	movl	$0x1, %eax
    aa1d:      	leaq	0x20(%rsp), %r14
    aa22:      	movq	(%rip), %rbp            # 0xaa29 <generic_kprobe_actions+0x4c9>
    aa29:      	movq	%rbp, %rdi
    aa2c:      	movq	%r14, %rsi
    aa2f:      	callq	*%rax
    aa31:      	testq	%rax, %rax
    aa34:      	je	0xae0e <generic_kprobe_actions+0x8ae>
    aa3a:      	movq	%rax, %rbx
    aa3d:      	movl	$0xe0011, 0x8(%rsp)     # imm = 0xE0011
    aa45:      	movq	$0x35c, 0xc(%rsp)       # imm = 0x35C
    aa4e:      	movl	$0x1, %eax
    aa53:      	leaq	0x8(%rsp), %r14
    aa58:      	movq	(%rip), %rbp            # 0xaa5f <generic_kprobe_actions+0x4ff>
    aa5f:      	movq	%rbp, %rdi
    aa62:      	movq	%r14, %rsi
    aa65:      	callq	*%rax
    aa67:      	testq	%rax, %rax
    aa6a:      	je	0xae93 <generic_kprobe_actions+0x933>
    aa70:      	incl	(%rax)
    aa72:      	jmp	0xaeb1 <generic_kprobe_actions+0x951>
    aa77:      	movl	$0xe, %eax
    aa7c:      	callq	*%rax
    aa7e:      	movq	%rax, 0x40(%rsp)
    aa83:      	movl	$0x1, %eax
    aa88:      	leaq	0x40(%rsp), %rsi
    aa8d:      	movq	(%rip), %rdi            # 0xaa94 <generic_kprobe_actions+0x534>
    aa94:      	callq	*%rax
    aa96:      	testq	%rax, %rax
    aa99:      	je	0xaeed <generic_kprobe_actions+0x98d>
    aa9f:      	movq	0x4(%rax), %rax
    aaa3:      	movq	%rax, 0x20(%rsp)
    aaa8:      	movl	$0x2, 0x28(%rsp)
    aab0:      	movl	$0x1, %eax
    aab5:      	leaq	0x20(%rsp), %rbx
    aaba:      	movq	(%rip), %rbp            # 0xaac1 <generic_kprobe_actions+0x561>
    aac1:      	movq	%rbp, %rdi
    aac4:      	movq	%rbx, %rsi
    aac7:      	callq	*%rax
    aac9:      	movl	$0x1, 0x3c(%rsp)
    aad1:      	testq	%rax, %rax
    aad4:      	je	0xada8 <generic_kprobe_actions+0x848>
    aada:      	lock
    aadb:      	incl	(%rax)
    aadd:      	movl	$0x3, %eax
    aae2:      	leaq	0x40(%rsp), %rsi
    aae7:      	movq	(%rip), %rdi            # 0xaaee <generic_kprobe_actions+0x58e>
    aaee:      	callq	*%rax
    aaf0:      	jmp	0xaeed <generic_kprobe_actions+0x98d>
    aaf5:      	movq	%rdx, 0x18(%rsp)
    aafa:      	leal	0x1(%r15), %eax
    aafe:      	movl	0x4(%r14,%rax,4), %ebp
    ab03:      	leal	0x2(%r15), %eax
    ab07:      	movl	0x4(%r14,%rax,4), %ebx
    ab0c:      	movl	$0x7d, %eax
    ab11:      	callq	*%rax
    ab13:      	movq	%rax, 0x8(%rsp)
    ab18:      	movl	$0x0, 0x40(%rsp)
    ab20:      	movq	%rbp, 0x70(%rsp)
    ab25:      	testq	%rbp, %rbp
    ab28:      	je	0xb173 <generic_kprobe_actions+0xc13>
    ab2e:      	movl	$0x1, %eax
    ab33:      	movq	(%rip), %rdi            # 0xab3a <generic_kprobe_actions+0x5da>
    ab3a:      	leaq	0x40(%rsp), %rsi
    ab3f:      	callq	*%rax
    ab41:      	testq	%rax, %rax
    ab44:      	je	0xb173 <generic_kprobe_actions+0xc13>
    ab4a:      	movq	%rax, 0x50(%rsp)
    ab4f:      	movq	%rax, %rbp
    ab52:      	movl	$0x1, %eax
    ab57:      	leaq	0x40(%rsp), %rsi
    ab5c:      	movq	(%rip), %rdi            # 0xab63 <generic_kprobe_actions+0x603>
    ab63:      	callq	*%rax
    ab65:      	movq	%rax, %rdx
    ab68:      	movq	0x18(%rsp), %rcx
    ab6d:      	movq	0x60(%rcx), %rax
    ab71:      	movq	%rax, (%rbp)
    ab75:      	movq	0x70(%rcx), %rax
    ab79:      	movq	%rbp, 0x80(%rsp)
    ab81:      	movq	%rax, 0x8(%rbp)
    ab85:      	xorl	%ebp, %ebp
    ab87:      	movl	$0x0, %eax
    ab8c:      	cmpl	$0x2, %ebx
    ab8f:      	je	0xafae <generic_kprobe_actions+0xa4e>
    ab95:      	cmpl	$0x1, %ebx
    ab98:      	je	0xafab <generic_kprobe_actions+0xa4b>
    ab9e:      	testl	%ebx, %ebx
    aba0:      	jne	0xb173 <generic_kprobe_actions+0xc13>
    aba6:      	movq	0x18(%rsp), %rax
    abab:      	movl	0x7c(%rax), %eax
    abae:      	jmp	0xafae <generic_kprobe_actions+0xa4e>
    abb3:      	movq	%rdx, 0x18(%rsp)
    abb8:      	movl	%r15d, %ebx
    abbb:      	movl	$0x3, %r14d
    abc1:      	cmpb	$0x0, 0x78(%rsp)
    abc6:      	leaq	0x8(%rsp), %rsi
    abcb:      	je	0xaec5 <generic_kprobe_actions+0x965>
    abd1:      	movslq	%eax, %rdi
    abd4:      	movl	$0x6d, %eax
    abd9:      	movq	%rsi, %r14
    abdc:      	callq	*%rax
    abde:      	movq	%r14, %rsi
    abe1:      	movl	$0x2, %r14d
    abe7:      	jmp	0xaec5 <generic_kprobe_actions+0x965>
    abec:      	leal	0x3(%r15), %ebx
    abf0:      	movl	$0x7, %r14d
    abf6:      	cmpb	$0x0, 0x78(%rsp)
    abfb:      	je	0xaec0 <generic_kprobe_actions+0x960>
    ac01:      	movl	%ebx, %eax
    ac03:      	movq	0x30(%rsp), %rcx
    ac08:      	movl	0x4(%rcx,%rax,4), %eax
    ac0c:      	cmpq	$0x4, %rax
    ac10:      	ja	0xac20 <generic_kprobe_actions+0x6c0>
    ac12:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    ac1a:      	je	0xb203 <generic_kprobe_actions+0xca3>
    ac20:      	xorl	%r14d, %r14d
    ac23:      	leal	0x2(%r15), %eax
    ac27:      	incl	%r15d
    ac2a:      	movq	0x30(%rsp), %rcx
    ac2f:      	movl	0x4(%rcx,%rax,4), %ebp
    ac33:      	movl	0x4(%rcx,%r15,4), %r15d
    ac38:      	movl	0x60(%rdx), %ecx
    ac3b:      	movl	$0xe, %eax
    ac40:      	shlq	$0x20, %r14
    ac44:      	orq	%rcx, %r14
    ac47:      	callq	*%rax
    ac49:      	movq	%rax, 0x60(%rsp)
    ac4e:      	movw	%r15w, 0x20(%rsp)
    ac54:      	movw	%bp, 0x22(%rsp)
    ac59:      	movq	%r14, 0x24(%rsp)
    ac5e:      	movl	$0x1, %eax
    ac63:      	leaq	0x60(%rsp), %r14
    ac68:      	movq	(%rip), %rbp            # 0xac6f <generic_kprobe_actions+0x70f>
    ac6f:      	movq	%rbp, %rdi
    ac72:      	movq	%r14, %rsi
    ac75:      	callq	*%rax
    ac77:      	testq	%rax, %rax
    ac7a:      	je	0xae29 <generic_kprobe_actions+0x8c9>
    ac80:      	movq	%rax, %r15
    ac83:      	movq	0x4(%rax), %rax
    ac87:      	movq	%rax, 0x40(%rsp)
    ac8c:      	movl	$0x1, 0x48(%rsp)
    ac94:      	movl	$0x1, %eax
    ac99:      	leaq	0x40(%rsp), %rbp
    ac9e:      	movq	(%rip), %r14            # 0xaca5 <generic_kprobe_actions+0x745>
    aca5:      	movq	%r14, %rdi
    aca8:      	movq	%rbp, %rsi
    acab:      	callq	*%rax
    acad:      	movl	$0x1, 0x6c(%rsp)
    acb5:      	testq	%rax, %rax
    acb8:      	je	0xaf48 <generic_kprobe_actions+0x9e8>
    acbe:      	lock
    acbf:      	incl	(%rax)
    acc1:      	movl	0x28(%rsp), %eax
    acc5:      	movl	%eax, 0x8(%r15)
    acc9:      	movq	0x20(%rsp), %rax
    acce:      	movq	%rax, (%r15)
    acd1:      	leaq	0x8(%rsp), %rsi
    acd6:      	jmp	0xb28e <generic_kprobe_actions+0xd2e>
    acdb:      	movq	%rax, 0x70(%rsp)
    ace0:      	movq	0x5e78(%rdx,%r14,8), %rax
    ace8:      	movl	$0x0, 0x14(%rsp)
    acf0:      	andl	$0x7ff, %eax            # imm = 0x7FF
    acf5:      	movl	0x90(%rdx,%rax), %eax
    acfc:      	movl	%eax, 0x10(%rsp)
    ad00:      	movl	$0xe, %eax
    ad05:      	callq	*%rax
    ad07:      	shrq	$0x20, %rax
    ad0b:      	movq	%rax, 0x8(%rsp)
    ad10:      	cmpl	$0x1, %r12d
    ad14:      	jne	0xaef7 <generic_kprobe_actions+0x997>
    ad1a:      	movq	0x50(%rsp), %rax
    ad1f:      	andl	$0x7, %eax
    ad22:      	cmpl	$0x4, %eax
    ad25:      	movq	0x30(%rsp), %r14
    ad2a:      	movl	$0x0, %ecx
    ad2f:      	ja	0xaf12 <generic_kprobe_actions+0x9b2>
    ad35:      	movq	%rbp, %rdx
    ad38:      	cmpl	$0x0, 0x5ea0(%rbp,%rax,4)
    ad40:      	jne	0xaf15 <generic_kprobe_actions+0x9b5>
    ad46:      	movq	0x5e78(%rdx,%rax,8), %rax
    ad4e:      	andl	$0x7ff, %eax            # imm = 0x7FF
    ad53:      	addq	%rax, %rdx
    ad56:      	addq	$0x90, %rdx
    ad5d:      	movl	0x90(%rbp,%rax), %esi
    ad64:      	andl	$0xfff, %esi            # imm = 0xFFF
    ad6a:      	addq	$0x8, %rsi
    ad6e:      	movl	$0x4, %eax
    ad73:      	movq	0x70(%rsp), %rdi
    ad78:      	callq	*%rax
    ad7a:      	xorl	%ecx, %ecx
    ad7c:      	movl	$0x2, %eax
    ad81:      	leaq	0x8(%rsp), %rsi
    ad86:      	movq	(%rip), %rdi            # 0xad8d <generic_kprobe_actions+0x82d>
    ad8d:      	movq	0x70(%rsp), %rdx
    ad92:      	xorl	%ecx, %ecx
    ad94:      	callq	*%rax
    ad96:      	xorl	%ecx, %ecx
    ad98:      	movq	%rbp, %rdx
    ad9b:      	testl	%ecx, %ecx
    ad9d:      	jne	0xa66a <generic_kprobe_actions+0x10a>
    ada3:      	jmp	0xa660 <generic_kprobe_actions+0x100>
    ada8:      	movl	$0x2, %eax
    adad:      	movl	$0x1, %ecx
    adb2:      	leaq	0x3c(%rsp), %rdx
    adb7:      	movq	%rbp, %rdi
    adba:      	movq	%rbx, %rsi
    adbd:      	callq	*%rax
    adbf:      	testq	%rax, %rax
    adc2:      	je	0xaadd <generic_kprobe_actions+0x57d>
    adc8:      	movq	%rax, %rbx
    adcb:      	negl	%eax
    adcd:      	movw	%ax, 0x8(%rsp)
    add2:      	movw	$0x3, 0xa(%rsp)
    add9:      	movabsq	$0x20000003b, %rax      # imm = 0x20000003B
    ade3:      	movq	%rax, 0xc(%rsp)
    ade8:      	movl	$0x1, %eax
    aded:      	leaq	0x8(%rsp), %rbp
    adf2:      	movq	(%rip), %rdi            # 0xadf9 <generic_kprobe_actions+0x899>
    adf9:      	movq	%rbp, %rsi
    adfc:      	callq	*%rax
    adfe:      	testq	%rax, %rax
    ae01:      	je	0xb21d <generic_kprobe_actions+0xcbd>
    ae07:      	incl	(%rax)
    ae09:      	jmp	0xb23f <generic_kprobe_actions+0xcdf>
    ae0e:      	movl	$0x2, %eax
    ae13:      	xorl	%ecx, %ecx
    ae15:      	leaq	0x60(%rsp), %rdx
    ae1a:      	movq	%rbp, %rdi
    ae1d:      	movq	%r14, %rsi
    ae20:      	xorl	%ecx, %ecx
    ae22:      	callq	*%rax
    ae24:      	jmp	0xaeb7 <generic_kprobe_actions+0x957>
    ae29:      	movl	$0x2, %eax
    ae2e:      	xorl	%ecx, %ecx
    ae30:      	leaq	0x20(%rsp), %rdx
    ae35:      	movq	%rbp, %rdi
    ae38:      	movq	%r14, %rsi
    ae3b:      	xorl	%ecx, %ecx
    ae3d:      	callq	*%rax
    ae3f:      	testq	%rax, %rax
    ae42:      	leaq	0x40(%rsp), %rbp
    ae47:      	leaq	0x8(%rsp), %rsi
    ae4c:      	je	0xb28e <generic_kprobe_actions+0xd2e>
    ae52:      	negl	%eax
    ae54:      	movw	%ax, 0x8(%rsp)
    ae59:      	movw	$0x3, 0xa(%rsp)
    ae60:      	movabsq	$0x20000006b, %rax      # imm = 0x20000006B
    ae6a:      	movq	%rax, 0xc(%rsp)
    ae6f:      	movl	$0x1, %eax
    ae74:      	movq	(%rip), %r14            # 0xae7b <generic_kprobe_actions+0x91b>
    ae7b:      	movq	%r14, %rdi
    ae7e:      	movq	%rsi, %r15
    ae81:      	callq	*%rax
    ae83:      	testq	%rax, %rax
    ae86:      	je	0xb26f <generic_kprobe_actions+0xd0f>
    ae8c:      	incl	(%rax)
    ae8e:      	jmp	0xb28b <generic_kprobe_actions+0xd2b>
    ae93:      	movl	$0x1, 0x40(%rsp)
    ae9b:      	movl	$0x2, %eax
    aea0:      	xorl	%ecx, %ecx
    aea2:      	leaq	0x40(%rsp), %rdx
    aea7:      	movq	%rbp, %rdi
    aeaa:      	movq	%r14, %rsi
    aead:      	xorl	%ecx, %ecx
    aeaf:      	callq	*%rax
    aeb1:      	movl	0x60(%rsp), %eax
    aeb5:      	movl	%eax, (%rbx)
    aeb7:      	movl	$0x4, %r14d
    aebd:      	movl	%r15d, %ebx
    aec0:      	leaq	0x8(%rsp), %rsi
    aec5:      	movl	$0x0, 0x8(%rsp)
    aecd:      	movl	$0x1, %eax
    aed2:      	movq	(%rip), %rdi            # 0xaed9 <generic_kprobe_actions+0x979>
    aed9:      	callq	*%rax
    aedb:      	testq	%rax, %rax
    aede:      	je	0xaee5 <generic_kprobe_actions+0x985>
    aee0:      	lock
    aee1:      	incq	(%rax,%r14,8)
    aee5:      	movl	%ebx, %r15d
    aee8:      	movq	0x30(%rsp), %r14
    aeed:      	movq	0x18(%rsp), %rdx
    aef2:      	jmp	0xa660 <generic_kprobe_actions+0x100>
    aef7:      	movl	$0x3, %eax
    aefc:      	leaq	0x8(%rsp), %rsi
    af01:      	movq	(%rip), %rdi            # 0xaf08 <generic_kprobe_actions+0x9a8>
    af08:      	callq	*%rax
    af0a:      	movq	%rax, %rcx
    af0d:      	movq	0x30(%rsp), %r14
    af12:      	movq	%rbp, %rdx
    af15:      	testl	%ecx, %ecx
    af17:      	jne	0xa66a <generic_kprobe_actions+0x10a>
    af1d:      	jmp	0xa660 <generic_kprobe_actions+0x100>
    af22:      	movl	$0x3, %eax
    af27:      	leaq	0x20(%rsp), %rsi
    af2c:      	movq	(%rip), %rdi            # 0xaf33 <generic_kprobe_actions+0x9d3>
    af33:      	callq	*%rax
    af35:      	movq	%rax, %rcx
    af38:      	movq	%rbp, %rdx
    af3b:      	testl	%ecx, %ecx
    af3d:      	jne	0xa66a <generic_kprobe_actions+0x10a>
    af43:      	jmp	0xa660 <generic_kprobe_actions+0x100>
    af48:      	movl	$0x2, %eax
    af4d:      	movl	$0x1, %ecx
    af52:      	leaq	0x6c(%rsp), %rdx
    af57:      	movq	%r14, %rdi
    af5a:      	movq	%rbp, %rsi
    af5d:      	callq	*%rax
    af5f:      	testq	%rax, %rax
    af62:      	je	0xacc1 <generic_kprobe_actions+0x761>
    af68:      	movq	%rax, %r14
    af6b:      	negl	%eax
    af6d:      	movw	%ax, 0x8(%rsp)
    af72:      	movw	$0x3, 0xa(%rsp)
    af79:      	movabsq	$0x20000003b, %rax      # imm = 0x20000003B
    af83:      	movq	%rax, 0xc(%rsp)
    af88:      	movl	$0x1, %eax
    af8d:      	leaq	0x8(%rsp), %rsi
    af92:      	movq	(%rip), %rdi            # 0xaf99 <generic_kprobe_actions+0xa39>
    af99:      	callq	*%rax
    af9b:      	testq	%rax, %rax
    af9e:      	je	0xb299 <generic_kprobe_actions+0xd39>
    afa4:      	incl	(%rax)
    afa6:      	jmp	0xb2bd <generic_kprobe_actions+0xd5d>
    afab:      	movl	0x10(%rcx), %eax
    afae:      	movl	%eax, %eax
    afb0:      	movq	0x80(%rsp), %rcx
    afb8:      	movq	%rax, 0x10(%rcx)
    afbc:      	movq	0x50(%rsp), %rdi
    afc1:      	addq	$0x18, %rdi
    afc5:      	movl	$0x4, %eax
    afca:      	movl	$0xc8, %ecx
    afcf:      	movq	%rdi, 0x50(%rsp)
    afd4:      	movl	$0xc8, %esi
    afd9:      	callq	*%rax
    afdb:      	xorl	%r14d, %r14d
    afde:      	jmp	0xafee <generic_kprobe_actions+0xa8e>
    afe0:      	addq	$0x4, %r14
    afe4:      	cmpq	$0x14, %r14
    afe8:      	je	0xb117 <generic_kprobe_actions+0xbb7>
    afee:      	movl	$0x0, 0x20(%rsp)
    aff6:      	movl	$0x1, %eax
    affb:      	movq	(%rip), %rdi            # 0xb002 <generic_kprobe_actions+0xaa2>
    b002:      	leaq	0x20(%rsp), %rsi
    b007:      	callq	*%rax
    b009:      	testq	%rax, %rax
    b00c:      	je	0xb117 <generic_kprobe_actions+0xbb7>
    b012:      	movq	%rax, %rsi
    b015:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    b01c:      	movl	$0x1, %eax
    b021:      	movq	(%rip), %rdi            # 0xb028 <generic_kprobe_actions+0xac8>
    b028:      	callq	*%rax
    b02a:      	testq	%rax, %rax
    b02d:      	je	0xb117 <generic_kprobe_actions+0xbb7>
    b033:      	cmpl	$-0x1, 0x40(%rax,%r14)
    b039:      	movq	0x18(%rsp), %rdx
    b03e:      	je	0xb117 <generic_kprobe_actions+0xbb7>
    b044:      	movq	0x5e78(%rdx,%r14,2), %rax
    b04c:      	movl	0x4(%rdx), %ecx
    b04f:      	cmpq	%rcx, %rax
    b052:      	jge	0xb117 <generic_kprobe_actions+0xbb7>
    b058:      	cmpq	$0x10, %r14
    b05c:      	je	0xb0c9 <generic_kprobe_actions+0xb69>
    b05e:      	movl	$0x0, 0x20(%rsp)
    b066:      	movl	$0x1, %eax
    b06b:      	movq	(%rip), %rdi            # 0xb072 <generic_kprobe_actions+0xb12>
    b072:      	leaq	0x20(%rsp), %rsi
    b077:      	callq	*%rax
    b079:      	testq	%rax, %rax
    b07c:      	je	0xb0bc <generic_kprobe_actions+0xb5c>
    b07e:      	movq	%rax, %rsi
    b081:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    b088:      	movl	$0x1, %eax
    b08d:      	movq	(%rip), %rdi            # 0xb094 <generic_kprobe_actions+0xb34>
    b094:      	callq	*%rax
    b096:      	testq	%rax, %rax
    b099:      	je	0xb0bc <generic_kprobe_actions+0xb5c>
    b09b:      	cmpl	$-0x1, 0x44(%rax,%r14)
    b0a1:      	movq	0x18(%rsp), %rdx
    b0a6:      	movq	0x5e78(%rdx,%r14,2), %rax
    b0ae:      	je	0xb0c9 <generic_kprobe_actions+0xb69>
    b0b0:      	movl	0x5e80(%rdx,%r14,2), %ebx
    b0b8:      	subl	%eax, %ebx
    b0ba:      	jmp	0xb0d1 <generic_kprobe_actions+0xb71>
    b0bc:      	movq	0x18(%rsp), %rdx
    b0c1:      	movq	0x5e78(%rdx,%r14,2), %rax
    b0c9:      	movl	0x4(%rdx), %ebx
    b0cc:      	subl	%eax, %ebx
    b0ce:      	addl	$0x4, %ebx
    b0d1:      	testl	%ebx, %ebx
    b0d3:      	jle	0xafe0 <generic_kprobe_actions+0xa80>
    b0d9:      	addl	$0x3ffc, %eax           # imm = 0x3FFC
    b0de:      	andl	$0x3fff, %eax           # imm = 0x3FFF
    b0e3:      	cmpl	$0x28, %ebx
    b0e6:      	movl	$0x28, %ecx
    b0eb:      	cmovgel	%ecx, %ebx
    b0ee:      	movzbl	%bpl, %ebp
    b0f2:      	movq	0x50(%rsp), %rcx
    b0f7:      	leaq	(%rcx,%rbp), %rdi
    b0fb:      	addq	%rax, %rdx
    b0fe:      	addq	$0x90, %rdx
    b105:      	movl	$0x4, %eax
    b10a:      	movl	%ebx, %esi
    b10c:      	callq	*%rax
    b10e:      	addl	%ebp, %ebx
    b110:      	movl	%ebx, %ebp
    b112:      	jmp	0xafe0 <generic_kprobe_actions+0xa80>
    b117:      	movl	$0x1, %eax
    b11c:      	movq	(%rip), %rdi            # 0xb123 <generic_kprobe_actions+0xbc3>
    b123:      	movq	0x80(%rsp), %rsi
    b12b:      	callq	*%rax
    b12d:      	testq	%rax, %rax
    b130:      	movq	0x30(%rsp), %r14
    b135:      	je	0xb154 <generic_kprobe_actions+0xbf4>
    b137:      	imulq	$-0xf4240, 0x70(%rsp), %rcx # imm = 0xFFF0BDC0
    b140:      	addq	0x8(%rsp), %rcx
    b145:      	cmpq	%rcx, (%rax)
    b148:      	jbe	0xb154 <generic_kprobe_actions+0xbf4>
    b14a:      	movl	$0x0, 0x5c(%rsp)
    b152:      	jmp	0xb173 <generic_kprobe_actions+0xc13>
    b154:      	movl	$0x2, %eax
    b159:      	xorl	%ecx, %ecx
    b15b:      	movq	(%rip), %rdi            # 0xb162 <generic_kprobe_actions+0xc02>
    b162:      	leaq	0x8(%rsp), %rdx
    b167:      	movq	0x80(%rsp), %rsi
    b16f:      	xorl	%ecx, %ecx
    b171:      	callq	*%rax
    b173:      	leal	0x3(%r15), %eax
    b177:      	cmpl	$0x0, 0x4(%r14,%rax,4)
    b17d:      	movq	0x18(%rsp), %rdx
    b182:      	je	0xb1ae <generic_kprobe_actions+0xc4e>
    b184:      	orb	$0x2, 0x1(%rdx)
    b188:      	movl	$0x1b, %eax
    b18d:      	xorl	%ecx, %ecx
    b18f:      	movq	(%rip), %rsi            # 0xb196 <generic_kprobe_actions+0xc36>
    b196:      	movq	0x88(%rsp), %rdi
    b19e:      	xorl	%edx, %edx
    b1a0:      	callq	*%rax
    b1a2:      	movq	0x18(%rsp), %rdx
    b1a7:      	movq	%rax, 0x80(%rdx)
    b1ae:      	leal	0x4(%r15), %eax
    b1b2:      	cmpl	$0x0, 0x4(%r14,%rax,4)
    b1b8:      	je	0xb1ea <generic_kprobe_actions+0xc8a>
    b1ba:      	orb	$0x4, 0x1(%rdx)
    b1be:      	movl	$0x1b, %eax
    b1c3:      	movq	(%rip), %rsi            # 0xb1ca <generic_kprobe_actions+0xc6a>
    b1ca:      	movl	$0x100, %ecx            # imm = 0x100
    b1cf:      	movq	0x88(%rsp), %rdi
    b1d7:      	movl	$0x100, %edx            # imm = 0x100
    b1dc:      	callq	*%rax
    b1de:      	movq	0x18(%rsp), %rdx
    b1e3:      	movq	%rax, 0x88(%rdx)
    b1ea:      	addl	$0x5, %r15d
    b1ee:      	cmpl	$0x0, 0x4(%r14,%r15,4)
    b1f4:      	je	0xa660 <generic_kprobe_actions+0x100>
    b1fa:      	orb	$0x8, 0x1(%rdx)
    b1fe:      	jmp	0xa660 <generic_kprobe_actions+0x100>
    b203:      	movq	0x5e78(%rdx,%rax,8), %rax
    b20b:      	andl	$0x7ff, %eax            # imm = 0x7FF
    b210:      	movq	0x90(%rdx,%rax), %r14
    b218:      	jmp	0xac23 <generic_kprobe_actions+0x6c3>
    b21d:      	movl	$0x1, 0x60(%rsp)
    b225:      	movl	$0x2, %eax
    b22a:      	xorl	%ecx, %ecx
    b22c:      	leaq	0x60(%rsp), %rdx
    b231:      	movq	(%rip), %rdi            # 0xb238 <generic_kprobe_actions+0xcd8>
    b238:      	movq	%rbp, %rsi
    b23b:      	xorl	%ecx, %ecx
    b23d:      	callq	*%rax
    b23f:      	testl	%ebx, %ebx
    b241:      	je	0xaadd <generic_kprobe_actions+0x57d>
    b247:      	movl	$0x1, %eax
    b24c:      	leaq	0x20(%rsp), %rsi
    b251:      	movq	(%rip), %rdi            # 0xb258 <generic_kprobe_actions+0xcf8>
    b258:      	callq	*%rax
    b25a:      	testq	%rax, %rax
    b25d:      	je	0xaadd <generic_kprobe_actions+0x57d>
    b263:      	movl	0x3c(%rsp), %ecx
    b267:      	lock
    b268:      	addl	%ecx, (%rax)
    b26a:      	jmp	0xaadd <generic_kprobe_actions+0x57d>
    b26f:      	movl	$0x1, 0x40(%rsp)
    b277:      	movl	$0x2, %eax
    b27c:      	xorl	%ecx, %ecx
    b27e:      	movq	%r15, %rsi
    b281:      	movq	%r14, %rdi
    b284:      	movq	%rbp, %rdx
    b287:      	xorl	%ecx, %ecx
    b289:      	callq	*%rax
    b28b:      	movq	%r15, %rsi
    b28e:      	movl	$0x6, %r14d
    b294:      	jmp	0xaec5 <generic_kprobe_actions+0x965>
    b299:      	movl	$0x1, 0x3c(%rsp)
    b2a1:      	movl	$0x2, %eax
    b2a6:      	xorl	%ecx, %ecx
    b2a8:      	leaq	0x3c(%rsp), %rdx
    b2ad:      	leaq	0x8(%rsp), %rsi
    b2b2:      	movq	(%rip), %rdi            # 0xb2b9 <generic_kprobe_actions+0xd59>
    b2b9:      	xorl	%ecx, %ecx
    b2bb:      	callq	*%rax
    b2bd:      	testl	%r14d, %r14d
    b2c0:      	je	0xacc1 <generic_kprobe_actions+0x761>
    b2c6:      	movl	$0x1, %eax
    b2cb:      	movq	(%rip), %rdi            # 0xb2d2 <generic_kprobe_actions+0xd72>
    b2d2:      	movq	%rbp, %rsi
    b2d5:      	callq	*%rax
    b2d7:      	testq	%rax, %rax
    b2da:      	je	0xacc1 <generic_kprobe_actions+0x761>
    b2e0:      	movl	0x6c(%rsp), %ecx
    b2e4:      	lock
    b2e5:      	addl	%ecx, (%rax)
    b2e7:      	jmp	0xacc1 <generic_kprobe_actions+0x761>
    b2ec:      	cmpb	$0x0, 0x5c(%rsp)
    b2f1:      	je	0xb313 <generic_kprobe_actions+0xdb3>
    b2f3:      	movq	(%rip), %rsi            # 0xb2fa <generic_kprobe_actions+0xd9a>
    b2fa:      	movl	$0x5, %ecx
    b2ff:      	movl	$0xc, %eax
    b304:      	movq	0x88(%rsp), %rdi
    b30c:      	movl	$0x5, %edx
    b311:      	callq	*%rax
    b313:      	xorl	%eax, %eax
    b315:      	addq	$0xa8, %rsp
    b31c:      	popq	%rbx
    b31d:      	popq	%r12
    b31f:      	popq	%r13
    b321:      	popq	%r14
    b323:      	popq	%r15
    b325:      	popq	%rbp
    b326:      	retq
    b327:      	nopw	(%rax,%rax)

000000000000b330 <generic_kprobe_output>:
    b330:      	pushq	%rbp
    b331:      	pushq	%r15
    b333:      	pushq	%r14
    b335:      	pushq	%r13
    b337:      	pushq	%r12
    b339:      	pushq	%rbx
    b33a:      	subq	$0x78, %rsp
    b33e:      	movq	%rdi, %r14
    b341:      	movl	$0x0, 0x24(%rsp)
    b349:      	movq	(%rip), %rdi            # 0xb350 <generic_kprobe_output+0x20>
    b350:      	leaq	0x24(%rsp), %rsi
    b355:      	movl	$0x1, %eax
    b35a:      	callq	*%rax
    b35c:      	testq	%rax, %rax
    b35f:      	je	0xb809 <generic_kprobe_output+0x4d9>
    b365:      	movq	%rax, %rbx
    b368:      	cmpq	$0x0, 0x5ee8(%rax)
    b370:      	je	0xb678 <generic_kprobe_output+0x348>
    b376:      	movl	$0xe, %eax
    b37b:      	callq	*%rax
    b37d:      	movq	%rax, %r15
    b380:      	shrq	$0x20, %r15
    b384:      	movl	$0x23, %eax
    b389:      	callq	*%rax
    b38b:      	movq	%rax, %r12
    b38e:      	movl	%r15d, 0x28(%rsp)
    b393:      	movq	(%rip), %rdi            # 0xb39a <generic_kprobe_output+0x6a>
    b39a:      	leaq	0x28(%rsp), %rsi
    b39f:      	movl	$0x1, %eax
    b3a4:      	callq	*%rax
    b3a6:      	testq	%rax, %rax
    b3a9:      	je	0xb678 <generic_kprobe_output+0x348>
    b3af:      	movq	%rax, %r15
    b3b2:      	leaq	0xd70(%r12), %rdx
    b3ba:      	leaq	0x70(%rsp), %rdi
    b3bf:      	movl	$0x8, %ecx
    b3c4:      	movl	$0x4, %eax
    b3c9:      	leaq	0x28(%r15), %r13
    b3cd:      	movl	$0x4, %ebp
    b3d2:      	movl	$0x8, %esi
    b3d7:      	callq	*%rax
    b3d9:      	movq	0x70(%rsp), %rcx
    b3de:      	leaq	0x28(%rsp), %rdi
    b3e3:      	movl	$0x48, %edx
    b3e8:      	movl	$0x4, %eax
    b3ed:      	movq	0x70(%rsp), %rdx
    b3f2:      	movl	$0x48, %esi
    b3f7:      	callq	*%rax
    b3f9:      	movl	$0x218, %edx            # imm = 0x218
    b3fe:      	movq	0x30(%rsp), %rcx
    b403:      	addq	%rdx, %rcx
    b406:      	movl	$0x4, %esi
    b40b:      	movl	$0x4, %eax
    b410:      	addq	0x30(%rsp), %rdx
    b415:      	movq	%r13, %rdi
    b418:      	movl	$0x4, %esi
    b41d:      	callq	*%rax
    b41f:      	leaq	0x2c(%r15), %rdi
    b423:      	movl	$0x4d8, %edx            # imm = 0x4D8
    b428:      	movq	0x38(%rsp), %rcx
    b42d:      	addq	%rdx, %rcx
    b430:      	movl	$0x4, %esi
    b435:      	movl	$0x4, %eax
    b43a:      	addq	0x38(%rsp), %rdx
    b43f:      	movl	$0x4, %esi
    b444:      	callq	*%rax
    b446:      	leaq	0x30(%r15), %rdi
    b44a:      	movq	0x40(%rsp), %rcx
    b44f:      	addq	$0x58, %rcx
    b453:      	movl	$0x4, %edx
    b458:      	movl	$0x4, %eax
    b45d:      	movq	0x40(%rsp), %rdx
    b462:      	addq	$0x58, %rdx
    b466:      	movl	$0x4, %esi
    b46b:      	callq	*%rax
    b46d:      	movq	$0x0, (%rsp)
    b475:      	leaq	0xb58(%r12), %rdx
    b47d:      	movq	%rsp, %rdi
    b480:      	movl	$0x8, %ecx
    b485:      	movl	$0x4, %eax
    b48a:      	movl	$0x8, %esi
    b48f:      	callq	*%rax
    b491:      	movq	(%rsp), %rcx
    b495:      	testq	%rcx, %rcx
    b498:      	je	0xb52b <generic_kprobe_output+0x1fb>
    b49e:      	movl	$0x0, 0xc(%rsp)
    b4a6:      	addq	$0x4, %rcx
    b4aa:      	leaq	0xc(%rsp), %rdi
    b4af:      	movl	$0x4, %eax
    b4b4:      	movq	(%rsp), %rdx
    b4b8:      	addq	$0x4, %rdx
    b4bc:      	movl	$0x4, %esi
    b4c1:      	callq	*%rax
    b4c3:      	movq	(%rsp), %rax
    b4c7:      	movslq	0xc(%rsp), %rcx
    b4cc:      	shlq	$0x4, %rcx
    b4d0:      	addq	%rax, %rcx
    b4d3:      	addq	$0x80, %rcx
    b4da:      	leaq	0x10(%rsp), %rdi
    b4df:      	movl	$0x10, %edx
    b4e4:      	movl	$0x4, %eax
    b4e9:      	movq	(%rsp), %rcx
    b4ed:      	movslq	0xc(%rsp), %rdx
    b4f2:      	shlq	$0x4, %rdx
    b4f6:      	addq	%rcx, %rdx
    b4f9:      	addq	$0x80, %rdx
    b500:      	movl	$0x10, %esi
    b505:      	callq	*%rax
    b507:      	leaq	0x34(%r15), %rdi
    b50b:      	movl	$0x158, %edx            # imm = 0x158
    b510:      	movq	0x18(%rsp), %rcx
    b515:      	addq	%rdx, %rcx
    b518:      	movl	$0x4, %eax
    b51d:      	addq	0x18(%rsp), %rdx
    b522:      	movl	$0x4, %esi
    b527:      	callq	*%rax
    b529:      	jmp	0xb533 <generic_kprobe_output+0x203>
    b52b:      	movl	$0x0, 0x34(%r15)
    b533:      	leaq	0x38(%r15), %rdi
    b537:      	movl	$0x158, %r13d           # imm = 0x158
    b53d:      	movq	0x48(%rsp), %rcx
    b542:      	addq	%r13, %rcx
    b545:      	movl	$0x4, %edx
    b54a:      	movl	$0x4, %eax
    b54f:      	movq	0x48(%rsp), %rdx
    b554:      	addq	%r13, %rdx
    b557:      	movl	$0x4, %esi
    b55c:      	callq	*%rax
    b55e:      	leaq	0x3c(%r15), %rdi
    b562:      	movl	$0x118, %edx            # imm = 0x118
    b567:      	movq	0x50(%rsp), %rcx
    b56c:      	addq	%rdx, %rcx
    b56f:      	movl	$0x4, %esi
    b574:      	movl	$0x4, %eax
    b579:      	addq	0x50(%rsp), %rdx
    b57e:      	movl	$0x4, %esi
    b583:      	callq	*%rax
    b585:      	leaq	0x40(%r15), %rdi
    b589:      	movl	$0x98, %ebp
    b58e:      	movq	0x58(%rsp), %rcx
    b593:      	addq	%rbp, %rcx
    b596:      	movl	$0x4, %edx
    b59b:      	movl	$0x4, %eax
    b5a0:      	movq	0x58(%rsp), %rdx
    b5a5:      	addq	%rbp, %rdx
    b5a8:      	movl	$0x4, %esi
    b5ad:      	callq	*%rax
    b5af:      	leaq	0x44(%r15), %rdi
    b5b3:      	movq	0x60(%rsp), %rcx
    b5b8:      	addq	%rbp, %rcx
    b5bb:      	movl	$0x4, %edx
    b5c0:      	movl	$0x4, %eax
    b5c5:      	addq	0x60(%rsp), %rbp
    b5ca:      	movl	$0x4, %esi
    b5cf:      	movq	%rbp, %rdx
    b5d2:      	callq	*%rax
    b5d4:      	leaq	0x48(%r15), %rdi
    b5d8:      	movq	0x68(%rsp), %rcx
    b5dd:      	addq	$0x58, %rcx
    b5e1:      	movl	$0x4, %edx
    b5e6:      	movl	$0x4, %eax
    b5eb:      	movq	0x68(%rsp), %rdx
    b5f0:      	addq	$0x58, %rdx
    b5f4:      	movl	$0x4, %esi
    b5f9:      	callq	*%rax
    b5fb:      	movq	$0x0, 0x10(%rsp)
    b604:      	movq	$0x0, (%rsp)
    b60c:      	addq	$0xd00, %r12            # imm = 0xD00
    b613:      	leaq	0x10(%rsp), %rdi
    b618:      	movl	$0x8, %ecx
    b61d:      	movl	$0x4, %eax
    b622:      	movl	$0x8, %esi
    b627:      	movq	%r12, %rdx
    b62a:      	callq	*%rax
    b62c:      	movl	$0x90, %edx
    b631:      	movq	0x10(%rsp), %rcx
    b636:      	addq	%rdx, %rcx
    b639:      	movq	%rsp, %rdi
    b63c:      	movl	$0x8, %esi
    b641:      	movl	$0x4, %eax
    b646:      	addq	0x10(%rsp), %rdx
    b64b:      	movl	$0x8, %esi
    b650:      	callq	*%rax
    b652:      	addq	$0x4c, %r15
    b656:      	movq	(%rsp), %rcx
    b65a:      	addq	%r13, %rcx
    b65d:      	movl	$0x4, %edx
    b662:      	movl	$0x4, %eax
    b667:      	addq	(%rsp), %r13
    b66b:      	movq	%r15, %rdi
    b66e:      	movl	$0x4, %esi
    b673:      	movq	%r13, %rdx
    b676:      	callq	*%rax
    b678:      	cmpq	$0x0, 0x5ef0(%rbx)
    b680:      	je	0xb739 <generic_kprobe_output+0x409>
    b686:      	movl	$0xe, %eax
    b68b:      	callq	*%rax
    b68d:      	movq	%rax, %r15
    b690:      	shrq	$0x20, %r15
    b694:      	movl	$0x23, %eax
    b699:      	callq	*%rax
    b69b:      	movq	%rax, %r12
    b69e:      	movl	%r15d, 0x28(%rsp)
    b6a3:      	movq	(%rip), %rdi            # 0xb6aa <generic_kprobe_output+0x37a>
    b6aa:      	leaq	0x28(%rsp), %rsi
    b6af:      	movl	$0x1, %eax
    b6b4:      	callq	*%rax
    b6b6:      	testq	%rax, %rax
    b6b9:      	je	0xb739 <generic_kprobe_output+0x409>
    b6bb:      	leaq	0x50(%rax), %r15
    b6bf:      	addq	$0xd00, %r12            # imm = 0xD00
    b6c6:      	leaq	0x28(%rsp), %rdi
    b6cb:      	movl	$0x8, %ecx
    b6d0:      	movq	%rax, %r13
    b6d3:      	movl	$0x4, %eax
    b6d8:      	movl	$0x8, %esi
    b6dd:      	movq	%r12, %rdx
    b6e0:      	callq	*%rax
    b6e2:      	movq	0x28(%rsp), %r12
    b6e7:      	leaq	0x58(%r13), %rdi
    b6eb:      	leaq	0x40(%r12), %rdx
    b6f0:      	movl	$0x8, %ecx
    b6f5:      	movl	$0x4, %eax
    b6fa:      	movl	$0x8, %esi
    b6ff:      	callq	*%rax
    b701:      	addq	$0x60, %r13
    b705:      	leaq	0x30(%r12), %rdx
    b70a:      	movl	$0x8, %ecx
    b70f:      	movl	$0x4, %eax
    b714:      	movq	%r13, %rdi
    b717:      	movl	$0x8, %esi
    b71c:      	callq	*%rax
    b71e:      	addq	$0x38, %r12
    b722:      	movl	$0x8, %ecx
    b727:      	movl	$0x4, %eax
    b72c:      	movq	%r15, %rdi
    b72f:      	movl	$0x8, %esi
    b734:      	movq	%r12, %rdx
    b737:      	callq	*%rax
    b739:      	movl	$0x90, %eax
    b73e:      	addl	0x4(%rbx), %eax
    b741:      	andl	$0x7fff, %eax           # imm = 0x7FFF
    b746:      	cmpl	$0x2328, %eax           # imm = 0x2328
    b74b:      	movl	$0x2328, %r15d          # imm = 0x2328
    b751:      	cmovbl	%eax, %r15d
    b755:      	movl	$0x0, 0x10(%rsp)
    b75d:      	movq	(%rip), %rdi            # 0xb764 <generic_kprobe_output+0x434>
    b764:      	leaq	0x10(%rsp), %rsi
    b769:      	movl	$0x1, %eax
    b76e:      	callq	*%rax
    b770:      	testq	%rax, %rax
    b773:      	je	0xb7c7 <generic_kprobe_output+0x497>
    b775:      	cmpb	$0x0, 0x28(%rax)
    b779:      	je	0xb7c7 <generic_kprobe_output+0x497>
    b77b:      	movq	(%rip), %rsi            # 0xb782 <generic_kprobe_output+0x452>
    b782:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    b787:      	movl	$0x19, %eax
    b78c:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    b791:      	movq	%r14, %rdi
    b794:      	movq	%rbx, %rcx
    b797:      	movq	%r15, %r8
    b79a:      	callq	*%rax
    b79c:      	testq	%rax, %rax
    b79f:      	js	0xb869 <generic_kprobe_output+0x539>
    b7a5:      	movl	$0x0, 0x28(%rsp)
    b7ad:      	movq	(%rip), %rdi            # 0xb7b4 <generic_kprobe_output+0x484>
    b7b4:      	leaq	0x28(%rsp), %rsi
    b7b9:      	movl	$0x1, %eax
    b7be:      	callq	*%rax
    b7c0:      	testq	%rax, %rax
    b7c3:      	jne	0xb804 <generic_kprobe_output+0x4d4>
    b7c5:      	jmp	0xb809 <generic_kprobe_output+0x4d9>
    b7c7:      	movq	(%rip), %rdi            # 0xb7ce <generic_kprobe_output+0x49e>
    b7ce:      	xorl	%ecx, %ecx
    b7d0:      	movl	$0x82, %eax
    b7d5:      	movq	%rbx, %rsi
    b7d8:      	movq	%r15, %rdx
    b7db:      	xorl	%ecx, %ecx
    b7dd:      	callq	*%rax
    b7df:      	testq	%rax, %rax
    b7e2:      	js	0xb81a <generic_kprobe_output+0x4ea>
    b7e4:      	movl	$0x0, 0x28(%rsp)
    b7ec:      	movq	(%rip), %rdi            # 0xb7f3 <generic_kprobe_output+0x4c3>
    b7f3:      	leaq	0x28(%rsp), %rsi
    b7f8:      	movl	$0x1, %eax
    b7fd:      	callq	*%rax
    b7ff:      	testq	%rax, %rax
    b802:      	je	0xb809 <generic_kprobe_output+0x4d9>
    b804:      	lock
    b805:      	incq	0x8(%rax)
    b809:      	xorl	%eax, %eax
    b80b:      	addq	$0x78, %rsp
    b80f:      	popq	%rbx
    b810:      	popq	%r12
    b812:      	popq	%r13
    b814:      	popq	%r14
    b816:      	popq	%r15
    b818:      	popq	%rbp
    b819:      	retq
    b81a:      	movq	%rax, %rbx
    b81d:      	movl	$0x0, 0x28(%rsp)
    b825:      	movq	(%rip), %rdi            # 0xb82c <generic_kprobe_output+0x4fc>
    b82c:      	leaq	0x28(%rsp), %rsi
    b831:      	movl	$0x1, %eax
    b836:      	callq	*%rax
    b838:      	testq	%rax, %rax
    b83b:      	je	0xb809 <generic_kprobe_output+0x4d9>
    b83d:      	cmpq	$-0xc, %rbx
    b841:      	jg	0xb8b1 <generic_kprobe_output+0x581>
    b843:      	cmpq	$-0x1c, %rbx
    b847:      	je	0xb8f3 <generic_kprobe_output+0x5c3>
    b84d:      	cmpq	$-0x16, %rbx
    b851:      	je	0xb8a2 <generic_kprobe_output+0x572>
    b853:      	cmpq	$-0x10, %rbx
    b857:      	jne	0xb8e4 <generic_kprobe_output+0x5b4>
    b85d:      	addq	$0x2f0, %rax            # imm = 0x2F0
    b863:      	lock
    b864:      	incq	(%rax)
    b867:      	jmp	0xb809 <generic_kprobe_output+0x4d9>
    b869:      	movq	%rax, %rbx
    b86c:      	movl	$0x0, 0x28(%rsp)
    b874:      	movq	(%rip), %rdi            # 0xb87b <generic_kprobe_output+0x54b>
    b87b:      	leaq	0x28(%rsp), %rsi
    b880:      	movl	$0x1, %eax
    b885:      	callq	*%rax
    b887:      	testq	%rax, %rax
    b88a:      	je	0xb809 <generic_kprobe_output+0x4d9>
    b890:      	cmpq	$-0xc, %rbx
    b894:      	jg	0xb8d2 <generic_kprobe_output+0x5a2>
    b896:      	cmpq	$-0x1c, %rbx
    b89a:      	je	0xb8f3 <generic_kprobe_output+0x5c3>
    b89c:      	cmpq	$-0x16, %rbx
    b8a0:      	jne	0xb853 <generic_kprobe_output+0x523>
    b8a2:      	addq	$0x2f8, %rax            # imm = 0x2F8
    b8a8:      	lock
    b8a9:      	incq	(%rax)
    b8ac:      	jmp	0xb809 <generic_kprobe_output+0x4d9>
    b8b1:      	cmpq	$-0xb, %rbx
    b8b5:      	je	0xb902 <generic_kprobe_output+0x5d2>
    b8b7:      	cmpq	$-0x7, %rbx
    b8bb:      	je	0xb911 <generic_kprobe_output+0x5e1>
    b8bd:      	cmpq	$-0x2, %rbx
    b8c1:      	jne	0xb8e4 <generic_kprobe_output+0x5b4>
    b8c3:      	addq	$0x2e0, %rax            # imm = 0x2E0
    b8c9:      	lock
    b8ca:      	incq	(%rax)
    b8cd:      	jmp	0xb809 <generic_kprobe_output+0x4d9>
    b8d2:      	cmpq	$-0xb, %rbx
    b8d6:      	je	0xb902 <generic_kprobe_output+0x5d2>
    b8d8:      	cmpq	$-0x7, %rbx
    b8dc:      	je	0xb911 <generic_kprobe_output+0x5e1>
    b8de:      	cmpq	$-0x2, %rbx
    b8e2:      	je	0xb8c3 <generic_kprobe_output+0x593>
    b8e4:      	addq	$0x2d8, %rax            # imm = 0x2D8
    b8ea:      	lock
    b8eb:      	incq	(%rax)
    b8ee:      	jmp	0xb809 <generic_kprobe_output+0x4d9>
    b8f3:      	addq	$0x300, %rax            # imm = 0x300
    b8f9:      	lock
    b8fa:      	incq	(%rax)
    b8fd:      	jmp	0xb809 <generic_kprobe_output+0x4d9>
    b902:      	addq	$0x308, %rax            # imm = 0x308
    b908:      	lock
    b909:      	incq	(%rax)
    b90c:      	jmp	0xb809 <generic_kprobe_output+0x4d9>
    b911:      	addq	$0x2e8, %rax            # imm = 0x2E8
    b917:      	lock
    b918:      	incq	(%rax)
    b91b:      	jmp	0xb809 <generic_kprobe_output+0x4d9>

000000000000b920 <generic_kprobe_path>:
    b920:      	pushq	%rbp
    b921:      	pushq	%r15
    b923:      	pushq	%r14
    b925:      	pushq	%r13
    b927:      	pushq	%r12
    b929:      	pushq	%rbx
    b92a:      	subq	$0x88, %rsp
    b931:      	movq	%rdi, %rbp
    b934:      	movl	$0x0, 0x70(%rsp)
    b93c:      	movq	(%rip), %rdi            # 0xb943 <generic_kprobe_path+0x23>
    b943:      	leaq	0x70(%rsp), %rsi
    b948:      	movl	$0x1, %eax
    b94d:      	callq	*%rax
    b94f:      	testq	%rax, %rax
    b952:      	je	0x17799 <generic_kprobe_path+0xbe79>
    b958:      	movq	%rax, %r14
    b95b:      	movl	0x6420(%rax), %eax
    b961:      	cmpl	$0x1, %eax
    b964:      	je	0xba06 <generic_kprobe_path+0xe6>
    b96a:      	testl	%eax, %eax
    b96c:      	jne	0x17799 <generic_kprobe_path+0xbe79>
    b972:      	movq	0x6440(%r14), %r12
    b979:      	movl	$0x0, 0x10(%rsp)
    b981:      	movq	(%rip), %rdi            # 0xb988 <generic_kprobe_path+0x68>
    b988:      	leaq	0x10(%rsp), %rsi
    b98d:      	movl	$0x1, %eax
    b992:      	callq	*%rax
    b994:      	testq	%rax, %rax
    b997:      	je	0x17799 <generic_kprobe_path+0xbe79>
    b99d:      	movq	%rax, %r15
    b9a0:      	addq	$0x8, %r12
    b9a4:      	leaq	0x58(%rsp), %rdi
    b9a9:      	movl	$0x8, %ecx
    b9ae:      	movl	$0x4, %eax
    b9b3:      	movl	$0x8, %esi
    b9b8:      	movq	%r12, %rdx
    b9bb:      	callq	*%rax
    b9bd:      	testq	%rax, %rax
    b9c0:      	je	0x17449 <generic_kprobe_path+0xbb29>
    b9c6:      	negl	%eax
    b9c8:      	movw	%ax, 0x18(%rsp)
    b9cd:      	movw	$0x6, 0x1a(%rsp)
    b9d4:      	movabsq	$0x40000002c, %rax      # imm = 0x40000002C
    b9de:      	movq	%rax, 0x1c(%rsp)
    b9e3:      	movq	(%rip), %rdi            # 0xb9ea <generic_kprobe_path+0xca>
    b9ea:      	leaq	0x18(%rsp), %rsi
    b9ef:      	movl	$0x1, %eax
    b9f4:      	callq	*%rax
    b9f6:      	testq	%rax, %rax
    b9f9:      	je	0x17428 <generic_kprobe_path+0xbb08>
    b9ff:      	incl	(%rax)
    ba01:      	jmp	0x17449 <generic_kprobe_path+0xbb29>
    ba06:      	movq	0x6448(%r14), %rax
    ba0d:      	movq	%rax, 0x18(%rsp)
    ba12:      	movq	0x6450(%r14), %rax
    ba19:      	movq	%rax, 0x20(%rsp)
    ba1e:      	movq	$0x0, 0x28(%rsp)
    ba27:      	movq	0x6458(%r14), %rax
    ba2e:      	movq	%rax, 0x30(%rsp)
    ba33:      	movq	0x6460(%r14), %rax
    ba3a:      	movq	%rax, 0x38(%rsp)
    ba3f:      	movq	0x6468(%r14), %rax
    ba46:      	movq	%rax, 0x40(%rsp)
    ba4b:      	movq	$0x0, 0x48(%rsp)
    ba54:      	movl	$0x0, 0x50(%rsp)
    ba5c:      	movb	$0x0, 0x54(%rsp)
    ba61:      	movl	$0x0, 0x74(%rsp)
    ba69:      	movq	(%rip), %rdi            # 0xba70 <generic_kprobe_path+0x150>
    ba70:      	leaq	0x74(%rsp), %rsi
    ba75:      	movl	$0x1, %eax
    ba7a:      	callq	*%rax
    ba7c:      	testq	%rax, %rax
    ba7f:      	je	0x17799 <generic_kprobe_path+0xbe79>
    ba85:      	movq	%rbp, 0x78(%rsp)
    ba8a:      	movq	%rax, 0x28(%rsp)
    ba8f:      	movl	0x6424(%r14), %edx
    ba96:      	movl	%edx, %ecx
    ba98:      	andl	$0xfff, %ecx            # imm = 0xFFF
    ba9e:      	movq	%rax, %rsi
    baa1:      	movq	%rax, 0x80(%rsp)
    baa9:      	addq	%rax, %rcx
    baac:      	movq	%rcx, 0x48(%rsp)
    bab1:      	movl	%edx, 0x50(%rsp)
    bab5:      	movl	$0x200, %eax            # imm = 0x200
    baba:      	movl	$0x8, %r13d
    bac0:      	movq	%rsp, %rbp
    bac3:      	movl	%eax, 0x6c(%rsp)
    bac7:      	movq	0x30(%rsp), %r12
    bacc:      	movq	0x38(%rsp), %rdx
    bad1:      	movq	0x40(%rsp), %r15
    bad6:      	cmpq	0x18(%rsp), %r12
    badb:      	jne	0xbae8 <generic_kprobe_path+0x1c8>
    badd:      	cmpq	0x20(%rsp), %rdx
    bae2:      	je	0x1738d <generic_kprobe_path+0xba6d>
    bae8:      	movl	$0x4, %eax
    baed:      	leaq	0x10(%rsp), %rdi
    baf2:      	movl	$0x8, %esi
    baf7:      	callq	*%rax
    baf9:      	cmpq	0x10(%rsp), %r12
    bafe:      	je	0xbbfd <generic_kprobe_path+0x2dd>
    bb04:      	leaq	0x18(%r12), %rbx
    bb09:      	movl	$0x4, %eax
    bb0e:      	movq	%rbp, %rdi
    bb11:      	movl	$0x8, %esi
    bb16:      	movq	%rbx, %rdx
    bb19:      	callq	*%rax
    bb1b:      	cmpq	%r12, (%rsp)
    bb1f:      	je	0xbbfd <generic_kprobe_path+0x2dd>
    bb25:      	movl	$0x4, %eax
    bb2a:      	leaq	0x8(%rsp), %rdi
    bb2f:      	movl	$0x8, %esi
    bb34:      	movq	%rbx, %rdx
    bb37:      	callq	*%rax
    bb39:      	addq	$0x20, %r12
    bb3d:      	movl	$0x4, %eax
    bb42:      	leaq	0x58(%rsp), %rdi
    bb47:      	movl	$0x10, %ecx
    bb4c:      	movl	$0x10, %esi
    bb51:      	movq	%r12, %rdx
    bb54:      	callq	*%rax
    bb56:      	movq	0x28(%rsp), %rbx
    bb5b:      	movq	0x48(%rsp), %rax
    bb60:      	movl	0x5c(%rsp), %r15d
    bb65:      	subq	%rbx, %rax
    bb68:      	movl	0x50(%rsp), %r12d
    bb6d:      	movl	%r15d, %edx
    bb70:      	subl	%r12d, %edx
    bb73:      	movl	$0x0, %ecx
    bb78:      	cmovbl	%ecx, %edx
    bb7b:      	addq	0x60(%rsp), %rdx
    bb80:      	xorl	%esi, %esi
    bb82:      	cmpl	%r15d, %r12d
    bb85:      	seta	%sil
    bb89:      	movl	%r15d, %ecx
    bb8c:      	cmovbl	%r12d, %ecx
    bb90:      	addl	%ecx, %esi
    bb92:      	movl	%r12d, %edi
    bb95:      	subl	%esi, %edi
    bb97:      	movl	%edi, 0x50(%rsp)
    bb9b:      	subq	%rsi, %rax
    bb9e:      	jb	0x17392 <generic_kprobe_path+0xba72>
    bba4:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    bbaa:      	ja	0x17392 <generic_kprobe_path+0xba72>
    bbb0:      	cmpl	%r15d, %r12d
    bbb3:      	jbe	0xbbb9 <generic_kprobe_path+0x299>
    bbb5:      	movb	$0x2f, (%rbx,%rax)
    bbb9:      	xorl	%edi, %edi
    bbbb:      	cmpl	%r15d, %r12d
    bbbe:      	seta	%dil
    bbc2:      	movzbl	%cl, %esi
    bbc5:      	addq	%rax, %rbx
    bbc8:      	addq	%rbx, %rdi
    bbcb:      	movl	$0x4, %eax
    bbd0:      	callq	*%rax
    bbd2:      	movq	%rbx, 0x48(%rsp)
    bbd7:      	cmpl	%r15d, %r12d
    bbda:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    bbe0:      	movq	0x8(%rsp), %r12
    bbe5:      	movq	%r12, 0x30(%rsp)
    bbea:      	movq	0x38(%rsp), %rdx
    bbef:      	movq	0x40(%rsp), %r15
    bbf4:      	cmpq	0x18(%rsp), %r12
    bbf9:      	je	0xbc55 <generic_kprobe_path+0x335>
    bbfb:      	jmp	0xbc60 <generic_kprobe_path+0x340>
    bbfd:      	leaq	0x10(%r15), %rdx
    bc01:      	movl	$0x4, %eax
    bc06:      	movq	%rbp, %rdi
    bc09:      	movl	$0x8, %esi
    bc0e:      	callq	*%rax
    bc10:      	movq	0x40(%rsp), %rax
    bc15:      	cmpq	(%rsp), %rax
    bc19:      	je	0x1738d <generic_kprobe_path+0xba6d>
    bc1f:      	addq	$0x18, %r15
    bc23:      	movl	$0x4, %eax
    bc28:      	leaq	0x30(%rsp), %rdi
    bc2d:      	movl	$0x8, %esi
    bc32:      	movq	%r15, %rdx
    bc35:      	callq	*%rax
    bc37:      	movq	(%rsp), %r15
    bc3b:      	movq	%r15, 0x40(%rsp)
    bc40:      	leaq	0x20(%r15), %rdx
    bc44:      	movq	%rdx, 0x38(%rsp)
    bc49:      	movq	0x30(%rsp), %r12
    bc4e:      	cmpq	0x18(%rsp), %r12
    bc53:      	jne	0xbc60 <generic_kprobe_path+0x340>
    bc55:      	cmpq	0x20(%rsp), %rdx
    bc5a:      	je	0x1738d <generic_kprobe_path+0xba6d>
    bc60:      	movl	$0x4, %eax
    bc65:      	leaq	0x10(%rsp), %rdi
    bc6a:      	movl	$0x8, %esi
    bc6f:      	callq	*%rax
    bc71:      	cmpq	0x10(%rsp), %r12
    bc76:      	je	0xbd75 <generic_kprobe_path+0x455>
    bc7c:      	leaq	0x18(%r12), %rbx
    bc81:      	movl	$0x4, %eax
    bc86:      	movq	%rbp, %rdi
    bc89:      	movl	$0x8, %esi
    bc8e:      	movq	%rbx, %rdx
    bc91:      	callq	*%rax
    bc93:      	cmpq	%r12, (%rsp)
    bc97:      	je	0xbd75 <generic_kprobe_path+0x455>
    bc9d:      	movl	$0x4, %eax
    bca2:      	leaq	0x8(%rsp), %rdi
    bca7:      	movl	$0x8, %esi
    bcac:      	movq	%rbx, %rdx
    bcaf:      	callq	*%rax
    bcb1:      	addq	$0x20, %r12
    bcb5:      	movl	$0x4, %eax
    bcba:      	leaq	0x58(%rsp), %rdi
    bcbf:      	movl	$0x10, %ecx
    bcc4:      	movl	$0x10, %esi
    bcc9:      	movq	%r12, %rdx
    bccc:      	callq	*%rax
    bcce:      	movq	0x28(%rsp), %rbx
    bcd3:      	movq	0x48(%rsp), %rax
    bcd8:      	movl	0x5c(%rsp), %r15d
    bcdd:      	subq	%rbx, %rax
    bce0:      	movl	0x50(%rsp), %r12d
    bce5:      	movl	%r15d, %edx
    bce8:      	subl	%r12d, %edx
    bceb:      	movl	$0x0, %ecx
    bcf0:      	cmovbl	%ecx, %edx
    bcf3:      	addq	0x60(%rsp), %rdx
    bcf8:      	xorl	%esi, %esi
    bcfa:      	cmpl	%r15d, %r12d
    bcfd:      	seta	%sil
    bd01:      	movl	%r15d, %ecx
    bd04:      	cmovbl	%r12d, %ecx
    bd08:      	addl	%ecx, %esi
    bd0a:      	movl	%r12d, %edi
    bd0d:      	subl	%esi, %edi
    bd0f:      	movl	%edi, 0x50(%rsp)
    bd13:      	subq	%rsi, %rax
    bd16:      	jb	0x17392 <generic_kprobe_path+0xba72>
    bd1c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    bd22:      	ja	0x17392 <generic_kprobe_path+0xba72>
    bd28:      	cmpl	%r15d, %r12d
    bd2b:      	jbe	0xbd31 <generic_kprobe_path+0x411>
    bd2d:      	movb	$0x2f, (%rbx,%rax)
    bd31:      	xorl	%edi, %edi
    bd33:      	cmpl	%r15d, %r12d
    bd36:      	seta	%dil
    bd3a:      	movzbl	%cl, %esi
    bd3d:      	addq	%rax, %rbx
    bd40:      	addq	%rbx, %rdi
    bd43:      	movl	$0x4, %eax
    bd48:      	callq	*%rax
    bd4a:      	movq	%rbx, 0x48(%rsp)
    bd4f:      	cmpl	%r15d, %r12d
    bd52:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    bd58:      	movq	0x8(%rsp), %r12
    bd5d:      	movq	%r12, 0x30(%rsp)
    bd62:      	movq	0x38(%rsp), %rdx
    bd67:      	movq	0x40(%rsp), %r15
    bd6c:      	cmpq	0x18(%rsp), %r12
    bd71:      	je	0xbdcd <generic_kprobe_path+0x4ad>
    bd73:      	jmp	0xbdd8 <generic_kprobe_path+0x4b8>
    bd75:      	leaq	0x10(%r15), %rdx
    bd79:      	movl	$0x4, %eax
    bd7e:      	movq	%rbp, %rdi
    bd81:      	movl	$0x8, %esi
    bd86:      	callq	*%rax
    bd88:      	movq	0x40(%rsp), %rax
    bd8d:      	cmpq	(%rsp), %rax
    bd91:      	je	0x1738d <generic_kprobe_path+0xba6d>
    bd97:      	addq	$0x18, %r15
    bd9b:      	movl	$0x4, %eax
    bda0:      	leaq	0x30(%rsp), %rdi
    bda5:      	movl	$0x8, %esi
    bdaa:      	movq	%r15, %rdx
    bdad:      	callq	*%rax
    bdaf:      	movq	(%rsp), %r15
    bdb3:      	movq	%r15, 0x40(%rsp)
    bdb8:      	leaq	0x20(%r15), %rdx
    bdbc:      	movq	%rdx, 0x38(%rsp)
    bdc1:      	movq	0x30(%rsp), %r12
    bdc6:      	cmpq	0x18(%rsp), %r12
    bdcb:      	jne	0xbdd8 <generic_kprobe_path+0x4b8>
    bdcd:      	cmpq	0x20(%rsp), %rdx
    bdd2:      	je	0x1738d <generic_kprobe_path+0xba6d>
    bdd8:      	movl	$0x4, %eax
    bddd:      	leaq	0x10(%rsp), %rdi
    bde2:      	movl	$0x8, %esi
    bde7:      	callq	*%rax
    bde9:      	cmpq	0x10(%rsp), %r12
    bdee:      	je	0xbeed <generic_kprobe_path+0x5cd>
    bdf4:      	leaq	0x18(%r12), %rbx
    bdf9:      	movl	$0x4, %eax
    bdfe:      	movq	%rbp, %rdi
    be01:      	movl	$0x8, %esi
    be06:      	movq	%rbx, %rdx
    be09:      	callq	*%rax
    be0b:      	cmpq	%r12, (%rsp)
    be0f:      	je	0xbeed <generic_kprobe_path+0x5cd>
    be15:      	movl	$0x4, %eax
    be1a:      	leaq	0x8(%rsp), %rdi
    be1f:      	movl	$0x8, %esi
    be24:      	movq	%rbx, %rdx
    be27:      	callq	*%rax
    be29:      	addq	$0x20, %r12
    be2d:      	movl	$0x4, %eax
    be32:      	leaq	0x58(%rsp), %rdi
    be37:      	movl	$0x10, %ecx
    be3c:      	movl	$0x10, %esi
    be41:      	movq	%r12, %rdx
    be44:      	callq	*%rax
    be46:      	movq	0x28(%rsp), %rbx
    be4b:      	movq	0x48(%rsp), %rax
    be50:      	movl	0x5c(%rsp), %r15d
    be55:      	subq	%rbx, %rax
    be58:      	movl	0x50(%rsp), %r12d
    be5d:      	movl	%r15d, %edx
    be60:      	subl	%r12d, %edx
    be63:      	movl	$0x0, %ecx
    be68:      	cmovbl	%ecx, %edx
    be6b:      	addq	0x60(%rsp), %rdx
    be70:      	xorl	%esi, %esi
    be72:      	cmpl	%r15d, %r12d
    be75:      	seta	%sil
    be79:      	movl	%r15d, %ecx
    be7c:      	cmovbl	%r12d, %ecx
    be80:      	addl	%ecx, %esi
    be82:      	movl	%r12d, %edi
    be85:      	subl	%esi, %edi
    be87:      	movl	%edi, 0x50(%rsp)
    be8b:      	subq	%rsi, %rax
    be8e:      	jb	0x17392 <generic_kprobe_path+0xba72>
    be94:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    be9a:      	ja	0x17392 <generic_kprobe_path+0xba72>
    bea0:      	cmpl	%r15d, %r12d
    bea3:      	jbe	0xbea9 <generic_kprobe_path+0x589>
    bea5:      	movb	$0x2f, (%rbx,%rax)
    bea9:      	xorl	%edi, %edi
    beab:      	cmpl	%r15d, %r12d
    beae:      	seta	%dil
    beb2:      	movzbl	%cl, %esi
    beb5:      	addq	%rax, %rbx
    beb8:      	addq	%rbx, %rdi
    bebb:      	movl	$0x4, %eax
    bec0:      	callq	*%rax
    bec2:      	movq	%rbx, 0x48(%rsp)
    bec7:      	cmpl	%r15d, %r12d
    beca:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    bed0:      	movq	0x8(%rsp), %r12
    bed5:      	movq	%r12, 0x30(%rsp)
    beda:      	movq	0x38(%rsp), %rdx
    bedf:      	movq	0x40(%rsp), %r15
    bee4:      	cmpq	0x18(%rsp), %r12
    bee9:      	je	0xbf45 <generic_kprobe_path+0x625>
    beeb:      	jmp	0xbf50 <generic_kprobe_path+0x630>
    beed:      	leaq	0x10(%r15), %rdx
    bef1:      	movl	$0x4, %eax
    bef6:      	movq	%rbp, %rdi
    bef9:      	movl	$0x8, %esi
    befe:      	callq	*%rax
    bf00:      	movq	0x40(%rsp), %rax
    bf05:      	cmpq	(%rsp), %rax
    bf09:      	je	0x1738d <generic_kprobe_path+0xba6d>
    bf0f:      	addq	$0x18, %r15
    bf13:      	movl	$0x4, %eax
    bf18:      	leaq	0x30(%rsp), %rdi
    bf1d:      	movl	$0x8, %esi
    bf22:      	movq	%r15, %rdx
    bf25:      	callq	*%rax
    bf27:      	movq	(%rsp), %r15
    bf2b:      	movq	%r15, 0x40(%rsp)
    bf30:      	leaq	0x20(%r15), %rdx
    bf34:      	movq	%rdx, 0x38(%rsp)
    bf39:      	movq	0x30(%rsp), %r12
    bf3e:      	cmpq	0x18(%rsp), %r12
    bf43:      	jne	0xbf50 <generic_kprobe_path+0x630>
    bf45:      	cmpq	0x20(%rsp), %rdx
    bf4a:      	je	0x1738d <generic_kprobe_path+0xba6d>
    bf50:      	movl	$0x4, %eax
    bf55:      	leaq	0x10(%rsp), %rdi
    bf5a:      	movl	$0x8, %esi
    bf5f:      	callq	*%rax
    bf61:      	cmpq	0x10(%rsp), %r12
    bf66:      	je	0xc065 <generic_kprobe_path+0x745>
    bf6c:      	leaq	0x18(%r12), %rbx
    bf71:      	movl	$0x4, %eax
    bf76:      	movq	%rbp, %rdi
    bf79:      	movl	$0x8, %esi
    bf7e:      	movq	%rbx, %rdx
    bf81:      	callq	*%rax
    bf83:      	cmpq	%r12, (%rsp)
    bf87:      	je	0xc065 <generic_kprobe_path+0x745>
    bf8d:      	movl	$0x4, %eax
    bf92:      	leaq	0x8(%rsp), %rdi
    bf97:      	movl	$0x8, %esi
    bf9c:      	movq	%rbx, %rdx
    bf9f:      	callq	*%rax
    bfa1:      	addq	$0x20, %r12
    bfa5:      	movl	$0x4, %eax
    bfaa:      	leaq	0x58(%rsp), %rdi
    bfaf:      	movl	$0x10, %ecx
    bfb4:      	movl	$0x10, %esi
    bfb9:      	movq	%r12, %rdx
    bfbc:      	callq	*%rax
    bfbe:      	movq	0x28(%rsp), %rbx
    bfc3:      	movq	0x48(%rsp), %rax
    bfc8:      	movl	0x5c(%rsp), %r15d
    bfcd:      	subq	%rbx, %rax
    bfd0:      	movl	0x50(%rsp), %r12d
    bfd5:      	movl	%r15d, %edx
    bfd8:      	subl	%r12d, %edx
    bfdb:      	movl	$0x0, %ecx
    bfe0:      	cmovbl	%ecx, %edx
    bfe3:      	addq	0x60(%rsp), %rdx
    bfe8:      	xorl	%esi, %esi
    bfea:      	cmpl	%r15d, %r12d
    bfed:      	seta	%sil
    bff1:      	movl	%r15d, %ecx
    bff4:      	cmovbl	%r12d, %ecx
    bff8:      	addl	%ecx, %esi
    bffa:      	movl	%r12d, %edi
    bffd:      	subl	%esi, %edi
    bfff:      	movl	%edi, 0x50(%rsp)
    c003:      	subq	%rsi, %rax
    c006:      	jb	0x17392 <generic_kprobe_path+0xba72>
    c00c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c012:      	ja	0x17392 <generic_kprobe_path+0xba72>
    c018:      	cmpl	%r15d, %r12d
    c01b:      	jbe	0xc021 <generic_kprobe_path+0x701>
    c01d:      	movb	$0x2f, (%rbx,%rax)
    c021:      	xorl	%edi, %edi
    c023:      	cmpl	%r15d, %r12d
    c026:      	seta	%dil
    c02a:      	movzbl	%cl, %esi
    c02d:      	addq	%rax, %rbx
    c030:      	addq	%rbx, %rdi
    c033:      	movl	$0x4, %eax
    c038:      	callq	*%rax
    c03a:      	movq	%rbx, 0x48(%rsp)
    c03f:      	cmpl	%r15d, %r12d
    c042:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    c048:      	movq	0x8(%rsp), %r12
    c04d:      	movq	%r12, 0x30(%rsp)
    c052:      	movq	0x38(%rsp), %rdx
    c057:      	movq	0x40(%rsp), %r15
    c05c:      	cmpq	0x18(%rsp), %r12
    c061:      	je	0xc0bd <generic_kprobe_path+0x79d>
    c063:      	jmp	0xc0c8 <generic_kprobe_path+0x7a8>
    c065:      	leaq	0x10(%r15), %rdx
    c069:      	movl	$0x4, %eax
    c06e:      	movq	%rbp, %rdi
    c071:      	movl	$0x8, %esi
    c076:      	callq	*%rax
    c078:      	movq	0x40(%rsp), %rax
    c07d:      	cmpq	(%rsp), %rax
    c081:      	je	0x1738d <generic_kprobe_path+0xba6d>
    c087:      	addq	$0x18, %r15
    c08b:      	movl	$0x4, %eax
    c090:      	leaq	0x30(%rsp), %rdi
    c095:      	movl	$0x8, %esi
    c09a:      	movq	%r15, %rdx
    c09d:      	callq	*%rax
    c09f:      	movq	(%rsp), %r15
    c0a3:      	movq	%r15, 0x40(%rsp)
    c0a8:      	leaq	0x20(%r15), %rdx
    c0ac:      	movq	%rdx, 0x38(%rsp)
    c0b1:      	movq	0x30(%rsp), %r12
    c0b6:      	cmpq	0x18(%rsp), %r12
    c0bb:      	jne	0xc0c8 <generic_kprobe_path+0x7a8>
    c0bd:      	cmpq	0x20(%rsp), %rdx
    c0c2:      	je	0x1738d <generic_kprobe_path+0xba6d>
    c0c8:      	movl	$0x4, %eax
    c0cd:      	leaq	0x10(%rsp), %rdi
    c0d2:      	movl	$0x8, %esi
    c0d7:      	callq	*%rax
    c0d9:      	cmpq	0x10(%rsp), %r12
    c0de:      	je	0xc1dd <generic_kprobe_path+0x8bd>
    c0e4:      	leaq	0x18(%r12), %rbx
    c0e9:      	movl	$0x4, %eax
    c0ee:      	movq	%rbp, %rdi
    c0f1:      	movl	$0x8, %esi
    c0f6:      	movq	%rbx, %rdx
    c0f9:      	callq	*%rax
    c0fb:      	cmpq	%r12, (%rsp)
    c0ff:      	je	0xc1dd <generic_kprobe_path+0x8bd>
    c105:      	movl	$0x4, %eax
    c10a:      	leaq	0x8(%rsp), %rdi
    c10f:      	movl	$0x8, %esi
    c114:      	movq	%rbx, %rdx
    c117:      	callq	*%rax
    c119:      	addq	$0x20, %r12
    c11d:      	movl	$0x4, %eax
    c122:      	leaq	0x58(%rsp), %rdi
    c127:      	movl	$0x10, %ecx
    c12c:      	movl	$0x10, %esi
    c131:      	movq	%r12, %rdx
    c134:      	callq	*%rax
    c136:      	movq	0x28(%rsp), %rbx
    c13b:      	movq	0x48(%rsp), %rax
    c140:      	movl	0x5c(%rsp), %r15d
    c145:      	subq	%rbx, %rax
    c148:      	movl	0x50(%rsp), %r12d
    c14d:      	movl	%r15d, %edx
    c150:      	subl	%r12d, %edx
    c153:      	movl	$0x0, %ecx
    c158:      	cmovbl	%ecx, %edx
    c15b:      	addq	0x60(%rsp), %rdx
    c160:      	xorl	%esi, %esi
    c162:      	cmpl	%r15d, %r12d
    c165:      	seta	%sil
    c169:      	movl	%r15d, %ecx
    c16c:      	cmovbl	%r12d, %ecx
    c170:      	addl	%ecx, %esi
    c172:      	movl	%r12d, %edi
    c175:      	subl	%esi, %edi
    c177:      	movl	%edi, 0x50(%rsp)
    c17b:      	subq	%rsi, %rax
    c17e:      	jb	0x17392 <generic_kprobe_path+0xba72>
    c184:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c18a:      	ja	0x17392 <generic_kprobe_path+0xba72>
    c190:      	cmpl	%r15d, %r12d
    c193:      	jbe	0xc199 <generic_kprobe_path+0x879>
    c195:      	movb	$0x2f, (%rbx,%rax)
    c199:      	xorl	%edi, %edi
    c19b:      	cmpl	%r15d, %r12d
    c19e:      	seta	%dil
    c1a2:      	movzbl	%cl, %esi
    c1a5:      	addq	%rax, %rbx
    c1a8:      	addq	%rbx, %rdi
    c1ab:      	movl	$0x4, %eax
    c1b0:      	callq	*%rax
    c1b2:      	movq	%rbx, 0x48(%rsp)
    c1b7:      	cmpl	%r15d, %r12d
    c1ba:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    c1c0:      	movq	0x8(%rsp), %r12
    c1c5:      	movq	%r12, 0x30(%rsp)
    c1ca:      	movq	0x38(%rsp), %rdx
    c1cf:      	movq	0x40(%rsp), %r15
    c1d4:      	cmpq	0x18(%rsp), %r12
    c1d9:      	je	0xc235 <generic_kprobe_path+0x915>
    c1db:      	jmp	0xc240 <generic_kprobe_path+0x920>
    c1dd:      	leaq	0x10(%r15), %rdx
    c1e1:      	movl	$0x4, %eax
    c1e6:      	movq	%rbp, %rdi
    c1e9:      	movl	$0x8, %esi
    c1ee:      	callq	*%rax
    c1f0:      	movq	0x40(%rsp), %rax
    c1f5:      	cmpq	(%rsp), %rax
    c1f9:      	je	0x1738d <generic_kprobe_path+0xba6d>
    c1ff:      	addq	$0x18, %r15
    c203:      	movl	$0x4, %eax
    c208:      	leaq	0x30(%rsp), %rdi
    c20d:      	movl	$0x8, %esi
    c212:      	movq	%r15, %rdx
    c215:      	callq	*%rax
    c217:      	movq	(%rsp), %r15
    c21b:      	movq	%r15, 0x40(%rsp)
    c220:      	leaq	0x20(%r15), %rdx
    c224:      	movq	%rdx, 0x38(%rsp)
    c229:      	movq	0x30(%rsp), %r12
    c22e:      	cmpq	0x18(%rsp), %r12
    c233:      	jne	0xc240 <generic_kprobe_path+0x920>
    c235:      	cmpq	0x20(%rsp), %rdx
    c23a:      	je	0x1738d <generic_kprobe_path+0xba6d>
    c240:      	movl	$0x4, %eax
    c245:      	leaq	0x10(%rsp), %rdi
    c24a:      	movl	$0x8, %esi
    c24f:      	callq	*%rax
    c251:      	cmpq	0x10(%rsp), %r12
    c256:      	je	0xc355 <generic_kprobe_path+0xa35>
    c25c:      	leaq	0x18(%r12), %rbx
    c261:      	movl	$0x4, %eax
    c266:      	movq	%rbp, %rdi
    c269:      	movl	$0x8, %esi
    c26e:      	movq	%rbx, %rdx
    c271:      	callq	*%rax
    c273:      	cmpq	%r12, (%rsp)
    c277:      	je	0xc355 <generic_kprobe_path+0xa35>
    c27d:      	movl	$0x4, %eax
    c282:      	leaq	0x8(%rsp), %rdi
    c287:      	movl	$0x8, %esi
    c28c:      	movq	%rbx, %rdx
    c28f:      	callq	*%rax
    c291:      	addq	$0x20, %r12
    c295:      	movl	$0x4, %eax
    c29a:      	leaq	0x58(%rsp), %rdi
    c29f:      	movl	$0x10, %ecx
    c2a4:      	movl	$0x10, %esi
    c2a9:      	movq	%r12, %rdx
    c2ac:      	callq	*%rax
    c2ae:      	movq	0x28(%rsp), %rbx
    c2b3:      	movq	0x48(%rsp), %rax
    c2b8:      	movl	0x5c(%rsp), %r15d
    c2bd:      	subq	%rbx, %rax
    c2c0:      	movl	0x50(%rsp), %r12d
    c2c5:      	movl	%r15d, %edx
    c2c8:      	subl	%r12d, %edx
    c2cb:      	movl	$0x0, %ecx
    c2d0:      	cmovbl	%ecx, %edx
    c2d3:      	addq	0x60(%rsp), %rdx
    c2d8:      	xorl	%esi, %esi
    c2da:      	cmpl	%r15d, %r12d
    c2dd:      	seta	%sil
    c2e1:      	movl	%r15d, %ecx
    c2e4:      	cmovbl	%r12d, %ecx
    c2e8:      	addl	%ecx, %esi
    c2ea:      	movl	%r12d, %edi
    c2ed:      	subl	%esi, %edi
    c2ef:      	movl	%edi, 0x50(%rsp)
    c2f3:      	subq	%rsi, %rax
    c2f6:      	jb	0x17392 <generic_kprobe_path+0xba72>
    c2fc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c302:      	ja	0x17392 <generic_kprobe_path+0xba72>
    c308:      	cmpl	%r15d, %r12d
    c30b:      	jbe	0xc311 <generic_kprobe_path+0x9f1>
    c30d:      	movb	$0x2f, (%rbx,%rax)
    c311:      	xorl	%edi, %edi
    c313:      	cmpl	%r15d, %r12d
    c316:      	seta	%dil
    c31a:      	movzbl	%cl, %esi
    c31d:      	addq	%rax, %rbx
    c320:      	addq	%rbx, %rdi
    c323:      	movl	$0x4, %eax
    c328:      	callq	*%rax
    c32a:      	movq	%rbx, 0x48(%rsp)
    c32f:      	cmpl	%r15d, %r12d
    c332:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    c338:      	movq	0x8(%rsp), %r12
    c33d:      	movq	%r12, 0x30(%rsp)
    c342:      	movq	0x38(%rsp), %rdx
    c347:      	movq	0x40(%rsp), %r15
    c34c:      	cmpq	0x18(%rsp), %r12
    c351:      	je	0xc3ad <generic_kprobe_path+0xa8d>
    c353:      	jmp	0xc3b8 <generic_kprobe_path+0xa98>
    c355:      	leaq	0x10(%r15), %rdx
    c359:      	movl	$0x4, %eax
    c35e:      	movq	%rbp, %rdi
    c361:      	movl	$0x8, %esi
    c366:      	callq	*%rax
    c368:      	movq	0x40(%rsp), %rax
    c36d:      	cmpq	(%rsp), %rax
    c371:      	je	0x1738d <generic_kprobe_path+0xba6d>
    c377:      	addq	$0x18, %r15
    c37b:      	movl	$0x4, %eax
    c380:      	leaq	0x30(%rsp), %rdi
    c385:      	movl	$0x8, %esi
    c38a:      	movq	%r15, %rdx
    c38d:      	callq	*%rax
    c38f:      	movq	(%rsp), %r15
    c393:      	movq	%r15, 0x40(%rsp)
    c398:      	leaq	0x20(%r15), %rdx
    c39c:      	movq	%rdx, 0x38(%rsp)
    c3a1:      	movq	0x30(%rsp), %r12
    c3a6:      	cmpq	0x18(%rsp), %r12
    c3ab:      	jne	0xc3b8 <generic_kprobe_path+0xa98>
    c3ad:      	cmpq	0x20(%rsp), %rdx
    c3b2:      	je	0x1738d <generic_kprobe_path+0xba6d>
    c3b8:      	movl	$0x4, %eax
    c3bd:      	leaq	0x10(%rsp), %rdi
    c3c2:      	movl	$0x8, %esi
    c3c7:      	callq	*%rax
    c3c9:      	cmpq	0x10(%rsp), %r12
    c3ce:      	je	0xc4cd <generic_kprobe_path+0xbad>
    c3d4:      	leaq	0x18(%r12), %rbx
    c3d9:      	movl	$0x4, %eax
    c3de:      	movq	%rbp, %rdi
    c3e1:      	movl	$0x8, %esi
    c3e6:      	movq	%rbx, %rdx
    c3e9:      	callq	*%rax
    c3eb:      	cmpq	%r12, (%rsp)
    c3ef:      	je	0xc4cd <generic_kprobe_path+0xbad>
    c3f5:      	movl	$0x4, %eax
    c3fa:      	leaq	0x8(%rsp), %rdi
    c3ff:      	movl	$0x8, %esi
    c404:      	movq	%rbx, %rdx
    c407:      	callq	*%rax
    c409:      	addq	$0x20, %r12
    c40d:      	movl	$0x4, %eax
    c412:      	leaq	0x58(%rsp), %rdi
    c417:      	movl	$0x10, %ecx
    c41c:      	movl	$0x10, %esi
    c421:      	movq	%r12, %rdx
    c424:      	callq	*%rax
    c426:      	movq	0x28(%rsp), %rbx
    c42b:      	movq	0x48(%rsp), %rax
    c430:      	movl	0x5c(%rsp), %r15d
    c435:      	subq	%rbx, %rax
    c438:      	movl	0x50(%rsp), %r12d
    c43d:      	movl	%r15d, %edx
    c440:      	subl	%r12d, %edx
    c443:      	movl	$0x0, %ecx
    c448:      	cmovbl	%ecx, %edx
    c44b:      	addq	0x60(%rsp), %rdx
    c450:      	xorl	%esi, %esi
    c452:      	cmpl	%r15d, %r12d
    c455:      	seta	%sil
    c459:      	movl	%r15d, %ecx
    c45c:      	cmovbl	%r12d, %ecx
    c460:      	addl	%ecx, %esi
    c462:      	movl	%r12d, %edi
    c465:      	subl	%esi, %edi
    c467:      	movl	%edi, 0x50(%rsp)
    c46b:      	subq	%rsi, %rax
    c46e:      	jb	0x17392 <generic_kprobe_path+0xba72>
    c474:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c47a:      	ja	0x17392 <generic_kprobe_path+0xba72>
    c480:      	cmpl	%r15d, %r12d
    c483:      	jbe	0xc489 <generic_kprobe_path+0xb69>
    c485:      	movb	$0x2f, (%rbx,%rax)
    c489:      	xorl	%edi, %edi
    c48b:      	cmpl	%r15d, %r12d
    c48e:      	seta	%dil
    c492:      	movzbl	%cl, %esi
    c495:      	addq	%rax, %rbx
    c498:      	addq	%rbx, %rdi
    c49b:      	movl	$0x4, %eax
    c4a0:      	callq	*%rax
    c4a2:      	movq	%rbx, 0x48(%rsp)
    c4a7:      	cmpl	%r15d, %r12d
    c4aa:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    c4b0:      	movq	0x8(%rsp), %r12
    c4b5:      	movq	%r12, 0x30(%rsp)
    c4ba:      	movq	0x38(%rsp), %rdx
    c4bf:      	movq	0x40(%rsp), %r15
    c4c4:      	cmpq	0x18(%rsp), %r12
    c4c9:      	je	0xc525 <generic_kprobe_path+0xc05>
    c4cb:      	jmp	0xc530 <generic_kprobe_path+0xc10>
    c4cd:      	leaq	0x10(%r15), %rdx
    c4d1:      	movl	$0x4, %eax
    c4d6:      	movq	%rbp, %rdi
    c4d9:      	movl	$0x8, %esi
    c4de:      	callq	*%rax
    c4e0:      	movq	0x40(%rsp), %rax
    c4e5:      	cmpq	(%rsp), %rax
    c4e9:      	je	0x1738d <generic_kprobe_path+0xba6d>
    c4ef:      	addq	$0x18, %r15
    c4f3:      	movl	$0x4, %eax
    c4f8:      	leaq	0x30(%rsp), %rdi
    c4fd:      	movl	$0x8, %esi
    c502:      	movq	%r15, %rdx
    c505:      	callq	*%rax
    c507:      	movq	(%rsp), %r15
    c50b:      	movq	%r15, 0x40(%rsp)
    c510:      	leaq	0x20(%r15), %rdx
    c514:      	movq	%rdx, 0x38(%rsp)
    c519:      	movq	0x30(%rsp), %r12
    c51e:      	cmpq	0x18(%rsp), %r12
    c523:      	jne	0xc530 <generic_kprobe_path+0xc10>
    c525:      	cmpq	0x20(%rsp), %rdx
    c52a:      	je	0x1738d <generic_kprobe_path+0xba6d>
    c530:      	movl	$0x4, %eax
    c535:      	leaq	0x10(%rsp), %rdi
    c53a:      	movl	$0x8, %esi
    c53f:      	callq	*%rax
    c541:      	cmpq	0x10(%rsp), %r12
    c546:      	je	0xc645 <generic_kprobe_path+0xd25>
    c54c:      	leaq	0x18(%r12), %rbx
    c551:      	movl	$0x4, %eax
    c556:      	movq	%rbp, %rdi
    c559:      	movl	$0x8, %esi
    c55e:      	movq	%rbx, %rdx
    c561:      	callq	*%rax
    c563:      	cmpq	%r12, (%rsp)
    c567:      	je	0xc645 <generic_kprobe_path+0xd25>
    c56d:      	movl	$0x4, %eax
    c572:      	leaq	0x8(%rsp), %rdi
    c577:      	movl	$0x8, %esi
    c57c:      	movq	%rbx, %rdx
    c57f:      	callq	*%rax
    c581:      	addq	$0x20, %r12
    c585:      	movl	$0x4, %eax
    c58a:      	leaq	0x58(%rsp), %rdi
    c58f:      	movl	$0x10, %ecx
    c594:      	movl	$0x10, %esi
    c599:      	movq	%r12, %rdx
    c59c:      	callq	*%rax
    c59e:      	movq	0x28(%rsp), %rbx
    c5a3:      	movq	0x48(%rsp), %rax
    c5a8:      	movl	0x5c(%rsp), %r15d
    c5ad:      	subq	%rbx, %rax
    c5b0:      	movl	0x50(%rsp), %r12d
    c5b5:      	movl	%r15d, %edx
    c5b8:      	subl	%r12d, %edx
    c5bb:      	movl	$0x0, %ecx
    c5c0:      	cmovbl	%ecx, %edx
    c5c3:      	addq	0x60(%rsp), %rdx
    c5c8:      	xorl	%esi, %esi
    c5ca:      	cmpl	%r15d, %r12d
    c5cd:      	seta	%sil
    c5d1:      	movl	%r15d, %ecx
    c5d4:      	cmovbl	%r12d, %ecx
    c5d8:      	addl	%ecx, %esi
    c5da:      	movl	%r12d, %edi
    c5dd:      	subl	%esi, %edi
    c5df:      	movl	%edi, 0x50(%rsp)
    c5e3:      	subq	%rsi, %rax
    c5e6:      	jb	0x17392 <generic_kprobe_path+0xba72>
    c5ec:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c5f2:      	ja	0x17392 <generic_kprobe_path+0xba72>
    c5f8:      	cmpl	%r15d, %r12d
    c5fb:      	jbe	0xc601 <generic_kprobe_path+0xce1>
    c5fd:      	movb	$0x2f, (%rbx,%rax)
    c601:      	xorl	%edi, %edi
    c603:      	cmpl	%r15d, %r12d
    c606:      	seta	%dil
    c60a:      	movzbl	%cl, %esi
    c60d:      	addq	%rax, %rbx
    c610:      	addq	%rbx, %rdi
    c613:      	movl	$0x4, %eax
    c618:      	callq	*%rax
    c61a:      	movq	%rbx, 0x48(%rsp)
    c61f:      	cmpl	%r15d, %r12d
    c622:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    c628:      	movq	0x8(%rsp), %r12
    c62d:      	movq	%r12, 0x30(%rsp)
    c632:      	movq	0x38(%rsp), %rdx
    c637:      	movq	0x40(%rsp), %r15
    c63c:      	cmpq	0x18(%rsp), %r12
    c641:      	je	0xc69d <generic_kprobe_path+0xd7d>
    c643:      	jmp	0xc6a8 <generic_kprobe_path+0xd88>
    c645:      	leaq	0x10(%r15), %rdx
    c649:      	movl	$0x4, %eax
    c64e:      	movq	%rbp, %rdi
    c651:      	movl	$0x8, %esi
    c656:      	callq	*%rax
    c658:      	movq	0x40(%rsp), %rax
    c65d:      	cmpq	(%rsp), %rax
    c661:      	je	0x1738d <generic_kprobe_path+0xba6d>
    c667:      	addq	$0x18, %r15
    c66b:      	movl	$0x4, %eax
    c670:      	leaq	0x30(%rsp), %rdi
    c675:      	movl	$0x8, %esi
    c67a:      	movq	%r15, %rdx
    c67d:      	callq	*%rax
    c67f:      	movq	(%rsp), %r15
    c683:      	movq	%r15, 0x40(%rsp)
    c688:      	leaq	0x20(%r15), %rdx
    c68c:      	movq	%rdx, 0x38(%rsp)
    c691:      	movq	0x30(%rsp), %r12
    c696:      	cmpq	0x18(%rsp), %r12
    c69b:      	jne	0xc6a8 <generic_kprobe_path+0xd88>
    c69d:      	cmpq	0x20(%rsp), %rdx
    c6a2:      	je	0x1738d <generic_kprobe_path+0xba6d>
    c6a8:      	movl	$0x4, %eax
    c6ad:      	leaq	0x10(%rsp), %rdi
    c6b2:      	movl	$0x8, %esi
    c6b7:      	callq	*%rax
    c6b9:      	cmpq	0x10(%rsp), %r12
    c6be:      	je	0xc7bd <generic_kprobe_path+0xe9d>
    c6c4:      	leaq	0x18(%r12), %rbx
    c6c9:      	movl	$0x4, %eax
    c6ce:      	movq	%rbp, %rdi
    c6d1:      	movl	$0x8, %esi
    c6d6:      	movq	%rbx, %rdx
    c6d9:      	callq	*%rax
    c6db:      	cmpq	%r12, (%rsp)
    c6df:      	je	0xc7bd <generic_kprobe_path+0xe9d>
    c6e5:      	movl	$0x4, %eax
    c6ea:      	leaq	0x8(%rsp), %rdi
    c6ef:      	movl	$0x8, %esi
    c6f4:      	movq	%rbx, %rdx
    c6f7:      	callq	*%rax
    c6f9:      	addq	$0x20, %r12
    c6fd:      	movl	$0x4, %eax
    c702:      	leaq	0x58(%rsp), %rdi
    c707:      	movl	$0x10, %ecx
    c70c:      	movl	$0x10, %esi
    c711:      	movq	%r12, %rdx
    c714:      	callq	*%rax
    c716:      	movq	0x28(%rsp), %rbx
    c71b:      	movq	0x48(%rsp), %rax
    c720:      	movl	0x5c(%rsp), %r15d
    c725:      	subq	%rbx, %rax
    c728:      	movl	0x50(%rsp), %r12d
    c72d:      	movl	%r15d, %edx
    c730:      	subl	%r12d, %edx
    c733:      	movl	$0x0, %ecx
    c738:      	cmovbl	%ecx, %edx
    c73b:      	addq	0x60(%rsp), %rdx
    c740:      	xorl	%esi, %esi
    c742:      	cmpl	%r15d, %r12d
    c745:      	seta	%sil
    c749:      	movl	%r15d, %ecx
    c74c:      	cmovbl	%r12d, %ecx
    c750:      	addl	%ecx, %esi
    c752:      	movl	%r12d, %edi
    c755:      	subl	%esi, %edi
    c757:      	movl	%edi, 0x50(%rsp)
    c75b:      	subq	%rsi, %rax
    c75e:      	jb	0x17392 <generic_kprobe_path+0xba72>
    c764:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c76a:      	ja	0x17392 <generic_kprobe_path+0xba72>
    c770:      	cmpl	%r15d, %r12d
    c773:      	jbe	0xc779 <generic_kprobe_path+0xe59>
    c775:      	movb	$0x2f, (%rbx,%rax)
    c779:      	xorl	%edi, %edi
    c77b:      	cmpl	%r15d, %r12d
    c77e:      	seta	%dil
    c782:      	movzbl	%cl, %esi
    c785:      	addq	%rax, %rbx
    c788:      	addq	%rbx, %rdi
    c78b:      	movl	$0x4, %eax
    c790:      	callq	*%rax
    c792:      	movq	%rbx, 0x48(%rsp)
    c797:      	cmpl	%r15d, %r12d
    c79a:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    c7a0:      	movq	0x8(%rsp), %r12
    c7a5:      	movq	%r12, 0x30(%rsp)
    c7aa:      	movq	0x38(%rsp), %rdx
    c7af:      	movq	0x40(%rsp), %r15
    c7b4:      	cmpq	0x18(%rsp), %r12
    c7b9:      	je	0xc815 <generic_kprobe_path+0xef5>
    c7bb:      	jmp	0xc820 <generic_kprobe_path+0xf00>
    c7bd:      	leaq	0x10(%r15), %rdx
    c7c1:      	movl	$0x4, %eax
    c7c6:      	movq	%rbp, %rdi
    c7c9:      	movl	$0x8, %esi
    c7ce:      	callq	*%rax
    c7d0:      	movq	0x40(%rsp), %rax
    c7d5:      	cmpq	(%rsp), %rax
    c7d9:      	je	0x1738d <generic_kprobe_path+0xba6d>
    c7df:      	addq	$0x18, %r15
    c7e3:      	movl	$0x4, %eax
    c7e8:      	leaq	0x30(%rsp), %rdi
    c7ed:      	movl	$0x8, %esi
    c7f2:      	movq	%r15, %rdx
    c7f5:      	callq	*%rax
    c7f7:      	movq	(%rsp), %r15
    c7fb:      	movq	%r15, 0x40(%rsp)
    c800:      	leaq	0x20(%r15), %rdx
    c804:      	movq	%rdx, 0x38(%rsp)
    c809:      	movq	0x30(%rsp), %r12
    c80e:      	cmpq	0x18(%rsp), %r12
    c813:      	jne	0xc820 <generic_kprobe_path+0xf00>
    c815:      	cmpq	0x20(%rsp), %rdx
    c81a:      	je	0x1738d <generic_kprobe_path+0xba6d>
    c820:      	movl	$0x4, %eax
    c825:      	leaq	0x10(%rsp), %rdi
    c82a:      	movl	$0x8, %esi
    c82f:      	callq	*%rax
    c831:      	cmpq	0x10(%rsp), %r12
    c836:      	je	0xc92e <generic_kprobe_path+0x100e>
    c83c:      	leaq	0x18(%r12), %rbx
    c841:      	movl	$0x4, %eax
    c846:      	movq	%rbp, %rdi
    c849:      	movl	$0x8, %esi
    c84e:      	movq	%rbx, %rdx
    c851:      	callq	*%rax
    c853:      	cmpq	%r12, (%rsp)
    c857:      	je	0xc92e <generic_kprobe_path+0x100e>
    c85d:      	movl	$0x4, %eax
    c862:      	leaq	0x8(%rsp), %rdi
    c867:      	movl	$0x8, %esi
    c86c:      	movq	%rbx, %rdx
    c86f:      	callq	*%rax
    c871:      	addq	$0x20, %r12
    c875:      	movl	$0x4, %eax
    c87a:      	leaq	0x58(%rsp), %rdi
    c87f:      	movl	$0x10, %ecx
    c884:      	movl	$0x10, %esi
    c889:      	movq	%r12, %rdx
    c88c:      	callq	*%rax
    c88e:      	movq	0x28(%rsp), %rbx
    c893:      	movq	0x48(%rsp), %rax
    c898:      	movl	0x5c(%rsp), %r15d
    c89d:      	subq	%rbx, %rax
    c8a0:      	movl	0x50(%rsp), %r12d
    c8a5:      	movl	%r15d, %edx
    c8a8:      	subl	%r12d, %edx
    c8ab:      	movl	$0x0, %ecx
    c8b0:      	cmovbl	%ecx, %edx
    c8b3:      	addq	0x60(%rsp), %rdx
    c8b8:      	xorl	%esi, %esi
    c8ba:      	cmpl	%r15d, %r12d
    c8bd:      	seta	%sil
    c8c1:      	movl	%r15d, %ecx
    c8c4:      	cmovbl	%r12d, %ecx
    c8c8:      	addl	%ecx, %esi
    c8ca:      	movl	%r12d, %edi
    c8cd:      	subl	%esi, %edi
    c8cf:      	movl	%edi, 0x50(%rsp)
    c8d3:      	subq	%rsi, %rax
    c8d6:      	jb	0x17392 <generic_kprobe_path+0xba72>
    c8dc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c8e2:      	ja	0x17392 <generic_kprobe_path+0xba72>
    c8e8:      	cmpl	%r15d, %r12d
    c8eb:      	jbe	0xc8f1 <generic_kprobe_path+0xfd1>
    c8ed:      	movb	$0x2f, (%rbx,%rax)
    c8f1:      	xorl	%edi, %edi
    c8f3:      	cmpl	%r15d, %r12d
    c8f6:      	seta	%dil
    c8fa:      	movzbl	%cl, %esi
    c8fd:      	addq	%rax, %rbx
    c900:      	addq	%rbx, %rdi
    c903:      	movl	$0x4, %eax
    c908:      	callq	*%rax
    c90a:      	movq	%rbx, 0x48(%rsp)
    c90f:      	cmpl	%r15d, %r12d
    c912:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    c918:      	movq	0x8(%rsp), %r12
    c91d:      	movq	%r12, 0x30(%rsp)
    c922:      	movq	0x38(%rsp), %rdx
    c927:      	movq	0x40(%rsp), %r15
    c92c:      	jmp	0xc97f <generic_kprobe_path+0x105f>
    c92e:      	leaq	0x10(%r15), %rdx
    c932:      	movl	$0x4, %eax
    c937:      	movq	%rbp, %rdi
    c93a:      	movl	$0x8, %esi
    c93f:      	callq	*%rax
    c941:      	movq	0x40(%rsp), %rax
    c946:      	cmpq	(%rsp), %rax
    c94a:      	je	0x1738d <generic_kprobe_path+0xba6d>
    c950:      	addq	$0x18, %r15
    c954:      	movl	$0x4, %eax
    c959:      	leaq	0x30(%rsp), %rdi
    c95e:      	movl	$0x8, %esi
    c963:      	movq	%r15, %rdx
    c966:      	callq	*%rax
    c968:      	movq	(%rsp), %r15
    c96c:      	movq	%r15, 0x40(%rsp)
    c971:      	leaq	0x20(%r15), %rdx
    c975:      	movq	%rdx, 0x38(%rsp)
    c97a:      	movq	0x30(%rsp), %r12
    c97f:      	cmpq	0x18(%rsp), %r12
    c984:      	jne	0xc991 <generic_kprobe_path+0x1071>
    c986:      	cmpq	0x20(%rsp), %rdx
    c98b:      	je	0x1738d <generic_kprobe_path+0xba6d>
    c991:      	movl	$0x4, %eax
    c996:      	leaq	0x10(%rsp), %rdi
    c99b:      	movl	$0x8, %esi
    c9a0:      	callq	*%rax
    c9a2:      	cmpq	0x10(%rsp), %r12
    c9a7:      	je	0xca9f <generic_kprobe_path+0x117f>
    c9ad:      	leaq	0x18(%r12), %rbx
    c9b2:      	movl	$0x4, %eax
    c9b7:      	movq	%rbp, %rdi
    c9ba:      	movl	$0x8, %esi
    c9bf:      	movq	%rbx, %rdx
    c9c2:      	callq	*%rax
    c9c4:      	cmpq	%r12, (%rsp)
    c9c8:      	je	0xca9f <generic_kprobe_path+0x117f>
    c9ce:      	movl	$0x4, %eax
    c9d3:      	leaq	0x8(%rsp), %rdi
    c9d8:      	movl	$0x8, %esi
    c9dd:      	movq	%rbx, %rdx
    c9e0:      	callq	*%rax
    c9e2:      	addq	$0x20, %r12
    c9e6:      	movl	$0x4, %eax
    c9eb:      	leaq	0x58(%rsp), %rdi
    c9f0:      	movl	$0x10, %ecx
    c9f5:      	movl	$0x10, %esi
    c9fa:      	movq	%r12, %rdx
    c9fd:      	callq	*%rax
    c9ff:      	movq	0x28(%rsp), %rbx
    ca04:      	movq	0x48(%rsp), %rax
    ca09:      	movl	0x5c(%rsp), %r15d
    ca0e:      	subq	%rbx, %rax
    ca11:      	movl	0x50(%rsp), %r12d
    ca16:      	movl	%r15d, %edx
    ca19:      	subl	%r12d, %edx
    ca1c:      	movl	$0x0, %ecx
    ca21:      	cmovbl	%ecx, %edx
    ca24:      	addq	0x60(%rsp), %rdx
    ca29:      	xorl	%esi, %esi
    ca2b:      	cmpl	%r15d, %r12d
    ca2e:      	seta	%sil
    ca32:      	movl	%r15d, %ecx
    ca35:      	cmovbl	%r12d, %ecx
    ca39:      	addl	%ecx, %esi
    ca3b:      	movl	%r12d, %edi
    ca3e:      	subl	%esi, %edi
    ca40:      	movl	%edi, 0x50(%rsp)
    ca44:      	subq	%rsi, %rax
    ca47:      	jb	0x17392 <generic_kprobe_path+0xba72>
    ca4d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ca53:      	ja	0x17392 <generic_kprobe_path+0xba72>
    ca59:      	cmpl	%r15d, %r12d
    ca5c:      	jbe	0xca62 <generic_kprobe_path+0x1142>
    ca5e:      	movb	$0x2f, (%rbx,%rax)
    ca62:      	xorl	%edi, %edi
    ca64:      	cmpl	%r15d, %r12d
    ca67:      	seta	%dil
    ca6b:      	movzbl	%cl, %esi
    ca6e:      	addq	%rax, %rbx
    ca71:      	addq	%rbx, %rdi
    ca74:      	movl	$0x4, %eax
    ca79:      	callq	*%rax
    ca7b:      	movq	%rbx, 0x48(%rsp)
    ca80:      	cmpl	%r15d, %r12d
    ca83:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    ca89:      	movq	0x8(%rsp), %r12
    ca8e:      	movq	%r12, 0x30(%rsp)
    ca93:      	movq	0x38(%rsp), %rdx
    ca98:      	movq	0x40(%rsp), %r15
    ca9d:      	jmp	0xcaf0 <generic_kprobe_path+0x11d0>
    ca9f:      	leaq	0x10(%r15), %rdx
    caa3:      	movl	$0x4, %eax
    caa8:      	movq	%rbp, %rdi
    caab:      	movl	$0x8, %esi
    cab0:      	callq	*%rax
    cab2:      	movq	0x40(%rsp), %rax
    cab7:      	cmpq	(%rsp), %rax
    cabb:      	je	0x1738d <generic_kprobe_path+0xba6d>
    cac1:      	addq	$0x18, %r15
    cac5:      	movl	$0x4, %eax
    caca:      	leaq	0x30(%rsp), %rdi
    cacf:      	movl	$0x8, %esi
    cad4:      	movq	%r15, %rdx
    cad7:      	callq	*%rax
    cad9:      	movq	(%rsp), %r15
    cadd:      	movq	%r15, 0x40(%rsp)
    cae2:      	leaq	0x20(%r15), %rdx
    cae6:      	movq	%rdx, 0x38(%rsp)
    caeb:      	movq	0x30(%rsp), %r12
    caf0:      	cmpq	0x18(%rsp), %r12
    caf5:      	jne	0xcb02 <generic_kprobe_path+0x11e2>
    caf7:      	cmpq	0x20(%rsp), %rdx
    cafc:      	je	0x1738d <generic_kprobe_path+0xba6d>
    cb02:      	movl	$0x4, %eax
    cb07:      	leaq	0x10(%rsp), %rdi
    cb0c:      	movl	$0x8, %esi
    cb11:      	callq	*%rax
    cb13:      	cmpq	0x10(%rsp), %r12
    cb18:      	je	0xcc10 <generic_kprobe_path+0x12f0>
    cb1e:      	leaq	0x18(%r12), %rbx
    cb23:      	movl	$0x4, %eax
    cb28:      	movq	%rbp, %rdi
    cb2b:      	movl	$0x8, %esi
    cb30:      	movq	%rbx, %rdx
    cb33:      	callq	*%rax
    cb35:      	cmpq	%r12, (%rsp)
    cb39:      	je	0xcc10 <generic_kprobe_path+0x12f0>
    cb3f:      	movl	$0x4, %eax
    cb44:      	leaq	0x8(%rsp), %rdi
    cb49:      	movl	$0x8, %esi
    cb4e:      	movq	%rbx, %rdx
    cb51:      	callq	*%rax
    cb53:      	addq	$0x20, %r12
    cb57:      	movl	$0x4, %eax
    cb5c:      	leaq	0x58(%rsp), %rdi
    cb61:      	movl	$0x10, %ecx
    cb66:      	movl	$0x10, %esi
    cb6b:      	movq	%r12, %rdx
    cb6e:      	callq	*%rax
    cb70:      	movq	0x28(%rsp), %rbx
    cb75:      	movq	0x48(%rsp), %rax
    cb7a:      	movl	0x5c(%rsp), %r15d
    cb7f:      	subq	%rbx, %rax
    cb82:      	movl	0x50(%rsp), %r12d
    cb87:      	movl	%r15d, %edx
    cb8a:      	subl	%r12d, %edx
    cb8d:      	movl	$0x0, %ecx
    cb92:      	cmovbl	%ecx, %edx
    cb95:      	addq	0x60(%rsp), %rdx
    cb9a:      	xorl	%esi, %esi
    cb9c:      	cmpl	%r15d, %r12d
    cb9f:      	seta	%sil
    cba3:      	movl	%r15d, %ecx
    cba6:      	cmovbl	%r12d, %ecx
    cbaa:      	addl	%ecx, %esi
    cbac:      	movl	%r12d, %edi
    cbaf:      	subl	%esi, %edi
    cbb1:      	movl	%edi, 0x50(%rsp)
    cbb5:      	subq	%rsi, %rax
    cbb8:      	jb	0x17392 <generic_kprobe_path+0xba72>
    cbbe:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    cbc4:      	ja	0x17392 <generic_kprobe_path+0xba72>
    cbca:      	cmpl	%r15d, %r12d
    cbcd:      	jbe	0xcbd3 <generic_kprobe_path+0x12b3>
    cbcf:      	movb	$0x2f, (%rbx,%rax)
    cbd3:      	xorl	%edi, %edi
    cbd5:      	cmpl	%r15d, %r12d
    cbd8:      	seta	%dil
    cbdc:      	movzbl	%cl, %esi
    cbdf:      	addq	%rax, %rbx
    cbe2:      	addq	%rbx, %rdi
    cbe5:      	movl	$0x4, %eax
    cbea:      	callq	*%rax
    cbec:      	movq	%rbx, 0x48(%rsp)
    cbf1:      	cmpl	%r15d, %r12d
    cbf4:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    cbfa:      	movq	0x8(%rsp), %r12
    cbff:      	movq	%r12, 0x30(%rsp)
    cc04:      	movq	0x38(%rsp), %rdx
    cc09:      	movq	0x40(%rsp), %r15
    cc0e:      	jmp	0xcc61 <generic_kprobe_path+0x1341>
    cc10:      	leaq	0x10(%r15), %rdx
    cc14:      	movl	$0x4, %eax
    cc19:      	movq	%rbp, %rdi
    cc1c:      	movl	$0x8, %esi
    cc21:      	callq	*%rax
    cc23:      	movq	0x40(%rsp), %rax
    cc28:      	cmpq	(%rsp), %rax
    cc2c:      	je	0x1738d <generic_kprobe_path+0xba6d>
    cc32:      	addq	$0x18, %r15
    cc36:      	movl	$0x4, %eax
    cc3b:      	leaq	0x30(%rsp), %rdi
    cc40:      	movl	$0x8, %esi
    cc45:      	movq	%r15, %rdx
    cc48:      	callq	*%rax
    cc4a:      	movq	(%rsp), %r15
    cc4e:      	movq	%r15, 0x40(%rsp)
    cc53:      	leaq	0x20(%r15), %rdx
    cc57:      	movq	%rdx, 0x38(%rsp)
    cc5c:      	movq	0x30(%rsp), %r12
    cc61:      	cmpq	0x18(%rsp), %r12
    cc66:      	jne	0xcc73 <generic_kprobe_path+0x1353>
    cc68:      	cmpq	0x20(%rsp), %rdx
    cc6d:      	je	0x1738d <generic_kprobe_path+0xba6d>
    cc73:      	movl	$0x4, %eax
    cc78:      	leaq	0x10(%rsp), %rdi
    cc7d:      	movl	$0x8, %esi
    cc82:      	callq	*%rax
    cc84:      	cmpq	0x10(%rsp), %r12
    cc89:      	je	0xcd81 <generic_kprobe_path+0x1461>
    cc8f:      	leaq	0x18(%r12), %rbx
    cc94:      	movl	$0x4, %eax
    cc99:      	movq	%rbp, %rdi
    cc9c:      	movl	$0x8, %esi
    cca1:      	movq	%rbx, %rdx
    cca4:      	callq	*%rax
    cca6:      	cmpq	%r12, (%rsp)
    ccaa:      	je	0xcd81 <generic_kprobe_path+0x1461>
    ccb0:      	movl	$0x4, %eax
    ccb5:      	leaq	0x8(%rsp), %rdi
    ccba:      	movl	$0x8, %esi
    ccbf:      	movq	%rbx, %rdx
    ccc2:      	callq	*%rax
    ccc4:      	addq	$0x20, %r12
    ccc8:      	movl	$0x4, %eax
    cccd:      	leaq	0x58(%rsp), %rdi
    ccd2:      	movl	$0x10, %ecx
    ccd7:      	movl	$0x10, %esi
    ccdc:      	movq	%r12, %rdx
    ccdf:      	callq	*%rax
    cce1:      	movq	0x28(%rsp), %rbx
    cce6:      	movq	0x48(%rsp), %rax
    cceb:      	movl	0x5c(%rsp), %r15d
    ccf0:      	subq	%rbx, %rax
    ccf3:      	movl	0x50(%rsp), %r12d
    ccf8:      	movl	%r15d, %edx
    ccfb:      	subl	%r12d, %edx
    ccfe:      	movl	$0x0, %ecx
    cd03:      	cmovbl	%ecx, %edx
    cd06:      	addq	0x60(%rsp), %rdx
    cd0b:      	xorl	%esi, %esi
    cd0d:      	cmpl	%r15d, %r12d
    cd10:      	seta	%sil
    cd14:      	movl	%r15d, %ecx
    cd17:      	cmovbl	%r12d, %ecx
    cd1b:      	addl	%ecx, %esi
    cd1d:      	movl	%r12d, %edi
    cd20:      	subl	%esi, %edi
    cd22:      	movl	%edi, 0x50(%rsp)
    cd26:      	subq	%rsi, %rax
    cd29:      	jb	0x17392 <generic_kprobe_path+0xba72>
    cd2f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    cd35:      	ja	0x17392 <generic_kprobe_path+0xba72>
    cd3b:      	cmpl	%r15d, %r12d
    cd3e:      	jbe	0xcd44 <generic_kprobe_path+0x1424>
    cd40:      	movb	$0x2f, (%rbx,%rax)
    cd44:      	xorl	%edi, %edi
    cd46:      	cmpl	%r15d, %r12d
    cd49:      	seta	%dil
    cd4d:      	movzbl	%cl, %esi
    cd50:      	addq	%rax, %rbx
    cd53:      	addq	%rbx, %rdi
    cd56:      	movl	$0x4, %eax
    cd5b:      	callq	*%rax
    cd5d:      	movq	%rbx, 0x48(%rsp)
    cd62:      	cmpl	%r15d, %r12d
    cd65:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    cd6b:      	movq	0x8(%rsp), %r12
    cd70:      	movq	%r12, 0x30(%rsp)
    cd75:      	movq	0x38(%rsp), %rdx
    cd7a:      	movq	0x40(%rsp), %r15
    cd7f:      	jmp	0xcdd2 <generic_kprobe_path+0x14b2>
    cd81:      	leaq	0x10(%r15), %rdx
    cd85:      	movl	$0x4, %eax
    cd8a:      	movq	%rbp, %rdi
    cd8d:      	movl	$0x8, %esi
    cd92:      	callq	*%rax
    cd94:      	movq	0x40(%rsp), %rax
    cd99:      	cmpq	(%rsp), %rax
    cd9d:      	je	0x1738d <generic_kprobe_path+0xba6d>
    cda3:      	addq	$0x18, %r15
    cda7:      	movl	$0x4, %eax
    cdac:      	leaq	0x30(%rsp), %rdi
    cdb1:      	movl	$0x8, %esi
    cdb6:      	movq	%r15, %rdx
    cdb9:      	callq	*%rax
    cdbb:      	movq	(%rsp), %r15
    cdbf:      	movq	%r15, 0x40(%rsp)
    cdc4:      	leaq	0x20(%r15), %rdx
    cdc8:      	movq	%rdx, 0x38(%rsp)
    cdcd:      	movq	0x30(%rsp), %r12
    cdd2:      	cmpq	0x18(%rsp), %r12
    cdd7:      	jne	0xcde4 <generic_kprobe_path+0x14c4>
    cdd9:      	cmpq	0x20(%rsp), %rdx
    cdde:      	je	0x1738d <generic_kprobe_path+0xba6d>
    cde4:      	movl	$0x4, %eax
    cde9:      	leaq	0x10(%rsp), %rdi
    cdee:      	movl	$0x8, %esi
    cdf3:      	callq	*%rax
    cdf5:      	cmpq	0x10(%rsp), %r12
    cdfa:      	je	0xcef2 <generic_kprobe_path+0x15d2>
    ce00:      	leaq	0x18(%r12), %rbx
    ce05:      	movl	$0x4, %eax
    ce0a:      	movq	%rbp, %rdi
    ce0d:      	movl	$0x8, %esi
    ce12:      	movq	%rbx, %rdx
    ce15:      	callq	*%rax
    ce17:      	cmpq	%r12, (%rsp)
    ce1b:      	je	0xcef2 <generic_kprobe_path+0x15d2>
    ce21:      	movl	$0x4, %eax
    ce26:      	leaq	0x8(%rsp), %rdi
    ce2b:      	movl	$0x8, %esi
    ce30:      	movq	%rbx, %rdx
    ce33:      	callq	*%rax
    ce35:      	addq	$0x20, %r12
    ce39:      	movl	$0x4, %eax
    ce3e:      	leaq	0x58(%rsp), %rdi
    ce43:      	movl	$0x10, %ecx
    ce48:      	movl	$0x10, %esi
    ce4d:      	movq	%r12, %rdx
    ce50:      	callq	*%rax
    ce52:      	movq	0x28(%rsp), %rbx
    ce57:      	movq	0x48(%rsp), %rax
    ce5c:      	movl	0x5c(%rsp), %r15d
    ce61:      	subq	%rbx, %rax
    ce64:      	movl	0x50(%rsp), %r12d
    ce69:      	movl	%r15d, %edx
    ce6c:      	subl	%r12d, %edx
    ce6f:      	movl	$0x0, %ecx
    ce74:      	cmovbl	%ecx, %edx
    ce77:      	addq	0x60(%rsp), %rdx
    ce7c:      	xorl	%esi, %esi
    ce7e:      	cmpl	%r15d, %r12d
    ce81:      	seta	%sil
    ce85:      	movl	%r15d, %ecx
    ce88:      	cmovbl	%r12d, %ecx
    ce8c:      	addl	%ecx, %esi
    ce8e:      	movl	%r12d, %edi
    ce91:      	subl	%esi, %edi
    ce93:      	movl	%edi, 0x50(%rsp)
    ce97:      	subq	%rsi, %rax
    ce9a:      	jb	0x17392 <generic_kprobe_path+0xba72>
    cea0:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    cea6:      	ja	0x17392 <generic_kprobe_path+0xba72>
    ceac:      	cmpl	%r15d, %r12d
    ceaf:      	jbe	0xceb5 <generic_kprobe_path+0x1595>
    ceb1:      	movb	$0x2f, (%rbx,%rax)
    ceb5:      	xorl	%edi, %edi
    ceb7:      	cmpl	%r15d, %r12d
    ceba:      	seta	%dil
    cebe:      	movzbl	%cl, %esi
    cec1:      	addq	%rax, %rbx
    cec4:      	addq	%rbx, %rdi
    cec7:      	movl	$0x4, %eax
    cecc:      	callq	*%rax
    cece:      	movq	%rbx, 0x48(%rsp)
    ced3:      	cmpl	%r15d, %r12d
    ced6:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    cedc:      	movq	0x8(%rsp), %r12
    cee1:      	movq	%r12, 0x30(%rsp)
    cee6:      	movq	0x38(%rsp), %rdx
    ceeb:      	movq	0x40(%rsp), %r15
    cef0:      	jmp	0xcf43 <generic_kprobe_path+0x1623>
    cef2:      	leaq	0x10(%r15), %rdx
    cef6:      	movl	$0x4, %eax
    cefb:      	movq	%rbp, %rdi
    cefe:      	movl	$0x8, %esi
    cf03:      	callq	*%rax
    cf05:      	movq	0x40(%rsp), %rax
    cf0a:      	cmpq	(%rsp), %rax
    cf0e:      	je	0x1738d <generic_kprobe_path+0xba6d>
    cf14:      	addq	$0x18, %r15
    cf18:      	movl	$0x4, %eax
    cf1d:      	leaq	0x30(%rsp), %rdi
    cf22:      	movl	$0x8, %esi
    cf27:      	movq	%r15, %rdx
    cf2a:      	callq	*%rax
    cf2c:      	movq	(%rsp), %r15
    cf30:      	movq	%r15, 0x40(%rsp)
    cf35:      	leaq	0x20(%r15), %rdx
    cf39:      	movq	%rdx, 0x38(%rsp)
    cf3e:      	movq	0x30(%rsp), %r12
    cf43:      	cmpq	0x18(%rsp), %r12
    cf48:      	jne	0xcf55 <generic_kprobe_path+0x1635>
    cf4a:      	cmpq	0x20(%rsp), %rdx
    cf4f:      	je	0x1738d <generic_kprobe_path+0xba6d>
    cf55:      	movl	$0x4, %eax
    cf5a:      	leaq	0x10(%rsp), %rdi
    cf5f:      	movl	$0x8, %esi
    cf64:      	callq	*%rax
    cf66:      	cmpq	0x10(%rsp), %r12
    cf6b:      	je	0xd063 <generic_kprobe_path+0x1743>
    cf71:      	leaq	0x18(%r12), %rbx
    cf76:      	movl	$0x4, %eax
    cf7b:      	movq	%rbp, %rdi
    cf7e:      	movl	$0x8, %esi
    cf83:      	movq	%rbx, %rdx
    cf86:      	callq	*%rax
    cf88:      	cmpq	%r12, (%rsp)
    cf8c:      	je	0xd063 <generic_kprobe_path+0x1743>
    cf92:      	movl	$0x4, %eax
    cf97:      	leaq	0x8(%rsp), %rdi
    cf9c:      	movl	$0x8, %esi
    cfa1:      	movq	%rbx, %rdx
    cfa4:      	callq	*%rax
    cfa6:      	addq	$0x20, %r12
    cfaa:      	movl	$0x4, %eax
    cfaf:      	leaq	0x58(%rsp), %rdi
    cfb4:      	movl	$0x10, %ecx
    cfb9:      	movl	$0x10, %esi
    cfbe:      	movq	%r12, %rdx
    cfc1:      	callq	*%rax
    cfc3:      	movq	0x28(%rsp), %rbx
    cfc8:      	movq	0x48(%rsp), %rax
    cfcd:      	movl	0x5c(%rsp), %r15d
    cfd2:      	subq	%rbx, %rax
    cfd5:      	movl	0x50(%rsp), %r12d
    cfda:      	movl	%r15d, %edx
    cfdd:      	subl	%r12d, %edx
    cfe0:      	movl	$0x0, %ecx
    cfe5:      	cmovbl	%ecx, %edx
    cfe8:      	addq	0x60(%rsp), %rdx
    cfed:      	xorl	%esi, %esi
    cfef:      	cmpl	%r15d, %r12d
    cff2:      	seta	%sil
    cff6:      	movl	%r15d, %ecx
    cff9:      	cmovbl	%r12d, %ecx
    cffd:      	addl	%ecx, %esi
    cfff:      	movl	%r12d, %edi
    d002:      	subl	%esi, %edi
    d004:      	movl	%edi, 0x50(%rsp)
    d008:      	subq	%rsi, %rax
    d00b:      	jb	0x17392 <generic_kprobe_path+0xba72>
    d011:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d017:      	ja	0x17392 <generic_kprobe_path+0xba72>
    d01d:      	cmpl	%r15d, %r12d
    d020:      	jbe	0xd026 <generic_kprobe_path+0x1706>
    d022:      	movb	$0x2f, (%rbx,%rax)
    d026:      	xorl	%edi, %edi
    d028:      	cmpl	%r15d, %r12d
    d02b:      	seta	%dil
    d02f:      	movzbl	%cl, %esi
    d032:      	addq	%rax, %rbx
    d035:      	addq	%rbx, %rdi
    d038:      	movl	$0x4, %eax
    d03d:      	callq	*%rax
    d03f:      	movq	%rbx, 0x48(%rsp)
    d044:      	cmpl	%r15d, %r12d
    d047:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    d04d:      	movq	0x8(%rsp), %r12
    d052:      	movq	%r12, 0x30(%rsp)
    d057:      	movq	0x38(%rsp), %rdx
    d05c:      	movq	0x40(%rsp), %r15
    d061:      	jmp	0xd0b4 <generic_kprobe_path+0x1794>
    d063:      	leaq	0x10(%r15), %rdx
    d067:      	movl	$0x4, %eax
    d06c:      	movq	%rbp, %rdi
    d06f:      	movl	$0x8, %esi
    d074:      	callq	*%rax
    d076:      	movq	0x40(%rsp), %rax
    d07b:      	cmpq	(%rsp), %rax
    d07f:      	je	0x1738d <generic_kprobe_path+0xba6d>
    d085:      	addq	$0x18, %r15
    d089:      	movl	$0x4, %eax
    d08e:      	leaq	0x30(%rsp), %rdi
    d093:      	movl	$0x8, %esi
    d098:      	movq	%r15, %rdx
    d09b:      	callq	*%rax
    d09d:      	movq	(%rsp), %r15
    d0a1:      	movq	%r15, 0x40(%rsp)
    d0a6:      	leaq	0x20(%r15), %rdx
    d0aa:      	movq	%rdx, 0x38(%rsp)
    d0af:      	movq	0x30(%rsp), %r12
    d0b4:      	cmpq	0x18(%rsp), %r12
    d0b9:      	jne	0xd0c6 <generic_kprobe_path+0x17a6>
    d0bb:      	cmpq	0x20(%rsp), %rdx
    d0c0:      	je	0x1738d <generic_kprobe_path+0xba6d>
    d0c6:      	movl	$0x4, %eax
    d0cb:      	leaq	0x10(%rsp), %rdi
    d0d0:      	movl	$0x8, %esi
    d0d5:      	callq	*%rax
    d0d7:      	cmpq	0x10(%rsp), %r12
    d0dc:      	je	0xd1d4 <generic_kprobe_path+0x18b4>
    d0e2:      	leaq	0x18(%r12), %rbx
    d0e7:      	movl	$0x4, %eax
    d0ec:      	movq	%rbp, %rdi
    d0ef:      	movl	$0x8, %esi
    d0f4:      	movq	%rbx, %rdx
    d0f7:      	callq	*%rax
    d0f9:      	cmpq	%r12, (%rsp)
    d0fd:      	je	0xd1d4 <generic_kprobe_path+0x18b4>
    d103:      	movl	$0x4, %eax
    d108:      	leaq	0x8(%rsp), %rdi
    d10d:      	movl	$0x8, %esi
    d112:      	movq	%rbx, %rdx
    d115:      	callq	*%rax
    d117:      	addq	$0x20, %r12
    d11b:      	movl	$0x4, %eax
    d120:      	leaq	0x58(%rsp), %rdi
    d125:      	movl	$0x10, %ecx
    d12a:      	movl	$0x10, %esi
    d12f:      	movq	%r12, %rdx
    d132:      	callq	*%rax
    d134:      	movq	0x28(%rsp), %rbx
    d139:      	movq	0x48(%rsp), %rax
    d13e:      	movl	0x5c(%rsp), %r15d
    d143:      	subq	%rbx, %rax
    d146:      	movl	0x50(%rsp), %r12d
    d14b:      	movl	%r15d, %edx
    d14e:      	subl	%r12d, %edx
    d151:      	movl	$0x0, %ecx
    d156:      	cmovbl	%ecx, %edx
    d159:      	addq	0x60(%rsp), %rdx
    d15e:      	xorl	%esi, %esi
    d160:      	cmpl	%r15d, %r12d
    d163:      	seta	%sil
    d167:      	movl	%r15d, %ecx
    d16a:      	cmovbl	%r12d, %ecx
    d16e:      	addl	%ecx, %esi
    d170:      	movl	%r12d, %edi
    d173:      	subl	%esi, %edi
    d175:      	movl	%edi, 0x50(%rsp)
    d179:      	subq	%rsi, %rax
    d17c:      	jb	0x17392 <generic_kprobe_path+0xba72>
    d182:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d188:      	ja	0x17392 <generic_kprobe_path+0xba72>
    d18e:      	cmpl	%r15d, %r12d
    d191:      	jbe	0xd197 <generic_kprobe_path+0x1877>
    d193:      	movb	$0x2f, (%rbx,%rax)
    d197:      	xorl	%edi, %edi
    d199:      	cmpl	%r15d, %r12d
    d19c:      	seta	%dil
    d1a0:      	movzbl	%cl, %esi
    d1a3:      	addq	%rax, %rbx
    d1a6:      	addq	%rbx, %rdi
    d1a9:      	movl	$0x4, %eax
    d1ae:      	callq	*%rax
    d1b0:      	movq	%rbx, 0x48(%rsp)
    d1b5:      	cmpl	%r15d, %r12d
    d1b8:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    d1be:      	movq	0x8(%rsp), %r12
    d1c3:      	movq	%r12, 0x30(%rsp)
    d1c8:      	movq	0x38(%rsp), %rdx
    d1cd:      	movq	0x40(%rsp), %r15
    d1d2:      	jmp	0xd225 <generic_kprobe_path+0x1905>
    d1d4:      	leaq	0x10(%r15), %rdx
    d1d8:      	movl	$0x4, %eax
    d1dd:      	movq	%rbp, %rdi
    d1e0:      	movl	$0x8, %esi
    d1e5:      	callq	*%rax
    d1e7:      	movq	0x40(%rsp), %rax
    d1ec:      	cmpq	(%rsp), %rax
    d1f0:      	je	0x1738d <generic_kprobe_path+0xba6d>
    d1f6:      	addq	$0x18, %r15
    d1fa:      	movl	$0x4, %eax
    d1ff:      	leaq	0x30(%rsp), %rdi
    d204:      	movl	$0x8, %esi
    d209:      	movq	%r15, %rdx
    d20c:      	callq	*%rax
    d20e:      	movq	(%rsp), %r15
    d212:      	movq	%r15, 0x40(%rsp)
    d217:      	leaq	0x20(%r15), %rdx
    d21b:      	movq	%rdx, 0x38(%rsp)
    d220:      	movq	0x30(%rsp), %r12
    d225:      	cmpq	0x18(%rsp), %r12
    d22a:      	jne	0xd237 <generic_kprobe_path+0x1917>
    d22c:      	cmpq	0x20(%rsp), %rdx
    d231:      	je	0x1738d <generic_kprobe_path+0xba6d>
    d237:      	movl	$0x4, %eax
    d23c:      	leaq	0x10(%rsp), %rdi
    d241:      	movl	$0x8, %esi
    d246:      	callq	*%rax
    d248:      	cmpq	0x10(%rsp), %r12
    d24d:      	je	0xd345 <generic_kprobe_path+0x1a25>
    d253:      	leaq	0x18(%r12), %rbx
    d258:      	movl	$0x4, %eax
    d25d:      	movq	%rbp, %rdi
    d260:      	movl	$0x8, %esi
    d265:      	movq	%rbx, %rdx
    d268:      	callq	*%rax
    d26a:      	cmpq	%r12, (%rsp)
    d26e:      	je	0xd345 <generic_kprobe_path+0x1a25>
    d274:      	movl	$0x4, %eax
    d279:      	leaq	0x8(%rsp), %rdi
    d27e:      	movl	$0x8, %esi
    d283:      	movq	%rbx, %rdx
    d286:      	callq	*%rax
    d288:      	addq	$0x20, %r12
    d28c:      	movl	$0x4, %eax
    d291:      	leaq	0x58(%rsp), %rdi
    d296:      	movl	$0x10, %ecx
    d29b:      	movl	$0x10, %esi
    d2a0:      	movq	%r12, %rdx
    d2a3:      	callq	*%rax
    d2a5:      	movq	0x28(%rsp), %rbx
    d2aa:      	movq	0x48(%rsp), %rax
    d2af:      	movl	0x5c(%rsp), %r15d
    d2b4:      	subq	%rbx, %rax
    d2b7:      	movl	0x50(%rsp), %r12d
    d2bc:      	movl	%r15d, %edx
    d2bf:      	subl	%r12d, %edx
    d2c2:      	movl	$0x0, %ecx
    d2c7:      	cmovbl	%ecx, %edx
    d2ca:      	addq	0x60(%rsp), %rdx
    d2cf:      	xorl	%esi, %esi
    d2d1:      	cmpl	%r15d, %r12d
    d2d4:      	seta	%sil
    d2d8:      	movl	%r15d, %ecx
    d2db:      	cmovbl	%r12d, %ecx
    d2df:      	addl	%ecx, %esi
    d2e1:      	movl	%r12d, %edi
    d2e4:      	subl	%esi, %edi
    d2e6:      	movl	%edi, 0x50(%rsp)
    d2ea:      	subq	%rsi, %rax
    d2ed:      	jb	0x17392 <generic_kprobe_path+0xba72>
    d2f3:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d2f9:      	ja	0x17392 <generic_kprobe_path+0xba72>
    d2ff:      	cmpl	%r15d, %r12d
    d302:      	jbe	0xd308 <generic_kprobe_path+0x19e8>
    d304:      	movb	$0x2f, (%rbx,%rax)
    d308:      	xorl	%edi, %edi
    d30a:      	cmpl	%r15d, %r12d
    d30d:      	seta	%dil
    d311:      	movzbl	%cl, %esi
    d314:      	addq	%rax, %rbx
    d317:      	addq	%rbx, %rdi
    d31a:      	movl	$0x4, %eax
    d31f:      	callq	*%rax
    d321:      	movq	%rbx, 0x48(%rsp)
    d326:      	cmpl	%r15d, %r12d
    d329:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    d32f:      	movq	0x8(%rsp), %r12
    d334:      	movq	%r12, 0x30(%rsp)
    d339:      	movq	0x38(%rsp), %rdx
    d33e:      	movq	0x40(%rsp), %r15
    d343:      	jmp	0xd396 <generic_kprobe_path+0x1a76>
    d345:      	leaq	0x10(%r15), %rdx
    d349:      	movl	$0x4, %eax
    d34e:      	movq	%rbp, %rdi
    d351:      	movl	$0x8, %esi
    d356:      	callq	*%rax
    d358:      	movq	0x40(%rsp), %rax
    d35d:      	cmpq	(%rsp), %rax
    d361:      	je	0x1738d <generic_kprobe_path+0xba6d>
    d367:      	addq	$0x18, %r15
    d36b:      	movl	$0x4, %eax
    d370:      	leaq	0x30(%rsp), %rdi
    d375:      	movl	$0x8, %esi
    d37a:      	movq	%r15, %rdx
    d37d:      	callq	*%rax
    d37f:      	movq	(%rsp), %r15
    d383:      	movq	%r15, 0x40(%rsp)
    d388:      	leaq	0x20(%r15), %rdx
    d38c:      	movq	%rdx, 0x38(%rsp)
    d391:      	movq	0x30(%rsp), %r12
    d396:      	cmpq	0x18(%rsp), %r12
    d39b:      	jne	0xd3a8 <generic_kprobe_path+0x1a88>
    d39d:      	cmpq	0x20(%rsp), %rdx
    d3a2:      	je	0x1738d <generic_kprobe_path+0xba6d>
    d3a8:      	movl	$0x4, %eax
    d3ad:      	leaq	0x10(%rsp), %rdi
    d3b2:      	movl	$0x8, %esi
    d3b7:      	callq	*%rax
    d3b9:      	cmpq	0x10(%rsp), %r12
    d3be:      	je	0xd4b6 <generic_kprobe_path+0x1b96>
    d3c4:      	leaq	0x18(%r12), %rbx
    d3c9:      	movl	$0x4, %eax
    d3ce:      	movq	%rbp, %rdi
    d3d1:      	movl	$0x8, %esi
    d3d6:      	movq	%rbx, %rdx
    d3d9:      	callq	*%rax
    d3db:      	cmpq	%r12, (%rsp)
    d3df:      	je	0xd4b6 <generic_kprobe_path+0x1b96>
    d3e5:      	movl	$0x4, %eax
    d3ea:      	leaq	0x8(%rsp), %rdi
    d3ef:      	movl	$0x8, %esi
    d3f4:      	movq	%rbx, %rdx
    d3f7:      	callq	*%rax
    d3f9:      	addq	$0x20, %r12
    d3fd:      	movl	$0x4, %eax
    d402:      	leaq	0x58(%rsp), %rdi
    d407:      	movl	$0x10, %ecx
    d40c:      	movl	$0x10, %esi
    d411:      	movq	%r12, %rdx
    d414:      	callq	*%rax
    d416:      	movq	0x28(%rsp), %rbx
    d41b:      	movq	0x48(%rsp), %rax
    d420:      	movl	0x5c(%rsp), %r15d
    d425:      	subq	%rbx, %rax
    d428:      	movl	0x50(%rsp), %r12d
    d42d:      	movl	%r15d, %edx
    d430:      	subl	%r12d, %edx
    d433:      	movl	$0x0, %ecx
    d438:      	cmovbl	%ecx, %edx
    d43b:      	addq	0x60(%rsp), %rdx
    d440:      	xorl	%esi, %esi
    d442:      	cmpl	%r15d, %r12d
    d445:      	seta	%sil
    d449:      	movl	%r15d, %ecx
    d44c:      	cmovbl	%r12d, %ecx
    d450:      	addl	%ecx, %esi
    d452:      	movl	%r12d, %edi
    d455:      	subl	%esi, %edi
    d457:      	movl	%edi, 0x50(%rsp)
    d45b:      	subq	%rsi, %rax
    d45e:      	jb	0x17392 <generic_kprobe_path+0xba72>
    d464:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d46a:      	ja	0x17392 <generic_kprobe_path+0xba72>
    d470:      	cmpl	%r15d, %r12d
    d473:      	jbe	0xd479 <generic_kprobe_path+0x1b59>
    d475:      	movb	$0x2f, (%rbx,%rax)
    d479:      	xorl	%edi, %edi
    d47b:      	cmpl	%r15d, %r12d
    d47e:      	seta	%dil
    d482:      	movzbl	%cl, %esi
    d485:      	addq	%rax, %rbx
    d488:      	addq	%rbx, %rdi
    d48b:      	movl	$0x4, %eax
    d490:      	callq	*%rax
    d492:      	movq	%rbx, 0x48(%rsp)
    d497:      	cmpl	%r15d, %r12d
    d49a:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    d4a0:      	movq	0x8(%rsp), %r12
    d4a5:      	movq	%r12, 0x30(%rsp)
    d4aa:      	movq	0x38(%rsp), %rdx
    d4af:      	movq	0x40(%rsp), %r15
    d4b4:      	jmp	0xd507 <generic_kprobe_path+0x1be7>
    d4b6:      	leaq	0x10(%r15), %rdx
    d4ba:      	movl	$0x4, %eax
    d4bf:      	movq	%rbp, %rdi
    d4c2:      	movl	$0x8, %esi
    d4c7:      	callq	*%rax
    d4c9:      	movq	0x40(%rsp), %rax
    d4ce:      	cmpq	(%rsp), %rax
    d4d2:      	je	0x1738d <generic_kprobe_path+0xba6d>
    d4d8:      	addq	$0x18, %r15
    d4dc:      	movl	$0x4, %eax
    d4e1:      	leaq	0x30(%rsp), %rdi
    d4e6:      	movl	$0x8, %esi
    d4eb:      	movq	%r15, %rdx
    d4ee:      	callq	*%rax
    d4f0:      	movq	(%rsp), %r15
    d4f4:      	movq	%r15, 0x40(%rsp)
    d4f9:      	leaq	0x20(%r15), %rdx
    d4fd:      	movq	%rdx, 0x38(%rsp)
    d502:      	movq	0x30(%rsp), %r12
    d507:      	cmpq	0x18(%rsp), %r12
    d50c:      	jne	0xd519 <generic_kprobe_path+0x1bf9>
    d50e:      	cmpq	0x20(%rsp), %rdx
    d513:      	je	0x1738d <generic_kprobe_path+0xba6d>
    d519:      	movl	$0x4, %eax
    d51e:      	leaq	0x10(%rsp), %rdi
    d523:      	movl	$0x8, %esi
    d528:      	callq	*%rax
    d52a:      	cmpq	0x10(%rsp), %r12
    d52f:      	je	0xd627 <generic_kprobe_path+0x1d07>
    d535:      	leaq	0x18(%r12), %rbx
    d53a:      	movl	$0x4, %eax
    d53f:      	movq	%rbp, %rdi
    d542:      	movl	$0x8, %esi
    d547:      	movq	%rbx, %rdx
    d54a:      	callq	*%rax
    d54c:      	cmpq	%r12, (%rsp)
    d550:      	je	0xd627 <generic_kprobe_path+0x1d07>
    d556:      	movl	$0x4, %eax
    d55b:      	leaq	0x8(%rsp), %rdi
    d560:      	movl	$0x8, %esi
    d565:      	movq	%rbx, %rdx
    d568:      	callq	*%rax
    d56a:      	addq	$0x20, %r12
    d56e:      	movl	$0x4, %eax
    d573:      	leaq	0x58(%rsp), %rdi
    d578:      	movl	$0x10, %ecx
    d57d:      	movl	$0x10, %esi
    d582:      	movq	%r12, %rdx
    d585:      	callq	*%rax
    d587:      	movq	0x28(%rsp), %rbx
    d58c:      	movq	0x48(%rsp), %rax
    d591:      	movl	0x5c(%rsp), %r15d
    d596:      	subq	%rbx, %rax
    d599:      	movl	0x50(%rsp), %r12d
    d59e:      	movl	%r15d, %edx
    d5a1:      	subl	%r12d, %edx
    d5a4:      	movl	$0x0, %ecx
    d5a9:      	cmovbl	%ecx, %edx
    d5ac:      	addq	0x60(%rsp), %rdx
    d5b1:      	xorl	%esi, %esi
    d5b3:      	cmpl	%r15d, %r12d
    d5b6:      	seta	%sil
    d5ba:      	movl	%r15d, %ecx
    d5bd:      	cmovbl	%r12d, %ecx
    d5c1:      	addl	%ecx, %esi
    d5c3:      	movl	%r12d, %edi
    d5c6:      	subl	%esi, %edi
    d5c8:      	movl	%edi, 0x50(%rsp)
    d5cc:      	subq	%rsi, %rax
    d5cf:      	jb	0x17392 <generic_kprobe_path+0xba72>
    d5d5:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d5db:      	ja	0x17392 <generic_kprobe_path+0xba72>
    d5e1:      	cmpl	%r15d, %r12d
    d5e4:      	jbe	0xd5ea <generic_kprobe_path+0x1cca>
    d5e6:      	movb	$0x2f, (%rbx,%rax)
    d5ea:      	xorl	%edi, %edi
    d5ec:      	cmpl	%r15d, %r12d
    d5ef:      	seta	%dil
    d5f3:      	movzbl	%cl, %esi
    d5f6:      	addq	%rax, %rbx
    d5f9:      	addq	%rbx, %rdi
    d5fc:      	movl	$0x4, %eax
    d601:      	callq	*%rax
    d603:      	movq	%rbx, 0x48(%rsp)
    d608:      	cmpl	%r15d, %r12d
    d60b:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    d611:      	movq	0x8(%rsp), %r12
    d616:      	movq	%r12, 0x30(%rsp)
    d61b:      	movq	0x38(%rsp), %rdx
    d620:      	movq	0x40(%rsp), %r15
    d625:      	jmp	0xd678 <generic_kprobe_path+0x1d58>
    d627:      	leaq	0x10(%r15), %rdx
    d62b:      	movl	$0x4, %eax
    d630:      	movq	%rbp, %rdi
    d633:      	movl	$0x8, %esi
    d638:      	callq	*%rax
    d63a:      	movq	0x40(%rsp), %rax
    d63f:      	cmpq	(%rsp), %rax
    d643:      	je	0x1738d <generic_kprobe_path+0xba6d>
    d649:      	addq	$0x18, %r15
    d64d:      	movl	$0x4, %eax
    d652:      	leaq	0x30(%rsp), %rdi
    d657:      	movl	$0x8, %esi
    d65c:      	movq	%r15, %rdx
    d65f:      	callq	*%rax
    d661:      	movq	(%rsp), %r15
    d665:      	movq	%r15, 0x40(%rsp)
    d66a:      	leaq	0x20(%r15), %rdx
    d66e:      	movq	%rdx, 0x38(%rsp)
    d673:      	movq	0x30(%rsp), %r12
    d678:      	cmpq	0x18(%rsp), %r12
    d67d:      	jne	0xd68a <generic_kprobe_path+0x1d6a>
    d67f:      	cmpq	0x20(%rsp), %rdx
    d684:      	je	0x1738d <generic_kprobe_path+0xba6d>
    d68a:      	movl	$0x4, %eax
    d68f:      	leaq	0x10(%rsp), %rdi
    d694:      	movl	$0x8, %esi
    d699:      	callq	*%rax
    d69b:      	cmpq	0x10(%rsp), %r12
    d6a0:      	je	0xd798 <generic_kprobe_path+0x1e78>
    d6a6:      	leaq	0x18(%r12), %rbx
    d6ab:      	movl	$0x4, %eax
    d6b0:      	movq	%rbp, %rdi
    d6b3:      	movl	$0x8, %esi
    d6b8:      	movq	%rbx, %rdx
    d6bb:      	callq	*%rax
    d6bd:      	cmpq	%r12, (%rsp)
    d6c1:      	je	0xd798 <generic_kprobe_path+0x1e78>
    d6c7:      	movl	$0x4, %eax
    d6cc:      	leaq	0x8(%rsp), %rdi
    d6d1:      	movl	$0x8, %esi
    d6d6:      	movq	%rbx, %rdx
    d6d9:      	callq	*%rax
    d6db:      	addq	$0x20, %r12
    d6df:      	movl	$0x4, %eax
    d6e4:      	leaq	0x58(%rsp), %rdi
    d6e9:      	movl	$0x10, %ecx
    d6ee:      	movl	$0x10, %esi
    d6f3:      	movq	%r12, %rdx
    d6f6:      	callq	*%rax
    d6f8:      	movq	0x28(%rsp), %rbx
    d6fd:      	movq	0x48(%rsp), %rax
    d702:      	movl	0x5c(%rsp), %r15d
    d707:      	subq	%rbx, %rax
    d70a:      	movl	0x50(%rsp), %r12d
    d70f:      	movl	%r15d, %edx
    d712:      	subl	%r12d, %edx
    d715:      	movl	$0x0, %ecx
    d71a:      	cmovbl	%ecx, %edx
    d71d:      	addq	0x60(%rsp), %rdx
    d722:      	xorl	%esi, %esi
    d724:      	cmpl	%r15d, %r12d
    d727:      	seta	%sil
    d72b:      	movl	%r15d, %ecx
    d72e:      	cmovbl	%r12d, %ecx
    d732:      	addl	%ecx, %esi
    d734:      	movl	%r12d, %edi
    d737:      	subl	%esi, %edi
    d739:      	movl	%edi, 0x50(%rsp)
    d73d:      	subq	%rsi, %rax
    d740:      	jb	0x17392 <generic_kprobe_path+0xba72>
    d746:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d74c:      	ja	0x17392 <generic_kprobe_path+0xba72>
    d752:      	cmpl	%r15d, %r12d
    d755:      	jbe	0xd75b <generic_kprobe_path+0x1e3b>
    d757:      	movb	$0x2f, (%rbx,%rax)
    d75b:      	xorl	%edi, %edi
    d75d:      	cmpl	%r15d, %r12d
    d760:      	seta	%dil
    d764:      	movzbl	%cl, %esi
    d767:      	addq	%rax, %rbx
    d76a:      	addq	%rbx, %rdi
    d76d:      	movl	$0x4, %eax
    d772:      	callq	*%rax
    d774:      	movq	%rbx, 0x48(%rsp)
    d779:      	cmpl	%r15d, %r12d
    d77c:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    d782:      	movq	0x8(%rsp), %r12
    d787:      	movq	%r12, 0x30(%rsp)
    d78c:      	movq	0x38(%rsp), %rdx
    d791:      	movq	0x40(%rsp), %r15
    d796:      	jmp	0xd7e9 <generic_kprobe_path+0x1ec9>
    d798:      	leaq	0x10(%r15), %rdx
    d79c:      	movl	$0x4, %eax
    d7a1:      	movq	%rbp, %rdi
    d7a4:      	movl	$0x8, %esi
    d7a9:      	callq	*%rax
    d7ab:      	movq	0x40(%rsp), %rax
    d7b0:      	cmpq	(%rsp), %rax
    d7b4:      	je	0x1738d <generic_kprobe_path+0xba6d>
    d7ba:      	addq	$0x18, %r15
    d7be:      	movl	$0x4, %eax
    d7c3:      	leaq	0x30(%rsp), %rdi
    d7c8:      	movl	$0x8, %esi
    d7cd:      	movq	%r15, %rdx
    d7d0:      	callq	*%rax
    d7d2:      	movq	(%rsp), %r15
    d7d6:      	movq	%r15, 0x40(%rsp)
    d7db:      	leaq	0x20(%r15), %rdx
    d7df:      	movq	%rdx, 0x38(%rsp)
    d7e4:      	movq	0x30(%rsp), %r12
    d7e9:      	cmpq	0x18(%rsp), %r12
    d7ee:      	jne	0xd7fb <generic_kprobe_path+0x1edb>
    d7f0:      	cmpq	0x20(%rsp), %rdx
    d7f5:      	je	0x1738d <generic_kprobe_path+0xba6d>
    d7fb:      	movl	$0x4, %eax
    d800:      	leaq	0x10(%rsp), %rdi
    d805:      	movl	$0x8, %esi
    d80a:      	callq	*%rax
    d80c:      	cmpq	0x10(%rsp), %r12
    d811:      	je	0xd909 <generic_kprobe_path+0x1fe9>
    d817:      	leaq	0x18(%r12), %rbx
    d81c:      	movl	$0x4, %eax
    d821:      	movq	%rbp, %rdi
    d824:      	movl	$0x8, %esi
    d829:      	movq	%rbx, %rdx
    d82c:      	callq	*%rax
    d82e:      	cmpq	%r12, (%rsp)
    d832:      	je	0xd909 <generic_kprobe_path+0x1fe9>
    d838:      	movl	$0x4, %eax
    d83d:      	leaq	0x8(%rsp), %rdi
    d842:      	movl	$0x8, %esi
    d847:      	movq	%rbx, %rdx
    d84a:      	callq	*%rax
    d84c:      	addq	$0x20, %r12
    d850:      	movl	$0x4, %eax
    d855:      	leaq	0x58(%rsp), %rdi
    d85a:      	movl	$0x10, %ecx
    d85f:      	movl	$0x10, %esi
    d864:      	movq	%r12, %rdx
    d867:      	callq	*%rax
    d869:      	movq	0x28(%rsp), %rbx
    d86e:      	movq	0x48(%rsp), %rax
    d873:      	movl	0x5c(%rsp), %r15d
    d878:      	subq	%rbx, %rax
    d87b:      	movl	0x50(%rsp), %r12d
    d880:      	movl	%r15d, %edx
    d883:      	subl	%r12d, %edx
    d886:      	movl	$0x0, %ecx
    d88b:      	cmovbl	%ecx, %edx
    d88e:      	addq	0x60(%rsp), %rdx
    d893:      	xorl	%esi, %esi
    d895:      	cmpl	%r15d, %r12d
    d898:      	seta	%sil
    d89c:      	movl	%r15d, %ecx
    d89f:      	cmovbl	%r12d, %ecx
    d8a3:      	addl	%ecx, %esi
    d8a5:      	movl	%r12d, %edi
    d8a8:      	subl	%esi, %edi
    d8aa:      	movl	%edi, 0x50(%rsp)
    d8ae:      	subq	%rsi, %rax
    d8b1:      	jb	0x17392 <generic_kprobe_path+0xba72>
    d8b7:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d8bd:      	ja	0x17392 <generic_kprobe_path+0xba72>
    d8c3:      	cmpl	%r15d, %r12d
    d8c6:      	jbe	0xd8cc <generic_kprobe_path+0x1fac>
    d8c8:      	movb	$0x2f, (%rbx,%rax)
    d8cc:      	xorl	%edi, %edi
    d8ce:      	cmpl	%r15d, %r12d
    d8d1:      	seta	%dil
    d8d5:      	movzbl	%cl, %esi
    d8d8:      	addq	%rax, %rbx
    d8db:      	addq	%rbx, %rdi
    d8de:      	movl	$0x4, %eax
    d8e3:      	callq	*%rax
    d8e5:      	movq	%rbx, 0x48(%rsp)
    d8ea:      	cmpl	%r15d, %r12d
    d8ed:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    d8f3:      	movq	0x8(%rsp), %r12
    d8f8:      	movq	%r12, 0x30(%rsp)
    d8fd:      	movq	0x38(%rsp), %rdx
    d902:      	movq	0x40(%rsp), %r15
    d907:      	jmp	0xd95a <generic_kprobe_path+0x203a>
    d909:      	leaq	0x10(%r15), %rdx
    d90d:      	movl	$0x4, %eax
    d912:      	movq	%rbp, %rdi
    d915:      	movl	$0x8, %esi
    d91a:      	callq	*%rax
    d91c:      	movq	0x40(%rsp), %rax
    d921:      	cmpq	(%rsp), %rax
    d925:      	je	0x1738d <generic_kprobe_path+0xba6d>
    d92b:      	addq	$0x18, %r15
    d92f:      	movl	$0x4, %eax
    d934:      	leaq	0x30(%rsp), %rdi
    d939:      	movl	$0x8, %esi
    d93e:      	movq	%r15, %rdx
    d941:      	callq	*%rax
    d943:      	movq	(%rsp), %r15
    d947:      	movq	%r15, 0x40(%rsp)
    d94c:      	leaq	0x20(%r15), %rdx
    d950:      	movq	%rdx, 0x38(%rsp)
    d955:      	movq	0x30(%rsp), %r12
    d95a:      	cmpq	0x18(%rsp), %r12
    d95f:      	jne	0xd96c <generic_kprobe_path+0x204c>
    d961:      	cmpq	0x20(%rsp), %rdx
    d966:      	je	0x1738d <generic_kprobe_path+0xba6d>
    d96c:      	movl	$0x4, %eax
    d971:      	leaq	0x10(%rsp), %rdi
    d976:      	movl	$0x8, %esi
    d97b:      	callq	*%rax
    d97d:      	cmpq	0x10(%rsp), %r12
    d982:      	je	0xda7a <generic_kprobe_path+0x215a>
    d988:      	leaq	0x18(%r12), %rbx
    d98d:      	movl	$0x4, %eax
    d992:      	movq	%rbp, %rdi
    d995:      	movl	$0x8, %esi
    d99a:      	movq	%rbx, %rdx
    d99d:      	callq	*%rax
    d99f:      	cmpq	%r12, (%rsp)
    d9a3:      	je	0xda7a <generic_kprobe_path+0x215a>
    d9a9:      	movl	$0x4, %eax
    d9ae:      	leaq	0x8(%rsp), %rdi
    d9b3:      	movl	$0x8, %esi
    d9b8:      	movq	%rbx, %rdx
    d9bb:      	callq	*%rax
    d9bd:      	addq	$0x20, %r12
    d9c1:      	movl	$0x4, %eax
    d9c6:      	leaq	0x58(%rsp), %rdi
    d9cb:      	movl	$0x10, %ecx
    d9d0:      	movl	$0x10, %esi
    d9d5:      	movq	%r12, %rdx
    d9d8:      	callq	*%rax
    d9da:      	movq	0x28(%rsp), %rbx
    d9df:      	movq	0x48(%rsp), %rax
    d9e4:      	movl	0x5c(%rsp), %r15d
    d9e9:      	subq	%rbx, %rax
    d9ec:      	movl	0x50(%rsp), %r12d
    d9f1:      	movl	%r15d, %edx
    d9f4:      	subl	%r12d, %edx
    d9f7:      	movl	$0x0, %ecx
    d9fc:      	cmovbl	%ecx, %edx
    d9ff:      	addq	0x60(%rsp), %rdx
    da04:      	xorl	%esi, %esi
    da06:      	cmpl	%r15d, %r12d
    da09:      	seta	%sil
    da0d:      	movl	%r15d, %ecx
    da10:      	cmovbl	%r12d, %ecx
    da14:      	addl	%ecx, %esi
    da16:      	movl	%r12d, %edi
    da19:      	subl	%esi, %edi
    da1b:      	movl	%edi, 0x50(%rsp)
    da1f:      	subq	%rsi, %rax
    da22:      	jb	0x17392 <generic_kprobe_path+0xba72>
    da28:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    da2e:      	ja	0x17392 <generic_kprobe_path+0xba72>
    da34:      	cmpl	%r15d, %r12d
    da37:      	jbe	0xda3d <generic_kprobe_path+0x211d>
    da39:      	movb	$0x2f, (%rbx,%rax)
    da3d:      	xorl	%edi, %edi
    da3f:      	cmpl	%r15d, %r12d
    da42:      	seta	%dil
    da46:      	movzbl	%cl, %esi
    da49:      	addq	%rax, %rbx
    da4c:      	addq	%rbx, %rdi
    da4f:      	movl	$0x4, %eax
    da54:      	callq	*%rax
    da56:      	movq	%rbx, 0x48(%rsp)
    da5b:      	cmpl	%r15d, %r12d
    da5e:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    da64:      	movq	0x8(%rsp), %r12
    da69:      	movq	%r12, 0x30(%rsp)
    da6e:      	movq	0x38(%rsp), %rdx
    da73:      	movq	0x40(%rsp), %r15
    da78:      	jmp	0xdacb <generic_kprobe_path+0x21ab>
    da7a:      	leaq	0x10(%r15), %rdx
    da7e:      	movl	$0x4, %eax
    da83:      	movq	%rbp, %rdi
    da86:      	movl	$0x8, %esi
    da8b:      	callq	*%rax
    da8d:      	movq	0x40(%rsp), %rax
    da92:      	cmpq	(%rsp), %rax
    da96:      	je	0x1738d <generic_kprobe_path+0xba6d>
    da9c:      	addq	$0x18, %r15
    daa0:      	movl	$0x4, %eax
    daa5:      	leaq	0x30(%rsp), %rdi
    daaa:      	movl	$0x8, %esi
    daaf:      	movq	%r15, %rdx
    dab2:      	callq	*%rax
    dab4:      	movq	(%rsp), %r15
    dab8:      	movq	%r15, 0x40(%rsp)
    dabd:      	leaq	0x20(%r15), %rdx
    dac1:      	movq	%rdx, 0x38(%rsp)
    dac6:      	movq	0x30(%rsp), %r12
    dacb:      	cmpq	0x18(%rsp), %r12
    dad0:      	jne	0xdadd <generic_kprobe_path+0x21bd>
    dad2:      	cmpq	0x20(%rsp), %rdx
    dad7:      	je	0x1738d <generic_kprobe_path+0xba6d>
    dadd:      	movl	$0x4, %eax
    dae2:      	leaq	0x10(%rsp), %rdi
    dae7:      	movl	$0x8, %esi
    daec:      	callq	*%rax
    daee:      	cmpq	0x10(%rsp), %r12
    daf3:      	je	0xdbeb <generic_kprobe_path+0x22cb>
    daf9:      	leaq	0x18(%r12), %rbx
    dafe:      	movl	$0x4, %eax
    db03:      	movq	%rbp, %rdi
    db06:      	movl	$0x8, %esi
    db0b:      	movq	%rbx, %rdx
    db0e:      	callq	*%rax
    db10:      	cmpq	%r12, (%rsp)
    db14:      	je	0xdbeb <generic_kprobe_path+0x22cb>
    db1a:      	movl	$0x4, %eax
    db1f:      	leaq	0x8(%rsp), %rdi
    db24:      	movl	$0x8, %esi
    db29:      	movq	%rbx, %rdx
    db2c:      	callq	*%rax
    db2e:      	addq	$0x20, %r12
    db32:      	movl	$0x4, %eax
    db37:      	leaq	0x58(%rsp), %rdi
    db3c:      	movl	$0x10, %ecx
    db41:      	movl	$0x10, %esi
    db46:      	movq	%r12, %rdx
    db49:      	callq	*%rax
    db4b:      	movq	0x28(%rsp), %rbx
    db50:      	movq	0x48(%rsp), %rax
    db55:      	movl	0x5c(%rsp), %r15d
    db5a:      	subq	%rbx, %rax
    db5d:      	movl	0x50(%rsp), %r12d
    db62:      	movl	%r15d, %edx
    db65:      	subl	%r12d, %edx
    db68:      	movl	$0x0, %ecx
    db6d:      	cmovbl	%ecx, %edx
    db70:      	addq	0x60(%rsp), %rdx
    db75:      	xorl	%esi, %esi
    db77:      	cmpl	%r15d, %r12d
    db7a:      	seta	%sil
    db7e:      	movl	%r15d, %ecx
    db81:      	cmovbl	%r12d, %ecx
    db85:      	addl	%ecx, %esi
    db87:      	movl	%r12d, %edi
    db8a:      	subl	%esi, %edi
    db8c:      	movl	%edi, 0x50(%rsp)
    db90:      	subq	%rsi, %rax
    db93:      	jb	0x17392 <generic_kprobe_path+0xba72>
    db99:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    db9f:      	ja	0x17392 <generic_kprobe_path+0xba72>
    dba5:      	cmpl	%r15d, %r12d
    dba8:      	jbe	0xdbae <generic_kprobe_path+0x228e>
    dbaa:      	movb	$0x2f, (%rbx,%rax)
    dbae:      	xorl	%edi, %edi
    dbb0:      	cmpl	%r15d, %r12d
    dbb3:      	seta	%dil
    dbb7:      	movzbl	%cl, %esi
    dbba:      	addq	%rax, %rbx
    dbbd:      	addq	%rbx, %rdi
    dbc0:      	movl	$0x4, %eax
    dbc5:      	callq	*%rax
    dbc7:      	movq	%rbx, 0x48(%rsp)
    dbcc:      	cmpl	%r15d, %r12d
    dbcf:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    dbd5:      	movq	0x8(%rsp), %r12
    dbda:      	movq	%r12, 0x30(%rsp)
    dbdf:      	movq	0x38(%rsp), %rdx
    dbe4:      	movq	0x40(%rsp), %r15
    dbe9:      	jmp	0xdc3c <generic_kprobe_path+0x231c>
    dbeb:      	leaq	0x10(%r15), %rdx
    dbef:      	movl	$0x4, %eax
    dbf4:      	movq	%rbp, %rdi
    dbf7:      	movl	$0x8, %esi
    dbfc:      	callq	*%rax
    dbfe:      	movq	0x40(%rsp), %rax
    dc03:      	cmpq	(%rsp), %rax
    dc07:      	je	0x1738d <generic_kprobe_path+0xba6d>
    dc0d:      	addq	$0x18, %r15
    dc11:      	movl	$0x4, %eax
    dc16:      	leaq	0x30(%rsp), %rdi
    dc1b:      	movl	$0x8, %esi
    dc20:      	movq	%r15, %rdx
    dc23:      	callq	*%rax
    dc25:      	movq	(%rsp), %r15
    dc29:      	movq	%r15, 0x40(%rsp)
    dc2e:      	leaq	0x20(%r15), %rdx
    dc32:      	movq	%rdx, 0x38(%rsp)
    dc37:      	movq	0x30(%rsp), %r12
    dc3c:      	cmpq	0x18(%rsp), %r12
    dc41:      	jne	0xdc4e <generic_kprobe_path+0x232e>
    dc43:      	cmpq	0x20(%rsp), %rdx
    dc48:      	je	0x1738d <generic_kprobe_path+0xba6d>
    dc4e:      	movl	$0x4, %eax
    dc53:      	leaq	0x10(%rsp), %rdi
    dc58:      	movl	$0x8, %esi
    dc5d:      	callq	*%rax
    dc5f:      	cmpq	0x10(%rsp), %r12
    dc64:      	je	0xdd5c <generic_kprobe_path+0x243c>
    dc6a:      	leaq	0x18(%r12), %rbx
    dc6f:      	movl	$0x4, %eax
    dc74:      	movq	%rbp, %rdi
    dc77:      	movl	$0x8, %esi
    dc7c:      	movq	%rbx, %rdx
    dc7f:      	callq	*%rax
    dc81:      	cmpq	%r12, (%rsp)
    dc85:      	je	0xdd5c <generic_kprobe_path+0x243c>
    dc8b:      	movl	$0x4, %eax
    dc90:      	leaq	0x8(%rsp), %rdi
    dc95:      	movl	$0x8, %esi
    dc9a:      	movq	%rbx, %rdx
    dc9d:      	callq	*%rax
    dc9f:      	addq	$0x20, %r12
    dca3:      	movl	$0x4, %eax
    dca8:      	leaq	0x58(%rsp), %rdi
    dcad:      	movl	$0x10, %ecx
    dcb2:      	movl	$0x10, %esi
    dcb7:      	movq	%r12, %rdx
    dcba:      	callq	*%rax
    dcbc:      	movq	0x28(%rsp), %rbx
    dcc1:      	movq	0x48(%rsp), %rax
    dcc6:      	movl	0x5c(%rsp), %r15d
    dccb:      	subq	%rbx, %rax
    dcce:      	movl	0x50(%rsp), %r12d
    dcd3:      	movl	%r15d, %edx
    dcd6:      	subl	%r12d, %edx
    dcd9:      	movl	$0x0, %ecx
    dcde:      	cmovbl	%ecx, %edx
    dce1:      	addq	0x60(%rsp), %rdx
    dce6:      	xorl	%esi, %esi
    dce8:      	cmpl	%r15d, %r12d
    dceb:      	seta	%sil
    dcef:      	movl	%r15d, %ecx
    dcf2:      	cmovbl	%r12d, %ecx
    dcf6:      	addl	%ecx, %esi
    dcf8:      	movl	%r12d, %edi
    dcfb:      	subl	%esi, %edi
    dcfd:      	movl	%edi, 0x50(%rsp)
    dd01:      	subq	%rsi, %rax
    dd04:      	jb	0x17392 <generic_kprobe_path+0xba72>
    dd0a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    dd10:      	ja	0x17392 <generic_kprobe_path+0xba72>
    dd16:      	cmpl	%r15d, %r12d
    dd19:      	jbe	0xdd1f <generic_kprobe_path+0x23ff>
    dd1b:      	movb	$0x2f, (%rbx,%rax)
    dd1f:      	xorl	%edi, %edi
    dd21:      	cmpl	%r15d, %r12d
    dd24:      	seta	%dil
    dd28:      	movzbl	%cl, %esi
    dd2b:      	addq	%rax, %rbx
    dd2e:      	addq	%rbx, %rdi
    dd31:      	movl	$0x4, %eax
    dd36:      	callq	*%rax
    dd38:      	movq	%rbx, 0x48(%rsp)
    dd3d:      	cmpl	%r15d, %r12d
    dd40:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    dd46:      	movq	0x8(%rsp), %r12
    dd4b:      	movq	%r12, 0x30(%rsp)
    dd50:      	movq	0x38(%rsp), %rdx
    dd55:      	movq	0x40(%rsp), %r15
    dd5a:      	jmp	0xddad <generic_kprobe_path+0x248d>
    dd5c:      	leaq	0x10(%r15), %rdx
    dd60:      	movl	$0x4, %eax
    dd65:      	movq	%rbp, %rdi
    dd68:      	movl	$0x8, %esi
    dd6d:      	callq	*%rax
    dd6f:      	movq	0x40(%rsp), %rax
    dd74:      	cmpq	(%rsp), %rax
    dd78:      	je	0x1738d <generic_kprobe_path+0xba6d>
    dd7e:      	addq	$0x18, %r15
    dd82:      	movl	$0x4, %eax
    dd87:      	leaq	0x30(%rsp), %rdi
    dd8c:      	movl	$0x8, %esi
    dd91:      	movq	%r15, %rdx
    dd94:      	callq	*%rax
    dd96:      	movq	(%rsp), %r15
    dd9a:      	movq	%r15, 0x40(%rsp)
    dd9f:      	leaq	0x20(%r15), %rdx
    dda3:      	movq	%rdx, 0x38(%rsp)
    dda8:      	movq	0x30(%rsp), %r12
    ddad:      	cmpq	0x18(%rsp), %r12
    ddb2:      	jne	0xddbf <generic_kprobe_path+0x249f>
    ddb4:      	cmpq	0x20(%rsp), %rdx
    ddb9:      	je	0x1738d <generic_kprobe_path+0xba6d>
    ddbf:      	movl	$0x4, %eax
    ddc4:      	leaq	0x10(%rsp), %rdi
    ddc9:      	movl	$0x8, %esi
    ddce:      	callq	*%rax
    ddd0:      	cmpq	0x10(%rsp), %r12
    ddd5:      	je	0xdecd <generic_kprobe_path+0x25ad>
    dddb:      	leaq	0x18(%r12), %rbx
    dde0:      	movl	$0x4, %eax
    dde5:      	movq	%rbp, %rdi
    dde8:      	movl	$0x8, %esi
    dded:      	movq	%rbx, %rdx
    ddf0:      	callq	*%rax
    ddf2:      	cmpq	%r12, (%rsp)
    ddf6:      	je	0xdecd <generic_kprobe_path+0x25ad>
    ddfc:      	movl	$0x4, %eax
    de01:      	leaq	0x8(%rsp), %rdi
    de06:      	movl	$0x8, %esi
    de0b:      	movq	%rbx, %rdx
    de0e:      	callq	*%rax
    de10:      	addq	$0x20, %r12
    de14:      	movl	$0x4, %eax
    de19:      	leaq	0x58(%rsp), %rdi
    de1e:      	movl	$0x10, %ecx
    de23:      	movl	$0x10, %esi
    de28:      	movq	%r12, %rdx
    de2b:      	callq	*%rax
    de2d:      	movq	0x28(%rsp), %rbx
    de32:      	movq	0x48(%rsp), %rax
    de37:      	movl	0x5c(%rsp), %r15d
    de3c:      	subq	%rbx, %rax
    de3f:      	movl	0x50(%rsp), %r12d
    de44:      	movl	%r15d, %edx
    de47:      	subl	%r12d, %edx
    de4a:      	movl	$0x0, %ecx
    de4f:      	cmovbl	%ecx, %edx
    de52:      	addq	0x60(%rsp), %rdx
    de57:      	xorl	%esi, %esi
    de59:      	cmpl	%r15d, %r12d
    de5c:      	seta	%sil
    de60:      	movl	%r15d, %ecx
    de63:      	cmovbl	%r12d, %ecx
    de67:      	addl	%ecx, %esi
    de69:      	movl	%r12d, %edi
    de6c:      	subl	%esi, %edi
    de6e:      	movl	%edi, 0x50(%rsp)
    de72:      	subq	%rsi, %rax
    de75:      	jb	0x17392 <generic_kprobe_path+0xba72>
    de7b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    de81:      	ja	0x17392 <generic_kprobe_path+0xba72>
    de87:      	cmpl	%r15d, %r12d
    de8a:      	jbe	0xde90 <generic_kprobe_path+0x2570>
    de8c:      	movb	$0x2f, (%rbx,%rax)
    de90:      	xorl	%edi, %edi
    de92:      	cmpl	%r15d, %r12d
    de95:      	seta	%dil
    de99:      	movzbl	%cl, %esi
    de9c:      	addq	%rax, %rbx
    de9f:      	addq	%rbx, %rdi
    dea2:      	movl	$0x4, %eax
    dea7:      	callq	*%rax
    dea9:      	movq	%rbx, 0x48(%rsp)
    deae:      	cmpl	%r15d, %r12d
    deb1:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    deb7:      	movq	0x8(%rsp), %r12
    debc:      	movq	%r12, 0x30(%rsp)
    dec1:      	movq	0x38(%rsp), %rdx
    dec6:      	movq	0x40(%rsp), %r15
    decb:      	jmp	0xdf1e <generic_kprobe_path+0x25fe>
    decd:      	leaq	0x10(%r15), %rdx
    ded1:      	movl	$0x4, %eax
    ded6:      	movq	%rbp, %rdi
    ded9:      	movl	$0x8, %esi
    dede:      	callq	*%rax
    dee0:      	movq	0x40(%rsp), %rax
    dee5:      	cmpq	(%rsp), %rax
    dee9:      	je	0x1738d <generic_kprobe_path+0xba6d>
    deef:      	addq	$0x18, %r15
    def3:      	movl	$0x4, %eax
    def8:      	leaq	0x30(%rsp), %rdi
    defd:      	movl	$0x8, %esi
    df02:      	movq	%r15, %rdx
    df05:      	callq	*%rax
    df07:      	movq	(%rsp), %r15
    df0b:      	movq	%r15, 0x40(%rsp)
    df10:      	leaq	0x20(%r15), %rdx
    df14:      	movq	%rdx, 0x38(%rsp)
    df19:      	movq	0x30(%rsp), %r12
    df1e:      	cmpq	0x18(%rsp), %r12
    df23:      	jne	0xdf30 <generic_kprobe_path+0x2610>
    df25:      	cmpq	0x20(%rsp), %rdx
    df2a:      	je	0x1738d <generic_kprobe_path+0xba6d>
    df30:      	movl	$0x4, %eax
    df35:      	leaq	0x10(%rsp), %rdi
    df3a:      	movl	$0x8, %esi
    df3f:      	callq	*%rax
    df41:      	cmpq	0x10(%rsp), %r12
    df46:      	je	0xe03e <generic_kprobe_path+0x271e>
    df4c:      	leaq	0x18(%r12), %rbx
    df51:      	movl	$0x4, %eax
    df56:      	movq	%rbp, %rdi
    df59:      	movl	$0x8, %esi
    df5e:      	movq	%rbx, %rdx
    df61:      	callq	*%rax
    df63:      	cmpq	%r12, (%rsp)
    df67:      	je	0xe03e <generic_kprobe_path+0x271e>
    df6d:      	movl	$0x4, %eax
    df72:      	leaq	0x8(%rsp), %rdi
    df77:      	movl	$0x8, %esi
    df7c:      	movq	%rbx, %rdx
    df7f:      	callq	*%rax
    df81:      	addq	$0x20, %r12
    df85:      	movl	$0x4, %eax
    df8a:      	leaq	0x58(%rsp), %rdi
    df8f:      	movl	$0x10, %ecx
    df94:      	movl	$0x10, %esi
    df99:      	movq	%r12, %rdx
    df9c:      	callq	*%rax
    df9e:      	movq	0x28(%rsp), %rbx
    dfa3:      	movq	0x48(%rsp), %rax
    dfa8:      	movl	0x5c(%rsp), %r15d
    dfad:      	subq	%rbx, %rax
    dfb0:      	movl	0x50(%rsp), %r12d
    dfb5:      	movl	%r15d, %edx
    dfb8:      	subl	%r12d, %edx
    dfbb:      	movl	$0x0, %ecx
    dfc0:      	cmovbl	%ecx, %edx
    dfc3:      	addq	0x60(%rsp), %rdx
    dfc8:      	xorl	%esi, %esi
    dfca:      	cmpl	%r15d, %r12d
    dfcd:      	seta	%sil
    dfd1:      	movl	%r15d, %ecx
    dfd4:      	cmovbl	%r12d, %ecx
    dfd8:      	addl	%ecx, %esi
    dfda:      	movl	%r12d, %edi
    dfdd:      	subl	%esi, %edi
    dfdf:      	movl	%edi, 0x50(%rsp)
    dfe3:      	subq	%rsi, %rax
    dfe6:      	jb	0x17392 <generic_kprobe_path+0xba72>
    dfec:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    dff2:      	ja	0x17392 <generic_kprobe_path+0xba72>
    dff8:      	cmpl	%r15d, %r12d
    dffb:      	jbe	0xe001 <generic_kprobe_path+0x26e1>
    dffd:      	movb	$0x2f, (%rbx,%rax)
    e001:      	xorl	%edi, %edi
    e003:      	cmpl	%r15d, %r12d
    e006:      	seta	%dil
    e00a:      	movzbl	%cl, %esi
    e00d:      	addq	%rax, %rbx
    e010:      	addq	%rbx, %rdi
    e013:      	movl	$0x4, %eax
    e018:      	callq	*%rax
    e01a:      	movq	%rbx, 0x48(%rsp)
    e01f:      	cmpl	%r15d, %r12d
    e022:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    e028:      	movq	0x8(%rsp), %r12
    e02d:      	movq	%r12, 0x30(%rsp)
    e032:      	movq	0x38(%rsp), %rdx
    e037:      	movq	0x40(%rsp), %r15
    e03c:      	jmp	0xe08f <generic_kprobe_path+0x276f>
    e03e:      	leaq	0x10(%r15), %rdx
    e042:      	movl	$0x4, %eax
    e047:      	movq	%rbp, %rdi
    e04a:      	movl	$0x8, %esi
    e04f:      	callq	*%rax
    e051:      	movq	0x40(%rsp), %rax
    e056:      	cmpq	(%rsp), %rax
    e05a:      	je	0x1738d <generic_kprobe_path+0xba6d>
    e060:      	addq	$0x18, %r15
    e064:      	movl	$0x4, %eax
    e069:      	leaq	0x30(%rsp), %rdi
    e06e:      	movl	$0x8, %esi
    e073:      	movq	%r15, %rdx
    e076:      	callq	*%rax
    e078:      	movq	(%rsp), %r15
    e07c:      	movq	%r15, 0x40(%rsp)
    e081:      	leaq	0x20(%r15), %rdx
    e085:      	movq	%rdx, 0x38(%rsp)
    e08a:      	movq	0x30(%rsp), %r12
    e08f:      	cmpq	0x18(%rsp), %r12
    e094:      	jne	0xe0a1 <generic_kprobe_path+0x2781>
    e096:      	cmpq	0x20(%rsp), %rdx
    e09b:      	je	0x1738d <generic_kprobe_path+0xba6d>
    e0a1:      	movl	$0x4, %eax
    e0a6:      	leaq	0x10(%rsp), %rdi
    e0ab:      	movl	$0x8, %esi
    e0b0:      	callq	*%rax
    e0b2:      	cmpq	0x10(%rsp), %r12
    e0b7:      	je	0xe1af <generic_kprobe_path+0x288f>
    e0bd:      	leaq	0x18(%r12), %rbx
    e0c2:      	movl	$0x4, %eax
    e0c7:      	movq	%rbp, %rdi
    e0ca:      	movl	$0x8, %esi
    e0cf:      	movq	%rbx, %rdx
    e0d2:      	callq	*%rax
    e0d4:      	cmpq	%r12, (%rsp)
    e0d8:      	je	0xe1af <generic_kprobe_path+0x288f>
    e0de:      	movl	$0x4, %eax
    e0e3:      	leaq	0x8(%rsp), %rdi
    e0e8:      	movl	$0x8, %esi
    e0ed:      	movq	%rbx, %rdx
    e0f0:      	callq	*%rax
    e0f2:      	addq	$0x20, %r12
    e0f6:      	movl	$0x4, %eax
    e0fb:      	leaq	0x58(%rsp), %rdi
    e100:      	movl	$0x10, %ecx
    e105:      	movl	$0x10, %esi
    e10a:      	movq	%r12, %rdx
    e10d:      	callq	*%rax
    e10f:      	movq	0x28(%rsp), %rbx
    e114:      	movq	0x48(%rsp), %rax
    e119:      	movl	0x5c(%rsp), %r15d
    e11e:      	subq	%rbx, %rax
    e121:      	movl	0x50(%rsp), %r12d
    e126:      	movl	%r15d, %edx
    e129:      	subl	%r12d, %edx
    e12c:      	movl	$0x0, %ecx
    e131:      	cmovbl	%ecx, %edx
    e134:      	addq	0x60(%rsp), %rdx
    e139:      	xorl	%esi, %esi
    e13b:      	cmpl	%r15d, %r12d
    e13e:      	seta	%sil
    e142:      	movl	%r15d, %ecx
    e145:      	cmovbl	%r12d, %ecx
    e149:      	addl	%ecx, %esi
    e14b:      	movl	%r12d, %edi
    e14e:      	subl	%esi, %edi
    e150:      	movl	%edi, 0x50(%rsp)
    e154:      	subq	%rsi, %rax
    e157:      	jb	0x17392 <generic_kprobe_path+0xba72>
    e15d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e163:      	ja	0x17392 <generic_kprobe_path+0xba72>
    e169:      	cmpl	%r15d, %r12d
    e16c:      	jbe	0xe172 <generic_kprobe_path+0x2852>
    e16e:      	movb	$0x2f, (%rbx,%rax)
    e172:      	xorl	%edi, %edi
    e174:      	cmpl	%r15d, %r12d
    e177:      	seta	%dil
    e17b:      	movzbl	%cl, %esi
    e17e:      	addq	%rax, %rbx
    e181:      	addq	%rbx, %rdi
    e184:      	movl	$0x4, %eax
    e189:      	callq	*%rax
    e18b:      	movq	%rbx, 0x48(%rsp)
    e190:      	cmpl	%r15d, %r12d
    e193:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    e199:      	movq	0x8(%rsp), %r12
    e19e:      	movq	%r12, 0x30(%rsp)
    e1a3:      	movq	0x38(%rsp), %rdx
    e1a8:      	movq	0x40(%rsp), %r15
    e1ad:      	jmp	0xe200 <generic_kprobe_path+0x28e0>
    e1af:      	leaq	0x10(%r15), %rdx
    e1b3:      	movl	$0x4, %eax
    e1b8:      	movq	%rbp, %rdi
    e1bb:      	movl	$0x8, %esi
    e1c0:      	callq	*%rax
    e1c2:      	movq	0x40(%rsp), %rax
    e1c7:      	cmpq	(%rsp), %rax
    e1cb:      	je	0x1738d <generic_kprobe_path+0xba6d>
    e1d1:      	addq	$0x18, %r15
    e1d5:      	movl	$0x4, %eax
    e1da:      	leaq	0x30(%rsp), %rdi
    e1df:      	movl	$0x8, %esi
    e1e4:      	movq	%r15, %rdx
    e1e7:      	callq	*%rax
    e1e9:      	movq	(%rsp), %r15
    e1ed:      	movq	%r15, 0x40(%rsp)
    e1f2:      	leaq	0x20(%r15), %rdx
    e1f6:      	movq	%rdx, 0x38(%rsp)
    e1fb:      	movq	0x30(%rsp), %r12
    e200:      	cmpq	0x18(%rsp), %r12
    e205:      	jne	0xe212 <generic_kprobe_path+0x28f2>
    e207:      	cmpq	0x20(%rsp), %rdx
    e20c:      	je	0x1738d <generic_kprobe_path+0xba6d>
    e212:      	movl	$0x4, %eax
    e217:      	leaq	0x10(%rsp), %rdi
    e21c:      	movl	$0x8, %esi
    e221:      	callq	*%rax
    e223:      	cmpq	0x10(%rsp), %r12
    e228:      	je	0xe320 <generic_kprobe_path+0x2a00>
    e22e:      	leaq	0x18(%r12), %rbx
    e233:      	movl	$0x4, %eax
    e238:      	movq	%rbp, %rdi
    e23b:      	movl	$0x8, %esi
    e240:      	movq	%rbx, %rdx
    e243:      	callq	*%rax
    e245:      	cmpq	%r12, (%rsp)
    e249:      	je	0xe320 <generic_kprobe_path+0x2a00>
    e24f:      	movl	$0x4, %eax
    e254:      	leaq	0x8(%rsp), %rdi
    e259:      	movl	$0x8, %esi
    e25e:      	movq	%rbx, %rdx
    e261:      	callq	*%rax
    e263:      	addq	$0x20, %r12
    e267:      	movl	$0x4, %eax
    e26c:      	leaq	0x58(%rsp), %rdi
    e271:      	movl	$0x10, %ecx
    e276:      	movl	$0x10, %esi
    e27b:      	movq	%r12, %rdx
    e27e:      	callq	*%rax
    e280:      	movq	0x28(%rsp), %rbx
    e285:      	movq	0x48(%rsp), %rax
    e28a:      	movl	0x5c(%rsp), %r15d
    e28f:      	subq	%rbx, %rax
    e292:      	movl	0x50(%rsp), %r12d
    e297:      	movl	%r15d, %edx
    e29a:      	subl	%r12d, %edx
    e29d:      	movl	$0x0, %ecx
    e2a2:      	cmovbl	%ecx, %edx
    e2a5:      	addq	0x60(%rsp), %rdx
    e2aa:      	xorl	%esi, %esi
    e2ac:      	cmpl	%r15d, %r12d
    e2af:      	seta	%sil
    e2b3:      	movl	%r15d, %ecx
    e2b6:      	cmovbl	%r12d, %ecx
    e2ba:      	addl	%ecx, %esi
    e2bc:      	movl	%r12d, %edi
    e2bf:      	subl	%esi, %edi
    e2c1:      	movl	%edi, 0x50(%rsp)
    e2c5:      	subq	%rsi, %rax
    e2c8:      	jb	0x17392 <generic_kprobe_path+0xba72>
    e2ce:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e2d4:      	ja	0x17392 <generic_kprobe_path+0xba72>
    e2da:      	cmpl	%r15d, %r12d
    e2dd:      	jbe	0xe2e3 <generic_kprobe_path+0x29c3>
    e2df:      	movb	$0x2f, (%rbx,%rax)
    e2e3:      	xorl	%edi, %edi
    e2e5:      	cmpl	%r15d, %r12d
    e2e8:      	seta	%dil
    e2ec:      	movzbl	%cl, %esi
    e2ef:      	addq	%rax, %rbx
    e2f2:      	addq	%rbx, %rdi
    e2f5:      	movl	$0x4, %eax
    e2fa:      	callq	*%rax
    e2fc:      	movq	%rbx, 0x48(%rsp)
    e301:      	cmpl	%r15d, %r12d
    e304:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    e30a:      	movq	0x8(%rsp), %r12
    e30f:      	movq	%r12, 0x30(%rsp)
    e314:      	movq	0x38(%rsp), %rdx
    e319:      	movq	0x40(%rsp), %r15
    e31e:      	jmp	0xe371 <generic_kprobe_path+0x2a51>
    e320:      	leaq	0x10(%r15), %rdx
    e324:      	movl	$0x4, %eax
    e329:      	movq	%rbp, %rdi
    e32c:      	movl	$0x8, %esi
    e331:      	callq	*%rax
    e333:      	movq	0x40(%rsp), %rax
    e338:      	cmpq	(%rsp), %rax
    e33c:      	je	0x1738d <generic_kprobe_path+0xba6d>
    e342:      	addq	$0x18, %r15
    e346:      	movl	$0x4, %eax
    e34b:      	leaq	0x30(%rsp), %rdi
    e350:      	movl	$0x8, %esi
    e355:      	movq	%r15, %rdx
    e358:      	callq	*%rax
    e35a:      	movq	(%rsp), %r15
    e35e:      	movq	%r15, 0x40(%rsp)
    e363:      	leaq	0x20(%r15), %rdx
    e367:      	movq	%rdx, 0x38(%rsp)
    e36c:      	movq	0x30(%rsp), %r12
    e371:      	cmpq	0x18(%rsp), %r12
    e376:      	jne	0xe383 <generic_kprobe_path+0x2a63>
    e378:      	cmpq	0x20(%rsp), %rdx
    e37d:      	je	0x1738d <generic_kprobe_path+0xba6d>
    e383:      	movl	$0x4, %eax
    e388:      	leaq	0x10(%rsp), %rdi
    e38d:      	movl	$0x8, %esi
    e392:      	callq	*%rax
    e394:      	cmpq	0x10(%rsp), %r12
    e399:      	je	0xe491 <generic_kprobe_path+0x2b71>
    e39f:      	leaq	0x18(%r12), %rbx
    e3a4:      	movl	$0x4, %eax
    e3a9:      	movq	%rbp, %rdi
    e3ac:      	movl	$0x8, %esi
    e3b1:      	movq	%rbx, %rdx
    e3b4:      	callq	*%rax
    e3b6:      	cmpq	%r12, (%rsp)
    e3ba:      	je	0xe491 <generic_kprobe_path+0x2b71>
    e3c0:      	movl	$0x4, %eax
    e3c5:      	leaq	0x8(%rsp), %rdi
    e3ca:      	movl	$0x8, %esi
    e3cf:      	movq	%rbx, %rdx
    e3d2:      	callq	*%rax
    e3d4:      	addq	$0x20, %r12
    e3d8:      	movl	$0x4, %eax
    e3dd:      	leaq	0x58(%rsp), %rdi
    e3e2:      	movl	$0x10, %ecx
    e3e7:      	movl	$0x10, %esi
    e3ec:      	movq	%r12, %rdx
    e3ef:      	callq	*%rax
    e3f1:      	movq	0x28(%rsp), %rbx
    e3f6:      	movq	0x48(%rsp), %rax
    e3fb:      	movl	0x5c(%rsp), %r15d
    e400:      	subq	%rbx, %rax
    e403:      	movl	0x50(%rsp), %r12d
    e408:      	movl	%r15d, %edx
    e40b:      	subl	%r12d, %edx
    e40e:      	movl	$0x0, %ecx
    e413:      	cmovbl	%ecx, %edx
    e416:      	addq	0x60(%rsp), %rdx
    e41b:      	xorl	%esi, %esi
    e41d:      	cmpl	%r15d, %r12d
    e420:      	seta	%sil
    e424:      	movl	%r15d, %ecx
    e427:      	cmovbl	%r12d, %ecx
    e42b:      	addl	%ecx, %esi
    e42d:      	movl	%r12d, %edi
    e430:      	subl	%esi, %edi
    e432:      	movl	%edi, 0x50(%rsp)
    e436:      	subq	%rsi, %rax
    e439:      	jb	0x17392 <generic_kprobe_path+0xba72>
    e43f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e445:      	ja	0x17392 <generic_kprobe_path+0xba72>
    e44b:      	cmpl	%r15d, %r12d
    e44e:      	jbe	0xe454 <generic_kprobe_path+0x2b34>
    e450:      	movb	$0x2f, (%rbx,%rax)
    e454:      	xorl	%edi, %edi
    e456:      	cmpl	%r15d, %r12d
    e459:      	seta	%dil
    e45d:      	movzbl	%cl, %esi
    e460:      	addq	%rax, %rbx
    e463:      	addq	%rbx, %rdi
    e466:      	movl	$0x4, %eax
    e46b:      	callq	*%rax
    e46d:      	movq	%rbx, 0x48(%rsp)
    e472:      	cmpl	%r15d, %r12d
    e475:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    e47b:      	movq	0x8(%rsp), %r12
    e480:      	movq	%r12, 0x30(%rsp)
    e485:      	movq	0x38(%rsp), %rdx
    e48a:      	movq	0x40(%rsp), %r15
    e48f:      	jmp	0xe4e2 <generic_kprobe_path+0x2bc2>
    e491:      	leaq	0x10(%r15), %rdx
    e495:      	movl	$0x4, %eax
    e49a:      	movq	%rbp, %rdi
    e49d:      	movl	$0x8, %esi
    e4a2:      	callq	*%rax
    e4a4:      	movq	0x40(%rsp), %rax
    e4a9:      	cmpq	(%rsp), %rax
    e4ad:      	je	0x1738d <generic_kprobe_path+0xba6d>
    e4b3:      	addq	$0x18, %r15
    e4b7:      	movl	$0x4, %eax
    e4bc:      	leaq	0x30(%rsp), %rdi
    e4c1:      	movl	$0x8, %esi
    e4c6:      	movq	%r15, %rdx
    e4c9:      	callq	*%rax
    e4cb:      	movq	(%rsp), %r15
    e4cf:      	movq	%r15, 0x40(%rsp)
    e4d4:      	leaq	0x20(%r15), %rdx
    e4d8:      	movq	%rdx, 0x38(%rsp)
    e4dd:      	movq	0x30(%rsp), %r12
    e4e2:      	cmpq	0x18(%rsp), %r12
    e4e7:      	jne	0xe4f4 <generic_kprobe_path+0x2bd4>
    e4e9:      	cmpq	0x20(%rsp), %rdx
    e4ee:      	je	0x1738d <generic_kprobe_path+0xba6d>
    e4f4:      	movl	$0x4, %eax
    e4f9:      	leaq	0x10(%rsp), %rdi
    e4fe:      	movl	$0x8, %esi
    e503:      	callq	*%rax
    e505:      	cmpq	0x10(%rsp), %r12
    e50a:      	je	0xe602 <generic_kprobe_path+0x2ce2>
    e510:      	leaq	0x18(%r12), %rbx
    e515:      	movl	$0x4, %eax
    e51a:      	movq	%rbp, %rdi
    e51d:      	movl	$0x8, %esi
    e522:      	movq	%rbx, %rdx
    e525:      	callq	*%rax
    e527:      	cmpq	%r12, (%rsp)
    e52b:      	je	0xe602 <generic_kprobe_path+0x2ce2>
    e531:      	movl	$0x4, %eax
    e536:      	leaq	0x8(%rsp), %rdi
    e53b:      	movl	$0x8, %esi
    e540:      	movq	%rbx, %rdx
    e543:      	callq	*%rax
    e545:      	addq	$0x20, %r12
    e549:      	movl	$0x4, %eax
    e54e:      	leaq	0x58(%rsp), %rdi
    e553:      	movl	$0x10, %ecx
    e558:      	movl	$0x10, %esi
    e55d:      	movq	%r12, %rdx
    e560:      	callq	*%rax
    e562:      	movq	0x28(%rsp), %rbx
    e567:      	movq	0x48(%rsp), %rax
    e56c:      	movl	0x5c(%rsp), %r15d
    e571:      	subq	%rbx, %rax
    e574:      	movl	0x50(%rsp), %r12d
    e579:      	movl	%r15d, %edx
    e57c:      	subl	%r12d, %edx
    e57f:      	movl	$0x0, %ecx
    e584:      	cmovbl	%ecx, %edx
    e587:      	addq	0x60(%rsp), %rdx
    e58c:      	xorl	%esi, %esi
    e58e:      	cmpl	%r15d, %r12d
    e591:      	seta	%sil
    e595:      	movl	%r15d, %ecx
    e598:      	cmovbl	%r12d, %ecx
    e59c:      	addl	%ecx, %esi
    e59e:      	movl	%r12d, %edi
    e5a1:      	subl	%esi, %edi
    e5a3:      	movl	%edi, 0x50(%rsp)
    e5a7:      	subq	%rsi, %rax
    e5aa:      	jb	0x17392 <generic_kprobe_path+0xba72>
    e5b0:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e5b6:      	ja	0x17392 <generic_kprobe_path+0xba72>
    e5bc:      	cmpl	%r15d, %r12d
    e5bf:      	jbe	0xe5c5 <generic_kprobe_path+0x2ca5>
    e5c1:      	movb	$0x2f, (%rbx,%rax)
    e5c5:      	xorl	%edi, %edi
    e5c7:      	cmpl	%r15d, %r12d
    e5ca:      	seta	%dil
    e5ce:      	movzbl	%cl, %esi
    e5d1:      	addq	%rax, %rbx
    e5d4:      	addq	%rbx, %rdi
    e5d7:      	movl	$0x4, %eax
    e5dc:      	callq	*%rax
    e5de:      	movq	%rbx, 0x48(%rsp)
    e5e3:      	cmpl	%r15d, %r12d
    e5e6:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    e5ec:      	movq	0x8(%rsp), %r12
    e5f1:      	movq	%r12, 0x30(%rsp)
    e5f6:      	movq	0x38(%rsp), %rdx
    e5fb:      	movq	0x40(%rsp), %r15
    e600:      	jmp	0xe653 <generic_kprobe_path+0x2d33>
    e602:      	leaq	0x10(%r15), %rdx
    e606:      	movl	$0x4, %eax
    e60b:      	movq	%rbp, %rdi
    e60e:      	movl	$0x8, %esi
    e613:      	callq	*%rax
    e615:      	movq	0x40(%rsp), %rax
    e61a:      	cmpq	(%rsp), %rax
    e61e:      	je	0x1738d <generic_kprobe_path+0xba6d>
    e624:      	addq	$0x18, %r15
    e628:      	movl	$0x4, %eax
    e62d:      	leaq	0x30(%rsp), %rdi
    e632:      	movl	$0x8, %esi
    e637:      	movq	%r15, %rdx
    e63a:      	callq	*%rax
    e63c:      	movq	(%rsp), %r15
    e640:      	movq	%r15, 0x40(%rsp)
    e645:      	leaq	0x20(%r15), %rdx
    e649:      	movq	%rdx, 0x38(%rsp)
    e64e:      	movq	0x30(%rsp), %r12
    e653:      	cmpq	0x18(%rsp), %r12
    e658:      	jne	0xe665 <generic_kprobe_path+0x2d45>
    e65a:      	cmpq	0x20(%rsp), %rdx
    e65f:      	je	0x1738d <generic_kprobe_path+0xba6d>
    e665:      	movl	$0x4, %eax
    e66a:      	leaq	0x10(%rsp), %rdi
    e66f:      	movl	$0x8, %esi
    e674:      	callq	*%rax
    e676:      	cmpq	0x10(%rsp), %r12
    e67b:      	je	0xe773 <generic_kprobe_path+0x2e53>
    e681:      	leaq	0x18(%r12), %rbx
    e686:      	movl	$0x4, %eax
    e68b:      	movq	%rbp, %rdi
    e68e:      	movl	$0x8, %esi
    e693:      	movq	%rbx, %rdx
    e696:      	callq	*%rax
    e698:      	cmpq	%r12, (%rsp)
    e69c:      	je	0xe773 <generic_kprobe_path+0x2e53>
    e6a2:      	movl	$0x4, %eax
    e6a7:      	leaq	0x8(%rsp), %rdi
    e6ac:      	movl	$0x8, %esi
    e6b1:      	movq	%rbx, %rdx
    e6b4:      	callq	*%rax
    e6b6:      	addq	$0x20, %r12
    e6ba:      	movl	$0x4, %eax
    e6bf:      	leaq	0x58(%rsp), %rdi
    e6c4:      	movl	$0x10, %ecx
    e6c9:      	movl	$0x10, %esi
    e6ce:      	movq	%r12, %rdx
    e6d1:      	callq	*%rax
    e6d3:      	movq	0x28(%rsp), %rbx
    e6d8:      	movq	0x48(%rsp), %rax
    e6dd:      	movl	0x5c(%rsp), %r15d
    e6e2:      	subq	%rbx, %rax
    e6e5:      	movl	0x50(%rsp), %r12d
    e6ea:      	movl	%r15d, %edx
    e6ed:      	subl	%r12d, %edx
    e6f0:      	movl	$0x0, %ecx
    e6f5:      	cmovbl	%ecx, %edx
    e6f8:      	addq	0x60(%rsp), %rdx
    e6fd:      	xorl	%esi, %esi
    e6ff:      	cmpl	%r15d, %r12d
    e702:      	seta	%sil
    e706:      	movl	%r15d, %ecx
    e709:      	cmovbl	%r12d, %ecx
    e70d:      	addl	%ecx, %esi
    e70f:      	movl	%r12d, %edi
    e712:      	subl	%esi, %edi
    e714:      	movl	%edi, 0x50(%rsp)
    e718:      	subq	%rsi, %rax
    e71b:      	jb	0x17392 <generic_kprobe_path+0xba72>
    e721:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e727:      	ja	0x17392 <generic_kprobe_path+0xba72>
    e72d:      	cmpl	%r15d, %r12d
    e730:      	jbe	0xe736 <generic_kprobe_path+0x2e16>
    e732:      	movb	$0x2f, (%rbx,%rax)
    e736:      	xorl	%edi, %edi
    e738:      	cmpl	%r15d, %r12d
    e73b:      	seta	%dil
    e73f:      	movzbl	%cl, %esi
    e742:      	addq	%rax, %rbx
    e745:      	addq	%rbx, %rdi
    e748:      	movl	$0x4, %eax
    e74d:      	callq	*%rax
    e74f:      	movq	%rbx, 0x48(%rsp)
    e754:      	cmpl	%r15d, %r12d
    e757:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    e75d:      	movq	0x8(%rsp), %r12
    e762:      	movq	%r12, 0x30(%rsp)
    e767:      	movq	0x38(%rsp), %rdx
    e76c:      	movq	0x40(%rsp), %r15
    e771:      	jmp	0xe7c4 <generic_kprobe_path+0x2ea4>
    e773:      	leaq	0x10(%r15), %rdx
    e777:      	movl	$0x4, %eax
    e77c:      	movq	%rbp, %rdi
    e77f:      	movl	$0x8, %esi
    e784:      	callq	*%rax
    e786:      	movq	0x40(%rsp), %rax
    e78b:      	cmpq	(%rsp), %rax
    e78f:      	je	0x1738d <generic_kprobe_path+0xba6d>
    e795:      	addq	$0x18, %r15
    e799:      	movl	$0x4, %eax
    e79e:      	leaq	0x30(%rsp), %rdi
    e7a3:      	movl	$0x8, %esi
    e7a8:      	movq	%r15, %rdx
    e7ab:      	callq	*%rax
    e7ad:      	movq	(%rsp), %r15
    e7b1:      	movq	%r15, 0x40(%rsp)
    e7b6:      	leaq	0x20(%r15), %rdx
    e7ba:      	movq	%rdx, 0x38(%rsp)
    e7bf:      	movq	0x30(%rsp), %r12
    e7c4:      	cmpq	0x18(%rsp), %r12
    e7c9:      	jne	0xe7d6 <generic_kprobe_path+0x2eb6>
    e7cb:      	cmpq	0x20(%rsp), %rdx
    e7d0:      	je	0x1738d <generic_kprobe_path+0xba6d>
    e7d6:      	movl	$0x4, %eax
    e7db:      	leaq	0x10(%rsp), %rdi
    e7e0:      	movl	$0x8, %esi
    e7e5:      	callq	*%rax
    e7e7:      	cmpq	0x10(%rsp), %r12
    e7ec:      	je	0xe8e4 <generic_kprobe_path+0x2fc4>
    e7f2:      	leaq	0x18(%r12), %rbx
    e7f7:      	movl	$0x4, %eax
    e7fc:      	movq	%rbp, %rdi
    e7ff:      	movl	$0x8, %esi
    e804:      	movq	%rbx, %rdx
    e807:      	callq	*%rax
    e809:      	cmpq	%r12, (%rsp)
    e80d:      	je	0xe8e4 <generic_kprobe_path+0x2fc4>
    e813:      	movl	$0x4, %eax
    e818:      	leaq	0x8(%rsp), %rdi
    e81d:      	movl	$0x8, %esi
    e822:      	movq	%rbx, %rdx
    e825:      	callq	*%rax
    e827:      	addq	$0x20, %r12
    e82b:      	movl	$0x4, %eax
    e830:      	leaq	0x58(%rsp), %rdi
    e835:      	movl	$0x10, %ecx
    e83a:      	movl	$0x10, %esi
    e83f:      	movq	%r12, %rdx
    e842:      	callq	*%rax
    e844:      	movq	0x28(%rsp), %rbx
    e849:      	movq	0x48(%rsp), %rax
    e84e:      	movl	0x5c(%rsp), %r15d
    e853:      	subq	%rbx, %rax
    e856:      	movl	0x50(%rsp), %r12d
    e85b:      	movl	%r15d, %edx
    e85e:      	subl	%r12d, %edx
    e861:      	movl	$0x0, %ecx
    e866:      	cmovbl	%ecx, %edx
    e869:      	addq	0x60(%rsp), %rdx
    e86e:      	xorl	%esi, %esi
    e870:      	cmpl	%r15d, %r12d
    e873:      	seta	%sil
    e877:      	movl	%r15d, %ecx
    e87a:      	cmovbl	%r12d, %ecx
    e87e:      	addl	%ecx, %esi
    e880:      	movl	%r12d, %edi
    e883:      	subl	%esi, %edi
    e885:      	movl	%edi, 0x50(%rsp)
    e889:      	subq	%rsi, %rax
    e88c:      	jb	0x17392 <generic_kprobe_path+0xba72>
    e892:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e898:      	ja	0x17392 <generic_kprobe_path+0xba72>
    e89e:      	cmpl	%r15d, %r12d
    e8a1:      	jbe	0xe8a7 <generic_kprobe_path+0x2f87>
    e8a3:      	movb	$0x2f, (%rbx,%rax)
    e8a7:      	xorl	%edi, %edi
    e8a9:      	cmpl	%r15d, %r12d
    e8ac:      	seta	%dil
    e8b0:      	movzbl	%cl, %esi
    e8b3:      	addq	%rax, %rbx
    e8b6:      	addq	%rbx, %rdi
    e8b9:      	movl	$0x4, %eax
    e8be:      	callq	*%rax
    e8c0:      	movq	%rbx, 0x48(%rsp)
    e8c5:      	cmpl	%r15d, %r12d
    e8c8:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    e8ce:      	movq	0x8(%rsp), %r12
    e8d3:      	movq	%r12, 0x30(%rsp)
    e8d8:      	movq	0x38(%rsp), %rdx
    e8dd:      	movq	0x40(%rsp), %r15
    e8e2:      	jmp	0xe935 <generic_kprobe_path+0x3015>
    e8e4:      	leaq	0x10(%r15), %rdx
    e8e8:      	movl	$0x4, %eax
    e8ed:      	movq	%rbp, %rdi
    e8f0:      	movl	$0x8, %esi
    e8f5:      	callq	*%rax
    e8f7:      	movq	0x40(%rsp), %rax
    e8fc:      	cmpq	(%rsp), %rax
    e900:      	je	0x1738d <generic_kprobe_path+0xba6d>
    e906:      	addq	$0x18, %r15
    e90a:      	movl	$0x4, %eax
    e90f:      	leaq	0x30(%rsp), %rdi
    e914:      	movl	$0x8, %esi
    e919:      	movq	%r15, %rdx
    e91c:      	callq	*%rax
    e91e:      	movq	(%rsp), %r15
    e922:      	movq	%r15, 0x40(%rsp)
    e927:      	leaq	0x20(%r15), %rdx
    e92b:      	movq	%rdx, 0x38(%rsp)
    e930:      	movq	0x30(%rsp), %r12
    e935:      	cmpq	0x18(%rsp), %r12
    e93a:      	jne	0xe947 <generic_kprobe_path+0x3027>
    e93c:      	cmpq	0x20(%rsp), %rdx
    e941:      	je	0x1738d <generic_kprobe_path+0xba6d>
    e947:      	movl	$0x4, %eax
    e94c:      	leaq	0x10(%rsp), %rdi
    e951:      	movl	$0x8, %esi
    e956:      	callq	*%rax
    e958:      	cmpq	0x10(%rsp), %r12
    e95d:      	je	0xea55 <generic_kprobe_path+0x3135>
    e963:      	leaq	0x18(%r12), %rbx
    e968:      	movl	$0x4, %eax
    e96d:      	movq	%rbp, %rdi
    e970:      	movl	$0x8, %esi
    e975:      	movq	%rbx, %rdx
    e978:      	callq	*%rax
    e97a:      	cmpq	%r12, (%rsp)
    e97e:      	je	0xea55 <generic_kprobe_path+0x3135>
    e984:      	movl	$0x4, %eax
    e989:      	leaq	0x8(%rsp), %rdi
    e98e:      	movl	$0x8, %esi
    e993:      	movq	%rbx, %rdx
    e996:      	callq	*%rax
    e998:      	addq	$0x20, %r12
    e99c:      	movl	$0x4, %eax
    e9a1:      	leaq	0x58(%rsp), %rdi
    e9a6:      	movl	$0x10, %ecx
    e9ab:      	movl	$0x10, %esi
    e9b0:      	movq	%r12, %rdx
    e9b3:      	callq	*%rax
    e9b5:      	movq	0x28(%rsp), %rbx
    e9ba:      	movq	0x48(%rsp), %rax
    e9bf:      	movl	0x5c(%rsp), %r15d
    e9c4:      	subq	%rbx, %rax
    e9c7:      	movl	0x50(%rsp), %r12d
    e9cc:      	movl	%r15d, %edx
    e9cf:      	subl	%r12d, %edx
    e9d2:      	movl	$0x0, %ecx
    e9d7:      	cmovbl	%ecx, %edx
    e9da:      	addq	0x60(%rsp), %rdx
    e9df:      	xorl	%esi, %esi
    e9e1:      	cmpl	%r15d, %r12d
    e9e4:      	seta	%sil
    e9e8:      	movl	%r15d, %ecx
    e9eb:      	cmovbl	%r12d, %ecx
    e9ef:      	addl	%ecx, %esi
    e9f1:      	movl	%r12d, %edi
    e9f4:      	subl	%esi, %edi
    e9f6:      	movl	%edi, 0x50(%rsp)
    e9fa:      	subq	%rsi, %rax
    e9fd:      	jb	0x17392 <generic_kprobe_path+0xba72>
    ea03:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ea09:      	ja	0x17392 <generic_kprobe_path+0xba72>
    ea0f:      	cmpl	%r15d, %r12d
    ea12:      	jbe	0xea18 <generic_kprobe_path+0x30f8>
    ea14:      	movb	$0x2f, (%rbx,%rax)
    ea18:      	xorl	%edi, %edi
    ea1a:      	cmpl	%r15d, %r12d
    ea1d:      	seta	%dil
    ea21:      	movzbl	%cl, %esi
    ea24:      	addq	%rax, %rbx
    ea27:      	addq	%rbx, %rdi
    ea2a:      	movl	$0x4, %eax
    ea2f:      	callq	*%rax
    ea31:      	movq	%rbx, 0x48(%rsp)
    ea36:      	cmpl	%r15d, %r12d
    ea39:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    ea3f:      	movq	0x8(%rsp), %r12
    ea44:      	movq	%r12, 0x30(%rsp)
    ea49:      	movq	0x38(%rsp), %rdx
    ea4e:      	movq	0x40(%rsp), %r15
    ea53:      	jmp	0xeaa6 <generic_kprobe_path+0x3186>
    ea55:      	leaq	0x10(%r15), %rdx
    ea59:      	movl	$0x4, %eax
    ea5e:      	movq	%rbp, %rdi
    ea61:      	movl	$0x8, %esi
    ea66:      	callq	*%rax
    ea68:      	movq	0x40(%rsp), %rax
    ea6d:      	cmpq	(%rsp), %rax
    ea71:      	je	0x1738d <generic_kprobe_path+0xba6d>
    ea77:      	addq	$0x18, %r15
    ea7b:      	movl	$0x4, %eax
    ea80:      	leaq	0x30(%rsp), %rdi
    ea85:      	movl	$0x8, %esi
    ea8a:      	movq	%r15, %rdx
    ea8d:      	callq	*%rax
    ea8f:      	movq	(%rsp), %r15
    ea93:      	movq	%r15, 0x40(%rsp)
    ea98:      	leaq	0x20(%r15), %rdx
    ea9c:      	movq	%rdx, 0x38(%rsp)
    eaa1:      	movq	0x30(%rsp), %r12
    eaa6:      	cmpq	0x18(%rsp), %r12
    eaab:      	jne	0xeab8 <generic_kprobe_path+0x3198>
    eaad:      	cmpq	0x20(%rsp), %rdx
    eab2:      	je	0x1738d <generic_kprobe_path+0xba6d>
    eab8:      	movl	$0x4, %eax
    eabd:      	leaq	0x10(%rsp), %rdi
    eac2:      	movl	$0x8, %esi
    eac7:      	callq	*%rax
    eac9:      	cmpq	0x10(%rsp), %r12
    eace:      	je	0xebc6 <generic_kprobe_path+0x32a6>
    ead4:      	leaq	0x18(%r12), %rbx
    ead9:      	movl	$0x4, %eax
    eade:      	movq	%rbp, %rdi
    eae1:      	movl	$0x8, %esi
    eae6:      	movq	%rbx, %rdx
    eae9:      	callq	*%rax
    eaeb:      	cmpq	%r12, (%rsp)
    eaef:      	je	0xebc6 <generic_kprobe_path+0x32a6>
    eaf5:      	movl	$0x4, %eax
    eafa:      	leaq	0x8(%rsp), %rdi
    eaff:      	movl	$0x8, %esi
    eb04:      	movq	%rbx, %rdx
    eb07:      	callq	*%rax
    eb09:      	addq	$0x20, %r12
    eb0d:      	movl	$0x4, %eax
    eb12:      	leaq	0x58(%rsp), %rdi
    eb17:      	movl	$0x10, %ecx
    eb1c:      	movl	$0x10, %esi
    eb21:      	movq	%r12, %rdx
    eb24:      	callq	*%rax
    eb26:      	movq	0x28(%rsp), %rbx
    eb2b:      	movq	0x48(%rsp), %rax
    eb30:      	movl	0x5c(%rsp), %r15d
    eb35:      	subq	%rbx, %rax
    eb38:      	movl	0x50(%rsp), %r12d
    eb3d:      	movl	%r15d, %edx
    eb40:      	subl	%r12d, %edx
    eb43:      	movl	$0x0, %ecx
    eb48:      	cmovbl	%ecx, %edx
    eb4b:      	addq	0x60(%rsp), %rdx
    eb50:      	xorl	%esi, %esi
    eb52:      	cmpl	%r15d, %r12d
    eb55:      	seta	%sil
    eb59:      	movl	%r15d, %ecx
    eb5c:      	cmovbl	%r12d, %ecx
    eb60:      	addl	%ecx, %esi
    eb62:      	movl	%r12d, %edi
    eb65:      	subl	%esi, %edi
    eb67:      	movl	%edi, 0x50(%rsp)
    eb6b:      	subq	%rsi, %rax
    eb6e:      	jb	0x17392 <generic_kprobe_path+0xba72>
    eb74:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    eb7a:      	ja	0x17392 <generic_kprobe_path+0xba72>
    eb80:      	cmpl	%r15d, %r12d
    eb83:      	jbe	0xeb89 <generic_kprobe_path+0x3269>
    eb85:      	movb	$0x2f, (%rbx,%rax)
    eb89:      	xorl	%edi, %edi
    eb8b:      	cmpl	%r15d, %r12d
    eb8e:      	seta	%dil
    eb92:      	movzbl	%cl, %esi
    eb95:      	addq	%rax, %rbx
    eb98:      	addq	%rbx, %rdi
    eb9b:      	movl	$0x4, %eax
    eba0:      	callq	*%rax
    eba2:      	movq	%rbx, 0x48(%rsp)
    eba7:      	cmpl	%r15d, %r12d
    ebaa:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    ebb0:      	movq	0x8(%rsp), %r12
    ebb5:      	movq	%r12, 0x30(%rsp)
    ebba:      	movq	0x38(%rsp), %rdx
    ebbf:      	movq	0x40(%rsp), %r15
    ebc4:      	jmp	0xec17 <generic_kprobe_path+0x32f7>
    ebc6:      	leaq	0x10(%r15), %rdx
    ebca:      	movl	$0x4, %eax
    ebcf:      	movq	%rbp, %rdi
    ebd2:      	movl	$0x8, %esi
    ebd7:      	callq	*%rax
    ebd9:      	movq	0x40(%rsp), %rax
    ebde:      	cmpq	(%rsp), %rax
    ebe2:      	je	0x1738d <generic_kprobe_path+0xba6d>
    ebe8:      	addq	$0x18, %r15
    ebec:      	movl	$0x4, %eax
    ebf1:      	leaq	0x30(%rsp), %rdi
    ebf6:      	movl	$0x8, %esi
    ebfb:      	movq	%r15, %rdx
    ebfe:      	callq	*%rax
    ec00:      	movq	(%rsp), %r15
    ec04:      	movq	%r15, 0x40(%rsp)
    ec09:      	leaq	0x20(%r15), %rdx
    ec0d:      	movq	%rdx, 0x38(%rsp)
    ec12:      	movq	0x30(%rsp), %r12
    ec17:      	cmpq	0x18(%rsp), %r12
    ec1c:      	jne	0xec29 <generic_kprobe_path+0x3309>
    ec1e:      	cmpq	0x20(%rsp), %rdx
    ec23:      	je	0x1738d <generic_kprobe_path+0xba6d>
    ec29:      	movl	$0x4, %eax
    ec2e:      	leaq	0x10(%rsp), %rdi
    ec33:      	movl	$0x8, %esi
    ec38:      	callq	*%rax
    ec3a:      	cmpq	0x10(%rsp), %r12
    ec3f:      	je	0xed37 <generic_kprobe_path+0x3417>
    ec45:      	leaq	0x18(%r12), %rbx
    ec4a:      	movl	$0x4, %eax
    ec4f:      	movq	%rbp, %rdi
    ec52:      	movl	$0x8, %esi
    ec57:      	movq	%rbx, %rdx
    ec5a:      	callq	*%rax
    ec5c:      	cmpq	%r12, (%rsp)
    ec60:      	je	0xed37 <generic_kprobe_path+0x3417>
    ec66:      	movl	$0x4, %eax
    ec6b:      	leaq	0x8(%rsp), %rdi
    ec70:      	movl	$0x8, %esi
    ec75:      	movq	%rbx, %rdx
    ec78:      	callq	*%rax
    ec7a:      	addq	$0x20, %r12
    ec7e:      	movl	$0x4, %eax
    ec83:      	leaq	0x58(%rsp), %rdi
    ec88:      	movl	$0x10, %ecx
    ec8d:      	movl	$0x10, %esi
    ec92:      	movq	%r12, %rdx
    ec95:      	callq	*%rax
    ec97:      	movq	0x28(%rsp), %rbx
    ec9c:      	movq	0x48(%rsp), %rax
    eca1:      	movl	0x5c(%rsp), %r15d
    eca6:      	subq	%rbx, %rax
    eca9:      	movl	0x50(%rsp), %r12d
    ecae:      	movl	%r15d, %edx
    ecb1:      	subl	%r12d, %edx
    ecb4:      	movl	$0x0, %ecx
    ecb9:      	cmovbl	%ecx, %edx
    ecbc:      	addq	0x60(%rsp), %rdx
    ecc1:      	xorl	%esi, %esi
    ecc3:      	cmpl	%r15d, %r12d
    ecc6:      	seta	%sil
    ecca:      	movl	%r15d, %ecx
    eccd:      	cmovbl	%r12d, %ecx
    ecd1:      	addl	%ecx, %esi
    ecd3:      	movl	%r12d, %edi
    ecd6:      	subl	%esi, %edi
    ecd8:      	movl	%edi, 0x50(%rsp)
    ecdc:      	subq	%rsi, %rax
    ecdf:      	jb	0x17392 <generic_kprobe_path+0xba72>
    ece5:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    eceb:      	ja	0x17392 <generic_kprobe_path+0xba72>
    ecf1:      	cmpl	%r15d, %r12d
    ecf4:      	jbe	0xecfa <generic_kprobe_path+0x33da>
    ecf6:      	movb	$0x2f, (%rbx,%rax)
    ecfa:      	xorl	%edi, %edi
    ecfc:      	cmpl	%r15d, %r12d
    ecff:      	seta	%dil
    ed03:      	movzbl	%cl, %esi
    ed06:      	addq	%rax, %rbx
    ed09:      	addq	%rbx, %rdi
    ed0c:      	movl	$0x4, %eax
    ed11:      	callq	*%rax
    ed13:      	movq	%rbx, 0x48(%rsp)
    ed18:      	cmpl	%r15d, %r12d
    ed1b:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    ed21:      	movq	0x8(%rsp), %r12
    ed26:      	movq	%r12, 0x30(%rsp)
    ed2b:      	movq	0x38(%rsp), %rdx
    ed30:      	movq	0x40(%rsp), %r15
    ed35:      	jmp	0xed88 <generic_kprobe_path+0x3468>
    ed37:      	leaq	0x10(%r15), %rdx
    ed3b:      	movl	$0x4, %eax
    ed40:      	movq	%rbp, %rdi
    ed43:      	movl	$0x8, %esi
    ed48:      	callq	*%rax
    ed4a:      	movq	0x40(%rsp), %rax
    ed4f:      	cmpq	(%rsp), %rax
    ed53:      	je	0x1738d <generic_kprobe_path+0xba6d>
    ed59:      	addq	$0x18, %r15
    ed5d:      	movl	$0x4, %eax
    ed62:      	leaq	0x30(%rsp), %rdi
    ed67:      	movl	$0x8, %esi
    ed6c:      	movq	%r15, %rdx
    ed6f:      	callq	*%rax
    ed71:      	movq	(%rsp), %r15
    ed75:      	movq	%r15, 0x40(%rsp)
    ed7a:      	leaq	0x20(%r15), %rdx
    ed7e:      	movq	%rdx, 0x38(%rsp)
    ed83:      	movq	0x30(%rsp), %r12
    ed88:      	cmpq	0x18(%rsp), %r12
    ed8d:      	jne	0xed9a <generic_kprobe_path+0x347a>
    ed8f:      	cmpq	0x20(%rsp), %rdx
    ed94:      	je	0x1738d <generic_kprobe_path+0xba6d>
    ed9a:      	movl	$0x4, %eax
    ed9f:      	leaq	0x10(%rsp), %rdi
    eda4:      	movl	$0x8, %esi
    eda9:      	callq	*%rax
    edab:      	cmpq	0x10(%rsp), %r12
    edb0:      	je	0xeea8 <generic_kprobe_path+0x3588>
    edb6:      	leaq	0x18(%r12), %rbx
    edbb:      	movl	$0x4, %eax
    edc0:      	movq	%rbp, %rdi
    edc3:      	movl	$0x8, %esi
    edc8:      	movq	%rbx, %rdx
    edcb:      	callq	*%rax
    edcd:      	cmpq	%r12, (%rsp)
    edd1:      	je	0xeea8 <generic_kprobe_path+0x3588>
    edd7:      	movl	$0x4, %eax
    eddc:      	leaq	0x8(%rsp), %rdi
    ede1:      	movl	$0x8, %esi
    ede6:      	movq	%rbx, %rdx
    ede9:      	callq	*%rax
    edeb:      	addq	$0x20, %r12
    edef:      	movl	$0x4, %eax
    edf4:      	leaq	0x58(%rsp), %rdi
    edf9:      	movl	$0x10, %ecx
    edfe:      	movl	$0x10, %esi
    ee03:      	movq	%r12, %rdx
    ee06:      	callq	*%rax
    ee08:      	movq	0x28(%rsp), %rbx
    ee0d:      	movq	0x48(%rsp), %rax
    ee12:      	movl	0x5c(%rsp), %r15d
    ee17:      	subq	%rbx, %rax
    ee1a:      	movl	0x50(%rsp), %r12d
    ee1f:      	movl	%r15d, %edx
    ee22:      	subl	%r12d, %edx
    ee25:      	movl	$0x0, %ecx
    ee2a:      	cmovbl	%ecx, %edx
    ee2d:      	addq	0x60(%rsp), %rdx
    ee32:      	xorl	%esi, %esi
    ee34:      	cmpl	%r15d, %r12d
    ee37:      	seta	%sil
    ee3b:      	movl	%r15d, %ecx
    ee3e:      	cmovbl	%r12d, %ecx
    ee42:      	addl	%ecx, %esi
    ee44:      	movl	%r12d, %edi
    ee47:      	subl	%esi, %edi
    ee49:      	movl	%edi, 0x50(%rsp)
    ee4d:      	subq	%rsi, %rax
    ee50:      	jb	0x17392 <generic_kprobe_path+0xba72>
    ee56:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ee5c:      	ja	0x17392 <generic_kprobe_path+0xba72>
    ee62:      	cmpl	%r15d, %r12d
    ee65:      	jbe	0xee6b <generic_kprobe_path+0x354b>
    ee67:      	movb	$0x2f, (%rbx,%rax)
    ee6b:      	xorl	%edi, %edi
    ee6d:      	cmpl	%r15d, %r12d
    ee70:      	seta	%dil
    ee74:      	movzbl	%cl, %esi
    ee77:      	addq	%rax, %rbx
    ee7a:      	addq	%rbx, %rdi
    ee7d:      	movl	$0x4, %eax
    ee82:      	callq	*%rax
    ee84:      	movq	%rbx, 0x48(%rsp)
    ee89:      	cmpl	%r15d, %r12d
    ee8c:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    ee92:      	movq	0x8(%rsp), %r12
    ee97:      	movq	%r12, 0x30(%rsp)
    ee9c:      	movq	0x38(%rsp), %rdx
    eea1:      	movq	0x40(%rsp), %r15
    eea6:      	jmp	0xeef9 <generic_kprobe_path+0x35d9>
    eea8:      	leaq	0x10(%r15), %rdx
    eeac:      	movl	$0x4, %eax
    eeb1:      	movq	%rbp, %rdi
    eeb4:      	movl	$0x8, %esi
    eeb9:      	callq	*%rax
    eebb:      	movq	0x40(%rsp), %rax
    eec0:      	cmpq	(%rsp), %rax
    eec4:      	je	0x1738d <generic_kprobe_path+0xba6d>
    eeca:      	addq	$0x18, %r15
    eece:      	movl	$0x4, %eax
    eed3:      	leaq	0x30(%rsp), %rdi
    eed8:      	movl	$0x8, %esi
    eedd:      	movq	%r15, %rdx
    eee0:      	callq	*%rax
    eee2:      	movq	(%rsp), %r15
    eee6:      	movq	%r15, 0x40(%rsp)
    eeeb:      	leaq	0x20(%r15), %rdx
    eeef:      	movq	%rdx, 0x38(%rsp)
    eef4:      	movq	0x30(%rsp), %r12
    eef9:      	cmpq	0x18(%rsp), %r12
    eefe:      	jne	0xef0b <generic_kprobe_path+0x35eb>
    ef00:      	cmpq	0x20(%rsp), %rdx
    ef05:      	je	0x1738d <generic_kprobe_path+0xba6d>
    ef0b:      	movl	$0x4, %eax
    ef10:      	leaq	0x10(%rsp), %rdi
    ef15:      	movl	$0x8, %esi
    ef1a:      	callq	*%rax
    ef1c:      	cmpq	0x10(%rsp), %r12
    ef21:      	je	0xf019 <generic_kprobe_path+0x36f9>
    ef27:      	leaq	0x18(%r12), %rbx
    ef2c:      	movl	$0x4, %eax
    ef31:      	movq	%rbp, %rdi
    ef34:      	movl	$0x8, %esi
    ef39:      	movq	%rbx, %rdx
    ef3c:      	callq	*%rax
    ef3e:      	cmpq	%r12, (%rsp)
    ef42:      	je	0xf019 <generic_kprobe_path+0x36f9>
    ef48:      	movl	$0x4, %eax
    ef4d:      	leaq	0x8(%rsp), %rdi
    ef52:      	movl	$0x8, %esi
    ef57:      	movq	%rbx, %rdx
    ef5a:      	callq	*%rax
    ef5c:      	addq	$0x20, %r12
    ef60:      	movl	$0x4, %eax
    ef65:      	leaq	0x58(%rsp), %rdi
    ef6a:      	movl	$0x10, %ecx
    ef6f:      	movl	$0x10, %esi
    ef74:      	movq	%r12, %rdx
    ef77:      	callq	*%rax
    ef79:      	movq	0x28(%rsp), %rbx
    ef7e:      	movq	0x48(%rsp), %rax
    ef83:      	movl	0x5c(%rsp), %r15d
    ef88:      	subq	%rbx, %rax
    ef8b:      	movl	0x50(%rsp), %r12d
    ef90:      	movl	%r15d, %edx
    ef93:      	subl	%r12d, %edx
    ef96:      	movl	$0x0, %ecx
    ef9b:      	cmovbl	%ecx, %edx
    ef9e:      	addq	0x60(%rsp), %rdx
    efa3:      	xorl	%esi, %esi
    efa5:      	cmpl	%r15d, %r12d
    efa8:      	seta	%sil
    efac:      	movl	%r15d, %ecx
    efaf:      	cmovbl	%r12d, %ecx
    efb3:      	addl	%ecx, %esi
    efb5:      	movl	%r12d, %edi
    efb8:      	subl	%esi, %edi
    efba:      	movl	%edi, 0x50(%rsp)
    efbe:      	subq	%rsi, %rax
    efc1:      	jb	0x17392 <generic_kprobe_path+0xba72>
    efc7:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    efcd:      	ja	0x17392 <generic_kprobe_path+0xba72>
    efd3:      	cmpl	%r15d, %r12d
    efd6:      	jbe	0xefdc <generic_kprobe_path+0x36bc>
    efd8:      	movb	$0x2f, (%rbx,%rax)
    efdc:      	xorl	%edi, %edi
    efde:      	cmpl	%r15d, %r12d
    efe1:      	seta	%dil
    efe5:      	movzbl	%cl, %esi
    efe8:      	addq	%rax, %rbx
    efeb:      	addq	%rbx, %rdi
    efee:      	movl	$0x4, %eax
    eff3:      	callq	*%rax
    eff5:      	movq	%rbx, 0x48(%rsp)
    effa:      	cmpl	%r15d, %r12d
    effd:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    f003:      	movq	0x8(%rsp), %r12
    f008:      	movq	%r12, 0x30(%rsp)
    f00d:      	movq	0x38(%rsp), %rdx
    f012:      	movq	0x40(%rsp), %r15
    f017:      	jmp	0xf06a <generic_kprobe_path+0x374a>
    f019:      	leaq	0x10(%r15), %rdx
    f01d:      	movl	$0x4, %eax
    f022:      	movq	%rbp, %rdi
    f025:      	movl	$0x8, %esi
    f02a:      	callq	*%rax
    f02c:      	movq	0x40(%rsp), %rax
    f031:      	cmpq	(%rsp), %rax
    f035:      	je	0x1738d <generic_kprobe_path+0xba6d>
    f03b:      	addq	$0x18, %r15
    f03f:      	movl	$0x4, %eax
    f044:      	leaq	0x30(%rsp), %rdi
    f049:      	movl	$0x8, %esi
    f04e:      	movq	%r15, %rdx
    f051:      	callq	*%rax
    f053:      	movq	(%rsp), %r15
    f057:      	movq	%r15, 0x40(%rsp)
    f05c:      	leaq	0x20(%r15), %rdx
    f060:      	movq	%rdx, 0x38(%rsp)
    f065:      	movq	0x30(%rsp), %r12
    f06a:      	cmpq	0x18(%rsp), %r12
    f06f:      	jne	0xf07c <generic_kprobe_path+0x375c>
    f071:      	cmpq	0x20(%rsp), %rdx
    f076:      	je	0x1738d <generic_kprobe_path+0xba6d>
    f07c:      	movl	$0x4, %eax
    f081:      	leaq	0x10(%rsp), %rdi
    f086:      	movl	$0x8, %esi
    f08b:      	callq	*%rax
    f08d:      	cmpq	0x10(%rsp), %r12
    f092:      	je	0xf18a <generic_kprobe_path+0x386a>
    f098:      	leaq	0x18(%r12), %rbx
    f09d:      	movl	$0x4, %eax
    f0a2:      	movq	%rbp, %rdi
    f0a5:      	movl	$0x8, %esi
    f0aa:      	movq	%rbx, %rdx
    f0ad:      	callq	*%rax
    f0af:      	cmpq	%r12, (%rsp)
    f0b3:      	je	0xf18a <generic_kprobe_path+0x386a>
    f0b9:      	movl	$0x4, %eax
    f0be:      	leaq	0x8(%rsp), %rdi
    f0c3:      	movl	$0x8, %esi
    f0c8:      	movq	%rbx, %rdx
    f0cb:      	callq	*%rax
    f0cd:      	addq	$0x20, %r12
    f0d1:      	movl	$0x4, %eax
    f0d6:      	leaq	0x58(%rsp), %rdi
    f0db:      	movl	$0x10, %ecx
    f0e0:      	movl	$0x10, %esi
    f0e5:      	movq	%r12, %rdx
    f0e8:      	callq	*%rax
    f0ea:      	movq	0x28(%rsp), %rbx
    f0ef:      	movq	0x48(%rsp), %rax
    f0f4:      	movl	0x5c(%rsp), %r15d
    f0f9:      	subq	%rbx, %rax
    f0fc:      	movl	0x50(%rsp), %r12d
    f101:      	movl	%r15d, %edx
    f104:      	subl	%r12d, %edx
    f107:      	movl	$0x0, %ecx
    f10c:      	cmovbl	%ecx, %edx
    f10f:      	addq	0x60(%rsp), %rdx
    f114:      	xorl	%esi, %esi
    f116:      	cmpl	%r15d, %r12d
    f119:      	seta	%sil
    f11d:      	movl	%r15d, %ecx
    f120:      	cmovbl	%r12d, %ecx
    f124:      	addl	%ecx, %esi
    f126:      	movl	%r12d, %edi
    f129:      	subl	%esi, %edi
    f12b:      	movl	%edi, 0x50(%rsp)
    f12f:      	subq	%rsi, %rax
    f132:      	jb	0x17392 <generic_kprobe_path+0xba72>
    f138:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f13e:      	ja	0x17392 <generic_kprobe_path+0xba72>
    f144:      	cmpl	%r15d, %r12d
    f147:      	jbe	0xf14d <generic_kprobe_path+0x382d>
    f149:      	movb	$0x2f, (%rbx,%rax)
    f14d:      	xorl	%edi, %edi
    f14f:      	cmpl	%r15d, %r12d
    f152:      	seta	%dil
    f156:      	movzbl	%cl, %esi
    f159:      	addq	%rax, %rbx
    f15c:      	addq	%rbx, %rdi
    f15f:      	movl	$0x4, %eax
    f164:      	callq	*%rax
    f166:      	movq	%rbx, 0x48(%rsp)
    f16b:      	cmpl	%r15d, %r12d
    f16e:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    f174:      	movq	0x8(%rsp), %r12
    f179:      	movq	%r12, 0x30(%rsp)
    f17e:      	movq	0x38(%rsp), %rdx
    f183:      	movq	0x40(%rsp), %r15
    f188:      	jmp	0xf1db <generic_kprobe_path+0x38bb>
    f18a:      	leaq	0x10(%r15), %rdx
    f18e:      	movl	$0x4, %eax
    f193:      	movq	%rbp, %rdi
    f196:      	movl	$0x8, %esi
    f19b:      	callq	*%rax
    f19d:      	movq	0x40(%rsp), %rax
    f1a2:      	cmpq	(%rsp), %rax
    f1a6:      	je	0x1738d <generic_kprobe_path+0xba6d>
    f1ac:      	addq	$0x18, %r15
    f1b0:      	movl	$0x4, %eax
    f1b5:      	leaq	0x30(%rsp), %rdi
    f1ba:      	movl	$0x8, %esi
    f1bf:      	movq	%r15, %rdx
    f1c2:      	callq	*%rax
    f1c4:      	movq	(%rsp), %r15
    f1c8:      	movq	%r15, 0x40(%rsp)
    f1cd:      	leaq	0x20(%r15), %rdx
    f1d1:      	movq	%rdx, 0x38(%rsp)
    f1d6:      	movq	0x30(%rsp), %r12
    f1db:      	cmpq	0x18(%rsp), %r12
    f1e0:      	jne	0xf1ed <generic_kprobe_path+0x38cd>
    f1e2:      	cmpq	0x20(%rsp), %rdx
    f1e7:      	je	0x1738d <generic_kprobe_path+0xba6d>
    f1ed:      	movl	$0x4, %eax
    f1f2:      	leaq	0x10(%rsp), %rdi
    f1f7:      	movl	$0x8, %esi
    f1fc:      	callq	*%rax
    f1fe:      	cmpq	0x10(%rsp), %r12
    f203:      	je	0xf2fb <generic_kprobe_path+0x39db>
    f209:      	leaq	0x18(%r12), %rbx
    f20e:      	movl	$0x4, %eax
    f213:      	movq	%rbp, %rdi
    f216:      	movl	$0x8, %esi
    f21b:      	movq	%rbx, %rdx
    f21e:      	callq	*%rax
    f220:      	cmpq	%r12, (%rsp)
    f224:      	je	0xf2fb <generic_kprobe_path+0x39db>
    f22a:      	movl	$0x4, %eax
    f22f:      	leaq	0x8(%rsp), %rdi
    f234:      	movl	$0x8, %esi
    f239:      	movq	%rbx, %rdx
    f23c:      	callq	*%rax
    f23e:      	addq	$0x20, %r12
    f242:      	movl	$0x4, %eax
    f247:      	leaq	0x58(%rsp), %rdi
    f24c:      	movl	$0x10, %ecx
    f251:      	movl	$0x10, %esi
    f256:      	movq	%r12, %rdx
    f259:      	callq	*%rax
    f25b:      	movq	0x28(%rsp), %rbx
    f260:      	movq	0x48(%rsp), %rax
    f265:      	movl	0x5c(%rsp), %r15d
    f26a:      	subq	%rbx, %rax
    f26d:      	movl	0x50(%rsp), %r12d
    f272:      	movl	%r15d, %edx
    f275:      	subl	%r12d, %edx
    f278:      	movl	$0x0, %ecx
    f27d:      	cmovbl	%ecx, %edx
    f280:      	addq	0x60(%rsp), %rdx
    f285:      	xorl	%esi, %esi
    f287:      	cmpl	%r15d, %r12d
    f28a:      	seta	%sil
    f28e:      	movl	%r15d, %ecx
    f291:      	cmovbl	%r12d, %ecx
    f295:      	addl	%ecx, %esi
    f297:      	movl	%r12d, %edi
    f29a:      	subl	%esi, %edi
    f29c:      	movl	%edi, 0x50(%rsp)
    f2a0:      	subq	%rsi, %rax
    f2a3:      	jb	0x17392 <generic_kprobe_path+0xba72>
    f2a9:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f2af:      	ja	0x17392 <generic_kprobe_path+0xba72>
    f2b5:      	cmpl	%r15d, %r12d
    f2b8:      	jbe	0xf2be <generic_kprobe_path+0x399e>
    f2ba:      	movb	$0x2f, (%rbx,%rax)
    f2be:      	xorl	%edi, %edi
    f2c0:      	cmpl	%r15d, %r12d
    f2c3:      	seta	%dil
    f2c7:      	movzbl	%cl, %esi
    f2ca:      	addq	%rax, %rbx
    f2cd:      	addq	%rbx, %rdi
    f2d0:      	movl	$0x4, %eax
    f2d5:      	callq	*%rax
    f2d7:      	movq	%rbx, 0x48(%rsp)
    f2dc:      	cmpl	%r15d, %r12d
    f2df:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    f2e5:      	movq	0x8(%rsp), %r12
    f2ea:      	movq	%r12, 0x30(%rsp)
    f2ef:      	movq	0x38(%rsp), %rdx
    f2f4:      	movq	0x40(%rsp), %r15
    f2f9:      	jmp	0xf34c <generic_kprobe_path+0x3a2c>
    f2fb:      	leaq	0x10(%r15), %rdx
    f2ff:      	movl	$0x4, %eax
    f304:      	movq	%rbp, %rdi
    f307:      	movl	$0x8, %esi
    f30c:      	callq	*%rax
    f30e:      	movq	0x40(%rsp), %rax
    f313:      	cmpq	(%rsp), %rax
    f317:      	je	0x1738d <generic_kprobe_path+0xba6d>
    f31d:      	addq	$0x18, %r15
    f321:      	movl	$0x4, %eax
    f326:      	leaq	0x30(%rsp), %rdi
    f32b:      	movl	$0x8, %esi
    f330:      	movq	%r15, %rdx
    f333:      	callq	*%rax
    f335:      	movq	(%rsp), %r15
    f339:      	movq	%r15, 0x40(%rsp)
    f33e:      	leaq	0x20(%r15), %rdx
    f342:      	movq	%rdx, 0x38(%rsp)
    f347:      	movq	0x30(%rsp), %r12
    f34c:      	cmpq	0x18(%rsp), %r12
    f351:      	jne	0xf35e <generic_kprobe_path+0x3a3e>
    f353:      	cmpq	0x20(%rsp), %rdx
    f358:      	je	0x1738d <generic_kprobe_path+0xba6d>
    f35e:      	movl	$0x4, %eax
    f363:      	leaq	0x10(%rsp), %rdi
    f368:      	movl	$0x8, %esi
    f36d:      	callq	*%rax
    f36f:      	cmpq	0x10(%rsp), %r12
    f374:      	je	0xf46c <generic_kprobe_path+0x3b4c>
    f37a:      	leaq	0x18(%r12), %rbx
    f37f:      	movl	$0x4, %eax
    f384:      	movq	%rbp, %rdi
    f387:      	movl	$0x8, %esi
    f38c:      	movq	%rbx, %rdx
    f38f:      	callq	*%rax
    f391:      	cmpq	%r12, (%rsp)
    f395:      	je	0xf46c <generic_kprobe_path+0x3b4c>
    f39b:      	movl	$0x4, %eax
    f3a0:      	leaq	0x8(%rsp), %rdi
    f3a5:      	movl	$0x8, %esi
    f3aa:      	movq	%rbx, %rdx
    f3ad:      	callq	*%rax
    f3af:      	addq	$0x20, %r12
    f3b3:      	movl	$0x4, %eax
    f3b8:      	leaq	0x58(%rsp), %rdi
    f3bd:      	movl	$0x10, %ecx
    f3c2:      	movl	$0x10, %esi
    f3c7:      	movq	%r12, %rdx
    f3ca:      	callq	*%rax
    f3cc:      	movq	0x28(%rsp), %rbx
    f3d1:      	movq	0x48(%rsp), %rax
    f3d6:      	movl	0x5c(%rsp), %r15d
    f3db:      	subq	%rbx, %rax
    f3de:      	movl	0x50(%rsp), %r12d
    f3e3:      	movl	%r15d, %edx
    f3e6:      	subl	%r12d, %edx
    f3e9:      	movl	$0x0, %ecx
    f3ee:      	cmovbl	%ecx, %edx
    f3f1:      	addq	0x60(%rsp), %rdx
    f3f6:      	xorl	%esi, %esi
    f3f8:      	cmpl	%r15d, %r12d
    f3fb:      	seta	%sil
    f3ff:      	movl	%r15d, %ecx
    f402:      	cmovbl	%r12d, %ecx
    f406:      	addl	%ecx, %esi
    f408:      	movl	%r12d, %edi
    f40b:      	subl	%esi, %edi
    f40d:      	movl	%edi, 0x50(%rsp)
    f411:      	subq	%rsi, %rax
    f414:      	jb	0x17392 <generic_kprobe_path+0xba72>
    f41a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f420:      	ja	0x17392 <generic_kprobe_path+0xba72>
    f426:      	cmpl	%r15d, %r12d
    f429:      	jbe	0xf42f <generic_kprobe_path+0x3b0f>
    f42b:      	movb	$0x2f, (%rbx,%rax)
    f42f:      	xorl	%edi, %edi
    f431:      	cmpl	%r15d, %r12d
    f434:      	seta	%dil
    f438:      	movzbl	%cl, %esi
    f43b:      	addq	%rax, %rbx
    f43e:      	addq	%rbx, %rdi
    f441:      	movl	$0x4, %eax
    f446:      	callq	*%rax
    f448:      	movq	%rbx, 0x48(%rsp)
    f44d:      	cmpl	%r15d, %r12d
    f450:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    f456:      	movq	0x8(%rsp), %r12
    f45b:      	movq	%r12, 0x30(%rsp)
    f460:      	movq	0x38(%rsp), %rdx
    f465:      	movq	0x40(%rsp), %r15
    f46a:      	jmp	0xf4bd <generic_kprobe_path+0x3b9d>
    f46c:      	leaq	0x10(%r15), %rdx
    f470:      	movl	$0x4, %eax
    f475:      	movq	%rbp, %rdi
    f478:      	movl	$0x8, %esi
    f47d:      	callq	*%rax
    f47f:      	movq	0x40(%rsp), %rax
    f484:      	cmpq	(%rsp), %rax
    f488:      	je	0x1738d <generic_kprobe_path+0xba6d>
    f48e:      	addq	$0x18, %r15
    f492:      	movl	$0x4, %eax
    f497:      	leaq	0x30(%rsp), %rdi
    f49c:      	movl	$0x8, %esi
    f4a1:      	movq	%r15, %rdx
    f4a4:      	callq	*%rax
    f4a6:      	movq	(%rsp), %r15
    f4aa:      	movq	%r15, 0x40(%rsp)
    f4af:      	leaq	0x20(%r15), %rdx
    f4b3:      	movq	%rdx, 0x38(%rsp)
    f4b8:      	movq	0x30(%rsp), %r12
    f4bd:      	cmpq	0x18(%rsp), %r12
    f4c2:      	jne	0xf4cf <generic_kprobe_path+0x3baf>
    f4c4:      	cmpq	0x20(%rsp), %rdx
    f4c9:      	je	0x1738d <generic_kprobe_path+0xba6d>
    f4cf:      	movl	$0x4, %eax
    f4d4:      	leaq	0x10(%rsp), %rdi
    f4d9:      	movl	$0x8, %esi
    f4de:      	callq	*%rax
    f4e0:      	cmpq	0x10(%rsp), %r12
    f4e5:      	je	0xf5dd <generic_kprobe_path+0x3cbd>
    f4eb:      	leaq	0x18(%r12), %rbx
    f4f0:      	movl	$0x4, %eax
    f4f5:      	movq	%rbp, %rdi
    f4f8:      	movl	$0x8, %esi
    f4fd:      	movq	%rbx, %rdx
    f500:      	callq	*%rax
    f502:      	cmpq	%r12, (%rsp)
    f506:      	je	0xf5dd <generic_kprobe_path+0x3cbd>
    f50c:      	movl	$0x4, %eax
    f511:      	leaq	0x8(%rsp), %rdi
    f516:      	movl	$0x8, %esi
    f51b:      	movq	%rbx, %rdx
    f51e:      	callq	*%rax
    f520:      	addq	$0x20, %r12
    f524:      	movl	$0x4, %eax
    f529:      	leaq	0x58(%rsp), %rdi
    f52e:      	movl	$0x10, %ecx
    f533:      	movl	$0x10, %esi
    f538:      	movq	%r12, %rdx
    f53b:      	callq	*%rax
    f53d:      	movq	0x28(%rsp), %rbx
    f542:      	movq	0x48(%rsp), %rax
    f547:      	movl	0x5c(%rsp), %r15d
    f54c:      	subq	%rbx, %rax
    f54f:      	movl	0x50(%rsp), %r12d
    f554:      	movl	%r15d, %edx
    f557:      	subl	%r12d, %edx
    f55a:      	movl	$0x0, %ecx
    f55f:      	cmovbl	%ecx, %edx
    f562:      	addq	0x60(%rsp), %rdx
    f567:      	xorl	%esi, %esi
    f569:      	cmpl	%r15d, %r12d
    f56c:      	seta	%sil
    f570:      	movl	%r15d, %ecx
    f573:      	cmovbl	%r12d, %ecx
    f577:      	addl	%ecx, %esi
    f579:      	movl	%r12d, %edi
    f57c:      	subl	%esi, %edi
    f57e:      	movl	%edi, 0x50(%rsp)
    f582:      	subq	%rsi, %rax
    f585:      	jb	0x17392 <generic_kprobe_path+0xba72>
    f58b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f591:      	ja	0x17392 <generic_kprobe_path+0xba72>
    f597:      	cmpl	%r15d, %r12d
    f59a:      	jbe	0xf5a0 <generic_kprobe_path+0x3c80>
    f59c:      	movb	$0x2f, (%rbx,%rax)
    f5a0:      	xorl	%edi, %edi
    f5a2:      	cmpl	%r15d, %r12d
    f5a5:      	seta	%dil
    f5a9:      	movzbl	%cl, %esi
    f5ac:      	addq	%rax, %rbx
    f5af:      	addq	%rbx, %rdi
    f5b2:      	movl	$0x4, %eax
    f5b7:      	callq	*%rax
    f5b9:      	movq	%rbx, 0x48(%rsp)
    f5be:      	cmpl	%r15d, %r12d
    f5c1:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    f5c7:      	movq	0x8(%rsp), %r12
    f5cc:      	movq	%r12, 0x30(%rsp)
    f5d1:      	movq	0x38(%rsp), %rdx
    f5d6:      	movq	0x40(%rsp), %r15
    f5db:      	jmp	0xf62e <generic_kprobe_path+0x3d0e>
    f5dd:      	leaq	0x10(%r15), %rdx
    f5e1:      	movl	$0x4, %eax
    f5e6:      	movq	%rbp, %rdi
    f5e9:      	movl	$0x8, %esi
    f5ee:      	callq	*%rax
    f5f0:      	movq	0x40(%rsp), %rax
    f5f5:      	cmpq	(%rsp), %rax
    f5f9:      	je	0x1738d <generic_kprobe_path+0xba6d>
    f5ff:      	addq	$0x18, %r15
    f603:      	movl	$0x4, %eax
    f608:      	leaq	0x30(%rsp), %rdi
    f60d:      	movl	$0x8, %esi
    f612:      	movq	%r15, %rdx
    f615:      	callq	*%rax
    f617:      	movq	(%rsp), %r15
    f61b:      	movq	%r15, 0x40(%rsp)
    f620:      	leaq	0x20(%r15), %rdx
    f624:      	movq	%rdx, 0x38(%rsp)
    f629:      	movq	0x30(%rsp), %r12
    f62e:      	cmpq	0x18(%rsp), %r12
    f633:      	jne	0xf640 <generic_kprobe_path+0x3d20>
    f635:      	cmpq	0x20(%rsp), %rdx
    f63a:      	je	0x1738d <generic_kprobe_path+0xba6d>
    f640:      	movl	$0x4, %eax
    f645:      	leaq	0x10(%rsp), %rdi
    f64a:      	movl	$0x8, %esi
    f64f:      	callq	*%rax
    f651:      	cmpq	0x10(%rsp), %r12
    f656:      	je	0xf74e <generic_kprobe_path+0x3e2e>
    f65c:      	leaq	0x18(%r12), %rbx
    f661:      	movl	$0x4, %eax
    f666:      	movq	%rbp, %rdi
    f669:      	movl	$0x8, %esi
    f66e:      	movq	%rbx, %rdx
    f671:      	callq	*%rax
    f673:      	cmpq	%r12, (%rsp)
    f677:      	je	0xf74e <generic_kprobe_path+0x3e2e>
    f67d:      	movl	$0x4, %eax
    f682:      	leaq	0x8(%rsp), %rdi
    f687:      	movl	$0x8, %esi
    f68c:      	movq	%rbx, %rdx
    f68f:      	callq	*%rax
    f691:      	addq	$0x20, %r12
    f695:      	movl	$0x4, %eax
    f69a:      	leaq	0x58(%rsp), %rdi
    f69f:      	movl	$0x10, %ecx
    f6a4:      	movl	$0x10, %esi
    f6a9:      	movq	%r12, %rdx
    f6ac:      	callq	*%rax
    f6ae:      	movq	0x28(%rsp), %rbx
    f6b3:      	movq	0x48(%rsp), %rax
    f6b8:      	movl	0x5c(%rsp), %r15d
    f6bd:      	subq	%rbx, %rax
    f6c0:      	movl	0x50(%rsp), %r12d
    f6c5:      	movl	%r15d, %edx
    f6c8:      	subl	%r12d, %edx
    f6cb:      	movl	$0x0, %ecx
    f6d0:      	cmovbl	%ecx, %edx
    f6d3:      	addq	0x60(%rsp), %rdx
    f6d8:      	xorl	%esi, %esi
    f6da:      	cmpl	%r15d, %r12d
    f6dd:      	seta	%sil
    f6e1:      	movl	%r15d, %ecx
    f6e4:      	cmovbl	%r12d, %ecx
    f6e8:      	addl	%ecx, %esi
    f6ea:      	movl	%r12d, %edi
    f6ed:      	subl	%esi, %edi
    f6ef:      	movl	%edi, 0x50(%rsp)
    f6f3:      	subq	%rsi, %rax
    f6f6:      	jb	0x17392 <generic_kprobe_path+0xba72>
    f6fc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f702:      	ja	0x17392 <generic_kprobe_path+0xba72>
    f708:      	cmpl	%r15d, %r12d
    f70b:      	jbe	0xf711 <generic_kprobe_path+0x3df1>
    f70d:      	movb	$0x2f, (%rbx,%rax)
    f711:      	xorl	%edi, %edi
    f713:      	cmpl	%r15d, %r12d
    f716:      	seta	%dil
    f71a:      	movzbl	%cl, %esi
    f71d:      	addq	%rax, %rbx
    f720:      	addq	%rbx, %rdi
    f723:      	movl	$0x4, %eax
    f728:      	callq	*%rax
    f72a:      	movq	%rbx, 0x48(%rsp)
    f72f:      	cmpl	%r15d, %r12d
    f732:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    f738:      	movq	0x8(%rsp), %r12
    f73d:      	movq	%r12, 0x30(%rsp)
    f742:      	movq	0x38(%rsp), %rdx
    f747:      	movq	0x40(%rsp), %r15
    f74c:      	jmp	0xf79f <generic_kprobe_path+0x3e7f>
    f74e:      	leaq	0x10(%r15), %rdx
    f752:      	movl	$0x4, %eax
    f757:      	movq	%rbp, %rdi
    f75a:      	movl	$0x8, %esi
    f75f:      	callq	*%rax
    f761:      	movq	0x40(%rsp), %rax
    f766:      	cmpq	(%rsp), %rax
    f76a:      	je	0x1738d <generic_kprobe_path+0xba6d>
    f770:      	addq	$0x18, %r15
    f774:      	movl	$0x4, %eax
    f779:      	leaq	0x30(%rsp), %rdi
    f77e:      	movl	$0x8, %esi
    f783:      	movq	%r15, %rdx
    f786:      	callq	*%rax
    f788:      	movq	(%rsp), %r15
    f78c:      	movq	%r15, 0x40(%rsp)
    f791:      	leaq	0x20(%r15), %rdx
    f795:      	movq	%rdx, 0x38(%rsp)
    f79a:      	movq	0x30(%rsp), %r12
    f79f:      	cmpq	0x18(%rsp), %r12
    f7a4:      	jne	0xf7b1 <generic_kprobe_path+0x3e91>
    f7a6:      	cmpq	0x20(%rsp), %rdx
    f7ab:      	je	0x1738d <generic_kprobe_path+0xba6d>
    f7b1:      	movl	$0x4, %eax
    f7b6:      	leaq	0x10(%rsp), %rdi
    f7bb:      	movl	$0x8, %esi
    f7c0:      	callq	*%rax
    f7c2:      	cmpq	0x10(%rsp), %r12
    f7c7:      	je	0xf8bf <generic_kprobe_path+0x3f9f>
    f7cd:      	leaq	0x18(%r12), %rbx
    f7d2:      	movl	$0x4, %eax
    f7d7:      	movq	%rbp, %rdi
    f7da:      	movl	$0x8, %esi
    f7df:      	movq	%rbx, %rdx
    f7e2:      	callq	*%rax
    f7e4:      	cmpq	%r12, (%rsp)
    f7e8:      	je	0xf8bf <generic_kprobe_path+0x3f9f>
    f7ee:      	movl	$0x4, %eax
    f7f3:      	leaq	0x8(%rsp), %rdi
    f7f8:      	movl	$0x8, %esi
    f7fd:      	movq	%rbx, %rdx
    f800:      	callq	*%rax
    f802:      	addq	$0x20, %r12
    f806:      	movl	$0x4, %eax
    f80b:      	leaq	0x58(%rsp), %rdi
    f810:      	movl	$0x10, %ecx
    f815:      	movl	$0x10, %esi
    f81a:      	movq	%r12, %rdx
    f81d:      	callq	*%rax
    f81f:      	movq	0x28(%rsp), %rbx
    f824:      	movq	0x48(%rsp), %rax
    f829:      	movl	0x5c(%rsp), %r15d
    f82e:      	subq	%rbx, %rax
    f831:      	movl	0x50(%rsp), %r12d
    f836:      	movl	%r15d, %edx
    f839:      	subl	%r12d, %edx
    f83c:      	movl	$0x0, %ecx
    f841:      	cmovbl	%ecx, %edx
    f844:      	addq	0x60(%rsp), %rdx
    f849:      	xorl	%esi, %esi
    f84b:      	cmpl	%r15d, %r12d
    f84e:      	seta	%sil
    f852:      	movl	%r15d, %ecx
    f855:      	cmovbl	%r12d, %ecx
    f859:      	addl	%ecx, %esi
    f85b:      	movl	%r12d, %edi
    f85e:      	subl	%esi, %edi
    f860:      	movl	%edi, 0x50(%rsp)
    f864:      	subq	%rsi, %rax
    f867:      	jb	0x17392 <generic_kprobe_path+0xba72>
    f86d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f873:      	ja	0x17392 <generic_kprobe_path+0xba72>
    f879:      	cmpl	%r15d, %r12d
    f87c:      	jbe	0xf882 <generic_kprobe_path+0x3f62>
    f87e:      	movb	$0x2f, (%rbx,%rax)
    f882:      	xorl	%edi, %edi
    f884:      	cmpl	%r15d, %r12d
    f887:      	seta	%dil
    f88b:      	movzbl	%cl, %esi
    f88e:      	addq	%rax, %rbx
    f891:      	addq	%rbx, %rdi
    f894:      	movl	$0x4, %eax
    f899:      	callq	*%rax
    f89b:      	movq	%rbx, 0x48(%rsp)
    f8a0:      	cmpl	%r15d, %r12d
    f8a3:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    f8a9:      	movq	0x8(%rsp), %r12
    f8ae:      	movq	%r12, 0x30(%rsp)
    f8b3:      	movq	0x38(%rsp), %rdx
    f8b8:      	movq	0x40(%rsp), %r15
    f8bd:      	jmp	0xf910 <generic_kprobe_path+0x3ff0>
    f8bf:      	leaq	0x10(%r15), %rdx
    f8c3:      	movl	$0x4, %eax
    f8c8:      	movq	%rbp, %rdi
    f8cb:      	movl	$0x8, %esi
    f8d0:      	callq	*%rax
    f8d2:      	movq	0x40(%rsp), %rax
    f8d7:      	cmpq	(%rsp), %rax
    f8db:      	je	0x1738d <generic_kprobe_path+0xba6d>
    f8e1:      	addq	$0x18, %r15
    f8e5:      	movl	$0x4, %eax
    f8ea:      	leaq	0x30(%rsp), %rdi
    f8ef:      	movl	$0x8, %esi
    f8f4:      	movq	%r15, %rdx
    f8f7:      	callq	*%rax
    f8f9:      	movq	(%rsp), %r15
    f8fd:      	movq	%r15, 0x40(%rsp)
    f902:      	leaq	0x20(%r15), %rdx
    f906:      	movq	%rdx, 0x38(%rsp)
    f90b:      	movq	0x30(%rsp), %r12
    f910:      	cmpq	0x18(%rsp), %r12
    f915:      	jne	0xf922 <generic_kprobe_path+0x4002>
    f917:      	cmpq	0x20(%rsp), %rdx
    f91c:      	je	0x1738d <generic_kprobe_path+0xba6d>
    f922:      	movl	$0x4, %eax
    f927:      	leaq	0x10(%rsp), %rdi
    f92c:      	movl	$0x8, %esi
    f931:      	callq	*%rax
    f933:      	cmpq	0x10(%rsp), %r12
    f938:      	je	0xfa30 <generic_kprobe_path+0x4110>
    f93e:      	leaq	0x18(%r12), %rbx
    f943:      	movl	$0x4, %eax
    f948:      	movq	%rbp, %rdi
    f94b:      	movl	$0x8, %esi
    f950:      	movq	%rbx, %rdx
    f953:      	callq	*%rax
    f955:      	cmpq	%r12, (%rsp)
    f959:      	je	0xfa30 <generic_kprobe_path+0x4110>
    f95f:      	movl	$0x4, %eax
    f964:      	leaq	0x8(%rsp), %rdi
    f969:      	movl	$0x8, %esi
    f96e:      	movq	%rbx, %rdx
    f971:      	callq	*%rax
    f973:      	addq	$0x20, %r12
    f977:      	movl	$0x4, %eax
    f97c:      	leaq	0x58(%rsp), %rdi
    f981:      	movl	$0x10, %ecx
    f986:      	movl	$0x10, %esi
    f98b:      	movq	%r12, %rdx
    f98e:      	callq	*%rax
    f990:      	movq	0x28(%rsp), %rbx
    f995:      	movq	0x48(%rsp), %rax
    f99a:      	movl	0x5c(%rsp), %r15d
    f99f:      	subq	%rbx, %rax
    f9a2:      	movl	0x50(%rsp), %r12d
    f9a7:      	movl	%r15d, %edx
    f9aa:      	subl	%r12d, %edx
    f9ad:      	movl	$0x0, %ecx
    f9b2:      	cmovbl	%ecx, %edx
    f9b5:      	addq	0x60(%rsp), %rdx
    f9ba:      	xorl	%esi, %esi
    f9bc:      	cmpl	%r15d, %r12d
    f9bf:      	seta	%sil
    f9c3:      	movl	%r15d, %ecx
    f9c6:      	cmovbl	%r12d, %ecx
    f9ca:      	addl	%ecx, %esi
    f9cc:      	movl	%r12d, %edi
    f9cf:      	subl	%esi, %edi
    f9d1:      	movl	%edi, 0x50(%rsp)
    f9d5:      	subq	%rsi, %rax
    f9d8:      	jb	0x17392 <generic_kprobe_path+0xba72>
    f9de:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f9e4:      	ja	0x17392 <generic_kprobe_path+0xba72>
    f9ea:      	cmpl	%r15d, %r12d
    f9ed:      	jbe	0xf9f3 <generic_kprobe_path+0x40d3>
    f9ef:      	movb	$0x2f, (%rbx,%rax)
    f9f3:      	xorl	%edi, %edi
    f9f5:      	cmpl	%r15d, %r12d
    f9f8:      	seta	%dil
    f9fc:      	movzbl	%cl, %esi
    f9ff:      	addq	%rax, %rbx
    fa02:      	addq	%rbx, %rdi
    fa05:      	movl	$0x4, %eax
    fa0a:      	callq	*%rax
    fa0c:      	movq	%rbx, 0x48(%rsp)
    fa11:      	cmpl	%r15d, %r12d
    fa14:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    fa1a:      	movq	0x8(%rsp), %r12
    fa1f:      	movq	%r12, 0x30(%rsp)
    fa24:      	movq	0x38(%rsp), %rdx
    fa29:      	movq	0x40(%rsp), %r15
    fa2e:      	jmp	0xfa81 <generic_kprobe_path+0x4161>
    fa30:      	leaq	0x10(%r15), %rdx
    fa34:      	movl	$0x4, %eax
    fa39:      	movq	%rbp, %rdi
    fa3c:      	movl	$0x8, %esi
    fa41:      	callq	*%rax
    fa43:      	movq	0x40(%rsp), %rax
    fa48:      	cmpq	(%rsp), %rax
    fa4c:      	je	0x1738d <generic_kprobe_path+0xba6d>
    fa52:      	addq	$0x18, %r15
    fa56:      	movl	$0x4, %eax
    fa5b:      	leaq	0x30(%rsp), %rdi
    fa60:      	movl	$0x8, %esi
    fa65:      	movq	%r15, %rdx
    fa68:      	callq	*%rax
    fa6a:      	movq	(%rsp), %r15
    fa6e:      	movq	%r15, 0x40(%rsp)
    fa73:      	leaq	0x20(%r15), %rdx
    fa77:      	movq	%rdx, 0x38(%rsp)
    fa7c:      	movq	0x30(%rsp), %r12
    fa81:      	cmpq	0x18(%rsp), %r12
    fa86:      	jne	0xfa93 <generic_kprobe_path+0x4173>
    fa88:      	cmpq	0x20(%rsp), %rdx
    fa8d:      	je	0x1738d <generic_kprobe_path+0xba6d>
    fa93:      	movl	$0x4, %eax
    fa98:      	leaq	0x10(%rsp), %rdi
    fa9d:      	movl	$0x8, %esi
    faa2:      	callq	*%rax
    faa4:      	cmpq	0x10(%rsp), %r12
    faa9:      	je	0xfba1 <generic_kprobe_path+0x4281>
    faaf:      	leaq	0x18(%r12), %rbx
    fab4:      	movl	$0x4, %eax
    fab9:      	movq	%rbp, %rdi
    fabc:      	movl	$0x8, %esi
    fac1:      	movq	%rbx, %rdx
    fac4:      	callq	*%rax
    fac6:      	cmpq	%r12, (%rsp)
    faca:      	je	0xfba1 <generic_kprobe_path+0x4281>
    fad0:      	movl	$0x4, %eax
    fad5:      	leaq	0x8(%rsp), %rdi
    fada:      	movl	$0x8, %esi
    fadf:      	movq	%rbx, %rdx
    fae2:      	callq	*%rax
    fae4:      	addq	$0x20, %r12
    fae8:      	movl	$0x4, %eax
    faed:      	leaq	0x58(%rsp), %rdi
    faf2:      	movl	$0x10, %ecx
    faf7:      	movl	$0x10, %esi
    fafc:      	movq	%r12, %rdx
    faff:      	callq	*%rax
    fb01:      	movq	0x28(%rsp), %rbx
    fb06:      	movq	0x48(%rsp), %rax
    fb0b:      	movl	0x5c(%rsp), %r15d
    fb10:      	subq	%rbx, %rax
    fb13:      	movl	0x50(%rsp), %r12d
    fb18:      	movl	%r15d, %edx
    fb1b:      	subl	%r12d, %edx
    fb1e:      	movl	$0x0, %ecx
    fb23:      	cmovbl	%ecx, %edx
    fb26:      	addq	0x60(%rsp), %rdx
    fb2b:      	xorl	%esi, %esi
    fb2d:      	cmpl	%r15d, %r12d
    fb30:      	seta	%sil
    fb34:      	movl	%r15d, %ecx
    fb37:      	cmovbl	%r12d, %ecx
    fb3b:      	addl	%ecx, %esi
    fb3d:      	movl	%r12d, %edi
    fb40:      	subl	%esi, %edi
    fb42:      	movl	%edi, 0x50(%rsp)
    fb46:      	subq	%rsi, %rax
    fb49:      	jb	0x17392 <generic_kprobe_path+0xba72>
    fb4f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    fb55:      	ja	0x17392 <generic_kprobe_path+0xba72>
    fb5b:      	cmpl	%r15d, %r12d
    fb5e:      	jbe	0xfb64 <generic_kprobe_path+0x4244>
    fb60:      	movb	$0x2f, (%rbx,%rax)
    fb64:      	xorl	%edi, %edi
    fb66:      	cmpl	%r15d, %r12d
    fb69:      	seta	%dil
    fb6d:      	movzbl	%cl, %esi
    fb70:      	addq	%rax, %rbx
    fb73:      	addq	%rbx, %rdi
    fb76:      	movl	$0x4, %eax
    fb7b:      	callq	*%rax
    fb7d:      	movq	%rbx, 0x48(%rsp)
    fb82:      	cmpl	%r15d, %r12d
    fb85:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    fb8b:      	movq	0x8(%rsp), %r12
    fb90:      	movq	%r12, 0x30(%rsp)
    fb95:      	movq	0x38(%rsp), %rdx
    fb9a:      	movq	0x40(%rsp), %r15
    fb9f:      	jmp	0xfbf2 <generic_kprobe_path+0x42d2>
    fba1:      	leaq	0x10(%r15), %rdx
    fba5:      	movl	$0x4, %eax
    fbaa:      	movq	%rbp, %rdi
    fbad:      	movl	$0x8, %esi
    fbb2:      	callq	*%rax
    fbb4:      	movq	0x40(%rsp), %rax
    fbb9:      	cmpq	(%rsp), %rax
    fbbd:      	je	0x1738d <generic_kprobe_path+0xba6d>
    fbc3:      	addq	$0x18, %r15
    fbc7:      	movl	$0x4, %eax
    fbcc:      	leaq	0x30(%rsp), %rdi
    fbd1:      	movl	$0x8, %esi
    fbd6:      	movq	%r15, %rdx
    fbd9:      	callq	*%rax
    fbdb:      	movq	(%rsp), %r15
    fbdf:      	movq	%r15, 0x40(%rsp)
    fbe4:      	leaq	0x20(%r15), %rdx
    fbe8:      	movq	%rdx, 0x38(%rsp)
    fbed:      	movq	0x30(%rsp), %r12
    fbf2:      	cmpq	0x18(%rsp), %r12
    fbf7:      	jne	0xfc04 <generic_kprobe_path+0x42e4>
    fbf9:      	cmpq	0x20(%rsp), %rdx
    fbfe:      	je	0x1738d <generic_kprobe_path+0xba6d>
    fc04:      	movl	$0x4, %eax
    fc09:      	leaq	0x10(%rsp), %rdi
    fc0e:      	movl	$0x8, %esi
    fc13:      	callq	*%rax
    fc15:      	cmpq	0x10(%rsp), %r12
    fc1a:      	je	0xfd12 <generic_kprobe_path+0x43f2>
    fc20:      	leaq	0x18(%r12), %rbx
    fc25:      	movl	$0x4, %eax
    fc2a:      	movq	%rbp, %rdi
    fc2d:      	movl	$0x8, %esi
    fc32:      	movq	%rbx, %rdx
    fc35:      	callq	*%rax
    fc37:      	cmpq	%r12, (%rsp)
    fc3b:      	je	0xfd12 <generic_kprobe_path+0x43f2>
    fc41:      	movl	$0x4, %eax
    fc46:      	leaq	0x8(%rsp), %rdi
    fc4b:      	movl	$0x8, %esi
    fc50:      	movq	%rbx, %rdx
    fc53:      	callq	*%rax
    fc55:      	addq	$0x20, %r12
    fc59:      	movl	$0x4, %eax
    fc5e:      	leaq	0x58(%rsp), %rdi
    fc63:      	movl	$0x10, %ecx
    fc68:      	movl	$0x10, %esi
    fc6d:      	movq	%r12, %rdx
    fc70:      	callq	*%rax
    fc72:      	movq	0x28(%rsp), %rbx
    fc77:      	movq	0x48(%rsp), %rax
    fc7c:      	movl	0x5c(%rsp), %r15d
    fc81:      	subq	%rbx, %rax
    fc84:      	movl	0x50(%rsp), %r12d
    fc89:      	movl	%r15d, %edx
    fc8c:      	subl	%r12d, %edx
    fc8f:      	movl	$0x0, %ecx
    fc94:      	cmovbl	%ecx, %edx
    fc97:      	addq	0x60(%rsp), %rdx
    fc9c:      	xorl	%esi, %esi
    fc9e:      	cmpl	%r15d, %r12d
    fca1:      	seta	%sil
    fca5:      	movl	%r15d, %ecx
    fca8:      	cmovbl	%r12d, %ecx
    fcac:      	addl	%ecx, %esi
    fcae:      	movl	%r12d, %edi
    fcb1:      	subl	%esi, %edi
    fcb3:      	movl	%edi, 0x50(%rsp)
    fcb7:      	subq	%rsi, %rax
    fcba:      	jb	0x17392 <generic_kprobe_path+0xba72>
    fcc0:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    fcc6:      	ja	0x17392 <generic_kprobe_path+0xba72>
    fccc:      	cmpl	%r15d, %r12d
    fccf:      	jbe	0xfcd5 <generic_kprobe_path+0x43b5>
    fcd1:      	movb	$0x2f, (%rbx,%rax)
    fcd5:      	xorl	%edi, %edi
    fcd7:      	cmpl	%r15d, %r12d
    fcda:      	seta	%dil
    fcde:      	movzbl	%cl, %esi
    fce1:      	addq	%rax, %rbx
    fce4:      	addq	%rbx, %rdi
    fce7:      	movl	$0x4, %eax
    fcec:      	callq	*%rax
    fcee:      	movq	%rbx, 0x48(%rsp)
    fcf3:      	cmpl	%r15d, %r12d
    fcf6:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    fcfc:      	movq	0x8(%rsp), %r12
    fd01:      	movq	%r12, 0x30(%rsp)
    fd06:      	movq	0x38(%rsp), %rdx
    fd0b:      	movq	0x40(%rsp), %r15
    fd10:      	jmp	0xfd63 <generic_kprobe_path+0x4443>
    fd12:      	leaq	0x10(%r15), %rdx
    fd16:      	movl	$0x4, %eax
    fd1b:      	movq	%rbp, %rdi
    fd1e:      	movl	$0x8, %esi
    fd23:      	callq	*%rax
    fd25:      	movq	0x40(%rsp), %rax
    fd2a:      	cmpq	(%rsp), %rax
    fd2e:      	je	0x1738d <generic_kprobe_path+0xba6d>
    fd34:      	addq	$0x18, %r15
    fd38:      	movl	$0x4, %eax
    fd3d:      	leaq	0x30(%rsp), %rdi
    fd42:      	movl	$0x8, %esi
    fd47:      	movq	%r15, %rdx
    fd4a:      	callq	*%rax
    fd4c:      	movq	(%rsp), %r15
    fd50:      	movq	%r15, 0x40(%rsp)
    fd55:      	leaq	0x20(%r15), %rdx
    fd59:      	movq	%rdx, 0x38(%rsp)
    fd5e:      	movq	0x30(%rsp), %r12
    fd63:      	cmpq	0x18(%rsp), %r12
    fd68:      	jne	0xfd75 <generic_kprobe_path+0x4455>
    fd6a:      	cmpq	0x20(%rsp), %rdx
    fd6f:      	je	0x1738d <generic_kprobe_path+0xba6d>
    fd75:      	movl	$0x4, %eax
    fd7a:      	leaq	0x10(%rsp), %rdi
    fd7f:      	movl	$0x8, %esi
    fd84:      	callq	*%rax
    fd86:      	cmpq	0x10(%rsp), %r12
    fd8b:      	je	0xfe83 <generic_kprobe_path+0x4563>
    fd91:      	leaq	0x18(%r12), %rbx
    fd96:      	movl	$0x4, %eax
    fd9b:      	movq	%rbp, %rdi
    fd9e:      	movl	$0x8, %esi
    fda3:      	movq	%rbx, %rdx
    fda6:      	callq	*%rax
    fda8:      	cmpq	%r12, (%rsp)
    fdac:      	je	0xfe83 <generic_kprobe_path+0x4563>
    fdb2:      	movl	$0x4, %eax
    fdb7:      	leaq	0x8(%rsp), %rdi
    fdbc:      	movl	$0x8, %esi
    fdc1:      	movq	%rbx, %rdx
    fdc4:      	callq	*%rax
    fdc6:      	addq	$0x20, %r12
    fdca:      	movl	$0x4, %eax
    fdcf:      	leaq	0x58(%rsp), %rdi
    fdd4:      	movl	$0x10, %ecx
    fdd9:      	movl	$0x10, %esi
    fdde:      	movq	%r12, %rdx
    fde1:      	callq	*%rax
    fde3:      	movq	0x28(%rsp), %rbx
    fde8:      	movq	0x48(%rsp), %rax
    fded:      	movl	0x5c(%rsp), %r15d
    fdf2:      	subq	%rbx, %rax
    fdf5:      	movl	0x50(%rsp), %r12d
    fdfa:      	movl	%r15d, %edx
    fdfd:      	subl	%r12d, %edx
    fe00:      	movl	$0x0, %ecx
    fe05:      	cmovbl	%ecx, %edx
    fe08:      	addq	0x60(%rsp), %rdx
    fe0d:      	xorl	%esi, %esi
    fe0f:      	cmpl	%r15d, %r12d
    fe12:      	seta	%sil
    fe16:      	movl	%r15d, %ecx
    fe19:      	cmovbl	%r12d, %ecx
    fe1d:      	addl	%ecx, %esi
    fe1f:      	movl	%r12d, %edi
    fe22:      	subl	%esi, %edi
    fe24:      	movl	%edi, 0x50(%rsp)
    fe28:      	subq	%rsi, %rax
    fe2b:      	jb	0x17392 <generic_kprobe_path+0xba72>
    fe31:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    fe37:      	ja	0x17392 <generic_kprobe_path+0xba72>
    fe3d:      	cmpl	%r15d, %r12d
    fe40:      	jbe	0xfe46 <generic_kprobe_path+0x4526>
    fe42:      	movb	$0x2f, (%rbx,%rax)
    fe46:      	xorl	%edi, %edi
    fe48:      	cmpl	%r15d, %r12d
    fe4b:      	seta	%dil
    fe4f:      	movzbl	%cl, %esi
    fe52:      	addq	%rax, %rbx
    fe55:      	addq	%rbx, %rdi
    fe58:      	movl	$0x4, %eax
    fe5d:      	callq	*%rax
    fe5f:      	movq	%rbx, 0x48(%rsp)
    fe64:      	cmpl	%r15d, %r12d
    fe67:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    fe6d:      	movq	0x8(%rsp), %r12
    fe72:      	movq	%r12, 0x30(%rsp)
    fe77:      	movq	0x38(%rsp), %rdx
    fe7c:      	movq	0x40(%rsp), %r15
    fe81:      	jmp	0xfed4 <generic_kprobe_path+0x45b4>
    fe83:      	leaq	0x10(%r15), %rdx
    fe87:      	movl	$0x4, %eax
    fe8c:      	movq	%rbp, %rdi
    fe8f:      	movl	$0x8, %esi
    fe94:      	callq	*%rax
    fe96:      	movq	0x40(%rsp), %rax
    fe9b:      	cmpq	(%rsp), %rax
    fe9f:      	je	0x1738d <generic_kprobe_path+0xba6d>
    fea5:      	addq	$0x18, %r15
    fea9:      	movl	$0x4, %eax
    feae:      	leaq	0x30(%rsp), %rdi
    feb3:      	movl	$0x8, %esi
    feb8:      	movq	%r15, %rdx
    febb:      	callq	*%rax
    febd:      	movq	(%rsp), %r15
    fec1:      	movq	%r15, 0x40(%rsp)
    fec6:      	leaq	0x20(%r15), %rdx
    feca:      	movq	%rdx, 0x38(%rsp)
    fecf:      	movq	0x30(%rsp), %r12
    fed4:      	cmpq	0x18(%rsp), %r12
    fed9:      	jne	0xfee6 <generic_kprobe_path+0x45c6>
    fedb:      	cmpq	0x20(%rsp), %rdx
    fee0:      	je	0x1738d <generic_kprobe_path+0xba6d>
    fee6:      	movl	$0x4, %eax
    feeb:      	leaq	0x10(%rsp), %rdi
    fef0:      	movl	$0x8, %esi
    fef5:      	callq	*%rax
    fef7:      	cmpq	0x10(%rsp), %r12
    fefc:      	je	0xfff4 <generic_kprobe_path+0x46d4>
    ff02:      	leaq	0x18(%r12), %rbx
    ff07:      	movl	$0x4, %eax
    ff0c:      	movq	%rbp, %rdi
    ff0f:      	movl	$0x8, %esi
    ff14:      	movq	%rbx, %rdx
    ff17:      	callq	*%rax
    ff19:      	cmpq	%r12, (%rsp)
    ff1d:      	je	0xfff4 <generic_kprobe_path+0x46d4>
    ff23:      	movl	$0x4, %eax
    ff28:      	leaq	0x8(%rsp), %rdi
    ff2d:      	movl	$0x8, %esi
    ff32:      	movq	%rbx, %rdx
    ff35:      	callq	*%rax
    ff37:      	addq	$0x20, %r12
    ff3b:      	movl	$0x4, %eax
    ff40:      	leaq	0x58(%rsp), %rdi
    ff45:      	movl	$0x10, %ecx
    ff4a:      	movl	$0x10, %esi
    ff4f:      	movq	%r12, %rdx
    ff52:      	callq	*%rax
    ff54:      	movq	0x28(%rsp), %rbx
    ff59:      	movq	0x48(%rsp), %rax
    ff5e:      	movl	0x5c(%rsp), %r15d
    ff63:      	subq	%rbx, %rax
    ff66:      	movl	0x50(%rsp), %r12d
    ff6b:      	movl	%r15d, %edx
    ff6e:      	subl	%r12d, %edx
    ff71:      	movl	$0x0, %ecx
    ff76:      	cmovbl	%ecx, %edx
    ff79:      	addq	0x60(%rsp), %rdx
    ff7e:      	xorl	%esi, %esi
    ff80:      	cmpl	%r15d, %r12d
    ff83:      	seta	%sil
    ff87:      	movl	%r15d, %ecx
    ff8a:      	cmovbl	%r12d, %ecx
    ff8e:      	addl	%ecx, %esi
    ff90:      	movl	%r12d, %edi
    ff93:      	subl	%esi, %edi
    ff95:      	movl	%edi, 0x50(%rsp)
    ff99:      	subq	%rsi, %rax
    ff9c:      	jb	0x17392 <generic_kprobe_path+0xba72>
    ffa2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ffa8:      	ja	0x17392 <generic_kprobe_path+0xba72>
    ffae:      	cmpl	%r15d, %r12d
    ffb1:      	jbe	0xffb7 <generic_kprobe_path+0x4697>
    ffb3:      	movb	$0x2f, (%rbx,%rax)
    ffb7:      	xorl	%edi, %edi
    ffb9:      	cmpl	%r15d, %r12d
    ffbc:      	seta	%dil
    ffc0:      	movzbl	%cl, %esi
    ffc3:      	addq	%rax, %rbx
    ffc6:      	addq	%rbx, %rdi
    ffc9:      	movl	$0x4, %eax
    ffce:      	callq	*%rax
    ffd0:      	movq	%rbx, 0x48(%rsp)
    ffd5:      	cmpl	%r15d, %r12d
    ffd8:      	jbe	0x17392 <generic_kprobe_path+0xba72>
    ffde:      	movq	0x8(%rsp), %r12
    ffe3:      	movq	%r12, 0x30(%rsp)
    ffe8:      	movq	0x38(%rsp), %rdx
    ffed:      	movq	0x40(%rsp), %r15
    fff2:      	jmp	0x10045 <generic_kprobe_path+0x4725>
    fff4:      	leaq	0x10(%r15), %rdx
    fff8:      	movl	$0x4, %eax
    fffd:      	movq	%rbp, %rdi
   10000:      	movl	$0x8, %esi
   10005:      	callq	*%rax
   10007:      	movq	0x40(%rsp), %rax
   1000c:      	cmpq	(%rsp), %rax
   10010:      	je	0x1738d <generic_kprobe_path+0xba6d>
   10016:      	addq	$0x18, %r15
   1001a:      	movl	$0x4, %eax
   1001f:      	leaq	0x30(%rsp), %rdi
   10024:      	movl	$0x8, %esi
   10029:      	movq	%r15, %rdx
   1002c:      	callq	*%rax
   1002e:      	movq	(%rsp), %r15
   10032:      	movq	%r15, 0x40(%rsp)
   10037:      	leaq	0x20(%r15), %rdx
   1003b:      	movq	%rdx, 0x38(%rsp)
   10040:      	movq	0x30(%rsp), %r12
   10045:      	cmpq	0x18(%rsp), %r12
   1004a:      	jne	0x10057 <generic_kprobe_path+0x4737>
   1004c:      	cmpq	0x20(%rsp), %rdx
   10051:      	je	0x1738d <generic_kprobe_path+0xba6d>
   10057:      	movl	$0x4, %eax
   1005c:      	leaq	0x10(%rsp), %rdi
   10061:      	movl	$0x8, %esi
   10066:      	callq	*%rax
   10068:      	cmpq	0x10(%rsp), %r12
   1006d:      	je	0x10165 <generic_kprobe_path+0x4845>
   10073:      	leaq	0x18(%r12), %rbx
   10078:      	movl	$0x4, %eax
   1007d:      	movq	%rbp, %rdi
   10080:      	movl	$0x8, %esi
   10085:      	movq	%rbx, %rdx
   10088:      	callq	*%rax
   1008a:      	cmpq	%r12, (%rsp)
   1008e:      	je	0x10165 <generic_kprobe_path+0x4845>
   10094:      	movl	$0x4, %eax
   10099:      	leaq	0x8(%rsp), %rdi
   1009e:      	movl	$0x8, %esi
   100a3:      	movq	%rbx, %rdx
   100a6:      	callq	*%rax
   100a8:      	addq	$0x20, %r12
   100ac:      	movl	$0x4, %eax
   100b1:      	leaq	0x58(%rsp), %rdi
   100b6:      	movl	$0x10, %ecx
   100bb:      	movl	$0x10, %esi
   100c0:      	movq	%r12, %rdx
   100c3:      	callq	*%rax
   100c5:      	movq	0x28(%rsp), %rbx
   100ca:      	movq	0x48(%rsp), %rax
   100cf:      	movl	0x5c(%rsp), %r15d
   100d4:      	subq	%rbx, %rax
   100d7:      	movl	0x50(%rsp), %r12d
   100dc:      	movl	%r15d, %edx
   100df:      	subl	%r12d, %edx
   100e2:      	movl	$0x0, %ecx
   100e7:      	cmovbl	%ecx, %edx
   100ea:      	addq	0x60(%rsp), %rdx
   100ef:      	xorl	%esi, %esi
   100f1:      	cmpl	%r15d, %r12d
   100f4:      	seta	%sil
   100f8:      	movl	%r15d, %ecx
   100fb:      	cmovbl	%r12d, %ecx
   100ff:      	addl	%ecx, %esi
   10101:      	movl	%r12d, %edi
   10104:      	subl	%esi, %edi
   10106:      	movl	%edi, 0x50(%rsp)
   1010a:      	subq	%rsi, %rax
   1010d:      	jb	0x17392 <generic_kprobe_path+0xba72>
   10113:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10119:      	ja	0x17392 <generic_kprobe_path+0xba72>
   1011f:      	cmpl	%r15d, %r12d
   10122:      	jbe	0x10128 <generic_kprobe_path+0x4808>
   10124:      	movb	$0x2f, (%rbx,%rax)
   10128:      	xorl	%edi, %edi
   1012a:      	cmpl	%r15d, %r12d
   1012d:      	seta	%dil
   10131:      	movzbl	%cl, %esi
   10134:      	addq	%rax, %rbx
   10137:      	addq	%rbx, %rdi
   1013a:      	movl	$0x4, %eax
   1013f:      	callq	*%rax
   10141:      	movq	%rbx, 0x48(%rsp)
   10146:      	cmpl	%r15d, %r12d
   10149:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   1014f:      	movq	0x8(%rsp), %r12
   10154:      	movq	%r12, 0x30(%rsp)
   10159:      	movq	0x38(%rsp), %rdx
   1015e:      	movq	0x40(%rsp), %r15
   10163:      	jmp	0x101b6 <generic_kprobe_path+0x4896>
   10165:      	leaq	0x10(%r15), %rdx
   10169:      	movl	$0x4, %eax
   1016e:      	movq	%rbp, %rdi
   10171:      	movl	$0x8, %esi
   10176:      	callq	*%rax
   10178:      	movq	0x40(%rsp), %rax
   1017d:      	cmpq	(%rsp), %rax
   10181:      	je	0x1738d <generic_kprobe_path+0xba6d>
   10187:      	addq	$0x18, %r15
   1018b:      	movl	$0x4, %eax
   10190:      	leaq	0x30(%rsp), %rdi
   10195:      	movl	$0x8, %esi
   1019a:      	movq	%r15, %rdx
   1019d:      	callq	*%rax
   1019f:      	movq	(%rsp), %r15
   101a3:      	movq	%r15, 0x40(%rsp)
   101a8:      	leaq	0x20(%r15), %rdx
   101ac:      	movq	%rdx, 0x38(%rsp)
   101b1:      	movq	0x30(%rsp), %r12
   101b6:      	cmpq	0x18(%rsp), %r12
   101bb:      	jne	0x101c8 <generic_kprobe_path+0x48a8>
   101bd:      	cmpq	0x20(%rsp), %rdx
   101c2:      	je	0x1738d <generic_kprobe_path+0xba6d>
   101c8:      	movl	$0x4, %eax
   101cd:      	leaq	0x10(%rsp), %rdi
   101d2:      	movl	$0x8, %esi
   101d7:      	callq	*%rax
   101d9:      	cmpq	0x10(%rsp), %r12
   101de:      	je	0x102d6 <generic_kprobe_path+0x49b6>
   101e4:      	leaq	0x18(%r12), %rbx
   101e9:      	movl	$0x4, %eax
   101ee:      	movq	%rbp, %rdi
   101f1:      	movl	$0x8, %esi
   101f6:      	movq	%rbx, %rdx
   101f9:      	callq	*%rax
   101fb:      	cmpq	%r12, (%rsp)
   101ff:      	je	0x102d6 <generic_kprobe_path+0x49b6>
   10205:      	movl	$0x4, %eax
   1020a:      	leaq	0x8(%rsp), %rdi
   1020f:      	movl	$0x8, %esi
   10214:      	movq	%rbx, %rdx
   10217:      	callq	*%rax
   10219:      	addq	$0x20, %r12
   1021d:      	movl	$0x4, %eax
   10222:      	leaq	0x58(%rsp), %rdi
   10227:      	movl	$0x10, %ecx
   1022c:      	movl	$0x10, %esi
   10231:      	movq	%r12, %rdx
   10234:      	callq	*%rax
   10236:      	movq	0x28(%rsp), %rbx
   1023b:      	movq	0x48(%rsp), %rax
   10240:      	movl	0x5c(%rsp), %r15d
   10245:      	subq	%rbx, %rax
   10248:      	movl	0x50(%rsp), %r12d
   1024d:      	movl	%r15d, %edx
   10250:      	subl	%r12d, %edx
   10253:      	movl	$0x0, %ecx
   10258:      	cmovbl	%ecx, %edx
   1025b:      	addq	0x60(%rsp), %rdx
   10260:      	xorl	%esi, %esi
   10262:      	cmpl	%r15d, %r12d
   10265:      	seta	%sil
   10269:      	movl	%r15d, %ecx
   1026c:      	cmovbl	%r12d, %ecx
   10270:      	addl	%ecx, %esi
   10272:      	movl	%r12d, %edi
   10275:      	subl	%esi, %edi
   10277:      	movl	%edi, 0x50(%rsp)
   1027b:      	subq	%rsi, %rax
   1027e:      	jb	0x17392 <generic_kprobe_path+0xba72>
   10284:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1028a:      	ja	0x17392 <generic_kprobe_path+0xba72>
   10290:      	cmpl	%r15d, %r12d
   10293:      	jbe	0x10299 <generic_kprobe_path+0x4979>
   10295:      	movb	$0x2f, (%rbx,%rax)
   10299:      	xorl	%edi, %edi
   1029b:      	cmpl	%r15d, %r12d
   1029e:      	seta	%dil
   102a2:      	movzbl	%cl, %esi
   102a5:      	addq	%rax, %rbx
   102a8:      	addq	%rbx, %rdi
   102ab:      	movl	$0x4, %eax
   102b0:      	callq	*%rax
   102b2:      	movq	%rbx, 0x48(%rsp)
   102b7:      	cmpl	%r15d, %r12d
   102ba:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   102c0:      	movq	0x8(%rsp), %r12
   102c5:      	movq	%r12, 0x30(%rsp)
   102ca:      	movq	0x38(%rsp), %rdx
   102cf:      	movq	0x40(%rsp), %r15
   102d4:      	jmp	0x10327 <generic_kprobe_path+0x4a07>
   102d6:      	leaq	0x10(%r15), %rdx
   102da:      	movl	$0x4, %eax
   102df:      	movq	%rbp, %rdi
   102e2:      	movl	$0x8, %esi
   102e7:      	callq	*%rax
   102e9:      	movq	0x40(%rsp), %rax
   102ee:      	cmpq	(%rsp), %rax
   102f2:      	je	0x1738d <generic_kprobe_path+0xba6d>
   102f8:      	addq	$0x18, %r15
   102fc:      	movl	$0x4, %eax
   10301:      	leaq	0x30(%rsp), %rdi
   10306:      	movl	$0x8, %esi
   1030b:      	movq	%r15, %rdx
   1030e:      	callq	*%rax
   10310:      	movq	(%rsp), %r15
   10314:      	movq	%r15, 0x40(%rsp)
   10319:      	leaq	0x20(%r15), %rdx
   1031d:      	movq	%rdx, 0x38(%rsp)
   10322:      	movq	0x30(%rsp), %r12
   10327:      	cmpq	0x18(%rsp), %r12
   1032c:      	jne	0x10339 <generic_kprobe_path+0x4a19>
   1032e:      	cmpq	0x20(%rsp), %rdx
   10333:      	je	0x1738d <generic_kprobe_path+0xba6d>
   10339:      	movl	$0x4, %eax
   1033e:      	leaq	0x10(%rsp), %rdi
   10343:      	movl	$0x8, %esi
   10348:      	callq	*%rax
   1034a:      	cmpq	0x10(%rsp), %r12
   1034f:      	je	0x10447 <generic_kprobe_path+0x4b27>
   10355:      	leaq	0x18(%r12), %rbx
   1035a:      	movl	$0x4, %eax
   1035f:      	movq	%rbp, %rdi
   10362:      	movl	$0x8, %esi
   10367:      	movq	%rbx, %rdx
   1036a:      	callq	*%rax
   1036c:      	cmpq	%r12, (%rsp)
   10370:      	je	0x10447 <generic_kprobe_path+0x4b27>
   10376:      	movl	$0x4, %eax
   1037b:      	leaq	0x8(%rsp), %rdi
   10380:      	movl	$0x8, %esi
   10385:      	movq	%rbx, %rdx
   10388:      	callq	*%rax
   1038a:      	addq	$0x20, %r12
   1038e:      	movl	$0x4, %eax
   10393:      	leaq	0x58(%rsp), %rdi
   10398:      	movl	$0x10, %ecx
   1039d:      	movl	$0x10, %esi
   103a2:      	movq	%r12, %rdx
   103a5:      	callq	*%rax
   103a7:      	movq	0x28(%rsp), %rbx
   103ac:      	movq	0x48(%rsp), %rax
   103b1:      	movl	0x5c(%rsp), %r15d
   103b6:      	subq	%rbx, %rax
   103b9:      	movl	0x50(%rsp), %r12d
   103be:      	movl	%r15d, %edx
   103c1:      	subl	%r12d, %edx
   103c4:      	movl	$0x0, %ecx
   103c9:      	cmovbl	%ecx, %edx
   103cc:      	addq	0x60(%rsp), %rdx
   103d1:      	xorl	%esi, %esi
   103d3:      	cmpl	%r15d, %r12d
   103d6:      	seta	%sil
   103da:      	movl	%r15d, %ecx
   103dd:      	cmovbl	%r12d, %ecx
   103e1:      	addl	%ecx, %esi
   103e3:      	movl	%r12d, %edi
   103e6:      	subl	%esi, %edi
   103e8:      	movl	%edi, 0x50(%rsp)
   103ec:      	subq	%rsi, %rax
   103ef:      	jb	0x17392 <generic_kprobe_path+0xba72>
   103f5:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   103fb:      	ja	0x17392 <generic_kprobe_path+0xba72>
   10401:      	cmpl	%r15d, %r12d
   10404:      	jbe	0x1040a <generic_kprobe_path+0x4aea>
   10406:      	movb	$0x2f, (%rbx,%rax)
   1040a:      	xorl	%edi, %edi
   1040c:      	cmpl	%r15d, %r12d
   1040f:      	seta	%dil
   10413:      	movzbl	%cl, %esi
   10416:      	addq	%rax, %rbx
   10419:      	addq	%rbx, %rdi
   1041c:      	movl	$0x4, %eax
   10421:      	callq	*%rax
   10423:      	movq	%rbx, 0x48(%rsp)
   10428:      	cmpl	%r15d, %r12d
   1042b:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   10431:      	movq	0x8(%rsp), %r12
   10436:      	movq	%r12, 0x30(%rsp)
   1043b:      	movq	0x38(%rsp), %rdx
   10440:      	movq	0x40(%rsp), %r15
   10445:      	jmp	0x10498 <generic_kprobe_path+0x4b78>
   10447:      	leaq	0x10(%r15), %rdx
   1044b:      	movl	$0x4, %eax
   10450:      	movq	%rbp, %rdi
   10453:      	movl	$0x8, %esi
   10458:      	callq	*%rax
   1045a:      	movq	0x40(%rsp), %rax
   1045f:      	cmpq	(%rsp), %rax
   10463:      	je	0x1738d <generic_kprobe_path+0xba6d>
   10469:      	addq	$0x18, %r15
   1046d:      	movl	$0x4, %eax
   10472:      	leaq	0x30(%rsp), %rdi
   10477:      	movl	$0x8, %esi
   1047c:      	movq	%r15, %rdx
   1047f:      	callq	*%rax
   10481:      	movq	(%rsp), %r15
   10485:      	movq	%r15, 0x40(%rsp)
   1048a:      	leaq	0x20(%r15), %rdx
   1048e:      	movq	%rdx, 0x38(%rsp)
   10493:      	movq	0x30(%rsp), %r12
   10498:      	cmpq	0x18(%rsp), %r12
   1049d:      	jne	0x104aa <generic_kprobe_path+0x4b8a>
   1049f:      	cmpq	0x20(%rsp), %rdx
   104a4:      	je	0x1738d <generic_kprobe_path+0xba6d>
   104aa:      	movl	$0x4, %eax
   104af:      	leaq	0x10(%rsp), %rdi
   104b4:      	movl	$0x8, %esi
   104b9:      	callq	*%rax
   104bb:      	cmpq	0x10(%rsp), %r12
   104c0:      	je	0x105b8 <generic_kprobe_path+0x4c98>
   104c6:      	leaq	0x18(%r12), %rbx
   104cb:      	movl	$0x4, %eax
   104d0:      	movq	%rbp, %rdi
   104d3:      	movl	$0x8, %esi
   104d8:      	movq	%rbx, %rdx
   104db:      	callq	*%rax
   104dd:      	cmpq	%r12, (%rsp)
   104e1:      	je	0x105b8 <generic_kprobe_path+0x4c98>
   104e7:      	movl	$0x4, %eax
   104ec:      	leaq	0x8(%rsp), %rdi
   104f1:      	movl	$0x8, %esi
   104f6:      	movq	%rbx, %rdx
   104f9:      	callq	*%rax
   104fb:      	addq	$0x20, %r12
   104ff:      	movl	$0x4, %eax
   10504:      	leaq	0x58(%rsp), %rdi
   10509:      	movl	$0x10, %ecx
   1050e:      	movl	$0x10, %esi
   10513:      	movq	%r12, %rdx
   10516:      	callq	*%rax
   10518:      	movq	0x28(%rsp), %rbx
   1051d:      	movq	0x48(%rsp), %rax
   10522:      	movl	0x5c(%rsp), %r15d
   10527:      	subq	%rbx, %rax
   1052a:      	movl	0x50(%rsp), %r12d
   1052f:      	movl	%r15d, %edx
   10532:      	subl	%r12d, %edx
   10535:      	movl	$0x0, %ecx
   1053a:      	cmovbl	%ecx, %edx
   1053d:      	addq	0x60(%rsp), %rdx
   10542:      	xorl	%esi, %esi
   10544:      	cmpl	%r15d, %r12d
   10547:      	seta	%sil
   1054b:      	movl	%r15d, %ecx
   1054e:      	cmovbl	%r12d, %ecx
   10552:      	addl	%ecx, %esi
   10554:      	movl	%r12d, %edi
   10557:      	subl	%esi, %edi
   10559:      	movl	%edi, 0x50(%rsp)
   1055d:      	subq	%rsi, %rax
   10560:      	jb	0x17392 <generic_kprobe_path+0xba72>
   10566:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1056c:      	ja	0x17392 <generic_kprobe_path+0xba72>
   10572:      	cmpl	%r15d, %r12d
   10575:      	jbe	0x1057b <generic_kprobe_path+0x4c5b>
   10577:      	movb	$0x2f, (%rbx,%rax)
   1057b:      	xorl	%edi, %edi
   1057d:      	cmpl	%r15d, %r12d
   10580:      	seta	%dil
   10584:      	movzbl	%cl, %esi
   10587:      	addq	%rax, %rbx
   1058a:      	addq	%rbx, %rdi
   1058d:      	movl	$0x4, %eax
   10592:      	callq	*%rax
   10594:      	movq	%rbx, 0x48(%rsp)
   10599:      	cmpl	%r15d, %r12d
   1059c:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   105a2:      	movq	0x8(%rsp), %r12
   105a7:      	movq	%r12, 0x30(%rsp)
   105ac:      	movq	0x38(%rsp), %rdx
   105b1:      	movq	0x40(%rsp), %r15
   105b6:      	jmp	0x10609 <generic_kprobe_path+0x4ce9>
   105b8:      	leaq	0x10(%r15), %rdx
   105bc:      	movl	$0x4, %eax
   105c1:      	movq	%rbp, %rdi
   105c4:      	movl	$0x8, %esi
   105c9:      	callq	*%rax
   105cb:      	movq	0x40(%rsp), %rax
   105d0:      	cmpq	(%rsp), %rax
   105d4:      	je	0x1738d <generic_kprobe_path+0xba6d>
   105da:      	addq	$0x18, %r15
   105de:      	movl	$0x4, %eax
   105e3:      	leaq	0x30(%rsp), %rdi
   105e8:      	movl	$0x8, %esi
   105ed:      	movq	%r15, %rdx
   105f0:      	callq	*%rax
   105f2:      	movq	(%rsp), %r15
   105f6:      	movq	%r15, 0x40(%rsp)
   105fb:      	leaq	0x20(%r15), %rdx
   105ff:      	movq	%rdx, 0x38(%rsp)
   10604:      	movq	0x30(%rsp), %r12
   10609:      	cmpq	0x18(%rsp), %r12
   1060e:      	jne	0x1061b <generic_kprobe_path+0x4cfb>
   10610:      	cmpq	0x20(%rsp), %rdx
   10615:      	je	0x1738d <generic_kprobe_path+0xba6d>
   1061b:      	movl	$0x4, %eax
   10620:      	leaq	0x10(%rsp), %rdi
   10625:      	movl	$0x8, %esi
   1062a:      	callq	*%rax
   1062c:      	cmpq	0x10(%rsp), %r12
   10631:      	je	0x10729 <generic_kprobe_path+0x4e09>
   10637:      	leaq	0x18(%r12), %rbx
   1063c:      	movl	$0x4, %eax
   10641:      	movq	%rbp, %rdi
   10644:      	movl	$0x8, %esi
   10649:      	movq	%rbx, %rdx
   1064c:      	callq	*%rax
   1064e:      	cmpq	%r12, (%rsp)
   10652:      	je	0x10729 <generic_kprobe_path+0x4e09>
   10658:      	movl	$0x4, %eax
   1065d:      	leaq	0x8(%rsp), %rdi
   10662:      	movl	$0x8, %esi
   10667:      	movq	%rbx, %rdx
   1066a:      	callq	*%rax
   1066c:      	addq	$0x20, %r12
   10670:      	movl	$0x4, %eax
   10675:      	leaq	0x58(%rsp), %rdi
   1067a:      	movl	$0x10, %ecx
   1067f:      	movl	$0x10, %esi
   10684:      	movq	%r12, %rdx
   10687:      	callq	*%rax
   10689:      	movq	0x28(%rsp), %rbx
   1068e:      	movq	0x48(%rsp), %rax
   10693:      	movl	0x5c(%rsp), %r15d
   10698:      	subq	%rbx, %rax
   1069b:      	movl	0x50(%rsp), %r12d
   106a0:      	movl	%r15d, %edx
   106a3:      	subl	%r12d, %edx
   106a6:      	movl	$0x0, %ecx
   106ab:      	cmovbl	%ecx, %edx
   106ae:      	addq	0x60(%rsp), %rdx
   106b3:      	xorl	%esi, %esi
   106b5:      	cmpl	%r15d, %r12d
   106b8:      	seta	%sil
   106bc:      	movl	%r15d, %ecx
   106bf:      	cmovbl	%r12d, %ecx
   106c3:      	addl	%ecx, %esi
   106c5:      	movl	%r12d, %edi
   106c8:      	subl	%esi, %edi
   106ca:      	movl	%edi, 0x50(%rsp)
   106ce:      	subq	%rsi, %rax
   106d1:      	jb	0x17392 <generic_kprobe_path+0xba72>
   106d7:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   106dd:      	ja	0x17392 <generic_kprobe_path+0xba72>
   106e3:      	cmpl	%r15d, %r12d
   106e6:      	jbe	0x106ec <generic_kprobe_path+0x4dcc>
   106e8:      	movb	$0x2f, (%rbx,%rax)
   106ec:      	xorl	%edi, %edi
   106ee:      	cmpl	%r15d, %r12d
   106f1:      	seta	%dil
   106f5:      	movzbl	%cl, %esi
   106f8:      	addq	%rax, %rbx
   106fb:      	addq	%rbx, %rdi
   106fe:      	movl	$0x4, %eax
   10703:      	callq	*%rax
   10705:      	movq	%rbx, 0x48(%rsp)
   1070a:      	cmpl	%r15d, %r12d
   1070d:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   10713:      	movq	0x8(%rsp), %r12
   10718:      	movq	%r12, 0x30(%rsp)
   1071d:      	movq	0x38(%rsp), %rdx
   10722:      	movq	0x40(%rsp), %r15
   10727:      	jmp	0x1077a <generic_kprobe_path+0x4e5a>
   10729:      	leaq	0x10(%r15), %rdx
   1072d:      	movl	$0x4, %eax
   10732:      	movq	%rbp, %rdi
   10735:      	movl	$0x8, %esi
   1073a:      	callq	*%rax
   1073c:      	movq	0x40(%rsp), %rax
   10741:      	cmpq	(%rsp), %rax
   10745:      	je	0x1738d <generic_kprobe_path+0xba6d>
   1074b:      	addq	$0x18, %r15
   1074f:      	movl	$0x4, %eax
   10754:      	leaq	0x30(%rsp), %rdi
   10759:      	movl	$0x8, %esi
   1075e:      	movq	%r15, %rdx
   10761:      	callq	*%rax
   10763:      	movq	(%rsp), %r15
   10767:      	movq	%r15, 0x40(%rsp)
   1076c:      	leaq	0x20(%r15), %rdx
   10770:      	movq	%rdx, 0x38(%rsp)
   10775:      	movq	0x30(%rsp), %r12
   1077a:      	cmpq	0x18(%rsp), %r12
   1077f:      	jne	0x1078c <generic_kprobe_path+0x4e6c>
   10781:      	cmpq	0x20(%rsp), %rdx
   10786:      	je	0x1738d <generic_kprobe_path+0xba6d>
   1078c:      	movl	$0x4, %eax
   10791:      	leaq	0x10(%rsp), %rdi
   10796:      	movl	$0x8, %esi
   1079b:      	callq	*%rax
   1079d:      	cmpq	0x10(%rsp), %r12
   107a2:      	je	0x1089a <generic_kprobe_path+0x4f7a>
   107a8:      	leaq	0x18(%r12), %rbx
   107ad:      	movl	$0x4, %eax
   107b2:      	movq	%rbp, %rdi
   107b5:      	movl	$0x8, %esi
   107ba:      	movq	%rbx, %rdx
   107bd:      	callq	*%rax
   107bf:      	cmpq	%r12, (%rsp)
   107c3:      	je	0x1089a <generic_kprobe_path+0x4f7a>
   107c9:      	movl	$0x4, %eax
   107ce:      	leaq	0x8(%rsp), %rdi
   107d3:      	movl	$0x8, %esi
   107d8:      	movq	%rbx, %rdx
   107db:      	callq	*%rax
   107dd:      	addq	$0x20, %r12
   107e1:      	movl	$0x4, %eax
   107e6:      	leaq	0x58(%rsp), %rdi
   107eb:      	movl	$0x10, %ecx
   107f0:      	movl	$0x10, %esi
   107f5:      	movq	%r12, %rdx
   107f8:      	callq	*%rax
   107fa:      	movq	0x28(%rsp), %rbx
   107ff:      	movq	0x48(%rsp), %rax
   10804:      	movl	0x5c(%rsp), %r15d
   10809:      	subq	%rbx, %rax
   1080c:      	movl	0x50(%rsp), %r12d
   10811:      	movl	%r15d, %edx
   10814:      	subl	%r12d, %edx
   10817:      	movl	$0x0, %ecx
   1081c:      	cmovbl	%ecx, %edx
   1081f:      	addq	0x60(%rsp), %rdx
   10824:      	xorl	%esi, %esi
   10826:      	cmpl	%r15d, %r12d
   10829:      	seta	%sil
   1082d:      	movl	%r15d, %ecx
   10830:      	cmovbl	%r12d, %ecx
   10834:      	addl	%ecx, %esi
   10836:      	movl	%r12d, %edi
   10839:      	subl	%esi, %edi
   1083b:      	movl	%edi, 0x50(%rsp)
   1083f:      	subq	%rsi, %rax
   10842:      	jb	0x17392 <generic_kprobe_path+0xba72>
   10848:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1084e:      	ja	0x17392 <generic_kprobe_path+0xba72>
   10854:      	cmpl	%r15d, %r12d
   10857:      	jbe	0x1085d <generic_kprobe_path+0x4f3d>
   10859:      	movb	$0x2f, (%rbx,%rax)
   1085d:      	xorl	%edi, %edi
   1085f:      	cmpl	%r15d, %r12d
   10862:      	seta	%dil
   10866:      	movzbl	%cl, %esi
   10869:      	addq	%rax, %rbx
   1086c:      	addq	%rbx, %rdi
   1086f:      	movl	$0x4, %eax
   10874:      	callq	*%rax
   10876:      	movq	%rbx, 0x48(%rsp)
   1087b:      	cmpl	%r15d, %r12d
   1087e:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   10884:      	movq	0x8(%rsp), %r12
   10889:      	movq	%r12, 0x30(%rsp)
   1088e:      	movq	0x38(%rsp), %rdx
   10893:      	movq	0x40(%rsp), %r15
   10898:      	jmp	0x108eb <generic_kprobe_path+0x4fcb>
   1089a:      	leaq	0x10(%r15), %rdx
   1089e:      	movl	$0x4, %eax
   108a3:      	movq	%rbp, %rdi
   108a6:      	movl	$0x8, %esi
   108ab:      	callq	*%rax
   108ad:      	movq	0x40(%rsp), %rax
   108b2:      	cmpq	(%rsp), %rax
   108b6:      	je	0x1738d <generic_kprobe_path+0xba6d>
   108bc:      	addq	$0x18, %r15
   108c0:      	movl	$0x4, %eax
   108c5:      	leaq	0x30(%rsp), %rdi
   108ca:      	movl	$0x8, %esi
   108cf:      	movq	%r15, %rdx
   108d2:      	callq	*%rax
   108d4:      	movq	(%rsp), %r15
   108d8:      	movq	%r15, 0x40(%rsp)
   108dd:      	leaq	0x20(%r15), %rdx
   108e1:      	movq	%rdx, 0x38(%rsp)
   108e6:      	movq	0x30(%rsp), %r12
   108eb:      	cmpq	0x18(%rsp), %r12
   108f0:      	jne	0x108fd <generic_kprobe_path+0x4fdd>
   108f2:      	cmpq	0x20(%rsp), %rdx
   108f7:      	je	0x1738d <generic_kprobe_path+0xba6d>
   108fd:      	movl	$0x4, %eax
   10902:      	leaq	0x10(%rsp), %rdi
   10907:      	movl	$0x8, %esi
   1090c:      	callq	*%rax
   1090e:      	cmpq	0x10(%rsp), %r12
   10913:      	je	0x10a0b <generic_kprobe_path+0x50eb>
   10919:      	leaq	0x18(%r12), %rbx
   1091e:      	movl	$0x4, %eax
   10923:      	movq	%rbp, %rdi
   10926:      	movl	$0x8, %esi
   1092b:      	movq	%rbx, %rdx
   1092e:      	callq	*%rax
   10930:      	cmpq	%r12, (%rsp)
   10934:      	je	0x10a0b <generic_kprobe_path+0x50eb>
   1093a:      	movl	$0x4, %eax
   1093f:      	leaq	0x8(%rsp), %rdi
   10944:      	movl	$0x8, %esi
   10949:      	movq	%rbx, %rdx
   1094c:      	callq	*%rax
   1094e:      	addq	$0x20, %r12
   10952:      	movl	$0x4, %eax
   10957:      	leaq	0x58(%rsp), %rdi
   1095c:      	movl	$0x10, %ecx
   10961:      	movl	$0x10, %esi
   10966:      	movq	%r12, %rdx
   10969:      	callq	*%rax
   1096b:      	movq	0x28(%rsp), %rbx
   10970:      	movq	0x48(%rsp), %rax
   10975:      	movl	0x5c(%rsp), %r15d
   1097a:      	subq	%rbx, %rax
   1097d:      	movl	0x50(%rsp), %r12d
   10982:      	movl	%r15d, %edx
   10985:      	subl	%r12d, %edx
   10988:      	movl	$0x0, %ecx
   1098d:      	cmovbl	%ecx, %edx
   10990:      	addq	0x60(%rsp), %rdx
   10995:      	xorl	%esi, %esi
   10997:      	cmpl	%r15d, %r12d
   1099a:      	seta	%sil
   1099e:      	movl	%r15d, %ecx
   109a1:      	cmovbl	%r12d, %ecx
   109a5:      	addl	%ecx, %esi
   109a7:      	movl	%r12d, %edi
   109aa:      	subl	%esi, %edi
   109ac:      	movl	%edi, 0x50(%rsp)
   109b0:      	subq	%rsi, %rax
   109b3:      	jb	0x17392 <generic_kprobe_path+0xba72>
   109b9:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   109bf:      	ja	0x17392 <generic_kprobe_path+0xba72>
   109c5:      	cmpl	%r15d, %r12d
   109c8:      	jbe	0x109ce <generic_kprobe_path+0x50ae>
   109ca:      	movb	$0x2f, (%rbx,%rax)
   109ce:      	xorl	%edi, %edi
   109d0:      	cmpl	%r15d, %r12d
   109d3:      	seta	%dil
   109d7:      	movzbl	%cl, %esi
   109da:      	addq	%rax, %rbx
   109dd:      	addq	%rbx, %rdi
   109e0:      	movl	$0x4, %eax
   109e5:      	callq	*%rax
   109e7:      	movq	%rbx, 0x48(%rsp)
   109ec:      	cmpl	%r15d, %r12d
   109ef:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   109f5:      	movq	0x8(%rsp), %r12
   109fa:      	movq	%r12, 0x30(%rsp)
   109ff:      	movq	0x38(%rsp), %rdx
   10a04:      	movq	0x40(%rsp), %r15
   10a09:      	jmp	0x10a5c <generic_kprobe_path+0x513c>
   10a0b:      	leaq	0x10(%r15), %rdx
   10a0f:      	movl	$0x4, %eax
   10a14:      	movq	%rbp, %rdi
   10a17:      	movl	$0x8, %esi
   10a1c:      	callq	*%rax
   10a1e:      	movq	0x40(%rsp), %rax
   10a23:      	cmpq	(%rsp), %rax
   10a27:      	je	0x1738d <generic_kprobe_path+0xba6d>
   10a2d:      	addq	$0x18, %r15
   10a31:      	movl	$0x4, %eax
   10a36:      	leaq	0x30(%rsp), %rdi
   10a3b:      	movl	$0x8, %esi
   10a40:      	movq	%r15, %rdx
   10a43:      	callq	*%rax
   10a45:      	movq	(%rsp), %r15
   10a49:      	movq	%r15, 0x40(%rsp)
   10a4e:      	leaq	0x20(%r15), %rdx
   10a52:      	movq	%rdx, 0x38(%rsp)
   10a57:      	movq	0x30(%rsp), %r12
   10a5c:      	cmpq	0x18(%rsp), %r12
   10a61:      	jne	0x10a6e <generic_kprobe_path+0x514e>
   10a63:      	cmpq	0x20(%rsp), %rdx
   10a68:      	je	0x1738d <generic_kprobe_path+0xba6d>
   10a6e:      	movl	$0x4, %eax
   10a73:      	leaq	0x10(%rsp), %rdi
   10a78:      	movl	$0x8, %esi
   10a7d:      	callq	*%rax
   10a7f:      	cmpq	0x10(%rsp), %r12
   10a84:      	je	0x10b7c <generic_kprobe_path+0x525c>
   10a8a:      	leaq	0x18(%r12), %rbx
   10a8f:      	movl	$0x4, %eax
   10a94:      	movq	%rbp, %rdi
   10a97:      	movl	$0x8, %esi
   10a9c:      	movq	%rbx, %rdx
   10a9f:      	callq	*%rax
   10aa1:      	cmpq	%r12, (%rsp)
   10aa5:      	je	0x10b7c <generic_kprobe_path+0x525c>
   10aab:      	movl	$0x4, %eax
   10ab0:      	leaq	0x8(%rsp), %rdi
   10ab5:      	movl	$0x8, %esi
   10aba:      	movq	%rbx, %rdx
   10abd:      	callq	*%rax
   10abf:      	addq	$0x20, %r12
   10ac3:      	movl	$0x4, %eax
   10ac8:      	leaq	0x58(%rsp), %rdi
   10acd:      	movl	$0x10, %ecx
   10ad2:      	movl	$0x10, %esi
   10ad7:      	movq	%r12, %rdx
   10ada:      	callq	*%rax
   10adc:      	movq	0x28(%rsp), %rbx
   10ae1:      	movq	0x48(%rsp), %rax
   10ae6:      	movl	0x5c(%rsp), %r15d
   10aeb:      	subq	%rbx, %rax
   10aee:      	movl	0x50(%rsp), %r12d
   10af3:      	movl	%r15d, %edx
   10af6:      	subl	%r12d, %edx
   10af9:      	movl	$0x0, %ecx
   10afe:      	cmovbl	%ecx, %edx
   10b01:      	addq	0x60(%rsp), %rdx
   10b06:      	xorl	%esi, %esi
   10b08:      	cmpl	%r15d, %r12d
   10b0b:      	seta	%sil
   10b0f:      	movl	%r15d, %ecx
   10b12:      	cmovbl	%r12d, %ecx
   10b16:      	addl	%ecx, %esi
   10b18:      	movl	%r12d, %edi
   10b1b:      	subl	%esi, %edi
   10b1d:      	movl	%edi, 0x50(%rsp)
   10b21:      	subq	%rsi, %rax
   10b24:      	jb	0x17392 <generic_kprobe_path+0xba72>
   10b2a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10b30:      	ja	0x17392 <generic_kprobe_path+0xba72>
   10b36:      	cmpl	%r15d, %r12d
   10b39:      	jbe	0x10b3f <generic_kprobe_path+0x521f>
   10b3b:      	movb	$0x2f, (%rbx,%rax)
   10b3f:      	xorl	%edi, %edi
   10b41:      	cmpl	%r15d, %r12d
   10b44:      	seta	%dil
   10b48:      	movzbl	%cl, %esi
   10b4b:      	addq	%rax, %rbx
   10b4e:      	addq	%rbx, %rdi
   10b51:      	movl	$0x4, %eax
   10b56:      	callq	*%rax
   10b58:      	movq	%rbx, 0x48(%rsp)
   10b5d:      	cmpl	%r15d, %r12d
   10b60:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   10b66:      	movq	0x8(%rsp), %r12
   10b6b:      	movq	%r12, 0x30(%rsp)
   10b70:      	movq	0x38(%rsp), %rdx
   10b75:      	movq	0x40(%rsp), %r15
   10b7a:      	jmp	0x10bcd <generic_kprobe_path+0x52ad>
   10b7c:      	leaq	0x10(%r15), %rdx
   10b80:      	movl	$0x4, %eax
   10b85:      	movq	%rbp, %rdi
   10b88:      	movl	$0x8, %esi
   10b8d:      	callq	*%rax
   10b8f:      	movq	0x40(%rsp), %rax
   10b94:      	cmpq	(%rsp), %rax
   10b98:      	je	0x1738d <generic_kprobe_path+0xba6d>
   10b9e:      	addq	$0x18, %r15
   10ba2:      	movl	$0x4, %eax
   10ba7:      	leaq	0x30(%rsp), %rdi
   10bac:      	movl	$0x8, %esi
   10bb1:      	movq	%r15, %rdx
   10bb4:      	callq	*%rax
   10bb6:      	movq	(%rsp), %r15
   10bba:      	movq	%r15, 0x40(%rsp)
   10bbf:      	leaq	0x20(%r15), %rdx
   10bc3:      	movq	%rdx, 0x38(%rsp)
   10bc8:      	movq	0x30(%rsp), %r12
   10bcd:      	cmpq	0x18(%rsp), %r12
   10bd2:      	jne	0x10bdf <generic_kprobe_path+0x52bf>
   10bd4:      	cmpq	0x20(%rsp), %rdx
   10bd9:      	je	0x1738d <generic_kprobe_path+0xba6d>
   10bdf:      	movl	$0x4, %eax
   10be4:      	leaq	0x10(%rsp), %rdi
   10be9:      	movl	$0x8, %esi
   10bee:      	callq	*%rax
   10bf0:      	cmpq	0x10(%rsp), %r12
   10bf5:      	je	0x10ced <generic_kprobe_path+0x53cd>
   10bfb:      	leaq	0x18(%r12), %rbx
   10c00:      	movl	$0x4, %eax
   10c05:      	movq	%rbp, %rdi
   10c08:      	movl	$0x8, %esi
   10c0d:      	movq	%rbx, %rdx
   10c10:      	callq	*%rax
   10c12:      	cmpq	%r12, (%rsp)
   10c16:      	je	0x10ced <generic_kprobe_path+0x53cd>
   10c1c:      	movl	$0x4, %eax
   10c21:      	leaq	0x8(%rsp), %rdi
   10c26:      	movl	$0x8, %esi
   10c2b:      	movq	%rbx, %rdx
   10c2e:      	callq	*%rax
   10c30:      	addq	$0x20, %r12
   10c34:      	movl	$0x4, %eax
   10c39:      	leaq	0x58(%rsp), %rdi
   10c3e:      	movl	$0x10, %ecx
   10c43:      	movl	$0x10, %esi
   10c48:      	movq	%r12, %rdx
   10c4b:      	callq	*%rax
   10c4d:      	movq	0x28(%rsp), %rbx
   10c52:      	movq	0x48(%rsp), %rax
   10c57:      	movl	0x5c(%rsp), %r15d
   10c5c:      	subq	%rbx, %rax
   10c5f:      	movl	0x50(%rsp), %r12d
   10c64:      	movl	%r15d, %edx
   10c67:      	subl	%r12d, %edx
   10c6a:      	movl	$0x0, %ecx
   10c6f:      	cmovbl	%ecx, %edx
   10c72:      	addq	0x60(%rsp), %rdx
   10c77:      	xorl	%esi, %esi
   10c79:      	cmpl	%r15d, %r12d
   10c7c:      	seta	%sil
   10c80:      	movl	%r15d, %ecx
   10c83:      	cmovbl	%r12d, %ecx
   10c87:      	addl	%ecx, %esi
   10c89:      	movl	%r12d, %edi
   10c8c:      	subl	%esi, %edi
   10c8e:      	movl	%edi, 0x50(%rsp)
   10c92:      	subq	%rsi, %rax
   10c95:      	jb	0x17392 <generic_kprobe_path+0xba72>
   10c9b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10ca1:      	ja	0x17392 <generic_kprobe_path+0xba72>
   10ca7:      	cmpl	%r15d, %r12d
   10caa:      	jbe	0x10cb0 <generic_kprobe_path+0x5390>
   10cac:      	movb	$0x2f, (%rbx,%rax)
   10cb0:      	xorl	%edi, %edi
   10cb2:      	cmpl	%r15d, %r12d
   10cb5:      	seta	%dil
   10cb9:      	movzbl	%cl, %esi
   10cbc:      	addq	%rax, %rbx
   10cbf:      	addq	%rbx, %rdi
   10cc2:      	movl	$0x4, %eax
   10cc7:      	callq	*%rax
   10cc9:      	movq	%rbx, 0x48(%rsp)
   10cce:      	cmpl	%r15d, %r12d
   10cd1:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   10cd7:      	movq	0x8(%rsp), %r12
   10cdc:      	movq	%r12, 0x30(%rsp)
   10ce1:      	movq	0x38(%rsp), %rdx
   10ce6:      	movq	0x40(%rsp), %r15
   10ceb:      	jmp	0x10d3e <generic_kprobe_path+0x541e>
   10ced:      	leaq	0x10(%r15), %rdx
   10cf1:      	movl	$0x4, %eax
   10cf6:      	movq	%rbp, %rdi
   10cf9:      	movl	$0x8, %esi
   10cfe:      	callq	*%rax
   10d00:      	movq	0x40(%rsp), %rax
   10d05:      	cmpq	(%rsp), %rax
   10d09:      	je	0x1738d <generic_kprobe_path+0xba6d>
   10d0f:      	addq	$0x18, %r15
   10d13:      	movl	$0x4, %eax
   10d18:      	leaq	0x30(%rsp), %rdi
   10d1d:      	movl	$0x8, %esi
   10d22:      	movq	%r15, %rdx
   10d25:      	callq	*%rax
   10d27:      	movq	(%rsp), %r15
   10d2b:      	movq	%r15, 0x40(%rsp)
   10d30:      	leaq	0x20(%r15), %rdx
   10d34:      	movq	%rdx, 0x38(%rsp)
   10d39:      	movq	0x30(%rsp), %r12
   10d3e:      	cmpq	0x18(%rsp), %r12
   10d43:      	jne	0x10d50 <generic_kprobe_path+0x5430>
   10d45:      	cmpq	0x20(%rsp), %rdx
   10d4a:      	je	0x1738d <generic_kprobe_path+0xba6d>
   10d50:      	movl	$0x4, %eax
   10d55:      	leaq	0x10(%rsp), %rdi
   10d5a:      	movl	$0x8, %esi
   10d5f:      	callq	*%rax
   10d61:      	cmpq	0x10(%rsp), %r12
   10d66:      	je	0x10e5e <generic_kprobe_path+0x553e>
   10d6c:      	leaq	0x18(%r12), %rbx
   10d71:      	movl	$0x4, %eax
   10d76:      	movq	%rbp, %rdi
   10d79:      	movl	$0x8, %esi
   10d7e:      	movq	%rbx, %rdx
   10d81:      	callq	*%rax
   10d83:      	cmpq	%r12, (%rsp)
   10d87:      	je	0x10e5e <generic_kprobe_path+0x553e>
   10d8d:      	movl	$0x4, %eax
   10d92:      	leaq	0x8(%rsp), %rdi
   10d97:      	movl	$0x8, %esi
   10d9c:      	movq	%rbx, %rdx
   10d9f:      	callq	*%rax
   10da1:      	addq	$0x20, %r12
   10da5:      	movl	$0x4, %eax
   10daa:      	leaq	0x58(%rsp), %rdi
   10daf:      	movl	$0x10, %ecx
   10db4:      	movl	$0x10, %esi
   10db9:      	movq	%r12, %rdx
   10dbc:      	callq	*%rax
   10dbe:      	movq	0x28(%rsp), %rbx
   10dc3:      	movq	0x48(%rsp), %rax
   10dc8:      	movl	0x5c(%rsp), %r15d
   10dcd:      	subq	%rbx, %rax
   10dd0:      	movl	0x50(%rsp), %r12d
   10dd5:      	movl	%r15d, %edx
   10dd8:      	subl	%r12d, %edx
   10ddb:      	movl	$0x0, %ecx
   10de0:      	cmovbl	%ecx, %edx
   10de3:      	addq	0x60(%rsp), %rdx
   10de8:      	xorl	%esi, %esi
   10dea:      	cmpl	%r15d, %r12d
   10ded:      	seta	%sil
   10df1:      	movl	%r15d, %ecx
   10df4:      	cmovbl	%r12d, %ecx
   10df8:      	addl	%ecx, %esi
   10dfa:      	movl	%r12d, %edi
   10dfd:      	subl	%esi, %edi
   10dff:      	movl	%edi, 0x50(%rsp)
   10e03:      	subq	%rsi, %rax
   10e06:      	jb	0x17392 <generic_kprobe_path+0xba72>
   10e0c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10e12:      	ja	0x17392 <generic_kprobe_path+0xba72>
   10e18:      	cmpl	%r15d, %r12d
   10e1b:      	jbe	0x10e21 <generic_kprobe_path+0x5501>
   10e1d:      	movb	$0x2f, (%rbx,%rax)
   10e21:      	xorl	%edi, %edi
   10e23:      	cmpl	%r15d, %r12d
   10e26:      	seta	%dil
   10e2a:      	movzbl	%cl, %esi
   10e2d:      	addq	%rax, %rbx
   10e30:      	addq	%rbx, %rdi
   10e33:      	movl	$0x4, %eax
   10e38:      	callq	*%rax
   10e3a:      	movq	%rbx, 0x48(%rsp)
   10e3f:      	cmpl	%r15d, %r12d
   10e42:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   10e48:      	movq	0x8(%rsp), %r12
   10e4d:      	movq	%r12, 0x30(%rsp)
   10e52:      	movq	0x38(%rsp), %rdx
   10e57:      	movq	0x40(%rsp), %r15
   10e5c:      	jmp	0x10eaf <generic_kprobe_path+0x558f>
   10e5e:      	leaq	0x10(%r15), %rdx
   10e62:      	movl	$0x4, %eax
   10e67:      	movq	%rbp, %rdi
   10e6a:      	movl	$0x8, %esi
   10e6f:      	callq	*%rax
   10e71:      	movq	0x40(%rsp), %rax
   10e76:      	cmpq	(%rsp), %rax
   10e7a:      	je	0x1738d <generic_kprobe_path+0xba6d>
   10e80:      	addq	$0x18, %r15
   10e84:      	movl	$0x4, %eax
   10e89:      	leaq	0x30(%rsp), %rdi
   10e8e:      	movl	$0x8, %esi
   10e93:      	movq	%r15, %rdx
   10e96:      	callq	*%rax
   10e98:      	movq	(%rsp), %r15
   10e9c:      	movq	%r15, 0x40(%rsp)
   10ea1:      	leaq	0x20(%r15), %rdx
   10ea5:      	movq	%rdx, 0x38(%rsp)
   10eaa:      	movq	0x30(%rsp), %r12
   10eaf:      	cmpq	0x18(%rsp), %r12
   10eb4:      	jne	0x10ec1 <generic_kprobe_path+0x55a1>
   10eb6:      	cmpq	0x20(%rsp), %rdx
   10ebb:      	je	0x1738d <generic_kprobe_path+0xba6d>
   10ec1:      	movl	$0x4, %eax
   10ec6:      	leaq	0x10(%rsp), %rdi
   10ecb:      	movl	$0x8, %esi
   10ed0:      	callq	*%rax
   10ed2:      	cmpq	0x10(%rsp), %r12
   10ed7:      	je	0x10fcf <generic_kprobe_path+0x56af>
   10edd:      	leaq	0x18(%r12), %rbx
   10ee2:      	movl	$0x4, %eax
   10ee7:      	movq	%rbp, %rdi
   10eea:      	movl	$0x8, %esi
   10eef:      	movq	%rbx, %rdx
   10ef2:      	callq	*%rax
   10ef4:      	cmpq	%r12, (%rsp)
   10ef8:      	je	0x10fcf <generic_kprobe_path+0x56af>
   10efe:      	movl	$0x4, %eax
   10f03:      	leaq	0x8(%rsp), %rdi
   10f08:      	movl	$0x8, %esi
   10f0d:      	movq	%rbx, %rdx
   10f10:      	callq	*%rax
   10f12:      	addq	$0x20, %r12
   10f16:      	movl	$0x4, %eax
   10f1b:      	leaq	0x58(%rsp), %rdi
   10f20:      	movl	$0x10, %ecx
   10f25:      	movl	$0x10, %esi
   10f2a:      	movq	%r12, %rdx
   10f2d:      	callq	*%rax
   10f2f:      	movq	0x28(%rsp), %rbx
   10f34:      	movq	0x48(%rsp), %rax
   10f39:      	movl	0x5c(%rsp), %r15d
   10f3e:      	subq	%rbx, %rax
   10f41:      	movl	0x50(%rsp), %r12d
   10f46:      	movl	%r15d, %edx
   10f49:      	subl	%r12d, %edx
   10f4c:      	movl	$0x0, %ecx
   10f51:      	cmovbl	%ecx, %edx
   10f54:      	addq	0x60(%rsp), %rdx
   10f59:      	xorl	%esi, %esi
   10f5b:      	cmpl	%r15d, %r12d
   10f5e:      	seta	%sil
   10f62:      	movl	%r15d, %ecx
   10f65:      	cmovbl	%r12d, %ecx
   10f69:      	addl	%ecx, %esi
   10f6b:      	movl	%r12d, %edi
   10f6e:      	subl	%esi, %edi
   10f70:      	movl	%edi, 0x50(%rsp)
   10f74:      	subq	%rsi, %rax
   10f77:      	jb	0x17392 <generic_kprobe_path+0xba72>
   10f7d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10f83:      	ja	0x17392 <generic_kprobe_path+0xba72>
   10f89:      	cmpl	%r15d, %r12d
   10f8c:      	jbe	0x10f92 <generic_kprobe_path+0x5672>
   10f8e:      	movb	$0x2f, (%rbx,%rax)
   10f92:      	xorl	%edi, %edi
   10f94:      	cmpl	%r15d, %r12d
   10f97:      	seta	%dil
   10f9b:      	movzbl	%cl, %esi
   10f9e:      	addq	%rax, %rbx
   10fa1:      	addq	%rbx, %rdi
   10fa4:      	movl	$0x4, %eax
   10fa9:      	callq	*%rax
   10fab:      	movq	%rbx, 0x48(%rsp)
   10fb0:      	cmpl	%r15d, %r12d
   10fb3:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   10fb9:      	movq	0x8(%rsp), %r12
   10fbe:      	movq	%r12, 0x30(%rsp)
   10fc3:      	movq	0x38(%rsp), %rdx
   10fc8:      	movq	0x40(%rsp), %r15
   10fcd:      	jmp	0x11020 <generic_kprobe_path+0x5700>
   10fcf:      	leaq	0x10(%r15), %rdx
   10fd3:      	movl	$0x4, %eax
   10fd8:      	movq	%rbp, %rdi
   10fdb:      	movl	$0x8, %esi
   10fe0:      	callq	*%rax
   10fe2:      	movq	0x40(%rsp), %rax
   10fe7:      	cmpq	(%rsp), %rax
   10feb:      	je	0x1738d <generic_kprobe_path+0xba6d>
   10ff1:      	addq	$0x18, %r15
   10ff5:      	movl	$0x4, %eax
   10ffa:      	leaq	0x30(%rsp), %rdi
   10fff:      	movl	$0x8, %esi
   11004:      	movq	%r15, %rdx
   11007:      	callq	*%rax
   11009:      	movq	(%rsp), %r15
   1100d:      	movq	%r15, 0x40(%rsp)
   11012:      	leaq	0x20(%r15), %rdx
   11016:      	movq	%rdx, 0x38(%rsp)
   1101b:      	movq	0x30(%rsp), %r12
   11020:      	cmpq	0x18(%rsp), %r12
   11025:      	jne	0x11032 <generic_kprobe_path+0x5712>
   11027:      	cmpq	0x20(%rsp), %rdx
   1102c:      	je	0x1738d <generic_kprobe_path+0xba6d>
   11032:      	movl	$0x4, %eax
   11037:      	leaq	0x10(%rsp), %rdi
   1103c:      	movl	$0x8, %esi
   11041:      	callq	*%rax
   11043:      	cmpq	0x10(%rsp), %r12
   11048:      	je	0x11140 <generic_kprobe_path+0x5820>
   1104e:      	leaq	0x18(%r12), %rbx
   11053:      	movl	$0x4, %eax
   11058:      	movq	%rbp, %rdi
   1105b:      	movl	$0x8, %esi
   11060:      	movq	%rbx, %rdx
   11063:      	callq	*%rax
   11065:      	cmpq	%r12, (%rsp)
   11069:      	je	0x11140 <generic_kprobe_path+0x5820>
   1106f:      	movl	$0x4, %eax
   11074:      	leaq	0x8(%rsp), %rdi
   11079:      	movl	$0x8, %esi
   1107e:      	movq	%rbx, %rdx
   11081:      	callq	*%rax
   11083:      	addq	$0x20, %r12
   11087:      	movl	$0x4, %eax
   1108c:      	leaq	0x58(%rsp), %rdi
   11091:      	movl	$0x10, %ecx
   11096:      	movl	$0x10, %esi
   1109b:      	movq	%r12, %rdx
   1109e:      	callq	*%rax
   110a0:      	movq	0x28(%rsp), %rbx
   110a5:      	movq	0x48(%rsp), %rax
   110aa:      	movl	0x5c(%rsp), %r15d
   110af:      	subq	%rbx, %rax
   110b2:      	movl	0x50(%rsp), %r12d
   110b7:      	movl	%r15d, %edx
   110ba:      	subl	%r12d, %edx
   110bd:      	movl	$0x0, %ecx
   110c2:      	cmovbl	%ecx, %edx
   110c5:      	addq	0x60(%rsp), %rdx
   110ca:      	xorl	%esi, %esi
   110cc:      	cmpl	%r15d, %r12d
   110cf:      	seta	%sil
   110d3:      	movl	%r15d, %ecx
   110d6:      	cmovbl	%r12d, %ecx
   110da:      	addl	%ecx, %esi
   110dc:      	movl	%r12d, %edi
   110df:      	subl	%esi, %edi
   110e1:      	movl	%edi, 0x50(%rsp)
   110e5:      	subq	%rsi, %rax
   110e8:      	jb	0x17392 <generic_kprobe_path+0xba72>
   110ee:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   110f4:      	ja	0x17392 <generic_kprobe_path+0xba72>
   110fa:      	cmpl	%r15d, %r12d
   110fd:      	jbe	0x11103 <generic_kprobe_path+0x57e3>
   110ff:      	movb	$0x2f, (%rbx,%rax)
   11103:      	xorl	%edi, %edi
   11105:      	cmpl	%r15d, %r12d
   11108:      	seta	%dil
   1110c:      	movzbl	%cl, %esi
   1110f:      	addq	%rax, %rbx
   11112:      	addq	%rbx, %rdi
   11115:      	movl	$0x4, %eax
   1111a:      	callq	*%rax
   1111c:      	movq	%rbx, 0x48(%rsp)
   11121:      	cmpl	%r15d, %r12d
   11124:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   1112a:      	movq	0x8(%rsp), %r12
   1112f:      	movq	%r12, 0x30(%rsp)
   11134:      	movq	0x38(%rsp), %rdx
   11139:      	movq	0x40(%rsp), %r15
   1113e:      	jmp	0x11191 <generic_kprobe_path+0x5871>
   11140:      	leaq	0x10(%r15), %rdx
   11144:      	movl	$0x4, %eax
   11149:      	movq	%rbp, %rdi
   1114c:      	movl	$0x8, %esi
   11151:      	callq	*%rax
   11153:      	movq	0x40(%rsp), %rax
   11158:      	cmpq	(%rsp), %rax
   1115c:      	je	0x1738d <generic_kprobe_path+0xba6d>
   11162:      	addq	$0x18, %r15
   11166:      	movl	$0x4, %eax
   1116b:      	leaq	0x30(%rsp), %rdi
   11170:      	movl	$0x8, %esi
   11175:      	movq	%r15, %rdx
   11178:      	callq	*%rax
   1117a:      	movq	(%rsp), %r15
   1117e:      	movq	%r15, 0x40(%rsp)
   11183:      	leaq	0x20(%r15), %rdx
   11187:      	movq	%rdx, 0x38(%rsp)
   1118c:      	movq	0x30(%rsp), %r12
   11191:      	cmpq	0x18(%rsp), %r12
   11196:      	jne	0x111a3 <generic_kprobe_path+0x5883>
   11198:      	cmpq	0x20(%rsp), %rdx
   1119d:      	je	0x1738d <generic_kprobe_path+0xba6d>
   111a3:      	movl	$0x4, %eax
   111a8:      	leaq	0x10(%rsp), %rdi
   111ad:      	movl	$0x8, %esi
   111b2:      	callq	*%rax
   111b4:      	cmpq	0x10(%rsp), %r12
   111b9:      	je	0x112b1 <generic_kprobe_path+0x5991>
   111bf:      	leaq	0x18(%r12), %rbx
   111c4:      	movl	$0x4, %eax
   111c9:      	movq	%rbp, %rdi
   111cc:      	movl	$0x8, %esi
   111d1:      	movq	%rbx, %rdx
   111d4:      	callq	*%rax
   111d6:      	cmpq	%r12, (%rsp)
   111da:      	je	0x112b1 <generic_kprobe_path+0x5991>
   111e0:      	movl	$0x4, %eax
   111e5:      	leaq	0x8(%rsp), %rdi
   111ea:      	movl	$0x8, %esi
   111ef:      	movq	%rbx, %rdx
   111f2:      	callq	*%rax
   111f4:      	addq	$0x20, %r12
   111f8:      	movl	$0x4, %eax
   111fd:      	leaq	0x58(%rsp), %rdi
   11202:      	movl	$0x10, %ecx
   11207:      	movl	$0x10, %esi
   1120c:      	movq	%r12, %rdx
   1120f:      	callq	*%rax
   11211:      	movq	0x28(%rsp), %rbx
   11216:      	movq	0x48(%rsp), %rax
   1121b:      	movl	0x5c(%rsp), %r15d
   11220:      	subq	%rbx, %rax
   11223:      	movl	0x50(%rsp), %r12d
   11228:      	movl	%r15d, %edx
   1122b:      	subl	%r12d, %edx
   1122e:      	movl	$0x0, %ecx
   11233:      	cmovbl	%ecx, %edx
   11236:      	addq	0x60(%rsp), %rdx
   1123b:      	xorl	%esi, %esi
   1123d:      	cmpl	%r15d, %r12d
   11240:      	seta	%sil
   11244:      	movl	%r15d, %ecx
   11247:      	cmovbl	%r12d, %ecx
   1124b:      	addl	%ecx, %esi
   1124d:      	movl	%r12d, %edi
   11250:      	subl	%esi, %edi
   11252:      	movl	%edi, 0x50(%rsp)
   11256:      	subq	%rsi, %rax
   11259:      	jb	0x17392 <generic_kprobe_path+0xba72>
   1125f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11265:      	ja	0x17392 <generic_kprobe_path+0xba72>
   1126b:      	cmpl	%r15d, %r12d
   1126e:      	jbe	0x11274 <generic_kprobe_path+0x5954>
   11270:      	movb	$0x2f, (%rbx,%rax)
   11274:      	xorl	%edi, %edi
   11276:      	cmpl	%r15d, %r12d
   11279:      	seta	%dil
   1127d:      	movzbl	%cl, %esi
   11280:      	addq	%rax, %rbx
   11283:      	addq	%rbx, %rdi
   11286:      	movl	$0x4, %eax
   1128b:      	callq	*%rax
   1128d:      	movq	%rbx, 0x48(%rsp)
   11292:      	cmpl	%r15d, %r12d
   11295:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   1129b:      	movq	0x8(%rsp), %r12
   112a0:      	movq	%r12, 0x30(%rsp)
   112a5:      	movq	0x38(%rsp), %rdx
   112aa:      	movq	0x40(%rsp), %r15
   112af:      	jmp	0x11302 <generic_kprobe_path+0x59e2>
   112b1:      	leaq	0x10(%r15), %rdx
   112b5:      	movl	$0x4, %eax
   112ba:      	movq	%rbp, %rdi
   112bd:      	movl	$0x8, %esi
   112c2:      	callq	*%rax
   112c4:      	movq	0x40(%rsp), %rax
   112c9:      	cmpq	(%rsp), %rax
   112cd:      	je	0x1738d <generic_kprobe_path+0xba6d>
   112d3:      	addq	$0x18, %r15
   112d7:      	movl	$0x4, %eax
   112dc:      	leaq	0x30(%rsp), %rdi
   112e1:      	movl	$0x8, %esi
   112e6:      	movq	%r15, %rdx
   112e9:      	callq	*%rax
   112eb:      	movq	(%rsp), %r15
   112ef:      	movq	%r15, 0x40(%rsp)
   112f4:      	leaq	0x20(%r15), %rdx
   112f8:      	movq	%rdx, 0x38(%rsp)
   112fd:      	movq	0x30(%rsp), %r12
   11302:      	cmpq	0x18(%rsp), %r12
   11307:      	jne	0x11314 <generic_kprobe_path+0x59f4>
   11309:      	cmpq	0x20(%rsp), %rdx
   1130e:      	je	0x1738d <generic_kprobe_path+0xba6d>
   11314:      	movl	$0x4, %eax
   11319:      	leaq	0x10(%rsp), %rdi
   1131e:      	movl	$0x8, %esi
   11323:      	callq	*%rax
   11325:      	cmpq	0x10(%rsp), %r12
   1132a:      	je	0x11422 <generic_kprobe_path+0x5b02>
   11330:      	leaq	0x18(%r12), %rbx
   11335:      	movl	$0x4, %eax
   1133a:      	movq	%rbp, %rdi
   1133d:      	movl	$0x8, %esi
   11342:      	movq	%rbx, %rdx
   11345:      	callq	*%rax
   11347:      	cmpq	%r12, (%rsp)
   1134b:      	je	0x11422 <generic_kprobe_path+0x5b02>
   11351:      	movl	$0x4, %eax
   11356:      	leaq	0x8(%rsp), %rdi
   1135b:      	movl	$0x8, %esi
   11360:      	movq	%rbx, %rdx
   11363:      	callq	*%rax
   11365:      	addq	$0x20, %r12
   11369:      	movl	$0x4, %eax
   1136e:      	leaq	0x58(%rsp), %rdi
   11373:      	movl	$0x10, %ecx
   11378:      	movl	$0x10, %esi
   1137d:      	movq	%r12, %rdx
   11380:      	callq	*%rax
   11382:      	movq	0x28(%rsp), %rbx
   11387:      	movq	0x48(%rsp), %rax
   1138c:      	movl	0x5c(%rsp), %r15d
   11391:      	subq	%rbx, %rax
   11394:      	movl	0x50(%rsp), %r12d
   11399:      	movl	%r15d, %edx
   1139c:      	subl	%r12d, %edx
   1139f:      	movl	$0x0, %ecx
   113a4:      	cmovbl	%ecx, %edx
   113a7:      	addq	0x60(%rsp), %rdx
   113ac:      	xorl	%esi, %esi
   113ae:      	cmpl	%r15d, %r12d
   113b1:      	seta	%sil
   113b5:      	movl	%r15d, %ecx
   113b8:      	cmovbl	%r12d, %ecx
   113bc:      	addl	%ecx, %esi
   113be:      	movl	%r12d, %edi
   113c1:      	subl	%esi, %edi
   113c3:      	movl	%edi, 0x50(%rsp)
   113c7:      	subq	%rsi, %rax
   113ca:      	jb	0x17392 <generic_kprobe_path+0xba72>
   113d0:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   113d6:      	ja	0x17392 <generic_kprobe_path+0xba72>
   113dc:      	cmpl	%r15d, %r12d
   113df:      	jbe	0x113e5 <generic_kprobe_path+0x5ac5>
   113e1:      	movb	$0x2f, (%rbx,%rax)
   113e5:      	xorl	%edi, %edi
   113e7:      	cmpl	%r15d, %r12d
   113ea:      	seta	%dil
   113ee:      	movzbl	%cl, %esi
   113f1:      	addq	%rax, %rbx
   113f4:      	addq	%rbx, %rdi
   113f7:      	movl	$0x4, %eax
   113fc:      	callq	*%rax
   113fe:      	movq	%rbx, 0x48(%rsp)
   11403:      	cmpl	%r15d, %r12d
   11406:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   1140c:      	movq	0x8(%rsp), %r12
   11411:      	movq	%r12, 0x30(%rsp)
   11416:      	movq	0x38(%rsp), %rdx
   1141b:      	movq	0x40(%rsp), %r15
   11420:      	jmp	0x11473 <generic_kprobe_path+0x5b53>
   11422:      	leaq	0x10(%r15), %rdx
   11426:      	movl	$0x4, %eax
   1142b:      	movq	%rbp, %rdi
   1142e:      	movl	$0x8, %esi
   11433:      	callq	*%rax
   11435:      	movq	0x40(%rsp), %rax
   1143a:      	cmpq	(%rsp), %rax
   1143e:      	je	0x1738d <generic_kprobe_path+0xba6d>
   11444:      	addq	$0x18, %r15
   11448:      	movl	$0x4, %eax
   1144d:      	leaq	0x30(%rsp), %rdi
   11452:      	movl	$0x8, %esi
   11457:      	movq	%r15, %rdx
   1145a:      	callq	*%rax
   1145c:      	movq	(%rsp), %r15
   11460:      	movq	%r15, 0x40(%rsp)
   11465:      	leaq	0x20(%r15), %rdx
   11469:      	movq	%rdx, 0x38(%rsp)
   1146e:      	movq	0x30(%rsp), %r12
   11473:      	cmpq	0x18(%rsp), %r12
   11478:      	jne	0x11485 <generic_kprobe_path+0x5b65>
   1147a:      	cmpq	0x20(%rsp), %rdx
   1147f:      	je	0x1738d <generic_kprobe_path+0xba6d>
   11485:      	movl	$0x4, %eax
   1148a:      	leaq	0x10(%rsp), %rdi
   1148f:      	movl	$0x8, %esi
   11494:      	callq	*%rax
   11496:      	cmpq	0x10(%rsp), %r12
   1149b:      	je	0x11593 <generic_kprobe_path+0x5c73>
   114a1:      	leaq	0x18(%r12), %rbx
   114a6:      	movl	$0x4, %eax
   114ab:      	movq	%rbp, %rdi
   114ae:      	movl	$0x8, %esi
   114b3:      	movq	%rbx, %rdx
   114b6:      	callq	*%rax
   114b8:      	cmpq	%r12, (%rsp)
   114bc:      	je	0x11593 <generic_kprobe_path+0x5c73>
   114c2:      	movl	$0x4, %eax
   114c7:      	leaq	0x8(%rsp), %rdi
   114cc:      	movl	$0x8, %esi
   114d1:      	movq	%rbx, %rdx
   114d4:      	callq	*%rax
   114d6:      	addq	$0x20, %r12
   114da:      	movl	$0x4, %eax
   114df:      	leaq	0x58(%rsp), %rdi
   114e4:      	movl	$0x10, %ecx
   114e9:      	movl	$0x10, %esi
   114ee:      	movq	%r12, %rdx
   114f1:      	callq	*%rax
   114f3:      	movq	0x28(%rsp), %rbx
   114f8:      	movq	0x48(%rsp), %rax
   114fd:      	movl	0x5c(%rsp), %r15d
   11502:      	subq	%rbx, %rax
   11505:      	movl	0x50(%rsp), %r12d
   1150a:      	movl	%r15d, %edx
   1150d:      	subl	%r12d, %edx
   11510:      	movl	$0x0, %ecx
   11515:      	cmovbl	%ecx, %edx
   11518:      	addq	0x60(%rsp), %rdx
   1151d:      	xorl	%esi, %esi
   1151f:      	cmpl	%r15d, %r12d
   11522:      	seta	%sil
   11526:      	movl	%r15d, %ecx
   11529:      	cmovbl	%r12d, %ecx
   1152d:      	addl	%ecx, %esi
   1152f:      	movl	%r12d, %edi
   11532:      	subl	%esi, %edi
   11534:      	movl	%edi, 0x50(%rsp)
   11538:      	subq	%rsi, %rax
   1153b:      	jb	0x17392 <generic_kprobe_path+0xba72>
   11541:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11547:      	ja	0x17392 <generic_kprobe_path+0xba72>
   1154d:      	cmpl	%r15d, %r12d
   11550:      	jbe	0x11556 <generic_kprobe_path+0x5c36>
   11552:      	movb	$0x2f, (%rbx,%rax)
   11556:      	xorl	%edi, %edi
   11558:      	cmpl	%r15d, %r12d
   1155b:      	seta	%dil
   1155f:      	movzbl	%cl, %esi
   11562:      	addq	%rax, %rbx
   11565:      	addq	%rbx, %rdi
   11568:      	movl	$0x4, %eax
   1156d:      	callq	*%rax
   1156f:      	movq	%rbx, 0x48(%rsp)
   11574:      	cmpl	%r15d, %r12d
   11577:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   1157d:      	movq	0x8(%rsp), %r12
   11582:      	movq	%r12, 0x30(%rsp)
   11587:      	movq	0x38(%rsp), %rdx
   1158c:      	movq	0x40(%rsp), %r15
   11591:      	jmp	0x115e4 <generic_kprobe_path+0x5cc4>
   11593:      	leaq	0x10(%r15), %rdx
   11597:      	movl	$0x4, %eax
   1159c:      	movq	%rbp, %rdi
   1159f:      	movl	$0x8, %esi
   115a4:      	callq	*%rax
   115a6:      	movq	0x40(%rsp), %rax
   115ab:      	cmpq	(%rsp), %rax
   115af:      	je	0x1738d <generic_kprobe_path+0xba6d>
   115b5:      	addq	$0x18, %r15
   115b9:      	movl	$0x4, %eax
   115be:      	leaq	0x30(%rsp), %rdi
   115c3:      	movl	$0x8, %esi
   115c8:      	movq	%r15, %rdx
   115cb:      	callq	*%rax
   115cd:      	movq	(%rsp), %r15
   115d1:      	movq	%r15, 0x40(%rsp)
   115d6:      	leaq	0x20(%r15), %rdx
   115da:      	movq	%rdx, 0x38(%rsp)
   115df:      	movq	0x30(%rsp), %r12
   115e4:      	cmpq	0x18(%rsp), %r12
   115e9:      	jne	0x115f6 <generic_kprobe_path+0x5cd6>
   115eb:      	cmpq	0x20(%rsp), %rdx
   115f0:      	je	0x1738d <generic_kprobe_path+0xba6d>
   115f6:      	movl	$0x4, %eax
   115fb:      	leaq	0x10(%rsp), %rdi
   11600:      	movl	$0x8, %esi
   11605:      	callq	*%rax
   11607:      	cmpq	0x10(%rsp), %r12
   1160c:      	je	0x11704 <generic_kprobe_path+0x5de4>
   11612:      	leaq	0x18(%r12), %rbx
   11617:      	movl	$0x4, %eax
   1161c:      	movq	%rbp, %rdi
   1161f:      	movl	$0x8, %esi
   11624:      	movq	%rbx, %rdx
   11627:      	callq	*%rax
   11629:      	cmpq	%r12, (%rsp)
   1162d:      	je	0x11704 <generic_kprobe_path+0x5de4>
   11633:      	movl	$0x4, %eax
   11638:      	leaq	0x8(%rsp), %rdi
   1163d:      	movl	$0x8, %esi
   11642:      	movq	%rbx, %rdx
   11645:      	callq	*%rax
   11647:      	addq	$0x20, %r12
   1164b:      	movl	$0x4, %eax
   11650:      	leaq	0x58(%rsp), %rdi
   11655:      	movl	$0x10, %ecx
   1165a:      	movl	$0x10, %esi
   1165f:      	movq	%r12, %rdx
   11662:      	callq	*%rax
   11664:      	movq	0x28(%rsp), %rbx
   11669:      	movq	0x48(%rsp), %rax
   1166e:      	movl	0x5c(%rsp), %r15d
   11673:      	subq	%rbx, %rax
   11676:      	movl	0x50(%rsp), %r12d
   1167b:      	movl	%r15d, %edx
   1167e:      	subl	%r12d, %edx
   11681:      	movl	$0x0, %ecx
   11686:      	cmovbl	%ecx, %edx
   11689:      	addq	0x60(%rsp), %rdx
   1168e:      	xorl	%esi, %esi
   11690:      	cmpl	%r15d, %r12d
   11693:      	seta	%sil
   11697:      	movl	%r15d, %ecx
   1169a:      	cmovbl	%r12d, %ecx
   1169e:      	addl	%ecx, %esi
   116a0:      	movl	%r12d, %edi
   116a3:      	subl	%esi, %edi
   116a5:      	movl	%edi, 0x50(%rsp)
   116a9:      	subq	%rsi, %rax
   116ac:      	jb	0x17392 <generic_kprobe_path+0xba72>
   116b2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   116b8:      	ja	0x17392 <generic_kprobe_path+0xba72>
   116be:      	cmpl	%r15d, %r12d
   116c1:      	jbe	0x116c7 <generic_kprobe_path+0x5da7>
   116c3:      	movb	$0x2f, (%rbx,%rax)
   116c7:      	xorl	%edi, %edi
   116c9:      	cmpl	%r15d, %r12d
   116cc:      	seta	%dil
   116d0:      	movzbl	%cl, %esi
   116d3:      	addq	%rax, %rbx
   116d6:      	addq	%rbx, %rdi
   116d9:      	movl	$0x4, %eax
   116de:      	callq	*%rax
   116e0:      	movq	%rbx, 0x48(%rsp)
   116e5:      	cmpl	%r15d, %r12d
   116e8:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   116ee:      	movq	0x8(%rsp), %r12
   116f3:      	movq	%r12, 0x30(%rsp)
   116f8:      	movq	0x38(%rsp), %rdx
   116fd:      	movq	0x40(%rsp), %r15
   11702:      	jmp	0x11755 <generic_kprobe_path+0x5e35>
   11704:      	leaq	0x10(%r15), %rdx
   11708:      	movl	$0x4, %eax
   1170d:      	movq	%rbp, %rdi
   11710:      	movl	$0x8, %esi
   11715:      	callq	*%rax
   11717:      	movq	0x40(%rsp), %rax
   1171c:      	cmpq	(%rsp), %rax
   11720:      	je	0x1738d <generic_kprobe_path+0xba6d>
   11726:      	addq	$0x18, %r15
   1172a:      	movl	$0x4, %eax
   1172f:      	leaq	0x30(%rsp), %rdi
   11734:      	movl	$0x8, %esi
   11739:      	movq	%r15, %rdx
   1173c:      	callq	*%rax
   1173e:      	movq	(%rsp), %r15
   11742:      	movq	%r15, 0x40(%rsp)
   11747:      	leaq	0x20(%r15), %rdx
   1174b:      	movq	%rdx, 0x38(%rsp)
   11750:      	movq	0x30(%rsp), %r12
   11755:      	cmpq	0x18(%rsp), %r12
   1175a:      	jne	0x11767 <generic_kprobe_path+0x5e47>
   1175c:      	cmpq	0x20(%rsp), %rdx
   11761:      	je	0x1738d <generic_kprobe_path+0xba6d>
   11767:      	movl	$0x4, %eax
   1176c:      	leaq	0x10(%rsp), %rdi
   11771:      	movl	$0x8, %esi
   11776:      	callq	*%rax
   11778:      	cmpq	0x10(%rsp), %r12
   1177d:      	je	0x11875 <generic_kprobe_path+0x5f55>
   11783:      	leaq	0x18(%r12), %rbx
   11788:      	movl	$0x4, %eax
   1178d:      	movq	%rbp, %rdi
   11790:      	movl	$0x8, %esi
   11795:      	movq	%rbx, %rdx
   11798:      	callq	*%rax
   1179a:      	cmpq	%r12, (%rsp)
   1179e:      	je	0x11875 <generic_kprobe_path+0x5f55>
   117a4:      	movl	$0x4, %eax
   117a9:      	leaq	0x8(%rsp), %rdi
   117ae:      	movl	$0x8, %esi
   117b3:      	movq	%rbx, %rdx
   117b6:      	callq	*%rax
   117b8:      	addq	$0x20, %r12
   117bc:      	movl	$0x4, %eax
   117c1:      	leaq	0x58(%rsp), %rdi
   117c6:      	movl	$0x10, %ecx
   117cb:      	movl	$0x10, %esi
   117d0:      	movq	%r12, %rdx
   117d3:      	callq	*%rax
   117d5:      	movq	0x28(%rsp), %rbx
   117da:      	movq	0x48(%rsp), %rax
   117df:      	movl	0x5c(%rsp), %r15d
   117e4:      	subq	%rbx, %rax
   117e7:      	movl	0x50(%rsp), %r12d
   117ec:      	movl	%r15d, %edx
   117ef:      	subl	%r12d, %edx
   117f2:      	movl	$0x0, %ecx
   117f7:      	cmovbl	%ecx, %edx
   117fa:      	addq	0x60(%rsp), %rdx
   117ff:      	xorl	%esi, %esi
   11801:      	cmpl	%r15d, %r12d
   11804:      	seta	%sil
   11808:      	movl	%r15d, %ecx
   1180b:      	cmovbl	%r12d, %ecx
   1180f:      	addl	%ecx, %esi
   11811:      	movl	%r12d, %edi
   11814:      	subl	%esi, %edi
   11816:      	movl	%edi, 0x50(%rsp)
   1181a:      	subq	%rsi, %rax
   1181d:      	jb	0x17392 <generic_kprobe_path+0xba72>
   11823:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11829:      	ja	0x17392 <generic_kprobe_path+0xba72>
   1182f:      	cmpl	%r15d, %r12d
   11832:      	jbe	0x11838 <generic_kprobe_path+0x5f18>
   11834:      	movb	$0x2f, (%rbx,%rax)
   11838:      	xorl	%edi, %edi
   1183a:      	cmpl	%r15d, %r12d
   1183d:      	seta	%dil
   11841:      	movzbl	%cl, %esi
   11844:      	addq	%rax, %rbx
   11847:      	addq	%rbx, %rdi
   1184a:      	movl	$0x4, %eax
   1184f:      	callq	*%rax
   11851:      	movq	%rbx, 0x48(%rsp)
   11856:      	cmpl	%r15d, %r12d
   11859:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   1185f:      	movq	0x8(%rsp), %r12
   11864:      	movq	%r12, 0x30(%rsp)
   11869:      	movq	0x38(%rsp), %rdx
   1186e:      	movq	0x40(%rsp), %r15
   11873:      	jmp	0x118c6 <generic_kprobe_path+0x5fa6>
   11875:      	leaq	0x10(%r15), %rdx
   11879:      	movl	$0x4, %eax
   1187e:      	movq	%rbp, %rdi
   11881:      	movl	$0x8, %esi
   11886:      	callq	*%rax
   11888:      	movq	0x40(%rsp), %rax
   1188d:      	cmpq	(%rsp), %rax
   11891:      	je	0x1738d <generic_kprobe_path+0xba6d>
   11897:      	addq	$0x18, %r15
   1189b:      	movl	$0x4, %eax
   118a0:      	leaq	0x30(%rsp), %rdi
   118a5:      	movl	$0x8, %esi
   118aa:      	movq	%r15, %rdx
   118ad:      	callq	*%rax
   118af:      	movq	(%rsp), %r15
   118b3:      	movq	%r15, 0x40(%rsp)
   118b8:      	leaq	0x20(%r15), %rdx
   118bc:      	movq	%rdx, 0x38(%rsp)
   118c1:      	movq	0x30(%rsp), %r12
   118c6:      	cmpq	0x18(%rsp), %r12
   118cb:      	jne	0x118d8 <generic_kprobe_path+0x5fb8>
   118cd:      	cmpq	0x20(%rsp), %rdx
   118d2:      	je	0x1738d <generic_kprobe_path+0xba6d>
   118d8:      	movl	$0x4, %eax
   118dd:      	leaq	0x10(%rsp), %rdi
   118e2:      	movl	$0x8, %esi
   118e7:      	callq	*%rax
   118e9:      	cmpq	0x10(%rsp), %r12
   118ee:      	je	0x119e6 <generic_kprobe_path+0x60c6>
   118f4:      	leaq	0x18(%r12), %rbx
   118f9:      	movl	$0x4, %eax
   118fe:      	movq	%rbp, %rdi
   11901:      	movl	$0x8, %esi
   11906:      	movq	%rbx, %rdx
   11909:      	callq	*%rax
   1190b:      	cmpq	%r12, (%rsp)
   1190f:      	je	0x119e6 <generic_kprobe_path+0x60c6>
   11915:      	movl	$0x4, %eax
   1191a:      	leaq	0x8(%rsp), %rdi
   1191f:      	movl	$0x8, %esi
   11924:      	movq	%rbx, %rdx
   11927:      	callq	*%rax
   11929:      	addq	$0x20, %r12
   1192d:      	movl	$0x4, %eax
   11932:      	leaq	0x58(%rsp), %rdi
   11937:      	movl	$0x10, %ecx
   1193c:      	movl	$0x10, %esi
   11941:      	movq	%r12, %rdx
   11944:      	callq	*%rax
   11946:      	movq	0x28(%rsp), %rbx
   1194b:      	movq	0x48(%rsp), %rax
   11950:      	movl	0x5c(%rsp), %r15d
   11955:      	subq	%rbx, %rax
   11958:      	movl	0x50(%rsp), %r12d
   1195d:      	movl	%r15d, %edx
   11960:      	subl	%r12d, %edx
   11963:      	movl	$0x0, %ecx
   11968:      	cmovbl	%ecx, %edx
   1196b:      	addq	0x60(%rsp), %rdx
   11970:      	xorl	%esi, %esi
   11972:      	cmpl	%r15d, %r12d
   11975:      	seta	%sil
   11979:      	movl	%r15d, %ecx
   1197c:      	cmovbl	%r12d, %ecx
   11980:      	addl	%ecx, %esi
   11982:      	movl	%r12d, %edi
   11985:      	subl	%esi, %edi
   11987:      	movl	%edi, 0x50(%rsp)
   1198b:      	subq	%rsi, %rax
   1198e:      	jb	0x17392 <generic_kprobe_path+0xba72>
   11994:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1199a:      	ja	0x17392 <generic_kprobe_path+0xba72>
   119a0:      	cmpl	%r15d, %r12d
   119a3:      	jbe	0x119a9 <generic_kprobe_path+0x6089>
   119a5:      	movb	$0x2f, (%rbx,%rax)
   119a9:      	xorl	%edi, %edi
   119ab:      	cmpl	%r15d, %r12d
   119ae:      	seta	%dil
   119b2:      	movzbl	%cl, %esi
   119b5:      	addq	%rax, %rbx
   119b8:      	addq	%rbx, %rdi
   119bb:      	movl	$0x4, %eax
   119c0:      	callq	*%rax
   119c2:      	movq	%rbx, 0x48(%rsp)
   119c7:      	cmpl	%r15d, %r12d
   119ca:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   119d0:      	movq	0x8(%rsp), %r12
   119d5:      	movq	%r12, 0x30(%rsp)
   119da:      	movq	0x38(%rsp), %rdx
   119df:      	movq	0x40(%rsp), %r15
   119e4:      	jmp	0x11a37 <generic_kprobe_path+0x6117>
   119e6:      	leaq	0x10(%r15), %rdx
   119ea:      	movl	$0x4, %eax
   119ef:      	movq	%rbp, %rdi
   119f2:      	movl	$0x8, %esi
   119f7:      	callq	*%rax
   119f9:      	movq	0x40(%rsp), %rax
   119fe:      	cmpq	(%rsp), %rax
   11a02:      	je	0x1738d <generic_kprobe_path+0xba6d>
   11a08:      	addq	$0x18, %r15
   11a0c:      	movl	$0x4, %eax
   11a11:      	leaq	0x30(%rsp), %rdi
   11a16:      	movl	$0x8, %esi
   11a1b:      	movq	%r15, %rdx
   11a1e:      	callq	*%rax
   11a20:      	movq	(%rsp), %r15
   11a24:      	movq	%r15, 0x40(%rsp)
   11a29:      	leaq	0x20(%r15), %rdx
   11a2d:      	movq	%rdx, 0x38(%rsp)
   11a32:      	movq	0x30(%rsp), %r12
   11a37:      	cmpq	0x18(%rsp), %r12
   11a3c:      	jne	0x11a49 <generic_kprobe_path+0x6129>
   11a3e:      	cmpq	0x20(%rsp), %rdx
   11a43:      	je	0x1738d <generic_kprobe_path+0xba6d>
   11a49:      	movl	$0x4, %eax
   11a4e:      	leaq	0x10(%rsp), %rdi
   11a53:      	movl	$0x8, %esi
   11a58:      	callq	*%rax
   11a5a:      	cmpq	0x10(%rsp), %r12
   11a5f:      	je	0x11b57 <generic_kprobe_path+0x6237>
   11a65:      	leaq	0x18(%r12), %rbx
   11a6a:      	movl	$0x4, %eax
   11a6f:      	movq	%rbp, %rdi
   11a72:      	movl	$0x8, %esi
   11a77:      	movq	%rbx, %rdx
   11a7a:      	callq	*%rax
   11a7c:      	cmpq	%r12, (%rsp)
   11a80:      	je	0x11b57 <generic_kprobe_path+0x6237>
   11a86:      	movl	$0x4, %eax
   11a8b:      	leaq	0x8(%rsp), %rdi
   11a90:      	movl	$0x8, %esi
   11a95:      	movq	%rbx, %rdx
   11a98:      	callq	*%rax
   11a9a:      	addq	$0x20, %r12
   11a9e:      	movl	$0x4, %eax
   11aa3:      	leaq	0x58(%rsp), %rdi
   11aa8:      	movl	$0x10, %ecx
   11aad:      	movl	$0x10, %esi
   11ab2:      	movq	%r12, %rdx
   11ab5:      	callq	*%rax
   11ab7:      	movq	0x28(%rsp), %rbx
   11abc:      	movq	0x48(%rsp), %rax
   11ac1:      	movl	0x5c(%rsp), %r15d
   11ac6:      	subq	%rbx, %rax
   11ac9:      	movl	0x50(%rsp), %r12d
   11ace:      	movl	%r15d, %edx
   11ad1:      	subl	%r12d, %edx
   11ad4:      	movl	$0x0, %ecx
   11ad9:      	cmovbl	%ecx, %edx
   11adc:      	addq	0x60(%rsp), %rdx
   11ae1:      	xorl	%esi, %esi
   11ae3:      	cmpl	%r15d, %r12d
   11ae6:      	seta	%sil
   11aea:      	movl	%r15d, %ecx
   11aed:      	cmovbl	%r12d, %ecx
   11af1:      	addl	%ecx, %esi
   11af3:      	movl	%r12d, %edi
   11af6:      	subl	%esi, %edi
   11af8:      	movl	%edi, 0x50(%rsp)
   11afc:      	subq	%rsi, %rax
   11aff:      	jb	0x17392 <generic_kprobe_path+0xba72>
   11b05:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11b0b:      	ja	0x17392 <generic_kprobe_path+0xba72>
   11b11:      	cmpl	%r15d, %r12d
   11b14:      	jbe	0x11b1a <generic_kprobe_path+0x61fa>
   11b16:      	movb	$0x2f, (%rbx,%rax)
   11b1a:      	xorl	%edi, %edi
   11b1c:      	cmpl	%r15d, %r12d
   11b1f:      	seta	%dil
   11b23:      	movzbl	%cl, %esi
   11b26:      	addq	%rax, %rbx
   11b29:      	addq	%rbx, %rdi
   11b2c:      	movl	$0x4, %eax
   11b31:      	callq	*%rax
   11b33:      	movq	%rbx, 0x48(%rsp)
   11b38:      	cmpl	%r15d, %r12d
   11b3b:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   11b41:      	movq	0x8(%rsp), %r12
   11b46:      	movq	%r12, 0x30(%rsp)
   11b4b:      	movq	0x38(%rsp), %rdx
   11b50:      	movq	0x40(%rsp), %r15
   11b55:      	jmp	0x11ba8 <generic_kprobe_path+0x6288>
   11b57:      	leaq	0x10(%r15), %rdx
   11b5b:      	movl	$0x4, %eax
   11b60:      	movq	%rbp, %rdi
   11b63:      	movl	$0x8, %esi
   11b68:      	callq	*%rax
   11b6a:      	movq	0x40(%rsp), %rax
   11b6f:      	cmpq	(%rsp), %rax
   11b73:      	je	0x1738d <generic_kprobe_path+0xba6d>
   11b79:      	addq	$0x18, %r15
   11b7d:      	movl	$0x4, %eax
   11b82:      	leaq	0x30(%rsp), %rdi
   11b87:      	movl	$0x8, %esi
   11b8c:      	movq	%r15, %rdx
   11b8f:      	callq	*%rax
   11b91:      	movq	(%rsp), %r15
   11b95:      	movq	%r15, 0x40(%rsp)
   11b9a:      	leaq	0x20(%r15), %rdx
   11b9e:      	movq	%rdx, 0x38(%rsp)
   11ba3:      	movq	0x30(%rsp), %r12
   11ba8:      	cmpq	0x18(%rsp), %r12
   11bad:      	jne	0x11bba <generic_kprobe_path+0x629a>
   11baf:      	cmpq	0x20(%rsp), %rdx
   11bb4:      	je	0x1738d <generic_kprobe_path+0xba6d>
   11bba:      	movl	$0x4, %eax
   11bbf:      	leaq	0x10(%rsp), %rdi
   11bc4:      	movl	$0x8, %esi
   11bc9:      	callq	*%rax
   11bcb:      	cmpq	0x10(%rsp), %r12
   11bd0:      	je	0x11cc8 <generic_kprobe_path+0x63a8>
   11bd6:      	leaq	0x18(%r12), %rbx
   11bdb:      	movl	$0x4, %eax
   11be0:      	movq	%rbp, %rdi
   11be3:      	movl	$0x8, %esi
   11be8:      	movq	%rbx, %rdx
   11beb:      	callq	*%rax
   11bed:      	cmpq	%r12, (%rsp)
   11bf1:      	je	0x11cc8 <generic_kprobe_path+0x63a8>
   11bf7:      	movl	$0x4, %eax
   11bfc:      	leaq	0x8(%rsp), %rdi
   11c01:      	movl	$0x8, %esi
   11c06:      	movq	%rbx, %rdx
   11c09:      	callq	*%rax
   11c0b:      	addq	$0x20, %r12
   11c0f:      	movl	$0x4, %eax
   11c14:      	leaq	0x58(%rsp), %rdi
   11c19:      	movl	$0x10, %ecx
   11c1e:      	movl	$0x10, %esi
   11c23:      	movq	%r12, %rdx
   11c26:      	callq	*%rax
   11c28:      	movq	0x28(%rsp), %rbx
   11c2d:      	movq	0x48(%rsp), %rax
   11c32:      	movl	0x5c(%rsp), %r15d
   11c37:      	subq	%rbx, %rax
   11c3a:      	movl	0x50(%rsp), %r12d
   11c3f:      	movl	%r15d, %edx
   11c42:      	subl	%r12d, %edx
   11c45:      	movl	$0x0, %ecx
   11c4a:      	cmovbl	%ecx, %edx
   11c4d:      	addq	0x60(%rsp), %rdx
   11c52:      	xorl	%esi, %esi
   11c54:      	cmpl	%r15d, %r12d
   11c57:      	seta	%sil
   11c5b:      	movl	%r15d, %ecx
   11c5e:      	cmovbl	%r12d, %ecx
   11c62:      	addl	%ecx, %esi
   11c64:      	movl	%r12d, %edi
   11c67:      	subl	%esi, %edi
   11c69:      	movl	%edi, 0x50(%rsp)
   11c6d:      	subq	%rsi, %rax
   11c70:      	jb	0x17392 <generic_kprobe_path+0xba72>
   11c76:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11c7c:      	ja	0x17392 <generic_kprobe_path+0xba72>
   11c82:      	cmpl	%r15d, %r12d
   11c85:      	jbe	0x11c8b <generic_kprobe_path+0x636b>
   11c87:      	movb	$0x2f, (%rbx,%rax)
   11c8b:      	xorl	%edi, %edi
   11c8d:      	cmpl	%r15d, %r12d
   11c90:      	seta	%dil
   11c94:      	movzbl	%cl, %esi
   11c97:      	addq	%rax, %rbx
   11c9a:      	addq	%rbx, %rdi
   11c9d:      	movl	$0x4, %eax
   11ca2:      	callq	*%rax
   11ca4:      	movq	%rbx, 0x48(%rsp)
   11ca9:      	cmpl	%r15d, %r12d
   11cac:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   11cb2:      	movq	0x8(%rsp), %r12
   11cb7:      	movq	%r12, 0x30(%rsp)
   11cbc:      	movq	0x38(%rsp), %rdx
   11cc1:      	movq	0x40(%rsp), %r15
   11cc6:      	jmp	0x11d19 <generic_kprobe_path+0x63f9>
   11cc8:      	leaq	0x10(%r15), %rdx
   11ccc:      	movl	$0x4, %eax
   11cd1:      	movq	%rbp, %rdi
   11cd4:      	movl	$0x8, %esi
   11cd9:      	callq	*%rax
   11cdb:      	movq	0x40(%rsp), %rax
   11ce0:      	cmpq	(%rsp), %rax
   11ce4:      	je	0x1738d <generic_kprobe_path+0xba6d>
   11cea:      	addq	$0x18, %r15
   11cee:      	movl	$0x4, %eax
   11cf3:      	leaq	0x30(%rsp), %rdi
   11cf8:      	movl	$0x8, %esi
   11cfd:      	movq	%r15, %rdx
   11d00:      	callq	*%rax
   11d02:      	movq	(%rsp), %r15
   11d06:      	movq	%r15, 0x40(%rsp)
   11d0b:      	leaq	0x20(%r15), %rdx
   11d0f:      	movq	%rdx, 0x38(%rsp)
   11d14:      	movq	0x30(%rsp), %r12
   11d19:      	cmpq	0x18(%rsp), %r12
   11d1e:      	jne	0x11d2b <generic_kprobe_path+0x640b>
   11d20:      	cmpq	0x20(%rsp), %rdx
   11d25:      	je	0x1738d <generic_kprobe_path+0xba6d>
   11d2b:      	movl	$0x4, %eax
   11d30:      	leaq	0x10(%rsp), %rdi
   11d35:      	movl	$0x8, %esi
   11d3a:      	callq	*%rax
   11d3c:      	cmpq	0x10(%rsp), %r12
   11d41:      	je	0x11e39 <generic_kprobe_path+0x6519>
   11d47:      	leaq	0x18(%r12), %rbx
   11d4c:      	movl	$0x4, %eax
   11d51:      	movq	%rbp, %rdi
   11d54:      	movl	$0x8, %esi
   11d59:      	movq	%rbx, %rdx
   11d5c:      	callq	*%rax
   11d5e:      	cmpq	%r12, (%rsp)
   11d62:      	je	0x11e39 <generic_kprobe_path+0x6519>
   11d68:      	movl	$0x4, %eax
   11d6d:      	leaq	0x8(%rsp), %rdi
   11d72:      	movl	$0x8, %esi
   11d77:      	movq	%rbx, %rdx
   11d7a:      	callq	*%rax
   11d7c:      	addq	$0x20, %r12
   11d80:      	movl	$0x4, %eax
   11d85:      	leaq	0x58(%rsp), %rdi
   11d8a:      	movl	$0x10, %ecx
   11d8f:      	movl	$0x10, %esi
   11d94:      	movq	%r12, %rdx
   11d97:      	callq	*%rax
   11d99:      	movq	0x28(%rsp), %rbx
   11d9e:      	movq	0x48(%rsp), %rax
   11da3:      	movl	0x5c(%rsp), %r15d
   11da8:      	subq	%rbx, %rax
   11dab:      	movl	0x50(%rsp), %r12d
   11db0:      	movl	%r15d, %edx
   11db3:      	subl	%r12d, %edx
   11db6:      	movl	$0x0, %ecx
   11dbb:      	cmovbl	%ecx, %edx
   11dbe:      	addq	0x60(%rsp), %rdx
   11dc3:      	xorl	%esi, %esi
   11dc5:      	cmpl	%r15d, %r12d
   11dc8:      	seta	%sil
   11dcc:      	movl	%r15d, %ecx
   11dcf:      	cmovbl	%r12d, %ecx
   11dd3:      	addl	%ecx, %esi
   11dd5:      	movl	%r12d, %edi
   11dd8:      	subl	%esi, %edi
   11dda:      	movl	%edi, 0x50(%rsp)
   11dde:      	subq	%rsi, %rax
   11de1:      	jb	0x17392 <generic_kprobe_path+0xba72>
   11de7:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11ded:      	ja	0x17392 <generic_kprobe_path+0xba72>
   11df3:      	cmpl	%r15d, %r12d
   11df6:      	jbe	0x11dfc <generic_kprobe_path+0x64dc>
   11df8:      	movb	$0x2f, (%rbx,%rax)
   11dfc:      	xorl	%edi, %edi
   11dfe:      	cmpl	%r15d, %r12d
   11e01:      	seta	%dil
   11e05:      	movzbl	%cl, %esi
   11e08:      	addq	%rax, %rbx
   11e0b:      	addq	%rbx, %rdi
   11e0e:      	movl	$0x4, %eax
   11e13:      	callq	*%rax
   11e15:      	movq	%rbx, 0x48(%rsp)
   11e1a:      	cmpl	%r15d, %r12d
   11e1d:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   11e23:      	movq	0x8(%rsp), %r12
   11e28:      	movq	%r12, 0x30(%rsp)
   11e2d:      	movq	0x38(%rsp), %rdx
   11e32:      	movq	0x40(%rsp), %r15
   11e37:      	jmp	0x11e8a <generic_kprobe_path+0x656a>
   11e39:      	leaq	0x10(%r15), %rdx
   11e3d:      	movl	$0x4, %eax
   11e42:      	movq	%rbp, %rdi
   11e45:      	movl	$0x8, %esi
   11e4a:      	callq	*%rax
   11e4c:      	movq	0x40(%rsp), %rax
   11e51:      	cmpq	(%rsp), %rax
   11e55:      	je	0x1738d <generic_kprobe_path+0xba6d>
   11e5b:      	addq	$0x18, %r15
   11e5f:      	movl	$0x4, %eax
   11e64:      	leaq	0x30(%rsp), %rdi
   11e69:      	movl	$0x8, %esi
   11e6e:      	movq	%r15, %rdx
   11e71:      	callq	*%rax
   11e73:      	movq	(%rsp), %r15
   11e77:      	movq	%r15, 0x40(%rsp)
   11e7c:      	leaq	0x20(%r15), %rdx
   11e80:      	movq	%rdx, 0x38(%rsp)
   11e85:      	movq	0x30(%rsp), %r12
   11e8a:      	cmpq	0x18(%rsp), %r12
   11e8f:      	jne	0x11e9c <generic_kprobe_path+0x657c>
   11e91:      	cmpq	0x20(%rsp), %rdx
   11e96:      	je	0x1738d <generic_kprobe_path+0xba6d>
   11e9c:      	movl	$0x4, %eax
   11ea1:      	leaq	0x10(%rsp), %rdi
   11ea6:      	movl	$0x8, %esi
   11eab:      	callq	*%rax
   11ead:      	cmpq	0x10(%rsp), %r12
   11eb2:      	je	0x11faa <generic_kprobe_path+0x668a>
   11eb8:      	leaq	0x18(%r12), %rbx
   11ebd:      	movl	$0x4, %eax
   11ec2:      	movq	%rbp, %rdi
   11ec5:      	movl	$0x8, %esi
   11eca:      	movq	%rbx, %rdx
   11ecd:      	callq	*%rax
   11ecf:      	cmpq	%r12, (%rsp)
   11ed3:      	je	0x11faa <generic_kprobe_path+0x668a>
   11ed9:      	movl	$0x4, %eax
   11ede:      	leaq	0x8(%rsp), %rdi
   11ee3:      	movl	$0x8, %esi
   11ee8:      	movq	%rbx, %rdx
   11eeb:      	callq	*%rax
   11eed:      	addq	$0x20, %r12
   11ef1:      	movl	$0x4, %eax
   11ef6:      	leaq	0x58(%rsp), %rdi
   11efb:      	movl	$0x10, %ecx
   11f00:      	movl	$0x10, %esi
   11f05:      	movq	%r12, %rdx
   11f08:      	callq	*%rax
   11f0a:      	movq	0x28(%rsp), %rbx
   11f0f:      	movq	0x48(%rsp), %rax
   11f14:      	movl	0x5c(%rsp), %r15d
   11f19:      	subq	%rbx, %rax
   11f1c:      	movl	0x50(%rsp), %r12d
   11f21:      	movl	%r15d, %edx
   11f24:      	subl	%r12d, %edx
   11f27:      	movl	$0x0, %ecx
   11f2c:      	cmovbl	%ecx, %edx
   11f2f:      	addq	0x60(%rsp), %rdx
   11f34:      	xorl	%esi, %esi
   11f36:      	cmpl	%r15d, %r12d
   11f39:      	seta	%sil
   11f3d:      	movl	%r15d, %ecx
   11f40:      	cmovbl	%r12d, %ecx
   11f44:      	addl	%ecx, %esi
   11f46:      	movl	%r12d, %edi
   11f49:      	subl	%esi, %edi
   11f4b:      	movl	%edi, 0x50(%rsp)
   11f4f:      	subq	%rsi, %rax
   11f52:      	jb	0x17392 <generic_kprobe_path+0xba72>
   11f58:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11f5e:      	ja	0x17392 <generic_kprobe_path+0xba72>
   11f64:      	cmpl	%r15d, %r12d
   11f67:      	jbe	0x11f6d <generic_kprobe_path+0x664d>
   11f69:      	movb	$0x2f, (%rbx,%rax)
   11f6d:      	xorl	%edi, %edi
   11f6f:      	cmpl	%r15d, %r12d
   11f72:      	seta	%dil
   11f76:      	movzbl	%cl, %esi
   11f79:      	addq	%rax, %rbx
   11f7c:      	addq	%rbx, %rdi
   11f7f:      	movl	$0x4, %eax
   11f84:      	callq	*%rax
   11f86:      	movq	%rbx, 0x48(%rsp)
   11f8b:      	cmpl	%r15d, %r12d
   11f8e:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   11f94:      	movq	0x8(%rsp), %r12
   11f99:      	movq	%r12, 0x30(%rsp)
   11f9e:      	movq	0x38(%rsp), %rdx
   11fa3:      	movq	0x40(%rsp), %r15
   11fa8:      	jmp	0x11ffb <generic_kprobe_path+0x66db>
   11faa:      	leaq	0x10(%r15), %rdx
   11fae:      	movl	$0x4, %eax
   11fb3:      	movq	%rbp, %rdi
   11fb6:      	movl	$0x8, %esi
   11fbb:      	callq	*%rax
   11fbd:      	movq	0x40(%rsp), %rax
   11fc2:      	cmpq	(%rsp), %rax
   11fc6:      	je	0x1738d <generic_kprobe_path+0xba6d>
   11fcc:      	addq	$0x18, %r15
   11fd0:      	movl	$0x4, %eax
   11fd5:      	leaq	0x30(%rsp), %rdi
   11fda:      	movl	$0x8, %esi
   11fdf:      	movq	%r15, %rdx
   11fe2:      	callq	*%rax
   11fe4:      	movq	(%rsp), %r15
   11fe8:      	movq	%r15, 0x40(%rsp)
   11fed:      	leaq	0x20(%r15), %rdx
   11ff1:      	movq	%rdx, 0x38(%rsp)
   11ff6:      	movq	0x30(%rsp), %r12
   11ffb:      	cmpq	0x18(%rsp), %r12
   12000:      	jne	0x1200d <generic_kprobe_path+0x66ed>
   12002:      	cmpq	0x20(%rsp), %rdx
   12007:      	je	0x1738d <generic_kprobe_path+0xba6d>
   1200d:      	movl	$0x4, %eax
   12012:      	leaq	0x10(%rsp), %rdi
   12017:      	movl	$0x8, %esi
   1201c:      	callq	*%rax
   1201e:      	cmpq	0x10(%rsp), %r12
   12023:      	je	0x1211b <generic_kprobe_path+0x67fb>
   12029:      	leaq	0x18(%r12), %rbx
   1202e:      	movl	$0x4, %eax
   12033:      	movq	%rbp, %rdi
   12036:      	movl	$0x8, %esi
   1203b:      	movq	%rbx, %rdx
   1203e:      	callq	*%rax
   12040:      	cmpq	%r12, (%rsp)
   12044:      	je	0x1211b <generic_kprobe_path+0x67fb>
   1204a:      	movl	$0x4, %eax
   1204f:      	leaq	0x8(%rsp), %rdi
   12054:      	movl	$0x8, %esi
   12059:      	movq	%rbx, %rdx
   1205c:      	callq	*%rax
   1205e:      	addq	$0x20, %r12
   12062:      	movl	$0x4, %eax
   12067:      	leaq	0x58(%rsp), %rdi
   1206c:      	movl	$0x10, %ecx
   12071:      	movl	$0x10, %esi
   12076:      	movq	%r12, %rdx
   12079:      	callq	*%rax
   1207b:      	movq	0x28(%rsp), %rbx
   12080:      	movq	0x48(%rsp), %rax
   12085:      	movl	0x5c(%rsp), %r15d
   1208a:      	subq	%rbx, %rax
   1208d:      	movl	0x50(%rsp), %r12d
   12092:      	movl	%r15d, %edx
   12095:      	subl	%r12d, %edx
   12098:      	movl	$0x0, %ecx
   1209d:      	cmovbl	%ecx, %edx
   120a0:      	addq	0x60(%rsp), %rdx
   120a5:      	xorl	%esi, %esi
   120a7:      	cmpl	%r15d, %r12d
   120aa:      	seta	%sil
   120ae:      	movl	%r15d, %ecx
   120b1:      	cmovbl	%r12d, %ecx
   120b5:      	addl	%ecx, %esi
   120b7:      	movl	%r12d, %edi
   120ba:      	subl	%esi, %edi
   120bc:      	movl	%edi, 0x50(%rsp)
   120c0:      	subq	%rsi, %rax
   120c3:      	jb	0x17392 <generic_kprobe_path+0xba72>
   120c9:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   120cf:      	ja	0x17392 <generic_kprobe_path+0xba72>
   120d5:      	cmpl	%r15d, %r12d
   120d8:      	jbe	0x120de <generic_kprobe_path+0x67be>
   120da:      	movb	$0x2f, (%rbx,%rax)
   120de:      	xorl	%edi, %edi
   120e0:      	cmpl	%r15d, %r12d
   120e3:      	seta	%dil
   120e7:      	movzbl	%cl, %esi
   120ea:      	addq	%rax, %rbx
   120ed:      	addq	%rbx, %rdi
   120f0:      	movl	$0x4, %eax
   120f5:      	callq	*%rax
   120f7:      	movq	%rbx, 0x48(%rsp)
   120fc:      	cmpl	%r15d, %r12d
   120ff:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   12105:      	movq	0x8(%rsp), %r12
   1210a:      	movq	%r12, 0x30(%rsp)
   1210f:      	movq	0x38(%rsp), %rdx
   12114:      	movq	0x40(%rsp), %r15
   12119:      	jmp	0x1216c <generic_kprobe_path+0x684c>
   1211b:      	leaq	0x10(%r15), %rdx
   1211f:      	movl	$0x4, %eax
   12124:      	movq	%rbp, %rdi
   12127:      	movl	$0x8, %esi
   1212c:      	callq	*%rax
   1212e:      	movq	0x40(%rsp), %rax
   12133:      	cmpq	(%rsp), %rax
   12137:      	je	0x1738d <generic_kprobe_path+0xba6d>
   1213d:      	addq	$0x18, %r15
   12141:      	movl	$0x4, %eax
   12146:      	leaq	0x30(%rsp), %rdi
   1214b:      	movl	$0x8, %esi
   12150:      	movq	%r15, %rdx
   12153:      	callq	*%rax
   12155:      	movq	(%rsp), %r15
   12159:      	movq	%r15, 0x40(%rsp)
   1215e:      	leaq	0x20(%r15), %rdx
   12162:      	movq	%rdx, 0x38(%rsp)
   12167:      	movq	0x30(%rsp), %r12
   1216c:      	cmpq	0x18(%rsp), %r12
   12171:      	jne	0x1217e <generic_kprobe_path+0x685e>
   12173:      	cmpq	0x20(%rsp), %rdx
   12178:      	je	0x1738d <generic_kprobe_path+0xba6d>
   1217e:      	movl	$0x4, %eax
   12183:      	leaq	0x10(%rsp), %rdi
   12188:      	movl	$0x8, %esi
   1218d:      	callq	*%rax
   1218f:      	cmpq	0x10(%rsp), %r12
   12194:      	je	0x1228c <generic_kprobe_path+0x696c>
   1219a:      	leaq	0x18(%r12), %rbx
   1219f:      	movl	$0x4, %eax
   121a4:      	movq	%rbp, %rdi
   121a7:      	movl	$0x8, %esi
   121ac:      	movq	%rbx, %rdx
   121af:      	callq	*%rax
   121b1:      	cmpq	%r12, (%rsp)
   121b5:      	je	0x1228c <generic_kprobe_path+0x696c>
   121bb:      	movl	$0x4, %eax
   121c0:      	leaq	0x8(%rsp), %rdi
   121c5:      	movl	$0x8, %esi
   121ca:      	movq	%rbx, %rdx
   121cd:      	callq	*%rax
   121cf:      	addq	$0x20, %r12
   121d3:      	movl	$0x4, %eax
   121d8:      	leaq	0x58(%rsp), %rdi
   121dd:      	movl	$0x10, %ecx
   121e2:      	movl	$0x10, %esi
   121e7:      	movq	%r12, %rdx
   121ea:      	callq	*%rax
   121ec:      	movq	0x28(%rsp), %rbx
   121f1:      	movq	0x48(%rsp), %rax
   121f6:      	movl	0x5c(%rsp), %r15d
   121fb:      	subq	%rbx, %rax
   121fe:      	movl	0x50(%rsp), %r12d
   12203:      	movl	%r15d, %edx
   12206:      	subl	%r12d, %edx
   12209:      	movl	$0x0, %ecx
   1220e:      	cmovbl	%ecx, %edx
   12211:      	addq	0x60(%rsp), %rdx
   12216:      	xorl	%esi, %esi
   12218:      	cmpl	%r15d, %r12d
   1221b:      	seta	%sil
   1221f:      	movl	%r15d, %ecx
   12222:      	cmovbl	%r12d, %ecx
   12226:      	addl	%ecx, %esi
   12228:      	movl	%r12d, %edi
   1222b:      	subl	%esi, %edi
   1222d:      	movl	%edi, 0x50(%rsp)
   12231:      	subq	%rsi, %rax
   12234:      	jb	0x17392 <generic_kprobe_path+0xba72>
   1223a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12240:      	ja	0x17392 <generic_kprobe_path+0xba72>
   12246:      	cmpl	%r15d, %r12d
   12249:      	jbe	0x1224f <generic_kprobe_path+0x692f>
   1224b:      	movb	$0x2f, (%rbx,%rax)
   1224f:      	xorl	%edi, %edi
   12251:      	cmpl	%r15d, %r12d
   12254:      	seta	%dil
   12258:      	movzbl	%cl, %esi
   1225b:      	addq	%rax, %rbx
   1225e:      	addq	%rbx, %rdi
   12261:      	movl	$0x4, %eax
   12266:      	callq	*%rax
   12268:      	movq	%rbx, 0x48(%rsp)
   1226d:      	cmpl	%r15d, %r12d
   12270:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   12276:      	movq	0x8(%rsp), %r12
   1227b:      	movq	%r12, 0x30(%rsp)
   12280:      	movq	0x38(%rsp), %rdx
   12285:      	movq	0x40(%rsp), %r15
   1228a:      	jmp	0x122dd <generic_kprobe_path+0x69bd>
   1228c:      	leaq	0x10(%r15), %rdx
   12290:      	movl	$0x4, %eax
   12295:      	movq	%rbp, %rdi
   12298:      	movl	$0x8, %esi
   1229d:      	callq	*%rax
   1229f:      	movq	0x40(%rsp), %rax
   122a4:      	cmpq	(%rsp), %rax
   122a8:      	je	0x1738d <generic_kprobe_path+0xba6d>
   122ae:      	addq	$0x18, %r15
   122b2:      	movl	$0x4, %eax
   122b7:      	leaq	0x30(%rsp), %rdi
   122bc:      	movl	$0x8, %esi
   122c1:      	movq	%r15, %rdx
   122c4:      	callq	*%rax
   122c6:      	movq	(%rsp), %r15
   122ca:      	movq	%r15, 0x40(%rsp)
   122cf:      	leaq	0x20(%r15), %rdx
   122d3:      	movq	%rdx, 0x38(%rsp)
   122d8:      	movq	0x30(%rsp), %r12
   122dd:      	cmpq	0x18(%rsp), %r12
   122e2:      	jne	0x122ef <generic_kprobe_path+0x69cf>
   122e4:      	cmpq	0x20(%rsp), %rdx
   122e9:      	je	0x1738d <generic_kprobe_path+0xba6d>
   122ef:      	movl	$0x4, %eax
   122f4:      	leaq	0x10(%rsp), %rdi
   122f9:      	movl	$0x8, %esi
   122fe:      	callq	*%rax
   12300:      	cmpq	0x10(%rsp), %r12
   12305:      	je	0x123fd <generic_kprobe_path+0x6add>
   1230b:      	leaq	0x18(%r12), %rbx
   12310:      	movl	$0x4, %eax
   12315:      	movq	%rbp, %rdi
   12318:      	movl	$0x8, %esi
   1231d:      	movq	%rbx, %rdx
   12320:      	callq	*%rax
   12322:      	cmpq	%r12, (%rsp)
   12326:      	je	0x123fd <generic_kprobe_path+0x6add>
   1232c:      	movl	$0x4, %eax
   12331:      	leaq	0x8(%rsp), %rdi
   12336:      	movl	$0x8, %esi
   1233b:      	movq	%rbx, %rdx
   1233e:      	callq	*%rax
   12340:      	addq	$0x20, %r12
   12344:      	movl	$0x4, %eax
   12349:      	leaq	0x58(%rsp), %rdi
   1234e:      	movl	$0x10, %ecx
   12353:      	movl	$0x10, %esi
   12358:      	movq	%r12, %rdx
   1235b:      	callq	*%rax
   1235d:      	movq	0x28(%rsp), %rbx
   12362:      	movq	0x48(%rsp), %rax
   12367:      	movl	0x5c(%rsp), %r15d
   1236c:      	subq	%rbx, %rax
   1236f:      	movl	0x50(%rsp), %r12d
   12374:      	movl	%r15d, %edx
   12377:      	subl	%r12d, %edx
   1237a:      	movl	$0x0, %ecx
   1237f:      	cmovbl	%ecx, %edx
   12382:      	addq	0x60(%rsp), %rdx
   12387:      	xorl	%esi, %esi
   12389:      	cmpl	%r15d, %r12d
   1238c:      	seta	%sil
   12390:      	movl	%r15d, %ecx
   12393:      	cmovbl	%r12d, %ecx
   12397:      	addl	%ecx, %esi
   12399:      	movl	%r12d, %edi
   1239c:      	subl	%esi, %edi
   1239e:      	movl	%edi, 0x50(%rsp)
   123a2:      	subq	%rsi, %rax
   123a5:      	jb	0x17392 <generic_kprobe_path+0xba72>
   123ab:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   123b1:      	ja	0x17392 <generic_kprobe_path+0xba72>
   123b7:      	cmpl	%r15d, %r12d
   123ba:      	jbe	0x123c0 <generic_kprobe_path+0x6aa0>
   123bc:      	movb	$0x2f, (%rbx,%rax)
   123c0:      	xorl	%edi, %edi
   123c2:      	cmpl	%r15d, %r12d
   123c5:      	seta	%dil
   123c9:      	movzbl	%cl, %esi
   123cc:      	addq	%rax, %rbx
   123cf:      	addq	%rbx, %rdi
   123d2:      	movl	$0x4, %eax
   123d7:      	callq	*%rax
   123d9:      	movq	%rbx, 0x48(%rsp)
   123de:      	cmpl	%r15d, %r12d
   123e1:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   123e7:      	movq	0x8(%rsp), %r12
   123ec:      	movq	%r12, 0x30(%rsp)
   123f1:      	movq	0x38(%rsp), %rdx
   123f6:      	movq	0x40(%rsp), %r15
   123fb:      	jmp	0x1244e <generic_kprobe_path+0x6b2e>
   123fd:      	leaq	0x10(%r15), %rdx
   12401:      	movl	$0x4, %eax
   12406:      	movq	%rbp, %rdi
   12409:      	movl	$0x8, %esi
   1240e:      	callq	*%rax
   12410:      	movq	0x40(%rsp), %rax
   12415:      	cmpq	(%rsp), %rax
   12419:      	je	0x1738d <generic_kprobe_path+0xba6d>
   1241f:      	addq	$0x18, %r15
   12423:      	movl	$0x4, %eax
   12428:      	leaq	0x30(%rsp), %rdi
   1242d:      	movl	$0x8, %esi
   12432:      	movq	%r15, %rdx
   12435:      	callq	*%rax
   12437:      	movq	(%rsp), %r15
   1243b:      	movq	%r15, 0x40(%rsp)
   12440:      	leaq	0x20(%r15), %rdx
   12444:      	movq	%rdx, 0x38(%rsp)
   12449:      	movq	0x30(%rsp), %r12
   1244e:      	cmpq	0x18(%rsp), %r12
   12453:      	jne	0x12460 <generic_kprobe_path+0x6b40>
   12455:      	cmpq	0x20(%rsp), %rdx
   1245a:      	je	0x1738d <generic_kprobe_path+0xba6d>
   12460:      	movl	$0x4, %eax
   12465:      	leaq	0x10(%rsp), %rdi
   1246a:      	movl	$0x8, %esi
   1246f:      	callq	*%rax
   12471:      	cmpq	0x10(%rsp), %r12
   12476:      	je	0x1256e <generic_kprobe_path+0x6c4e>
   1247c:      	leaq	0x18(%r12), %rbx
   12481:      	movl	$0x4, %eax
   12486:      	movq	%rbp, %rdi
   12489:      	movl	$0x8, %esi
   1248e:      	movq	%rbx, %rdx
   12491:      	callq	*%rax
   12493:      	cmpq	%r12, (%rsp)
   12497:      	je	0x1256e <generic_kprobe_path+0x6c4e>
   1249d:      	movl	$0x4, %eax
   124a2:      	leaq	0x8(%rsp), %rdi
   124a7:      	movl	$0x8, %esi
   124ac:      	movq	%rbx, %rdx
   124af:      	callq	*%rax
   124b1:      	addq	$0x20, %r12
   124b5:      	movl	$0x4, %eax
   124ba:      	leaq	0x58(%rsp), %rdi
   124bf:      	movl	$0x10, %ecx
   124c4:      	movl	$0x10, %esi
   124c9:      	movq	%r12, %rdx
   124cc:      	callq	*%rax
   124ce:      	movq	0x28(%rsp), %rbx
   124d3:      	movq	0x48(%rsp), %rax
   124d8:      	movl	0x5c(%rsp), %r15d
   124dd:      	subq	%rbx, %rax
   124e0:      	movl	0x50(%rsp), %r12d
   124e5:      	movl	%r15d, %edx
   124e8:      	subl	%r12d, %edx
   124eb:      	movl	$0x0, %ecx
   124f0:      	cmovbl	%ecx, %edx
   124f3:      	addq	0x60(%rsp), %rdx
   124f8:      	xorl	%esi, %esi
   124fa:      	cmpl	%r15d, %r12d
   124fd:      	seta	%sil
   12501:      	movl	%r15d, %ecx
   12504:      	cmovbl	%r12d, %ecx
   12508:      	addl	%ecx, %esi
   1250a:      	movl	%r12d, %edi
   1250d:      	subl	%esi, %edi
   1250f:      	movl	%edi, 0x50(%rsp)
   12513:      	subq	%rsi, %rax
   12516:      	jb	0x17392 <generic_kprobe_path+0xba72>
   1251c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12522:      	ja	0x17392 <generic_kprobe_path+0xba72>
   12528:      	cmpl	%r15d, %r12d
   1252b:      	jbe	0x12531 <generic_kprobe_path+0x6c11>
   1252d:      	movb	$0x2f, (%rbx,%rax)
   12531:      	xorl	%edi, %edi
   12533:      	cmpl	%r15d, %r12d
   12536:      	seta	%dil
   1253a:      	movzbl	%cl, %esi
   1253d:      	addq	%rax, %rbx
   12540:      	addq	%rbx, %rdi
   12543:      	movl	$0x4, %eax
   12548:      	callq	*%rax
   1254a:      	movq	%rbx, 0x48(%rsp)
   1254f:      	cmpl	%r15d, %r12d
   12552:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   12558:      	movq	0x8(%rsp), %r12
   1255d:      	movq	%r12, 0x30(%rsp)
   12562:      	movq	0x38(%rsp), %rdx
   12567:      	movq	0x40(%rsp), %r15
   1256c:      	jmp	0x125bf <generic_kprobe_path+0x6c9f>
   1256e:      	leaq	0x10(%r15), %rdx
   12572:      	movl	$0x4, %eax
   12577:      	movq	%rbp, %rdi
   1257a:      	movl	$0x8, %esi
   1257f:      	callq	*%rax
   12581:      	movq	0x40(%rsp), %rax
   12586:      	cmpq	(%rsp), %rax
   1258a:      	je	0x1738d <generic_kprobe_path+0xba6d>
   12590:      	addq	$0x18, %r15
   12594:      	movl	$0x4, %eax
   12599:      	leaq	0x30(%rsp), %rdi
   1259e:      	movl	$0x8, %esi
   125a3:      	movq	%r15, %rdx
   125a6:      	callq	*%rax
   125a8:      	movq	(%rsp), %r15
   125ac:      	movq	%r15, 0x40(%rsp)
   125b1:      	leaq	0x20(%r15), %rdx
   125b5:      	movq	%rdx, 0x38(%rsp)
   125ba:      	movq	0x30(%rsp), %r12
   125bf:      	cmpq	0x18(%rsp), %r12
   125c4:      	jne	0x125d1 <generic_kprobe_path+0x6cb1>
   125c6:      	cmpq	0x20(%rsp), %rdx
   125cb:      	je	0x1738d <generic_kprobe_path+0xba6d>
   125d1:      	movl	$0x4, %eax
   125d6:      	leaq	0x10(%rsp), %rdi
   125db:      	movl	$0x8, %esi
   125e0:      	callq	*%rax
   125e2:      	cmpq	0x10(%rsp), %r12
   125e7:      	je	0x126df <generic_kprobe_path+0x6dbf>
   125ed:      	leaq	0x18(%r12), %rbx
   125f2:      	movl	$0x4, %eax
   125f7:      	movq	%rbp, %rdi
   125fa:      	movl	$0x8, %esi
   125ff:      	movq	%rbx, %rdx
   12602:      	callq	*%rax
   12604:      	cmpq	%r12, (%rsp)
   12608:      	je	0x126df <generic_kprobe_path+0x6dbf>
   1260e:      	movl	$0x4, %eax
   12613:      	leaq	0x8(%rsp), %rdi
   12618:      	movl	$0x8, %esi
   1261d:      	movq	%rbx, %rdx
   12620:      	callq	*%rax
   12622:      	addq	$0x20, %r12
   12626:      	movl	$0x4, %eax
   1262b:      	leaq	0x58(%rsp), %rdi
   12630:      	movl	$0x10, %ecx
   12635:      	movl	$0x10, %esi
   1263a:      	movq	%r12, %rdx
   1263d:      	callq	*%rax
   1263f:      	movq	0x28(%rsp), %rbx
   12644:      	movq	0x48(%rsp), %rax
   12649:      	movl	0x5c(%rsp), %r15d
   1264e:      	subq	%rbx, %rax
   12651:      	movl	0x50(%rsp), %r12d
   12656:      	movl	%r15d, %edx
   12659:      	subl	%r12d, %edx
   1265c:      	movl	$0x0, %ecx
   12661:      	cmovbl	%ecx, %edx
   12664:      	addq	0x60(%rsp), %rdx
   12669:      	xorl	%esi, %esi
   1266b:      	cmpl	%r15d, %r12d
   1266e:      	seta	%sil
   12672:      	movl	%r15d, %ecx
   12675:      	cmovbl	%r12d, %ecx
   12679:      	addl	%ecx, %esi
   1267b:      	movl	%r12d, %edi
   1267e:      	subl	%esi, %edi
   12680:      	movl	%edi, 0x50(%rsp)
   12684:      	subq	%rsi, %rax
   12687:      	jb	0x17392 <generic_kprobe_path+0xba72>
   1268d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12693:      	ja	0x17392 <generic_kprobe_path+0xba72>
   12699:      	cmpl	%r15d, %r12d
   1269c:      	jbe	0x126a2 <generic_kprobe_path+0x6d82>
   1269e:      	movb	$0x2f, (%rbx,%rax)
   126a2:      	xorl	%edi, %edi
   126a4:      	cmpl	%r15d, %r12d
   126a7:      	seta	%dil
   126ab:      	movzbl	%cl, %esi
   126ae:      	addq	%rax, %rbx
   126b1:      	addq	%rbx, %rdi
   126b4:      	movl	$0x4, %eax
   126b9:      	callq	*%rax
   126bb:      	movq	%rbx, 0x48(%rsp)
   126c0:      	cmpl	%r15d, %r12d
   126c3:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   126c9:      	movq	0x8(%rsp), %r12
   126ce:      	movq	%r12, 0x30(%rsp)
   126d3:      	movq	0x38(%rsp), %rdx
   126d8:      	movq	0x40(%rsp), %r15
   126dd:      	jmp	0x12730 <generic_kprobe_path+0x6e10>
   126df:      	leaq	0x10(%r15), %rdx
   126e3:      	movl	$0x4, %eax
   126e8:      	movq	%rbp, %rdi
   126eb:      	movl	$0x8, %esi
   126f0:      	callq	*%rax
   126f2:      	movq	0x40(%rsp), %rax
   126f7:      	cmpq	(%rsp), %rax
   126fb:      	je	0x1738d <generic_kprobe_path+0xba6d>
   12701:      	addq	$0x18, %r15
   12705:      	movl	$0x4, %eax
   1270a:      	leaq	0x30(%rsp), %rdi
   1270f:      	movl	$0x8, %esi
   12714:      	movq	%r15, %rdx
   12717:      	callq	*%rax
   12719:      	movq	(%rsp), %r15
   1271d:      	movq	%r15, 0x40(%rsp)
   12722:      	leaq	0x20(%r15), %rdx
   12726:      	movq	%rdx, 0x38(%rsp)
   1272b:      	movq	0x30(%rsp), %r12
   12730:      	cmpq	0x18(%rsp), %r12
   12735:      	jne	0x12742 <generic_kprobe_path+0x6e22>
   12737:      	cmpq	0x20(%rsp), %rdx
   1273c:      	je	0x1738d <generic_kprobe_path+0xba6d>
   12742:      	movl	$0x4, %eax
   12747:      	leaq	0x10(%rsp), %rdi
   1274c:      	movl	$0x8, %esi
   12751:      	callq	*%rax
   12753:      	cmpq	0x10(%rsp), %r12
   12758:      	je	0x12850 <generic_kprobe_path+0x6f30>
   1275e:      	leaq	0x18(%r12), %rbx
   12763:      	movl	$0x4, %eax
   12768:      	movq	%rbp, %rdi
   1276b:      	movl	$0x8, %esi
   12770:      	movq	%rbx, %rdx
   12773:      	callq	*%rax
   12775:      	cmpq	%r12, (%rsp)
   12779:      	je	0x12850 <generic_kprobe_path+0x6f30>
   1277f:      	movl	$0x4, %eax
   12784:      	leaq	0x8(%rsp), %rdi
   12789:      	movl	$0x8, %esi
   1278e:      	movq	%rbx, %rdx
   12791:      	callq	*%rax
   12793:      	addq	$0x20, %r12
   12797:      	movl	$0x4, %eax
   1279c:      	leaq	0x58(%rsp), %rdi
   127a1:      	movl	$0x10, %ecx
   127a6:      	movl	$0x10, %esi
   127ab:      	movq	%r12, %rdx
   127ae:      	callq	*%rax
   127b0:      	movq	0x28(%rsp), %rbx
   127b5:      	movq	0x48(%rsp), %rax
   127ba:      	movl	0x5c(%rsp), %r15d
   127bf:      	subq	%rbx, %rax
   127c2:      	movl	0x50(%rsp), %r12d
   127c7:      	movl	%r15d, %edx
   127ca:      	subl	%r12d, %edx
   127cd:      	movl	$0x0, %ecx
   127d2:      	cmovbl	%ecx, %edx
   127d5:      	addq	0x60(%rsp), %rdx
   127da:      	xorl	%esi, %esi
   127dc:      	cmpl	%r15d, %r12d
   127df:      	seta	%sil
   127e3:      	movl	%r15d, %ecx
   127e6:      	cmovbl	%r12d, %ecx
   127ea:      	addl	%ecx, %esi
   127ec:      	movl	%r12d, %edi
   127ef:      	subl	%esi, %edi
   127f1:      	movl	%edi, 0x50(%rsp)
   127f5:      	subq	%rsi, %rax
   127f8:      	jb	0x17392 <generic_kprobe_path+0xba72>
   127fe:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12804:      	ja	0x17392 <generic_kprobe_path+0xba72>
   1280a:      	cmpl	%r15d, %r12d
   1280d:      	jbe	0x12813 <generic_kprobe_path+0x6ef3>
   1280f:      	movb	$0x2f, (%rbx,%rax)
   12813:      	xorl	%edi, %edi
   12815:      	cmpl	%r15d, %r12d
   12818:      	seta	%dil
   1281c:      	movzbl	%cl, %esi
   1281f:      	addq	%rax, %rbx
   12822:      	addq	%rbx, %rdi
   12825:      	movl	$0x4, %eax
   1282a:      	callq	*%rax
   1282c:      	movq	%rbx, 0x48(%rsp)
   12831:      	cmpl	%r15d, %r12d
   12834:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   1283a:      	movq	0x8(%rsp), %r12
   1283f:      	movq	%r12, 0x30(%rsp)
   12844:      	movq	0x38(%rsp), %rdx
   12849:      	movq	0x40(%rsp), %r15
   1284e:      	jmp	0x128a1 <generic_kprobe_path+0x6f81>
   12850:      	leaq	0x10(%r15), %rdx
   12854:      	movl	$0x4, %eax
   12859:      	movq	%rbp, %rdi
   1285c:      	movl	$0x8, %esi
   12861:      	callq	*%rax
   12863:      	movq	0x40(%rsp), %rax
   12868:      	cmpq	(%rsp), %rax
   1286c:      	je	0x1738d <generic_kprobe_path+0xba6d>
   12872:      	addq	$0x18, %r15
   12876:      	movl	$0x4, %eax
   1287b:      	leaq	0x30(%rsp), %rdi
   12880:      	movl	$0x8, %esi
   12885:      	movq	%r15, %rdx
   12888:      	callq	*%rax
   1288a:      	movq	(%rsp), %r15
   1288e:      	movq	%r15, 0x40(%rsp)
   12893:      	leaq	0x20(%r15), %rdx
   12897:      	movq	%rdx, 0x38(%rsp)
   1289c:      	movq	0x30(%rsp), %r12
   128a1:      	cmpq	0x18(%rsp), %r12
   128a6:      	jne	0x128b3 <generic_kprobe_path+0x6f93>
   128a8:      	cmpq	0x20(%rsp), %rdx
   128ad:      	je	0x1738d <generic_kprobe_path+0xba6d>
   128b3:      	movl	$0x4, %eax
   128b8:      	leaq	0x10(%rsp), %rdi
   128bd:      	movl	$0x8, %esi
   128c2:      	callq	*%rax
   128c4:      	cmpq	0x10(%rsp), %r12
   128c9:      	je	0x129c1 <generic_kprobe_path+0x70a1>
   128cf:      	leaq	0x18(%r12), %rbx
   128d4:      	movl	$0x4, %eax
   128d9:      	movq	%rbp, %rdi
   128dc:      	movl	$0x8, %esi
   128e1:      	movq	%rbx, %rdx
   128e4:      	callq	*%rax
   128e6:      	cmpq	%r12, (%rsp)
   128ea:      	je	0x129c1 <generic_kprobe_path+0x70a1>
   128f0:      	movl	$0x4, %eax
   128f5:      	leaq	0x8(%rsp), %rdi
   128fa:      	movl	$0x8, %esi
   128ff:      	movq	%rbx, %rdx
   12902:      	callq	*%rax
   12904:      	addq	$0x20, %r12
   12908:      	movl	$0x4, %eax
   1290d:      	leaq	0x58(%rsp), %rdi
   12912:      	movl	$0x10, %ecx
   12917:      	movl	$0x10, %esi
   1291c:      	movq	%r12, %rdx
   1291f:      	callq	*%rax
   12921:      	movq	0x28(%rsp), %rbx
   12926:      	movq	0x48(%rsp), %rax
   1292b:      	movl	0x5c(%rsp), %r15d
   12930:      	subq	%rbx, %rax
   12933:      	movl	0x50(%rsp), %r12d
   12938:      	movl	%r15d, %edx
   1293b:      	subl	%r12d, %edx
   1293e:      	movl	$0x0, %ecx
   12943:      	cmovbl	%ecx, %edx
   12946:      	addq	0x60(%rsp), %rdx
   1294b:      	xorl	%esi, %esi
   1294d:      	cmpl	%r15d, %r12d
   12950:      	seta	%sil
   12954:      	movl	%r15d, %ecx
   12957:      	cmovbl	%r12d, %ecx
   1295b:      	addl	%ecx, %esi
   1295d:      	movl	%r12d, %edi
   12960:      	subl	%esi, %edi
   12962:      	movl	%edi, 0x50(%rsp)
   12966:      	subq	%rsi, %rax
   12969:      	jb	0x17392 <generic_kprobe_path+0xba72>
   1296f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12975:      	ja	0x17392 <generic_kprobe_path+0xba72>
   1297b:      	cmpl	%r15d, %r12d
   1297e:      	jbe	0x12984 <generic_kprobe_path+0x7064>
   12980:      	movb	$0x2f, (%rbx,%rax)
   12984:      	xorl	%edi, %edi
   12986:      	cmpl	%r15d, %r12d
   12989:      	seta	%dil
   1298d:      	movzbl	%cl, %esi
   12990:      	addq	%rax, %rbx
   12993:      	addq	%rbx, %rdi
   12996:      	movl	$0x4, %eax
   1299b:      	callq	*%rax
   1299d:      	movq	%rbx, 0x48(%rsp)
   129a2:      	cmpl	%r15d, %r12d
   129a5:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   129ab:      	movq	0x8(%rsp), %r12
   129b0:      	movq	%r12, 0x30(%rsp)
   129b5:      	movq	0x38(%rsp), %rdx
   129ba:      	movq	0x40(%rsp), %r15
   129bf:      	jmp	0x12a12 <generic_kprobe_path+0x70f2>
   129c1:      	leaq	0x10(%r15), %rdx
   129c5:      	movl	$0x4, %eax
   129ca:      	movq	%rbp, %rdi
   129cd:      	movl	$0x8, %esi
   129d2:      	callq	*%rax
   129d4:      	movq	0x40(%rsp), %rax
   129d9:      	cmpq	(%rsp), %rax
   129dd:      	je	0x1738d <generic_kprobe_path+0xba6d>
   129e3:      	addq	$0x18, %r15
   129e7:      	movl	$0x4, %eax
   129ec:      	leaq	0x30(%rsp), %rdi
   129f1:      	movl	$0x8, %esi
   129f6:      	movq	%r15, %rdx
   129f9:      	callq	*%rax
   129fb:      	movq	(%rsp), %r15
   129ff:      	movq	%r15, 0x40(%rsp)
   12a04:      	leaq	0x20(%r15), %rdx
   12a08:      	movq	%rdx, 0x38(%rsp)
   12a0d:      	movq	0x30(%rsp), %r12
   12a12:      	cmpq	0x18(%rsp), %r12
   12a17:      	jne	0x12a24 <generic_kprobe_path+0x7104>
   12a19:      	cmpq	0x20(%rsp), %rdx
   12a1e:      	je	0x1738d <generic_kprobe_path+0xba6d>
   12a24:      	movl	$0x4, %eax
   12a29:      	leaq	0x10(%rsp), %rdi
   12a2e:      	movl	$0x8, %esi
   12a33:      	callq	*%rax
   12a35:      	cmpq	0x10(%rsp), %r12
   12a3a:      	je	0x12b32 <generic_kprobe_path+0x7212>
   12a40:      	leaq	0x18(%r12), %rbx
   12a45:      	movl	$0x4, %eax
   12a4a:      	movq	%rbp, %rdi
   12a4d:      	movl	$0x8, %esi
   12a52:      	movq	%rbx, %rdx
   12a55:      	callq	*%rax
   12a57:      	cmpq	%r12, (%rsp)
   12a5b:      	je	0x12b32 <generic_kprobe_path+0x7212>
   12a61:      	movl	$0x4, %eax
   12a66:      	leaq	0x8(%rsp), %rdi
   12a6b:      	movl	$0x8, %esi
   12a70:      	movq	%rbx, %rdx
   12a73:      	callq	*%rax
   12a75:      	addq	$0x20, %r12
   12a79:      	movl	$0x4, %eax
   12a7e:      	leaq	0x58(%rsp), %rdi
   12a83:      	movl	$0x10, %ecx
   12a88:      	movl	$0x10, %esi
   12a8d:      	movq	%r12, %rdx
   12a90:      	callq	*%rax
   12a92:      	movq	0x28(%rsp), %rbx
   12a97:      	movq	0x48(%rsp), %rax
   12a9c:      	movl	0x5c(%rsp), %r15d
   12aa1:      	subq	%rbx, %rax
   12aa4:      	movl	0x50(%rsp), %r12d
   12aa9:      	movl	%r15d, %edx
   12aac:      	subl	%r12d, %edx
   12aaf:      	movl	$0x0, %ecx
   12ab4:      	cmovbl	%ecx, %edx
   12ab7:      	addq	0x60(%rsp), %rdx
   12abc:      	xorl	%esi, %esi
   12abe:      	cmpl	%r15d, %r12d
   12ac1:      	seta	%sil
   12ac5:      	movl	%r15d, %ecx
   12ac8:      	cmovbl	%r12d, %ecx
   12acc:      	addl	%ecx, %esi
   12ace:      	movl	%r12d, %edi
   12ad1:      	subl	%esi, %edi
   12ad3:      	movl	%edi, 0x50(%rsp)
   12ad7:      	subq	%rsi, %rax
   12ada:      	jb	0x17392 <generic_kprobe_path+0xba72>
   12ae0:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12ae6:      	ja	0x17392 <generic_kprobe_path+0xba72>
   12aec:      	cmpl	%r15d, %r12d
   12aef:      	jbe	0x12af5 <generic_kprobe_path+0x71d5>
   12af1:      	movb	$0x2f, (%rbx,%rax)
   12af5:      	xorl	%edi, %edi
   12af7:      	cmpl	%r15d, %r12d
   12afa:      	seta	%dil
   12afe:      	movzbl	%cl, %esi
   12b01:      	addq	%rax, %rbx
   12b04:      	addq	%rbx, %rdi
   12b07:      	movl	$0x4, %eax
   12b0c:      	callq	*%rax
   12b0e:      	movq	%rbx, 0x48(%rsp)
   12b13:      	cmpl	%r15d, %r12d
   12b16:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   12b1c:      	movq	0x8(%rsp), %r12
   12b21:      	movq	%r12, 0x30(%rsp)
   12b26:      	movq	0x38(%rsp), %rdx
   12b2b:      	movq	0x40(%rsp), %r15
   12b30:      	jmp	0x12b83 <generic_kprobe_path+0x7263>
   12b32:      	leaq	0x10(%r15), %rdx
   12b36:      	movl	$0x4, %eax
   12b3b:      	movq	%rbp, %rdi
   12b3e:      	movl	$0x8, %esi
   12b43:      	callq	*%rax
   12b45:      	movq	0x40(%rsp), %rax
   12b4a:      	cmpq	(%rsp), %rax
   12b4e:      	je	0x1738d <generic_kprobe_path+0xba6d>
   12b54:      	addq	$0x18, %r15
   12b58:      	movl	$0x4, %eax
   12b5d:      	leaq	0x30(%rsp), %rdi
   12b62:      	movl	$0x8, %esi
   12b67:      	movq	%r15, %rdx
   12b6a:      	callq	*%rax
   12b6c:      	movq	(%rsp), %r15
   12b70:      	movq	%r15, 0x40(%rsp)
   12b75:      	leaq	0x20(%r15), %rdx
   12b79:      	movq	%rdx, 0x38(%rsp)
   12b7e:      	movq	0x30(%rsp), %r12
   12b83:      	cmpq	0x18(%rsp), %r12
   12b88:      	jne	0x12b95 <generic_kprobe_path+0x7275>
   12b8a:      	cmpq	0x20(%rsp), %rdx
   12b8f:      	je	0x1738d <generic_kprobe_path+0xba6d>
   12b95:      	movl	$0x4, %eax
   12b9a:      	leaq	0x10(%rsp), %rdi
   12b9f:      	movl	$0x8, %esi
   12ba4:      	callq	*%rax
   12ba6:      	cmpq	0x10(%rsp), %r12
   12bab:      	je	0x12ca3 <generic_kprobe_path+0x7383>
   12bb1:      	leaq	0x18(%r12), %rbx
   12bb6:      	movl	$0x4, %eax
   12bbb:      	movq	%rbp, %rdi
   12bbe:      	movl	$0x8, %esi
   12bc3:      	movq	%rbx, %rdx
   12bc6:      	callq	*%rax
   12bc8:      	cmpq	%r12, (%rsp)
   12bcc:      	je	0x12ca3 <generic_kprobe_path+0x7383>
   12bd2:      	movl	$0x4, %eax
   12bd7:      	leaq	0x8(%rsp), %rdi
   12bdc:      	movl	$0x8, %esi
   12be1:      	movq	%rbx, %rdx
   12be4:      	callq	*%rax
   12be6:      	addq	$0x20, %r12
   12bea:      	movl	$0x4, %eax
   12bef:      	leaq	0x58(%rsp), %rdi
   12bf4:      	movl	$0x10, %ecx
   12bf9:      	movl	$0x10, %esi
   12bfe:      	movq	%r12, %rdx
   12c01:      	callq	*%rax
   12c03:      	movq	0x28(%rsp), %rbx
   12c08:      	movq	0x48(%rsp), %rax
   12c0d:      	movl	0x5c(%rsp), %r15d
   12c12:      	subq	%rbx, %rax
   12c15:      	movl	0x50(%rsp), %r12d
   12c1a:      	movl	%r15d, %edx
   12c1d:      	subl	%r12d, %edx
   12c20:      	movl	$0x0, %ecx
   12c25:      	cmovbl	%ecx, %edx
   12c28:      	addq	0x60(%rsp), %rdx
   12c2d:      	xorl	%esi, %esi
   12c2f:      	cmpl	%r15d, %r12d
   12c32:      	seta	%sil
   12c36:      	movl	%r15d, %ecx
   12c39:      	cmovbl	%r12d, %ecx
   12c3d:      	addl	%ecx, %esi
   12c3f:      	movl	%r12d, %edi
   12c42:      	subl	%esi, %edi
   12c44:      	movl	%edi, 0x50(%rsp)
   12c48:      	subq	%rsi, %rax
   12c4b:      	jb	0x17392 <generic_kprobe_path+0xba72>
   12c51:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12c57:      	ja	0x17392 <generic_kprobe_path+0xba72>
   12c5d:      	cmpl	%r15d, %r12d
   12c60:      	jbe	0x12c66 <generic_kprobe_path+0x7346>
   12c62:      	movb	$0x2f, (%rbx,%rax)
   12c66:      	xorl	%edi, %edi
   12c68:      	cmpl	%r15d, %r12d
   12c6b:      	seta	%dil
   12c6f:      	movzbl	%cl, %esi
   12c72:      	addq	%rax, %rbx
   12c75:      	addq	%rbx, %rdi
   12c78:      	movl	$0x4, %eax
   12c7d:      	callq	*%rax
   12c7f:      	movq	%rbx, 0x48(%rsp)
   12c84:      	cmpl	%r15d, %r12d
   12c87:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   12c8d:      	movq	0x8(%rsp), %r12
   12c92:      	movq	%r12, 0x30(%rsp)
   12c97:      	movq	0x38(%rsp), %rdx
   12c9c:      	movq	0x40(%rsp), %r15
   12ca1:      	jmp	0x12cf4 <generic_kprobe_path+0x73d4>
   12ca3:      	leaq	0x10(%r15), %rdx
   12ca7:      	movl	$0x4, %eax
   12cac:      	movq	%rbp, %rdi
   12caf:      	movl	$0x8, %esi
   12cb4:      	callq	*%rax
   12cb6:      	movq	0x40(%rsp), %rax
   12cbb:      	cmpq	(%rsp), %rax
   12cbf:      	je	0x1738d <generic_kprobe_path+0xba6d>
   12cc5:      	addq	$0x18, %r15
   12cc9:      	movl	$0x4, %eax
   12cce:      	leaq	0x30(%rsp), %rdi
   12cd3:      	movl	$0x8, %esi
   12cd8:      	movq	%r15, %rdx
   12cdb:      	callq	*%rax
   12cdd:      	movq	(%rsp), %r15
   12ce1:      	movq	%r15, 0x40(%rsp)
   12ce6:      	leaq	0x20(%r15), %rdx
   12cea:      	movq	%rdx, 0x38(%rsp)
   12cef:      	movq	0x30(%rsp), %r12
   12cf4:      	cmpq	0x18(%rsp), %r12
   12cf9:      	jne	0x12d06 <generic_kprobe_path+0x73e6>
   12cfb:      	cmpq	0x20(%rsp), %rdx
   12d00:      	je	0x1738d <generic_kprobe_path+0xba6d>
   12d06:      	movl	$0x4, %eax
   12d0b:      	leaq	0x10(%rsp), %rdi
   12d10:      	movl	$0x8, %esi
   12d15:      	callq	*%rax
   12d17:      	cmpq	0x10(%rsp), %r12
   12d1c:      	je	0x12e14 <generic_kprobe_path+0x74f4>
   12d22:      	leaq	0x18(%r12), %rbx
   12d27:      	movl	$0x4, %eax
   12d2c:      	movq	%rbp, %rdi
   12d2f:      	movl	$0x8, %esi
   12d34:      	movq	%rbx, %rdx
   12d37:      	callq	*%rax
   12d39:      	cmpq	%r12, (%rsp)
   12d3d:      	je	0x12e14 <generic_kprobe_path+0x74f4>
   12d43:      	movl	$0x4, %eax
   12d48:      	leaq	0x8(%rsp), %rdi
   12d4d:      	movl	$0x8, %esi
   12d52:      	movq	%rbx, %rdx
   12d55:      	callq	*%rax
   12d57:      	addq	$0x20, %r12
   12d5b:      	movl	$0x4, %eax
   12d60:      	leaq	0x58(%rsp), %rdi
   12d65:      	movl	$0x10, %ecx
   12d6a:      	movl	$0x10, %esi
   12d6f:      	movq	%r12, %rdx
   12d72:      	callq	*%rax
   12d74:      	movq	0x28(%rsp), %rbx
   12d79:      	movq	0x48(%rsp), %rax
   12d7e:      	movl	0x5c(%rsp), %r15d
   12d83:      	subq	%rbx, %rax
   12d86:      	movl	0x50(%rsp), %r12d
   12d8b:      	movl	%r15d, %edx
   12d8e:      	subl	%r12d, %edx
   12d91:      	movl	$0x0, %ecx
   12d96:      	cmovbl	%ecx, %edx
   12d99:      	addq	0x60(%rsp), %rdx
   12d9e:      	xorl	%esi, %esi
   12da0:      	cmpl	%r15d, %r12d
   12da3:      	seta	%sil
   12da7:      	movl	%r15d, %ecx
   12daa:      	cmovbl	%r12d, %ecx
   12dae:      	addl	%ecx, %esi
   12db0:      	movl	%r12d, %edi
   12db3:      	subl	%esi, %edi
   12db5:      	movl	%edi, 0x50(%rsp)
   12db9:      	subq	%rsi, %rax
   12dbc:      	jb	0x17392 <generic_kprobe_path+0xba72>
   12dc2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12dc8:      	ja	0x17392 <generic_kprobe_path+0xba72>
   12dce:      	cmpl	%r15d, %r12d
   12dd1:      	jbe	0x12dd7 <generic_kprobe_path+0x74b7>
   12dd3:      	movb	$0x2f, (%rbx,%rax)
   12dd7:      	xorl	%edi, %edi
   12dd9:      	cmpl	%r15d, %r12d
   12ddc:      	seta	%dil
   12de0:      	movzbl	%cl, %esi
   12de3:      	addq	%rax, %rbx
   12de6:      	addq	%rbx, %rdi
   12de9:      	movl	$0x4, %eax
   12dee:      	callq	*%rax
   12df0:      	movq	%rbx, 0x48(%rsp)
   12df5:      	cmpl	%r15d, %r12d
   12df8:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   12dfe:      	movq	0x8(%rsp), %r12
   12e03:      	movq	%r12, 0x30(%rsp)
   12e08:      	movq	0x38(%rsp), %rdx
   12e0d:      	movq	0x40(%rsp), %r15
   12e12:      	jmp	0x12e65 <generic_kprobe_path+0x7545>
   12e14:      	leaq	0x10(%r15), %rdx
   12e18:      	movl	$0x4, %eax
   12e1d:      	movq	%rbp, %rdi
   12e20:      	movl	$0x8, %esi
   12e25:      	callq	*%rax
   12e27:      	movq	0x40(%rsp), %rax
   12e2c:      	cmpq	(%rsp), %rax
   12e30:      	je	0x1738d <generic_kprobe_path+0xba6d>
   12e36:      	addq	$0x18, %r15
   12e3a:      	movl	$0x4, %eax
   12e3f:      	leaq	0x30(%rsp), %rdi
   12e44:      	movl	$0x8, %esi
   12e49:      	movq	%r15, %rdx
   12e4c:      	callq	*%rax
   12e4e:      	movq	(%rsp), %r15
   12e52:      	movq	%r15, 0x40(%rsp)
   12e57:      	leaq	0x20(%r15), %rdx
   12e5b:      	movq	%rdx, 0x38(%rsp)
   12e60:      	movq	0x30(%rsp), %r12
   12e65:      	cmpq	0x18(%rsp), %r12
   12e6a:      	jne	0x12e77 <generic_kprobe_path+0x7557>
   12e6c:      	cmpq	0x20(%rsp), %rdx
   12e71:      	je	0x1738d <generic_kprobe_path+0xba6d>
   12e77:      	movl	$0x4, %eax
   12e7c:      	leaq	0x10(%rsp), %rdi
   12e81:      	movl	$0x8, %esi
   12e86:      	callq	*%rax
   12e88:      	cmpq	0x10(%rsp), %r12
   12e8d:      	je	0x12f85 <generic_kprobe_path+0x7665>
   12e93:      	leaq	0x18(%r12), %rbx
   12e98:      	movl	$0x4, %eax
   12e9d:      	movq	%rbp, %rdi
   12ea0:      	movl	$0x8, %esi
   12ea5:      	movq	%rbx, %rdx
   12ea8:      	callq	*%rax
   12eaa:      	cmpq	%r12, (%rsp)
   12eae:      	je	0x12f85 <generic_kprobe_path+0x7665>
   12eb4:      	movl	$0x4, %eax
   12eb9:      	leaq	0x8(%rsp), %rdi
   12ebe:      	movl	$0x8, %esi
   12ec3:      	movq	%rbx, %rdx
   12ec6:      	callq	*%rax
   12ec8:      	addq	$0x20, %r12
   12ecc:      	movl	$0x4, %eax
   12ed1:      	leaq	0x58(%rsp), %rdi
   12ed6:      	movl	$0x10, %ecx
   12edb:      	movl	$0x10, %esi
   12ee0:      	movq	%r12, %rdx
   12ee3:      	callq	*%rax
   12ee5:      	movq	0x28(%rsp), %rbx
   12eea:      	movq	0x48(%rsp), %rax
   12eef:      	movl	0x5c(%rsp), %r15d
   12ef4:      	subq	%rbx, %rax
   12ef7:      	movl	0x50(%rsp), %r12d
   12efc:      	movl	%r15d, %edx
   12eff:      	subl	%r12d, %edx
   12f02:      	movl	$0x0, %ecx
   12f07:      	cmovbl	%ecx, %edx
   12f0a:      	addq	0x60(%rsp), %rdx
   12f0f:      	xorl	%esi, %esi
   12f11:      	cmpl	%r15d, %r12d
   12f14:      	seta	%sil
   12f18:      	movl	%r15d, %ecx
   12f1b:      	cmovbl	%r12d, %ecx
   12f1f:      	addl	%ecx, %esi
   12f21:      	movl	%r12d, %edi
   12f24:      	subl	%esi, %edi
   12f26:      	movl	%edi, 0x50(%rsp)
   12f2a:      	subq	%rsi, %rax
   12f2d:      	jb	0x17392 <generic_kprobe_path+0xba72>
   12f33:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12f39:      	ja	0x17392 <generic_kprobe_path+0xba72>
   12f3f:      	cmpl	%r15d, %r12d
   12f42:      	jbe	0x12f48 <generic_kprobe_path+0x7628>
   12f44:      	movb	$0x2f, (%rbx,%rax)
   12f48:      	xorl	%edi, %edi
   12f4a:      	cmpl	%r15d, %r12d
   12f4d:      	seta	%dil
   12f51:      	movzbl	%cl, %esi
   12f54:      	addq	%rax, %rbx
   12f57:      	addq	%rbx, %rdi
   12f5a:      	movl	$0x4, %eax
   12f5f:      	callq	*%rax
   12f61:      	movq	%rbx, 0x48(%rsp)
   12f66:      	cmpl	%r15d, %r12d
   12f69:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   12f6f:      	movq	0x8(%rsp), %r12
   12f74:      	movq	%r12, 0x30(%rsp)
   12f79:      	movq	0x38(%rsp), %rdx
   12f7e:      	movq	0x40(%rsp), %r15
   12f83:      	jmp	0x12fd6 <generic_kprobe_path+0x76b6>
   12f85:      	leaq	0x10(%r15), %rdx
   12f89:      	movl	$0x4, %eax
   12f8e:      	movq	%rbp, %rdi
   12f91:      	movl	$0x8, %esi
   12f96:      	callq	*%rax
   12f98:      	movq	0x40(%rsp), %rax
   12f9d:      	cmpq	(%rsp), %rax
   12fa1:      	je	0x1738d <generic_kprobe_path+0xba6d>
   12fa7:      	addq	$0x18, %r15
   12fab:      	movl	$0x4, %eax
   12fb0:      	leaq	0x30(%rsp), %rdi
   12fb5:      	movl	$0x8, %esi
   12fba:      	movq	%r15, %rdx
   12fbd:      	callq	*%rax
   12fbf:      	movq	(%rsp), %r15
   12fc3:      	movq	%r15, 0x40(%rsp)
   12fc8:      	leaq	0x20(%r15), %rdx
   12fcc:      	movq	%rdx, 0x38(%rsp)
   12fd1:      	movq	0x30(%rsp), %r12
   12fd6:      	cmpq	0x18(%rsp), %r12
   12fdb:      	jne	0x12fe8 <generic_kprobe_path+0x76c8>
   12fdd:      	cmpq	0x20(%rsp), %rdx
   12fe2:      	je	0x1738d <generic_kprobe_path+0xba6d>
   12fe8:      	movl	$0x4, %eax
   12fed:      	leaq	0x10(%rsp), %rdi
   12ff2:      	movl	$0x8, %esi
   12ff7:      	callq	*%rax
   12ff9:      	cmpq	0x10(%rsp), %r12
   12ffe:      	je	0x130f6 <generic_kprobe_path+0x77d6>
   13004:      	leaq	0x18(%r12), %rbx
   13009:      	movl	$0x4, %eax
   1300e:      	movq	%rbp, %rdi
   13011:      	movl	$0x8, %esi
   13016:      	movq	%rbx, %rdx
   13019:      	callq	*%rax
   1301b:      	cmpq	%r12, (%rsp)
   1301f:      	je	0x130f6 <generic_kprobe_path+0x77d6>
   13025:      	movl	$0x4, %eax
   1302a:      	leaq	0x8(%rsp), %rdi
   1302f:      	movl	$0x8, %esi
   13034:      	movq	%rbx, %rdx
   13037:      	callq	*%rax
   13039:      	addq	$0x20, %r12
   1303d:      	movl	$0x4, %eax
   13042:      	leaq	0x58(%rsp), %rdi
   13047:      	movl	$0x10, %ecx
   1304c:      	movl	$0x10, %esi
   13051:      	movq	%r12, %rdx
   13054:      	callq	*%rax
   13056:      	movq	0x28(%rsp), %rbx
   1305b:      	movq	0x48(%rsp), %rax
   13060:      	movl	0x5c(%rsp), %r15d
   13065:      	subq	%rbx, %rax
   13068:      	movl	0x50(%rsp), %r12d
   1306d:      	movl	%r15d, %edx
   13070:      	subl	%r12d, %edx
   13073:      	movl	$0x0, %ecx
   13078:      	cmovbl	%ecx, %edx
   1307b:      	addq	0x60(%rsp), %rdx
   13080:      	xorl	%esi, %esi
   13082:      	cmpl	%r15d, %r12d
   13085:      	seta	%sil
   13089:      	movl	%r15d, %ecx
   1308c:      	cmovbl	%r12d, %ecx
   13090:      	addl	%ecx, %esi
   13092:      	movl	%r12d, %edi
   13095:      	subl	%esi, %edi
   13097:      	movl	%edi, 0x50(%rsp)
   1309b:      	subq	%rsi, %rax
   1309e:      	jb	0x17392 <generic_kprobe_path+0xba72>
   130a4:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   130aa:      	ja	0x17392 <generic_kprobe_path+0xba72>
   130b0:      	cmpl	%r15d, %r12d
   130b3:      	jbe	0x130b9 <generic_kprobe_path+0x7799>
   130b5:      	movb	$0x2f, (%rbx,%rax)
   130b9:      	xorl	%edi, %edi
   130bb:      	cmpl	%r15d, %r12d
   130be:      	seta	%dil
   130c2:      	movzbl	%cl, %esi
   130c5:      	addq	%rax, %rbx
   130c8:      	addq	%rbx, %rdi
   130cb:      	movl	$0x4, %eax
   130d0:      	callq	*%rax
   130d2:      	movq	%rbx, 0x48(%rsp)
   130d7:      	cmpl	%r15d, %r12d
   130da:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   130e0:      	movq	0x8(%rsp), %r12
   130e5:      	movq	%r12, 0x30(%rsp)
   130ea:      	movq	0x38(%rsp), %rdx
   130ef:      	movq	0x40(%rsp), %r15
   130f4:      	jmp	0x13147 <generic_kprobe_path+0x7827>
   130f6:      	leaq	0x10(%r15), %rdx
   130fa:      	movl	$0x4, %eax
   130ff:      	movq	%rbp, %rdi
   13102:      	movl	$0x8, %esi
   13107:      	callq	*%rax
   13109:      	movq	0x40(%rsp), %rax
   1310e:      	cmpq	(%rsp), %rax
   13112:      	je	0x1738d <generic_kprobe_path+0xba6d>
   13118:      	addq	$0x18, %r15
   1311c:      	movl	$0x4, %eax
   13121:      	leaq	0x30(%rsp), %rdi
   13126:      	movl	$0x8, %esi
   1312b:      	movq	%r15, %rdx
   1312e:      	callq	*%rax
   13130:      	movq	(%rsp), %r15
   13134:      	movq	%r15, 0x40(%rsp)
   13139:      	leaq	0x20(%r15), %rdx
   1313d:      	movq	%rdx, 0x38(%rsp)
   13142:      	movq	0x30(%rsp), %r12
   13147:      	cmpq	0x18(%rsp), %r12
   1314c:      	jne	0x13159 <generic_kprobe_path+0x7839>
   1314e:      	cmpq	0x20(%rsp), %rdx
   13153:      	je	0x1738d <generic_kprobe_path+0xba6d>
   13159:      	movl	$0x4, %eax
   1315e:      	leaq	0x10(%rsp), %rdi
   13163:      	movl	$0x8, %esi
   13168:      	callq	*%rax
   1316a:      	cmpq	0x10(%rsp), %r12
   1316f:      	je	0x13267 <generic_kprobe_path+0x7947>
   13175:      	leaq	0x18(%r12), %rbx
   1317a:      	movl	$0x4, %eax
   1317f:      	movq	%rbp, %rdi
   13182:      	movl	$0x8, %esi
   13187:      	movq	%rbx, %rdx
   1318a:      	callq	*%rax
   1318c:      	cmpq	%r12, (%rsp)
   13190:      	je	0x13267 <generic_kprobe_path+0x7947>
   13196:      	movl	$0x4, %eax
   1319b:      	leaq	0x8(%rsp), %rdi
   131a0:      	movl	$0x8, %esi
   131a5:      	movq	%rbx, %rdx
   131a8:      	callq	*%rax
   131aa:      	addq	$0x20, %r12
   131ae:      	movl	$0x4, %eax
   131b3:      	leaq	0x58(%rsp), %rdi
   131b8:      	movl	$0x10, %ecx
   131bd:      	movl	$0x10, %esi
   131c2:      	movq	%r12, %rdx
   131c5:      	callq	*%rax
   131c7:      	movq	0x28(%rsp), %rbx
   131cc:      	movq	0x48(%rsp), %rax
   131d1:      	movl	0x5c(%rsp), %r15d
   131d6:      	subq	%rbx, %rax
   131d9:      	movl	0x50(%rsp), %r12d
   131de:      	movl	%r15d, %edx
   131e1:      	subl	%r12d, %edx
   131e4:      	movl	$0x0, %ecx
   131e9:      	cmovbl	%ecx, %edx
   131ec:      	addq	0x60(%rsp), %rdx
   131f1:      	xorl	%esi, %esi
   131f3:      	cmpl	%r15d, %r12d
   131f6:      	seta	%sil
   131fa:      	movl	%r15d, %ecx
   131fd:      	cmovbl	%r12d, %ecx
   13201:      	addl	%ecx, %esi
   13203:      	movl	%r12d, %edi
   13206:      	subl	%esi, %edi
   13208:      	movl	%edi, 0x50(%rsp)
   1320c:      	subq	%rsi, %rax
   1320f:      	jb	0x17392 <generic_kprobe_path+0xba72>
   13215:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1321b:      	ja	0x17392 <generic_kprobe_path+0xba72>
   13221:      	cmpl	%r15d, %r12d
   13224:      	jbe	0x1322a <generic_kprobe_path+0x790a>
   13226:      	movb	$0x2f, (%rbx,%rax)
   1322a:      	xorl	%edi, %edi
   1322c:      	cmpl	%r15d, %r12d
   1322f:      	seta	%dil
   13233:      	movzbl	%cl, %esi
   13236:      	addq	%rax, %rbx
   13239:      	addq	%rbx, %rdi
   1323c:      	movl	$0x4, %eax
   13241:      	callq	*%rax
   13243:      	movq	%rbx, 0x48(%rsp)
   13248:      	cmpl	%r15d, %r12d
   1324b:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   13251:      	movq	0x8(%rsp), %r12
   13256:      	movq	%r12, 0x30(%rsp)
   1325b:      	movq	0x38(%rsp), %rdx
   13260:      	movq	0x40(%rsp), %r15
   13265:      	jmp	0x132b8 <generic_kprobe_path+0x7998>
   13267:      	leaq	0x10(%r15), %rdx
   1326b:      	movl	$0x4, %eax
   13270:      	movq	%rbp, %rdi
   13273:      	movl	$0x8, %esi
   13278:      	callq	*%rax
   1327a:      	movq	0x40(%rsp), %rax
   1327f:      	cmpq	(%rsp), %rax
   13283:      	je	0x1738d <generic_kprobe_path+0xba6d>
   13289:      	addq	$0x18, %r15
   1328d:      	movl	$0x4, %eax
   13292:      	leaq	0x30(%rsp), %rdi
   13297:      	movl	$0x8, %esi
   1329c:      	movq	%r15, %rdx
   1329f:      	callq	*%rax
   132a1:      	movq	(%rsp), %r15
   132a5:      	movq	%r15, 0x40(%rsp)
   132aa:      	leaq	0x20(%r15), %rdx
   132ae:      	movq	%rdx, 0x38(%rsp)
   132b3:      	movq	0x30(%rsp), %r12
   132b8:      	cmpq	0x18(%rsp), %r12
   132bd:      	jne	0x132ca <generic_kprobe_path+0x79aa>
   132bf:      	cmpq	0x20(%rsp), %rdx
   132c4:      	je	0x1738d <generic_kprobe_path+0xba6d>
   132ca:      	movl	$0x4, %eax
   132cf:      	leaq	0x10(%rsp), %rdi
   132d4:      	movl	$0x8, %esi
   132d9:      	callq	*%rax
   132db:      	cmpq	0x10(%rsp), %r12
   132e0:      	je	0x133d8 <generic_kprobe_path+0x7ab8>
   132e6:      	leaq	0x18(%r12), %rbx
   132eb:      	movl	$0x4, %eax
   132f0:      	movq	%rbp, %rdi
   132f3:      	movl	$0x8, %esi
   132f8:      	movq	%rbx, %rdx
   132fb:      	callq	*%rax
   132fd:      	cmpq	%r12, (%rsp)
   13301:      	je	0x133d8 <generic_kprobe_path+0x7ab8>
   13307:      	movl	$0x4, %eax
   1330c:      	leaq	0x8(%rsp), %rdi
   13311:      	movl	$0x8, %esi
   13316:      	movq	%rbx, %rdx
   13319:      	callq	*%rax
   1331b:      	addq	$0x20, %r12
   1331f:      	movl	$0x4, %eax
   13324:      	leaq	0x58(%rsp), %rdi
   13329:      	movl	$0x10, %ecx
   1332e:      	movl	$0x10, %esi
   13333:      	movq	%r12, %rdx
   13336:      	callq	*%rax
   13338:      	movq	0x28(%rsp), %rbx
   1333d:      	movq	0x48(%rsp), %rax
   13342:      	movl	0x5c(%rsp), %r15d
   13347:      	subq	%rbx, %rax
   1334a:      	movl	0x50(%rsp), %r12d
   1334f:      	movl	%r15d, %edx
   13352:      	subl	%r12d, %edx
   13355:      	movl	$0x0, %ecx
   1335a:      	cmovbl	%ecx, %edx
   1335d:      	addq	0x60(%rsp), %rdx
   13362:      	xorl	%esi, %esi
   13364:      	cmpl	%r15d, %r12d
   13367:      	seta	%sil
   1336b:      	movl	%r15d, %ecx
   1336e:      	cmovbl	%r12d, %ecx
   13372:      	addl	%ecx, %esi
   13374:      	movl	%r12d, %edi
   13377:      	subl	%esi, %edi
   13379:      	movl	%edi, 0x50(%rsp)
   1337d:      	subq	%rsi, %rax
   13380:      	jb	0x17392 <generic_kprobe_path+0xba72>
   13386:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1338c:      	ja	0x17392 <generic_kprobe_path+0xba72>
   13392:      	cmpl	%r15d, %r12d
   13395:      	jbe	0x1339b <generic_kprobe_path+0x7a7b>
   13397:      	movb	$0x2f, (%rbx,%rax)
   1339b:      	xorl	%edi, %edi
   1339d:      	cmpl	%r15d, %r12d
   133a0:      	seta	%dil
   133a4:      	movzbl	%cl, %esi
   133a7:      	addq	%rax, %rbx
   133aa:      	addq	%rbx, %rdi
   133ad:      	movl	$0x4, %eax
   133b2:      	callq	*%rax
   133b4:      	movq	%rbx, 0x48(%rsp)
   133b9:      	cmpl	%r15d, %r12d
   133bc:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   133c2:      	movq	0x8(%rsp), %r12
   133c7:      	movq	%r12, 0x30(%rsp)
   133cc:      	movq	0x38(%rsp), %rdx
   133d1:      	movq	0x40(%rsp), %r15
   133d6:      	jmp	0x13429 <generic_kprobe_path+0x7b09>
   133d8:      	leaq	0x10(%r15), %rdx
   133dc:      	movl	$0x4, %eax
   133e1:      	movq	%rbp, %rdi
   133e4:      	movl	$0x8, %esi
   133e9:      	callq	*%rax
   133eb:      	movq	0x40(%rsp), %rax
   133f0:      	cmpq	(%rsp), %rax
   133f4:      	je	0x1738d <generic_kprobe_path+0xba6d>
   133fa:      	addq	$0x18, %r15
   133fe:      	movl	$0x4, %eax
   13403:      	leaq	0x30(%rsp), %rdi
   13408:      	movl	$0x8, %esi
   1340d:      	movq	%r15, %rdx
   13410:      	callq	*%rax
   13412:      	movq	(%rsp), %r15
   13416:      	movq	%r15, 0x40(%rsp)
   1341b:      	leaq	0x20(%r15), %rdx
   1341f:      	movq	%rdx, 0x38(%rsp)
   13424:      	movq	0x30(%rsp), %r12
   13429:      	cmpq	0x18(%rsp), %r12
   1342e:      	jne	0x1343b <generic_kprobe_path+0x7b1b>
   13430:      	cmpq	0x20(%rsp), %rdx
   13435:      	je	0x1738d <generic_kprobe_path+0xba6d>
   1343b:      	movl	$0x4, %eax
   13440:      	leaq	0x10(%rsp), %rdi
   13445:      	movl	$0x8, %esi
   1344a:      	callq	*%rax
   1344c:      	cmpq	0x10(%rsp), %r12
   13451:      	je	0x13549 <generic_kprobe_path+0x7c29>
   13457:      	leaq	0x18(%r12), %rbx
   1345c:      	movl	$0x4, %eax
   13461:      	movq	%rbp, %rdi
   13464:      	movl	$0x8, %esi
   13469:      	movq	%rbx, %rdx
   1346c:      	callq	*%rax
   1346e:      	cmpq	%r12, (%rsp)
   13472:      	je	0x13549 <generic_kprobe_path+0x7c29>
   13478:      	movl	$0x4, %eax
   1347d:      	leaq	0x8(%rsp), %rdi
   13482:      	movl	$0x8, %esi
   13487:      	movq	%rbx, %rdx
   1348a:      	callq	*%rax
   1348c:      	addq	$0x20, %r12
   13490:      	movl	$0x4, %eax
   13495:      	leaq	0x58(%rsp), %rdi
   1349a:      	movl	$0x10, %ecx
   1349f:      	movl	$0x10, %esi
   134a4:      	movq	%r12, %rdx
   134a7:      	callq	*%rax
   134a9:      	movq	0x28(%rsp), %rbx
   134ae:      	movq	0x48(%rsp), %rax
   134b3:      	movl	0x5c(%rsp), %r15d
   134b8:      	subq	%rbx, %rax
   134bb:      	movl	0x50(%rsp), %r12d
   134c0:      	movl	%r15d, %edx
   134c3:      	subl	%r12d, %edx
   134c6:      	movl	$0x0, %ecx
   134cb:      	cmovbl	%ecx, %edx
   134ce:      	addq	0x60(%rsp), %rdx
   134d3:      	xorl	%esi, %esi
   134d5:      	cmpl	%r15d, %r12d
   134d8:      	seta	%sil
   134dc:      	movl	%r15d, %ecx
   134df:      	cmovbl	%r12d, %ecx
   134e3:      	addl	%ecx, %esi
   134e5:      	movl	%r12d, %edi
   134e8:      	subl	%esi, %edi
   134ea:      	movl	%edi, 0x50(%rsp)
   134ee:      	subq	%rsi, %rax
   134f1:      	jb	0x17392 <generic_kprobe_path+0xba72>
   134f7:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   134fd:      	ja	0x17392 <generic_kprobe_path+0xba72>
   13503:      	cmpl	%r15d, %r12d
   13506:      	jbe	0x1350c <generic_kprobe_path+0x7bec>
   13508:      	movb	$0x2f, (%rbx,%rax)
   1350c:      	xorl	%edi, %edi
   1350e:      	cmpl	%r15d, %r12d
   13511:      	seta	%dil
   13515:      	movzbl	%cl, %esi
   13518:      	addq	%rax, %rbx
   1351b:      	addq	%rbx, %rdi
   1351e:      	movl	$0x4, %eax
   13523:      	callq	*%rax
   13525:      	movq	%rbx, 0x48(%rsp)
   1352a:      	cmpl	%r15d, %r12d
   1352d:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   13533:      	movq	0x8(%rsp), %r12
   13538:      	movq	%r12, 0x30(%rsp)
   1353d:      	movq	0x38(%rsp), %rdx
   13542:      	movq	0x40(%rsp), %r15
   13547:      	jmp	0x1359a <generic_kprobe_path+0x7c7a>
   13549:      	leaq	0x10(%r15), %rdx
   1354d:      	movl	$0x4, %eax
   13552:      	movq	%rbp, %rdi
   13555:      	movl	$0x8, %esi
   1355a:      	callq	*%rax
   1355c:      	movq	0x40(%rsp), %rax
   13561:      	cmpq	(%rsp), %rax
   13565:      	je	0x1738d <generic_kprobe_path+0xba6d>
   1356b:      	addq	$0x18, %r15
   1356f:      	movl	$0x4, %eax
   13574:      	leaq	0x30(%rsp), %rdi
   13579:      	movl	$0x8, %esi
   1357e:      	movq	%r15, %rdx
   13581:      	callq	*%rax
   13583:      	movq	(%rsp), %r15
   13587:      	movq	%r15, 0x40(%rsp)
   1358c:      	leaq	0x20(%r15), %rdx
   13590:      	movq	%rdx, 0x38(%rsp)
   13595:      	movq	0x30(%rsp), %r12
   1359a:      	cmpq	0x18(%rsp), %r12
   1359f:      	jne	0x135ac <generic_kprobe_path+0x7c8c>
   135a1:      	cmpq	0x20(%rsp), %rdx
   135a6:      	je	0x1738d <generic_kprobe_path+0xba6d>
   135ac:      	movl	$0x4, %eax
   135b1:      	leaq	0x10(%rsp), %rdi
   135b6:      	movl	$0x8, %esi
   135bb:      	callq	*%rax
   135bd:      	cmpq	0x10(%rsp), %r12
   135c2:      	je	0x136ba <generic_kprobe_path+0x7d9a>
   135c8:      	leaq	0x18(%r12), %rbx
   135cd:      	movl	$0x4, %eax
   135d2:      	movq	%rbp, %rdi
   135d5:      	movl	$0x8, %esi
   135da:      	movq	%rbx, %rdx
   135dd:      	callq	*%rax
   135df:      	cmpq	%r12, (%rsp)
   135e3:      	je	0x136ba <generic_kprobe_path+0x7d9a>
   135e9:      	movl	$0x4, %eax
   135ee:      	leaq	0x8(%rsp), %rdi
   135f3:      	movl	$0x8, %esi
   135f8:      	movq	%rbx, %rdx
   135fb:      	callq	*%rax
   135fd:      	addq	$0x20, %r12
   13601:      	movl	$0x4, %eax
   13606:      	leaq	0x58(%rsp), %rdi
   1360b:      	movl	$0x10, %ecx
   13610:      	movl	$0x10, %esi
   13615:      	movq	%r12, %rdx
   13618:      	callq	*%rax
   1361a:      	movq	0x28(%rsp), %rbx
   1361f:      	movq	0x48(%rsp), %rax
   13624:      	movl	0x5c(%rsp), %r15d
   13629:      	subq	%rbx, %rax
   1362c:      	movl	0x50(%rsp), %r12d
   13631:      	movl	%r15d, %edx
   13634:      	subl	%r12d, %edx
   13637:      	movl	$0x0, %ecx
   1363c:      	cmovbl	%ecx, %edx
   1363f:      	addq	0x60(%rsp), %rdx
   13644:      	xorl	%esi, %esi
   13646:      	cmpl	%r15d, %r12d
   13649:      	seta	%sil
   1364d:      	movl	%r15d, %ecx
   13650:      	cmovbl	%r12d, %ecx
   13654:      	addl	%ecx, %esi
   13656:      	movl	%r12d, %edi
   13659:      	subl	%esi, %edi
   1365b:      	movl	%edi, 0x50(%rsp)
   1365f:      	subq	%rsi, %rax
   13662:      	jb	0x17392 <generic_kprobe_path+0xba72>
   13668:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1366e:      	ja	0x17392 <generic_kprobe_path+0xba72>
   13674:      	cmpl	%r15d, %r12d
   13677:      	jbe	0x1367d <generic_kprobe_path+0x7d5d>
   13679:      	movb	$0x2f, (%rbx,%rax)
   1367d:      	xorl	%edi, %edi
   1367f:      	cmpl	%r15d, %r12d
   13682:      	seta	%dil
   13686:      	movzbl	%cl, %esi
   13689:      	addq	%rax, %rbx
   1368c:      	addq	%rbx, %rdi
   1368f:      	movl	$0x4, %eax
   13694:      	callq	*%rax
   13696:      	movq	%rbx, 0x48(%rsp)
   1369b:      	cmpl	%r15d, %r12d
   1369e:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   136a4:      	movq	0x8(%rsp), %r12
   136a9:      	movq	%r12, 0x30(%rsp)
   136ae:      	movq	0x38(%rsp), %rdx
   136b3:      	movq	0x40(%rsp), %r15
   136b8:      	jmp	0x1370b <generic_kprobe_path+0x7deb>
   136ba:      	leaq	0x10(%r15), %rdx
   136be:      	movl	$0x4, %eax
   136c3:      	movq	%rbp, %rdi
   136c6:      	movl	$0x8, %esi
   136cb:      	callq	*%rax
   136cd:      	movq	0x40(%rsp), %rax
   136d2:      	cmpq	(%rsp), %rax
   136d6:      	je	0x1738d <generic_kprobe_path+0xba6d>
   136dc:      	addq	$0x18, %r15
   136e0:      	movl	$0x4, %eax
   136e5:      	leaq	0x30(%rsp), %rdi
   136ea:      	movl	$0x8, %esi
   136ef:      	movq	%r15, %rdx
   136f2:      	callq	*%rax
   136f4:      	movq	(%rsp), %r15
   136f8:      	movq	%r15, 0x40(%rsp)
   136fd:      	leaq	0x20(%r15), %rdx
   13701:      	movq	%rdx, 0x38(%rsp)
   13706:      	movq	0x30(%rsp), %r12
   1370b:      	cmpq	0x18(%rsp), %r12
   13710:      	jne	0x1371d <generic_kprobe_path+0x7dfd>
   13712:      	cmpq	0x20(%rsp), %rdx
   13717:      	je	0x1738d <generic_kprobe_path+0xba6d>
   1371d:      	movl	$0x4, %eax
   13722:      	leaq	0x10(%rsp), %rdi
   13727:      	movl	$0x8, %esi
   1372c:      	callq	*%rax
   1372e:      	cmpq	0x10(%rsp), %r12
   13733:      	je	0x1382b <generic_kprobe_path+0x7f0b>
   13739:      	leaq	0x18(%r12), %rbx
   1373e:      	movl	$0x4, %eax
   13743:      	movq	%rbp, %rdi
   13746:      	movl	$0x8, %esi
   1374b:      	movq	%rbx, %rdx
   1374e:      	callq	*%rax
   13750:      	cmpq	%r12, (%rsp)
   13754:      	je	0x1382b <generic_kprobe_path+0x7f0b>
   1375a:      	movl	$0x4, %eax
   1375f:      	leaq	0x8(%rsp), %rdi
   13764:      	movl	$0x8, %esi
   13769:      	movq	%rbx, %rdx
   1376c:      	callq	*%rax
   1376e:      	addq	$0x20, %r12
   13772:      	movl	$0x4, %eax
   13777:      	leaq	0x58(%rsp), %rdi
   1377c:      	movl	$0x10, %ecx
   13781:      	movl	$0x10, %esi
   13786:      	movq	%r12, %rdx
   13789:      	callq	*%rax
   1378b:      	movq	0x28(%rsp), %rbx
   13790:      	movq	0x48(%rsp), %rax
   13795:      	movl	0x5c(%rsp), %r15d
   1379a:      	subq	%rbx, %rax
   1379d:      	movl	0x50(%rsp), %r12d
   137a2:      	movl	%r15d, %edx
   137a5:      	subl	%r12d, %edx
   137a8:      	movl	$0x0, %ecx
   137ad:      	cmovbl	%ecx, %edx
   137b0:      	addq	0x60(%rsp), %rdx
   137b5:      	xorl	%esi, %esi
   137b7:      	cmpl	%r15d, %r12d
   137ba:      	seta	%sil
   137be:      	movl	%r15d, %ecx
   137c1:      	cmovbl	%r12d, %ecx
   137c5:      	addl	%ecx, %esi
   137c7:      	movl	%r12d, %edi
   137ca:      	subl	%esi, %edi
   137cc:      	movl	%edi, 0x50(%rsp)
   137d0:      	subq	%rsi, %rax
   137d3:      	jb	0x17392 <generic_kprobe_path+0xba72>
   137d9:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   137df:      	ja	0x17392 <generic_kprobe_path+0xba72>
   137e5:      	cmpl	%r15d, %r12d
   137e8:      	jbe	0x137ee <generic_kprobe_path+0x7ece>
   137ea:      	movb	$0x2f, (%rbx,%rax)
   137ee:      	xorl	%edi, %edi
   137f0:      	cmpl	%r15d, %r12d
   137f3:      	seta	%dil
   137f7:      	movzbl	%cl, %esi
   137fa:      	addq	%rax, %rbx
   137fd:      	addq	%rbx, %rdi
   13800:      	movl	$0x4, %eax
   13805:      	callq	*%rax
   13807:      	movq	%rbx, 0x48(%rsp)
   1380c:      	cmpl	%r15d, %r12d
   1380f:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   13815:      	movq	0x8(%rsp), %r12
   1381a:      	movq	%r12, 0x30(%rsp)
   1381f:      	movq	0x38(%rsp), %rdx
   13824:      	movq	0x40(%rsp), %r15
   13829:      	jmp	0x1387c <generic_kprobe_path+0x7f5c>
   1382b:      	leaq	0x10(%r15), %rdx
   1382f:      	movl	$0x4, %eax
   13834:      	movq	%rbp, %rdi
   13837:      	movl	$0x8, %esi
   1383c:      	callq	*%rax
   1383e:      	movq	0x40(%rsp), %rax
   13843:      	cmpq	(%rsp), %rax
   13847:      	je	0x1738d <generic_kprobe_path+0xba6d>
   1384d:      	addq	$0x18, %r15
   13851:      	movl	$0x4, %eax
   13856:      	leaq	0x30(%rsp), %rdi
   1385b:      	movl	$0x8, %esi
   13860:      	movq	%r15, %rdx
   13863:      	callq	*%rax
   13865:      	movq	(%rsp), %r15
   13869:      	movq	%r15, 0x40(%rsp)
   1386e:      	leaq	0x20(%r15), %rdx
   13872:      	movq	%rdx, 0x38(%rsp)
   13877:      	movq	0x30(%rsp), %r12
   1387c:      	cmpq	0x18(%rsp), %r12
   13881:      	jne	0x1388e <generic_kprobe_path+0x7f6e>
   13883:      	cmpq	0x20(%rsp), %rdx
   13888:      	je	0x1738d <generic_kprobe_path+0xba6d>
   1388e:      	movl	$0x4, %eax
   13893:      	leaq	0x10(%rsp), %rdi
   13898:      	movl	$0x8, %esi
   1389d:      	callq	*%rax
   1389f:      	cmpq	0x10(%rsp), %r12
   138a4:      	je	0x1399c <generic_kprobe_path+0x807c>
   138aa:      	leaq	0x18(%r12), %rbx
   138af:      	movl	$0x4, %eax
   138b4:      	movq	%rbp, %rdi
   138b7:      	movl	$0x8, %esi
   138bc:      	movq	%rbx, %rdx
   138bf:      	callq	*%rax
   138c1:      	cmpq	%r12, (%rsp)
   138c5:      	je	0x1399c <generic_kprobe_path+0x807c>
   138cb:      	movl	$0x4, %eax
   138d0:      	leaq	0x8(%rsp), %rdi
   138d5:      	movl	$0x8, %esi
   138da:      	movq	%rbx, %rdx
   138dd:      	callq	*%rax
   138df:      	addq	$0x20, %r12
   138e3:      	movl	$0x4, %eax
   138e8:      	leaq	0x58(%rsp), %rdi
   138ed:      	movl	$0x10, %ecx
   138f2:      	movl	$0x10, %esi
   138f7:      	movq	%r12, %rdx
   138fa:      	callq	*%rax
   138fc:      	movq	0x28(%rsp), %rbx
   13901:      	movq	0x48(%rsp), %rax
   13906:      	movl	0x5c(%rsp), %r15d
   1390b:      	subq	%rbx, %rax
   1390e:      	movl	0x50(%rsp), %r12d
   13913:      	movl	%r15d, %edx
   13916:      	subl	%r12d, %edx
   13919:      	movl	$0x0, %ecx
   1391e:      	cmovbl	%ecx, %edx
   13921:      	addq	0x60(%rsp), %rdx
   13926:      	xorl	%esi, %esi
   13928:      	cmpl	%r15d, %r12d
   1392b:      	seta	%sil
   1392f:      	movl	%r15d, %ecx
   13932:      	cmovbl	%r12d, %ecx
   13936:      	addl	%ecx, %esi
   13938:      	movl	%r12d, %edi
   1393b:      	subl	%esi, %edi
   1393d:      	movl	%edi, 0x50(%rsp)
   13941:      	subq	%rsi, %rax
   13944:      	jb	0x17392 <generic_kprobe_path+0xba72>
   1394a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13950:      	ja	0x17392 <generic_kprobe_path+0xba72>
   13956:      	cmpl	%r15d, %r12d
   13959:      	jbe	0x1395f <generic_kprobe_path+0x803f>
   1395b:      	movb	$0x2f, (%rbx,%rax)
   1395f:      	xorl	%edi, %edi
   13961:      	cmpl	%r15d, %r12d
   13964:      	seta	%dil
   13968:      	movzbl	%cl, %esi
   1396b:      	addq	%rax, %rbx
   1396e:      	addq	%rbx, %rdi
   13971:      	movl	$0x4, %eax
   13976:      	callq	*%rax
   13978:      	movq	%rbx, 0x48(%rsp)
   1397d:      	cmpl	%r15d, %r12d
   13980:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   13986:      	movq	0x8(%rsp), %r12
   1398b:      	movq	%r12, 0x30(%rsp)
   13990:      	movq	0x38(%rsp), %rdx
   13995:      	movq	0x40(%rsp), %r15
   1399a:      	jmp	0x139ed <generic_kprobe_path+0x80cd>
   1399c:      	leaq	0x10(%r15), %rdx
   139a0:      	movl	$0x4, %eax
   139a5:      	movq	%rbp, %rdi
   139a8:      	movl	$0x8, %esi
   139ad:      	callq	*%rax
   139af:      	movq	0x40(%rsp), %rax
   139b4:      	cmpq	(%rsp), %rax
   139b8:      	je	0x1738d <generic_kprobe_path+0xba6d>
   139be:      	addq	$0x18, %r15
   139c2:      	movl	$0x4, %eax
   139c7:      	leaq	0x30(%rsp), %rdi
   139cc:      	movl	$0x8, %esi
   139d1:      	movq	%r15, %rdx
   139d4:      	callq	*%rax
   139d6:      	movq	(%rsp), %r15
   139da:      	movq	%r15, 0x40(%rsp)
   139df:      	leaq	0x20(%r15), %rdx
   139e3:      	movq	%rdx, 0x38(%rsp)
   139e8:      	movq	0x30(%rsp), %r12
   139ed:      	cmpq	0x18(%rsp), %r12
   139f2:      	jne	0x139ff <generic_kprobe_path+0x80df>
   139f4:      	cmpq	0x20(%rsp), %rdx
   139f9:      	je	0x1738d <generic_kprobe_path+0xba6d>
   139ff:      	movl	$0x4, %eax
   13a04:      	leaq	0x10(%rsp), %rdi
   13a09:      	movl	$0x8, %esi
   13a0e:      	callq	*%rax
   13a10:      	cmpq	0x10(%rsp), %r12
   13a15:      	je	0x13b0d <generic_kprobe_path+0x81ed>
   13a1b:      	leaq	0x18(%r12), %rbx
   13a20:      	movl	$0x4, %eax
   13a25:      	movq	%rbp, %rdi
   13a28:      	movl	$0x8, %esi
   13a2d:      	movq	%rbx, %rdx
   13a30:      	callq	*%rax
   13a32:      	cmpq	%r12, (%rsp)
   13a36:      	je	0x13b0d <generic_kprobe_path+0x81ed>
   13a3c:      	movl	$0x4, %eax
   13a41:      	leaq	0x8(%rsp), %rdi
   13a46:      	movl	$0x8, %esi
   13a4b:      	movq	%rbx, %rdx
   13a4e:      	callq	*%rax
   13a50:      	addq	$0x20, %r12
   13a54:      	movl	$0x4, %eax
   13a59:      	leaq	0x58(%rsp), %rdi
   13a5e:      	movl	$0x10, %ecx
   13a63:      	movl	$0x10, %esi
   13a68:      	movq	%r12, %rdx
   13a6b:      	callq	*%rax
   13a6d:      	movq	0x28(%rsp), %rbx
   13a72:      	movq	0x48(%rsp), %rax
   13a77:      	movl	0x5c(%rsp), %r15d
   13a7c:      	subq	%rbx, %rax
   13a7f:      	movl	0x50(%rsp), %r12d
   13a84:      	movl	%r15d, %edx
   13a87:      	subl	%r12d, %edx
   13a8a:      	movl	$0x0, %ecx
   13a8f:      	cmovbl	%ecx, %edx
   13a92:      	addq	0x60(%rsp), %rdx
   13a97:      	xorl	%esi, %esi
   13a99:      	cmpl	%r15d, %r12d
   13a9c:      	seta	%sil
   13aa0:      	movl	%r15d, %ecx
   13aa3:      	cmovbl	%r12d, %ecx
   13aa7:      	addl	%ecx, %esi
   13aa9:      	movl	%r12d, %edi
   13aac:      	subl	%esi, %edi
   13aae:      	movl	%edi, 0x50(%rsp)
   13ab2:      	subq	%rsi, %rax
   13ab5:      	jb	0x17392 <generic_kprobe_path+0xba72>
   13abb:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13ac1:      	ja	0x17392 <generic_kprobe_path+0xba72>
   13ac7:      	cmpl	%r15d, %r12d
   13aca:      	jbe	0x13ad0 <generic_kprobe_path+0x81b0>
   13acc:      	movb	$0x2f, (%rbx,%rax)
   13ad0:      	xorl	%edi, %edi
   13ad2:      	cmpl	%r15d, %r12d
   13ad5:      	seta	%dil
   13ad9:      	movzbl	%cl, %esi
   13adc:      	addq	%rax, %rbx
   13adf:      	addq	%rbx, %rdi
   13ae2:      	movl	$0x4, %eax
   13ae7:      	callq	*%rax
   13ae9:      	movq	%rbx, 0x48(%rsp)
   13aee:      	cmpl	%r15d, %r12d
   13af1:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   13af7:      	movq	0x8(%rsp), %r12
   13afc:      	movq	%r12, 0x30(%rsp)
   13b01:      	movq	0x38(%rsp), %rdx
   13b06:      	movq	0x40(%rsp), %r15
   13b0b:      	jmp	0x13b5e <generic_kprobe_path+0x823e>
   13b0d:      	leaq	0x10(%r15), %rdx
   13b11:      	movl	$0x4, %eax
   13b16:      	movq	%rbp, %rdi
   13b19:      	movl	$0x8, %esi
   13b1e:      	callq	*%rax
   13b20:      	movq	0x40(%rsp), %rax
   13b25:      	cmpq	(%rsp), %rax
   13b29:      	je	0x1738d <generic_kprobe_path+0xba6d>
   13b2f:      	addq	$0x18, %r15
   13b33:      	movl	$0x4, %eax
   13b38:      	leaq	0x30(%rsp), %rdi
   13b3d:      	movl	$0x8, %esi
   13b42:      	movq	%r15, %rdx
   13b45:      	callq	*%rax
   13b47:      	movq	(%rsp), %r15
   13b4b:      	movq	%r15, 0x40(%rsp)
   13b50:      	leaq	0x20(%r15), %rdx
   13b54:      	movq	%rdx, 0x38(%rsp)
   13b59:      	movq	0x30(%rsp), %r12
   13b5e:      	cmpq	0x18(%rsp), %r12
   13b63:      	jne	0x13b70 <generic_kprobe_path+0x8250>
   13b65:      	cmpq	0x20(%rsp), %rdx
   13b6a:      	je	0x1738d <generic_kprobe_path+0xba6d>
   13b70:      	movl	$0x4, %eax
   13b75:      	leaq	0x10(%rsp), %rdi
   13b7a:      	movl	$0x8, %esi
   13b7f:      	callq	*%rax
   13b81:      	cmpq	0x10(%rsp), %r12
   13b86:      	je	0x13c7e <generic_kprobe_path+0x835e>
   13b8c:      	leaq	0x18(%r12), %rbx
   13b91:      	movl	$0x4, %eax
   13b96:      	movq	%rbp, %rdi
   13b99:      	movl	$0x8, %esi
   13b9e:      	movq	%rbx, %rdx
   13ba1:      	callq	*%rax
   13ba3:      	cmpq	%r12, (%rsp)
   13ba7:      	je	0x13c7e <generic_kprobe_path+0x835e>
   13bad:      	movl	$0x4, %eax
   13bb2:      	leaq	0x8(%rsp), %rdi
   13bb7:      	movl	$0x8, %esi
   13bbc:      	movq	%rbx, %rdx
   13bbf:      	callq	*%rax
   13bc1:      	addq	$0x20, %r12
   13bc5:      	movl	$0x4, %eax
   13bca:      	leaq	0x58(%rsp), %rdi
   13bcf:      	movl	$0x10, %ecx
   13bd4:      	movl	$0x10, %esi
   13bd9:      	movq	%r12, %rdx
   13bdc:      	callq	*%rax
   13bde:      	movq	0x28(%rsp), %rbx
   13be3:      	movq	0x48(%rsp), %rax
   13be8:      	movl	0x5c(%rsp), %r15d
   13bed:      	subq	%rbx, %rax
   13bf0:      	movl	0x50(%rsp), %r12d
   13bf5:      	movl	%r15d, %edx
   13bf8:      	subl	%r12d, %edx
   13bfb:      	movl	$0x0, %ecx
   13c00:      	cmovbl	%ecx, %edx
   13c03:      	addq	0x60(%rsp), %rdx
   13c08:      	xorl	%esi, %esi
   13c0a:      	cmpl	%r15d, %r12d
   13c0d:      	seta	%sil
   13c11:      	movl	%r15d, %ecx
   13c14:      	cmovbl	%r12d, %ecx
   13c18:      	addl	%ecx, %esi
   13c1a:      	movl	%r12d, %edi
   13c1d:      	subl	%esi, %edi
   13c1f:      	movl	%edi, 0x50(%rsp)
   13c23:      	subq	%rsi, %rax
   13c26:      	jb	0x17392 <generic_kprobe_path+0xba72>
   13c2c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13c32:      	ja	0x17392 <generic_kprobe_path+0xba72>
   13c38:      	cmpl	%r15d, %r12d
   13c3b:      	jbe	0x13c41 <generic_kprobe_path+0x8321>
   13c3d:      	movb	$0x2f, (%rbx,%rax)
   13c41:      	xorl	%edi, %edi
   13c43:      	cmpl	%r15d, %r12d
   13c46:      	seta	%dil
   13c4a:      	movzbl	%cl, %esi
   13c4d:      	addq	%rax, %rbx
   13c50:      	addq	%rbx, %rdi
   13c53:      	movl	$0x4, %eax
   13c58:      	callq	*%rax
   13c5a:      	movq	%rbx, 0x48(%rsp)
   13c5f:      	cmpl	%r15d, %r12d
   13c62:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   13c68:      	movq	0x8(%rsp), %r12
   13c6d:      	movq	%r12, 0x30(%rsp)
   13c72:      	movq	0x38(%rsp), %rdx
   13c77:      	movq	0x40(%rsp), %r15
   13c7c:      	jmp	0x13ccf <generic_kprobe_path+0x83af>
   13c7e:      	leaq	0x10(%r15), %rdx
   13c82:      	movl	$0x4, %eax
   13c87:      	movq	%rbp, %rdi
   13c8a:      	movl	$0x8, %esi
   13c8f:      	callq	*%rax
   13c91:      	movq	0x40(%rsp), %rax
   13c96:      	cmpq	(%rsp), %rax
   13c9a:      	je	0x1738d <generic_kprobe_path+0xba6d>
   13ca0:      	addq	$0x18, %r15
   13ca4:      	movl	$0x4, %eax
   13ca9:      	leaq	0x30(%rsp), %rdi
   13cae:      	movl	$0x8, %esi
   13cb3:      	movq	%r15, %rdx
   13cb6:      	callq	*%rax
   13cb8:      	movq	(%rsp), %r15
   13cbc:      	movq	%r15, 0x40(%rsp)
   13cc1:      	leaq	0x20(%r15), %rdx
   13cc5:      	movq	%rdx, 0x38(%rsp)
   13cca:      	movq	0x30(%rsp), %r12
   13ccf:      	cmpq	0x18(%rsp), %r12
   13cd4:      	jne	0x13ce1 <generic_kprobe_path+0x83c1>
   13cd6:      	cmpq	0x20(%rsp), %rdx
   13cdb:      	je	0x1738d <generic_kprobe_path+0xba6d>
   13ce1:      	movl	$0x4, %eax
   13ce6:      	leaq	0x10(%rsp), %rdi
   13ceb:      	movl	$0x8, %esi
   13cf0:      	callq	*%rax
   13cf2:      	cmpq	0x10(%rsp), %r12
   13cf7:      	je	0x13def <generic_kprobe_path+0x84cf>
   13cfd:      	leaq	0x18(%r12), %rbx
   13d02:      	movl	$0x4, %eax
   13d07:      	movq	%rbp, %rdi
   13d0a:      	movl	$0x8, %esi
   13d0f:      	movq	%rbx, %rdx
   13d12:      	callq	*%rax
   13d14:      	cmpq	%r12, (%rsp)
   13d18:      	je	0x13def <generic_kprobe_path+0x84cf>
   13d1e:      	movl	$0x4, %eax
   13d23:      	leaq	0x8(%rsp), %rdi
   13d28:      	movl	$0x8, %esi
   13d2d:      	movq	%rbx, %rdx
   13d30:      	callq	*%rax
   13d32:      	addq	$0x20, %r12
   13d36:      	movl	$0x4, %eax
   13d3b:      	leaq	0x58(%rsp), %rdi
   13d40:      	movl	$0x10, %ecx
   13d45:      	movl	$0x10, %esi
   13d4a:      	movq	%r12, %rdx
   13d4d:      	callq	*%rax
   13d4f:      	movq	0x28(%rsp), %rbx
   13d54:      	movq	0x48(%rsp), %rax
   13d59:      	movl	0x5c(%rsp), %r15d
   13d5e:      	subq	%rbx, %rax
   13d61:      	movl	0x50(%rsp), %r12d
   13d66:      	movl	%r15d, %edx
   13d69:      	subl	%r12d, %edx
   13d6c:      	movl	$0x0, %ecx
   13d71:      	cmovbl	%ecx, %edx
   13d74:      	addq	0x60(%rsp), %rdx
   13d79:      	xorl	%esi, %esi
   13d7b:      	cmpl	%r15d, %r12d
   13d7e:      	seta	%sil
   13d82:      	movl	%r15d, %ecx
   13d85:      	cmovbl	%r12d, %ecx
   13d89:      	addl	%ecx, %esi
   13d8b:      	movl	%r12d, %edi
   13d8e:      	subl	%esi, %edi
   13d90:      	movl	%edi, 0x50(%rsp)
   13d94:      	subq	%rsi, %rax
   13d97:      	jb	0x17392 <generic_kprobe_path+0xba72>
   13d9d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13da3:      	ja	0x17392 <generic_kprobe_path+0xba72>
   13da9:      	cmpl	%r15d, %r12d
   13dac:      	jbe	0x13db2 <generic_kprobe_path+0x8492>
   13dae:      	movb	$0x2f, (%rbx,%rax)
   13db2:      	xorl	%edi, %edi
   13db4:      	cmpl	%r15d, %r12d
   13db7:      	seta	%dil
   13dbb:      	movzbl	%cl, %esi
   13dbe:      	addq	%rax, %rbx
   13dc1:      	addq	%rbx, %rdi
   13dc4:      	movl	$0x4, %eax
   13dc9:      	callq	*%rax
   13dcb:      	movq	%rbx, 0x48(%rsp)
   13dd0:      	cmpl	%r15d, %r12d
   13dd3:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   13dd9:      	movq	0x8(%rsp), %r12
   13dde:      	movq	%r12, 0x30(%rsp)
   13de3:      	movq	0x38(%rsp), %rdx
   13de8:      	movq	0x40(%rsp), %r15
   13ded:      	jmp	0x13e40 <generic_kprobe_path+0x8520>
   13def:      	leaq	0x10(%r15), %rdx
   13df3:      	movl	$0x4, %eax
   13df8:      	movq	%rbp, %rdi
   13dfb:      	movl	$0x8, %esi
   13e00:      	callq	*%rax
   13e02:      	movq	0x40(%rsp), %rax
   13e07:      	cmpq	(%rsp), %rax
   13e0b:      	je	0x1738d <generic_kprobe_path+0xba6d>
   13e11:      	addq	$0x18, %r15
   13e15:      	movl	$0x4, %eax
   13e1a:      	leaq	0x30(%rsp), %rdi
   13e1f:      	movl	$0x8, %esi
   13e24:      	movq	%r15, %rdx
   13e27:      	callq	*%rax
   13e29:      	movq	(%rsp), %r15
   13e2d:      	movq	%r15, 0x40(%rsp)
   13e32:      	leaq	0x20(%r15), %rdx
   13e36:      	movq	%rdx, 0x38(%rsp)
   13e3b:      	movq	0x30(%rsp), %r12
   13e40:      	cmpq	0x18(%rsp), %r12
   13e45:      	jne	0x13e52 <generic_kprobe_path+0x8532>
   13e47:      	cmpq	0x20(%rsp), %rdx
   13e4c:      	je	0x1738d <generic_kprobe_path+0xba6d>
   13e52:      	movl	$0x4, %eax
   13e57:      	leaq	0x10(%rsp), %rdi
   13e5c:      	movl	$0x8, %esi
   13e61:      	callq	*%rax
   13e63:      	cmpq	0x10(%rsp), %r12
   13e68:      	je	0x13f60 <generic_kprobe_path+0x8640>
   13e6e:      	leaq	0x18(%r12), %rbx
   13e73:      	movl	$0x4, %eax
   13e78:      	movq	%rbp, %rdi
   13e7b:      	movl	$0x8, %esi
   13e80:      	movq	%rbx, %rdx
   13e83:      	callq	*%rax
   13e85:      	cmpq	%r12, (%rsp)
   13e89:      	je	0x13f60 <generic_kprobe_path+0x8640>
   13e8f:      	movl	$0x4, %eax
   13e94:      	leaq	0x8(%rsp), %rdi
   13e99:      	movl	$0x8, %esi
   13e9e:      	movq	%rbx, %rdx
   13ea1:      	callq	*%rax
   13ea3:      	addq	$0x20, %r12
   13ea7:      	movl	$0x4, %eax
   13eac:      	leaq	0x58(%rsp), %rdi
   13eb1:      	movl	$0x10, %ecx
   13eb6:      	movl	$0x10, %esi
   13ebb:      	movq	%r12, %rdx
   13ebe:      	callq	*%rax
   13ec0:      	movq	0x28(%rsp), %rbx
   13ec5:      	movq	0x48(%rsp), %rax
   13eca:      	movl	0x5c(%rsp), %r15d
   13ecf:      	subq	%rbx, %rax
   13ed2:      	movl	0x50(%rsp), %r12d
   13ed7:      	movl	%r15d, %edx
   13eda:      	subl	%r12d, %edx
   13edd:      	movl	$0x0, %ecx
   13ee2:      	cmovbl	%ecx, %edx
   13ee5:      	addq	0x60(%rsp), %rdx
   13eea:      	xorl	%esi, %esi
   13eec:      	cmpl	%r15d, %r12d
   13eef:      	seta	%sil
   13ef3:      	movl	%r15d, %ecx
   13ef6:      	cmovbl	%r12d, %ecx
   13efa:      	addl	%ecx, %esi
   13efc:      	movl	%r12d, %edi
   13eff:      	subl	%esi, %edi
   13f01:      	movl	%edi, 0x50(%rsp)
   13f05:      	subq	%rsi, %rax
   13f08:      	jb	0x17392 <generic_kprobe_path+0xba72>
   13f0e:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13f14:      	ja	0x17392 <generic_kprobe_path+0xba72>
   13f1a:      	cmpl	%r15d, %r12d
   13f1d:      	jbe	0x13f23 <generic_kprobe_path+0x8603>
   13f1f:      	movb	$0x2f, (%rbx,%rax)
   13f23:      	xorl	%edi, %edi
   13f25:      	cmpl	%r15d, %r12d
   13f28:      	seta	%dil
   13f2c:      	movzbl	%cl, %esi
   13f2f:      	addq	%rax, %rbx
   13f32:      	addq	%rbx, %rdi
   13f35:      	movl	$0x4, %eax
   13f3a:      	callq	*%rax
   13f3c:      	movq	%rbx, 0x48(%rsp)
   13f41:      	cmpl	%r15d, %r12d
   13f44:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   13f4a:      	movq	0x8(%rsp), %r12
   13f4f:      	movq	%r12, 0x30(%rsp)
   13f54:      	movq	0x38(%rsp), %rdx
   13f59:      	movq	0x40(%rsp), %r15
   13f5e:      	jmp	0x13fb1 <generic_kprobe_path+0x8691>
   13f60:      	leaq	0x10(%r15), %rdx
   13f64:      	movl	$0x4, %eax
   13f69:      	movq	%rbp, %rdi
   13f6c:      	movl	$0x8, %esi
   13f71:      	callq	*%rax
   13f73:      	movq	0x40(%rsp), %rax
   13f78:      	cmpq	(%rsp), %rax
   13f7c:      	je	0x1738d <generic_kprobe_path+0xba6d>
   13f82:      	addq	$0x18, %r15
   13f86:      	movl	$0x4, %eax
   13f8b:      	leaq	0x30(%rsp), %rdi
   13f90:      	movl	$0x8, %esi
   13f95:      	movq	%r15, %rdx
   13f98:      	callq	*%rax
   13f9a:      	movq	(%rsp), %r15
   13f9e:      	movq	%r15, 0x40(%rsp)
   13fa3:      	leaq	0x20(%r15), %rdx
   13fa7:      	movq	%rdx, 0x38(%rsp)
   13fac:      	movq	0x30(%rsp), %r12
   13fb1:      	cmpq	0x18(%rsp), %r12
   13fb6:      	jne	0x13fc3 <generic_kprobe_path+0x86a3>
   13fb8:      	cmpq	0x20(%rsp), %rdx
   13fbd:      	je	0x1738d <generic_kprobe_path+0xba6d>
   13fc3:      	movl	$0x4, %eax
   13fc8:      	leaq	0x10(%rsp), %rdi
   13fcd:      	movl	$0x8, %esi
   13fd2:      	callq	*%rax
   13fd4:      	cmpq	0x10(%rsp), %r12
   13fd9:      	je	0x140d1 <generic_kprobe_path+0x87b1>
   13fdf:      	leaq	0x18(%r12), %rbx
   13fe4:      	movl	$0x4, %eax
   13fe9:      	movq	%rbp, %rdi
   13fec:      	movl	$0x8, %esi
   13ff1:      	movq	%rbx, %rdx
   13ff4:      	callq	*%rax
   13ff6:      	cmpq	%r12, (%rsp)
   13ffa:      	je	0x140d1 <generic_kprobe_path+0x87b1>
   14000:      	movl	$0x4, %eax
   14005:      	leaq	0x8(%rsp), %rdi
   1400a:      	movl	$0x8, %esi
   1400f:      	movq	%rbx, %rdx
   14012:      	callq	*%rax
   14014:      	addq	$0x20, %r12
   14018:      	movl	$0x4, %eax
   1401d:      	leaq	0x58(%rsp), %rdi
   14022:      	movl	$0x10, %ecx
   14027:      	movl	$0x10, %esi
   1402c:      	movq	%r12, %rdx
   1402f:      	callq	*%rax
   14031:      	movq	0x28(%rsp), %rbx
   14036:      	movq	0x48(%rsp), %rax
   1403b:      	movl	0x5c(%rsp), %r15d
   14040:      	subq	%rbx, %rax
   14043:      	movl	0x50(%rsp), %r12d
   14048:      	movl	%r15d, %edx
   1404b:      	subl	%r12d, %edx
   1404e:      	movl	$0x0, %ecx
   14053:      	cmovbl	%ecx, %edx
   14056:      	addq	0x60(%rsp), %rdx
   1405b:      	xorl	%esi, %esi
   1405d:      	cmpl	%r15d, %r12d
   14060:      	seta	%sil
   14064:      	movl	%r15d, %ecx
   14067:      	cmovbl	%r12d, %ecx
   1406b:      	addl	%ecx, %esi
   1406d:      	movl	%r12d, %edi
   14070:      	subl	%esi, %edi
   14072:      	movl	%edi, 0x50(%rsp)
   14076:      	subq	%rsi, %rax
   14079:      	jb	0x17392 <generic_kprobe_path+0xba72>
   1407f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14085:      	ja	0x17392 <generic_kprobe_path+0xba72>
   1408b:      	cmpl	%r15d, %r12d
   1408e:      	jbe	0x14094 <generic_kprobe_path+0x8774>
   14090:      	movb	$0x2f, (%rbx,%rax)
   14094:      	xorl	%edi, %edi
   14096:      	cmpl	%r15d, %r12d
   14099:      	seta	%dil
   1409d:      	movzbl	%cl, %esi
   140a0:      	addq	%rax, %rbx
   140a3:      	addq	%rbx, %rdi
   140a6:      	movl	$0x4, %eax
   140ab:      	callq	*%rax
   140ad:      	movq	%rbx, 0x48(%rsp)
   140b2:      	cmpl	%r15d, %r12d
   140b5:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   140bb:      	movq	0x8(%rsp), %r12
   140c0:      	movq	%r12, 0x30(%rsp)
   140c5:      	movq	0x38(%rsp), %rdx
   140ca:      	movq	0x40(%rsp), %r15
   140cf:      	jmp	0x14122 <generic_kprobe_path+0x8802>
   140d1:      	leaq	0x10(%r15), %rdx
   140d5:      	movl	$0x4, %eax
   140da:      	movq	%rbp, %rdi
   140dd:      	movl	$0x8, %esi
   140e2:      	callq	*%rax
   140e4:      	movq	0x40(%rsp), %rax
   140e9:      	cmpq	(%rsp), %rax
   140ed:      	je	0x1738d <generic_kprobe_path+0xba6d>
   140f3:      	addq	$0x18, %r15
   140f7:      	movl	$0x4, %eax
   140fc:      	leaq	0x30(%rsp), %rdi
   14101:      	movl	$0x8, %esi
   14106:      	movq	%r15, %rdx
   14109:      	callq	*%rax
   1410b:      	movq	(%rsp), %r15
   1410f:      	movq	%r15, 0x40(%rsp)
   14114:      	leaq	0x20(%r15), %rdx
   14118:      	movq	%rdx, 0x38(%rsp)
   1411d:      	movq	0x30(%rsp), %r12
   14122:      	cmpq	0x18(%rsp), %r12
   14127:      	jne	0x14134 <generic_kprobe_path+0x8814>
   14129:      	cmpq	0x20(%rsp), %rdx
   1412e:      	je	0x1738d <generic_kprobe_path+0xba6d>
   14134:      	movl	$0x4, %eax
   14139:      	leaq	0x10(%rsp), %rdi
   1413e:      	movl	$0x8, %esi
   14143:      	callq	*%rax
   14145:      	cmpq	0x10(%rsp), %r12
   1414a:      	je	0x14242 <generic_kprobe_path+0x8922>
   14150:      	leaq	0x18(%r12), %rbx
   14155:      	movl	$0x4, %eax
   1415a:      	movq	%rbp, %rdi
   1415d:      	movl	$0x8, %esi
   14162:      	movq	%rbx, %rdx
   14165:      	callq	*%rax
   14167:      	cmpq	%r12, (%rsp)
   1416b:      	je	0x14242 <generic_kprobe_path+0x8922>
   14171:      	movl	$0x4, %eax
   14176:      	leaq	0x8(%rsp), %rdi
   1417b:      	movl	$0x8, %esi
   14180:      	movq	%rbx, %rdx
   14183:      	callq	*%rax
   14185:      	addq	$0x20, %r12
   14189:      	movl	$0x4, %eax
   1418e:      	leaq	0x58(%rsp), %rdi
   14193:      	movl	$0x10, %ecx
   14198:      	movl	$0x10, %esi
   1419d:      	movq	%r12, %rdx
   141a0:      	callq	*%rax
   141a2:      	movq	0x28(%rsp), %rbx
   141a7:      	movq	0x48(%rsp), %rax
   141ac:      	movl	0x5c(%rsp), %r15d
   141b1:      	subq	%rbx, %rax
   141b4:      	movl	0x50(%rsp), %r12d
   141b9:      	movl	%r15d, %edx
   141bc:      	subl	%r12d, %edx
   141bf:      	movl	$0x0, %ecx
   141c4:      	cmovbl	%ecx, %edx
   141c7:      	addq	0x60(%rsp), %rdx
   141cc:      	xorl	%esi, %esi
   141ce:      	cmpl	%r15d, %r12d
   141d1:      	seta	%sil
   141d5:      	movl	%r15d, %ecx
   141d8:      	cmovbl	%r12d, %ecx
   141dc:      	addl	%ecx, %esi
   141de:      	movl	%r12d, %edi
   141e1:      	subl	%esi, %edi
   141e3:      	movl	%edi, 0x50(%rsp)
   141e7:      	subq	%rsi, %rax
   141ea:      	jb	0x17392 <generic_kprobe_path+0xba72>
   141f0:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   141f6:      	ja	0x17392 <generic_kprobe_path+0xba72>
   141fc:      	cmpl	%r15d, %r12d
   141ff:      	jbe	0x14205 <generic_kprobe_path+0x88e5>
   14201:      	movb	$0x2f, (%rbx,%rax)
   14205:      	xorl	%edi, %edi
   14207:      	cmpl	%r15d, %r12d
   1420a:      	seta	%dil
   1420e:      	movzbl	%cl, %esi
   14211:      	addq	%rax, %rbx
   14214:      	addq	%rbx, %rdi
   14217:      	movl	$0x4, %eax
   1421c:      	callq	*%rax
   1421e:      	movq	%rbx, 0x48(%rsp)
   14223:      	cmpl	%r15d, %r12d
   14226:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   1422c:      	movq	0x8(%rsp), %r12
   14231:      	movq	%r12, 0x30(%rsp)
   14236:      	movq	0x38(%rsp), %rdx
   1423b:      	movq	0x40(%rsp), %r15
   14240:      	jmp	0x14293 <generic_kprobe_path+0x8973>
   14242:      	leaq	0x10(%r15), %rdx
   14246:      	movl	$0x4, %eax
   1424b:      	movq	%rbp, %rdi
   1424e:      	movl	$0x8, %esi
   14253:      	callq	*%rax
   14255:      	movq	0x40(%rsp), %rax
   1425a:      	cmpq	(%rsp), %rax
   1425e:      	je	0x1738d <generic_kprobe_path+0xba6d>
   14264:      	addq	$0x18, %r15
   14268:      	movl	$0x4, %eax
   1426d:      	leaq	0x30(%rsp), %rdi
   14272:      	movl	$0x8, %esi
   14277:      	movq	%r15, %rdx
   1427a:      	callq	*%rax
   1427c:      	movq	(%rsp), %r15
   14280:      	movq	%r15, 0x40(%rsp)
   14285:      	leaq	0x20(%r15), %rdx
   14289:      	movq	%rdx, 0x38(%rsp)
   1428e:      	movq	0x30(%rsp), %r12
   14293:      	cmpq	0x18(%rsp), %r12
   14298:      	jne	0x142a5 <generic_kprobe_path+0x8985>
   1429a:      	cmpq	0x20(%rsp), %rdx
   1429f:      	je	0x1738d <generic_kprobe_path+0xba6d>
   142a5:      	movl	$0x4, %eax
   142aa:      	leaq	0x10(%rsp), %rdi
   142af:      	movl	$0x8, %esi
   142b4:      	callq	*%rax
   142b6:      	cmpq	0x10(%rsp), %r12
   142bb:      	je	0x143b3 <generic_kprobe_path+0x8a93>
   142c1:      	leaq	0x18(%r12), %rbx
   142c6:      	movl	$0x4, %eax
   142cb:      	movq	%rbp, %rdi
   142ce:      	movl	$0x8, %esi
   142d3:      	movq	%rbx, %rdx
   142d6:      	callq	*%rax
   142d8:      	cmpq	%r12, (%rsp)
   142dc:      	je	0x143b3 <generic_kprobe_path+0x8a93>
   142e2:      	movl	$0x4, %eax
   142e7:      	leaq	0x8(%rsp), %rdi
   142ec:      	movl	$0x8, %esi
   142f1:      	movq	%rbx, %rdx
   142f4:      	callq	*%rax
   142f6:      	addq	$0x20, %r12
   142fa:      	movl	$0x4, %eax
   142ff:      	leaq	0x58(%rsp), %rdi
   14304:      	movl	$0x10, %ecx
   14309:      	movl	$0x10, %esi
   1430e:      	movq	%r12, %rdx
   14311:      	callq	*%rax
   14313:      	movq	0x28(%rsp), %rbx
   14318:      	movq	0x48(%rsp), %rax
   1431d:      	movl	0x5c(%rsp), %r15d
   14322:      	subq	%rbx, %rax
   14325:      	movl	0x50(%rsp), %r12d
   1432a:      	movl	%r15d, %edx
   1432d:      	subl	%r12d, %edx
   14330:      	movl	$0x0, %ecx
   14335:      	cmovbl	%ecx, %edx
   14338:      	addq	0x60(%rsp), %rdx
   1433d:      	xorl	%esi, %esi
   1433f:      	cmpl	%r15d, %r12d
   14342:      	seta	%sil
   14346:      	movl	%r15d, %ecx
   14349:      	cmovbl	%r12d, %ecx
   1434d:      	addl	%ecx, %esi
   1434f:      	movl	%r12d, %edi
   14352:      	subl	%esi, %edi
   14354:      	movl	%edi, 0x50(%rsp)
   14358:      	subq	%rsi, %rax
   1435b:      	jb	0x17392 <generic_kprobe_path+0xba72>
   14361:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14367:      	ja	0x17392 <generic_kprobe_path+0xba72>
   1436d:      	cmpl	%r15d, %r12d
   14370:      	jbe	0x14376 <generic_kprobe_path+0x8a56>
   14372:      	movb	$0x2f, (%rbx,%rax)
   14376:      	xorl	%edi, %edi
   14378:      	cmpl	%r15d, %r12d
   1437b:      	seta	%dil
   1437f:      	movzbl	%cl, %esi
   14382:      	addq	%rax, %rbx
   14385:      	addq	%rbx, %rdi
   14388:      	movl	$0x4, %eax
   1438d:      	callq	*%rax
   1438f:      	movq	%rbx, 0x48(%rsp)
   14394:      	cmpl	%r15d, %r12d
   14397:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   1439d:      	movq	0x8(%rsp), %r12
   143a2:      	movq	%r12, 0x30(%rsp)
   143a7:      	movq	0x38(%rsp), %rdx
   143ac:      	movq	0x40(%rsp), %r15
   143b1:      	jmp	0x14404 <generic_kprobe_path+0x8ae4>
   143b3:      	leaq	0x10(%r15), %rdx
   143b7:      	movl	$0x4, %eax
   143bc:      	movq	%rbp, %rdi
   143bf:      	movl	$0x8, %esi
   143c4:      	callq	*%rax
   143c6:      	movq	0x40(%rsp), %rax
   143cb:      	cmpq	(%rsp), %rax
   143cf:      	je	0x1738d <generic_kprobe_path+0xba6d>
   143d5:      	addq	$0x18, %r15
   143d9:      	movl	$0x4, %eax
   143de:      	leaq	0x30(%rsp), %rdi
   143e3:      	movl	$0x8, %esi
   143e8:      	movq	%r15, %rdx
   143eb:      	callq	*%rax
   143ed:      	movq	(%rsp), %r15
   143f1:      	movq	%r15, 0x40(%rsp)
   143f6:      	leaq	0x20(%r15), %rdx
   143fa:      	movq	%rdx, 0x38(%rsp)
   143ff:      	movq	0x30(%rsp), %r12
   14404:      	cmpq	0x18(%rsp), %r12
   14409:      	jne	0x14416 <generic_kprobe_path+0x8af6>
   1440b:      	cmpq	0x20(%rsp), %rdx
   14410:      	je	0x1738d <generic_kprobe_path+0xba6d>
   14416:      	movl	$0x4, %eax
   1441b:      	leaq	0x10(%rsp), %rdi
   14420:      	movl	$0x8, %esi
   14425:      	callq	*%rax
   14427:      	cmpq	0x10(%rsp), %r12
   1442c:      	je	0x14524 <generic_kprobe_path+0x8c04>
   14432:      	leaq	0x18(%r12), %rbx
   14437:      	movl	$0x4, %eax
   1443c:      	movq	%rbp, %rdi
   1443f:      	movl	$0x8, %esi
   14444:      	movq	%rbx, %rdx
   14447:      	callq	*%rax
   14449:      	cmpq	%r12, (%rsp)
   1444d:      	je	0x14524 <generic_kprobe_path+0x8c04>
   14453:      	movl	$0x4, %eax
   14458:      	leaq	0x8(%rsp), %rdi
   1445d:      	movl	$0x8, %esi
   14462:      	movq	%rbx, %rdx
   14465:      	callq	*%rax
   14467:      	addq	$0x20, %r12
   1446b:      	movl	$0x4, %eax
   14470:      	leaq	0x58(%rsp), %rdi
   14475:      	movl	$0x10, %ecx
   1447a:      	movl	$0x10, %esi
   1447f:      	movq	%r12, %rdx
   14482:      	callq	*%rax
   14484:      	movq	0x28(%rsp), %rbx
   14489:      	movq	0x48(%rsp), %rax
   1448e:      	movl	0x5c(%rsp), %r15d
   14493:      	subq	%rbx, %rax
   14496:      	movl	0x50(%rsp), %r12d
   1449b:      	movl	%r15d, %edx
   1449e:      	subl	%r12d, %edx
   144a1:      	movl	$0x0, %ecx
   144a6:      	cmovbl	%ecx, %edx
   144a9:      	addq	0x60(%rsp), %rdx
   144ae:      	xorl	%esi, %esi
   144b0:      	cmpl	%r15d, %r12d
   144b3:      	seta	%sil
   144b7:      	movl	%r15d, %ecx
   144ba:      	cmovbl	%r12d, %ecx
   144be:      	addl	%ecx, %esi
   144c0:      	movl	%r12d, %edi
   144c3:      	subl	%esi, %edi
   144c5:      	movl	%edi, 0x50(%rsp)
   144c9:      	subq	%rsi, %rax
   144cc:      	jb	0x17392 <generic_kprobe_path+0xba72>
   144d2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   144d8:      	ja	0x17392 <generic_kprobe_path+0xba72>
   144de:      	cmpl	%r15d, %r12d
   144e1:      	jbe	0x144e7 <generic_kprobe_path+0x8bc7>
   144e3:      	movb	$0x2f, (%rbx,%rax)
   144e7:      	xorl	%edi, %edi
   144e9:      	cmpl	%r15d, %r12d
   144ec:      	seta	%dil
   144f0:      	movzbl	%cl, %esi
   144f3:      	addq	%rax, %rbx
   144f6:      	addq	%rbx, %rdi
   144f9:      	movl	$0x4, %eax
   144fe:      	callq	*%rax
   14500:      	movq	%rbx, 0x48(%rsp)
   14505:      	cmpl	%r15d, %r12d
   14508:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   1450e:      	movq	0x8(%rsp), %r12
   14513:      	movq	%r12, 0x30(%rsp)
   14518:      	movq	0x38(%rsp), %rdx
   1451d:      	movq	0x40(%rsp), %r15
   14522:      	jmp	0x14575 <generic_kprobe_path+0x8c55>
   14524:      	leaq	0x10(%r15), %rdx
   14528:      	movl	$0x4, %eax
   1452d:      	movq	%rbp, %rdi
   14530:      	movl	$0x8, %esi
   14535:      	callq	*%rax
   14537:      	movq	0x40(%rsp), %rax
   1453c:      	cmpq	(%rsp), %rax
   14540:      	je	0x1738d <generic_kprobe_path+0xba6d>
   14546:      	addq	$0x18, %r15
   1454a:      	movl	$0x4, %eax
   1454f:      	leaq	0x30(%rsp), %rdi
   14554:      	movl	$0x8, %esi
   14559:      	movq	%r15, %rdx
   1455c:      	callq	*%rax
   1455e:      	movq	(%rsp), %r15
   14562:      	movq	%r15, 0x40(%rsp)
   14567:      	leaq	0x20(%r15), %rdx
   1456b:      	movq	%rdx, 0x38(%rsp)
   14570:      	movq	0x30(%rsp), %r12
   14575:      	cmpq	0x18(%rsp), %r12
   1457a:      	jne	0x14587 <generic_kprobe_path+0x8c67>
   1457c:      	cmpq	0x20(%rsp), %rdx
   14581:      	je	0x1738d <generic_kprobe_path+0xba6d>
   14587:      	movl	$0x4, %eax
   1458c:      	leaq	0x10(%rsp), %rdi
   14591:      	movl	$0x8, %esi
   14596:      	callq	*%rax
   14598:      	cmpq	0x10(%rsp), %r12
   1459d:      	je	0x14695 <generic_kprobe_path+0x8d75>
   145a3:      	leaq	0x18(%r12), %rbx
   145a8:      	movl	$0x4, %eax
   145ad:      	movq	%rbp, %rdi
   145b0:      	movl	$0x8, %esi
   145b5:      	movq	%rbx, %rdx
   145b8:      	callq	*%rax
   145ba:      	cmpq	%r12, (%rsp)
   145be:      	je	0x14695 <generic_kprobe_path+0x8d75>
   145c4:      	movl	$0x4, %eax
   145c9:      	leaq	0x8(%rsp), %rdi
   145ce:      	movl	$0x8, %esi
   145d3:      	movq	%rbx, %rdx
   145d6:      	callq	*%rax
   145d8:      	addq	$0x20, %r12
   145dc:      	movl	$0x4, %eax
   145e1:      	leaq	0x58(%rsp), %rdi
   145e6:      	movl	$0x10, %ecx
   145eb:      	movl	$0x10, %esi
   145f0:      	movq	%r12, %rdx
   145f3:      	callq	*%rax
   145f5:      	movq	0x28(%rsp), %rbx
   145fa:      	movq	0x48(%rsp), %rax
   145ff:      	movl	0x5c(%rsp), %r15d
   14604:      	subq	%rbx, %rax
   14607:      	movl	0x50(%rsp), %r12d
   1460c:      	movl	%r15d, %edx
   1460f:      	subl	%r12d, %edx
   14612:      	movl	$0x0, %ecx
   14617:      	cmovbl	%ecx, %edx
   1461a:      	addq	0x60(%rsp), %rdx
   1461f:      	xorl	%esi, %esi
   14621:      	cmpl	%r15d, %r12d
   14624:      	seta	%sil
   14628:      	movl	%r15d, %ecx
   1462b:      	cmovbl	%r12d, %ecx
   1462f:      	addl	%ecx, %esi
   14631:      	movl	%r12d, %edi
   14634:      	subl	%esi, %edi
   14636:      	movl	%edi, 0x50(%rsp)
   1463a:      	subq	%rsi, %rax
   1463d:      	jb	0x17392 <generic_kprobe_path+0xba72>
   14643:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14649:      	ja	0x17392 <generic_kprobe_path+0xba72>
   1464f:      	cmpl	%r15d, %r12d
   14652:      	jbe	0x14658 <generic_kprobe_path+0x8d38>
   14654:      	movb	$0x2f, (%rbx,%rax)
   14658:      	xorl	%edi, %edi
   1465a:      	cmpl	%r15d, %r12d
   1465d:      	seta	%dil
   14661:      	movzbl	%cl, %esi
   14664:      	addq	%rax, %rbx
   14667:      	addq	%rbx, %rdi
   1466a:      	movl	$0x4, %eax
   1466f:      	callq	*%rax
   14671:      	movq	%rbx, 0x48(%rsp)
   14676:      	cmpl	%r15d, %r12d
   14679:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   1467f:      	movq	0x8(%rsp), %r12
   14684:      	movq	%r12, 0x30(%rsp)
   14689:      	movq	0x38(%rsp), %rdx
   1468e:      	movq	0x40(%rsp), %r15
   14693:      	jmp	0x146e6 <generic_kprobe_path+0x8dc6>
   14695:      	leaq	0x10(%r15), %rdx
   14699:      	movl	$0x4, %eax
   1469e:      	movq	%rbp, %rdi
   146a1:      	movl	$0x8, %esi
   146a6:      	callq	*%rax
   146a8:      	movq	0x40(%rsp), %rax
   146ad:      	cmpq	(%rsp), %rax
   146b1:      	je	0x1738d <generic_kprobe_path+0xba6d>
   146b7:      	addq	$0x18, %r15
   146bb:      	movl	$0x4, %eax
   146c0:      	leaq	0x30(%rsp), %rdi
   146c5:      	movl	$0x8, %esi
   146ca:      	movq	%r15, %rdx
   146cd:      	callq	*%rax
   146cf:      	movq	(%rsp), %r15
   146d3:      	movq	%r15, 0x40(%rsp)
   146d8:      	leaq	0x20(%r15), %rdx
   146dc:      	movq	%rdx, 0x38(%rsp)
   146e1:      	movq	0x30(%rsp), %r12
   146e6:      	cmpq	0x18(%rsp), %r12
   146eb:      	jne	0x146f8 <generic_kprobe_path+0x8dd8>
   146ed:      	cmpq	0x20(%rsp), %rdx
   146f2:      	je	0x1738d <generic_kprobe_path+0xba6d>
   146f8:      	movl	$0x4, %eax
   146fd:      	leaq	0x10(%rsp), %rdi
   14702:      	movl	$0x8, %esi
   14707:      	callq	*%rax
   14709:      	cmpq	0x10(%rsp), %r12
   1470e:      	je	0x14806 <generic_kprobe_path+0x8ee6>
   14714:      	leaq	0x18(%r12), %rbx
   14719:      	movl	$0x4, %eax
   1471e:      	movq	%rbp, %rdi
   14721:      	movl	$0x8, %esi
   14726:      	movq	%rbx, %rdx
   14729:      	callq	*%rax
   1472b:      	cmpq	%r12, (%rsp)
   1472f:      	je	0x14806 <generic_kprobe_path+0x8ee6>
   14735:      	movl	$0x4, %eax
   1473a:      	leaq	0x8(%rsp), %rdi
   1473f:      	movl	$0x8, %esi
   14744:      	movq	%rbx, %rdx
   14747:      	callq	*%rax
   14749:      	addq	$0x20, %r12
   1474d:      	movl	$0x4, %eax
   14752:      	leaq	0x58(%rsp), %rdi
   14757:      	movl	$0x10, %ecx
   1475c:      	movl	$0x10, %esi
   14761:      	movq	%r12, %rdx
   14764:      	callq	*%rax
   14766:      	movq	0x28(%rsp), %rbx
   1476b:      	movq	0x48(%rsp), %rax
   14770:      	movl	0x5c(%rsp), %r15d
   14775:      	subq	%rbx, %rax
   14778:      	movl	0x50(%rsp), %r12d
   1477d:      	movl	%r15d, %edx
   14780:      	subl	%r12d, %edx
   14783:      	movl	$0x0, %ecx
   14788:      	cmovbl	%ecx, %edx
   1478b:      	addq	0x60(%rsp), %rdx
   14790:      	xorl	%esi, %esi
   14792:      	cmpl	%r15d, %r12d
   14795:      	seta	%sil
   14799:      	movl	%r15d, %ecx
   1479c:      	cmovbl	%r12d, %ecx
   147a0:      	addl	%ecx, %esi
   147a2:      	movl	%r12d, %edi
   147a5:      	subl	%esi, %edi
   147a7:      	movl	%edi, 0x50(%rsp)
   147ab:      	subq	%rsi, %rax
   147ae:      	jb	0x17392 <generic_kprobe_path+0xba72>
   147b4:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   147ba:      	ja	0x17392 <generic_kprobe_path+0xba72>
   147c0:      	cmpl	%r15d, %r12d
   147c3:      	jbe	0x147c9 <generic_kprobe_path+0x8ea9>
   147c5:      	movb	$0x2f, (%rbx,%rax)
   147c9:      	xorl	%edi, %edi
   147cb:      	cmpl	%r15d, %r12d
   147ce:      	seta	%dil
   147d2:      	movzbl	%cl, %esi
   147d5:      	addq	%rax, %rbx
   147d8:      	addq	%rbx, %rdi
   147db:      	movl	$0x4, %eax
   147e0:      	callq	*%rax
   147e2:      	movq	%rbx, 0x48(%rsp)
   147e7:      	cmpl	%r15d, %r12d
   147ea:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   147f0:      	movq	0x8(%rsp), %r12
   147f5:      	movq	%r12, 0x30(%rsp)
   147fa:      	movq	0x38(%rsp), %rdx
   147ff:      	movq	0x40(%rsp), %r15
   14804:      	jmp	0x14857 <generic_kprobe_path+0x8f37>
   14806:      	leaq	0x10(%r15), %rdx
   1480a:      	movl	$0x4, %eax
   1480f:      	movq	%rbp, %rdi
   14812:      	movl	$0x8, %esi
   14817:      	callq	*%rax
   14819:      	movq	0x40(%rsp), %rax
   1481e:      	cmpq	(%rsp), %rax
   14822:      	je	0x1738d <generic_kprobe_path+0xba6d>
   14828:      	addq	$0x18, %r15
   1482c:      	movl	$0x4, %eax
   14831:      	leaq	0x30(%rsp), %rdi
   14836:      	movl	$0x8, %esi
   1483b:      	movq	%r15, %rdx
   1483e:      	callq	*%rax
   14840:      	movq	(%rsp), %r15
   14844:      	movq	%r15, 0x40(%rsp)
   14849:      	leaq	0x20(%r15), %rdx
   1484d:      	movq	%rdx, 0x38(%rsp)
   14852:      	movq	0x30(%rsp), %r12
   14857:      	cmpq	0x18(%rsp), %r12
   1485c:      	jne	0x14869 <generic_kprobe_path+0x8f49>
   1485e:      	cmpq	0x20(%rsp), %rdx
   14863:      	je	0x1738d <generic_kprobe_path+0xba6d>
   14869:      	movl	$0x4, %eax
   1486e:      	leaq	0x10(%rsp), %rdi
   14873:      	movl	$0x8, %esi
   14878:      	callq	*%rax
   1487a:      	cmpq	0x10(%rsp), %r12
   1487f:      	je	0x14977 <generic_kprobe_path+0x9057>
   14885:      	leaq	0x18(%r12), %rbx
   1488a:      	movl	$0x4, %eax
   1488f:      	movq	%rbp, %rdi
   14892:      	movl	$0x8, %esi
   14897:      	movq	%rbx, %rdx
   1489a:      	callq	*%rax
   1489c:      	cmpq	%r12, (%rsp)
   148a0:      	je	0x14977 <generic_kprobe_path+0x9057>
   148a6:      	movl	$0x4, %eax
   148ab:      	leaq	0x8(%rsp), %rdi
   148b0:      	movl	$0x8, %esi
   148b5:      	movq	%rbx, %rdx
   148b8:      	callq	*%rax
   148ba:      	addq	$0x20, %r12
   148be:      	movl	$0x4, %eax
   148c3:      	leaq	0x58(%rsp), %rdi
   148c8:      	movl	$0x10, %ecx
   148cd:      	movl	$0x10, %esi
   148d2:      	movq	%r12, %rdx
   148d5:      	callq	*%rax
   148d7:      	movq	0x28(%rsp), %rbx
   148dc:      	movq	0x48(%rsp), %rax
   148e1:      	movl	0x5c(%rsp), %r15d
   148e6:      	subq	%rbx, %rax
   148e9:      	movl	0x50(%rsp), %r12d
   148ee:      	movl	%r15d, %edx
   148f1:      	subl	%r12d, %edx
   148f4:      	movl	$0x0, %ecx
   148f9:      	cmovbl	%ecx, %edx
   148fc:      	addq	0x60(%rsp), %rdx
   14901:      	xorl	%esi, %esi
   14903:      	cmpl	%r15d, %r12d
   14906:      	seta	%sil
   1490a:      	movl	%r15d, %ecx
   1490d:      	cmovbl	%r12d, %ecx
   14911:      	addl	%ecx, %esi
   14913:      	movl	%r12d, %edi
   14916:      	subl	%esi, %edi
   14918:      	movl	%edi, 0x50(%rsp)
   1491c:      	subq	%rsi, %rax
   1491f:      	jb	0x17392 <generic_kprobe_path+0xba72>
   14925:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1492b:      	ja	0x17392 <generic_kprobe_path+0xba72>
   14931:      	cmpl	%r15d, %r12d
   14934:      	jbe	0x1493a <generic_kprobe_path+0x901a>
   14936:      	movb	$0x2f, (%rbx,%rax)
   1493a:      	xorl	%edi, %edi
   1493c:      	cmpl	%r15d, %r12d
   1493f:      	seta	%dil
   14943:      	movzbl	%cl, %esi
   14946:      	addq	%rax, %rbx
   14949:      	addq	%rbx, %rdi
   1494c:      	movl	$0x4, %eax
   14951:      	callq	*%rax
   14953:      	movq	%rbx, 0x48(%rsp)
   14958:      	cmpl	%r15d, %r12d
   1495b:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   14961:      	movq	0x8(%rsp), %r12
   14966:      	movq	%r12, 0x30(%rsp)
   1496b:      	movq	0x38(%rsp), %rdx
   14970:      	movq	0x40(%rsp), %r15
   14975:      	jmp	0x149c8 <generic_kprobe_path+0x90a8>
   14977:      	leaq	0x10(%r15), %rdx
   1497b:      	movl	$0x4, %eax
   14980:      	movq	%rbp, %rdi
   14983:      	movl	$0x8, %esi
   14988:      	callq	*%rax
   1498a:      	movq	0x40(%rsp), %rax
   1498f:      	cmpq	(%rsp), %rax
   14993:      	je	0x1738d <generic_kprobe_path+0xba6d>
   14999:      	addq	$0x18, %r15
   1499d:      	movl	$0x4, %eax
   149a2:      	leaq	0x30(%rsp), %rdi
   149a7:      	movl	$0x8, %esi
   149ac:      	movq	%r15, %rdx
   149af:      	callq	*%rax
   149b1:      	movq	(%rsp), %r15
   149b5:      	movq	%r15, 0x40(%rsp)
   149ba:      	leaq	0x20(%r15), %rdx
   149be:      	movq	%rdx, 0x38(%rsp)
   149c3:      	movq	0x30(%rsp), %r12
   149c8:      	cmpq	0x18(%rsp), %r12
   149cd:      	jne	0x149da <generic_kprobe_path+0x90ba>
   149cf:      	cmpq	0x20(%rsp), %rdx
   149d4:      	je	0x1738d <generic_kprobe_path+0xba6d>
   149da:      	movl	$0x4, %eax
   149df:      	leaq	0x10(%rsp), %rdi
   149e4:      	movl	$0x8, %esi
   149e9:      	callq	*%rax
   149eb:      	cmpq	0x10(%rsp), %r12
   149f0:      	je	0x14ae8 <generic_kprobe_path+0x91c8>
   149f6:      	leaq	0x18(%r12), %rbx
   149fb:      	movl	$0x4, %eax
   14a00:      	movq	%rbp, %rdi
   14a03:      	movl	$0x8, %esi
   14a08:      	movq	%rbx, %rdx
   14a0b:      	callq	*%rax
   14a0d:      	cmpq	%r12, (%rsp)
   14a11:      	je	0x14ae8 <generic_kprobe_path+0x91c8>
   14a17:      	movl	$0x4, %eax
   14a1c:      	leaq	0x8(%rsp), %rdi
   14a21:      	movl	$0x8, %esi
   14a26:      	movq	%rbx, %rdx
   14a29:      	callq	*%rax
   14a2b:      	addq	$0x20, %r12
   14a2f:      	movl	$0x4, %eax
   14a34:      	leaq	0x58(%rsp), %rdi
   14a39:      	movl	$0x10, %ecx
   14a3e:      	movl	$0x10, %esi
   14a43:      	movq	%r12, %rdx
   14a46:      	callq	*%rax
   14a48:      	movq	0x28(%rsp), %rbx
   14a4d:      	movq	0x48(%rsp), %rax
   14a52:      	movl	0x5c(%rsp), %r15d
   14a57:      	subq	%rbx, %rax
   14a5a:      	movl	0x50(%rsp), %r12d
   14a5f:      	movl	%r15d, %edx
   14a62:      	subl	%r12d, %edx
   14a65:      	movl	$0x0, %ecx
   14a6a:      	cmovbl	%ecx, %edx
   14a6d:      	addq	0x60(%rsp), %rdx
   14a72:      	xorl	%esi, %esi
   14a74:      	cmpl	%r15d, %r12d
   14a77:      	seta	%sil
   14a7b:      	movl	%r15d, %ecx
   14a7e:      	cmovbl	%r12d, %ecx
   14a82:      	addl	%ecx, %esi
   14a84:      	movl	%r12d, %edi
   14a87:      	subl	%esi, %edi
   14a89:      	movl	%edi, 0x50(%rsp)
   14a8d:      	subq	%rsi, %rax
   14a90:      	jb	0x17392 <generic_kprobe_path+0xba72>
   14a96:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14a9c:      	ja	0x17392 <generic_kprobe_path+0xba72>
   14aa2:      	cmpl	%r15d, %r12d
   14aa5:      	jbe	0x14aab <generic_kprobe_path+0x918b>
   14aa7:      	movb	$0x2f, (%rbx,%rax)
   14aab:      	xorl	%edi, %edi
   14aad:      	cmpl	%r15d, %r12d
   14ab0:      	seta	%dil
   14ab4:      	movzbl	%cl, %esi
   14ab7:      	addq	%rax, %rbx
   14aba:      	addq	%rbx, %rdi
   14abd:      	movl	$0x4, %eax
   14ac2:      	callq	*%rax
   14ac4:      	movq	%rbx, 0x48(%rsp)
   14ac9:      	cmpl	%r15d, %r12d
   14acc:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   14ad2:      	movq	0x8(%rsp), %r12
   14ad7:      	movq	%r12, 0x30(%rsp)
   14adc:      	movq	0x38(%rsp), %rdx
   14ae1:      	movq	0x40(%rsp), %r15
   14ae6:      	jmp	0x14b39 <generic_kprobe_path+0x9219>
   14ae8:      	leaq	0x10(%r15), %rdx
   14aec:      	movl	$0x4, %eax
   14af1:      	movq	%rbp, %rdi
   14af4:      	movl	$0x8, %esi
   14af9:      	callq	*%rax
   14afb:      	movq	0x40(%rsp), %rax
   14b00:      	cmpq	(%rsp), %rax
   14b04:      	je	0x1738d <generic_kprobe_path+0xba6d>
   14b0a:      	addq	$0x18, %r15
   14b0e:      	movl	$0x4, %eax
   14b13:      	leaq	0x30(%rsp), %rdi
   14b18:      	movl	$0x8, %esi
   14b1d:      	movq	%r15, %rdx
   14b20:      	callq	*%rax
   14b22:      	movq	(%rsp), %r15
   14b26:      	movq	%r15, 0x40(%rsp)
   14b2b:      	leaq	0x20(%r15), %rdx
   14b2f:      	movq	%rdx, 0x38(%rsp)
   14b34:      	movq	0x30(%rsp), %r12
   14b39:      	cmpq	0x18(%rsp), %r12
   14b3e:      	jne	0x14b4b <generic_kprobe_path+0x922b>
   14b40:      	cmpq	0x20(%rsp), %rdx
   14b45:      	je	0x1738d <generic_kprobe_path+0xba6d>
   14b4b:      	movl	$0x4, %eax
   14b50:      	leaq	0x10(%rsp), %rdi
   14b55:      	movl	$0x8, %esi
   14b5a:      	callq	*%rax
   14b5c:      	cmpq	0x10(%rsp), %r12
   14b61:      	je	0x14c59 <generic_kprobe_path+0x9339>
   14b67:      	leaq	0x18(%r12), %rbx
   14b6c:      	movl	$0x4, %eax
   14b71:      	movq	%rbp, %rdi
   14b74:      	movl	$0x8, %esi
   14b79:      	movq	%rbx, %rdx
   14b7c:      	callq	*%rax
   14b7e:      	cmpq	%r12, (%rsp)
   14b82:      	je	0x14c59 <generic_kprobe_path+0x9339>
   14b88:      	movl	$0x4, %eax
   14b8d:      	leaq	0x8(%rsp), %rdi
   14b92:      	movl	$0x8, %esi
   14b97:      	movq	%rbx, %rdx
   14b9a:      	callq	*%rax
   14b9c:      	addq	$0x20, %r12
   14ba0:      	movl	$0x4, %eax
   14ba5:      	leaq	0x58(%rsp), %rdi
   14baa:      	movl	$0x10, %ecx
   14baf:      	movl	$0x10, %esi
   14bb4:      	movq	%r12, %rdx
   14bb7:      	callq	*%rax
   14bb9:      	movq	0x28(%rsp), %rbx
   14bbe:      	movq	0x48(%rsp), %rax
   14bc3:      	movl	0x5c(%rsp), %r15d
   14bc8:      	subq	%rbx, %rax
   14bcb:      	movl	0x50(%rsp), %r12d
   14bd0:      	movl	%r15d, %edx
   14bd3:      	subl	%r12d, %edx
   14bd6:      	movl	$0x0, %ecx
   14bdb:      	cmovbl	%ecx, %edx
   14bde:      	addq	0x60(%rsp), %rdx
   14be3:      	xorl	%esi, %esi
   14be5:      	cmpl	%r15d, %r12d
   14be8:      	seta	%sil
   14bec:      	movl	%r15d, %ecx
   14bef:      	cmovbl	%r12d, %ecx
   14bf3:      	addl	%ecx, %esi
   14bf5:      	movl	%r12d, %edi
   14bf8:      	subl	%esi, %edi
   14bfa:      	movl	%edi, 0x50(%rsp)
   14bfe:      	subq	%rsi, %rax
   14c01:      	jb	0x17392 <generic_kprobe_path+0xba72>
   14c07:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14c0d:      	ja	0x17392 <generic_kprobe_path+0xba72>
   14c13:      	cmpl	%r15d, %r12d
   14c16:      	jbe	0x14c1c <generic_kprobe_path+0x92fc>
   14c18:      	movb	$0x2f, (%rbx,%rax)
   14c1c:      	xorl	%edi, %edi
   14c1e:      	cmpl	%r15d, %r12d
   14c21:      	seta	%dil
   14c25:      	movzbl	%cl, %esi
   14c28:      	addq	%rax, %rbx
   14c2b:      	addq	%rbx, %rdi
   14c2e:      	movl	$0x4, %eax
   14c33:      	callq	*%rax
   14c35:      	movq	%rbx, 0x48(%rsp)
   14c3a:      	cmpl	%r15d, %r12d
   14c3d:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   14c43:      	movq	0x8(%rsp), %r12
   14c48:      	movq	%r12, 0x30(%rsp)
   14c4d:      	movq	0x38(%rsp), %rdx
   14c52:      	movq	0x40(%rsp), %r15
   14c57:      	jmp	0x14caa <generic_kprobe_path+0x938a>
   14c59:      	leaq	0x10(%r15), %rdx
   14c5d:      	movl	$0x4, %eax
   14c62:      	movq	%rbp, %rdi
   14c65:      	movl	$0x8, %esi
   14c6a:      	callq	*%rax
   14c6c:      	movq	0x40(%rsp), %rax
   14c71:      	cmpq	(%rsp), %rax
   14c75:      	je	0x1738d <generic_kprobe_path+0xba6d>
   14c7b:      	addq	$0x18, %r15
   14c7f:      	movl	$0x4, %eax
   14c84:      	leaq	0x30(%rsp), %rdi
   14c89:      	movl	$0x8, %esi
   14c8e:      	movq	%r15, %rdx
   14c91:      	callq	*%rax
   14c93:      	movq	(%rsp), %r15
   14c97:      	movq	%r15, 0x40(%rsp)
   14c9c:      	leaq	0x20(%r15), %rdx
   14ca0:      	movq	%rdx, 0x38(%rsp)
   14ca5:      	movq	0x30(%rsp), %r12
   14caa:      	cmpq	0x18(%rsp), %r12
   14caf:      	jne	0x14cbc <generic_kprobe_path+0x939c>
   14cb1:      	cmpq	0x20(%rsp), %rdx
   14cb6:      	je	0x1738d <generic_kprobe_path+0xba6d>
   14cbc:      	movl	$0x4, %eax
   14cc1:      	leaq	0x10(%rsp), %rdi
   14cc6:      	movl	$0x8, %esi
   14ccb:      	callq	*%rax
   14ccd:      	cmpq	0x10(%rsp), %r12
   14cd2:      	je	0x14dca <generic_kprobe_path+0x94aa>
   14cd8:      	leaq	0x18(%r12), %rbx
   14cdd:      	movl	$0x4, %eax
   14ce2:      	movq	%rbp, %rdi
   14ce5:      	movl	$0x8, %esi
   14cea:      	movq	%rbx, %rdx
   14ced:      	callq	*%rax
   14cef:      	cmpq	%r12, (%rsp)
   14cf3:      	je	0x14dca <generic_kprobe_path+0x94aa>
   14cf9:      	movl	$0x4, %eax
   14cfe:      	leaq	0x8(%rsp), %rdi
   14d03:      	movl	$0x8, %esi
   14d08:      	movq	%rbx, %rdx
   14d0b:      	callq	*%rax
   14d0d:      	addq	$0x20, %r12
   14d11:      	movl	$0x4, %eax
   14d16:      	leaq	0x58(%rsp), %rdi
   14d1b:      	movl	$0x10, %ecx
   14d20:      	movl	$0x10, %esi
   14d25:      	movq	%r12, %rdx
   14d28:      	callq	*%rax
   14d2a:      	movq	0x28(%rsp), %rbx
   14d2f:      	movq	0x48(%rsp), %rax
   14d34:      	movl	0x5c(%rsp), %r15d
   14d39:      	subq	%rbx, %rax
   14d3c:      	movl	0x50(%rsp), %r12d
   14d41:      	movl	%r15d, %edx
   14d44:      	subl	%r12d, %edx
   14d47:      	movl	$0x0, %ecx
   14d4c:      	cmovbl	%ecx, %edx
   14d4f:      	addq	0x60(%rsp), %rdx
   14d54:      	xorl	%esi, %esi
   14d56:      	cmpl	%r15d, %r12d
   14d59:      	seta	%sil
   14d5d:      	movl	%r15d, %ecx
   14d60:      	cmovbl	%r12d, %ecx
   14d64:      	addl	%ecx, %esi
   14d66:      	movl	%r12d, %edi
   14d69:      	subl	%esi, %edi
   14d6b:      	movl	%edi, 0x50(%rsp)
   14d6f:      	subq	%rsi, %rax
   14d72:      	jb	0x17392 <generic_kprobe_path+0xba72>
   14d78:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14d7e:      	ja	0x17392 <generic_kprobe_path+0xba72>
   14d84:      	cmpl	%r15d, %r12d
   14d87:      	jbe	0x14d8d <generic_kprobe_path+0x946d>
   14d89:      	movb	$0x2f, (%rbx,%rax)
   14d8d:      	xorl	%edi, %edi
   14d8f:      	cmpl	%r15d, %r12d
   14d92:      	seta	%dil
   14d96:      	movzbl	%cl, %esi
   14d99:      	addq	%rax, %rbx
   14d9c:      	addq	%rbx, %rdi
   14d9f:      	movl	$0x4, %eax
   14da4:      	callq	*%rax
   14da6:      	movq	%rbx, 0x48(%rsp)
   14dab:      	cmpl	%r15d, %r12d
   14dae:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   14db4:      	movq	0x8(%rsp), %r12
   14db9:      	movq	%r12, 0x30(%rsp)
   14dbe:      	movq	0x38(%rsp), %rdx
   14dc3:      	movq	0x40(%rsp), %r15
   14dc8:      	jmp	0x14e1b <generic_kprobe_path+0x94fb>
   14dca:      	leaq	0x10(%r15), %rdx
   14dce:      	movl	$0x4, %eax
   14dd3:      	movq	%rbp, %rdi
   14dd6:      	movl	$0x8, %esi
   14ddb:      	callq	*%rax
   14ddd:      	movq	0x40(%rsp), %rax
   14de2:      	cmpq	(%rsp), %rax
   14de6:      	je	0x1738d <generic_kprobe_path+0xba6d>
   14dec:      	addq	$0x18, %r15
   14df0:      	movl	$0x4, %eax
   14df5:      	leaq	0x30(%rsp), %rdi
   14dfa:      	movl	$0x8, %esi
   14dff:      	movq	%r15, %rdx
   14e02:      	callq	*%rax
   14e04:      	movq	(%rsp), %r15
   14e08:      	movq	%r15, 0x40(%rsp)
   14e0d:      	leaq	0x20(%r15), %rdx
   14e11:      	movq	%rdx, 0x38(%rsp)
   14e16:      	movq	0x30(%rsp), %r12
   14e1b:      	cmpq	0x18(%rsp), %r12
   14e20:      	jne	0x14e2d <generic_kprobe_path+0x950d>
   14e22:      	cmpq	0x20(%rsp), %rdx
   14e27:      	je	0x1738d <generic_kprobe_path+0xba6d>
   14e2d:      	movl	$0x4, %eax
   14e32:      	leaq	0x10(%rsp), %rdi
   14e37:      	movl	$0x8, %esi
   14e3c:      	callq	*%rax
   14e3e:      	cmpq	0x10(%rsp), %r12
   14e43:      	je	0x14f3b <generic_kprobe_path+0x961b>
   14e49:      	leaq	0x18(%r12), %rbx
   14e4e:      	movl	$0x4, %eax
   14e53:      	movq	%rbp, %rdi
   14e56:      	movl	$0x8, %esi
   14e5b:      	movq	%rbx, %rdx
   14e5e:      	callq	*%rax
   14e60:      	cmpq	%r12, (%rsp)
   14e64:      	je	0x14f3b <generic_kprobe_path+0x961b>
   14e6a:      	movl	$0x4, %eax
   14e6f:      	leaq	0x8(%rsp), %rdi
   14e74:      	movl	$0x8, %esi
   14e79:      	movq	%rbx, %rdx
   14e7c:      	callq	*%rax
   14e7e:      	addq	$0x20, %r12
   14e82:      	movl	$0x4, %eax
   14e87:      	leaq	0x58(%rsp), %rdi
   14e8c:      	movl	$0x10, %ecx
   14e91:      	movl	$0x10, %esi
   14e96:      	movq	%r12, %rdx
   14e99:      	callq	*%rax
   14e9b:      	movq	0x28(%rsp), %rbx
   14ea0:      	movq	0x48(%rsp), %rax
   14ea5:      	movl	0x5c(%rsp), %r15d
   14eaa:      	subq	%rbx, %rax
   14ead:      	movl	0x50(%rsp), %r12d
   14eb2:      	movl	%r15d, %edx
   14eb5:      	subl	%r12d, %edx
   14eb8:      	movl	$0x0, %ecx
   14ebd:      	cmovbl	%ecx, %edx
   14ec0:      	addq	0x60(%rsp), %rdx
   14ec5:      	xorl	%esi, %esi
   14ec7:      	cmpl	%r15d, %r12d
   14eca:      	seta	%sil
   14ece:      	movl	%r15d, %ecx
   14ed1:      	cmovbl	%r12d, %ecx
   14ed5:      	addl	%ecx, %esi
   14ed7:      	movl	%r12d, %edi
   14eda:      	subl	%esi, %edi
   14edc:      	movl	%edi, 0x50(%rsp)
   14ee0:      	subq	%rsi, %rax
   14ee3:      	jb	0x17392 <generic_kprobe_path+0xba72>
   14ee9:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14eef:      	ja	0x17392 <generic_kprobe_path+0xba72>
   14ef5:      	cmpl	%r15d, %r12d
   14ef8:      	jbe	0x14efe <generic_kprobe_path+0x95de>
   14efa:      	movb	$0x2f, (%rbx,%rax)
   14efe:      	xorl	%edi, %edi
   14f00:      	cmpl	%r15d, %r12d
   14f03:      	seta	%dil
   14f07:      	movzbl	%cl, %esi
   14f0a:      	addq	%rax, %rbx
   14f0d:      	addq	%rbx, %rdi
   14f10:      	movl	$0x4, %eax
   14f15:      	callq	*%rax
   14f17:      	movq	%rbx, 0x48(%rsp)
   14f1c:      	cmpl	%r15d, %r12d
   14f1f:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   14f25:      	movq	0x8(%rsp), %r12
   14f2a:      	movq	%r12, 0x30(%rsp)
   14f2f:      	movq	0x38(%rsp), %rdx
   14f34:      	movq	0x40(%rsp), %r15
   14f39:      	jmp	0x14f8c <generic_kprobe_path+0x966c>
   14f3b:      	leaq	0x10(%r15), %rdx
   14f3f:      	movl	$0x4, %eax
   14f44:      	movq	%rbp, %rdi
   14f47:      	movl	$0x8, %esi
   14f4c:      	callq	*%rax
   14f4e:      	movq	0x40(%rsp), %rax
   14f53:      	cmpq	(%rsp), %rax
   14f57:      	je	0x1738d <generic_kprobe_path+0xba6d>
   14f5d:      	addq	$0x18, %r15
   14f61:      	movl	$0x4, %eax
   14f66:      	leaq	0x30(%rsp), %rdi
   14f6b:      	movl	$0x8, %esi
   14f70:      	movq	%r15, %rdx
   14f73:      	callq	*%rax
   14f75:      	movq	(%rsp), %r15
   14f79:      	movq	%r15, 0x40(%rsp)
   14f7e:      	leaq	0x20(%r15), %rdx
   14f82:      	movq	%rdx, 0x38(%rsp)
   14f87:      	movq	0x30(%rsp), %r12
   14f8c:      	cmpq	0x18(%rsp), %r12
   14f91:      	jne	0x14f9e <generic_kprobe_path+0x967e>
   14f93:      	cmpq	0x20(%rsp), %rdx
   14f98:      	je	0x1738d <generic_kprobe_path+0xba6d>
   14f9e:      	movl	$0x4, %eax
   14fa3:      	leaq	0x10(%rsp), %rdi
   14fa8:      	movl	$0x8, %esi
   14fad:      	callq	*%rax
   14faf:      	cmpq	0x10(%rsp), %r12
   14fb4:      	je	0x150ac <generic_kprobe_path+0x978c>
   14fba:      	leaq	0x18(%r12), %rbx
   14fbf:      	movl	$0x4, %eax
   14fc4:      	movq	%rbp, %rdi
   14fc7:      	movl	$0x8, %esi
   14fcc:      	movq	%rbx, %rdx
   14fcf:      	callq	*%rax
   14fd1:      	cmpq	%r12, (%rsp)
   14fd5:      	je	0x150ac <generic_kprobe_path+0x978c>
   14fdb:      	movl	$0x4, %eax
   14fe0:      	leaq	0x8(%rsp), %rdi
   14fe5:      	movl	$0x8, %esi
   14fea:      	movq	%rbx, %rdx
   14fed:      	callq	*%rax
   14fef:      	addq	$0x20, %r12
   14ff3:      	movl	$0x4, %eax
   14ff8:      	leaq	0x58(%rsp), %rdi
   14ffd:      	movl	$0x10, %ecx
   15002:      	movl	$0x10, %esi
   15007:      	movq	%r12, %rdx
   1500a:      	callq	*%rax
   1500c:      	movq	0x28(%rsp), %rbx
   15011:      	movq	0x48(%rsp), %rax
   15016:      	movl	0x5c(%rsp), %r15d
   1501b:      	subq	%rbx, %rax
   1501e:      	movl	0x50(%rsp), %r12d
   15023:      	movl	%r15d, %edx
   15026:      	subl	%r12d, %edx
   15029:      	movl	$0x0, %ecx
   1502e:      	cmovbl	%ecx, %edx
   15031:      	addq	0x60(%rsp), %rdx
   15036:      	xorl	%esi, %esi
   15038:      	cmpl	%r15d, %r12d
   1503b:      	seta	%sil
   1503f:      	movl	%r15d, %ecx
   15042:      	cmovbl	%r12d, %ecx
   15046:      	addl	%ecx, %esi
   15048:      	movl	%r12d, %edi
   1504b:      	subl	%esi, %edi
   1504d:      	movl	%edi, 0x50(%rsp)
   15051:      	subq	%rsi, %rax
   15054:      	jb	0x17392 <generic_kprobe_path+0xba72>
   1505a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15060:      	ja	0x17392 <generic_kprobe_path+0xba72>
   15066:      	cmpl	%r15d, %r12d
   15069:      	jbe	0x1506f <generic_kprobe_path+0x974f>
   1506b:      	movb	$0x2f, (%rbx,%rax)
   1506f:      	xorl	%edi, %edi
   15071:      	cmpl	%r15d, %r12d
   15074:      	seta	%dil
   15078:      	movzbl	%cl, %esi
   1507b:      	addq	%rax, %rbx
   1507e:      	addq	%rbx, %rdi
   15081:      	movl	$0x4, %eax
   15086:      	callq	*%rax
   15088:      	movq	%rbx, 0x48(%rsp)
   1508d:      	cmpl	%r15d, %r12d
   15090:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   15096:      	movq	0x8(%rsp), %r12
   1509b:      	movq	%r12, 0x30(%rsp)
   150a0:      	movq	0x38(%rsp), %rdx
   150a5:      	movq	0x40(%rsp), %r15
   150aa:      	jmp	0x150fd <generic_kprobe_path+0x97dd>
   150ac:      	leaq	0x10(%r15), %rdx
   150b0:      	movl	$0x4, %eax
   150b5:      	movq	%rbp, %rdi
   150b8:      	movl	$0x8, %esi
   150bd:      	callq	*%rax
   150bf:      	movq	0x40(%rsp), %rax
   150c4:      	cmpq	(%rsp), %rax
   150c8:      	je	0x1738d <generic_kprobe_path+0xba6d>
   150ce:      	addq	$0x18, %r15
   150d2:      	movl	$0x4, %eax
   150d7:      	leaq	0x30(%rsp), %rdi
   150dc:      	movl	$0x8, %esi
   150e1:      	movq	%r15, %rdx
   150e4:      	callq	*%rax
   150e6:      	movq	(%rsp), %r15
   150ea:      	movq	%r15, 0x40(%rsp)
   150ef:      	leaq	0x20(%r15), %rdx
   150f3:      	movq	%rdx, 0x38(%rsp)
   150f8:      	movq	0x30(%rsp), %r12
   150fd:      	cmpq	0x18(%rsp), %r12
   15102:      	jne	0x1510f <generic_kprobe_path+0x97ef>
   15104:      	cmpq	0x20(%rsp), %rdx
   15109:      	je	0x1738d <generic_kprobe_path+0xba6d>
   1510f:      	movl	$0x4, %eax
   15114:      	leaq	0x10(%rsp), %rdi
   15119:      	movl	$0x8, %esi
   1511e:      	callq	*%rax
   15120:      	cmpq	0x10(%rsp), %r12
   15125:      	je	0x1521d <generic_kprobe_path+0x98fd>
   1512b:      	leaq	0x18(%r12), %rbx
   15130:      	movl	$0x4, %eax
   15135:      	movq	%rbp, %rdi
   15138:      	movl	$0x8, %esi
   1513d:      	movq	%rbx, %rdx
   15140:      	callq	*%rax
   15142:      	cmpq	%r12, (%rsp)
   15146:      	je	0x1521d <generic_kprobe_path+0x98fd>
   1514c:      	movl	$0x4, %eax
   15151:      	leaq	0x8(%rsp), %rdi
   15156:      	movl	$0x8, %esi
   1515b:      	movq	%rbx, %rdx
   1515e:      	callq	*%rax
   15160:      	addq	$0x20, %r12
   15164:      	movl	$0x4, %eax
   15169:      	leaq	0x58(%rsp), %rdi
   1516e:      	movl	$0x10, %ecx
   15173:      	movl	$0x10, %esi
   15178:      	movq	%r12, %rdx
   1517b:      	callq	*%rax
   1517d:      	movq	0x28(%rsp), %rbx
   15182:      	movq	0x48(%rsp), %rax
   15187:      	movl	0x5c(%rsp), %r15d
   1518c:      	subq	%rbx, %rax
   1518f:      	movl	0x50(%rsp), %r12d
   15194:      	movl	%r15d, %edx
   15197:      	subl	%r12d, %edx
   1519a:      	movl	$0x0, %ecx
   1519f:      	cmovbl	%ecx, %edx
   151a2:      	addq	0x60(%rsp), %rdx
   151a7:      	xorl	%esi, %esi
   151a9:      	cmpl	%r15d, %r12d
   151ac:      	seta	%sil
   151b0:      	movl	%r15d, %ecx
   151b3:      	cmovbl	%r12d, %ecx
   151b7:      	addl	%ecx, %esi
   151b9:      	movl	%r12d, %edi
   151bc:      	subl	%esi, %edi
   151be:      	movl	%edi, 0x50(%rsp)
   151c2:      	subq	%rsi, %rax
   151c5:      	jb	0x17392 <generic_kprobe_path+0xba72>
   151cb:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   151d1:      	ja	0x17392 <generic_kprobe_path+0xba72>
   151d7:      	cmpl	%r15d, %r12d
   151da:      	jbe	0x151e0 <generic_kprobe_path+0x98c0>
   151dc:      	movb	$0x2f, (%rbx,%rax)
   151e0:      	xorl	%edi, %edi
   151e2:      	cmpl	%r15d, %r12d
   151e5:      	seta	%dil
   151e9:      	movzbl	%cl, %esi
   151ec:      	addq	%rax, %rbx
   151ef:      	addq	%rbx, %rdi
   151f2:      	movl	$0x4, %eax
   151f7:      	callq	*%rax
   151f9:      	movq	%rbx, 0x48(%rsp)
   151fe:      	cmpl	%r15d, %r12d
   15201:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   15207:      	movq	0x8(%rsp), %r12
   1520c:      	movq	%r12, 0x30(%rsp)
   15211:      	movq	0x38(%rsp), %rdx
   15216:      	movq	0x40(%rsp), %r15
   1521b:      	jmp	0x1526e <generic_kprobe_path+0x994e>
   1521d:      	leaq	0x10(%r15), %rdx
   15221:      	movl	$0x4, %eax
   15226:      	movq	%rbp, %rdi
   15229:      	movl	$0x8, %esi
   1522e:      	callq	*%rax
   15230:      	movq	0x40(%rsp), %rax
   15235:      	cmpq	(%rsp), %rax
   15239:      	je	0x1738d <generic_kprobe_path+0xba6d>
   1523f:      	addq	$0x18, %r15
   15243:      	movl	$0x4, %eax
   15248:      	leaq	0x30(%rsp), %rdi
   1524d:      	movl	$0x8, %esi
   15252:      	movq	%r15, %rdx
   15255:      	callq	*%rax
   15257:      	movq	(%rsp), %r15
   1525b:      	movq	%r15, 0x40(%rsp)
   15260:      	leaq	0x20(%r15), %rdx
   15264:      	movq	%rdx, 0x38(%rsp)
   15269:      	movq	0x30(%rsp), %r12
   1526e:      	cmpq	0x18(%rsp), %r12
   15273:      	jne	0x15280 <generic_kprobe_path+0x9960>
   15275:      	cmpq	0x20(%rsp), %rdx
   1527a:      	je	0x1738d <generic_kprobe_path+0xba6d>
   15280:      	movl	$0x4, %eax
   15285:      	leaq	0x10(%rsp), %rdi
   1528a:      	movl	$0x8, %esi
   1528f:      	callq	*%rax
   15291:      	cmpq	0x10(%rsp), %r12
   15296:      	je	0x1538e <generic_kprobe_path+0x9a6e>
   1529c:      	leaq	0x18(%r12), %rbx
   152a1:      	movl	$0x4, %eax
   152a6:      	movq	%rbp, %rdi
   152a9:      	movl	$0x8, %esi
   152ae:      	movq	%rbx, %rdx
   152b1:      	callq	*%rax
   152b3:      	cmpq	%r12, (%rsp)
   152b7:      	je	0x1538e <generic_kprobe_path+0x9a6e>
   152bd:      	movl	$0x4, %eax
   152c2:      	leaq	0x8(%rsp), %rdi
   152c7:      	movl	$0x8, %esi
   152cc:      	movq	%rbx, %rdx
   152cf:      	callq	*%rax
   152d1:      	addq	$0x20, %r12
   152d5:      	movl	$0x4, %eax
   152da:      	leaq	0x58(%rsp), %rdi
   152df:      	movl	$0x10, %ecx
   152e4:      	movl	$0x10, %esi
   152e9:      	movq	%r12, %rdx
   152ec:      	callq	*%rax
   152ee:      	movq	0x28(%rsp), %rbx
   152f3:      	movq	0x48(%rsp), %rax
   152f8:      	movl	0x5c(%rsp), %r15d
   152fd:      	subq	%rbx, %rax
   15300:      	movl	0x50(%rsp), %r12d
   15305:      	movl	%r15d, %edx
   15308:      	subl	%r12d, %edx
   1530b:      	movl	$0x0, %ecx
   15310:      	cmovbl	%ecx, %edx
   15313:      	addq	0x60(%rsp), %rdx
   15318:      	xorl	%esi, %esi
   1531a:      	cmpl	%r15d, %r12d
   1531d:      	seta	%sil
   15321:      	movl	%r15d, %ecx
   15324:      	cmovbl	%r12d, %ecx
   15328:      	addl	%ecx, %esi
   1532a:      	movl	%r12d, %edi
   1532d:      	subl	%esi, %edi
   1532f:      	movl	%edi, 0x50(%rsp)
   15333:      	subq	%rsi, %rax
   15336:      	jb	0x17392 <generic_kprobe_path+0xba72>
   1533c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15342:      	ja	0x17392 <generic_kprobe_path+0xba72>
   15348:      	cmpl	%r15d, %r12d
   1534b:      	jbe	0x15351 <generic_kprobe_path+0x9a31>
   1534d:      	movb	$0x2f, (%rbx,%rax)
   15351:      	xorl	%edi, %edi
   15353:      	cmpl	%r15d, %r12d
   15356:      	seta	%dil
   1535a:      	movzbl	%cl, %esi
   1535d:      	addq	%rax, %rbx
   15360:      	addq	%rbx, %rdi
   15363:      	movl	$0x4, %eax
   15368:      	callq	*%rax
   1536a:      	movq	%rbx, 0x48(%rsp)
   1536f:      	cmpl	%r15d, %r12d
   15372:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   15378:      	movq	0x8(%rsp), %r12
   1537d:      	movq	%r12, 0x30(%rsp)
   15382:      	movq	0x38(%rsp), %rdx
   15387:      	movq	0x40(%rsp), %r15
   1538c:      	jmp	0x153df <generic_kprobe_path+0x9abf>
   1538e:      	leaq	0x10(%r15), %rdx
   15392:      	movl	$0x4, %eax
   15397:      	movq	%rbp, %rdi
   1539a:      	movl	$0x8, %esi
   1539f:      	callq	*%rax
   153a1:      	movq	0x40(%rsp), %rax
   153a6:      	cmpq	(%rsp), %rax
   153aa:      	je	0x1738d <generic_kprobe_path+0xba6d>
   153b0:      	addq	$0x18, %r15
   153b4:      	movl	$0x4, %eax
   153b9:      	leaq	0x30(%rsp), %rdi
   153be:      	movl	$0x8, %esi
   153c3:      	movq	%r15, %rdx
   153c6:      	callq	*%rax
   153c8:      	movq	(%rsp), %r15
   153cc:      	movq	%r15, 0x40(%rsp)
   153d1:      	leaq	0x20(%r15), %rdx
   153d5:      	movq	%rdx, 0x38(%rsp)
   153da:      	movq	0x30(%rsp), %r12
   153df:      	cmpq	0x18(%rsp), %r12
   153e4:      	jne	0x153f1 <generic_kprobe_path+0x9ad1>
   153e6:      	cmpq	0x20(%rsp), %rdx
   153eb:      	je	0x1738d <generic_kprobe_path+0xba6d>
   153f1:      	movl	$0x4, %eax
   153f6:      	leaq	0x10(%rsp), %rdi
   153fb:      	movl	$0x8, %esi
   15400:      	callq	*%rax
   15402:      	cmpq	0x10(%rsp), %r12
   15407:      	je	0x154ff <generic_kprobe_path+0x9bdf>
   1540d:      	leaq	0x18(%r12), %rbx
   15412:      	movl	$0x4, %eax
   15417:      	movq	%rbp, %rdi
   1541a:      	movl	$0x8, %esi
   1541f:      	movq	%rbx, %rdx
   15422:      	callq	*%rax
   15424:      	cmpq	%r12, (%rsp)
   15428:      	je	0x154ff <generic_kprobe_path+0x9bdf>
   1542e:      	movl	$0x4, %eax
   15433:      	leaq	0x8(%rsp), %rdi
   15438:      	movl	$0x8, %esi
   1543d:      	movq	%rbx, %rdx
   15440:      	callq	*%rax
   15442:      	addq	$0x20, %r12
   15446:      	movl	$0x4, %eax
   1544b:      	leaq	0x58(%rsp), %rdi
   15450:      	movl	$0x10, %ecx
   15455:      	movl	$0x10, %esi
   1545a:      	movq	%r12, %rdx
   1545d:      	callq	*%rax
   1545f:      	movq	0x28(%rsp), %rbx
   15464:      	movq	0x48(%rsp), %rax
   15469:      	movl	0x5c(%rsp), %r15d
   1546e:      	subq	%rbx, %rax
   15471:      	movl	0x50(%rsp), %r12d
   15476:      	movl	%r15d, %edx
   15479:      	subl	%r12d, %edx
   1547c:      	movl	$0x0, %ecx
   15481:      	cmovbl	%ecx, %edx
   15484:      	addq	0x60(%rsp), %rdx
   15489:      	xorl	%esi, %esi
   1548b:      	cmpl	%r15d, %r12d
   1548e:      	seta	%sil
   15492:      	movl	%r15d, %ecx
   15495:      	cmovbl	%r12d, %ecx
   15499:      	addl	%ecx, %esi
   1549b:      	movl	%r12d, %edi
   1549e:      	subl	%esi, %edi
   154a0:      	movl	%edi, 0x50(%rsp)
   154a4:      	subq	%rsi, %rax
   154a7:      	jb	0x17392 <generic_kprobe_path+0xba72>
   154ad:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   154b3:      	ja	0x17392 <generic_kprobe_path+0xba72>
   154b9:      	cmpl	%r15d, %r12d
   154bc:      	jbe	0x154c2 <generic_kprobe_path+0x9ba2>
   154be:      	movb	$0x2f, (%rbx,%rax)
   154c2:      	xorl	%edi, %edi
   154c4:      	cmpl	%r15d, %r12d
   154c7:      	seta	%dil
   154cb:      	movzbl	%cl, %esi
   154ce:      	addq	%rax, %rbx
   154d1:      	addq	%rbx, %rdi
   154d4:      	movl	$0x4, %eax
   154d9:      	callq	*%rax
   154db:      	movq	%rbx, 0x48(%rsp)
   154e0:      	cmpl	%r15d, %r12d
   154e3:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   154e9:      	movq	0x8(%rsp), %r12
   154ee:      	movq	%r12, 0x30(%rsp)
   154f3:      	movq	0x38(%rsp), %rdx
   154f8:      	movq	0x40(%rsp), %r15
   154fd:      	jmp	0x15550 <generic_kprobe_path+0x9c30>
   154ff:      	leaq	0x10(%r15), %rdx
   15503:      	movl	$0x4, %eax
   15508:      	movq	%rbp, %rdi
   1550b:      	movl	$0x8, %esi
   15510:      	callq	*%rax
   15512:      	movq	0x40(%rsp), %rax
   15517:      	cmpq	(%rsp), %rax
   1551b:      	je	0x1738d <generic_kprobe_path+0xba6d>
   15521:      	addq	$0x18, %r15
   15525:      	movl	$0x4, %eax
   1552a:      	leaq	0x30(%rsp), %rdi
   1552f:      	movl	$0x8, %esi
   15534:      	movq	%r15, %rdx
   15537:      	callq	*%rax
   15539:      	movq	(%rsp), %r15
   1553d:      	movq	%r15, 0x40(%rsp)
   15542:      	leaq	0x20(%r15), %rdx
   15546:      	movq	%rdx, 0x38(%rsp)
   1554b:      	movq	0x30(%rsp), %r12
   15550:      	cmpq	0x18(%rsp), %r12
   15555:      	jne	0x15562 <generic_kprobe_path+0x9c42>
   15557:      	cmpq	0x20(%rsp), %rdx
   1555c:      	je	0x1738d <generic_kprobe_path+0xba6d>
   15562:      	movl	$0x4, %eax
   15567:      	leaq	0x10(%rsp), %rdi
   1556c:      	movl	$0x8, %esi
   15571:      	callq	*%rax
   15573:      	cmpq	0x10(%rsp), %r12
   15578:      	je	0x15670 <generic_kprobe_path+0x9d50>
   1557e:      	leaq	0x18(%r12), %rbx
   15583:      	movl	$0x4, %eax
   15588:      	movq	%rbp, %rdi
   1558b:      	movl	$0x8, %esi
   15590:      	movq	%rbx, %rdx
   15593:      	callq	*%rax
   15595:      	cmpq	%r12, (%rsp)
   15599:      	je	0x15670 <generic_kprobe_path+0x9d50>
   1559f:      	movl	$0x4, %eax
   155a4:      	leaq	0x8(%rsp), %rdi
   155a9:      	movl	$0x8, %esi
   155ae:      	movq	%rbx, %rdx
   155b1:      	callq	*%rax
   155b3:      	addq	$0x20, %r12
   155b7:      	movl	$0x4, %eax
   155bc:      	leaq	0x58(%rsp), %rdi
   155c1:      	movl	$0x10, %ecx
   155c6:      	movl	$0x10, %esi
   155cb:      	movq	%r12, %rdx
   155ce:      	callq	*%rax
   155d0:      	movq	0x28(%rsp), %rbx
   155d5:      	movq	0x48(%rsp), %rax
   155da:      	movl	0x5c(%rsp), %r15d
   155df:      	subq	%rbx, %rax
   155e2:      	movl	0x50(%rsp), %r12d
   155e7:      	movl	%r15d, %edx
   155ea:      	subl	%r12d, %edx
   155ed:      	movl	$0x0, %ecx
   155f2:      	cmovbl	%ecx, %edx
   155f5:      	addq	0x60(%rsp), %rdx
   155fa:      	xorl	%esi, %esi
   155fc:      	cmpl	%r15d, %r12d
   155ff:      	seta	%sil
   15603:      	movl	%r15d, %ecx
   15606:      	cmovbl	%r12d, %ecx
   1560a:      	addl	%ecx, %esi
   1560c:      	movl	%r12d, %edi
   1560f:      	subl	%esi, %edi
   15611:      	movl	%edi, 0x50(%rsp)
   15615:      	subq	%rsi, %rax
   15618:      	jb	0x17392 <generic_kprobe_path+0xba72>
   1561e:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15624:      	ja	0x17392 <generic_kprobe_path+0xba72>
   1562a:      	cmpl	%r15d, %r12d
   1562d:      	jbe	0x15633 <generic_kprobe_path+0x9d13>
   1562f:      	movb	$0x2f, (%rbx,%rax)
   15633:      	xorl	%edi, %edi
   15635:      	cmpl	%r15d, %r12d
   15638:      	seta	%dil
   1563c:      	movzbl	%cl, %esi
   1563f:      	addq	%rax, %rbx
   15642:      	addq	%rbx, %rdi
   15645:      	movl	$0x4, %eax
   1564a:      	callq	*%rax
   1564c:      	movq	%rbx, 0x48(%rsp)
   15651:      	cmpl	%r15d, %r12d
   15654:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   1565a:      	movq	0x8(%rsp), %r12
   1565f:      	movq	%r12, 0x30(%rsp)
   15664:      	movq	0x38(%rsp), %rdx
   15669:      	movq	0x40(%rsp), %r15
   1566e:      	jmp	0x156c1 <generic_kprobe_path+0x9da1>
   15670:      	leaq	0x10(%r15), %rdx
   15674:      	movl	$0x4, %eax
   15679:      	movq	%rbp, %rdi
   1567c:      	movl	$0x8, %esi
   15681:      	callq	*%rax
   15683:      	movq	0x40(%rsp), %rax
   15688:      	cmpq	(%rsp), %rax
   1568c:      	je	0x1738d <generic_kprobe_path+0xba6d>
   15692:      	addq	$0x18, %r15
   15696:      	movl	$0x4, %eax
   1569b:      	leaq	0x30(%rsp), %rdi
   156a0:      	movl	$0x8, %esi
   156a5:      	movq	%r15, %rdx
   156a8:      	callq	*%rax
   156aa:      	movq	(%rsp), %r15
   156ae:      	movq	%r15, 0x40(%rsp)
   156b3:      	leaq	0x20(%r15), %rdx
   156b7:      	movq	%rdx, 0x38(%rsp)
   156bc:      	movq	0x30(%rsp), %r12
   156c1:      	cmpq	0x18(%rsp), %r12
   156c6:      	jne	0x156d3 <generic_kprobe_path+0x9db3>
   156c8:      	cmpq	0x20(%rsp), %rdx
   156cd:      	je	0x1738d <generic_kprobe_path+0xba6d>
   156d3:      	movl	$0x4, %eax
   156d8:      	leaq	0x10(%rsp), %rdi
   156dd:      	movl	$0x8, %esi
   156e2:      	callq	*%rax
   156e4:      	cmpq	0x10(%rsp), %r12
   156e9:      	je	0x157e1 <generic_kprobe_path+0x9ec1>
   156ef:      	leaq	0x18(%r12), %rbx
   156f4:      	movl	$0x4, %eax
   156f9:      	movq	%rbp, %rdi
   156fc:      	movl	$0x8, %esi
   15701:      	movq	%rbx, %rdx
   15704:      	callq	*%rax
   15706:      	cmpq	%r12, (%rsp)
   1570a:      	je	0x157e1 <generic_kprobe_path+0x9ec1>
   15710:      	movl	$0x4, %eax
   15715:      	leaq	0x8(%rsp), %rdi
   1571a:      	movl	$0x8, %esi
   1571f:      	movq	%rbx, %rdx
   15722:      	callq	*%rax
   15724:      	addq	$0x20, %r12
   15728:      	movl	$0x4, %eax
   1572d:      	leaq	0x58(%rsp), %rdi
   15732:      	movl	$0x10, %ecx
   15737:      	movl	$0x10, %esi
   1573c:      	movq	%r12, %rdx
   1573f:      	callq	*%rax
   15741:      	movq	0x28(%rsp), %rbx
   15746:      	movq	0x48(%rsp), %rax
   1574b:      	movl	0x5c(%rsp), %r15d
   15750:      	subq	%rbx, %rax
   15753:      	movl	0x50(%rsp), %r12d
   15758:      	movl	%r15d, %edx
   1575b:      	subl	%r12d, %edx
   1575e:      	movl	$0x0, %ecx
   15763:      	cmovbl	%ecx, %edx
   15766:      	addq	0x60(%rsp), %rdx
   1576b:      	xorl	%esi, %esi
   1576d:      	cmpl	%r15d, %r12d
   15770:      	seta	%sil
   15774:      	movl	%r15d, %ecx
   15777:      	cmovbl	%r12d, %ecx
   1577b:      	addl	%ecx, %esi
   1577d:      	movl	%r12d, %edi
   15780:      	subl	%esi, %edi
   15782:      	movl	%edi, 0x50(%rsp)
   15786:      	subq	%rsi, %rax
   15789:      	jb	0x17392 <generic_kprobe_path+0xba72>
   1578f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15795:      	ja	0x17392 <generic_kprobe_path+0xba72>
   1579b:      	cmpl	%r15d, %r12d
   1579e:      	jbe	0x157a4 <generic_kprobe_path+0x9e84>
   157a0:      	movb	$0x2f, (%rbx,%rax)
   157a4:      	xorl	%edi, %edi
   157a6:      	cmpl	%r15d, %r12d
   157a9:      	seta	%dil
   157ad:      	movzbl	%cl, %esi
   157b0:      	addq	%rax, %rbx
   157b3:      	addq	%rbx, %rdi
   157b6:      	movl	$0x4, %eax
   157bb:      	callq	*%rax
   157bd:      	movq	%rbx, 0x48(%rsp)
   157c2:      	cmpl	%r15d, %r12d
   157c5:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   157cb:      	movq	0x8(%rsp), %r12
   157d0:      	movq	%r12, 0x30(%rsp)
   157d5:      	movq	0x38(%rsp), %rdx
   157da:      	movq	0x40(%rsp), %r15
   157df:      	jmp	0x15832 <generic_kprobe_path+0x9f12>
   157e1:      	leaq	0x10(%r15), %rdx
   157e5:      	movl	$0x4, %eax
   157ea:      	movq	%rbp, %rdi
   157ed:      	movl	$0x8, %esi
   157f2:      	callq	*%rax
   157f4:      	movq	0x40(%rsp), %rax
   157f9:      	cmpq	(%rsp), %rax
   157fd:      	je	0x1738d <generic_kprobe_path+0xba6d>
   15803:      	addq	$0x18, %r15
   15807:      	movl	$0x4, %eax
   1580c:      	leaq	0x30(%rsp), %rdi
   15811:      	movl	$0x8, %esi
   15816:      	movq	%r15, %rdx
   15819:      	callq	*%rax
   1581b:      	movq	(%rsp), %r15
   1581f:      	movq	%r15, 0x40(%rsp)
   15824:      	leaq	0x20(%r15), %rdx
   15828:      	movq	%rdx, 0x38(%rsp)
   1582d:      	movq	0x30(%rsp), %r12
   15832:      	cmpq	0x18(%rsp), %r12
   15837:      	jne	0x15844 <generic_kprobe_path+0x9f24>
   15839:      	cmpq	0x20(%rsp), %rdx
   1583e:      	je	0x1738d <generic_kprobe_path+0xba6d>
   15844:      	movl	$0x4, %eax
   15849:      	leaq	0x10(%rsp), %rdi
   1584e:      	movl	$0x8, %esi
   15853:      	callq	*%rax
   15855:      	cmpq	0x10(%rsp), %r12
   1585a:      	je	0x15952 <generic_kprobe_path+0xa032>
   15860:      	leaq	0x18(%r12), %rbx
   15865:      	movl	$0x4, %eax
   1586a:      	movq	%rbp, %rdi
   1586d:      	movl	$0x8, %esi
   15872:      	movq	%rbx, %rdx
   15875:      	callq	*%rax
   15877:      	cmpq	%r12, (%rsp)
   1587b:      	je	0x15952 <generic_kprobe_path+0xa032>
   15881:      	movl	$0x4, %eax
   15886:      	leaq	0x8(%rsp), %rdi
   1588b:      	movl	$0x8, %esi
   15890:      	movq	%rbx, %rdx
   15893:      	callq	*%rax
   15895:      	addq	$0x20, %r12
   15899:      	movl	$0x4, %eax
   1589e:      	leaq	0x58(%rsp), %rdi
   158a3:      	movl	$0x10, %ecx
   158a8:      	movl	$0x10, %esi
   158ad:      	movq	%r12, %rdx
   158b0:      	callq	*%rax
   158b2:      	movq	0x28(%rsp), %rbx
   158b7:      	movq	0x48(%rsp), %rax
   158bc:      	movl	0x5c(%rsp), %r15d
   158c1:      	subq	%rbx, %rax
   158c4:      	movl	0x50(%rsp), %r12d
   158c9:      	movl	%r15d, %edx
   158cc:      	subl	%r12d, %edx
   158cf:      	movl	$0x0, %ecx
   158d4:      	cmovbl	%ecx, %edx
   158d7:      	addq	0x60(%rsp), %rdx
   158dc:      	xorl	%esi, %esi
   158de:      	cmpl	%r15d, %r12d
   158e1:      	seta	%sil
   158e5:      	movl	%r15d, %ecx
   158e8:      	cmovbl	%r12d, %ecx
   158ec:      	addl	%ecx, %esi
   158ee:      	movl	%r12d, %edi
   158f1:      	subl	%esi, %edi
   158f3:      	movl	%edi, 0x50(%rsp)
   158f7:      	subq	%rsi, %rax
   158fa:      	jb	0x17392 <generic_kprobe_path+0xba72>
   15900:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15906:      	ja	0x17392 <generic_kprobe_path+0xba72>
   1590c:      	cmpl	%r15d, %r12d
   1590f:      	jbe	0x15915 <generic_kprobe_path+0x9ff5>
   15911:      	movb	$0x2f, (%rbx,%rax)
   15915:      	xorl	%edi, %edi
   15917:      	cmpl	%r15d, %r12d
   1591a:      	seta	%dil
   1591e:      	movzbl	%cl, %esi
   15921:      	addq	%rax, %rbx
   15924:      	addq	%rbx, %rdi
   15927:      	movl	$0x4, %eax
   1592c:      	callq	*%rax
   1592e:      	movq	%rbx, 0x48(%rsp)
   15933:      	cmpl	%r15d, %r12d
   15936:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   1593c:      	movq	0x8(%rsp), %r12
   15941:      	movq	%r12, 0x30(%rsp)
   15946:      	movq	0x38(%rsp), %rdx
   1594b:      	movq	0x40(%rsp), %r15
   15950:      	jmp	0x159a3 <generic_kprobe_path+0xa083>
   15952:      	leaq	0x10(%r15), %rdx
   15956:      	movl	$0x4, %eax
   1595b:      	movq	%rbp, %rdi
   1595e:      	movl	$0x8, %esi
   15963:      	callq	*%rax
   15965:      	movq	0x40(%rsp), %rax
   1596a:      	cmpq	(%rsp), %rax
   1596e:      	je	0x1738d <generic_kprobe_path+0xba6d>
   15974:      	addq	$0x18, %r15
   15978:      	movl	$0x4, %eax
   1597d:      	leaq	0x30(%rsp), %rdi
   15982:      	movl	$0x8, %esi
   15987:      	movq	%r15, %rdx
   1598a:      	callq	*%rax
   1598c:      	movq	(%rsp), %r15
   15990:      	movq	%r15, 0x40(%rsp)
   15995:      	leaq	0x20(%r15), %rdx
   15999:      	movq	%rdx, 0x38(%rsp)
   1599e:      	movq	0x30(%rsp), %r12
   159a3:      	cmpq	0x18(%rsp), %r12
   159a8:      	jne	0x159b5 <generic_kprobe_path+0xa095>
   159aa:      	cmpq	0x20(%rsp), %rdx
   159af:      	je	0x1738d <generic_kprobe_path+0xba6d>
   159b5:      	movl	$0x4, %eax
   159ba:      	leaq	0x10(%rsp), %rdi
   159bf:      	movl	$0x8, %esi
   159c4:      	callq	*%rax
   159c6:      	cmpq	0x10(%rsp), %r12
   159cb:      	je	0x15ac3 <generic_kprobe_path+0xa1a3>
   159d1:      	leaq	0x18(%r12), %rbx
   159d6:      	movl	$0x4, %eax
   159db:      	movq	%rbp, %rdi
   159de:      	movl	$0x8, %esi
   159e3:      	movq	%rbx, %rdx
   159e6:      	callq	*%rax
   159e8:      	cmpq	%r12, (%rsp)
   159ec:      	je	0x15ac3 <generic_kprobe_path+0xa1a3>
   159f2:      	movl	$0x4, %eax
   159f7:      	leaq	0x8(%rsp), %rdi
   159fc:      	movl	$0x8, %esi
   15a01:      	movq	%rbx, %rdx
   15a04:      	callq	*%rax
   15a06:      	addq	$0x20, %r12
   15a0a:      	movl	$0x4, %eax
   15a0f:      	leaq	0x58(%rsp), %rdi
   15a14:      	movl	$0x10, %ecx
   15a19:      	movl	$0x10, %esi
   15a1e:      	movq	%r12, %rdx
   15a21:      	callq	*%rax
   15a23:      	movq	0x28(%rsp), %rbx
   15a28:      	movq	0x48(%rsp), %rax
   15a2d:      	movl	0x5c(%rsp), %r15d
   15a32:      	subq	%rbx, %rax
   15a35:      	movl	0x50(%rsp), %r12d
   15a3a:      	movl	%r15d, %edx
   15a3d:      	subl	%r12d, %edx
   15a40:      	movl	$0x0, %ecx
   15a45:      	cmovbl	%ecx, %edx
   15a48:      	addq	0x60(%rsp), %rdx
   15a4d:      	xorl	%esi, %esi
   15a4f:      	cmpl	%r15d, %r12d
   15a52:      	seta	%sil
   15a56:      	movl	%r15d, %ecx
   15a59:      	cmovbl	%r12d, %ecx
   15a5d:      	addl	%ecx, %esi
   15a5f:      	movl	%r12d, %edi
   15a62:      	subl	%esi, %edi
   15a64:      	movl	%edi, 0x50(%rsp)
   15a68:      	subq	%rsi, %rax
   15a6b:      	jb	0x17392 <generic_kprobe_path+0xba72>
   15a71:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15a77:      	ja	0x17392 <generic_kprobe_path+0xba72>
   15a7d:      	cmpl	%r15d, %r12d
   15a80:      	jbe	0x15a86 <generic_kprobe_path+0xa166>
   15a82:      	movb	$0x2f, (%rbx,%rax)
   15a86:      	xorl	%edi, %edi
   15a88:      	cmpl	%r15d, %r12d
   15a8b:      	seta	%dil
   15a8f:      	movzbl	%cl, %esi
   15a92:      	addq	%rax, %rbx
   15a95:      	addq	%rbx, %rdi
   15a98:      	movl	$0x4, %eax
   15a9d:      	callq	*%rax
   15a9f:      	movq	%rbx, 0x48(%rsp)
   15aa4:      	cmpl	%r15d, %r12d
   15aa7:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   15aad:      	movq	0x8(%rsp), %r12
   15ab2:      	movq	%r12, 0x30(%rsp)
   15ab7:      	movq	0x38(%rsp), %rdx
   15abc:      	movq	0x40(%rsp), %r15
   15ac1:      	jmp	0x15b14 <generic_kprobe_path+0xa1f4>
   15ac3:      	leaq	0x10(%r15), %rdx
   15ac7:      	movl	$0x4, %eax
   15acc:      	movq	%rbp, %rdi
   15acf:      	movl	$0x8, %esi
   15ad4:      	callq	*%rax
   15ad6:      	movq	0x40(%rsp), %rax
   15adb:      	cmpq	(%rsp), %rax
   15adf:      	je	0x1738d <generic_kprobe_path+0xba6d>
   15ae5:      	addq	$0x18, %r15
   15ae9:      	movl	$0x4, %eax
   15aee:      	leaq	0x30(%rsp), %rdi
   15af3:      	movl	$0x8, %esi
   15af8:      	movq	%r15, %rdx
   15afb:      	callq	*%rax
   15afd:      	movq	(%rsp), %r15
   15b01:      	movq	%r15, 0x40(%rsp)
   15b06:      	leaq	0x20(%r15), %rdx
   15b0a:      	movq	%rdx, 0x38(%rsp)
   15b0f:      	movq	0x30(%rsp), %r12
   15b14:      	cmpq	0x18(%rsp), %r12
   15b19:      	jne	0x15b26 <generic_kprobe_path+0xa206>
   15b1b:      	cmpq	0x20(%rsp), %rdx
   15b20:      	je	0x1738d <generic_kprobe_path+0xba6d>
   15b26:      	movl	$0x4, %eax
   15b2b:      	leaq	0x10(%rsp), %rdi
   15b30:      	movl	$0x8, %esi
   15b35:      	callq	*%rax
   15b37:      	cmpq	0x10(%rsp), %r12
   15b3c:      	je	0x15c34 <generic_kprobe_path+0xa314>
   15b42:      	leaq	0x18(%r12), %rbx
   15b47:      	movl	$0x4, %eax
   15b4c:      	movq	%rbp, %rdi
   15b4f:      	movl	$0x8, %esi
   15b54:      	movq	%rbx, %rdx
   15b57:      	callq	*%rax
   15b59:      	cmpq	%r12, (%rsp)
   15b5d:      	je	0x15c34 <generic_kprobe_path+0xa314>
   15b63:      	movl	$0x4, %eax
   15b68:      	leaq	0x8(%rsp), %rdi
   15b6d:      	movl	$0x8, %esi
   15b72:      	movq	%rbx, %rdx
   15b75:      	callq	*%rax
   15b77:      	addq	$0x20, %r12
   15b7b:      	movl	$0x4, %eax
   15b80:      	leaq	0x58(%rsp), %rdi
   15b85:      	movl	$0x10, %ecx
   15b8a:      	movl	$0x10, %esi
   15b8f:      	movq	%r12, %rdx
   15b92:      	callq	*%rax
   15b94:      	movq	0x28(%rsp), %rbx
   15b99:      	movq	0x48(%rsp), %rax
   15b9e:      	movl	0x5c(%rsp), %r15d
   15ba3:      	subq	%rbx, %rax
   15ba6:      	movl	0x50(%rsp), %r12d
   15bab:      	movl	%r15d, %edx
   15bae:      	subl	%r12d, %edx
   15bb1:      	movl	$0x0, %ecx
   15bb6:      	cmovbl	%ecx, %edx
   15bb9:      	addq	0x60(%rsp), %rdx
   15bbe:      	xorl	%esi, %esi
   15bc0:      	cmpl	%r15d, %r12d
   15bc3:      	seta	%sil
   15bc7:      	movl	%r15d, %ecx
   15bca:      	cmovbl	%r12d, %ecx
   15bce:      	addl	%ecx, %esi
   15bd0:      	movl	%r12d, %edi
   15bd3:      	subl	%esi, %edi
   15bd5:      	movl	%edi, 0x50(%rsp)
   15bd9:      	subq	%rsi, %rax
   15bdc:      	jb	0x17392 <generic_kprobe_path+0xba72>
   15be2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15be8:      	ja	0x17392 <generic_kprobe_path+0xba72>
   15bee:      	cmpl	%r15d, %r12d
   15bf1:      	jbe	0x15bf7 <generic_kprobe_path+0xa2d7>
   15bf3:      	movb	$0x2f, (%rbx,%rax)
   15bf7:      	xorl	%edi, %edi
   15bf9:      	cmpl	%r15d, %r12d
   15bfc:      	seta	%dil
   15c00:      	movzbl	%cl, %esi
   15c03:      	addq	%rax, %rbx
   15c06:      	addq	%rbx, %rdi
   15c09:      	movl	$0x4, %eax
   15c0e:      	callq	*%rax
   15c10:      	movq	%rbx, 0x48(%rsp)
   15c15:      	cmpl	%r15d, %r12d
   15c18:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   15c1e:      	movq	0x8(%rsp), %r12
   15c23:      	movq	%r12, 0x30(%rsp)
   15c28:      	movq	0x38(%rsp), %rdx
   15c2d:      	movq	0x40(%rsp), %r15
   15c32:      	jmp	0x15c85 <generic_kprobe_path+0xa365>
   15c34:      	leaq	0x10(%r15), %rdx
   15c38:      	movl	$0x4, %eax
   15c3d:      	movq	%rbp, %rdi
   15c40:      	movl	$0x8, %esi
   15c45:      	callq	*%rax
   15c47:      	movq	0x40(%rsp), %rax
   15c4c:      	cmpq	(%rsp), %rax
   15c50:      	je	0x1738d <generic_kprobe_path+0xba6d>
   15c56:      	addq	$0x18, %r15
   15c5a:      	movl	$0x4, %eax
   15c5f:      	leaq	0x30(%rsp), %rdi
   15c64:      	movl	$0x8, %esi
   15c69:      	movq	%r15, %rdx
   15c6c:      	callq	*%rax
   15c6e:      	movq	(%rsp), %r15
   15c72:      	movq	%r15, 0x40(%rsp)
   15c77:      	leaq	0x20(%r15), %rdx
   15c7b:      	movq	%rdx, 0x38(%rsp)
   15c80:      	movq	0x30(%rsp), %r12
   15c85:      	cmpq	0x18(%rsp), %r12
   15c8a:      	jne	0x15c97 <generic_kprobe_path+0xa377>
   15c8c:      	cmpq	0x20(%rsp), %rdx
   15c91:      	je	0x1738d <generic_kprobe_path+0xba6d>
   15c97:      	movl	$0x4, %eax
   15c9c:      	leaq	0x10(%rsp), %rdi
   15ca1:      	movl	$0x8, %esi
   15ca6:      	callq	*%rax
   15ca8:      	cmpq	0x10(%rsp), %r12
   15cad:      	je	0x15da5 <generic_kprobe_path+0xa485>
   15cb3:      	leaq	0x18(%r12), %rbx
   15cb8:      	movl	$0x4, %eax
   15cbd:      	movq	%rbp, %rdi
   15cc0:      	movl	$0x8, %esi
   15cc5:      	movq	%rbx, %rdx
   15cc8:      	callq	*%rax
   15cca:      	cmpq	%r12, (%rsp)
   15cce:      	je	0x15da5 <generic_kprobe_path+0xa485>
   15cd4:      	movl	$0x4, %eax
   15cd9:      	leaq	0x8(%rsp), %rdi
   15cde:      	movl	$0x8, %esi
   15ce3:      	movq	%rbx, %rdx
   15ce6:      	callq	*%rax
   15ce8:      	addq	$0x20, %r12
   15cec:      	movl	$0x4, %eax
   15cf1:      	leaq	0x58(%rsp), %rdi
   15cf6:      	movl	$0x10, %ecx
   15cfb:      	movl	$0x10, %esi
   15d00:      	movq	%r12, %rdx
   15d03:      	callq	*%rax
   15d05:      	movq	0x28(%rsp), %rbx
   15d0a:      	movq	0x48(%rsp), %rax
   15d0f:      	movl	0x5c(%rsp), %r15d
   15d14:      	subq	%rbx, %rax
   15d17:      	movl	0x50(%rsp), %r12d
   15d1c:      	movl	%r15d, %edx
   15d1f:      	subl	%r12d, %edx
   15d22:      	movl	$0x0, %ecx
   15d27:      	cmovbl	%ecx, %edx
   15d2a:      	addq	0x60(%rsp), %rdx
   15d2f:      	xorl	%esi, %esi
   15d31:      	cmpl	%r15d, %r12d
   15d34:      	seta	%sil
   15d38:      	movl	%r15d, %ecx
   15d3b:      	cmovbl	%r12d, %ecx
   15d3f:      	addl	%ecx, %esi
   15d41:      	movl	%r12d, %edi
   15d44:      	subl	%esi, %edi
   15d46:      	movl	%edi, 0x50(%rsp)
   15d4a:      	subq	%rsi, %rax
   15d4d:      	jb	0x17392 <generic_kprobe_path+0xba72>
   15d53:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15d59:      	ja	0x17392 <generic_kprobe_path+0xba72>
   15d5f:      	cmpl	%r15d, %r12d
   15d62:      	jbe	0x15d68 <generic_kprobe_path+0xa448>
   15d64:      	movb	$0x2f, (%rbx,%rax)
   15d68:      	xorl	%edi, %edi
   15d6a:      	cmpl	%r15d, %r12d
   15d6d:      	seta	%dil
   15d71:      	movzbl	%cl, %esi
   15d74:      	addq	%rax, %rbx
   15d77:      	addq	%rbx, %rdi
   15d7a:      	movl	$0x4, %eax
   15d7f:      	callq	*%rax
   15d81:      	movq	%rbx, 0x48(%rsp)
   15d86:      	cmpl	%r15d, %r12d
   15d89:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   15d8f:      	movq	0x8(%rsp), %r12
   15d94:      	movq	%r12, 0x30(%rsp)
   15d99:      	movq	0x38(%rsp), %rdx
   15d9e:      	movq	0x40(%rsp), %r15
   15da3:      	jmp	0x15df6 <generic_kprobe_path+0xa4d6>
   15da5:      	leaq	0x10(%r15), %rdx
   15da9:      	movl	$0x4, %eax
   15dae:      	movq	%rbp, %rdi
   15db1:      	movl	$0x8, %esi
   15db6:      	callq	*%rax
   15db8:      	movq	0x40(%rsp), %rax
   15dbd:      	cmpq	(%rsp), %rax
   15dc1:      	je	0x1738d <generic_kprobe_path+0xba6d>
   15dc7:      	addq	$0x18, %r15
   15dcb:      	movl	$0x4, %eax
   15dd0:      	leaq	0x30(%rsp), %rdi
   15dd5:      	movl	$0x8, %esi
   15dda:      	movq	%r15, %rdx
   15ddd:      	callq	*%rax
   15ddf:      	movq	(%rsp), %r15
   15de3:      	movq	%r15, 0x40(%rsp)
   15de8:      	leaq	0x20(%r15), %rdx
   15dec:      	movq	%rdx, 0x38(%rsp)
   15df1:      	movq	0x30(%rsp), %r12
   15df6:      	cmpq	0x18(%rsp), %r12
   15dfb:      	jne	0x15e08 <generic_kprobe_path+0xa4e8>
   15dfd:      	cmpq	0x20(%rsp), %rdx
   15e02:      	je	0x1738d <generic_kprobe_path+0xba6d>
   15e08:      	movl	$0x4, %eax
   15e0d:      	leaq	0x10(%rsp), %rdi
   15e12:      	movl	$0x8, %esi
   15e17:      	callq	*%rax
   15e19:      	cmpq	0x10(%rsp), %r12
   15e1e:      	je	0x15f16 <generic_kprobe_path+0xa5f6>
   15e24:      	leaq	0x18(%r12), %rbx
   15e29:      	movl	$0x4, %eax
   15e2e:      	movq	%rbp, %rdi
   15e31:      	movl	$0x8, %esi
   15e36:      	movq	%rbx, %rdx
   15e39:      	callq	*%rax
   15e3b:      	cmpq	%r12, (%rsp)
   15e3f:      	je	0x15f16 <generic_kprobe_path+0xa5f6>
   15e45:      	movl	$0x4, %eax
   15e4a:      	leaq	0x8(%rsp), %rdi
   15e4f:      	movl	$0x8, %esi
   15e54:      	movq	%rbx, %rdx
   15e57:      	callq	*%rax
   15e59:      	addq	$0x20, %r12
   15e5d:      	movl	$0x4, %eax
   15e62:      	leaq	0x58(%rsp), %rdi
   15e67:      	movl	$0x10, %ecx
   15e6c:      	movl	$0x10, %esi
   15e71:      	movq	%r12, %rdx
   15e74:      	callq	*%rax
   15e76:      	movq	0x28(%rsp), %rbx
   15e7b:      	movq	0x48(%rsp), %rax
   15e80:      	movl	0x5c(%rsp), %r15d
   15e85:      	subq	%rbx, %rax
   15e88:      	movl	0x50(%rsp), %r12d
   15e8d:      	movl	%r15d, %edx
   15e90:      	subl	%r12d, %edx
   15e93:      	movl	$0x0, %ecx
   15e98:      	cmovbl	%ecx, %edx
   15e9b:      	addq	0x60(%rsp), %rdx
   15ea0:      	xorl	%esi, %esi
   15ea2:      	cmpl	%r15d, %r12d
   15ea5:      	seta	%sil
   15ea9:      	movl	%r15d, %ecx
   15eac:      	cmovbl	%r12d, %ecx
   15eb0:      	addl	%ecx, %esi
   15eb2:      	movl	%r12d, %edi
   15eb5:      	subl	%esi, %edi
   15eb7:      	movl	%edi, 0x50(%rsp)
   15ebb:      	subq	%rsi, %rax
   15ebe:      	jb	0x17392 <generic_kprobe_path+0xba72>
   15ec4:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15eca:      	ja	0x17392 <generic_kprobe_path+0xba72>
   15ed0:      	cmpl	%r15d, %r12d
   15ed3:      	jbe	0x15ed9 <generic_kprobe_path+0xa5b9>
   15ed5:      	movb	$0x2f, (%rbx,%rax)
   15ed9:      	xorl	%edi, %edi
   15edb:      	cmpl	%r15d, %r12d
   15ede:      	seta	%dil
   15ee2:      	movzbl	%cl, %esi
   15ee5:      	addq	%rax, %rbx
   15ee8:      	addq	%rbx, %rdi
   15eeb:      	movl	$0x4, %eax
   15ef0:      	callq	*%rax
   15ef2:      	movq	%rbx, 0x48(%rsp)
   15ef7:      	cmpl	%r15d, %r12d
   15efa:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   15f00:      	movq	0x8(%rsp), %r12
   15f05:      	movq	%r12, 0x30(%rsp)
   15f0a:      	movq	0x38(%rsp), %rdx
   15f0f:      	movq	0x40(%rsp), %r15
   15f14:      	jmp	0x15f67 <generic_kprobe_path+0xa647>
   15f16:      	leaq	0x10(%r15), %rdx
   15f1a:      	movl	$0x4, %eax
   15f1f:      	movq	%rbp, %rdi
   15f22:      	movl	$0x8, %esi
   15f27:      	callq	*%rax
   15f29:      	movq	0x40(%rsp), %rax
   15f2e:      	cmpq	(%rsp), %rax
   15f32:      	je	0x1738d <generic_kprobe_path+0xba6d>
   15f38:      	addq	$0x18, %r15
   15f3c:      	movl	$0x4, %eax
   15f41:      	leaq	0x30(%rsp), %rdi
   15f46:      	movl	$0x8, %esi
   15f4b:      	movq	%r15, %rdx
   15f4e:      	callq	*%rax
   15f50:      	movq	(%rsp), %r15
   15f54:      	movq	%r15, 0x40(%rsp)
   15f59:      	leaq	0x20(%r15), %rdx
   15f5d:      	movq	%rdx, 0x38(%rsp)
   15f62:      	movq	0x30(%rsp), %r12
   15f67:      	cmpq	0x18(%rsp), %r12
   15f6c:      	jne	0x15f79 <generic_kprobe_path+0xa659>
   15f6e:      	cmpq	0x20(%rsp), %rdx
   15f73:      	je	0x1738d <generic_kprobe_path+0xba6d>
   15f79:      	movl	$0x4, %eax
   15f7e:      	leaq	0x10(%rsp), %rdi
   15f83:      	movl	$0x8, %esi
   15f88:      	callq	*%rax
   15f8a:      	cmpq	0x10(%rsp), %r12
   15f8f:      	je	0x16087 <generic_kprobe_path+0xa767>
   15f95:      	leaq	0x18(%r12), %rbx
   15f9a:      	movl	$0x4, %eax
   15f9f:      	movq	%rbp, %rdi
   15fa2:      	movl	$0x8, %esi
   15fa7:      	movq	%rbx, %rdx
   15faa:      	callq	*%rax
   15fac:      	cmpq	%r12, (%rsp)
   15fb0:      	je	0x16087 <generic_kprobe_path+0xa767>
   15fb6:      	movl	$0x4, %eax
   15fbb:      	leaq	0x8(%rsp), %rdi
   15fc0:      	movl	$0x8, %esi
   15fc5:      	movq	%rbx, %rdx
   15fc8:      	callq	*%rax
   15fca:      	addq	$0x20, %r12
   15fce:      	movl	$0x4, %eax
   15fd3:      	leaq	0x58(%rsp), %rdi
   15fd8:      	movl	$0x10, %ecx
   15fdd:      	movl	$0x10, %esi
   15fe2:      	movq	%r12, %rdx
   15fe5:      	callq	*%rax
   15fe7:      	movq	0x28(%rsp), %rbx
   15fec:      	movq	0x48(%rsp), %rax
   15ff1:      	movl	0x5c(%rsp), %r15d
   15ff6:      	subq	%rbx, %rax
   15ff9:      	movl	0x50(%rsp), %r12d
   15ffe:      	movl	%r15d, %edx
   16001:      	subl	%r12d, %edx
   16004:      	movl	$0x0, %ecx
   16009:      	cmovbl	%ecx, %edx
   1600c:      	addq	0x60(%rsp), %rdx
   16011:      	xorl	%esi, %esi
   16013:      	cmpl	%r15d, %r12d
   16016:      	seta	%sil
   1601a:      	movl	%r15d, %ecx
   1601d:      	cmovbl	%r12d, %ecx
   16021:      	addl	%ecx, %esi
   16023:      	movl	%r12d, %edi
   16026:      	subl	%esi, %edi
   16028:      	movl	%edi, 0x50(%rsp)
   1602c:      	subq	%rsi, %rax
   1602f:      	jb	0x17392 <generic_kprobe_path+0xba72>
   16035:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1603b:      	ja	0x17392 <generic_kprobe_path+0xba72>
   16041:      	cmpl	%r15d, %r12d
   16044:      	jbe	0x1604a <generic_kprobe_path+0xa72a>
   16046:      	movb	$0x2f, (%rbx,%rax)
   1604a:      	xorl	%edi, %edi
   1604c:      	cmpl	%r15d, %r12d
   1604f:      	seta	%dil
   16053:      	movzbl	%cl, %esi
   16056:      	addq	%rax, %rbx
   16059:      	addq	%rbx, %rdi
   1605c:      	movl	$0x4, %eax
   16061:      	callq	*%rax
   16063:      	movq	%rbx, 0x48(%rsp)
   16068:      	cmpl	%r15d, %r12d
   1606b:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   16071:      	movq	0x8(%rsp), %r12
   16076:      	movq	%r12, 0x30(%rsp)
   1607b:      	movq	0x38(%rsp), %rdx
   16080:      	movq	0x40(%rsp), %r15
   16085:      	jmp	0x160d8 <generic_kprobe_path+0xa7b8>
   16087:      	leaq	0x10(%r15), %rdx
   1608b:      	movl	$0x4, %eax
   16090:      	movq	%rbp, %rdi
   16093:      	movl	$0x8, %esi
   16098:      	callq	*%rax
   1609a:      	movq	0x40(%rsp), %rax
   1609f:      	cmpq	(%rsp), %rax
   160a3:      	je	0x1738d <generic_kprobe_path+0xba6d>
   160a9:      	addq	$0x18, %r15
   160ad:      	movl	$0x4, %eax
   160b2:      	leaq	0x30(%rsp), %rdi
   160b7:      	movl	$0x8, %esi
   160bc:      	movq	%r15, %rdx
   160bf:      	callq	*%rax
   160c1:      	movq	(%rsp), %r15
   160c5:      	movq	%r15, 0x40(%rsp)
   160ca:      	leaq	0x20(%r15), %rdx
   160ce:      	movq	%rdx, 0x38(%rsp)
   160d3:      	movq	0x30(%rsp), %r12
   160d8:      	cmpq	0x18(%rsp), %r12
   160dd:      	jne	0x160ea <generic_kprobe_path+0xa7ca>
   160df:      	cmpq	0x20(%rsp), %rdx
   160e4:      	je	0x1738d <generic_kprobe_path+0xba6d>
   160ea:      	movl	$0x4, %eax
   160ef:      	leaq	0x10(%rsp), %rdi
   160f4:      	movl	$0x8, %esi
   160f9:      	callq	*%rax
   160fb:      	cmpq	0x10(%rsp), %r12
   16100:      	je	0x161f8 <generic_kprobe_path+0xa8d8>
   16106:      	leaq	0x18(%r12), %rbx
   1610b:      	movl	$0x4, %eax
   16110:      	movq	%rbp, %rdi
   16113:      	movl	$0x8, %esi
   16118:      	movq	%rbx, %rdx
   1611b:      	callq	*%rax
   1611d:      	cmpq	%r12, (%rsp)
   16121:      	je	0x161f8 <generic_kprobe_path+0xa8d8>
   16127:      	movl	$0x4, %eax
   1612c:      	leaq	0x8(%rsp), %rdi
   16131:      	movl	$0x8, %esi
   16136:      	movq	%rbx, %rdx
   16139:      	callq	*%rax
   1613b:      	addq	$0x20, %r12
   1613f:      	movl	$0x4, %eax
   16144:      	leaq	0x58(%rsp), %rdi
   16149:      	movl	$0x10, %ecx
   1614e:      	movl	$0x10, %esi
   16153:      	movq	%r12, %rdx
   16156:      	callq	*%rax
   16158:      	movq	0x28(%rsp), %rbx
   1615d:      	movq	0x48(%rsp), %rax
   16162:      	movl	0x5c(%rsp), %r15d
   16167:      	subq	%rbx, %rax
   1616a:      	movl	0x50(%rsp), %r12d
   1616f:      	movl	%r15d, %edx
   16172:      	subl	%r12d, %edx
   16175:      	movl	$0x0, %ecx
   1617a:      	cmovbl	%ecx, %edx
   1617d:      	addq	0x60(%rsp), %rdx
   16182:      	xorl	%esi, %esi
   16184:      	cmpl	%r15d, %r12d
   16187:      	seta	%sil
   1618b:      	movl	%r15d, %ecx
   1618e:      	cmovbl	%r12d, %ecx
   16192:      	addl	%ecx, %esi
   16194:      	movl	%r12d, %edi
   16197:      	subl	%esi, %edi
   16199:      	movl	%edi, 0x50(%rsp)
   1619d:      	subq	%rsi, %rax
   161a0:      	jb	0x17392 <generic_kprobe_path+0xba72>
   161a6:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   161ac:      	ja	0x17392 <generic_kprobe_path+0xba72>
   161b2:      	cmpl	%r15d, %r12d
   161b5:      	jbe	0x161bb <generic_kprobe_path+0xa89b>
   161b7:      	movb	$0x2f, (%rbx,%rax)
   161bb:      	xorl	%edi, %edi
   161bd:      	cmpl	%r15d, %r12d
   161c0:      	seta	%dil
   161c4:      	movzbl	%cl, %esi
   161c7:      	addq	%rax, %rbx
   161ca:      	addq	%rbx, %rdi
   161cd:      	movl	$0x4, %eax
   161d2:      	callq	*%rax
   161d4:      	movq	%rbx, 0x48(%rsp)
   161d9:      	cmpl	%r15d, %r12d
   161dc:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   161e2:      	movq	0x8(%rsp), %r12
   161e7:      	movq	%r12, 0x30(%rsp)
   161ec:      	movq	0x38(%rsp), %rdx
   161f1:      	movq	0x40(%rsp), %r15
   161f6:      	jmp	0x16249 <generic_kprobe_path+0xa929>
   161f8:      	leaq	0x10(%r15), %rdx
   161fc:      	movl	$0x4, %eax
   16201:      	movq	%rbp, %rdi
   16204:      	movl	$0x8, %esi
   16209:      	callq	*%rax
   1620b:      	movq	0x40(%rsp), %rax
   16210:      	cmpq	(%rsp), %rax
   16214:      	je	0x1738d <generic_kprobe_path+0xba6d>
   1621a:      	addq	$0x18, %r15
   1621e:      	movl	$0x4, %eax
   16223:      	leaq	0x30(%rsp), %rdi
   16228:      	movl	$0x8, %esi
   1622d:      	movq	%r15, %rdx
   16230:      	callq	*%rax
   16232:      	movq	(%rsp), %r15
   16236:      	movq	%r15, 0x40(%rsp)
   1623b:      	leaq	0x20(%r15), %rdx
   1623f:      	movq	%rdx, 0x38(%rsp)
   16244:      	movq	0x30(%rsp), %r12
   16249:      	cmpq	0x18(%rsp), %r12
   1624e:      	jne	0x1625b <generic_kprobe_path+0xa93b>
   16250:      	cmpq	0x20(%rsp), %rdx
   16255:      	je	0x1738d <generic_kprobe_path+0xba6d>
   1625b:      	movl	$0x4, %eax
   16260:      	leaq	0x10(%rsp), %rdi
   16265:      	movl	$0x8, %esi
   1626a:      	callq	*%rax
   1626c:      	cmpq	0x10(%rsp), %r12
   16271:      	je	0x16369 <generic_kprobe_path+0xaa49>
   16277:      	leaq	0x18(%r12), %rbx
   1627c:      	movl	$0x4, %eax
   16281:      	movq	%rbp, %rdi
   16284:      	movl	$0x8, %esi
   16289:      	movq	%rbx, %rdx
   1628c:      	callq	*%rax
   1628e:      	cmpq	%r12, (%rsp)
   16292:      	je	0x16369 <generic_kprobe_path+0xaa49>
   16298:      	movl	$0x4, %eax
   1629d:      	leaq	0x8(%rsp), %rdi
   162a2:      	movl	$0x8, %esi
   162a7:      	movq	%rbx, %rdx
   162aa:      	callq	*%rax
   162ac:      	addq	$0x20, %r12
   162b0:      	movl	$0x4, %eax
   162b5:      	leaq	0x58(%rsp), %rdi
   162ba:      	movl	$0x10, %ecx
   162bf:      	movl	$0x10, %esi
   162c4:      	movq	%r12, %rdx
   162c7:      	callq	*%rax
   162c9:      	movq	0x28(%rsp), %rbx
   162ce:      	movq	0x48(%rsp), %rax
   162d3:      	movl	0x5c(%rsp), %r15d
   162d8:      	subq	%rbx, %rax
   162db:      	movl	0x50(%rsp), %r12d
   162e0:      	movl	%r15d, %edx
   162e3:      	subl	%r12d, %edx
   162e6:      	movl	$0x0, %ecx
   162eb:      	cmovbl	%ecx, %edx
   162ee:      	addq	0x60(%rsp), %rdx
   162f3:      	xorl	%esi, %esi
   162f5:      	cmpl	%r15d, %r12d
   162f8:      	seta	%sil
   162fc:      	movl	%r15d, %ecx
   162ff:      	cmovbl	%r12d, %ecx
   16303:      	addl	%ecx, %esi
   16305:      	movl	%r12d, %edi
   16308:      	subl	%esi, %edi
   1630a:      	movl	%edi, 0x50(%rsp)
   1630e:      	subq	%rsi, %rax
   16311:      	jb	0x17392 <generic_kprobe_path+0xba72>
   16317:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1631d:      	ja	0x17392 <generic_kprobe_path+0xba72>
   16323:      	cmpl	%r15d, %r12d
   16326:      	jbe	0x1632c <generic_kprobe_path+0xaa0c>
   16328:      	movb	$0x2f, (%rbx,%rax)
   1632c:      	xorl	%edi, %edi
   1632e:      	cmpl	%r15d, %r12d
   16331:      	seta	%dil
   16335:      	movzbl	%cl, %esi
   16338:      	addq	%rax, %rbx
   1633b:      	addq	%rbx, %rdi
   1633e:      	movl	$0x4, %eax
   16343:      	callq	*%rax
   16345:      	movq	%rbx, 0x48(%rsp)
   1634a:      	cmpl	%r15d, %r12d
   1634d:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   16353:      	movq	0x8(%rsp), %r12
   16358:      	movq	%r12, 0x30(%rsp)
   1635d:      	movq	0x38(%rsp), %rdx
   16362:      	movq	0x40(%rsp), %r15
   16367:      	jmp	0x163ba <generic_kprobe_path+0xaa9a>
   16369:      	leaq	0x10(%r15), %rdx
   1636d:      	movl	$0x4, %eax
   16372:      	movq	%rbp, %rdi
   16375:      	movl	$0x8, %esi
   1637a:      	callq	*%rax
   1637c:      	movq	0x40(%rsp), %rax
   16381:      	cmpq	(%rsp), %rax
   16385:      	je	0x1738d <generic_kprobe_path+0xba6d>
   1638b:      	addq	$0x18, %r15
   1638f:      	movl	$0x4, %eax
   16394:      	leaq	0x30(%rsp), %rdi
   16399:      	movl	$0x8, %esi
   1639e:      	movq	%r15, %rdx
   163a1:      	callq	*%rax
   163a3:      	movq	(%rsp), %r15
   163a7:      	movq	%r15, 0x40(%rsp)
   163ac:      	leaq	0x20(%r15), %rdx
   163b0:      	movq	%rdx, 0x38(%rsp)
   163b5:      	movq	0x30(%rsp), %r12
   163ba:      	cmpq	0x18(%rsp), %r12
   163bf:      	jne	0x163cc <generic_kprobe_path+0xaaac>
   163c1:      	cmpq	0x20(%rsp), %rdx
   163c6:      	je	0x1738d <generic_kprobe_path+0xba6d>
   163cc:      	movl	$0x4, %eax
   163d1:      	leaq	0x10(%rsp), %rdi
   163d6:      	movl	$0x8, %esi
   163db:      	callq	*%rax
   163dd:      	cmpq	0x10(%rsp), %r12
   163e2:      	je	0x164da <generic_kprobe_path+0xabba>
   163e8:      	leaq	0x18(%r12), %rbx
   163ed:      	movl	$0x4, %eax
   163f2:      	movq	%rbp, %rdi
   163f5:      	movl	$0x8, %esi
   163fa:      	movq	%rbx, %rdx
   163fd:      	callq	*%rax
   163ff:      	cmpq	%r12, (%rsp)
   16403:      	je	0x164da <generic_kprobe_path+0xabba>
   16409:      	movl	$0x4, %eax
   1640e:      	leaq	0x8(%rsp), %rdi
   16413:      	movl	$0x8, %esi
   16418:      	movq	%rbx, %rdx
   1641b:      	callq	*%rax
   1641d:      	addq	$0x20, %r12
   16421:      	movl	$0x4, %eax
   16426:      	leaq	0x58(%rsp), %rdi
   1642b:      	movl	$0x10, %ecx
   16430:      	movl	$0x10, %esi
   16435:      	movq	%r12, %rdx
   16438:      	callq	*%rax
   1643a:      	movq	0x28(%rsp), %rbx
   1643f:      	movq	0x48(%rsp), %rax
   16444:      	movl	0x5c(%rsp), %r15d
   16449:      	subq	%rbx, %rax
   1644c:      	movl	0x50(%rsp), %r12d
   16451:      	movl	%r15d, %edx
   16454:      	subl	%r12d, %edx
   16457:      	movl	$0x0, %ecx
   1645c:      	cmovbl	%ecx, %edx
   1645f:      	addq	0x60(%rsp), %rdx
   16464:      	xorl	%esi, %esi
   16466:      	cmpl	%r15d, %r12d
   16469:      	seta	%sil
   1646d:      	movl	%r15d, %ecx
   16470:      	cmovbl	%r12d, %ecx
   16474:      	addl	%ecx, %esi
   16476:      	movl	%r12d, %edi
   16479:      	subl	%esi, %edi
   1647b:      	movl	%edi, 0x50(%rsp)
   1647f:      	subq	%rsi, %rax
   16482:      	jb	0x17392 <generic_kprobe_path+0xba72>
   16488:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1648e:      	ja	0x17392 <generic_kprobe_path+0xba72>
   16494:      	cmpl	%r15d, %r12d
   16497:      	jbe	0x1649d <generic_kprobe_path+0xab7d>
   16499:      	movb	$0x2f, (%rbx,%rax)
   1649d:      	xorl	%edi, %edi
   1649f:      	cmpl	%r15d, %r12d
   164a2:      	seta	%dil
   164a6:      	movzbl	%cl, %esi
   164a9:      	addq	%rax, %rbx
   164ac:      	addq	%rbx, %rdi
   164af:      	movl	$0x4, %eax
   164b4:      	callq	*%rax
   164b6:      	movq	%rbx, 0x48(%rsp)
   164bb:      	cmpl	%r15d, %r12d
   164be:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   164c4:      	movq	0x8(%rsp), %r12
   164c9:      	movq	%r12, 0x30(%rsp)
   164ce:      	movq	0x38(%rsp), %rdx
   164d3:      	movq	0x40(%rsp), %r15
   164d8:      	jmp	0x1652b <generic_kprobe_path+0xac0b>
   164da:      	leaq	0x10(%r15), %rdx
   164de:      	movl	$0x4, %eax
   164e3:      	movq	%rbp, %rdi
   164e6:      	movl	$0x8, %esi
   164eb:      	callq	*%rax
   164ed:      	movq	0x40(%rsp), %rax
   164f2:      	cmpq	(%rsp), %rax
   164f6:      	je	0x1738d <generic_kprobe_path+0xba6d>
   164fc:      	addq	$0x18, %r15
   16500:      	movl	$0x4, %eax
   16505:      	leaq	0x30(%rsp), %rdi
   1650a:      	movl	$0x8, %esi
   1650f:      	movq	%r15, %rdx
   16512:      	callq	*%rax
   16514:      	movq	(%rsp), %r15
   16518:      	movq	%r15, 0x40(%rsp)
   1651d:      	leaq	0x20(%r15), %rdx
   16521:      	movq	%rdx, 0x38(%rsp)
   16526:      	movq	0x30(%rsp), %r12
   1652b:      	cmpq	0x18(%rsp), %r12
   16530:      	jne	0x1653d <generic_kprobe_path+0xac1d>
   16532:      	cmpq	0x20(%rsp), %rdx
   16537:      	je	0x1738d <generic_kprobe_path+0xba6d>
   1653d:      	movl	$0x4, %eax
   16542:      	leaq	0x10(%rsp), %rdi
   16547:      	movl	$0x8, %esi
   1654c:      	callq	*%rax
   1654e:      	cmpq	0x10(%rsp), %r12
   16553:      	je	0x1664b <generic_kprobe_path+0xad2b>
   16559:      	leaq	0x18(%r12), %rbx
   1655e:      	movl	$0x4, %eax
   16563:      	movq	%rbp, %rdi
   16566:      	movl	$0x8, %esi
   1656b:      	movq	%rbx, %rdx
   1656e:      	callq	*%rax
   16570:      	cmpq	%r12, (%rsp)
   16574:      	je	0x1664b <generic_kprobe_path+0xad2b>
   1657a:      	movl	$0x4, %eax
   1657f:      	leaq	0x8(%rsp), %rdi
   16584:      	movl	$0x8, %esi
   16589:      	movq	%rbx, %rdx
   1658c:      	callq	*%rax
   1658e:      	addq	$0x20, %r12
   16592:      	movl	$0x4, %eax
   16597:      	leaq	0x58(%rsp), %rdi
   1659c:      	movl	$0x10, %ecx
   165a1:      	movl	$0x10, %esi
   165a6:      	movq	%r12, %rdx
   165a9:      	callq	*%rax
   165ab:      	movq	0x28(%rsp), %rbx
   165b0:      	movq	0x48(%rsp), %rax
   165b5:      	movl	0x5c(%rsp), %r15d
   165ba:      	subq	%rbx, %rax
   165bd:      	movl	0x50(%rsp), %r12d
   165c2:      	movl	%r15d, %edx
   165c5:      	subl	%r12d, %edx
   165c8:      	movl	$0x0, %ecx
   165cd:      	cmovbl	%ecx, %edx
   165d0:      	addq	0x60(%rsp), %rdx
   165d5:      	xorl	%esi, %esi
   165d7:      	cmpl	%r15d, %r12d
   165da:      	seta	%sil
   165de:      	movl	%r15d, %ecx
   165e1:      	cmovbl	%r12d, %ecx
   165e5:      	addl	%ecx, %esi
   165e7:      	movl	%r12d, %edi
   165ea:      	subl	%esi, %edi
   165ec:      	movl	%edi, 0x50(%rsp)
   165f0:      	subq	%rsi, %rax
   165f3:      	jb	0x17392 <generic_kprobe_path+0xba72>
   165f9:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   165ff:      	ja	0x17392 <generic_kprobe_path+0xba72>
   16605:      	cmpl	%r15d, %r12d
   16608:      	jbe	0x1660e <generic_kprobe_path+0xacee>
   1660a:      	movb	$0x2f, (%rbx,%rax)
   1660e:      	xorl	%edi, %edi
   16610:      	cmpl	%r15d, %r12d
   16613:      	seta	%dil
   16617:      	movzbl	%cl, %esi
   1661a:      	addq	%rax, %rbx
   1661d:      	addq	%rbx, %rdi
   16620:      	movl	$0x4, %eax
   16625:      	callq	*%rax
   16627:      	movq	%rbx, 0x48(%rsp)
   1662c:      	cmpl	%r15d, %r12d
   1662f:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   16635:      	movq	0x8(%rsp), %r12
   1663a:      	movq	%r12, 0x30(%rsp)
   1663f:      	movq	0x38(%rsp), %rdx
   16644:      	movq	0x40(%rsp), %r15
   16649:      	jmp	0x1669c <generic_kprobe_path+0xad7c>
   1664b:      	leaq	0x10(%r15), %rdx
   1664f:      	movl	$0x4, %eax
   16654:      	movq	%rbp, %rdi
   16657:      	movl	$0x8, %esi
   1665c:      	callq	*%rax
   1665e:      	movq	0x40(%rsp), %rax
   16663:      	cmpq	(%rsp), %rax
   16667:      	je	0x1738d <generic_kprobe_path+0xba6d>
   1666d:      	addq	$0x18, %r15
   16671:      	movl	$0x4, %eax
   16676:      	leaq	0x30(%rsp), %rdi
   1667b:      	movl	$0x8, %esi
   16680:      	movq	%r15, %rdx
   16683:      	callq	*%rax
   16685:      	movq	(%rsp), %r15
   16689:      	movq	%r15, 0x40(%rsp)
   1668e:      	leaq	0x20(%r15), %rdx
   16692:      	movq	%rdx, 0x38(%rsp)
   16697:      	movq	0x30(%rsp), %r12
   1669c:      	cmpq	0x18(%rsp), %r12
   166a1:      	jne	0x166ae <generic_kprobe_path+0xad8e>
   166a3:      	cmpq	0x20(%rsp), %rdx
   166a8:      	je	0x1738d <generic_kprobe_path+0xba6d>
   166ae:      	movl	$0x4, %eax
   166b3:      	leaq	0x10(%rsp), %rdi
   166b8:      	movl	$0x8, %esi
   166bd:      	callq	*%rax
   166bf:      	cmpq	0x10(%rsp), %r12
   166c4:      	je	0x167bc <generic_kprobe_path+0xae9c>
   166ca:      	leaq	0x18(%r12), %rbx
   166cf:      	movl	$0x4, %eax
   166d4:      	movq	%rbp, %rdi
   166d7:      	movl	$0x8, %esi
   166dc:      	movq	%rbx, %rdx
   166df:      	callq	*%rax
   166e1:      	cmpq	%r12, (%rsp)
   166e5:      	je	0x167bc <generic_kprobe_path+0xae9c>
   166eb:      	movl	$0x4, %eax
   166f0:      	leaq	0x8(%rsp), %rdi
   166f5:      	movl	$0x8, %esi
   166fa:      	movq	%rbx, %rdx
   166fd:      	callq	*%rax
   166ff:      	addq	$0x20, %r12
   16703:      	movl	$0x4, %eax
   16708:      	leaq	0x58(%rsp), %rdi
   1670d:      	movl	$0x10, %ecx
   16712:      	movl	$0x10, %esi
   16717:      	movq	%r12, %rdx
   1671a:      	callq	*%rax
   1671c:      	movq	0x28(%rsp), %rbx
   16721:      	movq	0x48(%rsp), %rax
   16726:      	movl	0x5c(%rsp), %r15d
   1672b:      	subq	%rbx, %rax
   1672e:      	movl	0x50(%rsp), %r12d
   16733:      	movl	%r15d, %edx
   16736:      	subl	%r12d, %edx
   16739:      	movl	$0x0, %ecx
   1673e:      	cmovbl	%ecx, %edx
   16741:      	addq	0x60(%rsp), %rdx
   16746:      	xorl	%esi, %esi
   16748:      	cmpl	%r15d, %r12d
   1674b:      	seta	%sil
   1674f:      	movl	%r15d, %ecx
   16752:      	cmovbl	%r12d, %ecx
   16756:      	addl	%ecx, %esi
   16758:      	movl	%r12d, %edi
   1675b:      	subl	%esi, %edi
   1675d:      	movl	%edi, 0x50(%rsp)
   16761:      	subq	%rsi, %rax
   16764:      	jb	0x17392 <generic_kprobe_path+0xba72>
   1676a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   16770:      	ja	0x17392 <generic_kprobe_path+0xba72>
   16776:      	cmpl	%r15d, %r12d
   16779:      	jbe	0x1677f <generic_kprobe_path+0xae5f>
   1677b:      	movb	$0x2f, (%rbx,%rax)
   1677f:      	xorl	%edi, %edi
   16781:      	cmpl	%r15d, %r12d
   16784:      	seta	%dil
   16788:      	movzbl	%cl, %esi
   1678b:      	addq	%rax, %rbx
   1678e:      	addq	%rbx, %rdi
   16791:      	movl	$0x4, %eax
   16796:      	callq	*%rax
   16798:      	movq	%rbx, 0x48(%rsp)
   1679d:      	cmpl	%r15d, %r12d
   167a0:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   167a6:      	movq	0x8(%rsp), %r12
   167ab:      	movq	%r12, 0x30(%rsp)
   167b0:      	movq	0x38(%rsp), %rdx
   167b5:      	movq	0x40(%rsp), %r15
   167ba:      	jmp	0x1680d <generic_kprobe_path+0xaeed>
   167bc:      	leaq	0x10(%r15), %rdx
   167c0:      	movl	$0x4, %eax
   167c5:      	movq	%rbp, %rdi
   167c8:      	movl	$0x8, %esi
   167cd:      	callq	*%rax
   167cf:      	movq	0x40(%rsp), %rax
   167d4:      	cmpq	(%rsp), %rax
   167d8:      	je	0x1738d <generic_kprobe_path+0xba6d>
   167de:      	addq	$0x18, %r15
   167e2:      	movl	$0x4, %eax
   167e7:      	leaq	0x30(%rsp), %rdi
   167ec:      	movl	$0x8, %esi
   167f1:      	movq	%r15, %rdx
   167f4:      	callq	*%rax
   167f6:      	movq	(%rsp), %r15
   167fa:      	movq	%r15, 0x40(%rsp)
   167ff:      	leaq	0x20(%r15), %rdx
   16803:      	movq	%rdx, 0x38(%rsp)
   16808:      	movq	0x30(%rsp), %r12
   1680d:      	cmpq	0x18(%rsp), %r12
   16812:      	jne	0x1681f <generic_kprobe_path+0xaeff>
   16814:      	cmpq	0x20(%rsp), %rdx
   16819:      	je	0x1738d <generic_kprobe_path+0xba6d>
   1681f:      	movl	$0x4, %eax
   16824:      	leaq	0x10(%rsp), %rdi
   16829:      	movl	$0x8, %esi
   1682e:      	callq	*%rax
   16830:      	cmpq	0x10(%rsp), %r12
   16835:      	je	0x1692d <generic_kprobe_path+0xb00d>
   1683b:      	leaq	0x18(%r12), %rbx
   16840:      	movl	$0x4, %eax
   16845:      	movq	%rbp, %rdi
   16848:      	movl	$0x8, %esi
   1684d:      	movq	%rbx, %rdx
   16850:      	callq	*%rax
   16852:      	cmpq	%r12, (%rsp)
   16856:      	je	0x1692d <generic_kprobe_path+0xb00d>
   1685c:      	movl	$0x4, %eax
   16861:      	leaq	0x8(%rsp), %rdi
   16866:      	movl	$0x8, %esi
   1686b:      	movq	%rbx, %rdx
   1686e:      	callq	*%rax
   16870:      	addq	$0x20, %r12
   16874:      	movl	$0x4, %eax
   16879:      	leaq	0x58(%rsp), %rdi
   1687e:      	movl	$0x10, %ecx
   16883:      	movl	$0x10, %esi
   16888:      	movq	%r12, %rdx
   1688b:      	callq	*%rax
   1688d:      	movq	0x28(%rsp), %rbx
   16892:      	movq	0x48(%rsp), %rax
   16897:      	movl	0x5c(%rsp), %r15d
   1689c:      	subq	%rbx, %rax
   1689f:      	movl	0x50(%rsp), %r12d
   168a4:      	movl	%r15d, %edx
   168a7:      	subl	%r12d, %edx
   168aa:      	movl	$0x0, %ecx
   168af:      	cmovbl	%ecx, %edx
   168b2:      	addq	0x60(%rsp), %rdx
   168b7:      	xorl	%esi, %esi
   168b9:      	cmpl	%r15d, %r12d
   168bc:      	seta	%sil
   168c0:      	movl	%r15d, %ecx
   168c3:      	cmovbl	%r12d, %ecx
   168c7:      	addl	%ecx, %esi
   168c9:      	movl	%r12d, %edi
   168cc:      	subl	%esi, %edi
   168ce:      	movl	%edi, 0x50(%rsp)
   168d2:      	subq	%rsi, %rax
   168d5:      	jb	0x17392 <generic_kprobe_path+0xba72>
   168db:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   168e1:      	ja	0x17392 <generic_kprobe_path+0xba72>
   168e7:      	cmpl	%r15d, %r12d
   168ea:      	jbe	0x168f0 <generic_kprobe_path+0xafd0>
   168ec:      	movb	$0x2f, (%rbx,%rax)
   168f0:      	xorl	%edi, %edi
   168f2:      	cmpl	%r15d, %r12d
   168f5:      	seta	%dil
   168f9:      	movzbl	%cl, %esi
   168fc:      	addq	%rax, %rbx
   168ff:      	addq	%rbx, %rdi
   16902:      	movl	$0x4, %eax
   16907:      	callq	*%rax
   16909:      	movq	%rbx, 0x48(%rsp)
   1690e:      	cmpl	%r15d, %r12d
   16911:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   16917:      	movq	0x8(%rsp), %r12
   1691c:      	movq	%r12, 0x30(%rsp)
   16921:      	movq	0x38(%rsp), %rdx
   16926:      	movq	0x40(%rsp), %r15
   1692b:      	jmp	0x1697e <generic_kprobe_path+0xb05e>
   1692d:      	leaq	0x10(%r15), %rdx
   16931:      	movl	$0x4, %eax
   16936:      	movq	%rbp, %rdi
   16939:      	movl	$0x8, %esi
   1693e:      	callq	*%rax
   16940:      	movq	0x40(%rsp), %rax
   16945:      	cmpq	(%rsp), %rax
   16949:      	je	0x1738d <generic_kprobe_path+0xba6d>
   1694f:      	addq	$0x18, %r15
   16953:      	movl	$0x4, %eax
   16958:      	leaq	0x30(%rsp), %rdi
   1695d:      	movl	$0x8, %esi
   16962:      	movq	%r15, %rdx
   16965:      	callq	*%rax
   16967:      	movq	(%rsp), %r15
   1696b:      	movq	%r15, 0x40(%rsp)
   16970:      	leaq	0x20(%r15), %rdx
   16974:      	movq	%rdx, 0x38(%rsp)
   16979:      	movq	0x30(%rsp), %r12
   1697e:      	cmpq	0x18(%rsp), %r12
   16983:      	jne	0x16990 <generic_kprobe_path+0xb070>
   16985:      	cmpq	0x20(%rsp), %rdx
   1698a:      	je	0x1738d <generic_kprobe_path+0xba6d>
   16990:      	movl	$0x4, %eax
   16995:      	leaq	0x10(%rsp), %rdi
   1699a:      	movl	$0x8, %esi
   1699f:      	callq	*%rax
   169a1:      	cmpq	0x10(%rsp), %r12
   169a6:      	je	0x16a9e <generic_kprobe_path+0xb17e>
   169ac:      	leaq	0x18(%r12), %rbx
   169b1:      	movl	$0x4, %eax
   169b6:      	movq	%rbp, %rdi
   169b9:      	movl	$0x8, %esi
   169be:      	movq	%rbx, %rdx
   169c1:      	callq	*%rax
   169c3:      	cmpq	%r12, (%rsp)
   169c7:      	je	0x16a9e <generic_kprobe_path+0xb17e>
   169cd:      	movl	$0x4, %eax
   169d2:      	leaq	0x8(%rsp), %rdi
   169d7:      	movl	$0x8, %esi
   169dc:      	movq	%rbx, %rdx
   169df:      	callq	*%rax
   169e1:      	addq	$0x20, %r12
   169e5:      	movl	$0x4, %eax
   169ea:      	leaq	0x58(%rsp), %rdi
   169ef:      	movl	$0x10, %ecx
   169f4:      	movl	$0x10, %esi
   169f9:      	movq	%r12, %rdx
   169fc:      	callq	*%rax
   169fe:      	movq	0x28(%rsp), %rbx
   16a03:      	movq	0x48(%rsp), %rax
   16a08:      	movl	0x5c(%rsp), %r15d
   16a0d:      	subq	%rbx, %rax
   16a10:      	movl	0x50(%rsp), %r12d
   16a15:      	movl	%r15d, %edx
   16a18:      	subl	%r12d, %edx
   16a1b:      	movl	$0x0, %ecx
   16a20:      	cmovbl	%ecx, %edx
   16a23:      	addq	0x60(%rsp), %rdx
   16a28:      	xorl	%esi, %esi
   16a2a:      	cmpl	%r15d, %r12d
   16a2d:      	seta	%sil
   16a31:      	movl	%r15d, %ecx
   16a34:      	cmovbl	%r12d, %ecx
   16a38:      	addl	%ecx, %esi
   16a3a:      	movl	%r12d, %edi
   16a3d:      	subl	%esi, %edi
   16a3f:      	movl	%edi, 0x50(%rsp)
   16a43:      	subq	%rsi, %rax
   16a46:      	jb	0x17392 <generic_kprobe_path+0xba72>
   16a4c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   16a52:      	ja	0x17392 <generic_kprobe_path+0xba72>
   16a58:      	cmpl	%r15d, %r12d
   16a5b:      	jbe	0x16a61 <generic_kprobe_path+0xb141>
   16a5d:      	movb	$0x2f, (%rbx,%rax)
   16a61:      	xorl	%edi, %edi
   16a63:      	cmpl	%r15d, %r12d
   16a66:      	seta	%dil
   16a6a:      	movzbl	%cl, %esi
   16a6d:      	addq	%rax, %rbx
   16a70:      	addq	%rbx, %rdi
   16a73:      	movl	$0x4, %eax
   16a78:      	callq	*%rax
   16a7a:      	movq	%rbx, 0x48(%rsp)
   16a7f:      	cmpl	%r15d, %r12d
   16a82:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   16a88:      	movq	0x8(%rsp), %r12
   16a8d:      	movq	%r12, 0x30(%rsp)
   16a92:      	movq	0x38(%rsp), %rdx
   16a97:      	movq	0x40(%rsp), %r15
   16a9c:      	jmp	0x16aef <generic_kprobe_path+0xb1cf>
   16a9e:      	leaq	0x10(%r15), %rdx
   16aa2:      	movl	$0x4, %eax
   16aa7:      	movq	%rbp, %rdi
   16aaa:      	movl	$0x8, %esi
   16aaf:      	callq	*%rax
   16ab1:      	movq	0x40(%rsp), %rax
   16ab6:      	cmpq	(%rsp), %rax
   16aba:      	je	0x1738d <generic_kprobe_path+0xba6d>
   16ac0:      	addq	$0x18, %r15
   16ac4:      	movl	$0x4, %eax
   16ac9:      	leaq	0x30(%rsp), %rdi
   16ace:      	movl	$0x8, %esi
   16ad3:      	movq	%r15, %rdx
   16ad6:      	callq	*%rax
   16ad8:      	movq	(%rsp), %r15
   16adc:      	movq	%r15, 0x40(%rsp)
   16ae1:      	leaq	0x20(%r15), %rdx
   16ae5:      	movq	%rdx, 0x38(%rsp)
   16aea:      	movq	0x30(%rsp), %r12
   16aef:      	cmpq	0x18(%rsp), %r12
   16af4:      	jne	0x16b01 <generic_kprobe_path+0xb1e1>
   16af6:      	cmpq	0x20(%rsp), %rdx
   16afb:      	je	0x1738d <generic_kprobe_path+0xba6d>
   16b01:      	movl	$0x4, %eax
   16b06:      	leaq	0x10(%rsp), %rdi
   16b0b:      	movl	$0x8, %esi
   16b10:      	callq	*%rax
   16b12:      	cmpq	0x10(%rsp), %r12
   16b17:      	je	0x16c0f <generic_kprobe_path+0xb2ef>
   16b1d:      	leaq	0x18(%r12), %rbx
   16b22:      	movl	$0x4, %eax
   16b27:      	movq	%rbp, %rdi
   16b2a:      	movl	$0x8, %esi
   16b2f:      	movq	%rbx, %rdx
   16b32:      	callq	*%rax
   16b34:      	cmpq	%r12, (%rsp)
   16b38:      	je	0x16c0f <generic_kprobe_path+0xb2ef>
   16b3e:      	movl	$0x4, %eax
   16b43:      	leaq	0x8(%rsp), %rdi
   16b48:      	movl	$0x8, %esi
   16b4d:      	movq	%rbx, %rdx
   16b50:      	callq	*%rax
   16b52:      	addq	$0x20, %r12
   16b56:      	movl	$0x4, %eax
   16b5b:      	leaq	0x58(%rsp), %rdi
   16b60:      	movl	$0x10, %ecx
   16b65:      	movl	$0x10, %esi
   16b6a:      	movq	%r12, %rdx
   16b6d:      	callq	*%rax
   16b6f:      	movq	0x28(%rsp), %rbx
   16b74:      	movq	0x48(%rsp), %rax
   16b79:      	movl	0x5c(%rsp), %r15d
   16b7e:      	subq	%rbx, %rax
   16b81:      	movl	0x50(%rsp), %r12d
   16b86:      	movl	%r15d, %edx
   16b89:      	subl	%r12d, %edx
   16b8c:      	movl	$0x0, %ecx
   16b91:      	cmovbl	%ecx, %edx
   16b94:      	addq	0x60(%rsp), %rdx
   16b99:      	xorl	%esi, %esi
   16b9b:      	cmpl	%r15d, %r12d
   16b9e:      	seta	%sil
   16ba2:      	movl	%r15d, %ecx
   16ba5:      	cmovbl	%r12d, %ecx
   16ba9:      	addl	%ecx, %esi
   16bab:      	movl	%r12d, %edi
   16bae:      	subl	%esi, %edi
   16bb0:      	movl	%edi, 0x50(%rsp)
   16bb4:      	subq	%rsi, %rax
   16bb7:      	jb	0x17392 <generic_kprobe_path+0xba72>
   16bbd:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   16bc3:      	ja	0x17392 <generic_kprobe_path+0xba72>
   16bc9:      	cmpl	%r15d, %r12d
   16bcc:      	jbe	0x16bd2 <generic_kprobe_path+0xb2b2>
   16bce:      	movb	$0x2f, (%rbx,%rax)
   16bd2:      	xorl	%edi, %edi
   16bd4:      	cmpl	%r15d, %r12d
   16bd7:      	seta	%dil
   16bdb:      	movzbl	%cl, %esi
   16bde:      	addq	%rax, %rbx
   16be1:      	addq	%rbx, %rdi
   16be4:      	movl	$0x4, %eax
   16be9:      	callq	*%rax
   16beb:      	movq	%rbx, 0x48(%rsp)
   16bf0:      	cmpl	%r15d, %r12d
   16bf3:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   16bf9:      	movq	0x8(%rsp), %r12
   16bfe:      	movq	%r12, 0x30(%rsp)
   16c03:      	movq	0x38(%rsp), %rdx
   16c08:      	movq	0x40(%rsp), %r15
   16c0d:      	jmp	0x16c60 <generic_kprobe_path+0xb340>
   16c0f:      	leaq	0x10(%r15), %rdx
   16c13:      	movl	$0x4, %eax
   16c18:      	movq	%rbp, %rdi
   16c1b:      	movl	$0x8, %esi
   16c20:      	callq	*%rax
   16c22:      	movq	0x40(%rsp), %rax
   16c27:      	cmpq	(%rsp), %rax
   16c2b:      	je	0x1738d <generic_kprobe_path+0xba6d>
   16c31:      	addq	$0x18, %r15
   16c35:      	movl	$0x4, %eax
   16c3a:      	leaq	0x30(%rsp), %rdi
   16c3f:      	movl	$0x8, %esi
   16c44:      	movq	%r15, %rdx
   16c47:      	callq	*%rax
   16c49:      	movq	(%rsp), %r15
   16c4d:      	movq	%r15, 0x40(%rsp)
   16c52:      	leaq	0x20(%r15), %rdx
   16c56:      	movq	%rdx, 0x38(%rsp)
   16c5b:      	movq	0x30(%rsp), %r12
   16c60:      	cmpq	0x18(%rsp), %r12
   16c65:      	jne	0x16c72 <generic_kprobe_path+0xb352>
   16c67:      	cmpq	0x20(%rsp), %rdx
   16c6c:      	je	0x1738d <generic_kprobe_path+0xba6d>
   16c72:      	movl	$0x4, %eax
   16c77:      	leaq	0x10(%rsp), %rdi
   16c7c:      	movl	$0x8, %esi
   16c81:      	callq	*%rax
   16c83:      	cmpq	0x10(%rsp), %r12
   16c88:      	je	0x16d80 <generic_kprobe_path+0xb460>
   16c8e:      	leaq	0x18(%r12), %rbx
   16c93:      	movl	$0x4, %eax
   16c98:      	movq	%rbp, %rdi
   16c9b:      	movl	$0x8, %esi
   16ca0:      	movq	%rbx, %rdx
   16ca3:      	callq	*%rax
   16ca5:      	cmpq	%r12, (%rsp)
   16ca9:      	je	0x16d80 <generic_kprobe_path+0xb460>
   16caf:      	movl	$0x4, %eax
   16cb4:      	leaq	0x8(%rsp), %rdi
   16cb9:      	movl	$0x8, %esi
   16cbe:      	movq	%rbx, %rdx
   16cc1:      	callq	*%rax
   16cc3:      	addq	$0x20, %r12
   16cc7:      	movl	$0x4, %eax
   16ccc:      	leaq	0x58(%rsp), %rdi
   16cd1:      	movl	$0x10, %ecx
   16cd6:      	movl	$0x10, %esi
   16cdb:      	movq	%r12, %rdx
   16cde:      	callq	*%rax
   16ce0:      	movq	0x28(%rsp), %rbx
   16ce5:      	movq	0x48(%rsp), %rax
   16cea:      	movl	0x5c(%rsp), %r15d
   16cef:      	subq	%rbx, %rax
   16cf2:      	movl	0x50(%rsp), %r12d
   16cf7:      	movl	%r15d, %edx
   16cfa:      	subl	%r12d, %edx
   16cfd:      	movl	$0x0, %ecx
   16d02:      	cmovbl	%ecx, %edx
   16d05:      	addq	0x60(%rsp), %rdx
   16d0a:      	xorl	%esi, %esi
   16d0c:      	cmpl	%r15d, %r12d
   16d0f:      	seta	%sil
   16d13:      	movl	%r15d, %ecx
   16d16:      	cmovbl	%r12d, %ecx
   16d1a:      	addl	%ecx, %esi
   16d1c:      	movl	%r12d, %edi
   16d1f:      	subl	%esi, %edi
   16d21:      	movl	%edi, 0x50(%rsp)
   16d25:      	subq	%rsi, %rax
   16d28:      	jb	0x17392 <generic_kprobe_path+0xba72>
   16d2e:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   16d34:      	ja	0x17392 <generic_kprobe_path+0xba72>
   16d3a:      	cmpl	%r15d, %r12d
   16d3d:      	jbe	0x16d43 <generic_kprobe_path+0xb423>
   16d3f:      	movb	$0x2f, (%rbx,%rax)
   16d43:      	xorl	%edi, %edi
   16d45:      	cmpl	%r15d, %r12d
   16d48:      	seta	%dil
   16d4c:      	movzbl	%cl, %esi
   16d4f:      	addq	%rax, %rbx
   16d52:      	addq	%rbx, %rdi
   16d55:      	movl	$0x4, %eax
   16d5a:      	callq	*%rax
   16d5c:      	movq	%rbx, 0x48(%rsp)
   16d61:      	cmpl	%r15d, %r12d
   16d64:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   16d6a:      	movq	0x8(%rsp), %r12
   16d6f:      	movq	%r12, 0x30(%rsp)
   16d74:      	movq	0x38(%rsp), %rdx
   16d79:      	movq	0x40(%rsp), %r15
   16d7e:      	jmp	0x16dd1 <generic_kprobe_path+0xb4b1>
   16d80:      	leaq	0x10(%r15), %rdx
   16d84:      	movl	$0x4, %eax
   16d89:      	movq	%rbp, %rdi
   16d8c:      	movl	$0x8, %esi
   16d91:      	callq	*%rax
   16d93:      	movq	0x40(%rsp), %rax
   16d98:      	cmpq	(%rsp), %rax
   16d9c:      	je	0x1738d <generic_kprobe_path+0xba6d>
   16da2:      	addq	$0x18, %r15
   16da6:      	movl	$0x4, %eax
   16dab:      	leaq	0x30(%rsp), %rdi
   16db0:      	movl	$0x8, %esi
   16db5:      	movq	%r15, %rdx
   16db8:      	callq	*%rax
   16dba:      	movq	(%rsp), %r15
   16dbe:      	movq	%r15, 0x40(%rsp)
   16dc3:      	leaq	0x20(%r15), %rdx
   16dc7:      	movq	%rdx, 0x38(%rsp)
   16dcc:      	movq	0x30(%rsp), %r12
   16dd1:      	cmpq	0x18(%rsp), %r12
   16dd6:      	jne	0x16de3 <generic_kprobe_path+0xb4c3>
   16dd8:      	cmpq	0x20(%rsp), %rdx
   16ddd:      	je	0x1738d <generic_kprobe_path+0xba6d>
   16de3:      	movl	$0x4, %eax
   16de8:      	leaq	0x10(%rsp), %rdi
   16ded:      	movl	$0x8, %esi
   16df2:      	callq	*%rax
   16df4:      	cmpq	0x10(%rsp), %r12
   16df9:      	je	0x16ef1 <generic_kprobe_path+0xb5d1>
   16dff:      	leaq	0x18(%r12), %rbx
   16e04:      	movl	$0x4, %eax
   16e09:      	movq	%rbp, %rdi
   16e0c:      	movl	$0x8, %esi
   16e11:      	movq	%rbx, %rdx
   16e14:      	callq	*%rax
   16e16:      	cmpq	%r12, (%rsp)
   16e1a:      	je	0x16ef1 <generic_kprobe_path+0xb5d1>
   16e20:      	movl	$0x4, %eax
   16e25:      	leaq	0x8(%rsp), %rdi
   16e2a:      	movl	$0x8, %esi
   16e2f:      	movq	%rbx, %rdx
   16e32:      	callq	*%rax
   16e34:      	addq	$0x20, %r12
   16e38:      	movl	$0x4, %eax
   16e3d:      	leaq	0x58(%rsp), %rdi
   16e42:      	movl	$0x10, %ecx
   16e47:      	movl	$0x10, %esi
   16e4c:      	movq	%r12, %rdx
   16e4f:      	callq	*%rax
   16e51:      	movq	0x28(%rsp), %rbx
   16e56:      	movq	0x48(%rsp), %rax
   16e5b:      	movl	0x5c(%rsp), %r15d
   16e60:      	subq	%rbx, %rax
   16e63:      	movl	0x50(%rsp), %r12d
   16e68:      	movl	%r15d, %edx
   16e6b:      	subl	%r12d, %edx
   16e6e:      	movl	$0x0, %ecx
   16e73:      	cmovbl	%ecx, %edx
   16e76:      	addq	0x60(%rsp), %rdx
   16e7b:      	xorl	%esi, %esi
   16e7d:      	cmpl	%r15d, %r12d
   16e80:      	seta	%sil
   16e84:      	movl	%r15d, %ecx
   16e87:      	cmovbl	%r12d, %ecx
   16e8b:      	addl	%ecx, %esi
   16e8d:      	movl	%r12d, %edi
   16e90:      	subl	%esi, %edi
   16e92:      	movl	%edi, 0x50(%rsp)
   16e96:      	subq	%rsi, %rax
   16e99:      	jb	0x17392 <generic_kprobe_path+0xba72>
   16e9f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   16ea5:      	ja	0x17392 <generic_kprobe_path+0xba72>
   16eab:      	cmpl	%r15d, %r12d
   16eae:      	jbe	0x16eb4 <generic_kprobe_path+0xb594>
   16eb0:      	movb	$0x2f, (%rbx,%rax)
   16eb4:      	xorl	%edi, %edi
   16eb6:      	cmpl	%r15d, %r12d
   16eb9:      	seta	%dil
   16ebd:      	movzbl	%cl, %esi
   16ec0:      	addq	%rax, %rbx
   16ec3:      	addq	%rbx, %rdi
   16ec6:      	movl	$0x4, %eax
   16ecb:      	callq	*%rax
   16ecd:      	movq	%rbx, 0x48(%rsp)
   16ed2:      	cmpl	%r15d, %r12d
   16ed5:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   16edb:      	movq	0x8(%rsp), %r12
   16ee0:      	movq	%r12, 0x30(%rsp)
   16ee5:      	movq	0x38(%rsp), %rdx
   16eea:      	movq	0x40(%rsp), %r15
   16eef:      	jmp	0x16f42 <generic_kprobe_path+0xb622>
   16ef1:      	leaq	0x10(%r15), %rdx
   16ef5:      	movl	$0x4, %eax
   16efa:      	movq	%rbp, %rdi
   16efd:      	movl	$0x8, %esi
   16f02:      	callq	*%rax
   16f04:      	movq	0x40(%rsp), %rax
   16f09:      	cmpq	(%rsp), %rax
   16f0d:      	je	0x1738d <generic_kprobe_path+0xba6d>
   16f13:      	addq	$0x18, %r15
   16f17:      	movl	$0x4, %eax
   16f1c:      	leaq	0x30(%rsp), %rdi
   16f21:      	movl	$0x8, %esi
   16f26:      	movq	%r15, %rdx
   16f29:      	callq	*%rax
   16f2b:      	movq	(%rsp), %r15
   16f2f:      	movq	%r15, 0x40(%rsp)
   16f34:      	leaq	0x20(%r15), %rdx
   16f38:      	movq	%rdx, 0x38(%rsp)
   16f3d:      	movq	0x30(%rsp), %r12
   16f42:      	cmpq	0x18(%rsp), %r12
   16f47:      	jne	0x16f54 <generic_kprobe_path+0xb634>
   16f49:      	cmpq	0x20(%rsp), %rdx
   16f4e:      	je	0x1738d <generic_kprobe_path+0xba6d>
   16f54:      	movl	$0x4, %eax
   16f59:      	leaq	0x10(%rsp), %rdi
   16f5e:      	movl	$0x8, %esi
   16f63:      	callq	*%rax
   16f65:      	cmpq	0x10(%rsp), %r12
   16f6a:      	je	0x17062 <generic_kprobe_path+0xb742>
   16f70:      	leaq	0x18(%r12), %rbx
   16f75:      	movl	$0x4, %eax
   16f7a:      	movq	%rbp, %rdi
   16f7d:      	movl	$0x8, %esi
   16f82:      	movq	%rbx, %rdx
   16f85:      	callq	*%rax
   16f87:      	cmpq	%r12, (%rsp)
   16f8b:      	je	0x17062 <generic_kprobe_path+0xb742>
   16f91:      	movl	$0x4, %eax
   16f96:      	leaq	0x8(%rsp), %rdi
   16f9b:      	movl	$0x8, %esi
   16fa0:      	movq	%rbx, %rdx
   16fa3:      	callq	*%rax
   16fa5:      	addq	$0x20, %r12
   16fa9:      	movl	$0x4, %eax
   16fae:      	leaq	0x58(%rsp), %rdi
   16fb3:      	movl	$0x10, %ecx
   16fb8:      	movl	$0x10, %esi
   16fbd:      	movq	%r12, %rdx
   16fc0:      	callq	*%rax
   16fc2:      	movq	0x28(%rsp), %rbx
   16fc7:      	movq	0x48(%rsp), %rax
   16fcc:      	movl	0x5c(%rsp), %r15d
   16fd1:      	subq	%rbx, %rax
   16fd4:      	movl	0x50(%rsp), %r12d
   16fd9:      	movl	%r15d, %edx
   16fdc:      	subl	%r12d, %edx
   16fdf:      	movl	$0x0, %ecx
   16fe4:      	cmovbl	%ecx, %edx
   16fe7:      	addq	0x60(%rsp), %rdx
   16fec:      	xorl	%esi, %esi
   16fee:      	cmpl	%r15d, %r12d
   16ff1:      	seta	%sil
   16ff5:      	movl	%r15d, %ecx
   16ff8:      	cmovbl	%r12d, %ecx
   16ffc:      	addl	%ecx, %esi
   16ffe:      	movl	%r12d, %edi
   17001:      	subl	%esi, %edi
   17003:      	movl	%edi, 0x50(%rsp)
   17007:      	subq	%rsi, %rax
   1700a:      	jb	0x17392 <generic_kprobe_path+0xba72>
   17010:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   17016:      	ja	0x17392 <generic_kprobe_path+0xba72>
   1701c:      	cmpl	%r15d, %r12d
   1701f:      	jbe	0x17025 <generic_kprobe_path+0xb705>
   17021:      	movb	$0x2f, (%rbx,%rax)
   17025:      	xorl	%edi, %edi
   17027:      	cmpl	%r15d, %r12d
   1702a:      	seta	%dil
   1702e:      	movzbl	%cl, %esi
   17031:      	addq	%rax, %rbx
   17034:      	addq	%rbx, %rdi
   17037:      	movl	$0x4, %eax
   1703c:      	callq	*%rax
   1703e:      	movq	%rbx, 0x48(%rsp)
   17043:      	cmpl	%r15d, %r12d
   17046:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   1704c:      	movq	0x8(%rsp), %r12
   17051:      	movq	%r12, 0x30(%rsp)
   17056:      	movq	0x38(%rsp), %rdx
   1705b:      	movq	0x40(%rsp), %r15
   17060:      	jmp	0x170b3 <generic_kprobe_path+0xb793>
   17062:      	leaq	0x10(%r15), %rdx
   17066:      	movl	$0x4, %eax
   1706b:      	movq	%rbp, %rdi
   1706e:      	movl	$0x8, %esi
   17073:      	callq	*%rax
   17075:      	movq	0x40(%rsp), %rax
   1707a:      	cmpq	(%rsp), %rax
   1707e:      	je	0x1738d <generic_kprobe_path+0xba6d>
   17084:      	addq	$0x18, %r15
   17088:      	movl	$0x4, %eax
   1708d:      	leaq	0x30(%rsp), %rdi
   17092:      	movl	$0x8, %esi
   17097:      	movq	%r15, %rdx
   1709a:      	callq	*%rax
   1709c:      	movq	(%rsp), %r15
   170a0:      	movq	%r15, 0x40(%rsp)
   170a5:      	leaq	0x20(%r15), %rdx
   170a9:      	movq	%rdx, 0x38(%rsp)
   170ae:      	movq	0x30(%rsp), %r12
   170b3:      	cmpq	0x18(%rsp), %r12
   170b8:      	jne	0x170c5 <generic_kprobe_path+0xb7a5>
   170ba:      	cmpq	0x20(%rsp), %rdx
   170bf:      	je	0x1738d <generic_kprobe_path+0xba6d>
   170c5:      	movl	$0x4, %eax
   170ca:      	leaq	0x10(%rsp), %rdi
   170cf:      	movl	$0x8, %esi
   170d4:      	callq	*%rax
   170d6:      	cmpq	0x10(%rsp), %r12
   170db:      	je	0x171d3 <generic_kprobe_path+0xb8b3>
   170e1:      	leaq	0x18(%r12), %rbx
   170e6:      	movl	$0x4, %eax
   170eb:      	movq	%rbp, %rdi
   170ee:      	movl	$0x8, %esi
   170f3:      	movq	%rbx, %rdx
   170f6:      	callq	*%rax
   170f8:      	cmpq	%r12, (%rsp)
   170fc:      	je	0x171d3 <generic_kprobe_path+0xb8b3>
   17102:      	movl	$0x4, %eax
   17107:      	leaq	0x8(%rsp), %rdi
   1710c:      	movl	$0x8, %esi
   17111:      	movq	%rbx, %rdx
   17114:      	callq	*%rax
   17116:      	addq	$0x20, %r12
   1711a:      	movl	$0x4, %eax
   1711f:      	leaq	0x58(%rsp), %rdi
   17124:      	movl	$0x10, %ecx
   17129:      	movl	$0x10, %esi
   1712e:      	movq	%r12, %rdx
   17131:      	callq	*%rax
   17133:      	movq	0x28(%rsp), %rbx
   17138:      	movq	0x48(%rsp), %rax
   1713d:      	movl	0x5c(%rsp), %r15d
   17142:      	subq	%rbx, %rax
   17145:      	movl	0x50(%rsp), %r12d
   1714a:      	movl	%r15d, %edx
   1714d:      	subl	%r12d, %edx
   17150:      	movl	$0x0, %ecx
   17155:      	cmovbl	%ecx, %edx
   17158:      	addq	0x60(%rsp), %rdx
   1715d:      	xorl	%esi, %esi
   1715f:      	cmpl	%r15d, %r12d
   17162:      	seta	%sil
   17166:      	movl	%r15d, %ecx
   17169:      	cmovbl	%r12d, %ecx
   1716d:      	addl	%ecx, %esi
   1716f:      	movl	%r12d, %edi
   17172:      	subl	%esi, %edi
   17174:      	movl	%edi, 0x50(%rsp)
   17178:      	subq	%rsi, %rax
   1717b:      	jb	0x17392 <generic_kprobe_path+0xba72>
   17181:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   17187:      	ja	0x17392 <generic_kprobe_path+0xba72>
   1718d:      	cmpl	%r15d, %r12d
   17190:      	jbe	0x17196 <generic_kprobe_path+0xb876>
   17192:      	movb	$0x2f, (%rbx,%rax)
   17196:      	xorl	%edi, %edi
   17198:      	cmpl	%r15d, %r12d
   1719b:      	seta	%dil
   1719f:      	movzbl	%cl, %esi
   171a2:      	addq	%rax, %rbx
   171a5:      	addq	%rbx, %rdi
   171a8:      	movl	$0x4, %eax
   171ad:      	callq	*%rax
   171af:      	movq	%rbx, 0x48(%rsp)
   171b4:      	cmpl	%r15d, %r12d
   171b7:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   171bd:      	movq	0x8(%rsp), %r12
   171c2:      	movq	%r12, 0x30(%rsp)
   171c7:      	movq	0x38(%rsp), %rdx
   171cc:      	movq	0x40(%rsp), %r15
   171d1:      	jmp	0x17224 <generic_kprobe_path+0xb904>
   171d3:      	leaq	0x10(%r15), %rdx
   171d7:      	movl	$0x4, %eax
   171dc:      	movq	%rbp, %rdi
   171df:      	movl	$0x8, %esi
   171e4:      	callq	*%rax
   171e6:      	movq	0x40(%rsp), %rax
   171eb:      	cmpq	(%rsp), %rax
   171ef:      	je	0x1738d <generic_kprobe_path+0xba6d>
   171f5:      	addq	$0x18, %r15
   171f9:      	movl	$0x4, %eax
   171fe:      	leaq	0x30(%rsp), %rdi
   17203:      	movl	$0x8, %esi
   17208:      	movq	%r15, %rdx
   1720b:      	callq	*%rax
   1720d:      	movq	(%rsp), %r15
   17211:      	movq	%r15, 0x40(%rsp)
   17216:      	leaq	0x20(%r15), %rdx
   1721a:      	movq	%rdx, 0x38(%rsp)
   1721f:      	movq	0x30(%rsp), %r12
   17224:      	cmpq	0x18(%rsp), %r12
   17229:      	jne	0x17236 <generic_kprobe_path+0xb916>
   1722b:      	cmpq	0x20(%rsp), %rdx
   17230:      	je	0x1738d <generic_kprobe_path+0xba6d>
   17236:      	movl	$0x4, %eax
   1723b:      	leaq	0x10(%rsp), %rdi
   17240:      	movl	$0x8, %esi
   17245:      	callq	*%rax
   17247:      	cmpq	0x10(%rsp), %r12
   1724c:      	je	0x17336 <generic_kprobe_path+0xba16>
   17252:      	leaq	0x18(%r12), %rbx
   17257:      	movl	$0x4, %eax
   1725c:      	movq	%rbp, %rdi
   1725f:      	movl	$0x8, %esi
   17264:      	movq	%rbx, %rdx
   17267:      	callq	*%rax
   17269:      	cmpq	%r12, (%rsp)
   1726d:      	je	0x17336 <generic_kprobe_path+0xba16>
   17273:      	movl	$0x4, %eax
   17278:      	leaq	0x8(%rsp), %rdi
   1727d:      	movl	$0x8, %esi
   17282:      	movq	%rbx, %rdx
   17285:      	callq	*%rax
   17287:      	addq	$0x20, %r12
   1728b:      	movl	$0x4, %eax
   17290:      	leaq	0x58(%rsp), %rdi
   17295:      	movl	$0x10, %ecx
   1729a:      	movl	$0x10, %esi
   1729f:      	movq	%r12, %rdx
   172a2:      	callq	*%rax
   172a4:      	movq	0x28(%rsp), %rbx
   172a9:      	movq	0x48(%rsp), %rax
   172ae:      	movl	0x5c(%rsp), %r15d
   172b3:      	subq	%rbx, %rax
   172b6:      	movl	0x50(%rsp), %r12d
   172bb:      	movl	%r15d, %edx
   172be:      	subl	%r12d, %edx
   172c1:      	movl	$0x0, %ecx
   172c6:      	cmovbl	%ecx, %edx
   172c9:      	addq	0x60(%rsp), %rdx
   172ce:      	xorl	%esi, %esi
   172d0:      	cmpl	%r15d, %r12d
   172d3:      	seta	%sil
   172d7:      	movl	%r15d, %ecx
   172da:      	cmovbl	%r12d, %ecx
   172de:      	addl	%ecx, %esi
   172e0:      	movl	%r12d, %edi
   172e3:      	subl	%esi, %edi
   172e5:      	movl	%edi, 0x50(%rsp)
   172e9:      	subq	%rsi, %rax
   172ec:      	jb	0x17392 <generic_kprobe_path+0xba72>
   172f2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   172f8:      	ja	0x17392 <generic_kprobe_path+0xba72>
   172fe:      	cmpl	%r15d, %r12d
   17301:      	jbe	0x17307 <generic_kprobe_path+0xb9e7>
   17303:      	movb	$0x2f, (%rbx,%rax)
   17307:      	xorl	%edi, %edi
   17309:      	cmpl	%r15d, %r12d
   1730c:      	seta	%dil
   17310:      	movzbl	%cl, %esi
   17313:      	addq	%rax, %rbx
   17316:      	addq	%rbx, %rdi
   17319:      	movl	$0x4, %eax
   1731e:      	callq	*%rax
   17320:      	movq	%rbx, 0x48(%rsp)
   17325:      	cmpl	%r15d, %r12d
   17328:      	jbe	0x17392 <generic_kprobe_path+0xba72>
   1732a:      	movq	0x8(%rsp), %rax
   1732f:      	movq	%rax, 0x30(%rsp)
   17334:      	jmp	0x1737e <generic_kprobe_path+0xba5e>
   17336:      	leaq	0x10(%r15), %rdx
   1733a:      	movl	$0x4, %eax
   1733f:      	movq	%rbp, %rdi
   17342:      	movl	$0x8, %esi
   17347:      	callq	*%rax
   17349:      	movq	0x40(%rsp), %rax
   1734e:      	cmpq	(%rsp), %rax
   17352:      	je	0x1738d <generic_kprobe_path+0xba6d>
   17354:      	addq	$0x18, %r15
   17358:      	movl	$0x4, %eax
   1735d:      	leaq	0x30(%rsp), %rdi
   17362:      	movl	$0x8, %esi
   17367:      	movq	%r15, %rdx
   1736a:      	callq	*%rax
   1736c:      	movq	(%rsp), %rax
   17370:      	movq	%rax, 0x40(%rsp)
   17375:      	addq	$0x20, %rax
   17379:      	movq	%rax, 0x38(%rsp)
   1737e:      	movl	0x6c(%rsp), %eax
   17382:      	addl	$-0x80, %eax
   17385:      	jne	0xbac3 <generic_kprobe_path+0x1a3>
   1738b:      	jmp	0x17392 <generic_kprobe_path+0xba72>
   1738d:      	movb	$0x1, 0x54(%rsp)
   17392:      	movl	0x6428(%r14), %eax
   17399:      	incl	%eax
   1739b:      	movl	%eax, 0x6428(%r14)
   173a2:      	movl	0x48(%rsp), %ecx
   173a6:      	subl	0x80(%rsp), %ecx
   173ad:      	movl	%ecx, 0x6424(%r14)
   173b4:      	cmpb	$0x0, 0x54(%rsp)
   173b9:      	jne	0x17401 <generic_kprobe_path+0xbae1>
   173bb:      	cmpl	$0x8, %eax
   173be:      	je	0x17401 <generic_kprobe_path+0xbae1>
   173c0:      	movq	0x30(%rsp), %rax
   173c5:      	movq	%rax, 0x6458(%r14)
   173cc:      	movq	0x38(%rsp), %rax
   173d1:      	movq	%rax, 0x6460(%r14)
   173d8:      	movq	0x40(%rsp), %rax
   173dd:      	movq	%rax, 0x6468(%r14)
   173e4:      	movq	(%rip), %rcx            # 0x173eb <generic_kprobe_path+0xbacb>
   173eb:      	movl	$0x6, %edx
   173f0:      	movl	$0xc, %eax
   173f5:      	movq	0x78(%rsp), %rdi
   173fa:      	movl	$0x6, %edx
   173ff:      	jmp	0x1741c <generic_kprobe_path+0xbafc>
   17401:      	movq	(%rip), %rcx            # 0x17408 <generic_kprobe_path+0xbae8>
   17408:      	movl	$0x1, %edx
   1740d:      	movl	$0xc, %eax
   17412:      	movq	0x78(%rsp), %rdi
   17417:      	movl	$0x1, %edx
   1741c:      	movq	(%rip), %rsi            # 0x17423 <generic_kprobe_path+0xbb03>
   17423:      	jmp	0x17797 <generic_kprobe_path+0xbe77>
   17428:      	movl	$0x1, (%rsp)
   1742f:      	movq	(%rip), %rdi            # 0x17436 <generic_kprobe_path+0xbb16>
   17436:      	xorl	%ecx, %ecx
   17438:      	leaq	0x18(%rsp), %rsi
   1743d:      	movq	%rsp, %rdx
   17440:      	movl	$0x2, %eax
   17445:      	xorl	%ecx, %ecx
   17447:      	callq	*%rax
   17449:      	movq	0x58(%rsp), %r12
   1744e:      	leaq	0x10(%r12), %rdx
   17453:      	leaq	0x18(%rsp), %rdi
   17458:      	movl	$0x8, %ecx
   1745d:      	movl	$0x4, %eax
   17462:      	leaq	0xfff(%r15), %rbx
   17469:      	movl	$0x8, %esi
   1746e:      	callq	*%rax
   17470:      	cmpq	$0x0, 0x18(%rsp)
   17476:      	jne	0x174bf <generic_kprobe_path+0xbb9f>
   17478:      	leaq	0x18(%r12), %rdx
   1747d:      	leaq	0x18(%rsp), %rdi
   17482:      	movl	$0x8, %ecx
   17487:      	movl	$0x4, %eax
   1748c:      	movl	$0x8, %esi
   17491:      	callq	*%rax
   17493:      	cmpq	%r12, 0x18(%rsp)
   17498:      	je	0x174bf <generic_kprobe_path+0xbb9f>
   1749a:      	movq	%r15, %rbx
   1749d:      	addq	$0xff5, %rbx            # imm = 0xFF5
   174a4:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
   174ae:      	movq	%rax, 0xff5(%r15)
   174b5:      	movw	$0x2964, 0xffd(%r15)    # imm = 0x2964
   174bf:      	movl	$0x23, %eax
   174c4:      	callq	*%rax
   174c6:      	leaq	0xd50(%rax), %rdx
   174cd:      	movq	%rsp, %rdi
   174d0:      	movl	$0x8, %ecx
   174d5:      	movl	$0x4, %eax
   174da:      	movl	$0x8, %esi
   174df:      	callq	*%rax
   174e1:      	testq	%rax, %rax
   174e4:      	je	0x17543 <generic_kprobe_path+0xbc23>
   174e6:      	negl	%eax
   174e8:      	movw	%ax, 0x18(%rsp)
   174ed:      	movw	$0x6, 0x1a(%rsp)
   174f4:      	movabsq	$0x400000033, %rax      # imm = 0x400000033
   174fe:      	movq	%rax, 0x1c(%rsp)
   17503:      	movq	(%rip), %rdi            # 0x1750a <generic_kprobe_path+0xbbea>
   1750a:      	leaq	0x18(%rsp), %rsi
   1750f:      	movl	$0x1, %eax
   17514:      	callq	*%rax
   17516:      	testq	%rax, %rax
   17519:      	je	0x1751f <generic_kprobe_path+0xbbff>
   1751b:      	incl	(%rax)
   1751d:      	jmp	0x17543 <generic_kprobe_path+0xbc23>
   1751f:      	movl	$0x1, 0x8(%rsp)
   17527:      	movq	(%rip), %rdi            # 0x1752e <generic_kprobe_path+0xbc0e>
   1752e:      	xorl	%ecx, %ecx
   17530:      	leaq	0x18(%rsp), %rsi
   17535:      	leaq	0x8(%rsp), %rdx
   1753a:      	movl	$0x2, %eax
   1753f:      	xorl	%ecx, %ecx
   17541:      	callq	*%rax
   17543:      	movq	(%rsp), %rdx
   17547:      	leaq	0x18(%rdx), %r13
   1754b:      	movq	0x6440(%r14), %r12
   17552:      	leaq	0x6448(%r14), %rdi
   17559:      	addq	$0x20, %rdx
   1755d:      	movl	$0x8, %ecx
   17562:      	movl	$0x4, %eax
   17567:      	movl	$0x8, %esi
   1756c:      	callq	*%rax
   1756e:      	testq	%rax, %rax
   17571:      	je	0x175d0 <generic_kprobe_path+0xbcb0>
   17573:      	negl	%eax
   17575:      	movw	%ax, 0x18(%rsp)
   1757a:      	movw	$0x6, 0x1a(%rsp)
   17581:      	movabsq	$0x400000038, %rax      # imm = 0x400000038
   1758b:      	movq	%rax, 0x1c(%rsp)
   17590:      	movq	(%rip), %rdi            # 0x17597 <generic_kprobe_path+0xbc77>
   17597:      	leaq	0x18(%rsp), %rsi
   1759c:      	movl	$0x1, %eax
   175a1:      	callq	*%rax
   175a3:      	testq	%rax, %rax
   175a6:      	je	0x175ac <generic_kprobe_path+0xbc8c>
   175a8:      	incl	(%rax)
   175aa:      	jmp	0x175d0 <generic_kprobe_path+0xbcb0>
   175ac:      	movl	$0x1, 0x8(%rsp)
   175b4:      	movq	(%rip), %rdi            # 0x175bb <generic_kprobe_path+0xbc9b>
   175bb:      	xorl	%ecx, %ecx
   175bd:      	leaq	0x18(%rsp), %rsi
   175c2:      	leaq	0x8(%rsp), %rdx
   175c7:      	movl	$0x2, %eax
   175cc:      	xorl	%ecx, %ecx
   175ce:      	callq	*%rax
   175d0:      	leaq	0x6450(%r14), %rdi
   175d7:      	movl	$0x8, %ecx
   175dc:      	movl	$0x4, %eax
   175e1:      	movl	$0x8, %esi
   175e6:      	movq	%r13, %rdx
   175e9:      	callq	*%rax
   175eb:      	testq	%rax, %rax
   175ee:      	je	0x1764d <generic_kprobe_path+0xbd2d>
   175f0:      	negl	%eax
   175f2:      	movw	%ax, 0x18(%rsp)
   175f7:      	movw	$0x6, 0x1a(%rsp)
   175fe:      	movabsq	$0x400000039, %rax      # imm = 0x400000039
   17608:      	movq	%rax, 0x1c(%rsp)
   1760d:      	movq	(%rip), %rdi            # 0x17614 <generic_kprobe_path+0xbcf4>
   17614:      	leaq	0x18(%rsp), %rsi
   17619:      	movl	$0x1, %eax
   1761e:      	callq	*%rax
   17620:      	testq	%rax, %rax
   17623:      	je	0x17629 <generic_kprobe_path+0xbd09>
   17625:      	incl	(%rax)
   17627:      	jmp	0x1764d <generic_kprobe_path+0xbd2d>
   17629:      	movl	$0x1, 0x8(%rsp)
   17631:      	movq	(%rip), %rdi            # 0x17638 <generic_kprobe_path+0xbd18>
   17638:      	xorl	%ecx, %ecx
   1763a:      	leaq	0x18(%rsp), %rsi
   1763f:      	leaq	0x8(%rsp), %rdx
   17644:      	movl	$0x2, %eax
   17649:      	xorl	%ecx, %ecx
   1764b:      	callq	*%rax
   1764d:      	leaq	0x6458(%r14), %rdi
   17654:      	leaq	0x8(%r12), %rdx
   17659:      	movl	$0x8, %ecx
   1765e:      	movl	$0x4, %eax
   17663:      	movl	$0x8, %esi
   17668:      	callq	*%rax
   1766a:      	testq	%rax, %rax
   1766d:      	je	0x176cc <generic_kprobe_path+0xbdac>
   1766f:      	negl	%eax
   17671:      	movw	%ax, 0x18(%rsp)
   17676:      	movw	$0x6, 0x1a(%rsp)
   1767d:      	movabsq	$0x40000003a, %rax      # imm = 0x40000003A
   17687:      	movq	%rax, 0x1c(%rsp)
   1768c:      	movq	(%rip), %rdi            # 0x17693 <generic_kprobe_path+0xbd73>
   17693:      	leaq	0x18(%rsp), %rsi
   17698:      	movl	$0x1, %eax
   1769d:      	callq	*%rax
   1769f:      	testq	%rax, %rax
   176a2:      	je	0x176a8 <generic_kprobe_path+0xbd88>
   176a4:      	incl	(%rax)
   176a6:      	jmp	0x176cc <generic_kprobe_path+0xbdac>
   176a8:      	movl	$0x1, 0x8(%rsp)
   176b0:      	movq	(%rip), %rdi            # 0x176b7 <generic_kprobe_path+0xbd97>
   176b7:      	xorl	%ecx, %ecx
   176b9:      	leaq	0x18(%rsp), %rsi
   176be:      	leaq	0x8(%rsp), %rdx
   176c3:      	movl	$0x2, %eax
   176c8:      	xorl	%ecx, %ecx
   176ca:      	callq	*%rax
   176cc:      	movq	%r14, %rdi
   176cf:      	addq	$0x6460, %rdi           # imm = 0x6460
   176d6:      	movl	$0x8, %ecx
   176db:      	movl	$0x4, %eax
   176e0:      	movl	$0x8, %esi
   176e5:      	movq	%r12, %rdx
   176e8:      	callq	*%rax
   176ea:      	testq	%rax, %rax
   176ed:      	je	0x1774c <generic_kprobe_path+0xbe2c>
   176ef:      	negl	%eax
   176f1:      	movw	%ax, 0x18(%rsp)
   176f6:      	movw	$0x6, 0x1a(%rsp)
   176fd:      	movabsq	$0x40000003b, %rax      # imm = 0x40000003B
   17707:      	movq	%rax, 0x1c(%rsp)
   1770c:      	movq	(%rip), %rdi            # 0x17713 <generic_kprobe_path+0xbdf3>
   17713:      	leaq	0x18(%rsp), %rsi
   17718:      	movl	$0x1, %eax
   1771d:      	callq	*%rax
   1771f:      	testq	%rax, %rax
   17722:      	je	0x17728 <generic_kprobe_path+0xbe08>
   17724:      	incl	(%rax)
   17726:      	jmp	0x1774c <generic_kprobe_path+0xbe2c>
   17728:      	movl	$0x1, 0x8(%rsp)
   17730:      	movq	(%rip), %rdi            # 0x17737 <generic_kprobe_path+0xbe17>
   17737:      	xorl	%ecx, %ecx
   17739:      	leaq	0x18(%rsp), %rsi
   1773e:      	leaq	0x8(%rsp), %rdx
   17743:      	movl	$0x2, %eax
   17748:      	xorl	%ecx, %ecx
   1774a:      	callq	*%rax
   1774c:      	movq	0x6460(%r14), %rax
   17753:      	addq	$-0x20, %rax
   17757:      	movq	%rax, 0x6468(%r14)
   1775e:      	movl	$0x0, 0x6428(%r14)
   17769:      	subl	%r15d, %ebx
   1776c:      	movl	%ebx, 0x6424(%r14)
   17773:      	movl	$0x1, 0x6420(%r14)
   1777e:      	movq	(%rip), %rsi            # 0x17785 <generic_kprobe_path+0xbe65>
   17785:      	movl	$0x6, %ecx
   1778a:      	movl	$0xc, %eax
   1778f:      	movq	%rbp, %rdi
   17792:      	movl	$0x6, %edx
   17797:      	callq	*%rax
   17799:      	xorl	%eax, %eax
   1779b:      	addq	$0x88, %rsp
   177a2:      	popq	%rbx
   177a3:      	popq	%r12
   177a5:      	popq	%r13
   177a7:      	popq	%r14
   177a9:      	popq	%r15
   177ab:      	popq	%rbp
   177ac:      	retq

Disassembly of section kprobe/generic_kprobe:

0000000000000000 <generic_kprobe_event>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x88, %rsp
      11:      	movq	%rdi, %rbx
      14:      	movl	$0x0, 0x38(%rsp)
      1c:      	movq	(%rip), %rdi            # 0x23 <generic_kprobe_event+0x23>
      23:      	leaq	0x38(%rsp), %rsi
      28:      	movl	$0x1, %eax
      2d:      	callq	*%rax
      2f:      	testq	%rax, %rax
      32:      	je	0x62d <generic_kprobe_event+0x62d>
      38:      	movq	%rax, %r14
      3b:      	leaq	0x5ef8(%rax), %rsi
      42:      	movl	$0x0, 0x5ef8(%rax)
      4c:      	movq	(%rip), %rdi            # 0x53 <generic_kprobe_event+0x53>
      53:      	movl	$0x1, %eax
      58:      	callq	*%rax
      5a:      	testq	%rax, %rax
      5d:      	je	0x62d <generic_kprobe_event+0x62d>
      63:      	movl	0x64(%rax), %ecx
      66:      	movl	%ecx, 0x14(%rsp)
      6a:      	testl	%ecx, %ecx
      6c:      	je	0x23b <generic_kprobe_event+0x23b>
      72:      	movq	%rax, %r12
      75:      	movq	(%rip), %rdi            # 0x7c <generic_kprobe_event+0x7c>
      7c:      	leaq	0x14(%rsp), %rsi
      81:      	movl	$0x1, %eax
      86:      	callq	*%rax
      88:      	testq	%rax, %rax
      8b:      	je	0x62d <generic_kprobe_event+0x62d>
      91:      	movq	%rax, %r15
      94:      	movl	$0x0, 0x3c(%rsp)
      9c:      	movq	(%rip), %rdi            # 0xa3 <generic_kprobe_event+0xa3>
      a3:      	leaq	0x3c(%rsp), %rsi
      a8:      	movl	$0x1, %eax
      ad:      	callq	*%rax
      af:      	testq	%rax, %rax
      b2:      	je	0xd8 <generic_kprobe_event+0xd8>
      b4:      	cmpq	$0x63677270, 0x20(%rax) # imm = 0x63677270
      bc:      	jne	0xdc <generic_kprobe_event+0xdc>
      be:      	movl	$0x50, %eax
      c3:      	callq	*%rax
      c5:      	movq	%rax, 0x8(%rsp)
      ca:      	testq	%rax, %rax
      cd:      	jne	0x1f6 <generic_kprobe_event+0x1f6>
      d3:      	jmp	0x62d <generic_kprobe_event+0x62d>
      d8:      	xorl	%ebp, %ebp
      da:      	jmp	0xdf <generic_kprobe_event+0xdf>
      dc:      	movl	0x10(%rax), %ebp
      df:      	movl	$0x23, %eax
      e4:      	callq	*%rax
      e6:      	movq	$0x0, 0x20(%rsp)
      ef:      	leaq	0xf90(%rax), %rdx
      f6:      	leaq	0x28(%rsp), %rdi
      fb:      	movl	$0x8, %ecx
     100:      	movl	$0x71, %eax
     105:      	movl	$0x8, %esi
     10a:      	callq	*%rax
     10c:      	movq	0x28(%rsp), %rax
     111:      	testq	%rax, %rax
     114:      	je	0x62d <generic_kprobe_event+0x62d>
     11a:      	cmpl	$0xb, %ebp
     11d:      	ja	0x62d <generic_kprobe_event+0x62d>
     123:      	movl	%ebp, %edx
     125:      	leaq	(%rax,%rdx,8), %rcx
     129:      	leaq	0x40(%rsp), %rdi
     12e:      	movl	$0x8, %esi
     133:      	movl	$0x71, %eax
     138:      	shlq	$0x3, %rdx
     13c:      	addq	0x28(%rsp), %rdx
     141:      	movl	$0x8, %esi
     146:      	callq	*%rax
     148:      	movq	0x40(%rsp), %rcx
     14d:      	testq	%rcx, %rcx
     150:      	je	0x62d <generic_kprobe_event+0x62d>
     156:      	leaq	0x20(%rsp), %rdi
     15b:      	movl	$0x8, %edx
     160:      	movl	$0x71, %eax
     165:      	movq	0x40(%rsp), %rdx
     16a:      	movl	$0x8, %esi
     16f:      	callq	*%rax
     171:      	movq	0x20(%rsp), %rdx
     176:      	testq	%rdx, %rdx
     179:      	je	0x62d <generic_kprobe_event+0x62d>
     17f:      	movq	$0x0, 0x40(%rsp)
     188:      	addq	$0x100, %rdx            # imm = 0x100
     18f:      	leaq	0x40(%rsp), %rdi
     194:      	movl	$0x8, %ecx
     199:      	movl	$0x71, %eax
     19e:      	movl	$0x8, %esi
     1a3:      	callq	*%rax
     1a5:      	movq	0x40(%rsp), %rdx
     1aa:      	movq	$0x0, 0x40(%rsp)
     1b3:      	testq	%rdx, %rdx
     1b6:      	je	0x1e6 <generic_kprobe_event+0x1e6>
     1b8:      	addq	$0x60, %rdx
     1bc:      	leaq	0x40(%rsp), %rdi
     1c1:      	movl	$0x8, %ecx
     1c6:      	movl	$0x71, %eax
     1cb:      	movl	$0x8, %esi
     1d0:      	callq	*%rax
     1d2:      	movq	0x40(%rsp), %rax
     1d7:      	movq	%rax, 0x8(%rsp)
     1dc:      	testq	%rax, %rax
     1df:      	jne	0x1f6 <generic_kprobe_event+0x1f6>
     1e1:      	jmp	0x62d <generic_kprobe_event+0x62d>
     1e6:      	xorl	%eax, %eax
     1e8:      	movq	%rax, 0x8(%rsp)
     1ed:      	testq	%rax, %rax
     1f0:      	je	0x62d <generic_kprobe_event+0x62d>
     1f6:      	movq	%rax, 0x40(%rsp)
     1fb:      	movq	(%rip), %rdi            # 0x202 <generic_kprobe_event+0x202>
     202:      	leaq	0x40(%rsp), %rsi
     207:      	movl	$0x1, %eax
     20c:      	callq	*%rax
     20e:      	testq	%rax, %rax
     211:      	je	0x220 <generic_kprobe_event+0x220>
     213:      	movq	(%rax), %rax
     216:      	testq	%rax, %rax
     219:      	je	0x220 <generic_kprobe_event+0x220>
     21b:      	movq	%rax, 0x8(%rsp)
     220:      	leaq	0x8(%rsp), %rsi
     225:      	movl	$0x1, %eax
     22a:      	movq	%r15, %rdi
     22d:      	callq	*%rax
     22f:      	testq	%rax, %rax
     232:      	movq	%r12, %rax
     235:      	je	0x641 <generic_kprobe_event+0x641>
     23b:      	movl	(%rax), %eax
     23d:      	movq	%rax, 0x60(%r14)
     241:      	movq	$0x0, 0x68(%r14)
     249:      	movq	$0x0, 0x5efc(%r14)
     254:      	movl	$0x0, 0x6420(%r14)
     25f:      	movq	$0x0, 0x5eb8(%r14)
     26a:      	movq	$0x0, 0x5ec0(%r14)
     275:      	movq	$0x0, 0x5ec8(%r14)
     280:      	movq	$0x0, 0x5ed0(%r14)
     28b:      	movq	$0x0, 0x5ed8(%r14)
     296:      	movb	$0x0, 0x5ee0(%r14)
     29e:      	movl	$0x23, %eax
     2a3:      	callq	*%rax
     2a5:      	movq	%rax, %r15
     2a8:      	leaq	0xd70(%rax), %rdx
     2af:      	leaq	0x20(%rsp), %rdi
     2b4:      	movl	$0x8, %ecx
     2b9:      	movl	$0x4, %eax
     2be:      	leaq	0x20(%r14), %r12
     2c2:      	movl	$0x4, %r13d
     2c8:      	movl	$0x8, %esi
     2cd:      	callq	*%rax
     2cf:      	movq	0x20(%rsp), %rcx
     2d4:      	leaq	0x40(%rsp), %rdi
     2d9:      	movl	$0x48, %edx
     2de:      	movl	$0x4, %eax
     2e3:      	movq	0x20(%rsp), %rdx
     2e8:      	movl	$0x48, %esi
     2ed:      	callq	*%rax
     2ef:      	movl	$0x218, %edx            # imm = 0x218
     2f4:      	movq	0x48(%rsp), %rcx
     2f9:      	addq	%rdx, %rcx
     2fc:      	movl	$0x4, %esi
     301:      	movl	$0x4, %eax
     306:      	addq	0x48(%rsp), %rdx
     30b:      	movq	%r12, %rdi
     30e:      	movl	$0x4, %esi
     313:      	callq	*%rax
     315:      	leaq	0x24(%r14), %rdi
     319:      	movl	$0x4d8, %edx            # imm = 0x4D8
     31e:      	movq	0x50(%rsp), %rcx
     323:      	addq	%rdx, %rcx
     326:      	movl	$0x4, %esi
     32b:      	movl	$0x4, %eax
     330:      	addq	0x50(%rsp), %rdx
     335:      	movl	$0x4, %esi
     33a:      	callq	*%rax
     33c:      	leaq	0x28(%r14), %rdi
     340:      	movq	0x58(%rsp), %rcx
     345:      	addq	$0x58, %rcx
     349:      	movl	$0x4, %edx
     34e:      	movl	$0x4, %eax
     353:      	movq	0x58(%rsp), %rdx
     358:      	addq	$0x58, %rdx
     35c:      	movl	$0x4, %esi
     361:      	callq	*%rax
     363:      	movq	$0x0, 0x8(%rsp)
     36c:      	leaq	0xb58(%r15), %rdx
     373:      	leaq	0x8(%rsp), %rdi
     378:      	movl	$0x8, %ecx
     37d:      	movl	$0x4, %eax
     382:      	movl	$0x8, %esi
     387:      	callq	*%rax
     389:      	movq	0x8(%rsp), %rcx
     38e:      	testq	%rcx, %rcx
     391:      	je	0x427 <generic_kprobe_event+0x427>
     397:      	movl	$0x0, 0x18(%rsp)
     39f:      	addq	$0x4, %rcx
     3a3:      	leaq	0x18(%rsp), %rdi
     3a8:      	movl	$0x4, %eax
     3ad:      	movq	0x8(%rsp), %rdx
     3b2:      	addq	$0x4, %rdx
     3b6:      	movl	$0x4, %esi
     3bb:      	callq	*%rax
     3bd:      	movq	0x8(%rsp), %rax
     3c2:      	movslq	0x18(%rsp), %rcx
     3c7:      	shlq	$0x4, %rcx
     3cb:      	addq	%rax, %rcx
     3ce:      	addq	$0x80, %rcx
     3d5:      	leaq	0x28(%rsp), %rdi
     3da:      	movl	$0x10, %edx
     3df:      	movl	$0x4, %eax
     3e4:      	movq	0x8(%rsp), %rcx
     3e9:      	movslq	0x18(%rsp), %rdx
     3ee:      	shlq	$0x4, %rdx
     3f2:      	addq	%rcx, %rdx
     3f5:      	addq	$0x80, %rdx
     3fc:      	movl	$0x10, %esi
     401:      	callq	*%rax
     403:      	leaq	0x2c(%r14), %rdi
     407:      	movl	$0x158, %edx            # imm = 0x158
     40c:      	movq	0x30(%rsp), %rcx
     411:      	addq	%rdx, %rcx
     414:      	movl	$0x4, %eax
     419:      	addq	0x30(%rsp), %rdx
     41e:      	movl	$0x4, %esi
     423:      	callq	*%rax
     425:      	jmp	0x42f <generic_kprobe_event+0x42f>
     427:      	movl	$0x0, 0x2c(%r14)
     42f:      	leaq	0x30(%r14), %rdi
     433:      	movl	$0x158, %r12d           # imm = 0x158
     439:      	movq	0x60(%rsp), %rcx
     43e:      	addq	%r12, %rcx
     441:      	movl	$0x4, %edx
     446:      	movl	$0x4, %eax
     44b:      	movq	0x60(%rsp), %rdx
     450:      	addq	%r12, %rdx
     453:      	movl	$0x4, %esi
     458:      	callq	*%rax
     45a:      	leaq	0x34(%r14), %rdi
     45e:      	movl	$0x118, %edx            # imm = 0x118
     463:      	movq	0x68(%rsp), %rcx
     468:      	addq	%rdx, %rcx
     46b:      	movl	$0x4, %esi
     470:      	movl	$0x4, %eax
     475:      	addq	0x68(%rsp), %rdx
     47a:      	movl	$0x4, %esi
     47f:      	callq	*%rax
     481:      	leaq	0x38(%r14), %rdi
     485:      	movl	$0x98, %r13d
     48b:      	movq	0x70(%rsp), %rcx
     490:      	addq	%r13, %rcx
     493:      	movl	$0x4, %edx
     498:      	movl	$0x4, %eax
     49d:      	movq	0x70(%rsp), %rdx
     4a2:      	addq	%r13, %rdx
     4a5:      	movl	$0x4, %esi
     4aa:      	callq	*%rax
     4ac:      	leaq	0x3c(%r14), %rdi
     4b0:      	movq	0x78(%rsp), %rcx
     4b5:      	addq	%r13, %rcx
     4b8:      	movl	$0x4, %edx
     4bd:      	movl	$0x4, %eax
     4c2:      	addq	0x78(%rsp), %r13
     4c7:      	movl	$0x4, %esi
     4cc:      	movq	%r13, %rdx
     4cf:      	callq	*%rax
     4d1:      	leaq	0x40(%r14), %rdi
     4d5:      	movq	0x80(%rsp), %rcx
     4dd:      	addq	$0x58, %rcx
     4e1:      	movl	$0x4, %edx
     4e6:      	movl	$0x4, %eax
     4eb:      	movq	0x80(%rsp), %rdx
     4f3:      	addq	$0x58, %rdx
     4f7:      	movl	$0x4, %esi
     4fc:      	callq	*%rax
     4fe:      	movq	$0x0, 0x28(%rsp)
     507:      	movq	$0x0, 0x8(%rsp)
     510:      	addq	$0xd00, %r15            # imm = 0xD00
     517:      	leaq	0x28(%rsp), %rdi
     51c:      	movl	$0x8, %ecx
     521:      	movl	$0x4, %eax
     526:      	movl	$0x8, %esi
     52b:      	movq	%r15, %rdx
     52e:      	callq	*%rax
     530:      	movl	$0x90, %edx
     535:      	movq	0x28(%rsp), %rcx
     53a:      	addq	%rdx, %rcx
     53d:      	leaq	0x8(%rsp), %rdi
     542:      	movl	$0x8, %esi
     547:      	movl	$0x4, %eax
     54c:      	addq	0x28(%rsp), %rdx
     551:      	movl	$0x8, %esi
     556:      	callq	*%rax
     558:      	leaq	0x44(%r14), %rdi
     55c:      	movq	0x8(%rsp), %rcx
     561:      	addq	%r12, %rcx
     564:      	movl	$0x4, %edx
     569:      	movl	$0x4, %eax
     56e:      	addq	0x8(%rsp), %r12
     573:      	movl	$0x4, %esi
     578:      	movq	%r12, %rdx
     57b:      	callq	*%rax
     57d:      	leaq	0x48(%r14), %r12
     581:      	leaq	0x40(%rsp), %rdi
     586:      	movl	$0x8, %ecx
     58b:      	movl	$0x4, %eax
     590:      	movl	$0x8, %esi
     595:      	movq	%r15, %rdx
     598:      	callq	*%rax
     59a:      	movq	0x40(%rsp), %r15
     59f:      	leaq	0x50(%r14), %rdi
     5a3:      	leaq	0x40(%r15), %rdx
     5a7:      	movl	$0x8, %ecx
     5ac:      	movl	$0x4, %eax
     5b1:      	movl	$0x8, %esi
     5b6:      	callq	*%rax
     5b8:      	movq	%r14, %rdi
     5bb:      	addq	$0x58, %rdi
     5bf:      	leaq	0x30(%r15), %rdx
     5c3:      	movl	$0x8, %ecx
     5c8:      	movl	$0x4, %eax
     5cd:      	movl	$0x8, %esi
     5d2:      	callq	*%rax
     5d4:      	addq	$0x38, %r15
     5d8:      	movl	$0x8, %ecx
     5dd:      	movl	$0x4, %eax
     5e2:      	movq	%r12, %rdi
     5e5:      	movl	$0x8, %esi
     5ea:      	movq	%r15, %rdx
     5ed:      	callq	*%rax
     5ef:      	movb	$0x0, 0x5f08(%r14)
     5f7:      	movb	$0x0, 0x1(%r14)
     5fc:      	movq	$0x0, 0x5ee8(%r14)
     607:      	movq	$0x0, 0x5ef0(%r14)
     612:      	movq	(%rip), %rsi            # 0x619 <generic_kprobe_event+0x619>
     619:      	movl	$0x2, %ecx
     61e:      	movl	$0xc, %eax
     623:      	movq	%rbx, %rdi
     626:      	movl	$0x2, %edx
     62b:      	callq	*%rax
     62d:      	xorl	%eax, %eax
     62f:      	addq	$0x88, %rsp
     636:      	popq	%rbx
     637:      	popq	%r12
     639:      	popq	%r13
     63b:      	popq	%r14
     63d:      	popq	%r15
     63f:      	popq	%rbp
     640:      	retq
     641:      	movq	$-0x1, 0x18(%rsp)
     64a:      	leaq	0x18(%rsp), %rsi
     64f:      	movl	$0x1, %eax
     654:      	movq	%r15, %rdi
     657:      	callq	*%rax
     659:      	testq	%rax, %rax
     65c:      	je	0x62d <generic_kprobe_event+0x62d>
     65e:      	movl	$0x1, 0x14(%rsp)
     666:      	movq	(%rip), %rdi            # 0x66d <generic_kprobe_event+0x66d>
     66d:      	leaq	0x14(%rsp), %rsi
     672:      	movl	$0x1, %eax
     677:      	callq	*%rax
     679:      	testq	%rax, %rax
     67c:      	je	0x62d <generic_kprobe_event+0x62d>
     67e:      	movq	%rax, %rdi
     681:      	leaq	0x8(%rsp), %rsi
     686:      	movl	$0x1, %eax
     68b:      	callq	*%rax
     68d:      	testq	%rax, %rax
     690:      	movq	%r12, %rax
     693:      	jne	0x62d <generic_kprobe_event+0x62d>
     695:      	jmp	0x23b <generic_kprobe_event+0x23b>

Disassembly of section kprobe/generic_kprobe_override:

0000000000000000 <generic_kprobe_override>:
       0:      	pushq	%rbx
       1:      	subq	$0x10, %rsp
       5:      	movq	%rdi, %rbx
       8:      	movl	$0xe, %eax
       d:      	callq	*%rax
       f:      	movq	%rax, 0x8(%rsp)
      14:      	movq	(%rip), %rdi            # 0x1b <generic_kprobe_override+0x1b>
      1b:      	leaq	0x8(%rsp), %rsi
      20:      	movl	$0x1, %eax
      25:      	callq	*%rax
      27:      	testq	%rax, %rax
      2a:      	je	0x52 <generic_kprobe_override+0x52>
      2c:      	movslq	(%rax), %rcx
      2f:      	movq	%rax, %rdx
      32:      	movl	$0x3a, %eax
      37:      	movslq	(%rdx), %rsi
      3a:      	movq	%rbx, %rdi
      3d:      	callq	*%rax
      3f:      	movq	(%rip), %rdi            # 0x46 <generic_kprobe_override+0x46>
      46:      	leaq	0x8(%rsp), %rsi
      4b:      	movl	$0x3, %eax
      50:      	callq	*%rax
      52:      	xorl	%eax, %eax
      54:      	addq	$0x10, %rsp
      58:      	popq	%rbx
      59:      	retq

Disassembly of section fmod_ret/security_task_prctl:

0000000000000000 <generic_fmodret_override>:
       0:      	pushq	%rbx
       1:      	subq	$0x10, %rsp
       5:      	movl	$0xe, %eax
       a:      	callq	*%rax
       c:      	movq	%rax, 0x8(%rsp)
      11:      	movq	(%rip), %rdi            # 0x18 <generic_fmodret_override+0x18>
      18:      	leaq	0x8(%rsp), %rsi
      1d:      	movl	$0x1, %eax
      22:      	callq	*%rax
      24:      	testq	%rax, %rax
      27:      	je	0x48 <generic_fmodret_override+0x48>
      29:      	movq	%rax, %rbx
      2c:      	movq	(%rip), %rdi            # 0x33 <generic_fmodret_override+0x33>
      33:      	leaq	0x8(%rsp), %rsi
      38:      	movl	$0x3, %eax
      3d:      	callq	*%rax
      3f:      	movslq	(%rbx), %rax
      42:      	addq	$0x10, %rsp
      46:      	popq	%rbx
      47:      	retq
      48:      	xorl	%eax, %eax
      4a:      	addq	$0x10, %rsp
      4e:      	popq	%rbx
      4f:      	retq
