
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_generic_lsm_core_v61.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <extract_arg_depth>:
       0:      	movl	$0x1, %eax
       5:      	cmpl	$0x9, %edi
       8:      	ja	0x82 <extract_arg_depth+0x82>
       a:      	pushq	%r14
       c:      	pushq	%rbx
       d:      	pushq	%rax
       e:      	movq	(%rsi), %r8
      11:      	movl	%edi, %r9d
      14:      	cmpw	$0x0, 0x6(%r8,%r9,8)
      1b:      	je	0x7b <extract_arg_depth+0x7b>
      1d:      	movq	0x8(%rsi), %rcx
      21:      	movl	(%r8,%r9,8), %edx
      25:      	addq	(%rcx), %rdx
      28:      	movq	%rdx, (%rcx)
      2b:      	xorl	%eax, %eax
      2d:      	cmpw	$0x0, 0x4(%r8,%r9,8)
      34:      	je	0x7b <extract_arg_depth+0x7b>
      36:      	movl	%edi, %ebx
      38:      	cmpb	$0x0, 0x10(%rsi)
      3c:      	je	0x4a <extract_arg_depth+0x4a>
      3e:      	movl	$0x8, %edi
      43:      	movl	$0x94, %eax
      48:      	jmp	0x54 <extract_arg_depth+0x54>
      4a:      	movl	$0x8, %edi
      4f:      	movl	$0x4, %eax
      54:      	movq	%rsi, %r14
      57:      	movq	0x8(%rsi), %rdi
      5b:      	movq	(%rdi), %rdx
      5e:      	movl	$0x8, %esi
      63:      	callq	*%rax
      65:      	testl	%eax, %eax
      67:      	movl	$0x0, %eax
      6c:      	jns	0x7b <extract_arg_depth+0x7b>
      6e:      	incl	%ebx
      70:      	movq	0x18(%r14), %rax
      74:      	movl	%ebx, (%rax)
      76:      	movl	$0x1, %eax
      7b:      	addq	$0x8, %rsp
      7f:      	popq	%rbx
      80:      	popq	%r14
      82:      	retq
      83:      	nopw	%cs:(%rax,%rax)

0000000000000090 <do_bytes>:
      90:      	pushq	%rbp
      91:      	pushq	%r15
      93:      	pushq	%r14
      95:      	pushq	%r13
      97:      	pushq	%r12
      99:      	pushq	%rbx
      9a:      	pushq	%rax
      9b:      	movq	%rcx, %rbx
      9e:      	movq	%rdx, %r14
      a1:      	movq	%rsi, %r15
      a4:      	movq	%rdi, %r12
      a7:      	callq	0x2f0 <__do_bytes>
      ac:      	testl	%eax, %eax
      ae:      	js	0x257 <do_bytes+0x1c7>
      b4:      	movl	%eax, %r13d
      b7:      	andl	$0x7fffffff, %r13d      # imm = 0x7FFFFFFF
      be:      	movq	%rbx, %rcx
      c1:      	subq	%r13, %rcx
      c4:      	je	0x2de <do_bytes+0x24e>
      ca:      	leaq	(%r14,%r13), %rdx
      ce:      	movq	%r12, %rdi
      d1:      	movq	%r15, %rsi
      d4:      	callq	0x2f0 <__do_bytes>
      d9:      	testl	%eax, %eax
      db:      	js	0x257 <do_bytes+0x1c7>
      e1:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
      e6:      	movq	%rax, %rbp
      e9:      	addq	%r13, %rbp
      ec:      	movq	%rbx, %rcx
      ef:      	subq	%rbp, %rcx
      f2:      	je	0x2de <do_bytes+0x24e>
      f8:      	leaq	(%r14,%rbp), %rdx
      fc:      	movq	%r12, %rdi
      ff:      	movq	%r15, %rsi
     102:      	callq	0x2f0 <__do_bytes>
     107:      	testl	%eax, %eax
     109:      	js	0x257 <do_bytes+0x1c7>
     10f:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     114:      	movq	%rax, %r13
     117:      	addq	%rbp, %r13
     11a:      	movq	%rbx, %rcx
     11d:      	subq	%r13, %rcx
     120:      	je	0x2de <do_bytes+0x24e>
     126:      	leaq	(%r14,%r13), %rdx
     12a:      	movq	%r12, %rdi
     12d:      	movq	%r15, %rsi
     130:      	callq	0x2f0 <__do_bytes>
     135:      	testl	%eax, %eax
     137:      	js	0x257 <do_bytes+0x1c7>
     13d:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     142:      	movq	%rax, %rbp
     145:      	addq	%r13, %rbp
     148:      	movq	%rbx, %rcx
     14b:      	subq	%rbp, %rcx
     14e:      	je	0x2de <do_bytes+0x24e>
     154:      	leaq	(%r14,%rbp), %rdx
     158:      	movq	%r12, %rdi
     15b:      	movq	%r15, %rsi
     15e:      	callq	0x2f0 <__do_bytes>
     163:      	testl	%eax, %eax
     165:      	js	0x257 <do_bytes+0x1c7>
     16b:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     170:      	movq	%rax, %r13
     173:      	addq	%rbp, %r13
     176:      	movq	%rbx, %rcx
     179:      	subq	%r13, %rcx
     17c:      	je	0x2de <do_bytes+0x24e>
     182:      	leaq	(%r14,%r13), %rdx
     186:      	movq	%r12, %rdi
     189:      	movq	%r15, %rsi
     18c:      	callq	0x2f0 <__do_bytes>
     191:      	testl	%eax, %eax
     193:      	js	0x257 <do_bytes+0x1c7>
     199:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     19e:      	movq	%rax, %rbp
     1a1:      	addq	%r13, %rbp
     1a4:      	movq	%rbx, %rcx
     1a7:      	subq	%rbp, %rcx
     1aa:      	je	0x2de <do_bytes+0x24e>
     1b0:      	leaq	(%r14,%rbp), %rdx
     1b4:      	movq	%r12, %rdi
     1b7:      	movq	%r15, %rsi
     1ba:      	callq	0x2f0 <__do_bytes>
     1bf:      	testl	%eax, %eax
     1c1:      	js	0x257 <do_bytes+0x1c7>
     1c7:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     1cc:      	movq	%rax, %r13
     1cf:      	addq	%rbp, %r13
     1d2:      	movq	%rbx, %rcx
     1d5:      	subq	%r13, %rcx
     1d8:      	je	0x2de <do_bytes+0x24e>
     1de:      	leaq	(%r14,%r13), %rdx
     1e2:      	movq	%r12, %rdi
     1e5:      	movq	%r15, %rsi
     1e8:      	callq	0x2f0 <__do_bytes>
     1ed:      	testl	%eax, %eax
     1ef:      	js	0x257 <do_bytes+0x1c7>
     1f1:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     1f6:      	movq	%rax, %rbp
     1f9:      	addq	%r13, %rbp
     1fc:      	movq	%rbx, %rcx
     1ff:      	subq	%rbp, %rcx
     202:      	je	0x2de <do_bytes+0x24e>
     208:      	leaq	(%r14,%rbp), %rdx
     20c:      	movq	%r12, %rdi
     20f:      	movq	%r15, %rsi
     212:      	callq	0x2f0 <__do_bytes>
     217:      	testl	%eax, %eax
     219:      	js	0x257 <do_bytes+0x1c7>
     21b:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     220:      	movq	%rax, %r13
     223:      	addq	%rbp, %r13
     226:      	movq	%rbx, %rcx
     229:      	subq	%r13, %rcx
     22c:      	je	0x2de <do_bytes+0x24e>
     232:      	addq	%r13, %r14
     235:      	movq	%r12, %rdi
     238:      	movq	%r15, %rsi
     23b:      	movq	%r14, %rdx
     23e:      	callq	0x2f0 <__do_bytes>
     243:      	testl	%eax, %eax
     245:      	js	0x257 <do_bytes+0x1c7>
     247:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     24c:      	addq	%r13, %rax
     24f:      	movq	%rax, %rbx
     252:      	jmp	0x2de <do_bytes+0x24e>
     257:      	movslq	%eax, %rbx
     25a:      	movl	$0x0, 0x4(%rsp)
     262:      	movq	(%rip), %rdi            # 0x269 <do_bytes+0x1d9>
     269:      	leaq	0x4(%rsp), %rsi
     26e:      	movl	$0x1, %eax
     273:      	callq	*%rax
     275:      	testq	%rax, %rax
     278:      	je	0x2de <do_bytes+0x24e>
     27a:      	cmpq	$-0xc, %rbx
     27e:      	jg	0x29a <do_bytes+0x20a>
     280:      	cmpq	$-0x1c, %rbx
     284:      	je	0x2b4 <do_bytes+0x224>
     286:      	cmpq	$-0x16, %rbx
     28a:      	je	0x2cc <do_bytes+0x23c>
     28c:      	cmpq	$-0x10, %rbx
     290:      	jne	0x2c4 <do_bytes+0x234>
     292:      	addq	$0x558, %rax            # imm = 0x558
     298:      	jmp	0x2da <do_bytes+0x24a>
     29a:      	cmpq	$-0xb, %rbx
     29e:      	je	0x2bc <do_bytes+0x22c>
     2a0:      	cmpq	$-0x7, %rbx
     2a4:      	je	0x2d4 <do_bytes+0x244>
     2a6:      	cmpq	$-0x2, %rbx
     2aa:      	jne	0x2c4 <do_bytes+0x234>
     2ac:      	addq	$0x548, %rax            # imm = 0x548
     2b2:      	jmp	0x2da <do_bytes+0x24a>
     2b4:      	addq	$0x568, %rax            # imm = 0x568
     2ba:      	jmp	0x2da <do_bytes+0x24a>
     2bc:      	addq	$0x570, %rax            # imm = 0x570
     2c2:      	jmp	0x2da <do_bytes+0x24a>
     2c4:      	addq	$0x540, %rax            # imm = 0x540
     2ca:      	jmp	0x2da <do_bytes+0x24a>
     2cc:      	addq	$0x560, %rax            # imm = 0x560
     2d2:      	jmp	0x2da <do_bytes+0x24a>
     2d4:      	addq	$0x550, %rax            # imm = 0x550
     2da:      	lock
     2db:      	incq	(%rax)
     2de:      	movq	%rbx, %rax
     2e1:      	addq	$0x8, %rsp
     2e5:      	popq	%rbx
     2e6:      	popq	%r12
     2e8:      	popq	%r13
     2ea:      	popq	%r14
     2ec:      	popq	%r15
     2ee:      	popq	%rbp
     2ef:      	retq

00000000000002f0 <__do_bytes>:
     2f0:      	pushq	%r15
     2f2:      	pushq	%r14
     2f4:      	pushq	%r12
     2f6:      	pushq	%rbx
     2f7:      	pushq	%rax
     2f8:      	testq	%rcx, %rcx
     2fb:      	js	0x379 <__do_bytes+0x89>
     2fd:      	movq	%rsi, %r14
     300:      	movq	%rdi, %r12
     303:      	cmpq	$0x7fe0, %rcx           # imm = 0x7FE0
     30a:      	movl	$0x7fe0, %ebx           # imm = 0x7FE0
     30f:      	cmovbq	%rcx, %rbx
     313:      	leaq	0x20(%rsi), %rdi
     317:      	movl	$0x4, %eax
     31c:      	movl	%ebx, %esi
     31e:      	callq	*%rax
     320:      	testl	%eax, %eax
     322:      	js	0x39e <__do_bytes+0xae>
     324:      	leal	0x20(%rbx), %r15d
     328:      	movl	%r15d, 0x4(%r14)
     32c:      	movl	$0x0, 0x4(%rsp)
     334:      	movq	(%rip), %rdi            # 0x33b <__do_bytes+0x4b>
     33b:      	leaq	0x4(%rsp), %rsi
     340:      	movl	$0x1, %eax
     345:      	callq	*%rax
     347:      	testq	%rax, %rax
     34a:      	je	0x382 <__do_bytes+0x92>
     34c:      	cmpb	$0x0, 0x28(%rax)
     350:      	je	0x382 <__do_bytes+0x92>
     352:      	movq	(%rip), %rsi            # 0x359 <__do_bytes+0x69>
     359:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
     35e:      	movl	$0x19, %eax
     363:      	movq	%r12, %rdi
     366:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     36b:      	movq	%r14, %rcx
     36e:      	movq	%r15, %r8
     371:      	callq	*%rax
     373:      	testl	%eax, %eax
     375:      	js	0x39e <__do_bytes+0xae>
     377:      	jmp	0x3a1 <__do_bytes+0xb1>
     379:      	movq	$-0x1, %rbx
     380:      	jmp	0x3a1 <__do_bytes+0xb1>
     382:      	movq	(%rip), %rdi            # 0x389 <__do_bytes+0x99>
     389:      	xorl	%ecx, %ecx
     38b:      	movl	$0x82, %eax
     390:      	movq	%r14, %rsi
     393:      	movq	%r15, %rdx
     396:      	xorl	%ecx, %ecx
     398:      	callq	*%rax
     39a:      	testl	%eax, %eax
     39c:      	jns	0x3a1 <__do_bytes+0xb1>
     39e:      	movslq	%eax, %rbx
     3a1:      	movq	%rbx, %rax
     3a4:      	addq	$0x8, %rsp
     3a8:      	popq	%rbx
     3a9:      	popq	%r12
     3ab:      	popq	%r14
     3ad:      	popq	%r15
     3af:      	retq

00000000000003b0 <filter_64ty>:
     3b0:      	pushq	%rax
     3b1:      	movl	0x4(%rdi), %ecx
     3b4:      	xorl	%eax, %eax
     3b6:      	cmpq	$0x20, %rcx
     3ba:      	ja	0x3f5 <filter_64ty+0x45>
     3bc:      	movl	$0x101e, %edx           # imm = 0x101E
     3c1:      	btq	%rcx, %rdx
     3c5:      	jae	0x3ce <filter_64ty+0x1e>
     3c7:      	callq	0x4f0 <filter_64ty_selector_val>
     3cc:      	popq	%rcx
     3cd:      	retq
     3ce:      	movl	$0xc00, %edx            # imm = 0xC00
     3d3:      	btq	%rcx, %rdx
     3d7:      	jb	0x3f0 <filter_64ty+0x40>
     3d9:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
     3e3:      	btq	%rcx, %rdx
     3e7:      	jae	0x3f5 <filter_64ty+0x45>
     3e9:      	callq	0x7b0 <filter_64ty_range>
     3ee:      	popq	%rcx
     3ef:      	retq
     3f0:      	callq	0x730 <filter_64ty_map>
     3f5:      	popq	%rcx
     3f6:      	retq
     3f7:      	nopw	(%rax,%rax)

0000000000000400 <filter_32ty>:
     400:      	pushq	%rax
     401:      	movl	0x4(%rdi), %ecx
     404:      	xorl	%eax, %eax
     406:      	cmpq	$0x20, %rcx
     40a:      	ja	0x445 <filter_32ty+0x45>
     40c:      	movl	$0x101e, %edx           # imm = 0x101E
     411:      	btq	%rcx, %rdx
     415:      	jae	0x41e <filter_32ty+0x1e>
     417:      	callq	0x990 <filter_32ty_selector_val>
     41c:      	popq	%rcx
     41d:      	retq
     41e:      	movl	$0xc00, %edx            # imm = 0xC00
     423:      	btq	%rcx, %rdx
     427:      	jb	0x440 <filter_32ty+0x40>
     429:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
     433:      	btq	%rcx, %rdx
     437:      	jae	0x445 <filter_32ty+0x45>
     439:      	callq	0xc40 <filter_32ty_range>
     43e:      	popq	%rcx
     43f:      	retq
     440:      	callq	0xbb0 <filter_32ty_map>
     445:      	popq	%rcx
     446:      	retq
     447:      	nopw	(%rax,%rax)

0000000000000450 <filter_16ty>:
     450:      	pushq	%rax
     451:      	movl	0x4(%rdi), %ecx
     454:      	xorl	%eax, %eax
     456:      	cmpq	$0x20, %rcx
     45a:      	ja	0x495 <filter_16ty+0x45>
     45c:      	movl	$0x101e, %edx           # imm = 0x101E
     461:      	btq	%rcx, %rdx
     465:      	jae	0x46e <filter_16ty+0x1e>
     467:      	callq	0xe00 <filter_16ty_selector_val>
     46c:      	popq	%rcx
     46d:      	retq
     46e:      	movl	$0xc00, %edx            # imm = 0xC00
     473:      	btq	%rcx, %rdx
     477:      	jb	0x490 <filter_16ty+0x40>
     479:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
     483:      	btq	%rcx, %rdx
     487:      	jae	0x495 <filter_16ty+0x45>
     489:      	callq	0x10b0 <filter_16ty_range>
     48e:      	popq	%rcx
     48f:      	retq
     490:      	callq	0x1020 <filter_16ty_map>
     495:      	popq	%rcx
     496:      	retq
     497:      	nopw	(%rax,%rax)

00000000000004a0 <filter_8ty>:
     4a0:      	pushq	%rax
     4a1:      	movl	0x4(%rdi), %ecx
     4a4:      	xorl	%eax, %eax
     4a6:      	cmpq	$0x20, %rcx
     4aa:      	ja	0x4e5 <filter_8ty+0x45>
     4ac:      	movl	$0x101e, %edx           # imm = 0x101E
     4b1:      	btq	%rcx, %rdx
     4b5:      	jae	0x4be <filter_8ty+0x1e>
     4b7:      	callq	0x1270 <filter_8ty_selector_val>
     4bc:      	popq	%rcx
     4bd:      	retq
     4be:      	movl	$0xc00, %edx            # imm = 0xC00
     4c3:      	btq	%rcx, %rdx
     4c7:      	jb	0x4e0 <filter_8ty+0x40>
     4c9:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
     4d3:      	btq	%rcx, %rdx
     4d7:      	jae	0x4e5 <filter_8ty+0x45>
     4d9:      	callq	0x1520 <filter_8ty_range>
     4de:      	popq	%rcx
     4df:      	retq
     4e0:      	callq	0x1490 <filter_8ty_map>
     4e5:      	popq	%rcx
     4e6:      	retq
     4e7:      	nopw	(%rax,%rax)

00000000000004f0 <filter_64ty_selector_val>:
     4f0:      	movl	0x4(%rdi), %ecx
     4f3:      	movl	$0x1, %eax
     4f8:      	cmpq	$0x25, %rcx
     4fc:      	ja	0x574 <filter_64ty_selector_val+0x84>
     4fe:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     508:      	btq	%rcx, %rdx
     50c:      	jae	0x50f <filter_64ty_selector_val+0x1f>
     50e:      	retq
     50f:      	movl	$0x18, %edx
     514:      	btq	%rcx, %rdx
     518:      	jae	0x530 <filter_64ty_selector_val+0x40>
     51a:      	movq	(%rsi), %rdx
     51d:      	cmpq	0x10(%rdi), %rdx
     521:      	jne	0x652 <filter_64ty_selector_val+0x162>
     527:      	xorl	%eax, %eax
     529:      	cmpl	$0x3, %ecx
     52c:      	sete	%al
     52f:      	retq
     530:      	cmpq	$0xc, %rcx
     534:      	jne	0x574 <filter_64ty_selector_val+0x84>
     536:      	movq	(%rsi), %rcx
     539:      	testq	%rcx, 0x10(%rdi)
     53d:      	jne	0x50e <filter_64ty_selector_val+0x1e>
     53f:      	movl	0x8(%rdi), %edx
     542:      	cmpl	$0x11, %edx
     545:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     54b:      	testq	%rcx, 0x18(%rdi)
     54f:      	jne	0x50e <filter_64ty_selector_val+0x1e>
     551:      	cmpl	$0x19, %edx
     554:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     55a:      	testq	%rcx, 0x20(%rdi)
     55e:      	jne	0x50e <filter_64ty_selector_val+0x1e>
     560:      	cmpl	$0x21, %edx
     563:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     569:      	testq	%rcx, 0x28(%rdi)
     56d:      	jne	0x50e <filter_64ty_selector_val+0x1e>
     56f:      	jmp	0x71f <filter_64ty_selector_val+0x22f>
     574:      	cmpl	$0x1, %ecx
     577:      	je	0x5ea <filter_64ty_selector_val+0xfa>
     579:      	cmpl	$0x2, %ecx
     57c:      	jne	0x71f <filter_64ty_selector_val+0x22f>
     582:      	movl	0xc(%rdi), %ecx
     585:      	cmpl	$0xc, %ecx
     588:      	ja	0x6e2 <filter_64ty_selector_val+0x1f2>
     58e:      	movl	$0x1402, %edx           # imm = 0x1402
     593:      	btl	%ecx, %edx
     596:      	jae	0x6e2 <filter_64ty_selector_val+0x1f2>
     59c:      	movq	(%rsi), %rcx
     59f:      	cmpq	0x10(%rdi), %rcx
     5a3:      	jl	0x50e <filter_64ty_selector_val+0x1e>
     5a9:      	movl	0x8(%rdi), %edx
     5ac:      	cmpl	$0x11, %edx
     5af:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     5b5:      	cmpq	0x18(%rdi), %rcx
     5b9:      	jl	0x50e <filter_64ty_selector_val+0x1e>
     5bf:      	cmpl	$0x19, %edx
     5c2:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     5c8:      	cmpq	0x20(%rdi), %rcx
     5cc:      	jl	0x50e <filter_64ty_selector_val+0x1e>
     5d2:      	cmpl	$0x21, %edx
     5d5:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     5db:      	cmpq	0x28(%rdi), %rcx
     5df:      	jl	0x50e <filter_64ty_selector_val+0x1e>
     5e5:      	jmp	0x71f <filter_64ty_selector_val+0x22f>
     5ea:      	movl	0xc(%rdi), %ecx
     5ed:      	cmpl	$0xc, %ecx
     5f0:      	ja	0x6a3 <filter_64ty_selector_val+0x1b3>
     5f6:      	movl	$0x1402, %edx           # imm = 0x1402
     5fb:      	btl	%ecx, %edx
     5fe:      	jae	0x6a3 <filter_64ty_selector_val+0x1b3>
     604:      	movq	(%rsi), %rcx
     607:      	cmpq	0x10(%rdi), %rcx
     60b:      	jg	0x50e <filter_64ty_selector_val+0x1e>
     611:      	movl	0x8(%rdi), %edx
     614:      	cmpl	$0x11, %edx
     617:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     61d:      	cmpq	0x18(%rdi), %rcx
     621:      	jg	0x50e <filter_64ty_selector_val+0x1e>
     627:      	cmpl	$0x19, %edx
     62a:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     630:      	cmpq	0x20(%rdi), %rcx
     634:      	jg	0x50e <filter_64ty_selector_val+0x1e>
     63a:      	cmpl	$0x21, %edx
     63d:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     643:      	cmpq	0x28(%rdi), %rcx
     647:      	jg	0x50e <filter_64ty_selector_val+0x1e>
     64d:      	jmp	0x71f <filter_64ty_selector_val+0x22f>
     652:      	movl	0x8(%rdi), %esi
     655:      	cmpl	$0x11, %esi
     658:      	jb	0x682 <filter_64ty_selector_val+0x192>
     65a:      	cmpq	0x18(%rdi), %rdx
     65e:      	je	0x527 <filter_64ty_selector_val+0x37>
     664:      	cmpl	$0x19, %esi
     667:      	jb	0x682 <filter_64ty_selector_val+0x192>
     669:      	cmpq	0x20(%rdi), %rdx
     66d:      	je	0x527 <filter_64ty_selector_val+0x37>
     673:      	cmpl	$0x21, %esi
     676:      	jb	0x682 <filter_64ty_selector_val+0x192>
     678:      	cmpq	0x28(%rdi), %rdx
     67c:      	je	0x527 <filter_64ty_selector_val+0x37>
     682:      	cmpl	$0x25, %ecx
     685:      	ja	0x71f <filter_64ty_selector_val+0x22f>
     68b:      	movl	%ecx, %ecx
     68d:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
     697:      	btq	%rcx, %rdx
     69b:      	jb	0x50e <filter_64ty_selector_val+0x1e>
     6a1:      	jmp	0x71f <filter_64ty_selector_val+0x22f>
     6a3:      	movq	(%rsi), %rcx
     6a6:      	cmpq	0x10(%rdi), %rcx
     6aa:      	ja	0x50e <filter_64ty_selector_val+0x1e>
     6b0:      	movl	0x8(%rdi), %edx
     6b3:      	cmpl	$0x11, %edx
     6b6:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     6b8:      	cmpq	0x18(%rdi), %rcx
     6bc:      	ja	0x50e <filter_64ty_selector_val+0x1e>
     6c2:      	cmpl	$0x19, %edx
     6c5:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     6c7:      	cmpq	0x20(%rdi), %rcx
     6cb:      	ja	0x50e <filter_64ty_selector_val+0x1e>
     6d1:      	cmpl	$0x21, %edx
     6d4:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     6d6:      	cmpq	0x28(%rdi), %rcx
     6da:      	ja	0x50e <filter_64ty_selector_val+0x1e>
     6e0:      	jmp	0x71f <filter_64ty_selector_val+0x22f>
     6e2:      	movq	(%rsi), %rcx
     6e5:      	cmpq	0x10(%rdi), %rcx
     6e9:      	jb	0x50e <filter_64ty_selector_val+0x1e>
     6ef:      	movl	0x8(%rdi), %edx
     6f2:      	cmpl	$0x11, %edx
     6f5:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     6f7:      	cmpq	0x18(%rdi), %rcx
     6fb:      	jb	0x50e <filter_64ty_selector_val+0x1e>
     701:      	cmpl	$0x19, %edx
     704:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     706:      	cmpq	0x20(%rdi), %rcx
     70a:      	jb	0x50e <filter_64ty_selector_val+0x1e>
     710:      	cmpl	$0x21, %edx
     713:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     715:      	cmpq	0x28(%rdi), %rcx
     719:      	jb	0x50e <filter_64ty_selector_val+0x1e>
     71f:      	xorl	%eax, %eax
     721:      	retq
     722:      	nopw	%cs:(%rax,%rax)

0000000000000730 <filter_64ty_map>:
     730:      	pushq	%r14
     732:      	pushq	%rbx
     733:      	subq	$0x18, %rsp
     737:      	movq	%rsi, %r14
     73a:      	movq	%rdi, %rbx
     73d:      	movzbl	0x10(%rdi), %eax
     741:      	movl	%eax, 0xc(%rsp)
     745:      	movq	(%rip), %rdi            # 0x74c <filter_64ty_map+0x1c>
     74c:      	leaq	0xc(%rsp), %rsi
     751:      	movl	$0x1, %eax
     756:      	callq	*%rax
     758:      	testq	%rax, %rax
     75b:      	je	0x789 <filter_64ty_map+0x59>
     75d:      	movq	%rax, %rdi
     760:      	movq	(%r14), %rax
     763:      	movq	%rax, 0x10(%rsp)
     768:      	leaq	0x10(%rsp), %rsi
     76d:      	movl	$0x1, %eax
     772:      	callq	*%rax
     774:      	movl	0x4(%rbx), %ecx
     777:      	cmpl	$0xb, %ecx
     77a:      	je	0x793 <filter_64ty_map+0x63>
     77c:      	cmpl	$0xa, %ecx
     77f:      	jne	0x79b <filter_64ty_map+0x6b>
     781:      	testq	%rax, %rax
     784:      	setne	%al
     787:      	jmp	0x79d <filter_64ty_map+0x6d>
     789:      	xorl	%eax, %eax
     78b:      	addq	$0x18, %rsp
     78f:      	popq	%rbx
     790:      	popq	%r14
     792:      	retq
     793:      	testq	%rax, %rax
     796:      	sete	%al
     799:      	jmp	0x79d <filter_64ty_map+0x6d>
     79b:      	xorl	%eax, %eax
     79d:      	movzbl	%al, %eax
     7a0:      	addq	$0x18, %rsp
     7a4:      	popq	%rbx
     7a5:      	popq	%r14
     7a7:      	retq
     7a8:      	nopl	(%rax,%rax)

00000000000007b0 <filter_64ty_range>:
     7b0:      	movl	0x4(%rdi), %ecx
     7b3:      	movl	0xc(%rdi), %eax
     7b6:      	cmpl	$0xc, %eax
     7b9:      	ja	0x8b0 <filter_64ty_range+0x100>
     7bf:      	movl	$0x1402, %edx           # imm = 0x1402
     7c4:      	btl	%eax, %edx
     7c7:      	jae	0x8b0 <filter_64ty_range+0x100>
     7cd:      	movq	(%rsi), %rsi
     7d0:      	cmpl	$0x1f, %ecx
     7d3:      	jne	0x843 <filter_64ty_range+0x93>
     7d5:      	movl	$0x1, %eax
     7da:      	cmpq	%rsi, 0x10(%rdi)
     7de:      	jg	0x7ea <filter_64ty_range+0x3a>
     7e0:      	cmpq	0x18(%rdi), %rsi
     7e4:      	jle	0x8c9 <filter_64ty_range+0x119>
     7ea:      	movl	0x8(%rdi), %edx
     7ed:      	cmpl	$0x19, %edx
     7f0:      	jb	0x977 <filter_64ty_range+0x1c7>
     7f6:      	cmpq	%rsi, 0x20(%rdi)
     7fa:      	jg	0x806 <filter_64ty_range+0x56>
     7fc:      	cmpq	0x28(%rdi), %rsi
     800:      	jle	0x8c9 <filter_64ty_range+0x119>
     806:      	cmpl	$0x29, %edx
     809:      	jb	0x977 <filter_64ty_range+0x1c7>
     80f:      	cmpq	%rsi, 0x30(%rdi)
     813:      	jg	0x81f <filter_64ty_range+0x6f>
     815:      	cmpq	0x38(%rdi), %rsi
     819:      	jle	0x8c9 <filter_64ty_range+0x119>
     81f:      	cmpl	$0x39, %edx
     822:      	jb	0x977 <filter_64ty_range+0x1c7>
     828:      	xorl	%edx, %edx
     82a:      	cmpq	%rsi, 0x40(%rdi)
     82e:      	jg	0x979 <filter_64ty_range+0x1c9>
     834:      	cmpq	0x48(%rdi), %rsi
     838:      	jle	0x8c9 <filter_64ty_range+0x119>
     83e:      	jmp	0x979 <filter_64ty_range+0x1c9>
     843:      	movl	0x8(%rdi), %eax
     846:      	cmpq	%rsi, 0x10(%rdi)
     84a:      	setle	%r8b
     84e:      	cmpq	0x18(%rdi), %rsi
     852:      	setle	%dl
     855:      	andb	%r8b, %dl
     858:      	cmpl	$0x19, %eax
     85b:      	jb	0x979 <filter_64ty_range+0x1c9>
     861:      	cmpq	%rsi, 0x20(%rdi)
     865:      	setle	%r8b
     869:      	cmpq	0x28(%rdi), %rsi
     86d:      	setle	%r9b
     871:      	andb	%r8b, %r9b
     874:      	orb	%r9b, %dl
     877:      	cmpl	$0x29, %eax
     87a:      	jb	0x979 <filter_64ty_range+0x1c9>
     880:      	cmpq	%rsi, 0x30(%rdi)
     884:      	setle	%r8b
     888:      	cmpq	0x38(%rdi), %rsi
     88c:      	setle	%r9b
     890:      	andb	%r8b, %r9b
     893:      	orb	%r9b, %dl
     896:      	cmpl	$0x39, %eax
     899:      	jb	0x979 <filter_64ty_range+0x1c9>
     89f:      	cmpq	%rsi, 0x40(%rdi)
     8a3:      	setle	%al
     8a6:      	cmpq	0x48(%rdi), %rsi
     8aa:      	setle	%sil
     8ae:      	jmp	0x92d <filter_64ty_range+0x17d>
     8b0:      	movq	(%rsi), %rsi
     8b3:      	cmpl	$0x1f, %ecx
     8b6:      	jne	0x8ca <filter_64ty_range+0x11a>
     8b8:      	movl	$0x1, %eax
     8bd:      	cmpq	%rsi, 0x10(%rdi)
     8c1:      	ja	0x935 <filter_64ty_range+0x185>
     8c3:      	cmpq	0x18(%rdi), %rsi
     8c7:      	ja	0x935 <filter_64ty_range+0x185>
     8c9:      	retq
     8ca:      	movl	0x8(%rdi), %eax
     8cd:      	cmpq	%rsi, 0x10(%rdi)
     8d1:      	setbe	%r8b
     8d5:      	cmpq	0x18(%rdi), %rsi
     8d9:      	setbe	%dl
     8dc:      	andb	%r8b, %dl
     8df:      	cmpl	$0x19, %eax
     8e2:      	jb	0x979 <filter_64ty_range+0x1c9>
     8e8:      	cmpq	%rsi, 0x20(%rdi)
     8ec:      	setbe	%r8b
     8f0:      	cmpq	0x28(%rdi), %rsi
     8f4:      	setbe	%r9b
     8f8:      	andb	%r8b, %r9b
     8fb:      	orb	%r9b, %dl
     8fe:      	cmpl	$0x29, %eax
     901:      	jb	0x979 <filter_64ty_range+0x1c9>
     903:      	cmpq	%rsi, 0x30(%rdi)
     907:      	setbe	%r8b
     90b:      	cmpq	0x38(%rdi), %rsi
     90f:      	setbe	%r9b
     913:      	andb	%r8b, %r9b
     916:      	orb	%r9b, %dl
     919:      	cmpl	$0x39, %eax
     91c:      	jb	0x979 <filter_64ty_range+0x1c9>
     91e:      	cmpq	%rsi, 0x40(%rdi)
     922:      	setbe	%al
     925:      	cmpq	0x48(%rdi), %rsi
     929:      	setbe	%sil
     92d:      	andb	%al, %sil
     930:      	orb	%sil, %dl
     933:      	jmp	0x979 <filter_64ty_range+0x1c9>
     935:      	movl	0x8(%rdi), %edx
     938:      	cmpl	$0x19, %edx
     93b:      	jb	0x977 <filter_64ty_range+0x1c7>
     93d:      	cmpq	%rsi, 0x20(%rdi)
     941:      	ja	0x949 <filter_64ty_range+0x199>
     943:      	cmpq	0x28(%rdi), %rsi
     947:      	jbe	0x8c9 <filter_64ty_range+0x119>
     949:      	cmpl	$0x29, %edx
     94c:      	jb	0x977 <filter_64ty_range+0x1c7>
     94e:      	cmpq	%rsi, 0x30(%rdi)
     952:      	ja	0x95e <filter_64ty_range+0x1ae>
     954:      	cmpq	0x38(%rdi), %rsi
     958:      	jbe	0x8c9 <filter_64ty_range+0x119>
     95e:      	cmpl	$0x39, %edx
     961:      	jb	0x977 <filter_64ty_range+0x1c7>
     963:      	xorl	%edx, %edx
     965:      	cmpq	%rsi, 0x40(%rdi)
     969:      	ja	0x979 <filter_64ty_range+0x1c9>
     96b:      	cmpq	0x48(%rdi), %rsi
     96f:      	jbe	0x8c9 <filter_64ty_range+0x119>
     975:      	jmp	0x979 <filter_64ty_range+0x1c9>
     977:      	xorl	%edx, %edx
     979:      	cmpl	$0x20, %ecx
     97c:      	sete	%al
     97f:      	xorb	$0x1, %dl
     982:      	andb	%al, %dl
     984:      	movzbl	%dl, %eax
     987:      	retq
     988:      	nopl	(%rax,%rax)

0000000000000990 <filter_32ty_selector_val>:
     990:      	movl	0x4(%rdi), %ecx
     993:      	movl	$0x1, %eax
     998:      	cmpq	$0x25, %rcx
     99c:      	ja	0xa0d <filter_32ty_selector_val+0x7d>
     99e:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     9a8:      	btq	%rcx, %rdx
     9ac:      	jae	0x9af <filter_32ty_selector_val+0x1f>
     9ae:      	retq
     9af:      	movl	$0x18, %edx
     9b4:      	btq	%rcx, %rdx
     9b8:      	jae	0x9ce <filter_32ty_selector_val+0x3e>
     9ba:      	movl	(%rsi), %edx
     9bc:      	cmpl	0x10(%rdi), %edx
     9bf:      	jne	0xae1 <filter_32ty_selector_val+0x151>
     9c5:      	xorl	%eax, %eax
     9c7:      	cmpl	$0x3, %ecx
     9ca:      	sete	%al
     9cd:      	retq
     9ce:      	cmpq	$0xc, %rcx
     9d2:      	jne	0xa0d <filter_32ty_selector_val+0x7d>
     9d4:      	movl	(%rsi), %ecx
     9d6:      	testl	%ecx, 0x10(%rdi)
     9d9:      	jne	0x9ae <filter_32ty_selector_val+0x1e>
     9db:      	movl	0x8(%rdi), %edx
     9de:      	cmpl	$0xd, %edx
     9e1:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     9e7:      	testl	%ecx, 0x14(%rdi)
     9ea:      	jne	0x9ae <filter_32ty_selector_val+0x1e>
     9ec:      	cmpl	$0x11, %edx
     9ef:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     9f5:      	testl	%ecx, 0x18(%rdi)
     9f8:      	jne	0x9ae <filter_32ty_selector_val+0x1e>
     9fa:      	cmpl	$0x15, %edx
     9fd:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     a03:      	testl	%ecx, 0x1c(%rdi)
     a06:      	jne	0x9ae <filter_32ty_selector_val+0x1e>
     a08:      	jmp	0xba1 <filter_32ty_selector_val+0x211>
     a0d:      	cmpl	$0x1, %ecx
     a10:      	je	0xa7e <filter_32ty_selector_val+0xee>
     a12:      	cmpl	$0x2, %ecx
     a15:      	jne	0xba1 <filter_32ty_selector_val+0x211>
     a1b:      	movl	0xc(%rdi), %ecx
     a1e:      	cmpl	$0xc, %ecx
     a21:      	ja	0xb69 <filter_32ty_selector_val+0x1d9>
     a27:      	movl	$0x1402, %edx           # imm = 0x1402
     a2c:      	btl	%ecx, %edx
     a2f:      	jae	0xb69 <filter_32ty_selector_val+0x1d9>
     a35:      	movl	(%rsi), %ecx
     a37:      	cmpl	0x10(%rdi), %ecx
     a3a:      	jl	0x9ae <filter_32ty_selector_val+0x1e>
     a40:      	movl	0x8(%rdi), %edx
     a43:      	cmpl	$0xd, %edx
     a46:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     a4c:      	cmpl	0x14(%rdi), %ecx
     a4f:      	jl	0x9ae <filter_32ty_selector_val+0x1e>
     a55:      	cmpl	$0x11, %edx
     a58:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     a5e:      	cmpl	0x18(%rdi), %ecx
     a61:      	jl	0x9ae <filter_32ty_selector_val+0x1e>
     a67:      	cmpl	$0x15, %edx
     a6a:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     a70:      	cmpl	0x1c(%rdi), %ecx
     a73:      	jl	0x9ae <filter_32ty_selector_val+0x1e>
     a79:      	jmp	0xba1 <filter_32ty_selector_val+0x211>
     a7e:      	movl	0xc(%rdi), %ecx
     a81:      	cmpl	$0xc, %ecx
     a84:      	ja	0xb2f <filter_32ty_selector_val+0x19f>
     a8a:      	movl	$0x1402, %edx           # imm = 0x1402
     a8f:      	btl	%ecx, %edx
     a92:      	jae	0xb2f <filter_32ty_selector_val+0x19f>
     a98:      	movl	(%rsi), %ecx
     a9a:      	cmpl	0x10(%rdi), %ecx
     a9d:      	jg	0x9ae <filter_32ty_selector_val+0x1e>
     aa3:      	movl	0x8(%rdi), %edx
     aa6:      	cmpl	$0xd, %edx
     aa9:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     aaf:      	cmpl	0x14(%rdi), %ecx
     ab2:      	jg	0x9ae <filter_32ty_selector_val+0x1e>
     ab8:      	cmpl	$0x11, %edx
     abb:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     ac1:      	cmpl	0x18(%rdi), %ecx
     ac4:      	jg	0x9ae <filter_32ty_selector_val+0x1e>
     aca:      	cmpl	$0x15, %edx
     acd:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     ad3:      	cmpl	0x1c(%rdi), %ecx
     ad6:      	jg	0x9ae <filter_32ty_selector_val+0x1e>
     adc:      	jmp	0xba1 <filter_32ty_selector_val+0x211>
     ae1:      	movl	0x8(%rdi), %esi
     ae4:      	cmpl	$0xd, %esi
     ae7:      	jb	0xb0e <filter_32ty_selector_val+0x17e>
     ae9:      	cmpl	0x14(%rdi), %edx
     aec:      	je	0x9c5 <filter_32ty_selector_val+0x35>
     af2:      	cmpl	$0x11, %esi
     af5:      	jb	0xb0e <filter_32ty_selector_val+0x17e>
     af7:      	cmpl	0x18(%rdi), %edx
     afa:      	je	0x9c5 <filter_32ty_selector_val+0x35>
     b00:      	cmpl	$0x15, %esi
     b03:      	jb	0xb0e <filter_32ty_selector_val+0x17e>
     b05:      	cmpl	0x1c(%rdi), %edx
     b08:      	je	0x9c5 <filter_32ty_selector_val+0x35>
     b0e:      	cmpl	$0x25, %ecx
     b11:      	ja	0xba1 <filter_32ty_selector_val+0x211>
     b17:      	movl	%ecx, %ecx
     b19:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
     b23:      	btq	%rcx, %rdx
     b27:      	jb	0x9ae <filter_32ty_selector_val+0x1e>
     b2d:      	jmp	0xba1 <filter_32ty_selector_val+0x211>
     b2f:      	movl	(%rsi), %ecx
     b31:      	cmpl	0x10(%rdi), %ecx
     b34:      	ja	0x9ae <filter_32ty_selector_val+0x1e>
     b3a:      	movl	0x8(%rdi), %edx
     b3d:      	cmpl	$0xd, %edx
     b40:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     b42:      	cmpl	0x14(%rdi), %ecx
     b45:      	ja	0x9ae <filter_32ty_selector_val+0x1e>
     b4b:      	cmpl	$0x11, %edx
     b4e:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     b50:      	cmpl	0x18(%rdi), %ecx
     b53:      	ja	0x9ae <filter_32ty_selector_val+0x1e>
     b59:      	cmpl	$0x15, %edx
     b5c:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     b5e:      	cmpl	0x1c(%rdi), %ecx
     b61:      	ja	0x9ae <filter_32ty_selector_val+0x1e>
     b67:      	jmp	0xba1 <filter_32ty_selector_val+0x211>
     b69:      	movl	(%rsi), %ecx
     b6b:      	cmpl	0x10(%rdi), %ecx
     b6e:      	jb	0x9ae <filter_32ty_selector_val+0x1e>
     b74:      	movl	0x8(%rdi), %edx
     b77:      	cmpl	$0xd, %edx
     b7a:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     b7c:      	cmpl	0x14(%rdi), %ecx
     b7f:      	jb	0x9ae <filter_32ty_selector_val+0x1e>
     b85:      	cmpl	$0x11, %edx
     b88:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     b8a:      	cmpl	0x18(%rdi), %ecx
     b8d:      	jb	0x9ae <filter_32ty_selector_val+0x1e>
     b93:      	cmpl	$0x15, %edx
     b96:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     b98:      	cmpl	0x1c(%rdi), %ecx
     b9b:      	jb	0x9ae <filter_32ty_selector_val+0x1e>
     ba1:      	xorl	%eax, %eax
     ba3:      	retq
     ba4:      	nopw	%cs:(%rax,%rax)

0000000000000bb0 <filter_32ty_map>:
     bb0:      	pushq	%r14
     bb2:      	pushq	%rbx
     bb3:      	subq	$0x18, %rsp
     bb7:      	movq	%rsi, %r14
     bba:      	movq	%rdi, %rbx
     bbd:      	movzbl	0x10(%rdi), %eax
     bc1:      	movl	%eax, 0xc(%rsp)
     bc5:      	movq	(%rip), %rdi            # 0xbcc <filter_32ty_map+0x1c>
     bcc:      	leaq	0xc(%rsp), %rsi
     bd1:      	movl	$0x1, %eax
     bd6:      	callq	*%rax
     bd8:      	testq	%rax, %rax
     bdb:      	je	0xc10 <filter_32ty_map+0x60>
     bdd:      	movq	%rax, %rdi
     be0:      	movl	(%r14), %eax
     be3:      	movq	%rax, 0x10(%rsp)
     be8:      	leaq	0x10(%rsp), %rsi
     bed:      	movl	$0x1, %eax
     bf2:      	callq	*%rax
     bf4:      	movl	0x4(%rbx), %edx
     bf7:      	xorl	%ecx, %ecx
     bf9:      	cmpl	$0x1d, %edx
     bfc:      	ja	0xc2a <filter_32ty_map+0x7a>
     bfe:      	movl	$0x30038400, %esi       # imm = 0x30038400
     c03:      	btl	%edx, %esi
     c06:      	jae	0xc1a <filter_32ty_map+0x6a>
     c08:      	testq	%rax, %rax
     c0b:      	setne	%cl
     c0e:      	jmp	0xc2a <filter_32ty_map+0x7a>
     c10:      	xorl	%eax, %eax
     c12:      	addq	$0x18, %rsp
     c16:      	popq	%rbx
     c17:      	popq	%r14
     c19:      	retq
     c1a:      	movl	$0xc0800, %esi          # imm = 0xC0800
     c1f:      	btl	%edx, %esi
     c22:      	jae	0xc2a <filter_32ty_map+0x7a>
     c24:      	testq	%rax, %rax
     c27:      	sete	%cl
     c2a:      	movzbl	%cl, %eax
     c2d:      	addq	$0x18, %rsp
     c31:      	popq	%rbx
     c32:      	popq	%r14
     c34:      	retq
     c35:      	nopw	%cs:(%rax,%rax)

0000000000000c40 <filter_32ty_range>:
     c40:      	movl	0x4(%rdi), %ecx
     c43:      	movl	0xc(%rdi), %eax
     c46:      	cmpl	$0xc, %eax
     c49:      	ja	0xd2f <filter_32ty_range+0xef>
     c4f:      	movl	$0x1402, %edx           # imm = 0x1402
     c54:      	btl	%eax, %edx
     c57:      	jae	0xd2f <filter_32ty_range+0xef>
     c5d:      	movl	(%rsi), %esi
     c5f:      	cmpl	$0x1f, %ecx
     c62:      	jne	0xcca <filter_32ty_range+0x8a>
     c64:      	movl	$0x1, %eax
     c69:      	cmpl	%esi, 0x10(%rdi)
     c6c:      	jg	0xc77 <filter_32ty_range+0x37>
     c6e:      	cmpl	0x14(%rdi), %esi
     c71:      	jle	0xd45 <filter_32ty_range+0x105>
     c77:      	movl	0x8(%rdi), %edx
     c7a:      	cmpl	$0x11, %edx
     c7d:      	jb	0xde5 <filter_32ty_range+0x1a5>
     c83:      	cmpl	%esi, 0x18(%rdi)
     c86:      	jg	0xc91 <filter_32ty_range+0x51>
     c88:      	cmpl	0x1c(%rdi), %esi
     c8b:      	jle	0xd45 <filter_32ty_range+0x105>
     c91:      	cmpl	$0x19, %edx
     c94:      	jb	0xde5 <filter_32ty_range+0x1a5>
     c9a:      	cmpl	%esi, 0x20(%rdi)
     c9d:      	jg	0xca8 <filter_32ty_range+0x68>
     c9f:      	cmpl	0x24(%rdi), %esi
     ca2:      	jle	0xd45 <filter_32ty_range+0x105>
     ca8:      	cmpl	$0x21, %edx
     cab:      	jb	0xde5 <filter_32ty_range+0x1a5>
     cb1:      	xorl	%edx, %edx
     cb3:      	cmpl	%esi, 0x28(%rdi)
     cb6:      	jg	0xde7 <filter_32ty_range+0x1a7>
     cbc:      	cmpl	0x2c(%rdi), %esi
     cbf:      	jle	0xd45 <filter_32ty_range+0x105>
     cc5:      	jmp	0xde7 <filter_32ty_range+0x1a7>
     cca:      	movl	0x8(%rdi), %eax
     ccd:      	cmpl	%esi, 0x10(%rdi)
     cd0:      	setle	%r8b
     cd4:      	cmpl	0x14(%rdi), %esi
     cd7:      	setle	%dl
     cda:      	andb	%r8b, %dl
     cdd:      	cmpl	$0x11, %eax
     ce0:      	jb	0xde7 <filter_32ty_range+0x1a7>
     ce6:      	cmpl	%esi, 0x18(%rdi)
     ce9:      	setle	%r8b
     ced:      	cmpl	0x1c(%rdi), %esi
     cf0:      	setle	%r9b
     cf4:      	andb	%r8b, %r9b
     cf7:      	orb	%r9b, %dl
     cfa:      	cmpl	$0x19, %eax
     cfd:      	jb	0xde7 <filter_32ty_range+0x1a7>
     d03:      	cmpl	%esi, 0x20(%rdi)
     d06:      	setle	%r8b
     d0a:      	cmpl	0x24(%rdi), %esi
     d0d:      	setle	%r9b
     d11:      	andb	%r8b, %r9b
     d14:      	orb	%r9b, %dl
     d17:      	cmpl	$0x21, %eax
     d1a:      	jb	0xde7 <filter_32ty_range+0x1a7>
     d20:      	cmpl	%esi, 0x28(%rdi)
     d23:      	setle	%al
     d26:      	cmpl	0x2c(%rdi), %esi
     d29:      	setle	%sil
     d2d:      	jmp	0xda1 <filter_32ty_range+0x161>
     d2f:      	movl	(%rsi), %esi
     d31:      	cmpl	$0x1f, %ecx
     d34:      	jne	0xd46 <filter_32ty_range+0x106>
     d36:      	movl	$0x1, %eax
     d3b:      	cmpl	%esi, 0x10(%rdi)
     d3e:      	ja	0xda9 <filter_32ty_range+0x169>
     d40:      	cmpl	0x14(%rdi), %esi
     d43:      	ja	0xda9 <filter_32ty_range+0x169>
     d45:      	retq
     d46:      	movl	0x8(%rdi), %eax
     d49:      	cmpl	%esi, 0x10(%rdi)
     d4c:      	setbe	%r8b
     d50:      	cmpl	0x14(%rdi), %esi
     d53:      	setbe	%dl
     d56:      	andb	%r8b, %dl
     d59:      	cmpl	$0x11, %eax
     d5c:      	jb	0xde7 <filter_32ty_range+0x1a7>
     d62:      	cmpl	%esi, 0x18(%rdi)
     d65:      	setbe	%r8b
     d69:      	cmpl	0x1c(%rdi), %esi
     d6c:      	setbe	%r9b
     d70:      	andb	%r8b, %r9b
     d73:      	orb	%r9b, %dl
     d76:      	cmpl	$0x19, %eax
     d79:      	jb	0xde7 <filter_32ty_range+0x1a7>
     d7b:      	cmpl	%esi, 0x20(%rdi)
     d7e:      	setbe	%r8b
     d82:      	cmpl	0x24(%rdi), %esi
     d85:      	setbe	%r9b
     d89:      	andb	%r8b, %r9b
     d8c:      	orb	%r9b, %dl
     d8f:      	cmpl	$0x21, %eax
     d92:      	jb	0xde7 <filter_32ty_range+0x1a7>
     d94:      	cmpl	%esi, 0x28(%rdi)
     d97:      	setbe	%al
     d9a:      	cmpl	0x2c(%rdi), %esi
     d9d:      	setbe	%sil
     da1:      	andb	%al, %sil
     da4:      	orb	%sil, %dl
     da7:      	jmp	0xde7 <filter_32ty_range+0x1a7>
     da9:      	movl	0x8(%rdi), %edx
     dac:      	cmpl	$0x11, %edx
     daf:      	jb	0xde5 <filter_32ty_range+0x1a5>
     db1:      	cmpl	%esi, 0x18(%rdi)
     db4:      	ja	0xdbb <filter_32ty_range+0x17b>
     db6:      	cmpl	0x1c(%rdi), %esi
     db9:      	jbe	0xd45 <filter_32ty_range+0x105>
     dbb:      	cmpl	$0x19, %edx
     dbe:      	jb	0xde5 <filter_32ty_range+0x1a5>
     dc0:      	cmpl	%esi, 0x20(%rdi)
     dc3:      	ja	0xdce <filter_32ty_range+0x18e>
     dc5:      	cmpl	0x24(%rdi), %esi
     dc8:      	jbe	0xd45 <filter_32ty_range+0x105>
     dce:      	cmpl	$0x21, %edx
     dd1:      	jb	0xde5 <filter_32ty_range+0x1a5>
     dd3:      	xorl	%edx, %edx
     dd5:      	cmpl	%esi, 0x28(%rdi)
     dd8:      	ja	0xde7 <filter_32ty_range+0x1a7>
     dda:      	cmpl	0x2c(%rdi), %esi
     ddd:      	jbe	0xd45 <filter_32ty_range+0x105>
     de3:      	jmp	0xde7 <filter_32ty_range+0x1a7>
     de5:      	xorl	%edx, %edx
     de7:      	cmpl	$0x20, %ecx
     dea:      	sete	%al
     ded:      	xorb	$0x1, %dl
     df0:      	andb	%al, %dl
     df2:      	movzbl	%dl, %eax
     df5:      	retq
     df6:      	nopw	%cs:(%rax,%rax)

0000000000000e00 <filter_16ty_selector_val>:
     e00:      	movl	0x4(%rdi), %ecx
     e03:      	movl	$0x1, %eax
     e08:      	cmpq	$0x25, %rcx
     e0c:      	ja	0xe7f <filter_16ty_selector_val+0x7f>
     e0e:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     e18:      	btq	%rcx, %rdx
     e1c:      	jae	0xe1f <filter_16ty_selector_val+0x1f>
     e1e:      	retq
     e1f:      	movl	$0x18, %edx
     e24:      	btq	%rcx, %rdx
     e28:      	jae	0xe3f <filter_16ty_selector_val+0x3f>
     e2a:      	movzwl	(%rsi), %edx
     e2d:      	cmpl	%edx, 0x10(%rdi)
     e30:      	jne	0xf55 <filter_16ty_selector_val+0x155>
     e36:      	xorl	%eax, %eax
     e38:      	cmpl	$0x3, %ecx
     e3b:      	sete	%al
     e3e:      	retq
     e3f:      	cmpq	$0xc, %rcx
     e43:      	jne	0xe7f <filter_16ty_selector_val+0x7f>
     e45:      	movzwl	(%rsi), %ecx
     e48:      	testl	%ecx, 0x10(%rdi)
     e4b:      	jne	0xe1e <filter_16ty_selector_val+0x1e>
     e4d:      	movl	0x8(%rdi), %edx
     e50:      	cmpl	$0xd, %edx
     e53:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     e59:      	testl	%ecx, 0x14(%rdi)
     e5c:      	jne	0xe1e <filter_16ty_selector_val+0x1e>
     e5e:      	cmpl	$0x11, %edx
     e61:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     e67:      	testl	%ecx, 0x18(%rdi)
     e6a:      	jne	0xe1e <filter_16ty_selector_val+0x1e>
     e6c:      	cmpl	$0x15, %edx
     e6f:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     e75:      	testl	%ecx, 0x1c(%rdi)
     e78:      	jne	0xe1e <filter_16ty_selector_val+0x1e>
     e7a:      	jmp	0x1017 <filter_16ty_selector_val+0x217>
     e7f:      	cmpl	$0x1, %ecx
     e82:      	je	0xef1 <filter_16ty_selector_val+0xf1>
     e84:      	cmpl	$0x2, %ecx
     e87:      	jne	0x1017 <filter_16ty_selector_val+0x217>
     e8d:      	movl	0xc(%rdi), %ecx
     e90:      	cmpl	$0xc, %ecx
     e93:      	ja	0xfde <filter_16ty_selector_val+0x1de>
     e99:      	movl	$0x1402, %edx           # imm = 0x1402
     e9e:      	btl	%ecx, %edx
     ea1:      	jae	0xfde <filter_16ty_selector_val+0x1de>
     ea7:      	movswl	(%rsi), %ecx
     eaa:      	cmpl	%ecx, 0x10(%rdi)
     ead:      	jg	0xe1e <filter_16ty_selector_val+0x1e>
     eb3:      	movl	0x8(%rdi), %edx
     eb6:      	cmpl	$0xd, %edx
     eb9:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     ebf:      	cmpl	%ecx, 0x14(%rdi)
     ec2:      	jg	0xe1e <filter_16ty_selector_val+0x1e>
     ec8:      	cmpl	$0x11, %edx
     ecb:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     ed1:      	cmpl	%ecx, 0x18(%rdi)
     ed4:      	jg	0xe1e <filter_16ty_selector_val+0x1e>
     eda:      	cmpl	$0x15, %edx
     edd:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     ee3:      	cmpl	%ecx, 0x1c(%rdi)
     ee6:      	jg	0xe1e <filter_16ty_selector_val+0x1e>
     eec:      	jmp	0x1017 <filter_16ty_selector_val+0x217>
     ef1:      	movl	0xc(%rdi), %ecx
     ef4:      	cmpl	$0xc, %ecx
     ef7:      	ja	0xfa3 <filter_16ty_selector_val+0x1a3>
     efd:      	movl	$0x1402, %edx           # imm = 0x1402
     f02:      	btl	%ecx, %edx
     f05:      	jae	0xfa3 <filter_16ty_selector_val+0x1a3>
     f0b:      	movswl	(%rsi), %ecx
     f0e:      	cmpl	%ecx, 0x10(%rdi)
     f11:      	jl	0xe1e <filter_16ty_selector_val+0x1e>
     f17:      	movl	0x8(%rdi), %edx
     f1a:      	cmpl	$0xd, %edx
     f1d:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     f23:      	cmpl	%ecx, 0x14(%rdi)
     f26:      	jl	0xe1e <filter_16ty_selector_val+0x1e>
     f2c:      	cmpl	$0x11, %edx
     f2f:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     f35:      	cmpl	%ecx, 0x18(%rdi)
     f38:      	jl	0xe1e <filter_16ty_selector_val+0x1e>
     f3e:      	cmpl	$0x15, %edx
     f41:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     f47:      	cmpl	%ecx, 0x1c(%rdi)
     f4a:      	jl	0xe1e <filter_16ty_selector_val+0x1e>
     f50:      	jmp	0x1017 <filter_16ty_selector_val+0x217>
     f55:      	movl	0x8(%rdi), %esi
     f58:      	cmpl	$0xd, %esi
     f5b:      	jb	0xf82 <filter_16ty_selector_val+0x182>
     f5d:      	cmpl	%edx, 0x14(%rdi)
     f60:      	je	0xe36 <filter_16ty_selector_val+0x36>
     f66:      	cmpl	$0x11, %esi
     f69:      	jb	0xf82 <filter_16ty_selector_val+0x182>
     f6b:      	cmpl	%edx, 0x18(%rdi)
     f6e:      	je	0xe36 <filter_16ty_selector_val+0x36>
     f74:      	cmpl	$0x15, %esi
     f77:      	jb	0xf82 <filter_16ty_selector_val+0x182>
     f79:      	cmpl	%edx, 0x1c(%rdi)
     f7c:      	je	0xe36 <filter_16ty_selector_val+0x36>
     f82:      	cmpl	$0x25, %ecx
     f85:      	ja	0x1017 <filter_16ty_selector_val+0x217>
     f8b:      	movl	%ecx, %ecx
     f8d:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
     f97:      	btq	%rcx, %rdx
     f9b:      	jb	0xe1e <filter_16ty_selector_val+0x1e>
     fa1:      	jmp	0x1017 <filter_16ty_selector_val+0x217>
     fa3:      	movzwl	(%rsi), %ecx
     fa6:      	cmpl	%ecx, 0x10(%rdi)
     fa9:      	jb	0xe1e <filter_16ty_selector_val+0x1e>
     faf:      	movl	0x8(%rdi), %edx
     fb2:      	cmpl	$0xd, %edx
     fb5:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     fb7:      	cmpl	%ecx, 0x14(%rdi)
     fba:      	jb	0xe1e <filter_16ty_selector_val+0x1e>
     fc0:      	cmpl	$0x11, %edx
     fc3:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     fc5:      	cmpl	%ecx, 0x18(%rdi)
     fc8:      	jb	0xe1e <filter_16ty_selector_val+0x1e>
     fce:      	cmpl	$0x15, %edx
     fd1:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     fd3:      	cmpl	%ecx, 0x1c(%rdi)
     fd6:      	jb	0xe1e <filter_16ty_selector_val+0x1e>
     fdc:      	jmp	0x1017 <filter_16ty_selector_val+0x217>
     fde:      	movzwl	(%rsi), %ecx
     fe1:      	cmpl	%ecx, 0x10(%rdi)
     fe4:      	ja	0xe1e <filter_16ty_selector_val+0x1e>
     fea:      	movl	0x8(%rdi), %edx
     fed:      	cmpl	$0xd, %edx
     ff0:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     ff2:      	cmpl	%ecx, 0x14(%rdi)
     ff5:      	ja	0xe1e <filter_16ty_selector_val+0x1e>
     ffb:      	cmpl	$0x11, %edx
     ffe:      	jb	0x1017 <filter_16ty_selector_val+0x217>
    1000:      	cmpl	%ecx, 0x18(%rdi)
    1003:      	ja	0xe1e <filter_16ty_selector_val+0x1e>
    1009:      	cmpl	$0x15, %edx
    100c:      	jb	0x1017 <filter_16ty_selector_val+0x217>
    100e:      	cmpl	%ecx, 0x1c(%rdi)
    1011:      	ja	0xe1e <filter_16ty_selector_val+0x1e>
    1017:      	xorl	%eax, %eax
    1019:      	retq
    101a:      	nopw	(%rax,%rax)

0000000000001020 <filter_16ty_map>:
    1020:      	pushq	%r14
    1022:      	pushq	%rbx
    1023:      	subq	$0x18, %rsp
    1027:      	movq	%rsi, %r14
    102a:      	movq	%rdi, %rbx
    102d:      	movzbl	0x10(%rdi), %eax
    1031:      	movl	%eax, 0xc(%rsp)
    1035:      	movq	(%rip), %rdi            # 0x103c <filter_16ty_map+0x1c>
    103c:      	leaq	0xc(%rsp), %rsi
    1041:      	movl	$0x1, %eax
    1046:      	callq	*%rax
    1048:      	testq	%rax, %rax
    104b:      	je	0x1081 <filter_16ty_map+0x61>
    104d:      	movq	%rax, %rdi
    1050:      	movzwl	(%r14), %eax
    1054:      	movq	%rax, 0x10(%rsp)
    1059:      	leaq	0x10(%rsp), %rsi
    105e:      	movl	$0x1, %eax
    1063:      	callq	*%rax
    1065:      	movl	0x4(%rbx), %edx
    1068:      	xorl	%ecx, %ecx
    106a:      	cmpl	$0x1d, %edx
    106d:      	ja	0x109b <filter_16ty_map+0x7b>
    106f:      	movl	$0x30038400, %esi       # imm = 0x30038400
    1074:      	btl	%edx, %esi
    1077:      	jae	0x108b <filter_16ty_map+0x6b>
    1079:      	testq	%rax, %rax
    107c:      	setne	%cl
    107f:      	jmp	0x109b <filter_16ty_map+0x7b>
    1081:      	xorl	%eax, %eax
    1083:      	addq	$0x18, %rsp
    1087:      	popq	%rbx
    1088:      	popq	%r14
    108a:      	retq
    108b:      	movl	$0xc0800, %esi          # imm = 0xC0800
    1090:      	btl	%edx, %esi
    1093:      	jae	0x109b <filter_16ty_map+0x7b>
    1095:      	testq	%rax, %rax
    1098:      	sete	%cl
    109b:      	movzbl	%cl, %eax
    109e:      	addq	$0x18, %rsp
    10a2:      	popq	%rbx
    10a3:      	popq	%r14
    10a5:      	retq
    10a6:      	nopw	%cs:(%rax,%rax)

00000000000010b0 <filter_16ty_range>:
    10b0:      	movl	0x4(%rdi), %ecx
    10b3:      	movl	0xc(%rdi), %eax
    10b6:      	cmpl	$0xc, %eax
    10b9:      	ja	0x11a0 <filter_16ty_range+0xf0>
    10bf:      	movl	$0x1402, %edx           # imm = 0x1402
    10c4:      	btl	%eax, %edx
    10c7:      	jae	0x11a0 <filter_16ty_range+0xf0>
    10cd:      	movswl	(%rsi), %esi
    10d0:      	cmpl	$0x1f, %ecx
    10d3:      	jne	0x113b <filter_16ty_range+0x8b>
    10d5:      	movl	$0x1, %eax
    10da:      	cmpl	%esi, 0x10(%rdi)
    10dd:      	jg	0x10e8 <filter_16ty_range+0x38>
    10df:      	cmpl	%esi, 0x14(%rdi)
    10e2:      	jge	0x11b7 <filter_16ty_range+0x107>
    10e8:      	movl	0x8(%rdi), %edx
    10eb:      	cmpl	$0x11, %edx
    10ee:      	jb	0x1257 <filter_16ty_range+0x1a7>
    10f4:      	cmpl	%esi, 0x18(%rdi)
    10f7:      	jg	0x1102 <filter_16ty_range+0x52>
    10f9:      	cmpl	%esi, 0x1c(%rdi)
    10fc:      	jge	0x11b7 <filter_16ty_range+0x107>
    1102:      	cmpl	$0x19, %edx
    1105:      	jb	0x1257 <filter_16ty_range+0x1a7>
    110b:      	cmpl	%esi, 0x20(%rdi)
    110e:      	jg	0x1119 <filter_16ty_range+0x69>
    1110:      	cmpl	%esi, 0x24(%rdi)
    1113:      	jge	0x11b7 <filter_16ty_range+0x107>
    1119:      	cmpl	$0x21, %edx
    111c:      	jb	0x1257 <filter_16ty_range+0x1a7>
    1122:      	xorl	%edx, %edx
    1124:      	cmpl	%esi, 0x28(%rdi)
    1127:      	jg	0x1259 <filter_16ty_range+0x1a9>
    112d:      	cmpl	%esi, 0x2c(%rdi)
    1130:      	jge	0x11b7 <filter_16ty_range+0x107>
    1136:      	jmp	0x1259 <filter_16ty_range+0x1a9>
    113b:      	movl	0x8(%rdi), %eax
    113e:      	cmpl	%esi, 0x10(%rdi)
    1141:      	setle	%r8b
    1145:      	cmpl	%esi, 0x14(%rdi)
    1148:      	setge	%dl
    114b:      	andb	%r8b, %dl
    114e:      	cmpl	$0x11, %eax
    1151:      	jb	0x1259 <filter_16ty_range+0x1a9>
    1157:      	cmpl	%esi, 0x18(%rdi)
    115a:      	setle	%r8b
    115e:      	cmpl	%esi, 0x1c(%rdi)
    1161:      	setge	%r9b
    1165:      	andb	%r8b, %r9b
    1168:      	orb	%r9b, %dl
    116b:      	cmpl	$0x19, %eax
    116e:      	jb	0x1259 <filter_16ty_range+0x1a9>
    1174:      	cmpl	%esi, 0x20(%rdi)
    1177:      	setle	%r8b
    117b:      	cmpl	%esi, 0x24(%rdi)
    117e:      	setge	%r9b
    1182:      	andb	%r8b, %r9b
    1185:      	orb	%r9b, %dl
    1188:      	cmpl	$0x21, %eax
    118b:      	jb	0x1259 <filter_16ty_range+0x1a9>
    1191:      	cmpl	%esi, 0x28(%rdi)
    1194:      	setle	%al
    1197:      	cmpl	%esi, 0x2c(%rdi)
    119a:      	setge	%sil
    119e:      	jmp	0x1213 <filter_16ty_range+0x163>
    11a0:      	movzwl	(%rsi), %esi
    11a3:      	cmpl	$0x1f, %ecx
    11a6:      	jne	0x11b8 <filter_16ty_range+0x108>
    11a8:      	movl	$0x1, %eax
    11ad:      	cmpl	%esi, 0x10(%rdi)
    11b0:      	ja	0x121b <filter_16ty_range+0x16b>
    11b2:      	cmpl	%esi, 0x14(%rdi)
    11b5:      	jb	0x121b <filter_16ty_range+0x16b>
    11b7:      	retq
    11b8:      	movl	0x8(%rdi), %eax
    11bb:      	cmpl	%esi, 0x10(%rdi)
    11be:      	setbe	%r8b
    11c2:      	cmpl	%esi, 0x14(%rdi)
    11c5:      	setae	%dl
    11c8:      	andb	%r8b, %dl
    11cb:      	cmpl	$0x11, %eax
    11ce:      	jb	0x1259 <filter_16ty_range+0x1a9>
    11d4:      	cmpl	%esi, 0x18(%rdi)
    11d7:      	setbe	%r8b
    11db:      	cmpl	%esi, 0x1c(%rdi)
    11de:      	setae	%r9b
    11e2:      	andb	%r8b, %r9b
    11e5:      	orb	%r9b, %dl
    11e8:      	cmpl	$0x19, %eax
    11eb:      	jb	0x1259 <filter_16ty_range+0x1a9>
    11ed:      	cmpl	%esi, 0x20(%rdi)
    11f0:      	setbe	%r8b
    11f4:      	cmpl	%esi, 0x24(%rdi)
    11f7:      	setae	%r9b
    11fb:      	andb	%r8b, %r9b
    11fe:      	orb	%r9b, %dl
    1201:      	cmpl	$0x21, %eax
    1204:      	jb	0x1259 <filter_16ty_range+0x1a9>
    1206:      	cmpl	%esi, 0x28(%rdi)
    1209:      	setbe	%al
    120c:      	cmpl	%esi, 0x2c(%rdi)
    120f:      	setae	%sil
    1213:      	andb	%al, %sil
    1216:      	orb	%sil, %dl
    1219:      	jmp	0x1259 <filter_16ty_range+0x1a9>
    121b:      	movl	0x8(%rdi), %edx
    121e:      	cmpl	$0x11, %edx
    1221:      	jb	0x1257 <filter_16ty_range+0x1a7>
    1223:      	cmpl	%esi, 0x18(%rdi)
    1226:      	ja	0x122d <filter_16ty_range+0x17d>
    1228:      	cmpl	%esi, 0x1c(%rdi)
    122b:      	jae	0x11b7 <filter_16ty_range+0x107>
    122d:      	cmpl	$0x19, %edx
    1230:      	jb	0x1257 <filter_16ty_range+0x1a7>
    1232:      	cmpl	%esi, 0x20(%rdi)
    1235:      	ja	0x1240 <filter_16ty_range+0x190>
    1237:      	cmpl	%esi, 0x24(%rdi)
    123a:      	jae	0x11b7 <filter_16ty_range+0x107>
    1240:      	cmpl	$0x21, %edx
    1243:      	jb	0x1257 <filter_16ty_range+0x1a7>
    1245:      	xorl	%edx, %edx
    1247:      	cmpl	%esi, 0x28(%rdi)
    124a:      	ja	0x1259 <filter_16ty_range+0x1a9>
    124c:      	cmpl	%esi, 0x2c(%rdi)
    124f:      	jae	0x11b7 <filter_16ty_range+0x107>
    1255:      	jmp	0x1259 <filter_16ty_range+0x1a9>
    1257:      	xorl	%edx, %edx
    1259:      	cmpl	$0x20, %ecx
    125c:      	sete	%al
    125f:      	xorb	$0x1, %dl
    1262:      	andb	%al, %dl
    1264:      	movzbl	%dl, %eax
    1267:      	retq
    1268:      	nopl	(%rax,%rax)

0000000000001270 <filter_8ty_selector_val>:
    1270:      	movl	0x4(%rdi), %ecx
    1273:      	movl	$0x1, %eax
    1278:      	cmpq	$0x25, %rcx
    127c:      	ja	0x12ef <filter_8ty_selector_val+0x7f>
    127e:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
    1288:      	btq	%rcx, %rdx
    128c:      	jae	0x128f <filter_8ty_selector_val+0x1f>
    128e:      	retq
    128f:      	movl	$0x18, %edx
    1294:      	btq	%rcx, %rdx
    1298:      	jae	0x12af <filter_8ty_selector_val+0x3f>
    129a:      	movzbl	(%rsi), %edx
    129d:      	cmpl	%edx, 0x10(%rdi)
    12a0:      	jne	0x13c5 <filter_8ty_selector_val+0x155>
    12a6:      	xorl	%eax, %eax
    12a8:      	cmpl	$0x3, %ecx
    12ab:      	sete	%al
    12ae:      	retq
    12af:      	cmpq	$0xc, %rcx
    12b3:      	jne	0x12ef <filter_8ty_selector_val+0x7f>
    12b5:      	movzbl	(%rsi), %ecx
    12b8:      	testl	%ecx, 0x10(%rdi)
    12bb:      	jne	0x128e <filter_8ty_selector_val+0x1e>
    12bd:      	movl	0x8(%rdi), %edx
    12c0:      	cmpl	$0xd, %edx
    12c3:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    12c9:      	testl	%ecx, 0x14(%rdi)
    12cc:      	jne	0x128e <filter_8ty_selector_val+0x1e>
    12ce:      	cmpl	$0x11, %edx
    12d1:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    12d7:      	testl	%ecx, 0x18(%rdi)
    12da:      	jne	0x128e <filter_8ty_selector_val+0x1e>
    12dc:      	cmpl	$0x15, %edx
    12df:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    12e5:      	testl	%ecx, 0x1c(%rdi)
    12e8:      	jne	0x128e <filter_8ty_selector_val+0x1e>
    12ea:      	jmp	0x1487 <filter_8ty_selector_val+0x217>
    12ef:      	cmpl	$0x1, %ecx
    12f2:      	je	0x1361 <filter_8ty_selector_val+0xf1>
    12f4:      	cmpl	$0x2, %ecx
    12f7:      	jne	0x1487 <filter_8ty_selector_val+0x217>
    12fd:      	movl	0xc(%rdi), %ecx
    1300:      	cmpl	$0xc, %ecx
    1303:      	ja	0x144e <filter_8ty_selector_val+0x1de>
    1309:      	movl	$0x1402, %edx           # imm = 0x1402
    130e:      	btl	%ecx, %edx
    1311:      	jae	0x144e <filter_8ty_selector_val+0x1de>
    1317:      	movsbl	(%rsi), %ecx
    131a:      	cmpl	%ecx, 0x10(%rdi)
    131d:      	jg	0x128e <filter_8ty_selector_val+0x1e>
    1323:      	movl	0x8(%rdi), %edx
    1326:      	cmpl	$0xd, %edx
    1329:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    132f:      	cmpl	%ecx, 0x14(%rdi)
    1332:      	jg	0x128e <filter_8ty_selector_val+0x1e>
    1338:      	cmpl	$0x11, %edx
    133b:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    1341:      	cmpl	%ecx, 0x18(%rdi)
    1344:      	jg	0x128e <filter_8ty_selector_val+0x1e>
    134a:      	cmpl	$0x15, %edx
    134d:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    1353:      	cmpl	%ecx, 0x1c(%rdi)
    1356:      	jg	0x128e <filter_8ty_selector_val+0x1e>
    135c:      	jmp	0x1487 <filter_8ty_selector_val+0x217>
    1361:      	movl	0xc(%rdi), %ecx
    1364:      	cmpl	$0xc, %ecx
    1367:      	ja	0x1413 <filter_8ty_selector_val+0x1a3>
    136d:      	movl	$0x1402, %edx           # imm = 0x1402
    1372:      	btl	%ecx, %edx
    1375:      	jae	0x1413 <filter_8ty_selector_val+0x1a3>
    137b:      	movsbl	(%rsi), %ecx
    137e:      	cmpl	%ecx, 0x10(%rdi)
    1381:      	jl	0x128e <filter_8ty_selector_val+0x1e>
    1387:      	movl	0x8(%rdi), %edx
    138a:      	cmpl	$0xd, %edx
    138d:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    1393:      	cmpl	%ecx, 0x14(%rdi)
    1396:      	jl	0x128e <filter_8ty_selector_val+0x1e>
    139c:      	cmpl	$0x11, %edx
    139f:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    13a5:      	cmpl	%ecx, 0x18(%rdi)
    13a8:      	jl	0x128e <filter_8ty_selector_val+0x1e>
    13ae:      	cmpl	$0x15, %edx
    13b1:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    13b7:      	cmpl	%ecx, 0x1c(%rdi)
    13ba:      	jl	0x128e <filter_8ty_selector_val+0x1e>
    13c0:      	jmp	0x1487 <filter_8ty_selector_val+0x217>
    13c5:      	movl	0x8(%rdi), %esi
    13c8:      	cmpl	$0xd, %esi
    13cb:      	jb	0x13f2 <filter_8ty_selector_val+0x182>
    13cd:      	cmpl	%edx, 0x14(%rdi)
    13d0:      	je	0x12a6 <filter_8ty_selector_val+0x36>
    13d6:      	cmpl	$0x11, %esi
    13d9:      	jb	0x13f2 <filter_8ty_selector_val+0x182>
    13db:      	cmpl	%edx, 0x18(%rdi)
    13de:      	je	0x12a6 <filter_8ty_selector_val+0x36>
    13e4:      	cmpl	$0x15, %esi
    13e7:      	jb	0x13f2 <filter_8ty_selector_val+0x182>
    13e9:      	cmpl	%edx, 0x1c(%rdi)
    13ec:      	je	0x12a6 <filter_8ty_selector_val+0x36>
    13f2:      	cmpl	$0x25, %ecx
    13f5:      	ja	0x1487 <filter_8ty_selector_val+0x217>
    13fb:      	movl	%ecx, %ecx
    13fd:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1407:      	btq	%rcx, %rdx
    140b:      	jb	0x128e <filter_8ty_selector_val+0x1e>
    1411:      	jmp	0x1487 <filter_8ty_selector_val+0x217>
    1413:      	movzbl	(%rsi), %ecx
    1416:      	cmpl	%ecx, 0x10(%rdi)
    1419:      	jb	0x128e <filter_8ty_selector_val+0x1e>
    141f:      	movl	0x8(%rdi), %edx
    1422:      	cmpl	$0xd, %edx
    1425:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    1427:      	cmpl	%ecx, 0x14(%rdi)
    142a:      	jb	0x128e <filter_8ty_selector_val+0x1e>
    1430:      	cmpl	$0x11, %edx
    1433:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    1435:      	cmpl	%ecx, 0x18(%rdi)
    1438:      	jb	0x128e <filter_8ty_selector_val+0x1e>
    143e:      	cmpl	$0x15, %edx
    1441:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    1443:      	cmpl	%ecx, 0x1c(%rdi)
    1446:      	jb	0x128e <filter_8ty_selector_val+0x1e>
    144c:      	jmp	0x1487 <filter_8ty_selector_val+0x217>
    144e:      	movzbl	(%rsi), %ecx
    1451:      	cmpl	%ecx, 0x10(%rdi)
    1454:      	ja	0x128e <filter_8ty_selector_val+0x1e>
    145a:      	movl	0x8(%rdi), %edx
    145d:      	cmpl	$0xd, %edx
    1460:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    1462:      	cmpl	%ecx, 0x14(%rdi)
    1465:      	ja	0x128e <filter_8ty_selector_val+0x1e>
    146b:      	cmpl	$0x11, %edx
    146e:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    1470:      	cmpl	%ecx, 0x18(%rdi)
    1473:      	ja	0x128e <filter_8ty_selector_val+0x1e>
    1479:      	cmpl	$0x15, %edx
    147c:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    147e:      	cmpl	%ecx, 0x1c(%rdi)
    1481:      	ja	0x128e <filter_8ty_selector_val+0x1e>
    1487:      	xorl	%eax, %eax
    1489:      	retq
    148a:      	nopw	(%rax,%rax)

0000000000001490 <filter_8ty_map>:
    1490:      	pushq	%r14
    1492:      	pushq	%rbx
    1493:      	subq	$0x18, %rsp
    1497:      	movq	%rsi, %r14
    149a:      	movq	%rdi, %rbx
    149d:      	movzbl	0x10(%rdi), %eax
    14a1:      	movl	%eax, 0xc(%rsp)
    14a5:      	movq	(%rip), %rdi            # 0x14ac <filter_8ty_map+0x1c>
    14ac:      	leaq	0xc(%rsp), %rsi
    14b1:      	movl	$0x1, %eax
    14b6:      	callq	*%rax
    14b8:      	testq	%rax, %rax
    14bb:      	je	0x14f1 <filter_8ty_map+0x61>
    14bd:      	movq	%rax, %rdi
    14c0:      	movzbl	(%r14), %eax
    14c4:      	movq	%rax, 0x10(%rsp)
    14c9:      	leaq	0x10(%rsp), %rsi
    14ce:      	movl	$0x1, %eax
    14d3:      	callq	*%rax
    14d5:      	movl	0x4(%rbx), %edx
    14d8:      	xorl	%ecx, %ecx
    14da:      	cmpl	$0x1d, %edx
    14dd:      	ja	0x150b <filter_8ty_map+0x7b>
    14df:      	movl	$0x30038400, %esi       # imm = 0x30038400
    14e4:      	btl	%edx, %esi
    14e7:      	jae	0x14fb <filter_8ty_map+0x6b>
    14e9:      	testq	%rax, %rax
    14ec:      	setne	%cl
    14ef:      	jmp	0x150b <filter_8ty_map+0x7b>
    14f1:      	xorl	%eax, %eax
    14f3:      	addq	$0x18, %rsp
    14f7:      	popq	%rbx
    14f8:      	popq	%r14
    14fa:      	retq
    14fb:      	movl	$0xc0800, %esi          # imm = 0xC0800
    1500:      	btl	%edx, %esi
    1503:      	jae	0x150b <filter_8ty_map+0x7b>
    1505:      	testq	%rax, %rax
    1508:      	sete	%cl
    150b:      	movzbl	%cl, %eax
    150e:      	addq	$0x18, %rsp
    1512:      	popq	%rbx
    1513:      	popq	%r14
    1515:      	retq
    1516:      	nopw	%cs:(%rax,%rax)

0000000000001520 <filter_8ty_range>:
    1520:      	movl	0x4(%rdi), %ecx
    1523:      	movl	0xc(%rdi), %eax
    1526:      	cmpl	$0xc, %eax
    1529:      	ja	0x1610 <filter_8ty_range+0xf0>
    152f:      	movl	$0x1402, %edx           # imm = 0x1402
    1534:      	btl	%eax, %edx
    1537:      	jae	0x1610 <filter_8ty_range+0xf0>
    153d:      	movsbl	(%rsi), %esi
    1540:      	cmpl	$0x1f, %ecx
    1543:      	jne	0x15ab <filter_8ty_range+0x8b>
    1545:      	movl	$0x1, %eax
    154a:      	cmpl	%esi, 0x10(%rdi)
    154d:      	jg	0x1558 <filter_8ty_range+0x38>
    154f:      	cmpl	%esi, 0x14(%rdi)
    1552:      	jge	0x1627 <filter_8ty_range+0x107>
    1558:      	movl	0x8(%rdi), %edx
    155b:      	cmpl	$0x11, %edx
    155e:      	jb	0x16c7 <filter_8ty_range+0x1a7>
    1564:      	cmpl	%esi, 0x18(%rdi)
    1567:      	jg	0x1572 <filter_8ty_range+0x52>
    1569:      	cmpl	%esi, 0x1c(%rdi)
    156c:      	jge	0x1627 <filter_8ty_range+0x107>
    1572:      	cmpl	$0x19, %edx
    1575:      	jb	0x16c7 <filter_8ty_range+0x1a7>
    157b:      	cmpl	%esi, 0x20(%rdi)
    157e:      	jg	0x1589 <filter_8ty_range+0x69>
    1580:      	cmpl	%esi, 0x24(%rdi)
    1583:      	jge	0x1627 <filter_8ty_range+0x107>
    1589:      	cmpl	$0x21, %edx
    158c:      	jb	0x16c7 <filter_8ty_range+0x1a7>
    1592:      	xorl	%edx, %edx
    1594:      	cmpl	%esi, 0x28(%rdi)
    1597:      	jg	0x16c9 <filter_8ty_range+0x1a9>
    159d:      	cmpl	%esi, 0x2c(%rdi)
    15a0:      	jge	0x1627 <filter_8ty_range+0x107>
    15a6:      	jmp	0x16c9 <filter_8ty_range+0x1a9>
    15ab:      	movl	0x8(%rdi), %eax
    15ae:      	cmpl	%esi, 0x10(%rdi)
    15b1:      	setle	%r8b
    15b5:      	cmpl	%esi, 0x14(%rdi)
    15b8:      	setge	%dl
    15bb:      	andb	%r8b, %dl
    15be:      	cmpl	$0x11, %eax
    15c1:      	jb	0x16c9 <filter_8ty_range+0x1a9>
    15c7:      	cmpl	%esi, 0x18(%rdi)
    15ca:      	setle	%r8b
    15ce:      	cmpl	%esi, 0x1c(%rdi)
    15d1:      	setge	%r9b
    15d5:      	andb	%r8b, %r9b
    15d8:      	orb	%r9b, %dl
    15db:      	cmpl	$0x19, %eax
    15de:      	jb	0x16c9 <filter_8ty_range+0x1a9>
    15e4:      	cmpl	%esi, 0x20(%rdi)
    15e7:      	setle	%r8b
    15eb:      	cmpl	%esi, 0x24(%rdi)
    15ee:      	setge	%r9b
    15f2:      	andb	%r8b, %r9b
    15f5:      	orb	%r9b, %dl
    15f8:      	cmpl	$0x21, %eax
    15fb:      	jb	0x16c9 <filter_8ty_range+0x1a9>
    1601:      	cmpl	%esi, 0x28(%rdi)
    1604:      	setle	%al
    1607:      	cmpl	%esi, 0x2c(%rdi)
    160a:      	setge	%sil
    160e:      	jmp	0x1683 <filter_8ty_range+0x163>
    1610:      	movzbl	(%rsi), %esi
    1613:      	cmpl	$0x1f, %ecx
    1616:      	jne	0x1628 <filter_8ty_range+0x108>
    1618:      	movl	$0x1, %eax
    161d:      	cmpl	%esi, 0x10(%rdi)
    1620:      	ja	0x168b <filter_8ty_range+0x16b>
    1622:      	cmpl	%esi, 0x14(%rdi)
    1625:      	jb	0x168b <filter_8ty_range+0x16b>
    1627:      	retq
    1628:      	movl	0x8(%rdi), %eax
    162b:      	cmpl	%esi, 0x10(%rdi)
    162e:      	setbe	%r8b
    1632:      	cmpl	%esi, 0x14(%rdi)
    1635:      	setae	%dl
    1638:      	andb	%r8b, %dl
    163b:      	cmpl	$0x11, %eax
    163e:      	jb	0x16c9 <filter_8ty_range+0x1a9>
    1644:      	cmpl	%esi, 0x18(%rdi)
    1647:      	setbe	%r8b
    164b:      	cmpl	%esi, 0x1c(%rdi)
    164e:      	setae	%r9b
    1652:      	andb	%r8b, %r9b
    1655:      	orb	%r9b, %dl
    1658:      	cmpl	$0x19, %eax
    165b:      	jb	0x16c9 <filter_8ty_range+0x1a9>
    165d:      	cmpl	%esi, 0x20(%rdi)
    1660:      	setbe	%r8b
    1664:      	cmpl	%esi, 0x24(%rdi)
    1667:      	setae	%r9b
    166b:      	andb	%r8b, %r9b
    166e:      	orb	%r9b, %dl
    1671:      	cmpl	$0x21, %eax
    1674:      	jb	0x16c9 <filter_8ty_range+0x1a9>
    1676:      	cmpl	%esi, 0x28(%rdi)
    1679:      	setbe	%al
    167c:      	cmpl	%esi, 0x2c(%rdi)
    167f:      	setae	%sil
    1683:      	andb	%al, %sil
    1686:      	orb	%sil, %dl
    1689:      	jmp	0x16c9 <filter_8ty_range+0x1a9>
    168b:      	movl	0x8(%rdi), %edx
    168e:      	cmpl	$0x11, %edx
    1691:      	jb	0x16c7 <filter_8ty_range+0x1a7>
    1693:      	cmpl	%esi, 0x18(%rdi)
    1696:      	ja	0x169d <filter_8ty_range+0x17d>
    1698:      	cmpl	%esi, 0x1c(%rdi)
    169b:      	jae	0x1627 <filter_8ty_range+0x107>
    169d:      	cmpl	$0x19, %edx
    16a0:      	jb	0x16c7 <filter_8ty_range+0x1a7>
    16a2:      	cmpl	%esi, 0x20(%rdi)
    16a5:      	ja	0x16b0 <filter_8ty_range+0x190>
    16a7:      	cmpl	%esi, 0x24(%rdi)
    16aa:      	jae	0x1627 <filter_8ty_range+0x107>
    16b0:      	cmpl	$0x21, %edx
    16b3:      	jb	0x16c7 <filter_8ty_range+0x1a7>
    16b5:      	xorl	%edx, %edx
    16b7:      	cmpl	%esi, 0x28(%rdi)
    16ba:      	ja	0x16c9 <filter_8ty_range+0x1a9>
    16bc:      	cmpl	%esi, 0x2c(%rdi)
    16bf:      	jae	0x1627 <filter_8ty_range+0x107>
    16c5:      	jmp	0x16c9 <filter_8ty_range+0x1a9>
    16c7:      	xorl	%edx, %edx
    16c9:      	cmpl	$0x20, %ecx
    16cc:      	sete	%al
    16cf:      	xorb	$0x1, %dl
    16d2:      	andb	%al, %dl
    16d4:      	movzbl	%dl, %eax
    16d7:      	retq
    16d8:      	nopl	(%rax,%rax)

00000000000016e0 <filter_file_buf>:
    16e0:      	pushq	%rbx
    16e1:      	movq	%rdi, %rbx
    16e4:      	movl	(%rsi), %edx
    16e6:      	movl	0x4(%rdi), %ecx
    16e9:      	testl	%edx, %edx
    16eb:      	jne	0x16fb <filter_file_buf+0x1b>
    16ed:      	movl	%ecx, %eax
    16ef:      	andl	$-0x2, %eax
    16f2:      	cmpl	$0x24, %eax
    16f5:      	je	0x16fb <filter_file_buf+0x1b>
    16f7:      	xorl	%eax, %eax
    16f9:      	popq	%rbx
    16fa:      	retq
    16fb:      	cmpl	$0x25, %ecx
    16fe:      	ja	0x173a <filter_file_buf+0x5a>
    1700:      	movl	%ecx, %eax
    1702:      	movl	$0x4000100, %edi        # imm = 0x4000100
    1707:      	btq	%rax, %rdi
    170b:      	jb	0x176e <filter_file_buf+0x8e>
    170d:      	movl	$0x8000200, %edi        # imm = 0x8000200
    1712:      	btq	%rax, %rdi
    1716:      	jb	0x1758 <filter_file_buf+0x78>
    1718:      	movabsq	$0x3000000000, %rdi     # imm = 0x3000000000
    1722:      	btq	%rax, %rdi
    1726:      	jae	0x173a <filter_file_buf+0x5a>
    1728:      	movq	%rbx, %rdi
    172b:      	callq	0x21d0 <filter_file_type>
    1730:      	movl	0x4(%rbx), %ecx
    1733:      	cmpl	$0x25, %ecx
    1736:      	jbe	0x178b <filter_file_buf+0xab>
    1738:      	jmp	0x17a1 <filter_file_buf+0xc1>
    173a:      	leal	-0x3(%rcx), %eax
    173d:      	cmpl	$0x2, %eax
    1740:      	jae	0x1784 <filter_file_buf+0xa4>
    1742:      	addq	$0x4, %rsi
    1746:      	movq	%rbx, %rdi
    1749:      	callq	0x1c60 <filter_char_buf_equal>
    174e:      	movl	0x4(%rbx), %ecx
    1751:      	cmpl	$0x25, %ecx
    1754:      	jbe	0x178b <filter_file_buf+0xab>
    1756:      	jmp	0x17a1 <filter_file_buf+0xc1>
    1758:      	addq	$0x4, %rsi
    175c:      	movl	0x10(%rbx), %edi
    175f:      	callq	0x2080 <filter_char_buf_postfix>
    1764:      	movl	0x4(%rbx), %ecx
    1767:      	cmpl	$0x25, %ecx
    176a:      	jbe	0x178b <filter_file_buf+0xab>
    176c:      	jmp	0x17a1 <filter_file_buf+0xc1>
    176e:      	addq	$0x4, %rsi
    1772:      	movl	0x10(%rbx), %edi
    1775:      	callq	0x1fe0 <filter_char_buf_prefix>
    177a:      	movl	0x4(%rbx), %ecx
    177d:      	cmpl	$0x25, %ecx
    1780:      	jbe	0x178b <filter_file_buf+0xab>
    1782:      	jmp	0x17a1 <filter_file_buf+0xc1>
    1784:      	xorl	%eax, %eax
    1786:      	cmpl	$0x25, %ecx
    1789:      	ja	0x17a1 <filter_file_buf+0xc1>
    178b:      	movl	%ecx, %ecx
    178d:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1797:      	btq	%rcx, %rdx
    179b:      	jae	0x17a1 <filter_file_buf+0xc1>
    179d:      	xorq	$0x1, %rax
    17a1:      	popq	%rbx
    17a2:      	retq
    17a3:      	nopw	%cs:(%rax,%rax)

00000000000017b0 <filter_char_buf>:
    17b0:      	pushq	%rbx
    17b1:      	movq	%rsi, %rax
    17b4:      	movq	%rdi, %rbx
    17b7:      	movslq	%edx, %rcx
    17ba:      	movl	-0x4(%rsi,%rcx), %edx
    17be:      	movl	%ecx, %esi
    17c0:      	addq	%rax, %rsi
    17c3:      	movl	0x4(%rdi), %ecx
    17c6:      	xorl	%eax, %eax
    17c8:      	cmpl	$0x19, %ecx
    17cb:      	jg	0x17e1 <filter_char_buf+0x31>
    17cd:      	leal	-0x3(%rcx), %edi
    17d0:      	cmpl	$0x2, %edi
    17d3:      	jb	0x1818 <filter_char_buf+0x68>
    17d5:      	cmpl	$0x8, %ecx
    17d8:      	je	0x180e <filter_char_buf+0x5e>
    17da:      	cmpl	$0x9, %ecx
    17dd:      	je	0x17f0 <filter_char_buf+0x40>
    17df:      	jmp	0x182f <filter_char_buf+0x7f>
    17e1:      	cmpl	$0x20, %ecx
    17e4:      	jg	0x17fa <filter_char_buf+0x4a>
    17e6:      	cmpl	$0x1a, %ecx
    17e9:      	je	0x180e <filter_char_buf+0x5e>
    17eb:      	cmpl	$0x1b, %ecx
    17ee:      	jne	0x182f <filter_char_buf+0x7f>
    17f0:      	movl	0x10(%rbx), %edi
    17f3:      	callq	0x2080 <filter_char_buf_postfix>
    17f8:      	jmp	0x182c <filter_char_buf+0x7c>
    17fa:      	cmpl	$0x21, %ecx
    17fd:      	je	0x1822 <filter_char_buf+0x72>
    17ff:      	cmpl	$0x22, %ecx
    1802:      	jne	0x182f <filter_char_buf+0x7f>
    1804:      	movq	%rbx, %rdi
    1807:      	movl	$0x1, %ecx
    180c:      	jmp	0x1827 <filter_char_buf+0x77>
    180e:      	movl	0x10(%rbx), %edi
    1811:      	callq	0x1fe0 <filter_char_buf_prefix>
    1816:      	jmp	0x182c <filter_char_buf+0x7c>
    1818:      	movq	%rbx, %rdi
    181b:      	callq	0x1c60 <filter_char_buf_equal>
    1820:      	jmp	0x182c <filter_char_buf+0x7c>
    1822:      	movq	%rbx, %rdi
    1825:      	xorl	%ecx, %ecx
    1827:      	callq	0x2280 <filter_char_substring>
    182c:      	movl	0x4(%rbx), %ecx
    182f:      	cmpl	$0x25, %ecx
    1832:      	ja	0x1851 <filter_char_buf+0xa1>
    1834:      	movl	%ecx, %ecx
    1836:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1840:      	btq	%rcx, %rdx
    1844:      	jae	0x1851 <filter_char_buf+0xa1>
    1846:      	xorl	%ecx, %ecx
    1848:      	testq	%rax, %rax
    184b:      	sete	%cl
    184e:      	movq	%rcx, %rax
    1851:      	popq	%rbx
    1852:      	retq
    1853:      	nopw	%cs:(%rax,%rax)

0000000000001860 <filter_inet>:
    1860:      	pushq	%r15
    1862:      	pushq	%r14
    1864:      	pushq	%r12
    1866:      	pushq	%rbx
    1867:      	subq	$0x48, %rsp
    186b:      	movq	$0x0, 0x40(%rsp)
    1874:      	movq	$0x0, 0x38(%rsp)
    187d:      	movq	$0x0, 0x30(%rsp)
    1886:      	movq	$0x0, 0x28(%rsp)
    188f:      	movq	$0x0, 0x20(%rsp)
    1898:      	movl	$0x0, (%rsp)
    189f:      	movl	$0x0, 0x4(%rsp)
    18a7:      	movl	0xc(%rdi), %edx
    18aa:      	xorl	%eax, %eax
    18ac:      	cmpl	$0x27, %edx
    18af:      	jg	0x18c7 <filter_inet+0x67>
    18b1:      	cmpl	$0x5, %edx
    18b4:      	je	0x194c <filter_inet+0xec>
    18ba:      	movq	%rsi, %r8
    18bd:      	cmpl	$0x7, %edx
    18c0:      	je	0x18d8 <filter_inet+0x78>
    18c2:      	jmp	0x1b5d <filter_inet+0x2fd>
    18c7:      	cmpl	$0x28, %edx
    18ca:      	je	0x1924 <filter_inet+0xc4>
    18cc:      	movq	%rsi, %r8
    18cf:      	cmpl	$0x29, %edx
    18d2:      	jne	0x1b5d <filter_inet+0x2fd>
    18d8:      	movl	0x4(%rdi), %ecx
    18db:      	xorl	%eax, %eax
    18dd:      	cmpl	$0x13, %ecx
    18e0:      	jle	0x1959 <filter_inet+0xf9>
    18e2:      	cmpl	$0x17, %ecx
    18e5:      	jg	0x1904 <filter_inet+0xa4>
    18e7:      	leal	-0x14(%rcx), %edx
    18ea:      	cmpl	$0x2, %edx
    18ed:      	jb	0x19aa <filter_inet+0x14a>
    18f3:      	leal	-0x16(%rcx), %edx
    18f6:      	cmpl	$0x2, %edx
    18f9:      	jb	0x19a4 <filter_inet+0x144>
    18ff:      	jmp	0x1b5d <filter_inet+0x2fd>
    1904:      	cmpl	$0x1b, %ecx
    1907:      	jg	0x19e7 <filter_inet+0x187>
    190d:      	cmpl	$0x18, %ecx
    1910:      	je	0x1a1a <filter_inet+0x1ba>
    1916:      	cmpl	$0x19, %ecx
    1919:      	je	0x1a10 <filter_inet+0x1b0>
    191f:      	jmp	0x1b5d <filter_inet+0x2fd>
    1924:      	movzwl	(%rsi), %eax
    1927:      	movw	%ax, 0x46(%rsp)
    192c:      	movzwl	0x2(%rsi), %eax
    1930:      	movw	%ax, 0x40(%rsp)
    1935:      	movq	0x8(%rsi), %rax
    1939:      	movq	%rax, 0x20(%rsp)
    193e:      	movq	0x10(%rsi), %rax
    1942:      	movq	%rax, 0x28(%rsp)
    1947:      	leaq	0x20(%rsp), %rsi
    194c:      	xorl	%r8d, %r8d
    194f:      	movl	0x4(%rdi), %ecx
    1952:      	xorl	%eax, %eax
    1954:      	cmpl	$0x13, %ecx
    1957:      	jg	0x18e2 <filter_inet+0x82>
    1959:      	cmpl	$0xf, %ecx
    195c:      	jle	0x197a <filter_inet+0x11a>
    195e:      	cmpl	$0x11, %ecx
    1961:      	jg	0x1996 <filter_inet+0x136>
    1963:      	cmpl	$0x10, %ecx
    1966:      	je	0x19a4 <filter_inet+0x144>
    1968:      	cmpl	$0x11, %ecx
    196b:      	jne	0x1b5d <filter_inet+0x2fd>
    1971:      	movzwl	0x24(%rsi), %eax
    1975:      	jmp	0x1b52 <filter_inet+0x2f2>
    197a:      	cmpl	$0xd, %ecx
    197d:      	je	0x1a1a <filter_inet+0x1ba>
    1983:      	cmpl	$0xe, %ecx
    1986:      	je	0x1a10 <filter_inet+0x1b0>
    198c:      	cmpl	$0xf, %ecx
    198f:      	je	0x19aa <filter_inet+0x14a>
    1991:      	jmp	0x1b5d <filter_inet+0x2fd>
    1996:      	cmpl	$0x12, %ecx
    1999:      	je	0x19aa <filter_inet+0x14a>
    199b:      	cmpl	$0x13, %ecx
    199e:      	jne	0x1b5d <filter_inet+0x2fd>
    19a4:      	movzwl	0x22(%rsi), %edx
    19a8:      	jmp	0x19ae <filter_inet+0x14e>
    19aa:      	movzwl	0x20(%rsi), %edx
    19ae:      	movl	%edx, 0x4(%rsp)
    19b2:      	xorl	%ebx, %ebx
    19b4:      	xorl	%r15d, %r15d
    19b7:      	xorl	%r14d, %r14d
    19ba:      	xorl	%eax, %eax
    19bc:      	cmpl	$0x11, %ecx
    19bf:      	jg	0x1a31 <filter_inet+0x1d1>
    19c1:      	leal	-0xd(%rcx), %edx
    19c4:      	cmpl	$0x2, %edx
    19c7:      	jb	0x1a58 <filter_inet+0x1f8>
    19cd:      	leal	-0xf(%rcx), %edx
    19d0:      	cmpl	$0x2, %edx
    19d3:      	jb	0x1aad <filter_inet+0x24d>
    19d9:      	cmpl	$0x11, %ecx
    19dc:      	je	0x1b55 <filter_inet+0x2f5>
    19e2:      	jmp	0x1b5d <filter_inet+0x2fd>
    19e7:      	cmpl	$0x1c, %ecx
    19ea:      	je	0x1b4e <filter_inet+0x2ee>
    19f0:      	cmpl	$0x1d, %ecx
    19f3:      	jne	0x1b5d <filter_inet+0x2fd>
    19f9:      	cmpl	$0x7, %edx
    19fc:      	jne	0x1b81 <filter_inet+0x321>
    1a02:      	testq	%r8, %r8
    1a05:      	jne	0x1b8b <filter_inet+0x32b>
    1a0b:      	jmp	0x1b55 <filter_inet+0x2f5>
    1a10:      	movq	0x10(%rsi), %rbx
    1a14:      	movq	0x18(%rsi), %r14
    1a18:      	jmp	0x1a21 <filter_inet+0x1c1>
    1a1a:      	movq	(%rsi), %rbx
    1a1d:      	movq	0x8(%rsi), %r14
    1a21:      	movq	%rbx, %r15
    1a24:      	shrq	$0x20, %r15
    1a28:      	xorl	%edx, %edx
    1a2a:      	xorl	%eax, %eax
    1a2c:      	cmpl	$0x11, %ecx
    1a2f:      	jle	0x19c1 <filter_inet+0x161>
    1a31:      	cmpl	$0x19, %ecx
    1a34:      	ja	0x1aa1 <filter_inet+0x241>
    1a36:      	movl	$0x500000, %r8d         # imm = 0x500000
    1a3c:      	btl	%ecx, %r8d
    1a40:      	jb	0x1ab7 <filter_inet+0x257>
    1a42:      	movl	$0xa00000, %r8d         # imm = 0xA00000
    1a48:      	btl	%ecx, %r8d
    1a4c:      	jb	0x1ac7 <filter_inet+0x267>
    1a4e:      	movl	$0x3000000, %edx        # imm = 0x3000000
    1a53:      	btl	%ecx, %edx
    1a56:      	jae	0x1aa1 <filter_inet+0x241>
    1a58:      	movzwl	0x26(%rsi), %eax
    1a5c:      	cmpl	$0xa, %eax
    1a5f:      	je	0x1ad7 <filter_inet+0x277>
    1a61:      	cmpl	$0x2, %eax
    1a64:      	jne	0x1b47 <filter_inet+0x2e7>
    1a6a:      	movq	%rdi, %r12
    1a6d:      	movl	0x10(%rdi), %eax
    1a70:      	movl	%eax, 0x8(%rsp)
    1a74:      	movq	(%rip), %rdi            # 0x1a7b <filter_inet+0x21b>
    1a7b:      	leaq	0x8(%rsp), %rsi
    1a80:      	movl	$0x1, %eax
    1a85:      	callq	*%rax
    1a87:      	testq	%rax, %rax
    1a8a:      	je	0x1b69 <filter_inet+0x309>
    1a90:      	movq	%rax, %rdi
    1a93:      	movl	$0x20, 0xc(%rsp)
    1a9b:      	movl	%ebx, 0x10(%rsp)
    1a9f:      	jmp	0x1b1b <filter_inet+0x2bb>
    1aa1:      	addl	$-0x12, %ecx
    1aa4:      	cmpl	$0x2, %ecx
    1aa7:      	jae	0x1b5d <filter_inet+0x2fd>
    1aad:      	leaq	0x4(%rsp), %rsi
    1ab2:      	jmp	0x1b58 <filter_inet+0x2f8>
    1ab7:      	xorl	%eax, %eax
    1ab9:      	cmpl	$0x400, %edx            # imm = 0x400
    1abf:      	setb	%al
    1ac2:      	jmp	0x1b5d <filter_inet+0x2fd>
    1ac7:      	xorl	%eax, %eax
    1ac9:      	cmpl	$0x400, %edx            # imm = 0x400
    1acf:      	setae	%al
    1ad2:      	jmp	0x1b5d <filter_inet+0x2fd>
    1ad7:      	movq	%rdi, %r12
    1ada:      	movl	0x14(%rdi), %eax
    1add:      	movl	%eax, 0x8(%rsp)
    1ae1:      	movq	(%rip), %rdi            # 0x1ae8 <filter_inet+0x288>
    1ae8:      	leaq	0x8(%rsp), %rsi
    1aed:      	movl	$0x1, %eax
    1af2:      	callq	*%rax
    1af4:      	testq	%rax, %rax
    1af7:      	je	0x1b69 <filter_inet+0x309>
    1af9:      	movq	%rax, %rdi
    1afc:      	movl	$0x80, 0xc(%rsp)
    1b04:      	movl	%ebx, 0x10(%rsp)
    1b08:      	movl	%r15d, 0x14(%rsp)
    1b0d:      	movl	%r14d, 0x18(%rsp)
    1b12:      	shrq	$0x20, %r14
    1b16:      	movl	%r14d, 0x1c(%rsp)
    1b1b:      	leaq	0xc(%rsp), %rsi
    1b20:      	movl	$0x1, %eax
    1b25:      	callq	*%rax
    1b27:      	movl	0x4(%r12), %ecx
    1b2c:      	leal	-0x18(%rcx), %edx
    1b2f:      	cmpl	$0x2, %edx
    1b32:      	jb	0x1b76 <filter_inet+0x316>
    1b34:      	addl	$-0xd, %ecx
    1b37:      	cmpl	$0x1, %ecx
    1b3a:      	ja	0x1b47 <filter_inet+0x2e7>
    1b3c:      	testq	%rax, %rax
    1b3f:      	setne	%al
    1b42:      	movzbl	%al, %eax
    1b45:      	jmp	0x1b5d <filter_inet+0x2fd>
    1b47:      	xorl	%eax, %eax
    1b49:      	movzbl	%al, %eax
    1b4c:      	jmp	0x1b5d <filter_inet+0x2fd>
    1b4e:      	movzwl	0x26(%rsi), %eax
    1b52:      	movl	%eax, (%rsp)
    1b55:      	movq	%rsp, %rsi
    1b58:      	callq	0xbb0 <filter_32ty_map>
    1b5d:      	addq	$0x48, %rsp
    1b61:      	popq	%rbx
    1b62:      	popq	%r12
    1b64:      	popq	%r14
    1b66:      	popq	%r15
    1b68:      	retq
    1b69:      	movl	0x4(%r12), %eax
    1b6e:      	andl	$-0x2, %eax
    1b71:      	cmpl	$0x18, %eax
    1b74:      	jmp	0x1b79 <filter_inet+0x319>
    1b76:      	testq	%rax, %rax
    1b79:      	sete	%al
    1b7c:      	movzbl	%al, %eax
    1b7f:      	jmp	0x1b5d <filter_inet+0x2fd>
    1b81:      	cmpl	$0x29, %edx
    1b84:      	jne	0x1b93 <filter_inet+0x333>
    1b86:      	testq	%r8, %r8
    1b89:      	je	0x1b93 <filter_inet+0x333>
    1b8b:      	movzbl	0x3a(%r8), %eax
    1b90:      	movl	%eax, (%rsp)
    1b93:      	cmpl	$0x29, %edx
    1b96:      	je	0x1b55 <filter_inet+0x2f5>
    1b98:      	cmpl	$0x7, %edx
    1b9b:      	je	0x1b55 <filter_inet+0x2f5>
    1b9d:      	xorl	%eax, %eax
    1b9f:      	jmp	0x1b5d <filter_inet+0x2fd>
    1ba1:      	nopw	%cs:(%rax,%rax)

0000000000001bb0 <filter_sockaddr_un>:
    1bb0:      	pushq	%rbx
    1bb1:      	subq	$0x10, %rsp
    1bb5:      	movq	%rsi, %rcx
    1bb8:      	addq	$0x4, %rsi
    1bbc:      	movzbl	0x3(%rcx), %edx
    1bc0:      	movl	0x4(%rdi), %r8d
    1bc4:      	xorl	%eax, %eax
    1bc6:      	cmpl	$0x19, %r8d
    1bca:      	jg	0x1c00 <filter_sockaddr_un+0x50>
    1bcc:      	leal	-0x3(%r8), %ecx
    1bd0:      	cmpl	$0x2, %ecx
    1bd3:      	jae	0x1c0e <filter_sockaddr_un+0x5e>
    1bd5:      	movq	%rdi, %rbx
    1bd8:      	callq	0x1c60 <filter_char_buf_equal>
    1bdd:      	movl	0x4(%rbx), %ecx
    1be0:      	cmpq	$0x25, %rcx
    1be4:      	ja	0x1bfa <filter_sockaddr_un+0x4a>
    1be6:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1bf0:      	btq	%rcx, %rdx
    1bf4:      	jae	0x1bfa <filter_sockaddr_un+0x4a>
    1bf6:      	xorq	$0x1, %rax
    1bfa:      	addq	$0x10, %rsp
    1bfe:      	popq	%rbx
    1bff:      	retq
    1c00:      	cmpl	$0x1c, %r8d
    1c04:      	je	0x1c44 <filter_sockaddr_un+0x94>
    1c06:      	cmpl	$0x1a, %r8d
    1c0a:      	je	0x1c14 <filter_sockaddr_un+0x64>
    1c0c:      	jmp	0x1bfa <filter_sockaddr_un+0x4a>
    1c0e:      	cmpl	$0x8, %r8d
    1c12:      	jne	0x1bfa <filter_sockaddr_un+0x4a>
    1c14:      	movl	0x10(%rdi), %eax
    1c17:      	movq	%rdi, %rbx
    1c1a:      	movl	%eax, %edi
    1c1c:      	callq	0x1fe0 <filter_char_buf_prefix>
    1c21:      	movl	0x4(%rbx), %ecx
    1c24:      	cmpq	$0x25, %rcx
    1c28:      	ja	0x1bfa <filter_sockaddr_un+0x4a>
    1c2a:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1c34:      	btq	%rcx, %rdx
    1c38:      	jae	0x1bfa <filter_sockaddr_un+0x4a>
    1c3a:      	xorq	$0x1, %rax
    1c3e:      	addq	$0x10, %rsp
    1c42:      	popq	%rbx
    1c43:      	retq
    1c44:      	movzwl	(%rcx), %eax
    1c47:      	movl	%eax, 0xc(%rsp)
    1c4b:      	leaq	0xc(%rsp), %rsi
    1c50:      	callq	0xbb0 <filter_32ty_map>
    1c55:      	addq	$0x10, %rsp
    1c59:      	popq	%rbx
    1c5a:      	retq
    1c5b:      	nopl	(%rax,%rax)

0000000000001c60 <filter_char_buf_equal>:
    1c60:      	pushq	%rbp
    1c61:      	pushq	%r15
    1c63:      	pushq	%r14
    1c65:      	pushq	%r13
    1c67:      	pushq	%r12
    1c69:      	pushq	%rbx
    1c6a:      	subq	$0x28, %rsp
    1c6e:      	movl	$0x0, 0x14(%rsp)
    1c76:      	cmpl	$0x1000, %edx           # imm = 0x1000
    1c7c:      	ja	0x1fce <filter_char_buf_equal+0x36e>
    1c82:      	movl	%edx, %ebp
    1c84:      	movzwl	%bp, %eax
    1c87:      	cmpl	$0x90, %eax
    1c8c:      	ja	0x1cd5 <filter_char_buf_equal+0x75>
    1c8e:      	testw	%bp, %bp
    1c91:      	je	0x1ca4 <filter_char_buf_equal+0x44>
    1c93:      	movl	$0x18, %ecx
    1c98:      	movl	%ebp, %eax
    1c9a:      	cltd
    1c9b:      	idivl	%ecx
    1c9d:      	movl	%ebp, %r14d
    1ca0:      	testl	%edx, %edx
    1ca2:      	je	0x1cc4 <filter_char_buf_equal+0x64>
    1ca4:      	movl	$0x18, %ecx
    1ca9:      	movl	%ebp, %eax
    1cab:      	cltd
    1cac:      	idivl	%ecx
    1cae:      	shll	$0x3, %eax
    1cb1:      	leal	(%rax,%rax,2), %eax
    1cb4:      	addl	$0x18, %eax
    1cb7:      	movzwl	%ax, %r14d
    1cbb:      	cmpl	$0x90, %r14d
    1cc2:      	ja	0x1d13 <filter_char_buf_equal+0xb3>
    1cc4:      	movl	%r14d, %eax
    1cc7:      	cltd
    1cc8:      	idivl	%ecx
    1cca:      	movl	%eax, %r15d
    1ccd:      	decl	%r15d
    1cd0:      	jmp	0x1d5e <filter_char_buf_equal+0xfe>
    1cd5:      	movl	$0x100, %r14d           # imm = 0x100
    1cdb:      	cmpl	$0x101, %eax            # imm = 0x101
    1ce0:      	jb	0x1d13 <filter_char_buf_equal+0xb3>
    1ce2:      	movl	$0x200, %r14d           # imm = 0x200
    1ce8:      	cmpl	$0x201, %eax            # imm = 0x201
    1ced:      	jb	0x1d13 <filter_char_buf_equal+0xb3>
    1cef:      	movl	$0x400, %r14d           # imm = 0x400
    1cf5:      	cmpl	$0x401, %eax            # imm = 0x401
    1cfa:      	jb	0x1d13 <filter_char_buf_equal+0xb3>
    1cfc:      	xorl	%r14d, %r14d
    1cff:      	cmpl	$0x801, %eax            # imm = 0x801
    1d04:      	setae	%r14b
    1d08:      	shll	$0xb, %r14d
    1d0c:      	addl	$0x800, %r14d           # imm = 0x800
    1d13:      	leal	-0x100(%r14), %eax
    1d1a:      	rorxl	$0x8, %eax, %eax
    1d20:      	cmpl	$0x2, %eax
    1d23:      	jg	0x1d36 <filter_char_buf_equal+0xd6>
    1d25:      	testl	%eax, %eax
    1d27:      	je	0x1d50 <filter_char_buf_equal+0xf0>
    1d29:      	cmpl	$0x1, %eax
    1d2c:      	jne	0x1d48 <filter_char_buf_equal+0xe8>
    1d2e:      	movl	$0x7, %r15d
    1d34:      	jmp	0x1d5e <filter_char_buf_equal+0xfe>
    1d36:      	cmpl	$0x3, %eax
    1d39:      	je	0x1d58 <filter_char_buf_equal+0xf8>
    1d3b:      	cmpl	$0x7, %eax
    1d3e:      	jne	0x1d48 <filter_char_buf_equal+0xe8>
    1d40:      	movl	$0x9, %r15d
    1d46:      	jmp	0x1d5e <filter_char_buf_equal+0xfe>
    1d48:      	movl	$0xa, %r15d
    1d4e:      	jmp	0x1d5e <filter_char_buf_equal+0xfe>
    1d50:      	movl	$0x6, %r15d
    1d56:      	jmp	0x1d5e <filter_char_buf_equal+0xfe>
    1d58:      	movl	$0x8, %r15d
    1d5e:      	movl	%r15d, %eax
    1d61:      	andl	$0xf, %eax
    1d64:      	movl	0x10(%rdi,%rax,4), %r13d
    1d69:      	cmpl	$-0x1, %r13d
    1d6d:      	je	0x1fce <filter_char_buf_equal+0x36e>
    1d73:      	movq	%rsi, 0x20(%rsp)
    1d78:      	movq	(%rip), %rdi            # 0x1d7f <filter_char_buf_equal+0x11f>
    1d7f:      	leaq	0x14(%rsp), %r12
    1d84:      	movl	$0x1, %eax
    1d89:      	movq	%r12, %rsi
    1d8c:      	callq	*%rax
    1d8e:      	movq	%rax, %rbx
    1d91:      	movq	(%rip), %rdi            # 0x1d98 <filter_char_buf_equal+0x138>
    1d98:      	movl	$0x1, %eax
    1d9d:      	movq	%r12, %rsi
    1da0:      	callq	*%rax
    1da2:      	movq	%rax, %rcx
    1da5:      	xorl	%eax, %eax
    1da7:      	movq	%rbx, 0x8(%rsp)
    1dac:      	testq	%rbx, %rbx
    1daf:      	je	0x1fd0 <filter_char_buf_equal+0x370>
    1db5:      	testq	%rcx, %rcx
    1db8:      	je	0x1fd0 <filter_char_buf_equal+0x370>
    1dbe:      	movq	%rcx, 0x18(%rsp)
    1dc3:      	cmpl	$0x5, %r15d
    1dc7:      	jg	0x1e0a <filter_char_buf_equal+0x1aa>
    1dc9:      	movq	0x8(%rsp), %rax
    1dce:      	movb	%bpl, (%rax)
    1dd1:      	leaq	0x1(%rax), %rdi
    1dd5:      	movl	%ebp, %r12d
    1dd8:      	movl	$0x4, %eax
    1ddd:      	movq	0x20(%rsp), %rdx
    1de2:      	movl	%ebp, %esi
    1de4:      	callq	*%rax
    1de6:      	subl	%ebp, %r14d
    1de9:      	jbe	0x1e4f <filter_char_buf_equal+0x1ef>
    1deb:      	movq	0x8(%rsp), %rax
    1df0:      	leaq	(%rax,%r12), %rdi
    1df4:      	incq	%rdi
    1df7:      	andl	$0xfff, %r14d           # imm = 0xFFF
    1dfe:      	movl	$0x4, %eax
    1e03:      	movq	0x18(%rsp), %rdx
    1e08:      	jmp	0x1e4a <filter_char_buf_equal+0x1ea>
    1e0a:      	movq	0x8(%rsp), %rax
    1e0f:      	movw	%bp, (%rax)
    1e12:      	leaq	0x2(%rax), %rdi
    1e16:      	movl	%ebp, %r12d
    1e19:      	movl	$0x4, %eax
    1e1e:      	movq	0x20(%rsp), %rdx
    1e23:      	movl	%ebp, %esi
    1e25:      	callq	*%rax
    1e27:      	subl	%ebp, %r14d
    1e2a:      	jbe	0x1e4f <filter_char_buf_equal+0x1ef>
    1e2c:      	movq	0x8(%rsp), %rax
    1e31:      	leaq	(%rax,%r12), %rdi
    1e35:      	addq	$0x2, %rdi
    1e39:      	andl	$0xfff, %r14d           # imm = 0xFFF
    1e40:      	movl	$0x4, %eax
    1e45:      	movq	0x18(%rsp), %rdx
    1e4a:      	movl	%r14d, %esi
    1e4d:      	callq	*%rax
    1e4f:      	movl	%r13d, 0x4(%rsp)
    1e54:      	cmpl	$0x4, %r15d
    1e58:      	jle	0x1e94 <filter_char_buf_equal+0x234>
    1e5a:      	cmpl	$0x7, %r15d
    1e5e:      	jg	0x1ece <filter_char_buf_equal+0x26e>
    1e60:      	cmpl	$0x5, %r15d
    1e64:      	je	0x1f82 <filter_char_buf_equal+0x322>
    1e6a:      	cmpl	$0x6, %r15d
    1e6e:      	je	0x1f49 <filter_char_buf_equal+0x2e9>
    1e74:      	cmpl	$0x7, %r15d
    1e78:      	jne	0x1fce <filter_char_buf_equal+0x36e>
    1e7e:      	movq	(%rip), %rdi            # 0x1e85 <filter_char_buf_equal+0x225>
    1e85:      	leaq	0x4(%rsp), %rcx
    1e8a:      	movl	$0x1, %eax
    1e8f:      	jmp	0x1fa6 <filter_char_buf_equal+0x346>
    1e94:      	cmpl	$0x1, %r15d
    1e98:      	jle	0x1efe <filter_char_buf_equal+0x29e>
    1e9a:      	cmpl	$0x2, %r15d
    1e9e:      	je	0x1f6f <filter_char_buf_equal+0x30f>
    1ea4:      	cmpl	$0x3, %r15d
    1ea8:      	je	0x1f36 <filter_char_buf_equal+0x2d6>
    1eae:      	cmpl	$0x4, %r15d
    1eb2:      	jne	0x1fce <filter_char_buf_equal+0x36e>
    1eb8:      	movq	(%rip), %rdi            # 0x1ebf <filter_char_buf_equal+0x25f>
    1ebf:      	leaq	0x4(%rsp), %rcx
    1ec4:      	movl	$0x1, %eax
    1ec9:      	jmp	0x1fa6 <filter_char_buf_equal+0x346>
    1ece:      	cmpl	$0x8, %r15d
    1ed2:      	je	0x1f95 <filter_char_buf_equal+0x335>
    1ed8:      	cmpl	$0x9, %r15d
    1edc:      	je	0x1f5c <filter_char_buf_equal+0x2fc>
    1ede:      	cmpl	$0xa, %r15d
    1ee2:      	jne	0x1fce <filter_char_buf_equal+0x36e>
    1ee8:      	movq	(%rip), %rdi            # 0x1eef <filter_char_buf_equal+0x28f>
    1eef:      	leaq	0x4(%rsp), %rcx
    1ef4:      	movl	$0x1, %eax
    1ef9:      	jmp	0x1fa6 <filter_char_buf_equal+0x346>
    1efe:      	testl	%r15d, %r15d
    1f01:      	je	0x1f23 <filter_char_buf_equal+0x2c3>
    1f03:      	cmpl	$0x1, %r15d
    1f07:      	jne	0x1fce <filter_char_buf_equal+0x36e>
    1f0d:      	movq	(%rip), %rdi            # 0x1f14 <filter_char_buf_equal+0x2b4>
    1f14:      	leaq	0x4(%rsp), %rcx
    1f19:      	movl	$0x1, %eax
    1f1e:      	jmp	0x1fa6 <filter_char_buf_equal+0x346>
    1f23:      	movq	(%rip), %rdi            # 0x1f2a <filter_char_buf_equal+0x2ca>
    1f2a:      	leaq	0x4(%rsp), %rcx
    1f2f:      	movl	$0x1, %eax
    1f34:      	jmp	0x1fa6 <filter_char_buf_equal+0x346>
    1f36:      	movq	(%rip), %rdi            # 0x1f3d <filter_char_buf_equal+0x2dd>
    1f3d:      	leaq	0x4(%rsp), %rcx
    1f42:      	movl	$0x1, %eax
    1f47:      	jmp	0x1fa6 <filter_char_buf_equal+0x346>
    1f49:      	movq	(%rip), %rdi            # 0x1f50 <filter_char_buf_equal+0x2f0>
    1f50:      	leaq	0x4(%rsp), %rcx
    1f55:      	movl	$0x1, %eax
    1f5a:      	jmp	0x1fa6 <filter_char_buf_equal+0x346>
    1f5c:      	movq	(%rip), %rdi            # 0x1f63 <filter_char_buf_equal+0x303>
    1f63:      	leaq	0x4(%rsp), %rcx
    1f68:      	movl	$0x1, %eax
    1f6d:      	jmp	0x1fa6 <filter_char_buf_equal+0x346>
    1f6f:      	movq	(%rip), %rdi            # 0x1f76 <filter_char_buf_equal+0x316>
    1f76:      	leaq	0x4(%rsp), %rcx
    1f7b:      	movl	$0x1, %eax
    1f80:      	jmp	0x1fa6 <filter_char_buf_equal+0x346>
    1f82:      	movq	(%rip), %rdi            # 0x1f89 <filter_char_buf_equal+0x329>
    1f89:      	leaq	0x4(%rsp), %rcx
    1f8e:      	movl	$0x1, %eax
    1f93:      	jmp	0x1fa6 <filter_char_buf_equal+0x346>
    1f95:      	movq	(%rip), %rdi            # 0x1f9c <filter_char_buf_equal+0x33c>
    1f9c:      	leaq	0x4(%rsp), %rcx
    1fa1:      	movl	$0x1, %eax
    1fa6:      	leaq	0x4(%rsp), %rsi
    1fab:      	callq	*%rax
    1fad:      	testq	%rax, %rax
    1fb0:      	je	0x1fce <filter_char_buf_equal+0x36e>
    1fb2:      	movq	%rax, %rdi
    1fb5:      	movl	$0x1, %eax
    1fba:      	movq	0x8(%rsp), %rsi
    1fbf:      	callq	*%rax
    1fc1:      	movq	%rax, %rcx
    1fc4:      	xorl	%eax, %eax
    1fc6:      	testq	%rcx, %rcx
    1fc9:      	setne	%al
    1fcc:      	jmp	0x1fd0 <filter_char_buf_equal+0x370>
    1fce:      	xorl	%eax, %eax
    1fd0:      	addq	$0x28, %rsp
    1fd4:      	popq	%rbx
    1fd5:      	popq	%r12
    1fd7:      	popq	%r13
    1fd9:      	popq	%r14
    1fdb:      	popq	%r15
    1fdd:      	popq	%rbp
    1fde:      	retq
    1fdf:      	nop

0000000000001fe0 <filter_char_buf_prefix>:
    1fe0:      	pushq	%rbp
    1fe1:      	pushq	%r15
    1fe3:      	pushq	%r14
    1fe5:      	pushq	%rbx
    1fe6:      	pushq	%rax
    1fe7:      	movl	%edx, %ebp
    1fe9:      	movq	%rsi, %rbx
    1fec:      	movl	%edi, 0x4(%rsp)
    1ff0:      	movl	$0x0, (%rsp)
    1ff7:      	movq	(%rip), %rdi            # 0x1ffe <filter_char_buf_prefix+0x1e>
    1ffe:      	leaq	0x4(%rsp), %rsi
    2003:      	movl	$0x1, %eax
    2008:      	callq	*%rax
    200a:      	movq	%rax, %r14
    200d:      	xorl	%eax, %eax
    200f:      	testl	%ebp, %ebp
    2011:      	je	0x2075 <filter_char_buf_prefix+0x95>
    2013:      	testq	%r14, %r14
    2016:      	je	0x2075 <filter_char_buf_prefix+0x95>
    2018:      	movq	(%rip), %rdi            # 0x201f <filter_char_buf_prefix+0x3f>
    201f:      	movq	%rsp, %rsi
    2022:      	movl	$0x1, %eax
    2027:      	callq	*%rax
    2029:      	testq	%rax, %rax
    202c:      	je	0x2073 <filter_char_buf_prefix+0x93>
    202e:      	cmpl	$0xff, %ebp
    2034:      	movl	$0xff, %esi
    2039:      	cmovbl	%ebp, %esi
    203c:      	leal	(,%rsi,8), %ecx
    2043:      	movl	%ecx, (%rax)
    2045:      	movq	%rax, %rdi
    2048:      	addq	$0x4, %rdi
    204c:      	movq	%rax, %r15
    204f:      	movl	$0x4, %eax
    2054:      	movq	%rbx, %rdx
    2057:      	callq	*%rax
    2059:      	movl	$0x1, %eax
    205e:      	movq	%r14, %rdi
    2061:      	movq	%r15, %rsi
    2064:      	callq	*%rax
    2066:      	movq	%rax, %rcx
    2069:      	xorl	%eax, %eax
    206b:      	testq	%rcx, %rcx
    206e:      	setne	%al
    2071:      	jmp	0x2075 <filter_char_buf_prefix+0x95>
    2073:      	xorl	%eax, %eax
    2075:      	addq	$0x8, %rsp
    2079:      	popq	%rbx
    207a:      	popq	%r14
    207c:      	popq	%r15
    207e:      	popq	%rbp
    207f:      	retq

0000000000002080 <filter_char_buf_postfix>:
    2080:      	pushq	%r15
    2082:      	pushq	%r14
    2084:      	pushq	%rbx
    2085:      	subq	$0x10, %rsp
    2089:      	movl	%edx, %ebx
    208b:      	movq	%rsi, %r14
    208e:      	movl	%edi, 0xc(%rsp)
    2092:      	movl	$0x0, 0x8(%rsp)
    209a:      	movq	(%rip), %rdi            # 0x20a1 <filter_char_buf_postfix+0x21>
    20a1:      	leaq	0xc(%rsp), %rsi
    20a6:      	movl	$0x1, %eax
    20ab:      	callq	*%rax
    20ad:      	movq	%rax, %r15
    20b0:      	xorl	%eax, %eax
    20b2:      	testl	%ebx, %ebx
    20b4:      	je	0x21c0 <filter_char_buf_postfix+0x140>
    20ba:      	testq	%r15, %r15
    20bd:      	je	0x21c0 <filter_char_buf_postfix+0x140>
    20c3:      	movq	(%rip), %rdi            # 0x20ca <filter_char_buf_postfix+0x4a>
    20ca:      	leaq	0x8(%rsp), %rsi
    20cf:      	movl	$0x1, %eax
    20d4:      	callq	*%rax
    20d6:      	testq	%rax, %rax
    20d9:      	je	0x21be <filter_char_buf_postfix+0x13e>
    20df:      	movq	%rax, %rsi
    20e2:      	cmpl	$0x7f, %ebx
    20e5:      	movl	$0x7f, %eax
    20ea:      	cmovbl	%ebx, %eax
    20ed:      	shll	$0x3, %eax
    20f0:      	movl	%eax, (%rsi)
    20f2:      	movl	%ebx, %eax
    20f4:      	leal	-0x4(%rbx), %ecx
    20f7:      	movq	%rsi, %rdx
    20fa:      	addq	$0x7, %rdx
    20fe:      	leal	-0x3(%rbx), %edi
    2101:      	leal	-0x2(%rbx), %r8d
    2105:      	decl	%ebx
    2107:      	movq	$-0x3, %r9
    210e:      	nop
    2110:      	leal	(%rbx,%r9), %r10d
    2114:      	addl	$0x3, %r10d
    2118:      	andl	$0xfff, %r10d           # imm = 0xFFF
    211f:      	movzbl	(%r14,%r10), %r10d
    2124:      	movb	%r10b, -0x3(%rdx)
    2128:      	leaq	(%rax,%r9), %r10
    212c:      	cmpq	$-0x2, %r10
    2130:      	je	0x21a7 <filter_char_buf_postfix+0x127>
    2132:      	leal	(%r8,%r9), %r11d
    2136:      	addl	$0x3, %r11d
    213a:      	andl	$0xfff, %r11d           # imm = 0xFFF
    2141:      	movzbl	(%r14,%r11), %r11d
    2146:      	movb	%r11b, -0x2(%rdx)
    214a:      	cmpq	$-0x1, %r10
    214e:      	je	0x21a7 <filter_char_buf_postfix+0x127>
    2150:      	leal	(%rdi,%r9), %r10d
    2154:      	addl	$0x3, %r10d
    2158:      	andl	$0xfff, %r10d           # imm = 0xFFF
    215f:      	movzbl	(%r14,%r10), %r10d
    2164:      	movb	%r10b, -0x1(%rdx)
    2168:      	movq	%rax, %r10
    216b:      	addq	%r9, %r10
    216e:      	je	0x21a7 <filter_char_buf_postfix+0x127>
    2170:      	cmpq	$-0x7f, %r9
    2174:      	je	0x21a7 <filter_char_buf_postfix+0x127>
    2176:      	leal	(%rcx,%r9), %r10d
    217a:      	addl	$0x3, %r10d
    217e:      	andl	$0xfff, %r10d           # imm = 0xFFF
    2185:      	movzbl	(%r14,%r10), %r10d
    218a:      	movb	%r10b, (%rdx)
    218d:      	addq	$0x4, %rdx
    2191:      	leaq	(%rax,%r9), %r10
    2195:      	addq	$-0x4, %r10
    2199:      	addq	$-0x4, %r9
    219d:      	cmpq	$-0x3, %r10
    21a1:      	jne	0x2110 <filter_char_buf_postfix+0x90>
    21a7:      	movl	$0x1, %eax
    21ac:      	movq	%r15, %rdi
    21af:      	callq	*%rax
    21b1:      	movq	%rax, %rcx
    21b4:      	xorl	%eax, %eax
    21b6:      	testq	%rcx, %rcx
    21b9:      	setne	%al
    21bc:      	jmp	0x21c0 <filter_char_buf_postfix+0x140>
    21be:      	xorl	%eax, %eax
    21c0:      	addq	$0x10, %rsp
    21c4:      	popq	%rbx
    21c5:      	popq	%r14
    21c7:      	popq	%r15
    21c9:      	retq
    21ca:      	nopw	(%rax,%rax)

00000000000021d0 <filter_file_type>:
    21d0:      	pushq	%rbx
    21d1:      	subq	$0x10, %rsp
    21d5:      	movw	$0x0, 0xe(%rsp)
    21dc:      	movl	(%rsi), %eax
    21de:      	cmpq	$0x1000, %rax           # imm = 0x1000
    21e4:      	ja	0x226c <filter_file_type+0x9c>
    21ea:      	movq	%rdi, %rbx
    21ed:      	leaq	(%rsi,%rax), %rcx
    21f1:      	addq	$0x8, %rcx
    21f5:      	leaq	0xe(%rsp), %rdi
    21fa:      	movl	$0x2, %edx
    21ff:      	movl	$0x4, %eax
    2204:      	movl	(%rsi), %ecx
    2206:      	leaq	(%rsi,%rcx), %rdx
    220a:      	addq	$0x8, %rdx
    220e:      	movl	$0x2, %esi
    2213:      	callq	*%rax
    2215:      	movl	0x10(%rbx), %edx
    2218:      	testl	%edx, %edx
    221a:      	je	0x226c <filter_file_type+0x9c>
    221c:      	movzwl	0xe(%rsp), %ecx
    2221:      	andl	$0xf000, %ecx           # imm = 0xF000
    2227:      	movl	$0x1, %eax
    222c:      	cmpl	%ecx, %edx
    222e:      	je	0x226e <filter_file_type+0x9e>
    2230:      	movl	0x8(%rbx), %edx
    2233:      	cmpl	$0xc, %edx
    2236:      	jbe	0x226c <filter_file_type+0x9c>
    2238:      	movl	0x14(%rbx), %esi
    223b:      	testl	%esi, %esi
    223d:      	je	0x226c <filter_file_type+0x9c>
    223f:      	cmpl	%ecx, %esi
    2241:      	je	0x226e <filter_file_type+0x9e>
    2243:      	cmpl	$0x11, %edx
    2246:      	jb	0x226c <filter_file_type+0x9c>
    2248:      	movl	0x18(%rbx), %esi
    224b:      	testl	%esi, %esi
    224d:      	je	0x226c <filter_file_type+0x9c>
    224f:      	cmpl	%ecx, %esi
    2251:      	je	0x226e <filter_file_type+0x9e>
    2253:      	cmpl	$0x15, %edx
    2256:      	jb	0x226c <filter_file_type+0x9c>
    2258:      	movl	0x1c(%rbx), %edx
    225b:      	testl	%edx, %edx
    225d:      	je	0x226c <filter_file_type+0x9c>
    225f:      	xorl	%eax, %eax
    2261:      	cmpl	%ecx, %edx
    2263:      	sete	%al
    2266:      	addq	$0x10, %rsp
    226a:      	popq	%rbx
    226b:      	retq
    226c:      	xorl	%eax, %eax
    226e:      	addq	$0x10, %rsp
    2272:      	popq	%rbx
    2273:      	retq
    2274:      	nopw	%cs:(%rax,%rax)

0000000000002280 <filter_char_substring>:
    2280:      	pushq	%rbp
    2281:      	pushq	%r15
    2283:      	pushq	%r14
    2285:      	pushq	%r13
    2287:      	pushq	%r12
    2289:      	pushq	%rbx
    228a:      	pushq	%rax
    228b:      	movq	%rsi, %r15
    228e:      	movq	%rdi, %r14
    2291:      	movl	%edx, %ebp
    2293:      	testl	%ecx, %ecx
    2295:      	je	0x236d <filter_char_substring+0xed>
    229b:      	testl	%edx, %edx
    229d:      	je	0x241d <filter_char_substring+0x19d>
    22a3:      	leaq	0x4(%rsp), %r13
    22a8:      	xorl	%ebx, %ebx
    22aa:      	xorl	%r12d, %r12d
    22ad:      	nopl	(%rax)
    22b0:      	movl	0x10(%r14,%rbx,4), %eax
    22b5:      	movl	%eax, 0x4(%rsp)
    22b9:      	movl	$0x1, %eax
    22be:      	movq	(%rip), %rdi            # 0x22c5 <filter_char_substring+0x45>
    22c5:      	movq	%r13, %rsi
    22c8:      	callq	*%rax
    22ca:      	testq	%rax, %rax
    22cd:      	je	0x24b0 <filter_char_substring+0x230>
    22d3:      	movq	%r15, %rdx
    22d6:      	xorl	%ecx, %ecx
    22d8:      	jmp	0x22eb <filter_char_substring+0x6b>
    22da:      	nopw	(%rax,%rax)
    22e0:      	incq	%rcx
    22e3:      	incq	%rdx
    22e6:      	cmpq	%rbp, %rcx
    22e9:      	je	0x2348 <filter_char_substring+0xc8>
    22eb:      	xorl	%esi, %esi
    22ed:      	nopl	(%rax)
    22f0:      	leaq	(%rcx,%rsi), %rdi
    22f4:      	cmpq	%rbp, %rdi
    22f7:      	jae	0x22e0 <filter_char_substring+0x60>
    22f9:      	movsbl	(%rax,%rsi), %edi
    22fd:      	testl	%edi, %edi
    22ff:      	je	0x2340 <filter_char_substring+0xc0>
    2301:      	movsbl	(%rdx,%rsi), %r9d
    2306:      	leal	-0x41(%r9), %r10d
    230a:      	movl	%r9d, %r8d
    230d:      	orl	$0x20, %r8d
    2311:      	cmpl	$0x1a, %r10d
    2315:      	cmovael	%r9d, %r8d
    2319:      	leal	-0x41(%rdi), %r10d
    231d:      	movl	%edi, %r9d
    2320:      	orl	$0x20, %r9d
    2324:      	cmpl	$0x1a, %r10d
    2328:      	cmovael	%edi, %r9d
    232c:      	cmpq	$0x62, %rsi
    2330:      	ja	0x22e0 <filter_char_substring+0x60>
    2332:      	incq	%rsi
    2335:      	cmpl	%r9d, %r8d
    2338:      	je	0x22f0 <filter_char_substring+0x70>
    233a:      	jmp	0x22e0 <filter_char_substring+0x60>
    233c:      	nopl	(%rax)
    2340:      	testl	%ecx, %ecx
    2342:      	jns	0x24c1 <filter_char_substring+0x241>
    2348:      	leal	0xc(%r12), %eax
    234d:      	cmpl	0x8(%r14), %eax
    2351:      	jae	0x24b0 <filter_char_substring+0x230>
    2357:      	addl	$0x4, %r12d
    235b:      	incq	%rbx
    235e:      	cmpq	$0x64, %rbx
    2362:      	jne	0x22b0 <filter_char_substring+0x30>
    2368:      	jmp	0x24b0 <filter_char_substring+0x230>
    236d:      	testl	%edx, %edx
    236f:      	je	0x2462 <filter_char_substring+0x1e2>
    2375:      	leaq	0x4(%rsp), %r13
    237a:      	xorl	%ebx, %ebx
    237c:      	xorl	%r12d, %r12d
    237f:      	nop
    2380:      	movl	0x10(%r14,%rbx,4), %eax
    2385:      	movl	%eax, 0x4(%rsp)
    2389:      	movl	$0x1, %eax
    238e:      	movq	(%rip), %rdi            # 0x2395 <filter_char_substring+0x115>
    2395:      	movq	%r13, %rsi
    2398:      	callq	*%rax
    239a:      	testq	%rax, %rax
    239d:      	je	0x24b0 <filter_char_substring+0x230>
    23a3:      	movq	%r15, %rdx
    23a6:      	xorl	%ecx, %ecx
    23a8:      	jmp	0x23bb <filter_char_substring+0x13b>
    23aa:      	nopw	(%rax,%rax)
    23b0:      	incq	%rcx
    23b3:      	incq	%rdx
    23b6:      	cmpq	%rbp, %rcx
    23b9:      	je	0x23f8 <filter_char_substring+0x178>
    23bb:      	xorl	%esi, %esi
    23bd:      	nopl	(%rax)
    23c0:      	leaq	(%rcx,%rsi), %rdi
    23c4:      	cmpq	%rbp, %rdi
    23c7:      	jae	0x23b0 <filter_char_substring+0x130>
    23c9:      	movzbl	(%rax,%rsi), %edi
    23cd:      	testb	%dil, %dil
    23d0:      	je	0x23f0 <filter_char_substring+0x170>
    23d2:      	cmpq	$0x62, %rsi
    23d6:      	ja	0x23b0 <filter_char_substring+0x130>
    23d8:      	leaq	0x1(%rsi), %r8
    23dc:      	cmpb	%dil, (%rdx,%rsi)
    23e0:      	movq	%r8, %rsi
    23e3:      	je	0x23c0 <filter_char_substring+0x140>
    23e5:      	jmp	0x23b0 <filter_char_substring+0x130>
    23e7:      	nopw	(%rax,%rax)
    23f0:      	testl	%ecx, %ecx
    23f2:      	jns	0x24c1 <filter_char_substring+0x241>
    23f8:      	leal	0xc(%r12), %eax
    23fd:      	cmpl	0x8(%r14), %eax
    2401:      	jae	0x24b0 <filter_char_substring+0x230>
    2407:      	addl	$0x4, %r12d
    240b:      	incq	%rbx
    240e:      	cmpq	$0x64, %rbx
    2412:      	jne	0x2380 <filter_char_substring+0x100>
    2418:      	jmp	0x24b0 <filter_char_substring+0x230>
    241d:      	movl	$0x10, %ebx
    2422:      	movq	(%rip), %r15            # 0x2429 <filter_char_substring+0x1a9>
    2429:      	leaq	0x4(%rsp), %r12
    242e:      	nop
    2430:      	movl	(%r14,%rbx), %eax
    2434:      	movl	%eax, 0x4(%rsp)
    2438:      	movl	$0x1, %eax
    243d:      	movq	%r15, %rdi
    2440:      	movq	%r12, %rsi
    2443:      	callq	*%rax
    2445:      	testq	%rax, %rax
    2448:      	je	0x24b0 <filter_char_substring+0x230>
    244a:      	addq	$0x4, %rbx
    244e:      	leal	-0x8(%rbx), %eax
    2451:      	cmpl	0x8(%r14), %eax
    2455:      	jae	0x24b0 <filter_char_substring+0x230>
    2457:      	cmpq	$0x1a0, %rbx            # imm = 0x1A0
    245e:      	jne	0x2430 <filter_char_substring+0x1b0>
    2460:      	jmp	0x24b0 <filter_char_substring+0x230>
    2462:      	movl	$0x10, %ebx
    2467:      	movq	(%rip), %r15            # 0x246e <filter_char_substring+0x1ee>
    246e:      	leaq	0x4(%rsp), %r12
    2473:      	nopw	%cs:(%rax,%rax)
    2480:      	movl	(%r14,%rbx), %eax
    2484:      	movl	%eax, 0x4(%rsp)
    2488:      	movl	$0x1, %eax
    248d:      	movq	%r15, %rdi
    2490:      	movq	%r12, %rsi
    2493:      	callq	*%rax
    2495:      	testq	%rax, %rax
    2498:      	je	0x24b0 <filter_char_substring+0x230>
    249a:      	addq	$0x4, %rbx
    249e:      	leal	-0x8(%rbx), %eax
    24a1:      	cmpl	0x8(%r14), %eax
    24a5:      	jae	0x24b0 <filter_char_substring+0x230>
    24a7:      	cmpq	$0x1a0, %rbx            # imm = 0x1A0
    24ae:      	jne	0x2480 <filter_char_substring+0x200>
    24b0:      	xorl	%eax, %eax
    24b2:      	addq	$0x8, %rsp
    24b6:      	popq	%rbx
    24b7:      	popq	%r12
    24b9:      	popq	%r13
    24bb:      	popq	%r14
    24bd:      	popq	%r15
    24bf:      	popq	%rbp
    24c0:      	retq
    24c1:      	movl	$0x1, %eax
    24c6:      	jmp	0x24b2 <filter_char_substring+0x232>
    24c8:      	nopl	(%rax,%rax)

00000000000024d0 <do_action>:
    24d0:      	pushq	%rbp
    24d1:      	pushq	%r15
    24d3:      	pushq	%r14
    24d5:      	pushq	%r13
    24d7:      	pushq	%r12
    24d9:      	pushq	%rbx
    24da:      	subq	$0x78, %rsp
    24de:      	movl	%r8d, %ebp
    24e1:      	movq	%rcx, 0x38(%rsp)
    24e6:      	movq	%rdx, %r15
    24e9:      	movl	%esi, %ebx
    24eb:      	movq	%rdi, %r12
    24ee:      	movl	%esi, %eax
    24f0:      	movslq	0x4(%rdx,%rax,4), %r14
    24f5:      	movl	$0x0, 0x54(%rsp)
    24fd:      	movq	(%rip), %rdi            # 0x2504 <do_action+0x34>
    2504:      	leaq	0x54(%rsp), %rsi
    2509:      	movl	$0x1, %eax
    250e:      	callq	*%rax
    2510:      	movq	%rax, %r13
    2513:      	xorl	%eax, %eax
    2515:      	testq	%r13, %r13
    2518:      	je	0x2de5 <do_action+0x915>
    251e:      	cmpl	$0x7, %r14d
    2522:      	jg	0x254c <do_action+0x7c>
    2524:      	cmpl	$0x3, %r14d
    2528:      	jg	0x2583 <do_action+0xb3>
    252a:      	cmpl	$0x1, %r14d
    252e:      	jg	0x26b5 <do_action+0x1e5>
    2534:      	testl	%r14d, %r14d
    2537:      	je	0x29c3 <do_action+0x4f3>
    253d:      	cmpl	$0x1, %r14d
    2541:      	je	0x26ce <do_action+0x1fe>
    2547:      	jmp	0x2ddd <do_action+0x90d>
    254c:      	cmpl	$0xb, %r14d
    2550:      	jg	0x2687 <do_action+0x1b7>
    2556:      	leal	-0xa(%r14), %ecx
    255a:      	cmpl	$0x2, %ecx
    255d:      	jb	0x27d9 <do_action+0x309>
    2563:      	cmpl	$0x8, %r14d
    2567:      	je	0x28c6 <do_action+0x3f6>
    256d:      	cmpl	$0x9, %r14d
    2571:      	jne	0x2ddd <do_action+0x90d>
    2577:      	incl	%ebx
    2579:      	movl	0x4(%r15,%rbx,4), %eax
    257e:      	jmp	0x2892 <do_action+0x3c2>
    2583:      	leal	-0x6(%r14), %eax
    2587:      	cmpl	$0x2, %eax
    258a:      	jb	0x28b6 <do_action+0x3e6>
    2590:      	cmpl	$0x4, %r14d
    2594:      	je	0x28d3 <do_action+0x403>
    259a:      	cmpl	$0x5, %r14d
    259e:      	jne	0x2ddd <do_action+0x90d>
    25a4:      	leal	0x1(%rbx), %eax
    25a7:      	movl	0x4(%r15,%rax,4), %eax
    25ac:      	addl	$0x2, %ebx
    25af:      	andl	$0x7, %eax
    25b2:      	cmpl	$0x4, %eax
    25b5:      	ja	0x2ddd <do_action+0x90d>
    25bb:      	cmpl	$0x0, 0x5ea0(%r13,%rax,4)
    25c4:      	jne	0x2ddd <do_action+0x90d>
    25ca:      	movl	0x4(%r15,%rbx,4), %r15d
    25cf:      	movq	0x5e78(%r13,%rax,8), %rax
    25d7:      	movl	$0x0, 0xc(%rsp)
    25df:      	andl	$0x7ff, %eax            # imm = 0x7FF
    25e4:      	movl	0x90(%r13,%rax), %eax
    25ec:      	movl	%eax, 0x8(%rsp)
    25f0:      	movl	$0xe, %eax
    25f5:      	callq	*%rax
    25f7:      	shrq	$0x20, %rax
    25fb:      	movq	%rax, (%rsp)
    25ff:      	movq	(%rip), %rdi            # 0x2606 <do_action+0x136>
    2606:      	movq	%rsp, %rsi
    2609:      	movl	$0x1, %eax
    260e:      	callq	*%rax
    2610:      	testq	%rax, %rax
    2613:      	je	0x2ddd <do_action+0x90d>
    2619:      	andl	$0x7, %r15d
    261d:      	cmpl	$0x4, %r15d
    2621:      	ja	0x2ddd <do_action+0x90d>
    2627:      	cmpl	$0x0, 0x5ea0(%r13,%r15,4)
    2630:      	jne	0x2ddd <do_action+0x90d>
    2636:      	movq	0x5e78(%r13,%r15,8), %rcx
    263e:      	movl	$0x0, 0xc(%rsp)
    2646:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    264c:      	movl	0x90(%r13,%rcx), %ecx
    2654:      	movl	%ecx, 0x8(%rsp)
    2658:      	movq	%rax, %r15
    265b:      	movl	$0xe, %eax
    2660:      	callq	*%rax
    2662:      	shrq	$0x20, %rax
    2666:      	movq	%rax, (%rsp)
    266a:      	movq	(%rip), %rdi            # 0x2671 <do_action+0x1a1>
    2671:      	xorl	%ecx, %ecx
    2673:      	movq	%rsp, %rsi
    2676:      	movl	$0x2, %eax
    267b:      	movq	%r15, %rdx
    267e:      	xorl	%ecx, %ecx
    2680:      	callq	*%rax
    2682:      	jmp	0x2ddd <do_action+0x90d>
    2687:      	cmpl	$0xc, %r14d
    268b:      	je	0x2a7f <do_action+0x5af>
    2691:      	cmpl	$0xd, %r14d
    2695:      	je	0x294b <do_action+0x47b>
    269b:      	cmpl	$0xe, %r14d
    269f:      	jne	0x2ddd <do_action+0x90d>
    26a5:      	addl	$0x2, %ebx
    26a8:      	movzbl	%bpl, %r12d
    26ac:      	xorq	$0x9, %r12
    26b0:      	jmp	0x2b4f <do_action+0x67f>
    26b5:      	movl	$0x9, %eax
    26ba:      	cmpl	$0x2, %r14d
    26be:      	je	0x2892 <do_action+0x3c2>
    26c4:      	cmpl	$0x3, %r14d
    26c8:      	jne	0x2ddd <do_action+0x90d>
    26ce:      	leal	0x1(%rbx), %eax
    26d1:      	movl	0x4(%r15,%rax,4), %ebp
    26d6:      	addl	$0x2, %ebx
    26d9:      	movl	0x4(%r15,%rbx,4), %r12d
    26de:      	movl	$0x0, 0x10(%rsp)
    26e6:      	movq	(%rip), %rdi            # 0x26ed <do_action+0x21d>
    26ed:      	leaq	0x10(%rsp), %rsi
    26f2:      	movl	$0x1, %eax
    26f7:      	callq	*%rax
    26f9:      	xorl	%r15d, %r15d
    26fc:      	testq	%rax, %rax
    26ff:      	je	0x2b90 <do_action+0x6c0>
    2705:      	movq	%rax, 0x38(%rsp)
    270a:      	andl	$0x7, %ebp
    270d:      	cmpl	$0x4, %ebp
    2710:      	movl	$0x0, %eax
    2715:      	ja	0x2b92 <do_action+0x6c2>
    271b:      	cmpl	$0x0, 0x5ea0(%r13,%rbp,4)
    2724:      	jne	0x2b92 <do_action+0x6c2>
    272a:      	movq	0x5e78(%r13,%rbp,8), %rax
    2732:      	movl	$0x0, 0xc(%rsp)
    273a:      	andl	$0x7ff, %eax            # imm = 0x7FF
    273f:      	movl	0x90(%r13,%rax), %eax
    2747:      	movl	%eax, 0x8(%rsp)
    274b:      	movl	$0xe, %eax
    2750:      	callq	*%rax
    2752:      	shrq	$0x20, %rax
    2756:      	movq	%rax, (%rsp)
    275a:      	cmpl	$0x1, %r14d
    275e:      	jne	0x2b13 <do_action+0x643>
    2764:      	andl	$0x7, %r12d
    2768:      	cmpl	$0x4, %r12d
    276c:      	ja	0x2b90 <do_action+0x6c0>
    2772:      	cmpl	$0x0, 0x5ea0(%r13,%r12,4)
    277b:      	movl	$0x0, %eax
    2780:      	jne	0x2b92 <do_action+0x6c2>
    2786:      	movq	0x5e78(%r13,%r12,8), %rax
    278e:      	andl	$0x7ff, %eax            # imm = 0x7FF
    2793:      	leaq	(%rax,%r13), %rdx
    2797:      	addq	$0x90, %rdx
    279e:      	movl	0x90(%r13,%rax), %esi
    27a6:      	andl	$0xfff, %esi            # imm = 0xFFF
    27ac:      	addq	$0x8, %rsi
    27b0:      	movl	$0x4, %eax
    27b5:      	movq	0x38(%rsp), %r12
    27ba:      	movq	%r12, %rdi
    27bd:      	callq	*%rax
    27bf:      	movq	(%rip), %rdi            # 0x27c6 <do_action+0x2f6>
    27c6:      	xorl	%r15d, %r15d
    27c9:      	movq	%rsp, %rsi
    27cc:      	movl	$0x2, %eax
    27d1:      	movq	%r12, %rdx
    27d4:      	jmp	0x2889 <do_action+0x3b9>
    27d9:      	incl	%ebx
    27db:      	movl	0x4(%r15,%rbx,4), %ecx
    27e0:      	andl	$0x7, %ecx
    27e3:      	xorl	%r15d, %r15d
    27e6:      	cmpl	$0x4, %ecx
    27e9:      	ja	0x2b92 <do_action+0x6c2>
    27ef:      	cmpl	$0x0, 0x5ea0(%r13,%rcx,4)
    27f8:      	jne	0x2b92 <do_action+0x6c2>
    27fe:      	movq	0x5e78(%r13,%rcx,8), %rcx
    2806:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    280c:      	movq	0xb8(%r13,%rcx), %rcx
    2814:      	movq	%rcx, 0x10(%rsp)
    2819:      	testq	%rcx, %rcx
    281c:      	je	0x2b92 <do_action+0x6c2>
    2822:      	cmpl	$0xa, %r14d
    2826:      	jne	0x2b7a <do_action+0x6aa>
    282c:      	movl	$0xe, %eax
    2831:      	callq	*%rax
    2833:      	movq	%rax, %r12
    2836:      	shrq	$0x20, %rax
    283a:      	movl	%eax, (%rsp)
    283d:      	movq	(%rip), %rdi            # 0x2844 <do_action+0x374>
    2844:      	movq	%rsp, %rsi
    2847:      	movl	$0x1, %eax
    284c:      	callq	*%rax
    284e:      	movq	%rax, %rcx
    2851:      	testq	%rax, %rax
    2854:      	movl	$0x0, %eax
    2859:      	je	0x2b92 <do_action+0x6c2>
    285f:      	movl	(%rcx), %eax
    2861:      	movl	%eax, (%rsp)
    2864:      	movl	%r12d, 0x4(%rsp)
    2869:      	movq	0x8(%rcx), %rax
    286d:      	movq	%rax, 0x8(%rsp)
    2872:      	movq	(%rip), %rdi            # 0x2879 <do_action+0x3a9>
    2879:      	xorl	%r15d, %r15d
    287c:      	leaq	0x10(%rsp), %rsi
    2881:      	movq	%rsp, %rdx
    2884:      	movl	$0x2, %eax
    2889:      	xorl	%ecx, %ecx
    288b:      	callq	*%rax
    288d:      	jmp	0x2b90 <do_action+0x6c0>
    2892:      	movl	$0x3, %r12d
    2898:      	testb	%bpl, %bpl
    289b:      	je	0x2b4f <do_action+0x67f>
    28a1:      	movslq	%eax, %rdi
    28a4:      	movl	$0x6d, %eax
    28a9:      	callq	*%rax
    28ab:      	movl	$0x2, %r12d
    28b1:      	jmp	0x2b4f <do_action+0x67f>
    28b6:      	incl	%ebx
    28b8:      	movl	0x4(%r15,%rbx,4), %eax
    28bd:      	movl	%eax, 0x78(%r13)
    28c1:      	jmp	0x2ddd <do_action+0x90d>
    28c6:      	movq	0x38(%rsp), %rax
    28cb:      	movb	$0x0, (%rax)
    28ce:      	jmp	0x2ddd <do_action+0x90d>
    28d3:      	incl	%ebx
    28d5:      	movl	$0x5, %r12d
    28db:      	testb	%bpl, %bpl
    28de:      	je	0x2b4f <do_action+0x67f>
    28e4:      	movl	%ebx, %eax
    28e6:      	movl	0x4(%r15,%rax,4), %ebp
    28eb:      	movl	%ebp, 0x28(%rsp)
    28ef:      	movl	$0xe, %eax
    28f4:      	callq	*%rax
    28f6:      	movq	%rax, 0x10(%rsp)
    28fb:      	movq	(%rip), %rdi            # 0x2902 <do_action+0x432>
    2902:      	leaq	0x10(%rsp), %rsi
    2907:      	movl	$0x1, %eax
    290c:      	callq	*%rax
    290e:      	testq	%rax, %rax
    2911:      	je	0x2af5 <do_action+0x625>
    2917:      	movq	%rax, %r15
    291a:      	movl	$0xe0011, (%rsp)        # imm = 0xE0011
    2921:      	movq	$0x35c, 0x4(%rsp)       # imm = 0x35C
    292a:      	movq	(%rip), %rdi            # 0x2931 <do_action+0x461>
    2931:      	movq	%rsp, %rsi
    2934:      	movl	$0x1, %eax
    2939:      	callq	*%rax
    293b:      	testq	%rax, %rax
    293e:      	je	0x2b24 <do_action+0x654>
    2944:      	incl	(%rax)
    2946:      	jmp	0x2b46 <do_action+0x676>
    294b:      	movl	$0xe, %eax
    2950:      	callq	*%rax
    2952:      	movq	%rax, 0x20(%rsp)
    2957:      	movq	(%rip), %rdi            # 0x295e <do_action+0x48e>
    295e:      	leaq	0x20(%rsp), %rsi
    2963:      	movl	$0x1, %eax
    2968:      	callq	*%rax
    296a:      	testq	%rax, %rax
    296d:      	je	0x2ddd <do_action+0x90d>
    2973:      	movq	0x4(%rax), %rax
    2977:      	movq	%rax, 0x10(%rsp)
    297c:      	movl	$0x2, 0x18(%rsp)
    2984:      	movq	(%rip), %rdi            # 0x298b <do_action+0x4bb>
    298b:      	leaq	0x10(%rsp), %rsi
    2990:      	movl	$0x1, %eax
    2995:      	callq	*%rax
    2997:      	movl	$0x1, 0x2c(%rsp)
    299f:      	testq	%rax, %rax
    29a2:      	je	0x2a8f <do_action+0x5bf>
    29a8:      	lock
    29a9:      	incl	(%rax)
    29ab:      	movq	(%rip), %rdi            # 0x29b2 <do_action+0x4e2>
    29b2:      	leaq	0x20(%rsp), %rsi
    29b7:      	movl	$0x3, %eax
    29bc:      	callq	*%rax
    29be:      	jmp	0x2ddd <do_action+0x90d>
    29c3:      	leal	0x1(%rbx), %eax
    29c6:      	movl	0x4(%r15,%rax,4), %ebp
    29cb:      	leal	0x2(%rbx), %eax
    29ce:      	movl	0x4(%r15,%rax,4), %eax
    29d3:      	movl	%eax, 0x30(%rsp)
    29d7:      	movl	$0x7d, %eax
    29dc:      	callq	*%rax
    29de:      	movq	%rax, 0x68(%rsp)
    29e3:      	movq	%rax, (%rsp)
    29e7:      	movl	$0x0, 0x20(%rsp)
    29ef:      	movq	%rbp, 0x70(%rsp)
    29f4:      	testq	%rbp, %rbp
    29f7:      	je	0x2d6f <do_action+0x89f>
    29fd:      	movq	(%rip), %rdi            # 0x2a04 <do_action+0x534>
    2a04:      	leaq	0x20(%rsp), %rsi
    2a09:      	movl	$0x1, %eax
    2a0e:      	callq	*%rax
    2a10:      	testq	%rax, %rax
    2a13:      	je	0x2d6f <do_action+0x89f>
    2a19:      	movq	%rax, 0x48(%rsp)
    2a1e:      	movq	%rax, %rbp
    2a21:      	movq	(%rip), %rdi            # 0x2a28 <do_action+0x558>
    2a28:      	leaq	0x20(%rsp), %rsi
    2a2d:      	movl	$0x1, %eax
    2a32:      	callq	*%rax
    2a34:      	movq	%rax, %rdx
    2a37:      	movq	0x60(%r13), %rax
    2a3b:      	movq	%rax, (%rbp)
    2a3f:      	movq	0x70(%r13), %rax
    2a43:      	movq	%rbp, 0x40(%rsp)
    2a48:      	movq	%rax, 0x8(%rbp)
    2a4c:      	xorl	%eax, %eax
    2a4e:      	movq	%rax, 0x60(%rsp)
    2a53:      	movl	$0x0, %eax
    2a58:      	movl	0x30(%rsp), %ecx
    2a5c:      	cmpl	$0x2, %ecx
    2a5f:      	je	0x2ba4 <do_action+0x6d4>
    2a65:      	cmpl	$0x1, %ecx
    2a68:      	je	0x2ba0 <do_action+0x6d0>
    2a6e:      	testl	%ecx, %ecx
    2a70:      	jne	0x2d6f <do_action+0x89f>
    2a76:      	movl	0x7c(%r13), %eax
    2a7a:      	jmp	0x2ba4 <do_action+0x6d4>
    2a7f:      	addl	$0x3, %ebx
    2a82:      	movzbl	%bpl, %r12d
    2a86:      	xorq	$0x7, %r12
    2a8a:      	jmp	0x2b4f <do_action+0x67f>
    2a8f:      	movq	(%rip), %rdi            # 0x2a96 <do_action+0x5c6>
    2a96:      	leaq	0x10(%rsp), %rsi
    2a9b:      	leaq	0x2c(%rsp), %rdx
    2aa0:      	movl	$0x1, %ecx
    2aa5:      	movl	$0x2, %eax
    2aaa:      	callq	*%rax
    2aac:      	testq	%rax, %rax
    2aaf:      	je	0x29ab <do_action+0x4db>
    2ab5:      	movq	%rax, %r15
    2ab8:      	negl	%eax
    2aba:      	movw	%ax, (%rsp)
    2abe:      	movw	$0x3, 0x2(%rsp)
    2ac5:      	movabsq	$0x20000003b, %rax      # imm = 0x20000003B
    2acf:      	movq	%rax, 0x4(%rsp)
    2ad4:      	movq	(%rip), %rdi            # 0x2adb <do_action+0x60b>
    2adb:      	movq	%rsp, %rsi
    2ade:      	movl	$0x1, %eax
    2ae3:      	callq	*%rax
    2ae5:      	testq	%rax, %rax
    2ae8:      	je	0x2df4 <do_action+0x924>
    2aee:      	incl	(%rax)
    2af0:      	jmp	0x2e16 <do_action+0x946>
    2af5:      	movq	(%rip), %rdi            # 0x2afc <do_action+0x62c>
    2afc:      	xorl	%ecx, %ecx
    2afe:      	leaq	0x10(%rsp), %rsi
    2b03:      	leaq	0x28(%rsp), %rdx
    2b08:      	movl	$0x2, %eax
    2b0d:      	xorl	%ecx, %ecx
    2b0f:      	callq	*%rax
    2b11:      	jmp	0x2b49 <do_action+0x679>
    2b13:      	movq	(%rip), %rdi            # 0x2b1a <do_action+0x64a>
    2b1a:      	movq	%rsp, %rsi
    2b1d:      	movl	$0x3, %eax
    2b22:      	jmp	0x2b8b <do_action+0x6bb>
    2b24:      	movl	$0x1, 0x20(%rsp)
    2b2c:      	movq	(%rip), %rdi            # 0x2b33 <do_action+0x663>
    2b33:      	xorl	%ecx, %ecx
    2b35:      	movq	%rsp, %rsi
    2b38:      	leaq	0x20(%rsp), %rdx
    2b3d:      	movl	$0x2, %eax
    2b42:      	xorl	%ecx, %ecx
    2b44:      	callq	*%rax
    2b46:      	movl	%ebp, (%r15)
    2b49:      	movl	$0x4, %r12d
    2b4f:      	movl	$0x0, (%rsp)
    2b56:      	movq	(%rip), %rdi            # 0x2b5d <do_action+0x68d>
    2b5d:      	movq	%rsp, %rsi
    2b60:      	movl	$0x1, %eax
    2b65:      	callq	*%rax
    2b67:      	testq	%rax, %rax
    2b6a:      	je	0x2ddd <do_action+0x90d>
    2b70:      	lock
    2b71:      	incq	(%rax,%r12,8)
    2b75:      	jmp	0x2ddd <do_action+0x90d>
    2b7a:      	movq	(%rip), %rdi            # 0x2b81 <do_action+0x6b1>
    2b81:      	leaq	0x10(%rsp), %rsi
    2b86:      	movl	$0x3, %eax
    2b8b:      	callq	*%rax
    2b8d:      	movq	%rax, %r15
    2b90:      	xorl	%eax, %eax
    2b92:      	testl	%r15d, %r15d
    2b95:      	jne	0x2de5 <do_action+0x915>
    2b9b:      	jmp	0x2ddd <do_action+0x90d>
    2ba0:      	movl	0x10(%r13), %eax
    2ba4:      	movq	%r12, 0x30(%rsp)
    2ba9:      	movl	%eax, %eax
    2bab:      	movq	0x40(%rsp), %rcx
    2bb0:      	movq	%rax, 0x10(%rcx)
    2bb4:      	movq	0x48(%rsp), %rdi
    2bb9:      	addq	$0x18, %rdi
    2bbd:      	movl	$0xc8, %ecx
    2bc2:      	movl	$0x4, %eax
    2bc7:      	movq	%rdi, 0x48(%rsp)
    2bcc:      	movl	$0xc8, %esi
    2bd1:      	callq	*%rax
    2bd3:      	xorl	%r12d, %r12d
    2bd6:      	movq	%r13, 0x58(%rsp)
    2bdb:      	jmp	0x2beb <do_action+0x71b>
    2bdd:      	addq	$0x4, %r12
    2be1:      	cmpq	$0x14, %r12
    2be5:      	je	0x2d18 <do_action+0x848>
    2beb:      	movl	$0x0, 0x10(%rsp)
    2bf3:      	movl	$0x1, %eax
    2bf8:      	movq	(%rip), %rdi            # 0x2bff <do_action+0x72f>
    2bff:      	leaq	0x10(%rsp), %rsi
    2c04:      	callq	*%rax
    2c06:      	testq	%rax, %rax
    2c09:      	je	0x2d18 <do_action+0x848>
    2c0f:      	movq	%rax, %rsi
    2c12:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    2c19:      	movl	$0x1, %eax
    2c1e:      	movq	(%rip), %rdi            # 0x2c25 <do_action+0x755>
    2c25:      	callq	*%rax
    2c27:      	testq	%rax, %rax
    2c2a:      	je	0x2d18 <do_action+0x848>
    2c30:      	cmpl	$-0x1, 0x40(%rax,%r12)
    2c36:      	je	0x2d18 <do_action+0x848>
    2c3c:      	movq	0x5e78(%r13,%r12,2), %rax
    2c44:      	movl	0x4(%r13), %ecx
    2c48:      	cmpq	%rcx, %rax
    2c4b:      	jge	0x2d18 <do_action+0x848>
    2c51:      	cmpq	$0x10, %r12
    2c55:      	je	0x2cb8 <do_action+0x7e8>
    2c57:      	movl	$0x0, 0x10(%rsp)
    2c5f:      	movl	$0x1, %eax
    2c64:      	movq	(%rip), %rdi            # 0x2c6b <do_action+0x79b>
    2c6b:      	leaq	0x10(%rsp), %rsi
    2c70:      	callq	*%rax
    2c72:      	testq	%rax, %rax
    2c75:      	je	0x2cb0 <do_action+0x7e0>
    2c77:      	movq	%rax, %rsi
    2c7a:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    2c81:      	movl	$0x1, %eax
    2c86:      	movq	(%rip), %rdi            # 0x2c8d <do_action+0x7bd>
    2c8d:      	callq	*%rax
    2c8f:      	testq	%rax, %rax
    2c92:      	je	0x2cb0 <do_action+0x7e0>
    2c94:      	cmpl	$-0x1, 0x44(%rax,%r12)
    2c9a:      	movq	0x5e78(%r13,%r12,2), %rax
    2ca2:      	je	0x2cb8 <do_action+0x7e8>
    2ca4:      	movl	0x5e80(%r13,%r12,2), %ebp
    2cac:      	subl	%eax, %ebp
    2cae:      	jmp	0x2cc1 <do_action+0x7f1>
    2cb0:      	movq	0x5e78(%r13,%r12,2), %rax
    2cb8:      	movl	0x4(%r13), %ebp
    2cbc:      	subl	%eax, %ebp
    2cbe:      	addl	$0x4, %ebp
    2cc1:      	testl	%ebp, %ebp
    2cc3:      	jle	0x2bdd <do_action+0x70d>
    2cc9:      	addl	$0x3ffc, %eax           # imm = 0x3FFC
    2cce:      	andl	$0x3fff, %eax           # imm = 0x3FFF
    2cd3:      	cmpl	$0x28, %ebp
    2cd6:      	movl	$0x28, %ecx
    2cdb:      	cmovgel	%ecx, %ebp
    2cde:      	movzbl	0x60(%rsp), %r13d
    2ce4:      	movq	0x48(%rsp), %rcx
    2ce9:      	leaq	(%rcx,%r13), %rdi
    2ced:      	movq	0x58(%rsp), %rcx
    2cf2:      	leaq	(%rcx,%rax), %rdx
    2cf6:      	addq	$0x90, %rdx
    2cfd:      	movl	$0x4, %eax
    2d02:      	movl	%ebp, %esi
    2d04:      	callq	*%rax
    2d06:      	addl	%r13d, %ebp
    2d09:      	movq	0x58(%rsp), %r13
    2d0e:      	movq	%rbp, 0x60(%rsp)
    2d13:      	jmp	0x2bdd <do_action+0x70d>
    2d18:      	movq	(%rip), %rdi            # 0x2d1f <do_action+0x84f>
    2d1f:      	movl	$0x1, %eax
    2d24:      	movq	0x40(%rsp), %rsi
    2d29:      	callq	*%rax
    2d2b:      	testq	%rax, %rax
    2d2e:      	je	0x2d50 <do_action+0x880>
    2d30:      	imulq	$-0xf4240, 0x70(%rsp), %rcx # imm = 0xFFF0BDC0
    2d39:      	movq	0x68(%rsp), %rdx
    2d3e:      	addq	%rcx, %rdx
    2d41:      	cmpq	%rdx, (%rax)
    2d44:      	jbe	0x2d50 <do_action+0x880>
    2d46:      	movq	0x38(%rsp), %rax
    2d4b:      	movb	$0x0, (%rax)
    2d4e:      	jmp	0x2d6a <do_action+0x89a>
    2d50:      	movq	(%rip), %rdi            # 0x2d57 <do_action+0x887>
    2d57:      	xorl	%ecx, %ecx
    2d59:      	movq	%rsp, %rdx
    2d5c:      	movl	$0x2, %eax
    2d61:      	movq	0x40(%rsp), %rsi
    2d66:      	xorl	%ecx, %ecx
    2d68:      	callq	*%rax
    2d6a:      	movq	0x30(%rsp), %r12
    2d6f:      	leal	0x3(%rbx), %eax
    2d72:      	cmpl	$0x0, 0x4(%r15,%rax,4)
    2d78:      	je	0x2d9b <do_action+0x8cb>
    2d7a:      	orb	$0x2, 0x1(%r13)
    2d7f:      	movq	(%rip), %rsi            # 0x2d86 <do_action+0x8b6>
    2d86:      	xorl	%ecx, %ecx
    2d88:      	movl	$0x1b, %eax
    2d8d:      	movq	%r12, %rdi
    2d90:      	xorl	%edx, %edx
    2d92:      	callq	*%rax
    2d94:      	movq	%rax, 0x80(%r13)
    2d9b:      	leal	0x4(%rbx), %eax
    2d9e:      	cmpl	$0x0, 0x4(%r15,%rax,4)
    2da4:      	je	0x2dcd <do_action+0x8fd>
    2da6:      	orb	$0x4, 0x1(%r13)
    2dab:      	movq	(%rip), %rsi            # 0x2db2 <do_action+0x8e2>
    2db2:      	movl	$0x100, %ecx            # imm = 0x100
    2db7:      	movl	$0x1b, %eax
    2dbc:      	movl	$0x100, %edx            # imm = 0x100
    2dc1:      	movq	%r12, %rdi
    2dc4:      	callq	*%rax
    2dc6:      	movq	%rax, 0x88(%r13)
    2dcd:      	addl	$0x5, %ebx
    2dd0:      	cmpl	$0x0, 0x4(%r15,%rbx,4)
    2dd6:      	je	0x2ddd <do_action+0x90d>
    2dd8:      	orb	$0x8, 0x1(%r13)
    2ddd:      	movq	%r14, 0x70(%r13)
    2de1:      	incl	%ebx
    2de3:      	movl	%ebx, %eax
    2de5:      	addq	$0x78, %rsp
    2de9:      	popq	%rbx
    2dea:      	popq	%r12
    2dec:      	popq	%r13
    2dee:      	popq	%r14
    2df0:      	popq	%r15
    2df2:      	popq	%rbp
    2df3:      	retq
    2df4:      	movl	$0x1, 0x28(%rsp)
    2dfc:      	movq	(%rip), %rdi            # 0x2e03 <do_action+0x933>
    2e03:      	xorl	%ecx, %ecx
    2e05:      	movq	%rsp, %rsi
    2e08:      	leaq	0x28(%rsp), %rdx
    2e0d:      	movl	$0x2, %eax
    2e12:      	xorl	%ecx, %ecx
    2e14:      	callq	*%rax
    2e16:      	testl	%r15d, %r15d
    2e19:      	je	0x29ab <do_action+0x4db>
    2e1f:      	movq	(%rip), %rdi            # 0x2e26 <do_action+0x956>
    2e26:      	leaq	0x10(%rsp), %rsi
    2e2b:      	movl	$0x1, %eax
    2e30:      	callq	*%rax
    2e32:      	testq	%rax, %rax
    2e35:      	je	0x29ab <do_action+0x4db>
    2e3b:      	movl	0x2c(%rsp), %ecx
    2e3f:      	lock
    2e40:      	addl	%ecx, (%rax)
    2e42:      	jmp	0x29ab <do_action+0x4db>

Disassembly of section lsm:

0000000000000000 <generic_lsm_setup_event>:
       0:      	pushq	%r14
       2:      	pushq	%rbx
       3:      	subq	$0x18, %rsp
       7:      	movq	%rdi, %rbx
       a:      	movl	$0x0, 0x14(%rsp)
      12:      	movq	(%rip), %rdi            # 0x19 <generic_lsm_setup_event+0x19>
      19:      	leaq	0x14(%rsp), %rsi
      1e:      	movl	$0x1, %eax
      23:      	callq	*%rax
      25:      	testq	%rax, %rax
      28:      	je	0x1be <generic_lsm_setup_event+0x1be>
      2e:      	movq	%rax, %r14
      31:      	leaq	0x5ef8(%rax), %rsi
      38:      	movq	(%rip), %rdi            # 0x3f <generic_lsm_setup_event+0x3f>
      3f:      	movl	$0x1, %eax
      44:      	callq	*%rax
      46:      	testq	%rax, %rax
      49:      	je	0x1be <generic_lsm_setup_event+0x1be>
      4f:      	leaq	0x8(%rsp), %rdi
      54:      	movl	$0x8, %ecx
      59:      	movl	$0x4, %eax
      5e:      	movl	$0x8, %esi
      63:      	movq	%rbx, %rdx
      66:      	callq	*%rax
      68:      	movq	0x8(%rsp), %rax
      6d:      	movq	%rax, 0x5e50(%r14)
      74:      	leaq	0x8(%rbx), %rdx
      78:      	leaq	0x8(%rsp), %rdi
      7d:      	movl	$0x8, %ecx
      82:      	movl	$0x4, %eax
      87:      	movl	$0x8, %esi
      8c:      	callq	*%rax
      8e:      	movq	0x8(%rsp), %rax
      93:      	movq	%rax, 0x5e58(%r14)
      9a:      	leaq	0x10(%rbx), %rdx
      9e:      	leaq	0x8(%rsp), %rdi
      a3:      	movl	$0x8, %ecx
      a8:      	movl	$0x4, %eax
      ad:      	movl	$0x8, %esi
      b2:      	callq	*%rax
      b4:      	movq	0x8(%rsp), %rax
      b9:      	movq	%rax, 0x5e60(%r14)
      c0:      	leaq	0x18(%rbx), %rdx
      c4:      	leaq	0x8(%rsp), %rdi
      c9:      	movl	$0x8, %ecx
      ce:      	movl	$0x4, %eax
      d3:      	movl	$0x8, %esi
      d8:      	callq	*%rax
      da:      	movq	0x8(%rsp), %rax
      df:      	movq	%rax, 0x5e68(%r14)
      e6:      	leaq	0x20(%rbx), %rdx
      ea:      	leaq	0x8(%rsp), %rdi
      ef:      	movl	$0x8, %ecx
      f4:      	movl	$0x4, %eax
      f9:      	movl	$0x8, %esi
      fe:      	callq	*%rax
     100:      	movq	0x8(%rsp), %rax
     105:      	movq	%rax, 0x5e70(%r14)
     10c:      	movb	$0x10, (%r14)
     110:      	movw	$0x0, 0x2(%r14)
     117:      	movl	$0x0, 0x4(%r14)
     11f:      	movl	$0x7d, %eax
     124:      	callq	*%rax
     126:      	movq	%rax, 0x8(%r14)
     12a:      	movq	$0x0, 0x70(%r14)
     132:      	movl	$0x0, 0x14(%r14)
     13a:      	movl	$0xe, %eax
     13f:      	callq	*%rax
     141:      	movl	%eax, 0x7c(%r14)
     145:      	movl	$0x0, 0x8(%rsp)
     14d:      	movq	(%rip), %rdi            # 0x154 <generic_lsm_setup_event+0x154>
     154:      	leaq	0x8(%rsp), %rsi
     159:      	movl	$0x1, %eax
     15e:      	callq	*%rax
     160:      	testq	%rax, %rax
     163:      	je	0x188 <generic_lsm_setup_event+0x188>
     165:      	movq	%rax, %rsi
     168:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
     16f:      	movq	(%rip), %rdi            # 0x176 <generic_lsm_setup_event+0x176>
     176:      	movl	$0x1, %eax
     17b:      	callq	*%rax
     17d:      	testq	%rax, %rax
     180:      	je	0x188 <generic_lsm_setup_event+0x188>
     182:      	cmpl	$-0x1, 0x40(%rax)
     186:      	jne	0x1a3 <generic_lsm_setup_event+0x1a3>
     188:      	movq	(%rip), %rsi            # 0x18f <generic_lsm_setup_event+0x18f>
     18f:      	movl	$0x3, %ecx
     194:      	movl	$0xc, %eax
     199:      	movq	%rbx, %rdi
     19c:      	movl	$0x3, %edx
     1a1:      	callq	*%rax
     1a3:      	movq	(%rip), %rsi            # 0x1aa <generic_lsm_setup_event+0x1aa>
     1aa:      	movl	$0x1, %ecx
     1af:      	movl	$0xc, %eax
     1b4:      	movq	%rbx, %rdi
     1b7:      	movl	$0x1, %edx
     1bc:      	callq	*%rax
     1be:      	xorl	%eax, %eax
     1c0:      	addq	$0x18, %rsp
     1c4:      	popq	%rbx
     1c5:      	popq	%r14
     1c7:      	retq
     1c8:      	nopl	(%rax,%rax)

00000000000001d0 <generic_lsm_process_event>:
     1d0:      	pushq	%rbp
     1d1:      	pushq	%r15
     1d3:      	pushq	%r14
     1d5:      	pushq	%r13
     1d7:      	pushq	%r12
     1d9:      	pushq	%rbx
     1da:      	subq	$0x108, %rsp            # imm = 0x108
     1e1:      	movq	%rdi, %rbx
     1e4:      	movl	$0x0, 0xec(%rsp)
     1ef:      	movq	(%rip), %rdi            # 0x1f6 <generic_lsm_process_event+0x26>
     1f6:      	leaq	0xec(%rsp), %rsi
     1fe:      	movl	$0x1, %eax
     203:      	callq	*%rax
     205:      	testq	%rax, %rax
     208:      	je	0x3383 <generic_lsm_process_event+0x31b3>
     20e:      	movq	%rax, %r14
     211:      	movl	0x5efc(%rax), %r13d
     218:      	movl	0x4(%rax), %ebp
     21b:      	cmpq	$0x2327, %rbp           # imm = 0x2327
     222:      	ja	0x32e4 <generic_lsm_process_event+0x3114>
     228:      	movl	$0x0, 0xf0(%rsp)
     233:      	movq	(%rip), %rdi            # 0x23a <generic_lsm_process_event+0x6a>
     23a:      	leaq	0xf0(%rsp), %rsi
     242:      	movl	$0x1, %eax
     247:      	callq	*%rax
     249:      	testq	%rax, %rax
     24c:      	je	0x32e4 <generic_lsm_process_event+0x3114>
     252:      	movq	%rax, %r15
     255:      	leaq	0x5ef8(%rax), %rsi
     25c:      	movq	(%rip), %rdi            # 0x263 <generic_lsm_process_event+0x93>
     263:      	movl	$0x1, %eax
     268:      	callq	*%rax
     26a:      	cmpl	$0x4, %r13d
     26e:      	jg	0x32e4 <generic_lsm_process_event+0x3114>
     274:      	testq	%rax, %rax
     277:      	je	0x32e4 <generic_lsm_process_event+0x3114>
     27d:      	movq	%rbp, 0x18(%rsp)
     282:      	movl	%r13d, %edx
     285:      	andl	$0x7, %edx
     288:      	movl	%edx, %ebp
     28a:      	movl	0x4(%rax,%rbp,4), %r12d
     28f:      	movslq	0x18(%rax,%rbp,4), %rsi
     294:      	movl	%esi, %ecx
     296:      	movl	$0x0, 0x5ea0(%r15,%rbp,4)
     2a2:      	testl	$0x100, %esi            # imm = 0x100
     2a8:      	movq	%rdx, (%rsp)
     2ac:      	movq	%rcx, 0xc8(%rsp)
     2b4:      	movq	%rsi, 0x28(%rsp)
     2b9:      	jne	0x2d6 <generic_lsm_process_event+0x106>
     2bb:      	testb	%cl, %cl
     2bd:      	js	0x2e9 <generic_lsm_process_event+0x119>
     2bf:      	testb	$0x40, %sil
     2c3:      	jne	0x2f9 <generic_lsm_process_event+0x129>
     2c5:      	movl	0x40(%rax,%rdx,4), %ecx
     2c9:      	andl	$0x7, %ecx
     2cc:      	movq	0x5e50(%r15,%rcx,8), %rsi
     2d4:      	jmp	0x31d <generic_lsm_process_event+0x14d>
     2d6:      	movq	$0x0, 0xd8(%rsp)
     2e2:      	xorl	%esi, %esi
     2e4:      	jmp	0x40f <generic_lsm_process_event+0x23f>
     2e9:      	movq	$0x0, 0xd8(%rsp)
     2f5:      	xorl	%esi, %esi
     2f7:      	jmp	0x325 <generic_lsm_process_event+0x155>
     2f9:      	movq	%r13, 0x48(%rsp)
     2fe:      	movq	%rbx, %r13
     301:      	movq	%rax, %rbx
     304:      	movl	$0x23, %eax
     309:      	callq	*%rax
     30b:      	movq	(%rsp), %rdx
     30f:      	movq	%rax, %rsi
     312:      	movq	%rbx, %rax
     315:      	movq	%r13, %rbx
     318:      	movq	0x48(%rsp), %r13
     31d:      	movq	%rsi, 0xd8(%rsp)
     325:      	cmpl	$0x4, %edx
     328:      	ja	0x40f <generic_lsm_process_event+0x23f>
     32e:      	leaq	(%rdx,%rdx,4), %rcx
     332:      	shll	$0x4, %ecx
     335:      	cmpw	$0x0, 0x76(%rax,%rcx)
     33b:      	je	0x40f <generic_lsm_process_event+0x23f>
     341:      	addq	%rcx, %rax
     344:      	addq	$0x70, %rax
     348:      	movq	%rax, 0x60(%rsp)
     34d:      	leaq	0xd8(%rsp), %rax
     355:      	movq	%rax, 0x68(%rsp)
     35a:      	movb	$0x0, 0x70(%rsp)
     35f:      	leaq	(%r15,%rbp,4), %rax
     363:      	addq	$0x5ea0, %rax           # imm = 0x5EA0
     369:      	movq	%rax, 0x78(%rsp)
     36e:      	movq	(%rip), %rax            # 0x375 <generic_lsm_process_event+0x1a5>
     375:      	cmpb	$0x0, (%rax)
     378:      	je	0x3d9 <generic_lsm_process_event+0x209>
     37a:      	xorl	%r15d, %r15d
     37d:      	movl	$0x8, %ebp
     382:      	jmp	0x3a5 <generic_lsm_process_event+0x1d5>
     384:      	movl	$0x4, %eax
     389:      	movq	0x68(%rsp), %rdi
     38e:      	movq	(%rdi), %rdx
     391:      	movl	$0x8, %esi
     396:      	callq	*%rax
     398:      	testl	%eax, %eax
     39a:      	js	0x3fc <generic_lsm_process_event+0x22c>
     39c:      	incq	%r15
     39f:      	cmpq	$0xa, %r15
     3a3:      	je	0x407 <generic_lsm_process_event+0x237>
     3a5:      	movq	0x60(%rsp), %rax
     3aa:      	cmpw	$0x0, 0x6(%rax,%r15,8)
     3b1:      	je	0x407 <generic_lsm_process_event+0x237>
     3b3:      	movq	0x68(%rsp), %rcx
     3b8:      	movl	(%rax,%r15,8), %edx
     3bc:      	addq	(%rcx), %rdx
     3bf:      	movq	%rdx, (%rcx)
     3c2:      	cmpw	$0x0, 0x4(%rax,%r15,8)
     3c9:      	je	0x39c <generic_lsm_process_event+0x1cc>
     3cb:      	cmpb	$0x0, 0x70(%rsp)
     3d0:      	je	0x384 <generic_lsm_process_event+0x1b4>
     3d2:      	movl	$0x94, %eax
     3d7:      	jmp	0x389 <generic_lsm_process_event+0x1b9>
     3d9:      	leaq	(%rip), %rsi            # 0x3e0 <generic_lsm_process_event+0x210>
     3e0:      	xorl	%ecx, %ecx
     3e2:      	leaq	0x60(%rsp), %rdx
     3e7:      	movl	$0xa, %edi
     3ec:      	movl	$0xb5, %eax
     3f1:      	movl	$0xa, %edi
     3f6:      	xorl	%ecx, %ecx
     3f8:      	callq	*%rax
     3fa:      	jmp	0x407 <generic_lsm_process_event+0x237>
     3fc:      	incl	%r15d
     3ff:      	movq	0x78(%rsp), %rax
     404:      	movl	%r15d, (%rax)
     407:      	movq	0xd8(%rsp), %rsi
     40f:      	movl	$0x1000, %r15d          # imm = 0x1000
     415:      	cmpl	$0x15, %r12d
     419:      	jg	0x457 <generic_lsm_process_event+0x287>
     41b:      	cmpl	$0xb, %r12d
     41f:      	movq	0x18(%rsp), %rbp
     424:      	jg	0x48f <generic_lsm_process_event+0x2bf>
     426:      	cmpl	$0x5, %r12d
     42a:      	jg	0x51a <generic_lsm_process_event+0x34a>
     430:      	cmpl	$0x3, %r12d
     434:      	jg	0x5a4 <generic_lsm_process_event+0x3d4>
     43a:      	leal	-0x2(%r12), %eax
     43f:      	cmpl	$0x2, %eax
     442:      	jb	0x56a <generic_lsm_process_event+0x39a>
     448:      	cmpl	$0x1, %r12d
     44c:      	je	0x56a <generic_lsm_process_event+0x39a>
     452:      	jmp	0x5d6 <generic_lsm_process_event+0x406>
     457:      	cmpl	$0x20, %r12d
     45b:      	movq	0x18(%rsp), %rbp
     460:      	jle	0x4ba <generic_lsm_process_event+0x2ea>
     462:      	cmpl	$0x27, %r12d
     466:      	jg	0x4e7 <generic_lsm_process_event+0x317>
     468:      	leal	-0x21(%r12), %eax
     46d:      	cmpl	$0x4, %eax
     470:      	jb	0x5b8 <generic_lsm_process_event+0x3e8>
     476:      	cmpl	$0x25, %r12d
     47a:      	je	0x5d9 <generic_lsm_process_event+0x409>
     480:      	cmpl	$0x27, %r12d
     484:      	je	0x572 <generic_lsm_process_event+0x3a2>
     48a:      	jmp	0x5d6 <generic_lsm_process_event+0x406>
     48f:      	cmpl	$0x11, %r12d
     493:      	jg	0x543 <generic_lsm_process_event+0x373>
     499:      	leal	-0xf(%r12), %eax
     49e:      	cmpl	$0x3, %eax
     4a1:      	jb	0x5d9 <generic_lsm_process_event+0x409>
     4a7:      	leal	-0xc(%r12), %eax
     4ac:      	cmpl	$0x2, %eax
     4af:      	jb	0x56a <generic_lsm_process_event+0x39a>
     4b5:      	jmp	0x5d6 <generic_lsm_process_event+0x406>
     4ba:      	cmpl	$0x1a, %r12d
     4be:      	jg	0x560 <generic_lsm_process_event+0x390>
     4c4:      	cmpl	$0x16, %r12d
     4c8:      	je	0x572 <generic_lsm_process_event+0x3a2>
     4ce:      	cmpl	$0x17, %r12d
     4d2:      	je	0x5b8 <generic_lsm_process_event+0x3e8>
     4d8:      	cmpl	$0x1a, %r12d
     4dc:      	je	0x5ce <generic_lsm_process_event+0x3fe>
     4e2:      	jmp	0x5d6 <generic_lsm_process_event+0x406>
     4e7:      	cmpl	$0x29, %r12d
     4eb:      	jle	0x58e <generic_lsm_process_event+0x3be>
     4f1:      	cmpl	$0x2a, %r12d
     4f5:      	je	0x5d9 <generic_lsm_process_event+0x409>
     4fb:      	cmpl	$0x2b, %r12d
     4ff:      	je	0x59c <generic_lsm_process_event+0x3cc>
     505:      	cmpl	$0x2c, %r12d
     509:      	jne	0x5d6 <generic_lsm_process_event+0x406>
     50f:      	movl	$0x70, %r15d
     515:      	jmp	0x5d9 <generic_lsm_process_event+0x409>
     51a:      	cmpl	$0x9, %r12d
     51e:      	jg	0x5b8 <generic_lsm_process_event+0x3e8>
     524:      	cmpl	$0x6, %r12d
     528:      	je	0x5d9 <generic_lsm_process_event+0x409>
     52e:      	cmpl	$0x7, %r12d
     532:      	je	0x5b0 <generic_lsm_process_event+0x3e0>
     534:      	cmpl	$0x8, %r12d
     538:      	je	0x5ce <generic_lsm_process_event+0x3fe>
     53e:      	jmp	0x5d6 <generic_lsm_process_event+0x406>
     543:      	cmpl	$0x13, %r12d
     547:      	jg	0x57a <generic_lsm_process_event+0x3aa>
     549:      	movq	0x28(%rsp), %r15
     54e:      	cmpl	$0x12, %r12d
     552:      	je	0x5d9 <generic_lsm_process_event+0x409>
     558:      	cmpl	$0x13, %r12d
     55c:      	je	0x59c <generic_lsm_process_event+0x3cc>
     55e:      	jmp	0x5d6 <generic_lsm_process_event+0x406>
     560:      	leal	-0x1d(%r12), %eax
     565:      	cmpl	$0x4, %eax
     568:      	jae	0x5c8 <generic_lsm_process_event+0x3f8>
     56a:      	movl	$0x4, %r15d
     570:      	jmp	0x5d9 <generic_lsm_process_event+0x409>
     572:      	movl	$0x10, %r15d
     578:      	jmp	0x5d9 <generic_lsm_process_event+0x409>
     57a:      	cmpl	$0x14, %r12d
     57e:      	je	0x5c0 <generic_lsm_process_event+0x3f0>
     580:      	cmpl	$0x15, %r12d
     584:      	jne	0x5d6 <generic_lsm_process_event+0x406>
     586:      	movl	$0x20, %r15d
     58c:      	jmp	0x5d9 <generic_lsm_process_event+0x409>
     58e:      	cmpl	$0x28, %r12d
     592:      	je	0x59c <generic_lsm_process_event+0x3cc>
     594:      	cmpl	$0x29, %r12d
     598:      	je	0x5b0 <generic_lsm_process_event+0x3e0>
     59a:      	jmp	0x5d6 <generic_lsm_process_event+0x406>
     59c:      	movl	$0x18, %r15d
     5a2:      	jmp	0x5d9 <generic_lsm_process_event+0x409>
     5a4:      	cmpl	$0x4, %r12d
     5a8:      	je	0x5b8 <generic_lsm_process_event+0x3e8>
     5aa:      	cmpl	$0x5, %r12d
     5ae:      	jne	0x5d6 <generic_lsm_process_event+0x406>
     5b0:      	movl	$0x40, %r15d
     5b6:      	jmp	0x5d9 <generic_lsm_process_event+0x409>
     5b8:      	movl	$0x8, %r15d
     5be:      	jmp	0x5d9 <generic_lsm_process_event+0x409>
     5c0:      	movl	$0x98, %r15d
     5c6:      	jmp	0x5d9 <generic_lsm_process_event+0x409>
     5c8:      	cmpl	$0x1b, %r12d
     5cc:      	jne	0x5d6 <generic_lsm_process_event+0x406>
     5ce:      	movl	$0x50, %r15d
     5d4:      	jmp	0x5d9 <generic_lsm_process_event+0x409>
     5d6:      	xorl	%r15d, %r15d
     5d9:      	movq	%rsi, 0x20(%rsp)
     5de:      	movl	$0x0, 0xf4(%rsp)
     5e9:      	movq	(%rip), %rdi            # 0x5f0 <generic_lsm_process_event+0x420>
     5f0:      	leaq	0xf4(%rsp), %rsi
     5f8:      	movl	$0x1, %eax
     5fd:      	callq	*%rax
     5ff:      	testq	%rax, %rax
     602:      	je	0x32e4 <generic_lsm_process_event+0x3114>
     608:      	movl	$0x3ffb, %ecx           # imm = 0x3FFB
     60d:      	subq	%r15, %rcx
     610:      	cmpq	%rbp, %rcx
     613:      	jbe	0x32e4 <generic_lsm_process_event+0x3114>
     619:      	movq	(%rsp), %rdx
     61d:      	movl	0x5ea0(%rax,%rdx,4), %ecx
     624:      	movl	%ecx, 0x90(%rax,%rbp)
     62b:      	leaq	0x4(%rbp), %r15
     62f:      	movq	%r15, 0x5e78(%rax,%rdx,8)
     637:      	movl	$0x4, %edx
     63c:      	testl	%ecx, %ecx
     63e:      	jne	0x32e0 <generic_lsm_process_event+0x3110>
     644:      	movq	%rax, %rbp
     647:      	addq	$0x90, %rbp
     64e:      	andl	$0x3fff, %r15d          # imm = 0x3FFF
     655:      	addq	%r15, %rbp
     658:      	movq	0x20(%rsp), %rdx
     65d:      	movq	%rdx, 0x60(%rsp)
     662:      	movq	$0x0, 0xa0(%rsp)
     66e:      	cmpl	$0x17, %r12d
     672:      	movq	%r14, 0x30(%rsp)
     677:      	movq	%rax, 0x8(%rsp)
     67c:      	movq	%r13, 0x48(%rsp)
     681:      	jle	0x6be <generic_lsm_process_event+0x4ee>
     683:      	cmpl	$0x18, %r12d
     687:      	je	0x6d9 <generic_lsm_process_event+0x509>
     689:      	cmpl	$0x25, %r12d
     68d:      	je	0x717 <generic_lsm_process_event+0x547>
     693:      	cmpl	$0x2a, %r12d
     697:      	jne	0xe20 <generic_lsm_process_event+0xc50>
     69d:      	movq	$0x0, 0xf8(%rsp)
     6a9:      	movq	%rdx, 0x100(%rsp)
     6b1:      	leaq	0xf8(%rsp), %rax
     6b9:      	jmp	0x744 <generic_lsm_process_event+0x574>
     6be:      	cmpl	$0xf, %r12d
     6c2:      	je	0xd39 <generic_lsm_process_event+0xb69>
     6c8:      	cmpl	$0x10, %r12d
     6cc:      	jne	0xe20 <generic_lsm_process_event+0xc50>
     6d2:      	leaq	0x38(%rsp), %r15
     6d7:      	jmp	0x701 <generic_lsm_process_event+0x531>
     6d9:      	leaq	0x38(%rsp), %r15
     6de:      	movl	$0x8, %ecx
     6e3:      	movl	$0x4, %eax
     6e8:      	movq	0x60(%rsp), %rdx
     6ed:      	movq	%r15, %rdi
     6f0:      	movl	$0x8, %esi
     6f5:      	callq	*%rax
     6f7:      	movq	0x38(%rsp), %rax
     6fc:      	movq	%rax, 0x60(%rsp)
     701:      	leaq	0x60(%rsp), %rdx
     706:      	movl	$0x8, %ecx
     70b:      	movl	$0x4, %eax
     710:      	leaq	0x38(%rsp), %rdi
     715:      	jmp	0x734 <generic_lsm_process_event+0x564>
     717:      	addq	$0x40, %rdx
     71b:      	movq	%rdx, 0x60(%rsp)
     720:      	leaq	0x38(%rsp), %rdi
     725:      	movl	$0x8, %ecx
     72a:      	movl	$0x4, %eax
     72f:      	movq	0x60(%rsp), %rdx
     734:      	movl	$0x8, %esi
     739:      	callq	*%rax
     73b:      	movq	0x38(%rsp), %rax
     740:      	addq	$0x40, %rax
     744:      	movq	%rax, 0xb0(%rsp)
     74c:      	movl	$0x0, 0xb8(%rsp)
     757:      	movq	(%rip), %rdi            # 0x75e <generic_lsm_process_event+0x58e>
     75e:      	leaq	0xb8(%rsp), %rsi
     766:      	movl	$0x1, %eax
     76b:      	callq	*%rax
     76d:      	testq	%rax, %rax
     770:      	je	0x824 <generic_lsm_process_event+0x654>
     776:      	movq	%rax, %r12
     779:      	movq	%rbp, 0x10(%rsp)
     77e:      	addq	$0x1000, %rax           # imm = 0x1000
     784:      	movq	%rax, 0x20(%rsp)
     789:      	movl	$0x23, %eax
     78e:      	callq	*%rax
     790:      	leaq	0xd50(%rax), %rdx
     797:      	leaq	0xe0(%rsp), %rdi
     79f:      	movl	$0x8, %ecx
     7a4:      	movl	$0x4, %eax
     7a9:      	movl	$0x8, %esi
     7ae:      	callq	*%rax
     7b0:      	movq	0xe0(%rsp), %r13
     7b8:      	movq	0xb0(%rsp), %rax
     7c0:      	leaq	0x8(%rax), %rdx
     7c4:      	leaq	0xd0(%rsp), %rdi
     7cc:      	movl	$0x8, %ecx
     7d1:      	movl	$0x4, %eax
     7d6:      	leaq	0x18(%r13), %rcx
     7da:      	movq	%rcx, 0xc8(%rsp)
     7e2:      	movl	$0x8, %esi
     7e7:      	movq	%rdx, 0x28(%rsp)
     7ec:      	callq	*%rax
     7ee:      	movq	0xd0(%rsp), %r15
     7f6:      	leaq	0x10(%r15), %rdx
     7fa:      	leaq	0x60(%rsp), %rdi
     7ff:      	movl	$0x8, %ecx
     804:      	movl	$0x4, %eax
     809:      	movl	$0x8, %esi
     80e:      	callq	*%rax
     810:      	cmpq	$0x0, 0x60(%rsp)
     816:      	movl	$0x1000, %ebp           # imm = 0x1000
     81b:      	je	0x831 <generic_lsm_process_event+0x661>
     81d:      	movq	0x20(%rsp), %rcx
     822:      	jmp	0x883 <generic_lsm_process_event+0x6b3>
     824:      	xorl	%r15d, %r15d
     827:      	movq	0x48(%rsp), %r13
     82c:      	jmp	0x100f <generic_lsm_process_event+0xe3f>
     831:      	leaq	0x18(%r15), %rdx
     835:      	leaq	0x60(%rsp), %rdi
     83a:      	movl	$0x8, %ecx
     83f:      	movl	$0x4, %eax
     844:      	movl	$0x8, %esi
     849:      	callq	*%rax
     84b:      	cmpq	%r15, 0x60(%rsp)
     850:      	movq	0x20(%rsp), %rcx
     855:      	je	0x883 <generic_lsm_process_event+0x6b3>
     857:      	movq	%r12, %rcx
     85a:      	addq	$0xff6, %rcx            # imm = 0xFF6
     861:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
     86b:      	movq	%rax, 0xff6(%r12)
     873:      	movw	$0x2964, 0xffe(%r12)    # imm = 0x2964
     87e:      	movl	$0xff6, %ebp            # imm = 0xFF6
     883:      	movq	$0x0, 0x68(%rsp)
     88c:      	movq	$0x0, 0x60(%rsp)
     895:      	movq	%r12, 0x70(%rsp)
     89a:      	movq	$0x0, 0x78(%rsp)
     8a3:      	movq	$0x0, 0x80(%rsp)
     8af:      	movq	$0x0, 0x88(%rsp)
     8bb:      	movq	%rcx, 0x20(%rsp)
     8c0:      	movq	%rcx, 0x90(%rsp)
     8c8:      	movl	%ebp, 0x98(%rsp)
     8cf:      	movb	$0x0, 0x9c(%rsp)
     8d7:      	addq	$0x20, %r13
     8db:      	leaq	0x60(%rsp), %rdi
     8e0:      	movl	$0x8, %ecx
     8e5:      	movl	$0x4, %eax
     8ea:      	leaq	0x68(%rsp), %r12
     8ef:      	leaq	0x78(%rsp), %r15
     8f4:      	leaq	0x80(%rsp), %rbp
     8fc:      	movl	$0x8, %esi
     901:      	movq	%r13, %rdx
     904:      	callq	*%rax
     906:      	movl	$0x8, %ecx
     90b:      	movl	$0x4, %eax
     910:      	movq	0xc8(%rsp), %rdx
     918:      	movq	%r12, %rdi
     91b:      	movl	$0x8, %esi
     920:      	callq	*%rax
     922:      	movl	$0x8, %ecx
     927:      	movl	$0x4, %eax
     92c:      	movq	0x28(%rsp), %rdx
     931:      	movq	%r15, %rdi
     934:      	movl	$0x8, %esi
     939:      	callq	*%rax
     93b:      	movl	$0x8, %ecx
     940:      	movl	$0x4, %eax
     945:      	movq	0xb0(%rsp), %rdx
     94d:      	movq	%rbp, %rdi
     950:      	movl	$0x8, %esi
     955:      	callq	*%rax
     957:      	movq	0x80(%rsp), %rax
     95f:      	addq	$-0x20, %rax
     963:      	movq	%rax, 0x88(%rsp)
     96b:      	movq	(%rip), %rax            # 0x972 <generic_lsm_process_event+0x7a2>
     972:      	cmpb	$0x0, (%rax)
     975:      	je	0xb5d <generic_lsm_process_event+0x98d>
     97b:      	movl	$0x800, %ebp            # imm = 0x800
     980:      	movl	$0x8, %r15d
     986:      	movq	0x78(%rsp), %r12
     98b:      	movq	0x80(%rsp), %rdx
     993:      	movq	0x88(%rsp), %r13
     99b:      	cmpq	0x60(%rsp), %r12
     9a0:      	jne	0x9ad <generic_lsm_process_event+0x7dd>
     9a2:      	cmpq	0x68(%rsp), %rdx
     9a7:      	je	0xed3 <generic_lsm_process_event+0xd03>
     9ad:      	movl	$0x4, %eax
     9b2:      	leaq	0x50(%rsp), %rdi
     9b7:      	movl	$0x8, %esi
     9bc:      	callq	*%rax
     9be:      	cmpq	0x50(%rsp), %r12
     9c3:      	movl	$0x8, %r14d
     9c9:      	je	0xaec <generic_lsm_process_event+0x91c>
     9cf:      	leaq	0x18(%r12), %r15
     9d4:      	movl	$0x4, %eax
     9d9:      	leaq	0x38(%rsp), %rdi
     9de:      	movl	$0x8, %esi
     9e3:      	movq	%r15, %rdx
     9e6:      	callq	*%rax
     9e8:      	cmpq	%r12, 0x38(%rsp)
     9ed:      	je	0xaec <generic_lsm_process_event+0x91c>
     9f3:      	movl	$0x4, %eax
     9f8:      	leaq	0xc0(%rsp), %rdi
     a00:      	movl	$0x8, %esi
     a05:      	movq	%r15, %rdx
     a08:      	callq	*%rax
     a0a:      	addq	$0x20, %r12
     a0e:      	movl	$0x4, %eax
     a13:      	leaq	0xa0(%rsp), %rdi
     a1b:      	movl	$0x10, %ecx
     a20:      	movl	$0x10, %esi
     a25:      	movq	%r12, %rdx
     a28:      	callq	*%rax
     a2a:      	movq	0x70(%rsp), %r15
     a2f:      	movq	0x90(%rsp), %rax
     a37:      	movl	0xa4(%rsp), %r12d
     a3f:      	subq	%r15, %rax
     a42:      	movl	0x98(%rsp), %r13d
     a4a:      	movl	%r12d, %edx
     a4d:      	subl	%r13d, %edx
     a50:      	movl	$0x0, %ecx
     a55:      	cmovbl	%ecx, %edx
     a58:      	addq	0xa8(%rsp), %rdx
     a60:      	xorl	%esi, %esi
     a62:      	cmpl	%r12d, %r13d
     a65:      	seta	%sil
     a69:      	movl	%r12d, %ecx
     a6c:      	cmovbl	%r13d, %ecx
     a70:      	addl	%ecx, %esi
     a72:      	movl	%r13d, %edi
     a75:      	subl	%esi, %edi
     a77:      	movl	%edi, 0x98(%rsp)
     a7e:      	subq	%rsi, %rax
     a81:      	movq	0x30(%rsp), %r14
     a86:      	jb	0xefc <generic_lsm_process_event+0xd2c>
     a8c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
     a92:      	ja	0xefc <generic_lsm_process_event+0xd2c>
     a98:      	cmpl	%r12d, %r13d
     a9b:      	jbe	0xaa2 <generic_lsm_process_event+0x8d2>
     a9d:      	movb	$0x2f, (%r15,%rax)
     aa2:      	xorl	%edi, %edi
     aa4:      	cmpl	%r12d, %r13d
     aa7:      	seta	%dil
     aab:      	movzbl	%cl, %esi
     aae:      	addq	%rax, %r15
     ab1:      	addq	%r15, %rdi
     ab4:      	movl	$0x4, %eax
     ab9:      	callq	*%rax
     abb:      	movq	%r15, 0x90(%rsp)
     ac3:      	cmpl	%r12d, %r13d
     ac6:      	jbe	0xefc <generic_lsm_process_event+0xd2c>
     acc:      	movq	0xc0(%rsp), %rax
     ad4:      	movq	%rax, 0x78(%rsp)
     ad9:      	movl	$0x8, %r15d
     adf:      	decl	%ebp
     ae1:      	jne	0x986 <generic_lsm_process_event+0x7b6>
     ae7:      	jmp	0xefc <generic_lsm_process_event+0xd2c>
     aec:      	leaq	0x10(%r13), %rdx
     af0:      	movl	$0x4, %eax
     af5:      	leaq	0x38(%rsp), %rdi
     afa:      	movl	$0x8, %esi
     aff:      	callq	*%rax
     b01:      	movq	0x88(%rsp), %rax
     b09:      	cmpq	0x38(%rsp), %rax
     b0e:      	movl	$0x8, %r15d
     b14:      	je	0xeef <generic_lsm_process_event+0xd1f>
     b1a:      	addq	$0x18, %r13
     b1e:      	movl	$0x4, %eax
     b23:      	leaq	0x78(%rsp), %rdi
     b28:      	movl	$0x8, %esi
     b2d:      	movq	%r13, %rdx
     b30:      	callq	*%rax
     b32:      	movq	0x38(%rsp), %rax
     b37:      	movq	%rax, 0x88(%rsp)
     b3f:      	addq	$0x20, %rax
     b43:      	movq	%rax, 0x80(%rsp)
     b4b:      	movq	0x30(%rsp), %r14
     b50:      	decl	%ebp
     b52:      	jne	0x986 <generic_lsm_process_event+0x7b6>
     b58:      	jmp	0xefc <generic_lsm_process_event+0xd2c>
     b5d:      	movl	$0x800, %ebp            # imm = 0x800
     b62:      	movl	$0x8, %r15d
     b68:      	movq	0x78(%rsp), %r12
     b6d:      	movq	0x80(%rsp), %rdx
     b75:      	movq	0x88(%rsp), %r13
     b7d:      	cmpq	0x60(%rsp), %r12
     b82:      	jne	0xb8f <generic_lsm_process_event+0x9bf>
     b84:      	cmpq	0x68(%rsp), %rdx
     b89:      	je	0xed3 <generic_lsm_process_event+0xd03>
     b8f:      	movl	$0x4, %eax
     b94:      	leaq	0x50(%rsp), %rdi
     b99:      	movl	$0x8, %esi
     b9e:      	callq	*%rax
     ba0:      	cmpq	0x50(%rsp), %r12
     ba5:      	movl	$0x8, %ecx
     baa:      	je	0xccd <generic_lsm_process_event+0xafd>
     bb0:      	leaq	0x18(%r12), %r15
     bb5:      	movl	$0x4, %eax
     bba:      	leaq	0x38(%rsp), %rdi
     bbf:      	movl	$0x8, %esi
     bc4:      	movq	%r15, %rdx
     bc7:      	callq	*%rax
     bc9:      	movl	$0x8, %ecx
     bce:      	cmpq	%r12, 0x38(%rsp)
     bd3:      	je	0xccd <generic_lsm_process_event+0xafd>
     bd9:      	movl	$0x4, %eax
     bde:      	leaq	0xc0(%rsp), %rdi
     be6:      	movl	$0x8, %esi
     beb:      	movq	%r15, %rdx
     bee:      	callq	*%rax
     bf0:      	addq	$0x20, %r12
     bf4:      	movl	$0x4, %eax
     bf9:      	leaq	0xa0(%rsp), %rdi
     c01:      	movl	$0x10, %ecx
     c06:      	movl	$0x10, %esi
     c0b:      	movq	%r12, %rdx
     c0e:      	callq	*%rax
     c10:      	movq	0x70(%rsp), %r15
     c15:      	movq	0x90(%rsp), %rax
     c1d:      	movl	0xa4(%rsp), %r12d
     c25:      	subq	%r15, %rax
     c28:      	movl	0x98(%rsp), %r13d
     c30:      	movl	%r12d, %edx
     c33:      	subl	%r13d, %edx
     c36:      	movl	$0x0, %ecx
     c3b:      	cmovbl	%ecx, %edx
     c3e:      	addq	0xa8(%rsp), %rdx
     c46:      	xorl	%esi, %esi
     c48:      	cmpl	%r12d, %r13d
     c4b:      	seta	%sil
     c4f:      	movl	%r12d, %ecx
     c52:      	cmovbl	%r13d, %ecx
     c56:      	addl	%ecx, %esi
     c58:      	movl	%r13d, %edi
     c5b:      	subl	%esi, %edi
     c5d:      	movl	%edi, 0x98(%rsp)
     c64:      	subq	%rsi, %rax
     c67:      	jb	0xefc <generic_lsm_process_event+0xd2c>
     c6d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
     c73:      	ja	0xefc <generic_lsm_process_event+0xd2c>
     c79:      	cmpl	%r12d, %r13d
     c7c:      	jbe	0xc83 <generic_lsm_process_event+0xab3>
     c7e:      	movb	$0x2f, (%r15,%rax)
     c83:      	xorl	%edi, %edi
     c85:      	cmpl	%r12d, %r13d
     c88:      	seta	%dil
     c8c:      	movzbl	%cl, %esi
     c8f:      	addq	%rax, %r15
     c92:      	addq	%r15, %rdi
     c95:      	movl	$0x4, %eax
     c9a:      	callq	*%rax
     c9c:      	movq	%r15, 0x90(%rsp)
     ca4:      	cmpl	%r12d, %r13d
     ca7:      	jbe	0xefc <generic_lsm_process_event+0xd2c>
     cad:      	movq	0xc0(%rsp), %rax
     cb5:      	movq	%rax, 0x78(%rsp)
     cba:      	movl	$0x8, %r15d
     cc0:      	decl	%ebp
     cc2:      	jne	0xb68 <generic_lsm_process_event+0x998>
     cc8:      	jmp	0xefc <generic_lsm_process_event+0xd2c>
     ccd:      	leaq	0x10(%r13), %rdx
     cd1:      	movl	$0x4, %eax
     cd6:      	leaq	0x38(%rsp), %rdi
     cdb:      	movl	$0x8, %esi
     ce0:      	callq	*%rax
     ce2:      	movq	0x88(%rsp), %rax
     cea:      	cmpq	0x38(%rsp), %rax
     cef:      	movl	$0x8, %r15d
     cf5:      	je	0xed3 <generic_lsm_process_event+0xd03>
     cfb:      	addq	$0x18, %r13
     cff:      	movl	$0x4, %eax
     d04:      	leaq	0x78(%rsp), %rdi
     d09:      	movl	$0x8, %esi
     d0e:      	movq	%r13, %rdx
     d11:      	callq	*%rax
     d13:      	movq	0x38(%rsp), %rax
     d18:      	movq	%rax, 0x88(%rsp)
     d20:      	addq	$0x20, %rax
     d24:      	movq	%rax, 0x80(%rsp)
     d2c:      	decl	%ebp
     d2e:      	jne	0xb68 <generic_lsm_process_event+0x998>
     d34:      	jmp	0xefc <generic_lsm_process_event+0xd2c>
     d39:      	leaq	0xa0(%rsp), %rdi
     d41:      	leaq	0x60(%rsp), %rdx
     d46:      	movl	$0x8, %ecx
     d4b:      	movl	$0x4, %eax
     d50:      	movl	$0x8, %esi
     d55:      	callq	*%rax
     d57:      	movq	0xa0(%rsp), %rax
     d5f:      	movq	%rax, 0xb0(%rsp)
     d67:      	testq	%rax, %rax
     d6a:      	jne	0x74c <generic_lsm_process_event+0x57c>
     d70:      	movl	$0x0, 0xe0(%rsp)
     d7b:      	movq	(%rip), %rdi            # 0xd82 <generic_lsm_process_event+0xbb2>
     d82:      	leaq	0xe0(%rsp), %rsi
     d8a:      	movl	$0x1, %eax
     d8f:      	callq	*%rax
     d91:      	testq	%rax, %rax
     d94:      	je	0x117e <generic_lsm_process_event+0xfae>
     d9a:      	movq	%r15, 0xb0(%rsp)
     da2:      	movq	%rbp, 0x10(%rsp)
     da7:      	xorl	%r15d, %r15d
     daa:      	cmpl	$0x19, %r12d
     dae:      	movq	0x48(%rsp), %r13
     db3:      	movq	0x18(%rsp), %rbp
     db8:      	jg	0x124a <generic_lsm_process_event+0x107a>
     dbe:      	cmpl	$0x12, %r12d
     dc2:      	jle	0x13b6 <generic_lsm_process_event+0x11e6>
     dc8:      	cmpl	$0x14, %r12d
     dcc:      	jle	0x174b <generic_lsm_process_event+0x157b>
     dd2:      	cmpl	$0x15, %r12d
     dd6:      	je	0x2087 <generic_lsm_process_event+0x1eb7>
     ddc:      	cmpl	$0x16, %r12d
     de0:      	je	0x1ffa <generic_lsm_process_event+0x1e2a>
     de6:      	cmpl	$0x17, %r12d
     dea:      	movq	0x8(%rsp), %rcx
     def:      	movq	(%rsp), %rsi
     df3:      	movq	0x20(%rsp), %rdx
     df8:      	jne	0x27eb <generic_lsm_process_event+0x261b>
     dfe:      	movq	0x10(%rsp), %rax
     e03:      	movl	$0x0, 0x4(%rax)
     e0a:      	movl	%edx, (%rax)
     e0c:      	movl	$0x8, %r15d
     e12:      	testl	%r15d, %r15d
     e15:      	js	0x32c5 <generic_lsm_process_event+0x30f5>
     e1b:      	jmp	0x27f4 <generic_lsm_process_event+0x2624>
     e20:      	cmpl	$0x2c, %r12d
     e24:      	ja	0xd70 <generic_lsm_process_event+0xba0>
     e2a:      	movl	%r12d, %eax
     e2d:      	movabsq	$0x11c1f2027cf2, %rcx   # imm = 0x11C1F2027CF2
     e37:      	btq	%rax, %rcx
     e3b:      	jae	0xd70 <generic_lsm_process_event+0xba0>
     e41:      	movq	%rdx, 0x50(%rsp)
     e46:      	movl	$0x0, 0xe0(%rsp)
     e51:      	movq	(%rip), %rdi            # 0xe58 <generic_lsm_process_event+0xc88>
     e58:      	leaq	0xe0(%rsp), %rsi
     e60:      	movl	$0x1, %eax
     e65:      	callq	*%rax
     e67:      	testq	%rax, %rax
     e6a:      	je	0xedd <generic_lsm_process_event+0xd0d>
     e6c:      	movq	%r15, %r13
     e6f:      	movq	%rbp, 0x10(%rsp)
     e74:      	xorl	%r15d, %r15d
     e77:      	cmpl	$0x10, %r12d
     e7b:      	movq	0x8(%rsp), %rcx
     e80:      	jle	0x1019 <generic_lsm_process_event+0xe49>
     e86:      	cmpl	$0x1e, %r12d
     e8a:      	movq	0x18(%rsp), %rbp
     e8f:      	jle	0x1190 <generic_lsm_process_event+0xfc0>
     e95:      	cmpl	$0x26, %r12d
     e99:      	jg	0x128e <generic_lsm_process_event+0x10be>
     e9f:      	leal	-0x1f(%r12), %eax
     ea4:      	cmpl	$0x2, %eax
     ea7:      	jae	0x1845 <generic_lsm_process_event+0x1675>
     ead:      	leaq	0x50(%rsp), %rdx
     eb2:      	movl	$0x4, %r15d
     eb8:      	movl	$0x1, %ecx
     ebd:      	movl	$0x4, %eax
     ec2:      	movq	0x10(%rsp), %rdi
     ec7:      	movl	$0x1, %esi
     ecc:      	callq	*%rax
     ece:      	jmp	0x27dd <generic_lsm_process_event+0x260d>
     ed3:      	movb	$0x1, 0x9c(%rsp)
     edb:      	jmp	0xefc <generic_lsm_process_event+0xd2c>
     edd:      	xorl	%r15d, %r15d
     ee0:      	movq	0x8(%rsp), %rcx
     ee5:      	movq	0x18(%rsp), %rbp
     eea:      	jmp	0x27e2 <generic_lsm_process_event+0x2612>
     eef:      	movb	$0x1, 0x9c(%rsp)
     ef7:      	movq	0x30(%rsp), %r14
     efc:      	movq	0x90(%rsp), %rax
     f04:      	movq	0x20(%rsp), %rdx
     f09:      	xorl	%ebp, %ebp
     f0b:      	cmpq	%rdx, %rax
     f0e:      	je	0xf49 <generic_lsm_process_event+0xd79>
     f10:      	cmpb	$0x0, 0x9c(%rsp)
     f18:      	sete	%cl
     f1b:      	movl	0x98(%rsp), %edx
     f22:      	movl	$0x1000, %r15d          # imm = 0x1000
     f28:      	subl	%edx, %r15d
     f2b:      	testl	%edx, %edx
     f2d:      	cmovlel	%edx, %r15d
     f31:      	testq	%rax, %rax
     f34:      	movq	0x48(%rsp), %r13
     f39:      	je	0x100c <generic_lsm_process_event+0xe3c>
     f3f:      	movb	%cl, %bpl
     f42:      	addl	%ebp, %ebp
     f44:      	movq	%rax, %rdx
     f47:      	jmp	0xf51 <generic_lsm_process_event+0xd81>
     f49:      	xorl	%r15d, %r15d
     f4c:      	movq	0x48(%rsp), %r13
     f51:      	movq	0x10(%rsp), %r12
     f56:      	leaq	0x4(%r12), %rdi
     f5b:      	andl	$0xfff, %r15d           # imm = 0xFFF
     f62:      	movl	$0x4, %eax
     f67:      	movl	%r15d, %esi
     f6a:      	callq	*%rax
     f6c:      	movl	%r15d, (%r12)
     f70:      	leaq	0x60(%rsp), %rdi
     f75:      	movl	$0x8, %ecx
     f7a:      	movl	$0x4, %eax
     f7f:      	movq	0x28(%rsp), %rdx
     f84:      	movl	$0x8, %esi
     f89:      	callq	*%rax
     f8b:      	movq	0x60(%rsp), %rcx
     f90:      	addq	$0x30, %rcx
     f94:      	leaq	0xa0(%rsp), %rdi
     f9c:      	movl	$0x8, %edx
     fa1:      	movl	$0x4, %eax
     fa6:      	movq	0x60(%rsp), %rdx
     fab:      	addq	$0x30, %rdx
     faf:      	movl	$0x8, %esi
     fb4:      	callq	*%rax
     fb6:      	movq	0xa0(%rsp), %rcx
     fbe:      	leaq	0x38(%rsp), %rdi
     fc3:      	movl	$0x2, %edx
     fc8:      	movl	$0x4, %eax
     fcd:      	movq	0xa0(%rsp), %rdx
     fd5:      	movl	$0x2, %esi
     fda:      	callq	*%rax
     fdc:      	movl	%ebp, 0x4(%r12,%r15)
     fe1:      	movzwl	0x38(%rsp), %eax
     fe6:      	movw	%ax, 0x8(%r12,%r15)
     fec:      	addl	$0xa, %r15d
     ff0:      	movq	0x8(%rsp), %rcx
     ff5:      	movq	0x18(%rsp), %rbp
     ffa:      	movq	(%rsp), %rsi
     ffe:      	testl	%r15d, %r15d
    1001:      	js	0x32c5 <generic_lsm_process_event+0x30f5>
    1007:      	jmp	0x27f4 <generic_lsm_process_event+0x2624>
    100c:      	xorl	%r15d, %r15d
    100f:      	movq	0x18(%rsp), %rbp
    1014:      	jmp	0x27f4 <generic_lsm_process_event+0x2624>
    1019:      	cmpl	$0x9, %r12d
    101d:      	movq	0x18(%rsp), %rbp
    1022:      	movq	(%rsp), %rsi
    1026:      	jg	0x11c6 <generic_lsm_process_event+0xff6>
    102c:      	cmpl	$0x4, %r12d
    1030:      	jle	0x1456 <generic_lsm_process_event+0x1286>
    1036:      	cmpl	$0x5, %r12d
    103a:      	je	0x1ae6 <generic_lsm_process_event+0x1916>
    1040:      	cmpl	$0x6, %r12d
    1044:      	je	0x1228 <generic_lsm_process_event+0x1058>
    104a:      	movq	%rax, 0x20(%rsp)
    104f:      	cmpl	$0x7, %r12d
    1053:      	movq	0x8(%rsp), %rcx
    1058:      	movq	(%rsp), %rsi
    105c:      	jne	0x27e6 <generic_lsm_process_event+0x2616>
    1062:      	movq	0x50(%rsp), %r15
    1067:      	movq	0x10(%rsp), %rbp
    106c:      	movq	%r15, 0x28(%rbp)
    1070:      	leaq	0x26(%rbp), %rdi
    1074:      	leaq	0x10(%r15), %rdx
    1078:      	movl	$0x2, %ecx
    107d:      	movl	$0x4, %eax
    1082:      	movl	$0x2, %esi
    1087:      	callq	*%rax
    1089:      	leaq	0x3a(%rbp), %rdi
    108d:      	leaq	0x12(%r15), %rdx
    1091:      	movl	$0x1, %ecx
    1096:      	movl	$0x4, %eax
    109b:      	movl	$0x1, %esi
    10a0:      	callq	*%rax
    10a2:      	leaq	0x38(%rbp), %rdi
    10a6:      	leaq	0x226(%r15), %rdx
    10ad:      	movl	$0x2, %ecx
    10b2:      	movl	$0x4, %eax
    10b7:      	movl	$0x2, %esi
    10bc:      	callq	*%rax
    10be:      	leaq	0x24(%rbp), %rdi
    10c2:      	leaq	0x224(%r15), %rdx
    10c9:      	movl	$0x2, %ecx
    10ce:      	movl	$0x4, %eax
    10d3:      	movl	$0x2, %esi
    10d8:      	callq	*%rax
    10da:      	leaq	0x30(%rbp), %rdi
    10de:      	leaq	0x21c(%r15), %rdx
    10e5:      	movl	$0x4, %ecx
    10ea:      	movl	$0x4, %eax
    10ef:      	movl	$0x4, %esi
    10f4:      	callq	*%rax
    10f6:      	leaq	0x34(%rbp), %rdi
    10fa:      	leaq	0x218(%r15), %rdx
    1101:      	movl	$0x4, %ecx
    1106:      	movl	$0x4, %eax
    110b:      	movl	$0x4, %esi
    1110:      	callq	*%rax
    1112:      	leaq	0x10(%rbp), %r12
    1116:      	movq	$0x0, (%rbp)
    111e:      	movq	$0x0, 0x8(%rbp)
    1126:      	movq	$0x0, 0x10(%rbp)
    112e:      	movq	$0x0, 0x18(%rbp)
    1136:      	movzwl	0x26(%rbp), %eax
    113a:      	cmpl	$0xa, %eax
    113d:      	je	0x24a9 <generic_lsm_process_event+0x22d9>
    1143:      	cmpl	$0x2, %eax
    1146:      	jne	0x24d9 <generic_lsm_process_event+0x2309>
    114c:      	leaq	0x4(%r15), %rdx
    1150:      	movl	$0x4, %ecx
    1155:      	movl	$0x4, %eax
    115a:      	movq	%rbp, %rdi
    115d:      	movl	$0x4, %esi
    1162:      	callq	*%rax
    1164:      	movl	$0x4, %ecx
    1169:      	movl	$0x4, %eax
    116e:      	movq	%r12, %rdi
    1171:      	movl	$0x4, %esi
    1176:      	movq	%r15, %rdx
    1179:      	jmp	0x24d7 <generic_lsm_process_event+0x2307>
    117e:      	xorl	%r15d, %r15d
    1181:      	movq	0x8(%rsp), %rcx
    1186:      	movq	0x48(%rsp), %r13
    118b:      	jmp	0xff5 <generic_lsm_process_event+0xe25>
    1190:      	cmpl	$0x1c, %r12d
    1194:      	jg	0x1430 <generic_lsm_process_event+0x1260>
    119a:      	cmpl	$0x11, %r12d
    119e:      	je	0x187c <generic_lsm_process_event+0x16ac>
    11a4:      	movq	%rax, 0x20(%rsp)
    11a9:      	cmpl	$0x19, %r12d
    11ad:      	je	0x1940 <generic_lsm_process_event+0x1770>
    11b3:      	cmpl	$0x1c, %r12d
    11b7:      	movq	(%rsp), %rsi
    11bb:      	je	0x1466 <generic_lsm_process_event+0x1296>
    11c1:      	jmp	0x27e6 <generic_lsm_process_event+0x2616>
    11c6:      	leal	-0xa(%r12), %eax
    11cb:      	cmpl	$0x2, %eax
    11ce:      	jb	0x1466 <generic_lsm_process_event+0x1296>
    11d4:      	leal	-0xc(%r12), %eax
    11d9:      	cmpl	$0x2, %eax
    11dc:      	jb	0x1487 <generic_lsm_process_event+0x12b7>
    11e2:      	cmpl	$0xe, %r12d
    11e6:      	jne	0x27e6 <generic_lsm_process_event+0x2616>
    11ec:      	leaq	0x60(%rsp), %rdi
    11f1:      	leaq	0x50(%rsp), %r15
    11f6:      	movl	$0x8, %ecx
    11fb:      	movl	$0x4, %eax
    1200:      	movl	$0x8, %esi
    1205:      	movq	%r15, %rdx
    1208:      	callq	*%rax
    120a:      	movq	0x60(%rsp), %rcx
    120f:      	movl	$0x8, %edx
    1214:      	movl	$0x4, %eax
    1219:      	movq	0x60(%rsp), %rdx
    121e:      	movq	%r15, %rdi
    1221:      	movl	$0x8, %esi
    1226:      	callq	*%rax
    1228:      	movq	0x50(%rsp), %rdx
    122d:      	movq	0x10(%rsp), %r13
    1232:      	leaq	0x4(%r13), %rdi
    1236:      	movl	$0x1001, %ecx           # imm = 0x1001
    123b:      	movl	$0x2d, %eax
    1240:      	movl	$0x1001, %esi           # imm = 0x1001
    1245:      	jmp	0x1ccd <generic_lsm_process_event+0x1afd>
    124a:      	cmpl	$0x20, %r12d
    124e:      	movq	0x20(%rsp), %r8
    1253:      	jle	0x161b <generic_lsm_process_event+0x144b>
    1259:      	movq	%rax, %rcx
    125c:      	leal	-0x21(%r12), %eax
    1261:      	cmpl	$0x4, %eax
    1264:      	jae	0x14b6 <generic_lsm_process_event+0x12e6>
    126a:      	movl	$0x8, %r15d
    1270:      	movl	$0x8, %ecx
    1275:      	movl	$0x4, %eax
    127a:      	movq	0x10(%rsp), %rdi
    127f:      	movl	$0x8, %esi
    1284:      	movq	%r8, %rdx
    1287:      	callq	*%rax
    1289:      	jmp	0x2218 <generic_lsm_process_event+0x2048>
    128e:      	cmpl	$0x27, %r12d
    1292:      	je	0x1cab <generic_lsm_process_event+0x1adb>
    1298:      	cmpl	$0x28, %r12d
    129c:      	je	0x1cec <generic_lsm_process_event+0x1b1c>
    12a2:      	cmpl	$0x2c, %r12d
    12a6:      	movq	(%rsp), %rsi
    12aa:      	jne	0x27e6 <generic_lsm_process_event+0x2616>
    12b0:      	movq	0x50(%rsp), %r15
    12b5:      	movb	$0x0, 0x60(%rsp)
    12ba:      	movq	0x10(%rsp), %rdi
    12bf:      	movq	$0x0, 0x68(%rdi)
    12c7:      	movq	$0x0, 0x60(%rdi)
    12cf:      	movq	$0x0, 0x58(%rdi)
    12d7:      	movq	$0x0, 0x50(%rdi)
    12df:      	movq	$0x0, 0x48(%rdi)
    12e7:      	movq	$0x0, 0x40(%rdi)
    12ef:      	movq	$0x0, 0x38(%rdi)
    12f7:      	movq	$0x0, 0x30(%rdi)
    12ff:      	movq	$0x0, 0x28(%rdi)
    1307:      	movq	$0x0, 0x20(%rdi)
    130f:      	movq	$0x0, 0x18(%rdi)
    1317:      	movq	$0x0, 0x10(%rdi)
    131f:      	movq	$0x0, 0x8(%rdi)
    1327:      	movq	$0x0, (%rdi)
    132e:      	movl	$0x2, %ecx
    1333:      	movl	$0x4, %eax
    1338:      	movl	$0x2, %esi
    133d:      	movq	%r15, %rdx
    1340:      	callq	*%rax
    1342:      	testq	%rax, %rax
    1345:      	js	0x27d7 <generic_lsm_process_event+0x2607>
    134b:      	leaq	0x2(%r15), %r12
    134f:      	leaq	0x60(%rsp), %rdi
    1354:      	movl	$0x1, %ecx
    1359:      	movl	$0x4, %eax
    135e:      	movl	$0x1, %esi
    1363:      	movq	%r12, %rdx
    1366:      	callq	*%rax
    1368:      	testq	%rax, %rax
    136b:      	js	0x27d7 <generic_lsm_process_event+0x2607>
    1371:      	movq	0x10(%rsp), %rax
    1376:      	leaq	0x4(%rax), %rdi
    137a:      	cmpb	$0x0, 0x60(%rsp)
    137f:      	sete	0x2(%rax)
    1383:      	je	0x27a4 <generic_lsm_process_event+0x25d4>
    1389:      	movl	$0x6c, %ecx
    138e:      	movl	$0x2d, %eax
    1393:      	movl	$0x6c, %esi
    1398:      	movq	%r12, %rdx
    139b:      	callq	*%rax
    139d:      	testl	%eax, %eax
    139f:      	movq	0x18(%rsp), %rbp
    13a4:      	movq	0x30(%rsp), %r14
    13a9:      	js	0x27d7 <generic_lsm_process_event+0x2607>
    13af:      	decb	%al
    13b1:      	jmp	0x27cf <generic_lsm_process_event+0x25ff>
    13b6:      	cmpl	$0x7, %r12d
    13ba:      	jg	0x16e5 <generic_lsm_process_event+0x1515>
    13c0:      	movq	%rax, %rcx
    13c3:      	cmpl	$0x2, %r12d
    13c7:      	je	0x1d85 <generic_lsm_process_event+0x1bb5>
    13cd:      	movq	%rcx, 0x28(%rsp)
    13d2:      	cmpl	$0x3, %r12d
    13d6:      	movq	0x8(%rsp), %rcx
    13db:      	movq	(%rsp), %rsi
    13df:      	jne	0x27eb <generic_lsm_process_event+0x261b>
    13e5:      	movq	0x28(%rsp), %rax
    13ea:      	leaq	0x90(%rax), %rbp
    13f1:      	movq	0xc8(%rsp), %rax
    13f9:      	andl	$0xf, %eax
    13fc:      	cmpl	$0x2, %eax
    13ff:      	jle	0x264c <generic_lsm_process_event+0x247c>
    1405:      	cmpl	$0x3, %eax
    1408:      	je	0x28ea <generic_lsm_process_event+0x271a>
    140e:      	cmpl	$0x4, %eax
    1411:      	je	0x28f7 <generic_lsm_process_event+0x2727>
    1417:      	cmpl	$0x5, %eax
    141a:      	jne	0x2d29 <generic_lsm_process_event+0x2b59>
    1420:      	movq	0x28(%rsp), %rax
    1425:      	addq	$0x5e70, %rax           # imm = 0x5E70
    142b:      	jmp	0x290f <generic_lsm_process_event+0x273f>
    1430:      	leaq	0x50(%rsp), %rdx
    1435:      	movl	$0x4, %r15d
    143b:      	movl	$0x2, %ecx
    1440:      	movl	$0x4, %eax
    1445:      	movq	0x10(%rsp), %rdi
    144a:      	movl	$0x2, %esi
    144f:      	callq	*%rax
    1451:      	jmp	0x27dd <generic_lsm_process_event+0x260d>
    1456:      	cmpl	$0x1, %r12d
    145a:      	je	0x1487 <generic_lsm_process_event+0x12b7>
    145c:      	cmpl	$0x4, %r12d
    1460:      	jne	0x27e6 <generic_lsm_process_event+0x2616>
    1466:      	movl	$0x8, %r15d
    146c:      	leaq	0x50(%rsp), %rdx
    1471:      	movl	$0x8, %ecx
    1476:      	movl	$0x4, %eax
    147b:      	movq	0x10(%rsp), %rdi
    1480:      	movl	$0x8, %esi
    1485:      	jmp	0x14a6 <generic_lsm_process_event+0x12d6>
    1487:      	leaq	0x50(%rsp), %rdx
    148c:      	movl	$0x4, %r15d
    1492:      	movl	$0x4, %ecx
    1497:      	movl	$0x4, %eax
    149c:      	movq	0x10(%rsp), %rdi
    14a1:      	movl	$0x4, %esi
    14a6:      	callq	*%rax
    14a8:      	movq	(%rsp), %rsi
    14ac:      	movq	0x8(%rsp), %rcx
    14b1:      	jmp	0x27e6 <generic_lsm_process_event+0x2616>
    14b6:      	movq	%rcx, 0x28(%rsp)
    14bb:      	cmpl	$0x2b, %r12d
    14bf:      	je	0x217f <generic_lsm_process_event+0x1faf>
    14c5:      	cmpl	$0x29, %r12d
    14c9:      	movq	0x8(%rsp), %rcx
    14ce:      	movq	(%rsp), %rsi
    14d2:      	jne	0x27eb <generic_lsm_process_event+0x261b>
    14d8:      	movq	%rcx, %r13
    14db:      	addq	$0x18, %r8
    14df:      	leaq	0x60(%rsp), %rdi
    14e4:      	movl	$0x4, %r12d
    14ea:      	movl	$0x8, %ecx
    14ef:      	movl	$0x4, %eax
    14f4:      	movl	$0x8, %esi
    14f9:      	movq	%r8, %rdx
    14fc:      	callq	*%rax
    14fe:      	movq	0x60(%rsp), %r15
    1503:      	testq	%r15, %r15
    1506:      	je	0x289e <generic_lsm_process_event+0x26ce>
    150c:      	movq	0x10(%rsp), %rbp
    1511:      	movq	%r15, 0x28(%rbp)
    1515:      	leaq	0x26(%rbp), %rdi
    1519:      	leaq	0x10(%r15), %rdx
    151d:      	movl	$0x2, %ecx
    1522:      	movl	$0x4, %eax
    1527:      	movl	$0x2, %esi
    152c:      	callq	*%rax
    152e:      	leaq	0x3a(%rbp), %rdi
    1532:      	leaq	0x12(%r15), %rdx
    1536:      	movl	$0x1, %ecx
    153b:      	movl	$0x4, %eax
    1540:      	movl	$0x1, %esi
    1545:      	callq	*%rax
    1547:      	leaq	0x38(%rbp), %rdi
    154b:      	leaq	0x226(%r15), %rdx
    1552:      	movl	$0x2, %ecx
    1557:      	movl	$0x4, %eax
    155c:      	movl	$0x2, %esi
    1561:      	callq	*%rax
    1563:      	leaq	0x24(%rbp), %rdi
    1567:      	leaq	0x224(%r15), %rdx
    156e:      	movl	$0x2, %ecx
    1573:      	movl	$0x4, %eax
    1578:      	movl	$0x2, %esi
    157d:      	callq	*%rax
    157f:      	leaq	0x30(%rbp), %rdi
    1583:      	leaq	0x21c(%r15), %rdx
    158a:      	movl	$0x4, %eax
    158f:      	movl	$0x4, %esi
    1594:      	callq	*%rax
    1596:      	leaq	0x34(%rbp), %rdi
    159a:      	leaq	0x218(%r15), %rdx
    15a1:      	movl	$0x4, %eax
    15a6:      	movl	$0x4, %esi
    15ab:      	callq	*%rax
    15ad:      	leaq	0x10(%rbp), %r12
    15b1:      	movq	$0x0, (%rbp)
    15b9:      	movq	$0x0, 0x8(%rbp)
    15c1:      	movq	$0x0, 0x10(%rbp)
    15c9:      	movq	$0x0, 0x18(%rbp)
    15d1:      	movzwl	0x26(%rbp), %eax
    15d5:      	cmpl	$0xa, %eax
    15d8:      	je	0x2825 <generic_lsm_process_event+0x2655>
    15de:      	cmpl	$0x2, %eax
    15e1:      	jne	0x2857 <generic_lsm_process_event+0x2687>
    15e7:      	leaq	0x4(%r15), %rdx
    15eb:      	movl	$0x4, %ecx
    15f0:      	movl	$0x4, %eax
    15f5:      	movq	0x10(%rsp), %rdi
    15fa:      	movl	$0x4, %esi
    15ff:      	callq	*%rax
    1601:      	movl	$0x4, %ecx
    1606:      	movl	$0x4, %eax
    160b:      	movq	%r12, %rdi
    160e:      	movl	$0x4, %esi
    1613:      	movq	%r15, %rdx
    1616:      	jmp	0x2855 <generic_lsm_process_event+0x2685>
    161b:      	cmpl	$0x1a, %r12d
    161f:      	je	0x2222 <generic_lsm_process_event+0x2052>
    1625:      	cmpl	$0x1b, %r12d
    1629:      	movq	0x8(%rsp), %rcx
    162e:      	movq	(%rsp), %rsi
    1632:      	jne	0x27eb <generic_lsm_process_event+0x261b>
    1638:      	movq	%rcx, %r12
    163b:      	movq	0x10(%rsp), %rax
    1640:      	movq	$0x0, 0x48(%rax)
    1648:      	movq	$0x0, 0x40(%rax)
    1650:      	movq	$0x0, 0x38(%rax)
    1658:      	movq	$0x0, 0x30(%rax)
    1660:      	movq	$0x0, 0x28(%rax)
    1668:      	movq	$0x0, 0x20(%rax)
    1670:      	movq	$0x0, 0x18(%rax)
    1678:      	movq	$0x0, 0x10(%rax)
    1680:      	movq	$0x0, 0x8(%rax)
    1688:      	movq	$0x0, (%rax)
    168f:      	leaq	0x10(%rax), %rdi
    1693:      	leaq	0x18(%r8), %rdx
    1697:      	movl	$0x3f, %ecx
    169c:      	movl	$0x2d, %eax
    16a1:      	movl	$0x3f, %esi
    16a6:      	callq	*%rax
    16a8:      	testq	%rax, %rax
    16ab:      	js	0x2799 <generic_lsm_process_event+0x25c9>
    16b1:      	movq	0x10(%rsp), %rdi
    16b6:      	addq	$0x8, %rdi
    16ba:      	movq	0x20(%rsp), %rdx
    16bf:      	addq	$0x348, %rdx            # imm = 0x348
    16c6:      	movl	$0x8, %ecx
    16cb:      	movl	$0x4, %eax
    16d0:      	movl	$0x8, %esi
    16d5:      	callq	*%rax
    16d7:      	movl	$0x50, %r15d
    16dd:      	movq	%r12, %rcx
    16e0:      	jmp	0x32ae <generic_lsm_process_event+0x30de>
    16e5:      	movq	%r13, %rbp
    16e8:      	cmpl	$0x8, %r12d
    16ec:      	je	0x1df3 <generic_lsm_process_event+0x1c23>
    16f2:      	cmpl	$0x12, %r12d
    16f6:      	movq	0x8(%rsp), %rcx
    16fb:      	movq	%rbp, %r13
    16fe:      	movq	0x18(%rsp), %rbp
    1703:      	movq	(%rsp), %rsi
    1707:      	movq	0x20(%rsp), %rdx
    170c:      	jne	0x27eb <generic_lsm_process_event+0x261b>
    1712:      	movq	0xc8(%rsp), %r12
    171a:      	andl	$0x3ff, %r12d           # imm = 0x3FF
    1721:      	movq	%rcx, %r15
    1724:      	movl	$0x4, %eax
    1729:      	movq	0x10(%rsp), %rdi
    172e:      	movl	%r12d, %esi
    1731:      	callq	*%rax
    1733:      	movq	(%rsp), %rsi
    1737:      	movq	%r15, %rcx
    173a:      	movq	%r12, %r15
    173d:      	testl	%r15d, %r15d
    1740:      	js	0x32c5 <generic_lsm_process_event+0x30f5>
    1746:      	jmp	0x27f4 <generic_lsm_process_event+0x2624>
    174b:      	cmpl	$0x13, %r12d
    174f:      	je	0x2122 <generic_lsm_process_event+0x1f52>
    1755:      	cmpl	$0x14, %r12d
    1759:      	movq	0x8(%rsp), %rcx
    175e:      	movq	(%rsp), %rsi
    1762:      	movq	0x20(%rsp), %r8
    1767:      	jne	0x27eb <generic_lsm_process_event+0x261b>
    176d:      	movq	$0x0, 0x60(%rsp)
    1776:      	leaq	0x110(%r8), %rdx
    177d:      	leaq	0x60(%rsp), %rdi
    1782:      	movl	$0x8, %esi
    1787:      	movl	$0x4, %eax
    178c:      	leaq	0xd8(%r8), %rcx
    1793:      	movq	%rcx, 0x28(%rsp)
    1798:      	movl	$0x8, %esi
    179d:      	movq	%r8, %r15
    17a0:      	callq	*%rax
    17a2:      	movq	0x60(%rsp), %rcx
    17a7:      	movl	$0x80, %edx
    17ac:      	movl	$0x2d, %eax
    17b1:      	movq	0x10(%rsp), %r12
    17b6:      	movq	0x60(%rsp), %rdx
    17bb:      	movq	%r12, %rdi
    17be:      	movl	$0x80, %esi
    17c3:      	callq	*%rax
    17c5:      	leaq	0x90(%r12), %rdi
    17cd:      	movl	$0x4, %ecx
    17d2:      	movl	$0x4, %eax
    17d7:      	movq	0x28(%rsp), %rdx
    17dc:      	movl	$0x4, %esi
    17e1:      	callq	*%rax
    17e3:      	leaq	0x80(%r12), %rdi
    17eb:      	leaq	0xe0(%r15), %rdx
    17f2:      	movl	$0x8, %ecx
    17f7:      	movl	$0x4, %eax
    17fc:      	movl	$0x8, %esi
    1801:      	callq	*%rax
    1803:      	addq	$0x88, %r12
    180a:      	addq	$0x118, %r15            # imm = 0x118
    1811:      	movl	$0x8, %ecx
    1816:      	movl	$0x4, %eax
    181b:      	movq	%r12, %rdi
    181e:      	movl	$0x8, %esi
    1823:      	movq	%r15, %rdx
    1826:      	callq	*%rax
    1828:      	movq	(%rsp), %rsi
    182c:      	movq	0x8(%rsp), %rcx
    1831:      	movl	$0x98, %r15d
    1837:      	testl	%r15d, %r15d
    183a:      	js	0x32c5 <generic_lsm_process_event+0x30f5>
    1840:      	jmp	0x27f4 <generic_lsm_process_event+0x2624>
    1845:      	cmpl	$0x26, %r12d
    1849:      	movq	(%rsp), %rsi
    184d:      	jne	0x27e6 <generic_lsm_process_event+0x2616>
    1853:      	movq	0x50(%rsp), %rsi
    1858:      	movzwl	%si, %edx
    185b:      	addq	%rbx, %rdx
    185e:      	shrl	$0x10, %esi
    1861:      	andl	$0xfff, %esi            # imm = 0xFFF
    1867:      	movq	0x10(%rsp), %r13
    186c:      	leaq	0x4(%r13), %rdi
    1870:      	incl	%esi
    1872:      	movl	$0x2d, %eax
    1877:      	jmp	0x1ccd <generic_lsm_process_event+0x1afd>
    187c:      	movq	$0x0, 0x68(%rsp)
    1885:      	movl	$0xe, %eax
    188a:      	callq	*%rax
    188c:      	shrq	$0x20, %rax
    1890:      	movq	%rax, 0x60(%rsp)
    1895:      	leaq	0xa0(%rsp), %rdi
    189d:      	leaq	0x50(%rsp), %rdx
    18a2:      	movl	$0x4, %ecx
    18a7:      	movl	$0x4, %eax
    18ac:      	movl	$0x4, %r14d
    18b2:      	movl	$0x4, %esi
    18b7:      	callq	*%rax
    18b9:      	movl	0xa0(%rsp), %eax
    18c0:      	movl	%eax, 0x68(%rsp)
    18c4:      	movq	(%rip), %rdi            # 0x18cb <generic_lsm_process_event+0x16fb>
    18cb:      	leaq	0x60(%rsp), %rsi
    18d0:      	movl	$0x1, %eax
    18d5:      	callq	*%rax
    18d7:      	testq	%rax, %rax
    18da:      	je	0x22a5 <generic_lsm_process_event+0x20d5>
    18e0:      	movl	(%rax), %r15d
    18e3:      	leaq	0xa0(%rsp), %rdx
    18eb:      	movq	%rax, %r12
    18ee:      	movl	$0x4, %eax
    18f3:      	movq	0x10(%rsp), %rbp
    18f8:      	movq	%rbp, %rdi
    18fb:      	movl	$0x4, %esi
    1900:      	callq	*%rax
    1902:      	andl	$0xfff, %r15d           # imm = 0xFFF
    1909:      	leaq	0x4(%rbp), %rdi
    190d:      	leaq	0x4(%r15), %rsi
    1911:      	movl	$0x4, %eax
    1916:      	movq	%r12, %rdx
    1919:      	callq	*%rax
    191b:      	leaq	(%r15,%rbp), %rdi
    191f:      	addq	$0x8, %rdi
    1923:      	leaq	(%r15,%r12), %rdx
    1927:      	addq	$0x4, %rdx
    192b:      	movl	$0x4, %eax
    1930:      	movl	$0x4, %esi
    1935:      	callq	*%rax
    1937:      	addq	$0xc, %r15
    193b:      	jmp	0x255d <generic_lsm_process_event+0x238d>
    1940:      	movq	%rbx, 0x58(%rsp)
    1945:      	movq	0x50(%rsp), %r14
    194a:      	leaq	0xb8(%rsp), %rdi
    1952:      	movl	$0x1, %ecx
    1957:      	movl	$0x4, %eax
    195c:      	movl	$0x1, %esi
    1961:      	movq	%r14, %rdx
    1964:      	callq	*%rax
    1966:      	movzbl	0xb8(%rsp), %eax
    196e:      	testl	%eax, %eax
    1970:      	je	0x22b1 <generic_lsm_process_event+0x20e1>
    1976:      	cmpl	$0x1, %eax
    1979:      	jne	0x2567 <generic_lsm_process_event+0x2397>
    197f:      	addq	$0x10, %r14
    1983:      	leaq	0xa0(%rsp), %rdi
    198b:      	movl	$0x8, %r15d
    1991:      	movl	$0x8, %ecx
    1996:      	movl	$0x4, %eax
    199b:      	movl	$0x8, %esi
    19a0:      	movq	%r14, %rdx
    19a3:      	callq	*%rax
    19a5:      	movq	0xa0(%rsp), %rdx
    19ad:      	leaq	0x38(%rsp), %rdi
    19b2:      	movl	$0x8, %ecx
    19b7:      	movl	$0x4, %eax
    19bc:      	movl	$0x8, %esi
    19c1:      	callq	*%rax
    19c3:      	movq	0xa0(%rsp), %rdx
    19cb:      	addq	$0x8, %rdx
    19cf:      	leaq	0xc0(%rsp), %rdi
    19d7:      	movl	$0x8, %ecx
    19dc:      	movl	$0x4, %eax
    19e1:      	movl	$0x8, %esi
    19e6:      	callq	*%rax
    19e8:      	movq	0x38(%rsp), %r14
    19ed:      	movq	0xc0(%rsp), %rbx
    19f5:      	movq	0x20(%rsp), %rax
    19fa:      	leaq	(%rax,%r13), %r12
    19fe:      	addq	$0x90, %r12
    1a05:      	testb	$0x20, 0x28(%rsp)
    1a0a:      	je	0x2e52 <generic_lsm_process_event+0x2c82>
    1a10:      	cmpq	$0x1000, %rbx           # imm = 0x1000
    1a17:      	jb	0x2e26 <generic_lsm_process_event+0x2c56>
    1a1d:      	movl	$0x1, (%r12)
    1a25:      	movl	$0x0, 0xd0(%rsp)
    1a30:      	movq	(%rip), %rdi            # 0x1a37 <generic_lsm_process_event+0x1867>
    1a37:      	leaq	0xd0(%rsp), %rsi
    1a3f:      	movl	$0x1, %eax
    1a44:      	callq	*%rax
    1a46:      	testq	%rax, %rax
    1a49:      	je	0x2fc5 <generic_lsm_process_event+0x2df5>
    1a4f:      	movq	%rax, %r13
    1a52:      	movl	$0x18, (%rax)
    1a58:      	movl	$0xe, %eax
    1a5d:      	callq	*%rax
    1a5f:      	movq	%r13, %r15
    1a62:      	addq	$0x10, %r15
    1a66:      	movq	%rax, 0x10(%r13)
    1a6a:      	cmpq	$-0x16, %rax
    1a6e:      	jne	0x1a97 <generic_lsm_process_event+0x18c7>
    1a70:      	movq	0x58(%rsp), %rax
    1a75:      	leaq	0x20(%rax), %rdx
    1a79:      	leaq	0x60(%rsp), %rdi
    1a7e:      	movl	$0x8, %ecx
    1a83:      	movl	$0x4, %eax
    1a88:      	movl	$0x8, %esi
    1a8d:      	callq	*%rax
    1a8f:      	movq	0x60(%rsp), %rax
    1a94:      	movq	%rax, (%r15)
    1a97:      	movl	$0x7d, %eax
    1a9c:      	callq	*%rax
    1a9e:      	movq	%rax, 0x18(%r13)
    1aa2:      	movq	(%r15), %rax
    1aa5:      	movq	0x8(%r15), %rcx
    1aa9:      	movq	%rax, 0x14(%r12)
    1aae:      	movq	%rcx, 0x1c(%r12)
    1ab3:      	movq	0x58(%rsp), %rdi
    1ab8:      	movq	%r13, %rsi
    1abb:      	movq	%r14, %rdx
    1abe:      	movq	%rbx, %rcx
    1ac1:      	callq	0x1ac6 <generic_lsm_process_event+0x18f6>
    1ac6:      	testl	%eax, %eax
    1ac8:      	js	0x3177 <generic_lsm_process_event+0x2fa7>
    1ace:      	movq	$0x0, 0x4(%r12)
    1ad7:      	movl	%ebx, %edx
    1ad9:      	subl	%eax, %edx
    1adb:      	xorl	%ecx, %ecx
    1add:      	cmpq	$-0x1, %rbx
    1ae1:      	jmp	0x23f6 <generic_lsm_process_event+0x2226>
    1ae6:      	movq	%rbx, 0x58(%rsp)
    1aeb:      	movq	0x50(%rsp), %r12
    1af0:      	movq	0x10(%rsp), %rbx
    1af5:      	leaq	0x28(%rbx), %rdi
    1af9:      	leaq	0x98(%r12), %rdx
    1b01:      	movl	$0x4, %ecx
    1b06:      	movl	$0x4, %eax
    1b0b:      	movl	$0x4, %esi
    1b10:      	callq	*%rax
    1b12:      	leaq	0x2c(%rbx), %rdi
    1b16:      	leaq	0x70(%r12), %rdx
    1b1b:      	movl	$0x4, %ecx
    1b20:      	movl	$0x4, %eax
    1b25:      	movl	$0x4, %esi
    1b2a:      	callq	*%rax
    1b2c:      	leaq	0x30(%rbx), %rdi
    1b30:      	leaq	0x90(%r12), %rdx
    1b38:      	movl	$0x4, %ecx
    1b3d:      	movl	$0x4, %eax
    1b42:      	movl	$0x4, %esi
    1b47:      	callq	*%rax
    1b49:      	leaq	0x34(%rbx), %rdi
    1b4d:      	leaq	0xa8(%r12), %rdx
    1b55:      	movl	$0x4, %ecx
    1b5a:      	movl	$0x4, %eax
    1b5f:      	movl	$0x4, %esi
    1b64:      	callq	*%rax
    1b66:      	movq	$0x0, 0x60(%rsp)
    1b6f:      	leaq	0xc8(%r12), %rdx
    1b77:      	leaq	0x60(%rsp), %rdi
    1b7c:      	movl	$0x8, %ecx
    1b81:      	movl	$0x4, %eax
    1b86:      	movl	$0x8, %esi
    1b8b:      	callq	*%rax
    1b8d:      	leaq	0xb8(%r12), %rdx
    1b95:      	leaq	0xc0(%rsp), %rdi
    1b9d:      	movl	$0x2, %ecx
    1ba2:      	movl	$0x4, %eax
    1ba7:      	movl	$0x2, %esi
    1bac:      	callq	*%rax
    1bae:      	movzwl	0xc0(%rsp), %r15d
    1bb7:      	addq	0x60(%rsp), %r15
    1bbc:      	leaq	0xbf(%rsp), %rdi
    1bc4:      	movl	$0x1, %ecx
    1bc9:      	movl	$0x4, %eax
    1bce:      	movl	$0x1, %esi
    1bd3:      	movq	%r15, %rdx
    1bd6:      	callq	*%rax
    1bd8:      	movzbl	0xbf(%rsp), %eax
    1be0:      	shrl	$0x4, %eax
    1be3:      	cmpl	$0x6, %eax
    1be6:      	je	0x23fe <generic_lsm_process_event+0x222e>
    1bec:      	cmpl	$0x4, %eax
    1bef:      	jne	0x397d <generic_lsm_process_event+0x37ad>
    1bf5:      	leaq	0x9(%r15), %rdx
    1bf9:      	leaq	0xb8(%rsp), %rdi
    1c01:      	movl	$0x1, %ecx
    1c06:      	movl	$0x4, %eax
    1c0b:      	movl	$0x1, %esi
    1c10:      	callq	*%rax
    1c12:      	movzbl	0xb8(%rsp), %eax
    1c1a:      	movq	0x10(%rsp), %rdi
    1c1f:      	movw	%ax, 0x24(%rdi)
    1c23:      	movw	$0x2, 0x26(%rdi)
    1c29:      	leaq	0xc(%r15), %rdx
    1c2d:      	movq	$0x0, (%rdi)
    1c34:      	movq	$0x0, 0x8(%rdi)
    1c3c:      	movq	$0x0, 0x10(%rdi)
    1c44:      	movq	$0x0, 0x18(%rdi)
    1c4c:      	movl	$0x4, %ecx
    1c51:      	movl	$0x4, %eax
    1c56:      	leaq	0x10(%rdi), %rbx
    1c5a:      	movl	$0x4, %esi
    1c5f:      	callq	*%rax
    1c61:      	addq	$0x10, %r15
    1c65:      	movl	$0x4, %ecx
    1c6a:      	movl	$0x4, %eax
    1c6f:      	movq	%rbx, %rdi
    1c72:      	movl	$0x4, %esi
    1c77:      	movq	%r15, %rdx
    1c7a:      	callq	*%rax
    1c7c:      	leaq	0xb6(%r12), %rdx
    1c84:      	leaq	0xd0(%rsp), %rdi
    1c8c:      	movl	$0x2, %ecx
    1c91:      	movl	$0x4, %eax
    1c96:      	movl	$0x2, %esi
    1c9b:      	callq	*%rax
    1c9d:      	movzbl	0xb8(%rsp), %r15d
    1ca6:      	jmp	0x3815 <generic_lsm_process_event+0x3645>
    1cab:      	movl	$0x120, %edx            # imm = 0x120
    1cb0:      	addq	0x50(%rsp), %rdx
    1cb5:      	movq	0x10(%rsp), %r13
    1cba:      	leaq	0x4(%r13), %rdi
    1cbe:      	movl	$0x11, %ecx
    1cc3:      	movl	$0x2d, %eax
    1cc8:      	movl	$0x11, %esi
    1ccd:      	callq	*%rax
    1ccf:      	movq	%rax, %r15
    1cd2:      	testq	%rax, %rax
    1cd5:      	js	0x27dd <generic_lsm_process_event+0x260d>
    1cdb:      	leal	-0x1(%r15), %eax
    1cdf:      	movl	%eax, (%r13)
    1ce3:      	addq	$0x3, %r15
    1ce7:      	jmp	0x27dd <generic_lsm_process_event+0x260d>
    1cec:      	movq	0x50(%rsp), %r15
    1cf1:      	movq	0x10(%rsp), %r12
    1cf6:      	movq	$0x0, 0x10(%r12)
    1cff:      	movq	$0x0, 0x8(%r12)
    1d08:      	movq	$0x0, (%r12)
    1d10:      	movl	$0x2, %ecx
    1d15:      	movl	$0x4, %eax
    1d1a:      	movq	%r12, %rdi
    1d1d:      	movl	$0x2, %esi
    1d22:      	movq	%r15, %rdx
    1d25:      	callq	*%rax
    1d27:      	testq	%rax, %rax
    1d2a:      	js	0x26c5 <generic_lsm_process_event+0x24f5>
    1d30:      	movzwl	(%r12), %eax
    1d35:      	cmpl	$0xa, %eax
    1d38:      	je	0x266e <generic_lsm_process_event+0x249e>
    1d3e:      	cmpl	$0x2, %eax
    1d41:      	jne	0x26aa <generic_lsm_process_event+0x24da>
    1d47:      	leaq	0x4(%r15), %rdx
    1d4b:      	leaq	0x60(%rsp), %rdi
    1d50:      	movl	$0x4, %ecx
    1d55:      	movl	$0x4, %eax
    1d5a:      	movl	$0x4, %esi
    1d5f:      	callq	*%rax
    1d61:      	movl	0x60(%rsp), %eax
    1d65:      	movq	0x10(%rsp), %rcx
    1d6a:      	movq	%rax, 0x8(%rcx)
    1d6e:      	leaq	0x2(%rcx), %rdi
    1d72:      	addq	$0x2, %r15
    1d76:      	movl	$0x2, %ecx
    1d7b:      	movl	$0x4, %eax
    1d80:      	jmp	0x26a0 <generic_lsm_process_event+0x24d0>
    1d85:      	movq	%rbx, 0x58(%rsp)
    1d8a:      	movq	0xb0(%rsp), %rax
    1d92:      	movq	%rcx, %r13
    1d95:      	leaq	(%rcx,%rax), %rbx
    1d99:      	addq	$0x90, %rbx
    1da0:      	movq	$0x0, 0x50(%rsp)
    1da9:      	testb	$0x10, 0x28(%rsp)
    1dae:      	jne	0x2583 <generic_lsm_process_event+0x23b3>
    1db4:      	movq	0x28(%rsp), %rdx
    1db9:      	movl	%edx, %ebp
    1dbb:      	andl	$0xf, %edx
    1dbe:      	xorl	%eax, %eax
    1dc0:      	movq	%rdx, %rcx
    1dc3:      	cmpl	$0x2, %edx
    1dc6:      	jle	0x2807 <generic_lsm_process_event+0x2637>
    1dcc:      	cmpl	$0x3, %ecx
    1dcf:      	je	0x2fe0 <generic_lsm_process_event+0x2e10>
    1dd5:      	cmpl	$0x4, %ecx
    1dd8:      	je	0x2fe9 <generic_lsm_process_event+0x2e19>
    1dde:      	cmpl	$0x5, %ecx
    1de1:      	jne	0x2ffc <generic_lsm_process_event+0x2e2c>
    1de7:      	leaq	0x5e70(%r13), %rax
    1dee:      	jmp	0x2ff9 <generic_lsm_process_event+0x2e29>
    1df3:      	movq	0x10(%rsp), %r15
    1df8:      	leaq	0x28(%r15), %r13
    1dfc:      	leaq	0x40(%r15), %rax
    1e00:      	movq	%rax, 0x28(%rsp)
    1e05:      	movq	0x20(%rsp), %r12
    1e0a:      	leaq	0x8(%r12), %rdx
    1e0f:      	movl	$0x4, %ecx
    1e14:      	movl	$0x4, %eax
    1e19:      	movq	%r15, %rdi
    1e1c:      	movl	$0x4, %esi
    1e21:      	callq	*%rax
    1e23:      	leaq	0x4(%r15), %rdi
    1e27:      	leaq	0xc(%r12), %rdx
    1e2c:      	movl	$0x4, %ecx
    1e31:      	movl	$0x4, %eax
    1e36:      	movl	$0x4, %esi
    1e3b:      	callq	*%rax
    1e3d:      	leaq	0x10(%r15), %rdi
    1e41:      	leaq	0x18(%r12), %rdx
    1e46:      	movl	$0x4, %ecx
    1e4b:      	movl	$0x4, %eax
    1e50:      	movl	$0x4, %esi
    1e55:      	callq	*%rax
    1e57:      	leaq	0x14(%r15), %rdi
    1e5b:      	leaq	0x1c(%r12), %rdx
    1e60:      	movl	$0x4, %ecx
    1e65:      	movl	$0x4, %eax
    1e6a:      	movl	$0x4, %esi
    1e6f:      	callq	*%rax
    1e71:      	leaq	0x8(%r15), %rdi
    1e75:      	leaq	0x10(%r12), %rdx
    1e7a:      	movl	$0x4, %ecx
    1e7f:      	movl	$0x4, %eax
    1e84:      	movl	$0x4, %esi
    1e89:      	callq	*%rax
    1e8b:      	leaq	0xc(%r15), %rdi
    1e8f:      	leaq	0x14(%r12), %rdx
    1e94:      	movl	$0x4, %ecx
    1e99:      	movl	$0x4, %eax
    1e9e:      	movl	$0x4, %esi
    1ea3:      	callq	*%rax
    1ea5:      	leaq	0x18(%r15), %rdi
    1ea9:      	leaq	0x20(%r12), %rdx
    1eae:      	movl	$0x4, %ecx
    1eb3:      	movl	$0x4, %eax
    1eb8:      	movl	$0x4, %esi
    1ebd:      	callq	*%rax
    1ebf:      	leaq	0x1c(%r15), %rdi
    1ec3:      	leaq	0x24(%r12), %rdx
    1ec8:      	movl	$0x4, %ecx
    1ecd:      	movl	$0x4, %eax
    1ed2:      	movl	$0x4, %esi
    1ed7:      	callq	*%rax
    1ed9:      	movl	$0x0, 0x24(%r15)
    1ee1:      	leaq	0x20(%r15), %rdi
    1ee5:      	leaq	0x28(%r12), %rdx
    1eea:      	movl	$0x4, %ecx
    1eef:      	movl	$0x4, %eax
    1ef4:      	movl	$0x4, %esi
    1ef9:      	callq	*%rax
    1efb:      	leaq	0x30(%r15), %rdi
    1eff:      	leaq	0x40(%r12), %rdx
    1f04:      	movl	$0x8, %ecx
    1f09:      	movl	$0x4, %eax
    1f0e:      	movl	$0x8, %esi
    1f13:      	callq	*%rax
    1f15:      	leaq	0x38(%r15), %rdi
    1f19:      	leaq	0x30(%r12), %rdx
    1f1e:      	movl	$0x8, %ecx
    1f23:      	movl	$0x4, %eax
    1f28:      	movl	$0x8, %esi
    1f2d:      	callq	*%rax
    1f2f:      	leaq	0x38(%r12), %rdx
    1f34:      	movl	$0x8, %ecx
    1f39:      	movl	$0x4, %eax
    1f3e:      	movq	%r13, %rdi
    1f41:      	movl	$0x8, %esi
    1f46:      	callq	*%rax
    1f48:      	addq	$0x90, %r12
    1f4f:      	leaq	0x60(%rsp), %rdi
    1f54:      	movl	$0x8, %ecx
    1f59:      	movl	$0x4, %eax
    1f5e:      	movl	$0x8, %esi
    1f63:      	movq	%r12, %rdx
    1f66:      	callq	*%rax
    1f68:      	movq	0x60(%rsp), %r12
    1f6d:      	leaq	0xc8(%r12), %rdx
    1f75:      	movl	$0x4, %ecx
    1f7a:      	movl	$0x4, %eax
    1f7f:      	movq	0x28(%rsp), %rdi
    1f84:      	movl	$0x4, %esi
    1f89:      	callq	*%rax
    1f8b:      	leaq	0x44(%r15), %rdi
    1f8f:      	leaq	0xcc(%r12), %rdx
    1f97:      	movl	$0x4, %ecx
    1f9c:      	movl	$0x4, %eax
    1fa1:      	movl	$0x4, %esi
    1fa6:      	callq	*%rax
    1fa8:      	leaq	0x48(%r15), %rdi
    1fac:      	leaq	0xd0(%r12), %rdx
    1fb4:      	movl	$0x4, %ecx
    1fb9:      	movl	$0x4, %eax
    1fbe:      	movl	$0x4, %esi
    1fc3:      	callq	*%rax
    1fc5:      	addq	$0x4c, %r15
    1fc9:      	addq	$0x158, %r12            # imm = 0x158
    1fd0:      	movl	$0x4, %ecx
    1fd5:      	movl	$0x4, %eax
    1fda:      	movq	%r15, %rdi
    1fdd:      	movl	$0x4, %esi
    1fe2:      	movq	%r12, %rdx
    1fe5:      	callq	*%rax
    1fe7:      	movl	$0x50, %r15d
    1fed:      	movq	0x8(%rsp), %rcx
    1ff2:      	movq	%rbp, %r13
    1ff5:      	jmp	0xff5 <generic_lsm_process_event+0xe25>
    1ffa:      	movq	0x20(%rsp), %r12
    1fff:      	leaq	0xc8(%r12), %rdx
    2007:      	movl	$0x4, %ecx
    200c:      	movl	$0x4, %eax
    2011:      	movq	0x10(%rsp), %r15
    2016:      	movq	%r15, %rdi
    2019:      	movl	$0x4, %esi
    201e:      	callq	*%rax
    2020:      	leaq	0x4(%r15), %rdi
    2024:      	leaq	0xcc(%r12), %rdx
    202c:      	movl	$0x4, %ecx
    2031:      	movl	$0x4, %eax
    2036:      	movl	$0x4, %esi
    203b:      	callq	*%rax
    203d:      	leaq	0x8(%r15), %rdi
    2041:      	leaq	0xd0(%r12), %rdx
    2049:      	movl	$0x4, %ecx
    204e:      	movl	$0x4, %eax
    2053:      	movl	$0x4, %esi
    2058:      	callq	*%rax
    205a:      	addq	$0xc, %r15
    205e:      	addq	$0x158, %r12            # imm = 0x158
    2065:      	movl	$0x4, %ecx
    206a:      	movl	$0x4, %eax
    206f:      	movq	%r15, %rdi
    2072:      	movl	$0x4, %esi
    2077:      	movq	%r12, %rdx
    207a:      	callq	*%rax
    207c:      	movl	$0x10, %r15d
    2082:      	jmp	0x2218 <generic_lsm_process_event+0x2048>
    2087:      	movq	0x20(%rsp), %r12
    208c:      	leaq	0x38(%r12), %rdx
    2091:      	movl	$0x4, %ecx
    2096:      	movl	$0x4, %eax
    209b:      	movq	0x10(%rsp), %r15
    20a0:      	movq	%r15, %rdi
    20a3:      	movl	$0x4, %esi
    20a8:      	callq	*%rax
    20aa:      	leaq	0x4(%r15), %rdi
    20ae:      	leaq	0x3c(%r12), %rdx
    20b3:      	movl	$0x4, %ecx
    20b8:      	movl	$0x4, %eax
    20bd:      	movl	$0x4, %esi
    20c2:      	callq	*%rax
    20c4:      	leaq	0x8(%r15), %rdi
    20c8:      	leaq	0x40(%r12), %rdx
    20cd:      	movl	$0x4, %ecx
    20d2:      	movl	$0x4, %eax
    20d7:      	movl	$0x4, %esi
    20dc:      	callq	*%rax
    20de:      	leaq	0xc(%r15), %rdi
    20e2:      	leaq	0x44(%r12), %rdx
    20e7:      	movl	$0x4, %ecx
    20ec:      	movl	$0x4, %eax
    20f1:      	movl	$0x4, %esi
    20f6:      	callq	*%rax
    20f8:      	addq	$0x10, %r15
    20fc:      	subq	$-0x80, %r12
    2100:      	movl	$0x10, %ecx
    2105:      	movl	$0x4, %eax
    210a:      	movq	%r15, %rdi
    210d:      	movl	$0x10, %esi
    2112:      	movq	%r12, %rdx
    2115:      	callq	*%rax
    2117:      	movl	$0x20, %r15d
    211d:      	jmp	0x2218 <generic_lsm_process_event+0x2048>
    2122:      	movl	$0x4, %ecx
    2127:      	movl	$0x4, %eax
    212c:      	movq	0x10(%rsp), %r15
    2131:      	movq	0x20(%rsp), %r12
    2136:      	movq	%r15, %rdi
    2139:      	movl	$0x4, %esi
    213e:      	movq	%r12, %rdx
    2141:      	callq	*%rax
    2143:      	leaq	0x4(%r15), %rdi
    2147:      	leaq	0x4(%r12), %rdx
    214c:      	movl	$0x4, %ecx
    2151:      	movl	$0x4, %eax
    2156:      	movl	$0x4, %esi
    215b:      	callq	*%rax
    215d:      	addq	$0x8, %r15
    2161:      	addq	$0x30, %r12
    2165:      	movl	$0x10, %ecx
    216a:      	movl	$0x4, %eax
    216f:      	movq	%r15, %rdi
    2172:      	movl	$0x10, %esi
    2177:      	movq	%r12, %rdx
    217a:      	jmp	0x2210 <generic_lsm_process_event+0x2040>
    217f:      	leaq	0x4(%r8), %rdx
    2183:      	leaq	0x60(%rsp), %rdi
    2188:      	movl	$0x4, %ecx
    218d:      	movl	$0x4, %eax
    2192:      	movl	$0x4, %esi
    2197:      	movq	%r8, %r12
    219a:      	callq	*%rax
    219c:      	movl	0x60(%rsp), %eax
    21a0:      	movq	0x10(%rsp), %r15
    21a5:      	movl	%eax, (%r15)
    21a8:      	leaq	0xc(%r12), %rdx
    21ad:      	leaq	0x60(%rsp), %rdi
    21b2:      	movl	$0x4, %ecx
    21b7:      	movl	$0x4, %eax
    21bc:      	movl	$0x4, %esi
    21c1:      	callq	*%rax
    21c3:      	movl	0x60(%rsp), %eax
    21c7:      	movl	%eax, 0x4(%r15)
    21cb:      	addq	$0x50, %r12
    21cf:      	leaq	0x60(%rsp), %rdi
    21d4:      	movl	$0x8, %ecx
    21d9:      	movl	$0x2d, %eax
    21de:      	movl	$0x8, %esi
    21e3:      	movq	%r12, %rdx
    21e6:      	callq	*%rax
    21e8:      	addq	$0x8, %r15
    21ec:      	movl	$0x3f8, %edx            # imm = 0x3F8
    21f1:      	movq	0x60(%rsp), %rcx
    21f6:      	addq	%rdx, %rcx
    21f9:      	movl	$0x10, %esi
    21fe:      	movl	$0x2d, %eax
    2203:      	addq	0x60(%rsp), %rdx
    2208:      	movq	%r15, %rdi
    220b:      	movl	$0x10, %esi
    2210:      	callq	*%rax
    2212:      	movl	$0x18, %r15d
    2218:      	movq	0x8(%rsp), %rcx
    221d:      	jmp	0xffa <generic_lsm_process_event+0xe2a>
    2222:      	movq	0x10(%rsp), %rax
    2227:      	movq	$0x0, 0x48(%rax)
    222f:      	movq	$0x0, 0x40(%rax)
    2237:      	movq	$0x0, 0x38(%rax)
    223f:      	movq	$0x0, 0x30(%rax)
    2247:      	movq	$0x0, 0x28(%rax)
    224f:      	movq	$0x0, 0x20(%rax)
    2257:      	movq	$0x0, 0x18(%rax)
    225f:      	movq	$0x0, 0x10(%rax)
    2267:      	movq	$0x0, 0x8(%rax)
    226f:      	movq	$0x0, (%rax)
    2276:      	leaq	0x60(%rsp), %rdi
    227b:      	movl	$0x8, %ecx
    2280:      	movl	$0x4, %eax
    2285:      	movl	$0x8, %esi
    228a:      	movq	%r8, %rdx
    228d:      	callq	*%rax
    228f:      	testq	%rax, %rax
    2292:      	je	0x26d0 <generic_lsm_process_event+0x2500>
    2298:      	xorl	%r15d, %r15d
    229b:      	movq	0x8(%rsp), %rcx
    22a0:      	jmp	0x32ae <generic_lsm_process_event+0x30de>
    22a5:      	movq	$-0x1, %r15
    22ac:      	jmp	0x255d <generic_lsm_process_event+0x238d>
    22b1:      	leaq	0x10(%r14), %rdx
    22b5:      	leaq	0x38(%rsp), %rdi
    22ba:      	movl	$0x8, %ebx
    22bf:      	movl	$0x8, %ecx
    22c4:      	movl	$0x4, %eax
    22c9:      	movl	$0x8, %esi
    22ce:      	callq	*%rax
    22d0:      	addq	$0x18, %r14
    22d4:      	leaq	0xc0(%rsp), %rdi
    22dc:      	movl	$0x8, %ecx
    22e1:      	movl	$0x4, %eax
    22e6:      	movl	$0x8, %esi
    22eb:      	movq	%r14, %rdx
    22ee:      	callq	*%rax
    22f0:      	movq	0x38(%rsp), %rax
    22f5:      	movq	%rax, 0x28(%rsp)
    22fa:      	movq	0xc0(%rsp), %r14
    2302:      	movq	0x20(%rsp), %rax
    2307:      	leaq	(%rax,%r13), %r12
    230b:      	addq	$0x90, %r12
    2312:      	testb	$0x20, 0xc8(%rsp)
    231a:      	je	0x2ec6 <generic_lsm_process_event+0x2cf6>
    2320:      	cmpq	$0x1000, %r14           # imm = 0x1000
    2327:      	jb	0x2e9b <generic_lsm_process_event+0x2ccb>
    232d:      	movl	$0x1, (%r12)
    2335:      	movl	$0x0, 0xd0(%rsp)
    2340:      	movq	(%rip), %rdi            # 0x2347 <generic_lsm_process_event+0x2177>
    2347:      	leaq	0xd0(%rsp), %rsi
    234f:      	movl	$0x1, %eax
    2354:      	callq	*%rax
    2356:      	testq	%rax, %rax
    2359:      	je	0x2fc5 <generic_lsm_process_event+0x2df5>
    235f:      	movq	%rax, %r15
    2362:      	movl	$0x18, (%rax)
    2368:      	movl	$0xe, %eax
    236d:      	callq	*%rax
    236f:      	movq	%r15, %r13
    2372:      	addq	$0x10, %r13
    2376:      	movq	%rax, 0x10(%r15)
    237a:      	cmpq	$-0x16, %rax
    237e:      	jne	0x23a8 <generic_lsm_process_event+0x21d8>
    2380:      	movq	0x58(%rsp), %rax
    2385:      	leaq	0x20(%rax), %rdx
    2389:      	leaq	0x60(%rsp), %rdi
    238e:      	movl	$0x8, %ecx
    2393:      	movl	$0x4, %eax
    2398:      	movl	$0x8, %esi
    239d:      	callq	*%rax
    239f:      	movq	0x60(%rsp), %rax
    23a4:      	movq	%rax, (%r13)
    23a8:      	movl	$0x7d, %eax
    23ad:      	callq	*%rax
    23af:      	movq	%rax, 0x18(%r15)
    23b3:      	movq	(%r13), %rax
    23b7:      	movq	0x8(%r13), %rcx
    23bb:      	movq	%rax, 0x14(%r12)
    23c0:      	movq	%rcx, 0x1c(%r12)
    23c5:      	movq	0x58(%rsp), %rdi
    23ca:      	movq	%r15, %rsi
    23cd:      	movq	0x28(%rsp), %rdx
    23d2:      	movq	%r14, %rcx
    23d5:      	callq	0x23da <generic_lsm_process_event+0x220a>
    23da:      	testl	%eax, %eax
    23dc:      	js	0x3177 <generic_lsm_process_event+0x2fa7>
    23e2:      	movq	$0x0, 0x4(%r12)
    23eb:      	movl	%r14d, %edx
    23ee:      	subl	%eax, %edx
    23f0:      	xorl	%ecx, %ecx
    23f2:      	cmpq	$-0x1, %r14
    23f6:      	cmovnel	%edx, %ecx
    23f9:      	jmp	0x3189 <generic_lsm_process_event+0x2fb9>
    23fe:      	movq	0x60(%rsp), %rbx
    2403:      	movl	$0x0, 0xa0(%rsp)
    240e:      	movzwl	0xc0(%rsp), %r15d
    2417:      	movq	(%rip), %rdi            # 0x241e <generic_lsm_process_event+0x224e>
    241e:      	leaq	0xa0(%rsp), %rsi
    2426:      	movl	$0x1, %eax
    242b:      	leaq	(%rbx,%r15), %r13
    242f:      	callq	*%rax
    2431:      	testq	%rax, %rax
    2434:      	je	0x37c3 <generic_lsm_process_event+0x35f3>
    243a:      	movq	%rax, %rbp
    243d:      	movw	%r15w, (%rax)
    2441:      	movb	$-0x1, 0x5(%rax)
    2445:      	movb	$0x0, 0x7(%rax)
    2449:      	movq	%rax, %rdi
    244c:      	addq	$0x6, %rdi
    2450:      	leaq	0x6(%r13), %rdx
    2454:      	movl	$0x1, %ecx
    2459:      	movl	$0x4, %eax
    245e:      	movq	%rdi, 0x20(%rsp)
    2463:      	movl	$0x1, %esi
    2468:      	callq	*%rax
    246a:      	testq	%rax, %rax
    246d:      	js	0x37c3 <generic_lsm_process_event+0x35f3>
    2473:      	movzbl	0x5(%rbp), %eax
    2477:      	cmpl	$0x32, %eax
    247a:      	jg	0x2f14 <generic_lsm_process_event+0x2d44>
    2480:      	testl	%eax, %eax
    2482:      	je	0x2fd0 <generic_lsm_process_event+0x2e00>
    2488:      	cmpl	$0x2b, %eax
    248b:      	je	0x2fd0 <generic_lsm_process_event+0x2e00>
    2491:      	cmpl	$0x2c, %eax
    2494:      	jne	0x3279 <generic_lsm_process_event+0x30a9>
    249a:      	movw	$0x8, 0x2(%rbp)
    24a0:      	movw	$0x8, %ax
    24a4:      	jmp	0x31b8 <generic_lsm_process_event+0x2fe8>
    24a9:      	leaq	0x48(%r15), %rdx
    24ad:      	movl	$0x10, %ecx
    24b2:      	movl	$0x4, %eax
    24b7:      	movq	%rbp, %rdi
    24ba:      	movl	$0x10, %esi
    24bf:      	callq	*%rax
    24c1:      	leaq	0x38(%r15), %rdx
    24c5:      	movl	$0x10, %ecx
    24ca:      	movl	$0x4, %eax
    24cf:      	movq	%r12, %rdi
    24d2:      	movl	$0x10, %esi
    24d7:      	callq	*%rax
    24d9:      	leaq	0x20(%rbp), %rdi
    24dd:      	leaq	0xc(%r15), %r12
    24e1:      	addq	$0xe, %r15
    24e5:      	movl	$0x2, %ecx
    24ea:      	movl	$0x4, %eax
    24ef:      	movl	$0x2, %esi
    24f4:      	movq	%r15, %rdx
    24f7:      	callq	*%rax
    24f9:      	leaq	0x22(%rbp), %rdi
    24fd:      	movl	$0x2, %ecx
    2502:      	movl	$0x4, %eax
    2507:      	movl	$0x2, %esi
    250c:      	movq	%r12, %rdx
    250f:      	callq	*%rax
    2511:      	movzwl	0x22(%rbp), %eax
    2515:      	movbew	%ax, 0x22(%rbp)
    251b:      	movq	0x50(%rsp), %rax
    2520:      	movq	%rax, 0x60(%rsp)
    2525:      	movq	(%rip), %rdi            # 0x252c <generic_lsm_process_event+0x235c>
    252c:      	leaq	0x60(%rsp), %rsi
    2531:      	movl	$0x1, %eax
    2536:      	callq	*%rax
    2538:      	testq	%rax, %rax
    253b:      	je	0x2557 <generic_lsm_process_event+0x2387>
    253d:      	movl	(%rax), %ecx
    253f:      	movq	0x20(%rsp), %r13
    2544:      	movl	%ecx, 0x10(%r13)
    2548:      	movq	0x8(%rax), %rcx
    254c:      	movq	%rcx, 0x18(%r13)
    2550:      	movl	0x4(%rax), %eax
    2553:      	movl	%eax, 0x7c(%r13)
    2557:      	movl	$0x40, %r15d
    255d:      	movq	0x8(%rsp), %rcx
    2562:      	jmp	0x398d <generic_lsm_process_event+0x37bd>
    2567:      	movq	0x20(%rsp), %rax
    256c:      	movq	$0x0, 0x90(%rax,%r13)
    2578:      	movl	$0x8, %r15d
    257e:      	jmp	0x3983 <generic_lsm_process_event+0x37b3>
    2583:      	movl	$0xe, %eax
    2588:      	callq	*%rax
    258a:      	cmpq	$-0x16, %rax
    258e:      	jne	0x25b4 <generic_lsm_process_event+0x23e4>
    2590:      	movq	0x58(%rsp), %rax
    2595:      	leaq	0x20(%rax), %rdx
    2599:      	leaq	0x60(%rsp), %rdi
    259e:      	movl	$0x8, %ecx
    25a3:      	movl	$0x4, %eax
    25a8:      	movl	$0x8, %esi
    25ad:      	callq	*%rax
    25af:      	movq	0x60(%rsp), %rax
    25b4:      	movq	0x8(%r13), %rcx
    25b8:      	movq	0x60(%r13), %rdx
    25bc:      	movq	%rcx, 0x60(%rsp)
    25c1:      	movq	0x20(%rsp), %rcx
    25c6:      	movq	%rcx, 0x68(%rsp)
    25cb:      	movq	$0x0, 0x70(%rsp)
    25d4:      	movq	%rdx, 0xa0(%rsp)
    25dc:      	movq	%rax, 0xa8(%rsp)
    25e4:      	movq	(%rip), %rdi            # 0x25eb <generic_lsm_process_event+0x241b>
    25eb:      	xorl	%ecx, %ecx
    25ed:      	leaq	0xa0(%rsp), %rsi
    25f5:      	leaq	0x60(%rsp), %rdx
    25fa:      	movl	$0x2, %eax
    25ff:      	xorl	%ecx, %ecx
    2601:      	callq	*%rax
    2603:      	testq	%rax, %rax
    2606:      	je	0x2f6a <generic_lsm_process_event+0x2d9a>
    260c:      	negl	%eax
    260e:      	movw	%ax, 0x38(%rsp)
    2613:      	movw	$0x5, 0x3a(%rsp)
    261a:      	movabsq	$0x200000046, %rax      # imm = 0x200000046
    2624:      	movq	%rax, 0x3c(%rsp)
    2629:      	movq	(%rip), %rdi            # 0x2630 <generic_lsm_process_event+0x2460>
    2630:      	leaq	0x38(%rsp), %rsi
    2635:      	movl	$0x1, %eax
    263a:      	callq	*%rax
    263c:      	testq	%rax, %rax
    263f:      	je	0x2f40 <generic_lsm_process_event+0x2d70>
    2645:      	incl	(%rax)
    2647:      	jmp	0x2f6a <generic_lsm_process_event+0x2d9a>
    264c:      	cmpl	$0x1, %eax
    264f:      	je	0x2904 <generic_lsm_process_event+0x2734>
    2655:      	cmpl	$0x2, %eax
    2658:      	jne	0x2d29 <generic_lsm_process_event+0x2b59>
    265e:      	movq	0x28(%rsp), %rax
    2663:      	addq	$0x5e58, %rax           # imm = 0x5E58
    2669:      	jmp	0x290f <generic_lsm_process_event+0x273f>
    266e:      	movq	0x10(%rsp), %r12
    2673:      	leaq	0x8(%r12), %rdi
    2678:      	leaq	0x8(%r15), %rdx
    267c:      	movl	$0x10, %ecx
    2681:      	movl	$0x4, %eax
    2686:      	movl	$0x10, %esi
    268b:      	callq	*%rax
    268d:      	leaq	0x2(%r12), %rdi
    2692:      	addq	$0x2, %r15
    2696:      	movl	$0x2, %ecx
    269b:      	movl	$0x4, %eax
    26a0:      	movl	$0x2, %esi
    26a5:      	movq	%r15, %rdx
    26a8:      	callq	*%rax
    26aa:      	movq	0x10(%rsp), %r13
    26af:      	movzwl	0x2(%r13), %eax
    26b4:      	movbew	%ax, 0x2(%r13)
    26bb:      	movq	0x18(%rsp), %rbp
    26c0:      	movq	0x30(%rsp), %r14
    26c5:      	movl	$0x18, %r15d
    26cb:      	jmp	0x27dd <generic_lsm_process_event+0x260d>
    26d0:      	movq	0x10(%rsp), %rax
    26d5:      	leaq	0x10(%rax), %rdi
    26d9:      	movq	0x60(%rsp), %rcx
    26de:      	movl	$0x3f, %edx
    26e3:      	movl	$0x2d, %eax
    26e8:      	movq	0x60(%rsp), %rdx
    26ed:      	movl	$0x3f, %esi
    26f2:      	callq	*%rax
    26f4:      	testq	%rax, %rax
    26f7:      	js	0x2298 <generic_lsm_process_event+0x20c8>
    26fd:      	movq	0x20(%rsp), %r15
    2702:      	leaq	0x8(%r15), %rdx
    2706:      	leaq	0xa0(%rsp), %rdi
    270e:      	movl	$0x8, %ecx
    2713:      	movl	$0x4, %eax
    2718:      	movl	$0x8, %esi
    271d:      	callq	*%rax
    271f:      	movq	0x10(%rsp), %rax
    2724:      	leaq	0x8(%rax), %rdi
    2728:      	movl	$0x348, %edx            # imm = 0x348
    272d:      	movq	0xa0(%rsp), %rcx
    2735:      	addq	%rdx, %rcx
    2738:      	movl	$0x8, %esi
    273d:      	movl	$0x4, %eax
    2742:      	addq	0xa0(%rsp), %rdx
    274a:      	movl	$0x8, %esi
    274f:      	callq	*%rax
    2751:      	addq	$0x58, %r15
    2755:      	leaq	0xa0(%rsp), %rdi
    275d:      	movl	$0x4, %ecx
    2762:      	movl	$0x4, %eax
    2767:      	movl	$0x4, %esi
    276c:      	movq	%r15, %rdx
    276f:      	callq	*%rax
    2771:      	movl	$0x50, %r15d
    2777:      	testq	%rax, %rax
    277a:      	jne	0x229b <generic_lsm_process_event+0x20cb>
    2780:      	xorl	%eax, %eax
    2782:      	cmpl	$0x0, 0xa0(%rsp)
    278a:      	setne	%al
    278d:      	movq	0x10(%rsp), %rcx
    2792:      	movl	%eax, (%rcx)
    2794:      	jmp	0x229b <generic_lsm_process_event+0x20cb>
    2799:      	xorl	%r15d, %r15d
    279c:      	movq	%r12, %rcx
    279f:      	jmp	0x32ae <generic_lsm_process_event+0x30de>
    27a4:      	addq	$0x3, %r15
    27a8:      	movl	$0x6b, %ecx
    27ad:      	movl	$0x71, %eax
    27b2:      	movl	$0x6b, %esi
    27b7:      	movq	%r15, %rdx
    27ba:      	callq	*%rax
    27bc:      	movq	%rax, %rcx
    27bf:      	movb	$0x6b, %al
    27c1:      	testl	%ecx, %ecx
    27c3:      	movq	0x18(%rsp), %rbp
    27c8:      	movq	0x30(%rsp), %r14
    27cd:      	js	0x27d7 <generic_lsm_process_event+0x2607>
    27cf:      	movq	0x10(%rsp), %rcx
    27d4:      	movb	%al, 0x3(%rcx)
    27d7:      	movl	$0x70, %r15d
    27dd:      	movq	0x8(%rsp), %rcx
    27e2:      	movq	(%rsp), %rsi
    27e6:      	movq	0x48(%rsp), %r13
    27eb:      	testl	%r15d, %r15d
    27ee:      	js	0x32c5 <generic_lsm_process_event+0x30f5>
    27f4:      	andl	$0x7fffffff, %r15d      # imm = 0x7FFFFFFF
    27fb:      	addl	$0x4, %r15d
    27ff:      	movl	%r15d, %edx
    2802:      	jmp	0x32e0 <generic_lsm_process_event+0x3110>
    2807:      	cmpl	$0x1, %ecx
    280a:      	je	0x2ff2 <generic_lsm_process_event+0x2e22>
    2810:      	cmpl	$0x2, %ecx
    2813:      	jne	0x2ffc <generic_lsm_process_event+0x2e2c>
    2819:      	leaq	0x5e58(%r13), %rax
    2820:      	jmp	0x2ff9 <generic_lsm_process_event+0x2e29>
    2825:      	leaq	0x48(%r15), %rdx
    2829:      	movl	$0x10, %ecx
    282e:      	movl	$0x4, %eax
    2833:      	movq	0x10(%rsp), %rdi
    2838:      	movl	$0x10, %esi
    283d:      	callq	*%rax
    283f:      	leaq	0x38(%r15), %rdx
    2843:      	movl	$0x10, %ecx
    2848:      	movl	$0x4, %eax
    284d:      	movq	%r12, %rdi
    2850:      	movl	$0x10, %esi
    2855:      	callq	*%rax
    2857:      	movq	0x10(%rsp), %rbp
    285c:      	leaq	0x20(%rbp), %rdi
    2860:      	leaq	0xc(%r15), %r12
    2864:      	addq	$0xe, %r15
    2868:      	movl	$0x2, %ecx
    286d:      	movl	$0x4, %eax
    2872:      	movl	$0x2, %esi
    2877:      	movq	%r15, %rdx
    287a:      	callq	*%rax
    287c:      	leaq	0x22(%rbp), %rdi
    2880:      	movl	$0x2, %ecx
    2885:      	movl	$0x4, %eax
    288a:      	movl	$0x2, %esi
    288f:      	movq	%r12, %rdx
    2892:      	callq	*%rax
    2894:      	movzwl	0x22(%rbp), %eax
    2898:      	movbew	%ax, 0x22(%rbp)
    289e:      	movq	0x10(%rsp), %rax
    28a3:      	movq	0x28(%rax), %rax
    28a7:      	movq	%rax, 0x60(%rsp)
    28ac:      	movq	(%rip), %rdi            # 0x28b3 <generic_lsm_process_event+0x26e3>
    28b3:      	leaq	0x60(%rsp), %rsi
    28b8:      	movl	$0x1, %eax
    28bd:      	callq	*%rax
    28bf:      	testq	%rax, %rax
    28c2:      	je	0x28dc <generic_lsm_process_event+0x270c>
    28c4:      	movl	(%rax), %ecx
    28c6:      	movq	0x28(%rsp), %rdx
    28cb:      	movl	%ecx, 0x10(%rdx)
    28ce:      	movq	0x8(%rax), %rcx
    28d2:      	movq	%rcx, 0x18(%rdx)
    28d6:      	movl	0x4(%rax), %eax
    28d9:      	movl	%eax, 0x7c(%rdx)
    28dc:      	movl	$0x40, %r15d
    28e2:      	movq	%r13, %rcx
    28e5:      	jmp	0x32a9 <generic_lsm_process_event+0x30d9>
    28ea:      	movq	0x28(%rsp), %rax
    28ef:      	addq	$0x5e60, %rax           # imm = 0x5E60
    28f5:      	jmp	0x290f <generic_lsm_process_event+0x273f>
    28f7:      	movq	0x28(%rsp), %rax
    28fc:      	addq	$0x5e68, %rax           # imm = 0x5E68
    2902:      	jmp	0x290f <generic_lsm_process_event+0x273f>
    2904:      	movq	0x28(%rsp), %rax
    2909:      	addq	$0x5e50, %rax           # imm = 0x5E50
    290f:      	movq	(%rax), %r12
    2912:      	testb	$0x10, 0xc8(%rsp)
    291a:      	jne	0x2d40 <generic_lsm_process_event+0x2b70>
    2920:      	testq	%r12, %r12
    2923:      	je	0x2e05 <generic_lsm_process_event+0x2c35>
    2929:      	leaq	0x60(%rsp), %rdi
    292e:      	movl	$0x4, %r15d
    2934:      	movl	$0x10, %ecx
    2939:      	movl	$0x4, %eax
    293e:      	movq	0x20(%rsp), %rdx
    2943:      	movl	$0x10, %esi
    2948:      	callq	*%rax
    294a:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    294f:      	testl	%eax, %eax
    2951:      	js	0x2d18 <generic_lsm_process_event+0x2b48>
    2957:      	movq	0x68(%rsp), %r13
    295c:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2961:      	cmpq	$0xffe, %r13            # imm = 0xFFE
    2968:      	ja	0x2d18 <generic_lsm_process_event+0x2b48>
    296e:      	movq	0x18(%rsp), %rax
    2973:      	leaq	0xc(%rax), %rdi
    2977:      	movq	%rdi, %r14
    297a:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2980:      	addq	%rbp, %rdi
    2983:      	movq	0x60(%rsp), %rcx
    2988:      	movl	$0x4, %eax
    298d:      	movq	0x60(%rsp), %rdx
    2992:      	movl	%r13d, %esi
    2995:      	callq	*%rax
    2997:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    299c:      	testl	%eax, %eax
    299e:      	js	0x2d18 <generic_lsm_process_event+0x2b48>
    29a4:      	cmpq	$0x1, %r12
    29a8:      	je	0x2e08 <generic_lsm_process_event+0x2c38>
    29ae:      	movq	0x20(%rsp), %rax
    29b3:      	leaq	0x10(%rax), %rdx
    29b7:      	leaq	0x60(%rsp), %rdi
    29bc:      	movl	$0x4, %r15d
    29c2:      	movl	$0x10, %ecx
    29c7:      	movl	$0x4, %eax
    29cc:      	movl	$0x10, %esi
    29d1:      	callq	*%rax
    29d3:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    29d8:      	testl	%eax, %eax
    29da:      	js	0x2d18 <generic_lsm_process_event+0x2b48>
    29e0:      	movq	0x68(%rsp), %rax
    29e5:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    29ea:      	movq	%rax, 0x28(%rsp)
    29ef:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    29f5:      	ja	0x2d18 <generic_lsm_process_event+0x2b48>
    29fb:      	addq	%r13, %r14
    29fe:      	movq	%r14, 0xc8(%rsp)
    2a06:      	movl	%r14d, %edi
    2a09:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2a0f:      	addq	%rbp, %rdi
    2a12:      	movq	0x60(%rsp), %rcx
    2a17:      	movl	$0x4, %eax
    2a1c:      	movq	0x28(%rsp), %rsi
    2a21:      	movq	0x60(%rsp), %rdx
    2a26:      	callq	*%rax
    2a28:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2a2d:      	testl	%eax, %eax
    2a2f:      	js	0x2d18 <generic_lsm_process_event+0x2b48>
    2a35:      	addq	0x28(%rsp), %r13
    2a3a:      	cmpq	$0x3, %r12
    2a3e:      	jb	0x2e08 <generic_lsm_process_event+0x2c38>
    2a44:      	movq	0x20(%rsp), %rax
    2a49:      	leaq	0x20(%rax), %rdx
    2a4d:      	leaq	0x60(%rsp), %rdi
    2a52:      	movl	$0x4, %r15d
    2a58:      	movl	$0x10, %ecx
    2a5d:      	movl	$0x4, %eax
    2a62:      	movl	$0x10, %esi
    2a67:      	callq	*%rax
    2a69:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2a6e:      	testl	%eax, %eax
    2a70:      	js	0x2d18 <generic_lsm_process_event+0x2b48>
    2a76:      	movq	0x68(%rsp), %rax
    2a7b:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2a80:      	movq	%rax, 0x10(%rsp)
    2a85:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    2a8b:      	ja	0x2d18 <generic_lsm_process_event+0x2b48>
    2a91:      	movq	0x28(%rsp), %rdi
    2a96:      	addq	0xc8(%rsp), %rdi
    2a9e:      	movq	%rdi, %r14
    2aa1:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2aa7:      	addq	%rbp, %rdi
    2aaa:      	movq	0x60(%rsp), %rcx
    2aaf:      	movl	$0x4, %eax
    2ab4:      	movq	0x10(%rsp), %rsi
    2ab9:      	movq	0x60(%rsp), %rdx
    2abe:      	callq	*%rax
    2ac0:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2ac5:      	testl	%eax, %eax
    2ac7:      	js	0x2d18 <generic_lsm_process_event+0x2b48>
    2acd:      	addq	0x10(%rsp), %r13
    2ad2:      	cmpq	$0x3, %r12
    2ad6:      	je	0x2e08 <generic_lsm_process_event+0x2c38>
    2adc:      	movq	0x20(%rsp), %rax
    2ae1:      	leaq	0x30(%rax), %rdx
    2ae5:      	leaq	0x60(%rsp), %rdi
    2aea:      	movl	$0x4, %r15d
    2af0:      	movl	$0x10, %ecx
    2af5:      	movl	$0x4, %eax
    2afa:      	movl	$0x10, %esi
    2aff:      	callq	*%rax
    2b01:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2b06:      	testl	%eax, %eax
    2b08:      	js	0x2d18 <generic_lsm_process_event+0x2b48>
    2b0e:      	movq	0x68(%rsp), %rax
    2b13:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2b18:      	movq	%rax, 0x28(%rsp)
    2b1d:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    2b23:      	ja	0x2d18 <generic_lsm_process_event+0x2b48>
    2b29:      	movq	0x10(%rsp), %rdi
    2b2e:      	addq	%r14, %rdi
    2b31:      	movq	%rdi, %r14
    2b34:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2b3a:      	addq	%rbp, %rdi
    2b3d:      	movq	0x60(%rsp), %rcx
    2b42:      	movl	$0x4, %eax
    2b47:      	movq	0x28(%rsp), %rsi
    2b4c:      	movq	0x60(%rsp), %rdx
    2b51:      	callq	*%rax
    2b53:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2b58:      	testl	%eax, %eax
    2b5a:      	js	0x2d18 <generic_lsm_process_event+0x2b48>
    2b60:      	addq	0x28(%rsp), %r13
    2b65:      	cmpq	$0x5, %r12
    2b69:      	jb	0x2e08 <generic_lsm_process_event+0x2c38>
    2b6f:      	movq	0x20(%rsp), %rax
    2b74:      	leaq	0x40(%rax), %rdx
    2b78:      	leaq	0x60(%rsp), %rdi
    2b7d:      	movl	$0x4, %r15d
    2b83:      	movl	$0x10, %ecx
    2b88:      	movl	$0x4, %eax
    2b8d:      	movl	$0x10, %esi
    2b92:      	callq	*%rax
    2b94:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2b99:      	testl	%eax, %eax
    2b9b:      	js	0x2d18 <generic_lsm_process_event+0x2b48>
    2ba1:      	movq	0x68(%rsp), %rax
    2ba6:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2bab:      	movq	%rax, 0xc8(%rsp)
    2bb3:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    2bb9:      	ja	0x2d18 <generic_lsm_process_event+0x2b48>
    2bbf:      	movq	0x28(%rsp), %rdi
    2bc4:      	addq	%r14, %rdi
    2bc7:      	movq	%rdi, %r14
    2bca:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2bd0:      	addq	%rbp, %rdi
    2bd3:      	movq	0x60(%rsp), %rcx
    2bd8:      	movl	$0x4, %eax
    2bdd:      	movq	0xc8(%rsp), %rsi
    2be5:      	movq	0x60(%rsp), %rdx
    2bea:      	callq	*%rax
    2bec:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2bf1:      	testl	%eax, %eax
    2bf3:      	js	0x2d18 <generic_lsm_process_event+0x2b48>
    2bf9:      	addq	0xc8(%rsp), %r13
    2c01:      	cmpq	$0x5, %r12
    2c05:      	je	0x2e08 <generic_lsm_process_event+0x2c38>
    2c0b:      	movq	0x20(%rsp), %rax
    2c10:      	leaq	0x50(%rax), %rdx
    2c14:      	leaq	0x60(%rsp), %rdi
    2c19:      	movl	$0x4, %r15d
    2c1f:      	movl	$0x10, %ecx
    2c24:      	movl	$0x4, %eax
    2c29:      	movl	$0x10, %esi
    2c2e:      	callq	*%rax
    2c30:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2c35:      	testl	%eax, %eax
    2c37:      	js	0x2d18 <generic_lsm_process_event+0x2b48>
    2c3d:      	movq	0x68(%rsp), %rax
    2c42:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2c47:      	movq	%rax, 0x28(%rsp)
    2c4c:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    2c52:      	ja	0x2d18 <generic_lsm_process_event+0x2b48>
    2c58:      	movq	0xc8(%rsp), %rdi
    2c60:      	addq	%r14, %rdi
    2c63:      	movq	%rdi, %r14
    2c66:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2c6c:      	addq	%rbp, %rdi
    2c6f:      	movq	0x60(%rsp), %rcx
    2c74:      	movl	$0x4, %eax
    2c79:      	movq	0x28(%rsp), %rsi
    2c7e:      	movq	0x60(%rsp), %rdx
    2c83:      	callq	*%rax
    2c85:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2c8a:      	testl	%eax, %eax
    2c8c:      	js	0x2d18 <generic_lsm_process_event+0x2b48>
    2c92:      	addq	0x28(%rsp), %r13
    2c97:      	cmpq	$0x7, %r12
    2c9b:      	jb	0x2e08 <generic_lsm_process_event+0x2c38>
    2ca1:      	movq	0x20(%rsp), %rdx
    2ca6:      	addq	$0x60, %rdx
    2caa:      	leaq	0x60(%rsp), %rdi
    2caf:      	movl	$0x4, %r15d
    2cb5:      	movl	$0x10, %ecx
    2cba:      	movl	$0x4, %eax
    2cbf:      	movl	$0x10, %esi
    2cc4:      	callq	*%rax
    2cc6:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2ccb:      	testl	%eax, %eax
    2ccd:      	js	0x2d18 <generic_lsm_process_event+0x2b48>
    2ccf:      	movq	0x68(%rsp), %r12
    2cd4:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2cd9:      	cmpq	$0xffe, %r12            # imm = 0xFFE
    2ce0:      	ja	0x2d18 <generic_lsm_process_event+0x2b48>
    2ce2:      	movq	0x28(%rsp), %rdi
    2ce7:      	addq	%r14, %rdi
    2cea:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2cf0:      	addq	%rbp, %rdi
    2cf3:      	movq	0x60(%rsp), %rcx
    2cf8:      	movl	$0x4, %eax
    2cfd:      	movq	0x60(%rsp), %rdx
    2d02:      	movl	%r12d, %esi
    2d05:      	callq	*%rax
    2d07:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2d0c:      	testl	%eax, %eax
    2d0e:      	js	0x2d18 <generic_lsm_process_event+0x2b48>
    2d10:      	addq	%r12, %r13
    2d13:      	jmp	0x2e08 <generic_lsm_process_event+0x2c38>
    2d18:      	movq	0xb0(%rsp), %rax
    2d20:      	movl	%ecx, (%rbp,%rax)
    2d24:      	jmp	0x2fbb <generic_lsm_process_event+0x2deb>
    2d29:      	xorl	%r12d, %r12d
    2d2c:      	movl	$0x0, %r13d
    2d32:      	testb	$0x10, 0xc8(%rsp)
    2d3a:      	je	0x2e08 <generic_lsm_process_event+0x2c38>
    2d40:      	movl	$0xe, %eax
    2d45:      	callq	*%rax
    2d47:      	cmpq	$-0x16, %rax
    2d4b:      	jne	0x2d6c <generic_lsm_process_event+0x2b9c>
    2d4d:      	leaq	0x20(%rbx), %rdx
    2d51:      	leaq	0x60(%rsp), %rdi
    2d56:      	movl	$0x8, %ecx
    2d5b:      	movl	$0x4, %eax
    2d60:      	movl	$0x8, %esi
    2d65:      	callq	*%rax
    2d67:      	movq	0x60(%rsp), %rax
    2d6c:      	movq	0x28(%rsp), %rdx
    2d71:      	movq	0x8(%rdx), %rcx
    2d75:      	movq	0x60(%rdx), %rdx
    2d79:      	movq	%rcx, 0x60(%rsp)
    2d7e:      	movq	0x20(%rsp), %rcx
    2d83:      	movq	%rcx, 0x68(%rsp)
    2d88:      	movq	%r12, 0x70(%rsp)
    2d8d:      	movq	%rdx, 0xa0(%rsp)
    2d95:      	movq	%rax, 0xa8(%rsp)
    2d9d:      	movq	(%rip), %rdi            # 0x2da4 <generic_lsm_process_event+0x2bd4>
    2da4:      	xorl	%ecx, %ecx
    2da6:      	leaq	0xa0(%rsp), %rsi
    2dae:      	leaq	0x60(%rsp), %rdx
    2db3:      	movl	$0x2, %eax
    2db8:      	xorl	%ecx, %ecx
    2dba:      	callq	*%rax
    2dbc:      	testq	%rax, %rax
    2dbf:      	je	0x2fa5 <generic_lsm_process_event+0x2dd5>
    2dc5:      	negl	%eax
    2dc7:      	movw	%ax, 0x38(%rsp)
    2dcc:      	movw	$0x5, 0x3a(%rsp)
    2dd3:      	movabsq	$0x200000057, %rax      # imm = 0x200000057
    2ddd:      	movq	%rax, 0x3c(%rsp)
    2de2:      	movq	(%rip), %rdi            # 0x2de9 <generic_lsm_process_event+0x2c19>
    2de9:      	leaq	0x38(%rsp), %rsi
    2dee:      	movl	$0x1, %eax
    2df3:      	callq	*%rax
    2df5:      	testq	%rax, %rax
    2df8:      	je	0x2f7b <generic_lsm_process_event+0x2dab>
    2dfe:      	incl	(%rax)
    2e00:      	jmp	0x2fa5 <generic_lsm_process_event+0x2dd5>
    2e05:      	xorl	%r13d, %r13d
    2e08:      	movq	0xb0(%rsp), %rax
    2e10:      	movl	%r13d, (%rbp,%rax)
    2e15:      	movl	%r13d, 0x4(%rbp,%rax)
    2e1a:      	addq	$0x8, %r13
    2e1e:      	movq	%r13, %r15
    2e21:      	jmp	0x2fbb <generic_lsm_process_event+0x2deb>
    2e26:      	movq	0x20(%rsp), %rax
    2e2b:      	addq	$0x90, %rax
    2e31:      	movl	$0x0, (%r12)
    2e39:      	movq	0x18(%rsp), %rcx
    2e3e:      	leal	0x8(%rcx), %r12d
    2e42:      	andl	$0x3fff, %r12d          # imm = 0x3FFF
    2e49:      	addq	%rax, %r12
    2e4c:      	movl	$0xc, %r15d
    2e52:      	cmpq	$0xfff, %rbx            # imm = 0xFFF
    2e59:      	movl	$0xfff, %ebp            # imm = 0xFFF
    2e5e:      	cmovbq	%rbx, %rbp
    2e62:      	leaq	0x8(%r12), %rdi
    2e67:      	movl	$0x4, %eax
    2e6c:      	movl	%ebp, %esi
    2e6e:      	movq	%r14, %rdx
    2e71:      	callq	*%rax
    2e73:      	testl	%eax, %eax
    2e75:      	js	0x2e88 <generic_lsm_process_event+0x2cb8>
    2e77:      	movl	%ebx, (%r12)
    2e7b:      	movl	%ebp, 0x4(%r12)
    2e80:      	addq	%rbp, %r15
    2e83:      	jmp	0x3983 <generic_lsm_process_event+0x37b3>
    2e88:      	movl	$0xfffffffe, (%r12)     # imm = 0xFFFFFFFE
    2e90:      	movl	$0x4, %r15d
    2e96:      	jmp	0x3983 <generic_lsm_process_event+0x37b3>
    2e9b:      	movq	0x20(%rsp), %rax
    2ea0:      	addq	$0x90, %rax
    2ea6:      	movl	$0x0, (%r12)
    2eae:      	movq	0x18(%rsp), %rcx
    2eb3:      	leal	0x8(%rcx), %r12d
    2eb7:      	andl	$0x3fff, %r12d          # imm = 0x3FFF
    2ebe:      	addq	%rax, %r12
    2ec1:      	movl	$0xc, %ebx
    2ec6:      	cmpq	$0xfff, %r14            # imm = 0xFFF
    2ecd:      	movl	$0xfff, %ebp            # imm = 0xFFF
    2ed2:      	cmovbq	%r14, %rbp
    2ed6:      	leaq	0x8(%r12), %rdi
    2edb:      	movl	$0x4, %eax
    2ee0:      	movq	0x28(%rsp), %rdx
    2ee5:      	movl	$0x4, %r15d
    2eeb:      	movl	%ebp, %esi
    2eed:      	callq	*%rax
    2eef:      	testl	%eax, %eax
    2ef1:      	js	0x2f07 <generic_lsm_process_event+0x2d37>
    2ef3:      	movl	%r14d, (%r12)
    2ef7:      	movl	%ebp, 0x4(%r12)
    2efc:      	addq	%rbp, %rbx
    2eff:      	movq	%rbx, %r15
    2f02:      	jmp	0x3983 <generic_lsm_process_event+0x37b3>
    2f07:      	movl	$0xfffffffe, (%r12)     # imm = 0xFFFFFFFE
    2f0f:      	jmp	0x3983 <generic_lsm_process_event+0x37b3>
    2f14:      	cmpl	$0x33, %eax
    2f17:      	je	0x31a9 <generic_lsm_process_event+0x2fd9>
    2f1d:      	cmpl	$0x3c, %eax
    2f20:      	je	0x2fd0 <generic_lsm_process_event+0x2e00>
    2f26:      	cmpl	$0xff, %eax
    2f2b:      	jne	0x3279 <generic_lsm_process_event+0x30a9>
    2f31:      	movw	$0x28, 0x2(%rbp)
    2f37:      	movw	$0x28, %ax
    2f3b:      	jmp	0x31b8 <generic_lsm_process_event+0x2fe8>
    2f40:      	movl	$0x1, 0xd0(%rsp)
    2f4b:      	movq	(%rip), %rdi            # 0x2f52 <generic_lsm_process_event+0x2d82>
    2f52:      	xorl	%ecx, %ecx
    2f54:      	leaq	0x38(%rsp), %rsi
    2f59:      	leaq	0xd0(%rsp), %rdx
    2f61:      	movl	$0x2, %eax
    2f66:      	xorl	%ecx, %ecx
    2f68:      	callq	*%rax
    2f6a:      	movl	$0xfffffffc, (%rbx)     # imm = 0xFFFFFFFC
    2f70:      	movl	$0x4, %r15d
    2f76:      	jmp	0x329f <generic_lsm_process_event+0x30cf>
    2f7b:      	movl	$0x1, 0xc0(%rsp)
    2f86:      	movq	(%rip), %rdi            # 0x2f8d <generic_lsm_process_event+0x2dbd>
    2f8d:      	xorl	%ecx, %ecx
    2f8f:      	leaq	0x38(%rsp), %rsi
    2f94:      	leaq	0xc0(%rsp), %rdx
    2f9c:      	movl	$0x2, %eax
    2fa1:      	xorl	%ecx, %ecx
    2fa3:      	callq	*%rax
    2fa5:      	movq	0xb0(%rsp), %rax
    2fad:      	movl	$0xfffffffc, (%rbp,%rax) # imm = 0xFFFFFFFC
    2fb5:      	movl	$0x4, %r15d
    2fbb:      	movq	0x8(%rsp), %rcx
    2fc0:      	jmp	0x32a9 <generic_lsm_process_event+0x30d9>
    2fc5:      	movl	$0x4, %r15d
    2fcb:      	jmp	0x3983 <generic_lsm_process_event+0x37b3>
    2fd0:      	movzbl	0x7(%rbp), %eax
    2fd4:      	leal	0x8(,%rax,8), %eax
    2fdb:      	jmp	0x31b4 <generic_lsm_process_event+0x2fe4>
    2fe0:      	leaq	0x5e60(%r13), %rax
    2fe7:      	jmp	0x2ff9 <generic_lsm_process_event+0x2e29>
    2fe9:      	leaq	0x5e68(%r13), %rax
    2ff0:      	jmp	0x2ff9 <generic_lsm_process_event+0x2e29>
    2ff2:      	leaq	0x5e50(%r13), %rax
    2ff9:      	movq	(%rax), %rax
    2ffc:      	movq	%rax, 0xc0(%rsp)
    3004:      	leaq	0x50(%rsp), %rdi
    3009:      	leaq	0xc0(%rsp), %rdx
    3011:      	movl	$0x8, %ecx
    3016:      	movl	$0x4, %eax
    301b:      	movl	$0x8, %r15d
    3021:      	movl	$0x8, %esi
    3026:      	callq	*%rax
    3028:      	movq	0x50(%rsp), %r12
    302d:      	testb	$0x20, %bpl
    3031:      	je	0x3132 <generic_lsm_process_event+0x2f62>
    3037:      	cmpq	$0x1000, %r12           # imm = 0x1000
    303e:      	jb	0x310e <generic_lsm_process_event+0x2f3e>
    3044:      	movl	$0x1, (%rbx)
    304a:      	movl	$0x0, 0xa0(%rsp)
    3055:      	movq	(%rip), %rdi            # 0x305c <generic_lsm_process_event+0x2e8c>
    305c:      	leaq	0xa0(%rsp), %rsi
    3064:      	movl	$0x1, %eax
    3069:      	callq	*%rax
    306b:      	testq	%rax, %rax
    306e:      	je	0x319e <generic_lsm_process_event+0x2fce>
    3074:      	movq	%rax, %r13
    3077:      	movl	$0x18, (%rax)
    307d:      	movl	$0xe, %eax
    3082:      	callq	*%rax
    3084:      	movq	%r13, %r15
    3087:      	addq	$0x10, %r15
    308b:      	movq	%rax, 0x10(%r13)
    308f:      	cmpq	$-0x16, %rax
    3093:      	jne	0x30bc <generic_lsm_process_event+0x2eec>
    3095:      	movq	0x58(%rsp), %rax
    309a:      	leaq	0x20(%rax), %rdx
    309e:      	leaq	0x60(%rsp), %rdi
    30a3:      	movl	$0x8, %ecx
    30a8:      	movl	$0x4, %eax
    30ad:      	movl	$0x8, %esi
    30b2:      	callq	*%rax
    30b4:      	movq	0x60(%rsp), %rax
    30b9:      	movq	%rax, (%r15)
    30bc:      	movl	$0x7d, %eax
    30c1:      	callq	*%rax
    30c3:      	movq	%rax, 0x18(%r13)
    30c7:      	movq	(%r15), %rax
    30ca:      	movq	0x8(%r15), %rcx
    30ce:      	movq	%rax, 0x14(%rbx)
    30d2:      	movq	%rcx, 0x1c(%rbx)
    30d6:      	movq	0x58(%rsp), %rdi
    30db:      	movq	%r13, %rsi
    30de:      	movq	0x20(%rsp), %rdx
    30e3:      	movq	%r12, %rcx
    30e6:      	callq	0x30eb <generic_lsm_process_event+0x2f1b>
    30eb:      	testl	%eax, %eax
    30ed:      	js	0x3282 <generic_lsm_process_event+0x30b2>
    30f3:      	movq	$0x0, 0x4(%rbx)
    30fb:      	movl	%r12d, %edx
    30fe:      	subl	%eax, %edx
    3100:      	xorl	%ecx, %ecx
    3102:      	cmpq	$-0x1, %r12
    3106:      	cmovnel	%edx, %ecx
    3109:      	jmp	0x3293 <generic_lsm_process_event+0x30c3>
    310e:      	addq	$0x90, %r13
    3115:      	movl	$0x0, (%rbx)
    311b:      	movq	0x18(%rsp), %rax
    3120:      	leal	0x8(%rax), %ebx
    3123:      	andl	$0x3fff, %ebx           # imm = 0x3FFF
    3129:      	addq	%r13, %rbx
    312c:      	movl	$0xc, %r15d
    3132:      	cmpq	$0xfff, %r12            # imm = 0xFFF
    3139:      	movl	$0xfff, %ebp            # imm = 0xFFF
    313e:      	cmovbq	%r12, %rbp
    3142:      	leaq	0x8(%rbx), %rdi
    3146:      	movl	$0x4, %eax
    314b:      	movq	0x20(%rsp), %rdx
    3150:      	movl	%ebp, %esi
    3152:      	callq	*%rax
    3154:      	testl	%eax, %eax
    3156:      	js	0x3166 <generic_lsm_process_event+0x2f96>
    3158:      	movl	%r12d, (%rbx)
    315b:      	movl	%ebp, 0x4(%rbx)
    315e:      	addq	%rbp, %r15
    3161:      	jmp	0x329f <generic_lsm_process_event+0x30cf>
    3166:      	movl	$0xfffffffe, (%rbx)     # imm = 0xFFFFFFFE
    316c:      	movl	$0x4, %r15d
    3172:      	jmp	0x329f <generic_lsm_process_event+0x30cf>
    3177:      	movl	%eax, 0x4(%r12)
    317c:      	movl	$0x0, 0x8(%r12)
    3185:      	xorl	%ecx, %ecx
    3187:      	xorl	%eax, %eax
    3189:      	movl	%ecx, 0xc(%r12)
    318e:      	movl	%eax, 0x10(%r12)
    3193:      	movl	$0x24, %r15d
    3199:      	jmp	0x3983 <generic_lsm_process_event+0x37b3>
    319e:      	movl	$0x4, %r15d
    31a4:      	jmp	0x329f <generic_lsm_process_event+0x30cf>
    31a9:      	movzbl	0x7(%rbp), %eax
    31ad:      	leal	0x8(,%rax,4), %eax
    31b4:      	movw	%ax, 0x2(%rbp)
    31b8:      	addw	(%rbp), %ax
    31bc:      	movw	%ax, (%rbp)
    31c0:      	movzbl	0x6(%rbp), %r15d
    31c5:      	cmpq	$0x3c, %r15
    31c9:      	ja	0x39a0 <generic_lsm_process_event+0x37d0>
    31cf:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    31d9:      	btq	%r15, %rcx
    31dd:      	jae	0x39a0 <generic_lsm_process_event+0x37d0>
    31e3:      	movb	%r15b, 0x5(%rbp)
    31e7:      	movzwl	%ax, %ecx
    31ea:      	addq	%rbx, %rcx
    31ed:      	movl	$0x2, %edx
    31f2:      	movl	$0x4, %eax
    31f7:      	movq	0x20(%rsp), %rdi
    31fc:      	movzwl	(%rbp), %edx
    3200:      	addq	%rbx, %rdx
    3203:      	movl	$0x2, %esi
    3208:      	callq	*%rax
    320a:      	testq	%rax, %rax
    320d:      	js	0x37c3 <generic_lsm_process_event+0x35f3>
    3213:      	movzbl	0x5(%rbp), %eax
    3217:      	cmpl	$0x32, %eax
    321a:      	jg	0x323d <generic_lsm_process_event+0x306d>
    321c:      	testl	%eax, %eax
    321e:      	je	0x3265 <generic_lsm_process_event+0x3095>
    3220:      	cmpl	$0x2b, %eax
    3223:      	je	0x3265 <generic_lsm_process_event+0x3095>
    3225:      	cmpl	$0x2c, %eax
    3228:      	jne	0x33a8 <generic_lsm_process_event+0x31d8>
    322e:      	movw	$0x8, 0x2(%rbp)
    3234:      	movw	$0x8, %ax
    3238:      	jmp	0x33ac <generic_lsm_process_event+0x31dc>
    323d:      	cmpl	$0x33, %eax
    3240:      	je	0x3397 <generic_lsm_process_event+0x31c7>
    3246:      	cmpl	$0x3c, %eax
    3249:      	je	0x3265 <generic_lsm_process_event+0x3095>
    324b:      	cmpl	$0xff, %eax
    3250:      	jne	0x33a8 <generic_lsm_process_event+0x31d8>
    3256:      	movw	$0x28, 0x2(%rbp)
    325c:      	movw	$0x28, %ax
    3260:      	jmp	0x33ac <generic_lsm_process_event+0x31dc>
    3265:      	movzbl	0x7(%rbp), %eax
    3269:      	leal	0x8(,%rax,8), %eax
    3270:      	movw	%ax, 0x2(%rbp)
    3274:      	jmp	0x33ac <generic_lsm_process_event+0x31dc>
    3279:      	movzwl	0x2(%rbp), %eax
    327d:      	jmp	0x31b8 <generic_lsm_process_event+0x2fe8>
    3282:      	movq	%rbx, %rcx
    3285:      	movl	%eax, 0x4(%rbx)
    3288:      	movl	$0x0, 0x8(%rbx)
    328f:      	xorl	%ecx, %ecx
    3291:      	xorl	%eax, %eax
    3293:      	movl	%ecx, 0xc(%rbx)
    3296:      	movl	%eax, 0x10(%rbx)
    3299:      	movl	$0x24, %r15d
    329f:      	movq	0x8(%rsp), %rcx
    32a4:      	movq	0x58(%rsp), %rbx
    32a9:      	movq	0x48(%rsp), %r13
    32ae:      	movq	0x18(%rsp), %rbp
    32b3:      	movq	(%rsp), %rsi
    32b7:      	movq	0x30(%rsp), %r14
    32bc:      	testl	%r15d, %r15d
    32bf:      	jns	0x27f4 <generic_lsm_process_event+0x2624>
    32c5:      	movl	$0xffffffff, 0x5ea0(%rcx,%rsi,4) # imm = 0xFFFFFFFF
    32d0:      	movl	$0xffffffff, 0x90(%rcx,%rbp) # imm = 0xFFFFFFFF
    32db:      	movl	$0x4, %edx
    32e0:      	addl	%ebp, %edx
    32e2:      	movl	%edx, %ebp
    32e4:      	movl	%ebp, 0x4(%r14)
    32e8:      	cmpl	$0x3, %r13d
    32ec:      	jg	0x335d <generic_lsm_process_event+0x318d>
    32ee:      	movl	$0x0, 0x60(%rsp)
    32f6:      	movq	(%rip), %rdi            # 0x32fd <generic_lsm_process_event+0x312d>
    32fd:      	leaq	0x60(%rsp), %rsi
    3302:      	movl	$0x1, %eax
    3307:      	callq	*%rax
    3309:      	testq	%rax, %rax
    330c:      	je	0x335d <generic_lsm_process_event+0x318d>
    330e:      	movq	%rax, %rsi
    3311:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    3318:      	movq	(%rip), %rdi            # 0x331f <generic_lsm_process_event+0x314f>
    331f:      	movl	$0x1, %eax
    3324:      	callq	*%rax
    3326:      	testq	%rax, %rax
    3329:      	je	0x335d <generic_lsm_process_event+0x318d>
    332b:      	incl	%r13d
    332e:      	movl	%r13d, %ecx
    3331:      	andl	$0x7, %ecx
    3334:      	cmpl	$-0x1, 0x40(%rax,%rcx,4)
    3339:      	je	0x335d <generic_lsm_process_event+0x318d>
    333b:      	movl	%r13d, 0x5efc(%r14)
    3342:      	movq	(%rip), %rsi            # 0x3349 <generic_lsm_process_event+0x3179>
    3349:      	movl	$0x1, %ecx
    334e:      	movl	$0xc, %eax
    3353:      	movq	%rbx, %rdi
    3356:      	movl	$0x1, %edx
    335b:      	callq	*%rax
    335d:      	movl	$0x0, 0x5efc(%r14)
    3368:      	movq	(%rip), %rsi            # 0x336f <generic_lsm_process_event+0x319f>
    336f:      	movl	$0x3, %ecx
    3374:      	movl	$0xc, %eax
    3379:      	movq	%rbx, %rdi
    337c:      	movl	$0x3, %edx
    3381:      	callq	*%rax
    3383:      	xorl	%eax, %eax
    3385:      	addq	$0x108, %rsp            # imm = 0x108
    338c:      	popq	%rbx
    338d:      	popq	%r12
    338f:      	popq	%r13
    3391:      	popq	%r14
    3393:      	popq	%r15
    3395:      	popq	%rbp
    3396:      	retq
    3397:      	movzbl	0x7(%rbp), %eax
    339b:      	leal	0x8(,%rax,4), %eax
    33a2:      	movw	%ax, 0x2(%rbp)
    33a6:      	jmp	0x33ac <generic_lsm_process_event+0x31dc>
    33a8:      	movzwl	0x2(%rbp), %eax
    33ac:      	addw	(%rbp), %ax
    33b0:      	movw	%ax, (%rbp)
    33b4:      	movzbl	0x6(%rbp), %r15d
    33b9:      	cmpq	$0x3c, %r15
    33bd:      	ja	0x39a0 <generic_lsm_process_event+0x37d0>
    33c3:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    33cd:      	btq	%r15, %rcx
    33d1:      	jae	0x39a0 <generic_lsm_process_event+0x37d0>
    33d7:      	movb	%r15b, 0x5(%rbp)
    33db:      	movzwl	%ax, %ecx
    33de:      	addq	%rbx, %rcx
    33e1:      	movl	$0x2, %edx
    33e6:      	movl	$0x4, %eax
    33eb:      	movq	0x20(%rsp), %rdi
    33f0:      	movzwl	(%rbp), %edx
    33f4:      	addq	%rbx, %rdx
    33f7:      	movl	$0x2, %esi
    33fc:      	callq	*%rax
    33fe:      	testq	%rax, %rax
    3401:      	js	0x37c3 <generic_lsm_process_event+0x35f3>
    3407:      	movzbl	0x5(%rbp), %eax
    340b:      	cmpl	$0x32, %eax
    340e:      	jg	0x342a <generic_lsm_process_event+0x325a>
    3410:      	testl	%eax, %eax
    3412:      	je	0x3447 <generic_lsm_process_event+0x3277>
    3414:      	cmpl	$0x2b, %eax
    3417:      	je	0x3447 <generic_lsm_process_event+0x3277>
    3419:      	cmpl	$0x2c, %eax
    341c:      	jne	0x3469 <generic_lsm_process_event+0x3299>
    341e:      	movw	$0x8, 0x2(%rbp)
    3424:      	movw	$0x8, %ax
    3428:      	jmp	0x346d <generic_lsm_process_event+0x329d>
    342a:      	cmpl	$0x33, %eax
    342d:      	je	0x3458 <generic_lsm_process_event+0x3288>
    342f:      	cmpl	$0x3c, %eax
    3432:      	je	0x3447 <generic_lsm_process_event+0x3277>
    3434:      	cmpl	$0xff, %eax
    3439:      	jne	0x3469 <generic_lsm_process_event+0x3299>
    343b:      	movw	$0x28, 0x2(%rbp)
    3441:      	movw	$0x28, %ax
    3445:      	jmp	0x346d <generic_lsm_process_event+0x329d>
    3447:      	movzbl	0x7(%rbp), %eax
    344b:      	leal	0x8(,%rax,8), %eax
    3452:      	movw	%ax, 0x2(%rbp)
    3456:      	jmp	0x346d <generic_lsm_process_event+0x329d>
    3458:      	movzbl	0x7(%rbp), %eax
    345c:      	leal	0x8(,%rax,4), %eax
    3463:      	movw	%ax, 0x2(%rbp)
    3467:      	jmp	0x346d <generic_lsm_process_event+0x329d>
    3469:      	movzwl	0x2(%rbp), %eax
    346d:      	addw	(%rbp), %ax
    3471:      	movw	%ax, (%rbp)
    3475:      	movzbl	0x6(%rbp), %r15d
    347a:      	cmpq	$0x3c, %r15
    347e:      	ja	0x39a0 <generic_lsm_process_event+0x37d0>
    3484:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    348e:      	btq	%r15, %rcx
    3492:      	jae	0x39a0 <generic_lsm_process_event+0x37d0>
    3498:      	movb	%r15b, 0x5(%rbp)
    349c:      	movzwl	%ax, %ecx
    349f:      	addq	%rbx, %rcx
    34a2:      	movl	$0x2, %edx
    34a7:      	movl	$0x4, %eax
    34ac:      	movq	0x20(%rsp), %rdi
    34b1:      	movzwl	(%rbp), %edx
    34b5:      	addq	%rbx, %rdx
    34b8:      	movl	$0x2, %esi
    34bd:      	callq	*%rax
    34bf:      	testq	%rax, %rax
    34c2:      	js	0x37c3 <generic_lsm_process_event+0x35f3>
    34c8:      	movzbl	0x5(%rbp), %eax
    34cc:      	cmpl	$0x32, %eax
    34cf:      	jg	0x34eb <generic_lsm_process_event+0x331b>
    34d1:      	testl	%eax, %eax
    34d3:      	je	0x3508 <generic_lsm_process_event+0x3338>
    34d5:      	cmpl	$0x2b, %eax
    34d8:      	je	0x3508 <generic_lsm_process_event+0x3338>
    34da:      	cmpl	$0x2c, %eax
    34dd:      	jne	0x352a <generic_lsm_process_event+0x335a>
    34df:      	movw	$0x8, 0x2(%rbp)
    34e5:      	movw	$0x8, %ax
    34e9:      	jmp	0x352e <generic_lsm_process_event+0x335e>
    34eb:      	cmpl	$0x33, %eax
    34ee:      	je	0x3519 <generic_lsm_process_event+0x3349>
    34f0:      	cmpl	$0x3c, %eax
    34f3:      	je	0x3508 <generic_lsm_process_event+0x3338>
    34f5:      	cmpl	$0xff, %eax
    34fa:      	jne	0x352a <generic_lsm_process_event+0x335a>
    34fc:      	movw	$0x28, 0x2(%rbp)
    3502:      	movw	$0x28, %ax
    3506:      	jmp	0x352e <generic_lsm_process_event+0x335e>
    3508:      	movzbl	0x7(%rbp), %eax
    350c:      	leal	0x8(,%rax,8), %eax
    3513:      	movw	%ax, 0x2(%rbp)
    3517:      	jmp	0x352e <generic_lsm_process_event+0x335e>
    3519:      	movzbl	0x7(%rbp), %eax
    351d:      	leal	0x8(,%rax,4), %eax
    3524:      	movw	%ax, 0x2(%rbp)
    3528:      	jmp	0x352e <generic_lsm_process_event+0x335e>
    352a:      	movzwl	0x2(%rbp), %eax
    352e:      	addw	(%rbp), %ax
    3532:      	movw	%ax, (%rbp)
    3536:      	movzbl	0x6(%rbp), %r15d
    353b:      	cmpq	$0x3c, %r15
    353f:      	ja	0x39a0 <generic_lsm_process_event+0x37d0>
    3545:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    354f:      	btq	%r15, %rcx
    3553:      	jae	0x39a0 <generic_lsm_process_event+0x37d0>
    3559:      	movb	%r15b, 0x5(%rbp)
    355d:      	movzwl	%ax, %ecx
    3560:      	addq	%rbx, %rcx
    3563:      	movl	$0x2, %edx
    3568:      	movl	$0x4, %eax
    356d:      	movq	0x20(%rsp), %rdi
    3572:      	movzwl	(%rbp), %edx
    3576:      	addq	%rbx, %rdx
    3579:      	movl	$0x2, %esi
    357e:      	callq	*%rax
    3580:      	testq	%rax, %rax
    3583:      	js	0x37c3 <generic_lsm_process_event+0x35f3>
    3589:      	movzbl	0x5(%rbp), %eax
    358d:      	cmpl	$0x32, %eax
    3590:      	jg	0x35ac <generic_lsm_process_event+0x33dc>
    3592:      	testl	%eax, %eax
    3594:      	je	0x35c9 <generic_lsm_process_event+0x33f9>
    3596:      	cmpl	$0x2b, %eax
    3599:      	je	0x35c9 <generic_lsm_process_event+0x33f9>
    359b:      	cmpl	$0x2c, %eax
    359e:      	jne	0x35eb <generic_lsm_process_event+0x341b>
    35a0:      	movw	$0x8, 0x2(%rbp)
    35a6:      	movw	$0x8, %ax
    35aa:      	jmp	0x35ef <generic_lsm_process_event+0x341f>
    35ac:      	cmpl	$0x33, %eax
    35af:      	je	0x35da <generic_lsm_process_event+0x340a>
    35b1:      	cmpl	$0x3c, %eax
    35b4:      	je	0x35c9 <generic_lsm_process_event+0x33f9>
    35b6:      	cmpl	$0xff, %eax
    35bb:      	jne	0x35eb <generic_lsm_process_event+0x341b>
    35bd:      	movw	$0x28, 0x2(%rbp)
    35c3:      	movw	$0x28, %ax
    35c7:      	jmp	0x35ef <generic_lsm_process_event+0x341f>
    35c9:      	movzbl	0x7(%rbp), %eax
    35cd:      	leal	0x8(,%rax,8), %eax
    35d4:      	movw	%ax, 0x2(%rbp)
    35d8:      	jmp	0x35ef <generic_lsm_process_event+0x341f>
    35da:      	movzbl	0x7(%rbp), %eax
    35de:      	leal	0x8(,%rax,4), %eax
    35e5:      	movw	%ax, 0x2(%rbp)
    35e9:      	jmp	0x35ef <generic_lsm_process_event+0x341f>
    35eb:      	movzwl	0x2(%rbp), %eax
    35ef:      	addw	(%rbp), %ax
    35f3:      	movw	%ax, (%rbp)
    35f7:      	movzbl	0x6(%rbp), %r15d
    35fc:      	cmpq	$0x3c, %r15
    3600:      	ja	0x39a0 <generic_lsm_process_event+0x37d0>
    3606:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3610:      	btq	%r15, %rcx
    3614:      	jae	0x39a0 <generic_lsm_process_event+0x37d0>
    361a:      	movb	%r15b, 0x5(%rbp)
    361e:      	movzwl	%ax, %ecx
    3621:      	addq	%rbx, %rcx
    3624:      	movl	$0x2, %edx
    3629:      	movl	$0x4, %eax
    362e:      	movq	0x20(%rsp), %rdi
    3633:      	movzwl	(%rbp), %edx
    3637:      	addq	%rbx, %rdx
    363a:      	movl	$0x2, %esi
    363f:      	callq	*%rax
    3641:      	testq	%rax, %rax
    3644:      	js	0x37c3 <generic_lsm_process_event+0x35f3>
    364a:      	movzbl	0x5(%rbp), %eax
    364e:      	cmpl	$0x32, %eax
    3651:      	jg	0x366d <generic_lsm_process_event+0x349d>
    3653:      	testl	%eax, %eax
    3655:      	je	0x368a <generic_lsm_process_event+0x34ba>
    3657:      	cmpl	$0x2b, %eax
    365a:      	je	0x368a <generic_lsm_process_event+0x34ba>
    365c:      	cmpl	$0x2c, %eax
    365f:      	jne	0x36ac <generic_lsm_process_event+0x34dc>
    3661:      	movw	$0x8, 0x2(%rbp)
    3667:      	movw	$0x8, %ax
    366b:      	jmp	0x36b0 <generic_lsm_process_event+0x34e0>
    366d:      	cmpl	$0x33, %eax
    3670:      	je	0x369b <generic_lsm_process_event+0x34cb>
    3672:      	cmpl	$0x3c, %eax
    3675:      	je	0x368a <generic_lsm_process_event+0x34ba>
    3677:      	cmpl	$0xff, %eax
    367c:      	jne	0x36ac <generic_lsm_process_event+0x34dc>
    367e:      	movw	$0x28, 0x2(%rbp)
    3684:      	movw	$0x28, %ax
    3688:      	jmp	0x36b0 <generic_lsm_process_event+0x34e0>
    368a:      	movzbl	0x7(%rbp), %eax
    368e:      	leal	0x8(,%rax,8), %eax
    3695:      	movw	%ax, 0x2(%rbp)
    3699:      	jmp	0x36b0 <generic_lsm_process_event+0x34e0>
    369b:      	movzbl	0x7(%rbp), %eax
    369f:      	leal	0x8(,%rax,4), %eax
    36a6:      	movw	%ax, 0x2(%rbp)
    36aa:      	jmp	0x36b0 <generic_lsm_process_event+0x34e0>
    36ac:      	movzwl	0x2(%rbp), %eax
    36b0:      	addw	(%rbp), %ax
    36b4:      	movw	%ax, (%rbp)
    36b8:      	movzbl	0x6(%rbp), %r15d
    36bd:      	cmpq	$0x3c, %r15
    36c1:      	ja	0x39a0 <generic_lsm_process_event+0x37d0>
    36c7:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    36d1:      	btq	%r15, %rcx
    36d5:      	jae	0x39a0 <generic_lsm_process_event+0x37d0>
    36db:      	movb	%r15b, 0x5(%rbp)
    36df:      	movzwl	%ax, %ecx
    36e2:      	addq	%rbx, %rcx
    36e5:      	movl	$0x2, %edx
    36ea:      	movl	$0x4, %eax
    36ef:      	movq	0x20(%rsp), %rdi
    36f4:      	movzwl	(%rbp), %edx
    36f8:      	addq	%rbx, %rdx
    36fb:      	movl	$0x2, %esi
    3700:      	callq	*%rax
    3702:      	testq	%rax, %rax
    3705:      	js	0x37c3 <generic_lsm_process_event+0x35f3>
    370b:      	movzbl	0x5(%rbp), %eax
    370f:      	cmpl	$0x32, %eax
    3712:      	jg	0x372e <generic_lsm_process_event+0x355e>
    3714:      	testl	%eax, %eax
    3716:      	je	0x374b <generic_lsm_process_event+0x357b>
    3718:      	cmpl	$0x2b, %eax
    371b:      	je	0x374b <generic_lsm_process_event+0x357b>
    371d:      	cmpl	$0x2c, %eax
    3720:      	jne	0x376d <generic_lsm_process_event+0x359d>
    3722:      	movw	$0x8, 0x2(%rbp)
    3728:      	movw	$0x8, %ax
    372c:      	jmp	0x3771 <generic_lsm_process_event+0x35a1>
    372e:      	cmpl	$0x33, %eax
    3731:      	je	0x375c <generic_lsm_process_event+0x358c>
    3733:      	cmpl	$0x3c, %eax
    3736:      	je	0x374b <generic_lsm_process_event+0x357b>
    3738:      	cmpl	$0xff, %eax
    373d:      	jne	0x376d <generic_lsm_process_event+0x359d>
    373f:      	movw	$0x28, 0x2(%rbp)
    3745:      	movw	$0x28, %ax
    3749:      	jmp	0x3771 <generic_lsm_process_event+0x35a1>
    374b:      	movzbl	0x7(%rbp), %eax
    374f:      	leal	0x8(,%rax,8), %eax
    3756:      	movw	%ax, 0x2(%rbp)
    375a:      	jmp	0x3771 <generic_lsm_process_event+0x35a1>
    375c:      	movzbl	0x7(%rbp), %eax
    3760:      	leal	0x8(,%rax,4), %eax
    3767:      	movw	%ax, 0x2(%rbp)
    376b:      	jmp	0x3771 <generic_lsm_process_event+0x35a1>
    376d:      	movzwl	0x2(%rbp), %eax
    3771:      	addw	(%rbp), %ax
    3775:      	movw	%ax, (%rbp)
    3779:      	movzbl	0x6(%rbp), %r15d
    377e:      	cmpq	$0x3c, %r15
    3782:      	ja	0x39a0 <generic_lsm_process_event+0x37d0>
    3788:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3792:      	btq	%r15, %rcx
    3796:      	jae	0x39a0 <generic_lsm_process_event+0x37d0>
    379c:      	movb	%r15b, 0x5(%rbp)
    37a0:      	movzwl	%ax, %ecx
    37a3:      	addq	%rbx, %rcx
    37a6:      	movl	$0x2, %edx
    37ab:      	movl	$0x4, %eax
    37b0:      	movq	0x20(%rsp), %rdi
    37b5:      	movzwl	(%rbp), %edx
    37b9:      	addq	%rbx, %rdx
    37bc:      	movl	$0x2, %esi
    37c1:      	callq	*%rax
    37c3:      	xorl	%r15d, %r15d
    37c6:      	movb	%r15b, 0xb8(%rsp)
    37ce:      	movzbl	%r15b, %eax
    37d2:      	movq	0x10(%rsp), %rbx
    37d7:      	movw	%ax, 0x24(%rbx)
    37db:      	movw	$0xa, 0x26(%rbx)
    37e1:      	leaq	0x8(%r13), %rdx
    37e5:      	movl	$0x10, %ecx
    37ea:      	movl	$0x4, %eax
    37ef:      	movq	%rbx, %rdi
    37f2:      	movl	$0x10, %esi
    37f7:      	callq	*%rax
    37f9:      	leaq	0x10(%rbx), %rdi
    37fd:      	addq	$0x18, %r13
    3801:      	movl	$0x10, %ecx
    3806:      	movl	$0x4, %eax
    380b:      	movl	$0x10, %esi
    3810:      	movq	%r13, %rdx
    3813:      	callq	*%rax
    3815:      	cmpb	$0x11, %r15b
    3819:      	je	0x386c <generic_lsm_process_event+0x369c>
    381b:      	movzbl	%r15b, %eax
    381f:      	cmpl	$0x6, %eax
    3822:      	jne	0x38b7 <generic_lsm_process_event+0x36e7>
    3828:      	movq	0x60(%rsp), %rbx
    382d:      	movzwl	0xd0(%rsp), %r15d
    3836:      	leaq	(%rbx,%r15), %rdx
    383a:      	movq	0x10(%rsp), %rbp
    383f:      	leaq	0x20(%rbp), %rdi
    3843:      	movl	$0x2, %ecx
    3848:      	movl	$0x4, %eax
    384d:      	movl	$0x2, %esi
    3852:      	callq	*%rax
    3854:      	leaq	0x22(%rbp), %rdi
    3858:      	leaq	(%rbx,%r15), %rdx
    385c:      	addq	$0x2, %rdx
    3860:      	movl	$0x2, %ecx
    3865:      	movl	$0x4, %eax
    386a:      	jmp	0x38ae <generic_lsm_process_event+0x36de>
    386c:      	movq	0x60(%rsp), %rbx
    3871:      	movzwl	0xd0(%rsp), %r15d
    387a:      	leaq	(%rbx,%r15), %rdx
    387e:      	movq	0x10(%rsp), %rbp
    3883:      	leaq	0x20(%rbp), %rdi
    3887:      	movl	$0x2, %ecx
    388c:      	movl	$0x4, %eax
    3891:      	movl	$0x2, %esi
    3896:      	callq	*%rax
    3898:      	leaq	0x22(%rbp), %rdi
    389c:      	leaq	(%rbx,%r15), %rdx
    38a0:      	addq	$0x2, %rdx
    38a4:      	movl	$0x2, %ecx
    38a9:      	movl	$0x4, %eax
    38ae:      	movl	$0x2, %esi
    38b3:      	callq	*%rax
    38b5:      	jmp	0x38c3 <generic_lsm_process_event+0x36f3>
    38b7:      	movq	0x10(%rsp), %rax
    38bc:      	movl	$0x0, 0x20(%rax)
    38c3:      	movq	0x10(%rsp), %rdx
    38c8:      	movzwl	0x20(%rdx), %eax
    38cc:      	movzwl	0x22(%rdx), %ecx
    38d0:      	movbew	%ax, 0x20(%rdx)
    38d6:      	movbew	%cx, 0x22(%rdx)
    38dc:      	addq	$0xe0, %r12
    38e3:      	leaq	0xa0(%rsp), %rdi
    38eb:      	movl	$0x8, %ecx
    38f0:      	movl	$0x4, %eax
    38f5:      	movl	$0x4, %r15d
    38fb:      	movl	$0x8, %esi
    3900:      	movq	%r12, %rdx
    3903:      	callq	*%rax
    3905:      	movq	0xa0(%rsp), %rcx
    390d:      	testq	%rcx, %rcx
    3910:      	je	0x397d <generic_lsm_process_event+0x37ad>
    3912:      	addq	$0x5, %rcx
    3916:      	leaq	0x38(%rsp), %rdi
    391b:      	movl	$0x8, %edx
    3920:      	movl	$0x4, %eax
    3925:      	movq	0xa0(%rsp), %rdx
    392d:      	addq	$0x5, %rdx
    3931:      	movl	$0x8, %esi
    3936:      	callq	*%rax
    3938:      	movq	0xa0(%rsp), %rbx
    3940:      	movq	0x38(%rsp), %r12
    3945:      	movq	0x10(%rsp), %r13
    394a:      	leaq	0x38(%r13), %rdi
    394e:      	leaq	(%rbx,%r12,8), %rdx
    3952:      	addq	$0x44, %rdx
    3956:      	movl	$0x4, %eax
    395b:      	movl	$0x4, %esi
    3960:      	callq	*%rax
    3962:      	addq	$0x3c, %r13
    3966:      	leaq	(%rbx,%r12,8), %rdx
    396a:      	addq	$0x45, %rdx
    396e:      	movl	$0x4, %eax
    3973:      	movq	%r13, %rdi
    3976:      	movl	$0x4, %esi
    397b:      	callq	*%rax
    397d:      	movl	$0x40, %r15d
    3983:      	movq	0x8(%rsp), %rcx
    3988:      	movq	0x58(%rsp), %rbx
    398d:      	movq	0x18(%rsp), %rbp
    3992:      	movq	(%rsp), %rsi
    3996:      	movq	0x30(%rsp), %r14
    399b:      	jmp	0x27e6 <generic_lsm_process_event+0x2616>
    39a0:      	movw	%ax, 0xd0(%rsp)
    39a8:      	jmp	0x37c6 <generic_lsm_process_event+0x35f6>
    39ad:      	nopl	(%rax)

00000000000039b0 <generic_lsm_process_filter>:
    39b0:      	pushq	%rbp
    39b1:      	pushq	%r15
    39b3:      	pushq	%r14
    39b5:      	pushq	%r13
    39b7:      	pushq	%r12
    39b9:      	pushq	%rbx
    39ba:      	subq	$0xe8, %rsp
    39c1:      	movq	%rdi, %rbx
    39c4:      	movl	$0x0, 0xc8(%rsp)
    39cf:      	movq	(%rip), %rdi            # 0x39d6 <generic_lsm_process_filter+0x26>
    39d6:      	leaq	0xc8(%rsp), %rsi
    39de:      	movl	$0x1, %eax
    39e3:      	callq	*%rax
    39e5:      	testq	%rax, %rax
    39e8:      	je	0x5fd3 <generic_lsm_process_filter+0x2623>
    39ee:      	movq	%rax, %r14
    39f1:      	movl	$0x23, %eax
    39f6:      	callq	*%rax
    39f8:      	movq	%rax, %rcx
    39fb:      	movq	%rax, 0x60(%rsp)
    3a00:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    3a07:      	leaq	0x10(%rsp), %rdi
    3a0c:      	movl	$0x4, %edx
    3a11:      	movl	$0x71, %eax
    3a16:      	movl	$0xaf4, %edx            # imm = 0xAF4
    3a1b:      	addq	0x60(%rsp), %rdx
    3a20:      	movl	$0x4, %esi
    3a25:      	callq	*%rax
    3a27:      	movl	0x10(%rsp), %eax
    3a2b:      	movl	%eax, 0x40(%rsp)
    3a2f:      	movq	(%rip), %rdi            # 0x3a36 <generic_lsm_process_filter+0x86>
    3a36:      	leaq	0x40(%rsp), %rsi
    3a3b:      	movl	$0x1, %eax
    3a40:      	callq	*%rax
    3a42:      	testq	%rax, %rax
    3a45:      	movq	%r14, 0x50(%rsp)
    3a4a:      	je	0x3a5a <generic_lsm_process_filter+0xaa>
    3a4c:      	movq	%rax, %r15
    3a4f:      	cmpq	$0x0, 0x8(%rax)
    3a54:      	jne	0x49df <generic_lsm_process_filter+0x102f>
    3a5a:      	movl	$0xb00, %edx            # imm = 0xB00
    3a5f:      	movq	0x60(%rsp), %rcx
    3a64:      	addq	%rdx, %rcx
    3a67:      	leaq	0x60(%rsp), %rdi
    3a6c:      	movl	$0x8, %esi
    3a71:      	movl	$0x71, %eax
    3a76:      	addq	0x60(%rsp), %rdx
    3a7b:      	movl	$0x8, %esi
    3a80:      	callq	*%rax
    3a82:      	movq	0x60(%rsp), %rcx
    3a87:      	testq	%rcx, %rcx
    3a8a:      	je	0x3c1f <generic_lsm_process_filter+0x26f>
    3a90:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    3a97:      	leaq	0x10(%rsp), %rdi
    3a9c:      	movl	$0x4, %edx
    3aa1:      	movl	$0x71, %eax
    3aa6:      	movl	$0xaf4, %edx            # imm = 0xAF4
    3aab:      	addq	0x60(%rsp), %rdx
    3ab0:      	movl	$0x4, %esi
    3ab5:      	callq	*%rax
    3ab7:      	movl	0x10(%rsp), %eax
    3abb:      	movl	%eax, 0x40(%rsp)
    3abf:      	movq	(%rip), %rdi            # 0x3ac6 <generic_lsm_process_filter+0x116>
    3ac6:      	leaq	0x40(%rsp), %rsi
    3acb:      	movl	$0x1, %eax
    3ad0:      	callq	*%rax
    3ad2:      	testq	%rax, %rax
    3ad5:      	je	0x3ae5 <generic_lsm_process_filter+0x135>
    3ad7:      	movq	%rax, %r15
    3ada:      	cmpq	$0x0, 0x8(%rax)
    3adf:      	jne	0x49df <generic_lsm_process_filter+0x102f>
    3ae5:      	movl	$0xb00, %edx            # imm = 0xB00
    3aea:      	movq	0x60(%rsp), %rcx
    3aef:      	addq	%rdx, %rcx
    3af2:      	leaq	0x60(%rsp), %rdi
    3af7:      	movl	$0x8, %esi
    3afc:      	movl	$0x71, %eax
    3b01:      	addq	0x60(%rsp), %rdx
    3b06:      	movl	$0x8, %esi
    3b0b:      	callq	*%rax
    3b0d:      	movq	0x60(%rsp), %rcx
    3b12:      	testq	%rcx, %rcx
    3b15:      	je	0x3c1f <generic_lsm_process_filter+0x26f>
    3b1b:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    3b22:      	leaq	0x10(%rsp), %rdi
    3b27:      	movl	$0x4, %edx
    3b2c:      	movl	$0x71, %eax
    3b31:      	movl	$0xaf4, %edx            # imm = 0xAF4
    3b36:      	addq	0x60(%rsp), %rdx
    3b3b:      	movl	$0x4, %esi
    3b40:      	callq	*%rax
    3b42:      	movl	0x10(%rsp), %eax
    3b46:      	movl	%eax, 0x40(%rsp)
    3b4a:      	movq	(%rip), %rdi            # 0x3b51 <generic_lsm_process_filter+0x1a1>
    3b51:      	leaq	0x40(%rsp), %rsi
    3b56:      	movl	$0x1, %eax
    3b5b:      	callq	*%rax
    3b5d:      	testq	%rax, %rax
    3b60:      	je	0x3b70 <generic_lsm_process_filter+0x1c0>
    3b62:      	movq	%rax, %r15
    3b65:      	cmpq	$0x0, 0x8(%rax)
    3b6a:      	jne	0x49df <generic_lsm_process_filter+0x102f>
    3b70:      	movl	$0xb00, %edx            # imm = 0xB00
    3b75:      	movq	0x60(%rsp), %rcx
    3b7a:      	addq	%rdx, %rcx
    3b7d:      	leaq	0x60(%rsp), %rdi
    3b82:      	movl	$0x8, %esi
    3b87:      	movl	$0x71, %eax
    3b8c:      	addq	0x60(%rsp), %rdx
    3b91:      	movl	$0x8, %esi
    3b96:      	callq	*%rax
    3b98:      	movq	0x60(%rsp), %rcx
    3b9d:      	testq	%rcx, %rcx
    3ba0:      	je	0x3c1f <generic_lsm_process_filter+0x26f>
    3ba2:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    3ba9:      	leaq	0x10(%rsp), %rdi
    3bae:      	movl	$0x4, %edx
    3bb3:      	movl	$0x71, %eax
    3bb8:      	movl	$0xaf4, %edx            # imm = 0xAF4
    3bbd:      	addq	0x60(%rsp), %rdx
    3bc2:      	movl	$0x4, %esi
    3bc7:      	callq	*%rax
    3bc9:      	movl	0x10(%rsp), %eax
    3bcd:      	movl	%eax, 0x40(%rsp)
    3bd1:      	movq	(%rip), %rdi            # 0x3bd8 <generic_lsm_process_filter+0x228>
    3bd8:      	leaq	0x40(%rsp), %rsi
    3bdd:      	movl	$0x1, %eax
    3be2:      	callq	*%rax
    3be4:      	testq	%rax, %rax
    3be7:      	je	0x3bf7 <generic_lsm_process_filter+0x247>
    3be9:      	movq	%rax, %r15
    3bec:      	cmpq	$0x0, 0x8(%rax)
    3bf1:      	jne	0x49df <generic_lsm_process_filter+0x102f>
    3bf7:      	movl	$0xb00, %edx            # imm = 0xB00
    3bfc:      	movq	0x60(%rsp), %rcx
    3c01:      	addq	%rdx, %rcx
    3c04:      	leaq	0x60(%rsp), %rdi
    3c09:      	movl	$0x8, %esi
    3c0e:      	movl	$0x71, %eax
    3c13:      	addq	0x60(%rsp), %rdx
    3c18:      	movl	$0x8, %esi
    3c1d:      	callq	*%rax
    3c1f:      	movq	%rbx, 0xb8(%rsp)
    3c27:      	movl	$0x23, %eax
    3c2c:      	callq	*%rax
    3c2e:      	movq	%rax, %r13
    3c31:      	leaq	0xaf4(%rax), %rdx
    3c38:      	leaq	0x60(%rsp), %rdi
    3c3d:      	movl	$0x4, %ecx
    3c42:      	movl	$0x4, %eax
    3c47:      	movl	$0x4, %ebp
    3c4c:      	movl	$0x4, %esi
    3c51:      	callq	*%rax
    3c53:      	movl	0x60(%rsp), %eax
    3c57:      	movl	%eax, 0x5f10(%r14)
    3c5e:      	movl	$0x7d, %eax
    3c63:      	callq	*%rax
    3c65:      	movq	%rax, 0x5f18(%r14)
    3c6c:      	movl	$0x0, 0x5f20(%r14)
    3c77:      	movq	$0x0, 0x5f28(%r14)
    3c82:      	movl	$0x0, 0x5f30(%r14)
    3c8d:      	leaq	0x60(%r13), %rdx
    3c91:      	leaq	0x40(%rsp), %rdi
    3c96:      	movl	$0x8, %ecx
    3c9b:      	movl	$0x71, %eax
    3ca0:      	movl	$0x8, %esi
    3ca5:      	callq	*%rax
    3ca7:      	movq	0x40(%rsp), %rcx
    3cac:      	xorl	%ebx, %ebx
    3cae:      	testq	%rcx, %rcx
    3cb1:      	je	0x3d20 <generic_lsm_process_filter+0x370>
    3cb3:      	addq	$0x4, %rcx
    3cb7:      	leaq	0x10(%rsp), %rdi
    3cbc:      	movl	$0x4, %edx
    3cc1:      	movl	$0x71, %eax
    3cc6:      	movq	0x40(%rsp), %rdx
    3ccb:      	addq	$0x4, %rdx
    3ccf:      	movl	$0x4, %esi
    3cd4:      	callq	*%rax
    3cd6:      	movl	0x10(%rsp), %eax
    3cda:      	testl	%eax, %eax
    3cdc:      	je	0x3d20 <generic_lsm_process_filter+0x370>
    3cde:      	movq	0x40(%rsp), %rcx
    3ce3:      	shll	$0x4, %eax
    3ce6:      	addq	%rax, %rcx
    3ce9:      	addq	$0x80, %rcx
    3cf0:      	leaq	0x60(%rsp), %rdi
    3cf5:      	movl	$0x10, %edx
    3cfa:      	movl	$0x71, %eax
    3cff:      	movq	0x40(%rsp), %rcx
    3d04:      	movl	0x10(%rsp), %edx
    3d08:      	shll	$0x4, %edx
    3d0b:      	addq	%rcx, %rdx
    3d0e:      	addq	$0x80, %rdx
    3d15:      	movl	$0x10, %esi
    3d1a:      	callq	*%rax
    3d1c:      	movl	0x60(%rsp), %ebx
    3d20:      	movl	%ebx, 0x5f34(%r14)
    3d27:      	leaq	0xd00(%r13), %r15
    3d2e:      	leaq	0x60(%rsp), %rdi
    3d33:      	movl	$0x8, %ecx
    3d38:      	movl	$0x4, %eax
    3d3d:      	leaq	0x5f60(%r14), %rbx
    3d44:      	movl	$0x8, %esi
    3d49:      	movq	%r15, %rdx
    3d4c:      	callq	*%rax
    3d4e:      	movq	0x60(%rsp), %r12
    3d53:      	leaq	0x5f68(%r14), %rdi
    3d5a:      	leaq	0x40(%r12), %rdx
    3d5f:      	movl	$0x8, %ecx
    3d64:      	movl	$0x4, %eax
    3d69:      	movl	$0x8, %esi
    3d6e:      	callq	*%rax
    3d70:      	leaq	0x5f70(%r14), %rdi
    3d77:      	leaq	0x30(%r12), %rdx
    3d7c:      	movl	$0x8, %ecx
    3d81:      	movl	$0x4, %eax
    3d86:      	movl	$0x8, %esi
    3d8b:      	callq	*%rax
    3d8d:      	addq	$0x38, %r12
    3d91:      	movl	$0x8, %ecx
    3d96:      	movl	$0x4, %eax
    3d9b:      	movq	%rbx, %rdi
    3d9e:      	movl	$0x8, %esi
    3da3:      	movq	%r12, %rdx
    3da6:      	callq	*%rax
    3da8:      	leaq	0x5f38(%r14), %rbx
    3daf:      	leaq	0xd70(%r13), %rdx
    3db6:      	leaq	0x10(%rsp), %rdi
    3dbb:      	movl	$0x8, %ecx
    3dc0:      	movl	$0x4, %eax
    3dc5:      	movl	$0x8, %esi
    3dca:      	callq	*%rax
    3dcc:      	movq	0x10(%rsp), %rcx
    3dd1:      	leaq	0x60(%rsp), %rdi
    3dd6:      	movl	$0x48, %edx
    3ddb:      	movl	$0x4, %eax
    3de0:      	movq	0x10(%rsp), %rdx
    3de5:      	movl	$0x48, %esi
    3dea:      	callq	*%rax
    3dec:      	movl	$0x218, %edx            # imm = 0x218
    3df1:      	movq	0x68(%rsp), %rcx
    3df6:      	addq	%rdx, %rcx
    3df9:      	movl	$0x4, %eax
    3dfe:      	addq	0x68(%rsp), %rdx
    3e03:      	movq	%rbx, %rdi
    3e06:      	movl	$0x4, %esi
    3e0b:      	callq	*%rax
    3e0d:      	leaq	0x5f3c(%r14), %rdi
    3e14:      	movl	$0x4d8, %edx            # imm = 0x4D8
    3e19:      	movq	0x70(%rsp), %rcx
    3e1e:      	addq	%rdx, %rcx
    3e21:      	movl	$0x4, %eax
    3e26:      	addq	0x70(%rsp), %rdx
    3e2b:      	movl	$0x4, %esi
    3e30:      	callq	*%rax
    3e32:      	leaq	0x5f40(%r14), %rdi
    3e39:      	movq	0x78(%rsp), %rcx
    3e3e:      	addq	$0x58, %rcx
    3e42:      	movl	$0x4, %eax
    3e47:      	movq	0x78(%rsp), %rdx
    3e4c:      	addq	$0x58, %rdx
    3e50:      	movl	$0x4, %esi
    3e55:      	callq	*%rax
    3e57:      	movq	$0x0, 0x58(%rsp)
    3e60:      	leaq	0xb58(%r13), %rdx
    3e67:      	leaq	0x58(%rsp), %rdi
    3e6c:      	movl	$0x8, %ecx
    3e71:      	movl	$0x4, %eax
    3e76:      	movl	$0x8, %esi
    3e7b:      	callq	*%rax
    3e7d:      	movq	0x58(%rsp), %rcx
    3e82:      	testq	%rcx, %rcx
    3e85:      	je	0x3f34 <generic_lsm_process_filter+0x584>
    3e8b:      	movl	$0x0, 0xa8(%rsp)
    3e96:      	addq	$0x4, %rcx
    3e9a:      	leaq	0xa8(%rsp), %rdi
    3ea2:      	movl	$0x4, %edx
    3ea7:      	movl	$0x4, %eax
    3eac:      	movq	0x58(%rsp), %rdx
    3eb1:      	addq	$0x4, %rdx
    3eb5:      	movl	$0x4, %esi
    3eba:      	callq	*%rax
    3ebc:      	movq	0x58(%rsp), %rax
    3ec1:      	movslq	0xa8(%rsp), %rcx
    3ec9:      	shlq	$0x4, %rcx
    3ecd:      	addq	%rax, %rcx
    3ed0:      	addq	$0x80, %rcx
    3ed7:      	leaq	0x40(%rsp), %rdi
    3edc:      	movl	$0x10, %edx
    3ee1:      	movl	$0x4, %eax
    3ee6:      	movq	0x58(%rsp), %rcx
    3eeb:      	movslq	0xa8(%rsp), %rdx
    3ef3:      	shlq	$0x4, %rdx
    3ef7:      	addq	%rcx, %rdx
    3efa:      	addq	$0x80, %rdx
    3f01:      	movl	$0x10, %esi
    3f06:      	callq	*%rax
    3f08:      	leaq	0x5f44(%r14), %rdi
    3f0f:      	movl	$0x158, %edx            # imm = 0x158
    3f14:      	movq	0x48(%rsp), %rcx
    3f19:      	addq	%rdx, %rcx
    3f1c:      	movl	$0x4, %esi
    3f21:      	movl	$0x4, %eax
    3f26:      	addq	0x48(%rsp), %rdx
    3f2b:      	movl	$0x4, %esi
    3f30:      	callq	*%rax
    3f32:      	jmp	0x3f3f <generic_lsm_process_filter+0x58f>
    3f34:      	movl	$0x0, 0x5f44(%r14)
    3f3f:      	leaq	0x5f48(%r14), %rdi
    3f46:      	movl	$0x158, %ebx            # imm = 0x158
    3f4b:      	movq	0x80(%rsp), %rcx
    3f53:      	addq	%rbx, %rcx
    3f56:      	movl	$0x4, %edx
    3f5b:      	movl	$0x4, %eax
    3f60:      	movq	0x80(%rsp), %rdx
    3f68:      	addq	%rbx, %rdx
    3f6b:      	movl	$0x4, %esi
    3f70:      	callq	*%rax
    3f72:      	leaq	0x5f4c(%r14), %rdi
    3f79:      	movl	$0x118, %edx            # imm = 0x118
    3f7e:      	movq	0x88(%rsp), %rcx
    3f86:      	addq	%rdx, %rcx
    3f89:      	movl	$0x4, %esi
    3f8e:      	movl	$0x4, %eax
    3f93:      	addq	0x88(%rsp), %rdx
    3f9b:      	movl	$0x4, %esi
    3fa0:      	callq	*%rax
    3fa2:      	leaq	0x5f50(%r14), %rdi
    3fa9:      	movl	$0x98, %r12d
    3faf:      	movq	0x90(%rsp), %rcx
    3fb7:      	addq	%r12, %rcx
    3fba:      	movl	$0x4, %edx
    3fbf:      	movl	$0x4, %eax
    3fc4:      	movq	0x90(%rsp), %rdx
    3fcc:      	addq	%r12, %rdx
    3fcf:      	movl	$0x4, %esi
    3fd4:      	callq	*%rax
    3fd6:      	leaq	0x5f54(%r14), %rdi
    3fdd:      	movq	0x98(%rsp), %rcx
    3fe5:      	addq	%r12, %rcx
    3fe8:      	movl	$0x4, %edx
    3fed:      	movl	$0x4, %eax
    3ff2:      	addq	0x98(%rsp), %r12
    3ffa:      	movl	$0x4, %esi
    3fff:      	movq	%r12, %rdx
    4002:      	callq	*%rax
    4004:      	leaq	0x5f58(%r14), %rdi
    400b:      	movq	0xa0(%rsp), %rcx
    4013:      	addq	$0x58, %rcx
    4017:      	movl	$0x4, %edx
    401c:      	movl	$0x4, %eax
    4021:      	movq	0xa0(%rsp), %rdx
    4029:      	addq	$0x58, %rdx
    402d:      	movl	$0x4, %esi
    4032:      	callq	*%rax
    4034:      	movq	$0x0, 0x40(%rsp)
    403d:      	movq	$0x0, 0x58(%rsp)
    4046:      	leaq	0x40(%rsp), %rdi
    404b:      	movl	$0x8, %ecx
    4050:      	movl	$0x4, %eax
    4055:      	movl	$0x8, %esi
    405a:      	movq	%r15, %rdx
    405d:      	callq	*%rax
    405f:      	movl	$0x90, %edx
    4064:      	movq	0x40(%rsp), %rcx
    4069:      	addq	%rdx, %rcx
    406c:      	leaq	0x58(%rsp), %rdi
    4071:      	movl	$0x8, %esi
    4076:      	movl	$0x4, %eax
    407b:      	addq	0x40(%rsp), %rdx
    4080:      	movl	$0x8, %esi
    4085:      	callq	*%rax
    4087:      	leaq	0x5f5c(%r14), %rdi
    408e:      	movq	0x58(%rsp), %rcx
    4093:      	addq	%rbx, %rcx
    4096:      	movl	$0x4, %edx
    409b:      	movl	$0x4, %eax
    40a0:      	addq	0x58(%rsp), %rbx
    40a5:      	movl	$0x4, %esi
    40aa:      	movq	%rbx, %rdx
    40ad:      	callq	*%rax
    40af:      	cmpl	$0x1, 0x5f34(%r14)
    40b7:      	jne	0x40c1 <generic_lsm_process_filter+0x711>
    40b9:      	orb	$0x2, 0x5f33(%r14)
    40c1:      	leaq	0x5f78(%r14), %rdi
    40c8:      	movl	$0x308, %edx            # imm = 0x308
    40cd:      	movq	%rdi, 0x8(%rsp)
    40d2:      	xorl	%esi, %esi
    40d4:      	callq	0x40d9 <generic_lsm_process_filter+0x729>
    40d9:      	leaq	0x6290(%r14), %rbp
    40e0:      	addq	$0xa78, %r13            # imm = 0xA78
    40e7:      	leaq	0x40(%rsp), %rdi
    40ec:      	movl	$0x8, %ecx
    40f1:      	movl	$0x4, %eax
    40f6:      	movl	$0x8, %esi
    40fb:      	movq	%r13, %rdx
    40fe:      	callq	*%rax
    4100:      	movl	$0x5f8, %edx            # imm = 0x5F8
    4105:      	movq	0x40(%rsp), %rcx
    410a:      	addq	%rdx, %rcx
    410d:      	leaq	0x60(%rsp), %rdi
    4112:      	movl	$0x8, %esi
    4117:      	movl	$0x4, %eax
    411c:      	addq	0x40(%rsp), %rdx
    4121:      	movl	$0x8, %esi
    4126:      	callq	*%rax
    4128:      	movq	0x60(%rsp), %rbx
    412d:      	movl	$0x0, 0xcc(%rsp)
    4138:      	movq	(%rip), %rdi            # 0x413f <generic_lsm_process_filter+0x78f>
    413f:      	leaq	0xcc(%rsp), %rsi
    4147:      	movl	$0x1, %eax
    414c:      	callq	*%rax
    414e:      	testq	%rax, %rax
    4151:      	je	0x4857 <generic_lsm_process_filter+0xea7>
    4157:      	movq	%rax, %r12
    415a:      	movq	%rbp, 0x38(%rsp)
    415f:      	movl	$0x1000, 0x6410(%r14)   # imm = 0x1000
    416a:      	leaq	0x1000(%rax), %r13
    4171:      	movl	$0x23, %eax
    4176:      	callq	*%rax
    4178:      	leaq	0xd50(%rax), %rdx
    417f:      	leaq	0xd8(%rsp), %rdi
    4187:      	movl	$0x8, %ecx
    418c:      	movl	$0x4, %eax
    4191:      	movl	$0x8, %esi
    4196:      	callq	*%rax
    4198:      	movq	0xd8(%rsp), %rbp
    41a0:      	leaq	0x48(%rbx), %r15
    41a4:      	leaq	0xe0(%rsp), %rdi
    41ac:      	movl	$0x8, %ecx
    41b1:      	movl	$0x4, %eax
    41b6:      	movl	$0x8, %esi
    41bb:      	movq	%r15, %rdx
    41be:      	callq	*%rax
    41c0:      	movq	0xe0(%rsp), %r14
    41c8:      	leaq	0x10(%r14), %rdx
    41cc:      	leaq	0x60(%rsp), %rdi
    41d1:      	movl	$0x8, %ecx
    41d6:      	movl	$0x4, %eax
    41db:      	movl	$0x8, %esi
    41e0:      	callq	*%rax
    41e2:      	cmpq	$0x0, 0x60(%rsp)
    41e8:      	je	0x44b6 <generic_lsm_process_filter+0xb06>
    41ee:      	movq	0x50(%rsp), %r14
    41f3:      	movq	$0x0, 0x68(%rsp)
    41fc:      	movq	$0x0, 0x60(%rsp)
    4205:      	movq	%r12, 0x70(%rsp)
    420a:      	movq	$0x0, 0x78(%rsp)
    4213:      	movq	$0x0, 0x80(%rsp)
    421f:      	movq	$0x0, 0x88(%rsp)
    422b:      	movq	%r13, 0xc0(%rsp)
    4233:      	movq	%r13, 0x90(%rsp)
    423b:      	movl	0x6410(%r14), %eax
    4242:      	movl	%eax, 0x98(%rsp)
    4249:      	leaq	0x18(%rbp), %r13
    424d:      	movb	$0x0, 0x9c(%rsp)
    4255:      	addq	$0x20, %rbp
    4259:      	leaq	0x60(%rsp), %rdi
    425e:      	movl	$0x8, %ecx
    4263:      	movl	$0x4, %eax
    4268:      	addq	$0x40, %rbx
    426c:      	leaq	0x68(%rsp), %r12
    4271:      	leaq	0x78(%rsp), %r14
    4276:      	movl	$0x8, %esi
    427b:      	movq	%rbp, %rdx
    427e:      	callq	*%rax
    4280:      	movl	$0x8, %ecx
    4285:      	movl	$0x4, %eax
    428a:      	movq	%r12, %rdi
    428d:      	movl	$0x8, %esi
    4292:      	movq	%r13, %rdx
    4295:      	callq	*%rax
    4297:      	movl	$0x8, %ecx
    429c:      	movl	$0x4, %eax
    42a1:      	movq	%r14, %rdi
    42a4:      	movl	$0x8, %esi
    42a9:      	movq	%r15, %rdx
    42ac:      	callq	*%rax
    42ae:      	movl	$0x8, %ecx
    42b3:      	movl	$0x4, %eax
    42b8:      	leaq	0x80(%rsp), %rdi
    42c0:      	movl	$0x8, %esi
    42c5:      	movq	%rbx, %rdx
    42c8:      	callq	*%rax
    42ca:      	movq	0x80(%rsp), %rax
    42d2:      	addq	$-0x20, %rax
    42d6:      	movq	%rax, 0x88(%rsp)
    42de:      	movq	(%rip), %rax            # 0x42e5 <generic_lsm_process_filter+0x935>
    42e5:      	cmpb	$0x0, (%rax)
    42e8:      	je	0x450d <generic_lsm_process_filter+0xb5d>
    42ee:      	movl	$0x800, %r14d           # imm = 0x800
    42f4:      	movl	$0x8, %ebp
    42f9:      	leaq	0x10(%rsp), %rbx
    42fe:      	nop
    4300:      	movq	0x78(%rsp), %r15
    4305:      	movq	0x80(%rsp), %rdx
    430d:      	movq	0x88(%rsp), %r12
    4315:      	cmpq	0x60(%rsp), %r15
    431a:      	jne	0x4327 <generic_lsm_process_filter+0x977>
    431c:      	cmpq	0x68(%rsp), %rdx
    4321:      	je	0x46cf <generic_lsm_process_filter+0xd1f>
    4327:      	movl	$0x4, %eax
    432c:      	leaq	0xa8(%rsp), %rdi
    4334:      	movl	$0x8, %esi
    4339:      	callq	*%rax
    433b:      	cmpq	0xa8(%rsp), %r15
    4343:      	je	0x4450 <generic_lsm_process_filter+0xaa0>
    4349:      	leaq	0x18(%r15), %r13
    434d:      	movl	$0x4, %eax
    4352:      	movq	%rbx, %rdi
    4355:      	movl	$0x8, %esi
    435a:      	movq	%r13, %rdx
    435d:      	callq	*%rax
    435f:      	cmpq	%r15, 0x10(%rsp)
    4364:      	je	0x4450 <generic_lsm_process_filter+0xaa0>
    436a:      	movl	$0x4, %eax
    436f:      	leaq	0x58(%rsp), %rdi
    4374:      	movl	$0x8, %esi
    4379:      	movq	%r13, %rdx
    437c:      	callq	*%rax
    437e:      	addq	$0x20, %r15
    4382:      	movl	$0x4, %eax
    4387:      	leaq	0x40(%rsp), %rdi
    438c:      	movl	$0x10, %ecx
    4391:      	movl	$0x10, %esi
    4396:      	movq	%r15, %rdx
    4399:      	callq	*%rax
    439b:      	movq	0x70(%rsp), %r15
    43a0:      	movq	0x90(%rsp), %rax
    43a8:      	movl	0x44(%rsp), %r12d
    43ad:      	subq	%r15, %rax
    43b0:      	movl	0x98(%rsp), %r13d
    43b8:      	movl	%r12d, %edx
    43bb:      	subl	%r13d, %edx
    43be:      	movl	$0x0, %ecx
    43c3:      	cmovbl	%ecx, %edx
    43c6:      	addq	0x48(%rsp), %rdx
    43cb:      	xorl	%esi, %esi
    43cd:      	cmpl	%r12d, %r13d
    43d0:      	seta	%sil
    43d4:      	movl	%r12d, %ecx
    43d7:      	cmovbl	%r13d, %ecx
    43db:      	addl	%ecx, %esi
    43dd:      	movl	%r13d, %edi
    43e0:      	subl	%esi, %edi
    43e2:      	movl	%edi, 0x98(%rsp)
    43e9:      	subq	%rsi, %rax
    43ec:      	jb	0x46d7 <generic_lsm_process_filter+0xd27>
    43f2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    43f8:      	ja	0x46d7 <generic_lsm_process_filter+0xd27>
    43fe:      	cmpl	%r12d, %r13d
    4401:      	jbe	0x4408 <generic_lsm_process_filter+0xa58>
    4403:      	movb	$0x2f, (%r15,%rax)
    4408:      	xorl	%edi, %edi
    440a:      	cmpl	%r12d, %r13d
    440d:      	seta	%dil
    4411:      	movzbl	%cl, %esi
    4414:      	addq	%rax, %r15
    4417:      	addq	%r15, %rdi
    441a:      	movl	$0x4, %eax
    441f:      	callq	*%rax
    4421:      	movq	%r15, 0x90(%rsp)
    4429:      	cmpl	%r12d, %r13d
    442c:      	jbe	0x46d7 <generic_lsm_process_filter+0xd27>
    4432:      	movq	0x58(%rsp), %rax
    4437:      	movq	%rax, 0x78(%rsp)
    443c:      	decl	%r14d
    443f:      	jne	0x4300 <generic_lsm_process_filter+0x950>
    4445:      	jmp	0x46d7 <generic_lsm_process_filter+0xd27>
    444a:      	nopw	(%rax,%rax)
    4450:      	leaq	0x10(%r12), %rdx
    4455:      	movl	$0x4, %eax
    445a:      	movq	%rbx, %rdi
    445d:      	movl	$0x8, %esi
    4462:      	callq	*%rax
    4464:      	movq	0x88(%rsp), %rax
    446c:      	cmpq	0x10(%rsp), %rax
    4471:      	je	0x46cf <generic_lsm_process_filter+0xd1f>
    4477:      	addq	$0x18, %r12
    447b:      	movl	$0x4, %eax
    4480:      	leaq	0x78(%rsp), %rdi
    4485:      	movl	$0x8, %esi
    448a:      	movq	%r12, %rdx
    448d:      	callq	*%rax
    448f:      	movq	0x10(%rsp), %rax
    4494:      	movq	%rax, 0x88(%rsp)
    449c:      	addq	$0x20, %rax
    44a0:      	movq	%rax, 0x80(%rsp)
    44a8:      	decl	%r14d
    44ab:      	jne	0x4300 <generic_lsm_process_filter+0x950>
    44b1:      	jmp	0x46d7 <generic_lsm_process_filter+0xd27>
    44b6:      	leaq	0x18(%r14), %rdx
    44ba:      	leaq	0x60(%rsp), %rdi
    44bf:      	movl	$0x8, %ecx
    44c4:      	movl	$0x4, %eax
    44c9:      	movl	$0x8, %esi
    44ce:      	callq	*%rax
    44d0:      	cmpq	%r14, 0x60(%rsp)
    44d5:      	je	0x41ee <generic_lsm_process_filter+0x83e>
    44db:      	movq	0x50(%rsp), %r14
    44e0:      	movl	0x6410(%r14), %ecx
    44e7:      	leal	-0xa(%rcx), %eax
    44ea:      	movl	%eax, 0x6410(%r14)
    44f1:      	cmpl	$0x9, %ecx
    44f4:      	jg	0x4e94 <generic_lsm_process_filter+0x14e4>
    44fa:      	movl	$0xffffffdc, 0x6414(%r14) # imm = 0xFFFFFFDC
    4505:      	movq	%r13, %rbx
    4508:      	jmp	0x4758 <generic_lsm_process_filter+0xda8>
    450d:      	movl	$0x800, %r14d           # imm = 0x800
    4513:      	movl	$0x8, %ebp
    4518:      	leaq	0x10(%rsp), %rbx
    451d:      	nopl	(%rax)
    4520:      	movq	0x78(%rsp), %r15
    4525:      	movq	0x80(%rsp), %rdx
    452d:      	movq	0x88(%rsp), %r12
    4535:      	cmpq	0x60(%rsp), %r15
    453a:      	jne	0x4547 <generic_lsm_process_filter+0xb97>
    453c:      	cmpq	0x68(%rsp), %rdx
    4541:      	je	0x46cf <generic_lsm_process_filter+0xd1f>
    4547:      	movl	$0x4, %eax
    454c:      	leaq	0xa8(%rsp), %rdi
    4554:      	movl	$0x8, %esi
    4559:      	callq	*%rax
    455b:      	cmpq	0xa8(%rsp), %r15
    4563:      	je	0x4670 <generic_lsm_process_filter+0xcc0>
    4569:      	leaq	0x18(%r15), %r13
    456d:      	movl	$0x4, %eax
    4572:      	movq	%rbx, %rdi
    4575:      	movl	$0x8, %esi
    457a:      	movq	%r13, %rdx
    457d:      	callq	*%rax
    457f:      	cmpq	%r15, 0x10(%rsp)
    4584:      	je	0x4670 <generic_lsm_process_filter+0xcc0>
    458a:      	movl	$0x4, %eax
    458f:      	leaq	0x58(%rsp), %rdi
    4594:      	movl	$0x8, %esi
    4599:      	movq	%r13, %rdx
    459c:      	callq	*%rax
    459e:      	addq	$0x20, %r15
    45a2:      	movl	$0x4, %eax
    45a7:      	leaq	0x40(%rsp), %rdi
    45ac:      	movl	$0x10, %ecx
    45b1:      	movl	$0x10, %esi
    45b6:      	movq	%r15, %rdx
    45b9:      	callq	*%rax
    45bb:      	movq	0x70(%rsp), %r15
    45c0:      	movq	0x90(%rsp), %rax
    45c8:      	movl	0x44(%rsp), %r12d
    45cd:      	subq	%r15, %rax
    45d0:      	movl	0x98(%rsp), %r13d
    45d8:      	movl	%r12d, %edx
    45db:      	subl	%r13d, %edx
    45de:      	movl	$0x0, %ecx
    45e3:      	cmovbl	%ecx, %edx
    45e6:      	addq	0x48(%rsp), %rdx
    45eb:      	xorl	%esi, %esi
    45ed:      	cmpl	%r12d, %r13d
    45f0:      	seta	%sil
    45f4:      	movl	%r12d, %ecx
    45f7:      	cmovbl	%r13d, %ecx
    45fb:      	addl	%ecx, %esi
    45fd:      	movl	%r13d, %edi
    4600:      	subl	%esi, %edi
    4602:      	movl	%edi, 0x98(%rsp)
    4609:      	subq	%rsi, %rax
    460c:      	jb	0x46d7 <generic_lsm_process_filter+0xd27>
    4612:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    4618:      	ja	0x46d7 <generic_lsm_process_filter+0xd27>
    461e:      	cmpl	%r12d, %r13d
    4621:      	jbe	0x4628 <generic_lsm_process_filter+0xc78>
    4623:      	movb	$0x2f, (%r15,%rax)
    4628:      	xorl	%edi, %edi
    462a:      	cmpl	%r12d, %r13d
    462d:      	seta	%dil
    4631:      	movzbl	%cl, %esi
    4634:      	addq	%rax, %r15
    4637:      	addq	%r15, %rdi
    463a:      	movl	$0x4, %eax
    463f:      	callq	*%rax
    4641:      	movq	%r15, 0x90(%rsp)
    4649:      	cmpl	%r12d, %r13d
    464c:      	jbe	0x46d7 <generic_lsm_process_filter+0xd27>
    4652:      	movq	0x58(%rsp), %rax
    4657:      	movq	%rax, 0x78(%rsp)
    465c:      	decl	%r14d
    465f:      	jne	0x4520 <generic_lsm_process_filter+0xb70>
    4665:      	jmp	0x46d7 <generic_lsm_process_filter+0xd27>
    4667:      	nopw	(%rax,%rax)
    4670:      	leaq	0x10(%r12), %rdx
    4675:      	movl	$0x4, %eax
    467a:      	movq	%rbx, %rdi
    467d:      	movl	$0x8, %esi
    4682:      	callq	*%rax
    4684:      	movq	0x88(%rsp), %rax
    468c:      	cmpq	0x10(%rsp), %rax
    4691:      	je	0x46cf <generic_lsm_process_filter+0xd1f>
    4693:      	addq	$0x18, %r12
    4697:      	movl	$0x4, %eax
    469c:      	leaq	0x78(%rsp), %rdi
    46a1:      	movl	$0x8, %esi
    46a6:      	movq	%r12, %rdx
    46a9:      	callq	*%rax
    46ab:      	movq	0x10(%rsp), %rax
    46b0:      	movq	%rax, 0x88(%rsp)
    46b8:      	addq	$0x20, %rax
    46bc:      	movq	%rax, 0x80(%rsp)
    46c4:      	decl	%r14d
    46c7:      	jne	0x4520 <generic_lsm_process_filter+0xb70>
    46cd:      	jmp	0x46d7 <generic_lsm_process_filter+0xd27>
    46cf:      	movb	$0x1, 0x9c(%rsp)
    46d7:      	movq	0x90(%rsp), %rbx
    46df:      	movq	0xc0(%rsp), %rcx
    46e7:      	cmpq	%rcx, %rbx
    46ea:      	je	0x4738 <generic_lsm_process_filter+0xd88>
    46ec:      	xorl	%ecx, %ecx
    46ee:      	cmpb	$0x0, 0x9c(%rsp)
    46f6:      	sete	%cl
    46f9:      	addl	%ecx, %ecx
    46fb:      	movl	0x98(%rsp), %eax
    4702:      	movq	0x50(%rsp), %r14
    4707:      	movl	%eax, 0x6410(%r14)
    470e:      	movl	%ecx, 0x6414(%r14)
    4715:      	testl	%eax, %eax
    4717:      	movq	0x38(%rsp), %rbp
    471c:      	jle	0x472e <generic_lsm_process_filter+0xd7e>
    471e:      	movl	$0x1000, %ecx           # imm = 0x1000
    4723:      	subl	%eax, %ecx
    4725:      	movl	%ecx, 0x6410(%r14)
    472c:      	movl	%ecx, %eax
    472e:      	testq	%rbx, %rbx
    4731:      	jne	0x475d <generic_lsm_process_filter+0xdad>
    4733:      	jmp	0x4857 <generic_lsm_process_filter+0xea7>
    4738:      	movq	0x50(%rsp), %r14
    473d:      	movl	$0x0, 0x6410(%r14)
    4748:      	movl	$0x0, 0x6414(%r14)
    4753:      	xorl	%eax, %eax
    4755:      	movq	%rcx, %rbx
    4758:      	movq	0x38(%rsp), %rbp
    475d:      	xorl	%ecx, %ecx
    475f:      	movq	%r14, %rdx
    4762:      	movl	%eax, %r14d
    4765:      	subl	$0x7f, %r14d
    4769:      	movl	$0x7f, %r15d
    476f:      	cmovbl	%eax, %r15d
    4773:      	cmovbl	%ecx, %r14d
    4777:      	cmpl	$0xff, %eax
    477c:      	movl	$0xff, %ecx
    4781:      	cmovbl	%eax, %ecx
    4784:      	movzbl	%cl, %esi
    4787:      	movl	%esi, 0x6410(%rdx)
    478d:      	movl	$0x4, %eax
    4792:      	movq	%rbp, %rdi
    4795:      	movq	%rbx, %rdx
    4798:      	callq	*%rax
    479a:      	testq	%rax, %rax
    479d:      	je	0x47fc <generic_lsm_process_filter+0xe4c>
    479f:      	negl	%eax
    47a1:      	movw	%ax, 0x60(%rsp)
    47a6:      	movw	$0x8, 0x62(%rsp)
    47ad:      	movabsq	$0x4000002de, %rax      # imm = 0x4000002DE
    47b7:      	movq	%rax, 0x64(%rsp)
    47bc:      	movq	(%rip), %rdi            # 0x47c3 <generic_lsm_process_filter+0xe13>
    47c3:      	leaq	0x60(%rsp), %rsi
    47c8:      	movl	$0x1, %eax
    47cd:      	callq	*%rax
    47cf:      	testq	%rax, %rax
    47d2:      	je	0x47d8 <generic_lsm_process_filter+0xe28>
    47d4:      	incl	(%rax)
    47d6:      	jmp	0x47fc <generic_lsm_process_filter+0xe4c>
    47d8:      	movl	$0x1, 0x40(%rsp)
    47e0:      	movq	(%rip), %rdi            # 0x47e7 <generic_lsm_process_filter+0xe37>
    47e7:      	xorl	%ecx, %ecx
    47e9:      	leaq	0x60(%rsp), %rsi
    47ee:      	leaq	0x40(%rsp), %rdx
    47f3:      	movl	$0x2, %eax
    47f8:      	xorl	%ecx, %ecx
    47fa:      	callq	*%rax
    47fc:      	movq	0x50(%rsp), %rax
    4801:      	leaq	0x6390(%rax), %rdi
    4808:      	addq	%r14, %rbx
    480b:      	movq	%rax, %r14
    480e:      	movl	$0x4, %eax
    4813:      	movl	%r15d, %esi
    4816:      	movq	%rbx, %rdx
    4819:      	callq	*%rax
    481b:      	testq	%rax, %rax
    481e:      	je	0x4857 <generic_lsm_process_filter+0xea7>
    4820:      	negl	%eax
    4822:      	movw	%ax, 0x60(%rsp)
    4827:      	movw	$0x8, 0x62(%rsp)
    482e:      	movabsq	$0x4000002e0, %rax      # imm = 0x4000002E0
    4838:      	movq	%rax, 0x64(%rsp)
    483d:      	movq	(%rip), %rdi            # 0x4844 <generic_lsm_process_filter+0xe94>
    4844:      	leaq	0x60(%rsp), %rsi
    4849:      	movl	$0x1, %eax
    484e:      	callq	*%rax
    4850:      	testq	%rax, %rax
    4853:      	je	0x4884 <generic_lsm_process_filter+0xed4>
    4855:      	incl	(%rax)
    4857:      	movl	0x6410(%r14), %eax
    485e:      	leal	-0x101(%rax), %ecx
    4864:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
    486a:      	ja	0x48bd <generic_lsm_process_filter+0xf0d>
    486c:      	movq	0x8(%rsp), %rax
    4871:      	movl	$0xffffffff, (%rax)     # imm = 0xFFFFFFFF
    4877:      	movq	0xb8(%rsp), %rbx
    487f:      	jmp	0x49d3 <generic_lsm_process_filter+0x1023>
    4884:      	movl	$0x1, 0x40(%rsp)
    488c:      	movq	(%rip), %rdi            # 0x4893 <generic_lsm_process_filter+0xee3>
    4893:      	xorl	%ecx, %ecx
    4895:      	leaq	0x60(%rsp), %rsi
    489a:      	leaq	0x40(%rsp), %rdx
    489f:      	movl	$0x2, %eax
    48a4:      	xorl	%ecx, %ecx
    48a6:      	callq	*%rax
    48a8:      	movl	0x6410(%r14), %eax
    48af:      	leal	-0x101(%rax), %ecx
    48b5:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
    48bb:      	jbe	0x486c <generic_lsm_process_filter+0xebc>
    48bd:      	movzbl	%al, %ebx
    48c0:      	leaq	0x5f80(%r14), %rdi
    48c7:      	movl	$0x4, %eax
    48cc:      	movl	%ebx, %esi
    48ce:      	movq	%rbp, %rdx
    48d1:      	callq	*%rax
    48d3:      	movq	%rax, %r15
    48d6:      	testq	%rax, %rax
    48d9:      	je	0x493b <generic_lsm_process_filter+0xf8b>
    48db:      	movl	%r15d, %eax
    48de:      	negl	%eax
    48e0:      	movw	%ax, 0x60(%rsp)
    48e5:      	movw	$0xf, 0x62(%rsp)
    48ec:      	movabsq	$0x400000164, %rax      # imm = 0x400000164
    48f6:      	movq	%rax, 0x64(%rsp)
    48fb:      	movq	(%rip), %rdi            # 0x4902 <generic_lsm_process_filter+0xf52>
    4902:      	leaq	0x60(%rsp), %rsi
    4907:      	movl	$0x1, %eax
    490c:      	callq	*%rax
    490e:      	testq	%rax, %rax
    4911:      	je	0x4917 <generic_lsm_process_filter+0xf67>
    4913:      	incl	(%rax)
    4915:      	jmp	0x493b <generic_lsm_process_filter+0xf8b>
    4917:      	movl	$0x1, 0x40(%rsp)
    491f:      	movq	(%rip), %rdi            # 0x4926 <generic_lsm_process_filter+0xf76>
    4926:      	xorl	%ecx, %ecx
    4928:      	leaq	0x60(%rsp), %rsi
    492d:      	leaq	0x40(%rsp), %rdx
    4932:      	movl	$0x2, %eax
    4937:      	xorl	%ecx, %ecx
    4939:      	callq	*%rax
    493b:      	testl	%r15d, %r15d
    493e:      	cmovel	%ebx, %r15d
    4942:      	movl	%r15d, 0x5f78(%r14)
    4949:      	cmpl	$0x7f, %ebx
    494c:      	movl	$0x7f, %esi
    4951:      	cmovbl	%ebx, %esi
    4954:      	leaq	0x6080(%r14), %rdi
    495b:      	leaq	0x6390(%r14), %rdx
    4962:      	movl	$0x4, %eax
    4967:      	callq	*%rax
    4969:      	testq	%rax, %rax
    496c:      	movq	0xb8(%rsp), %rbx
    4974:      	je	0x49d3 <generic_lsm_process_filter+0x1023>
    4976:      	negl	%eax
    4978:      	movw	%ax, 0x60(%rsp)
    497d:      	movw	$0xf, 0x62(%rsp)
    4984:      	movabsq	$0x40000016a, %rax      # imm = 0x40000016A
    498e:      	movq	%rax, 0x64(%rsp)
    4993:      	movq	(%rip), %rdi            # 0x499a <generic_lsm_process_filter+0xfea>
    499a:      	leaq	0x60(%rsp), %rsi
    499f:      	movl	$0x1, %eax
    49a4:      	callq	*%rax
    49a6:      	testq	%rax, %rax
    49a9:      	je	0x49af <generic_lsm_process_filter+0xfff>
    49ab:      	incl	(%rax)
    49ad:      	jmp	0x49d3 <generic_lsm_process_filter+0x1023>
    49af:      	movl	$0x1, 0x40(%rsp)
    49b7:      	movq	(%rip), %rdi            # 0x49be <generic_lsm_process_filter+0x100e>
    49be:      	xorl	%ecx, %ecx
    49c0:      	leaq	0x60(%rsp), %rsi
    49c5:      	leaq	0x40(%rsp), %rdx
    49ca:      	movl	$0x2, %eax
    49cf:      	xorl	%ecx, %ecx
    49d1:      	callq	*%rax
    49d3:      	leaq	0x5f10(%r14), %r15
    49da:      	orb	$0x10, 0x1(%r14)
    49df:      	leaq	0x5ef8(%r14), %rsi
    49e6:      	movq	(%rip), %rdi            # 0x49ed <generic_lsm_process_filter+0x103d>
    49ed:      	movl	$0x1, %eax
    49f2:      	callq	*%rax
    49f4:      	testq	%rax, %rax
    49f7:      	je	0x5fd3 <generic_lsm_process_filter+0x2623>
    49fd:      	movq	0x5eb8(%r14), %r13
    4a04:      	cmpq	$0x6, %r13
    4a08:      	jae	0x4c36 <generic_lsm_process_filter+0x1286>
    4a0e:      	movslq	(%rax), %rcx
    4a11:      	testq	%rcx, %rcx
    4a14:      	je	0x4c58 <generic_lsm_process_filter+0x12a8>
    4a1a:      	cmpq	%rcx, %r13
    4a1d:      	jae	0x4c36 <generic_lsm_process_filter+0x1286>
    4a23:      	movq	%rax, 0x8(%rsp)
    4a28:      	movq	%rcx, 0xc0(%rsp)
    4a30:      	movq	%rbx, 0xb8(%rsp)
    4a38:      	movl	%r13d, 0x10(%rsp)
    4a3d:      	movl	$0x0, 0x58(%rsp)
    4a45:      	movq	(%rip), %rdi            # 0x4a4c <generic_lsm_process_filter+0x109c>
    4a4c:      	leaq	0x10(%rsp), %rsi
    4a51:      	movl	$0x1, %eax
    4a56:      	callq	*%rax
    4a58:      	testq	%rax, %rax
    4a5b:      	movq	%r15, 0x38(%rsp)
    4a60:      	je	0x4c74 <generic_lsm_process_filter+0x12c4>
    4a66:      	movq	%rax, %rbx
    4a69:      	movl	(%rax), %eax
    4a6b:      	testl	%eax, %eax
    4a6d:      	je	0x4c74 <generic_lsm_process_filter+0x12c4>
    4a73:      	cmpl	$0x0, 0x68(%r15)
    4a78:      	js	0x5f7b <generic_lsm_process_filter+0x25cb>
    4a7e:      	cmpl	$0x1b, %eax
    4a81:      	ja	0x5f7b <generic_lsm_process_filter+0x25cb>
    4a87:      	movl	$0x60, %ecx
    4a8c:      	btl	%eax, %ecx
    4a8f:      	jb	0x570c <generic_lsm_process_filter+0x1d5c>
    4a95:      	movl	$0x4000100, %ecx        # imm = 0x4000100
    4a9a:      	btl	%eax, %ecx
    4a9d:      	jb	0x5679 <generic_lsm_process_filter+0x1cc9>
    4aa3:      	movl	$0x8000200, %ecx        # imm = 0x8000200
    4aa8:      	btl	%eax, %ecx
    4aab:      	jae	0x5f7b <generic_lsm_process_filter+0x25cb>
    4ab1:      	movq	%rbx, %rsi
    4ab4:      	addq	$0x4, %rsi
    4ab8:      	movq	(%rip), %rdi            # 0x4abf <generic_lsm_process_filter+0x110f>
    4abf:      	movl	$0x1, %eax
    4ac4:      	callq	*%rax
    4ac6:      	testq	%rax, %rax
    4ac9:      	je	0x5f7b <generic_lsm_process_filter+0x25cb>
    4acf:      	movq	%rax, %r12
    4ad2:      	movq	0x38(%rsp), %rax
    4ad7:      	movl	0x68(%rax), %eax
    4ada:      	cmpl	$0x7f, %eax
    4add:      	movl	$0x7f, %r14d
    4ae3:      	cmovll	%eax, %r14d
    4ae7:      	movq	(%rip), %rdi            # 0x4aee <generic_lsm_process_filter+0x113e>
    4aee:      	leaq	0x58(%rsp), %rsi
    4af3:      	movl	$0x1, %eax
    4af8:      	callq	*%rax
    4afa:      	testq	%rax, %rax
    4afd:      	je	0x5f7b <generic_lsm_process_filter+0x25cb>
    4b03:      	movq	%rax, %rbp
    4b06:      	leal	(,%r14,8), %eax
    4b0e:      	movl	%eax, (%rbp)
    4b11:      	movq	0x38(%rsp), %rax
    4b16:      	cmpl	$0x0, 0x6c(%rax)
    4b1a:      	jne	0x4bfd <generic_lsm_process_filter+0x124d>
    4b20:      	movq	0x38(%rsp), %r15
    4b25:      	movl	0x68(%r15), %ecx
    4b29:      	movl	%ecx, %eax
    4b2b:      	subl	%r14d, %eax
    4b2e:      	movl	%r14d, %edx
    4b31:      	andl	$0x7f, %edx
    4b34:      	addl	%edx, %eax
    4b36:      	addl	%ecx, %edx
    4b38:      	movl	%r14d, %ecx
    4b3b:      	notl	%ecx
    4b3d:      	addl	%edx, %ecx
    4b3f:      	subl	%r14d, %edx
    4b42:      	leal	-0x4(%rdx), %esi
    4b45:      	leaq	0x1f3(%r15), %rdi
    4b4c:      	leal	-0x3(%rdx), %r8d
    4b50:      	addl	$-0x2, %edx
    4b53:      	movq	$-0x3, %r9
    4b5a:      	leal	(%rcx,%r9), %r10d
    4b5e:      	addl	$0x3, %r10d
    4b62:      	andl	$0x7f, %r10d
    4b66:      	movzbl	0x170(%r15,%r10), %r10d
    4b6f:      	movb	%r10b, -0x3(%rdi)
    4b73:      	leaq	(%rax,%r9), %r10
    4b77:      	cmpq	$-0x2, %r10
    4b7b:      	je	0x4bf5 <generic_lsm_process_filter+0x1245>
    4b7d:      	leal	(%rdx,%r9), %r11d
    4b81:      	addl	$0x3, %r11d
    4b85:      	andl	$0x7f, %r11d
    4b89:      	movzbl	0x170(%r15,%r11), %r11d
    4b92:      	movb	%r11b, -0x2(%rdi)
    4b96:      	cmpq	$-0x1, %r10
    4b9a:      	je	0x4bf5 <generic_lsm_process_filter+0x1245>
    4b9c:      	leal	(%r8,%r9), %r10d
    4ba0:      	addl	$0x3, %r10d
    4ba4:      	andl	$0x7f, %r10d
    4ba8:      	movzbl	0x170(%r15,%r10), %r10d
    4bb1:      	movb	%r10b, -0x1(%rdi)
    4bb5:      	movq	%rax, %r10
    4bb8:      	addq	%r9, %r10
    4bbb:      	je	0x4bf5 <generic_lsm_process_filter+0x1245>
    4bbd:      	cmpq	$-0x7f, %r9
    4bc1:      	je	0x4bf5 <generic_lsm_process_filter+0x1245>
    4bc3:      	leal	(%rsi,%r9), %r10d
    4bc7:      	addl	$0x3, %r10d
    4bcb:      	andl	$0x7f, %r10d
    4bcf:      	movzbl	0x170(%r15,%r10), %r10d
    4bd8:      	movb	%r10b, (%rdi)
    4bdb:      	addq	$0x4, %rdi
    4bdf:      	leaq	(%rax,%r9), %r10
    4be3:      	addq	$-0x4, %r10
    4be7:      	addq	$-0x4, %r9
    4beb:      	cmpq	$-0x3, %r10
    4bef:      	jne	0x4b5a <generic_lsm_process_filter+0x11aa>
    4bf5:      	movl	$0x1, 0x6c(%r15)
    4bfd:      	cmpl	$0x7f, %r14d
    4c01:      	ja	0x4c29 <generic_lsm_process_filter+0x1279>
    4c03:      	movslq	%r14d, %rsi
    4c06:      	movq	%rbp, %rdi
    4c09:      	addq	$0x4, %rdi
    4c0d:      	movq	0x38(%rsp), %rax
    4c12:      	leaq	0x1f0(%rax), %rdx
    4c19:      	movl	$0x4, %eax
    4c1e:      	callq	*%rax
    4c20:      	testq	%rax, %rax
    4c23:      	js	0x5f7b <generic_lsm_process_filter+0x25cb>
    4c29:      	movl	$0x1, %eax
    4c2e:      	movq	%r12, %rdi
    4c31:      	jmp	0x5704 <generic_lsm_process_filter+0x1d54>
    4c36:      	movl	(%r15), %eax
    4c39:      	movl	%eax, 0x10(%r14)
    4c3d:      	movq	0x8(%r15), %rax
    4c41:      	movq	%rax, 0x18(%r14)
    4c45:      	cmpb	$0x0, 0x5ec0(%r14)
    4c4d:      	jne	0x5fbe <generic_lsm_process_filter+0x260e>
    4c53:      	jmp	0x5fd3 <generic_lsm_process_filter+0x2623>
    4c58:      	movb	$0x1, 0x5ec0(%r14)
    4c60:      	movl	(%r15), %eax
    4c63:      	movl	%eax, 0x10(%r14)
    4c67:      	movq	0x8(%r15), %rax
    4c6b:      	movq	%rax, 0x18(%r14)
    4c6f:      	jmp	0x5fbe <generic_lsm_process_filter+0x260e>
    4c74:      	movq	0x8(%rsp), %r10
    4c79:      	movq	(%rip), %rax            # 0x4c80 <generic_lsm_process_filter+0x12d0>
    4c80:      	cmpb	$0x0, (%rax)
    4c83:      	je	0x4ec5 <generic_lsm_process_filter+0x1515>
    4c89:      	movq	(%rip), %rdi            # 0x4c90 <generic_lsm_process_filter+0x12e0>
    4c90:      	movl	$0x1, %eax
    4c95:      	movq	0x38(%rsp), %rsi
    4c9a:      	callq	*%rax
    4c9c:      	movq	0x8(%rsp), %r10
    4ca1:      	testq	%rax, %rax
    4ca4:      	je	0x4ec5 <generic_lsm_process_filter+0x1515>
    4caa:      	movq	%rax, %rbp
    4cad:      	leal	0x5(%r13), %eax
    4cb1:      	movl	%eax, 0x10(%rsp)
    4cb5:      	movl	$0x0, 0x58(%rsp)
    4cbd:      	movq	(%rip), %rdi            # 0x4cc4 <generic_lsm_process_filter+0x1314>
    4cc4:      	leaq	0x10(%rsp), %rsi
    4cc9:      	movl	$0x1, %eax
    4cce:      	callq	*%rax
    4cd0:      	testq	%rax, %rax
    4cd3:      	je	0x4ec0 <generic_lsm_process_filter+0x1510>
    4cd9:      	movq	%rax, %r12
    4cdc:      	movl	(%rax), %eax
    4cde:      	testl	%eax, %eax
    4ce0:      	je	0x4ec0 <generic_lsm_process_filter+0x1510>
    4ce6:      	cmpl	$0x0, (%rbp)
    4cea:      	js	0x5f7b <generic_lsm_process_filter+0x25cb>
    4cf0:      	cmpl	$0x1b, %eax
    4cf3:      	ja	0x5f7b <generic_lsm_process_filter+0x25cb>
    4cf9:      	movl	$0x60, %ecx
    4cfe:      	btl	%eax, %ecx
    4d01:      	jb	0x5968 <generic_lsm_process_filter+0x1fb8>
    4d07:      	movl	$0x4000100, %ecx        # imm = 0x4000100
    4d0c:      	btl	%eax, %ecx
    4d0f:      	jb	0x58d8 <generic_lsm_process_filter+0x1f28>
    4d15:      	movl	$0x8000200, %ecx        # imm = 0x8000200
    4d1a:      	btl	%eax, %ecx
    4d1d:      	jae	0x5f7b <generic_lsm_process_filter+0x25cb>
    4d23:      	movq	%r12, %rsi
    4d26:      	addq	$0x4, %rsi
    4d2a:      	movq	(%rip), %rdi            # 0x4d31 <generic_lsm_process_filter+0x1381>
    4d31:      	movl	$0x1, %eax
    4d36:      	callq	*%rax
    4d38:      	testq	%rax, %rax
    4d3b:      	je	0x5f7b <generic_lsm_process_filter+0x25cb>
    4d41:      	movq	%rax, %r15
    4d44:      	movl	(%rbp), %eax
    4d47:      	cmpl	$0x7f, %eax
    4d4a:      	movl	$0x7f, %r14d
    4d50:      	cmovll	%eax, %r14d
    4d54:      	movq	(%rip), %rdi            # 0x4d5b <generic_lsm_process_filter+0x13ab>
    4d5b:      	leaq	0x58(%rsp), %rsi
    4d60:      	movl	$0x1, %eax
    4d65:      	callq	*%rax
    4d67:      	testq	%rax, %rax
    4d6a:      	je	0x5f7b <generic_lsm_process_filter+0x25cb>
    4d70:      	movq	%rax, %rbx
    4d73:      	leal	(,%r14,8), %eax
    4d7b:      	movl	%eax, (%rbx)
    4d7d:      	cmpl	$0x0, 0x4(%rbp)
    4d81:      	jne	0x4e5d <generic_lsm_process_filter+0x14ad>
    4d87:      	movl	(%rbp), %ecx
    4d8a:      	movl	%ecx, %eax
    4d8c:      	subl	%r14d, %eax
    4d8f:      	movl	%r14d, %edx
    4d92:      	andl	$0x7f, %edx
    4d95:      	addl	%edx, %eax
    4d97:      	addl	%ecx, %edx
    4d99:      	movl	%r14d, %ecx
    4d9c:      	notl	%ecx
    4d9e:      	addl	%edx, %ecx
    4da0:      	subl	%r14d, %edx
    4da3:      	leal	-0x4(%rdx), %esi
    4da6:      	leaq	0x18b(%rbp), %rdi
    4dad:      	leal	-0x3(%rdx), %r8d
    4db1:      	addl	$-0x2, %edx
    4db4:      	movq	$-0x3, %r9
    4dbb:      	leal	(%rcx,%r9), %r10d
    4dbf:      	addl	$0x3, %r10d
    4dc3:      	andl	$0x7f, %r10d
    4dc7:      	movzbl	0x108(%rbp,%r10), %r10d
    4dd0:      	movb	%r10b, -0x3(%rdi)
    4dd4:      	leaq	(%rax,%r9), %r10
    4dd8:      	cmpq	$-0x2, %r10
    4ddc:      	je	0x4e56 <generic_lsm_process_filter+0x14a6>
    4dde:      	leal	(%rdx,%r9), %r11d
    4de2:      	addl	$0x3, %r11d
    4de6:      	andl	$0x7f, %r11d
    4dea:      	movzbl	0x108(%rbp,%r11), %r11d
    4df3:      	movb	%r11b, -0x2(%rdi)
    4df7:      	cmpq	$-0x1, %r10
    4dfb:      	je	0x4e56 <generic_lsm_process_filter+0x14a6>
    4dfd:      	leal	(%r8,%r9), %r10d
    4e01:      	addl	$0x3, %r10d
    4e05:      	andl	$0x7f, %r10d
    4e09:      	movzbl	0x108(%rbp,%r10), %r10d
    4e12:      	movb	%r10b, -0x1(%rdi)
    4e16:      	movq	%rax, %r10
    4e19:      	addq	%r9, %r10
    4e1c:      	je	0x4e56 <generic_lsm_process_filter+0x14a6>
    4e1e:      	cmpq	$-0x7f, %r9
    4e22:      	je	0x4e56 <generic_lsm_process_filter+0x14a6>
    4e24:      	leal	(%rsi,%r9), %r10d
    4e28:      	addl	$0x3, %r10d
    4e2c:      	andl	$0x7f, %r10d
    4e30:      	movzbl	0x108(%rbp,%r10), %r10d
    4e39:      	movb	%r10b, (%rdi)
    4e3c:      	addq	$0x4, %rdi
    4e40:      	leaq	(%rax,%r9), %r10
    4e44:      	addq	$-0x4, %r10
    4e48:      	addq	$-0x4, %r9
    4e4c:      	cmpq	$-0x3, %r10
    4e50:      	jne	0x4dbb <generic_lsm_process_filter+0x140b>
    4e56:      	movl	$0x1, 0x4(%rbp)
    4e5d:      	cmpl	$0x7f, %r14d
    4e61:      	ja	0x4e87 <generic_lsm_process_filter+0x14d7>
    4e63:      	movslq	%r14d, %rsi
    4e66:      	movq	%rbx, %rdi
    4e69:      	addq	$0x4, %rdi
    4e6d:      	addq	$0x188, %rbp            # imm = 0x188
    4e74:      	movl	$0x4, %eax
    4e79:      	movq	%rbp, %rdx
    4e7c:      	callq	*%rax
    4e7e:      	testq	%rax, %rax
    4e81:      	js	0x5f7b <generic_lsm_process_filter+0x25cb>
    4e87:      	movl	$0x1, %eax
    4e8c:      	movq	%r15, %rdi
    4e8f:      	jmp	0x5960 <generic_lsm_process_filter+0x1fb0>
    4e94:      	movq	%r12, %r13
    4e97:      	addq	$0xff6, %r13            # imm = 0xFF6
    4e9e:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
    4ea8:      	movq	%rax, 0xff6(%r12)
    4eb0:      	movw	$0x2964, 0xffe(%r12)    # imm = 0x2964
    4ebb:      	jmp	0x41f3 <generic_lsm_process_filter+0x843>
    4ec0:      	movq	0x8(%rsp), %r10
    4ec5:      	movl	%r13d, %eax
    4ec8:      	leaq	0x4(,%rax,4), %rcx
    4ed0:      	movl	0x4(%r10,%rax,4), %eax
    4ed5:      	leal	(%rax,%rcx), %r14d
    4ed9:      	andl	$0x3ff, %r14d           # imm = 0x3FF
    4ee0:      	addl	%eax, %ecx
    4ee2:      	addl	$0x4, %ecx
    4ee5:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    4eeb:      	leaq	0x8(%r14), %rbp
    4eef:      	cmpl	$0x5, (%rcx,%r10)
    4ef4:      	jb	0x541e <generic_lsm_process_filter+0x1a6e>
    4efa:      	movl	(%rbp,%r10), %r12d
    4eff:      	movl	0x4(%rbp,%r10), %edi
    4f04:      	movl	0x8(%rbp,%r10), %edx
    4f09:      	movq	$0x0, 0x68(%rsp)
    4f12:      	movq	$0x0, 0x60(%rsp)
    4f1b:      	cmpl	$0x4, %edx
    4f1e:      	movl	$0x4, %ecx
    4f23:      	cmovbl	%edx, %ecx
    4f26:      	cmpl	$0x6, %r12d
    4f2a:      	jne	0x4f40 <generic_lsm_process_filter+0x1590>
    4f2c:      	movabsq	$0x100000001, %rsi      # imm = 0x100000001
    4f36:      	movq	%rsi, 0x60(%rsp)
    4f3b:      	movq	%rsi, 0x68(%rsp)
    4f40:      	testl	%edx, %edx
    4f42:      	je	0x5425 <generic_lsm_process_filter+0x1a75>
    4f48:      	movq	0x38(%rsp), %rdx
    4f4d:      	leaq	0x24(%rdx), %rsi
    4f51:      	testb	$0x1, %dil
    4f55:      	movq	%rsi, 0xb0(%rsp)
    4f5d:      	movq	%rsi, %r8
    4f60:      	cmoveq	%rdx, %r8
    4f64:      	addq	$0x10, %rdx
    4f68:      	movq	%rdx, 0xd0(%rsp)
    4f70:      	leal	(%rax,%r13,4), %r9d
    4f74:      	addl	$0x4, %r9d
    4f78:      	andl	$0x3ff, %r9d            # imm = 0x3FF
    4f7f:      	addq	$0x14, %r9
    4f83:      	decq	%rcx
    4f86:      	cmpq	$0x3, %rcx
    4f8a:      	movl	$0x3, %eax
    4f8f:      	cmovbq	%rcx, %rax
    4f93:      	movl	%eax, %eax
    4f95:      	leaq	0x4(,%rax,4), %r11
    4f9d:      	xorl	%r13d, %r13d
    4fa0:      	movq	%rdi, 0x30(%rsp)
    4fa5:      	movq	%r8, 0x28(%rsp)
    4faa:      	movq	%r9, 0x20(%rsp)
    4faf:      	movq	%r11, 0x18(%rsp)
    4fb4:      	jmp	0x4ff0 <generic_lsm_process_filter+0x1640>
    4fb6:      	movq	0x8(%rsp), %r10
    4fbb:      	movq	0x30(%rsp), %rdi
    4fc0:      	movq	0x28(%rsp), %r8
    4fc5:      	movq	0x20(%rsp), %r9
    4fca:      	movq	0x18(%rsp), %r11
    4fcf:      	cmpl	$0x6, %r12d
    4fd3:      	setne	%al
    4fd6:      	xorb	$0x1, %bl
    4fd9:      	orb	%al, %bl
    4fdb:      	movzbl	%bl, %eax
    4fde:      	movl	%eax, 0x60(%rsp,%r13)
    4fe3:      	addq	$0x4, %r13
    4fe7:      	cmpq	%r13, %r11
    4fea:      	je	0x5425 <generic_lsm_process_filter+0x1a75>
    4ff0:      	leaq	(%r9,%r13), %rax
    4ff4:      	movl	(%r8), %ecx
    4ff7:      	cmpq	$0x3e8, %rax            # imm = 0x3E8
    4ffd:      	jbe	0x520a <generic_lsm_process_filter+0x185a>
    5003:      	xorl	%r15d, %r15d
    5006:      	testb	$0x2, %dil
    500a:      	je	0x5227 <generic_lsm_process_filter+0x1877>
    5010:      	testb	$0x1, %dil
    5014:      	jne	0x5248 <generic_lsm_process_filter+0x1898>
    501a:      	movq	0x38(%rsp), %rcx
    501f:      	movl	(%rcx), %eax
    5021:      	movb	$0x1, %bl
    5023:      	cmpq	%rax, %r15
    5026:      	je	0x4fcf <generic_lsm_process_filter+0x161f>
    5028:      	movl	0x10(%rcx), %eax
    502b:      	cmpq	%rax, %r15
    502e:      	je	0x4fcf <generic_lsm_process_filter+0x161f>
    5030:      	movl	$0x1, %eax
    5035:      	movq	0xd0(%rsp), %rsi
    503d:      	movq	(%rip), %rdi            # 0x5044 <generic_lsm_process_filter+0x1694>
    5044:      	callq	*%rax
    5046:      	testq	%rax, %rax
    5049:      	je	0x53ed <generic_lsm_process_filter+0x1a3d>
    504f:      	movq	%rax, %rsi
    5052:      	movl	(%rax), %eax
    5054:      	cmpq	%rax, %r15
    5057:      	je	0x4fb6 <generic_lsm_process_filter+0x1606>
    505d:      	movl	0x10(%rsi), %eax
    5060:      	cmpq	%rax, %r15
    5063:      	je	0x4fb6 <generic_lsm_process_filter+0x1606>
    5069:      	addq	$0x10, %rsi
    506d:      	movl	$0x1, %eax
    5072:      	movq	(%rip), %rdi            # 0x5079 <generic_lsm_process_filter+0x16c9>
    5079:      	callq	*%rax
    507b:      	testq	%rax, %rax
    507e:      	je	0x53ed <generic_lsm_process_filter+0x1a3d>
    5084:      	movq	%rax, %rsi
    5087:      	movl	(%rax), %eax
    5089:      	cmpq	%rax, %r15
    508c:      	je	0x4fb6 <generic_lsm_process_filter+0x1606>
    5092:      	movl	0x10(%rsi), %eax
    5095:      	cmpq	%rax, %r15
    5098:      	je	0x4fb6 <generic_lsm_process_filter+0x1606>
    509e:      	addq	$0x10, %rsi
    50a2:      	movl	$0x1, %eax
    50a7:      	movq	(%rip), %rdi            # 0x50ae <generic_lsm_process_filter+0x16fe>
    50ae:      	callq	*%rax
    50b0:      	testq	%rax, %rax
    50b3:      	je	0x53ed <generic_lsm_process_filter+0x1a3d>
    50b9:      	movq	%rax, %rsi
    50bc:      	movl	(%rax), %eax
    50be:      	cmpq	%rax, %r15
    50c1:      	je	0x4fb6 <generic_lsm_process_filter+0x1606>
    50c7:      	movl	0x10(%rsi), %eax
    50ca:      	cmpq	%rax, %r15
    50cd:      	je	0x4fb6 <generic_lsm_process_filter+0x1606>
    50d3:      	addq	$0x10, %rsi
    50d7:      	movl	$0x1, %eax
    50dc:      	movq	(%rip), %rdi            # 0x50e3 <generic_lsm_process_filter+0x1733>
    50e3:      	callq	*%rax
    50e5:      	testq	%rax, %rax
    50e8:      	je	0x53ed <generic_lsm_process_filter+0x1a3d>
    50ee:      	movq	%rax, %rsi
    50f1:      	movl	(%rax), %eax
    50f3:      	cmpq	%rax, %r15
    50f6:      	je	0x4fb6 <generic_lsm_process_filter+0x1606>
    50fc:      	movl	0x10(%rsi), %eax
    50ff:      	cmpq	%rax, %r15
    5102:      	je	0x4fb6 <generic_lsm_process_filter+0x1606>
    5108:      	addq	$0x10, %rsi
    510c:      	movl	$0x1, %eax
    5111:      	movq	(%rip), %rdi            # 0x5118 <generic_lsm_process_filter+0x1768>
    5118:      	callq	*%rax
    511a:      	testq	%rax, %rax
    511d:      	je	0x53ed <generic_lsm_process_filter+0x1a3d>
    5123:      	movq	%rax, %rsi
    5126:      	movl	(%rax), %eax
    5128:      	cmpq	%rax, %r15
    512b:      	je	0x4fb6 <generic_lsm_process_filter+0x1606>
    5131:      	movl	0x10(%rsi), %eax
    5134:      	cmpq	%rax, %r15
    5137:      	je	0x4fb6 <generic_lsm_process_filter+0x1606>
    513d:      	addq	$0x10, %rsi
    5141:      	movl	$0x1, %eax
    5146:      	movq	(%rip), %rdi            # 0x514d <generic_lsm_process_filter+0x179d>
    514d:      	callq	*%rax
    514f:      	testq	%rax, %rax
    5152:      	je	0x53ed <generic_lsm_process_filter+0x1a3d>
    5158:      	movq	%rax, %rsi
    515b:      	movl	(%rax), %eax
    515d:      	cmpq	%rax, %r15
    5160:      	je	0x4fb6 <generic_lsm_process_filter+0x1606>
    5166:      	movl	0x10(%rsi), %eax
    5169:      	cmpq	%rax, %r15
    516c:      	je	0x4fb6 <generic_lsm_process_filter+0x1606>
    5172:      	addq	$0x10, %rsi
    5176:      	movl	$0x1, %eax
    517b:      	movq	(%rip), %rdi            # 0x5182 <generic_lsm_process_filter+0x17d2>
    5182:      	callq	*%rax
    5184:      	testq	%rax, %rax
    5187:      	je	0x53ed <generic_lsm_process_filter+0x1a3d>
    518d:      	movq	%rax, %rsi
    5190:      	movl	(%rax), %eax
    5192:      	cmpq	%rax, %r15
    5195:      	je	0x4fb6 <generic_lsm_process_filter+0x1606>
    519b:      	movl	0x10(%rsi), %eax
    519e:      	cmpq	%rax, %r15
    51a1:      	je	0x4fb6 <generic_lsm_process_filter+0x1606>
    51a7:      	addq	$0x10, %rsi
    51ab:      	movl	$0x1, %eax
    51b0:      	movq	(%rip), %rdi            # 0x51b7 <generic_lsm_process_filter+0x1807>
    51b7:      	callq	*%rax
    51b9:      	testq	%rax, %rax
    51bc:      	je	0x53ed <generic_lsm_process_filter+0x1a3d>
    51c2:      	movq	%rax, %rsi
    51c5:      	movl	(%rax), %eax
    51c7:      	cmpq	%rax, %r15
    51ca:      	je	0x4fb6 <generic_lsm_process_filter+0x1606>
    51d0:      	movl	0x10(%rsi), %eax
    51d3:      	cmpq	%rax, %r15
    51d6:      	movq	0x8(%rsp), %r10
    51db:      	movq	0x30(%rsp), %rdi
    51e0:      	movq	0x28(%rsp), %r8
    51e5:      	movq	0x20(%rsp), %r9
    51ea:      	movq	0x18(%rsp), %r11
    51ef:      	je	0x4fcf <generic_lsm_process_filter+0x161f>
    51f5:      	addq	$0x10, %rsi
    51f9:      	movl	$0x1, %eax
    51fe:      	movq	(%rip), %rcx            # 0x5205 <generic_lsm_process_filter+0x1855>
    5205:      	jmp	0x53e4 <generic_lsm_process_filter+0x1a34>
    520a:      	movl	$0x4, %esi
    520f:      	xorl	%edx, %edx
    5211:      	divq	%rsi
    5214:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5219:      	movl	(%r10,%rax,4), %r15d
    521d:      	testb	$0x2, %dil
    5221:      	jne	0x5010 <generic_lsm_process_filter+0x1660>
    5227:      	cmpl	$0x5, %r12d
    522b:      	jne	0x5236 <generic_lsm_process_filter+0x1886>
    522d:      	cmpq	%rcx, %r15
    5230:      	jne	0x5417 <generic_lsm_process_filter+0x1a67>
    5236:      	cmpq	%rcx, %r15
    5239:      	setne	%al
    523c:      	cmpl	$0x6, %r12d
    5240:      	setne	%bl
    5243:      	jmp	0x4fd9 <generic_lsm_process_filter+0x1629>
    5248:      	movq	0xb0(%rsp), %rax
    5250:      	movl	(%rax), %eax
    5252:      	testq	%rax, %rax
    5255:      	je	0x5417 <generic_lsm_process_filter+0x1a67>
    525b:      	movb	$0x1, %bl
    525d:      	testq	%r15, %r15
    5260:      	je	0x4fcf <generic_lsm_process_filter+0x161f>
    5266:      	cmpq	%rax, %r15
    5269:      	je	0x4fcf <generic_lsm_process_filter+0x161f>
    526f:      	movl	$0x1, %eax
    5274:      	movq	0xd0(%rsp), %rsi
    527c:      	movq	(%rip), %rdi            # 0x5283 <generic_lsm_process_filter+0x18d3>
    5283:      	callq	*%rax
    5285:      	testq	%rax, %rax
    5288:      	je	0x53ed <generic_lsm_process_filter+0x1a3d>
    528e:      	movq	%rax, %rsi
    5291:      	movl	0x24(%rax), %eax
    5294:      	cmpq	%rax, %r15
    5297:      	je	0x4fb6 <generic_lsm_process_filter+0x1606>
    529d:      	addq	$0x10, %rsi
    52a1:      	movl	$0x1, %eax
    52a6:      	movq	(%rip), %rdi            # 0x52ad <generic_lsm_process_filter+0x18fd>
    52ad:      	callq	*%rax
    52af:      	testq	%rax, %rax
    52b2:      	je	0x53ed <generic_lsm_process_filter+0x1a3d>
    52b8:      	movq	%rax, %rsi
    52bb:      	movl	0x24(%rax), %eax
    52be:      	cmpq	%rax, %r15
    52c1:      	je	0x4fb6 <generic_lsm_process_filter+0x1606>
    52c7:      	addq	$0x10, %rsi
    52cb:      	movl	$0x1, %eax
    52d0:      	movq	(%rip), %rdi            # 0x52d7 <generic_lsm_process_filter+0x1927>
    52d7:      	callq	*%rax
    52d9:      	testq	%rax, %rax
    52dc:      	je	0x53ed <generic_lsm_process_filter+0x1a3d>
    52e2:      	movq	%rax, %rsi
    52e5:      	movl	0x24(%rax), %eax
    52e8:      	cmpq	%rax, %r15
    52eb:      	je	0x4fb6 <generic_lsm_process_filter+0x1606>
    52f1:      	addq	$0x10, %rsi
    52f5:      	movl	$0x1, %eax
    52fa:      	movq	(%rip), %rdi            # 0x5301 <generic_lsm_process_filter+0x1951>
    5301:      	callq	*%rax
    5303:      	testq	%rax, %rax
    5306:      	je	0x53ed <generic_lsm_process_filter+0x1a3d>
    530c:      	movq	%rax, %rsi
    530f:      	movl	0x24(%rax), %eax
    5312:      	cmpq	%rax, %r15
    5315:      	je	0x4fb6 <generic_lsm_process_filter+0x1606>
    531b:      	addq	$0x10, %rsi
    531f:      	movl	$0x1, %eax
    5324:      	movq	(%rip), %rdi            # 0x532b <generic_lsm_process_filter+0x197b>
    532b:      	callq	*%rax
    532d:      	testq	%rax, %rax
    5330:      	je	0x53ed <generic_lsm_process_filter+0x1a3d>
    5336:      	movq	%rax, %rsi
    5339:      	movl	0x24(%rax), %eax
    533c:      	cmpq	%rax, %r15
    533f:      	je	0x4fb6 <generic_lsm_process_filter+0x1606>
    5345:      	addq	$0x10, %rsi
    5349:      	movl	$0x1, %eax
    534e:      	movq	(%rip), %rdi            # 0x5355 <generic_lsm_process_filter+0x19a5>
    5355:      	callq	*%rax
    5357:      	testq	%rax, %rax
    535a:      	je	0x53ed <generic_lsm_process_filter+0x1a3d>
    5360:      	movq	%rax, %rsi
    5363:      	movl	0x24(%rax), %eax
    5366:      	cmpq	%rax, %r15
    5369:      	je	0x4fb6 <generic_lsm_process_filter+0x1606>
    536f:      	addq	$0x10, %rsi
    5373:      	movl	$0x1, %eax
    5378:      	movq	(%rip), %rdi            # 0x537f <generic_lsm_process_filter+0x19cf>
    537f:      	callq	*%rax
    5381:      	testq	%rax, %rax
    5384:      	je	0x53ed <generic_lsm_process_filter+0x1a3d>
    5386:      	movq	%rax, %rsi
    5389:      	movl	0x24(%rax), %eax
    538c:      	cmpq	%rax, %r15
    538f:      	je	0x4fb6 <generic_lsm_process_filter+0x1606>
    5395:      	addq	$0x10, %rsi
    5399:      	movl	$0x1, %eax
    539e:      	movq	(%rip), %rdi            # 0x53a5 <generic_lsm_process_filter+0x19f5>
    53a5:      	callq	*%rax
    53a7:      	testq	%rax, %rax
    53aa:      	je	0x53ed <generic_lsm_process_filter+0x1a3d>
    53ac:      	movq	%rax, %rsi
    53af:      	movl	0x24(%rax), %eax
    53b2:      	cmpq	%rax, %r15
    53b5:      	movq	0x8(%rsp), %r10
    53ba:      	movq	0x30(%rsp), %rdi
    53bf:      	movq	0x28(%rsp), %r8
    53c4:      	movq	0x20(%rsp), %r9
    53c9:      	movq	0x18(%rsp), %r11
    53ce:      	je	0x4fcf <generic_lsm_process_filter+0x161f>
    53d4:      	addq	$0x10, %rsi
    53d8:      	movl	$0x1, %eax
    53dd:      	movq	(%rip), %rcx            # 0x53e4 <generic_lsm_process_filter+0x1a34>
    53e4:      	movq	(%rip), %rdi            # 0x53eb <generic_lsm_process_filter+0x1a3b>
    53eb:      	callq	*%rax
    53ed:      	xorl	%ebx, %ebx
    53ef:      	cmpl	$0x5, %r12d
    53f3:      	movq	0x8(%rsp), %r10
    53f8:      	movq	0x30(%rsp), %rdi
    53fd:      	movq	0x28(%rsp), %r8
    5402:      	movq	0x20(%rsp), %r9
    5407:      	movq	0x18(%rsp), %r11
    540c:      	jne	0x4fcf <generic_lsm_process_filter+0x161f>
    5412:      	jmp	0x4fdb <generic_lsm_process_filter+0x162b>
    5417:      	xorl	%ebx, %ebx
    5419:      	jmp	0x4fdb <generic_lsm_process_filter+0x162b>
    541e:      	movl	$0x1, %eax
    5423:      	jmp	0x5461 <generic_lsm_process_filter+0x1ab1>
    5425:      	movl	0x60(%rsp), %esi
    5429:      	movl	0x64(%rsp), %ecx
    542d:      	movl	0x68(%rsp), %eax
    5431:      	movl	0x6c(%rsp), %edx
    5435:      	cmpl	$0x6, %r12d
    5439:      	jne	0x5443 <generic_lsm_process_filter+0x1a93>
    543b:      	andl	%esi, %ecx
    543d:      	andl	%edx, %eax
    543f:      	andl	%ecx, %eax
    5441:      	jmp	0x5449 <generic_lsm_process_filter+0x1a99>
    5443:      	orl	%esi, %ecx
    5445:      	orl	%edx, %eax
    5447:      	orl	%ecx, %eax
    5449:      	testl	%eax, %eax
    544b:      	je	0x5f7b <generic_lsm_process_filter+0x25cb>
    5451:      	addl	$0x14, %r14d
    5455:      	movl	0x8(%r10,%rbp), %ecx
    545a:      	andl	$0x7, %ecx
    545d:      	leal	(%r14,%rcx,4), %ebp
    5461:      	movq	0x50(%rsp), %r9
    5466:      	movl	%ebp, %ecx
    5468:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    546e:      	movl	(%rcx,%r10), %ecx
    5472:      	addl	$0x4, %ebp
    5475:      	addl	$-0x4, %ecx
    5478:      	xorl	%esi, %esi
    547a:      	movl	$0x4, %r8d
    5480:      	jmp	0x549f <generic_lsm_process_filter+0x1aef>
    5482:      	nopw	%cs:(%rax,%rax)
    5490:      	xorl	%ecx, %ecx
    5492:      	incq	%rsi
    5495:      	cmpq	$0xa, %rsi
    5499:      	je	0x5628 <generic_lsm_process_filter+0x1c78>
    549f:      	testl	%ecx, %ecx
    54a1:      	je	0x5490 <generic_lsm_process_filter+0x1ae0>
    54a3:      	movl	%ebp, %r9d
    54a6:      	andl	$0x3ff, %r9d            # imm = 0x3FF
    54ad:      	movl	(%r9,%r10), %r11d
    54b1:      	movq	%r10, %rax
    54b4:      	movl	0x4(%r9,%r10), %r10d
    54b9:      	movl	0x8(%r9,%rax), %edx
    54be:      	movq	$0x0, 0x68(%rsp)
    54c7:      	movq	$0x0, 0x60(%rsp)
    54d0:      	cmpl	$0x4, %edx
    54d3:      	movl	$0x4, %eax
    54d8:      	cmovbl	%edx, %eax
    54db:      	cmpl	$0x6, %r10d
    54df:      	jne	0x54f5 <generic_lsm_process_filter+0x1b45>
    54e1:      	movabsq	$0x100000001, %rdi      # imm = 0x100000001
    54eb:      	movq	%rdi, 0x60(%rsp)
    54f0:      	movq	%rdi, 0x68(%rsp)
    54f5:      	addl	$0xc, %ebp
    54f8:      	testl	%edx, %edx
    54fa:      	je	0x55d0 <generic_lsm_process_filter+0x1c20>
    5500:      	andl	$0xf, %r11d
    5504:      	decq	%rax
    5507:      	cmpq	$0x3, %rax
    550b:      	movl	$0x3, %edx
    5510:      	cmovaeq	%rdx, %rax
    5514:      	leaq	0x4(,%rax,4), %rbx
    551c:      	movl	%ebp, %r14d
    551f:      	cmpl	$0x9, %r11d
    5523:      	jbe	0x555a <generic_lsm_process_filter+0x1baa>
    5525:      	xorl	%r11d, %r11d
    5528:      	jmp	0x5546 <generic_lsm_process_filter+0x1b96>
    552a:      	nopw	(%rax,%rax)
    5530:      	movl	$0x0, 0x60(%rsp,%r11)
    5539:      	addq	$0x4, %r11
    553d:      	cmpq	%r11, %rbx
    5540:      	je	0x55d0 <generic_lsm_process_filter+0x1c20>
    5546:      	leaq	(%r14,%r11), %rax
    554a:      	cmpl	$0x3e8, %eax            # imm = 0x3E8
    554f:      	ja	0x5530 <generic_lsm_process_filter+0x1b80>
    5551:      	movl	%eax, %eax
    5553:      	xorl	%edx, %edx
    5555:      	divq	%r8
    5558:      	jmp	0x5530 <generic_lsm_process_filter+0x1b80>
    555a:      	xorl	%r15d, %r15d
    555d:      	jmp	0x55a1 <generic_lsm_process_filter+0x1bf1>
    555f:      	nop
    5560:      	cmpl	$0x5, %r10d
    5564:      	setne	%dl
    5567:      	movl	%r10d, %r13d
    556a:      	xorl	$0x6, %r13d
    556e:      	movq	0x50(%rsp), %rax
    5573:      	movl	0x20(%rax,%r11,4), %edi
    5578:      	movl	%r12d, %eax
    557b:      	xorl	%edi, %eax
    557d:      	cmpl	%edi, %r12d
    5580:      	sete	%dil
    5584:      	orb	%dl, %dil
    5587:      	orl	%r13d, %eax
    558a:      	setne	%al
    558d:      	andb	%dil, %al
    5590:      	movzbl	%al, %eax
    5593:      	movl	%eax, 0x60(%rsp,%r15)
    5598:      	addq	$0x4, %r15
    559c:      	cmpq	%r15, %rbx
    559f:      	je	0x55d0 <generic_lsm_process_filter+0x1c20>
    55a1:      	leaq	(%r14,%r15), %rdx
    55a5:      	xorl	%r12d, %r12d
    55a8:      	cmpl	$0x3e8, %edx            # imm = 0x3E8
    55ae:      	ja	0x5560 <generic_lsm_process_filter+0x1bb0>
    55b0:      	movl	%edx, %eax
    55b2:      	xorl	%edx, %edx
    55b4:      	divq	%r8
    55b7:      	andl	$0x3ff, %eax            # imm = 0x3FF
    55bc:      	movq	0x8(%rsp), %rdx
    55c1:      	movl	(%rdx,%rax,4), %r12d
    55c5:      	jmp	0x5560 <generic_lsm_process_filter+0x1bb0>
    55c7:      	nopw	(%rax,%rax)
    55d0:      	movl	0x60(%rsp), %ebx
    55d4:      	movl	0x64(%rsp), %edx
    55d8:      	movl	0x68(%rsp), %eax
    55dc:      	movl	0x6c(%rsp), %r11d
    55e1:      	cmpl	$0x6, %r10d
    55e5:      	jne	0x55f0 <generic_lsm_process_filter+0x1c40>
    55e7:      	andl	%ebx, %edx
    55e9:      	andl	%r11d, %eax
    55ec:      	andl	%edx, %eax
    55ee:      	jmp	0x55f7 <generic_lsm_process_filter+0x1c47>
    55f0:      	orl	%ebx, %edx
    55f2:      	orl	%r11d, %eax
    55f5:      	orl	%edx, %eax
    55f7:      	movq	0x8(%rsp), %r10
    55fc:      	testl	%eax, %eax
    55fe:      	je	0x5f7b <generic_lsm_process_filter+0x25cb>
    5604:      	movl	0x8(%r10,%r9), %edx
    5609:      	shll	$0x2, %edx
    560c:      	subl	%edx, %ecx
    560e:      	andl	$0x1c, %edx
    5611:      	addl	%edx, %ebp
    5613:      	addl	$-0xc, %ecx
    5616:      	movq	0x50(%rsp), %r9
    561b:      	incq	%rsi
    561e:      	cmpq	$0xa, %rsi
    5622:      	jne	0x549f <generic_lsm_process_filter+0x1aef>
    5628:      	movl	%ebp, %ecx
    562a:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5630:      	leal	0x4(%rbp), %ebx
    5633:      	cmpl	$0x4, (%rcx,%r10)
    5638:      	je	0x5808 <generic_lsm_process_filter+0x1e58>
    563e:      	andl	$0x3ff, %ebx            # imm = 0x3FF
    5644:      	movl	(%rbx,%r10), %ecx
    5648:      	movl	0x4(%rbx,%r10), %edx
    564d:      	movl	0x8(%rbx,%r10), %edi
    5652:      	movq	0xc(%rbx,%r10), %rax
    5657:      	testl	%edi, %edi
    5659:      	je	0x57dc <generic_lsm_process_filter+0x1e2c>
    565f:      	xorl	%esi, %esi
    5661:      	cmpl	$0x2, %ecx
    5664:      	ja	0x57ff <generic_lsm_process_filter+0x1e4f>
    566a:      	cmpl	%edi, 0x44(%r9)
    566e:      	jne	0x57e5 <generic_lsm_process_filter+0x1e35>
    5674:      	jmp	0x57ff <generic_lsm_process_filter+0x1e4f>
    5679:      	movq	%rbx, %rsi
    567c:      	addq	$0x4, %rsi
    5680:      	movq	(%rip), %rdi            # 0x5687 <generic_lsm_process_filter+0x1cd7>
    5687:      	movl	$0x1, %eax
    568c:      	callq	*%rax
    568e:      	testq	%rax, %rax
    5691:      	je	0x5f7b <generic_lsm_process_filter+0x25cb>
    5697:      	movq	%rax, %r14
    569a:      	movq	(%rip), %rdi            # 0x56a1 <generic_lsm_process_filter+0x1cf1>
    56a1:      	leaq	0x58(%rsp), %rsi
    56a6:      	movl	$0x1, %eax
    56ab:      	callq	*%rax
    56ad:      	testq	%rax, %rax
    56b0:      	je	0x5f7b <generic_lsm_process_filter+0x25cb>
    56b6:      	movq	%rax, %rbp
    56b9:      	movl	$0x104, %edx            # imm = 0x104
    56be:      	movq	%rax, %rdi
    56c1:      	xorl	%esi, %esi
    56c3:      	callq	0x56c8 <generic_lsm_process_filter+0x1d18>
    56c8:      	movq	0x38(%rsp), %rsi
    56cd:      	movl	0x68(%rsi), %eax
    56d0:      	leal	(,%rax,8), %ecx
    56d7:      	movl	%ecx, (%rbp)
    56da:      	movq	%rbp, %rdi
    56dd:      	addq	$0x4, %rdi
    56e1:      	movzbl	%al, %ecx
    56e4:      	leaq	0x70(%rsi), %rdx
    56e8:      	movl	$0x4, %eax
    56ed:      	movzbl	0x68(%rsi), %esi
    56f1:      	callq	*%rax
    56f3:      	testq	%rax, %rax
    56f6:      	js	0x5f7b <generic_lsm_process_filter+0x25cb>
    56fc:      	movl	$0x1, %eax
    5701:      	movq	%r14, %rdi
    5704:      	movq	%rbp, %rsi
    5707:      	jmp	0x5b07 <generic_lsm_process_filter+0x2157>
    570c:      	movl	$0x0, 0x40(%rsp)
    5714:      	movq	(%rip), %rdi            # 0x571b <generic_lsm_process_filter+0x1d6b>
    571b:      	leaq	0x40(%rsp), %rsi
    5720:      	movl	$0x1, %eax
    5725:      	callq	*%rax
    5727:      	testq	%rax, %rax
    572a:      	movq	0x38(%rsp), %rdx
    572f:      	je	0x5ab4 <generic_lsm_process_filter+0x2104>
    5735:      	movq	(%rax), %rcx
    5738:      	cmpq	0x378(%rdx), %rcx
    573f:      	je	0x5ab4 <generic_lsm_process_filter+0x2104>
    5745:      	movq	%rax, 0xb0(%rsp)
    574d:      	movq	(%rip), %rax            # 0x5754 <generic_lsm_process_filter+0x1da4>
    5754:      	cmpb	$0x0, (%rax)
    5757:      	je	0x5a2b <generic_lsm_process_filter+0x207b>
    575d:      	movl	$0x1869f, %r15d         # imm = 0x1869F
    5763:      	xorl	%r14d, %r14d
    5766:      	movq	(%rip), %r12            # 0x576d <generic_lsm_process_filter+0x1dbd>
    576d:      	movq	0x38(%rsp), %rax
    5772:      	movl	0x10(%rax), %eax
    5775:      	movl	%eax, 0x60(%rsp)
    5779:      	movl	$0x1, %eax
    577e:      	leaq	0x60(%rsp), %rsi
    5783:      	movq	%r12, %rdi
    5786:      	callq	*%rax
    5788:      	testq	%rax, %rax
    578b:      	je	0x5a9d <generic_lsm_process_filter+0x20ed>
    5791:      	movq	%rax, %rbp
    5794:      	leaq	0x70(%rax), %rsi
    5798:      	movl	$0x1, %eax
    579d:      	movq	(%rip), %rdi            # 0x57a4 <generic_lsm_process_filter+0x1df4>
    57a4:      	callq	*%rax
    57a6:      	testq	%rax, %rax
    57a9:      	je	0x57c0 <generic_lsm_process_filter+0x1e10>
    57ab:      	movq	(%rax), %rax
    57ae:      	testq	%rax, %rax
    57b1:      	je	0x57c0 <generic_lsm_process_filter+0x1e10>
    57b3:      	movq	0x38(%rsp), %rcx
    57b8:      	lock
    57b9:      	orq	%rax, 0x370(%rcx)
    57c0:      	subl	$0x1, %r15d
    57c4:      	setb	%al
    57c7:      	cmpq	%r14, %rbp
    57ca:      	je	0x5a9d <generic_lsm_process_filter+0x20ed>
    57d0:      	movq	%rbp, %r14
    57d3:      	testb	%al, %al
    57d5:      	je	0x576d <generic_lsm_process_filter+0x1dbd>
    57d7:      	jmp	0x5a9d <generic_lsm_process_filter+0x20ed>
    57dc:      	cmpl	$0x2, %ecx
    57df:      	jbe	0x57e5 <generic_lsm_process_filter+0x1e35>
    57e1:      	xorl	%esi, %esi
    57e3:      	jmp	0x57ff <generic_lsm_process_filter+0x1e4f>
    57e5:      	andq	0x48(%r9,%rcx,8), %rax
    57ea:      	cmpl	$0x5, %edx
    57ed:      	jne	0x57f8 <generic_lsm_process_filter+0x1e48>
    57ef:      	testq	%rax, %rax
    57f2:      	setne	%sil
    57f6:      	jmp	0x57ff <generic_lsm_process_filter+0x1e4f>
    57f8:      	testq	%rax, %rax
    57fb:      	sete	%sil
    57ff:      	addl	$0x18, %ebp
    5802:      	movzbl	%sil, %eax
    5806:      	movl	%ebp, %ebx
    5808:      	testl	%eax, %eax
    580a:      	je	0x5f7b <generic_lsm_process_filter+0x25cb>
    5810:      	movl	%ebx, %ecx
    5812:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5818:      	leal	0x4(%rbx), %eax
    581b:      	cmpl	$0x4, (%rcx,%r10)
    5820:      	je	0x5e83 <generic_lsm_process_filter+0x24d3>
    5826:      	andl	$0x3ff, %eax            # imm = 0x3FF
    582b:      	movl	(%rax,%r10), %r14d
    582f:      	movl	0x4(%rax,%r10), %ebp
    5834:      	movl	$0xe, %eax
    5839:      	callq	*%rax
    583b:      	shrq	$0x20, %rax
    583f:      	movl	%eax, 0x60(%rsp)
    5843:      	movq	(%rip), %rdi            # 0x584a <generic_lsm_process_filter+0x1e9a>
    584a:      	leaq	0x60(%rsp), %rsi
    584f:      	movl	$0x1, %eax
    5854:      	callq	*%rax
    5856:      	movq	0x8(%rsp), %r10
    585b:      	testq	%rax, %rax
    585e:      	je	0x5f7b <generic_lsm_process_filter+0x25cb>
    5864:      	cmpl	$0x5, %r14d
    5868:      	je	0x58a6 <generic_lsm_process_filter+0x1ef6>
    586a:      	cmpl	$0x6, %r14d
    586e:      	jne	0x5f7b <generic_lsm_process_filter+0x25cb>
    5874:      	movq	0x50(%rsp), %rsi
    5879:      	movq	%rsi, %rcx
    587c:      	addq	$0x5ee8, %rcx           # imm = 0x5EE8
    5883:      	testb	$0x1, %bpl
    5887:      	jne	0x5b49 <generic_lsm_process_filter+0x2199>
    588d:      	movl	0x28(%rax), %edx
    5890:      	testl	%edx, %edx
    5892:      	je	0x5b42 <generic_lsm_process_filter+0x2192>
    5898:      	cmpl	0x20(%rsi), %edx
    589b:      	je	0x5b49 <generic_lsm_process_filter+0x2199>
    58a1:      	jmp	0x5e77 <generic_lsm_process_filter+0x24c7>
    58a6:      	movq	0x50(%rsp), %rsi
    58ab:      	movq	%rsi, %rcx
    58ae:      	addq	$0x5ee8, %rcx           # imm = 0x5EE8
    58b5:      	testb	$0x1, %bpl
    58b9:      	je	0x5b67 <generic_lsm_process_filter+0x21b7>
    58bf:      	movl	0x28(%rax), %edx
    58c2:      	testl	%edx, %edx
    58c4:      	je	0x5b60 <generic_lsm_process_filter+0x21b0>
    58ca:      	cmpl	0x20(%rsi), %edx
    58cd:      	je	0x5b67 <generic_lsm_process_filter+0x21b7>
    58d3:      	jmp	0x5e77 <generic_lsm_process_filter+0x24c7>
    58d8:      	movq	%r12, %rsi
    58db:      	addq	$0x4, %rsi
    58df:      	movq	(%rip), %rdi            # 0x58e6 <generic_lsm_process_filter+0x1f36>
    58e6:      	movl	$0x1, %eax
    58eb:      	callq	*%rax
    58ed:      	testq	%rax, %rax
    58f0:      	je	0x5f7b <generic_lsm_process_filter+0x25cb>
    58f6:      	movq	%rax, %r14
    58f9:      	movq	(%rip), %rdi            # 0x5900 <generic_lsm_process_filter+0x1f50>
    5900:      	leaq	0x58(%rsp), %rsi
    5905:      	movl	$0x1, %eax
    590a:      	callq	*%rax
    590c:      	testq	%rax, %rax
    590f:      	je	0x5f7b <generic_lsm_process_filter+0x25cb>
    5915:      	movq	%rax, %rbx
    5918:      	movl	$0x104, %edx            # imm = 0x104
    591d:      	movq	%rax, %rdi
    5920:      	xorl	%esi, %esi
    5922:      	callq	0x5927 <generic_lsm_process_filter+0x1f77>
    5927:      	movl	(%rbp), %eax
    592a:      	leal	(,%rax,8), %ecx
    5931:      	movl	%ecx, (%rbx)
    5933:      	movq	%rbx, %rdi
    5936:      	addq	$0x4, %rdi
    593a:      	movzbl	%al, %ecx
    593d:      	movq	%rbp, %rdx
    5940:      	addq	$0x8, %rdx
    5944:      	movl	$0x4, %eax
    5949:      	movzbl	(%rbp), %esi
    594d:      	callq	*%rax
    594f:      	testq	%rax, %rax
    5952:      	js	0x5f7b <generic_lsm_process_filter+0x25cb>
    5958:      	movl	$0x1, %eax
    595d:      	movq	%r14, %rdi
    5960:      	movq	%rbx, %rsi
    5963:      	jmp	0x5cdd <generic_lsm_process_filter+0x232d>
    5968:      	movl	$0x0, 0x40(%rsp)
    5970:      	movq	(%rip), %rdi            # 0x5977 <generic_lsm_process_filter+0x1fc7>
    5977:      	leaq	0x40(%rsp), %rsi
    597c:      	movl	$0x1, %eax
    5981:      	callq	*%rax
    5983:      	testq	%rax, %rax
    5986:      	je	0x5c8a <generic_lsm_process_filter+0x22da>
    598c:      	movq	(%rax), %rcx
    598f:      	cmpq	0x310(%rbp), %rcx
    5996:      	je	0x5c8a <generic_lsm_process_filter+0x22da>
    599c:      	movq	%rax, 0xb0(%rsp)
    59a4:      	movq	(%rip), %rax            # 0x59ab <generic_lsm_process_filter+0x1ffb>
    59ab:      	cmpb	$0x0, (%rax)
    59ae:      	je	0x5c0e <generic_lsm_process_filter+0x225e>
    59b4:      	movl	$0x1869f, %r15d         # imm = 0x1869F
    59ba:      	xorl	%r14d, %r14d
    59bd:      	movq	0x38(%rsp), %rax
    59c2:      	movl	0x10(%rax), %eax
    59c5:      	movl	%eax, 0x60(%rsp)
    59c9:      	movl	$0x1, %eax
    59ce:      	movq	(%rip), %rdi            # 0x59d5 <generic_lsm_process_filter+0x2025>
    59d5:      	leaq	0x60(%rsp), %rsi
    59da:      	callq	*%rax
    59dc:      	testq	%rax, %rax
    59df:      	je	0x5c78 <generic_lsm_process_filter+0x22c8>
    59e5:      	movq	%rax, %rbx
    59e8:      	leaq	0x70(%rax), %rsi
    59ec:      	movl	$0x1, %eax
    59f1:      	movq	(%rip), %rdi            # 0x59f8 <generic_lsm_process_filter+0x2048>
    59f8:      	callq	*%rax
    59fa:      	testq	%rax, %rax
    59fd:      	je	0x5a0f <generic_lsm_process_filter+0x205f>
    59ff:      	movq	(%rax), %rax
    5a02:      	testq	%rax, %rax
    5a05:      	je	0x5a0f <generic_lsm_process_filter+0x205f>
    5a07:      	lock
    5a08:      	orq	%rax, 0x308(%rbp)
    5a0f:      	subl	$0x1, %r15d
    5a13:      	setb	%al
    5a16:      	cmpq	%r14, %rbx
    5a19:      	je	0x5c78 <generic_lsm_process_filter+0x22c8>
    5a1f:      	movq	%rbx, %r14
    5a22:      	testb	%al, %al
    5a24:      	je	0x59bd <generic_lsm_process_filter+0x200d>
    5a26:      	jmp	0x5c78 <generic_lsm_process_filter+0x22c8>
    5a2b:      	movl	$0x3ff, %r15d           # imm = 0x3FF
    5a31:      	xorl	%r14d, %r14d
    5a34:      	movq	(%rip), %r12            # 0x5a3b <generic_lsm_process_filter+0x208b>
    5a3b:      	movq	0x38(%rsp), %rax
    5a40:      	movl	0x10(%rax), %eax
    5a43:      	movl	%eax, 0x60(%rsp)
    5a47:      	movl	$0x1, %eax
    5a4c:      	leaq	0x60(%rsp), %rsi
    5a51:      	movq	%r12, %rdi
    5a54:      	callq	*%rax
    5a56:      	testq	%rax, %rax
    5a59:      	je	0x5a9d <generic_lsm_process_filter+0x20ed>
    5a5b:      	movq	%rax, %rbp
    5a5e:      	leaq	0x70(%rax), %rsi
    5a62:      	movl	$0x1, %eax
    5a67:      	movq	(%rip), %rdi            # 0x5a6e <generic_lsm_process_filter+0x20be>
    5a6e:      	callq	*%rax
    5a70:      	testq	%rax, %rax
    5a73:      	je	0x5a8a <generic_lsm_process_filter+0x20da>
    5a75:      	movq	(%rax), %rax
    5a78:      	testq	%rax, %rax
    5a7b:      	je	0x5a8a <generic_lsm_process_filter+0x20da>
    5a7d:      	movq	0x38(%rsp), %rcx
    5a82:      	lock
    5a83:      	orq	%rax, 0x370(%rcx)
    5a8a:      	subl	$0x1, %r15d
    5a8e:      	setb	%al
    5a91:      	cmpq	%r14, %rbp
    5a94:      	je	0x5a9d <generic_lsm_process_filter+0x20ed>
    5a96:      	movq	%rbp, %r14
    5a99:      	testb	%al, %al
    5a9b:      	je	0x5a3b <generic_lsm_process_filter+0x208b>
    5a9d:      	movq	0xb0(%rsp), %rax
    5aa5:      	movq	(%rax), %rax
    5aa8:      	movq	0x38(%rsp), %rdx
    5aad:      	movq	%rax, 0x378(%rdx)
    5ab4:      	movl	0x8(%rbx), %eax
    5ab7:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    5abc:      	cmpq	%rcx, %rax
    5abf:      	je	0x5ada <generic_lsm_process_filter+0x212a>
    5ac1:      	movq	0x370(%rdx), %rcx
    5ac8:      	btq	%rax, %rcx
    5acc:      	jae	0x5ada <generic_lsm_process_filter+0x212a>
    5ace:      	movabsq	$0xbadc0ffee, %rax      # imm = 0xBADC0FFEE
    5ad8:      	jmp	0x5b09 <generic_lsm_process_filter+0x2159>
    5ada:      	movq	(%rip), %rdi            # 0x5ae1 <generic_lsm_process_filter+0x2131>
    5ae1:      	leaq	0x10(%rsp), %rsi
    5ae6:      	movl	$0x1, %eax
    5aeb:      	callq	*%rax
    5aed:      	testq	%rax, %rax
    5af0:      	je	0x5f7b <generic_lsm_process_filter+0x25cb>
    5af6:      	movq	%rax, %rdi
    5af9:      	movq	0x38(%rsp), %rax
    5afe:      	leaq	0x70(%rax), %rsi
    5b02:      	movl	$0x1, %eax
    5b07:      	callq	*%rax
    5b09:      	movl	(%rbx), %ecx
    5b0b:      	cmpq	$0x25, %rcx
    5b0f:      	movq	0x8(%rsp), %r10
    5b14:      	ja	0x5b34 <generic_lsm_process_filter+0x2184>
    5b16:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    5b20:      	btq	%rcx, %rdx
    5b24:      	jae	0x5b34 <generic_lsm_process_filter+0x2184>
    5b26:      	testq	%rax, %rax
    5b29:      	jne	0x5f7b <generic_lsm_process_filter+0x25cb>
    5b2f:      	jmp	0x4c79 <generic_lsm_process_filter+0x12c9>
    5b34:      	testq	%rax, %rax
    5b37:      	jne	0x4c79 <generic_lsm_process_filter+0x12c9>
    5b3d:      	jmp	0x5f7b <generic_lsm_process_filter+0x25cb>
    5b42:      	movq	$0x1, (%rcx)
    5b49:      	testb	$0x2, %bpl
    5b4d:      	jne	0x5b85 <generic_lsm_process_filter+0x21d5>
    5b4f:      	movl	0x2c(%rax), %edx
    5b52:      	testl	%edx, %edx
    5b54:      	je	0x5b7e <generic_lsm_process_filter+0x21ce>
    5b56:      	cmpl	0x24(%rsi), %edx
    5b59:      	je	0x5b85 <generic_lsm_process_filter+0x21d5>
    5b5b:      	jmp	0x5e77 <generic_lsm_process_filter+0x24c7>
    5b60:      	movq	$0x1, (%rcx)
    5b67:      	testb	$0x2, %bpl
    5b6b:      	je	0x5ba3 <generic_lsm_process_filter+0x21f3>
    5b6d:      	movl	0x2c(%rax), %edx
    5b70:      	testl	%edx, %edx
    5b72:      	je	0x5b9c <generic_lsm_process_filter+0x21ec>
    5b74:      	cmpl	0x24(%rsi), %edx
    5b77:      	je	0x5ba3 <generic_lsm_process_filter+0x21f3>
    5b79:      	jmp	0x5e77 <generic_lsm_process_filter+0x24c7>
    5b7e:      	movq	$0x1, (%rcx)
    5b85:      	testb	$0x4, %bpl
    5b89:      	jne	0x5bc1 <generic_lsm_process_filter+0x2211>
    5b8b:      	movl	0x30(%rax), %edx
    5b8e:      	testl	%edx, %edx
    5b90:      	je	0x5bba <generic_lsm_process_filter+0x220a>
    5b92:      	cmpl	0x28(%rsi), %edx
    5b95:      	je	0x5bc1 <generic_lsm_process_filter+0x2211>
    5b97:      	jmp	0x5e77 <generic_lsm_process_filter+0x24c7>
    5b9c:      	movq	$0x1, (%rcx)
    5ba3:      	testb	$0x4, %bpl
    5ba7:      	je	0x5beb <generic_lsm_process_filter+0x223b>
    5ba9:      	movl	0x30(%rax), %edx
    5bac:      	testl	%edx, %edx
    5bae:      	je	0x5be4 <generic_lsm_process_filter+0x2234>
    5bb0:      	cmpl	0x28(%rsi), %edx
    5bb3:      	je	0x5beb <generic_lsm_process_filter+0x223b>
    5bb5:      	jmp	0x5e77 <generic_lsm_process_filter+0x24c7>
    5bba:      	movq	$0x1, (%rcx)
    5bc1:      	testb	$0x8, %bpl
    5bc5:      	jne	0x5d21 <generic_lsm_process_filter+0x2371>
    5bcb:      	movl	0x34(%rax), %edx
    5bce:      	testl	%edx, %edx
    5bd0:      	je	0x5d1a <generic_lsm_process_filter+0x236a>
    5bd6:      	cmpl	0x2c(%rsi), %edx
    5bd9:      	je	0x5d21 <generic_lsm_process_filter+0x2371>
    5bdf:      	jmp	0x5e77 <generic_lsm_process_filter+0x24c7>
    5be4:      	movq	$0x1, (%rcx)
    5beb:      	testb	$0x8, %bpl
    5bef:      	je	0x5d3f <generic_lsm_process_filter+0x238f>
    5bf5:      	movl	0x34(%rax), %edx
    5bf8:      	testl	%edx, %edx
    5bfa:      	je	0x5d38 <generic_lsm_process_filter+0x2388>
    5c00:      	cmpl	0x2c(%rsi), %edx
    5c03:      	je	0x5d3f <generic_lsm_process_filter+0x238f>
    5c09:      	jmp	0x5e77 <generic_lsm_process_filter+0x24c7>
    5c0e:      	movl	$0x3ff, %r15d           # imm = 0x3FF
    5c14:      	xorl	%r14d, %r14d
    5c17:      	movq	0x38(%rsp), %rax
    5c1c:      	movl	0x10(%rax), %eax
    5c1f:      	movl	%eax, 0x60(%rsp)
    5c23:      	movl	$0x1, %eax
    5c28:      	movq	(%rip), %rdi            # 0x5c2f <generic_lsm_process_filter+0x227f>
    5c2f:      	leaq	0x60(%rsp), %rsi
    5c34:      	callq	*%rax
    5c36:      	testq	%rax, %rax
    5c39:      	je	0x5c78 <generic_lsm_process_filter+0x22c8>
    5c3b:      	movq	%rax, %rbx
    5c3e:      	leaq	0x70(%rax), %rsi
    5c42:      	movl	$0x1, %eax
    5c47:      	movq	(%rip), %rdi            # 0x5c4e <generic_lsm_process_filter+0x229e>
    5c4e:      	callq	*%rax
    5c50:      	testq	%rax, %rax
    5c53:      	je	0x5c65 <generic_lsm_process_filter+0x22b5>
    5c55:      	movq	(%rax), %rax
    5c58:      	testq	%rax, %rax
    5c5b:      	je	0x5c65 <generic_lsm_process_filter+0x22b5>
    5c5d:      	lock
    5c5e:      	orq	%rax, 0x308(%rbp)
    5c65:      	subl	$0x1, %r15d
    5c69:      	setb	%al
    5c6c:      	cmpq	%r14, %rbx
    5c6f:      	je	0x5c78 <generic_lsm_process_filter+0x22c8>
    5c71:      	movq	%rbx, %r14
    5c74:      	testb	%al, %al
    5c76:      	je	0x5c17 <generic_lsm_process_filter+0x2267>
    5c78:      	movq	0xb0(%rsp), %rax
    5c80:      	movq	(%rax), %rax
    5c83:      	movq	%rax, 0x310(%rbp)
    5c8a:      	movl	0x8(%r12), %eax
    5c8f:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    5c94:      	cmpq	%rcx, %rax
    5c97:      	je	0x5cb2 <generic_lsm_process_filter+0x2302>
    5c99:      	movq	0x308(%rbp), %rcx
    5ca0:      	btq	%rax, %rcx
    5ca4:      	jae	0x5cb2 <generic_lsm_process_filter+0x2302>
    5ca6:      	movabsq	$0xbadc0ffee, %rax      # imm = 0xBADC0FFEE
    5cb0:      	jmp	0x5cdf <generic_lsm_process_filter+0x232f>
    5cb2:      	movq	(%rip), %rdi            # 0x5cb9 <generic_lsm_process_filter+0x2309>
    5cb9:      	leaq	0x10(%rsp), %rsi
    5cbe:      	movl	$0x1, %eax
    5cc3:      	callq	*%rax
    5cc5:      	testq	%rax, %rax
    5cc8:      	je	0x5f7b <generic_lsm_process_filter+0x25cb>
    5cce:      	movq	%rax, %rdi
    5cd1:      	addq	$0x8, %rbp
    5cd5:      	movl	$0x1, %eax
    5cda:      	movq	%rbp, %rsi
    5cdd:      	callq	*%rax
    5cdf:      	movl	(%r12), %ecx
    5ce3:      	cmpq	$0x25, %rcx
    5ce7:      	movq	0x8(%rsp), %r10
    5cec:      	ja	0x5d0c <generic_lsm_process_filter+0x235c>
    5cee:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    5cf8:      	btq	%rcx, %rdx
    5cfc:      	jae	0x5d0c <generic_lsm_process_filter+0x235c>
    5cfe:      	testq	%rax, %rax
    5d01:      	jne	0x5f7b <generic_lsm_process_filter+0x25cb>
    5d07:      	jmp	0x4ec5 <generic_lsm_process_filter+0x1515>
    5d0c:      	testq	%rax, %rax
    5d0f:      	jne	0x4ec5 <generic_lsm_process_filter+0x1515>
    5d15:      	jmp	0x5f7b <generic_lsm_process_filter+0x25cb>
    5d1a:      	movq	$0x1, (%rcx)
    5d21:      	testb	$0x10, %bpl
    5d25:      	jne	0x5d5d <generic_lsm_process_filter+0x23ad>
    5d27:      	movl	0x38(%rax), %edx
    5d2a:      	testl	%edx, %edx
    5d2c:      	je	0x5d56 <generic_lsm_process_filter+0x23a6>
    5d2e:      	cmpl	0x30(%rsi), %edx
    5d31:      	je	0x5d5d <generic_lsm_process_filter+0x23ad>
    5d33:      	jmp	0x5e77 <generic_lsm_process_filter+0x24c7>
    5d38:      	movq	$0x1, (%rcx)
    5d3f:      	testb	$0x10, %bpl
    5d43:      	je	0x5d7b <generic_lsm_process_filter+0x23cb>
    5d45:      	movl	0x38(%rax), %edx
    5d48:      	testl	%edx, %edx
    5d4a:      	je	0x5d74 <generic_lsm_process_filter+0x23c4>
    5d4c:      	cmpl	0x30(%rsi), %edx
    5d4f:      	je	0x5d7b <generic_lsm_process_filter+0x23cb>
    5d51:      	jmp	0x5e77 <generic_lsm_process_filter+0x24c7>
    5d56:      	movq	$0x1, (%rcx)
    5d5d:      	testb	$0x20, %bpl
    5d61:      	jne	0x5d99 <generic_lsm_process_filter+0x23e9>
    5d63:      	movl	0x3c(%rax), %edx
    5d66:      	testl	%edx, %edx
    5d68:      	je	0x5d92 <generic_lsm_process_filter+0x23e2>
    5d6a:      	cmpl	0x34(%rsi), %edx
    5d6d:      	je	0x5d99 <generic_lsm_process_filter+0x23e9>
    5d6f:      	jmp	0x5e77 <generic_lsm_process_filter+0x24c7>
    5d74:      	movq	$0x1, (%rcx)
    5d7b:      	testb	$0x20, %bpl
    5d7f:      	je	0x5db7 <generic_lsm_process_filter+0x2407>
    5d81:      	movl	0x3c(%rax), %edx
    5d84:      	testl	%edx, %edx
    5d86:      	je	0x5db0 <generic_lsm_process_filter+0x2400>
    5d88:      	cmpl	0x34(%rsi), %edx
    5d8b:      	je	0x5db7 <generic_lsm_process_filter+0x2407>
    5d8d:      	jmp	0x5e77 <generic_lsm_process_filter+0x24c7>
    5d92:      	movq	$0x1, (%rcx)
    5d99:      	testb	$0x40, %bpl
    5d9d:      	jne	0x5dd5 <generic_lsm_process_filter+0x2425>
    5d9f:      	movl	0x40(%rax), %edx
    5da2:      	testl	%edx, %edx
    5da4:      	je	0x5dce <generic_lsm_process_filter+0x241e>
    5da6:      	cmpl	0x38(%rsi), %edx
    5da9:      	je	0x5dd5 <generic_lsm_process_filter+0x2425>
    5dab:      	jmp	0x5e77 <generic_lsm_process_filter+0x24c7>
    5db0:      	movq	$0x1, (%rcx)
    5db7:      	testb	$0x40, %bpl
    5dbb:      	je	0x5df2 <generic_lsm_process_filter+0x2442>
    5dbd:      	movl	0x40(%rax), %edx
    5dc0:      	testl	%edx, %edx
    5dc2:      	je	0x5deb <generic_lsm_process_filter+0x243b>
    5dc4:      	cmpl	0x38(%rsi), %edx
    5dc7:      	je	0x5df2 <generic_lsm_process_filter+0x2442>
    5dc9:      	jmp	0x5e77 <generic_lsm_process_filter+0x24c7>
    5dce:      	movq	$0x1, (%rcx)
    5dd5:      	testb	%bpl, %bpl
    5dd8:      	js	0x5e0c <generic_lsm_process_filter+0x245c>
    5dda:      	movl	0x44(%rax), %edx
    5ddd:      	testl	%edx, %edx
    5ddf:      	je	0x5e05 <generic_lsm_process_filter+0x2455>
    5de1:      	cmpl	0x3c(%rsi), %edx
    5de4:      	je	0x5e0c <generic_lsm_process_filter+0x245c>
    5de6:      	jmp	0x5e77 <generic_lsm_process_filter+0x24c7>
    5deb:      	movq	$0x1, (%rcx)
    5df2:      	testb	%bpl, %bpl
    5df5:      	jns	0x5e29 <generic_lsm_process_filter+0x2479>
    5df7:      	movl	0x44(%rax), %edx
    5dfa:      	testl	%edx, %edx
    5dfc:      	je	0x5e22 <generic_lsm_process_filter+0x2472>
    5dfe:      	cmpl	0x3c(%rsi), %edx
    5e01:      	je	0x5e29 <generic_lsm_process_filter+0x2479>
    5e03:      	jmp	0x5e77 <generic_lsm_process_filter+0x24c7>
    5e05:      	movq	$0x1, (%rcx)
    5e0c:      	testl	$0x100, %ebp            # imm = 0x100
    5e12:      	jne	0x5e52 <generic_lsm_process_filter+0x24a2>
    5e14:      	movl	0x48(%rax), %edx
    5e17:      	testl	%edx, %edx
    5e19:      	je	0x5e4b <generic_lsm_process_filter+0x249b>
    5e1b:      	cmpl	0x40(%rsi), %edx
    5e1e:      	je	0x5e52 <generic_lsm_process_filter+0x24a2>
    5e20:      	jmp	0x5e77 <generic_lsm_process_filter+0x24c7>
    5e22:      	movq	$0x1, (%rcx)
    5e29:      	testl	$0x100, %ebp            # imm = 0x100
    5e2f:      	je	0x5f61 <generic_lsm_process_filter+0x25b1>
    5e35:      	movl	0x48(%rax), %edx
    5e38:      	testl	%edx, %edx
    5e3a:      	je	0x5f5a <generic_lsm_process_filter+0x25aa>
    5e40:      	cmpl	0x40(%rsi), %edx
    5e43:      	je	0x5f61 <generic_lsm_process_filter+0x25b1>
    5e49:      	jmp	0x5e77 <generic_lsm_process_filter+0x24c7>
    5e4b:      	movq	$0x1, (%rcx)
    5e52:      	testl	$0x200, %ebp            # imm = 0x200
    5e58:      	jne	0x5f7b <generic_lsm_process_filter+0x25cb>
    5e5e:      	movl	0x4c(%rax), %eax
    5e61:      	testl	%eax, %eax
    5e63:      	je	0x5f74 <generic_lsm_process_filter+0x25c4>
    5e69:      	movq	0x50(%rsp), %rdx
    5e6e:      	cmpl	0x44(%rdx), %eax
    5e71:      	je	0x5f7b <generic_lsm_process_filter+0x25cb>
    5e77:      	addl	$0xc, %ebx
    5e7a:      	movq	$0x1, (%rcx)
    5e81:      	movl	%ebx, %eax
    5e83:      	movl	%eax, %ecx
    5e85:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5e8b:      	cmpl	$0x4, (%rcx,%r10)
    5e90:      	movq	0x50(%rsp), %rcx
    5e95:      	jne	0x5ebc <generic_lsm_process_filter+0x250c>
    5e97:      	movq	0x5eb8(%rcx), %rax
    5e9e:      	andl	$0x1f, %eax
    5ea1:      	movb	$0x1, 0x5ec1(%rcx,%rax)
    5ea9:      	movb	$0x1, 0x5ee0(%rcx)
    5eb0:      	movb	$0x1, 0x5ec0(%rcx)
    5eb7:      	jmp	0x5f7b <generic_lsm_process_filter+0x25cb>
    5ebc:      	addl	$0x4, %eax
    5ebf:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5ec4:      	movl	(%rax,%r10), %r14d
    5ec8:      	movl	0x4(%rax,%r10), %ebx
    5ecd:      	movl	0x8(%rax,%r10), %ebp
    5ed2:      	movq	0xc(%rax,%r10), %r15
    5ed7:      	movl	$0xe, %eax
    5edc:      	callq	*%rax
    5ede:      	shrq	$0x20, %rax
    5ee2:      	movl	%eax, 0x60(%rsp)
    5ee6:      	movq	(%rip), %rdi            # 0x5eed <generic_lsm_process_filter+0x253d>
    5eed:      	leaq	0x60(%rsp), %rsi
    5ef2:      	movl	$0x1, %eax
    5ef7:      	callq	*%rax
    5ef9:      	testq	%rax, %rax
    5efc:      	je	0x5f7b <generic_lsm_process_filter+0x25cb>
    5efe:      	testl	%ebp, %ebp
    5f00:      	je	0x5f14 <generic_lsm_process_filter+0x2564>
    5f02:      	cmpl	$0x2, %r14d
    5f06:      	ja	0x5f7b <generic_lsm_process_filter+0x25cb>
    5f08:      	movq	0x50(%rsp), %rcx
    5f0d:      	cmpl	%ebp, 0x44(%rcx)
    5f10:      	jne	0x5f1a <generic_lsm_process_filter+0x256a>
    5f12:      	jmp	0x5f7b <generic_lsm_process_filter+0x25cb>
    5f14:      	cmpl	$0x2, %r14d
    5f18:      	ja	0x5f7b <generic_lsm_process_filter+0x25cb>
    5f1a:      	movq	0x50(%rax,%r14,8), %rax
    5f1f:      	movq	0x50(%rsp), %rcx
    5f24:      	movq	0x48(%rcx,%r14,8), %rcx
    5f29:      	movq	%rcx, %rdx
    5f2c:      	xorq	%rax, %rdx
    5f2f:      	testq	%r15, %rdx
    5f32:      	je	0x5f3b <generic_lsm_process_filter+0x258b>
    5f34:      	cmpl	$0x5, %ebx
    5f37:      	jne	0x5f7b <generic_lsm_process_filter+0x25cb>
    5f39:      	jmp	0x5f45 <generic_lsm_process_filter+0x2595>
    5f3b:      	cmpq	%rcx, %rax
    5f3e:      	je	0x5f7b <generic_lsm_process_filter+0x25cb>
    5f40:      	cmpl	$0x6, %ebx
    5f43:      	jne	0x5f7b <generic_lsm_process_filter+0x25cb>
    5f45:      	movq	0x50(%rsp), %rcx
    5f4a:      	movq	$0x1, 0x5ef0(%rcx)
    5f55:      	jmp	0x5e97 <generic_lsm_process_filter+0x24e7>
    5f5a:      	movq	$0x1, (%rcx)
    5f61:      	testl	$0x200, %ebp            # imm = 0x200
    5f67:      	je	0x5f7b <generic_lsm_process_filter+0x25cb>
    5f69:      	movl	0x4c(%rax), %eax
    5f6c:      	testl	%eax, %eax
    5f6e:      	jne	0x5e69 <generic_lsm_process_filter+0x24b9>
    5f74:      	movq	$0x1, (%rcx)
    5f7b:      	movq	0x50(%rsp), %rcx
    5f80:      	movq	0x5eb8(%rcx), %rax
    5f87:      	incq	%rax
    5f8a:      	movq	%rax, 0x5eb8(%rcx)
    5f91:      	cmpq	0xc0(%rsp), %rax
    5f99:      	jbe	0x5fe7 <generic_lsm_process_filter+0x2637>
    5f9b:      	movq	0x38(%rsp), %rdx
    5fa0:      	movl	(%rdx), %eax
    5fa2:      	movl	%eax, 0x10(%rcx)
    5fa5:      	movq	0x8(%rdx), %rax
    5fa9:      	movq	%rax, 0x18(%rcx)
    5fad:      	cmpb	$0x0, 0x5ec0(%rcx)
    5fb4:      	movq	0xb8(%rsp), %rbx
    5fbc:      	je	0x5fd3 <generic_lsm_process_filter+0x2623>
    5fbe:      	movq	(%rip), %rsi            # 0x5fc5 <generic_lsm_process_filter+0x2615>
    5fc5:      	xorl	%ecx, %ecx
    5fc7:      	movl	$0xc, %eax
    5fcc:      	movq	%rbx, %rdi
    5fcf:      	xorl	%edx, %edx
    5fd1:      	callq	*%rax
    5fd3:      	xorl	%eax, %eax
    5fd5:      	addq	$0xe8, %rsp
    5fdc:      	popq	%rbx
    5fdd:      	popq	%r12
    5fdf:      	popq	%r13
    5fe1:      	popq	%r14
    5fe3:      	popq	%r15
    5fe5:      	popq	%rbp
    5fe6:      	retq
    5fe7:      	movq	(%rip), %rsi            # 0x5fee <generic_lsm_process_filter+0x263e>
    5fee:      	movl	$0x2, %ecx
    5ff3:      	movl	$0xc, %eax
    5ff8:      	movq	0xb8(%rsp), %rdi
    6000:      	movl	$0x2, %edx
    6005:      	jmp	0x5fd1 <generic_lsm_process_filter+0x2621>
    6007:      	nopw	(%rax,%rax)

0000000000006010 <generic_lsm_filter_arg>:
    6010:      	pushq	%rbp
    6011:      	pushq	%r15
    6013:      	pushq	%r14
    6015:      	pushq	%r13
    6017:      	pushq	%r12
    6019:      	pushq	%rbx
    601a:      	subq	$0x28, %rsp
    601e:      	movq	%rdi, %rbx
    6021:      	movl	$0x0, 0xc(%rsp)
    6029:      	movq	(%rip), %rdi            # 0x6030 <generic_lsm_filter_arg+0x20>
    6030:      	leaq	0xc(%rsp), %rsi
    6035:      	movl	$0x1, %eax
    603a:      	callq	*%rax
    603c:      	testq	%rax, %rax
    603f:      	je	0x640c <generic_lsm_filter_arg+0x3fc>
    6045:      	movq	%rax, %r14
    6048:      	movl	0x5f00(%rax), %r12d
    604f:      	leaq	0x5ef8(%rax), %rsi
    6056:      	movq	(%rip), %rdi            # 0x605d <generic_lsm_filter_arg+0x4d>
    605d:      	movl	$0x1, %eax
    6062:      	callq	*%rax
    6064:      	testq	%rax, %rax
    6067:      	je	0x63f1 <generic_lsm_filter_arg+0x3e1>
    606d:      	cmpb	$0x0, 0x5ee0(%r14)
    6075:      	je	0x63f1 <generic_lsm_filter_arg+0x3e1>
    607b:      	movq	%rax, %r15
    607e:      	movl	%r12d, %eax
    6081:      	andl	$0x7, %eax
    6084:      	cmpb	$0x0, 0x5ec1(%r14,%rax)
    608d:      	je	0x611c <generic_lsm_filter_arg+0x10c>
    6093:      	movl	%eax, %eax
    6095:      	movl	0x4(%r15,%rax,4), %ecx
    609a:      	leaq	(%rcx,%rax,4), %rdx
    609e:      	addq	$0x4, %rdx
    60a2:      	leaq	(%rcx,%rax,4), %rax
    60a6:      	addq	$0x8, %rax
    60aa:      	andl	$0x3ff, %eax            # imm = 0x3FF
    60af:      	movl	(%rax,%r15), %eax
    60b3:      	addq	%rdx, %rax
    60b6:      	addq	$0x4, %rax
    60ba:      	movl	%eax, %ecx
    60bc:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    60c2:      	movl	(%rcx,%r15), %ecx
    60c6:      	addq	%rax, %rcx
    60c9:      	movl	%ecx, %eax
    60cb:      	andl	$0x3ff, %eax            # imm = 0x3FF
    60d0:      	movl	(%rax,%r15), %eax
    60d4:      	addq	%rcx, %rax
    60d7:      	movl	%eax, %ecx
    60d9:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    60df:      	movl	(%rcx,%r15), %ecx
    60e3:      	addq	%rax, %rcx
    60e6:      	movl	%ecx, %eax
    60e8:      	andl	$0x3ff, %eax            # imm = 0x3FF
    60ed:      	movl	(%rax,%r15), %ebp
    60f1:      	addq	%rcx, %rbp
    60f4:      	movl	%ebp, %eax
    60f6:      	andl	$0x3ff, %eax            # imm = 0x3FF
    60fb:      	movq	%rax, (%rsp)
    60ff:      	cmpl	$0x19, (%r15,%rax)
    6104:      	jae	0x6171 <generic_lsm_filter_arg+0x161>
    6106:      	movq	(%rsp), %rax
    610a:      	cmpq	$0x1, %rax
    610e:      	je	0x63f1 <generic_lsm_filter_arg+0x3e1>
    6114:      	testl	%eax, %eax
    6116:      	jne	0x63cb <generic_lsm_filter_arg+0x3bb>
    611c:      	cmpl	$0x1, %r12d
    6120:      	jg	0x6141 <generic_lsm_filter_arg+0x131>
    6122:      	cmpl	$-0x1, %r12d
    6126:      	je	0x641d <generic_lsm_filter_arg+0x40d>
    612c:      	testl	%r12d, %r12d
    612f:      	je	0x642a <generic_lsm_filter_arg+0x41a>
    6135:      	cmpl	$0x1, %r12d
    6139:      	je	0x643a <generic_lsm_filter_arg+0x42a>
    613f:      	jmp	0x615f <generic_lsm_filter_arg+0x14f>
    6141:      	cmpl	$0x2, %r12d
    6145:      	je	0x644a <generic_lsm_filter_arg+0x43a>
    614b:      	cmpl	$0x3, %r12d
    614f:      	je	0x645a <generic_lsm_filter_arg+0x44a>
    6155:      	cmpl	$0x4, %r12d
    6159:      	je	0x646a <generic_lsm_filter_arg+0x45a>
    615f:      	cmpl	$0x4, %r12d
    6163:      	jg	0x649c <generic_lsm_filter_arg+0x48c>
    6169:      	incl	%r12d
    616c:      	jmp	0x647a <generic_lsm_filter_arg+0x46a>
    6171:      	movq	(%rsp), %rax
    6175:      	addq	%r15, %rax
    6178:      	movq	%rax, 0x10(%rsp)
    617d:      	movl	$0x1, %r13d
    6183:      	nopw	%cs:(%rax,%rax)
    6190:      	movq	0x10(%rsp), %rax
    6195:      	movl	(%rax,%r13,4), %edi
    6199:      	testl	$0x3ff, %edi            # imm = 0x3FF
    619f:      	je	0x6106 <generic_lsm_filter_arg+0xf6>
    61a5:      	addl	%ebp, %edi
    61a7:      	andl	$0x3ff, %edi            # imm = 0x3FF
    61ad:      	movl	0x4(%r15,%rdi), %ecx
    61b2:      	cmpl	$0x23, %ecx
    61b5:      	je	0x611c <generic_lsm_filter_arg+0x10c>
    61bb:      	addq	%r15, %rdi
    61be:      	movl	(%rdi), %eax
    61c0:      	cmpq	$0x4, %rax
    61c4:      	ja	0x611c <generic_lsm_filter_arg+0x10c>
    61ca:      	cmpl	$0x0, 0x5ea0(%r14,%rax,4)
    61d3:      	jne	0x611c <generic_lsm_filter_arg+0x10c>
    61d9:      	movq	0x5e78(%r14,%rax,8), %rax
    61e1:      	andl	$0x7ff, %eax            # imm = 0x7FF
    61e6:      	leaq	(%r14,%rax), %rsi
    61ea:      	addq	$0x90, %rsi
    61f1:      	movl	0xc(%rdi), %eax
    61f4:      	cmpl	$0x1b, %eax
    61f7:      	jle	0x6218 <generic_lsm_filter_arg+0x208>
    61f9:      	cmpl	$0x25, %eax
    61fc:      	jg	0x6248 <generic_lsm_filter_arg+0x238>
    61fe:      	leal	-0x1c(%rax), %edx
    6201:      	cmpl	$0x9, %edx
    6204:      	jb	0x628e <generic_lsm_filter_arg+0x27e>
    620a:      	cmpl	$0x25, %eax
    620d:      	je	0x6371 <generic_lsm_filter_arg+0x361>
    6213:      	jmp	0x63b9 <generic_lsm_filter_arg+0x3a9>
    6218:      	cmpl	$0x9, %eax
    621b:      	jle	0x626e <generic_lsm_filter_arg+0x25e>
    621d:      	leal	-0xa(%rax), %edx
    6220:      	cmpl	$0x4, %edx
    6223:      	jb	0x628e <generic_lsm_filter_arg+0x27e>
    6225:      	leal	-0xf(%rax), %ecx
    6228:      	cmpl	$0x2, %ecx
    622b:      	jb	0x6371 <generic_lsm_filter_arg+0x361>
    6231:      	cmpl	$0x11, %eax
    6234:      	jne	0x63b9 <generic_lsm_filter_arg+0x3a9>
    623a:      	addq	$0x4, %rsi
    623e:      	callq	0x6243 <generic_lsm_filter_arg+0x233>
    6243:      	jmp	0x63b0 <generic_lsm_filter_arg+0x3a0>
    6248:      	cmpl	$0x29, %eax
    624b:      	jg	0x6360 <generic_lsm_filter_arg+0x350>
    6251:      	leal	-0x26(%rax), %ecx
    6254:      	cmpl	$0x2, %ecx
    6257:      	jb	0x631b <generic_lsm_filter_arg+0x30b>
    625d:      	addl	$-0x28, %eax
    6260:      	cmpl	$0x2, %eax
    6263:      	jb	0x6311 <generic_lsm_filter_arg+0x301>
    6269:      	jmp	0x63b9 <generic_lsm_filter_arg+0x3a9>
    626e:      	cmpl	$0x4, %eax
    6271:      	jg	0x62fe <generic_lsm_filter_arg+0x2ee>
    6277:      	cmpl	$0x1, %eax
    627a:      	je	0x628e <generic_lsm_filter_arg+0x27e>
    627c:      	cmpl	$0x2, %eax
    627f:      	je	0x638e <generic_lsm_filter_arg+0x37e>
    6285:      	cmpl	$0x4, %eax
    6288:      	jne	0x63b9 <generic_lsm_filter_arg+0x3a9>
    628e:      	cmpl	$0xb, %eax
    6291:      	jle	0x62db <generic_lsm_filter_arg+0x2cb>
    6293:      	cmpl	$0x24, %eax
    6296:      	ja	0x6378 <generic_lsm_filter_arg+0x368>
    629c:      	movl	%eax, %edx
    629e:      	movabsq	$0x1e00000000, %r8      # imm = 0x1E00000000
    62a8:      	btq	%rdx, %r8
    62ac:      	jb	0x6322 <generic_lsm_filter_arg+0x312>
    62ae:      	movl	$0x60000000, %ecx       # imm = 0x60000000
    62b3:      	btq	%rdx, %rcx
    62b7:      	jb	0x6387 <generic_lsm_filter_arg+0x377>
    62bd:      	movabsq	$0x180000000, %rcx      # imm = 0x180000000
    62c7:      	btq	%rdx, %rcx
    62cb:      	jae	0x6378 <generic_lsm_filter_arg+0x368>
    62d1:      	callq	0x62d6 <generic_lsm_filter_arg+0x2c6>
    62d6:      	jmp	0x63b0 <generic_lsm_filter_arg+0x3a0>
    62db:      	leal	-0xa(%rax), %ecx
    62de:      	cmpl	$0x2, %ecx
    62e1:      	jb	0x639f <generic_lsm_filter_arg+0x38f>
    62e7:      	cmpl	$0x1, %eax
    62ea:      	je	0x6380 <generic_lsm_filter_arg+0x370>
    62f0:      	cmpl	$0x4, %eax
    62f3:      	je	0x6380 <generic_lsm_filter_arg+0x370>
    62f9:      	jmp	0x63b9 <generic_lsm_filter_arg+0x3a9>
    62fe:      	cmpl	$0x5, %eax
    6301:      	je	0x6311 <generic_lsm_filter_arg+0x301>
    6303:      	cmpl	$0x6, %eax
    6306:      	je	0x631b <generic_lsm_filter_arg+0x30b>
    6308:      	cmpl	$0x7, %eax
    630b:      	jne	0x63b9 <generic_lsm_filter_arg+0x3a9>
    6311:      	callq	0x6316 <generic_lsm_filter_arg+0x306>
    6316:      	jmp	0x63b0 <generic_lsm_filter_arg+0x3a0>
    631b:      	movl	$0x4, %edx
    6320:      	jmp	0x6393 <generic_lsm_filter_arg+0x383>
    6322:      	cmpl	$0x1e, %ecx
    6325:      	jne	0x639f <generic_lsm_filter_arg+0x38f>
    6327:      	movl	0x10(%rdi), %eax
    632a:      	andl	$0x7, %eax
    632d:      	movl	%eax, %ecx
    632f:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
    6338:      	jne	0x611c <generic_lsm_filter_arg+0x10c>
    633e:      	movq	(%rsi), %rcx
    6341:      	movq	0x5e78(%r14,%rax,8), %rdx
    6349:      	andl	$0x7ff, %edx            # imm = 0x7FF
    634f:      	xorl	%eax, %eax
    6351:      	andnq	0x90(%r14,%rdx), %rcx, %rcx
    635b:      	setne	%al
    635e:      	jmp	0x63b0 <generic_lsm_filter_arg+0x3a0>
    6360:      	cmpl	$0x2a, %eax
    6363:      	je	0x6371 <generic_lsm_filter_arg+0x361>
    6365:      	cmpl	$0x2c, %eax
    6368:      	jne	0x63b9 <generic_lsm_filter_arg+0x3a9>
    636a:      	callq	0x636f <generic_lsm_filter_arg+0x35f>
    636f:      	jmp	0x63b0 <generic_lsm_filter_arg+0x3a0>
    6371:      	callq	0x6376 <generic_lsm_filter_arg+0x366>
    6376:      	jmp	0x63b0 <generic_lsm_filter_arg+0x3a0>
    6378:      	leal	-0xc(%rax), %ecx
    637b:      	cmpl	$0x2, %ecx
    637e:      	jae	0x639a <generic_lsm_filter_arg+0x38a>
    6380:      	callq	0x6385 <generic_lsm_filter_arg+0x375>
    6385:      	jmp	0x63b0 <generic_lsm_filter_arg+0x3a0>
    6387:      	callq	0x638c <generic_lsm_filter_arg+0x37c>
    638c:      	jmp	0x63b0 <generic_lsm_filter_arg+0x3a0>
    638e:      	movl	$0x8, %edx
    6393:      	callq	0x6398 <generic_lsm_filter_arg+0x388>
    6398:      	jmp	0x63b0 <generic_lsm_filter_arg+0x3a0>
    639a:      	cmpl	$0x1c, %eax
    639d:      	jne	0x63b9 <generic_lsm_filter_arg+0x3a9>
    639f:      	callq	0x63a4 <generic_lsm_filter_arg+0x394>
    63a4:      	nopw	%cs:(%rax,%rax)
    63b0:      	testq	%rax, %rax
    63b3:      	je	0x611c <generic_lsm_filter_arg+0x10c>
    63b9:      	incq	%r13
    63bc:      	cmpq	$0x6, %r13
    63c0:      	jne	0x6190 <generic_lsm_filter_arg+0x180>
    63c6:      	jmp	0x6106 <generic_lsm_filter_arg+0xf6>
    63cb:      	movq	(%rsp), %rax
    63cf:      	movl	%eax, 0x5f04(%r14)
    63d6:      	movq	(%rip), %rsi            # 0x63dd <generic_lsm_filter_arg+0x3cd>
    63dd:      	movl	$0x4, %ecx
    63e2:      	movl	$0xc, %eax
    63e7:      	movq	%rbx, %rdi
    63ea:      	movl	$0x4, %edx
    63ef:      	callq	*%rax
    63f1:      	movq	(%rip), %rsi            # 0x63f8 <generic_lsm_filter_arg+0x3e8>
    63f8:      	movl	$0x5, %ecx
    63fd:      	movl	$0xc, %eax
    6402:      	movq	%rbx, %rdi
    6405:      	movl	$0x5, %edx
    640a:      	callq	*%rax
    640c:      	xorl	%eax, %eax
    640e:      	addq	$0x28, %rsp
    6412:      	popq	%rbx
    6413:      	popq	%r12
    6415:      	popq	%r13
    6417:      	popq	%r14
    6419:      	popq	%r15
    641b:      	popq	%rbp
    641c:      	retq
    641d:      	xorl	%r12d, %r12d
    6420:      	cmpb	$0x0, 0x5ec1(%r14)
    6428:      	jne	0x647a <generic_lsm_filter_arg+0x46a>
    642a:      	movl	$0x1, %r12d
    6430:      	cmpb	$0x0, 0x5ec2(%r14)
    6438:      	jne	0x647a <generic_lsm_filter_arg+0x46a>
    643a:      	movl	$0x2, %r12d
    6440:      	cmpb	$0x0, 0x5ec3(%r14)
    6448:      	jne	0x647a <generic_lsm_filter_arg+0x46a>
    644a:      	movl	$0x3, %r12d
    6450:      	cmpb	$0x0, 0x5ec4(%r14)
    6458:      	jne	0x647a <generic_lsm_filter_arg+0x46a>
    645a:      	movl	$0x4, %r12d
    6460:      	cmpb	$0x0, 0x5ec5(%r14)
    6468:      	jne	0x647a <generic_lsm_filter_arg+0x46a>
    646a:      	movl	$0x5, %r12d
    6470:      	cmpb	$0x0, 0x5ec6(%r14)
    6478:      	je	0x649c <generic_lsm_filter_arg+0x48c>
    647a:      	movl	%r12d, 0x5f00(%r14)
    6481:      	movq	(%rip), %rsi            # 0x6488 <generic_lsm_filter_arg+0x478>
    6488:      	movl	$0x3, %ecx
    648d:      	movl	$0xc, %eax
    6492:      	movq	%rbx, %rdi
    6495:      	movl	$0x3, %edx
    649a:      	callq	*%rax
    649c:      	movq	0x60(%r14), %rbx
    64a0:      	movl	$0xe, %eax
    64a5:      	callq	*%rax
    64a7:      	movq	%rbx, 0x18(%rsp)
    64ac:      	movq	%rax, 0x20(%rsp)
    64b1:      	movq	(%rip), %rdi            # 0x64b8 <generic_lsm_filter_arg+0x4a8>
    64b8:      	leaq	0x18(%rsp), %rsi
    64bd:      	movl	$0x1, %eax
    64c2:      	callq	*%rax
    64c4:      	testq	%rax, %rax
    64c7:      	je	0x640c <generic_lsm_filter_arg+0x3fc>
    64cd:      	movq	(%rip), %rdi            # 0x64d4 <generic_lsm_filter_arg+0x4c4>
    64d4:      	leaq	0x18(%rsp), %rsi
    64d9:      	movl	$0x3, %eax
    64de:      	callq	*%rax
    64e0:      	jmp	0x640c <generic_lsm_filter_arg+0x3fc>
    64e5:      	nopw	%cs:(%rax,%rax)

00000000000064f0 <generic_lsm_actions>:
    64f0:      	pushq	%rbp
    64f1:      	pushq	%r15
    64f3:      	pushq	%r14
    64f5:      	pushq	%rbx
    64f6:      	subq	$0x58, %rsp
    64fa:      	movq	%rdi, %r14
    64fd:      	movl	$0x0, 0x8(%rsp)
    6505:      	movq	(%rip), %rdi            # 0x650c <generic_lsm_actions+0x1c>
    650c:      	leaq	0x8(%rsp), %rsi
    6511:      	movl	$0x1, %eax
    6516:      	callq	*%rax
    6518:      	xorl	%ebx, %ebx
    651a:      	testq	%rax, %rax
    651d:      	je	0x65a5 <generic_lsm_actions+0xb5>
    6523:      	movq	%rax, %rsi
    6526:      	movl	0x5f04(%rax), %r15d
    652d:      	cmpl	$0x2, %r15d
    6531:      	jl	0x65a5 <generic_lsm_actions+0xb5>
    6533:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    653a:      	movq	(%rip), %rdi            # 0x6541 <generic_lsm_actions+0x51>
    6541:      	movl	$0x1, %eax
    6546:      	callq	*%rax
    6548:      	testq	%rax, %rax
    654b:      	je	0x65a5 <generic_lsm_actions+0xb5>
    654d:      	movl	%r15d, %ecx
    6550:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    6556:      	addl	(%rax,%rcx), %r15d
    655a:      	movb	$0x1, 0x4(%rsp)
    655f:      	movl	$0x0, 0x10(%rsp)
    6567:      	movq	(%rip), %rdi            # 0x656e <generic_lsm_actions+0x7e>
    656e:      	leaq	0x10(%rsp), %rsi
    6573:      	movq	%rax, %rcx
    6576:      	movl	$0x1, %eax
    657b:      	andl	$0x7ff, %r15d           # imm = 0x7FF
    6582:      	addq	%rcx, %r15
    6585:      	callq	*%rax
    6587:      	testq	%rax, %rax
    658a:      	je	0x66ce <generic_lsm_actions+0x1de>
    6590:      	cmpb	$0x0, (%rax)
    6593:      	sete	%al
    6596:      	cmpl	$0x5, (%r15)
    659a:      	jae	0x66d6 <generic_lsm_actions+0x1e6>
    65a0:      	jmp	0x6730 <generic_lsm_actions+0x240>
    65a5:      	xorl	%r15d, %r15d
    65a8:      	movl	$0x0, 0x4(%rsp)
    65b0:      	movq	(%rip), %rdi            # 0x65b7 <generic_lsm_actions+0xc7>
    65b7:      	leaq	0x4(%rsp), %rsi
    65bc:      	movl	$0x1, %eax
    65c1:      	callq	*%rax
    65c3:      	testq	%rax, %rax
    65c6:      	je	0x66c1 <generic_lsm_actions+0x1d1>
    65cc:      	movb	%r15b, 0x5f08(%rax)
    65d3:      	testb	$0x8, 0x1(%rax)
    65d7:      	je	0x666b <generic_lsm_actions+0x17b>
    65dd:      	testq	%r15, %r15
    65e0:      	je	0x666b <generic_lsm_actions+0x17b>
    65e6:      	movq	%rax, %r14
    65e9:      	movl	$0xe, %eax
    65ee:      	callq	*%rax
    65f0:      	movq	%rax, 0x8(%rsp)
    65f5:      	movq	$0x0, 0x11(%rsp)
    65fe:      	movq	$0x0, 0x19(%rsp)
    6607:      	movq	$0x0, 0x21(%rsp)
    6610:      	movq	$0x0, 0x29(%rsp)
    6619:      	movq	$0x0, 0x31(%rsp)
    6622:      	movq	$0x0, 0x39(%rsp)
    662b:      	movq	$0x0, 0x41(%rsp)
    6634:      	movq	$0x0, 0x49(%rsp)
    663d:      	movb	$0x0, 0x51(%rsp)
    6642:      	movb	$0x1, 0x10(%rsp)
    6647:      	movq	(%rip), %rdi            # 0x664e <generic_lsm_actions+0x15e>
    664e:      	xorl	%ecx, %ecx
    6650:      	leaq	0x8(%rsp), %rsi
    6655:      	leaq	0x10(%rsp), %rdx
    665a:      	movl	$0x2, %eax
    665f:      	xorl	%ecx, %ecx
    6661:      	callq	*%rax
    6663:      	movzbl	0x5f08(%r14), %r15d
    666b:      	testb	%r15b, %r15b
    666e:      	jne	0x66c1 <generic_lsm_actions+0x1d1>
    6670:      	movl	$0xe, %eax
    6675:      	callq	*%rax
    6677:      	movq	%rax, 0x10(%rsp)
    667c:      	movq	(%rip), %rdi            # 0x6683 <generic_lsm_actions+0x193>
    6683:      	leaq	0x10(%rsp), %rsi
    6688:      	movl	$0x1, %eax
    668d:      	callq	*%rax
    668f:      	testq	%rax, %rax
    6692:      	je	0x66bf <generic_lsm_actions+0x1cf>
    6694:      	movq	%rax, %rbx
    6697:      	movq	(%rip), %rdi            # 0x669e <generic_lsm_actions+0x1ae>
    669e:      	leaq	0x10(%rsp), %rsi
    66a3:      	movl	$0x3, %eax
    66a8:      	callq	*%rax
    66aa:      	movl	(%rbx), %eax
    66ac:      	leal	-0x1(%rax), %ecx
    66af:      	cmpl	$0xfffff000, %ecx       # imm = 0xFFFFF000
    66b5:      	movl	$0xffffffff, %ebx       # imm = 0xFFFFFFFF
    66ba:      	cmovael	%eax, %ebx
    66bd:      	jmp	0x66c1 <generic_lsm_actions+0x1d1>
    66bf:      	xorl	%ebx, %ebx
    66c1:      	movl	%ebx, %eax
    66c3:      	addq	$0x58, %rsp
    66c7:      	popq	%rbx
    66c8:      	popq	%r14
    66ca:      	popq	%r15
    66cc:      	popq	%rbp
    66cd:      	retq
    66ce:      	movb	$0x1, %al
    66d0:      	cmpl	$0x5, (%r15)
    66d4:      	jb	0x6730 <generic_lsm_actions+0x240>
    66d6:      	movzbl	%al, %ebp
    66d9:      	leaq	0x4(%rsp), %rcx
    66de:      	movq	%r14, %rdi
    66e1:      	xorl	%esi, %esi
    66e3:      	movq	%r15, %rdx
    66e6:      	movl	%ebp, %r8d
    66e9:      	callq	0x66ee <generic_lsm_actions+0x1fe>
    66ee:      	leal	0x4(,%rax,4), %ecx
    66f5:      	cmpl	(%r15), %ecx
    66f8:      	jae	0x6730 <generic_lsm_actions+0x240>
    66fa:      	leaq	0x4(%rsp), %rcx
    66ff:      	movq	%r14, %rdi
    6702:      	movl	%eax, %esi
    6704:      	movq	%r15, %rdx
    6707:      	movl	%ebp, %r8d
    670a:      	callq	0x670f <generic_lsm_actions+0x21f>
    670f:      	leal	0x4(,%rax,4), %ecx
    6716:      	cmpl	(%r15), %ecx
    6719:      	jae	0x6730 <generic_lsm_actions+0x240>
    671b:      	leaq	0x4(%rsp), %rcx
    6720:      	movq	%r14, %rdi
    6723:      	movl	%eax, %esi
    6725:      	movq	%r15, %rdx
    6728:      	movl	%ebp, %r8d
    672b:      	callq	0x6730 <generic_lsm_actions+0x240>
    6730:      	movzbl	0x4(%rsp), %r15d
    6736:      	testq	%r15, %r15
    6739:      	je	0x65a8 <generic_lsm_actions+0xb8>
    673f:      	movq	(%rip), %rsi            # 0x6746 <generic_lsm_actions+0x256>
    6746:      	movl	$0x5, %ecx
    674b:      	movl	$0xc, %eax
    6750:      	movq	%r14, %rdi
    6753:      	movl	$0x5, %edx
    6758:      	callq	*%rax
    675a:      	jmp	0x65a8 <generic_lsm_actions+0xb8>

Disassembly of section lsm/generic_lsm_core:

0000000000000000 <generic_lsm_event>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x88, %rsp
      11:      	movq	%rdi, %rbx
      14:      	movl	$0x0, 0x38(%rsp)
      1c:      	movq	(%rip), %rdi            # 0x23 <generic_lsm_event+0x23>
      23:      	leaq	0x38(%rsp), %rsi
      28:      	movl	$0x1, %eax
      2d:      	callq	*%rax
      2f:      	testq	%rax, %rax
      32:      	je	0x622 <generic_lsm_event+0x622>
      38:      	movq	%rax, %r14
      3b:      	leaq	0x5ef8(%rax), %rsi
      42:      	movl	$0x0, 0x5ef8(%rax)
      4c:      	movq	(%rip), %rdi            # 0x53 <generic_lsm_event+0x53>
      53:      	movl	$0x1, %eax
      58:      	callq	*%rax
      5a:      	testq	%rax, %rax
      5d:      	je	0x622 <generic_lsm_event+0x622>
      63:      	movl	0x64(%rax), %ecx
      66:      	movl	%ecx, 0x14(%rsp)
      6a:      	testl	%ecx, %ecx
      6c:      	je	0x23b <generic_lsm_event+0x23b>
      72:      	movq	%rax, %r12
      75:      	movq	(%rip), %rdi            # 0x7c <generic_lsm_event+0x7c>
      7c:      	leaq	0x14(%rsp), %rsi
      81:      	movl	$0x1, %eax
      86:      	callq	*%rax
      88:      	testq	%rax, %rax
      8b:      	je	0x622 <generic_lsm_event+0x622>
      91:      	movq	%rax, %r15
      94:      	movl	$0x0, 0x3c(%rsp)
      9c:      	movq	(%rip), %rdi            # 0xa3 <generic_lsm_event+0xa3>
      a3:      	leaq	0x3c(%rsp), %rsi
      a8:      	movl	$0x1, %eax
      ad:      	callq	*%rax
      af:      	testq	%rax, %rax
      b2:      	je	0xd8 <generic_lsm_event+0xd8>
      b4:      	cmpq	$0x63677270, 0x20(%rax) # imm = 0x63677270
      bc:      	jne	0xdc <generic_lsm_event+0xdc>
      be:      	movl	$0x50, %eax
      c3:      	callq	*%rax
      c5:      	movq	%rax, 0x8(%rsp)
      ca:      	testq	%rax, %rax
      cd:      	jne	0x1f6 <generic_lsm_event+0x1f6>
      d3:      	jmp	0x622 <generic_lsm_event+0x622>
      d8:      	xorl	%ebp, %ebp
      da:      	jmp	0xdf <generic_lsm_event+0xdf>
      dc:      	movl	0x10(%rax), %ebp
      df:      	movl	$0x23, %eax
      e4:      	callq	*%rax
      e6:      	movq	$0x0, 0x20(%rsp)
      ef:      	leaq	0xf90(%rax), %rdx
      f6:      	leaq	0x28(%rsp), %rdi
      fb:      	movl	$0x8, %ecx
     100:      	movl	$0x71, %eax
     105:      	movl	$0x8, %esi
     10a:      	callq	*%rax
     10c:      	movq	0x28(%rsp), %rax
     111:      	testq	%rax, %rax
     114:      	je	0x622 <generic_lsm_event+0x622>
     11a:      	cmpl	$0xb, %ebp
     11d:      	ja	0x622 <generic_lsm_event+0x622>
     123:      	movl	%ebp, %edx
     125:      	leaq	(%rax,%rdx,8), %rcx
     129:      	leaq	0x40(%rsp), %rdi
     12e:      	movl	$0x8, %esi
     133:      	movl	$0x71, %eax
     138:      	shlq	$0x3, %rdx
     13c:      	addq	0x28(%rsp), %rdx
     141:      	movl	$0x8, %esi
     146:      	callq	*%rax
     148:      	movq	0x40(%rsp), %rcx
     14d:      	testq	%rcx, %rcx
     150:      	je	0x622 <generic_lsm_event+0x622>
     156:      	leaq	0x20(%rsp), %rdi
     15b:      	movl	$0x8, %edx
     160:      	movl	$0x71, %eax
     165:      	movq	0x40(%rsp), %rdx
     16a:      	movl	$0x8, %esi
     16f:      	callq	*%rax
     171:      	movq	0x20(%rsp), %rdx
     176:      	testq	%rdx, %rdx
     179:      	je	0x622 <generic_lsm_event+0x622>
     17f:      	movq	$0x0, 0x40(%rsp)
     188:      	addq	$0x100, %rdx            # imm = 0x100
     18f:      	leaq	0x40(%rsp), %rdi
     194:      	movl	$0x8, %ecx
     199:      	movl	$0x71, %eax
     19e:      	movl	$0x8, %esi
     1a3:      	callq	*%rax
     1a5:      	movq	0x40(%rsp), %rdx
     1aa:      	movq	$0x0, 0x40(%rsp)
     1b3:      	testq	%rdx, %rdx
     1b6:      	je	0x1e6 <generic_lsm_event+0x1e6>
     1b8:      	addq	$0x60, %rdx
     1bc:      	leaq	0x40(%rsp), %rdi
     1c1:      	movl	$0x8, %ecx
     1c6:      	movl	$0x71, %eax
     1cb:      	movl	$0x8, %esi
     1d0:      	callq	*%rax
     1d2:      	movq	0x40(%rsp), %rax
     1d7:      	movq	%rax, 0x8(%rsp)
     1dc:      	testq	%rax, %rax
     1df:      	jne	0x1f6 <generic_lsm_event+0x1f6>
     1e1:      	jmp	0x622 <generic_lsm_event+0x622>
     1e6:      	xorl	%eax, %eax
     1e8:      	movq	%rax, 0x8(%rsp)
     1ed:      	testq	%rax, %rax
     1f0:      	je	0x622 <generic_lsm_event+0x622>
     1f6:      	movq	%rax, 0x40(%rsp)
     1fb:      	movq	(%rip), %rdi            # 0x202 <generic_lsm_event+0x202>
     202:      	leaq	0x40(%rsp), %rsi
     207:      	movl	$0x1, %eax
     20c:      	callq	*%rax
     20e:      	testq	%rax, %rax
     211:      	je	0x220 <generic_lsm_event+0x220>
     213:      	movq	(%rax), %rax
     216:      	testq	%rax, %rax
     219:      	je	0x220 <generic_lsm_event+0x220>
     21b:      	movq	%rax, 0x8(%rsp)
     220:      	leaq	0x8(%rsp), %rsi
     225:      	movl	$0x1, %eax
     22a:      	movq	%r15, %rdi
     22d:      	callq	*%rax
     22f:      	testq	%rax, %rax
     232:      	movq	%r12, %rax
     235:      	je	0x636 <generic_lsm_event+0x636>
     23b:      	movl	(%rax), %eax
     23d:      	movq	%rax, 0x60(%r14)
     241:      	movq	$0x0, 0x68(%r14)
     249:      	movq	$0x0, 0x5efc(%r14)
     254:      	movq	$0x0, 0x5eb8(%r14)
     25f:      	movq	$0x0, 0x5ec0(%r14)
     26a:      	movq	$0x0, 0x5ec8(%r14)
     275:      	movq	$0x0, 0x5ed0(%r14)
     280:      	movq	$0x0, 0x5ed8(%r14)
     28b:      	movb	$0x0, 0x5ee0(%r14)
     293:      	movl	$0x23, %eax
     298:      	callq	*%rax
     29a:      	movq	%rax, %r15
     29d:      	leaq	0xd70(%rax), %rdx
     2a4:      	leaq	0x20(%rsp), %rdi
     2a9:      	movl	$0x8, %ecx
     2ae:      	movl	$0x4, %eax
     2b3:      	leaq	0x20(%r14), %r12
     2b7:      	movl	$0x4, %r13d
     2bd:      	movl	$0x8, %esi
     2c2:      	callq	*%rax
     2c4:      	movq	0x20(%rsp), %rcx
     2c9:      	leaq	0x40(%rsp), %rdi
     2ce:      	movl	$0x48, %edx
     2d3:      	movl	$0x4, %eax
     2d8:      	movq	0x20(%rsp), %rdx
     2dd:      	movl	$0x48, %esi
     2e2:      	callq	*%rax
     2e4:      	movl	$0x218, %edx            # imm = 0x218
     2e9:      	movq	0x48(%rsp), %rcx
     2ee:      	addq	%rdx, %rcx
     2f1:      	movl	$0x4, %esi
     2f6:      	movl	$0x4, %eax
     2fb:      	addq	0x48(%rsp), %rdx
     300:      	movq	%r12, %rdi
     303:      	movl	$0x4, %esi
     308:      	callq	*%rax
     30a:      	leaq	0x24(%r14), %rdi
     30e:      	movl	$0x4d8, %edx            # imm = 0x4D8
     313:      	movq	0x50(%rsp), %rcx
     318:      	addq	%rdx, %rcx
     31b:      	movl	$0x4, %esi
     320:      	movl	$0x4, %eax
     325:      	addq	0x50(%rsp), %rdx
     32a:      	movl	$0x4, %esi
     32f:      	callq	*%rax
     331:      	leaq	0x28(%r14), %rdi
     335:      	movq	0x58(%rsp), %rcx
     33a:      	addq	$0x58, %rcx
     33e:      	movl	$0x4, %edx
     343:      	movl	$0x4, %eax
     348:      	movq	0x58(%rsp), %rdx
     34d:      	addq	$0x58, %rdx
     351:      	movl	$0x4, %esi
     356:      	callq	*%rax
     358:      	movq	$0x0, 0x8(%rsp)
     361:      	leaq	0xb58(%r15), %rdx
     368:      	leaq	0x8(%rsp), %rdi
     36d:      	movl	$0x8, %ecx
     372:      	movl	$0x4, %eax
     377:      	movl	$0x8, %esi
     37c:      	callq	*%rax
     37e:      	movq	0x8(%rsp), %rcx
     383:      	testq	%rcx, %rcx
     386:      	je	0x41c <generic_lsm_event+0x41c>
     38c:      	movl	$0x0, 0x18(%rsp)
     394:      	addq	$0x4, %rcx
     398:      	leaq	0x18(%rsp), %rdi
     39d:      	movl	$0x4, %eax
     3a2:      	movq	0x8(%rsp), %rdx
     3a7:      	addq	$0x4, %rdx
     3ab:      	movl	$0x4, %esi
     3b0:      	callq	*%rax
     3b2:      	movq	0x8(%rsp), %rax
     3b7:      	movslq	0x18(%rsp), %rcx
     3bc:      	shlq	$0x4, %rcx
     3c0:      	addq	%rax, %rcx
     3c3:      	addq	$0x80, %rcx
     3ca:      	leaq	0x28(%rsp), %rdi
     3cf:      	movl	$0x10, %edx
     3d4:      	movl	$0x4, %eax
     3d9:      	movq	0x8(%rsp), %rcx
     3de:      	movslq	0x18(%rsp), %rdx
     3e3:      	shlq	$0x4, %rdx
     3e7:      	addq	%rcx, %rdx
     3ea:      	addq	$0x80, %rdx
     3f1:      	movl	$0x10, %esi
     3f6:      	callq	*%rax
     3f8:      	leaq	0x2c(%r14), %rdi
     3fc:      	movl	$0x158, %edx            # imm = 0x158
     401:      	movq	0x30(%rsp), %rcx
     406:      	addq	%rdx, %rcx
     409:      	movl	$0x4, %eax
     40e:      	addq	0x30(%rsp), %rdx
     413:      	movl	$0x4, %esi
     418:      	callq	*%rax
     41a:      	jmp	0x424 <generic_lsm_event+0x424>
     41c:      	movl	$0x0, 0x2c(%r14)
     424:      	leaq	0x30(%r14), %rdi
     428:      	movl	$0x158, %r12d           # imm = 0x158
     42e:      	movq	0x60(%rsp), %rcx
     433:      	addq	%r12, %rcx
     436:      	movl	$0x4, %edx
     43b:      	movl	$0x4, %eax
     440:      	movq	0x60(%rsp), %rdx
     445:      	addq	%r12, %rdx
     448:      	movl	$0x4, %esi
     44d:      	callq	*%rax
     44f:      	leaq	0x34(%r14), %rdi
     453:      	movl	$0x118, %edx            # imm = 0x118
     458:      	movq	0x68(%rsp), %rcx
     45d:      	addq	%rdx, %rcx
     460:      	movl	$0x4, %esi
     465:      	movl	$0x4, %eax
     46a:      	addq	0x68(%rsp), %rdx
     46f:      	movl	$0x4, %esi
     474:      	callq	*%rax
     476:      	leaq	0x38(%r14), %rdi
     47a:      	movl	$0x98, %r13d
     480:      	movq	0x70(%rsp), %rcx
     485:      	addq	%r13, %rcx
     488:      	movl	$0x4, %edx
     48d:      	movl	$0x4, %eax
     492:      	movq	0x70(%rsp), %rdx
     497:      	addq	%r13, %rdx
     49a:      	movl	$0x4, %esi
     49f:      	callq	*%rax
     4a1:      	leaq	0x3c(%r14), %rdi
     4a5:      	movq	0x78(%rsp), %rcx
     4aa:      	addq	%r13, %rcx
     4ad:      	movl	$0x4, %edx
     4b2:      	movl	$0x4, %eax
     4b7:      	addq	0x78(%rsp), %r13
     4bc:      	movl	$0x4, %esi
     4c1:      	movq	%r13, %rdx
     4c4:      	callq	*%rax
     4c6:      	leaq	0x40(%r14), %rdi
     4ca:      	movq	0x80(%rsp), %rcx
     4d2:      	addq	$0x58, %rcx
     4d6:      	movl	$0x4, %edx
     4db:      	movl	$0x4, %eax
     4e0:      	movq	0x80(%rsp), %rdx
     4e8:      	addq	$0x58, %rdx
     4ec:      	movl	$0x4, %esi
     4f1:      	callq	*%rax
     4f3:      	movq	$0x0, 0x28(%rsp)
     4fc:      	movq	$0x0, 0x8(%rsp)
     505:      	addq	$0xd00, %r15            # imm = 0xD00
     50c:      	leaq	0x28(%rsp), %rdi
     511:      	movl	$0x8, %ecx
     516:      	movl	$0x4, %eax
     51b:      	movl	$0x8, %esi
     520:      	movq	%r15, %rdx
     523:      	callq	*%rax
     525:      	movl	$0x90, %edx
     52a:      	movq	0x28(%rsp), %rcx
     52f:      	addq	%rdx, %rcx
     532:      	leaq	0x8(%rsp), %rdi
     537:      	movl	$0x8, %esi
     53c:      	movl	$0x4, %eax
     541:      	addq	0x28(%rsp), %rdx
     546:      	movl	$0x8, %esi
     54b:      	callq	*%rax
     54d:      	leaq	0x44(%r14), %rdi
     551:      	movq	0x8(%rsp), %rcx
     556:      	addq	%r12, %rcx
     559:      	movl	$0x4, %edx
     55e:      	movl	$0x4, %eax
     563:      	addq	0x8(%rsp), %r12
     568:      	movl	$0x4, %esi
     56d:      	movq	%r12, %rdx
     570:      	callq	*%rax
     572:      	leaq	0x48(%r14), %r12
     576:      	leaq	0x40(%rsp), %rdi
     57b:      	movl	$0x8, %ecx
     580:      	movl	$0x4, %eax
     585:      	movl	$0x8, %esi
     58a:      	movq	%r15, %rdx
     58d:      	callq	*%rax
     58f:      	movq	0x40(%rsp), %r15
     594:      	leaq	0x50(%r14), %rdi
     598:      	leaq	0x40(%r15), %rdx
     59c:      	movl	$0x8, %ecx
     5a1:      	movl	$0x4, %eax
     5a6:      	movl	$0x8, %esi
     5ab:      	callq	*%rax
     5ad:      	movq	%r14, %rdi
     5b0:      	addq	$0x58, %rdi
     5b4:      	leaq	0x30(%r15), %rdx
     5b8:      	movl	$0x8, %ecx
     5bd:      	movl	$0x4, %eax
     5c2:      	movl	$0x8, %esi
     5c7:      	callq	*%rax
     5c9:      	addq	$0x38, %r15
     5cd:      	movl	$0x8, %ecx
     5d2:      	movl	$0x4, %eax
     5d7:      	movq	%r12, %rdi
     5da:      	movl	$0x8, %esi
     5df:      	movq	%r15, %rdx
     5e2:      	callq	*%rax
     5e4:      	movb	$0x0, 0x5f08(%r14)
     5ec:      	movb	$0x0, 0x1(%r14)
     5f1:      	movq	$0x0, 0x5ee8(%r14)
     5fc:      	movq	$0x0, 0x5ef0(%r14)
     607:      	movq	(%rip), %rsi            # 0x60e <generic_lsm_event+0x60e>
     60e:      	movl	$0x2, %ecx
     613:      	movl	$0xc, %eax
     618:      	movq	%rbx, %rdi
     61b:      	movl	$0x2, %edx
     620:      	callq	*%rax
     622:      	xorl	%eax, %eax
     624:      	addq	$0x88, %rsp
     62b:      	popq	%rbx
     62c:      	popq	%r12
     62e:      	popq	%r13
     630:      	popq	%r14
     632:      	popq	%r15
     634:      	popq	%rbp
     635:      	retq
     636:      	movq	$-0x1, 0x18(%rsp)
     63f:      	leaq	0x18(%rsp), %rsi
     644:      	movl	$0x1, %eax
     649:      	movq	%r15, %rdi
     64c:      	callq	*%rax
     64e:      	testq	%rax, %rax
     651:      	je	0x622 <generic_lsm_event+0x622>
     653:      	movl	$0x1, 0x14(%rsp)
     65b:      	movq	(%rip), %rdi            # 0x662 <generic_lsm_event+0x662>
     662:      	leaq	0x14(%rsp), %rsi
     667:      	movl	$0x1, %eax
     66c:      	callq	*%rax
     66e:      	testq	%rax, %rax
     671:      	je	0x622 <generic_lsm_event+0x622>
     673:      	movq	%rax, %rdi
     676:      	leaq	0x8(%rsp), %rsi
     67b:      	movl	$0x1, %eax
     680:      	callq	*%rax
     682:      	testq	%rax, %rax
     685:      	movq	%r12, %rax
     688:      	jne	0x622 <generic_lsm_event+0x622>
     68a:      	jmp	0x23b <generic_lsm_event+0x23b>
