
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/otel/go_labels.native.o:	file format elf64-x86-64

Disassembly of section perf_event/go_labels:

0000000000000000 <perf_go_labels>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0xc8, %rsp
      11:      	movq	%rdi, %rbx
      14:      	movl	$0x0, 0x10(%rsp)
      1c:      	movq	(%rip), %rdi            # 0x23 <perf_go_labels+0x23>
      23:      	leaq	0x10(%rsp), %rsi
      28:      	movl	$0x1, %eax
      2d:      	callq	*%rax
      2f:      	testq	%rax, %rax
      32:      	je	0x127 <perf_go_labels+0x127>
      38:      	movq	%rax, %r14
      3b:      	movl	(%rax), %eax
      3d:      	movl	%eax, 0x5c(%rsp)
      41:      	movq	(%rip), %rdi            # 0x48 <perf_go_labels+0x48>
      48:      	leaq	0x5c(%rsp), %rsi
      4d:      	movl	$0x1, %eax
      52:      	callq	*%rax
      54:      	movq	(%rip), %r13            # 0x5b <perf_go_labels+0x5b>
      5b:      	movl	(%r13), %ecx
      5f:      	testq	%rax, %rax
      62:      	je	0x131 <perf_go_labels+0x131>
      68:      	movq	%rax, %r15
      6b:      	testl	%ecx, %ecx
      6d:      	jne	0xa36 <perf_go_labels+0xa36>
      73:      	movl	0x4(%r15), %eax
      77:      	addq	0xf78(%r14), %rax
      7e:      	leaq	0x80(%rsp), %rdi
      86:      	movl	$0x8, %ecx
      8b:      	movl	$0x70, %r8d
      91:      	movl	0x4(%r15), %edx
      95:      	addq	0xf78(%r14), %rdx
      9c:      	movl	$0x8, %esi
      a1:      	callq	*%r8
      a4:      	testq	%rax, %rax
      a7:      	je	0x1c5 <perf_go_labels+0x1c5>
      ad:      	cmpl	$0x0, (%r13)
      b2:      	je	0x20c <perf_go_labels+0x20c>
      b8:      	movabsq	$0x677275633e2d7274, %rax # imm = 0x677275633E2D7274
      c2:      	movq	%rax, 0x30(%rsp)
      c7:      	movabsq	$0x705f6d20726f6620, %rax # imm = 0x705F6D20726F6620
      d1:      	movq	%rax, 0x28(%rsp)
      d6:      	movabsq	$0x65756c6176206461, %rax # imm = 0x65756C6176206461
      e0:      	movq	%rax, 0x20(%rsp)
      e5:      	movabsq	$0x6572206f74206465, %rax # imm = 0x6572206F74206465
      ef:      	movq	%rax, 0x18(%rsp)
      f4:      	movabsq	$0x6c696166203a6c63, %rax # imm = 0x6C696166203A6C63
      fe:      	movq	%rax, 0x10(%rsp)
     103:      	movw	$0xa, 0x38(%rsp)
     10a:      	leaq	0x10(%rsp), %rdi
     10f:      	movl	$0x2a, %eax
     114:      	movl	$0x6, %ecx
     119:      	movl	$0x2a, %esi
     11e:      	xorl	%eax, %eax
     120:      	callq	*%rcx
     122:      	jmp	0x20c <perf_go_labels+0x20c>
     127:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
     12c:      	jmp	0x286 <perf_go_labels+0x286>
     131:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
     136:      	testl	%ecx, %ecx
     138:      	je	0x286 <perf_go_labels+0x286>
     13e:      	movabsq	$0x7972616e6962206f, %rax # imm = 0x7972616E6962206F
     148:      	movq	%rax, 0x38(%rsp)
     14d:      	movabsq	$0x6720612073612064, %rax # imm = 0x6720612073612064
     157:      	movq	%rax, 0x30(%rsp)
     15c:      	movabsq	$0x657a696e676f6365, %rax # imm = 0x657A696E676F6365
     166:      	movq	%rax, 0x28(%rsp)
     16b:      	movabsq	$0x7220746f6e206425, %rax # imm = 0x7220746F6E206425
     175:      	movq	%rax, 0x20(%rsp)
     17a:      	movabsq	$0x202c737465736666, %rax # imm = 0x202C737465736666
     184:      	movq	%rax, 0x18(%rsp)
     189:      	movabsq	$0x6f206f6e203a6c63, %rax # imm = 0x6F206F6E203A6C63
     193:      	movq	%rax, 0x10(%rsp)
     198:      	movw	$0xa, 0x40(%rsp)
     19f:      	leaq	0x10(%rsp), %rdi
     1a4:      	movl	$0x32, %eax
     1a9:      	movl	$0x6, %ecx
     1ae:      	movl	0x5c(%rsp), %edx
     1b2:      	movl	$0x32, %esi
     1b7:      	xorl	%eax, %eax
     1b9:      	callq	*%rcx
     1bb:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
     1c0:      	jmp	0x286 <perf_go_labels+0x286>
     1c5:      	movl	0x8(%r15), %eax
     1c9:      	addq	0x80(%rsp), %rax
     1d1:      	leaq	0xc0(%rsp), %rdi
     1d9:      	movl	$0x8, %ecx
     1de:      	movl	$0x70, %r8d
     1e4:      	movl	0x8(%r15), %edx
     1e8:      	addq	0x80(%rsp), %rdx
     1f0:      	movl	$0x8, %esi
     1f5:      	callq	*%r8
     1f8:      	testq	%rax, %rax
     1fb:      	je	0x298 <perf_go_labels+0x298>
     201:      	cmpl	$0x0, (%r13)
     206:      	jne	0xc4b <perf_go_labels+0xc4b>
     20c:      	movl	$0x61, 0x60(%rsp)
     214:      	movq	(%rip), %rdi            # 0x21b <perf_go_labels+0x21b>
     21b:      	leaq	0x60(%rsp), %rsi
     220:      	movl	$0x1, %eax
     225:      	callq	*%rax
     227:      	testq	%rax, %rax
     22a:      	je	0x231 <perf_go_labels+0x231>
     22c:      	incq	(%rax)
     22f:      	jmp	0x23c <perf_go_labels+0x23c>
     231:      	cmpl	$0x0, (%r13)
     236:      	jne	0xbd0 <perf_go_labels+0xbd0>
     23c:      	movl	$0x80, %eax
     241:      	subl	0x2c0(%r14), %eax
     248:      	shlq	$0x3, %rax
     24c:      	leaq	(%rax,%rax,2), %rax
     250:      	movl	$0xed0, %r8d            # imm = 0xED0
     256:      	subq	%rax, %r8
     259:      	xorl	%eax, %eax
     25b:      	cmpq	$0xed0, %r8             # imm = 0xED0
     262:      	ja	0x286 <perf_go_labels+0x286>
     264:      	movq	(%rip), %rsi            # 0x26b <perf_go_labels+0x26b>
     26b:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
     270:      	movl	$0x19, %r9d
     276:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     27b:      	movq	%rbx, %rdi
     27e:      	movq	%r14, %rcx
     281:      	callq	*%r9
     284:      	xorl	%eax, %eax
     286:      	addq	$0xc8, %rsp
     28d:      	popq	%rbx
     28e:      	popq	%r12
     290:      	popq	%r13
     292:      	popq	%r14
     294:      	popq	%r15
     296:      	popq	%rbp
     297:      	retq
     298:      	cmpl	$0x0, 0x14(%r15)
     29d:      	movq	0xc0(%rsp), %r12
     2a5:      	leaq	0x60(%rsp), %rdi
     2aa:      	je	0x356 <perf_go_labels+0x356>
     2b0:      	movl	$0x8, %eax
     2b5:      	movl	$0x70, %ecx
     2ba:      	movl	$0x8, %esi
     2bf:      	movq	%r12, %rdx
     2c2:      	callq	*%rcx
     2c4:      	testq	%rax, %rax
     2c7:      	je	0x3f9 <perf_go_labels+0x3f9>
     2cd:      	cmpl	$0x0, (%r13)
     2d2:      	je	0x20c <perf_go_labels+0x20c>
     2d8:      	movabsq	$0x786c252820727470, %rax # imm = 0x786C252820727470
     2e2:      	movq	%rax, 0x38(%rsp)
     2e7:      	movabsq	$0x5f70616d5f736c65, %rax # imm = 0x5F70616D5F736C65
     2f1:      	movq	%rax, 0x30(%rsp)
     2f6:      	movabsq	$0x62616c20726f6620, %rax # imm = 0x62616C20726F6620
     300:      	movq	%rax, 0x28(%rsp)
     305:      	movabsq	$0x65756c6176206461, %rax # imm = 0x65756C6176206461
     30f:      	movq	%rax, 0x20(%rsp)
     314:      	movabsq	$0x6572206f74206465, %rax # imm = 0x6572206F74206465
     31e:      	movq	%rax, 0x18(%rsp)
     323:      	movabsq	$0x6c696166203a6c63, %rax # imm = 0x6C696166203A6C63
     32d:      	movq	%rax, 0x10(%rsp)
     332:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
     33a:      	leaq	0x10(%rsp), %rdi
     33f:      	movl	$0x33, %eax
     344:      	movl	$0x6, %ecx
     349:      	movl	$0x33, %esi
     34e:      	movq	%r12, %rdx
     351:      	jmp	0x8ba <perf_go_labels+0x8ba>
     356:      	movl	$0x18, %eax
     35b:      	movl	$0x70, %ecx
     360:      	movl	$0x18, %esi
     365:      	movq	%r12, %rdx
     368:      	callq	*%rcx
     36a:      	testq	%rax, %rax
     36d:      	je	0x4b2 <perf_go_labels+0x4b2>
     373:      	cmpl	$0x0, (%r13)
     378:      	je	0x20c <perf_go_labels+0x20c>
     37e:      	movabsq	$0xa29786c25282065, %rax # imm = 0xA29786C25282065
     388:      	movq	%rax, 0x38(%rsp)
     38d:      	movabsq	$0x63696c7320736c65, %rax # imm = 0x63696C7320736C65
     397:      	movq	%rax, 0x30(%rsp)
     39c:      	movabsq	$0x62616c20726f6620, %rax # imm = 0x62616C20726F6620
     3a6:      	movq	%rax, 0x28(%rsp)
     3ab:      	movabsq	$0x65756c6176206461, %rax # imm = 0x65756C6176206461
     3b5:      	movq	%rax, 0x20(%rsp)
     3ba:      	movabsq	$0x6572206f74206465, %rax # imm = 0x6572206F74206465
     3c4:      	movq	%rax, 0x18(%rsp)
     3c9:      	movabsq	$0x6c696166203a6c63, %rax # imm = 0x6C696166203A6C63
     3d3:      	movq	%rax, 0x10(%rsp)
     3d8:      	movb	$0x0, 0x40(%rsp)
     3dd:      	leaq	0x10(%rsp), %rdi
     3e2:      	movl	$0x31, %eax
     3e7:      	movl	$0x6, %ecx
     3ec:      	movl	$0x31, %esi
     3f1:      	movq	%r12, %rdx
     3f4:      	jmp	0x8ba <perf_go_labels+0x8ba>
     3f9:      	movq	$0x0, 0x90(%rsp)
     405:      	movl	0xc(%r15), %eax
     409:      	addq	0x60(%rsp), %rax
     40e:      	leaq	0x90(%rsp), %rdi
     416:      	movl	$0x8, %ecx
     41b:      	movl	$0x70, %r8d
     421:      	movl	0xc(%r15), %edx
     425:      	addq	0x60(%rsp), %rdx
     42a:      	movl	$0x8, %esi
     42f:      	callq	*%r8
     432:      	testq	%rax, %rax
     435:      	je	0x577 <perf_go_labels+0x577>
     43b:      	cmpl	$0x0, (%r13)
     440:      	je	0x20c <perf_go_labels+0x20c>
     446:      	movabsq	$0x6e756f635f736c65, %rax # imm = 0x6E756F635F736C65
     450:      	movq	%rax, 0x30(%rsp)
     455:      	movabsq	$0x62616c20726f6620, %rax # imm = 0x62616C20726F6620
     45f:      	movq	%rax, 0x28(%rsp)
     464:      	movabsq	$0x65756c6176206461, %rax # imm = 0x65756C6176206461
     46e:      	movq	%rax, 0x20(%rsp)
     473:      	movabsq	$0x6572206f74206465, %rax # imm = 0x6572206F74206465
     47d:      	movq	%rax, 0x18(%rsp)
     482:      	movabsq	$0x6c696166203a6c63, %rax # imm = 0x6C696166203A6C63
     48c:      	movq	%rax, 0x10(%rsp)
     491:      	movl	$0xa746e, 0x37(%rsp)    # imm = 0xA746E
     499:      	leaq	0x10(%rsp), %rdi
     49e:      	movl	$0x2b, %eax
     4a3:      	movl	$0x6, %ecx
     4a8:      	movl	$0x2b, %esi
     4ad:      	jmp	0x11e <perf_go_labels+0x11e>
     4b2:      	movq	0x60(%rsp), %rax
     4b7:      	movq	0x68(%rsp), %rcx
     4bc:      	cmpq	$0xa, %rcx
     4c0:      	movl	$0xa, %r15d
     4c6:      	cmovbq	%rcx, %r15
     4ca:      	leaq	0xf80(%r14), %rdi
     4d1:      	movl	%r15d, %esi
     4d4:      	shll	$0x5, %esi
     4d7:      	movl	$0x70, %ecx
     4dc:      	movq	0x60(%rsp), %rdx
     4e1:      	callq	*%rcx
     4e3:      	testq	%rax, %rax
     4e6:      	je	0x630 <perf_go_labels+0x630>
     4ec:      	cmpl	$0x0, (%r13)
     4f1:      	je	0x20c <perf_go_labels+0x20c>
     4f7:      	movabsq	$0x6c2528206563696c, %rax # imm = 0x6C2528206563696C
     501:      	movq	%rax, 0x38(%rsp)
     506:      	movabsq	$0x7320736c6562616c, %rax # imm = 0x7320736C6562616C
     510:      	movq	%rax, 0x30(%rsp)
     515:      	movabsq	$0x206d6f7266207367, %rax # imm = 0x206D6F7266207367
     51f:      	movq	%rax, 0x28(%rsp)
     524:      	movabsq	$0x6e69727473206461, %rax # imm = 0x6E69727473206461
     52e:      	movq	%rax, 0x20(%rsp)
     533:      	movabsq	$0x6572206f74206465, %rax # imm = 0x6572206F74206465
     53d:      	movq	%rax, 0x18(%rsp)
     542:      	movabsq	$0x6c696166203a6c63, %rax # imm = 0x6C696166203A6C63
     54c:      	movq	%rax, 0x10(%rsp)
     551:      	movl	$0xa2978, 0x40(%rsp)    # imm = 0xA2978
     559:      	leaq	0x10(%rsp), %rdi
     55e:      	movl	$0x34, %eax
     563:      	movl	$0x6, %ecx
     568:      	movq	0x60(%rsp), %rdx
     56d:      	movl	$0x34, %esi
     572:      	jmp	0x8ba <perf_go_labels+0x8ba>
     577:      	cmpq	$0x0, 0x90(%rsp)
     580:      	je	0x6d3 <perf_go_labels+0x6d3>
     586:      	movl	0x10(%r15), %eax
     58a:      	addq	0x60(%rsp), %rax
     58f:      	leaq	0xf(%rsp), %rdi
     594:      	movl	$0x1, %ecx
     599:      	movl	$0x70, %r8d
     59f:      	movl	0x10(%r15), %edx
     5a3:      	addq	0x60(%rsp), %rdx
     5a8:      	movl	$0x1, %esi
     5ad:      	callq	*%r8
     5b0:      	testq	%rax, %rax
     5b3:      	je	0x715 <perf_go_labels+0x715>
     5b9:      	cmpl	$0x0, (%r13)
     5be:      	je	0x20c <perf_go_labels+0x20c>
     5c4:      	movabsq	$0x6e756f635f74656b, %rax # imm = 0x6E756F635F74656B
     5ce:      	movq	%rax, 0x30(%rsp)
     5d3:      	movabsq	$0x63756220726f6620, %rax # imm = 0x63756220726F6620
     5dd:      	movq	%rax, 0x28(%rsp)
     5e2:      	movabsq	$0x65756c6176206461, %rax # imm = 0x65756C6176206461
     5ec:      	movq	%rax, 0x20(%rsp)
     5f1:      	movabsq	$0x6572206f74206465, %rax # imm = 0x6572206F74206465
     5fb:      	movq	%rax, 0x18(%rsp)
     600:      	movabsq	$0x6c696166203a6c63, %rax # imm = 0x6C696166203A6C63
     60a:      	movq	%rax, 0x10(%rsp)
     60f:      	movl	$0xa746e, 0x37(%rsp)    # imm = 0xA746E
     617:      	leaq	0x10(%rsp), %rdi
     61c:      	movl	$0x2b, %eax
     621:      	movl	$0x6, %ecx
     626:      	movl	$0x2b, %esi
     62b:      	jmp	0x11e <perf_go_labels+0x11e>
     630:      	movq	%r15, 0x78(%rsp)
     635:      	movl	$0xf80, %r15d           # imm = 0xF80
     63b:      	xorl	%ebp, %ebp
     63d:      	xorl	%r12d, %r12d
     640:      	cmpq	%r12, 0x68(%rsp)
     645:      	jbe	0x6c5 <perf_go_labels+0x6c5>
     647:      	leaq	(%r14,%rbp), %rdi
     64b:      	addq	$0x3c, %rdi
     64f:      	movq	(%r14,%r15), %rax
     653:      	movq	0x8(%r14,%r15), %rsi
     658:      	cmpq	$0xf, %rsi
     65c:      	movl	$0xf, %ecx
     661:      	cmovaeq	%rcx, %rsi
     665:      	movl	$0x70, %ecx
     66a:      	movq	(%r14,%r15), %rdx
     66e:      	callq	*%rcx
     670:      	testq	%rax, %rax
     673:      	jne	0x7c2 <perf_go_labels+0x7c2>
     679:      	movq	0x10(%r14,%r15), %rax
     67e:      	movq	0x18(%r14,%r15), %rsi
     683:      	cmpq	$0x2f, %rsi
     687:      	movl	$0x2f, %ecx
     68c:      	cmovaeq	%rcx, %rsi
     690:      	leaq	(%r14,%rbp), %rdi
     694:      	addq	$0x4c, %rdi
     698:      	movl	$0x70, %ecx
     69d:      	movq	0x10(%r14,%r15), %rdx
     6a2:      	callq	*%rcx
     6a4:      	testq	%rax, %rax
     6a7:      	jne	0x83c <perf_go_labels+0x83c>
     6ad:      	incq	%r12
     6b0:      	addq	$0x40, %rbp
     6b4:      	addq	$0x20, %r15
     6b8:      	cmpq	$0x280, %rbp            # imm = 0x280
     6bf:      	jne	0x640 <perf_go_labels+0x640>
     6c5:      	movq	0x78(%rsp), %rax
     6ca:      	movl	%eax, 0x38(%r14)
     6ce:      	jmp	0x23c <perf_go_labels+0x23c>
     6d3:      	cmpl	$0x0, (%r13)
     6d8:      	je	0x20c <perf_go_labels+0x20c>
     6de:      	movabsq	$0xa736c6562616c, %rax  # imm = 0xA736C6562616C
     6e8:      	movq	%rax, 0x17(%rsp)
     6ed:      	movabsq	$0x6c206f6e203a6c63, %rax # imm = 0x6C206F6E203A6C63
     6f7:      	movq	%rax, 0x10(%rsp)
     6fc:      	leaq	0x10(%rsp), %rdi
     701:      	movl	$0xf, %eax
     706:      	movl	$0x6, %ecx
     70b:      	movl	$0xf, %esi
     710:      	jmp	0x11e <perf_go_labels+0x11e>
     715:      	movl	0x14(%r15), %eax
     719:      	addq	0x60(%rsp), %rax
     71e:      	leaq	0x88(%rsp), %rdi
     726:      	movl	$0x8, %ecx
     72b:      	movl	$0x70, %r8d
     731:      	movl	0x14(%r15), %edx
     735:      	addq	0x60(%rsp), %rdx
     73a:      	movl	$0x8, %esi
     73f:      	callq	*%r8
     742:      	testq	%rax, %rax
     745:      	je	0x8c3 <perf_go_labels+0x8c3>
     74b:      	cmpl	$0x0, (%r13)
     750:      	je	0x20c <perf_go_labels+0x20c>
     756:      	movabsq	$0x656b6375625f6c65, %rax # imm = 0x656B6375625F6C65
     760:      	movq	%rax, 0x30(%rsp)
     765:      	movabsq	$0x62616c20726f6620, %rax # imm = 0x62616C20726F6620
     76f:      	movq	%rax, 0x28(%rsp)
     774:      	movabsq	$0x65756c6176206461, %rax # imm = 0x65756C6176206461
     77e:      	movq	%rax, 0x20(%rsp)
     783:      	movabsq	$0x6572206f74206465, %rax # imm = 0x6572206F74206465
     78d:      	movq	%rax, 0x18(%rsp)
     792:      	movabsq	$0x6c696166203a6c63, %rax # imm = 0x6C696166203A6C63
     79c:      	movq	%rax, 0x10(%rsp)
     7a1:      	movl	$0xa7374, 0x38(%rsp)    # imm = 0xA7374
     7a9:      	leaq	0x10(%rsp), %rdi
     7ae:      	movl	$0x2c, %eax
     7b3:      	movl	$0x6, %ecx
     7b8:      	movl	$0x2c, %esi
     7bd:      	jmp	0x11e <perf_go_labels+0x11e>
     7c2:      	cmpl	$0x0, (%r13)
     7c7:      	je	0x20c <perf_go_labels+0x20c>
     7cd:      	movabsq	$0xa29786c252820, %rax  # imm = 0xA29786C252820
     7d7:      	movq	%rax, 0x37(%rsp)
     7dc:      	movabsq	$0x206c6562616c206d, %rax # imm = 0x206C6562616C206D
     7e6:      	movq	%rax, 0x30(%rsp)
     7eb:      	movabsq	$0x6f7473756320726f, %rax # imm = 0x6F7473756320726F
     7f5:      	movq	%rax, 0x28(%rsp)
     7fa:      	movabsq	$0x662079656b206461, %rax # imm = 0x662079656B206461
     804:      	movq	%rax, 0x20(%rsp)
     809:      	movabsq	$0x6572206f74206465, %rax # imm = 0x6572206F74206465
     813:      	movq	%rax, 0x18(%rsp)
     818:      	movabsq	$0x6c696166203a6c63, %rax # imm = 0x6C696166203A6C63
     822:      	movq	%rax, 0x10(%rsp)
     827:      	leaq	0x10(%rsp), %rdi
     82c:      	movl	$0x2f, %eax
     831:      	movl	$0x6, %ecx
     836:      	movq	(%r14,%r15), %rdx
     83a:      	jmp	0x8b5 <perf_go_labels+0x8b5>
     83c:      	cmpl	$0x0, (%r13)
     841:      	je	0x20c <perf_go_labels+0x20c>
     847:      	movabsq	$0xa29786c252820, %rax  # imm = 0xA29786C252820
     851:      	movq	%rax, 0x37(%rsp)
     856:      	movabsq	$0x206c6562616c206d, %rax # imm = 0x206C6562616C206D
     860:      	movq	%rax, 0x30(%rsp)
     865:      	movabsq	$0x6f7473756320726f, %rax # imm = 0x6F7473756320726F
     86f:      	movq	%rax, 0x28(%rsp)
     874:      	movabsq	$0x662079656b206461, %rax # imm = 0x662079656B206461
     87e:      	movq	%rax, 0x20(%rsp)
     883:      	movabsq	$0x6572206f74206465, %rax # imm = 0x6572206F74206465
     88d:      	movq	%rax, 0x18(%rsp)
     892:      	movabsq	$0x6c696166203a6c63, %rax # imm = 0x6C696166203A6C63
     89c:      	movq	%rax, 0x10(%rsp)
     8a1:      	leaq	0x10(%rsp), %rdi
     8a6:      	movl	$0x2f, %eax
     8ab:      	movl	$0x6, %ecx
     8b0:      	movq	0x10(%r14,%r15), %rdx
     8b5:      	movl	$0x2f, %esi
     8ba:      	xorl	%eax, %eax
     8bc:      	callq	*%rcx
     8be:      	jmp	0x20c <perf_go_labels+0x20c>
     8c3:      	movzbl	0xf(%rsp), %eax
     8c8:      	movl	$0x1, %ecx
     8cd:      	shlxq	%rax, %rcx, %rax
     8d2:      	movzbl	%al, %eax
     8d5:      	leaq	0xf80(%r14), %r15
     8dc:      	xorl	%ecx, %ecx
     8de:      	movl	$0x110, %esi            # imm = 0x110
     8e3:      	movq	%rax, 0xa0(%rsp)
     8eb:      	movq	%r15, 0x98(%rsp)
     8f3:      	cmpq	%rax, %rcx
     8f6:      	je	0x23c <perf_go_labels+0x23c>
     8fc:      	movq	%rcx, 0xa8(%rsp)
     904:      	imulq	$0x110, %rcx, %rdx      # imm = 0x110
     90b:      	movq	0x88(%rsp), %rax
     913:      	addq	%rdx, %rax
     916:      	movl	$0x70, %ecx
     91b:      	addq	0x88(%rsp), %rdx
     923:      	movq	%r15, %rdi
     926:      	movl	$0x110, %esi            # imm = 0x110
     92b:      	callq	*%rcx
     92d:      	testq	%rax, %rax
     930:      	jne	0x20c <perf_go_labels+0x20c>
     936:      	movl	0x38(%r14), %eax
     93a:      	movq	$-0x80, %r12
     941:      	jmp	0x950 <perf_go_labels+0x950>
     943:      	incq	%r15
     946:      	addq	$0x10, %r12
     94a:      	je	0xa07 <perf_go_labels+0xa07>
     950:      	cmpl	$0xa, %eax
     953:      	jae	0x23c <perf_go_labels+0x23c>
     959:      	cmpb	$0x0, (%r15)
     95d:      	je	0x943 <perf_go_labels+0x943>
     95f:      	movq	0x1008(%r14,%r12), %rcx
     967:      	testq	%rcx, %rcx
     96a:      	je	0x943 <perf_go_labels+0x943>
     96c:      	movq	%r15, 0xb8(%rsp)
     974:      	movl	%eax, %r15d
     977:      	movq	0x1088(%r14,%r12), %rax
     97f:      	movq	%rax, 0x78(%rsp)
     984:      	movl	0x1090(%r14,%r12), %ebp
     98c:      	shlq	$0x6, %r15
     990:      	leaq	(%r14,%r15), %rdi
     994:      	addq	$0x3c, %rdi
     998:      	movl	0x1010(%r14,%r12), %esi
     9a0:      	cmpl	$0xf, %esi
     9a3:      	movl	$0xf, %eax
     9a8:      	cmovael	%eax, %esi
     9ab:      	movl	$0x70, %eax
     9b0:      	movq	%rcx, %rdx
     9b3:      	movq	%rcx, 0xb0(%rsp)
     9bb:      	callq	*%rax
     9bd:      	testq	%rax, %rax
     9c0:      	jne	0xad8 <perf_go_labels+0xad8>
     9c6:      	leaq	(%r14,%r15), %rdi
     9ca:      	addq	$0x4c, %rdi
     9ce:      	cmpl	$0x2f, %ebp
     9d1:      	movl	$0x2f, %eax
     9d6:      	cmovael	%eax, %ebp
     9d9:      	movl	$0x70, %eax
     9de:      	movq	0x78(%rsp), %rdx
     9e3:      	movl	%ebp, %esi
     9e5:      	callq	*%rax
     9e7:      	testq	%rax, %rax
     9ea:      	jne	0xb59 <perf_go_labels+0xb59>
     9f0:      	movl	0x38(%r14), %eax
     9f4:      	incl	%eax
     9f6:      	movl	%eax, 0x38(%r14)
     9fa:      	movq	0xb8(%rsp), %r15
     a02:      	jmp	0x943 <perf_go_labels+0x943>
     a07:      	movq	0xa8(%rsp), %rcx
     a0f:      	incq	%rcx
     a12:      	cmpq	$0x10, %rcx
     a16:      	movq	0xa0(%rsp), %rax
     a1e:      	movq	0x98(%rsp), %r15
     a26:      	movl	$0x110, %esi            # imm = 0x110
     a2b:      	jne	0x8f3 <perf_go_labels+0x8f3>
     a31:      	jmp	0x23c <perf_go_labels+0x23c>
     a36:      	movabsq	$0xa786c25203a72, %rax  # imm = 0xA786C25203A72
     a40:      	movq	%rax, 0x48(%rsp)
     a45:      	movabsq	$0x74705f6d203a7972, %rax # imm = 0x74705F6D203A7972
     a4f:      	movq	%rax, 0x40(%rsp)
     a54:      	movabsq	$0x616e6962206f6720, %rax # imm = 0x616E6962206F6720
     a5e:      	movq	%rax, 0x38(%rsp)
     a63:      	movabsq	$0x612073612064657a, %rax # imm = 0x612073612064657A
     a6d:      	movq	%rax, 0x30(%rsp)
     a72:      	movabsq	$0x696e676f63657220, %rax # imm = 0x696E676F63657220
     a7c:      	movq	%rax, 0x28(%rsp)
     a81:      	movabsq	$0x6425202c646e756f, %rax # imm = 0x6425202C646E756F
     a8b:      	movq	%rax, 0x20(%rsp)
     a90:      	movabsq	$0x6620737465736666, %rax # imm = 0x6620737465736666
     a9a:      	movq	%rax, 0x18(%rsp)
     a9f:      	movabsq	$0x6f206f67203a6c63, %rax # imm = 0x6F206F67203A6C63
     aa9:      	movq	%rax, 0x10(%rsp)
     aae:      	leaq	0x10(%rsp), %rdi
     ab3:      	movl	$0x40, %eax
     ab8:      	movl	$0x6, %r8d
     abe:      	movl	0x5c(%rsp), %edx
     ac2:      	movq	0xf78(%r14), %rcx
     ac9:      	movl	$0x40, %esi
     ace:      	xorl	%eax, %eax
     ad0:      	callq	*%r8
     ad3:      	jmp	0x73 <perf_go_labels+0x73>
     ad8:      	movq	0xb0(%rsp), %rdx
     ae0:      	cmpl	$0x0, (%r13)
     ae5:      	je	0x20c <perf_go_labels+0x20c>
     aeb:      	movabsq	$0xa29786c252820, %rax  # imm = 0xA29786C252820
     af5:      	movq	%rax, 0x37(%rsp)
     afa:      	movabsq	$0x206c6562616c206d, %rax # imm = 0x206C6562616C206D
     b04:      	movq	%rax, 0x30(%rsp)
     b09:      	movabsq	$0x6f7473756320726f, %rax # imm = 0x6F7473756320726F
     b13:      	movq	%rax, 0x28(%rsp)
     b18:      	movabsq	$0x662079656b206461, %rax # imm = 0x662079656B206461
     b22:      	movq	%rax, 0x20(%rsp)
     b27:      	movabsq	$0x6572206f74206465, %rax # imm = 0x6572206F74206465
     b31:      	movq	%rax, 0x18(%rsp)
     b36:      	movabsq	$0x6c696166203a6c63, %rax # imm = 0x6C696166203A6C63
     b40:      	movq	%rax, 0x10(%rsp)
     b45:      	leaq	0x10(%rsp), %rdi
     b4a:      	movl	$0x2f, %eax
     b4f:      	movl	$0x6, %ecx
     b54:      	jmp	0x8b5 <perf_go_labels+0x8b5>
     b59:      	cmpl	$0x0, (%r13)
     b5e:      	je	0x20c <perf_go_labels+0x20c>
     b64:      	movabsq	$0x6562616c206d6f74, %rax # imm = 0x6562616C206D6F74
     b6e:      	movq	%rax, 0x30(%rsp)
     b73:      	movabsq	$0x73756320726f6620, %rax # imm = 0x73756320726F6620
     b7d:      	movq	%rax, 0x28(%rsp)
     b82:      	movabsq	$0x65756c6176206461, %rax # imm = 0x65756C6176206461
     b8c:      	movq	%rax, 0x20(%rsp)
     b91:      	movabsq	$0x6572206f74206465, %rax # imm = 0x6572206F74206465
     b9b:      	movq	%rax, 0x18(%rsp)
     ba0:      	movabsq	$0x6c696166203a6c63, %rax # imm = 0x6C696166203A6C63
     baa:      	movq	%rax, 0x10(%rsp)
     baf:      	movl	$0xa6c65, 0x37(%rsp)    # imm = 0xA6C65
     bb7:      	leaq	0x10(%rsp), %rdi
     bbc:      	movl	$0x2b, %eax
     bc1:      	movl	$0x6, %ecx
     bc6:      	movl	$0x2b, %esi
     bcb:      	jmp	0x11e <perf_go_labels+0x11e>
     bd0:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     bda:      	movq	%rax, 0x36(%rsp)
     bdf:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     be9:      	movq	%rax, 0x30(%rsp)
     bee:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     bf8:      	movq	%rax, 0x28(%rsp)
     bfd:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     c07:      	movq	%rax, 0x20(%rsp)
     c0c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     c16:      	movq	%rax, 0x18(%rsp)
     c1b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     c25:      	movq	%rax, 0x10(%rsp)
     c2a:      	leaq	0x10(%rsp), %rdi
     c2f:      	movl	$0x2e, %eax
     c34:      	movl	$0x6, %ecx
     c39:      	movl	0x60(%rsp), %edx
     c3d:      	movl	$0x2e, %esi
     c42:      	xorl	%eax, %eax
     c44:      	callq	*%rcx
     c46:      	jmp	0x23c <perf_go_labels+0x23c>
     c4b:      	movabsq	$0xa29786c253e2d, %rax  # imm = 0xA29786C253E2D
     c55:      	movq	%rax, 0x3e(%rsp)
     c5a:      	movabsq	$0x3e2d786c25282073, %rax # imm = 0x3E2D786C25282073
     c64:      	movq	%rax, 0x38(%rsp)
     c69:      	movabsq	$0x6c6562616c3e2d67, %rax # imm = 0x6C6562616C3E2D67
     c73:      	movq	%rax, 0x30(%rsp)
     c78:      	movabsq	$0x72756320726f6620, %rax # imm = 0x72756320726F6620
     c82:      	movq	%rax, 0x28(%rsp)
     c87:      	movabsq	$0x65756c6176206461, %rax # imm = 0x65756C6176206461
     c91:      	movq	%rax, 0x20(%rsp)
     c96:      	movabsq	$0x6572206f74206465, %rax # imm = 0x6572206F74206465
     ca0:      	movq	%rax, 0x18(%rsp)
     ca5:      	movabsq	$0x6c696166203a6c63, %rax # imm = 0x6C696166203A6C63
     caf:      	movq	%rax, 0x10(%rsp)
     cb4:      	leaq	0x10(%rsp), %rdi
     cb9:      	movl	$0x36, %eax
     cbe:      	movl	$0x6, %r8d
     cc4:      	movq	0x80(%rsp), %rdx
     ccc:      	movl	0x8(%r15), %ecx
     cd0:      	movl	$0x36, %esi
     cd5:      	xorl	%eax, %eax
     cd7:      	callq	*%r8
     cda:      	jmp	0x20c <perf_go_labels+0x20c>

Disassembly of section kprobe/go_labels:

0000000000000000 <kprobe_go_labels>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0xc8, %rsp
      11:      	movq	%rdi, %rbx
      14:      	movl	$0x0, 0x10(%rsp)
      1c:      	movq	(%rip), %rdi            # 0x23 <kprobe_go_labels+0x23>
      23:      	leaq	0x10(%rsp), %rsi
      28:      	movl	$0x1, %eax
      2d:      	callq	*%rax
      2f:      	testq	%rax, %rax
      32:      	je	0x127 <kprobe_go_labels+0x127>
      38:      	movq	%rax, %r14
      3b:      	movl	(%rax), %eax
      3d:      	movl	%eax, 0x5c(%rsp)
      41:      	movq	(%rip), %rdi            # 0x48 <kprobe_go_labels+0x48>
      48:      	leaq	0x5c(%rsp), %rsi
      4d:      	movl	$0x1, %eax
      52:      	callq	*%rax
      54:      	movq	(%rip), %r13            # 0x5b <kprobe_go_labels+0x5b>
      5b:      	movl	(%r13), %ecx
      5f:      	testq	%rax, %rax
      62:      	je	0x131 <kprobe_go_labels+0x131>
      68:      	movq	%rax, %r15
      6b:      	testl	%ecx, %ecx
      6d:      	jne	0xa36 <kprobe_go_labels+0xa36>
      73:      	movl	0x4(%r15), %eax
      77:      	addq	0xf78(%r14), %rax
      7e:      	leaq	0x80(%rsp), %rdi
      86:      	movl	$0x8, %ecx
      8b:      	movl	$0x70, %r8d
      91:      	movl	0x4(%r15), %edx
      95:      	addq	0xf78(%r14), %rdx
      9c:      	movl	$0x8, %esi
      a1:      	callq	*%r8
      a4:      	testq	%rax, %rax
      a7:      	je	0x1c5 <kprobe_go_labels+0x1c5>
      ad:      	cmpl	$0x0, (%r13)
      b2:      	je	0x20c <kprobe_go_labels+0x20c>
      b8:      	movabsq	$0x677275633e2d7274, %rax # imm = 0x677275633E2D7274
      c2:      	movq	%rax, 0x30(%rsp)
      c7:      	movabsq	$0x705f6d20726f6620, %rax # imm = 0x705F6D20726F6620
      d1:      	movq	%rax, 0x28(%rsp)
      d6:      	movabsq	$0x65756c6176206461, %rax # imm = 0x65756C6176206461
      e0:      	movq	%rax, 0x20(%rsp)
      e5:      	movabsq	$0x6572206f74206465, %rax # imm = 0x6572206F74206465
      ef:      	movq	%rax, 0x18(%rsp)
      f4:      	movabsq	$0x6c696166203a6c63, %rax # imm = 0x6C696166203A6C63
      fe:      	movq	%rax, 0x10(%rsp)
     103:      	movw	$0xa, 0x38(%rsp)
     10a:      	leaq	0x10(%rsp), %rdi
     10f:      	movl	$0x2a, %eax
     114:      	movl	$0x6, %ecx
     119:      	movl	$0x2a, %esi
     11e:      	xorl	%eax, %eax
     120:      	callq	*%rcx
     122:      	jmp	0x20c <kprobe_go_labels+0x20c>
     127:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
     12c:      	jmp	0x286 <kprobe_go_labels+0x286>
     131:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
     136:      	testl	%ecx, %ecx
     138:      	je	0x286 <kprobe_go_labels+0x286>
     13e:      	movabsq	$0x7972616e6962206f, %rax # imm = 0x7972616E6962206F
     148:      	movq	%rax, 0x38(%rsp)
     14d:      	movabsq	$0x6720612073612064, %rax # imm = 0x6720612073612064
     157:      	movq	%rax, 0x30(%rsp)
     15c:      	movabsq	$0x657a696e676f6365, %rax # imm = 0x657A696E676F6365
     166:      	movq	%rax, 0x28(%rsp)
     16b:      	movabsq	$0x7220746f6e206425, %rax # imm = 0x7220746F6E206425
     175:      	movq	%rax, 0x20(%rsp)
     17a:      	movabsq	$0x202c737465736666, %rax # imm = 0x202C737465736666
     184:      	movq	%rax, 0x18(%rsp)
     189:      	movabsq	$0x6f206f6e203a6c63, %rax # imm = 0x6F206F6E203A6C63
     193:      	movq	%rax, 0x10(%rsp)
     198:      	movw	$0xa, 0x40(%rsp)
     19f:      	leaq	0x10(%rsp), %rdi
     1a4:      	movl	$0x32, %eax
     1a9:      	movl	$0x6, %ecx
     1ae:      	movl	0x5c(%rsp), %edx
     1b2:      	movl	$0x32, %esi
     1b7:      	xorl	%eax, %eax
     1b9:      	callq	*%rcx
     1bb:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
     1c0:      	jmp	0x286 <kprobe_go_labels+0x286>
     1c5:      	movl	0x8(%r15), %eax
     1c9:      	addq	0x80(%rsp), %rax
     1d1:      	leaq	0xc0(%rsp), %rdi
     1d9:      	movl	$0x8, %ecx
     1de:      	movl	$0x70, %r8d
     1e4:      	movl	0x8(%r15), %edx
     1e8:      	addq	0x80(%rsp), %rdx
     1f0:      	movl	$0x8, %esi
     1f5:      	callq	*%r8
     1f8:      	testq	%rax, %rax
     1fb:      	je	0x298 <kprobe_go_labels+0x298>
     201:      	cmpl	$0x0, (%r13)
     206:      	jne	0xc4b <kprobe_go_labels+0xc4b>
     20c:      	movl	$0x61, 0x60(%rsp)
     214:      	movq	(%rip), %rdi            # 0x21b <kprobe_go_labels+0x21b>
     21b:      	leaq	0x60(%rsp), %rsi
     220:      	movl	$0x1, %eax
     225:      	callq	*%rax
     227:      	testq	%rax, %rax
     22a:      	je	0x231 <kprobe_go_labels+0x231>
     22c:      	incq	(%rax)
     22f:      	jmp	0x23c <kprobe_go_labels+0x23c>
     231:      	cmpl	$0x0, (%r13)
     236:      	jne	0xbd0 <kprobe_go_labels+0xbd0>
     23c:      	movl	$0x80, %eax
     241:      	subl	0x2c0(%r14), %eax
     248:      	shlq	$0x3, %rax
     24c:      	leaq	(%rax,%rax,2), %rax
     250:      	movl	$0xed0, %r8d            # imm = 0xED0
     256:      	subq	%rax, %r8
     259:      	xorl	%eax, %eax
     25b:      	cmpq	$0xed0, %r8             # imm = 0xED0
     262:      	ja	0x286 <kprobe_go_labels+0x286>
     264:      	movq	(%rip), %rsi            # 0x26b <kprobe_go_labels+0x26b>
     26b:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
     270:      	movl	$0x19, %r9d
     276:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     27b:      	movq	%rbx, %rdi
     27e:      	movq	%r14, %rcx
     281:      	callq	*%r9
     284:      	xorl	%eax, %eax
     286:      	addq	$0xc8, %rsp
     28d:      	popq	%rbx
     28e:      	popq	%r12
     290:      	popq	%r13
     292:      	popq	%r14
     294:      	popq	%r15
     296:      	popq	%rbp
     297:      	retq
     298:      	cmpl	$0x0, 0x14(%r15)
     29d:      	movq	0xc0(%rsp), %r12
     2a5:      	leaq	0x60(%rsp), %rdi
     2aa:      	je	0x356 <kprobe_go_labels+0x356>
     2b0:      	movl	$0x8, %eax
     2b5:      	movl	$0x70, %ecx
     2ba:      	movl	$0x8, %esi
     2bf:      	movq	%r12, %rdx
     2c2:      	callq	*%rcx
     2c4:      	testq	%rax, %rax
     2c7:      	je	0x3f9 <kprobe_go_labels+0x3f9>
     2cd:      	cmpl	$0x0, (%r13)
     2d2:      	je	0x20c <kprobe_go_labels+0x20c>
     2d8:      	movabsq	$0x786c252820727470, %rax # imm = 0x786C252820727470
     2e2:      	movq	%rax, 0x38(%rsp)
     2e7:      	movabsq	$0x5f70616d5f736c65, %rax # imm = 0x5F70616D5F736C65
     2f1:      	movq	%rax, 0x30(%rsp)
     2f6:      	movabsq	$0x62616c20726f6620, %rax # imm = 0x62616C20726F6620
     300:      	movq	%rax, 0x28(%rsp)
     305:      	movabsq	$0x65756c6176206461, %rax # imm = 0x65756C6176206461
     30f:      	movq	%rax, 0x20(%rsp)
     314:      	movabsq	$0x6572206f74206465, %rax # imm = 0x6572206F74206465
     31e:      	movq	%rax, 0x18(%rsp)
     323:      	movabsq	$0x6c696166203a6c63, %rax # imm = 0x6C696166203A6C63
     32d:      	movq	%rax, 0x10(%rsp)
     332:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
     33a:      	leaq	0x10(%rsp), %rdi
     33f:      	movl	$0x33, %eax
     344:      	movl	$0x6, %ecx
     349:      	movl	$0x33, %esi
     34e:      	movq	%r12, %rdx
     351:      	jmp	0x8ba <kprobe_go_labels+0x8ba>
     356:      	movl	$0x18, %eax
     35b:      	movl	$0x70, %ecx
     360:      	movl	$0x18, %esi
     365:      	movq	%r12, %rdx
     368:      	callq	*%rcx
     36a:      	testq	%rax, %rax
     36d:      	je	0x4b2 <kprobe_go_labels+0x4b2>
     373:      	cmpl	$0x0, (%r13)
     378:      	je	0x20c <kprobe_go_labels+0x20c>
     37e:      	movabsq	$0xa29786c25282065, %rax # imm = 0xA29786C25282065
     388:      	movq	%rax, 0x38(%rsp)
     38d:      	movabsq	$0x63696c7320736c65, %rax # imm = 0x63696C7320736C65
     397:      	movq	%rax, 0x30(%rsp)
     39c:      	movabsq	$0x62616c20726f6620, %rax # imm = 0x62616C20726F6620
     3a6:      	movq	%rax, 0x28(%rsp)
     3ab:      	movabsq	$0x65756c6176206461, %rax # imm = 0x65756C6176206461
     3b5:      	movq	%rax, 0x20(%rsp)
     3ba:      	movabsq	$0x6572206f74206465, %rax # imm = 0x6572206F74206465
     3c4:      	movq	%rax, 0x18(%rsp)
     3c9:      	movabsq	$0x6c696166203a6c63, %rax # imm = 0x6C696166203A6C63
     3d3:      	movq	%rax, 0x10(%rsp)
     3d8:      	movb	$0x0, 0x40(%rsp)
     3dd:      	leaq	0x10(%rsp), %rdi
     3e2:      	movl	$0x31, %eax
     3e7:      	movl	$0x6, %ecx
     3ec:      	movl	$0x31, %esi
     3f1:      	movq	%r12, %rdx
     3f4:      	jmp	0x8ba <kprobe_go_labels+0x8ba>
     3f9:      	movq	$0x0, 0x90(%rsp)
     405:      	movl	0xc(%r15), %eax
     409:      	addq	0x60(%rsp), %rax
     40e:      	leaq	0x90(%rsp), %rdi
     416:      	movl	$0x8, %ecx
     41b:      	movl	$0x70, %r8d
     421:      	movl	0xc(%r15), %edx
     425:      	addq	0x60(%rsp), %rdx
     42a:      	movl	$0x8, %esi
     42f:      	callq	*%r8
     432:      	testq	%rax, %rax
     435:      	je	0x577 <kprobe_go_labels+0x577>
     43b:      	cmpl	$0x0, (%r13)
     440:      	je	0x20c <kprobe_go_labels+0x20c>
     446:      	movabsq	$0x6e756f635f736c65, %rax # imm = 0x6E756F635F736C65
     450:      	movq	%rax, 0x30(%rsp)
     455:      	movabsq	$0x62616c20726f6620, %rax # imm = 0x62616C20726F6620
     45f:      	movq	%rax, 0x28(%rsp)
     464:      	movabsq	$0x65756c6176206461, %rax # imm = 0x65756C6176206461
     46e:      	movq	%rax, 0x20(%rsp)
     473:      	movabsq	$0x6572206f74206465, %rax # imm = 0x6572206F74206465
     47d:      	movq	%rax, 0x18(%rsp)
     482:      	movabsq	$0x6c696166203a6c63, %rax # imm = 0x6C696166203A6C63
     48c:      	movq	%rax, 0x10(%rsp)
     491:      	movl	$0xa746e, 0x37(%rsp)    # imm = 0xA746E
     499:      	leaq	0x10(%rsp), %rdi
     49e:      	movl	$0x2b, %eax
     4a3:      	movl	$0x6, %ecx
     4a8:      	movl	$0x2b, %esi
     4ad:      	jmp	0x11e <kprobe_go_labels+0x11e>
     4b2:      	movq	0x60(%rsp), %rax
     4b7:      	movq	0x68(%rsp), %rcx
     4bc:      	cmpq	$0xa, %rcx
     4c0:      	movl	$0xa, %r15d
     4c6:      	cmovbq	%rcx, %r15
     4ca:      	leaq	0xf80(%r14), %rdi
     4d1:      	movl	%r15d, %esi
     4d4:      	shll	$0x5, %esi
     4d7:      	movl	$0x70, %ecx
     4dc:      	movq	0x60(%rsp), %rdx
     4e1:      	callq	*%rcx
     4e3:      	testq	%rax, %rax
     4e6:      	je	0x630 <kprobe_go_labels+0x630>
     4ec:      	cmpl	$0x0, (%r13)
     4f1:      	je	0x20c <kprobe_go_labels+0x20c>
     4f7:      	movabsq	$0x6c2528206563696c, %rax # imm = 0x6C2528206563696C
     501:      	movq	%rax, 0x38(%rsp)
     506:      	movabsq	$0x7320736c6562616c, %rax # imm = 0x7320736C6562616C
     510:      	movq	%rax, 0x30(%rsp)
     515:      	movabsq	$0x206d6f7266207367, %rax # imm = 0x206D6F7266207367
     51f:      	movq	%rax, 0x28(%rsp)
     524:      	movabsq	$0x6e69727473206461, %rax # imm = 0x6E69727473206461
     52e:      	movq	%rax, 0x20(%rsp)
     533:      	movabsq	$0x6572206f74206465, %rax # imm = 0x6572206F74206465
     53d:      	movq	%rax, 0x18(%rsp)
     542:      	movabsq	$0x6c696166203a6c63, %rax # imm = 0x6C696166203A6C63
     54c:      	movq	%rax, 0x10(%rsp)
     551:      	movl	$0xa2978, 0x40(%rsp)    # imm = 0xA2978
     559:      	leaq	0x10(%rsp), %rdi
     55e:      	movl	$0x34, %eax
     563:      	movl	$0x6, %ecx
     568:      	movq	0x60(%rsp), %rdx
     56d:      	movl	$0x34, %esi
     572:      	jmp	0x8ba <kprobe_go_labels+0x8ba>
     577:      	cmpq	$0x0, 0x90(%rsp)
     580:      	je	0x6d3 <kprobe_go_labels+0x6d3>
     586:      	movl	0x10(%r15), %eax
     58a:      	addq	0x60(%rsp), %rax
     58f:      	leaq	0xf(%rsp), %rdi
     594:      	movl	$0x1, %ecx
     599:      	movl	$0x70, %r8d
     59f:      	movl	0x10(%r15), %edx
     5a3:      	addq	0x60(%rsp), %rdx
     5a8:      	movl	$0x1, %esi
     5ad:      	callq	*%r8
     5b0:      	testq	%rax, %rax
     5b3:      	je	0x715 <kprobe_go_labels+0x715>
     5b9:      	cmpl	$0x0, (%r13)
     5be:      	je	0x20c <kprobe_go_labels+0x20c>
     5c4:      	movabsq	$0x6e756f635f74656b, %rax # imm = 0x6E756F635F74656B
     5ce:      	movq	%rax, 0x30(%rsp)
     5d3:      	movabsq	$0x63756220726f6620, %rax # imm = 0x63756220726F6620
     5dd:      	movq	%rax, 0x28(%rsp)
     5e2:      	movabsq	$0x65756c6176206461, %rax # imm = 0x65756C6176206461
     5ec:      	movq	%rax, 0x20(%rsp)
     5f1:      	movabsq	$0x6572206f74206465, %rax # imm = 0x6572206F74206465
     5fb:      	movq	%rax, 0x18(%rsp)
     600:      	movabsq	$0x6c696166203a6c63, %rax # imm = 0x6C696166203A6C63
     60a:      	movq	%rax, 0x10(%rsp)
     60f:      	movl	$0xa746e, 0x37(%rsp)    # imm = 0xA746E
     617:      	leaq	0x10(%rsp), %rdi
     61c:      	movl	$0x2b, %eax
     621:      	movl	$0x6, %ecx
     626:      	movl	$0x2b, %esi
     62b:      	jmp	0x11e <kprobe_go_labels+0x11e>
     630:      	movq	%r15, 0x78(%rsp)
     635:      	movl	$0xf80, %r15d           # imm = 0xF80
     63b:      	xorl	%ebp, %ebp
     63d:      	xorl	%r12d, %r12d
     640:      	cmpq	%r12, 0x68(%rsp)
     645:      	jbe	0x6c5 <kprobe_go_labels+0x6c5>
     647:      	leaq	(%r14,%rbp), %rdi
     64b:      	addq	$0x3c, %rdi
     64f:      	movq	(%r14,%r15), %rax
     653:      	movq	0x8(%r14,%r15), %rsi
     658:      	cmpq	$0xf, %rsi
     65c:      	movl	$0xf, %ecx
     661:      	cmovaeq	%rcx, %rsi
     665:      	movl	$0x70, %ecx
     66a:      	movq	(%r14,%r15), %rdx
     66e:      	callq	*%rcx
     670:      	testq	%rax, %rax
     673:      	jne	0x7c2 <kprobe_go_labels+0x7c2>
     679:      	movq	0x10(%r14,%r15), %rax
     67e:      	movq	0x18(%r14,%r15), %rsi
     683:      	cmpq	$0x2f, %rsi
     687:      	movl	$0x2f, %ecx
     68c:      	cmovaeq	%rcx, %rsi
     690:      	leaq	(%r14,%rbp), %rdi
     694:      	addq	$0x4c, %rdi
     698:      	movl	$0x70, %ecx
     69d:      	movq	0x10(%r14,%r15), %rdx
     6a2:      	callq	*%rcx
     6a4:      	testq	%rax, %rax
     6a7:      	jne	0x83c <kprobe_go_labels+0x83c>
     6ad:      	incq	%r12
     6b0:      	addq	$0x40, %rbp
     6b4:      	addq	$0x20, %r15
     6b8:      	cmpq	$0x280, %rbp            # imm = 0x280
     6bf:      	jne	0x640 <kprobe_go_labels+0x640>
     6c5:      	movq	0x78(%rsp), %rax
     6ca:      	movl	%eax, 0x38(%r14)
     6ce:      	jmp	0x23c <kprobe_go_labels+0x23c>
     6d3:      	cmpl	$0x0, (%r13)
     6d8:      	je	0x20c <kprobe_go_labels+0x20c>
     6de:      	movabsq	$0xa736c6562616c, %rax  # imm = 0xA736C6562616C
     6e8:      	movq	%rax, 0x17(%rsp)
     6ed:      	movabsq	$0x6c206f6e203a6c63, %rax # imm = 0x6C206F6E203A6C63
     6f7:      	movq	%rax, 0x10(%rsp)
     6fc:      	leaq	0x10(%rsp), %rdi
     701:      	movl	$0xf, %eax
     706:      	movl	$0x6, %ecx
     70b:      	movl	$0xf, %esi
     710:      	jmp	0x11e <kprobe_go_labels+0x11e>
     715:      	movl	0x14(%r15), %eax
     719:      	addq	0x60(%rsp), %rax
     71e:      	leaq	0x88(%rsp), %rdi
     726:      	movl	$0x8, %ecx
     72b:      	movl	$0x70, %r8d
     731:      	movl	0x14(%r15), %edx
     735:      	addq	0x60(%rsp), %rdx
     73a:      	movl	$0x8, %esi
     73f:      	callq	*%r8
     742:      	testq	%rax, %rax
     745:      	je	0x8c3 <kprobe_go_labels+0x8c3>
     74b:      	cmpl	$0x0, (%r13)
     750:      	je	0x20c <kprobe_go_labels+0x20c>
     756:      	movabsq	$0x656b6375625f6c65, %rax # imm = 0x656B6375625F6C65
     760:      	movq	%rax, 0x30(%rsp)
     765:      	movabsq	$0x62616c20726f6620, %rax # imm = 0x62616C20726F6620
     76f:      	movq	%rax, 0x28(%rsp)
     774:      	movabsq	$0x65756c6176206461, %rax # imm = 0x65756C6176206461
     77e:      	movq	%rax, 0x20(%rsp)
     783:      	movabsq	$0x6572206f74206465, %rax # imm = 0x6572206F74206465
     78d:      	movq	%rax, 0x18(%rsp)
     792:      	movabsq	$0x6c696166203a6c63, %rax # imm = 0x6C696166203A6C63
     79c:      	movq	%rax, 0x10(%rsp)
     7a1:      	movl	$0xa7374, 0x38(%rsp)    # imm = 0xA7374
     7a9:      	leaq	0x10(%rsp), %rdi
     7ae:      	movl	$0x2c, %eax
     7b3:      	movl	$0x6, %ecx
     7b8:      	movl	$0x2c, %esi
     7bd:      	jmp	0x11e <kprobe_go_labels+0x11e>
     7c2:      	cmpl	$0x0, (%r13)
     7c7:      	je	0x20c <kprobe_go_labels+0x20c>
     7cd:      	movabsq	$0xa29786c252820, %rax  # imm = 0xA29786C252820
     7d7:      	movq	%rax, 0x37(%rsp)
     7dc:      	movabsq	$0x206c6562616c206d, %rax # imm = 0x206C6562616C206D
     7e6:      	movq	%rax, 0x30(%rsp)
     7eb:      	movabsq	$0x6f7473756320726f, %rax # imm = 0x6F7473756320726F
     7f5:      	movq	%rax, 0x28(%rsp)
     7fa:      	movabsq	$0x662079656b206461, %rax # imm = 0x662079656B206461
     804:      	movq	%rax, 0x20(%rsp)
     809:      	movabsq	$0x6572206f74206465, %rax # imm = 0x6572206F74206465
     813:      	movq	%rax, 0x18(%rsp)
     818:      	movabsq	$0x6c696166203a6c63, %rax # imm = 0x6C696166203A6C63
     822:      	movq	%rax, 0x10(%rsp)
     827:      	leaq	0x10(%rsp), %rdi
     82c:      	movl	$0x2f, %eax
     831:      	movl	$0x6, %ecx
     836:      	movq	(%r14,%r15), %rdx
     83a:      	jmp	0x8b5 <kprobe_go_labels+0x8b5>
     83c:      	cmpl	$0x0, (%r13)
     841:      	je	0x20c <kprobe_go_labels+0x20c>
     847:      	movabsq	$0xa29786c252820, %rax  # imm = 0xA29786C252820
     851:      	movq	%rax, 0x37(%rsp)
     856:      	movabsq	$0x206c6562616c206d, %rax # imm = 0x206C6562616C206D
     860:      	movq	%rax, 0x30(%rsp)
     865:      	movabsq	$0x6f7473756320726f, %rax # imm = 0x6F7473756320726F
     86f:      	movq	%rax, 0x28(%rsp)
     874:      	movabsq	$0x662079656b206461, %rax # imm = 0x662079656B206461
     87e:      	movq	%rax, 0x20(%rsp)
     883:      	movabsq	$0x6572206f74206465, %rax # imm = 0x6572206F74206465
     88d:      	movq	%rax, 0x18(%rsp)
     892:      	movabsq	$0x6c696166203a6c63, %rax # imm = 0x6C696166203A6C63
     89c:      	movq	%rax, 0x10(%rsp)
     8a1:      	leaq	0x10(%rsp), %rdi
     8a6:      	movl	$0x2f, %eax
     8ab:      	movl	$0x6, %ecx
     8b0:      	movq	0x10(%r14,%r15), %rdx
     8b5:      	movl	$0x2f, %esi
     8ba:      	xorl	%eax, %eax
     8bc:      	callq	*%rcx
     8be:      	jmp	0x20c <kprobe_go_labels+0x20c>
     8c3:      	movzbl	0xf(%rsp), %eax
     8c8:      	movl	$0x1, %ecx
     8cd:      	shlxq	%rax, %rcx, %rax
     8d2:      	movzbl	%al, %eax
     8d5:      	leaq	0xf80(%r14), %r15
     8dc:      	xorl	%ecx, %ecx
     8de:      	movl	$0x110, %esi            # imm = 0x110
     8e3:      	movq	%rax, 0xa0(%rsp)
     8eb:      	movq	%r15, 0x98(%rsp)
     8f3:      	cmpq	%rax, %rcx
     8f6:      	je	0x23c <kprobe_go_labels+0x23c>
     8fc:      	movq	%rcx, 0xa8(%rsp)
     904:      	imulq	$0x110, %rcx, %rdx      # imm = 0x110
     90b:      	movq	0x88(%rsp), %rax
     913:      	addq	%rdx, %rax
     916:      	movl	$0x70, %ecx
     91b:      	addq	0x88(%rsp), %rdx
     923:      	movq	%r15, %rdi
     926:      	movl	$0x110, %esi            # imm = 0x110
     92b:      	callq	*%rcx
     92d:      	testq	%rax, %rax
     930:      	jne	0x20c <kprobe_go_labels+0x20c>
     936:      	movl	0x38(%r14), %eax
     93a:      	movq	$-0x80, %r12
     941:      	jmp	0x950 <kprobe_go_labels+0x950>
     943:      	incq	%r15
     946:      	addq	$0x10, %r12
     94a:      	je	0xa07 <kprobe_go_labels+0xa07>
     950:      	cmpl	$0xa, %eax
     953:      	jae	0x23c <kprobe_go_labels+0x23c>
     959:      	cmpb	$0x0, (%r15)
     95d:      	je	0x943 <kprobe_go_labels+0x943>
     95f:      	movq	0x1008(%r14,%r12), %rcx
     967:      	testq	%rcx, %rcx
     96a:      	je	0x943 <kprobe_go_labels+0x943>
     96c:      	movq	%r15, 0xb8(%rsp)
     974:      	movl	%eax, %r15d
     977:      	movq	0x1088(%r14,%r12), %rax
     97f:      	movq	%rax, 0x78(%rsp)
     984:      	movl	0x1090(%r14,%r12), %ebp
     98c:      	shlq	$0x6, %r15
     990:      	leaq	(%r14,%r15), %rdi
     994:      	addq	$0x3c, %rdi
     998:      	movl	0x1010(%r14,%r12), %esi
     9a0:      	cmpl	$0xf, %esi
     9a3:      	movl	$0xf, %eax
     9a8:      	cmovael	%eax, %esi
     9ab:      	movl	$0x70, %eax
     9b0:      	movq	%rcx, %rdx
     9b3:      	movq	%rcx, 0xb0(%rsp)
     9bb:      	callq	*%rax
     9bd:      	testq	%rax, %rax
     9c0:      	jne	0xad8 <kprobe_go_labels+0xad8>
     9c6:      	leaq	(%r14,%r15), %rdi
     9ca:      	addq	$0x4c, %rdi
     9ce:      	cmpl	$0x2f, %ebp
     9d1:      	movl	$0x2f, %eax
     9d6:      	cmovael	%eax, %ebp
     9d9:      	movl	$0x70, %eax
     9de:      	movq	0x78(%rsp), %rdx
     9e3:      	movl	%ebp, %esi
     9e5:      	callq	*%rax
     9e7:      	testq	%rax, %rax
     9ea:      	jne	0xb59 <kprobe_go_labels+0xb59>
     9f0:      	movl	0x38(%r14), %eax
     9f4:      	incl	%eax
     9f6:      	movl	%eax, 0x38(%r14)
     9fa:      	movq	0xb8(%rsp), %r15
     a02:      	jmp	0x943 <kprobe_go_labels+0x943>
     a07:      	movq	0xa8(%rsp), %rcx
     a0f:      	incq	%rcx
     a12:      	cmpq	$0x10, %rcx
     a16:      	movq	0xa0(%rsp), %rax
     a1e:      	movq	0x98(%rsp), %r15
     a26:      	movl	$0x110, %esi            # imm = 0x110
     a2b:      	jne	0x8f3 <kprobe_go_labels+0x8f3>
     a31:      	jmp	0x23c <kprobe_go_labels+0x23c>
     a36:      	movabsq	$0xa786c25203a72, %rax  # imm = 0xA786C25203A72
     a40:      	movq	%rax, 0x48(%rsp)
     a45:      	movabsq	$0x74705f6d203a7972, %rax # imm = 0x74705F6D203A7972
     a4f:      	movq	%rax, 0x40(%rsp)
     a54:      	movabsq	$0x616e6962206f6720, %rax # imm = 0x616E6962206F6720
     a5e:      	movq	%rax, 0x38(%rsp)
     a63:      	movabsq	$0x612073612064657a, %rax # imm = 0x612073612064657A
     a6d:      	movq	%rax, 0x30(%rsp)
     a72:      	movabsq	$0x696e676f63657220, %rax # imm = 0x696E676F63657220
     a7c:      	movq	%rax, 0x28(%rsp)
     a81:      	movabsq	$0x6425202c646e756f, %rax # imm = 0x6425202C646E756F
     a8b:      	movq	%rax, 0x20(%rsp)
     a90:      	movabsq	$0x6620737465736666, %rax # imm = 0x6620737465736666
     a9a:      	movq	%rax, 0x18(%rsp)
     a9f:      	movabsq	$0x6f206f67203a6c63, %rax # imm = 0x6F206F67203A6C63
     aa9:      	movq	%rax, 0x10(%rsp)
     aae:      	leaq	0x10(%rsp), %rdi
     ab3:      	movl	$0x40, %eax
     ab8:      	movl	$0x6, %r8d
     abe:      	movl	0x5c(%rsp), %edx
     ac2:      	movq	0xf78(%r14), %rcx
     ac9:      	movl	$0x40, %esi
     ace:      	xorl	%eax, %eax
     ad0:      	callq	*%r8
     ad3:      	jmp	0x73 <kprobe_go_labels+0x73>
     ad8:      	movq	0xb0(%rsp), %rdx
     ae0:      	cmpl	$0x0, (%r13)
     ae5:      	je	0x20c <kprobe_go_labels+0x20c>
     aeb:      	movabsq	$0xa29786c252820, %rax  # imm = 0xA29786C252820
     af5:      	movq	%rax, 0x37(%rsp)
     afa:      	movabsq	$0x206c6562616c206d, %rax # imm = 0x206C6562616C206D
     b04:      	movq	%rax, 0x30(%rsp)
     b09:      	movabsq	$0x6f7473756320726f, %rax # imm = 0x6F7473756320726F
     b13:      	movq	%rax, 0x28(%rsp)
     b18:      	movabsq	$0x662079656b206461, %rax # imm = 0x662079656B206461
     b22:      	movq	%rax, 0x20(%rsp)
     b27:      	movabsq	$0x6572206f74206465, %rax # imm = 0x6572206F74206465
     b31:      	movq	%rax, 0x18(%rsp)
     b36:      	movabsq	$0x6c696166203a6c63, %rax # imm = 0x6C696166203A6C63
     b40:      	movq	%rax, 0x10(%rsp)
     b45:      	leaq	0x10(%rsp), %rdi
     b4a:      	movl	$0x2f, %eax
     b4f:      	movl	$0x6, %ecx
     b54:      	jmp	0x8b5 <kprobe_go_labels+0x8b5>
     b59:      	cmpl	$0x0, (%r13)
     b5e:      	je	0x20c <kprobe_go_labels+0x20c>
     b64:      	movabsq	$0x6562616c206d6f74, %rax # imm = 0x6562616C206D6F74
     b6e:      	movq	%rax, 0x30(%rsp)
     b73:      	movabsq	$0x73756320726f6620, %rax # imm = 0x73756320726F6620
     b7d:      	movq	%rax, 0x28(%rsp)
     b82:      	movabsq	$0x65756c6176206461, %rax # imm = 0x65756C6176206461
     b8c:      	movq	%rax, 0x20(%rsp)
     b91:      	movabsq	$0x6572206f74206465, %rax # imm = 0x6572206F74206465
     b9b:      	movq	%rax, 0x18(%rsp)
     ba0:      	movabsq	$0x6c696166203a6c63, %rax # imm = 0x6C696166203A6C63
     baa:      	movq	%rax, 0x10(%rsp)
     baf:      	movl	$0xa6c65, 0x37(%rsp)    # imm = 0xA6C65
     bb7:      	leaq	0x10(%rsp), %rdi
     bbc:      	movl	$0x2b, %eax
     bc1:      	movl	$0x6, %ecx
     bc6:      	movl	$0x2b, %esi
     bcb:      	jmp	0x11e <kprobe_go_labels+0x11e>
     bd0:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     bda:      	movq	%rax, 0x36(%rsp)
     bdf:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     be9:      	movq	%rax, 0x30(%rsp)
     bee:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     bf8:      	movq	%rax, 0x28(%rsp)
     bfd:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     c07:      	movq	%rax, 0x20(%rsp)
     c0c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     c16:      	movq	%rax, 0x18(%rsp)
     c1b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     c25:      	movq	%rax, 0x10(%rsp)
     c2a:      	leaq	0x10(%rsp), %rdi
     c2f:      	movl	$0x2e, %eax
     c34:      	movl	$0x6, %ecx
     c39:      	movl	0x60(%rsp), %edx
     c3d:      	movl	$0x2e, %esi
     c42:      	xorl	%eax, %eax
     c44:      	callq	*%rcx
     c46:      	jmp	0x23c <kprobe_go_labels+0x23c>
     c4b:      	movabsq	$0xa29786c253e2d, %rax  # imm = 0xA29786C253E2D
     c55:      	movq	%rax, 0x3e(%rsp)
     c5a:      	movabsq	$0x3e2d786c25282073, %rax # imm = 0x3E2D786C25282073
     c64:      	movq	%rax, 0x38(%rsp)
     c69:      	movabsq	$0x6c6562616c3e2d67, %rax # imm = 0x6C6562616C3E2D67
     c73:      	movq	%rax, 0x30(%rsp)
     c78:      	movabsq	$0x72756320726f6620, %rax # imm = 0x72756320726F6620
     c82:      	movq	%rax, 0x28(%rsp)
     c87:      	movabsq	$0x65756c6176206461, %rax # imm = 0x65756C6176206461
     c91:      	movq	%rax, 0x20(%rsp)
     c96:      	movabsq	$0x6572206f74206465, %rax # imm = 0x6572206F74206465
     ca0:      	movq	%rax, 0x18(%rsp)
     ca5:      	movabsq	$0x6c696166203a6c63, %rax # imm = 0x6C696166203A6C63
     caf:      	movq	%rax, 0x10(%rsp)
     cb4:      	leaq	0x10(%rsp), %rdi
     cb9:      	movl	$0x36, %eax
     cbe:      	movl	$0x6, %r8d
     cc4:      	movq	0x80(%rsp), %rdx
     ccc:      	movl	0x8(%r15), %ecx
     cd0:      	movl	$0x36, %esi
     cd5:      	xorl	%eax, %eax
     cd7:      	callq	*%r8
     cda:      	jmp	0x20c <kprobe_go_labels+0x20c>
