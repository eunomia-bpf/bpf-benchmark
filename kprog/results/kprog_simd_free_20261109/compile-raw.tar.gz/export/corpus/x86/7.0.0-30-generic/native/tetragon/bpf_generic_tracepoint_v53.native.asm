
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_generic_tracepoint_v53.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <native_bpf_strncasestr>:
       0:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
       5:      	testq	%rdx, %rdx
       8:      	je	0x74 <native_bpf_strncasestr+0x74>
       a:      	pushq	%rbx
       b:      	xorl	%ecx, %ecx
       d:      	jmp	0x1b <native_bpf_strncasestr+0x1b>
       f:      	nop
      10:      	incq	%rcx
      13:      	incq	%rdi
      16:      	cmpq	%rdx, %rcx
      19:      	je	0x73 <native_bpf_strncasestr+0x73>
      1b:      	xorl	%r8d, %r8d
      1e:      	nop
      20:      	leaq	(%rcx,%r8), %r9
      24:      	cmpq	%rdx, %r9
      27:      	jae	0x10 <native_bpf_strncasestr+0x10>
      29:      	movsbl	(%rsi,%r8), %r9d
      2e:      	testl	%r9d, %r9d
      31:      	je	0x71 <native_bpf_strncasestr+0x71>
      33:      	movsbl	(%rdi,%r8), %r10d
      38:      	leal	-0x41(%r10), %r11d
      3c:      	movl	%r10d, %ebx
      3f:      	orl	$0x20, %ebx
      42:      	cmpl	$0x1a, %r11d
      46:      	cmovael	%r10d, %ebx
      4a:      	leal	-0x41(%r9), %r10d
      4e:      	movl	%r9d, %r11d
      51:      	orl	$0x20, %r11d
      55:      	cmpl	$0x1a, %r10d
      59:      	cmovael	%r9d, %r11d
      5d:      	cmpl	%r11d, %ebx
      60:      	jne	0x10 <native_bpf_strncasestr+0x10>
      62:      	leaq	0x1(%r8), %r9
      66:      	cmpq	$0x63, %r8
      6a:      	movq	%r9, %r8
      6d:      	jb	0x20 <native_bpf_strncasestr+0x20>
      6f:      	jmp	0x10 <native_bpf_strncasestr+0x10>
      71:      	movl	%ecx, %eax
      73:      	popq	%rbx
      74:      	retq

Disassembly of section tracepoint:

0000000000000000 <generic_tracepoint_process_event>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x118, %rsp            # imm = 0x118
      11:      	movq	%rdi, %r12
      14:      	movl	$0x0, 0xfc(%rsp)
      1f:      	movq	(%rip), %rdi            # 0x26 <generic_tracepoint_process_event+0x26>
      26:      	leaq	0xfc(%rsp), %rsi
      2e:      	movl	$0x1, %eax
      33:      	callq	*%rax
      35:      	testq	%rax, %rax
      38:      	je	0x3056 <generic_tracepoint_process_event+0x3056>
      3e:      	movq	%rax, %r14
      41:      	movl	0x5efc(%rax), %ebx
      47:      	movl	0x4(%rax), %r13d
      4b:      	cmpq	$0x2327, %r13           # imm = 0x2327
      52:      	ja	0x660 <generic_tracepoint_process_event+0x660>
      58:      	movl	$0x0, 0x100(%rsp)
      63:      	movq	(%rip), %rdi            # 0x6a <generic_tracepoint_process_event+0x6a>
      6a:      	leaq	0x100(%rsp), %rsi
      72:      	movl	$0x1, %eax
      77:      	callq	*%rax
      79:      	testq	%rax, %rax
      7c:      	je	0x660 <generic_tracepoint_process_event+0x660>
      82:      	movq	%rax, %r15
      85:      	leaq	0x5ef8(%rax), %rsi
      8c:      	movq	(%rip), %rdi            # 0x93 <generic_tracepoint_process_event+0x93>
      93:      	movl	$0x1, %eax
      98:      	callq	*%rax
      9a:      	cmpl	$0x4, %ebx
      9d:      	jg	0x660 <generic_tracepoint_process_event+0x660>
      a3:      	testq	%rax, %rax
      a6:      	je	0x660 <generic_tracepoint_process_event+0x660>
      ac:      	movq	%r13, 0xe0(%rsp)
      b4:      	movq	%r12, 0xb8(%rsp)
      bc:      	movq	%rbx, 0xe8(%rsp)
      c4:      	andl	$0x7, %ebx
      c7:      	movl	%ebx, %ecx
      c9:      	movl	0x4(%rax,%rcx,4), %r12d
      ce:      	movslq	0x18(%rax,%rcx,4), %rbp
      d3:      	movl	$0x0, 0x5ea0(%r15,%rcx,4)
      df:      	movq	0x5e50(%r15,%rcx,8), %rcx
      e7:      	movq	%rcx, 0x18(%rsp)
      ec:      	testl	$0x100, %ebp            # imm = 0x100
      f2:      	movq	%rbx, 0x8(%rsp)
      f7:      	jne	0x427 <generic_tracepoint_process_event+0x427>
      fd:      	cmpl	$0x4, %ebx
     100:      	ja	0x430 <generic_tracepoint_process_event+0x430>
     106:      	leaq	(%rbx,%rbx,4), %rdx
     10a:      	shll	$0x4, %edx
     10d:      	cmpw	$0x0, 0x76(%rax,%rdx)
     113:      	je	0x430 <generic_tracepoint_process_event+0x430>
     119:      	leaq	(%rax,%rdx), %r13
     11d:      	addq	$0x70, %r13
     121:      	movl	(%r13), %eax
     125:      	addq	%rax, %rcx
     128:      	movq	%rcx, 0x18(%rsp)
     12d:      	cmpw	$0x0, 0x4(%r13)
     133:      	je	0x162 <generic_tracepoint_process_event+0x162>
     135:      	leaq	0x18(%rsp), %rdi
     13a:      	movl	$0x8, %edx
     13f:      	movl	$0x4, %eax
     144:      	movq	0x18(%rsp), %rdx
     149:      	movl	$0x8, %esi
     14e:      	callq	*%rax
     150:      	movq	0x8(%rsp), %rcx
     155:      	movl	$0x1, %ebx
     15a:      	testl	%eax, %eax
     15c:      	js	0x41d <generic_tracepoint_process_event+0x41d>
     162:      	cmpw	$0x0, 0xe(%r13)
     168:      	je	0x430 <generic_tracepoint_process_event+0x430>
     16e:      	movl	0x8(%r13), %ecx
     172:      	addq	0x18(%rsp), %rcx
     177:      	movq	%rcx, 0x18(%rsp)
     17c:      	cmpw	$0x0, 0xc(%r13)
     182:      	je	0x1b1 <generic_tracepoint_process_event+0x1b1>
     184:      	leaq	0x18(%rsp), %rdi
     189:      	movl	$0x8, %edx
     18e:      	movl	$0x4, %eax
     193:      	movq	0x18(%rsp), %rdx
     198:      	movl	$0x8, %esi
     19d:      	callq	*%rax
     19f:      	movq	0x8(%rsp), %rcx
     1a4:      	movl	$0x2, %ebx
     1a9:      	testl	%eax, %eax
     1ab:      	js	0x41d <generic_tracepoint_process_event+0x41d>
     1b1:      	cmpw	$0x0, 0x16(%r13)
     1b7:      	je	0x430 <generic_tracepoint_process_event+0x430>
     1bd:      	movl	0x10(%r13), %ecx
     1c1:      	addq	0x18(%rsp), %rcx
     1c6:      	movq	%rcx, 0x18(%rsp)
     1cb:      	cmpw	$0x0, 0x14(%r13)
     1d1:      	je	0x200 <generic_tracepoint_process_event+0x200>
     1d3:      	leaq	0x18(%rsp), %rdi
     1d8:      	movl	$0x8, %edx
     1dd:      	movl	$0x4, %eax
     1e2:      	movq	0x18(%rsp), %rdx
     1e7:      	movl	$0x8, %esi
     1ec:      	callq	*%rax
     1ee:      	movq	0x8(%rsp), %rcx
     1f3:      	movl	$0x3, %ebx
     1f8:      	testl	%eax, %eax
     1fa:      	js	0x41d <generic_tracepoint_process_event+0x41d>
     200:      	cmpw	$0x0, 0x1e(%r13)
     206:      	je	0x430 <generic_tracepoint_process_event+0x430>
     20c:      	movl	0x18(%r13), %ecx
     210:      	addq	0x18(%rsp), %rcx
     215:      	movq	%rcx, 0x18(%rsp)
     21a:      	cmpw	$0x0, 0x1c(%r13)
     220:      	je	0x24f <generic_tracepoint_process_event+0x24f>
     222:      	leaq	0x18(%rsp), %rdi
     227:      	movl	$0x8, %edx
     22c:      	movl	$0x4, %eax
     231:      	movq	0x18(%rsp), %rdx
     236:      	movl	$0x8, %esi
     23b:      	callq	*%rax
     23d:      	movq	0x8(%rsp), %rcx
     242:      	movl	$0x4, %ebx
     247:      	testl	%eax, %eax
     249:      	js	0x41d <generic_tracepoint_process_event+0x41d>
     24f:      	cmpw	$0x0, 0x26(%r13)
     255:      	je	0x430 <generic_tracepoint_process_event+0x430>
     25b:      	movl	0x20(%r13), %ecx
     25f:      	addq	0x18(%rsp), %rcx
     264:      	movq	%rcx, 0x18(%rsp)
     269:      	cmpw	$0x0, 0x24(%r13)
     26f:      	je	0x29e <generic_tracepoint_process_event+0x29e>
     271:      	leaq	0x18(%rsp), %rdi
     276:      	movl	$0x8, %edx
     27b:      	movl	$0x4, %eax
     280:      	movq	0x18(%rsp), %rdx
     285:      	movl	$0x8, %esi
     28a:      	callq	*%rax
     28c:      	movq	0x8(%rsp), %rcx
     291:      	movl	$0x5, %ebx
     296:      	testl	%eax, %eax
     298:      	js	0x41d <generic_tracepoint_process_event+0x41d>
     29e:      	cmpw	$0x0, 0x2e(%r13)
     2a4:      	je	0x430 <generic_tracepoint_process_event+0x430>
     2aa:      	movl	0x28(%r13), %ecx
     2ae:      	addq	0x18(%rsp), %rcx
     2b3:      	movq	%rcx, 0x18(%rsp)
     2b8:      	cmpw	$0x0, 0x2c(%r13)
     2be:      	je	0x2ed <generic_tracepoint_process_event+0x2ed>
     2c0:      	leaq	0x18(%rsp), %rdi
     2c5:      	movl	$0x8, %edx
     2ca:      	movl	$0x4, %eax
     2cf:      	movq	0x18(%rsp), %rdx
     2d4:      	movl	$0x8, %esi
     2d9:      	callq	*%rax
     2db:      	movq	0x8(%rsp), %rcx
     2e0:      	movl	$0x6, %ebx
     2e5:      	testl	%eax, %eax
     2e7:      	js	0x41d <generic_tracepoint_process_event+0x41d>
     2ed:      	cmpw	$0x0, 0x36(%r13)
     2f3:      	je	0x430 <generic_tracepoint_process_event+0x430>
     2f9:      	movl	0x30(%r13), %ecx
     2fd:      	addq	0x18(%rsp), %rcx
     302:      	movq	%rcx, 0x18(%rsp)
     307:      	cmpw	$0x0, 0x34(%r13)
     30d:      	je	0x33c <generic_tracepoint_process_event+0x33c>
     30f:      	leaq	0x18(%rsp), %rdi
     314:      	movl	$0x8, %edx
     319:      	movl	$0x4, %eax
     31e:      	movq	0x18(%rsp), %rdx
     323:      	movl	$0x8, %esi
     328:      	callq	*%rax
     32a:      	movq	0x8(%rsp), %rcx
     32f:      	movl	$0x7, %ebx
     334:      	testl	%eax, %eax
     336:      	js	0x41d <generic_tracepoint_process_event+0x41d>
     33c:      	cmpw	$0x0, 0x3e(%r13)
     342:      	je	0x430 <generic_tracepoint_process_event+0x430>
     348:      	movl	0x38(%r13), %ecx
     34c:      	addq	0x18(%rsp), %rcx
     351:      	movq	%rcx, 0x18(%rsp)
     356:      	cmpw	$0x0, 0x3c(%r13)
     35c:      	je	0x38b <generic_tracepoint_process_event+0x38b>
     35e:      	leaq	0x18(%rsp), %rdi
     363:      	movl	$0x8, %edx
     368:      	movl	$0x4, %eax
     36d:      	movq	0x18(%rsp), %rdx
     372:      	movl	$0x8, %ebx
     377:      	movl	$0x8, %esi
     37c:      	callq	*%rax
     37e:      	movq	0x8(%rsp), %rcx
     383:      	testl	%eax, %eax
     385:      	js	0x41d <generic_tracepoint_process_event+0x41d>
     38b:      	cmpw	$0x0, 0x46(%r13)
     391:      	je	0x430 <generic_tracepoint_process_event+0x430>
     397:      	movl	0x40(%r13), %ecx
     39b:      	addq	0x18(%rsp), %rcx
     3a0:      	movq	%rcx, 0x18(%rsp)
     3a5:      	cmpw	$0x0, 0x44(%r13)
     3ab:      	je	0x3d6 <generic_tracepoint_process_event+0x3d6>
     3ad:      	leaq	0x18(%rsp), %rdi
     3b2:      	movl	$0x8, %edx
     3b7:      	movl	$0x4, %eax
     3bc:      	movq	0x18(%rsp), %rdx
     3c1:      	movl	$0x8, %esi
     3c6:      	callq	*%rax
     3c8:      	movq	0x8(%rsp), %rcx
     3cd:      	movl	$0x9, %ebx
     3d2:      	testl	%eax, %eax
     3d4:      	js	0x41d <generic_tracepoint_process_event+0x41d>
     3d6:      	cmpw	$0x0, 0x4e(%r13)
     3dc:      	je	0x430 <generic_tracepoint_process_event+0x430>
     3de:      	movl	0x48(%r13), %ecx
     3e2:      	addq	0x18(%rsp), %rcx
     3e7:      	movq	%rcx, 0x18(%rsp)
     3ec:      	cmpw	$0x0, 0x4c(%r13)
     3f2:      	je	0x430 <generic_tracepoint_process_event+0x430>
     3f4:      	leaq	0x18(%rsp), %rdi
     3f9:      	movl	$0x8, %edx
     3fe:      	movl	$0x4, %eax
     403:      	movq	0x18(%rsp), %rdx
     408:      	movl	$0x8, %esi
     40d:      	callq	*%rax
     40f:      	movq	0x8(%rsp), %rcx
     414:      	movl	$0xa, %ebx
     419:      	testl	%eax, %eax
     41b:      	jns	0x430 <generic_tracepoint_process_event+0x430>
     41d:      	movl	%ebx, 0x5ea0(%r15,%rcx,4)
     425:      	jmp	0x430 <generic_tracepoint_process_event+0x430>
     427:      	movq	$0x0, 0x18(%rsp)
     430:      	movl	$0x1fe, %ebx            # imm = 0x1FE
     435:      	movq	0x18(%rsp), %r15
     43a:      	cmpl	$0x15, %r12d
     43e:      	jg	0x47f <generic_tracepoint_process_event+0x47f>
     440:      	cmpl	$0xb, %r12d
     444:      	movq	0xe0(%rsp), %r13
     44c:      	jg	0x4b4 <generic_tracepoint_process_event+0x4b4>
     44e:      	cmpl	$0x5, %r12d
     452:      	jg	0x50c <generic_tracepoint_process_event+0x50c>
     458:      	cmpl	$0x3, %r12d
     45c:      	jg	0x591 <generic_tracepoint_process_event+0x591>
     462:      	leal	-0x2(%r12), %eax
     467:      	cmpl	$0x2, %eax
     46a:      	jb	0x577 <generic_tracepoint_process_event+0x577>
     470:      	cmpl	$0x1, %r12d
     474:      	je	0x577 <generic_tracepoint_process_event+0x577>
     47a:      	jmp	0x5d9 <generic_tracepoint_process_event+0x5d9>
     47f:      	cmpl	$0x20, %r12d
     483:      	movq	0xe0(%rsp), %r13
     48b:      	jle	0x4df <generic_tracepoint_process_event+0x4df>
     48d:      	cmpl	$0x26, %r12d
     491:      	jg	0x535 <generic_tracepoint_process_event+0x535>
     497:      	leal	-0x21(%r12), %eax
     49c:      	cmpl	$0x4, %eax
     49f:      	jb	0x5a4 <generic_tracepoint_process_event+0x5a4>
     4a5:      	cmpl	$0x25, %r12d
     4a9:      	je	0x5db <generic_tracepoint_process_event+0x5db>
     4af:      	jmp	0x5d9 <generic_tracepoint_process_event+0x5d9>
     4b4:      	cmpl	$0x11, %r12d
     4b8:      	jg	0x556 <generic_tracepoint_process_event+0x556>
     4be:      	leal	-0xf(%r12), %eax
     4c3:      	cmpl	$0x3, %eax
     4c6:      	jb	0x5db <generic_tracepoint_process_event+0x5db>
     4cc:      	leal	-0xc(%r12), %eax
     4d1:      	cmpl	$0x2, %eax
     4d4:      	jb	0x577 <generic_tracepoint_process_event+0x577>
     4da:      	jmp	0x5d9 <generic_tracepoint_process_event+0x5d9>
     4df:      	cmpl	$0x1a, %r12d
     4e3:      	jg	0x56d <generic_tracepoint_process_event+0x56d>
     4e9:      	cmpl	$0x16, %r12d
     4ed:      	je	0x5be <generic_tracepoint_process_event+0x5be>
     4f3:      	cmpl	$0x17, %r12d
     4f7:      	je	0x5a4 <generic_tracepoint_process_event+0x5a4>
     4fd:      	cmpl	$0x1a, %r12d
     501:      	je	0x5d2 <generic_tracepoint_process_event+0x5d2>
     507:      	jmp	0x5d9 <generic_tracepoint_process_event+0x5d9>
     50c:      	cmpl	$0x9, %r12d
     510:      	jg	0x5a4 <generic_tracepoint_process_event+0x5a4>
     516:      	cmpl	$0x6, %r12d
     51a:      	je	0x5db <generic_tracepoint_process_event+0x5db>
     520:      	cmpl	$0x7, %r12d
     524:      	je	0x59d <generic_tracepoint_process_event+0x59d>
     526:      	cmpl	$0x8, %r12d
     52a:      	je	0x5d2 <generic_tracepoint_process_event+0x5d2>
     530:      	jmp	0x5d9 <generic_tracepoint_process_event+0x5d9>
     535:      	cmpl	$0x28, %r12d
     539:      	jle	0x5ab <generic_tracepoint_process_event+0x5ab>
     53b:      	cmpl	$0x29, %r12d
     53f:      	je	0x59d <generic_tracepoint_process_event+0x59d>
     541:      	cmpl	$0x2a, %r12d
     545:      	je	0x5db <generic_tracepoint_process_event+0x5db>
     54b:      	cmpl	$0x2b, %r12d
     54f:      	je	0x5b7 <generic_tracepoint_process_event+0x5b7>
     551:      	jmp	0x5d9 <generic_tracepoint_process_event+0x5d9>
     556:      	cmpl	$0x13, %r12d
     55a:      	jg	0x57e <generic_tracepoint_process_event+0x57e>
     55c:      	movq	%rbp, %rbx
     55f:      	cmpl	$0x12, %r12d
     563:      	je	0x5db <generic_tracepoint_process_event+0x5db>
     565:      	cmpl	$0x13, %r12d
     569:      	je	0x5b7 <generic_tracepoint_process_event+0x5b7>
     56b:      	jmp	0x5d9 <generic_tracepoint_process_event+0x5d9>
     56d:      	leal	-0x1d(%r12), %eax
     572:      	cmpl	$0x4, %eax
     575:      	jae	0x5cc <generic_tracepoint_process_event+0x5cc>
     577:      	movl	$0x4, %ebx
     57c:      	jmp	0x5db <generic_tracepoint_process_event+0x5db>
     57e:      	cmpl	$0x14, %r12d
     582:      	je	0x5c5 <generic_tracepoint_process_event+0x5c5>
     584:      	cmpl	$0x15, %r12d
     588:      	jne	0x5d9 <generic_tracepoint_process_event+0x5d9>
     58a:      	movl	$0x20, %ebx
     58f:      	jmp	0x5db <generic_tracepoint_process_event+0x5db>
     591:      	cmpl	$0x4, %r12d
     595:      	je	0x5a4 <generic_tracepoint_process_event+0x5a4>
     597:      	cmpl	$0x5, %r12d
     59b:      	jne	0x5d9 <generic_tracepoint_process_event+0x5d9>
     59d:      	movl	$0x40, %ebx
     5a2:      	jmp	0x5db <generic_tracepoint_process_event+0x5db>
     5a4:      	movl	$0x8, %ebx
     5a9:      	jmp	0x5db <generic_tracepoint_process_event+0x5db>
     5ab:      	cmpl	$0x27, %r12d
     5af:      	je	0x5be <generic_tracepoint_process_event+0x5be>
     5b1:      	cmpl	$0x28, %r12d
     5b5:      	jne	0x5d9 <generic_tracepoint_process_event+0x5d9>
     5b7:      	movl	$0x18, %ebx
     5bc:      	jmp	0x5db <generic_tracepoint_process_event+0x5db>
     5be:      	movl	$0x10, %ebx
     5c3:      	jmp	0x5db <generic_tracepoint_process_event+0x5db>
     5c5:      	movl	$0x98, %ebx
     5ca:      	jmp	0x5db <generic_tracepoint_process_event+0x5db>
     5cc:      	cmpl	$0x1b, %r12d
     5d0:      	jne	0x5d9 <generic_tracepoint_process_event+0x5d9>
     5d2:      	movl	$0x50, %ebx
     5d7:      	jmp	0x5db <generic_tracepoint_process_event+0x5db>
     5d9:      	xorl	%ebx, %ebx
     5db:      	movl	$0x0, 0x104(%rsp)
     5e6:      	movq	(%rip), %rdi            # 0x5ed <generic_tracepoint_process_event+0x5ed>
     5ed:      	leaq	0x104(%rsp), %rsi
     5f5:      	movl	$0x1, %eax
     5fa:      	callq	*%rax
     5fc:      	testq	%rax, %rax
     5ff:      	je	0x650 <generic_tracepoint_process_event+0x650>
     601:      	movl	$0x3ffb, %ecx           # imm = 0x3FFB
     606:      	subq	%rbx, %rcx
     609:      	cmpq	%r13, %rcx
     60c:      	jbe	0x650 <generic_tracepoint_process_event+0x650>
     60e:      	movq	0x8(%rsp), %rdx
     613:      	movl	0x5ea0(%rax,%rdx,4), %ecx
     61a:      	movl	%ecx, 0x90(%rax,%r13)
     622:      	leaq	0x4(%r13), %rsi
     626:      	movq	%rsi, 0x5e78(%rax,%rdx,8)
     62e:      	movl	$0x4, %edx
     633:      	testl	%ecx, %ecx
     635:      	je	0x6eb <generic_tracepoint_process_event+0x6eb>
     63b:      	movq	0xb8(%rsp), %r12
     643:      	movq	0xe8(%rsp), %rbx
     64b:      	jmp	0x301d <generic_tracepoint_process_event+0x301d>
     650:      	movq	0xb8(%rsp), %r12
     658:      	movq	0xe8(%rsp), %rbx
     660:      	movl	%r13d, 0x4(%r14)
     664:      	cmpl	$0x3, %ebx
     667:      	jg	0x3030 <generic_tracepoint_process_event+0x3030>
     66d:      	movl	$0x0, 0x50(%rsp)
     675:      	movq	(%rip), %rdi            # 0x67c <generic_tracepoint_process_event+0x67c>
     67c:      	leaq	0x50(%rsp), %rsi
     681:      	movl	$0x1, %eax
     686:      	callq	*%rax
     688:      	testq	%rax, %rax
     68b:      	je	0x3030 <generic_tracepoint_process_event+0x3030>
     691:      	movq	%rax, %rsi
     694:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
     69b:      	movq	(%rip), %rdi            # 0x6a2 <generic_tracepoint_process_event+0x6a2>
     6a2:      	movl	$0x1, %eax
     6a7:      	callq	*%rax
     6a9:      	testq	%rax, %rax
     6ac:      	je	0x3030 <generic_tracepoint_process_event+0x3030>
     6b2:      	incl	%ebx
     6b4:      	movl	%ebx, %ecx
     6b6:      	andl	$0x7, %ecx
     6b9:      	cmpl	$-0x1, 0x40(%rax,%rcx,4)
     6be:      	je	0x3030 <generic_tracepoint_process_event+0x3030>
     6c4:      	movl	%ebx, 0x5efc(%r14)
     6cb:      	movq	(%rip), %rsi            # 0x6d2 <generic_tracepoint_process_event+0x6d2>
     6d2:      	movl	$0x1, %ecx
     6d7:      	movl	$0xc, %eax
     6dc:      	movq	%r12, %rdi
     6df:      	movl	$0x1, %edx
     6e4:      	callq	*%rax
     6e6:      	jmp	0x3030 <generic_tracepoint_process_event+0x3030>
     6eb:      	movq	%rax, %rbx
     6ee:      	addq	$0x90, %rbx
     6f5:      	addq	%rsi, %rbx
     6f8:      	movq	%r15, 0x50(%rsp)
     6fd:      	movq	$0x0, 0x98(%rsp)
     709:      	cmpl	$0x17, %r12d
     70d:      	movq	%rax, 0x10(%rsp)
     712:      	jle	0x74f <generic_tracepoint_process_event+0x74f>
     714:      	cmpl	$0x18, %r12d
     718:      	je	0x76a <generic_tracepoint_process_event+0x76a>
     71a:      	cmpl	$0x25, %r12d
     71e:      	je	0x7ab <generic_tracepoint_process_event+0x7ab>
     724:      	cmpl	$0x2a, %r12d
     728:      	jne	0xd55 <generic_tracepoint_process_event+0xd55>
     72e:      	movq	$0x0, 0x108(%rsp)
     73a:      	movq	%r15, 0x110(%rsp)
     742:      	leaq	0x108(%rsp), %r15
     74a:      	jmp	0x7d8 <generic_tracepoint_process_event+0x7d8>
     74f:      	cmpl	$0xf, %r12d
     753:      	je	0xc8b <generic_tracepoint_process_event+0xc8b>
     759:      	cmpl	$0x10, %r12d
     75d:      	jne	0xd55 <generic_tracepoint_process_event+0xd55>
     763:      	leaq	0x40(%rsp), %r15
     768:      	jmp	0x795 <generic_tracepoint_process_event+0x795>
     76a:      	movq	%r15, %rdx
     76d:      	leaq	0x40(%rsp), %r15
     772:      	movl	$0x8, %ecx
     777:      	movl	$0x4, %eax
     77c:      	movq	0x50(%rsp), %rdx
     781:      	movq	%r15, %rdi
     784:      	movl	$0x8, %esi
     789:      	callq	*%rax
     78b:      	movq	0x40(%rsp), %rax
     790:      	movq	%rax, 0x50(%rsp)
     795:      	leaq	0x50(%rsp), %rdx
     79a:      	movl	$0x8, %ecx
     79f:      	movl	$0x4, %eax
     7a4:      	leaq	0x40(%rsp), %rdi
     7a9:      	jmp	0x7c8 <generic_tracepoint_process_event+0x7c8>
     7ab:      	addq	$0x40, %r15
     7af:      	movq	%r15, 0x50(%rsp)
     7b4:      	leaq	0x40(%rsp), %rdi
     7b9:      	movl	$0x8, %ecx
     7be:      	movl	$0x4, %eax
     7c3:      	movq	0x50(%rsp), %rdx
     7c8:      	movl	$0x8, %esi
     7cd:      	callq	*%rax
     7cf:      	movq	0x40(%rsp), %r15
     7d4:      	addq	$0x40, %r15
     7d8:      	movl	$0x0, 0xb4(%rsp)
     7e3:      	movq	(%rip), %rdi            # 0x7ea <generic_tracepoint_process_event+0x7ea>
     7ea:      	leaq	0xb4(%rsp), %rsi
     7f2:      	movl	$0x1, %eax
     7f7:      	callq	*%rax
     7f9:      	testq	%rax, %rax
     7fc:      	je	0x8a8 <generic_tracepoint_process_event+0x8a8>
     802:      	movq	%rax, %r12
     805:      	movq	%rbx, 0x28(%rsp)
     80a:      	addq	$0x1000, %rax           # imm = 0x1000
     810:      	movq	%rax, 0x20(%rsp)
     815:      	movl	$0x23, %eax
     81a:      	callq	*%rax
     81c:      	leaq	0xd50(%rax), %rdx
     823:      	leaq	0xc8(%rsp), %rdi
     82b:      	movl	$0x8, %ecx
     830:      	movl	$0x4, %eax
     835:      	movl	$0x8, %esi
     83a:      	callq	*%rax
     83c:      	movq	0xc8(%rsp), %rbp
     844:      	leaq	0x8(%r15), %rdx
     848:      	leaq	0xc0(%rsp), %rdi
     850:      	movl	$0x8, %ecx
     855:      	movl	$0x4, %eax
     85a:      	leaq	0x18(%rbp), %rcx
     85e:      	movq	%rcx, 0xa8(%rsp)
     866:      	movl	$0x8, %esi
     86b:      	movq	%rdx, 0x38(%rsp)
     870:      	callq	*%rax
     872:      	movq	0xc0(%rsp), %r13
     87a:      	leaq	0x10(%r13), %rdx
     87e:      	leaq	0x50(%rsp), %rdi
     883:      	movl	$0x8, %ecx
     888:      	movl	$0x4, %eax
     88d:      	movl	$0x8, %esi
     892:      	callq	*%rax
     894:      	cmpq	$0x0, 0x50(%rsp)
     89a:      	movl	$0x1000, %ebx           # imm = 0x1000
     89f:      	je	0x8b8 <generic_tracepoint_process_event+0x8b8>
     8a1:      	movq	0x20(%rsp), %rcx
     8a6:      	jmp	0x90a <generic_tracepoint_process_event+0x90a>
     8a8:      	xorl	%r13d, %r13d
     8ab:      	movq	0xb8(%rsp), %r12
     8b3:      	jmp	0x2fff <generic_tracepoint_process_event+0x2fff>
     8b8:      	leaq	0x18(%r13), %rdx
     8bc:      	leaq	0x50(%rsp), %rdi
     8c1:      	movl	$0x8, %ecx
     8c6:      	movl	$0x4, %eax
     8cb:      	movl	$0x8, %esi
     8d0:      	callq	*%rax
     8d2:      	cmpq	%r13, 0x50(%rsp)
     8d7:      	movq	0x20(%rsp), %rcx
     8dc:      	je	0x90a <generic_tracepoint_process_event+0x90a>
     8de:      	movq	%r12, %rcx
     8e1:      	addq	$0xff6, %rcx            # imm = 0xFF6
     8e8:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
     8f2:      	movq	%rax, 0xff6(%r12)
     8fa:      	movw	$0x2964, 0xffe(%r12)    # imm = 0x2964
     905:      	movl	$0xff6, %ebx            # imm = 0xFF6
     90a:      	movq	$0x0, 0x58(%rsp)
     913:      	movq	$0x0, 0x50(%rsp)
     91c:      	movq	%r12, 0x60(%rsp)
     921:      	movq	$0x0, 0x68(%rsp)
     92a:      	movq	$0x0, 0x70(%rsp)
     933:      	movq	$0x0, 0x78(%rsp)
     93c:      	movq	%rcx, 0x20(%rsp)
     941:      	movq	%rcx, 0x80(%rsp)
     949:      	movl	%ebx, 0x88(%rsp)
     950:      	movb	$0x0, 0x8c(%rsp)
     958:      	addq	$0x20, %rbp
     95c:      	leaq	0x50(%rsp), %rdi
     961:      	movl	$0x8, %ebx
     966:      	movl	$0x4, %eax
     96b:      	leaq	0x58(%rsp), %r13
     970:      	leaq	0x68(%rsp), %r12
     975:      	movl	$0x8, %esi
     97a:      	movq	%rbp, %rdx
     97d:      	callq	*%rax
     97f:      	movl	$0x8, %ecx
     984:      	movl	$0x4, %eax
     989:      	movq	0xa8(%rsp), %rdx
     991:      	movq	%r13, %rdi
     994:      	movl	$0x8, %esi
     999:      	callq	*%rax
     99b:      	movl	$0x8, %ecx
     9a0:      	movl	$0x4, %eax
     9a5:      	movq	0x38(%rsp), %rdx
     9aa:      	movq	%r12, %rdi
     9ad:      	movl	$0x8, %esi
     9b2:      	callq	*%rax
     9b4:      	movl	$0x8, %ecx
     9b9:      	movl	$0x4, %eax
     9be:      	leaq	0x70(%rsp), %rdi
     9c3:      	movl	$0x8, %esi
     9c8:      	movq	%r15, %rdx
     9cb:      	callq	*%rax
     9cd:      	movq	0x70(%rsp), %rax
     9d2:      	addq	$-0x20, %rax
     9d6:      	movq	%rax, 0x78(%rsp)
     9db:      	movl	$0x80, %ebp
     9e0:      	movq	0x68(%rsp), %r13
     9e5:      	movq	0x70(%rsp), %rdx
     9ea:      	movq	0x78(%rsp), %r12
     9ef:      	cmpq	0x50(%rsp), %r13
     9f4:      	jne	0xa01 <generic_tracepoint_process_event+0xa01>
     9f6:      	cmpq	0x58(%rsp), %rdx
     9fb:      	je	0xb7e <generic_tracepoint_process_event+0xb7e>
     a01:      	movl	$0x4, %eax
     a06:      	leaq	0xd0(%rsp), %rdi
     a0e:      	movl	$0x8, %esi
     a13:      	callq	*%rax
     a15:      	cmpq	0xd0(%rsp), %r13
     a1d:      	je	0xb27 <generic_tracepoint_process_event+0xb27>
     a23:      	leaq	0x18(%r13), %r15
     a27:      	movl	$0x4, %eax
     a2c:      	leaq	0x40(%rsp), %rdi
     a31:      	movl	$0x8, %esi
     a36:      	movq	%r15, %rdx
     a39:      	callq	*%rax
     a3b:      	cmpq	%r13, 0x40(%rsp)
     a40:      	je	0xb27 <generic_tracepoint_process_event+0xb27>
     a46:      	movl	$0x4, %eax
     a4b:      	leaq	0x30(%rsp), %rdi
     a50:      	movl	$0x8, %esi
     a55:      	movq	%r15, %rdx
     a58:      	callq	*%rax
     a5a:      	addq	$0x20, %r13
     a5e:      	movl	$0x4, %eax
     a63:      	leaq	0x98(%rsp), %rdi
     a6b:      	movl	$0x10, %ecx
     a70:      	movl	$0x10, %esi
     a75:      	movq	%r13, %rdx
     a78:      	callq	*%rax
     a7a:      	movq	0x60(%rsp), %r15
     a7f:      	movq	0x80(%rsp), %rax
     a87:      	movl	0x9c(%rsp), %r12d
     a8f:      	subq	%r15, %rax
     a92:      	movl	0x88(%rsp), %r13d
     a9a:      	movl	%r12d, %edx
     a9d:      	subl	%r13d, %edx
     aa0:      	movl	$0x0, %ecx
     aa5:      	cmovbl	%ecx, %edx
     aa8:      	addq	0xa0(%rsp), %rdx
     ab0:      	xorl	%esi, %esi
     ab2:      	cmpl	%r12d, %r13d
     ab5:      	seta	%sil
     ab9:      	movl	%r12d, %ecx
     abc:      	cmovbl	%r13d, %ecx
     ac0:      	addl	%ecx, %esi
     ac2:      	movl	%r13d, %edi
     ac5:      	subl	%esi, %edi
     ac7:      	movl	%edi, 0x88(%rsp)
     ace:      	subq	%rsi, %rax
     ad1:      	jb	0xb86 <generic_tracepoint_process_event+0xb86>
     ad7:      	cmpq	$0xfff, %rax            # imm = 0xFFF
     add:      	ja	0xb86 <generic_tracepoint_process_event+0xb86>
     ae3:      	cmpl	%r12d, %r13d
     ae6:      	jbe	0xaed <generic_tracepoint_process_event+0xaed>
     ae8:      	movb	$0x2f, (%r15,%rax)
     aed:      	xorl	%edi, %edi
     aef:      	cmpl	%r12d, %r13d
     af2:      	seta	%dil
     af6:      	movzbl	%cl, %esi
     af9:      	addq	%rax, %r15
     afc:      	addq	%r15, %rdi
     aff:      	movl	$0x4, %eax
     b04:      	callq	*%rax
     b06:      	movq	%r15, 0x80(%rsp)
     b0e:      	cmpl	%r12d, %r13d
     b11:      	jbe	0xb86 <generic_tracepoint_process_event+0xb86>
     b13:      	movq	0x30(%rsp), %rax
     b18:      	movq	%rax, 0x68(%rsp)
     b1d:      	decl	%ebp
     b1f:      	jne	0x9e0 <generic_tracepoint_process_event+0x9e0>
     b25:      	jmp	0xb86 <generic_tracepoint_process_event+0xb86>
     b27:      	leaq	0x10(%r12), %rdx
     b2c:      	movl	$0x4, %eax
     b31:      	leaq	0x40(%rsp), %rdi
     b36:      	movl	$0x8, %esi
     b3b:      	callq	*%rax
     b3d:      	movq	0x78(%rsp), %rax
     b42:      	cmpq	0x40(%rsp), %rax
     b47:      	je	0xb7e <generic_tracepoint_process_event+0xb7e>
     b49:      	addq	$0x18, %r12
     b4d:      	movl	$0x4, %eax
     b52:      	leaq	0x68(%rsp), %rdi
     b57:      	movl	$0x8, %esi
     b5c:      	movq	%r12, %rdx
     b5f:      	callq	*%rax
     b61:      	movq	0x40(%rsp), %rax
     b66:      	movq	%rax, 0x78(%rsp)
     b6b:      	addq	$0x20, %rax
     b6f:      	movq	%rax, 0x70(%rsp)
     b74:      	decl	%ebp
     b76:      	jne	0x9e0 <generic_tracepoint_process_event+0x9e0>
     b7c:      	jmp	0xb86 <generic_tracepoint_process_event+0xb86>
     b7e:      	movb	$0x1, 0x8c(%rsp)
     b86:      	movq	0x80(%rsp), %rax
     b8e:      	movq	0x20(%rsp), %rdx
     b93:      	cmpq	%rdx, %rax
     b96:      	movq	0xb8(%rsp), %r12
     b9e:      	je	0xbd5 <generic_tracepoint_process_event+0xbd5>
     ba0:      	xorl	%ebx, %ebx
     ba2:      	cmpb	$0x0, 0x8c(%rsp)
     baa:      	sete	%cl
     bad:      	movl	0x88(%rsp), %edx
     bb4:      	movl	$0x1000, %r13d          # imm = 0x1000
     bba:      	subl	%edx, %r13d
     bbd:      	testl	%edx, %edx
     bbf:      	cmovlel	%edx, %r13d
     bc3:      	testq	%rax, %rax
     bc6:      	je	0xf2a <generic_tracepoint_process_event+0xf2a>
     bcc:      	movb	%cl, %bl
     bce:      	addl	%ebx, %ebx
     bd0:      	movq	%rax, %rdx
     bd3:      	jmp	0xbda <generic_tracepoint_process_event+0xbda>
     bd5:      	xorl	%r13d, %r13d
     bd8:      	xorl	%ebx, %ebx
     bda:      	movq	0x28(%rsp), %r15
     bdf:      	leaq	0x4(%r15), %rdi
     be3:      	andl	$0xfff, %r13d           # imm = 0xFFF
     bea:      	movl	$0x4, %eax
     bef:      	movl	%r13d, %esi
     bf2:      	callq	*%rax
     bf4:      	movl	%r13d, (%r15)
     bf7:      	leaq	0x50(%rsp), %rdi
     bfc:      	movl	$0x8, %ecx
     c01:      	movl	$0x4, %eax
     c06:      	movq	0x38(%rsp), %rdx
     c0b:      	movl	$0x8, %esi
     c10:      	callq	*%rax
     c12:      	movq	0x50(%rsp), %rcx
     c17:      	addq	$0x30, %rcx
     c1b:      	leaq	0x98(%rsp), %rdi
     c23:      	movl	$0x8, %edx
     c28:      	movl	$0x4, %eax
     c2d:      	movq	0x50(%rsp), %rdx
     c32:      	addq	$0x30, %rdx
     c36:      	movl	$0x8, %esi
     c3b:      	callq	*%rax
     c3d:      	movq	0x98(%rsp), %rcx
     c45:      	leaq	0x40(%rsp), %rdi
     c4a:      	movl	$0x2, %edx
     c4f:      	movl	$0x4, %eax
     c54:      	movq	0x98(%rsp), %rdx
     c5c:      	movl	$0x2, %esi
     c61:      	callq	*%rax
     c63:      	movl	%ebx, 0x4(%r15,%r13)
     c68:      	movzwl	0x40(%rsp), %eax
     c6d:      	movw	%ax, 0x8(%r15,%r13)
     c73:      	addl	$0xa, %r13d
     c77:      	movq	0x10(%rsp), %rbp
     c7c:      	movq	0x8(%rsp), %rcx
     c81:      	movl	$0x4, %edx
     c86:      	jmp	0x2ffa <generic_tracepoint_process_event+0x2ffa>
     c8b:      	movq	%rsi, 0x38(%rsp)
     c90:      	movq	%r15, 0x20(%rsp)
     c95:      	leaq	0x98(%rsp), %rdi
     c9d:      	leaq	0x50(%rsp), %rdx
     ca2:      	movl	$0x8, %ecx
     ca7:      	movl	$0x4, %eax
     cac:      	movl	$0x8, %esi
     cb1:      	callq	*%rax
     cb3:      	movq	0x98(%rsp), %r15
     cbb:      	testq	%r15, %r15
     cbe:      	jne	0x7d8 <generic_tracepoint_process_event+0x7d8>
     cc4:      	movl	$0x0, 0xc8(%rsp)
     ccf:      	movq	(%rip), %rdi            # 0xcd6 <generic_tracepoint_process_event+0xcd6>
     cd6:      	leaq	0xc8(%rsp), %rsi
     cde:      	movl	$0x1, %eax
     ce3:      	callq	*%rax
     ce5:      	xorl	%r13d, %r13d
     ce8:      	testq	%rax, %rax
     ceb:      	je	0x2fe3 <generic_tracepoint_process_event+0x2fe3>
     cf1:      	cmpl	$0x19, %r12d
     cf5:      	jg	0x102c <generic_tracepoint_process_event+0x102c>
     cfb:      	cmpl	$0x12, %r12d
     cff:      	jle	0x1068 <generic_tracepoint_process_event+0x1068>
     d05:      	cmpl	$0x14, %r12d
     d09:      	jle	0x14d5 <generic_tracepoint_process_event+0x14d5>
     d0f:      	cmpl	$0x15, %r12d
     d13:      	je	0x1c33 <generic_tracepoint_process_event+0x1c33>
     d19:      	cmpl	$0x16, %r12d
     d1d:      	je	0x1bae <generic_tracepoint_process_event+0x1bae>
     d23:      	cmpl	$0x17, %r12d
     d27:      	movq	0x10(%rsp), %rbp
     d2c:      	movq	0x8(%rsp), %rcx
     d31:      	movl	$0x4, %edx
     d36:      	jne	0x2ff2 <generic_tracepoint_process_event+0x2ff2>
     d3c:      	movl	$0x0, 0x4(%rbx)
     d43:      	movq	0x20(%rsp), %rax
     d48:      	movl	%eax, (%rbx)
     d4a:      	movl	$0x8, %r13d
     d50:      	jmp	0x2ff2 <generic_tracepoint_process_event+0x2ff2>
     d55:      	movq	%rsi, 0x38(%rsp)
     d5a:      	movq	%r15, 0x20(%rsp)
     d5f:      	cmpl	$0x28, %r12d
     d63:      	ja	0xcc4 <generic_tracepoint_process_event+0xcc4>
     d69:      	movl	%r12d, %eax
     d6c:      	movabsq	$0x1c1f2027cf2, %rcx    # imm = 0x1C1F2027CF2
     d76:      	btq	%rax, %rcx
     d7a:      	jae	0xcc4 <generic_tracepoint_process_event+0xcc4>
     d80:      	movq	0x20(%rsp), %rax
     d85:      	movq	%rax, 0x30(%rsp)
     d8a:      	movl	$0x0, 0xd0(%rsp)
     d95:      	movq	(%rip), %rdi            # 0xd9c <generic_tracepoint_process_event+0xd9c>
     d9c:      	leaq	0xd0(%rsp), %rsi
     da4:      	movl	$0x1, %eax
     da9:      	callq	*%rax
     dab:      	xorl	%r13d, %r13d
     dae:      	testq	%rax, %rax
     db1:      	je	0x2fe3 <generic_tracepoint_process_event+0x2fe3>
     db7:      	cmpl	$0x10, %r12d
     dbb:      	movq	0x10(%rsp), %rbp
     dc0:      	movl	$0x4, %edx
     dc5:      	jg	0xf32 <generic_tracepoint_process_event+0xf32>
     dcb:      	cmpl	$0x9, %r12d
     dcf:      	movq	0x8(%rsp), %rcx
     dd4:      	jg	0xf73 <generic_tracepoint_process_event+0xf73>
     dda:      	cmpl	$0x4, %r12d
     dde:      	jle	0x10da <generic_tracepoint_process_event+0x10da>
     de4:      	cmpl	$0x5, %r12d
     de8:      	je	0x16a7 <generic_tracepoint_process_event+0x16a7>
     dee:      	cmpl	$0x6, %r12d
     df2:      	je	0xfd5 <generic_tracepoint_process_event+0xfd5>
     df8:      	movq	%rax, 0x20(%rsp)
     dfd:      	cmpl	$0x7, %r12d
     e01:      	movq	0x10(%rsp), %rbp
     e06:      	movq	0x8(%rsp), %rcx
     e0b:      	jne	0x2ff2 <generic_tracepoint_process_event+0x2ff2>
     e11:      	movq	0x30(%rsp), %r15
     e16:      	movq	%rbx, %r13
     e19:      	movq	%r15, 0x28(%rbx)
     e1d:      	leaq	0x26(%rbx), %rdi
     e21:      	leaq	0x10(%r15), %rdx
     e25:      	movl	$0x2, %ecx
     e2a:      	movl	$0x4, %eax
     e2f:      	movl	$0x2, %esi
     e34:      	callq	*%rax
     e36:      	leaq	0x3a(%rbx), %rdi
     e3a:      	leaq	0x12(%r15), %rdx
     e3e:      	movl	$0x1, %ecx
     e43:      	movl	$0x4, %eax
     e48:      	movl	$0x1, %esi
     e4d:      	callq	*%rax
     e4f:      	leaq	0x38(%rbx), %rdi
     e53:      	leaq	0x226(%r15), %rdx
     e5a:      	movl	$0x2, %ecx
     e5f:      	movl	$0x4, %eax
     e64:      	movl	$0x2, %esi
     e69:      	callq	*%rax
     e6b:      	leaq	0x24(%rbx), %rdi
     e6f:      	leaq	0x224(%r15), %rdx
     e76:      	movl	$0x2, %ecx
     e7b:      	movl	$0x4, %eax
     e80:      	movl	$0x2, %esi
     e85:      	callq	*%rax
     e87:      	leaq	0x30(%rbx), %rdi
     e8b:      	leaq	0x21c(%r15), %rdx
     e92:      	movl	$0x4, %ecx
     e97:      	movl	$0x4, %eax
     e9c:      	movl	$0x4, %esi
     ea1:      	callq	*%rax
     ea3:      	leaq	0x34(%rbx), %rdi
     ea7:      	leaq	0x218(%r15), %rdx
     eae:      	movl	$0x4, %ecx
     eb3:      	movl	$0x4, %eax
     eb8:      	movl	$0x4, %esi
     ebd:      	callq	*%rax
     ebf:      	leaq	0x10(%rbx), %r12
     ec3:      	movq	$0x0, (%rbx)
     eca:      	movq	$0x0, 0x8(%rbx)
     ed2:      	movq	$0x0, 0x10(%rbx)
     eda:      	movq	$0x0, 0x18(%rbx)
     ee2:      	movzwl	0x26(%rbx), %eax
     ee6:      	cmpl	$0xa, %eax
     ee9:      	je	0x1f03 <generic_tracepoint_process_event+0x1f03>
     eef:      	cmpl	$0x2, %eax
     ef2:      	jne	0x1f33 <generic_tracepoint_process_event+0x1f33>
     ef8:      	leaq	0x4(%r15), %rdx
     efc:      	movl	$0x4, %ecx
     f01:      	movl	$0x4, %eax
     f06:      	movq	%rbx, %rdi
     f09:      	movl	$0x4, %esi
     f0e:      	callq	*%rax
     f10:      	movl	$0x4, %ecx
     f15:      	movl	$0x4, %eax
     f1a:      	movq	%r12, %rdi
     f1d:      	movl	$0x4, %esi
     f22:      	movq	%r15, %rdx
     f25:      	jmp	0x1f31 <generic_tracepoint_process_event+0x1f31>
     f2a:      	xorl	%r13d, %r13d
     f2d:      	jmp	0x2fff <generic_tracepoint_process_event+0x2fff>
     f32:      	cmpl	$0x1e, %r12d
     f36:      	jg	0xff2 <generic_tracepoint_process_event+0xff2>
     f3c:      	cmpl	$0x1c, %r12d
     f40:      	jg	0x113c <generic_tracepoint_process_event+0x113c>
     f46:      	cmpl	$0x11, %r12d
     f4a:      	je	0x1866 <generic_tracepoint_process_event+0x1866>
     f50:      	movq	%rax, 0x20(%rsp)
     f55:      	cmpl	$0x19, %r12d
     f59:      	je	0x15bf <generic_tracepoint_process_event+0x15bf>
     f5f:      	cmpl	$0x1c, %r12d
     f63:      	movq	0x8(%rsp), %rcx
     f68:      	je	0x10ea <generic_tracepoint_process_event+0x10ea>
     f6e:      	jmp	0x2ff2 <generic_tracepoint_process_event+0x2ff2>
     f73:      	leal	-0xa(%r12), %eax
     f78:      	cmpl	$0x2, %eax
     f7b:      	jb	0x10ea <generic_tracepoint_process_event+0x10ea>
     f81:      	leal	-0xc(%r12), %eax
     f86:      	cmpl	$0x2, %eax
     f89:      	jb	0x1109 <generic_tracepoint_process_event+0x1109>
     f8f:      	cmpl	$0xe, %r12d
     f93:      	jne	0x2ff2 <generic_tracepoint_process_event+0x2ff2>
     f99:      	leaq	0x50(%rsp), %rdi
     f9e:      	leaq	0x30(%rsp), %r15
     fa3:      	movl	$0x8, %ecx
     fa8:      	movl	$0x4, %eax
     fad:      	movl	$0x8, %esi
     fb2:      	movq	%r15, %rdx
     fb5:      	callq	*%rax
     fb7:      	movq	0x50(%rsp), %rcx
     fbc:      	movl	$0x8, %edx
     fc1:      	movl	$0x4, %eax
     fc6:      	movq	0x50(%rsp), %rdx
     fcb:      	movq	%r15, %rdi
     fce:      	movl	$0x8, %esi
     fd3:      	callq	*%rax
     fd5:      	movq	0x30(%rsp), %rdx
     fda:      	leaq	0x4(%rbx), %rdi
     fde:      	movl	$0x1ff, %ecx            # imm = 0x1FF
     fe3:      	movl	$0x2d, %eax
     fe8:      	movl	$0x1ff, %esi            # imm = 0x1FF
     fed:      	jmp	0x1941 <generic_tracepoint_process_event+0x1941>
     ff2:      	cmpl	$0x26, %r12d
     ff6:      	jg	0x116f <generic_tracepoint_process_event+0x116f>
     ffc:      	leal	-0x1f(%r12), %eax
    1001:      	cmpl	$0x2, %eax
    1004:      	jae	0x144f <generic_tracepoint_process_event+0x144f>
    100a:      	leaq	0x30(%rsp), %rdx
    100f:      	movl	$0x4, %r13d
    1015:      	movl	$0x1, %ecx
    101a:      	movl	$0x4, %eax
    101f:      	movq	%rbx, %rdi
    1022:      	movl	$0x1, %esi
    1027:      	jmp	0x1159 <generic_tracepoint_process_event+0x1159>
    102c:      	cmpl	$0x20, %r12d
    1030:      	jle	0x1387 <generic_tracepoint_process_event+0x1387>
    1036:      	leal	-0x21(%r12), %ecx
    103b:      	cmpl	$0x4, %ecx
    103e:      	movq	0x20(%rsp), %rdx
    1043:      	jae	0x1221 <generic_tracepoint_process_event+0x1221>
    1049:      	movl	$0x8, %r13d
    104f:      	movl	$0x8, %ecx
    1054:      	movl	$0x4, %eax
    1059:      	movq	%rbx, %rdi
    105c:      	movl	$0x8, %esi
    1061:      	callq	*%rax
    1063:      	jmp	0x2fe3 <generic_tracepoint_process_event+0x2fe3>
    1068:      	movl	%ebp, %r15d
    106b:      	cmpl	$0x7, %r12d
    106f:      	jg	0x1487 <generic_tracepoint_process_event+0x1487>
    1075:      	cmpl	$0x2, %r12d
    1079:      	je	0x195e <generic_tracepoint_process_event+0x195e>
    107f:      	cmpl	$0x3, %r12d
    1083:      	movq	0x10(%rsp), %rbp
    1088:      	movq	0x8(%rsp), %rcx
    108d:      	movl	$0x4, %edx
    1092:      	jne	0x2ff2 <generic_tracepoint_process_event+0x2ff2>
    1098:      	movq	%rax, %rbx
    109b:      	leaq	0x90(%rax), %r12
    10a2:      	movl	%r15d, %eax
    10a5:      	andl	$0xf, %eax
    10a8:      	cmpl	$0x2, %eax
    10ab:      	jle	0x2095 <generic_tracepoint_process_event+0x2095>
    10b1:      	cmpl	$0x3, %eax
    10b4:      	je	0x229d <generic_tracepoint_process_event+0x229d>
    10ba:      	cmpl	$0x4, %eax
    10bd:      	je	0x22a8 <generic_tracepoint_process_event+0x22a8>
    10c3:      	cmpl	$0x5, %eax
    10c6:      	jne	0x26f5 <generic_tracepoint_process_event+0x26f5>
    10cc:      	movq	%rbx, %rax
    10cf:      	addq	$0x5e70, %rax           # imm = 0x5E70
    10d5:      	jmp	0x22bc <generic_tracepoint_process_event+0x22bc>
    10da:      	cmpl	$0x1, %r12d
    10de:      	je	0x1109 <generic_tracepoint_process_event+0x1109>
    10e0:      	cmpl	$0x4, %r12d
    10e4:      	jne	0x2ff2 <generic_tracepoint_process_event+0x2ff2>
    10ea:      	movl	$0x8, %r13d
    10f0:      	leaq	0x30(%rsp), %rdx
    10f5:      	movl	$0x8, %ecx
    10fa:      	movl	$0x4, %eax
    10ff:      	movq	%rbx, %rdi
    1102:      	movl	$0x8, %esi
    1107:      	jmp	0x1126 <generic_tracepoint_process_event+0x1126>
    1109:      	leaq	0x30(%rsp), %rdx
    110e:      	movl	$0x4, %r13d
    1114:      	movl	$0x4, %ecx
    1119:      	movl	$0x4, %eax
    111e:      	movq	%rbx, %rdi
    1121:      	movl	$0x4, %esi
    1126:      	callq	*%rax
    1128:      	movl	$0x4, %edx
    112d:      	movq	0x8(%rsp), %rcx
    1132:      	movq	0x10(%rsp), %rbp
    1137:      	jmp	0x2ff2 <generic_tracepoint_process_event+0x2ff2>
    113c:      	leaq	0x30(%rsp), %rdx
    1141:      	movl	$0x4, %r13d
    1147:      	movl	$0x2, %ecx
    114c:      	movl	$0x4, %eax
    1151:      	movq	%rbx, %rdi
    1154:      	movl	$0x2, %esi
    1159:      	callq	*%rax
    115b:      	movl	$0x4, %edx
    1160:      	movq	0x10(%rsp), %rbp
    1165:      	movq	0x8(%rsp), %rcx
    116a:      	jmp	0x2ff2 <generic_tracepoint_process_event+0x2ff2>
    116f:      	cmpl	$0x27, %r12d
    1173:      	je	0x1924 <generic_tracepoint_process_event+0x1924>
    1179:      	movq	%rbx, 0x28(%rsp)
    117e:      	cmpl	$0x28, %r12d
    1182:      	movq	0x8(%rsp), %rcx
    1187:      	jne	0x2ff2 <generic_tracepoint_process_event+0x2ff2>
    118d:      	movq	0x30(%rsp), %r15
    1192:      	movq	0x28(%rsp), %rbx
    1197:      	movq	$0x0, 0x10(%rbx)
    119f:      	movq	$0x0, 0x8(%rbx)
    11a7:      	movq	$0x0, (%rbx)
    11ae:      	movl	$0x2, %ecx
    11b3:      	movl	$0x4, %eax
    11b8:      	movq	%rbx, %rdi
    11bb:      	movl	$0x2, %esi
    11c0:      	movq	%r15, %rdx
    11c3:      	callq	*%rax
    11c5:      	testq	%rax, %rax
    11c8:      	js	0x20fe <generic_tracepoint_process_event+0x20fe>
    11ce:      	movzwl	(%rbx), %eax
    11d1:      	cmpl	$0xa, %eax
    11d4:      	je	0x20b5 <generic_tracepoint_process_event+0x20b5>
    11da:      	cmpl	$0x2, %eax
    11dd:      	jne	0x20ef <generic_tracepoint_process_event+0x20ef>
    11e3:      	leaq	0x4(%r15), %rdx
    11e7:      	leaq	0x50(%rsp), %rdi
    11ec:      	movl	$0x4, %ecx
    11f1:      	movl	$0x4, %eax
    11f6:      	movl	$0x4, %esi
    11fb:      	callq	*%rax
    11fd:      	movl	0x50(%rsp), %eax
    1201:      	movq	0x28(%rsp), %rcx
    1206:      	movq	%rax, 0x8(%rcx)
    120a:      	leaq	0x2(%rcx), %rdi
    120e:      	addq	$0x2, %r15
    1212:      	movl	$0x2, %ecx
    1217:      	movl	$0x4, %eax
    121c:      	jmp	0x20e5 <generic_tracepoint_process_event+0x20e5>
    1221:      	movq	%rdx, %r15
    1224:      	movq	%rax, 0x38(%rsp)
    1229:      	cmpl	$0x2b, %r12d
    122d:      	je	0x1d1c <generic_tracepoint_process_event+0x1d1c>
    1233:      	cmpl	$0x29, %r12d
    1237:      	movq	0x10(%rsp), %rbp
    123c:      	movq	0x8(%rsp), %rcx
    1241:      	movl	$0x4, %edx
    1246:      	jne	0x2ff2 <generic_tracepoint_process_event+0x2ff2>
    124c:      	addq	$0x18, %r15
    1250:      	leaq	0x50(%rsp), %rdi
    1255:      	movl	$0x4, %r12d
    125b:      	movl	$0x8, %ecx
    1260:      	movl	$0x4, %eax
    1265:      	movl	$0x8, %esi
    126a:      	movq	%r15, %rdx
    126d:      	callq	*%rax
    126f:      	movq	0x50(%rsp), %r15
    1274:      	testq	%r15, %r15
    1277:      	je	0x2259 <generic_tracepoint_process_event+0x2259>
    127d:      	movq	%rbx, %r13
    1280:      	movq	%r15, 0x28(%rbx)
    1284:      	leaq	0x26(%rbx), %rdi
    1288:      	leaq	0x10(%r15), %rdx
    128c:      	movl	$0x2, %ecx
    1291:      	movl	$0x4, %eax
    1296:      	movl	$0x2, %esi
    129b:      	callq	*%rax
    129d:      	leaq	0x3a(%rbx), %rdi
    12a1:      	leaq	0x12(%r15), %rdx
    12a5:      	movl	$0x1, %ecx
    12aa:      	movl	$0x4, %eax
    12af:      	movl	$0x1, %esi
    12b4:      	callq	*%rax
    12b6:      	leaq	0x38(%rbx), %rdi
    12ba:      	leaq	0x226(%r15), %rdx
    12c1:      	movl	$0x2, %ecx
    12c6:      	movl	$0x4, %eax
    12cb:      	movl	$0x2, %esi
    12d0:      	callq	*%rax
    12d2:      	leaq	0x24(%rbx), %rdi
    12d6:      	leaq	0x224(%r15), %rdx
    12dd:      	movl	$0x2, %ecx
    12e2:      	movl	$0x4, %eax
    12e7:      	movl	$0x2, %esi
    12ec:      	callq	*%rax
    12ee:      	leaq	0x30(%rbx), %rdi
    12f2:      	leaq	0x21c(%r15), %rdx
    12f9:      	movl	$0x4, %eax
    12fe:      	movl	$0x4, %esi
    1303:      	callq	*%rax
    1305:      	leaq	0x34(%rbx), %rdi
    1309:      	leaq	0x218(%r15), %rdx
    1310:      	movl	$0x4, %eax
    1315:      	movl	$0x4, %esi
    131a:      	callq	*%rax
    131c:      	leaq	0x10(%rbx), %r12
    1320:      	movq	$0x0, (%rbx)
    1327:      	movq	$0x0, 0x8(%rbx)
    132f:      	movq	$0x0, 0x10(%rbx)
    1337:      	movq	$0x0, 0x18(%rbx)
    133f:      	movzwl	0x26(%rbx), %eax
    1343:      	cmpl	$0xa, %eax
    1346:      	je	0x21e4 <generic_tracepoint_process_event+0x21e4>
    134c:      	cmpl	$0x2, %eax
    134f:      	jne	0x2214 <generic_tracepoint_process_event+0x2214>
    1355:      	leaq	0x4(%r15), %rdx
    1359:      	movl	$0x4, %ecx
    135e:      	movl	$0x4, %eax
    1363:      	movq	%rbx, %rdi
    1366:      	movl	$0x4, %esi
    136b:      	callq	*%rax
    136d:      	movl	$0x4, %ecx
    1372:      	movl	$0x4, %eax
    1377:      	movq	%r12, %rdi
    137a:      	movl	$0x4, %esi
    137f:      	movq	%r15, %rdx
    1382:      	jmp	0x2212 <generic_tracepoint_process_event+0x2212>
    1387:      	cmpl	$0x1a, %r12d
    138b:      	je	0x1daf <generic_tracepoint_process_event+0x1daf>
    1391:      	cmpl	$0x1b, %r12d
    1395:      	movq	0x10(%rsp), %rbp
    139a:      	movq	0x8(%rsp), %rcx
    139f:      	movl	$0x4, %edx
    13a4:      	jne	0x2ff2 <generic_tracepoint_process_event+0x2ff2>
    13aa:      	movq	$0x0, 0x48(%rbx)
    13b2:      	movq	$0x0, 0x40(%rbx)
    13ba:      	movq	$0x0, 0x38(%rbx)
    13c2:      	movq	$0x0, 0x30(%rbx)
    13ca:      	movq	$0x0, 0x28(%rbx)
    13d2:      	movq	$0x0, 0x20(%rbx)
    13da:      	movq	$0x0, 0x18(%rbx)
    13e2:      	movq	$0x0, 0x10(%rbx)
    13ea:      	movq	$0x0, 0x8(%rbx)
    13f2:      	movq	$0x0, (%rbx)
    13f9:      	leaq	0x10(%rbx), %rdi
    13fd:      	movq	0x20(%rsp), %rax
    1402:      	leaq	0x18(%rax), %rdx
    1406:      	movl	$0x3f, %ecx
    140b:      	movl	$0x2d, %eax
    1410:      	movl	$0x3f, %esi
    1415:      	callq	*%rax
    1417:      	testq	%rax, %rax
    141a:      	js	0x21be <generic_tracepoint_process_event+0x21be>
    1420:      	addq	$0x8, %rbx
    1424:      	movq	0x20(%rsp), %rdx
    1429:      	addq	$0x348, %rdx            # imm = 0x348
    1430:      	movl	$0x8, %ecx
    1435:      	movl	$0x4, %eax
    143a:      	movq	%rbx, %rdi
    143d:      	movl	$0x8, %esi
    1442:      	callq	*%rax
    1444:      	movl	$0x50, %r13d
    144a:      	jmp	0x2fe8 <generic_tracepoint_process_event+0x2fe8>
    144f:      	cmpl	$0x26, %r12d
    1453:      	movq	0x8(%rsp), %rcx
    1458:      	jne	0x2ff2 <generic_tracepoint_process_event+0x2ff2>
    145e:      	movq	0x30(%rsp), %rsi
    1463:      	movzwl	%si, %edx
    1466:      	addq	0xb8(%rsp), %rdx
    146e:      	shrl	$0x10, %esi
    1471:      	andl	$0xfff, %esi            # imm = 0xFFF
    1477:      	leaq	0x4(%rbx), %rdi
    147b:      	incl	%esi
    147d:      	movl	$0x2d, %eax
    1482:      	jmp	0x1941 <generic_tracepoint_process_event+0x1941>
    1487:      	cmpl	$0x8, %r12d
    148b:      	je	0x19bc <generic_tracepoint_process_event+0x19bc>
    1491:      	cmpl	$0x12, %r12d
    1495:      	movq	0x10(%rsp), %rbp
    149a:      	movq	0x8(%rsp), %rcx
    149f:      	movl	$0x4, %edx
    14a4:      	jne	0x2ff2 <generic_tracepoint_process_event+0x2ff2>
    14aa:      	andl	$0x3ff, %r15d           # imm = 0x3FF
    14b1:      	movl	$0x4, %eax
    14b6:      	movq	0x20(%rsp), %rdx
    14bb:      	movq	%rbx, %rdi
    14be:      	movl	%r15d, %esi
    14c1:      	callq	*%rax
    14c3:      	movl	$0x4, %edx
    14c8:      	movq	0x8(%rsp), %rcx
    14cd:      	movq	%r15, %r13
    14d0:      	jmp	0x2ff2 <generic_tracepoint_process_event+0x2ff2>
    14d5:      	cmpl	$0x13, %r12d
    14d9:      	je	0x1cc5 <generic_tracepoint_process_event+0x1cc5>
    14df:      	cmpl	$0x14, %r12d
    14e3:      	movq	0x10(%rsp), %rbp
    14e8:      	movq	0x8(%rsp), %rcx
    14ed:      	movl	$0x4, %edx
    14f2:      	jne	0x2ff2 <generic_tracepoint_process_event+0x2ff2>
    14f8:      	movq	$0x0, 0x50(%rsp)
    1501:      	movq	0x20(%rsp), %r12
    1506:      	leaq	0x110(%r12), %rdx
    150e:      	leaq	0x50(%rsp), %rdi
    1513:      	movl	$0x8, %ecx
    1518:      	movl	$0x4, %eax
    151d:      	leaq	0xd8(%r12), %r15
    1525:      	movl	$0x8, %esi
    152a:      	callq	*%rax
    152c:      	movq	0x50(%rsp), %rcx
    1531:      	movl	$0x80, %edx
    1536:      	movl	$0x2d, %eax
    153b:      	movq	0x50(%rsp), %rdx
    1540:      	movq	%rbx, %rdi
    1543:      	movl	$0x80, %esi
    1548:      	callq	*%rax
    154a:      	leaq	0x90(%rbx), %rdi
    1551:      	movl	$0x4, %ecx
    1556:      	movl	$0x4, %eax
    155b:      	movl	$0x4, %esi
    1560:      	movq	%r15, %rdx
    1563:      	callq	*%rax
    1565:      	leaq	0x80(%rbx), %rdi
    156c:      	leaq	0xe0(%r12), %rdx
    1574:      	movl	$0x8, %ecx
    1579:      	movl	$0x4, %eax
    157e:      	movl	$0x8, %esi
    1583:      	callq	*%rax
    1585:      	addq	$0x88, %rbx
    158c:      	addq	$0x118, %r12            # imm = 0x118
    1593:      	movl	$0x8, %ecx
    1598:      	movl	$0x4, %eax
    159d:      	movq	%rbx, %rdi
    15a0:      	movl	$0x8, %esi
    15a5:      	movq	%r12, %rdx
    15a8:      	callq	*%rax
    15aa:      	movl	$0x4, %edx
    15af:      	movq	0x8(%rsp), %rcx
    15b4:      	movl	$0x98, %r13d
    15ba:      	jmp	0x2ff2 <generic_tracepoint_process_event+0x2ff2>
    15bf:      	movq	0x30(%rsp), %r15
    15c4:      	leaq	0xc0(%rsp), %rdi
    15cc:      	movl	$0x1, %ecx
    15d1:      	movl	$0x4, %eax
    15d6:      	movl	$0x1, %esi
    15db:      	movq	%r15, %rdx
    15de:      	callq	*%rax
    15e0:      	cmpb	$0x1, 0xc0(%rsp)
    15e8:      	jne	0x1e2d <generic_tracepoint_process_event+0x1e2d>
    15ee:      	addq	$0x10, %r15
    15f2:      	leaq	0x50(%rsp), %rdi
    15f7:      	movl	$0x8, %ecx
    15fc:      	movl	$0x4, %eax
    1601:      	movl	$0x8, %esi
    1606:      	movq	%r15, %rdx
    1609:      	callq	*%rax
    160b:      	movq	0x50(%rsp), %rdx
    1610:      	leaq	0x98(%rsp), %rdi
    1618:      	movl	$0x8, %ecx
    161d:      	movl	$0x4, %eax
    1622:      	movl	$0x8, %esi
    1627:      	callq	*%rax
    1629:      	movq	0x50(%rsp), %rdx
    162e:      	addq	$0x8, %rdx
    1632:      	leaq	0x40(%rsp), %rdi
    1637:      	movl	$0x8, %ecx
    163c:      	movl	$0x4, %eax
    1641:      	movl	$0x8, %esi
    1646:      	callq	*%rax
    1648:      	movq	0x98(%rsp), %rdx
    1650:      	movq	0x40(%rsp), %r15
    1655:      	cmpq	$0xfff, %r15            # imm = 0xFFF
    165c:      	movl	$0xfff, %r13d           # imm = 0xFFF
    1662:      	cmovbq	%r15, %r13
    1666:      	movq	0x20(%rsp), %rbx
    166b:      	movq	0x38(%rsp), %rcx
    1670:      	leaq	(%rbx,%rcx), %rdi
    1674:      	addq	$0x98, %rdi
    167b:      	movl	$0x4, %eax
    1680:      	addq	%rcx, %rbx
    1683:      	addq	$0x90, %rbx
    168a:      	movl	%r13d, %esi
    168d:      	callq	*%rax
    168f:      	testl	%eax, %eax
    1691:      	js	0x2084 <generic_tracepoint_process_event+0x2084>
    1697:      	movl	%r15d, (%rbx)
    169a:      	movl	%r13d, 0x4(%rbx)
    169e:      	addq	$0x8, %r13
    16a2:      	jmp	0x2fe3 <generic_tracepoint_process_event+0x2fe3>
    16a7:      	movq	0x30(%rsp), %r12
    16ac:      	leaq	0x28(%rbx), %rdi
    16b0:      	leaq	0x98(%r12), %rdx
    16b8:      	movl	$0x4, %ecx
    16bd:      	movl	$0x4, %eax
    16c2:      	movl	$0x4, %esi
    16c7:      	callq	*%rax
    16c9:      	leaq	0x2c(%rbx), %rdi
    16cd:      	leaq	0x70(%r12), %rdx
    16d2:      	movl	$0x4, %ecx
    16d7:      	movl	$0x4, %eax
    16dc:      	movl	$0x4, %esi
    16e1:      	callq	*%rax
    16e3:      	leaq	0x30(%rbx), %rdi
    16e7:      	leaq	0x90(%r12), %rdx
    16ef:      	movl	$0x4, %ecx
    16f4:      	movl	$0x4, %eax
    16f9:      	movl	$0x4, %esi
    16fe:      	callq	*%rax
    1700:      	movq	%rbx, 0x28(%rsp)
    1705:      	leaq	0x34(%rbx), %rdi
    1709:      	leaq	0xa8(%r12), %rdx
    1711:      	movl	$0x4, %ecx
    1716:      	movl	$0x4, %eax
    171b:      	movl	$0x4, %esi
    1720:      	callq	*%rax
    1722:      	movq	$0x0, 0x50(%rsp)
    172b:      	leaq	0xc8(%r12), %rdx
    1733:      	leaq	0x50(%rsp), %rdi
    1738:      	movl	$0x8, %ecx
    173d:      	movl	$0x4, %eax
    1742:      	movl	$0x8, %esi
    1747:      	callq	*%rax
    1749:      	leaq	0xb8(%r12), %rdx
    1751:      	leaq	0xc0(%rsp), %rdi
    1759:      	movl	$0x2, %ecx
    175e:      	movl	$0x4, %eax
    1763:      	movl	$0x2, %esi
    1768:      	callq	*%rax
    176a:      	movzwl	0xc0(%rsp), %r15d
    1773:      	addq	0x50(%rsp), %r15
    1778:      	leaq	0x97(%rsp), %rdi
    1780:      	movl	$0x1, %ecx
    1785:      	movl	$0x4, %eax
    178a:      	movl	$0x1, %esi
    178f:      	movq	%r15, %rdx
    1792:      	callq	*%rax
    1794:      	movzbl	0x97(%rsp), %eax
    179c:      	shrl	$0x4, %eax
    179f:      	cmpl	$0x6, %eax
    17a2:      	je	0x1e5a <generic_tracepoint_process_event+0x1e5a>
    17a8:      	cmpl	$0x4, %eax
    17ab:      	jne	0x2fdd <generic_tracepoint_process_event+0x2fdd>
    17b1:      	leaq	0x9(%r15), %rdx
    17b5:      	leaq	0xb4(%rsp), %rdi
    17bd:      	movl	$0x1, %ecx
    17c2:      	movl	$0x4, %eax
    17c7:      	movl	$0x1, %esi
    17cc:      	callq	*%rax
    17ce:      	movzbl	0xb4(%rsp), %eax
    17d6:      	movq	0x28(%rsp), %rdi
    17db:      	movw	%ax, 0x24(%rdi)
    17df:      	movw	$0x2, 0x26(%rdi)
    17e5:      	leaq	0xc(%r15), %rdx
    17e9:      	movq	$0x0, (%rdi)
    17f0:      	movq	$0x0, 0x8(%rdi)
    17f8:      	movq	$0x0, 0x10(%rdi)
    1800:      	movq	$0x0, 0x18(%rdi)
    1808:      	movl	$0x4, %ecx
    180d:      	movl	$0x4, %eax
    1812:      	leaq	0x10(%rdi), %r13
    1816:      	movl	$0x4, %esi
    181b:      	callq	*%rax
    181d:      	addq	$0x10, %r15
    1821:      	movl	$0x4, %ecx
    1826:      	movl	$0x4, %eax
    182b:      	movq	%r13, %rdi
    182e:      	movl	$0x4, %esi
    1833:      	movq	%r15, %rdx
    1836:      	callq	*%rax
    1838:      	leaq	0xb6(%r12), %rdx
    1840:      	leaq	0xc8(%rsp), %rdi
    1848:      	movl	$0x2, %ecx
    184d:      	movl	$0x4, %eax
    1852:      	movl	$0x2, %esi
    1857:      	callq	*%rax
    1859:      	movzbl	0xb4(%rsp), %ebx
    1861:      	jmp	0x2e78 <generic_tracepoint_process_event+0x2e78>
    1866:      	movq	$0x0, 0x58(%rsp)
    186f:      	movl	$0xe, %eax
    1874:      	callq	*%rax
    1876:      	shrq	$0x20, %rax
    187a:      	movq	%rax, 0x50(%rsp)
    187f:      	leaq	0x98(%rsp), %rdi
    1887:      	leaq	0x30(%rsp), %rdx
    188c:      	movl	$0x4, %ecx
    1891:      	movl	$0x4, %eax
    1896:      	movl	$0x4, %ebp
    189b:      	movl	$0x4, %esi
    18a0:      	callq	*%rax
    18a2:      	movl	0x98(%rsp), %eax
    18a9:      	movl	%eax, 0x58(%rsp)
    18ad:      	movq	(%rip), %rdi            # 0x18b4 <generic_tracepoint_process_event+0x18b4>
    18b4:      	leaq	0x50(%rsp), %rsi
    18b9:      	movl	$0x1, %eax
    18be:      	callq	*%rax
    18c0:      	testq	%rax, %rax
    18c3:      	je	0x1e4e <generic_tracepoint_process_event+0x1e4e>
    18c9:      	movl	(%rax), %r13d
    18cc:      	leaq	0x98(%rsp), %rdx
    18d4:      	movq	%rax, %r15
    18d7:      	movl	$0x4, %eax
    18dc:      	movq	%rbx, %rdi
    18df:      	movl	$0x4, %esi
    18e4:      	callq	*%rax
    18e6:      	andl	$0xfff, %r13d           # imm = 0xFFF
    18ed:      	leaq	0x4(%rbx), %rdi
    18f1:      	leaq	0x4(%r13), %rsi
    18f5:      	movl	$0x4, %eax
    18fa:      	movq	%r15, %rdx
    18fd:      	callq	*%rax
    18ff:      	leaq	(%rbx,%r13), %rdi
    1903:      	addq	$0x8, %rdi
    1907:      	leaq	(%r15,%r13), %rdx
    190b:      	addq	$0x4, %rdx
    190f:      	movl	$0x4, %eax
    1914:      	movl	$0x4, %esi
    1919:      	callq	*%rax
    191b:      	addq	$0xc, %r13
    191f:      	jmp	0x2fe3 <generic_tracepoint_process_event+0x2fe3>
    1924:      	movl	$0x120, %edx            # imm = 0x120
    1929:      	addq	0x30(%rsp), %rdx
    192e:      	leaq	0x4(%rbx), %rdi
    1932:      	movl	$0x11, %ecx
    1937:      	movl	$0x2d, %eax
    193c:      	movl	$0x11, %esi
    1941:      	callq	*%rax
    1943:      	movq	%rax, %r13
    1946:      	testq	%rax, %rax
    1949:      	js	0x2fe3 <generic_tracepoint_process_event+0x2fe3>
    194f:      	leal	-0x1(%r13), %eax
    1953:      	movl	%eax, (%rbx)
    1955:      	addq	$0x3, %r13
    1959:      	jmp	0x2fe3 <generic_tracepoint_process_event+0x2fe3>
    195e:      	movq	%rax, %r15
    1961:      	movq	0x38(%rsp), %rcx
    1966:      	leaq	(%rax,%rcx), %rbx
    196a:      	addq	$0x90, %rbx
    1971:      	movq	$0x0, 0xd0(%rsp)
    197d:      	testb	$0x10, %bpl
    1981:      	jne	0x1fb8 <generic_tracepoint_process_event+0x1fb8>
    1987:      	andl	$0xf, %ebp
    198a:      	xorl	%eax, %eax
    198c:      	cmpl	$0x2, %ebp
    198f:      	jle	0x21c6 <generic_tracepoint_process_event+0x21c6>
    1995:      	cmpl	$0x3, %ebp
    1998:      	je	0x28b2 <generic_tracepoint_process_event+0x28b2>
    199e:      	cmpl	$0x4, %ebp
    19a1:      	je	0x28bb <generic_tracepoint_process_event+0x28bb>
    19a7:      	cmpl	$0x5, %ebp
    19aa:      	jne	0x28ce <generic_tracepoint_process_event+0x28ce>
    19b0:      	addq	$0x5e70, %r15           # imm = 0x5E70
    19b7:      	jmp	0x28cb <generic_tracepoint_process_event+0x28cb>
    19bc:      	leaq	0x28(%rbx), %r13
    19c0:      	leaq	0x40(%rbx), %r15
    19c4:      	movq	0x20(%rsp), %r12
    19c9:      	leaq	0x8(%r12), %rdx
    19ce:      	movl	$0x4, %ecx
    19d3:      	movl	$0x4, %eax
    19d8:      	movq	%rbx, %rdi
    19db:      	movl	$0x4, %esi
    19e0:      	callq	*%rax
    19e2:      	leaq	0x4(%rbx), %rdi
    19e6:      	leaq	0xc(%r12), %rdx
    19eb:      	movl	$0x4, %ecx
    19f0:      	movl	$0x4, %eax
    19f5:      	movl	$0x4, %esi
    19fa:      	callq	*%rax
    19fc:      	leaq	0x10(%rbx), %rdi
    1a00:      	leaq	0x18(%r12), %rdx
    1a05:      	movl	$0x4, %ecx
    1a0a:      	movl	$0x4, %eax
    1a0f:      	movl	$0x4, %esi
    1a14:      	callq	*%rax
    1a16:      	leaq	0x14(%rbx), %rdi
    1a1a:      	leaq	0x1c(%r12), %rdx
    1a1f:      	movl	$0x4, %ecx
    1a24:      	movl	$0x4, %eax
    1a29:      	movl	$0x4, %esi
    1a2e:      	callq	*%rax
    1a30:      	leaq	0x8(%rbx), %rdi
    1a34:      	leaq	0x10(%r12), %rdx
    1a39:      	movl	$0x4, %ecx
    1a3e:      	movl	$0x4, %eax
    1a43:      	movl	$0x4, %esi
    1a48:      	callq	*%rax
    1a4a:      	leaq	0xc(%rbx), %rdi
    1a4e:      	leaq	0x14(%r12), %rdx
    1a53:      	movl	$0x4, %ecx
    1a58:      	movl	$0x4, %eax
    1a5d:      	movl	$0x4, %esi
    1a62:      	callq	*%rax
    1a64:      	leaq	0x18(%rbx), %rdi
    1a68:      	leaq	0x20(%r12), %rdx
    1a6d:      	movl	$0x4, %ecx
    1a72:      	movl	$0x4, %eax
    1a77:      	movl	$0x4, %esi
    1a7c:      	callq	*%rax
    1a7e:      	leaq	0x1c(%rbx), %rdi
    1a82:      	leaq	0x24(%r12), %rdx
    1a87:      	movl	$0x4, %ecx
    1a8c:      	movl	$0x4, %eax
    1a91:      	movl	$0x4, %esi
    1a96:      	callq	*%rax
    1a98:      	movl	$0x0, 0x24(%rbx)
    1a9f:      	leaq	0x20(%rbx), %rdi
    1aa3:      	leaq	0x28(%r12), %rdx
    1aa8:      	movl	$0x4, %ecx
    1aad:      	movl	$0x4, %eax
    1ab2:      	movl	$0x4, %esi
    1ab7:      	callq	*%rax
    1ab9:      	leaq	0x30(%rbx), %rdi
    1abd:      	leaq	0x40(%r12), %rdx
    1ac2:      	movl	$0x8, %ecx
    1ac7:      	movl	$0x4, %eax
    1acc:      	movl	$0x8, %esi
    1ad1:      	callq	*%rax
    1ad3:      	leaq	0x38(%rbx), %rdi
    1ad7:      	leaq	0x30(%r12), %rdx
    1adc:      	movl	$0x8, %ecx
    1ae1:      	movl	$0x4, %eax
    1ae6:      	movl	$0x8, %esi
    1aeb:      	callq	*%rax
    1aed:      	leaq	0x38(%r12), %rdx
    1af2:      	movl	$0x8, %ecx
    1af7:      	movl	$0x4, %eax
    1afc:      	movq	%r13, %rdi
    1aff:      	movl	$0x8, %esi
    1b04:      	callq	*%rax
    1b06:      	addq	$0x90, %r12
    1b0d:      	leaq	0x50(%rsp), %rdi
    1b12:      	movl	$0x8, %ecx
    1b17:      	movl	$0x4, %eax
    1b1c:      	movl	$0x8, %esi
    1b21:      	movq	%r12, %rdx
    1b24:      	callq	*%rax
    1b26:      	movq	0x50(%rsp), %r12
    1b2b:      	leaq	0xc8(%r12), %rdx
    1b33:      	movl	$0x4, %ecx
    1b38:      	movl	$0x4, %eax
    1b3d:      	movq	%r15, %rdi
    1b40:      	movl	$0x4, %esi
    1b45:      	callq	*%rax
    1b47:      	leaq	0x44(%rbx), %rdi
    1b4b:      	leaq	0xcc(%r12), %rdx
    1b53:      	movl	$0x4, %ecx
    1b58:      	movl	$0x4, %eax
    1b5d:      	movl	$0x4, %esi
    1b62:      	callq	*%rax
    1b64:      	leaq	0x48(%rbx), %rdi
    1b68:      	leaq	0xd0(%r12), %rdx
    1b70:      	movl	$0x4, %ecx
    1b75:      	movl	$0x4, %eax
    1b7a:      	movl	$0x4, %esi
    1b7f:      	callq	*%rax
    1b81:      	addq	$0x4c, %rbx
    1b85:      	addq	$0x158, %r12            # imm = 0x158
    1b8c:      	movl	$0x4, %ecx
    1b91:      	movl	$0x4, %eax
    1b96:      	movq	%rbx, %rdi
    1b99:      	movl	$0x4, %esi
    1b9e:      	movq	%r12, %rdx
    1ba1:      	callq	*%rax
    1ba3:      	movl	$0x50, %r13d
    1ba9:      	jmp	0x2fe3 <generic_tracepoint_process_event+0x2fe3>
    1bae:      	movq	0x20(%rsp), %r15
    1bb3:      	leaq	0xc8(%r15), %rdx
    1bba:      	movl	$0x4, %ecx
    1bbf:      	movl	$0x4, %eax
    1bc4:      	movq	%rbx, %rdi
    1bc7:      	movl	$0x4, %esi
    1bcc:      	callq	*%rax
    1bce:      	leaq	0x4(%rbx), %rdi
    1bd2:      	leaq	0xcc(%r15), %rdx
    1bd9:      	movl	$0x4, %ecx
    1bde:      	movl	$0x4, %eax
    1be3:      	movl	$0x4, %esi
    1be8:      	callq	*%rax
    1bea:      	leaq	0x8(%rbx), %rdi
    1bee:      	leaq	0xd0(%r15), %rdx
    1bf5:      	movl	$0x4, %ecx
    1bfa:      	movl	$0x4, %eax
    1bff:      	movl	$0x4, %esi
    1c04:      	callq	*%rax
    1c06:      	addq	$0xc, %rbx
    1c0a:      	addq	$0x158, %r15            # imm = 0x158
    1c11:      	movl	$0x4, %ecx
    1c16:      	movl	$0x4, %eax
    1c1b:      	movq	%rbx, %rdi
    1c1e:      	movl	$0x4, %esi
    1c23:      	movq	%r15, %rdx
    1c26:      	callq	*%rax
    1c28:      	movl	$0x10, %r13d
    1c2e:      	jmp	0x2fe3 <generic_tracepoint_process_event+0x2fe3>
    1c33:      	movq	0x20(%rsp), %r15
    1c38:      	leaq	0x38(%r15), %rdx
    1c3c:      	movl	$0x4, %ecx
    1c41:      	movl	$0x4, %eax
    1c46:      	movq	%rbx, %rdi
    1c49:      	movl	$0x4, %esi
    1c4e:      	callq	*%rax
    1c50:      	leaq	0x4(%rbx), %rdi
    1c54:      	leaq	0x3c(%r15), %rdx
    1c58:      	movl	$0x4, %ecx
    1c5d:      	movl	$0x4, %eax
    1c62:      	movl	$0x4, %esi
    1c67:      	callq	*%rax
    1c69:      	leaq	0x8(%rbx), %rdi
    1c6d:      	leaq	0x40(%r15), %rdx
    1c71:      	movl	$0x4, %ecx
    1c76:      	movl	$0x4, %eax
    1c7b:      	movl	$0x4, %esi
    1c80:      	callq	*%rax
    1c82:      	leaq	0xc(%rbx), %rdi
    1c86:      	leaq	0x44(%r15), %rdx
    1c8a:      	movl	$0x4, %ecx
    1c8f:      	movl	$0x4, %eax
    1c94:      	movl	$0x4, %esi
    1c99:      	callq	*%rax
    1c9b:      	addq	$0x10, %rbx
    1c9f:      	subq	$-0x80, %r15
    1ca3:      	movl	$0x10, %ecx
    1ca8:      	movl	$0x4, %eax
    1cad:      	movq	%rbx, %rdi
    1cb0:      	movl	$0x10, %esi
    1cb5:      	movq	%r15, %rdx
    1cb8:      	callq	*%rax
    1cba:      	movl	$0x20, %r13d
    1cc0:      	jmp	0x2fe3 <generic_tracepoint_process_event+0x2fe3>
    1cc5:      	movl	$0x4, %ecx
    1cca:      	movl	$0x4, %eax
    1ccf:      	movq	0x20(%rsp), %r15
    1cd4:      	movq	%rbx, %rdi
    1cd7:      	movl	$0x4, %esi
    1cdc:      	movq	%r15, %rdx
    1cdf:      	callq	*%rax
    1ce1:      	leaq	0x4(%rbx), %rdi
    1ce5:      	leaq	0x4(%r15), %rdx
    1ce9:      	movl	$0x4, %ecx
    1cee:      	movl	$0x4, %eax
    1cf3:      	movl	$0x4, %esi
    1cf8:      	callq	*%rax
    1cfa:      	addq	$0x8, %rbx
    1cfe:      	addq	$0x30, %r15
    1d02:      	movl	$0x10, %ecx
    1d07:      	movl	$0x4, %eax
    1d0c:      	movq	%rbx, %rdi
    1d0f:      	movl	$0x10, %esi
    1d14:      	movq	%r15, %rdx
    1d17:      	jmp	0x1da2 <generic_tracepoint_process_event+0x1da2>
    1d1c:      	leaq	0x4(%r15), %rdx
    1d20:      	leaq	0x50(%rsp), %rdi
    1d25:      	movl	$0x4, %ecx
    1d2a:      	movl	$0x4, %eax
    1d2f:      	movl	$0x4, %esi
    1d34:      	callq	*%rax
    1d36:      	movl	0x50(%rsp), %eax
    1d3a:      	movl	%eax, (%rbx)
    1d3c:      	leaq	0xc(%r15), %rdx
    1d40:      	leaq	0x50(%rsp), %rdi
    1d45:      	movl	$0x4, %ecx
    1d4a:      	movl	$0x4, %eax
    1d4f:      	movl	$0x4, %esi
    1d54:      	callq	*%rax
    1d56:      	movl	0x50(%rsp), %eax
    1d5a:      	movl	%eax, 0x4(%rbx)
    1d5d:      	addq	$0x50, %r15
    1d61:      	leaq	0x50(%rsp), %rdi
    1d66:      	movl	$0x8, %ecx
    1d6b:      	movl	$0x2d, %eax
    1d70:      	movl	$0x8, %esi
    1d75:      	movq	%r15, %rdx
    1d78:      	callq	*%rax
    1d7a:      	addq	$0x8, %rbx
    1d7e:      	movl	$0x3f8, %edx            # imm = 0x3F8
    1d83:      	movq	0x50(%rsp), %rcx
    1d88:      	addq	%rdx, %rcx
    1d8b:      	movl	$0x10, %esi
    1d90:      	movl	$0x2d, %eax
    1d95:      	addq	0x50(%rsp), %rdx
    1d9a:      	movq	%rbx, %rdi
    1d9d:      	movl	$0x10, %esi
    1da2:      	callq	*%rax
    1da4:      	movl	$0x18, %r13d
    1daa:      	jmp	0x2fe3 <generic_tracepoint_process_event+0x2fe3>
    1daf:      	movq	$0x0, 0x48(%rbx)
    1db7:      	movq	$0x0, 0x40(%rbx)
    1dbf:      	movq	$0x0, 0x38(%rbx)
    1dc7:      	movq	$0x0, 0x30(%rbx)
    1dcf:      	movq	$0x0, 0x28(%rbx)
    1dd7:      	movq	$0x0, 0x20(%rbx)
    1ddf:      	movq	$0x0, 0x18(%rbx)
    1de7:      	movq	$0x0, 0x10(%rbx)
    1def:      	movq	$0x0, 0x8(%rbx)
    1df7:      	movq	$0x0, (%rbx)
    1dfe:      	leaq	0x50(%rsp), %rdi
    1e03:      	movl	$0x8, %ecx
    1e08:      	movl	$0x4, %eax
    1e0d:      	movq	0x20(%rsp), %rdx
    1e12:      	movl	$0x8, %esi
    1e17:      	movq	%rdx, %r15
    1e1a:      	callq	*%rax
    1e1c:      	testq	%rax, %rax
    1e1f:      	je	0x2109 <generic_tracepoint_process_event+0x2109>
    1e25:      	xorl	%r13d, %r13d
    1e28:      	jmp	0x2fe3 <generic_tracepoint_process_event+0x2fe3>
    1e2d:      	movq	0x20(%rsp), %rax
    1e32:      	movq	0x38(%rsp), %rcx
    1e37:      	movq	$0x0, 0x90(%rax,%rcx)
    1e43:      	movl	$0x8, %r13d
    1e49:      	jmp	0x2fe3 <generic_tracepoint_process_event+0x2fe3>
    1e4e:      	movq	$-0x1, %r13
    1e55:      	jmp	0x2fe3 <generic_tracepoint_process_event+0x2fe3>
    1e5a:      	movq	0x50(%rsp), %r15
    1e5f:      	movl	$0x0, 0x98(%rsp)
    1e6a:      	movzwl	0xc0(%rsp), %ebx
    1e72:      	movq	(%rip), %rdi            # 0x1e79 <generic_tracepoint_process_event+0x1e79>
    1e79:      	leaq	0x98(%rsp), %rsi
    1e81:      	movl	$0x1, %eax
    1e86:      	leaq	(%r15,%rbx), %r13
    1e8a:      	callq	*%rax
    1e8c:      	testq	%rax, %rax
    1e8f:      	je	0x2e27 <generic_tracepoint_process_event+0x2e27>
    1e95:      	movq	%rax, %rbp
    1e98:      	movw	%bx, (%rax)
    1e9b:      	movb	$-0x1, 0x5(%rax)
    1e9f:      	movb	$0x0, 0x7(%rax)
    1ea3:      	movq	%rax, %rdi
    1ea6:      	addq	$0x6, %rdi
    1eaa:      	leaq	0x6(%r13), %rdx
    1eae:      	movl	$0x1, %ecx
    1eb3:      	movl	$0x4, %eax
    1eb8:      	movq	%rdi, 0x20(%rsp)
    1ebd:      	movl	$0x1, %esi
    1ec2:      	callq	*%rax
    1ec4:      	testq	%rax, %rax
    1ec7:      	js	0x2e27 <generic_tracepoint_process_event+0x2e27>
    1ecd:      	movzbl	0x5(%rbp), %eax
    1ed1:      	cmpl	$0x32, %eax
    1ed4:      	jg	0x27ff <generic_tracepoint_process_event+0x27ff>
    1eda:      	testl	%eax, %eax
    1edc:      	je	0x28a2 <generic_tracepoint_process_event+0x28a2>
    1ee2:      	cmpl	$0x2b, %eax
    1ee5:      	je	0x28a2 <generic_tracepoint_process_event+0x28a2>
    1eeb:      	cmpl	$0x2c, %eax
    1eee:      	jne	0x29fe <generic_tracepoint_process_event+0x29fe>
    1ef4:      	movw	$0x8, 0x2(%rbp)
    1efa:      	movw	$0x8, %ax
    1efe:      	jmp	0x2954 <generic_tracepoint_process_event+0x2954>
    1f03:      	leaq	0x48(%r15), %rdx
    1f07:      	movl	$0x10, %ecx
    1f0c:      	movl	$0x4, %eax
    1f11:      	movq	%rbx, %rdi
    1f14:      	movl	$0x10, %esi
    1f19:      	callq	*%rax
    1f1b:      	leaq	0x38(%r15), %rdx
    1f1f:      	movl	$0x10, %ecx
    1f24:      	movl	$0x4, %eax
    1f29:      	movq	%r12, %rdi
    1f2c:      	movl	$0x10, %esi
    1f31:      	callq	*%rax
    1f33:      	leaq	0x20(%rbx), %rdi
    1f37:      	leaq	0xc(%r15), %r12
    1f3b:      	addq	$0xe, %r15
    1f3f:      	movl	$0x2, %ecx
    1f44:      	movl	$0x4, %eax
    1f49:      	movl	$0x2, %esi
    1f4e:      	movq	%r15, %rdx
    1f51:      	callq	*%rax
    1f53:      	leaq	0x22(%rbx), %rdi
    1f57:      	movl	$0x2, %ecx
    1f5c:      	movl	$0x4, %eax
    1f61:      	movl	$0x2, %esi
    1f66:      	movq	%r12, %rdx
    1f69:      	callq	*%rax
    1f6b:      	movzwl	0x22(%rbx), %eax
    1f6f:      	movbew	%ax, 0x22(%rbx)
    1f75:      	movq	0x30(%rsp), %rax
    1f7a:      	movq	%rax, 0x50(%rsp)
    1f7f:      	movq	(%rip), %rdi            # 0x1f86 <generic_tracepoint_process_event+0x1f86>
    1f86:      	leaq	0x50(%rsp), %rsi
    1f8b:      	movl	$0x1, %eax
    1f90:      	callq	*%rax
    1f92:      	testq	%rax, %rax
    1f95:      	je	0x2fdd <generic_tracepoint_process_event+0x2fdd>
    1f9b:      	movl	(%rax), %ecx
    1f9d:      	movq	0x20(%rsp), %rbx
    1fa2:      	movl	%ecx, 0x10(%rbx)
    1fa5:      	movq	0x8(%rax), %rcx
    1fa9:      	movq	%rcx, 0x18(%rbx)
    1fad:      	movl	0x4(%rax), %eax
    1fb0:      	movl	%eax, 0x7c(%rbx)
    1fb3:      	jmp	0x2fdd <generic_tracepoint_process_event+0x2fdd>
    1fb8:      	movl	$0xe, %eax
    1fbd:      	callq	*%rax
    1fbf:      	cmpq	$-0x16, %rax
    1fc3:      	jne	0x1fec <generic_tracepoint_process_event+0x1fec>
    1fc5:      	movq	0xb8(%rsp), %rax
    1fcd:      	leaq	0x20(%rax), %rdx
    1fd1:      	leaq	0x50(%rsp), %rdi
    1fd6:      	movl	$0x8, %ecx
    1fdb:      	movl	$0x4, %eax
    1fe0:      	movl	$0x8, %esi
    1fe5:      	callq	*%rax
    1fe7:      	movq	0x50(%rsp), %rax
    1fec:      	movq	0x8(%r15), %rcx
    1ff0:      	movq	0x60(%r15), %rdx
    1ff4:      	movq	%rcx, 0x50(%rsp)
    1ff9:      	movq	0x20(%rsp), %rcx
    1ffe:      	movq	%rcx, 0x58(%rsp)
    2003:      	movq	$0x0, 0x60(%rsp)
    200c:      	movq	%rdx, 0x98(%rsp)
    2014:      	movq	%rax, 0xa0(%rsp)
    201c:      	movq	(%rip), %rdi            # 0x2023 <generic_tracepoint_process_event+0x2023>
    2023:      	xorl	%ecx, %ecx
    2025:      	leaq	0x98(%rsp), %rsi
    202d:      	leaq	0x50(%rsp), %rdx
    2032:      	movl	$0x2, %eax
    2037:      	xorl	%ecx, %ecx
    2039:      	callq	*%rax
    203b:      	testq	%rax, %rax
    203e:      	je	0x2855 <generic_tracepoint_process_event+0x2855>
    2044:      	negl	%eax
    2046:      	movw	%ax, 0x40(%rsp)
    204b:      	movw	$0x5, 0x42(%rsp)
    2052:      	movabsq	$0x200000046, %rax      # imm = 0x200000046
    205c:      	movq	%rax, 0x44(%rsp)
    2061:      	movq	(%rip), %rdi            # 0x2068 <generic_tracepoint_process_event+0x2068>
    2068:      	leaq	0x40(%rsp), %rsi
    206d:      	movl	$0x1, %eax
    2072:      	callq	*%rax
    2074:      	testq	%rax, %rax
    2077:      	je	0x282b <generic_tracepoint_process_event+0x282b>
    207d:      	incl	(%rax)
    207f:      	jmp	0x2855 <generic_tracepoint_process_event+0x2855>
    2084:      	movl	$0xfffffffe, (%rbx)     # imm = 0xFFFFFFFE
    208a:      	movl	$0x4, %r13d
    2090:      	jmp	0x2fe3 <generic_tracepoint_process_event+0x2fe3>
    2095:      	cmpl	$0x1, %eax
    2098:      	je	0x22b3 <generic_tracepoint_process_event+0x22b3>
    209e:      	cmpl	$0x2, %eax
    20a1:      	jne	0x26f5 <generic_tracepoint_process_event+0x26f5>
    20a7:      	movq	%rbx, %rax
    20aa:      	addq	$0x5e58, %rax           # imm = 0x5E58
    20b0:      	jmp	0x22bc <generic_tracepoint_process_event+0x22bc>
    20b5:      	movq	0x28(%rsp), %rbx
    20ba:      	leaq	0x8(%rbx), %rdi
    20be:      	leaq	0x8(%r15), %rdx
    20c2:      	movl	$0x10, %ecx
    20c7:      	movl	$0x4, %eax
    20cc:      	movl	$0x10, %esi
    20d1:      	callq	*%rax
    20d3:      	leaq	0x2(%rbx), %rdi
    20d7:      	addq	$0x2, %r15
    20db:      	movl	$0x2, %ecx
    20e0:      	movl	$0x4, %eax
    20e5:      	movl	$0x2, %esi
    20ea:      	movq	%r15, %rdx
    20ed:      	callq	*%rax
    20ef:      	movq	0x28(%rsp), %rcx
    20f4:      	movzwl	0x2(%rcx), %eax
    20f8:      	movbew	%ax, 0x2(%rcx)
    20fe:      	movl	$0x18, %r13d
    2104:      	jmp	0x2fe3 <generic_tracepoint_process_event+0x2fe3>
    2109:      	leaq	0x10(%rbx), %rdi
    210d:      	movq	0x50(%rsp), %rcx
    2112:      	movl	$0x3f, %edx
    2117:      	movl	$0x2d, %eax
    211c:      	movq	0x50(%rsp), %rdx
    2121:      	movl	$0x3f, %esi
    2126:      	callq	*%rax
    2128:      	testq	%rax, %rax
    212b:      	js	0x1e25 <generic_tracepoint_process_event+0x1e25>
    2131:      	leaq	0x8(%r15), %rdx
    2135:      	leaq	0x98(%rsp), %rdi
    213d:      	movl	$0x8, %ecx
    2142:      	movl	$0x4, %eax
    2147:      	movl	$0x8, %esi
    214c:      	callq	*%rax
    214e:      	leaq	0x8(%rbx), %rdi
    2152:      	movl	$0x348, %edx            # imm = 0x348
    2157:      	movq	0x98(%rsp), %rcx
    215f:      	addq	%rdx, %rcx
    2162:      	movl	$0x8, %esi
    2167:      	movl	$0x4, %eax
    216c:      	addq	0x98(%rsp), %rdx
    2174:      	movl	$0x8, %esi
    2179:      	callq	*%rax
    217b:      	addq	$0x58, %r15
    217f:      	leaq	0x98(%rsp), %rdi
    2187:      	movl	$0x4, %ecx
    218c:      	movl	$0x4, %eax
    2191:      	movl	$0x4, %esi
    2196:      	movq	%r15, %rdx
    2199:      	callq	*%rax
    219b:      	movl	$0x50, %r13d
    21a1:      	testq	%rax, %rax
    21a4:      	jne	0x2fe3 <generic_tracepoint_process_event+0x2fe3>
    21aa:      	xorl	%eax, %eax
    21ac:      	cmpl	$0x0, 0x98(%rsp)
    21b4:      	setne	%al
    21b7:      	movl	%eax, (%rbx)
    21b9:      	jmp	0x2fe3 <generic_tracepoint_process_event+0x2fe3>
    21be:      	xorl	%r13d, %r13d
    21c1:      	jmp	0x2fe8 <generic_tracepoint_process_event+0x2fe8>
    21c6:      	cmpl	$0x1, %ebp
    21c9:      	je	0x28c4 <generic_tracepoint_process_event+0x28c4>
    21cf:      	cmpl	$0x2, %ebp
    21d2:      	jne	0x28ce <generic_tracepoint_process_event+0x28ce>
    21d8:      	addq	$0x5e58, %r15           # imm = 0x5E58
    21df:      	jmp	0x28cb <generic_tracepoint_process_event+0x28cb>
    21e4:      	leaq	0x48(%r15), %rdx
    21e8:      	movl	$0x10, %ecx
    21ed:      	movl	$0x4, %eax
    21f2:      	movq	%rbx, %rdi
    21f5:      	movl	$0x10, %esi
    21fa:      	callq	*%rax
    21fc:      	leaq	0x38(%r15), %rdx
    2200:      	movl	$0x10, %ecx
    2205:      	movl	$0x4, %eax
    220a:      	movq	%r12, %rdi
    220d:      	movl	$0x10, %esi
    2212:      	callq	*%rax
    2214:      	movq	%rbx, %r13
    2217:      	leaq	0x20(%rbx), %rdi
    221b:      	leaq	0xc(%r15), %r12
    221f:      	addq	$0xe, %r15
    2223:      	movl	$0x2, %ecx
    2228:      	movl	$0x4, %eax
    222d:      	movl	$0x2, %esi
    2232:      	movq	%r15, %rdx
    2235:      	callq	*%rax
    2237:      	leaq	0x22(%rbx), %rdi
    223b:      	movl	$0x2, %ecx
    2240:      	movl	$0x4, %eax
    2245:      	movl	$0x2, %esi
    224a:      	movq	%r12, %rdx
    224d:      	callq	*%rax
    224f:      	movzwl	0x22(%rbx), %eax
    2253:      	movbew	%ax, 0x22(%rbx)
    2259:      	movq	0x28(%rbx), %rax
    225d:      	movq	%rax, 0x50(%rsp)
    2262:      	movq	(%rip), %rdi            # 0x2269 <generic_tracepoint_process_event+0x2269>
    2269:      	leaq	0x50(%rsp), %rsi
    226e:      	movl	$0x1, %eax
    2273:      	callq	*%rax
    2275:      	testq	%rax, %rax
    2278:      	je	0x2292 <generic_tracepoint_process_event+0x2292>
    227a:      	movl	(%rax), %ecx
    227c:      	movq	0x38(%rsp), %rbx
    2281:      	movl	%ecx, 0x10(%rbx)
    2284:      	movq	0x8(%rax), %rcx
    2288:      	movq	%rcx, 0x18(%rbx)
    228c:      	movl	0x4(%rax), %eax
    228f:      	movl	%eax, 0x7c(%rbx)
    2292:      	movl	$0x40, %r13d
    2298:      	jmp	0x2fe8 <generic_tracepoint_process_event+0x2fe8>
    229d:      	movq	%rbx, %rax
    22a0:      	addq	$0x5e60, %rax           # imm = 0x5E60
    22a6:      	jmp	0x22bc <generic_tracepoint_process_event+0x22bc>
    22a8:      	movq	%rbx, %rax
    22ab:      	addq	$0x5e68, %rax           # imm = 0x5E68
    22b1:      	jmp	0x22bc <generic_tracepoint_process_event+0x22bc>
    22b3:      	movq	%rbx, %rax
    22b6:      	addq	$0x5e50, %rax           # imm = 0x5E50
    22bc:      	movq	(%rax), %rbp
    22bf:      	testb	$0x10, %r15b
    22c3:      	jne	0x270e <generic_tracepoint_process_event+0x270e>
    22c9:      	testq	%rbp, %rbp
    22cc:      	je	0x27d6 <generic_tracepoint_process_event+0x27d6>
    22d2:      	leaq	0x50(%rsp), %rdi
    22d7:      	movl	$0x4, %r13d
    22dd:      	movl	$0x10, %ecx
    22e2:      	movl	$0x4, %eax
    22e7:      	movq	0x20(%rsp), %rdx
    22ec:      	movl	$0x10, %esi
    22f1:      	movq	%rdx, %r15
    22f4:      	callq	*%rax
    22f6:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    22fb:      	testl	%eax, %eax
    22fd:      	js	0x26e7 <generic_tracepoint_process_event+0x26e7>
    2303:      	movq	0x58(%rsp), %rdx
    2308:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    230d:      	movq	%rdx, %rax
    2310:      	movq	%rdx, 0xa8(%rsp)
    2318:      	cmpq	$0xffe, %rdx            # imm = 0xFFE
    231f:      	ja	0x26e7 <generic_tracepoint_process_event+0x26e7>
    2325:      	movq	0xe0(%rsp), %rax
    232d:      	leaq	0xc(%rax), %rbx
    2331:      	leaq	(%r12,%rbx), %rdi
    2335:      	movq	0x50(%rsp), %rcx
    233a:      	movl	$0x4, %eax
    233f:      	movq	0xa8(%rsp), %rsi
    2347:      	movq	0x50(%rsp), %rdx
    234c:      	callq	*%rax
    234e:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2353:      	testl	%eax, %eax
    2355:      	js	0x26e7 <generic_tracepoint_process_event+0x26e7>
    235b:      	cmpq	$0x1, %rbp
    235f:      	je	0x27e0 <generic_tracepoint_process_event+0x27e0>
    2365:      	leaq	0x10(%r15), %rdx
    2369:      	leaq	0x50(%rsp), %rdi
    236e:      	movl	$0x4, %r13d
    2374:      	movl	$0x10, %ecx
    2379:      	movl	$0x4, %eax
    237e:      	movl	$0x10, %esi
    2383:      	callq	*%rax
    2385:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    238a:      	testl	%eax, %eax
    238c:      	js	0x26e7 <generic_tracepoint_process_event+0x26e7>
    2392:      	movq	0x58(%rsp), %rax
    2397:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    239c:      	movq	%rax, 0x28(%rsp)
    23a1:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    23a7:      	ja	0x26e7 <generic_tracepoint_process_event+0x26e7>
    23ad:      	addq	0xa8(%rsp), %rbx
    23b5:      	leaq	(%r12,%rbx), %rdi
    23b9:      	movq	0x50(%rsp), %rcx
    23be:      	movl	$0x4, %eax
    23c3:      	movq	0x28(%rsp), %rsi
    23c8:      	movq	0x50(%rsp), %rdx
    23cd:      	callq	*%rax
    23cf:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    23d4:      	testl	%eax, %eax
    23d6:      	js	0x26e7 <generic_tracepoint_process_event+0x26e7>
    23dc:      	movq	0x28(%rsp), %rax
    23e1:      	addq	%rax, 0xa8(%rsp)
    23e9:      	cmpq	$0x3, %rbp
    23ed:      	jb	0x27e0 <generic_tracepoint_process_event+0x27e0>
    23f3:      	leaq	0x20(%r15), %rdx
    23f7:      	leaq	0x50(%rsp), %rdi
    23fc:      	movl	$0x4, %r13d
    2402:      	movl	$0x10, %ecx
    2407:      	movl	$0x4, %eax
    240c:      	movl	$0x10, %esi
    2411:      	callq	*%rax
    2413:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2418:      	testl	%eax, %eax
    241a:      	js	0x26e7 <generic_tracepoint_process_event+0x26e7>
    2420:      	movq	0x58(%rsp), %rax
    2425:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    242a:      	movq	%rax, 0xd8(%rsp)
    2432:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    2438:      	ja	0x26e7 <generic_tracepoint_process_event+0x26e7>
    243e:      	movq	0x28(%rsp), %rdi
    2443:      	addq	%rbx, %rdi
    2446:      	movq	%rdi, %rbx
    2449:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    244f:      	addq	%r12, %rdi
    2452:      	movq	0x50(%rsp), %rcx
    2457:      	movl	$0x4, %eax
    245c:      	movq	0xd8(%rsp), %rsi
    2464:      	movq	0x50(%rsp), %rdx
    2469:      	callq	*%rax
    246b:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2470:      	testl	%eax, %eax
    2472:      	js	0x26e7 <generic_tracepoint_process_event+0x26e7>
    2478:      	movq	0xd8(%rsp), %rax
    2480:      	addq	%rax, 0xa8(%rsp)
    2488:      	cmpq	$0x3, %rbp
    248c:      	je	0x27e0 <generic_tracepoint_process_event+0x27e0>
    2492:      	leaq	0x30(%r15), %rdx
    2496:      	leaq	0x50(%rsp), %rdi
    249b:      	movl	$0x4, %r13d
    24a1:      	movl	$0x10, %ecx
    24a6:      	movl	$0x4, %eax
    24ab:      	movl	$0x10, %esi
    24b0:      	callq	*%rax
    24b2:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    24b7:      	testl	%eax, %eax
    24b9:      	js	0x26e7 <generic_tracepoint_process_event+0x26e7>
    24bf:      	movq	0x58(%rsp), %rax
    24c4:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    24c9:      	movq	%rax, 0x28(%rsp)
    24ce:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    24d4:      	ja	0x26e7 <generic_tracepoint_process_event+0x26e7>
    24da:      	movq	0xd8(%rsp), %rdi
    24e2:      	addq	%rbx, %rdi
    24e5:      	movq	%rdi, 0xd8(%rsp)
    24ed:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    24f3:      	addq	%r12, %rdi
    24f6:      	movq	0x50(%rsp), %rcx
    24fb:      	movl	$0x4, %eax
    2500:      	movq	0x28(%rsp), %rsi
    2505:      	movq	0x50(%rsp), %rdx
    250a:      	callq	*%rax
    250c:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2511:      	testl	%eax, %eax
    2513:      	js	0x26e7 <generic_tracepoint_process_event+0x26e7>
    2519:      	movq	0x28(%rsp), %rax
    251e:      	addq	%rax, 0xa8(%rsp)
    2526:      	cmpq	$0x5, %rbp
    252a:      	jb	0x27e0 <generic_tracepoint_process_event+0x27e0>
    2530:      	leaq	0x40(%r15), %rdx
    2534:      	leaq	0x50(%rsp), %rdi
    2539:      	movl	$0x4, %r13d
    253f:      	movl	$0x10, %ecx
    2544:      	movl	$0x4, %eax
    2549:      	movl	$0x10, %esi
    254e:      	callq	*%rax
    2550:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2555:      	testl	%eax, %eax
    2557:      	js	0x26e7 <generic_tracepoint_process_event+0x26e7>
    255d:      	movq	0x58(%rsp), %rax
    2562:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2567:      	movq	%rax, 0xf0(%rsp)
    256f:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    2575:      	ja	0x26e7 <generic_tracepoint_process_event+0x26e7>
    257b:      	movq	0x28(%rsp), %rdi
    2580:      	addq	0xd8(%rsp), %rdi
    2588:      	movq	%rdi, %rbx
    258b:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2591:      	addq	%r12, %rdi
    2594:      	movq	0x50(%rsp), %rcx
    2599:      	movl	$0x4, %eax
    259e:      	movq	0xf0(%rsp), %rsi
    25a6:      	movq	0x50(%rsp), %rdx
    25ab:      	callq	*%rax
    25ad:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    25b2:      	testl	%eax, %eax
    25b4:      	js	0x26e7 <generic_tracepoint_process_event+0x26e7>
    25ba:      	movq	0xf0(%rsp), %rax
    25c2:      	addq	%rax, 0xa8(%rsp)
    25ca:      	cmpq	$0x5, %rbp
    25ce:      	je	0x27e0 <generic_tracepoint_process_event+0x27e0>
    25d4:      	leaq	0x50(%r15), %rdx
    25d8:      	leaq	0x50(%rsp), %rdi
    25dd:      	movl	$0x4, %r13d
    25e3:      	movl	$0x10, %ecx
    25e8:      	movl	$0x4, %eax
    25ed:      	movl	$0x10, %esi
    25f2:      	callq	*%rax
    25f4:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    25f9:      	testl	%eax, %eax
    25fb:      	js	0x26e7 <generic_tracepoint_process_event+0x26e7>
    2601:      	movq	0x58(%rsp), %rax
    2606:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    260b:      	movq	%rax, 0x28(%rsp)
    2610:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    2616:      	ja	0x26e7 <generic_tracepoint_process_event+0x26e7>
    261c:      	movq	0xf0(%rsp), %rdi
    2624:      	addq	%rbx, %rdi
    2627:      	movq	%rdi, %rbx
    262a:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2630:      	addq	%r12, %rdi
    2633:      	movq	0x50(%rsp), %rcx
    2638:      	movl	$0x4, %eax
    263d:      	movq	0x28(%rsp), %rsi
    2642:      	movq	0x50(%rsp), %rdx
    2647:      	callq	*%rax
    2649:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    264e:      	testl	%eax, %eax
    2650:      	js	0x26e7 <generic_tracepoint_process_event+0x26e7>
    2656:      	movq	0x28(%rsp), %rax
    265b:      	addq	%rax, 0xa8(%rsp)
    2663:      	cmpq	$0x7, %rbp
    2667:      	jb	0x27e0 <generic_tracepoint_process_event+0x27e0>
    266d:      	addq	$0x60, %r15
    2671:      	leaq	0x50(%rsp), %rdi
    2676:      	movl	$0x4, %r13d
    267c:      	movl	$0x10, %ecx
    2681:      	movl	$0x4, %eax
    2686:      	movl	$0x10, %esi
    268b:      	movq	%r15, %rdx
    268e:      	callq	*%rax
    2690:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2695:      	testl	%eax, %eax
    2697:      	js	0x26e7 <generic_tracepoint_process_event+0x26e7>
    2699:      	movq	0x58(%rsp), %r15
    269e:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    26a3:      	cmpq	$0xffe, %r15            # imm = 0xFFE
    26aa:      	ja	0x26e7 <generic_tracepoint_process_event+0x26e7>
    26ac:      	movq	0x28(%rsp), %rdi
    26b1:      	addq	%rbx, %rdi
    26b4:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    26ba:      	addq	%r12, %rdi
    26bd:      	movq	0x50(%rsp), %rcx
    26c2:      	movl	$0x4, %eax
    26c7:      	movq	0x50(%rsp), %rdx
    26cc:      	movl	%r15d, %esi
    26cf:      	callq	*%rax
    26d1:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    26d6:      	testl	%eax, %eax
    26d8:      	js	0x26e7 <generic_tracepoint_process_event+0x26e7>
    26da:      	addq	%r15, 0xa8(%rsp)
    26e2:      	jmp	0x27e0 <generic_tracepoint_process_event+0x27e0>
    26e7:      	movq	0x38(%rsp), %rax
    26ec:      	movl	%ecx, (%r12,%rax)
    26f0:      	jmp	0x2fe3 <generic_tracepoint_process_event+0x2fe3>
    26f5:      	xorl	%ebp, %ebp
    26f7:      	movl	$0x0, %eax
    26fc:      	movq	%rax, 0xa8(%rsp)
    2704:      	testb	$0x10, %r15b
    2708:      	je	0x27e0 <generic_tracepoint_process_event+0x27e0>
    270e:      	movl	$0xe, %eax
    2713:      	callq	*%rax
    2715:      	cmpq	$-0x16, %rax
    2719:      	jne	0x2742 <generic_tracepoint_process_event+0x2742>
    271b:      	movq	0xb8(%rsp), %rax
    2723:      	leaq	0x20(%rax), %rdx
    2727:      	leaq	0x50(%rsp), %rdi
    272c:      	movl	$0x8, %ecx
    2731:      	movl	$0x4, %eax
    2736:      	movl	$0x8, %esi
    273b:      	callq	*%rax
    273d:      	movq	0x50(%rsp), %rax
    2742:      	movq	0x8(%rbx), %rcx
    2746:      	movq	0x60(%rbx), %rdx
    274a:      	movq	%rcx, 0x50(%rsp)
    274f:      	movq	0x20(%rsp), %rcx
    2754:      	movq	%rcx, 0x58(%rsp)
    2759:      	movq	%rbp, 0x60(%rsp)
    275e:      	movq	%rdx, 0x98(%rsp)
    2766:      	movq	%rax, 0xa0(%rsp)
    276e:      	movq	(%rip), %rdi            # 0x2775 <generic_tracepoint_process_event+0x2775>
    2775:      	xorl	%ecx, %ecx
    2777:      	leaq	0x98(%rsp), %rsi
    277f:      	leaq	0x50(%rsp), %rdx
    2784:      	movl	$0x2, %eax
    2789:      	xorl	%ecx, %ecx
    278b:      	callq	*%rax
    278d:      	testq	%rax, %rax
    2790:      	je	0x288a <generic_tracepoint_process_event+0x288a>
    2796:      	negl	%eax
    2798:      	movw	%ax, 0x40(%rsp)
    279d:      	movw	$0x5, 0x42(%rsp)
    27a4:      	movabsq	$0x200000057, %rax      # imm = 0x200000057
    27ae:      	movq	%rax, 0x44(%rsp)
    27b3:      	movq	(%rip), %rdi            # 0x27ba <generic_tracepoint_process_event+0x27ba>
    27ba:      	leaq	0x40(%rsp), %rsi
    27bf:      	movl	$0x1, %eax
    27c4:      	callq	*%rax
    27c6:      	testq	%rax, %rax
    27c9:      	je	0x2866 <generic_tracepoint_process_event+0x2866>
    27cf:      	incl	(%rax)
    27d1:      	jmp	0x288a <generic_tracepoint_process_event+0x288a>
    27d6:      	xorl	%eax, %eax
    27d8:      	movq	%rax, 0xa8(%rsp)
    27e0:      	movq	0x38(%rsp), %rax
    27e5:      	movq	0xa8(%rsp), %r13
    27ed:      	movl	%r13d, (%r12,%rax)
    27f1:      	movl	%r13d, 0x4(%r12,%rax)
    27f6:      	addq	$0x8, %r13
    27fa:      	jmp	0x2fe3 <generic_tracepoint_process_event+0x2fe3>
    27ff:      	cmpl	$0x33, %eax
    2802:      	je	0x2945 <generic_tracepoint_process_event+0x2945>
    2808:      	cmpl	$0x3c, %eax
    280b:      	je	0x28a2 <generic_tracepoint_process_event+0x28a2>
    2811:      	cmpl	$0xff, %eax
    2816:      	jne	0x29fe <generic_tracepoint_process_event+0x29fe>
    281c:      	movw	$0x28, 0x2(%rbp)
    2822:      	movw	$0x28, %ax
    2826:      	jmp	0x2954 <generic_tracepoint_process_event+0x2954>
    282b:      	movl	$0x1, 0xc0(%rsp)
    2836:      	movq	(%rip), %rdi            # 0x283d <generic_tracepoint_process_event+0x283d>
    283d:      	xorl	%ecx, %ecx
    283f:      	leaq	0x40(%rsp), %rsi
    2844:      	leaq	0xc0(%rsp), %rdx
    284c:      	movl	$0x2, %eax
    2851:      	xorl	%ecx, %ecx
    2853:      	callq	*%rax
    2855:      	movl	$0xfffffffc, (%rbx)     # imm = 0xFFFFFFFC
    285b:      	movl	$0x4, %r13d
    2861:      	jmp	0x2fe3 <generic_tracepoint_process_event+0x2fe3>
    2866:      	movl	$0x1, 0x30(%rsp)
    286e:      	movq	(%rip), %rdi            # 0x2875 <generic_tracepoint_process_event+0x2875>
    2875:      	xorl	%ecx, %ecx
    2877:      	leaq	0x40(%rsp), %rsi
    287c:      	leaq	0x30(%rsp), %rdx
    2881:      	movl	$0x2, %eax
    2886:      	xorl	%ecx, %ecx
    2888:      	callq	*%rax
    288a:      	movq	0x38(%rsp), %rax
    288f:      	movl	$0xfffffffc, (%r12,%rax) # imm = 0xFFFFFFFC
    2897:      	movl	$0x4, %r13d
    289d:      	jmp	0x2fe3 <generic_tracepoint_process_event+0x2fe3>
    28a2:      	movzbl	0x7(%rbp), %eax
    28a6:      	leal	0x8(,%rax,8), %eax
    28ad:      	jmp	0x2950 <generic_tracepoint_process_event+0x2950>
    28b2:      	addq	$0x5e60, %r15           # imm = 0x5E60
    28b9:      	jmp	0x28cb <generic_tracepoint_process_event+0x28cb>
    28bb:      	addq	$0x5e68, %r15           # imm = 0x5E68
    28c2:      	jmp	0x28cb <generic_tracepoint_process_event+0x28cb>
    28c4:      	addq	$0x5e50, %r15           # imm = 0x5E50
    28cb:      	movq	(%r15), %rax
    28ce:      	movq	%rax, 0x30(%rsp)
    28d3:      	leaq	0xd0(%rsp), %rdi
    28db:      	leaq	0x30(%rsp), %rdx
    28e0:      	movl	$0x8, %ecx
    28e5:      	movl	$0x4, %eax
    28ea:      	movl	$0x4, %r13d
    28f0:      	movl	$0x8, %esi
    28f5:      	callq	*%rax
    28f7:      	movq	0xd0(%rsp), %r12
    28ff:      	cmpq	$0xfff, %r12            # imm = 0xFFF
    2906:      	movl	$0xfff, %r15d           # imm = 0xFFF
    290c:      	cmovbq	%r12, %r15
    2910:      	leaq	0x8(%rbx), %rdi
    2914:      	movl	$0x4, %eax
    2919:      	movq	0x20(%rsp), %rdx
    291e:      	movl	%r15d, %esi
    2921:      	callq	*%rax
    2923:      	testl	%eax, %eax
    2925:      	js	0x293a <generic_tracepoint_process_event+0x293a>
    2927:      	movl	%r12d, (%rbx)
    292a:      	movl	%r15d, 0x4(%rbx)
    292e:      	addq	$0x8, %r15
    2932:      	movq	%r15, %r13
    2935:      	jmp	0x2fe3 <generic_tracepoint_process_event+0x2fe3>
    293a:      	movl	$0xfffffffe, (%rbx)     # imm = 0xFFFFFFFE
    2940:      	jmp	0x2fe3 <generic_tracepoint_process_event+0x2fe3>
    2945:      	movzbl	0x7(%rbp), %eax
    2949:      	leal	0x8(,%rax,4), %eax
    2950:      	movw	%ax, 0x2(%rbp)
    2954:      	addw	(%rbp), %ax
    2958:      	movw	%ax, (%rbp)
    295c:      	movzbl	0x6(%rbp), %ebx
    2960:      	cmpq	$0x3c, %rbx
    2964:      	ja	0x308e <generic_tracepoint_process_event+0x308e>
    296a:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    2974:      	btq	%rbx, %rcx
    2978:      	jae	0x308e <generic_tracepoint_process_event+0x308e>
    297e:      	movb	%bl, 0x5(%rbp)
    2981:      	movzwl	%ax, %ecx
    2984:      	addq	%r15, %rcx
    2987:      	movl	$0x2, %edx
    298c:      	movl	$0x4, %eax
    2991:      	movq	0x20(%rsp), %rdi
    2996:      	movzwl	(%rbp), %edx
    299a:      	addq	%r15, %rdx
    299d:      	movl	$0x2, %esi
    29a2:      	callq	*%rax
    29a4:      	testq	%rax, %rax
    29a7:      	js	0x2e27 <generic_tracepoint_process_event+0x2e27>
    29ad:      	movzbl	0x5(%rbp), %eax
    29b1:      	cmpl	$0x32, %eax
    29b4:      	jg	0x29d0 <generic_tracepoint_process_event+0x29d0>
    29b6:      	testl	%eax, %eax
    29b8:      	je	0x29ed <generic_tracepoint_process_event+0x29ed>
    29ba:      	cmpl	$0x2b, %eax
    29bd:      	je	0x29ed <generic_tracepoint_process_event+0x29ed>
    29bf:      	cmpl	$0x2c, %eax
    29c2:      	jne	0x2a18 <generic_tracepoint_process_event+0x2a18>
    29c4:      	movw	$0x8, 0x2(%rbp)
    29ca:      	movw	$0x8, %ax
    29ce:      	jmp	0x2a1c <generic_tracepoint_process_event+0x2a1c>
    29d0:      	cmpl	$0x33, %eax
    29d3:      	je	0x2a07 <generic_tracepoint_process_event+0x2a07>
    29d5:      	cmpl	$0x3c, %eax
    29d8:      	je	0x29ed <generic_tracepoint_process_event+0x29ed>
    29da:      	cmpl	$0xff, %eax
    29df:      	jne	0x2a18 <generic_tracepoint_process_event+0x2a18>
    29e1:      	movw	$0x28, 0x2(%rbp)
    29e7:      	movw	$0x28, %ax
    29eb:      	jmp	0x2a1c <generic_tracepoint_process_event+0x2a1c>
    29ed:      	movzbl	0x7(%rbp), %eax
    29f1:      	leal	0x8(,%rax,8), %eax
    29f8:      	movw	%ax, 0x2(%rbp)
    29fc:      	jmp	0x2a1c <generic_tracepoint_process_event+0x2a1c>
    29fe:      	movzwl	0x2(%rbp), %eax
    2a02:      	jmp	0x2954 <generic_tracepoint_process_event+0x2954>
    2a07:      	movzbl	0x7(%rbp), %eax
    2a0b:      	leal	0x8(,%rax,4), %eax
    2a12:      	movw	%ax, 0x2(%rbp)
    2a16:      	jmp	0x2a1c <generic_tracepoint_process_event+0x2a1c>
    2a18:      	movzwl	0x2(%rbp), %eax
    2a1c:      	addw	(%rbp), %ax
    2a20:      	movw	%ax, (%rbp)
    2a24:      	movzbl	0x6(%rbp), %ebx
    2a28:      	cmpq	$0x3c, %rbx
    2a2c:      	ja	0x308e <generic_tracepoint_process_event+0x308e>
    2a32:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    2a3c:      	btq	%rbx, %rcx
    2a40:      	jae	0x308e <generic_tracepoint_process_event+0x308e>
    2a46:      	movb	%bl, 0x5(%rbp)
    2a49:      	movzwl	%ax, %ecx
    2a4c:      	addq	%r15, %rcx
    2a4f:      	movl	$0x2, %edx
    2a54:      	movl	$0x4, %eax
    2a59:      	movq	0x20(%rsp), %rdi
    2a5e:      	movzwl	(%rbp), %edx
    2a62:      	addq	%r15, %rdx
    2a65:      	movl	$0x2, %esi
    2a6a:      	callq	*%rax
    2a6c:      	testq	%rax, %rax
    2a6f:      	js	0x2e27 <generic_tracepoint_process_event+0x2e27>
    2a75:      	movzbl	0x5(%rbp), %eax
    2a79:      	cmpl	$0x32, %eax
    2a7c:      	jg	0x2a98 <generic_tracepoint_process_event+0x2a98>
    2a7e:      	testl	%eax, %eax
    2a80:      	je	0x2ab5 <generic_tracepoint_process_event+0x2ab5>
    2a82:      	cmpl	$0x2b, %eax
    2a85:      	je	0x2ab5 <generic_tracepoint_process_event+0x2ab5>
    2a87:      	cmpl	$0x2c, %eax
    2a8a:      	jne	0x2ad7 <generic_tracepoint_process_event+0x2ad7>
    2a8c:      	movw	$0x8, 0x2(%rbp)
    2a92:      	movw	$0x8, %ax
    2a96:      	jmp	0x2adb <generic_tracepoint_process_event+0x2adb>
    2a98:      	cmpl	$0x33, %eax
    2a9b:      	je	0x2ac6 <generic_tracepoint_process_event+0x2ac6>
    2a9d:      	cmpl	$0x3c, %eax
    2aa0:      	je	0x2ab5 <generic_tracepoint_process_event+0x2ab5>
    2aa2:      	cmpl	$0xff, %eax
    2aa7:      	jne	0x2ad7 <generic_tracepoint_process_event+0x2ad7>
    2aa9:      	movw	$0x28, 0x2(%rbp)
    2aaf:      	movw	$0x28, %ax
    2ab3:      	jmp	0x2adb <generic_tracepoint_process_event+0x2adb>
    2ab5:      	movzbl	0x7(%rbp), %eax
    2ab9:      	leal	0x8(,%rax,8), %eax
    2ac0:      	movw	%ax, 0x2(%rbp)
    2ac4:      	jmp	0x2adb <generic_tracepoint_process_event+0x2adb>
    2ac6:      	movzbl	0x7(%rbp), %eax
    2aca:      	leal	0x8(,%rax,4), %eax
    2ad1:      	movw	%ax, 0x2(%rbp)
    2ad5:      	jmp	0x2adb <generic_tracepoint_process_event+0x2adb>
    2ad7:      	movzwl	0x2(%rbp), %eax
    2adb:      	addw	(%rbp), %ax
    2adf:      	movw	%ax, (%rbp)
    2ae3:      	movzbl	0x6(%rbp), %ebx
    2ae7:      	cmpq	$0x3c, %rbx
    2aeb:      	ja	0x308e <generic_tracepoint_process_event+0x308e>
    2af1:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    2afb:      	btq	%rbx, %rcx
    2aff:      	jae	0x308e <generic_tracepoint_process_event+0x308e>
    2b05:      	movb	%bl, 0x5(%rbp)
    2b08:      	movzwl	%ax, %ecx
    2b0b:      	addq	%r15, %rcx
    2b0e:      	movl	$0x2, %edx
    2b13:      	movl	$0x4, %eax
    2b18:      	movq	0x20(%rsp), %rdi
    2b1d:      	movzwl	(%rbp), %edx
    2b21:      	addq	%r15, %rdx
    2b24:      	movl	$0x2, %esi
    2b29:      	callq	*%rax
    2b2b:      	testq	%rax, %rax
    2b2e:      	js	0x2e27 <generic_tracepoint_process_event+0x2e27>
    2b34:      	movzbl	0x5(%rbp), %eax
    2b38:      	cmpl	$0x32, %eax
    2b3b:      	jg	0x2b57 <generic_tracepoint_process_event+0x2b57>
    2b3d:      	testl	%eax, %eax
    2b3f:      	je	0x2b74 <generic_tracepoint_process_event+0x2b74>
    2b41:      	cmpl	$0x2b, %eax
    2b44:      	je	0x2b74 <generic_tracepoint_process_event+0x2b74>
    2b46:      	cmpl	$0x2c, %eax
    2b49:      	jne	0x2b96 <generic_tracepoint_process_event+0x2b96>
    2b4b:      	movw	$0x8, 0x2(%rbp)
    2b51:      	movw	$0x8, %ax
    2b55:      	jmp	0x2b9a <generic_tracepoint_process_event+0x2b9a>
    2b57:      	cmpl	$0x33, %eax
    2b5a:      	je	0x2b85 <generic_tracepoint_process_event+0x2b85>
    2b5c:      	cmpl	$0x3c, %eax
    2b5f:      	je	0x2b74 <generic_tracepoint_process_event+0x2b74>
    2b61:      	cmpl	$0xff, %eax
    2b66:      	jne	0x2b96 <generic_tracepoint_process_event+0x2b96>
    2b68:      	movw	$0x28, 0x2(%rbp)
    2b6e:      	movw	$0x28, %ax
    2b72:      	jmp	0x2b9a <generic_tracepoint_process_event+0x2b9a>
    2b74:      	movzbl	0x7(%rbp), %eax
    2b78:      	leal	0x8(,%rax,8), %eax
    2b7f:      	movw	%ax, 0x2(%rbp)
    2b83:      	jmp	0x2b9a <generic_tracepoint_process_event+0x2b9a>
    2b85:      	movzbl	0x7(%rbp), %eax
    2b89:      	leal	0x8(,%rax,4), %eax
    2b90:      	movw	%ax, 0x2(%rbp)
    2b94:      	jmp	0x2b9a <generic_tracepoint_process_event+0x2b9a>
    2b96:      	movzwl	0x2(%rbp), %eax
    2b9a:      	addw	(%rbp), %ax
    2b9e:      	movw	%ax, (%rbp)
    2ba2:      	movzbl	0x6(%rbp), %ebx
    2ba6:      	cmpq	$0x3c, %rbx
    2baa:      	ja	0x308e <generic_tracepoint_process_event+0x308e>
    2bb0:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    2bba:      	btq	%rbx, %rcx
    2bbe:      	jae	0x308e <generic_tracepoint_process_event+0x308e>
    2bc4:      	movb	%bl, 0x5(%rbp)
    2bc7:      	movzwl	%ax, %ecx
    2bca:      	addq	%r15, %rcx
    2bcd:      	movl	$0x2, %edx
    2bd2:      	movl	$0x4, %eax
    2bd7:      	movq	0x20(%rsp), %rdi
    2bdc:      	movzwl	(%rbp), %edx
    2be0:      	addq	%r15, %rdx
    2be3:      	movl	$0x2, %esi
    2be8:      	callq	*%rax
    2bea:      	testq	%rax, %rax
    2bed:      	js	0x2e27 <generic_tracepoint_process_event+0x2e27>
    2bf3:      	movzbl	0x5(%rbp), %eax
    2bf7:      	cmpl	$0x32, %eax
    2bfa:      	jg	0x2c16 <generic_tracepoint_process_event+0x2c16>
    2bfc:      	testl	%eax, %eax
    2bfe:      	je	0x2c33 <generic_tracepoint_process_event+0x2c33>
    2c00:      	cmpl	$0x2b, %eax
    2c03:      	je	0x2c33 <generic_tracepoint_process_event+0x2c33>
    2c05:      	cmpl	$0x2c, %eax
    2c08:      	jne	0x2c55 <generic_tracepoint_process_event+0x2c55>
    2c0a:      	movw	$0x8, 0x2(%rbp)
    2c10:      	movw	$0x8, %ax
    2c14:      	jmp	0x2c59 <generic_tracepoint_process_event+0x2c59>
    2c16:      	cmpl	$0x33, %eax
    2c19:      	je	0x2c44 <generic_tracepoint_process_event+0x2c44>
    2c1b:      	cmpl	$0x3c, %eax
    2c1e:      	je	0x2c33 <generic_tracepoint_process_event+0x2c33>
    2c20:      	cmpl	$0xff, %eax
    2c25:      	jne	0x2c55 <generic_tracepoint_process_event+0x2c55>
    2c27:      	movw	$0x28, 0x2(%rbp)
    2c2d:      	movw	$0x28, %ax
    2c31:      	jmp	0x2c59 <generic_tracepoint_process_event+0x2c59>
    2c33:      	movzbl	0x7(%rbp), %eax
    2c37:      	leal	0x8(,%rax,8), %eax
    2c3e:      	movw	%ax, 0x2(%rbp)
    2c42:      	jmp	0x2c59 <generic_tracepoint_process_event+0x2c59>
    2c44:      	movzbl	0x7(%rbp), %eax
    2c48:      	leal	0x8(,%rax,4), %eax
    2c4f:      	movw	%ax, 0x2(%rbp)
    2c53:      	jmp	0x2c59 <generic_tracepoint_process_event+0x2c59>
    2c55:      	movzwl	0x2(%rbp), %eax
    2c59:      	addw	(%rbp), %ax
    2c5d:      	movw	%ax, (%rbp)
    2c61:      	movzbl	0x6(%rbp), %ebx
    2c65:      	cmpq	$0x3c, %rbx
    2c69:      	ja	0x308e <generic_tracepoint_process_event+0x308e>
    2c6f:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    2c79:      	btq	%rbx, %rcx
    2c7d:      	jae	0x308e <generic_tracepoint_process_event+0x308e>
    2c83:      	movb	%bl, 0x5(%rbp)
    2c86:      	movzwl	%ax, %ecx
    2c89:      	addq	%r15, %rcx
    2c8c:      	movl	$0x2, %edx
    2c91:      	movl	$0x4, %eax
    2c96:      	movq	0x20(%rsp), %rdi
    2c9b:      	movzwl	(%rbp), %edx
    2c9f:      	addq	%r15, %rdx
    2ca2:      	movl	$0x2, %esi
    2ca7:      	callq	*%rax
    2ca9:      	testq	%rax, %rax
    2cac:      	js	0x2e27 <generic_tracepoint_process_event+0x2e27>
    2cb2:      	movzbl	0x5(%rbp), %eax
    2cb6:      	cmpl	$0x32, %eax
    2cb9:      	jg	0x2cd5 <generic_tracepoint_process_event+0x2cd5>
    2cbb:      	testl	%eax, %eax
    2cbd:      	je	0x2cf2 <generic_tracepoint_process_event+0x2cf2>
    2cbf:      	cmpl	$0x2b, %eax
    2cc2:      	je	0x2cf2 <generic_tracepoint_process_event+0x2cf2>
    2cc4:      	cmpl	$0x2c, %eax
    2cc7:      	jne	0x2d14 <generic_tracepoint_process_event+0x2d14>
    2cc9:      	movw	$0x8, 0x2(%rbp)
    2ccf:      	movw	$0x8, %ax
    2cd3:      	jmp	0x2d18 <generic_tracepoint_process_event+0x2d18>
    2cd5:      	cmpl	$0x33, %eax
    2cd8:      	je	0x2d03 <generic_tracepoint_process_event+0x2d03>
    2cda:      	cmpl	$0x3c, %eax
    2cdd:      	je	0x2cf2 <generic_tracepoint_process_event+0x2cf2>
    2cdf:      	cmpl	$0xff, %eax
    2ce4:      	jne	0x2d14 <generic_tracepoint_process_event+0x2d14>
    2ce6:      	movw	$0x28, 0x2(%rbp)
    2cec:      	movw	$0x28, %ax
    2cf0:      	jmp	0x2d18 <generic_tracepoint_process_event+0x2d18>
    2cf2:      	movzbl	0x7(%rbp), %eax
    2cf6:      	leal	0x8(,%rax,8), %eax
    2cfd:      	movw	%ax, 0x2(%rbp)
    2d01:      	jmp	0x2d18 <generic_tracepoint_process_event+0x2d18>
    2d03:      	movzbl	0x7(%rbp), %eax
    2d07:      	leal	0x8(,%rax,4), %eax
    2d0e:      	movw	%ax, 0x2(%rbp)
    2d12:      	jmp	0x2d18 <generic_tracepoint_process_event+0x2d18>
    2d14:      	movzwl	0x2(%rbp), %eax
    2d18:      	addw	(%rbp), %ax
    2d1c:      	movw	%ax, (%rbp)
    2d20:      	movzbl	0x6(%rbp), %ebx
    2d24:      	cmpq	$0x3c, %rbx
    2d28:      	ja	0x308e <generic_tracepoint_process_event+0x308e>
    2d2e:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    2d38:      	btq	%rbx, %rcx
    2d3c:      	jae	0x308e <generic_tracepoint_process_event+0x308e>
    2d42:      	movb	%bl, 0x5(%rbp)
    2d45:      	movzwl	%ax, %ecx
    2d48:      	addq	%r15, %rcx
    2d4b:      	movl	$0x2, %edx
    2d50:      	movl	$0x4, %eax
    2d55:      	movq	0x20(%rsp), %rdi
    2d5a:      	movzwl	(%rbp), %edx
    2d5e:      	addq	%r15, %rdx
    2d61:      	movl	$0x2, %esi
    2d66:      	callq	*%rax
    2d68:      	testq	%rax, %rax
    2d6b:      	js	0x2e27 <generic_tracepoint_process_event+0x2e27>
    2d71:      	movzbl	0x5(%rbp), %eax
    2d75:      	cmpl	$0x32, %eax
    2d78:      	jg	0x2d94 <generic_tracepoint_process_event+0x2d94>
    2d7a:      	testl	%eax, %eax
    2d7c:      	je	0x2db1 <generic_tracepoint_process_event+0x2db1>
    2d7e:      	cmpl	$0x2b, %eax
    2d81:      	je	0x2db1 <generic_tracepoint_process_event+0x2db1>
    2d83:      	cmpl	$0x2c, %eax
    2d86:      	jne	0x2dd3 <generic_tracepoint_process_event+0x2dd3>
    2d88:      	movw	$0x8, 0x2(%rbp)
    2d8e:      	movw	$0x8, %ax
    2d92:      	jmp	0x2dd7 <generic_tracepoint_process_event+0x2dd7>
    2d94:      	cmpl	$0x33, %eax
    2d97:      	je	0x2dc2 <generic_tracepoint_process_event+0x2dc2>
    2d99:      	cmpl	$0x3c, %eax
    2d9c:      	je	0x2db1 <generic_tracepoint_process_event+0x2db1>
    2d9e:      	cmpl	$0xff, %eax
    2da3:      	jne	0x2dd3 <generic_tracepoint_process_event+0x2dd3>
    2da5:      	movw	$0x28, 0x2(%rbp)
    2dab:      	movw	$0x28, %ax
    2daf:      	jmp	0x2dd7 <generic_tracepoint_process_event+0x2dd7>
    2db1:      	movzbl	0x7(%rbp), %eax
    2db5:      	leal	0x8(,%rax,8), %eax
    2dbc:      	movw	%ax, 0x2(%rbp)
    2dc0:      	jmp	0x2dd7 <generic_tracepoint_process_event+0x2dd7>
    2dc2:      	movzbl	0x7(%rbp), %eax
    2dc6:      	leal	0x8(,%rax,4), %eax
    2dcd:      	movw	%ax, 0x2(%rbp)
    2dd1:      	jmp	0x2dd7 <generic_tracepoint_process_event+0x2dd7>
    2dd3:      	movzwl	0x2(%rbp), %eax
    2dd7:      	addw	(%rbp), %ax
    2ddb:      	movw	%ax, (%rbp)
    2ddf:      	movzbl	0x6(%rbp), %ebx
    2de3:      	cmpq	$0x3c, %rbx
    2de7:      	ja	0x308e <generic_tracepoint_process_event+0x308e>
    2ded:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    2df7:      	btq	%rbx, %rcx
    2dfb:      	jae	0x308e <generic_tracepoint_process_event+0x308e>
    2e01:      	movb	%bl, 0x5(%rbp)
    2e04:      	movzwl	%ax, %ecx
    2e07:      	addq	%r15, %rcx
    2e0a:      	movl	$0x2, %edx
    2e0f:      	movl	$0x4, %eax
    2e14:      	movq	0x20(%rsp), %rdi
    2e19:      	movzwl	(%rbp), %edx
    2e1d:      	addq	%r15, %rdx
    2e20:      	movl	$0x2, %esi
    2e25:      	callq	*%rax
    2e27:      	xorl	%ebx, %ebx
    2e29:      	movb	%bl, 0xb4(%rsp)
    2e30:      	movzbl	%bl, %eax
    2e33:      	movq	0x28(%rsp), %r15
    2e38:      	movw	%ax, 0x24(%r15)
    2e3d:      	movw	$0xa, 0x26(%r15)
    2e44:      	leaq	0x8(%r13), %rdx
    2e48:      	movl	$0x10, %ecx
    2e4d:      	movl	$0x4, %eax
    2e52:      	movq	%r15, %rdi
    2e55:      	movl	$0x10, %esi
    2e5a:      	callq	*%rax
    2e5c:      	leaq	0x10(%r15), %rdi
    2e60:      	addq	$0x18, %r13
    2e64:      	movl	$0x10, %ecx
    2e69:      	movl	$0x4, %eax
    2e6e:      	movl	$0x10, %esi
    2e73:      	movq	%r13, %rdx
    2e76:      	callq	*%rax
    2e78:      	cmpb	$0x11, %bl
    2e7b:      	je	0x2ecd <generic_tracepoint_process_event+0x2ecd>
    2e7d:      	movzbl	%bl, %eax
    2e80:      	cmpl	$0x6, %eax
    2e83:      	jne	0x2f18 <generic_tracepoint_process_event+0x2f18>
    2e89:      	movq	0x50(%rsp), %rbx
    2e8e:      	movzwl	0xc8(%rsp), %r15d
    2e97:      	leaq	(%rbx,%r15), %rdx
    2e9b:      	movq	0x28(%rsp), %r13
    2ea0:      	leaq	0x20(%r13), %rdi
    2ea4:      	movl	$0x2, %ecx
    2ea9:      	movl	$0x4, %eax
    2eae:      	movl	$0x2, %esi
    2eb3:      	callq	*%rax
    2eb5:      	leaq	0x22(%r13), %rdi
    2eb9:      	leaq	(%rbx,%r15), %rdx
    2ebd:      	addq	$0x2, %rdx
    2ec1:      	movl	$0x2, %ecx
    2ec6:      	movl	$0x4, %eax
    2ecb:      	jmp	0x2f0f <generic_tracepoint_process_event+0x2f0f>
    2ecd:      	movq	0x50(%rsp), %rbx
    2ed2:      	movzwl	0xc8(%rsp), %r15d
    2edb:      	leaq	(%rbx,%r15), %rdx
    2edf:      	movq	0x28(%rsp), %r13
    2ee4:      	leaq	0x20(%r13), %rdi
    2ee8:      	movl	$0x2, %ecx
    2eed:      	movl	$0x4, %eax
    2ef2:      	movl	$0x2, %esi
    2ef7:      	callq	*%rax
    2ef9:      	leaq	0x22(%r13), %rdi
    2efd:      	leaq	(%rbx,%r15), %rdx
    2f01:      	addq	$0x2, %rdx
    2f05:      	movl	$0x2, %ecx
    2f0a:      	movl	$0x4, %eax
    2f0f:      	movl	$0x2, %esi
    2f14:      	callq	*%rax
    2f16:      	jmp	0x2f24 <generic_tracepoint_process_event+0x2f24>
    2f18:      	movq	0x28(%rsp), %rax
    2f1d:      	movl	$0x0, 0x20(%rax)
    2f24:      	movq	0x28(%rsp), %rdx
    2f29:      	movzwl	0x20(%rdx), %eax
    2f2d:      	movzwl	0x22(%rdx), %ecx
    2f31:      	movbew	%ax, 0x20(%rdx)
    2f37:      	movbew	%cx, 0x22(%rdx)
    2f3d:      	addq	$0xe0, %r12
    2f44:      	leaq	0x98(%rsp), %rdi
    2f4c:      	movl	$0x8, %ecx
    2f51:      	movl	$0x4, %eax
    2f56:      	movl	$0x4, %ebx
    2f5b:      	movl	$0x8, %esi
    2f60:      	movq	%r12, %rdx
    2f63:      	callq	*%rax
    2f65:      	movq	0x98(%rsp), %rcx
    2f6d:      	testq	%rcx, %rcx
    2f70:      	je	0x2fdd <generic_tracepoint_process_event+0x2fdd>
    2f72:      	addq	$0x5, %rcx
    2f76:      	leaq	0x40(%rsp), %rdi
    2f7b:      	movl	$0x8, %edx
    2f80:      	movl	$0x4, %eax
    2f85:      	movq	0x98(%rsp), %rdx
    2f8d:      	addq	$0x5, %rdx
    2f91:      	movl	$0x8, %esi
    2f96:      	callq	*%rax
    2f98:      	movq	0x98(%rsp), %r15
    2fa0:      	movq	0x40(%rsp), %r12
    2fa5:      	movq	0x28(%rsp), %r13
    2faa:      	leaq	0x38(%r13), %rdi
    2fae:      	leaq	(%r15,%r12,8), %rdx
    2fb2:      	addq	$0x44, %rdx
    2fb6:      	movl	$0x4, %eax
    2fbb:      	movl	$0x4, %esi
    2fc0:      	callq	*%rax
    2fc2:      	addq	$0x3c, %r13
    2fc6:      	leaq	(%r15,%r12,8), %rdx
    2fca:      	addq	$0x45, %rdx
    2fce:      	movl	$0x4, %eax
    2fd3:      	movq	%r13, %rdi
    2fd6:      	movl	$0x4, %esi
    2fdb:      	callq	*%rax
    2fdd:      	movl	$0x40, %r13d
    2fe3:      	movq	0x10(%rsp), %rbp
    2fe8:      	movq	0x8(%rsp), %rcx
    2fed:      	movl	$0x4, %edx
    2ff2:      	movq	0xb8(%rsp), %r12
    2ffa:      	testl	%r13d, %r13d
    2ffd:      	js	0x306a <generic_tracepoint_process_event+0x306a>
    2fff:      	andl	$0x7fffffff, %r13d      # imm = 0x7FFFFFFF
    3006:      	addl	$0x4, %r13d
    300a:      	movl	%r13d, %edx
    300d:      	movq	0xe8(%rsp), %rbx
    3015:      	movq	0xe0(%rsp), %r13
    301d:      	addl	%r13d, %edx
    3020:      	movl	%edx, %r13d
    3023:      	movl	%r13d, 0x4(%r14)
    3027:      	cmpl	$0x3, %ebx
    302a:      	jle	0x66d <generic_tracepoint_process_event+0x66d>
    3030:      	movl	$0x0, 0x5efc(%r14)
    303b:      	movq	(%rip), %rsi            # 0x3042 <generic_tracepoint_process_event+0x3042>
    3042:      	movl	$0x3, %ecx
    3047:      	movl	$0xc, %eax
    304c:      	movq	%r12, %rdi
    304f:      	movl	$0x3, %edx
    3054:      	callq	*%rax
    3056:      	xorl	%eax, %eax
    3058:      	addq	$0x118, %rsp            # imm = 0x118
    305f:      	popq	%rbx
    3060:      	popq	%r12
    3062:      	popq	%r13
    3064:      	popq	%r14
    3066:      	popq	%r15
    3068:      	popq	%rbp
    3069:      	retq
    306a:      	movl	$0xffffffff, 0x5ea0(%rbp,%rcx,4) # imm = 0xFFFFFFFF
    3075:      	movq	0xe0(%rsp), %r13
    307d:      	movl	$0xffffffff, 0x90(%rbp,%r13) # imm = 0xFFFFFFFF
    3089:      	jmp	0x643 <generic_tracepoint_process_event+0x643>
    308e:      	movw	%ax, 0xc8(%rsp)
    3096:      	jmp	0x2e29 <generic_tracepoint_process_event+0x2e29>
    309b:      	nopl	(%rax,%rax)

00000000000030a0 <generic_tracepoint_filter>:
    30a0:      	pushq	%rbp
    30a1:      	pushq	%r15
    30a3:      	pushq	%r14
    30a5:      	pushq	%r13
    30a7:      	pushq	%r12
    30a9:      	pushq	%rbx
    30aa:      	subq	$0xf8, %rsp
    30b1:      	movq	%rdi, %rbp
    30b4:      	movl	$0x0, 0xc8(%rsp)
    30bf:      	movq	(%rip), %rdi            # 0x30c6 <generic_tracepoint_filter+0x26>
    30c6:      	leaq	0xc8(%rsp), %rsi
    30ce:      	movl	$0x1, %eax
    30d3:      	callq	*%rax
    30d5:      	testq	%rax, %rax
    30d8:      	je	0x535c <generic_tracepoint_filter+0x22bc>
    30de:      	movq	%rax, %r12
    30e1:      	movl	$0x23, %eax
    30e6:      	callq	*%rax
    30e8:      	movq	%rax, %rcx
    30eb:      	movq	%rax, 0x50(%rsp)
    30f0:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    30f7:      	leaq	0x48(%rsp), %rdi
    30fc:      	movl	$0x4, %edx
    3101:      	movl	$0x71, %eax
    3106:      	movl	$0xaf4, %edx            # imm = 0xAF4
    310b:      	addq	0x50(%rsp), %rdx
    3110:      	movl	$0x4, %esi
    3115:      	callq	*%rax
    3117:      	movl	0x48(%rsp), %eax
    311b:      	movl	%eax, 0x38(%rsp)
    311f:      	movq	(%rip), %rdi            # 0x3126 <generic_tracepoint_filter+0x86>
    3126:      	leaq	0x38(%rsp), %rsi
    312b:      	movl	$0x1, %eax
    3130:      	callq	*%rax
    3132:      	testq	%rax, %rax
    3135:      	movq	%r12, 0x30(%rsp)
    313a:      	je	0x314a <generic_tracepoint_filter+0xaa>
    313c:      	movq	%rax, %r14
    313f:      	cmpq	$0x0, 0x8(%rax)
    3144:      	jne	0x3f62 <generic_tracepoint_filter+0xec2>
    314a:      	movl	$0xb00, %edx            # imm = 0xB00
    314f:      	movq	0x50(%rsp), %rcx
    3154:      	addq	%rdx, %rcx
    3157:      	leaq	0x50(%rsp), %rdi
    315c:      	movl	$0x8, %esi
    3161:      	movl	$0x71, %eax
    3166:      	addq	0x50(%rsp), %rdx
    316b:      	movl	$0x8, %esi
    3170:      	callq	*%rax
    3172:      	movq	0x50(%rsp), %rcx
    3177:      	testq	%rcx, %rcx
    317a:      	je	0x330f <generic_tracepoint_filter+0x26f>
    3180:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    3187:      	leaq	0x48(%rsp), %rdi
    318c:      	movl	$0x4, %edx
    3191:      	movl	$0x71, %eax
    3196:      	movl	$0xaf4, %edx            # imm = 0xAF4
    319b:      	addq	0x50(%rsp), %rdx
    31a0:      	movl	$0x4, %esi
    31a5:      	callq	*%rax
    31a7:      	movl	0x48(%rsp), %eax
    31ab:      	movl	%eax, 0x38(%rsp)
    31af:      	movq	(%rip), %rdi            # 0x31b6 <generic_tracepoint_filter+0x116>
    31b6:      	leaq	0x38(%rsp), %rsi
    31bb:      	movl	$0x1, %eax
    31c0:      	callq	*%rax
    31c2:      	testq	%rax, %rax
    31c5:      	je	0x31d5 <generic_tracepoint_filter+0x135>
    31c7:      	movq	%rax, %r14
    31ca:      	cmpq	$0x0, 0x8(%rax)
    31cf:      	jne	0x3f62 <generic_tracepoint_filter+0xec2>
    31d5:      	movl	$0xb00, %edx            # imm = 0xB00
    31da:      	movq	0x50(%rsp), %rcx
    31df:      	addq	%rdx, %rcx
    31e2:      	leaq	0x50(%rsp), %rdi
    31e7:      	movl	$0x8, %esi
    31ec:      	movl	$0x71, %eax
    31f1:      	addq	0x50(%rsp), %rdx
    31f6:      	movl	$0x8, %esi
    31fb:      	callq	*%rax
    31fd:      	movq	0x50(%rsp), %rcx
    3202:      	testq	%rcx, %rcx
    3205:      	je	0x330f <generic_tracepoint_filter+0x26f>
    320b:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    3212:      	leaq	0x48(%rsp), %rdi
    3217:      	movl	$0x4, %edx
    321c:      	movl	$0x71, %eax
    3221:      	movl	$0xaf4, %edx            # imm = 0xAF4
    3226:      	addq	0x50(%rsp), %rdx
    322b:      	movl	$0x4, %esi
    3230:      	callq	*%rax
    3232:      	movl	0x48(%rsp), %eax
    3236:      	movl	%eax, 0x38(%rsp)
    323a:      	movq	(%rip), %rdi            # 0x3241 <generic_tracepoint_filter+0x1a1>
    3241:      	leaq	0x38(%rsp), %rsi
    3246:      	movl	$0x1, %eax
    324b:      	callq	*%rax
    324d:      	testq	%rax, %rax
    3250:      	je	0x3260 <generic_tracepoint_filter+0x1c0>
    3252:      	movq	%rax, %r14
    3255:      	cmpq	$0x0, 0x8(%rax)
    325a:      	jne	0x3f62 <generic_tracepoint_filter+0xec2>
    3260:      	movl	$0xb00, %edx            # imm = 0xB00
    3265:      	movq	0x50(%rsp), %rcx
    326a:      	addq	%rdx, %rcx
    326d:      	leaq	0x50(%rsp), %rdi
    3272:      	movl	$0x8, %esi
    3277:      	movl	$0x71, %eax
    327c:      	addq	0x50(%rsp), %rdx
    3281:      	movl	$0x8, %esi
    3286:      	callq	*%rax
    3288:      	movq	0x50(%rsp), %rcx
    328d:      	testq	%rcx, %rcx
    3290:      	je	0x330f <generic_tracepoint_filter+0x26f>
    3292:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    3299:      	leaq	0x48(%rsp), %rdi
    329e:      	movl	$0x4, %edx
    32a3:      	movl	$0x71, %eax
    32a8:      	movl	$0xaf4, %edx            # imm = 0xAF4
    32ad:      	addq	0x50(%rsp), %rdx
    32b2:      	movl	$0x4, %esi
    32b7:      	callq	*%rax
    32b9:      	movl	0x48(%rsp), %eax
    32bd:      	movl	%eax, 0x38(%rsp)
    32c1:      	movq	(%rip), %rdi            # 0x32c8 <generic_tracepoint_filter+0x228>
    32c8:      	leaq	0x38(%rsp), %rsi
    32cd:      	movl	$0x1, %eax
    32d2:      	callq	*%rax
    32d4:      	testq	%rax, %rax
    32d7:      	je	0x32e7 <generic_tracepoint_filter+0x247>
    32d9:      	movq	%rax, %r14
    32dc:      	cmpq	$0x0, 0x8(%rax)
    32e1:      	jne	0x3f62 <generic_tracepoint_filter+0xec2>
    32e7:      	movl	$0xb00, %edx            # imm = 0xB00
    32ec:      	movq	0x50(%rsp), %rcx
    32f1:      	addq	%rdx, %rcx
    32f4:      	leaq	0x50(%rsp), %rdi
    32f9:      	movl	$0x8, %esi
    32fe:      	movl	$0x71, %eax
    3303:      	addq	0x50(%rsp), %rdx
    3308:      	movl	$0x8, %esi
    330d:      	callq	*%rax
    330f:      	movl	$0x23, %eax
    3314:      	callq	*%rax
    3316:      	movq	%rax, %r13
    3319:      	leaq	0xaf4(%rax), %rdx
    3320:      	leaq	0x50(%rsp), %rdi
    3325:      	movl	$0x4, %ecx
    332a:      	movl	$0x4, %eax
    332f:      	movl	$0x4, %r14d
    3335:      	movl	$0x4, %esi
    333a:      	callq	*%rax
    333c:      	movl	0x50(%rsp), %eax
    3340:      	movl	%eax, 0x5f10(%r12)
    3348:      	movl	$0x7d, %eax
    334d:      	callq	*%rax
    334f:      	movq	%rax, 0x5f18(%r12)
    3357:      	movl	$0x0, 0x5f20(%r12)
    3363:      	movq	$0x0, 0x5f28(%r12)
    336f:      	movl	$0x0, 0x5f30(%r12)
    337b:      	leaq	0x60(%r13), %rdx
    337f:      	leaq	0x38(%rsp), %rdi
    3384:      	movl	$0x8, %ecx
    3389:      	movl	$0x71, %eax
    338e:      	movl	$0x8, %esi
    3393:      	callq	*%rax
    3395:      	movq	0x38(%rsp), %rcx
    339a:      	xorl	%ebx, %ebx
    339c:      	testq	%rcx, %rcx
    339f:      	je	0x340e <generic_tracepoint_filter+0x36e>
    33a1:      	addq	$0x4, %rcx
    33a5:      	leaq	0x48(%rsp), %rdi
    33aa:      	movl	$0x4, %edx
    33af:      	movl	$0x71, %eax
    33b4:      	movq	0x38(%rsp), %rdx
    33b9:      	addq	$0x4, %rdx
    33bd:      	movl	$0x4, %esi
    33c2:      	callq	*%rax
    33c4:      	movl	0x48(%rsp), %eax
    33c8:      	testl	%eax, %eax
    33ca:      	je	0x340e <generic_tracepoint_filter+0x36e>
    33cc:      	movq	0x38(%rsp), %rcx
    33d1:      	shll	$0x4, %eax
    33d4:      	addq	%rax, %rcx
    33d7:      	addq	$0x80, %rcx
    33de:      	leaq	0x50(%rsp), %rdi
    33e3:      	movl	$0x10, %edx
    33e8:      	movl	$0x71, %eax
    33ed:      	movq	0x38(%rsp), %rcx
    33f2:      	movl	0x48(%rsp), %edx
    33f6:      	shll	$0x4, %edx
    33f9:      	addq	%rcx, %rdx
    33fc:      	addq	$0x80, %rdx
    3403:      	movl	$0x10, %esi
    3408:      	callq	*%rax
    340a:      	movl	0x50(%rsp), %ebx
    340e:      	movl	%ebx, 0x5f34(%r12)
    3416:      	leaq	0xd00(%r13), %r15
    341d:      	leaq	0x50(%rsp), %rdi
    3422:      	movl	$0x8, %ecx
    3427:      	movl	$0x4, %eax
    342c:      	leaq	0x5f60(%r12), %rbx
    3434:      	movl	$0x8, %esi
    3439:      	movq	%r15, %rdx
    343c:      	callq	*%rax
    343e:      	movq	0x50(%rsp), %r12
    3443:      	movq	0x30(%rsp), %rax
    3448:      	leaq	0x5f68(%rax), %rdi
    344f:      	leaq	0x40(%r12), %rdx
    3454:      	movl	$0x8, %ecx
    3459:      	movl	$0x4, %eax
    345e:      	movl	$0x8, %esi
    3463:      	callq	*%rax
    3465:      	movq	0x30(%rsp), %rax
    346a:      	leaq	0x5f70(%rax), %rdi
    3471:      	leaq	0x30(%r12), %rdx
    3476:      	movl	$0x8, %ecx
    347b:      	movl	$0x4, %eax
    3480:      	movl	$0x8, %esi
    3485:      	callq	*%rax
    3487:      	addq	$0x38, %r12
    348b:      	movl	$0x8, %ecx
    3490:      	movl	$0x4, %eax
    3495:      	movq	%rbx, %rdi
    3498:      	movl	$0x8, %esi
    349d:      	movq	%r12, %rdx
    34a0:      	movq	0x30(%rsp), %r12
    34a5:      	callq	*%rax
    34a7:      	leaq	0x5f38(%r12), %rbx
    34af:      	leaq	0xd70(%r13), %rdx
    34b6:      	leaq	0x48(%rsp), %rdi
    34bb:      	movl	$0x8, %ecx
    34c0:      	movl	$0x4, %eax
    34c5:      	movl	$0x8, %esi
    34ca:      	callq	*%rax
    34cc:      	movq	0x48(%rsp), %rcx
    34d1:      	leaq	0x50(%rsp), %rdi
    34d6:      	movl	$0x48, %edx
    34db:      	movl	$0x4, %eax
    34e0:      	movq	0x48(%rsp), %rdx
    34e5:      	movl	$0x48, %esi
    34ea:      	callq	*%rax
    34ec:      	movl	$0x218, %edx            # imm = 0x218
    34f1:      	movq	0x58(%rsp), %rcx
    34f6:      	addq	%rdx, %rcx
    34f9:      	movl	$0x4, %eax
    34fe:      	addq	0x58(%rsp), %rdx
    3503:      	movq	%rbx, %rdi
    3506:      	movl	$0x4, %esi
    350b:      	callq	*%rax
    350d:      	leaq	0x5f3c(%r12), %rdi
    3515:      	movl	$0x4d8, %edx            # imm = 0x4D8
    351a:      	movq	0x60(%rsp), %rcx
    351f:      	addq	%rdx, %rcx
    3522:      	movl	$0x4, %eax
    3527:      	addq	0x60(%rsp), %rdx
    352c:      	movl	$0x4, %esi
    3531:      	callq	*%rax
    3533:      	leaq	0x5f40(%r12), %rdi
    353b:      	movq	0x68(%rsp), %rcx
    3540:      	addq	$0x58, %rcx
    3544:      	movl	$0x4, %eax
    3549:      	movq	0x68(%rsp), %rdx
    354e:      	addq	$0x58, %rdx
    3552:      	movl	$0x4, %esi
    3557:      	callq	*%rax
    3559:      	movq	$0x0, 0xa0(%rsp)
    3565:      	leaq	0xb58(%r13), %rdx
    356c:      	leaq	0xa0(%rsp), %rdi
    3574:      	movl	$0x8, %ecx
    3579:      	movl	$0x4, %eax
    357e:      	movl	$0x8, %esi
    3583:      	callq	*%rax
    3585:      	movq	0xa0(%rsp), %rcx
    358d:      	testq	%rcx, %rcx
    3590:      	je	0x3649 <generic_tracepoint_filter+0x5a9>
    3596:      	movl	$0x0, 0xc0(%rsp)
    35a1:      	addq	$0x4, %rcx
    35a5:      	leaq	0xc0(%rsp), %rdi
    35ad:      	movl	$0x4, %edx
    35b2:      	movl	$0x4, %eax
    35b7:      	movq	0xa0(%rsp), %rdx
    35bf:      	addq	$0x4, %rdx
    35c3:      	movl	$0x4, %esi
    35c8:      	callq	*%rax
    35ca:      	movq	0xa0(%rsp), %rax
    35d2:      	movslq	0xc0(%rsp), %rcx
    35da:      	shlq	$0x4, %rcx
    35de:      	addq	%rax, %rcx
    35e1:      	addq	$0x80, %rcx
    35e8:      	leaq	0x38(%rsp), %rdi
    35ed:      	movl	$0x10, %edx
    35f2:      	movl	$0x4, %eax
    35f7:      	movq	0xa0(%rsp), %rcx
    35ff:      	movslq	0xc0(%rsp), %rdx
    3607:      	shlq	$0x4, %rdx
    360b:      	addq	%rcx, %rdx
    360e:      	addq	$0x80, %rdx
    3615:      	movl	$0x10, %esi
    361a:      	callq	*%rax
    361c:      	leaq	0x5f44(%r12), %rdi
    3624:      	movl	$0x158, %edx            # imm = 0x158
    3629:      	movq	0x40(%rsp), %rcx
    362e:      	addq	%rdx, %rcx
    3631:      	movl	$0x4, %esi
    3636:      	movl	$0x4, %eax
    363b:      	addq	0x40(%rsp), %rdx
    3640:      	movl	$0x4, %esi
    3645:      	callq	*%rax
    3647:      	jmp	0x3655 <generic_tracepoint_filter+0x5b5>
    3649:      	movl	$0x0, 0x5f44(%r12)
    3655:      	movq	%rbp, 0xb0(%rsp)
    365d:      	leaq	0x5f48(%r12), %rdi
    3665:      	movl	$0x158, %ebx            # imm = 0x158
    366a:      	movq	0x70(%rsp), %rcx
    366f:      	addq	%rbx, %rcx
    3672:      	movl	$0x4, %edx
    3677:      	movl	$0x4, %eax
    367c:      	movq	0x70(%rsp), %rdx
    3681:      	addq	%rbx, %rdx
    3684:      	movl	$0x4, %esi
    3689:      	callq	*%rax
    368b:      	leaq	0x5f4c(%r12), %rdi
    3693:      	movl	$0x118, %edx            # imm = 0x118
    3698:      	movq	0x78(%rsp), %rcx
    369d:      	addq	%rdx, %rcx
    36a0:      	movl	$0x4, %esi
    36a5:      	movl	$0x4, %eax
    36aa:      	addq	0x78(%rsp), %rdx
    36af:      	movl	$0x4, %esi
    36b4:      	callq	*%rax
    36b6:      	leaq	0x5f50(%r12), %rdi
    36be:      	movl	$0x98, %r12d
    36c4:      	movq	0x80(%rsp), %rcx
    36cc:      	addq	%r12, %rcx
    36cf:      	movl	$0x4, %edx
    36d4:      	movl	$0x4, %eax
    36d9:      	movq	0x80(%rsp), %rdx
    36e1:      	addq	%r12, %rdx
    36e4:      	movl	$0x4, %esi
    36e9:      	callq	*%rax
    36eb:      	movq	0x30(%rsp), %rax
    36f0:      	leaq	0x5f54(%rax), %rdi
    36f7:      	movq	0x88(%rsp), %rcx
    36ff:      	addq	%r12, %rcx
    3702:      	movl	$0x4, %edx
    3707:      	movl	$0x4, %eax
    370c:      	addq	0x88(%rsp), %r12
    3714:      	movl	$0x4, %esi
    3719:      	movq	%r12, %rdx
    371c:      	movq	0x30(%rsp), %r12
    3721:      	callq	*%rax
    3723:      	leaq	0x5f58(%r12), %rdi
    372b:      	movq	0x90(%rsp), %rcx
    3733:      	addq	$0x58, %rcx
    3737:      	movl	$0x4, %edx
    373c:      	movl	$0x4, %eax
    3741:      	movq	0x90(%rsp), %rdx
    3749:      	addq	$0x58, %rdx
    374d:      	movl	$0x4, %esi
    3752:      	callq	*%rax
    3754:      	movq	$0x0, 0x38(%rsp)
    375d:      	movq	$0x0, 0xa0(%rsp)
    3769:      	leaq	0x38(%rsp), %rdi
    376e:      	movl	$0x8, %ecx
    3773:      	movl	$0x4, %eax
    3778:      	movl	$0x8, %esi
    377d:      	movq	%r15, %rdx
    3780:      	callq	*%rax
    3782:      	movl	$0x90, %edx
    3787:      	movq	0x38(%rsp), %rcx
    378c:      	addq	%rdx, %rcx
    378f:      	leaq	0xa0(%rsp), %rdi
    3797:      	movl	$0x8, %esi
    379c:      	movl	$0x4, %eax
    37a1:      	addq	0x38(%rsp), %rdx
    37a6:      	movl	$0x8, %esi
    37ab:      	callq	*%rax
    37ad:      	leaq	0x5f5c(%r12), %rdi
    37b5:      	movq	0xa0(%rsp), %rcx
    37bd:      	addq	%rbx, %rcx
    37c0:      	movl	$0x4, %edx
    37c5:      	movl	$0x4, %eax
    37ca:      	addq	0xa0(%rsp), %rbx
    37d2:      	movl	$0x4, %esi
    37d7:      	movq	%rbx, %rdx
    37da:      	callq	*%rax
    37dc:      	cmpl	$0x1, 0x5f34(%r12)
    37e5:      	jne	0x37f0 <generic_tracepoint_filter+0x750>
    37e7:      	orb	$0x2, 0x5f33(%r12)
    37f0:      	leaq	0x5f78(%r12), %rdi
    37f8:      	movl	$0x308, %edx            # imm = 0x308
    37fd:      	movq	%rdi, 0xa8(%rsp)
    3805:      	xorl	%esi, %esi
    3807:      	callq	0x380c <generic_tracepoint_filter+0x76c>
    380c:      	leaq	0x6290(%r12), %rax
    3814:      	movq	%rax, 0x8(%rsp)
    3819:      	addq	$0xa78, %r13            # imm = 0xA78
    3820:      	leaq	0x38(%rsp), %rdi
    3825:      	movl	$0x8, %ecx
    382a:      	movl	$0x4, %eax
    382f:      	movl	$0x8, %esi
    3834:      	movq	%r13, %rdx
    3837:      	callq	*%rax
    3839:      	movl	$0x5f8, %edx            # imm = 0x5F8
    383e:      	movq	0x38(%rsp), %rcx
    3843:      	addq	%rdx, %rcx
    3846:      	leaq	0x50(%rsp), %rdi
    384b:      	movl	$0x8, %esi
    3850:      	movl	$0x4, %eax
    3855:      	addq	0x38(%rsp), %rdx
    385a:      	movl	$0x8, %esi
    385f:      	callq	*%rax
    3861:      	movq	0x50(%rsp), %rbx
    3866:      	movl	$0x0, 0xcc(%rsp)
    3871:      	movq	(%rip), %rdi            # 0x3878 <generic_tracepoint_filter+0x7d8>
    3878:      	leaq	0xcc(%rsp), %rsi
    3880:      	movl	$0x1, %eax
    3885:      	callq	*%rax
    3887:      	testq	%rax, %rax
    388a:      	je	0x3bcc <generic_tracepoint_filter+0xb2c>
    3890:      	movq	%rax, %r15
    3893:      	movl	$0x1000, 0x6410(%r12)   # imm = 0x1000
    389f:      	leaq	0x1000(%rax), %r13
    38a6:      	movl	$0x23, %eax
    38ab:      	callq	*%rax
    38ad:      	leaq	0xd50(%rax), %rdx
    38b4:      	leaq	0xe8(%rsp), %rdi
    38bc:      	movl	$0x8, %ecx
    38c1:      	movl	$0x4, %eax
    38c6:      	movl	$0x8, %esi
    38cb:      	callq	*%rax
    38cd:      	movq	0xe8(%rsp), %r12
    38d5:      	leaq	0x48(%rbx), %rbp
    38d9:      	leaq	0xf0(%rsp), %rdi
    38e1:      	movl	$0x8, %ecx
    38e6:      	movl	$0x4, %eax
    38eb:      	movl	$0x8, %esi
    38f0:      	movq	%rbp, %rdx
    38f3:      	callq	*%rax
    38f5:      	movq	0xf0(%rsp), %r14
    38fd:      	leaq	0x10(%r14), %rdx
    3901:      	leaq	0x50(%rsp), %rdi
    3906:      	movl	$0x8, %ecx
    390b:      	movl	$0x4, %eax
    3910:      	movl	$0x8, %esi
    3915:      	callq	*%rax
    3917:      	cmpq	$0x0, 0x50(%rsp)
    391d:      	je	0x3c56 <generic_tracepoint_filter+0xbb6>
    3923:      	movq	%rbp, 0xb8(%rsp)
    392b:      	movq	$0x0, 0x58(%rsp)
    3934:      	movq	$0x0, 0x50(%rsp)
    393d:      	movq	%r15, 0x60(%rsp)
    3942:      	movq	$0x0, 0x68(%rsp)
    394b:      	movq	$0x0, 0x70(%rsp)
    3954:      	movq	$0x0, 0x78(%rsp)
    395d:      	movq	%r13, 0x28(%rsp)
    3962:      	movq	%r13, 0x80(%rsp)
    396a:      	movq	0x30(%rsp), %rax
    396f:      	movl	0x6410(%rax), %eax
    3975:      	movl	%eax, 0x88(%rsp)
    397c:      	leaq	0x18(%r12), %r15
    3981:      	movb	$0x0, 0x8c(%rsp)
    3989:      	addq	$0x20, %r12
    398d:      	leaq	0x50(%rsp), %rdi
    3992:      	movl	$0x8, %r14d
    3998:      	movl	$0x4, %eax
    399d:      	addq	$0x40, %rbx
    39a1:      	leaq	0x58(%rsp), %r13
    39a6:      	leaq	0x68(%rsp), %rbp
    39ab:      	movl	$0x8, %esi
    39b0:      	movq	%r12, %rdx
    39b3:      	callq	*%rax
    39b5:      	movl	$0x8, %ecx
    39ba:      	movl	$0x4, %eax
    39bf:      	movq	%r13, %rdi
    39c2:      	movl	$0x8, %esi
    39c7:      	movq	%r15, %rdx
    39ca:      	callq	*%rax
    39cc:      	movl	$0x8, %ecx
    39d1:      	movl	$0x4, %eax
    39d6:      	movq	0xb8(%rsp), %rdx
    39de:      	movq	%rbp, %rdi
    39e1:      	movl	$0x8, %esi
    39e6:      	callq	*%rax
    39e8:      	movl	$0x8, %ecx
    39ed:      	movl	$0x4, %eax
    39f2:      	leaq	0x70(%rsp), %rdi
    39f7:      	movl	$0x8, %esi
    39fc:      	movq	%rbx, %rdx
    39ff:      	callq	*%rax
    3a01:      	movq	0x70(%rsp), %rax
    3a06:      	addq	$-0x20, %rax
    3a0a:      	movq	%rax, 0x78(%rsp)
    3a0f:      	movl	$0x80, %ebp
    3a14:      	leaq	0x48(%rsp), %rbx
    3a19:      	nopl	(%rax)
    3a20:      	movq	0x68(%rsp), %r15
    3a25:      	movq	0x70(%rsp), %rdx
    3a2a:      	movq	0x78(%rsp), %r12
    3a2f:      	cmpq	0x50(%rsp), %r15
    3a34:      	jne	0x3a41 <generic_tracepoint_filter+0x9a1>
    3a36:      	cmpq	0x58(%rsp), %rdx
    3a3b:      	je	0x3cb5 <generic_tracepoint_filter+0xc15>
    3a41:      	movl	$0x4, %eax
    3a46:      	leaq	0xc0(%rsp), %rdi
    3a4e:      	movl	$0x8, %esi
    3a53:      	callq	*%rax
    3a55:      	cmpq	0xc0(%rsp), %r15
    3a5d:      	je	0x3b70 <generic_tracepoint_filter+0xad0>
    3a63:      	leaq	0x18(%r15), %r13
    3a67:      	movl	$0x4, %eax
    3a6c:      	movq	%rbx, %rdi
    3a6f:      	movl	$0x8, %esi
    3a74:      	movq	%r13, %rdx
    3a77:      	callq	*%rax
    3a79:      	cmpq	%r15, 0x48(%rsp)
    3a7e:      	je	0x3b70 <generic_tracepoint_filter+0xad0>
    3a84:      	movl	$0x4, %eax
    3a89:      	leaq	0xa0(%rsp), %rdi
    3a91:      	movl	$0x8, %esi
    3a96:      	movq	%r13, %rdx
    3a99:      	callq	*%rax
    3a9b:      	addq	$0x20, %r15
    3a9f:      	movl	$0x4, %eax
    3aa4:      	leaq	0x38(%rsp), %rdi
    3aa9:      	movl	$0x10, %ecx
    3aae:      	movl	$0x10, %esi
    3ab3:      	movq	%r15, %rdx
    3ab6:      	callq	*%rax
    3ab8:      	movq	0x60(%rsp), %r15
    3abd:      	movq	0x80(%rsp), %rax
    3ac5:      	movl	0x3c(%rsp), %r12d
    3aca:      	subq	%r15, %rax
    3acd:      	movl	0x88(%rsp), %r13d
    3ad5:      	movl	%r12d, %edx
    3ad8:      	subl	%r13d, %edx
    3adb:      	movl	$0x0, %ecx
    3ae0:      	cmovbl	%ecx, %edx
    3ae3:      	addq	0x40(%rsp), %rdx
    3ae8:      	xorl	%esi, %esi
    3aea:      	cmpl	%r12d, %r13d
    3aed:      	seta	%sil
    3af1:      	movl	%r12d, %ecx
    3af4:      	cmovbl	%r13d, %ecx
    3af8:      	addl	%ecx, %esi
    3afa:      	movl	%r13d, %edi
    3afd:      	subl	%esi, %edi
    3aff:      	movl	%edi, 0x88(%rsp)
    3b06:      	subq	%rsi, %rax
    3b09:      	jb	0x3cbd <generic_tracepoint_filter+0xc1d>
    3b0f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    3b15:      	ja	0x3cbd <generic_tracepoint_filter+0xc1d>
    3b1b:      	cmpl	%r12d, %r13d
    3b1e:      	jbe	0x3b25 <generic_tracepoint_filter+0xa85>
    3b20:      	movb	$0x2f, (%r15,%rax)
    3b25:      	xorl	%edi, %edi
    3b27:      	cmpl	%r12d, %r13d
    3b2a:      	seta	%dil
    3b2e:      	movzbl	%cl, %esi
    3b31:      	addq	%rax, %r15
    3b34:      	addq	%r15, %rdi
    3b37:      	movl	$0x4, %eax
    3b3c:      	callq	*%rax
    3b3e:      	movq	%r15, 0x80(%rsp)
    3b46:      	cmpl	%r12d, %r13d
    3b49:      	jbe	0x3cbd <generic_tracepoint_filter+0xc1d>
    3b4f:      	movq	0xa0(%rsp), %rax
    3b57:      	movq	%rax, 0x68(%rsp)
    3b5c:      	decl	%ebp
    3b5e:      	jne	0x3a20 <generic_tracepoint_filter+0x980>
    3b64:      	jmp	0x3cbd <generic_tracepoint_filter+0xc1d>
    3b69:      	nopl	(%rax)
    3b70:      	leaq	0x10(%r12), %rdx
    3b75:      	movl	$0x4, %eax
    3b7a:      	movq	%rbx, %rdi
    3b7d:      	movl	$0x8, %esi
    3b82:      	callq	*%rax
    3b84:      	movq	0x78(%rsp), %rax
    3b89:      	cmpq	0x48(%rsp), %rax
    3b8e:      	je	0x3dec <generic_tracepoint_filter+0xd4c>
    3b94:      	addq	$0x18, %r12
    3b98:      	movl	$0x4, %eax
    3b9d:      	leaq	0x68(%rsp), %rdi
    3ba2:      	movl	$0x8, %esi
    3ba7:      	movq	%r12, %rdx
    3baa:      	callq	*%rax
    3bac:      	movq	0x48(%rsp), %rax
    3bb1:      	movq	%rax, 0x78(%rsp)
    3bb6:      	addq	$0x20, %rax
    3bba:      	movq	%rax, 0x70(%rsp)
    3bbf:      	decl	%ebp
    3bc1:      	jne	0x3a20 <generic_tracepoint_filter+0x980>
    3bc7:      	jmp	0x3cbd <generic_tracepoint_filter+0xc1d>
    3bcc:      	movq	0xb0(%rsp), %rbp
    3bd4:      	movl	0x6410(%r12), %eax
    3bdc:      	leal	-0x101(%rax), %ecx
    3be2:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
    3be8:      	jbe	0x3f46 <generic_tracepoint_filter+0xea6>
    3bee:      	movzbl	%al, %ebx
    3bf1:      	leaq	0x5f80(%r12), %rdi
    3bf9:      	movl	$0x4, %eax
    3bfe:      	movq	0x8(%rsp), %rdx
    3c03:      	movl	%ebx, %esi
    3c05:      	callq	*%rax
    3c07:      	movq	%rax, %r15
    3c0a:      	testq	%rax, %rax
    3c0d:      	je	0x3d4d <generic_tracepoint_filter+0xcad>
    3c13:      	movl	%r15d, %eax
    3c16:      	negl	%eax
    3c18:      	movw	%ax, 0x50(%rsp)
    3c1d:      	movw	$0xf, 0x52(%rsp)
    3c24:      	movabsq	$0x400000164, %rax      # imm = 0x400000164
    3c2e:      	movq	%rax, 0x54(%rsp)
    3c33:      	movq	(%rip), %rdi            # 0x3c3a <generic_tracepoint_filter+0xb9a>
    3c3a:      	leaq	0x50(%rsp), %rsi
    3c3f:      	movl	$0x1, %eax
    3c44:      	callq	*%rax
    3c46:      	testq	%rax, %rax
    3c49:      	je	0x3d29 <generic_tracepoint_filter+0xc89>
    3c4f:      	incl	(%rax)
    3c51:      	jmp	0x3d4d <generic_tracepoint_filter+0xcad>
    3c56:      	leaq	0x18(%r14), %rdx
    3c5a:      	leaq	0x50(%rsp), %rdi
    3c5f:      	movl	$0x8, %ecx
    3c64:      	movl	$0x4, %eax
    3c69:      	movl	$0x8, %esi
    3c6e:      	callq	*%rax
    3c70:      	cmpq	%r14, 0x50(%rsp)
    3c75:      	je	0x3923 <generic_tracepoint_filter+0x883>
    3c7b:      	movq	0x30(%rsp), %rdx
    3c80:      	movl	0x6410(%rdx), %ecx
    3c86:      	leal	-0xa(%rcx), %eax
    3c89:      	movl	%eax, 0x6410(%rdx)
    3c8f:      	cmpl	$0x9, %ecx
    3c92:      	jg	0x4489 <generic_tracepoint_filter+0x13e9>
    3c98:      	movl	$0xffffffdc, 0x6414(%rdx) # imm = 0xFFFFFFDC
    3ca2:      	movq	%r13, %rbx
    3ca5:      	movq	0xb0(%rsp), %rbp
    3cad:      	movq	%rdx, %r12
    3cb0:      	jmp	0x3e34 <generic_tracepoint_filter+0xd94>
    3cb5:      	movb	$0x1, 0x8c(%rsp)
    3cbd:      	movq	0x80(%rsp), %rbx
    3cc5:      	movq	0x28(%rsp), %rcx
    3cca:      	cmpq	%rcx, %rbx
    3ccd:      	je	0x3e0a <generic_tracepoint_filter+0xd6a>
    3cd3:      	xorl	%ecx, %ecx
    3cd5:      	cmpb	$0x0, 0x8c(%rsp)
    3cdd:      	sete	%cl
    3ce0:      	addl	%ecx, %ecx
    3ce2:      	movl	0x88(%rsp), %eax
    3ce9:      	movq	0x30(%rsp), %r12
    3cee:      	movl	%eax, 0x6410(%r12)
    3cf6:      	movl	%ecx, 0x6414(%r12)
    3cfe:      	testl	%eax, %eax
    3d00:      	movq	0xb0(%rsp), %rbp
    3d08:      	jle	0x3d1b <generic_tracepoint_filter+0xc7b>
    3d0a:      	movl	$0x1000, %ecx           # imm = 0x1000
    3d0f:      	subl	%eax, %ecx
    3d11:      	movl	%ecx, 0x6410(%r12)
    3d19:      	movl	%ecx, %eax
    3d1b:      	testq	%rbx, %rbx
    3d1e:      	jne	0x3e34 <generic_tracepoint_filter+0xd94>
    3d24:      	jmp	0x3f2c <generic_tracepoint_filter+0xe8c>
    3d29:      	movl	$0x1, 0x38(%rsp)
    3d31:      	movq	(%rip), %rdi            # 0x3d38 <generic_tracepoint_filter+0xc98>
    3d38:      	xorl	%ecx, %ecx
    3d3a:      	leaq	0x50(%rsp), %rsi
    3d3f:      	leaq	0x38(%rsp), %rdx
    3d44:      	movl	$0x2, %eax
    3d49:      	xorl	%ecx, %ecx
    3d4b:      	callq	*%rax
    3d4d:      	testl	%r15d, %r15d
    3d50:      	cmovel	%ebx, %r15d
    3d54:      	movl	%r15d, 0x5f78(%r12)
    3d5c:      	cmpl	$0x7f, %ebx
    3d5f:      	movl	$0x7f, %esi
    3d64:      	cmovbl	%ebx, %esi
    3d67:      	leaq	0x6080(%r12), %rdi
    3d6f:      	leaq	0x6390(%r12), %rdx
    3d77:      	movl	$0x4, %eax
    3d7c:      	callq	*%rax
    3d7e:      	testq	%rax, %rax
    3d81:      	je	0x3f54 <generic_tracepoint_filter+0xeb4>
    3d87:      	negl	%eax
    3d89:      	movw	%ax, 0x50(%rsp)
    3d8e:      	movw	$0xf, 0x52(%rsp)
    3d95:      	movabsq	$0x40000016a, %rax      # imm = 0x40000016A
    3d9f:      	movq	%rax, 0x54(%rsp)
    3da4:      	movq	(%rip), %rdi            # 0x3dab <generic_tracepoint_filter+0xd0b>
    3dab:      	leaq	0x50(%rsp), %rsi
    3db0:      	movl	$0x1, %eax
    3db5:      	callq	*%rax
    3db7:      	testq	%rax, %rax
    3dba:      	je	0x3dc3 <generic_tracepoint_filter+0xd23>
    3dbc:      	incl	(%rax)
    3dbe:      	jmp	0x3f54 <generic_tracepoint_filter+0xeb4>
    3dc3:      	movl	$0x1, 0x38(%rsp)
    3dcb:      	movq	(%rip), %rdi            # 0x3dd2 <generic_tracepoint_filter+0xd32>
    3dd2:      	xorl	%ecx, %ecx
    3dd4:      	leaq	0x50(%rsp), %rsi
    3dd9:      	leaq	0x38(%rsp), %rdx
    3dde:      	movl	$0x2, %eax
    3de3:      	xorl	%ecx, %ecx
    3de5:      	callq	*%rax
    3de7:      	jmp	0x3f54 <generic_tracepoint_filter+0xeb4>
    3dec:      	movb	$0x1, 0x8c(%rsp)
    3df4:      	movq	0x80(%rsp), %rbx
    3dfc:      	movq	0x28(%rsp), %rcx
    3e01:      	cmpq	%rcx, %rbx
    3e04:      	jne	0x3cd3 <generic_tracepoint_filter+0xc33>
    3e0a:      	movq	0x30(%rsp), %r12
    3e0f:      	movl	$0x0, 0x6410(%r12)
    3e1b:      	movl	$0x0, 0x6414(%r12)
    3e27:      	xorl	%eax, %eax
    3e29:      	movq	%rcx, %rbx
    3e2c:      	movq	0xb0(%rsp), %rbp
    3e34:      	xorl	%ecx, %ecx
    3e36:      	movl	%eax, %r14d
    3e39:      	subl	$0x7f, %r14d
    3e3d:      	movl	$0x7f, %r15d
    3e43:      	cmovbl	%eax, %r15d
    3e47:      	cmovbl	%ecx, %r14d
    3e4b:      	cmpl	$0xff, %eax
    3e50:      	movl	$0xff, %ecx
    3e55:      	cmovbl	%eax, %ecx
    3e58:      	movzbl	%cl, %esi
    3e5b:      	movl	%esi, 0x6410(%r12)
    3e63:      	movl	$0x4, %eax
    3e68:      	movq	0x8(%rsp), %rdi
    3e6d:      	movq	%rbx, %rdx
    3e70:      	callq	*%rax
    3e72:      	testq	%rax, %rax
    3e75:      	je	0x3ed4 <generic_tracepoint_filter+0xe34>
    3e77:      	negl	%eax
    3e79:      	movw	%ax, 0x50(%rsp)
    3e7e:      	movw	$0x8, 0x52(%rsp)
    3e85:      	movabsq	$0x4000002de, %rax      # imm = 0x4000002DE
    3e8f:      	movq	%rax, 0x54(%rsp)
    3e94:      	movq	(%rip), %rdi            # 0x3e9b <generic_tracepoint_filter+0xdfb>
    3e9b:      	leaq	0x50(%rsp), %rsi
    3ea0:      	movl	$0x1, %eax
    3ea5:      	callq	*%rax
    3ea7:      	testq	%rax, %rax
    3eaa:      	je	0x3eb0 <generic_tracepoint_filter+0xe10>
    3eac:      	incl	(%rax)
    3eae:      	jmp	0x3ed4 <generic_tracepoint_filter+0xe34>
    3eb0:      	movl	$0x1, 0x38(%rsp)
    3eb8:      	movq	(%rip), %rdi            # 0x3ebf <generic_tracepoint_filter+0xe1f>
    3ebf:      	xorl	%ecx, %ecx
    3ec1:      	leaq	0x50(%rsp), %rsi
    3ec6:      	leaq	0x38(%rsp), %rdx
    3ecb:      	movl	$0x2, %eax
    3ed0:      	xorl	%ecx, %ecx
    3ed2:      	callq	*%rax
    3ed4:      	leaq	0x6390(%r12), %rdi
    3edc:      	addq	%r14, %rbx
    3edf:      	movl	$0x4, %eax
    3ee4:      	movl	%r15d, %esi
    3ee7:      	movq	%rbx, %rdx
    3eea:      	callq	*%rax
    3eec:      	testq	%rax, %rax
    3eef:      	je	0x3f2c <generic_tracepoint_filter+0xe8c>
    3ef1:      	negl	%eax
    3ef3:      	movw	%ax, 0x50(%rsp)
    3ef8:      	movw	$0x8, 0x52(%rsp)
    3eff:      	movabsq	$0x4000002e0, %rax      # imm = 0x4000002E0
    3f09:      	movq	%rax, 0x54(%rsp)
    3f0e:      	movq	(%rip), %rdi            # 0x3f15 <generic_tracepoint_filter+0xe75>
    3f15:      	leaq	0x50(%rsp), %rsi
    3f1a:      	movl	$0x1, %eax
    3f1f:      	callq	*%rax
    3f21:      	testq	%rax, %rax
    3f24:      	je	0x4446 <generic_tracepoint_filter+0x13a6>
    3f2a:      	incl	(%rax)
    3f2c:      	movl	0x6410(%r12), %eax
    3f34:      	leal	-0x101(%rax), %ecx
    3f3a:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
    3f40:      	ja	0x3bee <generic_tracepoint_filter+0xb4e>
    3f46:      	movq	0xa8(%rsp), %rax
    3f4e:      	movl	$0xffffffff, (%rax)     # imm = 0xFFFFFFFF
    3f54:      	leaq	0x5f10(%r12), %r14
    3f5c:      	orb	$0x10, 0x1(%r12)
    3f62:      	leaq	0x5ef8(%r12), %rsi
    3f6a:      	movq	(%rip), %rdi            # 0x3f71 <generic_tracepoint_filter+0xed1>
    3f71:      	movl	$0x1, %eax
    3f76:      	callq	*%rax
    3f78:      	testq	%rax, %rax
    3f7b:      	je	0x535c <generic_tracepoint_filter+0x22bc>
    3f81:      	movq	0x5eb8(%r12), %rbx
    3f89:      	cmpq	$0x6, %rbx
    3f8d:      	jae	0x41ca <generic_tracepoint_filter+0x112a>
    3f93:      	movslq	(%rax), %rcx
    3f96:      	testq	%rcx, %rcx
    3f99:      	je	0x41ef <generic_tracepoint_filter+0x114f>
    3f9f:      	cmpq	%rcx, %rbx
    3fa2:      	jae	0x41ca <generic_tracepoint_filter+0x112a>
    3fa8:      	movq	%rax, 0x8(%rsp)
    3fad:      	movq	%rcx, 0xb8(%rsp)
    3fb5:      	movq	%rbp, 0xb0(%rsp)
    3fbd:      	movl	%ebx, 0x50(%rsp)
    3fc1:      	movl	$0x0, 0x38(%rsp)
    3fc9:      	movq	(%rip), %rdi            # 0x3fd0 <generic_tracepoint_filter+0xf30>
    3fd0:      	leaq	0x50(%rsp), %rsi
    3fd5:      	movl	$0x1, %eax
    3fda:      	callq	*%rax
    3fdc:      	testq	%rax, %rax
    3fdf:      	movq	%r14, 0x28(%rsp)
    3fe4:      	je	0x420e <generic_tracepoint_filter+0x116e>
    3fea:      	movq	%rax, %r13
    3fed:      	movl	(%rax), %eax
    3fef:      	testl	%eax, %eax
    3ff1:      	je	0x420e <generic_tracepoint_filter+0x116e>
    3ff7:      	cmpl	$0x0, 0x68(%r14)
    3ffc:      	js	0x52fc <generic_tracepoint_filter+0x225c>
    4002:      	cmpl	$0x1b, %eax
    4005:      	ja	0x52fc <generic_tracepoint_filter+0x225c>
    400b:      	movl	$0x60, %ecx
    4010:      	btl	%eax, %ecx
    4013:      	jb	0x4658 <generic_tracepoint_filter+0x15b8>
    4019:      	movl	$0x4000100, %ecx        # imm = 0x4000100
    401e:      	btl	%eax, %ecx
    4021:      	jb	0x45c8 <generic_tracepoint_filter+0x1528>
    4027:      	movl	$0x8000200, %ecx        # imm = 0x8000200
    402c:      	btl	%eax, %ecx
    402f:      	jae	0x52fc <generic_tracepoint_filter+0x225c>
    4035:      	movq	%r13, %rsi
    4038:      	addq	$0x4, %rsi
    403c:      	movq	(%rip), %rdi            # 0x4043 <generic_tracepoint_filter+0xfa3>
    4043:      	movl	$0x1, %eax
    4048:      	callq	*%rax
    404a:      	testq	%rax, %rax
    404d:      	je	0x52fc <generic_tracepoint_filter+0x225c>
    4053:      	movq	%rax, %r15
    4056:      	movq	0x28(%rsp), %rax
    405b:      	movl	0x68(%rax), %eax
    405e:      	cmpl	$0x7f, %eax
    4061:      	movl	$0x7f, %r14d
    4067:      	cmovll	%eax, %r14d
    406b:      	movq	(%rip), %rdi            # 0x4072 <generic_tracepoint_filter+0xfd2>
    4072:      	leaq	0x38(%rsp), %rsi
    4077:      	movl	$0x1, %eax
    407c:      	callq	*%rax
    407e:      	testq	%rax, %rax
    4081:      	je	0x52fc <generic_tracepoint_filter+0x225c>
    4087:      	movq	%rax, %rbp
    408a:      	leal	(,%r14,8), %eax
    4092:      	movl	%eax, (%rbp)
    4095:      	movq	0x28(%rsp), %rax
    409a:      	cmpl	$0x0, 0x6c(%rax)
    409e:      	jne	0x4191 <generic_tracepoint_filter+0x10f1>
    40a4:      	movq	%r15, 0xa8(%rsp)
    40ac:      	movq	0x28(%rsp), %r15
    40b1:      	movl	0x68(%r15), %ecx
    40b5:      	movl	%ecx, %eax
    40b7:      	subl	%r14d, %eax
    40ba:      	movl	%r14d, %edx
    40bd:      	andl	$0x7f, %edx
    40c0:      	addl	%edx, %eax
    40c2:      	addl	%ecx, %edx
    40c4:      	movl	%r14d, %ecx
    40c7:      	notl	%ecx
    40c9:      	addl	%edx, %ecx
    40cb:      	subl	%r14d, %edx
    40ce:      	leal	-0x4(%rdx), %esi
    40d1:      	leaq	0x1f3(%r15), %rdi
    40d8:      	leal	-0x3(%rdx), %r8d
    40dc:      	addl	$-0x2, %edx
    40df:      	movq	$-0x3, %r9
    40e6:      	leal	(%rcx,%r9), %r10d
    40ea:      	addl	$0x3, %r10d
    40ee:      	andl	$0x7f, %r10d
    40f2:      	movzbl	0x170(%r15,%r10), %r10d
    40fb:      	movb	%r10b, -0x3(%rdi)
    40ff:      	leaq	(%rax,%r9), %r10
    4103:      	cmpq	$-0x2, %r10
    4107:      	je	0x4181 <generic_tracepoint_filter+0x10e1>
    4109:      	leal	(%rdx,%r9), %r11d
    410d:      	addl	$0x3, %r11d
    4111:      	andl	$0x7f, %r11d
    4115:      	movzbl	0x170(%r15,%r11), %r11d
    411e:      	movb	%r11b, -0x2(%rdi)
    4122:      	cmpq	$-0x1, %r10
    4126:      	je	0x4181 <generic_tracepoint_filter+0x10e1>
    4128:      	leal	(%r8,%r9), %r10d
    412c:      	addl	$0x3, %r10d
    4130:      	andl	$0x7f, %r10d
    4134:      	movzbl	0x170(%r15,%r10), %r10d
    413d:      	movb	%r10b, -0x1(%rdi)
    4141:      	movq	%rax, %r10
    4144:      	addq	%r9, %r10
    4147:      	je	0x4181 <generic_tracepoint_filter+0x10e1>
    4149:      	cmpq	$-0x7f, %r9
    414d:      	je	0x4181 <generic_tracepoint_filter+0x10e1>
    414f:      	leal	(%rsi,%r9), %r10d
    4153:      	addl	$0x3, %r10d
    4157:      	andl	$0x7f, %r10d
    415b:      	movzbl	0x170(%r15,%r10), %r10d
    4164:      	movb	%r10b, (%rdi)
    4167:      	addq	$0x4, %rdi
    416b:      	leaq	(%rax,%r9), %r10
    416f:      	addq	$-0x4, %r10
    4173:      	addq	$-0x4, %r9
    4177:      	cmpq	$-0x3, %r10
    417b:      	jne	0x40e6 <generic_tracepoint_filter+0x1046>
    4181:      	movl	$0x1, 0x6c(%r15)
    4189:      	movq	0xa8(%rsp), %r15
    4191:      	cmpl	$0x7f, %r14d
    4195:      	ja	0x41bd <generic_tracepoint_filter+0x111d>
    4197:      	movslq	%r14d, %rsi
    419a:      	movq	%rbp, %rdi
    419d:      	addq	$0x4, %rdi
    41a1:      	movq	0x28(%rsp), %rax
    41a6:      	leaq	0x1f0(%rax), %rdx
    41ad:      	movl	$0x4, %eax
    41b2:      	callq	*%rax
    41b4:      	testq	%rax, %rax
    41b7:      	js	0x52fc <generic_tracepoint_filter+0x225c>
    41bd:      	movl	$0x1, %eax
    41c2:      	movq	%r15, %rdi
    41c5:      	jmp	0x4653 <generic_tracepoint_filter+0x15b3>
    41ca:      	movl	(%r14), %eax
    41cd:      	movl	%eax, 0x10(%r12)
    41d2:      	movq	0x8(%r14), %rax
    41d6:      	movq	%rax, 0x18(%r12)
    41db:      	cmpb	$0x0, 0x5ec0(%r12)
    41e4:      	jne	0x5341 <generic_tracepoint_filter+0x22a1>
    41ea:      	jmp	0x535c <generic_tracepoint_filter+0x22bc>
    41ef:      	movb	$0x1, 0x5ec0(%r12)
    41f8:      	movl	(%r14), %eax
    41fb:      	movl	%eax, 0x10(%r12)
    4200:      	movq	0x8(%r14), %rax
    4204:      	movq	%rax, 0x18(%r12)
    4209:      	jmp	0x5341 <generic_tracepoint_filter+0x22a1>
    420e:      	movq	0x8(%rsp), %r10
    4213:      	movq	(%rip), %rax            # 0x421a <generic_tracepoint_filter+0x117a>
    421a:      	cmpb	$0x0, (%rax)
    421d:      	je	0x44c0 <generic_tracepoint_filter+0x1420>
    4223:      	movq	(%rip), %rdi            # 0x422a <generic_tracepoint_filter+0x118a>
    422a:      	movl	$0x1, %eax
    422f:      	movq	0x28(%rsp), %rsi
    4234:      	callq	*%rax
    4236:      	movq	0x8(%rsp), %r10
    423b:      	testq	%rax, %rax
    423e:      	je	0x44c0 <generic_tracepoint_filter+0x1420>
    4244:      	movq	%rax, %rbp
    4247:      	leal	0x5(%rbx), %eax
    424a:      	movl	%eax, 0x50(%rsp)
    424e:      	movl	$0x0, 0x38(%rsp)
    4256:      	movq	(%rip), %rdi            # 0x425d <generic_tracepoint_filter+0x11bd>
    425d:      	leaq	0x50(%rsp), %rsi
    4262:      	movl	$0x1, %eax
    4267:      	callq	*%rax
    4269:      	testq	%rax, %rax
    426c:      	je	0x44bb <generic_tracepoint_filter+0x141b>
    4272:      	movq	%rax, %r13
    4275:      	movl	(%rax), %eax
    4277:      	testl	%eax, %eax
    4279:      	je	0x44bb <generic_tracepoint_filter+0x141b>
    427f:      	cmpl	$0x0, (%rbp)
    4283:      	js	0x52fc <generic_tracepoint_filter+0x225c>
    4289:      	cmpl	$0x1b, %eax
    428c:      	ja	0x52fc <generic_tracepoint_filter+0x225c>
    4292:      	movl	$0x60, %ecx
    4297:      	btl	%eax, %ecx
    429a:      	jb	0x4776 <generic_tracepoint_filter+0x16d6>
    42a0:      	movl	$0x4000100, %ecx        # imm = 0x4000100
    42a5:      	btl	%eax, %ecx
    42a8:      	jb	0x46e8 <generic_tracepoint_filter+0x1648>
    42ae:      	movl	$0x8000200, %ecx        # imm = 0x8000200
    42b3:      	btl	%eax, %ecx
    42b6:      	jae	0x52fc <generic_tracepoint_filter+0x225c>
    42bc:      	movq	%r13, %rsi
    42bf:      	addq	$0x4, %rsi
    42c3:      	movq	(%rip), %rdi            # 0x42ca <generic_tracepoint_filter+0x122a>
    42ca:      	movl	$0x1, %eax
    42cf:      	callq	*%rax
    42d1:      	testq	%rax, %rax
    42d4:      	je	0x52fc <generic_tracepoint_filter+0x225c>
    42da:      	movq	%rax, %r15
    42dd:      	movl	(%rbp), %eax
    42e0:      	cmpl	$0x7f, %eax
    42e3:      	movl	$0x7f, %r14d
    42e9:      	cmovll	%eax, %r14d
    42ed:      	movq	(%rip), %rdi            # 0x42f4 <generic_tracepoint_filter+0x1254>
    42f4:      	leaq	0x38(%rsp), %rsi
    42f9:      	movl	$0x1, %eax
    42fe:      	callq	*%rax
    4300:      	testq	%rax, %rax
    4303:      	je	0x52fc <generic_tracepoint_filter+0x225c>
    4309:      	movq	%rax, %rcx
    430c:      	leal	(,%r14,8), %eax
    4314:      	movl	%eax, (%rcx)
    4316:      	cmpl	$0x0, 0x4(%rbp)
    431a:      	jne	0x4406 <generic_tracepoint_filter+0x1366>
    4320:      	movq	%rcx, 0xa8(%rsp)
    4328:      	movl	(%rbp), %ecx
    432b:      	movl	%ecx, %eax
    432d:      	subl	%r14d, %eax
    4330:      	movl	%r14d, %edx
    4333:      	andl	$0x7f, %edx
    4336:      	addl	%edx, %eax
    4338:      	addl	%ecx, %edx
    433a:      	movl	%r14d, %ecx
    433d:      	notl	%ecx
    433f:      	addl	%edx, %ecx
    4341:      	subl	%r14d, %edx
    4344:      	leal	-0x4(%rdx), %esi
    4347:      	leaq	0x18b(%rbp), %rdi
    434e:      	leal	-0x3(%rdx), %r8d
    4352:      	addl	$-0x2, %edx
    4355:      	movq	$-0x3, %r9
    435c:      	leal	(%rcx,%r9), %r10d
    4360:      	addl	$0x3, %r10d
    4364:      	andl	$0x7f, %r10d
    4368:      	movzbl	0x108(%rbp,%r10), %r10d
    4371:      	movb	%r10b, -0x3(%rdi)
    4375:      	leaq	(%rax,%r9), %r10
    4379:      	cmpq	$-0x2, %r10
    437d:      	je	0x43f7 <generic_tracepoint_filter+0x1357>
    437f:      	leal	(%rdx,%r9), %r11d
    4383:      	addl	$0x3, %r11d
    4387:      	andl	$0x7f, %r11d
    438b:      	movzbl	0x108(%rbp,%r11), %r11d
    4394:      	movb	%r11b, -0x2(%rdi)
    4398:      	cmpq	$-0x1, %r10
    439c:      	je	0x43f7 <generic_tracepoint_filter+0x1357>
    439e:      	leal	(%r8,%r9), %r10d
    43a2:      	addl	$0x3, %r10d
    43a6:      	andl	$0x7f, %r10d
    43aa:      	movzbl	0x108(%rbp,%r10), %r10d
    43b3:      	movb	%r10b, -0x1(%rdi)
    43b7:      	movq	%rax, %r10
    43ba:      	addq	%r9, %r10
    43bd:      	je	0x43f7 <generic_tracepoint_filter+0x1357>
    43bf:      	cmpq	$-0x7f, %r9
    43c3:      	je	0x43f7 <generic_tracepoint_filter+0x1357>
    43c5:      	leal	(%rsi,%r9), %r10d
    43c9:      	addl	$0x3, %r10d
    43cd:      	andl	$0x7f, %r10d
    43d1:      	movzbl	0x108(%rbp,%r10), %r10d
    43da:      	movb	%r10b, (%rdi)
    43dd:      	addq	$0x4, %rdi
    43e1:      	leaq	(%rax,%r9), %r10
    43e5:      	addq	$-0x4, %r10
    43e9:      	addq	$-0x4, %r9
    43ed:      	cmpq	$-0x3, %r10
    43f1:      	jne	0x435c <generic_tracepoint_filter+0x12bc>
    43f7:      	movl	$0x1, 0x4(%rbp)
    43fe:      	movq	0xa8(%rsp), %rcx
    4406:      	cmpl	$0x7f, %r14d
    440a:      	ja	0x4436 <generic_tracepoint_filter+0x1396>
    440c:      	movslq	%r14d, %rsi
    440f:      	movq	%rcx, %rdi
    4412:      	addq	$0x4, %rdi
    4416:      	addq	$0x188, %rbp            # imm = 0x188
    441d:      	movl	$0x4, %eax
    4422:      	movq	%rbp, %rdx
    4425:      	movq	%rcx, %r14
    4428:      	callq	*%rax
    442a:      	movq	%r14, %rcx
    442d:      	testq	%rax, %rax
    4430:      	js	0x52fc <generic_tracepoint_filter+0x225c>
    4436:      	movl	$0x1, %eax
    443b:      	movq	%r15, %rdi
    443e:      	movq	%rcx, %rsi
    4441:      	jmp	0x47d6 <generic_tracepoint_filter+0x1736>
    4446:      	movl	$0x1, 0x38(%rsp)
    444e:      	movq	(%rip), %rdi            # 0x4455 <generic_tracepoint_filter+0x13b5>
    4455:      	xorl	%ecx, %ecx
    4457:      	leaq	0x50(%rsp), %rsi
    445c:      	leaq	0x38(%rsp), %rdx
    4461:      	movl	$0x2, %eax
    4466:      	xorl	%ecx, %ecx
    4468:      	callq	*%rax
    446a:      	movl	0x6410(%r12), %eax
    4472:      	leal	-0x101(%rax), %ecx
    4478:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
    447e:      	jbe	0x3f46 <generic_tracepoint_filter+0xea6>
    4484:      	jmp	0x3bee <generic_tracepoint_filter+0xb4e>
    4489:      	movq	%rbp, 0xb8(%rsp)
    4491:      	movq	%r15, %r13
    4494:      	addq	$0xff6, %r13            # imm = 0xFF6
    449b:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
    44a5:      	movq	%rax, 0xff6(%r15)
    44ac:      	movw	$0x2964, 0xffe(%r15)    # imm = 0x2964
    44b6:      	jmp	0x392b <generic_tracepoint_filter+0x88b>
    44bb:      	movq	0x8(%rsp), %r10
    44c0:      	movl	%ebx, %eax
    44c2:      	leaq	0x4(,%rax,4), %rcx
    44ca:      	movl	0x4(%r10,%rax,4), %eax
    44cf:      	leal	(%rax,%rcx), %edx
    44d2:      	andl	$0x3ff, %edx            # imm = 0x3FF
    44d8:      	addl	%eax, %ecx
    44da:      	addl	$0x4, %ecx
    44dd:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    44e3:      	leaq	0x8(%rdx), %rbp
    44e7:      	cmpl	$0x5, (%rcx,%r10)
    44ec:      	jb	0x45be <generic_tracepoint_filter+0x151e>
    44f2:      	movq	%rdx, 0xd8(%rsp)
    44fa:      	movl	(%rbp,%r10), %edi
    44ff:      	movl	0x4(%rbp,%r10), %r8d
    4504:      	movl	0x8(%rbp,%r10), %edx
    4509:      	movq	$0x0, 0x58(%rsp)
    4512:      	movq	$0x0, 0x50(%rsp)
    451b:      	cmpl	$0x4, %edx
    451e:      	movl	$0x4, %ecx
    4523:      	cmovbl	%edx, %ecx
    4526:      	cmpl	$0x6, %edi
    4529:      	jne	0x453f <generic_tracepoint_filter+0x149f>
    452b:      	movabsq	$0x100000001, %rsi      # imm = 0x100000001
    4535:      	movq	%rsi, 0x50(%rsp)
    453a:      	movq	%rsi, 0x58(%rsp)
    453f:      	testl	%edx, %edx
    4541:      	movq	0x28(%rsp), %r14
    4546:      	je	0x4cc2 <generic_tracepoint_filter+0x1c22>
    454c:      	leaq	0x24(%r14), %rdx
    4550:      	testb	$0x1, %r8b
    4554:      	movq	%rdx, 0xe0(%rsp)
    455c:      	movq	%rdx, %r9
    455f:      	cmoveq	%r14, %r9
    4563:      	leaq	0x10(%r14), %rdx
    4567:      	movq	%rdx, 0xd0(%rsp)
    456f:      	leal	(%rax,%rbx,4), %r11d
    4573:      	addl	$0x4, %r11d
    4577:      	andl	$0x3ff, %r11d           # imm = 0x3FF
    457e:      	addq	$0x14, %r11
    4582:      	decq	%rcx
    4585:      	cmpq	$0x3, %rcx
    4589:      	movl	$0x3, %eax
    458e:      	cmovbq	%rcx, %rax
    4592:      	movl	%eax, %eax
    4594:      	leaq	0x4(,%rax,4), %rax
    459c:      	movq	%rax, 0xa8(%rsp)
    45a4:      	xorl	%ebx, %ebx
    45a6:      	movl	%edi, 0x4(%rsp)
    45aa:      	movq	%r8, 0x20(%rsp)
    45af:      	movq	%r9, 0x18(%rsp)
    45b4:      	movq	%r11, 0x10(%rsp)
    45b9:      	jmp	0x485c <generic_tracepoint_filter+0x17bc>
    45be:      	movl	$0x1, %eax
    45c3:      	jmp	0x4d03 <generic_tracepoint_filter+0x1c63>
    45c8:      	movq	%r13, %rsi
    45cb:      	addq	$0x4, %rsi
    45cf:      	movq	(%rip), %rdi            # 0x45d6 <generic_tracepoint_filter+0x1536>
    45d6:      	movl	$0x1, %eax
    45db:      	callq	*%rax
    45dd:      	testq	%rax, %rax
    45e0:      	je	0x52fc <generic_tracepoint_filter+0x225c>
    45e6:      	movq	%rax, %r14
    45e9:      	movq	(%rip), %rdi            # 0x45f0 <generic_tracepoint_filter+0x1550>
    45f0:      	leaq	0x38(%rsp), %rsi
    45f5:      	movl	$0x1, %eax
    45fa:      	callq	*%rax
    45fc:      	testq	%rax, %rax
    45ff:      	je	0x52fc <generic_tracepoint_filter+0x225c>
    4605:      	movq	%rax, %rbp
    4608:      	movl	$0x104, %edx            # imm = 0x104
    460d:      	movq	%rax, %rdi
    4610:      	xorl	%esi, %esi
    4612:      	callq	0x4617 <generic_tracepoint_filter+0x1577>
    4617:      	movq	0x28(%rsp), %rsi
    461c:      	movl	0x68(%rsi), %eax
    461f:      	leal	(,%rax,8), %ecx
    4626:      	movl	%ecx, (%rbp)
    4629:      	movq	%rbp, %rdi
    462c:      	addq	$0x4, %rdi
    4630:      	movzbl	%al, %ecx
    4633:      	leaq	0x70(%rsi), %rdx
    4637:      	movl	$0x4, %eax
    463c:      	movzbl	0x68(%rsi), %esi
    4640:      	callq	*%rax
    4642:      	testq	%rax, %rax
    4645:      	js	0x52fc <generic_tracepoint_filter+0x225c>
    464b:      	movl	$0x1, %eax
    4650:      	movq	%r14, %rdi
    4653:      	movq	%rbp, %rsi
    4656:      	jmp	0x46b1 <generic_tracepoint_filter+0x1611>
    4658:      	movl	0x8(%r13), %eax
    465c:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    4661:      	cmpq	%rcx, %rax
    4664:      	movq	0x28(%rsp), %rcx
    4669:      	je	0x4684 <generic_tracepoint_filter+0x15e4>
    466b:      	movq	0x370(%rcx), %rcx
    4672:      	btq	%rax, %rcx
    4676:      	jae	0x4684 <generic_tracepoint_filter+0x15e4>
    4678:      	movabsq	$0xbadc0ffee, %rax      # imm = 0xBADC0FFEE
    4682:      	jmp	0x46b3 <generic_tracepoint_filter+0x1613>
    4684:      	movq	(%rip), %rdi            # 0x468b <generic_tracepoint_filter+0x15eb>
    468b:      	leaq	0x50(%rsp), %rsi
    4690:      	movl	$0x1, %eax
    4695:      	callq	*%rax
    4697:      	testq	%rax, %rax
    469a:      	je	0x52fc <generic_tracepoint_filter+0x225c>
    46a0:      	movq	%rax, %rdi
    46a3:      	movq	0x28(%rsp), %rax
    46a8:      	leaq	0x70(%rax), %rsi
    46ac:      	movl	$0x1, %eax
    46b1:      	callq	*%rax
    46b3:      	movl	(%r13), %ecx
    46b7:      	cmpq	$0x25, %rcx
    46bb:      	movq	0x8(%rsp), %r10
    46c0:      	ja	0x479d <generic_tracepoint_filter+0x16fd>
    46c6:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    46d0:      	btq	%rcx, %rdx
    46d4:      	jae	0x479d <generic_tracepoint_filter+0x16fd>
    46da:      	testq	%rax, %rax
    46dd:      	jne	0x52fc <generic_tracepoint_filter+0x225c>
    46e3:      	jmp	0x4213 <generic_tracepoint_filter+0x1173>
    46e8:      	movq	%r13, %rsi
    46eb:      	addq	$0x4, %rsi
    46ef:      	movq	(%rip), %rdi            # 0x46f6 <generic_tracepoint_filter+0x1656>
    46f6:      	movl	$0x1, %eax
    46fb:      	callq	*%rax
    46fd:      	testq	%rax, %rax
    4700:      	je	0x52fc <generic_tracepoint_filter+0x225c>
    4706:      	movq	%rax, %r14
    4709:      	movq	(%rip), %rdi            # 0x4710 <generic_tracepoint_filter+0x1670>
    4710:      	leaq	0x38(%rsp), %rsi
    4715:      	movl	$0x1, %eax
    471a:      	callq	*%rax
    471c:      	testq	%rax, %rax
    471f:      	je	0x52fc <generic_tracepoint_filter+0x225c>
    4725:      	movq	%rax, %r15
    4728:      	movl	$0x104, %edx            # imm = 0x104
    472d:      	movq	%rax, %rdi
    4730:      	xorl	%esi, %esi
    4732:      	callq	0x4737 <generic_tracepoint_filter+0x1697>
    4737:      	movl	(%rbp), %eax
    473a:      	leal	(,%rax,8), %ecx
    4741:      	movl	%ecx, (%r15)
    4744:      	movq	%r15, %rdi
    4747:      	addq	$0x4, %rdi
    474b:      	movzbl	%al, %ecx
    474e:      	movq	%rbp, %rdx
    4751:      	addq	$0x8, %rdx
    4755:      	movl	$0x4, %eax
    475a:      	movzbl	(%rbp), %esi
    475e:      	callq	*%rax
    4760:      	testq	%rax, %rax
    4763:      	js	0x52fc <generic_tracepoint_filter+0x225c>
    4769:      	movl	$0x1, %eax
    476e:      	movq	%r14, %rdi
    4771:      	movq	%r15, %rsi
    4774:      	jmp	0x47d6 <generic_tracepoint_filter+0x1736>
    4776:      	movl	0x8(%r13), %eax
    477a:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    477f:      	cmpq	%rcx, %rax
    4782:      	je	0x47ab <generic_tracepoint_filter+0x170b>
    4784:      	movq	0x308(%rbp), %rcx
    478b:      	btq	%rax, %rcx
    478f:      	jae	0x47ab <generic_tracepoint_filter+0x170b>
    4791:      	movabsq	$0xbadc0ffee, %rax      # imm = 0xBADC0FFEE
    479b:      	jmp	0x47d8 <generic_tracepoint_filter+0x1738>
    479d:      	testq	%rax, %rax
    47a0:      	jne	0x4213 <generic_tracepoint_filter+0x1173>
    47a6:      	jmp	0x52fc <generic_tracepoint_filter+0x225c>
    47ab:      	movq	(%rip), %rdi            # 0x47b2 <generic_tracepoint_filter+0x1712>
    47b2:      	leaq	0x50(%rsp), %rsi
    47b7:      	movl	$0x1, %eax
    47bc:      	callq	*%rax
    47be:      	testq	%rax, %rax
    47c1:      	je	0x52fc <generic_tracepoint_filter+0x225c>
    47c7:      	movq	%rax, %rdi
    47ca:      	addq	$0x8, %rbp
    47ce:      	movl	$0x1, %eax
    47d3:      	movq	%rbp, %rsi
    47d6:      	callq	*%rax
    47d8:      	movl	(%r13), %ecx
    47dc:      	cmpq	$0x25, %rcx
    47e0:      	movq	0x8(%rsp), %r10
    47e5:      	ja	0x4805 <generic_tracepoint_filter+0x1765>
    47e7:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    47f1:      	btq	%rcx, %rdx
    47f5:      	jae	0x4805 <generic_tracepoint_filter+0x1765>
    47f7:      	testq	%rax, %rax
    47fa:      	jne	0x52fc <generic_tracepoint_filter+0x225c>
    4800:      	jmp	0x44c0 <generic_tracepoint_filter+0x1420>
    4805:      	testq	%rax, %rax
    4808:      	jne	0x44c0 <generic_tracepoint_filter+0x1420>
    480e:      	jmp	0x52fc <generic_tracepoint_filter+0x225c>
    4813:      	movq	0x30(%rsp), %r12
    4818:      	movq	0x28(%rsp), %r14
    481d:      	movq	0x8(%rsp), %r10
    4822:      	movl	0x4(%rsp), %edi
    4826:      	movq	0x20(%rsp), %r8
    482b:      	movq	0x18(%rsp), %r9
    4830:      	movq	0x10(%rsp), %r11
    4835:      	cmpl	$0x6, %edi
    4838:      	setne	%al
    483b:      	xorb	$0x1, %r13b
    483f:      	orb	%al, %r13b
    4842:      	movzbl	%r13b, %eax
    4846:      	movl	%eax, 0x50(%rsp,%rbx)
    484a:      	addq	$0x4, %rbx
    484e:      	cmpq	%rbx, 0xa8(%rsp)
    4856:      	je	0x4cc2 <generic_tracepoint_filter+0x1c22>
    485c:      	leaq	(%r11,%rbx), %rax
    4860:      	movl	(%r9), %ecx
    4863:      	cmpq	$0x3e8, %rax            # imm = 0x3E8
    4869:      	jbe	0x4a91 <generic_tracepoint_filter+0x19f1>
    486f:      	xorl	%r15d, %r15d
    4872:      	testb	$0x2, %r8b
    4876:      	je	0x4aae <generic_tracepoint_filter+0x1a0e>
    487c:      	testb	$0x1, %r8b
    4880:      	jne	0x4ace <generic_tracepoint_filter+0x1a2e>
    4886:      	movl	(%r14), %eax
    4889:      	movb	$0x1, %r13b
    488c:      	cmpq	%rax, %r15
    488f:      	je	0x4835 <generic_tracepoint_filter+0x1795>
    4891:      	movl	0x10(%r14), %eax
    4895:      	cmpq	%rax, %r15
    4898:      	je	0x4835 <generic_tracepoint_filter+0x1795>
    489a:      	movl	$0x1, %eax
    489f:      	movq	0xd0(%rsp), %rsi
    48a7:      	movq	(%rip), %rdi            # 0x48ae <generic_tracepoint_filter+0x180e>
    48ae:      	callq	*%rax
    48b0:      	testq	%rax, %rax
    48b3:      	je	0x4c91 <generic_tracepoint_filter+0x1bf1>
    48b9:      	movq	%rax, %rsi
    48bc:      	movl	(%rax), %eax
    48be:      	cmpq	%rax, %r15
    48c1:      	je	0x481d <generic_tracepoint_filter+0x177d>
    48c7:      	movl	0x10(%rsi), %eax
    48ca:      	cmpq	%rax, %r15
    48cd:      	je	0x481d <generic_tracepoint_filter+0x177d>
    48d3:      	addq	$0x10, %rsi
    48d7:      	movl	$0x1, %eax
    48dc:      	movq	(%rip), %rdi            # 0x48e3 <generic_tracepoint_filter+0x1843>
    48e3:      	callq	*%rax
    48e5:      	testq	%rax, %rax
    48e8:      	je	0x4c91 <generic_tracepoint_filter+0x1bf1>
    48ee:      	movq	%rax, %rsi
    48f1:      	movl	(%rax), %eax
    48f3:      	cmpq	%rax, %r15
    48f6:      	je	0x481d <generic_tracepoint_filter+0x177d>
    48fc:      	movl	0x10(%rsi), %eax
    48ff:      	cmpq	%rax, %r15
    4902:      	je	0x481d <generic_tracepoint_filter+0x177d>
    4908:      	addq	$0x10, %rsi
    490c:      	movl	$0x1, %eax
    4911:      	movq	(%rip), %rdi            # 0x4918 <generic_tracepoint_filter+0x1878>
    4918:      	callq	*%rax
    491a:      	testq	%rax, %rax
    491d:      	je	0x4c91 <generic_tracepoint_filter+0x1bf1>
    4923:      	movq	%rax, %rsi
    4926:      	movl	(%rax), %eax
    4928:      	cmpq	%rax, %r15
    492b:      	je	0x481d <generic_tracepoint_filter+0x177d>
    4931:      	movl	0x10(%rsi), %eax
    4934:      	cmpq	%rax, %r15
    4937:      	je	0x481d <generic_tracepoint_filter+0x177d>
    493d:      	addq	$0x10, %rsi
    4941:      	movl	$0x1, %eax
    4946:      	movq	(%rip), %rdi            # 0x494d <generic_tracepoint_filter+0x18ad>
    494d:      	callq	*%rax
    494f:      	testq	%rax, %rax
    4952:      	je	0x4c91 <generic_tracepoint_filter+0x1bf1>
    4958:      	movq	%rax, %rsi
    495b:      	movl	(%rax), %eax
    495d:      	cmpq	%rax, %r15
    4960:      	je	0x481d <generic_tracepoint_filter+0x177d>
    4966:      	movl	0x10(%rsi), %eax
    4969:      	cmpq	%rax, %r15
    496c:      	je	0x481d <generic_tracepoint_filter+0x177d>
    4972:      	addq	$0x10, %rsi
    4976:      	movl	$0x1, %eax
    497b:      	movq	(%rip), %rdi            # 0x4982 <generic_tracepoint_filter+0x18e2>
    4982:      	callq	*%rax
    4984:      	testq	%rax, %rax
    4987:      	je	0x4c91 <generic_tracepoint_filter+0x1bf1>
    498d:      	movq	%rax, %rsi
    4990:      	movl	(%rax), %eax
    4992:      	cmpq	%rax, %r15
    4995:      	je	0x481d <generic_tracepoint_filter+0x177d>
    499b:      	movl	0x10(%rsi), %eax
    499e:      	cmpq	%rax, %r15
    49a1:      	je	0x481d <generic_tracepoint_filter+0x177d>
    49a7:      	addq	$0x10, %rsi
    49ab:      	movl	$0x1, %eax
    49b0:      	movq	(%rip), %rdi            # 0x49b7 <generic_tracepoint_filter+0x1917>
    49b7:      	callq	*%rax
    49b9:      	testq	%rax, %rax
    49bc:      	je	0x4c91 <generic_tracepoint_filter+0x1bf1>
    49c2:      	movq	%rax, %rsi
    49c5:      	movl	(%rax), %eax
    49c7:      	cmpq	%rax, %r15
    49ca:      	je	0x4813 <generic_tracepoint_filter+0x1773>
    49d0:      	movl	0x10(%rsi), %eax
    49d3:      	cmpq	%rax, %r15
    49d6:      	je	0x4813 <generic_tracepoint_filter+0x1773>
    49dc:      	addq	$0x10, %rsi
    49e0:      	movl	$0x1, %eax
    49e5:      	movq	(%rip), %rdi            # 0x49ec <generic_tracepoint_filter+0x194c>
    49ec:      	callq	*%rax
    49ee:      	testq	%rax, %rax
    49f1:      	movq	0x30(%rsp), %r12
    49f6:      	movq	0x28(%rsp), %r14
    49fb:      	je	0x4c91 <generic_tracepoint_filter+0x1bf1>
    4a01:      	movq	%rax, %rsi
    4a04:      	movl	(%rax), %eax
    4a06:      	cmpq	%rax, %r15
    4a09:      	je	0x4813 <generic_tracepoint_filter+0x1773>
    4a0f:      	movl	0x10(%rsi), %eax
    4a12:      	cmpq	%rax, %r15
    4a15:      	je	0x4813 <generic_tracepoint_filter+0x1773>
    4a1b:      	addq	$0x10, %rsi
    4a1f:      	movl	$0x1, %eax
    4a24:      	movq	(%rip), %rdi            # 0x4a2b <generic_tracepoint_filter+0x198b>
    4a2b:      	callq	*%rax
    4a2d:      	testq	%rax, %rax
    4a30:      	movq	0x30(%rsp), %r12
    4a35:      	movq	0x28(%rsp), %r14
    4a3a:      	je	0x4c91 <generic_tracepoint_filter+0x1bf1>
    4a40:      	movq	%rax, %rsi
    4a43:      	movl	(%rax), %eax
    4a45:      	cmpq	%rax, %r15
    4a48:      	je	0x4813 <generic_tracepoint_filter+0x1773>
    4a4e:      	movl	0x10(%rsi), %eax
    4a51:      	cmpq	%rax, %r15
    4a54:      	movq	0x30(%rsp), %r12
    4a59:      	movq	0x28(%rsp), %r14
    4a5e:      	movq	0x8(%rsp), %r10
    4a63:      	movl	0x4(%rsp), %edi
    4a67:      	movq	0x20(%rsp), %r8
    4a6c:      	movq	0x18(%rsp), %r9
    4a71:      	movq	0x10(%rsp), %r11
    4a76:      	je	0x4835 <generic_tracepoint_filter+0x1795>
    4a7c:      	addq	$0x10, %rsi
    4a80:      	movl	$0x1, %eax
    4a85:      	movq	(%rip), %rcx            # 0x4a8c <generic_tracepoint_filter+0x19ec>
    4a8c:      	jmp	0x4c7e <generic_tracepoint_filter+0x1bde>
    4a91:      	movl	$0x4, %esi
    4a96:      	xorl	%edx, %edx
    4a98:      	divq	%rsi
    4a9b:      	andl	$0x3ff, %eax            # imm = 0x3FF
    4aa0:      	movl	(%r10,%rax,4), %r15d
    4aa4:      	testb	$0x2, %r8b
    4aa8:      	jne	0x487c <generic_tracepoint_filter+0x17dc>
    4aae:      	cmpl	$0x5, %edi
    4ab1:      	jne	0x4abc <generic_tracepoint_filter+0x1a1c>
    4ab3:      	cmpq	%rcx, %r15
    4ab6:      	jne	0x4cba <generic_tracepoint_filter+0x1c1a>
    4abc:      	cmpq	%rcx, %r15
    4abf:      	setne	%al
    4ac2:      	cmpl	$0x6, %edi
    4ac5:      	setne	%r13b
    4ac9:      	jmp	0x483f <generic_tracepoint_filter+0x179f>
    4ace:      	movq	0xe0(%rsp), %rax
    4ad6:      	movl	(%rax), %eax
    4ad8:      	testq	%rax, %rax
    4adb:      	je	0x4cba <generic_tracepoint_filter+0x1c1a>
    4ae1:      	movb	$0x1, %r13b
    4ae4:      	testq	%r15, %r15
    4ae7:      	je	0x4835 <generic_tracepoint_filter+0x1795>
    4aed:      	cmpq	%rax, %r15
    4af0:      	je	0x4835 <generic_tracepoint_filter+0x1795>
    4af6:      	movl	$0x1, %eax
    4afb:      	movq	0xd0(%rsp), %rsi
    4b03:      	movq	(%rip), %rdi            # 0x4b0a <generic_tracepoint_filter+0x1a6a>
    4b0a:      	callq	*%rax
    4b0c:      	testq	%rax, %rax
    4b0f:      	je	0x4c91 <generic_tracepoint_filter+0x1bf1>
    4b15:      	movq	%rax, %rsi
    4b18:      	movl	0x24(%rax), %eax
    4b1b:      	cmpq	%rax, %r15
    4b1e:      	je	0x481d <generic_tracepoint_filter+0x177d>
    4b24:      	addq	$0x10, %rsi
    4b28:      	movl	$0x1, %eax
    4b2d:      	movq	(%rip), %rdi            # 0x4b34 <generic_tracepoint_filter+0x1a94>
    4b34:      	callq	*%rax
    4b36:      	testq	%rax, %rax
    4b39:      	je	0x4c91 <generic_tracepoint_filter+0x1bf1>
    4b3f:      	movq	%rax, %rsi
    4b42:      	movl	0x24(%rax), %eax
    4b45:      	cmpq	%rax, %r15
    4b48:      	je	0x481d <generic_tracepoint_filter+0x177d>
    4b4e:      	addq	$0x10, %rsi
    4b52:      	movl	$0x1, %eax
    4b57:      	movq	(%rip), %rdi            # 0x4b5e <generic_tracepoint_filter+0x1abe>
    4b5e:      	callq	*%rax
    4b60:      	testq	%rax, %rax
    4b63:      	je	0x4c91 <generic_tracepoint_filter+0x1bf1>
    4b69:      	movq	%rax, %rsi
    4b6c:      	movl	0x24(%rax), %eax
    4b6f:      	cmpq	%rax, %r15
    4b72:      	je	0x481d <generic_tracepoint_filter+0x177d>
    4b78:      	addq	$0x10, %rsi
    4b7c:      	movl	$0x1, %eax
    4b81:      	movq	(%rip), %rdi            # 0x4b88 <generic_tracepoint_filter+0x1ae8>
    4b88:      	callq	*%rax
    4b8a:      	testq	%rax, %rax
    4b8d:      	je	0x4c91 <generic_tracepoint_filter+0x1bf1>
    4b93:      	movq	%rax, %rsi
    4b96:      	movl	0x24(%rax), %eax
    4b99:      	cmpq	%rax, %r15
    4b9c:      	je	0x481d <generic_tracepoint_filter+0x177d>
    4ba2:      	addq	$0x10, %rsi
    4ba6:      	movl	$0x1, %eax
    4bab:      	movq	(%rip), %rdi            # 0x4bb2 <generic_tracepoint_filter+0x1b12>
    4bb2:      	callq	*%rax
    4bb4:      	testq	%rax, %rax
    4bb7:      	je	0x4c91 <generic_tracepoint_filter+0x1bf1>
    4bbd:      	movq	%rax, %rsi
    4bc0:      	movl	0x24(%rax), %eax
    4bc3:      	cmpq	%rax, %r15
    4bc6:      	je	0x481d <generic_tracepoint_filter+0x177d>
    4bcc:      	addq	$0x10, %rsi
    4bd0:      	movl	$0x1, %eax
    4bd5:      	movq	(%rip), %rdi            # 0x4bdc <generic_tracepoint_filter+0x1b3c>
    4bdc:      	callq	*%rax
    4bde:      	testq	%rax, %rax
    4be1:      	je	0x4c91 <generic_tracepoint_filter+0x1bf1>
    4be7:      	movq	%rax, %rsi
    4bea:      	movl	0x24(%rax), %eax
    4bed:      	cmpq	%rax, %r15
    4bf0:      	je	0x4813 <generic_tracepoint_filter+0x1773>
    4bf6:      	addq	$0x10, %rsi
    4bfa:      	movl	$0x1, %eax
    4bff:      	movq	(%rip), %rdi            # 0x4c06 <generic_tracepoint_filter+0x1b66>
    4c06:      	callq	*%rax
    4c08:      	testq	%rax, %rax
    4c0b:      	movq	0x30(%rsp), %r12
    4c10:      	movq	0x28(%rsp), %r14
    4c15:      	je	0x4c91 <generic_tracepoint_filter+0x1bf1>
    4c17:      	movq	%rax, %rsi
    4c1a:      	movl	0x24(%rax), %eax
    4c1d:      	cmpq	%rax, %r15
    4c20:      	je	0x4813 <generic_tracepoint_filter+0x1773>
    4c26:      	addq	$0x10, %rsi
    4c2a:      	movl	$0x1, %eax
    4c2f:      	movq	(%rip), %rdi            # 0x4c36 <generic_tracepoint_filter+0x1b96>
    4c36:      	callq	*%rax
    4c38:      	testq	%rax, %rax
    4c3b:      	movq	0x30(%rsp), %r12
    4c40:      	movq	0x28(%rsp), %r14
    4c45:      	je	0x4c91 <generic_tracepoint_filter+0x1bf1>
    4c47:      	movq	%rax, %rsi
    4c4a:      	movl	0x24(%rax), %eax
    4c4d:      	cmpq	%rax, %r15
    4c50:      	movq	0x8(%rsp), %r10
    4c55:      	movl	0x4(%rsp), %edi
    4c59:      	movq	0x20(%rsp), %r8
    4c5e:      	movq	0x18(%rsp), %r9
    4c63:      	movq	0x10(%rsp), %r11
    4c68:      	je	0x4835 <generic_tracepoint_filter+0x1795>
    4c6e:      	addq	$0x10, %rsi
    4c72:      	movl	$0x1, %eax
    4c77:      	movq	(%rip), %rcx            # 0x4c7e <generic_tracepoint_filter+0x1bde>
    4c7e:      	movq	(%rip), %rdi            # 0x4c85 <generic_tracepoint_filter+0x1be5>
    4c85:      	callq	*%rax
    4c87:      	movq	0x30(%rsp), %r12
    4c8c:      	movq	0x28(%rsp), %r14
    4c91:      	xorl	%r13d, %r13d
    4c94:      	movl	0x4(%rsp), %edi
    4c98:      	cmpl	$0x5, %edi
    4c9b:      	movq	0x8(%rsp), %r10
    4ca0:      	movq	0x20(%rsp), %r8
    4ca5:      	movq	0x18(%rsp), %r9
    4caa:      	movq	0x10(%rsp), %r11
    4caf:      	jne	0x4835 <generic_tracepoint_filter+0x1795>
    4cb5:      	jmp	0x4842 <generic_tracepoint_filter+0x17a2>
    4cba:      	xorl	%r13d, %r13d
    4cbd:      	jmp	0x4842 <generic_tracepoint_filter+0x17a2>
    4cc2:      	movl	0x50(%rsp), %esi
    4cc6:      	movl	0x54(%rsp), %ecx
    4cca:      	movl	0x58(%rsp), %eax
    4cce:      	movl	0x5c(%rsp), %edx
    4cd2:      	cmpl	$0x6, %edi
    4cd5:      	jne	0x4cdf <generic_tracepoint_filter+0x1c3f>
    4cd7:      	andl	%esi, %ecx
    4cd9:      	andl	%edx, %eax
    4cdb:      	andl	%ecx, %eax
    4cdd:      	jmp	0x4ce5 <generic_tracepoint_filter+0x1c45>
    4cdf:      	orl	%esi, %ecx
    4ce1:      	orl	%edx, %eax
    4ce3:      	orl	%ecx, %eax
    4ce5:      	testl	%eax, %eax
    4ce7:      	movq	0xd8(%rsp), %rdx
    4cef:      	je	0x52fc <generic_tracepoint_filter+0x225c>
    4cf5:      	addl	$0x14, %edx
    4cf8:      	movl	0x8(%r10,%rbp), %ecx
    4cfd:      	andl	$0x7, %ecx
    4d00:      	leal	(%rdx,%rcx,4), %ebp
    4d03:      	movl	%ebp, %ecx
    4d05:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    4d0b:      	movl	(%rcx,%r10), %ecx
    4d0f:      	addl	$0x4, %ebp
    4d12:      	addl	$-0x4, %ecx
    4d15:      	xorl	%esi, %esi
    4d17:      	movl	$0x4, %r8d
    4d1d:      	jmp	0x4d2f <generic_tracepoint_filter+0x1c8f>
    4d1f:      	nop
    4d20:      	xorl	%ecx, %ecx
    4d22:      	incq	%rsi
    4d25:      	cmpq	$0xa, %rsi
    4d29:      	je	0x4eb8 <generic_tracepoint_filter+0x1e18>
    4d2f:      	testl	%ecx, %ecx
    4d31:      	je	0x4d20 <generic_tracepoint_filter+0x1c80>
    4d33:      	movl	%ebp, %r9d
    4d36:      	andl	$0x3ff, %r9d            # imm = 0x3FF
    4d3d:      	movl	(%r9,%r10), %r11d
    4d41:      	movq	%r10, %rax
    4d44:      	movl	0x4(%r9,%r10), %r10d
    4d49:      	movl	0x8(%r9,%rax), %edx
    4d4e:      	movq	$0x0, 0x58(%rsp)
    4d57:      	movq	$0x0, 0x50(%rsp)
    4d60:      	cmpl	$0x4, %edx
    4d63:      	movl	$0x4, %eax
    4d68:      	cmovbl	%edx, %eax
    4d6b:      	cmpl	$0x6, %r10d
    4d6f:      	jne	0x4d85 <generic_tracepoint_filter+0x1ce5>
    4d71:      	movabsq	$0x100000001, %rdi      # imm = 0x100000001
    4d7b:      	movq	%rdi, 0x50(%rsp)
    4d80:      	movq	%rdi, 0x58(%rsp)
    4d85:      	addl	$0xc, %ebp
    4d88:      	testl	%edx, %edx
    4d8a:      	je	0x4e60 <generic_tracepoint_filter+0x1dc0>
    4d90:      	andl	$0xf, %r11d
    4d94:      	decq	%rax
    4d97:      	cmpq	$0x3, %rax
    4d9b:      	movl	$0x3, %edx
    4da0:      	cmovaeq	%rdx, %rax
    4da4:      	leaq	0x4(,%rax,4), %rbx
    4dac:      	movl	%ebp, %r14d
    4daf:      	cmpl	$0x9, %r11d
    4db3:      	jbe	0x4dea <generic_tracepoint_filter+0x1d4a>
    4db5:      	xorl	%r11d, %r11d
    4db8:      	jmp	0x4dd6 <generic_tracepoint_filter+0x1d36>
    4dba:      	nopw	(%rax,%rax)
    4dc0:      	movl	$0x0, 0x50(%rsp,%r11)
    4dc9:      	addq	$0x4, %r11
    4dcd:      	cmpq	%r11, %rbx
    4dd0:      	je	0x4e60 <generic_tracepoint_filter+0x1dc0>
    4dd6:      	leaq	(%r14,%r11), %rax
    4dda:      	cmpl	$0x3e8, %eax            # imm = 0x3E8
    4ddf:      	ja	0x4dc0 <generic_tracepoint_filter+0x1d20>
    4de1:      	movl	%eax, %eax
    4de3:      	xorl	%edx, %edx
    4de5:      	divq	%r8
    4de8:      	jmp	0x4dc0 <generic_tracepoint_filter+0x1d20>
    4dea:      	xorl	%r15d, %r15d
    4ded:      	jmp	0x4e31 <generic_tracepoint_filter+0x1d91>
    4def:      	nop
    4df0:      	cmpl	$0x5, %r10d
    4df4:      	setne	%dl
    4df7:      	movl	%r10d, %r13d
    4dfa:      	xorl	$0x6, %r13d
    4dfe:      	movq	0x30(%rsp), %rax
    4e03:      	movl	0x20(%rax,%r11,4), %edi
    4e08:      	movl	%r12d, %eax
    4e0b:      	xorl	%edi, %eax
    4e0d:      	cmpl	%edi, %r12d
    4e10:      	sete	%dil
    4e14:      	orb	%dl, %dil
    4e17:      	orl	%r13d, %eax
    4e1a:      	setne	%al
    4e1d:      	andb	%dil, %al
    4e20:      	movzbl	%al, %eax
    4e23:      	movl	%eax, 0x50(%rsp,%r15)
    4e28:      	addq	$0x4, %r15
    4e2c:      	cmpq	%r15, %rbx
    4e2f:      	je	0x4e60 <generic_tracepoint_filter+0x1dc0>
    4e31:      	leaq	(%r14,%r15), %rdx
    4e35:      	xorl	%r12d, %r12d
    4e38:      	cmpl	$0x3e8, %edx            # imm = 0x3E8
    4e3e:      	ja	0x4df0 <generic_tracepoint_filter+0x1d50>
    4e40:      	movl	%edx, %eax
    4e42:      	xorl	%edx, %edx
    4e44:      	divq	%r8
    4e47:      	andl	$0x3ff, %eax            # imm = 0x3FF
    4e4c:      	movq	0x8(%rsp), %rdx
    4e51:      	movl	(%rdx,%rax,4), %r12d
    4e55:      	jmp	0x4df0 <generic_tracepoint_filter+0x1d50>
    4e57:      	nopw	(%rax,%rax)
    4e60:      	movl	0x50(%rsp), %ebx
    4e64:      	movl	0x54(%rsp), %edx
    4e68:      	movl	0x58(%rsp), %eax
    4e6c:      	movl	0x5c(%rsp), %r11d
    4e71:      	cmpl	$0x6, %r10d
    4e75:      	jne	0x4e80 <generic_tracepoint_filter+0x1de0>
    4e77:      	andl	%ebx, %edx
    4e79:      	andl	%r11d, %eax
    4e7c:      	andl	%edx, %eax
    4e7e:      	jmp	0x4e87 <generic_tracepoint_filter+0x1de7>
    4e80:      	orl	%ebx, %edx
    4e82:      	orl	%r11d, %eax
    4e85:      	orl	%edx, %eax
    4e87:      	movq	0x30(%rsp), %r12
    4e8c:      	movq	0x8(%rsp), %r10
    4e91:      	testl	%eax, %eax
    4e93:      	je	0x52fc <generic_tracepoint_filter+0x225c>
    4e99:      	movl	0x8(%r10,%r9), %edx
    4e9e:      	shll	$0x2, %edx
    4ea1:      	subl	%edx, %ecx
    4ea3:      	andl	$0x1c, %edx
    4ea6:      	addl	%edx, %ebp
    4ea8:      	addl	$-0xc, %ecx
    4eab:      	incq	%rsi
    4eae:      	cmpq	$0xa, %rsi
    4eb2:      	jne	0x4d2f <generic_tracepoint_filter+0x1c8f>
    4eb8:      	movl	%ebp, %ecx
    4eba:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    4ec0:      	leal	0x4(%rbp), %ebx
    4ec3:      	cmpl	$0x4, (%rcx,%r10)
    4ec8:      	je	0x4f23 <generic_tracepoint_filter+0x1e83>
    4eca:      	andl	$0x3ff, %ebx            # imm = 0x3FF
    4ed0:      	movl	(%rbx,%r10), %ecx
    4ed4:      	movl	0x4(%rbx,%r10), %edx
    4ed9:      	movl	0x8(%rbx,%r10), %edi
    4ede:      	movq	0xc(%rbx,%r10), %rax
    4ee3:      	testl	%edi, %edi
    4ee5:      	je	0x4ef7 <generic_tracepoint_filter+0x1e57>
    4ee7:      	xorl	%esi, %esi
    4ee9:      	cmpl	$0x2, %ecx
    4eec:      	ja	0x4f1a <generic_tracepoint_filter+0x1e7a>
    4eee:      	cmpl	%edi, 0x44(%r12)
    4ef3:      	jne	0x4f00 <generic_tracepoint_filter+0x1e60>
    4ef5:      	jmp	0x4f1a <generic_tracepoint_filter+0x1e7a>
    4ef7:      	cmpl	$0x2, %ecx
    4efa:      	jbe	0x4f00 <generic_tracepoint_filter+0x1e60>
    4efc:      	xorl	%esi, %esi
    4efe:      	jmp	0x4f1a <generic_tracepoint_filter+0x1e7a>
    4f00:      	andq	0x48(%r12,%rcx,8), %rax
    4f05:      	cmpl	$0x5, %edx
    4f08:      	jne	0x4f13 <generic_tracepoint_filter+0x1e73>
    4f0a:      	testq	%rax, %rax
    4f0d:      	setne	%sil
    4f11:      	jmp	0x4f1a <generic_tracepoint_filter+0x1e7a>
    4f13:      	testq	%rax, %rax
    4f16:      	sete	%sil
    4f1a:      	addl	$0x18, %ebp
    4f1d:      	movzbl	%sil, %eax
    4f21:      	movl	%ebp, %ebx
    4f23:      	testl	%eax, %eax
    4f25:      	je	0x52fc <generic_tracepoint_filter+0x225c>
    4f2b:      	movl	%ebx, %ecx
    4f2d:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    4f33:      	leal	0x4(%rbx), %eax
    4f36:      	cmpl	$0x4, (%rcx,%r10)
    4f3b:      	je	0x520f <generic_tracepoint_filter+0x216f>
    4f41:      	andl	$0x3ff, %eax            # imm = 0x3FF
    4f46:      	movl	(%rax,%r10), %r14d
    4f4a:      	movl	0x4(%rax,%r10), %ebp
    4f4f:      	movl	$0xe, %eax
    4f54:      	callq	*%rax
    4f56:      	shrq	$0x20, %rax
    4f5a:      	movl	%eax, 0x50(%rsp)
    4f5e:      	movq	(%rip), %rdi            # 0x4f65 <generic_tracepoint_filter+0x1ec5>
    4f65:      	leaq	0x50(%rsp), %rsi
    4f6a:      	movl	$0x1, %eax
    4f6f:      	callq	*%rax
    4f71:      	movq	0x8(%rsp), %r10
    4f76:      	testq	%rax, %rax
    4f79:      	je	0x52fc <generic_tracepoint_filter+0x225c>
    4f7f:      	cmpl	$0x5, %r14d
    4f83:      	je	0x4fb2 <generic_tracepoint_filter+0x1f12>
    4f85:      	cmpl	$0x6, %r14d
    4f89:      	jne	0x52fc <generic_tracepoint_filter+0x225c>
    4f8f:      	movq	%r12, %rcx
    4f92:      	addq	$0x5ee8, %rcx           # imm = 0x5EE8
    4f99:      	testb	$0x1, %bpl
    4f9d:      	jne	0x4fdc <generic_tracepoint_filter+0x1f3c>
    4f9f:      	movl	0x28(%rax), %edx
    4fa2:      	testl	%edx, %edx
    4fa4:      	je	0x4fd5 <generic_tracepoint_filter+0x1f35>
    4fa6:      	cmpl	0x20(%r12), %edx
    4fab:      	je	0x4fdc <generic_tracepoint_filter+0x1f3c>
    4fad:      	jmp	0x5203 <generic_tracepoint_filter+0x2163>
    4fb2:      	movq	%r12, %rcx
    4fb5:      	addq	$0x5ee8, %rcx           # imm = 0x5EE8
    4fbc:      	testb	$0x1, %bpl
    4fc0:      	je	0x4ffc <generic_tracepoint_filter+0x1f5c>
    4fc2:      	movl	0x28(%rax), %edx
    4fc5:      	testl	%edx, %edx
    4fc7:      	je	0x4ff5 <generic_tracepoint_filter+0x1f55>
    4fc9:      	cmpl	0x20(%r12), %edx
    4fce:      	je	0x4ffc <generic_tracepoint_filter+0x1f5c>
    4fd0:      	jmp	0x5203 <generic_tracepoint_filter+0x2163>
    4fd5:      	movq	$0x1, (%rcx)
    4fdc:      	testb	$0x2, %bpl
    4fe0:      	jne	0x501c <generic_tracepoint_filter+0x1f7c>
    4fe2:      	movl	0x2c(%rax), %edx
    4fe5:      	testl	%edx, %edx
    4fe7:      	je	0x5015 <generic_tracepoint_filter+0x1f75>
    4fe9:      	cmpl	0x24(%r12), %edx
    4fee:      	je	0x501c <generic_tracepoint_filter+0x1f7c>
    4ff0:      	jmp	0x5203 <generic_tracepoint_filter+0x2163>
    4ff5:      	movq	$0x1, (%rcx)
    4ffc:      	testb	$0x2, %bpl
    5000:      	je	0x503c <generic_tracepoint_filter+0x1f9c>
    5002:      	movl	0x2c(%rax), %edx
    5005:      	testl	%edx, %edx
    5007:      	je	0x5035 <generic_tracepoint_filter+0x1f95>
    5009:      	cmpl	0x24(%r12), %edx
    500e:      	je	0x503c <generic_tracepoint_filter+0x1f9c>
    5010:      	jmp	0x5203 <generic_tracepoint_filter+0x2163>
    5015:      	movq	$0x1, (%rcx)
    501c:      	testb	$0x4, %bpl
    5020:      	jne	0x505c <generic_tracepoint_filter+0x1fbc>
    5022:      	movl	0x30(%rax), %edx
    5025:      	testl	%edx, %edx
    5027:      	je	0x5055 <generic_tracepoint_filter+0x1fb5>
    5029:      	cmpl	0x28(%r12), %edx
    502e:      	je	0x505c <generic_tracepoint_filter+0x1fbc>
    5030:      	jmp	0x5203 <generic_tracepoint_filter+0x2163>
    5035:      	movq	$0x1, (%rcx)
    503c:      	testb	$0x4, %bpl
    5040:      	je	0x507c <generic_tracepoint_filter+0x1fdc>
    5042:      	movl	0x30(%rax), %edx
    5045:      	testl	%edx, %edx
    5047:      	je	0x5075 <generic_tracepoint_filter+0x1fd5>
    5049:      	cmpl	0x28(%r12), %edx
    504e:      	je	0x507c <generic_tracepoint_filter+0x1fdc>
    5050:      	jmp	0x5203 <generic_tracepoint_filter+0x2163>
    5055:      	movq	$0x1, (%rcx)
    505c:      	testb	$0x8, %bpl
    5060:      	jne	0x509c <generic_tracepoint_filter+0x1ffc>
    5062:      	movl	0x34(%rax), %edx
    5065:      	testl	%edx, %edx
    5067:      	je	0x5095 <generic_tracepoint_filter+0x1ff5>
    5069:      	cmpl	0x2c(%r12), %edx
    506e:      	je	0x509c <generic_tracepoint_filter+0x1ffc>
    5070:      	jmp	0x5203 <generic_tracepoint_filter+0x2163>
    5075:      	movq	$0x1, (%rcx)
    507c:      	testb	$0x8, %bpl
    5080:      	je	0x50bc <generic_tracepoint_filter+0x201c>
    5082:      	movl	0x34(%rax), %edx
    5085:      	testl	%edx, %edx
    5087:      	je	0x50b5 <generic_tracepoint_filter+0x2015>
    5089:      	cmpl	0x2c(%r12), %edx
    508e:      	je	0x50bc <generic_tracepoint_filter+0x201c>
    5090:      	jmp	0x5203 <generic_tracepoint_filter+0x2163>
    5095:      	movq	$0x1, (%rcx)
    509c:      	testb	$0x10, %bpl
    50a0:      	jne	0x50dc <generic_tracepoint_filter+0x203c>
    50a2:      	movl	0x38(%rax), %edx
    50a5:      	testl	%edx, %edx
    50a7:      	je	0x50d5 <generic_tracepoint_filter+0x2035>
    50a9:      	cmpl	0x30(%r12), %edx
    50ae:      	je	0x50dc <generic_tracepoint_filter+0x203c>
    50b0:      	jmp	0x5203 <generic_tracepoint_filter+0x2163>
    50b5:      	movq	$0x1, (%rcx)
    50bc:      	testb	$0x10, %bpl
    50c0:      	je	0x50fc <generic_tracepoint_filter+0x205c>
    50c2:      	movl	0x38(%rax), %edx
    50c5:      	testl	%edx, %edx
    50c7:      	je	0x50f5 <generic_tracepoint_filter+0x2055>
    50c9:      	cmpl	0x30(%r12), %edx
    50ce:      	je	0x50fc <generic_tracepoint_filter+0x205c>
    50d0:      	jmp	0x5203 <generic_tracepoint_filter+0x2163>
    50d5:      	movq	$0x1, (%rcx)
    50dc:      	testb	$0x20, %bpl
    50e0:      	jne	0x511c <generic_tracepoint_filter+0x207c>
    50e2:      	movl	0x3c(%rax), %edx
    50e5:      	testl	%edx, %edx
    50e7:      	je	0x5115 <generic_tracepoint_filter+0x2075>
    50e9:      	cmpl	0x34(%r12), %edx
    50ee:      	je	0x511c <generic_tracepoint_filter+0x207c>
    50f0:      	jmp	0x5203 <generic_tracepoint_filter+0x2163>
    50f5:      	movq	$0x1, (%rcx)
    50fc:      	testb	$0x20, %bpl
    5100:      	je	0x513c <generic_tracepoint_filter+0x209c>
    5102:      	movl	0x3c(%rax), %edx
    5105:      	testl	%edx, %edx
    5107:      	je	0x5135 <generic_tracepoint_filter+0x2095>
    5109:      	cmpl	0x34(%r12), %edx
    510e:      	je	0x513c <generic_tracepoint_filter+0x209c>
    5110:      	jmp	0x5203 <generic_tracepoint_filter+0x2163>
    5115:      	movq	$0x1, (%rcx)
    511c:      	testb	$0x40, %bpl
    5120:      	jne	0x515c <generic_tracepoint_filter+0x20bc>
    5122:      	movl	0x40(%rax), %edx
    5125:      	testl	%edx, %edx
    5127:      	je	0x5155 <generic_tracepoint_filter+0x20b5>
    5129:      	cmpl	0x38(%r12), %edx
    512e:      	je	0x515c <generic_tracepoint_filter+0x20bc>
    5130:      	jmp	0x5203 <generic_tracepoint_filter+0x2163>
    5135:      	movq	$0x1, (%rcx)
    513c:      	testb	$0x40, %bpl
    5140:      	je	0x517b <generic_tracepoint_filter+0x20db>
    5142:      	movl	0x40(%rax), %edx
    5145:      	testl	%edx, %edx
    5147:      	je	0x5174 <generic_tracepoint_filter+0x20d4>
    5149:      	cmpl	0x38(%r12), %edx
    514e:      	je	0x517b <generic_tracepoint_filter+0x20db>
    5150:      	jmp	0x5203 <generic_tracepoint_filter+0x2163>
    5155:      	movq	$0x1, (%rcx)
    515c:      	testb	%bpl, %bpl
    515f:      	js	0x5197 <generic_tracepoint_filter+0x20f7>
    5161:      	movl	0x44(%rax), %edx
    5164:      	testl	%edx, %edx
    5166:      	je	0x5190 <generic_tracepoint_filter+0x20f0>
    5168:      	cmpl	0x3c(%r12), %edx
    516d:      	je	0x5197 <generic_tracepoint_filter+0x20f7>
    516f:      	jmp	0x5203 <generic_tracepoint_filter+0x2163>
    5174:      	movq	$0x1, (%rcx)
    517b:      	testb	%bpl, %bpl
    517e:      	jns	0x51b6 <generic_tracepoint_filter+0x2116>
    5180:      	movl	0x44(%rax), %edx
    5183:      	testl	%edx, %edx
    5185:      	je	0x51af <generic_tracepoint_filter+0x210f>
    5187:      	cmpl	0x3c(%r12), %edx
    518c:      	je	0x51b6 <generic_tracepoint_filter+0x2116>
    518e:      	jmp	0x5203 <generic_tracepoint_filter+0x2163>
    5190:      	movq	$0x1, (%rcx)
    5197:      	testl	$0x100, %ebp            # imm = 0x100
    519d:      	jne	0x51e1 <generic_tracepoint_filter+0x2141>
    519f:      	movl	0x48(%rax), %edx
    51a2:      	testl	%edx, %edx
    51a4:      	je	0x51da <generic_tracepoint_filter+0x213a>
    51a6:      	cmpl	0x40(%r12), %edx
    51ab:      	je	0x51e1 <generic_tracepoint_filter+0x2141>
    51ad:      	jmp	0x5203 <generic_tracepoint_filter+0x2163>
    51af:      	movq	$0x1, (%rcx)
    51b6:      	testl	$0x100, %ebp            # imm = 0x100
    51bc:      	je	0x52e2 <generic_tracepoint_filter+0x2242>
    51c2:      	movl	0x48(%rax), %edx
    51c5:      	testl	%edx, %edx
    51c7:      	je	0x52db <generic_tracepoint_filter+0x223b>
    51cd:      	cmpl	0x40(%r12), %edx
    51d2:      	je	0x52e2 <generic_tracepoint_filter+0x2242>
    51d8:      	jmp	0x5203 <generic_tracepoint_filter+0x2163>
    51da:      	movq	$0x1, (%rcx)
    51e1:      	testl	$0x200, %ebp            # imm = 0x200
    51e7:      	jne	0x52fc <generic_tracepoint_filter+0x225c>
    51ed:      	movl	0x4c(%rax), %eax
    51f0:      	testl	%eax, %eax
    51f2:      	je	0x52f5 <generic_tracepoint_filter+0x2255>
    51f8:      	cmpl	0x44(%r12), %eax
    51fd:      	je	0x52fc <generic_tracepoint_filter+0x225c>
    5203:      	addl	$0xc, %ebx
    5206:      	movq	$0x1, (%rcx)
    520d:      	movl	%ebx, %eax
    520f:      	movl	%eax, %ecx
    5211:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5217:      	cmpl	$0x4, (%rcx,%r10)
    521c:      	jne	0x5249 <generic_tracepoint_filter+0x21a9>
    521e:      	movq	0x5eb8(%r12), %rax
    5226:      	andl	$0x1f, %eax
    5229:      	movb	$0x1, 0x5ec1(%r12,%rax)
    5232:      	movb	$0x1, 0x5ee0(%r12)
    523b:      	movb	$0x1, 0x5ec0(%r12)
    5244:      	jmp	0x52fc <generic_tracepoint_filter+0x225c>
    5249:      	addl	$0x4, %eax
    524c:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5251:      	movl	(%rax,%r10), %r14d
    5255:      	movl	0x4(%rax,%r10), %ebx
    525a:      	movl	0x8(%rax,%r10), %ebp
    525f:      	movq	0xc(%rax,%r10), %r15
    5264:      	movl	$0xe, %eax
    5269:      	callq	*%rax
    526b:      	shrq	$0x20, %rax
    526f:      	movl	%eax, 0x50(%rsp)
    5273:      	movq	(%rip), %rdi            # 0x527a <generic_tracepoint_filter+0x21da>
    527a:      	leaq	0x50(%rsp), %rsi
    527f:      	movl	$0x1, %eax
    5284:      	callq	*%rax
    5286:      	testq	%rax, %rax
    5289:      	je	0x52fc <generic_tracepoint_filter+0x225c>
    528b:      	testl	%ebp, %ebp
    528d:      	je	0x529e <generic_tracepoint_filter+0x21fe>
    528f:      	cmpl	$0x2, %r14d
    5293:      	ja	0x52fc <generic_tracepoint_filter+0x225c>
    5295:      	cmpl	%ebp, 0x44(%r12)
    529a:      	jne	0x52a4 <generic_tracepoint_filter+0x2204>
    529c:      	jmp	0x52fc <generic_tracepoint_filter+0x225c>
    529e:      	cmpl	$0x2, %r14d
    52a2:      	ja	0x52fc <generic_tracepoint_filter+0x225c>
    52a4:      	movq	0x50(%rax,%r14,8), %rax
    52a9:      	movq	0x48(%r12,%r14,8), %rcx
    52ae:      	movq	%rcx, %rdx
    52b1:      	xorq	%rax, %rdx
    52b4:      	testq	%r15, %rdx
    52b7:      	je	0x52c0 <generic_tracepoint_filter+0x2220>
    52b9:      	cmpl	$0x5, %ebx
    52bc:      	jne	0x52fc <generic_tracepoint_filter+0x225c>
    52be:      	jmp	0x52ca <generic_tracepoint_filter+0x222a>
    52c0:      	cmpq	%rcx, %rax
    52c3:      	je	0x52fc <generic_tracepoint_filter+0x225c>
    52c5:      	cmpl	$0x6, %ebx
    52c8:      	jne	0x52fc <generic_tracepoint_filter+0x225c>
    52ca:      	movq	$0x1, 0x5ef0(%r12)
    52d6:      	jmp	0x521e <generic_tracepoint_filter+0x217e>
    52db:      	movq	$0x1, (%rcx)
    52e2:      	testl	$0x200, %ebp            # imm = 0x200
    52e8:      	je	0x52fc <generic_tracepoint_filter+0x225c>
    52ea:      	movl	0x4c(%rax), %eax
    52ed:      	testl	%eax, %eax
    52ef:      	jne	0x51f8 <generic_tracepoint_filter+0x2158>
    52f5:      	movq	$0x1, (%rcx)
    52fc:      	movq	0x5eb8(%r12), %rax
    5304:      	incq	%rax
    5307:      	movq	%rax, 0x5eb8(%r12)
    530f:      	cmpq	0xb8(%rsp), %rax
    5317:      	jbe	0x5370 <generic_tracepoint_filter+0x22d0>
    5319:      	movq	0x28(%rsp), %rcx
    531e:      	movl	(%rcx), %eax
    5320:      	movl	%eax, 0x10(%r12)
    5325:      	movq	0x8(%rcx), %rax
    5329:      	movq	%rax, 0x18(%r12)
    532e:      	cmpb	$0x0, 0x5ec0(%r12)
    5337:      	movq	0xb0(%rsp), %rbp
    533f:      	je	0x535c <generic_tracepoint_filter+0x22bc>
    5341:      	movq	(%rip), %rsi            # 0x5348 <generic_tracepoint_filter+0x22a8>
    5348:      	movl	$0x1, %ecx
    534d:      	movl	$0xc, %eax
    5352:      	movq	%rbp, %rdi
    5355:      	movl	$0x1, %edx
    535a:      	callq	*%rax
    535c:      	xorl	%eax, %eax
    535e:      	addq	$0xf8, %rsp
    5365:      	popq	%rbx
    5366:      	popq	%r12
    5368:      	popq	%r13
    536a:      	popq	%r14
    536c:      	popq	%r15
    536e:      	popq	%rbp
    536f:      	retq
    5370:      	movq	(%rip), %rsi            # 0x5377 <generic_tracepoint_filter+0x22d7>
    5377:      	movl	$0x2, %ecx
    537c:      	movl	$0xc, %eax
    5381:      	movq	0xb0(%rsp), %rdi
    5389:      	movl	$0x2, %edx
    538e:      	jmp	0x535a <generic_tracepoint_filter+0x22ba>

0000000000005390 <generic_tracepoint_arg>:
    5390:      	pushq	%rbp
    5391:      	pushq	%r15
    5393:      	pushq	%r14
    5395:      	pushq	%r13
    5397:      	pushq	%r12
    5399:      	pushq	%rbx
    539a:      	subq	$0xc8, %rsp
    53a1:      	movq	%rdi, %r13
    53a4:      	movl	$0x0, 0xb4(%rsp)
    53af:      	movq	(%rip), %rdi            # 0x53b6 <generic_tracepoint_arg+0x26>
    53b6:      	leaq	0xb4(%rsp), %rsi
    53be:      	movl	$0x1, %eax
    53c3:      	callq	*%rax
    53c5:      	testq	%rax, %rax
    53c8:      	je	0x5563 <generic_tracepoint_arg+0x1d3>
    53ce:      	movq	%rax, %r14
    53d1:      	movl	0x5f00(%rax), %ebx
    53d7:      	leaq	0x5ef8(%rax), %rsi
    53de:      	movq	(%rip), %rdi            # 0x53e5 <generic_tracepoint_arg+0x55>
    53e5:      	movl	$0x1, %eax
    53ea:      	callq	*%rax
    53ec:      	testq	%rax, %rax
    53ef:      	je	0x5548 <generic_tracepoint_arg+0x1b8>
    53f5:      	cmpb	$0x0, 0x5ee0(%r14)
    53fd:      	je	0x5548 <generic_tracepoint_arg+0x1b8>
    5403:      	movq	%rax, %r15
    5406:      	movl	%ebx, %eax
    5408:      	andl	$0x7, %eax
    540b:      	cmpb	$0x0, 0x5ec1(%r14,%rax)
    5414:      	je	0x549d <generic_tracepoint_arg+0x10d>
    541a:      	movl	%eax, %eax
    541c:      	movl	0x4(%r15,%rax,4), %ecx
    5421:      	leaq	(%rcx,%rax,4), %rdx
    5425:      	addq	$0x4, %rdx
    5429:      	leaq	(%rcx,%rax,4), %rax
    542d:      	addq	$0x8, %rax
    5431:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5436:      	movl	(%rax,%r15), %eax
    543a:      	addq	%rdx, %rax
    543d:      	addq	$0x4, %rax
    5441:      	movl	%eax, %ecx
    5443:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5449:      	movl	(%rcx,%r15), %ecx
    544d:      	addq	%rax, %rcx
    5450:      	movl	%ecx, %eax
    5452:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5457:      	movl	(%rax,%r15), %eax
    545b:      	addq	%rcx, %rax
    545e:      	movl	%eax, %ecx
    5460:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5466:      	movl	(%rcx,%r15), %ecx
    546a:      	addq	%rax, %rcx
    546d:      	movl	%ecx, %eax
    546f:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5474:      	movl	(%rax,%r15), %r9d
    5478:      	addq	%rcx, %r9
    547b:      	movl	%r9d, %edi
    547e:      	andl	$0x3ff, %edi            # imm = 0x3FF
    5484:      	cmpl	$0x19, (%r15,%rdi)
    5489:      	jae	0x54e9 <generic_tracepoint_arg+0x159>
    548b:      	cmpq	$0x1, %rdi
    548f:      	je	0x5548 <generic_tracepoint_arg+0x1b8>
    5495:      	testl	%edi, %edi
    5497:      	jne	0x5526 <generic_tracepoint_arg+0x196>
    549d:      	cmpl	$0x1, %ebx
    54a0:      	jg	0x54be <generic_tracepoint_arg+0x12e>
    54a2:      	cmpl	$-0x1, %ebx
    54a5:      	je	0x5577 <generic_tracepoint_arg+0x1e7>
    54ab:      	testl	%ebx, %ebx
    54ad:      	je	0x5583 <generic_tracepoint_arg+0x1f3>
    54b3:      	cmpl	$0x1, %ebx
    54b6:      	je	0x5592 <generic_tracepoint_arg+0x202>
    54bc:      	jmp	0x54d9 <generic_tracepoint_arg+0x149>
    54be:      	cmpl	$0x2, %ebx
    54c1:      	je	0x55a1 <generic_tracepoint_arg+0x211>
    54c7:      	cmpl	$0x3, %ebx
    54ca:      	je	0x55b0 <generic_tracepoint_arg+0x220>
    54d0:      	cmpl	$0x4, %ebx
    54d3:      	je	0x55bf <generic_tracepoint_arg+0x22f>
    54d9:      	cmpl	$0x4, %ebx
    54dc:      	jg	0x55f0 <generic_tracepoint_arg+0x260>
    54e2:      	incl	%ebx
    54e4:      	jmp	0x55ce <generic_tracepoint_arg+0x23e>
    54e9:      	leaq	(%r15,%rdi), %rax
    54ed:      	movq	%rax, 0xc0(%rsp)
    54f5:      	xorl	%r11d, %r11d
    54f8:      	leaq	0x80(%rsp), %rax
    5500:      	movq	%rax, 0x38(%rsp)
    5505:      	movq	%rbx, 0xb8(%rsp)
    550d:      	movq	%rdi, 0x10(%rsp)
    5512:      	movq	%r9, 0x18(%rsp)
    5517:      	movq	%r15, 0x68(%rsp)
    551c:      	movq	%r13, 0x78(%rsp)
    5521:      	jmp	0x5665 <generic_tracepoint_arg+0x2d5>
    5526:      	movl	%edi, 0x5f04(%r14)
    552d:      	movq	(%rip), %rsi            # 0x5534 <generic_tracepoint_arg+0x1a4>
    5534:      	movl	$0x4, %ecx
    5539:      	movl	$0xc, %eax
    553e:      	movq	%r13, %rdi
    5541:      	movl	$0x4, %edx
    5546:      	callq	*%rax
    5548:      	movq	(%rip), %rsi            # 0x554f <generic_tracepoint_arg+0x1bf>
    554f:      	movl	$0x5, %ecx
    5554:      	movl	$0xc, %eax
    5559:      	movq	%r13, %rdi
    555c:      	movl	$0x5, %edx
    5561:      	callq	*%rax
    5563:      	xorl	%eax, %eax
    5565:      	addq	$0xc8, %rsp
    556c:      	popq	%rbx
    556d:      	popq	%r12
    556f:      	popq	%r13
    5571:      	popq	%r14
    5573:      	popq	%r15
    5575:      	popq	%rbp
    5576:      	retq
    5577:      	xorl	%ebx, %ebx
    5579:      	cmpb	$0x0, 0x5ec1(%r14)
    5581:      	jne	0x55ce <generic_tracepoint_arg+0x23e>
    5583:      	movl	$0x1, %ebx
    5588:      	cmpb	$0x0, 0x5ec2(%r14)
    5590:      	jne	0x55ce <generic_tracepoint_arg+0x23e>
    5592:      	movl	$0x2, %ebx
    5597:      	cmpb	$0x0, 0x5ec3(%r14)
    559f:      	jne	0x55ce <generic_tracepoint_arg+0x23e>
    55a1:      	movl	$0x3, %ebx
    55a6:      	cmpb	$0x0, 0x5ec4(%r14)
    55ae:      	jne	0x55ce <generic_tracepoint_arg+0x23e>
    55b0:      	movl	$0x4, %ebx
    55b5:      	cmpb	$0x0, 0x5ec5(%r14)
    55bd:      	jne	0x55ce <generic_tracepoint_arg+0x23e>
    55bf:      	movl	$0x5, %ebx
    55c4:      	cmpb	$0x0, 0x5ec6(%r14)
    55cc:      	je	0x55f0 <generic_tracepoint_arg+0x260>
    55ce:      	movl	%ebx, 0x5f00(%r14)
    55d5:      	movq	(%rip), %rsi            # 0x55dc <generic_tracepoint_arg+0x24c>
    55dc:      	movl	$0x3, %ecx
    55e1:      	movl	$0xc, %eax
    55e6:      	movq	%r13, %rdi
    55e9:      	movl	$0x3, %edx
    55ee:      	callq	*%rax
    55f0:      	movq	0x60(%r14), %rbx
    55f4:      	movl	$0xe, %eax
    55f9:      	callq	*%rax
    55fb:      	movq	%rbx, 0x40(%rsp)
    5600:      	movq	%rax, 0x48(%rsp)
    5605:      	movq	(%rip), %rdi            # 0x560c <generic_tracepoint_arg+0x27c>
    560c:      	leaq	0x40(%rsp), %rsi
    5611:      	movl	$0x1, %eax
    5616:      	callq	*%rax
    5618:      	testq	%rax, %rax
    561b:      	je	0x5563 <generic_tracepoint_arg+0x1d3>
    5621:      	movq	(%rip), %rdi            # 0x5628 <generic_tracepoint_arg+0x298>
    5628:      	leaq	0x40(%rsp), %rsi
    562d:      	movl	$0x3, %eax
    5632:      	callq	*%rax
    5634:      	jmp	0x5563 <generic_tracepoint_arg+0x1d3>
    5639:      	testq	%rax, %rax
    563c:      	setne	%cl
    563f:      	movzbl	%cl, %ebx
    5642:      	movq	0x78(%rsp), %r13
    5647:      	testq	%rbx, %rbx
    564a:      	movq	0xb8(%rsp), %rbx
    5652:      	je	0x549d <generic_tracepoint_arg+0x10d>
    5658:      	incq	%r11
    565b:      	cmpq	$0x5, %r11
    565f:      	je	0x548b <generic_tracepoint_arg+0xfb>
    5665:      	movq	0xc0(%rsp), %rax
    566d:      	movl	0x4(%rax,%r11,4), %r12d
    5672:      	testl	$0x3ff, %r12d           # imm = 0x3FF
    5679:      	je	0x548b <generic_tracepoint_arg+0xfb>
    567f:      	addl	%r9d, %r12d
    5682:      	andl	$0x3ff, %r12d           # imm = 0x3FF
    5689:      	movl	0x4(%r15,%r12), %eax
    568e:      	cmpl	$0x23, %eax
    5691:      	je	0x549d <generic_tracepoint_arg+0x10d>
    5697:      	addq	%r15, %r12
    569a:      	movl	(%r12), %ecx
    569e:      	cmpq	$0x4, %rcx
    56a2:      	ja	0x549d <generic_tracepoint_arg+0x10d>
    56a8:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
    56b1:      	jne	0x549d <generic_tracepoint_arg+0x10d>
    56b7:      	movq	0x5e78(%r14,%rcx,8), %rcx
    56bf:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    56c5:      	leaq	(%r14,%rcx), %rsi
    56c9:      	addq	$0x90, %rsi
    56d0:      	movl	0xc(%r12), %ecx
    56d5:      	cmpl	$0x10, %ecx
    56d8:      	jle	0x5734 <generic_tracepoint_arg+0x3a4>
    56da:      	leal	-0x1c(%rcx), %edx
    56dd:      	cmpl	$0x9, %edx
    56e0:      	jb	0x585e <generic_tracepoint_arg+0x4ce>
    56e6:      	movq	%rsi, %r8
    56e9:      	cmpl	$0x2a, %ecx
    56ec:      	ja	0x5b83 <generic_tracepoint_arg+0x7f3>
    56f2:      	movl	%ecx, %edx
    56f4:      	movabsq	$0xc000000000, %rsi     # imm = 0xC000000000
    56fe:      	btq	%rdx, %rsi
    5702:      	jb	0x575c <generic_tracepoint_arg+0x3cc>
    5704:      	movabsq	$0x30000000000, %rsi    # imm = 0x30000000000
    570e:      	btq	%rdx, %rsi
    5712:      	jb	0x57bb <generic_tracepoint_arg+0x42b>
    5718:      	movabsq	$0x42000000000, %rsi    # imm = 0x42000000000
    5722:      	btq	%rdx, %rsi
    5726:      	jae	0x5b83 <generic_tracepoint_arg+0x7f3>
    572c:      	movq	%r8, %rsi
    572f:      	jmp	0x5b93 <generic_tracepoint_arg+0x803>
    5734:      	cmpl	$0x6, %ecx
    5737:      	jg	0x5797 <generic_tracepoint_arg+0x407>
    5739:      	cmpl	$0x3, %ecx
    573c:      	jle	0x5813 <generic_tracepoint_arg+0x483>
    5742:      	cmpl	$0x4, %ecx
    5745:      	je	0x585e <generic_tracepoint_arg+0x4ce>
    574b:      	movq	%rsi, %r8
    574e:      	cmpl	$0x5, %ecx
    5751:      	je	0x57bb <generic_tracepoint_arg+0x42b>
    5753:      	cmpl	$0x6, %ecx
    5756:      	jne	0x5658 <generic_tracepoint_arg+0x2c8>
    575c:      	movq	%r8, %rsi
    575f:      	movl	(%r8), %ebp
    5762:      	addq	$0x4, %rsi
    5766:      	cmpl	$0x19, %eax
    5769:      	jg	0x5a17 <generic_tracepoint_arg+0x687>
    576f:      	leal	-0x3(%rax), %ecx
    5772:      	cmpl	$0x2, %ecx
    5775:      	jb	0x6370 <generic_tracepoint_arg+0xfe0>
    577b:      	cmpl	$0x8, %eax
    577e:      	je	0x62c7 <generic_tracepoint_arg+0xf37>
    5784:      	movl	$0x0, %ebx
    5789:      	cmpl	$0x9, %eax
    578c:      	je	0x5a37 <generic_tracepoint_arg+0x6a7>
    5792:      	jmp	0x8357 <generic_tracepoint_arg+0x2fc7>
    5797:      	leal	-0xa(%rcx), %edx
    579a:      	cmpl	$0x4, %edx
    579d:      	jb	0x585e <generic_tracepoint_arg+0x4ce>
    57a3:      	leal	-0xf(%rcx), %edx
    57a6:      	cmpl	$0x2, %edx
    57a9:      	jb	0x5b93 <generic_tracepoint_arg+0x803>
    57af:      	movq	%rsi, %r8
    57b2:      	cmpl	$0x7, %ecx
    57b5:      	jne	0x5658 <generic_tracepoint_arg+0x2c8>
    57bb:      	movq	$0x0, 0x60(%rsp)
    57c4:      	movq	$0x0, 0x58(%rsp)
    57cd:      	movq	$0x0, 0x50(%rsp)
    57d6:      	movq	$0x0, 0x48(%rsp)
    57df:      	movq	$0x0, 0x40(%rsp)
    57e8:      	cmpl	$0x27, %ecx
    57eb:      	jg	0x598c <generic_tracepoint_arg+0x5fc>
    57f1:      	cmpl	$0x5, %ecx
    57f4:      	movq	%r8, %rsi
    57f7:      	je	0x6114 <generic_tracepoint_arg+0xd84>
    57fd:      	movq	%rsi, %rdx
    5800:      	movl	$0x0, %ebx
    5805:      	cmpl	$0x7, %ecx
    5808:      	je	0x6116 <generic_tracepoint_arg+0xd86>
    580e:      	jmp	0x5642 <generic_tracepoint_arg+0x2b2>
    5813:      	cmpl	$0x1, %ecx
    5816:      	je	0x585e <generic_tracepoint_arg+0x4ce>
    5818:      	cmpl	$0x2, %ecx
    581b:      	jne	0x5658 <generic_tracepoint_arg+0x2c8>
    5821:      	movl	0x4(%rsi), %ebp
    5824:      	addq	$0x8, %rsi
    5828:      	cmpl	$0x19, %eax
    582b:      	jg	0x63f4 <generic_tracepoint_arg+0x1064>
    5831:      	leal	-0x3(%rax), %ecx
    5834:      	cmpl	$0x2, %ecx
    5837:      	jb	0x6c7c <generic_tracepoint_arg+0x18ec>
    583d:      	movq	%rsi, 0x8(%rsp)
    5842:      	cmpl	$0x8, %eax
    5845:      	je	0x6bdc <generic_tracepoint_arg+0x184c>
    584b:      	movl	$0x0, %ebx
    5850:      	cmpl	$0x9, %eax
    5853:      	je	0x6419 <generic_tracepoint_arg+0x1089>
    5859:      	jmp	0x8625 <generic_tracepoint_arg+0x3295>
    585e:      	movq	%rsi, 0x8(%rsp)
    5863:      	cmpl	$0xb, %ecx
    5866:      	jle	0x58f7 <generic_tracepoint_arg+0x567>
    586c:      	cmpl	$0x24, %ecx
    586f:      	ja	0x593e <generic_tracepoint_arg+0x5ae>
    5875:      	movl	%ecx, %edx
    5877:      	movabsq	$0x1e00000000, %rsi     # imm = 0x1E00000000
    5881:      	btq	%rdx, %rsi
    5885:      	jb	0x5912 <generic_tracepoint_arg+0x582>
    588b:      	movl	$0x60000000, %esi       # imm = 0x60000000
    5890:      	btq	%rdx, %rsi
    5894:      	jb	0x5ce9 <generic_tracepoint_arg+0x959>
    589a:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
    58a4:      	btq	%rdx, %rsi
    58a8:      	jae	0x593e <generic_tracepoint_arg+0x5ae>
    58ae:      	cmpl	$0x20, %eax
    58b1:      	ja	0x549d <generic_tracepoint_arg+0x10d>
    58b7:      	movl	%eax, %ecx
    58b9:      	movl	$0x101e, %edx           # imm = 0x101E
    58be:      	btq	%rcx, %rdx
    58c2:      	jae	0x656f <generic_tracepoint_arg+0x11df>
    58c8:      	movl	0x10(%r12), %ecx
    58cd:      	cmpl	$0x2, %eax
    58d0:      	jle	0x6a7c <generic_tracepoint_arg+0x16ec>
    58d6:      	leal	-0x3(%rax), %edx
    58d9:      	cmpl	$0x2, %edx
    58dc:      	movq	0x8(%rsp), %rdx
    58e1:      	jae	0x70af <generic_tracepoint_arg+0x1d1f>
    58e7:      	movzbl	(%rdx), %edx
    58ea:      	cmpl	%edx, %ecx
    58ec:      	jne	0x73cd <generic_tracepoint_arg+0x203d>
    58f2:      	jmp	0x85b1 <generic_tracepoint_arg+0x3221>
    58f7:      	leal	-0xa(%rcx), %edx
    58fa:      	cmpl	$0x2, %edx
    58fd:      	jb	0x5d83 <generic_tracepoint_arg+0x9f3>
    5903:      	cmpl	$0x1, %ecx
    5906:      	je	0x594a <generic_tracepoint_arg+0x5ba>
    5908:      	cmpl	$0x4, %ecx
    590b:      	je	0x594a <generic_tracepoint_arg+0x5ba>
    590d:      	jmp	0x5658 <generic_tracepoint_arg+0x2c8>
    5912:      	cmpl	$0x9, %eax
    5915:      	jle	0x5d32 <generic_tracepoint_arg+0x9a2>
    591b:      	cmpl	$0x1d, %eax
    591e:      	jg	0x6199 <generic_tracepoint_arg+0xe09>
    5924:      	leal	-0xa(%rax), %edx
    5927:      	cmpl	$0x2, %edx
    592a:      	jb	0x5e19 <generic_tracepoint_arg+0xa89>
    5930:      	cmpl	$0xc, %eax
    5933:      	je	0x5d99 <generic_tracepoint_arg+0xa09>
    5939:      	jmp	0x549d <generic_tracepoint_arg+0x10d>
    593e:      	leal	-0xc(%rcx), %edx
    5941:      	cmpl	$0x2, %edx
    5944:      	jae	0x5d7a <generic_tracepoint_arg+0x9ea>
    594a:      	cmpl	$0x20, %eax
    594d:      	ja	0x549d <generic_tracepoint_arg+0x10d>
    5953:      	movl	%eax, %edx
    5955:      	movl	$0x101e, %esi           # imm = 0x101E
    595a:      	btq	%rdx, %rsi
    595e:      	jae	0x59ae <generic_tracepoint_arg+0x61e>
    5960:      	movl	0x10(%r12), %edx
    5965:      	cmpl	$0x2, %eax
    5968:      	jle	0x5d3f <generic_tracepoint_arg+0x9af>
    596e:      	leal	-0x3(%rax), %esi
    5971:      	cmpl	$0x2, %esi
    5974:      	jae	0x6554 <generic_tracepoint_arg+0x11c4>
    597a:      	movq	0x8(%rsp), %rsi
    597f:      	cmpl	%edx, (%rsi)
    5981:      	jne	0x7651 <generic_tracepoint_arg+0x22c1>
    5987:      	jmp	0x85b1 <generic_tracepoint_arg+0x3221>
    598c:      	cmpl	$0x28, %ecx
    598f:      	movq	%r8, %rsi
    5992:      	je	0x60ec <generic_tracepoint_arg+0xd5c>
    5998:      	movq	%rsi, %rdx
    599b:      	movl	$0x0, %ebx
    59a0:      	cmpl	$0x29, %ecx
    59a3:      	je	0x6116 <generic_tracepoint_arg+0xd86>
    59a9:      	jmp	0x5642 <generic_tracepoint_arg+0x2b2>
    59ae:      	movl	$0xc00, %esi            # imm = 0xC00
    59b3:      	btq	%rdx, %rsi
    59b7:      	jb	0x6086 <generic_tracepoint_arg+0xcf6>
    59bd:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
    59c7:      	btq	%rdx, %rsi
    59cb:      	jae	0x549d <generic_tracepoint_arg+0x10d>
    59d1:      	cmpl	$0x1f, %eax
    59d4:      	jne	0x66c1 <generic_tracepoint_arg+0x1331>
    59da:      	movl	0x10(%r12), %esi
    59df:      	movl	0x14(%r12), %edx
    59e4:      	cmpl	$0xc, %ecx
    59e7:      	ja	0x7474 <generic_tracepoint_arg+0x20e4>
    59ed:      	movl	$0x1402, %eax           # imm = 0x1402
    59f2:      	btl	%ecx, %eax
    59f5:      	jae	0x7474 <generic_tracepoint_arg+0x20e4>
    59fb:      	movq	0x8(%rsp), %rax
    5a00:      	movl	(%rax), %eax
    5a02:      	cmpl	%eax, %esi
    5a04:      	jg	0x7487 <generic_tracepoint_arg+0x20f7>
    5a0a:      	cmpl	%edx, %eax
    5a0c:      	jle	0x5658 <generic_tracepoint_arg+0x2c8>
    5a12:      	jmp	0x7487 <generic_tracepoint_arg+0x20f7>
    5a17:      	cmpl	$0x20, %eax
    5a1a:      	jg	0x61e5 <generic_tracepoint_arg+0xe55>
    5a20:      	cmpl	$0x1a, %eax
    5a23:      	je	0x62c7 <generic_tracepoint_arg+0xf37>
    5a29:      	movl	$0x0, %ebx
    5a2e:      	cmpl	$0x1b, %eax
    5a31:      	jne	0x8357 <generic_tracepoint_arg+0x2fc7>
    5a37:      	movq	%rsi, 0x8(%rsp)
    5a3c:      	movq	%r11, 0x20(%rsp)
    5a41:      	movl	0x10(%r12), %eax
    5a46:      	movl	%eax, 0x40(%rsp)
    5a4a:      	movl	$0x0, 0x80(%rsp)
    5a55:      	movl	$0x1, %eax
    5a5a:      	leaq	0x40(%rsp), %rsi
    5a5f:      	movq	(%rip), %rdi            # 0x5a66 <generic_tracepoint_arg+0x6d6>
    5a66:      	callq	*%rax
    5a68:      	testl	%ebp, %ebp
    5a6a:      	je	0x8346 <generic_tracepoint_arg+0x2fb6>
    5a70:      	movl	$0x0, %ebx
    5a75:      	testq	%rax, %rax
    5a78:      	je	0x8348 <generic_tracepoint_arg+0x2fb8>
    5a7e:      	movq	%rax, 0x28(%rsp)
    5a83:      	movl	$0x1, %eax
    5a88:      	movq	0x38(%rsp), %rsi
    5a8d:      	movq	(%rip), %rdi            # 0x5a94 <generic_tracepoint_arg+0x704>
    5a94:      	callq	*%rax
    5a96:      	testq	%rax, %rax
    5a99:      	je	0x8346 <generic_tracepoint_arg+0x2fb6>
    5a9f:      	movq	%rax, %rdi
    5aa2:      	cmpl	$0x7f, %ebp
    5aa5:      	movl	$0x7f, %eax
    5aaa:      	cmovbl	%ebp, %eax
    5aad:      	shll	$0x3, %eax
    5ab0:      	movl	%eax, (%rdi)
    5ab2:      	movq	%rbp, %rax
    5ab5:      	negq	%rax
    5ab8:      	movl	$0x3, %ecx
    5abd:      	subq	%rbp, %rcx
    5ac0:      	leal	-0x4(%rbp), %edx
    5ac3:      	movq	%rdi, 0x70(%rsp)
    5ac8:      	addq	$0x7, %rdi
    5acc:      	movl	$0x2, %r8d
    5ad2:      	subq	%rbp, %r8
    5ad5:      	leal	-0x3(%rbp), %r9d
    5ad9:      	movl	$0x1, %r10d
    5adf:      	subq	%rbp, %r10
    5ae2:      	leal	-0x2(%rbp), %r11d
    5ae6:      	decl	%ebp
    5ae8:      	xorl	%ebx, %ebx
    5aea:      	movq	0x8(%rsp), %rsi
    5aef:      	leal	(%rbx,%rbp), %r13d
    5af3:      	andl	$0xfff, %r13d           # imm = 0xFFF
    5afa:      	movzbl	(%rsi,%r13), %r13d
    5aff:      	movb	%r13b, -0x3(%rdi)
    5b03:      	cmpq	%rbx, %r10
    5b06:      	je	0x5b60 <generic_tracepoint_arg+0x7d0>
    5b08:      	leal	(%r11,%rbx), %r13d
    5b0c:      	andl	$0xfff, %r13d           # imm = 0xFFF
    5b13:      	movzbl	(%rsi,%r13), %r13d
    5b18:      	movb	%r13b, -0x2(%rdi)
    5b1c:      	cmpq	%rbx, %r8
    5b1f:      	je	0x5b60 <generic_tracepoint_arg+0x7d0>
    5b21:      	leal	(%r9,%rbx), %r13d
    5b25:      	andl	$0xfff, %r13d           # imm = 0xFFF
    5b2c:      	movzbl	(%rsi,%r13), %r13d
    5b31:      	movb	%r13b, -0x1(%rdi)
    5b35:      	cmpq	%rbx, %rcx
    5b38:      	je	0x5b60 <generic_tracepoint_arg+0x7d0>
    5b3a:      	cmpq	$-0x7c, %rbx
    5b3e:      	je	0x5b60 <generic_tracepoint_arg+0x7d0>
    5b40:      	leal	(%rdx,%rbx), %r13d
    5b44:      	andl	$0xfff, %r13d           # imm = 0xFFF
    5b4b:      	movzbl	(%rsi,%r13), %r13d
    5b50:      	movb	%r13b, (%rdi)
    5b53:      	addq	$-0x4, %rbx
    5b57:      	addq	$0x4, %rdi
    5b5b:      	cmpq	%rbx, %rax
    5b5e:      	jne	0x5aef <generic_tracepoint_arg+0x75f>
    5b60:      	movl	$0x1, %eax
    5b65:      	movq	0x28(%rsp), %rdi
    5b6a:      	movq	0x70(%rsp), %rsi
    5b6f:      	callq	*%rax
    5b71:      	xorl	%ebx, %ebx
    5b73:      	testq	%rax, %rax
    5b76:      	setne	%bl
    5b79:      	movq	0x78(%rsp), %r13
    5b7e:      	jmp	0x8348 <generic_tracepoint_arg+0x2fb8>
    5b83:      	cmpl	$0x11, %ecx
    5b86:      	jne	0x5658 <generic_tracepoint_arg+0x2c8>
    5b8c:      	movq	%r8, %rsi
    5b8f:      	addq	$0x4, %rsi
    5b93:      	movq	%rsi, 0x8(%rsp)
    5b98:      	movl	(%rsi), %ebp
    5b9a:      	movl	%eax, %ecx
    5b9c:      	andl	$-0x2, %ecx
    5b9f:      	cmpl	$0x24, %ecx
    5ba2:      	je	0x5bac <generic_tracepoint_arg+0x81c>
    5ba4:      	testl	%ebp, %ebp
    5ba6:      	je	0x549d <generic_tracepoint_arg+0x10d>
    5bac:      	cmpl	$0x25, %eax
    5baf:      	movq	0x8(%rsp), %rsi
    5bb4:      	ja	0x5cb4 <generic_tracepoint_arg+0x924>
    5bba:      	movl	%eax, %ecx
    5bbc:      	movl	$0x4000100, %edx        # imm = 0x4000100
    5bc1:      	btq	%rcx, %rdx
    5bc5:      	jb	0x5fde <generic_tracepoint_arg+0xc4e>
    5bcb:      	movl	$0x8000200, %edx        # imm = 0x8000200
    5bd0:      	btq	%rcx, %rdx
    5bd4:      	jb	0x5e93 <generic_tracepoint_arg+0xb03>
    5bda:      	movabsq	$0x3000000000, %rdx     # imm = 0x3000000000
    5be4:      	btq	%rcx, %rdx
    5be8:      	jae	0x5cb4 <generic_tracepoint_arg+0x924>
    5bee:      	movw	$0x0, 0x40(%rsp)
    5bf5:      	cmpl	$0x1fe, %ebp            # imm = 0x1FE
    5bfb:      	ja	0x5cd3 <generic_tracepoint_arg+0x943>
    5c01:      	movq	%r11, 0x20(%rsp)
    5c06:      	leaq	(%rsi,%rbp), %rcx
    5c0a:      	addq	$0x8, %rcx
    5c0e:      	movl	$0x4, %eax
    5c13:      	leaq	0x40(%rsp), %rdi
    5c18:      	movl	$0x2, %edx
    5c1d:      	movl	(%rsi), %ecx
    5c1f:      	leaq	(%rsi,%rcx), %rdx
    5c23:      	addq	$0x8, %rdx
    5c27:      	movl	$0x2, %esi
    5c2c:      	callq	*%rax
    5c2e:      	movl	0x10(%r12), %ecx
    5c33:      	testl	%ecx, %ecx
    5c35:      	je	0x8169 <generic_tracepoint_arg+0x2dd9>
    5c3b:      	movzwl	0x40(%rsp), %eax
    5c40:      	andl	$0xf000, %eax           # imm = 0xF000
    5c45:      	movl	$0x1, %ebx
    5c4a:      	cmpl	%eax, %ecx
    5c4c:      	je	0x816b <generic_tracepoint_arg+0x2ddb>
    5c52:      	movl	0x8(%r12), %ecx
    5c57:      	cmpl	$0xd, %ecx
    5c5a:      	movq	0x10(%rsp), %rdi
    5c5f:      	movq	0x18(%rsp), %r9
    5c64:      	movq	0x20(%rsp), %r11
    5c69:      	jb	0x5cd3 <generic_tracepoint_arg+0x943>
    5c6b:      	movl	0x14(%r12), %edx
    5c70:      	testl	%edx, %edx
    5c72:      	je	0x5cd3 <generic_tracepoint_arg+0x943>
    5c74:      	cmpl	%eax, %edx
    5c76:      	je	0x817a <generic_tracepoint_arg+0x2dea>
    5c7c:      	cmpl	$0x11, %ecx
    5c7f:      	jb	0x5cd3 <generic_tracepoint_arg+0x943>
    5c81:      	movl	0x18(%r12), %edx
    5c86:      	testl	%edx, %edx
    5c88:      	je	0x5cd3 <generic_tracepoint_arg+0x943>
    5c8a:      	cmpl	%eax, %edx
    5c8c:      	je	0x817a <generic_tracepoint_arg+0x2dea>
    5c92:      	cmpl	$0x15, %ecx
    5c95:      	jb	0x8694 <generic_tracepoint_arg+0x3304>
    5c9b:      	movl	0x1c(%r12), %ecx
    5ca0:      	testl	%ecx, %ecx
    5ca2:      	je	0x8694 <generic_tracepoint_arg+0x3304>
    5ca8:      	xorl	%ebx, %ebx
    5caa:      	cmpl	%eax, %ecx
    5cac:      	sete	%bl
    5caf:      	jmp	0x8696 <generic_tracepoint_arg+0x3306>
    5cb4:      	addl	$-0x3, %eax
    5cb7:      	cmpl	$0x2, %eax
    5cba:      	jae	0x5cd3 <generic_tracepoint_arg+0x943>
    5cbc:      	movl	$0x0, 0x80(%rsp)
    5cc7:      	cmpl	$0x1fe, %ebp            # imm = 0x1FE
    5ccd:      	jbe	0x666b <generic_tracepoint_arg+0x12db>
    5cd3:      	xorl	%ebx, %ebx
    5cd5:      	movl	0x4(%r12), %eax
    5cda:      	cmpq	$0x25, %rax
    5cde:      	jbe	0x8189 <generic_tracepoint_arg+0x2df9>
    5ce4:      	jmp	0x5647 <generic_tracepoint_arg+0x2b7>
    5ce9:      	cmpl	$0x20, %eax
    5cec:      	ja	0x549d <generic_tracepoint_arg+0x10d>
    5cf2:      	movl	%eax, %ecx
    5cf4:      	movl	$0x101e, %edx           # imm = 0x101E
    5cf9:      	btq	%rcx, %rdx
    5cfd:      	jae	0x65a5 <generic_tracepoint_arg+0x1215>
    5d03:      	movl	0x10(%r12), %ecx
    5d08:      	cmpl	$0x2, %eax
    5d0b:      	jle	0x6aa3 <generic_tracepoint_arg+0x1713>
    5d11:      	leal	-0x3(%rax), %edx
    5d14:      	cmpl	$0x2, %edx
    5d17:      	movq	0x8(%rsp), %rdx
    5d1c:      	jae	0x70cd <generic_tracepoint_arg+0x1d3d>
    5d22:      	movzwl	(%rdx), %edx
    5d25:      	cmpl	%edx, %ecx
    5d27:      	jne	0x741a <generic_tracepoint_arg+0x208a>
    5d2d:      	jmp	0x85b1 <generic_tracepoint_arg+0x3221>
    5d32:      	leal	-0x1(%rax), %edx
    5d35:      	cmpl	$0x4, %edx
    5d38:      	jb	0x5d99 <generic_tracepoint_arg+0xa09>
    5d3a:      	jmp	0x549d <generic_tracepoint_arg+0x10d>
    5d3f:      	cmpl	$0x1, %eax
    5d42:      	je	0x682f <generic_tracepoint_arg+0x149f>
    5d48:      	cmpl	$0x2, %eax
    5d4b:      	jne	0x7651 <generic_tracepoint_arg+0x22c1>
    5d51:      	cmpl	$0xc, %ecx
    5d54:      	ja	0x7644 <generic_tracepoint_arg+0x22b4>
    5d5a:      	movl	$0x1402, %esi           # imm = 0x1402
    5d5f:      	btl	%ecx, %esi
    5d62:      	jae	0x7644 <generic_tracepoint_arg+0x22b4>
    5d68:      	movq	0x8(%rsp), %rsi
    5d6d:      	cmpl	%edx, (%rsi)
    5d6f:      	jl	0x5658 <generic_tracepoint_arg+0x2c8>
    5d75:      	jmp	0x7651 <generic_tracepoint_arg+0x22c1>
    5d7a:      	cmpl	$0x1c, %ecx
    5d7d:      	jne	0x5658 <generic_tracepoint_arg+0x2c8>
    5d83:      	cmpl	$0x20, %eax
    5d86:      	ja	0x549d <generic_tracepoint_arg+0x10d>
    5d8c:      	movl	%eax, %edx
    5d8e:      	movl	$0x101e, %esi           # imm = 0x101E
    5d93:      	btq	%rdx, %rsi
    5d97:      	jae	0x5dc2 <generic_tracepoint_arg+0xa32>
    5d99:      	movq	0x10(%r12), %rdx
    5d9e:      	cmpl	$0x2, %eax
    5da1:      	jle	0x5de6 <generic_tracepoint_arg+0xa56>
    5da3:      	leal	-0x3(%rax), %esi
    5da6:      	cmpl	$0x2, %esi
    5da9:      	jae	0x60d0 <generic_tracepoint_arg+0xd40>
    5daf:      	movq	0x8(%rsp), %rsi
    5db4:      	cmpq	%rdx, (%rsi)
    5db7:      	jne	0x7023 <generic_tracepoint_arg+0x1c93>
    5dbd:      	jmp	0x85b1 <generic_tracepoint_arg+0x3221>
    5dc2:      	movl	$0xc00, %esi            # imm = 0xC00
    5dc7:      	btq	%rdx, %rsi
    5dcb:      	jb	0x5e19 <generic_tracepoint_arg+0xa89>
    5dcd:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
    5dd7:      	btq	%rdx, %rsi
    5ddb:      	jb	0x61a5 <generic_tracepoint_arg+0xe15>
    5de1:      	jmp	0x549d <generic_tracepoint_arg+0x10d>
    5de6:      	cmpl	$0x1, %eax
    5de9:      	je	0x664a <generic_tracepoint_arg+0x12ba>
    5def:      	cmpl	$0x2, %eax
    5df2:      	jne	0x7023 <generic_tracepoint_arg+0x1c93>
    5df8:      	cmpl	$0xc, %ecx
    5dfb:      	je	0x5e06 <generic_tracepoint_arg+0xa76>
    5dfd:      	cmpl	$0xa, %ecx
    5e00:      	jne	0x7015 <generic_tracepoint_arg+0x1c85>
    5e06:      	movq	0x8(%rsp), %rsi
    5e0b:      	cmpq	%rdx, (%rsi)
    5e0e:      	jl	0x5658 <generic_tracepoint_arg+0x2c8>
    5e14:      	jmp	0x7023 <generic_tracepoint_arg+0x1c93>
    5e19:      	movq	%r11, %rbp
    5e1c:      	movzbl	0x10(%r12), %eax
    5e22:      	movl	%eax, 0x80(%rsp)
    5e29:      	movl	$0x1, %eax
    5e2e:      	movq	0x38(%rsp), %rsi
    5e33:      	movq	(%rip), %rdi            # 0x5e3a <generic_tracepoint_arg+0xaaa>
    5e3a:      	callq	*%rax
    5e3c:      	testq	%rax, %rax
    5e3f:      	je	0x6b8b <generic_tracepoint_arg+0x17fb>
    5e45:      	movq	%rax, %rdi
    5e48:      	movq	0x8(%rsp), %rax
    5e4d:      	movq	(%rax), %rax
    5e50:      	movq	%rax, 0x40(%rsp)
    5e55:      	movl	$0x1, %eax
    5e5a:      	leaq	0x40(%rsp), %rsi
    5e5f:      	callq	*%rax
    5e61:      	movl	0x4(%r12), %ecx
    5e66:      	cmpl	$0xb, %ecx
    5e69:      	je	0x6bb7 <generic_tracepoint_arg+0x1827>
    5e6f:      	cmpl	$0xa, %ecx
    5e72:      	movq	0x10(%rsp), %rdi
    5e77:      	movq	0x18(%rsp), %r9
    5e7c:      	movq	%rbp, %r11
    5e7f:      	jne	0x6bd2 <generic_tracepoint_arg+0x1842>
    5e85:      	testq	%rax, %rax
    5e88:      	setne	%al
    5e8b:      	movzbl	%al, %ebx
    5e8e:      	jmp	0x5647 <generic_tracepoint_arg+0x2b7>
    5e93:      	movq	%r11, 0x20(%rsp)
    5e98:      	movl	0x10(%r12), %eax
    5e9d:      	movl	%eax, 0x40(%rsp)
    5ea1:      	movl	$0x0, 0x80(%rsp)
    5eac:      	movl	$0x1, %eax
    5eb1:      	leaq	0x40(%rsp), %rsi
    5eb6:      	movq	(%rip), %rdi            # 0x5ebd <generic_tracepoint_arg+0xb2d>
    5ebd:      	callq	*%rax
    5ebf:      	testl	%ebp, %ebp
    5ec1:      	je	0x8169 <generic_tracepoint_arg+0x2dd9>
    5ec7:      	movl	$0x0, %ebx
    5ecc:      	testq	%rax, %rax
    5ecf:      	je	0x816b <generic_tracepoint_arg+0x2ddb>
    5ed5:      	movq	%rax, 0x28(%rsp)
    5eda:      	movl	$0x1, %eax
    5edf:      	movq	0x38(%rsp), %rsi
    5ee4:      	movq	(%rip), %rdi            # 0x5eeb <generic_tracepoint_arg+0xb5b>
    5eeb:      	callq	*%rax
    5eed:      	testq	%rax, %rax
    5ef0:      	je	0x8169 <generic_tracepoint_arg+0x2dd9>
    5ef6:      	movq	%rax, %rdi
    5ef9:      	cmpl	$0x7f, %ebp
    5efc:      	movl	$0x7f, %eax
    5f01:      	cmovbl	%ebp, %eax
    5f04:      	shll	$0x3, %eax
    5f07:      	movl	%eax, (%rdi)
    5f09:      	movq	%rbp, %rax
    5f0c:      	negq	%rax
    5f0f:      	movl	$0x3, %ecx
    5f14:      	subq	%rbp, %rcx
    5f17:      	leal	-0x4(%rbp), %edx
    5f1a:      	movq	%rdi, 0x70(%rsp)
    5f1f:      	addq	$0x7, %rdi
    5f23:      	movl	$0x2, %r8d
    5f29:      	subq	%rbp, %r8
    5f2c:      	leal	-0x3(%rbp), %r9d
    5f30:      	movl	$0x1, %r10d
    5f36:      	subq	%rbp, %r10
    5f39:      	leal	-0x2(%rbp), %r11d
    5f3d:      	decl	%ebp
    5f3f:      	xorl	%ebx, %ebx
    5f41:      	movq	0x8(%rsp), %rsi
    5f46:      	leal	(%rbx,%rbp), %r13d
    5f4a:      	andl	$0xfff, %r13d           # imm = 0xFFF
    5f51:      	movzbl	0x4(%rsi,%r13), %r13d
    5f57:      	movb	%r13b, -0x3(%rdi)
    5f5b:      	cmpq	%rbx, %r10
    5f5e:      	je	0x5fbb <generic_tracepoint_arg+0xc2b>
    5f60:      	leal	(%r11,%rbx), %r13d
    5f64:      	andl	$0xfff, %r13d           # imm = 0xFFF
    5f6b:      	movzbl	0x4(%rsi,%r13), %r13d
    5f71:      	movb	%r13b, -0x2(%rdi)
    5f75:      	cmpq	%rbx, %r8
    5f78:      	je	0x5fbb <generic_tracepoint_arg+0xc2b>
    5f7a:      	leal	(%r9,%rbx), %r13d
    5f7e:      	andl	$0xfff, %r13d           # imm = 0xFFF
    5f85:      	movzbl	0x4(%rsi,%r13), %r13d
    5f8b:      	movb	%r13b, -0x1(%rdi)
    5f8f:      	cmpq	%rbx, %rcx
    5f92:      	je	0x5fbb <generic_tracepoint_arg+0xc2b>
    5f94:      	cmpq	$-0x7c, %rbx
    5f98:      	je	0x5fbb <generic_tracepoint_arg+0xc2b>
    5f9a:      	leal	(%rdx,%rbx), %r13d
    5f9e:      	andl	$0xfff, %r13d           # imm = 0xFFF
    5fa5:      	movzbl	0x4(%rsi,%r13), %r13d
    5fab:      	movb	%r13b, (%rdi)
    5fae:      	addq	$-0x4, %rbx
    5fb2:      	addq	$0x4, %rdi
    5fb6:      	cmpq	%rbx, %rax
    5fb9:      	jne	0x5f46 <generic_tracepoint_arg+0xbb6>
    5fbb:      	movl	$0x1, %eax
    5fc0:      	movq	0x28(%rsp), %rdi
    5fc5:      	movq	0x70(%rsp), %rsi
    5fca:      	callq	*%rax
    5fcc:      	xorl	%ebx, %ebx
    5fce:      	testq	%rax, %rax
    5fd1:      	setne	%bl
    5fd4:      	movq	0x78(%rsp), %r13
    5fd9:      	jmp	0x816b <generic_tracepoint_arg+0x2ddb>
    5fde:      	movq	%r11, 0x20(%rsp)
    5fe3:      	movl	0x10(%r12), %eax
    5fe8:      	movl	%eax, 0x40(%rsp)
    5fec:      	movl	$0x0, 0x80(%rsp)
    5ff7:      	movl	$0x1, %eax
    5ffc:      	leaq	0x40(%rsp), %rsi
    6001:      	movq	(%rip), %rdi            # 0x6008 <generic_tracepoint_arg+0xc78>
    6008:      	callq	*%rax
    600a:      	testl	%ebp, %ebp
    600c:      	je	0x8169 <generic_tracepoint_arg+0x2dd9>
    6012:      	movl	$0x0, %ebx
    6017:      	testq	%rax, %rax
    601a:      	je	0x816b <generic_tracepoint_arg+0x2ddb>
    6020:      	movq	%rax, 0x28(%rsp)
    6025:      	movl	$0x1, %eax
    602a:      	movq	0x38(%rsp), %rsi
    602f:      	movq	(%rip), %rdi            # 0x6036 <generic_tracepoint_arg+0xca6>
    6036:      	callq	*%rax
    6038:      	testq	%rax, %rax
    603b:      	je	0x8169 <generic_tracepoint_arg+0x2dd9>
    6041:      	movq	%rax, %rbx
    6044:      	movq	0x8(%rsp), %rdx
    6049:      	addq	$0x4, %rdx
    604d:      	cmpl	$0xff, %ebp
    6053:      	movl	$0xff, %eax
    6058:      	cmovael	%eax, %ebp
    605b:      	leal	(,%rbp,8), %eax
    6062:      	movl	%eax, (%rbx)
    6064:      	movq	%rbx, %rdi
    6067:      	addq	$0x4, %rdi
    606b:      	movl	$0x4, %eax
    6070:      	movl	%ebp, %esi
    6072:      	callq	*%rax
    6074:      	movl	$0x1, %eax
    6079:      	movq	0x28(%rsp), %rdi
    607e:      	movq	%rbx, %rsi
    6081:      	jmp	0x815d <generic_tracepoint_arg+0x2dcd>
    6086:      	movq	%r11, %rbp
    6089:      	movzbl	0x10(%r12), %eax
    608f:      	movl	%eax, 0x80(%rsp)
    6096:      	movl	$0x1, %eax
    609b:      	movq	0x38(%rsp), %rsi
    60a0:      	movq	(%rip), %rdi            # 0x60a7 <generic_tracepoint_arg+0xd17>
    60a7:      	callq	*%rax
    60a9:      	testq	%rax, %rax
    60ac:      	je	0x6b8b <generic_tracepoint_arg+0x17fb>
    60b2:      	movq	%rax, %rdi
    60b5:      	movq	0x8(%rsp), %rax
    60ba:      	movl	(%rax), %eax
    60bc:      	movq	%rax, 0x40(%rsp)
    60c1:      	movl	$0x1, %eax
    60c6:      	leaq	0x40(%rsp), %rsi
    60cb:      	jmp	0x6b54 <generic_tracepoint_arg+0x17c4>
    60d0:      	cmpl	$0xc, %eax
    60d3:      	jne	0x7023 <generic_tracepoint_arg+0x1c93>
    60d9:      	movq	0x8(%rsp), %rsi
    60de:      	testq	%rdx, (%rsi)
    60e1:      	jne	0x5658 <generic_tracepoint_arg+0x2c8>
    60e7:      	jmp	0x7023 <generic_tracepoint_arg+0x1c93>
    60ec:      	movzwl	(%rsi), %edx
    60ef:      	movw	%dx, 0x66(%rsp)
    60f4:      	movzwl	0x2(%rsi), %edx
    60f8:      	movw	%dx, 0x60(%rsp)
    60fd:      	movq	0x8(%rsi), %rdx
    6101:      	movq	%rdx, 0x40(%rsp)
    6106:      	movq	0x10(%rsi), %rdx
    610a:      	movq	%rdx, 0x48(%rsp)
    610f:      	leaq	0x40(%rsp), %rsi
    6114:      	xorl	%edx, %edx
    6116:      	cmpl	$0x13, %eax
    6119:      	jle	0x6142 <generic_tracepoint_arg+0xdb2>
    611b:      	cmpl	$0x17, %eax
    611e:      	jg	0x6174 <generic_tracepoint_arg+0xde4>
    6120:      	leal	-0x14(%rax), %ecx
    6123:      	cmpl	$0x2, %ecx
    6126:      	jb	0x6713 <generic_tracepoint_arg+0x1383>
    612c:      	leal	-0x16(%rax), %ecx
    612f:      	movl	$0x0, %ebx
    6134:      	cmpl	$0x2, %ecx
    6137:      	jb	0x670c <generic_tracepoint_arg+0x137c>
    613d:      	jmp	0x5642 <generic_tracepoint_arg+0x2b2>
    6142:      	cmpl	$0xf, %eax
    6145:      	jle	0x63cf <generic_tracepoint_arg+0x103f>
    614b:      	cmpl	$0x11, %eax
    614e:      	jg	0x66f9 <generic_tracepoint_arg+0x1369>
    6154:      	cmpl	$0x10, %eax
    6157:      	je	0x670c <generic_tracepoint_arg+0x137c>
    615d:      	movl	$0x0, %ebx
    6162:      	cmpl	$0x11, %eax
    6165:      	jne	0x5642 <generic_tracepoint_arg+0x2b2>
    616b:      	movzwl	0x24(%rsi), %ebx
    616f:      	jmp	0x6f7e <generic_tracepoint_arg+0x1bee>
    6174:      	cmpl	$0x1b, %eax
    6177:      	jg	0x674c <generic_tracepoint_arg+0x13bc>
    617d:      	cmpl	$0x18, %eax
    6180:      	je	0x6786 <generic_tracepoint_arg+0x13f6>
    6186:      	movl	$0x0, %ebx
    618b:      	cmpl	$0x19, %eax
    618e:      	je	0x677c <generic_tracepoint_arg+0x13ec>
    6194:      	jmp	0x5642 <generic_tracepoint_arg+0x2b2>
    6199:      	leal	-0x1f(%rax), %edx
    619c:      	cmpl	$0x2, %edx
    619f:      	jae	0x6cae <generic_tracepoint_arg+0x191e>
    61a5:      	cmpl	$0x1f, %eax
    61a8:      	jne	0x639d <generic_tracepoint_arg+0x100d>
    61ae:      	movq	0x10(%r12), %rsi
    61b3:      	movq	0x18(%r12), %rdx
    61b8:      	cmpl	$0xa, %ecx
    61bb:      	je	0x61c6 <generic_tracepoint_arg+0xe36>
    61bd:      	cmpl	$0xc, %ecx
    61c0:      	jne	0x6ed1 <generic_tracepoint_arg+0x1b41>
    61c6:      	movq	0x8(%rsp), %rax
    61cb:      	movq	(%rax), %rax
    61ce:      	cmpq	%rax, %rsi
    61d1:      	jg	0x6ee7 <generic_tracepoint_arg+0x1b57>
    61d7:      	cmpq	%rdx, %rax
    61da:      	jle	0x5658 <generic_tracepoint_arg+0x2c8>
    61e0:      	jmp	0x6ee7 <generic_tracepoint_arg+0x1b57>
    61e5:      	cmpl	$0x21, %eax
    61e8:      	je	0x6858 <generic_tracepoint_arg+0x14c8>
    61ee:      	movl	$0x0, %ebx
    61f3:      	cmpl	$0x22, %eax
    61f6:      	jne	0x8357 <generic_tracepoint_arg+0x2fc7>
    61fc:      	movq	%rsi, 0x8(%rsp)
    6201:      	xorl	%ebx, %ebx
    6203:      	xorl	%r13d, %r13d
    6206:      	movq	%r11, %r15
    6209:      	movl	0x10(%r12,%rbx,4), %eax
    620e:      	movl	%eax, 0x40(%rsp)
    6212:      	movl	$0x1, %eax
    6217:      	leaq	0x40(%rsp), %rsi
    621c:      	movq	(%rip), %rdi            # 0x6223 <generic_tracepoint_arg+0xe93>
    6223:      	callq	*%rax
    6225:      	testq	%rax, %rax
    6228:      	je	0x7723 <generic_tracepoint_arg+0x2393>
    622e:      	testl	%ebp, %ebp
    6230:      	movq	%r15, %r11
    6233:      	movq	0x68(%rsp), %r15
    6238:      	je	0x62a4 <generic_tracepoint_arg+0xf14>
    623a:      	movq	0x8(%rsp), %rdx
    623f:      	xorl	%ecx, %ecx
    6241:      	jmp	0x624e <generic_tracepoint_arg+0xebe>
    6243:      	incq	%rcx
    6246:      	incq	%rdx
    6249:      	cmpq	%rbp, %rcx
    624c:      	je	0x62a4 <generic_tracepoint_arg+0xf14>
    624e:      	xorl	%esi, %esi
    6250:      	leaq	(%rcx,%rsi), %rdi
    6254:      	cmpq	%rbp, %rdi
    6257:      	jae	0x6243 <generic_tracepoint_arg+0xeb3>
    6259:      	movsbl	(%rax,%rsi), %edi
    625d:      	testl	%edi, %edi
    625f:      	je	0x629c <generic_tracepoint_arg+0xf0c>
    6261:      	movsbl	(%rdx,%rsi), %r9d
    6266:      	leal	-0x41(%r9), %r10d
    626a:      	movl	%r9d, %r8d
    626d:      	orl	$0x20, %r8d
    6271:      	cmpl	$0x1a, %r10d
    6275:      	cmovael	%r9d, %r8d
    6279:      	leal	-0x41(%rdi), %r10d
    627d:      	movl	%edi, %r9d
    6280:      	orl	$0x20, %r9d
    6284:      	cmpl	$0x1a, %r10d
    6288:      	cmovael	%edi, %r9d
    628c:      	cmpq	$0x62, %rsi
    6290:      	ja	0x6243 <generic_tracepoint_arg+0xeb3>
    6292:      	incq	%rsi
    6295:      	cmpl	%r9d, %r8d
    6298:      	je	0x6250 <generic_tracepoint_arg+0xec0>
    629a:      	jmp	0x6243 <generic_tracepoint_arg+0xeb3>
    629c:      	testl	%ecx, %ecx
    629e:      	jns	0x7a18 <generic_tracepoint_arg+0x2688>
    62a4:      	leal	0xc(%r13), %eax
    62a8:      	cmpl	0x8(%r12), %eax
    62ad:      	jae	0x62c0 <generic_tracepoint_arg+0xf30>
    62af:      	addl	$0x4, %r13d
    62b3:      	incq	%rbx
    62b6:      	cmpq	$0x64, %rbx
    62ba:      	jne	0x6206 <generic_tracepoint_arg+0xe76>
    62c0:      	xorl	%ebx, %ebx
    62c2:      	jmp	0x7a1d <generic_tracepoint_arg+0x268d>
    62c7:      	movq	%rsi, 0x8(%rsp)
    62cc:      	movq	%r11, 0x20(%rsp)
    62d1:      	movl	0x10(%r12), %eax
    62d6:      	movl	%eax, 0x40(%rsp)
    62da:      	movl	$0x0, 0x80(%rsp)
    62e5:      	movl	$0x1, %eax
    62ea:      	leaq	0x40(%rsp), %rsi
    62ef:      	movq	(%rip), %rdi            # 0x62f6 <generic_tracepoint_arg+0xf66>
    62f6:      	callq	*%rax
    62f8:      	testl	%ebp, %ebp
    62fa:      	je	0x8346 <generic_tracepoint_arg+0x2fb6>
    6300:      	movl	$0x0, %ebx
    6305:      	testq	%rax, %rax
    6308:      	je	0x8348 <generic_tracepoint_arg+0x2fb8>
    630e:      	movq	%rax, 0x28(%rsp)
    6313:      	movl	$0x1, %eax
    6318:      	movq	0x38(%rsp), %rsi
    631d:      	movq	(%rip), %rdi            # 0x6324 <generic_tracepoint_arg+0xf94>
    6324:      	callq	*%rax
    6326:      	testq	%rax, %rax
    6329:      	je	0x8346 <generic_tracepoint_arg+0x2fb6>
    632f:      	cmpl	$0xff, %ebp
    6335:      	movl	$0xff, %ecx
    633a:      	cmovael	%ecx, %ebp
    633d:      	leal	(,%rbp,8), %ecx
    6344:      	movl	%ecx, (%rax)
    6346:      	movq	%rax, %rdi
    6349:      	addq	$0x4, %rdi
    634d:      	movq	%rax, %rbx
    6350:      	movl	$0x4, %eax
    6355:      	movq	0x8(%rsp), %rdx
    635a:      	movl	%ebp, %esi
    635c:      	callq	*%rax
    635e:      	movl	$0x1, %eax
    6363:      	movq	0x28(%rsp), %rdi
    6368:      	movq	%rbx, %rsi
    636b:      	jmp	0x833a <generic_tracepoint_arg+0x2faa>
    6370:      	movl	$0x0, 0x80(%rsp)
    637b:      	cmpl	$0x1fe, %ebp            # imm = 0x1FE
    6381:      	jbe	0x6912 <generic_tracepoint_arg+0x1582>
    6387:      	xorl	%ebx, %ebx
    6389:      	movl	0x4(%r12), %eax
    638e:      	cmpq	$0x25, %rax
    6392:      	jbe	0x8366 <generic_tracepoint_arg+0x2fd6>
    6398:      	jmp	0x5647 <generic_tracepoint_arg+0x2b7>
    639d:      	movq	0x10(%r12), %rsi
    63a2:      	movq	0x18(%r12), %rax
    63a7:      	cmpl	$0xc, %ecx
    63aa:      	je	0x63b5 <generic_tracepoint_arg+0x1025>
    63ac:      	cmpl	$0xa, %ecx
    63af:      	jne	0x6f29 <generic_tracepoint_arg+0x1b99>
    63b5:      	movq	0x8(%rsp), %rdx
    63ba:      	movq	(%rdx), %rdx
    63bd:      	cmpq	%rdx, %rsi
    63c0:      	setle	%sil
    63c4:      	cmpq	%rax, %rdx
    63c7:      	setle	%al
    63ca:      	jmp	0x6f3e <generic_tracepoint_arg+0x1bae>
    63cf:      	cmpl	$0xd, %eax
    63d2:      	je	0x6786 <generic_tracepoint_arg+0x13f6>
    63d8:      	cmpl	$0xe, %eax
    63db:      	je	0x677c <generic_tracepoint_arg+0x13ec>
    63e1:      	movl	$0x0, %ebx
    63e6:      	cmpl	$0xf, %eax
    63e9:      	je	0x6713 <generic_tracepoint_arg+0x1383>
    63ef:      	jmp	0x5642 <generic_tracepoint_arg+0x2b2>
    63f4:      	cmpl	$0x20, %eax
    63f7:      	movq	%rsi, 0x8(%rsp)
    63fc:      	jg	0x69e8 <generic_tracepoint_arg+0x1658>
    6402:      	cmpl	$0x1a, %eax
    6405:      	je	0x6bdc <generic_tracepoint_arg+0x184c>
    640b:      	movl	$0x0, %ebx
    6410:      	cmpl	$0x1b, %eax
    6413:      	jne	0x8625 <generic_tracepoint_arg+0x3295>
    6419:      	movq	%r11, 0x20(%rsp)
    641e:      	movl	0x10(%r12), %eax
    6423:      	movl	%eax, 0x40(%rsp)
    6427:      	movl	$0x0, 0x80(%rsp)
    6432:      	movl	$0x1, %eax
    6437:      	leaq	0x40(%rsp), %rsi
    643c:      	movq	(%rip), %rdi            # 0x6443 <generic_tracepoint_arg+0x10b3>
    6443:      	callq	*%rax
    6445:      	testl	%ebp, %ebp
    6447:      	je	0x8614 <generic_tracepoint_arg+0x3284>
    644d:      	movq	%rax, %r13
    6450:      	movl	$0x0, %ebx
    6455:      	testq	%rax, %rax
    6458:      	je	0x8616 <generic_tracepoint_arg+0x3286>
    645e:      	movl	$0x1, %eax
    6463:      	movq	0x38(%rsp), %rsi
    6468:      	movq	(%rip), %rdi            # 0x646f <generic_tracepoint_arg+0x10df>
    646f:      	callq	*%rax
    6471:      	testq	%rax, %rax
    6474:      	je	0x8614 <generic_tracepoint_arg+0x3284>
    647a:      	movq	%rax, %rdi
    647d:      	movq	%r13, 0x28(%rsp)
    6482:      	cmpl	$0x7f, %ebp
    6485:      	movl	$0x7f, %eax
    648a:      	cmovbl	%ebp, %eax
    648d:      	shll	$0x3, %eax
    6490:      	movl	%eax, (%rdi)
    6492:      	movq	%rbp, %rax
    6495:      	negq	%rax
    6498:      	movl	$0x3, %ecx
    649d:      	subq	%rbp, %rcx
    64a0:      	leal	-0x4(%rbp), %edx
    64a3:      	movq	%rdi, 0x70(%rsp)
    64a8:      	addq	$0x7, %rdi
    64ac:      	movl	$0x2, %r8d
    64b2:      	subq	%rbp, %r8
    64b5:      	leal	-0x3(%rbp), %r9d
    64b9:      	movl	$0x1, %r10d
    64bf:      	subq	%rbp, %r10
    64c2:      	leal	-0x2(%rbp), %r11d
    64c6:      	decl	%ebp
    64c8:      	xorl	%ebx, %ebx
    64ca:      	movq	0x8(%rsp), %rsi
    64cf:      	leal	(%rbx,%rbp), %r13d
    64d3:      	andl	$0xfff, %r13d           # imm = 0xFFF
    64da:      	movzbl	(%rsi,%r13), %r13d
    64df:      	movb	%r13b, -0x3(%rdi)
    64e3:      	cmpq	%rbx, %r10
    64e6:      	je	0x6540 <generic_tracepoint_arg+0x11b0>
    64e8:      	leal	(%r11,%rbx), %r13d
    64ec:      	andl	$0xfff, %r13d           # imm = 0xFFF
    64f3:      	movzbl	(%rsi,%r13), %r13d
    64f8:      	movb	%r13b, -0x2(%rdi)
    64fc:      	cmpq	%rbx, %r8
    64ff:      	je	0x6540 <generic_tracepoint_arg+0x11b0>
    6501:      	leal	(%r9,%rbx), %r13d
    6505:      	andl	$0xfff, %r13d           # imm = 0xFFF
    650c:      	movzbl	(%rsi,%r13), %r13d
    6511:      	movb	%r13b, -0x1(%rdi)
    6515:      	cmpq	%rbx, %rcx
    6518:      	je	0x6540 <generic_tracepoint_arg+0x11b0>
    651a:      	cmpq	$-0x7c, %rbx
    651e:      	je	0x6540 <generic_tracepoint_arg+0x11b0>
    6520:      	leal	(%rdx,%rbx), %r13d
    6524:      	andl	$0xfff, %r13d           # imm = 0xFFF
    652b:      	movzbl	(%rsi,%r13), %r13d
    6530:      	movb	%r13b, (%rdi)
    6533:      	addq	$-0x4, %rbx
    6537:      	addq	$0x4, %rdi
    653b:      	cmpq	%rbx, %rax
    653e:      	jne	0x64cf <generic_tracepoint_arg+0x113f>
    6540:      	movl	$0x1, %eax
    6545:      	movq	0x28(%rsp), %rdi
    654a:      	movq	0x70(%rsp), %rsi
    654f:      	jmp	0x8608 <generic_tracepoint_arg+0x3278>
    6554:      	cmpl	$0xc, %eax
    6557:      	jne	0x7651 <generic_tracepoint_arg+0x22c1>
    655d:      	movq	0x8(%rsp), %rsi
    6562:      	testl	%edx, (%rsi)
    6564:      	jne	0x5658 <generic_tracepoint_arg+0x2c8>
    656a:      	jmp	0x7651 <generic_tracepoint_arg+0x22c1>
    656f:      	movl	$0xc00, %edx            # imm = 0xC00
    6574:      	btq	%rcx, %rdx
    6578:      	jb	0x6aca <generic_tracepoint_arg+0x173a>
    657e:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
    6588:      	btq	%rcx, %rdx
    658c:      	jae	0x549d <generic_tracepoint_arg+0x10d>
    6592:      	cmpl	$0x1f, %eax
    6595:      	jne	0x7224 <generic_tracepoint_arg+0x1e94>
    659b:      	movq	0x8(%rsp), %rax
    65a0:      	movzbl	(%rax), %eax
    65a3:      	jmp	0x65d9 <generic_tracepoint_arg+0x1249>
    65a5:      	movl	$0xc00, %edx            # imm = 0xC00
    65aa:      	btq	%rcx, %rdx
    65ae:      	jb	0x6b12 <generic_tracepoint_arg+0x1782>
    65b4:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
    65be:      	btq	%rcx, %rdx
    65c2:      	jae	0x549d <generic_tracepoint_arg+0x10d>
    65c8:      	cmpl	$0x1f, %eax
    65cb:      	jne	0x7233 <generic_tracepoint_arg+0x1ea3>
    65d1:      	movq	0x8(%rsp), %rax
    65d6:      	movzwl	(%rax), %eax
    65d9:      	cmpl	%eax, 0x10(%r12)
    65de:      	ja	0x65eb <generic_tracepoint_arg+0x125b>
    65e0:      	cmpl	%eax, 0x14(%r12)
    65e5:      	jae	0x5658 <generic_tracepoint_arg+0x2c8>
    65eb:      	movl	0x8(%r12), %ecx
    65f0:      	cmpl	$0x11, %ecx
    65f3:      	jb	0x549d <generic_tracepoint_arg+0x10d>
    65f9:      	cmpl	%eax, 0x18(%r12)
    65fe:      	ja	0x660b <generic_tracepoint_arg+0x127b>
    6600:      	cmpl	%eax, 0x1c(%r12)
    6605:      	jae	0x5658 <generic_tracepoint_arg+0x2c8>
    660b:      	cmpl	$0x19, %ecx
    660e:      	jb	0x549d <generic_tracepoint_arg+0x10d>
    6614:      	cmpl	%eax, 0x20(%r12)
    6619:      	ja	0x6626 <generic_tracepoint_arg+0x1296>
    661b:      	cmpl	%eax, 0x24(%r12)
    6620:      	jae	0x5658 <generic_tracepoint_arg+0x2c8>
    6626:      	cmpl	$0x21, %ecx
    6629:      	jb	0x549d <generic_tracepoint_arg+0x10d>
    662f:      	cmpl	%eax, 0x28(%r12)
    6634:      	ja	0x549d <generic_tracepoint_arg+0x10d>
    663a:      	cmpl	%eax, 0x2c(%r12)
    663f:      	jae	0x5658 <generic_tracepoint_arg+0x2c8>
    6645:      	jmp	0x549d <generic_tracepoint_arg+0x10d>
    664a:      	cmpl	$0xc, %ecx
    664d:      	je	0x6658 <generic_tracepoint_arg+0x12c8>
    664f:      	cmpl	$0xa, %ecx
    6652:      	jne	0x7005 <generic_tracepoint_arg+0x1c75>
    6658:      	movq	0x8(%rsp), %rsi
    665d:      	cmpq	%rdx, (%rsi)
    6660:      	jg	0x5658 <generic_tracepoint_arg+0x2c8>
    6666:      	jmp	0x7023 <generic_tracepoint_arg+0x1c93>
    666b:      	movzwl	%bp, %eax
    666e:      	cmpl	$0x90, %eax
    6673:      	movq	%r11, 0x20(%rsp)
    6678:      	ja	0x6d1f <generic_tracepoint_arg+0x198f>
    667e:      	testw	%bp, %bp
    6681:      	je	0x6693 <generic_tracepoint_arg+0x1303>
    6683:      	movl	%ebp, %eax
    6685:      	movl	$0x18, %ecx
    668a:      	cltd
    668b:      	idivl	%ecx
    668d:      	movl	%ebp, %esi
    668f:      	testl	%edx, %edx
    6691:      	je	0x66b5 <generic_tracepoint_arg+0x1325>
    6693:      	movl	%ebp, %eax
    6695:      	movl	$0x18, %ecx
    669a:      	cltd
    669b:      	idivl	%ecx
    669d:      	shll	$0x3, %eax
    66a0:      	leal	(%rax,%rax,2), %eax
    66a3:      	addl	$0x18, %eax
    66a6:      	movzwl	%ax, %esi
    66a9:      	cmpl	$0x90, %esi
    66af:      	ja	0x6d33 <generic_tracepoint_arg+0x19a3>
    66b5:      	movl	%esi, %eax
    66b7:      	cltd
    66b8:      	idivl	%ecx
    66ba:      	decl	%eax
    66bc:      	jmp	0x6d44 <generic_tracepoint_arg+0x19b4>
    66c1:      	movl	0x10(%r12), %esi
    66c6:      	movl	0x14(%r12), %eax
    66cb:      	cmpl	$0xc, %ecx
    66ce:      	ja	0x74d2 <generic_tracepoint_arg+0x2142>
    66d4:      	movl	$0x1402, %edx           # imm = 0x1402
    66d9:      	btl	%ecx, %edx
    66dc:      	jae	0x74d2 <generic_tracepoint_arg+0x2142>
    66e2:      	movq	0x8(%rsp), %rdx
    66e7:      	movl	(%rdx), %edx
    66e9:      	cmpl	%edx, %esi
    66eb:      	setle	%sil
    66ef:      	cmpl	%eax, %edx
    66f1:      	setle	%al
    66f4:      	jmp	0x74e4 <generic_tracepoint_arg+0x2154>
    66f9:      	cmpl	$0x12, %eax
    66fc:      	je	0x6713 <generic_tracepoint_arg+0x1383>
    66fe:      	movl	$0x0, %ebx
    6703:      	cmpl	$0x13, %eax
    6706:      	jne	0x5642 <generic_tracepoint_arg+0x2b2>
    670c:      	movzwl	0x22(%rsi), %r13d
    6711:      	jmp	0x6718 <generic_tracepoint_arg+0x1388>
    6713:      	movzwl	0x20(%rsi), %r13d
    6718:      	xorl	%edx, %edx
    671a:      	xorl	%ebp, %ebp
    671c:      	xorl	%r8d, %r8d
    671f:      	xorl	%ebx, %ebx
    6721:      	cmpl	$0x11, %eax
    6724:      	jg	0x679e <generic_tracepoint_arg+0x140e>
    6726:      	leal	-0xd(%rax), %ecx
    6729:      	cmpl	$0x2, %ecx
    672c:      	jb	0x67d1 <generic_tracepoint_arg+0x1441>
    6732:      	leal	-0xf(%rax), %ecx
    6735:      	cmpl	$0x2, %ecx
    6738:      	jb	0x6974 <generic_tracepoint_arg+0x15e4>
    673e:      	cmpl	$0x11, %eax
    6741:      	je	0x6f7e <generic_tracepoint_arg+0x1bee>
    6747:      	jmp	0x5642 <generic_tracepoint_arg+0x2b2>
    674c:      	cmpl	$0x1c, %eax
    674f:      	je	0x6f7a <generic_tracepoint_arg+0x1bea>
    6755:      	movl	$0x0, %ebx
    675a:      	cmpl	$0x1d, %eax
    675d:      	jne	0x5642 <generic_tracepoint_arg+0x2b2>
    6763:      	cmpl	$0x7, %ecx
    6766:      	jne	0x75c2 <generic_tracepoint_arg+0x2232>
    676c:      	testq	%rdx, %rdx
    676f:      	jne	0x75ce <generic_tracepoint_arg+0x223e>
    6775:      	xorl	%ebx, %ebx
    6777:      	jmp	0x75e0 <generic_tracepoint_arg+0x2250>
    677c:      	movq	0x10(%rsi), %rdx
    6780:      	movq	0x18(%rsi), %r8
    6784:      	jmp	0x678d <generic_tracepoint_arg+0x13fd>
    6786:      	movq	(%rsi), %rdx
    6789:      	movq	0x8(%rsi), %r8
    678d:      	movq	%rdx, %rbp
    6790:      	shrq	$0x20, %rbp
    6794:      	xorl	%r13d, %r13d
    6797:      	xorl	%ebx, %ebx
    6799:      	cmpl	$0x11, %eax
    679c:      	jle	0x6726 <generic_tracepoint_arg+0x1396>
    679e:      	cmpl	$0x19, %eax
    67a1:      	ja	0x6968 <generic_tracepoint_arg+0x15d8>
    67a7:      	movl	$0x500000, %ecx         # imm = 0x500000
    67ac:      	btl	%eax, %ecx
    67af:      	jb	0x6cf9 <generic_tracepoint_arg+0x1969>
    67b5:      	movl	$0xa00000, %ecx         # imm = 0xA00000
    67ba:      	btl	%eax, %ecx
    67bd:      	jb	0x6d0c <generic_tracepoint_arg+0x197c>
    67c3:      	movl	$0x3000000, %ecx        # imm = 0x3000000
    67c8:      	btl	%eax, %ecx
    67cb:      	jae	0x6968 <generic_tracepoint_arg+0x15d8>
    67d1:      	movzwl	0x26(%rsi), %eax
    67d5:      	cmpl	$0xa, %eax
    67d8:      	je	0x6e26 <generic_tracepoint_arg+0x1a96>
    67de:      	cmpl	$0x2, %eax
    67e1:      	jne	0x6ec7 <generic_tracepoint_arg+0x1b37>
    67e7:      	movq	%rdx, %r13
    67ea:      	movq	%r11, 0x20(%rsp)
    67ef:      	movl	0x10(%r12), %eax
    67f4:      	movl	%eax, 0x34(%rsp)
    67f8:      	movl	$0x1, %eax
    67fd:      	leaq	0x34(%rsp), %rsi
    6802:      	movq	(%rip), %rdi            # 0x6809 <generic_tracepoint_arg+0x1479>
    6809:      	callq	*%rax
    680b:      	testq	%rax, %rax
    680e:      	je	0x70eb <generic_tracepoint_arg+0x1d5b>
    6814:      	movq	%rax, %rdi
    6817:      	movl	$0x20, 0x80(%rsp)
    6822:      	movl	%r13d, 0x84(%rsp)
    682a:      	jmp	0x6e85 <generic_tracepoint_arg+0x1af5>
    682f:      	cmpl	$0xc, %ecx
    6832:      	ja	0x7635 <generic_tracepoint_arg+0x22a5>
    6838:      	movl	$0x1402, %esi           # imm = 0x1402
    683d:      	btl	%ecx, %esi
    6840:      	jae	0x7635 <generic_tracepoint_arg+0x22a5>
    6846:      	movq	0x8(%rsp), %rsi
    684b:      	cmpl	%edx, (%rsi)
    684d:      	jg	0x5658 <generic_tracepoint_arg+0x2c8>
    6853:      	jmp	0x7651 <generic_tracepoint_arg+0x22c1>
    6858:      	movq	%rsi, 0x8(%rsp)
    685d:      	xorl	%ebx, %ebx
    685f:      	xorl	%r13d, %r13d
    6862:      	movq	%r11, %r15
    6865:      	movl	0x10(%r12,%rbx,4), %eax
    686a:      	movl	%eax, 0x40(%rsp)
    686e:      	movl	$0x1, %eax
    6873:      	leaq	0x40(%rsp), %rsi
    6878:      	movq	(%rip), %rdi            # 0x687f <generic_tracepoint_arg+0x14ef>
    687f:      	callq	*%rax
    6881:      	testq	%rax, %rax
    6884:      	je	0x770f <generic_tracepoint_arg+0x237f>
    688a:      	testl	%ebp, %ebp
    688c:      	movq	0x18(%rsp), %r9
    6891:      	movq	%r15, %r11
    6894:      	movq	0x68(%rsp), %r15
    6899:      	je	0x68ef <generic_tracepoint_arg+0x155f>
    689b:      	movq	0x8(%rsp), %rdx
    68a0:      	xorl	%ecx, %ecx
    68a2:      	jmp	0x68af <generic_tracepoint_arg+0x151f>
    68a4:      	incq	%rcx
    68a7:      	incq	%rdx
    68aa:      	cmpq	%rbp, %rcx
    68ad:      	je	0x68ef <generic_tracepoint_arg+0x155f>
    68af:      	xorl	%esi, %esi
    68b1:      	nopw	%cs:(%rax,%rax)
    68c0:      	leaq	(%rcx,%rsi), %rdi
    68c4:      	cmpq	%rbp, %rdi
    68c7:      	jae	0x68a4 <generic_tracepoint_arg+0x1514>
    68c9:      	movzbl	(%rax,%rsi), %edi
    68cd:      	testb	%dil, %dil
    68d0:      	je	0x68e7 <generic_tracepoint_arg+0x1557>
    68d2:      	cmpq	$0x62, %rsi
    68d6:      	ja	0x68a4 <generic_tracepoint_arg+0x1514>
    68d8:      	leaq	0x1(%rsi), %r8
    68dc:      	cmpb	%dil, (%rdx,%rsi)
    68e0:      	movq	%r8, %rsi
    68e3:      	je	0x68c0 <generic_tracepoint_arg+0x1530>
    68e5:      	jmp	0x68a4 <generic_tracepoint_arg+0x1514>
    68e7:      	testl	%ecx, %ecx
    68e9:      	jns	0x79f5 <generic_tracepoint_arg+0x2665>
    68ef:      	leal	0xc(%r13), %eax
    68f3:      	cmpl	0x8(%r12), %eax
    68f8:      	jae	0x690b <generic_tracepoint_arg+0x157b>
    68fa:      	addl	$0x4, %r13d
    68fe:      	incq	%rbx
    6901:      	cmpq	$0x64, %rbx
    6905:      	jne	0x6862 <generic_tracepoint_arg+0x14d2>
    690b:      	xorl	%ebx, %ebx
    690d:      	jmp	0x79fa <generic_tracepoint_arg+0x266a>
    6912:      	movzwl	%bp, %eax
    6915:      	cmpl	$0x90, %eax
    691a:      	movq	%r11, 0x20(%rsp)
    691f:      	ja	0x70fb <generic_tracepoint_arg+0x1d6b>
    6925:      	testw	%bp, %bp
    6928:      	je	0x693a <generic_tracepoint_arg+0x15aa>
    692a:      	movl	%ebp, %eax
    692c:      	movl	$0x18, %ecx
    6931:      	cltd
    6932:      	idivl	%ecx
    6934:      	movl	%ebp, %edi
    6936:      	testl	%edx, %edx
    6938:      	je	0x695c <generic_tracepoint_arg+0x15cc>
    693a:      	movl	%ebp, %eax
    693c:      	movl	$0x18, %ecx
    6941:      	cltd
    6942:      	idivl	%ecx
    6944:      	shll	$0x3, %eax
    6947:      	leal	(%rax,%rax,2), %eax
    694a:      	addl	$0x18, %eax
    694d:      	movzwl	%ax, %edi
    6950:      	cmpl	$0x90, %edi
    6956:      	ja	0x710f <generic_tracepoint_arg+0x1d7f>
    695c:      	movl	%edi, %eax
    695e:      	cltd
    695f:      	idivl	%ecx
    6961:      	decl	%eax
    6963:      	jmp	0x7120 <generic_tracepoint_arg+0x1d90>
    6968:      	addl	$-0x12, %eax
    696b:      	cmpl	$0x2, %eax
    696e:      	jae	0x5642 <generic_tracepoint_arg+0x2b2>
    6974:      	movq	%r11, %rbp
    6977:      	movzbl	0x10(%r12), %eax
    697d:      	movl	%eax, 0x34(%rsp)
    6981:      	movl	$0x1, %eax
    6986:      	movq	(%rip), %rdi            # 0x698d <generic_tracepoint_arg+0x15fd>
    698d:      	leaq	0x34(%rsp), %rsi
    6992:      	callq	*%rax
    6994:      	testq	%rax, %rax
    6997:      	je	0x6c9a <generic_tracepoint_arg+0x190a>
    699d:      	movq	%rax, %rdi
    69a0:      	movzwl	%r13w, %eax
    69a4:      	movq	%rax, 0x80(%rsp)
    69ac:      	movl	$0x1, %eax
    69b1:      	movq	0x38(%rsp), %rsi
    69b6:      	callq	*%rax
    69b8:      	movl	0x4(%r12), %edx
    69bd:      	xorl	%ecx, %ecx
    69bf:      	cmpl	$0x1d, %edx
    69c2:      	ja	0x8039 <generic_tracepoint_arg+0x2ca9>
    69c8:      	movl	$0x30038400, %esi       # imm = 0x30038400
    69cd:      	btl	%edx, %esi
    69d0:      	movq	0x10(%rsp), %rdi
    69d5:      	movq	0x18(%rsp), %r9
    69da:      	movq	%rbp, %r11
    69dd:      	jb	0x5639 <generic_tracepoint_arg+0x2a9>
    69e3:      	jmp	0x6fec <generic_tracepoint_arg+0x1c5c>
    69e8:      	cmpl	$0x21, %eax
    69eb:      	je	0x72b8 <generic_tracepoint_arg+0x1f28>
    69f1:      	movl	$0x0, %ebx
    69f6:      	cmpl	$0x22, %eax
    69f9:      	jne	0x8625 <generic_tracepoint_arg+0x3295>
    69ff:      	movl	$0x10, %r13d
    6a05:      	movq	%r11, %r15
    6a08:      	movl	(%r12,%r13), %eax
    6a0c:      	movl	%eax, 0x40(%rsp)
    6a10:      	movl	$0x1, %eax
    6a15:      	leaq	0x40(%rsp), %rsi
    6a1a:      	movq	(%rip), %rdi            # 0x6a21 <generic_tracepoint_arg+0x1691>
    6a21:      	callq	*%rax
    6a23:      	testq	%rax, %rax
    6a26:      	je	0x7d22 <generic_tracepoint_arg+0x2992>
    6a2c:      	movq	0x8(%rsp), %rdi
    6a31:      	movq	%rax, %rsi
    6a34:      	movq	%rbp, %rdx
    6a37:      	callq	0x6a3c <generic_tracepoint_arg+0x16ac>
    6a3c:      	testl	%eax, %eax
    6a3e:      	jns	0x7d26 <generic_tracepoint_arg+0x2996>
    6a44:      	addq	$0x4, %r13
    6a48:      	leal	-0x8(%r13), %eax
    6a4c:      	cmpl	0x8(%r12), %eax
    6a51:      	movq	0x10(%rsp), %rdi
    6a56:      	movq	0x18(%rsp), %r9
    6a5b:      	movq	%r15, %r11
    6a5e:      	jae	0x7dd2 <generic_tracepoint_arg+0x2a42>
    6a64:      	movl	$0x0, %ebx
    6a69:      	cmpq	$0x1a0, %r13            # imm = 0x1A0
    6a70:      	movq	0x68(%rsp), %r15
    6a75:      	jne	0x6a05 <generic_tracepoint_arg+0x1675>
    6a77:      	jmp	0x8625 <generic_tracepoint_arg+0x3295>
    6a7c:      	cmpl	$0x1, %eax
    6a7f:      	je	0x73bd <generic_tracepoint_arg+0x202d>
    6a85:      	cmpl	$0x2, %eax
    6a88:      	jne	0x73cd <generic_tracepoint_arg+0x203d>
    6a8e:      	movq	0x8(%rsp), %rdx
    6a93:      	movzbl	(%rdx), %edx
    6a96:      	cmpl	%edx, %ecx
    6a98:      	ja	0x5658 <generic_tracepoint_arg+0x2c8>
    6a9e:      	jmp	0x73cd <generic_tracepoint_arg+0x203d>
    6aa3:      	cmpl	$0x1, %eax
    6aa6:      	je	0x740a <generic_tracepoint_arg+0x207a>
    6aac:      	cmpl	$0x2, %eax
    6aaf:      	jne	0x741a <generic_tracepoint_arg+0x208a>
    6ab5:      	movq	0x8(%rsp), %rdx
    6aba:      	movzwl	(%rdx), %edx
    6abd:      	cmpl	%edx, %ecx
    6abf:      	ja	0x5658 <generic_tracepoint_arg+0x2c8>
    6ac5:      	jmp	0x741a <generic_tracepoint_arg+0x208a>
    6aca:      	movq	%r11, %rbp
    6acd:      	movzbl	0x10(%r12), %eax
    6ad3:      	movl	%eax, 0x80(%rsp)
    6ada:      	movl	$0x1, %eax
    6adf:      	movq	0x38(%rsp), %rsi
    6ae4:      	movq	(%rip), %rdi            # 0x6aeb <generic_tracepoint_arg+0x175b>
    6aeb:      	callq	*%rax
    6aed:      	testq	%rax, %rax
    6af0:      	je	0x6b8b <generic_tracepoint_arg+0x17fb>
    6af6:      	movq	%rax, %rdi
    6af9:      	movq	0x8(%rsp), %rax
    6afe:      	movzbl	(%rax), %eax
    6b01:      	movq	%rax, 0x40(%rsp)
    6b06:      	movl	$0x1, %eax
    6b0b:      	leaq	0x40(%rsp), %rsi
    6b10:      	jmp	0x6b54 <generic_tracepoint_arg+0x17c4>
    6b12:      	movq	%r11, %rbp
    6b15:      	movzbl	0x10(%r12), %eax
    6b1b:      	movl	%eax, 0x80(%rsp)
    6b22:      	movl	$0x1, %eax
    6b27:      	movq	0x38(%rsp), %rsi
    6b2c:      	movq	(%rip), %rdi            # 0x6b33 <generic_tracepoint_arg+0x17a3>
    6b33:      	callq	*%rax
    6b35:      	testq	%rax, %rax
    6b38:      	je	0x6b8b <generic_tracepoint_arg+0x17fb>
    6b3a:      	movq	%rax, %rdi
    6b3d:      	movq	0x8(%rsp), %rax
    6b42:      	movzwl	(%rax), %eax
    6b45:      	movq	%rax, 0x40(%rsp)
    6b4a:      	movl	$0x1, %eax
    6b4f:      	leaq	0x40(%rsp), %rsi
    6b54:      	callq	*%rax
    6b56:      	movl	0x4(%r12), %edx
    6b5b:      	xorl	%ecx, %ecx
    6b5d:      	cmpl	$0x1d, %edx
    6b60:      	ja	0x7c83 <generic_tracepoint_arg+0x28f3>
    6b66:      	movl	$0x30038400, %esi       # imm = 0x30038400
    6b6b:      	btl	%edx, %esi
    6b6e:      	movq	0x10(%rsp), %rdi
    6b73:      	movq	0x18(%rsp), %r9
    6b78:      	movq	%rbp, %r11
    6b7b:      	jae	0x6b9f <generic_tracepoint_arg+0x180f>
    6b7d:      	testq	%rax, %rax
    6b80:      	setne	%cl
    6b83:      	movzbl	%cl, %ebx
    6b86:      	jmp	0x5647 <generic_tracepoint_arg+0x2b7>
    6b8b:      	xorl	%ebx, %ebx
    6b8d:      	movq	0x10(%rsp), %rdi
    6b92:      	movq	0x18(%rsp), %r9
    6b97:      	movq	%rbp, %r11
    6b9a:      	jmp	0x5647 <generic_tracepoint_arg+0x2b7>
    6b9f:      	movl	$0xc0800, %esi          # imm = 0xC0800
    6ba4:      	btl	%edx, %esi
    6ba7:      	jae	0x6baf <generic_tracepoint_arg+0x181f>
    6ba9:      	testq	%rax, %rax
    6bac:      	sete	%cl
    6baf:      	movzbl	%cl, %ebx
    6bb2:      	jmp	0x5647 <generic_tracepoint_arg+0x2b7>
    6bb7:      	testq	%rax, %rax
    6bba:      	sete	%al
    6bbd:      	movq	0x10(%rsp), %rdi
    6bc2:      	movq	0x18(%rsp), %r9
    6bc7:      	movq	%rbp, %r11
    6bca:      	movzbl	%al, %ebx
    6bcd:      	jmp	0x5647 <generic_tracepoint_arg+0x2b7>
    6bd2:      	xorl	%eax, %eax
    6bd4:      	movzbl	%al, %ebx
    6bd7:      	jmp	0x5647 <generic_tracepoint_arg+0x2b7>
    6bdc:      	movq	%r11, 0x20(%rsp)
    6be1:      	movl	0x10(%r12), %eax
    6be6:      	movl	%eax, 0x40(%rsp)
    6bea:      	movl	$0x0, 0x80(%rsp)
    6bf5:      	movl	$0x1, %eax
    6bfa:      	leaq	0x40(%rsp), %rsi
    6bff:      	movq	(%rip), %rdi            # 0x6c06 <generic_tracepoint_arg+0x1876>
    6c06:      	callq	*%rax
    6c08:      	testl	%ebp, %ebp
    6c0a:      	je	0x8614 <generic_tracepoint_arg+0x3284>
    6c10:      	movq	%rax, %r13
    6c13:      	movl	$0x0, %ebx
    6c18:      	testq	%rax, %rax
    6c1b:      	je	0x8616 <generic_tracepoint_arg+0x3286>
    6c21:      	movl	$0x1, %eax
    6c26:      	movq	0x38(%rsp), %rsi
    6c2b:      	movq	(%rip), %rdi            # 0x6c32 <generic_tracepoint_arg+0x18a2>
    6c32:      	callq	*%rax
    6c34:      	testq	%rax, %rax
    6c37:      	je	0x8614 <generic_tracepoint_arg+0x3284>
    6c3d:      	cmpl	$0xff, %ebp
    6c43:      	movl	$0xff, %ecx
    6c48:      	cmovael	%ecx, %ebp
    6c4b:      	leal	(,%rbp,8), %ecx
    6c52:      	movl	%ecx, (%rax)
    6c54:      	movq	%rax, %rdi
    6c57:      	addq	$0x4, %rdi
    6c5b:      	movq	%rax, %rbx
    6c5e:      	movl	$0x4, %eax
    6c63:      	movq	0x8(%rsp), %rdx
    6c68:      	movl	%ebp, %esi
    6c6a:      	callq	*%rax
    6c6c:      	movl	$0x1, %eax
    6c71:      	movq	%r13, %rdi
    6c74:      	movq	%rbx, %rsi
    6c77:      	jmp	0x8608 <generic_tracepoint_arg+0x3278>
    6c7c:      	movl	$0x0, 0x80(%rsp)
    6c87:      	cmpl	$0x1fe, %ebp            # imm = 0x1FE
    6c8d:      	jbe	0x7367 <generic_tracepoint_arg+0x1fd7>
    6c93:      	xorl	%ebx, %ebx
    6c95:      	jmp	0x8625 <generic_tracepoint_arg+0x3295>
    6c9a:      	xorl	%ebx, %ebx
    6c9c:      	movq	0x10(%rsp), %rdi
    6ca1:      	movq	0x18(%rsp), %r9
    6ca6:      	movq	%rbp, %r11
    6ca9:      	jmp	0x5642 <generic_tracepoint_arg+0x2b2>
    6cae:      	cmpl	$0x1e, %eax
    6cb1:      	jne	0x549d <generic_tracepoint_arg+0x10d>
    6cb7:      	movl	0x10(%r12), %eax
    6cbc:      	andl	$0x7, %eax
    6cbf:      	movl	%eax, %ecx
    6cc1:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
    6cca:      	jne	0x549d <generic_tracepoint_arg+0x10d>
    6cd0:      	movq	0x8(%rsp), %rcx
    6cd5:      	movq	(%rcx), %rcx
    6cd8:      	movq	0x5e78(%r14,%rax,8), %rax
    6ce0:      	andl	$0x7ff, %eax            # imm = 0x7FF
    6ce5:      	xorl	%ebx, %ebx
    6ce7:      	andnq	0x90(%r14,%rax), %rcx, %rax
    6cf1:      	setne	%bl
    6cf4:      	jmp	0x5647 <generic_tracepoint_arg+0x2b7>
    6cf9:      	movzwl	%r13w, %eax
    6cfd:      	xorl	%ebx, %ebx
    6cff:      	cmpl	$0x400, %eax            # imm = 0x400
    6d04:      	setb	%bl
    6d07:      	jmp	0x5642 <generic_tracepoint_arg+0x2b2>
    6d0c:      	movzwl	%r13w, %eax
    6d10:      	xorl	%ebx, %ebx
    6d12:      	cmpl	$0x400, %eax            # imm = 0x400
    6d17:      	setae	%bl
    6d1a:      	jmp	0x5642 <generic_tracepoint_arg+0x2b2>
    6d1f:      	cmpl	$0x101, %eax            # imm = 0x101
    6d24:      	movl	$0x100, %esi            # imm = 0x100
    6d29:      	movl	$0x1fe, %eax            # imm = 0x1FE
    6d2e:      	cmovael	%eax, %esi
    6d31:      	movl	%esi, %eax
    6d33:      	movzwl	%ax, %ecx
    6d36:      	xorl	%eax, %eax
    6d38:      	cmpl	$0x100, %ecx            # imm = 0x100
    6d3e:      	sete	%al
    6d41:      	xorl	$0x7, %eax
    6d44:      	movl	%eax, %ecx
    6d46:      	andl	$0xf, %ecx
    6d49:      	movl	0x10(%r12,%rcx,4), %ecx
    6d4e:      	cmpl	$-0x1, %ecx
    6d51:      	je	0x8169 <generic_tracepoint_arg+0x2dd9>
    6d57:      	movl	%ecx, 0xa0(%rsp)
    6d5e:      	movq	%rsi, 0x98(%rsp)
    6d66:      	movl	%eax, 0x70(%rsp)
    6d6a:      	movl	$0x1, %eax
    6d6f:      	movq	(%rip), %rdi            # 0x6d76 <generic_tracepoint_arg+0x19e6>
    6d76:      	movq	0x38(%rsp), %rbx
    6d7b:      	movq	%rbx, %rsi
    6d7e:      	callq	*%rax
    6d80:      	movq	%rax, 0x28(%rsp)
    6d85:      	movl	$0x1, %eax
    6d8a:      	movq	(%rip), %rdi            # 0x6d91 <generic_tracepoint_arg+0x1a01>
    6d91:      	movq	%rbx, %rsi
    6d94:      	callq	*%rax
    6d96:      	cmpq	$0x0, 0x28(%rsp)
    6d9c:      	je	0x8169 <generic_tracepoint_arg+0x2dd9>
    6da2:      	movl	$0x0, %ebx
    6da7:      	testq	%rax, %rax
    6daa:      	movq	0x10(%rsp), %rdi
    6daf:      	movq	0x18(%rsp), %r9
    6db4:      	movq	0x20(%rsp), %r11
    6db9:      	je	0x817a <generic_tracepoint_arg+0x2dea>
    6dbf:      	movq	%rax, 0xa8(%rsp)
    6dc7:      	movq	0x8(%rsp), %rdx
    6dcc:      	addq	$0x4, %rdx
    6dd0:      	movl	0x70(%rsp), %ebx
    6dd4:      	cmpl	$0x5, %ebx
    6dd7:      	jg	0x7780 <generic_tracepoint_arg+0x23f0>
    6ddd:      	movq	0x28(%rsp), %rax
    6de2:      	movb	%bpl, (%rax)
    6de5:      	leaq	0x1(%rax), %rdi
    6de9:      	movl	$0x4, %eax
    6dee:      	movl	%ebp, %esi
    6df0:      	callq	*%rax
    6df2:      	movq	0x98(%rsp), %rsi
    6dfa:      	subl	%ebp, %esi
    6dfc:      	jbe	0x77c3 <generic_tracepoint_arg+0x2433>
    6e02:      	movq	0x28(%rsp), %rax
    6e07:      	leaq	(%rax,%rbp), %rdi
    6e0b:      	incq	%rdi
    6e0e:      	andl	$0xfff, %esi            # imm = 0xFFF
    6e14:      	movl	$0x4, %eax
    6e19:      	movq	0xa8(%rsp), %rdx
    6e21:      	jmp	0x77c1 <generic_tracepoint_arg+0x2431>
    6e26:      	movq	%r8, %rbx
    6e29:      	movq	%rdx, %r13
    6e2c:      	movq	%r11, 0x20(%rsp)
    6e31:      	movl	0x14(%r12), %eax
    6e36:      	movl	%eax, 0x34(%rsp)
    6e3a:      	movl	$0x1, %eax
    6e3f:      	movq	(%rip), %rdi            # 0x6e46 <generic_tracepoint_arg+0x1ab6>
    6e46:      	leaq	0x34(%rsp), %rsi
    6e4b:      	callq	*%rax
    6e4d:      	testq	%rax, %rax
    6e50:      	je	0x70eb <generic_tracepoint_arg+0x1d5b>
    6e56:      	movq	%rax, %rdi
    6e59:      	movl	$0x80, 0x80(%rsp)
    6e64:      	movl	%r13d, 0x84(%rsp)
    6e6c:      	movl	%ebp, 0x88(%rsp)
    6e73:      	movl	%ebx, 0x8c(%rsp)
    6e7a:      	shrq	$0x20, %rbx
    6e7e:      	movl	%ebx, 0x90(%rsp)
    6e85:      	movl	$0x1, %eax
    6e8a:      	movq	0x38(%rsp), %rsi
    6e8f:      	callq	*%rax
    6e91:      	movl	0x4(%r12), %ecx
    6e96:      	leal	-0x18(%rcx), %edx
    6e99:      	cmpl	$0x2, %edx
    6e9c:      	jb	0x7457 <generic_tracepoint_arg+0x20c7>
    6ea2:      	addl	$-0xd, %ecx
    6ea5:      	cmpl	$0x1, %ecx
    6ea8:      	movq	0x10(%rsp), %rdi
    6ead:      	movq	0x18(%rsp), %r9
    6eb2:      	movq	0x20(%rsp), %r11
    6eb7:      	ja	0x6ec7 <generic_tracepoint_arg+0x1b37>
    6eb9:      	testq	%rax, %rax
    6ebc:      	setne	%al
    6ebf:      	movzbl	%al, %ebx
    6ec2:      	jmp	0x5642 <generic_tracepoint_arg+0x2b2>
    6ec7:      	xorl	%eax, %eax
    6ec9:      	movzbl	%al, %ebx
    6ecc:      	jmp	0x5642 <generic_tracepoint_arg+0x2b2>
    6ed1:      	movq	0x8(%rsp), %rax
    6ed6:      	movq	(%rax), %rax
    6ed9:      	cmpq	%rax, %rsi
    6edc:      	ja	0x6ee7 <generic_tracepoint_arg+0x1b57>
    6ede:      	cmpq	%rdx, %rax
    6ee1:      	jbe	0x5658 <generic_tracepoint_arg+0x2c8>
    6ee7:      	movl	0x8(%r12), %edx
    6eec:      	cmpl	$0x19, %edx
    6eef:      	jb	0x549d <generic_tracepoint_arg+0x10d>
    6ef5:      	movq	0x20(%r12), %rdi
    6efa:      	movq	0x28(%r12), %rsi
    6eff:      	cmpl	$0xc, %ecx
    6f02:      	je	0x6f0d <generic_tracepoint_arg+0x1b7d>
    6f04:      	cmpl	$0xa, %ecx
    6f07:      	jne	0x7572 <generic_tracepoint_arg+0x21e2>
    6f0d:      	cmpq	%rax, %rdi
    6f10:      	movq	0x10(%rsp), %rdi
    6f15:      	jg	0x7585 <generic_tracepoint_arg+0x21f5>
    6f1b:      	cmpq	%rsi, %rax
    6f1e:      	jle	0x5658 <generic_tracepoint_arg+0x2c8>
    6f24:      	jmp	0x7585 <generic_tracepoint_arg+0x21f5>
    6f29:      	movq	0x8(%rsp), %rdx
    6f2e:      	movq	(%rdx), %rdx
    6f31:      	cmpq	%rdx, %rsi
    6f34:      	setbe	%sil
    6f38:      	cmpq	%rax, %rdx
    6f3b:      	setbe	%al
    6f3e:      	andb	%sil, %al
    6f41:      	movl	0x8(%r12), %esi
    6f46:      	cmpl	$0x19, %esi
    6f49:      	jb	0x81b9 <generic_tracepoint_arg+0x2e29>
    6f4f:      	movq	0x20(%r12), %r8
    6f54:      	movq	0x28(%r12), %rdi
    6f59:      	cmpl	$0xc, %ecx
    6f5c:      	je	0x6f67 <generic_tracepoint_arg+0x1bd7>
    6f5e:      	cmpl	$0xa, %ecx
    6f61:      	jne	0x752a <generic_tracepoint_arg+0x219a>
    6f67:      	cmpq	%rdx, %r8
    6f6a:      	setle	%r8b
    6f6e:      	cmpq	%rdi, %rdx
    6f71:      	setle	%dil
    6f75:      	jmp	0x7538 <generic_tracepoint_arg+0x21a8>
    6f7a:      	movzwl	0x26(%rsi), %ebx
    6f7e:      	movq	%r11, %r13
    6f81:      	movzbl	0x10(%r12), %eax
    6f87:      	movl	%eax, 0x34(%rsp)
    6f8b:      	movl	$0x1, %eax
    6f90:      	movq	(%rip), %rdi            # 0x6f97 <generic_tracepoint_arg+0x1c07>
    6f97:      	leaq	0x34(%rsp), %rsi
    6f9c:      	callq	*%rax
    6f9e:      	testq	%rax, %rax
    6fa1:      	je	0x7621 <generic_tracepoint_arg+0x2291>
    6fa7:      	movq	%rax, %rdi
    6faa:      	movzwl	%bx, %eax
    6fad:      	movq	%rax, 0x80(%rsp)
    6fb5:      	movl	$0x1, %eax
    6fba:      	movq	0x38(%rsp), %rsi
    6fbf:      	callq	*%rax
    6fc1:      	movl	0x4(%r12), %edx
    6fc6:      	xorl	%ecx, %ecx
    6fc8:      	cmpl	$0x1d, %edx
    6fcb:      	ja	0x7fca <generic_tracepoint_arg+0x2c3a>
    6fd1:      	movl	$0x30038400, %esi       # imm = 0x30038400
    6fd6:      	btl	%edx, %esi
    6fd9:      	movq	0x10(%rsp), %rdi
    6fde:      	movq	0x18(%rsp), %r9
    6fe3:      	movq	%r13, %r11
    6fe6:      	jb	0x5639 <generic_tracepoint_arg+0x2a9>
    6fec:      	movl	$0xc0800, %esi          # imm = 0xC0800
    6ff1:      	btl	%edx, %esi
    6ff4:      	jae	0x563f <generic_tracepoint_arg+0x2af>
    6ffa:      	testq	%rax, %rax
    6ffd:      	sete	%cl
    7000:      	jmp	0x563f <generic_tracepoint_arg+0x2af>
    7005:      	movq	0x8(%rsp), %rsi
    700a:      	cmpq	%rdx, (%rsi)
    700d:      	ja	0x5658 <generic_tracepoint_arg+0x2c8>
    7013:      	jmp	0x7023 <generic_tracepoint_arg+0x1c93>
    7015:      	movq	0x8(%rsp), %rsi
    701a:      	cmpq	%rdx, (%rsi)
    701d:      	jb	0x5658 <generic_tracepoint_arg+0x2c8>
    7023:      	movl	0x8(%r12), %edx
    7028:      	cmpl	$0x11, %edx
    702b:      	jb	0x86da <generic_tracepoint_arg+0x334a>
    7031:      	movq	0x18(%r12), %rsi
    7036:      	cmpl	$0x2, %eax
    7039:      	jle	0x705b <generic_tracepoint_arg+0x1ccb>
    703b:      	leal	-0x3(%rax), %edi
    703e:      	cmpl	$0x2, %edi
    7041:      	jae	0x708e <generic_tracepoint_arg+0x1cfe>
    7043:      	movq	0x8(%rsp), %rdi
    7048:      	cmpq	%rsi, (%rdi)
    704b:      	movq	0x10(%rsp), %rdi
    7050:      	jne	0x7bc0 <generic_tracepoint_arg+0x2830>
    7056:      	jmp	0x85b1 <generic_tracepoint_arg+0x3221>
    705b:      	cmpl	$0x1, %eax
    705e:      	je	0x7203 <generic_tracepoint_arg+0x1e73>
    7064:      	cmpl	$0x2, %eax
    7067:      	jne	0x7bc0 <generic_tracepoint_arg+0x2830>
    706d:      	cmpl	$0xc, %ecx
    7070:      	je	0x707b <generic_tracepoint_arg+0x1ceb>
    7072:      	cmpl	$0xa, %ecx
    7075:      	jne	0x7bb2 <generic_tracepoint_arg+0x2822>
    707b:      	movq	0x8(%rsp), %r8
    7080:      	cmpq	%rsi, (%r8)
    7083:      	jl	0x5658 <generic_tracepoint_arg+0x2c8>
    7089:      	jmp	0x7bc0 <generic_tracepoint_arg+0x2830>
    708e:      	cmpl	$0xc, %eax
    7091:      	movq	0x10(%rsp), %rdi
    7096:      	jne	0x7bc0 <generic_tracepoint_arg+0x2830>
    709c:      	movq	0x8(%rsp), %r8
    70a1:      	testq	%rsi, (%r8)
    70a4:      	jne	0x5658 <generic_tracepoint_arg+0x2c8>
    70aa:      	jmp	0x7bc0 <generic_tracepoint_arg+0x2830>
    70af:      	cmpl	$0xc, %eax
    70b2:      	jne	0x73cd <generic_tracepoint_arg+0x203d>
    70b8:      	movq	0x8(%rsp), %rdx
    70bd:      	movzbl	(%rdx), %edx
    70c0:      	testl	%edx, %ecx
    70c2:      	jne	0x5658 <generic_tracepoint_arg+0x2c8>
    70c8:      	jmp	0x73cd <generic_tracepoint_arg+0x203d>
    70cd:      	cmpl	$0xc, %eax
    70d0:      	jne	0x741a <generic_tracepoint_arg+0x208a>
    70d6:      	movq	0x8(%rsp), %rdx
    70db:      	movzwl	(%rdx), %edx
    70de:      	testl	%edx, %ecx
    70e0:      	jne	0x5658 <generic_tracepoint_arg+0x2c8>
    70e6:      	jmp	0x741a <generic_tracepoint_arg+0x208a>
    70eb:      	movl	0x4(%r12), %eax
    70f0:      	andl	$-0x2, %eax
    70f3:      	cmpl	$0x18, %eax
    70f6:      	jmp	0x745a <generic_tracepoint_arg+0x20ca>
    70fb:      	cmpl	$0x101, %eax            # imm = 0x101
    7100:      	movl	$0x100, %edi            # imm = 0x100
    7105:      	movl	$0x1fe, %eax            # imm = 0x1FE
    710a:      	cmovael	%eax, %edi
    710d:      	movl	%edi, %eax
    710f:      	movzwl	%ax, %ecx
    7112:      	xorl	%eax, %eax
    7114:      	cmpl	$0x100, %ecx            # imm = 0x100
    711a:      	sete	%al
    711d:      	xorl	$0x7, %eax
    7120:      	movl	%eax, %ecx
    7122:      	andl	$0xf, %ecx
    7125:      	movl	0x10(%r12,%rcx,4), %ecx
    712a:      	cmpl	$-0x1, %ecx
    712d:      	je	0x8346 <generic_tracepoint_arg+0x2fb6>
    7133:      	movl	%ecx, 0xa0(%rsp)
    713a:      	movq	%rdi, 0x98(%rsp)
    7142:      	movl	%eax, 0x70(%rsp)
    7146:      	movq	%rsi, 0x8(%rsp)
    714b:      	movl	$0x1, %eax
    7150:      	movq	(%rip), %rdi            # 0x7157 <generic_tracepoint_arg+0x1dc7>
    7157:      	movq	0x38(%rsp), %rbx
    715c:      	movq	%rbx, %rsi
    715f:      	callq	*%rax
    7161:      	movq	%rax, 0x28(%rsp)
    7166:      	movl	$0x1, %eax
    716b:      	movq	(%rip), %rdi            # 0x7172 <generic_tracepoint_arg+0x1de2>
    7172:      	movq	%rbx, %rsi
    7175:      	callq	*%rax
    7177:      	cmpq	$0x0, 0x28(%rsp)
    717d:      	je	0x8346 <generic_tracepoint_arg+0x2fb6>
    7183:      	movl	$0x0, %ebx
    7188:      	testq	%rax, %rax
    718b:      	movq	0x10(%rsp), %rdi
    7190:      	movq	0x18(%rsp), %r9
    7195:      	movq	0x20(%rsp), %r11
    719a:      	je	0x8357 <generic_tracepoint_arg+0x2fc7>
    71a0:      	movq	%rax, 0xa8(%rsp)
    71a8:      	movl	0x70(%rsp), %ebx
    71ac:      	cmpl	$0x5, %ebx
    71af:      	jg	0x7a8a <generic_tracepoint_arg+0x26fa>
    71b5:      	movq	0x28(%rsp), %rax
    71ba:      	movb	%bpl, (%rax)
    71bd:      	leaq	0x1(%rax), %rdi
    71c1:      	movl	$0x4, %eax
    71c6:      	movq	0x8(%rsp), %rdx
    71cb:      	movl	%ebp, %esi
    71cd:      	callq	*%rax
    71cf:      	movq	0x98(%rsp), %rsi
    71d7:      	subl	%ebp, %esi
    71d9:      	jbe	0x7ad2 <generic_tracepoint_arg+0x2742>
    71df:      	movq	0x28(%rsp), %rax
    71e4:      	leaq	(%rax,%rbp), %rdi
    71e8:      	incq	%rdi
    71eb:      	andl	$0xfff, %esi            # imm = 0xFFF
    71f1:      	movl	$0x4, %eax
    71f6:      	movq	0xa8(%rsp), %rdx
    71fe:      	jmp	0x7ad0 <generic_tracepoint_arg+0x2740>
    7203:      	cmpl	$0xc, %ecx
    7206:      	je	0x7211 <generic_tracepoint_arg+0x1e81>
    7208:      	cmpl	$0xa, %ecx
    720b:      	jne	0x7ba2 <generic_tracepoint_arg+0x2812>
    7211:      	movq	0x8(%rsp), %r8
    7216:      	cmpq	%rsi, (%r8)
    7219:      	jg	0x5658 <generic_tracepoint_arg+0x2c8>
    721f:      	jmp	0x7bc0 <generic_tracepoint_arg+0x2830>
    7224:      	movl	0x8(%r12), %edx
    7229:      	movq	0x8(%rsp), %rax
    722e:      	movzbl	(%rax), %ecx
    7231:      	jmp	0x7240 <generic_tracepoint_arg+0x1eb0>
    7233:      	movl	0x8(%r12), %edx
    7238:      	movq	0x8(%rsp), %rax
    723d:      	movzwl	(%rax), %ecx
    7240:      	cmpl	%ecx, 0x10(%r12)
    7245:      	setbe	%sil
    7249:      	cmpl	%ecx, 0x14(%r12)
    724e:      	setae	%al
    7251:      	andb	%sil, %al
    7254:      	cmpl	$0x11, %edx
    7257:      	jb	0x81b9 <generic_tracepoint_arg+0x2e29>
    725d:      	cmpl	%ecx, 0x18(%r12)
    7262:      	setbe	%sil
    7266:      	cmpl	%ecx, 0x1c(%r12)
    726b:      	setae	%dil
    726f:      	andb	%sil, %dil
    7272:      	orb	%dil, %al
    7275:      	cmpl	$0x19, %edx
    7278:      	jb	0x81b4 <generic_tracepoint_arg+0x2e24>
    727e:      	cmpl	%ecx, 0x20(%r12)
    7283:      	setbe	%sil
    7287:      	cmpl	%ecx, 0x24(%r12)
    728c:      	setae	%dil
    7290:      	andb	%sil, %dil
    7293:      	orb	%dil, %al
    7296:      	cmpl	$0x21, %edx
    7299:      	jb	0x81b4 <generic_tracepoint_arg+0x2e24>
    729f:      	cmpl	%ecx, 0x28(%r12)
    72a4:      	setbe	%dl
    72a7:      	cmpl	%ecx, 0x2c(%r12)
    72ac:      	setae	%cl
    72af:      	andb	%dl, %cl
    72b1:      	orb	%cl, %al
    72b3:      	jmp	0x81b4 <generic_tracepoint_arg+0x2e24>
    72b8:      	xorl	%ebx, %ebx
    72ba:      	xorl	%r13d, %r13d
    72bd:      	movq	%r11, %r15
    72c0:      	movl	0x10(%r12,%rbx,4), %eax
    72c5:      	movl	%eax, 0x40(%rsp)
    72c9:      	movl	$0x1, %eax
    72ce:      	leaq	0x40(%rsp), %rsi
    72d3:      	movq	(%rip), %rdi            # 0x72da <generic_tracepoint_arg+0x1f4a>
    72da:      	callq	*%rax
    72dc:      	testq	%rax, %rax
    72df:      	je	0x7cb9 <generic_tracepoint_arg+0x2929>
    72e5:      	testl	%ebp, %ebp
    72e7:      	movq	0x18(%rsp), %r9
    72ec:      	movq	%r15, %r11
    72ef:      	movq	0x68(%rsp), %r15
    72f4:      	je	0x733f <generic_tracepoint_arg+0x1faf>
    72f6:      	movq	0x8(%rsp), %rdx
    72fb:      	xorl	%ecx, %ecx
    72fd:      	jmp	0x730a <generic_tracepoint_arg+0x1f7a>
    72ff:      	incq	%rcx
    7302:      	incq	%rdx
    7305:      	cmpq	%rbp, %rcx
    7308:      	je	0x733f <generic_tracepoint_arg+0x1faf>
    730a:      	xorl	%esi, %esi
    730c:      	nopl	(%rax)
    7310:      	leaq	(%rcx,%rsi), %rdi
    7314:      	cmpq	%rbp, %rdi
    7317:      	jae	0x72ff <generic_tracepoint_arg+0x1f6f>
    7319:      	movzbl	(%rax,%rsi), %edi
    731d:      	testb	%dil, %dil
    7320:      	je	0x7337 <generic_tracepoint_arg+0x1fa7>
    7322:      	cmpq	$0x62, %rsi
    7326:      	ja	0x72ff <generic_tracepoint_arg+0x1f6f>
    7328:      	leaq	0x1(%rsi), %r8
    732c:      	cmpb	%dil, (%rdx,%rsi)
    7330:      	movq	%r8, %rsi
    7333:      	je	0x7310 <generic_tracepoint_arg+0x1f80>
    7335:      	jmp	0x72ff <generic_tracepoint_arg+0x1f6f>
    7337:      	testl	%ecx, %ecx
    7339:      	jns	0x802a <generic_tracepoint_arg+0x2c9a>
    733f:      	leal	0xc(%r13), %eax
    7343:      	cmpl	0x8(%r12), %eax
    7348:      	jae	0x735b <generic_tracepoint_arg+0x1fcb>
    734a:      	addl	$0x4, %r13d
    734e:      	incq	%rbx
    7351:      	cmpq	$0x64, %rbx
    7355:      	jne	0x72bd <generic_tracepoint_arg+0x1f2d>
    735b:      	xorl	%ebx, %ebx
    735d:      	movq	0x10(%rsp), %rdi
    7362:      	jmp	0x8625 <generic_tracepoint_arg+0x3295>
    7367:      	movzwl	%bp, %eax
    736a:      	cmpl	$0x90, %eax
    736f:      	movq	%r11, 0x20(%rsp)
    7374:      	ja	0x7852 <generic_tracepoint_arg+0x24c2>
    737a:      	testw	%bp, %bp
    737d:      	je	0x738f <generic_tracepoint_arg+0x1fff>
    737f:      	movl	%ebp, %eax
    7381:      	movl	$0x18, %ecx
    7386:      	cltd
    7387:      	idivl	%ecx
    7389:      	movl	%ebp, %edi
    738b:      	testl	%edx, %edx
    738d:      	je	0x73b1 <generic_tracepoint_arg+0x2021>
    738f:      	movl	%ebp, %eax
    7391:      	movl	$0x18, %ecx
    7396:      	cltd
    7397:      	idivl	%ecx
    7399:      	shll	$0x3, %eax
    739c:      	leal	(%rax,%rax,2), %eax
    739f:      	addl	$0x18, %eax
    73a2:      	movzwl	%ax, %edi
    73a5:      	cmpl	$0x90, %edi
    73ab:      	ja	0x7866 <generic_tracepoint_arg+0x24d6>
    73b1:      	movl	%edi, %eax
    73b3:      	cltd
    73b4:      	idivl	%ecx
    73b6:      	decl	%eax
    73b8:      	jmp	0x7877 <generic_tracepoint_arg+0x24e7>
    73bd:      	movq	0x8(%rsp), %rdx
    73c2:      	movzbl	(%rdx), %edx
    73c5:      	cmpl	%edx, %ecx
    73c7:      	jb	0x5658 <generic_tracepoint_arg+0x2c8>
    73cd:      	movl	0x8(%r12), %ecx
    73d2:      	cmpl	$0xd, %ecx
    73d5:      	jb	0x86da <generic_tracepoint_arg+0x334a>
    73db:      	movl	0x14(%r12), %edx
    73e0:      	cmpl	$0x2, %eax
    73e3:      	jle	0x7732 <generic_tracepoint_arg+0x23a2>
    73e9:      	leal	-0x3(%rax), %esi
    73ec:      	cmpl	$0x2, %esi
    73ef:      	jae	0x7c47 <generic_tracepoint_arg+0x28b7>
    73f5:      	movq	0x8(%rsp), %rsi
    73fa:      	movzbl	(%rsi), %esi
    73fd:      	cmpl	%esi, %edx
    73ff:      	jne	0x7d52 <generic_tracepoint_arg+0x29c2>
    7405:      	jmp	0x85b1 <generic_tracepoint_arg+0x3221>
    740a:      	movq	0x8(%rsp), %rdx
    740f:      	movzwl	(%rdx), %edx
    7412:      	cmpl	%edx, %ecx
    7414:      	jb	0x5658 <generic_tracepoint_arg+0x2c8>
    741a:      	movl	0x8(%r12), %ecx
    741f:      	cmpl	$0xd, %ecx
    7422:      	jb	0x86da <generic_tracepoint_arg+0x334a>
    7428:      	movl	0x14(%r12), %edx
    742d:      	cmpl	$0x2, %eax
    7430:      	jle	0x7759 <generic_tracepoint_arg+0x23c9>
    7436:      	leal	-0x3(%rax), %esi
    7439:      	cmpl	$0x2, %esi
    743c:      	jae	0x7c65 <generic_tracepoint_arg+0x28d5>
    7442:      	movq	0x8(%rsp), %rsi
    7447:      	movzwl	(%rsi), %esi
    744a:      	cmpl	%esi, %edx
    744c:      	jne	0x7d9a <generic_tracepoint_arg+0x2a0a>
    7452:      	jmp	0x85b1 <generic_tracepoint_arg+0x3221>
    7457:      	testq	%rax, %rax
    745a:      	sete	%al
    745d:      	movq	0x10(%rsp), %rdi
    7462:      	movq	0x18(%rsp), %r9
    7467:      	movq	0x20(%rsp), %r11
    746c:      	movzbl	%al, %ebx
    746f:      	jmp	0x5642 <generic_tracepoint_arg+0x2b2>
    7474:      	movq	0x8(%rsp), %rax
    7479:      	movl	(%rax), %eax
    747b:      	cmpl	%eax, %esi
    747d:      	ja	0x7487 <generic_tracepoint_arg+0x20f7>
    747f:      	cmpl	%edx, %eax
    7481:      	jbe	0x5658 <generic_tracepoint_arg+0x2c8>
    7487:      	movl	0x8(%r12), %edx
    748c:      	cmpl	$0x11, %edx
    748f:      	jb	0x549d <generic_tracepoint_arg+0x10d>
    7495:      	movl	0x18(%r12), %edi
    749a:      	movl	0x1c(%r12), %esi
    749f:      	cmpl	$0xc, %ecx
    74a2:      	ja	0x799e <generic_tracepoint_arg+0x260e>
    74a8:      	movl	$0x1402, %r8d           # imm = 0x1402
    74ae:      	btl	%ecx, %r8d
    74b2:      	jae	0x799e <generic_tracepoint_arg+0x260e>
    74b8:      	cmpl	%eax, %edi
    74ba:      	movq	0x10(%rsp), %rdi
    74bf:      	jg	0x79af <generic_tracepoint_arg+0x261f>
    74c5:      	cmpl	%esi, %eax
    74c7:      	jle	0x5658 <generic_tracepoint_arg+0x2c8>
    74cd:      	jmp	0x79af <generic_tracepoint_arg+0x261f>
    74d2:      	movq	0x8(%rsp), %rdx
    74d7:      	movl	(%rdx), %edx
    74d9:      	cmpl	%edx, %esi
    74db:      	setbe	%sil
    74df:      	cmpl	%eax, %edx
    74e1:      	setbe	%al
    74e4:      	andb	%sil, %al
    74e7:      	movl	0x8(%r12), %esi
    74ec:      	cmpl	$0x11, %esi
    74ef:      	jb	0x81b9 <generic_tracepoint_arg+0x2e29>
    74f5:      	movl	0x18(%r12), %r8d
    74fa:      	movl	0x1c(%r12), %edi
    74ff:      	cmpl	$0xc, %ecx
    7502:      	ja	0x794d <generic_tracepoint_arg+0x25bd>
    7508:      	movl	$0x1402, %r10d          # imm = 0x1402
    750e:      	btl	%ecx, %r10d
    7512:      	jae	0x794d <generic_tracepoint_arg+0x25bd>
    7518:      	cmpl	%edx, %r8d
    751b:      	setle	%r8b
    751f:      	cmpl	%edi, %edx
    7521:      	setle	%dil
    7525:      	jmp	0x795a <generic_tracepoint_arg+0x25ca>
    752a:      	cmpq	%rdx, %r8
    752d:      	setbe	%r8b
    7531:      	cmpq	%rdi, %rdx
    7534:      	setbe	%dil
    7538:      	andb	%r8b, %dil
    753b:      	orb	%dil, %al
    753e:      	cmpl	$0x29, %esi
    7541:      	jb	0x81b4 <generic_tracepoint_arg+0x2e24>
    7547:      	movq	0x30(%r12), %r8
    754c:      	movq	0x38(%r12), %rdi
    7551:      	cmpl	$0xc, %ecx
    7554:      	je	0x755f <generic_tracepoint_arg+0x21cf>
    7556:      	cmpl	$0xa, %ecx
    7559:      	jne	0x7a40 <generic_tracepoint_arg+0x26b0>
    755f:      	cmpq	%rdx, %r8
    7562:      	setle	%r8b
    7566:      	cmpq	%rdi, %rdx
    7569:      	setle	%dil
    756d:      	jmp	0x7a4e <generic_tracepoint_arg+0x26be>
    7572:      	cmpq	%rax, %rdi
    7575:      	movq	0x10(%rsp), %rdi
    757a:      	ja	0x7585 <generic_tracepoint_arg+0x21f5>
    757c:      	cmpq	%rsi, %rax
    757f:      	jbe	0x5658 <generic_tracepoint_arg+0x2c8>
    7585:      	cmpl	$0x29, %edx
    7588:      	jb	0x549d <generic_tracepoint_arg+0x10d>
    758e:      	movq	0x30(%r12), %rdi
    7593:      	movq	0x38(%r12), %rsi
    7598:      	cmpl	$0xc, %ecx
    759b:      	je	0x75a6 <generic_tracepoint_arg+0x2216>
    759d:      	cmpl	$0xa, %ecx
    75a0:      	jne	0x7b57 <generic_tracepoint_arg+0x27c7>
    75a6:      	cmpq	%rax, %rdi
    75a9:      	movq	0x10(%rsp), %rdi
    75ae:      	jg	0x7b6a <generic_tracepoint_arg+0x27da>
    75b4:      	cmpq	%rsi, %rax
    75b7:      	jle	0x5658 <generic_tracepoint_arg+0x2c8>
    75bd:      	jmp	0x7b6a <generic_tracepoint_arg+0x27da>
    75c2:      	xorl	%ebx, %ebx
    75c4:      	cmpl	$0x29, %ecx
    75c7:      	jne	0x75d2 <generic_tracepoint_arg+0x2242>
    75c9:      	testq	%rdx, %rdx
    75cc:      	je	0x75d2 <generic_tracepoint_arg+0x2242>
    75ce:      	movzbl	0x3a(%rdx), %ebx
    75d2:      	cmpl	$0x29, %ecx
    75d5:      	je	0x75e0 <generic_tracepoint_arg+0x2250>
    75d7:      	cmpl	$0x7, %ecx
    75da:      	jne	0x7a83 <generic_tracepoint_arg+0x26f3>
    75e0:      	movq	%r11, %r13
    75e3:      	movzbl	0x10(%r12), %eax
    75e9:      	movl	%eax, 0x34(%rsp)
    75ed:      	movl	$0x1, %eax
    75f2:      	movq	(%rip), %rdi            # 0x75f9 <generic_tracepoint_arg+0x2269>
    75f9:      	leaq	0x34(%rsp), %rsi
    75fe:      	callq	*%rax
    7600:      	testq	%rax, %rax
    7603:      	je	0x7621 <generic_tracepoint_arg+0x2291>
    7605:      	movq	%rax, %rdi
    7608:      	movl	%ebx, %eax
    760a:      	movq	%rax, 0x80(%rsp)
    7612:      	movl	$0x1, %eax
    7617:      	movq	0x38(%rsp), %rsi
    761c:      	jmp	0x6fbf <generic_tracepoint_arg+0x1c2f>
    7621:      	xorl	%ebx, %ebx
    7623:      	movq	0x10(%rsp), %rdi
    7628:      	movq	0x18(%rsp), %r9
    762d:      	movq	%r13, %r11
    7630:      	jmp	0x5642 <generic_tracepoint_arg+0x2b2>
    7635:      	movq	0x8(%rsp), %rsi
    763a:      	cmpl	%edx, (%rsi)
    763c:      	ja	0x5658 <generic_tracepoint_arg+0x2c8>
    7642:      	jmp	0x7651 <generic_tracepoint_arg+0x22c1>
    7644:      	movq	0x8(%rsp), %rsi
    7649:      	cmpl	%edx, (%rsi)
    764b:      	jb	0x5658 <generic_tracepoint_arg+0x2c8>
    7651:      	movl	0x8(%r12), %edx
    7656:      	cmpl	$0xd, %edx
    7659:      	jb	0x86da <generic_tracepoint_arg+0x334a>
    765f:      	movl	0x14(%r12), %esi
    7664:      	cmpl	$0x2, %eax
    7667:      	jle	0x7688 <generic_tracepoint_arg+0x22f8>
    7669:      	leal	-0x3(%rax), %edi
    766c:      	cmpl	$0x2, %edi
    766f:      	jae	0x76c2 <generic_tracepoint_arg+0x2332>
    7671:      	movq	0x8(%rsp), %rdi
    7676:      	cmpl	%esi, (%rdi)
    7678:      	movq	0x10(%rsp), %rdi
    767d:      	jne	0x7e9c <generic_tracepoint_arg+0x2b0c>
    7683:      	jmp	0x85b1 <generic_tracepoint_arg+0x3221>
    7688:      	cmpl	$0x1, %eax
    768b:      	je	0x76e3 <generic_tracepoint_arg+0x2353>
    768d:      	cmpl	$0x2, %eax
    7690:      	jne	0x7e9c <generic_tracepoint_arg+0x2b0c>
    7696:      	cmpl	$0xc, %ecx
    7699:      	ja	0x7e8e <generic_tracepoint_arg+0x2afe>
    769f:      	movl	$0x1402, %r8d           # imm = 0x1402
    76a5:      	btl	%ecx, %r8d
    76a9:      	jae	0x7e8e <generic_tracepoint_arg+0x2afe>
    76af:      	movq	0x8(%rsp), %r8
    76b4:      	cmpl	%esi, (%r8)
    76b7:      	jl	0x5658 <generic_tracepoint_arg+0x2c8>
    76bd:      	jmp	0x7e9c <generic_tracepoint_arg+0x2b0c>
    76c2:      	cmpl	$0xc, %eax
    76c5:      	movq	0x10(%rsp), %rdi
    76ca:      	jne	0x7e9c <generic_tracepoint_arg+0x2b0c>
    76d0:      	movq	0x8(%rsp), %r8
    76d5:      	testl	%esi, (%r8)
    76d8:      	jne	0x5658 <generic_tracepoint_arg+0x2c8>
    76de:      	jmp	0x7e9c <generic_tracepoint_arg+0x2b0c>
    76e3:      	cmpl	$0xc, %ecx
    76e6:      	ja	0x7e7e <generic_tracepoint_arg+0x2aee>
    76ec:      	movl	$0x1402, %r8d           # imm = 0x1402
    76f2:      	btl	%ecx, %r8d
    76f6:      	jae	0x7e7e <generic_tracepoint_arg+0x2aee>
    76fc:      	movq	0x8(%rsp), %r8
    7701:      	cmpl	%esi, (%r8)
    7704:      	jg	0x5658 <generic_tracepoint_arg+0x2c8>
    770a:      	jmp	0x7e9c <generic_tracepoint_arg+0x2b0c>
    770f:      	xorl	%ebx, %ebx
    7711:      	movq	0x18(%rsp), %r9
    7716:      	movq	%r15, %r11
    7719:      	movq	0x68(%rsp), %r15
    771e:      	jmp	0x79fa <generic_tracepoint_arg+0x266a>
    7723:      	xorl	%ebx, %ebx
    7725:      	movq	%r15, %r11
    7728:      	movq	0x68(%rsp), %r15
    772d:      	jmp	0x7a1d <generic_tracepoint_arg+0x268d>
    7732:      	cmpl	$0x1, %eax
    7735:      	je	0x7d42 <generic_tracepoint_arg+0x29b2>
    773b:      	cmpl	$0x2, %eax
    773e:      	jne	0x7d52 <generic_tracepoint_arg+0x29c2>
    7744:      	movq	0x8(%rsp), %rsi
    7749:      	movzbl	(%rsi), %esi
    774c:      	cmpl	%esi, %edx
    774e:      	ja	0x5658 <generic_tracepoint_arg+0x2c8>
    7754:      	jmp	0x7d52 <generic_tracepoint_arg+0x29c2>
    7759:      	cmpl	$0x1, %eax
    775c:      	je	0x7d8a <generic_tracepoint_arg+0x29fa>
    7762:      	cmpl	$0x2, %eax
    7765:      	jne	0x7d9a <generic_tracepoint_arg+0x2a0a>
    776b:      	movq	0x8(%rsp), %rsi
    7770:      	movzwl	(%rsi), %esi
    7773:      	cmpl	%esi, %edx
    7775:      	ja	0x5658 <generic_tracepoint_arg+0x2c8>
    777b:      	jmp	0x7d9a <generic_tracepoint_arg+0x2a0a>
    7780:      	movq	0x28(%rsp), %rax
    7785:      	movw	%bp, (%rax)
    7788:      	leaq	0x2(%rax), %rdi
    778c:      	movl	$0x4, %eax
    7791:      	movl	%ebp, %esi
    7793:      	callq	*%rax
    7795:      	movq	0x98(%rsp), %rsi
    779d:      	subl	%ebp, %esi
    779f:      	jbe	0x77c3 <generic_tracepoint_arg+0x2433>
    77a1:      	movq	0x28(%rsp), %rax
    77a6:      	leaq	(%rax,%rbp), %rdi
    77aa:      	addq	$0x2, %rdi
    77ae:      	andl	$0xfff, %esi            # imm = 0xFFF
    77b4:      	movl	$0x4, %eax
    77b9:      	movq	0xa8(%rsp), %rdx
    77c1:      	callq	*%rax
    77c3:      	movl	0xa0(%rsp), %eax
    77ca:      	movl	%eax, 0x40(%rsp)
    77ce:      	cmpl	$0x3, %ebx
    77d1:      	jg	0x7812 <generic_tracepoint_arg+0x2482>
    77d3:      	cmpl	$0x1, %ebx
    77d6:      	movq	0x10(%rsp), %rdi
    77db:      	movq	0x18(%rsp), %r9
    77e0:      	movq	0x20(%rsp), %r11
    77e5:      	jg	0x7cd2 <generic_tracepoint_arg+0x2942>
    77eb:      	testl	%ebx, %ebx
    77ed:      	je	0x80ff <generic_tracepoint_arg+0x2d6f>
    77f3:      	cmpl	$0x1, %ebx
    77f6:      	jne	0x5cd3 <generic_tracepoint_arg+0x943>
    77fc:      	movl	$0x1, %eax
    7801:      	leaq	0x40(%rsp), %rsi
    7806:      	movq	(%rip), %rdi            # 0x780d <generic_tracepoint_arg+0x247d>
    780d:      	jmp	0x8149 <generic_tracepoint_arg+0x2db9>
    7812:      	cmpl	$0x5, %ebx
    7815:      	movq	0x10(%rsp), %rdi
    781a:      	movq	0x18(%rsp), %r9
    781f:      	movq	0x20(%rsp), %r11
    7824:      	jg	0x7cfa <generic_tracepoint_arg+0x296a>
    782a:      	cmpl	$0x4, %ebx
    782d:      	je	0x8112 <generic_tracepoint_arg+0x2d82>
    7833:      	cmpl	$0x5, %ebx
    7836:      	jne	0x5cd3 <generic_tracepoint_arg+0x943>
    783c:      	movl	$0x1, %eax
    7841:      	leaq	0x40(%rsp), %rsi
    7846:      	movq	(%rip), %rdi            # 0x784d <generic_tracepoint_arg+0x24bd>
    784d:      	jmp	0x8149 <generic_tracepoint_arg+0x2db9>
    7852:      	cmpl	$0x101, %eax            # imm = 0x101
    7857:      	movl	$0x100, %edi            # imm = 0x100
    785c:      	movl	$0x1fe, %eax            # imm = 0x1FE
    7861:      	cmovael	%eax, %edi
    7864:      	movl	%edi, %eax
    7866:      	movzwl	%ax, %ecx
    7869:      	xorl	%eax, %eax
    786b:      	cmpl	$0x100, %ecx            # imm = 0x100
    7871:      	sete	%al
    7874:      	xorl	$0x7, %eax
    7877:      	movl	%eax, %ecx
    7879:      	andl	$0xf, %ecx
    787c:      	movl	0x10(%r12,%rcx,4), %ecx
    7881:      	cmpl	$-0x1, %ecx
    7884:      	je	0x8614 <generic_tracepoint_arg+0x3284>
    788a:      	movl	%ecx, 0x98(%rsp)
    7891:      	movq	%rdi, 0xa0(%rsp)
    7899:      	movl	%eax, 0x70(%rsp)
    789d:      	movq	%rsi, 0x8(%rsp)
    78a2:      	movl	$0x1, %eax
    78a7:      	movq	(%rip), %rdi            # 0x78ae <generic_tracepoint_arg+0x251e>
    78ae:      	movq	0x38(%rsp), %rbx
    78b3:      	movq	%rbx, %rsi
    78b6:      	callq	*%rax
    78b8:      	movq	%rax, 0x28(%rsp)
    78bd:      	movl	$0x1, %eax
    78c2:      	movq	(%rip), %rdi            # 0x78c9 <generic_tracepoint_arg+0x2539>
    78c9:      	movq	%rbx, %rsi
    78cc:      	callq	*%rax
    78ce:      	cmpq	$0x0, 0x28(%rsp)
    78d4:      	je	0x8614 <generic_tracepoint_arg+0x3284>
    78da:      	movl	$0x0, %ebx
    78df:      	testq	%rax, %rax
    78e2:      	movq	0x10(%rsp), %rdi
    78e7:      	movq	0x18(%rsp), %r9
    78ec:      	movq	0x20(%rsp), %r11
    78f1:      	je	0x8625 <generic_tracepoint_arg+0x3295>
    78f7:      	movq	%rax, %r13
    78fa:      	movl	0x70(%rsp), %ebx
    78fe:      	cmpl	$0x5, %ebx
    7901:      	jg	0x804b <generic_tracepoint_arg+0x2cbb>
    7907:      	movq	0x28(%rsp), %rax
    790c:      	movb	%bpl, (%rax)
    790f:      	leaq	0x1(%rax), %rdi
    7913:      	movl	$0x4, %eax
    7918:      	movq	0x8(%rsp), %rdx
    791d:      	movl	%ebp, %esi
    791f:      	callq	*%rax
    7921:      	movq	0xa0(%rsp), %rsi
    7929:      	subl	%ebp, %esi
    792b:      	jbe	0x808e <generic_tracepoint_arg+0x2cfe>
    7931:      	movq	0x28(%rsp), %rax
    7936:      	leaq	(%rax,%rbp), %rdi
    793a:      	incq	%rdi
    793d:      	andl	$0xfff, %esi            # imm = 0xFFF
    7943:      	movl	$0x4, %eax
    7948:      	jmp	0x8089 <generic_tracepoint_arg+0x2cf9>
    794d:      	cmpl	%edx, %r8d
    7950:      	setbe	%r8b
    7954:      	cmpl	%edi, %edx
    7956:      	setbe	%dil
    795a:      	andb	%r8b, %dil
    795d:      	orb	%dil, %al
    7960:      	cmpl	$0x19, %esi
    7963:      	jb	0x81b4 <generic_tracepoint_arg+0x2e24>
    7969:      	movl	0x20(%r12), %r8d
    796e:      	movl	0x24(%r12), %edi
    7973:      	cmpl	$0xc, %ecx
    7976:      	ja	0x7dde <generic_tracepoint_arg+0x2a4e>
    797c:      	movl	$0x1402, %r10d          # imm = 0x1402
    7982:      	btl	%ecx, %r10d
    7986:      	jae	0x7dde <generic_tracepoint_arg+0x2a4e>
    798c:      	cmpl	%edx, %r8d
    798f:      	setle	%r8b
    7993:      	cmpl	%edi, %edx
    7995:      	setle	%dil
    7999:      	jmp	0x7deb <generic_tracepoint_arg+0x2a5b>
    799e:      	cmpl	%eax, %edi
    79a0:      	movq	0x10(%rsp), %rdi
    79a5:      	ja	0x79af <generic_tracepoint_arg+0x261f>
    79a7:      	cmpl	%esi, %eax
    79a9:      	jbe	0x5658 <generic_tracepoint_arg+0x2c8>
    79af:      	cmpl	$0x19, %edx
    79b2:      	jb	0x549d <generic_tracepoint_arg+0x10d>
    79b8:      	movl	0x20(%r12), %edi
    79bd:      	movl	0x24(%r12), %esi
    79c2:      	cmpl	$0xc, %ecx
    79c5:      	ja	0x7e2c <generic_tracepoint_arg+0x2a9c>
    79cb:      	movl	$0x1402, %r8d           # imm = 0x1402
    79d1:      	btl	%ecx, %r8d
    79d5:      	jae	0x7e2c <generic_tracepoint_arg+0x2a9c>
    79db:      	cmpl	%eax, %edi
    79dd:      	movq	0x10(%rsp), %rdi
    79e2:      	jg	0x7e3d <generic_tracepoint_arg+0x2aad>
    79e8:      	cmpl	%esi, %eax
    79ea:      	jle	0x5658 <generic_tracepoint_arg+0x2c8>
    79f0:      	jmp	0x7e3d <generic_tracepoint_arg+0x2aad>
    79f5:      	movl	$0x1, %ebx
    79fa:      	movq	0x78(%rsp), %r13
    79ff:      	movq	0x10(%rsp), %rdi
    7a04:      	movl	0x4(%r12), %eax
    7a09:      	cmpq	$0x25, %rax
    7a0d:      	jbe	0x8366 <generic_tracepoint_arg+0x2fd6>
    7a13:      	jmp	0x5647 <generic_tracepoint_arg+0x2b7>
    7a18:      	movl	$0x1, %ebx
    7a1d:      	movq	0x78(%rsp), %r13
    7a22:      	movq	0x10(%rsp), %rdi
    7a27:      	movq	0x18(%rsp), %r9
    7a2c:      	movl	0x4(%r12), %eax
    7a31:      	cmpq	$0x25, %rax
    7a35:      	jbe	0x8366 <generic_tracepoint_arg+0x2fd6>
    7a3b:      	jmp	0x5647 <generic_tracepoint_arg+0x2b7>
    7a40:      	cmpq	%rdx, %r8
    7a43:      	setbe	%r8b
    7a47:      	cmpq	%rdi, %rdx
    7a4a:      	setbe	%dil
    7a4e:      	andb	%r8b, %dil
    7a51:      	orb	%dil, %al
    7a54:      	cmpl	$0x39, %esi
    7a57:      	jb	0x81b4 <generic_tracepoint_arg+0x2e24>
    7a5d:      	movq	0x40(%r12), %rdi
    7a62:      	movq	0x48(%r12), %rsi
    7a67:      	cmpl	$0xc, %ecx
    7a6a:      	je	0x7a75 <generic_tracepoint_arg+0x26e5>
    7a6c:      	cmpl	$0xa, %ecx
    7a6f:      	jne	0x7f55 <generic_tracepoint_arg+0x2bc5>
    7a75:      	cmpq	%rdx, %rdi
    7a78:      	setle	%cl
    7a7b:      	cmpq	%rsi, %rdx
    7a7e:      	jmp	0x7e24 <generic_tracepoint_arg+0x2a94>
    7a83:      	xorl	%ebx, %ebx
    7a85:      	jmp	0x5642 <generic_tracepoint_arg+0x2b2>
    7a8a:      	movq	0x28(%rsp), %rax
    7a8f:      	movw	%bp, (%rax)
    7a92:      	leaq	0x2(%rax), %rdi
    7a96:      	movl	$0x4, %eax
    7a9b:      	movq	0x8(%rsp), %rdx
    7aa0:      	movl	%ebp, %esi
    7aa2:      	callq	*%rax
    7aa4:      	movq	0x98(%rsp), %rsi
    7aac:      	subl	%ebp, %esi
    7aae:      	jbe	0x7ad2 <generic_tracepoint_arg+0x2742>
    7ab0:      	movq	0x28(%rsp), %rax
    7ab5:      	leaq	(%rax,%rbp), %rdi
    7ab9:      	addq	$0x2, %rdi
    7abd:      	andl	$0xfff, %esi            # imm = 0xFFF
    7ac3:      	movl	$0x4, %eax
    7ac8:      	movq	0xa8(%rsp), %rdx
    7ad0:      	callq	*%rax
    7ad2:      	movl	0xa0(%rsp), %eax
    7ad9:      	movl	%eax, 0x40(%rsp)
    7add:      	cmpl	$0x3, %ebx
    7ae0:      	jg	0x7b1c <generic_tracepoint_arg+0x278c>
    7ae2:      	cmpl	$0x1, %ebx
    7ae5:      	movq	0x18(%rsp), %r9
    7aea:      	movq	0x20(%rsp), %r11
    7aef:      	jg	0x7f63 <generic_tracepoint_arg+0x2bd3>
    7af5:      	testl	%ebx, %ebx
    7af7:      	je	0x82dc <generic_tracepoint_arg+0x2f4c>
    7afd:      	cmpl	$0x1, %ebx
    7b00:      	jne	0x837f <generic_tracepoint_arg+0x2fef>
    7b06:      	movl	$0x1, %eax
    7b0b:      	leaq	0x40(%rsp), %rsi
    7b10:      	movq	(%rip), %rdi            # 0x7b17 <generic_tracepoint_arg+0x2787>
    7b17:      	jmp	0x8326 <generic_tracepoint_arg+0x2f96>
    7b1c:      	cmpl	$0x5, %ebx
    7b1f:      	movq	0x18(%rsp), %r9
    7b24:      	movq	0x20(%rsp), %r11
    7b29:      	jg	0x7f8b <generic_tracepoint_arg+0x2bfb>
    7b2f:      	cmpl	$0x4, %ebx
    7b32:      	je	0x82ef <generic_tracepoint_arg+0x2f5f>
    7b38:      	cmpl	$0x5, %ebx
    7b3b:      	jne	0x837f <generic_tracepoint_arg+0x2fef>
    7b41:      	movl	$0x1, %eax
    7b46:      	leaq	0x40(%rsp), %rsi
    7b4b:      	movq	(%rip), %rdi            # 0x7b52 <generic_tracepoint_arg+0x27c2>
    7b52:      	jmp	0x8326 <generic_tracepoint_arg+0x2f96>
    7b57:      	cmpq	%rax, %rdi
    7b5a:      	movq	0x10(%rsp), %rdi
    7b5f:      	ja	0x7b6a <generic_tracepoint_arg+0x27da>
    7b61:      	cmpq	%rsi, %rax
    7b64:      	jbe	0x5658 <generic_tracepoint_arg+0x2c8>
    7b6a:      	cmpl	$0x39, %edx
    7b6d:      	jb	0x549d <generic_tracepoint_arg+0x10d>
    7b73:      	movq	0x40(%r12), %rsi
    7b78:      	movq	0x48(%r12), %rdx
    7b7d:      	cmpl	$0xc, %ecx
    7b80:      	je	0x7b8b <generic_tracepoint_arg+0x27fb>
    7b82:      	cmpl	$0xa, %ecx
    7b85:      	jne	0x7fb3 <generic_tracepoint_arg+0x2c23>
    7b8b:      	cmpq	%rax, %rsi
    7b8e:      	jg	0x549d <generic_tracepoint_arg+0x10d>
    7b94:      	cmpq	%rdx, %rax
    7b97:      	jle	0x5658 <generic_tracepoint_arg+0x2c8>
    7b9d:      	jmp	0x549d <generic_tracepoint_arg+0x10d>
    7ba2:      	movq	0x8(%rsp), %r8
    7ba7:      	cmpq	%rsi, (%r8)
    7baa:      	ja	0x5658 <generic_tracepoint_arg+0x2c8>
    7bb0:      	jmp	0x7bc0 <generic_tracepoint_arg+0x2830>
    7bb2:      	movq	0x8(%rsp), %r8
    7bb7:      	cmpq	%rsi, (%r8)
    7bba:      	jb	0x5658 <generic_tracepoint_arg+0x2c8>
    7bc0:      	cmpl	$0x19, %edx
    7bc3:      	jb	0x86da <generic_tracepoint_arg+0x334a>
    7bc9:      	movq	0x20(%r12), %rsi
    7bce:      	cmpl	$0x2, %eax
    7bd1:      	jle	0x7bf3 <generic_tracepoint_arg+0x2863>
    7bd3:      	leal	-0x3(%rax), %edi
    7bd6:      	cmpl	$0x2, %edi
    7bd9:      	jae	0x7c26 <generic_tracepoint_arg+0x2896>
    7bdb:      	movq	0x8(%rsp), %rdi
    7be0:      	cmpq	%rsi, (%rdi)
    7be3:      	movq	0x10(%rsp), %rdi
    7be8:      	jne	0x81e4 <generic_tracepoint_arg+0x2e54>
    7bee:      	jmp	0x85b1 <generic_tracepoint_arg+0x3221>
    7bf3:      	cmpl	$0x1, %eax
    7bf6:      	je	0x7c98 <generic_tracepoint_arg+0x2908>
    7bfc:      	cmpl	$0x2, %eax
    7bff:      	jne	0x81e4 <generic_tracepoint_arg+0x2e54>
    7c05:      	cmpl	$0xc, %ecx
    7c08:      	je	0x7c13 <generic_tracepoint_arg+0x2883>
    7c0a:      	cmpl	$0xa, %ecx
    7c0d:      	jne	0x81d6 <generic_tracepoint_arg+0x2e46>
    7c13:      	movq	0x8(%rsp), %r8
    7c18:      	cmpq	%rsi, (%r8)
    7c1b:      	jl	0x5658 <generic_tracepoint_arg+0x2c8>
    7c21:      	jmp	0x81e4 <generic_tracepoint_arg+0x2e54>
    7c26:      	cmpl	$0xc, %eax
    7c29:      	movq	0x10(%rsp), %rdi
    7c2e:      	jne	0x81e4 <generic_tracepoint_arg+0x2e54>
    7c34:      	movq	0x8(%rsp), %r8
    7c39:      	testq	%rsi, (%r8)
    7c3c:      	jne	0x5658 <generic_tracepoint_arg+0x2c8>
    7c42:      	jmp	0x81e4 <generic_tracepoint_arg+0x2e54>
    7c47:      	cmpl	$0xc, %eax
    7c4a:      	jne	0x7d52 <generic_tracepoint_arg+0x29c2>
    7c50:      	movq	0x8(%rsp), %rsi
    7c55:      	movzbl	(%rsi), %esi
    7c58:      	testl	%esi, %edx
    7c5a:      	jne	0x5658 <generic_tracepoint_arg+0x2c8>
    7c60:      	jmp	0x7d52 <generic_tracepoint_arg+0x29c2>
    7c65:      	cmpl	$0xc, %eax
    7c68:      	jne	0x7d9a <generic_tracepoint_arg+0x2a0a>
    7c6e:      	movq	0x8(%rsp), %rsi
    7c73:      	movzwl	(%rsi), %esi
    7c76:      	testl	%esi, %edx
    7c78:      	jne	0x5658 <generic_tracepoint_arg+0x2c8>
    7c7e:      	jmp	0x7d9a <generic_tracepoint_arg+0x2a0a>
    7c83:      	movq	0x10(%rsp), %rdi
    7c88:      	movq	0x18(%rsp), %r9
    7c8d:      	movq	%rbp, %r11
    7c90:      	movzbl	%cl, %ebx
    7c93:      	jmp	0x5647 <generic_tracepoint_arg+0x2b7>
    7c98:      	cmpl	$0xc, %ecx
    7c9b:      	je	0x7ca6 <generic_tracepoint_arg+0x2916>
    7c9d:      	cmpl	$0xa, %ecx
    7ca0:      	jne	0x81c6 <generic_tracepoint_arg+0x2e36>
    7ca6:      	movq	0x8(%rsp), %r8
    7cab:      	cmpq	%rsi, (%r8)
    7cae:      	jg	0x5658 <generic_tracepoint_arg+0x2c8>
    7cb4:      	jmp	0x81e4 <generic_tracepoint_arg+0x2e54>
    7cb9:      	xorl	%ebx, %ebx
    7cbb:      	movq	0x18(%rsp), %r9
    7cc0:      	movq	%r15, %r11
    7cc3:      	movq	0x68(%rsp), %r15
    7cc8:      	movq	0x10(%rsp), %rdi
    7ccd:      	jmp	0x8625 <generic_tracepoint_arg+0x3295>
    7cd2:      	cmpl	$0x2, %ebx
    7cd5:      	je	0x8125 <generic_tracepoint_arg+0x2d95>
    7cdb:      	cmpl	$0x3, %ebx
    7cde:      	jne	0x5cd3 <generic_tracepoint_arg+0x943>
    7ce4:      	movl	$0x1, %eax
    7ce9:      	leaq	0x40(%rsp), %rsi
    7cee:      	movq	(%rip), %rdi            # 0x7cf5 <generic_tracepoint_arg+0x2965>
    7cf5:      	jmp	0x8149 <generic_tracepoint_arg+0x2db9>
    7cfa:      	cmpl	$0x6, %ebx
    7cfd:      	je	0x8138 <generic_tracepoint_arg+0x2da8>
    7d03:      	cmpl	$0x7, %ebx
    7d06:      	jne	0x5cd3 <generic_tracepoint_arg+0x943>
    7d0c:      	movl	$0x1, %eax
    7d11:      	leaq	0x40(%rsp), %rsi
    7d16:      	movq	(%rip), %rdi            # 0x7d1d <generic_tracepoint_arg+0x298d>
    7d1d:      	jmp	0x8149 <generic_tracepoint_arg+0x2db9>
    7d22:      	xorl	%ebx, %ebx
    7d24:      	jmp	0x7d2b <generic_tracepoint_arg+0x299b>
    7d26:      	movl	$0x1, %ebx
    7d2b:      	movq	0x10(%rsp), %rdi
    7d30:      	movq	0x18(%rsp), %r9
    7d35:      	movq	%r15, %r11
    7d38:      	movq	0x68(%rsp), %r15
    7d3d:      	jmp	0x8625 <generic_tracepoint_arg+0x3295>
    7d42:      	movq	0x8(%rsp), %rsi
    7d47:      	movzbl	(%rsi), %esi
    7d4a:      	cmpl	%esi, %edx
    7d4c:      	jb	0x5658 <generic_tracepoint_arg+0x2c8>
    7d52:      	cmpl	$0x11, %ecx
    7d55:      	jb	0x86da <generic_tracepoint_arg+0x334a>
    7d5b:      	movl	0x18(%r12), %edx
    7d60:      	cmpl	$0x2, %eax
    7d63:      	jle	0x7fdc <generic_tracepoint_arg+0x2c4c>
    7d69:      	leal	-0x3(%rax), %esi
    7d6c:      	cmpl	$0x2, %esi
    7d6f:      	jae	0x826a <generic_tracepoint_arg+0x2eda>
    7d75:      	movq	0x8(%rsp), %rsi
    7d7a:      	movzbl	(%rsi), %esi
    7d7d:      	cmpl	%esi, %edx
    7d7f:      	jne	0x83ec <generic_tracepoint_arg+0x305c>
    7d85:      	jmp	0x85b1 <generic_tracepoint_arg+0x3221>
    7d8a:      	movq	0x8(%rsp), %rsi
    7d8f:      	movzwl	(%rsi), %esi
    7d92:      	cmpl	%esi, %edx
    7d94:      	jb	0x5658 <generic_tracepoint_arg+0x2c8>
    7d9a:      	cmpl	$0x11, %ecx
    7d9d:      	jb	0x86da <generic_tracepoint_arg+0x334a>
    7da3:      	movl	0x18(%r12), %edx
    7da8:      	cmpl	$0x2, %eax
    7dab:      	jle	0x8003 <generic_tracepoint_arg+0x2c73>
    7db1:      	leal	-0x3(%rax), %esi
    7db4:      	cmpl	$0x2, %esi
    7db7:      	jae	0x8288 <generic_tracepoint_arg+0x2ef8>
    7dbd:      	movq	0x8(%rsp), %rsi
    7dc2:      	movzwl	(%rsi), %esi
    7dc5:      	cmpl	%esi, %edx
    7dc7:      	jne	0x843b <generic_tracepoint_arg+0x30ab>
    7dcd:      	jmp	0x85b1 <generic_tracepoint_arg+0x3221>
    7dd2:      	xorl	%ebx, %ebx
    7dd4:      	movq	0x68(%rsp), %r15
    7dd9:      	jmp	0x8625 <generic_tracepoint_arg+0x3295>
    7dde:      	cmpl	%edx, %r8d
    7de1:      	setbe	%r8b
    7de5:      	cmpl	%edi, %edx
    7de7:      	setbe	%dil
    7deb:      	andb	%r8b, %dil
    7dee:      	orb	%dil, %al
    7df1:      	cmpl	$0x21, %esi
    7df4:      	jb	0x81b4 <generic_tracepoint_arg+0x2e24>
    7dfa:      	movl	0x28(%r12), %edi
    7dff:      	movl	0x2c(%r12), %esi
    7e04:      	cmpl	$0xc, %ecx
    7e07:      	ja	0x81a6 <generic_tracepoint_arg+0x2e16>
    7e0d:      	movl	$0x1402, %r8d           # imm = 0x1402
    7e13:      	btl	%ecx, %r8d
    7e17:      	jae	0x81a6 <generic_tracepoint_arg+0x2e16>
    7e1d:      	cmpl	%edx, %edi
    7e1f:      	setle	%cl
    7e22:      	cmpl	%esi, %edx
    7e24:      	setle	%dl
    7e27:      	jmp	0x81b0 <generic_tracepoint_arg+0x2e20>
    7e2c:      	cmpl	%eax, %edi
    7e2e:      	movq	0x10(%rsp), %rdi
    7e33:      	ja	0x7e3d <generic_tracepoint_arg+0x2aad>
    7e35:      	cmpl	%esi, %eax
    7e37:      	jbe	0x5658 <generic_tracepoint_arg+0x2c8>
    7e3d:      	cmpl	$0x21, %edx
    7e40:      	jb	0x549d <generic_tracepoint_arg+0x10d>
    7e46:      	movl	0x28(%r12), %esi
    7e4b:      	movl	0x2c(%r12), %edx
    7e50:      	cmpl	$0xc, %ecx
    7e53:      	ja	0x82a6 <generic_tracepoint_arg+0x2f16>
    7e59:      	movl	$0x1402, %r8d           # imm = 0x1402
    7e5f:      	btl	%ecx, %r8d
    7e63:      	jae	0x82a6 <generic_tracepoint_arg+0x2f16>
    7e69:      	cmpl	%eax, %esi
    7e6b:      	jg	0x549d <generic_tracepoint_arg+0x10d>
    7e71:      	cmpl	%edx, %eax
    7e73:      	jle	0x5658 <generic_tracepoint_arg+0x2c8>
    7e79:      	jmp	0x549d <generic_tracepoint_arg+0x10d>
    7e7e:      	movq	0x8(%rsp), %r8
    7e83:      	cmpl	%esi, (%r8)
    7e86:      	ja	0x5658 <generic_tracepoint_arg+0x2c8>
    7e8c:      	jmp	0x7e9c <generic_tracepoint_arg+0x2b0c>
    7e8e:      	movq	0x8(%rsp), %r8
    7e93:      	cmpl	%esi, (%r8)
    7e96:      	jb	0x5658 <generic_tracepoint_arg+0x2c8>
    7e9c:      	cmpl	$0x11, %edx
    7e9f:      	jb	0x86da <generic_tracepoint_arg+0x334a>
    7ea5:      	movl	0x18(%r12), %esi
    7eaa:      	cmpl	$0x2, %eax
    7ead:      	jle	0x7ece <generic_tracepoint_arg+0x2b3e>
    7eaf:      	leal	-0x3(%rax), %edi
    7eb2:      	cmpl	$0x2, %edi
    7eb5:      	jae	0x7f08 <generic_tracepoint_arg+0x2b78>
    7eb7:      	movq	0x8(%rsp), %rdi
    7ebc:      	cmpl	%esi, (%rdi)
    7ebe:      	movq	0x10(%rsp), %rdi
    7ec3:      	jne	0x84a3 <generic_tracepoint_arg+0x3113>
    7ec9:      	jmp	0x85b1 <generic_tracepoint_arg+0x3221>
    7ece:      	cmpl	$0x1, %eax
    7ed1:      	je	0x7f29 <generic_tracepoint_arg+0x2b99>
    7ed3:      	cmpl	$0x2, %eax
    7ed6:      	jne	0x84a3 <generic_tracepoint_arg+0x3113>
    7edc:      	cmpl	$0xc, %ecx
    7edf:      	ja	0x8495 <generic_tracepoint_arg+0x3105>
    7ee5:      	movl	$0x1402, %r8d           # imm = 0x1402
    7eeb:      	btl	%ecx, %r8d
    7eef:      	jae	0x8495 <generic_tracepoint_arg+0x3105>
    7ef5:      	movq	0x8(%rsp), %r8
    7efa:      	cmpl	%esi, (%r8)
    7efd:      	jl	0x5658 <generic_tracepoint_arg+0x2c8>
    7f03:      	jmp	0x84a3 <generic_tracepoint_arg+0x3113>
    7f08:      	cmpl	$0xc, %eax
    7f0b:      	movq	0x10(%rsp), %rdi
    7f10:      	jne	0x84a3 <generic_tracepoint_arg+0x3113>
    7f16:      	movq	0x8(%rsp), %r8
    7f1b:      	testl	%esi, (%r8)
    7f1e:      	jne	0x5658 <generic_tracepoint_arg+0x2c8>
    7f24:      	jmp	0x84a3 <generic_tracepoint_arg+0x3113>
    7f29:      	cmpl	$0xc, %ecx
    7f2c:      	ja	0x8485 <generic_tracepoint_arg+0x30f5>
    7f32:      	movl	$0x1402, %r8d           # imm = 0x1402
    7f38:      	btl	%ecx, %r8d
    7f3c:      	jae	0x8485 <generic_tracepoint_arg+0x30f5>
    7f42:      	movq	0x8(%rsp), %r8
    7f47:      	cmpl	%esi, (%r8)
    7f4a:      	jg	0x5658 <generic_tracepoint_arg+0x2c8>
    7f50:      	jmp	0x84a3 <generic_tracepoint_arg+0x3113>
    7f55:      	cmpq	%rdx, %rdi
    7f58:      	setbe	%cl
    7f5b:      	cmpq	%rsi, %rdx
    7f5e:      	jmp	0x81ad <generic_tracepoint_arg+0x2e1d>
    7f63:      	cmpl	$0x2, %ebx
    7f66:      	je	0x8302 <generic_tracepoint_arg+0x2f72>
    7f6c:      	cmpl	$0x3, %ebx
    7f6f:      	jne	0x837f <generic_tracepoint_arg+0x2fef>
    7f75:      	movl	$0x1, %eax
    7f7a:      	leaq	0x40(%rsp), %rsi
    7f7f:      	movq	(%rip), %rdi            # 0x7f86 <generic_tracepoint_arg+0x2bf6>
    7f86:      	jmp	0x8326 <generic_tracepoint_arg+0x2f96>
    7f8b:      	cmpl	$0x6, %ebx
    7f8e:      	je	0x8315 <generic_tracepoint_arg+0x2f85>
    7f94:      	cmpl	$0x7, %ebx
    7f97:      	jne	0x837f <generic_tracepoint_arg+0x2fef>
    7f9d:      	movl	$0x1, %eax
    7fa2:      	leaq	0x40(%rsp), %rsi
    7fa7:      	movq	(%rip), %rdi            # 0x7fae <generic_tracepoint_arg+0x2c1e>
    7fae:      	jmp	0x8326 <generic_tracepoint_arg+0x2f96>
    7fb3:      	cmpq	%rax, %rsi
    7fb6:      	ja	0x549d <generic_tracepoint_arg+0x10d>
    7fbc:      	cmpq	%rdx, %rax
    7fbf:      	jbe	0x5658 <generic_tracepoint_arg+0x2c8>
    7fc5:      	jmp	0x549d <generic_tracepoint_arg+0x10d>
    7fca:      	movq	0x10(%rsp), %rdi
    7fcf:      	movq	0x18(%rsp), %r9
    7fd4:      	movq	%r13, %r11
    7fd7:      	jmp	0x563f <generic_tracepoint_arg+0x2af>
    7fdc:      	cmpl	$0x1, %eax
    7fdf:      	je	0x83dc <generic_tracepoint_arg+0x304c>
    7fe5:      	cmpl	$0x2, %eax
    7fe8:      	jne	0x83ec <generic_tracepoint_arg+0x305c>
    7fee:      	movq	0x8(%rsp), %rsi
    7ff3:      	movzbl	(%rsi), %esi
    7ff6:      	cmpl	%esi, %edx
    7ff8:      	ja	0x5658 <generic_tracepoint_arg+0x2c8>
    7ffe:      	jmp	0x83ec <generic_tracepoint_arg+0x305c>
    8003:      	cmpl	$0x1, %eax
    8006:      	je	0x842b <generic_tracepoint_arg+0x309b>
    800c:      	cmpl	$0x2, %eax
    800f:      	jne	0x843b <generic_tracepoint_arg+0x30ab>
    8015:      	movq	0x8(%rsp), %rsi
    801a:      	movzwl	(%rsi), %esi
    801d:      	cmpl	%esi, %edx
    801f:      	ja	0x5658 <generic_tracepoint_arg+0x2c8>
    8025:      	jmp	0x843b <generic_tracepoint_arg+0x30ab>
    802a:      	movl	$0x1, %ebx
    802f:      	movq	0x10(%rsp), %rdi
    8034:      	jmp	0x8625 <generic_tracepoint_arg+0x3295>
    8039:      	movq	0x10(%rsp), %rdi
    803e:      	movq	0x18(%rsp), %r9
    8043:      	movq	%rbp, %r11
    8046:      	jmp	0x563f <generic_tracepoint_arg+0x2af>
    804b:      	movq	0x28(%rsp), %rax
    8050:      	movw	%bp, (%rax)
    8053:      	leaq	0x2(%rax), %rdi
    8057:      	movl	$0x4, %eax
    805c:      	movq	0x8(%rsp), %rdx
    8061:      	movl	%ebp, %esi
    8063:      	callq	*%rax
    8065:      	movq	0xa0(%rsp), %rsi
    806d:      	subl	%ebp, %esi
    806f:      	jbe	0x808e <generic_tracepoint_arg+0x2cfe>
    8071:      	movq	0x28(%rsp), %rax
    8076:      	leaq	(%rax,%rbp), %rdi
    807a:      	addq	$0x2, %rdi
    807e:      	andl	$0xfff, %esi            # imm = 0xFFF
    8084:      	movl	$0x4, %eax
    8089:      	movq	%r13, %rdx
    808c:      	callq	*%rax
    808e:      	movl	0x98(%rsp), %eax
    8095:      	movl	%eax, 0x40(%rsp)
    8099:      	cmpl	$0x3, %ebx
    809c:      	jg	0x80ce <generic_tracepoint_arg+0x2d3e>
    809e:      	cmpl	$0x1, %ebx
    80a1:      	leaq	0x40(%rsp), %rsi
    80a6:      	jg	0x8396 <generic_tracepoint_arg+0x3006>
    80ac:      	testl	%ebx, %ebx
    80ae:      	je	0x85be <generic_tracepoint_arg+0x322e>
    80b4:      	cmpl	$0x1, %ebx
    80b7:      	jne	0x8614 <generic_tracepoint_arg+0x3284>
    80bd:      	movl	$0x1, %eax
    80c2:      	movq	(%rip), %rdi            # 0x80c9 <generic_tracepoint_arg+0x2d39>
    80c9:      	jmp	0x85f4 <generic_tracepoint_arg+0x3264>
    80ce:      	cmpl	$0x5, %ebx
    80d1:      	leaq	0x40(%rsp), %rsi
    80d6:      	jg	0x83b9 <generic_tracepoint_arg+0x3029>
    80dc:      	cmpl	$0x4, %ebx
    80df:      	je	0x85cc <generic_tracepoint_arg+0x323c>
    80e5:      	cmpl	$0x5, %ebx
    80e8:      	jne	0x8614 <generic_tracepoint_arg+0x3284>
    80ee:      	movl	$0x1, %eax
    80f3:      	movq	(%rip), %rdi            # 0x80fa <generic_tracepoint_arg+0x2d6a>
    80fa:      	jmp	0x85f4 <generic_tracepoint_arg+0x3264>
    80ff:      	movl	$0x1, %eax
    8104:      	movq	(%rip), %rdi            # 0x810b <generic_tracepoint_arg+0x2d7b>
    810b:      	leaq	0x40(%rsp), %rsi
    8110:      	jmp	0x8149 <generic_tracepoint_arg+0x2db9>
    8112:      	movl	$0x1, %eax
    8117:      	leaq	0x40(%rsp), %rsi
    811c:      	movq	(%rip), %rdi            # 0x8123 <generic_tracepoint_arg+0x2d93>
    8123:      	jmp	0x8149 <generic_tracepoint_arg+0x2db9>
    8125:      	movl	$0x1, %eax
    812a:      	leaq	0x40(%rsp), %rsi
    812f:      	movq	(%rip), %rdi            # 0x8136 <generic_tracepoint_arg+0x2da6>
    8136:      	jmp	0x8149 <generic_tracepoint_arg+0x2db9>
    8138:      	movl	$0x1, %eax
    813d:      	leaq	0x40(%rsp), %rsi
    8142:      	movq	(%rip), %rdi            # 0x8149 <generic_tracepoint_arg+0x2db9>
    8149:      	callq	*%rax
    814b:      	testq	%rax, %rax
    814e:      	je	0x8169 <generic_tracepoint_arg+0x2dd9>
    8150:      	movq	%rax, %rdi
    8153:      	movl	$0x1, %eax
    8158:      	movq	0x28(%rsp), %rsi
    815d:      	callq	*%rax
    815f:      	xorl	%ebx, %ebx
    8161:      	testq	%rax, %rax
    8164:      	setne	%bl
    8167:      	jmp	0x816b <generic_tracepoint_arg+0x2ddb>
    8169:      	xorl	%ebx, %ebx
    816b:      	movq	0x10(%rsp), %rdi
    8170:      	movq	0x18(%rsp), %r9
    8175:      	movq	0x20(%rsp), %r11
    817a:      	movl	0x4(%r12), %eax
    817f:      	cmpq	$0x25, %rax
    8183:      	ja	0x5647 <generic_tracepoint_arg+0x2b7>
    8189:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    8193:      	btq	%rax, %rcx
    8197:      	jae	0x5647 <generic_tracepoint_arg+0x2b7>
    819d:      	xorq	$0x1, %rbx
    81a1:      	jmp	0x5647 <generic_tracepoint_arg+0x2b7>
    81a6:      	cmpl	%edx, %edi
    81a8:      	setbe	%cl
    81ab:      	cmpl	%esi, %edx
    81ad:      	setbe	%dl
    81b0:      	andb	%cl, %dl
    81b2:      	orb	%dl, %al
    81b4:      	movq	0x10(%rsp), %rdi
    81b9:      	testb	%al, %al
    81bb:      	je	0x5658 <generic_tracepoint_arg+0x2c8>
    81c1:      	jmp	0x549d <generic_tracepoint_arg+0x10d>
    81c6:      	movq	0x8(%rsp), %r8
    81cb:      	cmpq	%rsi, (%r8)
    81ce:      	ja	0x5658 <generic_tracepoint_arg+0x2c8>
    81d4:      	jmp	0x81e4 <generic_tracepoint_arg+0x2e54>
    81d6:      	movq	0x8(%rsp), %r8
    81db:      	cmpq	%rsi, (%r8)
    81de:      	jb	0x5658 <generic_tracepoint_arg+0x2c8>
    81e4:      	cmpl	$0x21, %edx
    81e7:      	jb	0x86da <generic_tracepoint_arg+0x334a>
    81ed:      	movq	0x28(%r12), %rdx
    81f2:      	cmpl	$0x2, %eax
    81f5:      	jle	0x8224 <generic_tracepoint_arg+0x2e94>
    81f7:      	leal	-0x3(%rax), %ecx
    81fa:      	cmpl	$0x2, %ecx
    81fd:      	jb	0x8257 <generic_tracepoint_arg+0x2ec7>
    81ff:      	cmpl	$0x6, %eax
    8202:      	je	0x5658 <generic_tracepoint_arg+0x2c8>
    8208:      	cmpl	$0xc, %eax
    820b:      	jne	0x549d <generic_tracepoint_arg+0x10d>
    8211:      	movq	0x8(%rsp), %rcx
    8216:      	testq	%rdx, (%rcx)
    8219:      	jne	0x5658 <generic_tracepoint_arg+0x2c8>
    821f:      	jmp	0x86da <generic_tracepoint_arg+0x334a>
    8224:      	cmpl	$0x1, %eax
    8227:      	je	0x82bb <generic_tracepoint_arg+0x2f2b>
    822d:      	cmpl	$0x2, %eax
    8230:      	jne	0x549d <generic_tracepoint_arg+0x10d>
    8236:      	cmpl	$0xc, %ecx
    8239:      	je	0x8244 <generic_tracepoint_arg+0x2eb4>
    823b:      	cmpl	$0xa, %ecx
    823e:      	jne	0x865d <generic_tracepoint_arg+0x32cd>
    8244:      	movq	0x8(%rsp), %rcx
    8249:      	cmpq	%rdx, (%rcx)
    824c:      	jl	0x5658 <generic_tracepoint_arg+0x2c8>
    8252:      	jmp	0x86da <generic_tracepoint_arg+0x334a>
    8257:      	movq	0x8(%rsp), %rcx
    825c:      	cmpq	%rdx, (%rcx)
    825f:      	je	0x85b1 <generic_tracepoint_arg+0x3221>
    8265:      	jmp	0x86da <generic_tracepoint_arg+0x334a>
    826a:      	cmpl	$0xc, %eax
    826d:      	jne	0x83ec <generic_tracepoint_arg+0x305c>
    8273:      	movq	0x8(%rsp), %rsi
    8278:      	movzbl	(%rsi), %esi
    827b:      	testl	%esi, %edx
    827d:      	jne	0x5658 <generic_tracepoint_arg+0x2c8>
    8283:      	jmp	0x83ec <generic_tracepoint_arg+0x305c>
    8288:      	cmpl	$0xc, %eax
    828b:      	jne	0x843b <generic_tracepoint_arg+0x30ab>
    8291:      	movq	0x8(%rsp), %rsi
    8296:      	movzwl	(%rsi), %esi
    8299:      	testl	%esi, %edx
    829b:      	jne	0x5658 <generic_tracepoint_arg+0x2c8>
    82a1:      	jmp	0x843b <generic_tracepoint_arg+0x30ab>
    82a6:      	cmpl	%eax, %esi
    82a8:      	ja	0x549d <generic_tracepoint_arg+0x10d>
    82ae:      	cmpl	%edx, %eax
    82b0:      	jbe	0x5658 <generic_tracepoint_arg+0x2c8>
    82b6:      	jmp	0x549d <generic_tracepoint_arg+0x10d>
    82bb:      	cmpl	$0xc, %ecx
    82be:      	movq	0x8(%rsp), %rsi
    82c3:      	je	0x82ce <generic_tracepoint_arg+0x2f3e>
    82c5:      	cmpl	$0xa, %ecx
    82c8:      	jne	0x866d <generic_tracepoint_arg+0x32dd>
    82ce:      	cmpq	%rdx, (%rsi)
    82d1:      	jg	0x5658 <generic_tracepoint_arg+0x2c8>
    82d7:      	jmp	0x86da <generic_tracepoint_arg+0x334a>
    82dc:      	movl	$0x1, %eax
    82e1:      	movq	(%rip), %rdi            # 0x82e8 <generic_tracepoint_arg+0x2f58>
    82e8:      	leaq	0x40(%rsp), %rsi
    82ed:      	jmp	0x8326 <generic_tracepoint_arg+0x2f96>
    82ef:      	movl	$0x1, %eax
    82f4:      	leaq	0x40(%rsp), %rsi
    82f9:      	movq	(%rip), %rdi            # 0x8300 <generic_tracepoint_arg+0x2f70>
    8300:      	jmp	0x8326 <generic_tracepoint_arg+0x2f96>
    8302:      	movl	$0x1, %eax
    8307:      	leaq	0x40(%rsp), %rsi
    830c:      	movq	(%rip), %rdi            # 0x8313 <generic_tracepoint_arg+0x2f83>
    8313:      	jmp	0x8326 <generic_tracepoint_arg+0x2f96>
    8315:      	movl	$0x1, %eax
    831a:      	leaq	0x40(%rsp), %rsi
    831f:      	movq	(%rip), %rdi            # 0x8326 <generic_tracepoint_arg+0x2f96>
    8326:      	callq	*%rax
    8328:      	testq	%rax, %rax
    832b:      	je	0x8346 <generic_tracepoint_arg+0x2fb6>
    832d:      	movq	%rax, %rdi
    8330:      	movl	$0x1, %eax
    8335:      	movq	0x28(%rsp), %rsi
    833a:      	callq	*%rax
    833c:      	xorl	%ebx, %ebx
    833e:      	testq	%rax, %rax
    8341:      	setne	%bl
    8344:      	jmp	0x8348 <generic_tracepoint_arg+0x2fb8>
    8346:      	xorl	%ebx, %ebx
    8348:      	movq	0x10(%rsp), %rdi
    834d:      	movq	0x18(%rsp), %r9
    8352:      	movq	0x20(%rsp), %r11
    8357:      	movl	0x4(%r12), %eax
    835c:      	cmpq	$0x25, %rax
    8360:      	ja	0x5647 <generic_tracepoint_arg+0x2b7>
    8366:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    8370:      	btq	%rax, %rcx
    8374:      	jb	0x864d <generic_tracepoint_arg+0x32bd>
    837a:      	jmp	0x5647 <generic_tracepoint_arg+0x2b7>
    837f:      	xorl	%ebx, %ebx
    8381:      	movq	0x10(%rsp), %rdi
    8386:      	movl	0x4(%r12), %eax
    838b:      	cmpq	$0x25, %rax
    838f:      	jbe	0x8366 <generic_tracepoint_arg+0x2fd6>
    8391:      	jmp	0x5647 <generic_tracepoint_arg+0x2b7>
    8396:      	cmpl	$0x2, %ebx
    8399:      	je	0x85da <generic_tracepoint_arg+0x324a>
    839f:      	cmpl	$0x3, %ebx
    83a2:      	jne	0x8614 <generic_tracepoint_arg+0x3284>
    83a8:      	movl	$0x1, %eax
    83ad:      	movq	(%rip), %rdi            # 0x83b4 <generic_tracepoint_arg+0x3024>
    83b4:      	jmp	0x85f4 <generic_tracepoint_arg+0x3264>
    83b9:      	cmpl	$0x6, %ebx
    83bc:      	je	0x85e8 <generic_tracepoint_arg+0x3258>
    83c2:      	cmpl	$0x7, %ebx
    83c5:      	jne	0x8614 <generic_tracepoint_arg+0x3284>
    83cb:      	movl	$0x1, %eax
    83d0:      	movq	(%rip), %rdi            # 0x83d7 <generic_tracepoint_arg+0x3047>
    83d7:      	jmp	0x85f4 <generic_tracepoint_arg+0x3264>
    83dc:      	movq	0x8(%rsp), %rsi
    83e1:      	movzbl	(%rsi), %esi
    83e4:      	cmpl	%esi, %edx
    83e6:      	jb	0x5658 <generic_tracepoint_arg+0x2c8>
    83ec:      	cmpl	$0x15, %ecx
    83ef:      	jb	0x86da <generic_tracepoint_arg+0x334a>
    83f5:      	movl	0x1c(%r12), %ecx
    83fa:      	cmpl	$0x2, %eax
    83fd:      	jle	0x8554 <generic_tracepoint_arg+0x31c4>
    8403:      	leal	-0x3(%rax), %edx
    8406:      	cmpl	$0x2, %edx
    8409:      	jb	0x8597 <generic_tracepoint_arg+0x3207>
    840f:      	cmpl	$0x6, %eax
    8412:      	je	0x5658 <generic_tracepoint_arg+0x2c8>
    8418:      	cmpl	$0xc, %eax
    841b:      	jne	0x549d <generic_tracepoint_arg+0x10d>
    8421:      	movq	0x8(%rsp), %rdx
    8426:      	movzbl	(%rdx), %edx
    8429:      	jmp	0x8478 <generic_tracepoint_arg+0x30e8>
    842b:      	movq	0x8(%rsp), %rsi
    8430:      	movzwl	(%rsi), %esi
    8433:      	cmpl	%esi, %edx
    8435:      	jb	0x5658 <generic_tracepoint_arg+0x2c8>
    843b:      	cmpl	$0x15, %ecx
    843e:      	jb	0x86da <generic_tracepoint_arg+0x334a>
    8444:      	movl	0x1c(%r12), %ecx
    8449:      	cmpl	$0x2, %eax
    844c:      	jle	0x8570 <generic_tracepoint_arg+0x31e0>
    8452:      	leal	-0x3(%rax), %edx
    8455:      	cmpl	$0x2, %edx
    8458:      	jb	0x85a1 <generic_tracepoint_arg+0x3211>
    845e:      	cmpl	$0x6, %eax
    8461:      	je	0x5658 <generic_tracepoint_arg+0x2c8>
    8467:      	cmpl	$0xc, %eax
    846a:      	jne	0x549d <generic_tracepoint_arg+0x10d>
    8470:      	movq	0x8(%rsp), %rdx
    8475:      	movzwl	(%rdx), %edx
    8478:      	testl	%edx, %ecx
    847a:      	jne	0x5658 <generic_tracepoint_arg+0x2c8>
    8480:      	jmp	0x86da <generic_tracepoint_arg+0x334a>
    8485:      	movq	0x8(%rsp), %r8
    848a:      	cmpl	%esi, (%r8)
    848d:      	ja	0x5658 <generic_tracepoint_arg+0x2c8>
    8493:      	jmp	0x84a3 <generic_tracepoint_arg+0x3113>
    8495:      	movq	0x8(%rsp), %r8
    849a:      	cmpl	%esi, (%r8)
    849d:      	jb	0x5658 <generic_tracepoint_arg+0x2c8>
    84a3:      	cmpl	$0x15, %edx
    84a6:      	jb	0x86da <generic_tracepoint_arg+0x334a>
    84ac:      	movl	0x1c(%r12), %edx
    84b1:      	cmpl	$0x2, %eax
    84b4:      	jle	0x84e2 <generic_tracepoint_arg+0x3152>
    84b6:      	leal	-0x3(%rax), %ecx
    84b9:      	cmpl	$0x2, %ecx
    84bc:      	jb	0x8519 <generic_tracepoint_arg+0x3189>
    84be:      	cmpl	$0x6, %eax
    84c1:      	je	0x5658 <generic_tracepoint_arg+0x2c8>
    84c7:      	cmpl	$0xc, %eax
    84ca:      	jne	0x549d <generic_tracepoint_arg+0x10d>
    84d0:      	movq	0x8(%rsp), %rcx
    84d5:      	testl	%edx, (%rcx)
    84d7:      	jne	0x5658 <generic_tracepoint_arg+0x2c8>
    84dd:      	jmp	0x86da <generic_tracepoint_arg+0x334a>
    84e2:      	cmpl	$0x1, %eax
    84e5:      	je	0x852b <generic_tracepoint_arg+0x319b>
    84e7:      	cmpl	$0x2, %eax
    84ea:      	jne	0x549d <generic_tracepoint_arg+0x10d>
    84f0:      	cmpl	$0xc, %ecx
    84f3:      	ja	0x86be <generic_tracepoint_arg+0x332e>
    84f9:      	movl	$0x1402, %esi           # imm = 0x1402
    84fe:      	btl	%ecx, %esi
    8501:      	jae	0x86be <generic_tracepoint_arg+0x332e>
    8507:      	movq	0x8(%rsp), %rcx
    850c:      	cmpl	%edx, (%rcx)
    850e:      	jl	0x5658 <generic_tracepoint_arg+0x2c8>
    8514:      	jmp	0x86da <generic_tracepoint_arg+0x334a>
    8519:      	movq	0x8(%rsp), %rcx
    851e:      	cmpl	%edx, (%rcx)
    8520:      	je	0x85b1 <generic_tracepoint_arg+0x3221>
    8526:      	jmp	0x86da <generic_tracepoint_arg+0x334a>
    852b:      	cmpl	$0xc, %ecx
    852e:      	ja	0x86cd <generic_tracepoint_arg+0x333d>
    8534:      	movl	$0x1402, %esi           # imm = 0x1402
    8539:      	btl	%ecx, %esi
    853c:      	jae	0x86cd <generic_tracepoint_arg+0x333d>
    8542:      	movq	0x8(%rsp), %rcx
    8547:      	cmpl	%edx, (%rcx)
    8549:      	jg	0x5658 <generic_tracepoint_arg+0x2c8>
    854f:      	jmp	0x86da <generic_tracepoint_arg+0x334a>
    8554:      	cmpl	$0x1, %eax
    8557:      	je	0x8678 <generic_tracepoint_arg+0x32e8>
    855d:      	cmpl	$0x2, %eax
    8560:      	jne	0x549d <generic_tracepoint_arg+0x10d>
    8566:      	movq	0x8(%rsp), %rdx
    856b:      	movzbl	(%rdx), %edx
    856e:      	jmp	0x858a <generic_tracepoint_arg+0x31fa>
    8570:      	cmpl	$0x1, %eax
    8573:      	je	0x8682 <generic_tracepoint_arg+0x32f2>
    8579:      	cmpl	$0x2, %eax
    857c:      	jne	0x549d <generic_tracepoint_arg+0x10d>
    8582:      	movq	0x8(%rsp), %rdx
    8587:      	movzwl	(%rdx), %edx
    858a:      	cmpl	%edx, %ecx
    858c:      	ja	0x5658 <generic_tracepoint_arg+0x2c8>
    8592:      	jmp	0x86da <generic_tracepoint_arg+0x334a>
    8597:      	movq	0x8(%rsp), %rdx
    859c:      	movzbl	(%rdx), %edx
    859f:      	jmp	0x85a9 <generic_tracepoint_arg+0x3219>
    85a1:      	movq	0x8(%rsp), %rdx
    85a6:      	movzwl	(%rdx), %edx
    85a9:      	cmpl	%edx, %ecx
    85ab:      	jne	0x86da <generic_tracepoint_arg+0x334a>
    85b1:      	xorl	%ebx, %ebx
    85b3:      	cmpl	$0x3, %eax
    85b6:      	sete	%bl
    85b9:      	jmp	0x5647 <generic_tracepoint_arg+0x2b7>
    85be:      	movl	$0x1, %eax
    85c3:      	movq	(%rip), %rdi            # 0x85ca <generic_tracepoint_arg+0x323a>
    85ca:      	jmp	0x85f4 <generic_tracepoint_arg+0x3264>
    85cc:      	movl	$0x1, %eax
    85d1:      	movq	(%rip), %rdi            # 0x85d8 <generic_tracepoint_arg+0x3248>
    85d8:      	jmp	0x85f4 <generic_tracepoint_arg+0x3264>
    85da:      	movl	$0x1, %eax
    85df:      	movq	(%rip), %rdi            # 0x85e6 <generic_tracepoint_arg+0x3256>
    85e6:      	jmp	0x85f4 <generic_tracepoint_arg+0x3264>
    85e8:      	movl	$0x1, %eax
    85ed:      	movq	(%rip), %rdi            # 0x85f4 <generic_tracepoint_arg+0x3264>
    85f4:      	callq	*%rax
    85f6:      	testq	%rax, %rax
    85f9:      	je	0x8614 <generic_tracepoint_arg+0x3284>
    85fb:      	movq	%rax, %rdi
    85fe:      	movl	$0x1, %eax
    8603:      	movq	0x28(%rsp), %rsi
    8608:      	callq	*%rax
    860a:      	xorl	%ebx, %ebx
    860c:      	testq	%rax, %rax
    860f:      	setne	%bl
    8612:      	jmp	0x8616 <generic_tracepoint_arg+0x3286>
    8614:      	xorl	%ebx, %ebx
    8616:      	movq	0x10(%rsp), %rdi
    861b:      	movq	0x18(%rsp), %r9
    8620:      	movq	0x20(%rsp), %r11
    8625:      	movl	0x4(%r12), %eax
    862a:      	cmpq	$0x25, %rax
    862e:      	ja	0x5642 <generic_tracepoint_arg+0x2b2>
    8634:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    863e:      	btq	%rax, %rcx
    8642:      	movq	0x78(%rsp), %r13
    8647:      	jae	0x5647 <generic_tracepoint_arg+0x2b7>
    864d:      	xorl	%eax, %eax
    864f:      	testq	%rbx, %rbx
    8652:      	sete	%al
    8655:      	movq	%rax, %rbx
    8658:      	jmp	0x5647 <generic_tracepoint_arg+0x2b7>
    865d:      	movq	0x8(%rsp), %rcx
    8662:      	cmpq	%rdx, (%rcx)
    8665:      	jb	0x5658 <generic_tracepoint_arg+0x2c8>
    866b:      	jmp	0x86da <generic_tracepoint_arg+0x334a>
    866d:      	cmpq	%rdx, (%rsi)
    8670:      	ja	0x5658 <generic_tracepoint_arg+0x2c8>
    8676:      	jmp	0x86da <generic_tracepoint_arg+0x334a>
    8678:      	movq	0x8(%rsp), %rdx
    867d:      	movzbl	(%rdx), %edx
    8680:      	jmp	0x868a <generic_tracepoint_arg+0x32fa>
    8682:      	movq	0x8(%rsp), %rdx
    8687:      	movzwl	(%rdx), %edx
    868a:      	cmpl	%edx, %ecx
    868c:      	jb	0x5658 <generic_tracepoint_arg+0x2c8>
    8692:      	jmp	0x86da <generic_tracepoint_arg+0x334a>
    8694:      	xorl	%ebx, %ebx
    8696:      	movq	0x10(%rsp), %rdi
    869b:      	movq	0x18(%rsp), %r9
    86a0:      	movq	0x20(%rsp), %r11
    86a5:      	movq	0x68(%rsp), %r15
    86aa:      	movl	0x4(%r12), %eax
    86af:      	cmpq	$0x25, %rax
    86b3:      	jbe	0x8189 <generic_tracepoint_arg+0x2df9>
    86b9:      	jmp	0x5647 <generic_tracepoint_arg+0x2b7>
    86be:      	movq	0x8(%rsp), %rcx
    86c3:      	cmpl	%edx, (%rcx)
    86c5:      	jb	0x5658 <generic_tracepoint_arg+0x2c8>
    86cb:      	jmp	0x86da <generic_tracepoint_arg+0x334a>
    86cd:      	movq	0x8(%rsp), %rcx
    86d2:      	cmpl	%edx, (%rcx)
    86d4:      	ja	0x5658 <generic_tracepoint_arg+0x2c8>
    86da:      	orl	$0x2, %eax
    86dd:      	cmpl	$0x6, %eax
    86e0:      	je	0x5658 <generic_tracepoint_arg+0x2c8>
    86e6:      	jmp	0x549d <generic_tracepoint_arg+0x10d>
    86eb:      	nopl	(%rax,%rax)

00000000000086f0 <generic_tracepoint_actions>:
    86f0:      	pushq	%rbp
    86f1:      	pushq	%r15
    86f3:      	pushq	%r14
    86f5:      	pushq	%r13
    86f7:      	pushq	%r12
    86f9:      	pushq	%rbx
    86fa:      	subq	$0xa8, %rsp
    8701:      	movq	%rdi, 0x70(%rsp)
    8706:      	movl	$0x0, 0x84(%rsp)
    8711:      	movq	(%rip), %rdi            # 0x8718 <generic_tracepoint_actions+0x28>
    8718:      	leaq	0x84(%rsp), %rsi
    8720:      	movl	$0x1, %eax
    8725:      	callq	*%rax
    8727:      	testq	%rax, %rax
    872a:      	je	0x9405 <generic_tracepoint_actions+0xd15>
    8730:      	movq	%rax, %rsi
    8733:      	movl	0x5f04(%rax), %ebx
    8739:      	cmpl	$0x2, %ebx
    873c:      	jl	0x9405 <generic_tracepoint_actions+0xd15>
    8742:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    8749:      	movq	(%rip), %rdi            # 0x8750 <generic_tracepoint_actions+0x60>
    8750:      	movl	$0x1, %eax
    8755:      	callq	*%rax
    8757:      	testq	%rax, %rax
    875a:      	je	0x9405 <generic_tracepoint_actions+0xd15>
    8760:      	movq	%rax, %r14
    8763:      	movl	%ebx, %eax
    8765:      	andl	$0x7ff, %eax            # imm = 0x7FF
    876a:      	addl	(%r14,%rax), %ebx
    876e:      	movl	$0x0, 0x88(%rsp)
    8779:      	movq	(%rip), %rdi            # 0x8780 <generic_tracepoint_actions+0x90>
    8780:      	leaq	0x88(%rsp), %rsi
    8788:      	movl	$0x1, %eax
    878d:      	andl	$0x7ff, %ebx            # imm = 0x7FF
    8793:      	callq	*%rax
    8795:      	testq	%rax, %rax
    8798:      	je	0x87c4 <generic_tracepoint_actions+0xd4>
    879a:      	xorl	%ecx, %ecx
    879c:      	cmpb	$0x0, (%rax)
    879f:      	sete	%cl
    87a2:      	movq	%rcx, %rax
    87a5:      	xorq	$0x9, %rax
    87a9:      	movq	%rax, 0x98(%rsp)
    87b1:      	movq	%rcx, 0x68(%rsp)
    87b6:      	xorq	$0x5, %rcx
    87ba:      	movq	%rcx, 0x90(%rsp)
    87c2:      	jmp	0x87e5 <generic_tracepoint_actions+0xf5>
    87c4:      	movl	$0x4, %eax
    87c9:      	movq	%rax, 0x90(%rsp)
    87d1:      	movb	$0x1, %al
    87d3:      	movq	%rax, 0x68(%rsp)
    87d8:      	movl	$0x8, %eax
    87dd:      	movq	%rax, 0x98(%rsp)
    87e5:      	addq	%rbx, %r14
    87e8:      	movb	$0x1, %al
    87ea:      	movl	%eax, 0x58(%rsp)
    87ee:      	xorl	%ebp, %ebp
    87f0:      	xorl	%r15d, %r15d
    87f3:      	movq	%r14, 0x30(%rsp)
    87f8:      	jmp	0x8828 <generic_tracepoint_actions+0x138>
    87fa:      	incl	%r15d
    87fd:      	movl	0x4(%r14,%r15,4), %eax
    8802:      	movl	%eax, 0x78(%rdx)
    8805:      	nopw	%cs:(%rax,%rax)
    8810:      	movq	%r12, 0x70(%rdx)
    8814:      	incl	%r15d
    8817:      	movl	%r15d, %ebx
    881a:      	incl	%ebp
    881c:      	movl	%ebx, %r15d
    881f:      	cmpl	$0x3, %ebp
    8822:      	je	0x93e1 <generic_tracepoint_actions+0xcf1>
    8828:      	leal	0x4(,%r15,4), %eax
    8830:      	cmpl	(%r14), %eax
    8833:      	jae	0x93e1 <generic_tracepoint_actions+0xcf1>
    8839:      	movl	%r15d, %eax
    883c:      	movslq	0x4(%r14,%rax,4), %r12
    8841:      	movl	$0x0, 0x8c(%rsp)
    884c:      	movl	$0x1, %eax
    8851:      	movq	(%rip), %rdi            # 0x8858 <generic_tracepoint_actions+0x168>
    8858:      	leaq	0x8c(%rsp), %rsi
    8860:      	callq	*%rax
    8862:      	xorl	%ebx, %ebx
    8864:      	testq	%rax, %rax
    8867:      	je	0x881a <generic_tracepoint_actions+0x12a>
    8869:      	movq	%rax, %rdx
    886c:      	cmpl	$0x7, %r12d
    8870:      	jg	0x88a0 <generic_tracepoint_actions+0x1b0>
    8872:      	cmpl	$0x3, %r12d
    8876:      	jg	0x88dc <generic_tracepoint_actions+0x1ec>
    8878:      	cmpl	$0x1, %r12d
    887c:      	jg	0x8a28 <generic_tracepoint_actions+0x338>
    8882:      	testl	%r12d, %r12d
    8885:      	je	0x8c2e <generic_tracepoint_actions+0x53e>
    888b:      	cmpl	$0x1, %r12d
    888f:      	je	0x8a41 <generic_tracepoint_actions+0x351>
    8895:      	jmp	0x8810 <generic_tracepoint_actions+0x120>
    889a:      	nopw	(%rax,%rax)
    88a0:      	cmpl	$0xb, %r12d
    88a4:      	jg	0x89f6 <generic_tracepoint_actions+0x306>
    88aa:      	leal	-0xa(%r12), %eax
    88af:      	cmpl	$0x2, %eax
    88b2:      	jb	0x8ac4 <generic_tracepoint_actions+0x3d4>
    88b8:      	cmpl	$0x8, %r12d
    88bc:      	je	0x8b82 <generic_tracepoint_actions+0x492>
    88c2:      	cmpl	$0x9, %r12d
    88c6:      	jne	0x8810 <generic_tracepoint_actions+0x120>
    88cc:      	movq	%rdx, %rbx
    88cf:      	incl	%r15d
    88d2:      	movl	0x4(%r14,%r15,4), %eax
    88d7:      	jmp	0x8cf0 <generic_tracepoint_actions+0x600>
    88dc:      	leal	-0x6(%r12), %eax
    88e1:      	cmpl	$0x2, %eax
    88e4:      	jb	0x87fa <generic_tracepoint_actions+0x10a>
    88ea:      	cmpl	$0x4, %r12d
    88ee:      	je	0x8b8f <generic_tracepoint_actions+0x49f>
    88f4:      	cmpl	$0x5, %r12d
    88f8:      	jne	0x8810 <generic_tracepoint_actions+0x120>
    88fe:      	leal	0x1(%r15), %eax
    8902:      	movl	0x4(%r14,%rax,4), %eax
    8907:      	addl	$0x2, %r15d
    890b:      	movl	0x4(%r14,%r15,4), %ebx
    8910:      	movq	$0x0, 0x10(%rsp)
    8919:      	movq	$0x0, 0x8(%rsp)
    8922:      	andl	$0x7, %eax
    8925:      	cmpl	$0x4, %eax
    8928:      	ja	0x8810 <generic_tracepoint_actions+0x120>
    892e:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    8936:      	jne	0x8810 <generic_tracepoint_actions+0x120>
    893c:      	movq	0x5e78(%rdx,%rax,8), %rax
    8944:      	andl	$0x7ff, %eax            # imm = 0x7FF
    8949:      	movl	0x90(%rdx,%rax), %eax
    8950:      	movl	%eax, 0x10(%rsp)
    8954:      	movl	$0xe, %eax
    8959:      	movq	%rdx, %r13
    895c:      	callq	*%rax
    895e:      	shrq	$0x20, %rax
    8962:      	movq	%rax, 0x8(%rsp)
    8967:      	movl	$0x1, %eax
    896c:      	leaq	0x8(%rsp), %rsi
    8971:      	movq	(%rip), %rdi            # 0x8978 <generic_tracepoint_actions+0x288>
    8978:      	callq	*%rax
    897a:      	movq	%r13, %rdx
    897d:      	testq	%rax, %rax
    8980:      	je	0x8810 <generic_tracepoint_actions+0x120>
    8986:      	andl	$0x7, %ebx
    8989:      	cmpl	$0x4, %ebx
    898c:      	ja	0x8810 <generic_tracepoint_actions+0x120>
    8992:      	cmpl	$0x0, 0x5ea0(%rdx,%rbx,4)
    899a:      	jne	0x8810 <generic_tracepoint_actions+0x120>
    89a0:      	movq	0x5e78(%rdx,%rbx,8), %rcx
    89a8:      	movl	$0x0, 0x14(%rsp)
    89b0:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    89b6:      	movl	0x90(%rdx,%rcx), %ecx
    89bd:      	movl	%ecx, 0x10(%rsp)
    89c1:      	movq	%rax, %rbx
    89c4:      	movl	$0xe, %eax
    89c9:      	callq	*%rax
    89cb:      	shrq	$0x20, %rax
    89cf:      	movq	%rax, 0x8(%rsp)
    89d4:      	movl	$0x2, %eax
    89d9:      	xorl	%ecx, %ecx
    89db:      	leaq	0x8(%rsp), %rsi
    89e0:      	movq	(%rip), %rdi            # 0x89e7 <generic_tracepoint_actions+0x2f7>
    89e7:      	movq	%rbx, %rdx
    89ea:      	xorl	%ecx, %ecx
    89ec:      	callq	*%rax
    89ee:      	movq	%r13, %rdx
    89f1:      	jmp	0x8810 <generic_tracepoint_actions+0x120>
    89f6:      	cmpl	$0xc, %r12d
    89fa:      	je	0x8d24 <generic_tracepoint_actions+0x634>
    8a00:      	cmpl	$0xd, %r12d
    8a04:      	je	0x8baa <generic_tracepoint_actions+0x4ba>
    8a0a:      	cmpl	$0xe, %r12d
    8a0e:      	jne	0x8810 <generic_tracepoint_actions+0x120>
    8a14:      	movq	%rdx, %rbx
    8a17:      	addl	$0x2, %r15d
    8a1b:      	movq	0x98(%rsp), %r14
    8a23:      	jmp	0x8b9d <generic_tracepoint_actions+0x4ad>
    8a28:      	movl	$0x9, %eax
    8a2d:      	cmpl	$0x2, %r12d
    8a31:      	je	0x8ced <generic_tracepoint_actions+0x5fd>
    8a37:      	cmpl	$0x3, %r12d
    8a3b:      	jne	0x8810 <generic_tracepoint_actions+0x120>
    8a41:      	movq	%rdx, %r13
    8a44:      	leal	0x1(%r15), %eax
    8a48:      	movq	%r14, %rcx
    8a4b:      	movl	0x4(%r14,%rax,4), %r14d
    8a50:      	addl	$0x2, %r15d
    8a54:      	movl	0x4(%rcx,%r15,4), %eax
    8a59:      	movq	%rax, 0x18(%rsp)
    8a5e:      	movq	$0x0, 0x10(%rsp)
    8a67:      	movq	$0x0, 0x8(%rsp)
    8a70:      	movl	$0x0, 0x20(%rsp)
    8a78:      	movl	$0x1, %eax
    8a7d:      	leaq	0x20(%rsp), %rsi
    8a82:      	movq	(%rip), %rdi            # 0x8a89 <generic_tracepoint_actions+0x399>
    8a89:      	callq	*%rax
    8a8b:      	xorl	%ecx, %ecx
    8a8d:      	testq	%rax, %rax
    8a90:      	je	0x8fe5 <generic_tracepoint_actions+0x8f5>
    8a96:      	andl	$0x7, %r14d
    8a9a:      	cmpl	$0x4, %r14d
    8a9e:      	movq	%r13, %rdx
    8aa1:      	ja	0x8ab2 <generic_tracepoint_actions+0x3c2>
    8aa3:      	cmpl	$0x0, 0x5ea0(%rdx,%r14,4)
    8aac:      	je	0x8e30 <generic_tracepoint_actions+0x740>
    8ab2:      	movq	0x30(%rsp), %r14
    8ab7:      	testl	%ecx, %ecx
    8ab9:      	jne	0x881a <generic_tracepoint_actions+0x12a>
    8abf:      	jmp	0x8810 <generic_tracepoint_actions+0x120>
    8ac4:      	incl	%r15d
    8ac7:      	movl	0x4(%r14,%r15,4), %eax
    8acc:      	andl	$0x7, %eax
    8acf:      	xorl	%ecx, %ecx
    8ad1:      	cmpl	$0x4, %eax
    8ad4:      	ja	0x8fed <generic_tracepoint_actions+0x8fd>
    8ada:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    8ae2:      	jne	0x8fed <generic_tracepoint_actions+0x8fd>
    8ae8:      	movq	0x5e78(%rdx,%rax,8), %rax
    8af0:      	andl	$0x7ff, %eax            # imm = 0x7FF
    8af5:      	movq	0xb8(%rdx,%rax), %rax
    8afd:      	movq	%rax, 0x20(%rsp)
    8b02:      	testq	%rax, %rax
    8b05:      	je	0x8fed <generic_tracepoint_actions+0x8fd>
    8b0b:      	movq	%rdx, %r13
    8b0e:      	cmpl	$0xa, %r12d
    8b12:      	jne	0x8ffa <generic_tracepoint_actions+0x90a>
    8b18:      	movl	$0xe, %eax
    8b1d:      	callq	*%rax
    8b1f:      	movq	%rax, 0x18(%rsp)
    8b24:      	shrq	$0x20, %rax
    8b28:      	movl	%eax, 0x8(%rsp)
    8b2c:      	movl	$0x1, %eax
    8b31:      	leaq	0x8(%rsp), %rsi
    8b36:      	movq	(%rip), %rdi            # 0x8b3d <generic_tracepoint_actions+0x44d>
    8b3d:      	callq	*%rax
    8b3f:      	xorl	%ecx, %ecx
    8b41:      	testq	%rax, %rax
    8b44:      	movq	%r13, %rdx
    8b47:      	je	0x8fed <generic_tracepoint_actions+0x8fd>
    8b4d:      	movl	(%rax), %ecx
    8b4f:      	movl	%ecx, 0x8(%rsp)
    8b53:      	movq	0x18(%rsp), %rcx
    8b58:      	movl	%ecx, 0xc(%rsp)
    8b5c:      	movq	0x8(%rax), %rax
    8b60:      	movq	%rax, 0x10(%rsp)
    8b65:      	xorl	%ecx, %ecx
    8b67:      	movl	$0x2, %eax
    8b6c:      	leaq	0x20(%rsp), %rsi
    8b71:      	leaq	0x8(%rsp), %rdx
    8b76:      	movq	(%rip), %rdi            # 0x8b7d <generic_tracepoint_actions+0x48d>
    8b7d:      	jmp	0x8ee9 <generic_tracepoint_actions+0x7f9>
    8b82:      	movl	$0x0, 0x58(%rsp)
    8b8a:      	jmp	0x8810 <generic_tracepoint_actions+0x120>
    8b8f:      	movq	%rdx, %rbx
    8b92:      	incl	%r15d
    8b95:      	movq	0x90(%rsp), %r14
    8b9d:      	movl	%r15d, %r13d
    8ba0:      	leaq	0x8(%rsp), %rsi
    8ba5:      	jmp	0x935e <generic_tracepoint_actions+0xc6e>
    8baa:      	movq	%rdx, 0x18(%rsp)
    8baf:      	movl	$0xe, %eax
    8bb4:      	callq	*%rax
    8bb6:      	movq	%rax, 0x48(%rsp)
    8bbb:      	movl	$0x1, %eax
    8bc0:      	leaq	0x48(%rsp), %rsi
    8bc5:      	movq	(%rip), %rdi            # 0x8bcc <generic_tracepoint_actions+0x4dc>
    8bcc:      	callq	*%rax
    8bce:      	testq	%rax, %rax
    8bd1:      	je	0x8c24 <generic_tracepoint_actions+0x534>
    8bd3:      	movq	0x4(%rax), %rax
    8bd7:      	movq	%rax, 0x20(%rsp)
    8bdc:      	movl	$0x2, 0x28(%rsp)
    8be4:      	movl	$0x1, %eax
    8be9:      	leaq	0x20(%rsp), %rbx
    8bee:      	movq	(%rip), %r13            # 0x8bf5 <generic_tracepoint_actions+0x505>
    8bf5:      	movq	%r13, %rdi
    8bf8:      	movq	%rbx, %rsi
    8bfb:      	callq	*%rax
    8bfd:      	movl	$0x1, 0x3c(%rsp)
    8c05:      	testq	%rax, %rax
    8c08:      	je	0x8eff <generic_tracepoint_actions+0x80f>
    8c0e:      	lock
    8c0f:      	incl	(%rax)
    8c11:      	movl	$0x3, %eax
    8c16:      	leaq	0x48(%rsp), %rsi
    8c1b:      	movq	(%rip), %rdi            # 0x8c22 <generic_tracepoint_actions+0x532>
    8c22:      	callq	*%rax
    8c24:      	movq	0x18(%rsp), %rdx
    8c29:      	jmp	0x8810 <generic_tracepoint_actions+0x120>
    8c2e:      	movq	%rdx, 0x18(%rsp)
    8c33:      	leal	0x1(%r15), %eax
    8c37:      	movl	0x4(%r14,%rax,4), %r13d
    8c3c:      	leal	0x2(%r15), %eax
    8c40:      	movl	0x4(%r14,%rax,4), %ebx
    8c45:      	movl	$0x7d, %eax
    8c4a:      	callq	*%rax
    8c4c:      	movq	%rax, 0x8(%rsp)
    8c51:      	movl	$0x0, 0x48(%rsp)
    8c59:      	movq	%r13, 0xa0(%rsp)
    8c61:      	testq	%r13, %r13
    8c64:      	je	0x9252 <generic_tracepoint_actions+0xb62>
    8c6a:      	movl	$0x1, %eax
    8c6f:      	movq	(%rip), %rdi            # 0x8c76 <generic_tracepoint_actions+0x586>
    8c76:      	leaq	0x48(%rsp), %rsi
    8c7b:      	callq	*%rax
    8c7d:      	testq	%rax, %rax
    8c80:      	je	0x9252 <generic_tracepoint_actions+0xb62>
    8c86:      	movq	%rax, 0x40(%rsp)
    8c8b:      	movq	%rax, %r13
    8c8e:      	movl	$0x1, %eax
    8c93:      	leaq	0x48(%rsp), %rsi
    8c98:      	movq	(%rip), %rdi            # 0x8c9f <generic_tracepoint_actions+0x5af>
    8c9f:      	callq	*%rax
    8ca1:      	movq	%rax, %rdx
    8ca4:      	movq	0x18(%rsp), %rcx
    8ca9:      	movq	0x60(%rcx), %rax
    8cad:      	movq	%rax, (%r13)
    8cb1:      	movq	0x70(%rcx), %rax
    8cb5:      	movq	%r13, 0x60(%rsp)
    8cba:      	movq	%rax, 0x8(%r13)
    8cbe:      	xorl	%r13d, %r13d
    8cc1:      	movl	$0x0, %eax
    8cc6:      	cmpl	$0x2, %ebx
    8cc9:      	je	0x9090 <generic_tracepoint_actions+0x9a0>
    8ccf:      	cmpl	$0x1, %ebx
    8cd2:      	je	0x908d <generic_tracepoint_actions+0x99d>
    8cd8:      	testl	%ebx, %ebx
    8cda:      	jne	0x9252 <generic_tracepoint_actions+0xb62>
    8ce0:      	movq	0x18(%rsp), %rax
    8ce5:      	movl	0x7c(%rax), %eax
    8ce8:      	jmp	0x9090 <generic_tracepoint_actions+0x9a0>
    8ced:      	movq	%rdx, %rbx
    8cf0:      	movl	%r15d, %r13d
    8cf3:      	movl	$0x3, %r14d
    8cf9:      	cmpb	$0x0, 0x68(%rsp)
    8cfe:      	leaq	0x8(%rsp), %rsi
    8d03:      	je	0x935e <generic_tracepoint_actions+0xc6e>
    8d09:      	movslq	%eax, %rdi
    8d0c:      	movl	$0x6d, %eax
    8d11:      	movq	%rsi, %r14
    8d14:      	callq	*%rax
    8d16:      	movq	%r14, %rsi
    8d19:      	movl	$0x2, %r14d
    8d1f:      	jmp	0x935e <generic_tracepoint_actions+0xc6e>
    8d24:      	leal	0x3(%r15), %r13d
    8d28:      	movl	$0x7, %r14d
    8d2e:      	cmpb	$0x0, 0x68(%rsp)
    8d33:      	je	0x8e23 <generic_tracepoint_actions+0x733>
    8d39:      	movl	%r13d, %eax
    8d3c:      	movq	0x30(%rsp), %rcx
    8d41:      	movl	0x4(%rcx,%rax,4), %eax
    8d45:      	cmpq	$0x4, %rax
    8d49:      	movl	%r13d, 0x18(%rsp)
    8d4e:      	ja	0x8d5e <generic_tracepoint_actions+0x66e>
    8d50:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    8d58:      	je	0x92cc <generic_tracepoint_actions+0xbdc>
    8d5e:      	xorl	%r14d, %r14d
    8d61:      	leal	0x2(%r15), %eax
    8d65:      	incl	%r15d
    8d68:      	movq	0x30(%rsp), %rcx
    8d6d:      	movl	0x4(%rcx,%rax,4), %r13d
    8d72:      	movl	0x4(%rcx,%r15,4), %r15d
    8d77:      	movq	%rdx, %rbx
    8d7a:      	movl	0x60(%rdx), %ecx
    8d7d:      	movl	$0xe, %eax
    8d82:      	shlq	$0x20, %r14
    8d86:      	orq	%rcx, %r14
    8d89:      	callq	*%rax
    8d8b:      	movq	%rax, 0x78(%rsp)
    8d90:      	movw	%r15w, 0x20(%rsp)
    8d96:      	movw	%r13w, 0x22(%rsp)
    8d9c:      	movq	%r14, 0x24(%rsp)
    8da1:      	movl	$0x1, %eax
    8da6:      	movq	(%rip), %r14            # 0x8dad <generic_tracepoint_actions+0x6bd>
    8dad:      	leaq	0x78(%rsp), %r13
    8db2:      	movq	%r14, %rdi
    8db5:      	movq	%r13, %rsi
    8db8:      	callq	*%rax
    8dba:      	testq	%rax, %rax
    8dbd:      	je	0x8f65 <generic_tracepoint_actions+0x875>
    8dc3:      	movq	%rax, %r15
    8dc6:      	movq	0x4(%rax), %rax
    8dca:      	movq	%rax, 0x48(%rsp)
    8dcf:      	movl	$0x1, 0x50(%rsp)
    8dd7:      	movl	$0x1, %eax
    8ddc:      	leaq	0x48(%rsp), %r13
    8de1:      	movq	(%rip), %r14            # 0x8de8 <generic_tracepoint_actions+0x6f8>
    8de8:      	movq	%r14, %rdi
    8deb:      	movq	%r13, %rsi
    8dee:      	callq	*%rax
    8df0:      	movl	$0x1, 0x5c(%rsp)
    8df8:      	testq	%rax, %rax
    8dfb:      	je	0x9020 <generic_tracepoint_actions+0x930>
    8e01:      	lock
    8e02:      	incl	(%rax)
    8e04:      	movl	0x18(%rsp), %r13d
    8e09:      	movl	0x28(%rsp), %eax
    8e0d:      	movl	%eax, 0x8(%r15)
    8e11:      	movq	0x20(%rsp), %rax
    8e16:      	movq	%rax, (%r15)
    8e19:      	leaq	0x8(%rsp), %rsi
    8e1e:      	jmp	0x9358 <generic_tracepoint_actions+0xc68>
    8e23:      	movq	%rdx, %rbx
    8e26:      	leaq	0x8(%rsp), %rsi
    8e2b:      	jmp	0x935e <generic_tracepoint_actions+0xc6e>
    8e30:      	movq	%rax, 0x40(%rsp)
    8e35:      	movq	0x5e78(%rdx,%r14,8), %rax
    8e3d:      	movl	$0x0, 0x14(%rsp)
    8e45:      	andl	$0x7ff, %eax            # imm = 0x7FF
    8e4a:      	movl	0x90(%rdx,%rax), %eax
    8e51:      	movl	%eax, 0x10(%rsp)
    8e55:      	movl	$0xe, %eax
    8e5a:      	callq	*%rax
    8e5c:      	shrq	$0x20, %rax
    8e60:      	movq	%rax, 0x8(%rsp)
    8e65:      	cmpl	$0x1, %r12d
    8e69:      	jne	0x8fcf <generic_tracepoint_actions+0x8df>
    8e6f:      	movq	0x18(%rsp), %rax
    8e74:      	andl	$0x7, %eax
    8e77:      	cmpl	$0x4, %eax
    8e7a:      	movq	0x30(%rsp), %r14
    8e7f:      	movl	$0x0, %ecx
    8e84:      	ja	0x8fea <generic_tracepoint_actions+0x8fa>
    8e8a:      	movq	%r13, %rdx
    8e8d:      	cmpl	$0x0, 0x5ea0(%r13,%rax,4)
    8e96:      	jne	0x8fed <generic_tracepoint_actions+0x8fd>
    8e9c:      	movq	0x5e78(%rdx,%rax,8), %rax
    8ea4:      	andl	$0x7ff, %eax            # imm = 0x7FF
    8ea9:      	addq	%rax, %rdx
    8eac:      	addq	$0x90, %rdx
    8eb3:      	movl	0x90(%r13,%rax), %esi
    8ebb:      	andl	$0xfff, %esi            # imm = 0xFFF
    8ec1:      	addq	$0x8, %rsi
    8ec5:      	movl	$0x4, %eax
    8eca:      	movq	0x40(%rsp), %rdi
    8ecf:      	callq	*%rax
    8ed1:      	xorl	%ecx, %ecx
    8ed3:      	movl	$0x2, %eax
    8ed8:      	leaq	0x8(%rsp), %rsi
    8edd:      	movq	(%rip), %rdi            # 0x8ee4 <generic_tracepoint_actions+0x7f4>
    8ee4:      	movq	0x40(%rsp), %rdx
    8ee9:      	xorl	%ecx, %ecx
    8eeb:      	callq	*%rax
    8eed:      	xorl	%ecx, %ecx
    8eef:      	movq	%r13, %rdx
    8ef2:      	testl	%ecx, %ecx
    8ef4:      	jne	0x881a <generic_tracepoint_actions+0x12a>
    8efa:      	jmp	0x8810 <generic_tracepoint_actions+0x120>
    8eff:      	movl	$0x2, %eax
    8f04:      	movl	$0x1, %ecx
    8f09:      	leaq	0x3c(%rsp), %rdx
    8f0e:      	movq	%r13, %rdi
    8f11:      	movq	%rbx, %rsi
    8f14:      	callq	*%rax
    8f16:      	testq	%rax, %rax
    8f19:      	je	0x8c11 <generic_tracepoint_actions+0x521>
    8f1f:      	movq	%rax, %r13
    8f22:      	negl	%eax
    8f24:      	movw	%ax, 0x8(%rsp)
    8f29:      	movw	$0x3, 0xa(%rsp)
    8f30:      	movabsq	$0x20000003b, %rax      # imm = 0x20000003B
    8f3a:      	movq	%rax, 0xc(%rsp)
    8f3f:      	movl	$0x1, %eax
    8f44:      	leaq	0x8(%rsp), %rsi
    8f49:      	movq	(%rip), %rbx            # 0x8f50 <generic_tracepoint_actions+0x860>
    8f50:      	movq	%rbx, %rdi
    8f53:      	callq	*%rax
    8f55:      	testq	%rax, %rax
    8f58:      	je	0x92e6 <generic_tracepoint_actions+0xbf6>
    8f5e:      	incl	(%rax)
    8f60:      	jmp	0x9306 <generic_tracepoint_actions+0xc16>
    8f65:      	movl	$0x2, %eax
    8f6a:      	xorl	%ecx, %ecx
    8f6c:      	leaq	0x20(%rsp), %rdx
    8f71:      	movq	%r14, %rdi
    8f74:      	movq	%r13, %rsi
    8f77:      	xorl	%ecx, %ecx
    8f79:      	callq	*%rax
    8f7b:      	testq	%rax, %rax
    8f7e:      	leaq	0x8(%rsp), %rsi
    8f83:      	movl	0x18(%rsp), %r13d
    8f88:      	je	0x9358 <generic_tracepoint_actions+0xc68>
    8f8e:      	negl	%eax
    8f90:      	movw	%ax, 0x8(%rsp)
    8f95:      	movw	$0x3, 0xa(%rsp)
    8f9c:      	movabsq	$0x20000006b, %rax      # imm = 0x20000006B
    8fa6:      	movq	%rax, 0xc(%rsp)
    8fab:      	movl	$0x1, %eax
    8fb0:      	movq	(%rip), %r14            # 0x8fb7 <generic_tracepoint_actions+0x8c7>
    8fb7:      	movq	%r14, %rdi
    8fba:      	movq	%rsi, %r15
    8fbd:      	callq	*%rax
    8fbf:      	testq	%rax, %rax
    8fc2:      	je	0x9337 <generic_tracepoint_actions+0xc47>
    8fc8:      	incl	(%rax)
    8fca:      	jmp	0x9355 <generic_tracepoint_actions+0xc65>
    8fcf:      	movl	$0x3, %eax
    8fd4:      	leaq	0x8(%rsp), %rsi
    8fd9:      	movq	(%rip), %rdi            # 0x8fe0 <generic_tracepoint_actions+0x8f0>
    8fe0:      	callq	*%rax
    8fe2:      	movq	%rax, %rcx
    8fe5:      	movq	0x30(%rsp), %r14
    8fea:      	movq	%r13, %rdx
    8fed:      	testl	%ecx, %ecx
    8fef:      	jne	0x881a <generic_tracepoint_actions+0x12a>
    8ff5:      	jmp	0x8810 <generic_tracepoint_actions+0x120>
    8ffa:      	movl	$0x3, %eax
    8fff:      	leaq	0x20(%rsp), %rsi
    9004:      	movq	(%rip), %rdi            # 0x900b <generic_tracepoint_actions+0x91b>
    900b:      	callq	*%rax
    900d:      	movq	%rax, %rcx
    9010:      	movq	%r13, %rdx
    9013:      	testl	%ecx, %ecx
    9015:      	jne	0x881a <generic_tracepoint_actions+0x12a>
    901b:      	jmp	0x8810 <generic_tracepoint_actions+0x120>
    9020:      	movl	$0x2, %eax
    9025:      	movl	$0x1, %ecx
    902a:      	leaq	0x5c(%rsp), %rdx
    902f:      	movq	%r14, %rdi
    9032:      	movq	%r13, %rsi
    9035:      	callq	*%rax
    9037:      	testq	%rax, %rax
    903a:      	movl	0x18(%rsp), %r13d
    903f:      	je	0x8e09 <generic_tracepoint_actions+0x719>
    9045:      	movq	%rax, 0x40(%rsp)
    904a:      	negl	%eax
    904c:      	movw	%ax, 0x8(%rsp)
    9051:      	movw	$0x3, 0xa(%rsp)
    9058:      	movabsq	$0x20000003b, %rax      # imm = 0x20000003B
    9062:      	movq	%rax, 0xc(%rsp)
    9067:      	movl	$0x1, %eax
    906c:      	leaq	0x8(%rsp), %rsi
    9071:      	movq	(%rip), %r14            # 0x9078 <generic_tracepoint_actions+0x988>
    9078:      	movq	%r14, %rdi
    907b:      	callq	*%rax
    907d:      	testq	%rax, %rax
    9080:      	je	0x938e <generic_tracepoint_actions+0xc9e>
    9086:      	incl	(%rax)
    9088:      	jmp	0x93ae <generic_tracepoint_actions+0xcbe>
    908d:      	movl	0x10(%rcx), %eax
    9090:      	movl	%eax, %eax
    9092:      	movq	0x60(%rsp), %rcx
    9097:      	movq	%rax, 0x10(%rcx)
    909b:      	movq	0x40(%rsp), %rdi
    90a0:      	addq	$0x18, %rdi
    90a4:      	movl	$0x4, %eax
    90a9:      	movl	$0xc8, %ecx
    90ae:      	movq	%rdi, 0x40(%rsp)
    90b3:      	movl	$0xc8, %esi
    90b8:      	callq	*%rax
    90ba:      	xorl	%r14d, %r14d
    90bd:      	jmp	0x90ce <generic_tracepoint_actions+0x9de>
    90bf:      	nop
    90c0:      	addq	$0x4, %r14
    90c4:      	cmpq	$0x14, %r14
    90c8:      	je	0x91f9 <generic_tracepoint_actions+0xb09>
    90ce:      	movl	$0x0, 0x20(%rsp)
    90d6:      	movl	$0x1, %eax
    90db:      	movq	(%rip), %rdi            # 0x90e2 <generic_tracepoint_actions+0x9f2>
    90e2:      	leaq	0x20(%rsp), %rsi
    90e7:      	callq	*%rax
    90e9:      	testq	%rax, %rax
    90ec:      	je	0x91f9 <generic_tracepoint_actions+0xb09>
    90f2:      	movq	%rax, %rsi
    90f5:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    90fc:      	movl	$0x1, %eax
    9101:      	movq	(%rip), %rdi            # 0x9108 <generic_tracepoint_actions+0xa18>
    9108:      	callq	*%rax
    910a:      	testq	%rax, %rax
    910d:      	je	0x91f9 <generic_tracepoint_actions+0xb09>
    9113:      	cmpl	$-0x1, 0x40(%rax,%r14)
    9119:      	movq	0x18(%rsp), %rdx
    911e:      	je	0x91f9 <generic_tracepoint_actions+0xb09>
    9124:      	movq	0x5e78(%rdx,%r14,2), %rax
    912c:      	movl	0x4(%rdx), %ecx
    912f:      	cmpq	%rcx, %rax
    9132:      	jge	0x91f9 <generic_tracepoint_actions+0xb09>
    9138:      	cmpq	$0x10, %r14
    913c:      	je	0x91a9 <generic_tracepoint_actions+0xab9>
    913e:      	movl	$0x0, 0x20(%rsp)
    9146:      	movl	$0x1, %eax
    914b:      	movq	(%rip), %rdi            # 0x9152 <generic_tracepoint_actions+0xa62>
    9152:      	leaq	0x20(%rsp), %rsi
    9157:      	callq	*%rax
    9159:      	testq	%rax, %rax
    915c:      	je	0x919c <generic_tracepoint_actions+0xaac>
    915e:      	movq	%rax, %rsi
    9161:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    9168:      	movl	$0x1, %eax
    916d:      	movq	(%rip), %rdi            # 0x9174 <generic_tracepoint_actions+0xa84>
    9174:      	callq	*%rax
    9176:      	testq	%rax, %rax
    9179:      	je	0x919c <generic_tracepoint_actions+0xaac>
    917b:      	cmpl	$-0x1, 0x44(%rax,%r14)
    9181:      	movq	0x18(%rsp), %rdx
    9186:      	movq	0x5e78(%rdx,%r14,2), %rax
    918e:      	je	0x91a9 <generic_tracepoint_actions+0xab9>
    9190:      	movl	0x5e80(%rdx,%r14,2), %ebx
    9198:      	subl	%eax, %ebx
    919a:      	jmp	0x91b1 <generic_tracepoint_actions+0xac1>
    919c:      	movq	0x18(%rsp), %rdx
    91a1:      	movq	0x5e78(%rdx,%r14,2), %rax
    91a9:      	movl	0x4(%rdx), %ebx
    91ac:      	subl	%eax, %ebx
    91ae:      	addl	$0x4, %ebx
    91b1:      	testl	%ebx, %ebx
    91b3:      	jle	0x90c0 <generic_tracepoint_actions+0x9d0>
    91b9:      	addl	$0x3ffc, %eax           # imm = 0x3FFC
    91be:      	andl	$0x3fff, %eax           # imm = 0x3FFF
    91c3:      	cmpl	$0x28, %ebx
    91c6:      	movl	$0x28, %ecx
    91cb:      	cmovgel	%ecx, %ebx
    91ce:      	movzbl	%r13b, %r13d
    91d2:      	movq	0x40(%rsp), %rcx
    91d7:      	leaq	(%rcx,%r13), %rdi
    91db:      	addq	%rax, %rdx
    91de:      	addq	$0x90, %rdx
    91e5:      	movl	$0x4, %eax
    91ea:      	movl	%ebx, %esi
    91ec:      	callq	*%rax
    91ee:      	addl	%r13d, %ebx
    91f1:      	movl	%ebx, %r13d
    91f4:      	jmp	0x90c0 <generic_tracepoint_actions+0x9d0>
    91f9:      	movl	$0x1, %eax
    91fe:      	movq	(%rip), %rdi            # 0x9205 <generic_tracepoint_actions+0xb15>
    9205:      	movq	0x60(%rsp), %rsi
    920a:      	callq	*%rax
    920c:      	testq	%rax, %rax
    920f:      	movq	0x30(%rsp), %r14
    9214:      	je	0x9236 <generic_tracepoint_actions+0xb46>
    9216:      	imulq	$-0xf4240, 0xa0(%rsp), %rcx # imm = 0xFFF0BDC0
    9222:      	addq	0x8(%rsp), %rcx
    9227:      	cmpq	%rcx, (%rax)
    922a:      	jbe	0x9236 <generic_tracepoint_actions+0xb46>
    922c:      	movl	$0x0, 0x58(%rsp)
    9234:      	jmp	0x9252 <generic_tracepoint_actions+0xb62>
    9236:      	movl	$0x2, %eax
    923b:      	xorl	%ecx, %ecx
    923d:      	movq	(%rip), %rdi            # 0x9244 <generic_tracepoint_actions+0xb54>
    9244:      	leaq	0x8(%rsp), %rdx
    9249:      	movq	0x60(%rsp), %rsi
    924e:      	xorl	%ecx, %ecx
    9250:      	callq	*%rax
    9252:      	leal	0x3(%r15), %eax
    9256:      	cmpl	$0x0, 0x4(%r14,%rax,4)
    925c:      	movq	0x18(%rsp), %rdx
    9261:      	je	0x928a <generic_tracepoint_actions+0xb9a>
    9263:      	orb	$0x2, 0x1(%rdx)
    9267:      	movl	$0x1b, %eax
    926c:      	xorl	%ecx, %ecx
    926e:      	movq	(%rip), %rsi            # 0x9275 <generic_tracepoint_actions+0xb85>
    9275:      	movq	0x70(%rsp), %rdi
    927a:      	xorl	%edx, %edx
    927c:      	callq	*%rax
    927e:      	movq	0x18(%rsp), %rdx
    9283:      	movq	%rax, 0x80(%rdx)
    928a:      	addl	$0x4, %r15d
    928e:      	cmpl	$0x0, 0x4(%r14,%r15,4)
    9294:      	je	0x8810 <generic_tracepoint_actions+0x120>
    929a:      	orb	$0x4, 0x1(%rdx)
    929e:      	movl	$0x1b, %eax
    92a3:      	movq	(%rip), %rsi            # 0x92aa <generic_tracepoint_actions+0xbba>
    92aa:      	movl	$0x100, %ecx            # imm = 0x100
    92af:      	movq	0x70(%rsp), %rdi
    92b4:      	movl	$0x100, %edx            # imm = 0x100
    92b9:      	callq	*%rax
    92bb:      	movq	0x18(%rsp), %rdx
    92c0:      	movq	%rax, 0x88(%rdx)
    92c7:      	jmp	0x8810 <generic_tracepoint_actions+0x120>
    92cc:      	movq	0x5e78(%rdx,%rax,8), %rax
    92d4:      	andl	$0x7ff, %eax            # imm = 0x7FF
    92d9:      	movq	0x90(%rdx,%rax), %r14
    92e1:      	jmp	0x8d61 <generic_tracepoint_actions+0x671>
    92e6:      	movl	$0x1, 0x78(%rsp)
    92ee:      	movl	$0x2, %eax
    92f3:      	xorl	%ecx, %ecx
    92f5:      	leaq	0x78(%rsp), %rdx
    92fa:      	leaq	0x8(%rsp), %rsi
    92ff:      	movq	%rbx, %rdi
    9302:      	xorl	%ecx, %ecx
    9304:      	callq	*%rax
    9306:      	testl	%r13d, %r13d
    9309:      	je	0x8c11 <generic_tracepoint_actions+0x521>
    930f:      	movl	$0x1, %eax
    9314:      	leaq	0x20(%rsp), %rsi
    9319:      	movq	(%rip), %rdi            # 0x9320 <generic_tracepoint_actions+0xc30>
    9320:      	callq	*%rax
    9322:      	testq	%rax, %rax
    9325:      	je	0x8c11 <generic_tracepoint_actions+0x521>
    932b:      	movl	0x3c(%rsp), %ecx
    932f:      	lock
    9330:      	addl	%ecx, (%rax)
    9332:      	jmp	0x8c11 <generic_tracepoint_actions+0x521>
    9337:      	movl	$0x1, 0x48(%rsp)
    933f:      	movl	$0x2, %eax
    9344:      	xorl	%ecx, %ecx
    9346:      	movq	%r15, %rsi
    9349:      	leaq	0x48(%rsp), %rdx
    934e:      	movq	%r14, %rdi
    9351:      	xorl	%ecx, %ecx
    9353:      	callq	*%rax
    9355:      	movq	%r15, %rsi
    9358:      	movl	$0x6, %r14d
    935e:      	movl	$0x0, 0x8(%rsp)
    9366:      	movl	$0x1, %eax
    936b:      	movq	(%rip), %rdi            # 0x9372 <generic_tracepoint_actions+0xc82>
    9372:      	callq	*%rax
    9374:      	testq	%rax, %rax
    9377:      	je	0x937e <generic_tracepoint_actions+0xc8e>
    9379:      	lock
    937a:      	incq	(%rax,%r14,8)
    937e:      	movl	%r13d, %r15d
    9381:      	movq	0x30(%rsp), %r14
    9386:      	movq	%rbx, %rdx
    9389:      	jmp	0x8810 <generic_tracepoint_actions+0x120>
    938e:      	movl	$0x1, 0x3c(%rsp)
    9396:      	movl	$0x2, %eax
    939b:      	xorl	%ecx, %ecx
    939d:      	leaq	0x3c(%rsp), %rdx
    93a2:      	leaq	0x8(%rsp), %rsi
    93a7:      	movq	%r14, %rdi
    93aa:      	xorl	%ecx, %ecx
    93ac:      	callq	*%rax
    93ae:      	cmpl	$0x0, 0x40(%rsp)
    93b3:      	movq	(%rip), %rdi            # 0x93ba <generic_tracepoint_actions+0xcca>
    93ba:      	je	0x8e09 <generic_tracepoint_actions+0x719>
    93c0:      	movl	$0x1, %eax
    93c5:      	leaq	0x48(%rsp), %rsi
    93ca:      	callq	*%rax
    93cc:      	testq	%rax, %rax
    93cf:      	je	0x8e09 <generic_tracepoint_actions+0x719>
    93d5:      	movl	0x5c(%rsp), %ecx
    93d9:      	lock
    93da:      	addl	%ecx, (%rax)
    93dc:      	jmp	0x8e09 <generic_tracepoint_actions+0x719>
    93e1:      	cmpb	$0x0, 0x58(%rsp)
    93e6:      	je	0x9405 <generic_tracepoint_actions+0xd15>
    93e8:      	movq	(%rip), %rsi            # 0x93ef <generic_tracepoint_actions+0xcff>
    93ef:      	movl	$0x5, %ecx
    93f4:      	movl	$0xc, %eax
    93f9:      	movq	0x70(%rsp), %rdi
    93fe:      	movl	$0x5, %edx
    9403:      	callq	*%rax
    9405:      	xorl	%eax, %eax
    9407:      	addq	$0xa8, %rsp
    940e:      	popq	%rbx
    940f:      	popq	%r12
    9411:      	popq	%r13
    9413:      	popq	%r14
    9415:      	popq	%r15
    9417:      	popq	%rbp
    9418:      	retq
    9419:      	nopl	(%rax)

0000000000009420 <generic_tracepoint_output>:
    9420:      	pushq	%rbp
    9421:      	pushq	%r15
    9423:      	pushq	%r14
    9425:      	pushq	%r13
    9427:      	pushq	%r12
    9429:      	pushq	%rbx
    942a:      	subq	$0x78, %rsp
    942e:      	movq	%rdi, %rbx
    9431:      	movl	$0x0, 0x14(%rsp)
    9439:      	movq	(%rip), %rdi            # 0x9440 <generic_tracepoint_output+0x20>
    9440:      	leaq	0x14(%rsp), %rsi
    9445:      	movl	$0x1, %eax
    944a:      	callq	*%rax
    944c:      	testq	%rax, %rax
    944f:      	je	0x992a <generic_tracepoint_output+0x50a>
    9455:      	movq	%rax, %r14
    9458:      	cmpq	$0x0, 0x5ee8(%rax)
    9460:      	je	0x9774 <generic_tracepoint_output+0x354>
    9466:      	movl	$0xe, %eax
    946b:      	callq	*%rax
    946d:      	movq	%rax, %r15
    9470:      	shrq	$0x20, %r15
    9474:      	movl	$0x23, %eax
    9479:      	callq	*%rax
    947b:      	movq	%rax, %r12
    947e:      	movl	%r15d, 0x28(%rsp)
    9483:      	movq	(%rip), %rdi            # 0x948a <generic_tracepoint_output+0x6a>
    948a:      	leaq	0x28(%rsp), %rsi
    948f:      	movl	$0x1, %eax
    9494:      	callq	*%rax
    9496:      	testq	%rax, %rax
    9499:      	je	0x9774 <generic_tracepoint_output+0x354>
    949f:      	movq	%rax, %r15
    94a2:      	leaq	0xd70(%r12), %rdx
    94aa:      	leaq	0x70(%rsp), %rdi
    94af:      	movl	$0x8, %ecx
    94b4:      	movl	$0x4, %eax
    94b9:      	leaq	0x28(%r15), %r13
    94bd:      	movl	$0x4, %ebp
    94c2:      	movl	$0x8, %esi
    94c7:      	callq	*%rax
    94c9:      	movq	0x70(%rsp), %rcx
    94ce:      	leaq	0x28(%rsp), %rdi
    94d3:      	movl	$0x48, %edx
    94d8:      	movl	$0x4, %eax
    94dd:      	movq	0x70(%rsp), %rdx
    94e2:      	movl	$0x48, %esi
    94e7:      	callq	*%rax
    94e9:      	movl	$0x218, %edx            # imm = 0x218
    94ee:      	movq	0x30(%rsp), %rcx
    94f3:      	addq	%rdx, %rcx
    94f6:      	movl	$0x4, %esi
    94fb:      	movl	$0x4, %eax
    9500:      	addq	0x30(%rsp), %rdx
    9505:      	movq	%r13, %rdi
    9508:      	movl	$0x4, %esi
    950d:      	callq	*%rax
    950f:      	leaq	0x2c(%r15), %rdi
    9513:      	movl	$0x4d8, %edx            # imm = 0x4D8
    9518:      	movq	0x38(%rsp), %rcx
    951d:      	addq	%rdx, %rcx
    9520:      	movl	$0x4, %esi
    9525:      	movl	$0x4, %eax
    952a:      	addq	0x38(%rsp), %rdx
    952f:      	movl	$0x4, %esi
    9534:      	callq	*%rax
    9536:      	leaq	0x30(%r15), %rdi
    953a:      	movq	0x40(%rsp), %rcx
    953f:      	addq	$0x58, %rcx
    9543:      	movl	$0x4, %edx
    9548:      	movl	$0x4, %eax
    954d:      	movq	0x40(%rsp), %rdx
    9552:      	addq	$0x58, %rdx
    9556:      	movl	$0x4, %esi
    955b:      	callq	*%rax
    955d:      	movq	$0x0, 0x8(%rsp)
    9566:      	leaq	0xb58(%r12), %rdx
    956e:      	leaq	0x8(%rsp), %rdi
    9573:      	movl	$0x8, %ecx
    9578:      	movl	$0x4, %eax
    957d:      	movl	$0x8, %esi
    9582:      	callq	*%rax
    9584:      	movq	0x8(%rsp), %rcx
    9589:      	testq	%rcx, %rcx
    958c:      	je	0x9622 <generic_tracepoint_output+0x202>
    9592:      	movl	$0x0, 0x10(%rsp)
    959a:      	addq	$0x4, %rcx
    959e:      	leaq	0x10(%rsp), %rdi
    95a3:      	movl	$0x4, %eax
    95a8:      	movq	0x8(%rsp), %rdx
    95ad:      	addq	$0x4, %rdx
    95b1:      	movl	$0x4, %esi
    95b6:      	callq	*%rax
    95b8:      	movq	0x8(%rsp), %rax
    95bd:      	movslq	0x10(%rsp), %rcx
    95c2:      	shlq	$0x4, %rcx
    95c6:      	addq	%rax, %rcx
    95c9:      	addq	$0x80, %rcx
    95d0:      	leaq	0x18(%rsp), %rdi
    95d5:      	movl	$0x10, %edx
    95da:      	movl	$0x4, %eax
    95df:      	movq	0x8(%rsp), %rcx
    95e4:      	movslq	0x10(%rsp), %rdx
    95e9:      	shlq	$0x4, %rdx
    95ed:      	addq	%rcx, %rdx
    95f0:      	addq	$0x80, %rdx
    95f7:      	movl	$0x10, %esi
    95fc:      	callq	*%rax
    95fe:      	leaq	0x34(%r15), %rdi
    9602:      	movl	$0x158, %edx            # imm = 0x158
    9607:      	movq	0x20(%rsp), %rcx
    960c:      	addq	%rdx, %rcx
    960f:      	movl	$0x4, %eax
    9614:      	addq	0x20(%rsp), %rdx
    9619:      	movl	$0x4, %esi
    961e:      	callq	*%rax
    9620:      	jmp	0x962a <generic_tracepoint_output+0x20a>
    9622:      	movl	$0x0, 0x34(%r15)
    962a:      	leaq	0x38(%r15), %rdi
    962e:      	movl	$0x158, %r13d           # imm = 0x158
    9634:      	movq	0x48(%rsp), %rcx
    9639:      	addq	%r13, %rcx
    963c:      	movl	$0x4, %edx
    9641:      	movl	$0x4, %eax
    9646:      	movq	0x48(%rsp), %rdx
    964b:      	addq	%r13, %rdx
    964e:      	movl	$0x4, %esi
    9653:      	callq	*%rax
    9655:      	leaq	0x3c(%r15), %rdi
    9659:      	movl	$0x118, %edx            # imm = 0x118
    965e:      	movq	0x50(%rsp), %rcx
    9663:      	addq	%rdx, %rcx
    9666:      	movl	$0x4, %esi
    966b:      	movl	$0x4, %eax
    9670:      	addq	0x50(%rsp), %rdx
    9675:      	movl	$0x4, %esi
    967a:      	callq	*%rax
    967c:      	leaq	0x40(%r15), %rdi
    9680:      	movl	$0x98, %ebp
    9685:      	movq	0x58(%rsp), %rcx
    968a:      	addq	%rbp, %rcx
    968d:      	movl	$0x4, %edx
    9692:      	movl	$0x4, %eax
    9697:      	movq	0x58(%rsp), %rdx
    969c:      	addq	%rbp, %rdx
    969f:      	movl	$0x4, %esi
    96a4:      	callq	*%rax
    96a6:      	leaq	0x44(%r15), %rdi
    96aa:      	movq	0x60(%rsp), %rcx
    96af:      	addq	%rbp, %rcx
    96b2:      	movl	$0x4, %edx
    96b7:      	movl	$0x4, %eax
    96bc:      	addq	0x60(%rsp), %rbp
    96c1:      	movl	$0x4, %esi
    96c6:      	movq	%rbp, %rdx
    96c9:      	callq	*%rax
    96cb:      	leaq	0x48(%r15), %rdi
    96cf:      	movq	0x68(%rsp), %rcx
    96d4:      	addq	$0x58, %rcx
    96d8:      	movl	$0x4, %edx
    96dd:      	movl	$0x4, %eax
    96e2:      	movq	0x68(%rsp), %rdx
    96e7:      	addq	$0x58, %rdx
    96eb:      	movl	$0x4, %esi
    96f0:      	callq	*%rax
    96f2:      	movq	$0x0, 0x18(%rsp)
    96fb:      	movq	$0x0, 0x8(%rsp)
    9704:      	addq	$0xd00, %r12            # imm = 0xD00
    970b:      	leaq	0x18(%rsp), %rdi
    9710:      	movl	$0x8, %ecx
    9715:      	movl	$0x4, %eax
    971a:      	movl	$0x8, %esi
    971f:      	movq	%r12, %rdx
    9722:      	callq	*%rax
    9724:      	movl	$0x90, %edx
    9729:      	movq	0x18(%rsp), %rcx
    972e:      	addq	%rdx, %rcx
    9731:      	leaq	0x8(%rsp), %rdi
    9736:      	movl	$0x8, %esi
    973b:      	movl	$0x4, %eax
    9740:      	addq	0x18(%rsp), %rdx
    9745:      	movl	$0x8, %esi
    974a:      	callq	*%rax
    974c:      	addq	$0x4c, %r15
    9750:      	movq	0x8(%rsp), %rcx
    9755:      	addq	%r13, %rcx
    9758:      	movl	$0x4, %edx
    975d:      	movl	$0x4, %eax
    9762:      	addq	0x8(%rsp), %r13
    9767:      	movq	%r15, %rdi
    976a:      	movl	$0x4, %esi
    976f:      	movq	%r13, %rdx
    9772:      	callq	*%rax
    9774:      	cmpq	$0x0, 0x5ef0(%r14)
    977c:      	je	0x9835 <generic_tracepoint_output+0x415>
    9782:      	movl	$0xe, %eax
    9787:      	callq	*%rax
    9789:      	movq	%rax, %r15
    978c:      	shrq	$0x20, %r15
    9790:      	movl	$0x23, %eax
    9795:      	callq	*%rax
    9797:      	movq	%rax, %r12
    979a:      	movl	%r15d, 0x28(%rsp)
    979f:      	movq	(%rip), %rdi            # 0x97a6 <generic_tracepoint_output+0x386>
    97a6:      	leaq	0x28(%rsp), %rsi
    97ab:      	movl	$0x1, %eax
    97b0:      	callq	*%rax
    97b2:      	testq	%rax, %rax
    97b5:      	je	0x9835 <generic_tracepoint_output+0x415>
    97b7:      	leaq	0x50(%rax), %r15
    97bb:      	addq	$0xd00, %r12            # imm = 0xD00
    97c2:      	leaq	0x28(%rsp), %rdi
    97c7:      	movl	$0x8, %ecx
    97cc:      	movq	%rax, %r13
    97cf:      	movl	$0x4, %eax
    97d4:      	movl	$0x8, %esi
    97d9:      	movq	%r12, %rdx
    97dc:      	callq	*%rax
    97de:      	movq	0x28(%rsp), %r12
    97e3:      	leaq	0x58(%r13), %rdi
    97e7:      	leaq	0x40(%r12), %rdx
    97ec:      	movl	$0x8, %ecx
    97f1:      	movl	$0x4, %eax
    97f6:      	movl	$0x8, %esi
    97fb:      	callq	*%rax
    97fd:      	addq	$0x60, %r13
    9801:      	leaq	0x30(%r12), %rdx
    9806:      	movl	$0x8, %ecx
    980b:      	movl	$0x4, %eax
    9810:      	movq	%r13, %rdi
    9813:      	movl	$0x8, %esi
    9818:      	callq	*%rax
    981a:      	addq	$0x38, %r12
    981e:      	movl	$0x8, %ecx
    9823:      	movl	$0x4, %eax
    9828:      	movq	%r15, %rdi
    982b:      	movl	$0x8, %esi
    9830:      	movq	%r12, %rdx
    9833:      	callq	*%rax
    9835:      	movl	$0x90, %eax
    983a:      	addl	0x4(%r14), %eax
    983e:      	andl	$0x7fff, %eax           # imm = 0x7FFF
    9843:      	cmpl	$0x2328, %eax           # imm = 0x2328
    9848:      	movl	$0x2328, %r8d           # imm = 0x2328
    984e:      	cmovbl	%eax, %r8d
    9852:      	movq	(%rip), %rsi            # 0x9859 <generic_tracepoint_output+0x439>
    9859:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    985e:      	movl	$0x19, %eax
    9863:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    9868:      	movq	%rbx, %rdi
    986b:      	movq	%r14, %rcx
    986e:      	callq	*%rax
    9870:      	testq	%rax, %rax
    9873:      	js	0x98a3 <generic_tracepoint_output+0x483>
    9875:      	movl	$0x0, 0x28(%rsp)
    987d:      	movq	(%rip), %rdi            # 0x9884 <generic_tracepoint_output+0x464>
    9884:      	leaq	0x28(%rsp), %rsi
    9889:      	movl	$0x1, %eax
    988e:      	callq	*%rax
    9890:      	testq	%rax, %rax
    9893:      	je	0x992a <generic_tracepoint_output+0x50a>
    9899:      	lock
    989a:      	incq	0x8(%rax)
    989e:      	jmp	0x992a <generic_tracepoint_output+0x50a>
    98a3:      	movq	%rax, %rbx
    98a6:      	movl	$0x0, 0x28(%rsp)
    98ae:      	movq	(%rip), %rdi            # 0x98b5 <generic_tracepoint_output+0x495>
    98b5:      	leaq	0x28(%rsp), %rsi
    98ba:      	movl	$0x1, %eax
    98bf:      	callq	*%rax
    98c1:      	testq	%rax, %rax
    98c4:      	je	0x992a <generic_tracepoint_output+0x50a>
    98c6:      	cmpq	$-0xc, %rbx
    98ca:      	jg	0x98e6 <generic_tracepoint_output+0x4c6>
    98cc:      	cmpq	$-0x1c, %rbx
    98d0:      	je	0x9900 <generic_tracepoint_output+0x4e0>
    98d2:      	cmpq	$-0x16, %rbx
    98d6:      	je	0x9918 <generic_tracepoint_output+0x4f8>
    98d8:      	cmpq	$-0x10, %rbx
    98dc:      	jne	0x9910 <generic_tracepoint_output+0x4f0>
    98de:      	addq	$0x328, %rax            # imm = 0x328
    98e4:      	jmp	0x9926 <generic_tracepoint_output+0x506>
    98e6:      	cmpq	$-0xb, %rbx
    98ea:      	je	0x9908 <generic_tracepoint_output+0x4e8>
    98ec:      	cmpq	$-0x7, %rbx
    98f0:      	je	0x9920 <generic_tracepoint_output+0x500>
    98f2:      	cmpq	$-0x2, %rbx
    98f6:      	jne	0x9910 <generic_tracepoint_output+0x4f0>
    98f8:      	addq	$0x318, %rax            # imm = 0x318
    98fe:      	jmp	0x9926 <generic_tracepoint_output+0x506>
    9900:      	addq	$0x338, %rax            # imm = 0x338
    9906:      	jmp	0x9926 <generic_tracepoint_output+0x506>
    9908:      	addq	$0x340, %rax            # imm = 0x340
    990e:      	jmp	0x9926 <generic_tracepoint_output+0x506>
    9910:      	addq	$0x310, %rax            # imm = 0x310
    9916:      	jmp	0x9926 <generic_tracepoint_output+0x506>
    9918:      	addq	$0x330, %rax            # imm = 0x330
    991e:      	jmp	0x9926 <generic_tracepoint_output+0x506>
    9920:      	addq	$0x320, %rax            # imm = 0x320
    9926:      	lock
    9927:      	incq	(%rax)
    992a:      	xorl	%eax, %eax
    992c:      	addq	$0x78, %rsp
    9930:      	popq	%rbx
    9931:      	popq	%r12
    9933:      	popq	%r13
    9935:      	popq	%r14
    9937:      	popq	%r15
    9939:      	popq	%rbp
    993a:      	retq

Disassembly of section tracepoint/generic_tracepoint:

0000000000000000 <generic_tracepoint_event>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x88, %rsp
      11:      	movq	%rdi, %rbx
      14:      	movl	$0x0, 0x80(%rsp)
      1f:      	movq	(%rip), %rdi            # 0x26 <generic_tracepoint_event+0x26>
      26:      	leaq	0x80(%rsp), %rsi
      2e:      	movl	$0x1, %eax
      33:      	callq	*%rax
      35:      	testq	%rax, %rax
      38:      	je	0x32ec <generic_tracepoint_event+0x32ec>
      3e:      	movq	%rax, %r14
      41:      	movq	(%rip), %rdi            # 0x48 <generic_tracepoint_event+0x48>
      48:      	leaq	0x80(%rsp), %rsi
      50:      	movl	$0x1, %eax
      55:      	callq	*%rax
      57:      	testq	%rax, %rax
      5a:      	je	0x32ec <generic_tracepoint_event+0x32ec>
      60:      	movq	%rax, %r15
      63:      	movl	0x64(%rax), %eax
      66:      	movl	%eax, 0x7c(%rsp)
      6a:      	testl	%eax, %eax
      6c:      	je	0x23f <generic_tracepoint_event+0x23f>
      72:      	movq	(%rip), %rdi            # 0x79 <generic_tracepoint_event+0x79>
      79:      	leaq	0x7c(%rsp), %rsi
      7e:      	movl	$0x1, %eax
      83:      	callq	*%rax
      85:      	testq	%rax, %rax
      88:      	je	0x32ec <generic_tracepoint_event+0x32ec>
      8e:      	movq	%rax, %r12
      91:      	movl	$0x0, 0x84(%rsp)
      9c:      	movq	(%rip), %rdi            # 0xa3 <generic_tracepoint_event+0xa3>
      a3:      	leaq	0x84(%rsp), %rsi
      ab:      	movl	$0x1, %eax
      b0:      	callq	*%rax
      b2:      	testq	%rax, %rax
      b5:      	je	0xdb <generic_tracepoint_event+0xdb>
      b7:      	cmpq	$0x63677270, 0x20(%rax) # imm = 0x63677270
      bf:      	jne	0xdf <generic_tracepoint_event+0xdf>
      c1:      	movl	$0x50, %eax
      c6:      	callq	*%rax
      c8:      	movq	%rax, 0x68(%rsp)
      cd:      	testq	%rax, %rax
      d0:      	jne	0x1ed <generic_tracepoint_event+0x1ed>
      d6:      	jmp	0x32ec <generic_tracepoint_event+0x32ec>
      db:      	xorl	%ebp, %ebp
      dd:      	jmp	0xe2 <generic_tracepoint_event+0xe2>
      df:      	movl	0x10(%rax), %ebp
      e2:      	movl	$0x23, %eax
      e7:      	callq	*%rax
      e9:      	movq	$0x0, 0x8(%rsp)
      f2:      	leaq	0xf90(%rax), %rdx
      f9:      	leaq	0x10(%rsp), %rdi
      fe:      	movl	$0x8, %ecx
     103:      	movl	$0x71, %eax
     108:      	movl	$0x8, %esi
     10d:      	callq	*%rax
     10f:      	movq	0x10(%rsp), %rax
     114:      	testq	%rax, %rax
     117:      	je	0x168 <generic_tracepoint_event+0x168>
     119:      	cmpl	$0xb, %ebp
     11c:      	ja	0x168 <generic_tracepoint_event+0x168>
     11e:      	movl	%ebp, %edx
     120:      	leaq	(%rax,%rdx,8), %rcx
     124:      	leaq	0x20(%rsp), %rdi
     129:      	movl	$0x8, %esi
     12e:      	movl	$0x71, %eax
     133:      	shlq	$0x3, %rdx
     137:      	addq	0x10(%rsp), %rdx
     13c:      	movl	$0x8, %esi
     141:      	callq	*%rax
     143:      	movq	0x20(%rsp), %rcx
     148:      	testq	%rcx, %rcx
     14b:      	je	0x168 <generic_tracepoint_event+0x168>
     14d:      	leaq	0x8(%rsp), %rdi
     152:      	movl	$0x8, %edx
     157:      	movl	$0x71, %eax
     15c:      	movq	0x20(%rsp), %rdx
     161:      	movl	$0x8, %esi
     166:      	callq	*%rax
     168:      	movq	0x8(%rsp), %rdx
     16d:      	testq	%rdx, %rdx
     170:      	je	0x32ec <generic_tracepoint_event+0x32ec>
     176:      	movq	$0x0, 0x20(%rsp)
     17f:      	addq	$0x100, %rdx            # imm = 0x100
     186:      	leaq	0x20(%rsp), %rdi
     18b:      	movl	$0x8, %ecx
     190:      	movl	$0x71, %eax
     195:      	movl	$0x8, %esi
     19a:      	callq	*%rax
     19c:      	movq	0x20(%rsp), %rdx
     1a1:      	movq	$0x0, 0x20(%rsp)
     1aa:      	testq	%rdx, %rdx
     1ad:      	je	0x1dd <generic_tracepoint_event+0x1dd>
     1af:      	addq	$0x60, %rdx
     1b3:      	leaq	0x20(%rsp), %rdi
     1b8:      	movl	$0x8, %ecx
     1bd:      	movl	$0x71, %eax
     1c2:      	movl	$0x8, %esi
     1c7:      	callq	*%rax
     1c9:      	movq	0x20(%rsp), %rax
     1ce:      	movq	%rax, 0x68(%rsp)
     1d3:      	testq	%rax, %rax
     1d6:      	jne	0x1ed <generic_tracepoint_event+0x1ed>
     1d8:      	jmp	0x32ec <generic_tracepoint_event+0x32ec>
     1dd:      	xorl	%eax, %eax
     1df:      	movq	%rax, 0x68(%rsp)
     1e4:      	testq	%rax, %rax
     1e7:      	je	0x32ec <generic_tracepoint_event+0x32ec>
     1ed:      	movq	%rax, 0x20(%rsp)
     1f2:      	movq	(%rip), %rdi            # 0x1f9 <generic_tracepoint_event+0x1f9>
     1f9:      	leaq	0x20(%rsp), %rsi
     1fe:      	movl	$0x1, %eax
     203:      	callq	*%rax
     205:      	testq	%rax, %rax
     208:      	je	0x21e <generic_tracepoint_event+0x21e>
     20a:      	movq	(%rax), %rax
     20d:      	movq	%rax, 0x70(%rsp)
     212:      	testq	%rax, %rax
     215:      	je	0x227 <generic_tracepoint_event+0x227>
     217:      	movq	%rax, 0x68(%rsp)
     21c:      	jmp	0x227 <generic_tracepoint_event+0x227>
     21e:      	movq	$0x0, 0x70(%rsp)
     227:      	leaq	0x68(%rsp), %rsi
     22c:      	movl	$0x1, %eax
     231:      	movq	%r12, %rdi
     234:      	callq	*%rax
     236:      	testq	%rax, %rax
     239:      	je	0x461 <generic_tracepoint_event+0x461>
     23f:      	movl	$0x0, 0x5ef8(%r14)
     24a:      	movl	(%r15), %eax
     24d:      	movq	%rax, 0x60(%r14)
     251:      	movq	$0x0, 0x68(%r14)
     259:      	movzwl	0x2c(%r15), %edx
     25e:      	movl	0x4(%r15), %r13d
     262:      	addq	%rbx, %rdx
     265:      	xorl	%r12d, %r12d
     268:      	cmpl	$0xb, %r13d
     26c:      	jg	0x2a5 <generic_tracepoint_event+0x2a5>
     26e:      	cmpl	$0x3, %r13d
     272:      	jle	0x336 <generic_tracepoint_event+0x336>
     278:      	cmpl	$0x6, %r13d
     27c:      	jg	0x4c3 <generic_tracepoint_event+0x4c3>
     282:      	cmpl	$0x4, %r13d
     286:      	je	0x924 <generic_tracepoint_event+0x924>
     28c:      	cmpl	$0x5, %r13d
     290:      	je	0x7c9 <generic_tracepoint_event+0x7c9>
     296:      	cmpl	$0x6, %r13d
     29a:      	je	0x357 <generic_tracepoint_event+0x357>
     2a0:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     2a5:      	cmpl	$0x1d, %r13d
     2a9:      	jle	0x3d4 <generic_tracepoint_event+0x3d4>
     2af:      	cmpl	$0x25, %r13d
     2b3:      	jg	0x52f <generic_tracepoint_event+0x52f>
     2b9:      	cmpl	$0x1e, %r13d
     2bd:      	je	0x983 <generic_tracepoint_event+0x983>
     2c3:      	cmpl	$0x1f, %r13d
     2c7:      	je	0x846 <generic_tracepoint_event+0x846>
     2cd:      	cmpl	$0x20, %r13d
     2d1:      	jne	0xb87 <generic_tracepoint_event+0xb87>
     2d7:      	leaq	0x8(%rsp), %rdi
     2dc:      	movl	$0x1, %ecx
     2e1:      	movl	$0x4, %eax
     2e6:      	movl	$0x1, %esi
     2eb:      	callq	*%rax
     2ed:      	testq	%rax, %rax
     2f0:      	je	0xafc <generic_tracepoint_event+0xafc>
     2f6:      	negl	%eax
     2f8:      	movw	%ax, 0x20(%rsp)
     2fd:      	movw	$0x7, 0x22(%rsp)
     304:      	movabsq	$0x400000073, %rax      # imm = 0x400000073
     30e:      	movq	%rax, 0x24(%rsp)
     313:      	movq	(%rip), %rdi            # 0x31a <generic_tracepoint_event+0x31a>
     31a:      	leaq	0x20(%rsp), %rsi
     31f:      	movl	$0x1, %eax
     324:      	callq	*%rax
     326:      	testq	%rax, %rax
     329:      	je	0xad8 <generic_tracepoint_event+0xad8>
     32f:      	incl	(%rax)
     331:      	jmp	0xafc <generic_tracepoint_event+0xafc>
     336:      	cmpl	$-0xc, %r13d
     33a:      	jle	0x5ca <generic_tracepoint_event+0x5ca>
     340:      	leal	0xb(%r13), %eax
     344:      	cmpl	$0x2, %eax
     347:      	jb	0x4d0 <generic_tracepoint_event+0x4d0>
     34d:      	cmpl	$0x2, %r13d
     351:      	jne	0xb87 <generic_tracepoint_event+0xb87>
     357:      	leaq	0x10(%rsp), %rdi
     35c:      	movl	$0x8, %ecx
     361:      	movl	$0x4, %eax
     366:      	movl	$0x8, %esi
     36b:      	callq	*%rax
     36d:      	testq	%rax, %rax
     370:      	je	0xb2b <generic_tracepoint_event+0xb2b>
     376:      	negl	%eax
     378:      	movw	%ax, 0x20(%rsp)
     37d:      	movw	$0x7, 0x22(%rsp)
     384:      	movabsq	$0x400000081, %rax      # imm = 0x400000081
     38e:      	movq	%rax, 0x24(%rsp)
     393:      	movq	(%rip), %rdi            # 0x39a <generic_tracepoint_event+0x39a>
     39a:      	leaq	0x20(%rsp), %rsi
     39f:      	movl	$0x1, %eax
     3a4:      	callq	*%rax
     3a6:      	testq	%rax, %rax
     3a9:      	jne	0x97c <generic_tracepoint_event+0x97c>
     3af:      	movl	$0x1, 0x8(%rsp)
     3b7:      	movq	(%rip), %rdi            # 0x3be <generic_tracepoint_event+0x3be>
     3be:      	xorl	%ecx, %ecx
     3c0:      	leaq	0x20(%rsp), %rsi
     3c5:      	leaq	0x8(%rsp), %rdx
     3ca:      	movl	$0x2, %eax
     3cf:      	jmp	0xb27 <generic_tracepoint_event+0xb27>
     3d4:      	cmpl	$0x11, %r13d
     3d8:      	jle	0x5df <generic_tracepoint_event+0x5df>
     3de:      	cmpl	$0x12, %r13d
     3e2:      	je	0x7c1 <generic_tracepoint_event+0x7c1>
     3e8:      	cmpl	$0x1c, %r13d
     3ec:      	je	0x4d0 <generic_tracepoint_event+0x4d0>
     3f2:      	cmpl	$0x1d, %r13d
     3f6:      	jne	0xb87 <generic_tracepoint_event+0xb87>
     3fc:      	leaq	0x8(%rsp), %rdi
     401:      	movl	$0x2, %ecx
     406:      	movl	$0x4, %eax
     40b:      	movl	$0x2, %esi
     410:      	callq	*%rax
     412:      	testq	%rax, %rax
     415:      	je	0xa9e <generic_tracepoint_event+0xa9e>
     41b:      	negl	%eax
     41d:      	movw	%ax, 0x20(%rsp)
     422:      	movw	$0x7, 0x22(%rsp)
     429:      	movabsq	$0x40000006c, %rax      # imm = 0x40000006C
     433:      	movq	%rax, 0x24(%rsp)
     438:      	movq	(%rip), %rdi            # 0x43f <generic_tracepoint_event+0x43f>
     43f:      	leaq	0x20(%rsp), %rsi
     444:      	movl	$0x1, %eax
     449:      	callq	*%rax
     44b:      	testq	%rax, %rax
     44e:      	je	0xa7a <generic_tracepoint_event+0xa7a>
     454:      	incl	(%rax)
     456:      	movswq	0x8(%rsp), %r12
     45c:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     461:      	movq	$-0x1, 0x70(%rsp)
     46a:      	leaq	0x70(%rsp), %rsi
     46f:      	movl	$0x1, %eax
     474:      	movq	%r12, %rdi
     477:      	callq	*%rax
     479:      	testq	%rax, %rax
     47c:      	je	0x32ec <generic_tracepoint_event+0x32ec>
     482:      	movl	$0x1, 0x7c(%rsp)
     48a:      	movq	(%rip), %rdi            # 0x491 <generic_tracepoint_event+0x491>
     491:      	leaq	0x7c(%rsp), %rsi
     496:      	movl	$0x1, %eax
     49b:      	callq	*%rax
     49d:      	testq	%rax, %rax
     4a0:      	je	0x32ec <generic_tracepoint_event+0x32ec>
     4a6:      	movq	%rax, %rdi
     4a9:      	leaq	0x68(%rsp), %rsi
     4ae:      	movl	$0x1, %eax
     4b3:      	callq	*%rax
     4b5:      	testq	%rax, %rax
     4b8:      	jne	0x32ec <generic_tracepoint_event+0x32ec>
     4be:      	jmp	0x23f <generic_tracepoint_event+0x23f>
     4c3:      	leal	-0xa(%r13), %eax
     4c7:      	cmpl	$0x2, %eax
     4ca:      	jae	0x73a <generic_tracepoint_event+0x73a>
     4d0:      	leaq	0x10(%rsp), %rdi
     4d5:      	movl	$0x8, %ecx
     4da:      	movl	$0x4, %eax
     4df:      	movl	$0x8, %esi
     4e4:      	callq	*%rax
     4e6:      	testq	%rax, %rax
     4e9:      	je	0x6f8 <generic_tracepoint_event+0x6f8>
     4ef:      	negl	%eax
     4f1:      	movw	%ax, 0x20(%rsp)
     4f6:      	movw	$0x7, 0x22(%rsp)
     4fd:      	movabsq	$0x400000045, %rax      # imm = 0x400000045
     507:      	movq	%rax, 0x24(%rsp)
     50c:      	movq	(%rip), %rdi            # 0x513 <generic_tracepoint_event+0x513>
     513:      	leaq	0x20(%rsp), %rsi
     518:      	movl	$0x1, %eax
     51d:      	callq	*%rax
     51f:      	testq	%rax, %rax
     522:      	je	0x6d4 <generic_tracepoint_event+0x6d4>
     528:      	incl	(%rax)
     52a:      	jmp	0x6f8 <generic_tracepoint_event+0x6f8>
     52f:      	cmpl	$0x26, %r13d
     533:      	je	0x9e8 <generic_tracepoint_event+0x9e8>
     539:      	cmpl	$0x28, %r13d
     53d:      	je	0x8ab <generic_tracepoint_event+0x8ab>
     543:      	cmpl	$0x29, %r13d
     547:      	jne	0xb87 <generic_tracepoint_event+0xb87>
     54d:      	leaq	0x10(%rsp), %rdi
     552:      	movl	$0x8, %ecx
     557:      	movl	$0x4, %eax
     55c:      	movl	$0x8, %esi
     561:      	callq	*%rax
     563:      	testq	%rax, %rax
     566:      	je	0xb2b <generic_tracepoint_event+0xb2b>
     56c:      	negl	%eax
     56e:      	movw	%ax, 0x20(%rsp)
     573:      	movw	$0x7, 0x22(%rsp)
     57a:      	movabsq	$0x4000000a8, %rax      # imm = 0x4000000A8
     584:      	movq	%rax, 0x24(%rsp)
     589:      	movq	(%rip), %rdi            # 0x590 <generic_tracepoint_event+0x590>
     590:      	leaq	0x20(%rsp), %rsi
     595:      	movl	$0x1, %eax
     59a:      	callq	*%rax
     59c:      	testq	%rax, %rax
     59f:      	jne	0x97c <generic_tracepoint_event+0x97c>
     5a5:      	movl	$0x1, 0x8(%rsp)
     5ad:      	movq	(%rip), %rdi            # 0x5b4 <generic_tracepoint_event+0x5b4>
     5b4:      	xorl	%ecx, %ecx
     5b6:      	leaq	0x20(%rsp), %rsi
     5bb:      	leaq	0x8(%rsp), %rdx
     5c0:      	movl	$0x2, %eax
     5c5:      	jmp	0xb27 <generic_tracepoint_event+0xb27>
     5ca:      	cmpl	$-0xd, %r13d
     5ce:      	je	0x670 <generic_tracepoint_event+0x670>
     5d4:      	cmpl	$-0xc, %r13d
     5d8:      	je	0x5f3 <generic_tracepoint_event+0x5f3>
     5da:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     5df:      	cmpl	$0xc, %r13d
     5e3:      	je	0x670 <generic_tracepoint_event+0x670>
     5e9:      	cmpl	$0xd, %r13d
     5ed:      	jne	0xb87 <generic_tracepoint_event+0xb87>
     5f3:      	leaq	0x8(%rsp), %rdi
     5f8:      	movl	$0x4, %ecx
     5fd:      	movl	$0x4, %eax
     602:      	movl	$0x4, %esi
     607:      	callq	*%rax
     609:      	testq	%rax, %rax
     60c:      	je	0xb82 <generic_tracepoint_event+0xb82>
     612:      	negl	%eax
     614:      	movw	%ax, 0x20(%rsp)
     619:      	movw	$0x7, 0x22(%rsp)
     620:      	movabsq	$0x40000005e, %rax      # imm = 0x40000005E
     62a:      	movq	%rax, 0x24(%rsp)
     62f:      	movq	(%rip), %rdi            # 0x636 <generic_tracepoint_event+0x636>
     636:      	leaq	0x20(%rsp), %rsi
     63b:      	movl	$0x1, %eax
     640:      	callq	*%rax
     642:      	testq	%rax, %rax
     645:      	jne	0xa40 <generic_tracepoint_event+0xa40>
     64b:      	movl	$0x1, 0x10(%rsp)
     653:      	movq	(%rip), %rdi            # 0x65a <generic_tracepoint_event+0x65a>
     65a:      	xorl	%ecx, %ecx
     65c:      	leaq	0x20(%rsp), %rsi
     661:      	leaq	0x10(%rsp), %rdx
     666:      	movl	$0x2, %eax
     66b:      	jmp	0xb7e <generic_tracepoint_event+0xb7e>
     670:      	leaq	0x8(%rsp), %rdi
     675:      	movl	$0x4, %ecx
     67a:      	movl	$0x4, %eax
     67f:      	movl	$0x4, %esi
     684:      	callq	*%rax
     686:      	testq	%rax, %rax
     689:      	je	0xa70 <generic_tracepoint_event+0xa70>
     68f:      	negl	%eax
     691:      	movw	%ax, 0x20(%rsp)
     696:      	movw	$0x7, 0x22(%rsp)
     69d:      	movabsq	$0x400000056, %rax      # imm = 0x400000056
     6a7:      	movq	%rax, 0x24(%rsp)
     6ac:      	movq	(%rip), %rdi            # 0x6b3 <generic_tracepoint_event+0x6b3>
     6b3:      	leaq	0x20(%rsp), %rsi
     6b8:      	movl	$0x1, %eax
     6bd:      	callq	*%rax
     6bf:      	testq	%rax, %rax
     6c2:      	je	0xa4c <generic_tracepoint_event+0xa4c>
     6c8:      	incl	(%rax)
     6ca:      	movslq	0x8(%rsp), %r12
     6cf:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     6d4:      	movl	$0x1, 0x8(%rsp)
     6dc:      	movq	(%rip), %rdi            # 0x6e3 <generic_tracepoint_event+0x6e3>
     6e3:      	xorl	%ecx, %ecx
     6e5:      	leaq	0x20(%rsp), %rsi
     6ea:      	leaq	0x8(%rsp), %rdx
     6ef:      	movl	$0x2, %eax
     6f4:      	xorl	%ecx, %ecx
     6f6:      	callq	*%rax
     6f8:      	movq	0x10(%rsp), %r12
     6fd:      	cmpl	$0x1c, %r13d
     701:      	jne	0xb87 <generic_tracepoint_event+0xb87>
     707:      	movl	$0x23, %eax
     70c:      	callq	*%rax
     70e:      	leaq	0x10(%rax), %rdx
     712:      	leaq	0x20(%rsp), %rdi
     717:      	movl	$0x4, %ecx
     71c:      	movl	$0x4, %eax
     721:      	movl	$0x4, %esi
     726:      	callq	*%rax
     728:      	movl	0x20(%rsp), %eax
     72c:      	andl	$-0x2, %eax
     72f:      	shll	$0x1e, %eax
     732:      	orq	%rax, %r12
     735:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     73a:      	cmpl	$0x7, %r13d
     73e:      	jne	0xb87 <generic_tracepoint_event+0xb87>
     744:      	leaq	0x10(%rsp), %rdi
     749:      	movl	$0x8, %ecx
     74e:      	movl	$0x4, %eax
     753:      	movl	$0x8, %esi
     758:      	callq	*%rax
     75a:      	testq	%rax, %rax
     75d:      	je	0xb2b <generic_tracepoint_event+0xb2b>
     763:      	negl	%eax
     765:      	movw	%ax, 0x20(%rsp)
     76a:      	movw	$0x7, 0x22(%rsp)
     771:      	movabsq	$0x40000009a, %rax      # imm = 0x40000009A
     77b:      	movq	%rax, 0x24(%rsp)
     780:      	movq	(%rip), %rdi            # 0x787 <generic_tracepoint_event+0x787>
     787:      	leaq	0x20(%rsp), %rsi
     78c:      	movl	$0x1, %eax
     791:      	callq	*%rax
     793:      	testq	%rax, %rax
     796:      	jne	0x97c <generic_tracepoint_event+0x97c>
     79c:      	movl	$0x1, 0x8(%rsp)
     7a4:      	movq	(%rip), %rdi            # 0x7ab <generic_tracepoint_event+0x7ab>
     7ab:      	xorl	%ecx, %ecx
     7ad:      	leaq	0x20(%rsp), %rsi
     7b2:      	leaq	0x8(%rsp), %rdx
     7b7:      	movl	$0x2, %eax
     7bc:      	jmp	0xb27 <generic_tracepoint_event+0xb27>
     7c1:      	movq	%rdx, %r12
     7c4:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     7c9:      	leaq	0x10(%rsp), %rdi
     7ce:      	movl	$0x8, %ecx
     7d3:      	movl	$0x4, %eax
     7d8:      	movl	$0x8, %esi
     7dd:      	callq	*%rax
     7df:      	testq	%rax, %rax
     7e2:      	je	0xb2b <generic_tracepoint_event+0xb2b>
     7e8:      	negl	%eax
     7ea:      	movw	%ax, 0x20(%rsp)
     7ef:      	movw	$0x7, 0x22(%rsp)
     7f6:      	movabsq	$0x400000093, %rax      # imm = 0x400000093
     800:      	movq	%rax, 0x24(%rsp)
     805:      	movq	(%rip), %rdi            # 0x80c <generic_tracepoint_event+0x80c>
     80c:      	leaq	0x20(%rsp), %rsi
     811:      	movl	$0x1, %eax
     816:      	callq	*%rax
     818:      	testq	%rax, %rax
     81b:      	jne	0x97c <generic_tracepoint_event+0x97c>
     821:      	movl	$0x1, 0x8(%rsp)
     829:      	movq	(%rip), %rdi            # 0x830 <generic_tracepoint_event+0x830>
     830:      	xorl	%ecx, %ecx
     832:      	leaq	0x20(%rsp), %rsi
     837:      	leaq	0x8(%rsp), %rdx
     83c:      	movl	$0x2, %eax
     841:      	jmp	0xb27 <generic_tracepoint_event+0xb27>
     846:      	leaq	0x8(%rsp), %rdi
     84b:      	movl	$0x1, %ecx
     850:      	movl	$0x4, %eax
     855:      	movl	$0x1, %esi
     85a:      	callq	*%rax
     85c:      	testq	%rax, %rax
     85f:      	je	0xacd <generic_tracepoint_event+0xacd>
     865:      	negl	%eax
     867:      	movw	%ax, 0x20(%rsp)
     86c:      	movw	$0x7, 0x22(%rsp)
     873:      	movabsq	$0x40000007a, %rax      # imm = 0x40000007A
     87d:      	movq	%rax, 0x24(%rsp)
     882:      	movq	(%rip), %rdi            # 0x889 <generic_tracepoint_event+0x889>
     889:      	leaq	0x20(%rsp), %rsi
     88e:      	movl	$0x1, %eax
     893:      	callq	*%rax
     895:      	testq	%rax, %rax
     898:      	je	0xaa9 <generic_tracepoint_event+0xaa9>
     89e:      	incl	(%rax)
     8a0:      	movsbq	0x8(%rsp), %r12
     8a6:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     8ab:      	leaq	0x10(%rsp), %rdi
     8b0:      	movl	$0x8, %ecx
     8b5:      	movl	$0x4, %eax
     8ba:      	movl	$0x8, %esi
     8bf:      	callq	*%rax
     8c1:      	testq	%rax, %rax
     8c4:      	je	0xb2b <generic_tracepoint_event+0xb2b>
     8ca:      	negl	%eax
     8cc:      	movw	%ax, 0x20(%rsp)
     8d1:      	movw	$0x7, 0x22(%rsp)
     8d8:      	movabsq	$0x4000000a1, %rax      # imm = 0x4000000A1
     8e2:      	movq	%rax, 0x24(%rsp)
     8e7:      	movq	(%rip), %rdi            # 0x8ee <generic_tracepoint_event+0x8ee>
     8ee:      	leaq	0x20(%rsp), %rsi
     8f3:      	movl	$0x1, %eax
     8f8:      	callq	*%rax
     8fa:      	testq	%rax, %rax
     8fd:      	jne	0x97c <generic_tracepoint_event+0x97c>
     8ff:      	movl	$0x1, 0x8(%rsp)
     907:      	movq	(%rip), %rdi            # 0x90e <generic_tracepoint_event+0x90e>
     90e:      	xorl	%ecx, %ecx
     910:      	leaq	0x20(%rsp), %rsi
     915:      	leaq	0x8(%rsp), %rdx
     91a:      	movl	$0x2, %eax
     91f:      	jmp	0xb27 <generic_tracepoint_event+0xb27>
     924:      	leaq	0x10(%rsp), %rdi
     929:      	movl	$0x8, %ecx
     92e:      	movl	$0x4, %eax
     933:      	movl	$0x8, %esi
     938:      	callq	*%rax
     93a:      	testq	%rax, %rax
     93d:      	je	0xb2b <generic_tracepoint_event+0xb2b>
     943:      	negl	%eax
     945:      	movw	%ax, 0x20(%rsp)
     94a:      	movw	$0x7, 0x22(%rsp)
     951:      	movabsq	$0x40000004e, %rax      # imm = 0x40000004E
     95b:      	movq	%rax, 0x24(%rsp)
     960:      	movq	(%rip), %rdi            # 0x967 <generic_tracepoint_event+0x967>
     967:      	leaq	0x20(%rsp), %rsi
     96c:      	movl	$0x1, %eax
     971:      	callq	*%rax
     973:      	testq	%rax, %rax
     976:      	je	0xb07 <generic_tracepoint_event+0xb07>
     97c:      	incl	(%rax)
     97e:      	jmp	0xb2b <generic_tracepoint_event+0xb2b>
     983:      	leaq	0x8(%rsp), %rdi
     988:      	movl	$0x2, %ecx
     98d:      	movl	$0x4, %eax
     992:      	movl	$0x2, %esi
     997:      	callq	*%rax
     999:      	testq	%rax, %rax
     99c:      	je	0xb56 <generic_tracepoint_event+0xb56>
     9a2:      	negl	%eax
     9a4:      	movw	%ax, 0x20(%rsp)
     9a9:      	movw	$0x7, 0x22(%rsp)
     9b0:      	movabsq	$0x400000065, %rax      # imm = 0x400000065
     9ba:      	movq	%rax, 0x24(%rsp)
     9bf:      	movq	(%rip), %rdi            # 0x9c6 <generic_tracepoint_event+0x9c6>
     9c6:      	leaq	0x20(%rsp), %rsi
     9cb:      	movl	$0x1, %eax
     9d0:      	callq	*%rax
     9d2:      	testq	%rax, %rax
     9d5:      	je	0xb32 <generic_tracepoint_event+0xb32>
     9db:      	incl	(%rax)
     9dd:      	movzwl	0x8(%rsp), %r12d
     9e3:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     9e8:      	leaq	0x8(%rsp), %rdi
     9ed:      	movl	$0x4, %ecx
     9f2:      	movl	$0x4, %eax
     9f7:      	movl	$0x4, %esi
     9fc:      	callq	*%rax
     9fe:      	testq	%rax, %rax
     a01:      	je	0xb82 <generic_tracepoint_event+0xb82>
     a07:      	negl	%eax
     a09:      	movw	%ax, 0x20(%rsp)
     a0e:      	movw	$0x7, 0x22(%rsp)
     a15:      	movabsq	$0x400000088, %rax      # imm = 0x400000088
     a1f:      	movq	%rax, 0x24(%rsp)
     a24:      	movq	(%rip), %rdi            # 0xa2b <generic_tracepoint_event+0xa2b>
     a2b:      	leaq	0x20(%rsp), %rsi
     a30:      	movl	$0x1, %eax
     a35:      	callq	*%rax
     a37:      	testq	%rax, %rax
     a3a:      	je	0xb5e <generic_tracepoint_event+0xb5e>
     a40:      	incl	(%rax)
     a42:      	movl	0x8(%rsp), %r12d
     a47:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     a4c:      	movl	$0x1, 0x10(%rsp)
     a54:      	movq	(%rip), %rdi            # 0xa5b <generic_tracepoint_event+0xa5b>
     a5b:      	xorl	%ecx, %ecx
     a5d:      	leaq	0x20(%rsp), %rsi
     a62:      	leaq	0x10(%rsp), %rdx
     a67:      	movl	$0x2, %eax
     a6c:      	xorl	%ecx, %ecx
     a6e:      	callq	*%rax
     a70:      	movslq	0x8(%rsp), %r12
     a75:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     a7a:      	movl	$0x1, 0x10(%rsp)
     a82:      	movq	(%rip), %rdi            # 0xa89 <generic_tracepoint_event+0xa89>
     a89:      	xorl	%ecx, %ecx
     a8b:      	leaq	0x20(%rsp), %rsi
     a90:      	leaq	0x10(%rsp), %rdx
     a95:      	movl	$0x2, %eax
     a9a:      	xorl	%ecx, %ecx
     a9c:      	callq	*%rax
     a9e:      	movswq	0x8(%rsp), %r12
     aa4:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     aa9:      	movl	$0x1, 0x10(%rsp)
     ab1:      	movq	(%rip), %rdi            # 0xab8 <generic_tracepoint_event+0xab8>
     ab8:      	xorl	%ecx, %ecx
     aba:      	leaq	0x20(%rsp), %rsi
     abf:      	leaq	0x10(%rsp), %rdx
     ac4:      	movl	$0x2, %eax
     ac9:      	xorl	%ecx, %ecx
     acb:      	callq	*%rax
     acd:      	movsbq	0x8(%rsp), %r12
     ad3:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     ad8:      	movl	$0x1, 0x10(%rsp)
     ae0:      	movq	(%rip), %rdi            # 0xae7 <generic_tracepoint_event+0xae7>
     ae7:      	xorl	%ecx, %ecx
     ae9:      	leaq	0x20(%rsp), %rsi
     aee:      	leaq	0x10(%rsp), %rdx
     af3:      	movl	$0x2, %eax
     af8:      	xorl	%ecx, %ecx
     afa:      	callq	*%rax
     afc:      	movzbl	0x8(%rsp), %r12d
     b02:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     b07:      	movl	$0x1, 0x8(%rsp)
     b0f:      	movq	(%rip), %rdi            # 0xb16 <generic_tracepoint_event+0xb16>
     b16:      	xorl	%ecx, %ecx
     b18:      	leaq	0x20(%rsp), %rsi
     b1d:      	leaq	0x8(%rsp), %rdx
     b22:      	movl	$0x2, %eax
     b27:      	xorl	%ecx, %ecx
     b29:      	callq	*%rax
     b2b:      	movq	0x10(%rsp), %r12
     b30:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     b32:      	movl	$0x1, 0x10(%rsp)
     b3a:      	movq	(%rip), %rdi            # 0xb41 <generic_tracepoint_event+0xb41>
     b41:      	xorl	%ecx, %ecx
     b43:      	leaq	0x20(%rsp), %rsi
     b48:      	leaq	0x10(%rsp), %rdx
     b4d:      	movl	$0x2, %eax
     b52:      	xorl	%ecx, %ecx
     b54:      	callq	*%rax
     b56:      	movzwl	0x8(%rsp), %r12d
     b5c:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     b5e:      	movl	$0x1, 0x10(%rsp)
     b66:      	movq	(%rip), %rdi            # 0xb6d <generic_tracepoint_event+0xb6d>
     b6d:      	xorl	%ecx, %ecx
     b6f:      	leaq	0x20(%rsp), %rsi
     b74:      	leaq	0x10(%rsp), %rdx
     b79:      	movl	$0x2, %eax
     b7e:      	xorl	%ecx, %ecx
     b80:      	callq	*%rax
     b82:      	movl	0x8(%rsp), %r12d
     b87:      	movq	%r12, 0x5e50(%r14)
     b8e:      	movzwl	0x30(%r15), %edx
     b93:      	movl	0x8(%r15), %r13d
     b97:      	addq	%rbx, %rdx
     b9a:      	xorl	%r12d, %r12d
     b9d:      	cmpl	$0xb, %r13d
     ba1:      	jg	0xbda <generic_tracepoint_event+0xbda>
     ba3:      	cmpl	$0x3, %r13d
     ba7:      	jle	0xc71 <generic_tracepoint_event+0xc71>
     bad:      	cmpl	$0x6, %r13d
     bb1:      	jg	0xd98 <generic_tracepoint_event+0xd98>
     bb7:      	cmpl	$0x4, %r13d
     bbb:      	je	0x11f9 <generic_tracepoint_event+0x11f9>
     bc1:      	cmpl	$0x5, %r13d
     bc5:      	je	0x109e <generic_tracepoint_event+0x109e>
     bcb:      	cmpl	$0x6, %r13d
     bcf:      	je	0xc92 <generic_tracepoint_event+0xc92>
     bd5:      	jmp	0x145c <generic_tracepoint_event+0x145c>
     bda:      	cmpl	$0x1d, %r13d
     bde:      	jle	0xd0f <generic_tracepoint_event+0xd0f>
     be4:      	cmpl	$0x25, %r13d
     be8:      	jg	0xe04 <generic_tracepoint_event+0xe04>
     bee:      	cmpl	$0x1e, %r13d
     bf2:      	je	0x1258 <generic_tracepoint_event+0x1258>
     bf8:      	cmpl	$0x1f, %r13d
     bfc:      	je	0x111b <generic_tracepoint_event+0x111b>
     c02:      	cmpl	$0x20, %r13d
     c06:      	jne	0x145c <generic_tracepoint_event+0x145c>
     c0c:      	leaq	0x8(%rsp), %rdi
     c11:      	movl	$0x1, %ecx
     c16:      	movl	$0x4, %eax
     c1b:      	movl	$0x1, %esi
     c20:      	callq	*%rax
     c22:      	testq	%rax, %rax
     c25:      	je	0x13d1 <generic_tracepoint_event+0x13d1>
     c2b:      	negl	%eax
     c2d:      	movw	%ax, 0x20(%rsp)
     c32:      	movw	$0x7, 0x22(%rsp)
     c39:      	movabsq	$0x400000073, %rax      # imm = 0x400000073
     c43:      	movq	%rax, 0x24(%rsp)
     c48:      	movq	(%rip), %rdi            # 0xc4f <generic_tracepoint_event+0xc4f>
     c4f:      	leaq	0x20(%rsp), %rsi
     c54:      	movl	$0x1, %eax
     c59:      	callq	*%rax
     c5b:      	testq	%rax, %rax
     c5e:      	je	0x13ad <generic_tracepoint_event+0x13ad>
     c64:      	incl	(%rax)
     c66:      	movzbl	0x8(%rsp), %r12d
     c6c:      	jmp	0x145c <generic_tracepoint_event+0x145c>
     c71:      	cmpl	$-0xc, %r13d
     c75:      	jle	0xe9f <generic_tracepoint_event+0xe9f>
     c7b:      	leal	0xb(%r13), %eax
     c7f:      	cmpl	$0x2, %eax
     c82:      	jb	0xda5 <generic_tracepoint_event+0xda5>
     c88:      	cmpl	$0x2, %r13d
     c8c:      	jne	0x145c <generic_tracepoint_event+0x145c>
     c92:      	leaq	0x10(%rsp), %rdi
     c97:      	movl	$0x8, %ecx
     c9c:      	movl	$0x4, %eax
     ca1:      	movl	$0x8, %esi
     ca6:      	callq	*%rax
     ca8:      	testq	%rax, %rax
     cab:      	je	0x1400 <generic_tracepoint_event+0x1400>
     cb1:      	negl	%eax
     cb3:      	movw	%ax, 0x20(%rsp)
     cb8:      	movw	$0x7, 0x22(%rsp)
     cbf:      	movabsq	$0x400000081, %rax      # imm = 0x400000081
     cc9:      	movq	%rax, 0x24(%rsp)
     cce:      	movq	(%rip), %rdi            # 0xcd5 <generic_tracepoint_event+0xcd5>
     cd5:      	leaq	0x20(%rsp), %rsi
     cda:      	movl	$0x1, %eax
     cdf:      	callq	*%rax
     ce1:      	testq	%rax, %rax
     ce4:      	jne	0x1251 <generic_tracepoint_event+0x1251>
     cea:      	movl	$0x1, 0x8(%rsp)
     cf2:      	movq	(%rip), %rdi            # 0xcf9 <generic_tracepoint_event+0xcf9>
     cf9:      	xorl	%ecx, %ecx
     cfb:      	leaq	0x20(%rsp), %rsi
     d00:      	leaq	0x8(%rsp), %rdx
     d05:      	movl	$0x2, %eax
     d0a:      	jmp	0x13fc <generic_tracepoint_event+0x13fc>
     d0f:      	cmpl	$0x11, %r13d
     d13:      	jle	0xeb4 <generic_tracepoint_event+0xeb4>
     d19:      	cmpl	$0x12, %r13d
     d1d:      	je	0x1096 <generic_tracepoint_event+0x1096>
     d23:      	cmpl	$0x1c, %r13d
     d27:      	je	0xda5 <generic_tracepoint_event+0xda5>
     d29:      	cmpl	$0x1d, %r13d
     d2d:      	jne	0x145c <generic_tracepoint_event+0x145c>
     d33:      	leaq	0x8(%rsp), %rdi
     d38:      	movl	$0x2, %ecx
     d3d:      	movl	$0x4, %eax
     d42:      	movl	$0x2, %esi
     d47:      	callq	*%rax
     d49:      	testq	%rax, %rax
     d4c:      	je	0x1373 <generic_tracepoint_event+0x1373>
     d52:      	negl	%eax
     d54:      	movw	%ax, 0x20(%rsp)
     d59:      	movw	$0x7, 0x22(%rsp)
     d60:      	movabsq	$0x40000006c, %rax      # imm = 0x40000006C
     d6a:      	movq	%rax, 0x24(%rsp)
     d6f:      	movq	(%rip), %rdi            # 0xd76 <generic_tracepoint_event+0xd76>
     d76:      	leaq	0x20(%rsp), %rsi
     d7b:      	movl	$0x1, %eax
     d80:      	callq	*%rax
     d82:      	testq	%rax, %rax
     d85:      	je	0x134f <generic_tracepoint_event+0x134f>
     d8b:      	incl	(%rax)
     d8d:      	movswq	0x8(%rsp), %r12
     d93:      	jmp	0x145c <generic_tracepoint_event+0x145c>
     d98:      	leal	-0xa(%r13), %eax
     d9c:      	cmpl	$0x2, %eax
     d9f:      	jae	0x100f <generic_tracepoint_event+0x100f>
     da5:      	leaq	0x10(%rsp), %rdi
     daa:      	movl	$0x8, %ecx
     daf:      	movl	$0x4, %eax
     db4:      	movl	$0x8, %esi
     db9:      	callq	*%rax
     dbb:      	testq	%rax, %rax
     dbe:      	je	0xfcd <generic_tracepoint_event+0xfcd>
     dc4:      	negl	%eax
     dc6:      	movw	%ax, 0x20(%rsp)
     dcb:      	movw	$0x7, 0x22(%rsp)
     dd2:      	movabsq	$0x400000045, %rax      # imm = 0x400000045
     ddc:      	movq	%rax, 0x24(%rsp)
     de1:      	movq	(%rip), %rdi            # 0xde8 <generic_tracepoint_event+0xde8>
     de8:      	leaq	0x20(%rsp), %rsi
     ded:      	movl	$0x1, %eax
     df2:      	callq	*%rax
     df4:      	testq	%rax, %rax
     df7:      	je	0xfa9 <generic_tracepoint_event+0xfa9>
     dfd:      	incl	(%rax)
     dff:      	jmp	0xfcd <generic_tracepoint_event+0xfcd>
     e04:      	cmpl	$0x26, %r13d
     e08:      	je	0x12bd <generic_tracepoint_event+0x12bd>
     e0e:      	cmpl	$0x28, %r13d
     e12:      	je	0x1180 <generic_tracepoint_event+0x1180>
     e18:      	cmpl	$0x29, %r13d
     e1c:      	jne	0x145c <generic_tracepoint_event+0x145c>
     e22:      	leaq	0x10(%rsp), %rdi
     e27:      	movl	$0x8, %ecx
     e2c:      	movl	$0x4, %eax
     e31:      	movl	$0x8, %esi
     e36:      	callq	*%rax
     e38:      	testq	%rax, %rax
     e3b:      	je	0x1400 <generic_tracepoint_event+0x1400>
     e41:      	negl	%eax
     e43:      	movw	%ax, 0x20(%rsp)
     e48:      	movw	$0x7, 0x22(%rsp)
     e4f:      	movabsq	$0x4000000a8, %rax      # imm = 0x4000000A8
     e59:      	movq	%rax, 0x24(%rsp)
     e5e:      	movq	(%rip), %rdi            # 0xe65 <generic_tracepoint_event+0xe65>
     e65:      	leaq	0x20(%rsp), %rsi
     e6a:      	movl	$0x1, %eax
     e6f:      	callq	*%rax
     e71:      	testq	%rax, %rax
     e74:      	jne	0x1251 <generic_tracepoint_event+0x1251>
     e7a:      	movl	$0x1, 0x8(%rsp)
     e82:      	movq	(%rip), %rdi            # 0xe89 <generic_tracepoint_event+0xe89>
     e89:      	xorl	%ecx, %ecx
     e8b:      	leaq	0x20(%rsp), %rsi
     e90:      	leaq	0x8(%rsp), %rdx
     e95:      	movl	$0x2, %eax
     e9a:      	jmp	0x13fc <generic_tracepoint_event+0x13fc>
     e9f:      	cmpl	$-0xd, %r13d
     ea3:      	je	0xf45 <generic_tracepoint_event+0xf45>
     ea9:      	cmpl	$-0xc, %r13d
     ead:      	je	0xec8 <generic_tracepoint_event+0xec8>
     eaf:      	jmp	0x145c <generic_tracepoint_event+0x145c>
     eb4:      	cmpl	$0xc, %r13d
     eb8:      	je	0xf45 <generic_tracepoint_event+0xf45>
     ebe:      	cmpl	$0xd, %r13d
     ec2:      	jne	0x145c <generic_tracepoint_event+0x145c>
     ec8:      	leaq	0x8(%rsp), %rdi
     ecd:      	movl	$0x4, %ecx
     ed2:      	movl	$0x4, %eax
     ed7:      	movl	$0x4, %esi
     edc:      	callq	*%rax
     ede:      	testq	%rax, %rax
     ee1:      	je	0x1457 <generic_tracepoint_event+0x1457>
     ee7:      	negl	%eax
     ee9:      	movw	%ax, 0x20(%rsp)
     eee:      	movw	$0x7, 0x22(%rsp)
     ef5:      	movabsq	$0x40000005e, %rax      # imm = 0x40000005E
     eff:      	movq	%rax, 0x24(%rsp)
     f04:      	movq	(%rip), %rdi            # 0xf0b <generic_tracepoint_event+0xf0b>
     f0b:      	leaq	0x20(%rsp), %rsi
     f10:      	movl	$0x1, %eax
     f15:      	callq	*%rax
     f17:      	testq	%rax, %rax
     f1a:      	jne	0x1315 <generic_tracepoint_event+0x1315>
     f20:      	movl	$0x1, 0x10(%rsp)
     f28:      	movq	(%rip), %rdi            # 0xf2f <generic_tracepoint_event+0xf2f>
     f2f:      	xorl	%ecx, %ecx
     f31:      	leaq	0x20(%rsp), %rsi
     f36:      	leaq	0x10(%rsp), %rdx
     f3b:      	movl	$0x2, %eax
     f40:      	jmp	0x1453 <generic_tracepoint_event+0x1453>
     f45:      	leaq	0x8(%rsp), %rdi
     f4a:      	movl	$0x4, %ecx
     f4f:      	movl	$0x4, %eax
     f54:      	movl	$0x4, %esi
     f59:      	callq	*%rax
     f5b:      	testq	%rax, %rax
     f5e:      	je	0x1345 <generic_tracepoint_event+0x1345>
     f64:      	negl	%eax
     f66:      	movw	%ax, 0x20(%rsp)
     f6b:      	movw	$0x7, 0x22(%rsp)
     f72:      	movabsq	$0x400000056, %rax      # imm = 0x400000056
     f7c:      	movq	%rax, 0x24(%rsp)
     f81:      	movq	(%rip), %rdi            # 0xf88 <generic_tracepoint_event+0xf88>
     f88:      	leaq	0x20(%rsp), %rsi
     f8d:      	movl	$0x1, %eax
     f92:      	callq	*%rax
     f94:      	testq	%rax, %rax
     f97:      	je	0x1321 <generic_tracepoint_event+0x1321>
     f9d:      	incl	(%rax)
     f9f:      	movslq	0x8(%rsp), %r12
     fa4:      	jmp	0x145c <generic_tracepoint_event+0x145c>
     fa9:      	movl	$0x1, 0x8(%rsp)
     fb1:      	movq	(%rip), %rdi            # 0xfb8 <generic_tracepoint_event+0xfb8>
     fb8:      	xorl	%ecx, %ecx
     fba:      	leaq	0x20(%rsp), %rsi
     fbf:      	leaq	0x8(%rsp), %rdx
     fc4:      	movl	$0x2, %eax
     fc9:      	xorl	%ecx, %ecx
     fcb:      	callq	*%rax
     fcd:      	movq	0x10(%rsp), %r12
     fd2:      	cmpl	$0x1c, %r13d
     fd6:      	jne	0x145c <generic_tracepoint_event+0x145c>
     fdc:      	movl	$0x23, %eax
     fe1:      	callq	*%rax
     fe3:      	leaq	0x10(%rax), %rdx
     fe7:      	leaq	0x20(%rsp), %rdi
     fec:      	movl	$0x4, %ecx
     ff1:      	movl	$0x4, %eax
     ff6:      	movl	$0x4, %esi
     ffb:      	callq	*%rax
     ffd:      	movl	0x20(%rsp), %eax
    1001:      	andl	$-0x2, %eax
    1004:      	shll	$0x1e, %eax
    1007:      	orq	%rax, %r12
    100a:      	jmp	0x145c <generic_tracepoint_event+0x145c>
    100f:      	cmpl	$0x7, %r13d
    1013:      	jne	0x145c <generic_tracepoint_event+0x145c>
    1019:      	leaq	0x10(%rsp), %rdi
    101e:      	movl	$0x8, %ecx
    1023:      	movl	$0x4, %eax
    1028:      	movl	$0x8, %esi
    102d:      	callq	*%rax
    102f:      	testq	%rax, %rax
    1032:      	je	0x1400 <generic_tracepoint_event+0x1400>
    1038:      	negl	%eax
    103a:      	movw	%ax, 0x20(%rsp)
    103f:      	movw	$0x7, 0x22(%rsp)
    1046:      	movabsq	$0x40000009a, %rax      # imm = 0x40000009A
    1050:      	movq	%rax, 0x24(%rsp)
    1055:      	movq	(%rip), %rdi            # 0x105c <generic_tracepoint_event+0x105c>
    105c:      	leaq	0x20(%rsp), %rsi
    1061:      	movl	$0x1, %eax
    1066:      	callq	*%rax
    1068:      	testq	%rax, %rax
    106b:      	jne	0x1251 <generic_tracepoint_event+0x1251>
    1071:      	movl	$0x1, 0x8(%rsp)
    1079:      	movq	(%rip), %rdi            # 0x1080 <generic_tracepoint_event+0x1080>
    1080:      	xorl	%ecx, %ecx
    1082:      	leaq	0x20(%rsp), %rsi
    1087:      	leaq	0x8(%rsp), %rdx
    108c:      	movl	$0x2, %eax
    1091:      	jmp	0x13fc <generic_tracepoint_event+0x13fc>
    1096:      	movq	%rdx, %r12
    1099:      	jmp	0x145c <generic_tracepoint_event+0x145c>
    109e:      	leaq	0x10(%rsp), %rdi
    10a3:      	movl	$0x8, %ecx
    10a8:      	movl	$0x4, %eax
    10ad:      	movl	$0x8, %esi
    10b2:      	callq	*%rax
    10b4:      	testq	%rax, %rax
    10b7:      	je	0x1400 <generic_tracepoint_event+0x1400>
    10bd:      	negl	%eax
    10bf:      	movw	%ax, 0x20(%rsp)
    10c4:      	movw	$0x7, 0x22(%rsp)
    10cb:      	movabsq	$0x400000093, %rax      # imm = 0x400000093
    10d5:      	movq	%rax, 0x24(%rsp)
    10da:      	movq	(%rip), %rdi            # 0x10e1 <generic_tracepoint_event+0x10e1>
    10e1:      	leaq	0x20(%rsp), %rsi
    10e6:      	movl	$0x1, %eax
    10eb:      	callq	*%rax
    10ed:      	testq	%rax, %rax
    10f0:      	jne	0x1251 <generic_tracepoint_event+0x1251>
    10f6:      	movl	$0x1, 0x8(%rsp)
    10fe:      	movq	(%rip), %rdi            # 0x1105 <generic_tracepoint_event+0x1105>
    1105:      	xorl	%ecx, %ecx
    1107:      	leaq	0x20(%rsp), %rsi
    110c:      	leaq	0x8(%rsp), %rdx
    1111:      	movl	$0x2, %eax
    1116:      	jmp	0x13fc <generic_tracepoint_event+0x13fc>
    111b:      	leaq	0x8(%rsp), %rdi
    1120:      	movl	$0x1, %ecx
    1125:      	movl	$0x4, %eax
    112a:      	movl	$0x1, %esi
    112f:      	callq	*%rax
    1131:      	testq	%rax, %rax
    1134:      	je	0x13a2 <generic_tracepoint_event+0x13a2>
    113a:      	negl	%eax
    113c:      	movw	%ax, 0x20(%rsp)
    1141:      	movw	$0x7, 0x22(%rsp)
    1148:      	movabsq	$0x40000007a, %rax      # imm = 0x40000007A
    1152:      	movq	%rax, 0x24(%rsp)
    1157:      	movq	(%rip), %rdi            # 0x115e <generic_tracepoint_event+0x115e>
    115e:      	leaq	0x20(%rsp), %rsi
    1163:      	movl	$0x1, %eax
    1168:      	callq	*%rax
    116a:      	testq	%rax, %rax
    116d:      	je	0x137e <generic_tracepoint_event+0x137e>
    1173:      	incl	(%rax)
    1175:      	movsbq	0x8(%rsp), %r12
    117b:      	jmp	0x145c <generic_tracepoint_event+0x145c>
    1180:      	leaq	0x10(%rsp), %rdi
    1185:      	movl	$0x8, %ecx
    118a:      	movl	$0x4, %eax
    118f:      	movl	$0x8, %esi
    1194:      	callq	*%rax
    1196:      	testq	%rax, %rax
    1199:      	je	0x1400 <generic_tracepoint_event+0x1400>
    119f:      	negl	%eax
    11a1:      	movw	%ax, 0x20(%rsp)
    11a6:      	movw	$0x7, 0x22(%rsp)
    11ad:      	movabsq	$0x4000000a1, %rax      # imm = 0x4000000A1
    11b7:      	movq	%rax, 0x24(%rsp)
    11bc:      	movq	(%rip), %rdi            # 0x11c3 <generic_tracepoint_event+0x11c3>
    11c3:      	leaq	0x20(%rsp), %rsi
    11c8:      	movl	$0x1, %eax
    11cd:      	callq	*%rax
    11cf:      	testq	%rax, %rax
    11d2:      	jne	0x1251 <generic_tracepoint_event+0x1251>
    11d4:      	movl	$0x1, 0x8(%rsp)
    11dc:      	movq	(%rip), %rdi            # 0x11e3 <generic_tracepoint_event+0x11e3>
    11e3:      	xorl	%ecx, %ecx
    11e5:      	leaq	0x20(%rsp), %rsi
    11ea:      	leaq	0x8(%rsp), %rdx
    11ef:      	movl	$0x2, %eax
    11f4:      	jmp	0x13fc <generic_tracepoint_event+0x13fc>
    11f9:      	leaq	0x10(%rsp), %rdi
    11fe:      	movl	$0x8, %ecx
    1203:      	movl	$0x4, %eax
    1208:      	movl	$0x8, %esi
    120d:      	callq	*%rax
    120f:      	testq	%rax, %rax
    1212:      	je	0x1400 <generic_tracepoint_event+0x1400>
    1218:      	negl	%eax
    121a:      	movw	%ax, 0x20(%rsp)
    121f:      	movw	$0x7, 0x22(%rsp)
    1226:      	movabsq	$0x40000004e, %rax      # imm = 0x40000004E
    1230:      	movq	%rax, 0x24(%rsp)
    1235:      	movq	(%rip), %rdi            # 0x123c <generic_tracepoint_event+0x123c>
    123c:      	leaq	0x20(%rsp), %rsi
    1241:      	movl	$0x1, %eax
    1246:      	callq	*%rax
    1248:      	testq	%rax, %rax
    124b:      	je	0x13dc <generic_tracepoint_event+0x13dc>
    1251:      	incl	(%rax)
    1253:      	jmp	0x1400 <generic_tracepoint_event+0x1400>
    1258:      	leaq	0x8(%rsp), %rdi
    125d:      	movl	$0x2, %ecx
    1262:      	movl	$0x4, %eax
    1267:      	movl	$0x2, %esi
    126c:      	callq	*%rax
    126e:      	testq	%rax, %rax
    1271:      	je	0x142b <generic_tracepoint_event+0x142b>
    1277:      	negl	%eax
    1279:      	movw	%ax, 0x20(%rsp)
    127e:      	movw	$0x7, 0x22(%rsp)
    1285:      	movabsq	$0x400000065, %rax      # imm = 0x400000065
    128f:      	movq	%rax, 0x24(%rsp)
    1294:      	movq	(%rip), %rdi            # 0x129b <generic_tracepoint_event+0x129b>
    129b:      	leaq	0x20(%rsp), %rsi
    12a0:      	movl	$0x1, %eax
    12a5:      	callq	*%rax
    12a7:      	testq	%rax, %rax
    12aa:      	je	0x1407 <generic_tracepoint_event+0x1407>
    12b0:      	incl	(%rax)
    12b2:      	movzwl	0x8(%rsp), %r12d
    12b8:      	jmp	0x145c <generic_tracepoint_event+0x145c>
    12bd:      	leaq	0x8(%rsp), %rdi
    12c2:      	movl	$0x4, %ecx
    12c7:      	movl	$0x4, %eax
    12cc:      	movl	$0x4, %esi
    12d1:      	callq	*%rax
    12d3:      	testq	%rax, %rax
    12d6:      	je	0x1457 <generic_tracepoint_event+0x1457>
    12dc:      	negl	%eax
    12de:      	movw	%ax, 0x20(%rsp)
    12e3:      	movw	$0x7, 0x22(%rsp)
    12ea:      	movabsq	$0x400000088, %rax      # imm = 0x400000088
    12f4:      	movq	%rax, 0x24(%rsp)
    12f9:      	movq	(%rip), %rdi            # 0x1300 <generic_tracepoint_event+0x1300>
    1300:      	leaq	0x20(%rsp), %rsi
    1305:      	movl	$0x1, %eax
    130a:      	callq	*%rax
    130c:      	testq	%rax, %rax
    130f:      	je	0x1433 <generic_tracepoint_event+0x1433>
    1315:      	incl	(%rax)
    1317:      	movl	0x8(%rsp), %r12d
    131c:      	jmp	0x145c <generic_tracepoint_event+0x145c>
    1321:      	movl	$0x1, 0x10(%rsp)
    1329:      	movq	(%rip), %rdi            # 0x1330 <generic_tracepoint_event+0x1330>
    1330:      	xorl	%ecx, %ecx
    1332:      	leaq	0x20(%rsp), %rsi
    1337:      	leaq	0x10(%rsp), %rdx
    133c:      	movl	$0x2, %eax
    1341:      	xorl	%ecx, %ecx
    1343:      	callq	*%rax
    1345:      	movslq	0x8(%rsp), %r12
    134a:      	jmp	0x145c <generic_tracepoint_event+0x145c>
    134f:      	movl	$0x1, 0x10(%rsp)
    1357:      	movq	(%rip), %rdi            # 0x135e <generic_tracepoint_event+0x135e>
    135e:      	xorl	%ecx, %ecx
    1360:      	leaq	0x20(%rsp), %rsi
    1365:      	leaq	0x10(%rsp), %rdx
    136a:      	movl	$0x2, %eax
    136f:      	xorl	%ecx, %ecx
    1371:      	callq	*%rax
    1373:      	movswq	0x8(%rsp), %r12
    1379:      	jmp	0x145c <generic_tracepoint_event+0x145c>
    137e:      	movl	$0x1, 0x10(%rsp)
    1386:      	movq	(%rip), %rdi            # 0x138d <generic_tracepoint_event+0x138d>
    138d:      	xorl	%ecx, %ecx
    138f:      	leaq	0x20(%rsp), %rsi
    1394:      	leaq	0x10(%rsp), %rdx
    1399:      	movl	$0x2, %eax
    139e:      	xorl	%ecx, %ecx
    13a0:      	callq	*%rax
    13a2:      	movsbq	0x8(%rsp), %r12
    13a8:      	jmp	0x145c <generic_tracepoint_event+0x145c>
    13ad:      	movl	$0x1, 0x10(%rsp)
    13b5:      	movq	(%rip), %rdi            # 0x13bc <generic_tracepoint_event+0x13bc>
    13bc:      	xorl	%ecx, %ecx
    13be:      	leaq	0x20(%rsp), %rsi
    13c3:      	leaq	0x10(%rsp), %rdx
    13c8:      	movl	$0x2, %eax
    13cd:      	xorl	%ecx, %ecx
    13cf:      	callq	*%rax
    13d1:      	movzbl	0x8(%rsp), %r12d
    13d7:      	jmp	0x145c <generic_tracepoint_event+0x145c>
    13dc:      	movl	$0x1, 0x8(%rsp)
    13e4:      	movq	(%rip), %rdi            # 0x13eb <generic_tracepoint_event+0x13eb>
    13eb:      	xorl	%ecx, %ecx
    13ed:      	leaq	0x20(%rsp), %rsi
    13f2:      	leaq	0x8(%rsp), %rdx
    13f7:      	movl	$0x2, %eax
    13fc:      	xorl	%ecx, %ecx
    13fe:      	callq	*%rax
    1400:      	movq	0x10(%rsp), %r12
    1405:      	jmp	0x145c <generic_tracepoint_event+0x145c>
    1407:      	movl	$0x1, 0x10(%rsp)
    140f:      	movq	(%rip), %rdi            # 0x1416 <generic_tracepoint_event+0x1416>
    1416:      	xorl	%ecx, %ecx
    1418:      	leaq	0x20(%rsp), %rsi
    141d:      	leaq	0x10(%rsp), %rdx
    1422:      	movl	$0x2, %eax
    1427:      	xorl	%ecx, %ecx
    1429:      	callq	*%rax
    142b:      	movzwl	0x8(%rsp), %r12d
    1431:      	jmp	0x145c <generic_tracepoint_event+0x145c>
    1433:      	movl	$0x1, 0x10(%rsp)
    143b:      	movq	(%rip), %rdi            # 0x1442 <generic_tracepoint_event+0x1442>
    1442:      	xorl	%ecx, %ecx
    1444:      	leaq	0x20(%rsp), %rsi
    1449:      	leaq	0x10(%rsp), %rdx
    144e:      	movl	$0x2, %eax
    1453:      	xorl	%ecx, %ecx
    1455:      	callq	*%rax
    1457:      	movl	0x8(%rsp), %r12d
    145c:      	movq	%r12, 0x5e58(%r14)
    1463:      	movzwl	0x34(%r15), %edx
    1468:      	movl	0xc(%r15), %r13d
    146c:      	addq	%rbx, %rdx
    146f:      	xorl	%r12d, %r12d
    1472:      	cmpl	$0xb, %r13d
    1476:      	jg	0x14af <generic_tracepoint_event+0x14af>
    1478:      	cmpl	$0x3, %r13d
    147c:      	jle	0x1546 <generic_tracepoint_event+0x1546>
    1482:      	cmpl	$0x6, %r13d
    1486:      	jg	0x166d <generic_tracepoint_event+0x166d>
    148c:      	cmpl	$0x4, %r13d
    1490:      	je	0x1ace <generic_tracepoint_event+0x1ace>
    1496:      	cmpl	$0x5, %r13d
    149a:      	je	0x1973 <generic_tracepoint_event+0x1973>
    14a0:      	cmpl	$0x6, %r13d
    14a4:      	je	0x1567 <generic_tracepoint_event+0x1567>
    14aa:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    14af:      	cmpl	$0x1d, %r13d
    14b3:      	jle	0x15e4 <generic_tracepoint_event+0x15e4>
    14b9:      	cmpl	$0x25, %r13d
    14bd:      	jg	0x16d9 <generic_tracepoint_event+0x16d9>
    14c3:      	cmpl	$0x1e, %r13d
    14c7:      	je	0x1b2d <generic_tracepoint_event+0x1b2d>
    14cd:      	cmpl	$0x1f, %r13d
    14d1:      	je	0x19f0 <generic_tracepoint_event+0x19f0>
    14d7:      	cmpl	$0x20, %r13d
    14db:      	jne	0x1d31 <generic_tracepoint_event+0x1d31>
    14e1:      	leaq	0x8(%rsp), %rdi
    14e6:      	movl	$0x1, %ecx
    14eb:      	movl	$0x4, %eax
    14f0:      	movl	$0x1, %esi
    14f5:      	callq	*%rax
    14f7:      	testq	%rax, %rax
    14fa:      	je	0x1ca6 <generic_tracepoint_event+0x1ca6>
    1500:      	negl	%eax
    1502:      	movw	%ax, 0x20(%rsp)
    1507:      	movw	$0x7, 0x22(%rsp)
    150e:      	movabsq	$0x400000073, %rax      # imm = 0x400000073
    1518:      	movq	%rax, 0x24(%rsp)
    151d:      	movq	(%rip), %rdi            # 0x1524 <generic_tracepoint_event+0x1524>
    1524:      	leaq	0x20(%rsp), %rsi
    1529:      	movl	$0x1, %eax
    152e:      	callq	*%rax
    1530:      	testq	%rax, %rax
    1533:      	je	0x1c82 <generic_tracepoint_event+0x1c82>
    1539:      	incl	(%rax)
    153b:      	movzbl	0x8(%rsp), %r12d
    1541:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    1546:      	cmpl	$-0xc, %r13d
    154a:      	jle	0x1774 <generic_tracepoint_event+0x1774>
    1550:      	leal	0xb(%r13), %eax
    1554:      	cmpl	$0x2, %eax
    1557:      	jb	0x167a <generic_tracepoint_event+0x167a>
    155d:      	cmpl	$0x2, %r13d
    1561:      	jne	0x1d31 <generic_tracepoint_event+0x1d31>
    1567:      	leaq	0x10(%rsp), %rdi
    156c:      	movl	$0x8, %ecx
    1571:      	movl	$0x4, %eax
    1576:      	movl	$0x8, %esi
    157b:      	callq	*%rax
    157d:      	testq	%rax, %rax
    1580:      	je	0x1cd5 <generic_tracepoint_event+0x1cd5>
    1586:      	negl	%eax
    1588:      	movw	%ax, 0x20(%rsp)
    158d:      	movw	$0x7, 0x22(%rsp)
    1594:      	movabsq	$0x400000081, %rax      # imm = 0x400000081
    159e:      	movq	%rax, 0x24(%rsp)
    15a3:      	movq	(%rip), %rdi            # 0x15aa <generic_tracepoint_event+0x15aa>
    15aa:      	leaq	0x20(%rsp), %rsi
    15af:      	movl	$0x1, %eax
    15b4:      	callq	*%rax
    15b6:      	testq	%rax, %rax
    15b9:      	jne	0x1b26 <generic_tracepoint_event+0x1b26>
    15bf:      	movl	$0x1, 0x8(%rsp)
    15c7:      	movq	(%rip), %rdi            # 0x15ce <generic_tracepoint_event+0x15ce>
    15ce:      	xorl	%ecx, %ecx
    15d0:      	leaq	0x20(%rsp), %rsi
    15d5:      	leaq	0x8(%rsp), %rdx
    15da:      	movl	$0x2, %eax
    15df:      	jmp	0x1cd1 <generic_tracepoint_event+0x1cd1>
    15e4:      	cmpl	$0x11, %r13d
    15e8:      	jle	0x1789 <generic_tracepoint_event+0x1789>
    15ee:      	cmpl	$0x12, %r13d
    15f2:      	je	0x196b <generic_tracepoint_event+0x196b>
    15f8:      	cmpl	$0x1c, %r13d
    15fc:      	je	0x167a <generic_tracepoint_event+0x167a>
    15fe:      	cmpl	$0x1d, %r13d
    1602:      	jne	0x1d31 <generic_tracepoint_event+0x1d31>
    1608:      	leaq	0x8(%rsp), %rdi
    160d:      	movl	$0x2, %ecx
    1612:      	movl	$0x4, %eax
    1617:      	movl	$0x2, %esi
    161c:      	callq	*%rax
    161e:      	testq	%rax, %rax
    1621:      	je	0x1c48 <generic_tracepoint_event+0x1c48>
    1627:      	negl	%eax
    1629:      	movw	%ax, 0x20(%rsp)
    162e:      	movw	$0x7, 0x22(%rsp)
    1635:      	movabsq	$0x40000006c, %rax      # imm = 0x40000006C
    163f:      	movq	%rax, 0x24(%rsp)
    1644:      	movq	(%rip), %rdi            # 0x164b <generic_tracepoint_event+0x164b>
    164b:      	leaq	0x20(%rsp), %rsi
    1650:      	movl	$0x1, %eax
    1655:      	callq	*%rax
    1657:      	testq	%rax, %rax
    165a:      	je	0x1c24 <generic_tracepoint_event+0x1c24>
    1660:      	incl	(%rax)
    1662:      	movswq	0x8(%rsp), %r12
    1668:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    166d:      	leal	-0xa(%r13), %eax
    1671:      	cmpl	$0x2, %eax
    1674:      	jae	0x18e4 <generic_tracepoint_event+0x18e4>
    167a:      	leaq	0x10(%rsp), %rdi
    167f:      	movl	$0x8, %ecx
    1684:      	movl	$0x4, %eax
    1689:      	movl	$0x8, %esi
    168e:      	callq	*%rax
    1690:      	testq	%rax, %rax
    1693:      	je	0x18a2 <generic_tracepoint_event+0x18a2>
    1699:      	negl	%eax
    169b:      	movw	%ax, 0x20(%rsp)
    16a0:      	movw	$0x7, 0x22(%rsp)
    16a7:      	movabsq	$0x400000045, %rax      # imm = 0x400000045
    16b1:      	movq	%rax, 0x24(%rsp)
    16b6:      	movq	(%rip), %rdi            # 0x16bd <generic_tracepoint_event+0x16bd>
    16bd:      	leaq	0x20(%rsp), %rsi
    16c2:      	movl	$0x1, %eax
    16c7:      	callq	*%rax
    16c9:      	testq	%rax, %rax
    16cc:      	je	0x187e <generic_tracepoint_event+0x187e>
    16d2:      	incl	(%rax)
    16d4:      	jmp	0x18a2 <generic_tracepoint_event+0x18a2>
    16d9:      	cmpl	$0x26, %r13d
    16dd:      	je	0x1b92 <generic_tracepoint_event+0x1b92>
    16e3:      	cmpl	$0x28, %r13d
    16e7:      	je	0x1a55 <generic_tracepoint_event+0x1a55>
    16ed:      	cmpl	$0x29, %r13d
    16f1:      	jne	0x1d31 <generic_tracepoint_event+0x1d31>
    16f7:      	leaq	0x10(%rsp), %rdi
    16fc:      	movl	$0x8, %ecx
    1701:      	movl	$0x4, %eax
    1706:      	movl	$0x8, %esi
    170b:      	callq	*%rax
    170d:      	testq	%rax, %rax
    1710:      	je	0x1cd5 <generic_tracepoint_event+0x1cd5>
    1716:      	negl	%eax
    1718:      	movw	%ax, 0x20(%rsp)
    171d:      	movw	$0x7, 0x22(%rsp)
    1724:      	movabsq	$0x4000000a8, %rax      # imm = 0x4000000A8
    172e:      	movq	%rax, 0x24(%rsp)
    1733:      	movq	(%rip), %rdi            # 0x173a <generic_tracepoint_event+0x173a>
    173a:      	leaq	0x20(%rsp), %rsi
    173f:      	movl	$0x1, %eax
    1744:      	callq	*%rax
    1746:      	testq	%rax, %rax
    1749:      	jne	0x1b26 <generic_tracepoint_event+0x1b26>
    174f:      	movl	$0x1, 0x8(%rsp)
    1757:      	movq	(%rip), %rdi            # 0x175e <generic_tracepoint_event+0x175e>
    175e:      	xorl	%ecx, %ecx
    1760:      	leaq	0x20(%rsp), %rsi
    1765:      	leaq	0x8(%rsp), %rdx
    176a:      	movl	$0x2, %eax
    176f:      	jmp	0x1cd1 <generic_tracepoint_event+0x1cd1>
    1774:      	cmpl	$-0xd, %r13d
    1778:      	je	0x181a <generic_tracepoint_event+0x181a>
    177e:      	cmpl	$-0xc, %r13d
    1782:      	je	0x179d <generic_tracepoint_event+0x179d>
    1784:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    1789:      	cmpl	$0xc, %r13d
    178d:      	je	0x181a <generic_tracepoint_event+0x181a>
    1793:      	cmpl	$0xd, %r13d
    1797:      	jne	0x1d31 <generic_tracepoint_event+0x1d31>
    179d:      	leaq	0x8(%rsp), %rdi
    17a2:      	movl	$0x4, %ecx
    17a7:      	movl	$0x4, %eax
    17ac:      	movl	$0x4, %esi
    17b1:      	callq	*%rax
    17b3:      	testq	%rax, %rax
    17b6:      	je	0x1d2c <generic_tracepoint_event+0x1d2c>
    17bc:      	negl	%eax
    17be:      	movw	%ax, 0x20(%rsp)
    17c3:      	movw	$0x7, 0x22(%rsp)
    17ca:      	movabsq	$0x40000005e, %rax      # imm = 0x40000005E
    17d4:      	movq	%rax, 0x24(%rsp)
    17d9:      	movq	(%rip), %rdi            # 0x17e0 <generic_tracepoint_event+0x17e0>
    17e0:      	leaq	0x20(%rsp), %rsi
    17e5:      	movl	$0x1, %eax
    17ea:      	callq	*%rax
    17ec:      	testq	%rax, %rax
    17ef:      	jne	0x1bea <generic_tracepoint_event+0x1bea>
    17f5:      	movl	$0x1, 0x10(%rsp)
    17fd:      	movq	(%rip), %rdi            # 0x1804 <generic_tracepoint_event+0x1804>
    1804:      	xorl	%ecx, %ecx
    1806:      	leaq	0x20(%rsp), %rsi
    180b:      	leaq	0x10(%rsp), %rdx
    1810:      	movl	$0x2, %eax
    1815:      	jmp	0x1d28 <generic_tracepoint_event+0x1d28>
    181a:      	leaq	0x8(%rsp), %rdi
    181f:      	movl	$0x4, %ecx
    1824:      	movl	$0x4, %eax
    1829:      	movl	$0x4, %esi
    182e:      	callq	*%rax
    1830:      	testq	%rax, %rax
    1833:      	je	0x1c1a <generic_tracepoint_event+0x1c1a>
    1839:      	negl	%eax
    183b:      	movw	%ax, 0x20(%rsp)
    1840:      	movw	$0x7, 0x22(%rsp)
    1847:      	movabsq	$0x400000056, %rax      # imm = 0x400000056
    1851:      	movq	%rax, 0x24(%rsp)
    1856:      	movq	(%rip), %rdi            # 0x185d <generic_tracepoint_event+0x185d>
    185d:      	leaq	0x20(%rsp), %rsi
    1862:      	movl	$0x1, %eax
    1867:      	callq	*%rax
    1869:      	testq	%rax, %rax
    186c:      	je	0x1bf6 <generic_tracepoint_event+0x1bf6>
    1872:      	incl	(%rax)
    1874:      	movslq	0x8(%rsp), %r12
    1879:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    187e:      	movl	$0x1, 0x8(%rsp)
    1886:      	movq	(%rip), %rdi            # 0x188d <generic_tracepoint_event+0x188d>
    188d:      	xorl	%ecx, %ecx
    188f:      	leaq	0x20(%rsp), %rsi
    1894:      	leaq	0x8(%rsp), %rdx
    1899:      	movl	$0x2, %eax
    189e:      	xorl	%ecx, %ecx
    18a0:      	callq	*%rax
    18a2:      	movq	0x10(%rsp), %r12
    18a7:      	cmpl	$0x1c, %r13d
    18ab:      	jne	0x1d31 <generic_tracepoint_event+0x1d31>
    18b1:      	movl	$0x23, %eax
    18b6:      	callq	*%rax
    18b8:      	leaq	0x10(%rax), %rdx
    18bc:      	leaq	0x20(%rsp), %rdi
    18c1:      	movl	$0x4, %ecx
    18c6:      	movl	$0x4, %eax
    18cb:      	movl	$0x4, %esi
    18d0:      	callq	*%rax
    18d2:      	movl	0x20(%rsp), %eax
    18d6:      	andl	$-0x2, %eax
    18d9:      	shll	$0x1e, %eax
    18dc:      	orq	%rax, %r12
    18df:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    18e4:      	cmpl	$0x7, %r13d
    18e8:      	jne	0x1d31 <generic_tracepoint_event+0x1d31>
    18ee:      	leaq	0x10(%rsp), %rdi
    18f3:      	movl	$0x8, %ecx
    18f8:      	movl	$0x4, %eax
    18fd:      	movl	$0x8, %esi
    1902:      	callq	*%rax
    1904:      	testq	%rax, %rax
    1907:      	je	0x1cd5 <generic_tracepoint_event+0x1cd5>
    190d:      	negl	%eax
    190f:      	movw	%ax, 0x20(%rsp)
    1914:      	movw	$0x7, 0x22(%rsp)
    191b:      	movabsq	$0x40000009a, %rax      # imm = 0x40000009A
    1925:      	movq	%rax, 0x24(%rsp)
    192a:      	movq	(%rip), %rdi            # 0x1931 <generic_tracepoint_event+0x1931>
    1931:      	leaq	0x20(%rsp), %rsi
    1936:      	movl	$0x1, %eax
    193b:      	callq	*%rax
    193d:      	testq	%rax, %rax
    1940:      	jne	0x1b26 <generic_tracepoint_event+0x1b26>
    1946:      	movl	$0x1, 0x8(%rsp)
    194e:      	movq	(%rip), %rdi            # 0x1955 <generic_tracepoint_event+0x1955>
    1955:      	xorl	%ecx, %ecx
    1957:      	leaq	0x20(%rsp), %rsi
    195c:      	leaq	0x8(%rsp), %rdx
    1961:      	movl	$0x2, %eax
    1966:      	jmp	0x1cd1 <generic_tracepoint_event+0x1cd1>
    196b:      	movq	%rdx, %r12
    196e:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    1973:      	leaq	0x10(%rsp), %rdi
    1978:      	movl	$0x8, %ecx
    197d:      	movl	$0x4, %eax
    1982:      	movl	$0x8, %esi
    1987:      	callq	*%rax
    1989:      	testq	%rax, %rax
    198c:      	je	0x1cd5 <generic_tracepoint_event+0x1cd5>
    1992:      	negl	%eax
    1994:      	movw	%ax, 0x20(%rsp)
    1999:      	movw	$0x7, 0x22(%rsp)
    19a0:      	movabsq	$0x400000093, %rax      # imm = 0x400000093
    19aa:      	movq	%rax, 0x24(%rsp)
    19af:      	movq	(%rip), %rdi            # 0x19b6 <generic_tracepoint_event+0x19b6>
    19b6:      	leaq	0x20(%rsp), %rsi
    19bb:      	movl	$0x1, %eax
    19c0:      	callq	*%rax
    19c2:      	testq	%rax, %rax
    19c5:      	jne	0x1b26 <generic_tracepoint_event+0x1b26>
    19cb:      	movl	$0x1, 0x8(%rsp)
    19d3:      	movq	(%rip), %rdi            # 0x19da <generic_tracepoint_event+0x19da>
    19da:      	xorl	%ecx, %ecx
    19dc:      	leaq	0x20(%rsp), %rsi
    19e1:      	leaq	0x8(%rsp), %rdx
    19e6:      	movl	$0x2, %eax
    19eb:      	jmp	0x1cd1 <generic_tracepoint_event+0x1cd1>
    19f0:      	leaq	0x8(%rsp), %rdi
    19f5:      	movl	$0x1, %ecx
    19fa:      	movl	$0x4, %eax
    19ff:      	movl	$0x1, %esi
    1a04:      	callq	*%rax
    1a06:      	testq	%rax, %rax
    1a09:      	je	0x1c77 <generic_tracepoint_event+0x1c77>
    1a0f:      	negl	%eax
    1a11:      	movw	%ax, 0x20(%rsp)
    1a16:      	movw	$0x7, 0x22(%rsp)
    1a1d:      	movabsq	$0x40000007a, %rax      # imm = 0x40000007A
    1a27:      	movq	%rax, 0x24(%rsp)
    1a2c:      	movq	(%rip), %rdi            # 0x1a33 <generic_tracepoint_event+0x1a33>
    1a33:      	leaq	0x20(%rsp), %rsi
    1a38:      	movl	$0x1, %eax
    1a3d:      	callq	*%rax
    1a3f:      	testq	%rax, %rax
    1a42:      	je	0x1c53 <generic_tracepoint_event+0x1c53>
    1a48:      	incl	(%rax)
    1a4a:      	movsbq	0x8(%rsp), %r12
    1a50:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    1a55:      	leaq	0x10(%rsp), %rdi
    1a5a:      	movl	$0x8, %ecx
    1a5f:      	movl	$0x4, %eax
    1a64:      	movl	$0x8, %esi
    1a69:      	callq	*%rax
    1a6b:      	testq	%rax, %rax
    1a6e:      	je	0x1cd5 <generic_tracepoint_event+0x1cd5>
    1a74:      	negl	%eax
    1a76:      	movw	%ax, 0x20(%rsp)
    1a7b:      	movw	$0x7, 0x22(%rsp)
    1a82:      	movabsq	$0x4000000a1, %rax      # imm = 0x4000000A1
    1a8c:      	movq	%rax, 0x24(%rsp)
    1a91:      	movq	(%rip), %rdi            # 0x1a98 <generic_tracepoint_event+0x1a98>
    1a98:      	leaq	0x20(%rsp), %rsi
    1a9d:      	movl	$0x1, %eax
    1aa2:      	callq	*%rax
    1aa4:      	testq	%rax, %rax
    1aa7:      	jne	0x1b26 <generic_tracepoint_event+0x1b26>
    1aa9:      	movl	$0x1, 0x8(%rsp)
    1ab1:      	movq	(%rip), %rdi            # 0x1ab8 <generic_tracepoint_event+0x1ab8>
    1ab8:      	xorl	%ecx, %ecx
    1aba:      	leaq	0x20(%rsp), %rsi
    1abf:      	leaq	0x8(%rsp), %rdx
    1ac4:      	movl	$0x2, %eax
    1ac9:      	jmp	0x1cd1 <generic_tracepoint_event+0x1cd1>
    1ace:      	leaq	0x10(%rsp), %rdi
    1ad3:      	movl	$0x8, %ecx
    1ad8:      	movl	$0x4, %eax
    1add:      	movl	$0x8, %esi
    1ae2:      	callq	*%rax
    1ae4:      	testq	%rax, %rax
    1ae7:      	je	0x1cd5 <generic_tracepoint_event+0x1cd5>
    1aed:      	negl	%eax
    1aef:      	movw	%ax, 0x20(%rsp)
    1af4:      	movw	$0x7, 0x22(%rsp)
    1afb:      	movabsq	$0x40000004e, %rax      # imm = 0x40000004E
    1b05:      	movq	%rax, 0x24(%rsp)
    1b0a:      	movq	(%rip), %rdi            # 0x1b11 <generic_tracepoint_event+0x1b11>
    1b11:      	leaq	0x20(%rsp), %rsi
    1b16:      	movl	$0x1, %eax
    1b1b:      	callq	*%rax
    1b1d:      	testq	%rax, %rax
    1b20:      	je	0x1cb1 <generic_tracepoint_event+0x1cb1>
    1b26:      	incl	(%rax)
    1b28:      	jmp	0x1cd5 <generic_tracepoint_event+0x1cd5>
    1b2d:      	leaq	0x8(%rsp), %rdi
    1b32:      	movl	$0x2, %ecx
    1b37:      	movl	$0x4, %eax
    1b3c:      	movl	$0x2, %esi
    1b41:      	callq	*%rax
    1b43:      	testq	%rax, %rax
    1b46:      	je	0x1d00 <generic_tracepoint_event+0x1d00>
    1b4c:      	negl	%eax
    1b4e:      	movw	%ax, 0x20(%rsp)
    1b53:      	movw	$0x7, 0x22(%rsp)
    1b5a:      	movabsq	$0x400000065, %rax      # imm = 0x400000065
    1b64:      	movq	%rax, 0x24(%rsp)
    1b69:      	movq	(%rip), %rdi            # 0x1b70 <generic_tracepoint_event+0x1b70>
    1b70:      	leaq	0x20(%rsp), %rsi
    1b75:      	movl	$0x1, %eax
    1b7a:      	callq	*%rax
    1b7c:      	testq	%rax, %rax
    1b7f:      	je	0x1cdc <generic_tracepoint_event+0x1cdc>
    1b85:      	incl	(%rax)
    1b87:      	movzwl	0x8(%rsp), %r12d
    1b8d:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    1b92:      	leaq	0x8(%rsp), %rdi
    1b97:      	movl	$0x4, %ecx
    1b9c:      	movl	$0x4, %eax
    1ba1:      	movl	$0x4, %esi
    1ba6:      	callq	*%rax
    1ba8:      	testq	%rax, %rax
    1bab:      	je	0x1d2c <generic_tracepoint_event+0x1d2c>
    1bb1:      	negl	%eax
    1bb3:      	movw	%ax, 0x20(%rsp)
    1bb8:      	movw	$0x7, 0x22(%rsp)
    1bbf:      	movabsq	$0x400000088, %rax      # imm = 0x400000088
    1bc9:      	movq	%rax, 0x24(%rsp)
    1bce:      	movq	(%rip), %rdi            # 0x1bd5 <generic_tracepoint_event+0x1bd5>
    1bd5:      	leaq	0x20(%rsp), %rsi
    1bda:      	movl	$0x1, %eax
    1bdf:      	callq	*%rax
    1be1:      	testq	%rax, %rax
    1be4:      	je	0x1d08 <generic_tracepoint_event+0x1d08>
    1bea:      	incl	(%rax)
    1bec:      	movl	0x8(%rsp), %r12d
    1bf1:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    1bf6:      	movl	$0x1, 0x10(%rsp)
    1bfe:      	movq	(%rip), %rdi            # 0x1c05 <generic_tracepoint_event+0x1c05>
    1c05:      	xorl	%ecx, %ecx
    1c07:      	leaq	0x20(%rsp), %rsi
    1c0c:      	leaq	0x10(%rsp), %rdx
    1c11:      	movl	$0x2, %eax
    1c16:      	xorl	%ecx, %ecx
    1c18:      	callq	*%rax
    1c1a:      	movslq	0x8(%rsp), %r12
    1c1f:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    1c24:      	movl	$0x1, 0x10(%rsp)
    1c2c:      	movq	(%rip), %rdi            # 0x1c33 <generic_tracepoint_event+0x1c33>
    1c33:      	xorl	%ecx, %ecx
    1c35:      	leaq	0x20(%rsp), %rsi
    1c3a:      	leaq	0x10(%rsp), %rdx
    1c3f:      	movl	$0x2, %eax
    1c44:      	xorl	%ecx, %ecx
    1c46:      	callq	*%rax
    1c48:      	movswq	0x8(%rsp), %r12
    1c4e:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    1c53:      	movl	$0x1, 0x10(%rsp)
    1c5b:      	movq	(%rip), %rdi            # 0x1c62 <generic_tracepoint_event+0x1c62>
    1c62:      	xorl	%ecx, %ecx
    1c64:      	leaq	0x20(%rsp), %rsi
    1c69:      	leaq	0x10(%rsp), %rdx
    1c6e:      	movl	$0x2, %eax
    1c73:      	xorl	%ecx, %ecx
    1c75:      	callq	*%rax
    1c77:      	movsbq	0x8(%rsp), %r12
    1c7d:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    1c82:      	movl	$0x1, 0x10(%rsp)
    1c8a:      	movq	(%rip), %rdi            # 0x1c91 <generic_tracepoint_event+0x1c91>
    1c91:      	xorl	%ecx, %ecx
    1c93:      	leaq	0x20(%rsp), %rsi
    1c98:      	leaq	0x10(%rsp), %rdx
    1c9d:      	movl	$0x2, %eax
    1ca2:      	xorl	%ecx, %ecx
    1ca4:      	callq	*%rax
    1ca6:      	movzbl	0x8(%rsp), %r12d
    1cac:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    1cb1:      	movl	$0x1, 0x8(%rsp)
    1cb9:      	movq	(%rip), %rdi            # 0x1cc0 <generic_tracepoint_event+0x1cc0>
    1cc0:      	xorl	%ecx, %ecx
    1cc2:      	leaq	0x20(%rsp), %rsi
    1cc7:      	leaq	0x8(%rsp), %rdx
    1ccc:      	movl	$0x2, %eax
    1cd1:      	xorl	%ecx, %ecx
    1cd3:      	callq	*%rax
    1cd5:      	movq	0x10(%rsp), %r12
    1cda:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    1cdc:      	movl	$0x1, 0x10(%rsp)
    1ce4:      	movq	(%rip), %rdi            # 0x1ceb <generic_tracepoint_event+0x1ceb>
    1ceb:      	xorl	%ecx, %ecx
    1ced:      	leaq	0x20(%rsp), %rsi
    1cf2:      	leaq	0x10(%rsp), %rdx
    1cf7:      	movl	$0x2, %eax
    1cfc:      	xorl	%ecx, %ecx
    1cfe:      	callq	*%rax
    1d00:      	movzwl	0x8(%rsp), %r12d
    1d06:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    1d08:      	movl	$0x1, 0x10(%rsp)
    1d10:      	movq	(%rip), %rdi            # 0x1d17 <generic_tracepoint_event+0x1d17>
    1d17:      	xorl	%ecx, %ecx
    1d19:      	leaq	0x20(%rsp), %rsi
    1d1e:      	leaq	0x10(%rsp), %rdx
    1d23:      	movl	$0x2, %eax
    1d28:      	xorl	%ecx, %ecx
    1d2a:      	callq	*%rax
    1d2c:      	movl	0x8(%rsp), %r12d
    1d31:      	movq	%r12, 0x5e60(%r14)
    1d38:      	movzwl	0x38(%r15), %edx
    1d3d:      	movl	0x10(%r15), %r13d
    1d41:      	addq	%rbx, %rdx
    1d44:      	xorl	%r12d, %r12d
    1d47:      	cmpl	$0xb, %r13d
    1d4b:      	jg	0x1d84 <generic_tracepoint_event+0x1d84>
    1d4d:      	cmpl	$0x3, %r13d
    1d51:      	jle	0x1e1b <generic_tracepoint_event+0x1e1b>
    1d57:      	cmpl	$0x6, %r13d
    1d5b:      	jg	0x1f42 <generic_tracepoint_event+0x1f42>
    1d61:      	cmpl	$0x4, %r13d
    1d65:      	je	0x23a3 <generic_tracepoint_event+0x23a3>
    1d6b:      	cmpl	$0x5, %r13d
    1d6f:      	je	0x2248 <generic_tracepoint_event+0x2248>
    1d75:      	cmpl	$0x6, %r13d
    1d79:      	je	0x1e3c <generic_tracepoint_event+0x1e3c>
    1d7f:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    1d84:      	cmpl	$0x1d, %r13d
    1d88:      	jle	0x1eb9 <generic_tracepoint_event+0x1eb9>
    1d8e:      	cmpl	$0x25, %r13d
    1d92:      	jg	0x1fae <generic_tracepoint_event+0x1fae>
    1d98:      	cmpl	$0x1e, %r13d
    1d9c:      	je	0x2402 <generic_tracepoint_event+0x2402>
    1da2:      	cmpl	$0x1f, %r13d
    1da6:      	je	0x22c5 <generic_tracepoint_event+0x22c5>
    1dac:      	cmpl	$0x20, %r13d
    1db0:      	jne	0x2606 <generic_tracepoint_event+0x2606>
    1db6:      	leaq	0x8(%rsp), %rdi
    1dbb:      	movl	$0x1, %ecx
    1dc0:      	movl	$0x4, %eax
    1dc5:      	movl	$0x1, %esi
    1dca:      	callq	*%rax
    1dcc:      	testq	%rax, %rax
    1dcf:      	je	0x257b <generic_tracepoint_event+0x257b>
    1dd5:      	negl	%eax
    1dd7:      	movw	%ax, 0x20(%rsp)
    1ddc:      	movw	$0x7, 0x22(%rsp)
    1de3:      	movabsq	$0x400000073, %rax      # imm = 0x400000073
    1ded:      	movq	%rax, 0x24(%rsp)
    1df2:      	movq	(%rip), %rdi            # 0x1df9 <generic_tracepoint_event+0x1df9>
    1df9:      	leaq	0x20(%rsp), %rsi
    1dfe:      	movl	$0x1, %eax
    1e03:      	callq	*%rax
    1e05:      	testq	%rax, %rax
    1e08:      	je	0x2557 <generic_tracepoint_event+0x2557>
    1e0e:      	incl	(%rax)
    1e10:      	movzbl	0x8(%rsp), %r12d
    1e16:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    1e1b:      	cmpl	$-0xc, %r13d
    1e1f:      	jle	0x2049 <generic_tracepoint_event+0x2049>
    1e25:      	leal	0xb(%r13), %eax
    1e29:      	cmpl	$0x2, %eax
    1e2c:      	jb	0x1f4f <generic_tracepoint_event+0x1f4f>
    1e32:      	cmpl	$0x2, %r13d
    1e36:      	jne	0x2606 <generic_tracepoint_event+0x2606>
    1e3c:      	leaq	0x10(%rsp), %rdi
    1e41:      	movl	$0x8, %ecx
    1e46:      	movl	$0x4, %eax
    1e4b:      	movl	$0x8, %esi
    1e50:      	callq	*%rax
    1e52:      	testq	%rax, %rax
    1e55:      	je	0x25aa <generic_tracepoint_event+0x25aa>
    1e5b:      	negl	%eax
    1e5d:      	movw	%ax, 0x20(%rsp)
    1e62:      	movw	$0x7, 0x22(%rsp)
    1e69:      	movabsq	$0x400000081, %rax      # imm = 0x400000081
    1e73:      	movq	%rax, 0x24(%rsp)
    1e78:      	movq	(%rip), %rdi            # 0x1e7f <generic_tracepoint_event+0x1e7f>
    1e7f:      	leaq	0x20(%rsp), %rsi
    1e84:      	movl	$0x1, %eax
    1e89:      	callq	*%rax
    1e8b:      	testq	%rax, %rax
    1e8e:      	jne	0x23fb <generic_tracepoint_event+0x23fb>
    1e94:      	movl	$0x1, 0x8(%rsp)
    1e9c:      	movq	(%rip), %rdi            # 0x1ea3 <generic_tracepoint_event+0x1ea3>
    1ea3:      	xorl	%ecx, %ecx
    1ea5:      	leaq	0x20(%rsp), %rsi
    1eaa:      	leaq	0x8(%rsp), %rdx
    1eaf:      	movl	$0x2, %eax
    1eb4:      	jmp	0x25a6 <generic_tracepoint_event+0x25a6>
    1eb9:      	cmpl	$0x11, %r13d
    1ebd:      	jle	0x205e <generic_tracepoint_event+0x205e>
    1ec3:      	cmpl	$0x12, %r13d
    1ec7:      	je	0x2240 <generic_tracepoint_event+0x2240>
    1ecd:      	cmpl	$0x1c, %r13d
    1ed1:      	je	0x1f4f <generic_tracepoint_event+0x1f4f>
    1ed3:      	cmpl	$0x1d, %r13d
    1ed7:      	jne	0x2606 <generic_tracepoint_event+0x2606>
    1edd:      	leaq	0x8(%rsp), %rdi
    1ee2:      	movl	$0x2, %ecx
    1ee7:      	movl	$0x4, %eax
    1eec:      	movl	$0x2, %esi
    1ef1:      	callq	*%rax
    1ef3:      	testq	%rax, %rax
    1ef6:      	je	0x251d <generic_tracepoint_event+0x251d>
    1efc:      	negl	%eax
    1efe:      	movw	%ax, 0x20(%rsp)
    1f03:      	movw	$0x7, 0x22(%rsp)
    1f0a:      	movabsq	$0x40000006c, %rax      # imm = 0x40000006C
    1f14:      	movq	%rax, 0x24(%rsp)
    1f19:      	movq	(%rip), %rdi            # 0x1f20 <generic_tracepoint_event+0x1f20>
    1f20:      	leaq	0x20(%rsp), %rsi
    1f25:      	movl	$0x1, %eax
    1f2a:      	callq	*%rax
    1f2c:      	testq	%rax, %rax
    1f2f:      	je	0x24f9 <generic_tracepoint_event+0x24f9>
    1f35:      	incl	(%rax)
    1f37:      	movswq	0x8(%rsp), %r12
    1f3d:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    1f42:      	leal	-0xa(%r13), %eax
    1f46:      	cmpl	$0x2, %eax
    1f49:      	jae	0x21b9 <generic_tracepoint_event+0x21b9>
    1f4f:      	leaq	0x10(%rsp), %rdi
    1f54:      	movl	$0x8, %ecx
    1f59:      	movl	$0x4, %eax
    1f5e:      	movl	$0x8, %esi
    1f63:      	callq	*%rax
    1f65:      	testq	%rax, %rax
    1f68:      	je	0x2177 <generic_tracepoint_event+0x2177>
    1f6e:      	negl	%eax
    1f70:      	movw	%ax, 0x20(%rsp)
    1f75:      	movw	$0x7, 0x22(%rsp)
    1f7c:      	movabsq	$0x400000045, %rax      # imm = 0x400000045
    1f86:      	movq	%rax, 0x24(%rsp)
    1f8b:      	movq	(%rip), %rdi            # 0x1f92 <generic_tracepoint_event+0x1f92>
    1f92:      	leaq	0x20(%rsp), %rsi
    1f97:      	movl	$0x1, %eax
    1f9c:      	callq	*%rax
    1f9e:      	testq	%rax, %rax
    1fa1:      	je	0x2153 <generic_tracepoint_event+0x2153>
    1fa7:      	incl	(%rax)
    1fa9:      	jmp	0x2177 <generic_tracepoint_event+0x2177>
    1fae:      	cmpl	$0x26, %r13d
    1fb2:      	je	0x2467 <generic_tracepoint_event+0x2467>
    1fb8:      	cmpl	$0x28, %r13d
    1fbc:      	je	0x232a <generic_tracepoint_event+0x232a>
    1fc2:      	cmpl	$0x29, %r13d
    1fc6:      	jne	0x2606 <generic_tracepoint_event+0x2606>
    1fcc:      	leaq	0x10(%rsp), %rdi
    1fd1:      	movl	$0x8, %ecx
    1fd6:      	movl	$0x4, %eax
    1fdb:      	movl	$0x8, %esi
    1fe0:      	callq	*%rax
    1fe2:      	testq	%rax, %rax
    1fe5:      	je	0x25aa <generic_tracepoint_event+0x25aa>
    1feb:      	negl	%eax
    1fed:      	movw	%ax, 0x20(%rsp)
    1ff2:      	movw	$0x7, 0x22(%rsp)
    1ff9:      	movabsq	$0x4000000a8, %rax      # imm = 0x4000000A8
    2003:      	movq	%rax, 0x24(%rsp)
    2008:      	movq	(%rip), %rdi            # 0x200f <generic_tracepoint_event+0x200f>
    200f:      	leaq	0x20(%rsp), %rsi
    2014:      	movl	$0x1, %eax
    2019:      	callq	*%rax
    201b:      	testq	%rax, %rax
    201e:      	jne	0x23fb <generic_tracepoint_event+0x23fb>
    2024:      	movl	$0x1, 0x8(%rsp)
    202c:      	movq	(%rip), %rdi            # 0x2033 <generic_tracepoint_event+0x2033>
    2033:      	xorl	%ecx, %ecx
    2035:      	leaq	0x20(%rsp), %rsi
    203a:      	leaq	0x8(%rsp), %rdx
    203f:      	movl	$0x2, %eax
    2044:      	jmp	0x25a6 <generic_tracepoint_event+0x25a6>
    2049:      	cmpl	$-0xd, %r13d
    204d:      	je	0x20ef <generic_tracepoint_event+0x20ef>
    2053:      	cmpl	$-0xc, %r13d
    2057:      	je	0x2072 <generic_tracepoint_event+0x2072>
    2059:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    205e:      	cmpl	$0xc, %r13d
    2062:      	je	0x20ef <generic_tracepoint_event+0x20ef>
    2068:      	cmpl	$0xd, %r13d
    206c:      	jne	0x2606 <generic_tracepoint_event+0x2606>
    2072:      	leaq	0x8(%rsp), %rdi
    2077:      	movl	$0x4, %ecx
    207c:      	movl	$0x4, %eax
    2081:      	movl	$0x4, %esi
    2086:      	callq	*%rax
    2088:      	testq	%rax, %rax
    208b:      	je	0x2601 <generic_tracepoint_event+0x2601>
    2091:      	negl	%eax
    2093:      	movw	%ax, 0x20(%rsp)
    2098:      	movw	$0x7, 0x22(%rsp)
    209f:      	movabsq	$0x40000005e, %rax      # imm = 0x40000005E
    20a9:      	movq	%rax, 0x24(%rsp)
    20ae:      	movq	(%rip), %rdi            # 0x20b5 <generic_tracepoint_event+0x20b5>
    20b5:      	leaq	0x20(%rsp), %rsi
    20ba:      	movl	$0x1, %eax
    20bf:      	callq	*%rax
    20c1:      	testq	%rax, %rax
    20c4:      	jne	0x24bf <generic_tracepoint_event+0x24bf>
    20ca:      	movl	$0x1, 0x10(%rsp)
    20d2:      	movq	(%rip), %rdi            # 0x20d9 <generic_tracepoint_event+0x20d9>
    20d9:      	xorl	%ecx, %ecx
    20db:      	leaq	0x20(%rsp), %rsi
    20e0:      	leaq	0x10(%rsp), %rdx
    20e5:      	movl	$0x2, %eax
    20ea:      	jmp	0x25fd <generic_tracepoint_event+0x25fd>
    20ef:      	leaq	0x8(%rsp), %rdi
    20f4:      	movl	$0x4, %ecx
    20f9:      	movl	$0x4, %eax
    20fe:      	movl	$0x4, %esi
    2103:      	callq	*%rax
    2105:      	testq	%rax, %rax
    2108:      	je	0x24ef <generic_tracepoint_event+0x24ef>
    210e:      	negl	%eax
    2110:      	movw	%ax, 0x20(%rsp)
    2115:      	movw	$0x7, 0x22(%rsp)
    211c:      	movabsq	$0x400000056, %rax      # imm = 0x400000056
    2126:      	movq	%rax, 0x24(%rsp)
    212b:      	movq	(%rip), %rdi            # 0x2132 <generic_tracepoint_event+0x2132>
    2132:      	leaq	0x20(%rsp), %rsi
    2137:      	movl	$0x1, %eax
    213c:      	callq	*%rax
    213e:      	testq	%rax, %rax
    2141:      	je	0x24cb <generic_tracepoint_event+0x24cb>
    2147:      	incl	(%rax)
    2149:      	movslq	0x8(%rsp), %r12
    214e:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    2153:      	movl	$0x1, 0x8(%rsp)
    215b:      	movq	(%rip), %rdi            # 0x2162 <generic_tracepoint_event+0x2162>
    2162:      	xorl	%ecx, %ecx
    2164:      	leaq	0x20(%rsp), %rsi
    2169:      	leaq	0x8(%rsp), %rdx
    216e:      	movl	$0x2, %eax
    2173:      	xorl	%ecx, %ecx
    2175:      	callq	*%rax
    2177:      	movq	0x10(%rsp), %r12
    217c:      	cmpl	$0x1c, %r13d
    2180:      	jne	0x2606 <generic_tracepoint_event+0x2606>
    2186:      	movl	$0x23, %eax
    218b:      	callq	*%rax
    218d:      	leaq	0x10(%rax), %rdx
    2191:      	leaq	0x20(%rsp), %rdi
    2196:      	movl	$0x4, %ecx
    219b:      	movl	$0x4, %eax
    21a0:      	movl	$0x4, %esi
    21a5:      	callq	*%rax
    21a7:      	movl	0x20(%rsp), %eax
    21ab:      	andl	$-0x2, %eax
    21ae:      	shll	$0x1e, %eax
    21b1:      	orq	%rax, %r12
    21b4:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    21b9:      	cmpl	$0x7, %r13d
    21bd:      	jne	0x2606 <generic_tracepoint_event+0x2606>
    21c3:      	leaq	0x10(%rsp), %rdi
    21c8:      	movl	$0x8, %ecx
    21cd:      	movl	$0x4, %eax
    21d2:      	movl	$0x8, %esi
    21d7:      	callq	*%rax
    21d9:      	testq	%rax, %rax
    21dc:      	je	0x25aa <generic_tracepoint_event+0x25aa>
    21e2:      	negl	%eax
    21e4:      	movw	%ax, 0x20(%rsp)
    21e9:      	movw	$0x7, 0x22(%rsp)
    21f0:      	movabsq	$0x40000009a, %rax      # imm = 0x40000009A
    21fa:      	movq	%rax, 0x24(%rsp)
    21ff:      	movq	(%rip), %rdi            # 0x2206 <generic_tracepoint_event+0x2206>
    2206:      	leaq	0x20(%rsp), %rsi
    220b:      	movl	$0x1, %eax
    2210:      	callq	*%rax
    2212:      	testq	%rax, %rax
    2215:      	jne	0x23fb <generic_tracepoint_event+0x23fb>
    221b:      	movl	$0x1, 0x8(%rsp)
    2223:      	movq	(%rip), %rdi            # 0x222a <generic_tracepoint_event+0x222a>
    222a:      	xorl	%ecx, %ecx
    222c:      	leaq	0x20(%rsp), %rsi
    2231:      	leaq	0x8(%rsp), %rdx
    2236:      	movl	$0x2, %eax
    223b:      	jmp	0x25a6 <generic_tracepoint_event+0x25a6>
    2240:      	movq	%rdx, %r12
    2243:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    2248:      	leaq	0x10(%rsp), %rdi
    224d:      	movl	$0x8, %ecx
    2252:      	movl	$0x4, %eax
    2257:      	movl	$0x8, %esi
    225c:      	callq	*%rax
    225e:      	testq	%rax, %rax
    2261:      	je	0x25aa <generic_tracepoint_event+0x25aa>
    2267:      	negl	%eax
    2269:      	movw	%ax, 0x20(%rsp)
    226e:      	movw	$0x7, 0x22(%rsp)
    2275:      	movabsq	$0x400000093, %rax      # imm = 0x400000093
    227f:      	movq	%rax, 0x24(%rsp)
    2284:      	movq	(%rip), %rdi            # 0x228b <generic_tracepoint_event+0x228b>
    228b:      	leaq	0x20(%rsp), %rsi
    2290:      	movl	$0x1, %eax
    2295:      	callq	*%rax
    2297:      	testq	%rax, %rax
    229a:      	jne	0x23fb <generic_tracepoint_event+0x23fb>
    22a0:      	movl	$0x1, 0x8(%rsp)
    22a8:      	movq	(%rip), %rdi            # 0x22af <generic_tracepoint_event+0x22af>
    22af:      	xorl	%ecx, %ecx
    22b1:      	leaq	0x20(%rsp), %rsi
    22b6:      	leaq	0x8(%rsp), %rdx
    22bb:      	movl	$0x2, %eax
    22c0:      	jmp	0x25a6 <generic_tracepoint_event+0x25a6>
    22c5:      	leaq	0x8(%rsp), %rdi
    22ca:      	movl	$0x1, %ecx
    22cf:      	movl	$0x4, %eax
    22d4:      	movl	$0x1, %esi
    22d9:      	callq	*%rax
    22db:      	testq	%rax, %rax
    22de:      	je	0x254c <generic_tracepoint_event+0x254c>
    22e4:      	negl	%eax
    22e6:      	movw	%ax, 0x20(%rsp)
    22eb:      	movw	$0x7, 0x22(%rsp)
    22f2:      	movabsq	$0x40000007a, %rax      # imm = 0x40000007A
    22fc:      	movq	%rax, 0x24(%rsp)
    2301:      	movq	(%rip), %rdi            # 0x2308 <generic_tracepoint_event+0x2308>
    2308:      	leaq	0x20(%rsp), %rsi
    230d:      	movl	$0x1, %eax
    2312:      	callq	*%rax
    2314:      	testq	%rax, %rax
    2317:      	je	0x2528 <generic_tracepoint_event+0x2528>
    231d:      	incl	(%rax)
    231f:      	movsbq	0x8(%rsp), %r12
    2325:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    232a:      	leaq	0x10(%rsp), %rdi
    232f:      	movl	$0x8, %ecx
    2334:      	movl	$0x4, %eax
    2339:      	movl	$0x8, %esi
    233e:      	callq	*%rax
    2340:      	testq	%rax, %rax
    2343:      	je	0x25aa <generic_tracepoint_event+0x25aa>
    2349:      	negl	%eax
    234b:      	movw	%ax, 0x20(%rsp)
    2350:      	movw	$0x7, 0x22(%rsp)
    2357:      	movabsq	$0x4000000a1, %rax      # imm = 0x4000000A1
    2361:      	movq	%rax, 0x24(%rsp)
    2366:      	movq	(%rip), %rdi            # 0x236d <generic_tracepoint_event+0x236d>
    236d:      	leaq	0x20(%rsp), %rsi
    2372:      	movl	$0x1, %eax
    2377:      	callq	*%rax
    2379:      	testq	%rax, %rax
    237c:      	jne	0x23fb <generic_tracepoint_event+0x23fb>
    237e:      	movl	$0x1, 0x8(%rsp)
    2386:      	movq	(%rip), %rdi            # 0x238d <generic_tracepoint_event+0x238d>
    238d:      	xorl	%ecx, %ecx
    238f:      	leaq	0x20(%rsp), %rsi
    2394:      	leaq	0x8(%rsp), %rdx
    2399:      	movl	$0x2, %eax
    239e:      	jmp	0x25a6 <generic_tracepoint_event+0x25a6>
    23a3:      	leaq	0x10(%rsp), %rdi
    23a8:      	movl	$0x8, %ecx
    23ad:      	movl	$0x4, %eax
    23b2:      	movl	$0x8, %esi
    23b7:      	callq	*%rax
    23b9:      	testq	%rax, %rax
    23bc:      	je	0x25aa <generic_tracepoint_event+0x25aa>
    23c2:      	negl	%eax
    23c4:      	movw	%ax, 0x20(%rsp)
    23c9:      	movw	$0x7, 0x22(%rsp)
    23d0:      	movabsq	$0x40000004e, %rax      # imm = 0x40000004E
    23da:      	movq	%rax, 0x24(%rsp)
    23df:      	movq	(%rip), %rdi            # 0x23e6 <generic_tracepoint_event+0x23e6>
    23e6:      	leaq	0x20(%rsp), %rsi
    23eb:      	movl	$0x1, %eax
    23f0:      	callq	*%rax
    23f2:      	testq	%rax, %rax
    23f5:      	je	0x2586 <generic_tracepoint_event+0x2586>
    23fb:      	incl	(%rax)
    23fd:      	jmp	0x25aa <generic_tracepoint_event+0x25aa>
    2402:      	leaq	0x8(%rsp), %rdi
    2407:      	movl	$0x2, %ecx
    240c:      	movl	$0x4, %eax
    2411:      	movl	$0x2, %esi
    2416:      	callq	*%rax
    2418:      	testq	%rax, %rax
    241b:      	je	0x25d5 <generic_tracepoint_event+0x25d5>
    2421:      	negl	%eax
    2423:      	movw	%ax, 0x20(%rsp)
    2428:      	movw	$0x7, 0x22(%rsp)
    242f:      	movabsq	$0x400000065, %rax      # imm = 0x400000065
    2439:      	movq	%rax, 0x24(%rsp)
    243e:      	movq	(%rip), %rdi            # 0x2445 <generic_tracepoint_event+0x2445>
    2445:      	leaq	0x20(%rsp), %rsi
    244a:      	movl	$0x1, %eax
    244f:      	callq	*%rax
    2451:      	testq	%rax, %rax
    2454:      	je	0x25b1 <generic_tracepoint_event+0x25b1>
    245a:      	incl	(%rax)
    245c:      	movzwl	0x8(%rsp), %r12d
    2462:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    2467:      	leaq	0x8(%rsp), %rdi
    246c:      	movl	$0x4, %ecx
    2471:      	movl	$0x4, %eax
    2476:      	movl	$0x4, %esi
    247b:      	callq	*%rax
    247d:      	testq	%rax, %rax
    2480:      	je	0x2601 <generic_tracepoint_event+0x2601>
    2486:      	negl	%eax
    2488:      	movw	%ax, 0x20(%rsp)
    248d:      	movw	$0x7, 0x22(%rsp)
    2494:      	movabsq	$0x400000088, %rax      # imm = 0x400000088
    249e:      	movq	%rax, 0x24(%rsp)
    24a3:      	movq	(%rip), %rdi            # 0x24aa <generic_tracepoint_event+0x24aa>
    24aa:      	leaq	0x20(%rsp), %rsi
    24af:      	movl	$0x1, %eax
    24b4:      	callq	*%rax
    24b6:      	testq	%rax, %rax
    24b9:      	je	0x25dd <generic_tracepoint_event+0x25dd>
    24bf:      	incl	(%rax)
    24c1:      	movl	0x8(%rsp), %r12d
    24c6:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    24cb:      	movl	$0x1, 0x10(%rsp)
    24d3:      	movq	(%rip), %rdi            # 0x24da <generic_tracepoint_event+0x24da>
    24da:      	xorl	%ecx, %ecx
    24dc:      	leaq	0x20(%rsp), %rsi
    24e1:      	leaq	0x10(%rsp), %rdx
    24e6:      	movl	$0x2, %eax
    24eb:      	xorl	%ecx, %ecx
    24ed:      	callq	*%rax
    24ef:      	movslq	0x8(%rsp), %r12
    24f4:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    24f9:      	movl	$0x1, 0x10(%rsp)
    2501:      	movq	(%rip), %rdi            # 0x2508 <generic_tracepoint_event+0x2508>
    2508:      	xorl	%ecx, %ecx
    250a:      	leaq	0x20(%rsp), %rsi
    250f:      	leaq	0x10(%rsp), %rdx
    2514:      	movl	$0x2, %eax
    2519:      	xorl	%ecx, %ecx
    251b:      	callq	*%rax
    251d:      	movswq	0x8(%rsp), %r12
    2523:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    2528:      	movl	$0x1, 0x10(%rsp)
    2530:      	movq	(%rip), %rdi            # 0x2537 <generic_tracepoint_event+0x2537>
    2537:      	xorl	%ecx, %ecx
    2539:      	leaq	0x20(%rsp), %rsi
    253e:      	leaq	0x10(%rsp), %rdx
    2543:      	movl	$0x2, %eax
    2548:      	xorl	%ecx, %ecx
    254a:      	callq	*%rax
    254c:      	movsbq	0x8(%rsp), %r12
    2552:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    2557:      	movl	$0x1, 0x10(%rsp)
    255f:      	movq	(%rip), %rdi            # 0x2566 <generic_tracepoint_event+0x2566>
    2566:      	xorl	%ecx, %ecx
    2568:      	leaq	0x20(%rsp), %rsi
    256d:      	leaq	0x10(%rsp), %rdx
    2572:      	movl	$0x2, %eax
    2577:      	xorl	%ecx, %ecx
    2579:      	callq	*%rax
    257b:      	movzbl	0x8(%rsp), %r12d
    2581:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    2586:      	movl	$0x1, 0x8(%rsp)
    258e:      	movq	(%rip), %rdi            # 0x2595 <generic_tracepoint_event+0x2595>
    2595:      	xorl	%ecx, %ecx
    2597:      	leaq	0x20(%rsp), %rsi
    259c:      	leaq	0x8(%rsp), %rdx
    25a1:      	movl	$0x2, %eax
    25a6:      	xorl	%ecx, %ecx
    25a8:      	callq	*%rax
    25aa:      	movq	0x10(%rsp), %r12
    25af:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    25b1:      	movl	$0x1, 0x10(%rsp)
    25b9:      	movq	(%rip), %rdi            # 0x25c0 <generic_tracepoint_event+0x25c0>
    25c0:      	xorl	%ecx, %ecx
    25c2:      	leaq	0x20(%rsp), %rsi
    25c7:      	leaq	0x10(%rsp), %rdx
    25cc:      	movl	$0x2, %eax
    25d1:      	xorl	%ecx, %ecx
    25d3:      	callq	*%rax
    25d5:      	movzwl	0x8(%rsp), %r12d
    25db:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    25dd:      	movl	$0x1, 0x10(%rsp)
    25e5:      	movq	(%rip), %rdi            # 0x25ec <generic_tracepoint_event+0x25ec>
    25ec:      	xorl	%ecx, %ecx
    25ee:      	leaq	0x20(%rsp), %rsi
    25f3:      	leaq	0x10(%rsp), %rdx
    25f8:      	movl	$0x2, %eax
    25fd:      	xorl	%ecx, %ecx
    25ff:      	callq	*%rax
    2601:      	movl	0x8(%rsp), %r12d
    2606:      	movq	%r12, 0x5e68(%r14)
    260d:      	movzwl	0x3c(%r15), %edx
    2612:      	movl	0x14(%r15), %r12d
    2616:      	addq	%rbx, %rdx
    2619:      	xorl	%r15d, %r15d
    261c:      	cmpl	$0xb, %r12d
    2620:      	jg	0x2659 <generic_tracepoint_event+0x2659>
    2622:      	cmpl	$0x3, %r12d
    2626:      	jle	0x26f0 <generic_tracepoint_event+0x26f0>
    262c:      	cmpl	$0x6, %r12d
    2630:      	jg	0x2818 <generic_tracepoint_event+0x2818>
    2636:      	cmpl	$0x4, %r12d
    263a:      	je	0x2c7a <generic_tracepoint_event+0x2c7a>
    2640:      	cmpl	$0x5, %r12d
    2644:      	je	0x2b1f <generic_tracepoint_event+0x2b1f>
    264a:      	cmpl	$0x6, %r12d
    264e:      	je	0x2712 <generic_tracepoint_event+0x2712>
    2654:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2659:      	cmpl	$0x1d, %r12d
    265d:      	jle	0x278f <generic_tracepoint_event+0x278f>
    2663:      	cmpl	$0x25, %r12d
    2667:      	jg	0x2885 <generic_tracepoint_event+0x2885>
    266d:      	cmpl	$0x1e, %r12d
    2671:      	je	0x2cd9 <generic_tracepoint_event+0x2cd9>
    2677:      	cmpl	$0x1f, %r12d
    267b:      	je	0x2b9c <generic_tracepoint_event+0x2b9c>
    2681:      	cmpl	$0x20, %r12d
    2685:      	jne	0x2edd <generic_tracepoint_event+0x2edd>
    268b:      	leaq	0x8(%rsp), %rdi
    2690:      	movl	$0x1, %ecx
    2695:      	movl	$0x4, %eax
    269a:      	movl	$0x1, %esi
    269f:      	callq	*%rax
    26a1:      	testq	%rax, %rax
    26a4:      	je	0x2e52 <generic_tracepoint_event+0x2e52>
    26aa:      	negl	%eax
    26ac:      	movw	%ax, 0x20(%rsp)
    26b1:      	movw	$0x7, 0x22(%rsp)
    26b8:      	movabsq	$0x400000073, %rax      # imm = 0x400000073
    26c2:      	movq	%rax, 0x24(%rsp)
    26c7:      	movq	(%rip), %rdi            # 0x26ce <generic_tracepoint_event+0x26ce>
    26ce:      	leaq	0x20(%rsp), %rsi
    26d3:      	movl	$0x1, %eax
    26d8:      	callq	*%rax
    26da:      	testq	%rax, %rax
    26dd:      	je	0x2e2e <generic_tracepoint_event+0x2e2e>
    26e3:      	incl	(%rax)
    26e5:      	movzbl	0x8(%rsp), %r15d
    26eb:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    26f0:      	cmpl	$-0xc, %r12d
    26f4:      	jle	0x2920 <generic_tracepoint_event+0x2920>
    26fa:      	leal	0xb(%r12), %eax
    26ff:      	cmpl	$0x2, %eax
    2702:      	jb	0x2826 <generic_tracepoint_event+0x2826>
    2708:      	cmpl	$0x2, %r12d
    270c:      	jne	0x2edd <generic_tracepoint_event+0x2edd>
    2712:      	leaq	0x10(%rsp), %rdi
    2717:      	movl	$0x8, %ecx
    271c:      	movl	$0x4, %eax
    2721:      	movl	$0x8, %esi
    2726:      	callq	*%rax
    2728:      	testq	%rax, %rax
    272b:      	je	0x2e81 <generic_tracepoint_event+0x2e81>
    2731:      	negl	%eax
    2733:      	movw	%ax, 0x20(%rsp)
    2738:      	movw	$0x7, 0x22(%rsp)
    273f:      	movabsq	$0x400000081, %rax      # imm = 0x400000081
    2749:      	movq	%rax, 0x24(%rsp)
    274e:      	movq	(%rip), %rdi            # 0x2755 <generic_tracepoint_event+0x2755>
    2755:      	leaq	0x20(%rsp), %rsi
    275a:      	movl	$0x1, %eax
    275f:      	callq	*%rax
    2761:      	testq	%rax, %rax
    2764:      	jne	0x2cd2 <generic_tracepoint_event+0x2cd2>
    276a:      	movl	$0x1, 0x8(%rsp)
    2772:      	movq	(%rip), %rdi            # 0x2779 <generic_tracepoint_event+0x2779>
    2779:      	xorl	%ecx, %ecx
    277b:      	leaq	0x20(%rsp), %rsi
    2780:      	leaq	0x8(%rsp), %rdx
    2785:      	movl	$0x2, %eax
    278a:      	jmp	0x2e7d <generic_tracepoint_event+0x2e7d>
    278f:      	cmpl	$0x11, %r12d
    2793:      	jle	0x2935 <generic_tracepoint_event+0x2935>
    2799:      	cmpl	$0x12, %r12d
    279d:      	je	0x2b17 <generic_tracepoint_event+0x2b17>
    27a3:      	cmpl	$0x1c, %r12d
    27a7:      	je	0x2826 <generic_tracepoint_event+0x2826>
    27a9:      	cmpl	$0x1d, %r12d
    27ad:      	jne	0x2edd <generic_tracepoint_event+0x2edd>
    27b3:      	leaq	0x8(%rsp), %rdi
    27b8:      	movl	$0x2, %ecx
    27bd:      	movl	$0x4, %eax
    27c2:      	movl	$0x2, %esi
    27c7:      	callq	*%rax
    27c9:      	testq	%rax, %rax
    27cc:      	je	0x2df4 <generic_tracepoint_event+0x2df4>
    27d2:      	negl	%eax
    27d4:      	movw	%ax, 0x20(%rsp)
    27d9:      	movw	$0x7, 0x22(%rsp)
    27e0:      	movabsq	$0x40000006c, %rax      # imm = 0x40000006C
    27ea:      	movq	%rax, 0x24(%rsp)
    27ef:      	movq	(%rip), %rdi            # 0x27f6 <generic_tracepoint_event+0x27f6>
    27f6:      	leaq	0x20(%rsp), %rsi
    27fb:      	movl	$0x1, %eax
    2800:      	callq	*%rax
    2802:      	testq	%rax, %rax
    2805:      	je	0x2dd0 <generic_tracepoint_event+0x2dd0>
    280b:      	incl	(%rax)
    280d:      	movswq	0x8(%rsp), %r15
    2813:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2818:      	leal	-0xa(%r12), %eax
    281d:      	cmpl	$0x2, %eax
    2820:      	jae	0x2a90 <generic_tracepoint_event+0x2a90>
    2826:      	leaq	0x10(%rsp), %rdi
    282b:      	movl	$0x8, %ecx
    2830:      	movl	$0x4, %eax
    2835:      	movl	$0x8, %esi
    283a:      	callq	*%rax
    283c:      	testq	%rax, %rax
    283f:      	je	0x2a4e <generic_tracepoint_event+0x2a4e>
    2845:      	negl	%eax
    2847:      	movw	%ax, 0x20(%rsp)
    284c:      	movw	$0x7, 0x22(%rsp)
    2853:      	movabsq	$0x400000045, %rax      # imm = 0x400000045
    285d:      	movq	%rax, 0x24(%rsp)
    2862:      	movq	(%rip), %rdi            # 0x2869 <generic_tracepoint_event+0x2869>
    2869:      	leaq	0x20(%rsp), %rsi
    286e:      	movl	$0x1, %eax
    2873:      	callq	*%rax
    2875:      	testq	%rax, %rax
    2878:      	je	0x2a2a <generic_tracepoint_event+0x2a2a>
    287e:      	incl	(%rax)
    2880:      	jmp	0x2a4e <generic_tracepoint_event+0x2a4e>
    2885:      	cmpl	$0x26, %r12d
    2889:      	je	0x2d3e <generic_tracepoint_event+0x2d3e>
    288f:      	cmpl	$0x28, %r12d
    2893:      	je	0x2c01 <generic_tracepoint_event+0x2c01>
    2899:      	cmpl	$0x29, %r12d
    289d:      	jne	0x2edd <generic_tracepoint_event+0x2edd>
    28a3:      	leaq	0x10(%rsp), %rdi
    28a8:      	movl	$0x8, %ecx
    28ad:      	movl	$0x4, %eax
    28b2:      	movl	$0x8, %esi
    28b7:      	callq	*%rax
    28b9:      	testq	%rax, %rax
    28bc:      	je	0x2e81 <generic_tracepoint_event+0x2e81>
    28c2:      	negl	%eax
    28c4:      	movw	%ax, 0x20(%rsp)
    28c9:      	movw	$0x7, 0x22(%rsp)
    28d0:      	movabsq	$0x4000000a8, %rax      # imm = 0x4000000A8
    28da:      	movq	%rax, 0x24(%rsp)
    28df:      	movq	(%rip), %rdi            # 0x28e6 <generic_tracepoint_event+0x28e6>
    28e6:      	leaq	0x20(%rsp), %rsi
    28eb:      	movl	$0x1, %eax
    28f0:      	callq	*%rax
    28f2:      	testq	%rax, %rax
    28f5:      	jne	0x2cd2 <generic_tracepoint_event+0x2cd2>
    28fb:      	movl	$0x1, 0x8(%rsp)
    2903:      	movq	(%rip), %rdi            # 0x290a <generic_tracepoint_event+0x290a>
    290a:      	xorl	%ecx, %ecx
    290c:      	leaq	0x20(%rsp), %rsi
    2911:      	leaq	0x8(%rsp), %rdx
    2916:      	movl	$0x2, %eax
    291b:      	jmp	0x2e7d <generic_tracepoint_event+0x2e7d>
    2920:      	cmpl	$-0xd, %r12d
    2924:      	je	0x29c6 <generic_tracepoint_event+0x29c6>
    292a:      	cmpl	$-0xc, %r12d
    292e:      	je	0x2949 <generic_tracepoint_event+0x2949>
    2930:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2935:      	cmpl	$0xc, %r12d
    2939:      	je	0x29c6 <generic_tracepoint_event+0x29c6>
    293f:      	cmpl	$0xd, %r12d
    2943:      	jne	0x2edd <generic_tracepoint_event+0x2edd>
    2949:      	leaq	0x8(%rsp), %rdi
    294e:      	movl	$0x4, %ecx
    2953:      	movl	$0x4, %eax
    2958:      	movl	$0x4, %esi
    295d:      	callq	*%rax
    295f:      	testq	%rax, %rax
    2962:      	je	0x2ed8 <generic_tracepoint_event+0x2ed8>
    2968:      	negl	%eax
    296a:      	movw	%ax, 0x20(%rsp)
    296f:      	movw	$0x7, 0x22(%rsp)
    2976:      	movabsq	$0x40000005e, %rax      # imm = 0x40000005E
    2980:      	movq	%rax, 0x24(%rsp)
    2985:      	movq	(%rip), %rdi            # 0x298c <generic_tracepoint_event+0x298c>
    298c:      	leaq	0x20(%rsp), %rsi
    2991:      	movl	$0x1, %eax
    2996:      	callq	*%rax
    2998:      	testq	%rax, %rax
    299b:      	jne	0x2d96 <generic_tracepoint_event+0x2d96>
    29a1:      	movl	$0x1, 0x10(%rsp)
    29a9:      	movq	(%rip), %rdi            # 0x29b0 <generic_tracepoint_event+0x29b0>
    29b0:      	xorl	%ecx, %ecx
    29b2:      	leaq	0x20(%rsp), %rsi
    29b7:      	leaq	0x10(%rsp), %rdx
    29bc:      	movl	$0x2, %eax
    29c1:      	jmp	0x2ed4 <generic_tracepoint_event+0x2ed4>
    29c6:      	leaq	0x8(%rsp), %rdi
    29cb:      	movl	$0x4, %ecx
    29d0:      	movl	$0x4, %eax
    29d5:      	movl	$0x4, %esi
    29da:      	callq	*%rax
    29dc:      	testq	%rax, %rax
    29df:      	je	0x2dc6 <generic_tracepoint_event+0x2dc6>
    29e5:      	negl	%eax
    29e7:      	movw	%ax, 0x20(%rsp)
    29ec:      	movw	$0x7, 0x22(%rsp)
    29f3:      	movabsq	$0x400000056, %rax      # imm = 0x400000056
    29fd:      	movq	%rax, 0x24(%rsp)
    2a02:      	movq	(%rip), %rdi            # 0x2a09 <generic_tracepoint_event+0x2a09>
    2a09:      	leaq	0x20(%rsp), %rsi
    2a0e:      	movl	$0x1, %eax
    2a13:      	callq	*%rax
    2a15:      	testq	%rax, %rax
    2a18:      	je	0x2da2 <generic_tracepoint_event+0x2da2>
    2a1e:      	incl	(%rax)
    2a20:      	movslq	0x8(%rsp), %r15
    2a25:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2a2a:      	movl	$0x1, 0x8(%rsp)
    2a32:      	movq	(%rip), %rdi            # 0x2a39 <generic_tracepoint_event+0x2a39>
    2a39:      	xorl	%ecx, %ecx
    2a3b:      	leaq	0x20(%rsp), %rsi
    2a40:      	leaq	0x8(%rsp), %rdx
    2a45:      	movl	$0x2, %eax
    2a4a:      	xorl	%ecx, %ecx
    2a4c:      	callq	*%rax
    2a4e:      	movq	0x10(%rsp), %r15
    2a53:      	cmpl	$0x1c, %r12d
    2a57:      	jne	0x2edd <generic_tracepoint_event+0x2edd>
    2a5d:      	movl	$0x23, %eax
    2a62:      	callq	*%rax
    2a64:      	leaq	0x10(%rax), %rdx
    2a68:      	leaq	0x20(%rsp), %rdi
    2a6d:      	movl	$0x4, %ecx
    2a72:      	movl	$0x4, %eax
    2a77:      	movl	$0x4, %esi
    2a7c:      	callq	*%rax
    2a7e:      	movl	0x20(%rsp), %eax
    2a82:      	andl	$-0x2, %eax
    2a85:      	shll	$0x1e, %eax
    2a88:      	orq	%rax, %r15
    2a8b:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2a90:      	cmpl	$0x7, %r12d
    2a94:      	jne	0x2edd <generic_tracepoint_event+0x2edd>
    2a9a:      	leaq	0x10(%rsp), %rdi
    2a9f:      	movl	$0x8, %ecx
    2aa4:      	movl	$0x4, %eax
    2aa9:      	movl	$0x8, %esi
    2aae:      	callq	*%rax
    2ab0:      	testq	%rax, %rax
    2ab3:      	je	0x2e81 <generic_tracepoint_event+0x2e81>
    2ab9:      	negl	%eax
    2abb:      	movw	%ax, 0x20(%rsp)
    2ac0:      	movw	$0x7, 0x22(%rsp)
    2ac7:      	movabsq	$0x40000009a, %rax      # imm = 0x40000009A
    2ad1:      	movq	%rax, 0x24(%rsp)
    2ad6:      	movq	(%rip), %rdi            # 0x2add <generic_tracepoint_event+0x2add>
    2add:      	leaq	0x20(%rsp), %rsi
    2ae2:      	movl	$0x1, %eax
    2ae7:      	callq	*%rax
    2ae9:      	testq	%rax, %rax
    2aec:      	jne	0x2cd2 <generic_tracepoint_event+0x2cd2>
    2af2:      	movl	$0x1, 0x8(%rsp)
    2afa:      	movq	(%rip), %rdi            # 0x2b01 <generic_tracepoint_event+0x2b01>
    2b01:      	xorl	%ecx, %ecx
    2b03:      	leaq	0x20(%rsp), %rsi
    2b08:      	leaq	0x8(%rsp), %rdx
    2b0d:      	movl	$0x2, %eax
    2b12:      	jmp	0x2e7d <generic_tracepoint_event+0x2e7d>
    2b17:      	movq	%rdx, %r15
    2b1a:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2b1f:      	leaq	0x10(%rsp), %rdi
    2b24:      	movl	$0x8, %ecx
    2b29:      	movl	$0x4, %eax
    2b2e:      	movl	$0x8, %esi
    2b33:      	callq	*%rax
    2b35:      	testq	%rax, %rax
    2b38:      	je	0x2e81 <generic_tracepoint_event+0x2e81>
    2b3e:      	negl	%eax
    2b40:      	movw	%ax, 0x20(%rsp)
    2b45:      	movw	$0x7, 0x22(%rsp)
    2b4c:      	movabsq	$0x400000093, %rax      # imm = 0x400000093
    2b56:      	movq	%rax, 0x24(%rsp)
    2b5b:      	movq	(%rip), %rdi            # 0x2b62 <generic_tracepoint_event+0x2b62>
    2b62:      	leaq	0x20(%rsp), %rsi
    2b67:      	movl	$0x1, %eax
    2b6c:      	callq	*%rax
    2b6e:      	testq	%rax, %rax
    2b71:      	jne	0x2cd2 <generic_tracepoint_event+0x2cd2>
    2b77:      	movl	$0x1, 0x8(%rsp)
    2b7f:      	movq	(%rip), %rdi            # 0x2b86 <generic_tracepoint_event+0x2b86>
    2b86:      	xorl	%ecx, %ecx
    2b88:      	leaq	0x20(%rsp), %rsi
    2b8d:      	leaq	0x8(%rsp), %rdx
    2b92:      	movl	$0x2, %eax
    2b97:      	jmp	0x2e7d <generic_tracepoint_event+0x2e7d>
    2b9c:      	leaq	0x8(%rsp), %rdi
    2ba1:      	movl	$0x1, %ecx
    2ba6:      	movl	$0x4, %eax
    2bab:      	movl	$0x1, %esi
    2bb0:      	callq	*%rax
    2bb2:      	testq	%rax, %rax
    2bb5:      	je	0x2e23 <generic_tracepoint_event+0x2e23>
    2bbb:      	negl	%eax
    2bbd:      	movw	%ax, 0x20(%rsp)
    2bc2:      	movw	$0x7, 0x22(%rsp)
    2bc9:      	movabsq	$0x40000007a, %rax      # imm = 0x40000007A
    2bd3:      	movq	%rax, 0x24(%rsp)
    2bd8:      	movq	(%rip), %rdi            # 0x2bdf <generic_tracepoint_event+0x2bdf>
    2bdf:      	leaq	0x20(%rsp), %rsi
    2be4:      	movl	$0x1, %eax
    2be9:      	callq	*%rax
    2beb:      	testq	%rax, %rax
    2bee:      	je	0x2dff <generic_tracepoint_event+0x2dff>
    2bf4:      	incl	(%rax)
    2bf6:      	movsbq	0x8(%rsp), %r15
    2bfc:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2c01:      	leaq	0x10(%rsp), %rdi
    2c06:      	movl	$0x8, %ecx
    2c0b:      	movl	$0x4, %eax
    2c10:      	movl	$0x8, %esi
    2c15:      	callq	*%rax
    2c17:      	testq	%rax, %rax
    2c1a:      	je	0x2e81 <generic_tracepoint_event+0x2e81>
    2c20:      	negl	%eax
    2c22:      	movw	%ax, 0x20(%rsp)
    2c27:      	movw	$0x7, 0x22(%rsp)
    2c2e:      	movabsq	$0x4000000a1, %rax      # imm = 0x4000000A1
    2c38:      	movq	%rax, 0x24(%rsp)
    2c3d:      	movq	(%rip), %rdi            # 0x2c44 <generic_tracepoint_event+0x2c44>
    2c44:      	leaq	0x20(%rsp), %rsi
    2c49:      	movl	$0x1, %eax
    2c4e:      	callq	*%rax
    2c50:      	testq	%rax, %rax
    2c53:      	jne	0x2cd2 <generic_tracepoint_event+0x2cd2>
    2c55:      	movl	$0x1, 0x8(%rsp)
    2c5d:      	movq	(%rip), %rdi            # 0x2c64 <generic_tracepoint_event+0x2c64>
    2c64:      	xorl	%ecx, %ecx
    2c66:      	leaq	0x20(%rsp), %rsi
    2c6b:      	leaq	0x8(%rsp), %rdx
    2c70:      	movl	$0x2, %eax
    2c75:      	jmp	0x2e7d <generic_tracepoint_event+0x2e7d>
    2c7a:      	leaq	0x10(%rsp), %rdi
    2c7f:      	movl	$0x8, %ecx
    2c84:      	movl	$0x4, %eax
    2c89:      	movl	$0x8, %esi
    2c8e:      	callq	*%rax
    2c90:      	testq	%rax, %rax
    2c93:      	je	0x2e81 <generic_tracepoint_event+0x2e81>
    2c99:      	negl	%eax
    2c9b:      	movw	%ax, 0x20(%rsp)
    2ca0:      	movw	$0x7, 0x22(%rsp)
    2ca7:      	movabsq	$0x40000004e, %rax      # imm = 0x40000004E
    2cb1:      	movq	%rax, 0x24(%rsp)
    2cb6:      	movq	(%rip), %rdi            # 0x2cbd <generic_tracepoint_event+0x2cbd>
    2cbd:      	leaq	0x20(%rsp), %rsi
    2cc2:      	movl	$0x1, %eax
    2cc7:      	callq	*%rax
    2cc9:      	testq	%rax, %rax
    2ccc:      	je	0x2e5d <generic_tracepoint_event+0x2e5d>
    2cd2:      	incl	(%rax)
    2cd4:      	jmp	0x2e81 <generic_tracepoint_event+0x2e81>
    2cd9:      	leaq	0x8(%rsp), %rdi
    2cde:      	movl	$0x2, %ecx
    2ce3:      	movl	$0x4, %eax
    2ce8:      	movl	$0x2, %esi
    2ced:      	callq	*%rax
    2cef:      	testq	%rax, %rax
    2cf2:      	je	0x2eac <generic_tracepoint_event+0x2eac>
    2cf8:      	negl	%eax
    2cfa:      	movw	%ax, 0x20(%rsp)
    2cff:      	movw	$0x7, 0x22(%rsp)
    2d06:      	movabsq	$0x400000065, %rax      # imm = 0x400000065
    2d10:      	movq	%rax, 0x24(%rsp)
    2d15:      	movq	(%rip), %rdi            # 0x2d1c <generic_tracepoint_event+0x2d1c>
    2d1c:      	leaq	0x20(%rsp), %rsi
    2d21:      	movl	$0x1, %eax
    2d26:      	callq	*%rax
    2d28:      	testq	%rax, %rax
    2d2b:      	je	0x2e88 <generic_tracepoint_event+0x2e88>
    2d31:      	incl	(%rax)
    2d33:      	movzwl	0x8(%rsp), %r15d
    2d39:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2d3e:      	leaq	0x8(%rsp), %rdi
    2d43:      	movl	$0x4, %ecx
    2d48:      	movl	$0x4, %eax
    2d4d:      	movl	$0x4, %esi
    2d52:      	callq	*%rax
    2d54:      	testq	%rax, %rax
    2d57:      	je	0x2ed8 <generic_tracepoint_event+0x2ed8>
    2d5d:      	negl	%eax
    2d5f:      	movw	%ax, 0x20(%rsp)
    2d64:      	movw	$0x7, 0x22(%rsp)
    2d6b:      	movabsq	$0x400000088, %rax      # imm = 0x400000088
    2d75:      	movq	%rax, 0x24(%rsp)
    2d7a:      	movq	(%rip), %rdi            # 0x2d81 <generic_tracepoint_event+0x2d81>
    2d81:      	leaq	0x20(%rsp), %rsi
    2d86:      	movl	$0x1, %eax
    2d8b:      	callq	*%rax
    2d8d:      	testq	%rax, %rax
    2d90:      	je	0x2eb4 <generic_tracepoint_event+0x2eb4>
    2d96:      	incl	(%rax)
    2d98:      	movl	0x8(%rsp), %r15d
    2d9d:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2da2:      	movl	$0x1, 0x10(%rsp)
    2daa:      	movq	(%rip), %rdi            # 0x2db1 <generic_tracepoint_event+0x2db1>
    2db1:      	xorl	%ecx, %ecx
    2db3:      	leaq	0x20(%rsp), %rsi
    2db8:      	leaq	0x10(%rsp), %rdx
    2dbd:      	movl	$0x2, %eax
    2dc2:      	xorl	%ecx, %ecx
    2dc4:      	callq	*%rax
    2dc6:      	movslq	0x8(%rsp), %r15
    2dcb:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2dd0:      	movl	$0x1, 0x10(%rsp)
    2dd8:      	movq	(%rip), %rdi            # 0x2ddf <generic_tracepoint_event+0x2ddf>
    2ddf:      	xorl	%ecx, %ecx
    2de1:      	leaq	0x20(%rsp), %rsi
    2de6:      	leaq	0x10(%rsp), %rdx
    2deb:      	movl	$0x2, %eax
    2df0:      	xorl	%ecx, %ecx
    2df2:      	callq	*%rax
    2df4:      	movswq	0x8(%rsp), %r15
    2dfa:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2dff:      	movl	$0x1, 0x10(%rsp)
    2e07:      	movq	(%rip), %rdi            # 0x2e0e <generic_tracepoint_event+0x2e0e>
    2e0e:      	xorl	%ecx, %ecx
    2e10:      	leaq	0x20(%rsp), %rsi
    2e15:      	leaq	0x10(%rsp), %rdx
    2e1a:      	movl	$0x2, %eax
    2e1f:      	xorl	%ecx, %ecx
    2e21:      	callq	*%rax
    2e23:      	movsbq	0x8(%rsp), %r15
    2e29:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2e2e:      	movl	$0x1, 0x10(%rsp)
    2e36:      	movq	(%rip), %rdi            # 0x2e3d <generic_tracepoint_event+0x2e3d>
    2e3d:      	xorl	%ecx, %ecx
    2e3f:      	leaq	0x20(%rsp), %rsi
    2e44:      	leaq	0x10(%rsp), %rdx
    2e49:      	movl	$0x2, %eax
    2e4e:      	xorl	%ecx, %ecx
    2e50:      	callq	*%rax
    2e52:      	movzbl	0x8(%rsp), %r15d
    2e58:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2e5d:      	movl	$0x1, 0x8(%rsp)
    2e65:      	movq	(%rip), %rdi            # 0x2e6c <generic_tracepoint_event+0x2e6c>
    2e6c:      	xorl	%ecx, %ecx
    2e6e:      	leaq	0x20(%rsp), %rsi
    2e73:      	leaq	0x8(%rsp), %rdx
    2e78:      	movl	$0x2, %eax
    2e7d:      	xorl	%ecx, %ecx
    2e7f:      	callq	*%rax
    2e81:      	movq	0x10(%rsp), %r15
    2e86:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2e88:      	movl	$0x1, 0x10(%rsp)
    2e90:      	movq	(%rip), %rdi            # 0x2e97 <generic_tracepoint_event+0x2e97>
    2e97:      	xorl	%ecx, %ecx
    2e99:      	leaq	0x20(%rsp), %rsi
    2e9e:      	leaq	0x10(%rsp), %rdx
    2ea3:      	movl	$0x2, %eax
    2ea8:      	xorl	%ecx, %ecx
    2eaa:      	callq	*%rax
    2eac:      	movzwl	0x8(%rsp), %r15d
    2eb2:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2eb4:      	movl	$0x1, 0x10(%rsp)
    2ebc:      	movq	(%rip), %rdi            # 0x2ec3 <generic_tracepoint_event+0x2ec3>
    2ec3:      	xorl	%ecx, %ecx
    2ec5:      	leaq	0x20(%rsp), %rsi
    2eca:      	leaq	0x10(%rsp), %rdx
    2ecf:      	movl	$0x2, %eax
    2ed4:      	xorl	%ecx, %ecx
    2ed6:      	callq	*%rax
    2ed8:      	movl	0x8(%rsp), %r15d
    2edd:      	movq	%r15, 0x5e70(%r14)
    2ee4:      	movb	$0xe, (%r14)
    2ee8:      	movw	$0x0, 0x2(%r14)
    2eef:      	movl	$0x0, 0x4(%r14)
    2ef7:      	movl	$0x7d, %eax
    2efc:      	callq	*%rax
    2efe:      	movq	%rax, 0x8(%r14)
    2f02:      	movq	$0x0, 0x70(%r14)
    2f0a:      	movl	$0x0, 0x14(%r14)
    2f12:      	movl	$0xe, %eax
    2f17:      	callq	*%rax
    2f19:      	movl	%eax, 0x7c(%r14)
    2f1d:      	movb	$0xe, (%r14)
    2f21:      	movq	$0x0, 0x5efc(%r14)
    2f2c:      	movq	$0x0, 0x5eb8(%r14)
    2f37:      	movq	$0x0, 0x5ec0(%r14)
    2f42:      	movq	$0x0, 0x5ec8(%r14)
    2f4d:      	movq	$0x0, 0x5ed0(%r14)
    2f58:      	movq	$0x0, 0x5ed8(%r14)
    2f63:      	movb	$0x0, 0x5ee0(%r14)
    2f6b:      	movl	$0x23, %eax
    2f70:      	callq	*%rax
    2f72:      	movq	%rax, %r15
    2f75:      	leaq	0xd70(%rax), %rdx
    2f7c:      	leaq	0x8(%rsp), %rdi
    2f81:      	movl	$0x8, %ecx
    2f86:      	movl	$0x4, %eax
    2f8b:      	leaq	0x20(%r14), %r12
    2f8f:      	movl	$0x4, %r13d
    2f95:      	movl	$0x8, %esi
    2f9a:      	callq	*%rax
    2f9c:      	movq	0x8(%rsp), %rcx
    2fa1:      	leaq	0x20(%rsp), %rdi
    2fa6:      	movl	$0x48, %edx
    2fab:      	movl	$0x4, %eax
    2fb0:      	movq	0x8(%rsp), %rdx
    2fb5:      	movl	$0x48, %esi
    2fba:      	callq	*%rax
    2fbc:      	movl	$0x218, %edx            # imm = 0x218
    2fc1:      	movq	0x28(%rsp), %rcx
    2fc6:      	addq	%rdx, %rcx
    2fc9:      	movl	$0x4, %esi
    2fce:      	movl	$0x4, %eax
    2fd3:      	addq	0x28(%rsp), %rdx
    2fd8:      	movq	%r12, %rdi
    2fdb:      	movl	$0x4, %esi
    2fe0:      	callq	*%rax
    2fe2:      	leaq	0x24(%r14), %rdi
    2fe6:      	movl	$0x4d8, %edx            # imm = 0x4D8
    2feb:      	movq	0x30(%rsp), %rcx
    2ff0:      	addq	%rdx, %rcx
    2ff3:      	movl	$0x4, %esi
    2ff8:      	movl	$0x4, %eax
    2ffd:      	addq	0x30(%rsp), %rdx
    3002:      	movl	$0x4, %esi
    3007:      	callq	*%rax
    3009:      	leaq	0x28(%r14), %rdi
    300d:      	movq	0x38(%rsp), %rcx
    3012:      	addq	$0x58, %rcx
    3016:      	movl	$0x4, %edx
    301b:      	movl	$0x4, %eax
    3020:      	movq	0x38(%rsp), %rdx
    3025:      	addq	$0x58, %rdx
    3029:      	movl	$0x4, %esi
    302e:      	callq	*%rax
    3030:      	movq	$0x0, 0x68(%rsp)
    3039:      	leaq	0xb58(%r15), %rdx
    3040:      	leaq	0x68(%rsp), %rdi
    3045:      	movl	$0x8, %ecx
    304a:      	movl	$0x4, %eax
    304f:      	movl	$0x8, %esi
    3054:      	callq	*%rax
    3056:      	movq	0x68(%rsp), %rcx
    305b:      	testq	%rcx, %rcx
    305e:      	je	0x30f4 <generic_tracepoint_event+0x30f4>
    3064:      	movl	$0x0, 0x70(%rsp)
    306c:      	addq	$0x4, %rcx
    3070:      	leaq	0x70(%rsp), %rdi
    3075:      	movl	$0x4, %eax
    307a:      	movq	0x68(%rsp), %rdx
    307f:      	addq	$0x4, %rdx
    3083:      	movl	$0x4, %esi
    3088:      	callq	*%rax
    308a:      	movq	0x68(%rsp), %rax
    308f:      	movslq	0x70(%rsp), %rcx
    3094:      	shlq	$0x4, %rcx
    3098:      	addq	%rax, %rcx
    309b:      	addq	$0x80, %rcx
    30a2:      	leaq	0x10(%rsp), %rdi
    30a7:      	movl	$0x10, %edx
    30ac:      	movl	$0x4, %eax
    30b1:      	movq	0x68(%rsp), %rcx
    30b6:      	movslq	0x70(%rsp), %rdx
    30bb:      	shlq	$0x4, %rdx
    30bf:      	addq	%rcx, %rdx
    30c2:      	addq	$0x80, %rdx
    30c9:      	movl	$0x10, %esi
    30ce:      	callq	*%rax
    30d0:      	leaq	0x2c(%r14), %rdi
    30d4:      	movl	$0x158, %edx            # imm = 0x158
    30d9:      	movq	0x18(%rsp), %rcx
    30de:      	addq	%rdx, %rcx
    30e1:      	movl	$0x4, %eax
    30e6:      	addq	0x18(%rsp), %rdx
    30eb:      	movl	$0x4, %esi
    30f0:      	callq	*%rax
    30f2:      	jmp	0x30fc <generic_tracepoint_event+0x30fc>
    30f4:      	movl	$0x0, 0x2c(%r14)
    30fc:      	leaq	0x30(%r14), %rdi
    3100:      	movl	$0x158, %r12d           # imm = 0x158
    3106:      	movq	0x40(%rsp), %rcx
    310b:      	addq	%r12, %rcx
    310e:      	movl	$0x4, %edx
    3113:      	movl	$0x4, %eax
    3118:      	movq	0x40(%rsp), %rdx
    311d:      	addq	%r12, %rdx
    3120:      	movl	$0x4, %esi
    3125:      	callq	*%rax
    3127:      	leaq	0x34(%r14), %rdi
    312b:      	movl	$0x118, %edx            # imm = 0x118
    3130:      	movq	0x48(%rsp), %rcx
    3135:      	addq	%rdx, %rcx
    3138:      	movl	$0x4, %esi
    313d:      	movl	$0x4, %eax
    3142:      	addq	0x48(%rsp), %rdx
    3147:      	movl	$0x4, %esi
    314c:      	callq	*%rax
    314e:      	leaq	0x38(%r14), %rdi
    3152:      	movl	$0x98, %r13d
    3158:      	movq	0x50(%rsp), %rcx
    315d:      	addq	%r13, %rcx
    3160:      	movl	$0x4, %edx
    3165:      	movl	$0x4, %eax
    316a:      	movq	0x50(%rsp), %rdx
    316f:      	addq	%r13, %rdx
    3172:      	movl	$0x4, %esi
    3177:      	callq	*%rax
    3179:      	leaq	0x3c(%r14), %rdi
    317d:      	movq	0x58(%rsp), %rcx
    3182:      	addq	%r13, %rcx
    3185:      	movl	$0x4, %edx
    318a:      	movl	$0x4, %eax
    318f:      	addq	0x58(%rsp), %r13
    3194:      	movl	$0x4, %esi
    3199:      	movq	%r13, %rdx
    319c:      	callq	*%rax
    319e:      	leaq	0x40(%r14), %rdi
    31a2:      	movq	0x60(%rsp), %rcx
    31a7:      	addq	$0x58, %rcx
    31ab:      	movl	$0x4, %edx
    31b0:      	movl	$0x4, %eax
    31b5:      	movq	0x60(%rsp), %rdx
    31ba:      	addq	$0x58, %rdx
    31be:      	movl	$0x4, %esi
    31c3:      	callq	*%rax
    31c5:      	movq	$0x0, 0x10(%rsp)
    31ce:      	movq	$0x0, 0x68(%rsp)
    31d7:      	addq	$0xd00, %r15            # imm = 0xD00
    31de:      	leaq	0x10(%rsp), %rdi
    31e3:      	movl	$0x8, %ecx
    31e8:      	movl	$0x4, %eax
    31ed:      	movl	$0x8, %esi
    31f2:      	movq	%r15, %rdx
    31f5:      	callq	*%rax
    31f7:      	movl	$0x90, %edx
    31fc:      	movq	0x10(%rsp), %rcx
    3201:      	addq	%rdx, %rcx
    3204:      	leaq	0x68(%rsp), %rdi
    3209:      	movl	$0x8, %esi
    320e:      	movl	$0x4, %eax
    3213:      	addq	0x10(%rsp), %rdx
    3218:      	movl	$0x8, %esi
    321d:      	callq	*%rax
    321f:      	leaq	0x44(%r14), %rdi
    3223:      	movq	0x68(%rsp), %rcx
    3228:      	addq	%r12, %rcx
    322b:      	movl	$0x4, %edx
    3230:      	movl	$0x4, %eax
    3235:      	addq	0x68(%rsp), %r12
    323a:      	movl	$0x4, %esi
    323f:      	movq	%r12, %rdx
    3242:      	callq	*%rax
    3244:      	leaq	0x48(%r14), %r12
    3248:      	leaq	0x20(%rsp), %rdi
    324d:      	movl	$0x8, %ecx
    3252:      	movl	$0x4, %eax
    3257:      	movl	$0x8, %esi
    325c:      	movq	%r15, %rdx
    325f:      	callq	*%rax
    3261:      	movq	0x20(%rsp), %r15
    3266:      	leaq	0x50(%r14), %rdi
    326a:      	leaq	0x40(%r15), %rdx
    326e:      	movl	$0x8, %ecx
    3273:      	movl	$0x4, %eax
    3278:      	movl	$0x8, %esi
    327d:      	callq	*%rax
    327f:      	movq	%r14, %rdi
    3282:      	addq	$0x58, %rdi
    3286:      	leaq	0x30(%r15), %rdx
    328a:      	movl	$0x8, %ecx
    328f:      	movl	$0x4, %eax
    3294:      	movl	$0x8, %esi
    3299:      	callq	*%rax
    329b:      	addq	$0x38, %r15
    329f:      	movl	$0x8, %ecx
    32a4:      	movl	$0x4, %eax
    32a9:      	movq	%r12, %rdi
    32ac:      	movl	$0x8, %esi
    32b1:      	movq	%r15, %rdx
    32b4:      	callq	*%rax
    32b6:      	movb	$0x0, 0x1(%r14)
    32bb:      	movq	$0x0, 0x5ee8(%r14)
    32c6:      	movq	$0x0, 0x5ef0(%r14)
    32d1:      	movq	(%rip), %rsi            # 0x32d8 <generic_tracepoint_event+0x32d8>
    32d8:      	movl	$0x2, %ecx
    32dd:      	movl	$0xc, %eax
    32e2:      	movq	%rbx, %rdi
    32e5:      	movl	$0x2, %edx
    32ea:      	callq	*%rax
    32ec:      	xorl	%eax, %eax
    32ee:      	addq	$0x88, %rsp
    32f5:      	popq	%rbx
    32f6:      	popq	%r12
    32f8:      	popq	%r13
    32fa:      	popq	%r14
    32fc:      	popq	%r15
    32fe:      	popq	%rbp
    32ff:      	retq
