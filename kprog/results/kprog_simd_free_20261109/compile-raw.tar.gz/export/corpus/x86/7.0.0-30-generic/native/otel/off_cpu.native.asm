
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/otel/off_cpu.native.o:	file format elf64-x86-64

Disassembly of section tracepoint/sched/sched_switch:

0000000000000000 <tracepoint__sched_switch>:
       0:      	subq	$0x48, %rsp
       4:      	movl	$0xe, %eax
       9:      	callq	*%rax
       b:      	movq	%rax, 0x8(%rsp)
      10:      	movq	%rax, %rcx
      13:      	shrq	$0x20, %rcx
      17:      	je	0x6c <tracepoint__sched_switch+0x6c>
      19:      	movl	%eax, %eax
      1b:      	testq	%rax, %rax
      1e:      	je	0x6c <tracepoint__sched_switch+0x6c>
      20:      	movl	$0x7, %eax
      25:      	callq	*%rax
      27:      	movq	(%rip), %rcx            # 0x2e <tracepoint__sched_switch+0x2e>
      2e:      	movl	(%rcx), %ecx
      30:      	cmpq	%rcx, %rax
      33:      	ja	0x6c <tracepoint__sched_switch+0x6c>
      35:      	movl	$0x5, %eax
      3a:      	callq	*%rax
      3c:      	movq	%rax, (%rsp)
      40:      	movq	(%rip), %rdi            # 0x47 <tracepoint__sched_switch+0x47>
      47:      	xorl	%eax, %eax
      49:      	leaq	0x8(%rsp), %rsi
      4e:      	movq	%rsp, %rdx
      51:      	movl	$0x2, %r8d
      57:      	xorl	%ecx, %ecx
      59:      	callq	*%r8
      5c:      	testl	%eax, %eax
      5e:      	jns	0x6c <tracepoint__sched_switch+0x6c>
      60:      	movq	(%rip), %rax            # 0x67 <tracepoint__sched_switch+0x67>
      67:      	cmpl	$0x0, (%rax)
      6a:      	jne	0x73 <tracepoint__sched_switch+0x73>
      6c:      	xorl	%eax, %eax
      6e:      	addq	$0x48, %rsp
      72:      	retq
      73:      	movabsq	$0x72746e6520746e65, %rax # imm = 0x72746E6520746E65
      7d:      	movq	%rax, 0x30(%rsp)
      82:      	movabsq	$0x7665206863746977, %rax # imm = 0x7665206863746977
      8c:      	movq	%rax, 0x28(%rsp)
      91:      	movabsq	$0x735f646568637320, %rax # imm = 0x735F646568637320
      9b:      	movq	%rax, 0x20(%rsp)
      a0:      	movabsq	$0x64726f636572206f, %rax # imm = 0x64726F636572206F
      aa:      	movq	%rax, 0x18(%rsp)
      af:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
      b9:      	movq	%rax, 0x10(%rsp)
      be:      	movl	$0xa7972, 0x37(%rsp)    # imm = 0xA7972
      c6:      	leaq	0x10(%rsp), %rdi
      cb:      	movl	$0x2b, %eax
      d0:      	movl	$0x6, %ecx
      d5:      	movl	$0x2b, %esi
      da:      	xorl	%eax, %eax
      dc:      	callq	*%rcx
      de:      	xorl	%eax, %eax
      e0:      	addq	$0x48, %rsp
      e4:      	retq

Disassembly of section kprobe/dummy:

0000000000000000 <kprobe__dummy>:
       0:      	pushq	%rax
       1:      	movq	(%rip), %rsi            # 0x8 <kprobe__dummy+0x8>
       8:      	xorl	%eax, %eax
       a:      	movl	$0xc, %ecx
       f:      	xorl	%edx, %edx
      11:      	callq	*%rcx
      13:      	xorl	%eax, %eax
      15:      	popq	%rcx
      16:      	retq

Disassembly of section kprobe/finish_task_switch:

0000000000000000 <finish_task_switch>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x108, %rsp            # imm = 0x108
      11:      	movq	%rdi, %rbx
      14:      	movl	$0xe, %eax
      19:      	callq	*%rax
      1b:      	movq	%rax, %r12
      1e:      	movq	%rax, 0x100(%rsp)
      26:      	xorl	%ebp, %ebp
      28:      	testl	%r12d, %r12d
      2b:      	je	0xa20 <finish_task_switch+0xa20>
      31:      	movq	%r12, %r15
      34:      	shrq	$0x20, %r15
      38:      	testl	%r15d, %r15d
      3b:      	je	0xa20 <finish_task_switch+0xa20>
      41:      	movq	%rbx, 0x10(%rsp)
      46:      	movl	$0x5, %eax
      4b:      	callq	*%rax
      4d:      	movq	%rax, %rbx
      50:      	movq	(%rip), %rdi            # 0x57 <finish_task_switch+0x57>
      57:      	leaq	0x100(%rsp), %rsi
      5f:      	movl	$0x1, %eax
      64:      	callq	*%rax
      66:      	testq	%rax, %rax
      69:      	je	0xa20 <finish_task_switch+0xa20>
      6f:      	movq	%rax, %r14
      72:      	cmpq	$0x0, (%rax)
      76:      	je	0xa20 <finish_task_switch+0xa20>
      7c:      	movq	(%rip), %rdi            # 0x83 <finish_task_switch+0x83>
      83:      	leaq	0x100(%rsp), %rsi
      8b:      	movl	$0x3, %eax
      90:      	callq	*%rax
      92:      	movq	%rbx, %r13
      95:      	movq	(%rip), %rax            # 0x9c <finish_task_switch+0x9c>
      9c:      	subq	(%r14), %r13
      9f:      	cmpl	$0x0, (%rax)
      a2:      	jne	0x7b5 <finish_task_switch+0x7b5>
      a8:      	movl	$0x0, 0x20(%rsp)
      b0:      	movq	(%rip), %rdi            # 0xb7 <finish_task_switch+0xb7>
      b7:      	leaq	0x20(%rsp), %rsi
      bc:      	movl	$0x1, %eax
      c1:      	callq	*%rax
      c3:      	movl	$0xffffffff, %ebp       # imm = 0xFFFFFFFF
      c8:      	testq	%rax, %rax
      cb:      	je	0xa20 <finish_task_switch+0xa20>
      d1:      	movq	%rax, %r14
      d4:      	movq	$0x0, 0xf00(%rax)
      df:      	movb	$0x0, 0xf30(%rax)
      e6:      	movq	$0x0, 0xed0(%rax)
      f1:      	movq	$0x0, 0xed8(%rax)
      fc:      	movq	$0x0, 0xee0(%rax)
     107:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
     10c:      	movq	%rax, 0xf28(%r14)
     113:      	movl	$0x0, 0x1380(%r14)
     11e:      	movw	$0x100, 0x1384(%r14)    # imm = 0x100
     128:      	movq	$0x0, 0xf38(%r14)
     133:      	movq	$0x0, 0xf40(%r14)
     13e:      	movq	$0x0, 0xf58(%r14)
     149:      	movq	$0x0, 0xf60(%r14)
     154:      	movq	$0x0, 0xf68(%r14)
     15f:      	movq	$0x0, 0xf70(%r14)
     16a:      	movq	$0x0, 0xf78(%r14)
     175:      	movq	%rax, 0x2bc(%r14)
     17c:      	leaq	0x20(%r14), %rdi
     180:      	movl	$0x29c, %edx            # imm = 0x29C
     185:      	xorl	%esi, %esi
     187:      	callq	0x18c <finish_task_switch+0x18c>
     18c:      	movl	$0x2, 0x2c4(%r14)
     197:      	movl	%r15d, (%r14)
     19a:      	movl	%r12d, 0x4(%r14)
     19e:      	movq	%rbx, 0x8(%r14)
     1a2:      	movq	%r13, 0x2c8(%r14)
     1a9:      	leaq	0x10(%r14), %rdi
     1ad:      	movl	$0x10, %eax
     1b2:      	movl	$0x10, %ecx
     1b7:      	movl	$0x10, %esi
     1bc:      	callq	*%rcx
     1be:      	testl	%eax, %eax
     1c0:      	movq	(%rip), %r13            # 0x1c7 <finish_task_switch+0x1c7>
     1c7:      	movq	0x10(%rsp), %rbx
     1cc:      	jns	0x204 <finish_task_switch+0x204>
     1ce:      	movl	$0x34, 0xd0(%rsp)
     1d9:      	movq	(%rip), %rdi            # 0x1e0 <finish_task_switch+0x1e0>
     1e0:      	leaq	0xd0(%rsp), %rsi
     1e8:      	movl	$0x1, %eax
     1ed:      	callq	*%rax
     1ef:      	testq	%rax, %rax
     1f2:      	je	0x1f9 <finish_task_switch+0x1f9>
     1f4:      	incq	(%rax)
     1f7:      	jmp	0x204 <finish_task_switch+0x204>
     1f9:      	cmpl	$0x0, (%r13)
     1fe:      	jne	0xc73 <finish_task_switch+0xc73>
     204:      	movq	(%rip), %rsi            # 0x20b <finish_task_switch+0x20b>
     20b:      	movl	$0x400, %eax            # imm = 0x400
     210:      	movl	$0x1b, %ecx
     215:      	movl	$0x400, %edx            # imm = 0x400
     21a:      	movq	%rbx, %rdi
     21d:      	callq	*%rcx
     21f:      	movl	%eax, 0x2bc(%r14)
     226:      	cmpl	$0x0, (%r13)
     22b:      	jne	0x863 <finish_task_switch+0x863>
     231:      	cmpq	$0x2b, 0xa0(%rbx)
     239:      	jne	0x8bd <finish_task_switch+0x8bd>
     23f:      	cmpq	$0x23, 0x88(%rbx)
     247:      	jne	0x254 <finish_task_switch+0x254>
     249:      	movl	$0xfb1, %r12d           # imm = 0xFB1
     24f:      	jmp	0x956 <finish_task_switch+0x956>
     254:      	movq	0x80(%rbx), %rax
     25b:      	movq	%rax, 0xed0(%r14)
     262:      	movq	0x98(%rbx), %rax
     269:      	movq	%rax, 0xed8(%r14)
     270:      	movq	0x20(%rbx), %rax
     274:      	movq	%rax, 0xee0(%r14)
     27b:      	movq	0x50(%rbx), %rax
     27f:      	movq	%rax, 0xee8(%r14)
     286:      	movq	0x40(%rbx), %rax
     28a:      	movq	%rax, 0xef0(%r14)
     291:      	movq	0x30(%rbx), %rax
     295:      	movq	%rax, 0xef8(%r14)
     29c:      	movq	0x10(%rbx), %rax
     2a0:      	movq	%rax, 0xf00(%r14)
     2a7:      	movq	(%rbx), %rax
     2aa:      	movq	%rax, 0xf08(%r14)
     2b1:      	movb	$0x0, 0xf30(%r14)
     2b9:      	cmpl	$0x0, (%r13)
     2be:      	jne	0xad4 <finish_task_switch+0xad4>
     2c4:      	movl	$0x60, 0x20(%rsp)
     2cc:      	movbel	%r15d, 0x24(%rsp)
     2d3:      	movq	$0x0, 0x28(%rsp)
     2dc:      	movq	(%rip), %rdi            # 0x2e3 <finish_task_switch+0x2e3>
     2e3:      	leaq	0x20(%rsp), %rsi
     2e8:      	movl	$0x1, %eax
     2ed:      	callq	*%rax
     2ef:      	testq	%rax, %rax
     2f2:      	je	0x343 <finish_task_switch+0x343>
     2f4:      	movq	%r14, %rax
     2f7:      	addq	$0xed0, %rax            # imm = 0xED0
     2fd:      	movq	(%rax), %r12
     300:      	movl	(%r13), %eax
     304:      	testq	%r12, %r12
     307:      	je	0x407 <finish_task_switch+0x407>
     30d:      	testl	%eax, %eax
     30f:      	jne	0xcf1 <finish_task_switch+0xcf1>
     315:      	movq	%r12, %rax
     318:      	shrq	$0x38, %rax
     31c:      	je	0xd83 <finish_task_switch+0xd83>
     322:      	cmpl	$0x0, (%r13)
     327:      	jne	0x108f <finish_task_switch+0x108f>
     32d:      	movl	$0xb, 0xf28(%r14)
     338:      	movl	$0xfab, %r12d           # imm = 0xFAB
     33e:      	jmp	0x956 <finish_task_switch+0x956>
     343:      	movq	%r12, 0xc8(%rsp)
     34b:      	movl	%r15d, 0x8(%rsp)
     350:      	movq	(%rip), %rdi            # 0x357 <finish_task_switch+0x357>
     357:      	leaq	0x8(%rsp), %rsi
     35c:      	movl	$0x1, %eax
     361:      	callq	*%rax
     363:      	movq	%rax, %r14
     366:      	movl	$0x5, %eax
     36b:      	callq	*%rax
     36d:      	testq	%r14, %r14
     370:      	je	0x425 <finish_task_switch+0x425>
     376:      	movq	(%r14), %rcx
     379:      	movq	%rcx, %rsi
     37c:      	andq	$-0x20, %rsi
     380:      	movq	%rax, %rdx
     383:      	subq	%rsi, %rdx
     386:      	movl	%ecx, %esi
     388:      	andb	$0xf, %sil
     38c:      	movl	$0x5f5e100, %edi        # imm = 0x5F5E100
     391:      	shlxq	%rsi, %rdi, %rsi
     396:      	cmpq	%rsi, %rdx
     399:      	jae	0x429 <finish_task_switch+0x429>
     39f:      	cmpl	$0x0, (%r13)
     3a4:      	je	0x7ae <finish_task_switch+0x7ae>
     3aa:      	movabsq	$0xa74736166206f, %rax  # imm = 0xA74736166206F
     3b4:      	movq	%rax, 0x38(%rsp)
     3b9:      	movabsq	$0x6f74203a64657469, %rax # imm = 0x6F74203A64657469
     3c3:      	movq	%rax, 0x30(%rsp)
     3c8:      	movabsq	$0x6d696c20746e6576, %rax # imm = 0x6D696C20746E6576
     3d2:      	movq	%rax, 0x28(%rsp)
     3d7:      	movabsq	$0x6520642520444950, %rax # imm = 0x6520642520444950
     3e1:      	movq	%rax, 0x20(%rsp)
     3e6:      	leaq	0x20(%rsp), %rdi
     3eb:      	movl	$0x20, %eax
     3f0:      	movl	$0x6, %ecx
     3f5:      	movl	0x8(%rsp), %edx
     3f9:      	movl	$0x20, %esi
     3fe:      	xorl	%eax, %eax
     400:      	callq	*%rcx
     402:      	jmp	0x7ae <finish_task_switch+0x7ae>
     407:      	testl	%eax, %eax
     409:      	jne	0x1013 <finish_task_switch+0x1013>
     40f:      	movl	$0x1, 0xf28(%r14)
     41a:      	movl	$0xfad, %r12d           # imm = 0xFAD
     420:      	jmp	0x956 <finish_task_switch+0x956>
     425:      	xorl	%ebx, %ebx
     427:      	jmp	0x45a <finish_task_switch+0x45a>
     429:      	movl	%ecx, %ebx
     42b:      	andb	$0x10, %bl
     42e:      	movl	$0xffffffff, %edi       # imm = 0xFFFFFFFF
     433:      	addq	%rdi, %rsi
     436:      	addq	$0x2a05f201, %rsi       # imm = 0x2A05F201
     43d:      	cmpq	%rsi, %rdx
     440:      	jae	0x45a <finish_task_switch+0x45a>
     442:      	andl	$0xf, %ecx
     445:      	xorl	%edx, %edx
     447:      	testb	%bl, %bl
     449:      	sete	%dl
     44c:      	leal	0x4(,%rdx,4), %edx
     453:      	cmpl	%edx, %ecx
     455:      	adcb	$0x0, %cl
     458:      	jmp	0x45c <finish_task_switch+0x45c>
     45a:      	xorl	%ecx, %ecx
     45c:      	cmpl	$0x0, (%r13)
     461:      	movzbl	%cl, %r14d
     465:      	jne	0xfab <finish_task_switch+0xfab>
     46b:      	andq	$-0x20, %rax
     46f:      	movzbl	%bl, %ecx
     472:      	orq	%rax, %rcx
     475:      	orq	%rcx, %r14
     478:      	movq	%r14, 0xd0(%rsp)
     480:      	movq	(%rip), %rdi            # 0x487 <finish_task_switch+0x487>
     487:      	xorl	%eax, %eax
     489:      	leaq	0x8(%rsp), %rsi
     48e:      	leaq	0xd0(%rsp), %rdx
     496:      	movl	$0x2, %r8d
     49c:      	xorl	%ecx, %ecx
     49e:      	callq	*%r8
     4a1:      	testl	%eax, %eax
     4a3:      	je	0x4da <finish_task_switch+0x4da>
     4a5:      	cmpl	$0x0, (%r13)
     4aa:      	jne	0x10f2 <finish_task_switch+0x10f2>
     4b0:      	movl	$0x3d, 0x1c(%rsp)
     4b8:      	movq	(%rip), %rdi            # 0x4bf <finish_task_switch+0x4bf>
     4bf:      	leaq	0x1c(%rsp), %rsi
     4c4:      	movl	$0x1, %eax
     4c9:      	callq	*%rax
     4cb:      	testq	%rax, %rax
     4ce:      	je	0x545 <finish_task_switch+0x545>
     4d0:      	incq	(%rax)
     4d3:      	xorl	%ebp, %ebp
     4d5:      	jmp	0xa20 <finish_task_switch+0xa20>
     4da:      	movb	$0x1, 0xf(%rsp)
     4df:      	movq	(%rip), %rdi            # 0x4e6 <finish_task_switch+0x4e6>
     4e6:      	xorl	%eax, %eax
     4e8:      	leaq	0xc8(%rsp), %rsi
     4f0:      	leaq	0xf(%rsp), %rdx
     4f5:      	movl	$0x2, %r8d
     4fb:      	xorl	%ecx, %ecx
     4fd:      	callq	*%r8
     500:      	testl	%eax, %eax
     502:      	je	0x5cb <finish_task_switch+0x5cb>
     508:      	cmpl	$0x0, (%r13)
     50d:      	jne	0x12bf <finish_task_switch+0x12bf>
     513:      	movl	$0x3e, 0xd0(%rsp)
     51e:      	movq	(%rip), %rdi            # 0x525 <finish_task_switch+0x525>
     525:      	leaq	0xd0(%rsp), %rsi
     52d:      	movl	$0x1, %eax
     532:      	callq	*%rax
     534:      	testq	%rax, %rax
     537:      	je	0x63b <finish_task_switch+0x63b>
     53d:      	incq	(%rax)
     540:      	jmp	0x7ae <finish_task_switch+0x7ae>
     545:      	cmpl	$0x0, (%r13)
     54a:      	je	0x7ae <finish_task_switch+0x7ae>
     550:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     55a:      	movq	%rax, 0x46(%rsp)
     55f:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     569:      	movq	%rax, 0x40(%rsp)
     56e:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     578:      	movq	%rax, 0x38(%rsp)
     57d:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     587:      	movq	%rax, 0x30(%rsp)
     58c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     596:      	movq	%rax, 0x28(%rsp)
     59b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     5a5:      	movq	%rax, 0x20(%rsp)
     5aa:      	leaq	0x20(%rsp), %rdi
     5af:      	movl	$0x2e, %eax
     5b4:      	movl	$0x6, %ecx
     5b9:      	movl	0x1c(%rsp), %edx
     5bd:      	movl	$0x2e, %esi
     5c2:      	xorl	%eax, %eax
     5c4:      	callq	*%rcx
     5c6:      	jmp	0x7ae <finish_task_switch+0x7ae>
     5cb:      	movl	$0x1, 0x1c(%rsp)
     5d3:      	movb	$0x1, 0x8(%rsp)
     5d8:      	movq	(%rip), %rdi            # 0x5df <finish_task_switch+0x5df>
     5df:      	leaq	0x1c(%rsp), %rsi
     5e4:      	leaq	0x8(%rsp), %rdx
     5e9:      	movl	$0x1, %eax
     5ee:      	movl	$0x2, %r8d
     5f4:      	movl	$0x1, %ecx
     5f9:      	callq	*%r8
     5fc:      	testl	%eax, %eax
     5fe:      	js	0x6c6 <finish_task_switch+0x6c6>
     604:      	movl	$0x42, 0xd0(%rsp)
     60f:      	movq	(%rip), %rdi            # 0x616 <finish_task_switch+0x616>
     616:      	leaq	0xd0(%rsp), %rsi
     61e:      	movl	$0x1, %eax
     623:      	callq	*%rax
     625:      	testq	%rax, %rax
     628:      	je	0x722 <finish_task_switch+0x722>
     62e:      	incq	(%rax)
     631:      	movq	0x10(%rsp), %rdi
     636:      	jmp	0x732 <finish_task_switch+0x732>
     63b:      	cmpl	$0x0, (%r13)
     640:      	je	0x7ae <finish_task_switch+0x7ae>
     646:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     650:      	movq	%rax, 0x46(%rsp)
     655:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     65f:      	movq	%rax, 0x40(%rsp)
     664:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     66e:      	movq	%rax, 0x38(%rsp)
     673:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     67d:      	movq	%rax, 0x30(%rsp)
     682:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     68c:      	movq	%rax, 0x28(%rsp)
     691:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     69b:      	movq	%rax, 0x20(%rsp)
     6a0:      	leaq	0x20(%rsp), %rdi
     6a5:      	movl	$0x2e, %eax
     6aa:      	movl	$0x6, %ecx
     6af:      	movl	0xd0(%rsp), %edx
     6b6:      	movl	$0x2e, %esi
     6bb:      	xorl	%eax, %eax
     6bd:      	callq	*%rcx
     6bf:      	xorl	%ebp, %ebp
     6c1:      	jmp	0xa20 <finish_task_switch+0xa20>
     6c6:      	cmpl	$0x0, (%r13)
     6cb:      	je	0x779 <finish_task_switch+0x779>
     6d1:      	movabsq	$0xa64657469626968, %rax # imm = 0xA64657469626968
     6db:      	movq	%rax, 0x30(%rsp)
     6e0:      	movabsq	$0x6e69206425206570, %rax # imm = 0x6E69206425206570
     6ea:      	movq	%rax, 0x28(%rsp)
     6ef:      	movabsq	$0x797420746e657645, %rax # imm = 0x797420746E657645
     6f9:      	movq	%rax, 0x20(%rsp)
     6fe:      	movb	$0x0, 0x38(%rsp)
     703:      	leaq	0x20(%rsp), %rdi
     708:      	movl	$0x19, %eax
     70d:      	movl	$0x6, %ecx
     712:      	movl	$0x19, %esi
     717:      	movl	$0x1, %edx
     71c:      	xorl	%eax, %eax
     71e:      	callq	*%rcx
     720:      	jmp	0x779 <finish_task_switch+0x779>
     722:      	cmpl	$0x0, (%r13)
     727:      	movq	0x10(%rsp), %rdi
     72c:      	jne	0x14ef <finish_task_switch+0x14ef>
     732:      	movl	$0x1, 0xd0(%rsp)
     73d:      	movq	(%rip), %rsi            # 0x744 <finish_task_switch+0x744>
     744:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
     749:      	leaq	0xd0(%rsp), %rcx
     751:      	movl	$0x4, %edx
     756:      	movl	$0x19, %r9d
     75c:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     761:      	movl	$0x4, %r8d
     767:      	callq	*%r9
     76a:      	testl	%eax, %eax
     76c:      	jns	0x779 <finish_task_switch+0x779>
     76e:      	cmpl	$0x0, (%r13)
     773:      	jne	0x1460 <finish_task_switch+0x1460>
     779:      	movl	$0x3f, 0xd0(%rsp)
     784:      	movq	(%rip), %rdi            # 0x78b <finish_task_switch+0x78b>
     78b:      	leaq	0xd0(%rsp), %rsi
     793:      	movl	$0x1, %eax
     798:      	callq	*%rax
     79a:      	testq	%rax, %rax
     79d:      	jne	0x4d0 <finish_task_switch+0x4d0>
     7a3:      	cmpl	$0x0, (%r13)
     7a8:      	jne	0x13e2 <finish_task_switch+0x13e2>
     7ae:      	xorl	%ebp, %ebp
     7b0:      	jmp	0xa20 <finish_task_switch+0xa20>
     7b5:      	movabsq	$0xa3d3d3d3d2068, %rax  # imm = 0xA3D3D3D3D2068
     7bf:      	movq	%rax, 0x36(%rsp)
     7c4:      	movabsq	$0x206863746977735f, %rax # imm = 0x206863746977735F
     7ce:      	movq	%rax, 0x30(%rsp)
     7d3:      	movabsq	$0x6b7361745f687369, %rax # imm = 0x6B7361745F687369
     7dd:      	movq	%rax, 0x28(%rsp)
     7e2:      	movabsq	$0x6e6966203d3d3d3d, %rax # imm = 0x6E6966203D3D3D3D
     7ec:      	movq	%rax, 0x20(%rsp)
     7f1:      	leaq	0x20(%rsp), %rdi
     7f6:      	movl	$0x1e, %eax
     7fb:      	movl	$0x6, %ecx
     800:      	movl	$0x1e, %esi
     805:      	xorl	%eax, %eax
     807:      	callq	*%rcx
     809:      	movq	(%rip), %rax            # 0x810 <finish_task_switch+0x810>
     810:      	cmpl	$0x0, (%rax)
     813:      	je	0xa8 <finish_task_switch+0xa8>
     819:      	movabsq	$0xa64726f636572, %rax  # imm = 0xA64726F636572
     823:      	movq	%rax, 0x2e(%rsp)
     828:      	movabsq	$0x6572205550432067, %rax # imm = 0x6572205550432067
     832:      	movq	%rax, 0x28(%rsp)
     837:      	movabsq	$0x6e69747465736552, %rax # imm = 0x6E69747465736552
     841:      	movq	%rax, 0x20(%rsp)
     846:      	leaq	0x20(%rsp), %rdi
     84b:      	movl	$0x16, %eax
     850:      	movl	$0x6, %ecx
     855:      	movl	$0x16, %esi
     85a:      	xorl	%eax, %eax
     85c:      	callq	*%rcx
     85e:      	jmp	0xa8 <finish_task_switch+0xa8>
     863:      	movabsq	$0xa6425203d2064, %rax  # imm = 0xA6425203D2064
     86d:      	movq	%rax, 0x2e(%rsp)
     872:      	movabsq	$0x206469206b636174, %rax # imm = 0x206469206B636174
     87c:      	movq	%rax, 0x28(%rsp)
     881:      	movabsq	$0x73206c656e72656b, %rax # imm = 0x73206C656E72656B
     88b:      	movq	%rax, 0x20(%rsp)
     890:      	leaq	0x20(%rsp), %rdi
     895:      	movl	$0x16, %eax
     89a:      	movl	$0x6, %ecx
     89f:      	movl	0x2bc(%r14), %edx
     8a6:      	movl	$0x16, %esi
     8ab:      	xorl	%eax, %eax
     8ad:      	callq	*%rcx
     8af:      	cmpq	$0x2b, 0xa0(%rbx)
     8b7:      	je	0x23f <finish_task_switch+0x23f>
     8bd:      	movl	$0x23, %eax
     8c2:      	callq	*%rax
     8c4:      	movq	(%rip), %rcx            # 0x8cb <finish_task_switch+0x8cb>
     8cb:      	movl	(%rcx), %edx
     8cd:      	addq	%rax, %rdx
     8d0:      	leaq	0x20(%rsp), %rdi
     8d5:      	movl	$0x8, %eax
     8da:      	movl	$0x71, %ecx
     8df:      	movl	$0x8, %esi
     8e4:      	callq	*%rcx
     8e6:      	testq	%rax, %rax
     8e9:      	jne	0x91a <finish_task_switch+0x91a>
     8eb:      	movq	(%rip), %rax            # 0x8f2 <finish_task_switch+0x8f2>
     8f2:      	movl	(%rax), %edx
     8f4:      	addq	0x20(%rsp), %rdx
     8f9:      	je	0x91a <finish_task_switch+0x91a>
     8fb:      	leaq	0x20(%rsp), %rdi
     900:      	movl	$0xa8, %eax
     905:      	movl	$0x71, %ecx
     90a:      	movl	$0xa8, %esi
     90f:      	callq	*%rcx
     911:      	testq	%rax, %rax
     914:      	je	0xa34 <finish_task_switch+0xa34>
     91a:      	movl	$0x52, 0xc8(%rsp)
     925:      	movq	(%rip), %rdi            # 0x92c <finish_task_switch+0x92c>
     92c:      	leaq	0xc8(%rsp), %rsi
     934:      	movl	$0x1, %eax
     939:      	callq	*%rax
     93b:      	testq	%rax, %rax
     93e:      	je	0x945 <finish_task_switch+0x945>
     940:      	incq	(%rax)
     943:      	jmp	0x950 <finish_task_switch+0x950>
     945:      	cmpl	$0x0, (%r13)
     94a:      	jne	0xbe0 <finish_task_switch+0xbe0>
     950:      	movl	$0xfa9, %r12d           # imm = 0xFA9
     956:      	xorl	%r15d, %r15d
     959:      	movl	%r12d, 0xf2c(%r14)
     960:      	movl	$0x0, 0x20(%rsp)
     968:      	movq	(%rip), %rdi            # 0x96f <finish_task_switch+0x96f>
     96f:      	leaq	0x20(%rsp), %rsi
     974:      	movl	$0x1, %eax
     979:      	callq	*%rax
     97b:      	testq	%rax, %rax
     97e:      	je	0x9c7 <finish_task_switch+0x9c7>
     980:      	movzbl	0x1384(%rax), %ecx
     987:      	movl	%r15d, %edx
     98a:      	cmpb	$0x1d, %cl
     98d:      	jb	0x9f3 <finish_task_switch+0x9f3>
     98f:      	movq	%rax, %rbx
     992:      	movl	$0x5, 0xf2c(%rax)
     99c:      	movl	$0x44, 0xd0(%rsp)
     9a7:      	movq	(%rip), %rdi            # 0x9ae <finish_task_switch+0x9ae>
     9ae:      	leaq	0xd0(%rsp), %rsi
     9b6:      	movl	$0x1, %eax
     9bb:      	callq	*%rax
     9bd:      	testq	%rax, %rax
     9c0:      	je	0x9d7 <finish_task_switch+0x9d7>
     9c2:      	incq	(%rax)
     9c5:      	jmp	0x9e2 <finish_task_switch+0x9e2>
     9c7:      	movq	(%rip), %rcx            # 0x9ce <finish_task_switch+0x9ce>
     9ce:      	xorl	%edx, %edx
     9d0:      	movl	$0xc, %eax
     9d5:      	jmp	0xa09 <finish_task_switch+0xa09>
     9d7:      	cmpl	$0x0, (%r13)
     9dc:      	jne	0xf2d <finish_task_switch+0xf2d>
     9e2:      	movq	%rbx, %rax
     9e5:      	movzbl	0x1384(%rbx), %ecx
     9ec:      	xorl	%edx, %edx
     9ee:      	movq	0x10(%rsp), %rbx
     9f3:      	incb	%cl
     9f5:      	movb	%cl, 0x1384(%rax)
     9fb:      	movl	%edx, %ecx
     9fd:      	movq	(%rip), %rsi            # 0xa04 <finish_task_switch+0xa04>
     a04:      	movl	$0xc, %eax
     a09:      	movq	(%rip), %rsi            # 0xa10 <finish_task_switch+0xa10>
     a10:      	movq	%rbx, %rdi
     a13:      	callq	*%rax
     a15:      	cmpl	$0x0, (%r13)
     a1a:      	jne	0xb5e <finish_task_switch+0xb5e>
     a20:      	movl	%ebp, %eax
     a22:      	addq	$0x108, %rsp            # imm = 0x108
     a29:      	popq	%rbx
     a2a:      	popq	%r12
     a2c:      	popq	%r13
     a2e:      	popq	%r14
     a30:      	popq	%r15
     a32:      	popq	%rbp
     a33:      	retq
     a34:      	cmpq	$0x2b, 0xc0(%rsp)
     a3d:      	jne	0xb53 <finish_task_switch+0xb53>
     a43:      	cmpq	$0x23, 0xa8(%rsp)
     a4c:      	je	0x249 <finish_task_switch+0x249>
     a52:      	movq	0xa0(%rsp), %rax
     a5a:      	movq	%rax, 0xed0(%r14)
     a61:      	movq	0xb8(%rsp), %rax
     a69:      	movq	%rax, 0xed8(%r14)
     a70:      	movq	0x40(%rsp), %rax
     a75:      	movq	%rax, 0xee0(%r14)
     a7c:      	movq	0x70(%rsp), %rax
     a81:      	movq	%rax, 0xee8(%r14)
     a88:      	movq	0x60(%rsp), %rax
     a8d:      	movq	%rax, 0xef0(%r14)
     a94:      	movq	0x50(%rsp), %rax
     a99:      	movq	%rax, 0xef8(%r14)
     aa0:      	movq	0x30(%rsp), %rax
     aa5:      	movq	%rax, 0xf00(%r14)
     aac:      	movq	0x20(%rsp), %rax
     ab1:      	movq	%rax, 0xf08(%r14)
     ab8:      	cmpq	$-0x1, 0x98(%rsp)
     ac1:      	setne	0xf30(%r14)
     ac9:      	cmpl	$0x0, (%r13)
     ace:      	je	0x2c4 <finish_task_switch+0x2c4>
     ad4:      	movabsq	$0xa786c6c25203a, %rax  # imm = 0xA786C6C25203A
     ade:      	movq	%rax, 0x3f(%rsp)
     ae3:      	movabsq	$0x3a706620786c6c25, %rax # imm = 0x3A706620786C6C25
     aed:      	movq	%rax, 0x38(%rsp)
     af2:      	movabsq	$0x203a707320786c6c, %rax # imm = 0x203A707320786C6C
     afc:      	movq	%rax, 0x30(%rsp)
     b01:      	movabsq	$0x25203a6370203a73, %rax # imm = 0x25203A6370203A73
     b0b:      	movq	%rax, 0x28(%rsp)
     b10:      	movabsq	$0x6765722064616552, %rax # imm = 0x6765722064616552
     b1a:      	movq	%rax, 0x20(%rsp)
     b1f:      	leaq	0x20(%rsp), %rdi
     b24:      	movl	$0x27, %eax
     b29:      	movl	$0x6, %r9d
     b2f:      	movq	0xed0(%r14), %rdx
     b36:      	movq	0xed8(%r14), %rcx
     b3d:      	movq	0xee0(%r14), %r8
     b44:      	movl	$0x27, %esi
     b49:      	xorl	%eax, %eax
     b4b:      	callq	*%r9
     b4e:      	jmp	0x2c4 <finish_task_switch+0x2c4>
     b53:      	xorl	%r15d, %r15d
     b56:      	xorl	%r12d, %r12d
     b59:      	jmp	0x959 <finish_task_switch+0x959>
     b5e:      	movabsq	$0x746e655f72656361, %rax # imm = 0x746E655F72656361
     b68:      	movq	%rax, 0x48(%rsp)
     b6d:      	movabsq	$0x72745f6576697461, %rax # imm = 0x72745F6576697461
     b77:      	movq	%rax, 0x40(%rsp)
     b7c:      	movabsq	$0x6e206e6920642520, %rax # imm = 0x6E206E6920642520
     b86:      	movq	%rax, 0x38(%rsp)
     b8b:      	movabsq	$0x726f662064656c69, %rax # imm = 0x726F662064656C69
     b95:      	movq	%rax, 0x30(%rsp)
     b9a:      	movabsq	$0x6166206c6c616320, %rax # imm = 0x6166206C6C616320
     ba4:      	movq	%rax, 0x28(%rsp)
     ba9:      	movabsq	$0x6c6961745f667062, %rax # imm = 0x6C6961745F667062
     bb3:      	movq	%rax, 0x20(%rsp)
     bb8:      	movl	$0xa7972, 0x50(%rsp)    # imm = 0xA7972
     bc0:      	leaq	0x20(%rsp), %rdi
     bc5:      	movl	$0x34, %eax
     bca:      	movl	$0x6, %ecx
     bcf:      	movl	$0x34, %esi
     bd4:      	movl	%r15d, %edx
     bd7:      	xorl	%eax, %eax
     bd9:      	callq	*%rcx
     bdb:      	jmp	0xa20 <finish_task_switch+0xa20>
     be0:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     bea:      	movq	%rax, 0xf6(%rsp)
     bf2:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     bfc:      	movq	%rax, 0xf0(%rsp)
     c04:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     c0e:      	movq	%rax, 0xe8(%rsp)
     c16:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     c20:      	movq	%rax, 0xe0(%rsp)
     c28:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     c32:      	movq	%rax, 0xd8(%rsp)
     c3a:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     c44:      	movq	%rax, 0xd0(%rsp)
     c4c:      	leaq	0xd0(%rsp), %rdi
     c54:      	movl	$0x2e, %eax
     c59:      	movl	$0x6, %ecx
     c5e:      	movl	0xc8(%rsp), %edx
     c65:      	movl	$0x2e, %esi
     c6a:      	xorl	%eax, %eax
     c6c:      	callq	*%rcx
     c6e:      	jmp	0x950 <finish_task_switch+0x950>
     c73:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     c7d:      	movq	%rax, 0x46(%rsp)
     c82:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     c8c:      	movq	%rax, 0x40(%rsp)
     c91:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     c9b:      	movq	%rax, 0x38(%rsp)
     ca0:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     caa:      	movq	%rax, 0x30(%rsp)
     caf:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     cb9:      	movq	%rax, 0x28(%rsp)
     cbe:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     cc8:      	movq	%rax, 0x20(%rsp)
     ccd:      	leaq	0x20(%rsp), %rdi
     cd2:      	movl	$0x2e, %eax
     cd7:      	movl	$0x6, %ecx
     cdc:      	movl	0xd0(%rsp), %edx
     ce3:      	movl	$0x2e, %esi
     ce8:      	xorl	%eax, %eax
     cea:      	callq	*%rcx
     cec:      	jmp	0x204 <finish_task_switch+0x204>
     cf1:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
     cfb:      	movq	%rax, 0x48(%rsp)
     d00:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
     d0a:      	movq	%rax, 0x40(%rsp)
     d0f:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
     d19:      	movq	%rax, 0x38(%rsp)
     d1e:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
     d28:      	movq	%rax, 0x30(%rsp)
     d2d:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
     d37:      	movq	%rax, 0x28(%rsp)
     d3c:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
     d46:      	movq	%rax, 0x20(%rsp)
     d4b:      	movb	$0x0, 0x50(%rsp)
     d50:      	leaq	0x20(%rsp), %rdi
     d55:      	movl	$0x31, %eax
     d5a:      	movl	$0x6, %ecx
     d5f:      	movl	0x2c0(%r14), %edx
     d66:      	movl	$0x31, %esi
     d6b:      	xorl	%eax, %eax
     d6d:      	callq	*%rcx
     d6f:      	movq	0xed0(%r14), %r12
     d76:      	movq	%r12, %rax
     d79:      	shrq	$0x38, %rax
     d7d:      	jne	0x322 <finish_task_switch+0x322>
     d83:      	cmpq	$0xfff, %r12            # imm = 0xFFF
     d8a:      	ja	0xdad <finish_task_switch+0xdad>
     d8c:      	cmpl	$0x0, (%r13)
     d91:      	jne	0x1153 <finish_task_switch+0x1153>
     d97:      	movl	$0x31, 0xf28(%r14)
     da2:      	movl	$0xfae, %r12d           # imm = 0xFAE
     da8:      	jmp	0x956 <finish_task_switch+0x956>
     dad:      	movl	(%r14), %eax
     db0:      	movl	$0x60, 0xd0(%rsp)
     dbb:      	movbel	%eax, 0xd4(%rsp)
     dc4:      	movbeq	%r12, 0xd8(%rsp)
     dce:      	movq	(%rip), %rdi            # 0xdd5 <finish_task_switch+0xdd5>
     dd5:      	leaq	0xd0(%rsp), %rsi
     ddd:      	movl	$0x1, %eax
     de2:      	callq	*%rax
     de4:      	testq	%rax, %rax
     de7:      	je	0xe8c <finish_task_switch+0xe8c>
     ded:      	movabsq	$0xffffffffffffff, %rcx # imm = 0xFFFFFFFFFFFFFF
     df7:      	movq	0x8(%rax), %r15
     dfb:      	andq	%r15, %rcx
     dfe:      	movq	%rcx, 0xf20(%r14)
     e05:      	movq	(%rax), %rax
     e08:      	movq	%rax, 0xf10(%r14)
     e0f:      	shrq	$0x38, %r15
     e13:      	movq	%r12, %rax
     e16:      	subq	%rcx, %rax
     e19:      	movq	%rax, 0xf18(%r14)
     e20:      	cmpl	$0x0, (%r13)
     e25:      	jne	0x11af <finish_task_switch+0x11af>
     e2b:      	xorl	%r12d, %r12d
     e2e:      	cmpl	$0x1, %r15d
     e32:      	jne	0xe82 <finish_task_switch+0xe82>
     e34:      	movq	0xf10(%r14), %rax
     e3b:      	movq	%rax, 0xd0(%rsp)
     e43:      	movq	0xf18(%r14), %rbx
     e4a:      	movq	(%rip), %rdi            # 0xe51 <finish_task_switch+0xe51>
     e51:      	leaq	0xd0(%rsp), %rsi
     e59:      	movl	$0x1, %eax
     e5e:      	callq	*%rax
     e60:      	movl	$0x1, %r15d
     e66:      	testq	%rax, %rax
     e69:      	je	0xe82 <finish_task_switch+0xe82>
     e6b:      	cmpq	%rbx, (%rax)
     e6e:      	ja	0xe76 <finish_task_switch+0xe76>
     e70:      	cmpq	%rbx, 0x8(%rax)
     e74:      	jae	0xead <finish_task_switch+0xead>
     e76:      	cmpq	%rbx, 0x10(%rax)
     e7a:      	ja	0xe82 <finish_task_switch+0xe82>
     e7c:      	cmpq	%rbx, 0x18(%rax)
     e80:      	jae	0xead <finish_task_switch+0xead>
     e82:      	movq	0x10(%rsp), %rbx
     e87:      	jmp	0x959 <finish_task_switch+0x959>
     e8c:      	cmpl	$0x0, (%r13)
     e91:      	jne	0x1354 <finish_task_switch+0x1354>
     e97:      	movl	$0xc, 0xf28(%r14)
     ea2:      	movl	$0xfac, %r12d           # imm = 0xFAC
     ea8:      	jmp	0x956 <finish_task_switch+0x956>
     ead:      	cmpl	$0x0, (%r13)
     eb2:      	jne	0x1573 <finish_task_switch+0x1573>
     eb8:      	movl	0x1380(%r14), %ecx
     ebf:      	movl	0x20(%rax), %edx
     ec2:      	btl	%edx, %ecx
     ec5:      	jae	0x15e6 <finish_task_switch+0x15e6>
     ecb:      	cmpl	$0x0, (%r13)
     ed0:      	movq	0x10(%rsp), %rbx
     ed5:      	je	0x959 <finish_task_switch+0x959>
     edb:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
     ee5:      	movq	%rax, 0x30(%rsp)
     eea:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
     ef4:      	movq	%rax, 0x28(%rsp)
     ef9:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
     f03:      	movq	%rax, 0x20(%rsp)
     f08:      	movl	$0xa656e, 0x37(%rsp)    # imm = 0xA656E
     f10:      	leaq	0x20(%rsp), %rdi
     f15:      	movl	$0x1b, %eax
     f1a:      	movl	$0x6, %ecx
     f1f:      	movl	$0x1b, %esi
     f24:      	xorl	%eax, %eax
     f26:      	callq	*%rcx
     f28:      	jmp	0x959 <finish_task_switch+0x959>
     f2d:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     f37:      	movq	%rax, 0x46(%rsp)
     f3c:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     f46:      	movq	%rax, 0x40(%rsp)
     f4b:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     f55:      	movq	%rax, 0x38(%rsp)
     f5a:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     f64:      	movq	%rax, 0x30(%rsp)
     f69:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     f73:      	movq	%rax, 0x28(%rsp)
     f78:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     f82:      	movq	%rax, 0x20(%rsp)
     f87:      	leaq	0x20(%rsp), %rdi
     f8c:      	movl	$0x2e, %eax
     f91:      	movl	$0x6, %ecx
     f96:      	movl	0xd0(%rsp), %edx
     f9d:      	movl	$0x2e, %esi
     fa2:      	xorl	%eax, %eax
     fa4:      	callq	*%rcx
     fa6:      	jmp	0x9e2 <finish_task_switch+0x9e2>
     fab:      	movabsq	$0xa64253d74706d, %rcx  # imm = 0xA64253D74706D
     fb5:      	movq	%rcx, 0x37(%rsp)
     fba:      	movabsq	$0x6d65747461202c64, %rcx # imm = 0x6D65747461202C64
     fc4:      	movq	%rcx, 0x30(%rsp)
     fc9:      	movabsq	$0x6e657320746e6576, %rcx # imm = 0x6E657320746E6576
     fd3:      	movq	%rcx, 0x28(%rsp)
     fd8:      	movabsq	$0x6520642520444950, %rcx # imm = 0x6520642520444950
     fe2:      	movq	%rcx, 0x20(%rsp)
     fe7:      	leaq	0x20(%rsp), %rdi
     fec:      	movl	$0x1f, %ecx
     ff1:      	movl	$0x6, %r8d
     ff7:      	movl	0x8(%rsp), %edx
     ffb:      	movl	$0x1f, %esi
    1000:      	movl	%r14d, %ecx
    1003:      	movq	%rax, %r12
    1006:      	xorl	%eax, %eax
    1008:      	callq	*%r8
    100b:      	movq	%r12, %rax
    100e:      	jmp	0x46b <finish_task_switch+0x46b>
    1013:      	movabsq	$0xa2930203d3d2043, %rax # imm = 0xA2930203D3D2043
    101d:      	movq	%rax, 0x48(%rsp)
    1022:      	movabsq	$0x5028206572756c69, %rax # imm = 0x5028206572756C69
    102c:      	movq	%rax, 0x40(%rsp)
    1031:      	movabsq	$0x616620646e69776e, %rax # imm = 0x616620646E69776E
    103b:      	movq	%rax, 0x38(%rsp)
    1040:      	movabsq	$0x75206f7420657564, %rax # imm = 0x75206F7420657564
    104a:      	movq	%rax, 0x30(%rsp)
    104f:      	movabsq	$0x20646e69776e7520, %rax # imm = 0x20646E69776E7520
    1059:      	movq	%rax, 0x28(%rsp)
    105e:      	movabsq	$0x676e6970706f7453, %rax # imm = 0x676E6970706F7453
    1068:      	movq	%rax, 0x20(%rsp)
    106d:      	movb	$0x0, 0x50(%rsp)
    1072:      	leaq	0x20(%rsp), %rdi
    1077:      	movl	$0x31, %eax
    107c:      	movl	$0x6, %ecx
    1081:      	movl	$0x31, %esi
    1086:      	xorl	%eax, %eax
    1088:      	callq	*%rcx
    108a:      	jmp	0x40f <finish_task_switch+0x40f>
    108f:      	movabsq	$0x7373657264646120, %rax # imm = 0x7373657264646120
    1099:      	movq	%rax, 0x38(%rsp)
    109e:      	movabsq	$0x6c656e72656b2061, %rax # imm = 0x6C656E72656B2061
    10a8:      	movq	%rax, 0x30(%rsp)
    10ad:      	movabsq	$0x20736920786c2520, %rax # imm = 0x20736920786C2520
    10b7:      	movq	%rax, 0x28(%rsp)
    10bc:      	movabsq	$0x65756c6176204350, %rax # imm = 0x65756C6176204350
    10c6:      	movq	%rax, 0x20(%rsp)
    10cb:      	movw	$0xa, 0x40(%rsp)
    10d2:      	leaq	0x20(%rsp), %rdi
    10d7:      	movl	$0x22, %eax
    10dc:      	movl	$0x6, %ecx
    10e1:      	movl	$0x22, %esi
    10e6:      	movq	%r12, %rdx
    10e9:      	xorl	%eax, %eax
    10eb:      	callq	*%rcx
    10ed:      	jmp	0x32d <finish_task_switch+0x32d>
    10f2:      	movabsq	$0xa6425203a6425, %rcx  # imm = 0xA6425203A6425
    10fc:      	movq	%rcx, 0x35(%rsp)
    1101:      	movabsq	$0x3a64252044495020, %rcx # imm = 0x3A64252044495020
    110b:      	movq	%rcx, 0x30(%rsp)
    1110:      	movabsq	$0x74726f706572206f, %rcx # imm = 0x74726F706572206F
    111a:      	movq	%rcx, 0x28(%rsp)
    111f:      	movabsq	$0x742064656c696146, %rcx # imm = 0x742064656C696146
    1129:      	movq	%rcx, 0x20(%rsp)
    112e:      	leaq	0x20(%rsp), %rdi
    1133:      	movl	$0x1d, %ecx
    1138:      	movl	$0x6, %r8d
    113e:      	movl	0x8(%rsp), %edx
    1142:      	movl	$0x1d, %esi
    1147:      	movl	%eax, %ecx
    1149:      	xorl	%eax, %eax
    114b:      	callq	*%r8
    114e:      	jmp	0x4b0 <finish_task_switch+0x4b0>
    1153:      	movabsq	$0xa676e69726f6e, %rax  # imm = 0xA676E69726F6E
    115d:      	movq	%rax, 0x36(%rsp)
    1162:      	movabsq	$0x6f6e6769202c786c, %rax # imm = 0x6F6E6769202C786C
    116c:      	movq	%rax, 0x30(%rsp)
    1171:      	movabsq	$0x252065756c617620, %rax # imm = 0x252065756C617620
    117b:      	movq	%rax, 0x28(%rsp)
    1180:      	movabsq	$0x6370206c6c616d73, %rax # imm = 0x6370206C6C616D73
    118a:      	movq	%rax, 0x20(%rsp)
    118f:      	leaq	0x20(%rsp), %rdi
    1194:      	movl	$0x1e, %eax
    1199:      	movl	$0x6, %ecx
    119e:      	movl	$0x1e, %esi
    11a3:      	movq	%r12, %rdx
    11a6:      	xorl	%eax, %eax
    11a8:      	callq	*%rcx
    11aa:      	jmp	0xd97 <finish_task_switch+0xd97>
    11af:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    11b9:      	movq	%rax, 0x48(%rsp)
    11be:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    11c8:      	movq	%rax, 0x40(%rsp)
    11cd:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    11d7:      	movq	%rax, 0x38(%rsp)
    11dc:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    11e6:      	movq	%rax, 0x30(%rsp)
    11eb:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    11f5:      	movq	%rax, 0x28(%rsp)
    11fa:      	movabsq	$0x6365732074786554, %rbx # imm = 0x6365732074786554
    1204:      	movq	%rbx, 0x20(%rsp)
    1209:      	movw	$0xa, 0x50(%rsp)
    1210:      	leaq	0x20(%rsp), %rdi
    1215:      	movl	$0x32, %eax
    121a:      	movl	$0x6, %r9d
    1220:      	movq	0xf10(%r14), %rcx
    1227:      	movl	$0x32, %esi
    122c:      	movq	%r12, %rdx
    122f:      	movl	%r15d, %r8d
    1232:      	xorl	%eax, %eax
    1234:      	callq	*%r9
    1237:      	cmpl	$0x0, (%r13)
    123c:      	je	0xe2b <finish_task_switch+0xe2b>
    1242:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    124c:      	movq	%rax, 0x47(%rsp)
    1251:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    125b:      	movq	%rax, 0x40(%rsp)
    1260:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    126a:      	movq	%rax, 0x38(%rsp)
    126f:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    1279:      	movq	%rax, 0x30(%rsp)
    127e:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    1288:      	movq	%rax, 0x28(%rsp)
    128d:      	movq	%rbx, 0x20(%rsp)
    1292:      	leaq	0x20(%rsp), %rdi
    1297:      	movl	$0x2f, %eax
    129c:      	movl	$0x6, %r8d
    12a2:      	movq	0xf18(%r14), %rcx
    12a9:      	movq	0xf20(%r14), %rdx
    12b0:      	movl	$0x2f, %esi
    12b5:      	xorl	%eax, %eax
    12b7:      	callq	*%r8
    12ba:      	jmp	0xe2b <finish_task_switch+0xe2b>
    12bf:      	movl	0xc8(%rsp), %ecx
    12c6:      	movabsq	$0xa6425203a6425, %rdx  # imm = 0xA6425203A6425
    12d0:      	movq	%rdx, 0x4d(%rsp)
    12d5:      	movabsq	$0x3a6425203a444954, %rdx # imm = 0x3A6425203A444954
    12df:      	movq	%rdx, 0x48(%rsp)
    12e4:      	movabsq	$0x2064252044495020, %rdx # imm = 0x2064252044495020
    12ee:      	movq	%rdx, 0x40(%rsp)
    12f3:      	movabsq	$0x687469772073746e, %rdx # imm = 0x687469772073746E
    12fd:      	movq	%rdx, 0x38(%rsp)
    1302:      	movabsq	$0x6576655f64697020, %rdx # imm = 0x6576655F64697020
    130c:      	movq	%rdx, 0x30(%rsp)
    1311:      	movabsq	$0x657461647075206f, %rdx # imm = 0x657461647075206F
    131b:      	movq	%rdx, 0x28(%rsp)
    1320:      	movabsq	$0x742064656c696146, %rdx # imm = 0x742064656C696146
    132a:      	movq	%rdx, 0x20(%rsp)
    132f:      	leaq	0x20(%rsp), %rdi
    1334:      	movl	$0x35, %edx
    1339:      	movl	$0x6, %r9d
    133f:      	movl	$0x35, %esi
    1344:      	movl	%r15d, %edx
    1347:      	movl	%eax, %r8d
    134a:      	xorl	%eax, %eax
    134c:      	callq	*%r9
    134f:      	jmp	0x513 <finish_task_switch+0x513>
    1354:      	movabsq	$0xa786c2578302043, %rax # imm = 0xA786C2578302043
    135e:      	movq	%rax, 0x50(%rsp)
    1363:      	movabsq	$0x5020726f6620676e, %rax # imm = 0x5020726F6620676E
    136d:      	movq	%rax, 0x48(%rsp)
    1372:      	movabsq	$0x697070616d207972, %rax # imm = 0x697070616D207972
    137c:      	movq	%rax, 0x40(%rsp)
    1381:      	movabsq	$0x6f6d656d206c6176, %rax # imm = 0x6F6D656D206C6176
    138b:      	movq	%rax, 0x38(%rsp)
    1390:      	movabsq	$0x7265746e69207075, %rax # imm = 0x7265746E69207075
    139a:      	movq	%rax, 0x30(%rsp)
    139f:      	movabsq	$0x206b6f6f6c206f74, %rax # imm = 0x206B6F6F6C206F74
    13a9:      	movq	%rax, 0x28(%rsp)
    13ae:      	movabsq	$0x206572756c696146, %rax # imm = 0x206572756C696146
    13b8:      	movq	%rax, 0x20(%rsp)
    13bd:      	movb	$0x0, 0x58(%rsp)
    13c2:      	leaq	0x20(%rsp), %rdi
    13c7:      	movl	$0x39, %eax
    13cc:      	movl	$0x6, %ecx
    13d1:      	movl	$0x39, %esi
    13d6:      	movq	%r12, %rdx
    13d9:      	xorl	%eax, %eax
    13db:      	callq	*%rcx
    13dd:      	jmp	0xe97 <finish_task_switch+0xe97>
    13e2:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    13ec:      	movq	%rax, 0x46(%rsp)
    13f1:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    13fb:      	movq	%rax, 0x40(%rsp)
    1400:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    140a:      	movq	%rax, 0x38(%rsp)
    140f:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1419:      	movq	%rax, 0x30(%rsp)
    141e:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1428:      	movq	%rax, 0x28(%rsp)
    142d:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1437:      	movq	%rax, 0x20(%rsp)
    143c:      	leaq	0x20(%rsp), %rdi
    1441:      	movl	$0x2e, %eax
    1446:      	movl	$0x6, %ecx
    144b:      	movl	0xd0(%rsp), %edx
    1452:      	movl	$0x2e, %esi
    1457:      	xorl	%eax, %eax
    1459:      	callq	*%rcx
    145b:      	jmp	0x7ae <finish_task_switch+0x7ae>
    1460:      	movabsq	$0xa642520726f72, %rcx  # imm = 0xA642520726F72
    146a:      	movq	%rcx, 0x4e(%rsp)
    146f:      	movabsq	$0x6f727265203a6425, %rcx # imm = 0x6F727265203A6425
    1479:      	movq	%rcx, 0x48(%rsp)
    147e:      	movabsq	$0x20746e6576652064, %rcx # imm = 0x20746E6576652064
    1488:      	movq	%rcx, 0x40(%rsp)
    148d:      	movabsq	$0x6e6573206f742064, %rcx # imm = 0x6E6573206F742064
    1497:      	movq	%rcx, 0x38(%rsp)
    149c:      	movabsq	$0x656c696166207265, %rcx # imm = 0x656C696166207265
    14a6:      	movq	%rcx, 0x30(%rsp)
    14ab:      	movabsq	$0x67676972745f646e, %rcx # imm = 0x67676972745F646E
    14b5:      	movq	%rcx, 0x28(%rsp)
    14ba:      	movabsq	$0x65735f746e657665, %rcx # imm = 0x65735F746E657665
    14c4:      	movq	%rcx, 0x20(%rsp)
    14c9:      	leaq	0x20(%rsp), %rdi
    14ce:      	movl	$0x36, %ecx
    14d3:      	movl	$0x6, %r8d
    14d9:      	movl	$0x36, %esi
    14de:      	movl	$0x1, %edx
    14e3:      	movl	%eax, %ecx
    14e5:      	xorl	%eax, %eax
    14e7:      	callq	*%r8
    14ea:      	jmp	0x779 <finish_task_switch+0x779>
    14ef:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    14f9:      	movq	%rax, 0x46(%rsp)
    14fe:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1508:      	movq	%rax, 0x40(%rsp)
    150d:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1517:      	movq	%rax, 0x38(%rsp)
    151c:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1526:      	movq	%rax, 0x30(%rsp)
    152b:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1535:      	movq	%rax, 0x28(%rsp)
    153a:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1544:      	movq	%rax, 0x20(%rsp)
    1549:      	movq	%rdi, %rbx
    154c:      	leaq	0x20(%rsp), %rdi
    1551:      	movl	$0x2e, %eax
    1556:      	movl	$0x6, %ecx
    155b:      	movl	0xd0(%rsp), %edx
    1562:      	movl	$0x2e, %esi
    1567:      	xorl	%eax, %eax
    1569:      	callq	*%rcx
    156b:      	movq	%rbx, %rdi
    156e:      	jmp	0x732 <finish_task_switch+0x732>
    1573:      	movabsq	$0xa642520686374, %rcx  # imm = 0xA642520686374
    157d:      	movq	%rcx, 0x36(%rsp)
    1582:      	movabsq	$0x6374616d20737465, %rcx # imm = 0x6374616D20737465
    158c:      	movq	%rcx, 0x30(%rsp)
    1591:      	movabsq	$0x7366666f5f726574, %rcx # imm = 0x7366666F5F726574
    159b:      	movq	%rcx, 0x28(%rsp)
    15a0:      	movabsq	$0x6572707265746e69, %rcx # imm = 0x6572707265746E69
    15aa:      	movq	%rcx, 0x20(%rsp)
    15af:      	leaq	0x20(%rsp), %rdi
    15b4:      	movl	$0x1e, %ecx
    15b9:      	movl	$0x6, %r8d
    15bf:      	movzwl	0x20(%rax), %edx
    15c3:      	movl	$0x1e, %esi
    15c8:      	movq	%rax, %rbx
    15cb:      	xorl	%eax, %eax
    15cd:      	callq	*%r8
    15d0:      	movq	%rbx, %rax
    15d3:      	movl	0x1380(%r14), %ecx
    15da:      	movl	0x20(%rax), %edx
    15dd:      	btl	%edx, %ecx
    15e0:      	jb	0xecb <finish_task_switch+0xecb>
    15e6:      	movq	%rax, %rbx
    15e9:      	movl	$0x0, 0xc8(%rsp)
    15f4:      	movq	(%rip), %rdi            # 0x15fb <finish_task_switch+0x15fb>
    15fb:      	leaq	0xc8(%rsp), %rsi
    1603:      	movl	$0x1, %eax
    1608:      	callq	*%rax
    160a:      	testq	%rax, %rax
    160d:      	je	0x1614 <finish_task_switch+0x1614>
    160f:      	incq	(%rax)
    1612:      	jmp	0x161b <finish_task_switch+0x161b>
    1614:      	cmpl	$0x0, (%r13)
    1619:      	jne	0x162a <finish_task_switch+0x162a>
    161b:      	movzwl	0x20(%rbx), %r15d
    1620:      	movq	0x10(%rsp), %rbx
    1625:      	jmp	0x959 <finish_task_switch+0x959>
    162a:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1634:      	movq	%rax, 0x46(%rsp)
    1639:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1643:      	movq	%rax, 0x40(%rsp)
    1648:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1652:      	movq	%rax, 0x38(%rsp)
    1657:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1661:      	movq	%rax, 0x30(%rsp)
    1666:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1670:      	movq	%rax, 0x28(%rsp)
    1675:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    167f:      	movq	%rax, 0x20(%rsp)
    1684:      	leaq	0x20(%rsp), %rdi
    1689:      	movl	$0x2e, %eax
    168e:      	movl	$0x6, %ecx
    1693:      	movl	0xc8(%rsp), %edx
    169a:      	movl	$0x2e, %esi
    169f:      	xorl	%eax, %eax
    16a1:      	callq	*%rcx
    16a3:      	jmp	0x161b <finish_task_switch+0x161b>
