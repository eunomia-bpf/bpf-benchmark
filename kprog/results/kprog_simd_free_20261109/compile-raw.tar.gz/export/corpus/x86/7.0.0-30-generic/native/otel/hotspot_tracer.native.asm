
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/otel/hotspot_tracer.native.o:	file format elf64-x86-64

Disassembly of section perf_event/unwind_hotspot:

0000000000000000 <perf_unwind_hotspot>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x138, %rsp            # imm = 0x138
      11:      	movq	%rdi, %rbx
      14:      	movl	$0x0, 0x40(%rsp)
      1c:      	movq	(%rip), %rdi            # 0x23 <perf_unwind_hotspot+0x23>
      23:      	leaq	0x40(%rsp), %rsi
      28:      	movl	$0x1, %eax
      2d:      	callq	*%rax
      2f:      	testq	%rax, %rax
      32:      	je	0x4a4 <perf_unwind_hotspot+0x4a4>
      38:      	movq	%rax, %r14
      3b:      	movl	(%rax), %eax
      3d:      	movl	%eax, 0x134(%rsp)
      44:      	movq	(%rip), %r12            # 0x4b <perf_unwind_hotspot+0x4b>
      4b:      	cmpl	$0x0, (%r12)
      50:      	jne	0x6f1 <perf_unwind_hotspot+0x6f1>
      56:      	movq	(%rip), %rdi            # 0x5d <perf_unwind_hotspot+0x5d>
      5d:      	leaq	0x134(%rsp), %rsi
      65:      	movl	$0x1, %eax
      6a:      	callq	*%rax
      6c:      	testq	%rax, %rax
      6f:      	je	0x159 <perf_unwind_hotspot+0x159>
      75:      	movq	%rax, %r15
      78:      	movl	$0x29, 0xc8(%rsp)
      83:      	movq	(%rip), %rdi            # 0x8a <perf_unwind_hotspot+0x8a>
      8a:      	leaq	0xc8(%rsp), %rsi
      92:      	movl	$0x1, %eax
      97:      	callq	*%rax
      99:      	testq	%rax, %rax
      9c:      	movq	%rbx, 0x128(%rsp)
      a4:      	je	0x1d0 <perf_unwind_hotspot+0x1d0>
      aa:      	incq	(%rax)
      ad:      	cmpl	$0x0, (%r12)
      b2:      	movq	0xed0(%r14), %r12
      b9:      	movq	0xed8(%r14), %r13
      c0:      	movq	0xee0(%r14), %rax
      c7:      	movq	%rax, 0x38(%rsp)
      cc:      	je	0x1f5 <perf_unwind_hotspot+0x1f5>
      d2:      	movabsq	$0x252074657366666f, %rax # imm = 0x252074657366666F
      dc:      	movq	%rax, 0x60(%rsp)
      e1:      	movabsq	$0x202c786c25207472, %rax # imm = 0x202C786C25207472
      eb:      	movq	%rax, 0x58(%rsp)
      f0:      	movabsq	$0x6174732065646f63, %rax # imm = 0x6174732065646F63
      fa:      	movq	%rax, 0x50(%rsp)
      ff:      	movabsq	$0x206e6920786c2520, %rax # imm = 0x206E6920786C2520
     109:      	movq	%rax, 0x48(%rsp)
     10e:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
     118:      	movq	%rax, 0x40(%rsp)
     11d:      	movl	$0xa786c, 0x68(%rsp)    # imm = 0xA786C
     125:      	leaq	0x40(%rsp), %rdi
     12a:      	movl	$0x2c, %eax
     12f:      	movl	$0x6, %r9d
     135:      	movq	0xf20(%r14), %rcx
     13c:      	movq	0xed0(%r14), %rdx
     143:      	movq	0xf18(%r14), %r8
     14a:      	movl	$0x2c, %esi
     14f:      	xorl	%eax, %eax
     151:      	callq	*%r9
     154:      	jmp	0x1f5 <perf_unwind_hotspot+0x1f5>
     159:      	xorl	%eax, %eax
     15b:      	cmpl	$0x0, (%r12)
     160:      	je	0x4a9 <perf_unwind_hotspot+0x4a9>
     166:      	movabsq	$0xa646970207369, %rax  # imm = 0xA646970207369
     170:      	movq	%rax, 0x5e(%rsp)
     175:      	movabsq	$0x7369687420726f66, %rax # imm = 0x7369687420726F66
     17f:      	movq	%rax, 0x58(%rsp)
     184:      	movabsq	$0x206f666e49636f72, %rax # imm = 0x206F666E49636F72
     18e:      	movq	%rax, 0x50(%rsp)
     193:      	movabsq	$0x50746f7073746f48, %rax # imm = 0x50746F7073746F48
     19d:      	movq	%rax, 0x48(%rsp)
     1a2:      	movabsq	$0x206f6e203a6d766a, %rax # imm = 0x206F6E203A6D766A
     1ac:      	movq	%rax, 0x40(%rsp)
     1b1:      	leaq	0x40(%rsp), %rdi
     1b6:      	movl	$0x26, %eax
     1bb:      	movl	$0x6, %ecx
     1c0:      	movl	$0x26, %esi
     1c5:      	xorl	%eax, %eax
     1c7:      	callq	*%rcx
     1c9:      	xorl	%eax, %eax
     1cb:      	jmp	0x4a9 <perf_unwind_hotspot+0x4a9>
     1d0:      	cmpl	$0x0, (%r12)
     1d5:      	jne	0x9c7 <perf_unwind_hotspot+0x9c7>
     1db:      	movq	0xed0(%r14), %r12
     1e2:      	movq	0xed8(%r14), %r13
     1e9:      	movq	0xee0(%r14), %rax
     1f0:      	movq	%rax, 0x38(%rsp)
     1f5:      	movzbl	0x20(%r15), %eax
     1fa:      	shrxq	%rax, 0xf18(%r14), %rbx
     203:      	movb	$0x38, %al
     205:      	bzhiq	%rax, 0xf10(%r14), %rbp
     20e:      	leaq	(%rbx,%rbp), %rdx
     212:      	movq	%rsp, %rdi
     215:      	movl	$0x1, %eax
     21a:      	movl	$0x70, %ecx
     21f:      	movl	$0x1, %esi
     224:      	callq	*%rcx
     226:      	testq	%rax, %rax
     229:      	je	0x270 <perf_unwind_hotspot+0x270>
     22b:      	movq	$0x0, 0xc8(%rsp)
     237:      	movq	(%rip), %rbx            # 0x23e <perf_unwind_hotspot+0x23e>
     23e:      	cmpl	$0x0, (%rbx)
     241:      	jne	0x880 <perf_unwind_hotspot+0x880>
     247:      	movl	$0x2b, (%rsp)
     24e:      	movq	(%rip), %rdi            # 0x255 <perf_unwind_hotspot+0x255>
     255:      	movq	%rsp, %rsi
     258:      	movl	$0x1, %eax
     25d:      	callq	*%rax
     25f:      	testq	%rax, %rax
     262:      	je	0x339 <perf_unwind_hotspot+0x339>
     268:      	incq	(%rax)
     26b:      	jmp	0x342 <perf_unwind_hotspot+0x342>
     270:      	movq	(%rip), %rax            # 0x277 <perf_unwind_hotspot+0x277>
     277:      	cmpl	$0x0, (%rax)
     27a:      	jne	0xa45 <perf_unwind_hotspot+0xa45>
     280:      	movzbl	(%rsp), %eax
     284:      	leal	0x1(%rax), %ecx
     287:      	cmpb	$0x2, %cl
     28a:      	jae	0xab2 <perf_unwind_hotspot+0xab2>
     290:      	testb	%al, %al
     292:      	jne	0x22b <perf_unwind_hotspot+0x22b>
     294:      	movzbl	0x20(%r15), %eax
     299:      	shlxq	%rax, %rbx, %rax
     29e:      	addq	0xf20(%r14), %rax
     2a5:      	movzbl	0x1b(%r15), %ebx
     2aa:      	addq	%rax, %rbx
     2ad:      	movq	(%rip), %rax            # 0x2b4 <perf_unwind_hotspot+0x2b4>
     2b4:      	cmpl	$0x0, (%rax)
     2b7:      	jne	0x1270 <perf_unwind_hotspot+0x1270>
     2bd:      	movq	%rbx, 0xc8(%rsp)
     2c5:      	testq	%rbx, %rbx
     2c8:      	je	0x237 <perf_unwind_hotspot+0x237>
     2ce:      	movq	%r14, %rdx
     2d1:      	addq	$0xf80, %rdx            # imm = 0xF80
     2d8:      	movl	$0x200, %eax            # imm = 0x200
     2dd:      	movl	$0x70, %ecx
     2e2:      	movq	%rdx, %rbx
     2e5:      	movq	0xc8(%rsp), %rdx
     2ed:      	movq	%rbx, %rdi
     2f0:      	movl	$0x200, %esi            # imm = 0x200
     2f5:      	callq	*%rcx
     2f7:      	testq	%rax, %rax
     2fa:      	je	0x4bb <perf_unwind_hotspot+0x4bb>
     300:      	movq	(%rip), %rbx            # 0x307 <perf_unwind_hotspot+0x307>
     307:      	cmpl	$0x0, (%rbx)
     30a:      	jne	0x14ef <perf_unwind_hotspot+0x14ef>
     310:      	movl	$0x2c, (%rsp)
     317:      	movq	(%rip), %rdi            # 0x31e <perf_unwind_hotspot+0x31e>
     31e:      	movq	%rsp, %rsi
     321:      	movl	$0x1, %eax
     326:      	callq	*%rax
     328:      	testq	%rax, %rax
     32b:      	je	0x6de <perf_unwind_hotspot+0x6de>
     331:      	incq	(%rax)
     334:      	jmp	0x6e7 <perf_unwind_hotspot+0x6e7>
     339:      	cmpl	$0x0, (%rbx)
     33c:      	jne	0xdc6 <perf_unwind_hotspot+0xdc6>
     342:      	movl	$0x3e8, %ebx            # imm = 0x3E8
     347:      	xorl	%r12d, %r12d
     34a:      	movl	%ebx, %ebp
     34c:      	movq	0x128(%rsp), %r15
     354:      	movl	%ebp, 0xf2c(%r14)
     35b:      	movl	$0x0, 0x40(%rsp)
     363:      	movq	(%rip), %rdi            # 0x36a <perf_unwind_hotspot+0x36a>
     36a:      	leaq	0x40(%rsp), %rsi
     36f:      	movl	$0x1, %eax
     374:      	callq	*%rax
     376:      	testq	%rax, %rax
     379:      	je	0x3c9 <perf_unwind_hotspot+0x3c9>
     37b:      	movzbl	0x1384(%rax), %ecx
     382:      	movl	%r12d, %edx
     385:      	cmpb	$0x1d, %cl
     388:      	movq	(%rip), %r14            # 0x38f <perf_unwind_hotspot+0x38f>
     38f:      	jb	0x3f6 <perf_unwind_hotspot+0x3f6>
     391:      	movq	%rax, %rbx
     394:      	movl	$0x5, 0xf2c(%rax)
     39e:      	movl	$0x44, 0xc8(%rsp)
     3a9:      	movq	(%rip), %rdi            # 0x3b0 <perf_unwind_hotspot+0x3b0>
     3b0:      	leaq	0xc8(%rsp), %rsi
     3b8:      	movl	$0x1, %eax
     3bd:      	callq	*%rax
     3bf:      	testq	%rax, %rax
     3c2:      	je	0x3e0 <perf_unwind_hotspot+0x3e0>
     3c4:      	incq	(%rax)
     3c7:      	jmp	0x3ea <perf_unwind_hotspot+0x3ea>
     3c9:      	movq	(%rip), %rcx            # 0x3d0 <perf_unwind_hotspot+0x3d0>
     3d0:      	xorl	%edx, %edx
     3d2:      	movl	$0xc, %eax
     3d7:      	movq	(%rip), %r14            # 0x3de <perf_unwind_hotspot+0x3de>
     3de:      	jmp	0x40c <perf_unwind_hotspot+0x40c>
     3e0:      	cmpl	$0x0, (%r14)
     3e4:      	jne	0x11f2 <perf_unwind_hotspot+0x11f2>
     3ea:      	movq	%rbx, %rax
     3ed:      	movzbl	0x1384(%rbx), %ecx
     3f4:      	xorl	%edx, %edx
     3f6:      	incb	%cl
     3f8:      	movb	%cl, 0x1384(%rax)
     3fe:      	movl	%edx, %ecx
     400:      	movq	(%rip), %rsi            # 0x407 <perf_unwind_hotspot+0x407>
     407:      	movl	$0xc, %eax
     40c:      	movq	(%rip), %rsi            # 0x413 <perf_unwind_hotspot+0x413>
     413:      	movq	%r15, %rdi
     416:      	callq	*%rax
     418:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
     41d:      	cmpl	$0x0, (%r14)
     421:      	je	0x4a9 <perf_unwind_hotspot+0x4a9>
     427:      	movabsq	$0x6c69616620296425, %rax # imm = 0x6C69616620296425
     431:      	movq	%rax, 0x68(%rsp)
     436:      	movabsq	$0x28207265646e6977, %rax # imm = 0x28207265646E6977
     440:      	movq	%rax, 0x60(%rsp)
     445:      	movabsq	$0x6e7520656d617266, %rax # imm = 0x6E7520656D617266
     44f:      	movq	%rax, 0x58(%rsp)
     454:      	movabsq	$0x207478656e20726f, %rax # imm = 0x207478656E20726F
     45e:      	movq	%rax, 0x50(%rsp)
     463:      	movabsq	$0x66206c6c6163206c, %rax # imm = 0x66206C6C6163206C
     46d:      	movq	%rax, 0x48(%rsp)
     472:      	movabsq	$0x696174203a6d766a, %rax # imm = 0x696174203A6D766A
     47c:      	movq	%rax, 0x40(%rsp)
     481:      	movl	$0xa6465, 0x70(%rsp)    # imm = 0xA6465
     489:      	leaq	0x40(%rsp), %rdi
     48e:      	movl	$0x34, %eax
     493:      	movl	$0x6, %ecx
     498:      	movl	$0x34, %esi
     49d:      	movl	%r12d, %edx
     4a0:      	xorl	%eax, %eax
     4a2:      	callq	*%rcx
     4a4:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
     4a9:      	addq	$0x138, %rsp            # imm = 0x138
     4b0:      	popq	%rbx
     4b1:      	popq	%r12
     4b3:      	popq	%r13
     4b5:      	popq	%r14
     4b7:      	popq	%r15
     4b9:      	popq	%rbp
     4ba:      	retq
     4bb:      	movq	%rbx, 0x120(%rsp)
     4c3:      	movzwl	0x10(%r15), %eax
     4c8:      	movl	$0x1, %ebx
     4cd:      	cmpq	$0x1f8, %rax            # imm = 0x1F8
     4d3:      	ja	0x347 <perf_unwind_hotspot+0x347>
     4d9:      	movzwl	0x12(%r15), %ecx
     4de:      	cmpq	$0x1fc, %rcx            # imm = 0x1FC
     4e5:      	ja	0x347 <perf_unwind_hotspot+0x347>
     4eb:      	movzwl	0x14(%r15), %edx
     4f0:      	cmpq	$0x1f8, %rdx            # imm = 0x1F8
     4f7:      	ja	0x347 <perf_unwind_hotspot+0x347>
     4fd:      	movzbl	0x17(%r15), %esi
     502:      	movq	0x120(%rsp), %r8
     50a:      	movq	(%r8,%rsi), %rsi
     50e:      	movq	%rsi, 0xd0(%rsp)
     516:      	movzbl	0x18(%r15), %esi
     51b:      	movq	(%r8,%rsi), %rsi
     51f:      	movq	%rsi, 0xd8(%rsp)
     527:      	movzbl	0x1a(%r15), %esi
     52c:      	movl	(%r8,%rsi), %esi
     530:      	shll	$0x3, %esi
     533:      	movl	%esi, 0xf0(%rsp)
     53a:      	movzbl	0x19(%r15), %esi
     53f:      	movzwl	(%r8,%rsi), %esi
     544:      	movw	%si, 0xf8(%rsp)
     54c:      	movl	(%r8,%rcx), %ecx
     550:      	movl	%ecx, 0xf4(%rsp)
     557:      	movl	(%r8,%rdx), %ecx
     55b:      	movl	%ecx, 0xec(%rsp)
     562:      	movq	(%r8,%rax), %rax
     566:      	movq	%rax, 0xe0(%rsp)
     56e:      	leaq	0xe8(%rsp), %rdi
     576:      	movzbl	0x16(%r15), %eax
     57b:      	movq	(%r8,%rax), %rdx
     57f:      	movl	$0x4, %eax
     584:      	movl	$0x70, %ecx
     589:      	movl	$0x4, %esi
     58e:      	callq	*%rcx
     590:      	testq	%rax, %rax
     593:      	jne	0x300 <perf_unwind_hotspot+0x300>
     599:      	cmpb	$0x0, 0x21(%r15)
     59e:      	je	0x5cc <perf_unwind_hotspot+0x5cc>
     5a0:      	movq	0xc8(%rsp), %rax
     5a8:      	movl	0xd0(%rsp), %ecx
     5af:      	addq	%rax, %rcx
     5b2:      	movq	%rcx, 0xd0(%rsp)
     5ba:      	movl	0xd8(%rsp), %ecx
     5c1:      	addq	%rax, %rcx
     5c4:      	movq	%rcx, 0xd8(%rsp)
     5cc:      	movq	(%rip), %rax            # 0x5d3 <perf_unwind_hotspot+0x5d3>
     5d3:      	cmpl	$0x0, (%rax)
     5d6:      	jne	0x1c74 <perf_unwind_hotspot+0x1c74>
     5dc:      	movq	0xc8(%rsp), %rsi
     5e4:      	movq	0xd0(%rsp), %rax
     5ec:      	movl	0xe8(%rsp), %ebp
     5f3:      	movl	%r12d, %ebx
     5f6:      	subl	%eax, %ebx
     5f8:      	cmpl	$0x6974616d, %ebp       # imm = 0x6974616D
     5fe:      	movq	%rsi, 0xb8(%rsp)
     606:      	jg	0x749 <perf_unwind_hotspot+0x749>
     60c:      	cmpl	$0x62617476, %ebp       # imm = 0x62617476
     612:      	je	0x984 <perf_unwind_hotspot+0x984>
     618:      	cmpl	$0x65746e49, %ebp       # imm = 0x65746E49
     61e:      	jne	0x8de <perf_unwind_hotspot+0x8de>
     624:      	movq	%rbx, 0xa8(%rsp)
     62c:      	movq	0x38(%rsp), %rcx
     631:      	cmpq	%r13, %rcx
     634:      	jb	0xe40 <perf_unwind_hotspot+0xe40>
     63a:      	leaq	0x1000(%r13), %rax
     641:      	cmpq	%rax, %rcx
     644:      	jae	0xe40 <perf_unwind_hotspot+0xe40>
     64a:      	leaq	-0x50(%rcx), %rdx
     64e:      	leaq	0x40(%rsp), %rdi
     653:      	movl	$0x60, %eax
     658:      	movl	$0x70, %ecx
     65d:      	movl	$0x60, %esi
     662:      	callq	*%rcx
     664:      	testq	%rax, %rax
     667:      	je	0x1350 <perf_unwind_hotspot+0x1350>
     66d:      	movq	(%rip), %rax            # 0x674 <perf_unwind_hotspot+0x674>
     674:      	cmpl	$0x0, (%rax)
     677:      	je	0xe50 <perf_unwind_hotspot+0xe50>
     67d:      	movabsq	$0xa656d61726620, %rax  # imm = 0xA656D61726620
     687:      	movq	%rax, 0x1f(%rsp)
     68c:      	movabsq	$0x2072657465727072, %rax # imm = 0x2072657465727072
     696:      	movq	%rax, 0x18(%rsp)
     69b:      	movabsq	$0x65746e6920646165, %rax # imm = 0x65746E6920646165
     6a5:      	movq	%rax, 0x10(%rsp)
     6aa:      	movabsq	$0x72206f742064656c, %rax # imm = 0x72206F742064656C
     6b4:      	movq	%rax, 0x8(%rsp)
     6b9:      	movabsq	$0x696166203a6d766a, %rax # imm = 0x696166203A6D766A
     6c3:      	movq	%rax, (%rsp)
     6c7:      	movq	%rsp, %rdi
     6ca:      	movl	$0x27, %eax
     6cf:      	movl	$0x6, %ecx
     6d4:      	movl	$0x27, %esi
     6d9:      	jmp	0x2425 <perf_unwind_hotspot+0x2425>
     6de:      	cmpl	$0x0, (%rbx)
     6e1:      	jne	0x1917 <perf_unwind_hotspot+0x1917>
     6e7:      	movl	$0x3eb, %ebx            # imm = 0x3EB
     6ec:      	jmp	0x347 <perf_unwind_hotspot+0x347>
     6f1:      	movabsq	$0x3d3d3d3d20642520, %rax # imm = 0x3D3D3D3D20642520
     6fb:      	movq	%rax, 0x50(%rsp)
     700:      	movabsq	$0x646e69776e75203a, %rax # imm = 0x646E69776E75203A
     70a:      	movq	%rax, 0x48(%rsp)
     70f:      	movabsq	$0x6d766a203d3d3d3d, %rax # imm = 0x6D766A203D3D3D3D
     719:      	movq	%rax, 0x40(%rsp)
     71e:      	movw	$0xa, 0x58(%rsp)
     725:      	leaq	0x40(%rsp), %rdi
     72a:      	movl	$0x1a, %eax
     72f:      	movl	$0x6, %ecx
     734:      	movl	0x2c0(%r14), %edx
     73b:      	movl	$0x1a, %esi
     740:      	xorl	%eax, %eax
     742:      	callq	*%rcx
     744:      	jmp	0x56 <perf_unwind_hotspot+0x56>
     749:      	cmpl	$0x74656d6e, %ebp       # imm = 0x74656D6E
     74f:      	je	0x75d <perf_unwind_hotspot+0x75d>
     751:      	cmpl	$0x6974616e, %ebp       # imm = 0x6974616E
     757:      	jne	0x8de <perf_unwind_hotspot+0x8de>
     75d:      	movq	%rbx, 0xa8(%rsp)
     765:      	movzbl	0xf30(%r14), %ebx
     76d:      	movl	0xf4(%rsp), %ebp
     774:      	movq	0xe0(%rsp), %rcx
     77c:      	movl	%ecx, %edx
     77e:      	addq	%rsi, %rdx
     781:      	cmpb	$0x0, 0x21(%r15)
     786:      	cmoveq	%rcx, %rdx
     78a:      	cmpq	%rdx, %r12
     78d:      	jne	0x7da <perf_unwind_hotspot+0x7da>
     78f:      	movl	0xec(%rsp), %eax
     796:      	addq	%r13, %rax
     799:      	movq	%rsp, %rdi
     79c:      	movl	$0x8, %ecx
     7a1:      	movl	$0x70, %r8d
     7a7:      	movl	0xec(%rsp), %edx
     7ae:      	addq	%r13, %rdx
     7b1:      	movl	$0x8, %esi
     7b6:      	callq	*%r8
     7b9:      	testq	%rax, %rax
     7bc:      	je	0x1170 <perf_unwind_hotspot+0x1170>
     7c2:      	movq	(%rip), %rax            # 0x7c9 <perf_unwind_hotspot+0x7c9>
     7c9:      	cmpl	$0x0, (%rax)
     7cc:      	jne	0x21e7 <perf_unwind_hotspot+0x21e7>
     7d2:      	movq	0xd0(%rsp), %rax
     7da:      	movzwl	0xf8(%rsp), %ecx
     7e2:      	addq	%rax, %rcx
     7e5:      	cmpq	%rcx, %r12
     7e8:      	jae	0x912 <perf_unwind_hotspot+0x912>
     7ee:      	addq	$-0x4, %rcx
     7f2:      	movq	(%rip), %rax            # 0x7f9 <perf_unwind_hotspot+0x7f9>
     7f9:      	movl	(%rax), %eax
     7fb:      	cmpq	%rcx, %r12
     7fe:      	jae	0xe82 <perf_unwind_hotspot+0xe82>
     804:      	movb	$0x3, %cl
     806:      	movl	%ecx, 0xb0(%rsp)
     80d:      	testl	%eax, %eax
     80f:      	je	0x9aa <perf_unwind_hotspot+0x9aa>
     815:      	movabsq	$0x2963702820656d61, %rax # imm = 0x2963702820656D61
     81f:      	movq	%rax, 0x60(%rsp)
     824:      	movabsq	$0x7266206574656c70, %rax # imm = 0x7266206574656C70
     82e:      	movq	%rax, 0x58(%rsp)
     833:      	movabsq	$0x6d6f636e6920676e, %rax # imm = 0x6D6F636E6920676E
     83d:      	movq	%rax, 0x50(%rsp)
     842:      	movabsq	$0x69646e69776e7520, %rax # imm = 0x69646E69776E7520
     84c:      	movq	%rax, 0x48(%rsp)
     851:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
     85b:      	movq	%rax, 0x40(%rsp)
     860:      	movw	$0xa, 0x68(%rsp)
     867:      	leaq	0x40(%rsp), %rdi
     86c:      	movl	$0x2a, %eax
     871:      	movl	$0x6, %ecx
     876:      	movl	$0x2a, %esi
     87b:      	jmp	0x21de <perf_unwind_hotspot+0x21de>
     880:      	movabsq	$0xa637020726f6620, %rax # imm = 0xA637020726F6620
     88a:      	movq	%rax, 0x58(%rsp)
     88f:      	movabsq	$0x6465686374616d20, %rax # imm = 0x6465686374616D20
     899:      	movq	%rax, 0x50(%rsp)
     89e:      	movabsq	$0x626f6c6265646f63, %rax # imm = 0x626F6C6265646F63
     8a8:      	movq	%rax, 0x48(%rsp)
     8ad:      	movabsq	$0x206f6e203a6d766a, %rax # imm = 0x206F6E203A6D766A
     8b7:      	movq	%rax, 0x40(%rsp)
     8bc:      	movb	$0x0, 0x60(%rsp)
     8c1:      	leaq	0x40(%rsp), %rdi
     8c6:      	movl	$0x21, %eax
     8cb:      	movl	$0x6, %ecx
     8d0:      	movl	$0x21, %esi
     8d5:      	xorl	%eax, %eax
     8d7:      	callq	*%rcx
     8d9:      	jmp	0x247 <perf_unwind_hotspot+0x247>
     8de:      	movq	(%rip), %rax            # 0x8e5 <perf_unwind_hotspot+0x8e5>
     8e5:      	cmpl	$0x0, (%rax)
     8e8:      	jne	0x213c <perf_unwind_hotspot+0x213c>
     8ee:      	movl	0xf0(%rsp), %eax
     8f5:      	movl	$0x0, 0xb0(%rsp)
     900:      	movq	0x38(%rsp), %rcx
     905:      	testl	%eax, %eax
     907:      	jne	0xeb1 <perf_unwind_hotspot+0xeb1>
     90d:      	jmp	0xe9e <perf_unwind_hotspot+0xe9e>
     912:      	testb	%bl, %bl
     914:      	jne	0x938 <perf_unwind_hotspot+0x938>
     916:      	leaq	-0x1(%r12), %rdx
     91b:      	movq	%rsp, %rdi
     91e:      	movl	$0xe, %eax
     923:      	movl	$0x70, %ecx
     928:      	movl	$0xe, %esi
     92d:      	callq	*%rcx
     92f:      	testq	%rax, %rax
     932:      	je	0x144b <perf_unwind_hotspot+0x144b>
     938:      	movq	0x38(%rsp), %rax
     93d:      	movq	%rax, %rdx
     940:      	movl	0xf0(%rsp), %ebx
     947:      	leaq	(%rbx,%r13), %rcx
     94b:      	addq	$0x30, %rcx
     94f:      	subq	%r13, %rdx
     952:      	jb	0x1071 <perf_unwind_hotspot+0x1071>
     958:      	cmpq	%rcx, %rax
     95b:      	jae	0x1071 <perf_unwind_hotspot+0x1071>
     961:      	movb	$0x3, %al
     963:      	movl	%eax, 0xb0(%rsp)
     96a:      	movq	(%rip), %rax            # 0x971 <perf_unwind_hotspot+0x971>
     971:      	cmpl	$0x0, (%rax)
     974:      	jne	0x257d <perf_unwind_hotspot+0x257d>
     97a:      	movq	0x38(%rsp), %rcx
     97f:      	jmp	0xe96 <perf_unwind_hotspot+0xe96>
     984:      	movq	%rbx, 0xa8(%rsp)
     98c:      	movb	$0x1, %al
     98e:      	movl	%eax, 0xb0(%rsp)
     995:      	movl	$0x62617476, %ebp       # imm = 0x62617476
     99a:      	movq	(%rip), %rax            # 0x9a1 <perf_unwind_hotspot+0x9a1>
     9a1:      	cmpl	$0x0, (%rax)
     9a4:      	jne	0x219d <perf_unwind_hotspot+0x219d>
     9aa:      	movl	$0x8, 0xf0(%rsp)
     9b5:      	movl	$0x8, %eax
     9ba:      	movq	0xa8(%rsp), %rbx
     9c2:      	jmp	0xeb1 <perf_unwind_hotspot+0xeb1>
     9c7:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     9d1:      	movq	%rax, 0x66(%rsp)
     9d6:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     9e0:      	movq	%rax, 0x60(%rsp)
     9e5:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     9ef:      	movq	%rax, 0x58(%rsp)
     9f4:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     9fe:      	movq	%rax, 0x50(%rsp)
     a03:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     a0d:      	movq	%rax, 0x48(%rsp)
     a12:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     a1c:      	movq	%rax, 0x40(%rsp)
     a21:      	leaq	0x40(%rsp), %rdi
     a26:      	movl	$0x2e, %eax
     a2b:      	movl	$0x6, %ecx
     a30:      	movl	0xc8(%rsp), %edx
     a37:      	movl	$0x2e, %esi
     a3c:      	xorl	%eax, %eax
     a3e:      	callq	*%rcx
     a40:      	jmp	0xad <perf_unwind_hotspot+0xad>
     a45:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
     a4f:      	movq	%rax, 0x55(%rsp)
     a54:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
     a5e:      	movq	%rax, 0x50(%rsp)
     a63:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
     a6d:      	movq	%rax, 0x48(%rsp)
     a72:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
     a7c:      	movq	%rax, 0x40(%rsp)
     a81:      	leaq	0x40(%rsp), %rdi
     a86:      	movl	$0x1d, %eax
     a8b:      	movl	$0x6, %r8d
     a91:      	movzbl	(%rsp), %ecx
     a95:      	movl	$0x1d, %esi
     a9a:      	movq	%rbx, %rdx
     a9d:      	xorl	%eax, %eax
     a9f:      	callq	*%r8
     aa2:      	movzbl	(%rsp), %eax
     aa6:      	leal	0x1(%rax), %ecx
     aa9:      	cmpb	$0x2, %cl
     aac:      	jb	0x290 <perf_unwind_hotspot+0x290>
     ab2:      	movzbl	%al, %eax
     ab5:      	subq	%rax, %rbx
     ab8:      	leaq	(%rbx,%rbp), %rdx
     abc:      	movq	%rsp, %rdi
     abf:      	movl	$0x1, %eax
     ac4:      	movl	$0x70, %ecx
     ac9:      	movl	$0x1, %esi
     ace:      	callq	*%rcx
     ad0:      	testq	%rax, %rax
     ad3:      	jne	0x22b <perf_unwind_hotspot+0x22b>
     ad9:      	movq	(%rip), %rax            # 0xae0 <perf_unwind_hotspot+0xae0>
     ae0:      	cmpl	$0x0, (%rax)
     ae3:      	jne	0x1373 <perf_unwind_hotspot+0x1373>
     ae9:      	movzbl	(%rsp), %eax
     aed:      	leal	0x1(%rax), %ecx
     af0:      	cmpb	$0x2, %cl
     af3:      	jb	0x290 <perf_unwind_hotspot+0x290>
     af9:      	movzbl	%al, %eax
     afc:      	subq	%rax, %rbx
     aff:      	leaq	(%rbx,%rbp), %rdx
     b03:      	movq	%rsp, %rdi
     b06:      	movl	$0x1, %eax
     b0b:      	movl	$0x70, %ecx
     b10:      	movl	$0x1, %esi
     b15:      	callq	*%rcx
     b17:      	testq	%rax, %rax
     b1a:      	jne	0x22b <perf_unwind_hotspot+0x22b>
     b20:      	movq	(%rip), %rax            # 0xb27 <perf_unwind_hotspot+0xb27>
     b27:      	cmpl	$0x0, (%rax)
     b2a:      	jne	0x1991 <perf_unwind_hotspot+0x1991>
     b30:      	movzbl	(%rsp), %eax
     b34:      	leal	0x1(%rax), %ecx
     b37:      	cmpb	$0x2, %cl
     b3a:      	jb	0x290 <perf_unwind_hotspot+0x290>
     b40:      	movzbl	%al, %eax
     b43:      	subq	%rax, %rbx
     b46:      	leaq	(%rbx,%rbp), %rdx
     b4a:      	movq	%rsp, %rdi
     b4d:      	movl	$0x1, %eax
     b52:      	movl	$0x70, %ecx
     b57:      	movl	$0x1, %esi
     b5c:      	callq	*%rcx
     b5e:      	testq	%rax, %rax
     b61:      	jne	0x22b <perf_unwind_hotspot+0x22b>
     b67:      	movq	(%rip), %rax            # 0xb6e <perf_unwind_hotspot+0xb6e>
     b6e:      	cmpl	$0x0, (%rax)
     b71:      	jne	0x1b83 <perf_unwind_hotspot+0x1b83>
     b77:      	movzbl	(%rsp), %eax
     b7b:      	leal	0x1(%rax), %ecx
     b7e:      	cmpb	$0x2, %cl
     b81:      	jb	0x290 <perf_unwind_hotspot+0x290>
     b87:      	movzbl	%al, %eax
     b8a:      	subq	%rax, %rbx
     b8d:      	leaq	(%rbx,%rbp), %rdx
     b91:      	movq	%rsp, %rdi
     b94:      	movl	$0x1, %eax
     b99:      	movl	$0x70, %ecx
     b9e:      	movl	$0x1, %esi
     ba3:      	callq	*%rcx
     ba5:      	testq	%rax, %rax
     ba8:      	jne	0x22b <perf_unwind_hotspot+0x22b>
     bae:      	movq	(%rip), %rax            # 0xbb5 <perf_unwind_hotspot+0xbb5>
     bb5:      	cmpl	$0x0, (%rax)
     bb8:      	jne	0x1d78 <perf_unwind_hotspot+0x1d78>
     bbe:      	movzbl	(%rsp), %eax
     bc2:      	leal	0x1(%rax), %ecx
     bc5:      	cmpb	$0x2, %cl
     bc8:      	jb	0x290 <perf_unwind_hotspot+0x290>
     bce:      	movzbl	%al, %eax
     bd1:      	subq	%rax, %rbx
     bd4:      	leaq	(%rbx,%rbp), %rdx
     bd8:      	movq	%rsp, %rdi
     bdb:      	movl	$0x1, %eax
     be0:      	movl	$0x70, %ecx
     be5:      	movl	$0x1, %esi
     bea:      	callq	*%rcx
     bec:      	testq	%rax, %rax
     bef:      	jne	0x22b <perf_unwind_hotspot+0x22b>
     bf5:      	movq	(%rip), %rax            # 0xbfc <perf_unwind_hotspot+0xbfc>
     bfc:      	cmpl	$0x0, (%rax)
     bff:      	jne	0x24a5 <perf_unwind_hotspot+0x24a5>
     c05:      	movzbl	(%rsp), %eax
     c09:      	leal	0x1(%rax), %ecx
     c0c:      	cmpb	$0x2, %cl
     c0f:      	jb	0x290 <perf_unwind_hotspot+0x290>
     c15:      	movzbl	%al, %eax
     c18:      	subq	%rax, %rbx
     c1b:      	leaq	(%rbx,%rbp), %rdx
     c1f:      	movq	%rsp, %rdi
     c22:      	movl	$0x1, %eax
     c27:      	movl	$0x70, %ecx
     c2c:      	movl	$0x1, %esi
     c31:      	callq	*%rcx
     c33:      	testq	%rax, %rax
     c36:      	jne	0x22b <perf_unwind_hotspot+0x22b>
     c3c:      	movq	(%rip), %rax            # 0xc43 <perf_unwind_hotspot+0xc43>
     c43:      	cmpl	$0x0, (%rax)
     c46:      	jne	0x2aa8 <perf_unwind_hotspot+0x2aa8>
     c4c:      	movzbl	(%rsp), %eax
     c50:      	leal	0x1(%rax), %ecx
     c53:      	cmpb	$0x2, %cl
     c56:      	jb	0x290 <perf_unwind_hotspot+0x290>
     c5c:      	movzbl	%al, %eax
     c5f:      	subq	%rax, %rbx
     c62:      	leaq	(%rbx,%rbp), %rdx
     c66:      	movq	%rsp, %rdi
     c69:      	movl	$0x1, %eax
     c6e:      	movl	$0x70, %ecx
     c73:      	movl	$0x1, %esi
     c78:      	callq	*%rcx
     c7a:      	testq	%rax, %rax
     c7d:      	jne	0x22b <perf_unwind_hotspot+0x22b>
     c83:      	movq	(%rip), %rax            # 0xc8a <perf_unwind_hotspot+0xc8a>
     c8a:      	cmpl	$0x0, (%rax)
     c8d:      	jne	0x3bea <perf_unwind_hotspot+0x3bea>
     c93:      	movzbl	(%rsp), %eax
     c97:      	leal	0x1(%rax), %ecx
     c9a:      	cmpb	$0x2, %cl
     c9d:      	jb	0x290 <perf_unwind_hotspot+0x290>
     ca3:      	movzbl	%al, %eax
     ca6:      	subq	%rax, %rbx
     ca9:      	leaq	(%rbx,%rbp), %rdx
     cad:      	movq	%rsp, %rdi
     cb0:      	movl	$0x1, %eax
     cb5:      	movl	$0x70, %ecx
     cba:      	movl	$0x1, %esi
     cbf:      	callq	*%rcx
     cc1:      	testq	%rax, %rax
     cc4:      	jne	0x22b <perf_unwind_hotspot+0x22b>
     cca:      	movq	(%rip), %rax            # 0xcd1 <perf_unwind_hotspot+0xcd1>
     cd1:      	cmpl	$0x0, (%rax)
     cd4:      	jne	0x3fea <perf_unwind_hotspot+0x3fea>
     cda:      	movzbl	(%rsp), %eax
     cde:      	leal	0x1(%rax), %ecx
     ce1:      	cmpb	$0x2, %cl
     ce4:      	jb	0x290 <perf_unwind_hotspot+0x290>
     cea:      	movzbl	%al, %eax
     ced:      	subq	%rax, %rbx
     cf0:      	leaq	(%rbx,%rbp), %rdx
     cf4:      	movq	%rsp, %rdi
     cf7:      	movl	$0x1, %eax
     cfc:      	movl	$0x70, %ecx
     d01:      	movl	$0x1, %esi
     d06:      	callq	*%rcx
     d08:      	testq	%rax, %rax
     d0b:      	jne	0x22b <perf_unwind_hotspot+0x22b>
     d11:      	movq	(%rip), %rax            # 0xd18 <perf_unwind_hotspot+0xd18>
     d18:      	cmpl	$0x0, (%rax)
     d1b:      	jne	0x4381 <perf_unwind_hotspot+0x4381>
     d21:      	movzbl	(%rsp), %eax
     d25:      	leal	0x1(%rax), %ecx
     d28:      	cmpb	$0x2, %cl
     d2b:      	jb	0x290 <perf_unwind_hotspot+0x290>
     d31:      	movzbl	%al, %eax
     d34:      	subq	%rax, %rbx
     d37:      	leaq	(%rbx,%rbp), %rdx
     d3b:      	movq	%rsp, %rdi
     d3e:      	movl	$0x1, %eax
     d43:      	movl	$0x70, %ecx
     d48:      	movl	$0x1, %esi
     d4d:      	callq	*%rcx
     d4f:      	testq	%rax, %rax
     d52:      	jne	0x22b <perf_unwind_hotspot+0x22b>
     d58:      	movq	(%rip), %rax            # 0xd5f <perf_unwind_hotspot+0xd5f>
     d5f:      	cmpl	$0x0, (%rax)
     d62:      	jne	0x4465 <perf_unwind_hotspot+0x4465>
     d68:      	movzbl	(%rsp), %eax
     d6c:      	leal	0x1(%rax), %ecx
     d6f:      	cmpb	$0x2, %cl
     d72:      	jb	0x290 <perf_unwind_hotspot+0x290>
     d78:      	movzbl	%al, %eax
     d7b:      	subq	%rax, %rbx
     d7e:      	addq	%rbx, %rbp
     d81:      	movq	%rsp, %rdi
     d84:      	movl	$0x1, %eax
     d89:      	movl	$0x70, %ecx
     d8e:      	movl	$0x1, %esi
     d93:      	movq	%rbp, %rdx
     d96:      	callq	*%rcx
     d98:      	testq	%rax, %rax
     d9b:      	jne	0x22b <perf_unwind_hotspot+0x22b>
     da1:      	movq	(%rip), %rax            # 0xda8 <perf_unwind_hotspot+0xda8>
     da8:      	cmpl	$0x0, (%rax)
     dab:      	jne	0x47a7 <perf_unwind_hotspot+0x47a7>
     db1:      	movzbl	(%rsp), %eax
     db5:      	leal	0x1(%rax), %ecx
     db8:      	cmpb	$0x1, %cl
     dbb:      	ja	0x22b <perf_unwind_hotspot+0x22b>
     dc1:      	jmp	0x290 <perf_unwind_hotspot+0x290>
     dc6:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     dd0:      	movq	%rax, 0x66(%rsp)
     dd5:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     ddf:      	movq	%rax, 0x60(%rsp)
     de4:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     dee:      	movq	%rax, 0x58(%rsp)
     df3:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     dfd:      	movq	%rax, 0x50(%rsp)
     e02:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     e0c:      	movq	%rax, 0x48(%rsp)
     e11:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     e1b:      	movq	%rax, 0x40(%rsp)
     e20:      	leaq	0x40(%rsp), %rdi
     e25:      	movl	$0x2e, %eax
     e2a:      	movl	$0x6, %ecx
     e2f:      	movl	(%rsp), %edx
     e32:      	movl	$0x2e, %esi
     e37:      	xorl	%eax, %eax
     e39:      	callq	*%rcx
     e3b:      	jmp	0x342 <perf_unwind_hotspot+0x342>
     e40:      	movq	(%rip), %rax            # 0xe47 <perf_unwind_hotspot+0xe47>
     e47:      	cmpl	$0x0, (%rax)
     e4a:      	jne	0x23ba <perf_unwind_hotspot+0x23ba>
     e50:      	movl	$0x2d, 0x114(%rsp)
     e5b:      	movq	(%rip), %rdi            # 0xe62 <perf_unwind_hotspot+0xe62>
     e62:      	leaq	0x114(%rsp), %rsi
     e6a:      	movl	$0x1, %eax
     e6f:      	callq	*%rax
     e71:      	testq	%rax, %rax
     e74:      	je	0x11b7 <perf_unwind_hotspot+0x11b7>
     e7a:      	incq	(%rax)
     e7d:      	jmp	0x11c7 <perf_unwind_hotspot+0x11c7>
     e82:      	movb	$0x3, %cl
     e84:      	movl	%ecx, 0xb0(%rsp)
     e8b:      	testl	%eax, %eax
     e8d:      	jne	0x242e <perf_unwind_hotspot+0x242e>
     e93:      	movq	%r13, %rcx
     e96:      	movq	0xa8(%rsp), %rbx
     e9e:      	movl	$0x10, 0xf0(%rsp)
     ea9:      	movl	$0x10, %eax
     eae:      	movq	%rcx, %r13
     eb1:      	movl	%eax, %eax
     eb3:      	addq	%rax, %r13
     eb6:      	leaq	-0x10(%r13), %rdx
     eba:      	movq	%rsp, %rdi
     ebd:      	movl	$0x10, %eax
     ec2:      	movl	$0x70, %ecx
     ec7:      	movl	$0x10, %esi
     ecc:      	callq	*%rcx
     ece:      	movq	0x8(%rsp), %r12
     ed3:      	cmpl	$0x10, 0xf0(%rsp)
     edb:      	movq	0x38(%rsp), %r8
     ee0:      	jb	0xef6 <perf_unwind_hotspot+0xef6>
     ee2:      	movq	(%rip), %rax            # 0xee9 <perf_unwind_hotspot+0xee9>
     ee9:      	cmpl	$0x0, (%rax)
     eec:      	jne	0x1ec1 <perf_unwind_hotspot+0x1ec1>
     ef2:      	movq	(%rsp), %r8
     ef6:      	movl	0x2c0(%r14), %eax
     efd:      	cmpq	$0x7f, %rax
     f01:      	jb	0xf3c <perf_unwind_hotspot+0xf3c>
     f03:      	movq	(%rip), %rbx            # 0xf0a <perf_unwind_hotspot+0xf0a>
     f0a:      	cmpl	$0x0, (%rbx)
     f0d:      	jne	0x1dea <perf_unwind_hotspot+0x1dea>
     f13:      	movl	$0x2, (%rsp)
     f1a:      	movq	(%rip), %rdi            # 0xf21 <perf_unwind_hotspot+0xf21>
     f21:      	movq	%rsp, %rsi
     f24:      	movl	$0x1, %eax
     f29:      	callq	*%rax
     f2b:      	testq	%rax, %rax
     f2e:      	je	0xff9 <perf_unwind_hotspot+0xff9>
     f34:      	incq	(%rax)
     f37:      	jmp	0x1002 <perf_unwind_hotspot+0x1002>
     f3c:      	movzbl	0xf30(%r14), %ecx
     f44:      	movzbl	0xb0(%rsp), %edx
     f4c:      	shlq	$0x3c, %rdx
     f50:      	shlq	$0x20, %rbx
     f54:      	movl	%ebp, %esi
     f56:      	orq	%rbx, %rsi
     f59:      	orq	%rdx, %rsi
     f5c:      	leal	0x1(%rax), %edx
     f5f:      	movl	%edx, 0x2c0(%r14)
     f66:      	leaq	(%rax,%rax,2), %rax
     f6a:      	movq	0xb8(%rsp), %rdx
     f72:      	movq	%rdx, 0x2d0(%r14,%rax,8)
     f7a:      	movq	%rsi, 0x2d8(%r14,%rax,8)
     f82:      	movb	$0x5, 0x2e0(%r14,%rax,8)
     f8b:      	movb	%cl, 0x2e1(%r14,%rax,8)
     f93:      	movl	$0x0, 0x2e2(%r14,%rax,8)
     f9f:      	movw	$0x0, 0x2e6(%r14,%rax,8)
     faa:      	movq	(%rip), %rbx            # 0xfb1 <perf_unwind_hotspot+0xfb1>
     fb1:      	cmpl	$0x0, (%rbx)
     fb4:      	jne	0x1e52 <perf_unwind_hotspot+0x1e52>
     fba:      	movq	%r12, 0xed0(%r14)
     fc1:      	movq	%r13, 0xed8(%r14)
     fc8:      	movq	%r8, 0xee0(%r14)
     fcf:      	movb	$0x1, 0xf30(%r14)
     fd7:      	movl	$0x2a, (%rsp)
     fde:      	movq	(%rip), %rdi            # 0xfe5 <perf_unwind_hotspot+0xfe5>
     fe5:      	movq	%rsp, %rsi
     fe8:      	movl	$0x1, %eax
     fed:      	callq	*%rax
     fef:      	testq	%rax, %rax
     ff2:      	je	0x100c <perf_unwind_hotspot+0x100c>
     ff4:      	incq	(%rax)
     ff7:      	jmp	0x1015 <perf_unwind_hotspot+0x1015>
     ff9:      	cmpl	$0x0, (%rbx)
     ffc:      	jne	0x225e <perf_unwind_hotspot+0x225e>
    1002:      	movl	$0x2, %ebx
    1007:      	jmp	0x347 <perf_unwind_hotspot+0x347>
    100c:      	cmpl	$0x0, (%rbx)
    100f:      	jne	0x22dd <perf_unwind_hotspot+0x22dd>
    1015:      	movq	0xed0(%r14), %rbx
    101c:      	movq	(%rip), %rax            # 0x1023 <perf_unwind_hotspot+0x1023>
    1023:      	movl	(%rax), %eax
    1025:      	testq	%rbx, %rbx
    1028:      	je	0x9ceb <perf_unwind_hotspot+0x9ceb>
    102e:      	movabsq	$0xffffffffffffff, %r12 # imm = 0xFFFFFFFFFFFFFF
    1038:      	testl	%eax, %eax
    103a:      	jne	0x1f0b <perf_unwind_hotspot+0x1f0b>
    1040:      	cmpq	%r12, %rbx
    1043:      	jbe	0x1f99 <perf_unwind_hotspot+0x1f99>
    1049:      	movq	(%rip), %rax            # 0x1050 <perf_unwind_hotspot+0x1050>
    1050:      	cmpl	$0x0, (%rax)
    1053:      	jne	0x2357 <perf_unwind_hotspot+0x2357>
    1059:      	movl	$0xb, 0xf28(%r14)
    1064:      	movl	$0xfab, %ebp            # imm = 0xFAB
    1069:      	xorl	%r12d, %r12d
    106c:      	jmp	0x34c <perf_unwind_hotspot+0x34c>
    1071:      	movq	%rcx, 0x118(%rsp)
    1079:      	leaq	(%rbx,%r13), %rdx
    107d:      	addq	$-0x8, %rdx
    1081:      	leaq	0x40(%rsp), %rdi
    1086:      	movl	$0x30, %eax
    108b:      	movl	$0x70, %ecx
    1090:      	movl	$0x30, %esi
    1095:      	callq	*%rcx
    1097:      	movq	(%rip), %rax            # 0x109e <perf_unwind_hotspot+0x109e>
    109e:      	cmpl	$0x0, (%rax)
    10a1:      	jne	0x2517 <perf_unwind_hotspot+0x2517>
    10a7:      	movl	(%r14), %eax
    10aa:      	movl	$0x60, (%rsp)
    10b1:      	movbel	%eax, 0x4(%rsp)
    10b7:      	addq	%rbx, %r13
    10ba:      	movq	0x40(%rsp), %rax
    10bf:      	movbeq	%rax, 0x8(%rsp)
    10c6:      	movabsq	$-0x100000000000000, %rbx # imm = 0xFF00000000000000
    10d0:      	movq	(%rip), %rdi            # 0x10d7 <perf_unwind_hotspot+0x10d7>
    10d7:      	movq	%rsp, %rsi
    10da:      	movl	$0x1, %eax
    10df:      	callq	*%rax
    10e1:      	testq	%rax, %rax
    10e4:      	je	0x1102 <perf_unwind_hotspot+0x1102>
    10e6:      	movq	0x8(%rax), %rax
    10ea:      	andq	%rbx, %rax
    10ed:      	xorl	%edx, %edx
    10ef:      	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
    10f9:      	cmpq	%rcx, %rax
    10fc:      	je	0x168d <perf_unwind_hotspot+0x168d>
    1102:      	movq	(%rip), %rax            # 0x1109 <perf_unwind_hotspot+0x1109>
    1109:      	cmpl	$0x0, (%rax)
    110c:      	jne	0x2741 <perf_unwind_hotspot+0x2741>
    1112:      	movl	(%r14), %eax
    1115:      	movl	$0x60, (%rsp)
    111c:      	movbel	%eax, 0x4(%rsp)
    1122:      	movq	0x48(%rsp), %rax
    1127:      	movbeq	%rax, 0x8(%rsp)
    112e:      	movq	(%rip), %rdi            # 0x1135 <perf_unwind_hotspot+0x1135>
    1135:      	movq	%rsp, %rsi
    1138:      	movl	$0x1, %eax
    113d:      	callq	*%rax
    113f:      	testq	%rax, %rax
    1142:      	je	0x12e2 <perf_unwind_hotspot+0x12e2>
    1148:      	movq	0x8(%rax), %rax
    114c:      	andq	%rbx, %rax
    114f:      	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
    1159:      	cmpq	%rcx, %rax
    115c:      	jne	0x12e2 <perf_unwind_hotspot+0x12e2>
    1162:      	addq	$0x8, %r13
    1166:      	movl	$0x1, %edx
    116b:      	jmp	0x168d <perf_unwind_hotspot+0x168d>
    1170:      	movq	(%rsp), %rax
    1174:      	movq	0xd0(%rsp), %rcx
    117c:      	cmpq	%rcx, %rax
    117f:      	jb	0x7c2 <perf_unwind_hotspot+0x7c2>
    1185:      	cmpq	0xd8(%rsp), %rax
    118d:      	jae	0x7c2 <perf_unwind_hotspot+0x7c2>
    1193:      	movq	(%rip), %rdx            # 0x119a <perf_unwind_hotspot+0x119a>
    119a:      	cmpl	$0x0, (%rdx)
    119d:      	jne	0x2928 <perf_unwind_hotspot+0x2928>
    11a3:      	movl	%eax, %edx
    11a5:      	subl	%ecx, %edx
    11a7:      	movq	%rdx, 0xa8(%rsp)
    11af:      	movq	%rax, %r12
    11b2:      	jmp	0x7d2 <perf_unwind_hotspot+0x7d2>
    11b7:      	movq	(%rip), %rax            # 0x11be <perf_unwind_hotspot+0x11be>
    11be:      	cmpl	$0x0, (%rax)
    11c1:      	jne	0x266a <perf_unwind_hotspot+0x266a>
    11c7:      	movl	$0x3e9, %ebx            # imm = 0x3E9
    11cc:      	movl	$0x0, 0xc0(%rsp)
    11d7:      	movl	$0x65746e49, %ebp       # imm = 0x65746E49
    11dc:      	movb	$0x2, %al
    11de:      	movl	%eax, 0xb0(%rsp)
    11e5:      	testl	%ebx, %ebx
    11e7:      	jne	0x347 <perf_unwind_hotspot+0x347>
    11ed:      	jmp	0x16cb <perf_unwind_hotspot+0x16cb>
    11f2:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    11fc:      	movq	%rax, 0x66(%rsp)
    1201:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    120b:      	movq	%rax, 0x60(%rsp)
    1210:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    121a:      	movq	%rax, 0x58(%rsp)
    121f:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1229:      	movq	%rax, 0x50(%rsp)
    122e:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1238:      	movq	%rax, 0x48(%rsp)
    123d:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1247:      	movq	%rax, 0x40(%rsp)
    124c:      	leaq	0x40(%rsp), %rdi
    1251:      	movl	$0x2e, %eax
    1256:      	movl	$0x6, %ecx
    125b:      	movl	0xc8(%rsp), %edx
    1262:      	movl	$0x2e, %esi
    1267:      	xorl	%eax, %eax
    1269:      	callq	*%rcx
    126b:      	jmp	0x3ea <perf_unwind_hotspot+0x3ea>
    1270:      	movabsq	$0xa786c2520626f6c, %rax # imm = 0xA786C2520626F6C
    127a:      	movq	%rax, 0x58(%rsp)
    127f:      	movabsq	$0x6265646f63206f74, %rax # imm = 0x6265646F63206F74
    1289:      	movq	%rax, 0x50(%rsp)
    128e:      	movabsq	$0x2064657070616d20, %rax # imm = 0x2064657070616D20
    1298:      	movq	%rax, 0x48(%rsp)
    129d:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    12a7:      	movq	%rax, 0x40(%rsp)
    12ac:      	movb	$0x0, 0x60(%rsp)
    12b1:      	leaq	0x40(%rsp), %rdi
    12b6:      	movl	$0x21, %eax
    12bb:      	movl	$0x6, %ecx
    12c0:      	movl	$0x21, %esi
    12c5:      	movq	%rbx, %rdx
    12c8:      	xorl	%eax, %eax
    12ca:      	callq	*%rcx
    12cc:      	movq	%rbx, 0xc8(%rsp)
    12d4:      	testq	%rbx, %rbx
    12d7:      	jne	0x2ce <perf_unwind_hotspot+0x2ce>
    12dd:      	jmp	0x237 <perf_unwind_hotspot+0x237>
    12e2:      	movq	(%rip), %rax            # 0x12e9 <perf_unwind_hotspot+0x12e9>
    12e9:      	cmpl	$0x0, (%rax)
    12ec:      	jne	0x27aa <perf_unwind_hotspot+0x27aa>
    12f2:      	movl	(%r14), %eax
    12f5:      	movl	$0x60, (%rsp)
    12fc:      	movbel	%eax, 0x4(%rsp)
    1302:      	movq	0x50(%rsp), %rax
    1307:      	movbeq	%rax, 0x8(%rsp)
    130e:      	movq	(%rip), %rdi            # 0x1315 <perf_unwind_hotspot+0x1315>
    1315:      	movq	%rsp, %rsi
    1318:      	movl	$0x1, %eax
    131d:      	callq	*%rax
    131f:      	testq	%rax, %rax
    1322:      	je	0x13e5 <perf_unwind_hotspot+0x13e5>
    1328:      	movq	0x8(%rax), %rax
    132c:      	andq	%rbx, %rax
    132f:      	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
    1339:      	cmpq	%rcx, %rax
    133c:      	jne	0x13e5 <perf_unwind_hotspot+0x13e5>
    1342:      	addq	$0x10, %r13
    1346:      	movl	$0x2, %edx
    134b:      	jmp	0x168d <perf_unwind_hotspot+0x168d>
    1350:      	cmpl	$0x0, 0x2c0(%r14)
    1358:      	je	0x161b <perf_unwind_hotspot+0x161b>
    135e:      	cmpb	$0x0, 0x1f(%r15)
    1363:      	je	0x17a4 <perf_unwind_hotspot+0x17a4>
    1369:      	movq	0x50(%rsp), %rax
    136e:      	jmp	0x17a9 <perf_unwind_hotspot+0x17a9>
    1373:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    137d:      	movq	%rax, 0x55(%rsp)
    1382:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    138c:      	movq	%rax, 0x50(%rsp)
    1391:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    139b:      	movq	%rax, 0x48(%rsp)
    13a0:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    13aa:      	movq	%rax, 0x40(%rsp)
    13af:      	leaq	0x40(%rsp), %rdi
    13b4:      	movl	$0x1d, %eax
    13b9:      	movl	$0x6, %r8d
    13bf:      	movzbl	(%rsp), %ecx
    13c3:      	movl	$0x1d, %esi
    13c8:      	movq	%rbx, %rdx
    13cb:      	xorl	%eax, %eax
    13cd:      	callq	*%r8
    13d0:      	movzbl	(%rsp), %eax
    13d4:      	leal	0x1(%rax), %ecx
    13d7:      	cmpb	$0x2, %cl
    13da:      	jb	0x290 <perf_unwind_hotspot+0x290>
    13e0:      	jmp	0xaf9 <perf_unwind_hotspot+0xaf9>
    13e5:      	movq	(%rip), %rax            # 0x13ec <perf_unwind_hotspot+0x13ec>
    13ec:      	cmpl	$0x0, (%rax)
    13ef:      	jne	0x29d6 <perf_unwind_hotspot+0x29d6>
    13f5:      	movl	(%r14), %eax
    13f8:      	movl	$0x60, (%rsp)
    13ff:      	movbel	%eax, 0x4(%rsp)
    1405:      	movq	0x58(%rsp), %rax
    140a:      	movbeq	%rax, 0x8(%rsp)
    1411:      	movq	(%rip), %rdi            # 0x1418 <perf_unwind_hotspot+0x1418>
    1418:      	movq	%rsp, %rsi
    141b:      	movl	$0x1, %eax
    1420:      	callq	*%rax
    1422:      	testq	%rax, %rax
    1425:      	je	0x1481 <perf_unwind_hotspot+0x1481>
    1427:      	movq	0x8(%rax), %rax
    142b:      	andq	%rbx, %rax
    142e:      	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
    1438:      	cmpq	%rcx, %rax
    143b:      	jne	0x1481 <perf_unwind_hotspot+0x1481>
    143d:      	addq	$0x18, %r13
    1441:      	movl	$0x3, %edx
    1446:      	jmp	0x168d <perf_unwind_hotspot+0x168d>
    144b:      	movzbl	0x1(%rsp), %eax
    1450:      	cmpb	$-0x3d, %al
    1452:      	jne	0x1548 <perf_unwind_hotspot+0x1548>
    1458:      	movl	$0x1, 0xc0(%rsp)
    1463:      	movq	(%rip), %rax            # 0x146a <perf_unwind_hotspot+0x146a>
    146a:      	cmpl	$0x0, (%rax)
    146d:      	jne	0x2b1a <perf_unwind_hotspot+0x2b1a>
    1473:      	movb	$0x3, %al
    1475:      	movl	%eax, 0xb0(%rsp)
    147c:      	jmp	0x16cb <perf_unwind_hotspot+0x16cb>
    1481:      	movq	(%rip), %rax            # 0x1488 <perf_unwind_hotspot+0x1488>
    1488:      	cmpl	$0x0, (%rax)
    148b:      	jne	0x2a3f <perf_unwind_hotspot+0x2a3f>
    1491:      	movl	(%r14), %eax
    1494:      	movl	$0x60, (%rsp)
    149b:      	movbel	%eax, 0x4(%rsp)
    14a1:      	movq	0x60(%rsp), %rax
    14a6:      	movbeq	%rax, 0x8(%rsp)
    14ad:      	movq	(%rip), %rdi            # 0x14b4 <perf_unwind_hotspot+0x14b4>
    14b4:      	movq	%rsp, %rsi
    14b7:      	movl	$0x1, %eax
    14bc:      	callq	*%rax
    14be:      	testq	%rax, %rax
    14c1:      	je	0x1627 <perf_unwind_hotspot+0x1627>
    14c7:      	movq	0x8(%rax), %rax
    14cb:      	andq	%rbx, %rax
    14ce:      	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
    14d8:      	cmpq	%rcx, %rax
    14db:      	jne	0x1627 <perf_unwind_hotspot+0x1627>
    14e1:      	addq	$0x20, %r13
    14e5:      	movl	$0x4, %edx
    14ea:      	jmp	0x168d <perf_unwind_hotspot+0x168d>
    14ef:      	movabsq	$0xa626f6c626564, %rax  # imm = 0xA626F6C626564
    14f9:      	movq	%rax, 0x56(%rsp)
    14fe:      	movabsq	$0x65646f6320646165, %rax # imm = 0x65646F6320646165
    1508:      	movq	%rax, 0x50(%rsp)
    150d:      	movabsq	$0x72206f742064656c, %rax # imm = 0x72206F742064656C
    1517:      	movq	%rax, 0x48(%rsp)
    151c:      	movabsq	$0x696166203a6d766a, %rax # imm = 0x696166203A6D766A
    1526:      	movq	%rax, 0x40(%rsp)
    152b:      	leaq	0x40(%rsp), %rdi
    1530:      	movl	$0x1e, %eax
    1535:      	movl	$0x6, %ecx
    153a:      	movl	$0x1e, %esi
    153f:      	xorl	%eax, %eax
    1541:      	callq	*%rcx
    1543:      	jmp	0x310 <perf_unwind_hotspot+0x310>
    1548:      	movzbl	0x2(%rsp), %ecx
    154d:      	cmpb	$-0x3d, %cl
    1550:      	je	0x15a3 <perf_unwind_hotspot+0x15a3>
    1552:      	cmpb	$-0x3d, 0x3(%rsp)
    1557:      	je	0x15a3 <perf_unwind_hotspot+0x15a3>
    1559:      	cmpb	$-0x3d, 0x4(%rsp)
    155e:      	je	0x15a3 <perf_unwind_hotspot+0x15a3>
    1560:      	cmpb	$-0x3d, 0x5(%rsp)
    1565:      	je	0x15a3 <perf_unwind_hotspot+0x15a3>
    1567:      	cmpb	$-0x3d, 0x6(%rsp)
    156c:      	je	0x15a3 <perf_unwind_hotspot+0x15a3>
    156e:      	cmpb	$-0x3d, 0x7(%rsp)
    1573:      	je	0x15a3 <perf_unwind_hotspot+0x15a3>
    1575:      	cmpb	$-0x3d, 0x8(%rsp)
    157a:      	je	0x15a3 <perf_unwind_hotspot+0x15a3>
    157c:      	cmpb	$-0x3d, 0x9(%rsp)
    1581:      	je	0x15a3 <perf_unwind_hotspot+0x15a3>
    1583:      	cmpb	$-0x3d, 0xa(%rsp)
    1588:      	je	0x15a3 <perf_unwind_hotspot+0x15a3>
    158a:      	cmpb	$-0x3d, 0xb(%rsp)
    158f:      	je	0x15a3 <perf_unwind_hotspot+0x15a3>
    1591:      	cmpb	$-0x3d, 0xc(%rsp)
    1596:      	je	0x15a3 <perf_unwind_hotspot+0x15a3>
    1598:      	cmpb	$-0x3d, 0xd(%rsp)
    159d:      	jne	0x938 <perf_unwind_hotspot+0x938>
    15a3:      	cmpb	$0x5d, %al
    15a5:      	jne	0x1a28 <perf_unwind_hotspot+0x1a28>
    15ab:      	movl	$0x3, 0xc0(%rsp)
    15b6:      	movq	(%rip), %rax            # 0x15bd <perf_unwind_hotspot+0x15bd>
    15bd:      	cmpl	$0x0, (%rax)
    15c0:      	je	0x1473 <perf_unwind_hotspot+0x1473>
    15c6:      	movabsq	$0xa277062722070, %rax  # imm = 0xA277062722070
    15d0:      	movq	%rax, 0x58(%rsp)
    15d5:      	movabsq	$0x6f7027206e6f2065, %rax # imm = 0x6F7027206E6F2065
    15df:      	movq	%rax, 0x50(%rsp)
    15e4:      	movabsq	$0x75676f6c69706520, %rax # imm = 0x75676F6C69706520
    15ee:      	movq	%rax, 0x48(%rsp)
    15f3:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    15fd:      	movq	%rax, 0x40(%rsp)
    1602:      	leaq	0x40(%rsp), %rdi
    1607:      	movl	$0x20, %eax
    160c:      	movl	$0x6, %ecx
    1611:      	movl	$0x20, %esi
    1616:      	jmp	0x2b63 <perf_unwind_hotspot+0x2b63>
    161b:      	movq	0xf00(%r14), %rax
    1622:      	jmp	0x17a9 <perf_unwind_hotspot+0x17a9>
    1627:      	movq	(%rip), %rax            # 0x162e <perf_unwind_hotspot+0x162e>
    162e:      	cmpl	$0x0, (%rax)
    1631:      	jne	0x2c11 <perf_unwind_hotspot+0x2c11>
    1637:      	movl	(%r14), %eax
    163a:      	movl	$0x60, (%rsp)
    1641:      	movbel	%eax, 0x4(%rsp)
    1647:      	movq	0x68(%rsp), %rax
    164c:      	movbeq	%rax, 0x8(%rsp)
    1653:      	movq	(%rip), %rdi            # 0x165a <perf_unwind_hotspot+0x165a>
    165a:      	movq	%rsp, %rsi
    165d:      	movl	$0x1, %eax
    1662:      	callq	*%rax
    1664:      	testq	%rax, %rax
    1667:      	je	0x1772 <perf_unwind_hotspot+0x1772>
    166d:      	andq	0x8(%rax), %rbx
    1671:      	movabsq	$0x200000000000000, %rax # imm = 0x200000000000000
    167b:      	cmpq	%rax, %rbx
    167e:      	jne	0x1772 <perf_unwind_hotspot+0x1772>
    1684:      	addq	$0x28, %r13
    1688:      	movl	$0x5, %edx
    168d:      	movq	%r13, 0x118(%rsp)
    1695:      	xorl	%ebx, %ebx
    1697:      	movl	$0x5, 0xc0(%rsp)
    16a2:      	movq	(%rip), %rax            # 0x16a9 <perf_unwind_hotspot+0x16a9>
    16a9:      	cmpl	$0x0, (%rax)
    16ac:      	jne	0x25f4 <perf_unwind_hotspot+0x25f4>
    16b2:      	movb	$0x3, %al
    16b4:      	movl	%eax, 0xb0(%rsp)
    16bb:      	movq	0x118(%rsp), %r13
    16c3:      	testl	%ebx, %ebx
    16c5:      	jne	0x347 <perf_unwind_hotspot+0x347>
    16cb:      	cmpl	$0x2, 0xc0(%rsp)
    16d3:      	jle	0x1707 <perf_unwind_hotspot+0x1707>
    16d5:      	cmpl	$0x4, 0xc0(%rsp)
    16dd:      	jg	0x173b <perf_unwind_hotspot+0x173b>
    16df:      	cmpl	$0x3, 0xc0(%rsp)
    16e7:      	je	0xe93 <perf_unwind_hotspot+0xe93>
    16ed:      	cmpl	$0x4, 0xc0(%rsp)
    16f5:      	jne	0x1015 <perf_unwind_hotspot+0x1015>
    16fb:      	movl	0xf0(%rsp), %eax
    1702:      	jmp	0x9ba <perf_unwind_hotspot+0x9ba>
    1707:      	movl	$0x1, %ebx
    170c:      	cmpl	$0x0, 0xc0(%rsp)
    1714:      	je	0x347 <perf_unwind_hotspot+0x347>
    171a:      	cmpl	$0x1, 0xc0(%rsp)
    1722:      	je	0x9aa <perf_unwind_hotspot+0x9aa>
    1728:      	cmpl	$0x2, 0xc0(%rsp)
    1730:      	je	0x97a <perf_unwind_hotspot+0x97a>
    1736:      	jmp	0x1015 <perf_unwind_hotspot+0x1015>
    173b:      	cmpl	$0x5, 0xc0(%rsp)
    1743:      	je	0x1765 <perf_unwind_hotspot+0x1765>
    1745:      	cmpl	$0x6, 0xc0(%rsp)
    174d:      	movq	0x38(%rsp), %r8
    1752:      	movq	0xa8(%rsp), %rbx
    175a:      	je	0xef6 <perf_unwind_hotspot+0xef6>
    1760:      	jmp	0x1015 <perf_unwind_hotspot+0x1015>
    1765:      	movq	0xa8(%rsp), %rbx
    176d:      	jmp	0xeb6 <perf_unwind_hotspot+0xeb6>
    1772:      	movl	$0x2e, 0x100(%rsp)
    177d:      	movq	(%rip), %rdi            # 0x1784 <perf_unwind_hotspot+0x1784>
    1784:      	leaq	0x100(%rsp), %rsi
    178c:      	movl	$0x1, %eax
    1791:      	callq	*%rax
    1793:      	testq	%rax, %rax
    1796:      	je	0x1a03 <perf_unwind_hotspot+0x1a03>
    179c:      	incq	(%rax)
    179f:      	jmp	0x1a13 <perf_unwind_hotspot+0x1a13>
    17a4:      	movq	0x58(%rsp), %rax
    17a9:      	movq	%rax, 0xb0(%rsp)
    17b1:      	movq	0x78(%rsp), %rsi
    17b6:      	movq	0x88(%rsp), %r13
    17be:      	movq	0x90(%rsp), %rax
    17c6:      	movq	%rax, 0x38(%rsp)
    17cb:      	movq	0x98(%rsp), %r12
    17d3:      	movzbl	0x1c(%r15), %eax
    17d8:      	addq	%rsi, %rax
    17db:      	leaq	0x100(%rsp), %rdi
    17e3:      	movl	$0x8, %ecx
    17e8:      	movl	$0x70, %r8d
    17ee:      	movzbl	0x1c(%r15), %edx
    17f3:      	movq	%rsi, 0x118(%rsp)
    17fb:      	addq	%rsi, %rdx
    17fe:      	movl	$0x8, %esi
    1803:      	callq	*%r8
    1806:      	testq	%rax, %rax
    1809:      	je	0x1881 <perf_unwind_hotspot+0x1881>
    180b:      	movq	(%rip), %rax            # 0x1812 <perf_unwind_hotspot+0x1812>
    1812:      	cmpl	$0x0, (%rax)
    1815:      	je	0xe50 <perf_unwind_hotspot+0xe50>
    181b:      	movabsq	$0xa646f6874656d63, %rax # imm = 0xA646F6874656D63
    1825:      	movq	%rax, 0x20(%rsp)
    182a:      	movabsq	$0x2072657465727072, %rax # imm = 0x2072657465727072
    1834:      	movq	%rax, 0x18(%rsp)
    1839:      	movabsq	$0x65746e6920646165, %rax # imm = 0x65746E6920646165
    1843:      	movq	%rax, 0x10(%rsp)
    1848:      	movabsq	$0x72206f742064656c, %rax # imm = 0x72206F742064656C
    1852:      	movq	%rax, 0x8(%rsp)
    1857:      	movabsq	$0x696166203a6d766a, %rax # imm = 0x696166203A6D766A
    1861:      	movq	%rax, (%rsp)
    1865:      	movb	$0x0, 0x28(%rsp)
    186a:      	movq	%rsp, %rdi
    186d:      	movl	$0x29, %eax
    1872:      	movl	$0x6, %ecx
    1877:      	movl	$0x29, %esi
    187c:      	jmp	0x2425 <perf_unwind_hotspot+0x2425>
    1881:      	movq	0x100(%rsp), %rbp
    1889:      	movzbl	0x1d(%r15), %eax
    188e:      	addq	%rbp, %rax
    1891:      	xorl	%ebx, %ebx
    1893:      	movq	0xb0(%rsp), %rdx
    189b:      	cmpq	%rax, %rdx
    189e:      	movl	$0x0, %ecx
    18a3:      	cmovaeq	%rax, %rcx
    18a7:      	subq	%rcx, %rdx
    18aa:      	movq	%rdx, 0xb0(%rsp)
    18b2:      	movq	(%rip), %rax            # 0x18b9 <perf_unwind_hotspot+0x18b9>
    18b9:      	cmpl	$0x0, (%rax)
    18bc:      	jne	0x2b6c <perf_unwind_hotspot+0x2b6c>
    18c2:      	movq	0xb0(%rsp), %rcx
    18ca:      	cmpq	$0xffff, %rcx           # imm = 0xFFFF
    18d1:      	movl	$0xffff, %eax           # imm = 0xFFFF
    18d6:      	cmovbq	%rcx, %rax
    18da:      	movq	%rax, 0xa8(%rsp)
    18e2:      	shrq	$0x3, %rbp
    18e6:      	movl	$0x6, 0xc0(%rsp)
    18f1:      	movb	$0x2, %al
    18f3:      	movl	%eax, 0xb0(%rsp)
    18fa:      	movq	0x118(%rsp), %rax
    1902:      	movq	%rax, 0xb8(%rsp)
    190a:      	testl	%ebx, %ebx
    190c:      	jne	0x347 <perf_unwind_hotspot+0x347>
    1912:      	jmp	0x16cb <perf_unwind_hotspot+0x16cb>
    1917:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1921:      	movq	%rax, 0x66(%rsp)
    1926:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1930:      	movq	%rax, 0x60(%rsp)
    1935:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    193f:      	movq	%rax, 0x58(%rsp)
    1944:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    194e:      	movq	%rax, 0x50(%rsp)
    1953:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    195d:      	movq	%rax, 0x48(%rsp)
    1962:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    196c:      	movq	%rax, 0x40(%rsp)
    1971:      	leaq	0x40(%rsp), %rdi
    1976:      	movl	$0x2e, %eax
    197b:      	movl	$0x6, %ecx
    1980:      	movl	(%rsp), %edx
    1983:      	movl	$0x2e, %esi
    1988:      	xorl	%eax, %eax
    198a:      	callq	*%rcx
    198c:      	jmp	0x6e7 <perf_unwind_hotspot+0x6e7>
    1991:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    199b:      	movq	%rax, 0x55(%rsp)
    19a0:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    19aa:      	movq	%rax, 0x50(%rsp)
    19af:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    19b9:      	movq	%rax, 0x48(%rsp)
    19be:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    19c8:      	movq	%rax, 0x40(%rsp)
    19cd:      	leaq	0x40(%rsp), %rdi
    19d2:      	movl	$0x1d, %eax
    19d7:      	movl	$0x6, %r8d
    19dd:      	movzbl	(%rsp), %ecx
    19e1:      	movl	$0x1d, %esi
    19e6:      	movq	%rbx, %rdx
    19e9:      	xorl	%eax, %eax
    19eb:      	callq	*%r8
    19ee:      	movzbl	(%rsp), %eax
    19f2:      	leal	0x1(%rax), %ecx
    19f5:      	cmpb	$0x2, %cl
    19f8:      	jb	0x290 <perf_unwind_hotspot+0x290>
    19fe:      	jmp	0xb40 <perf_unwind_hotspot+0xb40>
    1a03:      	movq	(%rip), %rax            # 0x1a0a <perf_unwind_hotspot+0x1a0a>
    1a0a:      	cmpl	$0x0, (%rax)
    1a0d:      	jne	0x3b6f <perf_unwind_hotspot+0x3b6f>
    1a13:      	movl	$0x3ea, %ebx            # imm = 0x3EA
    1a18:      	movl	$0x0, 0xc0(%rsp)
    1a23:      	jmp	0x16b2 <perf_unwind_hotspot+0x16b2>
    1a28:      	cmpb	$0x41, %al
    1a2a:      	jne	0x1aca <perf_unwind_hotspot+0x1aca>
    1a30:      	cmpb	$-0x7b, %cl
    1a33:      	jne	0x1aca <perf_unwind_hotspot+0x1aca>
    1a39:      	cmpb	$0x2, 0x3(%rsp)
    1a3e:      	jne	0x1aca <perf_unwind_hotspot+0x1aca>
    1a44:      	cmpb	$-0x3d, 0x4(%rsp)
    1a49:      	jne	0x1aca <perf_unwind_hotspot+0x1aca>
    1a4b:      	movl	$0x1, 0xc0(%rsp)
    1a56:      	movq	(%rip), %rax            # 0x1a5d <perf_unwind_hotspot+0x1a5d>
    1a5d:      	cmpl	$0x0, (%rax)
    1a60:      	je	0x1473 <perf_unwind_hotspot+0x1473>
    1a66:      	movabsq	$0xa276b63656863, %rax  # imm = 0xA276B63656863
    1a70:      	movq	%rax, 0x5f(%rsp)
    1a75:      	movabsq	$0x6320746e696f7065, %rax # imm = 0x6320746E696F7065
    1a7f:      	movq	%rax, 0x58(%rsp)
    1a84:      	movabsq	$0x666173206e6f2065, %rax # imm = 0x666173206E6F2065
    1a8e:      	movq	%rax, 0x50(%rsp)
    1a93:      	movabsq	$0x75676f6c69706520, %rax # imm = 0x75676F6C69706520
    1a9d:      	movq	%rax, 0x48(%rsp)
    1aa2:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    1aac:      	movq	%rax, 0x40(%rsp)
    1ab1:      	leaq	0x40(%rsp), %rdi
    1ab6:      	movl	$0x27, %eax
    1abb:      	movl	$0x6, %ecx
    1ac0:      	movl	$0x27, %esi
    1ac5:      	jmp	0x2b63 <perf_unwind_hotspot+0x2b63>
    1aca:      	cmpb	$0xf, %al
    1acc:      	jne	0x1bf5 <perf_unwind_hotspot+0x1bf5>
    1ad2:      	cmpb	$-0x7b, %cl
    1ad5:      	jne	0x1bf5 <perf_unwind_hotspot+0x1bf5>
    1adb:      	cmpb	$-0x3d, 0x7(%rsp)
    1ae0:      	jne	0x1bf5 <perf_unwind_hotspot+0x1bf5>
    1ae6:      	movl	$0x1, 0xc0(%rsp)
    1af1:      	movq	(%rip), %rax            # 0x1af8 <perf_unwind_hotspot+0x1af8>
    1af8:      	cmpl	$0x0, (%rax)
    1afb:      	je	0x1473 <perf_unwind_hotspot+0x1473>
    1b01:      	movabsq	$0xa276b63656863, %rax  # imm = 0xA276B63656863
    1b0b:      	movq	%rax, 0x6e(%rsp)
    1b10:      	movabsq	$0x6863206e6f697470, %rax # imm = 0x6863206E6F697470
    1b1a:      	movq	%rax, 0x68(%rsp)
    1b1f:      	movabsq	$0x6563786520726570, %rax # imm = 0x6563786520726570
    1b29:      	movq	%rax, 0x60(%rsp)
    1b2e:      	movabsq	$0x7061727720657669, %rax # imm = 0x7061727720657669
    1b38:      	movq	%rax, 0x58(%rsp)
    1b3d:      	movabsq	$0x74616e206e6f2065, %rax # imm = 0x74616E206E6F2065
    1b47:      	movq	%rax, 0x50(%rsp)
    1b4c:      	movabsq	$0x75676f6c69706520, %rax # imm = 0x75676F6C69706520
    1b56:      	movq	%rax, 0x48(%rsp)
    1b5b:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    1b65:      	movq	%rax, 0x40(%rsp)
    1b6a:      	leaq	0x40(%rsp), %rdi
    1b6f:      	movl	$0x36, %eax
    1b74:      	movl	$0x6, %ecx
    1b79:      	movl	$0x36, %esi
    1b7e:      	jmp	0x2b63 <perf_unwind_hotspot+0x2b63>
    1b83:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    1b8d:      	movq	%rax, 0x55(%rsp)
    1b92:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    1b9c:      	movq	%rax, 0x50(%rsp)
    1ba1:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    1bab:      	movq	%rax, 0x48(%rsp)
    1bb0:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    1bba:      	movq	%rax, 0x40(%rsp)
    1bbf:      	leaq	0x40(%rsp), %rdi
    1bc4:      	movl	$0x1d, %eax
    1bc9:      	movl	$0x6, %r8d
    1bcf:      	movzbl	(%rsp), %ecx
    1bd3:      	movl	$0x1d, %esi
    1bd8:      	movq	%rbx, %rdx
    1bdb:      	xorl	%eax, %eax
    1bdd:      	callq	*%r8
    1be0:      	movzbl	(%rsp), %eax
    1be4:      	leal	0x1(%rax), %ecx
    1be7:      	cmpb	$0x2, %cl
    1bea:      	jb	0x290 <perf_unwind_hotspot+0x290>
    1bf0:      	jmp	0xb87 <perf_unwind_hotspot+0xb87>
    1bf5:      	movzbl	(%rsp), %eax
    1bf9:      	cmpl	$0xc9, %eax
    1bfe:      	je	0x1c09 <perf_unwind_hotspot+0x1c09>
    1c00:      	cmpl	$0x5d, %eax
    1c03:      	jne	0x938 <perf_unwind_hotspot+0x938>
    1c09:      	movl	$0x1, 0xc0(%rsp)
    1c14:      	movq	(%rip), %rax            # 0x1c1b <perf_unwind_hotspot+0x1c1b>
    1c1b:      	cmpl	$0x0, (%rax)
    1c1e:      	je	0x1473 <perf_unwind_hotspot+0x1473>
    1c24:      	movabsq	$0xa27657661656c, %rax  # imm = 0xA27657661656C
    1c2e:      	movq	%rax, 0x58(%rsp)
    1c33:      	movabsq	$0x2072657466612065, %rax # imm = 0x2072657466612065
    1c3d:      	movq	%rax, 0x50(%rsp)
    1c42:      	movabsq	$0x75676f6c69706520, %rax # imm = 0x75676F6C69706520
    1c4c:      	movq	%rax, 0x48(%rsp)
    1c51:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    1c5b:      	movq	%rax, 0x40(%rsp)
    1c60:      	leaq	0x40(%rsp), %rdi
    1c65:      	movl	$0x20, %eax
    1c6a:      	movl	$0x6, %ecx
    1c6f:      	jmp	0x1611 <perf_unwind_hotspot+0x1611>
    1c74:      	movabsq	$0xa786c252d786c, %rax  # imm = 0xA786C252D786C
    1c7e:      	movq	%rax, 0x4f(%rsp)
    1c83:      	movabsq	$0x6c252065646f6320, %rax # imm = 0x6C252065646F6320
    1c8d:      	movq	%rax, 0x48(%rsp)
    1c92:      	movabsq	$0x3e2d20203a6d766a, %rbx # imm = 0x3E2D20203A6D766A
    1c9c:      	movq	%rbx, 0x40(%rsp)
    1ca1:      	leaq	0x40(%rsp), %rdi
    1ca6:      	movl	$0x17, %eax
    1cab:      	movl	$0x6, %r8d
    1cb1:      	movq	0xd0(%rsp), %rdx
    1cb9:      	movq	0xd8(%rsp), %rcx
    1cc1:      	movl	$0x17, %esi
    1cc6:      	xorl	%eax, %eax
    1cc8:      	callq	*%r8
    1ccb:      	movq	(%rip), %rax            # 0x1cd2 <perf_unwind_hotspot+0x1cd2>
    1cd2:      	cmpl	$0x0, (%rax)
    1cd5:      	je	0x5dc <perf_unwind_hotspot+0x5dc>
    1cdb:      	movabsq	$0x783020657079745f, %rax # imm = 0x783020657079745F
    1ce5:      	movq	%rax, 0x70(%rsp)
    1cea:      	movabsq	$0x656d617266202c75, %rax # imm = 0x656D617266202C75
    1cf4:      	movq	%rax, 0x68(%rsp)
    1cf9:      	movabsq	$0x2520657a69735f65, %rax # imm = 0x2520657A69735F65
    1d03:      	movq	%rax, 0x60(%rsp)
    1d08:      	movabsq	$0x6d617266202c7525, %rax # imm = 0x6D617266202C7525
    1d12:      	movq	%rax, 0x58(%rsp)
    1d17:      	movabsq	$0x206574656c706d6f, %rax # imm = 0x206574656C706D6F
    1d21:      	movq	%rax, 0x50(%rsp)
    1d26:      	movabsq	$0x635f656d61726620, %rax # imm = 0x635F656D61726620
    1d30:      	movq	%rax, 0x48(%rsp)
    1d35:      	movq	%rbx, 0x40(%rsp)
    1d3a:      	movl	$0xa7825, 0x78(%rsp)    # imm = 0xA7825
    1d42:      	leaq	0x40(%rsp), %rdi
    1d47:      	movl	$0x3c, %eax
    1d4c:      	movl	$0x6, %r9d
    1d52:      	movzwl	0xf8(%rsp), %edx
    1d5a:      	movl	0xe8(%rsp), %r8d
    1d62:      	movl	0xf0(%rsp), %ecx
    1d69:      	movl	$0x3c, %esi
    1d6e:      	xorl	%eax, %eax
    1d70:      	callq	*%r9
    1d73:      	jmp	0x5dc <perf_unwind_hotspot+0x5dc>
    1d78:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    1d82:      	movq	%rax, 0x55(%rsp)
    1d87:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    1d91:      	movq	%rax, 0x50(%rsp)
    1d96:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    1da0:      	movq	%rax, 0x48(%rsp)
    1da5:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    1daf:      	movq	%rax, 0x40(%rsp)
    1db4:      	leaq	0x40(%rsp), %rdi
    1db9:      	movl	$0x1d, %eax
    1dbe:      	movl	$0x6, %r8d
    1dc4:      	movzbl	(%rsp), %ecx
    1dc8:      	movl	$0x1d, %esi
    1dcd:      	movq	%rbx, %rdx
    1dd0:      	xorl	%eax, %eax
    1dd2:      	callq	*%r8
    1dd5:      	movzbl	(%rsp), %eax
    1dd9:      	leal	0x1(%rax), %ecx
    1ddc:      	cmpb	$0x2, %cl
    1ddf:      	jb	0x290 <perf_unwind_hotspot+0x290>
    1de5:      	jmp	0xbce <perf_unwind_hotspot+0xbce>
    1dea:      	movabsq	$0xa6c6c75662073, %rax  # imm = 0xA6C6C75662073
    1df4:      	movq	%rax, 0x5d(%rsp)
    1df9:      	movabsq	$0x66207369206b6361, %rax # imm = 0x66207369206B6361
    1e03:      	movq	%rax, 0x58(%rsp)
    1e08:      	movabsq	$0x7473203a656d6172, %rax # imm = 0x7473203A656D6172
    1e12:      	movq	%rax, 0x50(%rsp)
    1e17:      	movabsq	$0x662068737570206f, %rax # imm = 0x662068737570206F
    1e21:      	movq	%rax, 0x48(%rsp)
    1e26:      	movabsq	$0x7420656c62616e75, %rax # imm = 0x7420656C62616E75
    1e30:      	movq	%rax, 0x40(%rsp)
    1e35:      	leaq	0x40(%rsp), %rdi
    1e3a:      	movl	$0x25, %eax
    1e3f:      	movl	$0x6, %ecx
    1e44:      	movl	$0x25, %esi
    1e49:      	xorl	%eax, %eax
    1e4b:      	callq	*%rcx
    1e4d:      	jmp	0xf13 <perf_unwind_hotspot+0xf13>
    1e52:      	movabsq	$0x25203a7066202c78, %rax # imm = 0x25203A7066202C78
    1e5c:      	movq	%rax, 0x58(%rsp)
    1e61:      	movabsq	$0x6c25203a7073202c, %rax # imm = 0x6C25203A7073202C
    1e6b:      	movq	%rax, 0x50(%rsp)
    1e70:      	movabsq	$0x786c25203a637020, %rax # imm = 0x786C25203A637020
    1e7a:      	movq	%rax, 0x48(%rsp)
    1e7f:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    1e89:      	movq	%rax, 0x40(%rsp)
    1e8e:      	movl	$0xa786c, 0x60(%rsp)    # imm = 0xA786C
    1e96:      	leaq	0x40(%rsp), %rdi
    1e9b:      	movl	$0x24, %eax
    1ea0:      	movl	$0x6, %r9d
    1ea6:      	movl	$0x24, %esi
    1eab:      	movq	%r12, %rdx
    1eae:      	movq	%r13, %rcx
    1eb1:      	movq	%r8, %rbp
    1eb4:      	xorl	%eax, %eax
    1eb6:      	callq	*%r9
    1eb9:      	movq	%rbp, %r8
    1ebc:      	jmp	0xfba <perf_unwind_hotspot+0xfba>
    1ec1:      	movabsq	$0xa706620726576, %rax  # imm = 0xA706620726576
    1ecb:      	movq	%rax, 0x4d(%rsp)
    1ed0:      	movabsq	$0x7265766f63657220, %rax # imm = 0x7265766F63657220
    1eda:      	movq	%rax, 0x48(%rsp)
    1edf:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    1ee9:      	movq	%rax, 0x40(%rsp)
    1eee:      	leaq	0x40(%rsp), %rdi
    1ef3:      	movl	$0x15, %eax
    1ef8:      	movl	$0x6, %ecx
    1efd:      	movl	$0x15, %esi
    1f02:      	xorl	%eax, %eax
    1f04:      	callq	*%rcx
    1f06:      	jmp	0xef2 <perf_unwind_hotspot+0xef2>
    1f0b:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    1f15:      	movq	%rax, 0x68(%rsp)
    1f1a:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    1f24:      	movq	%rax, 0x60(%rsp)
    1f29:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    1f33:      	movq	%rax, 0x58(%rsp)
    1f38:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    1f42:      	movq	%rax, 0x50(%rsp)
    1f47:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    1f51:      	movq	%rax, 0x48(%rsp)
    1f56:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    1f60:      	movq	%rax, 0x40(%rsp)
    1f65:      	movb	$0x0, 0x70(%rsp)
    1f6a:      	leaq	0x40(%rsp), %rdi
    1f6f:      	movl	$0x31, %eax
    1f74:      	movl	$0x6, %ecx
    1f79:      	movl	0x2c0(%r14), %edx
    1f80:      	movl	$0x31, %esi
    1f85:      	xorl	%eax, %eax
    1f87:      	callq	*%rcx
    1f89:      	movq	0xed0(%r14), %rbx
    1f90:      	cmpq	%r12, %rbx
    1f93:      	ja	0x1049 <perf_unwind_hotspot+0x1049>
    1f99:      	cmpq	$0xfff, %rbx            # imm = 0xFFF
    1fa0:      	ja	0x1fca <perf_unwind_hotspot+0x1fca>
    1fa2:      	movq	(%rip), %rax            # 0x1fa9 <perf_unwind_hotspot+0x1fa9>
    1fa9:      	cmpl	$0x0, (%rax)
    1fac:      	jne	0x26e5 <perf_unwind_hotspot+0x26e5>
    1fb2:      	movl	$0x31, 0xf28(%r14)
    1fbd:      	movl	$0xfae, %ebp            # imm = 0xFAE
    1fc2:      	xorl	%r12d, %r12d
    1fc5:      	jmp	0x34c <perf_unwind_hotspot+0x34c>
    1fca:      	movl	(%r14), %eax
    1fcd:      	movl	$0x60, 0xc8(%rsp)
    1fd8:      	movbel	%eax, 0xcc(%rsp)
    1fe1:      	movbeq	%rbx, 0xd0(%rsp)
    1feb:      	movq	(%rip), %rdi            # 0x1ff2 <perf_unwind_hotspot+0x1ff2>
    1ff2:      	leaq	0xc8(%rsp), %rsi
    1ffa:      	movl	$0x1, %eax
    1fff:      	callq	*%rax
    2001:      	testq	%rax, %rax
    2004:      	je	0x9d07 <perf_unwind_hotspot+0x9d07>
    200a:      	movq	0x8(%rax), %r12
    200e:      	movq	%r12, %rcx
    2011:      	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    201b:      	andq	%rdx, %rcx
    201e:      	movq	%rcx, 0xf20(%r14)
    2025:      	movq	(%rax), %rax
    2028:      	movq	%rax, 0xf10(%r14)
    202f:      	shrq	$0x38, %r12
    2033:      	movq	%rbx, %rax
    2036:      	subq	%rcx, %rax
    2039:      	movq	%rax, 0xf18(%r14)
    2040:      	movq	(%rip), %rax            # 0x2047 <perf_unwind_hotspot+0x2047>
    2047:      	cmpl	$0x0, (%rax)
    204a:      	jne	0x2813 <perf_unwind_hotspot+0x2813>
    2050:      	cmpl	$0x1, %r12d
    2054:      	jne	0x2d1c <perf_unwind_hotspot+0x2d1c>
    205a:      	movq	0xf10(%r14), %rax
    2061:      	movq	%rax, 0xc8(%rsp)
    2069:      	movq	0xf18(%r14), %r13
    2070:      	movq	(%rip), %rdi            # 0x2077 <perf_unwind_hotspot+0x2077>
    2077:      	leaq	0xc8(%rsp), %rsi
    207f:      	movl	$0x1, %eax
    2084:      	callq	*%rax
    2086:      	movl	$0x1, %r12d
    208c:      	testq	%rax, %rax
    208f:      	je	0x2d1c <perf_unwind_hotspot+0x2d1c>
    2095:      	movq	%rax, %rbx
    2098:      	cmpq	%r13, (%rax)
    209b:      	ja	0x20a3 <perf_unwind_hotspot+0x20a3>
    209d:      	cmpq	%r13, 0x8(%rbx)
    20a1:      	jae	0x20b7 <perf_unwind_hotspot+0x20b7>
    20a3:      	cmpq	%r13, 0x10(%rbx)
    20a7:      	ja	0x2d1c <perf_unwind_hotspot+0x2d1c>
    20ad:      	cmpq	%r13, 0x18(%rbx)
    20b1:      	jb	0x2d1c <perf_unwind_hotspot+0x2d1c>
    20b7:      	movq	(%rip), %rax            # 0x20be <perf_unwind_hotspot+0x20be>
    20be:      	cmpl	$0x0, (%rax)
    20c1:      	jne	0x2c7a <perf_unwind_hotspot+0x2c7a>
    20c7:      	movl	0x1380(%r14), %eax
    20ce:      	movl	0x20(%rbx), %ecx
    20d1:      	btl	%ecx, %eax
    20d4:      	jae	0x2ce5 <perf_unwind_hotspot+0x2ce5>
    20da:      	movq	(%rip), %rax            # 0x20e1 <perf_unwind_hotspot+0x20e1>
    20e1:      	cmpl	$0x0, (%rax)
    20e4:      	je	0x2d1c <perf_unwind_hotspot+0x2d1c>
    20ea:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    20f4:      	movq	%rax, 0x50(%rsp)
    20f9:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    2103:      	movq	%rax, 0x48(%rsp)
    2108:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    2112:      	movq	%rax, 0x40(%rsp)
    2117:      	movl	$0xa656e, 0x57(%rsp)    # imm = 0xA656E
    211f:      	leaq	0x40(%rsp), %rdi
    2124:      	movl	$0x1b, %eax
    2129:      	movl	$0x6, %ecx
    212e:      	movl	$0x1b, %esi
    2133:      	xorl	%eax, %eax
    2135:      	callq	*%rcx
    2137:      	jmp	0x2d1c <perf_unwind_hotspot+0x2d1c>
    213c:      	movabsq	$0x6170206b6361626c, %rax # imm = 0x6170206B6361626C
    2146:      	movq	%rax, 0x58(%rsp)
    214b:      	movabsq	$0x6c61662062757473, %rax # imm = 0x6C61662062757473
    2155:      	movq	%rax, 0x50(%rsp)
    215a:      	movabsq	$0x20646e69776e7520, %rax # imm = 0x20646E69776E7520
    2164:      	movq	%rax, 0x48(%rsp)
    2169:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    2173:      	movq	%rax, 0x40(%rsp)
    2178:      	movl	$0xa6874, 0x60(%rsp)    # imm = 0xA6874
    2180:      	leaq	0x40(%rsp), %rdi
    2185:      	movl	$0x24, %eax
    218a:      	movl	$0x6, %ecx
    218f:      	movl	$0x24, %esi
    2194:      	xorl	%eax, %eax
    2196:      	callq	*%rcx
    2198:      	jmp	0x8ee <perf_unwind_hotspot+0x8ee>
    219d:      	movabsq	$0xa656c62617476, %rax  # imm = 0xA656C62617476
    21a7:      	movq	%rax, 0x50(%rsp)
    21ac:      	movabsq	$0x20646e69776e7520, %rax # imm = 0x20646E69776E7520
    21b6:      	movq	%rax, 0x48(%rsp)
    21bb:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    21c5:      	movq	%rax, 0x40(%rsp)
    21ca:      	leaq	0x40(%rsp), %rdi
    21cf:      	movl	$0x18, %eax
    21d4:      	movl	$0x6, %ecx
    21d9:      	movl	$0x18, %esi
    21de:      	xorl	%eax, %eax
    21e0:      	callq	*%rcx
    21e2:      	jmp	0x9aa <perf_unwind_hotspot+0x9aa>
    21e7:      	movabsq	$0xa64656c696166, %rax  # imm = 0xA64656C696166
    21f1:      	movq	%rax, 0x68(%rsp)
    21f6:      	movabsq	$0x20797265766f6365, %rax # imm = 0x20797265766F6365
    2200:      	movq	%rax, 0x60(%rsp)
    2205:      	movabsq	$0x72206370202c656d, %rax # imm = 0x72206370202C656D
    220f:      	movq	%rax, 0x58(%rsp)
    2214:      	movabsq	$0x6172662064657a69, %rax # imm = 0x6172662064657A69
    221e:      	movq	%rax, 0x50(%rsp)
    2223:      	movabsq	$0x6d6974706f656420, %rax # imm = 0x6D6974706F656420
    222d:      	movq	%rax, 0x48(%rsp)
    2232:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    223c:      	movq	%rax, 0x40(%rsp)
    2241:      	leaq	0x40(%rsp), %rdi
    2246:      	movl	$0x30, %eax
    224b:      	movl	$0x6, %ecx
    2250:      	movl	$0x30, %esi
    2255:      	xorl	%eax, %eax
    2257:      	callq	*%rcx
    2259:      	jmp	0x7d2 <perf_unwind_hotspot+0x7d2>
    225e:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2268:      	movq	%rax, 0x66(%rsp)
    226d:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2277:      	movq	%rax, 0x60(%rsp)
    227c:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2286:      	movq	%rax, 0x58(%rsp)
    228b:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2295:      	movq	%rax, 0x50(%rsp)
    229a:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    22a4:      	movq	%rax, 0x48(%rsp)
    22a9:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    22b3:      	movq	%rax, 0x40(%rsp)
    22b8:      	leaq	0x40(%rsp), %rdi
    22bd:      	movl	$0x2e, %eax
    22c2:      	movl	$0x6, %ecx
    22c7:      	movl	(%rsp), %edx
    22ca:      	movl	$0x2e, %esi
    22cf:      	xorl	%eax, %eax
    22d1:      	callq	*%rcx
    22d3:      	movl	$0x2, %ebx
    22d8:      	jmp	0x347 <perf_unwind_hotspot+0x347>
    22dd:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    22e7:      	movq	%rax, 0x66(%rsp)
    22ec:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    22f6:      	movq	%rax, 0x60(%rsp)
    22fb:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2305:      	movq	%rax, 0x58(%rsp)
    230a:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2314:      	movq	%rax, 0x50(%rsp)
    2319:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2323:      	movq	%rax, 0x48(%rsp)
    2328:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2332:      	movq	%rax, 0x40(%rsp)
    2337:      	leaq	0x40(%rsp), %rdi
    233c:      	movl	$0x2e, %eax
    2341:      	movl	$0x6, %ecx
    2346:      	movl	(%rsp), %edx
    2349:      	movl	$0x2e, %esi
    234e:      	xorl	%eax, %eax
    2350:      	callq	*%rcx
    2352:      	jmp	0x1015 <perf_unwind_hotspot+0x1015>
    2357:      	movabsq	$0x7373657264646120, %rax # imm = 0x7373657264646120
    2361:      	movq	%rax, 0x58(%rsp)
    2366:      	movabsq	$0x6c656e72656b2061, %rax # imm = 0x6C656E72656B2061
    2370:      	movq	%rax, 0x50(%rsp)
    2375:      	movabsq	$0x20736920786c2520, %rax # imm = 0x20736920786C2520
    237f:      	movq	%rax, 0x48(%rsp)
    2384:      	movabsq	$0x65756c6176204350, %rax # imm = 0x65756C6176204350
    238e:      	movq	%rax, 0x40(%rsp)
    2393:      	movw	$0xa, 0x60(%rsp)
    239a:      	leaq	0x40(%rsp), %rdi
    239f:      	movl	$0x22, %eax
    23a4:      	movl	$0x6, %ecx
    23a9:      	movl	$0x22, %esi
    23ae:      	movq	%rbx, %rdx
    23b1:      	xorl	%eax, %eax
    23b3:      	callq	*%rcx
    23b5:      	jmp	0x1059 <perf_unwind_hotspot+0x1059>
    23ba:      	movabsq	$0xa656d61726620, %rax  # imm = 0xA656D61726620
    23c4:      	movq	%rax, 0x26(%rsp)
    23c9:      	movabsq	$0x6620726574657270, %rax # imm = 0x6620726574657270
    23d3:      	movq	%rax, 0x20(%rsp)
    23d8:      	movabsq	$0x7265746e69206562, %rax # imm = 0x7265746E69206562
    23e2:      	movq	%rax, 0x18(%rsp)
    23e7:      	movabsq	$0x206f742079617761, %rax # imm = 0x206F742079617761
    23f1:      	movq	%rax, 0x10(%rsp)
    23f6:      	movabsq	$0x20726166206f6f74, %rax # imm = 0x20726166206F6F74
    2400:      	movq	%rax, 0x8(%rsp)
    2405:      	movabsq	$0x207066203a6d766a, %rax # imm = 0x207066203A6D766A
    240f:      	movq	%rax, (%rsp)
    2413:      	movq	%rsp, %rdi
    2416:      	movl	$0x2e, %eax
    241b:      	movl	$0x6, %ecx
    2420:      	movl	$0x2e, %esi
    2425:      	xorl	%eax, %eax
    2427:      	callq	*%rcx
    2429:      	jmp	0xe50 <perf_unwind_hotspot+0xe50>
    242e:      	movabsq	$0xa2963702b7066, %rax  # imm = 0xA2963702B7066
    2438:      	movq	%rax, 0x65(%rsp)
    243d:      	movabsq	$0x2b70662820656d61, %rax # imm = 0x2B70662820656D61
    2447:      	movq	%rax, 0x60(%rsp)
    244c:      	movabsq	$0x7266206574656c70, %rax # imm = 0x7266206574656C70
    2456:      	movq	%rax, 0x58(%rsp)
    245b:      	movabsq	$0x6d6f636e6920676e, %rax # imm = 0x6D6F636E6920676E
    2465:      	movq	%rax, 0x50(%rsp)
    246a:      	movabsq	$0x69646e69776e7520, %rax # imm = 0x69646E69776E7520
    2474:      	movq	%rax, 0x48(%rsp)
    2479:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    2483:      	movq	%rax, 0x40(%rsp)
    2488:      	leaq	0x40(%rsp), %rdi
    248d:      	movl	$0x2d, %eax
    2492:      	movl	$0x6, %ecx
    2497:      	movl	$0x2d, %esi
    249c:      	xorl	%eax, %eax
    249e:      	callq	*%rcx
    24a0:      	jmp	0xe93 <perf_unwind_hotspot+0xe93>
    24a5:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    24af:      	movq	%rax, 0x55(%rsp)
    24b4:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    24be:      	movq	%rax, 0x50(%rsp)
    24c3:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    24cd:      	movq	%rax, 0x48(%rsp)
    24d2:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    24dc:      	movq	%rax, 0x40(%rsp)
    24e1:      	leaq	0x40(%rsp), %rdi
    24e6:      	movl	$0x1d, %eax
    24eb:      	movl	$0x6, %r8d
    24f1:      	movzbl	(%rsp), %ecx
    24f5:      	movl	$0x1d, %esi
    24fa:      	movq	%rbx, %rdx
    24fd:      	xorl	%eax, %eax
    24ff:      	callq	*%r8
    2502:      	movzbl	(%rsp), %eax
    2506:      	leal	0x1(%rax), %ecx
    2509:      	cmpb	$0x2, %cl
    250c:      	jb	0x290 <perf_unwind_hotspot+0x290>
    2512:      	jmp	0xc15 <perf_unwind_hotspot+0xc15>
    2517:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    2521:      	movq	%rax, 0x18(%rsp)
    2526:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    2530:      	movq	%rax, 0x10(%rsp)
    2535:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    253f:      	movq	%rax, 0x8(%rsp)
    2544:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    254e:      	movq	%rax, (%rsp)
    2552:      	movw	$0xa, 0x20(%rsp)
    2559:      	movq	%rsp, %rdi
    255c:      	movl	$0x22, %eax
    2561:      	movl	$0x6, %r8d
    2567:      	movq	0x40(%rsp), %rcx
    256c:      	movl	$0x22, %esi
    2571:      	xorl	%edx, %edx
    2573:      	xorl	%eax, %eax
    2575:      	callq	*%r8
    2578:      	jmp	0x10a7 <perf_unwind_hotspot+0x10a7>
    257d:      	movabsq	$0xa29646c252065, %rax  # imm = 0xA29646C252065
    2587:      	movq	%rax, 0x67(%rsp)
    258c:      	movabsq	$0x657a697320656d61, %rax # imm = 0x657A697320656D61
    2596:      	movq	%rax, 0x60(%rsp)
    259b:      	movabsq	$0x726628207265746e, %rax # imm = 0x726628207265746E
    25a5:      	movq	%rax, 0x58(%rsp)
    25aa:      	movabsq	$0x696f7020656d6172, %rax # imm = 0x696F7020656D6172
    25b4:      	movq	%rax, 0x50(%rsp)
    25b9:      	movabsq	$0x6620676e69737520, %rax # imm = 0x6620676E69737520
    25c3:      	movq	%rax, 0x48(%rsp)
    25c8:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    25d2:      	movq	%rax, 0x40(%rsp)
    25d7:      	leaq	0x40(%rsp), %rdi
    25dc:      	movl	$0x2f, %eax
    25e1:      	movl	$0x6, %ecx
    25e6:      	movl	$0x2f, %esi
    25eb:      	xorl	%eax, %eax
    25ed:      	callq	*%rcx
    25ef:      	jmp	0x97a <perf_unwind_hotspot+0x97a>
    25f4:      	movabsq	$0xa7364726f7720, %rax  # imm = 0xA7364726F7720
    25fe:      	movq	%rax, 0x26(%rsp)
    2603:      	movabsq	$0x77206425202b2065, %rax # imm = 0x77206425202B2065
    260d:      	movq	%rax, 0x20(%rsp)
    2612:      	movabsq	$0x6d61726620657465, %rax # imm = 0x6D61726620657465
    261c:      	movq	%rax, 0x18(%rsp)
    2621:      	movabsq	$0x6c706d6f6320676e, %rax # imm = 0x6C706D6F6320676E
    262b:      	movq	%rax, 0x10(%rsp)
    2630:      	movabsq	$0x69646e69776e7520, %rax # imm = 0x69646E69776E7520
    263a:      	movq	%rax, 0x8(%rsp)
    263f:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    2649:      	movq	%rax, (%rsp)
    264d:      	movq	%rsp, %rdi
    2650:      	movl	$0x2e, %eax
    2655:      	movl	$0x6, %ecx
    265a:      	xorl	%ebx, %ebx
    265c:      	movl	$0x2e, %esi
    2661:      	xorl	%eax, %eax
    2663:      	callq	*%rcx
    2665:      	jmp	0x16b2 <perf_unwind_hotspot+0x16b2>
    266a:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2674:      	movq	%rax, 0x26(%rsp)
    2679:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2683:      	movq	%rax, 0x20(%rsp)
    2688:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2692:      	movq	%rax, 0x18(%rsp)
    2697:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    26a1:      	movq	%rax, 0x10(%rsp)
    26a6:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    26b0:      	movq	%rax, 0x8(%rsp)
    26b5:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    26bf:      	movq	%rax, (%rsp)
    26c3:      	movq	%rsp, %rdi
    26c6:      	movl	$0x2e, %eax
    26cb:      	movl	$0x6, %ecx
    26d0:      	movl	0x114(%rsp), %edx
    26d7:      	movl	$0x2e, %esi
    26dc:      	xorl	%eax, %eax
    26de:      	callq	*%rcx
    26e0:      	jmp	0x11c7 <perf_unwind_hotspot+0x11c7>
    26e5:      	movabsq	$0xa676e69726f6e, %rax  # imm = 0xA676E69726F6E
    26ef:      	movq	%rax, 0x56(%rsp)
    26f4:      	movabsq	$0x6f6e6769202c786c, %rax # imm = 0x6F6E6769202C786C
    26fe:      	movq	%rax, 0x50(%rsp)
    2703:      	movabsq	$0x252065756c617620, %rax # imm = 0x252065756C617620
    270d:      	movq	%rax, 0x48(%rsp)
    2712:      	movabsq	$0x6370206c6c616d73, %rax # imm = 0x6370206C6C616D73
    271c:      	movq	%rax, 0x40(%rsp)
    2721:      	leaq	0x40(%rsp), %rdi
    2726:      	movl	$0x1e, %eax
    272b:      	movl	$0x6, %ecx
    2730:      	movl	$0x1e, %esi
    2735:      	movq	%rbx, %rdx
    2738:      	xorl	%eax, %eax
    273a:      	callq	*%rcx
    273c:      	jmp	0x1fb2 <perf_unwind_hotspot+0x1fb2>
    2741:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    274b:      	movq	%rax, 0x18(%rsp)
    2750:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    275a:      	movq	%rax, 0x10(%rsp)
    275f:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    2769:      	movq	%rax, 0x8(%rsp)
    276e:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    2778:      	movq	%rax, (%rsp)
    277c:      	movw	$0xa, 0x20(%rsp)
    2783:      	movq	%rsp, %rdi
    2786:      	movl	$0x22, %eax
    278b:      	movl	$0x6, %r8d
    2791:      	movq	0x48(%rsp), %rcx
    2796:      	movl	$0x22, %esi
    279b:      	movl	$0x1, %edx
    27a0:      	xorl	%eax, %eax
    27a2:      	callq	*%r8
    27a5:      	jmp	0x1112 <perf_unwind_hotspot+0x1112>
    27aa:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    27b4:      	movq	%rax, 0x18(%rsp)
    27b9:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    27c3:      	movq	%rax, 0x10(%rsp)
    27c8:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    27d2:      	movq	%rax, 0x8(%rsp)
    27d7:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    27e1:      	movq	%rax, (%rsp)
    27e5:      	movw	$0xa, 0x20(%rsp)
    27ec:      	movq	%rsp, %rdi
    27ef:      	movl	$0x22, %eax
    27f4:      	movl	$0x6, %r8d
    27fa:      	movq	0x50(%rsp), %rcx
    27ff:      	movl	$0x22, %esi
    2804:      	movl	$0x2, %edx
    2809:      	xorl	%eax, %eax
    280b:      	callq	*%r8
    280e:      	jmp	0x12f2 <perf_unwind_hotspot+0x12f2>
    2813:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    281d:      	movq	%rax, 0x68(%rsp)
    2822:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    282c:      	movq	%rax, 0x60(%rsp)
    2831:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    283b:      	movq	%rax, 0x58(%rsp)
    2840:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    284a:      	movq	%rax, 0x50(%rsp)
    284f:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    2859:      	movq	%rax, 0x48(%rsp)
    285e:      	movabsq	$0x6365732074786554, %r13 # imm = 0x6365732074786554
    2868:      	movq	%r13, 0x40(%rsp)
    286d:      	movw	$0xa, 0x70(%rsp)
    2874:      	leaq	0x40(%rsp), %rdi
    2879:      	movl	$0x32, %eax
    287e:      	movl	$0x6, %r9d
    2884:      	movq	0xf10(%r14), %rcx
    288b:      	movl	$0x32, %esi
    2890:      	movq	%rbx, %rdx
    2893:      	movl	%r12d, %r8d
    2896:      	xorl	%eax, %eax
    2898:      	callq	*%r9
    289b:      	movq	(%rip), %rax            # 0x28a2 <perf_unwind_hotspot+0x28a2>
    28a2:      	cmpl	$0x0, (%rax)
    28a5:      	je	0x2050 <perf_unwind_hotspot+0x2050>
    28ab:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    28b5:      	movq	%rax, 0x67(%rsp)
    28ba:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    28c4:      	movq	%rax, 0x60(%rsp)
    28c9:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    28d3:      	movq	%rax, 0x58(%rsp)
    28d8:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    28e2:      	movq	%rax, 0x50(%rsp)
    28e7:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    28f1:      	movq	%rax, 0x48(%rsp)
    28f6:      	movq	%r13, 0x40(%rsp)
    28fb:      	leaq	0x40(%rsp), %rdi
    2900:      	movl	$0x2f, %eax
    2905:      	movl	$0x6, %r8d
    290b:      	movq	0xf18(%r14), %rcx
    2912:      	movq	0xf20(%r14), %rdx
    2919:      	movl	$0x2f, %esi
    291e:      	xorl	%eax, %eax
    2920:      	callq	*%r8
    2923:      	jmp	0x2050 <perf_unwind_hotspot+0x2050>
    2928:      	movabsq	$0xa2964252b7073, %rax  # imm = 0xA2964252B7073
    2932:      	movq	%rax, 0x78(%rsp)
    2937:      	movabsq	$0x206d6f7266282078, %rax # imm = 0x206D6F7266282078
    2941:      	movq	%rax, 0x70(%rsp)
    2946:      	movabsq	$0x6c25783020736120, %rax # imm = 0x6C25783020736120
    2950:      	movq	%rax, 0x68(%rsp)
    2955:      	movabsq	$0x64657265766f6365, %rax # imm = 0x64657265766F6365
    295f:      	movq	%rax, 0x60(%rsp)
    2964:      	movabsq	$0x72206370202c656d, %rax # imm = 0x72206370202C656D
    296e:      	movq	%rax, 0x58(%rsp)
    2973:      	movabsq	$0x6172662064657a69, %rax # imm = 0x6172662064657A69
    297d:      	movq	%rax, 0x50(%rsp)
    2982:      	movabsq	$0x6d6974706f656420, %rax # imm = 0x6D6974706F656420
    298c:      	movq	%rax, 0x48(%rsp)
    2991:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    299b:      	movq	%rax, 0x40(%rsp)
    29a0:      	leaq	0x40(%rsp), %rdi
    29a5:      	movl	$0x40, %eax
    29aa:      	movl	$0x6, %r8d
    29b0:      	movq	(%rsp), %rdx
    29b4:      	movl	0xec(%rsp), %ecx
    29bb:      	movl	$0x40, %esi
    29c0:      	xorl	%eax, %eax
    29c2:      	callq	*%r8
    29c5:      	movq	(%rsp), %rax
    29c9:      	movq	0xd0(%rsp), %rcx
    29d1:      	jmp	0x11a3 <perf_unwind_hotspot+0x11a3>
    29d6:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    29e0:      	movq	%rax, 0x18(%rsp)
    29e5:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    29ef:      	movq	%rax, 0x10(%rsp)
    29f4:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    29fe:      	movq	%rax, 0x8(%rsp)
    2a03:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    2a0d:      	movq	%rax, (%rsp)
    2a11:      	movw	$0xa, 0x20(%rsp)
    2a18:      	movq	%rsp, %rdi
    2a1b:      	movl	$0x22, %eax
    2a20:      	movl	$0x6, %r8d
    2a26:      	movq	0x58(%rsp), %rcx
    2a2b:      	movl	$0x22, %esi
    2a30:      	movl	$0x3, %edx
    2a35:      	xorl	%eax, %eax
    2a37:      	callq	*%r8
    2a3a:      	jmp	0x13f5 <perf_unwind_hotspot+0x13f5>
    2a3f:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    2a49:      	movq	%rax, 0x18(%rsp)
    2a4e:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    2a58:      	movq	%rax, 0x10(%rsp)
    2a5d:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    2a67:      	movq	%rax, 0x8(%rsp)
    2a6c:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    2a76:      	movq	%rax, (%rsp)
    2a7a:      	movw	$0xa, 0x20(%rsp)
    2a81:      	movq	%rsp, %rdi
    2a84:      	movl	$0x22, %eax
    2a89:      	movl	$0x6, %r8d
    2a8f:      	movq	0x60(%rsp), %rcx
    2a94:      	movl	$0x22, %esi
    2a99:      	movl	$0x4, %edx
    2a9e:      	xorl	%eax, %eax
    2aa0:      	callq	*%r8
    2aa3:      	jmp	0x1491 <perf_unwind_hotspot+0x1491>
    2aa8:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    2ab2:      	movq	%rax, 0x55(%rsp)
    2ab7:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    2ac1:      	movq	%rax, 0x50(%rsp)
    2ac6:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    2ad0:      	movq	%rax, 0x48(%rsp)
    2ad5:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    2adf:      	movq	%rax, 0x40(%rsp)
    2ae4:      	leaq	0x40(%rsp), %rdi
    2ae9:      	movl	$0x1d, %eax
    2aee:      	movl	$0x6, %r8d
    2af4:      	movzbl	(%rsp), %ecx
    2af8:      	movl	$0x1d, %esi
    2afd:      	movq	%rbx, %rdx
    2b00:      	xorl	%eax, %eax
    2b02:      	callq	*%r8
    2b05:      	movzbl	(%rsp), %eax
    2b09:      	leal	0x1(%rax), %ecx
    2b0c:      	cmpb	$0x2, %cl
    2b0f:      	jb	0x290 <perf_unwind_hotspot+0x290>
    2b15:      	jmp	0xc5c <perf_unwind_hotspot+0xc5c>
    2b1a:      	movabsq	$0x657227206e6f2065, %rax # imm = 0x657227206E6F2065
    2b24:      	movq	%rax, 0x50(%rsp)
    2b29:      	movabsq	$0x75676f6c69706520, %rax # imm = 0x75676F6C69706520
    2b33:      	movq	%rax, 0x48(%rsp)
    2b38:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    2b42:      	movq	%rax, 0x40(%rsp)
    2b47:      	movl	$0xa2774, 0x58(%rsp)    # imm = 0xA2774
    2b4f:      	leaq	0x40(%rsp), %rdi
    2b54:      	movl	$0x1c, %eax
    2b59:      	movl	$0x6, %ecx
    2b5e:      	movl	$0x1c, %esi
    2b63:      	xorl	%eax, %eax
    2b65:      	callq	*%rcx
    2b67:      	jmp	0x1473 <perf_unwind_hotspot+0x1473>
    2b6c:      	movabsq	$0xa786c25203d20, %rax  # imm = 0xA786C25203D20
    2b76:      	movq	%rax, 0x2d(%rsp)
    2b7b:      	movabsq	$0x203d20706362202c, %rax # imm = 0x203D20706362202C
    2b85:      	movq	%rax, 0x28(%rsp)
    2b8a:      	movabsq	$0x786c257830203d20, %rax # imm = 0x786C257830203D20
    2b94:      	movq	%rax, 0x20(%rsp)
    2b99:      	movabsq	$0x646f6874656d6320, %rax # imm = 0x646F6874656D6320
    2ba3:      	movq	%rax, 0x18(%rsp)
    2ba8:      	movabsq	$0x2c786c257830203d, %rax # imm = 0x2C786C257830203D
    2bb2:      	movq	%rax, 0x10(%rsp)
    2bb7:      	movabsq	$0x20646f6874656d20, %rax # imm = 0x20646F6874656D20
    2bc1:      	movq	%rax, 0x8(%rsp)
    2bc6:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    2bd0:      	movq	%rax, (%rsp)
    2bd4:      	movq	%rsp, %rdi
    2bd7:      	movl	$0x35, %eax
    2bdc:      	movl	$0x6, %r9d
    2be2:      	movq	0x100(%rsp), %rcx
    2bea:      	movl	$0x35, %esi
    2bef:      	movq	0x118(%rsp), %rdx
    2bf7:      	movq	0xb0(%rsp), %r8
    2bff:      	xorl	%eax, %eax
    2c01:      	callq	*%r9
    2c04:      	movq	0x100(%rsp), %rbp
    2c0c:      	jmp	0x18c2 <perf_unwind_hotspot+0x18c2>
    2c11:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    2c1b:      	movq	%rax, 0x18(%rsp)
    2c20:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    2c2a:      	movq	%rax, 0x10(%rsp)
    2c2f:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    2c39:      	movq	%rax, 0x8(%rsp)
    2c3e:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    2c48:      	movq	%rax, (%rsp)
    2c4c:      	movw	$0xa, 0x20(%rsp)
    2c53:      	movq	%rsp, %rdi
    2c56:      	movl	$0x22, %eax
    2c5b:      	movl	$0x6, %r8d
    2c61:      	movq	0x68(%rsp), %rcx
    2c66:      	movl	$0x22, %esi
    2c6b:      	movl	$0x5, %edx
    2c70:      	xorl	%eax, %eax
    2c72:      	callq	*%r8
    2c75:      	jmp	0x1637 <perf_unwind_hotspot+0x1637>
    2c7a:      	movabsq	$0xa642520686374, %rax  # imm = 0xA642520686374
    2c84:      	movq	%rax, 0x56(%rsp)
    2c89:      	movabsq	$0x6374616d20737465, %rax # imm = 0x6374616D20737465
    2c93:      	movq	%rax, 0x50(%rsp)
    2c98:      	movabsq	$0x7366666f5f726574, %rax # imm = 0x7366666F5F726574
    2ca2:      	movq	%rax, 0x48(%rsp)
    2ca7:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    2cb1:      	movq	%rax, 0x40(%rsp)
    2cb6:      	leaq	0x40(%rsp), %rdi
    2cbb:      	movl	$0x1e, %eax
    2cc0:      	movl	$0x6, %ecx
    2cc5:      	movzwl	0x20(%rbx), %edx
    2cc9:      	movl	$0x1e, %esi
    2cce:      	xorl	%eax, %eax
    2cd0:      	callq	*%rcx
    2cd2:      	movl	0x1380(%r14), %eax
    2cd9:      	movl	0x20(%rbx), %ecx
    2cdc:      	btl	%ecx, %eax
    2cdf:      	jb	0x20da <perf_unwind_hotspot+0x20da>
    2ce5:      	movl	$0x0, (%rsp)
    2cec:      	movq	(%rip), %rdi            # 0x2cf3 <perf_unwind_hotspot+0x2cf3>
    2cf3:      	movq	%rsp, %rsi
    2cf6:      	movl	$0x1, %eax
    2cfb:      	callq	*%rax
    2cfd:      	testq	%rax, %rax
    2d00:      	je	0x2d07 <perf_unwind_hotspot+0x2d07>
    2d02:      	incq	(%rax)
    2d05:      	jmp	0x2d17 <perf_unwind_hotspot+0x2d17>
    2d07:      	movq	(%rip), %rax            # 0x2d0e <perf_unwind_hotspot+0x2d0e>
    2d0e:      	cmpl	$0x0, (%rax)
    2d11:      	jne	0x3f70 <perf_unwind_hotspot+0x3f70>
    2d17:      	movzwl	0x20(%rbx), %r12d
    2d1c:      	xorl	%ebp, %ebp
    2d1e:      	cmpl	$0x2, %r12d
    2d22:      	jne	0x34c <perf_unwind_hotspot+0x34c>
    2d28:      	movl	$0x29, 0xc8(%rsp)
    2d33:      	movq	(%rip), %rdi            # 0x2d3a <perf_unwind_hotspot+0x2d3a>
    2d3a:      	leaq	0xc8(%rsp), %rsi
    2d42:      	movl	$0x1, %eax
    2d47:      	callq	*%rax
    2d49:      	testq	%rax, %rax
    2d4c:      	je	0x2e0b <perf_unwind_hotspot+0x2e0b>
    2d52:      	incq	(%rax)
    2d55:      	movq	(%rip), %rax            # 0x2d5c <perf_unwind_hotspot+0x2d5c>
    2d5c:      	cmpl	$0x0, (%rax)
    2d5f:      	movq	0xed0(%r14), %r12
    2d66:      	movq	0xed8(%r14), %rax
    2d6d:      	movq	%rax, 0x38(%rsp)
    2d72:      	movq	0xee0(%r14), %rax
    2d79:      	movq	%rax, 0xa8(%rsp)
    2d81:      	je	0x2e3d <perf_unwind_hotspot+0x2e3d>
    2d87:      	movabsq	$0x252074657366666f, %rax # imm = 0x252074657366666F
    2d91:      	movq	%rax, 0x60(%rsp)
    2d96:      	movabsq	$0x202c786c25207472, %rax # imm = 0x202C786C25207472
    2da0:      	movq	%rax, 0x58(%rsp)
    2da5:      	movabsq	$0x6174732065646f63, %rax # imm = 0x6174732065646F63
    2daf:      	movq	%rax, 0x50(%rsp)
    2db4:      	movabsq	$0x206e6920786c2520, %rax # imm = 0x206E6920786C2520
    2dbe:      	movq	%rax, 0x48(%rsp)
    2dc3:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    2dcd:      	movq	%rax, 0x40(%rsp)
    2dd2:      	movl	$0xa786c, 0x68(%rsp)    # imm = 0xA786C
    2dda:      	leaq	0x40(%rsp), %rdi
    2ddf:      	movl	$0x2c, %eax
    2de4:      	movl	$0x6, %r9d
    2dea:      	movq	0xf20(%r14), %rcx
    2df1:      	movq	0xed0(%r14), %rdx
    2df8:      	movq	0xf18(%r14), %r8
    2dff:      	movl	$0x2c, %esi
    2e04:      	xorl	%eax, %eax
    2e06:      	callq	*%r9
    2e09:      	jmp	0x2e3d <perf_unwind_hotspot+0x2e3d>
    2e0b:      	movq	(%rip), %rax            # 0x2e12 <perf_unwind_hotspot+0x2e12>
    2e12:      	cmpl	$0x0, (%rax)
    2e15:      	jne	0x3369 <perf_unwind_hotspot+0x3369>
    2e1b:      	movq	0xed0(%r14), %r12
    2e22:      	movq	0xed8(%r14), %rax
    2e29:      	movq	%rax, 0x38(%rsp)
    2e2e:      	movq	0xee0(%r14), %rax
    2e35:      	movq	%rax, 0xa8(%rsp)
    2e3d:      	movzbl	0x20(%r15), %eax
    2e42:      	shrxq	%rax, 0xf18(%r14), %r13
    2e4b:      	movq	0xf10(%r14), %rbx
    2e52:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    2e5c:      	andq	%rax, %rbx
    2e5f:      	leaq	(%rbx,%r13), %rdx
    2e63:      	movq	%rsp, %rdi
    2e66:      	movl	$0x1, %eax
    2e6b:      	movl	$0x70, %ecx
    2e70:      	movl	$0x1, %esi
    2e75:      	callq	*%rcx
    2e77:      	testq	%rax, %rax
    2e7a:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    2e80:      	movq	(%rip), %rax            # 0x2e87 <perf_unwind_hotspot+0x2e87>
    2e87:      	cmpl	$0x0, (%rax)
    2e8a:      	jne	0x33e7 <perf_unwind_hotspot+0x33e7>
    2e90:      	movzbl	(%rsp), %eax
    2e94:      	leal	0x1(%rax), %ecx
    2e97:      	cmpb	$0x2, %cl
    2e9a:      	jae	0x3454 <perf_unwind_hotspot+0x3454>
    2ea0:      	testb	%al, %al
    2ea2:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    2ea8:      	movzbl	0x20(%r15), %eax
    2ead:      	shlxq	%rax, %r13, %rax
    2eb2:      	addq	0xf20(%r14), %rax
    2eb9:      	movzbl	0x1b(%r15), %ebx
    2ebe:      	addq	%rax, %rbx
    2ec1:      	movq	(%rip), %rax            # 0x2ec8 <perf_unwind_hotspot+0x2ec8>
    2ec8:      	cmpl	$0x0, (%rax)
    2ecb:      	jne	0x3d9f <perf_unwind_hotspot+0x3d9f>
    2ed1:      	movq	%rbx, 0xc8(%rsp)
    2ed9:      	testq	%rbx, %rbx
    2edc:      	je	0x237 <perf_unwind_hotspot+0x237>
    2ee2:      	movl	$0x200, %eax            # imm = 0x200
    2ee7:      	movl	$0x70, %ecx
    2eec:      	movq	0x120(%rsp), %rdi
    2ef4:      	movq	0xc8(%rsp), %rdx
    2efc:      	movl	$0x200, %esi            # imm = 0x200
    2f01:      	callq	*%rcx
    2f03:      	testq	%rax, %rax
    2f06:      	jne	0x300 <perf_unwind_hotspot+0x300>
    2f0c:      	movzwl	0x10(%r15), %eax
    2f11:      	movl	$0x1, %ebx
    2f16:      	cmpq	$0x1f8, %rax            # imm = 0x1F8
    2f1c:      	ja	0x347 <perf_unwind_hotspot+0x347>
    2f22:      	movzwl	0x12(%r15), %ecx
    2f27:      	cmpq	$0x1fc, %rcx            # imm = 0x1FC
    2f2e:      	ja	0x347 <perf_unwind_hotspot+0x347>
    2f34:      	movzwl	0x14(%r15), %edx
    2f39:      	cmpq	$0x1f8, %rdx            # imm = 0x1F8
    2f40:      	ja	0x347 <perf_unwind_hotspot+0x347>
    2f46:      	movzbl	0x17(%r15), %esi
    2f4b:      	movq	0x120(%rsp), %rdi
    2f53:      	movq	(%rdi,%rsi), %rsi
    2f57:      	movq	%rsi, 0xd0(%rsp)
    2f5f:      	movzbl	0x18(%r15), %esi
    2f64:      	movq	(%rdi,%rsi), %rsi
    2f68:      	movq	%rsi, 0xd8(%rsp)
    2f70:      	movzbl	0x1a(%r15), %esi
    2f75:      	movl	(%rdi,%rsi), %esi
    2f78:      	shll	$0x3, %esi
    2f7b:      	movl	%esi, 0xf0(%rsp)
    2f82:      	movzbl	0x19(%r15), %esi
    2f87:      	movzwl	(%rdi,%rsi), %esi
    2f8b:      	movw	%si, 0xf8(%rsp)
    2f93:      	movl	(%rdi,%rcx), %ecx
    2f96:      	movl	%ecx, 0xf4(%rsp)
    2f9d:      	movl	(%rdi,%rdx), %ecx
    2fa0:      	movl	%ecx, 0xec(%rsp)
    2fa7:      	movq	(%rdi,%rax), %rax
    2fab:      	movq	%rax, 0xe0(%rsp)
    2fb3:      	movzbl	0x16(%r15), %eax
    2fb8:      	movq	(%rdi,%rax), %rdx
    2fbc:      	movl	$0x4, %eax
    2fc1:      	movl	$0x70, %ecx
    2fc6:      	leaq	0xe8(%rsp), %rdi
    2fce:      	movl	$0x4, %esi
    2fd3:      	callq	*%rcx
    2fd5:      	testq	%rax, %rax
    2fd8:      	jne	0x300 <perf_unwind_hotspot+0x300>
    2fde:      	cmpb	$0x0, 0x21(%r15)
    2fe3:      	je	0x3011 <perf_unwind_hotspot+0x3011>
    2fe5:      	movq	0xc8(%rsp), %rax
    2fed:      	movl	0xd0(%rsp), %ecx
    2ff4:      	addq	%rax, %rcx
    2ff7:      	movq	%rcx, 0xd0(%rsp)
    2fff:      	movl	0xd8(%rsp), %ecx
    3006:      	addq	%rax, %rcx
    3009:      	movq	%rcx, 0xd8(%rsp)
    3011:      	movq	(%rip), %rax            # 0x3018 <perf_unwind_hotspot+0x3018>
    3018:      	cmpl	$0x0, (%rax)
    301b:      	jne	0x44d7 <perf_unwind_hotspot+0x44d7>
    3021:      	movq	0xc8(%rsp), %rax
    3029:      	movq	%rax, 0xc0(%rsp)
    3031:      	movq	0xd0(%rsp), %rax
    3039:      	movl	0xe8(%rsp), %edx
    3040:      	movl	%r12d, %ecx
    3043:      	subl	%eax, %ecx
    3045:      	movq	%rcx, 0x118(%rsp)
    304d:      	movq	%rdx, 0xb8(%rsp)
    3055:      	cmpl	$0x6974616d, %edx       # imm = 0x6974616D
    305b:      	jg	0x314b <perf_unwind_hotspot+0x314b>
    3061:      	cmpl	$0x62617476, 0xb8(%rsp) # imm = 0x62617476
    306c:      	je	0x328e <perf_unwind_hotspot+0x328e>
    3072:      	cmpl	$0x65746e49, 0xb8(%rsp) # imm = 0x65746E49
    307d:      	jne	0x32c9 <perf_unwind_hotspot+0x32c9>
    3083:      	movq	0x38(%rsp), %rax
    3088:      	cmpq	%rax, 0xa8(%rsp)
    3090:      	jb	0x3768 <perf_unwind_hotspot+0x3768>
    3096:      	movq	0x38(%rsp), %rax
    309b:      	addq	$0x1000, %rax           # imm = 0x1000
    30a1:      	cmpq	%rax, 0xa8(%rsp)
    30a9:      	jae	0x3768 <perf_unwind_hotspot+0x3768>
    30af:      	movq	0xa8(%rsp), %rax
    30b7:      	leaq	-0x50(%rax), %rdx
    30bb:      	leaq	0x40(%rsp), %rdi
    30c0:      	movl	$0x60, %eax
    30c5:      	movl	$0x70, %ecx
    30ca:      	movl	$0x60, %esi
    30cf:      	callq	*%rcx
    30d1:      	testq	%rax, %rax
    30d4:      	je	0x3e11 <perf_unwind_hotspot+0x3e11>
    30da:      	movq	(%rip), %rax            # 0x30e1 <perf_unwind_hotspot+0x30e1>
    30e1:      	cmpl	$0x0, (%rax)
    30e4:      	je	0x3778 <perf_unwind_hotspot+0x3778>
    30ea:      	movabsq	$0xa656d61726620, %rax  # imm = 0xA656D61726620
    30f4:      	movq	%rax, 0x1f(%rsp)
    30f9:      	movabsq	$0x2072657465727072, %rax # imm = 0x2072657465727072
    3103:      	movq	%rax, 0x18(%rsp)
    3108:      	movabsq	$0x65746e6920646165, %rax # imm = 0x65746E6920646165
    3112:      	movq	%rax, 0x10(%rsp)
    3117:      	movabsq	$0x72206f742064656c, %rax # imm = 0x72206F742064656C
    3121:      	movq	%rax, 0x8(%rsp)
    3126:      	movabsq	$0x696166203a6d766a, %rax # imm = 0x696166203A6D766A
    3130:      	movq	%rax, (%rsp)
    3134:      	movq	%rsp, %rdi
    3137:      	movl	$0x27, %eax
    313c:      	movl	$0x6, %ecx
    3141:      	movl	$0x27, %esi
    3146:      	jmp	0x4a9f <perf_unwind_hotspot+0x4a9f>
    314b:      	cmpl	$0x6974616e, 0xb8(%rsp) # imm = 0x6974616E
    3156:      	je	0x3169 <perf_unwind_hotspot+0x3169>
    3158:      	cmpl	$0x74656d6e, 0xb8(%rsp) # imm = 0x74656D6E
    3163:      	jne	0x32c9 <perf_unwind_hotspot+0x32c9>
    3169:      	movl	0xf4(%rsp), %ecx
    3170:      	movq	%rcx, 0xb8(%rsp)
    3178:      	movq	0xe0(%rsp), %rcx
    3180:      	movl	%ecx, %edx
    3182:      	addq	0xc0(%rsp), %rdx
    318a:      	cmpb	$0x0, 0x21(%r15)
    318f:      	cmoveq	%rcx, %rdx
    3193:      	cmpq	%rdx, %r12
    3196:      	jne	0x31e8 <perf_unwind_hotspot+0x31e8>
    3198:      	movl	0xec(%rsp), %eax
    319f:      	movq	0x38(%rsp), %rsi
    31a4:      	addq	%rsi, %rax
    31a7:      	movq	%rsp, %rdi
    31aa:      	movl	$0x8, %ecx
    31af:      	movl	$0x70, %r8d
    31b5:      	movl	0xec(%rsp), %edx
    31bc:      	addq	%rsi, %rdx
    31bf:      	movl	$0x8, %esi
    31c4:      	callq	*%r8
    31c7:      	testq	%rax, %rax
    31ca:      	je	0x3c5c <perf_unwind_hotspot+0x3c5c>
    31d0:      	movq	(%rip), %rax            # 0x31d7 <perf_unwind_hotspot+0x31d7>
    31d7:      	cmpl	$0x0, (%rax)
    31da:      	jne	0x48c4 <perf_unwind_hotspot+0x48c4>
    31e0:      	movq	0xd0(%rsp), %rax
    31e8:      	movzwl	0xf8(%rsp), %ecx
    31f0:      	addq	%rax, %rcx
    31f3:      	cmpq	%rcx, %r12
    31f6:      	jae	0x3300 <perf_unwind_hotspot+0x3300>
    31fc:      	addq	$-0x4, %rcx
    3200:      	movq	(%rip), %rax            # 0x3207 <perf_unwind_hotspot+0x3207>
    3207:      	movl	(%rax), %eax
    3209:      	cmpq	%rcx, %r12
    320c:      	jae	0x37aa <perf_unwind_hotspot+0x37aa>
    3212:      	movb	$0x3, %cl
    3214:      	movl	%ecx, 0xb0(%rsp)
    321b:      	testl	%eax, %eax
    321d:      	je	0x32b4 <perf_unwind_hotspot+0x32b4>
    3223:      	movabsq	$0x2963702820656d61, %rax # imm = 0x2963702820656D61
    322d:      	movq	%rax, 0x60(%rsp)
    3232:      	movabsq	$0x7266206574656c70, %rax # imm = 0x7266206574656C70
    323c:      	movq	%rax, 0x58(%rsp)
    3241:      	movabsq	$0x6d6f636e6920676e, %rax # imm = 0x6D6F636E6920676E
    324b:      	movq	%rax, 0x50(%rsp)
    3250:      	movabsq	$0x69646e69776e7520, %rax # imm = 0x69646E69776E7520
    325a:      	movq	%rax, 0x48(%rsp)
    325f:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    3269:      	movq	%rax, 0x40(%rsp)
    326e:      	movw	$0xa, 0x68(%rsp)
    3275:      	leaq	0x40(%rsp), %rdi
    327a:      	movl	$0x2a, %eax
    327f:      	movl	$0x6, %ecx
    3284:      	movl	$0x2a, %esi
    3289:      	jmp	0x485a <perf_unwind_hotspot+0x485a>
    328e:      	movb	$0x1, %al
    3290:      	movl	%eax, 0xb0(%rsp)
    3297:      	movl	$0x62617476, %eax       # imm = 0x62617476
    329c:      	movq	%rax, 0xb8(%rsp)
    32a4:      	movq	(%rip), %rax            # 0x32ab <perf_unwind_hotspot+0x32ab>
    32ab:      	cmpl	$0x0, (%rax)
    32ae:      	jne	0x4819 <perf_unwind_hotspot+0x4819>
    32b4:      	movl	$0x8, 0xf0(%rsp)
    32bf:      	movl	$0x8, %eax
    32c4:      	jmp	0x37d5 <perf_unwind_hotspot+0x37d5>
    32c9:      	movq	(%rip), %rax            # 0x32d0 <perf_unwind_hotspot+0x32d0>
    32d0:      	cmpl	$0x0, (%rax)
    32d3:      	jne	0x4863 <perf_unwind_hotspot+0x4863>
    32d9:      	movl	0xf0(%rsp), %eax
    32e0:      	movl	$0x0, 0xb0(%rsp)
    32eb:      	movq	0xa8(%rsp), %rcx
    32f3:      	testl	%eax, %eax
    32f5:      	jne	0x37d5 <perf_unwind_hotspot+0x37d5>
    32fb:      	jmp	0x37c0 <perf_unwind_hotspot+0x37c0>
    3300:      	movl	0xf0(%rsp), %ebx
    3307:      	movq	0xa8(%rsp), %rdx
    330f:      	movq	0x38(%rsp), %rax
    3314:      	leaq	(%rax,%rbx), %rcx
    3318:      	addq	$0x30, %rcx
    331c:      	movq	%rcx, 0x108(%rsp)
    3324:      	subq	%rax, %rdx
    3327:      	jb	0x3ad1 <perf_unwind_hotspot+0x3ad1>
    332d:      	movq	0x108(%rsp), %rax
    3335:      	cmpq	%rax, 0xa8(%rsp)
    333d:      	jae	0x3ad1 <perf_unwind_hotspot+0x3ad1>
    3343:      	movb	$0x3, %al
    3345:      	movl	%eax, 0xb0(%rsp)
    334c:      	movq	(%rip), %rax            # 0x3353 <perf_unwind_hotspot+0x3353>
    3353:      	cmpl	$0x0, (%rax)
    3356:      	jne	0x49b5 <perf_unwind_hotspot+0x49b5>
    335c:      	movq	0xa8(%rsp), %rcx
    3364:      	jmp	0x37c0 <perf_unwind_hotspot+0x37c0>
    3369:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3373:      	movq	%rax, 0x66(%rsp)
    3378:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    3382:      	movq	%rax, 0x60(%rsp)
    3387:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    3391:      	movq	%rax, 0x58(%rsp)
    3396:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    33a0:      	movq	%rax, 0x50(%rsp)
    33a5:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    33af:      	movq	%rax, 0x48(%rsp)
    33b4:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    33be:      	movq	%rax, 0x40(%rsp)
    33c3:      	leaq	0x40(%rsp), %rdi
    33c8:      	movl	$0x2e, %eax
    33cd:      	movl	$0x6, %ecx
    33d2:      	movl	0xc8(%rsp), %edx
    33d9:      	movl	$0x2e, %esi
    33de:      	xorl	%eax, %eax
    33e0:      	callq	*%rcx
    33e2:      	jmp	0x2d55 <perf_unwind_hotspot+0x2d55>
    33e7:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    33f1:      	movq	%rax, 0x55(%rsp)
    33f6:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    3400:      	movq	%rax, 0x50(%rsp)
    3405:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    340f:      	movq	%rax, 0x48(%rsp)
    3414:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    341e:      	movq	%rax, 0x40(%rsp)
    3423:      	leaq	0x40(%rsp), %rdi
    3428:      	movl	$0x1d, %eax
    342d:      	movl	$0x6, %r8d
    3433:      	movzbl	(%rsp), %ecx
    3437:      	movl	$0x1d, %esi
    343c:      	movq	%r13, %rdx
    343f:      	xorl	%eax, %eax
    3441:      	callq	*%r8
    3444:      	movzbl	(%rsp), %eax
    3448:      	leal	0x1(%rax), %ecx
    344b:      	cmpb	$0x2, %cl
    344e:      	jb	0x2ea0 <perf_unwind_hotspot+0x2ea0>
    3454:      	movzbl	%al, %eax
    3457:      	subq	%rax, %r13
    345a:      	leaq	(%rbx,%r13), %rdx
    345e:      	movq	%rsp, %rdi
    3461:      	movl	$0x1, %eax
    3466:      	movl	$0x70, %ecx
    346b:      	movl	$0x1, %esi
    3470:      	callq	*%rcx
    3472:      	testq	%rax, %rax
    3475:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    347b:      	movq	(%rip), %rax            # 0x3482 <perf_unwind_hotspot+0x3482>
    3482:      	cmpl	$0x0, (%rax)
    3485:      	jne	0x3e34 <perf_unwind_hotspot+0x3e34>
    348b:      	movzbl	(%rsp), %eax
    348f:      	leal	0x1(%rax), %ecx
    3492:      	cmpb	$0x2, %cl
    3495:      	jb	0x2ea0 <perf_unwind_hotspot+0x2ea0>
    349b:      	movzbl	%al, %eax
    349e:      	subq	%rax, %r13
    34a1:      	leaq	(%rbx,%r13), %rdx
    34a5:      	movq	%rsp, %rdi
    34a8:      	movl	$0x1, %eax
    34ad:      	movl	$0x70, %ecx
    34b2:      	movl	$0x1, %esi
    34b7:      	callq	*%rcx
    34b9:      	testq	%rax, %rax
    34bc:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    34c2:      	movq	(%rip), %rax            # 0x34c9 <perf_unwind_hotspot+0x34c9>
    34c9:      	cmpl	$0x0, (%rax)
    34cc:      	jne	0x42f2 <perf_unwind_hotspot+0x42f2>
    34d2:      	movzbl	(%rsp), %eax
    34d6:      	leal	0x1(%rax), %ecx
    34d9:      	cmpb	$0x2, %cl
    34dc:      	jb	0x2ea0 <perf_unwind_hotspot+0x2ea0>
    34e2:      	movzbl	%al, %eax
    34e5:      	subq	%rax, %r13
    34e8:      	leaq	(%rbx,%r13), %rdx
    34ec:      	movq	%rsp, %rdi
    34ef:      	movl	$0x1, %eax
    34f4:      	movl	$0x70, %ecx
    34f9:      	movl	$0x1, %esi
    34fe:      	callq	*%rcx
    3500:      	testq	%rax, %rax
    3503:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    3509:      	movq	(%rip), %rax            # 0x3510 <perf_unwind_hotspot+0x3510>
    3510:      	cmpl	$0x0, (%rax)
    3513:      	jne	0x43f3 <perf_unwind_hotspot+0x43f3>
    3519:      	movzbl	(%rsp), %eax
    351d:      	leal	0x1(%rax), %ecx
    3520:      	cmpb	$0x2, %cl
    3523:      	jb	0x2ea0 <perf_unwind_hotspot+0x2ea0>
    3529:      	movzbl	%al, %eax
    352c:      	subq	%rax, %r13
    352f:      	leaq	(%rbx,%r13), %rdx
    3533:      	movq	%rsp, %rdi
    3536:      	movl	$0x1, %eax
    353b:      	movl	$0x70, %ecx
    3540:      	movl	$0x1, %esi
    3545:      	callq	*%rcx
    3547:      	testq	%rax, %rax
    354a:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    3550:      	movq	(%rip), %rax            # 0x3557 <perf_unwind_hotspot+0x3557>
    3557:      	cmpl	$0x0, (%rax)
    355a:      	jne	0x45db <perf_unwind_hotspot+0x45db>
    3560:      	movzbl	(%rsp), %eax
    3564:      	leal	0x1(%rax), %ecx
    3567:      	cmpb	$0x2, %cl
    356a:      	jb	0x2ea0 <perf_unwind_hotspot+0x2ea0>
    3570:      	movzbl	%al, %eax
    3573:      	subq	%rax, %r13
    3576:      	leaq	(%rbx,%r13), %rdx
    357a:      	movq	%rsp, %rdi
    357d:      	movl	$0x1, %eax
    3582:      	movl	$0x70, %ecx
    3587:      	movl	$0x1, %esi
    358c:      	callq	*%rcx
    358e:      	testq	%rax, %rax
    3591:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    3597:      	movq	(%rip), %rax            # 0x359e <perf_unwind_hotspot+0x359e>
    359e:      	cmpl	$0x0, (%rax)
    35a1:      	jne	0x4b85 <perf_unwind_hotspot+0x4b85>
    35a7:      	movzbl	(%rsp), %eax
    35ab:      	leal	0x1(%rax), %ecx
    35ae:      	cmpb	$0x2, %cl
    35b1:      	jb	0x2ea0 <perf_unwind_hotspot+0x2ea0>
    35b7:      	movzbl	%al, %eax
    35ba:      	subq	%rax, %r13
    35bd:      	leaq	(%rbx,%r13), %rdx
    35c1:      	movq	%rsp, %rdi
    35c4:      	movl	$0x1, %eax
    35c9:      	movl	$0x70, %ecx
    35ce:      	movl	$0x1, %esi
    35d3:      	callq	*%rcx
    35d5:      	testq	%rax, %rax
    35d8:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    35de:      	movq	(%rip), %rax            # 0x35e5 <perf_unwind_hotspot+0x35e5>
    35e5:      	cmpl	$0x0, (%rax)
    35e8:      	jne	0x504f <perf_unwind_hotspot+0x504f>
    35ee:      	movzbl	(%rsp), %eax
    35f2:      	leal	0x1(%rax), %ecx
    35f5:      	cmpb	$0x2, %cl
    35f8:      	jb	0x2ea0 <perf_unwind_hotspot+0x2ea0>
    35fe:      	movzbl	%al, %eax
    3601:      	subq	%rax, %r13
    3604:      	leaq	(%rbx,%r13), %rdx
    3608:      	movq	%rsp, %rdi
    360b:      	movl	$0x1, %eax
    3610:      	movl	$0x70, %ecx
    3615:      	movl	$0x1, %esi
    361a:      	callq	*%rcx
    361c:      	testq	%rax, %rax
    361f:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    3625:      	movq	(%rip), %rax            # 0x362c <perf_unwind_hotspot+0x362c>
    362c:      	cmpl	$0x0, (%rax)
    362f:      	jne	0x6022 <perf_unwind_hotspot+0x6022>
    3635:      	movzbl	(%rsp), %eax
    3639:      	leal	0x1(%rax), %ecx
    363c:      	cmpb	$0x2, %cl
    363f:      	jb	0x2ea0 <perf_unwind_hotspot+0x2ea0>
    3645:      	movzbl	%al, %eax
    3648:      	subq	%rax, %r13
    364b:      	leaq	(%rbx,%r13), %rdx
    364f:      	movq	%rsp, %rdi
    3652:      	movl	$0x1, %eax
    3657:      	movl	$0x70, %ecx
    365c:      	movl	$0x1, %esi
    3661:      	callq	*%rcx
    3663:      	testq	%rax, %rax
    3666:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    366c:      	movq	(%rip), %rax            # 0x3673 <perf_unwind_hotspot+0x3673>
    3673:      	cmpl	$0x0, (%rax)
    3676:      	jne	0x6422 <perf_unwind_hotspot+0x6422>
    367c:      	movzbl	(%rsp), %eax
    3680:      	leal	0x1(%rax), %ecx
    3683:      	cmpb	$0x2, %cl
    3686:      	jb	0x2ea0 <perf_unwind_hotspot+0x2ea0>
    368c:      	movzbl	%al, %eax
    368f:      	subq	%rax, %r13
    3692:      	leaq	(%rbx,%r13), %rdx
    3696:      	movq	%rsp, %rdi
    3699:      	movl	$0x1, %eax
    369e:      	movl	$0x70, %ecx
    36a3:      	movl	$0x1, %esi
    36a8:      	callq	*%rcx
    36aa:      	testq	%rax, %rax
    36ad:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    36b3:      	movq	(%rip), %rax            # 0x36ba <perf_unwind_hotspot+0x36ba>
    36ba:      	cmpl	$0x0, (%rax)
    36bd:      	jne	0x67b9 <perf_unwind_hotspot+0x67b9>
    36c3:      	movzbl	(%rsp), %eax
    36c7:      	leal	0x1(%rax), %ecx
    36ca:      	cmpb	$0x2, %cl
    36cd:      	jb	0x2ea0 <perf_unwind_hotspot+0x2ea0>
    36d3:      	movzbl	%al, %eax
    36d6:      	subq	%rax, %r13
    36d9:      	leaq	(%rbx,%r13), %rdx
    36dd:      	movq	%rsp, %rdi
    36e0:      	movl	$0x1, %eax
    36e5:      	movl	$0x70, %ecx
    36ea:      	movl	$0x1, %esi
    36ef:      	callq	*%rcx
    36f1:      	testq	%rax, %rax
    36f4:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    36fa:      	movq	(%rip), %rax            # 0x3701 <perf_unwind_hotspot+0x3701>
    3701:      	cmpl	$0x0, (%rax)
    3704:      	jne	0x689d <perf_unwind_hotspot+0x689d>
    370a:      	movzbl	(%rsp), %eax
    370e:      	leal	0x1(%rax), %ecx
    3711:      	cmpb	$0x2, %cl
    3714:      	jb	0x2ea0 <perf_unwind_hotspot+0x2ea0>
    371a:      	movzbl	%al, %eax
    371d:      	subq	%rax, %r13
    3720:      	addq	%r13, %rbx
    3723:      	movq	%rsp, %rdi
    3726:      	movl	$0x1, %eax
    372b:      	movl	$0x70, %ecx
    3730:      	movl	$0x1, %esi
    3735:      	movq	%rbx, %rdx
    3738:      	callq	*%rcx
    373a:      	testq	%rax, %rax
    373d:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    3743:      	movq	(%rip), %rax            # 0x374a <perf_unwind_hotspot+0x374a>
    374a:      	cmpl	$0x0, (%rax)
    374d:      	jne	0x690f <perf_unwind_hotspot+0x690f>
    3753:      	movzbl	(%rsp), %eax
    3757:      	leal	0x1(%rax), %ecx
    375a:      	cmpb	$0x1, %cl
    375d:      	ja	0x22b <perf_unwind_hotspot+0x22b>
    3763:      	jmp	0x2ea0 <perf_unwind_hotspot+0x2ea0>
    3768:      	movq	(%rip), %rax            # 0x376f <perf_unwind_hotspot+0x376f>
    376f:      	cmpl	$0x0, (%rax)
    3772:      	jne	0x4a34 <perf_unwind_hotspot+0x4a34>
    3778:      	movl	$0x2d, 0x114(%rsp)
    3783:      	movq	(%rip), %rdi            # 0x378a <perf_unwind_hotspot+0x378a>
    378a:      	leaq	0x114(%rsp), %rsi
    3792:      	movl	$0x1, %eax
    3797:      	callq	*%rax
    3799:      	testq	%rax, %rax
    379c:      	je	0x3ca3 <perf_unwind_hotspot+0x3ca3>
    37a2:      	incq	(%rax)
    37a5:      	jmp	0x3cb3 <perf_unwind_hotspot+0x3cb3>
    37aa:      	movb	$0x3, %cl
    37ac:      	movl	%ecx, 0xb0(%rsp)
    37b3:      	testl	%eax, %eax
    37b5:      	jne	0x4aa8 <perf_unwind_hotspot+0x4aa8>
    37bb:      	movq	0x38(%rsp), %rcx
    37c0:      	movl	$0x10, 0xf0(%rsp)
    37cb:      	movl	$0x10, %eax
    37d0:      	movq	%rcx, 0x38(%rsp)
    37d5:      	movl	%eax, %eax
    37d7:      	addq	%rax, 0x38(%rsp)
    37dc:      	movq	0x38(%rsp), %rax
    37e1:      	leaq	-0x10(%rax), %rdx
    37e5:      	movq	%rsp, %rdi
    37e8:      	movl	$0x10, %eax
    37ed:      	movl	$0x70, %ecx
    37f2:      	movl	$0x10, %esi
    37f7:      	callq	*%rcx
    37f9:      	movq	0x8(%rsp), %r12
    37fe:      	cmpl	$0x10, 0xf0(%rsp)
    3806:      	jb	0x3824 <perf_unwind_hotspot+0x3824>
    3808:      	movq	(%rip), %rax            # 0x380f <perf_unwind_hotspot+0x380f>
    380f:      	cmpl	$0x0, (%rax)
    3812:      	jne	0x46c0 <perf_unwind_hotspot+0x46c0>
    3818:      	movq	(%rsp), %rax
    381c:      	movq	%rax, 0xa8(%rsp)
    3824:      	movl	0x2c0(%r14), %eax
    382b:      	cmpq	$0x7e, %rax
    382f:      	ja	0xf03 <perf_unwind_hotspot+0xf03>
    3835:      	movzbl	0xf30(%r14), %ecx
    383d:      	movzbl	0xb0(%rsp), %edx
    3845:      	shlq	$0x3c, %rdx
    3849:      	movq	0x118(%rsp), %rdi
    3851:      	shlq	$0x20, %rdi
    3855:      	movl	0xb8(%rsp), %esi
    385c:      	orq	%rdi, %rsi
    385f:      	orq	%rdx, %rsi
    3862:      	leal	0x1(%rax), %edx
    3865:      	movl	%edx, 0x2c0(%r14)
    386c:      	leaq	(%rax,%rax,2), %rax
    3870:      	movq	0xc0(%rsp), %rdx
    3878:      	movq	%rdx, 0x2d0(%r14,%rax,8)
    3880:      	movq	%rsi, 0x2d8(%r14,%rax,8)
    3888:      	movb	$0x5, 0x2e0(%r14,%rax,8)
    3891:      	movb	%cl, 0x2e1(%r14,%rax,8)
    3899:      	movl	$0x0, 0x2e2(%r14,%rax,8)
    38a5:      	movw	$0x0, 0x2e6(%r14,%rax,8)
    38b0:      	movq	(%rip), %rax            # 0x38b7 <perf_unwind_hotspot+0x38b7>
    38b7:      	cmpl	$0x0, (%rax)
    38ba:      	jne	0x464d <perf_unwind_hotspot+0x464d>
    38c0:      	movq	%r12, 0xed0(%r14)
    38c7:      	movq	0x38(%rsp), %rax
    38cc:      	movq	%rax, 0xed8(%r14)
    38d3:      	movq	0xa8(%rsp), %rax
    38db:      	movq	%rax, 0xee0(%r14)
    38e2:      	movb	$0x1, 0xf30(%r14)
    38ea:      	movl	$0x2a, (%rsp)
    38f1:      	movq	(%rip), %rdi            # 0x38f8 <perf_unwind_hotspot+0x38f8>
    38f8:      	movq	%rsp, %rsi
    38fb:      	movl	$0x1, %eax
    3900:      	callq	*%rax
    3902:      	testq	%rax, %rax
    3905:      	je	0x3915 <perf_unwind_hotspot+0x3915>
    3907:      	incq	(%rax)
    390a:      	movq	(%rip), %rax            # 0x3911 <perf_unwind_hotspot+0x3911>
    3911:      	movl	(%rax), %eax
    3913:      	jmp	0x3927 <perf_unwind_hotspot+0x3927>
    3915:      	xorl	%eax, %eax
    3917:      	movq	(%rip), %rcx            # 0x391e <perf_unwind_hotspot+0x391e>
    391e:      	cmpl	$0x0, (%rcx)
    3921:      	jne	0x493b <perf_unwind_hotspot+0x493b>
    3927:      	movq	0xed0(%r14), %rbx
    392e:      	testq	%rbx, %rbx
    3931:      	je	0x9ceb <perf_unwind_hotspot+0x9ceb>
    3937:      	testl	%eax, %eax
    3939:      	jne	0x470a <perf_unwind_hotspot+0x470a>
    393f:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    3949:      	cmpq	%rax, %rbx
    394c:      	ja	0x1049 <perf_unwind_hotspot+0x1049>
    3952:      	cmpq	$0x1000, %rbx           # imm = 0x1000
    3959:      	jb	0x1fa2 <perf_unwind_hotspot+0x1fa2>
    395f:      	movl	(%r14), %eax
    3962:      	movl	$0x60, 0xc8(%rsp)
    396d:      	movbel	%eax, 0xcc(%rsp)
    3976:      	movbeq	%rbx, 0xd0(%rsp)
    3980:      	movq	(%rip), %rdi            # 0x3987 <perf_unwind_hotspot+0x3987>
    3987:      	leaq	0xc8(%rsp), %rsi
    398f:      	movl	$0x1, %eax
    3994:      	callq	*%rax
    3996:      	testq	%rax, %rax
    3999:      	je	0x9d07 <perf_unwind_hotspot+0x9d07>
    399f:      	movq	0x8(%rax), %r12
    39a3:      	movq	%r12, %rcx
    39a6:      	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    39b0:      	andq	%rdx, %rcx
    39b3:      	movq	%rcx, 0xf20(%r14)
    39ba:      	movq	(%rax), %rax
    39bd:      	movq	%rax, 0xf10(%r14)
    39c4:      	shrq	$0x38, %r12
    39c8:      	movq	%rbx, %rax
    39cb:      	subq	%rcx, %rax
    39ce:      	movq	%rax, 0xf18(%r14)
    39d5:      	movq	(%rip), %rax            # 0x39dc <perf_unwind_hotspot+0x39dc>
    39dc:      	cmpl	$0x0, (%rax)
    39df:      	jne	0x4dba <perf_unwind_hotspot+0x4dba>
    39e5:      	cmpl	$0x1, %r12d
    39e9:      	jne	0x5274 <perf_unwind_hotspot+0x5274>
    39ef:      	movq	0xf10(%r14), %rax
    39f6:      	movq	%rax, 0xc8(%rsp)
    39fe:      	movq	0xf18(%r14), %r13
    3a05:      	movq	(%rip), %rdi            # 0x3a0c <perf_unwind_hotspot+0x3a0c>
    3a0c:      	leaq	0xc8(%rsp), %rsi
    3a14:      	movl	$0x1, %eax
    3a19:      	callq	*%rax
    3a1b:      	movl	$0x1, %r12d
    3a21:      	testq	%rax, %rax
    3a24:      	je	0x5274 <perf_unwind_hotspot+0x5274>
    3a2a:      	movq	%rax, %rbx
    3a2d:      	cmpq	%r13, (%rax)
    3a30:      	ja	0x3a38 <perf_unwind_hotspot+0x3a38>
    3a32:      	cmpq	%r13, 0x8(%rbx)
    3a36:      	jae	0x3a4c <perf_unwind_hotspot+0x3a4c>
    3a38:      	cmpq	%r13, 0x10(%rbx)
    3a3c:      	ja	0x5274 <perf_unwind_hotspot+0x5274>
    3a42:      	cmpq	%r13, 0x18(%rbx)
    3a46:      	jb	0x5274 <perf_unwind_hotspot+0x5274>
    3a4c:      	movq	(%rip), %rax            # 0x3a53 <perf_unwind_hotspot+0x3a53>
    3a53:      	cmpl	$0x0, (%rax)
    3a56:      	jne	0x51d2 <perf_unwind_hotspot+0x51d2>
    3a5c:      	movl	0x1380(%r14), %eax
    3a63:      	movl	0x20(%rbx), %ecx
    3a66:      	btl	%ecx, %eax
    3a69:      	jae	0x523d <perf_unwind_hotspot+0x523d>
    3a6f:      	movq	(%rip), %rax            # 0x3a76 <perf_unwind_hotspot+0x3a76>
    3a76:      	cmpl	$0x0, (%rax)
    3a79:      	je	0x5274 <perf_unwind_hotspot+0x5274>
    3a7f:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    3a89:      	movq	%rax, 0x50(%rsp)
    3a8e:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    3a98:      	movq	%rax, 0x48(%rsp)
    3a9d:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    3aa7:      	movq	%rax, 0x40(%rsp)
    3aac:      	movl	$0xa656e, 0x57(%rsp)    # imm = 0xA656E
    3ab4:      	leaq	0x40(%rsp), %rdi
    3ab9:      	movl	$0x1b, %eax
    3abe:      	movl	$0x6, %ecx
    3ac3:      	movl	$0x1b, %esi
    3ac8:      	xorl	%eax, %eax
    3aca:      	callq	*%rcx
    3acc:      	jmp	0x5274 <perf_unwind_hotspot+0x5274>
    3ad1:      	movq	0x38(%rsp), %rax
    3ad6:      	leaq	(%rax,%rbx), %rdx
    3ada:      	addq	$-0x8, %rdx
    3ade:      	leaq	0x40(%rsp), %rdi
    3ae3:      	movl	$0x30, %eax
    3ae8:      	movl	$0x70, %ecx
    3aed:      	movl	$0x30, %esi
    3af2:      	callq	*%rcx
    3af4:      	movq	(%rip), %rax            # 0x3afb <perf_unwind_hotspot+0x3afb>
    3afb:      	cmpl	$0x0, (%rax)
    3afe:      	jne	0x4b1f <perf_unwind_hotspot+0x4b1f>
    3b04:      	movl	(%r14), %eax
    3b07:      	movl	$0x60, (%rsp)
    3b0e:      	movbel	%eax, 0x4(%rsp)
    3b14:      	addq	%rbx, 0x38(%rsp)
    3b19:      	movq	0x40(%rsp), %rax
    3b1e:      	movbeq	%rax, 0x8(%rsp)
    3b25:      	movabsq	$-0x100000000000000, %rbx # imm = 0xFF00000000000000
    3b2f:      	movabsq	$0x200000000000000, %r13 # imm = 0x200000000000000
    3b39:      	movq	(%rip), %rdi            # 0x3b40 <perf_unwind_hotspot+0x3b40>
    3b40:      	movq	%rsp, %rsi
    3b43:      	movl	$0x1, %eax
    3b48:      	callq	*%rax
    3b4a:      	testq	%rax, %rax
    3b4d:      	je	0x3cd5 <perf_unwind_hotspot+0x3cd5>
    3b53:      	movq	0x8(%rax), %rax
    3b57:      	andq	%rbx, %rax
    3b5a:      	xorl	%edx, %edx
    3b5c:      	cmpq	%r13, %rax
    3b5f:      	jne	0x3cd5 <perf_unwind_hotspot+0x3cd5>
    3b65:      	movq	0x38(%rsp), %rax
    3b6a:      	jmp	0x40bd <perf_unwind_hotspot+0x40bd>
    3b6f:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3b79:      	movq	%rax, 0x26(%rsp)
    3b7e:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    3b88:      	movq	%rax, 0x20(%rsp)
    3b8d:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    3b97:      	movq	%rax, 0x18(%rsp)
    3b9c:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    3ba6:      	movq	%rax, 0x10(%rsp)
    3bab:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    3bb5:      	movq	%rax, 0x8(%rsp)
    3bba:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3bc4:      	movq	%rax, (%rsp)
    3bc8:      	movq	%rsp, %rdi
    3bcb:      	movl	$0x2e, %eax
    3bd0:      	movl	$0x6, %ecx
    3bd5:      	movl	0x100(%rsp), %edx
    3bdc:      	movl	$0x2e, %esi
    3be1:      	xorl	%eax, %eax
    3be3:      	callq	*%rcx
    3be5:      	jmp	0x1a13 <perf_unwind_hotspot+0x1a13>
    3bea:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    3bf4:      	movq	%rax, 0x55(%rsp)
    3bf9:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    3c03:      	movq	%rax, 0x50(%rsp)
    3c08:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    3c12:      	movq	%rax, 0x48(%rsp)
    3c17:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    3c21:      	movq	%rax, 0x40(%rsp)
    3c26:      	leaq	0x40(%rsp), %rdi
    3c2b:      	movl	$0x1d, %eax
    3c30:      	movl	$0x6, %r8d
    3c36:      	movzbl	(%rsp), %ecx
    3c3a:      	movl	$0x1d, %esi
    3c3f:      	movq	%rbx, %rdx
    3c42:      	xorl	%eax, %eax
    3c44:      	callq	*%r8
    3c47:      	movzbl	(%rsp), %eax
    3c4b:      	leal	0x1(%rax), %ecx
    3c4e:      	cmpb	$0x2, %cl
    3c51:      	jb	0x290 <perf_unwind_hotspot+0x290>
    3c57:      	jmp	0xca3 <perf_unwind_hotspot+0xca3>
    3c5c:      	movq	(%rsp), %rax
    3c60:      	movq	0xd0(%rsp), %rcx
    3c68:      	cmpq	%rcx, %rax
    3c6b:      	jb	0x31d0 <perf_unwind_hotspot+0x31d0>
    3c71:      	cmpq	0xd8(%rsp), %rax
    3c79:      	jae	0x31d0 <perf_unwind_hotspot+0x31d0>
    3c7f:      	movq	(%rip), %rdx            # 0x3c86 <perf_unwind_hotspot+0x3c86>
    3c86:      	cmpl	$0x0, (%rdx)
    3c89:      	jne	0x4ecf <perf_unwind_hotspot+0x4ecf>
    3c8f:      	movl	%eax, %edx
    3c91:      	subl	%ecx, %edx
    3c93:      	movq	%rdx, 0x118(%rsp)
    3c9b:      	movq	%rax, %r12
    3c9e:      	jmp	0x31e0 <perf_unwind_hotspot+0x31e0>
    3ca3:      	movq	(%rip), %rax            # 0x3caa <perf_unwind_hotspot+0x3caa>
    3caa:      	cmpl	$0x0, (%rax)
    3cad:      	jne	0x4c6d <perf_unwind_hotspot+0x4c6d>
    3cb3:      	movl	$0x3e9, %ebx            # imm = 0x3E9
    3cb8:      	xorl	%r13d, %r13d
    3cbb:      	movl	$0x65746e49, %eax       # imm = 0x65746E49
    3cc0:      	movq	%rax, 0xb8(%rsp)
    3cc8:      	testl	%ebx, %ebx
    3cca:      	jne	0x347 <perf_unwind_hotspot+0x347>
    3cd0:      	jmp	0x40fb <perf_unwind_hotspot+0x40fb>
    3cd5:      	movq	(%rip), %rax            # 0x3cdc <perf_unwind_hotspot+0x3cdc>
    3cdc:      	cmpl	$0x0, (%rax)
    3cdf:      	jne	0x4ce8 <perf_unwind_hotspot+0x4ce8>
    3ce5:      	movl	(%r14), %eax
    3ce8:      	movl	$0x60, (%rsp)
    3cef:      	movbel	%eax, 0x4(%rsp)
    3cf5:      	movq	0x48(%rsp), %rax
    3cfa:      	movbeq	%rax, 0x8(%rsp)
    3d01:      	movq	(%rip), %rdi            # 0x3d08 <perf_unwind_hotspot+0x3d08>
    3d08:      	movq	%rsp, %rsi
    3d0b:      	movl	$0x1, %eax
    3d10:      	callq	*%rax
    3d12:      	testq	%rax, %rax
    3d15:      	je	0x3d36 <perf_unwind_hotspot+0x3d36>
    3d17:      	movq	0x8(%rax), %rax
    3d1b:      	andq	%rbx, %rax
    3d1e:      	cmpq	%r13, %rax
    3d21:      	jne	0x3d36 <perf_unwind_hotspot+0x3d36>
    3d23:      	movq	0x38(%rsp), %rax
    3d28:      	addq	$0x8, %rax
    3d2c:      	movl	$0x1, %edx
    3d31:      	jmp	0x40bd <perf_unwind_hotspot+0x40bd>
    3d36:      	movq	(%rip), %rax            # 0x3d3d <perf_unwind_hotspot+0x3d3d>
    3d3d:      	cmpl	$0x0, (%rax)
    3d40:      	jne	0x4d51 <perf_unwind_hotspot+0x4d51>
    3d46:      	movl	(%r14), %eax
    3d49:      	movl	$0x60, (%rsp)
    3d50:      	movbel	%eax, 0x4(%rsp)
    3d56:      	movq	0x50(%rsp), %rax
    3d5b:      	movbeq	%rax, 0x8(%rsp)
    3d62:      	movq	(%rip), %rdi            # 0x3d69 <perf_unwind_hotspot+0x3d69>
    3d69:      	movq	%rsp, %rsi
    3d6c:      	movl	$0x1, %eax
    3d71:      	callq	*%rax
    3d73:      	testq	%rax, %rax
    3d76:      	je	0x3ea6 <perf_unwind_hotspot+0x3ea6>
    3d7c:      	movq	0x8(%rax), %rax
    3d80:      	andq	%rbx, %rax
    3d83:      	cmpq	%r13, %rax
    3d86:      	jne	0x3ea6 <perf_unwind_hotspot+0x3ea6>
    3d8c:      	movq	0x38(%rsp), %rax
    3d91:      	addq	$0x10, %rax
    3d95:      	movl	$0x2, %edx
    3d9a:      	jmp	0x40bd <perf_unwind_hotspot+0x40bd>
    3d9f:      	movabsq	$0xa786c2520626f6c, %rax # imm = 0xA786C2520626F6C
    3da9:      	movq	%rax, 0x58(%rsp)
    3dae:      	movabsq	$0x6265646f63206f74, %rax # imm = 0x6265646F63206F74
    3db8:      	movq	%rax, 0x50(%rsp)
    3dbd:      	movabsq	$0x2064657070616d20, %rax # imm = 0x2064657070616D20
    3dc7:      	movq	%rax, 0x48(%rsp)
    3dcc:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    3dd6:      	movq	%rax, 0x40(%rsp)
    3ddb:      	movb	$0x0, 0x60(%rsp)
    3de0:      	leaq	0x40(%rsp), %rdi
    3de5:      	movl	$0x21, %eax
    3dea:      	movl	$0x6, %ecx
    3def:      	movl	$0x21, %esi
    3df4:      	movq	%rbx, %rdx
    3df7:      	xorl	%eax, %eax
    3df9:      	callq	*%rcx
    3dfb:      	movq	%rbx, 0xc8(%rsp)
    3e03:      	testq	%rbx, %rbx
    3e06:      	jne	0x2ee2 <perf_unwind_hotspot+0x2ee2>
    3e0c:      	jmp	0x237 <perf_unwind_hotspot+0x237>
    3e11:      	cmpl	$0x0, 0x2c0(%r14)
    3e19:      	je	0x4151 <perf_unwind_hotspot+0x4151>
    3e1f:      	cmpb	$0x0, 0x1f(%r15)
    3e24:      	je	0x418c <perf_unwind_hotspot+0x418c>
    3e2a:      	movq	0x50(%rsp), %r13
    3e2f:      	jmp	0x4191 <perf_unwind_hotspot+0x4191>
    3e34:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    3e3e:      	movq	%rax, 0x55(%rsp)
    3e43:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    3e4d:      	movq	%rax, 0x50(%rsp)
    3e52:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    3e5c:      	movq	%rax, 0x48(%rsp)
    3e61:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    3e6b:      	movq	%rax, 0x40(%rsp)
    3e70:      	leaq	0x40(%rsp), %rdi
    3e75:      	movl	$0x1d, %eax
    3e7a:      	movl	$0x6, %r8d
    3e80:      	movzbl	(%rsp), %ecx
    3e84:      	movl	$0x1d, %esi
    3e89:      	movq	%r13, %rdx
    3e8c:      	xorl	%eax, %eax
    3e8e:      	callq	*%r8
    3e91:      	movzbl	(%rsp), %eax
    3e95:      	leal	0x1(%rax), %ecx
    3e98:      	cmpb	$0x2, %cl
    3e9b:      	jb	0x2ea0 <perf_unwind_hotspot+0x2ea0>
    3ea1:      	jmp	0x349b <perf_unwind_hotspot+0x349b>
    3ea6:      	movq	(%rip), %rax            # 0x3ead <perf_unwind_hotspot+0x3ead>
    3ead:      	cmpl	$0x0, (%rax)
    3eb0:      	jne	0x4f7d <perf_unwind_hotspot+0x4f7d>
    3eb6:      	movl	(%r14), %eax
    3eb9:      	movl	$0x60, (%rsp)
    3ec0:      	movbel	%eax, 0x4(%rsp)
    3ec6:      	movq	0x58(%rsp), %rax
    3ecb:      	movbeq	%rax, 0x8(%rsp)
    3ed2:      	movq	(%rip), %rdi            # 0x3ed9 <perf_unwind_hotspot+0x3ed9>
    3ed9:      	movq	%rsp, %rsi
    3edc:      	movl	$0x1, %eax
    3ee1:      	callq	*%rax
    3ee3:      	testq	%rax, %rax
    3ee6:      	je	0x3f07 <perf_unwind_hotspot+0x3f07>
    3ee8:      	movq	0x8(%rax), %rax
    3eec:      	andq	%rbx, %rax
    3eef:      	cmpq	%r13, %rax
    3ef2:      	jne	0x3f07 <perf_unwind_hotspot+0x3f07>
    3ef4:      	movq	0x38(%rsp), %rax
    3ef9:      	addq	$0x18, %rax
    3efd:      	movl	$0x3, %edx
    3f02:      	jmp	0x40bd <perf_unwind_hotspot+0x40bd>
    3f07:      	movq	(%rip), %rax            # 0x3f0e <perf_unwind_hotspot+0x3f0e>
    3f0e:      	cmpl	$0x0, (%rax)
    3f11:      	jne	0x4fe6 <perf_unwind_hotspot+0x4fe6>
    3f17:      	movl	(%r14), %eax
    3f1a:      	movl	$0x60, (%rsp)
    3f21:      	movbel	%eax, 0x4(%rsp)
    3f27:      	movq	0x60(%rsp), %rax
    3f2c:      	movbeq	%rax, 0x8(%rsp)
    3f33:      	movq	(%rip), %rdi            # 0x3f3a <perf_unwind_hotspot+0x3f3a>
    3f3a:      	movq	%rsp, %rsi
    3f3d:      	movl	$0x1, %eax
    3f42:      	callq	*%rax
    3f44:      	testq	%rax, %rax
    3f47:      	je	0x405c <perf_unwind_hotspot+0x405c>
    3f4d:      	movq	0x8(%rax), %rax
    3f51:      	andq	%rbx, %rax
    3f54:      	cmpq	%r13, %rax
    3f57:      	jne	0x405c <perf_unwind_hotspot+0x405c>
    3f5d:      	movq	0x38(%rsp), %rax
    3f62:      	addq	$0x20, %rax
    3f66:      	movl	$0x4, %edx
    3f6b:      	jmp	0x40bd <perf_unwind_hotspot+0x40bd>
    3f70:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3f7a:      	movq	%rax, 0x66(%rsp)
    3f7f:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    3f89:      	movq	%rax, 0x60(%rsp)
    3f8e:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    3f98:      	movq	%rax, 0x58(%rsp)
    3f9d:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    3fa7:      	movq	%rax, 0x50(%rsp)
    3fac:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    3fb6:      	movq	%rax, 0x48(%rsp)
    3fbb:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3fc5:      	movq	%rax, 0x40(%rsp)
    3fca:      	leaq	0x40(%rsp), %rdi
    3fcf:      	movl	$0x2e, %eax
    3fd4:      	movl	$0x6, %ecx
    3fd9:      	movl	(%rsp), %edx
    3fdc:      	movl	$0x2e, %esi
    3fe1:      	xorl	%eax, %eax
    3fe3:      	callq	*%rcx
    3fe5:      	jmp	0x2d17 <perf_unwind_hotspot+0x2d17>
    3fea:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    3ff4:      	movq	%rax, 0x55(%rsp)
    3ff9:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    4003:      	movq	%rax, 0x50(%rsp)
    4008:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    4012:      	movq	%rax, 0x48(%rsp)
    4017:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    4021:      	movq	%rax, 0x40(%rsp)
    4026:      	leaq	0x40(%rsp), %rdi
    402b:      	movl	$0x1d, %eax
    4030:      	movl	$0x6, %r8d
    4036:      	movzbl	(%rsp), %ecx
    403a:      	movl	$0x1d, %esi
    403f:      	movq	%rbx, %rdx
    4042:      	xorl	%eax, %eax
    4044:      	callq	*%r8
    4047:      	movzbl	(%rsp), %eax
    404b:      	leal	0x1(%rax), %ecx
    404e:      	cmpb	$0x2, %cl
    4051:      	jb	0x290 <perf_unwind_hotspot+0x290>
    4057:      	jmp	0xcea <perf_unwind_hotspot+0xcea>
    405c:      	movq	(%rip), %rax            # 0x4063 <perf_unwind_hotspot+0x4063>
    4063:      	cmpl	$0x0, (%rax)
    4066:      	jne	0x50c1 <perf_unwind_hotspot+0x50c1>
    406c:      	movl	(%r14), %eax
    406f:      	movl	$0x60, (%rsp)
    4076:      	movbel	%eax, 0x4(%rsp)
    407c:      	movq	0x68(%rsp), %rax
    4081:      	movbeq	%rax, 0x8(%rsp)
    4088:      	movq	(%rip), %rdi            # 0x408f <perf_unwind_hotspot+0x408f>
    408f:      	movq	%rsp, %rsi
    4092:      	movl	$0x1, %eax
    4097:      	callq	*%rax
    4099:      	testq	%rax, %rax
    409c:      	je	0x415a <perf_unwind_hotspot+0x415a>
    40a2:      	andq	0x8(%rax), %rbx
    40a6:      	cmpq	%r13, %rbx
    40a9:      	jne	0x415a <perf_unwind_hotspot+0x415a>
    40af:      	movq	0x38(%rsp), %rax
    40b4:      	addq	$0x28, %rax
    40b8:      	movl	$0x5, %edx
    40bd:      	movq	%rax, 0x108(%rsp)
    40c5:      	xorl	%ebx, %ebx
    40c7:      	movl	$0x5, %r13d
    40cd:      	movq	(%rip), %rax            # 0x40d4 <perf_unwind_hotspot+0x40d4>
    40d4:      	cmpl	$0x0, (%rax)
    40d7:      	jne	0x4bf7 <perf_unwind_hotspot+0x4bf7>
    40dd:      	movb	$0x3, %al
    40df:      	movl	%eax, 0xb0(%rsp)
    40e6:      	movq	0x108(%rsp), %rax
    40ee:      	movq	%rax, 0x38(%rsp)
    40f3:      	testl	%ebx, %ebx
    40f5:      	jne	0x347 <perf_unwind_hotspot+0x347>
    40fb:      	cmpl	$0x2, %r13d
    40ff:      	jle	0x411d <perf_unwind_hotspot+0x411d>
    4101:      	cmpl	$0x4, %r13d
    4105:      	jg	0x4142 <perf_unwind_hotspot+0x4142>
    4107:      	cmpl	$0x3, %r13d
    410b:      	je	0x37bb <perf_unwind_hotspot+0x37bb>
    4111:      	movl	0xf0(%rsp), %eax
    4118:      	jmp	0x37d5 <perf_unwind_hotspot+0x37d5>
    411d:      	movl	$0x1, %ebx
    4122:      	testl	%r13d, %r13d
    4125:      	je	0x347 <perf_unwind_hotspot+0x347>
    412b:      	movq	0xa8(%rsp), %rcx
    4133:      	cmpl	$0x1, %r13d
    4137:      	je	0x32b4 <perf_unwind_hotspot+0x32b4>
    413d:      	jmp	0x37c0 <perf_unwind_hotspot+0x37c0>
    4142:      	cmpl	$0x5, %r13d
    4146:      	je	0x37dc <perf_unwind_hotspot+0x37dc>
    414c:      	jmp	0x3824 <perf_unwind_hotspot+0x3824>
    4151:      	movq	0xf00(%r14), %r13
    4158:      	jmp	0x4191 <perf_unwind_hotspot+0x4191>
    415a:      	movl	$0x2e, 0x100(%rsp)
    4165:      	movq	(%rip), %rdi            # 0x416c <perf_unwind_hotspot+0x416c>
    416c:      	leaq	0x100(%rsp), %rsi
    4174:      	movl	$0x1, %eax
    4179:      	callq	*%rax
    417b:      	testq	%rax, %rax
    417e:      	je	0x4364 <perf_unwind_hotspot+0x4364>
    4184:      	incq	(%rax)
    4187:      	jmp	0x4374 <perf_unwind_hotspot+0x4374>
    418c:      	movq	0x58(%rsp), %r13
    4191:      	movq	0x78(%rsp), %rsi
    4196:      	movq	0x88(%rsp), %rax
    419e:      	movq	%rax, 0x38(%rsp)
    41a3:      	movq	0x90(%rsp), %rax
    41ab:      	movq	%rax, 0xa8(%rsp)
    41b3:      	movq	0x98(%rsp), %r12
    41bb:      	movzbl	0x1c(%r15), %eax
    41c0:      	addq	%rsi, %rax
    41c3:      	leaq	0x100(%rsp), %rdi
    41cb:      	movl	$0x8, %ecx
    41d0:      	movl	$0x70, %r8d
    41d6:      	movzbl	0x1c(%r15), %edx
    41db:      	movq	%rsi, 0x108(%rsp)
    41e3:      	addq	%rsi, %rdx
    41e6:      	movl	$0x8, %esi
    41eb:      	callq	*%r8
    41ee:      	testq	%rax, %rax
    41f1:      	je	0x4269 <perf_unwind_hotspot+0x4269>
    41f3:      	movq	(%rip), %rax            # 0x41fa <perf_unwind_hotspot+0x41fa>
    41fa:      	cmpl	$0x0, (%rax)
    41fd:      	je	0x3778 <perf_unwind_hotspot+0x3778>
    4203:      	movabsq	$0xa646f6874656d63, %rax # imm = 0xA646F6874656D63
    420d:      	movq	%rax, 0x20(%rsp)
    4212:      	movabsq	$0x2072657465727072, %rax # imm = 0x2072657465727072
    421c:      	movq	%rax, 0x18(%rsp)
    4221:      	movabsq	$0x65746e6920646165, %rax # imm = 0x65746E6920646165
    422b:      	movq	%rax, 0x10(%rsp)
    4230:      	movabsq	$0x72206f742064656c, %rax # imm = 0x72206F742064656C
    423a:      	movq	%rax, 0x8(%rsp)
    423f:      	movabsq	$0x696166203a6d766a, %rax # imm = 0x696166203A6D766A
    4249:      	movq	%rax, (%rsp)
    424d:      	movb	$0x0, 0x28(%rsp)
    4252:      	movq	%rsp, %rdi
    4255:      	movl	$0x29, %eax
    425a:      	movl	$0x6, %ecx
    425f:      	movl	$0x29, %esi
    4264:      	jmp	0x4a9f <perf_unwind_hotspot+0x4a9f>
    4269:      	movq	0x100(%rsp), %rdx
    4271:      	movzbl	0x1d(%r15), %eax
    4276:      	movq	%rdx, %rcx
    4279:      	movq	%rdx, 0xb8(%rsp)
    4281:      	addq	%rdx, %rax
    4284:      	xorl	%ebx, %ebx
    4286:      	cmpq	%rax, %r13
    4289:      	movl	$0x0, %ecx
    428e:      	cmovaeq	%rax, %rcx
    4292:      	subq	%rcx, %r13
    4295:      	movq	(%rip), %rax            # 0x429c <perf_unwind_hotspot+0x429c>
    429c:      	cmpl	$0x0, (%rax)
    429f:      	jne	0x512a <perf_unwind_hotspot+0x512a>
    42a5:      	cmpq	$0xffff, %r13           # imm = 0xFFFF
    42ac:      	movl	$0xffff, %eax           # imm = 0xFFFF
    42b1:      	cmovbq	%r13, %rax
    42b5:      	movq	%rax, 0x118(%rsp)
    42bd:      	shrq	$0x3, 0xb8(%rsp)
    42c6:      	movl	$0x6, %r13d
    42cc:      	movb	$0x2, %al
    42ce:      	movl	%eax, 0xb0(%rsp)
    42d5:      	movq	0x108(%rsp), %rax
    42dd:      	movq	%rax, 0xc0(%rsp)
    42e5:      	testl	%ebx, %ebx
    42e7:      	jne	0x347 <perf_unwind_hotspot+0x347>
    42ed:      	jmp	0x40fb <perf_unwind_hotspot+0x40fb>
    42f2:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    42fc:      	movq	%rax, 0x55(%rsp)
    4301:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    430b:      	movq	%rax, 0x50(%rsp)
    4310:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    431a:      	movq	%rax, 0x48(%rsp)
    431f:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    4329:      	movq	%rax, 0x40(%rsp)
    432e:      	leaq	0x40(%rsp), %rdi
    4333:      	movl	$0x1d, %eax
    4338:      	movl	$0x6, %r8d
    433e:      	movzbl	(%rsp), %ecx
    4342:      	movl	$0x1d, %esi
    4347:      	movq	%r13, %rdx
    434a:      	xorl	%eax, %eax
    434c:      	callq	*%r8
    434f:      	movzbl	(%rsp), %eax
    4353:      	leal	0x1(%rax), %ecx
    4356:      	cmpb	$0x2, %cl
    4359:      	jb	0x2ea0 <perf_unwind_hotspot+0x2ea0>
    435f:      	jmp	0x34e2 <perf_unwind_hotspot+0x34e2>
    4364:      	movq	(%rip), %rax            # 0x436b <perf_unwind_hotspot+0x436b>
    436b:      	cmpl	$0x0, (%rax)
    436e:      	jne	0x5ba0 <perf_unwind_hotspot+0x5ba0>
    4374:      	movl	$0x3ea, %ebx            # imm = 0x3EA
    4379:      	xorl	%r13d, %r13d
    437c:      	jmp	0x40dd <perf_unwind_hotspot+0x40dd>
    4381:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    438b:      	movq	%rax, 0x55(%rsp)
    4390:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    439a:      	movq	%rax, 0x50(%rsp)
    439f:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    43a9:      	movq	%rax, 0x48(%rsp)
    43ae:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    43b8:      	movq	%rax, 0x40(%rsp)
    43bd:      	leaq	0x40(%rsp), %rdi
    43c2:      	movl	$0x1d, %eax
    43c7:      	movl	$0x6, %r8d
    43cd:      	movzbl	(%rsp), %ecx
    43d1:      	movl	$0x1d, %esi
    43d6:      	movq	%rbx, %rdx
    43d9:      	xorl	%eax, %eax
    43db:      	callq	*%r8
    43de:      	movzbl	(%rsp), %eax
    43e2:      	leal	0x1(%rax), %ecx
    43e5:      	cmpb	$0x2, %cl
    43e8:      	jb	0x290 <perf_unwind_hotspot+0x290>
    43ee:      	jmp	0xd31 <perf_unwind_hotspot+0xd31>
    43f3:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    43fd:      	movq	%rax, 0x55(%rsp)
    4402:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    440c:      	movq	%rax, 0x50(%rsp)
    4411:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    441b:      	movq	%rax, 0x48(%rsp)
    4420:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    442a:      	movq	%rax, 0x40(%rsp)
    442f:      	leaq	0x40(%rsp), %rdi
    4434:      	movl	$0x1d, %eax
    4439:      	movl	$0x6, %r8d
    443f:      	movzbl	(%rsp), %ecx
    4443:      	movl	$0x1d, %esi
    4448:      	movq	%r13, %rdx
    444b:      	xorl	%eax, %eax
    444d:      	callq	*%r8
    4450:      	movzbl	(%rsp), %eax
    4454:      	leal	0x1(%rax), %ecx
    4457:      	cmpb	$0x2, %cl
    445a:      	jb	0x2ea0 <perf_unwind_hotspot+0x2ea0>
    4460:      	jmp	0x3529 <perf_unwind_hotspot+0x3529>
    4465:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    446f:      	movq	%rax, 0x55(%rsp)
    4474:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    447e:      	movq	%rax, 0x50(%rsp)
    4483:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    448d:      	movq	%rax, 0x48(%rsp)
    4492:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    449c:      	movq	%rax, 0x40(%rsp)
    44a1:      	leaq	0x40(%rsp), %rdi
    44a6:      	movl	$0x1d, %eax
    44ab:      	movl	$0x6, %r8d
    44b1:      	movzbl	(%rsp), %ecx
    44b5:      	movl	$0x1d, %esi
    44ba:      	movq	%rbx, %rdx
    44bd:      	xorl	%eax, %eax
    44bf:      	callq	*%r8
    44c2:      	movzbl	(%rsp), %eax
    44c6:      	leal	0x1(%rax), %ecx
    44c9:      	cmpb	$0x2, %cl
    44cc:      	jb	0x290 <perf_unwind_hotspot+0x290>
    44d2:      	jmp	0xd78 <perf_unwind_hotspot+0xd78>
    44d7:      	movabsq	$0xa786c252d786c, %rax  # imm = 0xA786C252D786C
    44e1:      	movq	%rax, 0x4f(%rsp)
    44e6:      	movabsq	$0x6c252065646f6320, %rax # imm = 0x6C252065646F6320
    44f0:      	movq	%rax, 0x48(%rsp)
    44f5:      	movabsq	$0x3e2d20203a6d766a, %rbx # imm = 0x3E2D20203A6D766A
    44ff:      	movq	%rbx, 0x40(%rsp)
    4504:      	leaq	0x40(%rsp), %rdi
    4509:      	movl	$0x17, %eax
    450e:      	movl	$0x6, %r8d
    4514:      	movq	0xd0(%rsp), %rdx
    451c:      	movq	0xd8(%rsp), %rcx
    4524:      	movl	$0x17, %esi
    4529:      	xorl	%eax, %eax
    452b:      	callq	*%r8
    452e:      	movq	(%rip), %rax            # 0x4535 <perf_unwind_hotspot+0x4535>
    4535:      	cmpl	$0x0, (%rax)
    4538:      	je	0x3021 <perf_unwind_hotspot+0x3021>
    453e:      	movabsq	$0x783020657079745f, %rax # imm = 0x783020657079745F
    4548:      	movq	%rax, 0x70(%rsp)
    454d:      	movabsq	$0x656d617266202c75, %rax # imm = 0x656D617266202C75
    4557:      	movq	%rax, 0x68(%rsp)
    455c:      	movabsq	$0x2520657a69735f65, %rax # imm = 0x2520657A69735F65
    4566:      	movq	%rax, 0x60(%rsp)
    456b:      	movabsq	$0x6d617266202c7525, %rax # imm = 0x6D617266202C7525
    4575:      	movq	%rax, 0x58(%rsp)
    457a:      	movabsq	$0x206574656c706d6f, %rax # imm = 0x206574656C706D6F
    4584:      	movq	%rax, 0x50(%rsp)
    4589:      	movabsq	$0x635f656d61726620, %rax # imm = 0x635F656D61726620
    4593:      	movq	%rax, 0x48(%rsp)
    4598:      	movq	%rbx, 0x40(%rsp)
    459d:      	movl	$0xa7825, 0x78(%rsp)    # imm = 0xA7825
    45a5:      	leaq	0x40(%rsp), %rdi
    45aa:      	movl	$0x3c, %eax
    45af:      	movl	$0x6, %r9d
    45b5:      	movzwl	0xf8(%rsp), %edx
    45bd:      	movl	0xe8(%rsp), %r8d
    45c5:      	movl	0xf0(%rsp), %ecx
    45cc:      	movl	$0x3c, %esi
    45d1:      	xorl	%eax, %eax
    45d3:      	callq	*%r9
    45d6:      	jmp	0x3021 <perf_unwind_hotspot+0x3021>
    45db:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    45e5:      	movq	%rax, 0x55(%rsp)
    45ea:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    45f4:      	movq	%rax, 0x50(%rsp)
    45f9:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    4603:      	movq	%rax, 0x48(%rsp)
    4608:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    4612:      	movq	%rax, 0x40(%rsp)
    4617:      	leaq	0x40(%rsp), %rdi
    461c:      	movl	$0x1d, %eax
    4621:      	movl	$0x6, %r8d
    4627:      	movzbl	(%rsp), %ecx
    462b:      	movl	$0x1d, %esi
    4630:      	movq	%r13, %rdx
    4633:      	xorl	%eax, %eax
    4635:      	callq	*%r8
    4638:      	movzbl	(%rsp), %eax
    463c:      	leal	0x1(%rax), %ecx
    463f:      	cmpb	$0x2, %cl
    4642:      	jb	0x2ea0 <perf_unwind_hotspot+0x2ea0>
    4648:      	jmp	0x3570 <perf_unwind_hotspot+0x3570>
    464d:      	movabsq	$0x25203a7066202c78, %rax # imm = 0x25203A7066202C78
    4657:      	movq	%rax, 0x58(%rsp)
    465c:      	movabsq	$0x6c25203a7073202c, %rax # imm = 0x6C25203A7073202C
    4666:      	movq	%rax, 0x50(%rsp)
    466b:      	movabsq	$0x786c25203a637020, %rax # imm = 0x786C25203A637020
    4675:      	movq	%rax, 0x48(%rsp)
    467a:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    4684:      	movq	%rax, 0x40(%rsp)
    4689:      	movl	$0xa786c, 0x60(%rsp)    # imm = 0xA786C
    4691:      	leaq	0x40(%rsp), %rdi
    4696:      	movl	$0x24, %eax
    469b:      	movl	$0x6, %r9d
    46a1:      	movl	$0x24, %esi
    46a6:      	movq	%r12, %rdx
    46a9:      	movq	0x38(%rsp), %rcx
    46ae:      	movq	0xa8(%rsp), %r8
    46b6:      	xorl	%eax, %eax
    46b8:      	callq	*%r9
    46bb:      	jmp	0x38c0 <perf_unwind_hotspot+0x38c0>
    46c0:      	movabsq	$0xa706620726576, %rax  # imm = 0xA706620726576
    46ca:      	movq	%rax, 0x4d(%rsp)
    46cf:      	movabsq	$0x7265766f63657220, %rax # imm = 0x7265766F63657220
    46d9:      	movq	%rax, 0x48(%rsp)
    46de:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    46e8:      	movq	%rax, 0x40(%rsp)
    46ed:      	leaq	0x40(%rsp), %rdi
    46f2:      	movl	$0x15, %eax
    46f7:      	movl	$0x6, %ecx
    46fc:      	movl	$0x15, %esi
    4701:      	xorl	%eax, %eax
    4703:      	callq	*%rcx
    4705:      	jmp	0x3818 <perf_unwind_hotspot+0x3818>
    470a:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    4714:      	movq	%rax, 0x68(%rsp)
    4719:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    4723:      	movq	%rax, 0x60(%rsp)
    4728:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    4732:      	movq	%rax, 0x58(%rsp)
    4737:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    4741:      	movq	%rax, 0x50(%rsp)
    4746:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    4750:      	movq	%rax, 0x48(%rsp)
    4755:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    475f:      	movq	%rax, 0x40(%rsp)
    4764:      	movb	$0x0, 0x70(%rsp)
    4769:      	leaq	0x40(%rsp), %rdi
    476e:      	movl	$0x31, %eax
    4773:      	movl	$0x6, %ecx
    4778:      	movl	0x2c0(%r14), %edx
    477f:      	movl	$0x31, %esi
    4784:      	xorl	%eax, %eax
    4786:      	callq	*%rcx
    4788:      	movq	0xed0(%r14), %rbx
    478f:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    4799:      	cmpq	%rax, %rbx
    479c:      	ja	0x1049 <perf_unwind_hotspot+0x1049>
    47a2:      	jmp	0x3952 <perf_unwind_hotspot+0x3952>
    47a7:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    47b1:      	movq	%rax, 0x55(%rsp)
    47b6:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    47c0:      	movq	%rax, 0x50(%rsp)
    47c5:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    47cf:      	movq	%rax, 0x48(%rsp)
    47d4:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    47de:      	movq	%rax, 0x40(%rsp)
    47e3:      	leaq	0x40(%rsp), %rdi
    47e8:      	movl	$0x1d, %eax
    47ed:      	movl	$0x6, %r8d
    47f3:      	movzbl	(%rsp), %ecx
    47f7:      	movl	$0x1d, %esi
    47fc:      	movq	%rbx, %rdx
    47ff:      	xorl	%eax, %eax
    4801:      	callq	*%r8
    4804:      	movzbl	(%rsp), %eax
    4808:      	leal	0x1(%rax), %ecx
    480b:      	cmpb	$0x1, %cl
    480e:      	ja	0x22b <perf_unwind_hotspot+0x22b>
    4814:      	jmp	0x290 <perf_unwind_hotspot+0x290>
    4819:      	movabsq	$0xa656c62617476, %rax  # imm = 0xA656C62617476
    4823:      	movq	%rax, 0x50(%rsp)
    4828:      	movabsq	$0x20646e69776e7520, %rax # imm = 0x20646E69776E7520
    4832:      	movq	%rax, 0x48(%rsp)
    4837:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    4841:      	movq	%rax, 0x40(%rsp)
    4846:      	leaq	0x40(%rsp), %rdi
    484b:      	movl	$0x18, %eax
    4850:      	movl	$0x6, %ecx
    4855:      	movl	$0x18, %esi
    485a:      	xorl	%eax, %eax
    485c:      	callq	*%rcx
    485e:      	jmp	0x32b4 <perf_unwind_hotspot+0x32b4>
    4863:      	movabsq	$0x6170206b6361626c, %rax # imm = 0x6170206B6361626C
    486d:      	movq	%rax, 0x58(%rsp)
    4872:      	movabsq	$0x6c61662062757473, %rax # imm = 0x6C61662062757473
    487c:      	movq	%rax, 0x50(%rsp)
    4881:      	movabsq	$0x20646e69776e7520, %rax # imm = 0x20646E69776E7520
    488b:      	movq	%rax, 0x48(%rsp)
    4890:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    489a:      	movq	%rax, 0x40(%rsp)
    489f:      	movl	$0xa6874, 0x60(%rsp)    # imm = 0xA6874
    48a7:      	leaq	0x40(%rsp), %rdi
    48ac:      	movl	$0x24, %eax
    48b1:      	movl	$0x6, %ecx
    48b6:      	movl	$0x24, %esi
    48bb:      	xorl	%eax, %eax
    48bd:      	callq	*%rcx
    48bf:      	jmp	0x32d9 <perf_unwind_hotspot+0x32d9>
    48c4:      	movabsq	$0xa64656c696166, %rax  # imm = 0xA64656C696166
    48ce:      	movq	%rax, 0x68(%rsp)
    48d3:      	movabsq	$0x20797265766f6365, %rax # imm = 0x20797265766F6365
    48dd:      	movq	%rax, 0x60(%rsp)
    48e2:      	movabsq	$0x72206370202c656d, %rax # imm = 0x72206370202C656D
    48ec:      	movq	%rax, 0x58(%rsp)
    48f1:      	movabsq	$0x6172662064657a69, %rax # imm = 0x6172662064657A69
    48fb:      	movq	%rax, 0x50(%rsp)
    4900:      	movabsq	$0x6d6974706f656420, %rax # imm = 0x6D6974706F656420
    490a:      	movq	%rax, 0x48(%rsp)
    490f:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    4919:      	movq	%rax, 0x40(%rsp)
    491e:      	leaq	0x40(%rsp), %rdi
    4923:      	movl	$0x30, %eax
    4928:      	movl	$0x6, %ecx
    492d:      	movl	$0x30, %esi
    4932:      	xorl	%eax, %eax
    4934:      	callq	*%rcx
    4936:      	jmp	0x31e0 <perf_unwind_hotspot+0x31e0>
    493b:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4945:      	movq	%rax, 0x66(%rsp)
    494a:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4954:      	movq	%rax, 0x60(%rsp)
    4959:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4963:      	movq	%rax, 0x58(%rsp)
    4968:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4972:      	movq	%rax, 0x50(%rsp)
    4977:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4981:      	movq	%rax, 0x48(%rsp)
    4986:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4990:      	movq	%rax, 0x40(%rsp)
    4995:      	leaq	0x40(%rsp), %rdi
    499a:      	movl	$0x2e, %eax
    499f:      	movl	$0x6, %ecx
    49a4:      	movl	(%rsp), %edx
    49a7:      	movl	$0x2e, %esi
    49ac:      	xorl	%eax, %eax
    49ae:      	callq	*%rcx
    49b0:      	jmp	0x390a <perf_unwind_hotspot+0x390a>
    49b5:      	movabsq	$0xa29646c252065, %rax  # imm = 0xA29646C252065
    49bf:      	movq	%rax, 0x67(%rsp)
    49c4:      	movabsq	$0x657a697320656d61, %rax # imm = 0x657A697320656D61
    49ce:      	movq	%rax, 0x60(%rsp)
    49d3:      	movabsq	$0x726628207265746e, %rax # imm = 0x726628207265746E
    49dd:      	movq	%rax, 0x58(%rsp)
    49e2:      	movabsq	$0x696f7020656d6172, %rax # imm = 0x696F7020656D6172
    49ec:      	movq	%rax, 0x50(%rsp)
    49f1:      	movabsq	$0x6620676e69737520, %rax # imm = 0x6620676E69737520
    49fb:      	movq	%rax, 0x48(%rsp)
    4a00:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    4a0a:      	movq	%rax, 0x40(%rsp)
    4a0f:      	leaq	0x40(%rsp), %rdi
    4a14:      	movl	$0x2f, %eax
    4a19:      	movl	$0x6, %ecx
    4a1e:      	movl	$0x2f, %esi
    4a23:      	xorl	%eax, %eax
    4a25:      	callq	*%rcx
    4a27:      	movq	0xa8(%rsp), %rcx
    4a2f:      	jmp	0x37c0 <perf_unwind_hotspot+0x37c0>
    4a34:      	movabsq	$0xa656d61726620, %rax  # imm = 0xA656D61726620
    4a3e:      	movq	%rax, 0x26(%rsp)
    4a43:      	movabsq	$0x6620726574657270, %rax # imm = 0x6620726574657270
    4a4d:      	movq	%rax, 0x20(%rsp)
    4a52:      	movabsq	$0x7265746e69206562, %rax # imm = 0x7265746E69206562
    4a5c:      	movq	%rax, 0x18(%rsp)
    4a61:      	movabsq	$0x206f742079617761, %rax # imm = 0x206F742079617761
    4a6b:      	movq	%rax, 0x10(%rsp)
    4a70:      	movabsq	$0x20726166206f6f74, %rax # imm = 0x20726166206F6F74
    4a7a:      	movq	%rax, 0x8(%rsp)
    4a7f:      	movabsq	$0x207066203a6d766a, %rax # imm = 0x207066203A6D766A
    4a89:      	movq	%rax, (%rsp)
    4a8d:      	movq	%rsp, %rdi
    4a90:      	movl	$0x2e, %eax
    4a95:      	movl	$0x6, %ecx
    4a9a:      	movl	$0x2e, %esi
    4a9f:      	xorl	%eax, %eax
    4aa1:      	callq	*%rcx
    4aa3:      	jmp	0x3778 <perf_unwind_hotspot+0x3778>
    4aa8:      	movabsq	$0xa2963702b7066, %rax  # imm = 0xA2963702B7066
    4ab2:      	movq	%rax, 0x65(%rsp)
    4ab7:      	movabsq	$0x2b70662820656d61, %rax # imm = 0x2B70662820656D61
    4ac1:      	movq	%rax, 0x60(%rsp)
    4ac6:      	movabsq	$0x7266206574656c70, %rax # imm = 0x7266206574656C70
    4ad0:      	movq	%rax, 0x58(%rsp)
    4ad5:      	movabsq	$0x6d6f636e6920676e, %rax # imm = 0x6D6F636E6920676E
    4adf:      	movq	%rax, 0x50(%rsp)
    4ae4:      	movabsq	$0x69646e69776e7520, %rax # imm = 0x69646E69776E7520
    4aee:      	movq	%rax, 0x48(%rsp)
    4af3:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    4afd:      	movq	%rax, 0x40(%rsp)
    4b02:      	leaq	0x40(%rsp), %rdi
    4b07:      	movl	$0x2d, %eax
    4b0c:      	movl	$0x6, %ecx
    4b11:      	movl	$0x2d, %esi
    4b16:      	xorl	%eax, %eax
    4b18:      	callq	*%rcx
    4b1a:      	jmp	0x37bb <perf_unwind_hotspot+0x37bb>
    4b1f:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    4b29:      	movq	%rax, 0x18(%rsp)
    4b2e:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    4b38:      	movq	%rax, 0x10(%rsp)
    4b3d:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    4b47:      	movq	%rax, 0x8(%rsp)
    4b4c:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    4b56:      	movq	%rax, (%rsp)
    4b5a:      	movw	$0xa, 0x20(%rsp)
    4b61:      	movq	%rsp, %rdi
    4b64:      	movl	$0x22, %eax
    4b69:      	movl	$0x6, %r8d
    4b6f:      	movq	0x40(%rsp), %rcx
    4b74:      	movl	$0x22, %esi
    4b79:      	xorl	%edx, %edx
    4b7b:      	xorl	%eax, %eax
    4b7d:      	callq	*%r8
    4b80:      	jmp	0x3b04 <perf_unwind_hotspot+0x3b04>
    4b85:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    4b8f:      	movq	%rax, 0x55(%rsp)
    4b94:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    4b9e:      	movq	%rax, 0x50(%rsp)
    4ba3:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    4bad:      	movq	%rax, 0x48(%rsp)
    4bb2:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    4bbc:      	movq	%rax, 0x40(%rsp)
    4bc1:      	leaq	0x40(%rsp), %rdi
    4bc6:      	movl	$0x1d, %eax
    4bcb:      	movl	$0x6, %r8d
    4bd1:      	movzbl	(%rsp), %ecx
    4bd5:      	movl	$0x1d, %esi
    4bda:      	movq	%r13, %rdx
    4bdd:      	xorl	%eax, %eax
    4bdf:      	callq	*%r8
    4be2:      	movzbl	(%rsp), %eax
    4be6:      	leal	0x1(%rax), %ecx
    4be9:      	cmpb	$0x2, %cl
    4bec:      	jb	0x2ea0 <perf_unwind_hotspot+0x2ea0>
    4bf2:      	jmp	0x35b7 <perf_unwind_hotspot+0x35b7>
    4bf7:      	movabsq	$0xa7364726f7720, %rax  # imm = 0xA7364726F7720
    4c01:      	movq	%rax, 0x26(%rsp)
    4c06:      	movabsq	$0x77206425202b2065, %rax # imm = 0x77206425202B2065
    4c10:      	movq	%rax, 0x20(%rsp)
    4c15:      	movabsq	$0x6d61726620657465, %rax # imm = 0x6D61726620657465
    4c1f:      	movq	%rax, 0x18(%rsp)
    4c24:      	movabsq	$0x6c706d6f6320676e, %rax # imm = 0x6C706D6F6320676E
    4c2e:      	movq	%rax, 0x10(%rsp)
    4c33:      	movabsq	$0x69646e69776e7520, %rax # imm = 0x69646E69776E7520
    4c3d:      	movq	%rax, 0x8(%rsp)
    4c42:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    4c4c:      	movq	%rax, (%rsp)
    4c50:      	movq	%rsp, %rdi
    4c53:      	movl	$0x2e, %eax
    4c58:      	movl	$0x6, %ecx
    4c5d:      	xorl	%ebx, %ebx
    4c5f:      	movl	$0x2e, %esi
    4c64:      	xorl	%eax, %eax
    4c66:      	callq	*%rcx
    4c68:      	jmp	0x40dd <perf_unwind_hotspot+0x40dd>
    4c6d:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4c77:      	movq	%rax, 0x26(%rsp)
    4c7c:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4c86:      	movq	%rax, 0x20(%rsp)
    4c8b:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4c95:      	movq	%rax, 0x18(%rsp)
    4c9a:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4ca4:      	movq	%rax, 0x10(%rsp)
    4ca9:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4cb3:      	movq	%rax, 0x8(%rsp)
    4cb8:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4cc2:      	movq	%rax, (%rsp)
    4cc6:      	movq	%rsp, %rdi
    4cc9:      	movl	$0x2e, %eax
    4cce:      	movl	$0x6, %ecx
    4cd3:      	movl	0x114(%rsp), %edx
    4cda:      	movl	$0x2e, %esi
    4cdf:      	xorl	%eax, %eax
    4ce1:      	callq	*%rcx
    4ce3:      	jmp	0x3cb3 <perf_unwind_hotspot+0x3cb3>
    4ce8:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    4cf2:      	movq	%rax, 0x18(%rsp)
    4cf7:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    4d01:      	movq	%rax, 0x10(%rsp)
    4d06:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    4d10:      	movq	%rax, 0x8(%rsp)
    4d15:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    4d1f:      	movq	%rax, (%rsp)
    4d23:      	movw	$0xa, 0x20(%rsp)
    4d2a:      	movq	%rsp, %rdi
    4d2d:      	movl	$0x22, %eax
    4d32:      	movl	$0x6, %r8d
    4d38:      	movq	0x48(%rsp), %rcx
    4d3d:      	movl	$0x22, %esi
    4d42:      	movl	$0x1, %edx
    4d47:      	xorl	%eax, %eax
    4d49:      	callq	*%r8
    4d4c:      	jmp	0x3ce5 <perf_unwind_hotspot+0x3ce5>
    4d51:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    4d5b:      	movq	%rax, 0x18(%rsp)
    4d60:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    4d6a:      	movq	%rax, 0x10(%rsp)
    4d6f:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    4d79:      	movq	%rax, 0x8(%rsp)
    4d7e:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    4d88:      	movq	%rax, (%rsp)
    4d8c:      	movw	$0xa, 0x20(%rsp)
    4d93:      	movq	%rsp, %rdi
    4d96:      	movl	$0x22, %eax
    4d9b:      	movl	$0x6, %r8d
    4da1:      	movq	0x50(%rsp), %rcx
    4da6:      	movl	$0x22, %esi
    4dab:      	movl	$0x2, %edx
    4db0:      	xorl	%eax, %eax
    4db2:      	callq	*%r8
    4db5:      	jmp	0x3d46 <perf_unwind_hotspot+0x3d46>
    4dba:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    4dc4:      	movq	%rax, 0x68(%rsp)
    4dc9:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    4dd3:      	movq	%rax, 0x60(%rsp)
    4dd8:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    4de2:      	movq	%rax, 0x58(%rsp)
    4de7:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    4df1:      	movq	%rax, 0x50(%rsp)
    4df6:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    4e00:      	movq	%rax, 0x48(%rsp)
    4e05:      	movabsq	$0x6365732074786554, %r13 # imm = 0x6365732074786554
    4e0f:      	movq	%r13, 0x40(%rsp)
    4e14:      	movw	$0xa, 0x70(%rsp)
    4e1b:      	leaq	0x40(%rsp), %rdi
    4e20:      	movl	$0x32, %eax
    4e25:      	movl	$0x6, %r9d
    4e2b:      	movq	0xf10(%r14), %rcx
    4e32:      	movl	$0x32, %esi
    4e37:      	movq	%rbx, %rdx
    4e3a:      	movl	%r12d, %r8d
    4e3d:      	xorl	%eax, %eax
    4e3f:      	callq	*%r9
    4e42:      	movq	(%rip), %rax            # 0x4e49 <perf_unwind_hotspot+0x4e49>
    4e49:      	cmpl	$0x0, (%rax)
    4e4c:      	je	0x39e5 <perf_unwind_hotspot+0x39e5>
    4e52:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    4e5c:      	movq	%rax, 0x67(%rsp)
    4e61:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    4e6b:      	movq	%rax, 0x60(%rsp)
    4e70:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    4e7a:      	movq	%rax, 0x58(%rsp)
    4e7f:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    4e89:      	movq	%rax, 0x50(%rsp)
    4e8e:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    4e98:      	movq	%rax, 0x48(%rsp)
    4e9d:      	movq	%r13, 0x40(%rsp)
    4ea2:      	leaq	0x40(%rsp), %rdi
    4ea7:      	movl	$0x2f, %eax
    4eac:      	movl	$0x6, %r8d
    4eb2:      	movq	0xf18(%r14), %rcx
    4eb9:      	movq	0xf20(%r14), %rdx
    4ec0:      	movl	$0x2f, %esi
    4ec5:      	xorl	%eax, %eax
    4ec7:      	callq	*%r8
    4eca:      	jmp	0x39e5 <perf_unwind_hotspot+0x39e5>
    4ecf:      	movabsq	$0xa2964252b7073, %rax  # imm = 0xA2964252B7073
    4ed9:      	movq	%rax, 0x78(%rsp)
    4ede:      	movabsq	$0x206d6f7266282078, %rax # imm = 0x206D6F7266282078
    4ee8:      	movq	%rax, 0x70(%rsp)
    4eed:      	movabsq	$0x6c25783020736120, %rax # imm = 0x6C25783020736120
    4ef7:      	movq	%rax, 0x68(%rsp)
    4efc:      	movabsq	$0x64657265766f6365, %rax # imm = 0x64657265766F6365
    4f06:      	movq	%rax, 0x60(%rsp)
    4f0b:      	movabsq	$0x72206370202c656d, %rax # imm = 0x72206370202C656D
    4f15:      	movq	%rax, 0x58(%rsp)
    4f1a:      	movabsq	$0x6172662064657a69, %rax # imm = 0x6172662064657A69
    4f24:      	movq	%rax, 0x50(%rsp)
    4f29:      	movabsq	$0x6d6974706f656420, %rax # imm = 0x6D6974706F656420
    4f33:      	movq	%rax, 0x48(%rsp)
    4f38:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    4f42:      	movq	%rax, 0x40(%rsp)
    4f47:      	leaq	0x40(%rsp), %rdi
    4f4c:      	movl	$0x40, %eax
    4f51:      	movl	$0x6, %r8d
    4f57:      	movq	(%rsp), %rdx
    4f5b:      	movl	0xec(%rsp), %ecx
    4f62:      	movl	$0x40, %esi
    4f67:      	xorl	%eax, %eax
    4f69:      	callq	*%r8
    4f6c:      	movq	(%rsp), %rax
    4f70:      	movq	0xd0(%rsp), %rcx
    4f78:      	jmp	0x3c8f <perf_unwind_hotspot+0x3c8f>
    4f7d:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    4f87:      	movq	%rax, 0x18(%rsp)
    4f8c:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    4f96:      	movq	%rax, 0x10(%rsp)
    4f9b:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    4fa5:      	movq	%rax, 0x8(%rsp)
    4faa:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    4fb4:      	movq	%rax, (%rsp)
    4fb8:      	movw	$0xa, 0x20(%rsp)
    4fbf:      	movq	%rsp, %rdi
    4fc2:      	movl	$0x22, %eax
    4fc7:      	movl	$0x6, %r8d
    4fcd:      	movq	0x58(%rsp), %rcx
    4fd2:      	movl	$0x22, %esi
    4fd7:      	movl	$0x3, %edx
    4fdc:      	xorl	%eax, %eax
    4fde:      	callq	*%r8
    4fe1:      	jmp	0x3eb6 <perf_unwind_hotspot+0x3eb6>
    4fe6:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    4ff0:      	movq	%rax, 0x18(%rsp)
    4ff5:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    4fff:      	movq	%rax, 0x10(%rsp)
    5004:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    500e:      	movq	%rax, 0x8(%rsp)
    5013:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    501d:      	movq	%rax, (%rsp)
    5021:      	movw	$0xa, 0x20(%rsp)
    5028:      	movq	%rsp, %rdi
    502b:      	movl	$0x22, %eax
    5030:      	movl	$0x6, %r8d
    5036:      	movq	0x60(%rsp), %rcx
    503b:      	movl	$0x22, %esi
    5040:      	movl	$0x4, %edx
    5045:      	xorl	%eax, %eax
    5047:      	callq	*%r8
    504a:      	jmp	0x3f17 <perf_unwind_hotspot+0x3f17>
    504f:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    5059:      	movq	%rax, 0x55(%rsp)
    505e:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    5068:      	movq	%rax, 0x50(%rsp)
    506d:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    5077:      	movq	%rax, 0x48(%rsp)
    507c:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    5086:      	movq	%rax, 0x40(%rsp)
    508b:      	leaq	0x40(%rsp), %rdi
    5090:      	movl	$0x1d, %eax
    5095:      	movl	$0x6, %r8d
    509b:      	movzbl	(%rsp), %ecx
    509f:      	movl	$0x1d, %esi
    50a4:      	movq	%r13, %rdx
    50a7:      	xorl	%eax, %eax
    50a9:      	callq	*%r8
    50ac:      	movzbl	(%rsp), %eax
    50b0:      	leal	0x1(%rax), %ecx
    50b3:      	cmpb	$0x2, %cl
    50b6:      	jb	0x2ea0 <perf_unwind_hotspot+0x2ea0>
    50bc:      	jmp	0x35fe <perf_unwind_hotspot+0x35fe>
    50c1:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    50cb:      	movq	%rax, 0x18(%rsp)
    50d0:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    50da:      	movq	%rax, 0x10(%rsp)
    50df:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    50e9:      	movq	%rax, 0x8(%rsp)
    50ee:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    50f8:      	movq	%rax, (%rsp)
    50fc:      	movw	$0xa, 0x20(%rsp)
    5103:      	movq	%rsp, %rdi
    5106:      	movl	$0x22, %eax
    510b:      	movl	$0x6, %r8d
    5111:      	movq	0x68(%rsp), %rcx
    5116:      	movl	$0x22, %esi
    511b:      	movl	$0x5, %edx
    5120:      	xorl	%eax, %eax
    5122:      	callq	*%r8
    5125:      	jmp	0x406c <perf_unwind_hotspot+0x406c>
    512a:      	movabsq	$0xa786c25203d20, %rax  # imm = 0xA786C25203D20
    5134:      	movq	%rax, 0x2d(%rsp)
    5139:      	movabsq	$0x203d20706362202c, %rax # imm = 0x203D20706362202C
    5143:      	movq	%rax, 0x28(%rsp)
    5148:      	movabsq	$0x786c257830203d20, %rax # imm = 0x786C257830203D20
    5152:      	movq	%rax, 0x20(%rsp)
    5157:      	movabsq	$0x646f6874656d6320, %rax # imm = 0x646F6874656D6320
    5161:      	movq	%rax, 0x18(%rsp)
    5166:      	movabsq	$0x2c786c257830203d, %rax # imm = 0x2C786C257830203D
    5170:      	movq	%rax, 0x10(%rsp)
    5175:      	movabsq	$0x20646f6874656d20, %rax # imm = 0x20646F6874656D20
    517f:      	movq	%rax, 0x8(%rsp)
    5184:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    518e:      	movq	%rax, (%rsp)
    5192:      	movq	%rsp, %rdi
    5195:      	movl	$0x35, %eax
    519a:      	movl	$0x6, %r9d
    51a0:      	movq	0x100(%rsp), %rcx
    51a8:      	movl	$0x35, %esi
    51ad:      	movq	0x108(%rsp), %rdx
    51b5:      	movq	%r13, %r8
    51b8:      	xorl	%eax, %eax
    51ba:      	callq	*%r9
    51bd:      	movq	0x100(%rsp), %rax
    51c5:      	movq	%rax, 0xb8(%rsp)
    51cd:      	jmp	0x42a5 <perf_unwind_hotspot+0x42a5>
    51d2:      	movabsq	$0xa642520686374, %rax  # imm = 0xA642520686374
    51dc:      	movq	%rax, 0x56(%rsp)
    51e1:      	movabsq	$0x6374616d20737465, %rax # imm = 0x6374616D20737465
    51eb:      	movq	%rax, 0x50(%rsp)
    51f0:      	movabsq	$0x7366666f5f726574, %rax # imm = 0x7366666F5F726574
    51fa:      	movq	%rax, 0x48(%rsp)
    51ff:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    5209:      	movq	%rax, 0x40(%rsp)
    520e:      	leaq	0x40(%rsp), %rdi
    5213:      	movl	$0x1e, %eax
    5218:      	movl	$0x6, %ecx
    521d:      	movzwl	0x20(%rbx), %edx
    5221:      	movl	$0x1e, %esi
    5226:      	xorl	%eax, %eax
    5228:      	callq	*%rcx
    522a:      	movl	0x1380(%r14), %eax
    5231:      	movl	0x20(%rbx), %ecx
    5234:      	btl	%ecx, %eax
    5237:      	jb	0x3a6f <perf_unwind_hotspot+0x3a6f>
    523d:      	movl	$0x0, (%rsp)
    5244:      	movq	(%rip), %rdi            # 0x524b <perf_unwind_hotspot+0x524b>
    524b:      	movq	%rsp, %rsi
    524e:      	movl	$0x1, %eax
    5253:      	callq	*%rax
    5255:      	testq	%rax, %rax
    5258:      	je	0x525f <perf_unwind_hotspot+0x525f>
    525a:      	incq	(%rax)
    525d:      	jmp	0x526f <perf_unwind_hotspot+0x526f>
    525f:      	movq	(%rip), %rax            # 0x5266 <perf_unwind_hotspot+0x5266>
    5266:      	cmpl	$0x0, (%rax)
    5269:      	jne	0x63a8 <perf_unwind_hotspot+0x63a8>
    526f:      	movzwl	0x20(%rbx), %r12d
    5274:      	cmpl	$0x2, %r12d
    5278:      	jne	0x34c <perf_unwind_hotspot+0x34c>
    527e:      	movl	$0x29, 0xc8(%rsp)
    5289:      	movq	(%rip), %rdi            # 0x5290 <perf_unwind_hotspot+0x5290>
    5290:      	leaq	0xc8(%rsp), %rsi
    5298:      	movl	$0x1, %eax
    529d:      	callq	*%rax
    529f:      	testq	%rax, %rax
    52a2:      	je	0x5361 <perf_unwind_hotspot+0x5361>
    52a8:      	incq	(%rax)
    52ab:      	movq	(%rip), %rax            # 0x52b2 <perf_unwind_hotspot+0x52b2>
    52b2:      	cmpl	$0x0, (%rax)
    52b5:      	movq	0xed0(%r14), %r12
    52bc:      	movq	0xed8(%r14), %rax
    52c3:      	movq	%rax, 0x38(%rsp)
    52c8:      	movq	0xee0(%r14), %rax
    52cf:      	movq	%rax, 0xa8(%rsp)
    52d7:      	je	0x5393 <perf_unwind_hotspot+0x5393>
    52dd:      	movabsq	$0x252074657366666f, %rax # imm = 0x252074657366666F
    52e7:      	movq	%rax, 0x60(%rsp)
    52ec:      	movabsq	$0x202c786c25207472, %rax # imm = 0x202C786C25207472
    52f6:      	movq	%rax, 0x58(%rsp)
    52fb:      	movabsq	$0x6174732065646f63, %rax # imm = 0x6174732065646F63
    5305:      	movq	%rax, 0x50(%rsp)
    530a:      	movabsq	$0x206e6920786c2520, %rax # imm = 0x206E6920786C2520
    5314:      	movq	%rax, 0x48(%rsp)
    5319:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    5323:      	movq	%rax, 0x40(%rsp)
    5328:      	movl	$0xa786c, 0x68(%rsp)    # imm = 0xA786C
    5330:      	leaq	0x40(%rsp), %rdi
    5335:      	movl	$0x2c, %eax
    533a:      	movl	$0x6, %r9d
    5340:      	movq	0xf20(%r14), %rcx
    5347:      	movq	0xed0(%r14), %rdx
    534e:      	movq	0xf18(%r14), %r8
    5355:      	movl	$0x2c, %esi
    535a:      	xorl	%eax, %eax
    535c:      	callq	*%r9
    535f:      	jmp	0x5393 <perf_unwind_hotspot+0x5393>
    5361:      	movq	(%rip), %rax            # 0x5368 <perf_unwind_hotspot+0x5368>
    5368:      	cmpl	$0x0, (%rax)
    536b:      	jne	0x58bf <perf_unwind_hotspot+0x58bf>
    5371:      	movq	0xed0(%r14), %r12
    5378:      	movq	0xed8(%r14), %rax
    537f:      	movq	%rax, 0x38(%rsp)
    5384:      	movq	0xee0(%r14), %rax
    538b:      	movq	%rax, 0xa8(%rsp)
    5393:      	movzbl	0x20(%r15), %eax
    5398:      	shrxq	%rax, 0xf18(%r14), %r13
    53a1:      	movq	0xf10(%r14), %rbx
    53a8:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    53b2:      	andq	%rax, %rbx
    53b5:      	leaq	(%rbx,%r13), %rdx
    53b9:      	movq	%rsp, %rdi
    53bc:      	movl	$0x1, %eax
    53c1:      	movl	$0x70, %ecx
    53c6:      	movl	$0x1, %esi
    53cb:      	callq	*%rcx
    53cd:      	testq	%rax, %rax
    53d0:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    53d6:      	movq	(%rip), %rax            # 0x53dd <perf_unwind_hotspot+0x53dd>
    53dd:      	cmpl	$0x0, (%rax)
    53e0:      	jne	0x593d <perf_unwind_hotspot+0x593d>
    53e6:      	movzbl	(%rsp), %eax
    53ea:      	leal	0x1(%rax), %ecx
    53ed:      	cmpb	$0x2, %cl
    53f0:      	jae	0x59aa <perf_unwind_hotspot+0x59aa>
    53f6:      	testb	%al, %al
    53f8:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    53fe:      	movzbl	0x20(%r15), %eax
    5403:      	shlxq	%rax, %r13, %rax
    5408:      	addq	0xf20(%r14), %rax
    540f:      	movzbl	0x1b(%r15), %ebx
    5414:      	addq	%rax, %rbx
    5417:      	movq	(%rip), %rax            # 0x541e <perf_unwind_hotspot+0x541e>
    541e:      	cmpl	$0x0, (%rax)
    5421:      	jne	0x61d7 <perf_unwind_hotspot+0x61d7>
    5427:      	movq	%rbx, 0xc8(%rsp)
    542f:      	testq	%rbx, %rbx
    5432:      	je	0x237 <perf_unwind_hotspot+0x237>
    5438:      	movl	$0x200, %eax            # imm = 0x200
    543d:      	movl	$0x70, %ecx
    5442:      	movq	0x120(%rsp), %rdi
    544a:      	movq	0xc8(%rsp), %rdx
    5452:      	movl	$0x200, %esi            # imm = 0x200
    5457:      	callq	*%rcx
    5459:      	testq	%rax, %rax
    545c:      	jne	0x300 <perf_unwind_hotspot+0x300>
    5462:      	movzwl	0x10(%r15), %eax
    5467:      	movl	$0x1, %ebx
    546c:      	cmpq	$0x1f8, %rax            # imm = 0x1F8
    5472:      	ja	0x347 <perf_unwind_hotspot+0x347>
    5478:      	movzwl	0x12(%r15), %ecx
    547d:      	cmpq	$0x1fc, %rcx            # imm = 0x1FC
    5484:      	ja	0x347 <perf_unwind_hotspot+0x347>
    548a:      	movzwl	0x14(%r15), %edx
    548f:      	cmpq	$0x1f8, %rdx            # imm = 0x1F8
    5496:      	ja	0x347 <perf_unwind_hotspot+0x347>
    549c:      	movzbl	0x17(%r15), %esi
    54a1:      	movq	0x120(%rsp), %rdi
    54a9:      	movq	(%rdi,%rsi), %rsi
    54ad:      	movq	%rsi, 0xd0(%rsp)
    54b5:      	movzbl	0x18(%r15), %esi
    54ba:      	movq	(%rdi,%rsi), %rsi
    54be:      	movq	%rsi, 0xd8(%rsp)
    54c6:      	movzbl	0x1a(%r15), %esi
    54cb:      	movl	(%rdi,%rsi), %esi
    54ce:      	shll	$0x3, %esi
    54d1:      	movl	%esi, 0xf0(%rsp)
    54d8:      	movzbl	0x19(%r15), %esi
    54dd:      	movzwl	(%rdi,%rsi), %esi
    54e1:      	movw	%si, 0xf8(%rsp)
    54e9:      	movl	(%rdi,%rcx), %ecx
    54ec:      	movl	%ecx, 0xf4(%rsp)
    54f3:      	movl	(%rdi,%rdx), %ecx
    54f6:      	movl	%ecx, 0xec(%rsp)
    54fd:      	movq	(%rdi,%rax), %rax
    5501:      	movq	%rax, 0xe0(%rsp)
    5509:      	movzbl	0x16(%r15), %eax
    550e:      	movq	(%rdi,%rax), %rdx
    5512:      	movl	$0x4, %eax
    5517:      	movl	$0x70, %ecx
    551c:      	leaq	0xe8(%rsp), %rdi
    5524:      	movl	$0x4, %esi
    5529:      	callq	*%rcx
    552b:      	testq	%rax, %rax
    552e:      	jne	0x300 <perf_unwind_hotspot+0x300>
    5534:      	cmpb	$0x0, 0x21(%r15)
    5539:      	je	0x5567 <perf_unwind_hotspot+0x5567>
    553b:      	movq	0xc8(%rsp), %rax
    5543:      	movl	0xd0(%rsp), %ecx
    554a:      	addq	%rax, %rcx
    554d:      	movq	%rcx, 0xd0(%rsp)
    5555:      	movl	0xd8(%rsp), %ecx
    555c:      	addq	%rax, %rcx
    555f:      	movq	%rcx, 0xd8(%rsp)
    5567:      	movq	(%rip), %rax            # 0x556e <perf_unwind_hotspot+0x556e>
    556e:      	cmpl	$0x0, (%rax)
    5571:      	jne	0x6981 <perf_unwind_hotspot+0x6981>
    5577:      	movq	0xc8(%rsp), %rax
    557f:      	movq	%rax, 0xc0(%rsp)
    5587:      	movq	0xd0(%rsp), %rax
    558f:      	movl	0xe8(%rsp), %edx
    5596:      	movl	%r12d, %ecx
    5599:      	subl	%eax, %ecx
    559b:      	movq	%rcx, 0x118(%rsp)
    55a3:      	movq	%rdx, 0xb8(%rsp)
    55ab:      	cmpl	$0x6974616d, %edx       # imm = 0x6974616D
    55b1:      	jg	0x56a1 <perf_unwind_hotspot+0x56a1>
    55b7:      	cmpl	$0x62617476, 0xb8(%rsp) # imm = 0x62617476
    55c2:      	je	0x57e4 <perf_unwind_hotspot+0x57e4>
    55c8:      	cmpl	$0x65746e49, 0xb8(%rsp) # imm = 0x65746E49
    55d3:      	jne	0x581f <perf_unwind_hotspot+0x581f>
    55d9:      	movq	0x38(%rsp), %rax
    55de:      	cmpq	%rax, 0xa8(%rsp)
    55e6:      	jb	0x5c1b <perf_unwind_hotspot+0x5c1b>
    55ec:      	movq	0x38(%rsp), %rax
    55f1:      	addq	$0x1000, %rax           # imm = 0x1000
    55f7:      	cmpq	%rax, 0xa8(%rsp)
    55ff:      	jae	0x5c1b <perf_unwind_hotspot+0x5c1b>
    5605:      	movq	0xa8(%rsp), %rax
    560d:      	leaq	-0x50(%rax), %rdx
    5611:      	leaq	0x40(%rsp), %rdi
    5616:      	movl	$0x60, %eax
    561b:      	movl	$0x70, %ecx
    5620:      	movl	$0x60, %esi
    5625:      	callq	*%rcx
    5627:      	testq	%rax, %rax
    562a:      	je	0x6249 <perf_unwind_hotspot+0x6249>
    5630:      	movq	(%rip), %rax            # 0x5637 <perf_unwind_hotspot+0x5637>
    5637:      	cmpl	$0x0, (%rax)
    563a:      	je	0x5c2b <perf_unwind_hotspot+0x5c2b>
    5640:      	movabsq	$0xa656d61726620, %rax  # imm = 0xA656D61726620
    564a:      	movq	%rax, 0x1f(%rsp)
    564f:      	movabsq	$0x2072657465727072, %rax # imm = 0x2072657465727072
    5659:      	movq	%rax, 0x18(%rsp)
    565e:      	movabsq	$0x65746e6920646165, %rax # imm = 0x65746E6920646165
    5668:      	movq	%rax, 0x10(%rsp)
    566d:      	movabsq	$0x72206f742064656c, %rax # imm = 0x72206F742064656C
    5677:      	movq	%rax, 0x8(%rsp)
    567c:      	movabsq	$0x696166203a6d766a, %rax # imm = 0x696166203A6D766A
    5686:      	movq	%rax, (%rsp)
    568a:      	movq	%rsp, %rdi
    568d:      	movl	$0x27, %eax
    5692:      	movl	$0x6, %ecx
    5697:      	movl	$0x27, %esi
    569c:      	jmp	0x70db <perf_unwind_hotspot+0x70db>
    56a1:      	cmpl	$0x6974616e, 0xb8(%rsp) # imm = 0x6974616E
    56ac:      	je	0x56bf <perf_unwind_hotspot+0x56bf>
    56ae:      	cmpl	$0x74656d6e, 0xb8(%rsp) # imm = 0x74656D6E
    56b9:      	jne	0x581f <perf_unwind_hotspot+0x581f>
    56bf:      	movl	0xf4(%rsp), %ecx
    56c6:      	movq	%rcx, 0xb8(%rsp)
    56ce:      	movq	0xe0(%rsp), %rcx
    56d6:      	movl	%ecx, %edx
    56d8:      	addq	0xc0(%rsp), %rdx
    56e0:      	cmpb	$0x0, 0x21(%r15)
    56e5:      	cmoveq	%rcx, %rdx
    56e9:      	cmpq	%rdx, %r12
    56ec:      	jne	0x573e <perf_unwind_hotspot+0x573e>
    56ee:      	movl	0xec(%rsp), %eax
    56f5:      	movq	0x38(%rsp), %rsi
    56fa:      	addq	%rsi, %rax
    56fd:      	movq	%rsp, %rdi
    5700:      	movl	$0x8, %ecx
    5705:      	movl	$0x70, %r8d
    570b:      	movl	0xec(%rsp), %edx
    5712:      	addq	%rsi, %rdx
    5715:      	movl	$0x8, %esi
    571a:      	callq	*%r8
    571d:      	testq	%rax, %rax
    5720:      	je	0x6094 <perf_unwind_hotspot+0x6094>
    5726:      	movq	(%rip), %rax            # 0x572d <perf_unwind_hotspot+0x572d>
    572d:      	cmpl	$0x0, (%rax)
    5730:      	jne	0x6a85 <perf_unwind_hotspot+0x6a85>
    5736:      	movq	0xd0(%rsp), %rax
    573e:      	movzwl	0xf8(%rsp), %ecx
    5746:      	addq	%rax, %rcx
    5749:      	cmpq	%rcx, %r12
    574c:      	jae	0x5856 <perf_unwind_hotspot+0x5856>
    5752:      	addq	$-0x4, %rcx
    5756:      	movq	(%rip), %rax            # 0x575d <perf_unwind_hotspot+0x575d>
    575d:      	movl	(%rax), %eax
    575f:      	cmpq	%rcx, %r12
    5762:      	jae	0x5c5d <perf_unwind_hotspot+0x5c5d>
    5768:      	movb	$0x3, %cl
    576a:      	movl	%ecx, 0xb0(%rsp)
    5771:      	testl	%eax, %eax
    5773:      	je	0x580a <perf_unwind_hotspot+0x580a>
    5779:      	movabsq	$0x2963702820656d61, %rax # imm = 0x2963702820656D61
    5783:      	movq	%rax, 0x60(%rsp)
    5788:      	movabsq	$0x7266206574656c70, %rax # imm = 0x7266206574656C70
    5792:      	movq	%rax, 0x58(%rsp)
    5797:      	movabsq	$0x6d6f636e6920676e, %rax # imm = 0x6D6F636E6920676E
    57a1:      	movq	%rax, 0x50(%rsp)
    57a6:      	movabsq	$0x69646e69776e7520, %rax # imm = 0x69646E69776E7520
    57b0:      	movq	%rax, 0x48(%rsp)
    57b5:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    57bf:      	movq	%rax, 0x40(%rsp)
    57c4:      	movw	$0xa, 0x68(%rsp)
    57cb:      	leaq	0x40(%rsp), %rdi
    57d0:      	movl	$0x2a, %eax
    57d5:      	movl	$0x6, %ecx
    57da:      	movl	$0x2a, %esi
    57df:      	jmp	0x6b3d <perf_unwind_hotspot+0x6b3d>
    57e4:      	movb	$0x1, %al
    57e6:      	movl	%eax, 0xb0(%rsp)
    57ed:      	movl	$0x62617476, %eax       # imm = 0x62617476
    57f2:      	movq	%rax, 0xb8(%rsp)
    57fa:      	movq	(%rip), %rax            # 0x5801 <perf_unwind_hotspot+0x5801>
    5801:      	cmpl	$0x0, (%rax)
    5804:      	jne	0x6afc <perf_unwind_hotspot+0x6afc>
    580a:      	movl	$0x8, 0xf0(%rsp)
    5815:      	movl	$0x8, %eax
    581a:      	jmp	0x5c88 <perf_unwind_hotspot+0x5c88>
    581f:      	movq	(%rip), %rax            # 0x5826 <perf_unwind_hotspot+0x5826>
    5826:      	cmpl	$0x0, (%rax)
    5829:      	jne	0x6b46 <perf_unwind_hotspot+0x6b46>
    582f:      	movl	0xf0(%rsp), %eax
    5836:      	movl	$0x0, 0xb0(%rsp)
    5841:      	movq	0xa8(%rsp), %rcx
    5849:      	testl	%eax, %eax
    584b:      	jne	0x5c88 <perf_unwind_hotspot+0x5c88>
    5851:      	jmp	0x5c73 <perf_unwind_hotspot+0x5c73>
    5856:      	movl	0xf0(%rsp), %ebx
    585d:      	movq	0xa8(%rsp), %rdx
    5865:      	movq	0x38(%rsp), %rax
    586a:      	leaq	(%rax,%rbx), %rcx
    586e:      	addq	$0x30, %rcx
    5872:      	movq	%rcx, 0x108(%rsp)
    587a:      	subq	%rax, %rdx
    587d:      	jb	0x5f84 <perf_unwind_hotspot+0x5f84>
    5883:      	movq	0x108(%rsp), %rax
    588b:      	cmpq	%rax, 0xa8(%rsp)
    5893:      	jae	0x5f84 <perf_unwind_hotspot+0x5f84>
    5899:      	movb	$0x3, %al
    589b:      	movl	%eax, 0xb0(%rsp)
    58a2:      	movq	(%rip), %rax            # 0x58a9 <perf_unwind_hotspot+0x58a9>
    58a9:      	cmpl	$0x0, (%rax)
    58ac:      	jne	0x6ba7 <perf_unwind_hotspot+0x6ba7>
    58b2:      	movq	0xa8(%rsp), %rcx
    58ba:      	jmp	0x5c73 <perf_unwind_hotspot+0x5c73>
    58bf:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    58c9:      	movq	%rax, 0x66(%rsp)
    58ce:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    58d8:      	movq	%rax, 0x60(%rsp)
    58dd:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    58e7:      	movq	%rax, 0x58(%rsp)
    58ec:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    58f6:      	movq	%rax, 0x50(%rsp)
    58fb:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    5905:      	movq	%rax, 0x48(%rsp)
    590a:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5914:      	movq	%rax, 0x40(%rsp)
    5919:      	leaq	0x40(%rsp), %rdi
    591e:      	movl	$0x2e, %eax
    5923:      	movl	$0x6, %ecx
    5928:      	movl	0xc8(%rsp), %edx
    592f:      	movl	$0x2e, %esi
    5934:      	xorl	%eax, %eax
    5936:      	callq	*%rcx
    5938:      	jmp	0x52ab <perf_unwind_hotspot+0x52ab>
    593d:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    5947:      	movq	%rax, 0x55(%rsp)
    594c:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    5956:      	movq	%rax, 0x50(%rsp)
    595b:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    5965:      	movq	%rax, 0x48(%rsp)
    596a:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    5974:      	movq	%rax, 0x40(%rsp)
    5979:      	leaq	0x40(%rsp), %rdi
    597e:      	movl	$0x1d, %eax
    5983:      	movl	$0x6, %r8d
    5989:      	movzbl	(%rsp), %ecx
    598d:      	movl	$0x1d, %esi
    5992:      	movq	%r13, %rdx
    5995:      	xorl	%eax, %eax
    5997:      	callq	*%r8
    599a:      	movzbl	(%rsp), %eax
    599e:      	leal	0x1(%rax), %ecx
    59a1:      	cmpb	$0x2, %cl
    59a4:      	jb	0x53f6 <perf_unwind_hotspot+0x53f6>
    59aa:      	movzbl	%al, %eax
    59ad:      	subq	%rax, %r13
    59b0:      	leaq	(%rbx,%r13), %rdx
    59b4:      	movq	%rsp, %rdi
    59b7:      	movl	$0x1, %eax
    59bc:      	movl	$0x70, %ecx
    59c1:      	movl	$0x1, %esi
    59c6:      	callq	*%rcx
    59c8:      	testq	%rax, %rax
    59cb:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    59d1:      	movq	(%rip), %rax            # 0x59d8 <perf_unwind_hotspot+0x59d8>
    59d8:      	cmpl	$0x0, (%rax)
    59db:      	jne	0x626c <perf_unwind_hotspot+0x626c>
    59e1:      	movzbl	(%rsp), %eax
    59e5:      	leal	0x1(%rax), %ecx
    59e8:      	cmpb	$0x2, %cl
    59eb:      	jb	0x53f6 <perf_unwind_hotspot+0x53f6>
    59f1:      	movzbl	%al, %eax
    59f4:      	subq	%rax, %r13
    59f7:      	leaq	(%rbx,%r13), %rdx
    59fb:      	movq	%rsp, %rdi
    59fe:      	movl	$0x1, %eax
    5a03:      	movl	$0x70, %ecx
    5a08:      	movl	$0x1, %esi
    5a0d:      	callq	*%rcx
    5a0f:      	testq	%rax, %rax
    5a12:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    5a18:      	movq	(%rip), %rax            # 0x5a1f <perf_unwind_hotspot+0x5a1f>
    5a1f:      	cmpl	$0x0, (%rax)
    5a22:      	jne	0x672a <perf_unwind_hotspot+0x672a>
    5a28:      	movzbl	(%rsp), %eax
    5a2c:      	leal	0x1(%rax), %ecx
    5a2f:      	cmpb	$0x2, %cl
    5a32:      	jb	0x53f6 <perf_unwind_hotspot+0x53f6>
    5a38:      	movzbl	%al, %eax
    5a3b:      	subq	%rax, %r13
    5a3e:      	leaq	(%rbx,%r13), %rdx
    5a42:      	movq	%rsp, %rdi
    5a45:      	movl	$0x1, %eax
    5a4a:      	movl	$0x70, %ecx
    5a4f:      	movl	$0x1, %esi
    5a54:      	callq	*%rcx
    5a56:      	testq	%rax, %rax
    5a59:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    5a5f:      	movq	(%rip), %rax            # 0x5a66 <perf_unwind_hotspot+0x5a66>
    5a66:      	cmpl	$0x0, (%rax)
    5a69:      	jne	0x682b <perf_unwind_hotspot+0x682b>
    5a6f:      	movzbl	(%rsp), %eax
    5a73:      	leal	0x1(%rax), %ecx
    5a76:      	cmpb	$0x2, %cl
    5a79:      	jb	0x53f6 <perf_unwind_hotspot+0x53f6>
    5a7f:      	movzbl	%al, %eax
    5a82:      	subq	%rax, %r13
    5a85:      	leaq	(%rbx,%r13), %rdx
    5a89:      	movq	%rsp, %rdi
    5a8c:      	movl	$0x1, %eax
    5a91:      	movl	$0x70, %ecx
    5a96:      	movl	$0x1, %esi
    5a9b:      	callq	*%rcx
    5a9d:      	testq	%rax, %rax
    5aa0:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    5aa6:      	movq	(%rip), %rax            # 0x5aad <perf_unwind_hotspot+0x5aad>
    5aad:      	cmpl	$0x0, (%rax)
    5ab0:      	jne	0x6c26 <perf_unwind_hotspot+0x6c26>
    5ab6:      	movzbl	(%rsp), %eax
    5aba:      	leal	0x1(%rax), %ecx
    5abd:      	cmpb	$0x2, %cl
    5ac0:      	jb	0x53f6 <perf_unwind_hotspot+0x53f6>
    5ac6:      	movzbl	%al, %eax
    5ac9:      	subq	%rax, %r13
    5acc:      	leaq	(%rbx,%r13), %rdx
    5ad0:      	movq	%rsp, %rdi
    5ad3:      	movl	$0x1, %eax
    5ad8:      	movl	$0x70, %ecx
    5add:      	movl	$0x1, %esi
    5ae2:      	callq	*%rcx
    5ae4:      	testq	%rax, %rax
    5ae7:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    5aed:      	movq	(%rip), %rax            # 0x5af4 <perf_unwind_hotspot+0x5af4>
    5af4:      	cmpl	$0x0, (%rax)
    5af7:      	jne	0x6c98 <perf_unwind_hotspot+0x6c98>
    5afd:      	movzbl	(%rsp), %eax
    5b01:      	leal	0x1(%rax), %ecx
    5b04:      	cmpb	$0x2, %cl
    5b07:      	jb	0x53f6 <perf_unwind_hotspot+0x53f6>
    5b0d:      	movzbl	%al, %eax
    5b10:      	subq	%rax, %r13
    5b13:      	leaq	(%rbx,%r13), %rdx
    5b17:      	movq	%rsp, %rdi
    5b1a:      	movl	$0x1, %eax
    5b1f:      	movl	$0x70, %ecx
    5b24:      	movl	$0x1, %esi
    5b29:      	callq	*%rcx
    5b2b:      	testq	%rax, %rax
    5b2e:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    5b34:      	movq	(%rip), %rax            # 0x5b3b <perf_unwind_hotspot+0x5b3b>
    5b3b:      	cmpl	$0x0, (%rax)
    5b3e:      	jne	0x6d0a <perf_unwind_hotspot+0x6d0a>
    5b44:      	movzbl	(%rsp), %eax
    5b48:      	leal	0x1(%rax), %ecx
    5b4b:      	cmpb	$0x2, %cl
    5b4e:      	jb	0x53f6 <perf_unwind_hotspot+0x53f6>
    5b54:      	movzbl	%al, %eax
    5b57:      	subq	%rax, %r13
    5b5a:      	leaq	(%rbx,%r13), %rdx
    5b5e:      	movq	%rsp, %rdi
    5b61:      	movl	$0x1, %eax
    5b66:      	movl	$0x70, %ecx
    5b6b:      	movl	$0x1, %esi
    5b70:      	callq	*%rcx
    5b72:      	testq	%rax, %rax
    5b75:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    5b7b:      	movq	(%rip), %rax            # 0x5b82 <perf_unwind_hotspot+0x5b82>
    5b82:      	cmpl	$0x0, (%rax)
    5b85:      	jne	0x6d7c <perf_unwind_hotspot+0x6d7c>
    5b8b:      	movzbl	(%rsp), %eax
    5b8f:      	leal	0x1(%rax), %ecx
    5b92:      	cmpb	$0x2, %cl
    5b95:      	jb	0x53f6 <perf_unwind_hotspot+0x53f6>
    5b9b:      	jmp	0x6de9 <perf_unwind_hotspot+0x6de9>
    5ba0:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    5baa:      	movq	%rax, 0x26(%rsp)
    5baf:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    5bb9:      	movq	%rax, 0x20(%rsp)
    5bbe:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    5bc8:      	movq	%rax, 0x18(%rsp)
    5bcd:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    5bd7:      	movq	%rax, 0x10(%rsp)
    5bdc:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    5be6:      	movq	%rax, 0x8(%rsp)
    5beb:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5bf5:      	movq	%rax, (%rsp)
    5bf9:      	movq	%rsp, %rdi
    5bfc:      	movl	$0x2e, %eax
    5c01:      	movl	$0x6, %ecx
    5c06:      	movl	0x100(%rsp), %edx
    5c0d:      	movl	$0x2e, %esi
    5c12:      	xorl	%eax, %eax
    5c14:      	callq	*%rcx
    5c16:      	jmp	0x4374 <perf_unwind_hotspot+0x4374>
    5c1b:      	movq	(%rip), %rax            # 0x5c22 <perf_unwind_hotspot+0x5c22>
    5c22:      	cmpl	$0x0, (%rax)
    5c25:      	jne	0x7070 <perf_unwind_hotspot+0x7070>
    5c2b:      	movl	$0x2d, 0x114(%rsp)
    5c36:      	movq	(%rip), %rdi            # 0x5c3d <perf_unwind_hotspot+0x5c3d>
    5c3d:      	leaq	0x114(%rsp), %rsi
    5c45:      	movl	$0x1, %eax
    5c4a:      	callq	*%rax
    5c4c:      	testq	%rax, %rax
    5c4f:      	je	0x60db <perf_unwind_hotspot+0x60db>
    5c55:      	incq	(%rax)
    5c58:      	jmp	0x60eb <perf_unwind_hotspot+0x60eb>
    5c5d:      	movb	$0x3, %cl
    5c5f:      	movl	%ecx, 0xb0(%rsp)
    5c66:      	testl	%eax, %eax
    5c68:      	jne	0x70e4 <perf_unwind_hotspot+0x70e4>
    5c6e:      	movq	0x38(%rsp), %rcx
    5c73:      	movl	$0x10, 0xf0(%rsp)
    5c7e:      	movl	$0x10, %eax
    5c83:      	movq	%rcx, 0x38(%rsp)
    5c88:      	movl	%eax, %eax
    5c8a:      	addq	%rax, 0x38(%rsp)
    5c8f:      	movq	0x38(%rsp), %rax
    5c94:      	leaq	-0x10(%rax), %rdx
    5c98:      	movq	%rsp, %rdi
    5c9b:      	movl	$0x10, %eax
    5ca0:      	movl	$0x70, %ecx
    5ca5:      	movl	$0x10, %esi
    5caa:      	callq	*%rcx
    5cac:      	movq	0x8(%rsp), %r12
    5cb1:      	cmpl	$0x10, 0xf0(%rsp)
    5cb9:      	jb	0x5cd7 <perf_unwind_hotspot+0x5cd7>
    5cbb:      	movq	(%rip), %rax            # 0x5cc2 <perf_unwind_hotspot+0x5cc2>
    5cc2:      	cmpl	$0x0, (%rax)
    5cc5:      	jne	0x715b <perf_unwind_hotspot+0x715b>
    5ccb:      	movq	(%rsp), %rax
    5ccf:      	movq	%rax, 0xa8(%rsp)
    5cd7:      	movl	0x2c0(%r14), %eax
    5cde:      	cmpq	$0x7e, %rax
    5ce2:      	ja	0xf03 <perf_unwind_hotspot+0xf03>
    5ce8:      	movzbl	0xf30(%r14), %ecx
    5cf0:      	movzbl	0xb0(%rsp), %edx
    5cf8:      	shlq	$0x3c, %rdx
    5cfc:      	movq	0x118(%rsp), %rdi
    5d04:      	shlq	$0x20, %rdi
    5d08:      	movl	0xb8(%rsp), %esi
    5d0f:      	orq	%rdi, %rsi
    5d12:      	orq	%rdx, %rsi
    5d15:      	leal	0x1(%rax), %edx
    5d18:      	movl	%edx, 0x2c0(%r14)
    5d1f:      	leaq	(%rax,%rax,2), %rax
    5d23:      	movq	0xc0(%rsp), %rdx
    5d2b:      	movq	%rdx, 0x2d0(%r14,%rax,8)
    5d33:      	movq	%rsi, 0x2d8(%r14,%rax,8)
    5d3b:      	movb	$0x5, 0x2e0(%r14,%rax,8)
    5d44:      	movb	%cl, 0x2e1(%r14,%rax,8)
    5d4c:      	movl	$0x0, 0x2e2(%r14,%rax,8)
    5d58:      	movw	$0x0, 0x2e6(%r14,%rax,8)
    5d63:      	movq	(%rip), %rax            # 0x5d6a <perf_unwind_hotspot+0x5d6a>
    5d6a:      	cmpl	$0x0, (%rax)
    5d6d:      	jne	0x71a5 <perf_unwind_hotspot+0x71a5>
    5d73:      	movq	%r12, 0xed0(%r14)
    5d7a:      	movq	0x38(%rsp), %rax
    5d7f:      	movq	%rax, 0xed8(%r14)
    5d86:      	movq	0xa8(%rsp), %rax
    5d8e:      	movq	%rax, 0xee0(%r14)
    5d95:      	movb	$0x1, 0xf30(%r14)
    5d9d:      	movl	$0x2a, (%rsp)
    5da4:      	movq	(%rip), %rdi            # 0x5dab <perf_unwind_hotspot+0x5dab>
    5dab:      	movq	%rsp, %rsi
    5dae:      	movl	$0x1, %eax
    5db3:      	callq	*%rax
    5db5:      	testq	%rax, %rax
    5db8:      	je	0x5dc8 <perf_unwind_hotspot+0x5dc8>
    5dba:      	incq	(%rax)
    5dbd:      	movq	(%rip), %rax            # 0x5dc4 <perf_unwind_hotspot+0x5dc4>
    5dc4:      	movl	(%rax), %eax
    5dc6:      	jmp	0x5dda <perf_unwind_hotspot+0x5dda>
    5dc8:      	xorl	%eax, %eax
    5dca:      	movq	(%rip), %rcx            # 0x5dd1 <perf_unwind_hotspot+0x5dd1>
    5dd1:      	cmpl	$0x0, (%rcx)
    5dd4:      	jne	0x7218 <perf_unwind_hotspot+0x7218>
    5dda:      	movq	0xed0(%r14), %rbx
    5de1:      	testq	%rbx, %rbx
    5de4:      	je	0x9ceb <perf_unwind_hotspot+0x9ceb>
    5dea:      	testl	%eax, %eax
    5dec:      	jne	0x7292 <perf_unwind_hotspot+0x7292>
    5df2:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    5dfc:      	cmpq	%rax, %rbx
    5dff:      	ja	0x1049 <perf_unwind_hotspot+0x1049>
    5e05:      	cmpq	$0x1000, %rbx           # imm = 0x1000
    5e0c:      	jb	0x1fa2 <perf_unwind_hotspot+0x1fa2>
    5e12:      	movl	(%r14), %eax
    5e15:      	movl	$0x60, 0xc8(%rsp)
    5e20:      	movbel	%eax, 0xcc(%rsp)
    5e29:      	movbeq	%rbx, 0xd0(%rsp)
    5e33:      	movq	(%rip), %rdi            # 0x5e3a <perf_unwind_hotspot+0x5e3a>
    5e3a:      	leaq	0xc8(%rsp), %rsi
    5e42:      	movl	$0x1, %eax
    5e47:      	callq	*%rax
    5e49:      	testq	%rax, %rax
    5e4c:      	je	0x9d07 <perf_unwind_hotspot+0x9d07>
    5e52:      	movq	0x8(%rax), %r12
    5e56:      	movq	%r12, %rcx
    5e59:      	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    5e63:      	andq	%rdx, %rcx
    5e66:      	movq	%rcx, 0xf20(%r14)
    5e6d:      	movq	(%rax), %rax
    5e70:      	movq	%rax, 0xf10(%r14)
    5e77:      	shrq	$0x38, %r12
    5e7b:      	movq	%rbx, %rax
    5e7e:      	subq	%rcx, %rax
    5e81:      	movq	%rax, 0xf18(%r14)
    5e88:      	movq	(%rip), %rax            # 0x5e8f <perf_unwind_hotspot+0x5e8f>
    5e8f:      	cmpl	$0x0, (%rax)
    5e92:      	jne	0x732f <perf_unwind_hotspot+0x732f>
    5e98:      	cmpl	$0x1, %r12d
    5e9c:      	jne	0x7a93 <perf_unwind_hotspot+0x7a93>
    5ea2:      	movq	0xf10(%r14), %rax
    5ea9:      	movq	%rax, 0xc8(%rsp)
    5eb1:      	movq	0xf18(%r14), %r13
    5eb8:      	movq	(%rip), %rdi            # 0x5ebf <perf_unwind_hotspot+0x5ebf>
    5ebf:      	leaq	0xc8(%rsp), %rsi
    5ec7:      	movl	$0x1, %eax
    5ecc:      	callq	*%rax
    5ece:      	movl	$0x1, %r12d
    5ed4:      	testq	%rax, %rax
    5ed7:      	je	0x7a93 <perf_unwind_hotspot+0x7a93>
    5edd:      	movq	%rax, %rbx
    5ee0:      	cmpq	%r13, (%rax)
    5ee3:      	ja	0x5eeb <perf_unwind_hotspot+0x5eeb>
    5ee5:      	cmpq	%r13, 0x8(%rbx)
    5ee9:      	jae	0x5eff <perf_unwind_hotspot+0x5eff>
    5eeb:      	cmpq	%r13, 0x10(%rbx)
    5eef:      	ja	0x7a93 <perf_unwind_hotspot+0x7a93>
    5ef5:      	cmpq	%r13, 0x18(%rbx)
    5ef9:      	jb	0x7a93 <perf_unwind_hotspot+0x7a93>
    5eff:      	movq	(%rip), %rax            # 0x5f06 <perf_unwind_hotspot+0x5f06>
    5f06:      	cmpl	$0x0, (%rax)
    5f09:      	jne	0x7444 <perf_unwind_hotspot+0x7444>
    5f0f:      	movl	0x1380(%r14), %eax
    5f16:      	movl	0x20(%rbx), %ecx
    5f19:      	btl	%ecx, %eax
    5f1c:      	jae	0x74af <perf_unwind_hotspot+0x74af>
    5f22:      	movq	(%rip), %rax            # 0x5f29 <perf_unwind_hotspot+0x5f29>
    5f29:      	cmpl	$0x0, (%rax)
    5f2c:      	je	0x7a93 <perf_unwind_hotspot+0x7a93>
    5f32:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    5f3c:      	movq	%rax, 0x50(%rsp)
    5f41:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    5f4b:      	movq	%rax, 0x48(%rsp)
    5f50:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    5f5a:      	movq	%rax, 0x40(%rsp)
    5f5f:      	movl	$0xa656e, 0x57(%rsp)    # imm = 0xA656E
    5f67:      	leaq	0x40(%rsp), %rdi
    5f6c:      	movl	$0x1b, %eax
    5f71:      	movl	$0x6, %ecx
    5f76:      	movl	$0x1b, %esi
    5f7b:      	xorl	%eax, %eax
    5f7d:      	callq	*%rcx
    5f7f:      	jmp	0x7a93 <perf_unwind_hotspot+0x7a93>
    5f84:      	movq	0x38(%rsp), %rax
    5f89:      	leaq	(%rax,%rbx), %rdx
    5f8d:      	addq	$-0x8, %rdx
    5f91:      	leaq	0x40(%rsp), %rdi
    5f96:      	movl	$0x30, %eax
    5f9b:      	movl	$0x70, %ecx
    5fa0:      	movl	$0x30, %esi
    5fa5:      	callq	*%rcx
    5fa7:      	movq	(%rip), %rax            # 0x5fae <perf_unwind_hotspot+0x5fae>
    5fae:      	cmpl	$0x0, (%rax)
    5fb1:      	jne	0x74d8 <perf_unwind_hotspot+0x74d8>
    5fb7:      	movl	(%r14), %eax
    5fba:      	movl	$0x60, (%rsp)
    5fc1:      	movbel	%eax, 0x4(%rsp)
    5fc7:      	addq	%rbx, 0x38(%rsp)
    5fcc:      	movq	0x40(%rsp), %rax
    5fd1:      	movbeq	%rax, 0x8(%rsp)
    5fd8:      	movabsq	$-0x100000000000000, %rbx # imm = 0xFF00000000000000
    5fe2:      	movabsq	$0x200000000000000, %r13 # imm = 0x200000000000000
    5fec:      	movq	(%rip), %rdi            # 0x5ff3 <perf_unwind_hotspot+0x5ff3>
    5ff3:      	movq	%rsp, %rsi
    5ff6:      	movl	$0x1, %eax
    5ffb:      	callq	*%rax
    5ffd:      	testq	%rax, %rax
    6000:      	je	0x610d <perf_unwind_hotspot+0x610d>
    6006:      	movq	0x8(%rax), %rax
    600a:      	andq	%rbx, %rax
    600d:      	xorl	%edx, %edx
    600f:      	cmpq	%r13, %rax
    6012:      	jne	0x610d <perf_unwind_hotspot+0x610d>
    6018:      	movq	0x38(%rsp), %rax
    601d:      	jmp	0x64f5 <perf_unwind_hotspot+0x64f5>
    6022:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    602c:      	movq	%rax, 0x55(%rsp)
    6031:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    603b:      	movq	%rax, 0x50(%rsp)
    6040:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    604a:      	movq	%rax, 0x48(%rsp)
    604f:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    6059:      	movq	%rax, 0x40(%rsp)
    605e:      	leaq	0x40(%rsp), %rdi
    6063:      	movl	$0x1d, %eax
    6068:      	movl	$0x6, %r8d
    606e:      	movzbl	(%rsp), %ecx
    6072:      	movl	$0x1d, %esi
    6077:      	movq	%r13, %rdx
    607a:      	xorl	%eax, %eax
    607c:      	callq	*%r8
    607f:      	movzbl	(%rsp), %eax
    6083:      	leal	0x1(%rax), %ecx
    6086:      	cmpb	$0x2, %cl
    6089:      	jb	0x2ea0 <perf_unwind_hotspot+0x2ea0>
    608f:      	jmp	0x3645 <perf_unwind_hotspot+0x3645>
    6094:      	movq	(%rsp), %rax
    6098:      	movq	0xd0(%rsp), %rcx
    60a0:      	cmpq	%rcx, %rax
    60a3:      	jb	0x5726 <perf_unwind_hotspot+0x5726>
    60a9:      	cmpq	0xd8(%rsp), %rax
    60b1:      	jae	0x5726 <perf_unwind_hotspot+0x5726>
    60b7:      	movq	(%rip), %rdx            # 0x60be <perf_unwind_hotspot+0x60be>
    60be:      	cmpl	$0x0, (%rdx)
    60c1:      	jne	0x753e <perf_unwind_hotspot+0x753e>
    60c7:      	movl	%eax, %edx
    60c9:      	subl	%ecx, %edx
    60cb:      	movq	%rdx, 0x118(%rsp)
    60d3:      	movq	%rax, %r12
    60d6:      	jmp	0x5736 <perf_unwind_hotspot+0x5736>
    60db:      	movq	(%rip), %rax            # 0x60e2 <perf_unwind_hotspot+0x60e2>
    60e2:      	cmpl	$0x0, (%rax)
    60e5:      	jne	0x75ec <perf_unwind_hotspot+0x75ec>
    60eb:      	movl	$0x3e9, %ebx            # imm = 0x3E9
    60f0:      	xorl	%r13d, %r13d
    60f3:      	movl	$0x65746e49, %eax       # imm = 0x65746E49
    60f8:      	movq	%rax, 0xb8(%rsp)
    6100:      	testl	%ebx, %ebx
    6102:      	jne	0x347 <perf_unwind_hotspot+0x347>
    6108:      	jmp	0x6533 <perf_unwind_hotspot+0x6533>
    610d:      	movq	(%rip), %rax            # 0x6114 <perf_unwind_hotspot+0x6114>
    6114:      	cmpl	$0x0, (%rax)
    6117:      	jne	0x7667 <perf_unwind_hotspot+0x7667>
    611d:      	movl	(%r14), %eax
    6120:      	movl	$0x60, (%rsp)
    6127:      	movbel	%eax, 0x4(%rsp)
    612d:      	movq	0x48(%rsp), %rax
    6132:      	movbeq	%rax, 0x8(%rsp)
    6139:      	movq	(%rip), %rdi            # 0x6140 <perf_unwind_hotspot+0x6140>
    6140:      	movq	%rsp, %rsi
    6143:      	movl	$0x1, %eax
    6148:      	callq	*%rax
    614a:      	testq	%rax, %rax
    614d:      	je	0x616e <perf_unwind_hotspot+0x616e>
    614f:      	movq	0x8(%rax), %rax
    6153:      	andq	%rbx, %rax
    6156:      	cmpq	%r13, %rax
    6159:      	jne	0x616e <perf_unwind_hotspot+0x616e>
    615b:      	movq	0x38(%rsp), %rax
    6160:      	addq	$0x8, %rax
    6164:      	movl	$0x1, %edx
    6169:      	jmp	0x64f5 <perf_unwind_hotspot+0x64f5>
    616e:      	movq	(%rip), %rax            # 0x6175 <perf_unwind_hotspot+0x6175>
    6175:      	cmpl	$0x0, (%rax)
    6178:      	jne	0x76d0 <perf_unwind_hotspot+0x76d0>
    617e:      	movl	(%r14), %eax
    6181:      	movl	$0x60, (%rsp)
    6188:      	movbel	%eax, 0x4(%rsp)
    618e:      	movq	0x50(%rsp), %rax
    6193:      	movbeq	%rax, 0x8(%rsp)
    619a:      	movq	(%rip), %rdi            # 0x61a1 <perf_unwind_hotspot+0x61a1>
    61a1:      	movq	%rsp, %rsi
    61a4:      	movl	$0x1, %eax
    61a9:      	callq	*%rax
    61ab:      	testq	%rax, %rax
    61ae:      	je	0x62de <perf_unwind_hotspot+0x62de>
    61b4:      	movq	0x8(%rax), %rax
    61b8:      	andq	%rbx, %rax
    61bb:      	cmpq	%r13, %rax
    61be:      	jne	0x62de <perf_unwind_hotspot+0x62de>
    61c4:      	movq	0x38(%rsp), %rax
    61c9:      	addq	$0x10, %rax
    61cd:      	movl	$0x2, %edx
    61d2:      	jmp	0x64f5 <perf_unwind_hotspot+0x64f5>
    61d7:      	movabsq	$0xa786c2520626f6c, %rax # imm = 0xA786C2520626F6C
    61e1:      	movq	%rax, 0x58(%rsp)
    61e6:      	movabsq	$0x6265646f63206f74, %rax # imm = 0x6265646F63206F74
    61f0:      	movq	%rax, 0x50(%rsp)
    61f5:      	movabsq	$0x2064657070616d20, %rax # imm = 0x2064657070616D20
    61ff:      	movq	%rax, 0x48(%rsp)
    6204:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    620e:      	movq	%rax, 0x40(%rsp)
    6213:      	movb	$0x0, 0x60(%rsp)
    6218:      	leaq	0x40(%rsp), %rdi
    621d:      	movl	$0x21, %eax
    6222:      	movl	$0x6, %ecx
    6227:      	movl	$0x21, %esi
    622c:      	movq	%rbx, %rdx
    622f:      	xorl	%eax, %eax
    6231:      	callq	*%rcx
    6233:      	movq	%rbx, 0xc8(%rsp)
    623b:      	testq	%rbx, %rbx
    623e:      	jne	0x5438 <perf_unwind_hotspot+0x5438>
    6244:      	jmp	0x237 <perf_unwind_hotspot+0x237>
    6249:      	cmpl	$0x0, 0x2c0(%r14)
    6251:      	je	0x6589 <perf_unwind_hotspot+0x6589>
    6257:      	cmpb	$0x0, 0x1f(%r15)
    625c:      	je	0x65c4 <perf_unwind_hotspot+0x65c4>
    6262:      	movq	0x50(%rsp), %r13
    6267:      	jmp	0x65c9 <perf_unwind_hotspot+0x65c9>
    626c:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    6276:      	movq	%rax, 0x55(%rsp)
    627b:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    6285:      	movq	%rax, 0x50(%rsp)
    628a:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    6294:      	movq	%rax, 0x48(%rsp)
    6299:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    62a3:      	movq	%rax, 0x40(%rsp)
    62a8:      	leaq	0x40(%rsp), %rdi
    62ad:      	movl	$0x1d, %eax
    62b2:      	movl	$0x6, %r8d
    62b8:      	movzbl	(%rsp), %ecx
    62bc:      	movl	$0x1d, %esi
    62c1:      	movq	%r13, %rdx
    62c4:      	xorl	%eax, %eax
    62c6:      	callq	*%r8
    62c9:      	movzbl	(%rsp), %eax
    62cd:      	leal	0x1(%rax), %ecx
    62d0:      	cmpb	$0x2, %cl
    62d3:      	jb	0x53f6 <perf_unwind_hotspot+0x53f6>
    62d9:      	jmp	0x59f1 <perf_unwind_hotspot+0x59f1>
    62de:      	movq	(%rip), %rax            # 0x62e5 <perf_unwind_hotspot+0x62e5>
    62e5:      	cmpl	$0x0, (%rax)
    62e8:      	jne	0x7739 <perf_unwind_hotspot+0x7739>
    62ee:      	movl	(%r14), %eax
    62f1:      	movl	$0x60, (%rsp)
    62f8:      	movbel	%eax, 0x4(%rsp)
    62fe:      	movq	0x58(%rsp), %rax
    6303:      	movbeq	%rax, 0x8(%rsp)
    630a:      	movq	(%rip), %rdi            # 0x6311 <perf_unwind_hotspot+0x6311>
    6311:      	movq	%rsp, %rsi
    6314:      	movl	$0x1, %eax
    6319:      	callq	*%rax
    631b:      	testq	%rax, %rax
    631e:      	je	0x633f <perf_unwind_hotspot+0x633f>
    6320:      	movq	0x8(%rax), %rax
    6324:      	andq	%rbx, %rax
    6327:      	cmpq	%r13, %rax
    632a:      	jne	0x633f <perf_unwind_hotspot+0x633f>
    632c:      	movq	0x38(%rsp), %rax
    6331:      	addq	$0x18, %rax
    6335:      	movl	$0x3, %edx
    633a:      	jmp	0x64f5 <perf_unwind_hotspot+0x64f5>
    633f:      	movq	(%rip), %rax            # 0x6346 <perf_unwind_hotspot+0x6346>
    6346:      	cmpl	$0x0, (%rax)
    6349:      	jne	0x77a2 <perf_unwind_hotspot+0x77a2>
    634f:      	movl	(%r14), %eax
    6352:      	movl	$0x60, (%rsp)
    6359:      	movbel	%eax, 0x4(%rsp)
    635f:      	movq	0x60(%rsp), %rax
    6364:      	movbeq	%rax, 0x8(%rsp)
    636b:      	movq	(%rip), %rdi            # 0x6372 <perf_unwind_hotspot+0x6372>
    6372:      	movq	%rsp, %rsi
    6375:      	movl	$0x1, %eax
    637a:      	callq	*%rax
    637c:      	testq	%rax, %rax
    637f:      	je	0x6494 <perf_unwind_hotspot+0x6494>
    6385:      	movq	0x8(%rax), %rax
    6389:      	andq	%rbx, %rax
    638c:      	cmpq	%r13, %rax
    638f:      	jne	0x6494 <perf_unwind_hotspot+0x6494>
    6395:      	movq	0x38(%rsp), %rax
    639a:      	addq	$0x20, %rax
    639e:      	movl	$0x4, %edx
    63a3:      	jmp	0x64f5 <perf_unwind_hotspot+0x64f5>
    63a8:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    63b2:      	movq	%rax, 0x66(%rsp)
    63b7:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    63c1:      	movq	%rax, 0x60(%rsp)
    63c6:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    63d0:      	movq	%rax, 0x58(%rsp)
    63d5:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    63df:      	movq	%rax, 0x50(%rsp)
    63e4:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    63ee:      	movq	%rax, 0x48(%rsp)
    63f3:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    63fd:      	movq	%rax, 0x40(%rsp)
    6402:      	leaq	0x40(%rsp), %rdi
    6407:      	movl	$0x2e, %eax
    640c:      	movl	$0x6, %ecx
    6411:      	movl	(%rsp), %edx
    6414:      	movl	$0x2e, %esi
    6419:      	xorl	%eax, %eax
    641b:      	callq	*%rcx
    641d:      	jmp	0x526f <perf_unwind_hotspot+0x526f>
    6422:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    642c:      	movq	%rax, 0x55(%rsp)
    6431:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    643b:      	movq	%rax, 0x50(%rsp)
    6440:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    644a:      	movq	%rax, 0x48(%rsp)
    644f:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    6459:      	movq	%rax, 0x40(%rsp)
    645e:      	leaq	0x40(%rsp), %rdi
    6463:      	movl	$0x1d, %eax
    6468:      	movl	$0x6, %r8d
    646e:      	movzbl	(%rsp), %ecx
    6472:      	movl	$0x1d, %esi
    6477:      	movq	%r13, %rdx
    647a:      	xorl	%eax, %eax
    647c:      	callq	*%r8
    647f:      	movzbl	(%rsp), %eax
    6483:      	leal	0x1(%rax), %ecx
    6486:      	cmpb	$0x2, %cl
    6489:      	jb	0x2ea0 <perf_unwind_hotspot+0x2ea0>
    648f:      	jmp	0x368c <perf_unwind_hotspot+0x368c>
    6494:      	movq	(%rip), %rax            # 0x649b <perf_unwind_hotspot+0x649b>
    649b:      	cmpl	$0x0, (%rax)
    649e:      	jne	0x780b <perf_unwind_hotspot+0x780b>
    64a4:      	movl	(%r14), %eax
    64a7:      	movl	$0x60, (%rsp)
    64ae:      	movbel	%eax, 0x4(%rsp)
    64b4:      	movq	0x68(%rsp), %rax
    64b9:      	movbeq	%rax, 0x8(%rsp)
    64c0:      	movq	(%rip), %rdi            # 0x64c7 <perf_unwind_hotspot+0x64c7>
    64c7:      	movq	%rsp, %rsi
    64ca:      	movl	$0x1, %eax
    64cf:      	callq	*%rax
    64d1:      	testq	%rax, %rax
    64d4:      	je	0x6592 <perf_unwind_hotspot+0x6592>
    64da:      	andq	0x8(%rax), %rbx
    64de:      	cmpq	%r13, %rbx
    64e1:      	jne	0x6592 <perf_unwind_hotspot+0x6592>
    64e7:      	movq	0x38(%rsp), %rax
    64ec:      	addq	$0x28, %rax
    64f0:      	movl	$0x5, %edx
    64f5:      	movq	%rax, 0x108(%rsp)
    64fd:      	xorl	%ebx, %ebx
    64ff:      	movl	$0x5, %r13d
    6505:      	movq	(%rip), %rax            # 0x650c <perf_unwind_hotspot+0x650c>
    650c:      	cmpl	$0x0, (%rax)
    650f:      	jne	0x7874 <perf_unwind_hotspot+0x7874>
    6515:      	movb	$0x3, %al
    6517:      	movl	%eax, 0xb0(%rsp)
    651e:      	movq	0x108(%rsp), %rax
    6526:      	movq	%rax, 0x38(%rsp)
    652b:      	testl	%ebx, %ebx
    652d:      	jne	0x347 <perf_unwind_hotspot+0x347>
    6533:      	cmpl	$0x2, %r13d
    6537:      	jle	0x6555 <perf_unwind_hotspot+0x6555>
    6539:      	cmpl	$0x4, %r13d
    653d:      	jg	0x657a <perf_unwind_hotspot+0x657a>
    653f:      	cmpl	$0x3, %r13d
    6543:      	je	0x5c6e <perf_unwind_hotspot+0x5c6e>
    6549:      	movl	0xf0(%rsp), %eax
    6550:      	jmp	0x5c88 <perf_unwind_hotspot+0x5c88>
    6555:      	movl	$0x1, %ebx
    655a:      	testl	%r13d, %r13d
    655d:      	je	0x347 <perf_unwind_hotspot+0x347>
    6563:      	movq	0xa8(%rsp), %rcx
    656b:      	cmpl	$0x1, %r13d
    656f:      	je	0x580a <perf_unwind_hotspot+0x580a>
    6575:      	jmp	0x5c73 <perf_unwind_hotspot+0x5c73>
    657a:      	cmpl	$0x5, %r13d
    657e:      	je	0x5c8f <perf_unwind_hotspot+0x5c8f>
    6584:      	jmp	0x5cd7 <perf_unwind_hotspot+0x5cd7>
    6589:      	movq	0xf00(%r14), %r13
    6590:      	jmp	0x65c9 <perf_unwind_hotspot+0x65c9>
    6592:      	movl	$0x2e, 0x100(%rsp)
    659d:      	movq	(%rip), %rdi            # 0x65a4 <perf_unwind_hotspot+0x65a4>
    65a4:      	leaq	0x100(%rsp), %rsi
    65ac:      	movl	$0x1, %eax
    65b1:      	callq	*%rax
    65b3:      	testq	%rax, %rax
    65b6:      	je	0x679c <perf_unwind_hotspot+0x679c>
    65bc:      	incq	(%rax)
    65bf:      	jmp	0x67ac <perf_unwind_hotspot+0x67ac>
    65c4:      	movq	0x58(%rsp), %r13
    65c9:      	movq	0x78(%rsp), %rsi
    65ce:      	movq	0x88(%rsp), %rax
    65d6:      	movq	%rax, 0x38(%rsp)
    65db:      	movq	0x90(%rsp), %rax
    65e3:      	movq	%rax, 0xa8(%rsp)
    65eb:      	movq	0x98(%rsp), %r12
    65f3:      	movzbl	0x1c(%r15), %eax
    65f8:      	addq	%rsi, %rax
    65fb:      	leaq	0x100(%rsp), %rdi
    6603:      	movl	$0x8, %ecx
    6608:      	movl	$0x70, %r8d
    660e:      	movzbl	0x1c(%r15), %edx
    6613:      	movq	%rsi, 0x108(%rsp)
    661b:      	addq	%rsi, %rdx
    661e:      	movl	$0x8, %esi
    6623:      	callq	*%r8
    6626:      	testq	%rax, %rax
    6629:      	je	0x66a1 <perf_unwind_hotspot+0x66a1>
    662b:      	movq	(%rip), %rax            # 0x6632 <perf_unwind_hotspot+0x6632>
    6632:      	cmpl	$0x0, (%rax)
    6635:      	je	0x5c2b <perf_unwind_hotspot+0x5c2b>
    663b:      	movabsq	$0xa646f6874656d63, %rax # imm = 0xA646F6874656D63
    6645:      	movq	%rax, 0x20(%rsp)
    664a:      	movabsq	$0x2072657465727072, %rax # imm = 0x2072657465727072
    6654:      	movq	%rax, 0x18(%rsp)
    6659:      	movabsq	$0x65746e6920646165, %rax # imm = 0x65746E6920646165
    6663:      	movq	%rax, 0x10(%rsp)
    6668:      	movabsq	$0x72206f742064656c, %rax # imm = 0x72206F742064656C
    6672:      	movq	%rax, 0x8(%rsp)
    6677:      	movabsq	$0x696166203a6d766a, %rax # imm = 0x696166203A6D766A
    6681:      	movq	%rax, (%rsp)
    6685:      	movb	$0x0, 0x28(%rsp)
    668a:      	movq	%rsp, %rdi
    668d:      	movl	$0x29, %eax
    6692:      	movl	$0x6, %ecx
    6697:      	movl	$0x29, %esi
    669c:      	jmp	0x70db <perf_unwind_hotspot+0x70db>
    66a1:      	movq	0x100(%rsp), %rdx
    66a9:      	movzbl	0x1d(%r15), %eax
    66ae:      	movq	%rdx, %rcx
    66b1:      	movq	%rdx, 0xb8(%rsp)
    66b9:      	addq	%rdx, %rax
    66bc:      	xorl	%ebx, %ebx
    66be:      	cmpq	%rax, %r13
    66c1:      	movl	$0x0, %ecx
    66c6:      	cmovaeq	%rax, %rcx
    66ca:      	subq	%rcx, %r13
    66cd:      	movq	(%rip), %rax            # 0x66d4 <perf_unwind_hotspot+0x66d4>
    66d4:      	cmpl	$0x0, (%rax)
    66d7:      	jne	0x78ea <perf_unwind_hotspot+0x78ea>
    66dd:      	cmpq	$0xffff, %r13           # imm = 0xFFFF
    66e4:      	movl	$0xffff, %eax           # imm = 0xFFFF
    66e9:      	cmovbq	%r13, %rax
    66ed:      	movq	%rax, 0x118(%rsp)
    66f5:      	shrq	$0x3, 0xb8(%rsp)
    66fe:      	movl	$0x6, %r13d
    6704:      	movb	$0x2, %al
    6706:      	movl	%eax, 0xb0(%rsp)
    670d:      	movq	0x108(%rsp), %rax
    6715:      	movq	%rax, 0xc0(%rsp)
    671d:      	testl	%ebx, %ebx
    671f:      	jne	0x347 <perf_unwind_hotspot+0x347>
    6725:      	jmp	0x6533 <perf_unwind_hotspot+0x6533>
    672a:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    6734:      	movq	%rax, 0x55(%rsp)
    6739:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    6743:      	movq	%rax, 0x50(%rsp)
    6748:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    6752:      	movq	%rax, 0x48(%rsp)
    6757:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    6761:      	movq	%rax, 0x40(%rsp)
    6766:      	leaq	0x40(%rsp), %rdi
    676b:      	movl	$0x1d, %eax
    6770:      	movl	$0x6, %r8d
    6776:      	movzbl	(%rsp), %ecx
    677a:      	movl	$0x1d, %esi
    677f:      	movq	%r13, %rdx
    6782:      	xorl	%eax, %eax
    6784:      	callq	*%r8
    6787:      	movzbl	(%rsp), %eax
    678b:      	leal	0x1(%rax), %ecx
    678e:      	cmpb	$0x2, %cl
    6791:      	jb	0x53f6 <perf_unwind_hotspot+0x53f6>
    6797:      	jmp	0x5a38 <perf_unwind_hotspot+0x5a38>
    679c:      	movq	(%rip), %rax            # 0x67a3 <perf_unwind_hotspot+0x67a3>
    67a3:      	cmpl	$0x0, (%rax)
    67a6:      	jne	0x7992 <perf_unwind_hotspot+0x7992>
    67ac:      	movl	$0x3ea, %ebx            # imm = 0x3EA
    67b1:      	xorl	%r13d, %r13d
    67b4:      	jmp	0x6515 <perf_unwind_hotspot+0x6515>
    67b9:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    67c3:      	movq	%rax, 0x55(%rsp)
    67c8:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    67d2:      	movq	%rax, 0x50(%rsp)
    67d7:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    67e1:      	movq	%rax, 0x48(%rsp)
    67e6:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    67f0:      	movq	%rax, 0x40(%rsp)
    67f5:      	leaq	0x40(%rsp), %rdi
    67fa:      	movl	$0x1d, %eax
    67ff:      	movl	$0x6, %r8d
    6805:      	movzbl	(%rsp), %ecx
    6809:      	movl	$0x1d, %esi
    680e:      	movq	%r13, %rdx
    6811:      	xorl	%eax, %eax
    6813:      	callq	*%r8
    6816:      	movzbl	(%rsp), %eax
    681a:      	leal	0x1(%rax), %ecx
    681d:      	cmpb	$0x2, %cl
    6820:      	jb	0x2ea0 <perf_unwind_hotspot+0x2ea0>
    6826:      	jmp	0x36d3 <perf_unwind_hotspot+0x36d3>
    682b:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    6835:      	movq	%rax, 0x55(%rsp)
    683a:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    6844:      	movq	%rax, 0x50(%rsp)
    6849:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    6853:      	movq	%rax, 0x48(%rsp)
    6858:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    6862:      	movq	%rax, 0x40(%rsp)
    6867:      	leaq	0x40(%rsp), %rdi
    686c:      	movl	$0x1d, %eax
    6871:      	movl	$0x6, %r8d
    6877:      	movzbl	(%rsp), %ecx
    687b:      	movl	$0x1d, %esi
    6880:      	movq	%r13, %rdx
    6883:      	xorl	%eax, %eax
    6885:      	callq	*%r8
    6888:      	movzbl	(%rsp), %eax
    688c:      	leal	0x1(%rax), %ecx
    688f:      	cmpb	$0x2, %cl
    6892:      	jb	0x53f6 <perf_unwind_hotspot+0x53f6>
    6898:      	jmp	0x5a7f <perf_unwind_hotspot+0x5a7f>
    689d:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    68a7:      	movq	%rax, 0x55(%rsp)
    68ac:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    68b6:      	movq	%rax, 0x50(%rsp)
    68bb:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    68c5:      	movq	%rax, 0x48(%rsp)
    68ca:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    68d4:      	movq	%rax, 0x40(%rsp)
    68d9:      	leaq	0x40(%rsp), %rdi
    68de:      	movl	$0x1d, %eax
    68e3:      	movl	$0x6, %r8d
    68e9:      	movzbl	(%rsp), %ecx
    68ed:      	movl	$0x1d, %esi
    68f2:      	movq	%r13, %rdx
    68f5:      	xorl	%eax, %eax
    68f7:      	callq	*%r8
    68fa:      	movzbl	(%rsp), %eax
    68fe:      	leal	0x1(%rax), %ecx
    6901:      	cmpb	$0x2, %cl
    6904:      	jb	0x2ea0 <perf_unwind_hotspot+0x2ea0>
    690a:      	jmp	0x371a <perf_unwind_hotspot+0x371a>
    690f:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    6919:      	movq	%rax, 0x55(%rsp)
    691e:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    6928:      	movq	%rax, 0x50(%rsp)
    692d:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    6937:      	movq	%rax, 0x48(%rsp)
    693c:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    6946:      	movq	%rax, 0x40(%rsp)
    694b:      	leaq	0x40(%rsp), %rdi
    6950:      	movl	$0x1d, %eax
    6955:      	movl	$0x6, %r8d
    695b:      	movzbl	(%rsp), %ecx
    695f:      	movl	$0x1d, %esi
    6964:      	movq	%r13, %rdx
    6967:      	xorl	%eax, %eax
    6969:      	callq	*%r8
    696c:      	movzbl	(%rsp), %eax
    6970:      	leal	0x1(%rax), %ecx
    6973:      	cmpb	$0x1, %cl
    6976:      	ja	0x22b <perf_unwind_hotspot+0x22b>
    697c:      	jmp	0x2ea0 <perf_unwind_hotspot+0x2ea0>
    6981:      	movabsq	$0xa786c252d786c, %rax  # imm = 0xA786C252D786C
    698b:      	movq	%rax, 0x4f(%rsp)
    6990:      	movabsq	$0x6c252065646f6320, %rax # imm = 0x6C252065646F6320
    699a:      	movq	%rax, 0x48(%rsp)
    699f:      	movabsq	$0x3e2d20203a6d766a, %rbx # imm = 0x3E2D20203A6D766A
    69a9:      	movq	%rbx, 0x40(%rsp)
    69ae:      	leaq	0x40(%rsp), %rdi
    69b3:      	movl	$0x17, %eax
    69b8:      	movl	$0x6, %r8d
    69be:      	movq	0xd0(%rsp), %rdx
    69c6:      	movq	0xd8(%rsp), %rcx
    69ce:      	movl	$0x17, %esi
    69d3:      	xorl	%eax, %eax
    69d5:      	callq	*%r8
    69d8:      	movq	(%rip), %rax            # 0x69df <perf_unwind_hotspot+0x69df>
    69df:      	cmpl	$0x0, (%rax)
    69e2:      	je	0x5577 <perf_unwind_hotspot+0x5577>
    69e8:      	movabsq	$0x783020657079745f, %rax # imm = 0x783020657079745F
    69f2:      	movq	%rax, 0x70(%rsp)
    69f7:      	movabsq	$0x656d617266202c75, %rax # imm = 0x656D617266202C75
    6a01:      	movq	%rax, 0x68(%rsp)
    6a06:      	movabsq	$0x2520657a69735f65, %rax # imm = 0x2520657A69735F65
    6a10:      	movq	%rax, 0x60(%rsp)
    6a15:      	movabsq	$0x6d617266202c7525, %rax # imm = 0x6D617266202C7525
    6a1f:      	movq	%rax, 0x58(%rsp)
    6a24:      	movabsq	$0x206574656c706d6f, %rax # imm = 0x206574656C706D6F
    6a2e:      	movq	%rax, 0x50(%rsp)
    6a33:      	movabsq	$0x635f656d61726620, %rax # imm = 0x635F656D61726620
    6a3d:      	movq	%rax, 0x48(%rsp)
    6a42:      	movq	%rbx, 0x40(%rsp)
    6a47:      	movl	$0xa7825, 0x78(%rsp)    # imm = 0xA7825
    6a4f:      	leaq	0x40(%rsp), %rdi
    6a54:      	movl	$0x3c, %eax
    6a59:      	movl	$0x6, %r9d
    6a5f:      	movzwl	0xf8(%rsp), %edx
    6a67:      	movl	0xe8(%rsp), %r8d
    6a6f:      	movl	0xf0(%rsp), %ecx
    6a76:      	movl	$0x3c, %esi
    6a7b:      	xorl	%eax, %eax
    6a7d:      	callq	*%r9
    6a80:      	jmp	0x5577 <perf_unwind_hotspot+0x5577>
    6a85:      	movabsq	$0xa64656c696166, %rax  # imm = 0xA64656C696166
    6a8f:      	movq	%rax, 0x68(%rsp)
    6a94:      	movabsq	$0x20797265766f6365, %rax # imm = 0x20797265766F6365
    6a9e:      	movq	%rax, 0x60(%rsp)
    6aa3:      	movabsq	$0x72206370202c656d, %rax # imm = 0x72206370202C656D
    6aad:      	movq	%rax, 0x58(%rsp)
    6ab2:      	movabsq	$0x6172662064657a69, %rax # imm = 0x6172662064657A69
    6abc:      	movq	%rax, 0x50(%rsp)
    6ac1:      	movabsq	$0x6d6974706f656420, %rax # imm = 0x6D6974706F656420
    6acb:      	movq	%rax, 0x48(%rsp)
    6ad0:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    6ada:      	movq	%rax, 0x40(%rsp)
    6adf:      	leaq	0x40(%rsp), %rdi
    6ae4:      	movl	$0x30, %eax
    6ae9:      	movl	$0x6, %ecx
    6aee:      	movl	$0x30, %esi
    6af3:      	xorl	%eax, %eax
    6af5:      	callq	*%rcx
    6af7:      	jmp	0x5736 <perf_unwind_hotspot+0x5736>
    6afc:      	movabsq	$0xa656c62617476, %rax  # imm = 0xA656C62617476
    6b06:      	movq	%rax, 0x50(%rsp)
    6b0b:      	movabsq	$0x20646e69776e7520, %rax # imm = 0x20646E69776E7520
    6b15:      	movq	%rax, 0x48(%rsp)
    6b1a:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    6b24:      	movq	%rax, 0x40(%rsp)
    6b29:      	leaq	0x40(%rsp), %rdi
    6b2e:      	movl	$0x18, %eax
    6b33:      	movl	$0x6, %ecx
    6b38:      	movl	$0x18, %esi
    6b3d:      	xorl	%eax, %eax
    6b3f:      	callq	*%rcx
    6b41:      	jmp	0x580a <perf_unwind_hotspot+0x580a>
    6b46:      	movabsq	$0x6170206b6361626c, %rax # imm = 0x6170206B6361626C
    6b50:      	movq	%rax, 0x58(%rsp)
    6b55:      	movabsq	$0x6c61662062757473, %rax # imm = 0x6C61662062757473
    6b5f:      	movq	%rax, 0x50(%rsp)
    6b64:      	movabsq	$0x20646e69776e7520, %rax # imm = 0x20646E69776E7520
    6b6e:      	movq	%rax, 0x48(%rsp)
    6b73:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    6b7d:      	movq	%rax, 0x40(%rsp)
    6b82:      	movl	$0xa6874, 0x60(%rsp)    # imm = 0xA6874
    6b8a:      	leaq	0x40(%rsp), %rdi
    6b8f:      	movl	$0x24, %eax
    6b94:      	movl	$0x6, %ecx
    6b99:      	movl	$0x24, %esi
    6b9e:      	xorl	%eax, %eax
    6ba0:      	callq	*%rcx
    6ba2:      	jmp	0x582f <perf_unwind_hotspot+0x582f>
    6ba7:      	movabsq	$0xa29646c252065, %rax  # imm = 0xA29646C252065
    6bb1:      	movq	%rax, 0x67(%rsp)
    6bb6:      	movabsq	$0x657a697320656d61, %rax # imm = 0x657A697320656D61
    6bc0:      	movq	%rax, 0x60(%rsp)
    6bc5:      	movabsq	$0x726628207265746e, %rax # imm = 0x726628207265746E
    6bcf:      	movq	%rax, 0x58(%rsp)
    6bd4:      	movabsq	$0x696f7020656d6172, %rax # imm = 0x696F7020656D6172
    6bde:      	movq	%rax, 0x50(%rsp)
    6be3:      	movabsq	$0x6620676e69737520, %rax # imm = 0x6620676E69737520
    6bed:      	movq	%rax, 0x48(%rsp)
    6bf2:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    6bfc:      	movq	%rax, 0x40(%rsp)
    6c01:      	leaq	0x40(%rsp), %rdi
    6c06:      	movl	$0x2f, %eax
    6c0b:      	movl	$0x6, %ecx
    6c10:      	movl	$0x2f, %esi
    6c15:      	xorl	%eax, %eax
    6c17:      	callq	*%rcx
    6c19:      	movq	0xa8(%rsp), %rcx
    6c21:      	jmp	0x5c73 <perf_unwind_hotspot+0x5c73>
    6c26:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    6c30:      	movq	%rax, 0x55(%rsp)
    6c35:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    6c3f:      	movq	%rax, 0x50(%rsp)
    6c44:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    6c4e:      	movq	%rax, 0x48(%rsp)
    6c53:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    6c5d:      	movq	%rax, 0x40(%rsp)
    6c62:      	leaq	0x40(%rsp), %rdi
    6c67:      	movl	$0x1d, %eax
    6c6c:      	movl	$0x6, %r8d
    6c72:      	movzbl	(%rsp), %ecx
    6c76:      	movl	$0x1d, %esi
    6c7b:      	movq	%r13, %rdx
    6c7e:      	xorl	%eax, %eax
    6c80:      	callq	*%r8
    6c83:      	movzbl	(%rsp), %eax
    6c87:      	leal	0x1(%rax), %ecx
    6c8a:      	cmpb	$0x2, %cl
    6c8d:      	jb	0x53f6 <perf_unwind_hotspot+0x53f6>
    6c93:      	jmp	0x5ac6 <perf_unwind_hotspot+0x5ac6>
    6c98:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    6ca2:      	movq	%rax, 0x55(%rsp)
    6ca7:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    6cb1:      	movq	%rax, 0x50(%rsp)
    6cb6:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    6cc0:      	movq	%rax, 0x48(%rsp)
    6cc5:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    6ccf:      	movq	%rax, 0x40(%rsp)
    6cd4:      	leaq	0x40(%rsp), %rdi
    6cd9:      	movl	$0x1d, %eax
    6cde:      	movl	$0x6, %r8d
    6ce4:      	movzbl	(%rsp), %ecx
    6ce8:      	movl	$0x1d, %esi
    6ced:      	movq	%r13, %rdx
    6cf0:      	xorl	%eax, %eax
    6cf2:      	callq	*%r8
    6cf5:      	movzbl	(%rsp), %eax
    6cf9:      	leal	0x1(%rax), %ecx
    6cfc:      	cmpb	$0x2, %cl
    6cff:      	jb	0x53f6 <perf_unwind_hotspot+0x53f6>
    6d05:      	jmp	0x5b0d <perf_unwind_hotspot+0x5b0d>
    6d0a:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    6d14:      	movq	%rax, 0x55(%rsp)
    6d19:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    6d23:      	movq	%rax, 0x50(%rsp)
    6d28:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    6d32:      	movq	%rax, 0x48(%rsp)
    6d37:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    6d41:      	movq	%rax, 0x40(%rsp)
    6d46:      	leaq	0x40(%rsp), %rdi
    6d4b:      	movl	$0x1d, %eax
    6d50:      	movl	$0x6, %r8d
    6d56:      	movzbl	(%rsp), %ecx
    6d5a:      	movl	$0x1d, %esi
    6d5f:      	movq	%r13, %rdx
    6d62:      	xorl	%eax, %eax
    6d64:      	callq	*%r8
    6d67:      	movzbl	(%rsp), %eax
    6d6b:      	leal	0x1(%rax), %ecx
    6d6e:      	cmpb	$0x2, %cl
    6d71:      	jb	0x53f6 <perf_unwind_hotspot+0x53f6>
    6d77:      	jmp	0x5b54 <perf_unwind_hotspot+0x5b54>
    6d7c:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    6d86:      	movq	%rax, 0x55(%rsp)
    6d8b:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    6d95:      	movq	%rax, 0x50(%rsp)
    6d9a:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    6da4:      	movq	%rax, 0x48(%rsp)
    6da9:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    6db3:      	movq	%rax, 0x40(%rsp)
    6db8:      	leaq	0x40(%rsp), %rdi
    6dbd:      	movl	$0x1d, %eax
    6dc2:      	movl	$0x6, %r8d
    6dc8:      	movzbl	(%rsp), %ecx
    6dcc:      	movl	$0x1d, %esi
    6dd1:      	movq	%r13, %rdx
    6dd4:      	xorl	%eax, %eax
    6dd6:      	callq	*%r8
    6dd9:      	movzbl	(%rsp), %eax
    6ddd:      	leal	0x1(%rax), %ecx
    6de0:      	cmpb	$0x2, %cl
    6de3:      	jb	0x53f6 <perf_unwind_hotspot+0x53f6>
    6de9:      	movzbl	%al, %eax
    6dec:      	subq	%rax, %r13
    6def:      	leaq	(%rbx,%r13), %rdx
    6df3:      	movq	%rsp, %rdi
    6df6:      	movl	$0x1, %eax
    6dfb:      	movl	$0x70, %ecx
    6e00:      	movl	$0x1, %esi
    6e05:      	callq	*%rcx
    6e07:      	testq	%rax, %rax
    6e0a:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    6e10:      	movq	(%rip), %rax            # 0x6e17 <perf_unwind_hotspot+0x6e17>
    6e17:      	cmpl	$0x0, (%rax)
    6e1a:      	je	0x6e79 <perf_unwind_hotspot+0x6e79>
    6e1c:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    6e26:      	movq	%rax, 0x55(%rsp)
    6e2b:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    6e35:      	movq	%rax, 0x50(%rsp)
    6e3a:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    6e44:      	movq	%rax, 0x48(%rsp)
    6e49:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    6e53:      	movq	%rax, 0x40(%rsp)
    6e58:      	leaq	0x40(%rsp), %rdi
    6e5d:      	movl	$0x1d, %eax
    6e62:      	movl	$0x6, %r8d
    6e68:      	movzbl	(%rsp), %ecx
    6e6c:      	movl	$0x1d, %esi
    6e71:      	movq	%r13, %rdx
    6e74:      	xorl	%eax, %eax
    6e76:      	callq	*%r8
    6e79:      	movzbl	(%rsp), %eax
    6e7d:      	leal	0x1(%rax), %ecx
    6e80:      	cmpb	$0x2, %cl
    6e83:      	jb	0x53f6 <perf_unwind_hotspot+0x53f6>
    6e89:      	movzbl	%al, %eax
    6e8c:      	subq	%rax, %r13
    6e8f:      	leaq	(%rbx,%r13), %rdx
    6e93:      	movq	%rsp, %rdi
    6e96:      	movl	$0x1, %eax
    6e9b:      	movl	$0x70, %ecx
    6ea0:      	movl	$0x1, %esi
    6ea5:      	callq	*%rcx
    6ea7:      	testq	%rax, %rax
    6eaa:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    6eb0:      	movq	(%rip), %rax            # 0x6eb7 <perf_unwind_hotspot+0x6eb7>
    6eb7:      	cmpl	$0x0, (%rax)
    6eba:      	je	0x6f19 <perf_unwind_hotspot+0x6f19>
    6ebc:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    6ec6:      	movq	%rax, 0x55(%rsp)
    6ecb:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    6ed5:      	movq	%rax, 0x50(%rsp)
    6eda:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    6ee4:      	movq	%rax, 0x48(%rsp)
    6ee9:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    6ef3:      	movq	%rax, 0x40(%rsp)
    6ef8:      	leaq	0x40(%rsp), %rdi
    6efd:      	movl	$0x1d, %eax
    6f02:      	movl	$0x6, %r8d
    6f08:      	movzbl	(%rsp), %ecx
    6f0c:      	movl	$0x1d, %esi
    6f11:      	movq	%r13, %rdx
    6f14:      	xorl	%eax, %eax
    6f16:      	callq	*%r8
    6f19:      	movzbl	(%rsp), %eax
    6f1d:      	leal	0x1(%rax), %ecx
    6f20:      	cmpb	$0x2, %cl
    6f23:      	jb	0x53f6 <perf_unwind_hotspot+0x53f6>
    6f29:      	movzbl	%al, %eax
    6f2c:      	subq	%rax, %r13
    6f2f:      	leaq	(%rbx,%r13), %rdx
    6f33:      	movq	%rsp, %rdi
    6f36:      	movl	$0x1, %eax
    6f3b:      	movl	$0x70, %ecx
    6f40:      	movl	$0x1, %esi
    6f45:      	callq	*%rcx
    6f47:      	testq	%rax, %rax
    6f4a:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    6f50:      	movq	(%rip), %rax            # 0x6f57 <perf_unwind_hotspot+0x6f57>
    6f57:      	cmpl	$0x0, (%rax)
    6f5a:      	je	0x6fb9 <perf_unwind_hotspot+0x6fb9>
    6f5c:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    6f66:      	movq	%rax, 0x55(%rsp)
    6f6b:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    6f75:      	movq	%rax, 0x50(%rsp)
    6f7a:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    6f84:      	movq	%rax, 0x48(%rsp)
    6f89:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    6f93:      	movq	%rax, 0x40(%rsp)
    6f98:      	leaq	0x40(%rsp), %rdi
    6f9d:      	movl	$0x1d, %eax
    6fa2:      	movl	$0x6, %r8d
    6fa8:      	movzbl	(%rsp), %ecx
    6fac:      	movl	$0x1d, %esi
    6fb1:      	movq	%r13, %rdx
    6fb4:      	xorl	%eax, %eax
    6fb6:      	callq	*%r8
    6fb9:      	movzbl	(%rsp), %eax
    6fbd:      	leal	0x1(%rax), %ecx
    6fc0:      	cmpb	$0x2, %cl
    6fc3:      	jb	0x53f6 <perf_unwind_hotspot+0x53f6>
    6fc9:      	movzbl	%al, %eax
    6fcc:      	subq	%rax, %r13
    6fcf:      	addq	%r13, %rbx
    6fd2:      	movq	%rsp, %rdi
    6fd5:      	movl	$0x1, %eax
    6fda:      	movl	$0x70, %ecx
    6fdf:      	movl	$0x1, %esi
    6fe4:      	movq	%rbx, %rdx
    6fe7:      	callq	*%rcx
    6fe9:      	testq	%rax, %rax
    6fec:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    6ff2:      	movq	(%rip), %rax            # 0x6ff9 <perf_unwind_hotspot+0x6ff9>
    6ff9:      	cmpl	$0x0, (%rax)
    6ffc:      	je	0x705b <perf_unwind_hotspot+0x705b>
    6ffe:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    7008:      	movq	%rax, 0x55(%rsp)
    700d:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    7017:      	movq	%rax, 0x50(%rsp)
    701c:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    7026:      	movq	%rax, 0x48(%rsp)
    702b:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    7035:      	movq	%rax, 0x40(%rsp)
    703a:      	leaq	0x40(%rsp), %rdi
    703f:      	movl	$0x1d, %eax
    7044:      	movl	$0x6, %r8d
    704a:      	movzbl	(%rsp), %ecx
    704e:      	movl	$0x1d, %esi
    7053:      	movq	%r13, %rdx
    7056:      	xorl	%eax, %eax
    7058:      	callq	*%r8
    705b:      	movzbl	(%rsp), %eax
    705f:      	leal	0x1(%rax), %ecx
    7062:      	cmpb	$0x1, %cl
    7065:      	ja	0x22b <perf_unwind_hotspot+0x22b>
    706b:      	jmp	0x53f6 <perf_unwind_hotspot+0x53f6>
    7070:      	movabsq	$0xa656d61726620, %rax  # imm = 0xA656D61726620
    707a:      	movq	%rax, 0x26(%rsp)
    707f:      	movabsq	$0x6620726574657270, %rax # imm = 0x6620726574657270
    7089:      	movq	%rax, 0x20(%rsp)
    708e:      	movabsq	$0x7265746e69206562, %rax # imm = 0x7265746E69206562
    7098:      	movq	%rax, 0x18(%rsp)
    709d:      	movabsq	$0x206f742079617761, %rax # imm = 0x206F742079617761
    70a7:      	movq	%rax, 0x10(%rsp)
    70ac:      	movabsq	$0x20726166206f6f74, %rax # imm = 0x20726166206F6F74
    70b6:      	movq	%rax, 0x8(%rsp)
    70bb:      	movabsq	$0x207066203a6d766a, %rax # imm = 0x207066203A6D766A
    70c5:      	movq	%rax, (%rsp)
    70c9:      	movq	%rsp, %rdi
    70cc:      	movl	$0x2e, %eax
    70d1:      	movl	$0x6, %ecx
    70d6:      	movl	$0x2e, %esi
    70db:      	xorl	%eax, %eax
    70dd:      	callq	*%rcx
    70df:      	jmp	0x5c2b <perf_unwind_hotspot+0x5c2b>
    70e4:      	movabsq	$0xa2963702b7066, %rax  # imm = 0xA2963702B7066
    70ee:      	movq	%rax, 0x65(%rsp)
    70f3:      	movabsq	$0x2b70662820656d61, %rax # imm = 0x2B70662820656D61
    70fd:      	movq	%rax, 0x60(%rsp)
    7102:      	movabsq	$0x7266206574656c70, %rax # imm = 0x7266206574656C70
    710c:      	movq	%rax, 0x58(%rsp)
    7111:      	movabsq	$0x6d6f636e6920676e, %rax # imm = 0x6D6F636E6920676E
    711b:      	movq	%rax, 0x50(%rsp)
    7120:      	movabsq	$0x69646e69776e7520, %rax # imm = 0x69646E69776E7520
    712a:      	movq	%rax, 0x48(%rsp)
    712f:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    7139:      	movq	%rax, 0x40(%rsp)
    713e:      	leaq	0x40(%rsp), %rdi
    7143:      	movl	$0x2d, %eax
    7148:      	movl	$0x6, %ecx
    714d:      	movl	$0x2d, %esi
    7152:      	xorl	%eax, %eax
    7154:      	callq	*%rcx
    7156:      	jmp	0x5c6e <perf_unwind_hotspot+0x5c6e>
    715b:      	movabsq	$0xa706620726576, %rax  # imm = 0xA706620726576
    7165:      	movq	%rax, 0x4d(%rsp)
    716a:      	movabsq	$0x7265766f63657220, %rax # imm = 0x7265766F63657220
    7174:      	movq	%rax, 0x48(%rsp)
    7179:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    7183:      	movq	%rax, 0x40(%rsp)
    7188:      	leaq	0x40(%rsp), %rdi
    718d:      	movl	$0x15, %eax
    7192:      	movl	$0x6, %ecx
    7197:      	movl	$0x15, %esi
    719c:      	xorl	%eax, %eax
    719e:      	callq	*%rcx
    71a0:      	jmp	0x5ccb <perf_unwind_hotspot+0x5ccb>
    71a5:      	movabsq	$0x25203a7066202c78, %rax # imm = 0x25203A7066202C78
    71af:      	movq	%rax, 0x58(%rsp)
    71b4:      	movabsq	$0x6c25203a7073202c, %rax # imm = 0x6C25203A7073202C
    71be:      	movq	%rax, 0x50(%rsp)
    71c3:      	movabsq	$0x786c25203a637020, %rax # imm = 0x786C25203A637020
    71cd:      	movq	%rax, 0x48(%rsp)
    71d2:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    71dc:      	movq	%rax, 0x40(%rsp)
    71e1:      	movl	$0xa786c, 0x60(%rsp)    # imm = 0xA786C
    71e9:      	leaq	0x40(%rsp), %rdi
    71ee:      	movl	$0x24, %eax
    71f3:      	movl	$0x6, %r9d
    71f9:      	movl	$0x24, %esi
    71fe:      	movq	%r12, %rdx
    7201:      	movq	0x38(%rsp), %rcx
    7206:      	movq	0xa8(%rsp), %r8
    720e:      	xorl	%eax, %eax
    7210:      	callq	*%r9
    7213:      	jmp	0x5d73 <perf_unwind_hotspot+0x5d73>
    7218:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    7222:      	movq	%rax, 0x66(%rsp)
    7227:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    7231:      	movq	%rax, 0x60(%rsp)
    7236:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    7240:      	movq	%rax, 0x58(%rsp)
    7245:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    724f:      	movq	%rax, 0x50(%rsp)
    7254:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    725e:      	movq	%rax, 0x48(%rsp)
    7263:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    726d:      	movq	%rax, 0x40(%rsp)
    7272:      	leaq	0x40(%rsp), %rdi
    7277:      	movl	$0x2e, %eax
    727c:      	movl	$0x6, %ecx
    7281:      	movl	(%rsp), %edx
    7284:      	movl	$0x2e, %esi
    7289:      	xorl	%eax, %eax
    728b:      	callq	*%rcx
    728d:      	jmp	0x5dbd <perf_unwind_hotspot+0x5dbd>
    7292:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    729c:      	movq	%rax, 0x68(%rsp)
    72a1:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    72ab:      	movq	%rax, 0x60(%rsp)
    72b0:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    72ba:      	movq	%rax, 0x58(%rsp)
    72bf:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    72c9:      	movq	%rax, 0x50(%rsp)
    72ce:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    72d8:      	movq	%rax, 0x48(%rsp)
    72dd:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    72e7:      	movq	%rax, 0x40(%rsp)
    72ec:      	movb	$0x0, 0x70(%rsp)
    72f1:      	leaq	0x40(%rsp), %rdi
    72f6:      	movl	$0x31, %eax
    72fb:      	movl	$0x6, %ecx
    7300:      	movl	0x2c0(%r14), %edx
    7307:      	movl	$0x31, %esi
    730c:      	xorl	%eax, %eax
    730e:      	callq	*%rcx
    7310:      	movq	0xed0(%r14), %rbx
    7317:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    7321:      	cmpq	%rax, %rbx
    7324:      	ja	0x1049 <perf_unwind_hotspot+0x1049>
    732a:      	jmp	0x5e05 <perf_unwind_hotspot+0x5e05>
    732f:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    7339:      	movq	%rax, 0x68(%rsp)
    733e:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    7348:      	movq	%rax, 0x60(%rsp)
    734d:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    7357:      	movq	%rax, 0x58(%rsp)
    735c:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    7366:      	movq	%rax, 0x50(%rsp)
    736b:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    7375:      	movq	%rax, 0x48(%rsp)
    737a:      	movabsq	$0x6365732074786554, %r13 # imm = 0x6365732074786554
    7384:      	movq	%r13, 0x40(%rsp)
    7389:      	movw	$0xa, 0x70(%rsp)
    7390:      	leaq	0x40(%rsp), %rdi
    7395:      	movl	$0x32, %eax
    739a:      	movl	$0x6, %r9d
    73a0:      	movq	0xf10(%r14), %rcx
    73a7:      	movl	$0x32, %esi
    73ac:      	movq	%rbx, %rdx
    73af:      	movl	%r12d, %r8d
    73b2:      	xorl	%eax, %eax
    73b4:      	callq	*%r9
    73b7:      	movq	(%rip), %rax            # 0x73be <perf_unwind_hotspot+0x73be>
    73be:      	cmpl	$0x0, (%rax)
    73c1:      	je	0x5e98 <perf_unwind_hotspot+0x5e98>
    73c7:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    73d1:      	movq	%rax, 0x67(%rsp)
    73d6:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    73e0:      	movq	%rax, 0x60(%rsp)
    73e5:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    73ef:      	movq	%rax, 0x58(%rsp)
    73f4:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    73fe:      	movq	%rax, 0x50(%rsp)
    7403:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    740d:      	movq	%rax, 0x48(%rsp)
    7412:      	movq	%r13, 0x40(%rsp)
    7417:      	leaq	0x40(%rsp), %rdi
    741c:      	movl	$0x2f, %eax
    7421:      	movl	$0x6, %r8d
    7427:      	movq	0xf18(%r14), %rcx
    742e:      	movq	0xf20(%r14), %rdx
    7435:      	movl	$0x2f, %esi
    743a:      	xorl	%eax, %eax
    743c:      	callq	*%r8
    743f:      	jmp	0x5e98 <perf_unwind_hotspot+0x5e98>
    7444:      	movabsq	$0xa642520686374, %rax  # imm = 0xA642520686374
    744e:      	movq	%rax, 0x56(%rsp)
    7453:      	movabsq	$0x6374616d20737465, %rax # imm = 0x6374616D20737465
    745d:      	movq	%rax, 0x50(%rsp)
    7462:      	movabsq	$0x7366666f5f726574, %rax # imm = 0x7366666F5F726574
    746c:      	movq	%rax, 0x48(%rsp)
    7471:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    747b:      	movq	%rax, 0x40(%rsp)
    7480:      	leaq	0x40(%rsp), %rdi
    7485:      	movl	$0x1e, %eax
    748a:      	movl	$0x6, %ecx
    748f:      	movzwl	0x20(%rbx), %edx
    7493:      	movl	$0x1e, %esi
    7498:      	xorl	%eax, %eax
    749a:      	callq	*%rcx
    749c:      	movl	0x1380(%r14), %eax
    74a3:      	movl	0x20(%rbx), %ecx
    74a6:      	btl	%ecx, %eax
    74a9:      	jb	0x5f22 <perf_unwind_hotspot+0x5f22>
    74af:      	movl	$0x0, (%rsp)
    74b6:      	movq	(%rip), %rdi            # 0x74bd <perf_unwind_hotspot+0x74bd>
    74bd:      	movq	%rsp, %rsi
    74c0:      	movl	$0x1, %eax
    74c5:      	callq	*%rax
    74c7:      	testq	%rax, %rax
    74ca:      	je	0x7a0d <perf_unwind_hotspot+0x7a0d>
    74d0:      	incq	(%rax)
    74d3:      	jmp	0x7a8e <perf_unwind_hotspot+0x7a8e>
    74d8:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    74e2:      	movq	%rax, 0x18(%rsp)
    74e7:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    74f1:      	movq	%rax, 0x10(%rsp)
    74f6:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    7500:      	movq	%rax, 0x8(%rsp)
    7505:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    750f:      	movq	%rax, (%rsp)
    7513:      	movw	$0xa, 0x20(%rsp)
    751a:      	movq	%rsp, %rdi
    751d:      	movl	$0x22, %eax
    7522:      	movl	$0x6, %r8d
    7528:      	movq	0x40(%rsp), %rcx
    752d:      	movl	$0x22, %esi
    7532:      	xorl	%edx, %edx
    7534:      	xorl	%eax, %eax
    7536:      	callq	*%r8
    7539:      	jmp	0x5fb7 <perf_unwind_hotspot+0x5fb7>
    753e:      	movabsq	$0xa2964252b7073, %rax  # imm = 0xA2964252B7073
    7548:      	movq	%rax, 0x78(%rsp)
    754d:      	movabsq	$0x206d6f7266282078, %rax # imm = 0x206D6F7266282078
    7557:      	movq	%rax, 0x70(%rsp)
    755c:      	movabsq	$0x6c25783020736120, %rax # imm = 0x6C25783020736120
    7566:      	movq	%rax, 0x68(%rsp)
    756b:      	movabsq	$0x64657265766f6365, %rax # imm = 0x64657265766F6365
    7575:      	movq	%rax, 0x60(%rsp)
    757a:      	movabsq	$0x72206370202c656d, %rax # imm = 0x72206370202C656D
    7584:      	movq	%rax, 0x58(%rsp)
    7589:      	movabsq	$0x6172662064657a69, %rax # imm = 0x6172662064657A69
    7593:      	movq	%rax, 0x50(%rsp)
    7598:      	movabsq	$0x6d6974706f656420, %rax # imm = 0x6D6974706F656420
    75a2:      	movq	%rax, 0x48(%rsp)
    75a7:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    75b1:      	movq	%rax, 0x40(%rsp)
    75b6:      	leaq	0x40(%rsp), %rdi
    75bb:      	movl	$0x40, %eax
    75c0:      	movl	$0x6, %r8d
    75c6:      	movq	(%rsp), %rdx
    75ca:      	movl	0xec(%rsp), %ecx
    75d1:      	movl	$0x40, %esi
    75d6:      	xorl	%eax, %eax
    75d8:      	callq	*%r8
    75db:      	movq	(%rsp), %rax
    75df:      	movq	0xd0(%rsp), %rcx
    75e7:      	jmp	0x60c7 <perf_unwind_hotspot+0x60c7>
    75ec:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    75f6:      	movq	%rax, 0x26(%rsp)
    75fb:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    7605:      	movq	%rax, 0x20(%rsp)
    760a:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    7614:      	movq	%rax, 0x18(%rsp)
    7619:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    7623:      	movq	%rax, 0x10(%rsp)
    7628:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    7632:      	movq	%rax, 0x8(%rsp)
    7637:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7641:      	movq	%rax, (%rsp)
    7645:      	movq	%rsp, %rdi
    7648:      	movl	$0x2e, %eax
    764d:      	movl	$0x6, %ecx
    7652:      	movl	0x114(%rsp), %edx
    7659:      	movl	$0x2e, %esi
    765e:      	xorl	%eax, %eax
    7660:      	callq	*%rcx
    7662:      	jmp	0x60eb <perf_unwind_hotspot+0x60eb>
    7667:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    7671:      	movq	%rax, 0x18(%rsp)
    7676:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    7680:      	movq	%rax, 0x10(%rsp)
    7685:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    768f:      	movq	%rax, 0x8(%rsp)
    7694:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    769e:      	movq	%rax, (%rsp)
    76a2:      	movw	$0xa, 0x20(%rsp)
    76a9:      	movq	%rsp, %rdi
    76ac:      	movl	$0x22, %eax
    76b1:      	movl	$0x6, %r8d
    76b7:      	movq	0x48(%rsp), %rcx
    76bc:      	movl	$0x22, %esi
    76c1:      	movl	$0x1, %edx
    76c6:      	xorl	%eax, %eax
    76c8:      	callq	*%r8
    76cb:      	jmp	0x611d <perf_unwind_hotspot+0x611d>
    76d0:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    76da:      	movq	%rax, 0x18(%rsp)
    76df:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    76e9:      	movq	%rax, 0x10(%rsp)
    76ee:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    76f8:      	movq	%rax, 0x8(%rsp)
    76fd:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    7707:      	movq	%rax, (%rsp)
    770b:      	movw	$0xa, 0x20(%rsp)
    7712:      	movq	%rsp, %rdi
    7715:      	movl	$0x22, %eax
    771a:      	movl	$0x6, %r8d
    7720:      	movq	0x50(%rsp), %rcx
    7725:      	movl	$0x22, %esi
    772a:      	movl	$0x2, %edx
    772f:      	xorl	%eax, %eax
    7731:      	callq	*%r8
    7734:      	jmp	0x617e <perf_unwind_hotspot+0x617e>
    7739:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    7743:      	movq	%rax, 0x18(%rsp)
    7748:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    7752:      	movq	%rax, 0x10(%rsp)
    7757:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    7761:      	movq	%rax, 0x8(%rsp)
    7766:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    7770:      	movq	%rax, (%rsp)
    7774:      	movw	$0xa, 0x20(%rsp)
    777b:      	movq	%rsp, %rdi
    777e:      	movl	$0x22, %eax
    7783:      	movl	$0x6, %r8d
    7789:      	movq	0x58(%rsp), %rcx
    778e:      	movl	$0x22, %esi
    7793:      	movl	$0x3, %edx
    7798:      	xorl	%eax, %eax
    779a:      	callq	*%r8
    779d:      	jmp	0x62ee <perf_unwind_hotspot+0x62ee>
    77a2:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    77ac:      	movq	%rax, 0x18(%rsp)
    77b1:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    77bb:      	movq	%rax, 0x10(%rsp)
    77c0:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    77ca:      	movq	%rax, 0x8(%rsp)
    77cf:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    77d9:      	movq	%rax, (%rsp)
    77dd:      	movw	$0xa, 0x20(%rsp)
    77e4:      	movq	%rsp, %rdi
    77e7:      	movl	$0x22, %eax
    77ec:      	movl	$0x6, %r8d
    77f2:      	movq	0x60(%rsp), %rcx
    77f7:      	movl	$0x22, %esi
    77fc:      	movl	$0x4, %edx
    7801:      	xorl	%eax, %eax
    7803:      	callq	*%r8
    7806:      	jmp	0x634f <perf_unwind_hotspot+0x634f>
    780b:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    7815:      	movq	%rax, 0x18(%rsp)
    781a:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    7824:      	movq	%rax, 0x10(%rsp)
    7829:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    7833:      	movq	%rax, 0x8(%rsp)
    7838:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    7842:      	movq	%rax, (%rsp)
    7846:      	movw	$0xa, 0x20(%rsp)
    784d:      	movq	%rsp, %rdi
    7850:      	movl	$0x22, %eax
    7855:      	movl	$0x6, %r8d
    785b:      	movq	0x68(%rsp), %rcx
    7860:      	movl	$0x22, %esi
    7865:      	movl	$0x5, %edx
    786a:      	xorl	%eax, %eax
    786c:      	callq	*%r8
    786f:      	jmp	0x64a4 <perf_unwind_hotspot+0x64a4>
    7874:      	movabsq	$0xa7364726f7720, %rax  # imm = 0xA7364726F7720
    787e:      	movq	%rax, 0x26(%rsp)
    7883:      	movabsq	$0x77206425202b2065, %rax # imm = 0x77206425202B2065
    788d:      	movq	%rax, 0x20(%rsp)
    7892:      	movabsq	$0x6d61726620657465, %rax # imm = 0x6D61726620657465
    789c:      	movq	%rax, 0x18(%rsp)
    78a1:      	movabsq	$0x6c706d6f6320676e, %rax # imm = 0x6C706D6F6320676E
    78ab:      	movq	%rax, 0x10(%rsp)
    78b0:      	movabsq	$0x69646e69776e7520, %rax # imm = 0x69646E69776E7520
    78ba:      	movq	%rax, 0x8(%rsp)
    78bf:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    78c9:      	movq	%rax, (%rsp)
    78cd:      	movq	%rsp, %rdi
    78d0:      	movl	$0x2e, %eax
    78d5:      	movl	$0x6, %ecx
    78da:      	xorl	%ebx, %ebx
    78dc:      	movl	$0x2e, %esi
    78e1:      	xorl	%eax, %eax
    78e3:      	callq	*%rcx
    78e5:      	jmp	0x6515 <perf_unwind_hotspot+0x6515>
    78ea:      	movabsq	$0xa786c25203d20, %rax  # imm = 0xA786C25203D20
    78f4:      	movq	%rax, 0x2d(%rsp)
    78f9:      	movabsq	$0x203d20706362202c, %rax # imm = 0x203D20706362202C
    7903:      	movq	%rax, 0x28(%rsp)
    7908:      	movabsq	$0x786c257830203d20, %rax # imm = 0x786C257830203D20
    7912:      	movq	%rax, 0x20(%rsp)
    7917:      	movabsq	$0x646f6874656d6320, %rax # imm = 0x646F6874656D6320
    7921:      	movq	%rax, 0x18(%rsp)
    7926:      	movabsq	$0x2c786c257830203d, %rax # imm = 0x2C786C257830203D
    7930:      	movq	%rax, 0x10(%rsp)
    7935:      	movabsq	$0x20646f6874656d20, %rax # imm = 0x20646F6874656D20
    793f:      	movq	%rax, 0x8(%rsp)
    7944:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    794e:      	movq	%rax, (%rsp)
    7952:      	movq	%rsp, %rdi
    7955:      	movl	$0x35, %eax
    795a:      	movl	$0x6, %r9d
    7960:      	movq	0x100(%rsp), %rcx
    7968:      	movl	$0x35, %esi
    796d:      	movq	0x108(%rsp), %rdx
    7975:      	movq	%r13, %r8
    7978:      	xorl	%eax, %eax
    797a:      	callq	*%r9
    797d:      	movq	0x100(%rsp), %rax
    7985:      	movq	%rax, 0xb8(%rsp)
    798d:      	jmp	0x66dd <perf_unwind_hotspot+0x66dd>
    7992:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    799c:      	movq	%rax, 0x26(%rsp)
    79a1:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    79ab:      	movq	%rax, 0x20(%rsp)
    79b0:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    79ba:      	movq	%rax, 0x18(%rsp)
    79bf:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    79c9:      	movq	%rax, 0x10(%rsp)
    79ce:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    79d8:      	movq	%rax, 0x8(%rsp)
    79dd:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    79e7:      	movq	%rax, (%rsp)
    79eb:      	movq	%rsp, %rdi
    79ee:      	movl	$0x2e, %eax
    79f3:      	movl	$0x6, %ecx
    79f8:      	movl	0x100(%rsp), %edx
    79ff:      	movl	$0x2e, %esi
    7a04:      	xorl	%eax, %eax
    7a06:      	callq	*%rcx
    7a08:      	jmp	0x67ac <perf_unwind_hotspot+0x67ac>
    7a0d:      	movq	(%rip), %rax            # 0x7a14 <perf_unwind_hotspot+0x7a14>
    7a14:      	cmpl	$0x0, (%rax)
    7a17:      	je	0x7a8e <perf_unwind_hotspot+0x7a8e>
    7a19:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    7a23:      	movq	%rax, 0x66(%rsp)
    7a28:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    7a32:      	movq	%rax, 0x60(%rsp)
    7a37:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    7a41:      	movq	%rax, 0x58(%rsp)
    7a46:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    7a50:      	movq	%rax, 0x50(%rsp)
    7a55:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    7a5f:      	movq	%rax, 0x48(%rsp)
    7a64:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7a6e:      	movq	%rax, 0x40(%rsp)
    7a73:      	leaq	0x40(%rsp), %rdi
    7a78:      	movl	$0x2e, %eax
    7a7d:      	movl	$0x6, %ecx
    7a82:      	movl	(%rsp), %edx
    7a85:      	movl	$0x2e, %esi
    7a8a:      	xorl	%eax, %eax
    7a8c:      	callq	*%rcx
    7a8e:      	movzwl	0x20(%rbx), %r12d
    7a93:      	cmpl	$0x2, %r12d
    7a97:      	jne	0x34c <perf_unwind_hotspot+0x34c>
    7a9d:      	movl	$0x29, 0xc8(%rsp)
    7aa8:      	movq	(%rip), %rdi            # 0x7aaf <perf_unwind_hotspot+0x7aaf>
    7aaf:      	leaq	0xc8(%rsp), %rsi
    7ab7:      	movl	$0x1, %eax
    7abc:      	callq	*%rax
    7abe:      	testq	%rax, %rax
    7ac1:      	je	0x7b88 <perf_unwind_hotspot+0x7b88>
    7ac7:      	incq	(%rax)
    7aca:      	movq	(%rip), %rax            # 0x7ad1 <perf_unwind_hotspot+0x7ad1>
    7ad1:      	cmpl	$0x0, (%rax)
    7ad4:      	movq	0xed0(%r14), %rax
    7adb:      	movq	%rax, 0xb8(%rsp)
    7ae3:      	movq	0xed8(%r14), %rax
    7aea:      	movq	%rax, 0x38(%rsp)
    7aef:      	movq	0xee0(%r14), %rax
    7af6:      	movq	%rax, 0xa8(%rsp)
    7afe:      	je	0x7bc2 <perf_unwind_hotspot+0x7bc2>
    7b04:      	movabsq	$0x252074657366666f, %rax # imm = 0x252074657366666F
    7b0e:      	movq	%rax, 0x60(%rsp)
    7b13:      	movabsq	$0x202c786c25207472, %rax # imm = 0x202C786C25207472
    7b1d:      	movq	%rax, 0x58(%rsp)
    7b22:      	movabsq	$0x6174732065646f63, %rax # imm = 0x6174732065646F63
    7b2c:      	movq	%rax, 0x50(%rsp)
    7b31:      	movabsq	$0x206e6920786c2520, %rax # imm = 0x206E6920786C2520
    7b3b:      	movq	%rax, 0x48(%rsp)
    7b40:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    7b4a:      	movq	%rax, 0x40(%rsp)
    7b4f:      	movl	$0xa786c, 0x68(%rsp)    # imm = 0xA786C
    7b57:      	leaq	0x40(%rsp), %rdi
    7b5c:      	movl	$0x2c, %eax
    7b61:      	movl	$0x6, %r9d
    7b67:      	movq	0xf20(%r14), %rcx
    7b6e:      	movq	0xed0(%r14), %rdx
    7b75:      	movq	0xf18(%r14), %r8
    7b7c:      	movl	$0x2c, %esi
    7b81:      	xorl	%eax, %eax
    7b83:      	callq	*%r9
    7b86:      	jmp	0x7bc2 <perf_unwind_hotspot+0x7bc2>
    7b88:      	movq	(%rip), %rax            # 0x7b8f <perf_unwind_hotspot+0x7b8f>
    7b8f:      	cmpl	$0x0, (%rax)
    7b92:      	jne	0x802c <perf_unwind_hotspot+0x802c>
    7b98:      	movq	0xed0(%r14), %rax
    7b9f:      	movq	%rax, 0xb8(%rsp)
    7ba7:      	movq	0xed8(%r14), %rax
    7bae:      	movq	%rax, 0x38(%rsp)
    7bb3:      	movq	0xee0(%r14), %rax
    7bba:      	movq	%rax, 0xa8(%rsp)
    7bc2:      	movzbl	0x20(%r15), %eax
    7bc7:      	shrxq	%rax, 0xf18(%r14), %r13
    7bd0:      	movq	0xf10(%r14), %rbx
    7bd7:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    7be1:      	andq	%rax, %rbx
    7be4:      	leaq	(%rbx,%r13), %rdx
    7be8:      	movq	%rsp, %rdi
    7beb:      	movl	$0x1, %eax
    7bf0:      	movl	$0x70, %ecx
    7bf5:      	movl	$0x1, %esi
    7bfa:      	callq	*%rcx
    7bfc:      	testq	%rax, %rax
    7bff:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    7c05:      	movq	(%rip), %rax            # 0x7c0c <perf_unwind_hotspot+0x7c0c>
    7c0c:      	cmpl	$0x0, (%rax)
    7c0f:      	jne	0x80aa <perf_unwind_hotspot+0x80aa>
    7c15:      	movzbl	(%rsp), %eax
    7c19:      	leal	0x1(%rax), %ecx
    7c1c:      	cmpb	$0x2, %cl
    7c1f:      	jae	0x8117 <perf_unwind_hotspot+0x8117>
    7c25:      	testb	%al, %al
    7c27:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    7c2d:      	movzbl	0x20(%r15), %eax
    7c32:      	shlxq	%rax, %r13, %rax
    7c37:      	addq	0xf20(%r14), %rax
    7c3e:      	movzbl	0x1b(%r15), %ebx
    7c43:      	addq	%rax, %rbx
    7c46:      	movq	(%rip), %rax            # 0x7c4d <perf_unwind_hotspot+0x7c4d>
    7c4d:      	cmpl	$0x0, (%rax)
    7c50:      	je	0x7cae <perf_unwind_hotspot+0x7cae>
    7c52:      	movabsq	$0xa786c2520626f6c, %rax # imm = 0xA786C2520626F6C
    7c5c:      	movq	%rax, 0x58(%rsp)
    7c61:      	movabsq	$0x6265646f63206f74, %rax # imm = 0x6265646F63206F74
    7c6b:      	movq	%rax, 0x50(%rsp)
    7c70:      	movabsq	$0x2064657070616d20, %rax # imm = 0x2064657070616D20
    7c7a:      	movq	%rax, 0x48(%rsp)
    7c7f:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    7c89:      	movq	%rax, 0x40(%rsp)
    7c8e:      	movb	$0x0, 0x60(%rsp)
    7c93:      	leaq	0x40(%rsp), %rdi
    7c98:      	movl	$0x21, %eax
    7c9d:      	movl	$0x6, %ecx
    7ca2:      	movl	$0x21, %esi
    7ca7:      	movq	%rbx, %rdx
    7caa:      	xorl	%eax, %eax
    7cac:      	callq	*%rcx
    7cae:      	movq	%rbx, 0xc8(%rsp)
    7cb6:      	testq	%rbx, %rbx
    7cb9:      	je	0x237 <perf_unwind_hotspot+0x237>
    7cbf:      	movl	$0x200, %eax            # imm = 0x200
    7cc4:      	movl	$0x70, %ecx
    7cc9:      	movq	0x120(%rsp), %rdi
    7cd1:      	movq	0xc8(%rsp), %rdx
    7cd9:      	movl	$0x200, %esi            # imm = 0x200
    7cde:      	callq	*%rcx
    7ce0:      	testq	%rax, %rax
    7ce3:      	jne	0x300 <perf_unwind_hotspot+0x300>
    7ce9:      	movzwl	0x10(%r15), %eax
    7cee:      	movl	$0x1, %ebx
    7cf3:      	cmpq	$0x1f8, %rax            # imm = 0x1F8
    7cf9:      	ja	0x347 <perf_unwind_hotspot+0x347>
    7cff:      	movzwl	0x12(%r15), %ecx
    7d04:      	cmpq	$0x1fc, %rcx            # imm = 0x1FC
    7d0b:      	ja	0x347 <perf_unwind_hotspot+0x347>
    7d11:      	movzwl	0x14(%r15), %edx
    7d16:      	cmpq	$0x1f8, %rdx            # imm = 0x1F8
    7d1d:      	ja	0x347 <perf_unwind_hotspot+0x347>
    7d23:      	movzbl	0x17(%r15), %esi
    7d28:      	movq	0x120(%rsp), %rdi
    7d30:      	movq	(%rdi,%rsi), %rsi
    7d34:      	movq	%rsi, 0xd0(%rsp)
    7d3c:      	movzbl	0x18(%r15), %esi
    7d41:      	movq	(%rdi,%rsi), %rsi
    7d45:      	movq	%rsi, 0xd8(%rsp)
    7d4d:      	movzbl	0x1a(%r15), %esi
    7d52:      	movl	(%rdi,%rsi), %esi
    7d55:      	shll	$0x3, %esi
    7d58:      	movl	%esi, 0xf0(%rsp)
    7d5f:      	movzbl	0x19(%r15), %esi
    7d64:      	movzwl	(%rdi,%rsi), %esi
    7d68:      	movw	%si, 0xf8(%rsp)
    7d70:      	movl	(%rdi,%rcx), %ecx
    7d73:      	movl	%ecx, 0xf4(%rsp)
    7d7a:      	movl	(%rdi,%rdx), %ecx
    7d7d:      	movl	%ecx, 0xec(%rsp)
    7d84:      	movq	(%rdi,%rax), %rax
    7d88:      	movq	%rax, 0xe0(%rsp)
    7d90:      	movzbl	0x16(%r15), %eax
    7d95:      	movq	(%rdi,%rax), %rdx
    7d99:      	movl	$0x4, %eax
    7d9e:      	movl	$0x70, %ecx
    7da3:      	leaq	0xe8(%rsp), %rdi
    7dab:      	movl	$0x4, %esi
    7db0:      	callq	*%rcx
    7db2:      	testq	%rax, %rax
    7db5:      	jne	0x300 <perf_unwind_hotspot+0x300>
    7dbb:      	cmpb	$0x0, 0x21(%r15)
    7dc0:      	je	0x7dee <perf_unwind_hotspot+0x7dee>
    7dc2:      	movq	0xc8(%rsp), %rax
    7dca:      	movl	0xd0(%rsp), %ecx
    7dd1:      	addq	%rax, %rcx
    7dd4:      	movq	%rcx, 0xd0(%rsp)
    7ddc:      	movl	0xd8(%rsp), %ecx
    7de3:      	addq	%rax, %rcx
    7de6:      	movq	%rcx, 0xd8(%rsp)
    7dee:      	movq	(%rip), %rax            # 0x7df5 <perf_unwind_hotspot+0x7df5>
    7df5:      	cmpl	$0x0, (%rax)
    7df8:      	je	0x7efd <perf_unwind_hotspot+0x7efd>
    7dfe:      	movabsq	$0xa786c252d786c, %rax  # imm = 0xA786C252D786C
    7e08:      	movq	%rax, 0x4f(%rsp)
    7e0d:      	movabsq	$0x6c252065646f6320, %rax # imm = 0x6C252065646F6320
    7e17:      	movq	%rax, 0x48(%rsp)
    7e1c:      	movabsq	$0x3e2d20203a6d766a, %rbx # imm = 0x3E2D20203A6D766A
    7e26:      	movq	%rbx, 0x40(%rsp)
    7e2b:      	leaq	0x40(%rsp), %rdi
    7e30:      	movl	$0x17, %eax
    7e35:      	movl	$0x6, %r8d
    7e3b:      	movq	0xd0(%rsp), %rdx
    7e43:      	movq	0xd8(%rsp), %rcx
    7e4b:      	movl	$0x17, %esi
    7e50:      	xorl	%eax, %eax
    7e52:      	callq	*%r8
    7e55:      	movq	(%rip), %rax            # 0x7e5c <perf_unwind_hotspot+0x7e5c>
    7e5c:      	cmpl	$0x0, (%rax)
    7e5f:      	je	0x7efd <perf_unwind_hotspot+0x7efd>
    7e65:      	movabsq	$0x783020657079745f, %rax # imm = 0x783020657079745F
    7e6f:      	movq	%rax, 0x70(%rsp)
    7e74:      	movabsq	$0x656d617266202c75, %rax # imm = 0x656D617266202C75
    7e7e:      	movq	%rax, 0x68(%rsp)
    7e83:      	movabsq	$0x2520657a69735f65, %rax # imm = 0x2520657A69735F65
    7e8d:      	movq	%rax, 0x60(%rsp)
    7e92:      	movabsq	$0x6d617266202c7525, %rax # imm = 0x6D617266202C7525
    7e9c:      	movq	%rax, 0x58(%rsp)
    7ea1:      	movabsq	$0x206574656c706d6f, %rax # imm = 0x206574656C706D6F
    7eab:      	movq	%rax, 0x50(%rsp)
    7eb0:      	movabsq	$0x635f656d61726620, %rax # imm = 0x635F656D61726620
    7eba:      	movq	%rax, 0x48(%rsp)
    7ebf:      	movq	%rbx, 0x40(%rsp)
    7ec4:      	movl	$0xa7825, 0x78(%rsp)    # imm = 0xA7825
    7ecc:      	leaq	0x40(%rsp), %rdi
    7ed1:      	movl	$0x3c, %eax
    7ed6:      	movl	$0x6, %r9d
    7edc:      	movzwl	0xf8(%rsp), %edx
    7ee4:      	movl	0xe8(%rsp), %r8d
    7eec:      	movl	0xf0(%rsp), %ecx
    7ef3:      	movl	$0x3c, %esi
    7ef8:      	xorl	%eax, %eax
    7efa:      	callq	*%r9
    7efd:      	movq	0xc8(%rsp), %rax
    7f05:      	movq	%rax, 0xc0(%rsp)
    7f0d:      	movq	0xd0(%rsp), %rax
    7f15:      	movl	0xe8(%rsp), %edx
    7f1c:      	movq	0xb8(%rsp), %rcx
    7f24:      	subl	%eax, %ecx
    7f26:      	movq	%rcx, 0x118(%rsp)
    7f2e:      	movq	%rdx, 0x120(%rsp)
    7f36:      	cmpl	$0x6974616d, %edx       # imm = 0x6974616D
    7f3c:      	jg	0x87fe <perf_unwind_hotspot+0x87fe>
    7f42:      	cmpl	$0x62617476, 0x120(%rsp) # imm = 0x62617476
    7f4d:      	je	0x8981 <perf_unwind_hotspot+0x8981>
    7f53:      	cmpl	$0x65746e49, 0x120(%rsp) # imm = 0x65746E49
    7f5e:      	jne	0x8a86 <perf_unwind_hotspot+0x8a86>
    7f64:      	movabsq	$0xa656d61726620, %r12  # imm = 0xA656D61726620
    7f6e:      	movq	0x38(%rsp), %rax
    7f73:      	cmpq	%rax, 0xa8(%rsp)
    7f7b:      	jb	0x89ed <perf_unwind_hotspot+0x89ed>
    7f81:      	movq	0x38(%rsp), %rax
    7f86:      	addq	$0x1000, %rax           # imm = 0x1000
    7f8c:      	cmpq	%rax, 0xa8(%rsp)
    7f94:      	jae	0x89ed <perf_unwind_hotspot+0x89ed>
    7f9a:      	movq	0xa8(%rsp), %rax
    7fa2:      	leaq	-0x50(%rax), %rdx
    7fa6:      	leaq	0x40(%rsp), %rdi
    7fab:      	movl	$0x60, %eax
    7fb0:      	movl	$0x70, %ecx
    7fb5:      	movl	$0x60, %esi
    7fba:      	callq	*%rcx
    7fbc:      	movabsq	$0x2072657465727072, %rbx # imm = 0x2072657465727072
    7fc6:      	testq	%rax, %rax
    7fc9:      	je	0x8a63 <perf_unwind_hotspot+0x8a63>
    7fcf:      	movq	(%rip), %rax            # 0x7fd6 <perf_unwind_hotspot+0x7fd6>
    7fd6:      	cmpl	$0x0, (%rax)
    7fd9:      	je	0x8d2a <perf_unwind_hotspot+0x8d2a>
    7fdf:      	movq	%r12, 0x1f(%rsp)
    7fe4:      	movq	%rbx, 0x18(%rsp)
    7fe9:      	movabsq	$0x65746e6920646165, %rax # imm = 0x65746E6920646165
    7ff3:      	movq	%rax, 0x10(%rsp)
    7ff8:      	movabsq	$0x72206f742064656c, %rax # imm = 0x72206F742064656C
    8002:      	movq	%rax, 0x8(%rsp)
    8007:      	movabsq	$0x696166203a6d766a, %rax # imm = 0x696166203A6D766A
    8011:      	movq	%rax, (%rsp)
    8015:      	movq	%rsp, %rdi
    8018:      	movl	$0x27, %eax
    801d:      	movl	$0x6, %ecx
    8022:      	movl	$0x27, %esi
    8027:      	jmp	0x8d26 <perf_unwind_hotspot+0x8d26>
    802c:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    8036:      	movq	%rax, 0x66(%rsp)
    803b:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    8045:      	movq	%rax, 0x60(%rsp)
    804a:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    8054:      	movq	%rax, 0x58(%rsp)
    8059:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    8063:      	movq	%rax, 0x50(%rsp)
    8068:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    8072:      	movq	%rax, 0x48(%rsp)
    8077:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    8081:      	movq	%rax, 0x40(%rsp)
    8086:      	leaq	0x40(%rsp), %rdi
    808b:      	movl	$0x2e, %eax
    8090:      	movl	$0x6, %ecx
    8095:      	movl	0xc8(%rsp), %edx
    809c:      	movl	$0x2e, %esi
    80a1:      	xorl	%eax, %eax
    80a3:      	callq	*%rcx
    80a5:      	jmp	0x7aca <perf_unwind_hotspot+0x7aca>
    80aa:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    80b4:      	movq	%rax, 0x55(%rsp)
    80b9:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    80c3:      	movq	%rax, 0x50(%rsp)
    80c8:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    80d2:      	movq	%rax, 0x48(%rsp)
    80d7:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    80e1:      	movq	%rax, 0x40(%rsp)
    80e6:      	leaq	0x40(%rsp), %rdi
    80eb:      	movl	$0x1d, %eax
    80f0:      	movl	$0x6, %r8d
    80f6:      	movzbl	(%rsp), %ecx
    80fa:      	movl	$0x1d, %esi
    80ff:      	movq	%r13, %rdx
    8102:      	xorl	%eax, %eax
    8104:      	callq	*%r8
    8107:      	movzbl	(%rsp), %eax
    810b:      	leal	0x1(%rax), %ecx
    810e:      	cmpb	$0x2, %cl
    8111:      	jb	0x7c25 <perf_unwind_hotspot+0x7c25>
    8117:      	movzbl	%al, %eax
    811a:      	subq	%rax, %r13
    811d:      	leaq	(%rbx,%r13), %rdx
    8121:      	movq	%rsp, %rdi
    8124:      	movl	$0x1, %eax
    8129:      	movl	$0x70, %ecx
    812e:      	movl	$0x1, %esi
    8133:      	callq	*%rcx
    8135:      	testq	%rax, %rax
    8138:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    813e:      	movq	(%rip), %rax            # 0x8145 <perf_unwind_hotspot+0x8145>
    8145:      	cmpl	$0x0, (%rax)
    8148:      	je	0x81a7 <perf_unwind_hotspot+0x81a7>
    814a:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    8154:      	movq	%rax, 0x55(%rsp)
    8159:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    8163:      	movq	%rax, 0x50(%rsp)
    8168:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    8172:      	movq	%rax, 0x48(%rsp)
    8177:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    8181:      	movq	%rax, 0x40(%rsp)
    8186:      	leaq	0x40(%rsp), %rdi
    818b:      	movl	$0x1d, %eax
    8190:      	movl	$0x6, %r8d
    8196:      	movzbl	(%rsp), %ecx
    819a:      	movl	$0x1d, %esi
    819f:      	movq	%r13, %rdx
    81a2:      	xorl	%eax, %eax
    81a4:      	callq	*%r8
    81a7:      	movzbl	(%rsp), %eax
    81ab:      	leal	0x1(%rax), %ecx
    81ae:      	cmpb	$0x2, %cl
    81b1:      	jb	0x7c25 <perf_unwind_hotspot+0x7c25>
    81b7:      	movzbl	%al, %eax
    81ba:      	subq	%rax, %r13
    81bd:      	leaq	(%rbx,%r13), %rdx
    81c1:      	movq	%rsp, %rdi
    81c4:      	movl	$0x1, %eax
    81c9:      	movl	$0x70, %ecx
    81ce:      	movl	$0x1, %esi
    81d3:      	callq	*%rcx
    81d5:      	testq	%rax, %rax
    81d8:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    81de:      	movq	(%rip), %rax            # 0x81e5 <perf_unwind_hotspot+0x81e5>
    81e5:      	cmpl	$0x0, (%rax)
    81e8:      	je	0x8247 <perf_unwind_hotspot+0x8247>
    81ea:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    81f4:      	movq	%rax, 0x55(%rsp)
    81f9:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    8203:      	movq	%rax, 0x50(%rsp)
    8208:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    8212:      	movq	%rax, 0x48(%rsp)
    8217:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    8221:      	movq	%rax, 0x40(%rsp)
    8226:      	leaq	0x40(%rsp), %rdi
    822b:      	movl	$0x1d, %eax
    8230:      	movl	$0x6, %r8d
    8236:      	movzbl	(%rsp), %ecx
    823a:      	movl	$0x1d, %esi
    823f:      	movq	%r13, %rdx
    8242:      	xorl	%eax, %eax
    8244:      	callq	*%r8
    8247:      	movzbl	(%rsp), %eax
    824b:      	leal	0x1(%rax), %ecx
    824e:      	cmpb	$0x2, %cl
    8251:      	jb	0x7c25 <perf_unwind_hotspot+0x7c25>
    8257:      	movzbl	%al, %eax
    825a:      	subq	%rax, %r13
    825d:      	leaq	(%rbx,%r13), %rdx
    8261:      	movq	%rsp, %rdi
    8264:      	movl	$0x1, %eax
    8269:      	movl	$0x70, %ecx
    826e:      	movl	$0x1, %esi
    8273:      	callq	*%rcx
    8275:      	testq	%rax, %rax
    8278:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    827e:      	movq	(%rip), %rax            # 0x8285 <perf_unwind_hotspot+0x8285>
    8285:      	cmpl	$0x0, (%rax)
    8288:      	je	0x82e7 <perf_unwind_hotspot+0x82e7>
    828a:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    8294:      	movq	%rax, 0x55(%rsp)
    8299:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    82a3:      	movq	%rax, 0x50(%rsp)
    82a8:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    82b2:      	movq	%rax, 0x48(%rsp)
    82b7:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    82c1:      	movq	%rax, 0x40(%rsp)
    82c6:      	leaq	0x40(%rsp), %rdi
    82cb:      	movl	$0x1d, %eax
    82d0:      	movl	$0x6, %r8d
    82d6:      	movzbl	(%rsp), %ecx
    82da:      	movl	$0x1d, %esi
    82df:      	movq	%r13, %rdx
    82e2:      	xorl	%eax, %eax
    82e4:      	callq	*%r8
    82e7:      	movzbl	(%rsp), %eax
    82eb:      	leal	0x1(%rax), %ecx
    82ee:      	cmpb	$0x2, %cl
    82f1:      	jb	0x7c25 <perf_unwind_hotspot+0x7c25>
    82f7:      	movzbl	%al, %eax
    82fa:      	subq	%rax, %r13
    82fd:      	leaq	(%rbx,%r13), %rdx
    8301:      	movq	%rsp, %rdi
    8304:      	movl	$0x1, %eax
    8309:      	movl	$0x70, %ecx
    830e:      	movl	$0x1, %esi
    8313:      	callq	*%rcx
    8315:      	testq	%rax, %rax
    8318:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    831e:      	movq	(%rip), %rax            # 0x8325 <perf_unwind_hotspot+0x8325>
    8325:      	cmpl	$0x0, (%rax)
    8328:      	je	0x8387 <perf_unwind_hotspot+0x8387>
    832a:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    8334:      	movq	%rax, 0x55(%rsp)
    8339:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    8343:      	movq	%rax, 0x50(%rsp)
    8348:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    8352:      	movq	%rax, 0x48(%rsp)
    8357:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    8361:      	movq	%rax, 0x40(%rsp)
    8366:      	leaq	0x40(%rsp), %rdi
    836b:      	movl	$0x1d, %eax
    8370:      	movl	$0x6, %r8d
    8376:      	movzbl	(%rsp), %ecx
    837a:      	movl	$0x1d, %esi
    837f:      	movq	%r13, %rdx
    8382:      	xorl	%eax, %eax
    8384:      	callq	*%r8
    8387:      	movzbl	(%rsp), %eax
    838b:      	leal	0x1(%rax), %ecx
    838e:      	cmpb	$0x2, %cl
    8391:      	jb	0x7c25 <perf_unwind_hotspot+0x7c25>
    8397:      	movzbl	%al, %eax
    839a:      	subq	%rax, %r13
    839d:      	leaq	(%rbx,%r13), %rdx
    83a1:      	movq	%rsp, %rdi
    83a4:      	movl	$0x1, %eax
    83a9:      	movl	$0x70, %ecx
    83ae:      	movl	$0x1, %esi
    83b3:      	callq	*%rcx
    83b5:      	testq	%rax, %rax
    83b8:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    83be:      	movq	(%rip), %rax            # 0x83c5 <perf_unwind_hotspot+0x83c5>
    83c5:      	cmpl	$0x0, (%rax)
    83c8:      	je	0x8427 <perf_unwind_hotspot+0x8427>
    83ca:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    83d4:      	movq	%rax, 0x55(%rsp)
    83d9:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    83e3:      	movq	%rax, 0x50(%rsp)
    83e8:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    83f2:      	movq	%rax, 0x48(%rsp)
    83f7:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    8401:      	movq	%rax, 0x40(%rsp)
    8406:      	leaq	0x40(%rsp), %rdi
    840b:      	movl	$0x1d, %eax
    8410:      	movl	$0x6, %r8d
    8416:      	movzbl	(%rsp), %ecx
    841a:      	movl	$0x1d, %esi
    841f:      	movq	%r13, %rdx
    8422:      	xorl	%eax, %eax
    8424:      	callq	*%r8
    8427:      	movzbl	(%rsp), %eax
    842b:      	leal	0x1(%rax), %ecx
    842e:      	cmpb	$0x2, %cl
    8431:      	jb	0x7c25 <perf_unwind_hotspot+0x7c25>
    8437:      	movzbl	%al, %eax
    843a:      	subq	%rax, %r13
    843d:      	leaq	(%rbx,%r13), %rdx
    8441:      	movq	%rsp, %rdi
    8444:      	movl	$0x1, %eax
    8449:      	movl	$0x70, %ecx
    844e:      	movl	$0x1, %esi
    8453:      	callq	*%rcx
    8455:      	testq	%rax, %rax
    8458:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    845e:      	movq	(%rip), %rax            # 0x8465 <perf_unwind_hotspot+0x8465>
    8465:      	cmpl	$0x0, (%rax)
    8468:      	je	0x84c7 <perf_unwind_hotspot+0x84c7>
    846a:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    8474:      	movq	%rax, 0x55(%rsp)
    8479:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    8483:      	movq	%rax, 0x50(%rsp)
    8488:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    8492:      	movq	%rax, 0x48(%rsp)
    8497:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    84a1:      	movq	%rax, 0x40(%rsp)
    84a6:      	leaq	0x40(%rsp), %rdi
    84ab:      	movl	$0x1d, %eax
    84b0:      	movl	$0x6, %r8d
    84b6:      	movzbl	(%rsp), %ecx
    84ba:      	movl	$0x1d, %esi
    84bf:      	movq	%r13, %rdx
    84c2:      	xorl	%eax, %eax
    84c4:      	callq	*%r8
    84c7:      	movzbl	(%rsp), %eax
    84cb:      	leal	0x1(%rax), %ecx
    84ce:      	cmpb	$0x2, %cl
    84d1:      	jb	0x7c25 <perf_unwind_hotspot+0x7c25>
    84d7:      	movzbl	%al, %eax
    84da:      	subq	%rax, %r13
    84dd:      	leaq	(%rbx,%r13), %rdx
    84e1:      	movq	%rsp, %rdi
    84e4:      	movl	$0x1, %eax
    84e9:      	movl	$0x70, %ecx
    84ee:      	movl	$0x1, %esi
    84f3:      	callq	*%rcx
    84f5:      	testq	%rax, %rax
    84f8:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    84fe:      	movq	(%rip), %rax            # 0x8505 <perf_unwind_hotspot+0x8505>
    8505:      	cmpl	$0x0, (%rax)
    8508:      	je	0x8567 <perf_unwind_hotspot+0x8567>
    850a:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    8514:      	movq	%rax, 0x55(%rsp)
    8519:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    8523:      	movq	%rax, 0x50(%rsp)
    8528:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    8532:      	movq	%rax, 0x48(%rsp)
    8537:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    8541:      	movq	%rax, 0x40(%rsp)
    8546:      	leaq	0x40(%rsp), %rdi
    854b:      	movl	$0x1d, %eax
    8550:      	movl	$0x6, %r8d
    8556:      	movzbl	(%rsp), %ecx
    855a:      	movl	$0x1d, %esi
    855f:      	movq	%r13, %rdx
    8562:      	xorl	%eax, %eax
    8564:      	callq	*%r8
    8567:      	movzbl	(%rsp), %eax
    856b:      	leal	0x1(%rax), %ecx
    856e:      	cmpb	$0x2, %cl
    8571:      	jb	0x7c25 <perf_unwind_hotspot+0x7c25>
    8577:      	movzbl	%al, %eax
    857a:      	subq	%rax, %r13
    857d:      	leaq	(%rbx,%r13), %rdx
    8581:      	movq	%rsp, %rdi
    8584:      	movl	$0x1, %eax
    8589:      	movl	$0x70, %ecx
    858e:      	movl	$0x1, %esi
    8593:      	callq	*%rcx
    8595:      	testq	%rax, %rax
    8598:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    859e:      	movq	(%rip), %rax            # 0x85a5 <perf_unwind_hotspot+0x85a5>
    85a5:      	cmpl	$0x0, (%rax)
    85a8:      	je	0x8607 <perf_unwind_hotspot+0x8607>
    85aa:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    85b4:      	movq	%rax, 0x55(%rsp)
    85b9:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    85c3:      	movq	%rax, 0x50(%rsp)
    85c8:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    85d2:      	movq	%rax, 0x48(%rsp)
    85d7:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    85e1:      	movq	%rax, 0x40(%rsp)
    85e6:      	leaq	0x40(%rsp), %rdi
    85eb:      	movl	$0x1d, %eax
    85f0:      	movl	$0x6, %r8d
    85f6:      	movzbl	(%rsp), %ecx
    85fa:      	movl	$0x1d, %esi
    85ff:      	movq	%r13, %rdx
    8602:      	xorl	%eax, %eax
    8604:      	callq	*%r8
    8607:      	movzbl	(%rsp), %eax
    860b:      	leal	0x1(%rax), %ecx
    860e:      	cmpb	$0x2, %cl
    8611:      	jb	0x7c25 <perf_unwind_hotspot+0x7c25>
    8617:      	movzbl	%al, %eax
    861a:      	subq	%rax, %r13
    861d:      	leaq	(%rbx,%r13), %rdx
    8621:      	movq	%rsp, %rdi
    8624:      	movl	$0x1, %eax
    8629:      	movl	$0x70, %ecx
    862e:      	movl	$0x1, %esi
    8633:      	callq	*%rcx
    8635:      	testq	%rax, %rax
    8638:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    863e:      	movq	(%rip), %rax            # 0x8645 <perf_unwind_hotspot+0x8645>
    8645:      	cmpl	$0x0, (%rax)
    8648:      	je	0x86a7 <perf_unwind_hotspot+0x86a7>
    864a:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    8654:      	movq	%rax, 0x55(%rsp)
    8659:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    8663:      	movq	%rax, 0x50(%rsp)
    8668:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    8672:      	movq	%rax, 0x48(%rsp)
    8677:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    8681:      	movq	%rax, 0x40(%rsp)
    8686:      	leaq	0x40(%rsp), %rdi
    868b:      	movl	$0x1d, %eax
    8690:      	movl	$0x6, %r8d
    8696:      	movzbl	(%rsp), %ecx
    869a:      	movl	$0x1d, %esi
    869f:      	movq	%r13, %rdx
    86a2:      	xorl	%eax, %eax
    86a4:      	callq	*%r8
    86a7:      	movzbl	(%rsp), %eax
    86ab:      	leal	0x1(%rax), %ecx
    86ae:      	cmpb	$0x2, %cl
    86b1:      	jb	0x7c25 <perf_unwind_hotspot+0x7c25>
    86b7:      	movzbl	%al, %eax
    86ba:      	subq	%rax, %r13
    86bd:      	leaq	(%rbx,%r13), %rdx
    86c1:      	movq	%rsp, %rdi
    86c4:      	movl	$0x1, %eax
    86c9:      	movl	$0x70, %ecx
    86ce:      	movl	$0x1, %esi
    86d3:      	callq	*%rcx
    86d5:      	testq	%rax, %rax
    86d8:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    86de:      	movq	(%rip), %rax            # 0x86e5 <perf_unwind_hotspot+0x86e5>
    86e5:      	cmpl	$0x0, (%rax)
    86e8:      	je	0x8747 <perf_unwind_hotspot+0x8747>
    86ea:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    86f4:      	movq	%rax, 0x55(%rsp)
    86f9:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    8703:      	movq	%rax, 0x50(%rsp)
    8708:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    8712:      	movq	%rax, 0x48(%rsp)
    8717:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    8721:      	movq	%rax, 0x40(%rsp)
    8726:      	leaq	0x40(%rsp), %rdi
    872b:      	movl	$0x1d, %eax
    8730:      	movl	$0x6, %r8d
    8736:      	movzbl	(%rsp), %ecx
    873a:      	movl	$0x1d, %esi
    873f:      	movq	%r13, %rdx
    8742:      	xorl	%eax, %eax
    8744:      	callq	*%r8
    8747:      	movzbl	(%rsp), %eax
    874b:      	leal	0x1(%rax), %ecx
    874e:      	cmpb	$0x2, %cl
    8751:      	jb	0x7c25 <perf_unwind_hotspot+0x7c25>
    8757:      	movzbl	%al, %eax
    875a:      	subq	%rax, %r13
    875d:      	addq	%r13, %rbx
    8760:      	movq	%rsp, %rdi
    8763:      	movl	$0x1, %eax
    8768:      	movl	$0x70, %ecx
    876d:      	movl	$0x1, %esi
    8772:      	movq	%rbx, %rdx
    8775:      	callq	*%rcx
    8777:      	testq	%rax, %rax
    877a:      	jne	0x22b <perf_unwind_hotspot+0x22b>
    8780:      	movq	(%rip), %rax            # 0x8787 <perf_unwind_hotspot+0x8787>
    8787:      	cmpl	$0x0, (%rax)
    878a:      	je	0x87e9 <perf_unwind_hotspot+0x87e9>
    878c:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    8796:      	movq	%rax, 0x55(%rsp)
    879b:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    87a5:      	movq	%rax, 0x50(%rsp)
    87aa:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    87b4:      	movq	%rax, 0x48(%rsp)
    87b9:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    87c3:      	movq	%rax, 0x40(%rsp)
    87c8:      	leaq	0x40(%rsp), %rdi
    87cd:      	movl	$0x1d, %eax
    87d2:      	movl	$0x6, %r8d
    87d8:      	movzbl	(%rsp), %ecx
    87dc:      	movl	$0x1d, %esi
    87e1:      	movq	%r13, %rdx
    87e4:      	xorl	%eax, %eax
    87e6:      	callq	*%r8
    87e9:      	movzbl	(%rsp), %eax
    87ed:      	leal	0x1(%rax), %ecx
    87f0:      	cmpb	$0x1, %cl
    87f3:      	ja	0x22b <perf_unwind_hotspot+0x22b>
    87f9:      	jmp	0x7c25 <perf_unwind_hotspot+0x7c25>
    87fe:      	cmpl	$0x6974616e, 0x120(%rsp) # imm = 0x6974616E
    8809:      	je	0x881c <perf_unwind_hotspot+0x881c>
    880b:      	cmpl	$0x74656d6e, 0x120(%rsp) # imm = 0x74656D6E
    8816:      	jne	0x8a86 <perf_unwind_hotspot+0x8a86>
    881c:      	movl	0xf4(%rsp), %ecx
    8823:      	movq	%rcx, 0x120(%rsp)
    882b:      	movq	0xe0(%rsp), %rcx
    8833:      	movl	%ecx, %edx
    8835:      	addq	0xc0(%rsp), %rdx
    883d:      	cmpb	$0x0, 0x21(%r15)
    8842:      	cmoveq	%rcx, %rdx
    8846:      	cmpq	%rdx, 0xb8(%rsp)
    884e:      	jne	0x8b9b <perf_unwind_hotspot+0x8b9b>
    8854:      	movl	0xec(%rsp), %eax
    885b:      	movq	0x38(%rsp), %rsi
    8860:      	addq	%rsi, %rax
    8863:      	movq	%rsp, %rdi
    8866:      	movl	$0x8, %ecx
    886b:      	movl	$0x70, %r8d
    8871:      	movl	0xec(%rsp), %edx
    8878:      	addq	%rsi, %rdx
    887b:      	movl	$0x8, %esi
    8880:      	callq	*%r8
    8883:      	testq	%rax, %rax
    8886:      	jne	0x8b15 <perf_unwind_hotspot+0x8b15>
    888c:      	movq	(%rsp), %rax
    8890:      	movq	0xd0(%rsp), %rcx
    8898:      	cmpq	%rcx, %rax
    889b:      	jb	0x8b15 <perf_unwind_hotspot+0x8b15>
    88a1:      	cmpq	0xd8(%rsp), %rax
    88a9:      	jae	0x8b15 <perf_unwind_hotspot+0x8b15>
    88af:      	movq	(%rip), %rdx            # 0x88b6 <perf_unwind_hotspot+0x88b6>
    88b6:      	cmpl	$0x0, (%rdx)
    88b9:      	je	0x8968 <perf_unwind_hotspot+0x8968>
    88bf:      	movabsq	$0xa2964252b7073, %rax  # imm = 0xA2964252B7073
    88c9:      	movq	%rax, 0x78(%rsp)
    88ce:      	movabsq	$0x206d6f7266282078, %rax # imm = 0x206D6F7266282078
    88d8:      	movq	%rax, 0x70(%rsp)
    88dd:      	movabsq	$0x6c25783020736120, %rax # imm = 0x6C25783020736120
    88e7:      	movq	%rax, 0x68(%rsp)
    88ec:      	movabsq	$0x64657265766f6365, %rax # imm = 0x64657265766F6365
    88f6:      	movq	%rax, 0x60(%rsp)
    88fb:      	movabsq	$0x72206370202c656d, %rax # imm = 0x72206370202C656D
    8905:      	movq	%rax, 0x58(%rsp)
    890a:      	movabsq	$0x6172662064657a69, %rax # imm = 0x6172662064657A69
    8914:      	movq	%rax, 0x50(%rsp)
    8919:      	movabsq	$0x6d6974706f656420, %rax # imm = 0x6D6974706F656420
    8923:      	movq	%rax, 0x48(%rsp)
    8928:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    8932:      	movq	%rax, 0x40(%rsp)
    8937:      	leaq	0x40(%rsp), %rdi
    893c:      	movl	$0x40, %eax
    8941:      	movl	$0x6, %r8d
    8947:      	movq	(%rsp), %rdx
    894b:      	movl	0xec(%rsp), %ecx
    8952:      	movl	$0x40, %esi
    8957:      	xorl	%eax, %eax
    8959:      	callq	*%r8
    895c:      	movq	(%rsp), %rax
    8960:      	movq	0xd0(%rsp), %rcx
    8968:      	movl	%eax, %edx
    896a:      	subl	%ecx, %edx
    896c:      	movq	%rdx, 0x118(%rsp)
    8974:      	movq	%rax, 0xb8(%rsp)
    897c:      	jmp	0x8b93 <perf_unwind_hotspot+0x8b93>
    8981:      	movb	$0x1, %al
    8983:      	movl	%eax, 0xb0(%rsp)
    898a:      	movl	$0x62617476, %eax       # imm = 0x62617476
    898f:      	movq	%rax, 0x120(%rsp)
    8997:      	movq	(%rip), %rax            # 0x899e <perf_unwind_hotspot+0x899e>
    899e:      	cmpl	$0x0, (%rax)
    89a1:      	je	0x96a7 <perf_unwind_hotspot+0x96a7>
    89a7:      	movabsq	$0xa656c62617476, %rax  # imm = 0xA656C62617476
    89b1:      	movq	%rax, 0x50(%rsp)
    89b6:      	movabsq	$0x20646e69776e7520, %rax # imm = 0x20646E69776E7520
    89c0:      	movq	%rax, 0x48(%rsp)
    89c5:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    89cf:      	movq	%rax, 0x40(%rsp)
    89d4:      	leaq	0x40(%rsp), %rdi
    89d9:      	movl	$0x18, %eax
    89de:      	movl	$0x6, %ecx
    89e3:      	movl	$0x18, %esi
    89e8:      	jmp	0x8c46 <perf_unwind_hotspot+0x8c46>
    89ed:      	movq	(%rip), %rax            # 0x89f4 <perf_unwind_hotspot+0x89f4>
    89f4:      	cmpl	$0x0, (%rax)
    89f7:      	je	0x8d2a <perf_unwind_hotspot+0x8d2a>
    89fd:      	movq	%r12, 0x26(%rsp)
    8a02:      	movabsq	$0x6620726574657270, %rax # imm = 0x6620726574657270
    8a0c:      	movq	%rax, 0x20(%rsp)
    8a11:      	movabsq	$0x7265746e69206562, %rax # imm = 0x7265746E69206562
    8a1b:      	movq	%rax, 0x18(%rsp)
    8a20:      	movabsq	$0x206f742079617761, %rax # imm = 0x206F742079617761
    8a2a:      	movq	%rax, 0x10(%rsp)
    8a2f:      	movabsq	$0x20726166206f6f74, %rax # imm = 0x20726166206F6F74
    8a39:      	movq	%rax, 0x8(%rsp)
    8a3e:      	movabsq	$0x207066203a6d766a, %rax # imm = 0x207066203A6D766A
    8a48:      	movq	%rax, (%rsp)
    8a4c:      	movq	%rsp, %rdi
    8a4f:      	movl	$0x2e, %eax
    8a54:      	movl	$0x6, %ecx
    8a59:      	movl	$0x2e, %esi
    8a5e:      	jmp	0x8d26 <perf_unwind_hotspot+0x8d26>
    8a63:      	cmpl	$0x0, 0x2c0(%r14)
    8a6b:      	je	0x8c4f <perf_unwind_hotspot+0x8c4f>
    8a71:      	cmpb	$0x0, 0x1f(%r15)
    8a76:      	je	0x8c58 <perf_unwind_hotspot+0x8c58>
    8a7c:      	movq	0x50(%rsp), %r13
    8a81:      	jmp	0x8c5d <perf_unwind_hotspot+0x8c5d>
    8a86:      	movq	(%rip), %rax            # 0x8a8d <perf_unwind_hotspot+0x8a8d>
    8a8d:      	cmpl	$0x0, (%rax)
    8a90:      	je	0x8aee <perf_unwind_hotspot+0x8aee>
    8a92:      	movabsq	$0x6170206b6361626c, %rax # imm = 0x6170206B6361626C
    8a9c:      	movq	%rax, 0x58(%rsp)
    8aa1:      	movabsq	$0x6c61662062757473, %rax # imm = 0x6C61662062757473
    8aab:      	movq	%rax, 0x50(%rsp)
    8ab0:      	movabsq	$0x20646e69776e7520, %rax # imm = 0x20646E69776E7520
    8aba:      	movq	%rax, 0x48(%rsp)
    8abf:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    8ac9:      	movq	%rax, 0x40(%rsp)
    8ace:      	movl	$0xa6874, 0x60(%rsp)    # imm = 0xA6874
    8ad6:      	leaq	0x40(%rsp), %rdi
    8adb:      	movl	$0x24, %eax
    8ae0:      	movl	$0x6, %ecx
    8ae5:      	movl	$0x24, %esi
    8aea:      	xorl	%eax, %eax
    8aec:      	callq	*%rcx
    8aee:      	movl	0xf0(%rsp), %eax
    8af5:      	movl	$0x0, 0xb0(%rsp)
    8b00:      	movq	0xa8(%rsp), %rcx
    8b08:      	testl	%eax, %eax
    8b0a:      	jne	0x96e3 <perf_unwind_hotspot+0x96e3>
    8b10:      	jmp	0x96ce <perf_unwind_hotspot+0x96ce>
    8b15:      	movq	(%rip), %rax            # 0x8b1c <perf_unwind_hotspot+0x8b1c>
    8b1c:      	cmpl	$0x0, (%rax)
    8b1f:      	je	0x8b93 <perf_unwind_hotspot+0x8b93>
    8b21:      	movabsq	$0xa64656c696166, %rax  # imm = 0xA64656C696166
    8b2b:      	movq	%rax, 0x68(%rsp)
    8b30:      	movabsq	$0x20797265766f6365, %rax # imm = 0x20797265766F6365
    8b3a:      	movq	%rax, 0x60(%rsp)
    8b3f:      	movabsq	$0x72206370202c656d, %rax # imm = 0x72206370202C656D
    8b49:      	movq	%rax, 0x58(%rsp)
    8b4e:      	movabsq	$0x6172662064657a69, %rax # imm = 0x6172662064657A69
    8b58:      	movq	%rax, 0x50(%rsp)
    8b5d:      	movabsq	$0x6d6974706f656420, %rax # imm = 0x6D6974706F656420
    8b67:      	movq	%rax, 0x48(%rsp)
    8b6c:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    8b76:      	movq	%rax, 0x40(%rsp)
    8b7b:      	leaq	0x40(%rsp), %rdi
    8b80:      	movl	$0x30, %eax
    8b85:      	movl	$0x6, %ecx
    8b8a:      	movl	$0x30, %esi
    8b8f:      	xorl	%eax, %eax
    8b91:      	callq	*%rcx
    8b93:      	movq	0xd0(%rsp), %rax
    8b9b:      	movzwl	0xf8(%rsp), %ecx
    8ba3:      	addq	%rax, %rcx
    8ba6:      	cmpq	%rcx, 0xb8(%rsp)
    8bae:      	jae	0x8d5c <perf_unwind_hotspot+0x8d5c>
    8bb4:      	addq	$-0x4, %rcx
    8bb8:      	movq	(%rip), %rax            # 0x8bbf <perf_unwind_hotspot+0x8bbf>
    8bbf:      	movl	(%rax), %eax
    8bc1:      	cmpq	%rcx, 0xb8(%rsp)
    8bc9:      	jae	0x8e23 <perf_unwind_hotspot+0x8e23>
    8bcf:      	movb	$0x3, %cl
    8bd1:      	movl	%ecx, 0xb0(%rsp)
    8bd8:      	testl	%eax, %eax
    8bda:      	je	0x96a7 <perf_unwind_hotspot+0x96a7>
    8be0:      	movabsq	$0x2963702820656d61, %rax # imm = 0x2963702820656D61
    8bea:      	movq	%rax, 0x60(%rsp)
    8bef:      	movabsq	$0x7266206574656c70, %rax # imm = 0x7266206574656C70
    8bf9:      	movq	%rax, 0x58(%rsp)
    8bfe:      	movabsq	$0x6d6f636e6920676e, %rax # imm = 0x6D6F636E6920676E
    8c08:      	movq	%rax, 0x50(%rsp)
    8c0d:      	movabsq	$0x69646e69776e7520, %rax # imm = 0x69646E69776E7520
    8c17:      	movq	%rax, 0x48(%rsp)
    8c1c:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    8c26:      	movq	%rax, 0x40(%rsp)
    8c2b:      	movw	$0xa, 0x68(%rsp)
    8c32:      	leaq	0x40(%rsp), %rdi
    8c37:      	movl	$0x2a, %eax
    8c3c:      	movl	$0x6, %ecx
    8c41:      	movl	$0x2a, %esi
    8c46:      	xorl	%eax, %eax
    8c48:      	callq	*%rcx
    8c4a:      	jmp	0x96a7 <perf_unwind_hotspot+0x96a7>
    8c4f:      	movq	0xf00(%r14), %r13
    8c56:      	jmp	0x8c5d <perf_unwind_hotspot+0x8c5d>
    8c58:      	movq	0x58(%rsp), %r13
    8c5d:      	movq	0x78(%rsp), %r12
    8c62:      	movq	0x88(%rsp), %rax
    8c6a:      	movq	%rax, 0x38(%rsp)
    8c6f:      	movq	0x90(%rsp), %rax
    8c77:      	movq	%rax, 0xa8(%rsp)
    8c7f:      	movq	0x98(%rsp), %rax
    8c87:      	movq	%rax, 0xb8(%rsp)
    8c8f:      	movzbl	0x1c(%r15), %eax
    8c94:      	addq	%r12, %rax
    8c97:      	leaq	0x100(%rsp), %rdi
    8c9f:      	movl	$0x8, %ecx
    8ca4:      	movl	$0x70, %r8d
    8caa:      	movzbl	0x1c(%r15), %edx
    8caf:      	addq	%r12, %rdx
    8cb2:      	movl	$0x8, %esi
    8cb7:      	callq	*%r8
    8cba:      	testq	%rax, %rax
    8cbd:      	je	0x8eab <perf_unwind_hotspot+0x8eab>
    8cc3:      	movq	(%rip), %rax            # 0x8cca <perf_unwind_hotspot+0x8cca>
    8cca:      	cmpl	$0x0, (%rax)
    8ccd:      	je	0x8d2a <perf_unwind_hotspot+0x8d2a>
    8ccf:      	movabsq	$0xa646f6874656d63, %rax # imm = 0xA646F6874656D63
    8cd9:      	movq	%rax, 0x20(%rsp)
    8cde:      	movq	%rbx, 0x18(%rsp)
    8ce3:      	movabsq	$0x65746e6920646165, %rax # imm = 0x65746E6920646165
    8ced:      	movq	%rax, 0x10(%rsp)
    8cf2:      	movabsq	$0x72206f742064656c, %rax # imm = 0x72206F742064656C
    8cfc:      	movq	%rax, 0x8(%rsp)
    8d01:      	movabsq	$0x696166203a6d766a, %rax # imm = 0x696166203A6D766A
    8d0b:      	movq	%rax, (%rsp)
    8d0f:      	movb	$0x0, 0x28(%rsp)
    8d14:      	movq	%rsp, %rdi
    8d17:      	movl	$0x29, %eax
    8d1c:      	movl	$0x6, %ecx
    8d21:      	movl	$0x29, %esi
    8d26:      	xorl	%eax, %eax
    8d28:      	callq	*%rcx
    8d2a:      	movl	$0x2d, 0x114(%rsp)
    8d35:      	movq	(%rip), %rdi            # 0x8d3c <perf_unwind_hotspot+0x8d3c>
    8d3c:      	leaq	0x114(%rsp), %rsi
    8d44:      	movl	$0x1, %eax
    8d49:      	callq	*%rax
    8d4b:      	testq	%rax, %rax
    8d4e:      	je	0x8fc2 <perf_unwind_hotspot+0x8fc2>
    8d54:      	incq	(%rax)
    8d57:      	jmp	0x9044 <perf_unwind_hotspot+0x9044>
    8d5c:      	movl	0xf0(%rsp), %ebx
    8d63:      	movq	0xa8(%rsp), %rdx
    8d6b:      	movq	0x38(%rsp), %rax
    8d70:      	leaq	(%rax,%rbx), %r15
    8d74:      	addq	$0x30, %r15
    8d78:      	subq	%rax, %rdx
    8d7b:      	jb	0x905e <perf_unwind_hotspot+0x905e>
    8d81:      	cmpq	%r15, 0xa8(%rsp)
    8d89:      	jae	0x905e <perf_unwind_hotspot+0x905e>
    8d8f:      	movb	$0x3, %al
    8d91:      	movl	%eax, 0xb0(%rsp)
    8d98:      	movq	(%rip), %rax            # 0x8d9f <perf_unwind_hotspot+0x8d9f>
    8d9f:      	cmpl	$0x0, (%rax)
    8da2:      	je	0x8e16 <perf_unwind_hotspot+0x8e16>
    8da4:      	movabsq	$0xa29646c252065, %rax  # imm = 0xA29646C252065
    8dae:      	movq	%rax, 0x67(%rsp)
    8db3:      	movabsq	$0x657a697320656d61, %rax # imm = 0x657A697320656D61
    8dbd:      	movq	%rax, 0x60(%rsp)
    8dc2:      	movabsq	$0x726628207265746e, %rax # imm = 0x726628207265746E
    8dcc:      	movq	%rax, 0x58(%rsp)
    8dd1:      	movabsq	$0x696f7020656d6172, %rax # imm = 0x696F7020656D6172
    8ddb:      	movq	%rax, 0x50(%rsp)
    8de0:      	movabsq	$0x6620676e69737520, %rax # imm = 0x6620676E69737520
    8dea:      	movq	%rax, 0x48(%rsp)
    8def:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    8df9:      	movq	%rax, 0x40(%rsp)
    8dfe:      	leaq	0x40(%rsp), %rdi
    8e03:      	movl	$0x2f, %eax
    8e08:      	movl	$0x6, %ecx
    8e0d:      	movl	$0x2f, %esi
    8e12:      	xorl	%eax, %eax
    8e14:      	callq	*%rcx
    8e16:      	movq	0xa8(%rsp), %rcx
    8e1e:      	jmp	0x96ce <perf_unwind_hotspot+0x96ce>
    8e23:      	movb	$0x3, %cl
    8e25:      	movl	%ecx, 0xb0(%rsp)
    8e2c:      	testl	%eax, %eax
    8e2e:      	je	0x9684 <perf_unwind_hotspot+0x9684>
    8e34:      	movabsq	$0xa2963702b7066, %rax  # imm = 0xA2963702B7066
    8e3e:      	movq	%rax, 0x65(%rsp)
    8e43:      	movabsq	$0x2b70662820656d61, %rax # imm = 0x2B70662820656D61
    8e4d:      	movq	%rax, 0x60(%rsp)
    8e52:      	movabsq	$0x7266206574656c70, %rax # imm = 0x7266206574656C70
    8e5c:      	movq	%rax, 0x58(%rsp)
    8e61:      	movabsq	$0x6d6f636e6920676e, %rax # imm = 0x6D6F636E6920676E
    8e6b:      	movq	%rax, 0x50(%rsp)
    8e70:      	movabsq	$0x69646e69776e7520, %rax # imm = 0x69646E69776E7520
    8e7a:      	movq	%rax, 0x48(%rsp)
    8e7f:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    8e89:      	movq	%rax, 0x40(%rsp)
    8e8e:      	leaq	0x40(%rsp), %rdi
    8e93:      	movl	$0x2d, %eax
    8e98:      	movl	$0x6, %ecx
    8e9d:      	movl	$0x2d, %esi
    8ea2:      	xorl	%eax, %eax
    8ea4:      	callq	*%rcx
    8ea6:      	jmp	0x9684 <perf_unwind_hotspot+0x9684>
    8eab:      	movq	0x100(%rsp), %rdx
    8eb3:      	movzbl	0x1d(%r15), %eax
    8eb8:      	movq	%rdx, %rcx
    8ebb:      	movq	%rdx, 0x120(%rsp)
    8ec3:      	addq	%rdx, %rax
    8ec6:      	xorl	%ebx, %ebx
    8ec8:      	cmpq	%rax, %r13
    8ecb:      	movl	$0x0, %ecx
    8ed0:      	cmovaeq	%rax, %rcx
    8ed4:      	subq	%rcx, %r13
    8ed7:      	movq	(%rip), %rax            # 0x8ede <perf_unwind_hotspot+0x8ede>
    8ede:      	cmpl	$0x0, (%rax)
    8ee1:      	je	0x8f85 <perf_unwind_hotspot+0x8f85>
    8ee7:      	movabsq	$0xa786c25203d20, %rax  # imm = 0xA786C25203D20
    8ef1:      	movq	%rax, 0x2d(%rsp)
    8ef6:      	movabsq	$0x203d20706362202c, %rax # imm = 0x203D20706362202C
    8f00:      	movq	%rax, 0x28(%rsp)
    8f05:      	movabsq	$0x786c257830203d20, %rax # imm = 0x786C257830203D20
    8f0f:      	movq	%rax, 0x20(%rsp)
    8f14:      	movabsq	$0x646f6874656d6320, %rax # imm = 0x646F6874656D6320
    8f1e:      	movq	%rax, 0x18(%rsp)
    8f23:      	movabsq	$0x2c786c257830203d, %rax # imm = 0x2C786C257830203D
    8f2d:      	movq	%rax, 0x10(%rsp)
    8f32:      	movabsq	$0x20646f6874656d20, %rax # imm = 0x20646F6874656D20
    8f3c:      	movq	%rax, 0x8(%rsp)
    8f41:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    8f4b:      	movq	%rax, (%rsp)
    8f4f:      	movq	%rsp, %rdi
    8f52:      	movl	$0x35, %eax
    8f57:      	movl	$0x6, %r9d
    8f5d:      	movq	0x100(%rsp), %rcx
    8f65:      	movl	$0x35, %esi
    8f6a:      	movq	%r12, %rdx
    8f6d:      	movq	%r13, %r8
    8f70:      	xorl	%eax, %eax
    8f72:      	callq	*%r9
    8f75:      	movq	0x100(%rsp), %rax
    8f7d:      	movq	%rax, 0x120(%rsp)
    8f85:      	cmpq	$0xffff, %r13           # imm = 0xFFFF
    8f8c:      	movl	$0xffff, %eax           # imm = 0xFFFF
    8f91:      	cmovbq	%r13, %rax
    8f95:      	movq	%rax, 0x118(%rsp)
    8f9d:      	shrq	$0x3, 0x120(%rsp)
    8fa6:      	movl	$0x6, %r13d
    8fac:      	movb	$0x2, %al
    8fae:      	movl	%eax, 0xb0(%rsp)
    8fb5:      	movq	%r12, 0xc0(%rsp)
    8fbd:      	jmp	0x966a <perf_unwind_hotspot+0x966a>
    8fc2:      	movq	(%rip), %rax            # 0x8fc9 <perf_unwind_hotspot+0x8fc9>
    8fc9:      	cmpl	$0x0, (%rax)
    8fcc:      	je	0x9044 <perf_unwind_hotspot+0x9044>
    8fce:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    8fd8:      	movq	%rax, 0x26(%rsp)
    8fdd:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    8fe7:      	movq	%rax, 0x20(%rsp)
    8fec:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    8ff6:      	movq	%rax, 0x18(%rsp)
    8ffb:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    9005:      	movq	%rax, 0x10(%rsp)
    900a:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    9014:      	movq	%rax, 0x8(%rsp)
    9019:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    9023:      	movq	%rax, (%rsp)
    9027:      	movq	%rsp, %rdi
    902a:      	movl	$0x2e, %eax
    902f:      	movl	$0x6, %ecx
    9034:      	movl	0x114(%rsp), %edx
    903b:      	movl	$0x2e, %esi
    9040:      	xorl	%eax, %eax
    9042:      	callq	*%rcx
    9044:      	movl	$0x3e9, %ebx            # imm = 0x3E9
    9049:      	xorl	%r13d, %r13d
    904c:      	movl	$0x65746e49, %eax       # imm = 0x65746E49
    9051:      	movq	%rax, 0x120(%rsp)
    9059:      	jmp	0x966a <perf_unwind_hotspot+0x966a>
    905e:      	movq	0x38(%rsp), %rax
    9063:      	leaq	(%rax,%rbx), %rdx
    9067:      	addq	$-0x8, %rdx
    906b:      	leaq	0x40(%rsp), %rdi
    9070:      	movl	$0x30, %eax
    9075:      	movl	$0x70, %ecx
    907a:      	movl	$0x30, %esi
    907f:      	callq	*%rcx
    9081:      	movq	(%rip), %rax            # 0x9088 <perf_unwind_hotspot+0x9088>
    9088:      	cmpl	$0x0, (%rax)
    908b:      	je	0x90ee <perf_unwind_hotspot+0x90ee>
    908d:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    9097:      	movq	%rax, 0x18(%rsp)
    909c:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    90a6:      	movq	%rax, 0x10(%rsp)
    90ab:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    90b5:      	movq	%rax, 0x8(%rsp)
    90ba:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    90c4:      	movq	%rax, (%rsp)
    90c8:      	movw	$0xa, 0x20(%rsp)
    90cf:      	movq	%rsp, %rdi
    90d2:      	movl	$0x22, %eax
    90d7:      	movl	$0x6, %r8d
    90dd:      	movq	0x40(%rsp), %rcx
    90e2:      	movl	$0x22, %esi
    90e7:      	xorl	%edx, %edx
    90e9:      	xorl	%eax, %eax
    90eb:      	callq	*%r8
    90ee:      	movl	(%r14), %eax
    90f1:      	movl	$0x60, (%rsp)
    90f8:      	movbel	%eax, 0x4(%rsp)
    90fe:      	addq	%rbx, 0x38(%rsp)
    9103:      	movq	0x40(%rsp), %rax
    9108:      	movbeq	%rax, 0x8(%rsp)
    910f:      	movabsq	$-0x100000000000000, %rbx # imm = 0xFF00000000000000
    9119:      	movabsq	$0x200000000000000, %r12 # imm = 0x200000000000000
    9123:      	movq	(%rip), %rdi            # 0x912a <perf_unwind_hotspot+0x912a>
    912a:      	movq	%rsp, %rsi
    912d:      	movl	$0x1, %eax
    9132:      	callq	*%rax
    9134:      	testq	%rax, %rax
    9137:      	je	0x9151 <perf_unwind_hotspot+0x9151>
    9139:      	movq	0x8(%rax), %rax
    913d:      	andq	%rbx, %rax
    9140:      	xorl	%edx, %edx
    9142:      	cmpq	%r12, %rax
    9145:      	jne	0x9151 <perf_unwind_hotspot+0x9151>
    9147:      	movq	0x38(%rsp), %r15
    914c:      	jmp	0x9516 <perf_unwind_hotspot+0x9516>
    9151:      	movq	(%rip), %rax            # 0x9158 <perf_unwind_hotspot+0x9158>
    9158:      	cmpl	$0x0, (%rax)
    915b:      	je	0x91c1 <perf_unwind_hotspot+0x91c1>
    915d:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    9167:      	movq	%rax, 0x18(%rsp)
    916c:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    9176:      	movq	%rax, 0x10(%rsp)
    917b:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    9185:      	movq	%rax, 0x8(%rsp)
    918a:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    9194:      	movq	%rax, (%rsp)
    9198:      	movw	$0xa, 0x20(%rsp)
    919f:      	movq	%rsp, %rdi
    91a2:      	movl	$0x22, %eax
    91a7:      	movl	$0x6, %r8d
    91ad:      	movq	0x48(%rsp), %rcx
    91b2:      	movl	$0x22, %esi
    91b7:      	movl	$0x1, %edx
    91bc:      	xorl	%eax, %eax
    91be:      	callq	*%r8
    91c1:      	movl	(%r14), %eax
    91c4:      	movl	$0x60, (%rsp)
    91cb:      	movbel	%eax, 0x4(%rsp)
    91d1:      	movq	0x48(%rsp), %rax
    91d6:      	movbeq	%rax, 0x8(%rsp)
    91dd:      	movq	(%rip), %rdi            # 0x91e4 <perf_unwind_hotspot+0x91e4>
    91e4:      	movq	%rsp, %rsi
    91e7:      	movl	$0x1, %eax
    91ec:      	callq	*%rax
    91ee:      	testq	%rax, %rax
    91f1:      	je	0x9212 <perf_unwind_hotspot+0x9212>
    91f3:      	movq	0x8(%rax), %rax
    91f7:      	andq	%rbx, %rax
    91fa:      	cmpq	%r12, %rax
    91fd:      	jne	0x9212 <perf_unwind_hotspot+0x9212>
    91ff:      	movq	0x38(%rsp), %r15
    9204:      	addq	$0x8, %r15
    9208:      	movl	$0x1, %edx
    920d:      	jmp	0x9516 <perf_unwind_hotspot+0x9516>
    9212:      	movq	(%rip), %rax            # 0x9219 <perf_unwind_hotspot+0x9219>
    9219:      	cmpl	$0x0, (%rax)
    921c:      	je	0x9282 <perf_unwind_hotspot+0x9282>
    921e:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    9228:      	movq	%rax, 0x18(%rsp)
    922d:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    9237:      	movq	%rax, 0x10(%rsp)
    923c:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    9246:      	movq	%rax, 0x8(%rsp)
    924b:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    9255:      	movq	%rax, (%rsp)
    9259:      	movw	$0xa, 0x20(%rsp)
    9260:      	movq	%rsp, %rdi
    9263:      	movl	$0x22, %eax
    9268:      	movl	$0x6, %r8d
    926e:      	movq	0x50(%rsp), %rcx
    9273:      	movl	$0x22, %esi
    9278:      	movl	$0x2, %edx
    927d:      	xorl	%eax, %eax
    927f:      	callq	*%r8
    9282:      	movl	(%r14), %eax
    9285:      	movl	$0x60, (%rsp)
    928c:      	movbel	%eax, 0x4(%rsp)
    9292:      	movq	0x50(%rsp), %rax
    9297:      	movbeq	%rax, 0x8(%rsp)
    929e:      	movq	(%rip), %rdi            # 0x92a5 <perf_unwind_hotspot+0x92a5>
    92a5:      	movq	%rsp, %rsi
    92a8:      	movl	$0x1, %eax
    92ad:      	callq	*%rax
    92af:      	testq	%rax, %rax
    92b2:      	je	0x92d3 <perf_unwind_hotspot+0x92d3>
    92b4:      	movq	0x8(%rax), %rax
    92b8:      	andq	%rbx, %rax
    92bb:      	cmpq	%r12, %rax
    92be:      	jne	0x92d3 <perf_unwind_hotspot+0x92d3>
    92c0:      	movq	0x38(%rsp), %r15
    92c5:      	addq	$0x10, %r15
    92c9:      	movl	$0x2, %edx
    92ce:      	jmp	0x9516 <perf_unwind_hotspot+0x9516>
    92d3:      	movq	(%rip), %rax            # 0x92da <perf_unwind_hotspot+0x92da>
    92da:      	cmpl	$0x0, (%rax)
    92dd:      	je	0x9343 <perf_unwind_hotspot+0x9343>
    92df:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    92e9:      	movq	%rax, 0x18(%rsp)
    92ee:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    92f8:      	movq	%rax, 0x10(%rsp)
    92fd:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    9307:      	movq	%rax, 0x8(%rsp)
    930c:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    9316:      	movq	%rax, (%rsp)
    931a:      	movw	$0xa, 0x20(%rsp)
    9321:      	movq	%rsp, %rdi
    9324:      	movl	$0x22, %eax
    9329:      	movl	$0x6, %r8d
    932f:      	movq	0x58(%rsp), %rcx
    9334:      	movl	$0x22, %esi
    9339:      	movl	$0x3, %edx
    933e:      	xorl	%eax, %eax
    9340:      	callq	*%r8
    9343:      	movl	(%r14), %eax
    9346:      	movl	$0x60, (%rsp)
    934d:      	movbel	%eax, 0x4(%rsp)
    9353:      	movq	0x58(%rsp), %rax
    9358:      	movbeq	%rax, 0x8(%rsp)
    935f:      	movq	(%rip), %rdi            # 0x9366 <perf_unwind_hotspot+0x9366>
    9366:      	movq	%rsp, %rsi
    9369:      	movl	$0x1, %eax
    936e:      	callq	*%rax
    9370:      	testq	%rax, %rax
    9373:      	je	0x9394 <perf_unwind_hotspot+0x9394>
    9375:      	movq	0x8(%rax), %rax
    9379:      	andq	%rbx, %rax
    937c:      	cmpq	%r12, %rax
    937f:      	jne	0x9394 <perf_unwind_hotspot+0x9394>
    9381:      	movq	0x38(%rsp), %r15
    9386:      	addq	$0x18, %r15
    938a:      	movl	$0x3, %edx
    938f:      	jmp	0x9516 <perf_unwind_hotspot+0x9516>
    9394:      	movq	(%rip), %rax            # 0x939b <perf_unwind_hotspot+0x939b>
    939b:      	cmpl	$0x0, (%rax)
    939e:      	je	0x9404 <perf_unwind_hotspot+0x9404>
    93a0:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    93aa:      	movq	%rax, 0x18(%rsp)
    93af:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    93b9:      	movq	%rax, 0x10(%rsp)
    93be:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    93c8:      	movq	%rax, 0x8(%rsp)
    93cd:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    93d7:      	movq	%rax, (%rsp)
    93db:      	movw	$0xa, 0x20(%rsp)
    93e2:      	movq	%rsp, %rdi
    93e5:      	movl	$0x22, %eax
    93ea:      	movl	$0x6, %r8d
    93f0:      	movq	0x60(%rsp), %rcx
    93f5:      	movl	$0x22, %esi
    93fa:      	movl	$0x4, %edx
    93ff:      	xorl	%eax, %eax
    9401:      	callq	*%r8
    9404:      	movl	(%r14), %eax
    9407:      	movl	$0x60, (%rsp)
    940e:      	movbel	%eax, 0x4(%rsp)
    9414:      	movq	0x60(%rsp), %rax
    9419:      	movbeq	%rax, 0x8(%rsp)
    9420:      	movq	(%rip), %rdi            # 0x9427 <perf_unwind_hotspot+0x9427>
    9427:      	movq	%rsp, %rsi
    942a:      	movl	$0x1, %eax
    942f:      	callq	*%rax
    9431:      	testq	%rax, %rax
    9434:      	je	0x9455 <perf_unwind_hotspot+0x9455>
    9436:      	movq	0x8(%rax), %rax
    943a:      	andq	%rbx, %rax
    943d:      	cmpq	%r12, %rax
    9440:      	jne	0x9455 <perf_unwind_hotspot+0x9455>
    9442:      	movq	0x38(%rsp), %r15
    9447:      	addq	$0x20, %r15
    944b:      	movl	$0x4, %edx
    9450:      	jmp	0x9516 <perf_unwind_hotspot+0x9516>
    9455:      	movq	(%rip), %rax            # 0x945c <perf_unwind_hotspot+0x945c>
    945c:      	cmpl	$0x0, (%rax)
    945f:      	je	0x94c5 <perf_unwind_hotspot+0x94c5>
    9461:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    946b:      	movq	%rax, 0x18(%rsp)
    9470:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    947a:      	movq	%rax, 0x10(%rsp)
    947f:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    9489:      	movq	%rax, 0x8(%rsp)
    948e:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    9498:      	movq	%rax, (%rsp)
    949c:      	movw	$0xa, 0x20(%rsp)
    94a3:      	movq	%rsp, %rdi
    94a6:      	movl	$0x22, %eax
    94ab:      	movl	$0x6, %r8d
    94b1:      	movq	0x68(%rsp), %rcx
    94b6:      	movl	$0x22, %esi
    94bb:      	movl	$0x5, %edx
    94c0:      	xorl	%eax, %eax
    94c2:      	callq	*%r8
    94c5:      	movl	(%r14), %eax
    94c8:      	movl	$0x60, (%rsp)
    94cf:      	movbel	%eax, 0x4(%rsp)
    94d5:      	movq	0x68(%rsp), %rax
    94da:      	movbeq	%rax, 0x8(%rsp)
    94e1:      	movq	(%rip), %rdi            # 0x94e8 <perf_unwind_hotspot+0x94e8>
    94e8:      	movq	%rsp, %rsi
    94eb:      	movl	$0x1, %eax
    94f0:      	callq	*%rax
    94f2:      	testq	%rax, %rax
    94f5:      	je	0x95a4 <perf_unwind_hotspot+0x95a4>
    94fb:      	andq	0x8(%rax), %rbx
    94ff:      	cmpq	%r12, %rbx
    9502:      	jne	0x95a4 <perf_unwind_hotspot+0x95a4>
    9508:      	movq	0x38(%rsp), %r15
    950d:      	addq	$0x28, %r15
    9511:      	movl	$0x5, %edx
    9516:      	xorl	%ebx, %ebx
    9518:      	movl	$0x5, %r13d
    951e:      	movq	(%rip), %rax            # 0x9525 <perf_unwind_hotspot+0x9525>
    9525:      	cmpl	$0x0, (%rax)
    9528:      	je	0x965c <perf_unwind_hotspot+0x965c>
    952e:      	movabsq	$0xa7364726f7720, %rax  # imm = 0xA7364726F7720
    9538:      	movq	%rax, 0x26(%rsp)
    953d:      	movabsq	$0x77206425202b2065, %rax # imm = 0x77206425202B2065
    9547:      	movq	%rax, 0x20(%rsp)
    954c:      	movabsq	$0x6d61726620657465, %rax # imm = 0x6D61726620657465
    9556:      	movq	%rax, 0x18(%rsp)
    955b:      	movabsq	$0x6c706d6f6320676e, %rax # imm = 0x6C706D6F6320676E
    9565:      	movq	%rax, 0x10(%rsp)
    956a:      	movabsq	$0x69646e69776e7520, %rax # imm = 0x69646E69776E7520
    9574:      	movq	%rax, 0x8(%rsp)
    9579:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    9583:      	movq	%rax, (%rsp)
    9587:      	movq	%rsp, %rdi
    958a:      	movl	$0x2e, %eax
    958f:      	movl	$0x6, %ecx
    9594:      	xorl	%ebx, %ebx
    9596:      	movl	$0x2e, %esi
    959b:      	xorl	%eax, %eax
    959d:      	callq	*%rcx
    959f:      	jmp	0x965c <perf_unwind_hotspot+0x965c>
    95a4:      	movl	$0x2e, 0x100(%rsp)
    95af:      	movq	(%rip), %rdi            # 0x95b6 <perf_unwind_hotspot+0x95b6>
    95b6:      	leaq	0x100(%rsp), %rsi
    95be:      	movl	$0x1, %eax
    95c3:      	callq	*%rax
    95c5:      	testq	%rax, %rax
    95c8:      	je	0x95d2 <perf_unwind_hotspot+0x95d2>
    95ca:      	incq	(%rax)
    95cd:      	jmp	0x9654 <perf_unwind_hotspot+0x9654>
    95d2:      	movq	(%rip), %rax            # 0x95d9 <perf_unwind_hotspot+0x95d9>
    95d9:      	cmpl	$0x0, (%rax)
    95dc:      	je	0x9654 <perf_unwind_hotspot+0x9654>
    95de:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    95e8:      	movq	%rax, 0x26(%rsp)
    95ed:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    95f7:      	movq	%rax, 0x20(%rsp)
    95fc:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    9606:      	movq	%rax, 0x18(%rsp)
    960b:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    9615:      	movq	%rax, 0x10(%rsp)
    961a:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    9624:      	movq	%rax, 0x8(%rsp)
    9629:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    9633:      	movq	%rax, (%rsp)
    9637:      	movq	%rsp, %rdi
    963a:      	movl	$0x2e, %eax
    963f:      	movl	$0x6, %ecx
    9644:      	movl	0x100(%rsp), %edx
    964b:      	movl	$0x2e, %esi
    9650:      	xorl	%eax, %eax
    9652:      	callq	*%rcx
    9654:      	movl	$0x3ea, %ebx            # imm = 0x3EA
    9659:      	xorl	%r13d, %r13d
    965c:      	movb	$0x3, %al
    965e:      	movl	%eax, 0xb0(%rsp)
    9665:      	movq	%r15, 0x38(%rsp)
    966a:      	testl	%ebx, %ebx
    966c:      	jne	0x347 <perf_unwind_hotspot+0x347>
    9672:      	cmpl	$0x2, %r13d
    9676:      	jle	0x968b <perf_unwind_hotspot+0x968b>
    9678:      	cmpl	$0x4, %r13d
    967c:      	jg	0x96b9 <perf_unwind_hotspot+0x96b9>
    967e:      	cmpl	$0x3, %r13d
    9682:      	jne	0x96c5 <perf_unwind_hotspot+0x96c5>
    9684:      	movq	0x38(%rsp), %rcx
    9689:      	jmp	0x96ce <perf_unwind_hotspot+0x96ce>
    968b:      	movl	$0x1, %ebx
    9690:      	testl	%r13d, %r13d
    9693:      	je	0x347 <perf_unwind_hotspot+0x347>
    9699:      	movq	0xa8(%rsp), %rcx
    96a1:      	cmpl	$0x1, %r13d
    96a5:      	jne	0x96ce <perf_unwind_hotspot+0x96ce>
    96a7:      	movl	$0x8, 0xf0(%rsp)
    96b2:      	movl	$0x8, %eax
    96b7:      	jmp	0x96e3 <perf_unwind_hotspot+0x96e3>
    96b9:      	cmpl	$0x5, %r13d
    96bd:      	jne	0x977b <perf_unwind_hotspot+0x977b>
    96c3:      	jmp	0x96ea <perf_unwind_hotspot+0x96ea>
    96c5:      	movl	0xf0(%rsp), %eax
    96cc:      	jmp	0x96e3 <perf_unwind_hotspot+0x96e3>
    96ce:      	movl	$0x10, 0xf0(%rsp)
    96d9:      	movl	$0x10, %eax
    96de:      	movq	%rcx, 0x38(%rsp)
    96e3:      	movl	%eax, %eax
    96e5:      	addq	%rax, 0x38(%rsp)
    96ea:      	movq	0x38(%rsp), %rax
    96ef:      	leaq	-0x10(%rax), %rdx
    96f3:      	movq	%rsp, %rdi
    96f6:      	movl	$0x10, %eax
    96fb:      	movl	$0x70, %ecx
    9700:      	movl	$0x10, %esi
    9705:      	callq	*%rcx
    9707:      	movq	0x8(%rsp), %rax
    970c:      	movq	%rax, 0xb8(%rsp)
    9714:      	cmpl	$0x10, 0xf0(%rsp)
    971c:      	jb	0x977b <perf_unwind_hotspot+0x977b>
    971e:      	movq	(%rip), %rax            # 0x9725 <perf_unwind_hotspot+0x9725>
    9725:      	cmpl	$0x0, (%rax)
    9728:      	je	0x976f <perf_unwind_hotspot+0x976f>
    972a:      	movabsq	$0xa706620726576, %rax  # imm = 0xA706620726576
    9734:      	movq	%rax, 0x4d(%rsp)
    9739:      	movabsq	$0x7265766f63657220, %rax # imm = 0x7265766F63657220
    9743:      	movq	%rax, 0x48(%rsp)
    9748:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    9752:      	movq	%rax, 0x40(%rsp)
    9757:      	leaq	0x40(%rsp), %rdi
    975c:      	movl	$0x15, %eax
    9761:      	movl	$0x6, %ecx
    9766:      	movl	$0x15, %esi
    976b:      	xorl	%eax, %eax
    976d:      	callq	*%rcx
    976f:      	movq	(%rsp), %rax
    9773:      	movq	%rax, 0xa8(%rsp)
    977b:      	movl	0x2c0(%r14), %eax
    9782:      	cmpq	$0x7e, %rax
    9786:      	ja	0xf03 <perf_unwind_hotspot+0xf03>
    978c:      	movzbl	0xf30(%r14), %ecx
    9794:      	movzbl	0xb0(%rsp), %edx
    979c:      	shlq	$0x3c, %rdx
    97a0:      	movq	0x118(%rsp), %rdi
    97a8:      	shlq	$0x20, %rdi
    97ac:      	movl	0x120(%rsp), %esi
    97b3:      	orq	%rdi, %rsi
    97b6:      	orq	%rdx, %rsi
    97b9:      	leal	0x1(%rax), %edx
    97bc:      	movl	%edx, 0x2c0(%r14)
    97c3:      	leaq	(%rax,%rax,2), %rax
    97c7:      	movq	0xc0(%rsp), %rdx
    97cf:      	movq	%rdx, 0x2d0(%r14,%rax,8)
    97d7:      	movq	%rsi, 0x2d8(%r14,%rax,8)
    97df:      	movb	$0x5, 0x2e0(%r14,%rax,8)
    97e8:      	movb	%cl, 0x2e1(%r14,%rax,8)
    97f0:      	movl	$0x0, 0x2e2(%r14,%rax,8)
    97fc:      	movw	$0x0, 0x2e6(%r14,%rax,8)
    9807:      	movq	(%rip), %rax            # 0x980e <perf_unwind_hotspot+0x980e>
    980e:      	cmpl	$0x0, (%rax)
    9811:      	je	0x9886 <perf_unwind_hotspot+0x9886>
    9813:      	movabsq	$0x25203a7066202c78, %rax # imm = 0x25203A7066202C78
    981d:      	movq	%rax, 0x58(%rsp)
    9822:      	movabsq	$0x6c25203a7073202c, %rax # imm = 0x6C25203A7073202C
    982c:      	movq	%rax, 0x50(%rsp)
    9831:      	movabsq	$0x786c25203a637020, %rax # imm = 0x786C25203A637020
    983b:      	movq	%rax, 0x48(%rsp)
    9840:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    984a:      	movq	%rax, 0x40(%rsp)
    984f:      	movl	$0xa786c, 0x60(%rsp)    # imm = 0xA786C
    9857:      	leaq	0x40(%rsp), %rdi
    985c:      	movl	$0x24, %eax
    9861:      	movl	$0x6, %r9d
    9867:      	movl	$0x24, %esi
    986c:      	movq	0xb8(%rsp), %rdx
    9874:      	movq	0x38(%rsp), %rcx
    9879:      	movq	0xa8(%rsp), %r8
    9881:      	xorl	%eax, %eax
    9883:      	callq	*%r9
    9886:      	movq	0xb8(%rsp), %rax
    988e:      	movq	%rax, 0xed0(%r14)
    9895:      	movq	0x38(%rsp), %rax
    989a:      	movq	%rax, 0xed8(%r14)
    98a1:      	movq	0xa8(%rsp), %rax
    98a9:      	movq	%rax, 0xee0(%r14)
    98b0:      	movb	$0x1, 0xf30(%r14)
    98b8:      	movl	$0x2a, (%rsp)
    98bf:      	movq	(%rip), %rdi            # 0x98c6 <perf_unwind_hotspot+0x98c6>
    98c6:      	movq	%rsp, %rsi
    98c9:      	movl	$0x1, %eax
    98ce:      	callq	*%rax
    98d0:      	testq	%rax, %rax
    98d3:      	je	0x98dd <perf_unwind_hotspot+0x98dd>
    98d5:      	incq	(%rax)
    98d8:      	jmp	0x9960 <perf_unwind_hotspot+0x9960>
    98dd:      	xorl	%eax, %eax
    98df:      	movq	(%rip), %rcx            # 0x98e6 <perf_unwind_hotspot+0x98e6>
    98e6:      	cmpl	$0x0, (%rcx)
    98e9:      	je	0x9969 <perf_unwind_hotspot+0x9969>
    98eb:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    98f5:      	movq	%rax, 0x66(%rsp)
    98fa:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    9904:      	movq	%rax, 0x60(%rsp)
    9909:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    9913:      	movq	%rax, 0x58(%rsp)
    9918:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    9922:      	movq	%rax, 0x50(%rsp)
    9927:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    9931:      	movq	%rax, 0x48(%rsp)
    9936:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    9940:      	movq	%rax, 0x40(%rsp)
    9945:      	leaq	0x40(%rsp), %rdi
    994a:      	movl	$0x2e, %eax
    994f:      	movl	$0x6, %ecx
    9954:      	movl	(%rsp), %edx
    9957:      	movl	$0x2e, %esi
    995c:      	xorl	%eax, %eax
    995e:      	callq	*%rcx
    9960:      	movq	(%rip), %rax            # 0x9967 <perf_unwind_hotspot+0x9967>
    9967:      	movl	(%rax), %eax
    9969:      	movq	0xed0(%r14), %rbx
    9970:      	testq	%rbx, %rbx
    9973:      	je	0x9ceb <perf_unwind_hotspot+0x9ceb>
    9979:      	testl	%eax, %eax
    997b:      	je	0x9a06 <perf_unwind_hotspot+0x9a06>
    9981:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    998b:      	movq	%rax, 0x68(%rsp)
    9990:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    999a:      	movq	%rax, 0x60(%rsp)
    999f:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    99a9:      	movq	%rax, 0x58(%rsp)
    99ae:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    99b8:      	movq	%rax, 0x50(%rsp)
    99bd:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    99c7:      	movq	%rax, 0x48(%rsp)
    99cc:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    99d6:      	movq	%rax, 0x40(%rsp)
    99db:      	movb	$0x0, 0x70(%rsp)
    99e0:      	leaq	0x40(%rsp), %rdi
    99e5:      	movl	$0x31, %eax
    99ea:      	movl	$0x6, %ecx
    99ef:      	movl	0x2c0(%r14), %edx
    99f6:      	movl	$0x31, %esi
    99fb:      	xorl	%eax, %eax
    99fd:      	callq	*%rcx
    99ff:      	movq	0xed0(%r14), %rbx
    9a06:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    9a10:      	cmpq	%rax, %rbx
    9a13:      	ja	0x1049 <perf_unwind_hotspot+0x1049>
    9a19:      	cmpq	$0x1000, %rbx           # imm = 0x1000
    9a20:      	jb	0x1fa2 <perf_unwind_hotspot+0x1fa2>
    9a26:      	movl	(%r14), %eax
    9a29:      	movl	$0x60, 0xc8(%rsp)
    9a34:      	movbel	%eax, 0xcc(%rsp)
    9a3d:      	movbeq	%rbx, 0xd0(%rsp)
    9a47:      	movq	(%rip), %rdi            # 0x9a4e <perf_unwind_hotspot+0x9a4e>
    9a4e:      	leaq	0xc8(%rsp), %rsi
    9a56:      	movl	$0x1, %eax
    9a5b:      	callq	*%rax
    9a5d:      	testq	%rax, %rax
    9a60:      	je	0x9d07 <perf_unwind_hotspot+0x9d07>
    9a66:      	movq	0x8(%rax), %r12
    9a6a:      	movabsq	$0xffffffffffffff, %rcx # imm = 0xFFFFFFFFFFFFFF
    9a74:      	andq	%r12, %rcx
    9a77:      	movq	%rcx, 0xf20(%r14)
    9a7e:      	movq	(%rax), %rax
    9a81:      	movq	%rax, 0xf10(%r14)
    9a88:      	shrq	$0x38, %r12
    9a8c:      	movq	%rbx, %rax
    9a8f:      	subq	%rcx, %rax
    9a92:      	movq	%rax, 0xf18(%r14)
    9a99:      	movq	(%rip), %rax            # 0x9aa0 <perf_unwind_hotspot+0x9aa0>
    9aa0:      	cmpl	$0x0, (%rax)
    9aa3:      	je	0x9bb5 <perf_unwind_hotspot+0x9bb5>
    9aa9:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    9ab3:      	movq	%rax, 0x68(%rsp)
    9ab8:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    9ac2:      	movq	%rax, 0x60(%rsp)
    9ac7:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    9ad1:      	movq	%rax, 0x58(%rsp)
    9ad6:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    9ae0:      	movq	%rax, 0x50(%rsp)
    9ae5:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    9aef:      	movq	%rax, 0x48(%rsp)
    9af4:      	movabsq	$0x6365732074786554, %r15 # imm = 0x6365732074786554
    9afe:      	movq	%r15, 0x40(%rsp)
    9b03:      	movw	$0xa, 0x70(%rsp)
    9b0a:      	leaq	0x40(%rsp), %rdi
    9b0f:      	movl	$0x32, %eax
    9b14:      	movl	$0x6, %r9d
    9b1a:      	movq	0xf10(%r14), %rcx
    9b21:      	movl	$0x32, %esi
    9b26:      	movq	%rbx, %rdx
    9b29:      	movl	%r12d, %r8d
    9b2c:      	xorl	%eax, %eax
    9b2e:      	callq	*%r9
    9b31:      	movq	(%rip), %rax            # 0x9b38 <perf_unwind_hotspot+0x9b38>
    9b38:      	cmpl	$0x0, (%rax)
    9b3b:      	je	0x9bb5 <perf_unwind_hotspot+0x9bb5>
    9b3d:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    9b47:      	movq	%rax, 0x67(%rsp)
    9b4c:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    9b56:      	movq	%rax, 0x60(%rsp)
    9b5b:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    9b65:      	movq	%rax, 0x58(%rsp)
    9b6a:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    9b74:      	movq	%rax, 0x50(%rsp)
    9b79:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    9b83:      	movq	%rax, 0x48(%rsp)
    9b88:      	movq	%r15, 0x40(%rsp)
    9b8d:      	leaq	0x40(%rsp), %rdi
    9b92:      	movl	$0x2f, %eax
    9b97:      	movl	$0x6, %r8d
    9b9d:      	movq	0xf18(%r14), %rcx
    9ba4:      	movq	0xf20(%r14), %rdx
    9bab:      	movl	$0x2f, %esi
    9bb0:      	xorl	%eax, %eax
    9bb2:      	callq	*%r8
    9bb5:      	cmpl	$0x1, %r12d
    9bb9:      	jne	0x34c <perf_unwind_hotspot+0x34c>
    9bbf:      	movq	0xf10(%r14), %rax
    9bc6:      	movq	%rax, 0xc8(%rsp)
    9bce:      	movq	0xf18(%r14), %r15
    9bd5:      	movq	(%rip), %rdi            # 0x9bdc <perf_unwind_hotspot+0x9bdc>
    9bdc:      	leaq	0xc8(%rsp), %rsi
    9be4:      	movl	$0x1, %eax
    9be9:      	callq	*%rax
    9beb:      	movl	$0x1, %r12d
    9bf1:      	testq	%rax, %rax
    9bf4:      	je	0x34c <perf_unwind_hotspot+0x34c>
    9bfa:      	movq	%rax, %rbx
    9bfd:      	cmpq	%r15, (%rax)
    9c00:      	ja	0x9c08 <perf_unwind_hotspot+0x9c08>
    9c02:      	cmpq	%r15, 0x8(%rbx)
    9c06:      	jae	0x9c1c <perf_unwind_hotspot+0x9c1c>
    9c08:      	cmpq	%r15, 0x10(%rbx)
    9c0c:      	ja	0x34c <perf_unwind_hotspot+0x34c>
    9c12:      	cmpq	%r15, 0x18(%rbx)
    9c16:      	jb	0x34c <perf_unwind_hotspot+0x34c>
    9c1c:      	movq	(%rip), %rax            # 0x9c23 <perf_unwind_hotspot+0x9c23>
    9c23:      	cmpl	$0x0, (%rax)
    9c26:      	movabsq	$0x6572707265746e69, %r15 # imm = 0x6572707265746E69
    9c30:      	je	0x9c80 <perf_unwind_hotspot+0x9c80>
    9c32:      	movabsq	$0xa642520686374, %rax  # imm = 0xA642520686374
    9c3c:      	movq	%rax, 0x56(%rsp)
    9c41:      	movabsq	$0x6374616d20737465, %rax # imm = 0x6374616D20737465
    9c4b:      	movq	%rax, 0x50(%rsp)
    9c50:      	movabsq	$0x7366666f5f726574, %rax # imm = 0x7366666F5F726574
    9c5a:      	movq	%rax, 0x48(%rsp)
    9c5f:      	movq	%r15, 0x40(%rsp)
    9c64:      	leaq	0x40(%rsp), %rdi
    9c69:      	movl	$0x1e, %eax
    9c6e:      	movl	$0x6, %ecx
    9c73:      	movzwl	0x20(%rbx), %edx
    9c77:      	movl	$0x1e, %esi
    9c7c:      	xorl	%eax, %eax
    9c7e:      	callq	*%rcx
    9c80:      	movl	0x1380(%r14), %eax
    9c87:      	movl	0x20(%rbx), %ecx
    9c8a:      	btl	%ecx, %eax
    9c8d:      	jae	0x9e39 <perf_unwind_hotspot+0x9e39>
    9c93:      	movq	(%rip), %rax            # 0x9c9a <perf_unwind_hotspot+0x9c9a>
    9c9a:      	cmpl	$0x0, (%rax)
    9c9d:      	je	0x34c <perf_unwind_hotspot+0x34c>
    9ca3:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    9cad:      	movq	%rax, 0x50(%rsp)
    9cb2:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    9cbc:      	movq	%rax, 0x48(%rsp)
    9cc1:      	movq	%r15, 0x40(%rsp)
    9cc6:      	movl	$0xa656e, 0x57(%rsp)    # imm = 0xA656E
    9cce:      	leaq	0x40(%rsp), %rdi
    9cd3:      	movl	$0x1b, %eax
    9cd8:      	movl	$0x6, %ecx
    9cdd:      	movl	$0x1b, %esi
    9ce2:      	xorl	%eax, %eax
    9ce4:      	callq	*%rcx
    9ce6:      	jmp	0x34c <perf_unwind_hotspot+0x34c>
    9ceb:      	testl	%eax, %eax
    9ced:      	jne	0x9d2f <perf_unwind_hotspot+0x9d2f>
    9cef:      	movl	$0x1, 0xf28(%r14)
    9cfa:      	movl	$0xfad, %ebp            # imm = 0xFAD
    9cff:      	xorl	%r12d, %r12d
    9d02:      	jmp	0x34c <perf_unwind_hotspot+0x34c>
    9d07:      	movq	(%rip), %rax            # 0x9d0e <perf_unwind_hotspot+0x9d0e>
    9d0e:      	cmpl	$0x0, (%rax)
    9d11:      	jne	0x9dab <perf_unwind_hotspot+0x9dab>
    9d17:      	movl	$0xc, 0xf28(%r14)
    9d22:      	movl	$0xfac, %ebp            # imm = 0xFAC
    9d27:      	xorl	%r12d, %r12d
    9d2a:      	jmp	0x34c <perf_unwind_hotspot+0x34c>
    9d2f:      	movabsq	$0xa2930203d3d2043, %rax # imm = 0xA2930203D3D2043
    9d39:      	movq	%rax, 0x68(%rsp)
    9d3e:      	movabsq	$0x5028206572756c69, %rax # imm = 0x5028206572756C69
    9d48:      	movq	%rax, 0x60(%rsp)
    9d4d:      	movabsq	$0x616620646e69776e, %rax # imm = 0x616620646E69776E
    9d57:      	movq	%rax, 0x58(%rsp)
    9d5c:      	movabsq	$0x75206f7420657564, %rax # imm = 0x75206F7420657564
    9d66:      	movq	%rax, 0x50(%rsp)
    9d6b:      	movabsq	$0x20646e69776e7520, %rax # imm = 0x20646E69776E7520
    9d75:      	movq	%rax, 0x48(%rsp)
    9d7a:      	movabsq	$0x676e6970706f7453, %rax # imm = 0x676E6970706F7453
    9d84:      	movq	%rax, 0x40(%rsp)
    9d89:      	movb	$0x0, 0x70(%rsp)
    9d8e:      	leaq	0x40(%rsp), %rdi
    9d93:      	movl	$0x31, %eax
    9d98:      	movl	$0x6, %ecx
    9d9d:      	movl	$0x31, %esi
    9da2:      	xorl	%eax, %eax
    9da4:      	callq	*%rcx
    9da6:      	jmp	0x9cef <perf_unwind_hotspot+0x9cef>
    9dab:      	movabsq	$0xa786c2578302043, %rax # imm = 0xA786C2578302043
    9db5:      	movq	%rax, 0x70(%rsp)
    9dba:      	movabsq	$0x5020726f6620676e, %rax # imm = 0x5020726F6620676E
    9dc4:      	movq	%rax, 0x68(%rsp)
    9dc9:      	movabsq	$0x697070616d207972, %rax # imm = 0x697070616D207972
    9dd3:      	movq	%rax, 0x60(%rsp)
    9dd8:      	movabsq	$0x6f6d656d206c6176, %rax # imm = 0x6F6D656D206C6176
    9de2:      	movq	%rax, 0x58(%rsp)
    9de7:      	movabsq	$0x7265746e69207075, %rax # imm = 0x7265746E69207075
    9df1:      	movq	%rax, 0x50(%rsp)
    9df6:      	movabsq	$0x206b6f6f6c206f74, %rax # imm = 0x206B6F6F6C206F74
    9e00:      	movq	%rax, 0x48(%rsp)
    9e05:      	movabsq	$0x206572756c696146, %rax # imm = 0x206572756C696146
    9e0f:      	movq	%rax, 0x40(%rsp)
    9e14:      	movb	$0x0, 0x78(%rsp)
    9e19:      	leaq	0x40(%rsp), %rdi
    9e1e:      	movl	$0x39, %eax
    9e23:      	movl	$0x6, %ecx
    9e28:      	movl	$0x39, %esi
    9e2d:      	movq	%rbx, %rdx
    9e30:      	xorl	%eax, %eax
    9e32:      	callq	*%rcx
    9e34:      	jmp	0x9d17 <perf_unwind_hotspot+0x9d17>
    9e39:      	movl	$0x0, (%rsp)
    9e40:      	movq	(%rip), %rdi            # 0x9e47 <perf_unwind_hotspot+0x9e47>
    9e47:      	movq	%rsp, %rsi
    9e4a:      	movl	$0x1, %eax
    9e4f:      	callq	*%rax
    9e51:      	testq	%rax, %rax
    9e54:      	je	0x9e63 <perf_unwind_hotspot+0x9e63>
    9e56:      	incq	(%rax)
    9e59:      	movzwl	0x20(%rbx), %r12d
    9e5e:      	jmp	0x34c <perf_unwind_hotspot+0x34c>
    9e63:      	movq	(%rip), %rax            # 0x9e6a <perf_unwind_hotspot+0x9e6a>
    9e6a:      	cmpl	$0x0, (%rax)
    9e6d:      	je	0x9ee4 <perf_unwind_hotspot+0x9ee4>
    9e6f:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    9e79:      	movq	%rax, 0x66(%rsp)
    9e7e:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    9e88:      	movq	%rax, 0x60(%rsp)
    9e8d:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    9e97:      	movq	%rax, 0x58(%rsp)
    9e9c:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    9ea6:      	movq	%rax, 0x50(%rsp)
    9eab:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    9eb5:      	movq	%rax, 0x48(%rsp)
    9eba:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    9ec4:      	movq	%rax, 0x40(%rsp)
    9ec9:      	leaq	0x40(%rsp), %rdi
    9ece:      	movl	$0x2e, %eax
    9ed3:      	movl	$0x6, %ecx
    9ed8:      	movl	(%rsp), %edx
    9edb:      	movl	$0x2e, %esi
    9ee0:      	xorl	%eax, %eax
    9ee2:      	callq	*%rcx
    9ee4:      	movzwl	0x20(%rbx), %r12d
    9ee9:      	jmp	0x34c <perf_unwind_hotspot+0x34c>

Disassembly of section kprobe/unwind_hotspot:

0000000000000000 <kprobe_unwind_hotspot>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x138, %rsp            # imm = 0x138
      11:      	movq	%rdi, %rbx
      14:      	movl	$0x0, 0x40(%rsp)
      1c:      	movq	(%rip), %rdi            # 0x23 <kprobe_unwind_hotspot+0x23>
      23:      	leaq	0x40(%rsp), %rsi
      28:      	movl	$0x1, %eax
      2d:      	callq	*%rax
      2f:      	testq	%rax, %rax
      32:      	je	0x4a4 <kprobe_unwind_hotspot+0x4a4>
      38:      	movq	%rax, %r14
      3b:      	movl	(%rax), %eax
      3d:      	movl	%eax, 0x134(%rsp)
      44:      	movq	(%rip), %r12            # 0x4b <kprobe_unwind_hotspot+0x4b>
      4b:      	cmpl	$0x0, (%r12)
      50:      	jne	0x6f1 <kprobe_unwind_hotspot+0x6f1>
      56:      	movq	(%rip), %rdi            # 0x5d <kprobe_unwind_hotspot+0x5d>
      5d:      	leaq	0x134(%rsp), %rsi
      65:      	movl	$0x1, %eax
      6a:      	callq	*%rax
      6c:      	testq	%rax, %rax
      6f:      	je	0x159 <kprobe_unwind_hotspot+0x159>
      75:      	movq	%rax, %r15
      78:      	movl	$0x29, 0xc8(%rsp)
      83:      	movq	(%rip), %rdi            # 0x8a <kprobe_unwind_hotspot+0x8a>
      8a:      	leaq	0xc8(%rsp), %rsi
      92:      	movl	$0x1, %eax
      97:      	callq	*%rax
      99:      	testq	%rax, %rax
      9c:      	movq	%rbx, 0x128(%rsp)
      a4:      	je	0x1d0 <kprobe_unwind_hotspot+0x1d0>
      aa:      	incq	(%rax)
      ad:      	cmpl	$0x0, (%r12)
      b2:      	movq	0xed0(%r14), %r12
      b9:      	movq	0xed8(%r14), %r13
      c0:      	movq	0xee0(%r14), %rax
      c7:      	movq	%rax, 0x38(%rsp)
      cc:      	je	0x1f5 <kprobe_unwind_hotspot+0x1f5>
      d2:      	movabsq	$0x252074657366666f, %rax # imm = 0x252074657366666F
      dc:      	movq	%rax, 0x60(%rsp)
      e1:      	movabsq	$0x202c786c25207472, %rax # imm = 0x202C786C25207472
      eb:      	movq	%rax, 0x58(%rsp)
      f0:      	movabsq	$0x6174732065646f63, %rax # imm = 0x6174732065646F63
      fa:      	movq	%rax, 0x50(%rsp)
      ff:      	movabsq	$0x206e6920786c2520, %rax # imm = 0x206E6920786C2520
     109:      	movq	%rax, 0x48(%rsp)
     10e:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
     118:      	movq	%rax, 0x40(%rsp)
     11d:      	movl	$0xa786c, 0x68(%rsp)    # imm = 0xA786C
     125:      	leaq	0x40(%rsp), %rdi
     12a:      	movl	$0x2c, %eax
     12f:      	movl	$0x6, %r9d
     135:      	movq	0xf20(%r14), %rcx
     13c:      	movq	0xed0(%r14), %rdx
     143:      	movq	0xf18(%r14), %r8
     14a:      	movl	$0x2c, %esi
     14f:      	xorl	%eax, %eax
     151:      	callq	*%r9
     154:      	jmp	0x1f5 <kprobe_unwind_hotspot+0x1f5>
     159:      	xorl	%eax, %eax
     15b:      	cmpl	$0x0, (%r12)
     160:      	je	0x4a9 <kprobe_unwind_hotspot+0x4a9>
     166:      	movabsq	$0xa646970207369, %rax  # imm = 0xA646970207369
     170:      	movq	%rax, 0x5e(%rsp)
     175:      	movabsq	$0x7369687420726f66, %rax # imm = 0x7369687420726F66
     17f:      	movq	%rax, 0x58(%rsp)
     184:      	movabsq	$0x206f666e49636f72, %rax # imm = 0x206F666E49636F72
     18e:      	movq	%rax, 0x50(%rsp)
     193:      	movabsq	$0x50746f7073746f48, %rax # imm = 0x50746F7073746F48
     19d:      	movq	%rax, 0x48(%rsp)
     1a2:      	movabsq	$0x206f6e203a6d766a, %rax # imm = 0x206F6E203A6D766A
     1ac:      	movq	%rax, 0x40(%rsp)
     1b1:      	leaq	0x40(%rsp), %rdi
     1b6:      	movl	$0x26, %eax
     1bb:      	movl	$0x6, %ecx
     1c0:      	movl	$0x26, %esi
     1c5:      	xorl	%eax, %eax
     1c7:      	callq	*%rcx
     1c9:      	xorl	%eax, %eax
     1cb:      	jmp	0x4a9 <kprobe_unwind_hotspot+0x4a9>
     1d0:      	cmpl	$0x0, (%r12)
     1d5:      	jne	0x9c7 <kprobe_unwind_hotspot+0x9c7>
     1db:      	movq	0xed0(%r14), %r12
     1e2:      	movq	0xed8(%r14), %r13
     1e9:      	movq	0xee0(%r14), %rax
     1f0:      	movq	%rax, 0x38(%rsp)
     1f5:      	movzbl	0x20(%r15), %eax
     1fa:      	shrxq	%rax, 0xf18(%r14), %rbx
     203:      	movb	$0x38, %al
     205:      	bzhiq	%rax, 0xf10(%r14), %rbp
     20e:      	leaq	(%rbx,%rbp), %rdx
     212:      	movq	%rsp, %rdi
     215:      	movl	$0x1, %eax
     21a:      	movl	$0x70, %ecx
     21f:      	movl	$0x1, %esi
     224:      	callq	*%rcx
     226:      	testq	%rax, %rax
     229:      	je	0x270 <kprobe_unwind_hotspot+0x270>
     22b:      	movq	$0x0, 0xc8(%rsp)
     237:      	movq	(%rip), %rbx            # 0x23e <kprobe_unwind_hotspot+0x23e>
     23e:      	cmpl	$0x0, (%rbx)
     241:      	jne	0x880 <kprobe_unwind_hotspot+0x880>
     247:      	movl	$0x2b, (%rsp)
     24e:      	movq	(%rip), %rdi            # 0x255 <kprobe_unwind_hotspot+0x255>
     255:      	movq	%rsp, %rsi
     258:      	movl	$0x1, %eax
     25d:      	callq	*%rax
     25f:      	testq	%rax, %rax
     262:      	je	0x339 <kprobe_unwind_hotspot+0x339>
     268:      	incq	(%rax)
     26b:      	jmp	0x342 <kprobe_unwind_hotspot+0x342>
     270:      	movq	(%rip), %rax            # 0x277 <kprobe_unwind_hotspot+0x277>
     277:      	cmpl	$0x0, (%rax)
     27a:      	jne	0xa45 <kprobe_unwind_hotspot+0xa45>
     280:      	movzbl	(%rsp), %eax
     284:      	leal	0x1(%rax), %ecx
     287:      	cmpb	$0x2, %cl
     28a:      	jae	0xab2 <kprobe_unwind_hotspot+0xab2>
     290:      	testb	%al, %al
     292:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
     294:      	movzbl	0x20(%r15), %eax
     299:      	shlxq	%rax, %rbx, %rax
     29e:      	addq	0xf20(%r14), %rax
     2a5:      	movzbl	0x1b(%r15), %ebx
     2aa:      	addq	%rax, %rbx
     2ad:      	movq	(%rip), %rax            # 0x2b4 <kprobe_unwind_hotspot+0x2b4>
     2b4:      	cmpl	$0x0, (%rax)
     2b7:      	jne	0x1270 <kprobe_unwind_hotspot+0x1270>
     2bd:      	movq	%rbx, 0xc8(%rsp)
     2c5:      	testq	%rbx, %rbx
     2c8:      	je	0x237 <kprobe_unwind_hotspot+0x237>
     2ce:      	movq	%r14, %rdx
     2d1:      	addq	$0xf80, %rdx            # imm = 0xF80
     2d8:      	movl	$0x200, %eax            # imm = 0x200
     2dd:      	movl	$0x70, %ecx
     2e2:      	movq	%rdx, %rbx
     2e5:      	movq	0xc8(%rsp), %rdx
     2ed:      	movq	%rbx, %rdi
     2f0:      	movl	$0x200, %esi            # imm = 0x200
     2f5:      	callq	*%rcx
     2f7:      	testq	%rax, %rax
     2fa:      	je	0x4bb <kprobe_unwind_hotspot+0x4bb>
     300:      	movq	(%rip), %rbx            # 0x307 <kprobe_unwind_hotspot+0x307>
     307:      	cmpl	$0x0, (%rbx)
     30a:      	jne	0x14ef <kprobe_unwind_hotspot+0x14ef>
     310:      	movl	$0x2c, (%rsp)
     317:      	movq	(%rip), %rdi            # 0x31e <kprobe_unwind_hotspot+0x31e>
     31e:      	movq	%rsp, %rsi
     321:      	movl	$0x1, %eax
     326:      	callq	*%rax
     328:      	testq	%rax, %rax
     32b:      	je	0x6de <kprobe_unwind_hotspot+0x6de>
     331:      	incq	(%rax)
     334:      	jmp	0x6e7 <kprobe_unwind_hotspot+0x6e7>
     339:      	cmpl	$0x0, (%rbx)
     33c:      	jne	0xdc6 <kprobe_unwind_hotspot+0xdc6>
     342:      	movl	$0x3e8, %ebx            # imm = 0x3E8
     347:      	xorl	%r12d, %r12d
     34a:      	movl	%ebx, %ebp
     34c:      	movq	0x128(%rsp), %r15
     354:      	movl	%ebp, 0xf2c(%r14)
     35b:      	movl	$0x0, 0x40(%rsp)
     363:      	movq	(%rip), %rdi            # 0x36a <kprobe_unwind_hotspot+0x36a>
     36a:      	leaq	0x40(%rsp), %rsi
     36f:      	movl	$0x1, %eax
     374:      	callq	*%rax
     376:      	testq	%rax, %rax
     379:      	je	0x3c9 <kprobe_unwind_hotspot+0x3c9>
     37b:      	movzbl	0x1384(%rax), %ecx
     382:      	movl	%r12d, %edx
     385:      	cmpb	$0x1d, %cl
     388:      	movq	(%rip), %r14            # 0x38f <kprobe_unwind_hotspot+0x38f>
     38f:      	jb	0x3f6 <kprobe_unwind_hotspot+0x3f6>
     391:      	movq	%rax, %rbx
     394:      	movl	$0x5, 0xf2c(%rax)
     39e:      	movl	$0x44, 0xc8(%rsp)
     3a9:      	movq	(%rip), %rdi            # 0x3b0 <kprobe_unwind_hotspot+0x3b0>
     3b0:      	leaq	0xc8(%rsp), %rsi
     3b8:      	movl	$0x1, %eax
     3bd:      	callq	*%rax
     3bf:      	testq	%rax, %rax
     3c2:      	je	0x3e0 <kprobe_unwind_hotspot+0x3e0>
     3c4:      	incq	(%rax)
     3c7:      	jmp	0x3ea <kprobe_unwind_hotspot+0x3ea>
     3c9:      	movq	(%rip), %rcx            # 0x3d0 <kprobe_unwind_hotspot+0x3d0>
     3d0:      	xorl	%edx, %edx
     3d2:      	movl	$0xc, %eax
     3d7:      	movq	(%rip), %r14            # 0x3de <kprobe_unwind_hotspot+0x3de>
     3de:      	jmp	0x40c <kprobe_unwind_hotspot+0x40c>
     3e0:      	cmpl	$0x0, (%r14)
     3e4:      	jne	0x11f2 <kprobe_unwind_hotspot+0x11f2>
     3ea:      	movq	%rbx, %rax
     3ed:      	movzbl	0x1384(%rbx), %ecx
     3f4:      	xorl	%edx, %edx
     3f6:      	incb	%cl
     3f8:      	movb	%cl, 0x1384(%rax)
     3fe:      	movl	%edx, %ecx
     400:      	movq	(%rip), %rsi            # 0x407 <kprobe_unwind_hotspot+0x407>
     407:      	movl	$0xc, %eax
     40c:      	movq	(%rip), %rsi            # 0x413 <kprobe_unwind_hotspot+0x413>
     413:      	movq	%r15, %rdi
     416:      	callq	*%rax
     418:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
     41d:      	cmpl	$0x0, (%r14)
     421:      	je	0x4a9 <kprobe_unwind_hotspot+0x4a9>
     427:      	movabsq	$0x6c69616620296425, %rax # imm = 0x6C69616620296425
     431:      	movq	%rax, 0x68(%rsp)
     436:      	movabsq	$0x28207265646e6977, %rax # imm = 0x28207265646E6977
     440:      	movq	%rax, 0x60(%rsp)
     445:      	movabsq	$0x6e7520656d617266, %rax # imm = 0x6E7520656D617266
     44f:      	movq	%rax, 0x58(%rsp)
     454:      	movabsq	$0x207478656e20726f, %rax # imm = 0x207478656E20726F
     45e:      	movq	%rax, 0x50(%rsp)
     463:      	movabsq	$0x66206c6c6163206c, %rax # imm = 0x66206C6C6163206C
     46d:      	movq	%rax, 0x48(%rsp)
     472:      	movabsq	$0x696174203a6d766a, %rax # imm = 0x696174203A6D766A
     47c:      	movq	%rax, 0x40(%rsp)
     481:      	movl	$0xa6465, 0x70(%rsp)    # imm = 0xA6465
     489:      	leaq	0x40(%rsp), %rdi
     48e:      	movl	$0x34, %eax
     493:      	movl	$0x6, %ecx
     498:      	movl	$0x34, %esi
     49d:      	movl	%r12d, %edx
     4a0:      	xorl	%eax, %eax
     4a2:      	callq	*%rcx
     4a4:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
     4a9:      	addq	$0x138, %rsp            # imm = 0x138
     4b0:      	popq	%rbx
     4b1:      	popq	%r12
     4b3:      	popq	%r13
     4b5:      	popq	%r14
     4b7:      	popq	%r15
     4b9:      	popq	%rbp
     4ba:      	retq
     4bb:      	movq	%rbx, 0x120(%rsp)
     4c3:      	movzwl	0x10(%r15), %eax
     4c8:      	movl	$0x1, %ebx
     4cd:      	cmpq	$0x1f8, %rax            # imm = 0x1F8
     4d3:      	ja	0x347 <kprobe_unwind_hotspot+0x347>
     4d9:      	movzwl	0x12(%r15), %ecx
     4de:      	cmpq	$0x1fc, %rcx            # imm = 0x1FC
     4e5:      	ja	0x347 <kprobe_unwind_hotspot+0x347>
     4eb:      	movzwl	0x14(%r15), %edx
     4f0:      	cmpq	$0x1f8, %rdx            # imm = 0x1F8
     4f7:      	ja	0x347 <kprobe_unwind_hotspot+0x347>
     4fd:      	movzbl	0x17(%r15), %esi
     502:      	movq	0x120(%rsp), %r8
     50a:      	movq	(%r8,%rsi), %rsi
     50e:      	movq	%rsi, 0xd0(%rsp)
     516:      	movzbl	0x18(%r15), %esi
     51b:      	movq	(%r8,%rsi), %rsi
     51f:      	movq	%rsi, 0xd8(%rsp)
     527:      	movzbl	0x1a(%r15), %esi
     52c:      	movl	(%r8,%rsi), %esi
     530:      	shll	$0x3, %esi
     533:      	movl	%esi, 0xf0(%rsp)
     53a:      	movzbl	0x19(%r15), %esi
     53f:      	movzwl	(%r8,%rsi), %esi
     544:      	movw	%si, 0xf8(%rsp)
     54c:      	movl	(%r8,%rcx), %ecx
     550:      	movl	%ecx, 0xf4(%rsp)
     557:      	movl	(%r8,%rdx), %ecx
     55b:      	movl	%ecx, 0xec(%rsp)
     562:      	movq	(%r8,%rax), %rax
     566:      	movq	%rax, 0xe0(%rsp)
     56e:      	leaq	0xe8(%rsp), %rdi
     576:      	movzbl	0x16(%r15), %eax
     57b:      	movq	(%r8,%rax), %rdx
     57f:      	movl	$0x4, %eax
     584:      	movl	$0x70, %ecx
     589:      	movl	$0x4, %esi
     58e:      	callq	*%rcx
     590:      	testq	%rax, %rax
     593:      	jne	0x300 <kprobe_unwind_hotspot+0x300>
     599:      	cmpb	$0x0, 0x21(%r15)
     59e:      	je	0x5cc <kprobe_unwind_hotspot+0x5cc>
     5a0:      	movq	0xc8(%rsp), %rax
     5a8:      	movl	0xd0(%rsp), %ecx
     5af:      	addq	%rax, %rcx
     5b2:      	movq	%rcx, 0xd0(%rsp)
     5ba:      	movl	0xd8(%rsp), %ecx
     5c1:      	addq	%rax, %rcx
     5c4:      	movq	%rcx, 0xd8(%rsp)
     5cc:      	movq	(%rip), %rax            # 0x5d3 <kprobe_unwind_hotspot+0x5d3>
     5d3:      	cmpl	$0x0, (%rax)
     5d6:      	jne	0x1c74 <kprobe_unwind_hotspot+0x1c74>
     5dc:      	movq	0xc8(%rsp), %rsi
     5e4:      	movq	0xd0(%rsp), %rax
     5ec:      	movl	0xe8(%rsp), %ebp
     5f3:      	movl	%r12d, %ebx
     5f6:      	subl	%eax, %ebx
     5f8:      	cmpl	$0x6974616d, %ebp       # imm = 0x6974616D
     5fe:      	movq	%rsi, 0xb8(%rsp)
     606:      	jg	0x749 <kprobe_unwind_hotspot+0x749>
     60c:      	cmpl	$0x62617476, %ebp       # imm = 0x62617476
     612:      	je	0x984 <kprobe_unwind_hotspot+0x984>
     618:      	cmpl	$0x65746e49, %ebp       # imm = 0x65746E49
     61e:      	jne	0x8de <kprobe_unwind_hotspot+0x8de>
     624:      	movq	%rbx, 0xa8(%rsp)
     62c:      	movq	0x38(%rsp), %rcx
     631:      	cmpq	%r13, %rcx
     634:      	jb	0xe40 <kprobe_unwind_hotspot+0xe40>
     63a:      	leaq	0x1000(%r13), %rax
     641:      	cmpq	%rax, %rcx
     644:      	jae	0xe40 <kprobe_unwind_hotspot+0xe40>
     64a:      	leaq	-0x50(%rcx), %rdx
     64e:      	leaq	0x40(%rsp), %rdi
     653:      	movl	$0x60, %eax
     658:      	movl	$0x70, %ecx
     65d:      	movl	$0x60, %esi
     662:      	callq	*%rcx
     664:      	testq	%rax, %rax
     667:      	je	0x1350 <kprobe_unwind_hotspot+0x1350>
     66d:      	movq	(%rip), %rax            # 0x674 <kprobe_unwind_hotspot+0x674>
     674:      	cmpl	$0x0, (%rax)
     677:      	je	0xe50 <kprobe_unwind_hotspot+0xe50>
     67d:      	movabsq	$0xa656d61726620, %rax  # imm = 0xA656D61726620
     687:      	movq	%rax, 0x1f(%rsp)
     68c:      	movabsq	$0x2072657465727072, %rax # imm = 0x2072657465727072
     696:      	movq	%rax, 0x18(%rsp)
     69b:      	movabsq	$0x65746e6920646165, %rax # imm = 0x65746E6920646165
     6a5:      	movq	%rax, 0x10(%rsp)
     6aa:      	movabsq	$0x72206f742064656c, %rax # imm = 0x72206F742064656C
     6b4:      	movq	%rax, 0x8(%rsp)
     6b9:      	movabsq	$0x696166203a6d766a, %rax # imm = 0x696166203A6D766A
     6c3:      	movq	%rax, (%rsp)
     6c7:      	movq	%rsp, %rdi
     6ca:      	movl	$0x27, %eax
     6cf:      	movl	$0x6, %ecx
     6d4:      	movl	$0x27, %esi
     6d9:      	jmp	0x2425 <kprobe_unwind_hotspot+0x2425>
     6de:      	cmpl	$0x0, (%rbx)
     6e1:      	jne	0x1917 <kprobe_unwind_hotspot+0x1917>
     6e7:      	movl	$0x3eb, %ebx            # imm = 0x3EB
     6ec:      	jmp	0x347 <kprobe_unwind_hotspot+0x347>
     6f1:      	movabsq	$0x3d3d3d3d20642520, %rax # imm = 0x3D3D3D3D20642520
     6fb:      	movq	%rax, 0x50(%rsp)
     700:      	movabsq	$0x646e69776e75203a, %rax # imm = 0x646E69776E75203A
     70a:      	movq	%rax, 0x48(%rsp)
     70f:      	movabsq	$0x6d766a203d3d3d3d, %rax # imm = 0x6D766A203D3D3D3D
     719:      	movq	%rax, 0x40(%rsp)
     71e:      	movw	$0xa, 0x58(%rsp)
     725:      	leaq	0x40(%rsp), %rdi
     72a:      	movl	$0x1a, %eax
     72f:      	movl	$0x6, %ecx
     734:      	movl	0x2c0(%r14), %edx
     73b:      	movl	$0x1a, %esi
     740:      	xorl	%eax, %eax
     742:      	callq	*%rcx
     744:      	jmp	0x56 <kprobe_unwind_hotspot+0x56>
     749:      	cmpl	$0x74656d6e, %ebp       # imm = 0x74656D6E
     74f:      	je	0x75d <kprobe_unwind_hotspot+0x75d>
     751:      	cmpl	$0x6974616e, %ebp       # imm = 0x6974616E
     757:      	jne	0x8de <kprobe_unwind_hotspot+0x8de>
     75d:      	movq	%rbx, 0xa8(%rsp)
     765:      	movzbl	0xf30(%r14), %ebx
     76d:      	movl	0xf4(%rsp), %ebp
     774:      	movq	0xe0(%rsp), %rcx
     77c:      	movl	%ecx, %edx
     77e:      	addq	%rsi, %rdx
     781:      	cmpb	$0x0, 0x21(%r15)
     786:      	cmoveq	%rcx, %rdx
     78a:      	cmpq	%rdx, %r12
     78d:      	jne	0x7da <kprobe_unwind_hotspot+0x7da>
     78f:      	movl	0xec(%rsp), %eax
     796:      	addq	%r13, %rax
     799:      	movq	%rsp, %rdi
     79c:      	movl	$0x8, %ecx
     7a1:      	movl	$0x70, %r8d
     7a7:      	movl	0xec(%rsp), %edx
     7ae:      	addq	%r13, %rdx
     7b1:      	movl	$0x8, %esi
     7b6:      	callq	*%r8
     7b9:      	testq	%rax, %rax
     7bc:      	je	0x1170 <kprobe_unwind_hotspot+0x1170>
     7c2:      	movq	(%rip), %rax            # 0x7c9 <kprobe_unwind_hotspot+0x7c9>
     7c9:      	cmpl	$0x0, (%rax)
     7cc:      	jne	0x21e7 <kprobe_unwind_hotspot+0x21e7>
     7d2:      	movq	0xd0(%rsp), %rax
     7da:      	movzwl	0xf8(%rsp), %ecx
     7e2:      	addq	%rax, %rcx
     7e5:      	cmpq	%rcx, %r12
     7e8:      	jae	0x912 <kprobe_unwind_hotspot+0x912>
     7ee:      	addq	$-0x4, %rcx
     7f2:      	movq	(%rip), %rax            # 0x7f9 <kprobe_unwind_hotspot+0x7f9>
     7f9:      	movl	(%rax), %eax
     7fb:      	cmpq	%rcx, %r12
     7fe:      	jae	0xe82 <kprobe_unwind_hotspot+0xe82>
     804:      	movb	$0x3, %cl
     806:      	movl	%ecx, 0xb0(%rsp)
     80d:      	testl	%eax, %eax
     80f:      	je	0x9aa <kprobe_unwind_hotspot+0x9aa>
     815:      	movabsq	$0x2963702820656d61, %rax # imm = 0x2963702820656D61
     81f:      	movq	%rax, 0x60(%rsp)
     824:      	movabsq	$0x7266206574656c70, %rax # imm = 0x7266206574656C70
     82e:      	movq	%rax, 0x58(%rsp)
     833:      	movabsq	$0x6d6f636e6920676e, %rax # imm = 0x6D6F636E6920676E
     83d:      	movq	%rax, 0x50(%rsp)
     842:      	movabsq	$0x69646e69776e7520, %rax # imm = 0x69646E69776E7520
     84c:      	movq	%rax, 0x48(%rsp)
     851:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
     85b:      	movq	%rax, 0x40(%rsp)
     860:      	movw	$0xa, 0x68(%rsp)
     867:      	leaq	0x40(%rsp), %rdi
     86c:      	movl	$0x2a, %eax
     871:      	movl	$0x6, %ecx
     876:      	movl	$0x2a, %esi
     87b:      	jmp	0x21de <kprobe_unwind_hotspot+0x21de>
     880:      	movabsq	$0xa637020726f6620, %rax # imm = 0xA637020726F6620
     88a:      	movq	%rax, 0x58(%rsp)
     88f:      	movabsq	$0x6465686374616d20, %rax # imm = 0x6465686374616D20
     899:      	movq	%rax, 0x50(%rsp)
     89e:      	movabsq	$0x626f6c6265646f63, %rax # imm = 0x626F6C6265646F63
     8a8:      	movq	%rax, 0x48(%rsp)
     8ad:      	movabsq	$0x206f6e203a6d766a, %rax # imm = 0x206F6E203A6D766A
     8b7:      	movq	%rax, 0x40(%rsp)
     8bc:      	movb	$0x0, 0x60(%rsp)
     8c1:      	leaq	0x40(%rsp), %rdi
     8c6:      	movl	$0x21, %eax
     8cb:      	movl	$0x6, %ecx
     8d0:      	movl	$0x21, %esi
     8d5:      	xorl	%eax, %eax
     8d7:      	callq	*%rcx
     8d9:      	jmp	0x247 <kprobe_unwind_hotspot+0x247>
     8de:      	movq	(%rip), %rax            # 0x8e5 <kprobe_unwind_hotspot+0x8e5>
     8e5:      	cmpl	$0x0, (%rax)
     8e8:      	jne	0x213c <kprobe_unwind_hotspot+0x213c>
     8ee:      	movl	0xf0(%rsp), %eax
     8f5:      	movl	$0x0, 0xb0(%rsp)
     900:      	movq	0x38(%rsp), %rcx
     905:      	testl	%eax, %eax
     907:      	jne	0xeb1 <kprobe_unwind_hotspot+0xeb1>
     90d:      	jmp	0xe9e <kprobe_unwind_hotspot+0xe9e>
     912:      	testb	%bl, %bl
     914:      	jne	0x938 <kprobe_unwind_hotspot+0x938>
     916:      	leaq	-0x1(%r12), %rdx
     91b:      	movq	%rsp, %rdi
     91e:      	movl	$0xe, %eax
     923:      	movl	$0x70, %ecx
     928:      	movl	$0xe, %esi
     92d:      	callq	*%rcx
     92f:      	testq	%rax, %rax
     932:      	je	0x144b <kprobe_unwind_hotspot+0x144b>
     938:      	movq	0x38(%rsp), %rax
     93d:      	movq	%rax, %rdx
     940:      	movl	0xf0(%rsp), %ebx
     947:      	leaq	(%rbx,%r13), %rcx
     94b:      	addq	$0x30, %rcx
     94f:      	subq	%r13, %rdx
     952:      	jb	0x1071 <kprobe_unwind_hotspot+0x1071>
     958:      	cmpq	%rcx, %rax
     95b:      	jae	0x1071 <kprobe_unwind_hotspot+0x1071>
     961:      	movb	$0x3, %al
     963:      	movl	%eax, 0xb0(%rsp)
     96a:      	movq	(%rip), %rax            # 0x971 <kprobe_unwind_hotspot+0x971>
     971:      	cmpl	$0x0, (%rax)
     974:      	jne	0x257d <kprobe_unwind_hotspot+0x257d>
     97a:      	movq	0x38(%rsp), %rcx
     97f:      	jmp	0xe96 <kprobe_unwind_hotspot+0xe96>
     984:      	movq	%rbx, 0xa8(%rsp)
     98c:      	movb	$0x1, %al
     98e:      	movl	%eax, 0xb0(%rsp)
     995:      	movl	$0x62617476, %ebp       # imm = 0x62617476
     99a:      	movq	(%rip), %rax            # 0x9a1 <kprobe_unwind_hotspot+0x9a1>
     9a1:      	cmpl	$0x0, (%rax)
     9a4:      	jne	0x219d <kprobe_unwind_hotspot+0x219d>
     9aa:      	movl	$0x8, 0xf0(%rsp)
     9b5:      	movl	$0x8, %eax
     9ba:      	movq	0xa8(%rsp), %rbx
     9c2:      	jmp	0xeb1 <kprobe_unwind_hotspot+0xeb1>
     9c7:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     9d1:      	movq	%rax, 0x66(%rsp)
     9d6:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     9e0:      	movq	%rax, 0x60(%rsp)
     9e5:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     9ef:      	movq	%rax, 0x58(%rsp)
     9f4:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     9fe:      	movq	%rax, 0x50(%rsp)
     a03:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     a0d:      	movq	%rax, 0x48(%rsp)
     a12:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     a1c:      	movq	%rax, 0x40(%rsp)
     a21:      	leaq	0x40(%rsp), %rdi
     a26:      	movl	$0x2e, %eax
     a2b:      	movl	$0x6, %ecx
     a30:      	movl	0xc8(%rsp), %edx
     a37:      	movl	$0x2e, %esi
     a3c:      	xorl	%eax, %eax
     a3e:      	callq	*%rcx
     a40:      	jmp	0xad <kprobe_unwind_hotspot+0xad>
     a45:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
     a4f:      	movq	%rax, 0x55(%rsp)
     a54:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
     a5e:      	movq	%rax, 0x50(%rsp)
     a63:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
     a6d:      	movq	%rax, 0x48(%rsp)
     a72:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
     a7c:      	movq	%rax, 0x40(%rsp)
     a81:      	leaq	0x40(%rsp), %rdi
     a86:      	movl	$0x1d, %eax
     a8b:      	movl	$0x6, %r8d
     a91:      	movzbl	(%rsp), %ecx
     a95:      	movl	$0x1d, %esi
     a9a:      	movq	%rbx, %rdx
     a9d:      	xorl	%eax, %eax
     a9f:      	callq	*%r8
     aa2:      	movzbl	(%rsp), %eax
     aa6:      	leal	0x1(%rax), %ecx
     aa9:      	cmpb	$0x2, %cl
     aac:      	jb	0x290 <kprobe_unwind_hotspot+0x290>
     ab2:      	movzbl	%al, %eax
     ab5:      	subq	%rax, %rbx
     ab8:      	leaq	(%rbx,%rbp), %rdx
     abc:      	movq	%rsp, %rdi
     abf:      	movl	$0x1, %eax
     ac4:      	movl	$0x70, %ecx
     ac9:      	movl	$0x1, %esi
     ace:      	callq	*%rcx
     ad0:      	testq	%rax, %rax
     ad3:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
     ad9:      	movq	(%rip), %rax            # 0xae0 <kprobe_unwind_hotspot+0xae0>
     ae0:      	cmpl	$0x0, (%rax)
     ae3:      	jne	0x1373 <kprobe_unwind_hotspot+0x1373>
     ae9:      	movzbl	(%rsp), %eax
     aed:      	leal	0x1(%rax), %ecx
     af0:      	cmpb	$0x2, %cl
     af3:      	jb	0x290 <kprobe_unwind_hotspot+0x290>
     af9:      	movzbl	%al, %eax
     afc:      	subq	%rax, %rbx
     aff:      	leaq	(%rbx,%rbp), %rdx
     b03:      	movq	%rsp, %rdi
     b06:      	movl	$0x1, %eax
     b0b:      	movl	$0x70, %ecx
     b10:      	movl	$0x1, %esi
     b15:      	callq	*%rcx
     b17:      	testq	%rax, %rax
     b1a:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
     b20:      	movq	(%rip), %rax            # 0xb27 <kprobe_unwind_hotspot+0xb27>
     b27:      	cmpl	$0x0, (%rax)
     b2a:      	jne	0x1991 <kprobe_unwind_hotspot+0x1991>
     b30:      	movzbl	(%rsp), %eax
     b34:      	leal	0x1(%rax), %ecx
     b37:      	cmpb	$0x2, %cl
     b3a:      	jb	0x290 <kprobe_unwind_hotspot+0x290>
     b40:      	movzbl	%al, %eax
     b43:      	subq	%rax, %rbx
     b46:      	leaq	(%rbx,%rbp), %rdx
     b4a:      	movq	%rsp, %rdi
     b4d:      	movl	$0x1, %eax
     b52:      	movl	$0x70, %ecx
     b57:      	movl	$0x1, %esi
     b5c:      	callq	*%rcx
     b5e:      	testq	%rax, %rax
     b61:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
     b67:      	movq	(%rip), %rax            # 0xb6e <kprobe_unwind_hotspot+0xb6e>
     b6e:      	cmpl	$0x0, (%rax)
     b71:      	jne	0x1b83 <kprobe_unwind_hotspot+0x1b83>
     b77:      	movzbl	(%rsp), %eax
     b7b:      	leal	0x1(%rax), %ecx
     b7e:      	cmpb	$0x2, %cl
     b81:      	jb	0x290 <kprobe_unwind_hotspot+0x290>
     b87:      	movzbl	%al, %eax
     b8a:      	subq	%rax, %rbx
     b8d:      	leaq	(%rbx,%rbp), %rdx
     b91:      	movq	%rsp, %rdi
     b94:      	movl	$0x1, %eax
     b99:      	movl	$0x70, %ecx
     b9e:      	movl	$0x1, %esi
     ba3:      	callq	*%rcx
     ba5:      	testq	%rax, %rax
     ba8:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
     bae:      	movq	(%rip), %rax            # 0xbb5 <kprobe_unwind_hotspot+0xbb5>
     bb5:      	cmpl	$0x0, (%rax)
     bb8:      	jne	0x1d78 <kprobe_unwind_hotspot+0x1d78>
     bbe:      	movzbl	(%rsp), %eax
     bc2:      	leal	0x1(%rax), %ecx
     bc5:      	cmpb	$0x2, %cl
     bc8:      	jb	0x290 <kprobe_unwind_hotspot+0x290>
     bce:      	movzbl	%al, %eax
     bd1:      	subq	%rax, %rbx
     bd4:      	leaq	(%rbx,%rbp), %rdx
     bd8:      	movq	%rsp, %rdi
     bdb:      	movl	$0x1, %eax
     be0:      	movl	$0x70, %ecx
     be5:      	movl	$0x1, %esi
     bea:      	callq	*%rcx
     bec:      	testq	%rax, %rax
     bef:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
     bf5:      	movq	(%rip), %rax            # 0xbfc <kprobe_unwind_hotspot+0xbfc>
     bfc:      	cmpl	$0x0, (%rax)
     bff:      	jne	0x24a5 <kprobe_unwind_hotspot+0x24a5>
     c05:      	movzbl	(%rsp), %eax
     c09:      	leal	0x1(%rax), %ecx
     c0c:      	cmpb	$0x2, %cl
     c0f:      	jb	0x290 <kprobe_unwind_hotspot+0x290>
     c15:      	movzbl	%al, %eax
     c18:      	subq	%rax, %rbx
     c1b:      	leaq	(%rbx,%rbp), %rdx
     c1f:      	movq	%rsp, %rdi
     c22:      	movl	$0x1, %eax
     c27:      	movl	$0x70, %ecx
     c2c:      	movl	$0x1, %esi
     c31:      	callq	*%rcx
     c33:      	testq	%rax, %rax
     c36:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
     c3c:      	movq	(%rip), %rax            # 0xc43 <kprobe_unwind_hotspot+0xc43>
     c43:      	cmpl	$0x0, (%rax)
     c46:      	jne	0x2aa8 <kprobe_unwind_hotspot+0x2aa8>
     c4c:      	movzbl	(%rsp), %eax
     c50:      	leal	0x1(%rax), %ecx
     c53:      	cmpb	$0x2, %cl
     c56:      	jb	0x290 <kprobe_unwind_hotspot+0x290>
     c5c:      	movzbl	%al, %eax
     c5f:      	subq	%rax, %rbx
     c62:      	leaq	(%rbx,%rbp), %rdx
     c66:      	movq	%rsp, %rdi
     c69:      	movl	$0x1, %eax
     c6e:      	movl	$0x70, %ecx
     c73:      	movl	$0x1, %esi
     c78:      	callq	*%rcx
     c7a:      	testq	%rax, %rax
     c7d:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
     c83:      	movq	(%rip), %rax            # 0xc8a <kprobe_unwind_hotspot+0xc8a>
     c8a:      	cmpl	$0x0, (%rax)
     c8d:      	jne	0x3bea <kprobe_unwind_hotspot+0x3bea>
     c93:      	movzbl	(%rsp), %eax
     c97:      	leal	0x1(%rax), %ecx
     c9a:      	cmpb	$0x2, %cl
     c9d:      	jb	0x290 <kprobe_unwind_hotspot+0x290>
     ca3:      	movzbl	%al, %eax
     ca6:      	subq	%rax, %rbx
     ca9:      	leaq	(%rbx,%rbp), %rdx
     cad:      	movq	%rsp, %rdi
     cb0:      	movl	$0x1, %eax
     cb5:      	movl	$0x70, %ecx
     cba:      	movl	$0x1, %esi
     cbf:      	callq	*%rcx
     cc1:      	testq	%rax, %rax
     cc4:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
     cca:      	movq	(%rip), %rax            # 0xcd1 <kprobe_unwind_hotspot+0xcd1>
     cd1:      	cmpl	$0x0, (%rax)
     cd4:      	jne	0x3fea <kprobe_unwind_hotspot+0x3fea>
     cda:      	movzbl	(%rsp), %eax
     cde:      	leal	0x1(%rax), %ecx
     ce1:      	cmpb	$0x2, %cl
     ce4:      	jb	0x290 <kprobe_unwind_hotspot+0x290>
     cea:      	movzbl	%al, %eax
     ced:      	subq	%rax, %rbx
     cf0:      	leaq	(%rbx,%rbp), %rdx
     cf4:      	movq	%rsp, %rdi
     cf7:      	movl	$0x1, %eax
     cfc:      	movl	$0x70, %ecx
     d01:      	movl	$0x1, %esi
     d06:      	callq	*%rcx
     d08:      	testq	%rax, %rax
     d0b:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
     d11:      	movq	(%rip), %rax            # 0xd18 <kprobe_unwind_hotspot+0xd18>
     d18:      	cmpl	$0x0, (%rax)
     d1b:      	jne	0x4381 <kprobe_unwind_hotspot+0x4381>
     d21:      	movzbl	(%rsp), %eax
     d25:      	leal	0x1(%rax), %ecx
     d28:      	cmpb	$0x2, %cl
     d2b:      	jb	0x290 <kprobe_unwind_hotspot+0x290>
     d31:      	movzbl	%al, %eax
     d34:      	subq	%rax, %rbx
     d37:      	leaq	(%rbx,%rbp), %rdx
     d3b:      	movq	%rsp, %rdi
     d3e:      	movl	$0x1, %eax
     d43:      	movl	$0x70, %ecx
     d48:      	movl	$0x1, %esi
     d4d:      	callq	*%rcx
     d4f:      	testq	%rax, %rax
     d52:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
     d58:      	movq	(%rip), %rax            # 0xd5f <kprobe_unwind_hotspot+0xd5f>
     d5f:      	cmpl	$0x0, (%rax)
     d62:      	jne	0x4465 <kprobe_unwind_hotspot+0x4465>
     d68:      	movzbl	(%rsp), %eax
     d6c:      	leal	0x1(%rax), %ecx
     d6f:      	cmpb	$0x2, %cl
     d72:      	jb	0x290 <kprobe_unwind_hotspot+0x290>
     d78:      	movzbl	%al, %eax
     d7b:      	subq	%rax, %rbx
     d7e:      	addq	%rbx, %rbp
     d81:      	movq	%rsp, %rdi
     d84:      	movl	$0x1, %eax
     d89:      	movl	$0x70, %ecx
     d8e:      	movl	$0x1, %esi
     d93:      	movq	%rbp, %rdx
     d96:      	callq	*%rcx
     d98:      	testq	%rax, %rax
     d9b:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
     da1:      	movq	(%rip), %rax            # 0xda8 <kprobe_unwind_hotspot+0xda8>
     da8:      	cmpl	$0x0, (%rax)
     dab:      	jne	0x47a7 <kprobe_unwind_hotspot+0x47a7>
     db1:      	movzbl	(%rsp), %eax
     db5:      	leal	0x1(%rax), %ecx
     db8:      	cmpb	$0x1, %cl
     dbb:      	ja	0x22b <kprobe_unwind_hotspot+0x22b>
     dc1:      	jmp	0x290 <kprobe_unwind_hotspot+0x290>
     dc6:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     dd0:      	movq	%rax, 0x66(%rsp)
     dd5:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     ddf:      	movq	%rax, 0x60(%rsp)
     de4:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     dee:      	movq	%rax, 0x58(%rsp)
     df3:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     dfd:      	movq	%rax, 0x50(%rsp)
     e02:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     e0c:      	movq	%rax, 0x48(%rsp)
     e11:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     e1b:      	movq	%rax, 0x40(%rsp)
     e20:      	leaq	0x40(%rsp), %rdi
     e25:      	movl	$0x2e, %eax
     e2a:      	movl	$0x6, %ecx
     e2f:      	movl	(%rsp), %edx
     e32:      	movl	$0x2e, %esi
     e37:      	xorl	%eax, %eax
     e39:      	callq	*%rcx
     e3b:      	jmp	0x342 <kprobe_unwind_hotspot+0x342>
     e40:      	movq	(%rip), %rax            # 0xe47 <kprobe_unwind_hotspot+0xe47>
     e47:      	cmpl	$0x0, (%rax)
     e4a:      	jne	0x23ba <kprobe_unwind_hotspot+0x23ba>
     e50:      	movl	$0x2d, 0x114(%rsp)
     e5b:      	movq	(%rip), %rdi            # 0xe62 <kprobe_unwind_hotspot+0xe62>
     e62:      	leaq	0x114(%rsp), %rsi
     e6a:      	movl	$0x1, %eax
     e6f:      	callq	*%rax
     e71:      	testq	%rax, %rax
     e74:      	je	0x11b7 <kprobe_unwind_hotspot+0x11b7>
     e7a:      	incq	(%rax)
     e7d:      	jmp	0x11c7 <kprobe_unwind_hotspot+0x11c7>
     e82:      	movb	$0x3, %cl
     e84:      	movl	%ecx, 0xb0(%rsp)
     e8b:      	testl	%eax, %eax
     e8d:      	jne	0x242e <kprobe_unwind_hotspot+0x242e>
     e93:      	movq	%r13, %rcx
     e96:      	movq	0xa8(%rsp), %rbx
     e9e:      	movl	$0x10, 0xf0(%rsp)
     ea9:      	movl	$0x10, %eax
     eae:      	movq	%rcx, %r13
     eb1:      	movl	%eax, %eax
     eb3:      	addq	%rax, %r13
     eb6:      	leaq	-0x10(%r13), %rdx
     eba:      	movq	%rsp, %rdi
     ebd:      	movl	$0x10, %eax
     ec2:      	movl	$0x70, %ecx
     ec7:      	movl	$0x10, %esi
     ecc:      	callq	*%rcx
     ece:      	movq	0x8(%rsp), %r12
     ed3:      	cmpl	$0x10, 0xf0(%rsp)
     edb:      	movq	0x38(%rsp), %r8
     ee0:      	jb	0xef6 <kprobe_unwind_hotspot+0xef6>
     ee2:      	movq	(%rip), %rax            # 0xee9 <kprobe_unwind_hotspot+0xee9>
     ee9:      	cmpl	$0x0, (%rax)
     eec:      	jne	0x1ec1 <kprobe_unwind_hotspot+0x1ec1>
     ef2:      	movq	(%rsp), %r8
     ef6:      	movl	0x2c0(%r14), %eax
     efd:      	cmpq	$0x7f, %rax
     f01:      	jb	0xf3c <kprobe_unwind_hotspot+0xf3c>
     f03:      	movq	(%rip), %rbx            # 0xf0a <kprobe_unwind_hotspot+0xf0a>
     f0a:      	cmpl	$0x0, (%rbx)
     f0d:      	jne	0x1dea <kprobe_unwind_hotspot+0x1dea>
     f13:      	movl	$0x2, (%rsp)
     f1a:      	movq	(%rip), %rdi            # 0xf21 <kprobe_unwind_hotspot+0xf21>
     f21:      	movq	%rsp, %rsi
     f24:      	movl	$0x1, %eax
     f29:      	callq	*%rax
     f2b:      	testq	%rax, %rax
     f2e:      	je	0xff9 <kprobe_unwind_hotspot+0xff9>
     f34:      	incq	(%rax)
     f37:      	jmp	0x1002 <kprobe_unwind_hotspot+0x1002>
     f3c:      	movzbl	0xf30(%r14), %ecx
     f44:      	movzbl	0xb0(%rsp), %edx
     f4c:      	shlq	$0x3c, %rdx
     f50:      	shlq	$0x20, %rbx
     f54:      	movl	%ebp, %esi
     f56:      	orq	%rbx, %rsi
     f59:      	orq	%rdx, %rsi
     f5c:      	leal	0x1(%rax), %edx
     f5f:      	movl	%edx, 0x2c0(%r14)
     f66:      	leaq	(%rax,%rax,2), %rax
     f6a:      	movq	0xb8(%rsp), %rdx
     f72:      	movq	%rdx, 0x2d0(%r14,%rax,8)
     f7a:      	movq	%rsi, 0x2d8(%r14,%rax,8)
     f82:      	movb	$0x5, 0x2e0(%r14,%rax,8)
     f8b:      	movb	%cl, 0x2e1(%r14,%rax,8)
     f93:      	movl	$0x0, 0x2e2(%r14,%rax,8)
     f9f:      	movw	$0x0, 0x2e6(%r14,%rax,8)
     faa:      	movq	(%rip), %rbx            # 0xfb1 <kprobe_unwind_hotspot+0xfb1>
     fb1:      	cmpl	$0x0, (%rbx)
     fb4:      	jne	0x1e52 <kprobe_unwind_hotspot+0x1e52>
     fba:      	movq	%r12, 0xed0(%r14)
     fc1:      	movq	%r13, 0xed8(%r14)
     fc8:      	movq	%r8, 0xee0(%r14)
     fcf:      	movb	$0x1, 0xf30(%r14)
     fd7:      	movl	$0x2a, (%rsp)
     fde:      	movq	(%rip), %rdi            # 0xfe5 <kprobe_unwind_hotspot+0xfe5>
     fe5:      	movq	%rsp, %rsi
     fe8:      	movl	$0x1, %eax
     fed:      	callq	*%rax
     fef:      	testq	%rax, %rax
     ff2:      	je	0x100c <kprobe_unwind_hotspot+0x100c>
     ff4:      	incq	(%rax)
     ff7:      	jmp	0x1015 <kprobe_unwind_hotspot+0x1015>
     ff9:      	cmpl	$0x0, (%rbx)
     ffc:      	jne	0x225e <kprobe_unwind_hotspot+0x225e>
    1002:      	movl	$0x2, %ebx
    1007:      	jmp	0x347 <kprobe_unwind_hotspot+0x347>
    100c:      	cmpl	$0x0, (%rbx)
    100f:      	jne	0x22dd <kprobe_unwind_hotspot+0x22dd>
    1015:      	movq	0xed0(%r14), %rbx
    101c:      	movq	(%rip), %rax            # 0x1023 <kprobe_unwind_hotspot+0x1023>
    1023:      	movl	(%rax), %eax
    1025:      	testq	%rbx, %rbx
    1028:      	je	0x9ceb <kprobe_unwind_hotspot+0x9ceb>
    102e:      	movabsq	$0xffffffffffffff, %r12 # imm = 0xFFFFFFFFFFFFFF
    1038:      	testl	%eax, %eax
    103a:      	jne	0x1f0b <kprobe_unwind_hotspot+0x1f0b>
    1040:      	cmpq	%r12, %rbx
    1043:      	jbe	0x1f99 <kprobe_unwind_hotspot+0x1f99>
    1049:      	movq	(%rip), %rax            # 0x1050 <kprobe_unwind_hotspot+0x1050>
    1050:      	cmpl	$0x0, (%rax)
    1053:      	jne	0x2357 <kprobe_unwind_hotspot+0x2357>
    1059:      	movl	$0xb, 0xf28(%r14)
    1064:      	movl	$0xfab, %ebp            # imm = 0xFAB
    1069:      	xorl	%r12d, %r12d
    106c:      	jmp	0x34c <kprobe_unwind_hotspot+0x34c>
    1071:      	movq	%rcx, 0x118(%rsp)
    1079:      	leaq	(%rbx,%r13), %rdx
    107d:      	addq	$-0x8, %rdx
    1081:      	leaq	0x40(%rsp), %rdi
    1086:      	movl	$0x30, %eax
    108b:      	movl	$0x70, %ecx
    1090:      	movl	$0x30, %esi
    1095:      	callq	*%rcx
    1097:      	movq	(%rip), %rax            # 0x109e <kprobe_unwind_hotspot+0x109e>
    109e:      	cmpl	$0x0, (%rax)
    10a1:      	jne	0x2517 <kprobe_unwind_hotspot+0x2517>
    10a7:      	movl	(%r14), %eax
    10aa:      	movl	$0x60, (%rsp)
    10b1:      	movbel	%eax, 0x4(%rsp)
    10b7:      	addq	%rbx, %r13
    10ba:      	movq	0x40(%rsp), %rax
    10bf:      	movbeq	%rax, 0x8(%rsp)
    10c6:      	movabsq	$-0x100000000000000, %rbx # imm = 0xFF00000000000000
    10d0:      	movq	(%rip), %rdi            # 0x10d7 <kprobe_unwind_hotspot+0x10d7>
    10d7:      	movq	%rsp, %rsi
    10da:      	movl	$0x1, %eax
    10df:      	callq	*%rax
    10e1:      	testq	%rax, %rax
    10e4:      	je	0x1102 <kprobe_unwind_hotspot+0x1102>
    10e6:      	movq	0x8(%rax), %rax
    10ea:      	andq	%rbx, %rax
    10ed:      	xorl	%edx, %edx
    10ef:      	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
    10f9:      	cmpq	%rcx, %rax
    10fc:      	je	0x168d <kprobe_unwind_hotspot+0x168d>
    1102:      	movq	(%rip), %rax            # 0x1109 <kprobe_unwind_hotspot+0x1109>
    1109:      	cmpl	$0x0, (%rax)
    110c:      	jne	0x2741 <kprobe_unwind_hotspot+0x2741>
    1112:      	movl	(%r14), %eax
    1115:      	movl	$0x60, (%rsp)
    111c:      	movbel	%eax, 0x4(%rsp)
    1122:      	movq	0x48(%rsp), %rax
    1127:      	movbeq	%rax, 0x8(%rsp)
    112e:      	movq	(%rip), %rdi            # 0x1135 <kprobe_unwind_hotspot+0x1135>
    1135:      	movq	%rsp, %rsi
    1138:      	movl	$0x1, %eax
    113d:      	callq	*%rax
    113f:      	testq	%rax, %rax
    1142:      	je	0x12e2 <kprobe_unwind_hotspot+0x12e2>
    1148:      	movq	0x8(%rax), %rax
    114c:      	andq	%rbx, %rax
    114f:      	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
    1159:      	cmpq	%rcx, %rax
    115c:      	jne	0x12e2 <kprobe_unwind_hotspot+0x12e2>
    1162:      	addq	$0x8, %r13
    1166:      	movl	$0x1, %edx
    116b:      	jmp	0x168d <kprobe_unwind_hotspot+0x168d>
    1170:      	movq	(%rsp), %rax
    1174:      	movq	0xd0(%rsp), %rcx
    117c:      	cmpq	%rcx, %rax
    117f:      	jb	0x7c2 <kprobe_unwind_hotspot+0x7c2>
    1185:      	cmpq	0xd8(%rsp), %rax
    118d:      	jae	0x7c2 <kprobe_unwind_hotspot+0x7c2>
    1193:      	movq	(%rip), %rdx            # 0x119a <kprobe_unwind_hotspot+0x119a>
    119a:      	cmpl	$0x0, (%rdx)
    119d:      	jne	0x2928 <kprobe_unwind_hotspot+0x2928>
    11a3:      	movl	%eax, %edx
    11a5:      	subl	%ecx, %edx
    11a7:      	movq	%rdx, 0xa8(%rsp)
    11af:      	movq	%rax, %r12
    11b2:      	jmp	0x7d2 <kprobe_unwind_hotspot+0x7d2>
    11b7:      	movq	(%rip), %rax            # 0x11be <kprobe_unwind_hotspot+0x11be>
    11be:      	cmpl	$0x0, (%rax)
    11c1:      	jne	0x266a <kprobe_unwind_hotspot+0x266a>
    11c7:      	movl	$0x3e9, %ebx            # imm = 0x3E9
    11cc:      	movl	$0x0, 0xc0(%rsp)
    11d7:      	movl	$0x65746e49, %ebp       # imm = 0x65746E49
    11dc:      	movb	$0x2, %al
    11de:      	movl	%eax, 0xb0(%rsp)
    11e5:      	testl	%ebx, %ebx
    11e7:      	jne	0x347 <kprobe_unwind_hotspot+0x347>
    11ed:      	jmp	0x16cb <kprobe_unwind_hotspot+0x16cb>
    11f2:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    11fc:      	movq	%rax, 0x66(%rsp)
    1201:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    120b:      	movq	%rax, 0x60(%rsp)
    1210:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    121a:      	movq	%rax, 0x58(%rsp)
    121f:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1229:      	movq	%rax, 0x50(%rsp)
    122e:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1238:      	movq	%rax, 0x48(%rsp)
    123d:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1247:      	movq	%rax, 0x40(%rsp)
    124c:      	leaq	0x40(%rsp), %rdi
    1251:      	movl	$0x2e, %eax
    1256:      	movl	$0x6, %ecx
    125b:      	movl	0xc8(%rsp), %edx
    1262:      	movl	$0x2e, %esi
    1267:      	xorl	%eax, %eax
    1269:      	callq	*%rcx
    126b:      	jmp	0x3ea <kprobe_unwind_hotspot+0x3ea>
    1270:      	movabsq	$0xa786c2520626f6c, %rax # imm = 0xA786C2520626F6C
    127a:      	movq	%rax, 0x58(%rsp)
    127f:      	movabsq	$0x6265646f63206f74, %rax # imm = 0x6265646F63206F74
    1289:      	movq	%rax, 0x50(%rsp)
    128e:      	movabsq	$0x2064657070616d20, %rax # imm = 0x2064657070616D20
    1298:      	movq	%rax, 0x48(%rsp)
    129d:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    12a7:      	movq	%rax, 0x40(%rsp)
    12ac:      	movb	$0x0, 0x60(%rsp)
    12b1:      	leaq	0x40(%rsp), %rdi
    12b6:      	movl	$0x21, %eax
    12bb:      	movl	$0x6, %ecx
    12c0:      	movl	$0x21, %esi
    12c5:      	movq	%rbx, %rdx
    12c8:      	xorl	%eax, %eax
    12ca:      	callq	*%rcx
    12cc:      	movq	%rbx, 0xc8(%rsp)
    12d4:      	testq	%rbx, %rbx
    12d7:      	jne	0x2ce <kprobe_unwind_hotspot+0x2ce>
    12dd:      	jmp	0x237 <kprobe_unwind_hotspot+0x237>
    12e2:      	movq	(%rip), %rax            # 0x12e9 <kprobe_unwind_hotspot+0x12e9>
    12e9:      	cmpl	$0x0, (%rax)
    12ec:      	jne	0x27aa <kprobe_unwind_hotspot+0x27aa>
    12f2:      	movl	(%r14), %eax
    12f5:      	movl	$0x60, (%rsp)
    12fc:      	movbel	%eax, 0x4(%rsp)
    1302:      	movq	0x50(%rsp), %rax
    1307:      	movbeq	%rax, 0x8(%rsp)
    130e:      	movq	(%rip), %rdi            # 0x1315 <kprobe_unwind_hotspot+0x1315>
    1315:      	movq	%rsp, %rsi
    1318:      	movl	$0x1, %eax
    131d:      	callq	*%rax
    131f:      	testq	%rax, %rax
    1322:      	je	0x13e5 <kprobe_unwind_hotspot+0x13e5>
    1328:      	movq	0x8(%rax), %rax
    132c:      	andq	%rbx, %rax
    132f:      	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
    1339:      	cmpq	%rcx, %rax
    133c:      	jne	0x13e5 <kprobe_unwind_hotspot+0x13e5>
    1342:      	addq	$0x10, %r13
    1346:      	movl	$0x2, %edx
    134b:      	jmp	0x168d <kprobe_unwind_hotspot+0x168d>
    1350:      	cmpl	$0x0, 0x2c0(%r14)
    1358:      	je	0x161b <kprobe_unwind_hotspot+0x161b>
    135e:      	cmpb	$0x0, 0x1f(%r15)
    1363:      	je	0x17a4 <kprobe_unwind_hotspot+0x17a4>
    1369:      	movq	0x50(%rsp), %rax
    136e:      	jmp	0x17a9 <kprobe_unwind_hotspot+0x17a9>
    1373:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    137d:      	movq	%rax, 0x55(%rsp)
    1382:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    138c:      	movq	%rax, 0x50(%rsp)
    1391:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    139b:      	movq	%rax, 0x48(%rsp)
    13a0:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    13aa:      	movq	%rax, 0x40(%rsp)
    13af:      	leaq	0x40(%rsp), %rdi
    13b4:      	movl	$0x1d, %eax
    13b9:      	movl	$0x6, %r8d
    13bf:      	movzbl	(%rsp), %ecx
    13c3:      	movl	$0x1d, %esi
    13c8:      	movq	%rbx, %rdx
    13cb:      	xorl	%eax, %eax
    13cd:      	callq	*%r8
    13d0:      	movzbl	(%rsp), %eax
    13d4:      	leal	0x1(%rax), %ecx
    13d7:      	cmpb	$0x2, %cl
    13da:      	jb	0x290 <kprobe_unwind_hotspot+0x290>
    13e0:      	jmp	0xaf9 <kprobe_unwind_hotspot+0xaf9>
    13e5:      	movq	(%rip), %rax            # 0x13ec <kprobe_unwind_hotspot+0x13ec>
    13ec:      	cmpl	$0x0, (%rax)
    13ef:      	jne	0x29d6 <kprobe_unwind_hotspot+0x29d6>
    13f5:      	movl	(%r14), %eax
    13f8:      	movl	$0x60, (%rsp)
    13ff:      	movbel	%eax, 0x4(%rsp)
    1405:      	movq	0x58(%rsp), %rax
    140a:      	movbeq	%rax, 0x8(%rsp)
    1411:      	movq	(%rip), %rdi            # 0x1418 <kprobe_unwind_hotspot+0x1418>
    1418:      	movq	%rsp, %rsi
    141b:      	movl	$0x1, %eax
    1420:      	callq	*%rax
    1422:      	testq	%rax, %rax
    1425:      	je	0x1481 <kprobe_unwind_hotspot+0x1481>
    1427:      	movq	0x8(%rax), %rax
    142b:      	andq	%rbx, %rax
    142e:      	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
    1438:      	cmpq	%rcx, %rax
    143b:      	jne	0x1481 <kprobe_unwind_hotspot+0x1481>
    143d:      	addq	$0x18, %r13
    1441:      	movl	$0x3, %edx
    1446:      	jmp	0x168d <kprobe_unwind_hotspot+0x168d>
    144b:      	movzbl	0x1(%rsp), %eax
    1450:      	cmpb	$-0x3d, %al
    1452:      	jne	0x1548 <kprobe_unwind_hotspot+0x1548>
    1458:      	movl	$0x1, 0xc0(%rsp)
    1463:      	movq	(%rip), %rax            # 0x146a <kprobe_unwind_hotspot+0x146a>
    146a:      	cmpl	$0x0, (%rax)
    146d:      	jne	0x2b1a <kprobe_unwind_hotspot+0x2b1a>
    1473:      	movb	$0x3, %al
    1475:      	movl	%eax, 0xb0(%rsp)
    147c:      	jmp	0x16cb <kprobe_unwind_hotspot+0x16cb>
    1481:      	movq	(%rip), %rax            # 0x1488 <kprobe_unwind_hotspot+0x1488>
    1488:      	cmpl	$0x0, (%rax)
    148b:      	jne	0x2a3f <kprobe_unwind_hotspot+0x2a3f>
    1491:      	movl	(%r14), %eax
    1494:      	movl	$0x60, (%rsp)
    149b:      	movbel	%eax, 0x4(%rsp)
    14a1:      	movq	0x60(%rsp), %rax
    14a6:      	movbeq	%rax, 0x8(%rsp)
    14ad:      	movq	(%rip), %rdi            # 0x14b4 <kprobe_unwind_hotspot+0x14b4>
    14b4:      	movq	%rsp, %rsi
    14b7:      	movl	$0x1, %eax
    14bc:      	callq	*%rax
    14be:      	testq	%rax, %rax
    14c1:      	je	0x1627 <kprobe_unwind_hotspot+0x1627>
    14c7:      	movq	0x8(%rax), %rax
    14cb:      	andq	%rbx, %rax
    14ce:      	movabsq	$0x200000000000000, %rcx # imm = 0x200000000000000
    14d8:      	cmpq	%rcx, %rax
    14db:      	jne	0x1627 <kprobe_unwind_hotspot+0x1627>
    14e1:      	addq	$0x20, %r13
    14e5:      	movl	$0x4, %edx
    14ea:      	jmp	0x168d <kprobe_unwind_hotspot+0x168d>
    14ef:      	movabsq	$0xa626f6c626564, %rax  # imm = 0xA626F6C626564
    14f9:      	movq	%rax, 0x56(%rsp)
    14fe:      	movabsq	$0x65646f6320646165, %rax # imm = 0x65646F6320646165
    1508:      	movq	%rax, 0x50(%rsp)
    150d:      	movabsq	$0x72206f742064656c, %rax # imm = 0x72206F742064656C
    1517:      	movq	%rax, 0x48(%rsp)
    151c:      	movabsq	$0x696166203a6d766a, %rax # imm = 0x696166203A6D766A
    1526:      	movq	%rax, 0x40(%rsp)
    152b:      	leaq	0x40(%rsp), %rdi
    1530:      	movl	$0x1e, %eax
    1535:      	movl	$0x6, %ecx
    153a:      	movl	$0x1e, %esi
    153f:      	xorl	%eax, %eax
    1541:      	callq	*%rcx
    1543:      	jmp	0x310 <kprobe_unwind_hotspot+0x310>
    1548:      	movzbl	0x2(%rsp), %ecx
    154d:      	cmpb	$-0x3d, %cl
    1550:      	je	0x15a3 <kprobe_unwind_hotspot+0x15a3>
    1552:      	cmpb	$-0x3d, 0x3(%rsp)
    1557:      	je	0x15a3 <kprobe_unwind_hotspot+0x15a3>
    1559:      	cmpb	$-0x3d, 0x4(%rsp)
    155e:      	je	0x15a3 <kprobe_unwind_hotspot+0x15a3>
    1560:      	cmpb	$-0x3d, 0x5(%rsp)
    1565:      	je	0x15a3 <kprobe_unwind_hotspot+0x15a3>
    1567:      	cmpb	$-0x3d, 0x6(%rsp)
    156c:      	je	0x15a3 <kprobe_unwind_hotspot+0x15a3>
    156e:      	cmpb	$-0x3d, 0x7(%rsp)
    1573:      	je	0x15a3 <kprobe_unwind_hotspot+0x15a3>
    1575:      	cmpb	$-0x3d, 0x8(%rsp)
    157a:      	je	0x15a3 <kprobe_unwind_hotspot+0x15a3>
    157c:      	cmpb	$-0x3d, 0x9(%rsp)
    1581:      	je	0x15a3 <kprobe_unwind_hotspot+0x15a3>
    1583:      	cmpb	$-0x3d, 0xa(%rsp)
    1588:      	je	0x15a3 <kprobe_unwind_hotspot+0x15a3>
    158a:      	cmpb	$-0x3d, 0xb(%rsp)
    158f:      	je	0x15a3 <kprobe_unwind_hotspot+0x15a3>
    1591:      	cmpb	$-0x3d, 0xc(%rsp)
    1596:      	je	0x15a3 <kprobe_unwind_hotspot+0x15a3>
    1598:      	cmpb	$-0x3d, 0xd(%rsp)
    159d:      	jne	0x938 <kprobe_unwind_hotspot+0x938>
    15a3:      	cmpb	$0x5d, %al
    15a5:      	jne	0x1a28 <kprobe_unwind_hotspot+0x1a28>
    15ab:      	movl	$0x3, 0xc0(%rsp)
    15b6:      	movq	(%rip), %rax            # 0x15bd <kprobe_unwind_hotspot+0x15bd>
    15bd:      	cmpl	$0x0, (%rax)
    15c0:      	je	0x1473 <kprobe_unwind_hotspot+0x1473>
    15c6:      	movabsq	$0xa277062722070, %rax  # imm = 0xA277062722070
    15d0:      	movq	%rax, 0x58(%rsp)
    15d5:      	movabsq	$0x6f7027206e6f2065, %rax # imm = 0x6F7027206E6F2065
    15df:      	movq	%rax, 0x50(%rsp)
    15e4:      	movabsq	$0x75676f6c69706520, %rax # imm = 0x75676F6C69706520
    15ee:      	movq	%rax, 0x48(%rsp)
    15f3:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    15fd:      	movq	%rax, 0x40(%rsp)
    1602:      	leaq	0x40(%rsp), %rdi
    1607:      	movl	$0x20, %eax
    160c:      	movl	$0x6, %ecx
    1611:      	movl	$0x20, %esi
    1616:      	jmp	0x2b63 <kprobe_unwind_hotspot+0x2b63>
    161b:      	movq	0xf00(%r14), %rax
    1622:      	jmp	0x17a9 <kprobe_unwind_hotspot+0x17a9>
    1627:      	movq	(%rip), %rax            # 0x162e <kprobe_unwind_hotspot+0x162e>
    162e:      	cmpl	$0x0, (%rax)
    1631:      	jne	0x2c11 <kprobe_unwind_hotspot+0x2c11>
    1637:      	movl	(%r14), %eax
    163a:      	movl	$0x60, (%rsp)
    1641:      	movbel	%eax, 0x4(%rsp)
    1647:      	movq	0x68(%rsp), %rax
    164c:      	movbeq	%rax, 0x8(%rsp)
    1653:      	movq	(%rip), %rdi            # 0x165a <kprobe_unwind_hotspot+0x165a>
    165a:      	movq	%rsp, %rsi
    165d:      	movl	$0x1, %eax
    1662:      	callq	*%rax
    1664:      	testq	%rax, %rax
    1667:      	je	0x1772 <kprobe_unwind_hotspot+0x1772>
    166d:      	andq	0x8(%rax), %rbx
    1671:      	movabsq	$0x200000000000000, %rax # imm = 0x200000000000000
    167b:      	cmpq	%rax, %rbx
    167e:      	jne	0x1772 <kprobe_unwind_hotspot+0x1772>
    1684:      	addq	$0x28, %r13
    1688:      	movl	$0x5, %edx
    168d:      	movq	%r13, 0x118(%rsp)
    1695:      	xorl	%ebx, %ebx
    1697:      	movl	$0x5, 0xc0(%rsp)
    16a2:      	movq	(%rip), %rax            # 0x16a9 <kprobe_unwind_hotspot+0x16a9>
    16a9:      	cmpl	$0x0, (%rax)
    16ac:      	jne	0x25f4 <kprobe_unwind_hotspot+0x25f4>
    16b2:      	movb	$0x3, %al
    16b4:      	movl	%eax, 0xb0(%rsp)
    16bb:      	movq	0x118(%rsp), %r13
    16c3:      	testl	%ebx, %ebx
    16c5:      	jne	0x347 <kprobe_unwind_hotspot+0x347>
    16cb:      	cmpl	$0x2, 0xc0(%rsp)
    16d3:      	jle	0x1707 <kprobe_unwind_hotspot+0x1707>
    16d5:      	cmpl	$0x4, 0xc0(%rsp)
    16dd:      	jg	0x173b <kprobe_unwind_hotspot+0x173b>
    16df:      	cmpl	$0x3, 0xc0(%rsp)
    16e7:      	je	0xe93 <kprobe_unwind_hotspot+0xe93>
    16ed:      	cmpl	$0x4, 0xc0(%rsp)
    16f5:      	jne	0x1015 <kprobe_unwind_hotspot+0x1015>
    16fb:      	movl	0xf0(%rsp), %eax
    1702:      	jmp	0x9ba <kprobe_unwind_hotspot+0x9ba>
    1707:      	movl	$0x1, %ebx
    170c:      	cmpl	$0x0, 0xc0(%rsp)
    1714:      	je	0x347 <kprobe_unwind_hotspot+0x347>
    171a:      	cmpl	$0x1, 0xc0(%rsp)
    1722:      	je	0x9aa <kprobe_unwind_hotspot+0x9aa>
    1728:      	cmpl	$0x2, 0xc0(%rsp)
    1730:      	je	0x97a <kprobe_unwind_hotspot+0x97a>
    1736:      	jmp	0x1015 <kprobe_unwind_hotspot+0x1015>
    173b:      	cmpl	$0x5, 0xc0(%rsp)
    1743:      	je	0x1765 <kprobe_unwind_hotspot+0x1765>
    1745:      	cmpl	$0x6, 0xc0(%rsp)
    174d:      	movq	0x38(%rsp), %r8
    1752:      	movq	0xa8(%rsp), %rbx
    175a:      	je	0xef6 <kprobe_unwind_hotspot+0xef6>
    1760:      	jmp	0x1015 <kprobe_unwind_hotspot+0x1015>
    1765:      	movq	0xa8(%rsp), %rbx
    176d:      	jmp	0xeb6 <kprobe_unwind_hotspot+0xeb6>
    1772:      	movl	$0x2e, 0x100(%rsp)
    177d:      	movq	(%rip), %rdi            # 0x1784 <kprobe_unwind_hotspot+0x1784>
    1784:      	leaq	0x100(%rsp), %rsi
    178c:      	movl	$0x1, %eax
    1791:      	callq	*%rax
    1793:      	testq	%rax, %rax
    1796:      	je	0x1a03 <kprobe_unwind_hotspot+0x1a03>
    179c:      	incq	(%rax)
    179f:      	jmp	0x1a13 <kprobe_unwind_hotspot+0x1a13>
    17a4:      	movq	0x58(%rsp), %rax
    17a9:      	movq	%rax, 0xb0(%rsp)
    17b1:      	movq	0x78(%rsp), %rsi
    17b6:      	movq	0x88(%rsp), %r13
    17be:      	movq	0x90(%rsp), %rax
    17c6:      	movq	%rax, 0x38(%rsp)
    17cb:      	movq	0x98(%rsp), %r12
    17d3:      	movzbl	0x1c(%r15), %eax
    17d8:      	addq	%rsi, %rax
    17db:      	leaq	0x100(%rsp), %rdi
    17e3:      	movl	$0x8, %ecx
    17e8:      	movl	$0x70, %r8d
    17ee:      	movzbl	0x1c(%r15), %edx
    17f3:      	movq	%rsi, 0x118(%rsp)
    17fb:      	addq	%rsi, %rdx
    17fe:      	movl	$0x8, %esi
    1803:      	callq	*%r8
    1806:      	testq	%rax, %rax
    1809:      	je	0x1881 <kprobe_unwind_hotspot+0x1881>
    180b:      	movq	(%rip), %rax            # 0x1812 <kprobe_unwind_hotspot+0x1812>
    1812:      	cmpl	$0x0, (%rax)
    1815:      	je	0xe50 <kprobe_unwind_hotspot+0xe50>
    181b:      	movabsq	$0xa646f6874656d63, %rax # imm = 0xA646F6874656D63
    1825:      	movq	%rax, 0x20(%rsp)
    182a:      	movabsq	$0x2072657465727072, %rax # imm = 0x2072657465727072
    1834:      	movq	%rax, 0x18(%rsp)
    1839:      	movabsq	$0x65746e6920646165, %rax # imm = 0x65746E6920646165
    1843:      	movq	%rax, 0x10(%rsp)
    1848:      	movabsq	$0x72206f742064656c, %rax # imm = 0x72206F742064656C
    1852:      	movq	%rax, 0x8(%rsp)
    1857:      	movabsq	$0x696166203a6d766a, %rax # imm = 0x696166203A6D766A
    1861:      	movq	%rax, (%rsp)
    1865:      	movb	$0x0, 0x28(%rsp)
    186a:      	movq	%rsp, %rdi
    186d:      	movl	$0x29, %eax
    1872:      	movl	$0x6, %ecx
    1877:      	movl	$0x29, %esi
    187c:      	jmp	0x2425 <kprobe_unwind_hotspot+0x2425>
    1881:      	movq	0x100(%rsp), %rbp
    1889:      	movzbl	0x1d(%r15), %eax
    188e:      	addq	%rbp, %rax
    1891:      	xorl	%ebx, %ebx
    1893:      	movq	0xb0(%rsp), %rdx
    189b:      	cmpq	%rax, %rdx
    189e:      	movl	$0x0, %ecx
    18a3:      	cmovaeq	%rax, %rcx
    18a7:      	subq	%rcx, %rdx
    18aa:      	movq	%rdx, 0xb0(%rsp)
    18b2:      	movq	(%rip), %rax            # 0x18b9 <kprobe_unwind_hotspot+0x18b9>
    18b9:      	cmpl	$0x0, (%rax)
    18bc:      	jne	0x2b6c <kprobe_unwind_hotspot+0x2b6c>
    18c2:      	movq	0xb0(%rsp), %rcx
    18ca:      	cmpq	$0xffff, %rcx           # imm = 0xFFFF
    18d1:      	movl	$0xffff, %eax           # imm = 0xFFFF
    18d6:      	cmovbq	%rcx, %rax
    18da:      	movq	%rax, 0xa8(%rsp)
    18e2:      	shrq	$0x3, %rbp
    18e6:      	movl	$0x6, 0xc0(%rsp)
    18f1:      	movb	$0x2, %al
    18f3:      	movl	%eax, 0xb0(%rsp)
    18fa:      	movq	0x118(%rsp), %rax
    1902:      	movq	%rax, 0xb8(%rsp)
    190a:      	testl	%ebx, %ebx
    190c:      	jne	0x347 <kprobe_unwind_hotspot+0x347>
    1912:      	jmp	0x16cb <kprobe_unwind_hotspot+0x16cb>
    1917:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1921:      	movq	%rax, 0x66(%rsp)
    1926:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1930:      	movq	%rax, 0x60(%rsp)
    1935:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    193f:      	movq	%rax, 0x58(%rsp)
    1944:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    194e:      	movq	%rax, 0x50(%rsp)
    1953:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    195d:      	movq	%rax, 0x48(%rsp)
    1962:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    196c:      	movq	%rax, 0x40(%rsp)
    1971:      	leaq	0x40(%rsp), %rdi
    1976:      	movl	$0x2e, %eax
    197b:      	movl	$0x6, %ecx
    1980:      	movl	(%rsp), %edx
    1983:      	movl	$0x2e, %esi
    1988:      	xorl	%eax, %eax
    198a:      	callq	*%rcx
    198c:      	jmp	0x6e7 <kprobe_unwind_hotspot+0x6e7>
    1991:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    199b:      	movq	%rax, 0x55(%rsp)
    19a0:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    19aa:      	movq	%rax, 0x50(%rsp)
    19af:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    19b9:      	movq	%rax, 0x48(%rsp)
    19be:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    19c8:      	movq	%rax, 0x40(%rsp)
    19cd:      	leaq	0x40(%rsp), %rdi
    19d2:      	movl	$0x1d, %eax
    19d7:      	movl	$0x6, %r8d
    19dd:      	movzbl	(%rsp), %ecx
    19e1:      	movl	$0x1d, %esi
    19e6:      	movq	%rbx, %rdx
    19e9:      	xorl	%eax, %eax
    19eb:      	callq	*%r8
    19ee:      	movzbl	(%rsp), %eax
    19f2:      	leal	0x1(%rax), %ecx
    19f5:      	cmpb	$0x2, %cl
    19f8:      	jb	0x290 <kprobe_unwind_hotspot+0x290>
    19fe:      	jmp	0xb40 <kprobe_unwind_hotspot+0xb40>
    1a03:      	movq	(%rip), %rax            # 0x1a0a <kprobe_unwind_hotspot+0x1a0a>
    1a0a:      	cmpl	$0x0, (%rax)
    1a0d:      	jne	0x3b6f <kprobe_unwind_hotspot+0x3b6f>
    1a13:      	movl	$0x3ea, %ebx            # imm = 0x3EA
    1a18:      	movl	$0x0, 0xc0(%rsp)
    1a23:      	jmp	0x16b2 <kprobe_unwind_hotspot+0x16b2>
    1a28:      	cmpb	$0x41, %al
    1a2a:      	jne	0x1aca <kprobe_unwind_hotspot+0x1aca>
    1a30:      	cmpb	$-0x7b, %cl
    1a33:      	jne	0x1aca <kprobe_unwind_hotspot+0x1aca>
    1a39:      	cmpb	$0x2, 0x3(%rsp)
    1a3e:      	jne	0x1aca <kprobe_unwind_hotspot+0x1aca>
    1a44:      	cmpb	$-0x3d, 0x4(%rsp)
    1a49:      	jne	0x1aca <kprobe_unwind_hotspot+0x1aca>
    1a4b:      	movl	$0x1, 0xc0(%rsp)
    1a56:      	movq	(%rip), %rax            # 0x1a5d <kprobe_unwind_hotspot+0x1a5d>
    1a5d:      	cmpl	$0x0, (%rax)
    1a60:      	je	0x1473 <kprobe_unwind_hotspot+0x1473>
    1a66:      	movabsq	$0xa276b63656863, %rax  # imm = 0xA276B63656863
    1a70:      	movq	%rax, 0x5f(%rsp)
    1a75:      	movabsq	$0x6320746e696f7065, %rax # imm = 0x6320746E696F7065
    1a7f:      	movq	%rax, 0x58(%rsp)
    1a84:      	movabsq	$0x666173206e6f2065, %rax # imm = 0x666173206E6F2065
    1a8e:      	movq	%rax, 0x50(%rsp)
    1a93:      	movabsq	$0x75676f6c69706520, %rax # imm = 0x75676F6C69706520
    1a9d:      	movq	%rax, 0x48(%rsp)
    1aa2:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    1aac:      	movq	%rax, 0x40(%rsp)
    1ab1:      	leaq	0x40(%rsp), %rdi
    1ab6:      	movl	$0x27, %eax
    1abb:      	movl	$0x6, %ecx
    1ac0:      	movl	$0x27, %esi
    1ac5:      	jmp	0x2b63 <kprobe_unwind_hotspot+0x2b63>
    1aca:      	cmpb	$0xf, %al
    1acc:      	jne	0x1bf5 <kprobe_unwind_hotspot+0x1bf5>
    1ad2:      	cmpb	$-0x7b, %cl
    1ad5:      	jne	0x1bf5 <kprobe_unwind_hotspot+0x1bf5>
    1adb:      	cmpb	$-0x3d, 0x7(%rsp)
    1ae0:      	jne	0x1bf5 <kprobe_unwind_hotspot+0x1bf5>
    1ae6:      	movl	$0x1, 0xc0(%rsp)
    1af1:      	movq	(%rip), %rax            # 0x1af8 <kprobe_unwind_hotspot+0x1af8>
    1af8:      	cmpl	$0x0, (%rax)
    1afb:      	je	0x1473 <kprobe_unwind_hotspot+0x1473>
    1b01:      	movabsq	$0xa276b63656863, %rax  # imm = 0xA276B63656863
    1b0b:      	movq	%rax, 0x6e(%rsp)
    1b10:      	movabsq	$0x6863206e6f697470, %rax # imm = 0x6863206E6F697470
    1b1a:      	movq	%rax, 0x68(%rsp)
    1b1f:      	movabsq	$0x6563786520726570, %rax # imm = 0x6563786520726570
    1b29:      	movq	%rax, 0x60(%rsp)
    1b2e:      	movabsq	$0x7061727720657669, %rax # imm = 0x7061727720657669
    1b38:      	movq	%rax, 0x58(%rsp)
    1b3d:      	movabsq	$0x74616e206e6f2065, %rax # imm = 0x74616E206E6F2065
    1b47:      	movq	%rax, 0x50(%rsp)
    1b4c:      	movabsq	$0x75676f6c69706520, %rax # imm = 0x75676F6C69706520
    1b56:      	movq	%rax, 0x48(%rsp)
    1b5b:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    1b65:      	movq	%rax, 0x40(%rsp)
    1b6a:      	leaq	0x40(%rsp), %rdi
    1b6f:      	movl	$0x36, %eax
    1b74:      	movl	$0x6, %ecx
    1b79:      	movl	$0x36, %esi
    1b7e:      	jmp	0x2b63 <kprobe_unwind_hotspot+0x2b63>
    1b83:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    1b8d:      	movq	%rax, 0x55(%rsp)
    1b92:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    1b9c:      	movq	%rax, 0x50(%rsp)
    1ba1:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    1bab:      	movq	%rax, 0x48(%rsp)
    1bb0:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    1bba:      	movq	%rax, 0x40(%rsp)
    1bbf:      	leaq	0x40(%rsp), %rdi
    1bc4:      	movl	$0x1d, %eax
    1bc9:      	movl	$0x6, %r8d
    1bcf:      	movzbl	(%rsp), %ecx
    1bd3:      	movl	$0x1d, %esi
    1bd8:      	movq	%rbx, %rdx
    1bdb:      	xorl	%eax, %eax
    1bdd:      	callq	*%r8
    1be0:      	movzbl	(%rsp), %eax
    1be4:      	leal	0x1(%rax), %ecx
    1be7:      	cmpb	$0x2, %cl
    1bea:      	jb	0x290 <kprobe_unwind_hotspot+0x290>
    1bf0:      	jmp	0xb87 <kprobe_unwind_hotspot+0xb87>
    1bf5:      	movzbl	(%rsp), %eax
    1bf9:      	cmpl	$0xc9, %eax
    1bfe:      	je	0x1c09 <kprobe_unwind_hotspot+0x1c09>
    1c00:      	cmpl	$0x5d, %eax
    1c03:      	jne	0x938 <kprobe_unwind_hotspot+0x938>
    1c09:      	movl	$0x1, 0xc0(%rsp)
    1c14:      	movq	(%rip), %rax            # 0x1c1b <kprobe_unwind_hotspot+0x1c1b>
    1c1b:      	cmpl	$0x0, (%rax)
    1c1e:      	je	0x1473 <kprobe_unwind_hotspot+0x1473>
    1c24:      	movabsq	$0xa27657661656c, %rax  # imm = 0xA27657661656C
    1c2e:      	movq	%rax, 0x58(%rsp)
    1c33:      	movabsq	$0x2072657466612065, %rax # imm = 0x2072657466612065
    1c3d:      	movq	%rax, 0x50(%rsp)
    1c42:      	movabsq	$0x75676f6c69706520, %rax # imm = 0x75676F6C69706520
    1c4c:      	movq	%rax, 0x48(%rsp)
    1c51:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    1c5b:      	movq	%rax, 0x40(%rsp)
    1c60:      	leaq	0x40(%rsp), %rdi
    1c65:      	movl	$0x20, %eax
    1c6a:      	movl	$0x6, %ecx
    1c6f:      	jmp	0x1611 <kprobe_unwind_hotspot+0x1611>
    1c74:      	movabsq	$0xa786c252d786c, %rax  # imm = 0xA786C252D786C
    1c7e:      	movq	%rax, 0x4f(%rsp)
    1c83:      	movabsq	$0x6c252065646f6320, %rax # imm = 0x6C252065646F6320
    1c8d:      	movq	%rax, 0x48(%rsp)
    1c92:      	movabsq	$0x3e2d20203a6d766a, %rbx # imm = 0x3E2D20203A6D766A
    1c9c:      	movq	%rbx, 0x40(%rsp)
    1ca1:      	leaq	0x40(%rsp), %rdi
    1ca6:      	movl	$0x17, %eax
    1cab:      	movl	$0x6, %r8d
    1cb1:      	movq	0xd0(%rsp), %rdx
    1cb9:      	movq	0xd8(%rsp), %rcx
    1cc1:      	movl	$0x17, %esi
    1cc6:      	xorl	%eax, %eax
    1cc8:      	callq	*%r8
    1ccb:      	movq	(%rip), %rax            # 0x1cd2 <kprobe_unwind_hotspot+0x1cd2>
    1cd2:      	cmpl	$0x0, (%rax)
    1cd5:      	je	0x5dc <kprobe_unwind_hotspot+0x5dc>
    1cdb:      	movabsq	$0x783020657079745f, %rax # imm = 0x783020657079745F
    1ce5:      	movq	%rax, 0x70(%rsp)
    1cea:      	movabsq	$0x656d617266202c75, %rax # imm = 0x656D617266202C75
    1cf4:      	movq	%rax, 0x68(%rsp)
    1cf9:      	movabsq	$0x2520657a69735f65, %rax # imm = 0x2520657A69735F65
    1d03:      	movq	%rax, 0x60(%rsp)
    1d08:      	movabsq	$0x6d617266202c7525, %rax # imm = 0x6D617266202C7525
    1d12:      	movq	%rax, 0x58(%rsp)
    1d17:      	movabsq	$0x206574656c706d6f, %rax # imm = 0x206574656C706D6F
    1d21:      	movq	%rax, 0x50(%rsp)
    1d26:      	movabsq	$0x635f656d61726620, %rax # imm = 0x635F656D61726620
    1d30:      	movq	%rax, 0x48(%rsp)
    1d35:      	movq	%rbx, 0x40(%rsp)
    1d3a:      	movl	$0xa7825, 0x78(%rsp)    # imm = 0xA7825
    1d42:      	leaq	0x40(%rsp), %rdi
    1d47:      	movl	$0x3c, %eax
    1d4c:      	movl	$0x6, %r9d
    1d52:      	movzwl	0xf8(%rsp), %edx
    1d5a:      	movl	0xe8(%rsp), %r8d
    1d62:      	movl	0xf0(%rsp), %ecx
    1d69:      	movl	$0x3c, %esi
    1d6e:      	xorl	%eax, %eax
    1d70:      	callq	*%r9
    1d73:      	jmp	0x5dc <kprobe_unwind_hotspot+0x5dc>
    1d78:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    1d82:      	movq	%rax, 0x55(%rsp)
    1d87:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    1d91:      	movq	%rax, 0x50(%rsp)
    1d96:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    1da0:      	movq	%rax, 0x48(%rsp)
    1da5:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    1daf:      	movq	%rax, 0x40(%rsp)
    1db4:      	leaq	0x40(%rsp), %rdi
    1db9:      	movl	$0x1d, %eax
    1dbe:      	movl	$0x6, %r8d
    1dc4:      	movzbl	(%rsp), %ecx
    1dc8:      	movl	$0x1d, %esi
    1dcd:      	movq	%rbx, %rdx
    1dd0:      	xorl	%eax, %eax
    1dd2:      	callq	*%r8
    1dd5:      	movzbl	(%rsp), %eax
    1dd9:      	leal	0x1(%rax), %ecx
    1ddc:      	cmpb	$0x2, %cl
    1ddf:      	jb	0x290 <kprobe_unwind_hotspot+0x290>
    1de5:      	jmp	0xbce <kprobe_unwind_hotspot+0xbce>
    1dea:      	movabsq	$0xa6c6c75662073, %rax  # imm = 0xA6C6C75662073
    1df4:      	movq	%rax, 0x5d(%rsp)
    1df9:      	movabsq	$0x66207369206b6361, %rax # imm = 0x66207369206B6361
    1e03:      	movq	%rax, 0x58(%rsp)
    1e08:      	movabsq	$0x7473203a656d6172, %rax # imm = 0x7473203A656D6172
    1e12:      	movq	%rax, 0x50(%rsp)
    1e17:      	movabsq	$0x662068737570206f, %rax # imm = 0x662068737570206F
    1e21:      	movq	%rax, 0x48(%rsp)
    1e26:      	movabsq	$0x7420656c62616e75, %rax # imm = 0x7420656C62616E75
    1e30:      	movq	%rax, 0x40(%rsp)
    1e35:      	leaq	0x40(%rsp), %rdi
    1e3a:      	movl	$0x25, %eax
    1e3f:      	movl	$0x6, %ecx
    1e44:      	movl	$0x25, %esi
    1e49:      	xorl	%eax, %eax
    1e4b:      	callq	*%rcx
    1e4d:      	jmp	0xf13 <kprobe_unwind_hotspot+0xf13>
    1e52:      	movabsq	$0x25203a7066202c78, %rax # imm = 0x25203A7066202C78
    1e5c:      	movq	%rax, 0x58(%rsp)
    1e61:      	movabsq	$0x6c25203a7073202c, %rax # imm = 0x6C25203A7073202C
    1e6b:      	movq	%rax, 0x50(%rsp)
    1e70:      	movabsq	$0x786c25203a637020, %rax # imm = 0x786C25203A637020
    1e7a:      	movq	%rax, 0x48(%rsp)
    1e7f:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    1e89:      	movq	%rax, 0x40(%rsp)
    1e8e:      	movl	$0xa786c, 0x60(%rsp)    # imm = 0xA786C
    1e96:      	leaq	0x40(%rsp), %rdi
    1e9b:      	movl	$0x24, %eax
    1ea0:      	movl	$0x6, %r9d
    1ea6:      	movl	$0x24, %esi
    1eab:      	movq	%r12, %rdx
    1eae:      	movq	%r13, %rcx
    1eb1:      	movq	%r8, %rbp
    1eb4:      	xorl	%eax, %eax
    1eb6:      	callq	*%r9
    1eb9:      	movq	%rbp, %r8
    1ebc:      	jmp	0xfba <kprobe_unwind_hotspot+0xfba>
    1ec1:      	movabsq	$0xa706620726576, %rax  # imm = 0xA706620726576
    1ecb:      	movq	%rax, 0x4d(%rsp)
    1ed0:      	movabsq	$0x7265766f63657220, %rax # imm = 0x7265766F63657220
    1eda:      	movq	%rax, 0x48(%rsp)
    1edf:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    1ee9:      	movq	%rax, 0x40(%rsp)
    1eee:      	leaq	0x40(%rsp), %rdi
    1ef3:      	movl	$0x15, %eax
    1ef8:      	movl	$0x6, %ecx
    1efd:      	movl	$0x15, %esi
    1f02:      	xorl	%eax, %eax
    1f04:      	callq	*%rcx
    1f06:      	jmp	0xef2 <kprobe_unwind_hotspot+0xef2>
    1f0b:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    1f15:      	movq	%rax, 0x68(%rsp)
    1f1a:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    1f24:      	movq	%rax, 0x60(%rsp)
    1f29:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    1f33:      	movq	%rax, 0x58(%rsp)
    1f38:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    1f42:      	movq	%rax, 0x50(%rsp)
    1f47:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    1f51:      	movq	%rax, 0x48(%rsp)
    1f56:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    1f60:      	movq	%rax, 0x40(%rsp)
    1f65:      	movb	$0x0, 0x70(%rsp)
    1f6a:      	leaq	0x40(%rsp), %rdi
    1f6f:      	movl	$0x31, %eax
    1f74:      	movl	$0x6, %ecx
    1f79:      	movl	0x2c0(%r14), %edx
    1f80:      	movl	$0x31, %esi
    1f85:      	xorl	%eax, %eax
    1f87:      	callq	*%rcx
    1f89:      	movq	0xed0(%r14), %rbx
    1f90:      	cmpq	%r12, %rbx
    1f93:      	ja	0x1049 <kprobe_unwind_hotspot+0x1049>
    1f99:      	cmpq	$0xfff, %rbx            # imm = 0xFFF
    1fa0:      	ja	0x1fca <kprobe_unwind_hotspot+0x1fca>
    1fa2:      	movq	(%rip), %rax            # 0x1fa9 <kprobe_unwind_hotspot+0x1fa9>
    1fa9:      	cmpl	$0x0, (%rax)
    1fac:      	jne	0x26e5 <kprobe_unwind_hotspot+0x26e5>
    1fb2:      	movl	$0x31, 0xf28(%r14)
    1fbd:      	movl	$0xfae, %ebp            # imm = 0xFAE
    1fc2:      	xorl	%r12d, %r12d
    1fc5:      	jmp	0x34c <kprobe_unwind_hotspot+0x34c>
    1fca:      	movl	(%r14), %eax
    1fcd:      	movl	$0x60, 0xc8(%rsp)
    1fd8:      	movbel	%eax, 0xcc(%rsp)
    1fe1:      	movbeq	%rbx, 0xd0(%rsp)
    1feb:      	movq	(%rip), %rdi            # 0x1ff2 <kprobe_unwind_hotspot+0x1ff2>
    1ff2:      	leaq	0xc8(%rsp), %rsi
    1ffa:      	movl	$0x1, %eax
    1fff:      	callq	*%rax
    2001:      	testq	%rax, %rax
    2004:      	je	0x9d07 <kprobe_unwind_hotspot+0x9d07>
    200a:      	movq	0x8(%rax), %r12
    200e:      	movq	%r12, %rcx
    2011:      	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    201b:      	andq	%rdx, %rcx
    201e:      	movq	%rcx, 0xf20(%r14)
    2025:      	movq	(%rax), %rax
    2028:      	movq	%rax, 0xf10(%r14)
    202f:      	shrq	$0x38, %r12
    2033:      	movq	%rbx, %rax
    2036:      	subq	%rcx, %rax
    2039:      	movq	%rax, 0xf18(%r14)
    2040:      	movq	(%rip), %rax            # 0x2047 <kprobe_unwind_hotspot+0x2047>
    2047:      	cmpl	$0x0, (%rax)
    204a:      	jne	0x2813 <kprobe_unwind_hotspot+0x2813>
    2050:      	cmpl	$0x1, %r12d
    2054:      	jne	0x2d1c <kprobe_unwind_hotspot+0x2d1c>
    205a:      	movq	0xf10(%r14), %rax
    2061:      	movq	%rax, 0xc8(%rsp)
    2069:      	movq	0xf18(%r14), %r13
    2070:      	movq	(%rip), %rdi            # 0x2077 <kprobe_unwind_hotspot+0x2077>
    2077:      	leaq	0xc8(%rsp), %rsi
    207f:      	movl	$0x1, %eax
    2084:      	callq	*%rax
    2086:      	movl	$0x1, %r12d
    208c:      	testq	%rax, %rax
    208f:      	je	0x2d1c <kprobe_unwind_hotspot+0x2d1c>
    2095:      	movq	%rax, %rbx
    2098:      	cmpq	%r13, (%rax)
    209b:      	ja	0x20a3 <kprobe_unwind_hotspot+0x20a3>
    209d:      	cmpq	%r13, 0x8(%rbx)
    20a1:      	jae	0x20b7 <kprobe_unwind_hotspot+0x20b7>
    20a3:      	cmpq	%r13, 0x10(%rbx)
    20a7:      	ja	0x2d1c <kprobe_unwind_hotspot+0x2d1c>
    20ad:      	cmpq	%r13, 0x18(%rbx)
    20b1:      	jb	0x2d1c <kprobe_unwind_hotspot+0x2d1c>
    20b7:      	movq	(%rip), %rax            # 0x20be <kprobe_unwind_hotspot+0x20be>
    20be:      	cmpl	$0x0, (%rax)
    20c1:      	jne	0x2c7a <kprobe_unwind_hotspot+0x2c7a>
    20c7:      	movl	0x1380(%r14), %eax
    20ce:      	movl	0x20(%rbx), %ecx
    20d1:      	btl	%ecx, %eax
    20d4:      	jae	0x2ce5 <kprobe_unwind_hotspot+0x2ce5>
    20da:      	movq	(%rip), %rax            # 0x20e1 <kprobe_unwind_hotspot+0x20e1>
    20e1:      	cmpl	$0x0, (%rax)
    20e4:      	je	0x2d1c <kprobe_unwind_hotspot+0x2d1c>
    20ea:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    20f4:      	movq	%rax, 0x50(%rsp)
    20f9:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    2103:      	movq	%rax, 0x48(%rsp)
    2108:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    2112:      	movq	%rax, 0x40(%rsp)
    2117:      	movl	$0xa656e, 0x57(%rsp)    # imm = 0xA656E
    211f:      	leaq	0x40(%rsp), %rdi
    2124:      	movl	$0x1b, %eax
    2129:      	movl	$0x6, %ecx
    212e:      	movl	$0x1b, %esi
    2133:      	xorl	%eax, %eax
    2135:      	callq	*%rcx
    2137:      	jmp	0x2d1c <kprobe_unwind_hotspot+0x2d1c>
    213c:      	movabsq	$0x6170206b6361626c, %rax # imm = 0x6170206B6361626C
    2146:      	movq	%rax, 0x58(%rsp)
    214b:      	movabsq	$0x6c61662062757473, %rax # imm = 0x6C61662062757473
    2155:      	movq	%rax, 0x50(%rsp)
    215a:      	movabsq	$0x20646e69776e7520, %rax # imm = 0x20646E69776E7520
    2164:      	movq	%rax, 0x48(%rsp)
    2169:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    2173:      	movq	%rax, 0x40(%rsp)
    2178:      	movl	$0xa6874, 0x60(%rsp)    # imm = 0xA6874
    2180:      	leaq	0x40(%rsp), %rdi
    2185:      	movl	$0x24, %eax
    218a:      	movl	$0x6, %ecx
    218f:      	movl	$0x24, %esi
    2194:      	xorl	%eax, %eax
    2196:      	callq	*%rcx
    2198:      	jmp	0x8ee <kprobe_unwind_hotspot+0x8ee>
    219d:      	movabsq	$0xa656c62617476, %rax  # imm = 0xA656C62617476
    21a7:      	movq	%rax, 0x50(%rsp)
    21ac:      	movabsq	$0x20646e69776e7520, %rax # imm = 0x20646E69776E7520
    21b6:      	movq	%rax, 0x48(%rsp)
    21bb:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    21c5:      	movq	%rax, 0x40(%rsp)
    21ca:      	leaq	0x40(%rsp), %rdi
    21cf:      	movl	$0x18, %eax
    21d4:      	movl	$0x6, %ecx
    21d9:      	movl	$0x18, %esi
    21de:      	xorl	%eax, %eax
    21e0:      	callq	*%rcx
    21e2:      	jmp	0x9aa <kprobe_unwind_hotspot+0x9aa>
    21e7:      	movabsq	$0xa64656c696166, %rax  # imm = 0xA64656C696166
    21f1:      	movq	%rax, 0x68(%rsp)
    21f6:      	movabsq	$0x20797265766f6365, %rax # imm = 0x20797265766F6365
    2200:      	movq	%rax, 0x60(%rsp)
    2205:      	movabsq	$0x72206370202c656d, %rax # imm = 0x72206370202C656D
    220f:      	movq	%rax, 0x58(%rsp)
    2214:      	movabsq	$0x6172662064657a69, %rax # imm = 0x6172662064657A69
    221e:      	movq	%rax, 0x50(%rsp)
    2223:      	movabsq	$0x6d6974706f656420, %rax # imm = 0x6D6974706F656420
    222d:      	movq	%rax, 0x48(%rsp)
    2232:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    223c:      	movq	%rax, 0x40(%rsp)
    2241:      	leaq	0x40(%rsp), %rdi
    2246:      	movl	$0x30, %eax
    224b:      	movl	$0x6, %ecx
    2250:      	movl	$0x30, %esi
    2255:      	xorl	%eax, %eax
    2257:      	callq	*%rcx
    2259:      	jmp	0x7d2 <kprobe_unwind_hotspot+0x7d2>
    225e:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2268:      	movq	%rax, 0x66(%rsp)
    226d:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2277:      	movq	%rax, 0x60(%rsp)
    227c:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2286:      	movq	%rax, 0x58(%rsp)
    228b:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2295:      	movq	%rax, 0x50(%rsp)
    229a:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    22a4:      	movq	%rax, 0x48(%rsp)
    22a9:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    22b3:      	movq	%rax, 0x40(%rsp)
    22b8:      	leaq	0x40(%rsp), %rdi
    22bd:      	movl	$0x2e, %eax
    22c2:      	movl	$0x6, %ecx
    22c7:      	movl	(%rsp), %edx
    22ca:      	movl	$0x2e, %esi
    22cf:      	xorl	%eax, %eax
    22d1:      	callq	*%rcx
    22d3:      	movl	$0x2, %ebx
    22d8:      	jmp	0x347 <kprobe_unwind_hotspot+0x347>
    22dd:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    22e7:      	movq	%rax, 0x66(%rsp)
    22ec:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    22f6:      	movq	%rax, 0x60(%rsp)
    22fb:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2305:      	movq	%rax, 0x58(%rsp)
    230a:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2314:      	movq	%rax, 0x50(%rsp)
    2319:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2323:      	movq	%rax, 0x48(%rsp)
    2328:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2332:      	movq	%rax, 0x40(%rsp)
    2337:      	leaq	0x40(%rsp), %rdi
    233c:      	movl	$0x2e, %eax
    2341:      	movl	$0x6, %ecx
    2346:      	movl	(%rsp), %edx
    2349:      	movl	$0x2e, %esi
    234e:      	xorl	%eax, %eax
    2350:      	callq	*%rcx
    2352:      	jmp	0x1015 <kprobe_unwind_hotspot+0x1015>
    2357:      	movabsq	$0x7373657264646120, %rax # imm = 0x7373657264646120
    2361:      	movq	%rax, 0x58(%rsp)
    2366:      	movabsq	$0x6c656e72656b2061, %rax # imm = 0x6C656E72656B2061
    2370:      	movq	%rax, 0x50(%rsp)
    2375:      	movabsq	$0x20736920786c2520, %rax # imm = 0x20736920786C2520
    237f:      	movq	%rax, 0x48(%rsp)
    2384:      	movabsq	$0x65756c6176204350, %rax # imm = 0x65756C6176204350
    238e:      	movq	%rax, 0x40(%rsp)
    2393:      	movw	$0xa, 0x60(%rsp)
    239a:      	leaq	0x40(%rsp), %rdi
    239f:      	movl	$0x22, %eax
    23a4:      	movl	$0x6, %ecx
    23a9:      	movl	$0x22, %esi
    23ae:      	movq	%rbx, %rdx
    23b1:      	xorl	%eax, %eax
    23b3:      	callq	*%rcx
    23b5:      	jmp	0x1059 <kprobe_unwind_hotspot+0x1059>
    23ba:      	movabsq	$0xa656d61726620, %rax  # imm = 0xA656D61726620
    23c4:      	movq	%rax, 0x26(%rsp)
    23c9:      	movabsq	$0x6620726574657270, %rax # imm = 0x6620726574657270
    23d3:      	movq	%rax, 0x20(%rsp)
    23d8:      	movabsq	$0x7265746e69206562, %rax # imm = 0x7265746E69206562
    23e2:      	movq	%rax, 0x18(%rsp)
    23e7:      	movabsq	$0x206f742079617761, %rax # imm = 0x206F742079617761
    23f1:      	movq	%rax, 0x10(%rsp)
    23f6:      	movabsq	$0x20726166206f6f74, %rax # imm = 0x20726166206F6F74
    2400:      	movq	%rax, 0x8(%rsp)
    2405:      	movabsq	$0x207066203a6d766a, %rax # imm = 0x207066203A6D766A
    240f:      	movq	%rax, (%rsp)
    2413:      	movq	%rsp, %rdi
    2416:      	movl	$0x2e, %eax
    241b:      	movl	$0x6, %ecx
    2420:      	movl	$0x2e, %esi
    2425:      	xorl	%eax, %eax
    2427:      	callq	*%rcx
    2429:      	jmp	0xe50 <kprobe_unwind_hotspot+0xe50>
    242e:      	movabsq	$0xa2963702b7066, %rax  # imm = 0xA2963702B7066
    2438:      	movq	%rax, 0x65(%rsp)
    243d:      	movabsq	$0x2b70662820656d61, %rax # imm = 0x2B70662820656D61
    2447:      	movq	%rax, 0x60(%rsp)
    244c:      	movabsq	$0x7266206574656c70, %rax # imm = 0x7266206574656C70
    2456:      	movq	%rax, 0x58(%rsp)
    245b:      	movabsq	$0x6d6f636e6920676e, %rax # imm = 0x6D6F636E6920676E
    2465:      	movq	%rax, 0x50(%rsp)
    246a:      	movabsq	$0x69646e69776e7520, %rax # imm = 0x69646E69776E7520
    2474:      	movq	%rax, 0x48(%rsp)
    2479:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    2483:      	movq	%rax, 0x40(%rsp)
    2488:      	leaq	0x40(%rsp), %rdi
    248d:      	movl	$0x2d, %eax
    2492:      	movl	$0x6, %ecx
    2497:      	movl	$0x2d, %esi
    249c:      	xorl	%eax, %eax
    249e:      	callq	*%rcx
    24a0:      	jmp	0xe93 <kprobe_unwind_hotspot+0xe93>
    24a5:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    24af:      	movq	%rax, 0x55(%rsp)
    24b4:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    24be:      	movq	%rax, 0x50(%rsp)
    24c3:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    24cd:      	movq	%rax, 0x48(%rsp)
    24d2:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    24dc:      	movq	%rax, 0x40(%rsp)
    24e1:      	leaq	0x40(%rsp), %rdi
    24e6:      	movl	$0x1d, %eax
    24eb:      	movl	$0x6, %r8d
    24f1:      	movzbl	(%rsp), %ecx
    24f5:      	movl	$0x1d, %esi
    24fa:      	movq	%rbx, %rdx
    24fd:      	xorl	%eax, %eax
    24ff:      	callq	*%r8
    2502:      	movzbl	(%rsp), %eax
    2506:      	leal	0x1(%rax), %ecx
    2509:      	cmpb	$0x2, %cl
    250c:      	jb	0x290 <kprobe_unwind_hotspot+0x290>
    2512:      	jmp	0xc15 <kprobe_unwind_hotspot+0xc15>
    2517:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    2521:      	movq	%rax, 0x18(%rsp)
    2526:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    2530:      	movq	%rax, 0x10(%rsp)
    2535:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    253f:      	movq	%rax, 0x8(%rsp)
    2544:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    254e:      	movq	%rax, (%rsp)
    2552:      	movw	$0xa, 0x20(%rsp)
    2559:      	movq	%rsp, %rdi
    255c:      	movl	$0x22, %eax
    2561:      	movl	$0x6, %r8d
    2567:      	movq	0x40(%rsp), %rcx
    256c:      	movl	$0x22, %esi
    2571:      	xorl	%edx, %edx
    2573:      	xorl	%eax, %eax
    2575:      	callq	*%r8
    2578:      	jmp	0x10a7 <kprobe_unwind_hotspot+0x10a7>
    257d:      	movabsq	$0xa29646c252065, %rax  # imm = 0xA29646C252065
    2587:      	movq	%rax, 0x67(%rsp)
    258c:      	movabsq	$0x657a697320656d61, %rax # imm = 0x657A697320656D61
    2596:      	movq	%rax, 0x60(%rsp)
    259b:      	movabsq	$0x726628207265746e, %rax # imm = 0x726628207265746E
    25a5:      	movq	%rax, 0x58(%rsp)
    25aa:      	movabsq	$0x696f7020656d6172, %rax # imm = 0x696F7020656D6172
    25b4:      	movq	%rax, 0x50(%rsp)
    25b9:      	movabsq	$0x6620676e69737520, %rax # imm = 0x6620676E69737520
    25c3:      	movq	%rax, 0x48(%rsp)
    25c8:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    25d2:      	movq	%rax, 0x40(%rsp)
    25d7:      	leaq	0x40(%rsp), %rdi
    25dc:      	movl	$0x2f, %eax
    25e1:      	movl	$0x6, %ecx
    25e6:      	movl	$0x2f, %esi
    25eb:      	xorl	%eax, %eax
    25ed:      	callq	*%rcx
    25ef:      	jmp	0x97a <kprobe_unwind_hotspot+0x97a>
    25f4:      	movabsq	$0xa7364726f7720, %rax  # imm = 0xA7364726F7720
    25fe:      	movq	%rax, 0x26(%rsp)
    2603:      	movabsq	$0x77206425202b2065, %rax # imm = 0x77206425202B2065
    260d:      	movq	%rax, 0x20(%rsp)
    2612:      	movabsq	$0x6d61726620657465, %rax # imm = 0x6D61726620657465
    261c:      	movq	%rax, 0x18(%rsp)
    2621:      	movabsq	$0x6c706d6f6320676e, %rax # imm = 0x6C706D6F6320676E
    262b:      	movq	%rax, 0x10(%rsp)
    2630:      	movabsq	$0x69646e69776e7520, %rax # imm = 0x69646E69776E7520
    263a:      	movq	%rax, 0x8(%rsp)
    263f:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    2649:      	movq	%rax, (%rsp)
    264d:      	movq	%rsp, %rdi
    2650:      	movl	$0x2e, %eax
    2655:      	movl	$0x6, %ecx
    265a:      	xorl	%ebx, %ebx
    265c:      	movl	$0x2e, %esi
    2661:      	xorl	%eax, %eax
    2663:      	callq	*%rcx
    2665:      	jmp	0x16b2 <kprobe_unwind_hotspot+0x16b2>
    266a:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2674:      	movq	%rax, 0x26(%rsp)
    2679:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2683:      	movq	%rax, 0x20(%rsp)
    2688:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2692:      	movq	%rax, 0x18(%rsp)
    2697:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    26a1:      	movq	%rax, 0x10(%rsp)
    26a6:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    26b0:      	movq	%rax, 0x8(%rsp)
    26b5:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    26bf:      	movq	%rax, (%rsp)
    26c3:      	movq	%rsp, %rdi
    26c6:      	movl	$0x2e, %eax
    26cb:      	movl	$0x6, %ecx
    26d0:      	movl	0x114(%rsp), %edx
    26d7:      	movl	$0x2e, %esi
    26dc:      	xorl	%eax, %eax
    26de:      	callq	*%rcx
    26e0:      	jmp	0x11c7 <kprobe_unwind_hotspot+0x11c7>
    26e5:      	movabsq	$0xa676e69726f6e, %rax  # imm = 0xA676E69726F6E
    26ef:      	movq	%rax, 0x56(%rsp)
    26f4:      	movabsq	$0x6f6e6769202c786c, %rax # imm = 0x6F6E6769202C786C
    26fe:      	movq	%rax, 0x50(%rsp)
    2703:      	movabsq	$0x252065756c617620, %rax # imm = 0x252065756C617620
    270d:      	movq	%rax, 0x48(%rsp)
    2712:      	movabsq	$0x6370206c6c616d73, %rax # imm = 0x6370206C6C616D73
    271c:      	movq	%rax, 0x40(%rsp)
    2721:      	leaq	0x40(%rsp), %rdi
    2726:      	movl	$0x1e, %eax
    272b:      	movl	$0x6, %ecx
    2730:      	movl	$0x1e, %esi
    2735:      	movq	%rbx, %rdx
    2738:      	xorl	%eax, %eax
    273a:      	callq	*%rcx
    273c:      	jmp	0x1fb2 <kprobe_unwind_hotspot+0x1fb2>
    2741:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    274b:      	movq	%rax, 0x18(%rsp)
    2750:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    275a:      	movq	%rax, 0x10(%rsp)
    275f:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    2769:      	movq	%rax, 0x8(%rsp)
    276e:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    2778:      	movq	%rax, (%rsp)
    277c:      	movw	$0xa, 0x20(%rsp)
    2783:      	movq	%rsp, %rdi
    2786:      	movl	$0x22, %eax
    278b:      	movl	$0x6, %r8d
    2791:      	movq	0x48(%rsp), %rcx
    2796:      	movl	$0x22, %esi
    279b:      	movl	$0x1, %edx
    27a0:      	xorl	%eax, %eax
    27a2:      	callq	*%r8
    27a5:      	jmp	0x1112 <kprobe_unwind_hotspot+0x1112>
    27aa:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    27b4:      	movq	%rax, 0x18(%rsp)
    27b9:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    27c3:      	movq	%rax, 0x10(%rsp)
    27c8:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    27d2:      	movq	%rax, 0x8(%rsp)
    27d7:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    27e1:      	movq	%rax, (%rsp)
    27e5:      	movw	$0xa, 0x20(%rsp)
    27ec:      	movq	%rsp, %rdi
    27ef:      	movl	$0x22, %eax
    27f4:      	movl	$0x6, %r8d
    27fa:      	movq	0x50(%rsp), %rcx
    27ff:      	movl	$0x22, %esi
    2804:      	movl	$0x2, %edx
    2809:      	xorl	%eax, %eax
    280b:      	callq	*%r8
    280e:      	jmp	0x12f2 <kprobe_unwind_hotspot+0x12f2>
    2813:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    281d:      	movq	%rax, 0x68(%rsp)
    2822:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    282c:      	movq	%rax, 0x60(%rsp)
    2831:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    283b:      	movq	%rax, 0x58(%rsp)
    2840:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    284a:      	movq	%rax, 0x50(%rsp)
    284f:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    2859:      	movq	%rax, 0x48(%rsp)
    285e:      	movabsq	$0x6365732074786554, %r13 # imm = 0x6365732074786554
    2868:      	movq	%r13, 0x40(%rsp)
    286d:      	movw	$0xa, 0x70(%rsp)
    2874:      	leaq	0x40(%rsp), %rdi
    2879:      	movl	$0x32, %eax
    287e:      	movl	$0x6, %r9d
    2884:      	movq	0xf10(%r14), %rcx
    288b:      	movl	$0x32, %esi
    2890:      	movq	%rbx, %rdx
    2893:      	movl	%r12d, %r8d
    2896:      	xorl	%eax, %eax
    2898:      	callq	*%r9
    289b:      	movq	(%rip), %rax            # 0x28a2 <kprobe_unwind_hotspot+0x28a2>
    28a2:      	cmpl	$0x0, (%rax)
    28a5:      	je	0x2050 <kprobe_unwind_hotspot+0x2050>
    28ab:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    28b5:      	movq	%rax, 0x67(%rsp)
    28ba:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    28c4:      	movq	%rax, 0x60(%rsp)
    28c9:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    28d3:      	movq	%rax, 0x58(%rsp)
    28d8:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    28e2:      	movq	%rax, 0x50(%rsp)
    28e7:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    28f1:      	movq	%rax, 0x48(%rsp)
    28f6:      	movq	%r13, 0x40(%rsp)
    28fb:      	leaq	0x40(%rsp), %rdi
    2900:      	movl	$0x2f, %eax
    2905:      	movl	$0x6, %r8d
    290b:      	movq	0xf18(%r14), %rcx
    2912:      	movq	0xf20(%r14), %rdx
    2919:      	movl	$0x2f, %esi
    291e:      	xorl	%eax, %eax
    2920:      	callq	*%r8
    2923:      	jmp	0x2050 <kprobe_unwind_hotspot+0x2050>
    2928:      	movabsq	$0xa2964252b7073, %rax  # imm = 0xA2964252B7073
    2932:      	movq	%rax, 0x78(%rsp)
    2937:      	movabsq	$0x206d6f7266282078, %rax # imm = 0x206D6F7266282078
    2941:      	movq	%rax, 0x70(%rsp)
    2946:      	movabsq	$0x6c25783020736120, %rax # imm = 0x6C25783020736120
    2950:      	movq	%rax, 0x68(%rsp)
    2955:      	movabsq	$0x64657265766f6365, %rax # imm = 0x64657265766F6365
    295f:      	movq	%rax, 0x60(%rsp)
    2964:      	movabsq	$0x72206370202c656d, %rax # imm = 0x72206370202C656D
    296e:      	movq	%rax, 0x58(%rsp)
    2973:      	movabsq	$0x6172662064657a69, %rax # imm = 0x6172662064657A69
    297d:      	movq	%rax, 0x50(%rsp)
    2982:      	movabsq	$0x6d6974706f656420, %rax # imm = 0x6D6974706F656420
    298c:      	movq	%rax, 0x48(%rsp)
    2991:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    299b:      	movq	%rax, 0x40(%rsp)
    29a0:      	leaq	0x40(%rsp), %rdi
    29a5:      	movl	$0x40, %eax
    29aa:      	movl	$0x6, %r8d
    29b0:      	movq	(%rsp), %rdx
    29b4:      	movl	0xec(%rsp), %ecx
    29bb:      	movl	$0x40, %esi
    29c0:      	xorl	%eax, %eax
    29c2:      	callq	*%r8
    29c5:      	movq	(%rsp), %rax
    29c9:      	movq	0xd0(%rsp), %rcx
    29d1:      	jmp	0x11a3 <kprobe_unwind_hotspot+0x11a3>
    29d6:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    29e0:      	movq	%rax, 0x18(%rsp)
    29e5:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    29ef:      	movq	%rax, 0x10(%rsp)
    29f4:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    29fe:      	movq	%rax, 0x8(%rsp)
    2a03:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    2a0d:      	movq	%rax, (%rsp)
    2a11:      	movw	$0xa, 0x20(%rsp)
    2a18:      	movq	%rsp, %rdi
    2a1b:      	movl	$0x22, %eax
    2a20:      	movl	$0x6, %r8d
    2a26:      	movq	0x58(%rsp), %rcx
    2a2b:      	movl	$0x22, %esi
    2a30:      	movl	$0x3, %edx
    2a35:      	xorl	%eax, %eax
    2a37:      	callq	*%r8
    2a3a:      	jmp	0x13f5 <kprobe_unwind_hotspot+0x13f5>
    2a3f:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    2a49:      	movq	%rax, 0x18(%rsp)
    2a4e:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    2a58:      	movq	%rax, 0x10(%rsp)
    2a5d:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    2a67:      	movq	%rax, 0x8(%rsp)
    2a6c:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    2a76:      	movq	%rax, (%rsp)
    2a7a:      	movw	$0xa, 0x20(%rsp)
    2a81:      	movq	%rsp, %rdi
    2a84:      	movl	$0x22, %eax
    2a89:      	movl	$0x6, %r8d
    2a8f:      	movq	0x60(%rsp), %rcx
    2a94:      	movl	$0x22, %esi
    2a99:      	movl	$0x4, %edx
    2a9e:      	xorl	%eax, %eax
    2aa0:      	callq	*%r8
    2aa3:      	jmp	0x1491 <kprobe_unwind_hotspot+0x1491>
    2aa8:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    2ab2:      	movq	%rax, 0x55(%rsp)
    2ab7:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    2ac1:      	movq	%rax, 0x50(%rsp)
    2ac6:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    2ad0:      	movq	%rax, 0x48(%rsp)
    2ad5:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    2adf:      	movq	%rax, 0x40(%rsp)
    2ae4:      	leaq	0x40(%rsp), %rdi
    2ae9:      	movl	$0x1d, %eax
    2aee:      	movl	$0x6, %r8d
    2af4:      	movzbl	(%rsp), %ecx
    2af8:      	movl	$0x1d, %esi
    2afd:      	movq	%rbx, %rdx
    2b00:      	xorl	%eax, %eax
    2b02:      	callq	*%r8
    2b05:      	movzbl	(%rsp), %eax
    2b09:      	leal	0x1(%rax), %ecx
    2b0c:      	cmpb	$0x2, %cl
    2b0f:      	jb	0x290 <kprobe_unwind_hotspot+0x290>
    2b15:      	jmp	0xc5c <kprobe_unwind_hotspot+0xc5c>
    2b1a:      	movabsq	$0x657227206e6f2065, %rax # imm = 0x657227206E6F2065
    2b24:      	movq	%rax, 0x50(%rsp)
    2b29:      	movabsq	$0x75676f6c69706520, %rax # imm = 0x75676F6C69706520
    2b33:      	movq	%rax, 0x48(%rsp)
    2b38:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    2b42:      	movq	%rax, 0x40(%rsp)
    2b47:      	movl	$0xa2774, 0x58(%rsp)    # imm = 0xA2774
    2b4f:      	leaq	0x40(%rsp), %rdi
    2b54:      	movl	$0x1c, %eax
    2b59:      	movl	$0x6, %ecx
    2b5e:      	movl	$0x1c, %esi
    2b63:      	xorl	%eax, %eax
    2b65:      	callq	*%rcx
    2b67:      	jmp	0x1473 <kprobe_unwind_hotspot+0x1473>
    2b6c:      	movabsq	$0xa786c25203d20, %rax  # imm = 0xA786C25203D20
    2b76:      	movq	%rax, 0x2d(%rsp)
    2b7b:      	movabsq	$0x203d20706362202c, %rax # imm = 0x203D20706362202C
    2b85:      	movq	%rax, 0x28(%rsp)
    2b8a:      	movabsq	$0x786c257830203d20, %rax # imm = 0x786C257830203D20
    2b94:      	movq	%rax, 0x20(%rsp)
    2b99:      	movabsq	$0x646f6874656d6320, %rax # imm = 0x646F6874656D6320
    2ba3:      	movq	%rax, 0x18(%rsp)
    2ba8:      	movabsq	$0x2c786c257830203d, %rax # imm = 0x2C786C257830203D
    2bb2:      	movq	%rax, 0x10(%rsp)
    2bb7:      	movabsq	$0x20646f6874656d20, %rax # imm = 0x20646F6874656D20
    2bc1:      	movq	%rax, 0x8(%rsp)
    2bc6:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    2bd0:      	movq	%rax, (%rsp)
    2bd4:      	movq	%rsp, %rdi
    2bd7:      	movl	$0x35, %eax
    2bdc:      	movl	$0x6, %r9d
    2be2:      	movq	0x100(%rsp), %rcx
    2bea:      	movl	$0x35, %esi
    2bef:      	movq	0x118(%rsp), %rdx
    2bf7:      	movq	0xb0(%rsp), %r8
    2bff:      	xorl	%eax, %eax
    2c01:      	callq	*%r9
    2c04:      	movq	0x100(%rsp), %rbp
    2c0c:      	jmp	0x18c2 <kprobe_unwind_hotspot+0x18c2>
    2c11:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    2c1b:      	movq	%rax, 0x18(%rsp)
    2c20:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    2c2a:      	movq	%rax, 0x10(%rsp)
    2c2f:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    2c39:      	movq	%rax, 0x8(%rsp)
    2c3e:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    2c48:      	movq	%rax, (%rsp)
    2c4c:      	movw	$0xa, 0x20(%rsp)
    2c53:      	movq	%rsp, %rdi
    2c56:      	movl	$0x22, %eax
    2c5b:      	movl	$0x6, %r8d
    2c61:      	movq	0x68(%rsp), %rcx
    2c66:      	movl	$0x22, %esi
    2c6b:      	movl	$0x5, %edx
    2c70:      	xorl	%eax, %eax
    2c72:      	callq	*%r8
    2c75:      	jmp	0x1637 <kprobe_unwind_hotspot+0x1637>
    2c7a:      	movabsq	$0xa642520686374, %rax  # imm = 0xA642520686374
    2c84:      	movq	%rax, 0x56(%rsp)
    2c89:      	movabsq	$0x6374616d20737465, %rax # imm = 0x6374616D20737465
    2c93:      	movq	%rax, 0x50(%rsp)
    2c98:      	movabsq	$0x7366666f5f726574, %rax # imm = 0x7366666F5F726574
    2ca2:      	movq	%rax, 0x48(%rsp)
    2ca7:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    2cb1:      	movq	%rax, 0x40(%rsp)
    2cb6:      	leaq	0x40(%rsp), %rdi
    2cbb:      	movl	$0x1e, %eax
    2cc0:      	movl	$0x6, %ecx
    2cc5:      	movzwl	0x20(%rbx), %edx
    2cc9:      	movl	$0x1e, %esi
    2cce:      	xorl	%eax, %eax
    2cd0:      	callq	*%rcx
    2cd2:      	movl	0x1380(%r14), %eax
    2cd9:      	movl	0x20(%rbx), %ecx
    2cdc:      	btl	%ecx, %eax
    2cdf:      	jb	0x20da <kprobe_unwind_hotspot+0x20da>
    2ce5:      	movl	$0x0, (%rsp)
    2cec:      	movq	(%rip), %rdi            # 0x2cf3 <kprobe_unwind_hotspot+0x2cf3>
    2cf3:      	movq	%rsp, %rsi
    2cf6:      	movl	$0x1, %eax
    2cfb:      	callq	*%rax
    2cfd:      	testq	%rax, %rax
    2d00:      	je	0x2d07 <kprobe_unwind_hotspot+0x2d07>
    2d02:      	incq	(%rax)
    2d05:      	jmp	0x2d17 <kprobe_unwind_hotspot+0x2d17>
    2d07:      	movq	(%rip), %rax            # 0x2d0e <kprobe_unwind_hotspot+0x2d0e>
    2d0e:      	cmpl	$0x0, (%rax)
    2d11:      	jne	0x3f70 <kprobe_unwind_hotspot+0x3f70>
    2d17:      	movzwl	0x20(%rbx), %r12d
    2d1c:      	xorl	%ebp, %ebp
    2d1e:      	cmpl	$0x2, %r12d
    2d22:      	jne	0x34c <kprobe_unwind_hotspot+0x34c>
    2d28:      	movl	$0x29, 0xc8(%rsp)
    2d33:      	movq	(%rip), %rdi            # 0x2d3a <kprobe_unwind_hotspot+0x2d3a>
    2d3a:      	leaq	0xc8(%rsp), %rsi
    2d42:      	movl	$0x1, %eax
    2d47:      	callq	*%rax
    2d49:      	testq	%rax, %rax
    2d4c:      	je	0x2e0b <kprobe_unwind_hotspot+0x2e0b>
    2d52:      	incq	(%rax)
    2d55:      	movq	(%rip), %rax            # 0x2d5c <kprobe_unwind_hotspot+0x2d5c>
    2d5c:      	cmpl	$0x0, (%rax)
    2d5f:      	movq	0xed0(%r14), %r12
    2d66:      	movq	0xed8(%r14), %rax
    2d6d:      	movq	%rax, 0x38(%rsp)
    2d72:      	movq	0xee0(%r14), %rax
    2d79:      	movq	%rax, 0xa8(%rsp)
    2d81:      	je	0x2e3d <kprobe_unwind_hotspot+0x2e3d>
    2d87:      	movabsq	$0x252074657366666f, %rax # imm = 0x252074657366666F
    2d91:      	movq	%rax, 0x60(%rsp)
    2d96:      	movabsq	$0x202c786c25207472, %rax # imm = 0x202C786C25207472
    2da0:      	movq	%rax, 0x58(%rsp)
    2da5:      	movabsq	$0x6174732065646f63, %rax # imm = 0x6174732065646F63
    2daf:      	movq	%rax, 0x50(%rsp)
    2db4:      	movabsq	$0x206e6920786c2520, %rax # imm = 0x206E6920786C2520
    2dbe:      	movq	%rax, 0x48(%rsp)
    2dc3:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    2dcd:      	movq	%rax, 0x40(%rsp)
    2dd2:      	movl	$0xa786c, 0x68(%rsp)    # imm = 0xA786C
    2dda:      	leaq	0x40(%rsp), %rdi
    2ddf:      	movl	$0x2c, %eax
    2de4:      	movl	$0x6, %r9d
    2dea:      	movq	0xf20(%r14), %rcx
    2df1:      	movq	0xed0(%r14), %rdx
    2df8:      	movq	0xf18(%r14), %r8
    2dff:      	movl	$0x2c, %esi
    2e04:      	xorl	%eax, %eax
    2e06:      	callq	*%r9
    2e09:      	jmp	0x2e3d <kprobe_unwind_hotspot+0x2e3d>
    2e0b:      	movq	(%rip), %rax            # 0x2e12 <kprobe_unwind_hotspot+0x2e12>
    2e12:      	cmpl	$0x0, (%rax)
    2e15:      	jne	0x3369 <kprobe_unwind_hotspot+0x3369>
    2e1b:      	movq	0xed0(%r14), %r12
    2e22:      	movq	0xed8(%r14), %rax
    2e29:      	movq	%rax, 0x38(%rsp)
    2e2e:      	movq	0xee0(%r14), %rax
    2e35:      	movq	%rax, 0xa8(%rsp)
    2e3d:      	movzbl	0x20(%r15), %eax
    2e42:      	shrxq	%rax, 0xf18(%r14), %r13
    2e4b:      	movq	0xf10(%r14), %rbx
    2e52:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    2e5c:      	andq	%rax, %rbx
    2e5f:      	leaq	(%rbx,%r13), %rdx
    2e63:      	movq	%rsp, %rdi
    2e66:      	movl	$0x1, %eax
    2e6b:      	movl	$0x70, %ecx
    2e70:      	movl	$0x1, %esi
    2e75:      	callq	*%rcx
    2e77:      	testq	%rax, %rax
    2e7a:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    2e80:      	movq	(%rip), %rax            # 0x2e87 <kprobe_unwind_hotspot+0x2e87>
    2e87:      	cmpl	$0x0, (%rax)
    2e8a:      	jne	0x33e7 <kprobe_unwind_hotspot+0x33e7>
    2e90:      	movzbl	(%rsp), %eax
    2e94:      	leal	0x1(%rax), %ecx
    2e97:      	cmpb	$0x2, %cl
    2e9a:      	jae	0x3454 <kprobe_unwind_hotspot+0x3454>
    2ea0:      	testb	%al, %al
    2ea2:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    2ea8:      	movzbl	0x20(%r15), %eax
    2ead:      	shlxq	%rax, %r13, %rax
    2eb2:      	addq	0xf20(%r14), %rax
    2eb9:      	movzbl	0x1b(%r15), %ebx
    2ebe:      	addq	%rax, %rbx
    2ec1:      	movq	(%rip), %rax            # 0x2ec8 <kprobe_unwind_hotspot+0x2ec8>
    2ec8:      	cmpl	$0x0, (%rax)
    2ecb:      	jne	0x3d9f <kprobe_unwind_hotspot+0x3d9f>
    2ed1:      	movq	%rbx, 0xc8(%rsp)
    2ed9:      	testq	%rbx, %rbx
    2edc:      	je	0x237 <kprobe_unwind_hotspot+0x237>
    2ee2:      	movl	$0x200, %eax            # imm = 0x200
    2ee7:      	movl	$0x70, %ecx
    2eec:      	movq	0x120(%rsp), %rdi
    2ef4:      	movq	0xc8(%rsp), %rdx
    2efc:      	movl	$0x200, %esi            # imm = 0x200
    2f01:      	callq	*%rcx
    2f03:      	testq	%rax, %rax
    2f06:      	jne	0x300 <kprobe_unwind_hotspot+0x300>
    2f0c:      	movzwl	0x10(%r15), %eax
    2f11:      	movl	$0x1, %ebx
    2f16:      	cmpq	$0x1f8, %rax            # imm = 0x1F8
    2f1c:      	ja	0x347 <kprobe_unwind_hotspot+0x347>
    2f22:      	movzwl	0x12(%r15), %ecx
    2f27:      	cmpq	$0x1fc, %rcx            # imm = 0x1FC
    2f2e:      	ja	0x347 <kprobe_unwind_hotspot+0x347>
    2f34:      	movzwl	0x14(%r15), %edx
    2f39:      	cmpq	$0x1f8, %rdx            # imm = 0x1F8
    2f40:      	ja	0x347 <kprobe_unwind_hotspot+0x347>
    2f46:      	movzbl	0x17(%r15), %esi
    2f4b:      	movq	0x120(%rsp), %rdi
    2f53:      	movq	(%rdi,%rsi), %rsi
    2f57:      	movq	%rsi, 0xd0(%rsp)
    2f5f:      	movzbl	0x18(%r15), %esi
    2f64:      	movq	(%rdi,%rsi), %rsi
    2f68:      	movq	%rsi, 0xd8(%rsp)
    2f70:      	movzbl	0x1a(%r15), %esi
    2f75:      	movl	(%rdi,%rsi), %esi
    2f78:      	shll	$0x3, %esi
    2f7b:      	movl	%esi, 0xf0(%rsp)
    2f82:      	movzbl	0x19(%r15), %esi
    2f87:      	movzwl	(%rdi,%rsi), %esi
    2f8b:      	movw	%si, 0xf8(%rsp)
    2f93:      	movl	(%rdi,%rcx), %ecx
    2f96:      	movl	%ecx, 0xf4(%rsp)
    2f9d:      	movl	(%rdi,%rdx), %ecx
    2fa0:      	movl	%ecx, 0xec(%rsp)
    2fa7:      	movq	(%rdi,%rax), %rax
    2fab:      	movq	%rax, 0xe0(%rsp)
    2fb3:      	movzbl	0x16(%r15), %eax
    2fb8:      	movq	(%rdi,%rax), %rdx
    2fbc:      	movl	$0x4, %eax
    2fc1:      	movl	$0x70, %ecx
    2fc6:      	leaq	0xe8(%rsp), %rdi
    2fce:      	movl	$0x4, %esi
    2fd3:      	callq	*%rcx
    2fd5:      	testq	%rax, %rax
    2fd8:      	jne	0x300 <kprobe_unwind_hotspot+0x300>
    2fde:      	cmpb	$0x0, 0x21(%r15)
    2fe3:      	je	0x3011 <kprobe_unwind_hotspot+0x3011>
    2fe5:      	movq	0xc8(%rsp), %rax
    2fed:      	movl	0xd0(%rsp), %ecx
    2ff4:      	addq	%rax, %rcx
    2ff7:      	movq	%rcx, 0xd0(%rsp)
    2fff:      	movl	0xd8(%rsp), %ecx
    3006:      	addq	%rax, %rcx
    3009:      	movq	%rcx, 0xd8(%rsp)
    3011:      	movq	(%rip), %rax            # 0x3018 <kprobe_unwind_hotspot+0x3018>
    3018:      	cmpl	$0x0, (%rax)
    301b:      	jne	0x44d7 <kprobe_unwind_hotspot+0x44d7>
    3021:      	movq	0xc8(%rsp), %rax
    3029:      	movq	%rax, 0xc0(%rsp)
    3031:      	movq	0xd0(%rsp), %rax
    3039:      	movl	0xe8(%rsp), %edx
    3040:      	movl	%r12d, %ecx
    3043:      	subl	%eax, %ecx
    3045:      	movq	%rcx, 0x118(%rsp)
    304d:      	movq	%rdx, 0xb8(%rsp)
    3055:      	cmpl	$0x6974616d, %edx       # imm = 0x6974616D
    305b:      	jg	0x314b <kprobe_unwind_hotspot+0x314b>
    3061:      	cmpl	$0x62617476, 0xb8(%rsp) # imm = 0x62617476
    306c:      	je	0x328e <kprobe_unwind_hotspot+0x328e>
    3072:      	cmpl	$0x65746e49, 0xb8(%rsp) # imm = 0x65746E49
    307d:      	jne	0x32c9 <kprobe_unwind_hotspot+0x32c9>
    3083:      	movq	0x38(%rsp), %rax
    3088:      	cmpq	%rax, 0xa8(%rsp)
    3090:      	jb	0x3768 <kprobe_unwind_hotspot+0x3768>
    3096:      	movq	0x38(%rsp), %rax
    309b:      	addq	$0x1000, %rax           # imm = 0x1000
    30a1:      	cmpq	%rax, 0xa8(%rsp)
    30a9:      	jae	0x3768 <kprobe_unwind_hotspot+0x3768>
    30af:      	movq	0xa8(%rsp), %rax
    30b7:      	leaq	-0x50(%rax), %rdx
    30bb:      	leaq	0x40(%rsp), %rdi
    30c0:      	movl	$0x60, %eax
    30c5:      	movl	$0x70, %ecx
    30ca:      	movl	$0x60, %esi
    30cf:      	callq	*%rcx
    30d1:      	testq	%rax, %rax
    30d4:      	je	0x3e11 <kprobe_unwind_hotspot+0x3e11>
    30da:      	movq	(%rip), %rax            # 0x30e1 <kprobe_unwind_hotspot+0x30e1>
    30e1:      	cmpl	$0x0, (%rax)
    30e4:      	je	0x3778 <kprobe_unwind_hotspot+0x3778>
    30ea:      	movabsq	$0xa656d61726620, %rax  # imm = 0xA656D61726620
    30f4:      	movq	%rax, 0x1f(%rsp)
    30f9:      	movabsq	$0x2072657465727072, %rax # imm = 0x2072657465727072
    3103:      	movq	%rax, 0x18(%rsp)
    3108:      	movabsq	$0x65746e6920646165, %rax # imm = 0x65746E6920646165
    3112:      	movq	%rax, 0x10(%rsp)
    3117:      	movabsq	$0x72206f742064656c, %rax # imm = 0x72206F742064656C
    3121:      	movq	%rax, 0x8(%rsp)
    3126:      	movabsq	$0x696166203a6d766a, %rax # imm = 0x696166203A6D766A
    3130:      	movq	%rax, (%rsp)
    3134:      	movq	%rsp, %rdi
    3137:      	movl	$0x27, %eax
    313c:      	movl	$0x6, %ecx
    3141:      	movl	$0x27, %esi
    3146:      	jmp	0x4a9f <kprobe_unwind_hotspot+0x4a9f>
    314b:      	cmpl	$0x6974616e, 0xb8(%rsp) # imm = 0x6974616E
    3156:      	je	0x3169 <kprobe_unwind_hotspot+0x3169>
    3158:      	cmpl	$0x74656d6e, 0xb8(%rsp) # imm = 0x74656D6E
    3163:      	jne	0x32c9 <kprobe_unwind_hotspot+0x32c9>
    3169:      	movl	0xf4(%rsp), %ecx
    3170:      	movq	%rcx, 0xb8(%rsp)
    3178:      	movq	0xe0(%rsp), %rcx
    3180:      	movl	%ecx, %edx
    3182:      	addq	0xc0(%rsp), %rdx
    318a:      	cmpb	$0x0, 0x21(%r15)
    318f:      	cmoveq	%rcx, %rdx
    3193:      	cmpq	%rdx, %r12
    3196:      	jne	0x31e8 <kprobe_unwind_hotspot+0x31e8>
    3198:      	movl	0xec(%rsp), %eax
    319f:      	movq	0x38(%rsp), %rsi
    31a4:      	addq	%rsi, %rax
    31a7:      	movq	%rsp, %rdi
    31aa:      	movl	$0x8, %ecx
    31af:      	movl	$0x70, %r8d
    31b5:      	movl	0xec(%rsp), %edx
    31bc:      	addq	%rsi, %rdx
    31bf:      	movl	$0x8, %esi
    31c4:      	callq	*%r8
    31c7:      	testq	%rax, %rax
    31ca:      	je	0x3c5c <kprobe_unwind_hotspot+0x3c5c>
    31d0:      	movq	(%rip), %rax            # 0x31d7 <kprobe_unwind_hotspot+0x31d7>
    31d7:      	cmpl	$0x0, (%rax)
    31da:      	jne	0x48c4 <kprobe_unwind_hotspot+0x48c4>
    31e0:      	movq	0xd0(%rsp), %rax
    31e8:      	movzwl	0xf8(%rsp), %ecx
    31f0:      	addq	%rax, %rcx
    31f3:      	cmpq	%rcx, %r12
    31f6:      	jae	0x3300 <kprobe_unwind_hotspot+0x3300>
    31fc:      	addq	$-0x4, %rcx
    3200:      	movq	(%rip), %rax            # 0x3207 <kprobe_unwind_hotspot+0x3207>
    3207:      	movl	(%rax), %eax
    3209:      	cmpq	%rcx, %r12
    320c:      	jae	0x37aa <kprobe_unwind_hotspot+0x37aa>
    3212:      	movb	$0x3, %cl
    3214:      	movl	%ecx, 0xb0(%rsp)
    321b:      	testl	%eax, %eax
    321d:      	je	0x32b4 <kprobe_unwind_hotspot+0x32b4>
    3223:      	movabsq	$0x2963702820656d61, %rax # imm = 0x2963702820656D61
    322d:      	movq	%rax, 0x60(%rsp)
    3232:      	movabsq	$0x7266206574656c70, %rax # imm = 0x7266206574656C70
    323c:      	movq	%rax, 0x58(%rsp)
    3241:      	movabsq	$0x6d6f636e6920676e, %rax # imm = 0x6D6F636E6920676E
    324b:      	movq	%rax, 0x50(%rsp)
    3250:      	movabsq	$0x69646e69776e7520, %rax # imm = 0x69646E69776E7520
    325a:      	movq	%rax, 0x48(%rsp)
    325f:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    3269:      	movq	%rax, 0x40(%rsp)
    326e:      	movw	$0xa, 0x68(%rsp)
    3275:      	leaq	0x40(%rsp), %rdi
    327a:      	movl	$0x2a, %eax
    327f:      	movl	$0x6, %ecx
    3284:      	movl	$0x2a, %esi
    3289:      	jmp	0x485a <kprobe_unwind_hotspot+0x485a>
    328e:      	movb	$0x1, %al
    3290:      	movl	%eax, 0xb0(%rsp)
    3297:      	movl	$0x62617476, %eax       # imm = 0x62617476
    329c:      	movq	%rax, 0xb8(%rsp)
    32a4:      	movq	(%rip), %rax            # 0x32ab <kprobe_unwind_hotspot+0x32ab>
    32ab:      	cmpl	$0x0, (%rax)
    32ae:      	jne	0x4819 <kprobe_unwind_hotspot+0x4819>
    32b4:      	movl	$0x8, 0xf0(%rsp)
    32bf:      	movl	$0x8, %eax
    32c4:      	jmp	0x37d5 <kprobe_unwind_hotspot+0x37d5>
    32c9:      	movq	(%rip), %rax            # 0x32d0 <kprobe_unwind_hotspot+0x32d0>
    32d0:      	cmpl	$0x0, (%rax)
    32d3:      	jne	0x4863 <kprobe_unwind_hotspot+0x4863>
    32d9:      	movl	0xf0(%rsp), %eax
    32e0:      	movl	$0x0, 0xb0(%rsp)
    32eb:      	movq	0xa8(%rsp), %rcx
    32f3:      	testl	%eax, %eax
    32f5:      	jne	0x37d5 <kprobe_unwind_hotspot+0x37d5>
    32fb:      	jmp	0x37c0 <kprobe_unwind_hotspot+0x37c0>
    3300:      	movl	0xf0(%rsp), %ebx
    3307:      	movq	0xa8(%rsp), %rdx
    330f:      	movq	0x38(%rsp), %rax
    3314:      	leaq	(%rax,%rbx), %rcx
    3318:      	addq	$0x30, %rcx
    331c:      	movq	%rcx, 0x108(%rsp)
    3324:      	subq	%rax, %rdx
    3327:      	jb	0x3ad1 <kprobe_unwind_hotspot+0x3ad1>
    332d:      	movq	0x108(%rsp), %rax
    3335:      	cmpq	%rax, 0xa8(%rsp)
    333d:      	jae	0x3ad1 <kprobe_unwind_hotspot+0x3ad1>
    3343:      	movb	$0x3, %al
    3345:      	movl	%eax, 0xb0(%rsp)
    334c:      	movq	(%rip), %rax            # 0x3353 <kprobe_unwind_hotspot+0x3353>
    3353:      	cmpl	$0x0, (%rax)
    3356:      	jne	0x49b5 <kprobe_unwind_hotspot+0x49b5>
    335c:      	movq	0xa8(%rsp), %rcx
    3364:      	jmp	0x37c0 <kprobe_unwind_hotspot+0x37c0>
    3369:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3373:      	movq	%rax, 0x66(%rsp)
    3378:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    3382:      	movq	%rax, 0x60(%rsp)
    3387:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    3391:      	movq	%rax, 0x58(%rsp)
    3396:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    33a0:      	movq	%rax, 0x50(%rsp)
    33a5:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    33af:      	movq	%rax, 0x48(%rsp)
    33b4:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    33be:      	movq	%rax, 0x40(%rsp)
    33c3:      	leaq	0x40(%rsp), %rdi
    33c8:      	movl	$0x2e, %eax
    33cd:      	movl	$0x6, %ecx
    33d2:      	movl	0xc8(%rsp), %edx
    33d9:      	movl	$0x2e, %esi
    33de:      	xorl	%eax, %eax
    33e0:      	callq	*%rcx
    33e2:      	jmp	0x2d55 <kprobe_unwind_hotspot+0x2d55>
    33e7:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    33f1:      	movq	%rax, 0x55(%rsp)
    33f6:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    3400:      	movq	%rax, 0x50(%rsp)
    3405:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    340f:      	movq	%rax, 0x48(%rsp)
    3414:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    341e:      	movq	%rax, 0x40(%rsp)
    3423:      	leaq	0x40(%rsp), %rdi
    3428:      	movl	$0x1d, %eax
    342d:      	movl	$0x6, %r8d
    3433:      	movzbl	(%rsp), %ecx
    3437:      	movl	$0x1d, %esi
    343c:      	movq	%r13, %rdx
    343f:      	xorl	%eax, %eax
    3441:      	callq	*%r8
    3444:      	movzbl	(%rsp), %eax
    3448:      	leal	0x1(%rax), %ecx
    344b:      	cmpb	$0x2, %cl
    344e:      	jb	0x2ea0 <kprobe_unwind_hotspot+0x2ea0>
    3454:      	movzbl	%al, %eax
    3457:      	subq	%rax, %r13
    345a:      	leaq	(%rbx,%r13), %rdx
    345e:      	movq	%rsp, %rdi
    3461:      	movl	$0x1, %eax
    3466:      	movl	$0x70, %ecx
    346b:      	movl	$0x1, %esi
    3470:      	callq	*%rcx
    3472:      	testq	%rax, %rax
    3475:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    347b:      	movq	(%rip), %rax            # 0x3482 <kprobe_unwind_hotspot+0x3482>
    3482:      	cmpl	$0x0, (%rax)
    3485:      	jne	0x3e34 <kprobe_unwind_hotspot+0x3e34>
    348b:      	movzbl	(%rsp), %eax
    348f:      	leal	0x1(%rax), %ecx
    3492:      	cmpb	$0x2, %cl
    3495:      	jb	0x2ea0 <kprobe_unwind_hotspot+0x2ea0>
    349b:      	movzbl	%al, %eax
    349e:      	subq	%rax, %r13
    34a1:      	leaq	(%rbx,%r13), %rdx
    34a5:      	movq	%rsp, %rdi
    34a8:      	movl	$0x1, %eax
    34ad:      	movl	$0x70, %ecx
    34b2:      	movl	$0x1, %esi
    34b7:      	callq	*%rcx
    34b9:      	testq	%rax, %rax
    34bc:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    34c2:      	movq	(%rip), %rax            # 0x34c9 <kprobe_unwind_hotspot+0x34c9>
    34c9:      	cmpl	$0x0, (%rax)
    34cc:      	jne	0x42f2 <kprobe_unwind_hotspot+0x42f2>
    34d2:      	movzbl	(%rsp), %eax
    34d6:      	leal	0x1(%rax), %ecx
    34d9:      	cmpb	$0x2, %cl
    34dc:      	jb	0x2ea0 <kprobe_unwind_hotspot+0x2ea0>
    34e2:      	movzbl	%al, %eax
    34e5:      	subq	%rax, %r13
    34e8:      	leaq	(%rbx,%r13), %rdx
    34ec:      	movq	%rsp, %rdi
    34ef:      	movl	$0x1, %eax
    34f4:      	movl	$0x70, %ecx
    34f9:      	movl	$0x1, %esi
    34fe:      	callq	*%rcx
    3500:      	testq	%rax, %rax
    3503:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    3509:      	movq	(%rip), %rax            # 0x3510 <kprobe_unwind_hotspot+0x3510>
    3510:      	cmpl	$0x0, (%rax)
    3513:      	jne	0x43f3 <kprobe_unwind_hotspot+0x43f3>
    3519:      	movzbl	(%rsp), %eax
    351d:      	leal	0x1(%rax), %ecx
    3520:      	cmpb	$0x2, %cl
    3523:      	jb	0x2ea0 <kprobe_unwind_hotspot+0x2ea0>
    3529:      	movzbl	%al, %eax
    352c:      	subq	%rax, %r13
    352f:      	leaq	(%rbx,%r13), %rdx
    3533:      	movq	%rsp, %rdi
    3536:      	movl	$0x1, %eax
    353b:      	movl	$0x70, %ecx
    3540:      	movl	$0x1, %esi
    3545:      	callq	*%rcx
    3547:      	testq	%rax, %rax
    354a:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    3550:      	movq	(%rip), %rax            # 0x3557 <kprobe_unwind_hotspot+0x3557>
    3557:      	cmpl	$0x0, (%rax)
    355a:      	jne	0x45db <kprobe_unwind_hotspot+0x45db>
    3560:      	movzbl	(%rsp), %eax
    3564:      	leal	0x1(%rax), %ecx
    3567:      	cmpb	$0x2, %cl
    356a:      	jb	0x2ea0 <kprobe_unwind_hotspot+0x2ea0>
    3570:      	movzbl	%al, %eax
    3573:      	subq	%rax, %r13
    3576:      	leaq	(%rbx,%r13), %rdx
    357a:      	movq	%rsp, %rdi
    357d:      	movl	$0x1, %eax
    3582:      	movl	$0x70, %ecx
    3587:      	movl	$0x1, %esi
    358c:      	callq	*%rcx
    358e:      	testq	%rax, %rax
    3591:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    3597:      	movq	(%rip), %rax            # 0x359e <kprobe_unwind_hotspot+0x359e>
    359e:      	cmpl	$0x0, (%rax)
    35a1:      	jne	0x4b85 <kprobe_unwind_hotspot+0x4b85>
    35a7:      	movzbl	(%rsp), %eax
    35ab:      	leal	0x1(%rax), %ecx
    35ae:      	cmpb	$0x2, %cl
    35b1:      	jb	0x2ea0 <kprobe_unwind_hotspot+0x2ea0>
    35b7:      	movzbl	%al, %eax
    35ba:      	subq	%rax, %r13
    35bd:      	leaq	(%rbx,%r13), %rdx
    35c1:      	movq	%rsp, %rdi
    35c4:      	movl	$0x1, %eax
    35c9:      	movl	$0x70, %ecx
    35ce:      	movl	$0x1, %esi
    35d3:      	callq	*%rcx
    35d5:      	testq	%rax, %rax
    35d8:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    35de:      	movq	(%rip), %rax            # 0x35e5 <kprobe_unwind_hotspot+0x35e5>
    35e5:      	cmpl	$0x0, (%rax)
    35e8:      	jne	0x504f <kprobe_unwind_hotspot+0x504f>
    35ee:      	movzbl	(%rsp), %eax
    35f2:      	leal	0x1(%rax), %ecx
    35f5:      	cmpb	$0x2, %cl
    35f8:      	jb	0x2ea0 <kprobe_unwind_hotspot+0x2ea0>
    35fe:      	movzbl	%al, %eax
    3601:      	subq	%rax, %r13
    3604:      	leaq	(%rbx,%r13), %rdx
    3608:      	movq	%rsp, %rdi
    360b:      	movl	$0x1, %eax
    3610:      	movl	$0x70, %ecx
    3615:      	movl	$0x1, %esi
    361a:      	callq	*%rcx
    361c:      	testq	%rax, %rax
    361f:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    3625:      	movq	(%rip), %rax            # 0x362c <kprobe_unwind_hotspot+0x362c>
    362c:      	cmpl	$0x0, (%rax)
    362f:      	jne	0x6022 <kprobe_unwind_hotspot+0x6022>
    3635:      	movzbl	(%rsp), %eax
    3639:      	leal	0x1(%rax), %ecx
    363c:      	cmpb	$0x2, %cl
    363f:      	jb	0x2ea0 <kprobe_unwind_hotspot+0x2ea0>
    3645:      	movzbl	%al, %eax
    3648:      	subq	%rax, %r13
    364b:      	leaq	(%rbx,%r13), %rdx
    364f:      	movq	%rsp, %rdi
    3652:      	movl	$0x1, %eax
    3657:      	movl	$0x70, %ecx
    365c:      	movl	$0x1, %esi
    3661:      	callq	*%rcx
    3663:      	testq	%rax, %rax
    3666:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    366c:      	movq	(%rip), %rax            # 0x3673 <kprobe_unwind_hotspot+0x3673>
    3673:      	cmpl	$0x0, (%rax)
    3676:      	jne	0x6422 <kprobe_unwind_hotspot+0x6422>
    367c:      	movzbl	(%rsp), %eax
    3680:      	leal	0x1(%rax), %ecx
    3683:      	cmpb	$0x2, %cl
    3686:      	jb	0x2ea0 <kprobe_unwind_hotspot+0x2ea0>
    368c:      	movzbl	%al, %eax
    368f:      	subq	%rax, %r13
    3692:      	leaq	(%rbx,%r13), %rdx
    3696:      	movq	%rsp, %rdi
    3699:      	movl	$0x1, %eax
    369e:      	movl	$0x70, %ecx
    36a3:      	movl	$0x1, %esi
    36a8:      	callq	*%rcx
    36aa:      	testq	%rax, %rax
    36ad:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    36b3:      	movq	(%rip), %rax            # 0x36ba <kprobe_unwind_hotspot+0x36ba>
    36ba:      	cmpl	$0x0, (%rax)
    36bd:      	jne	0x67b9 <kprobe_unwind_hotspot+0x67b9>
    36c3:      	movzbl	(%rsp), %eax
    36c7:      	leal	0x1(%rax), %ecx
    36ca:      	cmpb	$0x2, %cl
    36cd:      	jb	0x2ea0 <kprobe_unwind_hotspot+0x2ea0>
    36d3:      	movzbl	%al, %eax
    36d6:      	subq	%rax, %r13
    36d9:      	leaq	(%rbx,%r13), %rdx
    36dd:      	movq	%rsp, %rdi
    36e0:      	movl	$0x1, %eax
    36e5:      	movl	$0x70, %ecx
    36ea:      	movl	$0x1, %esi
    36ef:      	callq	*%rcx
    36f1:      	testq	%rax, %rax
    36f4:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    36fa:      	movq	(%rip), %rax            # 0x3701 <kprobe_unwind_hotspot+0x3701>
    3701:      	cmpl	$0x0, (%rax)
    3704:      	jne	0x689d <kprobe_unwind_hotspot+0x689d>
    370a:      	movzbl	(%rsp), %eax
    370e:      	leal	0x1(%rax), %ecx
    3711:      	cmpb	$0x2, %cl
    3714:      	jb	0x2ea0 <kprobe_unwind_hotspot+0x2ea0>
    371a:      	movzbl	%al, %eax
    371d:      	subq	%rax, %r13
    3720:      	addq	%r13, %rbx
    3723:      	movq	%rsp, %rdi
    3726:      	movl	$0x1, %eax
    372b:      	movl	$0x70, %ecx
    3730:      	movl	$0x1, %esi
    3735:      	movq	%rbx, %rdx
    3738:      	callq	*%rcx
    373a:      	testq	%rax, %rax
    373d:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    3743:      	movq	(%rip), %rax            # 0x374a <kprobe_unwind_hotspot+0x374a>
    374a:      	cmpl	$0x0, (%rax)
    374d:      	jne	0x690f <kprobe_unwind_hotspot+0x690f>
    3753:      	movzbl	(%rsp), %eax
    3757:      	leal	0x1(%rax), %ecx
    375a:      	cmpb	$0x1, %cl
    375d:      	ja	0x22b <kprobe_unwind_hotspot+0x22b>
    3763:      	jmp	0x2ea0 <kprobe_unwind_hotspot+0x2ea0>
    3768:      	movq	(%rip), %rax            # 0x376f <kprobe_unwind_hotspot+0x376f>
    376f:      	cmpl	$0x0, (%rax)
    3772:      	jne	0x4a34 <kprobe_unwind_hotspot+0x4a34>
    3778:      	movl	$0x2d, 0x114(%rsp)
    3783:      	movq	(%rip), %rdi            # 0x378a <kprobe_unwind_hotspot+0x378a>
    378a:      	leaq	0x114(%rsp), %rsi
    3792:      	movl	$0x1, %eax
    3797:      	callq	*%rax
    3799:      	testq	%rax, %rax
    379c:      	je	0x3ca3 <kprobe_unwind_hotspot+0x3ca3>
    37a2:      	incq	(%rax)
    37a5:      	jmp	0x3cb3 <kprobe_unwind_hotspot+0x3cb3>
    37aa:      	movb	$0x3, %cl
    37ac:      	movl	%ecx, 0xb0(%rsp)
    37b3:      	testl	%eax, %eax
    37b5:      	jne	0x4aa8 <kprobe_unwind_hotspot+0x4aa8>
    37bb:      	movq	0x38(%rsp), %rcx
    37c0:      	movl	$0x10, 0xf0(%rsp)
    37cb:      	movl	$0x10, %eax
    37d0:      	movq	%rcx, 0x38(%rsp)
    37d5:      	movl	%eax, %eax
    37d7:      	addq	%rax, 0x38(%rsp)
    37dc:      	movq	0x38(%rsp), %rax
    37e1:      	leaq	-0x10(%rax), %rdx
    37e5:      	movq	%rsp, %rdi
    37e8:      	movl	$0x10, %eax
    37ed:      	movl	$0x70, %ecx
    37f2:      	movl	$0x10, %esi
    37f7:      	callq	*%rcx
    37f9:      	movq	0x8(%rsp), %r12
    37fe:      	cmpl	$0x10, 0xf0(%rsp)
    3806:      	jb	0x3824 <kprobe_unwind_hotspot+0x3824>
    3808:      	movq	(%rip), %rax            # 0x380f <kprobe_unwind_hotspot+0x380f>
    380f:      	cmpl	$0x0, (%rax)
    3812:      	jne	0x46c0 <kprobe_unwind_hotspot+0x46c0>
    3818:      	movq	(%rsp), %rax
    381c:      	movq	%rax, 0xa8(%rsp)
    3824:      	movl	0x2c0(%r14), %eax
    382b:      	cmpq	$0x7e, %rax
    382f:      	ja	0xf03 <kprobe_unwind_hotspot+0xf03>
    3835:      	movzbl	0xf30(%r14), %ecx
    383d:      	movzbl	0xb0(%rsp), %edx
    3845:      	shlq	$0x3c, %rdx
    3849:      	movq	0x118(%rsp), %rdi
    3851:      	shlq	$0x20, %rdi
    3855:      	movl	0xb8(%rsp), %esi
    385c:      	orq	%rdi, %rsi
    385f:      	orq	%rdx, %rsi
    3862:      	leal	0x1(%rax), %edx
    3865:      	movl	%edx, 0x2c0(%r14)
    386c:      	leaq	(%rax,%rax,2), %rax
    3870:      	movq	0xc0(%rsp), %rdx
    3878:      	movq	%rdx, 0x2d0(%r14,%rax,8)
    3880:      	movq	%rsi, 0x2d8(%r14,%rax,8)
    3888:      	movb	$0x5, 0x2e0(%r14,%rax,8)
    3891:      	movb	%cl, 0x2e1(%r14,%rax,8)
    3899:      	movl	$0x0, 0x2e2(%r14,%rax,8)
    38a5:      	movw	$0x0, 0x2e6(%r14,%rax,8)
    38b0:      	movq	(%rip), %rax            # 0x38b7 <kprobe_unwind_hotspot+0x38b7>
    38b7:      	cmpl	$0x0, (%rax)
    38ba:      	jne	0x464d <kprobe_unwind_hotspot+0x464d>
    38c0:      	movq	%r12, 0xed0(%r14)
    38c7:      	movq	0x38(%rsp), %rax
    38cc:      	movq	%rax, 0xed8(%r14)
    38d3:      	movq	0xa8(%rsp), %rax
    38db:      	movq	%rax, 0xee0(%r14)
    38e2:      	movb	$0x1, 0xf30(%r14)
    38ea:      	movl	$0x2a, (%rsp)
    38f1:      	movq	(%rip), %rdi            # 0x38f8 <kprobe_unwind_hotspot+0x38f8>
    38f8:      	movq	%rsp, %rsi
    38fb:      	movl	$0x1, %eax
    3900:      	callq	*%rax
    3902:      	testq	%rax, %rax
    3905:      	je	0x3915 <kprobe_unwind_hotspot+0x3915>
    3907:      	incq	(%rax)
    390a:      	movq	(%rip), %rax            # 0x3911 <kprobe_unwind_hotspot+0x3911>
    3911:      	movl	(%rax), %eax
    3913:      	jmp	0x3927 <kprobe_unwind_hotspot+0x3927>
    3915:      	xorl	%eax, %eax
    3917:      	movq	(%rip), %rcx            # 0x391e <kprobe_unwind_hotspot+0x391e>
    391e:      	cmpl	$0x0, (%rcx)
    3921:      	jne	0x493b <kprobe_unwind_hotspot+0x493b>
    3927:      	movq	0xed0(%r14), %rbx
    392e:      	testq	%rbx, %rbx
    3931:      	je	0x9ceb <kprobe_unwind_hotspot+0x9ceb>
    3937:      	testl	%eax, %eax
    3939:      	jne	0x470a <kprobe_unwind_hotspot+0x470a>
    393f:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    3949:      	cmpq	%rax, %rbx
    394c:      	ja	0x1049 <kprobe_unwind_hotspot+0x1049>
    3952:      	cmpq	$0x1000, %rbx           # imm = 0x1000
    3959:      	jb	0x1fa2 <kprobe_unwind_hotspot+0x1fa2>
    395f:      	movl	(%r14), %eax
    3962:      	movl	$0x60, 0xc8(%rsp)
    396d:      	movbel	%eax, 0xcc(%rsp)
    3976:      	movbeq	%rbx, 0xd0(%rsp)
    3980:      	movq	(%rip), %rdi            # 0x3987 <kprobe_unwind_hotspot+0x3987>
    3987:      	leaq	0xc8(%rsp), %rsi
    398f:      	movl	$0x1, %eax
    3994:      	callq	*%rax
    3996:      	testq	%rax, %rax
    3999:      	je	0x9d07 <kprobe_unwind_hotspot+0x9d07>
    399f:      	movq	0x8(%rax), %r12
    39a3:      	movq	%r12, %rcx
    39a6:      	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    39b0:      	andq	%rdx, %rcx
    39b3:      	movq	%rcx, 0xf20(%r14)
    39ba:      	movq	(%rax), %rax
    39bd:      	movq	%rax, 0xf10(%r14)
    39c4:      	shrq	$0x38, %r12
    39c8:      	movq	%rbx, %rax
    39cb:      	subq	%rcx, %rax
    39ce:      	movq	%rax, 0xf18(%r14)
    39d5:      	movq	(%rip), %rax            # 0x39dc <kprobe_unwind_hotspot+0x39dc>
    39dc:      	cmpl	$0x0, (%rax)
    39df:      	jne	0x4dba <kprobe_unwind_hotspot+0x4dba>
    39e5:      	cmpl	$0x1, %r12d
    39e9:      	jne	0x5274 <kprobe_unwind_hotspot+0x5274>
    39ef:      	movq	0xf10(%r14), %rax
    39f6:      	movq	%rax, 0xc8(%rsp)
    39fe:      	movq	0xf18(%r14), %r13
    3a05:      	movq	(%rip), %rdi            # 0x3a0c <kprobe_unwind_hotspot+0x3a0c>
    3a0c:      	leaq	0xc8(%rsp), %rsi
    3a14:      	movl	$0x1, %eax
    3a19:      	callq	*%rax
    3a1b:      	movl	$0x1, %r12d
    3a21:      	testq	%rax, %rax
    3a24:      	je	0x5274 <kprobe_unwind_hotspot+0x5274>
    3a2a:      	movq	%rax, %rbx
    3a2d:      	cmpq	%r13, (%rax)
    3a30:      	ja	0x3a38 <kprobe_unwind_hotspot+0x3a38>
    3a32:      	cmpq	%r13, 0x8(%rbx)
    3a36:      	jae	0x3a4c <kprobe_unwind_hotspot+0x3a4c>
    3a38:      	cmpq	%r13, 0x10(%rbx)
    3a3c:      	ja	0x5274 <kprobe_unwind_hotspot+0x5274>
    3a42:      	cmpq	%r13, 0x18(%rbx)
    3a46:      	jb	0x5274 <kprobe_unwind_hotspot+0x5274>
    3a4c:      	movq	(%rip), %rax            # 0x3a53 <kprobe_unwind_hotspot+0x3a53>
    3a53:      	cmpl	$0x0, (%rax)
    3a56:      	jne	0x51d2 <kprobe_unwind_hotspot+0x51d2>
    3a5c:      	movl	0x1380(%r14), %eax
    3a63:      	movl	0x20(%rbx), %ecx
    3a66:      	btl	%ecx, %eax
    3a69:      	jae	0x523d <kprobe_unwind_hotspot+0x523d>
    3a6f:      	movq	(%rip), %rax            # 0x3a76 <kprobe_unwind_hotspot+0x3a76>
    3a76:      	cmpl	$0x0, (%rax)
    3a79:      	je	0x5274 <kprobe_unwind_hotspot+0x5274>
    3a7f:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    3a89:      	movq	%rax, 0x50(%rsp)
    3a8e:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    3a98:      	movq	%rax, 0x48(%rsp)
    3a9d:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    3aa7:      	movq	%rax, 0x40(%rsp)
    3aac:      	movl	$0xa656e, 0x57(%rsp)    # imm = 0xA656E
    3ab4:      	leaq	0x40(%rsp), %rdi
    3ab9:      	movl	$0x1b, %eax
    3abe:      	movl	$0x6, %ecx
    3ac3:      	movl	$0x1b, %esi
    3ac8:      	xorl	%eax, %eax
    3aca:      	callq	*%rcx
    3acc:      	jmp	0x5274 <kprobe_unwind_hotspot+0x5274>
    3ad1:      	movq	0x38(%rsp), %rax
    3ad6:      	leaq	(%rax,%rbx), %rdx
    3ada:      	addq	$-0x8, %rdx
    3ade:      	leaq	0x40(%rsp), %rdi
    3ae3:      	movl	$0x30, %eax
    3ae8:      	movl	$0x70, %ecx
    3aed:      	movl	$0x30, %esi
    3af2:      	callq	*%rcx
    3af4:      	movq	(%rip), %rax            # 0x3afb <kprobe_unwind_hotspot+0x3afb>
    3afb:      	cmpl	$0x0, (%rax)
    3afe:      	jne	0x4b1f <kprobe_unwind_hotspot+0x4b1f>
    3b04:      	movl	(%r14), %eax
    3b07:      	movl	$0x60, (%rsp)
    3b0e:      	movbel	%eax, 0x4(%rsp)
    3b14:      	addq	%rbx, 0x38(%rsp)
    3b19:      	movq	0x40(%rsp), %rax
    3b1e:      	movbeq	%rax, 0x8(%rsp)
    3b25:      	movabsq	$-0x100000000000000, %rbx # imm = 0xFF00000000000000
    3b2f:      	movabsq	$0x200000000000000, %r13 # imm = 0x200000000000000
    3b39:      	movq	(%rip), %rdi            # 0x3b40 <kprobe_unwind_hotspot+0x3b40>
    3b40:      	movq	%rsp, %rsi
    3b43:      	movl	$0x1, %eax
    3b48:      	callq	*%rax
    3b4a:      	testq	%rax, %rax
    3b4d:      	je	0x3cd5 <kprobe_unwind_hotspot+0x3cd5>
    3b53:      	movq	0x8(%rax), %rax
    3b57:      	andq	%rbx, %rax
    3b5a:      	xorl	%edx, %edx
    3b5c:      	cmpq	%r13, %rax
    3b5f:      	jne	0x3cd5 <kprobe_unwind_hotspot+0x3cd5>
    3b65:      	movq	0x38(%rsp), %rax
    3b6a:      	jmp	0x40bd <kprobe_unwind_hotspot+0x40bd>
    3b6f:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3b79:      	movq	%rax, 0x26(%rsp)
    3b7e:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    3b88:      	movq	%rax, 0x20(%rsp)
    3b8d:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    3b97:      	movq	%rax, 0x18(%rsp)
    3b9c:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    3ba6:      	movq	%rax, 0x10(%rsp)
    3bab:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    3bb5:      	movq	%rax, 0x8(%rsp)
    3bba:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3bc4:      	movq	%rax, (%rsp)
    3bc8:      	movq	%rsp, %rdi
    3bcb:      	movl	$0x2e, %eax
    3bd0:      	movl	$0x6, %ecx
    3bd5:      	movl	0x100(%rsp), %edx
    3bdc:      	movl	$0x2e, %esi
    3be1:      	xorl	%eax, %eax
    3be3:      	callq	*%rcx
    3be5:      	jmp	0x1a13 <kprobe_unwind_hotspot+0x1a13>
    3bea:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    3bf4:      	movq	%rax, 0x55(%rsp)
    3bf9:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    3c03:      	movq	%rax, 0x50(%rsp)
    3c08:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    3c12:      	movq	%rax, 0x48(%rsp)
    3c17:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    3c21:      	movq	%rax, 0x40(%rsp)
    3c26:      	leaq	0x40(%rsp), %rdi
    3c2b:      	movl	$0x1d, %eax
    3c30:      	movl	$0x6, %r8d
    3c36:      	movzbl	(%rsp), %ecx
    3c3a:      	movl	$0x1d, %esi
    3c3f:      	movq	%rbx, %rdx
    3c42:      	xorl	%eax, %eax
    3c44:      	callq	*%r8
    3c47:      	movzbl	(%rsp), %eax
    3c4b:      	leal	0x1(%rax), %ecx
    3c4e:      	cmpb	$0x2, %cl
    3c51:      	jb	0x290 <kprobe_unwind_hotspot+0x290>
    3c57:      	jmp	0xca3 <kprobe_unwind_hotspot+0xca3>
    3c5c:      	movq	(%rsp), %rax
    3c60:      	movq	0xd0(%rsp), %rcx
    3c68:      	cmpq	%rcx, %rax
    3c6b:      	jb	0x31d0 <kprobe_unwind_hotspot+0x31d0>
    3c71:      	cmpq	0xd8(%rsp), %rax
    3c79:      	jae	0x31d0 <kprobe_unwind_hotspot+0x31d0>
    3c7f:      	movq	(%rip), %rdx            # 0x3c86 <kprobe_unwind_hotspot+0x3c86>
    3c86:      	cmpl	$0x0, (%rdx)
    3c89:      	jne	0x4ecf <kprobe_unwind_hotspot+0x4ecf>
    3c8f:      	movl	%eax, %edx
    3c91:      	subl	%ecx, %edx
    3c93:      	movq	%rdx, 0x118(%rsp)
    3c9b:      	movq	%rax, %r12
    3c9e:      	jmp	0x31e0 <kprobe_unwind_hotspot+0x31e0>
    3ca3:      	movq	(%rip), %rax            # 0x3caa <kprobe_unwind_hotspot+0x3caa>
    3caa:      	cmpl	$0x0, (%rax)
    3cad:      	jne	0x4c6d <kprobe_unwind_hotspot+0x4c6d>
    3cb3:      	movl	$0x3e9, %ebx            # imm = 0x3E9
    3cb8:      	xorl	%r13d, %r13d
    3cbb:      	movl	$0x65746e49, %eax       # imm = 0x65746E49
    3cc0:      	movq	%rax, 0xb8(%rsp)
    3cc8:      	testl	%ebx, %ebx
    3cca:      	jne	0x347 <kprobe_unwind_hotspot+0x347>
    3cd0:      	jmp	0x40fb <kprobe_unwind_hotspot+0x40fb>
    3cd5:      	movq	(%rip), %rax            # 0x3cdc <kprobe_unwind_hotspot+0x3cdc>
    3cdc:      	cmpl	$0x0, (%rax)
    3cdf:      	jne	0x4ce8 <kprobe_unwind_hotspot+0x4ce8>
    3ce5:      	movl	(%r14), %eax
    3ce8:      	movl	$0x60, (%rsp)
    3cef:      	movbel	%eax, 0x4(%rsp)
    3cf5:      	movq	0x48(%rsp), %rax
    3cfa:      	movbeq	%rax, 0x8(%rsp)
    3d01:      	movq	(%rip), %rdi            # 0x3d08 <kprobe_unwind_hotspot+0x3d08>
    3d08:      	movq	%rsp, %rsi
    3d0b:      	movl	$0x1, %eax
    3d10:      	callq	*%rax
    3d12:      	testq	%rax, %rax
    3d15:      	je	0x3d36 <kprobe_unwind_hotspot+0x3d36>
    3d17:      	movq	0x8(%rax), %rax
    3d1b:      	andq	%rbx, %rax
    3d1e:      	cmpq	%r13, %rax
    3d21:      	jne	0x3d36 <kprobe_unwind_hotspot+0x3d36>
    3d23:      	movq	0x38(%rsp), %rax
    3d28:      	addq	$0x8, %rax
    3d2c:      	movl	$0x1, %edx
    3d31:      	jmp	0x40bd <kprobe_unwind_hotspot+0x40bd>
    3d36:      	movq	(%rip), %rax            # 0x3d3d <kprobe_unwind_hotspot+0x3d3d>
    3d3d:      	cmpl	$0x0, (%rax)
    3d40:      	jne	0x4d51 <kprobe_unwind_hotspot+0x4d51>
    3d46:      	movl	(%r14), %eax
    3d49:      	movl	$0x60, (%rsp)
    3d50:      	movbel	%eax, 0x4(%rsp)
    3d56:      	movq	0x50(%rsp), %rax
    3d5b:      	movbeq	%rax, 0x8(%rsp)
    3d62:      	movq	(%rip), %rdi            # 0x3d69 <kprobe_unwind_hotspot+0x3d69>
    3d69:      	movq	%rsp, %rsi
    3d6c:      	movl	$0x1, %eax
    3d71:      	callq	*%rax
    3d73:      	testq	%rax, %rax
    3d76:      	je	0x3ea6 <kprobe_unwind_hotspot+0x3ea6>
    3d7c:      	movq	0x8(%rax), %rax
    3d80:      	andq	%rbx, %rax
    3d83:      	cmpq	%r13, %rax
    3d86:      	jne	0x3ea6 <kprobe_unwind_hotspot+0x3ea6>
    3d8c:      	movq	0x38(%rsp), %rax
    3d91:      	addq	$0x10, %rax
    3d95:      	movl	$0x2, %edx
    3d9a:      	jmp	0x40bd <kprobe_unwind_hotspot+0x40bd>
    3d9f:      	movabsq	$0xa786c2520626f6c, %rax # imm = 0xA786C2520626F6C
    3da9:      	movq	%rax, 0x58(%rsp)
    3dae:      	movabsq	$0x6265646f63206f74, %rax # imm = 0x6265646F63206F74
    3db8:      	movq	%rax, 0x50(%rsp)
    3dbd:      	movabsq	$0x2064657070616d20, %rax # imm = 0x2064657070616D20
    3dc7:      	movq	%rax, 0x48(%rsp)
    3dcc:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    3dd6:      	movq	%rax, 0x40(%rsp)
    3ddb:      	movb	$0x0, 0x60(%rsp)
    3de0:      	leaq	0x40(%rsp), %rdi
    3de5:      	movl	$0x21, %eax
    3dea:      	movl	$0x6, %ecx
    3def:      	movl	$0x21, %esi
    3df4:      	movq	%rbx, %rdx
    3df7:      	xorl	%eax, %eax
    3df9:      	callq	*%rcx
    3dfb:      	movq	%rbx, 0xc8(%rsp)
    3e03:      	testq	%rbx, %rbx
    3e06:      	jne	0x2ee2 <kprobe_unwind_hotspot+0x2ee2>
    3e0c:      	jmp	0x237 <kprobe_unwind_hotspot+0x237>
    3e11:      	cmpl	$0x0, 0x2c0(%r14)
    3e19:      	je	0x4151 <kprobe_unwind_hotspot+0x4151>
    3e1f:      	cmpb	$0x0, 0x1f(%r15)
    3e24:      	je	0x418c <kprobe_unwind_hotspot+0x418c>
    3e2a:      	movq	0x50(%rsp), %r13
    3e2f:      	jmp	0x4191 <kprobe_unwind_hotspot+0x4191>
    3e34:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    3e3e:      	movq	%rax, 0x55(%rsp)
    3e43:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    3e4d:      	movq	%rax, 0x50(%rsp)
    3e52:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    3e5c:      	movq	%rax, 0x48(%rsp)
    3e61:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    3e6b:      	movq	%rax, 0x40(%rsp)
    3e70:      	leaq	0x40(%rsp), %rdi
    3e75:      	movl	$0x1d, %eax
    3e7a:      	movl	$0x6, %r8d
    3e80:      	movzbl	(%rsp), %ecx
    3e84:      	movl	$0x1d, %esi
    3e89:      	movq	%r13, %rdx
    3e8c:      	xorl	%eax, %eax
    3e8e:      	callq	*%r8
    3e91:      	movzbl	(%rsp), %eax
    3e95:      	leal	0x1(%rax), %ecx
    3e98:      	cmpb	$0x2, %cl
    3e9b:      	jb	0x2ea0 <kprobe_unwind_hotspot+0x2ea0>
    3ea1:      	jmp	0x349b <kprobe_unwind_hotspot+0x349b>
    3ea6:      	movq	(%rip), %rax            # 0x3ead <kprobe_unwind_hotspot+0x3ead>
    3ead:      	cmpl	$0x0, (%rax)
    3eb0:      	jne	0x4f7d <kprobe_unwind_hotspot+0x4f7d>
    3eb6:      	movl	(%r14), %eax
    3eb9:      	movl	$0x60, (%rsp)
    3ec0:      	movbel	%eax, 0x4(%rsp)
    3ec6:      	movq	0x58(%rsp), %rax
    3ecb:      	movbeq	%rax, 0x8(%rsp)
    3ed2:      	movq	(%rip), %rdi            # 0x3ed9 <kprobe_unwind_hotspot+0x3ed9>
    3ed9:      	movq	%rsp, %rsi
    3edc:      	movl	$0x1, %eax
    3ee1:      	callq	*%rax
    3ee3:      	testq	%rax, %rax
    3ee6:      	je	0x3f07 <kprobe_unwind_hotspot+0x3f07>
    3ee8:      	movq	0x8(%rax), %rax
    3eec:      	andq	%rbx, %rax
    3eef:      	cmpq	%r13, %rax
    3ef2:      	jne	0x3f07 <kprobe_unwind_hotspot+0x3f07>
    3ef4:      	movq	0x38(%rsp), %rax
    3ef9:      	addq	$0x18, %rax
    3efd:      	movl	$0x3, %edx
    3f02:      	jmp	0x40bd <kprobe_unwind_hotspot+0x40bd>
    3f07:      	movq	(%rip), %rax            # 0x3f0e <kprobe_unwind_hotspot+0x3f0e>
    3f0e:      	cmpl	$0x0, (%rax)
    3f11:      	jne	0x4fe6 <kprobe_unwind_hotspot+0x4fe6>
    3f17:      	movl	(%r14), %eax
    3f1a:      	movl	$0x60, (%rsp)
    3f21:      	movbel	%eax, 0x4(%rsp)
    3f27:      	movq	0x60(%rsp), %rax
    3f2c:      	movbeq	%rax, 0x8(%rsp)
    3f33:      	movq	(%rip), %rdi            # 0x3f3a <kprobe_unwind_hotspot+0x3f3a>
    3f3a:      	movq	%rsp, %rsi
    3f3d:      	movl	$0x1, %eax
    3f42:      	callq	*%rax
    3f44:      	testq	%rax, %rax
    3f47:      	je	0x405c <kprobe_unwind_hotspot+0x405c>
    3f4d:      	movq	0x8(%rax), %rax
    3f51:      	andq	%rbx, %rax
    3f54:      	cmpq	%r13, %rax
    3f57:      	jne	0x405c <kprobe_unwind_hotspot+0x405c>
    3f5d:      	movq	0x38(%rsp), %rax
    3f62:      	addq	$0x20, %rax
    3f66:      	movl	$0x4, %edx
    3f6b:      	jmp	0x40bd <kprobe_unwind_hotspot+0x40bd>
    3f70:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3f7a:      	movq	%rax, 0x66(%rsp)
    3f7f:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    3f89:      	movq	%rax, 0x60(%rsp)
    3f8e:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    3f98:      	movq	%rax, 0x58(%rsp)
    3f9d:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    3fa7:      	movq	%rax, 0x50(%rsp)
    3fac:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    3fb6:      	movq	%rax, 0x48(%rsp)
    3fbb:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3fc5:      	movq	%rax, 0x40(%rsp)
    3fca:      	leaq	0x40(%rsp), %rdi
    3fcf:      	movl	$0x2e, %eax
    3fd4:      	movl	$0x6, %ecx
    3fd9:      	movl	(%rsp), %edx
    3fdc:      	movl	$0x2e, %esi
    3fe1:      	xorl	%eax, %eax
    3fe3:      	callq	*%rcx
    3fe5:      	jmp	0x2d17 <kprobe_unwind_hotspot+0x2d17>
    3fea:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    3ff4:      	movq	%rax, 0x55(%rsp)
    3ff9:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    4003:      	movq	%rax, 0x50(%rsp)
    4008:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    4012:      	movq	%rax, 0x48(%rsp)
    4017:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    4021:      	movq	%rax, 0x40(%rsp)
    4026:      	leaq	0x40(%rsp), %rdi
    402b:      	movl	$0x1d, %eax
    4030:      	movl	$0x6, %r8d
    4036:      	movzbl	(%rsp), %ecx
    403a:      	movl	$0x1d, %esi
    403f:      	movq	%rbx, %rdx
    4042:      	xorl	%eax, %eax
    4044:      	callq	*%r8
    4047:      	movzbl	(%rsp), %eax
    404b:      	leal	0x1(%rax), %ecx
    404e:      	cmpb	$0x2, %cl
    4051:      	jb	0x290 <kprobe_unwind_hotspot+0x290>
    4057:      	jmp	0xcea <kprobe_unwind_hotspot+0xcea>
    405c:      	movq	(%rip), %rax            # 0x4063 <kprobe_unwind_hotspot+0x4063>
    4063:      	cmpl	$0x0, (%rax)
    4066:      	jne	0x50c1 <kprobe_unwind_hotspot+0x50c1>
    406c:      	movl	(%r14), %eax
    406f:      	movl	$0x60, (%rsp)
    4076:      	movbel	%eax, 0x4(%rsp)
    407c:      	movq	0x68(%rsp), %rax
    4081:      	movbeq	%rax, 0x8(%rsp)
    4088:      	movq	(%rip), %rdi            # 0x408f <kprobe_unwind_hotspot+0x408f>
    408f:      	movq	%rsp, %rsi
    4092:      	movl	$0x1, %eax
    4097:      	callq	*%rax
    4099:      	testq	%rax, %rax
    409c:      	je	0x415a <kprobe_unwind_hotspot+0x415a>
    40a2:      	andq	0x8(%rax), %rbx
    40a6:      	cmpq	%r13, %rbx
    40a9:      	jne	0x415a <kprobe_unwind_hotspot+0x415a>
    40af:      	movq	0x38(%rsp), %rax
    40b4:      	addq	$0x28, %rax
    40b8:      	movl	$0x5, %edx
    40bd:      	movq	%rax, 0x108(%rsp)
    40c5:      	xorl	%ebx, %ebx
    40c7:      	movl	$0x5, %r13d
    40cd:      	movq	(%rip), %rax            # 0x40d4 <kprobe_unwind_hotspot+0x40d4>
    40d4:      	cmpl	$0x0, (%rax)
    40d7:      	jne	0x4bf7 <kprobe_unwind_hotspot+0x4bf7>
    40dd:      	movb	$0x3, %al
    40df:      	movl	%eax, 0xb0(%rsp)
    40e6:      	movq	0x108(%rsp), %rax
    40ee:      	movq	%rax, 0x38(%rsp)
    40f3:      	testl	%ebx, %ebx
    40f5:      	jne	0x347 <kprobe_unwind_hotspot+0x347>
    40fb:      	cmpl	$0x2, %r13d
    40ff:      	jle	0x411d <kprobe_unwind_hotspot+0x411d>
    4101:      	cmpl	$0x4, %r13d
    4105:      	jg	0x4142 <kprobe_unwind_hotspot+0x4142>
    4107:      	cmpl	$0x3, %r13d
    410b:      	je	0x37bb <kprobe_unwind_hotspot+0x37bb>
    4111:      	movl	0xf0(%rsp), %eax
    4118:      	jmp	0x37d5 <kprobe_unwind_hotspot+0x37d5>
    411d:      	movl	$0x1, %ebx
    4122:      	testl	%r13d, %r13d
    4125:      	je	0x347 <kprobe_unwind_hotspot+0x347>
    412b:      	movq	0xa8(%rsp), %rcx
    4133:      	cmpl	$0x1, %r13d
    4137:      	je	0x32b4 <kprobe_unwind_hotspot+0x32b4>
    413d:      	jmp	0x37c0 <kprobe_unwind_hotspot+0x37c0>
    4142:      	cmpl	$0x5, %r13d
    4146:      	je	0x37dc <kprobe_unwind_hotspot+0x37dc>
    414c:      	jmp	0x3824 <kprobe_unwind_hotspot+0x3824>
    4151:      	movq	0xf00(%r14), %r13
    4158:      	jmp	0x4191 <kprobe_unwind_hotspot+0x4191>
    415a:      	movl	$0x2e, 0x100(%rsp)
    4165:      	movq	(%rip), %rdi            # 0x416c <kprobe_unwind_hotspot+0x416c>
    416c:      	leaq	0x100(%rsp), %rsi
    4174:      	movl	$0x1, %eax
    4179:      	callq	*%rax
    417b:      	testq	%rax, %rax
    417e:      	je	0x4364 <kprobe_unwind_hotspot+0x4364>
    4184:      	incq	(%rax)
    4187:      	jmp	0x4374 <kprobe_unwind_hotspot+0x4374>
    418c:      	movq	0x58(%rsp), %r13
    4191:      	movq	0x78(%rsp), %rsi
    4196:      	movq	0x88(%rsp), %rax
    419e:      	movq	%rax, 0x38(%rsp)
    41a3:      	movq	0x90(%rsp), %rax
    41ab:      	movq	%rax, 0xa8(%rsp)
    41b3:      	movq	0x98(%rsp), %r12
    41bb:      	movzbl	0x1c(%r15), %eax
    41c0:      	addq	%rsi, %rax
    41c3:      	leaq	0x100(%rsp), %rdi
    41cb:      	movl	$0x8, %ecx
    41d0:      	movl	$0x70, %r8d
    41d6:      	movzbl	0x1c(%r15), %edx
    41db:      	movq	%rsi, 0x108(%rsp)
    41e3:      	addq	%rsi, %rdx
    41e6:      	movl	$0x8, %esi
    41eb:      	callq	*%r8
    41ee:      	testq	%rax, %rax
    41f1:      	je	0x4269 <kprobe_unwind_hotspot+0x4269>
    41f3:      	movq	(%rip), %rax            # 0x41fa <kprobe_unwind_hotspot+0x41fa>
    41fa:      	cmpl	$0x0, (%rax)
    41fd:      	je	0x3778 <kprobe_unwind_hotspot+0x3778>
    4203:      	movabsq	$0xa646f6874656d63, %rax # imm = 0xA646F6874656D63
    420d:      	movq	%rax, 0x20(%rsp)
    4212:      	movabsq	$0x2072657465727072, %rax # imm = 0x2072657465727072
    421c:      	movq	%rax, 0x18(%rsp)
    4221:      	movabsq	$0x65746e6920646165, %rax # imm = 0x65746E6920646165
    422b:      	movq	%rax, 0x10(%rsp)
    4230:      	movabsq	$0x72206f742064656c, %rax # imm = 0x72206F742064656C
    423a:      	movq	%rax, 0x8(%rsp)
    423f:      	movabsq	$0x696166203a6d766a, %rax # imm = 0x696166203A6D766A
    4249:      	movq	%rax, (%rsp)
    424d:      	movb	$0x0, 0x28(%rsp)
    4252:      	movq	%rsp, %rdi
    4255:      	movl	$0x29, %eax
    425a:      	movl	$0x6, %ecx
    425f:      	movl	$0x29, %esi
    4264:      	jmp	0x4a9f <kprobe_unwind_hotspot+0x4a9f>
    4269:      	movq	0x100(%rsp), %rdx
    4271:      	movzbl	0x1d(%r15), %eax
    4276:      	movq	%rdx, %rcx
    4279:      	movq	%rdx, 0xb8(%rsp)
    4281:      	addq	%rdx, %rax
    4284:      	xorl	%ebx, %ebx
    4286:      	cmpq	%rax, %r13
    4289:      	movl	$0x0, %ecx
    428e:      	cmovaeq	%rax, %rcx
    4292:      	subq	%rcx, %r13
    4295:      	movq	(%rip), %rax            # 0x429c <kprobe_unwind_hotspot+0x429c>
    429c:      	cmpl	$0x0, (%rax)
    429f:      	jne	0x512a <kprobe_unwind_hotspot+0x512a>
    42a5:      	cmpq	$0xffff, %r13           # imm = 0xFFFF
    42ac:      	movl	$0xffff, %eax           # imm = 0xFFFF
    42b1:      	cmovbq	%r13, %rax
    42b5:      	movq	%rax, 0x118(%rsp)
    42bd:      	shrq	$0x3, 0xb8(%rsp)
    42c6:      	movl	$0x6, %r13d
    42cc:      	movb	$0x2, %al
    42ce:      	movl	%eax, 0xb0(%rsp)
    42d5:      	movq	0x108(%rsp), %rax
    42dd:      	movq	%rax, 0xc0(%rsp)
    42e5:      	testl	%ebx, %ebx
    42e7:      	jne	0x347 <kprobe_unwind_hotspot+0x347>
    42ed:      	jmp	0x40fb <kprobe_unwind_hotspot+0x40fb>
    42f2:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    42fc:      	movq	%rax, 0x55(%rsp)
    4301:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    430b:      	movq	%rax, 0x50(%rsp)
    4310:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    431a:      	movq	%rax, 0x48(%rsp)
    431f:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    4329:      	movq	%rax, 0x40(%rsp)
    432e:      	leaq	0x40(%rsp), %rdi
    4333:      	movl	$0x1d, %eax
    4338:      	movl	$0x6, %r8d
    433e:      	movzbl	(%rsp), %ecx
    4342:      	movl	$0x1d, %esi
    4347:      	movq	%r13, %rdx
    434a:      	xorl	%eax, %eax
    434c:      	callq	*%r8
    434f:      	movzbl	(%rsp), %eax
    4353:      	leal	0x1(%rax), %ecx
    4356:      	cmpb	$0x2, %cl
    4359:      	jb	0x2ea0 <kprobe_unwind_hotspot+0x2ea0>
    435f:      	jmp	0x34e2 <kprobe_unwind_hotspot+0x34e2>
    4364:      	movq	(%rip), %rax            # 0x436b <kprobe_unwind_hotspot+0x436b>
    436b:      	cmpl	$0x0, (%rax)
    436e:      	jne	0x5ba0 <kprobe_unwind_hotspot+0x5ba0>
    4374:      	movl	$0x3ea, %ebx            # imm = 0x3EA
    4379:      	xorl	%r13d, %r13d
    437c:      	jmp	0x40dd <kprobe_unwind_hotspot+0x40dd>
    4381:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    438b:      	movq	%rax, 0x55(%rsp)
    4390:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    439a:      	movq	%rax, 0x50(%rsp)
    439f:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    43a9:      	movq	%rax, 0x48(%rsp)
    43ae:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    43b8:      	movq	%rax, 0x40(%rsp)
    43bd:      	leaq	0x40(%rsp), %rdi
    43c2:      	movl	$0x1d, %eax
    43c7:      	movl	$0x6, %r8d
    43cd:      	movzbl	(%rsp), %ecx
    43d1:      	movl	$0x1d, %esi
    43d6:      	movq	%rbx, %rdx
    43d9:      	xorl	%eax, %eax
    43db:      	callq	*%r8
    43de:      	movzbl	(%rsp), %eax
    43e2:      	leal	0x1(%rax), %ecx
    43e5:      	cmpb	$0x2, %cl
    43e8:      	jb	0x290 <kprobe_unwind_hotspot+0x290>
    43ee:      	jmp	0xd31 <kprobe_unwind_hotspot+0xd31>
    43f3:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    43fd:      	movq	%rax, 0x55(%rsp)
    4402:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    440c:      	movq	%rax, 0x50(%rsp)
    4411:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    441b:      	movq	%rax, 0x48(%rsp)
    4420:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    442a:      	movq	%rax, 0x40(%rsp)
    442f:      	leaq	0x40(%rsp), %rdi
    4434:      	movl	$0x1d, %eax
    4439:      	movl	$0x6, %r8d
    443f:      	movzbl	(%rsp), %ecx
    4443:      	movl	$0x1d, %esi
    4448:      	movq	%r13, %rdx
    444b:      	xorl	%eax, %eax
    444d:      	callq	*%r8
    4450:      	movzbl	(%rsp), %eax
    4454:      	leal	0x1(%rax), %ecx
    4457:      	cmpb	$0x2, %cl
    445a:      	jb	0x2ea0 <kprobe_unwind_hotspot+0x2ea0>
    4460:      	jmp	0x3529 <kprobe_unwind_hotspot+0x3529>
    4465:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    446f:      	movq	%rax, 0x55(%rsp)
    4474:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    447e:      	movq	%rax, 0x50(%rsp)
    4483:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    448d:      	movq	%rax, 0x48(%rsp)
    4492:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    449c:      	movq	%rax, 0x40(%rsp)
    44a1:      	leaq	0x40(%rsp), %rdi
    44a6:      	movl	$0x1d, %eax
    44ab:      	movl	$0x6, %r8d
    44b1:      	movzbl	(%rsp), %ecx
    44b5:      	movl	$0x1d, %esi
    44ba:      	movq	%rbx, %rdx
    44bd:      	xorl	%eax, %eax
    44bf:      	callq	*%r8
    44c2:      	movzbl	(%rsp), %eax
    44c6:      	leal	0x1(%rax), %ecx
    44c9:      	cmpb	$0x2, %cl
    44cc:      	jb	0x290 <kprobe_unwind_hotspot+0x290>
    44d2:      	jmp	0xd78 <kprobe_unwind_hotspot+0xd78>
    44d7:      	movabsq	$0xa786c252d786c, %rax  # imm = 0xA786C252D786C
    44e1:      	movq	%rax, 0x4f(%rsp)
    44e6:      	movabsq	$0x6c252065646f6320, %rax # imm = 0x6C252065646F6320
    44f0:      	movq	%rax, 0x48(%rsp)
    44f5:      	movabsq	$0x3e2d20203a6d766a, %rbx # imm = 0x3E2D20203A6D766A
    44ff:      	movq	%rbx, 0x40(%rsp)
    4504:      	leaq	0x40(%rsp), %rdi
    4509:      	movl	$0x17, %eax
    450e:      	movl	$0x6, %r8d
    4514:      	movq	0xd0(%rsp), %rdx
    451c:      	movq	0xd8(%rsp), %rcx
    4524:      	movl	$0x17, %esi
    4529:      	xorl	%eax, %eax
    452b:      	callq	*%r8
    452e:      	movq	(%rip), %rax            # 0x4535 <kprobe_unwind_hotspot+0x4535>
    4535:      	cmpl	$0x0, (%rax)
    4538:      	je	0x3021 <kprobe_unwind_hotspot+0x3021>
    453e:      	movabsq	$0x783020657079745f, %rax # imm = 0x783020657079745F
    4548:      	movq	%rax, 0x70(%rsp)
    454d:      	movabsq	$0x656d617266202c75, %rax # imm = 0x656D617266202C75
    4557:      	movq	%rax, 0x68(%rsp)
    455c:      	movabsq	$0x2520657a69735f65, %rax # imm = 0x2520657A69735F65
    4566:      	movq	%rax, 0x60(%rsp)
    456b:      	movabsq	$0x6d617266202c7525, %rax # imm = 0x6D617266202C7525
    4575:      	movq	%rax, 0x58(%rsp)
    457a:      	movabsq	$0x206574656c706d6f, %rax # imm = 0x206574656C706D6F
    4584:      	movq	%rax, 0x50(%rsp)
    4589:      	movabsq	$0x635f656d61726620, %rax # imm = 0x635F656D61726620
    4593:      	movq	%rax, 0x48(%rsp)
    4598:      	movq	%rbx, 0x40(%rsp)
    459d:      	movl	$0xa7825, 0x78(%rsp)    # imm = 0xA7825
    45a5:      	leaq	0x40(%rsp), %rdi
    45aa:      	movl	$0x3c, %eax
    45af:      	movl	$0x6, %r9d
    45b5:      	movzwl	0xf8(%rsp), %edx
    45bd:      	movl	0xe8(%rsp), %r8d
    45c5:      	movl	0xf0(%rsp), %ecx
    45cc:      	movl	$0x3c, %esi
    45d1:      	xorl	%eax, %eax
    45d3:      	callq	*%r9
    45d6:      	jmp	0x3021 <kprobe_unwind_hotspot+0x3021>
    45db:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    45e5:      	movq	%rax, 0x55(%rsp)
    45ea:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    45f4:      	movq	%rax, 0x50(%rsp)
    45f9:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    4603:      	movq	%rax, 0x48(%rsp)
    4608:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    4612:      	movq	%rax, 0x40(%rsp)
    4617:      	leaq	0x40(%rsp), %rdi
    461c:      	movl	$0x1d, %eax
    4621:      	movl	$0x6, %r8d
    4627:      	movzbl	(%rsp), %ecx
    462b:      	movl	$0x1d, %esi
    4630:      	movq	%r13, %rdx
    4633:      	xorl	%eax, %eax
    4635:      	callq	*%r8
    4638:      	movzbl	(%rsp), %eax
    463c:      	leal	0x1(%rax), %ecx
    463f:      	cmpb	$0x2, %cl
    4642:      	jb	0x2ea0 <kprobe_unwind_hotspot+0x2ea0>
    4648:      	jmp	0x3570 <kprobe_unwind_hotspot+0x3570>
    464d:      	movabsq	$0x25203a7066202c78, %rax # imm = 0x25203A7066202C78
    4657:      	movq	%rax, 0x58(%rsp)
    465c:      	movabsq	$0x6c25203a7073202c, %rax # imm = 0x6C25203A7073202C
    4666:      	movq	%rax, 0x50(%rsp)
    466b:      	movabsq	$0x786c25203a637020, %rax # imm = 0x786C25203A637020
    4675:      	movq	%rax, 0x48(%rsp)
    467a:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    4684:      	movq	%rax, 0x40(%rsp)
    4689:      	movl	$0xa786c, 0x60(%rsp)    # imm = 0xA786C
    4691:      	leaq	0x40(%rsp), %rdi
    4696:      	movl	$0x24, %eax
    469b:      	movl	$0x6, %r9d
    46a1:      	movl	$0x24, %esi
    46a6:      	movq	%r12, %rdx
    46a9:      	movq	0x38(%rsp), %rcx
    46ae:      	movq	0xa8(%rsp), %r8
    46b6:      	xorl	%eax, %eax
    46b8:      	callq	*%r9
    46bb:      	jmp	0x38c0 <kprobe_unwind_hotspot+0x38c0>
    46c0:      	movabsq	$0xa706620726576, %rax  # imm = 0xA706620726576
    46ca:      	movq	%rax, 0x4d(%rsp)
    46cf:      	movabsq	$0x7265766f63657220, %rax # imm = 0x7265766F63657220
    46d9:      	movq	%rax, 0x48(%rsp)
    46de:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    46e8:      	movq	%rax, 0x40(%rsp)
    46ed:      	leaq	0x40(%rsp), %rdi
    46f2:      	movl	$0x15, %eax
    46f7:      	movl	$0x6, %ecx
    46fc:      	movl	$0x15, %esi
    4701:      	xorl	%eax, %eax
    4703:      	callq	*%rcx
    4705:      	jmp	0x3818 <kprobe_unwind_hotspot+0x3818>
    470a:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    4714:      	movq	%rax, 0x68(%rsp)
    4719:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    4723:      	movq	%rax, 0x60(%rsp)
    4728:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    4732:      	movq	%rax, 0x58(%rsp)
    4737:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    4741:      	movq	%rax, 0x50(%rsp)
    4746:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    4750:      	movq	%rax, 0x48(%rsp)
    4755:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    475f:      	movq	%rax, 0x40(%rsp)
    4764:      	movb	$0x0, 0x70(%rsp)
    4769:      	leaq	0x40(%rsp), %rdi
    476e:      	movl	$0x31, %eax
    4773:      	movl	$0x6, %ecx
    4778:      	movl	0x2c0(%r14), %edx
    477f:      	movl	$0x31, %esi
    4784:      	xorl	%eax, %eax
    4786:      	callq	*%rcx
    4788:      	movq	0xed0(%r14), %rbx
    478f:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    4799:      	cmpq	%rax, %rbx
    479c:      	ja	0x1049 <kprobe_unwind_hotspot+0x1049>
    47a2:      	jmp	0x3952 <kprobe_unwind_hotspot+0x3952>
    47a7:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    47b1:      	movq	%rax, 0x55(%rsp)
    47b6:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    47c0:      	movq	%rax, 0x50(%rsp)
    47c5:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    47cf:      	movq	%rax, 0x48(%rsp)
    47d4:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    47de:      	movq	%rax, 0x40(%rsp)
    47e3:      	leaq	0x40(%rsp), %rdi
    47e8:      	movl	$0x1d, %eax
    47ed:      	movl	$0x6, %r8d
    47f3:      	movzbl	(%rsp), %ecx
    47f7:      	movl	$0x1d, %esi
    47fc:      	movq	%rbx, %rdx
    47ff:      	xorl	%eax, %eax
    4801:      	callq	*%r8
    4804:      	movzbl	(%rsp), %eax
    4808:      	leal	0x1(%rax), %ecx
    480b:      	cmpb	$0x1, %cl
    480e:      	ja	0x22b <kprobe_unwind_hotspot+0x22b>
    4814:      	jmp	0x290 <kprobe_unwind_hotspot+0x290>
    4819:      	movabsq	$0xa656c62617476, %rax  # imm = 0xA656C62617476
    4823:      	movq	%rax, 0x50(%rsp)
    4828:      	movabsq	$0x20646e69776e7520, %rax # imm = 0x20646E69776E7520
    4832:      	movq	%rax, 0x48(%rsp)
    4837:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    4841:      	movq	%rax, 0x40(%rsp)
    4846:      	leaq	0x40(%rsp), %rdi
    484b:      	movl	$0x18, %eax
    4850:      	movl	$0x6, %ecx
    4855:      	movl	$0x18, %esi
    485a:      	xorl	%eax, %eax
    485c:      	callq	*%rcx
    485e:      	jmp	0x32b4 <kprobe_unwind_hotspot+0x32b4>
    4863:      	movabsq	$0x6170206b6361626c, %rax # imm = 0x6170206B6361626C
    486d:      	movq	%rax, 0x58(%rsp)
    4872:      	movabsq	$0x6c61662062757473, %rax # imm = 0x6C61662062757473
    487c:      	movq	%rax, 0x50(%rsp)
    4881:      	movabsq	$0x20646e69776e7520, %rax # imm = 0x20646E69776E7520
    488b:      	movq	%rax, 0x48(%rsp)
    4890:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    489a:      	movq	%rax, 0x40(%rsp)
    489f:      	movl	$0xa6874, 0x60(%rsp)    # imm = 0xA6874
    48a7:      	leaq	0x40(%rsp), %rdi
    48ac:      	movl	$0x24, %eax
    48b1:      	movl	$0x6, %ecx
    48b6:      	movl	$0x24, %esi
    48bb:      	xorl	%eax, %eax
    48bd:      	callq	*%rcx
    48bf:      	jmp	0x32d9 <kprobe_unwind_hotspot+0x32d9>
    48c4:      	movabsq	$0xa64656c696166, %rax  # imm = 0xA64656C696166
    48ce:      	movq	%rax, 0x68(%rsp)
    48d3:      	movabsq	$0x20797265766f6365, %rax # imm = 0x20797265766F6365
    48dd:      	movq	%rax, 0x60(%rsp)
    48e2:      	movabsq	$0x72206370202c656d, %rax # imm = 0x72206370202C656D
    48ec:      	movq	%rax, 0x58(%rsp)
    48f1:      	movabsq	$0x6172662064657a69, %rax # imm = 0x6172662064657A69
    48fb:      	movq	%rax, 0x50(%rsp)
    4900:      	movabsq	$0x6d6974706f656420, %rax # imm = 0x6D6974706F656420
    490a:      	movq	%rax, 0x48(%rsp)
    490f:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    4919:      	movq	%rax, 0x40(%rsp)
    491e:      	leaq	0x40(%rsp), %rdi
    4923:      	movl	$0x30, %eax
    4928:      	movl	$0x6, %ecx
    492d:      	movl	$0x30, %esi
    4932:      	xorl	%eax, %eax
    4934:      	callq	*%rcx
    4936:      	jmp	0x31e0 <kprobe_unwind_hotspot+0x31e0>
    493b:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4945:      	movq	%rax, 0x66(%rsp)
    494a:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4954:      	movq	%rax, 0x60(%rsp)
    4959:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4963:      	movq	%rax, 0x58(%rsp)
    4968:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4972:      	movq	%rax, 0x50(%rsp)
    4977:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4981:      	movq	%rax, 0x48(%rsp)
    4986:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4990:      	movq	%rax, 0x40(%rsp)
    4995:      	leaq	0x40(%rsp), %rdi
    499a:      	movl	$0x2e, %eax
    499f:      	movl	$0x6, %ecx
    49a4:      	movl	(%rsp), %edx
    49a7:      	movl	$0x2e, %esi
    49ac:      	xorl	%eax, %eax
    49ae:      	callq	*%rcx
    49b0:      	jmp	0x390a <kprobe_unwind_hotspot+0x390a>
    49b5:      	movabsq	$0xa29646c252065, %rax  # imm = 0xA29646C252065
    49bf:      	movq	%rax, 0x67(%rsp)
    49c4:      	movabsq	$0x657a697320656d61, %rax # imm = 0x657A697320656D61
    49ce:      	movq	%rax, 0x60(%rsp)
    49d3:      	movabsq	$0x726628207265746e, %rax # imm = 0x726628207265746E
    49dd:      	movq	%rax, 0x58(%rsp)
    49e2:      	movabsq	$0x696f7020656d6172, %rax # imm = 0x696F7020656D6172
    49ec:      	movq	%rax, 0x50(%rsp)
    49f1:      	movabsq	$0x6620676e69737520, %rax # imm = 0x6620676E69737520
    49fb:      	movq	%rax, 0x48(%rsp)
    4a00:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    4a0a:      	movq	%rax, 0x40(%rsp)
    4a0f:      	leaq	0x40(%rsp), %rdi
    4a14:      	movl	$0x2f, %eax
    4a19:      	movl	$0x6, %ecx
    4a1e:      	movl	$0x2f, %esi
    4a23:      	xorl	%eax, %eax
    4a25:      	callq	*%rcx
    4a27:      	movq	0xa8(%rsp), %rcx
    4a2f:      	jmp	0x37c0 <kprobe_unwind_hotspot+0x37c0>
    4a34:      	movabsq	$0xa656d61726620, %rax  # imm = 0xA656D61726620
    4a3e:      	movq	%rax, 0x26(%rsp)
    4a43:      	movabsq	$0x6620726574657270, %rax # imm = 0x6620726574657270
    4a4d:      	movq	%rax, 0x20(%rsp)
    4a52:      	movabsq	$0x7265746e69206562, %rax # imm = 0x7265746E69206562
    4a5c:      	movq	%rax, 0x18(%rsp)
    4a61:      	movabsq	$0x206f742079617761, %rax # imm = 0x206F742079617761
    4a6b:      	movq	%rax, 0x10(%rsp)
    4a70:      	movabsq	$0x20726166206f6f74, %rax # imm = 0x20726166206F6F74
    4a7a:      	movq	%rax, 0x8(%rsp)
    4a7f:      	movabsq	$0x207066203a6d766a, %rax # imm = 0x207066203A6D766A
    4a89:      	movq	%rax, (%rsp)
    4a8d:      	movq	%rsp, %rdi
    4a90:      	movl	$0x2e, %eax
    4a95:      	movl	$0x6, %ecx
    4a9a:      	movl	$0x2e, %esi
    4a9f:      	xorl	%eax, %eax
    4aa1:      	callq	*%rcx
    4aa3:      	jmp	0x3778 <kprobe_unwind_hotspot+0x3778>
    4aa8:      	movabsq	$0xa2963702b7066, %rax  # imm = 0xA2963702B7066
    4ab2:      	movq	%rax, 0x65(%rsp)
    4ab7:      	movabsq	$0x2b70662820656d61, %rax # imm = 0x2B70662820656D61
    4ac1:      	movq	%rax, 0x60(%rsp)
    4ac6:      	movabsq	$0x7266206574656c70, %rax # imm = 0x7266206574656C70
    4ad0:      	movq	%rax, 0x58(%rsp)
    4ad5:      	movabsq	$0x6d6f636e6920676e, %rax # imm = 0x6D6F636E6920676E
    4adf:      	movq	%rax, 0x50(%rsp)
    4ae4:      	movabsq	$0x69646e69776e7520, %rax # imm = 0x69646E69776E7520
    4aee:      	movq	%rax, 0x48(%rsp)
    4af3:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    4afd:      	movq	%rax, 0x40(%rsp)
    4b02:      	leaq	0x40(%rsp), %rdi
    4b07:      	movl	$0x2d, %eax
    4b0c:      	movl	$0x6, %ecx
    4b11:      	movl	$0x2d, %esi
    4b16:      	xorl	%eax, %eax
    4b18:      	callq	*%rcx
    4b1a:      	jmp	0x37bb <kprobe_unwind_hotspot+0x37bb>
    4b1f:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    4b29:      	movq	%rax, 0x18(%rsp)
    4b2e:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    4b38:      	movq	%rax, 0x10(%rsp)
    4b3d:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    4b47:      	movq	%rax, 0x8(%rsp)
    4b4c:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    4b56:      	movq	%rax, (%rsp)
    4b5a:      	movw	$0xa, 0x20(%rsp)
    4b61:      	movq	%rsp, %rdi
    4b64:      	movl	$0x22, %eax
    4b69:      	movl	$0x6, %r8d
    4b6f:      	movq	0x40(%rsp), %rcx
    4b74:      	movl	$0x22, %esi
    4b79:      	xorl	%edx, %edx
    4b7b:      	xorl	%eax, %eax
    4b7d:      	callq	*%r8
    4b80:      	jmp	0x3b04 <kprobe_unwind_hotspot+0x3b04>
    4b85:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    4b8f:      	movq	%rax, 0x55(%rsp)
    4b94:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    4b9e:      	movq	%rax, 0x50(%rsp)
    4ba3:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    4bad:      	movq	%rax, 0x48(%rsp)
    4bb2:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    4bbc:      	movq	%rax, 0x40(%rsp)
    4bc1:      	leaq	0x40(%rsp), %rdi
    4bc6:      	movl	$0x1d, %eax
    4bcb:      	movl	$0x6, %r8d
    4bd1:      	movzbl	(%rsp), %ecx
    4bd5:      	movl	$0x1d, %esi
    4bda:      	movq	%r13, %rdx
    4bdd:      	xorl	%eax, %eax
    4bdf:      	callq	*%r8
    4be2:      	movzbl	(%rsp), %eax
    4be6:      	leal	0x1(%rax), %ecx
    4be9:      	cmpb	$0x2, %cl
    4bec:      	jb	0x2ea0 <kprobe_unwind_hotspot+0x2ea0>
    4bf2:      	jmp	0x35b7 <kprobe_unwind_hotspot+0x35b7>
    4bf7:      	movabsq	$0xa7364726f7720, %rax  # imm = 0xA7364726F7720
    4c01:      	movq	%rax, 0x26(%rsp)
    4c06:      	movabsq	$0x77206425202b2065, %rax # imm = 0x77206425202B2065
    4c10:      	movq	%rax, 0x20(%rsp)
    4c15:      	movabsq	$0x6d61726620657465, %rax # imm = 0x6D61726620657465
    4c1f:      	movq	%rax, 0x18(%rsp)
    4c24:      	movabsq	$0x6c706d6f6320676e, %rax # imm = 0x6C706D6F6320676E
    4c2e:      	movq	%rax, 0x10(%rsp)
    4c33:      	movabsq	$0x69646e69776e7520, %rax # imm = 0x69646E69776E7520
    4c3d:      	movq	%rax, 0x8(%rsp)
    4c42:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    4c4c:      	movq	%rax, (%rsp)
    4c50:      	movq	%rsp, %rdi
    4c53:      	movl	$0x2e, %eax
    4c58:      	movl	$0x6, %ecx
    4c5d:      	xorl	%ebx, %ebx
    4c5f:      	movl	$0x2e, %esi
    4c64:      	xorl	%eax, %eax
    4c66:      	callq	*%rcx
    4c68:      	jmp	0x40dd <kprobe_unwind_hotspot+0x40dd>
    4c6d:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4c77:      	movq	%rax, 0x26(%rsp)
    4c7c:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4c86:      	movq	%rax, 0x20(%rsp)
    4c8b:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4c95:      	movq	%rax, 0x18(%rsp)
    4c9a:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4ca4:      	movq	%rax, 0x10(%rsp)
    4ca9:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4cb3:      	movq	%rax, 0x8(%rsp)
    4cb8:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4cc2:      	movq	%rax, (%rsp)
    4cc6:      	movq	%rsp, %rdi
    4cc9:      	movl	$0x2e, %eax
    4cce:      	movl	$0x6, %ecx
    4cd3:      	movl	0x114(%rsp), %edx
    4cda:      	movl	$0x2e, %esi
    4cdf:      	xorl	%eax, %eax
    4ce1:      	callq	*%rcx
    4ce3:      	jmp	0x3cb3 <kprobe_unwind_hotspot+0x3cb3>
    4ce8:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    4cf2:      	movq	%rax, 0x18(%rsp)
    4cf7:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    4d01:      	movq	%rax, 0x10(%rsp)
    4d06:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    4d10:      	movq	%rax, 0x8(%rsp)
    4d15:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    4d1f:      	movq	%rax, (%rsp)
    4d23:      	movw	$0xa, 0x20(%rsp)
    4d2a:      	movq	%rsp, %rdi
    4d2d:      	movl	$0x22, %eax
    4d32:      	movl	$0x6, %r8d
    4d38:      	movq	0x48(%rsp), %rcx
    4d3d:      	movl	$0x22, %esi
    4d42:      	movl	$0x1, %edx
    4d47:      	xorl	%eax, %eax
    4d49:      	callq	*%r8
    4d4c:      	jmp	0x3ce5 <kprobe_unwind_hotspot+0x3ce5>
    4d51:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    4d5b:      	movq	%rax, 0x18(%rsp)
    4d60:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    4d6a:      	movq	%rax, 0x10(%rsp)
    4d6f:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    4d79:      	movq	%rax, 0x8(%rsp)
    4d7e:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    4d88:      	movq	%rax, (%rsp)
    4d8c:      	movw	$0xa, 0x20(%rsp)
    4d93:      	movq	%rsp, %rdi
    4d96:      	movl	$0x22, %eax
    4d9b:      	movl	$0x6, %r8d
    4da1:      	movq	0x50(%rsp), %rcx
    4da6:      	movl	$0x22, %esi
    4dab:      	movl	$0x2, %edx
    4db0:      	xorl	%eax, %eax
    4db2:      	callq	*%r8
    4db5:      	jmp	0x3d46 <kprobe_unwind_hotspot+0x3d46>
    4dba:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    4dc4:      	movq	%rax, 0x68(%rsp)
    4dc9:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    4dd3:      	movq	%rax, 0x60(%rsp)
    4dd8:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    4de2:      	movq	%rax, 0x58(%rsp)
    4de7:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    4df1:      	movq	%rax, 0x50(%rsp)
    4df6:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    4e00:      	movq	%rax, 0x48(%rsp)
    4e05:      	movabsq	$0x6365732074786554, %r13 # imm = 0x6365732074786554
    4e0f:      	movq	%r13, 0x40(%rsp)
    4e14:      	movw	$0xa, 0x70(%rsp)
    4e1b:      	leaq	0x40(%rsp), %rdi
    4e20:      	movl	$0x32, %eax
    4e25:      	movl	$0x6, %r9d
    4e2b:      	movq	0xf10(%r14), %rcx
    4e32:      	movl	$0x32, %esi
    4e37:      	movq	%rbx, %rdx
    4e3a:      	movl	%r12d, %r8d
    4e3d:      	xorl	%eax, %eax
    4e3f:      	callq	*%r9
    4e42:      	movq	(%rip), %rax            # 0x4e49 <kprobe_unwind_hotspot+0x4e49>
    4e49:      	cmpl	$0x0, (%rax)
    4e4c:      	je	0x39e5 <kprobe_unwind_hotspot+0x39e5>
    4e52:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    4e5c:      	movq	%rax, 0x67(%rsp)
    4e61:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    4e6b:      	movq	%rax, 0x60(%rsp)
    4e70:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    4e7a:      	movq	%rax, 0x58(%rsp)
    4e7f:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    4e89:      	movq	%rax, 0x50(%rsp)
    4e8e:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    4e98:      	movq	%rax, 0x48(%rsp)
    4e9d:      	movq	%r13, 0x40(%rsp)
    4ea2:      	leaq	0x40(%rsp), %rdi
    4ea7:      	movl	$0x2f, %eax
    4eac:      	movl	$0x6, %r8d
    4eb2:      	movq	0xf18(%r14), %rcx
    4eb9:      	movq	0xf20(%r14), %rdx
    4ec0:      	movl	$0x2f, %esi
    4ec5:      	xorl	%eax, %eax
    4ec7:      	callq	*%r8
    4eca:      	jmp	0x39e5 <kprobe_unwind_hotspot+0x39e5>
    4ecf:      	movabsq	$0xa2964252b7073, %rax  # imm = 0xA2964252B7073
    4ed9:      	movq	%rax, 0x78(%rsp)
    4ede:      	movabsq	$0x206d6f7266282078, %rax # imm = 0x206D6F7266282078
    4ee8:      	movq	%rax, 0x70(%rsp)
    4eed:      	movabsq	$0x6c25783020736120, %rax # imm = 0x6C25783020736120
    4ef7:      	movq	%rax, 0x68(%rsp)
    4efc:      	movabsq	$0x64657265766f6365, %rax # imm = 0x64657265766F6365
    4f06:      	movq	%rax, 0x60(%rsp)
    4f0b:      	movabsq	$0x72206370202c656d, %rax # imm = 0x72206370202C656D
    4f15:      	movq	%rax, 0x58(%rsp)
    4f1a:      	movabsq	$0x6172662064657a69, %rax # imm = 0x6172662064657A69
    4f24:      	movq	%rax, 0x50(%rsp)
    4f29:      	movabsq	$0x6d6974706f656420, %rax # imm = 0x6D6974706F656420
    4f33:      	movq	%rax, 0x48(%rsp)
    4f38:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    4f42:      	movq	%rax, 0x40(%rsp)
    4f47:      	leaq	0x40(%rsp), %rdi
    4f4c:      	movl	$0x40, %eax
    4f51:      	movl	$0x6, %r8d
    4f57:      	movq	(%rsp), %rdx
    4f5b:      	movl	0xec(%rsp), %ecx
    4f62:      	movl	$0x40, %esi
    4f67:      	xorl	%eax, %eax
    4f69:      	callq	*%r8
    4f6c:      	movq	(%rsp), %rax
    4f70:      	movq	0xd0(%rsp), %rcx
    4f78:      	jmp	0x3c8f <kprobe_unwind_hotspot+0x3c8f>
    4f7d:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    4f87:      	movq	%rax, 0x18(%rsp)
    4f8c:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    4f96:      	movq	%rax, 0x10(%rsp)
    4f9b:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    4fa5:      	movq	%rax, 0x8(%rsp)
    4faa:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    4fb4:      	movq	%rax, (%rsp)
    4fb8:      	movw	$0xa, 0x20(%rsp)
    4fbf:      	movq	%rsp, %rdi
    4fc2:      	movl	$0x22, %eax
    4fc7:      	movl	$0x6, %r8d
    4fcd:      	movq	0x58(%rsp), %rcx
    4fd2:      	movl	$0x22, %esi
    4fd7:      	movl	$0x3, %edx
    4fdc:      	xorl	%eax, %eax
    4fde:      	callq	*%r8
    4fe1:      	jmp	0x3eb6 <kprobe_unwind_hotspot+0x3eb6>
    4fe6:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    4ff0:      	movq	%rax, 0x18(%rsp)
    4ff5:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    4fff:      	movq	%rax, 0x10(%rsp)
    5004:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    500e:      	movq	%rax, 0x8(%rsp)
    5013:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    501d:      	movq	%rax, (%rsp)
    5021:      	movw	$0xa, 0x20(%rsp)
    5028:      	movq	%rsp, %rdi
    502b:      	movl	$0x22, %eax
    5030:      	movl	$0x6, %r8d
    5036:      	movq	0x60(%rsp), %rcx
    503b:      	movl	$0x22, %esi
    5040:      	movl	$0x4, %edx
    5045:      	xorl	%eax, %eax
    5047:      	callq	*%r8
    504a:      	jmp	0x3f17 <kprobe_unwind_hotspot+0x3f17>
    504f:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    5059:      	movq	%rax, 0x55(%rsp)
    505e:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    5068:      	movq	%rax, 0x50(%rsp)
    506d:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    5077:      	movq	%rax, 0x48(%rsp)
    507c:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    5086:      	movq	%rax, 0x40(%rsp)
    508b:      	leaq	0x40(%rsp), %rdi
    5090:      	movl	$0x1d, %eax
    5095:      	movl	$0x6, %r8d
    509b:      	movzbl	(%rsp), %ecx
    509f:      	movl	$0x1d, %esi
    50a4:      	movq	%r13, %rdx
    50a7:      	xorl	%eax, %eax
    50a9:      	callq	*%r8
    50ac:      	movzbl	(%rsp), %eax
    50b0:      	leal	0x1(%rax), %ecx
    50b3:      	cmpb	$0x2, %cl
    50b6:      	jb	0x2ea0 <kprobe_unwind_hotspot+0x2ea0>
    50bc:      	jmp	0x35fe <kprobe_unwind_hotspot+0x35fe>
    50c1:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    50cb:      	movq	%rax, 0x18(%rsp)
    50d0:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    50da:      	movq	%rax, 0x10(%rsp)
    50df:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    50e9:      	movq	%rax, 0x8(%rsp)
    50ee:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    50f8:      	movq	%rax, (%rsp)
    50fc:      	movw	$0xa, 0x20(%rsp)
    5103:      	movq	%rsp, %rdi
    5106:      	movl	$0x22, %eax
    510b:      	movl	$0x6, %r8d
    5111:      	movq	0x68(%rsp), %rcx
    5116:      	movl	$0x22, %esi
    511b:      	movl	$0x5, %edx
    5120:      	xorl	%eax, %eax
    5122:      	callq	*%r8
    5125:      	jmp	0x406c <kprobe_unwind_hotspot+0x406c>
    512a:      	movabsq	$0xa786c25203d20, %rax  # imm = 0xA786C25203D20
    5134:      	movq	%rax, 0x2d(%rsp)
    5139:      	movabsq	$0x203d20706362202c, %rax # imm = 0x203D20706362202C
    5143:      	movq	%rax, 0x28(%rsp)
    5148:      	movabsq	$0x786c257830203d20, %rax # imm = 0x786C257830203D20
    5152:      	movq	%rax, 0x20(%rsp)
    5157:      	movabsq	$0x646f6874656d6320, %rax # imm = 0x646F6874656D6320
    5161:      	movq	%rax, 0x18(%rsp)
    5166:      	movabsq	$0x2c786c257830203d, %rax # imm = 0x2C786C257830203D
    5170:      	movq	%rax, 0x10(%rsp)
    5175:      	movabsq	$0x20646f6874656d20, %rax # imm = 0x20646F6874656D20
    517f:      	movq	%rax, 0x8(%rsp)
    5184:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    518e:      	movq	%rax, (%rsp)
    5192:      	movq	%rsp, %rdi
    5195:      	movl	$0x35, %eax
    519a:      	movl	$0x6, %r9d
    51a0:      	movq	0x100(%rsp), %rcx
    51a8:      	movl	$0x35, %esi
    51ad:      	movq	0x108(%rsp), %rdx
    51b5:      	movq	%r13, %r8
    51b8:      	xorl	%eax, %eax
    51ba:      	callq	*%r9
    51bd:      	movq	0x100(%rsp), %rax
    51c5:      	movq	%rax, 0xb8(%rsp)
    51cd:      	jmp	0x42a5 <kprobe_unwind_hotspot+0x42a5>
    51d2:      	movabsq	$0xa642520686374, %rax  # imm = 0xA642520686374
    51dc:      	movq	%rax, 0x56(%rsp)
    51e1:      	movabsq	$0x6374616d20737465, %rax # imm = 0x6374616D20737465
    51eb:      	movq	%rax, 0x50(%rsp)
    51f0:      	movabsq	$0x7366666f5f726574, %rax # imm = 0x7366666F5F726574
    51fa:      	movq	%rax, 0x48(%rsp)
    51ff:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    5209:      	movq	%rax, 0x40(%rsp)
    520e:      	leaq	0x40(%rsp), %rdi
    5213:      	movl	$0x1e, %eax
    5218:      	movl	$0x6, %ecx
    521d:      	movzwl	0x20(%rbx), %edx
    5221:      	movl	$0x1e, %esi
    5226:      	xorl	%eax, %eax
    5228:      	callq	*%rcx
    522a:      	movl	0x1380(%r14), %eax
    5231:      	movl	0x20(%rbx), %ecx
    5234:      	btl	%ecx, %eax
    5237:      	jb	0x3a6f <kprobe_unwind_hotspot+0x3a6f>
    523d:      	movl	$0x0, (%rsp)
    5244:      	movq	(%rip), %rdi            # 0x524b <kprobe_unwind_hotspot+0x524b>
    524b:      	movq	%rsp, %rsi
    524e:      	movl	$0x1, %eax
    5253:      	callq	*%rax
    5255:      	testq	%rax, %rax
    5258:      	je	0x525f <kprobe_unwind_hotspot+0x525f>
    525a:      	incq	(%rax)
    525d:      	jmp	0x526f <kprobe_unwind_hotspot+0x526f>
    525f:      	movq	(%rip), %rax            # 0x5266 <kprobe_unwind_hotspot+0x5266>
    5266:      	cmpl	$0x0, (%rax)
    5269:      	jne	0x63a8 <kprobe_unwind_hotspot+0x63a8>
    526f:      	movzwl	0x20(%rbx), %r12d
    5274:      	cmpl	$0x2, %r12d
    5278:      	jne	0x34c <kprobe_unwind_hotspot+0x34c>
    527e:      	movl	$0x29, 0xc8(%rsp)
    5289:      	movq	(%rip), %rdi            # 0x5290 <kprobe_unwind_hotspot+0x5290>
    5290:      	leaq	0xc8(%rsp), %rsi
    5298:      	movl	$0x1, %eax
    529d:      	callq	*%rax
    529f:      	testq	%rax, %rax
    52a2:      	je	0x5361 <kprobe_unwind_hotspot+0x5361>
    52a8:      	incq	(%rax)
    52ab:      	movq	(%rip), %rax            # 0x52b2 <kprobe_unwind_hotspot+0x52b2>
    52b2:      	cmpl	$0x0, (%rax)
    52b5:      	movq	0xed0(%r14), %r12
    52bc:      	movq	0xed8(%r14), %rax
    52c3:      	movq	%rax, 0x38(%rsp)
    52c8:      	movq	0xee0(%r14), %rax
    52cf:      	movq	%rax, 0xa8(%rsp)
    52d7:      	je	0x5393 <kprobe_unwind_hotspot+0x5393>
    52dd:      	movabsq	$0x252074657366666f, %rax # imm = 0x252074657366666F
    52e7:      	movq	%rax, 0x60(%rsp)
    52ec:      	movabsq	$0x202c786c25207472, %rax # imm = 0x202C786C25207472
    52f6:      	movq	%rax, 0x58(%rsp)
    52fb:      	movabsq	$0x6174732065646f63, %rax # imm = 0x6174732065646F63
    5305:      	movq	%rax, 0x50(%rsp)
    530a:      	movabsq	$0x206e6920786c2520, %rax # imm = 0x206E6920786C2520
    5314:      	movq	%rax, 0x48(%rsp)
    5319:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    5323:      	movq	%rax, 0x40(%rsp)
    5328:      	movl	$0xa786c, 0x68(%rsp)    # imm = 0xA786C
    5330:      	leaq	0x40(%rsp), %rdi
    5335:      	movl	$0x2c, %eax
    533a:      	movl	$0x6, %r9d
    5340:      	movq	0xf20(%r14), %rcx
    5347:      	movq	0xed0(%r14), %rdx
    534e:      	movq	0xf18(%r14), %r8
    5355:      	movl	$0x2c, %esi
    535a:      	xorl	%eax, %eax
    535c:      	callq	*%r9
    535f:      	jmp	0x5393 <kprobe_unwind_hotspot+0x5393>
    5361:      	movq	(%rip), %rax            # 0x5368 <kprobe_unwind_hotspot+0x5368>
    5368:      	cmpl	$0x0, (%rax)
    536b:      	jne	0x58bf <kprobe_unwind_hotspot+0x58bf>
    5371:      	movq	0xed0(%r14), %r12
    5378:      	movq	0xed8(%r14), %rax
    537f:      	movq	%rax, 0x38(%rsp)
    5384:      	movq	0xee0(%r14), %rax
    538b:      	movq	%rax, 0xa8(%rsp)
    5393:      	movzbl	0x20(%r15), %eax
    5398:      	shrxq	%rax, 0xf18(%r14), %r13
    53a1:      	movq	0xf10(%r14), %rbx
    53a8:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    53b2:      	andq	%rax, %rbx
    53b5:      	leaq	(%rbx,%r13), %rdx
    53b9:      	movq	%rsp, %rdi
    53bc:      	movl	$0x1, %eax
    53c1:      	movl	$0x70, %ecx
    53c6:      	movl	$0x1, %esi
    53cb:      	callq	*%rcx
    53cd:      	testq	%rax, %rax
    53d0:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    53d6:      	movq	(%rip), %rax            # 0x53dd <kprobe_unwind_hotspot+0x53dd>
    53dd:      	cmpl	$0x0, (%rax)
    53e0:      	jne	0x593d <kprobe_unwind_hotspot+0x593d>
    53e6:      	movzbl	(%rsp), %eax
    53ea:      	leal	0x1(%rax), %ecx
    53ed:      	cmpb	$0x2, %cl
    53f0:      	jae	0x59aa <kprobe_unwind_hotspot+0x59aa>
    53f6:      	testb	%al, %al
    53f8:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    53fe:      	movzbl	0x20(%r15), %eax
    5403:      	shlxq	%rax, %r13, %rax
    5408:      	addq	0xf20(%r14), %rax
    540f:      	movzbl	0x1b(%r15), %ebx
    5414:      	addq	%rax, %rbx
    5417:      	movq	(%rip), %rax            # 0x541e <kprobe_unwind_hotspot+0x541e>
    541e:      	cmpl	$0x0, (%rax)
    5421:      	jne	0x61d7 <kprobe_unwind_hotspot+0x61d7>
    5427:      	movq	%rbx, 0xc8(%rsp)
    542f:      	testq	%rbx, %rbx
    5432:      	je	0x237 <kprobe_unwind_hotspot+0x237>
    5438:      	movl	$0x200, %eax            # imm = 0x200
    543d:      	movl	$0x70, %ecx
    5442:      	movq	0x120(%rsp), %rdi
    544a:      	movq	0xc8(%rsp), %rdx
    5452:      	movl	$0x200, %esi            # imm = 0x200
    5457:      	callq	*%rcx
    5459:      	testq	%rax, %rax
    545c:      	jne	0x300 <kprobe_unwind_hotspot+0x300>
    5462:      	movzwl	0x10(%r15), %eax
    5467:      	movl	$0x1, %ebx
    546c:      	cmpq	$0x1f8, %rax            # imm = 0x1F8
    5472:      	ja	0x347 <kprobe_unwind_hotspot+0x347>
    5478:      	movzwl	0x12(%r15), %ecx
    547d:      	cmpq	$0x1fc, %rcx            # imm = 0x1FC
    5484:      	ja	0x347 <kprobe_unwind_hotspot+0x347>
    548a:      	movzwl	0x14(%r15), %edx
    548f:      	cmpq	$0x1f8, %rdx            # imm = 0x1F8
    5496:      	ja	0x347 <kprobe_unwind_hotspot+0x347>
    549c:      	movzbl	0x17(%r15), %esi
    54a1:      	movq	0x120(%rsp), %rdi
    54a9:      	movq	(%rdi,%rsi), %rsi
    54ad:      	movq	%rsi, 0xd0(%rsp)
    54b5:      	movzbl	0x18(%r15), %esi
    54ba:      	movq	(%rdi,%rsi), %rsi
    54be:      	movq	%rsi, 0xd8(%rsp)
    54c6:      	movzbl	0x1a(%r15), %esi
    54cb:      	movl	(%rdi,%rsi), %esi
    54ce:      	shll	$0x3, %esi
    54d1:      	movl	%esi, 0xf0(%rsp)
    54d8:      	movzbl	0x19(%r15), %esi
    54dd:      	movzwl	(%rdi,%rsi), %esi
    54e1:      	movw	%si, 0xf8(%rsp)
    54e9:      	movl	(%rdi,%rcx), %ecx
    54ec:      	movl	%ecx, 0xf4(%rsp)
    54f3:      	movl	(%rdi,%rdx), %ecx
    54f6:      	movl	%ecx, 0xec(%rsp)
    54fd:      	movq	(%rdi,%rax), %rax
    5501:      	movq	%rax, 0xe0(%rsp)
    5509:      	movzbl	0x16(%r15), %eax
    550e:      	movq	(%rdi,%rax), %rdx
    5512:      	movl	$0x4, %eax
    5517:      	movl	$0x70, %ecx
    551c:      	leaq	0xe8(%rsp), %rdi
    5524:      	movl	$0x4, %esi
    5529:      	callq	*%rcx
    552b:      	testq	%rax, %rax
    552e:      	jne	0x300 <kprobe_unwind_hotspot+0x300>
    5534:      	cmpb	$0x0, 0x21(%r15)
    5539:      	je	0x5567 <kprobe_unwind_hotspot+0x5567>
    553b:      	movq	0xc8(%rsp), %rax
    5543:      	movl	0xd0(%rsp), %ecx
    554a:      	addq	%rax, %rcx
    554d:      	movq	%rcx, 0xd0(%rsp)
    5555:      	movl	0xd8(%rsp), %ecx
    555c:      	addq	%rax, %rcx
    555f:      	movq	%rcx, 0xd8(%rsp)
    5567:      	movq	(%rip), %rax            # 0x556e <kprobe_unwind_hotspot+0x556e>
    556e:      	cmpl	$0x0, (%rax)
    5571:      	jne	0x6981 <kprobe_unwind_hotspot+0x6981>
    5577:      	movq	0xc8(%rsp), %rax
    557f:      	movq	%rax, 0xc0(%rsp)
    5587:      	movq	0xd0(%rsp), %rax
    558f:      	movl	0xe8(%rsp), %edx
    5596:      	movl	%r12d, %ecx
    5599:      	subl	%eax, %ecx
    559b:      	movq	%rcx, 0x118(%rsp)
    55a3:      	movq	%rdx, 0xb8(%rsp)
    55ab:      	cmpl	$0x6974616d, %edx       # imm = 0x6974616D
    55b1:      	jg	0x56a1 <kprobe_unwind_hotspot+0x56a1>
    55b7:      	cmpl	$0x62617476, 0xb8(%rsp) # imm = 0x62617476
    55c2:      	je	0x57e4 <kprobe_unwind_hotspot+0x57e4>
    55c8:      	cmpl	$0x65746e49, 0xb8(%rsp) # imm = 0x65746E49
    55d3:      	jne	0x581f <kprobe_unwind_hotspot+0x581f>
    55d9:      	movq	0x38(%rsp), %rax
    55de:      	cmpq	%rax, 0xa8(%rsp)
    55e6:      	jb	0x5c1b <kprobe_unwind_hotspot+0x5c1b>
    55ec:      	movq	0x38(%rsp), %rax
    55f1:      	addq	$0x1000, %rax           # imm = 0x1000
    55f7:      	cmpq	%rax, 0xa8(%rsp)
    55ff:      	jae	0x5c1b <kprobe_unwind_hotspot+0x5c1b>
    5605:      	movq	0xa8(%rsp), %rax
    560d:      	leaq	-0x50(%rax), %rdx
    5611:      	leaq	0x40(%rsp), %rdi
    5616:      	movl	$0x60, %eax
    561b:      	movl	$0x70, %ecx
    5620:      	movl	$0x60, %esi
    5625:      	callq	*%rcx
    5627:      	testq	%rax, %rax
    562a:      	je	0x6249 <kprobe_unwind_hotspot+0x6249>
    5630:      	movq	(%rip), %rax            # 0x5637 <kprobe_unwind_hotspot+0x5637>
    5637:      	cmpl	$0x0, (%rax)
    563a:      	je	0x5c2b <kprobe_unwind_hotspot+0x5c2b>
    5640:      	movabsq	$0xa656d61726620, %rax  # imm = 0xA656D61726620
    564a:      	movq	%rax, 0x1f(%rsp)
    564f:      	movabsq	$0x2072657465727072, %rax # imm = 0x2072657465727072
    5659:      	movq	%rax, 0x18(%rsp)
    565e:      	movabsq	$0x65746e6920646165, %rax # imm = 0x65746E6920646165
    5668:      	movq	%rax, 0x10(%rsp)
    566d:      	movabsq	$0x72206f742064656c, %rax # imm = 0x72206F742064656C
    5677:      	movq	%rax, 0x8(%rsp)
    567c:      	movabsq	$0x696166203a6d766a, %rax # imm = 0x696166203A6D766A
    5686:      	movq	%rax, (%rsp)
    568a:      	movq	%rsp, %rdi
    568d:      	movl	$0x27, %eax
    5692:      	movl	$0x6, %ecx
    5697:      	movl	$0x27, %esi
    569c:      	jmp	0x70db <kprobe_unwind_hotspot+0x70db>
    56a1:      	cmpl	$0x6974616e, 0xb8(%rsp) # imm = 0x6974616E
    56ac:      	je	0x56bf <kprobe_unwind_hotspot+0x56bf>
    56ae:      	cmpl	$0x74656d6e, 0xb8(%rsp) # imm = 0x74656D6E
    56b9:      	jne	0x581f <kprobe_unwind_hotspot+0x581f>
    56bf:      	movl	0xf4(%rsp), %ecx
    56c6:      	movq	%rcx, 0xb8(%rsp)
    56ce:      	movq	0xe0(%rsp), %rcx
    56d6:      	movl	%ecx, %edx
    56d8:      	addq	0xc0(%rsp), %rdx
    56e0:      	cmpb	$0x0, 0x21(%r15)
    56e5:      	cmoveq	%rcx, %rdx
    56e9:      	cmpq	%rdx, %r12
    56ec:      	jne	0x573e <kprobe_unwind_hotspot+0x573e>
    56ee:      	movl	0xec(%rsp), %eax
    56f5:      	movq	0x38(%rsp), %rsi
    56fa:      	addq	%rsi, %rax
    56fd:      	movq	%rsp, %rdi
    5700:      	movl	$0x8, %ecx
    5705:      	movl	$0x70, %r8d
    570b:      	movl	0xec(%rsp), %edx
    5712:      	addq	%rsi, %rdx
    5715:      	movl	$0x8, %esi
    571a:      	callq	*%r8
    571d:      	testq	%rax, %rax
    5720:      	je	0x6094 <kprobe_unwind_hotspot+0x6094>
    5726:      	movq	(%rip), %rax            # 0x572d <kprobe_unwind_hotspot+0x572d>
    572d:      	cmpl	$0x0, (%rax)
    5730:      	jne	0x6a85 <kprobe_unwind_hotspot+0x6a85>
    5736:      	movq	0xd0(%rsp), %rax
    573e:      	movzwl	0xf8(%rsp), %ecx
    5746:      	addq	%rax, %rcx
    5749:      	cmpq	%rcx, %r12
    574c:      	jae	0x5856 <kprobe_unwind_hotspot+0x5856>
    5752:      	addq	$-0x4, %rcx
    5756:      	movq	(%rip), %rax            # 0x575d <kprobe_unwind_hotspot+0x575d>
    575d:      	movl	(%rax), %eax
    575f:      	cmpq	%rcx, %r12
    5762:      	jae	0x5c5d <kprobe_unwind_hotspot+0x5c5d>
    5768:      	movb	$0x3, %cl
    576a:      	movl	%ecx, 0xb0(%rsp)
    5771:      	testl	%eax, %eax
    5773:      	je	0x580a <kprobe_unwind_hotspot+0x580a>
    5779:      	movabsq	$0x2963702820656d61, %rax # imm = 0x2963702820656D61
    5783:      	movq	%rax, 0x60(%rsp)
    5788:      	movabsq	$0x7266206574656c70, %rax # imm = 0x7266206574656C70
    5792:      	movq	%rax, 0x58(%rsp)
    5797:      	movabsq	$0x6d6f636e6920676e, %rax # imm = 0x6D6F636E6920676E
    57a1:      	movq	%rax, 0x50(%rsp)
    57a6:      	movabsq	$0x69646e69776e7520, %rax # imm = 0x69646E69776E7520
    57b0:      	movq	%rax, 0x48(%rsp)
    57b5:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    57bf:      	movq	%rax, 0x40(%rsp)
    57c4:      	movw	$0xa, 0x68(%rsp)
    57cb:      	leaq	0x40(%rsp), %rdi
    57d0:      	movl	$0x2a, %eax
    57d5:      	movl	$0x6, %ecx
    57da:      	movl	$0x2a, %esi
    57df:      	jmp	0x6b3d <kprobe_unwind_hotspot+0x6b3d>
    57e4:      	movb	$0x1, %al
    57e6:      	movl	%eax, 0xb0(%rsp)
    57ed:      	movl	$0x62617476, %eax       # imm = 0x62617476
    57f2:      	movq	%rax, 0xb8(%rsp)
    57fa:      	movq	(%rip), %rax            # 0x5801 <kprobe_unwind_hotspot+0x5801>
    5801:      	cmpl	$0x0, (%rax)
    5804:      	jne	0x6afc <kprobe_unwind_hotspot+0x6afc>
    580a:      	movl	$0x8, 0xf0(%rsp)
    5815:      	movl	$0x8, %eax
    581a:      	jmp	0x5c88 <kprobe_unwind_hotspot+0x5c88>
    581f:      	movq	(%rip), %rax            # 0x5826 <kprobe_unwind_hotspot+0x5826>
    5826:      	cmpl	$0x0, (%rax)
    5829:      	jne	0x6b46 <kprobe_unwind_hotspot+0x6b46>
    582f:      	movl	0xf0(%rsp), %eax
    5836:      	movl	$0x0, 0xb0(%rsp)
    5841:      	movq	0xa8(%rsp), %rcx
    5849:      	testl	%eax, %eax
    584b:      	jne	0x5c88 <kprobe_unwind_hotspot+0x5c88>
    5851:      	jmp	0x5c73 <kprobe_unwind_hotspot+0x5c73>
    5856:      	movl	0xf0(%rsp), %ebx
    585d:      	movq	0xa8(%rsp), %rdx
    5865:      	movq	0x38(%rsp), %rax
    586a:      	leaq	(%rax,%rbx), %rcx
    586e:      	addq	$0x30, %rcx
    5872:      	movq	%rcx, 0x108(%rsp)
    587a:      	subq	%rax, %rdx
    587d:      	jb	0x5f84 <kprobe_unwind_hotspot+0x5f84>
    5883:      	movq	0x108(%rsp), %rax
    588b:      	cmpq	%rax, 0xa8(%rsp)
    5893:      	jae	0x5f84 <kprobe_unwind_hotspot+0x5f84>
    5899:      	movb	$0x3, %al
    589b:      	movl	%eax, 0xb0(%rsp)
    58a2:      	movq	(%rip), %rax            # 0x58a9 <kprobe_unwind_hotspot+0x58a9>
    58a9:      	cmpl	$0x0, (%rax)
    58ac:      	jne	0x6ba7 <kprobe_unwind_hotspot+0x6ba7>
    58b2:      	movq	0xa8(%rsp), %rcx
    58ba:      	jmp	0x5c73 <kprobe_unwind_hotspot+0x5c73>
    58bf:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    58c9:      	movq	%rax, 0x66(%rsp)
    58ce:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    58d8:      	movq	%rax, 0x60(%rsp)
    58dd:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    58e7:      	movq	%rax, 0x58(%rsp)
    58ec:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    58f6:      	movq	%rax, 0x50(%rsp)
    58fb:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    5905:      	movq	%rax, 0x48(%rsp)
    590a:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5914:      	movq	%rax, 0x40(%rsp)
    5919:      	leaq	0x40(%rsp), %rdi
    591e:      	movl	$0x2e, %eax
    5923:      	movl	$0x6, %ecx
    5928:      	movl	0xc8(%rsp), %edx
    592f:      	movl	$0x2e, %esi
    5934:      	xorl	%eax, %eax
    5936:      	callq	*%rcx
    5938:      	jmp	0x52ab <kprobe_unwind_hotspot+0x52ab>
    593d:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    5947:      	movq	%rax, 0x55(%rsp)
    594c:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    5956:      	movq	%rax, 0x50(%rsp)
    595b:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    5965:      	movq	%rax, 0x48(%rsp)
    596a:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    5974:      	movq	%rax, 0x40(%rsp)
    5979:      	leaq	0x40(%rsp), %rdi
    597e:      	movl	$0x1d, %eax
    5983:      	movl	$0x6, %r8d
    5989:      	movzbl	(%rsp), %ecx
    598d:      	movl	$0x1d, %esi
    5992:      	movq	%r13, %rdx
    5995:      	xorl	%eax, %eax
    5997:      	callq	*%r8
    599a:      	movzbl	(%rsp), %eax
    599e:      	leal	0x1(%rax), %ecx
    59a1:      	cmpb	$0x2, %cl
    59a4:      	jb	0x53f6 <kprobe_unwind_hotspot+0x53f6>
    59aa:      	movzbl	%al, %eax
    59ad:      	subq	%rax, %r13
    59b0:      	leaq	(%rbx,%r13), %rdx
    59b4:      	movq	%rsp, %rdi
    59b7:      	movl	$0x1, %eax
    59bc:      	movl	$0x70, %ecx
    59c1:      	movl	$0x1, %esi
    59c6:      	callq	*%rcx
    59c8:      	testq	%rax, %rax
    59cb:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    59d1:      	movq	(%rip), %rax            # 0x59d8 <kprobe_unwind_hotspot+0x59d8>
    59d8:      	cmpl	$0x0, (%rax)
    59db:      	jne	0x626c <kprobe_unwind_hotspot+0x626c>
    59e1:      	movzbl	(%rsp), %eax
    59e5:      	leal	0x1(%rax), %ecx
    59e8:      	cmpb	$0x2, %cl
    59eb:      	jb	0x53f6 <kprobe_unwind_hotspot+0x53f6>
    59f1:      	movzbl	%al, %eax
    59f4:      	subq	%rax, %r13
    59f7:      	leaq	(%rbx,%r13), %rdx
    59fb:      	movq	%rsp, %rdi
    59fe:      	movl	$0x1, %eax
    5a03:      	movl	$0x70, %ecx
    5a08:      	movl	$0x1, %esi
    5a0d:      	callq	*%rcx
    5a0f:      	testq	%rax, %rax
    5a12:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    5a18:      	movq	(%rip), %rax            # 0x5a1f <kprobe_unwind_hotspot+0x5a1f>
    5a1f:      	cmpl	$0x0, (%rax)
    5a22:      	jne	0x672a <kprobe_unwind_hotspot+0x672a>
    5a28:      	movzbl	(%rsp), %eax
    5a2c:      	leal	0x1(%rax), %ecx
    5a2f:      	cmpb	$0x2, %cl
    5a32:      	jb	0x53f6 <kprobe_unwind_hotspot+0x53f6>
    5a38:      	movzbl	%al, %eax
    5a3b:      	subq	%rax, %r13
    5a3e:      	leaq	(%rbx,%r13), %rdx
    5a42:      	movq	%rsp, %rdi
    5a45:      	movl	$0x1, %eax
    5a4a:      	movl	$0x70, %ecx
    5a4f:      	movl	$0x1, %esi
    5a54:      	callq	*%rcx
    5a56:      	testq	%rax, %rax
    5a59:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    5a5f:      	movq	(%rip), %rax            # 0x5a66 <kprobe_unwind_hotspot+0x5a66>
    5a66:      	cmpl	$0x0, (%rax)
    5a69:      	jne	0x682b <kprobe_unwind_hotspot+0x682b>
    5a6f:      	movzbl	(%rsp), %eax
    5a73:      	leal	0x1(%rax), %ecx
    5a76:      	cmpb	$0x2, %cl
    5a79:      	jb	0x53f6 <kprobe_unwind_hotspot+0x53f6>
    5a7f:      	movzbl	%al, %eax
    5a82:      	subq	%rax, %r13
    5a85:      	leaq	(%rbx,%r13), %rdx
    5a89:      	movq	%rsp, %rdi
    5a8c:      	movl	$0x1, %eax
    5a91:      	movl	$0x70, %ecx
    5a96:      	movl	$0x1, %esi
    5a9b:      	callq	*%rcx
    5a9d:      	testq	%rax, %rax
    5aa0:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    5aa6:      	movq	(%rip), %rax            # 0x5aad <kprobe_unwind_hotspot+0x5aad>
    5aad:      	cmpl	$0x0, (%rax)
    5ab0:      	jne	0x6c26 <kprobe_unwind_hotspot+0x6c26>
    5ab6:      	movzbl	(%rsp), %eax
    5aba:      	leal	0x1(%rax), %ecx
    5abd:      	cmpb	$0x2, %cl
    5ac0:      	jb	0x53f6 <kprobe_unwind_hotspot+0x53f6>
    5ac6:      	movzbl	%al, %eax
    5ac9:      	subq	%rax, %r13
    5acc:      	leaq	(%rbx,%r13), %rdx
    5ad0:      	movq	%rsp, %rdi
    5ad3:      	movl	$0x1, %eax
    5ad8:      	movl	$0x70, %ecx
    5add:      	movl	$0x1, %esi
    5ae2:      	callq	*%rcx
    5ae4:      	testq	%rax, %rax
    5ae7:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    5aed:      	movq	(%rip), %rax            # 0x5af4 <kprobe_unwind_hotspot+0x5af4>
    5af4:      	cmpl	$0x0, (%rax)
    5af7:      	jne	0x6c98 <kprobe_unwind_hotspot+0x6c98>
    5afd:      	movzbl	(%rsp), %eax
    5b01:      	leal	0x1(%rax), %ecx
    5b04:      	cmpb	$0x2, %cl
    5b07:      	jb	0x53f6 <kprobe_unwind_hotspot+0x53f6>
    5b0d:      	movzbl	%al, %eax
    5b10:      	subq	%rax, %r13
    5b13:      	leaq	(%rbx,%r13), %rdx
    5b17:      	movq	%rsp, %rdi
    5b1a:      	movl	$0x1, %eax
    5b1f:      	movl	$0x70, %ecx
    5b24:      	movl	$0x1, %esi
    5b29:      	callq	*%rcx
    5b2b:      	testq	%rax, %rax
    5b2e:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    5b34:      	movq	(%rip), %rax            # 0x5b3b <kprobe_unwind_hotspot+0x5b3b>
    5b3b:      	cmpl	$0x0, (%rax)
    5b3e:      	jne	0x6d0a <kprobe_unwind_hotspot+0x6d0a>
    5b44:      	movzbl	(%rsp), %eax
    5b48:      	leal	0x1(%rax), %ecx
    5b4b:      	cmpb	$0x2, %cl
    5b4e:      	jb	0x53f6 <kprobe_unwind_hotspot+0x53f6>
    5b54:      	movzbl	%al, %eax
    5b57:      	subq	%rax, %r13
    5b5a:      	leaq	(%rbx,%r13), %rdx
    5b5e:      	movq	%rsp, %rdi
    5b61:      	movl	$0x1, %eax
    5b66:      	movl	$0x70, %ecx
    5b6b:      	movl	$0x1, %esi
    5b70:      	callq	*%rcx
    5b72:      	testq	%rax, %rax
    5b75:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    5b7b:      	movq	(%rip), %rax            # 0x5b82 <kprobe_unwind_hotspot+0x5b82>
    5b82:      	cmpl	$0x0, (%rax)
    5b85:      	jne	0x6d7c <kprobe_unwind_hotspot+0x6d7c>
    5b8b:      	movzbl	(%rsp), %eax
    5b8f:      	leal	0x1(%rax), %ecx
    5b92:      	cmpb	$0x2, %cl
    5b95:      	jb	0x53f6 <kprobe_unwind_hotspot+0x53f6>
    5b9b:      	jmp	0x6de9 <kprobe_unwind_hotspot+0x6de9>
    5ba0:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    5baa:      	movq	%rax, 0x26(%rsp)
    5baf:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    5bb9:      	movq	%rax, 0x20(%rsp)
    5bbe:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    5bc8:      	movq	%rax, 0x18(%rsp)
    5bcd:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    5bd7:      	movq	%rax, 0x10(%rsp)
    5bdc:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    5be6:      	movq	%rax, 0x8(%rsp)
    5beb:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5bf5:      	movq	%rax, (%rsp)
    5bf9:      	movq	%rsp, %rdi
    5bfc:      	movl	$0x2e, %eax
    5c01:      	movl	$0x6, %ecx
    5c06:      	movl	0x100(%rsp), %edx
    5c0d:      	movl	$0x2e, %esi
    5c12:      	xorl	%eax, %eax
    5c14:      	callq	*%rcx
    5c16:      	jmp	0x4374 <kprobe_unwind_hotspot+0x4374>
    5c1b:      	movq	(%rip), %rax            # 0x5c22 <kprobe_unwind_hotspot+0x5c22>
    5c22:      	cmpl	$0x0, (%rax)
    5c25:      	jne	0x7070 <kprobe_unwind_hotspot+0x7070>
    5c2b:      	movl	$0x2d, 0x114(%rsp)
    5c36:      	movq	(%rip), %rdi            # 0x5c3d <kprobe_unwind_hotspot+0x5c3d>
    5c3d:      	leaq	0x114(%rsp), %rsi
    5c45:      	movl	$0x1, %eax
    5c4a:      	callq	*%rax
    5c4c:      	testq	%rax, %rax
    5c4f:      	je	0x60db <kprobe_unwind_hotspot+0x60db>
    5c55:      	incq	(%rax)
    5c58:      	jmp	0x60eb <kprobe_unwind_hotspot+0x60eb>
    5c5d:      	movb	$0x3, %cl
    5c5f:      	movl	%ecx, 0xb0(%rsp)
    5c66:      	testl	%eax, %eax
    5c68:      	jne	0x70e4 <kprobe_unwind_hotspot+0x70e4>
    5c6e:      	movq	0x38(%rsp), %rcx
    5c73:      	movl	$0x10, 0xf0(%rsp)
    5c7e:      	movl	$0x10, %eax
    5c83:      	movq	%rcx, 0x38(%rsp)
    5c88:      	movl	%eax, %eax
    5c8a:      	addq	%rax, 0x38(%rsp)
    5c8f:      	movq	0x38(%rsp), %rax
    5c94:      	leaq	-0x10(%rax), %rdx
    5c98:      	movq	%rsp, %rdi
    5c9b:      	movl	$0x10, %eax
    5ca0:      	movl	$0x70, %ecx
    5ca5:      	movl	$0x10, %esi
    5caa:      	callq	*%rcx
    5cac:      	movq	0x8(%rsp), %r12
    5cb1:      	cmpl	$0x10, 0xf0(%rsp)
    5cb9:      	jb	0x5cd7 <kprobe_unwind_hotspot+0x5cd7>
    5cbb:      	movq	(%rip), %rax            # 0x5cc2 <kprobe_unwind_hotspot+0x5cc2>
    5cc2:      	cmpl	$0x0, (%rax)
    5cc5:      	jne	0x715b <kprobe_unwind_hotspot+0x715b>
    5ccb:      	movq	(%rsp), %rax
    5ccf:      	movq	%rax, 0xa8(%rsp)
    5cd7:      	movl	0x2c0(%r14), %eax
    5cde:      	cmpq	$0x7e, %rax
    5ce2:      	ja	0xf03 <kprobe_unwind_hotspot+0xf03>
    5ce8:      	movzbl	0xf30(%r14), %ecx
    5cf0:      	movzbl	0xb0(%rsp), %edx
    5cf8:      	shlq	$0x3c, %rdx
    5cfc:      	movq	0x118(%rsp), %rdi
    5d04:      	shlq	$0x20, %rdi
    5d08:      	movl	0xb8(%rsp), %esi
    5d0f:      	orq	%rdi, %rsi
    5d12:      	orq	%rdx, %rsi
    5d15:      	leal	0x1(%rax), %edx
    5d18:      	movl	%edx, 0x2c0(%r14)
    5d1f:      	leaq	(%rax,%rax,2), %rax
    5d23:      	movq	0xc0(%rsp), %rdx
    5d2b:      	movq	%rdx, 0x2d0(%r14,%rax,8)
    5d33:      	movq	%rsi, 0x2d8(%r14,%rax,8)
    5d3b:      	movb	$0x5, 0x2e0(%r14,%rax,8)
    5d44:      	movb	%cl, 0x2e1(%r14,%rax,8)
    5d4c:      	movl	$0x0, 0x2e2(%r14,%rax,8)
    5d58:      	movw	$0x0, 0x2e6(%r14,%rax,8)
    5d63:      	movq	(%rip), %rax            # 0x5d6a <kprobe_unwind_hotspot+0x5d6a>
    5d6a:      	cmpl	$0x0, (%rax)
    5d6d:      	jne	0x71a5 <kprobe_unwind_hotspot+0x71a5>
    5d73:      	movq	%r12, 0xed0(%r14)
    5d7a:      	movq	0x38(%rsp), %rax
    5d7f:      	movq	%rax, 0xed8(%r14)
    5d86:      	movq	0xa8(%rsp), %rax
    5d8e:      	movq	%rax, 0xee0(%r14)
    5d95:      	movb	$0x1, 0xf30(%r14)
    5d9d:      	movl	$0x2a, (%rsp)
    5da4:      	movq	(%rip), %rdi            # 0x5dab <kprobe_unwind_hotspot+0x5dab>
    5dab:      	movq	%rsp, %rsi
    5dae:      	movl	$0x1, %eax
    5db3:      	callq	*%rax
    5db5:      	testq	%rax, %rax
    5db8:      	je	0x5dc8 <kprobe_unwind_hotspot+0x5dc8>
    5dba:      	incq	(%rax)
    5dbd:      	movq	(%rip), %rax            # 0x5dc4 <kprobe_unwind_hotspot+0x5dc4>
    5dc4:      	movl	(%rax), %eax
    5dc6:      	jmp	0x5dda <kprobe_unwind_hotspot+0x5dda>
    5dc8:      	xorl	%eax, %eax
    5dca:      	movq	(%rip), %rcx            # 0x5dd1 <kprobe_unwind_hotspot+0x5dd1>
    5dd1:      	cmpl	$0x0, (%rcx)
    5dd4:      	jne	0x7218 <kprobe_unwind_hotspot+0x7218>
    5dda:      	movq	0xed0(%r14), %rbx
    5de1:      	testq	%rbx, %rbx
    5de4:      	je	0x9ceb <kprobe_unwind_hotspot+0x9ceb>
    5dea:      	testl	%eax, %eax
    5dec:      	jne	0x7292 <kprobe_unwind_hotspot+0x7292>
    5df2:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    5dfc:      	cmpq	%rax, %rbx
    5dff:      	ja	0x1049 <kprobe_unwind_hotspot+0x1049>
    5e05:      	cmpq	$0x1000, %rbx           # imm = 0x1000
    5e0c:      	jb	0x1fa2 <kprobe_unwind_hotspot+0x1fa2>
    5e12:      	movl	(%r14), %eax
    5e15:      	movl	$0x60, 0xc8(%rsp)
    5e20:      	movbel	%eax, 0xcc(%rsp)
    5e29:      	movbeq	%rbx, 0xd0(%rsp)
    5e33:      	movq	(%rip), %rdi            # 0x5e3a <kprobe_unwind_hotspot+0x5e3a>
    5e3a:      	leaq	0xc8(%rsp), %rsi
    5e42:      	movl	$0x1, %eax
    5e47:      	callq	*%rax
    5e49:      	testq	%rax, %rax
    5e4c:      	je	0x9d07 <kprobe_unwind_hotspot+0x9d07>
    5e52:      	movq	0x8(%rax), %r12
    5e56:      	movq	%r12, %rcx
    5e59:      	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    5e63:      	andq	%rdx, %rcx
    5e66:      	movq	%rcx, 0xf20(%r14)
    5e6d:      	movq	(%rax), %rax
    5e70:      	movq	%rax, 0xf10(%r14)
    5e77:      	shrq	$0x38, %r12
    5e7b:      	movq	%rbx, %rax
    5e7e:      	subq	%rcx, %rax
    5e81:      	movq	%rax, 0xf18(%r14)
    5e88:      	movq	(%rip), %rax            # 0x5e8f <kprobe_unwind_hotspot+0x5e8f>
    5e8f:      	cmpl	$0x0, (%rax)
    5e92:      	jne	0x732f <kprobe_unwind_hotspot+0x732f>
    5e98:      	cmpl	$0x1, %r12d
    5e9c:      	jne	0x7a93 <kprobe_unwind_hotspot+0x7a93>
    5ea2:      	movq	0xf10(%r14), %rax
    5ea9:      	movq	%rax, 0xc8(%rsp)
    5eb1:      	movq	0xf18(%r14), %r13
    5eb8:      	movq	(%rip), %rdi            # 0x5ebf <kprobe_unwind_hotspot+0x5ebf>
    5ebf:      	leaq	0xc8(%rsp), %rsi
    5ec7:      	movl	$0x1, %eax
    5ecc:      	callq	*%rax
    5ece:      	movl	$0x1, %r12d
    5ed4:      	testq	%rax, %rax
    5ed7:      	je	0x7a93 <kprobe_unwind_hotspot+0x7a93>
    5edd:      	movq	%rax, %rbx
    5ee0:      	cmpq	%r13, (%rax)
    5ee3:      	ja	0x5eeb <kprobe_unwind_hotspot+0x5eeb>
    5ee5:      	cmpq	%r13, 0x8(%rbx)
    5ee9:      	jae	0x5eff <kprobe_unwind_hotspot+0x5eff>
    5eeb:      	cmpq	%r13, 0x10(%rbx)
    5eef:      	ja	0x7a93 <kprobe_unwind_hotspot+0x7a93>
    5ef5:      	cmpq	%r13, 0x18(%rbx)
    5ef9:      	jb	0x7a93 <kprobe_unwind_hotspot+0x7a93>
    5eff:      	movq	(%rip), %rax            # 0x5f06 <kprobe_unwind_hotspot+0x5f06>
    5f06:      	cmpl	$0x0, (%rax)
    5f09:      	jne	0x7444 <kprobe_unwind_hotspot+0x7444>
    5f0f:      	movl	0x1380(%r14), %eax
    5f16:      	movl	0x20(%rbx), %ecx
    5f19:      	btl	%ecx, %eax
    5f1c:      	jae	0x74af <kprobe_unwind_hotspot+0x74af>
    5f22:      	movq	(%rip), %rax            # 0x5f29 <kprobe_unwind_hotspot+0x5f29>
    5f29:      	cmpl	$0x0, (%rax)
    5f2c:      	je	0x7a93 <kprobe_unwind_hotspot+0x7a93>
    5f32:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    5f3c:      	movq	%rax, 0x50(%rsp)
    5f41:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    5f4b:      	movq	%rax, 0x48(%rsp)
    5f50:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    5f5a:      	movq	%rax, 0x40(%rsp)
    5f5f:      	movl	$0xa656e, 0x57(%rsp)    # imm = 0xA656E
    5f67:      	leaq	0x40(%rsp), %rdi
    5f6c:      	movl	$0x1b, %eax
    5f71:      	movl	$0x6, %ecx
    5f76:      	movl	$0x1b, %esi
    5f7b:      	xorl	%eax, %eax
    5f7d:      	callq	*%rcx
    5f7f:      	jmp	0x7a93 <kprobe_unwind_hotspot+0x7a93>
    5f84:      	movq	0x38(%rsp), %rax
    5f89:      	leaq	(%rax,%rbx), %rdx
    5f8d:      	addq	$-0x8, %rdx
    5f91:      	leaq	0x40(%rsp), %rdi
    5f96:      	movl	$0x30, %eax
    5f9b:      	movl	$0x70, %ecx
    5fa0:      	movl	$0x30, %esi
    5fa5:      	callq	*%rcx
    5fa7:      	movq	(%rip), %rax            # 0x5fae <kprobe_unwind_hotspot+0x5fae>
    5fae:      	cmpl	$0x0, (%rax)
    5fb1:      	jne	0x74d8 <kprobe_unwind_hotspot+0x74d8>
    5fb7:      	movl	(%r14), %eax
    5fba:      	movl	$0x60, (%rsp)
    5fc1:      	movbel	%eax, 0x4(%rsp)
    5fc7:      	addq	%rbx, 0x38(%rsp)
    5fcc:      	movq	0x40(%rsp), %rax
    5fd1:      	movbeq	%rax, 0x8(%rsp)
    5fd8:      	movabsq	$-0x100000000000000, %rbx # imm = 0xFF00000000000000
    5fe2:      	movabsq	$0x200000000000000, %r13 # imm = 0x200000000000000
    5fec:      	movq	(%rip), %rdi            # 0x5ff3 <kprobe_unwind_hotspot+0x5ff3>
    5ff3:      	movq	%rsp, %rsi
    5ff6:      	movl	$0x1, %eax
    5ffb:      	callq	*%rax
    5ffd:      	testq	%rax, %rax
    6000:      	je	0x610d <kprobe_unwind_hotspot+0x610d>
    6006:      	movq	0x8(%rax), %rax
    600a:      	andq	%rbx, %rax
    600d:      	xorl	%edx, %edx
    600f:      	cmpq	%r13, %rax
    6012:      	jne	0x610d <kprobe_unwind_hotspot+0x610d>
    6018:      	movq	0x38(%rsp), %rax
    601d:      	jmp	0x64f5 <kprobe_unwind_hotspot+0x64f5>
    6022:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    602c:      	movq	%rax, 0x55(%rsp)
    6031:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    603b:      	movq	%rax, 0x50(%rsp)
    6040:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    604a:      	movq	%rax, 0x48(%rsp)
    604f:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    6059:      	movq	%rax, 0x40(%rsp)
    605e:      	leaq	0x40(%rsp), %rdi
    6063:      	movl	$0x1d, %eax
    6068:      	movl	$0x6, %r8d
    606e:      	movzbl	(%rsp), %ecx
    6072:      	movl	$0x1d, %esi
    6077:      	movq	%r13, %rdx
    607a:      	xorl	%eax, %eax
    607c:      	callq	*%r8
    607f:      	movzbl	(%rsp), %eax
    6083:      	leal	0x1(%rax), %ecx
    6086:      	cmpb	$0x2, %cl
    6089:      	jb	0x2ea0 <kprobe_unwind_hotspot+0x2ea0>
    608f:      	jmp	0x3645 <kprobe_unwind_hotspot+0x3645>
    6094:      	movq	(%rsp), %rax
    6098:      	movq	0xd0(%rsp), %rcx
    60a0:      	cmpq	%rcx, %rax
    60a3:      	jb	0x5726 <kprobe_unwind_hotspot+0x5726>
    60a9:      	cmpq	0xd8(%rsp), %rax
    60b1:      	jae	0x5726 <kprobe_unwind_hotspot+0x5726>
    60b7:      	movq	(%rip), %rdx            # 0x60be <kprobe_unwind_hotspot+0x60be>
    60be:      	cmpl	$0x0, (%rdx)
    60c1:      	jne	0x753e <kprobe_unwind_hotspot+0x753e>
    60c7:      	movl	%eax, %edx
    60c9:      	subl	%ecx, %edx
    60cb:      	movq	%rdx, 0x118(%rsp)
    60d3:      	movq	%rax, %r12
    60d6:      	jmp	0x5736 <kprobe_unwind_hotspot+0x5736>
    60db:      	movq	(%rip), %rax            # 0x60e2 <kprobe_unwind_hotspot+0x60e2>
    60e2:      	cmpl	$0x0, (%rax)
    60e5:      	jne	0x75ec <kprobe_unwind_hotspot+0x75ec>
    60eb:      	movl	$0x3e9, %ebx            # imm = 0x3E9
    60f0:      	xorl	%r13d, %r13d
    60f3:      	movl	$0x65746e49, %eax       # imm = 0x65746E49
    60f8:      	movq	%rax, 0xb8(%rsp)
    6100:      	testl	%ebx, %ebx
    6102:      	jne	0x347 <kprobe_unwind_hotspot+0x347>
    6108:      	jmp	0x6533 <kprobe_unwind_hotspot+0x6533>
    610d:      	movq	(%rip), %rax            # 0x6114 <kprobe_unwind_hotspot+0x6114>
    6114:      	cmpl	$0x0, (%rax)
    6117:      	jne	0x7667 <kprobe_unwind_hotspot+0x7667>
    611d:      	movl	(%r14), %eax
    6120:      	movl	$0x60, (%rsp)
    6127:      	movbel	%eax, 0x4(%rsp)
    612d:      	movq	0x48(%rsp), %rax
    6132:      	movbeq	%rax, 0x8(%rsp)
    6139:      	movq	(%rip), %rdi            # 0x6140 <kprobe_unwind_hotspot+0x6140>
    6140:      	movq	%rsp, %rsi
    6143:      	movl	$0x1, %eax
    6148:      	callq	*%rax
    614a:      	testq	%rax, %rax
    614d:      	je	0x616e <kprobe_unwind_hotspot+0x616e>
    614f:      	movq	0x8(%rax), %rax
    6153:      	andq	%rbx, %rax
    6156:      	cmpq	%r13, %rax
    6159:      	jne	0x616e <kprobe_unwind_hotspot+0x616e>
    615b:      	movq	0x38(%rsp), %rax
    6160:      	addq	$0x8, %rax
    6164:      	movl	$0x1, %edx
    6169:      	jmp	0x64f5 <kprobe_unwind_hotspot+0x64f5>
    616e:      	movq	(%rip), %rax            # 0x6175 <kprobe_unwind_hotspot+0x6175>
    6175:      	cmpl	$0x0, (%rax)
    6178:      	jne	0x76d0 <kprobe_unwind_hotspot+0x76d0>
    617e:      	movl	(%r14), %eax
    6181:      	movl	$0x60, (%rsp)
    6188:      	movbel	%eax, 0x4(%rsp)
    618e:      	movq	0x50(%rsp), %rax
    6193:      	movbeq	%rax, 0x8(%rsp)
    619a:      	movq	(%rip), %rdi            # 0x61a1 <kprobe_unwind_hotspot+0x61a1>
    61a1:      	movq	%rsp, %rsi
    61a4:      	movl	$0x1, %eax
    61a9:      	callq	*%rax
    61ab:      	testq	%rax, %rax
    61ae:      	je	0x62de <kprobe_unwind_hotspot+0x62de>
    61b4:      	movq	0x8(%rax), %rax
    61b8:      	andq	%rbx, %rax
    61bb:      	cmpq	%r13, %rax
    61be:      	jne	0x62de <kprobe_unwind_hotspot+0x62de>
    61c4:      	movq	0x38(%rsp), %rax
    61c9:      	addq	$0x10, %rax
    61cd:      	movl	$0x2, %edx
    61d2:      	jmp	0x64f5 <kprobe_unwind_hotspot+0x64f5>
    61d7:      	movabsq	$0xa786c2520626f6c, %rax # imm = 0xA786C2520626F6C
    61e1:      	movq	%rax, 0x58(%rsp)
    61e6:      	movabsq	$0x6265646f63206f74, %rax # imm = 0x6265646F63206F74
    61f0:      	movq	%rax, 0x50(%rsp)
    61f5:      	movabsq	$0x2064657070616d20, %rax # imm = 0x2064657070616D20
    61ff:      	movq	%rax, 0x48(%rsp)
    6204:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    620e:      	movq	%rax, 0x40(%rsp)
    6213:      	movb	$0x0, 0x60(%rsp)
    6218:      	leaq	0x40(%rsp), %rdi
    621d:      	movl	$0x21, %eax
    6222:      	movl	$0x6, %ecx
    6227:      	movl	$0x21, %esi
    622c:      	movq	%rbx, %rdx
    622f:      	xorl	%eax, %eax
    6231:      	callq	*%rcx
    6233:      	movq	%rbx, 0xc8(%rsp)
    623b:      	testq	%rbx, %rbx
    623e:      	jne	0x5438 <kprobe_unwind_hotspot+0x5438>
    6244:      	jmp	0x237 <kprobe_unwind_hotspot+0x237>
    6249:      	cmpl	$0x0, 0x2c0(%r14)
    6251:      	je	0x6589 <kprobe_unwind_hotspot+0x6589>
    6257:      	cmpb	$0x0, 0x1f(%r15)
    625c:      	je	0x65c4 <kprobe_unwind_hotspot+0x65c4>
    6262:      	movq	0x50(%rsp), %r13
    6267:      	jmp	0x65c9 <kprobe_unwind_hotspot+0x65c9>
    626c:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    6276:      	movq	%rax, 0x55(%rsp)
    627b:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    6285:      	movq	%rax, 0x50(%rsp)
    628a:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    6294:      	movq	%rax, 0x48(%rsp)
    6299:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    62a3:      	movq	%rax, 0x40(%rsp)
    62a8:      	leaq	0x40(%rsp), %rdi
    62ad:      	movl	$0x1d, %eax
    62b2:      	movl	$0x6, %r8d
    62b8:      	movzbl	(%rsp), %ecx
    62bc:      	movl	$0x1d, %esi
    62c1:      	movq	%r13, %rdx
    62c4:      	xorl	%eax, %eax
    62c6:      	callq	*%r8
    62c9:      	movzbl	(%rsp), %eax
    62cd:      	leal	0x1(%rax), %ecx
    62d0:      	cmpb	$0x2, %cl
    62d3:      	jb	0x53f6 <kprobe_unwind_hotspot+0x53f6>
    62d9:      	jmp	0x59f1 <kprobe_unwind_hotspot+0x59f1>
    62de:      	movq	(%rip), %rax            # 0x62e5 <kprobe_unwind_hotspot+0x62e5>
    62e5:      	cmpl	$0x0, (%rax)
    62e8:      	jne	0x7739 <kprobe_unwind_hotspot+0x7739>
    62ee:      	movl	(%r14), %eax
    62f1:      	movl	$0x60, (%rsp)
    62f8:      	movbel	%eax, 0x4(%rsp)
    62fe:      	movq	0x58(%rsp), %rax
    6303:      	movbeq	%rax, 0x8(%rsp)
    630a:      	movq	(%rip), %rdi            # 0x6311 <kprobe_unwind_hotspot+0x6311>
    6311:      	movq	%rsp, %rsi
    6314:      	movl	$0x1, %eax
    6319:      	callq	*%rax
    631b:      	testq	%rax, %rax
    631e:      	je	0x633f <kprobe_unwind_hotspot+0x633f>
    6320:      	movq	0x8(%rax), %rax
    6324:      	andq	%rbx, %rax
    6327:      	cmpq	%r13, %rax
    632a:      	jne	0x633f <kprobe_unwind_hotspot+0x633f>
    632c:      	movq	0x38(%rsp), %rax
    6331:      	addq	$0x18, %rax
    6335:      	movl	$0x3, %edx
    633a:      	jmp	0x64f5 <kprobe_unwind_hotspot+0x64f5>
    633f:      	movq	(%rip), %rax            # 0x6346 <kprobe_unwind_hotspot+0x6346>
    6346:      	cmpl	$0x0, (%rax)
    6349:      	jne	0x77a2 <kprobe_unwind_hotspot+0x77a2>
    634f:      	movl	(%r14), %eax
    6352:      	movl	$0x60, (%rsp)
    6359:      	movbel	%eax, 0x4(%rsp)
    635f:      	movq	0x60(%rsp), %rax
    6364:      	movbeq	%rax, 0x8(%rsp)
    636b:      	movq	(%rip), %rdi            # 0x6372 <kprobe_unwind_hotspot+0x6372>
    6372:      	movq	%rsp, %rsi
    6375:      	movl	$0x1, %eax
    637a:      	callq	*%rax
    637c:      	testq	%rax, %rax
    637f:      	je	0x6494 <kprobe_unwind_hotspot+0x6494>
    6385:      	movq	0x8(%rax), %rax
    6389:      	andq	%rbx, %rax
    638c:      	cmpq	%r13, %rax
    638f:      	jne	0x6494 <kprobe_unwind_hotspot+0x6494>
    6395:      	movq	0x38(%rsp), %rax
    639a:      	addq	$0x20, %rax
    639e:      	movl	$0x4, %edx
    63a3:      	jmp	0x64f5 <kprobe_unwind_hotspot+0x64f5>
    63a8:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    63b2:      	movq	%rax, 0x66(%rsp)
    63b7:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    63c1:      	movq	%rax, 0x60(%rsp)
    63c6:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    63d0:      	movq	%rax, 0x58(%rsp)
    63d5:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    63df:      	movq	%rax, 0x50(%rsp)
    63e4:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    63ee:      	movq	%rax, 0x48(%rsp)
    63f3:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    63fd:      	movq	%rax, 0x40(%rsp)
    6402:      	leaq	0x40(%rsp), %rdi
    6407:      	movl	$0x2e, %eax
    640c:      	movl	$0x6, %ecx
    6411:      	movl	(%rsp), %edx
    6414:      	movl	$0x2e, %esi
    6419:      	xorl	%eax, %eax
    641b:      	callq	*%rcx
    641d:      	jmp	0x526f <kprobe_unwind_hotspot+0x526f>
    6422:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    642c:      	movq	%rax, 0x55(%rsp)
    6431:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    643b:      	movq	%rax, 0x50(%rsp)
    6440:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    644a:      	movq	%rax, 0x48(%rsp)
    644f:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    6459:      	movq	%rax, 0x40(%rsp)
    645e:      	leaq	0x40(%rsp), %rdi
    6463:      	movl	$0x1d, %eax
    6468:      	movl	$0x6, %r8d
    646e:      	movzbl	(%rsp), %ecx
    6472:      	movl	$0x1d, %esi
    6477:      	movq	%r13, %rdx
    647a:      	xorl	%eax, %eax
    647c:      	callq	*%r8
    647f:      	movzbl	(%rsp), %eax
    6483:      	leal	0x1(%rax), %ecx
    6486:      	cmpb	$0x2, %cl
    6489:      	jb	0x2ea0 <kprobe_unwind_hotspot+0x2ea0>
    648f:      	jmp	0x368c <kprobe_unwind_hotspot+0x368c>
    6494:      	movq	(%rip), %rax            # 0x649b <kprobe_unwind_hotspot+0x649b>
    649b:      	cmpl	$0x0, (%rax)
    649e:      	jne	0x780b <kprobe_unwind_hotspot+0x780b>
    64a4:      	movl	(%r14), %eax
    64a7:      	movl	$0x60, (%rsp)
    64ae:      	movbel	%eax, 0x4(%rsp)
    64b4:      	movq	0x68(%rsp), %rax
    64b9:      	movbeq	%rax, 0x8(%rsp)
    64c0:      	movq	(%rip), %rdi            # 0x64c7 <kprobe_unwind_hotspot+0x64c7>
    64c7:      	movq	%rsp, %rsi
    64ca:      	movl	$0x1, %eax
    64cf:      	callq	*%rax
    64d1:      	testq	%rax, %rax
    64d4:      	je	0x6592 <kprobe_unwind_hotspot+0x6592>
    64da:      	andq	0x8(%rax), %rbx
    64de:      	cmpq	%r13, %rbx
    64e1:      	jne	0x6592 <kprobe_unwind_hotspot+0x6592>
    64e7:      	movq	0x38(%rsp), %rax
    64ec:      	addq	$0x28, %rax
    64f0:      	movl	$0x5, %edx
    64f5:      	movq	%rax, 0x108(%rsp)
    64fd:      	xorl	%ebx, %ebx
    64ff:      	movl	$0x5, %r13d
    6505:      	movq	(%rip), %rax            # 0x650c <kprobe_unwind_hotspot+0x650c>
    650c:      	cmpl	$0x0, (%rax)
    650f:      	jne	0x7874 <kprobe_unwind_hotspot+0x7874>
    6515:      	movb	$0x3, %al
    6517:      	movl	%eax, 0xb0(%rsp)
    651e:      	movq	0x108(%rsp), %rax
    6526:      	movq	%rax, 0x38(%rsp)
    652b:      	testl	%ebx, %ebx
    652d:      	jne	0x347 <kprobe_unwind_hotspot+0x347>
    6533:      	cmpl	$0x2, %r13d
    6537:      	jle	0x6555 <kprobe_unwind_hotspot+0x6555>
    6539:      	cmpl	$0x4, %r13d
    653d:      	jg	0x657a <kprobe_unwind_hotspot+0x657a>
    653f:      	cmpl	$0x3, %r13d
    6543:      	je	0x5c6e <kprobe_unwind_hotspot+0x5c6e>
    6549:      	movl	0xf0(%rsp), %eax
    6550:      	jmp	0x5c88 <kprobe_unwind_hotspot+0x5c88>
    6555:      	movl	$0x1, %ebx
    655a:      	testl	%r13d, %r13d
    655d:      	je	0x347 <kprobe_unwind_hotspot+0x347>
    6563:      	movq	0xa8(%rsp), %rcx
    656b:      	cmpl	$0x1, %r13d
    656f:      	je	0x580a <kprobe_unwind_hotspot+0x580a>
    6575:      	jmp	0x5c73 <kprobe_unwind_hotspot+0x5c73>
    657a:      	cmpl	$0x5, %r13d
    657e:      	je	0x5c8f <kprobe_unwind_hotspot+0x5c8f>
    6584:      	jmp	0x5cd7 <kprobe_unwind_hotspot+0x5cd7>
    6589:      	movq	0xf00(%r14), %r13
    6590:      	jmp	0x65c9 <kprobe_unwind_hotspot+0x65c9>
    6592:      	movl	$0x2e, 0x100(%rsp)
    659d:      	movq	(%rip), %rdi            # 0x65a4 <kprobe_unwind_hotspot+0x65a4>
    65a4:      	leaq	0x100(%rsp), %rsi
    65ac:      	movl	$0x1, %eax
    65b1:      	callq	*%rax
    65b3:      	testq	%rax, %rax
    65b6:      	je	0x679c <kprobe_unwind_hotspot+0x679c>
    65bc:      	incq	(%rax)
    65bf:      	jmp	0x67ac <kprobe_unwind_hotspot+0x67ac>
    65c4:      	movq	0x58(%rsp), %r13
    65c9:      	movq	0x78(%rsp), %rsi
    65ce:      	movq	0x88(%rsp), %rax
    65d6:      	movq	%rax, 0x38(%rsp)
    65db:      	movq	0x90(%rsp), %rax
    65e3:      	movq	%rax, 0xa8(%rsp)
    65eb:      	movq	0x98(%rsp), %r12
    65f3:      	movzbl	0x1c(%r15), %eax
    65f8:      	addq	%rsi, %rax
    65fb:      	leaq	0x100(%rsp), %rdi
    6603:      	movl	$0x8, %ecx
    6608:      	movl	$0x70, %r8d
    660e:      	movzbl	0x1c(%r15), %edx
    6613:      	movq	%rsi, 0x108(%rsp)
    661b:      	addq	%rsi, %rdx
    661e:      	movl	$0x8, %esi
    6623:      	callq	*%r8
    6626:      	testq	%rax, %rax
    6629:      	je	0x66a1 <kprobe_unwind_hotspot+0x66a1>
    662b:      	movq	(%rip), %rax            # 0x6632 <kprobe_unwind_hotspot+0x6632>
    6632:      	cmpl	$0x0, (%rax)
    6635:      	je	0x5c2b <kprobe_unwind_hotspot+0x5c2b>
    663b:      	movabsq	$0xa646f6874656d63, %rax # imm = 0xA646F6874656D63
    6645:      	movq	%rax, 0x20(%rsp)
    664a:      	movabsq	$0x2072657465727072, %rax # imm = 0x2072657465727072
    6654:      	movq	%rax, 0x18(%rsp)
    6659:      	movabsq	$0x65746e6920646165, %rax # imm = 0x65746E6920646165
    6663:      	movq	%rax, 0x10(%rsp)
    6668:      	movabsq	$0x72206f742064656c, %rax # imm = 0x72206F742064656C
    6672:      	movq	%rax, 0x8(%rsp)
    6677:      	movabsq	$0x696166203a6d766a, %rax # imm = 0x696166203A6D766A
    6681:      	movq	%rax, (%rsp)
    6685:      	movb	$0x0, 0x28(%rsp)
    668a:      	movq	%rsp, %rdi
    668d:      	movl	$0x29, %eax
    6692:      	movl	$0x6, %ecx
    6697:      	movl	$0x29, %esi
    669c:      	jmp	0x70db <kprobe_unwind_hotspot+0x70db>
    66a1:      	movq	0x100(%rsp), %rdx
    66a9:      	movzbl	0x1d(%r15), %eax
    66ae:      	movq	%rdx, %rcx
    66b1:      	movq	%rdx, 0xb8(%rsp)
    66b9:      	addq	%rdx, %rax
    66bc:      	xorl	%ebx, %ebx
    66be:      	cmpq	%rax, %r13
    66c1:      	movl	$0x0, %ecx
    66c6:      	cmovaeq	%rax, %rcx
    66ca:      	subq	%rcx, %r13
    66cd:      	movq	(%rip), %rax            # 0x66d4 <kprobe_unwind_hotspot+0x66d4>
    66d4:      	cmpl	$0x0, (%rax)
    66d7:      	jne	0x78ea <kprobe_unwind_hotspot+0x78ea>
    66dd:      	cmpq	$0xffff, %r13           # imm = 0xFFFF
    66e4:      	movl	$0xffff, %eax           # imm = 0xFFFF
    66e9:      	cmovbq	%r13, %rax
    66ed:      	movq	%rax, 0x118(%rsp)
    66f5:      	shrq	$0x3, 0xb8(%rsp)
    66fe:      	movl	$0x6, %r13d
    6704:      	movb	$0x2, %al
    6706:      	movl	%eax, 0xb0(%rsp)
    670d:      	movq	0x108(%rsp), %rax
    6715:      	movq	%rax, 0xc0(%rsp)
    671d:      	testl	%ebx, %ebx
    671f:      	jne	0x347 <kprobe_unwind_hotspot+0x347>
    6725:      	jmp	0x6533 <kprobe_unwind_hotspot+0x6533>
    672a:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    6734:      	movq	%rax, 0x55(%rsp)
    6739:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    6743:      	movq	%rax, 0x50(%rsp)
    6748:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    6752:      	movq	%rax, 0x48(%rsp)
    6757:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    6761:      	movq	%rax, 0x40(%rsp)
    6766:      	leaq	0x40(%rsp), %rdi
    676b:      	movl	$0x1d, %eax
    6770:      	movl	$0x6, %r8d
    6776:      	movzbl	(%rsp), %ecx
    677a:      	movl	$0x1d, %esi
    677f:      	movq	%r13, %rdx
    6782:      	xorl	%eax, %eax
    6784:      	callq	*%r8
    6787:      	movzbl	(%rsp), %eax
    678b:      	leal	0x1(%rax), %ecx
    678e:      	cmpb	$0x2, %cl
    6791:      	jb	0x53f6 <kprobe_unwind_hotspot+0x53f6>
    6797:      	jmp	0x5a38 <kprobe_unwind_hotspot+0x5a38>
    679c:      	movq	(%rip), %rax            # 0x67a3 <kprobe_unwind_hotspot+0x67a3>
    67a3:      	cmpl	$0x0, (%rax)
    67a6:      	jne	0x7992 <kprobe_unwind_hotspot+0x7992>
    67ac:      	movl	$0x3ea, %ebx            # imm = 0x3EA
    67b1:      	xorl	%r13d, %r13d
    67b4:      	jmp	0x6515 <kprobe_unwind_hotspot+0x6515>
    67b9:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    67c3:      	movq	%rax, 0x55(%rsp)
    67c8:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    67d2:      	movq	%rax, 0x50(%rsp)
    67d7:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    67e1:      	movq	%rax, 0x48(%rsp)
    67e6:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    67f0:      	movq	%rax, 0x40(%rsp)
    67f5:      	leaq	0x40(%rsp), %rdi
    67fa:      	movl	$0x1d, %eax
    67ff:      	movl	$0x6, %r8d
    6805:      	movzbl	(%rsp), %ecx
    6809:      	movl	$0x1d, %esi
    680e:      	movq	%r13, %rdx
    6811:      	xorl	%eax, %eax
    6813:      	callq	*%r8
    6816:      	movzbl	(%rsp), %eax
    681a:      	leal	0x1(%rax), %ecx
    681d:      	cmpb	$0x2, %cl
    6820:      	jb	0x2ea0 <kprobe_unwind_hotspot+0x2ea0>
    6826:      	jmp	0x36d3 <kprobe_unwind_hotspot+0x36d3>
    682b:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    6835:      	movq	%rax, 0x55(%rsp)
    683a:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    6844:      	movq	%rax, 0x50(%rsp)
    6849:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    6853:      	movq	%rax, 0x48(%rsp)
    6858:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    6862:      	movq	%rax, 0x40(%rsp)
    6867:      	leaq	0x40(%rsp), %rdi
    686c:      	movl	$0x1d, %eax
    6871:      	movl	$0x6, %r8d
    6877:      	movzbl	(%rsp), %ecx
    687b:      	movl	$0x1d, %esi
    6880:      	movq	%r13, %rdx
    6883:      	xorl	%eax, %eax
    6885:      	callq	*%r8
    6888:      	movzbl	(%rsp), %eax
    688c:      	leal	0x1(%rax), %ecx
    688f:      	cmpb	$0x2, %cl
    6892:      	jb	0x53f6 <kprobe_unwind_hotspot+0x53f6>
    6898:      	jmp	0x5a7f <kprobe_unwind_hotspot+0x5a7f>
    689d:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    68a7:      	movq	%rax, 0x55(%rsp)
    68ac:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    68b6:      	movq	%rax, 0x50(%rsp)
    68bb:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    68c5:      	movq	%rax, 0x48(%rsp)
    68ca:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    68d4:      	movq	%rax, 0x40(%rsp)
    68d9:      	leaq	0x40(%rsp), %rdi
    68de:      	movl	$0x1d, %eax
    68e3:      	movl	$0x6, %r8d
    68e9:      	movzbl	(%rsp), %ecx
    68ed:      	movl	$0x1d, %esi
    68f2:      	movq	%r13, %rdx
    68f5:      	xorl	%eax, %eax
    68f7:      	callq	*%r8
    68fa:      	movzbl	(%rsp), %eax
    68fe:      	leal	0x1(%rax), %ecx
    6901:      	cmpb	$0x2, %cl
    6904:      	jb	0x2ea0 <kprobe_unwind_hotspot+0x2ea0>
    690a:      	jmp	0x371a <kprobe_unwind_hotspot+0x371a>
    690f:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    6919:      	movq	%rax, 0x55(%rsp)
    691e:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    6928:      	movq	%rax, 0x50(%rsp)
    692d:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    6937:      	movq	%rax, 0x48(%rsp)
    693c:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    6946:      	movq	%rax, 0x40(%rsp)
    694b:      	leaq	0x40(%rsp), %rdi
    6950:      	movl	$0x1d, %eax
    6955:      	movl	$0x6, %r8d
    695b:      	movzbl	(%rsp), %ecx
    695f:      	movl	$0x1d, %esi
    6964:      	movq	%r13, %rdx
    6967:      	xorl	%eax, %eax
    6969:      	callq	*%r8
    696c:      	movzbl	(%rsp), %eax
    6970:      	leal	0x1(%rax), %ecx
    6973:      	cmpb	$0x1, %cl
    6976:      	ja	0x22b <kprobe_unwind_hotspot+0x22b>
    697c:      	jmp	0x2ea0 <kprobe_unwind_hotspot+0x2ea0>
    6981:      	movabsq	$0xa786c252d786c, %rax  # imm = 0xA786C252D786C
    698b:      	movq	%rax, 0x4f(%rsp)
    6990:      	movabsq	$0x6c252065646f6320, %rax # imm = 0x6C252065646F6320
    699a:      	movq	%rax, 0x48(%rsp)
    699f:      	movabsq	$0x3e2d20203a6d766a, %rbx # imm = 0x3E2D20203A6D766A
    69a9:      	movq	%rbx, 0x40(%rsp)
    69ae:      	leaq	0x40(%rsp), %rdi
    69b3:      	movl	$0x17, %eax
    69b8:      	movl	$0x6, %r8d
    69be:      	movq	0xd0(%rsp), %rdx
    69c6:      	movq	0xd8(%rsp), %rcx
    69ce:      	movl	$0x17, %esi
    69d3:      	xorl	%eax, %eax
    69d5:      	callq	*%r8
    69d8:      	movq	(%rip), %rax            # 0x69df <kprobe_unwind_hotspot+0x69df>
    69df:      	cmpl	$0x0, (%rax)
    69e2:      	je	0x5577 <kprobe_unwind_hotspot+0x5577>
    69e8:      	movabsq	$0x783020657079745f, %rax # imm = 0x783020657079745F
    69f2:      	movq	%rax, 0x70(%rsp)
    69f7:      	movabsq	$0x656d617266202c75, %rax # imm = 0x656D617266202C75
    6a01:      	movq	%rax, 0x68(%rsp)
    6a06:      	movabsq	$0x2520657a69735f65, %rax # imm = 0x2520657A69735F65
    6a10:      	movq	%rax, 0x60(%rsp)
    6a15:      	movabsq	$0x6d617266202c7525, %rax # imm = 0x6D617266202C7525
    6a1f:      	movq	%rax, 0x58(%rsp)
    6a24:      	movabsq	$0x206574656c706d6f, %rax # imm = 0x206574656C706D6F
    6a2e:      	movq	%rax, 0x50(%rsp)
    6a33:      	movabsq	$0x635f656d61726620, %rax # imm = 0x635F656D61726620
    6a3d:      	movq	%rax, 0x48(%rsp)
    6a42:      	movq	%rbx, 0x40(%rsp)
    6a47:      	movl	$0xa7825, 0x78(%rsp)    # imm = 0xA7825
    6a4f:      	leaq	0x40(%rsp), %rdi
    6a54:      	movl	$0x3c, %eax
    6a59:      	movl	$0x6, %r9d
    6a5f:      	movzwl	0xf8(%rsp), %edx
    6a67:      	movl	0xe8(%rsp), %r8d
    6a6f:      	movl	0xf0(%rsp), %ecx
    6a76:      	movl	$0x3c, %esi
    6a7b:      	xorl	%eax, %eax
    6a7d:      	callq	*%r9
    6a80:      	jmp	0x5577 <kprobe_unwind_hotspot+0x5577>
    6a85:      	movabsq	$0xa64656c696166, %rax  # imm = 0xA64656C696166
    6a8f:      	movq	%rax, 0x68(%rsp)
    6a94:      	movabsq	$0x20797265766f6365, %rax # imm = 0x20797265766F6365
    6a9e:      	movq	%rax, 0x60(%rsp)
    6aa3:      	movabsq	$0x72206370202c656d, %rax # imm = 0x72206370202C656D
    6aad:      	movq	%rax, 0x58(%rsp)
    6ab2:      	movabsq	$0x6172662064657a69, %rax # imm = 0x6172662064657A69
    6abc:      	movq	%rax, 0x50(%rsp)
    6ac1:      	movabsq	$0x6d6974706f656420, %rax # imm = 0x6D6974706F656420
    6acb:      	movq	%rax, 0x48(%rsp)
    6ad0:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    6ada:      	movq	%rax, 0x40(%rsp)
    6adf:      	leaq	0x40(%rsp), %rdi
    6ae4:      	movl	$0x30, %eax
    6ae9:      	movl	$0x6, %ecx
    6aee:      	movl	$0x30, %esi
    6af3:      	xorl	%eax, %eax
    6af5:      	callq	*%rcx
    6af7:      	jmp	0x5736 <kprobe_unwind_hotspot+0x5736>
    6afc:      	movabsq	$0xa656c62617476, %rax  # imm = 0xA656C62617476
    6b06:      	movq	%rax, 0x50(%rsp)
    6b0b:      	movabsq	$0x20646e69776e7520, %rax # imm = 0x20646E69776E7520
    6b15:      	movq	%rax, 0x48(%rsp)
    6b1a:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    6b24:      	movq	%rax, 0x40(%rsp)
    6b29:      	leaq	0x40(%rsp), %rdi
    6b2e:      	movl	$0x18, %eax
    6b33:      	movl	$0x6, %ecx
    6b38:      	movl	$0x18, %esi
    6b3d:      	xorl	%eax, %eax
    6b3f:      	callq	*%rcx
    6b41:      	jmp	0x580a <kprobe_unwind_hotspot+0x580a>
    6b46:      	movabsq	$0x6170206b6361626c, %rax # imm = 0x6170206B6361626C
    6b50:      	movq	%rax, 0x58(%rsp)
    6b55:      	movabsq	$0x6c61662062757473, %rax # imm = 0x6C61662062757473
    6b5f:      	movq	%rax, 0x50(%rsp)
    6b64:      	movabsq	$0x20646e69776e7520, %rax # imm = 0x20646E69776E7520
    6b6e:      	movq	%rax, 0x48(%rsp)
    6b73:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    6b7d:      	movq	%rax, 0x40(%rsp)
    6b82:      	movl	$0xa6874, 0x60(%rsp)    # imm = 0xA6874
    6b8a:      	leaq	0x40(%rsp), %rdi
    6b8f:      	movl	$0x24, %eax
    6b94:      	movl	$0x6, %ecx
    6b99:      	movl	$0x24, %esi
    6b9e:      	xorl	%eax, %eax
    6ba0:      	callq	*%rcx
    6ba2:      	jmp	0x582f <kprobe_unwind_hotspot+0x582f>
    6ba7:      	movabsq	$0xa29646c252065, %rax  # imm = 0xA29646C252065
    6bb1:      	movq	%rax, 0x67(%rsp)
    6bb6:      	movabsq	$0x657a697320656d61, %rax # imm = 0x657A697320656D61
    6bc0:      	movq	%rax, 0x60(%rsp)
    6bc5:      	movabsq	$0x726628207265746e, %rax # imm = 0x726628207265746E
    6bcf:      	movq	%rax, 0x58(%rsp)
    6bd4:      	movabsq	$0x696f7020656d6172, %rax # imm = 0x696F7020656D6172
    6bde:      	movq	%rax, 0x50(%rsp)
    6be3:      	movabsq	$0x6620676e69737520, %rax # imm = 0x6620676E69737520
    6bed:      	movq	%rax, 0x48(%rsp)
    6bf2:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    6bfc:      	movq	%rax, 0x40(%rsp)
    6c01:      	leaq	0x40(%rsp), %rdi
    6c06:      	movl	$0x2f, %eax
    6c0b:      	movl	$0x6, %ecx
    6c10:      	movl	$0x2f, %esi
    6c15:      	xorl	%eax, %eax
    6c17:      	callq	*%rcx
    6c19:      	movq	0xa8(%rsp), %rcx
    6c21:      	jmp	0x5c73 <kprobe_unwind_hotspot+0x5c73>
    6c26:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    6c30:      	movq	%rax, 0x55(%rsp)
    6c35:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    6c3f:      	movq	%rax, 0x50(%rsp)
    6c44:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    6c4e:      	movq	%rax, 0x48(%rsp)
    6c53:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    6c5d:      	movq	%rax, 0x40(%rsp)
    6c62:      	leaq	0x40(%rsp), %rdi
    6c67:      	movl	$0x1d, %eax
    6c6c:      	movl	$0x6, %r8d
    6c72:      	movzbl	(%rsp), %ecx
    6c76:      	movl	$0x1d, %esi
    6c7b:      	movq	%r13, %rdx
    6c7e:      	xorl	%eax, %eax
    6c80:      	callq	*%r8
    6c83:      	movzbl	(%rsp), %eax
    6c87:      	leal	0x1(%rax), %ecx
    6c8a:      	cmpb	$0x2, %cl
    6c8d:      	jb	0x53f6 <kprobe_unwind_hotspot+0x53f6>
    6c93:      	jmp	0x5ac6 <kprobe_unwind_hotspot+0x5ac6>
    6c98:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    6ca2:      	movq	%rax, 0x55(%rsp)
    6ca7:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    6cb1:      	movq	%rax, 0x50(%rsp)
    6cb6:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    6cc0:      	movq	%rax, 0x48(%rsp)
    6cc5:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    6ccf:      	movq	%rax, 0x40(%rsp)
    6cd4:      	leaq	0x40(%rsp), %rdi
    6cd9:      	movl	$0x1d, %eax
    6cde:      	movl	$0x6, %r8d
    6ce4:      	movzbl	(%rsp), %ecx
    6ce8:      	movl	$0x1d, %esi
    6ced:      	movq	%r13, %rdx
    6cf0:      	xorl	%eax, %eax
    6cf2:      	callq	*%r8
    6cf5:      	movzbl	(%rsp), %eax
    6cf9:      	leal	0x1(%rax), %ecx
    6cfc:      	cmpb	$0x2, %cl
    6cff:      	jb	0x53f6 <kprobe_unwind_hotspot+0x53f6>
    6d05:      	jmp	0x5b0d <kprobe_unwind_hotspot+0x5b0d>
    6d0a:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    6d14:      	movq	%rax, 0x55(%rsp)
    6d19:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    6d23:      	movq	%rax, 0x50(%rsp)
    6d28:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    6d32:      	movq	%rax, 0x48(%rsp)
    6d37:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    6d41:      	movq	%rax, 0x40(%rsp)
    6d46:      	leaq	0x40(%rsp), %rdi
    6d4b:      	movl	$0x1d, %eax
    6d50:      	movl	$0x6, %r8d
    6d56:      	movzbl	(%rsp), %ecx
    6d5a:      	movl	$0x1d, %esi
    6d5f:      	movq	%r13, %rdx
    6d62:      	xorl	%eax, %eax
    6d64:      	callq	*%r8
    6d67:      	movzbl	(%rsp), %eax
    6d6b:      	leal	0x1(%rax), %ecx
    6d6e:      	cmpb	$0x2, %cl
    6d71:      	jb	0x53f6 <kprobe_unwind_hotspot+0x53f6>
    6d77:      	jmp	0x5b54 <kprobe_unwind_hotspot+0x5b54>
    6d7c:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    6d86:      	movq	%rax, 0x55(%rsp)
    6d8b:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    6d95:      	movq	%rax, 0x50(%rsp)
    6d9a:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    6da4:      	movq	%rax, 0x48(%rsp)
    6da9:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    6db3:      	movq	%rax, 0x40(%rsp)
    6db8:      	leaq	0x40(%rsp), %rdi
    6dbd:      	movl	$0x1d, %eax
    6dc2:      	movl	$0x6, %r8d
    6dc8:      	movzbl	(%rsp), %ecx
    6dcc:      	movl	$0x1d, %esi
    6dd1:      	movq	%r13, %rdx
    6dd4:      	xorl	%eax, %eax
    6dd6:      	callq	*%r8
    6dd9:      	movzbl	(%rsp), %eax
    6ddd:      	leal	0x1(%rax), %ecx
    6de0:      	cmpb	$0x2, %cl
    6de3:      	jb	0x53f6 <kprobe_unwind_hotspot+0x53f6>
    6de9:      	movzbl	%al, %eax
    6dec:      	subq	%rax, %r13
    6def:      	leaq	(%rbx,%r13), %rdx
    6df3:      	movq	%rsp, %rdi
    6df6:      	movl	$0x1, %eax
    6dfb:      	movl	$0x70, %ecx
    6e00:      	movl	$0x1, %esi
    6e05:      	callq	*%rcx
    6e07:      	testq	%rax, %rax
    6e0a:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    6e10:      	movq	(%rip), %rax            # 0x6e17 <kprobe_unwind_hotspot+0x6e17>
    6e17:      	cmpl	$0x0, (%rax)
    6e1a:      	je	0x6e79 <kprobe_unwind_hotspot+0x6e79>
    6e1c:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    6e26:      	movq	%rax, 0x55(%rsp)
    6e2b:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    6e35:      	movq	%rax, 0x50(%rsp)
    6e3a:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    6e44:      	movq	%rax, 0x48(%rsp)
    6e49:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    6e53:      	movq	%rax, 0x40(%rsp)
    6e58:      	leaq	0x40(%rsp), %rdi
    6e5d:      	movl	$0x1d, %eax
    6e62:      	movl	$0x6, %r8d
    6e68:      	movzbl	(%rsp), %ecx
    6e6c:      	movl	$0x1d, %esi
    6e71:      	movq	%r13, %rdx
    6e74:      	xorl	%eax, %eax
    6e76:      	callq	*%r8
    6e79:      	movzbl	(%rsp), %eax
    6e7d:      	leal	0x1(%rax), %ecx
    6e80:      	cmpb	$0x2, %cl
    6e83:      	jb	0x53f6 <kprobe_unwind_hotspot+0x53f6>
    6e89:      	movzbl	%al, %eax
    6e8c:      	subq	%rax, %r13
    6e8f:      	leaq	(%rbx,%r13), %rdx
    6e93:      	movq	%rsp, %rdi
    6e96:      	movl	$0x1, %eax
    6e9b:      	movl	$0x70, %ecx
    6ea0:      	movl	$0x1, %esi
    6ea5:      	callq	*%rcx
    6ea7:      	testq	%rax, %rax
    6eaa:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    6eb0:      	movq	(%rip), %rax            # 0x6eb7 <kprobe_unwind_hotspot+0x6eb7>
    6eb7:      	cmpl	$0x0, (%rax)
    6eba:      	je	0x6f19 <kprobe_unwind_hotspot+0x6f19>
    6ebc:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    6ec6:      	movq	%rax, 0x55(%rsp)
    6ecb:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    6ed5:      	movq	%rax, 0x50(%rsp)
    6eda:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    6ee4:      	movq	%rax, 0x48(%rsp)
    6ee9:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    6ef3:      	movq	%rax, 0x40(%rsp)
    6ef8:      	leaq	0x40(%rsp), %rdi
    6efd:      	movl	$0x1d, %eax
    6f02:      	movl	$0x6, %r8d
    6f08:      	movzbl	(%rsp), %ecx
    6f0c:      	movl	$0x1d, %esi
    6f11:      	movq	%r13, %rdx
    6f14:      	xorl	%eax, %eax
    6f16:      	callq	*%r8
    6f19:      	movzbl	(%rsp), %eax
    6f1d:      	leal	0x1(%rax), %ecx
    6f20:      	cmpb	$0x2, %cl
    6f23:      	jb	0x53f6 <kprobe_unwind_hotspot+0x53f6>
    6f29:      	movzbl	%al, %eax
    6f2c:      	subq	%rax, %r13
    6f2f:      	leaq	(%rbx,%r13), %rdx
    6f33:      	movq	%rsp, %rdi
    6f36:      	movl	$0x1, %eax
    6f3b:      	movl	$0x70, %ecx
    6f40:      	movl	$0x1, %esi
    6f45:      	callq	*%rcx
    6f47:      	testq	%rax, %rax
    6f4a:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    6f50:      	movq	(%rip), %rax            # 0x6f57 <kprobe_unwind_hotspot+0x6f57>
    6f57:      	cmpl	$0x0, (%rax)
    6f5a:      	je	0x6fb9 <kprobe_unwind_hotspot+0x6fb9>
    6f5c:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    6f66:      	movq	%rax, 0x55(%rsp)
    6f6b:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    6f75:      	movq	%rax, 0x50(%rsp)
    6f7a:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    6f84:      	movq	%rax, 0x48(%rsp)
    6f89:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    6f93:      	movq	%rax, 0x40(%rsp)
    6f98:      	leaq	0x40(%rsp), %rdi
    6f9d:      	movl	$0x1d, %eax
    6fa2:      	movl	$0x6, %r8d
    6fa8:      	movzbl	(%rsp), %ecx
    6fac:      	movl	$0x1d, %esi
    6fb1:      	movq	%r13, %rdx
    6fb4:      	xorl	%eax, %eax
    6fb6:      	callq	*%r8
    6fb9:      	movzbl	(%rsp), %eax
    6fbd:      	leal	0x1(%rax), %ecx
    6fc0:      	cmpb	$0x2, %cl
    6fc3:      	jb	0x53f6 <kprobe_unwind_hotspot+0x53f6>
    6fc9:      	movzbl	%al, %eax
    6fcc:      	subq	%rax, %r13
    6fcf:      	addq	%r13, %rbx
    6fd2:      	movq	%rsp, %rdi
    6fd5:      	movl	$0x1, %eax
    6fda:      	movl	$0x70, %ecx
    6fdf:      	movl	$0x1, %esi
    6fe4:      	movq	%rbx, %rdx
    6fe7:      	callq	*%rcx
    6fe9:      	testq	%rax, %rax
    6fec:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    6ff2:      	movq	(%rip), %rax            # 0x6ff9 <kprobe_unwind_hotspot+0x6ff9>
    6ff9:      	cmpl	$0x0, (%rax)
    6ffc:      	je	0x705b <kprobe_unwind_hotspot+0x705b>
    6ffe:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    7008:      	movq	%rax, 0x55(%rsp)
    700d:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    7017:      	movq	%rax, 0x50(%rsp)
    701c:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    7026:      	movq	%rax, 0x48(%rsp)
    702b:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    7035:      	movq	%rax, 0x40(%rsp)
    703a:      	leaq	0x40(%rsp), %rdi
    703f:      	movl	$0x1d, %eax
    7044:      	movl	$0x6, %r8d
    704a:      	movzbl	(%rsp), %ecx
    704e:      	movl	$0x1d, %esi
    7053:      	movq	%r13, %rdx
    7056:      	xorl	%eax, %eax
    7058:      	callq	*%r8
    705b:      	movzbl	(%rsp), %eax
    705f:      	leal	0x1(%rax), %ecx
    7062:      	cmpb	$0x1, %cl
    7065:      	ja	0x22b <kprobe_unwind_hotspot+0x22b>
    706b:      	jmp	0x53f6 <kprobe_unwind_hotspot+0x53f6>
    7070:      	movabsq	$0xa656d61726620, %rax  # imm = 0xA656D61726620
    707a:      	movq	%rax, 0x26(%rsp)
    707f:      	movabsq	$0x6620726574657270, %rax # imm = 0x6620726574657270
    7089:      	movq	%rax, 0x20(%rsp)
    708e:      	movabsq	$0x7265746e69206562, %rax # imm = 0x7265746E69206562
    7098:      	movq	%rax, 0x18(%rsp)
    709d:      	movabsq	$0x206f742079617761, %rax # imm = 0x206F742079617761
    70a7:      	movq	%rax, 0x10(%rsp)
    70ac:      	movabsq	$0x20726166206f6f74, %rax # imm = 0x20726166206F6F74
    70b6:      	movq	%rax, 0x8(%rsp)
    70bb:      	movabsq	$0x207066203a6d766a, %rax # imm = 0x207066203A6D766A
    70c5:      	movq	%rax, (%rsp)
    70c9:      	movq	%rsp, %rdi
    70cc:      	movl	$0x2e, %eax
    70d1:      	movl	$0x6, %ecx
    70d6:      	movl	$0x2e, %esi
    70db:      	xorl	%eax, %eax
    70dd:      	callq	*%rcx
    70df:      	jmp	0x5c2b <kprobe_unwind_hotspot+0x5c2b>
    70e4:      	movabsq	$0xa2963702b7066, %rax  # imm = 0xA2963702B7066
    70ee:      	movq	%rax, 0x65(%rsp)
    70f3:      	movabsq	$0x2b70662820656d61, %rax # imm = 0x2B70662820656D61
    70fd:      	movq	%rax, 0x60(%rsp)
    7102:      	movabsq	$0x7266206574656c70, %rax # imm = 0x7266206574656C70
    710c:      	movq	%rax, 0x58(%rsp)
    7111:      	movabsq	$0x6d6f636e6920676e, %rax # imm = 0x6D6F636E6920676E
    711b:      	movq	%rax, 0x50(%rsp)
    7120:      	movabsq	$0x69646e69776e7520, %rax # imm = 0x69646E69776E7520
    712a:      	movq	%rax, 0x48(%rsp)
    712f:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    7139:      	movq	%rax, 0x40(%rsp)
    713e:      	leaq	0x40(%rsp), %rdi
    7143:      	movl	$0x2d, %eax
    7148:      	movl	$0x6, %ecx
    714d:      	movl	$0x2d, %esi
    7152:      	xorl	%eax, %eax
    7154:      	callq	*%rcx
    7156:      	jmp	0x5c6e <kprobe_unwind_hotspot+0x5c6e>
    715b:      	movabsq	$0xa706620726576, %rax  # imm = 0xA706620726576
    7165:      	movq	%rax, 0x4d(%rsp)
    716a:      	movabsq	$0x7265766f63657220, %rax # imm = 0x7265766F63657220
    7174:      	movq	%rax, 0x48(%rsp)
    7179:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    7183:      	movq	%rax, 0x40(%rsp)
    7188:      	leaq	0x40(%rsp), %rdi
    718d:      	movl	$0x15, %eax
    7192:      	movl	$0x6, %ecx
    7197:      	movl	$0x15, %esi
    719c:      	xorl	%eax, %eax
    719e:      	callq	*%rcx
    71a0:      	jmp	0x5ccb <kprobe_unwind_hotspot+0x5ccb>
    71a5:      	movabsq	$0x25203a7066202c78, %rax # imm = 0x25203A7066202C78
    71af:      	movq	%rax, 0x58(%rsp)
    71b4:      	movabsq	$0x6c25203a7073202c, %rax # imm = 0x6C25203A7073202C
    71be:      	movq	%rax, 0x50(%rsp)
    71c3:      	movabsq	$0x786c25203a637020, %rax # imm = 0x786C25203A637020
    71cd:      	movq	%rax, 0x48(%rsp)
    71d2:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    71dc:      	movq	%rax, 0x40(%rsp)
    71e1:      	movl	$0xa786c, 0x60(%rsp)    # imm = 0xA786C
    71e9:      	leaq	0x40(%rsp), %rdi
    71ee:      	movl	$0x24, %eax
    71f3:      	movl	$0x6, %r9d
    71f9:      	movl	$0x24, %esi
    71fe:      	movq	%r12, %rdx
    7201:      	movq	0x38(%rsp), %rcx
    7206:      	movq	0xa8(%rsp), %r8
    720e:      	xorl	%eax, %eax
    7210:      	callq	*%r9
    7213:      	jmp	0x5d73 <kprobe_unwind_hotspot+0x5d73>
    7218:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    7222:      	movq	%rax, 0x66(%rsp)
    7227:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    7231:      	movq	%rax, 0x60(%rsp)
    7236:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    7240:      	movq	%rax, 0x58(%rsp)
    7245:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    724f:      	movq	%rax, 0x50(%rsp)
    7254:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    725e:      	movq	%rax, 0x48(%rsp)
    7263:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    726d:      	movq	%rax, 0x40(%rsp)
    7272:      	leaq	0x40(%rsp), %rdi
    7277:      	movl	$0x2e, %eax
    727c:      	movl	$0x6, %ecx
    7281:      	movl	(%rsp), %edx
    7284:      	movl	$0x2e, %esi
    7289:      	xorl	%eax, %eax
    728b:      	callq	*%rcx
    728d:      	jmp	0x5dbd <kprobe_unwind_hotspot+0x5dbd>
    7292:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    729c:      	movq	%rax, 0x68(%rsp)
    72a1:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    72ab:      	movq	%rax, 0x60(%rsp)
    72b0:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    72ba:      	movq	%rax, 0x58(%rsp)
    72bf:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    72c9:      	movq	%rax, 0x50(%rsp)
    72ce:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    72d8:      	movq	%rax, 0x48(%rsp)
    72dd:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    72e7:      	movq	%rax, 0x40(%rsp)
    72ec:      	movb	$0x0, 0x70(%rsp)
    72f1:      	leaq	0x40(%rsp), %rdi
    72f6:      	movl	$0x31, %eax
    72fb:      	movl	$0x6, %ecx
    7300:      	movl	0x2c0(%r14), %edx
    7307:      	movl	$0x31, %esi
    730c:      	xorl	%eax, %eax
    730e:      	callq	*%rcx
    7310:      	movq	0xed0(%r14), %rbx
    7317:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    7321:      	cmpq	%rax, %rbx
    7324:      	ja	0x1049 <kprobe_unwind_hotspot+0x1049>
    732a:      	jmp	0x5e05 <kprobe_unwind_hotspot+0x5e05>
    732f:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    7339:      	movq	%rax, 0x68(%rsp)
    733e:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    7348:      	movq	%rax, 0x60(%rsp)
    734d:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    7357:      	movq	%rax, 0x58(%rsp)
    735c:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    7366:      	movq	%rax, 0x50(%rsp)
    736b:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    7375:      	movq	%rax, 0x48(%rsp)
    737a:      	movabsq	$0x6365732074786554, %r13 # imm = 0x6365732074786554
    7384:      	movq	%r13, 0x40(%rsp)
    7389:      	movw	$0xa, 0x70(%rsp)
    7390:      	leaq	0x40(%rsp), %rdi
    7395:      	movl	$0x32, %eax
    739a:      	movl	$0x6, %r9d
    73a0:      	movq	0xf10(%r14), %rcx
    73a7:      	movl	$0x32, %esi
    73ac:      	movq	%rbx, %rdx
    73af:      	movl	%r12d, %r8d
    73b2:      	xorl	%eax, %eax
    73b4:      	callq	*%r9
    73b7:      	movq	(%rip), %rax            # 0x73be <kprobe_unwind_hotspot+0x73be>
    73be:      	cmpl	$0x0, (%rax)
    73c1:      	je	0x5e98 <kprobe_unwind_hotspot+0x5e98>
    73c7:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    73d1:      	movq	%rax, 0x67(%rsp)
    73d6:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    73e0:      	movq	%rax, 0x60(%rsp)
    73e5:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    73ef:      	movq	%rax, 0x58(%rsp)
    73f4:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    73fe:      	movq	%rax, 0x50(%rsp)
    7403:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    740d:      	movq	%rax, 0x48(%rsp)
    7412:      	movq	%r13, 0x40(%rsp)
    7417:      	leaq	0x40(%rsp), %rdi
    741c:      	movl	$0x2f, %eax
    7421:      	movl	$0x6, %r8d
    7427:      	movq	0xf18(%r14), %rcx
    742e:      	movq	0xf20(%r14), %rdx
    7435:      	movl	$0x2f, %esi
    743a:      	xorl	%eax, %eax
    743c:      	callq	*%r8
    743f:      	jmp	0x5e98 <kprobe_unwind_hotspot+0x5e98>
    7444:      	movabsq	$0xa642520686374, %rax  # imm = 0xA642520686374
    744e:      	movq	%rax, 0x56(%rsp)
    7453:      	movabsq	$0x6374616d20737465, %rax # imm = 0x6374616D20737465
    745d:      	movq	%rax, 0x50(%rsp)
    7462:      	movabsq	$0x7366666f5f726574, %rax # imm = 0x7366666F5F726574
    746c:      	movq	%rax, 0x48(%rsp)
    7471:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    747b:      	movq	%rax, 0x40(%rsp)
    7480:      	leaq	0x40(%rsp), %rdi
    7485:      	movl	$0x1e, %eax
    748a:      	movl	$0x6, %ecx
    748f:      	movzwl	0x20(%rbx), %edx
    7493:      	movl	$0x1e, %esi
    7498:      	xorl	%eax, %eax
    749a:      	callq	*%rcx
    749c:      	movl	0x1380(%r14), %eax
    74a3:      	movl	0x20(%rbx), %ecx
    74a6:      	btl	%ecx, %eax
    74a9:      	jb	0x5f22 <kprobe_unwind_hotspot+0x5f22>
    74af:      	movl	$0x0, (%rsp)
    74b6:      	movq	(%rip), %rdi            # 0x74bd <kprobe_unwind_hotspot+0x74bd>
    74bd:      	movq	%rsp, %rsi
    74c0:      	movl	$0x1, %eax
    74c5:      	callq	*%rax
    74c7:      	testq	%rax, %rax
    74ca:      	je	0x7a0d <kprobe_unwind_hotspot+0x7a0d>
    74d0:      	incq	(%rax)
    74d3:      	jmp	0x7a8e <kprobe_unwind_hotspot+0x7a8e>
    74d8:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    74e2:      	movq	%rax, 0x18(%rsp)
    74e7:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    74f1:      	movq	%rax, 0x10(%rsp)
    74f6:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    7500:      	movq	%rax, 0x8(%rsp)
    7505:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    750f:      	movq	%rax, (%rsp)
    7513:      	movw	$0xa, 0x20(%rsp)
    751a:      	movq	%rsp, %rdi
    751d:      	movl	$0x22, %eax
    7522:      	movl	$0x6, %r8d
    7528:      	movq	0x40(%rsp), %rcx
    752d:      	movl	$0x22, %esi
    7532:      	xorl	%edx, %edx
    7534:      	xorl	%eax, %eax
    7536:      	callq	*%r8
    7539:      	jmp	0x5fb7 <kprobe_unwind_hotspot+0x5fb7>
    753e:      	movabsq	$0xa2964252b7073, %rax  # imm = 0xA2964252B7073
    7548:      	movq	%rax, 0x78(%rsp)
    754d:      	movabsq	$0x206d6f7266282078, %rax # imm = 0x206D6F7266282078
    7557:      	movq	%rax, 0x70(%rsp)
    755c:      	movabsq	$0x6c25783020736120, %rax # imm = 0x6C25783020736120
    7566:      	movq	%rax, 0x68(%rsp)
    756b:      	movabsq	$0x64657265766f6365, %rax # imm = 0x64657265766F6365
    7575:      	movq	%rax, 0x60(%rsp)
    757a:      	movabsq	$0x72206370202c656d, %rax # imm = 0x72206370202C656D
    7584:      	movq	%rax, 0x58(%rsp)
    7589:      	movabsq	$0x6172662064657a69, %rax # imm = 0x6172662064657A69
    7593:      	movq	%rax, 0x50(%rsp)
    7598:      	movabsq	$0x6d6974706f656420, %rax # imm = 0x6D6974706F656420
    75a2:      	movq	%rax, 0x48(%rsp)
    75a7:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    75b1:      	movq	%rax, 0x40(%rsp)
    75b6:      	leaq	0x40(%rsp), %rdi
    75bb:      	movl	$0x40, %eax
    75c0:      	movl	$0x6, %r8d
    75c6:      	movq	(%rsp), %rdx
    75ca:      	movl	0xec(%rsp), %ecx
    75d1:      	movl	$0x40, %esi
    75d6:      	xorl	%eax, %eax
    75d8:      	callq	*%r8
    75db:      	movq	(%rsp), %rax
    75df:      	movq	0xd0(%rsp), %rcx
    75e7:      	jmp	0x60c7 <kprobe_unwind_hotspot+0x60c7>
    75ec:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    75f6:      	movq	%rax, 0x26(%rsp)
    75fb:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    7605:      	movq	%rax, 0x20(%rsp)
    760a:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    7614:      	movq	%rax, 0x18(%rsp)
    7619:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    7623:      	movq	%rax, 0x10(%rsp)
    7628:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    7632:      	movq	%rax, 0x8(%rsp)
    7637:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7641:      	movq	%rax, (%rsp)
    7645:      	movq	%rsp, %rdi
    7648:      	movl	$0x2e, %eax
    764d:      	movl	$0x6, %ecx
    7652:      	movl	0x114(%rsp), %edx
    7659:      	movl	$0x2e, %esi
    765e:      	xorl	%eax, %eax
    7660:      	callq	*%rcx
    7662:      	jmp	0x60eb <kprobe_unwind_hotspot+0x60eb>
    7667:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    7671:      	movq	%rax, 0x18(%rsp)
    7676:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    7680:      	movq	%rax, 0x10(%rsp)
    7685:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    768f:      	movq	%rax, 0x8(%rsp)
    7694:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    769e:      	movq	%rax, (%rsp)
    76a2:      	movw	$0xa, 0x20(%rsp)
    76a9:      	movq	%rsp, %rdi
    76ac:      	movl	$0x22, %eax
    76b1:      	movl	$0x6, %r8d
    76b7:      	movq	0x48(%rsp), %rcx
    76bc:      	movl	$0x22, %esi
    76c1:      	movl	$0x1, %edx
    76c6:      	xorl	%eax, %eax
    76c8:      	callq	*%r8
    76cb:      	jmp	0x611d <kprobe_unwind_hotspot+0x611d>
    76d0:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    76da:      	movq	%rax, 0x18(%rsp)
    76df:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    76e9:      	movq	%rax, 0x10(%rsp)
    76ee:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    76f8:      	movq	%rax, 0x8(%rsp)
    76fd:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    7707:      	movq	%rax, (%rsp)
    770b:      	movw	$0xa, 0x20(%rsp)
    7712:      	movq	%rsp, %rdi
    7715:      	movl	$0x22, %eax
    771a:      	movl	$0x6, %r8d
    7720:      	movq	0x50(%rsp), %rcx
    7725:      	movl	$0x22, %esi
    772a:      	movl	$0x2, %edx
    772f:      	xorl	%eax, %eax
    7731:      	callq	*%r8
    7734:      	jmp	0x617e <kprobe_unwind_hotspot+0x617e>
    7739:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    7743:      	movq	%rax, 0x18(%rsp)
    7748:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    7752:      	movq	%rax, 0x10(%rsp)
    7757:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    7761:      	movq	%rax, 0x8(%rsp)
    7766:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    7770:      	movq	%rax, (%rsp)
    7774:      	movw	$0xa, 0x20(%rsp)
    777b:      	movq	%rsp, %rdi
    777e:      	movl	$0x22, %eax
    7783:      	movl	$0x6, %r8d
    7789:      	movq	0x58(%rsp), %rcx
    778e:      	movl	$0x22, %esi
    7793:      	movl	$0x3, %edx
    7798:      	xorl	%eax, %eax
    779a:      	callq	*%r8
    779d:      	jmp	0x62ee <kprobe_unwind_hotspot+0x62ee>
    77a2:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    77ac:      	movq	%rax, 0x18(%rsp)
    77b1:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    77bb:      	movq	%rax, 0x10(%rsp)
    77c0:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    77ca:      	movq	%rax, 0x8(%rsp)
    77cf:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    77d9:      	movq	%rax, (%rsp)
    77dd:      	movw	$0xa, 0x20(%rsp)
    77e4:      	movq	%rsp, %rdi
    77e7:      	movl	$0x22, %eax
    77ec:      	movl	$0x6, %r8d
    77f2:      	movq	0x60(%rsp), %rcx
    77f7:      	movl	$0x22, %esi
    77fc:      	movl	$0x4, %edx
    7801:      	xorl	%eax, %eax
    7803:      	callq	*%r8
    7806:      	jmp	0x634f <kprobe_unwind_hotspot+0x634f>
    780b:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    7815:      	movq	%rax, 0x18(%rsp)
    781a:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    7824:      	movq	%rax, 0x10(%rsp)
    7829:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    7833:      	movq	%rax, 0x8(%rsp)
    7838:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    7842:      	movq	%rax, (%rsp)
    7846:      	movw	$0xa, 0x20(%rsp)
    784d:      	movq	%rsp, %rdi
    7850:      	movl	$0x22, %eax
    7855:      	movl	$0x6, %r8d
    785b:      	movq	0x68(%rsp), %rcx
    7860:      	movl	$0x22, %esi
    7865:      	movl	$0x5, %edx
    786a:      	xorl	%eax, %eax
    786c:      	callq	*%r8
    786f:      	jmp	0x64a4 <kprobe_unwind_hotspot+0x64a4>
    7874:      	movabsq	$0xa7364726f7720, %rax  # imm = 0xA7364726F7720
    787e:      	movq	%rax, 0x26(%rsp)
    7883:      	movabsq	$0x77206425202b2065, %rax # imm = 0x77206425202B2065
    788d:      	movq	%rax, 0x20(%rsp)
    7892:      	movabsq	$0x6d61726620657465, %rax # imm = 0x6D61726620657465
    789c:      	movq	%rax, 0x18(%rsp)
    78a1:      	movabsq	$0x6c706d6f6320676e, %rax # imm = 0x6C706D6F6320676E
    78ab:      	movq	%rax, 0x10(%rsp)
    78b0:      	movabsq	$0x69646e69776e7520, %rax # imm = 0x69646E69776E7520
    78ba:      	movq	%rax, 0x8(%rsp)
    78bf:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    78c9:      	movq	%rax, (%rsp)
    78cd:      	movq	%rsp, %rdi
    78d0:      	movl	$0x2e, %eax
    78d5:      	movl	$0x6, %ecx
    78da:      	xorl	%ebx, %ebx
    78dc:      	movl	$0x2e, %esi
    78e1:      	xorl	%eax, %eax
    78e3:      	callq	*%rcx
    78e5:      	jmp	0x6515 <kprobe_unwind_hotspot+0x6515>
    78ea:      	movabsq	$0xa786c25203d20, %rax  # imm = 0xA786C25203D20
    78f4:      	movq	%rax, 0x2d(%rsp)
    78f9:      	movabsq	$0x203d20706362202c, %rax # imm = 0x203D20706362202C
    7903:      	movq	%rax, 0x28(%rsp)
    7908:      	movabsq	$0x786c257830203d20, %rax # imm = 0x786C257830203D20
    7912:      	movq	%rax, 0x20(%rsp)
    7917:      	movabsq	$0x646f6874656d6320, %rax # imm = 0x646F6874656D6320
    7921:      	movq	%rax, 0x18(%rsp)
    7926:      	movabsq	$0x2c786c257830203d, %rax # imm = 0x2C786C257830203D
    7930:      	movq	%rax, 0x10(%rsp)
    7935:      	movabsq	$0x20646f6874656d20, %rax # imm = 0x20646F6874656D20
    793f:      	movq	%rax, 0x8(%rsp)
    7944:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    794e:      	movq	%rax, (%rsp)
    7952:      	movq	%rsp, %rdi
    7955:      	movl	$0x35, %eax
    795a:      	movl	$0x6, %r9d
    7960:      	movq	0x100(%rsp), %rcx
    7968:      	movl	$0x35, %esi
    796d:      	movq	0x108(%rsp), %rdx
    7975:      	movq	%r13, %r8
    7978:      	xorl	%eax, %eax
    797a:      	callq	*%r9
    797d:      	movq	0x100(%rsp), %rax
    7985:      	movq	%rax, 0xb8(%rsp)
    798d:      	jmp	0x66dd <kprobe_unwind_hotspot+0x66dd>
    7992:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    799c:      	movq	%rax, 0x26(%rsp)
    79a1:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    79ab:      	movq	%rax, 0x20(%rsp)
    79b0:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    79ba:      	movq	%rax, 0x18(%rsp)
    79bf:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    79c9:      	movq	%rax, 0x10(%rsp)
    79ce:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    79d8:      	movq	%rax, 0x8(%rsp)
    79dd:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    79e7:      	movq	%rax, (%rsp)
    79eb:      	movq	%rsp, %rdi
    79ee:      	movl	$0x2e, %eax
    79f3:      	movl	$0x6, %ecx
    79f8:      	movl	0x100(%rsp), %edx
    79ff:      	movl	$0x2e, %esi
    7a04:      	xorl	%eax, %eax
    7a06:      	callq	*%rcx
    7a08:      	jmp	0x67ac <kprobe_unwind_hotspot+0x67ac>
    7a0d:      	movq	(%rip), %rax            # 0x7a14 <kprobe_unwind_hotspot+0x7a14>
    7a14:      	cmpl	$0x0, (%rax)
    7a17:      	je	0x7a8e <kprobe_unwind_hotspot+0x7a8e>
    7a19:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    7a23:      	movq	%rax, 0x66(%rsp)
    7a28:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    7a32:      	movq	%rax, 0x60(%rsp)
    7a37:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    7a41:      	movq	%rax, 0x58(%rsp)
    7a46:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    7a50:      	movq	%rax, 0x50(%rsp)
    7a55:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    7a5f:      	movq	%rax, 0x48(%rsp)
    7a64:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7a6e:      	movq	%rax, 0x40(%rsp)
    7a73:      	leaq	0x40(%rsp), %rdi
    7a78:      	movl	$0x2e, %eax
    7a7d:      	movl	$0x6, %ecx
    7a82:      	movl	(%rsp), %edx
    7a85:      	movl	$0x2e, %esi
    7a8a:      	xorl	%eax, %eax
    7a8c:      	callq	*%rcx
    7a8e:      	movzwl	0x20(%rbx), %r12d
    7a93:      	cmpl	$0x2, %r12d
    7a97:      	jne	0x34c <kprobe_unwind_hotspot+0x34c>
    7a9d:      	movl	$0x29, 0xc8(%rsp)
    7aa8:      	movq	(%rip), %rdi            # 0x7aaf <kprobe_unwind_hotspot+0x7aaf>
    7aaf:      	leaq	0xc8(%rsp), %rsi
    7ab7:      	movl	$0x1, %eax
    7abc:      	callq	*%rax
    7abe:      	testq	%rax, %rax
    7ac1:      	je	0x7b88 <kprobe_unwind_hotspot+0x7b88>
    7ac7:      	incq	(%rax)
    7aca:      	movq	(%rip), %rax            # 0x7ad1 <kprobe_unwind_hotspot+0x7ad1>
    7ad1:      	cmpl	$0x0, (%rax)
    7ad4:      	movq	0xed0(%r14), %rax
    7adb:      	movq	%rax, 0xb8(%rsp)
    7ae3:      	movq	0xed8(%r14), %rax
    7aea:      	movq	%rax, 0x38(%rsp)
    7aef:      	movq	0xee0(%r14), %rax
    7af6:      	movq	%rax, 0xa8(%rsp)
    7afe:      	je	0x7bc2 <kprobe_unwind_hotspot+0x7bc2>
    7b04:      	movabsq	$0x252074657366666f, %rax # imm = 0x252074657366666F
    7b0e:      	movq	%rax, 0x60(%rsp)
    7b13:      	movabsq	$0x202c786c25207472, %rax # imm = 0x202C786C25207472
    7b1d:      	movq	%rax, 0x58(%rsp)
    7b22:      	movabsq	$0x6174732065646f63, %rax # imm = 0x6174732065646F63
    7b2c:      	movq	%rax, 0x50(%rsp)
    7b31:      	movabsq	$0x206e6920786c2520, %rax # imm = 0x206E6920786C2520
    7b3b:      	movq	%rax, 0x48(%rsp)
    7b40:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    7b4a:      	movq	%rax, 0x40(%rsp)
    7b4f:      	movl	$0xa786c, 0x68(%rsp)    # imm = 0xA786C
    7b57:      	leaq	0x40(%rsp), %rdi
    7b5c:      	movl	$0x2c, %eax
    7b61:      	movl	$0x6, %r9d
    7b67:      	movq	0xf20(%r14), %rcx
    7b6e:      	movq	0xed0(%r14), %rdx
    7b75:      	movq	0xf18(%r14), %r8
    7b7c:      	movl	$0x2c, %esi
    7b81:      	xorl	%eax, %eax
    7b83:      	callq	*%r9
    7b86:      	jmp	0x7bc2 <kprobe_unwind_hotspot+0x7bc2>
    7b88:      	movq	(%rip), %rax            # 0x7b8f <kprobe_unwind_hotspot+0x7b8f>
    7b8f:      	cmpl	$0x0, (%rax)
    7b92:      	jne	0x802c <kprobe_unwind_hotspot+0x802c>
    7b98:      	movq	0xed0(%r14), %rax
    7b9f:      	movq	%rax, 0xb8(%rsp)
    7ba7:      	movq	0xed8(%r14), %rax
    7bae:      	movq	%rax, 0x38(%rsp)
    7bb3:      	movq	0xee0(%r14), %rax
    7bba:      	movq	%rax, 0xa8(%rsp)
    7bc2:      	movzbl	0x20(%r15), %eax
    7bc7:      	shrxq	%rax, 0xf18(%r14), %r13
    7bd0:      	movq	0xf10(%r14), %rbx
    7bd7:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    7be1:      	andq	%rax, %rbx
    7be4:      	leaq	(%rbx,%r13), %rdx
    7be8:      	movq	%rsp, %rdi
    7beb:      	movl	$0x1, %eax
    7bf0:      	movl	$0x70, %ecx
    7bf5:      	movl	$0x1, %esi
    7bfa:      	callq	*%rcx
    7bfc:      	testq	%rax, %rax
    7bff:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    7c05:      	movq	(%rip), %rax            # 0x7c0c <kprobe_unwind_hotspot+0x7c0c>
    7c0c:      	cmpl	$0x0, (%rax)
    7c0f:      	jne	0x80aa <kprobe_unwind_hotspot+0x80aa>
    7c15:      	movzbl	(%rsp), %eax
    7c19:      	leal	0x1(%rax), %ecx
    7c1c:      	cmpb	$0x2, %cl
    7c1f:      	jae	0x8117 <kprobe_unwind_hotspot+0x8117>
    7c25:      	testb	%al, %al
    7c27:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    7c2d:      	movzbl	0x20(%r15), %eax
    7c32:      	shlxq	%rax, %r13, %rax
    7c37:      	addq	0xf20(%r14), %rax
    7c3e:      	movzbl	0x1b(%r15), %ebx
    7c43:      	addq	%rax, %rbx
    7c46:      	movq	(%rip), %rax            # 0x7c4d <kprobe_unwind_hotspot+0x7c4d>
    7c4d:      	cmpl	$0x0, (%rax)
    7c50:      	je	0x7cae <kprobe_unwind_hotspot+0x7cae>
    7c52:      	movabsq	$0xa786c2520626f6c, %rax # imm = 0xA786C2520626F6C
    7c5c:      	movq	%rax, 0x58(%rsp)
    7c61:      	movabsq	$0x6265646f63206f74, %rax # imm = 0x6265646F63206F74
    7c6b:      	movq	%rax, 0x50(%rsp)
    7c70:      	movabsq	$0x2064657070616d20, %rax # imm = 0x2064657070616D20
    7c7a:      	movq	%rax, 0x48(%rsp)
    7c7f:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    7c89:      	movq	%rax, 0x40(%rsp)
    7c8e:      	movb	$0x0, 0x60(%rsp)
    7c93:      	leaq	0x40(%rsp), %rdi
    7c98:      	movl	$0x21, %eax
    7c9d:      	movl	$0x6, %ecx
    7ca2:      	movl	$0x21, %esi
    7ca7:      	movq	%rbx, %rdx
    7caa:      	xorl	%eax, %eax
    7cac:      	callq	*%rcx
    7cae:      	movq	%rbx, 0xc8(%rsp)
    7cb6:      	testq	%rbx, %rbx
    7cb9:      	je	0x237 <kprobe_unwind_hotspot+0x237>
    7cbf:      	movl	$0x200, %eax            # imm = 0x200
    7cc4:      	movl	$0x70, %ecx
    7cc9:      	movq	0x120(%rsp), %rdi
    7cd1:      	movq	0xc8(%rsp), %rdx
    7cd9:      	movl	$0x200, %esi            # imm = 0x200
    7cde:      	callq	*%rcx
    7ce0:      	testq	%rax, %rax
    7ce3:      	jne	0x300 <kprobe_unwind_hotspot+0x300>
    7ce9:      	movzwl	0x10(%r15), %eax
    7cee:      	movl	$0x1, %ebx
    7cf3:      	cmpq	$0x1f8, %rax            # imm = 0x1F8
    7cf9:      	ja	0x347 <kprobe_unwind_hotspot+0x347>
    7cff:      	movzwl	0x12(%r15), %ecx
    7d04:      	cmpq	$0x1fc, %rcx            # imm = 0x1FC
    7d0b:      	ja	0x347 <kprobe_unwind_hotspot+0x347>
    7d11:      	movzwl	0x14(%r15), %edx
    7d16:      	cmpq	$0x1f8, %rdx            # imm = 0x1F8
    7d1d:      	ja	0x347 <kprobe_unwind_hotspot+0x347>
    7d23:      	movzbl	0x17(%r15), %esi
    7d28:      	movq	0x120(%rsp), %rdi
    7d30:      	movq	(%rdi,%rsi), %rsi
    7d34:      	movq	%rsi, 0xd0(%rsp)
    7d3c:      	movzbl	0x18(%r15), %esi
    7d41:      	movq	(%rdi,%rsi), %rsi
    7d45:      	movq	%rsi, 0xd8(%rsp)
    7d4d:      	movzbl	0x1a(%r15), %esi
    7d52:      	movl	(%rdi,%rsi), %esi
    7d55:      	shll	$0x3, %esi
    7d58:      	movl	%esi, 0xf0(%rsp)
    7d5f:      	movzbl	0x19(%r15), %esi
    7d64:      	movzwl	(%rdi,%rsi), %esi
    7d68:      	movw	%si, 0xf8(%rsp)
    7d70:      	movl	(%rdi,%rcx), %ecx
    7d73:      	movl	%ecx, 0xf4(%rsp)
    7d7a:      	movl	(%rdi,%rdx), %ecx
    7d7d:      	movl	%ecx, 0xec(%rsp)
    7d84:      	movq	(%rdi,%rax), %rax
    7d88:      	movq	%rax, 0xe0(%rsp)
    7d90:      	movzbl	0x16(%r15), %eax
    7d95:      	movq	(%rdi,%rax), %rdx
    7d99:      	movl	$0x4, %eax
    7d9e:      	movl	$0x70, %ecx
    7da3:      	leaq	0xe8(%rsp), %rdi
    7dab:      	movl	$0x4, %esi
    7db0:      	callq	*%rcx
    7db2:      	testq	%rax, %rax
    7db5:      	jne	0x300 <kprobe_unwind_hotspot+0x300>
    7dbb:      	cmpb	$0x0, 0x21(%r15)
    7dc0:      	je	0x7dee <kprobe_unwind_hotspot+0x7dee>
    7dc2:      	movq	0xc8(%rsp), %rax
    7dca:      	movl	0xd0(%rsp), %ecx
    7dd1:      	addq	%rax, %rcx
    7dd4:      	movq	%rcx, 0xd0(%rsp)
    7ddc:      	movl	0xd8(%rsp), %ecx
    7de3:      	addq	%rax, %rcx
    7de6:      	movq	%rcx, 0xd8(%rsp)
    7dee:      	movq	(%rip), %rax            # 0x7df5 <kprobe_unwind_hotspot+0x7df5>
    7df5:      	cmpl	$0x0, (%rax)
    7df8:      	je	0x7efd <kprobe_unwind_hotspot+0x7efd>
    7dfe:      	movabsq	$0xa786c252d786c, %rax  # imm = 0xA786C252D786C
    7e08:      	movq	%rax, 0x4f(%rsp)
    7e0d:      	movabsq	$0x6c252065646f6320, %rax # imm = 0x6C252065646F6320
    7e17:      	movq	%rax, 0x48(%rsp)
    7e1c:      	movabsq	$0x3e2d20203a6d766a, %rbx # imm = 0x3E2D20203A6D766A
    7e26:      	movq	%rbx, 0x40(%rsp)
    7e2b:      	leaq	0x40(%rsp), %rdi
    7e30:      	movl	$0x17, %eax
    7e35:      	movl	$0x6, %r8d
    7e3b:      	movq	0xd0(%rsp), %rdx
    7e43:      	movq	0xd8(%rsp), %rcx
    7e4b:      	movl	$0x17, %esi
    7e50:      	xorl	%eax, %eax
    7e52:      	callq	*%r8
    7e55:      	movq	(%rip), %rax            # 0x7e5c <kprobe_unwind_hotspot+0x7e5c>
    7e5c:      	cmpl	$0x0, (%rax)
    7e5f:      	je	0x7efd <kprobe_unwind_hotspot+0x7efd>
    7e65:      	movabsq	$0x783020657079745f, %rax # imm = 0x783020657079745F
    7e6f:      	movq	%rax, 0x70(%rsp)
    7e74:      	movabsq	$0x656d617266202c75, %rax # imm = 0x656D617266202C75
    7e7e:      	movq	%rax, 0x68(%rsp)
    7e83:      	movabsq	$0x2520657a69735f65, %rax # imm = 0x2520657A69735F65
    7e8d:      	movq	%rax, 0x60(%rsp)
    7e92:      	movabsq	$0x6d617266202c7525, %rax # imm = 0x6D617266202C7525
    7e9c:      	movq	%rax, 0x58(%rsp)
    7ea1:      	movabsq	$0x206574656c706d6f, %rax # imm = 0x206574656C706D6F
    7eab:      	movq	%rax, 0x50(%rsp)
    7eb0:      	movabsq	$0x635f656d61726620, %rax # imm = 0x635F656D61726620
    7eba:      	movq	%rax, 0x48(%rsp)
    7ebf:      	movq	%rbx, 0x40(%rsp)
    7ec4:      	movl	$0xa7825, 0x78(%rsp)    # imm = 0xA7825
    7ecc:      	leaq	0x40(%rsp), %rdi
    7ed1:      	movl	$0x3c, %eax
    7ed6:      	movl	$0x6, %r9d
    7edc:      	movzwl	0xf8(%rsp), %edx
    7ee4:      	movl	0xe8(%rsp), %r8d
    7eec:      	movl	0xf0(%rsp), %ecx
    7ef3:      	movl	$0x3c, %esi
    7ef8:      	xorl	%eax, %eax
    7efa:      	callq	*%r9
    7efd:      	movq	0xc8(%rsp), %rax
    7f05:      	movq	%rax, 0xc0(%rsp)
    7f0d:      	movq	0xd0(%rsp), %rax
    7f15:      	movl	0xe8(%rsp), %edx
    7f1c:      	movq	0xb8(%rsp), %rcx
    7f24:      	subl	%eax, %ecx
    7f26:      	movq	%rcx, 0x118(%rsp)
    7f2e:      	movq	%rdx, 0x120(%rsp)
    7f36:      	cmpl	$0x6974616d, %edx       # imm = 0x6974616D
    7f3c:      	jg	0x87fe <kprobe_unwind_hotspot+0x87fe>
    7f42:      	cmpl	$0x62617476, 0x120(%rsp) # imm = 0x62617476
    7f4d:      	je	0x8981 <kprobe_unwind_hotspot+0x8981>
    7f53:      	cmpl	$0x65746e49, 0x120(%rsp) # imm = 0x65746E49
    7f5e:      	jne	0x8a86 <kprobe_unwind_hotspot+0x8a86>
    7f64:      	movabsq	$0xa656d61726620, %r12  # imm = 0xA656D61726620
    7f6e:      	movq	0x38(%rsp), %rax
    7f73:      	cmpq	%rax, 0xa8(%rsp)
    7f7b:      	jb	0x89ed <kprobe_unwind_hotspot+0x89ed>
    7f81:      	movq	0x38(%rsp), %rax
    7f86:      	addq	$0x1000, %rax           # imm = 0x1000
    7f8c:      	cmpq	%rax, 0xa8(%rsp)
    7f94:      	jae	0x89ed <kprobe_unwind_hotspot+0x89ed>
    7f9a:      	movq	0xa8(%rsp), %rax
    7fa2:      	leaq	-0x50(%rax), %rdx
    7fa6:      	leaq	0x40(%rsp), %rdi
    7fab:      	movl	$0x60, %eax
    7fb0:      	movl	$0x70, %ecx
    7fb5:      	movl	$0x60, %esi
    7fba:      	callq	*%rcx
    7fbc:      	movabsq	$0x2072657465727072, %rbx # imm = 0x2072657465727072
    7fc6:      	testq	%rax, %rax
    7fc9:      	je	0x8a63 <kprobe_unwind_hotspot+0x8a63>
    7fcf:      	movq	(%rip), %rax            # 0x7fd6 <kprobe_unwind_hotspot+0x7fd6>
    7fd6:      	cmpl	$0x0, (%rax)
    7fd9:      	je	0x8d2a <kprobe_unwind_hotspot+0x8d2a>
    7fdf:      	movq	%r12, 0x1f(%rsp)
    7fe4:      	movq	%rbx, 0x18(%rsp)
    7fe9:      	movabsq	$0x65746e6920646165, %rax # imm = 0x65746E6920646165
    7ff3:      	movq	%rax, 0x10(%rsp)
    7ff8:      	movabsq	$0x72206f742064656c, %rax # imm = 0x72206F742064656C
    8002:      	movq	%rax, 0x8(%rsp)
    8007:      	movabsq	$0x696166203a6d766a, %rax # imm = 0x696166203A6D766A
    8011:      	movq	%rax, (%rsp)
    8015:      	movq	%rsp, %rdi
    8018:      	movl	$0x27, %eax
    801d:      	movl	$0x6, %ecx
    8022:      	movl	$0x27, %esi
    8027:      	jmp	0x8d26 <kprobe_unwind_hotspot+0x8d26>
    802c:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    8036:      	movq	%rax, 0x66(%rsp)
    803b:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    8045:      	movq	%rax, 0x60(%rsp)
    804a:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    8054:      	movq	%rax, 0x58(%rsp)
    8059:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    8063:      	movq	%rax, 0x50(%rsp)
    8068:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    8072:      	movq	%rax, 0x48(%rsp)
    8077:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    8081:      	movq	%rax, 0x40(%rsp)
    8086:      	leaq	0x40(%rsp), %rdi
    808b:      	movl	$0x2e, %eax
    8090:      	movl	$0x6, %ecx
    8095:      	movl	0xc8(%rsp), %edx
    809c:      	movl	$0x2e, %esi
    80a1:      	xorl	%eax, %eax
    80a3:      	callq	*%rcx
    80a5:      	jmp	0x7aca <kprobe_unwind_hotspot+0x7aca>
    80aa:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    80b4:      	movq	%rax, 0x55(%rsp)
    80b9:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    80c3:      	movq	%rax, 0x50(%rsp)
    80c8:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    80d2:      	movq	%rax, 0x48(%rsp)
    80d7:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    80e1:      	movq	%rax, 0x40(%rsp)
    80e6:      	leaq	0x40(%rsp), %rdi
    80eb:      	movl	$0x1d, %eax
    80f0:      	movl	$0x6, %r8d
    80f6:      	movzbl	(%rsp), %ecx
    80fa:      	movl	$0x1d, %esi
    80ff:      	movq	%r13, %rdx
    8102:      	xorl	%eax, %eax
    8104:      	callq	*%r8
    8107:      	movzbl	(%rsp), %eax
    810b:      	leal	0x1(%rax), %ecx
    810e:      	cmpb	$0x2, %cl
    8111:      	jb	0x7c25 <kprobe_unwind_hotspot+0x7c25>
    8117:      	movzbl	%al, %eax
    811a:      	subq	%rax, %r13
    811d:      	leaq	(%rbx,%r13), %rdx
    8121:      	movq	%rsp, %rdi
    8124:      	movl	$0x1, %eax
    8129:      	movl	$0x70, %ecx
    812e:      	movl	$0x1, %esi
    8133:      	callq	*%rcx
    8135:      	testq	%rax, %rax
    8138:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    813e:      	movq	(%rip), %rax            # 0x8145 <kprobe_unwind_hotspot+0x8145>
    8145:      	cmpl	$0x0, (%rax)
    8148:      	je	0x81a7 <kprobe_unwind_hotspot+0x81a7>
    814a:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    8154:      	movq	%rax, 0x55(%rsp)
    8159:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    8163:      	movq	%rax, 0x50(%rsp)
    8168:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    8172:      	movq	%rax, 0x48(%rsp)
    8177:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    8181:      	movq	%rax, 0x40(%rsp)
    8186:      	leaq	0x40(%rsp), %rdi
    818b:      	movl	$0x1d, %eax
    8190:      	movl	$0x6, %r8d
    8196:      	movzbl	(%rsp), %ecx
    819a:      	movl	$0x1d, %esi
    819f:      	movq	%r13, %rdx
    81a2:      	xorl	%eax, %eax
    81a4:      	callq	*%r8
    81a7:      	movzbl	(%rsp), %eax
    81ab:      	leal	0x1(%rax), %ecx
    81ae:      	cmpb	$0x2, %cl
    81b1:      	jb	0x7c25 <kprobe_unwind_hotspot+0x7c25>
    81b7:      	movzbl	%al, %eax
    81ba:      	subq	%rax, %r13
    81bd:      	leaq	(%rbx,%r13), %rdx
    81c1:      	movq	%rsp, %rdi
    81c4:      	movl	$0x1, %eax
    81c9:      	movl	$0x70, %ecx
    81ce:      	movl	$0x1, %esi
    81d3:      	callq	*%rcx
    81d5:      	testq	%rax, %rax
    81d8:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    81de:      	movq	(%rip), %rax            # 0x81e5 <kprobe_unwind_hotspot+0x81e5>
    81e5:      	cmpl	$0x0, (%rax)
    81e8:      	je	0x8247 <kprobe_unwind_hotspot+0x8247>
    81ea:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    81f4:      	movq	%rax, 0x55(%rsp)
    81f9:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    8203:      	movq	%rax, 0x50(%rsp)
    8208:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    8212:      	movq	%rax, 0x48(%rsp)
    8217:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    8221:      	movq	%rax, 0x40(%rsp)
    8226:      	leaq	0x40(%rsp), %rdi
    822b:      	movl	$0x1d, %eax
    8230:      	movl	$0x6, %r8d
    8236:      	movzbl	(%rsp), %ecx
    823a:      	movl	$0x1d, %esi
    823f:      	movq	%r13, %rdx
    8242:      	xorl	%eax, %eax
    8244:      	callq	*%r8
    8247:      	movzbl	(%rsp), %eax
    824b:      	leal	0x1(%rax), %ecx
    824e:      	cmpb	$0x2, %cl
    8251:      	jb	0x7c25 <kprobe_unwind_hotspot+0x7c25>
    8257:      	movzbl	%al, %eax
    825a:      	subq	%rax, %r13
    825d:      	leaq	(%rbx,%r13), %rdx
    8261:      	movq	%rsp, %rdi
    8264:      	movl	$0x1, %eax
    8269:      	movl	$0x70, %ecx
    826e:      	movl	$0x1, %esi
    8273:      	callq	*%rcx
    8275:      	testq	%rax, %rax
    8278:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    827e:      	movq	(%rip), %rax            # 0x8285 <kprobe_unwind_hotspot+0x8285>
    8285:      	cmpl	$0x0, (%rax)
    8288:      	je	0x82e7 <kprobe_unwind_hotspot+0x82e7>
    828a:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    8294:      	movq	%rax, 0x55(%rsp)
    8299:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    82a3:      	movq	%rax, 0x50(%rsp)
    82a8:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    82b2:      	movq	%rax, 0x48(%rsp)
    82b7:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    82c1:      	movq	%rax, 0x40(%rsp)
    82c6:      	leaq	0x40(%rsp), %rdi
    82cb:      	movl	$0x1d, %eax
    82d0:      	movl	$0x6, %r8d
    82d6:      	movzbl	(%rsp), %ecx
    82da:      	movl	$0x1d, %esi
    82df:      	movq	%r13, %rdx
    82e2:      	xorl	%eax, %eax
    82e4:      	callq	*%r8
    82e7:      	movzbl	(%rsp), %eax
    82eb:      	leal	0x1(%rax), %ecx
    82ee:      	cmpb	$0x2, %cl
    82f1:      	jb	0x7c25 <kprobe_unwind_hotspot+0x7c25>
    82f7:      	movzbl	%al, %eax
    82fa:      	subq	%rax, %r13
    82fd:      	leaq	(%rbx,%r13), %rdx
    8301:      	movq	%rsp, %rdi
    8304:      	movl	$0x1, %eax
    8309:      	movl	$0x70, %ecx
    830e:      	movl	$0x1, %esi
    8313:      	callq	*%rcx
    8315:      	testq	%rax, %rax
    8318:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    831e:      	movq	(%rip), %rax            # 0x8325 <kprobe_unwind_hotspot+0x8325>
    8325:      	cmpl	$0x0, (%rax)
    8328:      	je	0x8387 <kprobe_unwind_hotspot+0x8387>
    832a:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    8334:      	movq	%rax, 0x55(%rsp)
    8339:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    8343:      	movq	%rax, 0x50(%rsp)
    8348:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    8352:      	movq	%rax, 0x48(%rsp)
    8357:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    8361:      	movq	%rax, 0x40(%rsp)
    8366:      	leaq	0x40(%rsp), %rdi
    836b:      	movl	$0x1d, %eax
    8370:      	movl	$0x6, %r8d
    8376:      	movzbl	(%rsp), %ecx
    837a:      	movl	$0x1d, %esi
    837f:      	movq	%r13, %rdx
    8382:      	xorl	%eax, %eax
    8384:      	callq	*%r8
    8387:      	movzbl	(%rsp), %eax
    838b:      	leal	0x1(%rax), %ecx
    838e:      	cmpb	$0x2, %cl
    8391:      	jb	0x7c25 <kprobe_unwind_hotspot+0x7c25>
    8397:      	movzbl	%al, %eax
    839a:      	subq	%rax, %r13
    839d:      	leaq	(%rbx,%r13), %rdx
    83a1:      	movq	%rsp, %rdi
    83a4:      	movl	$0x1, %eax
    83a9:      	movl	$0x70, %ecx
    83ae:      	movl	$0x1, %esi
    83b3:      	callq	*%rcx
    83b5:      	testq	%rax, %rax
    83b8:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    83be:      	movq	(%rip), %rax            # 0x83c5 <kprobe_unwind_hotspot+0x83c5>
    83c5:      	cmpl	$0x0, (%rax)
    83c8:      	je	0x8427 <kprobe_unwind_hotspot+0x8427>
    83ca:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    83d4:      	movq	%rax, 0x55(%rsp)
    83d9:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    83e3:      	movq	%rax, 0x50(%rsp)
    83e8:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    83f2:      	movq	%rax, 0x48(%rsp)
    83f7:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    8401:      	movq	%rax, 0x40(%rsp)
    8406:      	leaq	0x40(%rsp), %rdi
    840b:      	movl	$0x1d, %eax
    8410:      	movl	$0x6, %r8d
    8416:      	movzbl	(%rsp), %ecx
    841a:      	movl	$0x1d, %esi
    841f:      	movq	%r13, %rdx
    8422:      	xorl	%eax, %eax
    8424:      	callq	*%r8
    8427:      	movzbl	(%rsp), %eax
    842b:      	leal	0x1(%rax), %ecx
    842e:      	cmpb	$0x2, %cl
    8431:      	jb	0x7c25 <kprobe_unwind_hotspot+0x7c25>
    8437:      	movzbl	%al, %eax
    843a:      	subq	%rax, %r13
    843d:      	leaq	(%rbx,%r13), %rdx
    8441:      	movq	%rsp, %rdi
    8444:      	movl	$0x1, %eax
    8449:      	movl	$0x70, %ecx
    844e:      	movl	$0x1, %esi
    8453:      	callq	*%rcx
    8455:      	testq	%rax, %rax
    8458:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    845e:      	movq	(%rip), %rax            # 0x8465 <kprobe_unwind_hotspot+0x8465>
    8465:      	cmpl	$0x0, (%rax)
    8468:      	je	0x84c7 <kprobe_unwind_hotspot+0x84c7>
    846a:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    8474:      	movq	%rax, 0x55(%rsp)
    8479:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    8483:      	movq	%rax, 0x50(%rsp)
    8488:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    8492:      	movq	%rax, 0x48(%rsp)
    8497:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    84a1:      	movq	%rax, 0x40(%rsp)
    84a6:      	leaq	0x40(%rsp), %rdi
    84ab:      	movl	$0x1d, %eax
    84b0:      	movl	$0x6, %r8d
    84b6:      	movzbl	(%rsp), %ecx
    84ba:      	movl	$0x1d, %esi
    84bf:      	movq	%r13, %rdx
    84c2:      	xorl	%eax, %eax
    84c4:      	callq	*%r8
    84c7:      	movzbl	(%rsp), %eax
    84cb:      	leal	0x1(%rax), %ecx
    84ce:      	cmpb	$0x2, %cl
    84d1:      	jb	0x7c25 <kprobe_unwind_hotspot+0x7c25>
    84d7:      	movzbl	%al, %eax
    84da:      	subq	%rax, %r13
    84dd:      	leaq	(%rbx,%r13), %rdx
    84e1:      	movq	%rsp, %rdi
    84e4:      	movl	$0x1, %eax
    84e9:      	movl	$0x70, %ecx
    84ee:      	movl	$0x1, %esi
    84f3:      	callq	*%rcx
    84f5:      	testq	%rax, %rax
    84f8:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    84fe:      	movq	(%rip), %rax            # 0x8505 <kprobe_unwind_hotspot+0x8505>
    8505:      	cmpl	$0x0, (%rax)
    8508:      	je	0x8567 <kprobe_unwind_hotspot+0x8567>
    850a:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    8514:      	movq	%rax, 0x55(%rsp)
    8519:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    8523:      	movq	%rax, 0x50(%rsp)
    8528:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    8532:      	movq	%rax, 0x48(%rsp)
    8537:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    8541:      	movq	%rax, 0x40(%rsp)
    8546:      	leaq	0x40(%rsp), %rdi
    854b:      	movl	$0x1d, %eax
    8550:      	movl	$0x6, %r8d
    8556:      	movzbl	(%rsp), %ecx
    855a:      	movl	$0x1d, %esi
    855f:      	movq	%r13, %rdx
    8562:      	xorl	%eax, %eax
    8564:      	callq	*%r8
    8567:      	movzbl	(%rsp), %eax
    856b:      	leal	0x1(%rax), %ecx
    856e:      	cmpb	$0x2, %cl
    8571:      	jb	0x7c25 <kprobe_unwind_hotspot+0x7c25>
    8577:      	movzbl	%al, %eax
    857a:      	subq	%rax, %r13
    857d:      	leaq	(%rbx,%r13), %rdx
    8581:      	movq	%rsp, %rdi
    8584:      	movl	$0x1, %eax
    8589:      	movl	$0x70, %ecx
    858e:      	movl	$0x1, %esi
    8593:      	callq	*%rcx
    8595:      	testq	%rax, %rax
    8598:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    859e:      	movq	(%rip), %rax            # 0x85a5 <kprobe_unwind_hotspot+0x85a5>
    85a5:      	cmpl	$0x0, (%rax)
    85a8:      	je	0x8607 <kprobe_unwind_hotspot+0x8607>
    85aa:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    85b4:      	movq	%rax, 0x55(%rsp)
    85b9:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    85c3:      	movq	%rax, 0x50(%rsp)
    85c8:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    85d2:      	movq	%rax, 0x48(%rsp)
    85d7:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    85e1:      	movq	%rax, 0x40(%rsp)
    85e6:      	leaq	0x40(%rsp), %rdi
    85eb:      	movl	$0x1d, %eax
    85f0:      	movl	$0x6, %r8d
    85f6:      	movzbl	(%rsp), %ecx
    85fa:      	movl	$0x1d, %esi
    85ff:      	movq	%r13, %rdx
    8602:      	xorl	%eax, %eax
    8604:      	callq	*%r8
    8607:      	movzbl	(%rsp), %eax
    860b:      	leal	0x1(%rax), %ecx
    860e:      	cmpb	$0x2, %cl
    8611:      	jb	0x7c25 <kprobe_unwind_hotspot+0x7c25>
    8617:      	movzbl	%al, %eax
    861a:      	subq	%rax, %r13
    861d:      	leaq	(%rbx,%r13), %rdx
    8621:      	movq	%rsp, %rdi
    8624:      	movl	$0x1, %eax
    8629:      	movl	$0x70, %ecx
    862e:      	movl	$0x1, %esi
    8633:      	callq	*%rcx
    8635:      	testq	%rax, %rax
    8638:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    863e:      	movq	(%rip), %rax            # 0x8645 <kprobe_unwind_hotspot+0x8645>
    8645:      	cmpl	$0x0, (%rax)
    8648:      	je	0x86a7 <kprobe_unwind_hotspot+0x86a7>
    864a:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    8654:      	movq	%rax, 0x55(%rsp)
    8659:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    8663:      	movq	%rax, 0x50(%rsp)
    8668:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    8672:      	movq	%rax, 0x48(%rsp)
    8677:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    8681:      	movq	%rax, 0x40(%rsp)
    8686:      	leaq	0x40(%rsp), %rdi
    868b:      	movl	$0x1d, %eax
    8690:      	movl	$0x6, %r8d
    8696:      	movzbl	(%rsp), %ecx
    869a:      	movl	$0x1d, %esi
    869f:      	movq	%r13, %rdx
    86a2:      	xorl	%eax, %eax
    86a4:      	callq	*%r8
    86a7:      	movzbl	(%rsp), %eax
    86ab:      	leal	0x1(%rax), %ecx
    86ae:      	cmpb	$0x2, %cl
    86b1:      	jb	0x7c25 <kprobe_unwind_hotspot+0x7c25>
    86b7:      	movzbl	%al, %eax
    86ba:      	subq	%rax, %r13
    86bd:      	leaq	(%rbx,%r13), %rdx
    86c1:      	movq	%rsp, %rdi
    86c4:      	movl	$0x1, %eax
    86c9:      	movl	$0x70, %ecx
    86ce:      	movl	$0x1, %esi
    86d3:      	callq	*%rcx
    86d5:      	testq	%rax, %rax
    86d8:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    86de:      	movq	(%rip), %rax            # 0x86e5 <kprobe_unwind_hotspot+0x86e5>
    86e5:      	cmpl	$0x0, (%rax)
    86e8:      	je	0x8747 <kprobe_unwind_hotspot+0x8747>
    86ea:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    86f4:      	movq	%rax, 0x55(%rsp)
    86f9:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    8703:      	movq	%rax, 0x50(%rsp)
    8708:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    8712:      	movq	%rax, 0x48(%rsp)
    8717:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    8721:      	movq	%rax, 0x40(%rsp)
    8726:      	leaq	0x40(%rsp), %rdi
    872b:      	movl	$0x1d, %eax
    8730:      	movl	$0x6, %r8d
    8736:      	movzbl	(%rsp), %ecx
    873a:      	movl	$0x1d, %esi
    873f:      	movq	%r13, %rdx
    8742:      	xorl	%eax, %eax
    8744:      	callq	*%r8
    8747:      	movzbl	(%rsp), %eax
    874b:      	leal	0x1(%rax), %ecx
    874e:      	cmpb	$0x2, %cl
    8751:      	jb	0x7c25 <kprobe_unwind_hotspot+0x7c25>
    8757:      	movzbl	%al, %eax
    875a:      	subq	%rax, %r13
    875d:      	addq	%r13, %rbx
    8760:      	movq	%rsp, %rdi
    8763:      	movl	$0x1, %eax
    8768:      	movl	$0x70, %ecx
    876d:      	movl	$0x1, %esi
    8772:      	movq	%rbx, %rdx
    8775:      	callq	*%rcx
    8777:      	testq	%rax, %rax
    877a:      	jne	0x22b <kprobe_unwind_hotspot+0x22b>
    8780:      	movq	(%rip), %rax            # 0x8787 <kprobe_unwind_hotspot+0x8787>
    8787:      	cmpl	$0x0, (%rax)
    878a:      	je	0x87e9 <kprobe_unwind_hotspot+0x87e9>
    878c:      	movabsq	$0xa752520676174, %rax  # imm = 0xA752520676174
    8796:      	movq	%rax, 0x55(%rsp)
    879b:      	movabsq	$0x676174202c756c25, %rax # imm = 0x676174202C756C25
    87a5:      	movq	%rax, 0x50(%rsp)
    87aa:      	movabsq	$0x20746e656d676573, %rax # imm = 0x20746E656D676573
    87b4:      	movq	%rax, 0x48(%rsp)
    87b9:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    87c3:      	movq	%rax, 0x40(%rsp)
    87c8:      	leaq	0x40(%rsp), %rdi
    87cd:      	movl	$0x1d, %eax
    87d2:      	movl	$0x6, %r8d
    87d8:      	movzbl	(%rsp), %ecx
    87dc:      	movl	$0x1d, %esi
    87e1:      	movq	%r13, %rdx
    87e4:      	xorl	%eax, %eax
    87e6:      	callq	*%r8
    87e9:      	movzbl	(%rsp), %eax
    87ed:      	leal	0x1(%rax), %ecx
    87f0:      	cmpb	$0x1, %cl
    87f3:      	ja	0x22b <kprobe_unwind_hotspot+0x22b>
    87f9:      	jmp	0x7c25 <kprobe_unwind_hotspot+0x7c25>
    87fe:      	cmpl	$0x6974616e, 0x120(%rsp) # imm = 0x6974616E
    8809:      	je	0x881c <kprobe_unwind_hotspot+0x881c>
    880b:      	cmpl	$0x74656d6e, 0x120(%rsp) # imm = 0x74656D6E
    8816:      	jne	0x8a86 <kprobe_unwind_hotspot+0x8a86>
    881c:      	movl	0xf4(%rsp), %ecx
    8823:      	movq	%rcx, 0x120(%rsp)
    882b:      	movq	0xe0(%rsp), %rcx
    8833:      	movl	%ecx, %edx
    8835:      	addq	0xc0(%rsp), %rdx
    883d:      	cmpb	$0x0, 0x21(%r15)
    8842:      	cmoveq	%rcx, %rdx
    8846:      	cmpq	%rdx, 0xb8(%rsp)
    884e:      	jne	0x8b9b <kprobe_unwind_hotspot+0x8b9b>
    8854:      	movl	0xec(%rsp), %eax
    885b:      	movq	0x38(%rsp), %rsi
    8860:      	addq	%rsi, %rax
    8863:      	movq	%rsp, %rdi
    8866:      	movl	$0x8, %ecx
    886b:      	movl	$0x70, %r8d
    8871:      	movl	0xec(%rsp), %edx
    8878:      	addq	%rsi, %rdx
    887b:      	movl	$0x8, %esi
    8880:      	callq	*%r8
    8883:      	testq	%rax, %rax
    8886:      	jne	0x8b15 <kprobe_unwind_hotspot+0x8b15>
    888c:      	movq	(%rsp), %rax
    8890:      	movq	0xd0(%rsp), %rcx
    8898:      	cmpq	%rcx, %rax
    889b:      	jb	0x8b15 <kprobe_unwind_hotspot+0x8b15>
    88a1:      	cmpq	0xd8(%rsp), %rax
    88a9:      	jae	0x8b15 <kprobe_unwind_hotspot+0x8b15>
    88af:      	movq	(%rip), %rdx            # 0x88b6 <kprobe_unwind_hotspot+0x88b6>
    88b6:      	cmpl	$0x0, (%rdx)
    88b9:      	je	0x8968 <kprobe_unwind_hotspot+0x8968>
    88bf:      	movabsq	$0xa2964252b7073, %rax  # imm = 0xA2964252B7073
    88c9:      	movq	%rax, 0x78(%rsp)
    88ce:      	movabsq	$0x206d6f7266282078, %rax # imm = 0x206D6F7266282078
    88d8:      	movq	%rax, 0x70(%rsp)
    88dd:      	movabsq	$0x6c25783020736120, %rax # imm = 0x6C25783020736120
    88e7:      	movq	%rax, 0x68(%rsp)
    88ec:      	movabsq	$0x64657265766f6365, %rax # imm = 0x64657265766F6365
    88f6:      	movq	%rax, 0x60(%rsp)
    88fb:      	movabsq	$0x72206370202c656d, %rax # imm = 0x72206370202C656D
    8905:      	movq	%rax, 0x58(%rsp)
    890a:      	movabsq	$0x6172662064657a69, %rax # imm = 0x6172662064657A69
    8914:      	movq	%rax, 0x50(%rsp)
    8919:      	movabsq	$0x6d6974706f656420, %rax # imm = 0x6D6974706F656420
    8923:      	movq	%rax, 0x48(%rsp)
    8928:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    8932:      	movq	%rax, 0x40(%rsp)
    8937:      	leaq	0x40(%rsp), %rdi
    893c:      	movl	$0x40, %eax
    8941:      	movl	$0x6, %r8d
    8947:      	movq	(%rsp), %rdx
    894b:      	movl	0xec(%rsp), %ecx
    8952:      	movl	$0x40, %esi
    8957:      	xorl	%eax, %eax
    8959:      	callq	*%r8
    895c:      	movq	(%rsp), %rax
    8960:      	movq	0xd0(%rsp), %rcx
    8968:      	movl	%eax, %edx
    896a:      	subl	%ecx, %edx
    896c:      	movq	%rdx, 0x118(%rsp)
    8974:      	movq	%rax, 0xb8(%rsp)
    897c:      	jmp	0x8b93 <kprobe_unwind_hotspot+0x8b93>
    8981:      	movb	$0x1, %al
    8983:      	movl	%eax, 0xb0(%rsp)
    898a:      	movl	$0x62617476, %eax       # imm = 0x62617476
    898f:      	movq	%rax, 0x120(%rsp)
    8997:      	movq	(%rip), %rax            # 0x899e <kprobe_unwind_hotspot+0x899e>
    899e:      	cmpl	$0x0, (%rax)
    89a1:      	je	0x96a7 <kprobe_unwind_hotspot+0x96a7>
    89a7:      	movabsq	$0xa656c62617476, %rax  # imm = 0xA656C62617476
    89b1:      	movq	%rax, 0x50(%rsp)
    89b6:      	movabsq	$0x20646e69776e7520, %rax # imm = 0x20646E69776E7520
    89c0:      	movq	%rax, 0x48(%rsp)
    89c5:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    89cf:      	movq	%rax, 0x40(%rsp)
    89d4:      	leaq	0x40(%rsp), %rdi
    89d9:      	movl	$0x18, %eax
    89de:      	movl	$0x6, %ecx
    89e3:      	movl	$0x18, %esi
    89e8:      	jmp	0x8c46 <kprobe_unwind_hotspot+0x8c46>
    89ed:      	movq	(%rip), %rax            # 0x89f4 <kprobe_unwind_hotspot+0x89f4>
    89f4:      	cmpl	$0x0, (%rax)
    89f7:      	je	0x8d2a <kprobe_unwind_hotspot+0x8d2a>
    89fd:      	movq	%r12, 0x26(%rsp)
    8a02:      	movabsq	$0x6620726574657270, %rax # imm = 0x6620726574657270
    8a0c:      	movq	%rax, 0x20(%rsp)
    8a11:      	movabsq	$0x7265746e69206562, %rax # imm = 0x7265746E69206562
    8a1b:      	movq	%rax, 0x18(%rsp)
    8a20:      	movabsq	$0x206f742079617761, %rax # imm = 0x206F742079617761
    8a2a:      	movq	%rax, 0x10(%rsp)
    8a2f:      	movabsq	$0x20726166206f6f74, %rax # imm = 0x20726166206F6F74
    8a39:      	movq	%rax, 0x8(%rsp)
    8a3e:      	movabsq	$0x207066203a6d766a, %rax # imm = 0x207066203A6D766A
    8a48:      	movq	%rax, (%rsp)
    8a4c:      	movq	%rsp, %rdi
    8a4f:      	movl	$0x2e, %eax
    8a54:      	movl	$0x6, %ecx
    8a59:      	movl	$0x2e, %esi
    8a5e:      	jmp	0x8d26 <kprobe_unwind_hotspot+0x8d26>
    8a63:      	cmpl	$0x0, 0x2c0(%r14)
    8a6b:      	je	0x8c4f <kprobe_unwind_hotspot+0x8c4f>
    8a71:      	cmpb	$0x0, 0x1f(%r15)
    8a76:      	je	0x8c58 <kprobe_unwind_hotspot+0x8c58>
    8a7c:      	movq	0x50(%rsp), %r13
    8a81:      	jmp	0x8c5d <kprobe_unwind_hotspot+0x8c5d>
    8a86:      	movq	(%rip), %rax            # 0x8a8d <kprobe_unwind_hotspot+0x8a8d>
    8a8d:      	cmpl	$0x0, (%rax)
    8a90:      	je	0x8aee <kprobe_unwind_hotspot+0x8aee>
    8a92:      	movabsq	$0x6170206b6361626c, %rax # imm = 0x6170206B6361626C
    8a9c:      	movq	%rax, 0x58(%rsp)
    8aa1:      	movabsq	$0x6c61662062757473, %rax # imm = 0x6C61662062757473
    8aab:      	movq	%rax, 0x50(%rsp)
    8ab0:      	movabsq	$0x20646e69776e7520, %rax # imm = 0x20646E69776E7520
    8aba:      	movq	%rax, 0x48(%rsp)
    8abf:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    8ac9:      	movq	%rax, 0x40(%rsp)
    8ace:      	movl	$0xa6874, 0x60(%rsp)    # imm = 0xA6874
    8ad6:      	leaq	0x40(%rsp), %rdi
    8adb:      	movl	$0x24, %eax
    8ae0:      	movl	$0x6, %ecx
    8ae5:      	movl	$0x24, %esi
    8aea:      	xorl	%eax, %eax
    8aec:      	callq	*%rcx
    8aee:      	movl	0xf0(%rsp), %eax
    8af5:      	movl	$0x0, 0xb0(%rsp)
    8b00:      	movq	0xa8(%rsp), %rcx
    8b08:      	testl	%eax, %eax
    8b0a:      	jne	0x96e3 <kprobe_unwind_hotspot+0x96e3>
    8b10:      	jmp	0x96ce <kprobe_unwind_hotspot+0x96ce>
    8b15:      	movq	(%rip), %rax            # 0x8b1c <kprobe_unwind_hotspot+0x8b1c>
    8b1c:      	cmpl	$0x0, (%rax)
    8b1f:      	je	0x8b93 <kprobe_unwind_hotspot+0x8b93>
    8b21:      	movabsq	$0xa64656c696166, %rax  # imm = 0xA64656C696166
    8b2b:      	movq	%rax, 0x68(%rsp)
    8b30:      	movabsq	$0x20797265766f6365, %rax # imm = 0x20797265766F6365
    8b3a:      	movq	%rax, 0x60(%rsp)
    8b3f:      	movabsq	$0x72206370202c656d, %rax # imm = 0x72206370202C656D
    8b49:      	movq	%rax, 0x58(%rsp)
    8b4e:      	movabsq	$0x6172662064657a69, %rax # imm = 0x6172662064657A69
    8b58:      	movq	%rax, 0x50(%rsp)
    8b5d:      	movabsq	$0x6d6974706f656420, %rax # imm = 0x6D6974706F656420
    8b67:      	movq	%rax, 0x48(%rsp)
    8b6c:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    8b76:      	movq	%rax, 0x40(%rsp)
    8b7b:      	leaq	0x40(%rsp), %rdi
    8b80:      	movl	$0x30, %eax
    8b85:      	movl	$0x6, %ecx
    8b8a:      	movl	$0x30, %esi
    8b8f:      	xorl	%eax, %eax
    8b91:      	callq	*%rcx
    8b93:      	movq	0xd0(%rsp), %rax
    8b9b:      	movzwl	0xf8(%rsp), %ecx
    8ba3:      	addq	%rax, %rcx
    8ba6:      	cmpq	%rcx, 0xb8(%rsp)
    8bae:      	jae	0x8d5c <kprobe_unwind_hotspot+0x8d5c>
    8bb4:      	addq	$-0x4, %rcx
    8bb8:      	movq	(%rip), %rax            # 0x8bbf <kprobe_unwind_hotspot+0x8bbf>
    8bbf:      	movl	(%rax), %eax
    8bc1:      	cmpq	%rcx, 0xb8(%rsp)
    8bc9:      	jae	0x8e23 <kprobe_unwind_hotspot+0x8e23>
    8bcf:      	movb	$0x3, %cl
    8bd1:      	movl	%ecx, 0xb0(%rsp)
    8bd8:      	testl	%eax, %eax
    8bda:      	je	0x96a7 <kprobe_unwind_hotspot+0x96a7>
    8be0:      	movabsq	$0x2963702820656d61, %rax # imm = 0x2963702820656D61
    8bea:      	movq	%rax, 0x60(%rsp)
    8bef:      	movabsq	$0x7266206574656c70, %rax # imm = 0x7266206574656C70
    8bf9:      	movq	%rax, 0x58(%rsp)
    8bfe:      	movabsq	$0x6d6f636e6920676e, %rax # imm = 0x6D6F636E6920676E
    8c08:      	movq	%rax, 0x50(%rsp)
    8c0d:      	movabsq	$0x69646e69776e7520, %rax # imm = 0x69646E69776E7520
    8c17:      	movq	%rax, 0x48(%rsp)
    8c1c:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    8c26:      	movq	%rax, 0x40(%rsp)
    8c2b:      	movw	$0xa, 0x68(%rsp)
    8c32:      	leaq	0x40(%rsp), %rdi
    8c37:      	movl	$0x2a, %eax
    8c3c:      	movl	$0x6, %ecx
    8c41:      	movl	$0x2a, %esi
    8c46:      	xorl	%eax, %eax
    8c48:      	callq	*%rcx
    8c4a:      	jmp	0x96a7 <kprobe_unwind_hotspot+0x96a7>
    8c4f:      	movq	0xf00(%r14), %r13
    8c56:      	jmp	0x8c5d <kprobe_unwind_hotspot+0x8c5d>
    8c58:      	movq	0x58(%rsp), %r13
    8c5d:      	movq	0x78(%rsp), %r12
    8c62:      	movq	0x88(%rsp), %rax
    8c6a:      	movq	%rax, 0x38(%rsp)
    8c6f:      	movq	0x90(%rsp), %rax
    8c77:      	movq	%rax, 0xa8(%rsp)
    8c7f:      	movq	0x98(%rsp), %rax
    8c87:      	movq	%rax, 0xb8(%rsp)
    8c8f:      	movzbl	0x1c(%r15), %eax
    8c94:      	addq	%r12, %rax
    8c97:      	leaq	0x100(%rsp), %rdi
    8c9f:      	movl	$0x8, %ecx
    8ca4:      	movl	$0x70, %r8d
    8caa:      	movzbl	0x1c(%r15), %edx
    8caf:      	addq	%r12, %rdx
    8cb2:      	movl	$0x8, %esi
    8cb7:      	callq	*%r8
    8cba:      	testq	%rax, %rax
    8cbd:      	je	0x8eab <kprobe_unwind_hotspot+0x8eab>
    8cc3:      	movq	(%rip), %rax            # 0x8cca <kprobe_unwind_hotspot+0x8cca>
    8cca:      	cmpl	$0x0, (%rax)
    8ccd:      	je	0x8d2a <kprobe_unwind_hotspot+0x8d2a>
    8ccf:      	movabsq	$0xa646f6874656d63, %rax # imm = 0xA646F6874656D63
    8cd9:      	movq	%rax, 0x20(%rsp)
    8cde:      	movq	%rbx, 0x18(%rsp)
    8ce3:      	movabsq	$0x65746e6920646165, %rax # imm = 0x65746E6920646165
    8ced:      	movq	%rax, 0x10(%rsp)
    8cf2:      	movabsq	$0x72206f742064656c, %rax # imm = 0x72206F742064656C
    8cfc:      	movq	%rax, 0x8(%rsp)
    8d01:      	movabsq	$0x696166203a6d766a, %rax # imm = 0x696166203A6D766A
    8d0b:      	movq	%rax, (%rsp)
    8d0f:      	movb	$0x0, 0x28(%rsp)
    8d14:      	movq	%rsp, %rdi
    8d17:      	movl	$0x29, %eax
    8d1c:      	movl	$0x6, %ecx
    8d21:      	movl	$0x29, %esi
    8d26:      	xorl	%eax, %eax
    8d28:      	callq	*%rcx
    8d2a:      	movl	$0x2d, 0x114(%rsp)
    8d35:      	movq	(%rip), %rdi            # 0x8d3c <kprobe_unwind_hotspot+0x8d3c>
    8d3c:      	leaq	0x114(%rsp), %rsi
    8d44:      	movl	$0x1, %eax
    8d49:      	callq	*%rax
    8d4b:      	testq	%rax, %rax
    8d4e:      	je	0x8fc2 <kprobe_unwind_hotspot+0x8fc2>
    8d54:      	incq	(%rax)
    8d57:      	jmp	0x9044 <kprobe_unwind_hotspot+0x9044>
    8d5c:      	movl	0xf0(%rsp), %ebx
    8d63:      	movq	0xa8(%rsp), %rdx
    8d6b:      	movq	0x38(%rsp), %rax
    8d70:      	leaq	(%rax,%rbx), %r15
    8d74:      	addq	$0x30, %r15
    8d78:      	subq	%rax, %rdx
    8d7b:      	jb	0x905e <kprobe_unwind_hotspot+0x905e>
    8d81:      	cmpq	%r15, 0xa8(%rsp)
    8d89:      	jae	0x905e <kprobe_unwind_hotspot+0x905e>
    8d8f:      	movb	$0x3, %al
    8d91:      	movl	%eax, 0xb0(%rsp)
    8d98:      	movq	(%rip), %rax            # 0x8d9f <kprobe_unwind_hotspot+0x8d9f>
    8d9f:      	cmpl	$0x0, (%rax)
    8da2:      	je	0x8e16 <kprobe_unwind_hotspot+0x8e16>
    8da4:      	movabsq	$0xa29646c252065, %rax  # imm = 0xA29646C252065
    8dae:      	movq	%rax, 0x67(%rsp)
    8db3:      	movabsq	$0x657a697320656d61, %rax # imm = 0x657A697320656D61
    8dbd:      	movq	%rax, 0x60(%rsp)
    8dc2:      	movabsq	$0x726628207265746e, %rax # imm = 0x726628207265746E
    8dcc:      	movq	%rax, 0x58(%rsp)
    8dd1:      	movabsq	$0x696f7020656d6172, %rax # imm = 0x696F7020656D6172
    8ddb:      	movq	%rax, 0x50(%rsp)
    8de0:      	movabsq	$0x6620676e69737520, %rax # imm = 0x6620676E69737520
    8dea:      	movq	%rax, 0x48(%rsp)
    8def:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    8df9:      	movq	%rax, 0x40(%rsp)
    8dfe:      	leaq	0x40(%rsp), %rdi
    8e03:      	movl	$0x2f, %eax
    8e08:      	movl	$0x6, %ecx
    8e0d:      	movl	$0x2f, %esi
    8e12:      	xorl	%eax, %eax
    8e14:      	callq	*%rcx
    8e16:      	movq	0xa8(%rsp), %rcx
    8e1e:      	jmp	0x96ce <kprobe_unwind_hotspot+0x96ce>
    8e23:      	movb	$0x3, %cl
    8e25:      	movl	%ecx, 0xb0(%rsp)
    8e2c:      	testl	%eax, %eax
    8e2e:      	je	0x9684 <kprobe_unwind_hotspot+0x9684>
    8e34:      	movabsq	$0xa2963702b7066, %rax  # imm = 0xA2963702B7066
    8e3e:      	movq	%rax, 0x65(%rsp)
    8e43:      	movabsq	$0x2b70662820656d61, %rax # imm = 0x2B70662820656D61
    8e4d:      	movq	%rax, 0x60(%rsp)
    8e52:      	movabsq	$0x7266206574656c70, %rax # imm = 0x7266206574656C70
    8e5c:      	movq	%rax, 0x58(%rsp)
    8e61:      	movabsq	$0x6d6f636e6920676e, %rax # imm = 0x6D6F636E6920676E
    8e6b:      	movq	%rax, 0x50(%rsp)
    8e70:      	movabsq	$0x69646e69776e7520, %rax # imm = 0x69646E69776E7520
    8e7a:      	movq	%rax, 0x48(%rsp)
    8e7f:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    8e89:      	movq	%rax, 0x40(%rsp)
    8e8e:      	leaq	0x40(%rsp), %rdi
    8e93:      	movl	$0x2d, %eax
    8e98:      	movl	$0x6, %ecx
    8e9d:      	movl	$0x2d, %esi
    8ea2:      	xorl	%eax, %eax
    8ea4:      	callq	*%rcx
    8ea6:      	jmp	0x9684 <kprobe_unwind_hotspot+0x9684>
    8eab:      	movq	0x100(%rsp), %rdx
    8eb3:      	movzbl	0x1d(%r15), %eax
    8eb8:      	movq	%rdx, %rcx
    8ebb:      	movq	%rdx, 0x120(%rsp)
    8ec3:      	addq	%rdx, %rax
    8ec6:      	xorl	%ebx, %ebx
    8ec8:      	cmpq	%rax, %r13
    8ecb:      	movl	$0x0, %ecx
    8ed0:      	cmovaeq	%rax, %rcx
    8ed4:      	subq	%rcx, %r13
    8ed7:      	movq	(%rip), %rax            # 0x8ede <kprobe_unwind_hotspot+0x8ede>
    8ede:      	cmpl	$0x0, (%rax)
    8ee1:      	je	0x8f85 <kprobe_unwind_hotspot+0x8f85>
    8ee7:      	movabsq	$0xa786c25203d20, %rax  # imm = 0xA786C25203D20
    8ef1:      	movq	%rax, 0x2d(%rsp)
    8ef6:      	movabsq	$0x203d20706362202c, %rax # imm = 0x203D20706362202C
    8f00:      	movq	%rax, 0x28(%rsp)
    8f05:      	movabsq	$0x786c257830203d20, %rax # imm = 0x786C257830203D20
    8f0f:      	movq	%rax, 0x20(%rsp)
    8f14:      	movabsq	$0x646f6874656d6320, %rax # imm = 0x646F6874656D6320
    8f1e:      	movq	%rax, 0x18(%rsp)
    8f23:      	movabsq	$0x2c786c257830203d, %rax # imm = 0x2C786C257830203D
    8f2d:      	movq	%rax, 0x10(%rsp)
    8f32:      	movabsq	$0x20646f6874656d20, %rax # imm = 0x20646F6874656D20
    8f3c:      	movq	%rax, 0x8(%rsp)
    8f41:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    8f4b:      	movq	%rax, (%rsp)
    8f4f:      	movq	%rsp, %rdi
    8f52:      	movl	$0x35, %eax
    8f57:      	movl	$0x6, %r9d
    8f5d:      	movq	0x100(%rsp), %rcx
    8f65:      	movl	$0x35, %esi
    8f6a:      	movq	%r12, %rdx
    8f6d:      	movq	%r13, %r8
    8f70:      	xorl	%eax, %eax
    8f72:      	callq	*%r9
    8f75:      	movq	0x100(%rsp), %rax
    8f7d:      	movq	%rax, 0x120(%rsp)
    8f85:      	cmpq	$0xffff, %r13           # imm = 0xFFFF
    8f8c:      	movl	$0xffff, %eax           # imm = 0xFFFF
    8f91:      	cmovbq	%r13, %rax
    8f95:      	movq	%rax, 0x118(%rsp)
    8f9d:      	shrq	$0x3, 0x120(%rsp)
    8fa6:      	movl	$0x6, %r13d
    8fac:      	movb	$0x2, %al
    8fae:      	movl	%eax, 0xb0(%rsp)
    8fb5:      	movq	%r12, 0xc0(%rsp)
    8fbd:      	jmp	0x966a <kprobe_unwind_hotspot+0x966a>
    8fc2:      	movq	(%rip), %rax            # 0x8fc9 <kprobe_unwind_hotspot+0x8fc9>
    8fc9:      	cmpl	$0x0, (%rax)
    8fcc:      	je	0x9044 <kprobe_unwind_hotspot+0x9044>
    8fce:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    8fd8:      	movq	%rax, 0x26(%rsp)
    8fdd:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    8fe7:      	movq	%rax, 0x20(%rsp)
    8fec:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    8ff6:      	movq	%rax, 0x18(%rsp)
    8ffb:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    9005:      	movq	%rax, 0x10(%rsp)
    900a:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    9014:      	movq	%rax, 0x8(%rsp)
    9019:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    9023:      	movq	%rax, (%rsp)
    9027:      	movq	%rsp, %rdi
    902a:      	movl	$0x2e, %eax
    902f:      	movl	$0x6, %ecx
    9034:      	movl	0x114(%rsp), %edx
    903b:      	movl	$0x2e, %esi
    9040:      	xorl	%eax, %eax
    9042:      	callq	*%rcx
    9044:      	movl	$0x3e9, %ebx            # imm = 0x3E9
    9049:      	xorl	%r13d, %r13d
    904c:      	movl	$0x65746e49, %eax       # imm = 0x65746E49
    9051:      	movq	%rax, 0x120(%rsp)
    9059:      	jmp	0x966a <kprobe_unwind_hotspot+0x966a>
    905e:      	movq	0x38(%rsp), %rax
    9063:      	leaq	(%rax,%rbx), %rdx
    9067:      	addq	$-0x8, %rdx
    906b:      	leaq	0x40(%rsp), %rdi
    9070:      	movl	$0x30, %eax
    9075:      	movl	$0x70, %ecx
    907a:      	movl	$0x30, %esi
    907f:      	callq	*%rcx
    9081:      	movq	(%rip), %rax            # 0x9088 <kprobe_unwind_hotspot+0x9088>
    9088:      	cmpl	$0x0, (%rax)
    908b:      	je	0x90ee <kprobe_unwind_hotspot+0x90ee>
    908d:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    9097:      	movq	%rax, 0x18(%rsp)
    909c:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    90a6:      	movq	%rax, 0x10(%rsp)
    90ab:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    90b5:      	movq	%rax, 0x8(%rsp)
    90ba:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    90c4:      	movq	%rax, (%rsp)
    90c8:      	movw	$0xa, 0x20(%rsp)
    90cf:      	movq	%rsp, %rdi
    90d2:      	movl	$0x22, %eax
    90d7:      	movl	$0x6, %r8d
    90dd:      	movq	0x40(%rsp), %rcx
    90e2:      	movl	$0x22, %esi
    90e7:      	xorl	%edx, %edx
    90e9:      	xorl	%eax, %eax
    90eb:      	callq	*%r8
    90ee:      	movl	(%r14), %eax
    90f1:      	movl	$0x60, (%rsp)
    90f8:      	movbel	%eax, 0x4(%rsp)
    90fe:      	addq	%rbx, 0x38(%rsp)
    9103:      	movq	0x40(%rsp), %rax
    9108:      	movbeq	%rax, 0x8(%rsp)
    910f:      	movabsq	$-0x100000000000000, %rbx # imm = 0xFF00000000000000
    9119:      	movabsq	$0x200000000000000, %r12 # imm = 0x200000000000000
    9123:      	movq	(%rip), %rdi            # 0x912a <kprobe_unwind_hotspot+0x912a>
    912a:      	movq	%rsp, %rsi
    912d:      	movl	$0x1, %eax
    9132:      	callq	*%rax
    9134:      	testq	%rax, %rax
    9137:      	je	0x9151 <kprobe_unwind_hotspot+0x9151>
    9139:      	movq	0x8(%rax), %rax
    913d:      	andq	%rbx, %rax
    9140:      	xorl	%edx, %edx
    9142:      	cmpq	%r12, %rax
    9145:      	jne	0x9151 <kprobe_unwind_hotspot+0x9151>
    9147:      	movq	0x38(%rsp), %r15
    914c:      	jmp	0x9516 <kprobe_unwind_hotspot+0x9516>
    9151:      	movq	(%rip), %rax            # 0x9158 <kprobe_unwind_hotspot+0x9158>
    9158:      	cmpl	$0x0, (%rax)
    915b:      	je	0x91c1 <kprobe_unwind_hotspot+0x91c1>
    915d:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    9167:      	movq	%rax, 0x18(%rsp)
    916c:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    9176:      	movq	%rax, 0x10(%rsp)
    917b:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    9185:      	movq	%rax, 0x8(%rsp)
    918a:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    9194:      	movq	%rax, (%rsp)
    9198:      	movw	$0xa, 0x20(%rsp)
    919f:      	movq	%rsp, %rdi
    91a2:      	movl	$0x22, %eax
    91a7:      	movl	$0x6, %r8d
    91ad:      	movq	0x48(%rsp), %rcx
    91b2:      	movl	$0x22, %esi
    91b7:      	movl	$0x1, %edx
    91bc:      	xorl	%eax, %eax
    91be:      	callq	*%r8
    91c1:      	movl	(%r14), %eax
    91c4:      	movl	$0x60, (%rsp)
    91cb:      	movbel	%eax, 0x4(%rsp)
    91d1:      	movq	0x48(%rsp), %rax
    91d6:      	movbeq	%rax, 0x8(%rsp)
    91dd:      	movq	(%rip), %rdi            # 0x91e4 <kprobe_unwind_hotspot+0x91e4>
    91e4:      	movq	%rsp, %rsi
    91e7:      	movl	$0x1, %eax
    91ec:      	callq	*%rax
    91ee:      	testq	%rax, %rax
    91f1:      	je	0x9212 <kprobe_unwind_hotspot+0x9212>
    91f3:      	movq	0x8(%rax), %rax
    91f7:      	andq	%rbx, %rax
    91fa:      	cmpq	%r12, %rax
    91fd:      	jne	0x9212 <kprobe_unwind_hotspot+0x9212>
    91ff:      	movq	0x38(%rsp), %r15
    9204:      	addq	$0x8, %r15
    9208:      	movl	$0x1, %edx
    920d:      	jmp	0x9516 <kprobe_unwind_hotspot+0x9516>
    9212:      	movq	(%rip), %rax            # 0x9219 <kprobe_unwind_hotspot+0x9219>
    9219:      	cmpl	$0x0, (%rax)
    921c:      	je	0x9282 <kprobe_unwind_hotspot+0x9282>
    921e:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    9228:      	movq	%rax, 0x18(%rsp)
    922d:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    9237:      	movq	%rax, 0x10(%rsp)
    923c:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    9246:      	movq	%rax, 0x8(%rsp)
    924b:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    9255:      	movq	%rax, (%rsp)
    9259:      	movw	$0xa, 0x20(%rsp)
    9260:      	movq	%rsp, %rdi
    9263:      	movl	$0x22, %eax
    9268:      	movl	$0x6, %r8d
    926e:      	movq	0x50(%rsp), %rcx
    9273:      	movl	$0x22, %esi
    9278:      	movl	$0x2, %edx
    927d:      	xorl	%eax, %eax
    927f:      	callq	*%r8
    9282:      	movl	(%r14), %eax
    9285:      	movl	$0x60, (%rsp)
    928c:      	movbel	%eax, 0x4(%rsp)
    9292:      	movq	0x50(%rsp), %rax
    9297:      	movbeq	%rax, 0x8(%rsp)
    929e:      	movq	(%rip), %rdi            # 0x92a5 <kprobe_unwind_hotspot+0x92a5>
    92a5:      	movq	%rsp, %rsi
    92a8:      	movl	$0x1, %eax
    92ad:      	callq	*%rax
    92af:      	testq	%rax, %rax
    92b2:      	je	0x92d3 <kprobe_unwind_hotspot+0x92d3>
    92b4:      	movq	0x8(%rax), %rax
    92b8:      	andq	%rbx, %rax
    92bb:      	cmpq	%r12, %rax
    92be:      	jne	0x92d3 <kprobe_unwind_hotspot+0x92d3>
    92c0:      	movq	0x38(%rsp), %r15
    92c5:      	addq	$0x10, %r15
    92c9:      	movl	$0x2, %edx
    92ce:      	jmp	0x9516 <kprobe_unwind_hotspot+0x9516>
    92d3:      	movq	(%rip), %rax            # 0x92da <kprobe_unwind_hotspot+0x92da>
    92da:      	cmpl	$0x0, (%rax)
    92dd:      	je	0x9343 <kprobe_unwind_hotspot+0x9343>
    92df:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    92e9:      	movq	%rax, 0x18(%rsp)
    92ee:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    92f8:      	movq	%rax, 0x10(%rsp)
    92fd:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    9307:      	movq	%rax, 0x8(%rsp)
    930c:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    9316:      	movq	%rax, (%rsp)
    931a:      	movw	$0xa, 0x20(%rsp)
    9321:      	movq	%rsp, %rdi
    9324:      	movl	$0x22, %eax
    9329:      	movl	$0x6, %r8d
    932f:      	movq	0x58(%rsp), %rcx
    9334:      	movl	$0x22, %esi
    9339:      	movl	$0x3, %edx
    933e:      	xorl	%eax, %eax
    9340:      	callq	*%r8
    9343:      	movl	(%r14), %eax
    9346:      	movl	$0x60, (%rsp)
    934d:      	movbel	%eax, 0x4(%rsp)
    9353:      	movq	0x58(%rsp), %rax
    9358:      	movbeq	%rax, 0x8(%rsp)
    935f:      	movq	(%rip), %rdi            # 0x9366 <kprobe_unwind_hotspot+0x9366>
    9366:      	movq	%rsp, %rsi
    9369:      	movl	$0x1, %eax
    936e:      	callq	*%rax
    9370:      	testq	%rax, %rax
    9373:      	je	0x9394 <kprobe_unwind_hotspot+0x9394>
    9375:      	movq	0x8(%rax), %rax
    9379:      	andq	%rbx, %rax
    937c:      	cmpq	%r12, %rax
    937f:      	jne	0x9394 <kprobe_unwind_hotspot+0x9394>
    9381:      	movq	0x38(%rsp), %r15
    9386:      	addq	$0x18, %r15
    938a:      	movl	$0x3, %edx
    938f:      	jmp	0x9516 <kprobe_unwind_hotspot+0x9516>
    9394:      	movq	(%rip), %rax            # 0x939b <kprobe_unwind_hotspot+0x939b>
    939b:      	cmpl	$0x0, (%rax)
    939e:      	je	0x9404 <kprobe_unwind_hotspot+0x9404>
    93a0:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    93aa:      	movq	%rax, 0x18(%rsp)
    93af:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    93b9:      	movq	%rax, 0x10(%rsp)
    93be:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    93c8:      	movq	%rax, 0x8(%rsp)
    93cd:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    93d7:      	movq	%rax, (%rsp)
    93db:      	movw	$0xa, 0x20(%rsp)
    93e2:      	movq	%rsp, %rdi
    93e5:      	movl	$0x22, %eax
    93ea:      	movl	$0x6, %r8d
    93f0:      	movq	0x60(%rsp), %rcx
    93f5:      	movl	$0x22, %esi
    93fa:      	movl	$0x4, %edx
    93ff:      	xorl	%eax, %eax
    9401:      	callq	*%r8
    9404:      	movl	(%r14), %eax
    9407:      	movl	$0x60, (%rsp)
    940e:      	movbel	%eax, 0x4(%rsp)
    9414:      	movq	0x60(%rsp), %rax
    9419:      	movbeq	%rax, 0x8(%rsp)
    9420:      	movq	(%rip), %rdi            # 0x9427 <kprobe_unwind_hotspot+0x9427>
    9427:      	movq	%rsp, %rsi
    942a:      	movl	$0x1, %eax
    942f:      	callq	*%rax
    9431:      	testq	%rax, %rax
    9434:      	je	0x9455 <kprobe_unwind_hotspot+0x9455>
    9436:      	movq	0x8(%rax), %rax
    943a:      	andq	%rbx, %rax
    943d:      	cmpq	%r12, %rax
    9440:      	jne	0x9455 <kprobe_unwind_hotspot+0x9455>
    9442:      	movq	0x38(%rsp), %r15
    9447:      	addq	$0x20, %r15
    944b:      	movl	$0x4, %edx
    9450:      	jmp	0x9516 <kprobe_unwind_hotspot+0x9516>
    9455:      	movq	(%rip), %rax            # 0x945c <kprobe_unwind_hotspot+0x945c>
    945c:      	cmpl	$0x0, (%rax)
    945f:      	je	0x94c5 <kprobe_unwind_hotspot+0x94c5>
    9461:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    946b:      	movq	%rax, 0x18(%rsp)
    9470:      	movabsq	$0x616469646e616320, %rax # imm = 0x616469646E616320
    947a:      	movq	%rax, 0x10(%rsp)
    947f:      	movabsq	$0x6370207525203e2d, %rax # imm = 0x6370207525203E2D
    9489:      	movq	%rax, 0x8(%rsp)
    948e:      	movabsq	$0x202020203a6d766a, %rax # imm = 0x202020203A6D766A
    9498:      	movq	%rax, (%rsp)
    949c:      	movw	$0xa, 0x20(%rsp)
    94a3:      	movq	%rsp, %rdi
    94a6:      	movl	$0x22, %eax
    94ab:      	movl	$0x6, %r8d
    94b1:      	movq	0x68(%rsp), %rcx
    94b6:      	movl	$0x22, %esi
    94bb:      	movl	$0x5, %edx
    94c0:      	xorl	%eax, %eax
    94c2:      	callq	*%r8
    94c5:      	movl	(%r14), %eax
    94c8:      	movl	$0x60, (%rsp)
    94cf:      	movbel	%eax, 0x4(%rsp)
    94d5:      	movq	0x68(%rsp), %rax
    94da:      	movbeq	%rax, 0x8(%rsp)
    94e1:      	movq	(%rip), %rdi            # 0x94e8 <kprobe_unwind_hotspot+0x94e8>
    94e8:      	movq	%rsp, %rsi
    94eb:      	movl	$0x1, %eax
    94f0:      	callq	*%rax
    94f2:      	testq	%rax, %rax
    94f5:      	je	0x95a4 <kprobe_unwind_hotspot+0x95a4>
    94fb:      	andq	0x8(%rax), %rbx
    94ff:      	cmpq	%r12, %rbx
    9502:      	jne	0x95a4 <kprobe_unwind_hotspot+0x95a4>
    9508:      	movq	0x38(%rsp), %r15
    950d:      	addq	$0x28, %r15
    9511:      	movl	$0x5, %edx
    9516:      	xorl	%ebx, %ebx
    9518:      	movl	$0x5, %r13d
    951e:      	movq	(%rip), %rax            # 0x9525 <kprobe_unwind_hotspot+0x9525>
    9525:      	cmpl	$0x0, (%rax)
    9528:      	je	0x965c <kprobe_unwind_hotspot+0x965c>
    952e:      	movabsq	$0xa7364726f7720, %rax  # imm = 0xA7364726F7720
    9538:      	movq	%rax, 0x26(%rsp)
    953d:      	movabsq	$0x77206425202b2065, %rax # imm = 0x77206425202B2065
    9547:      	movq	%rax, 0x20(%rsp)
    954c:      	movabsq	$0x6d61726620657465, %rax # imm = 0x6D61726620657465
    9556:      	movq	%rax, 0x18(%rsp)
    955b:      	movabsq	$0x6c706d6f6320676e, %rax # imm = 0x6C706D6F6320676E
    9565:      	movq	%rax, 0x10(%rsp)
    956a:      	movabsq	$0x69646e69776e7520, %rax # imm = 0x69646E69776E7520
    9574:      	movq	%rax, 0x8(%rsp)
    9579:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    9583:      	movq	%rax, (%rsp)
    9587:      	movq	%rsp, %rdi
    958a:      	movl	$0x2e, %eax
    958f:      	movl	$0x6, %ecx
    9594:      	xorl	%ebx, %ebx
    9596:      	movl	$0x2e, %esi
    959b:      	xorl	%eax, %eax
    959d:      	callq	*%rcx
    959f:      	jmp	0x965c <kprobe_unwind_hotspot+0x965c>
    95a4:      	movl	$0x2e, 0x100(%rsp)
    95af:      	movq	(%rip), %rdi            # 0x95b6 <kprobe_unwind_hotspot+0x95b6>
    95b6:      	leaq	0x100(%rsp), %rsi
    95be:      	movl	$0x1, %eax
    95c3:      	callq	*%rax
    95c5:      	testq	%rax, %rax
    95c8:      	je	0x95d2 <kprobe_unwind_hotspot+0x95d2>
    95ca:      	incq	(%rax)
    95cd:      	jmp	0x9654 <kprobe_unwind_hotspot+0x9654>
    95d2:      	movq	(%rip), %rax            # 0x95d9 <kprobe_unwind_hotspot+0x95d9>
    95d9:      	cmpl	$0x0, (%rax)
    95dc:      	je	0x9654 <kprobe_unwind_hotspot+0x9654>
    95de:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    95e8:      	movq	%rax, 0x26(%rsp)
    95ed:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    95f7:      	movq	%rax, 0x20(%rsp)
    95fc:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    9606:      	movq	%rax, 0x18(%rsp)
    960b:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    9615:      	movq	%rax, 0x10(%rsp)
    961a:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    9624:      	movq	%rax, 0x8(%rsp)
    9629:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    9633:      	movq	%rax, (%rsp)
    9637:      	movq	%rsp, %rdi
    963a:      	movl	$0x2e, %eax
    963f:      	movl	$0x6, %ecx
    9644:      	movl	0x100(%rsp), %edx
    964b:      	movl	$0x2e, %esi
    9650:      	xorl	%eax, %eax
    9652:      	callq	*%rcx
    9654:      	movl	$0x3ea, %ebx            # imm = 0x3EA
    9659:      	xorl	%r13d, %r13d
    965c:      	movb	$0x3, %al
    965e:      	movl	%eax, 0xb0(%rsp)
    9665:      	movq	%r15, 0x38(%rsp)
    966a:      	testl	%ebx, %ebx
    966c:      	jne	0x347 <kprobe_unwind_hotspot+0x347>
    9672:      	cmpl	$0x2, %r13d
    9676:      	jle	0x968b <kprobe_unwind_hotspot+0x968b>
    9678:      	cmpl	$0x4, %r13d
    967c:      	jg	0x96b9 <kprobe_unwind_hotspot+0x96b9>
    967e:      	cmpl	$0x3, %r13d
    9682:      	jne	0x96c5 <kprobe_unwind_hotspot+0x96c5>
    9684:      	movq	0x38(%rsp), %rcx
    9689:      	jmp	0x96ce <kprobe_unwind_hotspot+0x96ce>
    968b:      	movl	$0x1, %ebx
    9690:      	testl	%r13d, %r13d
    9693:      	je	0x347 <kprobe_unwind_hotspot+0x347>
    9699:      	movq	0xa8(%rsp), %rcx
    96a1:      	cmpl	$0x1, %r13d
    96a5:      	jne	0x96ce <kprobe_unwind_hotspot+0x96ce>
    96a7:      	movl	$0x8, 0xf0(%rsp)
    96b2:      	movl	$0x8, %eax
    96b7:      	jmp	0x96e3 <kprobe_unwind_hotspot+0x96e3>
    96b9:      	cmpl	$0x5, %r13d
    96bd:      	jne	0x977b <kprobe_unwind_hotspot+0x977b>
    96c3:      	jmp	0x96ea <kprobe_unwind_hotspot+0x96ea>
    96c5:      	movl	0xf0(%rsp), %eax
    96cc:      	jmp	0x96e3 <kprobe_unwind_hotspot+0x96e3>
    96ce:      	movl	$0x10, 0xf0(%rsp)
    96d9:      	movl	$0x10, %eax
    96de:      	movq	%rcx, 0x38(%rsp)
    96e3:      	movl	%eax, %eax
    96e5:      	addq	%rax, 0x38(%rsp)
    96ea:      	movq	0x38(%rsp), %rax
    96ef:      	leaq	-0x10(%rax), %rdx
    96f3:      	movq	%rsp, %rdi
    96f6:      	movl	$0x10, %eax
    96fb:      	movl	$0x70, %ecx
    9700:      	movl	$0x10, %esi
    9705:      	callq	*%rcx
    9707:      	movq	0x8(%rsp), %rax
    970c:      	movq	%rax, 0xb8(%rsp)
    9714:      	cmpl	$0x10, 0xf0(%rsp)
    971c:      	jb	0x977b <kprobe_unwind_hotspot+0x977b>
    971e:      	movq	(%rip), %rax            # 0x9725 <kprobe_unwind_hotspot+0x9725>
    9725:      	cmpl	$0x0, (%rax)
    9728:      	je	0x976f <kprobe_unwind_hotspot+0x976f>
    972a:      	movabsq	$0xa706620726576, %rax  # imm = 0xA706620726576
    9734:      	movq	%rax, 0x4d(%rsp)
    9739:      	movabsq	$0x7265766f63657220, %rax # imm = 0x7265766F63657220
    9743:      	movq	%rax, 0x48(%rsp)
    9748:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    9752:      	movq	%rax, 0x40(%rsp)
    9757:      	leaq	0x40(%rsp), %rdi
    975c:      	movl	$0x15, %eax
    9761:      	movl	$0x6, %ecx
    9766:      	movl	$0x15, %esi
    976b:      	xorl	%eax, %eax
    976d:      	callq	*%rcx
    976f:      	movq	(%rsp), %rax
    9773:      	movq	%rax, 0xa8(%rsp)
    977b:      	movl	0x2c0(%r14), %eax
    9782:      	cmpq	$0x7e, %rax
    9786:      	ja	0xf03 <kprobe_unwind_hotspot+0xf03>
    978c:      	movzbl	0xf30(%r14), %ecx
    9794:      	movzbl	0xb0(%rsp), %edx
    979c:      	shlq	$0x3c, %rdx
    97a0:      	movq	0x118(%rsp), %rdi
    97a8:      	shlq	$0x20, %rdi
    97ac:      	movl	0x120(%rsp), %esi
    97b3:      	orq	%rdi, %rsi
    97b6:      	orq	%rdx, %rsi
    97b9:      	leal	0x1(%rax), %edx
    97bc:      	movl	%edx, 0x2c0(%r14)
    97c3:      	leaq	(%rax,%rax,2), %rax
    97c7:      	movq	0xc0(%rsp), %rdx
    97cf:      	movq	%rdx, 0x2d0(%r14,%rax,8)
    97d7:      	movq	%rsi, 0x2d8(%r14,%rax,8)
    97df:      	movb	$0x5, 0x2e0(%r14,%rax,8)
    97e8:      	movb	%cl, 0x2e1(%r14,%rax,8)
    97f0:      	movl	$0x0, 0x2e2(%r14,%rax,8)
    97fc:      	movw	$0x0, 0x2e6(%r14,%rax,8)
    9807:      	movq	(%rip), %rax            # 0x980e <kprobe_unwind_hotspot+0x980e>
    980e:      	cmpl	$0x0, (%rax)
    9811:      	je	0x9886 <kprobe_unwind_hotspot+0x9886>
    9813:      	movabsq	$0x25203a7066202c78, %rax # imm = 0x25203A7066202C78
    981d:      	movq	%rax, 0x58(%rsp)
    9822:      	movabsq	$0x6c25203a7073202c, %rax # imm = 0x6C25203A7073202C
    982c:      	movq	%rax, 0x50(%rsp)
    9831:      	movabsq	$0x786c25203a637020, %rax # imm = 0x786C25203A637020
    983b:      	movq	%rax, 0x48(%rsp)
    9840:      	movabsq	$0x3e2d20203a6d766a, %rax # imm = 0x3E2D20203A6D766A
    984a:      	movq	%rax, 0x40(%rsp)
    984f:      	movl	$0xa786c, 0x60(%rsp)    # imm = 0xA786C
    9857:      	leaq	0x40(%rsp), %rdi
    985c:      	movl	$0x24, %eax
    9861:      	movl	$0x6, %r9d
    9867:      	movl	$0x24, %esi
    986c:      	movq	0xb8(%rsp), %rdx
    9874:      	movq	0x38(%rsp), %rcx
    9879:      	movq	0xa8(%rsp), %r8
    9881:      	xorl	%eax, %eax
    9883:      	callq	*%r9
    9886:      	movq	0xb8(%rsp), %rax
    988e:      	movq	%rax, 0xed0(%r14)
    9895:      	movq	0x38(%rsp), %rax
    989a:      	movq	%rax, 0xed8(%r14)
    98a1:      	movq	0xa8(%rsp), %rax
    98a9:      	movq	%rax, 0xee0(%r14)
    98b0:      	movb	$0x1, 0xf30(%r14)
    98b8:      	movl	$0x2a, (%rsp)
    98bf:      	movq	(%rip), %rdi            # 0x98c6 <kprobe_unwind_hotspot+0x98c6>
    98c6:      	movq	%rsp, %rsi
    98c9:      	movl	$0x1, %eax
    98ce:      	callq	*%rax
    98d0:      	testq	%rax, %rax
    98d3:      	je	0x98dd <kprobe_unwind_hotspot+0x98dd>
    98d5:      	incq	(%rax)
    98d8:      	jmp	0x9960 <kprobe_unwind_hotspot+0x9960>
    98dd:      	xorl	%eax, %eax
    98df:      	movq	(%rip), %rcx            # 0x98e6 <kprobe_unwind_hotspot+0x98e6>
    98e6:      	cmpl	$0x0, (%rcx)
    98e9:      	je	0x9969 <kprobe_unwind_hotspot+0x9969>
    98eb:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    98f5:      	movq	%rax, 0x66(%rsp)
    98fa:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    9904:      	movq	%rax, 0x60(%rsp)
    9909:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    9913:      	movq	%rax, 0x58(%rsp)
    9918:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    9922:      	movq	%rax, 0x50(%rsp)
    9927:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    9931:      	movq	%rax, 0x48(%rsp)
    9936:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    9940:      	movq	%rax, 0x40(%rsp)
    9945:      	leaq	0x40(%rsp), %rdi
    994a:      	movl	$0x2e, %eax
    994f:      	movl	$0x6, %ecx
    9954:      	movl	(%rsp), %edx
    9957:      	movl	$0x2e, %esi
    995c:      	xorl	%eax, %eax
    995e:      	callq	*%rcx
    9960:      	movq	(%rip), %rax            # 0x9967 <kprobe_unwind_hotspot+0x9967>
    9967:      	movl	(%rax), %eax
    9969:      	movq	0xed0(%r14), %rbx
    9970:      	testq	%rbx, %rbx
    9973:      	je	0x9ceb <kprobe_unwind_hotspot+0x9ceb>
    9979:      	testl	%eax, %eax
    997b:      	je	0x9a06 <kprobe_unwind_hotspot+0x9a06>
    9981:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    998b:      	movq	%rax, 0x68(%rsp)
    9990:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    999a:      	movq	%rax, 0x60(%rsp)
    999f:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    99a9:      	movq	%rax, 0x58(%rsp)
    99ae:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    99b8:      	movq	%rax, 0x50(%rsp)
    99bd:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    99c7:      	movq	%rax, 0x48(%rsp)
    99cc:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    99d6:      	movq	%rax, 0x40(%rsp)
    99db:      	movb	$0x0, 0x70(%rsp)
    99e0:      	leaq	0x40(%rsp), %rdi
    99e5:      	movl	$0x31, %eax
    99ea:      	movl	$0x6, %ecx
    99ef:      	movl	0x2c0(%r14), %edx
    99f6:      	movl	$0x31, %esi
    99fb:      	xorl	%eax, %eax
    99fd:      	callq	*%rcx
    99ff:      	movq	0xed0(%r14), %rbx
    9a06:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    9a10:      	cmpq	%rax, %rbx
    9a13:      	ja	0x1049 <kprobe_unwind_hotspot+0x1049>
    9a19:      	cmpq	$0x1000, %rbx           # imm = 0x1000
    9a20:      	jb	0x1fa2 <kprobe_unwind_hotspot+0x1fa2>
    9a26:      	movl	(%r14), %eax
    9a29:      	movl	$0x60, 0xc8(%rsp)
    9a34:      	movbel	%eax, 0xcc(%rsp)
    9a3d:      	movbeq	%rbx, 0xd0(%rsp)
    9a47:      	movq	(%rip), %rdi            # 0x9a4e <kprobe_unwind_hotspot+0x9a4e>
    9a4e:      	leaq	0xc8(%rsp), %rsi
    9a56:      	movl	$0x1, %eax
    9a5b:      	callq	*%rax
    9a5d:      	testq	%rax, %rax
    9a60:      	je	0x9d07 <kprobe_unwind_hotspot+0x9d07>
    9a66:      	movq	0x8(%rax), %r12
    9a6a:      	movabsq	$0xffffffffffffff, %rcx # imm = 0xFFFFFFFFFFFFFF
    9a74:      	andq	%r12, %rcx
    9a77:      	movq	%rcx, 0xf20(%r14)
    9a7e:      	movq	(%rax), %rax
    9a81:      	movq	%rax, 0xf10(%r14)
    9a88:      	shrq	$0x38, %r12
    9a8c:      	movq	%rbx, %rax
    9a8f:      	subq	%rcx, %rax
    9a92:      	movq	%rax, 0xf18(%r14)
    9a99:      	movq	(%rip), %rax            # 0x9aa0 <kprobe_unwind_hotspot+0x9aa0>
    9aa0:      	cmpl	$0x0, (%rax)
    9aa3:      	je	0x9bb5 <kprobe_unwind_hotspot+0x9bb5>
    9aa9:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    9ab3:      	movq	%rax, 0x68(%rsp)
    9ab8:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    9ac2:      	movq	%rax, 0x60(%rsp)
    9ac7:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    9ad1:      	movq	%rax, 0x58(%rsp)
    9ad6:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    9ae0:      	movq	%rax, 0x50(%rsp)
    9ae5:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    9aef:      	movq	%rax, 0x48(%rsp)
    9af4:      	movabsq	$0x6365732074786554, %r15 # imm = 0x6365732074786554
    9afe:      	movq	%r15, 0x40(%rsp)
    9b03:      	movw	$0xa, 0x70(%rsp)
    9b0a:      	leaq	0x40(%rsp), %rdi
    9b0f:      	movl	$0x32, %eax
    9b14:      	movl	$0x6, %r9d
    9b1a:      	movq	0xf10(%r14), %rcx
    9b21:      	movl	$0x32, %esi
    9b26:      	movq	%rbx, %rdx
    9b29:      	movl	%r12d, %r8d
    9b2c:      	xorl	%eax, %eax
    9b2e:      	callq	*%r9
    9b31:      	movq	(%rip), %rax            # 0x9b38 <kprobe_unwind_hotspot+0x9b38>
    9b38:      	cmpl	$0x0, (%rax)
    9b3b:      	je	0x9bb5 <kprobe_unwind_hotspot+0x9bb5>
    9b3d:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    9b47:      	movq	%rax, 0x67(%rsp)
    9b4c:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    9b56:      	movq	%rax, 0x60(%rsp)
    9b5b:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    9b65:      	movq	%rax, 0x58(%rsp)
    9b6a:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    9b74:      	movq	%rax, 0x50(%rsp)
    9b79:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    9b83:      	movq	%rax, 0x48(%rsp)
    9b88:      	movq	%r15, 0x40(%rsp)
    9b8d:      	leaq	0x40(%rsp), %rdi
    9b92:      	movl	$0x2f, %eax
    9b97:      	movl	$0x6, %r8d
    9b9d:      	movq	0xf18(%r14), %rcx
    9ba4:      	movq	0xf20(%r14), %rdx
    9bab:      	movl	$0x2f, %esi
    9bb0:      	xorl	%eax, %eax
    9bb2:      	callq	*%r8
    9bb5:      	cmpl	$0x1, %r12d
    9bb9:      	jne	0x34c <kprobe_unwind_hotspot+0x34c>
    9bbf:      	movq	0xf10(%r14), %rax
    9bc6:      	movq	%rax, 0xc8(%rsp)
    9bce:      	movq	0xf18(%r14), %r15
    9bd5:      	movq	(%rip), %rdi            # 0x9bdc <kprobe_unwind_hotspot+0x9bdc>
    9bdc:      	leaq	0xc8(%rsp), %rsi
    9be4:      	movl	$0x1, %eax
    9be9:      	callq	*%rax
    9beb:      	movl	$0x1, %r12d
    9bf1:      	testq	%rax, %rax
    9bf4:      	je	0x34c <kprobe_unwind_hotspot+0x34c>
    9bfa:      	movq	%rax, %rbx
    9bfd:      	cmpq	%r15, (%rax)
    9c00:      	ja	0x9c08 <kprobe_unwind_hotspot+0x9c08>
    9c02:      	cmpq	%r15, 0x8(%rbx)
    9c06:      	jae	0x9c1c <kprobe_unwind_hotspot+0x9c1c>
    9c08:      	cmpq	%r15, 0x10(%rbx)
    9c0c:      	ja	0x34c <kprobe_unwind_hotspot+0x34c>
    9c12:      	cmpq	%r15, 0x18(%rbx)
    9c16:      	jb	0x34c <kprobe_unwind_hotspot+0x34c>
    9c1c:      	movq	(%rip), %rax            # 0x9c23 <kprobe_unwind_hotspot+0x9c23>
    9c23:      	cmpl	$0x0, (%rax)
    9c26:      	movabsq	$0x6572707265746e69, %r15 # imm = 0x6572707265746E69
    9c30:      	je	0x9c80 <kprobe_unwind_hotspot+0x9c80>
    9c32:      	movabsq	$0xa642520686374, %rax  # imm = 0xA642520686374
    9c3c:      	movq	%rax, 0x56(%rsp)
    9c41:      	movabsq	$0x6374616d20737465, %rax # imm = 0x6374616D20737465
    9c4b:      	movq	%rax, 0x50(%rsp)
    9c50:      	movabsq	$0x7366666f5f726574, %rax # imm = 0x7366666F5F726574
    9c5a:      	movq	%rax, 0x48(%rsp)
    9c5f:      	movq	%r15, 0x40(%rsp)
    9c64:      	leaq	0x40(%rsp), %rdi
    9c69:      	movl	$0x1e, %eax
    9c6e:      	movl	$0x6, %ecx
    9c73:      	movzwl	0x20(%rbx), %edx
    9c77:      	movl	$0x1e, %esi
    9c7c:      	xorl	%eax, %eax
    9c7e:      	callq	*%rcx
    9c80:      	movl	0x1380(%r14), %eax
    9c87:      	movl	0x20(%rbx), %ecx
    9c8a:      	btl	%ecx, %eax
    9c8d:      	jae	0x9e39 <kprobe_unwind_hotspot+0x9e39>
    9c93:      	movq	(%rip), %rax            # 0x9c9a <kprobe_unwind_hotspot+0x9c9a>
    9c9a:      	cmpl	$0x0, (%rax)
    9c9d:      	je	0x34c <kprobe_unwind_hotspot+0x34c>
    9ca3:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    9cad:      	movq	%rax, 0x50(%rsp)
    9cb2:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    9cbc:      	movq	%rax, 0x48(%rsp)
    9cc1:      	movq	%r15, 0x40(%rsp)
    9cc6:      	movl	$0xa656e, 0x57(%rsp)    # imm = 0xA656E
    9cce:      	leaq	0x40(%rsp), %rdi
    9cd3:      	movl	$0x1b, %eax
    9cd8:      	movl	$0x6, %ecx
    9cdd:      	movl	$0x1b, %esi
    9ce2:      	xorl	%eax, %eax
    9ce4:      	callq	*%rcx
    9ce6:      	jmp	0x34c <kprobe_unwind_hotspot+0x34c>
    9ceb:      	testl	%eax, %eax
    9ced:      	jne	0x9d2f <kprobe_unwind_hotspot+0x9d2f>
    9cef:      	movl	$0x1, 0xf28(%r14)
    9cfa:      	movl	$0xfad, %ebp            # imm = 0xFAD
    9cff:      	xorl	%r12d, %r12d
    9d02:      	jmp	0x34c <kprobe_unwind_hotspot+0x34c>
    9d07:      	movq	(%rip), %rax            # 0x9d0e <kprobe_unwind_hotspot+0x9d0e>
    9d0e:      	cmpl	$0x0, (%rax)
    9d11:      	jne	0x9dab <kprobe_unwind_hotspot+0x9dab>
    9d17:      	movl	$0xc, 0xf28(%r14)
    9d22:      	movl	$0xfac, %ebp            # imm = 0xFAC
    9d27:      	xorl	%r12d, %r12d
    9d2a:      	jmp	0x34c <kprobe_unwind_hotspot+0x34c>
    9d2f:      	movabsq	$0xa2930203d3d2043, %rax # imm = 0xA2930203D3D2043
    9d39:      	movq	%rax, 0x68(%rsp)
    9d3e:      	movabsq	$0x5028206572756c69, %rax # imm = 0x5028206572756C69
    9d48:      	movq	%rax, 0x60(%rsp)
    9d4d:      	movabsq	$0x616620646e69776e, %rax # imm = 0x616620646E69776E
    9d57:      	movq	%rax, 0x58(%rsp)
    9d5c:      	movabsq	$0x75206f7420657564, %rax # imm = 0x75206F7420657564
    9d66:      	movq	%rax, 0x50(%rsp)
    9d6b:      	movabsq	$0x20646e69776e7520, %rax # imm = 0x20646E69776E7520
    9d75:      	movq	%rax, 0x48(%rsp)
    9d7a:      	movabsq	$0x676e6970706f7453, %rax # imm = 0x676E6970706F7453
    9d84:      	movq	%rax, 0x40(%rsp)
    9d89:      	movb	$0x0, 0x70(%rsp)
    9d8e:      	leaq	0x40(%rsp), %rdi
    9d93:      	movl	$0x31, %eax
    9d98:      	movl	$0x6, %ecx
    9d9d:      	movl	$0x31, %esi
    9da2:      	xorl	%eax, %eax
    9da4:      	callq	*%rcx
    9da6:      	jmp	0x9cef <kprobe_unwind_hotspot+0x9cef>
    9dab:      	movabsq	$0xa786c2578302043, %rax # imm = 0xA786C2578302043
    9db5:      	movq	%rax, 0x70(%rsp)
    9dba:      	movabsq	$0x5020726f6620676e, %rax # imm = 0x5020726F6620676E
    9dc4:      	movq	%rax, 0x68(%rsp)
    9dc9:      	movabsq	$0x697070616d207972, %rax # imm = 0x697070616D207972
    9dd3:      	movq	%rax, 0x60(%rsp)
    9dd8:      	movabsq	$0x6f6d656d206c6176, %rax # imm = 0x6F6D656D206C6176
    9de2:      	movq	%rax, 0x58(%rsp)
    9de7:      	movabsq	$0x7265746e69207075, %rax # imm = 0x7265746E69207075
    9df1:      	movq	%rax, 0x50(%rsp)
    9df6:      	movabsq	$0x206b6f6f6c206f74, %rax # imm = 0x206B6F6F6C206F74
    9e00:      	movq	%rax, 0x48(%rsp)
    9e05:      	movabsq	$0x206572756c696146, %rax # imm = 0x206572756C696146
    9e0f:      	movq	%rax, 0x40(%rsp)
    9e14:      	movb	$0x0, 0x78(%rsp)
    9e19:      	leaq	0x40(%rsp), %rdi
    9e1e:      	movl	$0x39, %eax
    9e23:      	movl	$0x6, %ecx
    9e28:      	movl	$0x39, %esi
    9e2d:      	movq	%rbx, %rdx
    9e30:      	xorl	%eax, %eax
    9e32:      	callq	*%rcx
    9e34:      	jmp	0x9d17 <kprobe_unwind_hotspot+0x9d17>
    9e39:      	movl	$0x0, (%rsp)
    9e40:      	movq	(%rip), %rdi            # 0x9e47 <kprobe_unwind_hotspot+0x9e47>
    9e47:      	movq	%rsp, %rsi
    9e4a:      	movl	$0x1, %eax
    9e4f:      	callq	*%rax
    9e51:      	testq	%rax, %rax
    9e54:      	je	0x9e63 <kprobe_unwind_hotspot+0x9e63>
    9e56:      	incq	(%rax)
    9e59:      	movzwl	0x20(%rbx), %r12d
    9e5e:      	jmp	0x34c <kprobe_unwind_hotspot+0x34c>
    9e63:      	movq	(%rip), %rax            # 0x9e6a <kprobe_unwind_hotspot+0x9e6a>
    9e6a:      	cmpl	$0x0, (%rax)
    9e6d:      	je	0x9ee4 <kprobe_unwind_hotspot+0x9ee4>
    9e6f:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    9e79:      	movq	%rax, 0x66(%rsp)
    9e7e:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    9e88:      	movq	%rax, 0x60(%rsp)
    9e8d:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    9e97:      	movq	%rax, 0x58(%rsp)
    9e9c:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    9ea6:      	movq	%rax, 0x50(%rsp)
    9eab:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    9eb5:      	movq	%rax, 0x48(%rsp)
    9eba:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    9ec4:      	movq	%rax, 0x40(%rsp)
    9ec9:      	leaq	0x40(%rsp), %rdi
    9ece:      	movl	$0x2e, %eax
    9ed3:      	movl	$0x6, %ecx
    9ed8:      	movl	(%rsp), %edx
    9edb:      	movl	$0x2e, %esi
    9ee0:      	xorl	%eax, %eax
    9ee2:      	callq	*%rcx
    9ee4:      	movzwl	0x20(%rbx), %r12d
    9ee9:      	jmp	0x34c <kprobe_unwind_hotspot+0x34c>
