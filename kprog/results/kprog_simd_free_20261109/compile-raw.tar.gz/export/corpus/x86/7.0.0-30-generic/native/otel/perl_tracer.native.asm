
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/otel/perl_tracer.native.o:	file format elf64-x86-64

Disassembly of section perf_event/unwind_perl:

0000000000000000 <perf_unwind_perl>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0xc8, %rsp
      11:      	movq	%rdi, %rbx
      14:      	movl	$0x0, 0x10(%rsp)
      1c:      	movq	(%rip), %rdi            # 0x23 <perf_unwind_perl+0x23>
      23:      	leaq	0x10(%rsp), %rsi
      28:      	movl	$0x1, %eax
      2d:      	callq	*%rax
      2f:      	testq	%rax, %rax
      32:      	je	0x5912 <perf_unwind_perl+0x5912>
      38:      	movq	%rax, %r12
      3b:      	movq	%rax, %r15
      3e:      	movl	(%r12), %eax
      42:      	movl	%eax, 0xc4(%rsp)
      49:      	movq	(%rip), %r13            # 0x50 <perf_unwind_perl+0x50>
      50:      	cmpl	$0x0, (%r13)
      55:      	jne	0x14db <perf_unwind_perl+0x14db>
      5b:      	movq	(%rip), %rdi            # 0x62 <perf_unwind_perl+0x62>
      62:      	leaq	0xc4(%rsp), %rsi
      6a:      	movl	$0x1, %eax
      6f:      	callq	*%rax
      71:      	movl	(%r13), %ecx
      75:      	testq	%rax, %rax
      78:      	je	0xd5 <perf_unwind_perl+0xd5>
      7a:      	movq	%rax, %r14
      7d:      	testl	%ecx, %ecx
      7f:      	jne	0x1516 <perf_unwind_perl+0x1516>
      85:      	leaq	0xf38(%r12), %rax
      8d:      	movq	%rax, 0xb8(%rsp)
      95:      	movq	0xf38(%r15), %rax
      9c:      	testq	%rax, %rax
      9f:      	je	0x14e <perf_unwind_perl+0x14e>
      a5:      	movq	%rax, 0xa8(%rsp)
      ad:      	movq	0xf48(%r15), %rcx
      b4:      	movq	0xf50(%r15), %r13
      bb:      	addq	$0xf40, %r12            # imm = 0xF40
      c2:      	cmpq	%rcx, %r13
      c5:      	jae	0x243 <perf_unwind_perl+0x243>
      cb:      	movl	$0x3, %ebp
      d0:      	jmp	0x5636 <perf_unwind_perl+0x5636>
      d5:      	xorl	%eax, %eax
      d7:      	testl	%ecx, %ecx
      d9:      	je	0x5917 <perf_unwind_perl+0x5917>
      df:      	movabsq	$0xa6f666e69207373, %rax # imm = 0xA6F666E69207373
      e9:      	movq	%rax, 0x30(%rsp)
      ee:      	movabsq	$0x6572646461206f6e, %rax # imm = 0x6572646461206F6E
      f8:      	movq	%rax, 0x28(%rsp)
      fd:      	movabsq	$0x202c6b6361747320, %rax # imm = 0x202C6B6361747320
     107:      	movq	%rax, 0x20(%rsp)
     10c:      	movabsq	$0x6c72655020646c69, %rax # imm = 0x6C72655020646C69
     116:      	movq	%rax, 0x18(%rsp)
     11b:      	movabsq	$0x75622074276e6143, %rax # imm = 0x75622074276E6143
     125:      	movq	%rax, 0x10(%rsp)
     12a:      	movb	$0x0, 0x38(%rsp)
     12f:      	leaq	0x10(%rsp), %rdi
     134:      	movl	$0x29, %eax
     139:      	movl	$0x6, %ecx
     13e:      	movl	$0x29, %esi
     143:      	xorl	%eax, %eax
     145:      	callq	*%rcx
     147:      	xorl	%eax, %eax
     149:      	jmp	0x5917 <perf_unwind_perl+0x5917>
     14e:      	movl	$0xf, 0x50(%rsp)
     156:      	movq	(%rip), %rdi            # 0x15d <perf_unwind_perl+0x15d>
     15d:      	leaq	0x50(%rsp), %rsi
     162:      	movl	$0x1, %eax
     167:      	callq	*%rax
     169:      	testq	%rax, %rax
     16c:      	je	0x2b8 <perf_unwind_perl+0x2b8>
     172:      	incq	(%rax)
     175:      	cmpb	$0x0, 0x14(%r14)
     17a:      	jne	0x2ce <perf_unwind_perl+0x2ce>
     180:      	movq	(%r14), %rax
     183:      	movq	%rax, 0x60(%rsp)
     188:      	movq	%r13, %rbp
     18b:      	cmpl	$0x0, (%r13)
     190:      	jne	0x2128 <perf_unwind_perl+0x2128>
     196:      	movzwl	0x12(%r14), %eax
     19b:      	addq	0x60(%rsp), %rax
     1a0:      	movl	$0x8, %ecx
     1a5:      	movl	$0x70, %r8d
     1ab:      	movq	0xb8(%rsp), %rdi
     1b3:      	movzwl	0x12(%r14), %edx
     1b8:      	addq	0x60(%rsp), %rdx
     1bd:      	movl	$0x8, %esi
     1c2:      	callq	*%r8
     1c5:      	testq	%rax, %rax
     1c8:      	jne	0x205 <perf_unwind_perl+0x205>
     1ca:      	leaq	0xf40(%r12), %r13
     1d2:      	movzwl	0x10(%r14), %eax
     1d7:      	addq	0x60(%rsp), %rax
     1dc:      	movl	$0x8, %ecx
     1e1:      	movl	$0x70, %r8d
     1e7:      	movzwl	0x10(%r14), %edx
     1ec:      	addq	0x60(%rsp), %rdx
     1f1:      	movq	%r13, %rdi
     1f4:      	movl	$0x8, %esi
     1f9:      	callq	*%r8
     1fc:      	testq	%rax, %rax
     1ff:      	je	0xa03 <perf_unwind_perl+0xa03>
     205:      	movq	%rbp, %r13
     208:      	cmpl	$0x0, (%rbp)
     20c:      	jne	0x22d8 <perf_unwind_perl+0x22d8>
     212:      	movl	$0x12, 0x50(%rsp)
     21a:      	movq	(%rip), %rdi            # 0x221 <perf_unwind_perl+0x221>
     221:      	leaq	0x50(%rsp), %rsi
     226:      	movl	$0x1, %eax
     22b:      	callq	*%rax
     22d:      	testq	%rax, %rax
     230:      	je	0x782 <perf_unwind_perl+0x782>
     236:      	incq	(%rax)
     239:      	movl	$0x1, %ebp
     23e:      	jmp	0x586a <perf_unwind_perl+0x586a>
     243:      	movq	%rcx, 0x98(%rsp)
     24b:      	movzbl	0x19(%r14), %eax
     250:      	addq	%r13, %rax
     253:      	leaq	0xe(%rsp), %rdi
     258:      	movl	$0x1, %ecx
     25d:      	movl	$0x70, %r8d
     263:      	movzbl	0x19(%r14), %edx
     268:      	addq	%r13, %rdx
     26b:      	movl	$0x1, %esi
     270:      	callq	*%r8
     273:      	testq	%rax, %rax
     276:      	je	0x39c <perf_unwind_perl+0x39c>
     27c:      	movq	(%rip), %rax            # 0x283 <perf_unwind_perl+0x283>
     283:      	cmpl	$0x0, (%rax)
     286:      	jne	0x1efd <perf_unwind_perl+0x1efd>
     28c:      	movl	$0x13, 0x50(%rsp)
     294:      	movq	(%rip), %rdi            # 0x29b <perf_unwind_perl+0x29b>
     29b:      	leaq	0x50(%rsp), %rsi
     2a0:      	movl	$0x1, %eax
     2a5:      	callq	*%rax
     2a7:      	testq	%rax, %rax
     2aa:      	je	0x4b8 <perf_unwind_perl+0x4b8>
     2b0:      	incq	(%rax)
     2b3:      	jmp	0x4c8 <perf_unwind_perl+0x4c8>
     2b8:      	cmpl	$0x0, (%r13)
     2bd:      	jne	0x21d0 <perf_unwind_perl+0x21d0>
     2c3:      	cmpb	$0x0, 0x14(%r14)
     2c8:      	je	0x180 <perf_unwind_perl+0x180>
     2ce:      	movl	$0x23, %eax
     2d3:      	callq	*%rax
     2d5:      	movq	(%rip), %rcx            # 0x2dc <perf_unwind_perl+0x2dc>
     2dc:      	addq	(%rcx), %rax
     2df:      	leaq	0x88(%rsp), %rdi
     2e7:      	movl	$0x8, %ecx
     2ec:      	movl	$0x71, %r8d
     2f2:      	movl	$0x8, %esi
     2f7:      	movq	%rax, %rdx
     2fa:      	callq	*%r8
     2fd:      	testq	%rax, %rax
     300:      	je	0x5a9 <perf_unwind_perl+0x5a9>
     306:      	cmpl	$0x0, (%r13)
     30b:      	jne	0x2177 <perf_unwind_perl+0x2177>
     311:      	movl	$0x4, 0x50(%rsp)
     319:      	movq	(%rip), %rdi            # 0x320 <perf_unwind_perl+0x320>
     320:      	leaq	0x50(%rsp), %rsi
     325:      	movl	$0x1, %eax
     32a:      	callq	*%rax
     32c:      	testq	%rax, %rax
     32f:      	je	0x6f1 <perf_unwind_perl+0x6f1>
     335:      	incq	(%rax)
     338:      	cmpl	$0x0, (%r13)
     33d:      	je	0xbb4 <perf_unwind_perl+0xbb4>
     343:      	movabsq	$0xa737365726464, %rax  # imm = 0xA737365726464
     34d:      	movq	%rax, 0x28(%rsp)
     352:      	movabsq	$0x6120657361622044, %rax # imm = 0x6120657361622044
     35c:      	movq	%rax, 0x20(%rsp)
     361:      	movabsq	$0x535420746567206f, %rax # imm = 0x535420746567206F
     36b:      	movq	%rax, 0x18(%rsp)
     370:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     37a:      	movq	%rax, 0x10(%rsp)
     37f:      	leaq	0x10(%rsp), %rdi
     384:      	movl	$0x20, %eax
     389:      	movl	$0x6, %ecx
     38e:      	movl	$0x20, %esi
     393:      	xorl	%eax, %eax
     395:      	callq	*%rcx
     397:      	jmp	0xbb4 <perf_unwind_perl+0xbb4>
     39c:      	movq	(%rip), %rax            # 0x3a3 <perf_unwind_perl+0x3a3>
     3a3:      	cmpl	$0x0, (%rax)
     3a6:      	jne	0x23a5 <perf_unwind_perl+0x23a5>
     3ac:      	movzbl	0xe(%rsp), %eax
     3b1:      	movl	%eax, %ecx
     3b3:      	andl	$0xf, %ecx
     3b6:      	movl	$0x3, %ebp
     3bb:      	leal	-0x9(%rcx), %edx
     3be:      	cmpl	$0x2, %edx
     3c1:      	jae	0x641 <perf_unwind_perl+0x641>
     3c7:      	testb	%al, %al
     3c9:      	js	0x4cd <perf_unwind_perl+0x4cd>
     3cf:      	movzbl	0x1b(%r14), %eax
     3d4:      	addq	%r13, %rax
     3d7:      	leaq	0x10(%rsp), %rdi
     3dc:      	movl	$0x8, %ecx
     3e1:      	movl	$0x70, %r8d
     3e7:      	movzbl	0x1b(%r14), %edx
     3ec:      	addq	%r13, %rdx
     3ef:      	movl	$0x8, %esi
     3f4:      	callq	*%r8
     3f7:      	testq	%rax, %rax
     3fa:      	jne	0x27c <perf_unwind_perl+0x27c>
     400:      	cmpq	$0x0, 0x10(%rsp)
     406:      	setne	%bpl
     40a:      	movzbl	0x1c(%r14), %eax
     40f:      	addq	%r13, %rax
     412:      	leaq	0xa0(%rsp), %rdi
     41a:      	movl	$0x8, %ecx
     41f:      	movl	$0x70, %r8d
     425:      	movzbl	0x1c(%r14), %edx
     42a:      	addq	%r13, %rdx
     42d:      	movl	$0x8, %esi
     432:      	callq	*%r8
     435:      	testq	%rax, %rax
     438:      	jne	0x27c <perf_unwind_perl+0x27c>
     43e:      	movb	%bpl, 0xf(%rsp)
     443:      	movq	0xa0(%rsp), %rbp
     44b:      	movzbl	0x1e(%r14), %eax
     450:      	addq	%rbp, %rax
     453:      	leaq	0x5c(%rsp), %rdi
     458:      	movl	$0x4, %ecx
     45d:      	movl	$0x70, %r8d
     463:      	movzbl	0x1e(%r14), %edx
     468:      	addq	%rbp, %rdx
     46b:      	movl	$0x4, %esi
     470:      	callq	*%r8
     473:      	testq	%rax, %rax
     476:      	je	0xf5a <perf_unwind_perl+0xf5a>
     47c:      	movq	(%rip), %rax            # 0x483 <perf_unwind_perl+0x483>
     483:      	cmpl	$0x0, (%rax)
     486:      	jne	0x3a01 <perf_unwind_perl+0x3a01>
     48c:      	movl	$0x14, 0x74(%rsp)
     494:      	movq	(%rip), %rdi            # 0x49b <perf_unwind_perl+0x49b>
     49b:      	leaq	0x74(%rsp), %rsi
     4a0:      	movl	$0x1, %eax
     4a5:      	callq	*%rax
     4a7:      	testq	%rax, %rax
     4aa:      	je	0x12e7 <perf_unwind_perl+0x12e7>
     4b0:      	incq	(%rax)
     4b3:      	jmp	0x27c <perf_unwind_perl+0x27c>
     4b8:      	movq	(%rip), %rax            # 0x4bf <perf_unwind_perl+0x4bf>
     4bf:      	cmpl	$0x0, (%rax)
     4c2:      	jne	0x2569 <perf_unwind_perl+0x2569>
     4c8:      	movl	$0x3, %ebp
     4cd:      	movzbl	0x1d(%r14), %eax
     4d2:      	subq	%rax, 0xf50(%r15)
     4d9:      	movl	$0x10, 0x50(%rsp)
     4e1:      	movq	(%rip), %rdi            # 0x4e8 <perf_unwind_perl+0x4e8>
     4e8:      	leaq	0x50(%rsp), %rsi
     4ed:      	movl	$0x1, %eax
     4f2:      	callq	*%rax
     4f4:      	testq	%rax, %rax
     4f7:      	je	0x506 <perf_unwind_perl+0x506>
     4f9:      	incq	(%rax)
     4fc:      	movq	0x98(%rsp), %rcx
     504:      	jmp	0x51e <perf_unwind_perl+0x51e>
     506:      	movq	(%rip), %rax            # 0x50d <perf_unwind_perl+0x50d>
     50d:      	cmpl	$0x0, (%rax)
     510:      	movq	0x98(%rsp), %rcx
     518:      	jne	0x23ec <perf_unwind_perl+0x23ec>
     51e:      	cmpl	$0x3, %ebp
     521:      	jne	0x5636 <perf_unwind_perl+0x5636>
     527:      	movq	0xf50(%r15), %r13
     52e:      	cmpq	%rcx, %r13
     531:      	jb	0xcb <perf_unwind_perl+0xcb>
     537:      	movzbl	0x19(%r14), %eax
     53c:      	addq	%r13, %rax
     53f:      	leaq	0xe(%rsp), %rdi
     544:      	movl	$0x1, %ecx
     549:      	movl	$0x70, %r8d
     54f:      	movzbl	0x19(%r14), %edx
     554:      	addq	%r13, %rdx
     557:      	movl	$0x1, %esi
     55c:      	callq	*%r8
     55f:      	testq	%rax, %rax
     562:      	je	0x8cd <perf_unwind_perl+0x8cd>
     568:      	movq	(%rip), %rax            # 0x56f <perf_unwind_perl+0x56f>
     56f:      	cmpl	$0x0, (%rax)
     572:      	jne	0x29a3 <perf_unwind_perl+0x29a3>
     578:      	movl	$0x13, 0x50(%rsp)
     580:      	movq	(%rip), %rdi            # 0x587 <perf_unwind_perl+0x587>
     587:      	leaq	0x50(%rsp), %rsi
     58c:      	movl	$0x1, %eax
     591:      	callq	*%rax
     593:      	testq	%rax, %rax
     596:      	je	0x9e9 <perf_unwind_perl+0x9e9>
     59c:      	incq	(%rax)
     59f:      	movl	$0x3, %ebp
     5a4:      	jmp	0xacd <perf_unwind_perl+0xacd>
     5a9:      	movq	(%r14), %rax
     5ac:      	leaq	0xb4(%rsp), %rdi
     5b4:      	movl	$0x4, %ecx
     5b9:      	movl	$0x70, %r8d
     5bf:      	movq	(%r14), %rdx
     5c2:      	movl	$0x4, %esi
     5c7:      	callq	*%r8
     5ca:      	testq	%rax, %rax
     5cd:      	je	0x808 <perf_unwind_perl+0x808>
     5d3:      	cmpl	$0x0, (%r13)
     5d8:      	je	0xbb4 <perf_unwind_perl+0xbb4>
     5de:      	movabsq	$0x786c257830206d6f, %rax # imm = 0x786C257830206D6F
     5e8:      	movq	%rax, 0x28(%rsp)
     5ed:      	movabsq	$0x72662079654b6473, %rax # imm = 0x72662079654B6473
     5f7:      	movq	%rax, 0x20(%rsp)
     5fc:      	movabsq	$0x742064616572206f, %rax # imm = 0x742064616572206F
     606:      	movq	%rax, 0x18(%rsp)
     60b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     615:      	movq	%rax, 0x10(%rsp)
     61a:      	movw	$0xa, 0x30(%rsp)
     621:      	leaq	0x10(%rsp), %rdi
     626:      	movl	$0x22, %eax
     62b:      	movl	$0x6, %ecx
     630:      	movq	(%r14), %rdx
     633:      	movl	$0x22, %esi
     638:      	xorl	%eax, %eax
     63a:      	callq	*%rcx
     63c:      	jmp	0xbb4 <perf_unwind_perl+0xbb4>
     641:      	cmpl	$0xc, %ecx
     644:      	je	0x4cd <perf_unwind_perl+0x4cd>
     64a:      	cmpq	$0x0, (%r12)
     64f:      	jne	0x4cd <perf_unwind_perl+0x4cd>
     655:      	movzbl	0x1a(%r14), %eax
     65a:      	addq	%r13, %rax
     65d:      	movl	$0x8, %ecx
     662:      	movl	$0x70, %r8d
     668:      	movzbl	0x1a(%r14), %edx
     66d:      	addq	%r13, %rdx
     670:      	movq	%r12, %rdi
     673:      	movl	$0x8, %esi
     678:      	callq	*%r8
     67b:      	testq	%rax, %rax
     67e:      	jne	0x27c <perf_unwind_perl+0x27c>
     684:      	movq	(%rip), %rax            # 0x68b <perf_unwind_perl+0x68b>
     68b:      	cmpl	$0x0, (%rax)
     68e:      	je	0x4cd <perf_unwind_perl+0x4cd>
     694:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
     69e:      	movq	%rax, 0x26(%rsp)
     6a3:      	movabsq	$0x30206b6361747320, %rax # imm = 0x30206B6361747320
     6ad:      	movq	%rax, 0x20(%rsp)
     6b2:      	movabsq	$0x747865746e6f6320, %rax # imm = 0x747865746E6F6320
     6bc:      	movq	%rax, 0x18(%rsp)
     6c1:      	movabsq	$0x6d6f726620504f43, %rax # imm = 0x6D6F726620504F43
     6cb:      	movq	%rax, 0x10(%rsp)
     6d0:      	leaq	0x10(%rsp), %rdi
     6d5:      	movl	$0x1e, %eax
     6da:      	movl	$0x6, %ecx
     6df:      	movq	(%r12), %rdx
     6e3:      	movl	$0x1e, %esi
     6e8:      	xorl	%eax, %eax
     6ea:      	callq	*%rcx
     6ec:      	jmp	0x4cd <perf_unwind_perl+0x4cd>
     6f1:      	cmpl	$0x0, (%r13)
     6f6:      	je	0xbb4 <perf_unwind_perl+0xbb4>
     6fc:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     706:      	movq	%rax, 0x36(%rsp)
     70b:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     715:      	movq	%rax, 0x30(%rsp)
     71a:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     724:      	movq	%rax, 0x28(%rsp)
     729:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     733:      	movq	%rax, 0x20(%rsp)
     738:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     742:      	movq	%rax, 0x18(%rsp)
     747:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     751:      	movq	%rax, 0x10(%rsp)
     756:      	leaq	0x10(%rsp), %rdi
     75b:      	movl	$0x2e, %eax
     760:      	movl	$0x6, %ecx
     765:      	movl	0x50(%rsp), %edx
     769:      	movl	$0x2e, %esi
     76e:      	xorl	%eax, %eax
     770:      	callq	*%rcx
     772:      	cmpl	$0x0, (%r13)
     777:      	je	0xbb4 <perf_unwind_perl+0xbb4>
     77d:      	jmp	0x343 <perf_unwind_perl+0x343>
     782:      	cmpl	$0x0, (%r13)
     787:      	je	0xbe4 <perf_unwind_perl+0xbe4>
     78d:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     797:      	movq	%rax, 0x36(%rsp)
     79c:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     7a6:      	movq	%rax, 0x30(%rsp)
     7ab:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     7b5:      	movq	%rax, 0x28(%rsp)
     7ba:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     7c4:      	movq	%rax, 0x20(%rsp)
     7c9:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     7d3:      	movq	%rax, 0x18(%rsp)
     7d8:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     7e2:      	movq	%rax, 0x10(%rsp)
     7e7:      	leaq	0x10(%rsp), %rdi
     7ec:      	movl	$0x2e, %eax
     7f1:      	movl	$0x6, %ecx
     7f6:      	movl	0x50(%rsp), %edx
     7fa:      	movl	$0x2e, %esi
     7ff:      	xorl	%eax, %eax
     801:      	callq	*%rcx
     803:      	jmp	0xbe4 <perf_unwind_perl+0xbe4>
     808:      	movq	%r13, %rbp
     80b:      	movslq	0xb4(%rsp), %r13
     813:      	movswq	0xc(%r14), %rax
     818:      	addq	0x88(%rsp), %rax
     820:      	movq	%rax, 0x50(%rsp)
     825:      	cmpb	$0x0, 0xf(%r14)
     82a:      	je	0x853 <perf_unwind_perl+0x853>
     82c:      	leaq	0x50(%rsp), %rdi
     831:      	movl	$0x8, %ecx
     836:      	movl	$0x70, %r8d
     83c:      	movq	0x50(%rsp), %rdx
     841:      	movl	$0x8, %esi
     846:      	callq	*%r8
     849:      	testq	%rax, %rax
     84c:      	jne	0x894 <perf_unwind_perl+0x894>
     84e:      	movq	0x50(%rsp), %rax
     853:      	movzbl	0xe(%r14), %ecx
     858:      	imulq	%r13, %rcx
     85c:      	addq	%rax, %rcx
     85f:      	movq	%rcx, 0x50(%rsp)
     864:      	cmpl	$0x0, (%rbp)
     868:      	jne	0x2fb0 <perf_unwind_perl+0x2fb0>
     86e:      	leaq	0x60(%rsp), %rdi
     873:      	movl	$0x8, %eax
     878:      	movl	$0x70, %r8d
     87e:      	movq	0x50(%rsp), %rdx
     883:      	movl	$0x8, %esi
     888:      	callq	*%r8
     88b:      	testq	%rax, %rax
     88e:      	je	0xbee <perf_unwind_perl+0xbee>
     894:      	movq	%rbp, %r13
     897:      	cmpl	$0x0, (%rbp)
     89b:      	jne	0x2e73 <perf_unwind_perl+0x2e73>
     8a1:      	movl	$0x3, 0x78(%rsp)
     8a9:      	movq	(%rip), %rdi            # 0x8b0 <perf_unwind_perl+0x8b0>
     8b0:      	leaq	0x78(%rsp), %rsi
     8b5:      	movl	$0x1, %eax
     8ba:      	callq	*%rax
     8bc:      	testq	%rax, %rax
     8bf:      	je	0xba9 <perf_unwind_perl+0xba9>
     8c5:      	incq	(%rax)
     8c8:      	jmp	0xbb4 <perf_unwind_perl+0xbb4>
     8cd:      	movq	(%rip), %rax            # 0x8d4 <perf_unwind_perl+0x8d4>
     8d4:      	cmpl	$0x0, (%rax)
     8d7:      	jne	0x2cbd <perf_unwind_perl+0x2cbd>
     8dd:      	movzbl	0xe(%rsp), %eax
     8e2:      	movl	%eax, %ecx
     8e4:      	andl	$0xf, %ecx
     8e7:      	movl	$0x3, %ebp
     8ec:      	leal	-0x9(%rcx), %edx
     8ef:      	cmpl	$0x2, %edx
     8f2:      	jae	0xabd <perf_unwind_perl+0xabd>
     8f8:      	testb	%al, %al
     8fa:      	js	0xacd <perf_unwind_perl+0xacd>
     900:      	movzbl	0x1b(%r14), %eax
     905:      	addq	%r13, %rax
     908:      	leaq	0x10(%rsp), %rdi
     90d:      	movl	$0x8, %ecx
     912:      	movl	$0x70, %r8d
     918:      	movzbl	0x1b(%r14), %edx
     91d:      	addq	%r13, %rdx
     920:      	movl	$0x8, %esi
     925:      	callq	*%r8
     928:      	testq	%rax, %rax
     92b:      	jne	0x568 <perf_unwind_perl+0x568>
     931:      	cmpq	$0x0, 0x10(%rsp)
     937:      	setne	%bpl
     93b:      	movzbl	0x1c(%r14), %eax
     940:      	addq	%r13, %rax
     943:      	leaq	0xa0(%rsp), %rdi
     94b:      	movl	$0x8, %ecx
     950:      	movl	$0x70, %r8d
     956:      	movzbl	0x1c(%r14), %edx
     95b:      	addq	%r13, %rdx
     95e:      	movl	$0x8, %esi
     963:      	callq	*%r8
     966:      	testq	%rax, %rax
     969:      	jne	0x568 <perf_unwind_perl+0x568>
     96f:      	movb	%bpl, 0xf(%rsp)
     974:      	movq	0xa0(%rsp), %rbp
     97c:      	movzbl	0x1e(%r14), %eax
     981:      	addq	%rbp, %rax
     984:      	leaq	0x5c(%rsp), %rdi
     989:      	movl	$0x4, %ecx
     98e:      	movl	$0x70, %r8d
     994:      	movzbl	0x1e(%r14), %edx
     999:      	addq	%rbp, %rdx
     99c:      	movl	$0x4, %esi
     9a1:      	callq	*%r8
     9a4:      	testq	%rax, %rax
     9a7:      	je	0x1573 <perf_unwind_perl+0x1573>
     9ad:      	movq	(%rip), %rax            # 0x9b4 <perf_unwind_perl+0x9b4>
     9b4:      	cmpl	$0x0, (%rax)
     9b7:      	jne	0x43ed <perf_unwind_perl+0x43ed>
     9bd:      	movl	$0x14, 0x74(%rsp)
     9c5:      	movq	(%rip), %rdi            # 0x9cc <perf_unwind_perl+0x9cc>
     9cc:      	leaq	0x74(%rsp), %rsi
     9d1:      	movl	$0x1, %eax
     9d6:      	callq	*%rax
     9d8:      	testq	%rax, %rax
     9db:      	je	0x19ca <perf_unwind_perl+0x19ca>
     9e1:      	incq	(%rax)
     9e4:      	jmp	0x568 <perf_unwind_perl+0x568>
     9e9:      	movq	(%rip), %rax            # 0x9f0 <perf_unwind_perl+0x9f0>
     9f0:      	cmpl	$0x0, (%rax)
     9f3:      	jne	0x2ed1 <perf_unwind_perl+0x2ed1>
     9f9:      	movl	$0x3, %ebp
     9fe:      	jmp	0xacd <perf_unwind_perl+0xacd>
     a03:      	cmpl	$0x0, (%rbp)
     a07:      	jne	0x2f4c <perf_unwind_perl+0x2f4c>
     a0d:      	movq	0xb8(%rsp), %rax
     a15:      	movq	(%rax), %r13
     a18:      	movzbl	0x15(%r14), %eax
     a1d:      	addq	%r13, %rax
     a20:      	leaq	0x50(%rsp), %rdi
     a25:      	movl	$0x8, %ecx
     a2a:      	movl	$0x70, %r8d
     a30:      	movzbl	0x15(%r14), %edx
     a35:      	addq	%r13, %rdx
     a38:      	movl	$0x8, %esi
     a3d:      	callq	*%r8
     a40:      	testq	%rax, %rax
     a43:      	jne	0xa76 <perf_unwind_perl+0xa76>
     a45:      	movzbl	0x17(%r14), %eax
     a4a:      	addq	%r13, %rax
     a4d:      	leaq	0x78(%rsp), %rdi
     a52:      	movl	$0x4, %ecx
     a57:      	movl	$0x70, %r8d
     a5d:      	movzbl	0x17(%r14), %edx
     a62:      	addq	%r13, %rdx
     a65:      	movl	$0x4, %esi
     a6a:      	callq	*%r8
     a6d:      	testq	%rax, %rax
     a70:      	je	0xf08 <perf_unwind_perl+0xf08>
     a76:      	cmpl	$0x0, (%rbp)
     a7a:      	jne	0x3020 <perf_unwind_perl+0x3020>
     a80:      	orb	$0x8, 0x1380(%r15)
     a88:      	movl	$0x12, 0x88(%rsp)
     a93:      	movq	(%rip), %rdi            # 0xa9a <perf_unwind_perl+0xa9a>
     a9a:      	leaq	0x88(%rsp), %rsi
     aa2:      	movl	$0x1, %eax
     aa7:      	callq	*%rax
     aa9:      	testq	%rax, %rax
     aac:      	je	0xd7a <perf_unwind_perl+0xd7a>
     ab2:      	incq	(%rax)
     ab5:      	movq	%rbp, %r13
     ab8:      	jmp	0xf39 <perf_unwind_perl+0xf39>
     abd:      	cmpl	$0xc, %ecx
     ac0:      	je	0xacd <perf_unwind_perl+0xacd>
     ac2:      	cmpq	$0x0, (%r12)
     ac7:      	je	0x1816 <perf_unwind_perl+0x1816>
     acd:      	movzbl	0x1d(%r14), %eax
     ad2:      	subq	%rax, 0xf50(%r15)
     ad9:      	movl	$0x10, 0x50(%rsp)
     ae1:      	movq	(%rip), %rdi            # 0xae8 <perf_unwind_perl+0xae8>
     ae8:      	leaq	0x50(%rsp), %rsi
     aed:      	movl	$0x1, %eax
     af2:      	callq	*%rax
     af4:      	testq	%rax, %rax
     af7:      	je	0xb06 <perf_unwind_perl+0xb06>
     af9:      	incq	(%rax)
     afc:      	movq	0x98(%rsp), %rcx
     b04:      	jmp	0xb1e <perf_unwind_perl+0xb1e>
     b06:      	movq	(%rip), %rax            # 0xb0d <perf_unwind_perl+0xb0d>
     b0d:      	cmpl	$0x0, (%rax)
     b10:      	movq	0x98(%rsp), %rcx
     b18:      	jne	0x2d04 <perf_unwind_perl+0x2d04>
     b1e:      	cmpl	$0x3, %ebp
     b21:      	jne	0x5636 <perf_unwind_perl+0x5636>
     b27:      	movq	0xf50(%r15), %r13
     b2e:      	cmpq	%rcx, %r13
     b31:      	jb	0xcb <perf_unwind_perl+0xcb>
     b37:      	movzbl	0x19(%r14), %eax
     b3c:      	addq	%r13, %rax
     b3f:      	leaq	0xe(%rsp), %rdi
     b44:      	movl	$0x1, %ecx
     b49:      	movl	$0x70, %r8d
     b4f:      	movzbl	0x19(%r14), %edx
     b54:      	addq	%r13, %rdx
     b57:      	movl	$0x1, %esi
     b5c:      	callq	*%r8
     b5f:      	testq	%rax, %rax
     b62:      	je	0xc5e <perf_unwind_perl+0xc5e>
     b68:      	movq	(%rip), %rax            # 0xb6f <perf_unwind_perl+0xb6f>
     b6f:      	cmpl	$0x0, (%rax)
     b72:      	jne	0x33c3 <perf_unwind_perl+0x33c3>
     b78:      	movl	$0x13, 0x50(%rsp)
     b80:      	movq	(%rip), %rdi            # 0xb87 <perf_unwind_perl+0xb87>
     b87:      	leaq	0x50(%rsp), %rsi
     b8c:      	movl	$0x1, %eax
     b91:      	callq	*%rax
     b93:      	testq	%rax, %rax
     b96:      	je	0xe05 <perf_unwind_perl+0xe05>
     b9c:      	incq	(%rax)
     b9f:      	movl	$0x3, %ebp
     ba4:      	jmp	0xe2c <perf_unwind_perl+0xe2c>
     ba9:      	cmpl	$0x0, (%r13)
     bae:      	jne	0x3666 <perf_unwind_perl+0x3666>
     bb4:      	movl	$0x11, 0x50(%rsp)
     bbc:      	movq	(%rip), %rdi            # 0xbc3 <perf_unwind_perl+0xbc3>
     bc3:      	leaq	0x50(%rsp), %rsi
     bc8:      	movl	$0x1, %eax
     bcd:      	callq	*%rax
     bcf:      	testq	%rax, %rax
     bd2:      	je	0xbd9 <perf_unwind_perl+0xbd9>
     bd4:      	incq	(%rax)
     bd7:      	jmp	0xbe4 <perf_unwind_perl+0xbe4>
     bd9:      	cmpl	$0x0, (%r13)
     bde:      	jne	0x25e4 <perf_unwind_perl+0x25e4>
     be4:      	movl	$0x1, %ebp
     be9:      	jmp	0x586a <perf_unwind_perl+0x586a>
     bee:      	movq	%rbp, %r13
     bf1:      	cmpl	$0x0, (%rbp)
     bf5:      	je	0x188 <perf_unwind_perl+0x188>
     bfb:      	movabsq	$0x2079654b20445354, %rax # imm = 0x2079654B20445354
     c05:      	movq	%rax, 0x20(%rsp)
     c0a:      	movabsq	$0x202c786c25783020, %rax # imm = 0x202C786C25783020
     c14:      	movq	%rax, 0x18(%rsp)
     c19:      	movabsq	$0x6573614220445354, %rax # imm = 0x6573614220445354
     c23:      	movq	%rax, 0x10(%rsp)
     c28:      	movl	$0xa6425, 0x28(%rsp)    # imm = 0xA6425
     c30:      	leaq	0x10(%rsp), %rdi
     c35:      	movl	$0x1c, %eax
     c3a:      	movl	$0x6, %r8d
     c40:      	movq	0x88(%rsp), %rdx
     c48:      	movl	0xb4(%rsp), %ecx
     c4f:      	movl	$0x1c, %esi
     c54:      	xorl	%eax, %eax
     c56:      	callq	*%r8
     c59:      	jmp	0x188 <perf_unwind_perl+0x188>
     c5e:      	movq	(%rip), %rax            # 0xc65 <perf_unwind_perl+0xc65>
     c65:      	cmpl	$0x0, (%rax)
     c68:      	jne	0x37d0 <perf_unwind_perl+0x37d0>
     c6e:      	movzbl	0xe(%rsp), %eax
     c73:      	movl	%eax, %ecx
     c75:      	andl	$0xf, %ecx
     c78:      	movl	$0x3, %ebp
     c7d:      	leal	-0x9(%rcx), %edx
     c80:      	cmpl	$0x2, %edx
     c83:      	jae	0xe1c <perf_unwind_perl+0xe1c>
     c89:      	testb	%al, %al
     c8b:      	js	0xe2c <perf_unwind_perl+0xe2c>
     c91:      	movzbl	0x1b(%r14), %eax
     c96:      	addq	%r13, %rax
     c99:      	leaq	0x10(%rsp), %rdi
     c9e:      	movl	$0x8, %ecx
     ca3:      	movl	$0x70, %r8d
     ca9:      	movzbl	0x1b(%r14), %edx
     cae:      	addq	%r13, %rdx
     cb1:      	movl	$0x8, %esi
     cb6:      	callq	*%r8
     cb9:      	testq	%rax, %rax
     cbc:      	jne	0xb68 <perf_unwind_perl+0xb68>
     cc2:      	cmpq	$0x0, 0x10(%rsp)
     cc8:      	setne	%bpl
     ccc:      	movzbl	0x1c(%r14), %eax
     cd1:      	addq	%r13, %rax
     cd4:      	leaq	0xa0(%rsp), %rdi
     cdc:      	movl	$0x8, %ecx
     ce1:      	movl	$0x70, %r8d
     ce7:      	movzbl	0x1c(%r14), %edx
     cec:      	addq	%r13, %rdx
     cef:      	movl	$0x8, %esi
     cf4:      	callq	*%r8
     cf7:      	testq	%rax, %rax
     cfa:      	jne	0xb68 <perf_unwind_perl+0xb68>
     d00:      	movb	%bpl, 0xf(%rsp)
     d05:      	movq	0xa0(%rsp), %rbp
     d0d:      	movzbl	0x1e(%r14), %eax
     d12:      	addq	%rbp, %rax
     d15:      	leaq	0x5c(%rsp), %rdi
     d1a:      	movl	$0x4, %ecx
     d1f:      	movl	$0x70, %r8d
     d25:      	movzbl	0x1e(%r14), %edx
     d2a:      	addq	%rbp, %rdx
     d2d:      	movl	$0x4, %esi
     d32:      	callq	*%r8
     d35:      	testq	%rax, %rax
     d38:      	je	0x1bbe <perf_unwind_perl+0x1bbe>
     d3e:      	movq	(%rip), %rax            # 0xd45 <perf_unwind_perl+0xd45>
     d45:      	cmpl	$0x0, (%rax)
     d48:      	jne	0x4d9b <perf_unwind_perl+0x4d9b>
     d4e:      	movl	$0x14, 0x74(%rsp)
     d56:      	movq	(%rip), %rdi            # 0xd5d <perf_unwind_perl+0xd5d>
     d5d:      	leaq	0x74(%rsp), %rsi
     d62:      	movl	$0x1, %eax
     d67:      	callq	*%rax
     d69:      	testq	%rax, %rax
     d6c:      	je	0x2087 <perf_unwind_perl+0x2087>
     d72:      	incq	(%rax)
     d75:      	jmp	0xb68 <perf_unwind_perl+0xb68>
     d7a:      	movq	%rbp, %r13
     d7d:      	cmpl	$0x0, (%rbp)
     d81:      	je	0xf39 <perf_unwind_perl+0xf39>
     d87:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     d91:      	movq	%rax, 0x36(%rsp)
     d96:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     da0:      	movq	%rax, 0x30(%rsp)
     da5:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     daf:      	movq	%rax, 0x28(%rsp)
     db4:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     dbe:      	movq	%rax, 0x20(%rsp)
     dc3:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     dcd:      	movq	%rax, 0x18(%rsp)
     dd2:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     ddc:      	movq	%rax, 0x10(%rsp)
     de1:      	leaq	0x10(%rsp), %rdi
     de6:      	movl	$0x2e, %eax
     deb:      	movl	$0x6, %ecx
     df0:      	movl	0x88(%rsp), %edx
     df7:      	movl	$0x2e, %esi
     dfc:      	xorl	%eax, %eax
     dfe:      	callq	*%rcx
     e00:      	jmp	0xf39 <perf_unwind_perl+0xf39>
     e05:      	movq	(%rip), %rax            # 0xe0c <perf_unwind_perl+0xe0c>
     e0c:      	cmpl	$0x0, (%rax)
     e0f:      	jne	0x3986 <perf_unwind_perl+0x3986>
     e15:      	movl	$0x3, %ebp
     e1a:      	jmp	0xe2c <perf_unwind_perl+0xe2c>
     e1c:      	cmpl	$0xc, %ecx
     e1f:      	je	0xe2c <perf_unwind_perl+0xe2c>
     e21:      	cmpq	$0x0, (%r12)
     e26:      	je	0x1e61 <perf_unwind_perl+0x1e61>
     e2c:      	movzbl	0x1d(%r14), %eax
     e31:      	subq	%rax, 0xf50(%r15)
     e38:      	movl	$0x10, 0x50(%rsp)
     e40:      	movq	(%rip), %rdi            # 0xe47 <perf_unwind_perl+0xe47>
     e47:      	leaq	0x50(%rsp), %rsi
     e4c:      	movl	$0x1, %eax
     e51:      	callq	*%rax
     e53:      	testq	%rax, %rax
     e56:      	je	0xe65 <perf_unwind_perl+0xe65>
     e58:      	incq	(%rax)
     e5b:      	movq	0x98(%rsp), %rcx
     e63:      	jmp	0xe7d <perf_unwind_perl+0xe7d>
     e65:      	movq	(%rip), %rax            # 0xe6c <perf_unwind_perl+0xe6c>
     e6c:      	cmpl	$0x0, (%rax)
     e6f:      	movq	0x98(%rsp), %rcx
     e77:      	jne	0x3817 <perf_unwind_perl+0x3817>
     e7d:      	cmpl	$0x3, %ebp
     e80:      	jne	0x5636 <perf_unwind_perl+0x5636>
     e86:      	movq	0xf50(%r15), %r13
     e8d:      	cmpq	%rcx, %r13
     e90:      	jb	0xcb <perf_unwind_perl+0xcb>
     e96:      	movzbl	0x19(%r14), %eax
     e9b:      	addq	%r13, %rax
     e9e:      	leaq	0xe(%rsp), %rdi
     ea3:      	movl	$0x1, %ecx
     ea8:      	movl	$0x70, %r8d
     eae:      	movzbl	0x19(%r14), %edx
     eb3:      	addq	%r13, %rdx
     eb6:      	movl	$0x1, %esi
     ebb:      	callq	*%r8
     ebe:      	testq	%rax, %rax
     ec1:      	je	0x11cf <perf_unwind_perl+0x11cf>
     ec7:      	movq	(%rip), %rax            # 0xece <perf_unwind_perl+0xece>
     ece:      	cmpl	$0x0, (%rax)
     ed1:      	jne	0x3db7 <perf_unwind_perl+0x3db7>
     ed7:      	movl	$0x13, 0x50(%rsp)
     edf:      	movq	(%rip), %rdi            # 0xee6 <perf_unwind_perl+0xee6>
     ee6:      	leaq	0x50(%rsp), %rsi
     eeb:      	movl	$0x1, %eax
     ef0:      	callq	*%rax
     ef2:      	testq	%rax, %rax
     ef5:      	je	0x136b <perf_unwind_perl+0x136b>
     efb:      	incq	(%rax)
     efe:      	movl	$0x3, %ebp
     f03:      	jmp	0x13ff <perf_unwind_perl+0x13ff>
     f08:      	movq	%rbp, %r13
     f0b:      	cmpl	$0x0, (%rbp)
     f0f:      	jne	0x4040 <perf_unwind_perl+0x4040>
     f15:      	movq	0x50(%rsp), %rax
     f1a:      	movq	%rax, 0xf48(%r15)
     f21:      	movslq	0x78(%rsp), %rcx
     f26:      	movzbl	0x1d(%r14), %edx
     f2b:      	imulq	%rcx, %rdx
     f2f:      	addq	%rax, %rdx
     f32:      	movq	%rdx, 0xf50(%r15)
     f39:      	movq	0xb8(%rsp), %rax
     f41:      	movq	(%rax), %rax
     f44:      	movq	%rax, 0xa8(%rsp)
     f4c:      	testq	%rax, %rax
     f4f:      	jne	0xad <perf_unwind_perl+0xad>
     f55:      	jmp	0xbe4 <perf_unwind_perl+0xbe4>
     f5a:      	movl	0x5c(%rsp), %eax
     f5e:      	andl	$0x1f, %eax
     f61:      	cmpl	$0xd, %eax
     f64:      	jne	0x1382 <perf_unwind_perl+0x1382>
     f6a:      	movzbl	0x1f(%r14), %eax
     f6f:      	addq	%rbp, %rax
     f72:      	leaq	0x50(%rsp), %rdi
     f77:      	movl	$0x8, %ecx
     f7c:      	movl	$0x70, %r8d
     f82:      	movzbl	0x1f(%r14), %edx
     f87:      	addq	%rbp, %rdx
     f8a:      	movl	$0x8, %esi
     f8f:      	callq	*%r8
     f92:      	testq	%rax, %rax
     f95:      	jne	0x47c <perf_unwind_perl+0x47c>
     f9b:      	movzbl	0x21(%r14), %eax
     fa0:      	addq	0x50(%rsp), %rax
     fa5:      	leaq	0x70(%rsp), %rdi
     faa:      	movl	$0x4, %ecx
     faf:      	movl	$0x70, %r8d
     fb5:      	movzbl	0x21(%r14), %edx
     fba:      	addq	0x50(%rsp), %rdx
     fbf:      	movl	$0x4, %esi
     fc4:      	callq	*%r8
     fc7:      	testq	%rax, %rax
     fca:      	jne	0x47c <perf_unwind_perl+0x47c>
     fd0:      	testb	$-0x80, 0x71(%rsp)
     fd5:      	jne	0x2256 <perf_unwind_perl+0x2256>
     fdb:      	movzbl	0x22(%r14), %eax
     fe0:      	addq	0x50(%rsp), %rax
     fe5:      	leaq	0x60(%rsp), %rbp
     fea:      	movl	$0x8, %ecx
     fef:      	movl	$0x70, %r8d
     ff5:      	movzbl	0x22(%r14), %edx
     ffa:      	addq	0x50(%rsp), %rdx
     fff:      	movq	%rbp, %rdi
    1002:      	movl	$0x8, %esi
    1007:      	callq	*%r8
    100a:      	testq	%rax, %rax
    100d:      	jne	0x47c <perf_unwind_perl+0x47c>
    1013:      	movq	0x60(%rsp), %rax
    1018:      	testq	%rax, %rax
    101b:      	je	0x47c <perf_unwind_perl+0x47c>
    1021:      	movq	(%rip), %rcx            # 0x1028 <perf_unwind_perl+0x1028>
    1028:      	cmpl	$0x0, (%rcx)
    102b:      	jne	0x65a5 <perf_unwind_perl+0x65a5>
    1031:      	movzbl	0x1e(%r14), %ecx
    1036:      	addq	%rax, %rcx
    1039:      	leaq	0x6c(%rsp), %rdi
    103e:      	movl	$0x4, %eax
    1043:      	movl	$0x70, %r8d
    1049:      	movzbl	0x1e(%r14), %edx
    104e:      	addq	0x60(%rsp), %rdx
    1053:      	movl	$0x4, %esi
    1058:      	callq	*%r8
    105b:      	testq	%rax, %rax
    105e:      	jne	0x47c <perf_unwind_perl+0x47c>
    1064:      	movl	$0x801f, %eax           # imm = 0x801F
    1069:      	andl	0x6c(%rsp), %eax
    106d:      	cmpl	$0x8009, %eax           # imm = 0x8009
    1072:      	jne	0x354d <perf_unwind_perl+0x354d>
    1078:      	movzbl	0x20(%r14), %eax
    107d:      	addq	0x60(%rsp), %rax
    1082:      	leaq	0x88(%rsp), %rdi
    108a:      	movl	$0x8, %ecx
    108f:      	movl	$0x70, %r8d
    1095:      	movzbl	0x20(%r14), %edx
    109a:      	addq	0x60(%rsp), %rdx
    109f:      	movl	$0x8, %esi
    10a4:      	callq	*%r8
    10a7:      	testq	%rax, %rax
    10aa:      	jne	0x47c <perf_unwind_perl+0x47c>
    10b0:      	movzbl	0x23(%r14), %eax
    10b5:      	addq	0x88(%rsp), %rax
    10bd:      	leaq	0x78(%rsp), %rdi
    10c2:      	movl	$0x8, %ecx
    10c7:      	movl	$0x70, %r8d
    10cd:      	movzbl	0x23(%r14), %edx
    10d2:      	addq	0x88(%rsp), %rdx
    10da:      	movl	$0x8, %esi
    10df:      	callq	*%r8
    10e2:      	testq	%rax, %rax
    10e5:      	jne	0x47c <perf_unwind_perl+0x47c>
    10eb:      	movq	0x78(%rsp), %rax
    10f0:      	movq	%rax, 0x80(%rsp)
    10f8:      	testq	%rax, %rax
    10fb:      	je	0x1151 <perf_unwind_perl+0x1151>
    10fd:      	movq	(%rip), %rax            # 0x1104 <perf_unwind_perl+0x1104>
    1104:      	cmpl	$0x0, (%rax)
    1107:      	je	0x1166 <perf_unwind_perl+0x1166>
    1109:      	movabsq	$0x2578302074612056, %rax # imm = 0x2578302074612056
    1113:      	movq	%rax, 0x18(%rsp)
    1118:      	movabsq	$0x474520646e756f46, %rax # imm = 0x474520646E756F46
    1122:      	movq	%rax, 0x10(%rsp)
    1127:      	movl	$0xa786c, 0x20(%rsp)    # imm = 0xA786C
    112f:      	leaq	0x10(%rsp), %rdi
    1134:      	movl	$0x14, %eax
    1139:      	movl	$0x6, %ecx
    113e:      	movq	0x78(%rsp), %rdx
    1143:      	movl	$0x14, %esi
    1148:      	xorl	%eax, %eax
    114a:      	callq	*%rcx
    114c:      	leaq	0x78(%rsp), %rbp
    1151:      	movq	(%rbp), %rax
    1155:      	movq	%rax, 0x80(%rsp)
    115d:      	testq	%rax, %rax
    1160:      	je	0x27c <perf_unwind_perl+0x27c>
    1166:      	movq	(%r12), %rax
    116a:      	movq	%rax, 0x90(%rsp)
    1172:      	movq	(%rip), %rax            # 0x1179 <perf_unwind_perl+0x1179>
    1179:      	cmpl	$0x0, (%rax)
    117c:      	jne	0x7d00 <perf_unwind_perl+0x7d00>
    1182:      	movl	0x2c0(%r15), %eax
    1189:      	cmpq	$0x7f, %rax
    118d:      	jb	0x7d86 <perf_unwind_perl+0x7d86>
    1193:      	movq	(%rip), %rax            # 0x119a <perf_unwind_perl+0x119a>
    119a:      	cmpl	$0x0, (%rax)
    119d:      	jne	0x7f4b <perf_unwind_perl+0x7f4b>
    11a3:      	movl	$0x2, 0x50(%rsp)
    11ab:      	movq	(%rip), %rdi            # 0x11b2 <perf_unwind_perl+0x11b2>
    11b2:      	leaq	0x50(%rsp), %rsi
    11b7:      	movl	$0x1, %eax
    11bc:      	callq	*%rax
    11be:      	testq	%rax, %rax
    11c1:      	je	0x4ceb <perf_unwind_perl+0x4ceb>
    11c7:      	incq	(%rax)
    11ca:      	jmp	0x4cfb <perf_unwind_perl+0x4cfb>
    11cf:      	movq	(%rip), %rax            # 0x11d6 <perf_unwind_perl+0x11d6>
    11d6:      	cmpl	$0x0, (%rax)
    11d9:      	jne	0x41bc <perf_unwind_perl+0x41bc>
    11df:      	movzbl	0xe(%rsp), %eax
    11e4:      	movl	%eax, %ecx
    11e6:      	andl	$0xf, %ecx
    11e9:      	movl	$0x3, %ebp
    11ee:      	leal	-0x9(%rcx), %edx
    11f1:      	cmpl	$0x2, %edx
    11f4:      	jae	0x13ef <perf_unwind_perl+0x13ef>
    11fa:      	testb	%al, %al
    11fc:      	js	0x13ff <perf_unwind_perl+0x13ff>
    1202:      	movzbl	0x1b(%r14), %eax
    1207:      	addq	%r13, %rax
    120a:      	leaq	0x10(%rsp), %rdi
    120f:      	movl	$0x8, %ecx
    1214:      	movl	$0x70, %r8d
    121a:      	movzbl	0x1b(%r14), %edx
    121f:      	addq	%r13, %rdx
    1222:      	movl	$0x8, %esi
    1227:      	callq	*%r8
    122a:      	testq	%rax, %rax
    122d:      	jne	0xec7 <perf_unwind_perl+0xec7>
    1233:      	cmpq	$0x0, 0x10(%rsp)
    1239:      	setne	0xf(%rsp)
    123e:      	movzbl	0x1c(%r14), %eax
    1243:      	addq	%r13, %rax
    1246:      	leaq	0xa0(%rsp), %rdi
    124e:      	movl	$0x8, %ecx
    1253:      	movl	$0x70, %r8d
    1259:      	movzbl	0x1c(%r14), %edx
    125e:      	addq	%r13, %rdx
    1261:      	movl	$0x8, %esi
    1266:      	callq	*%r8
    1269:      	testq	%rax, %rax
    126c:      	jne	0xec7 <perf_unwind_perl+0xec7>
    1272:      	movq	0xa0(%rsp), %rbp
    127a:      	movzbl	0x1e(%r14), %eax
    127f:      	addq	%rbp, %rax
    1282:      	leaq	0x5c(%rsp), %rdi
    1287:      	movl	$0x4, %ecx
    128c:      	movl	$0x70, %r8d
    1292:      	movzbl	0x1e(%r14), %edx
    1297:      	addq	%rbp, %rdx
    129a:      	movl	$0x4, %esi
    129f:      	callq	*%r8
    12a2:      	testq	%rax, %rax
    12a5:      	je	0x2664 <perf_unwind_perl+0x2664>
    12ab:      	movq	(%rip), %rax            # 0x12b2 <perf_unwind_perl+0x12b2>
    12b2:      	cmpl	$0x0, (%rax)
    12b5:      	jne	0x5f4c <perf_unwind_perl+0x5f4c>
    12bb:      	movl	$0x14, 0x74(%rsp)
    12c3:      	movq	(%rip), %rdi            # 0x12ca <perf_unwind_perl+0x12ca>
    12ca:      	leaq	0x74(%rsp), %rsi
    12cf:      	movl	$0x1, %eax
    12d4:      	callq	*%rax
    12d6:      	testq	%rax, %rax
    12d9:      	je	0x2b2d <perf_unwind_perl+0x2b2d>
    12df:      	incq	(%rax)
    12e2:      	jmp	0xec7 <perf_unwind_perl+0xec7>
    12e7:      	movq	(%rip), %rax            # 0x12ee <perf_unwind_perl+0x12ee>
    12ee:      	cmpl	$0x0, (%rax)
    12f1:      	je	0x27c <perf_unwind_perl+0x27c>
    12f7:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1301:      	movq	%rax, 0x36(%rsp)
    1306:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1310:      	movq	%rax, 0x30(%rsp)
    1315:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    131f:      	movq	%rax, 0x28(%rsp)
    1324:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    132e:      	movq	%rax, 0x20(%rsp)
    1333:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    133d:      	movq	%rax, 0x18(%rsp)
    1342:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    134c:      	movq	%rax, 0x10(%rsp)
    1351:      	leaq	0x10(%rsp), %rdi
    1356:      	movl	$0x2e, %eax
    135b:      	movl	$0x6, %ecx
    1360:      	movl	0x74(%rsp), %edx
    1364:      	movl	$0x2e, %esi
    1369:      	jmp	0x13e6 <perf_unwind_perl+0x13e6>
    136b:      	movq	(%rip), %rax            # 0x1372 <perf_unwind_perl+0x1372>
    1372:      	cmpl	$0x0, (%rax)
    1375:      	jne	0x4372 <perf_unwind_perl+0x4372>
    137b:      	movl	$0x3, %ebp
    1380:      	jmp	0x13ff <perf_unwind_perl+0x13ff>
    1382:      	movq	(%rip), %rax            # 0x1389 <perf_unwind_perl+0x1389>
    1389:      	cmpl	$0x0, (%rax)
    138c:      	je	0x27c <perf_unwind_perl+0x27c>
    1392:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    139c:      	movq	%rax, 0x26(%rsp)
    13a1:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    13ab:      	movq	%rax, 0x20(%rsp)
    13b0:      	movabsq	$0x5643565020612074, %rax # imm = 0x5643565020612074
    13ba:      	movq	%rax, 0x18(%rsp)
    13bf:      	movabsq	$0x6f6e207369205643, %rax # imm = 0x6F6E207369205643
    13c9:      	movq	%rax, 0x10(%rsp)
    13ce:      	leaq	0x10(%rsp), %rdi
    13d3:      	movl	$0x1e, %eax
    13d8:      	movl	$0x6, %ecx
    13dd:      	movl	0x5c(%rsp), %edx
    13e1:      	movl	$0x1e, %esi
    13e6:      	xorl	%eax, %eax
    13e8:      	callq	*%rcx
    13ea:      	jmp	0x27c <perf_unwind_perl+0x27c>
    13ef:      	cmpl	$0xc, %ecx
    13f2:      	je	0x13ff <perf_unwind_perl+0x13ff>
    13f4:      	cmpq	$0x0, (%r12)
    13f9:      	je	0x2907 <perf_unwind_perl+0x2907>
    13ff:      	movzbl	0x1d(%r14), %eax
    1404:      	subq	%rax, 0xf50(%r15)
    140b:      	movl	$0x10, 0x50(%rsp)
    1413:      	movq	(%rip), %rdi            # 0x141a <perf_unwind_perl+0x141a>
    141a:      	leaq	0x50(%rsp), %rsi
    141f:      	movl	$0x1, %eax
    1424:      	callq	*%rax
    1426:      	testq	%rax, %rax
    1429:      	je	0x1438 <perf_unwind_perl+0x1438>
    142b:      	incq	(%rax)
    142e:      	movq	0x98(%rsp), %rcx
    1436:      	jmp	0x1450 <perf_unwind_perl+0x1450>
    1438:      	movq	(%rip), %rax            # 0x143f <perf_unwind_perl+0x143f>
    143f:      	cmpl	$0x0, (%rax)
    1442:      	movq	0x98(%rsp), %rcx
    144a:      	jne	0x4203 <perf_unwind_perl+0x4203>
    1450:      	cmpl	$0x3, %ebp
    1453:      	jne	0x5636 <perf_unwind_perl+0x5636>
    1459:      	movq	0xf50(%r15), %r13
    1460:      	cmpq	%rcx, %r13
    1463:      	jb	0xcb <perf_unwind_perl+0xcb>
    1469:      	movzbl	0x19(%r14), %eax
    146e:      	addq	%r13, %rax
    1471:      	leaq	0xe(%rsp), %rdi
    1476:      	movl	$0x1, %ecx
    147b:      	movl	$0x70, %r8d
    1481:      	movzbl	0x19(%r14), %edx
    1486:      	addq	%r13, %rdx
    1489:      	movl	$0x1, %esi
    148e:      	callq	*%r8
    1491:      	testq	%rax, %rax
    1494:      	je	0x18b2 <perf_unwind_perl+0x18b2>
    149a:      	movq	(%rip), %rax            # 0x14a1 <perf_unwind_perl+0x14a1>
    14a1:      	cmpl	$0x0, (%rax)
    14a4:      	jne	0x47a3 <perf_unwind_perl+0x47a3>
    14aa:      	movl	$0x13, 0x50(%rsp)
    14b2:      	movq	(%rip), %rdi            # 0x14b9 <perf_unwind_perl+0x14b9>
    14b9:      	leaq	0x50(%rsp), %rsi
    14be:      	movl	$0x1, %eax
    14c3:      	callq	*%rax
    14c5:      	testq	%rax, %rax
    14c8:      	je	0x1a4e <perf_unwind_perl+0x1a4e>
    14ce:      	incq	(%rax)
    14d1:      	movl	$0x3, %ebp
    14d6:      	jmp	0x1ae2 <perf_unwind_perl+0x1ae2>
    14db:      	movabsq	$0xa29286c726570, %rax  # imm = 0xA29286C726570
    14e5:      	movq	%rax, 0x17(%rsp)
    14ea:      	movabsq	$0x705f646e69776e75, %rax # imm = 0x705F646E69776E75
    14f4:      	movq	%rax, 0x10(%rsp)
    14f9:      	leaq	0x10(%rsp), %rdi
    14fe:      	movl	$0xf, %eax
    1503:      	movl	$0x6, %ecx
    1508:      	movl	$0xf, %esi
    150d:      	xorl	%eax, %eax
    150f:      	callq	*%rcx
    1511:      	jmp	0x5b <perf_unwind_perl+0x5b>
    1516:      	movabsq	$0xa782578302072, %rax  # imm = 0xA782578302072
    1520:      	movq	%rax, 0x26(%rsp)
    1525:      	movabsq	$0x20726f66206b6361, %rax # imm = 0x20726F66206B6361
    152f:      	movq	%rax, 0x20(%rsp)
    1534:      	movabsq	$0x7473206c72655020, %rax # imm = 0x7473206C72655020
    153e:      	movq	%rax, 0x18(%rsp)
    1543:      	movabsq	$0x676e69646c697542, %rax # imm = 0x676E69646C697542
    154d:      	movq	%rax, 0x10(%rsp)
    1552:      	leaq	0x10(%rsp), %rdi
    1557:      	movl	$0x1e, %eax
    155c:      	movl	$0x6, %ecx
    1561:      	movl	0x8(%r14), %edx
    1565:      	movl	$0x1e, %esi
    156a:      	xorl	%eax, %eax
    156c:      	callq	*%rcx
    156e:      	jmp	0x85 <perf_unwind_perl+0x85>
    1573:      	movl	0x5c(%rsp), %eax
    1577:      	andl	$0x1f, %eax
    157a:      	cmpl	$0xd, %eax
    157d:      	jne	0x1a65 <perf_unwind_perl+0x1a65>
    1583:      	movzbl	0x1f(%r14), %eax
    1588:      	addq	%rbp, %rax
    158b:      	leaq	0x50(%rsp), %rdi
    1590:      	movl	$0x8, %ecx
    1595:      	movl	$0x70, %r8d
    159b:      	movzbl	0x1f(%r14), %edx
    15a0:      	addq	%rbp, %rdx
    15a3:      	movl	$0x8, %esi
    15a8:      	callq	*%r8
    15ab:      	testq	%rax, %rax
    15ae:      	jne	0x9ad <perf_unwind_perl+0x9ad>
    15b4:      	movzbl	0x21(%r14), %eax
    15b9:      	addq	0x50(%rsp), %rax
    15be:      	leaq	0x70(%rsp), %rdi
    15c3:      	movl	$0x4, %ecx
    15c8:      	movl	$0x70, %r8d
    15ce:      	movzbl	0x21(%r14), %edx
    15d3:      	addq	0x50(%rsp), %rdx
    15d8:      	movl	$0x4, %esi
    15dd:      	callq	*%r8
    15e0:      	testq	%rax, %rax
    15e3:      	jne	0x9ad <perf_unwind_perl+0x9ad>
    15e9:      	testb	$-0x80, 0x71(%rsp)
    15ee:      	jne	0x2bce <perf_unwind_perl+0x2bce>
    15f4:      	movzbl	0x22(%r14), %eax
    15f9:      	addq	0x50(%rsp), %rax
    15fe:      	leaq	0x60(%rsp), %rbp
    1603:      	movl	$0x8, %ecx
    1608:      	movl	$0x70, %r8d
    160e:      	movzbl	0x22(%r14), %edx
    1613:      	addq	0x50(%rsp), %rdx
    1618:      	movq	%rbp, %rdi
    161b:      	movl	$0x8, %esi
    1620:      	callq	*%r8
    1623:      	testq	%rax, %rax
    1626:      	jne	0x9ad <perf_unwind_perl+0x9ad>
    162c:      	movq	0x60(%rsp), %rax
    1631:      	testq	%rax, %rax
    1634:      	je	0x9ad <perf_unwind_perl+0x9ad>
    163a:      	movq	(%rip), %rcx            # 0x1641 <perf_unwind_perl+0x1641>
    1641:      	cmpl	$0x0, (%rcx)
    1644:      	jne	0x6e25 <perf_unwind_perl+0x6e25>
    164a:      	movzbl	0x1e(%r14), %ecx
    164f:      	addq	%rax, %rcx
    1652:      	leaq	0x6c(%rsp), %rdi
    1657:      	movl	$0x4, %eax
    165c:      	movl	$0x70, %r8d
    1662:      	movzbl	0x1e(%r14), %edx
    1667:      	addq	0x60(%rsp), %rdx
    166c:      	movl	$0x4, %esi
    1671:      	callq	*%r8
    1674:      	testq	%rax, %rax
    1677:      	jne	0x9ad <perf_unwind_perl+0x9ad>
    167d:      	movl	$0x801f, %eax           # imm = 0x801F
    1682:      	andl	0x6c(%rsp), %eax
    1686:      	cmpl	$0x8009, %eax           # imm = 0x8009
    168b:      	jne	0x3f41 <perf_unwind_perl+0x3f41>
    1691:      	movzbl	0x20(%r14), %eax
    1696:      	addq	0x60(%rsp), %rax
    169b:      	leaq	0x88(%rsp), %rdi
    16a3:      	movl	$0x8, %ecx
    16a8:      	movl	$0x70, %r8d
    16ae:      	movzbl	0x20(%r14), %edx
    16b3:      	addq	0x60(%rsp), %rdx
    16b8:      	movl	$0x8, %esi
    16bd:      	callq	*%r8
    16c0:      	testq	%rax, %rax
    16c3:      	jne	0x9ad <perf_unwind_perl+0x9ad>
    16c9:      	movzbl	0x23(%r14), %eax
    16ce:      	addq	0x88(%rsp), %rax
    16d6:      	leaq	0x78(%rsp), %rdi
    16db:      	movl	$0x8, %ecx
    16e0:      	movl	$0x70, %r8d
    16e6:      	movzbl	0x23(%r14), %edx
    16eb:      	addq	0x88(%rsp), %rdx
    16f3:      	movl	$0x8, %esi
    16f8:      	callq	*%r8
    16fb:      	testq	%rax, %rax
    16fe:      	jne	0x9ad <perf_unwind_perl+0x9ad>
    1704:      	movq	0x78(%rsp), %rax
    1709:      	movq	%rax, 0x80(%rsp)
    1711:      	testq	%rax, %rax
    1714:      	je	0x176a <perf_unwind_perl+0x176a>
    1716:      	movq	(%rip), %rax            # 0x171d <perf_unwind_perl+0x171d>
    171d:      	cmpl	$0x0, (%rax)
    1720:      	je	0x177f <perf_unwind_perl+0x177f>
    1722:      	movabsq	$0x2578302074612056, %rax # imm = 0x2578302074612056
    172c:      	movq	%rax, 0x18(%rsp)
    1731:      	movabsq	$0x474520646e756f46, %rax # imm = 0x474520646E756F46
    173b:      	movq	%rax, 0x10(%rsp)
    1740:      	movl	$0xa786c, 0x20(%rsp)    # imm = 0xA786C
    1748:      	leaq	0x10(%rsp), %rdi
    174d:      	movl	$0x14, %eax
    1752:      	movl	$0x6, %ecx
    1757:      	movq	0x78(%rsp), %rdx
    175c:      	movl	$0x14, %esi
    1761:      	xorl	%eax, %eax
    1763:      	callq	*%rcx
    1765:      	leaq	0x78(%rsp), %rbp
    176a:      	movq	(%rbp), %rax
    176e:      	movq	%rax, 0x80(%rsp)
    1776:      	testq	%rax, %rax
    1779:      	je	0x568 <perf_unwind_perl+0x568>
    177f:      	movq	(%r12), %rax
    1783:      	movq	%rax, 0x90(%rsp)
    178b:      	movq	(%rip), %rax            # 0x1792 <perf_unwind_perl+0x1792>
    1792:      	cmpl	$0x0, (%rax)
    1795:      	jne	0x834a <perf_unwind_perl+0x834a>
    179b:      	movl	0x2c0(%r15), %eax
    17a2:      	cmpq	$0x7e, %rax
    17a6:      	ja	0x1193 <perf_unwind_perl+0x1193>
    17ac:      	xorl	%ecx, %ecx
    17ae:      	movzbl	0xf(%rsp), %edx
    17b3:      	movb	%dl, %cl
    17b5:      	leal	0x1(,%rcx,2), %ebp
    17bc:      	leal	0x1(%rax), %ecx
    17bf:      	movl	%ecx, 0x2c0(%r15)
    17c6:      	leaq	(%rax,%rax,2), %rax
    17ca:      	movq	0x80(%rsp), %rcx
    17d2:      	movq	%rcx, 0x2d0(%r15,%rax,8)
    17da:      	movq	0x90(%rsp), %rcx
    17e2:      	movq	%rcx, 0x2d8(%r15,%rax,8)
    17ea:      	movb	$0x7, 0x2e0(%r15,%rax,8)
    17f3:      	movl	$0x0, 0x2e1(%r15,%rax,8)
    17ff:      	movl	$0x0, 0x2e4(%r15,%rax,8)
    180b:      	movq	$0x0, 0xf40(%r15)
    1816:      	movzbl	0x1a(%r14), %eax
    181b:      	addq	%r13, %rax
    181e:      	movl	$0x8, %ecx
    1823:      	movl	$0x70, %r8d
    1829:      	movzbl	0x1a(%r14), %edx
    182e:      	addq	%r13, %rdx
    1831:      	movq	%r12, %rdi
    1834:      	movl	$0x8, %esi
    1839:      	callq	*%r8
    183c:      	testq	%rax, %rax
    183f:      	jne	0x568 <perf_unwind_perl+0x568>
    1845:      	movq	(%rip), %rax            # 0x184c <perf_unwind_perl+0x184c>
    184c:      	cmpl	$0x0, (%rax)
    184f:      	je	0xacd <perf_unwind_perl+0xacd>
    1855:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    185f:      	movq	%rax, 0x26(%rsp)
    1864:      	movabsq	$0x30206b6361747320, %rax # imm = 0x30206B6361747320
    186e:      	movq	%rax, 0x20(%rsp)
    1873:      	movabsq	$0x747865746e6f6320, %rax # imm = 0x747865746E6F6320
    187d:      	movq	%rax, 0x18(%rsp)
    1882:      	movabsq	$0x6d6f726620504f43, %rax # imm = 0x6D6F726620504F43
    188c:      	movq	%rax, 0x10(%rsp)
    1891:      	leaq	0x10(%rsp), %rdi
    1896:      	movl	$0x1e, %eax
    189b:      	movl	$0x6, %ecx
    18a0:      	movq	(%r12), %rdx
    18a4:      	movl	$0x1e, %esi
    18a9:      	xorl	%eax, %eax
    18ab:      	callq	*%rcx
    18ad:      	jmp	0xacd <perf_unwind_perl+0xacd>
    18b2:      	movq	(%rip), %rax            # 0x18b9 <perf_unwind_perl+0x18b9>
    18b9:      	cmpl	$0x0, (%rax)
    18bc:      	jne	0x4b35 <perf_unwind_perl+0x4b35>
    18c2:      	movzbl	0xe(%rsp), %eax
    18c7:      	movl	%eax, %ecx
    18c9:      	andl	$0xf, %ecx
    18cc:      	movl	$0x3, %ebp
    18d1:      	leal	-0x9(%rcx), %edx
    18d4:      	cmpl	$0x2, %edx
    18d7:      	jae	0x1ad2 <perf_unwind_perl+0x1ad2>
    18dd:      	testb	%al, %al
    18df:      	js	0x1ae2 <perf_unwind_perl+0x1ae2>
    18e5:      	movzbl	0x1b(%r14), %eax
    18ea:      	addq	%r13, %rax
    18ed:      	leaq	0x10(%rsp), %rdi
    18f2:      	movl	$0x8, %ecx
    18f7:      	movl	$0x70, %r8d
    18fd:      	movzbl	0x1b(%r14), %edx
    1902:      	addq	%r13, %rdx
    1905:      	movl	$0x8, %esi
    190a:      	callq	*%r8
    190d:      	testq	%rax, %rax
    1910:      	jne	0x149a <perf_unwind_perl+0x149a>
    1916:      	cmpq	$0x0, 0x10(%rsp)
    191c:      	setne	0xf(%rsp)
    1921:      	movzbl	0x1c(%r14), %eax
    1926:      	addq	%r13, %rax
    1929:      	leaq	0xa0(%rsp), %rdi
    1931:      	movl	$0x8, %ecx
    1936:      	movl	$0x70, %r8d
    193c:      	movzbl	0x1c(%r14), %edx
    1941:      	addq	%r13, %rdx
    1944:      	movl	$0x8, %esi
    1949:      	callq	*%r8
    194c:      	testq	%rax, %rax
    194f:      	jne	0x149a <perf_unwind_perl+0x149a>
    1955:      	movq	0xa0(%rsp), %rbp
    195d:      	movzbl	0x1e(%r14), %eax
    1962:      	addq	%rbp, %rax
    1965:      	leaq	0x5c(%rsp), %rdi
    196a:      	movl	$0x4, %ecx
    196f:      	movl	$0x70, %r8d
    1975:      	movzbl	0x1e(%r14), %edx
    197a:      	addq	%rbp, %rdx
    197d:      	movl	$0x4, %esi
    1982:      	callq	*%r8
    1985:      	testq	%rax, %rax
    1988:      	je	0x3084 <perf_unwind_perl+0x3084>
    198e:      	movq	(%rip), %rax            # 0x1995 <perf_unwind_perl+0x1995>
    1995:      	cmpl	$0x0, (%rax)
    1998:      	jne	0x68fe <perf_unwind_perl+0x68fe>
    199e:      	movl	$0x14, 0x74(%rsp)
    19a6:      	movq	(%rip), %rdi            # 0x19ad <perf_unwind_perl+0x19ad>
    19ad:      	leaq	0x74(%rsp), %rsi
    19b2:      	movl	$0x1, %eax
    19b7:      	callq	*%rax
    19b9:      	testq	%rax, %rax
    19bc:      	je	0x35c5 <perf_unwind_perl+0x35c5>
    19c2:      	incq	(%rax)
    19c5:      	jmp	0x149a <perf_unwind_perl+0x149a>
    19ca:      	movq	(%rip), %rax            # 0x19d1 <perf_unwind_perl+0x19d1>
    19d1:      	cmpl	$0x0, (%rax)
    19d4:      	je	0x568 <perf_unwind_perl+0x568>
    19da:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    19e4:      	movq	%rax, 0x36(%rsp)
    19e9:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    19f3:      	movq	%rax, 0x30(%rsp)
    19f8:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1a02:      	movq	%rax, 0x28(%rsp)
    1a07:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1a11:      	movq	%rax, 0x20(%rsp)
    1a16:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1a20:      	movq	%rax, 0x18(%rsp)
    1a25:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1a2f:      	movq	%rax, 0x10(%rsp)
    1a34:      	leaq	0x10(%rsp), %rdi
    1a39:      	movl	$0x2e, %eax
    1a3e:      	movl	$0x6, %ecx
    1a43:      	movl	0x74(%rsp), %edx
    1a47:      	movl	$0x2e, %esi
    1a4c:      	jmp	0x1ac9 <perf_unwind_perl+0x1ac9>
    1a4e:      	movq	(%rip), %rax            # 0x1a55 <perf_unwind_perl+0x1a55>
    1a55:      	cmpl	$0x0, (%rax)
    1a58:      	jne	0x4d20 <perf_unwind_perl+0x4d20>
    1a5e:      	movl	$0x3, %ebp
    1a63:      	jmp	0x1ae2 <perf_unwind_perl+0x1ae2>
    1a65:      	movq	(%rip), %rax            # 0x1a6c <perf_unwind_perl+0x1a6c>
    1a6c:      	cmpl	$0x0, (%rax)
    1a6f:      	je	0x568 <perf_unwind_perl+0x568>
    1a75:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    1a7f:      	movq	%rax, 0x26(%rsp)
    1a84:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    1a8e:      	movq	%rax, 0x20(%rsp)
    1a93:      	movabsq	$0x5643565020612074, %rax # imm = 0x5643565020612074
    1a9d:      	movq	%rax, 0x18(%rsp)
    1aa2:      	movabsq	$0x6f6e207369205643, %rax # imm = 0x6F6E207369205643
    1aac:      	movq	%rax, 0x10(%rsp)
    1ab1:      	leaq	0x10(%rsp), %rdi
    1ab6:      	movl	$0x1e, %eax
    1abb:      	movl	$0x6, %ecx
    1ac0:      	movl	0x5c(%rsp), %edx
    1ac4:      	movl	$0x1e, %esi
    1ac9:      	xorl	%eax, %eax
    1acb:      	callq	*%rcx
    1acd:      	jmp	0x568 <perf_unwind_perl+0x568>
    1ad2:      	cmpl	$0xc, %ecx
    1ad5:      	je	0x1ae2 <perf_unwind_perl+0x1ae2>
    1ad7:      	cmpq	$0x0, (%r12)
    1adc:      	je	0x3327 <perf_unwind_perl+0x3327>
    1ae2:      	movzbl	0x1d(%r14), %eax
    1ae7:      	subq	%rax, 0xf50(%r15)
    1aee:      	movl	$0x10, 0x50(%rsp)
    1af6:      	movq	(%rip), %rdi            # 0x1afd <perf_unwind_perl+0x1afd>
    1afd:      	leaq	0x50(%rsp), %rsi
    1b02:      	movl	$0x1, %eax
    1b07:      	callq	*%rax
    1b09:      	testq	%rax, %rax
    1b0c:      	je	0x1b1b <perf_unwind_perl+0x1b1b>
    1b0e:      	incq	(%rax)
    1b11:      	movq	0x98(%rsp), %rcx
    1b19:      	jmp	0x1b33 <perf_unwind_perl+0x1b33>
    1b1b:      	movq	(%rip), %rax            # 0x1b22 <perf_unwind_perl+0x1b22>
    1b22:      	cmpl	$0x0, (%rax)
    1b25:      	movq	0x98(%rsp), %rcx
    1b2d:      	jne	0x4b7c <perf_unwind_perl+0x4b7c>
    1b33:      	cmpl	$0x3, %ebp
    1b36:      	jne	0x5636 <perf_unwind_perl+0x5636>
    1b3c:      	movq	0xf50(%r15), %r13
    1b43:      	cmpq	%rcx, %r13
    1b46:      	jb	0xcb <perf_unwind_perl+0xcb>
    1b4c:      	movzbl	0x19(%r14), %eax
    1b51:      	addq	%r13, %rax
    1b54:      	leaq	0xe(%rsp), %rdi
    1b59:      	movl	$0x1, %ecx
    1b5e:      	movl	$0x70, %r8d
    1b64:      	movzbl	0x19(%r14), %edx
    1b69:      	addq	%r13, %rdx
    1b6c:      	movl	$0x1, %esi
    1b71:      	callq	*%r8
    1b74:      	testq	%rax, %rax
    1b77:      	je	0x1f6f <perf_unwind_perl+0x1f6f>
    1b7d:      	movq	(%rip), %rax            # 0x1b84 <perf_unwind_perl+0x1b84>
    1b84:      	cmpl	$0x0, (%rax)
    1b87:      	jne	0x5151 <perf_unwind_perl+0x5151>
    1b8d:      	movl	$0x13, 0x50(%rsp)
    1b95:      	movq	(%rip), %rdi            # 0x1b9c <perf_unwind_perl+0x1b9c>
    1b9c:      	leaq	0x50(%rsp), %rsi
    1ba1:      	movl	$0x1, %eax
    1ba6:      	callq	*%rax
    1ba8:      	testq	%rax, %rax
    1bab:      	je	0x210e <perf_unwind_perl+0x210e>
    1bb1:      	incq	(%rax)
    1bb4:      	movl	$0x3, %ebp
    1bb9:      	jmp	0x2477 <perf_unwind_perl+0x2477>
    1bbe:      	movl	0x5c(%rsp), %eax
    1bc2:      	andl	$0x1f, %eax
    1bc5:      	cmpl	$0xd, %eax
    1bc8:      	jne	0x2338 <perf_unwind_perl+0x2338>
    1bce:      	movzbl	0x1f(%r14), %eax
    1bd3:      	addq	%rbp, %rax
    1bd6:      	leaq	0x50(%rsp), %rdi
    1bdb:      	movl	$0x8, %ecx
    1be0:      	movl	$0x70, %r8d
    1be6:      	movzbl	0x1f(%r14), %edx
    1beb:      	addq	%rbp, %rdx
    1bee:      	movl	$0x8, %esi
    1bf3:      	callq	*%r8
    1bf6:      	testq	%rax, %rax
    1bf9:      	jne	0xd3e <perf_unwind_perl+0xd3e>
    1bff:      	movzbl	0x21(%r14), %eax
    1c04:      	addq	0x50(%rsp), %rax
    1c09:      	leaq	0x70(%rsp), %rdi
    1c0e:      	movl	$0x4, %ecx
    1c13:      	movl	$0x70, %r8d
    1c19:      	movzbl	0x21(%r14), %edx
    1c1e:      	addq	0x50(%rsp), %rdx
    1c23:      	movl	$0x4, %esi
    1c28:      	callq	*%r8
    1c2b:      	testq	%rax, %rax
    1c2e:      	jne	0xd3e <perf_unwind_perl+0xd3e>
    1c34:      	testb	$-0x80, 0x71(%rsp)
    1c39:      	jne	0x36e1 <perf_unwind_perl+0x36e1>
    1c3f:      	movzbl	0x22(%r14), %eax
    1c44:      	addq	0x50(%rsp), %rax
    1c49:      	leaq	0x60(%rsp), %rbp
    1c4e:      	movl	$0x8, %ecx
    1c53:      	movl	$0x70, %r8d
    1c59:      	movzbl	0x22(%r14), %edx
    1c5e:      	addq	0x50(%rsp), %rdx
    1c63:      	movq	%rbp, %rdi
    1c66:      	movl	$0x8, %esi
    1c6b:      	callq	*%r8
    1c6e:      	testq	%rax, %rax
    1c71:      	jne	0xd3e <perf_unwind_perl+0xd3e>
    1c77:      	movq	0x60(%rsp), %rax
    1c7c:      	testq	%rax, %rax
    1c7f:      	je	0xd3e <perf_unwind_perl+0xd3e>
    1c85:      	movq	(%rip), %rcx            # 0x1c8c <perf_unwind_perl+0x1c8c>
    1c8c:      	cmpl	$0x0, (%rcx)
    1c8f:      	jne	0x75d6 <perf_unwind_perl+0x75d6>
    1c95:      	movzbl	0x1e(%r14), %ecx
    1c9a:      	addq	%rax, %rcx
    1c9d:      	leaq	0x6c(%rsp), %rdi
    1ca2:      	movl	$0x4, %eax
    1ca7:      	movl	$0x70, %r8d
    1cad:      	movzbl	0x1e(%r14), %edx
    1cb2:      	addq	0x60(%rsp), %rdx
    1cb7:      	movl	$0x4, %esi
    1cbc:      	callq	*%r8
    1cbf:      	testq	%rax, %rax
    1cc2:      	jne	0xd3e <perf_unwind_perl+0xd3e>
    1cc8:      	movl	$0x801f, %eax           # imm = 0x801F
    1ccd:      	andl	0x6c(%rsp), %eax
    1cd1:      	cmpl	$0x8009, %eax           # imm = 0x8009
    1cd6:      	jne	0x492d <perf_unwind_perl+0x492d>
    1cdc:      	movzbl	0x20(%r14), %eax
    1ce1:      	addq	0x60(%rsp), %rax
    1ce6:      	leaq	0x88(%rsp), %rdi
    1cee:      	movl	$0x8, %ecx
    1cf3:      	movl	$0x70, %r8d
    1cf9:      	movzbl	0x20(%r14), %edx
    1cfe:      	addq	0x60(%rsp), %rdx
    1d03:      	movl	$0x8, %esi
    1d08:      	callq	*%r8
    1d0b:      	testq	%rax, %rax
    1d0e:      	jne	0xd3e <perf_unwind_perl+0xd3e>
    1d14:      	movzbl	0x23(%r14), %eax
    1d19:      	addq	0x88(%rsp), %rax
    1d21:      	leaq	0x78(%rsp), %rdi
    1d26:      	movl	$0x8, %ecx
    1d2b:      	movl	$0x70, %r8d
    1d31:      	movzbl	0x23(%r14), %edx
    1d36:      	addq	0x88(%rsp), %rdx
    1d3e:      	movl	$0x8, %esi
    1d43:      	callq	*%r8
    1d46:      	testq	%rax, %rax
    1d49:      	jne	0xd3e <perf_unwind_perl+0xd3e>
    1d4f:      	movq	0x78(%rsp), %rax
    1d54:      	movq	%rax, 0x80(%rsp)
    1d5c:      	testq	%rax, %rax
    1d5f:      	je	0x1db5 <perf_unwind_perl+0x1db5>
    1d61:      	movq	(%rip), %rax            # 0x1d68 <perf_unwind_perl+0x1d68>
    1d68:      	cmpl	$0x0, (%rax)
    1d6b:      	je	0x1dca <perf_unwind_perl+0x1dca>
    1d6d:      	movabsq	$0x2578302074612056, %rax # imm = 0x2578302074612056
    1d77:      	movq	%rax, 0x18(%rsp)
    1d7c:      	movabsq	$0x474520646e756f46, %rax # imm = 0x474520646E756F46
    1d86:      	movq	%rax, 0x10(%rsp)
    1d8b:      	movl	$0xa786c, 0x20(%rsp)    # imm = 0xA786C
    1d93:      	leaq	0x10(%rsp), %rdi
    1d98:      	movl	$0x14, %eax
    1d9d:      	movl	$0x6, %ecx
    1da2:      	movq	0x78(%rsp), %rdx
    1da7:      	movl	$0x14, %esi
    1dac:      	xorl	%eax, %eax
    1dae:      	callq	*%rcx
    1db0:      	leaq	0x78(%rsp), %rbp
    1db5:      	movq	(%rbp), %rax
    1db9:      	movq	%rax, 0x80(%rsp)
    1dc1:      	testq	%rax, %rax
    1dc4:      	je	0xb68 <perf_unwind_perl+0xb68>
    1dca:      	movq	(%r12), %rax
    1dce:      	movq	%rax, 0x90(%rsp)
    1dd6:      	movq	(%rip), %rax            # 0x1ddd <perf_unwind_perl+0x1ddd>
    1ddd:      	cmpl	$0x0, (%rax)
    1de0:      	jne	0x8753 <perf_unwind_perl+0x8753>
    1de6:      	movl	0x2c0(%r15), %eax
    1ded:      	cmpq	$0x7e, %rax
    1df1:      	ja	0x1193 <perf_unwind_perl+0x1193>
    1df7:      	xorl	%ecx, %ecx
    1df9:      	movzbl	0xf(%rsp), %edx
    1dfe:      	movb	%dl, %cl
    1e00:      	leal	0x1(,%rcx,2), %ebp
    1e07:      	leal	0x1(%rax), %ecx
    1e0a:      	movl	%ecx, 0x2c0(%r15)
    1e11:      	leaq	(%rax,%rax,2), %rax
    1e15:      	movq	0x80(%rsp), %rcx
    1e1d:      	movq	%rcx, 0x2d0(%r15,%rax,8)
    1e25:      	movq	0x90(%rsp), %rcx
    1e2d:      	movq	%rcx, 0x2d8(%r15,%rax,8)
    1e35:      	movb	$0x7, 0x2e0(%r15,%rax,8)
    1e3e:      	movl	$0x0, 0x2e1(%r15,%rax,8)
    1e4a:      	movl	$0x0, 0x2e4(%r15,%rax,8)
    1e56:      	movq	$0x0, 0xf40(%r15)
    1e61:      	movzbl	0x1a(%r14), %eax
    1e66:      	addq	%r13, %rax
    1e69:      	movl	$0x8, %ecx
    1e6e:      	movl	$0x70, %r8d
    1e74:      	movzbl	0x1a(%r14), %edx
    1e79:      	addq	%r13, %rdx
    1e7c:      	movq	%r12, %rdi
    1e7f:      	movl	$0x8, %esi
    1e84:      	callq	*%r8
    1e87:      	testq	%rax, %rax
    1e8a:      	jne	0xb68 <perf_unwind_perl+0xb68>
    1e90:      	movq	(%rip), %rax            # 0x1e97 <perf_unwind_perl+0x1e97>
    1e97:      	cmpl	$0x0, (%rax)
    1e9a:      	je	0xe2c <perf_unwind_perl+0xe2c>
    1ea0:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    1eaa:      	movq	%rax, 0x26(%rsp)
    1eaf:      	movabsq	$0x30206b6361747320, %rax # imm = 0x30206B6361747320
    1eb9:      	movq	%rax, 0x20(%rsp)
    1ebe:      	movabsq	$0x747865746e6f6320, %rax # imm = 0x747865746E6F6320
    1ec8:      	movq	%rax, 0x18(%rsp)
    1ecd:      	movabsq	$0x6d6f726620504f43, %rax # imm = 0x6D6F726620504F43
    1ed7:      	movq	%rax, 0x10(%rsp)
    1edc:      	leaq	0x10(%rsp), %rdi
    1ee1:      	movl	$0x1e, %eax
    1ee6:      	movl	$0x6, %ecx
    1eeb:      	movq	(%r12), %rdx
    1eef:      	movl	$0x1e, %esi
    1ef4:      	xorl	%eax, %eax
    1ef6:      	callq	*%rcx
    1ef8:      	jmp	0xe2c <perf_unwind_perl+0xe2c>
    1efd:      	movabsq	$0x7025207461207972, %rax # imm = 0x7025207461207972
    1f07:      	movq	%rax, 0x30(%rsp)
    1f0c:      	movabsq	$0x746e65206b636174, %rax # imm = 0x746E65206B636174
    1f16:      	movq	%rax, 0x28(%rsp)
    1f1b:      	movabsq	$0x7320747865746e6f, %rax # imm = 0x7320747865746E6F
    1f25:      	movq	%rax, 0x20(%rsp)
    1f2a:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    1f34:      	movq	%rax, 0x18(%rsp)
    1f39:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1f43:      	movq	%rax, 0x10(%rsp)
    1f48:      	movw	$0xa, 0x38(%rsp)
    1f4f:      	leaq	0x10(%rsp), %rdi
    1f54:      	movl	$0x2a, %eax
    1f59:      	movl	$0x6, %ecx
    1f5e:      	movl	$0x2a, %esi
    1f63:      	movq	%r13, %rdx
    1f66:      	xorl	%eax, %eax
    1f68:      	callq	*%rcx
    1f6a:      	jmp	0x28c <perf_unwind_perl+0x28c>
    1f6f:      	movq	(%rip), %rax            # 0x1f76 <perf_unwind_perl+0x1f76>
    1f76:      	cmpl	$0x0, (%rax)
    1f79:      	jne	0x54e3 <perf_unwind_perl+0x54e3>
    1f7f:      	movzbl	0xe(%rsp), %eax
    1f84:      	movl	%eax, %ecx
    1f86:      	andl	$0xf, %ecx
    1f89:      	movl	$0x3, %ebp
    1f8e:      	leal	-0x9(%rcx), %edx
    1f91:      	cmpl	$0x2, %edx
    1f94:      	jae	0x2467 <perf_unwind_perl+0x2467>
    1f9a:      	testb	%al, %al
    1f9c:      	js	0x2477 <perf_unwind_perl+0x2477>
    1fa2:      	movzbl	0x1b(%r14), %eax
    1fa7:      	addq	%r13, %rax
    1faa:      	leaq	0x10(%rsp), %rdi
    1faf:      	movl	$0x8, %ecx
    1fb4:      	movl	$0x70, %r8d
    1fba:      	movzbl	0x1b(%r14), %edx
    1fbf:      	addq	%r13, %rdx
    1fc2:      	movl	$0x8, %esi
    1fc7:      	callq	*%r8
    1fca:      	testq	%rax, %rax
    1fcd:      	jne	0x1b7d <perf_unwind_perl+0x1b7d>
    1fd3:      	cmpq	$0x0, 0x10(%rsp)
    1fd9:      	setne	0xf(%rsp)
    1fde:      	movzbl	0x1c(%r14), %eax
    1fe3:      	addq	%r13, %rax
    1fe6:      	leaq	0xa0(%rsp), %rdi
    1fee:      	movl	$0x8, %ecx
    1ff3:      	movl	$0x70, %r8d
    1ff9:      	movzbl	0x1c(%r14), %edx
    1ffe:      	addq	%r13, %rdx
    2001:      	movl	$0x8, %esi
    2006:      	callq	*%r8
    2009:      	testq	%rax, %rax
    200c:      	jne	0x1b7d <perf_unwind_perl+0x1b7d>
    2012:      	movq	0xa0(%rsp), %rbp
    201a:      	movzbl	0x1e(%r14), %eax
    201f:      	addq	%rbp, %rax
    2022:      	leaq	0x5c(%rsp), %rdi
    2027:      	movl	$0x4, %ecx
    202c:      	movl	$0x70, %r8d
    2032:      	movzbl	0x1e(%r14), %edx
    2037:      	addq	%rbp, %rdx
    203a:      	movl	$0x4, %esi
    203f:      	callq	*%r8
    2042:      	testq	%rax, %rax
    2045:      	je	0x3a78 <perf_unwind_perl+0x3a78>
    204b:      	movq	(%rip), %rax            # 0x2052 <perf_unwind_perl+0x2052>
    2052:      	cmpl	$0x0, (%rax)
    2055:      	jne	0x70af <perf_unwind_perl+0x70af>
    205b:      	movl	$0x14, 0x74(%rsp)
    2063:      	movq	(%rip), %rdi            # 0x206a <perf_unwind_perl+0x206a>
    206a:      	leaq	0x74(%rsp), %rsi
    206f:      	movl	$0x1, %eax
    2074:      	callq	*%rax
    2076:      	testq	%rax, %rax
    2079:      	je	0x3fb9 <perf_unwind_perl+0x3fb9>
    207f:      	incq	(%rax)
    2082:      	jmp	0x1b7d <perf_unwind_perl+0x1b7d>
    2087:      	movq	(%rip), %rax            # 0x208e <perf_unwind_perl+0x208e>
    208e:      	cmpl	$0x0, (%rax)
    2091:      	je	0xb68 <perf_unwind_perl+0xb68>
    2097:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    20a1:      	movq	%rax, 0x36(%rsp)
    20a6:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    20b0:      	movq	%rax, 0x30(%rsp)
    20b5:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    20bf:      	movq	%rax, 0x28(%rsp)
    20c4:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    20ce:      	movq	%rax, 0x20(%rsp)
    20d3:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    20dd:      	movq	%rax, 0x18(%rsp)
    20e2:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    20ec:      	movq	%rax, 0x10(%rsp)
    20f1:      	leaq	0x10(%rsp), %rdi
    20f6:      	movl	$0x2e, %eax
    20fb:      	movl	$0x6, %ecx
    2100:      	movl	0x74(%rsp), %edx
    2104:      	movl	$0x2e, %esi
    2109:      	jmp	0x239c <perf_unwind_perl+0x239c>
    210e:      	movq	(%rip), %rax            # 0x2115 <perf_unwind_perl+0x2115>
    2115:      	cmpl	$0x0, (%rax)
    2118:      	jne	0x5ed1 <perf_unwind_perl+0x5ed1>
    211e:      	movl	$0x3, %ebp
    2123:      	jmp	0x2477 <perf_unwind_perl+0x2477>
    2128:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    2132:      	movq	%rax, 0x1f(%rsp)
    2137:      	movabsq	$0x2072657465727072, %rax # imm = 0x2072657465727072
    2141:      	movq	%rax, 0x18(%rsp)
    2146:      	movabsq	$0x65746e496c726550, %rax # imm = 0x65746E496C726550
    2150:      	movq	%rax, 0x10(%rsp)
    2155:      	leaq	0x10(%rsp), %rdi
    215a:      	movl	$0x17, %eax
    215f:      	movl	$0x6, %ecx
    2164:      	movq	0x60(%rsp), %rdx
    2169:      	movl	$0x17, %esi
    216e:      	xorl	%eax, %eax
    2170:      	callq	*%rcx
    2172:      	jmp	0x196 <perf_unwind_perl+0x196>
    2177:      	movabsq	$0xa65756c617620, %rax  # imm = 0xA65756C617620
    2181:      	movq	%rax, 0x25(%rsp)
    2186:      	movabsq	$0x6176206573616270, %rax # imm = 0x6176206573616270
    2190:      	movq	%rax, 0x20(%rsp)
    2195:      	movabsq	$0x742064616572206f, %rax # imm = 0x742064616572206F
    219f:      	movq	%rax, 0x18(%rsp)
    21a4:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    21ae:      	movq	%rax, 0x10(%rsp)
    21b3:      	leaq	0x10(%rsp), %rdi
    21b8:      	movl	$0x1d, %eax
    21bd:      	movl	$0x6, %ecx
    21c2:      	movl	$0x1d, %esi
    21c7:      	xorl	%eax, %eax
    21c9:      	callq	*%rcx
    21cb:      	jmp	0x311 <perf_unwind_perl+0x311>
    21d0:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    21da:      	movq	%rax, 0x36(%rsp)
    21df:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    21e9:      	movq	%rax, 0x30(%rsp)
    21ee:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    21f8:      	movq	%rax, 0x28(%rsp)
    21fd:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2207:      	movq	%rax, 0x20(%rsp)
    220c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2216:      	movq	%rax, 0x18(%rsp)
    221b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2225:      	movq	%rax, 0x10(%rsp)
    222a:      	leaq	0x10(%rsp), %rdi
    222f:      	movl	$0x2e, %eax
    2234:      	movl	$0x6, %ecx
    2239:      	movl	0x50(%rsp), %edx
    223d:      	movl	$0x2e, %esi
    2242:      	xorl	%eax, %eax
    2244:      	callq	*%rcx
    2246:      	cmpb	$0x0, 0x14(%r14)
    224b:      	jne	0x2ce <perf_unwind_perl+0x2ce>
    2251:      	jmp	0x180 <perf_unwind_perl+0x180>
    2256:      	movq	(%rip), %rax            # 0x225d <perf_unwind_perl+0x225d>
    225d:      	cmpl	$0x0, (%rax)
    2260:      	je	0x27c <perf_unwind_perl+0x27c>
    2266:      	movabsq	$0xa782578302f78, %rax  # imm = 0xA782578302F78
    2270:      	movq	%rax, 0x2e(%rsp)
    2275:      	movabsq	$0x2f78257830207367, %rax # imm = 0x2F78257830207367
    227f:      	movq	%rax, 0x28(%rsp)
    2284:      	movabsq	$0x616c66202c564320, %rax # imm = 0x616C66202C564320
    228e:      	movq	%rax, 0x20(%rsp)
    2293:      	movabsq	$0x44454d414e206465, %rax # imm = 0x44454D414E206465
    229d:      	movq	%rax, 0x18(%rsp)
    22a2:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    22ac:      	movq	%rax, 0x10(%rsp)
    22b1:      	leaq	0x10(%rsp), %rdi
    22b6:      	movl	$0x26, %eax
    22bb:      	movl	$0x6, %r8d
    22c1:      	movl	0x5c(%rsp), %edx
    22c5:      	movl	0x70(%rsp), %ecx
    22c9:      	movl	$0x26, %esi
    22ce:      	xorl	%eax, %eax
    22d0:      	callq	*%r8
    22d3:      	jmp	0x27c <perf_unwind_perl+0x27c>
    22d8:      	movabsq	$0x6574617473207265, %rax # imm = 0x6574617473207265
    22e2:      	movq	%rax, 0x28(%rsp)
    22e7:      	movabsq	$0x746572707265746e, %rax # imm = 0x746572707265746E
    22f1:      	movq	%rax, 0x20(%rsp)
    22f6:      	movabsq	$0x692064616572206f, %rax # imm = 0x692064616572206F
    2300:      	movq	%rax, 0x18(%rsp)
    2305:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    230f:      	movq	%rax, 0x10(%rsp)
    2314:      	movw	$0xa, 0x30(%rsp)
    231b:      	leaq	0x10(%rsp), %rdi
    2320:      	movl	$0x22, %eax
    2325:      	movl	$0x6, %ecx
    232a:      	movl	$0x22, %esi
    232f:      	xorl	%eax, %eax
    2331:      	callq	*%rcx
    2333:      	jmp	0x212 <perf_unwind_perl+0x212>
    2338:      	movq	(%rip), %rax            # 0x233f <perf_unwind_perl+0x233f>
    233f:      	cmpl	$0x0, (%rax)
    2342:      	je	0xb68 <perf_unwind_perl+0xb68>
    2348:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    2352:      	movq	%rax, 0x26(%rsp)
    2357:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    2361:      	movq	%rax, 0x20(%rsp)
    2366:      	movabsq	$0x5643565020612074, %rax # imm = 0x5643565020612074
    2370:      	movq	%rax, 0x18(%rsp)
    2375:      	movabsq	$0x6f6e207369205643, %rax # imm = 0x6F6E207369205643
    237f:      	movq	%rax, 0x10(%rsp)
    2384:      	leaq	0x10(%rsp), %rdi
    2389:      	movl	$0x1e, %eax
    238e:      	movl	$0x6, %ecx
    2393:      	movl	0x5c(%rsp), %edx
    2397:      	movl	$0x1e, %esi
    239c:      	xorl	%eax, %eax
    239e:      	callq	*%rcx
    23a0:      	jmp	0xb68 <perf_unwind_perl+0xb68>
    23a5:      	movabsq	$0x7825783020786320, %rax # imm = 0x7825783020786320
    23af:      	movq	%rax, 0x18(%rsp)
    23b4:      	movabsq	$0x6c72657020746f47, %rax # imm = 0x6C72657020746F47
    23be:      	movq	%rax, 0x10(%rsp)
    23c3:      	movw	$0xa, 0x20(%rsp)
    23ca:      	leaq	0x10(%rsp), %rdi
    23cf:      	movl	$0x12, %eax
    23d4:      	movl	$0x6, %ecx
    23d9:      	movzbl	0xe(%rsp), %edx
    23de:      	movl	$0x12, %esi
    23e3:      	xorl	%eax, %eax
    23e5:      	callq	*%rcx
    23e7:      	jmp	0x3ac <perf_unwind_perl+0x3ac>
    23ec:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    23f6:      	movq	%rax, 0x36(%rsp)
    23fb:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2405:      	movq	%rax, 0x30(%rsp)
    240a:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2414:      	movq	%rax, 0x28(%rsp)
    2419:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2423:      	movq	%rax, 0x20(%rsp)
    2428:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2432:      	movq	%rax, 0x18(%rsp)
    2437:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2441:      	movq	%rax, 0x10(%rsp)
    2446:      	leaq	0x10(%rsp), %rdi
    244b:      	movl	$0x2e, %eax
    2450:      	movl	$0x6, %ecx
    2455:      	movl	0x50(%rsp), %edx
    2459:      	movl	$0x2e, %esi
    245e:      	xorl	%eax, %eax
    2460:      	callq	*%rcx
    2462:      	jmp	0x4fc <perf_unwind_perl+0x4fc>
    2467:      	cmpl	$0xc, %ecx
    246a:      	je	0x2477 <perf_unwind_perl+0x2477>
    246c:      	cmpq	$0x0, (%r12)
    2471:      	je	0x3d1b <perf_unwind_perl+0x3d1b>
    2477:      	movzbl	0x1d(%r14), %eax
    247c:      	subq	%rax, 0xf50(%r15)
    2483:      	movl	$0x10, 0x50(%rsp)
    248b:      	movq	(%rip), %rdi            # 0x2492 <perf_unwind_perl+0x2492>
    2492:      	leaq	0x50(%rsp), %rsi
    2497:      	movl	$0x1, %eax
    249c:      	callq	*%rax
    249e:      	testq	%rax, %rax
    24a1:      	je	0x24b8 <perf_unwind_perl+0x24b8>
    24a3:      	incq	(%rax)
    24a6:      	cmpl	$0x3, %ebp
    24a9:      	movq	0x98(%rsp), %rcx
    24b1:      	je	0x24d9 <perf_unwind_perl+0x24d9>
    24b3:      	jmp	0x5636 <perf_unwind_perl+0x5636>
    24b8:      	movq	(%rip), %rax            # 0x24bf <perf_unwind_perl+0x24bf>
    24bf:      	cmpl	$0x0, (%rax)
    24c2:      	jne	0x552a <perf_unwind_perl+0x552a>
    24c8:      	cmpl	$0x3, %ebp
    24cb:      	movq	0x98(%rsp), %rcx
    24d3:      	jne	0x5636 <perf_unwind_perl+0x5636>
    24d9:      	movq	0xf50(%r15), %r13
    24e0:      	cmpq	%rcx, %r13
    24e3:      	jae	0x24f7 <perf_unwind_perl+0x24f7>
    24e5:      	movl	$0x3, %ebp
    24ea:      	movq	0x98(%rsp), %rcx
    24f2:      	jmp	0x5636 <perf_unwind_perl+0x5636>
    24f7:      	movzbl	0x19(%r14), %eax
    24fc:      	addq	%r13, %rax
    24ff:      	leaq	0xe(%rsp), %rdi
    2504:      	movl	$0x1, %ecx
    2509:      	movl	$0x70, %r8d
    250f:      	movzbl	0x19(%r14), %edx
    2514:      	addq	%r13, %rdx
    2517:      	movl	$0x1, %esi
    251c:      	callq	*%r8
    251f:      	testq	%rax, %rax
    2522:      	je	0x2a15 <perf_unwind_perl+0x2a15>
    2528:      	movq	(%rip), %rax            # 0x252f <perf_unwind_perl+0x252f>
    252f:      	cmpl	$0x0, (%rax)
    2532:      	jne	0x6302 <perf_unwind_perl+0x6302>
    2538:      	movl	$0x13, 0x50(%rsp)
    2540:      	movq	(%rip), %rdi            # 0x2547 <perf_unwind_perl+0x2547>
    2547:      	leaq	0x50(%rsp), %rsi
    254c:      	movl	$0x1, %eax
    2551:      	callq	*%rax
    2553:      	testq	%rax, %rax
    2556:      	je	0x2bb4 <perf_unwind_perl+0x2bb4>
    255c:      	incq	(%rax)
    255f:      	movl	$0x3, %ebp
    2564:      	jmp	0x2d8f <perf_unwind_perl+0x2d8f>
    2569:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2573:      	movq	%rax, 0x36(%rsp)
    2578:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2582:      	movq	%rax, 0x30(%rsp)
    2587:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2591:      	movq	%rax, 0x28(%rsp)
    2596:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    25a0:      	movq	%rax, 0x20(%rsp)
    25a5:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    25af:      	movq	%rax, 0x18(%rsp)
    25b4:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    25be:      	movq	%rax, 0x10(%rsp)
    25c3:      	leaq	0x10(%rsp), %rdi
    25c8:      	movl	$0x2e, %eax
    25cd:      	movl	$0x6, %ecx
    25d2:      	movl	0x50(%rsp), %edx
    25d6:      	movl	$0x2e, %esi
    25db:      	xorl	%eax, %eax
    25dd:      	callq	*%rcx
    25df:      	jmp	0x4c8 <perf_unwind_perl+0x4c8>
    25e4:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    25ee:      	movq	%rax, 0x36(%rsp)
    25f3:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    25fd:      	movq	%rax, 0x30(%rsp)
    2602:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    260c:      	movq	%rax, 0x28(%rsp)
    2611:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    261b:      	movq	%rax, 0x20(%rsp)
    2620:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    262a:      	movq	%rax, 0x18(%rsp)
    262f:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2639:      	movq	%rax, 0x10(%rsp)
    263e:      	leaq	0x10(%rsp), %rdi
    2643:      	movl	$0x2e, %eax
    2648:      	movl	$0x6, %ecx
    264d:      	movl	0x50(%rsp), %edx
    2651:      	movl	$0x2e, %esi
    2656:      	xorl	%eax, %eax
    2658:      	callq	*%rcx
    265a:      	movl	$0x1, %ebp
    265f:      	jmp	0x586a <perf_unwind_perl+0x586a>
    2664:      	movl	0x5c(%rsp), %eax
    2668:      	andl	$0x1f, %eax
    266b:      	cmpl	$0xd, %eax
    266e:      	jne	0x2c50 <perf_unwind_perl+0x2c50>
    2674:      	movzbl	0x1f(%r14), %eax
    2679:      	addq	%rbp, %rax
    267c:      	leaq	0x50(%rsp), %rdi
    2681:      	movl	$0x8, %ecx
    2686:      	movl	$0x70, %r8d
    268c:      	movzbl	0x1f(%r14), %edx
    2691:      	addq	%rbp, %rdx
    2694:      	movl	$0x8, %esi
    2699:      	callq	*%r8
    269c:      	testq	%rax, %rax
    269f:      	jne	0x12ab <perf_unwind_perl+0x12ab>
    26a5:      	movzbl	0x21(%r14), %eax
    26aa:      	addq	0x50(%rsp), %rax
    26af:      	leaq	0x70(%rsp), %rdi
    26b4:      	movl	$0x4, %ecx
    26b9:      	movl	$0x70, %r8d
    26bf:      	movzbl	0x21(%r14), %edx
    26c4:      	addq	0x50(%rsp), %rdx
    26c9:      	movl	$0x4, %esi
    26ce:      	callq	*%r8
    26d1:      	testq	%rax, %rax
    26d4:      	jne	0x12ab <perf_unwind_perl+0x12ab>
    26da:      	testb	$-0x80, 0x71(%rsp)
    26df:      	jne	0x40cd <perf_unwind_perl+0x40cd>
    26e5:      	movzbl	0x22(%r14), %eax
    26ea:      	addq	0x50(%rsp), %rax
    26ef:      	leaq	0x60(%rsp), %rbp
    26f4:      	movl	$0x8, %ecx
    26f9:      	movl	$0x70, %r8d
    26ff:      	movzbl	0x22(%r14), %edx
    2704:      	addq	0x50(%rsp), %rdx
    2709:      	movq	%rbp, %rdi
    270c:      	movl	$0x8, %esi
    2711:      	callq	*%r8
    2714:      	testq	%rax, %rax
    2717:      	jne	0x12ab <perf_unwind_perl+0x12ab>
    271d:      	movq	0x60(%rsp), %rax
    2722:      	testq	%rax, %rax
    2725:      	je	0x12ab <perf_unwind_perl+0x12ab>
    272b:      	movq	(%rip), %rcx            # 0x2732 <perf_unwind_perl+0x2732>
    2732:      	cmpl	$0x0, (%rcx)
    2735:      	jne	0x7e7c <perf_unwind_perl+0x7e7c>
    273b:      	movzbl	0x1e(%r14), %ecx
    2740:      	addq	%rax, %rcx
    2743:      	leaq	0x6c(%rsp), %rdi
    2748:      	movl	$0x4, %eax
    274d:      	movl	$0x70, %r8d
    2753:      	movzbl	0x1e(%r14), %edx
    2758:      	addq	0x60(%rsp), %rdx
    275d:      	movl	$0x4, %esi
    2762:      	callq	*%r8
    2765:      	testq	%rax, %rax
    2768:      	jne	0x12ab <perf_unwind_perl+0x12ab>
    276e:      	movl	$0x801f, %eax           # imm = 0x801F
    2773:      	andl	0x6c(%rsp), %eax
    2777:      	cmpl	$0x8009, %eax           # imm = 0x8009
    277c:      	jne	0x52db <perf_unwind_perl+0x52db>
    2782:      	movzbl	0x20(%r14), %eax
    2787:      	addq	0x60(%rsp), %rax
    278c:      	leaq	0x88(%rsp), %rdi
    2794:      	movl	$0x8, %ecx
    2799:      	movl	$0x70, %r8d
    279f:      	movzbl	0x20(%r14), %edx
    27a4:      	addq	0x60(%rsp), %rdx
    27a9:      	movl	$0x8, %esi
    27ae:      	callq	*%r8
    27b1:      	testq	%rax, %rax
    27b4:      	jne	0x12ab <perf_unwind_perl+0x12ab>
    27ba:      	movzbl	0x23(%r14), %eax
    27bf:      	addq	0x88(%rsp), %rax
    27c7:      	leaq	0x78(%rsp), %rdi
    27cc:      	movl	$0x8, %ecx
    27d1:      	movl	$0x70, %r8d
    27d7:      	movzbl	0x23(%r14), %edx
    27dc:      	addq	0x88(%rsp), %rdx
    27e4:      	movl	$0x8, %esi
    27e9:      	callq	*%r8
    27ec:      	testq	%rax, %rax
    27ef:      	jne	0x12ab <perf_unwind_perl+0x12ab>
    27f5:      	movq	0x78(%rsp), %rax
    27fa:      	movq	%rax, 0x80(%rsp)
    2802:      	testq	%rax, %rax
    2805:      	je	0x285b <perf_unwind_perl+0x285b>
    2807:      	movq	(%rip), %rax            # 0x280e <perf_unwind_perl+0x280e>
    280e:      	cmpl	$0x0, (%rax)
    2811:      	je	0x2870 <perf_unwind_perl+0x2870>
    2813:      	movabsq	$0x2578302074612056, %rax # imm = 0x2578302074612056
    281d:      	movq	%rax, 0x18(%rsp)
    2822:      	movabsq	$0x474520646e756f46, %rax # imm = 0x474520646E756F46
    282c:      	movq	%rax, 0x10(%rsp)
    2831:      	movl	$0xa786c, 0x20(%rsp)    # imm = 0xA786C
    2839:      	leaq	0x10(%rsp), %rdi
    283e:      	movl	$0x14, %eax
    2843:      	movl	$0x6, %ecx
    2848:      	movq	0x78(%rsp), %rdx
    284d:      	movl	$0x14, %esi
    2852:      	xorl	%eax, %eax
    2854:      	callq	*%rcx
    2856:      	leaq	0x78(%rsp), %rbp
    285b:      	movq	(%rbp), %rax
    285f:      	movq	%rax, 0x80(%rsp)
    2867:      	testq	%rax, %rax
    286a:      	je	0xec7 <perf_unwind_perl+0xec7>
    2870:      	movq	(%r12), %rax
    2874:      	movq	%rax, 0x90(%rsp)
    287c:      	movq	(%rip), %rax            # 0x2883 <perf_unwind_perl+0x2883>
    2883:      	cmpl	$0x0, (%rax)
    2886:      	jne	0x8a5e <perf_unwind_perl+0x8a5e>
    288c:      	movl	0x2c0(%r15), %eax
    2893:      	cmpq	$0x7e, %rax
    2897:      	ja	0x1193 <perf_unwind_perl+0x1193>
    289d:      	xorl	%ecx, %ecx
    289f:      	movzbl	0xf(%rsp), %edx
    28a4:      	movb	%dl, %cl
    28a6:      	leal	0x1(,%rcx,2), %ebp
    28ad:      	leal	0x1(%rax), %ecx
    28b0:      	movl	%ecx, 0x2c0(%r15)
    28b7:      	leaq	(%rax,%rax,2), %rax
    28bb:      	movq	0x80(%rsp), %rcx
    28c3:      	movq	%rcx, 0x2d0(%r15,%rax,8)
    28cb:      	movq	0x90(%rsp), %rcx
    28d3:      	movq	%rcx, 0x2d8(%r15,%rax,8)
    28db:      	movb	$0x7, 0x2e0(%r15,%rax,8)
    28e4:      	movl	$0x0, 0x2e1(%r15,%rax,8)
    28f0:      	movl	$0x0, 0x2e4(%r15,%rax,8)
    28fc:      	movq	$0x0, 0xf40(%r15)
    2907:      	movzbl	0x1a(%r14), %eax
    290c:      	addq	%r13, %rax
    290f:      	movl	$0x8, %ecx
    2914:      	movl	$0x70, %r8d
    291a:      	movzbl	0x1a(%r14), %edx
    291f:      	addq	%r13, %rdx
    2922:      	movq	%r12, %rdi
    2925:      	movl	$0x8, %esi
    292a:      	callq	*%r8
    292d:      	testq	%rax, %rax
    2930:      	jne	0xec7 <perf_unwind_perl+0xec7>
    2936:      	movq	(%rip), %rax            # 0x293d <perf_unwind_perl+0x293d>
    293d:      	cmpl	$0x0, (%rax)
    2940:      	je	0x13ff <perf_unwind_perl+0x13ff>
    2946:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    2950:      	movq	%rax, 0x26(%rsp)
    2955:      	movabsq	$0x30206b6361747320, %rax # imm = 0x30206B6361747320
    295f:      	movq	%rax, 0x20(%rsp)
    2964:      	movabsq	$0x747865746e6f6320, %rax # imm = 0x747865746E6F6320
    296e:      	movq	%rax, 0x18(%rsp)
    2973:      	movabsq	$0x6d6f726620504f43, %rax # imm = 0x6D6F726620504F43
    297d:      	movq	%rax, 0x10(%rsp)
    2982:      	leaq	0x10(%rsp), %rdi
    2987:      	movl	$0x1e, %eax
    298c:      	movl	$0x6, %ecx
    2991:      	movq	(%r12), %rdx
    2995:      	movl	$0x1e, %esi
    299a:      	xorl	%eax, %eax
    299c:      	callq	*%rcx
    299e:      	jmp	0x13ff <perf_unwind_perl+0x13ff>
    29a3:      	movabsq	$0x7025207461207972, %rax # imm = 0x7025207461207972
    29ad:      	movq	%rax, 0x30(%rsp)
    29b2:      	movabsq	$0x746e65206b636174, %rax # imm = 0x746E65206B636174
    29bc:      	movq	%rax, 0x28(%rsp)
    29c1:      	movabsq	$0x7320747865746e6f, %rax # imm = 0x7320747865746E6F
    29cb:      	movq	%rax, 0x20(%rsp)
    29d0:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    29da:      	movq	%rax, 0x18(%rsp)
    29df:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    29e9:      	movq	%rax, 0x10(%rsp)
    29ee:      	movw	$0xa, 0x38(%rsp)
    29f5:      	leaq	0x10(%rsp), %rdi
    29fa:      	movl	$0x2a, %eax
    29ff:      	movl	$0x6, %ecx
    2a04:      	movl	$0x2a, %esi
    2a09:      	movq	%r13, %rdx
    2a0c:      	xorl	%eax, %eax
    2a0e:      	callq	*%rcx
    2a10:      	jmp	0x578 <perf_unwind_perl+0x578>
    2a15:      	movq	(%rip), %rax            # 0x2a1c <perf_unwind_perl+0x2a1c>
    2a1c:      	cmpl	$0x0, (%rax)
    2a1f:      	jne	0x66e1 <perf_unwind_perl+0x66e1>
    2a25:      	movzbl	0xe(%rsp), %eax
    2a2a:      	movl	%eax, %ecx
    2a2c:      	andl	$0xf, %ecx
    2a2f:      	movl	$0x3, %ebp
    2a34:      	leal	-0x9(%rcx), %edx
    2a37:      	cmpl	$0x2, %edx
    2a3a:      	jae	0x2d7f <perf_unwind_perl+0x2d7f>
    2a40:      	testb	%al, %al
    2a42:      	js	0x2d8f <perf_unwind_perl+0x2d8f>
    2a48:      	movzbl	0x1b(%r14), %eax
    2a4d:      	addq	%r13, %rax
    2a50:      	leaq	0x10(%rsp), %rdi
    2a55:      	movl	$0x8, %ecx
    2a5a:      	movl	$0x70, %r8d
    2a60:      	movzbl	0x1b(%r14), %edx
    2a65:      	addq	%r13, %rdx
    2a68:      	movl	$0x8, %esi
    2a6d:      	callq	*%r8
    2a70:      	testq	%rax, %rax
    2a73:      	jne	0x2528 <perf_unwind_perl+0x2528>
    2a79:      	cmpq	$0x0, 0x10(%rsp)
    2a7f:      	setne	0xf(%rsp)
    2a84:      	movzbl	0x1c(%r14), %eax
    2a89:      	addq	%r13, %rax
    2a8c:      	leaq	0xa0(%rsp), %rdi
    2a94:      	movl	$0x8, %ecx
    2a99:      	movl	$0x70, %r8d
    2a9f:      	movzbl	0x1c(%r14), %edx
    2aa4:      	addq	%r13, %rdx
    2aa7:      	movl	$0x8, %esi
    2aac:      	callq	*%r8
    2aaf:      	testq	%rax, %rax
    2ab2:      	jne	0x2528 <perf_unwind_perl+0x2528>
    2ab8:      	movq	0xa0(%rsp), %rbp
    2ac0:      	movzbl	0x1e(%r14), %eax
    2ac5:      	addq	%rbp, %rax
    2ac8:      	leaq	0x5c(%rsp), %rdi
    2acd:      	movl	$0x4, %ecx
    2ad2:      	movl	$0x70, %r8d
    2ad8:      	movzbl	0x1e(%r14), %edx
    2add:      	addq	%rbp, %rdx
    2ae0:      	movl	$0x4, %esi
    2ae5:      	callq	*%r8
    2ae8:      	testq	%rax, %rax
    2aeb:      	je	0x4464 <perf_unwind_perl+0x4464>
    2af1:      	movq	(%rip), %rax            # 0x2af8 <perf_unwind_perl+0x2af8>
    2af8:      	cmpl	$0x0, (%rax)
    2afb:      	jne	0x7860 <perf_unwind_perl+0x7860>
    2b01:      	movl	$0x14, 0x74(%rsp)
    2b09:      	movq	(%rip), %rdi            # 0x2b10 <perf_unwind_perl+0x2b10>
    2b10:      	leaq	0x74(%rsp), %rsi
    2b15:      	movl	$0x1, %eax
    2b1a:      	callq	*%rax
    2b1c:      	testq	%rax, %rax
    2b1f:      	je	0x49a5 <perf_unwind_perl+0x49a5>
    2b25:      	incq	(%rax)
    2b28:      	jmp	0x2528 <perf_unwind_perl+0x2528>
    2b2d:      	movq	(%rip), %rax            # 0x2b34 <perf_unwind_perl+0x2b34>
    2b34:      	cmpl	$0x0, (%rax)
    2b37:      	je	0xec7 <perf_unwind_perl+0xec7>
    2b3d:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2b47:      	movq	%rax, 0x36(%rsp)
    2b4c:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2b56:      	movq	%rax, 0x30(%rsp)
    2b5b:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2b65:      	movq	%rax, 0x28(%rsp)
    2b6a:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2b74:      	movq	%rax, 0x20(%rsp)
    2b79:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2b83:      	movq	%rax, 0x18(%rsp)
    2b88:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2b92:      	movq	%rax, 0x10(%rsp)
    2b97:      	leaq	0x10(%rsp), %rdi
    2b9c:      	movl	$0x2e, %eax
    2ba1:      	movl	$0x6, %ecx
    2ba6:      	movl	0x74(%rsp), %edx
    2baa:      	movl	$0x2e, %esi
    2baf:      	jmp	0x2cb4 <perf_unwind_perl+0x2cb4>
    2bb4:      	movq	(%rip), %rax            # 0x2bbb <perf_unwind_perl+0x2bbb>
    2bbb:      	cmpl	$0x0, (%rax)
    2bbe:      	jne	0x6883 <perf_unwind_perl+0x6883>
    2bc4:      	movl	$0x3, %ebp
    2bc9:      	jmp	0x2d8f <perf_unwind_perl+0x2d8f>
    2bce:      	movq	(%rip), %rax            # 0x2bd5 <perf_unwind_perl+0x2bd5>
    2bd5:      	cmpl	$0x0, (%rax)
    2bd8:      	je	0x568 <perf_unwind_perl+0x568>
    2bde:      	movabsq	$0xa782578302f78, %rax  # imm = 0xA782578302F78
    2be8:      	movq	%rax, 0x2e(%rsp)
    2bed:      	movabsq	$0x2f78257830207367, %rax # imm = 0x2F78257830207367
    2bf7:      	movq	%rax, 0x28(%rsp)
    2bfc:      	movabsq	$0x616c66202c564320, %rax # imm = 0x616C66202C564320
    2c06:      	movq	%rax, 0x20(%rsp)
    2c0b:      	movabsq	$0x44454d414e206465, %rax # imm = 0x44454D414E206465
    2c15:      	movq	%rax, 0x18(%rsp)
    2c1a:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    2c24:      	movq	%rax, 0x10(%rsp)
    2c29:      	leaq	0x10(%rsp), %rdi
    2c2e:      	movl	$0x26, %eax
    2c33:      	movl	$0x6, %r8d
    2c39:      	movl	0x5c(%rsp), %edx
    2c3d:      	movl	0x70(%rsp), %ecx
    2c41:      	movl	$0x26, %esi
    2c46:      	xorl	%eax, %eax
    2c48:      	callq	*%r8
    2c4b:      	jmp	0x568 <perf_unwind_perl+0x568>
    2c50:      	movq	(%rip), %rax            # 0x2c57 <perf_unwind_perl+0x2c57>
    2c57:      	cmpl	$0x0, (%rax)
    2c5a:      	je	0xec7 <perf_unwind_perl+0xec7>
    2c60:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    2c6a:      	movq	%rax, 0x26(%rsp)
    2c6f:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    2c79:      	movq	%rax, 0x20(%rsp)
    2c7e:      	movabsq	$0x5643565020612074, %rax # imm = 0x5643565020612074
    2c88:      	movq	%rax, 0x18(%rsp)
    2c8d:      	movabsq	$0x6f6e207369205643, %rax # imm = 0x6F6E207369205643
    2c97:      	movq	%rax, 0x10(%rsp)
    2c9c:      	leaq	0x10(%rsp), %rdi
    2ca1:      	movl	$0x1e, %eax
    2ca6:      	movl	$0x6, %ecx
    2cab:      	movl	0x5c(%rsp), %edx
    2caf:      	movl	$0x1e, %esi
    2cb4:      	xorl	%eax, %eax
    2cb6:      	callq	*%rcx
    2cb8:      	jmp	0xec7 <perf_unwind_perl+0xec7>
    2cbd:      	movabsq	$0x7825783020786320, %rax # imm = 0x7825783020786320
    2cc7:      	movq	%rax, 0x18(%rsp)
    2ccc:      	movabsq	$0x6c72657020746f47, %rax # imm = 0x6C72657020746F47
    2cd6:      	movq	%rax, 0x10(%rsp)
    2cdb:      	movw	$0xa, 0x20(%rsp)
    2ce2:      	leaq	0x10(%rsp), %rdi
    2ce7:      	movl	$0x12, %eax
    2cec:      	movl	$0x6, %ecx
    2cf1:      	movzbl	0xe(%rsp), %edx
    2cf6:      	movl	$0x12, %esi
    2cfb:      	xorl	%eax, %eax
    2cfd:      	callq	*%rcx
    2cff:      	jmp	0x8dd <perf_unwind_perl+0x8dd>
    2d04:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2d0e:      	movq	%rax, 0x36(%rsp)
    2d13:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2d1d:      	movq	%rax, 0x30(%rsp)
    2d22:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2d2c:      	movq	%rax, 0x28(%rsp)
    2d31:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2d3b:      	movq	%rax, 0x20(%rsp)
    2d40:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2d4a:      	movq	%rax, 0x18(%rsp)
    2d4f:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2d59:      	movq	%rax, 0x10(%rsp)
    2d5e:      	leaq	0x10(%rsp), %rdi
    2d63:      	movl	$0x2e, %eax
    2d68:      	movl	$0x6, %ecx
    2d6d:      	movl	0x50(%rsp), %edx
    2d71:      	movl	$0x2e, %esi
    2d76:      	xorl	%eax, %eax
    2d78:      	callq	*%rcx
    2d7a:      	jmp	0xafc <perf_unwind_perl+0xafc>
    2d7f:      	cmpl	$0xc, %ecx
    2d82:      	je	0x2d8f <perf_unwind_perl+0x2d8f>
    2d84:      	cmpq	$0x0, (%r12)
    2d89:      	je	0x4707 <perf_unwind_perl+0x4707>
    2d8f:      	movzbl	0x1d(%r14), %eax
    2d94:      	subq	%rax, 0xf50(%r15)
    2d9b:      	movl	$0x10, 0x50(%rsp)
    2da3:      	movq	(%rip), %rdi            # 0x2daa <perf_unwind_perl+0x2daa>
    2daa:      	leaq	0x50(%rsp), %rsi
    2daf:      	movl	$0x1, %eax
    2db4:      	callq	*%rax
    2db6:      	testq	%rax, %rax
    2db9:      	je	0x2dd0 <perf_unwind_perl+0x2dd0>
    2dbb:      	incq	(%rax)
    2dbe:      	cmpl	$0x3, %ebp
    2dc1:      	movq	0x98(%rsp), %rcx
    2dc9:      	je	0x2df1 <perf_unwind_perl+0x2df1>
    2dcb:      	jmp	0x5636 <perf_unwind_perl+0x5636>
    2dd0:      	movq	(%rip), %rax            # 0x2dd7 <perf_unwind_perl+0x2dd7>
    2dd7:      	cmpl	$0x0, (%rax)
    2dda:      	jne	0x6728 <perf_unwind_perl+0x6728>
    2de0:      	cmpl	$0x3, %ebp
    2de3:      	movq	0x98(%rsp), %rcx
    2deb:      	jne	0x5636 <perf_unwind_perl+0x5636>
    2df1:      	movq	0xf50(%r15), %r13
    2df8:      	cmpq	%rcx, %r13
    2dfb:      	jb	0x24e5 <perf_unwind_perl+0x24e5>
    2e01:      	movzbl	0x19(%r14), %eax
    2e06:      	addq	%r13, %rax
    2e09:      	leaq	0xe(%rsp), %rdi
    2e0e:      	movl	$0x1, %ecx
    2e13:      	movl	$0x70, %r8d
    2e19:      	movzbl	0x19(%r14), %edx
    2e1e:      	addq	%r13, %rdx
    2e21:      	movl	$0x1, %esi
    2e26:      	callq	*%r8
    2e29:      	testq	%rax, %rax
    2e2c:      	je	0x3435 <perf_unwind_perl+0x3435>
    2e32:      	movq	(%rip), %rax            # 0x2e39 <perf_unwind_perl+0x2e39>
    2e39:      	cmpl	$0x0, (%rax)
    2e3c:      	jne	0x6cb4 <perf_unwind_perl+0x6cb4>
    2e42:      	movl	$0x13, 0x50(%rsp)
    2e4a:      	movq	(%rip), %rdi            # 0x2e51 <perf_unwind_perl+0x2e51>
    2e51:      	leaq	0x50(%rsp), %rsi
    2e56:      	movl	$0x1, %eax
    2e5b:      	callq	*%rax
    2e5d:      	testq	%rax, %rax
    2e60:      	je	0x364c <perf_unwind_perl+0x364c>
    2e66:      	incq	(%rax)
    2e69:      	movl	$0x3, %ebp
    2e6e:      	jmp	0x38a2 <perf_unwind_perl+0x38a2>
    2e73:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    2e7d:      	movq	%rax, 0x27(%rsp)
    2e82:      	movabsq	$0x206d6f7266204453, %rax # imm = 0x206D6F7266204453
    2e8c:      	movq	%rax, 0x20(%rsp)
    2e91:      	movabsq	$0x542064616572206f, %rax # imm = 0x542064616572206F
    2e9b:      	movq	%rax, 0x18(%rsp)
    2ea0:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2eaa:      	movq	%rax, 0x10(%rsp)
    2eaf:      	leaq	0x10(%rsp), %rdi
    2eb4:      	movl	$0x1f, %eax
    2eb9:      	movl	$0x6, %ecx
    2ebe:      	movq	0x50(%rsp), %rdx
    2ec3:      	movl	$0x1f, %esi
    2ec8:      	xorl	%eax, %eax
    2eca:      	callq	*%rcx
    2ecc:      	jmp	0x8a1 <perf_unwind_perl+0x8a1>
    2ed1:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2edb:      	movq	%rax, 0x36(%rsp)
    2ee0:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2eea:      	movq	%rax, 0x30(%rsp)
    2eef:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2ef9:      	movq	%rax, 0x28(%rsp)
    2efe:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2f08:      	movq	%rax, 0x20(%rsp)
    2f0d:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2f17:      	movq	%rax, 0x18(%rsp)
    2f1c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2f26:      	movq	%rax, 0x10(%rsp)
    2f2b:      	leaq	0x10(%rsp), %rdi
    2f30:      	movl	$0x2e, %eax
    2f35:      	movl	$0x6, %ecx
    2f3a:      	movl	0x50(%rsp), %edx
    2f3e:      	movl	$0x2e, %esi
    2f43:      	xorl	%eax, %eax
    2f45:      	callq	*%rcx
    2f47:      	jmp	0x9f9 <perf_unwind_perl+0x9f9>
    2f4c:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    2f56:      	movq	%rax, 0x28(%rsp)
    2f5b:      	movabsq	$0x6174732072657465, %rax # imm = 0x6174732072657465
    2f65:      	movq	%rax, 0x20(%rsp)
    2f6a:      	movabsq	$0x72707265746e6920, %rax # imm = 0x72707265746E6920
    2f74:      	movq	%rax, 0x18(%rsp)
    2f79:      	movabsq	$0x6d6f726620504f43, %rax # imm = 0x6D6F726620504F43
    2f83:      	movq	%rax, 0x10(%rsp)
    2f88:      	movw	$0xa, 0x30(%rsp)
    2f8f:      	leaq	0x10(%rsp), %rdi
    2f94:      	movl	$0x22, %eax
    2f99:      	movl	$0x6, %ecx
    2f9e:      	movq	(%r13), %rdx
    2fa2:      	movl	$0x22, %esi
    2fa7:      	xorl	%eax, %eax
    2fa9:      	callq	*%rcx
    2fab:      	jmp	0xa0d <perf_unwind_perl+0xa0d>
    2fb0:      	movabsq	$0x6c25783020737365, %rax # imm = 0x6C25783020737365
    2fba:      	movq	%rax, 0x28(%rsp)
    2fbf:      	movabsq	$0x72646461206d6f72, %rax # imm = 0x72646461206D6F72
    2fc9:      	movq	%rax, 0x20(%rsp)
    2fce:      	movabsq	$0x662064252079656b, %rax # imm = 0x662064252079656B
    2fd8:      	movq	%rax, 0x18(%rsp)
    2fdd:      	movabsq	$0x2044535464616572, %rax # imm = 0x2044535464616572
    2fe7:      	movq	%rax, 0x10(%rsp)
    2fec:      	movl	$0xa786c, 0x2f(%rsp)    # imm = 0xA786C
    2ff4:      	leaq	0x10(%rsp), %rdi
    2ff9:      	movl	$0x23, %eax
    2ffe:      	movl	$0x6, %r8d
    3004:      	movq	0x50(%rsp), %rcx
    3009:      	movl	$0x23, %esi
    300e:      	movl	%r13d, %edx
    3011:      	xorl	%eax, %eax
    3013:      	callq	*%r8
    3016:      	movq	0x50(%rsp), %rcx
    301b:      	jmp	0x86e <perf_unwind_perl+0x86e>
    3020:      	movabsq	$0x6c25783020746120, %rax # imm = 0x6C25783020746120
    302a:      	movq	%rax, 0x28(%rsp)
    302f:      	movabsq	$0x6f666e696b636174, %rax # imm = 0x6F666E696B636174
    3039:      	movq	%rax, 0x20(%rsp)
    303e:      	movabsq	$0x732064616572206f, %rax # imm = 0x732064616572206F
    3048:      	movq	%rax, 0x18(%rsp)
    304d:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3057:      	movq	%rax, 0x10(%rsp)
    305c:      	movl	$0xa786c, 0x2f(%rsp)    # imm = 0xA786C
    3064:      	leaq	0x10(%rsp), %rdi
    3069:      	movl	$0x23, %eax
    306e:      	movl	$0x6, %ecx
    3073:      	movl	$0x23, %esi
    3078:      	movq	%r13, %rdx
    307b:      	xorl	%eax, %eax
    307d:      	callq	*%rcx
    307f:      	jmp	0xa80 <perf_unwind_perl+0xa80>
    3084:      	movl	0x5c(%rsp), %eax
    3088:      	andl	$0x1f, %eax
    308b:      	cmpl	$0xd, %eax
    308e:      	jne	0x3763 <perf_unwind_perl+0x3763>
    3094:      	movzbl	0x1f(%r14), %eax
    3099:      	addq	%rbp, %rax
    309c:      	leaq	0x50(%rsp), %rdi
    30a1:      	movl	$0x8, %ecx
    30a6:      	movl	$0x70, %r8d
    30ac:      	movzbl	0x1f(%r14), %edx
    30b1:      	addq	%rbp, %rdx
    30b4:      	movl	$0x8, %esi
    30b9:      	callq	*%r8
    30bc:      	testq	%rax, %rax
    30bf:      	jne	0x198e <perf_unwind_perl+0x198e>
    30c5:      	movzbl	0x21(%r14), %eax
    30ca:      	addq	0x50(%rsp), %rax
    30cf:      	leaq	0x70(%rsp), %rdi
    30d4:      	movl	$0x4, %ecx
    30d9:      	movl	$0x70, %r8d
    30df:      	movzbl	0x21(%r14), %edx
    30e4:      	addq	0x50(%rsp), %rdx
    30e9:      	movl	$0x4, %esi
    30ee:      	callq	*%r8
    30f1:      	testq	%rax, %rax
    30f4:      	jne	0x198e <perf_unwind_perl+0x198e>
    30fa:      	testb	$-0x80, 0x71(%rsp)
    30ff:      	jne	0x4a46 <perf_unwind_perl+0x4a46>
    3105:      	movzbl	0x22(%r14), %eax
    310a:      	addq	0x50(%rsp), %rax
    310f:      	leaq	0x60(%rsp), %rbp
    3114:      	movl	$0x8, %ecx
    3119:      	movl	$0x70, %r8d
    311f:      	movzbl	0x22(%r14), %edx
    3124:      	addq	0x50(%rsp), %rdx
    3129:      	movq	%rbp, %rdi
    312c:      	movl	$0x8, %esi
    3131:      	callq	*%r8
    3134:      	testq	%rax, %rax
    3137:      	jne	0x198e <perf_unwind_perl+0x198e>
    313d:      	movq	0x60(%rsp), %rax
    3142:      	testq	%rax, %rax
    3145:      	je	0x198e <perf_unwind_perl+0x198e>
    314b:      	movq	(%rip), %rcx            # 0x3152 <perf_unwind_perl+0x3152>
    3152:      	cmpl	$0x0, (%rcx)
    3155:      	jne	0x83d5 <perf_unwind_perl+0x83d5>
    315b:      	movzbl	0x1e(%r14), %ecx
    3160:      	addq	%rax, %rcx
    3163:      	leaq	0x6c(%rsp), %rdi
    3168:      	movl	$0x4, %eax
    316d:      	movl	$0x70, %r8d
    3173:      	movzbl	0x1e(%r14), %edx
    3178:      	addq	0x60(%rsp), %rdx
    317d:      	movl	$0x4, %esi
    3182:      	callq	*%r8
    3185:      	testq	%rax, %rax
    3188:      	jne	0x198e <perf_unwind_perl+0x198e>
    318e:      	movl	$0x801f, %eax           # imm = 0x801F
    3193:      	andl	0x6c(%rsp), %eax
    3197:      	cmpl	$0x8009, %eax           # imm = 0x8009
    319c:      	jne	0x648c <perf_unwind_perl+0x648c>
    31a2:      	movzbl	0x20(%r14), %eax
    31a7:      	addq	0x60(%rsp), %rax
    31ac:      	leaq	0x88(%rsp), %rdi
    31b4:      	movl	$0x8, %ecx
    31b9:      	movl	$0x70, %r8d
    31bf:      	movzbl	0x20(%r14), %edx
    31c4:      	addq	0x60(%rsp), %rdx
    31c9:      	movl	$0x8, %esi
    31ce:      	callq	*%r8
    31d1:      	testq	%rax, %rax
    31d4:      	jne	0x198e <perf_unwind_perl+0x198e>
    31da:      	movzbl	0x23(%r14), %eax
    31df:      	addq	0x88(%rsp), %rax
    31e7:      	leaq	0x78(%rsp), %rdi
    31ec:      	movl	$0x8, %ecx
    31f1:      	movl	$0x70, %r8d
    31f7:      	movzbl	0x23(%r14), %edx
    31fc:      	addq	0x88(%rsp), %rdx
    3204:      	movl	$0x8, %esi
    3209:      	callq	*%r8
    320c:      	testq	%rax, %rax
    320f:      	jne	0x198e <perf_unwind_perl+0x198e>
    3215:      	movq	0x78(%rsp), %rax
    321a:      	movq	%rax, 0x80(%rsp)
    3222:      	testq	%rax, %rax
    3225:      	je	0x327b <perf_unwind_perl+0x327b>
    3227:      	movq	(%rip), %rax            # 0x322e <perf_unwind_perl+0x322e>
    322e:      	cmpl	$0x0, (%rax)
    3231:      	je	0x3290 <perf_unwind_perl+0x3290>
    3233:      	movabsq	$0x2578302074612056, %rax # imm = 0x2578302074612056
    323d:      	movq	%rax, 0x18(%rsp)
    3242:      	movabsq	$0x474520646e756f46, %rax # imm = 0x474520646E756F46
    324c:      	movq	%rax, 0x10(%rsp)
    3251:      	movl	$0xa786c, 0x20(%rsp)    # imm = 0xA786C
    3259:      	leaq	0x10(%rsp), %rdi
    325e:      	movl	$0x14, %eax
    3263:      	movl	$0x6, %ecx
    3268:      	movq	0x78(%rsp), %rdx
    326d:      	movl	$0x14, %esi
    3272:      	xorl	%eax, %eax
    3274:      	callq	*%rcx
    3276:      	leaq	0x78(%rsp), %rbp
    327b:      	movq	(%rbp), %rax
    327f:      	movq	%rax, 0x80(%rsp)
    3287:      	testq	%rax, %rax
    328a:      	je	0x149a <perf_unwind_perl+0x149a>
    3290:      	movq	(%r12), %rax
    3294:      	movq	%rax, 0x90(%rsp)
    329c:      	movq	(%rip), %rax            # 0x32a3 <perf_unwind_perl+0x32a3>
    32a3:      	cmpl	$0x0, (%rax)
    32a6:      	jne	0x8c25 <perf_unwind_perl+0x8c25>
    32ac:      	movl	0x2c0(%r15), %eax
    32b3:      	cmpq	$0x7e, %rax
    32b7:      	ja	0x1193 <perf_unwind_perl+0x1193>
    32bd:      	xorl	%ecx, %ecx
    32bf:      	movzbl	0xf(%rsp), %edx
    32c4:      	movb	%dl, %cl
    32c6:      	leal	0x1(,%rcx,2), %ebp
    32cd:      	leal	0x1(%rax), %ecx
    32d0:      	movl	%ecx, 0x2c0(%r15)
    32d7:      	leaq	(%rax,%rax,2), %rax
    32db:      	movq	0x80(%rsp), %rcx
    32e3:      	movq	%rcx, 0x2d0(%r15,%rax,8)
    32eb:      	movq	0x90(%rsp), %rcx
    32f3:      	movq	%rcx, 0x2d8(%r15,%rax,8)
    32fb:      	movb	$0x7, 0x2e0(%r15,%rax,8)
    3304:      	movl	$0x0, 0x2e1(%r15,%rax,8)
    3310:      	movl	$0x0, 0x2e4(%r15,%rax,8)
    331c:      	movq	$0x0, 0xf40(%r15)
    3327:      	movzbl	0x1a(%r14), %eax
    332c:      	addq	%r13, %rax
    332f:      	movl	$0x8, %ecx
    3334:      	movl	$0x70, %r8d
    333a:      	movzbl	0x1a(%r14), %edx
    333f:      	addq	%r13, %rdx
    3342:      	movq	%r12, %rdi
    3345:      	movl	$0x8, %esi
    334a:      	callq	*%r8
    334d:      	testq	%rax, %rax
    3350:      	jne	0x149a <perf_unwind_perl+0x149a>
    3356:      	movq	(%rip), %rax            # 0x335d <perf_unwind_perl+0x335d>
    335d:      	cmpl	$0x0, (%rax)
    3360:      	je	0x1ae2 <perf_unwind_perl+0x1ae2>
    3366:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    3370:      	movq	%rax, 0x26(%rsp)
    3375:      	movabsq	$0x30206b6361747320, %rax # imm = 0x30206B6361747320
    337f:      	movq	%rax, 0x20(%rsp)
    3384:      	movabsq	$0x747865746e6f6320, %rax # imm = 0x747865746E6F6320
    338e:      	movq	%rax, 0x18(%rsp)
    3393:      	movabsq	$0x6d6f726620504f43, %rax # imm = 0x6D6F726620504F43
    339d:      	movq	%rax, 0x10(%rsp)
    33a2:      	leaq	0x10(%rsp), %rdi
    33a7:      	movl	$0x1e, %eax
    33ac:      	movl	$0x6, %ecx
    33b1:      	movq	(%r12), %rdx
    33b5:      	movl	$0x1e, %esi
    33ba:      	xorl	%eax, %eax
    33bc:      	callq	*%rcx
    33be:      	jmp	0x1ae2 <perf_unwind_perl+0x1ae2>
    33c3:      	movabsq	$0x7025207461207972, %rax # imm = 0x7025207461207972
    33cd:      	movq	%rax, 0x30(%rsp)
    33d2:      	movabsq	$0x746e65206b636174, %rax # imm = 0x746E65206B636174
    33dc:      	movq	%rax, 0x28(%rsp)
    33e1:      	movabsq	$0x7320747865746e6f, %rax # imm = 0x7320747865746E6F
    33eb:      	movq	%rax, 0x20(%rsp)
    33f0:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    33fa:      	movq	%rax, 0x18(%rsp)
    33ff:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3409:      	movq	%rax, 0x10(%rsp)
    340e:      	movw	$0xa, 0x38(%rsp)
    3415:      	leaq	0x10(%rsp), %rdi
    341a:      	movl	$0x2a, %eax
    341f:      	movl	$0x6, %ecx
    3424:      	movl	$0x2a, %esi
    3429:      	movq	%r13, %rdx
    342c:      	xorl	%eax, %eax
    342e:      	callq	*%rcx
    3430:      	jmp	0xb78 <perf_unwind_perl+0xb78>
    3435:      	movq	(%rip), %rax            # 0x343c <perf_unwind_perl+0x343c>
    343c:      	cmpl	$0x0, (%rax)
    343f:      	jne	0x6f61 <perf_unwind_perl+0x6f61>
    3445:      	movzbl	0xe(%rsp), %eax
    344a:      	movl	%eax, %ecx
    344c:      	andl	$0xf, %ecx
    344f:      	movl	$0x3, %ebp
    3454:      	leal	-0x9(%rcx), %edx
    3457:      	cmpl	$0x2, %edx
    345a:      	jae	0x3892 <perf_unwind_perl+0x3892>
    3460:      	testb	%al, %al
    3462:      	js	0x38a2 <perf_unwind_perl+0x38a2>
    3468:      	movzbl	0x1b(%r14), %eax
    346d:      	addq	%r13, %rax
    3470:      	leaq	0x10(%rsp), %rdi
    3475:      	movl	$0x8, %ecx
    347a:      	movl	$0x70, %r8d
    3480:      	movzbl	0x1b(%r14), %edx
    3485:      	addq	%r13, %rdx
    3488:      	movl	$0x8, %esi
    348d:      	callq	*%r8
    3490:      	testq	%rax, %rax
    3493:      	jne	0x2e32 <perf_unwind_perl+0x2e32>
    3499:      	cmpq	$0x0, 0x10(%rsp)
    349f:      	setne	0xf(%rsp)
    34a4:      	movzbl	0x1c(%r14), %eax
    34a9:      	addq	%r13, %rax
    34ac:      	leaq	0xa0(%rsp), %rdi
    34b4:      	movl	$0x8, %ecx
    34b9:      	movl	$0x70, %r8d
    34bf:      	movzbl	0x1c(%r14), %edx
    34c4:      	addq	%r13, %rdx
    34c7:      	movl	$0x8, %esi
    34cc:      	callq	*%r8
    34cf:      	testq	%rax, %rax
    34d2:      	jne	0x2e32 <perf_unwind_perl+0x2e32>
    34d8:      	movq	0xa0(%rsp), %rbp
    34e0:      	movzbl	0x1e(%r14), %eax
    34e5:      	addq	%rbp, %rax
    34e8:      	leaq	0x5c(%rsp), %rdi
    34ed:      	movl	$0x4, %ecx
    34f2:      	movl	$0x70, %r8d
    34f8:      	movzbl	0x1e(%r14), %edx
    34fd:      	addq	%rbp, %rdx
    3500:      	movl	$0x4, %esi
    3505:      	callq	*%r8
    3508:      	testq	%rax, %rax
    350b:      	je	0x4e12 <perf_unwind_perl+0x4e12>
    3511:      	movq	(%rip), %rax            # 0x3518 <perf_unwind_perl+0x3518>
    3518:      	cmpl	$0x0, (%rax)
    351b:      	jne	0x816e <perf_unwind_perl+0x816e>
    3521:      	movl	$0x14, 0x74(%rsp)
    3529:      	movq	(%rip), %rdi            # 0x3530 <perf_unwind_perl+0x3530>
    3530:      	leaq	0x74(%rsp), %rsi
    3535:      	movl	$0x1, %eax
    353a:      	callq	*%rax
    353c:      	testq	%rax, %rax
    353f:      	je	0x5353 <perf_unwind_perl+0x5353>
    3545:      	incq	(%rax)
    3548:      	jmp	0x2e32 <perf_unwind_perl+0x2e32>
    354d:      	movq	(%rip), %rax            # 0x3554 <perf_unwind_perl+0x3554>
    3554:      	cmpl	$0x0, (%rax)
    3557:      	je	0x27c <perf_unwind_perl+0x27c>
    355d:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    3567:      	movq	%rax, 0x2e(%rsp)
    356c:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    3576:      	movq	%rax, 0x28(%rsp)
    357b:      	movabsq	$0x50472d74756f6874, %rax # imm = 0x50472D74756F6874
    3585:      	movq	%rax, 0x20(%rsp)
    358a:      	movabsq	$0x69772d5647206465, %rax # imm = 0x69772D5647206465
    3594:      	movq	%rax, 0x18(%rsp)
    3599:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    35a3:      	movq	%rax, 0x10(%rsp)
    35a8:      	leaq	0x10(%rsp), %rdi
    35ad:      	movl	$0x26, %eax
    35b2:      	movl	$0x6, %ecx
    35b7:      	movl	0x6c(%rsp), %edx
    35bb:      	movl	$0x26, %esi
    35c0:      	jmp	0x13e6 <perf_unwind_perl+0x13e6>
    35c5:      	movq	(%rip), %rax            # 0x35cc <perf_unwind_perl+0x35cc>
    35cc:      	cmpl	$0x0, (%rax)
    35cf:      	je	0x149a <perf_unwind_perl+0x149a>
    35d5:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    35df:      	movq	%rax, 0x36(%rsp)
    35e4:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    35ee:      	movq	%rax, 0x30(%rsp)
    35f3:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    35fd:      	movq	%rax, 0x28(%rsp)
    3602:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    360c:      	movq	%rax, 0x20(%rsp)
    3611:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    361b:      	movq	%rax, 0x18(%rsp)
    3620:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    362a:      	movq	%rax, 0x10(%rsp)
    362f:      	leaq	0x10(%rsp), %rdi
    3634:      	movl	$0x2e, %eax
    3639:      	movl	$0x6, %ecx
    363e:      	movl	0x74(%rsp), %edx
    3642:      	movl	$0x2e, %esi
    3647:      	jmp	0x37c7 <perf_unwind_perl+0x37c7>
    364c:      	movq	(%rip), %rax            # 0x3653 <perf_unwind_perl+0x3653>
    3653:      	cmpl	$0x0, (%rax)
    3656:      	jne	0x7034 <perf_unwind_perl+0x7034>
    365c:      	movl	$0x3, %ebp
    3661:      	jmp	0x38a2 <perf_unwind_perl+0x38a2>
    3666:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3670:      	movq	%rax, 0x36(%rsp)
    3675:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    367f:      	movq	%rax, 0x30(%rsp)
    3684:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    368e:      	movq	%rax, 0x28(%rsp)
    3693:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    369d:      	movq	%rax, 0x20(%rsp)
    36a2:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    36ac:      	movq	%rax, 0x18(%rsp)
    36b1:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    36bb:      	movq	%rax, 0x10(%rsp)
    36c0:      	leaq	0x10(%rsp), %rdi
    36c5:      	movl	$0x2e, %eax
    36ca:      	movl	$0x6, %ecx
    36cf:      	movl	0x78(%rsp), %edx
    36d3:      	movl	$0x2e, %esi
    36d8:      	xorl	%eax, %eax
    36da:      	callq	*%rcx
    36dc:      	jmp	0xbb4 <perf_unwind_perl+0xbb4>
    36e1:      	movq	(%rip), %rax            # 0x36e8 <perf_unwind_perl+0x36e8>
    36e8:      	cmpl	$0x0, (%rax)
    36eb:      	je	0xb68 <perf_unwind_perl+0xb68>
    36f1:      	movabsq	$0xa782578302f78, %rax  # imm = 0xA782578302F78
    36fb:      	movq	%rax, 0x2e(%rsp)
    3700:      	movabsq	$0x2f78257830207367, %rax # imm = 0x2F78257830207367
    370a:      	movq	%rax, 0x28(%rsp)
    370f:      	movabsq	$0x616c66202c564320, %rax # imm = 0x616C66202C564320
    3719:      	movq	%rax, 0x20(%rsp)
    371e:      	movabsq	$0x44454d414e206465, %rax # imm = 0x44454D414E206465
    3728:      	movq	%rax, 0x18(%rsp)
    372d:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    3737:      	movq	%rax, 0x10(%rsp)
    373c:      	leaq	0x10(%rsp), %rdi
    3741:      	movl	$0x26, %eax
    3746:      	movl	$0x6, %r8d
    374c:      	movl	0x5c(%rsp), %edx
    3750:      	movl	0x70(%rsp), %ecx
    3754:      	movl	$0x26, %esi
    3759:      	xorl	%eax, %eax
    375b:      	callq	*%r8
    375e:      	jmp	0xb68 <perf_unwind_perl+0xb68>
    3763:      	movq	(%rip), %rax            # 0x376a <perf_unwind_perl+0x376a>
    376a:      	cmpl	$0x0, (%rax)
    376d:      	je	0x149a <perf_unwind_perl+0x149a>
    3773:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    377d:      	movq	%rax, 0x26(%rsp)
    3782:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    378c:      	movq	%rax, 0x20(%rsp)
    3791:      	movabsq	$0x5643565020612074, %rax # imm = 0x5643565020612074
    379b:      	movq	%rax, 0x18(%rsp)
    37a0:      	movabsq	$0x6f6e207369205643, %rax # imm = 0x6F6E207369205643
    37aa:      	movq	%rax, 0x10(%rsp)
    37af:      	leaq	0x10(%rsp), %rdi
    37b4:      	movl	$0x1e, %eax
    37b9:      	movl	$0x6, %ecx
    37be:      	movl	0x5c(%rsp), %edx
    37c2:      	movl	$0x1e, %esi
    37c7:      	xorl	%eax, %eax
    37c9:      	callq	*%rcx
    37cb:      	jmp	0x149a <perf_unwind_perl+0x149a>
    37d0:      	movabsq	$0x7825783020786320, %rax # imm = 0x7825783020786320
    37da:      	movq	%rax, 0x18(%rsp)
    37df:      	movabsq	$0x6c72657020746f47, %rax # imm = 0x6C72657020746F47
    37e9:      	movq	%rax, 0x10(%rsp)
    37ee:      	movw	$0xa, 0x20(%rsp)
    37f5:      	leaq	0x10(%rsp), %rdi
    37fa:      	movl	$0x12, %eax
    37ff:      	movl	$0x6, %ecx
    3804:      	movzbl	0xe(%rsp), %edx
    3809:      	movl	$0x12, %esi
    380e:      	xorl	%eax, %eax
    3810:      	callq	*%rcx
    3812:      	jmp	0xc6e <perf_unwind_perl+0xc6e>
    3817:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3821:      	movq	%rax, 0x36(%rsp)
    3826:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    3830:      	movq	%rax, 0x30(%rsp)
    3835:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    383f:      	movq	%rax, 0x28(%rsp)
    3844:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    384e:      	movq	%rax, 0x20(%rsp)
    3853:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    385d:      	movq	%rax, 0x18(%rsp)
    3862:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    386c:      	movq	%rax, 0x10(%rsp)
    3871:      	leaq	0x10(%rsp), %rdi
    3876:      	movl	$0x2e, %eax
    387b:      	movl	$0x6, %ecx
    3880:      	movl	0x50(%rsp), %edx
    3884:      	movl	$0x2e, %esi
    3889:      	xorl	%eax, %eax
    388b:      	callq	*%rcx
    388d:      	jmp	0xe5b <perf_unwind_perl+0xe5b>
    3892:      	cmpl	$0xc, %ecx
    3895:      	je	0x38a2 <perf_unwind_perl+0x38a2>
    3897:      	cmpq	$0x0, (%r12)
    389c:      	je	0x50b5 <perf_unwind_perl+0x50b5>
    38a2:      	movzbl	0x1d(%r14), %eax
    38a7:      	subq	%rax, 0xf50(%r15)
    38ae:      	movl	$0x10, 0x50(%rsp)
    38b6:      	movq	(%rip), %rdi            # 0x38bd <perf_unwind_perl+0x38bd>
    38bd:      	leaq	0x50(%rsp), %rsi
    38c2:      	movl	$0x1, %eax
    38c7:      	callq	*%rax
    38c9:      	testq	%rax, %rax
    38cc:      	je	0x38e3 <perf_unwind_perl+0x38e3>
    38ce:      	incq	(%rax)
    38d1:      	cmpl	$0x3, %ebp
    38d4:      	movq	0x98(%rsp), %rcx
    38dc:      	je	0x3904 <perf_unwind_perl+0x3904>
    38de:      	jmp	0x5636 <perf_unwind_perl+0x5636>
    38e3:      	movq	(%rip), %rax            # 0x38ea <perf_unwind_perl+0x38ea>
    38ea:      	cmpl	$0x0, (%rax)
    38ed:      	jne	0x6fa8 <perf_unwind_perl+0x6fa8>
    38f3:      	cmpl	$0x3, %ebp
    38f6:      	movq	0x98(%rsp), %rcx
    38fe:      	jne	0x5636 <perf_unwind_perl+0x5636>
    3904:      	movq	0xf50(%r15), %r13
    390b:      	cmpq	%rcx, %r13
    390e:      	jb	0x24e5 <perf_unwind_perl+0x24e5>
    3914:      	movzbl	0x19(%r14), %eax
    3919:      	addq	%r13, %rax
    391c:      	leaq	0xe(%rsp), %rdi
    3921:      	movl	$0x1, %ecx
    3926:      	movl	$0x70, %r8d
    392c:      	movzbl	0x19(%r14), %edx
    3931:      	addq	%r13, %rdx
    3934:      	movl	$0x1, %esi
    3939:      	callq	*%r8
    393c:      	testq	%rax, %rax
    393f:      	je	0x3e29 <perf_unwind_perl+0x3e29>
    3945:      	movq	(%rip), %rax            # 0x394c <perf_unwind_perl+0x394c>
    394c:      	cmpl	$0x0, (%rax)
    394f:      	jne	0x7465 <perf_unwind_perl+0x7465>
    3955:      	movl	$0x13, 0x50(%rsp)
    395d:      	movq	(%rip), %rdi            # 0x3964 <perf_unwind_perl+0x3964>
    3964:      	leaq	0x50(%rsp), %rsi
    3969:      	movl	$0x1, %eax
    396e:      	callq	*%rax
    3970:      	testq	%rax, %rax
    3973:      	je	0x40b3 <perf_unwind_perl+0x40b3>
    3979:      	incq	(%rax)
    397c:      	movl	$0x3, %ebp
    3981:      	jmp	0x428e <perf_unwind_perl+0x428e>
    3986:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3990:      	movq	%rax, 0x36(%rsp)
    3995:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    399f:      	movq	%rax, 0x30(%rsp)
    39a4:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    39ae:      	movq	%rax, 0x28(%rsp)
    39b3:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    39bd:      	movq	%rax, 0x20(%rsp)
    39c2:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    39cc:      	movq	%rax, 0x18(%rsp)
    39d1:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    39db:      	movq	%rax, 0x10(%rsp)
    39e0:      	leaq	0x10(%rsp), %rdi
    39e5:      	movl	$0x2e, %eax
    39ea:      	movl	$0x6, %ecx
    39ef:      	movl	0x50(%rsp), %edx
    39f3:      	movl	$0x2e, %esi
    39f8:      	xorl	%eax, %eax
    39fa:      	callq	*%rcx
    39fc:      	jmp	0xe15 <perf_unwind_perl+0xe15>
    3a01:      	movabsq	$0xa7667655f7663, %rax  # imm = 0xA7667655F7663
    3a0b:      	movq	%rax, 0x35(%rsp)
    3a10:      	movabsq	$0x5f76635f65766c6f, %rax # imm = 0x5F76635F65766C6F
    3a1a:      	movq	%rax, 0x30(%rsp)
    3a1f:      	movabsq	$0x736572206e692029, %rax # imm = 0x736572206E692029
    3a29:      	movq	%rax, 0x28(%rsp)
    3a2e:      	movabsq	$0x28726573755f6461, %rax # imm = 0x28726573755F6461
    3a38:      	movq	%rax, 0x20(%rsp)
    3a3d:      	movabsq	$0x65725f65626f7270, %rax # imm = 0x65725F65626F7270
    3a47:      	movq	%rax, 0x18(%rsp)
    3a4c:      	movabsq	$0x5f66706220646142, %rax # imm = 0x5F66706220646142
    3a56:      	movq	%rax, 0x10(%rsp)
    3a5b:      	leaq	0x10(%rsp), %rdi
    3a60:      	movl	$0x2d, %eax
    3a65:      	movl	$0x6, %ecx
    3a6a:      	movl	$0x2d, %esi
    3a6f:      	xorl	%eax, %eax
    3a71:      	callq	*%rcx
    3a73:      	jmp	0x48c <perf_unwind_perl+0x48c>
    3a78:      	movl	0x5c(%rsp), %eax
    3a7c:      	andl	$0x1f, %eax
    3a7f:      	cmpl	$0xd, %eax
    3a82:      	jne	0x414f <perf_unwind_perl+0x414f>
    3a88:      	movzbl	0x1f(%r14), %eax
    3a8d:      	addq	%rbp, %rax
    3a90:      	leaq	0x50(%rsp), %rdi
    3a95:      	movl	$0x8, %ecx
    3a9a:      	movl	$0x70, %r8d
    3aa0:      	movzbl	0x1f(%r14), %edx
    3aa5:      	addq	%rbp, %rdx
    3aa8:      	movl	$0x8, %esi
    3aad:      	callq	*%r8
    3ab0:      	testq	%rax, %rax
    3ab3:      	jne	0x204b <perf_unwind_perl+0x204b>
    3ab9:      	movzbl	0x21(%r14), %eax
    3abe:      	addq	0x50(%rsp), %rax
    3ac3:      	leaq	0x70(%rsp), %rdi
    3ac8:      	movl	$0x4, %ecx
    3acd:      	movl	$0x70, %r8d
    3ad3:      	movzbl	0x21(%r14), %edx
    3ad8:      	addq	0x50(%rsp), %rdx
    3add:      	movl	$0x4, %esi
    3ae2:      	callq	*%r8
    3ae5:      	testq	%rax, %rax
    3ae8:      	jne	0x204b <perf_unwind_perl+0x204b>
    3aee:      	testb	$-0x80, 0x71(%rsp)
    3af3:      	jne	0x53f4 <perf_unwind_perl+0x53f4>
    3af9:      	movzbl	0x22(%r14), %eax
    3afe:      	addq	0x50(%rsp), %rax
    3b03:      	leaq	0x60(%rsp), %rbp
    3b08:      	movl	$0x8, %ecx
    3b0d:      	movl	$0x70, %r8d
    3b13:      	movzbl	0x22(%r14), %edx
    3b18:      	addq	0x50(%rsp), %rdx
    3b1d:      	movq	%rbp, %rdi
    3b20:      	movl	$0x8, %esi
    3b25:      	callq	*%r8
    3b28:      	testq	%rax, %rax
    3b2b:      	jne	0x204b <perf_unwind_perl+0x204b>
    3b31:      	movq	0x60(%rsp), %rax
    3b36:      	testq	%rax, %rax
    3b39:      	je	0x204b <perf_unwind_perl+0x204b>
    3b3f:      	movq	(%rip), %rcx            # 0x3b46 <perf_unwind_perl+0x3b46>
    3b46:      	cmpl	$0x0, (%rcx)
    3b49:      	jne	0x87de <perf_unwind_perl+0x87de>
    3b4f:      	movzbl	0x1e(%r14), %ecx
    3b54:      	addq	%rax, %rcx
    3b57:      	leaq	0x6c(%rsp), %rdi
    3b5c:      	movl	$0x4, %eax
    3b61:      	movl	$0x70, %r8d
    3b67:      	movzbl	0x1e(%r14), %edx
    3b6c:      	addq	0x60(%rsp), %rdx
    3b71:      	movl	$0x4, %esi
    3b76:      	callq	*%r8
    3b79:      	testq	%rax, %rax
    3b7c:      	jne	0x204b <perf_unwind_perl+0x204b>
    3b82:      	movl	$0x801f, %eax           # imm = 0x801F
    3b87:      	andl	0x6c(%rsp), %eax
    3b8b:      	cmpl	$0x8009, %eax           # imm = 0x8009
    3b90:      	jne	0x6d26 <perf_unwind_perl+0x6d26>
    3b96:      	movzbl	0x20(%r14), %eax
    3b9b:      	addq	0x60(%rsp), %rax
    3ba0:      	leaq	0x88(%rsp), %rdi
    3ba8:      	movl	$0x8, %ecx
    3bad:      	movl	$0x70, %r8d
    3bb3:      	movzbl	0x20(%r14), %edx
    3bb8:      	addq	0x60(%rsp), %rdx
    3bbd:      	movl	$0x8, %esi
    3bc2:      	callq	*%r8
    3bc5:      	testq	%rax, %rax
    3bc8:      	jne	0x204b <perf_unwind_perl+0x204b>
    3bce:      	movzbl	0x23(%r14), %eax
    3bd3:      	addq	0x88(%rsp), %rax
    3bdb:      	leaq	0x78(%rsp), %rdi
    3be0:      	movl	$0x8, %ecx
    3be5:      	movl	$0x70, %r8d
    3beb:      	movzbl	0x23(%r14), %edx
    3bf0:      	addq	0x88(%rsp), %rdx
    3bf8:      	movl	$0x8, %esi
    3bfd:      	callq	*%r8
    3c00:      	testq	%rax, %rax
    3c03:      	jne	0x204b <perf_unwind_perl+0x204b>
    3c09:      	movq	0x78(%rsp), %rax
    3c0e:      	movq	%rax, 0x80(%rsp)
    3c16:      	testq	%rax, %rax
    3c19:      	je	0x3c6f <perf_unwind_perl+0x3c6f>
    3c1b:      	movq	(%rip), %rax            # 0x3c22 <perf_unwind_perl+0x3c22>
    3c22:      	cmpl	$0x0, (%rax)
    3c25:      	je	0x3c84 <perf_unwind_perl+0x3c84>
    3c27:      	movabsq	$0x2578302074612056, %rax # imm = 0x2578302074612056
    3c31:      	movq	%rax, 0x18(%rsp)
    3c36:      	movabsq	$0x474520646e756f46, %rax # imm = 0x474520646E756F46
    3c40:      	movq	%rax, 0x10(%rsp)
    3c45:      	movl	$0xa786c, 0x20(%rsp)    # imm = 0xA786C
    3c4d:      	leaq	0x10(%rsp), %rdi
    3c52:      	movl	$0x14, %eax
    3c57:      	movl	$0x6, %ecx
    3c5c:      	movq	0x78(%rsp), %rdx
    3c61:      	movl	$0x14, %esi
    3c66:      	xorl	%eax, %eax
    3c68:      	callq	*%rcx
    3c6a:      	leaq	0x78(%rsp), %rbp
    3c6f:      	movq	(%rbp), %rax
    3c73:      	movq	%rax, 0x80(%rsp)
    3c7b:      	testq	%rax, %rax
    3c7e:      	je	0x1b7d <perf_unwind_perl+0x1b7d>
    3c84:      	movq	(%r12), %rax
    3c88:      	movq	%rax, 0x90(%rsp)
    3c90:      	movq	(%rip), %rax            # 0x3c97 <perf_unwind_perl+0x3c97>
    3c97:      	cmpl	$0x0, (%rax)
    3c9a:      	jne	0x8d74 <perf_unwind_perl+0x8d74>
    3ca0:      	movl	0x2c0(%r15), %eax
    3ca7:      	cmpq	$0x7e, %rax
    3cab:      	ja	0x1193 <perf_unwind_perl+0x1193>
    3cb1:      	xorl	%ecx, %ecx
    3cb3:      	movzbl	0xf(%rsp), %edx
    3cb8:      	movb	%dl, %cl
    3cba:      	leal	0x1(,%rcx,2), %ebp
    3cc1:      	leal	0x1(%rax), %ecx
    3cc4:      	movl	%ecx, 0x2c0(%r15)
    3ccb:      	leaq	(%rax,%rax,2), %rax
    3ccf:      	movq	0x80(%rsp), %rcx
    3cd7:      	movq	%rcx, 0x2d0(%r15,%rax,8)
    3cdf:      	movq	0x90(%rsp), %rcx
    3ce7:      	movq	%rcx, 0x2d8(%r15,%rax,8)
    3cef:      	movb	$0x7, 0x2e0(%r15,%rax,8)
    3cf8:      	movl	$0x0, 0x2e1(%r15,%rax,8)
    3d04:      	movl	$0x0, 0x2e4(%r15,%rax,8)
    3d10:      	movq	$0x0, 0xf40(%r15)
    3d1b:      	movzbl	0x1a(%r14), %eax
    3d20:      	addq	%r13, %rax
    3d23:      	movl	$0x8, %ecx
    3d28:      	movl	$0x70, %r8d
    3d2e:      	movzbl	0x1a(%r14), %edx
    3d33:      	addq	%r13, %rdx
    3d36:      	movq	%r12, %rdi
    3d39:      	movl	$0x8, %esi
    3d3e:      	callq	*%r8
    3d41:      	testq	%rax, %rax
    3d44:      	jne	0x1b7d <perf_unwind_perl+0x1b7d>
    3d4a:      	movq	(%rip), %rax            # 0x3d51 <perf_unwind_perl+0x3d51>
    3d51:      	cmpl	$0x0, (%rax)
    3d54:      	je	0x2477 <perf_unwind_perl+0x2477>
    3d5a:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    3d64:      	movq	%rax, 0x26(%rsp)
    3d69:      	movabsq	$0x30206b6361747320, %rax # imm = 0x30206B6361747320
    3d73:      	movq	%rax, 0x20(%rsp)
    3d78:      	movabsq	$0x747865746e6f6320, %rax # imm = 0x747865746E6F6320
    3d82:      	movq	%rax, 0x18(%rsp)
    3d87:      	movabsq	$0x6d6f726620504f43, %rax # imm = 0x6D6F726620504F43
    3d91:      	movq	%rax, 0x10(%rsp)
    3d96:      	leaq	0x10(%rsp), %rdi
    3d9b:      	movl	$0x1e, %eax
    3da0:      	movl	$0x6, %ecx
    3da5:      	movq	(%r12), %rdx
    3da9:      	movl	$0x1e, %esi
    3dae:      	xorl	%eax, %eax
    3db0:      	callq	*%rcx
    3db2:      	jmp	0x2477 <perf_unwind_perl+0x2477>
    3db7:      	movabsq	$0x7025207461207972, %rax # imm = 0x7025207461207972
    3dc1:      	movq	%rax, 0x30(%rsp)
    3dc6:      	movabsq	$0x746e65206b636174, %rax # imm = 0x746E65206B636174
    3dd0:      	movq	%rax, 0x28(%rsp)
    3dd5:      	movabsq	$0x7320747865746e6f, %rax # imm = 0x7320747865746E6F
    3ddf:      	movq	%rax, 0x20(%rsp)
    3de4:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    3dee:      	movq	%rax, 0x18(%rsp)
    3df3:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3dfd:      	movq	%rax, 0x10(%rsp)
    3e02:      	movw	$0xa, 0x38(%rsp)
    3e09:      	leaq	0x10(%rsp), %rdi
    3e0e:      	movl	$0x2a, %eax
    3e13:      	movl	$0x6, %ecx
    3e18:      	movl	$0x2a, %esi
    3e1d:      	movq	%r13, %rdx
    3e20:      	xorl	%eax, %eax
    3e22:      	callq	*%rcx
    3e24:      	jmp	0xed7 <perf_unwind_perl+0xed7>
    3e29:      	movq	(%rip), %rax            # 0x3e30 <perf_unwind_perl+0x3e30>
    3e30:      	cmpl	$0x0, (%rax)
    3e33:      	jne	0x7712 <perf_unwind_perl+0x7712>
    3e39:      	movzbl	0xe(%rsp), %eax
    3e3e:      	movl	%eax, %ecx
    3e40:      	andl	$0xf, %ecx
    3e43:      	movl	$0x3, %ebp
    3e48:      	leal	-0x9(%rcx), %edx
    3e4b:      	cmpl	$0x2, %edx
    3e4e:      	jae	0x427e <perf_unwind_perl+0x427e>
    3e54:      	testb	%al, %al
    3e56:      	js	0x428e <perf_unwind_perl+0x428e>
    3e5c:      	movzbl	0x1b(%r14), %eax
    3e61:      	addq	%r13, %rax
    3e64:      	leaq	0x10(%rsp), %rdi
    3e69:      	movl	$0x8, %ecx
    3e6e:      	movl	$0x70, %r8d
    3e74:      	movzbl	0x1b(%r14), %edx
    3e79:      	addq	%r13, %rdx
    3e7c:      	movl	$0x8, %esi
    3e81:      	callq	*%r8
    3e84:      	testq	%rax, %rax
    3e87:      	jne	0x3945 <perf_unwind_perl+0x3945>
    3e8d:      	cmpq	$0x0, 0x10(%rsp)
    3e93:      	setne	0xf(%rsp)
    3e98:      	movzbl	0x1c(%r14), %eax
    3e9d:      	addq	%r13, %rax
    3ea0:      	leaq	0xa0(%rsp), %rdi
    3ea8:      	movl	$0x8, %ecx
    3ead:      	movl	$0x70, %r8d
    3eb3:      	movzbl	0x1c(%r14), %edx
    3eb8:      	addq	%r13, %rdx
    3ebb:      	movl	$0x8, %esi
    3ec0:      	callq	*%r8
    3ec3:      	testq	%rax, %rax
    3ec6:      	jne	0x3945 <perf_unwind_perl+0x3945>
    3ecc:      	movq	0xa0(%rsp), %rbp
    3ed4:      	movzbl	0x1e(%r14), %eax
    3ed9:      	addq	%rbp, %rax
    3edc:      	leaq	0x5c(%rsp), %rdi
    3ee1:      	movl	$0x4, %ecx
    3ee6:      	movl	$0x70, %r8d
    3eec:      	movzbl	0x1e(%r14), %edx
    3ef1:      	addq	%rbp, %rdx
    3ef4:      	movl	$0x4, %esi
    3ef9:      	callq	*%r8
    3efc:      	testq	%rax, %rax
    3eff:      	je	0x5fc3 <perf_unwind_perl+0x5fc3>
    3f05:      	movq	(%rip), %rax            # 0x3f0c <perf_unwind_perl+0x3f0c>
    3f0c:      	cmpl	$0x0, (%rax)
    3f0f:      	jne	0x85f2 <perf_unwind_perl+0x85f2>
    3f15:      	movl	$0x14, 0x74(%rsp)
    3f1d:      	movq	(%rip), %rdi            # 0x3f24 <perf_unwind_perl+0x3f24>
    3f24:      	leaq	0x74(%rsp), %rsi
    3f29:      	movl	$0x1, %eax
    3f2e:      	callq	*%rax
    3f30:      	testq	%rax, %rax
    3f33:      	je	0x6504 <perf_unwind_perl+0x6504>
    3f39:      	incq	(%rax)
    3f3c:      	jmp	0x3945 <perf_unwind_perl+0x3945>
    3f41:      	movq	(%rip), %rax            # 0x3f48 <perf_unwind_perl+0x3f48>
    3f48:      	cmpl	$0x0, (%rax)
    3f4b:      	je	0x568 <perf_unwind_perl+0x568>
    3f51:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    3f5b:      	movq	%rax, 0x2e(%rsp)
    3f60:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    3f6a:      	movq	%rax, 0x28(%rsp)
    3f6f:      	movabsq	$0x50472d74756f6874, %rax # imm = 0x50472D74756F6874
    3f79:      	movq	%rax, 0x20(%rsp)
    3f7e:      	movabsq	$0x69772d5647206465, %rax # imm = 0x69772D5647206465
    3f88:      	movq	%rax, 0x18(%rsp)
    3f8d:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    3f97:      	movq	%rax, 0x10(%rsp)
    3f9c:      	leaq	0x10(%rsp), %rdi
    3fa1:      	movl	$0x26, %eax
    3fa6:      	movl	$0x6, %ecx
    3fab:      	movl	0x6c(%rsp), %edx
    3faf:      	movl	$0x26, %esi
    3fb4:      	jmp	0x1ac9 <perf_unwind_perl+0x1ac9>
    3fb9:      	movq	(%rip), %rax            # 0x3fc0 <perf_unwind_perl+0x3fc0>
    3fc0:      	cmpl	$0x0, (%rax)
    3fc3:      	je	0x1b7d <perf_unwind_perl+0x1b7d>
    3fc9:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3fd3:      	movq	%rax, 0x36(%rsp)
    3fd8:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    3fe2:      	movq	%rax, 0x30(%rsp)
    3fe7:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    3ff1:      	movq	%rax, 0x28(%rsp)
    3ff6:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4000:      	movq	%rax, 0x20(%rsp)
    4005:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    400f:      	movq	%rax, 0x18(%rsp)
    4014:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    401e:      	movq	%rax, 0x10(%rsp)
    4023:      	leaq	0x10(%rsp), %rdi
    4028:      	movl	$0x2e, %eax
    402d:      	movl	$0x6, %ecx
    4032:      	movl	0x74(%rsp), %edx
    4036:      	movl	$0x2e, %esi
    403b:      	jmp	0x41b3 <perf_unwind_perl+0x41b3>
    4040:      	movabsq	$0xa642520786978, %rax  # imm = 0xA642520786978
    404a:      	movq	%rax, 0x2e(%rsp)
    404f:      	movabsq	$0x697863202c786c25, %rax # imm = 0x697863202C786C25
    4059:      	movq	%rax, 0x28(%rsp)
    405e:      	movabsq	$0x7830206573616278, %rax # imm = 0x7830206573616278
    4068:      	movq	%rax, 0x20(%rsp)
    406d:      	movabsq	$0x63202c6f666e696b, %rax # imm = 0x63202C6F666E696B
    4077:      	movq	%rax, 0x18(%rsp)
    407c:      	movabsq	$0x636174732077654e, %rax # imm = 0x636174732077654E
    4086:      	movq	%rax, 0x10(%rsp)
    408b:      	leaq	0x10(%rsp), %rdi
    4090:      	movl	$0x26, %eax
    4095:      	movl	$0x6, %r8d
    409b:      	movq	0x50(%rsp), %rdx
    40a0:      	movl	0x78(%rsp), %ecx
    40a4:      	movl	$0x26, %esi
    40a9:      	xorl	%eax, %eax
    40ab:      	callq	*%r8
    40ae:      	jmp	0xf15 <perf_unwind_perl+0xf15>
    40b3:      	movq	(%rip), %rax            # 0x40ba <perf_unwind_perl+0x40ba>
    40ba:      	cmpl	$0x0, (%rax)
    40bd:      	jne	0x77e5 <perf_unwind_perl+0x77e5>
    40c3:      	movl	$0x3, %ebp
    40c8:      	jmp	0x428e <perf_unwind_perl+0x428e>
    40cd:      	movq	(%rip), %rax            # 0x40d4 <perf_unwind_perl+0x40d4>
    40d4:      	cmpl	$0x0, (%rax)
    40d7:      	je	0xec7 <perf_unwind_perl+0xec7>
    40dd:      	movabsq	$0xa782578302f78, %rax  # imm = 0xA782578302F78
    40e7:      	movq	%rax, 0x2e(%rsp)
    40ec:      	movabsq	$0x2f78257830207367, %rax # imm = 0x2F78257830207367
    40f6:      	movq	%rax, 0x28(%rsp)
    40fb:      	movabsq	$0x616c66202c564320, %rax # imm = 0x616C66202C564320
    4105:      	movq	%rax, 0x20(%rsp)
    410a:      	movabsq	$0x44454d414e206465, %rax # imm = 0x44454D414E206465
    4114:      	movq	%rax, 0x18(%rsp)
    4119:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    4123:      	movq	%rax, 0x10(%rsp)
    4128:      	leaq	0x10(%rsp), %rdi
    412d:      	movl	$0x26, %eax
    4132:      	movl	$0x6, %r8d
    4138:      	movl	0x5c(%rsp), %edx
    413c:      	movl	0x70(%rsp), %ecx
    4140:      	movl	$0x26, %esi
    4145:      	xorl	%eax, %eax
    4147:      	callq	*%r8
    414a:      	jmp	0xec7 <perf_unwind_perl+0xec7>
    414f:      	movq	(%rip), %rax            # 0x4156 <perf_unwind_perl+0x4156>
    4156:      	cmpl	$0x0, (%rax)
    4159:      	je	0x1b7d <perf_unwind_perl+0x1b7d>
    415f:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    4169:      	movq	%rax, 0x26(%rsp)
    416e:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    4178:      	movq	%rax, 0x20(%rsp)
    417d:      	movabsq	$0x5643565020612074, %rax # imm = 0x5643565020612074
    4187:      	movq	%rax, 0x18(%rsp)
    418c:      	movabsq	$0x6f6e207369205643, %rax # imm = 0x6F6E207369205643
    4196:      	movq	%rax, 0x10(%rsp)
    419b:      	leaq	0x10(%rsp), %rdi
    41a0:      	movl	$0x1e, %eax
    41a5:      	movl	$0x6, %ecx
    41aa:      	movl	0x5c(%rsp), %edx
    41ae:      	movl	$0x1e, %esi
    41b3:      	xorl	%eax, %eax
    41b5:      	callq	*%rcx
    41b7:      	jmp	0x1b7d <perf_unwind_perl+0x1b7d>
    41bc:      	movabsq	$0x7825783020786320, %rax # imm = 0x7825783020786320
    41c6:      	movq	%rax, 0x18(%rsp)
    41cb:      	movabsq	$0x6c72657020746f47, %rax # imm = 0x6C72657020746F47
    41d5:      	movq	%rax, 0x10(%rsp)
    41da:      	movw	$0xa, 0x20(%rsp)
    41e1:      	leaq	0x10(%rsp), %rdi
    41e6:      	movl	$0x12, %eax
    41eb:      	movl	$0x6, %ecx
    41f0:      	movzbl	0xe(%rsp), %edx
    41f5:      	movl	$0x12, %esi
    41fa:      	xorl	%eax, %eax
    41fc:      	callq	*%rcx
    41fe:      	jmp	0x11df <perf_unwind_perl+0x11df>
    4203:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    420d:      	movq	%rax, 0x36(%rsp)
    4212:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    421c:      	movq	%rax, 0x30(%rsp)
    4221:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    422b:      	movq	%rax, 0x28(%rsp)
    4230:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    423a:      	movq	%rax, 0x20(%rsp)
    423f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4249:      	movq	%rax, 0x18(%rsp)
    424e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4258:      	movq	%rax, 0x10(%rsp)
    425d:      	leaq	0x10(%rsp), %rdi
    4262:      	movl	$0x2e, %eax
    4267:      	movl	$0x6, %ecx
    426c:      	movl	0x50(%rsp), %edx
    4270:      	movl	$0x2e, %esi
    4275:      	xorl	%eax, %eax
    4277:      	callq	*%rcx
    4279:      	jmp	0x142e <perf_unwind_perl+0x142e>
    427e:      	cmpl	$0xc, %ecx
    4281:      	je	0x428e <perf_unwind_perl+0x428e>
    4283:      	cmpq	$0x0, (%r12)
    4288:      	je	0x6266 <perf_unwind_perl+0x6266>
    428e:      	movzbl	0x1d(%r14), %eax
    4293:      	subq	%rax, 0xf50(%r15)
    429a:      	movl	$0x10, 0x50(%rsp)
    42a2:      	movq	(%rip), %rdi            # 0x42a9 <perf_unwind_perl+0x42a9>
    42a9:      	leaq	0x50(%rsp), %rsi
    42ae:      	movl	$0x1, %eax
    42b3:      	callq	*%rax
    42b5:      	testq	%rax, %rax
    42b8:      	je	0x42cf <perf_unwind_perl+0x42cf>
    42ba:      	incq	(%rax)
    42bd:      	cmpl	$0x3, %ebp
    42c0:      	movq	0x98(%rsp), %rcx
    42c8:      	je	0x42f0 <perf_unwind_perl+0x42f0>
    42ca:      	jmp	0x5636 <perf_unwind_perl+0x5636>
    42cf:      	movq	(%rip), %rax            # 0x42d6 <perf_unwind_perl+0x42d6>
    42d6:      	cmpl	$0x0, (%rax)
    42d9:      	jne	0x7759 <perf_unwind_perl+0x7759>
    42df:      	cmpl	$0x3, %ebp
    42e2:      	movq	0x98(%rsp), %rcx
    42ea:      	jne	0x5636 <perf_unwind_perl+0x5636>
    42f0:      	movq	0xf50(%r15), %r13
    42f7:      	cmpq	%rcx, %r13
    42fa:      	jb	0x24e5 <perf_unwind_perl+0x24e5>
    4300:      	movzbl	0x19(%r14), %eax
    4305:      	addq	%r13, %rax
    4308:      	leaq	0xe(%rsp), %rdi
    430d:      	movl	$0x1, %ecx
    4312:      	movl	$0x70, %r8d
    4318:      	movzbl	0x19(%r14), %edx
    431d:      	addq	%r13, %rdx
    4320:      	movl	$0x1, %esi
    4325:      	callq	*%r8
    4328:      	testq	%rax, %rax
    432b:      	je	0x4815 <perf_unwind_perl+0x4815>
    4331:      	movq	(%rip), %rax            # 0x4338 <perf_unwind_perl+0x4338>
    4338:      	cmpl	$0x0, (%rax)
    433b:      	jne	0x7c16 <perf_unwind_perl+0x7c16>
    4341:      	movl	$0x13, 0x50(%rsp)
    4349:      	movq	(%rip), %rdi            # 0x4350 <perf_unwind_perl+0x4350>
    4350:      	leaq	0x50(%rsp), %rsi
    4355:      	movl	$0x1, %eax
    435a:      	callq	*%rax
    435c:      	testq	%rax, %rax
    435f:      	je	0x4a2c <perf_unwind_perl+0x4a2c>
    4365:      	incq	(%rax)
    4368:      	movl	$0x3, %ebp
    436d:      	jmp	0x4c07 <perf_unwind_perl+0x4c07>
    4372:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    437c:      	movq	%rax, 0x36(%rsp)
    4381:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    438b:      	movq	%rax, 0x30(%rsp)
    4390:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    439a:      	movq	%rax, 0x28(%rsp)
    439f:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    43a9:      	movq	%rax, 0x20(%rsp)
    43ae:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    43b8:      	movq	%rax, 0x18(%rsp)
    43bd:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    43c7:      	movq	%rax, 0x10(%rsp)
    43cc:      	leaq	0x10(%rsp), %rdi
    43d1:      	movl	$0x2e, %eax
    43d6:      	movl	$0x6, %ecx
    43db:      	movl	0x50(%rsp), %edx
    43df:      	movl	$0x2e, %esi
    43e4:      	xorl	%eax, %eax
    43e6:      	callq	*%rcx
    43e8:      	jmp	0x137b <perf_unwind_perl+0x137b>
    43ed:      	movabsq	$0xa7667655f7663, %rax  # imm = 0xA7667655F7663
    43f7:      	movq	%rax, 0x35(%rsp)
    43fc:      	movabsq	$0x5f76635f65766c6f, %rax # imm = 0x5F76635F65766C6F
    4406:      	movq	%rax, 0x30(%rsp)
    440b:      	movabsq	$0x736572206e692029, %rax # imm = 0x736572206E692029
    4415:      	movq	%rax, 0x28(%rsp)
    441a:      	movabsq	$0x28726573755f6461, %rax # imm = 0x28726573755F6461
    4424:      	movq	%rax, 0x20(%rsp)
    4429:      	movabsq	$0x65725f65626f7270, %rax # imm = 0x65725F65626F7270
    4433:      	movq	%rax, 0x18(%rsp)
    4438:      	movabsq	$0x5f66706220646142, %rax # imm = 0x5F66706220646142
    4442:      	movq	%rax, 0x10(%rsp)
    4447:      	leaq	0x10(%rsp), %rdi
    444c:      	movl	$0x2d, %eax
    4451:      	movl	$0x6, %ecx
    4456:      	movl	$0x2d, %esi
    445b:      	xorl	%eax, %eax
    445d:      	callq	*%rcx
    445f:      	jmp	0x9bd <perf_unwind_perl+0x9bd>
    4464:      	movl	0x5c(%rsp), %eax
    4468:      	andl	$0x1f, %eax
    446b:      	cmpl	$0xd, %eax
    446e:      	jne	0x4ac8 <perf_unwind_perl+0x4ac8>
    4474:      	movzbl	0x1f(%r14), %eax
    4479:      	addq	%rbp, %rax
    447c:      	leaq	0x50(%rsp), %rdi
    4481:      	movl	$0x8, %ecx
    4486:      	movl	$0x70, %r8d
    448c:      	movzbl	0x1f(%r14), %edx
    4491:      	addq	%rbp, %rdx
    4494:      	movl	$0x8, %esi
    4499:      	callq	*%r8
    449c:      	testq	%rax, %rax
    449f:      	jne	0x2af1 <perf_unwind_perl+0x2af1>
    44a5:      	movzbl	0x21(%r14), %eax
    44aa:      	addq	0x50(%rsp), %rax
    44af:      	leaq	0x70(%rsp), %rdi
    44b4:      	movl	$0x4, %ecx
    44b9:      	movl	$0x70, %r8d
    44bf:      	movzbl	0x21(%r14), %edx
    44c4:      	addq	0x50(%rsp), %rdx
    44c9:      	movl	$0x4, %esi
    44ce:      	callq	*%r8
    44d1:      	testq	%rax, %rax
    44d4:      	jne	0x2af1 <perf_unwind_perl+0x2af1>
    44da:      	testb	$-0x80, 0x71(%rsp)
    44df:      	jne	0x65f2 <perf_unwind_perl+0x65f2>
    44e5:      	movzbl	0x22(%r14), %eax
    44ea:      	addq	0x50(%rsp), %rax
    44ef:      	leaq	0x60(%rsp), %rbp
    44f4:      	movl	$0x8, %ecx
    44f9:      	movl	$0x70, %r8d
    44ff:      	movzbl	0x22(%r14), %edx
    4504:      	addq	0x50(%rsp), %rdx
    4509:      	movq	%rbp, %rdi
    450c:      	movl	$0x8, %esi
    4511:      	callq	*%r8
    4514:      	testq	%rax, %rax
    4517:      	jne	0x2af1 <perf_unwind_perl+0x2af1>
    451d:      	movq	0x60(%rsp), %rax
    4522:      	testq	%rax, %rax
    4525:      	je	0x2af1 <perf_unwind_perl+0x2af1>
    452b:      	movq	(%rip), %rcx            # 0x4532 <perf_unwind_perl+0x4532>
    4532:      	cmpl	$0x0, (%rcx)
    4535:      	jne	0x8ae9 <perf_unwind_perl+0x8ae9>
    453b:      	movzbl	0x1e(%r14), %ecx
    4540:      	addq	%rax, %rcx
    4543:      	leaq	0x6c(%rsp), %rdi
    4548:      	movl	$0x4, %eax
    454d:      	movl	$0x70, %r8d
    4553:      	movzbl	0x1e(%r14), %edx
    4558:      	addq	0x60(%rsp), %rdx
    455d:      	movl	$0x4, %esi
    4562:      	callq	*%r8
    4565:      	testq	%rax, %rax
    4568:      	jne	0x2af1 <perf_unwind_perl+0x2af1>
    456e:      	movl	$0x801f, %eax           # imm = 0x801F
    4573:      	andl	0x6c(%rsp), %eax
    4577:      	cmpl	$0x8009, %eax           # imm = 0x8009
    457c:      	jne	0x74d7 <perf_unwind_perl+0x74d7>
    4582:      	movzbl	0x20(%r14), %eax
    4587:      	addq	0x60(%rsp), %rax
    458c:      	leaq	0x88(%rsp), %rdi
    4594:      	movl	$0x8, %ecx
    4599:      	movl	$0x70, %r8d
    459f:      	movzbl	0x20(%r14), %edx
    45a4:      	addq	0x60(%rsp), %rdx
    45a9:      	movl	$0x8, %esi
    45ae:      	callq	*%r8
    45b1:      	testq	%rax, %rax
    45b4:      	jne	0x2af1 <perf_unwind_perl+0x2af1>
    45ba:      	movzbl	0x23(%r14), %eax
    45bf:      	addq	0x88(%rsp), %rax
    45c7:      	leaq	0x78(%rsp), %rdi
    45cc:      	movl	$0x8, %ecx
    45d1:      	movl	$0x70, %r8d
    45d7:      	movzbl	0x23(%r14), %edx
    45dc:      	addq	0x88(%rsp), %rdx
    45e4:      	movl	$0x8, %esi
    45e9:      	callq	*%r8
    45ec:      	testq	%rax, %rax
    45ef:      	jne	0x2af1 <perf_unwind_perl+0x2af1>
    45f5:      	movq	0x78(%rsp), %rax
    45fa:      	movq	%rax, 0x80(%rsp)
    4602:      	testq	%rax, %rax
    4605:      	je	0x465b <perf_unwind_perl+0x465b>
    4607:      	movq	(%rip), %rax            # 0x460e <perf_unwind_perl+0x460e>
    460e:      	cmpl	$0x0, (%rax)
    4611:      	je	0x4670 <perf_unwind_perl+0x4670>
    4613:      	movabsq	$0x2578302074612056, %rax # imm = 0x2578302074612056
    461d:      	movq	%rax, 0x18(%rsp)
    4622:      	movabsq	$0x474520646e756f46, %rax # imm = 0x474520646E756F46
    462c:      	movq	%rax, 0x10(%rsp)
    4631:      	movl	$0xa786c, 0x20(%rsp)    # imm = 0xA786C
    4639:      	leaq	0x10(%rsp), %rdi
    463e:      	movl	$0x14, %eax
    4643:      	movl	$0x6, %ecx
    4648:      	movq	0x78(%rsp), %rdx
    464d:      	movl	$0x14, %esi
    4652:      	xorl	%eax, %eax
    4654:      	callq	*%rcx
    4656:      	leaq	0x78(%rsp), %rbp
    465b:      	movq	(%rbp), %rax
    465f:      	movq	%rax, 0x80(%rsp)
    4667:      	testq	%rax, %rax
    466a:      	je	0x2528 <perf_unwind_perl+0x2528>
    4670:      	movq	(%r12), %rax
    4674:      	movq	%rax, 0x90(%rsp)
    467c:      	movq	(%rip), %rax            # 0x4683 <perf_unwind_perl+0x4683>
    4683:      	cmpl	$0x0, (%rax)
    4686:      	jne	0x8e4c <perf_unwind_perl+0x8e4c>
    468c:      	movl	0x2c0(%r15), %eax
    4693:      	cmpq	$0x7e, %rax
    4697:      	ja	0x1193 <perf_unwind_perl+0x1193>
    469d:      	xorl	%ecx, %ecx
    469f:      	movzbl	0xf(%rsp), %edx
    46a4:      	movb	%dl, %cl
    46a6:      	leal	0x1(,%rcx,2), %ebp
    46ad:      	leal	0x1(%rax), %ecx
    46b0:      	movl	%ecx, 0x2c0(%r15)
    46b7:      	leaq	(%rax,%rax,2), %rax
    46bb:      	movq	0x80(%rsp), %rcx
    46c3:      	movq	%rcx, 0x2d0(%r15,%rax,8)
    46cb:      	movq	0x90(%rsp), %rcx
    46d3:      	movq	%rcx, 0x2d8(%r15,%rax,8)
    46db:      	movb	$0x7, 0x2e0(%r15,%rax,8)
    46e4:      	movl	$0x0, 0x2e1(%r15,%rax,8)
    46f0:      	movl	$0x0, 0x2e4(%r15,%rax,8)
    46fc:      	movq	$0x0, 0xf40(%r15)
    4707:      	movzbl	0x1a(%r14), %eax
    470c:      	addq	%r13, %rax
    470f:      	movl	$0x8, %ecx
    4714:      	movl	$0x70, %r8d
    471a:      	movzbl	0x1a(%r14), %edx
    471f:      	addq	%r13, %rdx
    4722:      	movq	%r12, %rdi
    4725:      	movl	$0x8, %esi
    472a:      	callq	*%r8
    472d:      	testq	%rax, %rax
    4730:      	jne	0x2528 <perf_unwind_perl+0x2528>
    4736:      	movq	(%rip), %rax            # 0x473d <perf_unwind_perl+0x473d>
    473d:      	cmpl	$0x0, (%rax)
    4740:      	je	0x2d8f <perf_unwind_perl+0x2d8f>
    4746:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    4750:      	movq	%rax, 0x26(%rsp)
    4755:      	movabsq	$0x30206b6361747320, %rax # imm = 0x30206B6361747320
    475f:      	movq	%rax, 0x20(%rsp)
    4764:      	movabsq	$0x747865746e6f6320, %rax # imm = 0x747865746E6F6320
    476e:      	movq	%rax, 0x18(%rsp)
    4773:      	movabsq	$0x6d6f726620504f43, %rax # imm = 0x6D6F726620504F43
    477d:      	movq	%rax, 0x10(%rsp)
    4782:      	leaq	0x10(%rsp), %rdi
    4787:      	movl	$0x1e, %eax
    478c:      	movl	$0x6, %ecx
    4791:      	movq	(%r12), %rdx
    4795:      	movl	$0x1e, %esi
    479a:      	xorl	%eax, %eax
    479c:      	callq	*%rcx
    479e:      	jmp	0x2d8f <perf_unwind_perl+0x2d8f>
    47a3:      	movabsq	$0x7025207461207972, %rax # imm = 0x7025207461207972
    47ad:      	movq	%rax, 0x30(%rsp)
    47b2:      	movabsq	$0x746e65206b636174, %rax # imm = 0x746E65206B636174
    47bc:      	movq	%rax, 0x28(%rsp)
    47c1:      	movabsq	$0x7320747865746e6f, %rax # imm = 0x7320747865746E6F
    47cb:      	movq	%rax, 0x20(%rsp)
    47d0:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    47da:      	movq	%rax, 0x18(%rsp)
    47df:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    47e9:      	movq	%rax, 0x10(%rsp)
    47ee:      	movw	$0xa, 0x38(%rsp)
    47f5:      	leaq	0x10(%rsp), %rdi
    47fa:      	movl	$0x2a, %eax
    47ff:      	movl	$0x6, %ecx
    4804:      	movl	$0x2a, %esi
    4809:      	movq	%r13, %rdx
    480c:      	xorl	%eax, %eax
    480e:      	callq	*%rcx
    4810:      	jmp	0x14aa <perf_unwind_perl+0x14aa>
    4815:      	movq	(%rip), %rax            # 0x481c <perf_unwind_perl+0x481c>
    481c:      	cmpl	$0x0, (%rax)
    481f:      	jne	0x8020 <perf_unwind_perl+0x8020>
    4825:      	movzbl	0xe(%rsp), %eax
    482a:      	movl	%eax, %ecx
    482c:      	andl	$0xf, %ecx
    482f:      	movl	$0x3, %ebp
    4834:      	leal	-0x9(%rcx), %edx
    4837:      	cmpl	$0x2, %edx
    483a:      	jae	0x4bf7 <perf_unwind_perl+0x4bf7>
    4840:      	testb	%al, %al
    4842:      	js	0x4c07 <perf_unwind_perl+0x4c07>
    4848:      	movzbl	0x1b(%r14), %eax
    484d:      	addq	%r13, %rax
    4850:      	leaq	0x10(%rsp), %rdi
    4855:      	movl	$0x8, %ecx
    485a:      	movl	$0x70, %r8d
    4860:      	movzbl	0x1b(%r14), %edx
    4865:      	addq	%r13, %rdx
    4868:      	movl	$0x8, %esi
    486d:      	callq	*%r8
    4870:      	testq	%rax, %rax
    4873:      	jne	0x4331 <perf_unwind_perl+0x4331>
    4879:      	cmpq	$0x0, 0x10(%rsp)
    487f:      	setne	0xf(%rsp)
    4884:      	movzbl	0x1c(%r14), %eax
    4889:      	addq	%r13, %rax
    488c:      	leaq	0xa0(%rsp), %rdi
    4894:      	movl	$0x8, %ecx
    4899:      	movl	$0x70, %r8d
    489f:      	movzbl	0x1c(%r14), %edx
    48a4:      	addq	%r13, %rdx
    48a7:      	movl	$0x8, %esi
    48ac:      	callq	*%r8
    48af:      	testq	%rax, %rax
    48b2:      	jne	0x4331 <perf_unwind_perl+0x4331>
    48b8:      	movq	0xa0(%rsp), %rbp
    48c0:      	movzbl	0x1e(%r14), %eax
    48c5:      	addq	%rbp, %rax
    48c8:      	leaq	0x5c(%rsp), %rdi
    48cd:      	movl	$0x4, %ecx
    48d2:      	movl	$0x70, %r8d
    48d8:      	movzbl	0x1e(%r14), %edx
    48dd:      	addq	%rbp, %rdx
    48e0:      	movl	$0x4, %esi
    48e5:      	callq	*%r8
    48e8:      	testq	%rax, %rax
    48eb:      	je	0x6975 <perf_unwind_perl+0x6975>
    48f1:      	movq	(%rip), %rax            # 0x48f8 <perf_unwind_perl+0x48f8>
    48f8:      	cmpl	$0x0, (%rax)
    48fb:      	jne	0x896f <perf_unwind_perl+0x896f>
    4901:      	movl	$0x14, 0x74(%rsp)
    4909:      	movq	(%rip), %rdi            # 0x4910 <perf_unwind_perl+0x4910>
    4910:      	leaq	0x74(%rsp), %rsi
    4915:      	movl	$0x1, %eax
    491a:      	callq	*%rax
    491c:      	testq	%rax, %rax
    491f:      	je	0x6d9e <perf_unwind_perl+0x6d9e>
    4925:      	incq	(%rax)
    4928:      	jmp	0x4331 <perf_unwind_perl+0x4331>
    492d:      	movq	(%rip), %rax            # 0x4934 <perf_unwind_perl+0x4934>
    4934:      	cmpl	$0x0, (%rax)
    4937:      	je	0xb68 <perf_unwind_perl+0xb68>
    493d:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    4947:      	movq	%rax, 0x2e(%rsp)
    494c:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    4956:      	movq	%rax, 0x28(%rsp)
    495b:      	movabsq	$0x50472d74756f6874, %rax # imm = 0x50472D74756F6874
    4965:      	movq	%rax, 0x20(%rsp)
    496a:      	movabsq	$0x69772d5647206465, %rax # imm = 0x69772D5647206465
    4974:      	movq	%rax, 0x18(%rsp)
    4979:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    4983:      	movq	%rax, 0x10(%rsp)
    4988:      	leaq	0x10(%rsp), %rdi
    498d:      	movl	$0x26, %eax
    4992:      	movl	$0x6, %ecx
    4997:      	movl	0x6c(%rsp), %edx
    499b:      	movl	$0x26, %esi
    49a0:      	jmp	0x239c <perf_unwind_perl+0x239c>
    49a5:      	movq	(%rip), %rax            # 0x49ac <perf_unwind_perl+0x49ac>
    49ac:      	cmpl	$0x0, (%rax)
    49af:      	je	0x2528 <perf_unwind_perl+0x2528>
    49b5:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    49bf:      	movq	%rax, 0x36(%rsp)
    49c4:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    49ce:      	movq	%rax, 0x30(%rsp)
    49d3:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    49dd:      	movq	%rax, 0x28(%rsp)
    49e2:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    49ec:      	movq	%rax, 0x20(%rsp)
    49f1:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    49fb:      	movq	%rax, 0x18(%rsp)
    4a00:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4a0a:      	movq	%rax, 0x10(%rsp)
    4a0f:      	leaq	0x10(%rsp), %rdi
    4a14:      	movl	$0x2e, %eax
    4a19:      	movl	$0x6, %ecx
    4a1e:      	movl	0x74(%rsp), %edx
    4a22:      	movl	$0x2e, %esi
    4a27:      	jmp	0x4b2c <perf_unwind_perl+0x4b2c>
    4a2c:      	movq	(%rip), %rax            # 0x4a33 <perf_unwind_perl+0x4a33>
    4a33:      	cmpl	$0x0, (%rax)
    4a36:      	jne	0x80f3 <perf_unwind_perl+0x80f3>
    4a3c:      	movl	$0x3, %ebp
    4a41:      	jmp	0x4c07 <perf_unwind_perl+0x4c07>
    4a46:      	movq	(%rip), %rax            # 0x4a4d <perf_unwind_perl+0x4a4d>
    4a4d:      	cmpl	$0x0, (%rax)
    4a50:      	je	0x149a <perf_unwind_perl+0x149a>
    4a56:      	movabsq	$0xa782578302f78, %rax  # imm = 0xA782578302F78
    4a60:      	movq	%rax, 0x2e(%rsp)
    4a65:      	movabsq	$0x2f78257830207367, %rax # imm = 0x2F78257830207367
    4a6f:      	movq	%rax, 0x28(%rsp)
    4a74:      	movabsq	$0x616c66202c564320, %rax # imm = 0x616C66202C564320
    4a7e:      	movq	%rax, 0x20(%rsp)
    4a83:      	movabsq	$0x44454d414e206465, %rax # imm = 0x44454D414E206465
    4a8d:      	movq	%rax, 0x18(%rsp)
    4a92:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    4a9c:      	movq	%rax, 0x10(%rsp)
    4aa1:      	leaq	0x10(%rsp), %rdi
    4aa6:      	movl	$0x26, %eax
    4aab:      	movl	$0x6, %r8d
    4ab1:      	movl	0x5c(%rsp), %edx
    4ab5:      	movl	0x70(%rsp), %ecx
    4ab9:      	movl	$0x26, %esi
    4abe:      	xorl	%eax, %eax
    4ac0:      	callq	*%r8
    4ac3:      	jmp	0x149a <perf_unwind_perl+0x149a>
    4ac8:      	movq	(%rip), %rax            # 0x4acf <perf_unwind_perl+0x4acf>
    4acf:      	cmpl	$0x0, (%rax)
    4ad2:      	je	0x2528 <perf_unwind_perl+0x2528>
    4ad8:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    4ae2:      	movq	%rax, 0x26(%rsp)
    4ae7:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    4af1:      	movq	%rax, 0x20(%rsp)
    4af6:      	movabsq	$0x5643565020612074, %rax # imm = 0x5643565020612074
    4b00:      	movq	%rax, 0x18(%rsp)
    4b05:      	movabsq	$0x6f6e207369205643, %rax # imm = 0x6F6E207369205643
    4b0f:      	movq	%rax, 0x10(%rsp)
    4b14:      	leaq	0x10(%rsp), %rdi
    4b19:      	movl	$0x1e, %eax
    4b1e:      	movl	$0x6, %ecx
    4b23:      	movl	0x5c(%rsp), %edx
    4b27:      	movl	$0x1e, %esi
    4b2c:      	xorl	%eax, %eax
    4b2e:      	callq	*%rcx
    4b30:      	jmp	0x2528 <perf_unwind_perl+0x2528>
    4b35:      	movabsq	$0x7825783020786320, %rax # imm = 0x7825783020786320
    4b3f:      	movq	%rax, 0x18(%rsp)
    4b44:      	movabsq	$0x6c72657020746f47, %rax # imm = 0x6C72657020746F47
    4b4e:      	movq	%rax, 0x10(%rsp)
    4b53:      	movw	$0xa, 0x20(%rsp)
    4b5a:      	leaq	0x10(%rsp), %rdi
    4b5f:      	movl	$0x12, %eax
    4b64:      	movl	$0x6, %ecx
    4b69:      	movzbl	0xe(%rsp), %edx
    4b6e:      	movl	$0x12, %esi
    4b73:      	xorl	%eax, %eax
    4b75:      	callq	*%rcx
    4b77:      	jmp	0x18c2 <perf_unwind_perl+0x18c2>
    4b7c:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4b86:      	movq	%rax, 0x36(%rsp)
    4b8b:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4b95:      	movq	%rax, 0x30(%rsp)
    4b9a:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4ba4:      	movq	%rax, 0x28(%rsp)
    4ba9:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4bb3:      	movq	%rax, 0x20(%rsp)
    4bb8:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4bc2:      	movq	%rax, 0x18(%rsp)
    4bc7:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4bd1:      	movq	%rax, 0x10(%rsp)
    4bd6:      	leaq	0x10(%rsp), %rdi
    4bdb:      	movl	$0x2e, %eax
    4be0:      	movl	$0x6, %ecx
    4be5:      	movl	0x50(%rsp), %edx
    4be9:      	movl	$0x2e, %esi
    4bee:      	xorl	%eax, %eax
    4bf0:      	callq	*%rcx
    4bf2:      	jmp	0x1b11 <perf_unwind_perl+0x1b11>
    4bf7:      	cmpl	$0xc, %ecx
    4bfa:      	je	0x4c07 <perf_unwind_perl+0x4c07>
    4bfc:      	cmpq	$0x0, (%r12)
    4c01:      	je	0x6c18 <perf_unwind_perl+0x6c18>
    4c07:      	movzbl	0x1d(%r14), %eax
    4c0c:      	subq	%rax, 0xf50(%r15)
    4c13:      	movl	$0x10, 0x50(%rsp)
    4c1b:      	movq	(%rip), %rdi            # 0x4c22 <perf_unwind_perl+0x4c22>
    4c22:      	leaq	0x50(%rsp), %rsi
    4c27:      	movl	$0x1, %eax
    4c2c:      	callq	*%rax
    4c2e:      	testq	%rax, %rax
    4c31:      	je	0x4c48 <perf_unwind_perl+0x4c48>
    4c33:      	incq	(%rax)
    4c36:      	cmpl	$0x3, %ebp
    4c39:      	movq	0x98(%rsp), %rcx
    4c41:      	je	0x4c69 <perf_unwind_perl+0x4c69>
    4c43:      	jmp	0x5636 <perf_unwind_perl+0x5636>
    4c48:      	movq	(%rip), %rax            # 0x4c4f <perf_unwind_perl+0x4c4f>
    4c4f:      	cmpl	$0x0, (%rax)
    4c52:      	jne	0x8067 <perf_unwind_perl+0x8067>
    4c58:      	cmpl	$0x3, %ebp
    4c5b:      	movq	0x98(%rsp), %rcx
    4c63:      	jne	0x5636 <perf_unwind_perl+0x5636>
    4c69:      	movq	0xf50(%r15), %r13
    4c70:      	cmpq	%rcx, %r13
    4c73:      	jb	0x24e5 <perf_unwind_perl+0x24e5>
    4c79:      	movzbl	0x19(%r14), %eax
    4c7e:      	addq	%r13, %rax
    4c81:      	leaq	0xe(%rsp), %rdi
    4c86:      	movl	$0x1, %ecx
    4c8b:      	movl	$0x70, %r8d
    4c91:      	movzbl	0x19(%r14), %edx
    4c96:      	addq	%r13, %rdx
    4c99:      	movl	$0x1, %esi
    4c9e:      	callq	*%r8
    4ca1:      	testq	%rax, %rax
    4ca4:      	je	0x51c3 <perf_unwind_perl+0x51c3>
    4caa:      	movq	(%rip), %rax            # 0x4cb1 <perf_unwind_perl+0x4cb1>
    4cb1:      	cmpl	$0x0, (%rax)
    4cb4:      	jne	0x81e5 <perf_unwind_perl+0x81e5>
    4cba:      	movl	$0x13, 0x50(%rsp)
    4cc2:      	movq	(%rip), %rdi            # 0x4cc9 <perf_unwind_perl+0x4cc9>
    4cc9:      	leaq	0x50(%rsp), %rsi
    4cce:      	movl	$0x1, %eax
    4cd3:      	callq	*%rax
    4cd5:      	testq	%rax, %rax
    4cd8:      	je	0x53da <perf_unwind_perl+0x53da>
    4cde:      	incq	(%rax)
    4ce1:      	movl	$0x3, %ebp
    4ce6:      	jmp	0x55c6 <perf_unwind_perl+0x55c6>
    4ceb:      	movq	(%rip), %rax            # 0x4cf2 <perf_unwind_perl+0x4cf2>
    4cf2:      	cmpl	$0x0, (%rax)
    4cf5:      	jne	0x82cf <perf_unwind_perl+0x82cf>
    4cfb:      	movzbl	0x1d(%r14), %ecx
    4d00:      	movq	0xf50(%r15), %rax
    4d07:      	subq	%rcx, %rax
    4d0a:      	movq	%rax, 0xf50(%r15)
    4d11:      	xorl	%ebp, %ebp
    4d13:      	movq	0x98(%rsp), %rcx
    4d1b:      	jmp	0x563d <perf_unwind_perl+0x563d>
    4d20:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4d2a:      	movq	%rax, 0x36(%rsp)
    4d2f:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4d39:      	movq	%rax, 0x30(%rsp)
    4d3e:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4d48:      	movq	%rax, 0x28(%rsp)
    4d4d:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4d57:      	movq	%rax, 0x20(%rsp)
    4d5c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4d66:      	movq	%rax, 0x18(%rsp)
    4d6b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4d75:      	movq	%rax, 0x10(%rsp)
    4d7a:      	leaq	0x10(%rsp), %rdi
    4d7f:      	movl	$0x2e, %eax
    4d84:      	movl	$0x6, %ecx
    4d89:      	movl	0x50(%rsp), %edx
    4d8d:      	movl	$0x2e, %esi
    4d92:      	xorl	%eax, %eax
    4d94:      	callq	*%rcx
    4d96:      	jmp	0x1a5e <perf_unwind_perl+0x1a5e>
    4d9b:      	movabsq	$0xa7667655f7663, %rax  # imm = 0xA7667655F7663
    4da5:      	movq	%rax, 0x35(%rsp)
    4daa:      	movabsq	$0x5f76635f65766c6f, %rax # imm = 0x5F76635F65766C6F
    4db4:      	movq	%rax, 0x30(%rsp)
    4db9:      	movabsq	$0x736572206e692029, %rax # imm = 0x736572206E692029
    4dc3:      	movq	%rax, 0x28(%rsp)
    4dc8:      	movabsq	$0x28726573755f6461, %rax # imm = 0x28726573755F6461
    4dd2:      	movq	%rax, 0x20(%rsp)
    4dd7:      	movabsq	$0x65725f65626f7270, %rax # imm = 0x65725F65626F7270
    4de1:      	movq	%rax, 0x18(%rsp)
    4de6:      	movabsq	$0x5f66706220646142, %rax # imm = 0x5F66706220646142
    4df0:      	movq	%rax, 0x10(%rsp)
    4df5:      	leaq	0x10(%rsp), %rdi
    4dfa:      	movl	$0x2d, %eax
    4dff:      	movl	$0x6, %ecx
    4e04:      	movl	$0x2d, %esi
    4e09:      	xorl	%eax, %eax
    4e0b:      	callq	*%rcx
    4e0d:      	jmp	0xd4e <perf_unwind_perl+0xd4e>
    4e12:      	movl	0x5c(%rsp), %eax
    4e16:      	andl	$0x1f, %eax
    4e19:      	cmpl	$0xd, %eax
    4e1c:      	jne	0x5476 <perf_unwind_perl+0x5476>
    4e22:      	movzbl	0x1f(%r14), %eax
    4e27:      	addq	%rbp, %rax
    4e2a:      	leaq	0x50(%rsp), %rdi
    4e2f:      	movl	$0x8, %ecx
    4e34:      	movl	$0x70, %r8d
    4e3a:      	movzbl	0x1f(%r14), %edx
    4e3f:      	addq	%rbp, %rdx
    4e42:      	movl	$0x8, %esi
    4e47:      	callq	*%r8
    4e4a:      	testq	%rax, %rax
    4e4d:      	jne	0x3511 <perf_unwind_perl+0x3511>
    4e53:      	movzbl	0x21(%r14), %eax
    4e58:      	addq	0x50(%rsp), %rax
    4e5d:      	leaq	0x70(%rsp), %rdi
    4e62:      	movl	$0x4, %ecx
    4e67:      	movl	$0x70, %r8d
    4e6d:      	movzbl	0x21(%r14), %edx
    4e72:      	addq	0x50(%rsp), %rdx
    4e77:      	movl	$0x4, %esi
    4e7c:      	callq	*%r8
    4e7f:      	testq	%rax, %rax
    4e82:      	jne	0x3511 <perf_unwind_perl+0x3511>
    4e88:      	testb	$-0x80, 0x71(%rsp)
    4e8d:      	jne	0x6e72 <perf_unwind_perl+0x6e72>
    4e93:      	movzbl	0x22(%r14), %eax
    4e98:      	addq	0x50(%rsp), %rax
    4e9d:      	leaq	0x60(%rsp), %rbp
    4ea2:      	movl	$0x8, %ecx
    4ea7:      	movl	$0x70, %r8d
    4ead:      	movzbl	0x22(%r14), %edx
    4eb2:      	addq	0x50(%rsp), %rdx
    4eb7:      	movq	%rbp, %rdi
    4eba:      	movl	$0x8, %esi
    4ebf:      	callq	*%r8
    4ec2:      	testq	%rax, %rax
    4ec5:      	jne	0x3511 <perf_unwind_perl+0x3511>
    4ecb:      	movq	0x60(%rsp), %rax
    4ed0:      	testq	%rax, %rax
    4ed3:      	je	0x3511 <perf_unwind_perl+0x3511>
    4ed9:      	movq	(%rip), %rcx            # 0x4ee0 <perf_unwind_perl+0x4ee0>
    4ee0:      	cmpl	$0x0, (%rcx)
    4ee3:      	jne	0x8cb0 <perf_unwind_perl+0x8cb0>
    4ee9:      	movzbl	0x1e(%r14), %ecx
    4eee:      	addq	%rax, %rcx
    4ef1:      	leaq	0x6c(%rsp), %rdi
    4ef6:      	movl	$0x4, %eax
    4efb:      	movl	$0x70, %r8d
    4f01:      	movzbl	0x1e(%r14), %edx
    4f06:      	addq	0x60(%rsp), %rdx
    4f0b:      	movl	$0x4, %esi
    4f10:      	callq	*%r8
    4f13:      	testq	%rax, %rax
    4f16:      	jne	0x3511 <perf_unwind_perl+0x3511>
    4f1c:      	movl	$0x801f, %eax           # imm = 0x801F
    4f21:      	andl	0x6c(%rsp), %eax
    4f25:      	cmpl	$0x8009, %eax           # imm = 0x8009
    4f2a:      	jne	0x7c88 <perf_unwind_perl+0x7c88>
    4f30:      	movzbl	0x20(%r14), %eax
    4f35:      	addq	0x60(%rsp), %rax
    4f3a:      	leaq	0x88(%rsp), %rdi
    4f42:      	movl	$0x8, %ecx
    4f47:      	movl	$0x70, %r8d
    4f4d:      	movzbl	0x20(%r14), %edx
    4f52:      	addq	0x60(%rsp), %rdx
    4f57:      	movl	$0x8, %esi
    4f5c:      	callq	*%r8
    4f5f:      	testq	%rax, %rax
    4f62:      	jne	0x3511 <perf_unwind_perl+0x3511>
    4f68:      	movzbl	0x23(%r14), %eax
    4f6d:      	addq	0x88(%rsp), %rax
    4f75:      	leaq	0x78(%rsp), %rdi
    4f7a:      	movl	$0x8, %ecx
    4f7f:      	movl	$0x70, %r8d
    4f85:      	movzbl	0x23(%r14), %edx
    4f8a:      	addq	0x88(%rsp), %rdx
    4f92:      	movl	$0x8, %esi
    4f97:      	callq	*%r8
    4f9a:      	testq	%rax, %rax
    4f9d:      	jne	0x3511 <perf_unwind_perl+0x3511>
    4fa3:      	movq	0x78(%rsp), %rax
    4fa8:      	movq	%rax, 0x80(%rsp)
    4fb0:      	testq	%rax, %rax
    4fb3:      	je	0x5009 <perf_unwind_perl+0x5009>
    4fb5:      	movq	(%rip), %rax            # 0x4fbc <perf_unwind_perl+0x4fbc>
    4fbc:      	cmpl	$0x0, (%rax)
    4fbf:      	je	0x501e <perf_unwind_perl+0x501e>
    4fc1:      	movabsq	$0x2578302074612056, %rax # imm = 0x2578302074612056
    4fcb:      	movq	%rax, 0x18(%rsp)
    4fd0:      	movabsq	$0x474520646e756f46, %rax # imm = 0x474520646E756F46
    4fda:      	movq	%rax, 0x10(%rsp)
    4fdf:      	movl	$0xa786c, 0x20(%rsp)    # imm = 0xA786C
    4fe7:      	leaq	0x10(%rsp), %rdi
    4fec:      	movl	$0x14, %eax
    4ff1:      	movl	$0x6, %ecx
    4ff6:      	movq	0x78(%rsp), %rdx
    4ffb:      	movl	$0x14, %esi
    5000:      	xorl	%eax, %eax
    5002:      	callq	*%rcx
    5004:      	leaq	0x78(%rsp), %rbp
    5009:      	movq	(%rbp), %rax
    500d:      	movq	%rax, 0x80(%rsp)
    5015:      	testq	%rax, %rax
    5018:      	je	0x2e32 <perf_unwind_perl+0x2e32>
    501e:      	movq	(%r12), %rax
    5022:      	movq	%rax, 0x90(%rsp)
    502a:      	movq	(%rip), %rax            # 0x5031 <perf_unwind_perl+0x5031>
    5031:      	cmpl	$0x0, (%rax)
    5034:      	jne	0x8f24 <perf_unwind_perl+0x8f24>
    503a:      	movl	0x2c0(%r15), %eax
    5041:      	cmpq	$0x7e, %rax
    5045:      	ja	0x1193 <perf_unwind_perl+0x1193>
    504b:      	xorl	%ecx, %ecx
    504d:      	movzbl	0xf(%rsp), %edx
    5052:      	movb	%dl, %cl
    5054:      	leal	0x1(,%rcx,2), %ebp
    505b:      	leal	0x1(%rax), %ecx
    505e:      	movl	%ecx, 0x2c0(%r15)
    5065:      	leaq	(%rax,%rax,2), %rax
    5069:      	movq	0x80(%rsp), %rcx
    5071:      	movq	%rcx, 0x2d0(%r15,%rax,8)
    5079:      	movq	0x90(%rsp), %rcx
    5081:      	movq	%rcx, 0x2d8(%r15,%rax,8)
    5089:      	movb	$0x7, 0x2e0(%r15,%rax,8)
    5092:      	movl	$0x0, 0x2e1(%r15,%rax,8)
    509e:      	movl	$0x0, 0x2e4(%r15,%rax,8)
    50aa:      	movq	$0x0, 0xf40(%r15)
    50b5:      	movzbl	0x1a(%r14), %eax
    50ba:      	addq	%r13, %rax
    50bd:      	movl	$0x8, %ecx
    50c2:      	movl	$0x70, %r8d
    50c8:      	movzbl	0x1a(%r14), %edx
    50cd:      	addq	%r13, %rdx
    50d0:      	movq	%r12, %rdi
    50d3:      	movl	$0x8, %esi
    50d8:      	callq	*%r8
    50db:      	testq	%rax, %rax
    50de:      	jne	0x2e32 <perf_unwind_perl+0x2e32>
    50e4:      	movq	(%rip), %rax            # 0x50eb <perf_unwind_perl+0x50eb>
    50eb:      	cmpl	$0x0, (%rax)
    50ee:      	je	0x38a2 <perf_unwind_perl+0x38a2>
    50f4:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    50fe:      	movq	%rax, 0x26(%rsp)
    5103:      	movabsq	$0x30206b6361747320, %rax # imm = 0x30206B6361747320
    510d:      	movq	%rax, 0x20(%rsp)
    5112:      	movabsq	$0x747865746e6f6320, %rax # imm = 0x747865746E6F6320
    511c:      	movq	%rax, 0x18(%rsp)
    5121:      	movabsq	$0x6d6f726620504f43, %rax # imm = 0x6D6F726620504F43
    512b:      	movq	%rax, 0x10(%rsp)
    5130:      	leaq	0x10(%rsp), %rdi
    5135:      	movl	$0x1e, %eax
    513a:      	movl	$0x6, %ecx
    513f:      	movq	(%r12), %rdx
    5143:      	movl	$0x1e, %esi
    5148:      	xorl	%eax, %eax
    514a:      	callq	*%rcx
    514c:      	jmp	0x38a2 <perf_unwind_perl+0x38a2>
    5151:      	movabsq	$0x7025207461207972, %rax # imm = 0x7025207461207972
    515b:      	movq	%rax, 0x30(%rsp)
    5160:      	movabsq	$0x746e65206b636174, %rax # imm = 0x746E65206B636174
    516a:      	movq	%rax, 0x28(%rsp)
    516f:      	movabsq	$0x7320747865746e6f, %rax # imm = 0x7320747865746E6F
    5179:      	movq	%rax, 0x20(%rsp)
    517e:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    5188:      	movq	%rax, 0x18(%rsp)
    518d:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5197:      	movq	%rax, 0x10(%rsp)
    519c:      	movw	$0xa, 0x38(%rsp)
    51a3:      	leaq	0x10(%rsp), %rdi
    51a8:      	movl	$0x2a, %eax
    51ad:      	movl	$0x6, %ecx
    51b2:      	movl	$0x2a, %esi
    51b7:      	movq	%r13, %rdx
    51ba:      	xorl	%eax, %eax
    51bc:      	callq	*%rcx
    51be:      	jmp	0x1b8d <perf_unwind_perl+0x1b8d>
    51c3:      	movq	(%rip), %rax            # 0x51ca <perf_unwind_perl+0x51ca>
    51ca:      	cmpl	$0x0, (%rax)
    51cd:      	jne	0x84a4 <perf_unwind_perl+0x84a4>
    51d3:      	movzbl	0xe(%rsp), %eax
    51d8:      	movl	%eax, %ecx
    51da:      	andl	$0xf, %ecx
    51dd:      	movl	$0x3, %ebp
    51e2:      	leal	-0x9(%rcx), %edx
    51e5:      	cmpl	$0x2, %edx
    51e8:      	jae	0x55b6 <perf_unwind_perl+0x55b6>
    51ee:      	testb	%al, %al
    51f0:      	js	0x55c6 <perf_unwind_perl+0x55c6>
    51f6:      	movzbl	0x1b(%r14), %eax
    51fb:      	addq	%r13, %rax
    51fe:      	leaq	0x10(%rsp), %rdi
    5203:      	movl	$0x8, %ecx
    5208:      	movl	$0x70, %r8d
    520e:      	movzbl	0x1b(%r14), %edx
    5213:      	addq	%r13, %rdx
    5216:      	movl	$0x8, %esi
    521b:      	callq	*%r8
    521e:      	testq	%rax, %rax
    5221:      	jne	0x4caa <perf_unwind_perl+0x4caa>
    5227:      	cmpq	$0x0, 0x10(%rsp)
    522d:      	setne	0xf(%rsp)
    5232:      	movzbl	0x1c(%r14), %eax
    5237:      	addq	%r13, %rax
    523a:      	leaq	0xa0(%rsp), %rdi
    5242:      	movl	$0x8, %ecx
    5247:      	movl	$0x70, %r8d
    524d:      	movzbl	0x1c(%r14), %edx
    5252:      	addq	%r13, %rdx
    5255:      	movl	$0x8, %esi
    525a:      	callq	*%r8
    525d:      	testq	%rax, %rax
    5260:      	jne	0x4caa <perf_unwind_perl+0x4caa>
    5266:      	movq	0xa0(%rsp), %rbp
    526e:      	movzbl	0x1e(%r14), %eax
    5273:      	addq	%rbp, %rax
    5276:      	leaq	0x5c(%rsp), %rdi
    527b:      	movl	$0x4, %ecx
    5280:      	movl	$0x70, %r8d
    5286:      	movzbl	0x1e(%r14), %edx
    528b:      	addq	%rbp, %rdx
    528e:      	movl	$0x4, %esi
    5293:      	callq	*%r8
    5296:      	testq	%rax, %rax
    5299:      	je	0x7126 <perf_unwind_perl+0x7126>
    529f:      	movq	(%rip), %rax            # 0x52a6 <perf_unwind_perl+0x52a6>
    52a6:      	cmpl	$0x0, (%rax)
    52a9:      	jne	0x8b36 <perf_unwind_perl+0x8b36>
    52af:      	movl	$0x14, 0x74(%rsp)
    52b7:      	movq	(%rip), %rdi            # 0x52be <perf_unwind_perl+0x52be>
    52be:      	leaq	0x74(%rsp), %rsi
    52c3:      	movl	$0x1, %eax
    52c8:      	callq	*%rax
    52ca:      	testq	%rax, %rax
    52cd:      	je	0x754f <perf_unwind_perl+0x754f>
    52d3:      	incq	(%rax)
    52d6:      	jmp	0x4caa <perf_unwind_perl+0x4caa>
    52db:      	movq	(%rip), %rax            # 0x52e2 <perf_unwind_perl+0x52e2>
    52e2:      	cmpl	$0x0, (%rax)
    52e5:      	je	0xec7 <perf_unwind_perl+0xec7>
    52eb:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    52f5:      	movq	%rax, 0x2e(%rsp)
    52fa:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    5304:      	movq	%rax, 0x28(%rsp)
    5309:      	movabsq	$0x50472d74756f6874, %rax # imm = 0x50472D74756F6874
    5313:      	movq	%rax, 0x20(%rsp)
    5318:      	movabsq	$0x69772d5647206465, %rax # imm = 0x69772D5647206465
    5322:      	movq	%rax, 0x18(%rsp)
    5327:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    5331:      	movq	%rax, 0x10(%rsp)
    5336:      	leaq	0x10(%rsp), %rdi
    533b:      	movl	$0x26, %eax
    5340:      	movl	$0x6, %ecx
    5345:      	movl	0x6c(%rsp), %edx
    5349:      	movl	$0x26, %esi
    534e:      	jmp	0x2cb4 <perf_unwind_perl+0x2cb4>
    5353:      	movq	(%rip), %rax            # 0x535a <perf_unwind_perl+0x535a>
    535a:      	cmpl	$0x0, (%rax)
    535d:      	je	0x2e32 <perf_unwind_perl+0x2e32>
    5363:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    536d:      	movq	%rax, 0x36(%rsp)
    5372:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    537c:      	movq	%rax, 0x30(%rsp)
    5381:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    538b:      	movq	%rax, 0x28(%rsp)
    5390:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    539a:      	movq	%rax, 0x20(%rsp)
    539f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    53a9:      	movq	%rax, 0x18(%rsp)
    53ae:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    53b8:      	movq	%rax, 0x10(%rsp)
    53bd:      	leaq	0x10(%rsp), %rdi
    53c2:      	movl	$0x2e, %eax
    53c7:      	movl	$0x6, %ecx
    53cc:      	movl	0x74(%rsp), %edx
    53d0:      	movl	$0x2e, %esi
    53d5:      	jmp	0x54da <perf_unwind_perl+0x54da>
    53da:      	movq	(%rip), %rax            # 0x53e1 <perf_unwind_perl+0x53e1>
    53e1:      	cmpl	$0x0, (%rax)
    53e4:      	jne	0x8577 <perf_unwind_perl+0x8577>
    53ea:      	movl	$0x3, %ebp
    53ef:      	jmp	0x55c6 <perf_unwind_perl+0x55c6>
    53f4:      	movq	(%rip), %rax            # 0x53fb <perf_unwind_perl+0x53fb>
    53fb:      	cmpl	$0x0, (%rax)
    53fe:      	je	0x1b7d <perf_unwind_perl+0x1b7d>
    5404:      	movabsq	$0xa782578302f78, %rax  # imm = 0xA782578302F78
    540e:      	movq	%rax, 0x2e(%rsp)
    5413:      	movabsq	$0x2f78257830207367, %rax # imm = 0x2F78257830207367
    541d:      	movq	%rax, 0x28(%rsp)
    5422:      	movabsq	$0x616c66202c564320, %rax # imm = 0x616C66202C564320
    542c:      	movq	%rax, 0x20(%rsp)
    5431:      	movabsq	$0x44454d414e206465, %rax # imm = 0x44454D414E206465
    543b:      	movq	%rax, 0x18(%rsp)
    5440:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    544a:      	movq	%rax, 0x10(%rsp)
    544f:      	leaq	0x10(%rsp), %rdi
    5454:      	movl	$0x26, %eax
    5459:      	movl	$0x6, %r8d
    545f:      	movl	0x5c(%rsp), %edx
    5463:      	movl	0x70(%rsp), %ecx
    5467:      	movl	$0x26, %esi
    546c:      	xorl	%eax, %eax
    546e:      	callq	*%r8
    5471:      	jmp	0x1b7d <perf_unwind_perl+0x1b7d>
    5476:      	movq	(%rip), %rax            # 0x547d <perf_unwind_perl+0x547d>
    547d:      	cmpl	$0x0, (%rax)
    5480:      	je	0x2e32 <perf_unwind_perl+0x2e32>
    5486:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    5490:      	movq	%rax, 0x26(%rsp)
    5495:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    549f:      	movq	%rax, 0x20(%rsp)
    54a4:      	movabsq	$0x5643565020612074, %rax # imm = 0x5643565020612074
    54ae:      	movq	%rax, 0x18(%rsp)
    54b3:      	movabsq	$0x6f6e207369205643, %rax # imm = 0x6F6E207369205643
    54bd:      	movq	%rax, 0x10(%rsp)
    54c2:      	leaq	0x10(%rsp), %rdi
    54c7:      	movl	$0x1e, %eax
    54cc:      	movl	$0x6, %ecx
    54d1:      	movl	0x5c(%rsp), %edx
    54d5:      	movl	$0x1e, %esi
    54da:      	xorl	%eax, %eax
    54dc:      	callq	*%rcx
    54de:      	jmp	0x2e32 <perf_unwind_perl+0x2e32>
    54e3:      	movabsq	$0x7825783020786320, %rax # imm = 0x7825783020786320
    54ed:      	movq	%rax, 0x18(%rsp)
    54f2:      	movabsq	$0x6c72657020746f47, %rax # imm = 0x6C72657020746F47
    54fc:      	movq	%rax, 0x10(%rsp)
    5501:      	movw	$0xa, 0x20(%rsp)
    5508:      	leaq	0x10(%rsp), %rdi
    550d:      	movl	$0x12, %eax
    5512:      	movl	$0x6, %ecx
    5517:      	movzbl	0xe(%rsp), %edx
    551c:      	movl	$0x12, %esi
    5521:      	xorl	%eax, %eax
    5523:      	callq	*%rcx
    5525:      	jmp	0x1f7f <perf_unwind_perl+0x1f7f>
    552a:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    5534:      	movq	%rax, 0x36(%rsp)
    5539:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    5543:      	movq	%rax, 0x30(%rsp)
    5548:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    5552:      	movq	%rax, 0x28(%rsp)
    5557:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    5561:      	movq	%rax, 0x20(%rsp)
    5566:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    5570:      	movq	%rax, 0x18(%rsp)
    5575:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    557f:      	movq	%rax, 0x10(%rsp)
    5584:      	leaq	0x10(%rsp), %rdi
    5589:      	movl	$0x2e, %eax
    558e:      	movl	$0x6, %ecx
    5593:      	movl	0x50(%rsp), %edx
    5597:      	movl	$0x2e, %esi
    559c:      	xorl	%eax, %eax
    559e:      	callq	*%rcx
    55a0:      	cmpl	$0x3, %ebp
    55a3:      	movq	0x98(%rsp), %rcx
    55ab:      	je	0x24d9 <perf_unwind_perl+0x24d9>
    55b1:      	jmp	0x5636 <perf_unwind_perl+0x5636>
    55b6:      	cmpl	$0xc, %ecx
    55b9:      	je	0x55c6 <perf_unwind_perl+0x55c6>
    55bb:      	cmpq	$0x0, (%r12)
    55c0:      	je	0x73c9 <perf_unwind_perl+0x73c9>
    55c6:      	movzbl	0x1d(%r14), %eax
    55cb:      	subq	%rax, 0xf50(%r15)
    55d2:      	movl	$0x10, 0x50(%rsp)
    55da:      	movq	(%rip), %rdi            # 0x55e1 <perf_unwind_perl+0x55e1>
    55e1:      	leaq	0x50(%rsp), %rsi
    55e6:      	movl	$0x1, %eax
    55eb:      	callq	*%rax
    55ed:      	testq	%rax, %rax
    55f0:      	je	0x5604 <perf_unwind_perl+0x5604>
    55f2:      	incq	(%rax)
    55f5:      	cmpl	$0x3, %ebp
    55f8:      	movq	0x98(%rsp), %rcx
    5600:      	je	0x5621 <perf_unwind_perl+0x5621>
    5602:      	jmp	0x5636 <perf_unwind_perl+0x5636>
    5604:      	movq	(%rip), %rax            # 0x560b <perf_unwind_perl+0x560b>
    560b:      	cmpl	$0x0, (%rax)
    560e:      	jne	0x84eb <perf_unwind_perl+0x84eb>
    5614:      	cmpl	$0x3, %ebp
    5617:      	movq	0x98(%rsp), %rcx
    561f:      	jne	0x5636 <perf_unwind_perl+0x5636>
    5621:      	movq	0xf50(%r15), %r13
    5628:      	movl	$0x3, %ebp
    562d:      	cmpq	%rcx, %r13
    5630:      	jae	0x5e5f <perf_unwind_perl+0x5e5f>
    5636:      	movq	0xf50(%r15), %rax
    563d:      	cmpq	%rcx, %rax
    5640:      	movq	(%rip), %r13            # 0x5647 <perf_unwind_perl+0x5647>
    5647:      	jae	0x585f <perf_unwind_perl+0x585f>
    564d:      	movq	(%r12), %r12
    5651:      	testq	%r12, %r12
    5654:      	je	0x56f7 <perf_unwind_perl+0x56f7>
    565a:      	cmpl	$0x0, (%r13)
    565f:      	jne	0x5a96 <perf_unwind_perl+0x5a96>
    5665:      	movl	0x2c0(%r15), %eax
    566c:      	cmpq	$0x7f, %rax
    5670:      	jb	0x56a9 <perf_unwind_perl+0x56a9>
    5672:      	cmpl	$0x0, (%r13)
    5677:      	jne	0x5c3b <perf_unwind_perl+0x5c3b>
    567d:      	movl	$0x2, 0x50(%rsp)
    5685:      	movq	(%rip), %rdi            # 0x568c <perf_unwind_perl+0x568c>
    568c:      	leaq	0x50(%rsp), %rsi
    5691:      	movl	$0x1, %eax
    5696:      	callq	*%rax
    5698:      	testq	%rax, %rax
    569b:      	je	0x5929 <perf_unwind_perl+0x5929>
    56a1:      	incq	(%rax)
    56a4:      	jmp	0x5934 <perf_unwind_perl+0x5934>
    56a9:      	leal	0x1(%rax), %ecx
    56ac:      	movl	%ecx, 0x2c0(%r15)
    56b3:      	leaq	(%rax,%rax,2), %rax
    56b7:      	movq	$0x0, 0x2d0(%r15,%rax,8)
    56c3:      	movq	%r12, 0x2d8(%r15,%rax,8)
    56cb:      	movb	$0x7, 0x2e0(%r15,%rax,8)
    56d4:      	movl	$0x0, 0x2e1(%r15,%rax,8)
    56e0:      	movl	$0x0, 0x2e4(%r15,%rax,8)
    56ec:      	movq	$0x0, 0xf40(%r15)
    56f7:      	movl	$0x0, 0x78(%rsp)
    56ff:      	movzbl	0x18(%r14), %eax
    5704:      	addq	0xa8(%rsp), %rax
    570c:      	leaq	0x78(%rsp), %rdi
    5711:      	movl	$0x4, %ecx
    5716:      	movl	$0x70, %r8d
    571c:      	movzbl	0x18(%r14), %edx
    5721:      	addq	0xa8(%rsp), %rdx
    5729:      	movl	$0x4, %esi
    572e:      	callq	*%r8
    5731:      	testq	%rax, %rax
    5734:      	jne	0x5847 <perf_unwind_perl+0x5847>
    573a:      	cmpl	$0x1, 0x78(%rsp)
    573f:      	je	0x5847 <perf_unwind_perl+0x5847>
    5745:      	movzbl	0x16(%r14), %eax
    574a:      	addq	0xa8(%rsp), %rax
    5752:      	leaq	0xa8(%rsp), %rdi
    575a:      	movl	$0x8, %ecx
    575f:      	movl	$0x70, %r8d
    5765:      	movzbl	0x16(%r14), %edx
    576a:      	addq	0xa8(%rsp), %rdx
    5772:      	movl	$0x8, %esi
    5777:      	callq	*%r8
    577a:      	testq	%rax, %rax
    577d:      	jne	0x5847 <perf_unwind_perl+0x5847>
    5783:      	movq	0xa8(%rsp), %r12
    578b:      	testq	%r12, %r12
    578e:      	je	0x5847 <perf_unwind_perl+0x5847>
    5794:      	cmpl	$0x0, (%r13)
    5799:      	jne	0x5ca3 <perf_unwind_perl+0x5ca3>
    579f:      	movq	0xb8(%rsp), %rax
    57a7:      	movq	%r12, (%rax)
    57aa:      	movzbl	0x15(%r14), %eax
    57af:      	addq	%r12, %rax
    57b2:      	leaq	0x50(%rsp), %rdi
    57b7:      	movl	$0x8, %ecx
    57bc:      	movl	$0x70, %r8d
    57c2:      	movzbl	0x15(%r14), %edx
    57c7:      	addq	%r12, %rdx
    57ca:      	movl	$0x8, %esi
    57cf:      	callq	*%r8
    57d2:      	testq	%rax, %rax
    57d5:      	jne	0x580b <perf_unwind_perl+0x580b>
    57d7:      	movzbl	0x17(%r14), %eax
    57dc:      	addq	%r12, %rax
    57df:      	leaq	0x88(%rsp), %rdi
    57e7:      	movl	$0x4, %ecx
    57ec:      	movl	$0x70, %r8d
    57f2:      	movzbl	0x17(%r14), %edx
    57f7:      	addq	%r12, %rdx
    57fa:      	movl	$0x4, %esi
    57ff:      	callq	*%r8
    5802:      	testq	%rax, %rax
    5805:      	je	0x59c1 <perf_unwind_perl+0x59c1>
    580b:      	cmpl	$0x0, (%r13)
    5810:      	jne	0x5d08 <perf_unwind_perl+0x5d08>
    5816:      	orb	$0x8, 0x1380(%r15)
    581e:      	movl	$0x12, 0x60(%rsp)
    5826:      	movq	(%rip), %rdi            # 0x582d <perf_unwind_perl+0x582d>
    582d:      	leaq	0x60(%rsp), %rsi
    5832:      	movl	$0x1, %eax
    5837:      	callq	*%rax
    5839:      	testq	%rax, %rax
    583c:      	je	0x593b <perf_unwind_perl+0x593b>
    5842:      	incq	(%rax)
    5845:      	jmp	0x585a <perf_unwind_perl+0x585a>
    5847:      	cmpl	$0x0, (%r13)
    584c:      	jne	0x5b76 <perf_unwind_perl+0x5b76>
    5852:      	orb	$0x8, 0x1380(%r15)
    585a:      	movl	$0x1, %ebp
    585f:      	cmpl	$0x0, (%r13)
    5864:      	jne	0x59f8 <perf_unwind_perl+0x59f8>
    586a:      	movl	$0x0, 0x10(%rsp)
    5872:      	movq	(%rip), %rdi            # 0x5879 <perf_unwind_perl+0x5879>
    5879:      	leaq	0x10(%rsp), %rsi
    587e:      	movl	$0x1, %eax
    5883:      	callq	*%rax
    5885:      	testq	%rax, %rax
    5888:      	je	0x58c8 <perf_unwind_perl+0x58c8>
    588a:      	movzbl	0x1384(%rax), %ecx
    5891:      	cmpb	$0x1d, %cl
    5894:      	jb	0x58f5 <perf_unwind_perl+0x58f5>
    5896:      	movq	%rax, %r14
    5899:      	movl	$0x5, 0xf2c(%rax)
    58a3:      	movl	$0x44, 0x50(%rsp)
    58ab:      	movq	(%rip), %rdi            # 0x58b2 <perf_unwind_perl+0x58b2>
    58b2:      	leaq	0x50(%rsp), %rsi
    58b7:      	movl	$0x1, %eax
    58bc:      	callq	*%rax
    58be:      	testq	%rax, %rax
    58c1:      	je	0x58dd <perf_unwind_perl+0x58dd>
    58c3:      	incq	(%rax)
    58c6:      	jmp	0x58e8 <perf_unwind_perl+0x58e8>
    58c8:      	movq	(%rip), %rsi            # 0x58cf <perf_unwind_perl+0x58cf>
    58cf:      	xorl	%eax, %eax
    58d1:      	movl	$0xc, %ecx
    58d6:      	movq	%rbx, %rdi
    58d9:      	xorl	%edx, %edx
    58db:      	jmp	0x5910 <perf_unwind_perl+0x5910>
    58dd:      	cmpl	$0x0, (%r13)
    58e2:      	jne	0x5bc0 <perf_unwind_perl+0x5bc0>
    58e8:      	movq	%r14, %rax
    58eb:      	movzbl	0x1384(%r14), %ecx
    58f3:      	xorl	%ebp, %ebp
    58f5:      	incb	%cl
    58f7:      	movb	%cl, 0x1384(%rax)
    58fd:      	movl	%ebp, %eax
    58ff:      	movq	(%rip), %rsi            # 0x5906 <perf_unwind_perl+0x5906>
    5906:      	movl	$0xc, %ecx
    590b:      	movq	%rbx, %rdi
    590e:      	movl	%ebp, %edx
    5910:      	callq	*%rcx
    5912:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
    5917:      	addq	$0xc8, %rsp
    591e:      	popq	%rbx
    591f:      	popq	%r12
    5921:      	popq	%r13
    5923:      	popq	%r14
    5925:      	popq	%r15
    5927:      	popq	%rbp
    5928:      	retq
    5929:      	cmpl	$0x0, (%r13)
    592e:      	jne	0x5d6c <perf_unwind_perl+0x5d6c>
    5934:      	xorl	%ebp, %ebp
    5936:      	jmp	0x586a <perf_unwind_perl+0x586a>
    593b:      	cmpl	$0x0, (%r13)
    5940:      	je	0x585a <perf_unwind_perl+0x585a>
    5946:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    5950:      	movq	%rax, 0x36(%rsp)
    5955:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    595f:      	movq	%rax, 0x30(%rsp)
    5964:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    596e:      	movq	%rax, 0x28(%rsp)
    5973:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    597d:      	movq	%rax, 0x20(%rsp)
    5982:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    598c:      	movq	%rax, 0x18(%rsp)
    5991:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    599b:      	movq	%rax, 0x10(%rsp)
    59a0:      	leaq	0x10(%rsp), %rdi
    59a5:      	movl	$0x2e, %eax
    59aa:      	movl	$0x6, %ecx
    59af:      	movl	0x60(%rsp), %edx
    59b3:      	movl	$0x2e, %esi
    59b8:      	xorl	%eax, %eax
    59ba:      	callq	*%rcx
    59bc:      	jmp	0x585a <perf_unwind_perl+0x585a>
    59c1:      	cmpl	$0x0, (%r13)
    59c6:      	jne	0x5de9 <perf_unwind_perl+0x5de9>
    59cc:      	movq	0x50(%rsp), %rax
    59d1:      	movq	%rax, 0xf48(%r15)
    59d8:      	movslq	0x88(%rsp), %rcx
    59e0:      	movzbl	0x1d(%r14), %edx
    59e5:      	imulq	%rcx, %rdx
    59e9:      	addq	%rax, %rdx
    59ec:      	movq	%rdx, 0xf50(%r15)
    59f3:      	jmp	0x585a <perf_unwind_perl+0x585a>
    59f8:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    5a02:      	movq	%rax, 0x3d(%rsp)
    5a07:      	movabsq	$0x783020786c257830, %rax # imm = 0x783020786C257830
    5a11:      	movq	%rax, 0x38(%rsp)
    5a16:      	movabsq	$0x202c786c25783020, %rax # imm = 0x202C786C25783020
    5a20:      	movq	%rax, 0x30(%rsp)
    5a25:      	movabsq	$0x6f666e696b636174, %rax # imm = 0x6F666E696B636174
    5a2f:      	movq	%rax, 0x28(%rsp)
    5a34:      	movabsq	$0x73207478656e202c, %rax # imm = 0x73207478656E202C
    5a3e:      	movq	%rax, 0x20(%rsp)
    5a43:      	movabsq	$0x656e6f6420646e69, %rax # imm = 0x656E6F6420646E69
    5a4d:      	movq	%rax, 0x18(%rsp)
    5a52:      	movabsq	$0x776e75206c726550, %rax # imm = 0x776E75206C726550
    5a5c:      	movq	%rax, 0x10(%rsp)
    5a61:      	leaq	0x10(%rsp), %rdi
    5a66:      	movl	$0x35, %eax
    5a6b:      	movl	$0x6, %r9d
    5a71:      	movq	0xa8(%rsp), %rdx
    5a79:      	movq	0xf48(%r15), %rcx
    5a80:      	movq	0xf50(%r15), %r8
    5a87:      	movl	$0x35, %esi
    5a8c:      	xorl	%eax, %eax
    5a8e:      	callq	*%r9
    5a91:      	jmp	0x586a <perf_unwind_perl+0x586a>
    5a96:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    5aa0:      	movq	%rax, 0x30(%rsp)
    5aa5:      	movabsq	$0x6e69616d20676e69, %rax # imm = 0x6E69616D20676E69
    5aaf:      	movq	%rax, 0x28(%rsp)
    5ab4:      	movabsq	$0x68737570202d206b, %rax # imm = 0x68737570202D206B
    5abe:      	movq	%rax, 0x20(%rsp)
    5ac3:      	movabsq	$0x63617473206c7265, %rax # imm = 0x63617473206C7265
    5acd:      	movq	%rax, 0x18(%rsp)
    5ad2:      	movabsq	$0x7020666f20646e45, %rax # imm = 0x7020666F20646E45
    5adc:      	movq	%rax, 0x10(%rsp)
    5ae1:      	leaq	0x10(%rsp), %rdi
    5ae6:      	movl	$0x28, %eax
    5aeb:      	movl	$0x6, %ecx
    5af0:      	movl	$0x28, %esi
    5af5:      	movq	%r12, %rdx
    5af8:      	xorl	%eax, %eax
    5afa:      	callq	*%rcx
    5afc:      	cmpl	$0x0, (%r13)
    5b01:      	je	0x5665 <perf_unwind_perl+0x5665>
    5b07:      	movabsq	$0xa786c2578303d, %rax  # imm = 0xA786C2578303D
    5b11:      	movq	%rax, 0x30(%rsp)
    5b16:      	movabsq	$0x7663202c786c2578, %rax # imm = 0x7663202C786C2578
    5b20:      	movq	%rax, 0x28(%rsp)
    5b25:      	movabsq	$0x303d706f6320656d, %rax # imm = 0x303D706F6320656D
    5b2f:      	movq	%rax, 0x20(%rsp)
    5b34:      	movabsq	$0x617266206c726570, %rax # imm = 0x617266206C726570
    5b3e:      	movq	%rax, 0x18(%rsp)
    5b43:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    5b4d:      	movq	%rax, 0x10(%rsp)
    5b52:      	leaq	0x10(%rsp), %rdi
    5b57:      	movl	$0x28, %eax
    5b5c:      	movl	$0x6, %r8d
    5b62:      	movl	$0x28, %esi
    5b67:      	xorl	%edx, %edx
    5b69:      	movq	%r12, %rcx
    5b6c:      	xorl	%eax, %eax
    5b6e:      	callq	*%r8
    5b71:      	jmp	0x5665 <perf_unwind_perl+0x5665>
    5b76:      	movabsq	$0xa656e6f642073, %rax  # imm = 0xA656E6F642073
    5b80:      	movq	%rax, 0x1e(%rsp)
    5b85:      	movabsq	$0x20736f666e696b63, %rax # imm = 0x20736F666E696B63
    5b8f:      	movq	%rax, 0x18(%rsp)
    5b94:      	movabsq	$0x617473206c726550, %rax # imm = 0x617473206C726550
    5b9e:      	movq	%rax, 0x10(%rsp)
    5ba3:      	leaq	0x10(%rsp), %rdi
    5ba8:      	movl	$0x16, %eax
    5bad:      	movl	$0x6, %ecx
    5bb2:      	movl	$0x16, %esi
    5bb7:      	xorl	%eax, %eax
    5bb9:      	callq	*%rcx
    5bbb:      	jmp	0x5852 <perf_unwind_perl+0x5852>
    5bc0:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    5bca:      	movq	%rax, 0x36(%rsp)
    5bcf:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    5bd9:      	movq	%rax, 0x30(%rsp)
    5bde:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    5be8:      	movq	%rax, 0x28(%rsp)
    5bed:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    5bf7:      	movq	%rax, 0x20(%rsp)
    5bfc:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    5c06:      	movq	%rax, 0x18(%rsp)
    5c0b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5c15:      	movq	%rax, 0x10(%rsp)
    5c1a:      	leaq	0x10(%rsp), %rdi
    5c1f:      	movl	$0x2e, %eax
    5c24:      	movl	$0x6, %ecx
    5c29:      	movl	0x50(%rsp), %edx
    5c2d:      	movl	$0x2e, %esi
    5c32:      	xorl	%eax, %eax
    5c34:      	callq	*%rcx
    5c36:      	jmp	0x58e8 <perf_unwind_perl+0x58e8>
    5c3b:      	movabsq	$0xa6c6c75662073, %rax  # imm = 0xA6C6C75662073
    5c45:      	movq	%rax, 0x2d(%rsp)
    5c4a:      	movabsq	$0x66207369206b6361, %rax # imm = 0x66207369206B6361
    5c54:      	movq	%rax, 0x28(%rsp)
    5c59:      	movabsq	$0x7473203a656d6172, %rax # imm = 0x7473203A656D6172
    5c63:      	movq	%rax, 0x20(%rsp)
    5c68:      	movabsq	$0x662068737570206f, %rax # imm = 0x662068737570206F
    5c72:      	movq	%rax, 0x18(%rsp)
    5c77:      	movabsq	$0x7420656c62616e75, %rax # imm = 0x7420656C62616E75
    5c81:      	movq	%rax, 0x10(%rsp)
    5c86:      	leaq	0x10(%rsp), %rdi
    5c8b:      	movl	$0x25, %eax
    5c90:      	movl	$0x6, %ecx
    5c95:      	movl	$0x25, %esi
    5c9a:      	xorl	%eax, %eax
    5c9c:      	callq	*%rcx
    5c9e:      	jmp	0x567d <perf_unwind_perl+0x567d>
    5ca3:      	movabsq	$0xa642520657079, %rax  # imm = 0xA642520657079
    5cad:      	movq	%rax, 0x26(%rsp)
    5cb2:      	movabsq	$0x707974203a6f666e, %rax # imm = 0x707974203A6F666E
    5cbc:      	movq	%rax, 0x20(%rsp)
    5cc1:      	movabsq	$0x696b636174732074, %rax # imm = 0x696B636174732074
    5ccb:      	movq	%rax, 0x18(%rsp)
    5cd0:      	movabsq	$0x78656e206c726550, %rax # imm = 0x78656E206C726550
    5cda:      	movq	%rax, 0x10(%rsp)
    5cdf:      	leaq	0x10(%rsp), %rdi
    5ce4:      	movl	$0x1e, %eax
    5ce9:      	movl	$0x6, %ecx
    5cee:      	movl	0x78(%rsp), %edx
    5cf2:      	movl	$0x1e, %esi
    5cf7:      	xorl	%eax, %eax
    5cf9:      	callq	*%rcx
    5cfb:      	movq	0xa8(%rsp), %r12
    5d03:      	jmp	0x579f <perf_unwind_perl+0x579f>
    5d08:      	movabsq	$0x6c25783020746120, %rax # imm = 0x6C25783020746120
    5d12:      	movq	%rax, 0x28(%rsp)
    5d17:      	movabsq	$0x6f666e696b636174, %rax # imm = 0x6F666E696B636174
    5d21:      	movq	%rax, 0x20(%rsp)
    5d26:      	movabsq	$0x732064616572206f, %rax # imm = 0x732064616572206F
    5d30:      	movq	%rax, 0x18(%rsp)
    5d35:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5d3f:      	movq	%rax, 0x10(%rsp)
    5d44:      	movl	$0xa786c, 0x2f(%rsp)    # imm = 0xA786C
    5d4c:      	leaq	0x10(%rsp), %rdi
    5d51:      	movl	$0x23, %eax
    5d56:      	movl	$0x6, %ecx
    5d5b:      	movl	$0x23, %esi
    5d60:      	movq	%r12, %rdx
    5d63:      	xorl	%eax, %eax
    5d65:      	callq	*%rcx
    5d67:      	jmp	0x5816 <perf_unwind_perl+0x5816>
    5d6c:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    5d76:      	movq	%rax, 0x36(%rsp)
    5d7b:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    5d85:      	movq	%rax, 0x30(%rsp)
    5d8a:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    5d94:      	movq	%rax, 0x28(%rsp)
    5d99:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    5da3:      	movq	%rax, 0x20(%rsp)
    5da8:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    5db2:      	movq	%rax, 0x18(%rsp)
    5db7:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5dc1:      	movq	%rax, 0x10(%rsp)
    5dc6:      	leaq	0x10(%rsp), %rdi
    5dcb:      	movl	$0x2e, %eax
    5dd0:      	movl	$0x6, %ecx
    5dd5:      	movl	0x50(%rsp), %edx
    5dd9:      	movl	$0x2e, %esi
    5dde:      	xorl	%eax, %eax
    5de0:      	callq	*%rcx
    5de2:      	xorl	%ebp, %ebp
    5de4:      	jmp	0x586a <perf_unwind_perl+0x586a>
    5de9:      	movabsq	$0xa642520786978, %rax  # imm = 0xA642520786978
    5df3:      	movq	%rax, 0x2e(%rsp)
    5df8:      	movabsq	$0x697863202c786c25, %rax # imm = 0x697863202C786C25
    5e02:      	movq	%rax, 0x28(%rsp)
    5e07:      	movabsq	$0x7830206573616278, %rax # imm = 0x7830206573616278
    5e11:      	movq	%rax, 0x20(%rsp)
    5e16:      	movabsq	$0x63202c6f666e696b, %rax # imm = 0x63202C6F666E696B
    5e20:      	movq	%rax, 0x18(%rsp)
    5e25:      	movabsq	$0x636174732077654e, %rax # imm = 0x636174732077654E
    5e2f:      	movq	%rax, 0x10(%rsp)
    5e34:      	leaq	0x10(%rsp), %rdi
    5e39:      	movl	$0x26, %eax
    5e3e:      	movl	$0x6, %r8d
    5e44:      	movq	0x50(%rsp), %rdx
    5e49:      	movl	0x88(%rsp), %ecx
    5e50:      	movl	$0x26, %esi
    5e55:      	xorl	%eax, %eax
    5e57:      	callq	*%r8
    5e5a:      	jmp	0x59cc <perf_unwind_perl+0x59cc>
    5e5f:      	movzbl	0x19(%r14), %eax
    5e64:      	addq	%r13, %rax
    5e67:      	leaq	0xe(%rsp), %rdi
    5e6c:      	movl	$0x1, %ecx
    5e71:      	movl	$0x70, %r8d
    5e77:      	movzbl	0x19(%r14), %edx
    5e7c:      	addq	%r13, %rdx
    5e7f:      	movl	$0x1, %esi
    5e84:      	callq	*%r8
    5e87:      	testq	%rax, %rax
    5e8a:      	je	0x6374 <perf_unwind_perl+0x6374>
    5e90:      	movq	(%rip), %rax            # 0x5e97 <perf_unwind_perl+0x5e97>
    5e97:      	cmpl	$0x0, (%rax)
    5e9a:      	jne	0x8669 <perf_unwind_perl+0x8669>
    5ea0:      	movl	$0x13, 0x50(%rsp)
    5ea8:      	movq	(%rip), %rdi            # 0x5eaf <perf_unwind_perl+0x5eaf>
    5eaf:      	leaq	0x50(%rsp), %rsi
    5eb4:      	movl	$0x1, %eax
    5eb9:      	callq	*%rax
    5ebb:      	testq	%rax, %rax
    5ebe:      	je	0x658b <perf_unwind_perl+0x658b>
    5ec4:      	incq	(%rax)
    5ec7:      	movl	$0x3, %ebp
    5ecc:      	jmp	0x67c4 <perf_unwind_perl+0x67c4>
    5ed1:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    5edb:      	movq	%rax, 0x36(%rsp)
    5ee0:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    5eea:      	movq	%rax, 0x30(%rsp)
    5eef:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    5ef9:      	movq	%rax, 0x28(%rsp)
    5efe:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    5f08:      	movq	%rax, 0x20(%rsp)
    5f0d:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    5f17:      	movq	%rax, 0x18(%rsp)
    5f1c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5f26:      	movq	%rax, 0x10(%rsp)
    5f2b:      	leaq	0x10(%rsp), %rdi
    5f30:      	movl	$0x2e, %eax
    5f35:      	movl	$0x6, %ecx
    5f3a:      	movl	0x50(%rsp), %edx
    5f3e:      	movl	$0x2e, %esi
    5f43:      	xorl	%eax, %eax
    5f45:      	callq	*%rcx
    5f47:      	jmp	0x211e <perf_unwind_perl+0x211e>
    5f4c:      	movabsq	$0xa7667655f7663, %rax  # imm = 0xA7667655F7663
    5f56:      	movq	%rax, 0x35(%rsp)
    5f5b:      	movabsq	$0x5f76635f65766c6f, %rax # imm = 0x5F76635F65766C6F
    5f65:      	movq	%rax, 0x30(%rsp)
    5f6a:      	movabsq	$0x736572206e692029, %rax # imm = 0x736572206E692029
    5f74:      	movq	%rax, 0x28(%rsp)
    5f79:      	movabsq	$0x28726573755f6461, %rax # imm = 0x28726573755F6461
    5f83:      	movq	%rax, 0x20(%rsp)
    5f88:      	movabsq	$0x65725f65626f7270, %rax # imm = 0x65725F65626F7270
    5f92:      	movq	%rax, 0x18(%rsp)
    5f97:      	movabsq	$0x5f66706220646142, %rax # imm = 0x5F66706220646142
    5fa1:      	movq	%rax, 0x10(%rsp)
    5fa6:      	leaq	0x10(%rsp), %rdi
    5fab:      	movl	$0x2d, %eax
    5fb0:      	movl	$0x6, %ecx
    5fb5:      	movl	$0x2d, %esi
    5fba:      	xorl	%eax, %eax
    5fbc:      	callq	*%rcx
    5fbe:      	jmp	0x12bb <perf_unwind_perl+0x12bb>
    5fc3:      	movl	0x5c(%rsp), %eax
    5fc7:      	andl	$0x1f, %eax
    5fca:      	cmpl	$0xd, %eax
    5fcd:      	jne	0x6674 <perf_unwind_perl+0x6674>
    5fd3:      	movzbl	0x1f(%r14), %eax
    5fd8:      	addq	%rbp, %rax
    5fdb:      	leaq	0x50(%rsp), %rdi
    5fe0:      	movl	$0x8, %ecx
    5fe5:      	movl	$0x70, %r8d
    5feb:      	movzbl	0x1f(%r14), %edx
    5ff0:      	addq	%rbp, %rdx
    5ff3:      	movl	$0x8, %esi
    5ff8:      	callq	*%r8
    5ffb:      	testq	%rax, %rax
    5ffe:      	jne	0x3f05 <perf_unwind_perl+0x3f05>
    6004:      	movzbl	0x21(%r14), %eax
    6009:      	addq	0x50(%rsp), %rax
    600e:      	leaq	0x70(%rsp), %rdi
    6013:      	movl	$0x4, %ecx
    6018:      	movl	$0x70, %r8d
    601e:      	movzbl	0x21(%r14), %edx
    6023:      	addq	0x50(%rsp), %rdx
    6028:      	movl	$0x4, %esi
    602d:      	callq	*%r8
    6030:      	testq	%rax, %rax
    6033:      	jne	0x3f05 <perf_unwind_perl+0x3f05>
    6039:      	testb	$-0x80, 0x71(%rsp)
    603e:      	jne	0x7623 <perf_unwind_perl+0x7623>
    6044:      	movzbl	0x22(%r14), %eax
    6049:      	addq	0x50(%rsp), %rax
    604e:      	leaq	0x60(%rsp), %rbp
    6053:      	movl	$0x8, %ecx
    6058:      	movl	$0x70, %r8d
    605e:      	movzbl	0x22(%r14), %edx
    6063:      	addq	0x50(%rsp), %rdx
    6068:      	movq	%rbp, %rdi
    606b:      	movl	$0x8, %esi
    6070:      	callq	*%r8
    6073:      	testq	%rax, %rax
    6076:      	jne	0x3f05 <perf_unwind_perl+0x3f05>
    607c:      	movq	0x60(%rsp), %rax
    6081:      	testq	%rax, %rax
    6084:      	je	0x3f05 <perf_unwind_perl+0x3f05>
    608a:      	movq	(%rip), %rcx            # 0x6091 <perf_unwind_perl+0x6091>
    6091:      	cmpl	$0x0, (%rcx)
    6094:      	jne	0x8dff <perf_unwind_perl+0x8dff>
    609a:      	movzbl	0x1e(%r14), %ecx
    609f:      	addq	%rax, %rcx
    60a2:      	leaq	0x6c(%rsp), %rdi
    60a7:      	movl	$0x4, %eax
    60ac:      	movl	$0x70, %r8d
    60b2:      	movzbl	0x1e(%r14), %edx
    60b7:      	addq	0x60(%rsp), %rdx
    60bc:      	movl	$0x4, %esi
    60c1:      	callq	*%r8
    60c4:      	testq	%rax, %rax
    60c7:      	jne	0x3f05 <perf_unwind_perl+0x3f05>
    60cd:      	movl	$0x801f, %eax           # imm = 0x801F
    60d2:      	andl	0x6c(%rsp), %eax
    60d6:      	cmpl	$0x8009, %eax           # imm = 0x8009
    60db:      	jne	0x8257 <perf_unwind_perl+0x8257>
    60e1:      	movzbl	0x20(%r14), %eax
    60e6:      	addq	0x60(%rsp), %rax
    60eb:      	leaq	0x88(%rsp), %rdi
    60f3:      	movl	$0x8, %ecx
    60f8:      	movl	$0x70, %r8d
    60fe:      	movzbl	0x20(%r14), %edx
    6103:      	addq	0x60(%rsp), %rdx
    6108:      	movl	$0x8, %esi
    610d:      	callq	*%r8
    6110:      	testq	%rax, %rax
    6113:      	jne	0x3f05 <perf_unwind_perl+0x3f05>
    6119:      	movzbl	0x23(%r14), %eax
    611e:      	addq	0x88(%rsp), %rax
    6126:      	leaq	0x78(%rsp), %rdi
    612b:      	movl	$0x8, %ecx
    6130:      	movl	$0x70, %r8d
    6136:      	movzbl	0x23(%r14), %edx
    613b:      	addq	0x88(%rsp), %rdx
    6143:      	movl	$0x8, %esi
    6148:      	callq	*%r8
    614b:      	testq	%rax, %rax
    614e:      	jne	0x3f05 <perf_unwind_perl+0x3f05>
    6154:      	movq	0x78(%rsp), %rax
    6159:      	movq	%rax, 0x80(%rsp)
    6161:      	testq	%rax, %rax
    6164:      	je	0x61ba <perf_unwind_perl+0x61ba>
    6166:      	movq	(%rip), %rax            # 0x616d <perf_unwind_perl+0x616d>
    616d:      	cmpl	$0x0, (%rax)
    6170:      	je	0x61cf <perf_unwind_perl+0x61cf>
    6172:      	movabsq	$0x2578302074612056, %rax # imm = 0x2578302074612056
    617c:      	movq	%rax, 0x18(%rsp)
    6181:      	movabsq	$0x474520646e756f46, %rax # imm = 0x474520646E756F46
    618b:      	movq	%rax, 0x10(%rsp)
    6190:      	movl	$0xa786c, 0x20(%rsp)    # imm = 0xA786C
    6198:      	leaq	0x10(%rsp), %rdi
    619d:      	movl	$0x14, %eax
    61a2:      	movl	$0x6, %ecx
    61a7:      	movq	0x78(%rsp), %rdx
    61ac:      	movl	$0x14, %esi
    61b1:      	xorl	%eax, %eax
    61b3:      	callq	*%rcx
    61b5:      	leaq	0x78(%rsp), %rbp
    61ba:      	movq	(%rbp), %rax
    61be:      	movq	%rax, 0x80(%rsp)
    61c6:      	testq	%rax, %rax
    61c9:      	je	0x3945 <perf_unwind_perl+0x3945>
    61cf:      	movq	(%r12), %rax
    61d3:      	movq	%rax, 0x90(%rsp)
    61db:      	movq	(%rip), %rax            # 0x61e2 <perf_unwind_perl+0x61e2>
    61e2:      	cmpl	$0x0, (%rax)
    61e5:      	jne	0x8ffc <perf_unwind_perl+0x8ffc>
    61eb:      	movl	0x2c0(%r15), %eax
    61f2:      	cmpq	$0x7e, %rax
    61f6:      	ja	0x1193 <perf_unwind_perl+0x1193>
    61fc:      	xorl	%ecx, %ecx
    61fe:      	movzbl	0xf(%rsp), %edx
    6203:      	movb	%dl, %cl
    6205:      	leal	0x1(,%rcx,2), %ebp
    620c:      	leal	0x1(%rax), %ecx
    620f:      	movl	%ecx, 0x2c0(%r15)
    6216:      	leaq	(%rax,%rax,2), %rax
    621a:      	movq	0x80(%rsp), %rcx
    6222:      	movq	%rcx, 0x2d0(%r15,%rax,8)
    622a:      	movq	0x90(%rsp), %rcx
    6232:      	movq	%rcx, 0x2d8(%r15,%rax,8)
    623a:      	movb	$0x7, 0x2e0(%r15,%rax,8)
    6243:      	movl	$0x0, 0x2e1(%r15,%rax,8)
    624f:      	movl	$0x0, 0x2e4(%r15,%rax,8)
    625b:      	movq	$0x0, 0xf40(%r15)
    6266:      	movzbl	0x1a(%r14), %eax
    626b:      	addq	%r13, %rax
    626e:      	movl	$0x8, %ecx
    6273:      	movl	$0x70, %r8d
    6279:      	movzbl	0x1a(%r14), %edx
    627e:      	addq	%r13, %rdx
    6281:      	movq	%r12, %rdi
    6284:      	movl	$0x8, %esi
    6289:      	callq	*%r8
    628c:      	testq	%rax, %rax
    628f:      	jne	0x3945 <perf_unwind_perl+0x3945>
    6295:      	movq	(%rip), %rax            # 0x629c <perf_unwind_perl+0x629c>
    629c:      	cmpl	$0x0, (%rax)
    629f:      	je	0x428e <perf_unwind_perl+0x428e>
    62a5:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    62af:      	movq	%rax, 0x26(%rsp)
    62b4:      	movabsq	$0x30206b6361747320, %rax # imm = 0x30206B6361747320
    62be:      	movq	%rax, 0x20(%rsp)
    62c3:      	movabsq	$0x747865746e6f6320, %rax # imm = 0x747865746E6F6320
    62cd:      	movq	%rax, 0x18(%rsp)
    62d2:      	movabsq	$0x6d6f726620504f43, %rax # imm = 0x6D6F726620504F43
    62dc:      	movq	%rax, 0x10(%rsp)
    62e1:      	leaq	0x10(%rsp), %rdi
    62e6:      	movl	$0x1e, %eax
    62eb:      	movl	$0x6, %ecx
    62f0:      	movq	(%r12), %rdx
    62f4:      	movl	$0x1e, %esi
    62f9:      	xorl	%eax, %eax
    62fb:      	callq	*%rcx
    62fd:      	jmp	0x428e <perf_unwind_perl+0x428e>
    6302:      	movabsq	$0x7025207461207972, %rax # imm = 0x7025207461207972
    630c:      	movq	%rax, 0x30(%rsp)
    6311:      	movabsq	$0x746e65206b636174, %rax # imm = 0x746E65206B636174
    631b:      	movq	%rax, 0x28(%rsp)
    6320:      	movabsq	$0x7320747865746e6f, %rax # imm = 0x7320747865746E6F
    632a:      	movq	%rax, 0x20(%rsp)
    632f:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    6339:      	movq	%rax, 0x18(%rsp)
    633e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6348:      	movq	%rax, 0x10(%rsp)
    634d:      	movw	$0xa, 0x38(%rsp)
    6354:      	leaq	0x10(%rsp), %rdi
    6359:      	movl	$0x2a, %eax
    635e:      	movl	$0x6, %ecx
    6363:      	movl	$0x2a, %esi
    6368:      	movq	%r13, %rdx
    636b:      	xorl	%eax, %eax
    636d:      	callq	*%rcx
    636f:      	jmp	0x2538 <perf_unwind_perl+0x2538>
    6374:      	movq	(%rip), %rax            # 0x637b <perf_unwind_perl+0x637b>
    637b:      	cmpl	$0x0, (%rax)
    637e:      	jne	0x88ad <perf_unwind_perl+0x88ad>
    6384:      	movzbl	0xe(%rsp), %eax
    6389:      	movl	%eax, %ecx
    638b:      	andl	$0xf, %ecx
    638e:      	movl	$0x3, %ebp
    6393:      	leal	-0x9(%rcx), %edx
    6396:      	cmpl	$0x2, %edx
    6399:      	jae	0x67b4 <perf_unwind_perl+0x67b4>
    639f:      	testb	%al, %al
    63a1:      	js	0x67c4 <perf_unwind_perl+0x67c4>
    63a7:      	movzbl	0x1b(%r14), %eax
    63ac:      	addq	%r13, %rax
    63af:      	leaq	0x10(%rsp), %rdi
    63b4:      	movl	$0x8, %ecx
    63b9:      	movl	$0x70, %r8d
    63bf:      	movzbl	0x1b(%r14), %edx
    63c4:      	addq	%r13, %rdx
    63c7:      	movl	$0x8, %esi
    63cc:      	callq	*%r8
    63cf:      	testq	%rax, %rax
    63d2:      	jne	0x5e90 <perf_unwind_perl+0x5e90>
    63d8:      	cmpq	$0x0, 0x10(%rsp)
    63de:      	setne	0xf(%rsp)
    63e3:      	movzbl	0x1c(%r14), %eax
    63e8:      	addq	%r13, %rax
    63eb:      	leaq	0xa0(%rsp), %rdi
    63f3:      	movl	$0x8, %ecx
    63f8:      	movl	$0x70, %r8d
    63fe:      	movzbl	0x1c(%r14), %edx
    6403:      	addq	%r13, %rdx
    6406:      	movl	$0x8, %esi
    640b:      	callq	*%r8
    640e:      	testq	%rax, %rax
    6411:      	jne	0x5e90 <perf_unwind_perl+0x5e90>
    6417:      	movq	0xa0(%rsp), %rbp
    641f:      	movzbl	0x1e(%r14), %eax
    6424:      	addq	%rbp, %rax
    6427:      	leaq	0x5c(%rsp), %rdi
    642c:      	movl	$0x4, %ecx
    6431:      	movl	$0x70, %r8d
    6437:      	movzbl	0x1e(%r14), %edx
    643c:      	addq	%rbp, %rdx
    643f:      	movl	$0x4, %esi
    6444:      	callq	*%r8
    6447:      	testq	%rax, %rax
    644a:      	je	0x78d7 <perf_unwind_perl+0x78d7>
    6450:      	movq	(%rip), %rax            # 0x6457 <perf_unwind_perl+0x6457>
    6457:      	cmpl	$0x0, (%rax)
    645a:      	jne	0x8cfd <perf_unwind_perl+0x8cfd>
    6460:      	movl	$0x14, 0x74(%rsp)
    6468:      	movq	(%rip), %rdi            # 0x646f <perf_unwind_perl+0x646f>
    646f:      	leaq	0x74(%rsp), %rsi
    6474:      	movl	$0x1, %eax
    6479:      	callq	*%rax
    647b:      	testq	%rax, %rax
    647e:      	je	0x7df5 <perf_unwind_perl+0x7df5>
    6484:      	incq	(%rax)
    6487:      	jmp	0x5e90 <perf_unwind_perl+0x5e90>
    648c:      	movq	(%rip), %rax            # 0x6493 <perf_unwind_perl+0x6493>
    6493:      	cmpl	$0x0, (%rax)
    6496:      	je	0x149a <perf_unwind_perl+0x149a>
    649c:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    64a6:      	movq	%rax, 0x2e(%rsp)
    64ab:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    64b5:      	movq	%rax, 0x28(%rsp)
    64ba:      	movabsq	$0x50472d74756f6874, %rax # imm = 0x50472D74756F6874
    64c4:      	movq	%rax, 0x20(%rsp)
    64c9:      	movabsq	$0x69772d5647206465, %rax # imm = 0x69772D5647206465
    64d3:      	movq	%rax, 0x18(%rsp)
    64d8:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    64e2:      	movq	%rax, 0x10(%rsp)
    64e7:      	leaq	0x10(%rsp), %rdi
    64ec:      	movl	$0x26, %eax
    64f1:      	movl	$0x6, %ecx
    64f6:      	movl	0x6c(%rsp), %edx
    64fa:      	movl	$0x26, %esi
    64ff:      	jmp	0x37c7 <perf_unwind_perl+0x37c7>
    6504:      	movq	(%rip), %rax            # 0x650b <perf_unwind_perl+0x650b>
    650b:      	cmpl	$0x0, (%rax)
    650e:      	je	0x3945 <perf_unwind_perl+0x3945>
    6514:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    651e:      	movq	%rax, 0x36(%rsp)
    6523:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    652d:      	movq	%rax, 0x30(%rsp)
    6532:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    653c:      	movq	%rax, 0x28(%rsp)
    6541:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    654b:      	movq	%rax, 0x20(%rsp)
    6550:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    655a:      	movq	%rax, 0x18(%rsp)
    655f:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6569:      	movq	%rax, 0x10(%rsp)
    656e:      	leaq	0x10(%rsp), %rdi
    6573:      	movl	$0x2e, %eax
    6578:      	movl	$0x6, %ecx
    657d:      	movl	0x74(%rsp), %edx
    6581:      	movl	$0x2e, %esi
    6586:      	jmp	0x66d8 <perf_unwind_perl+0x66d8>
    658b:      	movq	(%rip), %rax            # 0x6592 <perf_unwind_perl+0x6592>
    6592:      	cmpl	$0x0, (%rax)
    6595:      	jne	0x88f4 <perf_unwind_perl+0x88f4>
    659b:      	movl	$0x3, %ebp
    65a0:      	jmp	0x67c4 <perf_unwind_perl+0x67c4>
    65a5:      	movabsq	$0x6c25783020746120, %rax # imm = 0x6C25783020746120
    65af:      	movq	%rax, 0x18(%rsp)
    65b4:      	movabsq	$0x564720646e756f46, %rax # imm = 0x564720646E756F46
    65be:      	movq	%rax, 0x10(%rsp)
    65c3:      	movl	$0xa786c, 0x1f(%rsp)    # imm = 0xA786C
    65cb:      	leaq	0x10(%rsp), %rdi
    65d0:      	movl	$0x13, %eax
    65d5:      	movl	$0x6, %ecx
    65da:      	movq	0x60(%rsp), %rdx
    65df:      	movl	$0x13, %esi
    65e4:      	xorl	%eax, %eax
    65e6:      	callq	*%rcx
    65e8:      	movq	0x60(%rsp), %rax
    65ed:      	jmp	0x1031 <perf_unwind_perl+0x1031>
    65f2:      	movq	(%rip), %rax            # 0x65f9 <perf_unwind_perl+0x65f9>
    65f9:      	cmpl	$0x0, (%rax)
    65fc:      	je	0x2528 <perf_unwind_perl+0x2528>
    6602:      	movabsq	$0xa782578302f78, %rax  # imm = 0xA782578302F78
    660c:      	movq	%rax, 0x2e(%rsp)
    6611:      	movabsq	$0x2f78257830207367, %rax # imm = 0x2F78257830207367
    661b:      	movq	%rax, 0x28(%rsp)
    6620:      	movabsq	$0x616c66202c564320, %rax # imm = 0x616C66202C564320
    662a:      	movq	%rax, 0x20(%rsp)
    662f:      	movabsq	$0x44454d414e206465, %rax # imm = 0x44454D414E206465
    6639:      	movq	%rax, 0x18(%rsp)
    663e:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    6648:      	movq	%rax, 0x10(%rsp)
    664d:      	leaq	0x10(%rsp), %rdi
    6652:      	movl	$0x26, %eax
    6657:      	movl	$0x6, %r8d
    665d:      	movl	0x5c(%rsp), %edx
    6661:      	movl	0x70(%rsp), %ecx
    6665:      	movl	$0x26, %esi
    666a:      	xorl	%eax, %eax
    666c:      	callq	*%r8
    666f:      	jmp	0x2528 <perf_unwind_perl+0x2528>
    6674:      	movq	(%rip), %rax            # 0x667b <perf_unwind_perl+0x667b>
    667b:      	cmpl	$0x0, (%rax)
    667e:      	je	0x3945 <perf_unwind_perl+0x3945>
    6684:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    668e:      	movq	%rax, 0x26(%rsp)
    6693:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    669d:      	movq	%rax, 0x20(%rsp)
    66a2:      	movabsq	$0x5643565020612074, %rax # imm = 0x5643565020612074
    66ac:      	movq	%rax, 0x18(%rsp)
    66b1:      	movabsq	$0x6f6e207369205643, %rax # imm = 0x6F6E207369205643
    66bb:      	movq	%rax, 0x10(%rsp)
    66c0:      	leaq	0x10(%rsp), %rdi
    66c5:      	movl	$0x1e, %eax
    66ca:      	movl	$0x6, %ecx
    66cf:      	movl	0x5c(%rsp), %edx
    66d3:      	movl	$0x1e, %esi
    66d8:      	xorl	%eax, %eax
    66da:      	callq	*%rcx
    66dc:      	jmp	0x3945 <perf_unwind_perl+0x3945>
    66e1:      	movabsq	$0x7825783020786320, %rax # imm = 0x7825783020786320
    66eb:      	movq	%rax, 0x18(%rsp)
    66f0:      	movabsq	$0x6c72657020746f47, %rax # imm = 0x6C72657020746F47
    66fa:      	movq	%rax, 0x10(%rsp)
    66ff:      	movw	$0xa, 0x20(%rsp)
    6706:      	leaq	0x10(%rsp), %rdi
    670b:      	movl	$0x12, %eax
    6710:      	movl	$0x6, %ecx
    6715:      	movzbl	0xe(%rsp), %edx
    671a:      	movl	$0x12, %esi
    671f:      	xorl	%eax, %eax
    6721:      	callq	*%rcx
    6723:      	jmp	0x2a25 <perf_unwind_perl+0x2a25>
    6728:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    6732:      	movq	%rax, 0x36(%rsp)
    6737:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    6741:      	movq	%rax, 0x30(%rsp)
    6746:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    6750:      	movq	%rax, 0x28(%rsp)
    6755:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    675f:      	movq	%rax, 0x20(%rsp)
    6764:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    676e:      	movq	%rax, 0x18(%rsp)
    6773:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    677d:      	movq	%rax, 0x10(%rsp)
    6782:      	leaq	0x10(%rsp), %rdi
    6787:      	movl	$0x2e, %eax
    678c:      	movl	$0x6, %ecx
    6791:      	movl	0x50(%rsp), %edx
    6795:      	movl	$0x2e, %esi
    679a:      	xorl	%eax, %eax
    679c:      	callq	*%rcx
    679e:      	cmpl	$0x3, %ebp
    67a1:      	movq	0x98(%rsp), %rcx
    67a9:      	je	0x2df1 <perf_unwind_perl+0x2df1>
    67af:      	jmp	0x5636 <perf_unwind_perl+0x5636>
    67b4:      	cmpl	$0xc, %ecx
    67b7:      	je	0x67c4 <perf_unwind_perl+0x67c4>
    67b9:      	cmpq	$0x0, (%r12)
    67be:      	je	0x7b7a <perf_unwind_perl+0x7b7a>
    67c4:      	movzbl	0x1d(%r14), %eax
    67c9:      	subq	%rax, 0xf50(%r15)
    67d0:      	movl	$0x10, 0x50(%rsp)
    67d8:      	movq	(%rip), %rdi            # 0x67df <perf_unwind_perl+0x67df>
    67df:      	leaq	0x50(%rsp), %rsi
    67e4:      	movl	$0x1, %eax
    67e9:      	callq	*%rax
    67eb:      	testq	%rax, %rax
    67ee:      	je	0x67f8 <perf_unwind_perl+0x67f8>
    67f0:      	incq	(%rax)
    67f3:      	jmp	0x24ea <perf_unwind_perl+0x24ea>
    67f8:      	movq	(%rip), %rax            # 0x67ff <perf_unwind_perl+0x67ff>
    67ff:      	cmpl	$0x0, (%rax)
    6802:      	je	0x24ea <perf_unwind_perl+0x24ea>
    6808:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    6812:      	movq	%rax, 0x36(%rsp)
    6817:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    6821:      	movq	%rax, 0x30(%rsp)
    6826:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    6830:      	movq	%rax, 0x28(%rsp)
    6835:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    683f:      	movq	%rax, 0x20(%rsp)
    6844:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    684e:      	movq	%rax, 0x18(%rsp)
    6853:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    685d:      	movq	%rax, 0x10(%rsp)
    6862:      	leaq	0x10(%rsp), %rdi
    6867:      	movl	$0x2e, %eax
    686c:      	movl	$0x6, %ecx
    6871:      	movl	0x50(%rsp), %edx
    6875:      	movl	$0x2e, %esi
    687a:      	xorl	%eax, %eax
    687c:      	callq	*%rcx
    687e:      	jmp	0x24ea <perf_unwind_perl+0x24ea>
    6883:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    688d:      	movq	%rax, 0x36(%rsp)
    6892:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    689c:      	movq	%rax, 0x30(%rsp)
    68a1:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    68ab:      	movq	%rax, 0x28(%rsp)
    68b0:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    68ba:      	movq	%rax, 0x20(%rsp)
    68bf:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    68c9:      	movq	%rax, 0x18(%rsp)
    68ce:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    68d8:      	movq	%rax, 0x10(%rsp)
    68dd:      	leaq	0x10(%rsp), %rdi
    68e2:      	movl	$0x2e, %eax
    68e7:      	movl	$0x6, %ecx
    68ec:      	movl	0x50(%rsp), %edx
    68f0:      	movl	$0x2e, %esi
    68f5:      	xorl	%eax, %eax
    68f7:      	callq	*%rcx
    68f9:      	jmp	0x2bc4 <perf_unwind_perl+0x2bc4>
    68fe:      	movabsq	$0xa7667655f7663, %rax  # imm = 0xA7667655F7663
    6908:      	movq	%rax, 0x35(%rsp)
    690d:      	movabsq	$0x5f76635f65766c6f, %rax # imm = 0x5F76635F65766C6F
    6917:      	movq	%rax, 0x30(%rsp)
    691c:      	movabsq	$0x736572206e692029, %rax # imm = 0x736572206E692029
    6926:      	movq	%rax, 0x28(%rsp)
    692b:      	movabsq	$0x28726573755f6461, %rax # imm = 0x28726573755F6461
    6935:      	movq	%rax, 0x20(%rsp)
    693a:      	movabsq	$0x65725f65626f7270, %rax # imm = 0x65725F65626F7270
    6944:      	movq	%rax, 0x18(%rsp)
    6949:      	movabsq	$0x5f66706220646142, %rax # imm = 0x5F66706220646142
    6953:      	movq	%rax, 0x10(%rsp)
    6958:      	leaq	0x10(%rsp), %rdi
    695d:      	movl	$0x2d, %eax
    6962:      	movl	$0x6, %ecx
    6967:      	movl	$0x2d, %esi
    696c:      	xorl	%eax, %eax
    696e:      	callq	*%rcx
    6970:      	jmp	0x199e <perf_unwind_perl+0x199e>
    6975:      	movl	0x5c(%rsp), %eax
    6979:      	andl	$0x1f, %eax
    697c:      	cmpl	$0xd, %eax
    697f:      	jne	0x6ef4 <perf_unwind_perl+0x6ef4>
    6985:      	movzbl	0x1f(%r14), %eax
    698a:      	addq	%rbp, %rax
    698d:      	leaq	0x50(%rsp), %rdi
    6992:      	movl	$0x8, %ecx
    6997:      	movl	$0x70, %r8d
    699d:      	movzbl	0x1f(%r14), %edx
    69a2:      	addq	%rbp, %rdx
    69a5:      	movl	$0x8, %esi
    69aa:      	callq	*%r8
    69ad:      	testq	%rax, %rax
    69b0:      	jne	0x48f1 <perf_unwind_perl+0x48f1>
    69b6:      	movzbl	0x21(%r14), %eax
    69bb:      	addq	0x50(%rsp), %rax
    69c0:      	leaq	0x70(%rsp), %rdi
    69c5:      	movl	$0x4, %ecx
    69ca:      	movl	$0x70, %r8d
    69d0:      	movzbl	0x21(%r14), %edx
    69d5:      	addq	0x50(%rsp), %rdx
    69da:      	movl	$0x4, %esi
    69df:      	callq	*%r8
    69e2:      	testq	%rax, %rax
    69e5:      	jne	0x48f1 <perf_unwind_perl+0x48f1>
    69eb:      	testb	$-0x80, 0x71(%rsp)
    69f0:      	jne	0x7ec9 <perf_unwind_perl+0x7ec9>
    69f6:      	movzbl	0x22(%r14), %eax
    69fb:      	addq	0x50(%rsp), %rax
    6a00:      	leaq	0x60(%rsp), %rbp
    6a05:      	movl	$0x8, %ecx
    6a0a:      	movl	$0x70, %r8d
    6a10:      	movzbl	0x22(%r14), %edx
    6a15:      	addq	0x50(%rsp), %rdx
    6a1a:      	movq	%rbp, %rdi
    6a1d:      	movl	$0x8, %esi
    6a22:      	callq	*%r8
    6a25:      	testq	%rax, %rax
    6a28:      	jne	0x48f1 <perf_unwind_perl+0x48f1>
    6a2e:      	movq	0x60(%rsp), %rax
    6a33:      	testq	%rax, %rax
    6a36:      	je	0x48f1 <perf_unwind_perl+0x48f1>
    6a3c:      	movq	(%rip), %rcx            # 0x6a43 <perf_unwind_perl+0x6a43>
    6a43:      	cmpl	$0x0, (%rcx)
    6a46:      	jne	0x8ed7 <perf_unwind_perl+0x8ed7>
    6a4c:      	movzbl	0x1e(%r14), %ecx
    6a51:      	addq	%rax, %rcx
    6a54:      	leaq	0x6c(%rsp), %rdi
    6a59:      	movl	$0x4, %eax
    6a5e:      	movl	$0x70, %r8d
    6a64:      	movzbl	0x1e(%r14), %edx
    6a69:      	addq	0x60(%rsp), %rdx
    6a6e:      	movl	$0x4, %esi
    6a73:      	callq	*%r8
    6a76:      	testq	%rax, %rax
    6a79:      	jne	0x48f1 <perf_unwind_perl+0x48f1>
    6a7f:      	movl	$0x801f, %eax           # imm = 0x801F
    6a84:      	andl	0x6c(%rsp), %eax
    6a88:      	cmpl	$0x8009, %eax           # imm = 0x8009
    6a8d:      	jne	0x86db <perf_unwind_perl+0x86db>
    6a93:      	movzbl	0x20(%r14), %eax
    6a98:      	addq	0x60(%rsp), %rax
    6a9d:      	leaq	0x88(%rsp), %rdi
    6aa5:      	movl	$0x8, %ecx
    6aaa:      	movl	$0x70, %r8d
    6ab0:      	movzbl	0x20(%r14), %edx
    6ab5:      	addq	0x60(%rsp), %rdx
    6aba:      	movl	$0x8, %esi
    6abf:      	callq	*%r8
    6ac2:      	testq	%rax, %rax
    6ac5:      	jne	0x48f1 <perf_unwind_perl+0x48f1>
    6acb:      	movzbl	0x23(%r14), %eax
    6ad0:      	addq	0x88(%rsp), %rax
    6ad8:      	leaq	0x78(%rsp), %rdi
    6add:      	movl	$0x8, %ecx
    6ae2:      	movl	$0x70, %r8d
    6ae8:      	movzbl	0x23(%r14), %edx
    6aed:      	addq	0x88(%rsp), %rdx
    6af5:      	movl	$0x8, %esi
    6afa:      	callq	*%r8
    6afd:      	testq	%rax, %rax
    6b00:      	jne	0x48f1 <perf_unwind_perl+0x48f1>
    6b06:      	movq	0x78(%rsp), %rax
    6b0b:      	movq	%rax, 0x80(%rsp)
    6b13:      	testq	%rax, %rax
    6b16:      	je	0x6b6c <perf_unwind_perl+0x6b6c>
    6b18:      	movq	(%rip), %rax            # 0x6b1f <perf_unwind_perl+0x6b1f>
    6b1f:      	cmpl	$0x0, (%rax)
    6b22:      	je	0x6b81 <perf_unwind_perl+0x6b81>
    6b24:      	movabsq	$0x2578302074612056, %rax # imm = 0x2578302074612056
    6b2e:      	movq	%rax, 0x18(%rsp)
    6b33:      	movabsq	$0x474520646e756f46, %rax # imm = 0x474520646E756F46
    6b3d:      	movq	%rax, 0x10(%rsp)
    6b42:      	movl	$0xa786c, 0x20(%rsp)    # imm = 0xA786C
    6b4a:      	leaq	0x10(%rsp), %rdi
    6b4f:      	movl	$0x14, %eax
    6b54:      	movl	$0x6, %ecx
    6b59:      	movq	0x78(%rsp), %rdx
    6b5e:      	movl	$0x14, %esi
    6b63:      	xorl	%eax, %eax
    6b65:      	callq	*%rcx
    6b67:      	leaq	0x78(%rsp), %rbp
    6b6c:      	movq	(%rbp), %rax
    6b70:      	movq	%rax, 0x80(%rsp)
    6b78:      	testq	%rax, %rax
    6b7b:      	je	0x4331 <perf_unwind_perl+0x4331>
    6b81:      	movq	(%r12), %rax
    6b85:      	movq	%rax, 0x90(%rsp)
    6b8d:      	movq	(%rip), %rax            # 0x6b94 <perf_unwind_perl+0x6b94>
    6b94:      	cmpl	$0x0, (%rax)
    6b97:      	jne	0x90d4 <perf_unwind_perl+0x90d4>
    6b9d:      	movl	0x2c0(%r15), %eax
    6ba4:      	cmpq	$0x7e, %rax
    6ba8:      	ja	0x1193 <perf_unwind_perl+0x1193>
    6bae:      	xorl	%ecx, %ecx
    6bb0:      	movzbl	0xf(%rsp), %edx
    6bb5:      	movb	%dl, %cl
    6bb7:      	leal	0x1(,%rcx,2), %ebp
    6bbe:      	leal	0x1(%rax), %ecx
    6bc1:      	movl	%ecx, 0x2c0(%r15)
    6bc8:      	leaq	(%rax,%rax,2), %rax
    6bcc:      	movq	0x80(%rsp), %rcx
    6bd4:      	movq	%rcx, 0x2d0(%r15,%rax,8)
    6bdc:      	movq	0x90(%rsp), %rcx
    6be4:      	movq	%rcx, 0x2d8(%r15,%rax,8)
    6bec:      	movb	$0x7, 0x2e0(%r15,%rax,8)
    6bf5:      	movl	$0x0, 0x2e1(%r15,%rax,8)
    6c01:      	movl	$0x0, 0x2e4(%r15,%rax,8)
    6c0d:      	movq	$0x0, 0xf40(%r15)
    6c18:      	movzbl	0x1a(%r14), %eax
    6c1d:      	addq	%r13, %rax
    6c20:      	movl	$0x8, %ecx
    6c25:      	movl	$0x70, %r8d
    6c2b:      	movzbl	0x1a(%r14), %edx
    6c30:      	addq	%r13, %rdx
    6c33:      	movq	%r12, %rdi
    6c36:      	movl	$0x8, %esi
    6c3b:      	callq	*%r8
    6c3e:      	testq	%rax, %rax
    6c41:      	jne	0x4331 <perf_unwind_perl+0x4331>
    6c47:      	movq	(%rip), %rax            # 0x6c4e <perf_unwind_perl+0x6c4e>
    6c4e:      	cmpl	$0x0, (%rax)
    6c51:      	je	0x4c07 <perf_unwind_perl+0x4c07>
    6c57:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    6c61:      	movq	%rax, 0x26(%rsp)
    6c66:      	movabsq	$0x30206b6361747320, %rax # imm = 0x30206B6361747320
    6c70:      	movq	%rax, 0x20(%rsp)
    6c75:      	movabsq	$0x747865746e6f6320, %rax # imm = 0x747865746E6F6320
    6c7f:      	movq	%rax, 0x18(%rsp)
    6c84:      	movabsq	$0x6d6f726620504f43, %rax # imm = 0x6D6F726620504F43
    6c8e:      	movq	%rax, 0x10(%rsp)
    6c93:      	leaq	0x10(%rsp), %rdi
    6c98:      	movl	$0x1e, %eax
    6c9d:      	movl	$0x6, %ecx
    6ca2:      	movq	(%r12), %rdx
    6ca6:      	movl	$0x1e, %esi
    6cab:      	xorl	%eax, %eax
    6cad:      	callq	*%rcx
    6caf:      	jmp	0x4c07 <perf_unwind_perl+0x4c07>
    6cb4:      	movabsq	$0x7025207461207972, %rax # imm = 0x7025207461207972
    6cbe:      	movq	%rax, 0x30(%rsp)
    6cc3:      	movabsq	$0x746e65206b636174, %rax # imm = 0x746E65206B636174
    6ccd:      	movq	%rax, 0x28(%rsp)
    6cd2:      	movabsq	$0x7320747865746e6f, %rax # imm = 0x7320747865746E6F
    6cdc:      	movq	%rax, 0x20(%rsp)
    6ce1:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    6ceb:      	movq	%rax, 0x18(%rsp)
    6cf0:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6cfa:      	movq	%rax, 0x10(%rsp)
    6cff:      	movw	$0xa, 0x38(%rsp)
    6d06:      	leaq	0x10(%rsp), %rdi
    6d0b:      	movl	$0x2a, %eax
    6d10:      	movl	$0x6, %ecx
    6d15:      	movl	$0x2a, %esi
    6d1a:      	movq	%r13, %rdx
    6d1d:      	xorl	%eax, %eax
    6d1f:      	callq	*%rcx
    6d21:      	jmp	0x2e42 <perf_unwind_perl+0x2e42>
    6d26:      	movq	(%rip), %rax            # 0x6d2d <perf_unwind_perl+0x6d2d>
    6d2d:      	cmpl	$0x0, (%rax)
    6d30:      	je	0x1b7d <perf_unwind_perl+0x1b7d>
    6d36:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    6d40:      	movq	%rax, 0x2e(%rsp)
    6d45:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    6d4f:      	movq	%rax, 0x28(%rsp)
    6d54:      	movabsq	$0x50472d74756f6874, %rax # imm = 0x50472D74756F6874
    6d5e:      	movq	%rax, 0x20(%rsp)
    6d63:      	movabsq	$0x69772d5647206465, %rax # imm = 0x69772D5647206465
    6d6d:      	movq	%rax, 0x18(%rsp)
    6d72:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    6d7c:      	movq	%rax, 0x10(%rsp)
    6d81:      	leaq	0x10(%rsp), %rdi
    6d86:      	movl	$0x26, %eax
    6d8b:      	movl	$0x6, %ecx
    6d90:      	movl	0x6c(%rsp), %edx
    6d94:      	movl	$0x26, %esi
    6d99:      	jmp	0x41b3 <perf_unwind_perl+0x41b3>
    6d9e:      	movq	(%rip), %rax            # 0x6da5 <perf_unwind_perl+0x6da5>
    6da5:      	cmpl	$0x0, (%rax)
    6da8:      	je	0x4331 <perf_unwind_perl+0x4331>
    6dae:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    6db8:      	movq	%rax, 0x36(%rsp)
    6dbd:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    6dc7:      	movq	%rax, 0x30(%rsp)
    6dcc:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    6dd6:      	movq	%rax, 0x28(%rsp)
    6ddb:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    6de5:      	movq	%rax, 0x20(%rsp)
    6dea:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    6df4:      	movq	%rax, 0x18(%rsp)
    6df9:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6e03:      	movq	%rax, 0x10(%rsp)
    6e08:      	leaq	0x10(%rsp), %rdi
    6e0d:      	movl	$0x2e, %eax
    6e12:      	movl	$0x6, %ecx
    6e17:      	movl	0x74(%rsp), %edx
    6e1b:      	movl	$0x2e, %esi
    6e20:      	jmp	0x6f58 <perf_unwind_perl+0x6f58>
    6e25:      	movabsq	$0x6c25783020746120, %rax # imm = 0x6C25783020746120
    6e2f:      	movq	%rax, 0x18(%rsp)
    6e34:      	movabsq	$0x564720646e756f46, %rax # imm = 0x564720646E756F46
    6e3e:      	movq	%rax, 0x10(%rsp)
    6e43:      	movl	$0xa786c, 0x1f(%rsp)    # imm = 0xA786C
    6e4b:      	leaq	0x10(%rsp), %rdi
    6e50:      	movl	$0x13, %eax
    6e55:      	movl	$0x6, %ecx
    6e5a:      	movq	0x60(%rsp), %rdx
    6e5f:      	movl	$0x13, %esi
    6e64:      	xorl	%eax, %eax
    6e66:      	callq	*%rcx
    6e68:      	movq	0x60(%rsp), %rax
    6e6d:      	jmp	0x164a <perf_unwind_perl+0x164a>
    6e72:      	movq	(%rip), %rax            # 0x6e79 <perf_unwind_perl+0x6e79>
    6e79:      	cmpl	$0x0, (%rax)
    6e7c:      	je	0x2e32 <perf_unwind_perl+0x2e32>
    6e82:      	movabsq	$0xa782578302f78, %rax  # imm = 0xA782578302F78
    6e8c:      	movq	%rax, 0x2e(%rsp)
    6e91:      	movabsq	$0x2f78257830207367, %rax # imm = 0x2F78257830207367
    6e9b:      	movq	%rax, 0x28(%rsp)
    6ea0:      	movabsq	$0x616c66202c564320, %rax # imm = 0x616C66202C564320
    6eaa:      	movq	%rax, 0x20(%rsp)
    6eaf:      	movabsq	$0x44454d414e206465, %rax # imm = 0x44454D414E206465
    6eb9:      	movq	%rax, 0x18(%rsp)
    6ebe:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    6ec8:      	movq	%rax, 0x10(%rsp)
    6ecd:      	leaq	0x10(%rsp), %rdi
    6ed2:      	movl	$0x26, %eax
    6ed7:      	movl	$0x6, %r8d
    6edd:      	movl	0x5c(%rsp), %edx
    6ee1:      	movl	0x70(%rsp), %ecx
    6ee5:      	movl	$0x26, %esi
    6eea:      	xorl	%eax, %eax
    6eec:      	callq	*%r8
    6eef:      	jmp	0x2e32 <perf_unwind_perl+0x2e32>
    6ef4:      	movq	(%rip), %rax            # 0x6efb <perf_unwind_perl+0x6efb>
    6efb:      	cmpl	$0x0, (%rax)
    6efe:      	je	0x4331 <perf_unwind_perl+0x4331>
    6f04:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    6f0e:      	movq	%rax, 0x26(%rsp)
    6f13:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    6f1d:      	movq	%rax, 0x20(%rsp)
    6f22:      	movabsq	$0x5643565020612074, %rax # imm = 0x5643565020612074
    6f2c:      	movq	%rax, 0x18(%rsp)
    6f31:      	movabsq	$0x6f6e207369205643, %rax # imm = 0x6F6E207369205643
    6f3b:      	movq	%rax, 0x10(%rsp)
    6f40:      	leaq	0x10(%rsp), %rdi
    6f45:      	movl	$0x1e, %eax
    6f4a:      	movl	$0x6, %ecx
    6f4f:      	movl	0x5c(%rsp), %edx
    6f53:      	movl	$0x1e, %esi
    6f58:      	xorl	%eax, %eax
    6f5a:      	callq	*%rcx
    6f5c:      	jmp	0x4331 <perf_unwind_perl+0x4331>
    6f61:      	movabsq	$0x7825783020786320, %rax # imm = 0x7825783020786320
    6f6b:      	movq	%rax, 0x18(%rsp)
    6f70:      	movabsq	$0x6c72657020746f47, %rax # imm = 0x6C72657020746F47
    6f7a:      	movq	%rax, 0x10(%rsp)
    6f7f:      	movw	$0xa, 0x20(%rsp)
    6f86:      	leaq	0x10(%rsp), %rdi
    6f8b:      	movl	$0x12, %eax
    6f90:      	movl	$0x6, %ecx
    6f95:      	movzbl	0xe(%rsp), %edx
    6f9a:      	movl	$0x12, %esi
    6f9f:      	xorl	%eax, %eax
    6fa1:      	callq	*%rcx
    6fa3:      	jmp	0x3445 <perf_unwind_perl+0x3445>
    6fa8:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    6fb2:      	movq	%rax, 0x36(%rsp)
    6fb7:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    6fc1:      	movq	%rax, 0x30(%rsp)
    6fc6:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    6fd0:      	movq	%rax, 0x28(%rsp)
    6fd5:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    6fdf:      	movq	%rax, 0x20(%rsp)
    6fe4:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    6fee:      	movq	%rax, 0x18(%rsp)
    6ff3:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6ffd:      	movq	%rax, 0x10(%rsp)
    7002:      	leaq	0x10(%rsp), %rdi
    7007:      	movl	$0x2e, %eax
    700c:      	movl	$0x6, %ecx
    7011:      	movl	0x50(%rsp), %edx
    7015:      	movl	$0x2e, %esi
    701a:      	xorl	%eax, %eax
    701c:      	callq	*%rcx
    701e:      	cmpl	$0x3, %ebp
    7021:      	movq	0x98(%rsp), %rcx
    7029:      	je	0x3904 <perf_unwind_perl+0x3904>
    702f:      	jmp	0x5636 <perf_unwind_perl+0x5636>
    7034:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    703e:      	movq	%rax, 0x36(%rsp)
    7043:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    704d:      	movq	%rax, 0x30(%rsp)
    7052:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    705c:      	movq	%rax, 0x28(%rsp)
    7061:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    706b:      	movq	%rax, 0x20(%rsp)
    7070:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    707a:      	movq	%rax, 0x18(%rsp)
    707f:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7089:      	movq	%rax, 0x10(%rsp)
    708e:      	leaq	0x10(%rsp), %rdi
    7093:      	movl	$0x2e, %eax
    7098:      	movl	$0x6, %ecx
    709d:      	movl	0x50(%rsp), %edx
    70a1:      	movl	$0x2e, %esi
    70a6:      	xorl	%eax, %eax
    70a8:      	callq	*%rcx
    70aa:      	jmp	0x365c <perf_unwind_perl+0x365c>
    70af:      	movabsq	$0xa7667655f7663, %rax  # imm = 0xA7667655F7663
    70b9:      	movq	%rax, 0x35(%rsp)
    70be:      	movabsq	$0x5f76635f65766c6f, %rax # imm = 0x5F76635F65766C6F
    70c8:      	movq	%rax, 0x30(%rsp)
    70cd:      	movabsq	$0x736572206e692029, %rax # imm = 0x736572206E692029
    70d7:      	movq	%rax, 0x28(%rsp)
    70dc:      	movabsq	$0x28726573755f6461, %rax # imm = 0x28726573755F6461
    70e6:      	movq	%rax, 0x20(%rsp)
    70eb:      	movabsq	$0x65725f65626f7270, %rax # imm = 0x65725F65626F7270
    70f5:      	movq	%rax, 0x18(%rsp)
    70fa:      	movabsq	$0x5f66706220646142, %rax # imm = 0x5F66706220646142
    7104:      	movq	%rax, 0x10(%rsp)
    7109:      	leaq	0x10(%rsp), %rdi
    710e:      	movl	$0x2d, %eax
    7113:      	movl	$0x6, %ecx
    7118:      	movl	$0x2d, %esi
    711d:      	xorl	%eax, %eax
    711f:      	callq	*%rcx
    7121:      	jmp	0x205b <perf_unwind_perl+0x205b>
    7126:      	movl	0x5c(%rsp), %eax
    712a:      	andl	$0x1f, %eax
    712d:      	cmpl	$0xd, %eax
    7130:      	jne	0x76a5 <perf_unwind_perl+0x76a5>
    7136:      	movzbl	0x1f(%r14), %eax
    713b:      	addq	%rbp, %rax
    713e:      	leaq	0x50(%rsp), %rdi
    7143:      	movl	$0x8, %ecx
    7148:      	movl	$0x70, %r8d
    714e:      	movzbl	0x1f(%r14), %edx
    7153:      	addq	%rbp, %rdx
    7156:      	movl	$0x8, %esi
    715b:      	callq	*%r8
    715e:      	testq	%rax, %rax
    7161:      	jne	0x529f <perf_unwind_perl+0x529f>
    7167:      	movzbl	0x21(%r14), %eax
    716c:      	addq	0x50(%rsp), %rax
    7171:      	leaq	0x70(%rsp), %rdi
    7176:      	movl	$0x4, %ecx
    717b:      	movl	$0x70, %r8d
    7181:      	movzbl	0x21(%r14), %edx
    7186:      	addq	0x50(%rsp), %rdx
    718b:      	movl	$0x4, %esi
    7190:      	callq	*%r8
    7193:      	testq	%rax, %rax
    7196:      	jne	0x529f <perf_unwind_perl+0x529f>
    719c:      	testb	$-0x80, 0x71(%rsp)
    71a1:      	jne	0x8422 <perf_unwind_perl+0x8422>
    71a7:      	movzbl	0x22(%r14), %eax
    71ac:      	addq	0x50(%rsp), %rax
    71b1:      	leaq	0x60(%rsp), %rbp
    71b6:      	movl	$0x8, %ecx
    71bb:      	movl	$0x70, %r8d
    71c1:      	movzbl	0x22(%r14), %edx
    71c6:      	addq	0x50(%rsp), %rdx
    71cb:      	movq	%rbp, %rdi
    71ce:      	movl	$0x8, %esi
    71d3:      	callq	*%r8
    71d6:      	testq	%rax, %rax
    71d9:      	jne	0x529f <perf_unwind_perl+0x529f>
    71df:      	movq	0x60(%rsp), %rax
    71e4:      	testq	%rax, %rax
    71e7:      	je	0x529f <perf_unwind_perl+0x529f>
    71ed:      	movq	(%rip), %rcx            # 0x71f4 <perf_unwind_perl+0x71f4>
    71f4:      	cmpl	$0x0, (%rcx)
    71f7:      	jne	0x8faf <perf_unwind_perl+0x8faf>
    71fd:      	movzbl	0x1e(%r14), %ecx
    7202:      	addq	%rax, %rcx
    7205:      	leaq	0x6c(%rsp), %rdi
    720a:      	movl	$0x4, %eax
    720f:      	movl	$0x70, %r8d
    7215:      	movzbl	0x1e(%r14), %edx
    721a:      	addq	0x60(%rsp), %rdx
    721f:      	movl	$0x4, %esi
    7224:      	callq	*%r8
    7227:      	testq	%rax, %rax
    722a:      	jne	0x529f <perf_unwind_perl+0x529f>
    7230:      	movl	$0x801f, %eax           # imm = 0x801F
    7235:      	andl	0x6c(%rsp), %eax
    7239:      	cmpl	$0x8009, %eax           # imm = 0x8009
    723e:      	jne	0x89e6 <perf_unwind_perl+0x89e6>
    7244:      	movzbl	0x20(%r14), %eax
    7249:      	addq	0x60(%rsp), %rax
    724e:      	leaq	0x88(%rsp), %rdi
    7256:      	movl	$0x8, %ecx
    725b:      	movl	$0x70, %r8d
    7261:      	movzbl	0x20(%r14), %edx
    7266:      	addq	0x60(%rsp), %rdx
    726b:      	movl	$0x8, %esi
    7270:      	callq	*%r8
    7273:      	testq	%rax, %rax
    7276:      	jne	0x529f <perf_unwind_perl+0x529f>
    727c:      	movzbl	0x23(%r14), %eax
    7281:      	addq	0x88(%rsp), %rax
    7289:      	leaq	0x78(%rsp), %rdi
    728e:      	movl	$0x8, %ecx
    7293:      	movl	$0x70, %r8d
    7299:      	movzbl	0x23(%r14), %edx
    729e:      	addq	0x88(%rsp), %rdx
    72a6:      	movl	$0x8, %esi
    72ab:      	callq	*%r8
    72ae:      	testq	%rax, %rax
    72b1:      	jne	0x529f <perf_unwind_perl+0x529f>
    72b7:      	movq	0x78(%rsp), %rax
    72bc:      	movq	%rax, 0x80(%rsp)
    72c4:      	testq	%rax, %rax
    72c7:      	je	0x731d <perf_unwind_perl+0x731d>
    72c9:      	movq	(%rip), %rax            # 0x72d0 <perf_unwind_perl+0x72d0>
    72d0:      	cmpl	$0x0, (%rax)
    72d3:      	je	0x7332 <perf_unwind_perl+0x7332>
    72d5:      	movabsq	$0x2578302074612056, %rax # imm = 0x2578302074612056
    72df:      	movq	%rax, 0x18(%rsp)
    72e4:      	movabsq	$0x474520646e756f46, %rax # imm = 0x474520646E756F46
    72ee:      	movq	%rax, 0x10(%rsp)
    72f3:      	movl	$0xa786c, 0x20(%rsp)    # imm = 0xA786C
    72fb:      	leaq	0x10(%rsp), %rdi
    7300:      	movl	$0x14, %eax
    7305:      	movl	$0x6, %ecx
    730a:      	movq	0x78(%rsp), %rdx
    730f:      	movl	$0x14, %esi
    7314:      	xorl	%eax, %eax
    7316:      	callq	*%rcx
    7318:      	leaq	0x78(%rsp), %rbp
    731d:      	movq	(%rbp), %rax
    7321:      	movq	%rax, 0x80(%rsp)
    7329:      	testq	%rax, %rax
    732c:      	je	0x4caa <perf_unwind_perl+0x4caa>
    7332:      	movq	(%r12), %rax
    7336:      	movq	%rax, 0x90(%rsp)
    733e:      	movq	(%rip), %rax            # 0x7345 <perf_unwind_perl+0x7345>
    7345:      	cmpl	$0x0, (%rax)
    7348:      	jne	0x915f <perf_unwind_perl+0x915f>
    734e:      	movl	0x2c0(%r15), %eax
    7355:      	cmpq	$0x7e, %rax
    7359:      	ja	0x1193 <perf_unwind_perl+0x1193>
    735f:      	xorl	%ecx, %ecx
    7361:      	movzbl	0xf(%rsp), %edx
    7366:      	movb	%dl, %cl
    7368:      	leal	0x1(,%rcx,2), %ebp
    736f:      	leal	0x1(%rax), %ecx
    7372:      	movl	%ecx, 0x2c0(%r15)
    7379:      	leaq	(%rax,%rax,2), %rax
    737d:      	movq	0x80(%rsp), %rcx
    7385:      	movq	%rcx, 0x2d0(%r15,%rax,8)
    738d:      	movq	0x90(%rsp), %rcx
    7395:      	movq	%rcx, 0x2d8(%r15,%rax,8)
    739d:      	movb	$0x7, 0x2e0(%r15,%rax,8)
    73a6:      	movl	$0x0, 0x2e1(%r15,%rax,8)
    73b2:      	movl	$0x0, 0x2e4(%r15,%rax,8)
    73be:      	movq	$0x0, 0xf40(%r15)
    73c9:      	movzbl	0x1a(%r14), %eax
    73ce:      	addq	%r13, %rax
    73d1:      	movl	$0x8, %ecx
    73d6:      	movl	$0x70, %r8d
    73dc:      	movzbl	0x1a(%r14), %edx
    73e1:      	addq	%r13, %rdx
    73e4:      	movq	%r12, %rdi
    73e7:      	movl	$0x8, %esi
    73ec:      	callq	*%r8
    73ef:      	testq	%rax, %rax
    73f2:      	jne	0x4caa <perf_unwind_perl+0x4caa>
    73f8:      	movq	(%rip), %rax            # 0x73ff <perf_unwind_perl+0x73ff>
    73ff:      	cmpl	$0x0, (%rax)
    7402:      	je	0x55c6 <perf_unwind_perl+0x55c6>
    7408:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    7412:      	movq	%rax, 0x26(%rsp)
    7417:      	movabsq	$0x30206b6361747320, %rax # imm = 0x30206B6361747320
    7421:      	movq	%rax, 0x20(%rsp)
    7426:      	movabsq	$0x747865746e6f6320, %rax # imm = 0x747865746E6F6320
    7430:      	movq	%rax, 0x18(%rsp)
    7435:      	movabsq	$0x6d6f726620504f43, %rax # imm = 0x6D6F726620504F43
    743f:      	movq	%rax, 0x10(%rsp)
    7444:      	leaq	0x10(%rsp), %rdi
    7449:      	movl	$0x1e, %eax
    744e:      	movl	$0x6, %ecx
    7453:      	movq	(%r12), %rdx
    7457:      	movl	$0x1e, %esi
    745c:      	xorl	%eax, %eax
    745e:      	callq	*%rcx
    7460:      	jmp	0x55c6 <perf_unwind_perl+0x55c6>
    7465:      	movabsq	$0x7025207461207972, %rax # imm = 0x7025207461207972
    746f:      	movq	%rax, 0x30(%rsp)
    7474:      	movabsq	$0x746e65206b636174, %rax # imm = 0x746E65206B636174
    747e:      	movq	%rax, 0x28(%rsp)
    7483:      	movabsq	$0x7320747865746e6f, %rax # imm = 0x7320747865746E6F
    748d:      	movq	%rax, 0x20(%rsp)
    7492:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    749c:      	movq	%rax, 0x18(%rsp)
    74a1:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    74ab:      	movq	%rax, 0x10(%rsp)
    74b0:      	movw	$0xa, 0x38(%rsp)
    74b7:      	leaq	0x10(%rsp), %rdi
    74bc:      	movl	$0x2a, %eax
    74c1:      	movl	$0x6, %ecx
    74c6:      	movl	$0x2a, %esi
    74cb:      	movq	%r13, %rdx
    74ce:      	xorl	%eax, %eax
    74d0:      	callq	*%rcx
    74d2:      	jmp	0x3955 <perf_unwind_perl+0x3955>
    74d7:      	movq	(%rip), %rax            # 0x74de <perf_unwind_perl+0x74de>
    74de:      	cmpl	$0x0, (%rax)
    74e1:      	je	0x2528 <perf_unwind_perl+0x2528>
    74e7:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    74f1:      	movq	%rax, 0x2e(%rsp)
    74f6:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    7500:      	movq	%rax, 0x28(%rsp)
    7505:      	movabsq	$0x50472d74756f6874, %rax # imm = 0x50472D74756F6874
    750f:      	movq	%rax, 0x20(%rsp)
    7514:      	movabsq	$0x69772d5647206465, %rax # imm = 0x69772D5647206465
    751e:      	movq	%rax, 0x18(%rsp)
    7523:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    752d:      	movq	%rax, 0x10(%rsp)
    7532:      	leaq	0x10(%rsp), %rdi
    7537:      	movl	$0x26, %eax
    753c:      	movl	$0x6, %ecx
    7541:      	movl	0x6c(%rsp), %edx
    7545:      	movl	$0x26, %esi
    754a:      	jmp	0x4b2c <perf_unwind_perl+0x4b2c>
    754f:      	movq	(%rip), %rax            # 0x7556 <perf_unwind_perl+0x7556>
    7556:      	cmpl	$0x0, (%rax)
    7559:      	je	0x4caa <perf_unwind_perl+0x4caa>
    755f:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    7569:      	movq	%rax, 0x36(%rsp)
    756e:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    7578:      	movq	%rax, 0x30(%rsp)
    757d:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    7587:      	movq	%rax, 0x28(%rsp)
    758c:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    7596:      	movq	%rax, 0x20(%rsp)
    759b:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    75a5:      	movq	%rax, 0x18(%rsp)
    75aa:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    75b4:      	movq	%rax, 0x10(%rsp)
    75b9:      	leaq	0x10(%rsp), %rdi
    75be:      	movl	$0x2e, %eax
    75c3:      	movl	$0x6, %ecx
    75c8:      	movl	0x74(%rsp), %edx
    75cc:      	movl	$0x2e, %esi
    75d1:      	jmp	0x7709 <perf_unwind_perl+0x7709>
    75d6:      	movabsq	$0x6c25783020746120, %rax # imm = 0x6C25783020746120
    75e0:      	movq	%rax, 0x18(%rsp)
    75e5:      	movabsq	$0x564720646e756f46, %rax # imm = 0x564720646E756F46
    75ef:      	movq	%rax, 0x10(%rsp)
    75f4:      	movl	$0xa786c, 0x1f(%rsp)    # imm = 0xA786C
    75fc:      	leaq	0x10(%rsp), %rdi
    7601:      	movl	$0x13, %eax
    7606:      	movl	$0x6, %ecx
    760b:      	movq	0x60(%rsp), %rdx
    7610:      	movl	$0x13, %esi
    7615:      	xorl	%eax, %eax
    7617:      	callq	*%rcx
    7619:      	movq	0x60(%rsp), %rax
    761e:      	jmp	0x1c95 <perf_unwind_perl+0x1c95>
    7623:      	movq	(%rip), %rax            # 0x762a <perf_unwind_perl+0x762a>
    762a:      	cmpl	$0x0, (%rax)
    762d:      	je	0x3945 <perf_unwind_perl+0x3945>
    7633:      	movabsq	$0xa782578302f78, %rax  # imm = 0xA782578302F78
    763d:      	movq	%rax, 0x2e(%rsp)
    7642:      	movabsq	$0x2f78257830207367, %rax # imm = 0x2F78257830207367
    764c:      	movq	%rax, 0x28(%rsp)
    7651:      	movabsq	$0x616c66202c564320, %rax # imm = 0x616C66202C564320
    765b:      	movq	%rax, 0x20(%rsp)
    7660:      	movabsq	$0x44454d414e206465, %rax # imm = 0x44454D414E206465
    766a:      	movq	%rax, 0x18(%rsp)
    766f:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    7679:      	movq	%rax, 0x10(%rsp)
    767e:      	leaq	0x10(%rsp), %rdi
    7683:      	movl	$0x26, %eax
    7688:      	movl	$0x6, %r8d
    768e:      	movl	0x5c(%rsp), %edx
    7692:      	movl	0x70(%rsp), %ecx
    7696:      	movl	$0x26, %esi
    769b:      	xorl	%eax, %eax
    769d:      	callq	*%r8
    76a0:      	jmp	0x3945 <perf_unwind_perl+0x3945>
    76a5:      	movq	(%rip), %rax            # 0x76ac <perf_unwind_perl+0x76ac>
    76ac:      	cmpl	$0x0, (%rax)
    76af:      	je	0x4caa <perf_unwind_perl+0x4caa>
    76b5:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    76bf:      	movq	%rax, 0x26(%rsp)
    76c4:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    76ce:      	movq	%rax, 0x20(%rsp)
    76d3:      	movabsq	$0x5643565020612074, %rax # imm = 0x5643565020612074
    76dd:      	movq	%rax, 0x18(%rsp)
    76e2:      	movabsq	$0x6f6e207369205643, %rax # imm = 0x6F6E207369205643
    76ec:      	movq	%rax, 0x10(%rsp)
    76f1:      	leaq	0x10(%rsp), %rdi
    76f6:      	movl	$0x1e, %eax
    76fb:      	movl	$0x6, %ecx
    7700:      	movl	0x5c(%rsp), %edx
    7704:      	movl	$0x1e, %esi
    7709:      	xorl	%eax, %eax
    770b:      	callq	*%rcx
    770d:      	jmp	0x4caa <perf_unwind_perl+0x4caa>
    7712:      	movabsq	$0x7825783020786320, %rax # imm = 0x7825783020786320
    771c:      	movq	%rax, 0x18(%rsp)
    7721:      	movabsq	$0x6c72657020746f47, %rax # imm = 0x6C72657020746F47
    772b:      	movq	%rax, 0x10(%rsp)
    7730:      	movw	$0xa, 0x20(%rsp)
    7737:      	leaq	0x10(%rsp), %rdi
    773c:      	movl	$0x12, %eax
    7741:      	movl	$0x6, %ecx
    7746:      	movzbl	0xe(%rsp), %edx
    774b:      	movl	$0x12, %esi
    7750:      	xorl	%eax, %eax
    7752:      	callq	*%rcx
    7754:      	jmp	0x3e39 <perf_unwind_perl+0x3e39>
    7759:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    7763:      	movq	%rax, 0x36(%rsp)
    7768:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    7772:      	movq	%rax, 0x30(%rsp)
    7777:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    7781:      	movq	%rax, 0x28(%rsp)
    7786:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    7790:      	movq	%rax, 0x20(%rsp)
    7795:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    779f:      	movq	%rax, 0x18(%rsp)
    77a4:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    77ae:      	movq	%rax, 0x10(%rsp)
    77b3:      	leaq	0x10(%rsp), %rdi
    77b8:      	movl	$0x2e, %eax
    77bd:      	movl	$0x6, %ecx
    77c2:      	movl	0x50(%rsp), %edx
    77c6:      	movl	$0x2e, %esi
    77cb:      	xorl	%eax, %eax
    77cd:      	callq	*%rcx
    77cf:      	cmpl	$0x3, %ebp
    77d2:      	movq	0x98(%rsp), %rcx
    77da:      	je	0x42f0 <perf_unwind_perl+0x42f0>
    77e0:      	jmp	0x5636 <perf_unwind_perl+0x5636>
    77e5:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    77ef:      	movq	%rax, 0x36(%rsp)
    77f4:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    77fe:      	movq	%rax, 0x30(%rsp)
    7803:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    780d:      	movq	%rax, 0x28(%rsp)
    7812:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    781c:      	movq	%rax, 0x20(%rsp)
    7821:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    782b:      	movq	%rax, 0x18(%rsp)
    7830:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    783a:      	movq	%rax, 0x10(%rsp)
    783f:      	leaq	0x10(%rsp), %rdi
    7844:      	movl	$0x2e, %eax
    7849:      	movl	$0x6, %ecx
    784e:      	movl	0x50(%rsp), %edx
    7852:      	movl	$0x2e, %esi
    7857:      	xorl	%eax, %eax
    7859:      	callq	*%rcx
    785b:      	jmp	0x40c3 <perf_unwind_perl+0x40c3>
    7860:      	movabsq	$0xa7667655f7663, %rax  # imm = 0xA7667655F7663
    786a:      	movq	%rax, 0x35(%rsp)
    786f:      	movabsq	$0x5f76635f65766c6f, %rax # imm = 0x5F76635F65766C6F
    7879:      	movq	%rax, 0x30(%rsp)
    787e:      	movabsq	$0x736572206e692029, %rax # imm = 0x736572206E692029
    7888:      	movq	%rax, 0x28(%rsp)
    788d:      	movabsq	$0x28726573755f6461, %rax # imm = 0x28726573755F6461
    7897:      	movq	%rax, 0x20(%rsp)
    789c:      	movabsq	$0x65725f65626f7270, %rax # imm = 0x65725F65626F7270
    78a6:      	movq	%rax, 0x18(%rsp)
    78ab:      	movabsq	$0x5f66706220646142, %rax # imm = 0x5F66706220646142
    78b5:      	movq	%rax, 0x10(%rsp)
    78ba:      	leaq	0x10(%rsp), %rdi
    78bf:      	movl	$0x2d, %eax
    78c4:      	movl	$0x6, %ecx
    78c9:      	movl	$0x2d, %esi
    78ce:      	xorl	%eax, %eax
    78d0:      	callq	*%rcx
    78d2:      	jmp	0x2b01 <perf_unwind_perl+0x2b01>
    78d7:      	movl	0x5c(%rsp), %eax
    78db:      	andl	$0x1f, %eax
    78de:      	cmpl	$0xd, %eax
    78e1:      	jne	0x7fb3 <perf_unwind_perl+0x7fb3>
    78e7:      	movzbl	0x1f(%r14), %eax
    78ec:      	addq	%rbp, %rax
    78ef:      	leaq	0x50(%rsp), %rdi
    78f4:      	movl	$0x8, %ecx
    78f9:      	movl	$0x70, %r8d
    78ff:      	movzbl	0x1f(%r14), %edx
    7904:      	addq	%rbp, %rdx
    7907:      	movl	$0x8, %esi
    790c:      	callq	*%r8
    790f:      	testq	%rax, %rax
    7912:      	jne	0x6450 <perf_unwind_perl+0x6450>
    7918:      	movzbl	0x21(%r14), %eax
    791d:      	addq	0x50(%rsp), %rax
    7922:      	leaq	0x70(%rsp), %rdi
    7927:      	movl	$0x4, %ecx
    792c:      	movl	$0x70, %r8d
    7932:      	movzbl	0x21(%r14), %edx
    7937:      	addq	0x50(%rsp), %rdx
    793c:      	movl	$0x4, %esi
    7941:      	callq	*%r8
    7944:      	testq	%rax, %rax
    7947:      	jne	0x6450 <perf_unwind_perl+0x6450>
    794d:      	testb	$-0x80, 0x71(%rsp)
    7952:      	jne	0x882b <perf_unwind_perl+0x882b>
    7958:      	movzbl	0x22(%r14), %eax
    795d:      	addq	0x50(%rsp), %rax
    7962:      	leaq	0x60(%rsp), %rbp
    7967:      	movl	$0x8, %ecx
    796c:      	movl	$0x70, %r8d
    7972:      	movzbl	0x22(%r14), %edx
    7977:      	addq	0x50(%rsp), %rdx
    797c:      	movq	%rbp, %rdi
    797f:      	movl	$0x8, %esi
    7984:      	callq	*%r8
    7987:      	testq	%rax, %rax
    798a:      	jne	0x6450 <perf_unwind_perl+0x6450>
    7990:      	movq	0x60(%rsp), %rax
    7995:      	testq	%rax, %rax
    7998:      	je	0x6450 <perf_unwind_perl+0x6450>
    799e:      	movq	(%rip), %rcx            # 0x79a5 <perf_unwind_perl+0x79a5>
    79a5:      	cmpl	$0x0, (%rcx)
    79a8:      	jne	0x9087 <perf_unwind_perl+0x9087>
    79ae:      	movzbl	0x1e(%r14), %ecx
    79b3:      	addq	%rax, %rcx
    79b6:      	leaq	0x6c(%rsp), %rdi
    79bb:      	movl	$0x4, %eax
    79c0:      	movl	$0x70, %r8d
    79c6:      	movzbl	0x1e(%r14), %edx
    79cb:      	addq	0x60(%rsp), %rdx
    79d0:      	movl	$0x4, %esi
    79d5:      	callq	*%r8
    79d8:      	testq	%rax, %rax
    79db:      	jne	0x6450 <perf_unwind_perl+0x6450>
    79e1:      	movl	$0x801f, %eax           # imm = 0x801F
    79e6:      	andl	0x6c(%rsp), %eax
    79ea:      	cmpl	$0x8009, %eax           # imm = 0x8009
    79ef:      	jne	0x8bad <perf_unwind_perl+0x8bad>
    79f5:      	movzbl	0x20(%r14), %eax
    79fa:      	addq	0x60(%rsp), %rax
    79ff:      	leaq	0x88(%rsp), %rdi
    7a07:      	movl	$0x8, %ecx
    7a0c:      	movl	$0x70, %r8d
    7a12:      	movzbl	0x20(%r14), %edx
    7a17:      	addq	0x60(%rsp), %rdx
    7a1c:      	movl	$0x8, %esi
    7a21:      	callq	*%r8
    7a24:      	testq	%rax, %rax
    7a27:      	jne	0x6450 <perf_unwind_perl+0x6450>
    7a2d:      	movzbl	0x23(%r14), %eax
    7a32:      	addq	0x88(%rsp), %rax
    7a3a:      	leaq	0x78(%rsp), %rdi
    7a3f:      	movl	$0x8, %ecx
    7a44:      	movl	$0x70, %r8d
    7a4a:      	movzbl	0x23(%r14), %edx
    7a4f:      	addq	0x88(%rsp), %rdx
    7a57:      	movl	$0x8, %esi
    7a5c:      	callq	*%r8
    7a5f:      	testq	%rax, %rax
    7a62:      	jne	0x6450 <perf_unwind_perl+0x6450>
    7a68:      	movq	0x78(%rsp), %rax
    7a6d:      	movq	%rax, 0x80(%rsp)
    7a75:      	testq	%rax, %rax
    7a78:      	je	0x7ace <perf_unwind_perl+0x7ace>
    7a7a:      	movq	(%rip), %rax            # 0x7a81 <perf_unwind_perl+0x7a81>
    7a81:      	cmpl	$0x0, (%rax)
    7a84:      	je	0x7ae3 <perf_unwind_perl+0x7ae3>
    7a86:      	movabsq	$0x2578302074612056, %rax # imm = 0x2578302074612056
    7a90:      	movq	%rax, 0x18(%rsp)
    7a95:      	movabsq	$0x474520646e756f46, %rax # imm = 0x474520646E756F46
    7a9f:      	movq	%rax, 0x10(%rsp)
    7aa4:      	movl	$0xa786c, 0x20(%rsp)    # imm = 0xA786C
    7aac:      	leaq	0x10(%rsp), %rdi
    7ab1:      	movl	$0x14, %eax
    7ab6:      	movl	$0x6, %ecx
    7abb:      	movq	0x78(%rsp), %rdx
    7ac0:      	movl	$0x14, %esi
    7ac5:      	xorl	%eax, %eax
    7ac7:      	callq	*%rcx
    7ac9:      	leaq	0x78(%rsp), %rbp
    7ace:      	movq	(%rbp), %rax
    7ad2:      	movq	%rax, 0x80(%rsp)
    7ada:      	testq	%rax, %rax
    7add:      	je	0x5e90 <perf_unwind_perl+0x5e90>
    7ae3:      	movq	(%r12), %rax
    7ae7:      	movq	%rax, 0x90(%rsp)
    7aef:      	movq	(%rip), %rax            # 0x7af6 <perf_unwind_perl+0x7af6>
    7af6:      	cmpl	$0x0, (%rax)
    7af9:      	jne	0x91ea <perf_unwind_perl+0x91ea>
    7aff:      	movl	0x2c0(%r15), %eax
    7b06:      	cmpq	$0x7e, %rax
    7b0a:      	ja	0x1193 <perf_unwind_perl+0x1193>
    7b10:      	xorl	%ecx, %ecx
    7b12:      	movzbl	0xf(%rsp), %edx
    7b17:      	movb	%dl, %cl
    7b19:      	leal	0x1(,%rcx,2), %ebp
    7b20:      	leal	0x1(%rax), %ecx
    7b23:      	movl	%ecx, 0x2c0(%r15)
    7b2a:      	leaq	(%rax,%rax,2), %rax
    7b2e:      	movq	0x80(%rsp), %rcx
    7b36:      	movq	%rcx, 0x2d0(%r15,%rax,8)
    7b3e:      	movq	0x90(%rsp), %rcx
    7b46:      	movq	%rcx, 0x2d8(%r15,%rax,8)
    7b4e:      	movb	$0x7, 0x2e0(%r15,%rax,8)
    7b57:      	movl	$0x0, 0x2e1(%r15,%rax,8)
    7b63:      	movl	$0x0, 0x2e4(%r15,%rax,8)
    7b6f:      	movq	$0x0, 0xf40(%r15)
    7b7a:      	movzbl	0x1a(%r14), %eax
    7b7f:      	addq	%r13, %rax
    7b82:      	movl	$0x8, %ecx
    7b87:      	movl	$0x70, %r8d
    7b8d:      	movzbl	0x1a(%r14), %edx
    7b92:      	addq	%r13, %rdx
    7b95:      	movq	%r12, %rdi
    7b98:      	movl	$0x8, %esi
    7b9d:      	callq	*%r8
    7ba0:      	testq	%rax, %rax
    7ba3:      	jne	0x5e90 <perf_unwind_perl+0x5e90>
    7ba9:      	movq	(%rip), %rax            # 0x7bb0 <perf_unwind_perl+0x7bb0>
    7bb0:      	cmpl	$0x0, (%rax)
    7bb3:      	je	0x67c4 <perf_unwind_perl+0x67c4>
    7bb9:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    7bc3:      	movq	%rax, 0x26(%rsp)
    7bc8:      	movabsq	$0x30206b6361747320, %rax # imm = 0x30206B6361747320
    7bd2:      	movq	%rax, 0x20(%rsp)
    7bd7:      	movabsq	$0x747865746e6f6320, %rax # imm = 0x747865746E6F6320
    7be1:      	movq	%rax, 0x18(%rsp)
    7be6:      	movabsq	$0x6d6f726620504f43, %rax # imm = 0x6D6F726620504F43
    7bf0:      	movq	%rax, 0x10(%rsp)
    7bf5:      	leaq	0x10(%rsp), %rdi
    7bfa:      	movl	$0x1e, %eax
    7bff:      	movl	$0x6, %ecx
    7c04:      	movq	(%r12), %rdx
    7c08:      	movl	$0x1e, %esi
    7c0d:      	xorl	%eax, %eax
    7c0f:      	callq	*%rcx
    7c11:      	jmp	0x67c4 <perf_unwind_perl+0x67c4>
    7c16:      	movabsq	$0x7025207461207972, %rax # imm = 0x7025207461207972
    7c20:      	movq	%rax, 0x30(%rsp)
    7c25:      	movabsq	$0x746e65206b636174, %rax # imm = 0x746E65206B636174
    7c2f:      	movq	%rax, 0x28(%rsp)
    7c34:      	movabsq	$0x7320747865746e6f, %rax # imm = 0x7320747865746E6F
    7c3e:      	movq	%rax, 0x20(%rsp)
    7c43:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    7c4d:      	movq	%rax, 0x18(%rsp)
    7c52:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7c5c:      	movq	%rax, 0x10(%rsp)
    7c61:      	movw	$0xa, 0x38(%rsp)
    7c68:      	leaq	0x10(%rsp), %rdi
    7c6d:      	movl	$0x2a, %eax
    7c72:      	movl	$0x6, %ecx
    7c77:      	movl	$0x2a, %esi
    7c7c:      	movq	%r13, %rdx
    7c7f:      	xorl	%eax, %eax
    7c81:      	callq	*%rcx
    7c83:      	jmp	0x4341 <perf_unwind_perl+0x4341>
    7c88:      	movq	(%rip), %rax            # 0x7c8f <perf_unwind_perl+0x7c8f>
    7c8f:      	cmpl	$0x0, (%rax)
    7c92:      	je	0x2e32 <perf_unwind_perl+0x2e32>
    7c98:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    7ca2:      	movq	%rax, 0x2e(%rsp)
    7ca7:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    7cb1:      	movq	%rax, 0x28(%rsp)
    7cb6:      	movabsq	$0x50472d74756f6874, %rax # imm = 0x50472D74756F6874
    7cc0:      	movq	%rax, 0x20(%rsp)
    7cc5:      	movabsq	$0x69772d5647206465, %rax # imm = 0x69772D5647206465
    7ccf:      	movq	%rax, 0x18(%rsp)
    7cd4:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    7cde:      	movq	%rax, 0x10(%rsp)
    7ce3:      	leaq	0x10(%rsp), %rdi
    7ce8:      	movl	$0x26, %eax
    7ced:      	movl	$0x6, %ecx
    7cf2:      	movl	0x6c(%rsp), %edx
    7cf6:      	movl	$0x26, %esi
    7cfb:      	jmp	0x54da <perf_unwind_perl+0x54da>
    7d00:      	movabsq	$0xa786c2578303d, %rax  # imm = 0xA786C2578303D
    7d0a:      	movq	%rax, 0x30(%rsp)
    7d0f:      	movabsq	$0x7663202c786c2578, %rax # imm = 0x7663202C786C2578
    7d19:      	movq	%rax, 0x28(%rsp)
    7d1e:      	movabsq	$0x303d706f6320656d, %rax # imm = 0x303D706F6320656D
    7d28:      	movq	%rax, 0x20(%rsp)
    7d2d:      	movabsq	$0x617266206c726570, %rax # imm = 0x617266206C726570
    7d37:      	movq	%rax, 0x18(%rsp)
    7d3c:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    7d46:      	movq	%rax, 0x10(%rsp)
    7d4b:      	leaq	0x10(%rsp), %rdi
    7d50:      	movl	$0x28, %eax
    7d55:      	movl	$0x6, %r8d
    7d5b:      	movl	$0x28, %esi
    7d60:      	movq	0x80(%rsp), %rdx
    7d68:      	movq	0x90(%rsp), %rcx
    7d70:      	xorl	%eax, %eax
    7d72:      	callq	*%r8
    7d75:      	movl	0x2c0(%r15), %eax
    7d7c:      	cmpq	$0x7f, %rax
    7d80:      	jae	0x1193 <perf_unwind_perl+0x1193>
    7d86:      	xorl	%ecx, %ecx
    7d88:      	movzbl	0xf(%rsp), %edx
    7d8d:      	movb	%dl, %cl
    7d8f:      	leal	0x1(,%rcx,2), %ebp
    7d96:      	leal	0x1(%rax), %ecx
    7d99:      	movl	%ecx, 0x2c0(%r15)
    7da0:      	leaq	(%rax,%rax,2), %rax
    7da4:      	movq	0x80(%rsp), %rcx
    7dac:      	movq	%rcx, 0x2d0(%r15,%rax,8)
    7db4:      	movq	0x90(%rsp), %rcx
    7dbc:      	movq	%rcx, 0x2d8(%r15,%rax,8)
    7dc4:      	movb	$0x7, 0x2e0(%r15,%rax,8)
    7dcd:      	movl	$0x0, 0x2e1(%r15,%rax,8)
    7dd9:      	movl	$0x0, 0x2e4(%r15,%rax,8)
    7de5:      	movq	$0x0, 0xf40(%r15)
    7df0:      	jmp	0x655 <perf_unwind_perl+0x655>
    7df5:      	movq	(%rip), %rax            # 0x7dfc <perf_unwind_perl+0x7dfc>
    7dfc:      	cmpl	$0x0, (%rax)
    7dff:      	je	0x5e90 <perf_unwind_perl+0x5e90>
    7e05:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    7e0f:      	movq	%rax, 0x36(%rsp)
    7e14:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    7e1e:      	movq	%rax, 0x30(%rsp)
    7e23:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    7e2d:      	movq	%rax, 0x28(%rsp)
    7e32:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    7e3c:      	movq	%rax, 0x20(%rsp)
    7e41:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    7e4b:      	movq	%rax, 0x18(%rsp)
    7e50:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7e5a:      	movq	%rax, 0x10(%rsp)
    7e5f:      	leaq	0x10(%rsp), %rdi
    7e64:      	movl	$0x2e, %eax
    7e69:      	movl	$0x6, %ecx
    7e6e:      	movl	0x74(%rsp), %edx
    7e72:      	movl	$0x2e, %esi
    7e77:      	jmp	0x8017 <perf_unwind_perl+0x8017>
    7e7c:      	movabsq	$0x6c25783020746120, %rax # imm = 0x6C25783020746120
    7e86:      	movq	%rax, 0x18(%rsp)
    7e8b:      	movabsq	$0x564720646e756f46, %rax # imm = 0x564720646E756F46
    7e95:      	movq	%rax, 0x10(%rsp)
    7e9a:      	movl	$0xa786c, 0x1f(%rsp)    # imm = 0xA786C
    7ea2:      	leaq	0x10(%rsp), %rdi
    7ea7:      	movl	$0x13, %eax
    7eac:      	movl	$0x6, %ecx
    7eb1:      	movq	0x60(%rsp), %rdx
    7eb6:      	movl	$0x13, %esi
    7ebb:      	xorl	%eax, %eax
    7ebd:      	callq	*%rcx
    7ebf:      	movq	0x60(%rsp), %rax
    7ec4:      	jmp	0x273b <perf_unwind_perl+0x273b>
    7ec9:      	movq	(%rip), %rax            # 0x7ed0 <perf_unwind_perl+0x7ed0>
    7ed0:      	cmpl	$0x0, (%rax)
    7ed3:      	je	0x4331 <perf_unwind_perl+0x4331>
    7ed9:      	movabsq	$0xa782578302f78, %rax  # imm = 0xA782578302F78
    7ee3:      	movq	%rax, 0x2e(%rsp)
    7ee8:      	movabsq	$0x2f78257830207367, %rax # imm = 0x2F78257830207367
    7ef2:      	movq	%rax, 0x28(%rsp)
    7ef7:      	movabsq	$0x616c66202c564320, %rax # imm = 0x616C66202C564320
    7f01:      	movq	%rax, 0x20(%rsp)
    7f06:      	movabsq	$0x44454d414e206465, %rax # imm = 0x44454D414E206465
    7f10:      	movq	%rax, 0x18(%rsp)
    7f15:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    7f1f:      	movq	%rax, 0x10(%rsp)
    7f24:      	leaq	0x10(%rsp), %rdi
    7f29:      	movl	$0x26, %eax
    7f2e:      	movl	$0x6, %r8d
    7f34:      	movl	0x5c(%rsp), %edx
    7f38:      	movl	0x70(%rsp), %ecx
    7f3c:      	movl	$0x26, %esi
    7f41:      	xorl	%eax, %eax
    7f43:      	callq	*%r8
    7f46:      	jmp	0x4331 <perf_unwind_perl+0x4331>
    7f4b:      	movabsq	$0xa6c6c75662073, %rax  # imm = 0xA6C6C75662073
    7f55:      	movq	%rax, 0x2d(%rsp)
    7f5a:      	movabsq	$0x66207369206b6361, %rax # imm = 0x66207369206B6361
    7f64:      	movq	%rax, 0x28(%rsp)
    7f69:      	movabsq	$0x7473203a656d6172, %rax # imm = 0x7473203A656D6172
    7f73:      	movq	%rax, 0x20(%rsp)
    7f78:      	movabsq	$0x662068737570206f, %rax # imm = 0x662068737570206F
    7f82:      	movq	%rax, 0x18(%rsp)
    7f87:      	movabsq	$0x7420656c62616e75, %rax # imm = 0x7420656C62616E75
    7f91:      	movq	%rax, 0x10(%rsp)
    7f96:      	leaq	0x10(%rsp), %rdi
    7f9b:      	movl	$0x25, %eax
    7fa0:      	movl	$0x6, %ecx
    7fa5:      	movl	$0x25, %esi
    7faa:      	xorl	%eax, %eax
    7fac:      	callq	*%rcx
    7fae:      	jmp	0x11a3 <perf_unwind_perl+0x11a3>
    7fb3:      	movq	(%rip), %rax            # 0x7fba <perf_unwind_perl+0x7fba>
    7fba:      	cmpl	$0x0, (%rax)
    7fbd:      	je	0x5e90 <perf_unwind_perl+0x5e90>
    7fc3:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    7fcd:      	movq	%rax, 0x26(%rsp)
    7fd2:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    7fdc:      	movq	%rax, 0x20(%rsp)
    7fe1:      	movabsq	$0x5643565020612074, %rax # imm = 0x5643565020612074
    7feb:      	movq	%rax, 0x18(%rsp)
    7ff0:      	movabsq	$0x6f6e207369205643, %rax # imm = 0x6F6E207369205643
    7ffa:      	movq	%rax, 0x10(%rsp)
    7fff:      	leaq	0x10(%rsp), %rdi
    8004:      	movl	$0x1e, %eax
    8009:      	movl	$0x6, %ecx
    800e:      	movl	0x5c(%rsp), %edx
    8012:      	movl	$0x1e, %esi
    8017:      	xorl	%eax, %eax
    8019:      	callq	*%rcx
    801b:      	jmp	0x5e90 <perf_unwind_perl+0x5e90>
    8020:      	movabsq	$0x7825783020786320, %rax # imm = 0x7825783020786320
    802a:      	movq	%rax, 0x18(%rsp)
    802f:      	movabsq	$0x6c72657020746f47, %rax # imm = 0x6C72657020746F47
    8039:      	movq	%rax, 0x10(%rsp)
    803e:      	movw	$0xa, 0x20(%rsp)
    8045:      	leaq	0x10(%rsp), %rdi
    804a:      	movl	$0x12, %eax
    804f:      	movl	$0x6, %ecx
    8054:      	movzbl	0xe(%rsp), %edx
    8059:      	movl	$0x12, %esi
    805e:      	xorl	%eax, %eax
    8060:      	callq	*%rcx
    8062:      	jmp	0x4825 <perf_unwind_perl+0x4825>
    8067:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    8071:      	movq	%rax, 0x36(%rsp)
    8076:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    8080:      	movq	%rax, 0x30(%rsp)
    8085:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    808f:      	movq	%rax, 0x28(%rsp)
    8094:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    809e:      	movq	%rax, 0x20(%rsp)
    80a3:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    80ad:      	movq	%rax, 0x18(%rsp)
    80b2:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    80bc:      	movq	%rax, 0x10(%rsp)
    80c1:      	leaq	0x10(%rsp), %rdi
    80c6:      	movl	$0x2e, %eax
    80cb:      	movl	$0x6, %ecx
    80d0:      	movl	0x50(%rsp), %edx
    80d4:      	movl	$0x2e, %esi
    80d9:      	xorl	%eax, %eax
    80db:      	callq	*%rcx
    80dd:      	cmpl	$0x3, %ebp
    80e0:      	movq	0x98(%rsp), %rcx
    80e8:      	je	0x4c69 <perf_unwind_perl+0x4c69>
    80ee:      	jmp	0x5636 <perf_unwind_perl+0x5636>
    80f3:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    80fd:      	movq	%rax, 0x36(%rsp)
    8102:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    810c:      	movq	%rax, 0x30(%rsp)
    8111:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    811b:      	movq	%rax, 0x28(%rsp)
    8120:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    812a:      	movq	%rax, 0x20(%rsp)
    812f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    8139:      	movq	%rax, 0x18(%rsp)
    813e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    8148:      	movq	%rax, 0x10(%rsp)
    814d:      	leaq	0x10(%rsp), %rdi
    8152:      	movl	$0x2e, %eax
    8157:      	movl	$0x6, %ecx
    815c:      	movl	0x50(%rsp), %edx
    8160:      	movl	$0x2e, %esi
    8165:      	xorl	%eax, %eax
    8167:      	callq	*%rcx
    8169:      	jmp	0x4a3c <perf_unwind_perl+0x4a3c>
    816e:      	movabsq	$0xa7667655f7663, %rax  # imm = 0xA7667655F7663
    8178:      	movq	%rax, 0x35(%rsp)
    817d:      	movabsq	$0x5f76635f65766c6f, %rax # imm = 0x5F76635F65766C6F
    8187:      	movq	%rax, 0x30(%rsp)
    818c:      	movabsq	$0x736572206e692029, %rax # imm = 0x736572206E692029
    8196:      	movq	%rax, 0x28(%rsp)
    819b:      	movabsq	$0x28726573755f6461, %rax # imm = 0x28726573755F6461
    81a5:      	movq	%rax, 0x20(%rsp)
    81aa:      	movabsq	$0x65725f65626f7270, %rax # imm = 0x65725F65626F7270
    81b4:      	movq	%rax, 0x18(%rsp)
    81b9:      	movabsq	$0x5f66706220646142, %rax # imm = 0x5F66706220646142
    81c3:      	movq	%rax, 0x10(%rsp)
    81c8:      	leaq	0x10(%rsp), %rdi
    81cd:      	movl	$0x2d, %eax
    81d2:      	movl	$0x6, %ecx
    81d7:      	movl	$0x2d, %esi
    81dc:      	xorl	%eax, %eax
    81de:      	callq	*%rcx
    81e0:      	jmp	0x3521 <perf_unwind_perl+0x3521>
    81e5:      	movabsq	$0x7025207461207972, %rax # imm = 0x7025207461207972
    81ef:      	movq	%rax, 0x30(%rsp)
    81f4:      	movabsq	$0x746e65206b636174, %rax # imm = 0x746E65206B636174
    81fe:      	movq	%rax, 0x28(%rsp)
    8203:      	movabsq	$0x7320747865746e6f, %rax # imm = 0x7320747865746E6F
    820d:      	movq	%rax, 0x20(%rsp)
    8212:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    821c:      	movq	%rax, 0x18(%rsp)
    8221:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    822b:      	movq	%rax, 0x10(%rsp)
    8230:      	movw	$0xa, 0x38(%rsp)
    8237:      	leaq	0x10(%rsp), %rdi
    823c:      	movl	$0x2a, %eax
    8241:      	movl	$0x6, %ecx
    8246:      	movl	$0x2a, %esi
    824b:      	movq	%r13, %rdx
    824e:      	xorl	%eax, %eax
    8250:      	callq	*%rcx
    8252:      	jmp	0x4cba <perf_unwind_perl+0x4cba>
    8257:      	movq	(%rip), %rax            # 0x825e <perf_unwind_perl+0x825e>
    825e:      	cmpl	$0x0, (%rax)
    8261:      	je	0x3945 <perf_unwind_perl+0x3945>
    8267:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    8271:      	movq	%rax, 0x2e(%rsp)
    8276:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    8280:      	movq	%rax, 0x28(%rsp)
    8285:      	movabsq	$0x50472d74756f6874, %rax # imm = 0x50472D74756F6874
    828f:      	movq	%rax, 0x20(%rsp)
    8294:      	movabsq	$0x69772d5647206465, %rax # imm = 0x69772D5647206465
    829e:      	movq	%rax, 0x18(%rsp)
    82a3:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    82ad:      	movq	%rax, 0x10(%rsp)
    82b2:      	leaq	0x10(%rsp), %rdi
    82b7:      	movl	$0x26, %eax
    82bc:      	movl	$0x6, %ecx
    82c1:      	movl	0x6c(%rsp), %edx
    82c5:      	movl	$0x26, %esi
    82ca:      	jmp	0x66d8 <perf_unwind_perl+0x66d8>
    82cf:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    82d9:      	movq	%rax, 0x36(%rsp)
    82de:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    82e8:      	movq	%rax, 0x30(%rsp)
    82ed:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    82f7:      	movq	%rax, 0x28(%rsp)
    82fc:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    8306:      	movq	%rax, 0x20(%rsp)
    830b:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    8315:      	movq	%rax, 0x18(%rsp)
    831a:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    8324:      	movq	%rax, 0x10(%rsp)
    8329:      	leaq	0x10(%rsp), %rdi
    832e:      	movl	$0x2e, %eax
    8333:      	movl	$0x6, %ecx
    8338:      	movl	0x50(%rsp), %edx
    833c:      	movl	$0x2e, %esi
    8341:      	xorl	%eax, %eax
    8343:      	callq	*%rcx
    8345:      	jmp	0x4cfb <perf_unwind_perl+0x4cfb>
    834a:      	movabsq	$0xa786c2578303d, %rax  # imm = 0xA786C2578303D
    8354:      	movq	%rax, 0x30(%rsp)
    8359:      	movabsq	$0x7663202c786c2578, %rax # imm = 0x7663202C786C2578
    8363:      	movq	%rax, 0x28(%rsp)
    8368:      	movabsq	$0x303d706f6320656d, %rax # imm = 0x303D706F6320656D
    8372:      	movq	%rax, 0x20(%rsp)
    8377:      	movabsq	$0x617266206c726570, %rax # imm = 0x617266206C726570
    8381:      	movq	%rax, 0x18(%rsp)
    8386:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    8390:      	movq	%rax, 0x10(%rsp)
    8395:      	leaq	0x10(%rsp), %rdi
    839a:      	movl	$0x28, %eax
    839f:      	movl	$0x6, %r8d
    83a5:      	movl	$0x28, %esi
    83aa:      	movq	0x80(%rsp), %rdx
    83b2:      	movq	0x90(%rsp), %rcx
    83ba:      	xorl	%eax, %eax
    83bc:      	callq	*%r8
    83bf:      	movl	0x2c0(%r15), %eax
    83c6:      	cmpq	$0x7e, %rax
    83ca:      	ja	0x1193 <perf_unwind_perl+0x1193>
    83d0:      	jmp	0x17ac <perf_unwind_perl+0x17ac>
    83d5:      	movabsq	$0x6c25783020746120, %rax # imm = 0x6C25783020746120
    83df:      	movq	%rax, 0x18(%rsp)
    83e4:      	movabsq	$0x564720646e756f46, %rax # imm = 0x564720646E756F46
    83ee:      	movq	%rax, 0x10(%rsp)
    83f3:      	movl	$0xa786c, 0x1f(%rsp)    # imm = 0xA786C
    83fb:      	leaq	0x10(%rsp), %rdi
    8400:      	movl	$0x13, %eax
    8405:      	movl	$0x6, %ecx
    840a:      	movq	0x60(%rsp), %rdx
    840f:      	movl	$0x13, %esi
    8414:      	xorl	%eax, %eax
    8416:      	callq	*%rcx
    8418:      	movq	0x60(%rsp), %rax
    841d:      	jmp	0x315b <perf_unwind_perl+0x315b>
    8422:      	movq	(%rip), %rax            # 0x8429 <perf_unwind_perl+0x8429>
    8429:      	cmpl	$0x0, (%rax)
    842c:      	je	0x4caa <perf_unwind_perl+0x4caa>
    8432:      	movabsq	$0xa782578302f78, %rax  # imm = 0xA782578302F78
    843c:      	movq	%rax, 0x2e(%rsp)
    8441:      	movabsq	$0x2f78257830207367, %rax # imm = 0x2F78257830207367
    844b:      	movq	%rax, 0x28(%rsp)
    8450:      	movabsq	$0x616c66202c564320, %rax # imm = 0x616C66202C564320
    845a:      	movq	%rax, 0x20(%rsp)
    845f:      	movabsq	$0x44454d414e206465, %rax # imm = 0x44454D414E206465
    8469:      	movq	%rax, 0x18(%rsp)
    846e:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    8478:      	movq	%rax, 0x10(%rsp)
    847d:      	leaq	0x10(%rsp), %rdi
    8482:      	movl	$0x26, %eax
    8487:      	movl	$0x6, %r8d
    848d:      	movl	0x5c(%rsp), %edx
    8491:      	movl	0x70(%rsp), %ecx
    8495:      	movl	$0x26, %esi
    849a:      	xorl	%eax, %eax
    849c:      	callq	*%r8
    849f:      	jmp	0x4caa <perf_unwind_perl+0x4caa>
    84a4:      	movabsq	$0x7825783020786320, %rax # imm = 0x7825783020786320
    84ae:      	movq	%rax, 0x18(%rsp)
    84b3:      	movabsq	$0x6c72657020746f47, %rax # imm = 0x6C72657020746F47
    84bd:      	movq	%rax, 0x10(%rsp)
    84c2:      	movw	$0xa, 0x20(%rsp)
    84c9:      	leaq	0x10(%rsp), %rdi
    84ce:      	movl	$0x12, %eax
    84d3:      	movl	$0x6, %ecx
    84d8:      	movzbl	0xe(%rsp), %edx
    84dd:      	movl	$0x12, %esi
    84e2:      	xorl	%eax, %eax
    84e4:      	callq	*%rcx
    84e6:      	jmp	0x51d3 <perf_unwind_perl+0x51d3>
    84eb:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    84f5:      	movq	%rax, 0x36(%rsp)
    84fa:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    8504:      	movq	%rax, 0x30(%rsp)
    8509:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    8513:      	movq	%rax, 0x28(%rsp)
    8518:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    8522:      	movq	%rax, 0x20(%rsp)
    8527:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    8531:      	movq	%rax, 0x18(%rsp)
    8536:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    8540:      	movq	%rax, 0x10(%rsp)
    8545:      	leaq	0x10(%rsp), %rdi
    854a:      	movl	$0x2e, %eax
    854f:      	movl	$0x6, %ecx
    8554:      	movl	0x50(%rsp), %edx
    8558:      	movl	$0x2e, %esi
    855d:      	xorl	%eax, %eax
    855f:      	callq	*%rcx
    8561:      	cmpl	$0x3, %ebp
    8564:      	movq	0x98(%rsp), %rcx
    856c:      	je	0x5621 <perf_unwind_perl+0x5621>
    8572:      	jmp	0x5636 <perf_unwind_perl+0x5636>
    8577:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    8581:      	movq	%rax, 0x36(%rsp)
    8586:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    8590:      	movq	%rax, 0x30(%rsp)
    8595:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    859f:      	movq	%rax, 0x28(%rsp)
    85a4:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    85ae:      	movq	%rax, 0x20(%rsp)
    85b3:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    85bd:      	movq	%rax, 0x18(%rsp)
    85c2:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    85cc:      	movq	%rax, 0x10(%rsp)
    85d1:      	leaq	0x10(%rsp), %rdi
    85d6:      	movl	$0x2e, %eax
    85db:      	movl	$0x6, %ecx
    85e0:      	movl	0x50(%rsp), %edx
    85e4:      	movl	$0x2e, %esi
    85e9:      	xorl	%eax, %eax
    85eb:      	callq	*%rcx
    85ed:      	jmp	0x53ea <perf_unwind_perl+0x53ea>
    85f2:      	movabsq	$0xa7667655f7663, %rax  # imm = 0xA7667655F7663
    85fc:      	movq	%rax, 0x35(%rsp)
    8601:      	movabsq	$0x5f76635f65766c6f, %rax # imm = 0x5F76635F65766C6F
    860b:      	movq	%rax, 0x30(%rsp)
    8610:      	movabsq	$0x736572206e692029, %rax # imm = 0x736572206E692029
    861a:      	movq	%rax, 0x28(%rsp)
    861f:      	movabsq	$0x28726573755f6461, %rax # imm = 0x28726573755F6461
    8629:      	movq	%rax, 0x20(%rsp)
    862e:      	movabsq	$0x65725f65626f7270, %rax # imm = 0x65725F65626F7270
    8638:      	movq	%rax, 0x18(%rsp)
    863d:      	movabsq	$0x5f66706220646142, %rax # imm = 0x5F66706220646142
    8647:      	movq	%rax, 0x10(%rsp)
    864c:      	leaq	0x10(%rsp), %rdi
    8651:      	movl	$0x2d, %eax
    8656:      	movl	$0x6, %ecx
    865b:      	movl	$0x2d, %esi
    8660:      	xorl	%eax, %eax
    8662:      	callq	*%rcx
    8664:      	jmp	0x3f15 <perf_unwind_perl+0x3f15>
    8669:      	movabsq	$0x7025207461207972, %rax # imm = 0x7025207461207972
    8673:      	movq	%rax, 0x30(%rsp)
    8678:      	movabsq	$0x746e65206b636174, %rax # imm = 0x746E65206B636174
    8682:      	movq	%rax, 0x28(%rsp)
    8687:      	movabsq	$0x7320747865746e6f, %rax # imm = 0x7320747865746E6F
    8691:      	movq	%rax, 0x20(%rsp)
    8696:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    86a0:      	movq	%rax, 0x18(%rsp)
    86a5:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    86af:      	movq	%rax, 0x10(%rsp)
    86b4:      	movw	$0xa, 0x38(%rsp)
    86bb:      	leaq	0x10(%rsp), %rdi
    86c0:      	movl	$0x2a, %eax
    86c5:      	movl	$0x6, %ecx
    86ca:      	movl	$0x2a, %esi
    86cf:      	movq	%r13, %rdx
    86d2:      	xorl	%eax, %eax
    86d4:      	callq	*%rcx
    86d6:      	jmp	0x5ea0 <perf_unwind_perl+0x5ea0>
    86db:      	movq	(%rip), %rax            # 0x86e2 <perf_unwind_perl+0x86e2>
    86e2:      	cmpl	$0x0, (%rax)
    86e5:      	je	0x4331 <perf_unwind_perl+0x4331>
    86eb:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    86f5:      	movq	%rax, 0x2e(%rsp)
    86fa:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    8704:      	movq	%rax, 0x28(%rsp)
    8709:      	movabsq	$0x50472d74756f6874, %rax # imm = 0x50472D74756F6874
    8713:      	movq	%rax, 0x20(%rsp)
    8718:      	movabsq	$0x69772d5647206465, %rax # imm = 0x69772D5647206465
    8722:      	movq	%rax, 0x18(%rsp)
    8727:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    8731:      	movq	%rax, 0x10(%rsp)
    8736:      	leaq	0x10(%rsp), %rdi
    873b:      	movl	$0x26, %eax
    8740:      	movl	$0x6, %ecx
    8745:      	movl	0x6c(%rsp), %edx
    8749:      	movl	$0x26, %esi
    874e:      	jmp	0x6f58 <perf_unwind_perl+0x6f58>
    8753:      	movabsq	$0xa786c2578303d, %rax  # imm = 0xA786C2578303D
    875d:      	movq	%rax, 0x30(%rsp)
    8762:      	movabsq	$0x7663202c786c2578, %rax # imm = 0x7663202C786C2578
    876c:      	movq	%rax, 0x28(%rsp)
    8771:      	movabsq	$0x303d706f6320656d, %rax # imm = 0x303D706F6320656D
    877b:      	movq	%rax, 0x20(%rsp)
    8780:      	movabsq	$0x617266206c726570, %rax # imm = 0x617266206C726570
    878a:      	movq	%rax, 0x18(%rsp)
    878f:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    8799:      	movq	%rax, 0x10(%rsp)
    879e:      	leaq	0x10(%rsp), %rdi
    87a3:      	movl	$0x28, %eax
    87a8:      	movl	$0x6, %r8d
    87ae:      	movl	$0x28, %esi
    87b3:      	movq	0x80(%rsp), %rdx
    87bb:      	movq	0x90(%rsp), %rcx
    87c3:      	xorl	%eax, %eax
    87c5:      	callq	*%r8
    87c8:      	movl	0x2c0(%r15), %eax
    87cf:      	cmpq	$0x7e, %rax
    87d3:      	ja	0x1193 <perf_unwind_perl+0x1193>
    87d9:      	jmp	0x1df7 <perf_unwind_perl+0x1df7>
    87de:      	movabsq	$0x6c25783020746120, %rax # imm = 0x6C25783020746120
    87e8:      	movq	%rax, 0x18(%rsp)
    87ed:      	movabsq	$0x564720646e756f46, %rax # imm = 0x564720646E756F46
    87f7:      	movq	%rax, 0x10(%rsp)
    87fc:      	movl	$0xa786c, 0x1f(%rsp)    # imm = 0xA786C
    8804:      	leaq	0x10(%rsp), %rdi
    8809:      	movl	$0x13, %eax
    880e:      	movl	$0x6, %ecx
    8813:      	movq	0x60(%rsp), %rdx
    8818:      	movl	$0x13, %esi
    881d:      	xorl	%eax, %eax
    881f:      	callq	*%rcx
    8821:      	movq	0x60(%rsp), %rax
    8826:      	jmp	0x3b4f <perf_unwind_perl+0x3b4f>
    882b:      	movq	(%rip), %rax            # 0x8832 <perf_unwind_perl+0x8832>
    8832:      	cmpl	$0x0, (%rax)
    8835:      	je	0x5e90 <perf_unwind_perl+0x5e90>
    883b:      	movabsq	$0xa782578302f78, %rax  # imm = 0xA782578302F78
    8845:      	movq	%rax, 0x2e(%rsp)
    884a:      	movabsq	$0x2f78257830207367, %rax # imm = 0x2F78257830207367
    8854:      	movq	%rax, 0x28(%rsp)
    8859:      	movabsq	$0x616c66202c564320, %rax # imm = 0x616C66202C564320
    8863:      	movq	%rax, 0x20(%rsp)
    8868:      	movabsq	$0x44454d414e206465, %rax # imm = 0x44454D414E206465
    8872:      	movq	%rax, 0x18(%rsp)
    8877:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    8881:      	movq	%rax, 0x10(%rsp)
    8886:      	leaq	0x10(%rsp), %rdi
    888b:      	movl	$0x26, %eax
    8890:      	movl	$0x6, %r8d
    8896:      	movl	0x5c(%rsp), %edx
    889a:      	movl	0x70(%rsp), %ecx
    889e:      	movl	$0x26, %esi
    88a3:      	xorl	%eax, %eax
    88a5:      	callq	*%r8
    88a8:      	jmp	0x5e90 <perf_unwind_perl+0x5e90>
    88ad:      	movabsq	$0x7825783020786320, %rax # imm = 0x7825783020786320
    88b7:      	movq	%rax, 0x18(%rsp)
    88bc:      	movabsq	$0x6c72657020746f47, %rax # imm = 0x6C72657020746F47
    88c6:      	movq	%rax, 0x10(%rsp)
    88cb:      	movw	$0xa, 0x20(%rsp)
    88d2:      	leaq	0x10(%rsp), %rdi
    88d7:      	movl	$0x12, %eax
    88dc:      	movl	$0x6, %ecx
    88e1:      	movzbl	0xe(%rsp), %edx
    88e6:      	movl	$0x12, %esi
    88eb:      	xorl	%eax, %eax
    88ed:      	callq	*%rcx
    88ef:      	jmp	0x6384 <perf_unwind_perl+0x6384>
    88f4:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    88fe:      	movq	%rax, 0x36(%rsp)
    8903:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    890d:      	movq	%rax, 0x30(%rsp)
    8912:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    891c:      	movq	%rax, 0x28(%rsp)
    8921:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    892b:      	movq	%rax, 0x20(%rsp)
    8930:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    893a:      	movq	%rax, 0x18(%rsp)
    893f:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    8949:      	movq	%rax, 0x10(%rsp)
    894e:      	leaq	0x10(%rsp), %rdi
    8953:      	movl	$0x2e, %eax
    8958:      	movl	$0x6, %ecx
    895d:      	movl	0x50(%rsp), %edx
    8961:      	movl	$0x2e, %esi
    8966:      	xorl	%eax, %eax
    8968:      	callq	*%rcx
    896a:      	jmp	0x659b <perf_unwind_perl+0x659b>
    896f:      	movabsq	$0xa7667655f7663, %rax  # imm = 0xA7667655F7663
    8979:      	movq	%rax, 0x35(%rsp)
    897e:      	movabsq	$0x5f76635f65766c6f, %rax # imm = 0x5F76635F65766C6F
    8988:      	movq	%rax, 0x30(%rsp)
    898d:      	movabsq	$0x736572206e692029, %rax # imm = 0x736572206E692029
    8997:      	movq	%rax, 0x28(%rsp)
    899c:      	movabsq	$0x28726573755f6461, %rax # imm = 0x28726573755F6461
    89a6:      	movq	%rax, 0x20(%rsp)
    89ab:      	movabsq	$0x65725f65626f7270, %rax # imm = 0x65725F65626F7270
    89b5:      	movq	%rax, 0x18(%rsp)
    89ba:      	movabsq	$0x5f66706220646142, %rax # imm = 0x5F66706220646142
    89c4:      	movq	%rax, 0x10(%rsp)
    89c9:      	leaq	0x10(%rsp), %rdi
    89ce:      	movl	$0x2d, %eax
    89d3:      	movl	$0x6, %ecx
    89d8:      	movl	$0x2d, %esi
    89dd:      	xorl	%eax, %eax
    89df:      	callq	*%rcx
    89e1:      	jmp	0x4901 <perf_unwind_perl+0x4901>
    89e6:      	movq	(%rip), %rax            # 0x89ed <perf_unwind_perl+0x89ed>
    89ed:      	cmpl	$0x0, (%rax)
    89f0:      	je	0x4caa <perf_unwind_perl+0x4caa>
    89f6:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    8a00:      	movq	%rax, 0x2e(%rsp)
    8a05:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    8a0f:      	movq	%rax, 0x28(%rsp)
    8a14:      	movabsq	$0x50472d74756f6874, %rax # imm = 0x50472D74756F6874
    8a1e:      	movq	%rax, 0x20(%rsp)
    8a23:      	movabsq	$0x69772d5647206465, %rax # imm = 0x69772D5647206465
    8a2d:      	movq	%rax, 0x18(%rsp)
    8a32:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    8a3c:      	movq	%rax, 0x10(%rsp)
    8a41:      	leaq	0x10(%rsp), %rdi
    8a46:      	movl	$0x26, %eax
    8a4b:      	movl	$0x6, %ecx
    8a50:      	movl	0x6c(%rsp), %edx
    8a54:      	movl	$0x26, %esi
    8a59:      	jmp	0x7709 <perf_unwind_perl+0x7709>
    8a5e:      	movabsq	$0xa786c2578303d, %rax  # imm = 0xA786C2578303D
    8a68:      	movq	%rax, 0x30(%rsp)
    8a6d:      	movabsq	$0x7663202c786c2578, %rax # imm = 0x7663202C786C2578
    8a77:      	movq	%rax, 0x28(%rsp)
    8a7c:      	movabsq	$0x303d706f6320656d, %rax # imm = 0x303D706F6320656D
    8a86:      	movq	%rax, 0x20(%rsp)
    8a8b:      	movabsq	$0x617266206c726570, %rax # imm = 0x617266206C726570
    8a95:      	movq	%rax, 0x18(%rsp)
    8a9a:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    8aa4:      	movq	%rax, 0x10(%rsp)
    8aa9:      	leaq	0x10(%rsp), %rdi
    8aae:      	movl	$0x28, %eax
    8ab3:      	movl	$0x6, %r8d
    8ab9:      	movl	$0x28, %esi
    8abe:      	movq	0x80(%rsp), %rdx
    8ac6:      	movq	0x90(%rsp), %rcx
    8ace:      	xorl	%eax, %eax
    8ad0:      	callq	*%r8
    8ad3:      	movl	0x2c0(%r15), %eax
    8ada:      	cmpq	$0x7e, %rax
    8ade:      	ja	0x1193 <perf_unwind_perl+0x1193>
    8ae4:      	jmp	0x289d <perf_unwind_perl+0x289d>
    8ae9:      	movabsq	$0x6c25783020746120, %rax # imm = 0x6C25783020746120
    8af3:      	movq	%rax, 0x18(%rsp)
    8af8:      	movabsq	$0x564720646e756f46, %rax # imm = 0x564720646E756F46
    8b02:      	movq	%rax, 0x10(%rsp)
    8b07:      	movl	$0xa786c, 0x1f(%rsp)    # imm = 0xA786C
    8b0f:      	leaq	0x10(%rsp), %rdi
    8b14:      	movl	$0x13, %eax
    8b19:      	movl	$0x6, %ecx
    8b1e:      	movq	0x60(%rsp), %rdx
    8b23:      	movl	$0x13, %esi
    8b28:      	xorl	%eax, %eax
    8b2a:      	callq	*%rcx
    8b2c:      	movq	0x60(%rsp), %rax
    8b31:      	jmp	0x453b <perf_unwind_perl+0x453b>
    8b36:      	movabsq	$0xa7667655f7663, %rax  # imm = 0xA7667655F7663
    8b40:      	movq	%rax, 0x35(%rsp)
    8b45:      	movabsq	$0x5f76635f65766c6f, %rax # imm = 0x5F76635F65766C6F
    8b4f:      	movq	%rax, 0x30(%rsp)
    8b54:      	movabsq	$0x736572206e692029, %rax # imm = 0x736572206E692029
    8b5e:      	movq	%rax, 0x28(%rsp)
    8b63:      	movabsq	$0x28726573755f6461, %rax # imm = 0x28726573755F6461
    8b6d:      	movq	%rax, 0x20(%rsp)
    8b72:      	movabsq	$0x65725f65626f7270, %rax # imm = 0x65725F65626F7270
    8b7c:      	movq	%rax, 0x18(%rsp)
    8b81:      	movabsq	$0x5f66706220646142, %rax # imm = 0x5F66706220646142
    8b8b:      	movq	%rax, 0x10(%rsp)
    8b90:      	leaq	0x10(%rsp), %rdi
    8b95:      	movl	$0x2d, %eax
    8b9a:      	movl	$0x6, %ecx
    8b9f:      	movl	$0x2d, %esi
    8ba4:      	xorl	%eax, %eax
    8ba6:      	callq	*%rcx
    8ba8:      	jmp	0x52af <perf_unwind_perl+0x52af>
    8bad:      	movq	(%rip), %rax            # 0x8bb4 <perf_unwind_perl+0x8bb4>
    8bb4:      	cmpl	$0x0, (%rax)
    8bb7:      	je	0x5e90 <perf_unwind_perl+0x5e90>
    8bbd:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    8bc7:      	movq	%rax, 0x2e(%rsp)
    8bcc:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    8bd6:      	movq	%rax, 0x28(%rsp)
    8bdb:      	movabsq	$0x50472d74756f6874, %rax # imm = 0x50472D74756F6874
    8be5:      	movq	%rax, 0x20(%rsp)
    8bea:      	movabsq	$0x69772d5647206465, %rax # imm = 0x69772D5647206465
    8bf4:      	movq	%rax, 0x18(%rsp)
    8bf9:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    8c03:      	movq	%rax, 0x10(%rsp)
    8c08:      	leaq	0x10(%rsp), %rdi
    8c0d:      	movl	$0x26, %eax
    8c12:      	movl	$0x6, %ecx
    8c17:      	movl	0x6c(%rsp), %edx
    8c1b:      	movl	$0x26, %esi
    8c20:      	jmp	0x8017 <perf_unwind_perl+0x8017>
    8c25:      	movabsq	$0xa786c2578303d, %rax  # imm = 0xA786C2578303D
    8c2f:      	movq	%rax, 0x30(%rsp)
    8c34:      	movabsq	$0x7663202c786c2578, %rax # imm = 0x7663202C786C2578
    8c3e:      	movq	%rax, 0x28(%rsp)
    8c43:      	movabsq	$0x303d706f6320656d, %rax # imm = 0x303D706F6320656D
    8c4d:      	movq	%rax, 0x20(%rsp)
    8c52:      	movabsq	$0x617266206c726570, %rax # imm = 0x617266206C726570
    8c5c:      	movq	%rax, 0x18(%rsp)
    8c61:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    8c6b:      	movq	%rax, 0x10(%rsp)
    8c70:      	leaq	0x10(%rsp), %rdi
    8c75:      	movl	$0x28, %eax
    8c7a:      	movl	$0x6, %r8d
    8c80:      	movl	$0x28, %esi
    8c85:      	movq	0x80(%rsp), %rdx
    8c8d:      	movq	0x90(%rsp), %rcx
    8c95:      	xorl	%eax, %eax
    8c97:      	callq	*%r8
    8c9a:      	movl	0x2c0(%r15), %eax
    8ca1:      	cmpq	$0x7e, %rax
    8ca5:      	ja	0x1193 <perf_unwind_perl+0x1193>
    8cab:      	jmp	0x32bd <perf_unwind_perl+0x32bd>
    8cb0:      	movabsq	$0x6c25783020746120, %rax # imm = 0x6C25783020746120
    8cba:      	movq	%rax, 0x18(%rsp)
    8cbf:      	movabsq	$0x564720646e756f46, %rax # imm = 0x564720646E756F46
    8cc9:      	movq	%rax, 0x10(%rsp)
    8cce:      	movl	$0xa786c, 0x1f(%rsp)    # imm = 0xA786C
    8cd6:      	leaq	0x10(%rsp), %rdi
    8cdb:      	movl	$0x13, %eax
    8ce0:      	movl	$0x6, %ecx
    8ce5:      	movq	0x60(%rsp), %rdx
    8cea:      	movl	$0x13, %esi
    8cef:      	xorl	%eax, %eax
    8cf1:      	callq	*%rcx
    8cf3:      	movq	0x60(%rsp), %rax
    8cf8:      	jmp	0x4ee9 <perf_unwind_perl+0x4ee9>
    8cfd:      	movabsq	$0xa7667655f7663, %rax  # imm = 0xA7667655F7663
    8d07:      	movq	%rax, 0x35(%rsp)
    8d0c:      	movabsq	$0x5f76635f65766c6f, %rax # imm = 0x5F76635F65766C6F
    8d16:      	movq	%rax, 0x30(%rsp)
    8d1b:      	movabsq	$0x736572206e692029, %rax # imm = 0x736572206E692029
    8d25:      	movq	%rax, 0x28(%rsp)
    8d2a:      	movabsq	$0x28726573755f6461, %rax # imm = 0x28726573755F6461
    8d34:      	movq	%rax, 0x20(%rsp)
    8d39:      	movabsq	$0x65725f65626f7270, %rax # imm = 0x65725F65626F7270
    8d43:      	movq	%rax, 0x18(%rsp)
    8d48:      	movabsq	$0x5f66706220646142, %rax # imm = 0x5F66706220646142
    8d52:      	movq	%rax, 0x10(%rsp)
    8d57:      	leaq	0x10(%rsp), %rdi
    8d5c:      	movl	$0x2d, %eax
    8d61:      	movl	$0x6, %ecx
    8d66:      	movl	$0x2d, %esi
    8d6b:      	xorl	%eax, %eax
    8d6d:      	callq	*%rcx
    8d6f:      	jmp	0x6460 <perf_unwind_perl+0x6460>
    8d74:      	movabsq	$0xa786c2578303d, %rax  # imm = 0xA786C2578303D
    8d7e:      	movq	%rax, 0x30(%rsp)
    8d83:      	movabsq	$0x7663202c786c2578, %rax # imm = 0x7663202C786C2578
    8d8d:      	movq	%rax, 0x28(%rsp)
    8d92:      	movabsq	$0x303d706f6320656d, %rax # imm = 0x303D706F6320656D
    8d9c:      	movq	%rax, 0x20(%rsp)
    8da1:      	movabsq	$0x617266206c726570, %rax # imm = 0x617266206C726570
    8dab:      	movq	%rax, 0x18(%rsp)
    8db0:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    8dba:      	movq	%rax, 0x10(%rsp)
    8dbf:      	leaq	0x10(%rsp), %rdi
    8dc4:      	movl	$0x28, %eax
    8dc9:      	movl	$0x6, %r8d
    8dcf:      	movl	$0x28, %esi
    8dd4:      	movq	0x80(%rsp), %rdx
    8ddc:      	movq	0x90(%rsp), %rcx
    8de4:      	xorl	%eax, %eax
    8de6:      	callq	*%r8
    8de9:      	movl	0x2c0(%r15), %eax
    8df0:      	cmpq	$0x7e, %rax
    8df4:      	ja	0x1193 <perf_unwind_perl+0x1193>
    8dfa:      	jmp	0x3cb1 <perf_unwind_perl+0x3cb1>
    8dff:      	movabsq	$0x6c25783020746120, %rax # imm = 0x6C25783020746120
    8e09:      	movq	%rax, 0x18(%rsp)
    8e0e:      	movabsq	$0x564720646e756f46, %rax # imm = 0x564720646E756F46
    8e18:      	movq	%rax, 0x10(%rsp)
    8e1d:      	movl	$0xa786c, 0x1f(%rsp)    # imm = 0xA786C
    8e25:      	leaq	0x10(%rsp), %rdi
    8e2a:      	movl	$0x13, %eax
    8e2f:      	movl	$0x6, %ecx
    8e34:      	movq	0x60(%rsp), %rdx
    8e39:      	movl	$0x13, %esi
    8e3e:      	xorl	%eax, %eax
    8e40:      	callq	*%rcx
    8e42:      	movq	0x60(%rsp), %rax
    8e47:      	jmp	0x609a <perf_unwind_perl+0x609a>
    8e4c:      	movabsq	$0xa786c2578303d, %rax  # imm = 0xA786C2578303D
    8e56:      	movq	%rax, 0x30(%rsp)
    8e5b:      	movabsq	$0x7663202c786c2578, %rax # imm = 0x7663202C786C2578
    8e65:      	movq	%rax, 0x28(%rsp)
    8e6a:      	movabsq	$0x303d706f6320656d, %rax # imm = 0x303D706F6320656D
    8e74:      	movq	%rax, 0x20(%rsp)
    8e79:      	movabsq	$0x617266206c726570, %rax # imm = 0x617266206C726570
    8e83:      	movq	%rax, 0x18(%rsp)
    8e88:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    8e92:      	movq	%rax, 0x10(%rsp)
    8e97:      	leaq	0x10(%rsp), %rdi
    8e9c:      	movl	$0x28, %eax
    8ea1:      	movl	$0x6, %r8d
    8ea7:      	movl	$0x28, %esi
    8eac:      	movq	0x80(%rsp), %rdx
    8eb4:      	movq	0x90(%rsp), %rcx
    8ebc:      	xorl	%eax, %eax
    8ebe:      	callq	*%r8
    8ec1:      	movl	0x2c0(%r15), %eax
    8ec8:      	cmpq	$0x7e, %rax
    8ecc:      	ja	0x1193 <perf_unwind_perl+0x1193>
    8ed2:      	jmp	0x469d <perf_unwind_perl+0x469d>
    8ed7:      	movabsq	$0x6c25783020746120, %rax # imm = 0x6C25783020746120
    8ee1:      	movq	%rax, 0x18(%rsp)
    8ee6:      	movabsq	$0x564720646e756f46, %rax # imm = 0x564720646E756F46
    8ef0:      	movq	%rax, 0x10(%rsp)
    8ef5:      	movl	$0xa786c, 0x1f(%rsp)    # imm = 0xA786C
    8efd:      	leaq	0x10(%rsp), %rdi
    8f02:      	movl	$0x13, %eax
    8f07:      	movl	$0x6, %ecx
    8f0c:      	movq	0x60(%rsp), %rdx
    8f11:      	movl	$0x13, %esi
    8f16:      	xorl	%eax, %eax
    8f18:      	callq	*%rcx
    8f1a:      	movq	0x60(%rsp), %rax
    8f1f:      	jmp	0x6a4c <perf_unwind_perl+0x6a4c>
    8f24:      	movabsq	$0xa786c2578303d, %rax  # imm = 0xA786C2578303D
    8f2e:      	movq	%rax, 0x30(%rsp)
    8f33:      	movabsq	$0x7663202c786c2578, %rax # imm = 0x7663202C786C2578
    8f3d:      	movq	%rax, 0x28(%rsp)
    8f42:      	movabsq	$0x303d706f6320656d, %rax # imm = 0x303D706F6320656D
    8f4c:      	movq	%rax, 0x20(%rsp)
    8f51:      	movabsq	$0x617266206c726570, %rax # imm = 0x617266206C726570
    8f5b:      	movq	%rax, 0x18(%rsp)
    8f60:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    8f6a:      	movq	%rax, 0x10(%rsp)
    8f6f:      	leaq	0x10(%rsp), %rdi
    8f74:      	movl	$0x28, %eax
    8f79:      	movl	$0x6, %r8d
    8f7f:      	movl	$0x28, %esi
    8f84:      	movq	0x80(%rsp), %rdx
    8f8c:      	movq	0x90(%rsp), %rcx
    8f94:      	xorl	%eax, %eax
    8f96:      	callq	*%r8
    8f99:      	movl	0x2c0(%r15), %eax
    8fa0:      	cmpq	$0x7e, %rax
    8fa4:      	ja	0x1193 <perf_unwind_perl+0x1193>
    8faa:      	jmp	0x504b <perf_unwind_perl+0x504b>
    8faf:      	movabsq	$0x6c25783020746120, %rax # imm = 0x6C25783020746120
    8fb9:      	movq	%rax, 0x18(%rsp)
    8fbe:      	movabsq	$0x564720646e756f46, %rax # imm = 0x564720646E756F46
    8fc8:      	movq	%rax, 0x10(%rsp)
    8fcd:      	movl	$0xa786c, 0x1f(%rsp)    # imm = 0xA786C
    8fd5:      	leaq	0x10(%rsp), %rdi
    8fda:      	movl	$0x13, %eax
    8fdf:      	movl	$0x6, %ecx
    8fe4:      	movq	0x60(%rsp), %rdx
    8fe9:      	movl	$0x13, %esi
    8fee:      	xorl	%eax, %eax
    8ff0:      	callq	*%rcx
    8ff2:      	movq	0x60(%rsp), %rax
    8ff7:      	jmp	0x71fd <perf_unwind_perl+0x71fd>
    8ffc:      	movabsq	$0xa786c2578303d, %rax  # imm = 0xA786C2578303D
    9006:      	movq	%rax, 0x30(%rsp)
    900b:      	movabsq	$0x7663202c786c2578, %rax # imm = 0x7663202C786C2578
    9015:      	movq	%rax, 0x28(%rsp)
    901a:      	movabsq	$0x303d706f6320656d, %rax # imm = 0x303D706F6320656D
    9024:      	movq	%rax, 0x20(%rsp)
    9029:      	movabsq	$0x617266206c726570, %rax # imm = 0x617266206C726570
    9033:      	movq	%rax, 0x18(%rsp)
    9038:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    9042:      	movq	%rax, 0x10(%rsp)
    9047:      	leaq	0x10(%rsp), %rdi
    904c:      	movl	$0x28, %eax
    9051:      	movl	$0x6, %r8d
    9057:      	movl	$0x28, %esi
    905c:      	movq	0x80(%rsp), %rdx
    9064:      	movq	0x90(%rsp), %rcx
    906c:      	xorl	%eax, %eax
    906e:      	callq	*%r8
    9071:      	movl	0x2c0(%r15), %eax
    9078:      	cmpq	$0x7e, %rax
    907c:      	ja	0x1193 <perf_unwind_perl+0x1193>
    9082:      	jmp	0x61fc <perf_unwind_perl+0x61fc>
    9087:      	movabsq	$0x6c25783020746120, %rax # imm = 0x6C25783020746120
    9091:      	movq	%rax, 0x18(%rsp)
    9096:      	movabsq	$0x564720646e756f46, %rax # imm = 0x564720646E756F46
    90a0:      	movq	%rax, 0x10(%rsp)
    90a5:      	movl	$0xa786c, 0x1f(%rsp)    # imm = 0xA786C
    90ad:      	leaq	0x10(%rsp), %rdi
    90b2:      	movl	$0x13, %eax
    90b7:      	movl	$0x6, %ecx
    90bc:      	movq	0x60(%rsp), %rdx
    90c1:      	movl	$0x13, %esi
    90c6:      	xorl	%eax, %eax
    90c8:      	callq	*%rcx
    90ca:      	movq	0x60(%rsp), %rax
    90cf:      	jmp	0x79ae <perf_unwind_perl+0x79ae>
    90d4:      	movabsq	$0xa786c2578303d, %rax  # imm = 0xA786C2578303D
    90de:      	movq	%rax, 0x30(%rsp)
    90e3:      	movabsq	$0x7663202c786c2578, %rax # imm = 0x7663202C786C2578
    90ed:      	movq	%rax, 0x28(%rsp)
    90f2:      	movabsq	$0x303d706f6320656d, %rax # imm = 0x303D706F6320656D
    90fc:      	movq	%rax, 0x20(%rsp)
    9101:      	movabsq	$0x617266206c726570, %rax # imm = 0x617266206C726570
    910b:      	movq	%rax, 0x18(%rsp)
    9110:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    911a:      	movq	%rax, 0x10(%rsp)
    911f:      	leaq	0x10(%rsp), %rdi
    9124:      	movl	$0x28, %eax
    9129:      	movl	$0x6, %r8d
    912f:      	movl	$0x28, %esi
    9134:      	movq	0x80(%rsp), %rdx
    913c:      	movq	0x90(%rsp), %rcx
    9144:      	xorl	%eax, %eax
    9146:      	callq	*%r8
    9149:      	movl	0x2c0(%r15), %eax
    9150:      	cmpq	$0x7e, %rax
    9154:      	ja	0x1193 <perf_unwind_perl+0x1193>
    915a:      	jmp	0x6bae <perf_unwind_perl+0x6bae>
    915f:      	movabsq	$0xa786c2578303d, %rax  # imm = 0xA786C2578303D
    9169:      	movq	%rax, 0x30(%rsp)
    916e:      	movabsq	$0x7663202c786c2578, %rax # imm = 0x7663202C786C2578
    9178:      	movq	%rax, 0x28(%rsp)
    917d:      	movabsq	$0x303d706f6320656d, %rax # imm = 0x303D706F6320656D
    9187:      	movq	%rax, 0x20(%rsp)
    918c:      	movabsq	$0x617266206c726570, %rax # imm = 0x617266206C726570
    9196:      	movq	%rax, 0x18(%rsp)
    919b:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    91a5:      	movq	%rax, 0x10(%rsp)
    91aa:      	leaq	0x10(%rsp), %rdi
    91af:      	movl	$0x28, %eax
    91b4:      	movl	$0x6, %r8d
    91ba:      	movl	$0x28, %esi
    91bf:      	movq	0x80(%rsp), %rdx
    91c7:      	movq	0x90(%rsp), %rcx
    91cf:      	xorl	%eax, %eax
    91d1:      	callq	*%r8
    91d4:      	movl	0x2c0(%r15), %eax
    91db:      	cmpq	$0x7e, %rax
    91df:      	ja	0x1193 <perf_unwind_perl+0x1193>
    91e5:      	jmp	0x735f <perf_unwind_perl+0x735f>
    91ea:      	movabsq	$0xa786c2578303d, %rax  # imm = 0xA786C2578303D
    91f4:      	movq	%rax, 0x30(%rsp)
    91f9:      	movabsq	$0x7663202c786c2578, %rax # imm = 0x7663202C786C2578
    9203:      	movq	%rax, 0x28(%rsp)
    9208:      	movabsq	$0x303d706f6320656d, %rax # imm = 0x303D706F6320656D
    9212:      	movq	%rax, 0x20(%rsp)
    9217:      	movabsq	$0x617266206c726570, %rax # imm = 0x617266206C726570
    9221:      	movq	%rax, 0x18(%rsp)
    9226:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    9230:      	movq	%rax, 0x10(%rsp)
    9235:      	leaq	0x10(%rsp), %rdi
    923a:      	movl	$0x28, %eax
    923f:      	movl	$0x6, %r8d
    9245:      	movl	$0x28, %esi
    924a:      	movq	0x80(%rsp), %rdx
    9252:      	movq	0x90(%rsp), %rcx
    925a:      	xorl	%eax, %eax
    925c:      	callq	*%r8
    925f:      	movl	0x2c0(%r15), %eax
    9266:      	cmpq	$0x7e, %rax
    926a:      	ja	0x1193 <perf_unwind_perl+0x1193>
    9270:      	jmp	0x7b10 <perf_unwind_perl+0x7b10>

Disassembly of section kprobe/unwind_perl:

0000000000000000 <kprobe_unwind_perl>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0xc8, %rsp
      11:      	movq	%rdi, %rbx
      14:      	movl	$0x0, 0x10(%rsp)
      1c:      	movq	(%rip), %rdi            # 0x23 <kprobe_unwind_perl+0x23>
      23:      	leaq	0x10(%rsp), %rsi
      28:      	movl	$0x1, %eax
      2d:      	callq	*%rax
      2f:      	testq	%rax, %rax
      32:      	je	0x5912 <kprobe_unwind_perl+0x5912>
      38:      	movq	%rax, %r12
      3b:      	movq	%rax, %r15
      3e:      	movl	(%r12), %eax
      42:      	movl	%eax, 0xc4(%rsp)
      49:      	movq	(%rip), %r13            # 0x50 <kprobe_unwind_perl+0x50>
      50:      	cmpl	$0x0, (%r13)
      55:      	jne	0x14db <kprobe_unwind_perl+0x14db>
      5b:      	movq	(%rip), %rdi            # 0x62 <kprobe_unwind_perl+0x62>
      62:      	leaq	0xc4(%rsp), %rsi
      6a:      	movl	$0x1, %eax
      6f:      	callq	*%rax
      71:      	movl	(%r13), %ecx
      75:      	testq	%rax, %rax
      78:      	je	0xd5 <kprobe_unwind_perl+0xd5>
      7a:      	movq	%rax, %r14
      7d:      	testl	%ecx, %ecx
      7f:      	jne	0x1516 <kprobe_unwind_perl+0x1516>
      85:      	leaq	0xf38(%r12), %rax
      8d:      	movq	%rax, 0xb8(%rsp)
      95:      	movq	0xf38(%r15), %rax
      9c:      	testq	%rax, %rax
      9f:      	je	0x14e <kprobe_unwind_perl+0x14e>
      a5:      	movq	%rax, 0xa8(%rsp)
      ad:      	movq	0xf48(%r15), %rcx
      b4:      	movq	0xf50(%r15), %r13
      bb:      	addq	$0xf40, %r12            # imm = 0xF40
      c2:      	cmpq	%rcx, %r13
      c5:      	jae	0x243 <kprobe_unwind_perl+0x243>
      cb:      	movl	$0x3, %ebp
      d0:      	jmp	0x5636 <kprobe_unwind_perl+0x5636>
      d5:      	xorl	%eax, %eax
      d7:      	testl	%ecx, %ecx
      d9:      	je	0x5917 <kprobe_unwind_perl+0x5917>
      df:      	movabsq	$0xa6f666e69207373, %rax # imm = 0xA6F666E69207373
      e9:      	movq	%rax, 0x30(%rsp)
      ee:      	movabsq	$0x6572646461206f6e, %rax # imm = 0x6572646461206F6E
      f8:      	movq	%rax, 0x28(%rsp)
      fd:      	movabsq	$0x202c6b6361747320, %rax # imm = 0x202C6B6361747320
     107:      	movq	%rax, 0x20(%rsp)
     10c:      	movabsq	$0x6c72655020646c69, %rax # imm = 0x6C72655020646C69
     116:      	movq	%rax, 0x18(%rsp)
     11b:      	movabsq	$0x75622074276e6143, %rax # imm = 0x75622074276E6143
     125:      	movq	%rax, 0x10(%rsp)
     12a:      	movb	$0x0, 0x38(%rsp)
     12f:      	leaq	0x10(%rsp), %rdi
     134:      	movl	$0x29, %eax
     139:      	movl	$0x6, %ecx
     13e:      	movl	$0x29, %esi
     143:      	xorl	%eax, %eax
     145:      	callq	*%rcx
     147:      	xorl	%eax, %eax
     149:      	jmp	0x5917 <kprobe_unwind_perl+0x5917>
     14e:      	movl	$0xf, 0x50(%rsp)
     156:      	movq	(%rip), %rdi            # 0x15d <kprobe_unwind_perl+0x15d>
     15d:      	leaq	0x50(%rsp), %rsi
     162:      	movl	$0x1, %eax
     167:      	callq	*%rax
     169:      	testq	%rax, %rax
     16c:      	je	0x2b8 <kprobe_unwind_perl+0x2b8>
     172:      	incq	(%rax)
     175:      	cmpb	$0x0, 0x14(%r14)
     17a:      	jne	0x2ce <kprobe_unwind_perl+0x2ce>
     180:      	movq	(%r14), %rax
     183:      	movq	%rax, 0x60(%rsp)
     188:      	movq	%r13, %rbp
     18b:      	cmpl	$0x0, (%r13)
     190:      	jne	0x2128 <kprobe_unwind_perl+0x2128>
     196:      	movzwl	0x12(%r14), %eax
     19b:      	addq	0x60(%rsp), %rax
     1a0:      	movl	$0x8, %ecx
     1a5:      	movl	$0x70, %r8d
     1ab:      	movq	0xb8(%rsp), %rdi
     1b3:      	movzwl	0x12(%r14), %edx
     1b8:      	addq	0x60(%rsp), %rdx
     1bd:      	movl	$0x8, %esi
     1c2:      	callq	*%r8
     1c5:      	testq	%rax, %rax
     1c8:      	jne	0x205 <kprobe_unwind_perl+0x205>
     1ca:      	leaq	0xf40(%r12), %r13
     1d2:      	movzwl	0x10(%r14), %eax
     1d7:      	addq	0x60(%rsp), %rax
     1dc:      	movl	$0x8, %ecx
     1e1:      	movl	$0x70, %r8d
     1e7:      	movzwl	0x10(%r14), %edx
     1ec:      	addq	0x60(%rsp), %rdx
     1f1:      	movq	%r13, %rdi
     1f4:      	movl	$0x8, %esi
     1f9:      	callq	*%r8
     1fc:      	testq	%rax, %rax
     1ff:      	je	0xa03 <kprobe_unwind_perl+0xa03>
     205:      	movq	%rbp, %r13
     208:      	cmpl	$0x0, (%rbp)
     20c:      	jne	0x22d8 <kprobe_unwind_perl+0x22d8>
     212:      	movl	$0x12, 0x50(%rsp)
     21a:      	movq	(%rip), %rdi            # 0x221 <kprobe_unwind_perl+0x221>
     221:      	leaq	0x50(%rsp), %rsi
     226:      	movl	$0x1, %eax
     22b:      	callq	*%rax
     22d:      	testq	%rax, %rax
     230:      	je	0x782 <kprobe_unwind_perl+0x782>
     236:      	incq	(%rax)
     239:      	movl	$0x1, %ebp
     23e:      	jmp	0x586a <kprobe_unwind_perl+0x586a>
     243:      	movq	%rcx, 0x98(%rsp)
     24b:      	movzbl	0x19(%r14), %eax
     250:      	addq	%r13, %rax
     253:      	leaq	0xe(%rsp), %rdi
     258:      	movl	$0x1, %ecx
     25d:      	movl	$0x70, %r8d
     263:      	movzbl	0x19(%r14), %edx
     268:      	addq	%r13, %rdx
     26b:      	movl	$0x1, %esi
     270:      	callq	*%r8
     273:      	testq	%rax, %rax
     276:      	je	0x39c <kprobe_unwind_perl+0x39c>
     27c:      	movq	(%rip), %rax            # 0x283 <kprobe_unwind_perl+0x283>
     283:      	cmpl	$0x0, (%rax)
     286:      	jne	0x1efd <kprobe_unwind_perl+0x1efd>
     28c:      	movl	$0x13, 0x50(%rsp)
     294:      	movq	(%rip), %rdi            # 0x29b <kprobe_unwind_perl+0x29b>
     29b:      	leaq	0x50(%rsp), %rsi
     2a0:      	movl	$0x1, %eax
     2a5:      	callq	*%rax
     2a7:      	testq	%rax, %rax
     2aa:      	je	0x4b8 <kprobe_unwind_perl+0x4b8>
     2b0:      	incq	(%rax)
     2b3:      	jmp	0x4c8 <kprobe_unwind_perl+0x4c8>
     2b8:      	cmpl	$0x0, (%r13)
     2bd:      	jne	0x21d0 <kprobe_unwind_perl+0x21d0>
     2c3:      	cmpb	$0x0, 0x14(%r14)
     2c8:      	je	0x180 <kprobe_unwind_perl+0x180>
     2ce:      	movl	$0x23, %eax
     2d3:      	callq	*%rax
     2d5:      	movq	(%rip), %rcx            # 0x2dc <kprobe_unwind_perl+0x2dc>
     2dc:      	addq	(%rcx), %rax
     2df:      	leaq	0x88(%rsp), %rdi
     2e7:      	movl	$0x8, %ecx
     2ec:      	movl	$0x71, %r8d
     2f2:      	movl	$0x8, %esi
     2f7:      	movq	%rax, %rdx
     2fa:      	callq	*%r8
     2fd:      	testq	%rax, %rax
     300:      	je	0x5a9 <kprobe_unwind_perl+0x5a9>
     306:      	cmpl	$0x0, (%r13)
     30b:      	jne	0x2177 <kprobe_unwind_perl+0x2177>
     311:      	movl	$0x4, 0x50(%rsp)
     319:      	movq	(%rip), %rdi            # 0x320 <kprobe_unwind_perl+0x320>
     320:      	leaq	0x50(%rsp), %rsi
     325:      	movl	$0x1, %eax
     32a:      	callq	*%rax
     32c:      	testq	%rax, %rax
     32f:      	je	0x6f1 <kprobe_unwind_perl+0x6f1>
     335:      	incq	(%rax)
     338:      	cmpl	$0x0, (%r13)
     33d:      	je	0xbb4 <kprobe_unwind_perl+0xbb4>
     343:      	movabsq	$0xa737365726464, %rax  # imm = 0xA737365726464
     34d:      	movq	%rax, 0x28(%rsp)
     352:      	movabsq	$0x6120657361622044, %rax # imm = 0x6120657361622044
     35c:      	movq	%rax, 0x20(%rsp)
     361:      	movabsq	$0x535420746567206f, %rax # imm = 0x535420746567206F
     36b:      	movq	%rax, 0x18(%rsp)
     370:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     37a:      	movq	%rax, 0x10(%rsp)
     37f:      	leaq	0x10(%rsp), %rdi
     384:      	movl	$0x20, %eax
     389:      	movl	$0x6, %ecx
     38e:      	movl	$0x20, %esi
     393:      	xorl	%eax, %eax
     395:      	callq	*%rcx
     397:      	jmp	0xbb4 <kprobe_unwind_perl+0xbb4>
     39c:      	movq	(%rip), %rax            # 0x3a3 <kprobe_unwind_perl+0x3a3>
     3a3:      	cmpl	$0x0, (%rax)
     3a6:      	jne	0x23a5 <kprobe_unwind_perl+0x23a5>
     3ac:      	movzbl	0xe(%rsp), %eax
     3b1:      	movl	%eax, %ecx
     3b3:      	andl	$0xf, %ecx
     3b6:      	movl	$0x3, %ebp
     3bb:      	leal	-0x9(%rcx), %edx
     3be:      	cmpl	$0x2, %edx
     3c1:      	jae	0x641 <kprobe_unwind_perl+0x641>
     3c7:      	testb	%al, %al
     3c9:      	js	0x4cd <kprobe_unwind_perl+0x4cd>
     3cf:      	movzbl	0x1b(%r14), %eax
     3d4:      	addq	%r13, %rax
     3d7:      	leaq	0x10(%rsp), %rdi
     3dc:      	movl	$0x8, %ecx
     3e1:      	movl	$0x70, %r8d
     3e7:      	movzbl	0x1b(%r14), %edx
     3ec:      	addq	%r13, %rdx
     3ef:      	movl	$0x8, %esi
     3f4:      	callq	*%r8
     3f7:      	testq	%rax, %rax
     3fa:      	jne	0x27c <kprobe_unwind_perl+0x27c>
     400:      	cmpq	$0x0, 0x10(%rsp)
     406:      	setne	%bpl
     40a:      	movzbl	0x1c(%r14), %eax
     40f:      	addq	%r13, %rax
     412:      	leaq	0xa0(%rsp), %rdi
     41a:      	movl	$0x8, %ecx
     41f:      	movl	$0x70, %r8d
     425:      	movzbl	0x1c(%r14), %edx
     42a:      	addq	%r13, %rdx
     42d:      	movl	$0x8, %esi
     432:      	callq	*%r8
     435:      	testq	%rax, %rax
     438:      	jne	0x27c <kprobe_unwind_perl+0x27c>
     43e:      	movb	%bpl, 0xf(%rsp)
     443:      	movq	0xa0(%rsp), %rbp
     44b:      	movzbl	0x1e(%r14), %eax
     450:      	addq	%rbp, %rax
     453:      	leaq	0x5c(%rsp), %rdi
     458:      	movl	$0x4, %ecx
     45d:      	movl	$0x70, %r8d
     463:      	movzbl	0x1e(%r14), %edx
     468:      	addq	%rbp, %rdx
     46b:      	movl	$0x4, %esi
     470:      	callq	*%r8
     473:      	testq	%rax, %rax
     476:      	je	0xf5a <kprobe_unwind_perl+0xf5a>
     47c:      	movq	(%rip), %rax            # 0x483 <kprobe_unwind_perl+0x483>
     483:      	cmpl	$0x0, (%rax)
     486:      	jne	0x3a01 <kprobe_unwind_perl+0x3a01>
     48c:      	movl	$0x14, 0x74(%rsp)
     494:      	movq	(%rip), %rdi            # 0x49b <kprobe_unwind_perl+0x49b>
     49b:      	leaq	0x74(%rsp), %rsi
     4a0:      	movl	$0x1, %eax
     4a5:      	callq	*%rax
     4a7:      	testq	%rax, %rax
     4aa:      	je	0x12e7 <kprobe_unwind_perl+0x12e7>
     4b0:      	incq	(%rax)
     4b3:      	jmp	0x27c <kprobe_unwind_perl+0x27c>
     4b8:      	movq	(%rip), %rax            # 0x4bf <kprobe_unwind_perl+0x4bf>
     4bf:      	cmpl	$0x0, (%rax)
     4c2:      	jne	0x2569 <kprobe_unwind_perl+0x2569>
     4c8:      	movl	$0x3, %ebp
     4cd:      	movzbl	0x1d(%r14), %eax
     4d2:      	subq	%rax, 0xf50(%r15)
     4d9:      	movl	$0x10, 0x50(%rsp)
     4e1:      	movq	(%rip), %rdi            # 0x4e8 <kprobe_unwind_perl+0x4e8>
     4e8:      	leaq	0x50(%rsp), %rsi
     4ed:      	movl	$0x1, %eax
     4f2:      	callq	*%rax
     4f4:      	testq	%rax, %rax
     4f7:      	je	0x506 <kprobe_unwind_perl+0x506>
     4f9:      	incq	(%rax)
     4fc:      	movq	0x98(%rsp), %rcx
     504:      	jmp	0x51e <kprobe_unwind_perl+0x51e>
     506:      	movq	(%rip), %rax            # 0x50d <kprobe_unwind_perl+0x50d>
     50d:      	cmpl	$0x0, (%rax)
     510:      	movq	0x98(%rsp), %rcx
     518:      	jne	0x23ec <kprobe_unwind_perl+0x23ec>
     51e:      	cmpl	$0x3, %ebp
     521:      	jne	0x5636 <kprobe_unwind_perl+0x5636>
     527:      	movq	0xf50(%r15), %r13
     52e:      	cmpq	%rcx, %r13
     531:      	jb	0xcb <kprobe_unwind_perl+0xcb>
     537:      	movzbl	0x19(%r14), %eax
     53c:      	addq	%r13, %rax
     53f:      	leaq	0xe(%rsp), %rdi
     544:      	movl	$0x1, %ecx
     549:      	movl	$0x70, %r8d
     54f:      	movzbl	0x19(%r14), %edx
     554:      	addq	%r13, %rdx
     557:      	movl	$0x1, %esi
     55c:      	callq	*%r8
     55f:      	testq	%rax, %rax
     562:      	je	0x8cd <kprobe_unwind_perl+0x8cd>
     568:      	movq	(%rip), %rax            # 0x56f <kprobe_unwind_perl+0x56f>
     56f:      	cmpl	$0x0, (%rax)
     572:      	jne	0x29a3 <kprobe_unwind_perl+0x29a3>
     578:      	movl	$0x13, 0x50(%rsp)
     580:      	movq	(%rip), %rdi            # 0x587 <kprobe_unwind_perl+0x587>
     587:      	leaq	0x50(%rsp), %rsi
     58c:      	movl	$0x1, %eax
     591:      	callq	*%rax
     593:      	testq	%rax, %rax
     596:      	je	0x9e9 <kprobe_unwind_perl+0x9e9>
     59c:      	incq	(%rax)
     59f:      	movl	$0x3, %ebp
     5a4:      	jmp	0xacd <kprobe_unwind_perl+0xacd>
     5a9:      	movq	(%r14), %rax
     5ac:      	leaq	0xb4(%rsp), %rdi
     5b4:      	movl	$0x4, %ecx
     5b9:      	movl	$0x70, %r8d
     5bf:      	movq	(%r14), %rdx
     5c2:      	movl	$0x4, %esi
     5c7:      	callq	*%r8
     5ca:      	testq	%rax, %rax
     5cd:      	je	0x808 <kprobe_unwind_perl+0x808>
     5d3:      	cmpl	$0x0, (%r13)
     5d8:      	je	0xbb4 <kprobe_unwind_perl+0xbb4>
     5de:      	movabsq	$0x786c257830206d6f, %rax # imm = 0x786C257830206D6F
     5e8:      	movq	%rax, 0x28(%rsp)
     5ed:      	movabsq	$0x72662079654b6473, %rax # imm = 0x72662079654B6473
     5f7:      	movq	%rax, 0x20(%rsp)
     5fc:      	movabsq	$0x742064616572206f, %rax # imm = 0x742064616572206F
     606:      	movq	%rax, 0x18(%rsp)
     60b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     615:      	movq	%rax, 0x10(%rsp)
     61a:      	movw	$0xa, 0x30(%rsp)
     621:      	leaq	0x10(%rsp), %rdi
     626:      	movl	$0x22, %eax
     62b:      	movl	$0x6, %ecx
     630:      	movq	(%r14), %rdx
     633:      	movl	$0x22, %esi
     638:      	xorl	%eax, %eax
     63a:      	callq	*%rcx
     63c:      	jmp	0xbb4 <kprobe_unwind_perl+0xbb4>
     641:      	cmpl	$0xc, %ecx
     644:      	je	0x4cd <kprobe_unwind_perl+0x4cd>
     64a:      	cmpq	$0x0, (%r12)
     64f:      	jne	0x4cd <kprobe_unwind_perl+0x4cd>
     655:      	movzbl	0x1a(%r14), %eax
     65a:      	addq	%r13, %rax
     65d:      	movl	$0x8, %ecx
     662:      	movl	$0x70, %r8d
     668:      	movzbl	0x1a(%r14), %edx
     66d:      	addq	%r13, %rdx
     670:      	movq	%r12, %rdi
     673:      	movl	$0x8, %esi
     678:      	callq	*%r8
     67b:      	testq	%rax, %rax
     67e:      	jne	0x27c <kprobe_unwind_perl+0x27c>
     684:      	movq	(%rip), %rax            # 0x68b <kprobe_unwind_perl+0x68b>
     68b:      	cmpl	$0x0, (%rax)
     68e:      	je	0x4cd <kprobe_unwind_perl+0x4cd>
     694:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
     69e:      	movq	%rax, 0x26(%rsp)
     6a3:      	movabsq	$0x30206b6361747320, %rax # imm = 0x30206B6361747320
     6ad:      	movq	%rax, 0x20(%rsp)
     6b2:      	movabsq	$0x747865746e6f6320, %rax # imm = 0x747865746E6F6320
     6bc:      	movq	%rax, 0x18(%rsp)
     6c1:      	movabsq	$0x6d6f726620504f43, %rax # imm = 0x6D6F726620504F43
     6cb:      	movq	%rax, 0x10(%rsp)
     6d0:      	leaq	0x10(%rsp), %rdi
     6d5:      	movl	$0x1e, %eax
     6da:      	movl	$0x6, %ecx
     6df:      	movq	(%r12), %rdx
     6e3:      	movl	$0x1e, %esi
     6e8:      	xorl	%eax, %eax
     6ea:      	callq	*%rcx
     6ec:      	jmp	0x4cd <kprobe_unwind_perl+0x4cd>
     6f1:      	cmpl	$0x0, (%r13)
     6f6:      	je	0xbb4 <kprobe_unwind_perl+0xbb4>
     6fc:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     706:      	movq	%rax, 0x36(%rsp)
     70b:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     715:      	movq	%rax, 0x30(%rsp)
     71a:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     724:      	movq	%rax, 0x28(%rsp)
     729:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     733:      	movq	%rax, 0x20(%rsp)
     738:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     742:      	movq	%rax, 0x18(%rsp)
     747:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     751:      	movq	%rax, 0x10(%rsp)
     756:      	leaq	0x10(%rsp), %rdi
     75b:      	movl	$0x2e, %eax
     760:      	movl	$0x6, %ecx
     765:      	movl	0x50(%rsp), %edx
     769:      	movl	$0x2e, %esi
     76e:      	xorl	%eax, %eax
     770:      	callq	*%rcx
     772:      	cmpl	$0x0, (%r13)
     777:      	je	0xbb4 <kprobe_unwind_perl+0xbb4>
     77d:      	jmp	0x343 <kprobe_unwind_perl+0x343>
     782:      	cmpl	$0x0, (%r13)
     787:      	je	0xbe4 <kprobe_unwind_perl+0xbe4>
     78d:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     797:      	movq	%rax, 0x36(%rsp)
     79c:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     7a6:      	movq	%rax, 0x30(%rsp)
     7ab:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     7b5:      	movq	%rax, 0x28(%rsp)
     7ba:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     7c4:      	movq	%rax, 0x20(%rsp)
     7c9:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     7d3:      	movq	%rax, 0x18(%rsp)
     7d8:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     7e2:      	movq	%rax, 0x10(%rsp)
     7e7:      	leaq	0x10(%rsp), %rdi
     7ec:      	movl	$0x2e, %eax
     7f1:      	movl	$0x6, %ecx
     7f6:      	movl	0x50(%rsp), %edx
     7fa:      	movl	$0x2e, %esi
     7ff:      	xorl	%eax, %eax
     801:      	callq	*%rcx
     803:      	jmp	0xbe4 <kprobe_unwind_perl+0xbe4>
     808:      	movq	%r13, %rbp
     80b:      	movslq	0xb4(%rsp), %r13
     813:      	movswq	0xc(%r14), %rax
     818:      	addq	0x88(%rsp), %rax
     820:      	movq	%rax, 0x50(%rsp)
     825:      	cmpb	$0x0, 0xf(%r14)
     82a:      	je	0x853 <kprobe_unwind_perl+0x853>
     82c:      	leaq	0x50(%rsp), %rdi
     831:      	movl	$0x8, %ecx
     836:      	movl	$0x70, %r8d
     83c:      	movq	0x50(%rsp), %rdx
     841:      	movl	$0x8, %esi
     846:      	callq	*%r8
     849:      	testq	%rax, %rax
     84c:      	jne	0x894 <kprobe_unwind_perl+0x894>
     84e:      	movq	0x50(%rsp), %rax
     853:      	movzbl	0xe(%r14), %ecx
     858:      	imulq	%r13, %rcx
     85c:      	addq	%rax, %rcx
     85f:      	movq	%rcx, 0x50(%rsp)
     864:      	cmpl	$0x0, (%rbp)
     868:      	jne	0x2fb0 <kprobe_unwind_perl+0x2fb0>
     86e:      	leaq	0x60(%rsp), %rdi
     873:      	movl	$0x8, %eax
     878:      	movl	$0x70, %r8d
     87e:      	movq	0x50(%rsp), %rdx
     883:      	movl	$0x8, %esi
     888:      	callq	*%r8
     88b:      	testq	%rax, %rax
     88e:      	je	0xbee <kprobe_unwind_perl+0xbee>
     894:      	movq	%rbp, %r13
     897:      	cmpl	$0x0, (%rbp)
     89b:      	jne	0x2e73 <kprobe_unwind_perl+0x2e73>
     8a1:      	movl	$0x3, 0x78(%rsp)
     8a9:      	movq	(%rip), %rdi            # 0x8b0 <kprobe_unwind_perl+0x8b0>
     8b0:      	leaq	0x78(%rsp), %rsi
     8b5:      	movl	$0x1, %eax
     8ba:      	callq	*%rax
     8bc:      	testq	%rax, %rax
     8bf:      	je	0xba9 <kprobe_unwind_perl+0xba9>
     8c5:      	incq	(%rax)
     8c8:      	jmp	0xbb4 <kprobe_unwind_perl+0xbb4>
     8cd:      	movq	(%rip), %rax            # 0x8d4 <kprobe_unwind_perl+0x8d4>
     8d4:      	cmpl	$0x0, (%rax)
     8d7:      	jne	0x2cbd <kprobe_unwind_perl+0x2cbd>
     8dd:      	movzbl	0xe(%rsp), %eax
     8e2:      	movl	%eax, %ecx
     8e4:      	andl	$0xf, %ecx
     8e7:      	movl	$0x3, %ebp
     8ec:      	leal	-0x9(%rcx), %edx
     8ef:      	cmpl	$0x2, %edx
     8f2:      	jae	0xabd <kprobe_unwind_perl+0xabd>
     8f8:      	testb	%al, %al
     8fa:      	js	0xacd <kprobe_unwind_perl+0xacd>
     900:      	movzbl	0x1b(%r14), %eax
     905:      	addq	%r13, %rax
     908:      	leaq	0x10(%rsp), %rdi
     90d:      	movl	$0x8, %ecx
     912:      	movl	$0x70, %r8d
     918:      	movzbl	0x1b(%r14), %edx
     91d:      	addq	%r13, %rdx
     920:      	movl	$0x8, %esi
     925:      	callq	*%r8
     928:      	testq	%rax, %rax
     92b:      	jne	0x568 <kprobe_unwind_perl+0x568>
     931:      	cmpq	$0x0, 0x10(%rsp)
     937:      	setne	%bpl
     93b:      	movzbl	0x1c(%r14), %eax
     940:      	addq	%r13, %rax
     943:      	leaq	0xa0(%rsp), %rdi
     94b:      	movl	$0x8, %ecx
     950:      	movl	$0x70, %r8d
     956:      	movzbl	0x1c(%r14), %edx
     95b:      	addq	%r13, %rdx
     95e:      	movl	$0x8, %esi
     963:      	callq	*%r8
     966:      	testq	%rax, %rax
     969:      	jne	0x568 <kprobe_unwind_perl+0x568>
     96f:      	movb	%bpl, 0xf(%rsp)
     974:      	movq	0xa0(%rsp), %rbp
     97c:      	movzbl	0x1e(%r14), %eax
     981:      	addq	%rbp, %rax
     984:      	leaq	0x5c(%rsp), %rdi
     989:      	movl	$0x4, %ecx
     98e:      	movl	$0x70, %r8d
     994:      	movzbl	0x1e(%r14), %edx
     999:      	addq	%rbp, %rdx
     99c:      	movl	$0x4, %esi
     9a1:      	callq	*%r8
     9a4:      	testq	%rax, %rax
     9a7:      	je	0x1573 <kprobe_unwind_perl+0x1573>
     9ad:      	movq	(%rip), %rax            # 0x9b4 <kprobe_unwind_perl+0x9b4>
     9b4:      	cmpl	$0x0, (%rax)
     9b7:      	jne	0x43ed <kprobe_unwind_perl+0x43ed>
     9bd:      	movl	$0x14, 0x74(%rsp)
     9c5:      	movq	(%rip), %rdi            # 0x9cc <kprobe_unwind_perl+0x9cc>
     9cc:      	leaq	0x74(%rsp), %rsi
     9d1:      	movl	$0x1, %eax
     9d6:      	callq	*%rax
     9d8:      	testq	%rax, %rax
     9db:      	je	0x19ca <kprobe_unwind_perl+0x19ca>
     9e1:      	incq	(%rax)
     9e4:      	jmp	0x568 <kprobe_unwind_perl+0x568>
     9e9:      	movq	(%rip), %rax            # 0x9f0 <kprobe_unwind_perl+0x9f0>
     9f0:      	cmpl	$0x0, (%rax)
     9f3:      	jne	0x2ed1 <kprobe_unwind_perl+0x2ed1>
     9f9:      	movl	$0x3, %ebp
     9fe:      	jmp	0xacd <kprobe_unwind_perl+0xacd>
     a03:      	cmpl	$0x0, (%rbp)
     a07:      	jne	0x2f4c <kprobe_unwind_perl+0x2f4c>
     a0d:      	movq	0xb8(%rsp), %rax
     a15:      	movq	(%rax), %r13
     a18:      	movzbl	0x15(%r14), %eax
     a1d:      	addq	%r13, %rax
     a20:      	leaq	0x50(%rsp), %rdi
     a25:      	movl	$0x8, %ecx
     a2a:      	movl	$0x70, %r8d
     a30:      	movzbl	0x15(%r14), %edx
     a35:      	addq	%r13, %rdx
     a38:      	movl	$0x8, %esi
     a3d:      	callq	*%r8
     a40:      	testq	%rax, %rax
     a43:      	jne	0xa76 <kprobe_unwind_perl+0xa76>
     a45:      	movzbl	0x17(%r14), %eax
     a4a:      	addq	%r13, %rax
     a4d:      	leaq	0x78(%rsp), %rdi
     a52:      	movl	$0x4, %ecx
     a57:      	movl	$0x70, %r8d
     a5d:      	movzbl	0x17(%r14), %edx
     a62:      	addq	%r13, %rdx
     a65:      	movl	$0x4, %esi
     a6a:      	callq	*%r8
     a6d:      	testq	%rax, %rax
     a70:      	je	0xf08 <kprobe_unwind_perl+0xf08>
     a76:      	cmpl	$0x0, (%rbp)
     a7a:      	jne	0x3020 <kprobe_unwind_perl+0x3020>
     a80:      	orb	$0x8, 0x1380(%r15)
     a88:      	movl	$0x12, 0x88(%rsp)
     a93:      	movq	(%rip), %rdi            # 0xa9a <kprobe_unwind_perl+0xa9a>
     a9a:      	leaq	0x88(%rsp), %rsi
     aa2:      	movl	$0x1, %eax
     aa7:      	callq	*%rax
     aa9:      	testq	%rax, %rax
     aac:      	je	0xd7a <kprobe_unwind_perl+0xd7a>
     ab2:      	incq	(%rax)
     ab5:      	movq	%rbp, %r13
     ab8:      	jmp	0xf39 <kprobe_unwind_perl+0xf39>
     abd:      	cmpl	$0xc, %ecx
     ac0:      	je	0xacd <kprobe_unwind_perl+0xacd>
     ac2:      	cmpq	$0x0, (%r12)
     ac7:      	je	0x1816 <kprobe_unwind_perl+0x1816>
     acd:      	movzbl	0x1d(%r14), %eax
     ad2:      	subq	%rax, 0xf50(%r15)
     ad9:      	movl	$0x10, 0x50(%rsp)
     ae1:      	movq	(%rip), %rdi            # 0xae8 <kprobe_unwind_perl+0xae8>
     ae8:      	leaq	0x50(%rsp), %rsi
     aed:      	movl	$0x1, %eax
     af2:      	callq	*%rax
     af4:      	testq	%rax, %rax
     af7:      	je	0xb06 <kprobe_unwind_perl+0xb06>
     af9:      	incq	(%rax)
     afc:      	movq	0x98(%rsp), %rcx
     b04:      	jmp	0xb1e <kprobe_unwind_perl+0xb1e>
     b06:      	movq	(%rip), %rax            # 0xb0d <kprobe_unwind_perl+0xb0d>
     b0d:      	cmpl	$0x0, (%rax)
     b10:      	movq	0x98(%rsp), %rcx
     b18:      	jne	0x2d04 <kprobe_unwind_perl+0x2d04>
     b1e:      	cmpl	$0x3, %ebp
     b21:      	jne	0x5636 <kprobe_unwind_perl+0x5636>
     b27:      	movq	0xf50(%r15), %r13
     b2e:      	cmpq	%rcx, %r13
     b31:      	jb	0xcb <kprobe_unwind_perl+0xcb>
     b37:      	movzbl	0x19(%r14), %eax
     b3c:      	addq	%r13, %rax
     b3f:      	leaq	0xe(%rsp), %rdi
     b44:      	movl	$0x1, %ecx
     b49:      	movl	$0x70, %r8d
     b4f:      	movzbl	0x19(%r14), %edx
     b54:      	addq	%r13, %rdx
     b57:      	movl	$0x1, %esi
     b5c:      	callq	*%r8
     b5f:      	testq	%rax, %rax
     b62:      	je	0xc5e <kprobe_unwind_perl+0xc5e>
     b68:      	movq	(%rip), %rax            # 0xb6f <kprobe_unwind_perl+0xb6f>
     b6f:      	cmpl	$0x0, (%rax)
     b72:      	jne	0x33c3 <kprobe_unwind_perl+0x33c3>
     b78:      	movl	$0x13, 0x50(%rsp)
     b80:      	movq	(%rip), %rdi            # 0xb87 <kprobe_unwind_perl+0xb87>
     b87:      	leaq	0x50(%rsp), %rsi
     b8c:      	movl	$0x1, %eax
     b91:      	callq	*%rax
     b93:      	testq	%rax, %rax
     b96:      	je	0xe05 <kprobe_unwind_perl+0xe05>
     b9c:      	incq	(%rax)
     b9f:      	movl	$0x3, %ebp
     ba4:      	jmp	0xe2c <kprobe_unwind_perl+0xe2c>
     ba9:      	cmpl	$0x0, (%r13)
     bae:      	jne	0x3666 <kprobe_unwind_perl+0x3666>
     bb4:      	movl	$0x11, 0x50(%rsp)
     bbc:      	movq	(%rip), %rdi            # 0xbc3 <kprobe_unwind_perl+0xbc3>
     bc3:      	leaq	0x50(%rsp), %rsi
     bc8:      	movl	$0x1, %eax
     bcd:      	callq	*%rax
     bcf:      	testq	%rax, %rax
     bd2:      	je	0xbd9 <kprobe_unwind_perl+0xbd9>
     bd4:      	incq	(%rax)
     bd7:      	jmp	0xbe4 <kprobe_unwind_perl+0xbe4>
     bd9:      	cmpl	$0x0, (%r13)
     bde:      	jne	0x25e4 <kprobe_unwind_perl+0x25e4>
     be4:      	movl	$0x1, %ebp
     be9:      	jmp	0x586a <kprobe_unwind_perl+0x586a>
     bee:      	movq	%rbp, %r13
     bf1:      	cmpl	$0x0, (%rbp)
     bf5:      	je	0x188 <kprobe_unwind_perl+0x188>
     bfb:      	movabsq	$0x2079654b20445354, %rax # imm = 0x2079654B20445354
     c05:      	movq	%rax, 0x20(%rsp)
     c0a:      	movabsq	$0x202c786c25783020, %rax # imm = 0x202C786C25783020
     c14:      	movq	%rax, 0x18(%rsp)
     c19:      	movabsq	$0x6573614220445354, %rax # imm = 0x6573614220445354
     c23:      	movq	%rax, 0x10(%rsp)
     c28:      	movl	$0xa6425, 0x28(%rsp)    # imm = 0xA6425
     c30:      	leaq	0x10(%rsp), %rdi
     c35:      	movl	$0x1c, %eax
     c3a:      	movl	$0x6, %r8d
     c40:      	movq	0x88(%rsp), %rdx
     c48:      	movl	0xb4(%rsp), %ecx
     c4f:      	movl	$0x1c, %esi
     c54:      	xorl	%eax, %eax
     c56:      	callq	*%r8
     c59:      	jmp	0x188 <kprobe_unwind_perl+0x188>
     c5e:      	movq	(%rip), %rax            # 0xc65 <kprobe_unwind_perl+0xc65>
     c65:      	cmpl	$0x0, (%rax)
     c68:      	jne	0x37d0 <kprobe_unwind_perl+0x37d0>
     c6e:      	movzbl	0xe(%rsp), %eax
     c73:      	movl	%eax, %ecx
     c75:      	andl	$0xf, %ecx
     c78:      	movl	$0x3, %ebp
     c7d:      	leal	-0x9(%rcx), %edx
     c80:      	cmpl	$0x2, %edx
     c83:      	jae	0xe1c <kprobe_unwind_perl+0xe1c>
     c89:      	testb	%al, %al
     c8b:      	js	0xe2c <kprobe_unwind_perl+0xe2c>
     c91:      	movzbl	0x1b(%r14), %eax
     c96:      	addq	%r13, %rax
     c99:      	leaq	0x10(%rsp), %rdi
     c9e:      	movl	$0x8, %ecx
     ca3:      	movl	$0x70, %r8d
     ca9:      	movzbl	0x1b(%r14), %edx
     cae:      	addq	%r13, %rdx
     cb1:      	movl	$0x8, %esi
     cb6:      	callq	*%r8
     cb9:      	testq	%rax, %rax
     cbc:      	jne	0xb68 <kprobe_unwind_perl+0xb68>
     cc2:      	cmpq	$0x0, 0x10(%rsp)
     cc8:      	setne	%bpl
     ccc:      	movzbl	0x1c(%r14), %eax
     cd1:      	addq	%r13, %rax
     cd4:      	leaq	0xa0(%rsp), %rdi
     cdc:      	movl	$0x8, %ecx
     ce1:      	movl	$0x70, %r8d
     ce7:      	movzbl	0x1c(%r14), %edx
     cec:      	addq	%r13, %rdx
     cef:      	movl	$0x8, %esi
     cf4:      	callq	*%r8
     cf7:      	testq	%rax, %rax
     cfa:      	jne	0xb68 <kprobe_unwind_perl+0xb68>
     d00:      	movb	%bpl, 0xf(%rsp)
     d05:      	movq	0xa0(%rsp), %rbp
     d0d:      	movzbl	0x1e(%r14), %eax
     d12:      	addq	%rbp, %rax
     d15:      	leaq	0x5c(%rsp), %rdi
     d1a:      	movl	$0x4, %ecx
     d1f:      	movl	$0x70, %r8d
     d25:      	movzbl	0x1e(%r14), %edx
     d2a:      	addq	%rbp, %rdx
     d2d:      	movl	$0x4, %esi
     d32:      	callq	*%r8
     d35:      	testq	%rax, %rax
     d38:      	je	0x1bbe <kprobe_unwind_perl+0x1bbe>
     d3e:      	movq	(%rip), %rax            # 0xd45 <kprobe_unwind_perl+0xd45>
     d45:      	cmpl	$0x0, (%rax)
     d48:      	jne	0x4d9b <kprobe_unwind_perl+0x4d9b>
     d4e:      	movl	$0x14, 0x74(%rsp)
     d56:      	movq	(%rip), %rdi            # 0xd5d <kprobe_unwind_perl+0xd5d>
     d5d:      	leaq	0x74(%rsp), %rsi
     d62:      	movl	$0x1, %eax
     d67:      	callq	*%rax
     d69:      	testq	%rax, %rax
     d6c:      	je	0x2087 <kprobe_unwind_perl+0x2087>
     d72:      	incq	(%rax)
     d75:      	jmp	0xb68 <kprobe_unwind_perl+0xb68>
     d7a:      	movq	%rbp, %r13
     d7d:      	cmpl	$0x0, (%rbp)
     d81:      	je	0xf39 <kprobe_unwind_perl+0xf39>
     d87:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     d91:      	movq	%rax, 0x36(%rsp)
     d96:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     da0:      	movq	%rax, 0x30(%rsp)
     da5:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     daf:      	movq	%rax, 0x28(%rsp)
     db4:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     dbe:      	movq	%rax, 0x20(%rsp)
     dc3:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     dcd:      	movq	%rax, 0x18(%rsp)
     dd2:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     ddc:      	movq	%rax, 0x10(%rsp)
     de1:      	leaq	0x10(%rsp), %rdi
     de6:      	movl	$0x2e, %eax
     deb:      	movl	$0x6, %ecx
     df0:      	movl	0x88(%rsp), %edx
     df7:      	movl	$0x2e, %esi
     dfc:      	xorl	%eax, %eax
     dfe:      	callq	*%rcx
     e00:      	jmp	0xf39 <kprobe_unwind_perl+0xf39>
     e05:      	movq	(%rip), %rax            # 0xe0c <kprobe_unwind_perl+0xe0c>
     e0c:      	cmpl	$0x0, (%rax)
     e0f:      	jne	0x3986 <kprobe_unwind_perl+0x3986>
     e15:      	movl	$0x3, %ebp
     e1a:      	jmp	0xe2c <kprobe_unwind_perl+0xe2c>
     e1c:      	cmpl	$0xc, %ecx
     e1f:      	je	0xe2c <kprobe_unwind_perl+0xe2c>
     e21:      	cmpq	$0x0, (%r12)
     e26:      	je	0x1e61 <kprobe_unwind_perl+0x1e61>
     e2c:      	movzbl	0x1d(%r14), %eax
     e31:      	subq	%rax, 0xf50(%r15)
     e38:      	movl	$0x10, 0x50(%rsp)
     e40:      	movq	(%rip), %rdi            # 0xe47 <kprobe_unwind_perl+0xe47>
     e47:      	leaq	0x50(%rsp), %rsi
     e4c:      	movl	$0x1, %eax
     e51:      	callq	*%rax
     e53:      	testq	%rax, %rax
     e56:      	je	0xe65 <kprobe_unwind_perl+0xe65>
     e58:      	incq	(%rax)
     e5b:      	movq	0x98(%rsp), %rcx
     e63:      	jmp	0xe7d <kprobe_unwind_perl+0xe7d>
     e65:      	movq	(%rip), %rax            # 0xe6c <kprobe_unwind_perl+0xe6c>
     e6c:      	cmpl	$0x0, (%rax)
     e6f:      	movq	0x98(%rsp), %rcx
     e77:      	jne	0x3817 <kprobe_unwind_perl+0x3817>
     e7d:      	cmpl	$0x3, %ebp
     e80:      	jne	0x5636 <kprobe_unwind_perl+0x5636>
     e86:      	movq	0xf50(%r15), %r13
     e8d:      	cmpq	%rcx, %r13
     e90:      	jb	0xcb <kprobe_unwind_perl+0xcb>
     e96:      	movzbl	0x19(%r14), %eax
     e9b:      	addq	%r13, %rax
     e9e:      	leaq	0xe(%rsp), %rdi
     ea3:      	movl	$0x1, %ecx
     ea8:      	movl	$0x70, %r8d
     eae:      	movzbl	0x19(%r14), %edx
     eb3:      	addq	%r13, %rdx
     eb6:      	movl	$0x1, %esi
     ebb:      	callq	*%r8
     ebe:      	testq	%rax, %rax
     ec1:      	je	0x11cf <kprobe_unwind_perl+0x11cf>
     ec7:      	movq	(%rip), %rax            # 0xece <kprobe_unwind_perl+0xece>
     ece:      	cmpl	$0x0, (%rax)
     ed1:      	jne	0x3db7 <kprobe_unwind_perl+0x3db7>
     ed7:      	movl	$0x13, 0x50(%rsp)
     edf:      	movq	(%rip), %rdi            # 0xee6 <kprobe_unwind_perl+0xee6>
     ee6:      	leaq	0x50(%rsp), %rsi
     eeb:      	movl	$0x1, %eax
     ef0:      	callq	*%rax
     ef2:      	testq	%rax, %rax
     ef5:      	je	0x136b <kprobe_unwind_perl+0x136b>
     efb:      	incq	(%rax)
     efe:      	movl	$0x3, %ebp
     f03:      	jmp	0x13ff <kprobe_unwind_perl+0x13ff>
     f08:      	movq	%rbp, %r13
     f0b:      	cmpl	$0x0, (%rbp)
     f0f:      	jne	0x4040 <kprobe_unwind_perl+0x4040>
     f15:      	movq	0x50(%rsp), %rax
     f1a:      	movq	%rax, 0xf48(%r15)
     f21:      	movslq	0x78(%rsp), %rcx
     f26:      	movzbl	0x1d(%r14), %edx
     f2b:      	imulq	%rcx, %rdx
     f2f:      	addq	%rax, %rdx
     f32:      	movq	%rdx, 0xf50(%r15)
     f39:      	movq	0xb8(%rsp), %rax
     f41:      	movq	(%rax), %rax
     f44:      	movq	%rax, 0xa8(%rsp)
     f4c:      	testq	%rax, %rax
     f4f:      	jne	0xad <kprobe_unwind_perl+0xad>
     f55:      	jmp	0xbe4 <kprobe_unwind_perl+0xbe4>
     f5a:      	movl	0x5c(%rsp), %eax
     f5e:      	andl	$0x1f, %eax
     f61:      	cmpl	$0xd, %eax
     f64:      	jne	0x1382 <kprobe_unwind_perl+0x1382>
     f6a:      	movzbl	0x1f(%r14), %eax
     f6f:      	addq	%rbp, %rax
     f72:      	leaq	0x50(%rsp), %rdi
     f77:      	movl	$0x8, %ecx
     f7c:      	movl	$0x70, %r8d
     f82:      	movzbl	0x1f(%r14), %edx
     f87:      	addq	%rbp, %rdx
     f8a:      	movl	$0x8, %esi
     f8f:      	callq	*%r8
     f92:      	testq	%rax, %rax
     f95:      	jne	0x47c <kprobe_unwind_perl+0x47c>
     f9b:      	movzbl	0x21(%r14), %eax
     fa0:      	addq	0x50(%rsp), %rax
     fa5:      	leaq	0x70(%rsp), %rdi
     faa:      	movl	$0x4, %ecx
     faf:      	movl	$0x70, %r8d
     fb5:      	movzbl	0x21(%r14), %edx
     fba:      	addq	0x50(%rsp), %rdx
     fbf:      	movl	$0x4, %esi
     fc4:      	callq	*%r8
     fc7:      	testq	%rax, %rax
     fca:      	jne	0x47c <kprobe_unwind_perl+0x47c>
     fd0:      	testb	$-0x80, 0x71(%rsp)
     fd5:      	jne	0x2256 <kprobe_unwind_perl+0x2256>
     fdb:      	movzbl	0x22(%r14), %eax
     fe0:      	addq	0x50(%rsp), %rax
     fe5:      	leaq	0x60(%rsp), %rbp
     fea:      	movl	$0x8, %ecx
     fef:      	movl	$0x70, %r8d
     ff5:      	movzbl	0x22(%r14), %edx
     ffa:      	addq	0x50(%rsp), %rdx
     fff:      	movq	%rbp, %rdi
    1002:      	movl	$0x8, %esi
    1007:      	callq	*%r8
    100a:      	testq	%rax, %rax
    100d:      	jne	0x47c <kprobe_unwind_perl+0x47c>
    1013:      	movq	0x60(%rsp), %rax
    1018:      	testq	%rax, %rax
    101b:      	je	0x47c <kprobe_unwind_perl+0x47c>
    1021:      	movq	(%rip), %rcx            # 0x1028 <kprobe_unwind_perl+0x1028>
    1028:      	cmpl	$0x0, (%rcx)
    102b:      	jne	0x65a5 <kprobe_unwind_perl+0x65a5>
    1031:      	movzbl	0x1e(%r14), %ecx
    1036:      	addq	%rax, %rcx
    1039:      	leaq	0x6c(%rsp), %rdi
    103e:      	movl	$0x4, %eax
    1043:      	movl	$0x70, %r8d
    1049:      	movzbl	0x1e(%r14), %edx
    104e:      	addq	0x60(%rsp), %rdx
    1053:      	movl	$0x4, %esi
    1058:      	callq	*%r8
    105b:      	testq	%rax, %rax
    105e:      	jne	0x47c <kprobe_unwind_perl+0x47c>
    1064:      	movl	$0x801f, %eax           # imm = 0x801F
    1069:      	andl	0x6c(%rsp), %eax
    106d:      	cmpl	$0x8009, %eax           # imm = 0x8009
    1072:      	jne	0x354d <kprobe_unwind_perl+0x354d>
    1078:      	movzbl	0x20(%r14), %eax
    107d:      	addq	0x60(%rsp), %rax
    1082:      	leaq	0x88(%rsp), %rdi
    108a:      	movl	$0x8, %ecx
    108f:      	movl	$0x70, %r8d
    1095:      	movzbl	0x20(%r14), %edx
    109a:      	addq	0x60(%rsp), %rdx
    109f:      	movl	$0x8, %esi
    10a4:      	callq	*%r8
    10a7:      	testq	%rax, %rax
    10aa:      	jne	0x47c <kprobe_unwind_perl+0x47c>
    10b0:      	movzbl	0x23(%r14), %eax
    10b5:      	addq	0x88(%rsp), %rax
    10bd:      	leaq	0x78(%rsp), %rdi
    10c2:      	movl	$0x8, %ecx
    10c7:      	movl	$0x70, %r8d
    10cd:      	movzbl	0x23(%r14), %edx
    10d2:      	addq	0x88(%rsp), %rdx
    10da:      	movl	$0x8, %esi
    10df:      	callq	*%r8
    10e2:      	testq	%rax, %rax
    10e5:      	jne	0x47c <kprobe_unwind_perl+0x47c>
    10eb:      	movq	0x78(%rsp), %rax
    10f0:      	movq	%rax, 0x80(%rsp)
    10f8:      	testq	%rax, %rax
    10fb:      	je	0x1151 <kprobe_unwind_perl+0x1151>
    10fd:      	movq	(%rip), %rax            # 0x1104 <kprobe_unwind_perl+0x1104>
    1104:      	cmpl	$0x0, (%rax)
    1107:      	je	0x1166 <kprobe_unwind_perl+0x1166>
    1109:      	movabsq	$0x2578302074612056, %rax # imm = 0x2578302074612056
    1113:      	movq	%rax, 0x18(%rsp)
    1118:      	movabsq	$0x474520646e756f46, %rax # imm = 0x474520646E756F46
    1122:      	movq	%rax, 0x10(%rsp)
    1127:      	movl	$0xa786c, 0x20(%rsp)    # imm = 0xA786C
    112f:      	leaq	0x10(%rsp), %rdi
    1134:      	movl	$0x14, %eax
    1139:      	movl	$0x6, %ecx
    113e:      	movq	0x78(%rsp), %rdx
    1143:      	movl	$0x14, %esi
    1148:      	xorl	%eax, %eax
    114a:      	callq	*%rcx
    114c:      	leaq	0x78(%rsp), %rbp
    1151:      	movq	(%rbp), %rax
    1155:      	movq	%rax, 0x80(%rsp)
    115d:      	testq	%rax, %rax
    1160:      	je	0x27c <kprobe_unwind_perl+0x27c>
    1166:      	movq	(%r12), %rax
    116a:      	movq	%rax, 0x90(%rsp)
    1172:      	movq	(%rip), %rax            # 0x1179 <kprobe_unwind_perl+0x1179>
    1179:      	cmpl	$0x0, (%rax)
    117c:      	jne	0x7d00 <kprobe_unwind_perl+0x7d00>
    1182:      	movl	0x2c0(%r15), %eax
    1189:      	cmpq	$0x7f, %rax
    118d:      	jb	0x7d86 <kprobe_unwind_perl+0x7d86>
    1193:      	movq	(%rip), %rax            # 0x119a <kprobe_unwind_perl+0x119a>
    119a:      	cmpl	$0x0, (%rax)
    119d:      	jne	0x7f4b <kprobe_unwind_perl+0x7f4b>
    11a3:      	movl	$0x2, 0x50(%rsp)
    11ab:      	movq	(%rip), %rdi            # 0x11b2 <kprobe_unwind_perl+0x11b2>
    11b2:      	leaq	0x50(%rsp), %rsi
    11b7:      	movl	$0x1, %eax
    11bc:      	callq	*%rax
    11be:      	testq	%rax, %rax
    11c1:      	je	0x4ceb <kprobe_unwind_perl+0x4ceb>
    11c7:      	incq	(%rax)
    11ca:      	jmp	0x4cfb <kprobe_unwind_perl+0x4cfb>
    11cf:      	movq	(%rip), %rax            # 0x11d6 <kprobe_unwind_perl+0x11d6>
    11d6:      	cmpl	$0x0, (%rax)
    11d9:      	jne	0x41bc <kprobe_unwind_perl+0x41bc>
    11df:      	movzbl	0xe(%rsp), %eax
    11e4:      	movl	%eax, %ecx
    11e6:      	andl	$0xf, %ecx
    11e9:      	movl	$0x3, %ebp
    11ee:      	leal	-0x9(%rcx), %edx
    11f1:      	cmpl	$0x2, %edx
    11f4:      	jae	0x13ef <kprobe_unwind_perl+0x13ef>
    11fa:      	testb	%al, %al
    11fc:      	js	0x13ff <kprobe_unwind_perl+0x13ff>
    1202:      	movzbl	0x1b(%r14), %eax
    1207:      	addq	%r13, %rax
    120a:      	leaq	0x10(%rsp), %rdi
    120f:      	movl	$0x8, %ecx
    1214:      	movl	$0x70, %r8d
    121a:      	movzbl	0x1b(%r14), %edx
    121f:      	addq	%r13, %rdx
    1222:      	movl	$0x8, %esi
    1227:      	callq	*%r8
    122a:      	testq	%rax, %rax
    122d:      	jne	0xec7 <kprobe_unwind_perl+0xec7>
    1233:      	cmpq	$0x0, 0x10(%rsp)
    1239:      	setne	0xf(%rsp)
    123e:      	movzbl	0x1c(%r14), %eax
    1243:      	addq	%r13, %rax
    1246:      	leaq	0xa0(%rsp), %rdi
    124e:      	movl	$0x8, %ecx
    1253:      	movl	$0x70, %r8d
    1259:      	movzbl	0x1c(%r14), %edx
    125e:      	addq	%r13, %rdx
    1261:      	movl	$0x8, %esi
    1266:      	callq	*%r8
    1269:      	testq	%rax, %rax
    126c:      	jne	0xec7 <kprobe_unwind_perl+0xec7>
    1272:      	movq	0xa0(%rsp), %rbp
    127a:      	movzbl	0x1e(%r14), %eax
    127f:      	addq	%rbp, %rax
    1282:      	leaq	0x5c(%rsp), %rdi
    1287:      	movl	$0x4, %ecx
    128c:      	movl	$0x70, %r8d
    1292:      	movzbl	0x1e(%r14), %edx
    1297:      	addq	%rbp, %rdx
    129a:      	movl	$0x4, %esi
    129f:      	callq	*%r8
    12a2:      	testq	%rax, %rax
    12a5:      	je	0x2664 <kprobe_unwind_perl+0x2664>
    12ab:      	movq	(%rip), %rax            # 0x12b2 <kprobe_unwind_perl+0x12b2>
    12b2:      	cmpl	$0x0, (%rax)
    12b5:      	jne	0x5f4c <kprobe_unwind_perl+0x5f4c>
    12bb:      	movl	$0x14, 0x74(%rsp)
    12c3:      	movq	(%rip), %rdi            # 0x12ca <kprobe_unwind_perl+0x12ca>
    12ca:      	leaq	0x74(%rsp), %rsi
    12cf:      	movl	$0x1, %eax
    12d4:      	callq	*%rax
    12d6:      	testq	%rax, %rax
    12d9:      	je	0x2b2d <kprobe_unwind_perl+0x2b2d>
    12df:      	incq	(%rax)
    12e2:      	jmp	0xec7 <kprobe_unwind_perl+0xec7>
    12e7:      	movq	(%rip), %rax            # 0x12ee <kprobe_unwind_perl+0x12ee>
    12ee:      	cmpl	$0x0, (%rax)
    12f1:      	je	0x27c <kprobe_unwind_perl+0x27c>
    12f7:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1301:      	movq	%rax, 0x36(%rsp)
    1306:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1310:      	movq	%rax, 0x30(%rsp)
    1315:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    131f:      	movq	%rax, 0x28(%rsp)
    1324:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    132e:      	movq	%rax, 0x20(%rsp)
    1333:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    133d:      	movq	%rax, 0x18(%rsp)
    1342:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    134c:      	movq	%rax, 0x10(%rsp)
    1351:      	leaq	0x10(%rsp), %rdi
    1356:      	movl	$0x2e, %eax
    135b:      	movl	$0x6, %ecx
    1360:      	movl	0x74(%rsp), %edx
    1364:      	movl	$0x2e, %esi
    1369:      	jmp	0x13e6 <kprobe_unwind_perl+0x13e6>
    136b:      	movq	(%rip), %rax            # 0x1372 <kprobe_unwind_perl+0x1372>
    1372:      	cmpl	$0x0, (%rax)
    1375:      	jne	0x4372 <kprobe_unwind_perl+0x4372>
    137b:      	movl	$0x3, %ebp
    1380:      	jmp	0x13ff <kprobe_unwind_perl+0x13ff>
    1382:      	movq	(%rip), %rax            # 0x1389 <kprobe_unwind_perl+0x1389>
    1389:      	cmpl	$0x0, (%rax)
    138c:      	je	0x27c <kprobe_unwind_perl+0x27c>
    1392:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    139c:      	movq	%rax, 0x26(%rsp)
    13a1:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    13ab:      	movq	%rax, 0x20(%rsp)
    13b0:      	movabsq	$0x5643565020612074, %rax # imm = 0x5643565020612074
    13ba:      	movq	%rax, 0x18(%rsp)
    13bf:      	movabsq	$0x6f6e207369205643, %rax # imm = 0x6F6E207369205643
    13c9:      	movq	%rax, 0x10(%rsp)
    13ce:      	leaq	0x10(%rsp), %rdi
    13d3:      	movl	$0x1e, %eax
    13d8:      	movl	$0x6, %ecx
    13dd:      	movl	0x5c(%rsp), %edx
    13e1:      	movl	$0x1e, %esi
    13e6:      	xorl	%eax, %eax
    13e8:      	callq	*%rcx
    13ea:      	jmp	0x27c <kprobe_unwind_perl+0x27c>
    13ef:      	cmpl	$0xc, %ecx
    13f2:      	je	0x13ff <kprobe_unwind_perl+0x13ff>
    13f4:      	cmpq	$0x0, (%r12)
    13f9:      	je	0x2907 <kprobe_unwind_perl+0x2907>
    13ff:      	movzbl	0x1d(%r14), %eax
    1404:      	subq	%rax, 0xf50(%r15)
    140b:      	movl	$0x10, 0x50(%rsp)
    1413:      	movq	(%rip), %rdi            # 0x141a <kprobe_unwind_perl+0x141a>
    141a:      	leaq	0x50(%rsp), %rsi
    141f:      	movl	$0x1, %eax
    1424:      	callq	*%rax
    1426:      	testq	%rax, %rax
    1429:      	je	0x1438 <kprobe_unwind_perl+0x1438>
    142b:      	incq	(%rax)
    142e:      	movq	0x98(%rsp), %rcx
    1436:      	jmp	0x1450 <kprobe_unwind_perl+0x1450>
    1438:      	movq	(%rip), %rax            # 0x143f <kprobe_unwind_perl+0x143f>
    143f:      	cmpl	$0x0, (%rax)
    1442:      	movq	0x98(%rsp), %rcx
    144a:      	jne	0x4203 <kprobe_unwind_perl+0x4203>
    1450:      	cmpl	$0x3, %ebp
    1453:      	jne	0x5636 <kprobe_unwind_perl+0x5636>
    1459:      	movq	0xf50(%r15), %r13
    1460:      	cmpq	%rcx, %r13
    1463:      	jb	0xcb <kprobe_unwind_perl+0xcb>
    1469:      	movzbl	0x19(%r14), %eax
    146e:      	addq	%r13, %rax
    1471:      	leaq	0xe(%rsp), %rdi
    1476:      	movl	$0x1, %ecx
    147b:      	movl	$0x70, %r8d
    1481:      	movzbl	0x19(%r14), %edx
    1486:      	addq	%r13, %rdx
    1489:      	movl	$0x1, %esi
    148e:      	callq	*%r8
    1491:      	testq	%rax, %rax
    1494:      	je	0x18b2 <kprobe_unwind_perl+0x18b2>
    149a:      	movq	(%rip), %rax            # 0x14a1 <kprobe_unwind_perl+0x14a1>
    14a1:      	cmpl	$0x0, (%rax)
    14a4:      	jne	0x47a3 <kprobe_unwind_perl+0x47a3>
    14aa:      	movl	$0x13, 0x50(%rsp)
    14b2:      	movq	(%rip), %rdi            # 0x14b9 <kprobe_unwind_perl+0x14b9>
    14b9:      	leaq	0x50(%rsp), %rsi
    14be:      	movl	$0x1, %eax
    14c3:      	callq	*%rax
    14c5:      	testq	%rax, %rax
    14c8:      	je	0x1a4e <kprobe_unwind_perl+0x1a4e>
    14ce:      	incq	(%rax)
    14d1:      	movl	$0x3, %ebp
    14d6:      	jmp	0x1ae2 <kprobe_unwind_perl+0x1ae2>
    14db:      	movabsq	$0xa29286c726570, %rax  # imm = 0xA29286C726570
    14e5:      	movq	%rax, 0x17(%rsp)
    14ea:      	movabsq	$0x705f646e69776e75, %rax # imm = 0x705F646E69776E75
    14f4:      	movq	%rax, 0x10(%rsp)
    14f9:      	leaq	0x10(%rsp), %rdi
    14fe:      	movl	$0xf, %eax
    1503:      	movl	$0x6, %ecx
    1508:      	movl	$0xf, %esi
    150d:      	xorl	%eax, %eax
    150f:      	callq	*%rcx
    1511:      	jmp	0x5b <kprobe_unwind_perl+0x5b>
    1516:      	movabsq	$0xa782578302072, %rax  # imm = 0xA782578302072
    1520:      	movq	%rax, 0x26(%rsp)
    1525:      	movabsq	$0x20726f66206b6361, %rax # imm = 0x20726F66206B6361
    152f:      	movq	%rax, 0x20(%rsp)
    1534:      	movabsq	$0x7473206c72655020, %rax # imm = 0x7473206C72655020
    153e:      	movq	%rax, 0x18(%rsp)
    1543:      	movabsq	$0x676e69646c697542, %rax # imm = 0x676E69646C697542
    154d:      	movq	%rax, 0x10(%rsp)
    1552:      	leaq	0x10(%rsp), %rdi
    1557:      	movl	$0x1e, %eax
    155c:      	movl	$0x6, %ecx
    1561:      	movl	0x8(%r14), %edx
    1565:      	movl	$0x1e, %esi
    156a:      	xorl	%eax, %eax
    156c:      	callq	*%rcx
    156e:      	jmp	0x85 <kprobe_unwind_perl+0x85>
    1573:      	movl	0x5c(%rsp), %eax
    1577:      	andl	$0x1f, %eax
    157a:      	cmpl	$0xd, %eax
    157d:      	jne	0x1a65 <kprobe_unwind_perl+0x1a65>
    1583:      	movzbl	0x1f(%r14), %eax
    1588:      	addq	%rbp, %rax
    158b:      	leaq	0x50(%rsp), %rdi
    1590:      	movl	$0x8, %ecx
    1595:      	movl	$0x70, %r8d
    159b:      	movzbl	0x1f(%r14), %edx
    15a0:      	addq	%rbp, %rdx
    15a3:      	movl	$0x8, %esi
    15a8:      	callq	*%r8
    15ab:      	testq	%rax, %rax
    15ae:      	jne	0x9ad <kprobe_unwind_perl+0x9ad>
    15b4:      	movzbl	0x21(%r14), %eax
    15b9:      	addq	0x50(%rsp), %rax
    15be:      	leaq	0x70(%rsp), %rdi
    15c3:      	movl	$0x4, %ecx
    15c8:      	movl	$0x70, %r8d
    15ce:      	movzbl	0x21(%r14), %edx
    15d3:      	addq	0x50(%rsp), %rdx
    15d8:      	movl	$0x4, %esi
    15dd:      	callq	*%r8
    15e0:      	testq	%rax, %rax
    15e3:      	jne	0x9ad <kprobe_unwind_perl+0x9ad>
    15e9:      	testb	$-0x80, 0x71(%rsp)
    15ee:      	jne	0x2bce <kprobe_unwind_perl+0x2bce>
    15f4:      	movzbl	0x22(%r14), %eax
    15f9:      	addq	0x50(%rsp), %rax
    15fe:      	leaq	0x60(%rsp), %rbp
    1603:      	movl	$0x8, %ecx
    1608:      	movl	$0x70, %r8d
    160e:      	movzbl	0x22(%r14), %edx
    1613:      	addq	0x50(%rsp), %rdx
    1618:      	movq	%rbp, %rdi
    161b:      	movl	$0x8, %esi
    1620:      	callq	*%r8
    1623:      	testq	%rax, %rax
    1626:      	jne	0x9ad <kprobe_unwind_perl+0x9ad>
    162c:      	movq	0x60(%rsp), %rax
    1631:      	testq	%rax, %rax
    1634:      	je	0x9ad <kprobe_unwind_perl+0x9ad>
    163a:      	movq	(%rip), %rcx            # 0x1641 <kprobe_unwind_perl+0x1641>
    1641:      	cmpl	$0x0, (%rcx)
    1644:      	jne	0x6e25 <kprobe_unwind_perl+0x6e25>
    164a:      	movzbl	0x1e(%r14), %ecx
    164f:      	addq	%rax, %rcx
    1652:      	leaq	0x6c(%rsp), %rdi
    1657:      	movl	$0x4, %eax
    165c:      	movl	$0x70, %r8d
    1662:      	movzbl	0x1e(%r14), %edx
    1667:      	addq	0x60(%rsp), %rdx
    166c:      	movl	$0x4, %esi
    1671:      	callq	*%r8
    1674:      	testq	%rax, %rax
    1677:      	jne	0x9ad <kprobe_unwind_perl+0x9ad>
    167d:      	movl	$0x801f, %eax           # imm = 0x801F
    1682:      	andl	0x6c(%rsp), %eax
    1686:      	cmpl	$0x8009, %eax           # imm = 0x8009
    168b:      	jne	0x3f41 <kprobe_unwind_perl+0x3f41>
    1691:      	movzbl	0x20(%r14), %eax
    1696:      	addq	0x60(%rsp), %rax
    169b:      	leaq	0x88(%rsp), %rdi
    16a3:      	movl	$0x8, %ecx
    16a8:      	movl	$0x70, %r8d
    16ae:      	movzbl	0x20(%r14), %edx
    16b3:      	addq	0x60(%rsp), %rdx
    16b8:      	movl	$0x8, %esi
    16bd:      	callq	*%r8
    16c0:      	testq	%rax, %rax
    16c3:      	jne	0x9ad <kprobe_unwind_perl+0x9ad>
    16c9:      	movzbl	0x23(%r14), %eax
    16ce:      	addq	0x88(%rsp), %rax
    16d6:      	leaq	0x78(%rsp), %rdi
    16db:      	movl	$0x8, %ecx
    16e0:      	movl	$0x70, %r8d
    16e6:      	movzbl	0x23(%r14), %edx
    16eb:      	addq	0x88(%rsp), %rdx
    16f3:      	movl	$0x8, %esi
    16f8:      	callq	*%r8
    16fb:      	testq	%rax, %rax
    16fe:      	jne	0x9ad <kprobe_unwind_perl+0x9ad>
    1704:      	movq	0x78(%rsp), %rax
    1709:      	movq	%rax, 0x80(%rsp)
    1711:      	testq	%rax, %rax
    1714:      	je	0x176a <kprobe_unwind_perl+0x176a>
    1716:      	movq	(%rip), %rax            # 0x171d <kprobe_unwind_perl+0x171d>
    171d:      	cmpl	$0x0, (%rax)
    1720:      	je	0x177f <kprobe_unwind_perl+0x177f>
    1722:      	movabsq	$0x2578302074612056, %rax # imm = 0x2578302074612056
    172c:      	movq	%rax, 0x18(%rsp)
    1731:      	movabsq	$0x474520646e756f46, %rax # imm = 0x474520646E756F46
    173b:      	movq	%rax, 0x10(%rsp)
    1740:      	movl	$0xa786c, 0x20(%rsp)    # imm = 0xA786C
    1748:      	leaq	0x10(%rsp), %rdi
    174d:      	movl	$0x14, %eax
    1752:      	movl	$0x6, %ecx
    1757:      	movq	0x78(%rsp), %rdx
    175c:      	movl	$0x14, %esi
    1761:      	xorl	%eax, %eax
    1763:      	callq	*%rcx
    1765:      	leaq	0x78(%rsp), %rbp
    176a:      	movq	(%rbp), %rax
    176e:      	movq	%rax, 0x80(%rsp)
    1776:      	testq	%rax, %rax
    1779:      	je	0x568 <kprobe_unwind_perl+0x568>
    177f:      	movq	(%r12), %rax
    1783:      	movq	%rax, 0x90(%rsp)
    178b:      	movq	(%rip), %rax            # 0x1792 <kprobe_unwind_perl+0x1792>
    1792:      	cmpl	$0x0, (%rax)
    1795:      	jne	0x834a <kprobe_unwind_perl+0x834a>
    179b:      	movl	0x2c0(%r15), %eax
    17a2:      	cmpq	$0x7e, %rax
    17a6:      	ja	0x1193 <kprobe_unwind_perl+0x1193>
    17ac:      	xorl	%ecx, %ecx
    17ae:      	movzbl	0xf(%rsp), %edx
    17b3:      	movb	%dl, %cl
    17b5:      	leal	0x1(,%rcx,2), %ebp
    17bc:      	leal	0x1(%rax), %ecx
    17bf:      	movl	%ecx, 0x2c0(%r15)
    17c6:      	leaq	(%rax,%rax,2), %rax
    17ca:      	movq	0x80(%rsp), %rcx
    17d2:      	movq	%rcx, 0x2d0(%r15,%rax,8)
    17da:      	movq	0x90(%rsp), %rcx
    17e2:      	movq	%rcx, 0x2d8(%r15,%rax,8)
    17ea:      	movb	$0x7, 0x2e0(%r15,%rax,8)
    17f3:      	movl	$0x0, 0x2e1(%r15,%rax,8)
    17ff:      	movl	$0x0, 0x2e4(%r15,%rax,8)
    180b:      	movq	$0x0, 0xf40(%r15)
    1816:      	movzbl	0x1a(%r14), %eax
    181b:      	addq	%r13, %rax
    181e:      	movl	$0x8, %ecx
    1823:      	movl	$0x70, %r8d
    1829:      	movzbl	0x1a(%r14), %edx
    182e:      	addq	%r13, %rdx
    1831:      	movq	%r12, %rdi
    1834:      	movl	$0x8, %esi
    1839:      	callq	*%r8
    183c:      	testq	%rax, %rax
    183f:      	jne	0x568 <kprobe_unwind_perl+0x568>
    1845:      	movq	(%rip), %rax            # 0x184c <kprobe_unwind_perl+0x184c>
    184c:      	cmpl	$0x0, (%rax)
    184f:      	je	0xacd <kprobe_unwind_perl+0xacd>
    1855:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    185f:      	movq	%rax, 0x26(%rsp)
    1864:      	movabsq	$0x30206b6361747320, %rax # imm = 0x30206B6361747320
    186e:      	movq	%rax, 0x20(%rsp)
    1873:      	movabsq	$0x747865746e6f6320, %rax # imm = 0x747865746E6F6320
    187d:      	movq	%rax, 0x18(%rsp)
    1882:      	movabsq	$0x6d6f726620504f43, %rax # imm = 0x6D6F726620504F43
    188c:      	movq	%rax, 0x10(%rsp)
    1891:      	leaq	0x10(%rsp), %rdi
    1896:      	movl	$0x1e, %eax
    189b:      	movl	$0x6, %ecx
    18a0:      	movq	(%r12), %rdx
    18a4:      	movl	$0x1e, %esi
    18a9:      	xorl	%eax, %eax
    18ab:      	callq	*%rcx
    18ad:      	jmp	0xacd <kprobe_unwind_perl+0xacd>
    18b2:      	movq	(%rip), %rax            # 0x18b9 <kprobe_unwind_perl+0x18b9>
    18b9:      	cmpl	$0x0, (%rax)
    18bc:      	jne	0x4b35 <kprobe_unwind_perl+0x4b35>
    18c2:      	movzbl	0xe(%rsp), %eax
    18c7:      	movl	%eax, %ecx
    18c9:      	andl	$0xf, %ecx
    18cc:      	movl	$0x3, %ebp
    18d1:      	leal	-0x9(%rcx), %edx
    18d4:      	cmpl	$0x2, %edx
    18d7:      	jae	0x1ad2 <kprobe_unwind_perl+0x1ad2>
    18dd:      	testb	%al, %al
    18df:      	js	0x1ae2 <kprobe_unwind_perl+0x1ae2>
    18e5:      	movzbl	0x1b(%r14), %eax
    18ea:      	addq	%r13, %rax
    18ed:      	leaq	0x10(%rsp), %rdi
    18f2:      	movl	$0x8, %ecx
    18f7:      	movl	$0x70, %r8d
    18fd:      	movzbl	0x1b(%r14), %edx
    1902:      	addq	%r13, %rdx
    1905:      	movl	$0x8, %esi
    190a:      	callq	*%r8
    190d:      	testq	%rax, %rax
    1910:      	jne	0x149a <kprobe_unwind_perl+0x149a>
    1916:      	cmpq	$0x0, 0x10(%rsp)
    191c:      	setne	0xf(%rsp)
    1921:      	movzbl	0x1c(%r14), %eax
    1926:      	addq	%r13, %rax
    1929:      	leaq	0xa0(%rsp), %rdi
    1931:      	movl	$0x8, %ecx
    1936:      	movl	$0x70, %r8d
    193c:      	movzbl	0x1c(%r14), %edx
    1941:      	addq	%r13, %rdx
    1944:      	movl	$0x8, %esi
    1949:      	callq	*%r8
    194c:      	testq	%rax, %rax
    194f:      	jne	0x149a <kprobe_unwind_perl+0x149a>
    1955:      	movq	0xa0(%rsp), %rbp
    195d:      	movzbl	0x1e(%r14), %eax
    1962:      	addq	%rbp, %rax
    1965:      	leaq	0x5c(%rsp), %rdi
    196a:      	movl	$0x4, %ecx
    196f:      	movl	$0x70, %r8d
    1975:      	movzbl	0x1e(%r14), %edx
    197a:      	addq	%rbp, %rdx
    197d:      	movl	$0x4, %esi
    1982:      	callq	*%r8
    1985:      	testq	%rax, %rax
    1988:      	je	0x3084 <kprobe_unwind_perl+0x3084>
    198e:      	movq	(%rip), %rax            # 0x1995 <kprobe_unwind_perl+0x1995>
    1995:      	cmpl	$0x0, (%rax)
    1998:      	jne	0x68fe <kprobe_unwind_perl+0x68fe>
    199e:      	movl	$0x14, 0x74(%rsp)
    19a6:      	movq	(%rip), %rdi            # 0x19ad <kprobe_unwind_perl+0x19ad>
    19ad:      	leaq	0x74(%rsp), %rsi
    19b2:      	movl	$0x1, %eax
    19b7:      	callq	*%rax
    19b9:      	testq	%rax, %rax
    19bc:      	je	0x35c5 <kprobe_unwind_perl+0x35c5>
    19c2:      	incq	(%rax)
    19c5:      	jmp	0x149a <kprobe_unwind_perl+0x149a>
    19ca:      	movq	(%rip), %rax            # 0x19d1 <kprobe_unwind_perl+0x19d1>
    19d1:      	cmpl	$0x0, (%rax)
    19d4:      	je	0x568 <kprobe_unwind_perl+0x568>
    19da:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    19e4:      	movq	%rax, 0x36(%rsp)
    19e9:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    19f3:      	movq	%rax, 0x30(%rsp)
    19f8:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1a02:      	movq	%rax, 0x28(%rsp)
    1a07:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1a11:      	movq	%rax, 0x20(%rsp)
    1a16:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1a20:      	movq	%rax, 0x18(%rsp)
    1a25:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1a2f:      	movq	%rax, 0x10(%rsp)
    1a34:      	leaq	0x10(%rsp), %rdi
    1a39:      	movl	$0x2e, %eax
    1a3e:      	movl	$0x6, %ecx
    1a43:      	movl	0x74(%rsp), %edx
    1a47:      	movl	$0x2e, %esi
    1a4c:      	jmp	0x1ac9 <kprobe_unwind_perl+0x1ac9>
    1a4e:      	movq	(%rip), %rax            # 0x1a55 <kprobe_unwind_perl+0x1a55>
    1a55:      	cmpl	$0x0, (%rax)
    1a58:      	jne	0x4d20 <kprobe_unwind_perl+0x4d20>
    1a5e:      	movl	$0x3, %ebp
    1a63:      	jmp	0x1ae2 <kprobe_unwind_perl+0x1ae2>
    1a65:      	movq	(%rip), %rax            # 0x1a6c <kprobe_unwind_perl+0x1a6c>
    1a6c:      	cmpl	$0x0, (%rax)
    1a6f:      	je	0x568 <kprobe_unwind_perl+0x568>
    1a75:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    1a7f:      	movq	%rax, 0x26(%rsp)
    1a84:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    1a8e:      	movq	%rax, 0x20(%rsp)
    1a93:      	movabsq	$0x5643565020612074, %rax # imm = 0x5643565020612074
    1a9d:      	movq	%rax, 0x18(%rsp)
    1aa2:      	movabsq	$0x6f6e207369205643, %rax # imm = 0x6F6E207369205643
    1aac:      	movq	%rax, 0x10(%rsp)
    1ab1:      	leaq	0x10(%rsp), %rdi
    1ab6:      	movl	$0x1e, %eax
    1abb:      	movl	$0x6, %ecx
    1ac0:      	movl	0x5c(%rsp), %edx
    1ac4:      	movl	$0x1e, %esi
    1ac9:      	xorl	%eax, %eax
    1acb:      	callq	*%rcx
    1acd:      	jmp	0x568 <kprobe_unwind_perl+0x568>
    1ad2:      	cmpl	$0xc, %ecx
    1ad5:      	je	0x1ae2 <kprobe_unwind_perl+0x1ae2>
    1ad7:      	cmpq	$0x0, (%r12)
    1adc:      	je	0x3327 <kprobe_unwind_perl+0x3327>
    1ae2:      	movzbl	0x1d(%r14), %eax
    1ae7:      	subq	%rax, 0xf50(%r15)
    1aee:      	movl	$0x10, 0x50(%rsp)
    1af6:      	movq	(%rip), %rdi            # 0x1afd <kprobe_unwind_perl+0x1afd>
    1afd:      	leaq	0x50(%rsp), %rsi
    1b02:      	movl	$0x1, %eax
    1b07:      	callq	*%rax
    1b09:      	testq	%rax, %rax
    1b0c:      	je	0x1b1b <kprobe_unwind_perl+0x1b1b>
    1b0e:      	incq	(%rax)
    1b11:      	movq	0x98(%rsp), %rcx
    1b19:      	jmp	0x1b33 <kprobe_unwind_perl+0x1b33>
    1b1b:      	movq	(%rip), %rax            # 0x1b22 <kprobe_unwind_perl+0x1b22>
    1b22:      	cmpl	$0x0, (%rax)
    1b25:      	movq	0x98(%rsp), %rcx
    1b2d:      	jne	0x4b7c <kprobe_unwind_perl+0x4b7c>
    1b33:      	cmpl	$0x3, %ebp
    1b36:      	jne	0x5636 <kprobe_unwind_perl+0x5636>
    1b3c:      	movq	0xf50(%r15), %r13
    1b43:      	cmpq	%rcx, %r13
    1b46:      	jb	0xcb <kprobe_unwind_perl+0xcb>
    1b4c:      	movzbl	0x19(%r14), %eax
    1b51:      	addq	%r13, %rax
    1b54:      	leaq	0xe(%rsp), %rdi
    1b59:      	movl	$0x1, %ecx
    1b5e:      	movl	$0x70, %r8d
    1b64:      	movzbl	0x19(%r14), %edx
    1b69:      	addq	%r13, %rdx
    1b6c:      	movl	$0x1, %esi
    1b71:      	callq	*%r8
    1b74:      	testq	%rax, %rax
    1b77:      	je	0x1f6f <kprobe_unwind_perl+0x1f6f>
    1b7d:      	movq	(%rip), %rax            # 0x1b84 <kprobe_unwind_perl+0x1b84>
    1b84:      	cmpl	$0x0, (%rax)
    1b87:      	jne	0x5151 <kprobe_unwind_perl+0x5151>
    1b8d:      	movl	$0x13, 0x50(%rsp)
    1b95:      	movq	(%rip), %rdi            # 0x1b9c <kprobe_unwind_perl+0x1b9c>
    1b9c:      	leaq	0x50(%rsp), %rsi
    1ba1:      	movl	$0x1, %eax
    1ba6:      	callq	*%rax
    1ba8:      	testq	%rax, %rax
    1bab:      	je	0x210e <kprobe_unwind_perl+0x210e>
    1bb1:      	incq	(%rax)
    1bb4:      	movl	$0x3, %ebp
    1bb9:      	jmp	0x2477 <kprobe_unwind_perl+0x2477>
    1bbe:      	movl	0x5c(%rsp), %eax
    1bc2:      	andl	$0x1f, %eax
    1bc5:      	cmpl	$0xd, %eax
    1bc8:      	jne	0x2338 <kprobe_unwind_perl+0x2338>
    1bce:      	movzbl	0x1f(%r14), %eax
    1bd3:      	addq	%rbp, %rax
    1bd6:      	leaq	0x50(%rsp), %rdi
    1bdb:      	movl	$0x8, %ecx
    1be0:      	movl	$0x70, %r8d
    1be6:      	movzbl	0x1f(%r14), %edx
    1beb:      	addq	%rbp, %rdx
    1bee:      	movl	$0x8, %esi
    1bf3:      	callq	*%r8
    1bf6:      	testq	%rax, %rax
    1bf9:      	jne	0xd3e <kprobe_unwind_perl+0xd3e>
    1bff:      	movzbl	0x21(%r14), %eax
    1c04:      	addq	0x50(%rsp), %rax
    1c09:      	leaq	0x70(%rsp), %rdi
    1c0e:      	movl	$0x4, %ecx
    1c13:      	movl	$0x70, %r8d
    1c19:      	movzbl	0x21(%r14), %edx
    1c1e:      	addq	0x50(%rsp), %rdx
    1c23:      	movl	$0x4, %esi
    1c28:      	callq	*%r8
    1c2b:      	testq	%rax, %rax
    1c2e:      	jne	0xd3e <kprobe_unwind_perl+0xd3e>
    1c34:      	testb	$-0x80, 0x71(%rsp)
    1c39:      	jne	0x36e1 <kprobe_unwind_perl+0x36e1>
    1c3f:      	movzbl	0x22(%r14), %eax
    1c44:      	addq	0x50(%rsp), %rax
    1c49:      	leaq	0x60(%rsp), %rbp
    1c4e:      	movl	$0x8, %ecx
    1c53:      	movl	$0x70, %r8d
    1c59:      	movzbl	0x22(%r14), %edx
    1c5e:      	addq	0x50(%rsp), %rdx
    1c63:      	movq	%rbp, %rdi
    1c66:      	movl	$0x8, %esi
    1c6b:      	callq	*%r8
    1c6e:      	testq	%rax, %rax
    1c71:      	jne	0xd3e <kprobe_unwind_perl+0xd3e>
    1c77:      	movq	0x60(%rsp), %rax
    1c7c:      	testq	%rax, %rax
    1c7f:      	je	0xd3e <kprobe_unwind_perl+0xd3e>
    1c85:      	movq	(%rip), %rcx            # 0x1c8c <kprobe_unwind_perl+0x1c8c>
    1c8c:      	cmpl	$0x0, (%rcx)
    1c8f:      	jne	0x75d6 <kprobe_unwind_perl+0x75d6>
    1c95:      	movzbl	0x1e(%r14), %ecx
    1c9a:      	addq	%rax, %rcx
    1c9d:      	leaq	0x6c(%rsp), %rdi
    1ca2:      	movl	$0x4, %eax
    1ca7:      	movl	$0x70, %r8d
    1cad:      	movzbl	0x1e(%r14), %edx
    1cb2:      	addq	0x60(%rsp), %rdx
    1cb7:      	movl	$0x4, %esi
    1cbc:      	callq	*%r8
    1cbf:      	testq	%rax, %rax
    1cc2:      	jne	0xd3e <kprobe_unwind_perl+0xd3e>
    1cc8:      	movl	$0x801f, %eax           # imm = 0x801F
    1ccd:      	andl	0x6c(%rsp), %eax
    1cd1:      	cmpl	$0x8009, %eax           # imm = 0x8009
    1cd6:      	jne	0x492d <kprobe_unwind_perl+0x492d>
    1cdc:      	movzbl	0x20(%r14), %eax
    1ce1:      	addq	0x60(%rsp), %rax
    1ce6:      	leaq	0x88(%rsp), %rdi
    1cee:      	movl	$0x8, %ecx
    1cf3:      	movl	$0x70, %r8d
    1cf9:      	movzbl	0x20(%r14), %edx
    1cfe:      	addq	0x60(%rsp), %rdx
    1d03:      	movl	$0x8, %esi
    1d08:      	callq	*%r8
    1d0b:      	testq	%rax, %rax
    1d0e:      	jne	0xd3e <kprobe_unwind_perl+0xd3e>
    1d14:      	movzbl	0x23(%r14), %eax
    1d19:      	addq	0x88(%rsp), %rax
    1d21:      	leaq	0x78(%rsp), %rdi
    1d26:      	movl	$0x8, %ecx
    1d2b:      	movl	$0x70, %r8d
    1d31:      	movzbl	0x23(%r14), %edx
    1d36:      	addq	0x88(%rsp), %rdx
    1d3e:      	movl	$0x8, %esi
    1d43:      	callq	*%r8
    1d46:      	testq	%rax, %rax
    1d49:      	jne	0xd3e <kprobe_unwind_perl+0xd3e>
    1d4f:      	movq	0x78(%rsp), %rax
    1d54:      	movq	%rax, 0x80(%rsp)
    1d5c:      	testq	%rax, %rax
    1d5f:      	je	0x1db5 <kprobe_unwind_perl+0x1db5>
    1d61:      	movq	(%rip), %rax            # 0x1d68 <kprobe_unwind_perl+0x1d68>
    1d68:      	cmpl	$0x0, (%rax)
    1d6b:      	je	0x1dca <kprobe_unwind_perl+0x1dca>
    1d6d:      	movabsq	$0x2578302074612056, %rax # imm = 0x2578302074612056
    1d77:      	movq	%rax, 0x18(%rsp)
    1d7c:      	movabsq	$0x474520646e756f46, %rax # imm = 0x474520646E756F46
    1d86:      	movq	%rax, 0x10(%rsp)
    1d8b:      	movl	$0xa786c, 0x20(%rsp)    # imm = 0xA786C
    1d93:      	leaq	0x10(%rsp), %rdi
    1d98:      	movl	$0x14, %eax
    1d9d:      	movl	$0x6, %ecx
    1da2:      	movq	0x78(%rsp), %rdx
    1da7:      	movl	$0x14, %esi
    1dac:      	xorl	%eax, %eax
    1dae:      	callq	*%rcx
    1db0:      	leaq	0x78(%rsp), %rbp
    1db5:      	movq	(%rbp), %rax
    1db9:      	movq	%rax, 0x80(%rsp)
    1dc1:      	testq	%rax, %rax
    1dc4:      	je	0xb68 <kprobe_unwind_perl+0xb68>
    1dca:      	movq	(%r12), %rax
    1dce:      	movq	%rax, 0x90(%rsp)
    1dd6:      	movq	(%rip), %rax            # 0x1ddd <kprobe_unwind_perl+0x1ddd>
    1ddd:      	cmpl	$0x0, (%rax)
    1de0:      	jne	0x8753 <kprobe_unwind_perl+0x8753>
    1de6:      	movl	0x2c0(%r15), %eax
    1ded:      	cmpq	$0x7e, %rax
    1df1:      	ja	0x1193 <kprobe_unwind_perl+0x1193>
    1df7:      	xorl	%ecx, %ecx
    1df9:      	movzbl	0xf(%rsp), %edx
    1dfe:      	movb	%dl, %cl
    1e00:      	leal	0x1(,%rcx,2), %ebp
    1e07:      	leal	0x1(%rax), %ecx
    1e0a:      	movl	%ecx, 0x2c0(%r15)
    1e11:      	leaq	(%rax,%rax,2), %rax
    1e15:      	movq	0x80(%rsp), %rcx
    1e1d:      	movq	%rcx, 0x2d0(%r15,%rax,8)
    1e25:      	movq	0x90(%rsp), %rcx
    1e2d:      	movq	%rcx, 0x2d8(%r15,%rax,8)
    1e35:      	movb	$0x7, 0x2e0(%r15,%rax,8)
    1e3e:      	movl	$0x0, 0x2e1(%r15,%rax,8)
    1e4a:      	movl	$0x0, 0x2e4(%r15,%rax,8)
    1e56:      	movq	$0x0, 0xf40(%r15)
    1e61:      	movzbl	0x1a(%r14), %eax
    1e66:      	addq	%r13, %rax
    1e69:      	movl	$0x8, %ecx
    1e6e:      	movl	$0x70, %r8d
    1e74:      	movzbl	0x1a(%r14), %edx
    1e79:      	addq	%r13, %rdx
    1e7c:      	movq	%r12, %rdi
    1e7f:      	movl	$0x8, %esi
    1e84:      	callq	*%r8
    1e87:      	testq	%rax, %rax
    1e8a:      	jne	0xb68 <kprobe_unwind_perl+0xb68>
    1e90:      	movq	(%rip), %rax            # 0x1e97 <kprobe_unwind_perl+0x1e97>
    1e97:      	cmpl	$0x0, (%rax)
    1e9a:      	je	0xe2c <kprobe_unwind_perl+0xe2c>
    1ea0:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    1eaa:      	movq	%rax, 0x26(%rsp)
    1eaf:      	movabsq	$0x30206b6361747320, %rax # imm = 0x30206B6361747320
    1eb9:      	movq	%rax, 0x20(%rsp)
    1ebe:      	movabsq	$0x747865746e6f6320, %rax # imm = 0x747865746E6F6320
    1ec8:      	movq	%rax, 0x18(%rsp)
    1ecd:      	movabsq	$0x6d6f726620504f43, %rax # imm = 0x6D6F726620504F43
    1ed7:      	movq	%rax, 0x10(%rsp)
    1edc:      	leaq	0x10(%rsp), %rdi
    1ee1:      	movl	$0x1e, %eax
    1ee6:      	movl	$0x6, %ecx
    1eeb:      	movq	(%r12), %rdx
    1eef:      	movl	$0x1e, %esi
    1ef4:      	xorl	%eax, %eax
    1ef6:      	callq	*%rcx
    1ef8:      	jmp	0xe2c <kprobe_unwind_perl+0xe2c>
    1efd:      	movabsq	$0x7025207461207972, %rax # imm = 0x7025207461207972
    1f07:      	movq	%rax, 0x30(%rsp)
    1f0c:      	movabsq	$0x746e65206b636174, %rax # imm = 0x746E65206B636174
    1f16:      	movq	%rax, 0x28(%rsp)
    1f1b:      	movabsq	$0x7320747865746e6f, %rax # imm = 0x7320747865746E6F
    1f25:      	movq	%rax, 0x20(%rsp)
    1f2a:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    1f34:      	movq	%rax, 0x18(%rsp)
    1f39:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1f43:      	movq	%rax, 0x10(%rsp)
    1f48:      	movw	$0xa, 0x38(%rsp)
    1f4f:      	leaq	0x10(%rsp), %rdi
    1f54:      	movl	$0x2a, %eax
    1f59:      	movl	$0x6, %ecx
    1f5e:      	movl	$0x2a, %esi
    1f63:      	movq	%r13, %rdx
    1f66:      	xorl	%eax, %eax
    1f68:      	callq	*%rcx
    1f6a:      	jmp	0x28c <kprobe_unwind_perl+0x28c>
    1f6f:      	movq	(%rip), %rax            # 0x1f76 <kprobe_unwind_perl+0x1f76>
    1f76:      	cmpl	$0x0, (%rax)
    1f79:      	jne	0x54e3 <kprobe_unwind_perl+0x54e3>
    1f7f:      	movzbl	0xe(%rsp), %eax
    1f84:      	movl	%eax, %ecx
    1f86:      	andl	$0xf, %ecx
    1f89:      	movl	$0x3, %ebp
    1f8e:      	leal	-0x9(%rcx), %edx
    1f91:      	cmpl	$0x2, %edx
    1f94:      	jae	0x2467 <kprobe_unwind_perl+0x2467>
    1f9a:      	testb	%al, %al
    1f9c:      	js	0x2477 <kprobe_unwind_perl+0x2477>
    1fa2:      	movzbl	0x1b(%r14), %eax
    1fa7:      	addq	%r13, %rax
    1faa:      	leaq	0x10(%rsp), %rdi
    1faf:      	movl	$0x8, %ecx
    1fb4:      	movl	$0x70, %r8d
    1fba:      	movzbl	0x1b(%r14), %edx
    1fbf:      	addq	%r13, %rdx
    1fc2:      	movl	$0x8, %esi
    1fc7:      	callq	*%r8
    1fca:      	testq	%rax, %rax
    1fcd:      	jne	0x1b7d <kprobe_unwind_perl+0x1b7d>
    1fd3:      	cmpq	$0x0, 0x10(%rsp)
    1fd9:      	setne	0xf(%rsp)
    1fde:      	movzbl	0x1c(%r14), %eax
    1fe3:      	addq	%r13, %rax
    1fe6:      	leaq	0xa0(%rsp), %rdi
    1fee:      	movl	$0x8, %ecx
    1ff3:      	movl	$0x70, %r8d
    1ff9:      	movzbl	0x1c(%r14), %edx
    1ffe:      	addq	%r13, %rdx
    2001:      	movl	$0x8, %esi
    2006:      	callq	*%r8
    2009:      	testq	%rax, %rax
    200c:      	jne	0x1b7d <kprobe_unwind_perl+0x1b7d>
    2012:      	movq	0xa0(%rsp), %rbp
    201a:      	movzbl	0x1e(%r14), %eax
    201f:      	addq	%rbp, %rax
    2022:      	leaq	0x5c(%rsp), %rdi
    2027:      	movl	$0x4, %ecx
    202c:      	movl	$0x70, %r8d
    2032:      	movzbl	0x1e(%r14), %edx
    2037:      	addq	%rbp, %rdx
    203a:      	movl	$0x4, %esi
    203f:      	callq	*%r8
    2042:      	testq	%rax, %rax
    2045:      	je	0x3a78 <kprobe_unwind_perl+0x3a78>
    204b:      	movq	(%rip), %rax            # 0x2052 <kprobe_unwind_perl+0x2052>
    2052:      	cmpl	$0x0, (%rax)
    2055:      	jne	0x70af <kprobe_unwind_perl+0x70af>
    205b:      	movl	$0x14, 0x74(%rsp)
    2063:      	movq	(%rip), %rdi            # 0x206a <kprobe_unwind_perl+0x206a>
    206a:      	leaq	0x74(%rsp), %rsi
    206f:      	movl	$0x1, %eax
    2074:      	callq	*%rax
    2076:      	testq	%rax, %rax
    2079:      	je	0x3fb9 <kprobe_unwind_perl+0x3fb9>
    207f:      	incq	(%rax)
    2082:      	jmp	0x1b7d <kprobe_unwind_perl+0x1b7d>
    2087:      	movq	(%rip), %rax            # 0x208e <kprobe_unwind_perl+0x208e>
    208e:      	cmpl	$0x0, (%rax)
    2091:      	je	0xb68 <kprobe_unwind_perl+0xb68>
    2097:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    20a1:      	movq	%rax, 0x36(%rsp)
    20a6:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    20b0:      	movq	%rax, 0x30(%rsp)
    20b5:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    20bf:      	movq	%rax, 0x28(%rsp)
    20c4:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    20ce:      	movq	%rax, 0x20(%rsp)
    20d3:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    20dd:      	movq	%rax, 0x18(%rsp)
    20e2:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    20ec:      	movq	%rax, 0x10(%rsp)
    20f1:      	leaq	0x10(%rsp), %rdi
    20f6:      	movl	$0x2e, %eax
    20fb:      	movl	$0x6, %ecx
    2100:      	movl	0x74(%rsp), %edx
    2104:      	movl	$0x2e, %esi
    2109:      	jmp	0x239c <kprobe_unwind_perl+0x239c>
    210e:      	movq	(%rip), %rax            # 0x2115 <kprobe_unwind_perl+0x2115>
    2115:      	cmpl	$0x0, (%rax)
    2118:      	jne	0x5ed1 <kprobe_unwind_perl+0x5ed1>
    211e:      	movl	$0x3, %ebp
    2123:      	jmp	0x2477 <kprobe_unwind_perl+0x2477>
    2128:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    2132:      	movq	%rax, 0x1f(%rsp)
    2137:      	movabsq	$0x2072657465727072, %rax # imm = 0x2072657465727072
    2141:      	movq	%rax, 0x18(%rsp)
    2146:      	movabsq	$0x65746e496c726550, %rax # imm = 0x65746E496C726550
    2150:      	movq	%rax, 0x10(%rsp)
    2155:      	leaq	0x10(%rsp), %rdi
    215a:      	movl	$0x17, %eax
    215f:      	movl	$0x6, %ecx
    2164:      	movq	0x60(%rsp), %rdx
    2169:      	movl	$0x17, %esi
    216e:      	xorl	%eax, %eax
    2170:      	callq	*%rcx
    2172:      	jmp	0x196 <kprobe_unwind_perl+0x196>
    2177:      	movabsq	$0xa65756c617620, %rax  # imm = 0xA65756C617620
    2181:      	movq	%rax, 0x25(%rsp)
    2186:      	movabsq	$0x6176206573616270, %rax # imm = 0x6176206573616270
    2190:      	movq	%rax, 0x20(%rsp)
    2195:      	movabsq	$0x742064616572206f, %rax # imm = 0x742064616572206F
    219f:      	movq	%rax, 0x18(%rsp)
    21a4:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    21ae:      	movq	%rax, 0x10(%rsp)
    21b3:      	leaq	0x10(%rsp), %rdi
    21b8:      	movl	$0x1d, %eax
    21bd:      	movl	$0x6, %ecx
    21c2:      	movl	$0x1d, %esi
    21c7:      	xorl	%eax, %eax
    21c9:      	callq	*%rcx
    21cb:      	jmp	0x311 <kprobe_unwind_perl+0x311>
    21d0:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    21da:      	movq	%rax, 0x36(%rsp)
    21df:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    21e9:      	movq	%rax, 0x30(%rsp)
    21ee:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    21f8:      	movq	%rax, 0x28(%rsp)
    21fd:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2207:      	movq	%rax, 0x20(%rsp)
    220c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2216:      	movq	%rax, 0x18(%rsp)
    221b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2225:      	movq	%rax, 0x10(%rsp)
    222a:      	leaq	0x10(%rsp), %rdi
    222f:      	movl	$0x2e, %eax
    2234:      	movl	$0x6, %ecx
    2239:      	movl	0x50(%rsp), %edx
    223d:      	movl	$0x2e, %esi
    2242:      	xorl	%eax, %eax
    2244:      	callq	*%rcx
    2246:      	cmpb	$0x0, 0x14(%r14)
    224b:      	jne	0x2ce <kprobe_unwind_perl+0x2ce>
    2251:      	jmp	0x180 <kprobe_unwind_perl+0x180>
    2256:      	movq	(%rip), %rax            # 0x225d <kprobe_unwind_perl+0x225d>
    225d:      	cmpl	$0x0, (%rax)
    2260:      	je	0x27c <kprobe_unwind_perl+0x27c>
    2266:      	movabsq	$0xa782578302f78, %rax  # imm = 0xA782578302F78
    2270:      	movq	%rax, 0x2e(%rsp)
    2275:      	movabsq	$0x2f78257830207367, %rax # imm = 0x2F78257830207367
    227f:      	movq	%rax, 0x28(%rsp)
    2284:      	movabsq	$0x616c66202c564320, %rax # imm = 0x616C66202C564320
    228e:      	movq	%rax, 0x20(%rsp)
    2293:      	movabsq	$0x44454d414e206465, %rax # imm = 0x44454D414E206465
    229d:      	movq	%rax, 0x18(%rsp)
    22a2:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    22ac:      	movq	%rax, 0x10(%rsp)
    22b1:      	leaq	0x10(%rsp), %rdi
    22b6:      	movl	$0x26, %eax
    22bb:      	movl	$0x6, %r8d
    22c1:      	movl	0x5c(%rsp), %edx
    22c5:      	movl	0x70(%rsp), %ecx
    22c9:      	movl	$0x26, %esi
    22ce:      	xorl	%eax, %eax
    22d0:      	callq	*%r8
    22d3:      	jmp	0x27c <kprobe_unwind_perl+0x27c>
    22d8:      	movabsq	$0x6574617473207265, %rax # imm = 0x6574617473207265
    22e2:      	movq	%rax, 0x28(%rsp)
    22e7:      	movabsq	$0x746572707265746e, %rax # imm = 0x746572707265746E
    22f1:      	movq	%rax, 0x20(%rsp)
    22f6:      	movabsq	$0x692064616572206f, %rax # imm = 0x692064616572206F
    2300:      	movq	%rax, 0x18(%rsp)
    2305:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    230f:      	movq	%rax, 0x10(%rsp)
    2314:      	movw	$0xa, 0x30(%rsp)
    231b:      	leaq	0x10(%rsp), %rdi
    2320:      	movl	$0x22, %eax
    2325:      	movl	$0x6, %ecx
    232a:      	movl	$0x22, %esi
    232f:      	xorl	%eax, %eax
    2331:      	callq	*%rcx
    2333:      	jmp	0x212 <kprobe_unwind_perl+0x212>
    2338:      	movq	(%rip), %rax            # 0x233f <kprobe_unwind_perl+0x233f>
    233f:      	cmpl	$0x0, (%rax)
    2342:      	je	0xb68 <kprobe_unwind_perl+0xb68>
    2348:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    2352:      	movq	%rax, 0x26(%rsp)
    2357:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    2361:      	movq	%rax, 0x20(%rsp)
    2366:      	movabsq	$0x5643565020612074, %rax # imm = 0x5643565020612074
    2370:      	movq	%rax, 0x18(%rsp)
    2375:      	movabsq	$0x6f6e207369205643, %rax # imm = 0x6F6E207369205643
    237f:      	movq	%rax, 0x10(%rsp)
    2384:      	leaq	0x10(%rsp), %rdi
    2389:      	movl	$0x1e, %eax
    238e:      	movl	$0x6, %ecx
    2393:      	movl	0x5c(%rsp), %edx
    2397:      	movl	$0x1e, %esi
    239c:      	xorl	%eax, %eax
    239e:      	callq	*%rcx
    23a0:      	jmp	0xb68 <kprobe_unwind_perl+0xb68>
    23a5:      	movabsq	$0x7825783020786320, %rax # imm = 0x7825783020786320
    23af:      	movq	%rax, 0x18(%rsp)
    23b4:      	movabsq	$0x6c72657020746f47, %rax # imm = 0x6C72657020746F47
    23be:      	movq	%rax, 0x10(%rsp)
    23c3:      	movw	$0xa, 0x20(%rsp)
    23ca:      	leaq	0x10(%rsp), %rdi
    23cf:      	movl	$0x12, %eax
    23d4:      	movl	$0x6, %ecx
    23d9:      	movzbl	0xe(%rsp), %edx
    23de:      	movl	$0x12, %esi
    23e3:      	xorl	%eax, %eax
    23e5:      	callq	*%rcx
    23e7:      	jmp	0x3ac <kprobe_unwind_perl+0x3ac>
    23ec:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    23f6:      	movq	%rax, 0x36(%rsp)
    23fb:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2405:      	movq	%rax, 0x30(%rsp)
    240a:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2414:      	movq	%rax, 0x28(%rsp)
    2419:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2423:      	movq	%rax, 0x20(%rsp)
    2428:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2432:      	movq	%rax, 0x18(%rsp)
    2437:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2441:      	movq	%rax, 0x10(%rsp)
    2446:      	leaq	0x10(%rsp), %rdi
    244b:      	movl	$0x2e, %eax
    2450:      	movl	$0x6, %ecx
    2455:      	movl	0x50(%rsp), %edx
    2459:      	movl	$0x2e, %esi
    245e:      	xorl	%eax, %eax
    2460:      	callq	*%rcx
    2462:      	jmp	0x4fc <kprobe_unwind_perl+0x4fc>
    2467:      	cmpl	$0xc, %ecx
    246a:      	je	0x2477 <kprobe_unwind_perl+0x2477>
    246c:      	cmpq	$0x0, (%r12)
    2471:      	je	0x3d1b <kprobe_unwind_perl+0x3d1b>
    2477:      	movzbl	0x1d(%r14), %eax
    247c:      	subq	%rax, 0xf50(%r15)
    2483:      	movl	$0x10, 0x50(%rsp)
    248b:      	movq	(%rip), %rdi            # 0x2492 <kprobe_unwind_perl+0x2492>
    2492:      	leaq	0x50(%rsp), %rsi
    2497:      	movl	$0x1, %eax
    249c:      	callq	*%rax
    249e:      	testq	%rax, %rax
    24a1:      	je	0x24b8 <kprobe_unwind_perl+0x24b8>
    24a3:      	incq	(%rax)
    24a6:      	cmpl	$0x3, %ebp
    24a9:      	movq	0x98(%rsp), %rcx
    24b1:      	je	0x24d9 <kprobe_unwind_perl+0x24d9>
    24b3:      	jmp	0x5636 <kprobe_unwind_perl+0x5636>
    24b8:      	movq	(%rip), %rax            # 0x24bf <kprobe_unwind_perl+0x24bf>
    24bf:      	cmpl	$0x0, (%rax)
    24c2:      	jne	0x552a <kprobe_unwind_perl+0x552a>
    24c8:      	cmpl	$0x3, %ebp
    24cb:      	movq	0x98(%rsp), %rcx
    24d3:      	jne	0x5636 <kprobe_unwind_perl+0x5636>
    24d9:      	movq	0xf50(%r15), %r13
    24e0:      	cmpq	%rcx, %r13
    24e3:      	jae	0x24f7 <kprobe_unwind_perl+0x24f7>
    24e5:      	movl	$0x3, %ebp
    24ea:      	movq	0x98(%rsp), %rcx
    24f2:      	jmp	0x5636 <kprobe_unwind_perl+0x5636>
    24f7:      	movzbl	0x19(%r14), %eax
    24fc:      	addq	%r13, %rax
    24ff:      	leaq	0xe(%rsp), %rdi
    2504:      	movl	$0x1, %ecx
    2509:      	movl	$0x70, %r8d
    250f:      	movzbl	0x19(%r14), %edx
    2514:      	addq	%r13, %rdx
    2517:      	movl	$0x1, %esi
    251c:      	callq	*%r8
    251f:      	testq	%rax, %rax
    2522:      	je	0x2a15 <kprobe_unwind_perl+0x2a15>
    2528:      	movq	(%rip), %rax            # 0x252f <kprobe_unwind_perl+0x252f>
    252f:      	cmpl	$0x0, (%rax)
    2532:      	jne	0x6302 <kprobe_unwind_perl+0x6302>
    2538:      	movl	$0x13, 0x50(%rsp)
    2540:      	movq	(%rip), %rdi            # 0x2547 <kprobe_unwind_perl+0x2547>
    2547:      	leaq	0x50(%rsp), %rsi
    254c:      	movl	$0x1, %eax
    2551:      	callq	*%rax
    2553:      	testq	%rax, %rax
    2556:      	je	0x2bb4 <kprobe_unwind_perl+0x2bb4>
    255c:      	incq	(%rax)
    255f:      	movl	$0x3, %ebp
    2564:      	jmp	0x2d8f <kprobe_unwind_perl+0x2d8f>
    2569:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2573:      	movq	%rax, 0x36(%rsp)
    2578:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2582:      	movq	%rax, 0x30(%rsp)
    2587:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2591:      	movq	%rax, 0x28(%rsp)
    2596:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    25a0:      	movq	%rax, 0x20(%rsp)
    25a5:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    25af:      	movq	%rax, 0x18(%rsp)
    25b4:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    25be:      	movq	%rax, 0x10(%rsp)
    25c3:      	leaq	0x10(%rsp), %rdi
    25c8:      	movl	$0x2e, %eax
    25cd:      	movl	$0x6, %ecx
    25d2:      	movl	0x50(%rsp), %edx
    25d6:      	movl	$0x2e, %esi
    25db:      	xorl	%eax, %eax
    25dd:      	callq	*%rcx
    25df:      	jmp	0x4c8 <kprobe_unwind_perl+0x4c8>
    25e4:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    25ee:      	movq	%rax, 0x36(%rsp)
    25f3:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    25fd:      	movq	%rax, 0x30(%rsp)
    2602:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    260c:      	movq	%rax, 0x28(%rsp)
    2611:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    261b:      	movq	%rax, 0x20(%rsp)
    2620:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    262a:      	movq	%rax, 0x18(%rsp)
    262f:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2639:      	movq	%rax, 0x10(%rsp)
    263e:      	leaq	0x10(%rsp), %rdi
    2643:      	movl	$0x2e, %eax
    2648:      	movl	$0x6, %ecx
    264d:      	movl	0x50(%rsp), %edx
    2651:      	movl	$0x2e, %esi
    2656:      	xorl	%eax, %eax
    2658:      	callq	*%rcx
    265a:      	movl	$0x1, %ebp
    265f:      	jmp	0x586a <kprobe_unwind_perl+0x586a>
    2664:      	movl	0x5c(%rsp), %eax
    2668:      	andl	$0x1f, %eax
    266b:      	cmpl	$0xd, %eax
    266e:      	jne	0x2c50 <kprobe_unwind_perl+0x2c50>
    2674:      	movzbl	0x1f(%r14), %eax
    2679:      	addq	%rbp, %rax
    267c:      	leaq	0x50(%rsp), %rdi
    2681:      	movl	$0x8, %ecx
    2686:      	movl	$0x70, %r8d
    268c:      	movzbl	0x1f(%r14), %edx
    2691:      	addq	%rbp, %rdx
    2694:      	movl	$0x8, %esi
    2699:      	callq	*%r8
    269c:      	testq	%rax, %rax
    269f:      	jne	0x12ab <kprobe_unwind_perl+0x12ab>
    26a5:      	movzbl	0x21(%r14), %eax
    26aa:      	addq	0x50(%rsp), %rax
    26af:      	leaq	0x70(%rsp), %rdi
    26b4:      	movl	$0x4, %ecx
    26b9:      	movl	$0x70, %r8d
    26bf:      	movzbl	0x21(%r14), %edx
    26c4:      	addq	0x50(%rsp), %rdx
    26c9:      	movl	$0x4, %esi
    26ce:      	callq	*%r8
    26d1:      	testq	%rax, %rax
    26d4:      	jne	0x12ab <kprobe_unwind_perl+0x12ab>
    26da:      	testb	$-0x80, 0x71(%rsp)
    26df:      	jne	0x40cd <kprobe_unwind_perl+0x40cd>
    26e5:      	movzbl	0x22(%r14), %eax
    26ea:      	addq	0x50(%rsp), %rax
    26ef:      	leaq	0x60(%rsp), %rbp
    26f4:      	movl	$0x8, %ecx
    26f9:      	movl	$0x70, %r8d
    26ff:      	movzbl	0x22(%r14), %edx
    2704:      	addq	0x50(%rsp), %rdx
    2709:      	movq	%rbp, %rdi
    270c:      	movl	$0x8, %esi
    2711:      	callq	*%r8
    2714:      	testq	%rax, %rax
    2717:      	jne	0x12ab <kprobe_unwind_perl+0x12ab>
    271d:      	movq	0x60(%rsp), %rax
    2722:      	testq	%rax, %rax
    2725:      	je	0x12ab <kprobe_unwind_perl+0x12ab>
    272b:      	movq	(%rip), %rcx            # 0x2732 <kprobe_unwind_perl+0x2732>
    2732:      	cmpl	$0x0, (%rcx)
    2735:      	jne	0x7e7c <kprobe_unwind_perl+0x7e7c>
    273b:      	movzbl	0x1e(%r14), %ecx
    2740:      	addq	%rax, %rcx
    2743:      	leaq	0x6c(%rsp), %rdi
    2748:      	movl	$0x4, %eax
    274d:      	movl	$0x70, %r8d
    2753:      	movzbl	0x1e(%r14), %edx
    2758:      	addq	0x60(%rsp), %rdx
    275d:      	movl	$0x4, %esi
    2762:      	callq	*%r8
    2765:      	testq	%rax, %rax
    2768:      	jne	0x12ab <kprobe_unwind_perl+0x12ab>
    276e:      	movl	$0x801f, %eax           # imm = 0x801F
    2773:      	andl	0x6c(%rsp), %eax
    2777:      	cmpl	$0x8009, %eax           # imm = 0x8009
    277c:      	jne	0x52db <kprobe_unwind_perl+0x52db>
    2782:      	movzbl	0x20(%r14), %eax
    2787:      	addq	0x60(%rsp), %rax
    278c:      	leaq	0x88(%rsp), %rdi
    2794:      	movl	$0x8, %ecx
    2799:      	movl	$0x70, %r8d
    279f:      	movzbl	0x20(%r14), %edx
    27a4:      	addq	0x60(%rsp), %rdx
    27a9:      	movl	$0x8, %esi
    27ae:      	callq	*%r8
    27b1:      	testq	%rax, %rax
    27b4:      	jne	0x12ab <kprobe_unwind_perl+0x12ab>
    27ba:      	movzbl	0x23(%r14), %eax
    27bf:      	addq	0x88(%rsp), %rax
    27c7:      	leaq	0x78(%rsp), %rdi
    27cc:      	movl	$0x8, %ecx
    27d1:      	movl	$0x70, %r8d
    27d7:      	movzbl	0x23(%r14), %edx
    27dc:      	addq	0x88(%rsp), %rdx
    27e4:      	movl	$0x8, %esi
    27e9:      	callq	*%r8
    27ec:      	testq	%rax, %rax
    27ef:      	jne	0x12ab <kprobe_unwind_perl+0x12ab>
    27f5:      	movq	0x78(%rsp), %rax
    27fa:      	movq	%rax, 0x80(%rsp)
    2802:      	testq	%rax, %rax
    2805:      	je	0x285b <kprobe_unwind_perl+0x285b>
    2807:      	movq	(%rip), %rax            # 0x280e <kprobe_unwind_perl+0x280e>
    280e:      	cmpl	$0x0, (%rax)
    2811:      	je	0x2870 <kprobe_unwind_perl+0x2870>
    2813:      	movabsq	$0x2578302074612056, %rax # imm = 0x2578302074612056
    281d:      	movq	%rax, 0x18(%rsp)
    2822:      	movabsq	$0x474520646e756f46, %rax # imm = 0x474520646E756F46
    282c:      	movq	%rax, 0x10(%rsp)
    2831:      	movl	$0xa786c, 0x20(%rsp)    # imm = 0xA786C
    2839:      	leaq	0x10(%rsp), %rdi
    283e:      	movl	$0x14, %eax
    2843:      	movl	$0x6, %ecx
    2848:      	movq	0x78(%rsp), %rdx
    284d:      	movl	$0x14, %esi
    2852:      	xorl	%eax, %eax
    2854:      	callq	*%rcx
    2856:      	leaq	0x78(%rsp), %rbp
    285b:      	movq	(%rbp), %rax
    285f:      	movq	%rax, 0x80(%rsp)
    2867:      	testq	%rax, %rax
    286a:      	je	0xec7 <kprobe_unwind_perl+0xec7>
    2870:      	movq	(%r12), %rax
    2874:      	movq	%rax, 0x90(%rsp)
    287c:      	movq	(%rip), %rax            # 0x2883 <kprobe_unwind_perl+0x2883>
    2883:      	cmpl	$0x0, (%rax)
    2886:      	jne	0x8a5e <kprobe_unwind_perl+0x8a5e>
    288c:      	movl	0x2c0(%r15), %eax
    2893:      	cmpq	$0x7e, %rax
    2897:      	ja	0x1193 <kprobe_unwind_perl+0x1193>
    289d:      	xorl	%ecx, %ecx
    289f:      	movzbl	0xf(%rsp), %edx
    28a4:      	movb	%dl, %cl
    28a6:      	leal	0x1(,%rcx,2), %ebp
    28ad:      	leal	0x1(%rax), %ecx
    28b0:      	movl	%ecx, 0x2c0(%r15)
    28b7:      	leaq	(%rax,%rax,2), %rax
    28bb:      	movq	0x80(%rsp), %rcx
    28c3:      	movq	%rcx, 0x2d0(%r15,%rax,8)
    28cb:      	movq	0x90(%rsp), %rcx
    28d3:      	movq	%rcx, 0x2d8(%r15,%rax,8)
    28db:      	movb	$0x7, 0x2e0(%r15,%rax,8)
    28e4:      	movl	$0x0, 0x2e1(%r15,%rax,8)
    28f0:      	movl	$0x0, 0x2e4(%r15,%rax,8)
    28fc:      	movq	$0x0, 0xf40(%r15)
    2907:      	movzbl	0x1a(%r14), %eax
    290c:      	addq	%r13, %rax
    290f:      	movl	$0x8, %ecx
    2914:      	movl	$0x70, %r8d
    291a:      	movzbl	0x1a(%r14), %edx
    291f:      	addq	%r13, %rdx
    2922:      	movq	%r12, %rdi
    2925:      	movl	$0x8, %esi
    292a:      	callq	*%r8
    292d:      	testq	%rax, %rax
    2930:      	jne	0xec7 <kprobe_unwind_perl+0xec7>
    2936:      	movq	(%rip), %rax            # 0x293d <kprobe_unwind_perl+0x293d>
    293d:      	cmpl	$0x0, (%rax)
    2940:      	je	0x13ff <kprobe_unwind_perl+0x13ff>
    2946:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    2950:      	movq	%rax, 0x26(%rsp)
    2955:      	movabsq	$0x30206b6361747320, %rax # imm = 0x30206B6361747320
    295f:      	movq	%rax, 0x20(%rsp)
    2964:      	movabsq	$0x747865746e6f6320, %rax # imm = 0x747865746E6F6320
    296e:      	movq	%rax, 0x18(%rsp)
    2973:      	movabsq	$0x6d6f726620504f43, %rax # imm = 0x6D6F726620504F43
    297d:      	movq	%rax, 0x10(%rsp)
    2982:      	leaq	0x10(%rsp), %rdi
    2987:      	movl	$0x1e, %eax
    298c:      	movl	$0x6, %ecx
    2991:      	movq	(%r12), %rdx
    2995:      	movl	$0x1e, %esi
    299a:      	xorl	%eax, %eax
    299c:      	callq	*%rcx
    299e:      	jmp	0x13ff <kprobe_unwind_perl+0x13ff>
    29a3:      	movabsq	$0x7025207461207972, %rax # imm = 0x7025207461207972
    29ad:      	movq	%rax, 0x30(%rsp)
    29b2:      	movabsq	$0x746e65206b636174, %rax # imm = 0x746E65206B636174
    29bc:      	movq	%rax, 0x28(%rsp)
    29c1:      	movabsq	$0x7320747865746e6f, %rax # imm = 0x7320747865746E6F
    29cb:      	movq	%rax, 0x20(%rsp)
    29d0:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    29da:      	movq	%rax, 0x18(%rsp)
    29df:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    29e9:      	movq	%rax, 0x10(%rsp)
    29ee:      	movw	$0xa, 0x38(%rsp)
    29f5:      	leaq	0x10(%rsp), %rdi
    29fa:      	movl	$0x2a, %eax
    29ff:      	movl	$0x6, %ecx
    2a04:      	movl	$0x2a, %esi
    2a09:      	movq	%r13, %rdx
    2a0c:      	xorl	%eax, %eax
    2a0e:      	callq	*%rcx
    2a10:      	jmp	0x578 <kprobe_unwind_perl+0x578>
    2a15:      	movq	(%rip), %rax            # 0x2a1c <kprobe_unwind_perl+0x2a1c>
    2a1c:      	cmpl	$0x0, (%rax)
    2a1f:      	jne	0x66e1 <kprobe_unwind_perl+0x66e1>
    2a25:      	movzbl	0xe(%rsp), %eax
    2a2a:      	movl	%eax, %ecx
    2a2c:      	andl	$0xf, %ecx
    2a2f:      	movl	$0x3, %ebp
    2a34:      	leal	-0x9(%rcx), %edx
    2a37:      	cmpl	$0x2, %edx
    2a3a:      	jae	0x2d7f <kprobe_unwind_perl+0x2d7f>
    2a40:      	testb	%al, %al
    2a42:      	js	0x2d8f <kprobe_unwind_perl+0x2d8f>
    2a48:      	movzbl	0x1b(%r14), %eax
    2a4d:      	addq	%r13, %rax
    2a50:      	leaq	0x10(%rsp), %rdi
    2a55:      	movl	$0x8, %ecx
    2a5a:      	movl	$0x70, %r8d
    2a60:      	movzbl	0x1b(%r14), %edx
    2a65:      	addq	%r13, %rdx
    2a68:      	movl	$0x8, %esi
    2a6d:      	callq	*%r8
    2a70:      	testq	%rax, %rax
    2a73:      	jne	0x2528 <kprobe_unwind_perl+0x2528>
    2a79:      	cmpq	$0x0, 0x10(%rsp)
    2a7f:      	setne	0xf(%rsp)
    2a84:      	movzbl	0x1c(%r14), %eax
    2a89:      	addq	%r13, %rax
    2a8c:      	leaq	0xa0(%rsp), %rdi
    2a94:      	movl	$0x8, %ecx
    2a99:      	movl	$0x70, %r8d
    2a9f:      	movzbl	0x1c(%r14), %edx
    2aa4:      	addq	%r13, %rdx
    2aa7:      	movl	$0x8, %esi
    2aac:      	callq	*%r8
    2aaf:      	testq	%rax, %rax
    2ab2:      	jne	0x2528 <kprobe_unwind_perl+0x2528>
    2ab8:      	movq	0xa0(%rsp), %rbp
    2ac0:      	movzbl	0x1e(%r14), %eax
    2ac5:      	addq	%rbp, %rax
    2ac8:      	leaq	0x5c(%rsp), %rdi
    2acd:      	movl	$0x4, %ecx
    2ad2:      	movl	$0x70, %r8d
    2ad8:      	movzbl	0x1e(%r14), %edx
    2add:      	addq	%rbp, %rdx
    2ae0:      	movl	$0x4, %esi
    2ae5:      	callq	*%r8
    2ae8:      	testq	%rax, %rax
    2aeb:      	je	0x4464 <kprobe_unwind_perl+0x4464>
    2af1:      	movq	(%rip), %rax            # 0x2af8 <kprobe_unwind_perl+0x2af8>
    2af8:      	cmpl	$0x0, (%rax)
    2afb:      	jne	0x7860 <kprobe_unwind_perl+0x7860>
    2b01:      	movl	$0x14, 0x74(%rsp)
    2b09:      	movq	(%rip), %rdi            # 0x2b10 <kprobe_unwind_perl+0x2b10>
    2b10:      	leaq	0x74(%rsp), %rsi
    2b15:      	movl	$0x1, %eax
    2b1a:      	callq	*%rax
    2b1c:      	testq	%rax, %rax
    2b1f:      	je	0x49a5 <kprobe_unwind_perl+0x49a5>
    2b25:      	incq	(%rax)
    2b28:      	jmp	0x2528 <kprobe_unwind_perl+0x2528>
    2b2d:      	movq	(%rip), %rax            # 0x2b34 <kprobe_unwind_perl+0x2b34>
    2b34:      	cmpl	$0x0, (%rax)
    2b37:      	je	0xec7 <kprobe_unwind_perl+0xec7>
    2b3d:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2b47:      	movq	%rax, 0x36(%rsp)
    2b4c:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2b56:      	movq	%rax, 0x30(%rsp)
    2b5b:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2b65:      	movq	%rax, 0x28(%rsp)
    2b6a:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2b74:      	movq	%rax, 0x20(%rsp)
    2b79:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2b83:      	movq	%rax, 0x18(%rsp)
    2b88:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2b92:      	movq	%rax, 0x10(%rsp)
    2b97:      	leaq	0x10(%rsp), %rdi
    2b9c:      	movl	$0x2e, %eax
    2ba1:      	movl	$0x6, %ecx
    2ba6:      	movl	0x74(%rsp), %edx
    2baa:      	movl	$0x2e, %esi
    2baf:      	jmp	0x2cb4 <kprobe_unwind_perl+0x2cb4>
    2bb4:      	movq	(%rip), %rax            # 0x2bbb <kprobe_unwind_perl+0x2bbb>
    2bbb:      	cmpl	$0x0, (%rax)
    2bbe:      	jne	0x6883 <kprobe_unwind_perl+0x6883>
    2bc4:      	movl	$0x3, %ebp
    2bc9:      	jmp	0x2d8f <kprobe_unwind_perl+0x2d8f>
    2bce:      	movq	(%rip), %rax            # 0x2bd5 <kprobe_unwind_perl+0x2bd5>
    2bd5:      	cmpl	$0x0, (%rax)
    2bd8:      	je	0x568 <kprobe_unwind_perl+0x568>
    2bde:      	movabsq	$0xa782578302f78, %rax  # imm = 0xA782578302F78
    2be8:      	movq	%rax, 0x2e(%rsp)
    2bed:      	movabsq	$0x2f78257830207367, %rax # imm = 0x2F78257830207367
    2bf7:      	movq	%rax, 0x28(%rsp)
    2bfc:      	movabsq	$0x616c66202c564320, %rax # imm = 0x616C66202C564320
    2c06:      	movq	%rax, 0x20(%rsp)
    2c0b:      	movabsq	$0x44454d414e206465, %rax # imm = 0x44454D414E206465
    2c15:      	movq	%rax, 0x18(%rsp)
    2c1a:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    2c24:      	movq	%rax, 0x10(%rsp)
    2c29:      	leaq	0x10(%rsp), %rdi
    2c2e:      	movl	$0x26, %eax
    2c33:      	movl	$0x6, %r8d
    2c39:      	movl	0x5c(%rsp), %edx
    2c3d:      	movl	0x70(%rsp), %ecx
    2c41:      	movl	$0x26, %esi
    2c46:      	xorl	%eax, %eax
    2c48:      	callq	*%r8
    2c4b:      	jmp	0x568 <kprobe_unwind_perl+0x568>
    2c50:      	movq	(%rip), %rax            # 0x2c57 <kprobe_unwind_perl+0x2c57>
    2c57:      	cmpl	$0x0, (%rax)
    2c5a:      	je	0xec7 <kprobe_unwind_perl+0xec7>
    2c60:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    2c6a:      	movq	%rax, 0x26(%rsp)
    2c6f:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    2c79:      	movq	%rax, 0x20(%rsp)
    2c7e:      	movabsq	$0x5643565020612074, %rax # imm = 0x5643565020612074
    2c88:      	movq	%rax, 0x18(%rsp)
    2c8d:      	movabsq	$0x6f6e207369205643, %rax # imm = 0x6F6E207369205643
    2c97:      	movq	%rax, 0x10(%rsp)
    2c9c:      	leaq	0x10(%rsp), %rdi
    2ca1:      	movl	$0x1e, %eax
    2ca6:      	movl	$0x6, %ecx
    2cab:      	movl	0x5c(%rsp), %edx
    2caf:      	movl	$0x1e, %esi
    2cb4:      	xorl	%eax, %eax
    2cb6:      	callq	*%rcx
    2cb8:      	jmp	0xec7 <kprobe_unwind_perl+0xec7>
    2cbd:      	movabsq	$0x7825783020786320, %rax # imm = 0x7825783020786320
    2cc7:      	movq	%rax, 0x18(%rsp)
    2ccc:      	movabsq	$0x6c72657020746f47, %rax # imm = 0x6C72657020746F47
    2cd6:      	movq	%rax, 0x10(%rsp)
    2cdb:      	movw	$0xa, 0x20(%rsp)
    2ce2:      	leaq	0x10(%rsp), %rdi
    2ce7:      	movl	$0x12, %eax
    2cec:      	movl	$0x6, %ecx
    2cf1:      	movzbl	0xe(%rsp), %edx
    2cf6:      	movl	$0x12, %esi
    2cfb:      	xorl	%eax, %eax
    2cfd:      	callq	*%rcx
    2cff:      	jmp	0x8dd <kprobe_unwind_perl+0x8dd>
    2d04:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2d0e:      	movq	%rax, 0x36(%rsp)
    2d13:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2d1d:      	movq	%rax, 0x30(%rsp)
    2d22:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2d2c:      	movq	%rax, 0x28(%rsp)
    2d31:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2d3b:      	movq	%rax, 0x20(%rsp)
    2d40:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2d4a:      	movq	%rax, 0x18(%rsp)
    2d4f:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2d59:      	movq	%rax, 0x10(%rsp)
    2d5e:      	leaq	0x10(%rsp), %rdi
    2d63:      	movl	$0x2e, %eax
    2d68:      	movl	$0x6, %ecx
    2d6d:      	movl	0x50(%rsp), %edx
    2d71:      	movl	$0x2e, %esi
    2d76:      	xorl	%eax, %eax
    2d78:      	callq	*%rcx
    2d7a:      	jmp	0xafc <kprobe_unwind_perl+0xafc>
    2d7f:      	cmpl	$0xc, %ecx
    2d82:      	je	0x2d8f <kprobe_unwind_perl+0x2d8f>
    2d84:      	cmpq	$0x0, (%r12)
    2d89:      	je	0x4707 <kprobe_unwind_perl+0x4707>
    2d8f:      	movzbl	0x1d(%r14), %eax
    2d94:      	subq	%rax, 0xf50(%r15)
    2d9b:      	movl	$0x10, 0x50(%rsp)
    2da3:      	movq	(%rip), %rdi            # 0x2daa <kprobe_unwind_perl+0x2daa>
    2daa:      	leaq	0x50(%rsp), %rsi
    2daf:      	movl	$0x1, %eax
    2db4:      	callq	*%rax
    2db6:      	testq	%rax, %rax
    2db9:      	je	0x2dd0 <kprobe_unwind_perl+0x2dd0>
    2dbb:      	incq	(%rax)
    2dbe:      	cmpl	$0x3, %ebp
    2dc1:      	movq	0x98(%rsp), %rcx
    2dc9:      	je	0x2df1 <kprobe_unwind_perl+0x2df1>
    2dcb:      	jmp	0x5636 <kprobe_unwind_perl+0x5636>
    2dd0:      	movq	(%rip), %rax            # 0x2dd7 <kprobe_unwind_perl+0x2dd7>
    2dd7:      	cmpl	$0x0, (%rax)
    2dda:      	jne	0x6728 <kprobe_unwind_perl+0x6728>
    2de0:      	cmpl	$0x3, %ebp
    2de3:      	movq	0x98(%rsp), %rcx
    2deb:      	jne	0x5636 <kprobe_unwind_perl+0x5636>
    2df1:      	movq	0xf50(%r15), %r13
    2df8:      	cmpq	%rcx, %r13
    2dfb:      	jb	0x24e5 <kprobe_unwind_perl+0x24e5>
    2e01:      	movzbl	0x19(%r14), %eax
    2e06:      	addq	%r13, %rax
    2e09:      	leaq	0xe(%rsp), %rdi
    2e0e:      	movl	$0x1, %ecx
    2e13:      	movl	$0x70, %r8d
    2e19:      	movzbl	0x19(%r14), %edx
    2e1e:      	addq	%r13, %rdx
    2e21:      	movl	$0x1, %esi
    2e26:      	callq	*%r8
    2e29:      	testq	%rax, %rax
    2e2c:      	je	0x3435 <kprobe_unwind_perl+0x3435>
    2e32:      	movq	(%rip), %rax            # 0x2e39 <kprobe_unwind_perl+0x2e39>
    2e39:      	cmpl	$0x0, (%rax)
    2e3c:      	jne	0x6cb4 <kprobe_unwind_perl+0x6cb4>
    2e42:      	movl	$0x13, 0x50(%rsp)
    2e4a:      	movq	(%rip), %rdi            # 0x2e51 <kprobe_unwind_perl+0x2e51>
    2e51:      	leaq	0x50(%rsp), %rsi
    2e56:      	movl	$0x1, %eax
    2e5b:      	callq	*%rax
    2e5d:      	testq	%rax, %rax
    2e60:      	je	0x364c <kprobe_unwind_perl+0x364c>
    2e66:      	incq	(%rax)
    2e69:      	movl	$0x3, %ebp
    2e6e:      	jmp	0x38a2 <kprobe_unwind_perl+0x38a2>
    2e73:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    2e7d:      	movq	%rax, 0x27(%rsp)
    2e82:      	movabsq	$0x206d6f7266204453, %rax # imm = 0x206D6F7266204453
    2e8c:      	movq	%rax, 0x20(%rsp)
    2e91:      	movabsq	$0x542064616572206f, %rax # imm = 0x542064616572206F
    2e9b:      	movq	%rax, 0x18(%rsp)
    2ea0:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2eaa:      	movq	%rax, 0x10(%rsp)
    2eaf:      	leaq	0x10(%rsp), %rdi
    2eb4:      	movl	$0x1f, %eax
    2eb9:      	movl	$0x6, %ecx
    2ebe:      	movq	0x50(%rsp), %rdx
    2ec3:      	movl	$0x1f, %esi
    2ec8:      	xorl	%eax, %eax
    2eca:      	callq	*%rcx
    2ecc:      	jmp	0x8a1 <kprobe_unwind_perl+0x8a1>
    2ed1:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2edb:      	movq	%rax, 0x36(%rsp)
    2ee0:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2eea:      	movq	%rax, 0x30(%rsp)
    2eef:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2ef9:      	movq	%rax, 0x28(%rsp)
    2efe:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2f08:      	movq	%rax, 0x20(%rsp)
    2f0d:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2f17:      	movq	%rax, 0x18(%rsp)
    2f1c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2f26:      	movq	%rax, 0x10(%rsp)
    2f2b:      	leaq	0x10(%rsp), %rdi
    2f30:      	movl	$0x2e, %eax
    2f35:      	movl	$0x6, %ecx
    2f3a:      	movl	0x50(%rsp), %edx
    2f3e:      	movl	$0x2e, %esi
    2f43:      	xorl	%eax, %eax
    2f45:      	callq	*%rcx
    2f47:      	jmp	0x9f9 <kprobe_unwind_perl+0x9f9>
    2f4c:      	movabsq	$0x786c257830206574, %rax # imm = 0x786C257830206574
    2f56:      	movq	%rax, 0x28(%rsp)
    2f5b:      	movabsq	$0x6174732072657465, %rax # imm = 0x6174732072657465
    2f65:      	movq	%rax, 0x20(%rsp)
    2f6a:      	movabsq	$0x72707265746e6920, %rax # imm = 0x72707265746E6920
    2f74:      	movq	%rax, 0x18(%rsp)
    2f79:      	movabsq	$0x6d6f726620504f43, %rax # imm = 0x6D6F726620504F43
    2f83:      	movq	%rax, 0x10(%rsp)
    2f88:      	movw	$0xa, 0x30(%rsp)
    2f8f:      	leaq	0x10(%rsp), %rdi
    2f94:      	movl	$0x22, %eax
    2f99:      	movl	$0x6, %ecx
    2f9e:      	movq	(%r13), %rdx
    2fa2:      	movl	$0x22, %esi
    2fa7:      	xorl	%eax, %eax
    2fa9:      	callq	*%rcx
    2fab:      	jmp	0xa0d <kprobe_unwind_perl+0xa0d>
    2fb0:      	movabsq	$0x6c25783020737365, %rax # imm = 0x6C25783020737365
    2fba:      	movq	%rax, 0x28(%rsp)
    2fbf:      	movabsq	$0x72646461206d6f72, %rax # imm = 0x72646461206D6F72
    2fc9:      	movq	%rax, 0x20(%rsp)
    2fce:      	movabsq	$0x662064252079656b, %rax # imm = 0x662064252079656B
    2fd8:      	movq	%rax, 0x18(%rsp)
    2fdd:      	movabsq	$0x2044535464616572, %rax # imm = 0x2044535464616572
    2fe7:      	movq	%rax, 0x10(%rsp)
    2fec:      	movl	$0xa786c, 0x2f(%rsp)    # imm = 0xA786C
    2ff4:      	leaq	0x10(%rsp), %rdi
    2ff9:      	movl	$0x23, %eax
    2ffe:      	movl	$0x6, %r8d
    3004:      	movq	0x50(%rsp), %rcx
    3009:      	movl	$0x23, %esi
    300e:      	movl	%r13d, %edx
    3011:      	xorl	%eax, %eax
    3013:      	callq	*%r8
    3016:      	movq	0x50(%rsp), %rcx
    301b:      	jmp	0x86e <kprobe_unwind_perl+0x86e>
    3020:      	movabsq	$0x6c25783020746120, %rax # imm = 0x6C25783020746120
    302a:      	movq	%rax, 0x28(%rsp)
    302f:      	movabsq	$0x6f666e696b636174, %rax # imm = 0x6F666E696B636174
    3039:      	movq	%rax, 0x20(%rsp)
    303e:      	movabsq	$0x732064616572206f, %rax # imm = 0x732064616572206F
    3048:      	movq	%rax, 0x18(%rsp)
    304d:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3057:      	movq	%rax, 0x10(%rsp)
    305c:      	movl	$0xa786c, 0x2f(%rsp)    # imm = 0xA786C
    3064:      	leaq	0x10(%rsp), %rdi
    3069:      	movl	$0x23, %eax
    306e:      	movl	$0x6, %ecx
    3073:      	movl	$0x23, %esi
    3078:      	movq	%r13, %rdx
    307b:      	xorl	%eax, %eax
    307d:      	callq	*%rcx
    307f:      	jmp	0xa80 <kprobe_unwind_perl+0xa80>
    3084:      	movl	0x5c(%rsp), %eax
    3088:      	andl	$0x1f, %eax
    308b:      	cmpl	$0xd, %eax
    308e:      	jne	0x3763 <kprobe_unwind_perl+0x3763>
    3094:      	movzbl	0x1f(%r14), %eax
    3099:      	addq	%rbp, %rax
    309c:      	leaq	0x50(%rsp), %rdi
    30a1:      	movl	$0x8, %ecx
    30a6:      	movl	$0x70, %r8d
    30ac:      	movzbl	0x1f(%r14), %edx
    30b1:      	addq	%rbp, %rdx
    30b4:      	movl	$0x8, %esi
    30b9:      	callq	*%r8
    30bc:      	testq	%rax, %rax
    30bf:      	jne	0x198e <kprobe_unwind_perl+0x198e>
    30c5:      	movzbl	0x21(%r14), %eax
    30ca:      	addq	0x50(%rsp), %rax
    30cf:      	leaq	0x70(%rsp), %rdi
    30d4:      	movl	$0x4, %ecx
    30d9:      	movl	$0x70, %r8d
    30df:      	movzbl	0x21(%r14), %edx
    30e4:      	addq	0x50(%rsp), %rdx
    30e9:      	movl	$0x4, %esi
    30ee:      	callq	*%r8
    30f1:      	testq	%rax, %rax
    30f4:      	jne	0x198e <kprobe_unwind_perl+0x198e>
    30fa:      	testb	$-0x80, 0x71(%rsp)
    30ff:      	jne	0x4a46 <kprobe_unwind_perl+0x4a46>
    3105:      	movzbl	0x22(%r14), %eax
    310a:      	addq	0x50(%rsp), %rax
    310f:      	leaq	0x60(%rsp), %rbp
    3114:      	movl	$0x8, %ecx
    3119:      	movl	$0x70, %r8d
    311f:      	movzbl	0x22(%r14), %edx
    3124:      	addq	0x50(%rsp), %rdx
    3129:      	movq	%rbp, %rdi
    312c:      	movl	$0x8, %esi
    3131:      	callq	*%r8
    3134:      	testq	%rax, %rax
    3137:      	jne	0x198e <kprobe_unwind_perl+0x198e>
    313d:      	movq	0x60(%rsp), %rax
    3142:      	testq	%rax, %rax
    3145:      	je	0x198e <kprobe_unwind_perl+0x198e>
    314b:      	movq	(%rip), %rcx            # 0x3152 <kprobe_unwind_perl+0x3152>
    3152:      	cmpl	$0x0, (%rcx)
    3155:      	jne	0x83d5 <kprobe_unwind_perl+0x83d5>
    315b:      	movzbl	0x1e(%r14), %ecx
    3160:      	addq	%rax, %rcx
    3163:      	leaq	0x6c(%rsp), %rdi
    3168:      	movl	$0x4, %eax
    316d:      	movl	$0x70, %r8d
    3173:      	movzbl	0x1e(%r14), %edx
    3178:      	addq	0x60(%rsp), %rdx
    317d:      	movl	$0x4, %esi
    3182:      	callq	*%r8
    3185:      	testq	%rax, %rax
    3188:      	jne	0x198e <kprobe_unwind_perl+0x198e>
    318e:      	movl	$0x801f, %eax           # imm = 0x801F
    3193:      	andl	0x6c(%rsp), %eax
    3197:      	cmpl	$0x8009, %eax           # imm = 0x8009
    319c:      	jne	0x648c <kprobe_unwind_perl+0x648c>
    31a2:      	movzbl	0x20(%r14), %eax
    31a7:      	addq	0x60(%rsp), %rax
    31ac:      	leaq	0x88(%rsp), %rdi
    31b4:      	movl	$0x8, %ecx
    31b9:      	movl	$0x70, %r8d
    31bf:      	movzbl	0x20(%r14), %edx
    31c4:      	addq	0x60(%rsp), %rdx
    31c9:      	movl	$0x8, %esi
    31ce:      	callq	*%r8
    31d1:      	testq	%rax, %rax
    31d4:      	jne	0x198e <kprobe_unwind_perl+0x198e>
    31da:      	movzbl	0x23(%r14), %eax
    31df:      	addq	0x88(%rsp), %rax
    31e7:      	leaq	0x78(%rsp), %rdi
    31ec:      	movl	$0x8, %ecx
    31f1:      	movl	$0x70, %r8d
    31f7:      	movzbl	0x23(%r14), %edx
    31fc:      	addq	0x88(%rsp), %rdx
    3204:      	movl	$0x8, %esi
    3209:      	callq	*%r8
    320c:      	testq	%rax, %rax
    320f:      	jne	0x198e <kprobe_unwind_perl+0x198e>
    3215:      	movq	0x78(%rsp), %rax
    321a:      	movq	%rax, 0x80(%rsp)
    3222:      	testq	%rax, %rax
    3225:      	je	0x327b <kprobe_unwind_perl+0x327b>
    3227:      	movq	(%rip), %rax            # 0x322e <kprobe_unwind_perl+0x322e>
    322e:      	cmpl	$0x0, (%rax)
    3231:      	je	0x3290 <kprobe_unwind_perl+0x3290>
    3233:      	movabsq	$0x2578302074612056, %rax # imm = 0x2578302074612056
    323d:      	movq	%rax, 0x18(%rsp)
    3242:      	movabsq	$0x474520646e756f46, %rax # imm = 0x474520646E756F46
    324c:      	movq	%rax, 0x10(%rsp)
    3251:      	movl	$0xa786c, 0x20(%rsp)    # imm = 0xA786C
    3259:      	leaq	0x10(%rsp), %rdi
    325e:      	movl	$0x14, %eax
    3263:      	movl	$0x6, %ecx
    3268:      	movq	0x78(%rsp), %rdx
    326d:      	movl	$0x14, %esi
    3272:      	xorl	%eax, %eax
    3274:      	callq	*%rcx
    3276:      	leaq	0x78(%rsp), %rbp
    327b:      	movq	(%rbp), %rax
    327f:      	movq	%rax, 0x80(%rsp)
    3287:      	testq	%rax, %rax
    328a:      	je	0x149a <kprobe_unwind_perl+0x149a>
    3290:      	movq	(%r12), %rax
    3294:      	movq	%rax, 0x90(%rsp)
    329c:      	movq	(%rip), %rax            # 0x32a3 <kprobe_unwind_perl+0x32a3>
    32a3:      	cmpl	$0x0, (%rax)
    32a6:      	jne	0x8c25 <kprobe_unwind_perl+0x8c25>
    32ac:      	movl	0x2c0(%r15), %eax
    32b3:      	cmpq	$0x7e, %rax
    32b7:      	ja	0x1193 <kprobe_unwind_perl+0x1193>
    32bd:      	xorl	%ecx, %ecx
    32bf:      	movzbl	0xf(%rsp), %edx
    32c4:      	movb	%dl, %cl
    32c6:      	leal	0x1(,%rcx,2), %ebp
    32cd:      	leal	0x1(%rax), %ecx
    32d0:      	movl	%ecx, 0x2c0(%r15)
    32d7:      	leaq	(%rax,%rax,2), %rax
    32db:      	movq	0x80(%rsp), %rcx
    32e3:      	movq	%rcx, 0x2d0(%r15,%rax,8)
    32eb:      	movq	0x90(%rsp), %rcx
    32f3:      	movq	%rcx, 0x2d8(%r15,%rax,8)
    32fb:      	movb	$0x7, 0x2e0(%r15,%rax,8)
    3304:      	movl	$0x0, 0x2e1(%r15,%rax,8)
    3310:      	movl	$0x0, 0x2e4(%r15,%rax,8)
    331c:      	movq	$0x0, 0xf40(%r15)
    3327:      	movzbl	0x1a(%r14), %eax
    332c:      	addq	%r13, %rax
    332f:      	movl	$0x8, %ecx
    3334:      	movl	$0x70, %r8d
    333a:      	movzbl	0x1a(%r14), %edx
    333f:      	addq	%r13, %rdx
    3342:      	movq	%r12, %rdi
    3345:      	movl	$0x8, %esi
    334a:      	callq	*%r8
    334d:      	testq	%rax, %rax
    3350:      	jne	0x149a <kprobe_unwind_perl+0x149a>
    3356:      	movq	(%rip), %rax            # 0x335d <kprobe_unwind_perl+0x335d>
    335d:      	cmpl	$0x0, (%rax)
    3360:      	je	0x1ae2 <kprobe_unwind_perl+0x1ae2>
    3366:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    3370:      	movq	%rax, 0x26(%rsp)
    3375:      	movabsq	$0x30206b6361747320, %rax # imm = 0x30206B6361747320
    337f:      	movq	%rax, 0x20(%rsp)
    3384:      	movabsq	$0x747865746e6f6320, %rax # imm = 0x747865746E6F6320
    338e:      	movq	%rax, 0x18(%rsp)
    3393:      	movabsq	$0x6d6f726620504f43, %rax # imm = 0x6D6F726620504F43
    339d:      	movq	%rax, 0x10(%rsp)
    33a2:      	leaq	0x10(%rsp), %rdi
    33a7:      	movl	$0x1e, %eax
    33ac:      	movl	$0x6, %ecx
    33b1:      	movq	(%r12), %rdx
    33b5:      	movl	$0x1e, %esi
    33ba:      	xorl	%eax, %eax
    33bc:      	callq	*%rcx
    33be:      	jmp	0x1ae2 <kprobe_unwind_perl+0x1ae2>
    33c3:      	movabsq	$0x7025207461207972, %rax # imm = 0x7025207461207972
    33cd:      	movq	%rax, 0x30(%rsp)
    33d2:      	movabsq	$0x746e65206b636174, %rax # imm = 0x746E65206B636174
    33dc:      	movq	%rax, 0x28(%rsp)
    33e1:      	movabsq	$0x7320747865746e6f, %rax # imm = 0x7320747865746E6F
    33eb:      	movq	%rax, 0x20(%rsp)
    33f0:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    33fa:      	movq	%rax, 0x18(%rsp)
    33ff:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3409:      	movq	%rax, 0x10(%rsp)
    340e:      	movw	$0xa, 0x38(%rsp)
    3415:      	leaq	0x10(%rsp), %rdi
    341a:      	movl	$0x2a, %eax
    341f:      	movl	$0x6, %ecx
    3424:      	movl	$0x2a, %esi
    3429:      	movq	%r13, %rdx
    342c:      	xorl	%eax, %eax
    342e:      	callq	*%rcx
    3430:      	jmp	0xb78 <kprobe_unwind_perl+0xb78>
    3435:      	movq	(%rip), %rax            # 0x343c <kprobe_unwind_perl+0x343c>
    343c:      	cmpl	$0x0, (%rax)
    343f:      	jne	0x6f61 <kprobe_unwind_perl+0x6f61>
    3445:      	movzbl	0xe(%rsp), %eax
    344a:      	movl	%eax, %ecx
    344c:      	andl	$0xf, %ecx
    344f:      	movl	$0x3, %ebp
    3454:      	leal	-0x9(%rcx), %edx
    3457:      	cmpl	$0x2, %edx
    345a:      	jae	0x3892 <kprobe_unwind_perl+0x3892>
    3460:      	testb	%al, %al
    3462:      	js	0x38a2 <kprobe_unwind_perl+0x38a2>
    3468:      	movzbl	0x1b(%r14), %eax
    346d:      	addq	%r13, %rax
    3470:      	leaq	0x10(%rsp), %rdi
    3475:      	movl	$0x8, %ecx
    347a:      	movl	$0x70, %r8d
    3480:      	movzbl	0x1b(%r14), %edx
    3485:      	addq	%r13, %rdx
    3488:      	movl	$0x8, %esi
    348d:      	callq	*%r8
    3490:      	testq	%rax, %rax
    3493:      	jne	0x2e32 <kprobe_unwind_perl+0x2e32>
    3499:      	cmpq	$0x0, 0x10(%rsp)
    349f:      	setne	0xf(%rsp)
    34a4:      	movzbl	0x1c(%r14), %eax
    34a9:      	addq	%r13, %rax
    34ac:      	leaq	0xa0(%rsp), %rdi
    34b4:      	movl	$0x8, %ecx
    34b9:      	movl	$0x70, %r8d
    34bf:      	movzbl	0x1c(%r14), %edx
    34c4:      	addq	%r13, %rdx
    34c7:      	movl	$0x8, %esi
    34cc:      	callq	*%r8
    34cf:      	testq	%rax, %rax
    34d2:      	jne	0x2e32 <kprobe_unwind_perl+0x2e32>
    34d8:      	movq	0xa0(%rsp), %rbp
    34e0:      	movzbl	0x1e(%r14), %eax
    34e5:      	addq	%rbp, %rax
    34e8:      	leaq	0x5c(%rsp), %rdi
    34ed:      	movl	$0x4, %ecx
    34f2:      	movl	$0x70, %r8d
    34f8:      	movzbl	0x1e(%r14), %edx
    34fd:      	addq	%rbp, %rdx
    3500:      	movl	$0x4, %esi
    3505:      	callq	*%r8
    3508:      	testq	%rax, %rax
    350b:      	je	0x4e12 <kprobe_unwind_perl+0x4e12>
    3511:      	movq	(%rip), %rax            # 0x3518 <kprobe_unwind_perl+0x3518>
    3518:      	cmpl	$0x0, (%rax)
    351b:      	jne	0x816e <kprobe_unwind_perl+0x816e>
    3521:      	movl	$0x14, 0x74(%rsp)
    3529:      	movq	(%rip), %rdi            # 0x3530 <kprobe_unwind_perl+0x3530>
    3530:      	leaq	0x74(%rsp), %rsi
    3535:      	movl	$0x1, %eax
    353a:      	callq	*%rax
    353c:      	testq	%rax, %rax
    353f:      	je	0x5353 <kprobe_unwind_perl+0x5353>
    3545:      	incq	(%rax)
    3548:      	jmp	0x2e32 <kprobe_unwind_perl+0x2e32>
    354d:      	movq	(%rip), %rax            # 0x3554 <kprobe_unwind_perl+0x3554>
    3554:      	cmpl	$0x0, (%rax)
    3557:      	je	0x27c <kprobe_unwind_perl+0x27c>
    355d:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    3567:      	movq	%rax, 0x2e(%rsp)
    356c:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    3576:      	movq	%rax, 0x28(%rsp)
    357b:      	movabsq	$0x50472d74756f6874, %rax # imm = 0x50472D74756F6874
    3585:      	movq	%rax, 0x20(%rsp)
    358a:      	movabsq	$0x69772d5647206465, %rax # imm = 0x69772D5647206465
    3594:      	movq	%rax, 0x18(%rsp)
    3599:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    35a3:      	movq	%rax, 0x10(%rsp)
    35a8:      	leaq	0x10(%rsp), %rdi
    35ad:      	movl	$0x26, %eax
    35b2:      	movl	$0x6, %ecx
    35b7:      	movl	0x6c(%rsp), %edx
    35bb:      	movl	$0x26, %esi
    35c0:      	jmp	0x13e6 <kprobe_unwind_perl+0x13e6>
    35c5:      	movq	(%rip), %rax            # 0x35cc <kprobe_unwind_perl+0x35cc>
    35cc:      	cmpl	$0x0, (%rax)
    35cf:      	je	0x149a <kprobe_unwind_perl+0x149a>
    35d5:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    35df:      	movq	%rax, 0x36(%rsp)
    35e4:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    35ee:      	movq	%rax, 0x30(%rsp)
    35f3:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    35fd:      	movq	%rax, 0x28(%rsp)
    3602:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    360c:      	movq	%rax, 0x20(%rsp)
    3611:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    361b:      	movq	%rax, 0x18(%rsp)
    3620:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    362a:      	movq	%rax, 0x10(%rsp)
    362f:      	leaq	0x10(%rsp), %rdi
    3634:      	movl	$0x2e, %eax
    3639:      	movl	$0x6, %ecx
    363e:      	movl	0x74(%rsp), %edx
    3642:      	movl	$0x2e, %esi
    3647:      	jmp	0x37c7 <kprobe_unwind_perl+0x37c7>
    364c:      	movq	(%rip), %rax            # 0x3653 <kprobe_unwind_perl+0x3653>
    3653:      	cmpl	$0x0, (%rax)
    3656:      	jne	0x7034 <kprobe_unwind_perl+0x7034>
    365c:      	movl	$0x3, %ebp
    3661:      	jmp	0x38a2 <kprobe_unwind_perl+0x38a2>
    3666:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3670:      	movq	%rax, 0x36(%rsp)
    3675:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    367f:      	movq	%rax, 0x30(%rsp)
    3684:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    368e:      	movq	%rax, 0x28(%rsp)
    3693:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    369d:      	movq	%rax, 0x20(%rsp)
    36a2:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    36ac:      	movq	%rax, 0x18(%rsp)
    36b1:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    36bb:      	movq	%rax, 0x10(%rsp)
    36c0:      	leaq	0x10(%rsp), %rdi
    36c5:      	movl	$0x2e, %eax
    36ca:      	movl	$0x6, %ecx
    36cf:      	movl	0x78(%rsp), %edx
    36d3:      	movl	$0x2e, %esi
    36d8:      	xorl	%eax, %eax
    36da:      	callq	*%rcx
    36dc:      	jmp	0xbb4 <kprobe_unwind_perl+0xbb4>
    36e1:      	movq	(%rip), %rax            # 0x36e8 <kprobe_unwind_perl+0x36e8>
    36e8:      	cmpl	$0x0, (%rax)
    36eb:      	je	0xb68 <kprobe_unwind_perl+0xb68>
    36f1:      	movabsq	$0xa782578302f78, %rax  # imm = 0xA782578302F78
    36fb:      	movq	%rax, 0x2e(%rsp)
    3700:      	movabsq	$0x2f78257830207367, %rax # imm = 0x2F78257830207367
    370a:      	movq	%rax, 0x28(%rsp)
    370f:      	movabsq	$0x616c66202c564320, %rax # imm = 0x616C66202C564320
    3719:      	movq	%rax, 0x20(%rsp)
    371e:      	movabsq	$0x44454d414e206465, %rax # imm = 0x44454D414E206465
    3728:      	movq	%rax, 0x18(%rsp)
    372d:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    3737:      	movq	%rax, 0x10(%rsp)
    373c:      	leaq	0x10(%rsp), %rdi
    3741:      	movl	$0x26, %eax
    3746:      	movl	$0x6, %r8d
    374c:      	movl	0x5c(%rsp), %edx
    3750:      	movl	0x70(%rsp), %ecx
    3754:      	movl	$0x26, %esi
    3759:      	xorl	%eax, %eax
    375b:      	callq	*%r8
    375e:      	jmp	0xb68 <kprobe_unwind_perl+0xb68>
    3763:      	movq	(%rip), %rax            # 0x376a <kprobe_unwind_perl+0x376a>
    376a:      	cmpl	$0x0, (%rax)
    376d:      	je	0x149a <kprobe_unwind_perl+0x149a>
    3773:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    377d:      	movq	%rax, 0x26(%rsp)
    3782:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    378c:      	movq	%rax, 0x20(%rsp)
    3791:      	movabsq	$0x5643565020612074, %rax # imm = 0x5643565020612074
    379b:      	movq	%rax, 0x18(%rsp)
    37a0:      	movabsq	$0x6f6e207369205643, %rax # imm = 0x6F6E207369205643
    37aa:      	movq	%rax, 0x10(%rsp)
    37af:      	leaq	0x10(%rsp), %rdi
    37b4:      	movl	$0x1e, %eax
    37b9:      	movl	$0x6, %ecx
    37be:      	movl	0x5c(%rsp), %edx
    37c2:      	movl	$0x1e, %esi
    37c7:      	xorl	%eax, %eax
    37c9:      	callq	*%rcx
    37cb:      	jmp	0x149a <kprobe_unwind_perl+0x149a>
    37d0:      	movabsq	$0x7825783020786320, %rax # imm = 0x7825783020786320
    37da:      	movq	%rax, 0x18(%rsp)
    37df:      	movabsq	$0x6c72657020746f47, %rax # imm = 0x6C72657020746F47
    37e9:      	movq	%rax, 0x10(%rsp)
    37ee:      	movw	$0xa, 0x20(%rsp)
    37f5:      	leaq	0x10(%rsp), %rdi
    37fa:      	movl	$0x12, %eax
    37ff:      	movl	$0x6, %ecx
    3804:      	movzbl	0xe(%rsp), %edx
    3809:      	movl	$0x12, %esi
    380e:      	xorl	%eax, %eax
    3810:      	callq	*%rcx
    3812:      	jmp	0xc6e <kprobe_unwind_perl+0xc6e>
    3817:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3821:      	movq	%rax, 0x36(%rsp)
    3826:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    3830:      	movq	%rax, 0x30(%rsp)
    3835:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    383f:      	movq	%rax, 0x28(%rsp)
    3844:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    384e:      	movq	%rax, 0x20(%rsp)
    3853:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    385d:      	movq	%rax, 0x18(%rsp)
    3862:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    386c:      	movq	%rax, 0x10(%rsp)
    3871:      	leaq	0x10(%rsp), %rdi
    3876:      	movl	$0x2e, %eax
    387b:      	movl	$0x6, %ecx
    3880:      	movl	0x50(%rsp), %edx
    3884:      	movl	$0x2e, %esi
    3889:      	xorl	%eax, %eax
    388b:      	callq	*%rcx
    388d:      	jmp	0xe5b <kprobe_unwind_perl+0xe5b>
    3892:      	cmpl	$0xc, %ecx
    3895:      	je	0x38a2 <kprobe_unwind_perl+0x38a2>
    3897:      	cmpq	$0x0, (%r12)
    389c:      	je	0x50b5 <kprobe_unwind_perl+0x50b5>
    38a2:      	movzbl	0x1d(%r14), %eax
    38a7:      	subq	%rax, 0xf50(%r15)
    38ae:      	movl	$0x10, 0x50(%rsp)
    38b6:      	movq	(%rip), %rdi            # 0x38bd <kprobe_unwind_perl+0x38bd>
    38bd:      	leaq	0x50(%rsp), %rsi
    38c2:      	movl	$0x1, %eax
    38c7:      	callq	*%rax
    38c9:      	testq	%rax, %rax
    38cc:      	je	0x38e3 <kprobe_unwind_perl+0x38e3>
    38ce:      	incq	(%rax)
    38d1:      	cmpl	$0x3, %ebp
    38d4:      	movq	0x98(%rsp), %rcx
    38dc:      	je	0x3904 <kprobe_unwind_perl+0x3904>
    38de:      	jmp	0x5636 <kprobe_unwind_perl+0x5636>
    38e3:      	movq	(%rip), %rax            # 0x38ea <kprobe_unwind_perl+0x38ea>
    38ea:      	cmpl	$0x0, (%rax)
    38ed:      	jne	0x6fa8 <kprobe_unwind_perl+0x6fa8>
    38f3:      	cmpl	$0x3, %ebp
    38f6:      	movq	0x98(%rsp), %rcx
    38fe:      	jne	0x5636 <kprobe_unwind_perl+0x5636>
    3904:      	movq	0xf50(%r15), %r13
    390b:      	cmpq	%rcx, %r13
    390e:      	jb	0x24e5 <kprobe_unwind_perl+0x24e5>
    3914:      	movzbl	0x19(%r14), %eax
    3919:      	addq	%r13, %rax
    391c:      	leaq	0xe(%rsp), %rdi
    3921:      	movl	$0x1, %ecx
    3926:      	movl	$0x70, %r8d
    392c:      	movzbl	0x19(%r14), %edx
    3931:      	addq	%r13, %rdx
    3934:      	movl	$0x1, %esi
    3939:      	callq	*%r8
    393c:      	testq	%rax, %rax
    393f:      	je	0x3e29 <kprobe_unwind_perl+0x3e29>
    3945:      	movq	(%rip), %rax            # 0x394c <kprobe_unwind_perl+0x394c>
    394c:      	cmpl	$0x0, (%rax)
    394f:      	jne	0x7465 <kprobe_unwind_perl+0x7465>
    3955:      	movl	$0x13, 0x50(%rsp)
    395d:      	movq	(%rip), %rdi            # 0x3964 <kprobe_unwind_perl+0x3964>
    3964:      	leaq	0x50(%rsp), %rsi
    3969:      	movl	$0x1, %eax
    396e:      	callq	*%rax
    3970:      	testq	%rax, %rax
    3973:      	je	0x40b3 <kprobe_unwind_perl+0x40b3>
    3979:      	incq	(%rax)
    397c:      	movl	$0x3, %ebp
    3981:      	jmp	0x428e <kprobe_unwind_perl+0x428e>
    3986:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3990:      	movq	%rax, 0x36(%rsp)
    3995:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    399f:      	movq	%rax, 0x30(%rsp)
    39a4:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    39ae:      	movq	%rax, 0x28(%rsp)
    39b3:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    39bd:      	movq	%rax, 0x20(%rsp)
    39c2:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    39cc:      	movq	%rax, 0x18(%rsp)
    39d1:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    39db:      	movq	%rax, 0x10(%rsp)
    39e0:      	leaq	0x10(%rsp), %rdi
    39e5:      	movl	$0x2e, %eax
    39ea:      	movl	$0x6, %ecx
    39ef:      	movl	0x50(%rsp), %edx
    39f3:      	movl	$0x2e, %esi
    39f8:      	xorl	%eax, %eax
    39fa:      	callq	*%rcx
    39fc:      	jmp	0xe15 <kprobe_unwind_perl+0xe15>
    3a01:      	movabsq	$0xa7667655f7663, %rax  # imm = 0xA7667655F7663
    3a0b:      	movq	%rax, 0x35(%rsp)
    3a10:      	movabsq	$0x5f76635f65766c6f, %rax # imm = 0x5F76635F65766C6F
    3a1a:      	movq	%rax, 0x30(%rsp)
    3a1f:      	movabsq	$0x736572206e692029, %rax # imm = 0x736572206E692029
    3a29:      	movq	%rax, 0x28(%rsp)
    3a2e:      	movabsq	$0x28726573755f6461, %rax # imm = 0x28726573755F6461
    3a38:      	movq	%rax, 0x20(%rsp)
    3a3d:      	movabsq	$0x65725f65626f7270, %rax # imm = 0x65725F65626F7270
    3a47:      	movq	%rax, 0x18(%rsp)
    3a4c:      	movabsq	$0x5f66706220646142, %rax # imm = 0x5F66706220646142
    3a56:      	movq	%rax, 0x10(%rsp)
    3a5b:      	leaq	0x10(%rsp), %rdi
    3a60:      	movl	$0x2d, %eax
    3a65:      	movl	$0x6, %ecx
    3a6a:      	movl	$0x2d, %esi
    3a6f:      	xorl	%eax, %eax
    3a71:      	callq	*%rcx
    3a73:      	jmp	0x48c <kprobe_unwind_perl+0x48c>
    3a78:      	movl	0x5c(%rsp), %eax
    3a7c:      	andl	$0x1f, %eax
    3a7f:      	cmpl	$0xd, %eax
    3a82:      	jne	0x414f <kprobe_unwind_perl+0x414f>
    3a88:      	movzbl	0x1f(%r14), %eax
    3a8d:      	addq	%rbp, %rax
    3a90:      	leaq	0x50(%rsp), %rdi
    3a95:      	movl	$0x8, %ecx
    3a9a:      	movl	$0x70, %r8d
    3aa0:      	movzbl	0x1f(%r14), %edx
    3aa5:      	addq	%rbp, %rdx
    3aa8:      	movl	$0x8, %esi
    3aad:      	callq	*%r8
    3ab0:      	testq	%rax, %rax
    3ab3:      	jne	0x204b <kprobe_unwind_perl+0x204b>
    3ab9:      	movzbl	0x21(%r14), %eax
    3abe:      	addq	0x50(%rsp), %rax
    3ac3:      	leaq	0x70(%rsp), %rdi
    3ac8:      	movl	$0x4, %ecx
    3acd:      	movl	$0x70, %r8d
    3ad3:      	movzbl	0x21(%r14), %edx
    3ad8:      	addq	0x50(%rsp), %rdx
    3add:      	movl	$0x4, %esi
    3ae2:      	callq	*%r8
    3ae5:      	testq	%rax, %rax
    3ae8:      	jne	0x204b <kprobe_unwind_perl+0x204b>
    3aee:      	testb	$-0x80, 0x71(%rsp)
    3af3:      	jne	0x53f4 <kprobe_unwind_perl+0x53f4>
    3af9:      	movzbl	0x22(%r14), %eax
    3afe:      	addq	0x50(%rsp), %rax
    3b03:      	leaq	0x60(%rsp), %rbp
    3b08:      	movl	$0x8, %ecx
    3b0d:      	movl	$0x70, %r8d
    3b13:      	movzbl	0x22(%r14), %edx
    3b18:      	addq	0x50(%rsp), %rdx
    3b1d:      	movq	%rbp, %rdi
    3b20:      	movl	$0x8, %esi
    3b25:      	callq	*%r8
    3b28:      	testq	%rax, %rax
    3b2b:      	jne	0x204b <kprobe_unwind_perl+0x204b>
    3b31:      	movq	0x60(%rsp), %rax
    3b36:      	testq	%rax, %rax
    3b39:      	je	0x204b <kprobe_unwind_perl+0x204b>
    3b3f:      	movq	(%rip), %rcx            # 0x3b46 <kprobe_unwind_perl+0x3b46>
    3b46:      	cmpl	$0x0, (%rcx)
    3b49:      	jne	0x87de <kprobe_unwind_perl+0x87de>
    3b4f:      	movzbl	0x1e(%r14), %ecx
    3b54:      	addq	%rax, %rcx
    3b57:      	leaq	0x6c(%rsp), %rdi
    3b5c:      	movl	$0x4, %eax
    3b61:      	movl	$0x70, %r8d
    3b67:      	movzbl	0x1e(%r14), %edx
    3b6c:      	addq	0x60(%rsp), %rdx
    3b71:      	movl	$0x4, %esi
    3b76:      	callq	*%r8
    3b79:      	testq	%rax, %rax
    3b7c:      	jne	0x204b <kprobe_unwind_perl+0x204b>
    3b82:      	movl	$0x801f, %eax           # imm = 0x801F
    3b87:      	andl	0x6c(%rsp), %eax
    3b8b:      	cmpl	$0x8009, %eax           # imm = 0x8009
    3b90:      	jne	0x6d26 <kprobe_unwind_perl+0x6d26>
    3b96:      	movzbl	0x20(%r14), %eax
    3b9b:      	addq	0x60(%rsp), %rax
    3ba0:      	leaq	0x88(%rsp), %rdi
    3ba8:      	movl	$0x8, %ecx
    3bad:      	movl	$0x70, %r8d
    3bb3:      	movzbl	0x20(%r14), %edx
    3bb8:      	addq	0x60(%rsp), %rdx
    3bbd:      	movl	$0x8, %esi
    3bc2:      	callq	*%r8
    3bc5:      	testq	%rax, %rax
    3bc8:      	jne	0x204b <kprobe_unwind_perl+0x204b>
    3bce:      	movzbl	0x23(%r14), %eax
    3bd3:      	addq	0x88(%rsp), %rax
    3bdb:      	leaq	0x78(%rsp), %rdi
    3be0:      	movl	$0x8, %ecx
    3be5:      	movl	$0x70, %r8d
    3beb:      	movzbl	0x23(%r14), %edx
    3bf0:      	addq	0x88(%rsp), %rdx
    3bf8:      	movl	$0x8, %esi
    3bfd:      	callq	*%r8
    3c00:      	testq	%rax, %rax
    3c03:      	jne	0x204b <kprobe_unwind_perl+0x204b>
    3c09:      	movq	0x78(%rsp), %rax
    3c0e:      	movq	%rax, 0x80(%rsp)
    3c16:      	testq	%rax, %rax
    3c19:      	je	0x3c6f <kprobe_unwind_perl+0x3c6f>
    3c1b:      	movq	(%rip), %rax            # 0x3c22 <kprobe_unwind_perl+0x3c22>
    3c22:      	cmpl	$0x0, (%rax)
    3c25:      	je	0x3c84 <kprobe_unwind_perl+0x3c84>
    3c27:      	movabsq	$0x2578302074612056, %rax # imm = 0x2578302074612056
    3c31:      	movq	%rax, 0x18(%rsp)
    3c36:      	movabsq	$0x474520646e756f46, %rax # imm = 0x474520646E756F46
    3c40:      	movq	%rax, 0x10(%rsp)
    3c45:      	movl	$0xa786c, 0x20(%rsp)    # imm = 0xA786C
    3c4d:      	leaq	0x10(%rsp), %rdi
    3c52:      	movl	$0x14, %eax
    3c57:      	movl	$0x6, %ecx
    3c5c:      	movq	0x78(%rsp), %rdx
    3c61:      	movl	$0x14, %esi
    3c66:      	xorl	%eax, %eax
    3c68:      	callq	*%rcx
    3c6a:      	leaq	0x78(%rsp), %rbp
    3c6f:      	movq	(%rbp), %rax
    3c73:      	movq	%rax, 0x80(%rsp)
    3c7b:      	testq	%rax, %rax
    3c7e:      	je	0x1b7d <kprobe_unwind_perl+0x1b7d>
    3c84:      	movq	(%r12), %rax
    3c88:      	movq	%rax, 0x90(%rsp)
    3c90:      	movq	(%rip), %rax            # 0x3c97 <kprobe_unwind_perl+0x3c97>
    3c97:      	cmpl	$0x0, (%rax)
    3c9a:      	jne	0x8d74 <kprobe_unwind_perl+0x8d74>
    3ca0:      	movl	0x2c0(%r15), %eax
    3ca7:      	cmpq	$0x7e, %rax
    3cab:      	ja	0x1193 <kprobe_unwind_perl+0x1193>
    3cb1:      	xorl	%ecx, %ecx
    3cb3:      	movzbl	0xf(%rsp), %edx
    3cb8:      	movb	%dl, %cl
    3cba:      	leal	0x1(,%rcx,2), %ebp
    3cc1:      	leal	0x1(%rax), %ecx
    3cc4:      	movl	%ecx, 0x2c0(%r15)
    3ccb:      	leaq	(%rax,%rax,2), %rax
    3ccf:      	movq	0x80(%rsp), %rcx
    3cd7:      	movq	%rcx, 0x2d0(%r15,%rax,8)
    3cdf:      	movq	0x90(%rsp), %rcx
    3ce7:      	movq	%rcx, 0x2d8(%r15,%rax,8)
    3cef:      	movb	$0x7, 0x2e0(%r15,%rax,8)
    3cf8:      	movl	$0x0, 0x2e1(%r15,%rax,8)
    3d04:      	movl	$0x0, 0x2e4(%r15,%rax,8)
    3d10:      	movq	$0x0, 0xf40(%r15)
    3d1b:      	movzbl	0x1a(%r14), %eax
    3d20:      	addq	%r13, %rax
    3d23:      	movl	$0x8, %ecx
    3d28:      	movl	$0x70, %r8d
    3d2e:      	movzbl	0x1a(%r14), %edx
    3d33:      	addq	%r13, %rdx
    3d36:      	movq	%r12, %rdi
    3d39:      	movl	$0x8, %esi
    3d3e:      	callq	*%r8
    3d41:      	testq	%rax, %rax
    3d44:      	jne	0x1b7d <kprobe_unwind_perl+0x1b7d>
    3d4a:      	movq	(%rip), %rax            # 0x3d51 <kprobe_unwind_perl+0x3d51>
    3d51:      	cmpl	$0x0, (%rax)
    3d54:      	je	0x2477 <kprobe_unwind_perl+0x2477>
    3d5a:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    3d64:      	movq	%rax, 0x26(%rsp)
    3d69:      	movabsq	$0x30206b6361747320, %rax # imm = 0x30206B6361747320
    3d73:      	movq	%rax, 0x20(%rsp)
    3d78:      	movabsq	$0x747865746e6f6320, %rax # imm = 0x747865746E6F6320
    3d82:      	movq	%rax, 0x18(%rsp)
    3d87:      	movabsq	$0x6d6f726620504f43, %rax # imm = 0x6D6F726620504F43
    3d91:      	movq	%rax, 0x10(%rsp)
    3d96:      	leaq	0x10(%rsp), %rdi
    3d9b:      	movl	$0x1e, %eax
    3da0:      	movl	$0x6, %ecx
    3da5:      	movq	(%r12), %rdx
    3da9:      	movl	$0x1e, %esi
    3dae:      	xorl	%eax, %eax
    3db0:      	callq	*%rcx
    3db2:      	jmp	0x2477 <kprobe_unwind_perl+0x2477>
    3db7:      	movabsq	$0x7025207461207972, %rax # imm = 0x7025207461207972
    3dc1:      	movq	%rax, 0x30(%rsp)
    3dc6:      	movabsq	$0x746e65206b636174, %rax # imm = 0x746E65206B636174
    3dd0:      	movq	%rax, 0x28(%rsp)
    3dd5:      	movabsq	$0x7320747865746e6f, %rax # imm = 0x7320747865746E6F
    3ddf:      	movq	%rax, 0x20(%rsp)
    3de4:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    3dee:      	movq	%rax, 0x18(%rsp)
    3df3:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3dfd:      	movq	%rax, 0x10(%rsp)
    3e02:      	movw	$0xa, 0x38(%rsp)
    3e09:      	leaq	0x10(%rsp), %rdi
    3e0e:      	movl	$0x2a, %eax
    3e13:      	movl	$0x6, %ecx
    3e18:      	movl	$0x2a, %esi
    3e1d:      	movq	%r13, %rdx
    3e20:      	xorl	%eax, %eax
    3e22:      	callq	*%rcx
    3e24:      	jmp	0xed7 <kprobe_unwind_perl+0xed7>
    3e29:      	movq	(%rip), %rax            # 0x3e30 <kprobe_unwind_perl+0x3e30>
    3e30:      	cmpl	$0x0, (%rax)
    3e33:      	jne	0x7712 <kprobe_unwind_perl+0x7712>
    3e39:      	movzbl	0xe(%rsp), %eax
    3e3e:      	movl	%eax, %ecx
    3e40:      	andl	$0xf, %ecx
    3e43:      	movl	$0x3, %ebp
    3e48:      	leal	-0x9(%rcx), %edx
    3e4b:      	cmpl	$0x2, %edx
    3e4e:      	jae	0x427e <kprobe_unwind_perl+0x427e>
    3e54:      	testb	%al, %al
    3e56:      	js	0x428e <kprobe_unwind_perl+0x428e>
    3e5c:      	movzbl	0x1b(%r14), %eax
    3e61:      	addq	%r13, %rax
    3e64:      	leaq	0x10(%rsp), %rdi
    3e69:      	movl	$0x8, %ecx
    3e6e:      	movl	$0x70, %r8d
    3e74:      	movzbl	0x1b(%r14), %edx
    3e79:      	addq	%r13, %rdx
    3e7c:      	movl	$0x8, %esi
    3e81:      	callq	*%r8
    3e84:      	testq	%rax, %rax
    3e87:      	jne	0x3945 <kprobe_unwind_perl+0x3945>
    3e8d:      	cmpq	$0x0, 0x10(%rsp)
    3e93:      	setne	0xf(%rsp)
    3e98:      	movzbl	0x1c(%r14), %eax
    3e9d:      	addq	%r13, %rax
    3ea0:      	leaq	0xa0(%rsp), %rdi
    3ea8:      	movl	$0x8, %ecx
    3ead:      	movl	$0x70, %r8d
    3eb3:      	movzbl	0x1c(%r14), %edx
    3eb8:      	addq	%r13, %rdx
    3ebb:      	movl	$0x8, %esi
    3ec0:      	callq	*%r8
    3ec3:      	testq	%rax, %rax
    3ec6:      	jne	0x3945 <kprobe_unwind_perl+0x3945>
    3ecc:      	movq	0xa0(%rsp), %rbp
    3ed4:      	movzbl	0x1e(%r14), %eax
    3ed9:      	addq	%rbp, %rax
    3edc:      	leaq	0x5c(%rsp), %rdi
    3ee1:      	movl	$0x4, %ecx
    3ee6:      	movl	$0x70, %r8d
    3eec:      	movzbl	0x1e(%r14), %edx
    3ef1:      	addq	%rbp, %rdx
    3ef4:      	movl	$0x4, %esi
    3ef9:      	callq	*%r8
    3efc:      	testq	%rax, %rax
    3eff:      	je	0x5fc3 <kprobe_unwind_perl+0x5fc3>
    3f05:      	movq	(%rip), %rax            # 0x3f0c <kprobe_unwind_perl+0x3f0c>
    3f0c:      	cmpl	$0x0, (%rax)
    3f0f:      	jne	0x85f2 <kprobe_unwind_perl+0x85f2>
    3f15:      	movl	$0x14, 0x74(%rsp)
    3f1d:      	movq	(%rip), %rdi            # 0x3f24 <kprobe_unwind_perl+0x3f24>
    3f24:      	leaq	0x74(%rsp), %rsi
    3f29:      	movl	$0x1, %eax
    3f2e:      	callq	*%rax
    3f30:      	testq	%rax, %rax
    3f33:      	je	0x6504 <kprobe_unwind_perl+0x6504>
    3f39:      	incq	(%rax)
    3f3c:      	jmp	0x3945 <kprobe_unwind_perl+0x3945>
    3f41:      	movq	(%rip), %rax            # 0x3f48 <kprobe_unwind_perl+0x3f48>
    3f48:      	cmpl	$0x0, (%rax)
    3f4b:      	je	0x568 <kprobe_unwind_perl+0x568>
    3f51:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    3f5b:      	movq	%rax, 0x2e(%rsp)
    3f60:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    3f6a:      	movq	%rax, 0x28(%rsp)
    3f6f:      	movabsq	$0x50472d74756f6874, %rax # imm = 0x50472D74756F6874
    3f79:      	movq	%rax, 0x20(%rsp)
    3f7e:      	movabsq	$0x69772d5647206465, %rax # imm = 0x69772D5647206465
    3f88:      	movq	%rax, 0x18(%rsp)
    3f8d:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    3f97:      	movq	%rax, 0x10(%rsp)
    3f9c:      	leaq	0x10(%rsp), %rdi
    3fa1:      	movl	$0x26, %eax
    3fa6:      	movl	$0x6, %ecx
    3fab:      	movl	0x6c(%rsp), %edx
    3faf:      	movl	$0x26, %esi
    3fb4:      	jmp	0x1ac9 <kprobe_unwind_perl+0x1ac9>
    3fb9:      	movq	(%rip), %rax            # 0x3fc0 <kprobe_unwind_perl+0x3fc0>
    3fc0:      	cmpl	$0x0, (%rax)
    3fc3:      	je	0x1b7d <kprobe_unwind_perl+0x1b7d>
    3fc9:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3fd3:      	movq	%rax, 0x36(%rsp)
    3fd8:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    3fe2:      	movq	%rax, 0x30(%rsp)
    3fe7:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    3ff1:      	movq	%rax, 0x28(%rsp)
    3ff6:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4000:      	movq	%rax, 0x20(%rsp)
    4005:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    400f:      	movq	%rax, 0x18(%rsp)
    4014:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    401e:      	movq	%rax, 0x10(%rsp)
    4023:      	leaq	0x10(%rsp), %rdi
    4028:      	movl	$0x2e, %eax
    402d:      	movl	$0x6, %ecx
    4032:      	movl	0x74(%rsp), %edx
    4036:      	movl	$0x2e, %esi
    403b:      	jmp	0x41b3 <kprobe_unwind_perl+0x41b3>
    4040:      	movabsq	$0xa642520786978, %rax  # imm = 0xA642520786978
    404a:      	movq	%rax, 0x2e(%rsp)
    404f:      	movabsq	$0x697863202c786c25, %rax # imm = 0x697863202C786C25
    4059:      	movq	%rax, 0x28(%rsp)
    405e:      	movabsq	$0x7830206573616278, %rax # imm = 0x7830206573616278
    4068:      	movq	%rax, 0x20(%rsp)
    406d:      	movabsq	$0x63202c6f666e696b, %rax # imm = 0x63202C6F666E696B
    4077:      	movq	%rax, 0x18(%rsp)
    407c:      	movabsq	$0x636174732077654e, %rax # imm = 0x636174732077654E
    4086:      	movq	%rax, 0x10(%rsp)
    408b:      	leaq	0x10(%rsp), %rdi
    4090:      	movl	$0x26, %eax
    4095:      	movl	$0x6, %r8d
    409b:      	movq	0x50(%rsp), %rdx
    40a0:      	movl	0x78(%rsp), %ecx
    40a4:      	movl	$0x26, %esi
    40a9:      	xorl	%eax, %eax
    40ab:      	callq	*%r8
    40ae:      	jmp	0xf15 <kprobe_unwind_perl+0xf15>
    40b3:      	movq	(%rip), %rax            # 0x40ba <kprobe_unwind_perl+0x40ba>
    40ba:      	cmpl	$0x0, (%rax)
    40bd:      	jne	0x77e5 <kprobe_unwind_perl+0x77e5>
    40c3:      	movl	$0x3, %ebp
    40c8:      	jmp	0x428e <kprobe_unwind_perl+0x428e>
    40cd:      	movq	(%rip), %rax            # 0x40d4 <kprobe_unwind_perl+0x40d4>
    40d4:      	cmpl	$0x0, (%rax)
    40d7:      	je	0xec7 <kprobe_unwind_perl+0xec7>
    40dd:      	movabsq	$0xa782578302f78, %rax  # imm = 0xA782578302F78
    40e7:      	movq	%rax, 0x2e(%rsp)
    40ec:      	movabsq	$0x2f78257830207367, %rax # imm = 0x2F78257830207367
    40f6:      	movq	%rax, 0x28(%rsp)
    40fb:      	movabsq	$0x616c66202c564320, %rax # imm = 0x616C66202C564320
    4105:      	movq	%rax, 0x20(%rsp)
    410a:      	movabsq	$0x44454d414e206465, %rax # imm = 0x44454D414E206465
    4114:      	movq	%rax, 0x18(%rsp)
    4119:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    4123:      	movq	%rax, 0x10(%rsp)
    4128:      	leaq	0x10(%rsp), %rdi
    412d:      	movl	$0x26, %eax
    4132:      	movl	$0x6, %r8d
    4138:      	movl	0x5c(%rsp), %edx
    413c:      	movl	0x70(%rsp), %ecx
    4140:      	movl	$0x26, %esi
    4145:      	xorl	%eax, %eax
    4147:      	callq	*%r8
    414a:      	jmp	0xec7 <kprobe_unwind_perl+0xec7>
    414f:      	movq	(%rip), %rax            # 0x4156 <kprobe_unwind_perl+0x4156>
    4156:      	cmpl	$0x0, (%rax)
    4159:      	je	0x1b7d <kprobe_unwind_perl+0x1b7d>
    415f:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    4169:      	movq	%rax, 0x26(%rsp)
    416e:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    4178:      	movq	%rax, 0x20(%rsp)
    417d:      	movabsq	$0x5643565020612074, %rax # imm = 0x5643565020612074
    4187:      	movq	%rax, 0x18(%rsp)
    418c:      	movabsq	$0x6f6e207369205643, %rax # imm = 0x6F6E207369205643
    4196:      	movq	%rax, 0x10(%rsp)
    419b:      	leaq	0x10(%rsp), %rdi
    41a0:      	movl	$0x1e, %eax
    41a5:      	movl	$0x6, %ecx
    41aa:      	movl	0x5c(%rsp), %edx
    41ae:      	movl	$0x1e, %esi
    41b3:      	xorl	%eax, %eax
    41b5:      	callq	*%rcx
    41b7:      	jmp	0x1b7d <kprobe_unwind_perl+0x1b7d>
    41bc:      	movabsq	$0x7825783020786320, %rax # imm = 0x7825783020786320
    41c6:      	movq	%rax, 0x18(%rsp)
    41cb:      	movabsq	$0x6c72657020746f47, %rax # imm = 0x6C72657020746F47
    41d5:      	movq	%rax, 0x10(%rsp)
    41da:      	movw	$0xa, 0x20(%rsp)
    41e1:      	leaq	0x10(%rsp), %rdi
    41e6:      	movl	$0x12, %eax
    41eb:      	movl	$0x6, %ecx
    41f0:      	movzbl	0xe(%rsp), %edx
    41f5:      	movl	$0x12, %esi
    41fa:      	xorl	%eax, %eax
    41fc:      	callq	*%rcx
    41fe:      	jmp	0x11df <kprobe_unwind_perl+0x11df>
    4203:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    420d:      	movq	%rax, 0x36(%rsp)
    4212:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    421c:      	movq	%rax, 0x30(%rsp)
    4221:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    422b:      	movq	%rax, 0x28(%rsp)
    4230:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    423a:      	movq	%rax, 0x20(%rsp)
    423f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4249:      	movq	%rax, 0x18(%rsp)
    424e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4258:      	movq	%rax, 0x10(%rsp)
    425d:      	leaq	0x10(%rsp), %rdi
    4262:      	movl	$0x2e, %eax
    4267:      	movl	$0x6, %ecx
    426c:      	movl	0x50(%rsp), %edx
    4270:      	movl	$0x2e, %esi
    4275:      	xorl	%eax, %eax
    4277:      	callq	*%rcx
    4279:      	jmp	0x142e <kprobe_unwind_perl+0x142e>
    427e:      	cmpl	$0xc, %ecx
    4281:      	je	0x428e <kprobe_unwind_perl+0x428e>
    4283:      	cmpq	$0x0, (%r12)
    4288:      	je	0x6266 <kprobe_unwind_perl+0x6266>
    428e:      	movzbl	0x1d(%r14), %eax
    4293:      	subq	%rax, 0xf50(%r15)
    429a:      	movl	$0x10, 0x50(%rsp)
    42a2:      	movq	(%rip), %rdi            # 0x42a9 <kprobe_unwind_perl+0x42a9>
    42a9:      	leaq	0x50(%rsp), %rsi
    42ae:      	movl	$0x1, %eax
    42b3:      	callq	*%rax
    42b5:      	testq	%rax, %rax
    42b8:      	je	0x42cf <kprobe_unwind_perl+0x42cf>
    42ba:      	incq	(%rax)
    42bd:      	cmpl	$0x3, %ebp
    42c0:      	movq	0x98(%rsp), %rcx
    42c8:      	je	0x42f0 <kprobe_unwind_perl+0x42f0>
    42ca:      	jmp	0x5636 <kprobe_unwind_perl+0x5636>
    42cf:      	movq	(%rip), %rax            # 0x42d6 <kprobe_unwind_perl+0x42d6>
    42d6:      	cmpl	$0x0, (%rax)
    42d9:      	jne	0x7759 <kprobe_unwind_perl+0x7759>
    42df:      	cmpl	$0x3, %ebp
    42e2:      	movq	0x98(%rsp), %rcx
    42ea:      	jne	0x5636 <kprobe_unwind_perl+0x5636>
    42f0:      	movq	0xf50(%r15), %r13
    42f7:      	cmpq	%rcx, %r13
    42fa:      	jb	0x24e5 <kprobe_unwind_perl+0x24e5>
    4300:      	movzbl	0x19(%r14), %eax
    4305:      	addq	%r13, %rax
    4308:      	leaq	0xe(%rsp), %rdi
    430d:      	movl	$0x1, %ecx
    4312:      	movl	$0x70, %r8d
    4318:      	movzbl	0x19(%r14), %edx
    431d:      	addq	%r13, %rdx
    4320:      	movl	$0x1, %esi
    4325:      	callq	*%r8
    4328:      	testq	%rax, %rax
    432b:      	je	0x4815 <kprobe_unwind_perl+0x4815>
    4331:      	movq	(%rip), %rax            # 0x4338 <kprobe_unwind_perl+0x4338>
    4338:      	cmpl	$0x0, (%rax)
    433b:      	jne	0x7c16 <kprobe_unwind_perl+0x7c16>
    4341:      	movl	$0x13, 0x50(%rsp)
    4349:      	movq	(%rip), %rdi            # 0x4350 <kprobe_unwind_perl+0x4350>
    4350:      	leaq	0x50(%rsp), %rsi
    4355:      	movl	$0x1, %eax
    435a:      	callq	*%rax
    435c:      	testq	%rax, %rax
    435f:      	je	0x4a2c <kprobe_unwind_perl+0x4a2c>
    4365:      	incq	(%rax)
    4368:      	movl	$0x3, %ebp
    436d:      	jmp	0x4c07 <kprobe_unwind_perl+0x4c07>
    4372:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    437c:      	movq	%rax, 0x36(%rsp)
    4381:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    438b:      	movq	%rax, 0x30(%rsp)
    4390:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    439a:      	movq	%rax, 0x28(%rsp)
    439f:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    43a9:      	movq	%rax, 0x20(%rsp)
    43ae:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    43b8:      	movq	%rax, 0x18(%rsp)
    43bd:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    43c7:      	movq	%rax, 0x10(%rsp)
    43cc:      	leaq	0x10(%rsp), %rdi
    43d1:      	movl	$0x2e, %eax
    43d6:      	movl	$0x6, %ecx
    43db:      	movl	0x50(%rsp), %edx
    43df:      	movl	$0x2e, %esi
    43e4:      	xorl	%eax, %eax
    43e6:      	callq	*%rcx
    43e8:      	jmp	0x137b <kprobe_unwind_perl+0x137b>
    43ed:      	movabsq	$0xa7667655f7663, %rax  # imm = 0xA7667655F7663
    43f7:      	movq	%rax, 0x35(%rsp)
    43fc:      	movabsq	$0x5f76635f65766c6f, %rax # imm = 0x5F76635F65766C6F
    4406:      	movq	%rax, 0x30(%rsp)
    440b:      	movabsq	$0x736572206e692029, %rax # imm = 0x736572206E692029
    4415:      	movq	%rax, 0x28(%rsp)
    441a:      	movabsq	$0x28726573755f6461, %rax # imm = 0x28726573755F6461
    4424:      	movq	%rax, 0x20(%rsp)
    4429:      	movabsq	$0x65725f65626f7270, %rax # imm = 0x65725F65626F7270
    4433:      	movq	%rax, 0x18(%rsp)
    4438:      	movabsq	$0x5f66706220646142, %rax # imm = 0x5F66706220646142
    4442:      	movq	%rax, 0x10(%rsp)
    4447:      	leaq	0x10(%rsp), %rdi
    444c:      	movl	$0x2d, %eax
    4451:      	movl	$0x6, %ecx
    4456:      	movl	$0x2d, %esi
    445b:      	xorl	%eax, %eax
    445d:      	callq	*%rcx
    445f:      	jmp	0x9bd <kprobe_unwind_perl+0x9bd>
    4464:      	movl	0x5c(%rsp), %eax
    4468:      	andl	$0x1f, %eax
    446b:      	cmpl	$0xd, %eax
    446e:      	jne	0x4ac8 <kprobe_unwind_perl+0x4ac8>
    4474:      	movzbl	0x1f(%r14), %eax
    4479:      	addq	%rbp, %rax
    447c:      	leaq	0x50(%rsp), %rdi
    4481:      	movl	$0x8, %ecx
    4486:      	movl	$0x70, %r8d
    448c:      	movzbl	0x1f(%r14), %edx
    4491:      	addq	%rbp, %rdx
    4494:      	movl	$0x8, %esi
    4499:      	callq	*%r8
    449c:      	testq	%rax, %rax
    449f:      	jne	0x2af1 <kprobe_unwind_perl+0x2af1>
    44a5:      	movzbl	0x21(%r14), %eax
    44aa:      	addq	0x50(%rsp), %rax
    44af:      	leaq	0x70(%rsp), %rdi
    44b4:      	movl	$0x4, %ecx
    44b9:      	movl	$0x70, %r8d
    44bf:      	movzbl	0x21(%r14), %edx
    44c4:      	addq	0x50(%rsp), %rdx
    44c9:      	movl	$0x4, %esi
    44ce:      	callq	*%r8
    44d1:      	testq	%rax, %rax
    44d4:      	jne	0x2af1 <kprobe_unwind_perl+0x2af1>
    44da:      	testb	$-0x80, 0x71(%rsp)
    44df:      	jne	0x65f2 <kprobe_unwind_perl+0x65f2>
    44e5:      	movzbl	0x22(%r14), %eax
    44ea:      	addq	0x50(%rsp), %rax
    44ef:      	leaq	0x60(%rsp), %rbp
    44f4:      	movl	$0x8, %ecx
    44f9:      	movl	$0x70, %r8d
    44ff:      	movzbl	0x22(%r14), %edx
    4504:      	addq	0x50(%rsp), %rdx
    4509:      	movq	%rbp, %rdi
    450c:      	movl	$0x8, %esi
    4511:      	callq	*%r8
    4514:      	testq	%rax, %rax
    4517:      	jne	0x2af1 <kprobe_unwind_perl+0x2af1>
    451d:      	movq	0x60(%rsp), %rax
    4522:      	testq	%rax, %rax
    4525:      	je	0x2af1 <kprobe_unwind_perl+0x2af1>
    452b:      	movq	(%rip), %rcx            # 0x4532 <kprobe_unwind_perl+0x4532>
    4532:      	cmpl	$0x0, (%rcx)
    4535:      	jne	0x8ae9 <kprobe_unwind_perl+0x8ae9>
    453b:      	movzbl	0x1e(%r14), %ecx
    4540:      	addq	%rax, %rcx
    4543:      	leaq	0x6c(%rsp), %rdi
    4548:      	movl	$0x4, %eax
    454d:      	movl	$0x70, %r8d
    4553:      	movzbl	0x1e(%r14), %edx
    4558:      	addq	0x60(%rsp), %rdx
    455d:      	movl	$0x4, %esi
    4562:      	callq	*%r8
    4565:      	testq	%rax, %rax
    4568:      	jne	0x2af1 <kprobe_unwind_perl+0x2af1>
    456e:      	movl	$0x801f, %eax           # imm = 0x801F
    4573:      	andl	0x6c(%rsp), %eax
    4577:      	cmpl	$0x8009, %eax           # imm = 0x8009
    457c:      	jne	0x74d7 <kprobe_unwind_perl+0x74d7>
    4582:      	movzbl	0x20(%r14), %eax
    4587:      	addq	0x60(%rsp), %rax
    458c:      	leaq	0x88(%rsp), %rdi
    4594:      	movl	$0x8, %ecx
    4599:      	movl	$0x70, %r8d
    459f:      	movzbl	0x20(%r14), %edx
    45a4:      	addq	0x60(%rsp), %rdx
    45a9:      	movl	$0x8, %esi
    45ae:      	callq	*%r8
    45b1:      	testq	%rax, %rax
    45b4:      	jne	0x2af1 <kprobe_unwind_perl+0x2af1>
    45ba:      	movzbl	0x23(%r14), %eax
    45bf:      	addq	0x88(%rsp), %rax
    45c7:      	leaq	0x78(%rsp), %rdi
    45cc:      	movl	$0x8, %ecx
    45d1:      	movl	$0x70, %r8d
    45d7:      	movzbl	0x23(%r14), %edx
    45dc:      	addq	0x88(%rsp), %rdx
    45e4:      	movl	$0x8, %esi
    45e9:      	callq	*%r8
    45ec:      	testq	%rax, %rax
    45ef:      	jne	0x2af1 <kprobe_unwind_perl+0x2af1>
    45f5:      	movq	0x78(%rsp), %rax
    45fa:      	movq	%rax, 0x80(%rsp)
    4602:      	testq	%rax, %rax
    4605:      	je	0x465b <kprobe_unwind_perl+0x465b>
    4607:      	movq	(%rip), %rax            # 0x460e <kprobe_unwind_perl+0x460e>
    460e:      	cmpl	$0x0, (%rax)
    4611:      	je	0x4670 <kprobe_unwind_perl+0x4670>
    4613:      	movabsq	$0x2578302074612056, %rax # imm = 0x2578302074612056
    461d:      	movq	%rax, 0x18(%rsp)
    4622:      	movabsq	$0x474520646e756f46, %rax # imm = 0x474520646E756F46
    462c:      	movq	%rax, 0x10(%rsp)
    4631:      	movl	$0xa786c, 0x20(%rsp)    # imm = 0xA786C
    4639:      	leaq	0x10(%rsp), %rdi
    463e:      	movl	$0x14, %eax
    4643:      	movl	$0x6, %ecx
    4648:      	movq	0x78(%rsp), %rdx
    464d:      	movl	$0x14, %esi
    4652:      	xorl	%eax, %eax
    4654:      	callq	*%rcx
    4656:      	leaq	0x78(%rsp), %rbp
    465b:      	movq	(%rbp), %rax
    465f:      	movq	%rax, 0x80(%rsp)
    4667:      	testq	%rax, %rax
    466a:      	je	0x2528 <kprobe_unwind_perl+0x2528>
    4670:      	movq	(%r12), %rax
    4674:      	movq	%rax, 0x90(%rsp)
    467c:      	movq	(%rip), %rax            # 0x4683 <kprobe_unwind_perl+0x4683>
    4683:      	cmpl	$0x0, (%rax)
    4686:      	jne	0x8e4c <kprobe_unwind_perl+0x8e4c>
    468c:      	movl	0x2c0(%r15), %eax
    4693:      	cmpq	$0x7e, %rax
    4697:      	ja	0x1193 <kprobe_unwind_perl+0x1193>
    469d:      	xorl	%ecx, %ecx
    469f:      	movzbl	0xf(%rsp), %edx
    46a4:      	movb	%dl, %cl
    46a6:      	leal	0x1(,%rcx,2), %ebp
    46ad:      	leal	0x1(%rax), %ecx
    46b0:      	movl	%ecx, 0x2c0(%r15)
    46b7:      	leaq	(%rax,%rax,2), %rax
    46bb:      	movq	0x80(%rsp), %rcx
    46c3:      	movq	%rcx, 0x2d0(%r15,%rax,8)
    46cb:      	movq	0x90(%rsp), %rcx
    46d3:      	movq	%rcx, 0x2d8(%r15,%rax,8)
    46db:      	movb	$0x7, 0x2e0(%r15,%rax,8)
    46e4:      	movl	$0x0, 0x2e1(%r15,%rax,8)
    46f0:      	movl	$0x0, 0x2e4(%r15,%rax,8)
    46fc:      	movq	$0x0, 0xf40(%r15)
    4707:      	movzbl	0x1a(%r14), %eax
    470c:      	addq	%r13, %rax
    470f:      	movl	$0x8, %ecx
    4714:      	movl	$0x70, %r8d
    471a:      	movzbl	0x1a(%r14), %edx
    471f:      	addq	%r13, %rdx
    4722:      	movq	%r12, %rdi
    4725:      	movl	$0x8, %esi
    472a:      	callq	*%r8
    472d:      	testq	%rax, %rax
    4730:      	jne	0x2528 <kprobe_unwind_perl+0x2528>
    4736:      	movq	(%rip), %rax            # 0x473d <kprobe_unwind_perl+0x473d>
    473d:      	cmpl	$0x0, (%rax)
    4740:      	je	0x2d8f <kprobe_unwind_perl+0x2d8f>
    4746:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    4750:      	movq	%rax, 0x26(%rsp)
    4755:      	movabsq	$0x30206b6361747320, %rax # imm = 0x30206B6361747320
    475f:      	movq	%rax, 0x20(%rsp)
    4764:      	movabsq	$0x747865746e6f6320, %rax # imm = 0x747865746E6F6320
    476e:      	movq	%rax, 0x18(%rsp)
    4773:      	movabsq	$0x6d6f726620504f43, %rax # imm = 0x6D6F726620504F43
    477d:      	movq	%rax, 0x10(%rsp)
    4782:      	leaq	0x10(%rsp), %rdi
    4787:      	movl	$0x1e, %eax
    478c:      	movl	$0x6, %ecx
    4791:      	movq	(%r12), %rdx
    4795:      	movl	$0x1e, %esi
    479a:      	xorl	%eax, %eax
    479c:      	callq	*%rcx
    479e:      	jmp	0x2d8f <kprobe_unwind_perl+0x2d8f>
    47a3:      	movabsq	$0x7025207461207972, %rax # imm = 0x7025207461207972
    47ad:      	movq	%rax, 0x30(%rsp)
    47b2:      	movabsq	$0x746e65206b636174, %rax # imm = 0x746E65206B636174
    47bc:      	movq	%rax, 0x28(%rsp)
    47c1:      	movabsq	$0x7320747865746e6f, %rax # imm = 0x7320747865746E6F
    47cb:      	movq	%rax, 0x20(%rsp)
    47d0:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    47da:      	movq	%rax, 0x18(%rsp)
    47df:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    47e9:      	movq	%rax, 0x10(%rsp)
    47ee:      	movw	$0xa, 0x38(%rsp)
    47f5:      	leaq	0x10(%rsp), %rdi
    47fa:      	movl	$0x2a, %eax
    47ff:      	movl	$0x6, %ecx
    4804:      	movl	$0x2a, %esi
    4809:      	movq	%r13, %rdx
    480c:      	xorl	%eax, %eax
    480e:      	callq	*%rcx
    4810:      	jmp	0x14aa <kprobe_unwind_perl+0x14aa>
    4815:      	movq	(%rip), %rax            # 0x481c <kprobe_unwind_perl+0x481c>
    481c:      	cmpl	$0x0, (%rax)
    481f:      	jne	0x8020 <kprobe_unwind_perl+0x8020>
    4825:      	movzbl	0xe(%rsp), %eax
    482a:      	movl	%eax, %ecx
    482c:      	andl	$0xf, %ecx
    482f:      	movl	$0x3, %ebp
    4834:      	leal	-0x9(%rcx), %edx
    4837:      	cmpl	$0x2, %edx
    483a:      	jae	0x4bf7 <kprobe_unwind_perl+0x4bf7>
    4840:      	testb	%al, %al
    4842:      	js	0x4c07 <kprobe_unwind_perl+0x4c07>
    4848:      	movzbl	0x1b(%r14), %eax
    484d:      	addq	%r13, %rax
    4850:      	leaq	0x10(%rsp), %rdi
    4855:      	movl	$0x8, %ecx
    485a:      	movl	$0x70, %r8d
    4860:      	movzbl	0x1b(%r14), %edx
    4865:      	addq	%r13, %rdx
    4868:      	movl	$0x8, %esi
    486d:      	callq	*%r8
    4870:      	testq	%rax, %rax
    4873:      	jne	0x4331 <kprobe_unwind_perl+0x4331>
    4879:      	cmpq	$0x0, 0x10(%rsp)
    487f:      	setne	0xf(%rsp)
    4884:      	movzbl	0x1c(%r14), %eax
    4889:      	addq	%r13, %rax
    488c:      	leaq	0xa0(%rsp), %rdi
    4894:      	movl	$0x8, %ecx
    4899:      	movl	$0x70, %r8d
    489f:      	movzbl	0x1c(%r14), %edx
    48a4:      	addq	%r13, %rdx
    48a7:      	movl	$0x8, %esi
    48ac:      	callq	*%r8
    48af:      	testq	%rax, %rax
    48b2:      	jne	0x4331 <kprobe_unwind_perl+0x4331>
    48b8:      	movq	0xa0(%rsp), %rbp
    48c0:      	movzbl	0x1e(%r14), %eax
    48c5:      	addq	%rbp, %rax
    48c8:      	leaq	0x5c(%rsp), %rdi
    48cd:      	movl	$0x4, %ecx
    48d2:      	movl	$0x70, %r8d
    48d8:      	movzbl	0x1e(%r14), %edx
    48dd:      	addq	%rbp, %rdx
    48e0:      	movl	$0x4, %esi
    48e5:      	callq	*%r8
    48e8:      	testq	%rax, %rax
    48eb:      	je	0x6975 <kprobe_unwind_perl+0x6975>
    48f1:      	movq	(%rip), %rax            # 0x48f8 <kprobe_unwind_perl+0x48f8>
    48f8:      	cmpl	$0x0, (%rax)
    48fb:      	jne	0x896f <kprobe_unwind_perl+0x896f>
    4901:      	movl	$0x14, 0x74(%rsp)
    4909:      	movq	(%rip), %rdi            # 0x4910 <kprobe_unwind_perl+0x4910>
    4910:      	leaq	0x74(%rsp), %rsi
    4915:      	movl	$0x1, %eax
    491a:      	callq	*%rax
    491c:      	testq	%rax, %rax
    491f:      	je	0x6d9e <kprobe_unwind_perl+0x6d9e>
    4925:      	incq	(%rax)
    4928:      	jmp	0x4331 <kprobe_unwind_perl+0x4331>
    492d:      	movq	(%rip), %rax            # 0x4934 <kprobe_unwind_perl+0x4934>
    4934:      	cmpl	$0x0, (%rax)
    4937:      	je	0xb68 <kprobe_unwind_perl+0xb68>
    493d:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    4947:      	movq	%rax, 0x2e(%rsp)
    494c:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    4956:      	movq	%rax, 0x28(%rsp)
    495b:      	movabsq	$0x50472d74756f6874, %rax # imm = 0x50472D74756F6874
    4965:      	movq	%rax, 0x20(%rsp)
    496a:      	movabsq	$0x69772d5647206465, %rax # imm = 0x69772D5647206465
    4974:      	movq	%rax, 0x18(%rsp)
    4979:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    4983:      	movq	%rax, 0x10(%rsp)
    4988:      	leaq	0x10(%rsp), %rdi
    498d:      	movl	$0x26, %eax
    4992:      	movl	$0x6, %ecx
    4997:      	movl	0x6c(%rsp), %edx
    499b:      	movl	$0x26, %esi
    49a0:      	jmp	0x239c <kprobe_unwind_perl+0x239c>
    49a5:      	movq	(%rip), %rax            # 0x49ac <kprobe_unwind_perl+0x49ac>
    49ac:      	cmpl	$0x0, (%rax)
    49af:      	je	0x2528 <kprobe_unwind_perl+0x2528>
    49b5:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    49bf:      	movq	%rax, 0x36(%rsp)
    49c4:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    49ce:      	movq	%rax, 0x30(%rsp)
    49d3:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    49dd:      	movq	%rax, 0x28(%rsp)
    49e2:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    49ec:      	movq	%rax, 0x20(%rsp)
    49f1:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    49fb:      	movq	%rax, 0x18(%rsp)
    4a00:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4a0a:      	movq	%rax, 0x10(%rsp)
    4a0f:      	leaq	0x10(%rsp), %rdi
    4a14:      	movl	$0x2e, %eax
    4a19:      	movl	$0x6, %ecx
    4a1e:      	movl	0x74(%rsp), %edx
    4a22:      	movl	$0x2e, %esi
    4a27:      	jmp	0x4b2c <kprobe_unwind_perl+0x4b2c>
    4a2c:      	movq	(%rip), %rax            # 0x4a33 <kprobe_unwind_perl+0x4a33>
    4a33:      	cmpl	$0x0, (%rax)
    4a36:      	jne	0x80f3 <kprobe_unwind_perl+0x80f3>
    4a3c:      	movl	$0x3, %ebp
    4a41:      	jmp	0x4c07 <kprobe_unwind_perl+0x4c07>
    4a46:      	movq	(%rip), %rax            # 0x4a4d <kprobe_unwind_perl+0x4a4d>
    4a4d:      	cmpl	$0x0, (%rax)
    4a50:      	je	0x149a <kprobe_unwind_perl+0x149a>
    4a56:      	movabsq	$0xa782578302f78, %rax  # imm = 0xA782578302F78
    4a60:      	movq	%rax, 0x2e(%rsp)
    4a65:      	movabsq	$0x2f78257830207367, %rax # imm = 0x2F78257830207367
    4a6f:      	movq	%rax, 0x28(%rsp)
    4a74:      	movabsq	$0x616c66202c564320, %rax # imm = 0x616C66202C564320
    4a7e:      	movq	%rax, 0x20(%rsp)
    4a83:      	movabsq	$0x44454d414e206465, %rax # imm = 0x44454D414E206465
    4a8d:      	movq	%rax, 0x18(%rsp)
    4a92:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    4a9c:      	movq	%rax, 0x10(%rsp)
    4aa1:      	leaq	0x10(%rsp), %rdi
    4aa6:      	movl	$0x26, %eax
    4aab:      	movl	$0x6, %r8d
    4ab1:      	movl	0x5c(%rsp), %edx
    4ab5:      	movl	0x70(%rsp), %ecx
    4ab9:      	movl	$0x26, %esi
    4abe:      	xorl	%eax, %eax
    4ac0:      	callq	*%r8
    4ac3:      	jmp	0x149a <kprobe_unwind_perl+0x149a>
    4ac8:      	movq	(%rip), %rax            # 0x4acf <kprobe_unwind_perl+0x4acf>
    4acf:      	cmpl	$0x0, (%rax)
    4ad2:      	je	0x2528 <kprobe_unwind_perl+0x2528>
    4ad8:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    4ae2:      	movq	%rax, 0x26(%rsp)
    4ae7:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    4af1:      	movq	%rax, 0x20(%rsp)
    4af6:      	movabsq	$0x5643565020612074, %rax # imm = 0x5643565020612074
    4b00:      	movq	%rax, 0x18(%rsp)
    4b05:      	movabsq	$0x6f6e207369205643, %rax # imm = 0x6F6E207369205643
    4b0f:      	movq	%rax, 0x10(%rsp)
    4b14:      	leaq	0x10(%rsp), %rdi
    4b19:      	movl	$0x1e, %eax
    4b1e:      	movl	$0x6, %ecx
    4b23:      	movl	0x5c(%rsp), %edx
    4b27:      	movl	$0x1e, %esi
    4b2c:      	xorl	%eax, %eax
    4b2e:      	callq	*%rcx
    4b30:      	jmp	0x2528 <kprobe_unwind_perl+0x2528>
    4b35:      	movabsq	$0x7825783020786320, %rax # imm = 0x7825783020786320
    4b3f:      	movq	%rax, 0x18(%rsp)
    4b44:      	movabsq	$0x6c72657020746f47, %rax # imm = 0x6C72657020746F47
    4b4e:      	movq	%rax, 0x10(%rsp)
    4b53:      	movw	$0xa, 0x20(%rsp)
    4b5a:      	leaq	0x10(%rsp), %rdi
    4b5f:      	movl	$0x12, %eax
    4b64:      	movl	$0x6, %ecx
    4b69:      	movzbl	0xe(%rsp), %edx
    4b6e:      	movl	$0x12, %esi
    4b73:      	xorl	%eax, %eax
    4b75:      	callq	*%rcx
    4b77:      	jmp	0x18c2 <kprobe_unwind_perl+0x18c2>
    4b7c:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4b86:      	movq	%rax, 0x36(%rsp)
    4b8b:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4b95:      	movq	%rax, 0x30(%rsp)
    4b9a:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4ba4:      	movq	%rax, 0x28(%rsp)
    4ba9:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4bb3:      	movq	%rax, 0x20(%rsp)
    4bb8:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4bc2:      	movq	%rax, 0x18(%rsp)
    4bc7:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4bd1:      	movq	%rax, 0x10(%rsp)
    4bd6:      	leaq	0x10(%rsp), %rdi
    4bdb:      	movl	$0x2e, %eax
    4be0:      	movl	$0x6, %ecx
    4be5:      	movl	0x50(%rsp), %edx
    4be9:      	movl	$0x2e, %esi
    4bee:      	xorl	%eax, %eax
    4bf0:      	callq	*%rcx
    4bf2:      	jmp	0x1b11 <kprobe_unwind_perl+0x1b11>
    4bf7:      	cmpl	$0xc, %ecx
    4bfa:      	je	0x4c07 <kprobe_unwind_perl+0x4c07>
    4bfc:      	cmpq	$0x0, (%r12)
    4c01:      	je	0x6c18 <kprobe_unwind_perl+0x6c18>
    4c07:      	movzbl	0x1d(%r14), %eax
    4c0c:      	subq	%rax, 0xf50(%r15)
    4c13:      	movl	$0x10, 0x50(%rsp)
    4c1b:      	movq	(%rip), %rdi            # 0x4c22 <kprobe_unwind_perl+0x4c22>
    4c22:      	leaq	0x50(%rsp), %rsi
    4c27:      	movl	$0x1, %eax
    4c2c:      	callq	*%rax
    4c2e:      	testq	%rax, %rax
    4c31:      	je	0x4c48 <kprobe_unwind_perl+0x4c48>
    4c33:      	incq	(%rax)
    4c36:      	cmpl	$0x3, %ebp
    4c39:      	movq	0x98(%rsp), %rcx
    4c41:      	je	0x4c69 <kprobe_unwind_perl+0x4c69>
    4c43:      	jmp	0x5636 <kprobe_unwind_perl+0x5636>
    4c48:      	movq	(%rip), %rax            # 0x4c4f <kprobe_unwind_perl+0x4c4f>
    4c4f:      	cmpl	$0x0, (%rax)
    4c52:      	jne	0x8067 <kprobe_unwind_perl+0x8067>
    4c58:      	cmpl	$0x3, %ebp
    4c5b:      	movq	0x98(%rsp), %rcx
    4c63:      	jne	0x5636 <kprobe_unwind_perl+0x5636>
    4c69:      	movq	0xf50(%r15), %r13
    4c70:      	cmpq	%rcx, %r13
    4c73:      	jb	0x24e5 <kprobe_unwind_perl+0x24e5>
    4c79:      	movzbl	0x19(%r14), %eax
    4c7e:      	addq	%r13, %rax
    4c81:      	leaq	0xe(%rsp), %rdi
    4c86:      	movl	$0x1, %ecx
    4c8b:      	movl	$0x70, %r8d
    4c91:      	movzbl	0x19(%r14), %edx
    4c96:      	addq	%r13, %rdx
    4c99:      	movl	$0x1, %esi
    4c9e:      	callq	*%r8
    4ca1:      	testq	%rax, %rax
    4ca4:      	je	0x51c3 <kprobe_unwind_perl+0x51c3>
    4caa:      	movq	(%rip), %rax            # 0x4cb1 <kprobe_unwind_perl+0x4cb1>
    4cb1:      	cmpl	$0x0, (%rax)
    4cb4:      	jne	0x81e5 <kprobe_unwind_perl+0x81e5>
    4cba:      	movl	$0x13, 0x50(%rsp)
    4cc2:      	movq	(%rip), %rdi            # 0x4cc9 <kprobe_unwind_perl+0x4cc9>
    4cc9:      	leaq	0x50(%rsp), %rsi
    4cce:      	movl	$0x1, %eax
    4cd3:      	callq	*%rax
    4cd5:      	testq	%rax, %rax
    4cd8:      	je	0x53da <kprobe_unwind_perl+0x53da>
    4cde:      	incq	(%rax)
    4ce1:      	movl	$0x3, %ebp
    4ce6:      	jmp	0x55c6 <kprobe_unwind_perl+0x55c6>
    4ceb:      	movq	(%rip), %rax            # 0x4cf2 <kprobe_unwind_perl+0x4cf2>
    4cf2:      	cmpl	$0x0, (%rax)
    4cf5:      	jne	0x82cf <kprobe_unwind_perl+0x82cf>
    4cfb:      	movzbl	0x1d(%r14), %ecx
    4d00:      	movq	0xf50(%r15), %rax
    4d07:      	subq	%rcx, %rax
    4d0a:      	movq	%rax, 0xf50(%r15)
    4d11:      	xorl	%ebp, %ebp
    4d13:      	movq	0x98(%rsp), %rcx
    4d1b:      	jmp	0x563d <kprobe_unwind_perl+0x563d>
    4d20:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4d2a:      	movq	%rax, 0x36(%rsp)
    4d2f:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4d39:      	movq	%rax, 0x30(%rsp)
    4d3e:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4d48:      	movq	%rax, 0x28(%rsp)
    4d4d:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4d57:      	movq	%rax, 0x20(%rsp)
    4d5c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4d66:      	movq	%rax, 0x18(%rsp)
    4d6b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4d75:      	movq	%rax, 0x10(%rsp)
    4d7a:      	leaq	0x10(%rsp), %rdi
    4d7f:      	movl	$0x2e, %eax
    4d84:      	movl	$0x6, %ecx
    4d89:      	movl	0x50(%rsp), %edx
    4d8d:      	movl	$0x2e, %esi
    4d92:      	xorl	%eax, %eax
    4d94:      	callq	*%rcx
    4d96:      	jmp	0x1a5e <kprobe_unwind_perl+0x1a5e>
    4d9b:      	movabsq	$0xa7667655f7663, %rax  # imm = 0xA7667655F7663
    4da5:      	movq	%rax, 0x35(%rsp)
    4daa:      	movabsq	$0x5f76635f65766c6f, %rax # imm = 0x5F76635F65766C6F
    4db4:      	movq	%rax, 0x30(%rsp)
    4db9:      	movabsq	$0x736572206e692029, %rax # imm = 0x736572206E692029
    4dc3:      	movq	%rax, 0x28(%rsp)
    4dc8:      	movabsq	$0x28726573755f6461, %rax # imm = 0x28726573755F6461
    4dd2:      	movq	%rax, 0x20(%rsp)
    4dd7:      	movabsq	$0x65725f65626f7270, %rax # imm = 0x65725F65626F7270
    4de1:      	movq	%rax, 0x18(%rsp)
    4de6:      	movabsq	$0x5f66706220646142, %rax # imm = 0x5F66706220646142
    4df0:      	movq	%rax, 0x10(%rsp)
    4df5:      	leaq	0x10(%rsp), %rdi
    4dfa:      	movl	$0x2d, %eax
    4dff:      	movl	$0x6, %ecx
    4e04:      	movl	$0x2d, %esi
    4e09:      	xorl	%eax, %eax
    4e0b:      	callq	*%rcx
    4e0d:      	jmp	0xd4e <kprobe_unwind_perl+0xd4e>
    4e12:      	movl	0x5c(%rsp), %eax
    4e16:      	andl	$0x1f, %eax
    4e19:      	cmpl	$0xd, %eax
    4e1c:      	jne	0x5476 <kprobe_unwind_perl+0x5476>
    4e22:      	movzbl	0x1f(%r14), %eax
    4e27:      	addq	%rbp, %rax
    4e2a:      	leaq	0x50(%rsp), %rdi
    4e2f:      	movl	$0x8, %ecx
    4e34:      	movl	$0x70, %r8d
    4e3a:      	movzbl	0x1f(%r14), %edx
    4e3f:      	addq	%rbp, %rdx
    4e42:      	movl	$0x8, %esi
    4e47:      	callq	*%r8
    4e4a:      	testq	%rax, %rax
    4e4d:      	jne	0x3511 <kprobe_unwind_perl+0x3511>
    4e53:      	movzbl	0x21(%r14), %eax
    4e58:      	addq	0x50(%rsp), %rax
    4e5d:      	leaq	0x70(%rsp), %rdi
    4e62:      	movl	$0x4, %ecx
    4e67:      	movl	$0x70, %r8d
    4e6d:      	movzbl	0x21(%r14), %edx
    4e72:      	addq	0x50(%rsp), %rdx
    4e77:      	movl	$0x4, %esi
    4e7c:      	callq	*%r8
    4e7f:      	testq	%rax, %rax
    4e82:      	jne	0x3511 <kprobe_unwind_perl+0x3511>
    4e88:      	testb	$-0x80, 0x71(%rsp)
    4e8d:      	jne	0x6e72 <kprobe_unwind_perl+0x6e72>
    4e93:      	movzbl	0x22(%r14), %eax
    4e98:      	addq	0x50(%rsp), %rax
    4e9d:      	leaq	0x60(%rsp), %rbp
    4ea2:      	movl	$0x8, %ecx
    4ea7:      	movl	$0x70, %r8d
    4ead:      	movzbl	0x22(%r14), %edx
    4eb2:      	addq	0x50(%rsp), %rdx
    4eb7:      	movq	%rbp, %rdi
    4eba:      	movl	$0x8, %esi
    4ebf:      	callq	*%r8
    4ec2:      	testq	%rax, %rax
    4ec5:      	jne	0x3511 <kprobe_unwind_perl+0x3511>
    4ecb:      	movq	0x60(%rsp), %rax
    4ed0:      	testq	%rax, %rax
    4ed3:      	je	0x3511 <kprobe_unwind_perl+0x3511>
    4ed9:      	movq	(%rip), %rcx            # 0x4ee0 <kprobe_unwind_perl+0x4ee0>
    4ee0:      	cmpl	$0x0, (%rcx)
    4ee3:      	jne	0x8cb0 <kprobe_unwind_perl+0x8cb0>
    4ee9:      	movzbl	0x1e(%r14), %ecx
    4eee:      	addq	%rax, %rcx
    4ef1:      	leaq	0x6c(%rsp), %rdi
    4ef6:      	movl	$0x4, %eax
    4efb:      	movl	$0x70, %r8d
    4f01:      	movzbl	0x1e(%r14), %edx
    4f06:      	addq	0x60(%rsp), %rdx
    4f0b:      	movl	$0x4, %esi
    4f10:      	callq	*%r8
    4f13:      	testq	%rax, %rax
    4f16:      	jne	0x3511 <kprobe_unwind_perl+0x3511>
    4f1c:      	movl	$0x801f, %eax           # imm = 0x801F
    4f21:      	andl	0x6c(%rsp), %eax
    4f25:      	cmpl	$0x8009, %eax           # imm = 0x8009
    4f2a:      	jne	0x7c88 <kprobe_unwind_perl+0x7c88>
    4f30:      	movzbl	0x20(%r14), %eax
    4f35:      	addq	0x60(%rsp), %rax
    4f3a:      	leaq	0x88(%rsp), %rdi
    4f42:      	movl	$0x8, %ecx
    4f47:      	movl	$0x70, %r8d
    4f4d:      	movzbl	0x20(%r14), %edx
    4f52:      	addq	0x60(%rsp), %rdx
    4f57:      	movl	$0x8, %esi
    4f5c:      	callq	*%r8
    4f5f:      	testq	%rax, %rax
    4f62:      	jne	0x3511 <kprobe_unwind_perl+0x3511>
    4f68:      	movzbl	0x23(%r14), %eax
    4f6d:      	addq	0x88(%rsp), %rax
    4f75:      	leaq	0x78(%rsp), %rdi
    4f7a:      	movl	$0x8, %ecx
    4f7f:      	movl	$0x70, %r8d
    4f85:      	movzbl	0x23(%r14), %edx
    4f8a:      	addq	0x88(%rsp), %rdx
    4f92:      	movl	$0x8, %esi
    4f97:      	callq	*%r8
    4f9a:      	testq	%rax, %rax
    4f9d:      	jne	0x3511 <kprobe_unwind_perl+0x3511>
    4fa3:      	movq	0x78(%rsp), %rax
    4fa8:      	movq	%rax, 0x80(%rsp)
    4fb0:      	testq	%rax, %rax
    4fb3:      	je	0x5009 <kprobe_unwind_perl+0x5009>
    4fb5:      	movq	(%rip), %rax            # 0x4fbc <kprobe_unwind_perl+0x4fbc>
    4fbc:      	cmpl	$0x0, (%rax)
    4fbf:      	je	0x501e <kprobe_unwind_perl+0x501e>
    4fc1:      	movabsq	$0x2578302074612056, %rax # imm = 0x2578302074612056
    4fcb:      	movq	%rax, 0x18(%rsp)
    4fd0:      	movabsq	$0x474520646e756f46, %rax # imm = 0x474520646E756F46
    4fda:      	movq	%rax, 0x10(%rsp)
    4fdf:      	movl	$0xa786c, 0x20(%rsp)    # imm = 0xA786C
    4fe7:      	leaq	0x10(%rsp), %rdi
    4fec:      	movl	$0x14, %eax
    4ff1:      	movl	$0x6, %ecx
    4ff6:      	movq	0x78(%rsp), %rdx
    4ffb:      	movl	$0x14, %esi
    5000:      	xorl	%eax, %eax
    5002:      	callq	*%rcx
    5004:      	leaq	0x78(%rsp), %rbp
    5009:      	movq	(%rbp), %rax
    500d:      	movq	%rax, 0x80(%rsp)
    5015:      	testq	%rax, %rax
    5018:      	je	0x2e32 <kprobe_unwind_perl+0x2e32>
    501e:      	movq	(%r12), %rax
    5022:      	movq	%rax, 0x90(%rsp)
    502a:      	movq	(%rip), %rax            # 0x5031 <kprobe_unwind_perl+0x5031>
    5031:      	cmpl	$0x0, (%rax)
    5034:      	jne	0x8f24 <kprobe_unwind_perl+0x8f24>
    503a:      	movl	0x2c0(%r15), %eax
    5041:      	cmpq	$0x7e, %rax
    5045:      	ja	0x1193 <kprobe_unwind_perl+0x1193>
    504b:      	xorl	%ecx, %ecx
    504d:      	movzbl	0xf(%rsp), %edx
    5052:      	movb	%dl, %cl
    5054:      	leal	0x1(,%rcx,2), %ebp
    505b:      	leal	0x1(%rax), %ecx
    505e:      	movl	%ecx, 0x2c0(%r15)
    5065:      	leaq	(%rax,%rax,2), %rax
    5069:      	movq	0x80(%rsp), %rcx
    5071:      	movq	%rcx, 0x2d0(%r15,%rax,8)
    5079:      	movq	0x90(%rsp), %rcx
    5081:      	movq	%rcx, 0x2d8(%r15,%rax,8)
    5089:      	movb	$0x7, 0x2e0(%r15,%rax,8)
    5092:      	movl	$0x0, 0x2e1(%r15,%rax,8)
    509e:      	movl	$0x0, 0x2e4(%r15,%rax,8)
    50aa:      	movq	$0x0, 0xf40(%r15)
    50b5:      	movzbl	0x1a(%r14), %eax
    50ba:      	addq	%r13, %rax
    50bd:      	movl	$0x8, %ecx
    50c2:      	movl	$0x70, %r8d
    50c8:      	movzbl	0x1a(%r14), %edx
    50cd:      	addq	%r13, %rdx
    50d0:      	movq	%r12, %rdi
    50d3:      	movl	$0x8, %esi
    50d8:      	callq	*%r8
    50db:      	testq	%rax, %rax
    50de:      	jne	0x2e32 <kprobe_unwind_perl+0x2e32>
    50e4:      	movq	(%rip), %rax            # 0x50eb <kprobe_unwind_perl+0x50eb>
    50eb:      	cmpl	$0x0, (%rax)
    50ee:      	je	0x38a2 <kprobe_unwind_perl+0x38a2>
    50f4:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    50fe:      	movq	%rax, 0x26(%rsp)
    5103:      	movabsq	$0x30206b6361747320, %rax # imm = 0x30206B6361747320
    510d:      	movq	%rax, 0x20(%rsp)
    5112:      	movabsq	$0x747865746e6f6320, %rax # imm = 0x747865746E6F6320
    511c:      	movq	%rax, 0x18(%rsp)
    5121:      	movabsq	$0x6d6f726620504f43, %rax # imm = 0x6D6F726620504F43
    512b:      	movq	%rax, 0x10(%rsp)
    5130:      	leaq	0x10(%rsp), %rdi
    5135:      	movl	$0x1e, %eax
    513a:      	movl	$0x6, %ecx
    513f:      	movq	(%r12), %rdx
    5143:      	movl	$0x1e, %esi
    5148:      	xorl	%eax, %eax
    514a:      	callq	*%rcx
    514c:      	jmp	0x38a2 <kprobe_unwind_perl+0x38a2>
    5151:      	movabsq	$0x7025207461207972, %rax # imm = 0x7025207461207972
    515b:      	movq	%rax, 0x30(%rsp)
    5160:      	movabsq	$0x746e65206b636174, %rax # imm = 0x746E65206B636174
    516a:      	movq	%rax, 0x28(%rsp)
    516f:      	movabsq	$0x7320747865746e6f, %rax # imm = 0x7320747865746E6F
    5179:      	movq	%rax, 0x20(%rsp)
    517e:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    5188:      	movq	%rax, 0x18(%rsp)
    518d:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5197:      	movq	%rax, 0x10(%rsp)
    519c:      	movw	$0xa, 0x38(%rsp)
    51a3:      	leaq	0x10(%rsp), %rdi
    51a8:      	movl	$0x2a, %eax
    51ad:      	movl	$0x6, %ecx
    51b2:      	movl	$0x2a, %esi
    51b7:      	movq	%r13, %rdx
    51ba:      	xorl	%eax, %eax
    51bc:      	callq	*%rcx
    51be:      	jmp	0x1b8d <kprobe_unwind_perl+0x1b8d>
    51c3:      	movq	(%rip), %rax            # 0x51ca <kprobe_unwind_perl+0x51ca>
    51ca:      	cmpl	$0x0, (%rax)
    51cd:      	jne	0x84a4 <kprobe_unwind_perl+0x84a4>
    51d3:      	movzbl	0xe(%rsp), %eax
    51d8:      	movl	%eax, %ecx
    51da:      	andl	$0xf, %ecx
    51dd:      	movl	$0x3, %ebp
    51e2:      	leal	-0x9(%rcx), %edx
    51e5:      	cmpl	$0x2, %edx
    51e8:      	jae	0x55b6 <kprobe_unwind_perl+0x55b6>
    51ee:      	testb	%al, %al
    51f0:      	js	0x55c6 <kprobe_unwind_perl+0x55c6>
    51f6:      	movzbl	0x1b(%r14), %eax
    51fb:      	addq	%r13, %rax
    51fe:      	leaq	0x10(%rsp), %rdi
    5203:      	movl	$0x8, %ecx
    5208:      	movl	$0x70, %r8d
    520e:      	movzbl	0x1b(%r14), %edx
    5213:      	addq	%r13, %rdx
    5216:      	movl	$0x8, %esi
    521b:      	callq	*%r8
    521e:      	testq	%rax, %rax
    5221:      	jne	0x4caa <kprobe_unwind_perl+0x4caa>
    5227:      	cmpq	$0x0, 0x10(%rsp)
    522d:      	setne	0xf(%rsp)
    5232:      	movzbl	0x1c(%r14), %eax
    5237:      	addq	%r13, %rax
    523a:      	leaq	0xa0(%rsp), %rdi
    5242:      	movl	$0x8, %ecx
    5247:      	movl	$0x70, %r8d
    524d:      	movzbl	0x1c(%r14), %edx
    5252:      	addq	%r13, %rdx
    5255:      	movl	$0x8, %esi
    525a:      	callq	*%r8
    525d:      	testq	%rax, %rax
    5260:      	jne	0x4caa <kprobe_unwind_perl+0x4caa>
    5266:      	movq	0xa0(%rsp), %rbp
    526e:      	movzbl	0x1e(%r14), %eax
    5273:      	addq	%rbp, %rax
    5276:      	leaq	0x5c(%rsp), %rdi
    527b:      	movl	$0x4, %ecx
    5280:      	movl	$0x70, %r8d
    5286:      	movzbl	0x1e(%r14), %edx
    528b:      	addq	%rbp, %rdx
    528e:      	movl	$0x4, %esi
    5293:      	callq	*%r8
    5296:      	testq	%rax, %rax
    5299:      	je	0x7126 <kprobe_unwind_perl+0x7126>
    529f:      	movq	(%rip), %rax            # 0x52a6 <kprobe_unwind_perl+0x52a6>
    52a6:      	cmpl	$0x0, (%rax)
    52a9:      	jne	0x8b36 <kprobe_unwind_perl+0x8b36>
    52af:      	movl	$0x14, 0x74(%rsp)
    52b7:      	movq	(%rip), %rdi            # 0x52be <kprobe_unwind_perl+0x52be>
    52be:      	leaq	0x74(%rsp), %rsi
    52c3:      	movl	$0x1, %eax
    52c8:      	callq	*%rax
    52ca:      	testq	%rax, %rax
    52cd:      	je	0x754f <kprobe_unwind_perl+0x754f>
    52d3:      	incq	(%rax)
    52d6:      	jmp	0x4caa <kprobe_unwind_perl+0x4caa>
    52db:      	movq	(%rip), %rax            # 0x52e2 <kprobe_unwind_perl+0x52e2>
    52e2:      	cmpl	$0x0, (%rax)
    52e5:      	je	0xec7 <kprobe_unwind_perl+0xec7>
    52eb:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    52f5:      	movq	%rax, 0x2e(%rsp)
    52fa:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    5304:      	movq	%rax, 0x28(%rsp)
    5309:      	movabsq	$0x50472d74756f6874, %rax # imm = 0x50472D74756F6874
    5313:      	movq	%rax, 0x20(%rsp)
    5318:      	movabsq	$0x69772d5647206465, %rax # imm = 0x69772D5647206465
    5322:      	movq	%rax, 0x18(%rsp)
    5327:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    5331:      	movq	%rax, 0x10(%rsp)
    5336:      	leaq	0x10(%rsp), %rdi
    533b:      	movl	$0x26, %eax
    5340:      	movl	$0x6, %ecx
    5345:      	movl	0x6c(%rsp), %edx
    5349:      	movl	$0x26, %esi
    534e:      	jmp	0x2cb4 <kprobe_unwind_perl+0x2cb4>
    5353:      	movq	(%rip), %rax            # 0x535a <kprobe_unwind_perl+0x535a>
    535a:      	cmpl	$0x0, (%rax)
    535d:      	je	0x2e32 <kprobe_unwind_perl+0x2e32>
    5363:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    536d:      	movq	%rax, 0x36(%rsp)
    5372:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    537c:      	movq	%rax, 0x30(%rsp)
    5381:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    538b:      	movq	%rax, 0x28(%rsp)
    5390:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    539a:      	movq	%rax, 0x20(%rsp)
    539f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    53a9:      	movq	%rax, 0x18(%rsp)
    53ae:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    53b8:      	movq	%rax, 0x10(%rsp)
    53bd:      	leaq	0x10(%rsp), %rdi
    53c2:      	movl	$0x2e, %eax
    53c7:      	movl	$0x6, %ecx
    53cc:      	movl	0x74(%rsp), %edx
    53d0:      	movl	$0x2e, %esi
    53d5:      	jmp	0x54da <kprobe_unwind_perl+0x54da>
    53da:      	movq	(%rip), %rax            # 0x53e1 <kprobe_unwind_perl+0x53e1>
    53e1:      	cmpl	$0x0, (%rax)
    53e4:      	jne	0x8577 <kprobe_unwind_perl+0x8577>
    53ea:      	movl	$0x3, %ebp
    53ef:      	jmp	0x55c6 <kprobe_unwind_perl+0x55c6>
    53f4:      	movq	(%rip), %rax            # 0x53fb <kprobe_unwind_perl+0x53fb>
    53fb:      	cmpl	$0x0, (%rax)
    53fe:      	je	0x1b7d <kprobe_unwind_perl+0x1b7d>
    5404:      	movabsq	$0xa782578302f78, %rax  # imm = 0xA782578302F78
    540e:      	movq	%rax, 0x2e(%rsp)
    5413:      	movabsq	$0x2f78257830207367, %rax # imm = 0x2F78257830207367
    541d:      	movq	%rax, 0x28(%rsp)
    5422:      	movabsq	$0x616c66202c564320, %rax # imm = 0x616C66202C564320
    542c:      	movq	%rax, 0x20(%rsp)
    5431:      	movabsq	$0x44454d414e206465, %rax # imm = 0x44454D414E206465
    543b:      	movq	%rax, 0x18(%rsp)
    5440:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    544a:      	movq	%rax, 0x10(%rsp)
    544f:      	leaq	0x10(%rsp), %rdi
    5454:      	movl	$0x26, %eax
    5459:      	movl	$0x6, %r8d
    545f:      	movl	0x5c(%rsp), %edx
    5463:      	movl	0x70(%rsp), %ecx
    5467:      	movl	$0x26, %esi
    546c:      	xorl	%eax, %eax
    546e:      	callq	*%r8
    5471:      	jmp	0x1b7d <kprobe_unwind_perl+0x1b7d>
    5476:      	movq	(%rip), %rax            # 0x547d <kprobe_unwind_perl+0x547d>
    547d:      	cmpl	$0x0, (%rax)
    5480:      	je	0x2e32 <kprobe_unwind_perl+0x2e32>
    5486:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    5490:      	movq	%rax, 0x26(%rsp)
    5495:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    549f:      	movq	%rax, 0x20(%rsp)
    54a4:      	movabsq	$0x5643565020612074, %rax # imm = 0x5643565020612074
    54ae:      	movq	%rax, 0x18(%rsp)
    54b3:      	movabsq	$0x6f6e207369205643, %rax # imm = 0x6F6E207369205643
    54bd:      	movq	%rax, 0x10(%rsp)
    54c2:      	leaq	0x10(%rsp), %rdi
    54c7:      	movl	$0x1e, %eax
    54cc:      	movl	$0x6, %ecx
    54d1:      	movl	0x5c(%rsp), %edx
    54d5:      	movl	$0x1e, %esi
    54da:      	xorl	%eax, %eax
    54dc:      	callq	*%rcx
    54de:      	jmp	0x2e32 <kprobe_unwind_perl+0x2e32>
    54e3:      	movabsq	$0x7825783020786320, %rax # imm = 0x7825783020786320
    54ed:      	movq	%rax, 0x18(%rsp)
    54f2:      	movabsq	$0x6c72657020746f47, %rax # imm = 0x6C72657020746F47
    54fc:      	movq	%rax, 0x10(%rsp)
    5501:      	movw	$0xa, 0x20(%rsp)
    5508:      	leaq	0x10(%rsp), %rdi
    550d:      	movl	$0x12, %eax
    5512:      	movl	$0x6, %ecx
    5517:      	movzbl	0xe(%rsp), %edx
    551c:      	movl	$0x12, %esi
    5521:      	xorl	%eax, %eax
    5523:      	callq	*%rcx
    5525:      	jmp	0x1f7f <kprobe_unwind_perl+0x1f7f>
    552a:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    5534:      	movq	%rax, 0x36(%rsp)
    5539:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    5543:      	movq	%rax, 0x30(%rsp)
    5548:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    5552:      	movq	%rax, 0x28(%rsp)
    5557:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    5561:      	movq	%rax, 0x20(%rsp)
    5566:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    5570:      	movq	%rax, 0x18(%rsp)
    5575:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    557f:      	movq	%rax, 0x10(%rsp)
    5584:      	leaq	0x10(%rsp), %rdi
    5589:      	movl	$0x2e, %eax
    558e:      	movl	$0x6, %ecx
    5593:      	movl	0x50(%rsp), %edx
    5597:      	movl	$0x2e, %esi
    559c:      	xorl	%eax, %eax
    559e:      	callq	*%rcx
    55a0:      	cmpl	$0x3, %ebp
    55a3:      	movq	0x98(%rsp), %rcx
    55ab:      	je	0x24d9 <kprobe_unwind_perl+0x24d9>
    55b1:      	jmp	0x5636 <kprobe_unwind_perl+0x5636>
    55b6:      	cmpl	$0xc, %ecx
    55b9:      	je	0x55c6 <kprobe_unwind_perl+0x55c6>
    55bb:      	cmpq	$0x0, (%r12)
    55c0:      	je	0x73c9 <kprobe_unwind_perl+0x73c9>
    55c6:      	movzbl	0x1d(%r14), %eax
    55cb:      	subq	%rax, 0xf50(%r15)
    55d2:      	movl	$0x10, 0x50(%rsp)
    55da:      	movq	(%rip), %rdi            # 0x55e1 <kprobe_unwind_perl+0x55e1>
    55e1:      	leaq	0x50(%rsp), %rsi
    55e6:      	movl	$0x1, %eax
    55eb:      	callq	*%rax
    55ed:      	testq	%rax, %rax
    55f0:      	je	0x5604 <kprobe_unwind_perl+0x5604>
    55f2:      	incq	(%rax)
    55f5:      	cmpl	$0x3, %ebp
    55f8:      	movq	0x98(%rsp), %rcx
    5600:      	je	0x5621 <kprobe_unwind_perl+0x5621>
    5602:      	jmp	0x5636 <kprobe_unwind_perl+0x5636>
    5604:      	movq	(%rip), %rax            # 0x560b <kprobe_unwind_perl+0x560b>
    560b:      	cmpl	$0x0, (%rax)
    560e:      	jne	0x84eb <kprobe_unwind_perl+0x84eb>
    5614:      	cmpl	$0x3, %ebp
    5617:      	movq	0x98(%rsp), %rcx
    561f:      	jne	0x5636 <kprobe_unwind_perl+0x5636>
    5621:      	movq	0xf50(%r15), %r13
    5628:      	movl	$0x3, %ebp
    562d:      	cmpq	%rcx, %r13
    5630:      	jae	0x5e5f <kprobe_unwind_perl+0x5e5f>
    5636:      	movq	0xf50(%r15), %rax
    563d:      	cmpq	%rcx, %rax
    5640:      	movq	(%rip), %r13            # 0x5647 <kprobe_unwind_perl+0x5647>
    5647:      	jae	0x585f <kprobe_unwind_perl+0x585f>
    564d:      	movq	(%r12), %r12
    5651:      	testq	%r12, %r12
    5654:      	je	0x56f7 <kprobe_unwind_perl+0x56f7>
    565a:      	cmpl	$0x0, (%r13)
    565f:      	jne	0x5a96 <kprobe_unwind_perl+0x5a96>
    5665:      	movl	0x2c0(%r15), %eax
    566c:      	cmpq	$0x7f, %rax
    5670:      	jb	0x56a9 <kprobe_unwind_perl+0x56a9>
    5672:      	cmpl	$0x0, (%r13)
    5677:      	jne	0x5c3b <kprobe_unwind_perl+0x5c3b>
    567d:      	movl	$0x2, 0x50(%rsp)
    5685:      	movq	(%rip), %rdi            # 0x568c <kprobe_unwind_perl+0x568c>
    568c:      	leaq	0x50(%rsp), %rsi
    5691:      	movl	$0x1, %eax
    5696:      	callq	*%rax
    5698:      	testq	%rax, %rax
    569b:      	je	0x5929 <kprobe_unwind_perl+0x5929>
    56a1:      	incq	(%rax)
    56a4:      	jmp	0x5934 <kprobe_unwind_perl+0x5934>
    56a9:      	leal	0x1(%rax), %ecx
    56ac:      	movl	%ecx, 0x2c0(%r15)
    56b3:      	leaq	(%rax,%rax,2), %rax
    56b7:      	movq	$0x0, 0x2d0(%r15,%rax,8)
    56c3:      	movq	%r12, 0x2d8(%r15,%rax,8)
    56cb:      	movb	$0x7, 0x2e0(%r15,%rax,8)
    56d4:      	movl	$0x0, 0x2e1(%r15,%rax,8)
    56e0:      	movl	$0x0, 0x2e4(%r15,%rax,8)
    56ec:      	movq	$0x0, 0xf40(%r15)
    56f7:      	movl	$0x0, 0x78(%rsp)
    56ff:      	movzbl	0x18(%r14), %eax
    5704:      	addq	0xa8(%rsp), %rax
    570c:      	leaq	0x78(%rsp), %rdi
    5711:      	movl	$0x4, %ecx
    5716:      	movl	$0x70, %r8d
    571c:      	movzbl	0x18(%r14), %edx
    5721:      	addq	0xa8(%rsp), %rdx
    5729:      	movl	$0x4, %esi
    572e:      	callq	*%r8
    5731:      	testq	%rax, %rax
    5734:      	jne	0x5847 <kprobe_unwind_perl+0x5847>
    573a:      	cmpl	$0x1, 0x78(%rsp)
    573f:      	je	0x5847 <kprobe_unwind_perl+0x5847>
    5745:      	movzbl	0x16(%r14), %eax
    574a:      	addq	0xa8(%rsp), %rax
    5752:      	leaq	0xa8(%rsp), %rdi
    575a:      	movl	$0x8, %ecx
    575f:      	movl	$0x70, %r8d
    5765:      	movzbl	0x16(%r14), %edx
    576a:      	addq	0xa8(%rsp), %rdx
    5772:      	movl	$0x8, %esi
    5777:      	callq	*%r8
    577a:      	testq	%rax, %rax
    577d:      	jne	0x5847 <kprobe_unwind_perl+0x5847>
    5783:      	movq	0xa8(%rsp), %r12
    578b:      	testq	%r12, %r12
    578e:      	je	0x5847 <kprobe_unwind_perl+0x5847>
    5794:      	cmpl	$0x0, (%r13)
    5799:      	jne	0x5ca3 <kprobe_unwind_perl+0x5ca3>
    579f:      	movq	0xb8(%rsp), %rax
    57a7:      	movq	%r12, (%rax)
    57aa:      	movzbl	0x15(%r14), %eax
    57af:      	addq	%r12, %rax
    57b2:      	leaq	0x50(%rsp), %rdi
    57b7:      	movl	$0x8, %ecx
    57bc:      	movl	$0x70, %r8d
    57c2:      	movzbl	0x15(%r14), %edx
    57c7:      	addq	%r12, %rdx
    57ca:      	movl	$0x8, %esi
    57cf:      	callq	*%r8
    57d2:      	testq	%rax, %rax
    57d5:      	jne	0x580b <kprobe_unwind_perl+0x580b>
    57d7:      	movzbl	0x17(%r14), %eax
    57dc:      	addq	%r12, %rax
    57df:      	leaq	0x88(%rsp), %rdi
    57e7:      	movl	$0x4, %ecx
    57ec:      	movl	$0x70, %r8d
    57f2:      	movzbl	0x17(%r14), %edx
    57f7:      	addq	%r12, %rdx
    57fa:      	movl	$0x4, %esi
    57ff:      	callq	*%r8
    5802:      	testq	%rax, %rax
    5805:      	je	0x59c1 <kprobe_unwind_perl+0x59c1>
    580b:      	cmpl	$0x0, (%r13)
    5810:      	jne	0x5d08 <kprobe_unwind_perl+0x5d08>
    5816:      	orb	$0x8, 0x1380(%r15)
    581e:      	movl	$0x12, 0x60(%rsp)
    5826:      	movq	(%rip), %rdi            # 0x582d <kprobe_unwind_perl+0x582d>
    582d:      	leaq	0x60(%rsp), %rsi
    5832:      	movl	$0x1, %eax
    5837:      	callq	*%rax
    5839:      	testq	%rax, %rax
    583c:      	je	0x593b <kprobe_unwind_perl+0x593b>
    5842:      	incq	(%rax)
    5845:      	jmp	0x585a <kprobe_unwind_perl+0x585a>
    5847:      	cmpl	$0x0, (%r13)
    584c:      	jne	0x5b76 <kprobe_unwind_perl+0x5b76>
    5852:      	orb	$0x8, 0x1380(%r15)
    585a:      	movl	$0x1, %ebp
    585f:      	cmpl	$0x0, (%r13)
    5864:      	jne	0x59f8 <kprobe_unwind_perl+0x59f8>
    586a:      	movl	$0x0, 0x10(%rsp)
    5872:      	movq	(%rip), %rdi            # 0x5879 <kprobe_unwind_perl+0x5879>
    5879:      	leaq	0x10(%rsp), %rsi
    587e:      	movl	$0x1, %eax
    5883:      	callq	*%rax
    5885:      	testq	%rax, %rax
    5888:      	je	0x58c8 <kprobe_unwind_perl+0x58c8>
    588a:      	movzbl	0x1384(%rax), %ecx
    5891:      	cmpb	$0x1d, %cl
    5894:      	jb	0x58f5 <kprobe_unwind_perl+0x58f5>
    5896:      	movq	%rax, %r14
    5899:      	movl	$0x5, 0xf2c(%rax)
    58a3:      	movl	$0x44, 0x50(%rsp)
    58ab:      	movq	(%rip), %rdi            # 0x58b2 <kprobe_unwind_perl+0x58b2>
    58b2:      	leaq	0x50(%rsp), %rsi
    58b7:      	movl	$0x1, %eax
    58bc:      	callq	*%rax
    58be:      	testq	%rax, %rax
    58c1:      	je	0x58dd <kprobe_unwind_perl+0x58dd>
    58c3:      	incq	(%rax)
    58c6:      	jmp	0x58e8 <kprobe_unwind_perl+0x58e8>
    58c8:      	movq	(%rip), %rsi            # 0x58cf <kprobe_unwind_perl+0x58cf>
    58cf:      	xorl	%eax, %eax
    58d1:      	movl	$0xc, %ecx
    58d6:      	movq	%rbx, %rdi
    58d9:      	xorl	%edx, %edx
    58db:      	jmp	0x5910 <kprobe_unwind_perl+0x5910>
    58dd:      	cmpl	$0x0, (%r13)
    58e2:      	jne	0x5bc0 <kprobe_unwind_perl+0x5bc0>
    58e8:      	movq	%r14, %rax
    58eb:      	movzbl	0x1384(%r14), %ecx
    58f3:      	xorl	%ebp, %ebp
    58f5:      	incb	%cl
    58f7:      	movb	%cl, 0x1384(%rax)
    58fd:      	movl	%ebp, %eax
    58ff:      	movq	(%rip), %rsi            # 0x5906 <kprobe_unwind_perl+0x5906>
    5906:      	movl	$0xc, %ecx
    590b:      	movq	%rbx, %rdi
    590e:      	movl	%ebp, %edx
    5910:      	callq	*%rcx
    5912:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
    5917:      	addq	$0xc8, %rsp
    591e:      	popq	%rbx
    591f:      	popq	%r12
    5921:      	popq	%r13
    5923:      	popq	%r14
    5925:      	popq	%r15
    5927:      	popq	%rbp
    5928:      	retq
    5929:      	cmpl	$0x0, (%r13)
    592e:      	jne	0x5d6c <kprobe_unwind_perl+0x5d6c>
    5934:      	xorl	%ebp, %ebp
    5936:      	jmp	0x586a <kprobe_unwind_perl+0x586a>
    593b:      	cmpl	$0x0, (%r13)
    5940:      	je	0x585a <kprobe_unwind_perl+0x585a>
    5946:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    5950:      	movq	%rax, 0x36(%rsp)
    5955:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    595f:      	movq	%rax, 0x30(%rsp)
    5964:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    596e:      	movq	%rax, 0x28(%rsp)
    5973:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    597d:      	movq	%rax, 0x20(%rsp)
    5982:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    598c:      	movq	%rax, 0x18(%rsp)
    5991:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    599b:      	movq	%rax, 0x10(%rsp)
    59a0:      	leaq	0x10(%rsp), %rdi
    59a5:      	movl	$0x2e, %eax
    59aa:      	movl	$0x6, %ecx
    59af:      	movl	0x60(%rsp), %edx
    59b3:      	movl	$0x2e, %esi
    59b8:      	xorl	%eax, %eax
    59ba:      	callq	*%rcx
    59bc:      	jmp	0x585a <kprobe_unwind_perl+0x585a>
    59c1:      	cmpl	$0x0, (%r13)
    59c6:      	jne	0x5de9 <kprobe_unwind_perl+0x5de9>
    59cc:      	movq	0x50(%rsp), %rax
    59d1:      	movq	%rax, 0xf48(%r15)
    59d8:      	movslq	0x88(%rsp), %rcx
    59e0:      	movzbl	0x1d(%r14), %edx
    59e5:      	imulq	%rcx, %rdx
    59e9:      	addq	%rax, %rdx
    59ec:      	movq	%rdx, 0xf50(%r15)
    59f3:      	jmp	0x585a <kprobe_unwind_perl+0x585a>
    59f8:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    5a02:      	movq	%rax, 0x3d(%rsp)
    5a07:      	movabsq	$0x783020786c257830, %rax # imm = 0x783020786C257830
    5a11:      	movq	%rax, 0x38(%rsp)
    5a16:      	movabsq	$0x202c786c25783020, %rax # imm = 0x202C786C25783020
    5a20:      	movq	%rax, 0x30(%rsp)
    5a25:      	movabsq	$0x6f666e696b636174, %rax # imm = 0x6F666E696B636174
    5a2f:      	movq	%rax, 0x28(%rsp)
    5a34:      	movabsq	$0x73207478656e202c, %rax # imm = 0x73207478656E202C
    5a3e:      	movq	%rax, 0x20(%rsp)
    5a43:      	movabsq	$0x656e6f6420646e69, %rax # imm = 0x656E6F6420646E69
    5a4d:      	movq	%rax, 0x18(%rsp)
    5a52:      	movabsq	$0x776e75206c726550, %rax # imm = 0x776E75206C726550
    5a5c:      	movq	%rax, 0x10(%rsp)
    5a61:      	leaq	0x10(%rsp), %rdi
    5a66:      	movl	$0x35, %eax
    5a6b:      	movl	$0x6, %r9d
    5a71:      	movq	0xa8(%rsp), %rdx
    5a79:      	movq	0xf48(%r15), %rcx
    5a80:      	movq	0xf50(%r15), %r8
    5a87:      	movl	$0x35, %esi
    5a8c:      	xorl	%eax, %eax
    5a8e:      	callq	*%r9
    5a91:      	jmp	0x586a <kprobe_unwind_perl+0x586a>
    5a96:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    5aa0:      	movq	%rax, 0x30(%rsp)
    5aa5:      	movabsq	$0x6e69616d20676e69, %rax # imm = 0x6E69616D20676E69
    5aaf:      	movq	%rax, 0x28(%rsp)
    5ab4:      	movabsq	$0x68737570202d206b, %rax # imm = 0x68737570202D206B
    5abe:      	movq	%rax, 0x20(%rsp)
    5ac3:      	movabsq	$0x63617473206c7265, %rax # imm = 0x63617473206C7265
    5acd:      	movq	%rax, 0x18(%rsp)
    5ad2:      	movabsq	$0x7020666f20646e45, %rax # imm = 0x7020666F20646E45
    5adc:      	movq	%rax, 0x10(%rsp)
    5ae1:      	leaq	0x10(%rsp), %rdi
    5ae6:      	movl	$0x28, %eax
    5aeb:      	movl	$0x6, %ecx
    5af0:      	movl	$0x28, %esi
    5af5:      	movq	%r12, %rdx
    5af8:      	xorl	%eax, %eax
    5afa:      	callq	*%rcx
    5afc:      	cmpl	$0x0, (%r13)
    5b01:      	je	0x5665 <kprobe_unwind_perl+0x5665>
    5b07:      	movabsq	$0xa786c2578303d, %rax  # imm = 0xA786C2578303D
    5b11:      	movq	%rax, 0x30(%rsp)
    5b16:      	movabsq	$0x7663202c786c2578, %rax # imm = 0x7663202C786C2578
    5b20:      	movq	%rax, 0x28(%rsp)
    5b25:      	movabsq	$0x303d706f6320656d, %rax # imm = 0x303D706F6320656D
    5b2f:      	movq	%rax, 0x20(%rsp)
    5b34:      	movabsq	$0x617266206c726570, %rax # imm = 0x617266206C726570
    5b3e:      	movq	%rax, 0x18(%rsp)
    5b43:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    5b4d:      	movq	%rax, 0x10(%rsp)
    5b52:      	leaq	0x10(%rsp), %rdi
    5b57:      	movl	$0x28, %eax
    5b5c:      	movl	$0x6, %r8d
    5b62:      	movl	$0x28, %esi
    5b67:      	xorl	%edx, %edx
    5b69:      	movq	%r12, %rcx
    5b6c:      	xorl	%eax, %eax
    5b6e:      	callq	*%r8
    5b71:      	jmp	0x5665 <kprobe_unwind_perl+0x5665>
    5b76:      	movabsq	$0xa656e6f642073, %rax  # imm = 0xA656E6F642073
    5b80:      	movq	%rax, 0x1e(%rsp)
    5b85:      	movabsq	$0x20736f666e696b63, %rax # imm = 0x20736F666E696B63
    5b8f:      	movq	%rax, 0x18(%rsp)
    5b94:      	movabsq	$0x617473206c726550, %rax # imm = 0x617473206C726550
    5b9e:      	movq	%rax, 0x10(%rsp)
    5ba3:      	leaq	0x10(%rsp), %rdi
    5ba8:      	movl	$0x16, %eax
    5bad:      	movl	$0x6, %ecx
    5bb2:      	movl	$0x16, %esi
    5bb7:      	xorl	%eax, %eax
    5bb9:      	callq	*%rcx
    5bbb:      	jmp	0x5852 <kprobe_unwind_perl+0x5852>
    5bc0:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    5bca:      	movq	%rax, 0x36(%rsp)
    5bcf:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    5bd9:      	movq	%rax, 0x30(%rsp)
    5bde:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    5be8:      	movq	%rax, 0x28(%rsp)
    5bed:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    5bf7:      	movq	%rax, 0x20(%rsp)
    5bfc:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    5c06:      	movq	%rax, 0x18(%rsp)
    5c0b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5c15:      	movq	%rax, 0x10(%rsp)
    5c1a:      	leaq	0x10(%rsp), %rdi
    5c1f:      	movl	$0x2e, %eax
    5c24:      	movl	$0x6, %ecx
    5c29:      	movl	0x50(%rsp), %edx
    5c2d:      	movl	$0x2e, %esi
    5c32:      	xorl	%eax, %eax
    5c34:      	callq	*%rcx
    5c36:      	jmp	0x58e8 <kprobe_unwind_perl+0x58e8>
    5c3b:      	movabsq	$0xa6c6c75662073, %rax  # imm = 0xA6C6C75662073
    5c45:      	movq	%rax, 0x2d(%rsp)
    5c4a:      	movabsq	$0x66207369206b6361, %rax # imm = 0x66207369206B6361
    5c54:      	movq	%rax, 0x28(%rsp)
    5c59:      	movabsq	$0x7473203a656d6172, %rax # imm = 0x7473203A656D6172
    5c63:      	movq	%rax, 0x20(%rsp)
    5c68:      	movabsq	$0x662068737570206f, %rax # imm = 0x662068737570206F
    5c72:      	movq	%rax, 0x18(%rsp)
    5c77:      	movabsq	$0x7420656c62616e75, %rax # imm = 0x7420656C62616E75
    5c81:      	movq	%rax, 0x10(%rsp)
    5c86:      	leaq	0x10(%rsp), %rdi
    5c8b:      	movl	$0x25, %eax
    5c90:      	movl	$0x6, %ecx
    5c95:      	movl	$0x25, %esi
    5c9a:      	xorl	%eax, %eax
    5c9c:      	callq	*%rcx
    5c9e:      	jmp	0x567d <kprobe_unwind_perl+0x567d>
    5ca3:      	movabsq	$0xa642520657079, %rax  # imm = 0xA642520657079
    5cad:      	movq	%rax, 0x26(%rsp)
    5cb2:      	movabsq	$0x707974203a6f666e, %rax # imm = 0x707974203A6F666E
    5cbc:      	movq	%rax, 0x20(%rsp)
    5cc1:      	movabsq	$0x696b636174732074, %rax # imm = 0x696B636174732074
    5ccb:      	movq	%rax, 0x18(%rsp)
    5cd0:      	movabsq	$0x78656e206c726550, %rax # imm = 0x78656E206C726550
    5cda:      	movq	%rax, 0x10(%rsp)
    5cdf:      	leaq	0x10(%rsp), %rdi
    5ce4:      	movl	$0x1e, %eax
    5ce9:      	movl	$0x6, %ecx
    5cee:      	movl	0x78(%rsp), %edx
    5cf2:      	movl	$0x1e, %esi
    5cf7:      	xorl	%eax, %eax
    5cf9:      	callq	*%rcx
    5cfb:      	movq	0xa8(%rsp), %r12
    5d03:      	jmp	0x579f <kprobe_unwind_perl+0x579f>
    5d08:      	movabsq	$0x6c25783020746120, %rax # imm = 0x6C25783020746120
    5d12:      	movq	%rax, 0x28(%rsp)
    5d17:      	movabsq	$0x6f666e696b636174, %rax # imm = 0x6F666E696B636174
    5d21:      	movq	%rax, 0x20(%rsp)
    5d26:      	movabsq	$0x732064616572206f, %rax # imm = 0x732064616572206F
    5d30:      	movq	%rax, 0x18(%rsp)
    5d35:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5d3f:      	movq	%rax, 0x10(%rsp)
    5d44:      	movl	$0xa786c, 0x2f(%rsp)    # imm = 0xA786C
    5d4c:      	leaq	0x10(%rsp), %rdi
    5d51:      	movl	$0x23, %eax
    5d56:      	movl	$0x6, %ecx
    5d5b:      	movl	$0x23, %esi
    5d60:      	movq	%r12, %rdx
    5d63:      	xorl	%eax, %eax
    5d65:      	callq	*%rcx
    5d67:      	jmp	0x5816 <kprobe_unwind_perl+0x5816>
    5d6c:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    5d76:      	movq	%rax, 0x36(%rsp)
    5d7b:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    5d85:      	movq	%rax, 0x30(%rsp)
    5d8a:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    5d94:      	movq	%rax, 0x28(%rsp)
    5d99:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    5da3:      	movq	%rax, 0x20(%rsp)
    5da8:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    5db2:      	movq	%rax, 0x18(%rsp)
    5db7:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5dc1:      	movq	%rax, 0x10(%rsp)
    5dc6:      	leaq	0x10(%rsp), %rdi
    5dcb:      	movl	$0x2e, %eax
    5dd0:      	movl	$0x6, %ecx
    5dd5:      	movl	0x50(%rsp), %edx
    5dd9:      	movl	$0x2e, %esi
    5dde:      	xorl	%eax, %eax
    5de0:      	callq	*%rcx
    5de2:      	xorl	%ebp, %ebp
    5de4:      	jmp	0x586a <kprobe_unwind_perl+0x586a>
    5de9:      	movabsq	$0xa642520786978, %rax  # imm = 0xA642520786978
    5df3:      	movq	%rax, 0x2e(%rsp)
    5df8:      	movabsq	$0x697863202c786c25, %rax # imm = 0x697863202C786C25
    5e02:      	movq	%rax, 0x28(%rsp)
    5e07:      	movabsq	$0x7830206573616278, %rax # imm = 0x7830206573616278
    5e11:      	movq	%rax, 0x20(%rsp)
    5e16:      	movabsq	$0x63202c6f666e696b, %rax # imm = 0x63202C6F666E696B
    5e20:      	movq	%rax, 0x18(%rsp)
    5e25:      	movabsq	$0x636174732077654e, %rax # imm = 0x636174732077654E
    5e2f:      	movq	%rax, 0x10(%rsp)
    5e34:      	leaq	0x10(%rsp), %rdi
    5e39:      	movl	$0x26, %eax
    5e3e:      	movl	$0x6, %r8d
    5e44:      	movq	0x50(%rsp), %rdx
    5e49:      	movl	0x88(%rsp), %ecx
    5e50:      	movl	$0x26, %esi
    5e55:      	xorl	%eax, %eax
    5e57:      	callq	*%r8
    5e5a:      	jmp	0x59cc <kprobe_unwind_perl+0x59cc>
    5e5f:      	movzbl	0x19(%r14), %eax
    5e64:      	addq	%r13, %rax
    5e67:      	leaq	0xe(%rsp), %rdi
    5e6c:      	movl	$0x1, %ecx
    5e71:      	movl	$0x70, %r8d
    5e77:      	movzbl	0x19(%r14), %edx
    5e7c:      	addq	%r13, %rdx
    5e7f:      	movl	$0x1, %esi
    5e84:      	callq	*%r8
    5e87:      	testq	%rax, %rax
    5e8a:      	je	0x6374 <kprobe_unwind_perl+0x6374>
    5e90:      	movq	(%rip), %rax            # 0x5e97 <kprobe_unwind_perl+0x5e97>
    5e97:      	cmpl	$0x0, (%rax)
    5e9a:      	jne	0x8669 <kprobe_unwind_perl+0x8669>
    5ea0:      	movl	$0x13, 0x50(%rsp)
    5ea8:      	movq	(%rip), %rdi            # 0x5eaf <kprobe_unwind_perl+0x5eaf>
    5eaf:      	leaq	0x50(%rsp), %rsi
    5eb4:      	movl	$0x1, %eax
    5eb9:      	callq	*%rax
    5ebb:      	testq	%rax, %rax
    5ebe:      	je	0x658b <kprobe_unwind_perl+0x658b>
    5ec4:      	incq	(%rax)
    5ec7:      	movl	$0x3, %ebp
    5ecc:      	jmp	0x67c4 <kprobe_unwind_perl+0x67c4>
    5ed1:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    5edb:      	movq	%rax, 0x36(%rsp)
    5ee0:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    5eea:      	movq	%rax, 0x30(%rsp)
    5eef:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    5ef9:      	movq	%rax, 0x28(%rsp)
    5efe:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    5f08:      	movq	%rax, 0x20(%rsp)
    5f0d:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    5f17:      	movq	%rax, 0x18(%rsp)
    5f1c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5f26:      	movq	%rax, 0x10(%rsp)
    5f2b:      	leaq	0x10(%rsp), %rdi
    5f30:      	movl	$0x2e, %eax
    5f35:      	movl	$0x6, %ecx
    5f3a:      	movl	0x50(%rsp), %edx
    5f3e:      	movl	$0x2e, %esi
    5f43:      	xorl	%eax, %eax
    5f45:      	callq	*%rcx
    5f47:      	jmp	0x211e <kprobe_unwind_perl+0x211e>
    5f4c:      	movabsq	$0xa7667655f7663, %rax  # imm = 0xA7667655F7663
    5f56:      	movq	%rax, 0x35(%rsp)
    5f5b:      	movabsq	$0x5f76635f65766c6f, %rax # imm = 0x5F76635F65766C6F
    5f65:      	movq	%rax, 0x30(%rsp)
    5f6a:      	movabsq	$0x736572206e692029, %rax # imm = 0x736572206E692029
    5f74:      	movq	%rax, 0x28(%rsp)
    5f79:      	movabsq	$0x28726573755f6461, %rax # imm = 0x28726573755F6461
    5f83:      	movq	%rax, 0x20(%rsp)
    5f88:      	movabsq	$0x65725f65626f7270, %rax # imm = 0x65725F65626F7270
    5f92:      	movq	%rax, 0x18(%rsp)
    5f97:      	movabsq	$0x5f66706220646142, %rax # imm = 0x5F66706220646142
    5fa1:      	movq	%rax, 0x10(%rsp)
    5fa6:      	leaq	0x10(%rsp), %rdi
    5fab:      	movl	$0x2d, %eax
    5fb0:      	movl	$0x6, %ecx
    5fb5:      	movl	$0x2d, %esi
    5fba:      	xorl	%eax, %eax
    5fbc:      	callq	*%rcx
    5fbe:      	jmp	0x12bb <kprobe_unwind_perl+0x12bb>
    5fc3:      	movl	0x5c(%rsp), %eax
    5fc7:      	andl	$0x1f, %eax
    5fca:      	cmpl	$0xd, %eax
    5fcd:      	jne	0x6674 <kprobe_unwind_perl+0x6674>
    5fd3:      	movzbl	0x1f(%r14), %eax
    5fd8:      	addq	%rbp, %rax
    5fdb:      	leaq	0x50(%rsp), %rdi
    5fe0:      	movl	$0x8, %ecx
    5fe5:      	movl	$0x70, %r8d
    5feb:      	movzbl	0x1f(%r14), %edx
    5ff0:      	addq	%rbp, %rdx
    5ff3:      	movl	$0x8, %esi
    5ff8:      	callq	*%r8
    5ffb:      	testq	%rax, %rax
    5ffe:      	jne	0x3f05 <kprobe_unwind_perl+0x3f05>
    6004:      	movzbl	0x21(%r14), %eax
    6009:      	addq	0x50(%rsp), %rax
    600e:      	leaq	0x70(%rsp), %rdi
    6013:      	movl	$0x4, %ecx
    6018:      	movl	$0x70, %r8d
    601e:      	movzbl	0x21(%r14), %edx
    6023:      	addq	0x50(%rsp), %rdx
    6028:      	movl	$0x4, %esi
    602d:      	callq	*%r8
    6030:      	testq	%rax, %rax
    6033:      	jne	0x3f05 <kprobe_unwind_perl+0x3f05>
    6039:      	testb	$-0x80, 0x71(%rsp)
    603e:      	jne	0x7623 <kprobe_unwind_perl+0x7623>
    6044:      	movzbl	0x22(%r14), %eax
    6049:      	addq	0x50(%rsp), %rax
    604e:      	leaq	0x60(%rsp), %rbp
    6053:      	movl	$0x8, %ecx
    6058:      	movl	$0x70, %r8d
    605e:      	movzbl	0x22(%r14), %edx
    6063:      	addq	0x50(%rsp), %rdx
    6068:      	movq	%rbp, %rdi
    606b:      	movl	$0x8, %esi
    6070:      	callq	*%r8
    6073:      	testq	%rax, %rax
    6076:      	jne	0x3f05 <kprobe_unwind_perl+0x3f05>
    607c:      	movq	0x60(%rsp), %rax
    6081:      	testq	%rax, %rax
    6084:      	je	0x3f05 <kprobe_unwind_perl+0x3f05>
    608a:      	movq	(%rip), %rcx            # 0x6091 <kprobe_unwind_perl+0x6091>
    6091:      	cmpl	$0x0, (%rcx)
    6094:      	jne	0x8dff <kprobe_unwind_perl+0x8dff>
    609a:      	movzbl	0x1e(%r14), %ecx
    609f:      	addq	%rax, %rcx
    60a2:      	leaq	0x6c(%rsp), %rdi
    60a7:      	movl	$0x4, %eax
    60ac:      	movl	$0x70, %r8d
    60b2:      	movzbl	0x1e(%r14), %edx
    60b7:      	addq	0x60(%rsp), %rdx
    60bc:      	movl	$0x4, %esi
    60c1:      	callq	*%r8
    60c4:      	testq	%rax, %rax
    60c7:      	jne	0x3f05 <kprobe_unwind_perl+0x3f05>
    60cd:      	movl	$0x801f, %eax           # imm = 0x801F
    60d2:      	andl	0x6c(%rsp), %eax
    60d6:      	cmpl	$0x8009, %eax           # imm = 0x8009
    60db:      	jne	0x8257 <kprobe_unwind_perl+0x8257>
    60e1:      	movzbl	0x20(%r14), %eax
    60e6:      	addq	0x60(%rsp), %rax
    60eb:      	leaq	0x88(%rsp), %rdi
    60f3:      	movl	$0x8, %ecx
    60f8:      	movl	$0x70, %r8d
    60fe:      	movzbl	0x20(%r14), %edx
    6103:      	addq	0x60(%rsp), %rdx
    6108:      	movl	$0x8, %esi
    610d:      	callq	*%r8
    6110:      	testq	%rax, %rax
    6113:      	jne	0x3f05 <kprobe_unwind_perl+0x3f05>
    6119:      	movzbl	0x23(%r14), %eax
    611e:      	addq	0x88(%rsp), %rax
    6126:      	leaq	0x78(%rsp), %rdi
    612b:      	movl	$0x8, %ecx
    6130:      	movl	$0x70, %r8d
    6136:      	movzbl	0x23(%r14), %edx
    613b:      	addq	0x88(%rsp), %rdx
    6143:      	movl	$0x8, %esi
    6148:      	callq	*%r8
    614b:      	testq	%rax, %rax
    614e:      	jne	0x3f05 <kprobe_unwind_perl+0x3f05>
    6154:      	movq	0x78(%rsp), %rax
    6159:      	movq	%rax, 0x80(%rsp)
    6161:      	testq	%rax, %rax
    6164:      	je	0x61ba <kprobe_unwind_perl+0x61ba>
    6166:      	movq	(%rip), %rax            # 0x616d <kprobe_unwind_perl+0x616d>
    616d:      	cmpl	$0x0, (%rax)
    6170:      	je	0x61cf <kprobe_unwind_perl+0x61cf>
    6172:      	movabsq	$0x2578302074612056, %rax # imm = 0x2578302074612056
    617c:      	movq	%rax, 0x18(%rsp)
    6181:      	movabsq	$0x474520646e756f46, %rax # imm = 0x474520646E756F46
    618b:      	movq	%rax, 0x10(%rsp)
    6190:      	movl	$0xa786c, 0x20(%rsp)    # imm = 0xA786C
    6198:      	leaq	0x10(%rsp), %rdi
    619d:      	movl	$0x14, %eax
    61a2:      	movl	$0x6, %ecx
    61a7:      	movq	0x78(%rsp), %rdx
    61ac:      	movl	$0x14, %esi
    61b1:      	xorl	%eax, %eax
    61b3:      	callq	*%rcx
    61b5:      	leaq	0x78(%rsp), %rbp
    61ba:      	movq	(%rbp), %rax
    61be:      	movq	%rax, 0x80(%rsp)
    61c6:      	testq	%rax, %rax
    61c9:      	je	0x3945 <kprobe_unwind_perl+0x3945>
    61cf:      	movq	(%r12), %rax
    61d3:      	movq	%rax, 0x90(%rsp)
    61db:      	movq	(%rip), %rax            # 0x61e2 <kprobe_unwind_perl+0x61e2>
    61e2:      	cmpl	$0x0, (%rax)
    61e5:      	jne	0x8ffc <kprobe_unwind_perl+0x8ffc>
    61eb:      	movl	0x2c0(%r15), %eax
    61f2:      	cmpq	$0x7e, %rax
    61f6:      	ja	0x1193 <kprobe_unwind_perl+0x1193>
    61fc:      	xorl	%ecx, %ecx
    61fe:      	movzbl	0xf(%rsp), %edx
    6203:      	movb	%dl, %cl
    6205:      	leal	0x1(,%rcx,2), %ebp
    620c:      	leal	0x1(%rax), %ecx
    620f:      	movl	%ecx, 0x2c0(%r15)
    6216:      	leaq	(%rax,%rax,2), %rax
    621a:      	movq	0x80(%rsp), %rcx
    6222:      	movq	%rcx, 0x2d0(%r15,%rax,8)
    622a:      	movq	0x90(%rsp), %rcx
    6232:      	movq	%rcx, 0x2d8(%r15,%rax,8)
    623a:      	movb	$0x7, 0x2e0(%r15,%rax,8)
    6243:      	movl	$0x0, 0x2e1(%r15,%rax,8)
    624f:      	movl	$0x0, 0x2e4(%r15,%rax,8)
    625b:      	movq	$0x0, 0xf40(%r15)
    6266:      	movzbl	0x1a(%r14), %eax
    626b:      	addq	%r13, %rax
    626e:      	movl	$0x8, %ecx
    6273:      	movl	$0x70, %r8d
    6279:      	movzbl	0x1a(%r14), %edx
    627e:      	addq	%r13, %rdx
    6281:      	movq	%r12, %rdi
    6284:      	movl	$0x8, %esi
    6289:      	callq	*%r8
    628c:      	testq	%rax, %rax
    628f:      	jne	0x3945 <kprobe_unwind_perl+0x3945>
    6295:      	movq	(%rip), %rax            # 0x629c <kprobe_unwind_perl+0x629c>
    629c:      	cmpl	$0x0, (%rax)
    629f:      	je	0x428e <kprobe_unwind_perl+0x428e>
    62a5:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    62af:      	movq	%rax, 0x26(%rsp)
    62b4:      	movabsq	$0x30206b6361747320, %rax # imm = 0x30206B6361747320
    62be:      	movq	%rax, 0x20(%rsp)
    62c3:      	movabsq	$0x747865746e6f6320, %rax # imm = 0x747865746E6F6320
    62cd:      	movq	%rax, 0x18(%rsp)
    62d2:      	movabsq	$0x6d6f726620504f43, %rax # imm = 0x6D6F726620504F43
    62dc:      	movq	%rax, 0x10(%rsp)
    62e1:      	leaq	0x10(%rsp), %rdi
    62e6:      	movl	$0x1e, %eax
    62eb:      	movl	$0x6, %ecx
    62f0:      	movq	(%r12), %rdx
    62f4:      	movl	$0x1e, %esi
    62f9:      	xorl	%eax, %eax
    62fb:      	callq	*%rcx
    62fd:      	jmp	0x428e <kprobe_unwind_perl+0x428e>
    6302:      	movabsq	$0x7025207461207972, %rax # imm = 0x7025207461207972
    630c:      	movq	%rax, 0x30(%rsp)
    6311:      	movabsq	$0x746e65206b636174, %rax # imm = 0x746E65206B636174
    631b:      	movq	%rax, 0x28(%rsp)
    6320:      	movabsq	$0x7320747865746e6f, %rax # imm = 0x7320747865746E6F
    632a:      	movq	%rax, 0x20(%rsp)
    632f:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    6339:      	movq	%rax, 0x18(%rsp)
    633e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6348:      	movq	%rax, 0x10(%rsp)
    634d:      	movw	$0xa, 0x38(%rsp)
    6354:      	leaq	0x10(%rsp), %rdi
    6359:      	movl	$0x2a, %eax
    635e:      	movl	$0x6, %ecx
    6363:      	movl	$0x2a, %esi
    6368:      	movq	%r13, %rdx
    636b:      	xorl	%eax, %eax
    636d:      	callq	*%rcx
    636f:      	jmp	0x2538 <kprobe_unwind_perl+0x2538>
    6374:      	movq	(%rip), %rax            # 0x637b <kprobe_unwind_perl+0x637b>
    637b:      	cmpl	$0x0, (%rax)
    637e:      	jne	0x88ad <kprobe_unwind_perl+0x88ad>
    6384:      	movzbl	0xe(%rsp), %eax
    6389:      	movl	%eax, %ecx
    638b:      	andl	$0xf, %ecx
    638e:      	movl	$0x3, %ebp
    6393:      	leal	-0x9(%rcx), %edx
    6396:      	cmpl	$0x2, %edx
    6399:      	jae	0x67b4 <kprobe_unwind_perl+0x67b4>
    639f:      	testb	%al, %al
    63a1:      	js	0x67c4 <kprobe_unwind_perl+0x67c4>
    63a7:      	movzbl	0x1b(%r14), %eax
    63ac:      	addq	%r13, %rax
    63af:      	leaq	0x10(%rsp), %rdi
    63b4:      	movl	$0x8, %ecx
    63b9:      	movl	$0x70, %r8d
    63bf:      	movzbl	0x1b(%r14), %edx
    63c4:      	addq	%r13, %rdx
    63c7:      	movl	$0x8, %esi
    63cc:      	callq	*%r8
    63cf:      	testq	%rax, %rax
    63d2:      	jne	0x5e90 <kprobe_unwind_perl+0x5e90>
    63d8:      	cmpq	$0x0, 0x10(%rsp)
    63de:      	setne	0xf(%rsp)
    63e3:      	movzbl	0x1c(%r14), %eax
    63e8:      	addq	%r13, %rax
    63eb:      	leaq	0xa0(%rsp), %rdi
    63f3:      	movl	$0x8, %ecx
    63f8:      	movl	$0x70, %r8d
    63fe:      	movzbl	0x1c(%r14), %edx
    6403:      	addq	%r13, %rdx
    6406:      	movl	$0x8, %esi
    640b:      	callq	*%r8
    640e:      	testq	%rax, %rax
    6411:      	jne	0x5e90 <kprobe_unwind_perl+0x5e90>
    6417:      	movq	0xa0(%rsp), %rbp
    641f:      	movzbl	0x1e(%r14), %eax
    6424:      	addq	%rbp, %rax
    6427:      	leaq	0x5c(%rsp), %rdi
    642c:      	movl	$0x4, %ecx
    6431:      	movl	$0x70, %r8d
    6437:      	movzbl	0x1e(%r14), %edx
    643c:      	addq	%rbp, %rdx
    643f:      	movl	$0x4, %esi
    6444:      	callq	*%r8
    6447:      	testq	%rax, %rax
    644a:      	je	0x78d7 <kprobe_unwind_perl+0x78d7>
    6450:      	movq	(%rip), %rax            # 0x6457 <kprobe_unwind_perl+0x6457>
    6457:      	cmpl	$0x0, (%rax)
    645a:      	jne	0x8cfd <kprobe_unwind_perl+0x8cfd>
    6460:      	movl	$0x14, 0x74(%rsp)
    6468:      	movq	(%rip), %rdi            # 0x646f <kprobe_unwind_perl+0x646f>
    646f:      	leaq	0x74(%rsp), %rsi
    6474:      	movl	$0x1, %eax
    6479:      	callq	*%rax
    647b:      	testq	%rax, %rax
    647e:      	je	0x7df5 <kprobe_unwind_perl+0x7df5>
    6484:      	incq	(%rax)
    6487:      	jmp	0x5e90 <kprobe_unwind_perl+0x5e90>
    648c:      	movq	(%rip), %rax            # 0x6493 <kprobe_unwind_perl+0x6493>
    6493:      	cmpl	$0x0, (%rax)
    6496:      	je	0x149a <kprobe_unwind_perl+0x149a>
    649c:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    64a6:      	movq	%rax, 0x2e(%rsp)
    64ab:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    64b5:      	movq	%rax, 0x28(%rsp)
    64ba:      	movabsq	$0x50472d74756f6874, %rax # imm = 0x50472D74756F6874
    64c4:      	movq	%rax, 0x20(%rsp)
    64c9:      	movabsq	$0x69772d5647206465, %rax # imm = 0x69772D5647206465
    64d3:      	movq	%rax, 0x18(%rsp)
    64d8:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    64e2:      	movq	%rax, 0x10(%rsp)
    64e7:      	leaq	0x10(%rsp), %rdi
    64ec:      	movl	$0x26, %eax
    64f1:      	movl	$0x6, %ecx
    64f6:      	movl	0x6c(%rsp), %edx
    64fa:      	movl	$0x26, %esi
    64ff:      	jmp	0x37c7 <kprobe_unwind_perl+0x37c7>
    6504:      	movq	(%rip), %rax            # 0x650b <kprobe_unwind_perl+0x650b>
    650b:      	cmpl	$0x0, (%rax)
    650e:      	je	0x3945 <kprobe_unwind_perl+0x3945>
    6514:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    651e:      	movq	%rax, 0x36(%rsp)
    6523:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    652d:      	movq	%rax, 0x30(%rsp)
    6532:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    653c:      	movq	%rax, 0x28(%rsp)
    6541:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    654b:      	movq	%rax, 0x20(%rsp)
    6550:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    655a:      	movq	%rax, 0x18(%rsp)
    655f:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6569:      	movq	%rax, 0x10(%rsp)
    656e:      	leaq	0x10(%rsp), %rdi
    6573:      	movl	$0x2e, %eax
    6578:      	movl	$0x6, %ecx
    657d:      	movl	0x74(%rsp), %edx
    6581:      	movl	$0x2e, %esi
    6586:      	jmp	0x66d8 <kprobe_unwind_perl+0x66d8>
    658b:      	movq	(%rip), %rax            # 0x6592 <kprobe_unwind_perl+0x6592>
    6592:      	cmpl	$0x0, (%rax)
    6595:      	jne	0x88f4 <kprobe_unwind_perl+0x88f4>
    659b:      	movl	$0x3, %ebp
    65a0:      	jmp	0x67c4 <kprobe_unwind_perl+0x67c4>
    65a5:      	movabsq	$0x6c25783020746120, %rax # imm = 0x6C25783020746120
    65af:      	movq	%rax, 0x18(%rsp)
    65b4:      	movabsq	$0x564720646e756f46, %rax # imm = 0x564720646E756F46
    65be:      	movq	%rax, 0x10(%rsp)
    65c3:      	movl	$0xa786c, 0x1f(%rsp)    # imm = 0xA786C
    65cb:      	leaq	0x10(%rsp), %rdi
    65d0:      	movl	$0x13, %eax
    65d5:      	movl	$0x6, %ecx
    65da:      	movq	0x60(%rsp), %rdx
    65df:      	movl	$0x13, %esi
    65e4:      	xorl	%eax, %eax
    65e6:      	callq	*%rcx
    65e8:      	movq	0x60(%rsp), %rax
    65ed:      	jmp	0x1031 <kprobe_unwind_perl+0x1031>
    65f2:      	movq	(%rip), %rax            # 0x65f9 <kprobe_unwind_perl+0x65f9>
    65f9:      	cmpl	$0x0, (%rax)
    65fc:      	je	0x2528 <kprobe_unwind_perl+0x2528>
    6602:      	movabsq	$0xa782578302f78, %rax  # imm = 0xA782578302F78
    660c:      	movq	%rax, 0x2e(%rsp)
    6611:      	movabsq	$0x2f78257830207367, %rax # imm = 0x2F78257830207367
    661b:      	movq	%rax, 0x28(%rsp)
    6620:      	movabsq	$0x616c66202c564320, %rax # imm = 0x616C66202C564320
    662a:      	movq	%rax, 0x20(%rsp)
    662f:      	movabsq	$0x44454d414e206465, %rax # imm = 0x44454D414E206465
    6639:      	movq	%rax, 0x18(%rsp)
    663e:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    6648:      	movq	%rax, 0x10(%rsp)
    664d:      	leaq	0x10(%rsp), %rdi
    6652:      	movl	$0x26, %eax
    6657:      	movl	$0x6, %r8d
    665d:      	movl	0x5c(%rsp), %edx
    6661:      	movl	0x70(%rsp), %ecx
    6665:      	movl	$0x26, %esi
    666a:      	xorl	%eax, %eax
    666c:      	callq	*%r8
    666f:      	jmp	0x2528 <kprobe_unwind_perl+0x2528>
    6674:      	movq	(%rip), %rax            # 0x667b <kprobe_unwind_perl+0x667b>
    667b:      	cmpl	$0x0, (%rax)
    667e:      	je	0x3945 <kprobe_unwind_perl+0x3945>
    6684:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    668e:      	movq	%rax, 0x26(%rsp)
    6693:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    669d:      	movq	%rax, 0x20(%rsp)
    66a2:      	movabsq	$0x5643565020612074, %rax # imm = 0x5643565020612074
    66ac:      	movq	%rax, 0x18(%rsp)
    66b1:      	movabsq	$0x6f6e207369205643, %rax # imm = 0x6F6E207369205643
    66bb:      	movq	%rax, 0x10(%rsp)
    66c0:      	leaq	0x10(%rsp), %rdi
    66c5:      	movl	$0x1e, %eax
    66ca:      	movl	$0x6, %ecx
    66cf:      	movl	0x5c(%rsp), %edx
    66d3:      	movl	$0x1e, %esi
    66d8:      	xorl	%eax, %eax
    66da:      	callq	*%rcx
    66dc:      	jmp	0x3945 <kprobe_unwind_perl+0x3945>
    66e1:      	movabsq	$0x7825783020786320, %rax # imm = 0x7825783020786320
    66eb:      	movq	%rax, 0x18(%rsp)
    66f0:      	movabsq	$0x6c72657020746f47, %rax # imm = 0x6C72657020746F47
    66fa:      	movq	%rax, 0x10(%rsp)
    66ff:      	movw	$0xa, 0x20(%rsp)
    6706:      	leaq	0x10(%rsp), %rdi
    670b:      	movl	$0x12, %eax
    6710:      	movl	$0x6, %ecx
    6715:      	movzbl	0xe(%rsp), %edx
    671a:      	movl	$0x12, %esi
    671f:      	xorl	%eax, %eax
    6721:      	callq	*%rcx
    6723:      	jmp	0x2a25 <kprobe_unwind_perl+0x2a25>
    6728:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    6732:      	movq	%rax, 0x36(%rsp)
    6737:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    6741:      	movq	%rax, 0x30(%rsp)
    6746:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    6750:      	movq	%rax, 0x28(%rsp)
    6755:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    675f:      	movq	%rax, 0x20(%rsp)
    6764:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    676e:      	movq	%rax, 0x18(%rsp)
    6773:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    677d:      	movq	%rax, 0x10(%rsp)
    6782:      	leaq	0x10(%rsp), %rdi
    6787:      	movl	$0x2e, %eax
    678c:      	movl	$0x6, %ecx
    6791:      	movl	0x50(%rsp), %edx
    6795:      	movl	$0x2e, %esi
    679a:      	xorl	%eax, %eax
    679c:      	callq	*%rcx
    679e:      	cmpl	$0x3, %ebp
    67a1:      	movq	0x98(%rsp), %rcx
    67a9:      	je	0x2df1 <kprobe_unwind_perl+0x2df1>
    67af:      	jmp	0x5636 <kprobe_unwind_perl+0x5636>
    67b4:      	cmpl	$0xc, %ecx
    67b7:      	je	0x67c4 <kprobe_unwind_perl+0x67c4>
    67b9:      	cmpq	$0x0, (%r12)
    67be:      	je	0x7b7a <kprobe_unwind_perl+0x7b7a>
    67c4:      	movzbl	0x1d(%r14), %eax
    67c9:      	subq	%rax, 0xf50(%r15)
    67d0:      	movl	$0x10, 0x50(%rsp)
    67d8:      	movq	(%rip), %rdi            # 0x67df <kprobe_unwind_perl+0x67df>
    67df:      	leaq	0x50(%rsp), %rsi
    67e4:      	movl	$0x1, %eax
    67e9:      	callq	*%rax
    67eb:      	testq	%rax, %rax
    67ee:      	je	0x67f8 <kprobe_unwind_perl+0x67f8>
    67f0:      	incq	(%rax)
    67f3:      	jmp	0x24ea <kprobe_unwind_perl+0x24ea>
    67f8:      	movq	(%rip), %rax            # 0x67ff <kprobe_unwind_perl+0x67ff>
    67ff:      	cmpl	$0x0, (%rax)
    6802:      	je	0x24ea <kprobe_unwind_perl+0x24ea>
    6808:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    6812:      	movq	%rax, 0x36(%rsp)
    6817:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    6821:      	movq	%rax, 0x30(%rsp)
    6826:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    6830:      	movq	%rax, 0x28(%rsp)
    6835:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    683f:      	movq	%rax, 0x20(%rsp)
    6844:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    684e:      	movq	%rax, 0x18(%rsp)
    6853:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    685d:      	movq	%rax, 0x10(%rsp)
    6862:      	leaq	0x10(%rsp), %rdi
    6867:      	movl	$0x2e, %eax
    686c:      	movl	$0x6, %ecx
    6871:      	movl	0x50(%rsp), %edx
    6875:      	movl	$0x2e, %esi
    687a:      	xorl	%eax, %eax
    687c:      	callq	*%rcx
    687e:      	jmp	0x24ea <kprobe_unwind_perl+0x24ea>
    6883:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    688d:      	movq	%rax, 0x36(%rsp)
    6892:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    689c:      	movq	%rax, 0x30(%rsp)
    68a1:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    68ab:      	movq	%rax, 0x28(%rsp)
    68b0:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    68ba:      	movq	%rax, 0x20(%rsp)
    68bf:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    68c9:      	movq	%rax, 0x18(%rsp)
    68ce:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    68d8:      	movq	%rax, 0x10(%rsp)
    68dd:      	leaq	0x10(%rsp), %rdi
    68e2:      	movl	$0x2e, %eax
    68e7:      	movl	$0x6, %ecx
    68ec:      	movl	0x50(%rsp), %edx
    68f0:      	movl	$0x2e, %esi
    68f5:      	xorl	%eax, %eax
    68f7:      	callq	*%rcx
    68f9:      	jmp	0x2bc4 <kprobe_unwind_perl+0x2bc4>
    68fe:      	movabsq	$0xa7667655f7663, %rax  # imm = 0xA7667655F7663
    6908:      	movq	%rax, 0x35(%rsp)
    690d:      	movabsq	$0x5f76635f65766c6f, %rax # imm = 0x5F76635F65766C6F
    6917:      	movq	%rax, 0x30(%rsp)
    691c:      	movabsq	$0x736572206e692029, %rax # imm = 0x736572206E692029
    6926:      	movq	%rax, 0x28(%rsp)
    692b:      	movabsq	$0x28726573755f6461, %rax # imm = 0x28726573755F6461
    6935:      	movq	%rax, 0x20(%rsp)
    693a:      	movabsq	$0x65725f65626f7270, %rax # imm = 0x65725F65626F7270
    6944:      	movq	%rax, 0x18(%rsp)
    6949:      	movabsq	$0x5f66706220646142, %rax # imm = 0x5F66706220646142
    6953:      	movq	%rax, 0x10(%rsp)
    6958:      	leaq	0x10(%rsp), %rdi
    695d:      	movl	$0x2d, %eax
    6962:      	movl	$0x6, %ecx
    6967:      	movl	$0x2d, %esi
    696c:      	xorl	%eax, %eax
    696e:      	callq	*%rcx
    6970:      	jmp	0x199e <kprobe_unwind_perl+0x199e>
    6975:      	movl	0x5c(%rsp), %eax
    6979:      	andl	$0x1f, %eax
    697c:      	cmpl	$0xd, %eax
    697f:      	jne	0x6ef4 <kprobe_unwind_perl+0x6ef4>
    6985:      	movzbl	0x1f(%r14), %eax
    698a:      	addq	%rbp, %rax
    698d:      	leaq	0x50(%rsp), %rdi
    6992:      	movl	$0x8, %ecx
    6997:      	movl	$0x70, %r8d
    699d:      	movzbl	0x1f(%r14), %edx
    69a2:      	addq	%rbp, %rdx
    69a5:      	movl	$0x8, %esi
    69aa:      	callq	*%r8
    69ad:      	testq	%rax, %rax
    69b0:      	jne	0x48f1 <kprobe_unwind_perl+0x48f1>
    69b6:      	movzbl	0x21(%r14), %eax
    69bb:      	addq	0x50(%rsp), %rax
    69c0:      	leaq	0x70(%rsp), %rdi
    69c5:      	movl	$0x4, %ecx
    69ca:      	movl	$0x70, %r8d
    69d0:      	movzbl	0x21(%r14), %edx
    69d5:      	addq	0x50(%rsp), %rdx
    69da:      	movl	$0x4, %esi
    69df:      	callq	*%r8
    69e2:      	testq	%rax, %rax
    69e5:      	jne	0x48f1 <kprobe_unwind_perl+0x48f1>
    69eb:      	testb	$-0x80, 0x71(%rsp)
    69f0:      	jne	0x7ec9 <kprobe_unwind_perl+0x7ec9>
    69f6:      	movzbl	0x22(%r14), %eax
    69fb:      	addq	0x50(%rsp), %rax
    6a00:      	leaq	0x60(%rsp), %rbp
    6a05:      	movl	$0x8, %ecx
    6a0a:      	movl	$0x70, %r8d
    6a10:      	movzbl	0x22(%r14), %edx
    6a15:      	addq	0x50(%rsp), %rdx
    6a1a:      	movq	%rbp, %rdi
    6a1d:      	movl	$0x8, %esi
    6a22:      	callq	*%r8
    6a25:      	testq	%rax, %rax
    6a28:      	jne	0x48f1 <kprobe_unwind_perl+0x48f1>
    6a2e:      	movq	0x60(%rsp), %rax
    6a33:      	testq	%rax, %rax
    6a36:      	je	0x48f1 <kprobe_unwind_perl+0x48f1>
    6a3c:      	movq	(%rip), %rcx            # 0x6a43 <kprobe_unwind_perl+0x6a43>
    6a43:      	cmpl	$0x0, (%rcx)
    6a46:      	jne	0x8ed7 <kprobe_unwind_perl+0x8ed7>
    6a4c:      	movzbl	0x1e(%r14), %ecx
    6a51:      	addq	%rax, %rcx
    6a54:      	leaq	0x6c(%rsp), %rdi
    6a59:      	movl	$0x4, %eax
    6a5e:      	movl	$0x70, %r8d
    6a64:      	movzbl	0x1e(%r14), %edx
    6a69:      	addq	0x60(%rsp), %rdx
    6a6e:      	movl	$0x4, %esi
    6a73:      	callq	*%r8
    6a76:      	testq	%rax, %rax
    6a79:      	jne	0x48f1 <kprobe_unwind_perl+0x48f1>
    6a7f:      	movl	$0x801f, %eax           # imm = 0x801F
    6a84:      	andl	0x6c(%rsp), %eax
    6a88:      	cmpl	$0x8009, %eax           # imm = 0x8009
    6a8d:      	jne	0x86db <kprobe_unwind_perl+0x86db>
    6a93:      	movzbl	0x20(%r14), %eax
    6a98:      	addq	0x60(%rsp), %rax
    6a9d:      	leaq	0x88(%rsp), %rdi
    6aa5:      	movl	$0x8, %ecx
    6aaa:      	movl	$0x70, %r8d
    6ab0:      	movzbl	0x20(%r14), %edx
    6ab5:      	addq	0x60(%rsp), %rdx
    6aba:      	movl	$0x8, %esi
    6abf:      	callq	*%r8
    6ac2:      	testq	%rax, %rax
    6ac5:      	jne	0x48f1 <kprobe_unwind_perl+0x48f1>
    6acb:      	movzbl	0x23(%r14), %eax
    6ad0:      	addq	0x88(%rsp), %rax
    6ad8:      	leaq	0x78(%rsp), %rdi
    6add:      	movl	$0x8, %ecx
    6ae2:      	movl	$0x70, %r8d
    6ae8:      	movzbl	0x23(%r14), %edx
    6aed:      	addq	0x88(%rsp), %rdx
    6af5:      	movl	$0x8, %esi
    6afa:      	callq	*%r8
    6afd:      	testq	%rax, %rax
    6b00:      	jne	0x48f1 <kprobe_unwind_perl+0x48f1>
    6b06:      	movq	0x78(%rsp), %rax
    6b0b:      	movq	%rax, 0x80(%rsp)
    6b13:      	testq	%rax, %rax
    6b16:      	je	0x6b6c <kprobe_unwind_perl+0x6b6c>
    6b18:      	movq	(%rip), %rax            # 0x6b1f <kprobe_unwind_perl+0x6b1f>
    6b1f:      	cmpl	$0x0, (%rax)
    6b22:      	je	0x6b81 <kprobe_unwind_perl+0x6b81>
    6b24:      	movabsq	$0x2578302074612056, %rax # imm = 0x2578302074612056
    6b2e:      	movq	%rax, 0x18(%rsp)
    6b33:      	movabsq	$0x474520646e756f46, %rax # imm = 0x474520646E756F46
    6b3d:      	movq	%rax, 0x10(%rsp)
    6b42:      	movl	$0xa786c, 0x20(%rsp)    # imm = 0xA786C
    6b4a:      	leaq	0x10(%rsp), %rdi
    6b4f:      	movl	$0x14, %eax
    6b54:      	movl	$0x6, %ecx
    6b59:      	movq	0x78(%rsp), %rdx
    6b5e:      	movl	$0x14, %esi
    6b63:      	xorl	%eax, %eax
    6b65:      	callq	*%rcx
    6b67:      	leaq	0x78(%rsp), %rbp
    6b6c:      	movq	(%rbp), %rax
    6b70:      	movq	%rax, 0x80(%rsp)
    6b78:      	testq	%rax, %rax
    6b7b:      	je	0x4331 <kprobe_unwind_perl+0x4331>
    6b81:      	movq	(%r12), %rax
    6b85:      	movq	%rax, 0x90(%rsp)
    6b8d:      	movq	(%rip), %rax            # 0x6b94 <kprobe_unwind_perl+0x6b94>
    6b94:      	cmpl	$0x0, (%rax)
    6b97:      	jne	0x90d4 <kprobe_unwind_perl+0x90d4>
    6b9d:      	movl	0x2c0(%r15), %eax
    6ba4:      	cmpq	$0x7e, %rax
    6ba8:      	ja	0x1193 <kprobe_unwind_perl+0x1193>
    6bae:      	xorl	%ecx, %ecx
    6bb0:      	movzbl	0xf(%rsp), %edx
    6bb5:      	movb	%dl, %cl
    6bb7:      	leal	0x1(,%rcx,2), %ebp
    6bbe:      	leal	0x1(%rax), %ecx
    6bc1:      	movl	%ecx, 0x2c0(%r15)
    6bc8:      	leaq	(%rax,%rax,2), %rax
    6bcc:      	movq	0x80(%rsp), %rcx
    6bd4:      	movq	%rcx, 0x2d0(%r15,%rax,8)
    6bdc:      	movq	0x90(%rsp), %rcx
    6be4:      	movq	%rcx, 0x2d8(%r15,%rax,8)
    6bec:      	movb	$0x7, 0x2e0(%r15,%rax,8)
    6bf5:      	movl	$0x0, 0x2e1(%r15,%rax,8)
    6c01:      	movl	$0x0, 0x2e4(%r15,%rax,8)
    6c0d:      	movq	$0x0, 0xf40(%r15)
    6c18:      	movzbl	0x1a(%r14), %eax
    6c1d:      	addq	%r13, %rax
    6c20:      	movl	$0x8, %ecx
    6c25:      	movl	$0x70, %r8d
    6c2b:      	movzbl	0x1a(%r14), %edx
    6c30:      	addq	%r13, %rdx
    6c33:      	movq	%r12, %rdi
    6c36:      	movl	$0x8, %esi
    6c3b:      	callq	*%r8
    6c3e:      	testq	%rax, %rax
    6c41:      	jne	0x4331 <kprobe_unwind_perl+0x4331>
    6c47:      	movq	(%rip), %rax            # 0x6c4e <kprobe_unwind_perl+0x6c4e>
    6c4e:      	cmpl	$0x0, (%rax)
    6c51:      	je	0x4c07 <kprobe_unwind_perl+0x4c07>
    6c57:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    6c61:      	movq	%rax, 0x26(%rsp)
    6c66:      	movabsq	$0x30206b6361747320, %rax # imm = 0x30206B6361747320
    6c70:      	movq	%rax, 0x20(%rsp)
    6c75:      	movabsq	$0x747865746e6f6320, %rax # imm = 0x747865746E6F6320
    6c7f:      	movq	%rax, 0x18(%rsp)
    6c84:      	movabsq	$0x6d6f726620504f43, %rax # imm = 0x6D6F726620504F43
    6c8e:      	movq	%rax, 0x10(%rsp)
    6c93:      	leaq	0x10(%rsp), %rdi
    6c98:      	movl	$0x1e, %eax
    6c9d:      	movl	$0x6, %ecx
    6ca2:      	movq	(%r12), %rdx
    6ca6:      	movl	$0x1e, %esi
    6cab:      	xorl	%eax, %eax
    6cad:      	callq	*%rcx
    6caf:      	jmp	0x4c07 <kprobe_unwind_perl+0x4c07>
    6cb4:      	movabsq	$0x7025207461207972, %rax # imm = 0x7025207461207972
    6cbe:      	movq	%rax, 0x30(%rsp)
    6cc3:      	movabsq	$0x746e65206b636174, %rax # imm = 0x746E65206B636174
    6ccd:      	movq	%rax, 0x28(%rsp)
    6cd2:      	movabsq	$0x7320747865746e6f, %rax # imm = 0x7320747865746E6F
    6cdc:      	movq	%rax, 0x20(%rsp)
    6ce1:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    6ceb:      	movq	%rax, 0x18(%rsp)
    6cf0:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6cfa:      	movq	%rax, 0x10(%rsp)
    6cff:      	movw	$0xa, 0x38(%rsp)
    6d06:      	leaq	0x10(%rsp), %rdi
    6d0b:      	movl	$0x2a, %eax
    6d10:      	movl	$0x6, %ecx
    6d15:      	movl	$0x2a, %esi
    6d1a:      	movq	%r13, %rdx
    6d1d:      	xorl	%eax, %eax
    6d1f:      	callq	*%rcx
    6d21:      	jmp	0x2e42 <kprobe_unwind_perl+0x2e42>
    6d26:      	movq	(%rip), %rax            # 0x6d2d <kprobe_unwind_perl+0x6d2d>
    6d2d:      	cmpl	$0x0, (%rax)
    6d30:      	je	0x1b7d <kprobe_unwind_perl+0x1b7d>
    6d36:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    6d40:      	movq	%rax, 0x2e(%rsp)
    6d45:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    6d4f:      	movq	%rax, 0x28(%rsp)
    6d54:      	movabsq	$0x50472d74756f6874, %rax # imm = 0x50472D74756F6874
    6d5e:      	movq	%rax, 0x20(%rsp)
    6d63:      	movabsq	$0x69772d5647206465, %rax # imm = 0x69772D5647206465
    6d6d:      	movq	%rax, 0x18(%rsp)
    6d72:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    6d7c:      	movq	%rax, 0x10(%rsp)
    6d81:      	leaq	0x10(%rsp), %rdi
    6d86:      	movl	$0x26, %eax
    6d8b:      	movl	$0x6, %ecx
    6d90:      	movl	0x6c(%rsp), %edx
    6d94:      	movl	$0x26, %esi
    6d99:      	jmp	0x41b3 <kprobe_unwind_perl+0x41b3>
    6d9e:      	movq	(%rip), %rax            # 0x6da5 <kprobe_unwind_perl+0x6da5>
    6da5:      	cmpl	$0x0, (%rax)
    6da8:      	je	0x4331 <kprobe_unwind_perl+0x4331>
    6dae:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    6db8:      	movq	%rax, 0x36(%rsp)
    6dbd:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    6dc7:      	movq	%rax, 0x30(%rsp)
    6dcc:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    6dd6:      	movq	%rax, 0x28(%rsp)
    6ddb:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    6de5:      	movq	%rax, 0x20(%rsp)
    6dea:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    6df4:      	movq	%rax, 0x18(%rsp)
    6df9:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6e03:      	movq	%rax, 0x10(%rsp)
    6e08:      	leaq	0x10(%rsp), %rdi
    6e0d:      	movl	$0x2e, %eax
    6e12:      	movl	$0x6, %ecx
    6e17:      	movl	0x74(%rsp), %edx
    6e1b:      	movl	$0x2e, %esi
    6e20:      	jmp	0x6f58 <kprobe_unwind_perl+0x6f58>
    6e25:      	movabsq	$0x6c25783020746120, %rax # imm = 0x6C25783020746120
    6e2f:      	movq	%rax, 0x18(%rsp)
    6e34:      	movabsq	$0x564720646e756f46, %rax # imm = 0x564720646E756F46
    6e3e:      	movq	%rax, 0x10(%rsp)
    6e43:      	movl	$0xa786c, 0x1f(%rsp)    # imm = 0xA786C
    6e4b:      	leaq	0x10(%rsp), %rdi
    6e50:      	movl	$0x13, %eax
    6e55:      	movl	$0x6, %ecx
    6e5a:      	movq	0x60(%rsp), %rdx
    6e5f:      	movl	$0x13, %esi
    6e64:      	xorl	%eax, %eax
    6e66:      	callq	*%rcx
    6e68:      	movq	0x60(%rsp), %rax
    6e6d:      	jmp	0x164a <kprobe_unwind_perl+0x164a>
    6e72:      	movq	(%rip), %rax            # 0x6e79 <kprobe_unwind_perl+0x6e79>
    6e79:      	cmpl	$0x0, (%rax)
    6e7c:      	je	0x2e32 <kprobe_unwind_perl+0x2e32>
    6e82:      	movabsq	$0xa782578302f78, %rax  # imm = 0xA782578302F78
    6e8c:      	movq	%rax, 0x2e(%rsp)
    6e91:      	movabsq	$0x2f78257830207367, %rax # imm = 0x2F78257830207367
    6e9b:      	movq	%rax, 0x28(%rsp)
    6ea0:      	movabsq	$0x616c66202c564320, %rax # imm = 0x616C66202C564320
    6eaa:      	movq	%rax, 0x20(%rsp)
    6eaf:      	movabsq	$0x44454d414e206465, %rax # imm = 0x44454D414E206465
    6eb9:      	movq	%rax, 0x18(%rsp)
    6ebe:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    6ec8:      	movq	%rax, 0x10(%rsp)
    6ecd:      	leaq	0x10(%rsp), %rdi
    6ed2:      	movl	$0x26, %eax
    6ed7:      	movl	$0x6, %r8d
    6edd:      	movl	0x5c(%rsp), %edx
    6ee1:      	movl	0x70(%rsp), %ecx
    6ee5:      	movl	$0x26, %esi
    6eea:      	xorl	%eax, %eax
    6eec:      	callq	*%r8
    6eef:      	jmp	0x2e32 <kprobe_unwind_perl+0x2e32>
    6ef4:      	movq	(%rip), %rax            # 0x6efb <kprobe_unwind_perl+0x6efb>
    6efb:      	cmpl	$0x0, (%rax)
    6efe:      	je	0x4331 <kprobe_unwind_perl+0x4331>
    6f04:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    6f0e:      	movq	%rax, 0x26(%rsp)
    6f13:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    6f1d:      	movq	%rax, 0x20(%rsp)
    6f22:      	movabsq	$0x5643565020612074, %rax # imm = 0x5643565020612074
    6f2c:      	movq	%rax, 0x18(%rsp)
    6f31:      	movabsq	$0x6f6e207369205643, %rax # imm = 0x6F6E207369205643
    6f3b:      	movq	%rax, 0x10(%rsp)
    6f40:      	leaq	0x10(%rsp), %rdi
    6f45:      	movl	$0x1e, %eax
    6f4a:      	movl	$0x6, %ecx
    6f4f:      	movl	0x5c(%rsp), %edx
    6f53:      	movl	$0x1e, %esi
    6f58:      	xorl	%eax, %eax
    6f5a:      	callq	*%rcx
    6f5c:      	jmp	0x4331 <kprobe_unwind_perl+0x4331>
    6f61:      	movabsq	$0x7825783020786320, %rax # imm = 0x7825783020786320
    6f6b:      	movq	%rax, 0x18(%rsp)
    6f70:      	movabsq	$0x6c72657020746f47, %rax # imm = 0x6C72657020746F47
    6f7a:      	movq	%rax, 0x10(%rsp)
    6f7f:      	movw	$0xa, 0x20(%rsp)
    6f86:      	leaq	0x10(%rsp), %rdi
    6f8b:      	movl	$0x12, %eax
    6f90:      	movl	$0x6, %ecx
    6f95:      	movzbl	0xe(%rsp), %edx
    6f9a:      	movl	$0x12, %esi
    6f9f:      	xorl	%eax, %eax
    6fa1:      	callq	*%rcx
    6fa3:      	jmp	0x3445 <kprobe_unwind_perl+0x3445>
    6fa8:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    6fb2:      	movq	%rax, 0x36(%rsp)
    6fb7:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    6fc1:      	movq	%rax, 0x30(%rsp)
    6fc6:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    6fd0:      	movq	%rax, 0x28(%rsp)
    6fd5:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    6fdf:      	movq	%rax, 0x20(%rsp)
    6fe4:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    6fee:      	movq	%rax, 0x18(%rsp)
    6ff3:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6ffd:      	movq	%rax, 0x10(%rsp)
    7002:      	leaq	0x10(%rsp), %rdi
    7007:      	movl	$0x2e, %eax
    700c:      	movl	$0x6, %ecx
    7011:      	movl	0x50(%rsp), %edx
    7015:      	movl	$0x2e, %esi
    701a:      	xorl	%eax, %eax
    701c:      	callq	*%rcx
    701e:      	cmpl	$0x3, %ebp
    7021:      	movq	0x98(%rsp), %rcx
    7029:      	je	0x3904 <kprobe_unwind_perl+0x3904>
    702f:      	jmp	0x5636 <kprobe_unwind_perl+0x5636>
    7034:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    703e:      	movq	%rax, 0x36(%rsp)
    7043:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    704d:      	movq	%rax, 0x30(%rsp)
    7052:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    705c:      	movq	%rax, 0x28(%rsp)
    7061:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    706b:      	movq	%rax, 0x20(%rsp)
    7070:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    707a:      	movq	%rax, 0x18(%rsp)
    707f:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7089:      	movq	%rax, 0x10(%rsp)
    708e:      	leaq	0x10(%rsp), %rdi
    7093:      	movl	$0x2e, %eax
    7098:      	movl	$0x6, %ecx
    709d:      	movl	0x50(%rsp), %edx
    70a1:      	movl	$0x2e, %esi
    70a6:      	xorl	%eax, %eax
    70a8:      	callq	*%rcx
    70aa:      	jmp	0x365c <kprobe_unwind_perl+0x365c>
    70af:      	movabsq	$0xa7667655f7663, %rax  # imm = 0xA7667655F7663
    70b9:      	movq	%rax, 0x35(%rsp)
    70be:      	movabsq	$0x5f76635f65766c6f, %rax # imm = 0x5F76635F65766C6F
    70c8:      	movq	%rax, 0x30(%rsp)
    70cd:      	movabsq	$0x736572206e692029, %rax # imm = 0x736572206E692029
    70d7:      	movq	%rax, 0x28(%rsp)
    70dc:      	movabsq	$0x28726573755f6461, %rax # imm = 0x28726573755F6461
    70e6:      	movq	%rax, 0x20(%rsp)
    70eb:      	movabsq	$0x65725f65626f7270, %rax # imm = 0x65725F65626F7270
    70f5:      	movq	%rax, 0x18(%rsp)
    70fa:      	movabsq	$0x5f66706220646142, %rax # imm = 0x5F66706220646142
    7104:      	movq	%rax, 0x10(%rsp)
    7109:      	leaq	0x10(%rsp), %rdi
    710e:      	movl	$0x2d, %eax
    7113:      	movl	$0x6, %ecx
    7118:      	movl	$0x2d, %esi
    711d:      	xorl	%eax, %eax
    711f:      	callq	*%rcx
    7121:      	jmp	0x205b <kprobe_unwind_perl+0x205b>
    7126:      	movl	0x5c(%rsp), %eax
    712a:      	andl	$0x1f, %eax
    712d:      	cmpl	$0xd, %eax
    7130:      	jne	0x76a5 <kprobe_unwind_perl+0x76a5>
    7136:      	movzbl	0x1f(%r14), %eax
    713b:      	addq	%rbp, %rax
    713e:      	leaq	0x50(%rsp), %rdi
    7143:      	movl	$0x8, %ecx
    7148:      	movl	$0x70, %r8d
    714e:      	movzbl	0x1f(%r14), %edx
    7153:      	addq	%rbp, %rdx
    7156:      	movl	$0x8, %esi
    715b:      	callq	*%r8
    715e:      	testq	%rax, %rax
    7161:      	jne	0x529f <kprobe_unwind_perl+0x529f>
    7167:      	movzbl	0x21(%r14), %eax
    716c:      	addq	0x50(%rsp), %rax
    7171:      	leaq	0x70(%rsp), %rdi
    7176:      	movl	$0x4, %ecx
    717b:      	movl	$0x70, %r8d
    7181:      	movzbl	0x21(%r14), %edx
    7186:      	addq	0x50(%rsp), %rdx
    718b:      	movl	$0x4, %esi
    7190:      	callq	*%r8
    7193:      	testq	%rax, %rax
    7196:      	jne	0x529f <kprobe_unwind_perl+0x529f>
    719c:      	testb	$-0x80, 0x71(%rsp)
    71a1:      	jne	0x8422 <kprobe_unwind_perl+0x8422>
    71a7:      	movzbl	0x22(%r14), %eax
    71ac:      	addq	0x50(%rsp), %rax
    71b1:      	leaq	0x60(%rsp), %rbp
    71b6:      	movl	$0x8, %ecx
    71bb:      	movl	$0x70, %r8d
    71c1:      	movzbl	0x22(%r14), %edx
    71c6:      	addq	0x50(%rsp), %rdx
    71cb:      	movq	%rbp, %rdi
    71ce:      	movl	$0x8, %esi
    71d3:      	callq	*%r8
    71d6:      	testq	%rax, %rax
    71d9:      	jne	0x529f <kprobe_unwind_perl+0x529f>
    71df:      	movq	0x60(%rsp), %rax
    71e4:      	testq	%rax, %rax
    71e7:      	je	0x529f <kprobe_unwind_perl+0x529f>
    71ed:      	movq	(%rip), %rcx            # 0x71f4 <kprobe_unwind_perl+0x71f4>
    71f4:      	cmpl	$0x0, (%rcx)
    71f7:      	jne	0x8faf <kprobe_unwind_perl+0x8faf>
    71fd:      	movzbl	0x1e(%r14), %ecx
    7202:      	addq	%rax, %rcx
    7205:      	leaq	0x6c(%rsp), %rdi
    720a:      	movl	$0x4, %eax
    720f:      	movl	$0x70, %r8d
    7215:      	movzbl	0x1e(%r14), %edx
    721a:      	addq	0x60(%rsp), %rdx
    721f:      	movl	$0x4, %esi
    7224:      	callq	*%r8
    7227:      	testq	%rax, %rax
    722a:      	jne	0x529f <kprobe_unwind_perl+0x529f>
    7230:      	movl	$0x801f, %eax           # imm = 0x801F
    7235:      	andl	0x6c(%rsp), %eax
    7239:      	cmpl	$0x8009, %eax           # imm = 0x8009
    723e:      	jne	0x89e6 <kprobe_unwind_perl+0x89e6>
    7244:      	movzbl	0x20(%r14), %eax
    7249:      	addq	0x60(%rsp), %rax
    724e:      	leaq	0x88(%rsp), %rdi
    7256:      	movl	$0x8, %ecx
    725b:      	movl	$0x70, %r8d
    7261:      	movzbl	0x20(%r14), %edx
    7266:      	addq	0x60(%rsp), %rdx
    726b:      	movl	$0x8, %esi
    7270:      	callq	*%r8
    7273:      	testq	%rax, %rax
    7276:      	jne	0x529f <kprobe_unwind_perl+0x529f>
    727c:      	movzbl	0x23(%r14), %eax
    7281:      	addq	0x88(%rsp), %rax
    7289:      	leaq	0x78(%rsp), %rdi
    728e:      	movl	$0x8, %ecx
    7293:      	movl	$0x70, %r8d
    7299:      	movzbl	0x23(%r14), %edx
    729e:      	addq	0x88(%rsp), %rdx
    72a6:      	movl	$0x8, %esi
    72ab:      	callq	*%r8
    72ae:      	testq	%rax, %rax
    72b1:      	jne	0x529f <kprobe_unwind_perl+0x529f>
    72b7:      	movq	0x78(%rsp), %rax
    72bc:      	movq	%rax, 0x80(%rsp)
    72c4:      	testq	%rax, %rax
    72c7:      	je	0x731d <kprobe_unwind_perl+0x731d>
    72c9:      	movq	(%rip), %rax            # 0x72d0 <kprobe_unwind_perl+0x72d0>
    72d0:      	cmpl	$0x0, (%rax)
    72d3:      	je	0x7332 <kprobe_unwind_perl+0x7332>
    72d5:      	movabsq	$0x2578302074612056, %rax # imm = 0x2578302074612056
    72df:      	movq	%rax, 0x18(%rsp)
    72e4:      	movabsq	$0x474520646e756f46, %rax # imm = 0x474520646E756F46
    72ee:      	movq	%rax, 0x10(%rsp)
    72f3:      	movl	$0xa786c, 0x20(%rsp)    # imm = 0xA786C
    72fb:      	leaq	0x10(%rsp), %rdi
    7300:      	movl	$0x14, %eax
    7305:      	movl	$0x6, %ecx
    730a:      	movq	0x78(%rsp), %rdx
    730f:      	movl	$0x14, %esi
    7314:      	xorl	%eax, %eax
    7316:      	callq	*%rcx
    7318:      	leaq	0x78(%rsp), %rbp
    731d:      	movq	(%rbp), %rax
    7321:      	movq	%rax, 0x80(%rsp)
    7329:      	testq	%rax, %rax
    732c:      	je	0x4caa <kprobe_unwind_perl+0x4caa>
    7332:      	movq	(%r12), %rax
    7336:      	movq	%rax, 0x90(%rsp)
    733e:      	movq	(%rip), %rax            # 0x7345 <kprobe_unwind_perl+0x7345>
    7345:      	cmpl	$0x0, (%rax)
    7348:      	jne	0x915f <kprobe_unwind_perl+0x915f>
    734e:      	movl	0x2c0(%r15), %eax
    7355:      	cmpq	$0x7e, %rax
    7359:      	ja	0x1193 <kprobe_unwind_perl+0x1193>
    735f:      	xorl	%ecx, %ecx
    7361:      	movzbl	0xf(%rsp), %edx
    7366:      	movb	%dl, %cl
    7368:      	leal	0x1(,%rcx,2), %ebp
    736f:      	leal	0x1(%rax), %ecx
    7372:      	movl	%ecx, 0x2c0(%r15)
    7379:      	leaq	(%rax,%rax,2), %rax
    737d:      	movq	0x80(%rsp), %rcx
    7385:      	movq	%rcx, 0x2d0(%r15,%rax,8)
    738d:      	movq	0x90(%rsp), %rcx
    7395:      	movq	%rcx, 0x2d8(%r15,%rax,8)
    739d:      	movb	$0x7, 0x2e0(%r15,%rax,8)
    73a6:      	movl	$0x0, 0x2e1(%r15,%rax,8)
    73b2:      	movl	$0x0, 0x2e4(%r15,%rax,8)
    73be:      	movq	$0x0, 0xf40(%r15)
    73c9:      	movzbl	0x1a(%r14), %eax
    73ce:      	addq	%r13, %rax
    73d1:      	movl	$0x8, %ecx
    73d6:      	movl	$0x70, %r8d
    73dc:      	movzbl	0x1a(%r14), %edx
    73e1:      	addq	%r13, %rdx
    73e4:      	movq	%r12, %rdi
    73e7:      	movl	$0x8, %esi
    73ec:      	callq	*%r8
    73ef:      	testq	%rax, %rax
    73f2:      	jne	0x4caa <kprobe_unwind_perl+0x4caa>
    73f8:      	movq	(%rip), %rax            # 0x73ff <kprobe_unwind_perl+0x73ff>
    73ff:      	cmpl	$0x0, (%rax)
    7402:      	je	0x55c6 <kprobe_unwind_perl+0x55c6>
    7408:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    7412:      	movq	%rax, 0x26(%rsp)
    7417:      	movabsq	$0x30206b6361747320, %rax # imm = 0x30206B6361747320
    7421:      	movq	%rax, 0x20(%rsp)
    7426:      	movabsq	$0x747865746e6f6320, %rax # imm = 0x747865746E6F6320
    7430:      	movq	%rax, 0x18(%rsp)
    7435:      	movabsq	$0x6d6f726620504f43, %rax # imm = 0x6D6F726620504F43
    743f:      	movq	%rax, 0x10(%rsp)
    7444:      	leaq	0x10(%rsp), %rdi
    7449:      	movl	$0x1e, %eax
    744e:      	movl	$0x6, %ecx
    7453:      	movq	(%r12), %rdx
    7457:      	movl	$0x1e, %esi
    745c:      	xorl	%eax, %eax
    745e:      	callq	*%rcx
    7460:      	jmp	0x55c6 <kprobe_unwind_perl+0x55c6>
    7465:      	movabsq	$0x7025207461207972, %rax # imm = 0x7025207461207972
    746f:      	movq	%rax, 0x30(%rsp)
    7474:      	movabsq	$0x746e65206b636174, %rax # imm = 0x746E65206B636174
    747e:      	movq	%rax, 0x28(%rsp)
    7483:      	movabsq	$0x7320747865746e6f, %rax # imm = 0x7320747865746E6F
    748d:      	movq	%rax, 0x20(%rsp)
    7492:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    749c:      	movq	%rax, 0x18(%rsp)
    74a1:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    74ab:      	movq	%rax, 0x10(%rsp)
    74b0:      	movw	$0xa, 0x38(%rsp)
    74b7:      	leaq	0x10(%rsp), %rdi
    74bc:      	movl	$0x2a, %eax
    74c1:      	movl	$0x6, %ecx
    74c6:      	movl	$0x2a, %esi
    74cb:      	movq	%r13, %rdx
    74ce:      	xorl	%eax, %eax
    74d0:      	callq	*%rcx
    74d2:      	jmp	0x3955 <kprobe_unwind_perl+0x3955>
    74d7:      	movq	(%rip), %rax            # 0x74de <kprobe_unwind_perl+0x74de>
    74de:      	cmpl	$0x0, (%rax)
    74e1:      	je	0x2528 <kprobe_unwind_perl+0x2528>
    74e7:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    74f1:      	movq	%rax, 0x2e(%rsp)
    74f6:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    7500:      	movq	%rax, 0x28(%rsp)
    7505:      	movabsq	$0x50472d74756f6874, %rax # imm = 0x50472D74756F6874
    750f:      	movq	%rax, 0x20(%rsp)
    7514:      	movabsq	$0x69772d5647206465, %rax # imm = 0x69772D5647206465
    751e:      	movq	%rax, 0x18(%rsp)
    7523:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    752d:      	movq	%rax, 0x10(%rsp)
    7532:      	leaq	0x10(%rsp), %rdi
    7537:      	movl	$0x26, %eax
    753c:      	movl	$0x6, %ecx
    7541:      	movl	0x6c(%rsp), %edx
    7545:      	movl	$0x26, %esi
    754a:      	jmp	0x4b2c <kprobe_unwind_perl+0x4b2c>
    754f:      	movq	(%rip), %rax            # 0x7556 <kprobe_unwind_perl+0x7556>
    7556:      	cmpl	$0x0, (%rax)
    7559:      	je	0x4caa <kprobe_unwind_perl+0x4caa>
    755f:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    7569:      	movq	%rax, 0x36(%rsp)
    756e:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    7578:      	movq	%rax, 0x30(%rsp)
    757d:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    7587:      	movq	%rax, 0x28(%rsp)
    758c:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    7596:      	movq	%rax, 0x20(%rsp)
    759b:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    75a5:      	movq	%rax, 0x18(%rsp)
    75aa:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    75b4:      	movq	%rax, 0x10(%rsp)
    75b9:      	leaq	0x10(%rsp), %rdi
    75be:      	movl	$0x2e, %eax
    75c3:      	movl	$0x6, %ecx
    75c8:      	movl	0x74(%rsp), %edx
    75cc:      	movl	$0x2e, %esi
    75d1:      	jmp	0x7709 <kprobe_unwind_perl+0x7709>
    75d6:      	movabsq	$0x6c25783020746120, %rax # imm = 0x6C25783020746120
    75e0:      	movq	%rax, 0x18(%rsp)
    75e5:      	movabsq	$0x564720646e756f46, %rax # imm = 0x564720646E756F46
    75ef:      	movq	%rax, 0x10(%rsp)
    75f4:      	movl	$0xa786c, 0x1f(%rsp)    # imm = 0xA786C
    75fc:      	leaq	0x10(%rsp), %rdi
    7601:      	movl	$0x13, %eax
    7606:      	movl	$0x6, %ecx
    760b:      	movq	0x60(%rsp), %rdx
    7610:      	movl	$0x13, %esi
    7615:      	xorl	%eax, %eax
    7617:      	callq	*%rcx
    7619:      	movq	0x60(%rsp), %rax
    761e:      	jmp	0x1c95 <kprobe_unwind_perl+0x1c95>
    7623:      	movq	(%rip), %rax            # 0x762a <kprobe_unwind_perl+0x762a>
    762a:      	cmpl	$0x0, (%rax)
    762d:      	je	0x3945 <kprobe_unwind_perl+0x3945>
    7633:      	movabsq	$0xa782578302f78, %rax  # imm = 0xA782578302F78
    763d:      	movq	%rax, 0x2e(%rsp)
    7642:      	movabsq	$0x2f78257830207367, %rax # imm = 0x2F78257830207367
    764c:      	movq	%rax, 0x28(%rsp)
    7651:      	movabsq	$0x616c66202c564320, %rax # imm = 0x616C66202C564320
    765b:      	movq	%rax, 0x20(%rsp)
    7660:      	movabsq	$0x44454d414e206465, %rax # imm = 0x44454D414E206465
    766a:      	movq	%rax, 0x18(%rsp)
    766f:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    7679:      	movq	%rax, 0x10(%rsp)
    767e:      	leaq	0x10(%rsp), %rdi
    7683:      	movl	$0x26, %eax
    7688:      	movl	$0x6, %r8d
    768e:      	movl	0x5c(%rsp), %edx
    7692:      	movl	0x70(%rsp), %ecx
    7696:      	movl	$0x26, %esi
    769b:      	xorl	%eax, %eax
    769d:      	callq	*%r8
    76a0:      	jmp	0x3945 <kprobe_unwind_perl+0x3945>
    76a5:      	movq	(%rip), %rax            # 0x76ac <kprobe_unwind_perl+0x76ac>
    76ac:      	cmpl	$0x0, (%rax)
    76af:      	je	0x4caa <kprobe_unwind_perl+0x4caa>
    76b5:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    76bf:      	movq	%rax, 0x26(%rsp)
    76c4:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    76ce:      	movq	%rax, 0x20(%rsp)
    76d3:      	movabsq	$0x5643565020612074, %rax # imm = 0x5643565020612074
    76dd:      	movq	%rax, 0x18(%rsp)
    76e2:      	movabsq	$0x6f6e207369205643, %rax # imm = 0x6F6E207369205643
    76ec:      	movq	%rax, 0x10(%rsp)
    76f1:      	leaq	0x10(%rsp), %rdi
    76f6:      	movl	$0x1e, %eax
    76fb:      	movl	$0x6, %ecx
    7700:      	movl	0x5c(%rsp), %edx
    7704:      	movl	$0x1e, %esi
    7709:      	xorl	%eax, %eax
    770b:      	callq	*%rcx
    770d:      	jmp	0x4caa <kprobe_unwind_perl+0x4caa>
    7712:      	movabsq	$0x7825783020786320, %rax # imm = 0x7825783020786320
    771c:      	movq	%rax, 0x18(%rsp)
    7721:      	movabsq	$0x6c72657020746f47, %rax # imm = 0x6C72657020746F47
    772b:      	movq	%rax, 0x10(%rsp)
    7730:      	movw	$0xa, 0x20(%rsp)
    7737:      	leaq	0x10(%rsp), %rdi
    773c:      	movl	$0x12, %eax
    7741:      	movl	$0x6, %ecx
    7746:      	movzbl	0xe(%rsp), %edx
    774b:      	movl	$0x12, %esi
    7750:      	xorl	%eax, %eax
    7752:      	callq	*%rcx
    7754:      	jmp	0x3e39 <kprobe_unwind_perl+0x3e39>
    7759:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    7763:      	movq	%rax, 0x36(%rsp)
    7768:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    7772:      	movq	%rax, 0x30(%rsp)
    7777:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    7781:      	movq	%rax, 0x28(%rsp)
    7786:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    7790:      	movq	%rax, 0x20(%rsp)
    7795:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    779f:      	movq	%rax, 0x18(%rsp)
    77a4:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    77ae:      	movq	%rax, 0x10(%rsp)
    77b3:      	leaq	0x10(%rsp), %rdi
    77b8:      	movl	$0x2e, %eax
    77bd:      	movl	$0x6, %ecx
    77c2:      	movl	0x50(%rsp), %edx
    77c6:      	movl	$0x2e, %esi
    77cb:      	xorl	%eax, %eax
    77cd:      	callq	*%rcx
    77cf:      	cmpl	$0x3, %ebp
    77d2:      	movq	0x98(%rsp), %rcx
    77da:      	je	0x42f0 <kprobe_unwind_perl+0x42f0>
    77e0:      	jmp	0x5636 <kprobe_unwind_perl+0x5636>
    77e5:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    77ef:      	movq	%rax, 0x36(%rsp)
    77f4:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    77fe:      	movq	%rax, 0x30(%rsp)
    7803:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    780d:      	movq	%rax, 0x28(%rsp)
    7812:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    781c:      	movq	%rax, 0x20(%rsp)
    7821:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    782b:      	movq	%rax, 0x18(%rsp)
    7830:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    783a:      	movq	%rax, 0x10(%rsp)
    783f:      	leaq	0x10(%rsp), %rdi
    7844:      	movl	$0x2e, %eax
    7849:      	movl	$0x6, %ecx
    784e:      	movl	0x50(%rsp), %edx
    7852:      	movl	$0x2e, %esi
    7857:      	xorl	%eax, %eax
    7859:      	callq	*%rcx
    785b:      	jmp	0x40c3 <kprobe_unwind_perl+0x40c3>
    7860:      	movabsq	$0xa7667655f7663, %rax  # imm = 0xA7667655F7663
    786a:      	movq	%rax, 0x35(%rsp)
    786f:      	movabsq	$0x5f76635f65766c6f, %rax # imm = 0x5F76635F65766C6F
    7879:      	movq	%rax, 0x30(%rsp)
    787e:      	movabsq	$0x736572206e692029, %rax # imm = 0x736572206E692029
    7888:      	movq	%rax, 0x28(%rsp)
    788d:      	movabsq	$0x28726573755f6461, %rax # imm = 0x28726573755F6461
    7897:      	movq	%rax, 0x20(%rsp)
    789c:      	movabsq	$0x65725f65626f7270, %rax # imm = 0x65725F65626F7270
    78a6:      	movq	%rax, 0x18(%rsp)
    78ab:      	movabsq	$0x5f66706220646142, %rax # imm = 0x5F66706220646142
    78b5:      	movq	%rax, 0x10(%rsp)
    78ba:      	leaq	0x10(%rsp), %rdi
    78bf:      	movl	$0x2d, %eax
    78c4:      	movl	$0x6, %ecx
    78c9:      	movl	$0x2d, %esi
    78ce:      	xorl	%eax, %eax
    78d0:      	callq	*%rcx
    78d2:      	jmp	0x2b01 <kprobe_unwind_perl+0x2b01>
    78d7:      	movl	0x5c(%rsp), %eax
    78db:      	andl	$0x1f, %eax
    78de:      	cmpl	$0xd, %eax
    78e1:      	jne	0x7fb3 <kprobe_unwind_perl+0x7fb3>
    78e7:      	movzbl	0x1f(%r14), %eax
    78ec:      	addq	%rbp, %rax
    78ef:      	leaq	0x50(%rsp), %rdi
    78f4:      	movl	$0x8, %ecx
    78f9:      	movl	$0x70, %r8d
    78ff:      	movzbl	0x1f(%r14), %edx
    7904:      	addq	%rbp, %rdx
    7907:      	movl	$0x8, %esi
    790c:      	callq	*%r8
    790f:      	testq	%rax, %rax
    7912:      	jne	0x6450 <kprobe_unwind_perl+0x6450>
    7918:      	movzbl	0x21(%r14), %eax
    791d:      	addq	0x50(%rsp), %rax
    7922:      	leaq	0x70(%rsp), %rdi
    7927:      	movl	$0x4, %ecx
    792c:      	movl	$0x70, %r8d
    7932:      	movzbl	0x21(%r14), %edx
    7937:      	addq	0x50(%rsp), %rdx
    793c:      	movl	$0x4, %esi
    7941:      	callq	*%r8
    7944:      	testq	%rax, %rax
    7947:      	jne	0x6450 <kprobe_unwind_perl+0x6450>
    794d:      	testb	$-0x80, 0x71(%rsp)
    7952:      	jne	0x882b <kprobe_unwind_perl+0x882b>
    7958:      	movzbl	0x22(%r14), %eax
    795d:      	addq	0x50(%rsp), %rax
    7962:      	leaq	0x60(%rsp), %rbp
    7967:      	movl	$0x8, %ecx
    796c:      	movl	$0x70, %r8d
    7972:      	movzbl	0x22(%r14), %edx
    7977:      	addq	0x50(%rsp), %rdx
    797c:      	movq	%rbp, %rdi
    797f:      	movl	$0x8, %esi
    7984:      	callq	*%r8
    7987:      	testq	%rax, %rax
    798a:      	jne	0x6450 <kprobe_unwind_perl+0x6450>
    7990:      	movq	0x60(%rsp), %rax
    7995:      	testq	%rax, %rax
    7998:      	je	0x6450 <kprobe_unwind_perl+0x6450>
    799e:      	movq	(%rip), %rcx            # 0x79a5 <kprobe_unwind_perl+0x79a5>
    79a5:      	cmpl	$0x0, (%rcx)
    79a8:      	jne	0x9087 <kprobe_unwind_perl+0x9087>
    79ae:      	movzbl	0x1e(%r14), %ecx
    79b3:      	addq	%rax, %rcx
    79b6:      	leaq	0x6c(%rsp), %rdi
    79bb:      	movl	$0x4, %eax
    79c0:      	movl	$0x70, %r8d
    79c6:      	movzbl	0x1e(%r14), %edx
    79cb:      	addq	0x60(%rsp), %rdx
    79d0:      	movl	$0x4, %esi
    79d5:      	callq	*%r8
    79d8:      	testq	%rax, %rax
    79db:      	jne	0x6450 <kprobe_unwind_perl+0x6450>
    79e1:      	movl	$0x801f, %eax           # imm = 0x801F
    79e6:      	andl	0x6c(%rsp), %eax
    79ea:      	cmpl	$0x8009, %eax           # imm = 0x8009
    79ef:      	jne	0x8bad <kprobe_unwind_perl+0x8bad>
    79f5:      	movzbl	0x20(%r14), %eax
    79fa:      	addq	0x60(%rsp), %rax
    79ff:      	leaq	0x88(%rsp), %rdi
    7a07:      	movl	$0x8, %ecx
    7a0c:      	movl	$0x70, %r8d
    7a12:      	movzbl	0x20(%r14), %edx
    7a17:      	addq	0x60(%rsp), %rdx
    7a1c:      	movl	$0x8, %esi
    7a21:      	callq	*%r8
    7a24:      	testq	%rax, %rax
    7a27:      	jne	0x6450 <kprobe_unwind_perl+0x6450>
    7a2d:      	movzbl	0x23(%r14), %eax
    7a32:      	addq	0x88(%rsp), %rax
    7a3a:      	leaq	0x78(%rsp), %rdi
    7a3f:      	movl	$0x8, %ecx
    7a44:      	movl	$0x70, %r8d
    7a4a:      	movzbl	0x23(%r14), %edx
    7a4f:      	addq	0x88(%rsp), %rdx
    7a57:      	movl	$0x8, %esi
    7a5c:      	callq	*%r8
    7a5f:      	testq	%rax, %rax
    7a62:      	jne	0x6450 <kprobe_unwind_perl+0x6450>
    7a68:      	movq	0x78(%rsp), %rax
    7a6d:      	movq	%rax, 0x80(%rsp)
    7a75:      	testq	%rax, %rax
    7a78:      	je	0x7ace <kprobe_unwind_perl+0x7ace>
    7a7a:      	movq	(%rip), %rax            # 0x7a81 <kprobe_unwind_perl+0x7a81>
    7a81:      	cmpl	$0x0, (%rax)
    7a84:      	je	0x7ae3 <kprobe_unwind_perl+0x7ae3>
    7a86:      	movabsq	$0x2578302074612056, %rax # imm = 0x2578302074612056
    7a90:      	movq	%rax, 0x18(%rsp)
    7a95:      	movabsq	$0x474520646e756f46, %rax # imm = 0x474520646E756F46
    7a9f:      	movq	%rax, 0x10(%rsp)
    7aa4:      	movl	$0xa786c, 0x20(%rsp)    # imm = 0xA786C
    7aac:      	leaq	0x10(%rsp), %rdi
    7ab1:      	movl	$0x14, %eax
    7ab6:      	movl	$0x6, %ecx
    7abb:      	movq	0x78(%rsp), %rdx
    7ac0:      	movl	$0x14, %esi
    7ac5:      	xorl	%eax, %eax
    7ac7:      	callq	*%rcx
    7ac9:      	leaq	0x78(%rsp), %rbp
    7ace:      	movq	(%rbp), %rax
    7ad2:      	movq	%rax, 0x80(%rsp)
    7ada:      	testq	%rax, %rax
    7add:      	je	0x5e90 <kprobe_unwind_perl+0x5e90>
    7ae3:      	movq	(%r12), %rax
    7ae7:      	movq	%rax, 0x90(%rsp)
    7aef:      	movq	(%rip), %rax            # 0x7af6 <kprobe_unwind_perl+0x7af6>
    7af6:      	cmpl	$0x0, (%rax)
    7af9:      	jne	0x91ea <kprobe_unwind_perl+0x91ea>
    7aff:      	movl	0x2c0(%r15), %eax
    7b06:      	cmpq	$0x7e, %rax
    7b0a:      	ja	0x1193 <kprobe_unwind_perl+0x1193>
    7b10:      	xorl	%ecx, %ecx
    7b12:      	movzbl	0xf(%rsp), %edx
    7b17:      	movb	%dl, %cl
    7b19:      	leal	0x1(,%rcx,2), %ebp
    7b20:      	leal	0x1(%rax), %ecx
    7b23:      	movl	%ecx, 0x2c0(%r15)
    7b2a:      	leaq	(%rax,%rax,2), %rax
    7b2e:      	movq	0x80(%rsp), %rcx
    7b36:      	movq	%rcx, 0x2d0(%r15,%rax,8)
    7b3e:      	movq	0x90(%rsp), %rcx
    7b46:      	movq	%rcx, 0x2d8(%r15,%rax,8)
    7b4e:      	movb	$0x7, 0x2e0(%r15,%rax,8)
    7b57:      	movl	$0x0, 0x2e1(%r15,%rax,8)
    7b63:      	movl	$0x0, 0x2e4(%r15,%rax,8)
    7b6f:      	movq	$0x0, 0xf40(%r15)
    7b7a:      	movzbl	0x1a(%r14), %eax
    7b7f:      	addq	%r13, %rax
    7b82:      	movl	$0x8, %ecx
    7b87:      	movl	$0x70, %r8d
    7b8d:      	movzbl	0x1a(%r14), %edx
    7b92:      	addq	%r13, %rdx
    7b95:      	movq	%r12, %rdi
    7b98:      	movl	$0x8, %esi
    7b9d:      	callq	*%r8
    7ba0:      	testq	%rax, %rax
    7ba3:      	jne	0x5e90 <kprobe_unwind_perl+0x5e90>
    7ba9:      	movq	(%rip), %rax            # 0x7bb0 <kprobe_unwind_perl+0x7bb0>
    7bb0:      	cmpl	$0x0, (%rax)
    7bb3:      	je	0x67c4 <kprobe_unwind_perl+0x67c4>
    7bb9:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    7bc3:      	movq	%rax, 0x26(%rsp)
    7bc8:      	movabsq	$0x30206b6361747320, %rax # imm = 0x30206B6361747320
    7bd2:      	movq	%rax, 0x20(%rsp)
    7bd7:      	movabsq	$0x747865746e6f6320, %rax # imm = 0x747865746E6F6320
    7be1:      	movq	%rax, 0x18(%rsp)
    7be6:      	movabsq	$0x6d6f726620504f43, %rax # imm = 0x6D6F726620504F43
    7bf0:      	movq	%rax, 0x10(%rsp)
    7bf5:      	leaq	0x10(%rsp), %rdi
    7bfa:      	movl	$0x1e, %eax
    7bff:      	movl	$0x6, %ecx
    7c04:      	movq	(%r12), %rdx
    7c08:      	movl	$0x1e, %esi
    7c0d:      	xorl	%eax, %eax
    7c0f:      	callq	*%rcx
    7c11:      	jmp	0x67c4 <kprobe_unwind_perl+0x67c4>
    7c16:      	movabsq	$0x7025207461207972, %rax # imm = 0x7025207461207972
    7c20:      	movq	%rax, 0x30(%rsp)
    7c25:      	movabsq	$0x746e65206b636174, %rax # imm = 0x746E65206B636174
    7c2f:      	movq	%rax, 0x28(%rsp)
    7c34:      	movabsq	$0x7320747865746e6f, %rax # imm = 0x7320747865746E6F
    7c3e:      	movq	%rax, 0x20(%rsp)
    7c43:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    7c4d:      	movq	%rax, 0x18(%rsp)
    7c52:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7c5c:      	movq	%rax, 0x10(%rsp)
    7c61:      	movw	$0xa, 0x38(%rsp)
    7c68:      	leaq	0x10(%rsp), %rdi
    7c6d:      	movl	$0x2a, %eax
    7c72:      	movl	$0x6, %ecx
    7c77:      	movl	$0x2a, %esi
    7c7c:      	movq	%r13, %rdx
    7c7f:      	xorl	%eax, %eax
    7c81:      	callq	*%rcx
    7c83:      	jmp	0x4341 <kprobe_unwind_perl+0x4341>
    7c88:      	movq	(%rip), %rax            # 0x7c8f <kprobe_unwind_perl+0x7c8f>
    7c8f:      	cmpl	$0x0, (%rax)
    7c92:      	je	0x2e32 <kprobe_unwind_perl+0x2e32>
    7c98:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    7ca2:      	movq	%rax, 0x2e(%rsp)
    7ca7:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    7cb1:      	movq	%rax, 0x28(%rsp)
    7cb6:      	movabsq	$0x50472d74756f6874, %rax # imm = 0x50472D74756F6874
    7cc0:      	movq	%rax, 0x20(%rsp)
    7cc5:      	movabsq	$0x69772d5647206465, %rax # imm = 0x69772D5647206465
    7ccf:      	movq	%rax, 0x18(%rsp)
    7cd4:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    7cde:      	movq	%rax, 0x10(%rsp)
    7ce3:      	leaq	0x10(%rsp), %rdi
    7ce8:      	movl	$0x26, %eax
    7ced:      	movl	$0x6, %ecx
    7cf2:      	movl	0x6c(%rsp), %edx
    7cf6:      	movl	$0x26, %esi
    7cfb:      	jmp	0x54da <kprobe_unwind_perl+0x54da>
    7d00:      	movabsq	$0xa786c2578303d, %rax  # imm = 0xA786C2578303D
    7d0a:      	movq	%rax, 0x30(%rsp)
    7d0f:      	movabsq	$0x7663202c786c2578, %rax # imm = 0x7663202C786C2578
    7d19:      	movq	%rax, 0x28(%rsp)
    7d1e:      	movabsq	$0x303d706f6320656d, %rax # imm = 0x303D706F6320656D
    7d28:      	movq	%rax, 0x20(%rsp)
    7d2d:      	movabsq	$0x617266206c726570, %rax # imm = 0x617266206C726570
    7d37:      	movq	%rax, 0x18(%rsp)
    7d3c:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    7d46:      	movq	%rax, 0x10(%rsp)
    7d4b:      	leaq	0x10(%rsp), %rdi
    7d50:      	movl	$0x28, %eax
    7d55:      	movl	$0x6, %r8d
    7d5b:      	movl	$0x28, %esi
    7d60:      	movq	0x80(%rsp), %rdx
    7d68:      	movq	0x90(%rsp), %rcx
    7d70:      	xorl	%eax, %eax
    7d72:      	callq	*%r8
    7d75:      	movl	0x2c0(%r15), %eax
    7d7c:      	cmpq	$0x7f, %rax
    7d80:      	jae	0x1193 <kprobe_unwind_perl+0x1193>
    7d86:      	xorl	%ecx, %ecx
    7d88:      	movzbl	0xf(%rsp), %edx
    7d8d:      	movb	%dl, %cl
    7d8f:      	leal	0x1(,%rcx,2), %ebp
    7d96:      	leal	0x1(%rax), %ecx
    7d99:      	movl	%ecx, 0x2c0(%r15)
    7da0:      	leaq	(%rax,%rax,2), %rax
    7da4:      	movq	0x80(%rsp), %rcx
    7dac:      	movq	%rcx, 0x2d0(%r15,%rax,8)
    7db4:      	movq	0x90(%rsp), %rcx
    7dbc:      	movq	%rcx, 0x2d8(%r15,%rax,8)
    7dc4:      	movb	$0x7, 0x2e0(%r15,%rax,8)
    7dcd:      	movl	$0x0, 0x2e1(%r15,%rax,8)
    7dd9:      	movl	$0x0, 0x2e4(%r15,%rax,8)
    7de5:      	movq	$0x0, 0xf40(%r15)
    7df0:      	jmp	0x655 <kprobe_unwind_perl+0x655>
    7df5:      	movq	(%rip), %rax            # 0x7dfc <kprobe_unwind_perl+0x7dfc>
    7dfc:      	cmpl	$0x0, (%rax)
    7dff:      	je	0x5e90 <kprobe_unwind_perl+0x5e90>
    7e05:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    7e0f:      	movq	%rax, 0x36(%rsp)
    7e14:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    7e1e:      	movq	%rax, 0x30(%rsp)
    7e23:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    7e2d:      	movq	%rax, 0x28(%rsp)
    7e32:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    7e3c:      	movq	%rax, 0x20(%rsp)
    7e41:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    7e4b:      	movq	%rax, 0x18(%rsp)
    7e50:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7e5a:      	movq	%rax, 0x10(%rsp)
    7e5f:      	leaq	0x10(%rsp), %rdi
    7e64:      	movl	$0x2e, %eax
    7e69:      	movl	$0x6, %ecx
    7e6e:      	movl	0x74(%rsp), %edx
    7e72:      	movl	$0x2e, %esi
    7e77:      	jmp	0x8017 <kprobe_unwind_perl+0x8017>
    7e7c:      	movabsq	$0x6c25783020746120, %rax # imm = 0x6C25783020746120
    7e86:      	movq	%rax, 0x18(%rsp)
    7e8b:      	movabsq	$0x564720646e756f46, %rax # imm = 0x564720646E756F46
    7e95:      	movq	%rax, 0x10(%rsp)
    7e9a:      	movl	$0xa786c, 0x1f(%rsp)    # imm = 0xA786C
    7ea2:      	leaq	0x10(%rsp), %rdi
    7ea7:      	movl	$0x13, %eax
    7eac:      	movl	$0x6, %ecx
    7eb1:      	movq	0x60(%rsp), %rdx
    7eb6:      	movl	$0x13, %esi
    7ebb:      	xorl	%eax, %eax
    7ebd:      	callq	*%rcx
    7ebf:      	movq	0x60(%rsp), %rax
    7ec4:      	jmp	0x273b <kprobe_unwind_perl+0x273b>
    7ec9:      	movq	(%rip), %rax            # 0x7ed0 <kprobe_unwind_perl+0x7ed0>
    7ed0:      	cmpl	$0x0, (%rax)
    7ed3:      	je	0x4331 <kprobe_unwind_perl+0x4331>
    7ed9:      	movabsq	$0xa782578302f78, %rax  # imm = 0xA782578302F78
    7ee3:      	movq	%rax, 0x2e(%rsp)
    7ee8:      	movabsq	$0x2f78257830207367, %rax # imm = 0x2F78257830207367
    7ef2:      	movq	%rax, 0x28(%rsp)
    7ef7:      	movabsq	$0x616c66202c564320, %rax # imm = 0x616C66202C564320
    7f01:      	movq	%rax, 0x20(%rsp)
    7f06:      	movabsq	$0x44454d414e206465, %rax # imm = 0x44454D414E206465
    7f10:      	movq	%rax, 0x18(%rsp)
    7f15:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    7f1f:      	movq	%rax, 0x10(%rsp)
    7f24:      	leaq	0x10(%rsp), %rdi
    7f29:      	movl	$0x26, %eax
    7f2e:      	movl	$0x6, %r8d
    7f34:      	movl	0x5c(%rsp), %edx
    7f38:      	movl	0x70(%rsp), %ecx
    7f3c:      	movl	$0x26, %esi
    7f41:      	xorl	%eax, %eax
    7f43:      	callq	*%r8
    7f46:      	jmp	0x4331 <kprobe_unwind_perl+0x4331>
    7f4b:      	movabsq	$0xa6c6c75662073, %rax  # imm = 0xA6C6C75662073
    7f55:      	movq	%rax, 0x2d(%rsp)
    7f5a:      	movabsq	$0x66207369206b6361, %rax # imm = 0x66207369206B6361
    7f64:      	movq	%rax, 0x28(%rsp)
    7f69:      	movabsq	$0x7473203a656d6172, %rax # imm = 0x7473203A656D6172
    7f73:      	movq	%rax, 0x20(%rsp)
    7f78:      	movabsq	$0x662068737570206f, %rax # imm = 0x662068737570206F
    7f82:      	movq	%rax, 0x18(%rsp)
    7f87:      	movabsq	$0x7420656c62616e75, %rax # imm = 0x7420656C62616E75
    7f91:      	movq	%rax, 0x10(%rsp)
    7f96:      	leaq	0x10(%rsp), %rdi
    7f9b:      	movl	$0x25, %eax
    7fa0:      	movl	$0x6, %ecx
    7fa5:      	movl	$0x25, %esi
    7faa:      	xorl	%eax, %eax
    7fac:      	callq	*%rcx
    7fae:      	jmp	0x11a3 <kprobe_unwind_perl+0x11a3>
    7fb3:      	movq	(%rip), %rax            # 0x7fba <kprobe_unwind_perl+0x7fba>
    7fba:      	cmpl	$0x0, (%rax)
    7fbd:      	je	0x5e90 <kprobe_unwind_perl+0x5e90>
    7fc3:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    7fcd:      	movq	%rax, 0x26(%rsp)
    7fd2:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    7fdc:      	movq	%rax, 0x20(%rsp)
    7fe1:      	movabsq	$0x5643565020612074, %rax # imm = 0x5643565020612074
    7feb:      	movq	%rax, 0x18(%rsp)
    7ff0:      	movabsq	$0x6f6e207369205643, %rax # imm = 0x6F6E207369205643
    7ffa:      	movq	%rax, 0x10(%rsp)
    7fff:      	leaq	0x10(%rsp), %rdi
    8004:      	movl	$0x1e, %eax
    8009:      	movl	$0x6, %ecx
    800e:      	movl	0x5c(%rsp), %edx
    8012:      	movl	$0x1e, %esi
    8017:      	xorl	%eax, %eax
    8019:      	callq	*%rcx
    801b:      	jmp	0x5e90 <kprobe_unwind_perl+0x5e90>
    8020:      	movabsq	$0x7825783020786320, %rax # imm = 0x7825783020786320
    802a:      	movq	%rax, 0x18(%rsp)
    802f:      	movabsq	$0x6c72657020746f47, %rax # imm = 0x6C72657020746F47
    8039:      	movq	%rax, 0x10(%rsp)
    803e:      	movw	$0xa, 0x20(%rsp)
    8045:      	leaq	0x10(%rsp), %rdi
    804a:      	movl	$0x12, %eax
    804f:      	movl	$0x6, %ecx
    8054:      	movzbl	0xe(%rsp), %edx
    8059:      	movl	$0x12, %esi
    805e:      	xorl	%eax, %eax
    8060:      	callq	*%rcx
    8062:      	jmp	0x4825 <kprobe_unwind_perl+0x4825>
    8067:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    8071:      	movq	%rax, 0x36(%rsp)
    8076:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    8080:      	movq	%rax, 0x30(%rsp)
    8085:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    808f:      	movq	%rax, 0x28(%rsp)
    8094:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    809e:      	movq	%rax, 0x20(%rsp)
    80a3:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    80ad:      	movq	%rax, 0x18(%rsp)
    80b2:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    80bc:      	movq	%rax, 0x10(%rsp)
    80c1:      	leaq	0x10(%rsp), %rdi
    80c6:      	movl	$0x2e, %eax
    80cb:      	movl	$0x6, %ecx
    80d0:      	movl	0x50(%rsp), %edx
    80d4:      	movl	$0x2e, %esi
    80d9:      	xorl	%eax, %eax
    80db:      	callq	*%rcx
    80dd:      	cmpl	$0x3, %ebp
    80e0:      	movq	0x98(%rsp), %rcx
    80e8:      	je	0x4c69 <kprobe_unwind_perl+0x4c69>
    80ee:      	jmp	0x5636 <kprobe_unwind_perl+0x5636>
    80f3:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    80fd:      	movq	%rax, 0x36(%rsp)
    8102:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    810c:      	movq	%rax, 0x30(%rsp)
    8111:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    811b:      	movq	%rax, 0x28(%rsp)
    8120:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    812a:      	movq	%rax, 0x20(%rsp)
    812f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    8139:      	movq	%rax, 0x18(%rsp)
    813e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    8148:      	movq	%rax, 0x10(%rsp)
    814d:      	leaq	0x10(%rsp), %rdi
    8152:      	movl	$0x2e, %eax
    8157:      	movl	$0x6, %ecx
    815c:      	movl	0x50(%rsp), %edx
    8160:      	movl	$0x2e, %esi
    8165:      	xorl	%eax, %eax
    8167:      	callq	*%rcx
    8169:      	jmp	0x4a3c <kprobe_unwind_perl+0x4a3c>
    816e:      	movabsq	$0xa7667655f7663, %rax  # imm = 0xA7667655F7663
    8178:      	movq	%rax, 0x35(%rsp)
    817d:      	movabsq	$0x5f76635f65766c6f, %rax # imm = 0x5F76635F65766C6F
    8187:      	movq	%rax, 0x30(%rsp)
    818c:      	movabsq	$0x736572206e692029, %rax # imm = 0x736572206E692029
    8196:      	movq	%rax, 0x28(%rsp)
    819b:      	movabsq	$0x28726573755f6461, %rax # imm = 0x28726573755F6461
    81a5:      	movq	%rax, 0x20(%rsp)
    81aa:      	movabsq	$0x65725f65626f7270, %rax # imm = 0x65725F65626F7270
    81b4:      	movq	%rax, 0x18(%rsp)
    81b9:      	movabsq	$0x5f66706220646142, %rax # imm = 0x5F66706220646142
    81c3:      	movq	%rax, 0x10(%rsp)
    81c8:      	leaq	0x10(%rsp), %rdi
    81cd:      	movl	$0x2d, %eax
    81d2:      	movl	$0x6, %ecx
    81d7:      	movl	$0x2d, %esi
    81dc:      	xorl	%eax, %eax
    81de:      	callq	*%rcx
    81e0:      	jmp	0x3521 <kprobe_unwind_perl+0x3521>
    81e5:      	movabsq	$0x7025207461207972, %rax # imm = 0x7025207461207972
    81ef:      	movq	%rax, 0x30(%rsp)
    81f4:      	movabsq	$0x746e65206b636174, %rax # imm = 0x746E65206B636174
    81fe:      	movq	%rax, 0x28(%rsp)
    8203:      	movabsq	$0x7320747865746e6f, %rax # imm = 0x7320747865746E6F
    820d:      	movq	%rax, 0x20(%rsp)
    8212:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    821c:      	movq	%rax, 0x18(%rsp)
    8221:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    822b:      	movq	%rax, 0x10(%rsp)
    8230:      	movw	$0xa, 0x38(%rsp)
    8237:      	leaq	0x10(%rsp), %rdi
    823c:      	movl	$0x2a, %eax
    8241:      	movl	$0x6, %ecx
    8246:      	movl	$0x2a, %esi
    824b:      	movq	%r13, %rdx
    824e:      	xorl	%eax, %eax
    8250:      	callq	*%rcx
    8252:      	jmp	0x4cba <kprobe_unwind_perl+0x4cba>
    8257:      	movq	(%rip), %rax            # 0x825e <kprobe_unwind_perl+0x825e>
    825e:      	cmpl	$0x0, (%rax)
    8261:      	je	0x3945 <kprobe_unwind_perl+0x3945>
    8267:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    8271:      	movq	%rax, 0x2e(%rsp)
    8276:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    8280:      	movq	%rax, 0x28(%rsp)
    8285:      	movabsq	$0x50472d74756f6874, %rax # imm = 0x50472D74756F6874
    828f:      	movq	%rax, 0x20(%rsp)
    8294:      	movabsq	$0x69772d5647206465, %rax # imm = 0x69772D5647206465
    829e:      	movq	%rax, 0x18(%rsp)
    82a3:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    82ad:      	movq	%rax, 0x10(%rsp)
    82b2:      	leaq	0x10(%rsp), %rdi
    82b7:      	movl	$0x26, %eax
    82bc:      	movl	$0x6, %ecx
    82c1:      	movl	0x6c(%rsp), %edx
    82c5:      	movl	$0x26, %esi
    82ca:      	jmp	0x66d8 <kprobe_unwind_perl+0x66d8>
    82cf:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    82d9:      	movq	%rax, 0x36(%rsp)
    82de:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    82e8:      	movq	%rax, 0x30(%rsp)
    82ed:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    82f7:      	movq	%rax, 0x28(%rsp)
    82fc:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    8306:      	movq	%rax, 0x20(%rsp)
    830b:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    8315:      	movq	%rax, 0x18(%rsp)
    831a:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    8324:      	movq	%rax, 0x10(%rsp)
    8329:      	leaq	0x10(%rsp), %rdi
    832e:      	movl	$0x2e, %eax
    8333:      	movl	$0x6, %ecx
    8338:      	movl	0x50(%rsp), %edx
    833c:      	movl	$0x2e, %esi
    8341:      	xorl	%eax, %eax
    8343:      	callq	*%rcx
    8345:      	jmp	0x4cfb <kprobe_unwind_perl+0x4cfb>
    834a:      	movabsq	$0xa786c2578303d, %rax  # imm = 0xA786C2578303D
    8354:      	movq	%rax, 0x30(%rsp)
    8359:      	movabsq	$0x7663202c786c2578, %rax # imm = 0x7663202C786C2578
    8363:      	movq	%rax, 0x28(%rsp)
    8368:      	movabsq	$0x303d706f6320656d, %rax # imm = 0x303D706F6320656D
    8372:      	movq	%rax, 0x20(%rsp)
    8377:      	movabsq	$0x617266206c726570, %rax # imm = 0x617266206C726570
    8381:      	movq	%rax, 0x18(%rsp)
    8386:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    8390:      	movq	%rax, 0x10(%rsp)
    8395:      	leaq	0x10(%rsp), %rdi
    839a:      	movl	$0x28, %eax
    839f:      	movl	$0x6, %r8d
    83a5:      	movl	$0x28, %esi
    83aa:      	movq	0x80(%rsp), %rdx
    83b2:      	movq	0x90(%rsp), %rcx
    83ba:      	xorl	%eax, %eax
    83bc:      	callq	*%r8
    83bf:      	movl	0x2c0(%r15), %eax
    83c6:      	cmpq	$0x7e, %rax
    83ca:      	ja	0x1193 <kprobe_unwind_perl+0x1193>
    83d0:      	jmp	0x17ac <kprobe_unwind_perl+0x17ac>
    83d5:      	movabsq	$0x6c25783020746120, %rax # imm = 0x6C25783020746120
    83df:      	movq	%rax, 0x18(%rsp)
    83e4:      	movabsq	$0x564720646e756f46, %rax # imm = 0x564720646E756F46
    83ee:      	movq	%rax, 0x10(%rsp)
    83f3:      	movl	$0xa786c, 0x1f(%rsp)    # imm = 0xA786C
    83fb:      	leaq	0x10(%rsp), %rdi
    8400:      	movl	$0x13, %eax
    8405:      	movl	$0x6, %ecx
    840a:      	movq	0x60(%rsp), %rdx
    840f:      	movl	$0x13, %esi
    8414:      	xorl	%eax, %eax
    8416:      	callq	*%rcx
    8418:      	movq	0x60(%rsp), %rax
    841d:      	jmp	0x315b <kprobe_unwind_perl+0x315b>
    8422:      	movq	(%rip), %rax            # 0x8429 <kprobe_unwind_perl+0x8429>
    8429:      	cmpl	$0x0, (%rax)
    842c:      	je	0x4caa <kprobe_unwind_perl+0x4caa>
    8432:      	movabsq	$0xa782578302f78, %rax  # imm = 0xA782578302F78
    843c:      	movq	%rax, 0x2e(%rsp)
    8441:      	movabsq	$0x2f78257830207367, %rax # imm = 0x2F78257830207367
    844b:      	movq	%rax, 0x28(%rsp)
    8450:      	movabsq	$0x616c66202c564320, %rax # imm = 0x616C66202C564320
    845a:      	movq	%rax, 0x20(%rsp)
    845f:      	movabsq	$0x44454d414e206465, %rax # imm = 0x44454D414E206465
    8469:      	movq	%rax, 0x18(%rsp)
    846e:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    8478:      	movq	%rax, 0x10(%rsp)
    847d:      	leaq	0x10(%rsp), %rdi
    8482:      	movl	$0x26, %eax
    8487:      	movl	$0x6, %r8d
    848d:      	movl	0x5c(%rsp), %edx
    8491:      	movl	0x70(%rsp), %ecx
    8495:      	movl	$0x26, %esi
    849a:      	xorl	%eax, %eax
    849c:      	callq	*%r8
    849f:      	jmp	0x4caa <kprobe_unwind_perl+0x4caa>
    84a4:      	movabsq	$0x7825783020786320, %rax # imm = 0x7825783020786320
    84ae:      	movq	%rax, 0x18(%rsp)
    84b3:      	movabsq	$0x6c72657020746f47, %rax # imm = 0x6C72657020746F47
    84bd:      	movq	%rax, 0x10(%rsp)
    84c2:      	movw	$0xa, 0x20(%rsp)
    84c9:      	leaq	0x10(%rsp), %rdi
    84ce:      	movl	$0x12, %eax
    84d3:      	movl	$0x6, %ecx
    84d8:      	movzbl	0xe(%rsp), %edx
    84dd:      	movl	$0x12, %esi
    84e2:      	xorl	%eax, %eax
    84e4:      	callq	*%rcx
    84e6:      	jmp	0x51d3 <kprobe_unwind_perl+0x51d3>
    84eb:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    84f5:      	movq	%rax, 0x36(%rsp)
    84fa:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    8504:      	movq	%rax, 0x30(%rsp)
    8509:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    8513:      	movq	%rax, 0x28(%rsp)
    8518:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    8522:      	movq	%rax, 0x20(%rsp)
    8527:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    8531:      	movq	%rax, 0x18(%rsp)
    8536:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    8540:      	movq	%rax, 0x10(%rsp)
    8545:      	leaq	0x10(%rsp), %rdi
    854a:      	movl	$0x2e, %eax
    854f:      	movl	$0x6, %ecx
    8554:      	movl	0x50(%rsp), %edx
    8558:      	movl	$0x2e, %esi
    855d:      	xorl	%eax, %eax
    855f:      	callq	*%rcx
    8561:      	cmpl	$0x3, %ebp
    8564:      	movq	0x98(%rsp), %rcx
    856c:      	je	0x5621 <kprobe_unwind_perl+0x5621>
    8572:      	jmp	0x5636 <kprobe_unwind_perl+0x5636>
    8577:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    8581:      	movq	%rax, 0x36(%rsp)
    8586:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    8590:      	movq	%rax, 0x30(%rsp)
    8595:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    859f:      	movq	%rax, 0x28(%rsp)
    85a4:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    85ae:      	movq	%rax, 0x20(%rsp)
    85b3:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    85bd:      	movq	%rax, 0x18(%rsp)
    85c2:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    85cc:      	movq	%rax, 0x10(%rsp)
    85d1:      	leaq	0x10(%rsp), %rdi
    85d6:      	movl	$0x2e, %eax
    85db:      	movl	$0x6, %ecx
    85e0:      	movl	0x50(%rsp), %edx
    85e4:      	movl	$0x2e, %esi
    85e9:      	xorl	%eax, %eax
    85eb:      	callq	*%rcx
    85ed:      	jmp	0x53ea <kprobe_unwind_perl+0x53ea>
    85f2:      	movabsq	$0xa7667655f7663, %rax  # imm = 0xA7667655F7663
    85fc:      	movq	%rax, 0x35(%rsp)
    8601:      	movabsq	$0x5f76635f65766c6f, %rax # imm = 0x5F76635F65766C6F
    860b:      	movq	%rax, 0x30(%rsp)
    8610:      	movabsq	$0x736572206e692029, %rax # imm = 0x736572206E692029
    861a:      	movq	%rax, 0x28(%rsp)
    861f:      	movabsq	$0x28726573755f6461, %rax # imm = 0x28726573755F6461
    8629:      	movq	%rax, 0x20(%rsp)
    862e:      	movabsq	$0x65725f65626f7270, %rax # imm = 0x65725F65626F7270
    8638:      	movq	%rax, 0x18(%rsp)
    863d:      	movabsq	$0x5f66706220646142, %rax # imm = 0x5F66706220646142
    8647:      	movq	%rax, 0x10(%rsp)
    864c:      	leaq	0x10(%rsp), %rdi
    8651:      	movl	$0x2d, %eax
    8656:      	movl	$0x6, %ecx
    865b:      	movl	$0x2d, %esi
    8660:      	xorl	%eax, %eax
    8662:      	callq	*%rcx
    8664:      	jmp	0x3f15 <kprobe_unwind_perl+0x3f15>
    8669:      	movabsq	$0x7025207461207972, %rax # imm = 0x7025207461207972
    8673:      	movq	%rax, 0x30(%rsp)
    8678:      	movabsq	$0x746e65206b636174, %rax # imm = 0x746E65206B636174
    8682:      	movq	%rax, 0x28(%rsp)
    8687:      	movabsq	$0x7320747865746e6f, %rax # imm = 0x7320747865746E6F
    8691:      	movq	%rax, 0x20(%rsp)
    8696:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    86a0:      	movq	%rax, 0x18(%rsp)
    86a5:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    86af:      	movq	%rax, 0x10(%rsp)
    86b4:      	movw	$0xa, 0x38(%rsp)
    86bb:      	leaq	0x10(%rsp), %rdi
    86c0:      	movl	$0x2a, %eax
    86c5:      	movl	$0x6, %ecx
    86ca:      	movl	$0x2a, %esi
    86cf:      	movq	%r13, %rdx
    86d2:      	xorl	%eax, %eax
    86d4:      	callq	*%rcx
    86d6:      	jmp	0x5ea0 <kprobe_unwind_perl+0x5ea0>
    86db:      	movq	(%rip), %rax            # 0x86e2 <kprobe_unwind_perl+0x86e2>
    86e2:      	cmpl	$0x0, (%rax)
    86e5:      	je	0x4331 <kprobe_unwind_perl+0x4331>
    86eb:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    86f5:      	movq	%rax, 0x2e(%rsp)
    86fa:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    8704:      	movq	%rax, 0x28(%rsp)
    8709:      	movabsq	$0x50472d74756f6874, %rax # imm = 0x50472D74756F6874
    8713:      	movq	%rax, 0x20(%rsp)
    8718:      	movabsq	$0x69772d5647206465, %rax # imm = 0x69772D5647206465
    8722:      	movq	%rax, 0x18(%rsp)
    8727:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    8731:      	movq	%rax, 0x10(%rsp)
    8736:      	leaq	0x10(%rsp), %rdi
    873b:      	movl	$0x26, %eax
    8740:      	movl	$0x6, %ecx
    8745:      	movl	0x6c(%rsp), %edx
    8749:      	movl	$0x26, %esi
    874e:      	jmp	0x6f58 <kprobe_unwind_perl+0x6f58>
    8753:      	movabsq	$0xa786c2578303d, %rax  # imm = 0xA786C2578303D
    875d:      	movq	%rax, 0x30(%rsp)
    8762:      	movabsq	$0x7663202c786c2578, %rax # imm = 0x7663202C786C2578
    876c:      	movq	%rax, 0x28(%rsp)
    8771:      	movabsq	$0x303d706f6320656d, %rax # imm = 0x303D706F6320656D
    877b:      	movq	%rax, 0x20(%rsp)
    8780:      	movabsq	$0x617266206c726570, %rax # imm = 0x617266206C726570
    878a:      	movq	%rax, 0x18(%rsp)
    878f:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    8799:      	movq	%rax, 0x10(%rsp)
    879e:      	leaq	0x10(%rsp), %rdi
    87a3:      	movl	$0x28, %eax
    87a8:      	movl	$0x6, %r8d
    87ae:      	movl	$0x28, %esi
    87b3:      	movq	0x80(%rsp), %rdx
    87bb:      	movq	0x90(%rsp), %rcx
    87c3:      	xorl	%eax, %eax
    87c5:      	callq	*%r8
    87c8:      	movl	0x2c0(%r15), %eax
    87cf:      	cmpq	$0x7e, %rax
    87d3:      	ja	0x1193 <kprobe_unwind_perl+0x1193>
    87d9:      	jmp	0x1df7 <kprobe_unwind_perl+0x1df7>
    87de:      	movabsq	$0x6c25783020746120, %rax # imm = 0x6C25783020746120
    87e8:      	movq	%rax, 0x18(%rsp)
    87ed:      	movabsq	$0x564720646e756f46, %rax # imm = 0x564720646E756F46
    87f7:      	movq	%rax, 0x10(%rsp)
    87fc:      	movl	$0xa786c, 0x1f(%rsp)    # imm = 0xA786C
    8804:      	leaq	0x10(%rsp), %rdi
    8809:      	movl	$0x13, %eax
    880e:      	movl	$0x6, %ecx
    8813:      	movq	0x60(%rsp), %rdx
    8818:      	movl	$0x13, %esi
    881d:      	xorl	%eax, %eax
    881f:      	callq	*%rcx
    8821:      	movq	0x60(%rsp), %rax
    8826:      	jmp	0x3b4f <kprobe_unwind_perl+0x3b4f>
    882b:      	movq	(%rip), %rax            # 0x8832 <kprobe_unwind_perl+0x8832>
    8832:      	cmpl	$0x0, (%rax)
    8835:      	je	0x5e90 <kprobe_unwind_perl+0x5e90>
    883b:      	movabsq	$0xa782578302f78, %rax  # imm = 0xA782578302F78
    8845:      	movq	%rax, 0x2e(%rsp)
    884a:      	movabsq	$0x2f78257830207367, %rax # imm = 0x2F78257830207367
    8854:      	movq	%rax, 0x28(%rsp)
    8859:      	movabsq	$0x616c66202c564320, %rax # imm = 0x616C66202C564320
    8863:      	movq	%rax, 0x20(%rsp)
    8868:      	movabsq	$0x44454d414e206465, %rax # imm = 0x44454D414E206465
    8872:      	movq	%rax, 0x18(%rsp)
    8877:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    8881:      	movq	%rax, 0x10(%rsp)
    8886:      	leaq	0x10(%rsp), %rdi
    888b:      	movl	$0x26, %eax
    8890:      	movl	$0x6, %r8d
    8896:      	movl	0x5c(%rsp), %edx
    889a:      	movl	0x70(%rsp), %ecx
    889e:      	movl	$0x26, %esi
    88a3:      	xorl	%eax, %eax
    88a5:      	callq	*%r8
    88a8:      	jmp	0x5e90 <kprobe_unwind_perl+0x5e90>
    88ad:      	movabsq	$0x7825783020786320, %rax # imm = 0x7825783020786320
    88b7:      	movq	%rax, 0x18(%rsp)
    88bc:      	movabsq	$0x6c72657020746f47, %rax # imm = 0x6C72657020746F47
    88c6:      	movq	%rax, 0x10(%rsp)
    88cb:      	movw	$0xa, 0x20(%rsp)
    88d2:      	leaq	0x10(%rsp), %rdi
    88d7:      	movl	$0x12, %eax
    88dc:      	movl	$0x6, %ecx
    88e1:      	movzbl	0xe(%rsp), %edx
    88e6:      	movl	$0x12, %esi
    88eb:      	xorl	%eax, %eax
    88ed:      	callq	*%rcx
    88ef:      	jmp	0x6384 <kprobe_unwind_perl+0x6384>
    88f4:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    88fe:      	movq	%rax, 0x36(%rsp)
    8903:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    890d:      	movq	%rax, 0x30(%rsp)
    8912:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    891c:      	movq	%rax, 0x28(%rsp)
    8921:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    892b:      	movq	%rax, 0x20(%rsp)
    8930:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    893a:      	movq	%rax, 0x18(%rsp)
    893f:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    8949:      	movq	%rax, 0x10(%rsp)
    894e:      	leaq	0x10(%rsp), %rdi
    8953:      	movl	$0x2e, %eax
    8958:      	movl	$0x6, %ecx
    895d:      	movl	0x50(%rsp), %edx
    8961:      	movl	$0x2e, %esi
    8966:      	xorl	%eax, %eax
    8968:      	callq	*%rcx
    896a:      	jmp	0x659b <kprobe_unwind_perl+0x659b>
    896f:      	movabsq	$0xa7667655f7663, %rax  # imm = 0xA7667655F7663
    8979:      	movq	%rax, 0x35(%rsp)
    897e:      	movabsq	$0x5f76635f65766c6f, %rax # imm = 0x5F76635F65766C6F
    8988:      	movq	%rax, 0x30(%rsp)
    898d:      	movabsq	$0x736572206e692029, %rax # imm = 0x736572206E692029
    8997:      	movq	%rax, 0x28(%rsp)
    899c:      	movabsq	$0x28726573755f6461, %rax # imm = 0x28726573755F6461
    89a6:      	movq	%rax, 0x20(%rsp)
    89ab:      	movabsq	$0x65725f65626f7270, %rax # imm = 0x65725F65626F7270
    89b5:      	movq	%rax, 0x18(%rsp)
    89ba:      	movabsq	$0x5f66706220646142, %rax # imm = 0x5F66706220646142
    89c4:      	movq	%rax, 0x10(%rsp)
    89c9:      	leaq	0x10(%rsp), %rdi
    89ce:      	movl	$0x2d, %eax
    89d3:      	movl	$0x6, %ecx
    89d8:      	movl	$0x2d, %esi
    89dd:      	xorl	%eax, %eax
    89df:      	callq	*%rcx
    89e1:      	jmp	0x4901 <kprobe_unwind_perl+0x4901>
    89e6:      	movq	(%rip), %rax            # 0x89ed <kprobe_unwind_perl+0x89ed>
    89ed:      	cmpl	$0x0, (%rax)
    89f0:      	je	0x4caa <kprobe_unwind_perl+0x4caa>
    89f6:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    8a00:      	movq	%rax, 0x2e(%rsp)
    8a05:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    8a0f:      	movq	%rax, 0x28(%rsp)
    8a14:      	movabsq	$0x50472d74756f6874, %rax # imm = 0x50472D74756F6874
    8a1e:      	movq	%rax, 0x20(%rsp)
    8a23:      	movabsq	$0x69772d5647206465, %rax # imm = 0x69772D5647206465
    8a2d:      	movq	%rax, 0x18(%rsp)
    8a32:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    8a3c:      	movq	%rax, 0x10(%rsp)
    8a41:      	leaq	0x10(%rsp), %rdi
    8a46:      	movl	$0x26, %eax
    8a4b:      	movl	$0x6, %ecx
    8a50:      	movl	0x6c(%rsp), %edx
    8a54:      	movl	$0x26, %esi
    8a59:      	jmp	0x7709 <kprobe_unwind_perl+0x7709>
    8a5e:      	movabsq	$0xa786c2578303d, %rax  # imm = 0xA786C2578303D
    8a68:      	movq	%rax, 0x30(%rsp)
    8a6d:      	movabsq	$0x7663202c786c2578, %rax # imm = 0x7663202C786C2578
    8a77:      	movq	%rax, 0x28(%rsp)
    8a7c:      	movabsq	$0x303d706f6320656d, %rax # imm = 0x303D706F6320656D
    8a86:      	movq	%rax, 0x20(%rsp)
    8a8b:      	movabsq	$0x617266206c726570, %rax # imm = 0x617266206C726570
    8a95:      	movq	%rax, 0x18(%rsp)
    8a9a:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    8aa4:      	movq	%rax, 0x10(%rsp)
    8aa9:      	leaq	0x10(%rsp), %rdi
    8aae:      	movl	$0x28, %eax
    8ab3:      	movl	$0x6, %r8d
    8ab9:      	movl	$0x28, %esi
    8abe:      	movq	0x80(%rsp), %rdx
    8ac6:      	movq	0x90(%rsp), %rcx
    8ace:      	xorl	%eax, %eax
    8ad0:      	callq	*%r8
    8ad3:      	movl	0x2c0(%r15), %eax
    8ada:      	cmpq	$0x7e, %rax
    8ade:      	ja	0x1193 <kprobe_unwind_perl+0x1193>
    8ae4:      	jmp	0x289d <kprobe_unwind_perl+0x289d>
    8ae9:      	movabsq	$0x6c25783020746120, %rax # imm = 0x6C25783020746120
    8af3:      	movq	%rax, 0x18(%rsp)
    8af8:      	movabsq	$0x564720646e756f46, %rax # imm = 0x564720646E756F46
    8b02:      	movq	%rax, 0x10(%rsp)
    8b07:      	movl	$0xa786c, 0x1f(%rsp)    # imm = 0xA786C
    8b0f:      	leaq	0x10(%rsp), %rdi
    8b14:      	movl	$0x13, %eax
    8b19:      	movl	$0x6, %ecx
    8b1e:      	movq	0x60(%rsp), %rdx
    8b23:      	movl	$0x13, %esi
    8b28:      	xorl	%eax, %eax
    8b2a:      	callq	*%rcx
    8b2c:      	movq	0x60(%rsp), %rax
    8b31:      	jmp	0x453b <kprobe_unwind_perl+0x453b>
    8b36:      	movabsq	$0xa7667655f7663, %rax  # imm = 0xA7667655F7663
    8b40:      	movq	%rax, 0x35(%rsp)
    8b45:      	movabsq	$0x5f76635f65766c6f, %rax # imm = 0x5F76635F65766C6F
    8b4f:      	movq	%rax, 0x30(%rsp)
    8b54:      	movabsq	$0x736572206e692029, %rax # imm = 0x736572206E692029
    8b5e:      	movq	%rax, 0x28(%rsp)
    8b63:      	movabsq	$0x28726573755f6461, %rax # imm = 0x28726573755F6461
    8b6d:      	movq	%rax, 0x20(%rsp)
    8b72:      	movabsq	$0x65725f65626f7270, %rax # imm = 0x65725F65626F7270
    8b7c:      	movq	%rax, 0x18(%rsp)
    8b81:      	movabsq	$0x5f66706220646142, %rax # imm = 0x5F66706220646142
    8b8b:      	movq	%rax, 0x10(%rsp)
    8b90:      	leaq	0x10(%rsp), %rdi
    8b95:      	movl	$0x2d, %eax
    8b9a:      	movl	$0x6, %ecx
    8b9f:      	movl	$0x2d, %esi
    8ba4:      	xorl	%eax, %eax
    8ba6:      	callq	*%rcx
    8ba8:      	jmp	0x52af <kprobe_unwind_perl+0x52af>
    8bad:      	movq	(%rip), %rax            # 0x8bb4 <kprobe_unwind_perl+0x8bb4>
    8bb4:      	cmpl	$0x0, (%rax)
    8bb7:      	je	0x5e90 <kprobe_unwind_perl+0x5e90>
    8bbd:      	movabsq	$0xa782578302073, %rax  # imm = 0xA782578302073
    8bc7:      	movq	%rax, 0x2e(%rsp)
    8bcc:      	movabsq	$0x207367616c66202c, %rax # imm = 0x207367616C66202C
    8bd6:      	movq	%rax, 0x28(%rsp)
    8bdb:      	movabsq	$0x50472d74756f6874, %rax # imm = 0x50472D74756F6874
    8be5:      	movq	%rax, 0x20(%rsp)
    8bea:      	movabsq	$0x69772d5647206465, %rax # imm = 0x69772D5647206465
    8bf4:      	movq	%rax, 0x18(%rsp)
    8bf9:      	movabsq	$0x7463657078656e55, %rax # imm = 0x7463657078656E55
    8c03:      	movq	%rax, 0x10(%rsp)
    8c08:      	leaq	0x10(%rsp), %rdi
    8c0d:      	movl	$0x26, %eax
    8c12:      	movl	$0x6, %ecx
    8c17:      	movl	0x6c(%rsp), %edx
    8c1b:      	movl	$0x26, %esi
    8c20:      	jmp	0x8017 <kprobe_unwind_perl+0x8017>
    8c25:      	movabsq	$0xa786c2578303d, %rax  # imm = 0xA786C2578303D
    8c2f:      	movq	%rax, 0x30(%rsp)
    8c34:      	movabsq	$0x7663202c786c2578, %rax # imm = 0x7663202C786C2578
    8c3e:      	movq	%rax, 0x28(%rsp)
    8c43:      	movabsq	$0x303d706f6320656d, %rax # imm = 0x303D706F6320656D
    8c4d:      	movq	%rax, 0x20(%rsp)
    8c52:      	movabsq	$0x617266206c726570, %rax # imm = 0x617266206C726570
    8c5c:      	movq	%rax, 0x18(%rsp)
    8c61:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    8c6b:      	movq	%rax, 0x10(%rsp)
    8c70:      	leaq	0x10(%rsp), %rdi
    8c75:      	movl	$0x28, %eax
    8c7a:      	movl	$0x6, %r8d
    8c80:      	movl	$0x28, %esi
    8c85:      	movq	0x80(%rsp), %rdx
    8c8d:      	movq	0x90(%rsp), %rcx
    8c95:      	xorl	%eax, %eax
    8c97:      	callq	*%r8
    8c9a:      	movl	0x2c0(%r15), %eax
    8ca1:      	cmpq	$0x7e, %rax
    8ca5:      	ja	0x1193 <kprobe_unwind_perl+0x1193>
    8cab:      	jmp	0x32bd <kprobe_unwind_perl+0x32bd>
    8cb0:      	movabsq	$0x6c25783020746120, %rax # imm = 0x6C25783020746120
    8cba:      	movq	%rax, 0x18(%rsp)
    8cbf:      	movabsq	$0x564720646e756f46, %rax # imm = 0x564720646E756F46
    8cc9:      	movq	%rax, 0x10(%rsp)
    8cce:      	movl	$0xa786c, 0x1f(%rsp)    # imm = 0xA786C
    8cd6:      	leaq	0x10(%rsp), %rdi
    8cdb:      	movl	$0x13, %eax
    8ce0:      	movl	$0x6, %ecx
    8ce5:      	movq	0x60(%rsp), %rdx
    8cea:      	movl	$0x13, %esi
    8cef:      	xorl	%eax, %eax
    8cf1:      	callq	*%rcx
    8cf3:      	movq	0x60(%rsp), %rax
    8cf8:      	jmp	0x4ee9 <kprobe_unwind_perl+0x4ee9>
    8cfd:      	movabsq	$0xa7667655f7663, %rax  # imm = 0xA7667655F7663
    8d07:      	movq	%rax, 0x35(%rsp)
    8d0c:      	movabsq	$0x5f76635f65766c6f, %rax # imm = 0x5F76635F65766C6F
    8d16:      	movq	%rax, 0x30(%rsp)
    8d1b:      	movabsq	$0x736572206e692029, %rax # imm = 0x736572206E692029
    8d25:      	movq	%rax, 0x28(%rsp)
    8d2a:      	movabsq	$0x28726573755f6461, %rax # imm = 0x28726573755F6461
    8d34:      	movq	%rax, 0x20(%rsp)
    8d39:      	movabsq	$0x65725f65626f7270, %rax # imm = 0x65725F65626F7270
    8d43:      	movq	%rax, 0x18(%rsp)
    8d48:      	movabsq	$0x5f66706220646142, %rax # imm = 0x5F66706220646142
    8d52:      	movq	%rax, 0x10(%rsp)
    8d57:      	leaq	0x10(%rsp), %rdi
    8d5c:      	movl	$0x2d, %eax
    8d61:      	movl	$0x6, %ecx
    8d66:      	movl	$0x2d, %esi
    8d6b:      	xorl	%eax, %eax
    8d6d:      	callq	*%rcx
    8d6f:      	jmp	0x6460 <kprobe_unwind_perl+0x6460>
    8d74:      	movabsq	$0xa786c2578303d, %rax  # imm = 0xA786C2578303D
    8d7e:      	movq	%rax, 0x30(%rsp)
    8d83:      	movabsq	$0x7663202c786c2578, %rax # imm = 0x7663202C786C2578
    8d8d:      	movq	%rax, 0x28(%rsp)
    8d92:      	movabsq	$0x303d706f6320656d, %rax # imm = 0x303D706F6320656D
    8d9c:      	movq	%rax, 0x20(%rsp)
    8da1:      	movabsq	$0x617266206c726570, %rax # imm = 0x617266206C726570
    8dab:      	movq	%rax, 0x18(%rsp)
    8db0:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    8dba:      	movq	%rax, 0x10(%rsp)
    8dbf:      	leaq	0x10(%rsp), %rdi
    8dc4:      	movl	$0x28, %eax
    8dc9:      	movl	$0x6, %r8d
    8dcf:      	movl	$0x28, %esi
    8dd4:      	movq	0x80(%rsp), %rdx
    8ddc:      	movq	0x90(%rsp), %rcx
    8de4:      	xorl	%eax, %eax
    8de6:      	callq	*%r8
    8de9:      	movl	0x2c0(%r15), %eax
    8df0:      	cmpq	$0x7e, %rax
    8df4:      	ja	0x1193 <kprobe_unwind_perl+0x1193>
    8dfa:      	jmp	0x3cb1 <kprobe_unwind_perl+0x3cb1>
    8dff:      	movabsq	$0x6c25783020746120, %rax # imm = 0x6C25783020746120
    8e09:      	movq	%rax, 0x18(%rsp)
    8e0e:      	movabsq	$0x564720646e756f46, %rax # imm = 0x564720646E756F46
    8e18:      	movq	%rax, 0x10(%rsp)
    8e1d:      	movl	$0xa786c, 0x1f(%rsp)    # imm = 0xA786C
    8e25:      	leaq	0x10(%rsp), %rdi
    8e2a:      	movl	$0x13, %eax
    8e2f:      	movl	$0x6, %ecx
    8e34:      	movq	0x60(%rsp), %rdx
    8e39:      	movl	$0x13, %esi
    8e3e:      	xorl	%eax, %eax
    8e40:      	callq	*%rcx
    8e42:      	movq	0x60(%rsp), %rax
    8e47:      	jmp	0x609a <kprobe_unwind_perl+0x609a>
    8e4c:      	movabsq	$0xa786c2578303d, %rax  # imm = 0xA786C2578303D
    8e56:      	movq	%rax, 0x30(%rsp)
    8e5b:      	movabsq	$0x7663202c786c2578, %rax # imm = 0x7663202C786C2578
    8e65:      	movq	%rax, 0x28(%rsp)
    8e6a:      	movabsq	$0x303d706f6320656d, %rax # imm = 0x303D706F6320656D
    8e74:      	movq	%rax, 0x20(%rsp)
    8e79:      	movabsq	$0x617266206c726570, %rax # imm = 0x617266206C726570
    8e83:      	movq	%rax, 0x18(%rsp)
    8e88:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    8e92:      	movq	%rax, 0x10(%rsp)
    8e97:      	leaq	0x10(%rsp), %rdi
    8e9c:      	movl	$0x28, %eax
    8ea1:      	movl	$0x6, %r8d
    8ea7:      	movl	$0x28, %esi
    8eac:      	movq	0x80(%rsp), %rdx
    8eb4:      	movq	0x90(%rsp), %rcx
    8ebc:      	xorl	%eax, %eax
    8ebe:      	callq	*%r8
    8ec1:      	movl	0x2c0(%r15), %eax
    8ec8:      	cmpq	$0x7e, %rax
    8ecc:      	ja	0x1193 <kprobe_unwind_perl+0x1193>
    8ed2:      	jmp	0x469d <kprobe_unwind_perl+0x469d>
    8ed7:      	movabsq	$0x6c25783020746120, %rax # imm = 0x6C25783020746120
    8ee1:      	movq	%rax, 0x18(%rsp)
    8ee6:      	movabsq	$0x564720646e756f46, %rax # imm = 0x564720646E756F46
    8ef0:      	movq	%rax, 0x10(%rsp)
    8ef5:      	movl	$0xa786c, 0x1f(%rsp)    # imm = 0xA786C
    8efd:      	leaq	0x10(%rsp), %rdi
    8f02:      	movl	$0x13, %eax
    8f07:      	movl	$0x6, %ecx
    8f0c:      	movq	0x60(%rsp), %rdx
    8f11:      	movl	$0x13, %esi
    8f16:      	xorl	%eax, %eax
    8f18:      	callq	*%rcx
    8f1a:      	movq	0x60(%rsp), %rax
    8f1f:      	jmp	0x6a4c <kprobe_unwind_perl+0x6a4c>
    8f24:      	movabsq	$0xa786c2578303d, %rax  # imm = 0xA786C2578303D
    8f2e:      	movq	%rax, 0x30(%rsp)
    8f33:      	movabsq	$0x7663202c786c2578, %rax # imm = 0x7663202C786C2578
    8f3d:      	movq	%rax, 0x28(%rsp)
    8f42:      	movabsq	$0x303d706f6320656d, %rax # imm = 0x303D706F6320656D
    8f4c:      	movq	%rax, 0x20(%rsp)
    8f51:      	movabsq	$0x617266206c726570, %rax # imm = 0x617266206C726570
    8f5b:      	movq	%rax, 0x18(%rsp)
    8f60:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    8f6a:      	movq	%rax, 0x10(%rsp)
    8f6f:      	leaq	0x10(%rsp), %rdi
    8f74:      	movl	$0x28, %eax
    8f79:      	movl	$0x6, %r8d
    8f7f:      	movl	$0x28, %esi
    8f84:      	movq	0x80(%rsp), %rdx
    8f8c:      	movq	0x90(%rsp), %rcx
    8f94:      	xorl	%eax, %eax
    8f96:      	callq	*%r8
    8f99:      	movl	0x2c0(%r15), %eax
    8fa0:      	cmpq	$0x7e, %rax
    8fa4:      	ja	0x1193 <kprobe_unwind_perl+0x1193>
    8faa:      	jmp	0x504b <kprobe_unwind_perl+0x504b>
    8faf:      	movabsq	$0x6c25783020746120, %rax # imm = 0x6C25783020746120
    8fb9:      	movq	%rax, 0x18(%rsp)
    8fbe:      	movabsq	$0x564720646e756f46, %rax # imm = 0x564720646E756F46
    8fc8:      	movq	%rax, 0x10(%rsp)
    8fcd:      	movl	$0xa786c, 0x1f(%rsp)    # imm = 0xA786C
    8fd5:      	leaq	0x10(%rsp), %rdi
    8fda:      	movl	$0x13, %eax
    8fdf:      	movl	$0x6, %ecx
    8fe4:      	movq	0x60(%rsp), %rdx
    8fe9:      	movl	$0x13, %esi
    8fee:      	xorl	%eax, %eax
    8ff0:      	callq	*%rcx
    8ff2:      	movq	0x60(%rsp), %rax
    8ff7:      	jmp	0x71fd <kprobe_unwind_perl+0x71fd>
    8ffc:      	movabsq	$0xa786c2578303d, %rax  # imm = 0xA786C2578303D
    9006:      	movq	%rax, 0x30(%rsp)
    900b:      	movabsq	$0x7663202c786c2578, %rax # imm = 0x7663202C786C2578
    9015:      	movq	%rax, 0x28(%rsp)
    901a:      	movabsq	$0x303d706f6320656d, %rax # imm = 0x303D706F6320656D
    9024:      	movq	%rax, 0x20(%rsp)
    9029:      	movabsq	$0x617266206c726570, %rax # imm = 0x617266206C726570
    9033:      	movq	%rax, 0x18(%rsp)
    9038:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    9042:      	movq	%rax, 0x10(%rsp)
    9047:      	leaq	0x10(%rsp), %rdi
    904c:      	movl	$0x28, %eax
    9051:      	movl	$0x6, %r8d
    9057:      	movl	$0x28, %esi
    905c:      	movq	0x80(%rsp), %rdx
    9064:      	movq	0x90(%rsp), %rcx
    906c:      	xorl	%eax, %eax
    906e:      	callq	*%r8
    9071:      	movl	0x2c0(%r15), %eax
    9078:      	cmpq	$0x7e, %rax
    907c:      	ja	0x1193 <kprobe_unwind_perl+0x1193>
    9082:      	jmp	0x61fc <kprobe_unwind_perl+0x61fc>
    9087:      	movabsq	$0x6c25783020746120, %rax # imm = 0x6C25783020746120
    9091:      	movq	%rax, 0x18(%rsp)
    9096:      	movabsq	$0x564720646e756f46, %rax # imm = 0x564720646E756F46
    90a0:      	movq	%rax, 0x10(%rsp)
    90a5:      	movl	$0xa786c, 0x1f(%rsp)    # imm = 0xA786C
    90ad:      	leaq	0x10(%rsp), %rdi
    90b2:      	movl	$0x13, %eax
    90b7:      	movl	$0x6, %ecx
    90bc:      	movq	0x60(%rsp), %rdx
    90c1:      	movl	$0x13, %esi
    90c6:      	xorl	%eax, %eax
    90c8:      	callq	*%rcx
    90ca:      	movq	0x60(%rsp), %rax
    90cf:      	jmp	0x79ae <kprobe_unwind_perl+0x79ae>
    90d4:      	movabsq	$0xa786c2578303d, %rax  # imm = 0xA786C2578303D
    90de:      	movq	%rax, 0x30(%rsp)
    90e3:      	movabsq	$0x7663202c786c2578, %rax # imm = 0x7663202C786C2578
    90ed:      	movq	%rax, 0x28(%rsp)
    90f2:      	movabsq	$0x303d706f6320656d, %rax # imm = 0x303D706F6320656D
    90fc:      	movq	%rax, 0x20(%rsp)
    9101:      	movabsq	$0x617266206c726570, %rax # imm = 0x617266206C726570
    910b:      	movq	%rax, 0x18(%rsp)
    9110:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    911a:      	movq	%rax, 0x10(%rsp)
    911f:      	leaq	0x10(%rsp), %rdi
    9124:      	movl	$0x28, %eax
    9129:      	movl	$0x6, %r8d
    912f:      	movl	$0x28, %esi
    9134:      	movq	0x80(%rsp), %rdx
    913c:      	movq	0x90(%rsp), %rcx
    9144:      	xorl	%eax, %eax
    9146:      	callq	*%r8
    9149:      	movl	0x2c0(%r15), %eax
    9150:      	cmpq	$0x7e, %rax
    9154:      	ja	0x1193 <kprobe_unwind_perl+0x1193>
    915a:      	jmp	0x6bae <kprobe_unwind_perl+0x6bae>
    915f:      	movabsq	$0xa786c2578303d, %rax  # imm = 0xA786C2578303D
    9169:      	movq	%rax, 0x30(%rsp)
    916e:      	movabsq	$0x7663202c786c2578, %rax # imm = 0x7663202C786C2578
    9178:      	movq	%rax, 0x28(%rsp)
    917d:      	movabsq	$0x303d706f6320656d, %rax # imm = 0x303D706F6320656D
    9187:      	movq	%rax, 0x20(%rsp)
    918c:      	movabsq	$0x617266206c726570, %rax # imm = 0x617266206C726570
    9196:      	movq	%rax, 0x18(%rsp)
    919b:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    91a5:      	movq	%rax, 0x10(%rsp)
    91aa:      	leaq	0x10(%rsp), %rdi
    91af:      	movl	$0x28, %eax
    91b4:      	movl	$0x6, %r8d
    91ba:      	movl	$0x28, %esi
    91bf:      	movq	0x80(%rsp), %rdx
    91c7:      	movq	0x90(%rsp), %rcx
    91cf:      	xorl	%eax, %eax
    91d1:      	callq	*%r8
    91d4:      	movl	0x2c0(%r15), %eax
    91db:      	cmpq	$0x7e, %rax
    91df:      	ja	0x1193 <kprobe_unwind_perl+0x1193>
    91e5:      	jmp	0x735f <kprobe_unwind_perl+0x735f>
    91ea:      	movabsq	$0xa786c2578303d, %rax  # imm = 0xA786C2578303D
    91f4:      	movq	%rax, 0x30(%rsp)
    91f9:      	movabsq	$0x7663202c786c2578, %rax # imm = 0x7663202C786C2578
    9203:      	movq	%rax, 0x28(%rsp)
    9208:      	movabsq	$0x303d706f6320656d, %rax # imm = 0x303D706F6320656D
    9212:      	movq	%rax, 0x20(%rsp)
    9217:      	movabsq	$0x617266206c726570, %rax # imm = 0x617266206C726570
    9221:      	movq	%rax, 0x18(%rsp)
    9226:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    9230:      	movq	%rax, 0x10(%rsp)
    9235:      	leaq	0x10(%rsp), %rdi
    923a:      	movl	$0x28, %eax
    923f:      	movl	$0x6, %r8d
    9245:      	movl	$0x28, %esi
    924a:      	movq	0x80(%rsp), %rdx
    9252:      	movq	0x90(%rsp), %rcx
    925a:      	xorl	%eax, %eax
    925c:      	callq	*%r8
    925f:      	movl	0x2c0(%r15), %eax
    9266:      	cmpq	$0x7e, %rax
    926a:      	ja	0x1193 <kprobe_unwind_perl+0x1193>
    9270:      	jmp	0x7b10 <kprobe_unwind_perl+0x7b10>
