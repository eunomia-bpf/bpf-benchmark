
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_generic_lsm_core_v511.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <native_bpf_strncasestr>:
       0:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
       5:      	testq	%rdx, %rdx
       8:      	je	0x74 <native_bpf_strncasestr+0x74>
       a:      	pushq	%rbx
       b:      	xorl	%ecx, %ecx
       d:      	jmp	0x1b <native_bpf_strncasestr+0x1b>
       f:      	nop
      10:      	incq	%rcx
      13:      	incq	%rdi
      16:      	cmpq	%rdx, %rcx
      19:      	je	0x73 <native_bpf_strncasestr+0x73>
      1b:      	xorl	%r8d, %r8d
      1e:      	nop
      20:      	leaq	(%rcx,%r8), %r9
      24:      	cmpq	%rdx, %r9
      27:      	jae	0x10 <native_bpf_strncasestr+0x10>
      29:      	movsbl	(%rsi,%r8), %r9d
      2e:      	testl	%r9d, %r9d
      31:      	je	0x71 <native_bpf_strncasestr+0x71>
      33:      	movsbl	(%rdi,%r8), %r10d
      38:      	leal	-0x41(%r10), %r11d
      3c:      	movl	%r10d, %ebx
      3f:      	orl	$0x20, %ebx
      42:      	cmpl	$0x1a, %r11d
      46:      	cmovael	%r10d, %ebx
      4a:      	leal	-0x41(%r9), %r10d
      4e:      	movl	%r9d, %r11d
      51:      	orl	$0x20, %r11d
      55:      	cmpl	$0x1a, %r10d
      59:      	cmovael	%r9d, %r11d
      5d:      	cmpl	%r11d, %ebx
      60:      	jne	0x10 <native_bpf_strncasestr+0x10>
      62:      	leaq	0x1(%r8), %r9
      66:      	cmpq	$0x63, %r8
      6a:      	movq	%r9, %r8
      6d:      	jb	0x20 <native_bpf_strncasestr+0x20>
      6f:      	jmp	0x10 <native_bpf_strncasestr+0x10>
      71:      	movl	%ecx, %eax
      73:      	popq	%rbx
      74:      	retq

Disassembly of section lsm:

0000000000000000 <generic_lsm_setup_event>:
       0:      	pushq	%r14
       2:      	pushq	%rbx
       3:      	subq	$0x18, %rsp
       7:      	movq	%rdi, %rbx
       a:      	movl	$0x0, 0x14(%rsp)
      12:      	movq	(%rip), %rdi            # 0x19 <generic_lsm_setup_event+0x19>
      19:      	leaq	0x14(%rsp), %rsi
      1e:      	movl	$0x1, %eax
      23:      	callq	*%rax
      25:      	testq	%rax, %rax
      28:      	je	0x1be <generic_lsm_setup_event+0x1be>
      2e:      	movq	%rax, %r14
      31:      	leaq	0x5ef8(%rax), %rsi
      38:      	movq	(%rip), %rdi            # 0x3f <generic_lsm_setup_event+0x3f>
      3f:      	movl	$0x1, %eax
      44:      	callq	*%rax
      46:      	testq	%rax, %rax
      49:      	je	0x1be <generic_lsm_setup_event+0x1be>
      4f:      	leaq	0x8(%rsp), %rdi
      54:      	movl	$0x8, %ecx
      59:      	movl	$0x4, %eax
      5e:      	movl	$0x8, %esi
      63:      	movq	%rbx, %rdx
      66:      	callq	*%rax
      68:      	movq	0x8(%rsp), %rax
      6d:      	movq	%rax, 0x5e50(%r14)
      74:      	leaq	0x8(%rbx), %rdx
      78:      	leaq	0x8(%rsp), %rdi
      7d:      	movl	$0x8, %ecx
      82:      	movl	$0x4, %eax
      87:      	movl	$0x8, %esi
      8c:      	callq	*%rax
      8e:      	movq	0x8(%rsp), %rax
      93:      	movq	%rax, 0x5e58(%r14)
      9a:      	leaq	0x10(%rbx), %rdx
      9e:      	leaq	0x8(%rsp), %rdi
      a3:      	movl	$0x8, %ecx
      a8:      	movl	$0x4, %eax
      ad:      	movl	$0x8, %esi
      b2:      	callq	*%rax
      b4:      	movq	0x8(%rsp), %rax
      b9:      	movq	%rax, 0x5e60(%r14)
      c0:      	leaq	0x18(%rbx), %rdx
      c4:      	leaq	0x8(%rsp), %rdi
      c9:      	movl	$0x8, %ecx
      ce:      	movl	$0x4, %eax
      d3:      	movl	$0x8, %esi
      d8:      	callq	*%rax
      da:      	movq	0x8(%rsp), %rax
      df:      	movq	%rax, 0x5e68(%r14)
      e6:      	leaq	0x20(%rbx), %rdx
      ea:      	leaq	0x8(%rsp), %rdi
      ef:      	movl	$0x8, %ecx
      f4:      	movl	$0x4, %eax
      f9:      	movl	$0x8, %esi
      fe:      	callq	*%rax
     100:      	movq	0x8(%rsp), %rax
     105:      	movq	%rax, 0x5e70(%r14)
     10c:      	movb	$0x10, (%r14)
     110:      	movw	$0x0, 0x2(%r14)
     117:      	movl	$0x0, 0x4(%r14)
     11f:      	movl	$0x7d, %eax
     124:      	callq	*%rax
     126:      	movq	%rax, 0x8(%r14)
     12a:      	movq	$0x0, 0x70(%r14)
     132:      	movl	$0x0, 0x14(%r14)
     13a:      	movl	$0xe, %eax
     13f:      	callq	*%rax
     141:      	movl	%eax, 0x7c(%r14)
     145:      	movl	$0x0, 0x8(%rsp)
     14d:      	movq	(%rip), %rdi            # 0x154 <generic_lsm_setup_event+0x154>
     154:      	leaq	0x8(%rsp), %rsi
     159:      	movl	$0x1, %eax
     15e:      	callq	*%rax
     160:      	testq	%rax, %rax
     163:      	je	0x188 <generic_lsm_setup_event+0x188>
     165:      	movq	%rax, %rsi
     168:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
     16f:      	movq	(%rip), %rdi            # 0x176 <generic_lsm_setup_event+0x176>
     176:      	movl	$0x1, %eax
     17b:      	callq	*%rax
     17d:      	testq	%rax, %rax
     180:      	je	0x188 <generic_lsm_setup_event+0x188>
     182:      	cmpl	$-0x1, 0x40(%rax)
     186:      	jne	0x1a3 <generic_lsm_setup_event+0x1a3>
     188:      	movq	(%rip), %rsi            # 0x18f <generic_lsm_setup_event+0x18f>
     18f:      	movl	$0x3, %ecx
     194:      	movl	$0xc, %eax
     199:      	movq	%rbx, %rdi
     19c:      	movl	$0x3, %edx
     1a1:      	callq	*%rax
     1a3:      	movq	(%rip), %rsi            # 0x1aa <generic_lsm_setup_event+0x1aa>
     1aa:      	movl	$0x1, %ecx
     1af:      	movl	$0xc, %eax
     1b4:      	movq	%rbx, %rdi
     1b7:      	movl	$0x1, %edx
     1bc:      	callq	*%rax
     1be:      	xorl	%eax, %eax
     1c0:      	addq	$0x18, %rsp
     1c4:      	popq	%rbx
     1c5:      	popq	%r14
     1c7:      	retq
     1c8:      	nopl	(%rax,%rax)

00000000000001d0 <generic_lsm_process_event>:
     1d0:      	pushq	%rbp
     1d1:      	pushq	%r15
     1d3:      	pushq	%r14
     1d5:      	pushq	%r13
     1d7:      	pushq	%r12
     1d9:      	pushq	%rbx
     1da:      	subq	$0x108, %rsp            # imm = 0x108
     1e1:      	movq	%rdi, %rbx
     1e4:      	movl	$0x0, 0xf4(%rsp)
     1ef:      	movq	(%rip), %rdi            # 0x1f6 <generic_lsm_process_event+0x26>
     1f6:      	leaq	0xf4(%rsp), %rsi
     1fe:      	movl	$0x1, %eax
     203:      	callq	*%rax
     205:      	testq	%rax, %rax
     208:      	je	0xe5f <generic_lsm_process_event+0xc8f>
     20e:      	movq	%rax, %r14
     211:      	movl	0x5efc(%rax), %r12d
     218:      	movl	0x4(%rax), %ebp
     21b:      	cmpq	$0x2327, %rbp           # imm = 0x2327
     222:      	ja	0xdc0 <generic_lsm_process_event+0xbf0>
     228:      	movl	$0x0, 0xf8(%rsp)
     233:      	movq	(%rip), %rdi            # 0x23a <generic_lsm_process_event+0x6a>
     23a:      	leaq	0xf8(%rsp), %rsi
     242:      	movl	$0x1, %eax
     247:      	callq	*%rax
     249:      	testq	%rax, %rax
     24c:      	je	0xdc0 <generic_lsm_process_event+0xbf0>
     252:      	movq	%rax, %r15
     255:      	leaq	0x5ef8(%rax), %rsi
     25c:      	movq	(%rip), %rdi            # 0x263 <generic_lsm_process_event+0x93>
     263:      	movl	$0x1, %eax
     268:      	callq	*%rax
     26a:      	cmpl	$0x4, %r12d
     26e:      	jg	0xdc0 <generic_lsm_process_event+0xbf0>
     274:      	testq	%rax, %rax
     277:      	je	0xdc0 <generic_lsm_process_event+0xbf0>
     27d:      	movq	%r12, 0x100(%rsp)
     285:      	movl	%r12d, %edx
     288:      	andl	$0x7, %edx
     28b:      	movl	%edx, %ecx
     28d:      	movl	0x4(%rax,%rcx,4), %r13d
     292:      	movslq	0x18(%rax,%rcx,4), %r12
     297:      	movl	%r12d, %esi
     29a:      	movl	$0x0, 0x5ea0(%r15,%rcx,4)
     2a6:      	testl	$0x100, %r12d           # imm = 0x100
     2ad:      	movq	%rbp, 0xc8(%rsp)
     2b5:      	movq	%rdx, 0x20(%rsp)
     2ba:      	jne	0x2d8 <generic_lsm_process_event+0x108>
     2bc:      	testb	%r12b, %r12b
     2bf:      	js	0x2e6 <generic_lsm_process_event+0x116>
     2c1:      	testb	$0x40, %sil
     2c5:      	jne	0x2f3 <generic_lsm_process_event+0x123>
     2c7:      	movl	0x40(%rax,%rdx,4), %ecx
     2cb:      	andl	$0x7, %ecx
     2ce:      	movq	0x5e50(%r15,%rcx,8), %rcx
     2d6:      	jmp	0x324 <generic_lsm_process_event+0x154>
     2d8:      	movq	$0x0, 0x8(%rsp)
     2e1:      	jmp	0x9e9 <generic_lsm_process_event+0x819>
     2e6:      	movq	$0x0, 0x8(%rsp)
     2ef:      	xorl	%ecx, %ecx
     2f1:      	jmp	0x329 <generic_lsm_process_event+0x159>
     2f3:      	movq	%rax, 0x10(%rsp)
     2f8:      	movl	$0x23, %eax
     2fd:      	movq	%r14, %rbp
     300:      	movq	%r13, %r14
     303:      	movq	%r12, %r13
     306:      	movq	%rsi, %r12
     309:      	callq	*%rax
     30b:      	movq	%r12, %rsi
     30e:      	movq	%r13, %r12
     311:      	movq	%r14, %r13
     314:      	movq	%rbp, %r14
     317:      	movq	0x20(%rsp), %rdx
     31c:      	movq	%rax, %rcx
     31f:      	movq	0x10(%rsp), %rax
     324:      	movq	%rcx, 0x8(%rsp)
     329:      	cmpl	$0x4, %edx
     32c:      	ja	0x9e9 <generic_lsm_process_event+0x819>
     332:      	leaq	(%rdx,%rdx,4), %rdx
     336:      	shll	$0x4, %edx
     339:      	cmpw	$0x0, 0x76(%rax,%rdx)
     33f:      	je	0x9e9 <generic_lsm_process_event+0x819>
     345:      	leaq	(%rax,%rdx), %rdi
     349:      	addq	$0x70, %rdi
     34d:      	movq	(%rip), %rax            # 0x354 <generic_lsm_process_event+0x184>
     354:      	movzbl	(%rax), %edx
     357:      	movl	(%rdi), %eax
     359:      	addq	%rax, %rcx
     35c:      	movq	%rcx, 0x8(%rsp)
     361:      	movzwl	0x4(%rdi), %eax
     365:      	testb	%dl, %dl
     367:      	movq	%rdi, 0x10(%rsp)
     36c:      	je	0x6a2 <generic_lsm_process_event+0x4d2>
     372:      	testw	%ax, %ax
     375:      	je	0x3af <generic_lsm_process_event+0x1df>
     377:      	leaq	0x8(%rsp), %rdi
     37c:      	movl	$0x8, %edx
     381:      	movl	$0x4, %eax
     386:      	movq	0x8(%rsp), %rdx
     38b:      	movq	%rsi, %rbp
     38e:      	movl	$0x8, %esi
     393:      	callq	*%rax
     395:      	movq	0x10(%rsp), %rdi
     39a:      	movq	%rbp, %rsi
     39d:      	movq	0x20(%rsp), %rcx
     3a2:      	movl	$0x1, %ebp
     3a7:      	testl	%eax, %eax
     3a9:      	js	0x9e1 <generic_lsm_process_event+0x811>
     3af:      	cmpw	$0x0, 0xe(%rdi)
     3b4:      	je	0x9e9 <generic_lsm_process_event+0x819>
     3ba:      	movl	0x8(%rdi), %ecx
     3bd:      	addq	0x8(%rsp), %rcx
     3c2:      	movq	%rcx, 0x8(%rsp)
     3c7:      	cmpw	$0x0, 0xc(%rdi)
     3cc:      	je	0x406 <generic_lsm_process_event+0x236>
     3ce:      	leaq	0x8(%rsp), %rdi
     3d3:      	movl	$0x8, %edx
     3d8:      	movl	$0x4, %eax
     3dd:      	movq	0x8(%rsp), %rdx
     3e2:      	movq	%rsi, %rbp
     3e5:      	movl	$0x8, %esi
     3ea:      	callq	*%rax
     3ec:      	movq	0x10(%rsp), %rdi
     3f1:      	movq	%rbp, %rsi
     3f4:      	movq	0x20(%rsp), %rcx
     3f9:      	movl	$0x2, %ebp
     3fe:      	testl	%eax, %eax
     400:      	js	0x9e1 <generic_lsm_process_event+0x811>
     406:      	cmpw	$0x0, 0x16(%rdi)
     40b:      	je	0x9e9 <generic_lsm_process_event+0x819>
     411:      	movl	0x10(%rdi), %ecx
     414:      	addq	0x8(%rsp), %rcx
     419:      	movq	%rcx, 0x8(%rsp)
     41e:      	cmpw	$0x0, 0x14(%rdi)
     423:      	je	0x45d <generic_lsm_process_event+0x28d>
     425:      	leaq	0x8(%rsp), %rdi
     42a:      	movl	$0x8, %edx
     42f:      	movl	$0x4, %eax
     434:      	movq	0x8(%rsp), %rdx
     439:      	movq	%rsi, %rbp
     43c:      	movl	$0x8, %esi
     441:      	callq	*%rax
     443:      	movq	0x10(%rsp), %rdi
     448:      	movq	%rbp, %rsi
     44b:      	movq	0x20(%rsp), %rcx
     450:      	movl	$0x3, %ebp
     455:      	testl	%eax, %eax
     457:      	js	0x9e1 <generic_lsm_process_event+0x811>
     45d:      	cmpw	$0x0, 0x1e(%rdi)
     462:      	je	0x9e9 <generic_lsm_process_event+0x819>
     468:      	movl	0x18(%rdi), %ecx
     46b:      	addq	0x8(%rsp), %rcx
     470:      	movq	%rcx, 0x8(%rsp)
     475:      	cmpw	$0x0, 0x1c(%rdi)
     47a:      	je	0x4b4 <generic_lsm_process_event+0x2e4>
     47c:      	leaq	0x8(%rsp), %rdi
     481:      	movl	$0x8, %edx
     486:      	movl	$0x4, %eax
     48b:      	movq	0x8(%rsp), %rdx
     490:      	movq	%rsi, %rbp
     493:      	movl	$0x8, %esi
     498:      	callq	*%rax
     49a:      	movq	0x10(%rsp), %rdi
     49f:      	movq	%rbp, %rsi
     4a2:      	movq	0x20(%rsp), %rcx
     4a7:      	movl	$0x4, %ebp
     4ac:      	testl	%eax, %eax
     4ae:      	js	0x9e1 <generic_lsm_process_event+0x811>
     4b4:      	cmpw	$0x0, 0x26(%rdi)
     4b9:      	je	0x9e9 <generic_lsm_process_event+0x819>
     4bf:      	movl	0x20(%rdi), %ecx
     4c2:      	addq	0x8(%rsp), %rcx
     4c7:      	movq	%rcx, 0x8(%rsp)
     4cc:      	cmpw	$0x0, 0x24(%rdi)
     4d1:      	je	0x50b <generic_lsm_process_event+0x33b>
     4d3:      	leaq	0x8(%rsp), %rdi
     4d8:      	movl	$0x8, %edx
     4dd:      	movl	$0x4, %eax
     4e2:      	movq	0x8(%rsp), %rdx
     4e7:      	movq	%rsi, %rbp
     4ea:      	movl	$0x8, %esi
     4ef:      	callq	*%rax
     4f1:      	movq	0x10(%rsp), %rdi
     4f6:      	movq	%rbp, %rsi
     4f9:      	movq	0x20(%rsp), %rcx
     4fe:      	movl	$0x5, %ebp
     503:      	testl	%eax, %eax
     505:      	js	0x9e1 <generic_lsm_process_event+0x811>
     50b:      	cmpw	$0x0, 0x2e(%rdi)
     510:      	je	0x9e9 <generic_lsm_process_event+0x819>
     516:      	movl	0x28(%rdi), %ecx
     519:      	addq	0x8(%rsp), %rcx
     51e:      	movq	%rcx, 0x8(%rsp)
     523:      	cmpw	$0x0, 0x2c(%rdi)
     528:      	je	0x562 <generic_lsm_process_event+0x392>
     52a:      	leaq	0x8(%rsp), %rdi
     52f:      	movl	$0x8, %edx
     534:      	movl	$0x4, %eax
     539:      	movq	0x8(%rsp), %rdx
     53e:      	movq	%rsi, %rbp
     541:      	movl	$0x8, %esi
     546:      	callq	*%rax
     548:      	movq	0x10(%rsp), %rdi
     54d:      	movq	%rbp, %rsi
     550:      	movq	0x20(%rsp), %rcx
     555:      	movl	$0x6, %ebp
     55a:      	testl	%eax, %eax
     55c:      	js	0x9e1 <generic_lsm_process_event+0x811>
     562:      	cmpw	$0x0, 0x36(%rdi)
     567:      	je	0x9e9 <generic_lsm_process_event+0x819>
     56d:      	movl	0x30(%rdi), %ecx
     570:      	addq	0x8(%rsp), %rcx
     575:      	movq	%rcx, 0x8(%rsp)
     57a:      	cmpw	$0x0, 0x34(%rdi)
     57f:      	je	0x5b9 <generic_lsm_process_event+0x3e9>
     581:      	leaq	0x8(%rsp), %rdi
     586:      	movl	$0x8, %edx
     58b:      	movl	$0x4, %eax
     590:      	movq	0x8(%rsp), %rdx
     595:      	movq	%rsi, %rbp
     598:      	movl	$0x8, %esi
     59d:      	callq	*%rax
     59f:      	movq	0x10(%rsp), %rdi
     5a4:      	movq	%rbp, %rsi
     5a7:      	movq	0x20(%rsp), %rcx
     5ac:      	movl	$0x7, %ebp
     5b1:      	testl	%eax, %eax
     5b3:      	js	0x9e1 <generic_lsm_process_event+0x811>
     5b9:      	cmpw	$0x0, 0x3e(%rdi)
     5be:      	je	0x9e9 <generic_lsm_process_event+0x819>
     5c4:      	movl	0x38(%rdi), %ecx
     5c7:      	addq	0x8(%rsp), %rcx
     5cc:      	movq	%rcx, 0x8(%rsp)
     5d1:      	cmpw	$0x0, 0x3c(%rdi)
     5d6:      	je	0x614 <generic_lsm_process_event+0x444>
     5d8:      	leaq	0x8(%rsp), %rdi
     5dd:      	movl	$0x8, %edx
     5e2:      	movl	$0x4, %eax
     5e7:      	movq	0x8(%rsp), %rdx
     5ec:      	movl	$0x8, %ebp
     5f1:      	movq	%rsi, 0x40(%rsp)
     5f6:      	movl	$0x8, %esi
     5fb:      	callq	*%rax
     5fd:      	movq	0x10(%rsp), %rdi
     602:      	movq	0x40(%rsp), %rsi
     607:      	movq	0x20(%rsp), %rcx
     60c:      	testl	%eax, %eax
     60e:      	js	0x9e1 <generic_lsm_process_event+0x811>
     614:      	cmpw	$0x0, 0x46(%rdi)
     619:      	je	0x9e9 <generic_lsm_process_event+0x819>
     61f:      	movl	0x40(%rdi), %ecx
     622:      	addq	0x8(%rsp), %rcx
     627:      	movq	%rcx, 0x8(%rsp)
     62c:      	cmpw	$0x0, 0x44(%rdi)
     631:      	je	0x66b <generic_lsm_process_event+0x49b>
     633:      	leaq	0x8(%rsp), %rdi
     638:      	movl	$0x8, %edx
     63d:      	movl	$0x4, %eax
     642:      	movq	0x8(%rsp), %rdx
     647:      	movq	%rsi, %rbp
     64a:      	movl	$0x8, %esi
     64f:      	callq	*%rax
     651:      	movq	0x10(%rsp), %rdi
     656:      	movq	%rbp, %rsi
     659:      	movq	0x20(%rsp), %rcx
     65e:      	movl	$0x9, %ebp
     663:      	testl	%eax, %eax
     665:      	js	0x9e1 <generic_lsm_process_event+0x811>
     66b:      	cmpw	$0x0, 0x4e(%rdi)
     670:      	je	0x9e9 <generic_lsm_process_event+0x819>
     676:      	movl	0x48(%rdi), %ecx
     679:      	addq	0x8(%rsp), %rcx
     67e:      	movq	%rcx, 0x8(%rsp)
     683:      	cmpw	$0x0, 0x4c(%rdi)
     688:      	je	0x9e9 <generic_lsm_process_event+0x819>
     68e:      	leaq	0x8(%rsp), %rdi
     693:      	movl	$0x8, %edx
     698:      	movl	$0x4, %eax
     69d:      	jmp	0x9c1 <generic_lsm_process_event+0x7f1>
     6a2:      	testw	%ax, %ax
     6a5:      	je	0x6df <generic_lsm_process_event+0x50f>
     6a7:      	leaq	0x8(%rsp), %rdi
     6ac:      	movl	$0x8, %edx
     6b1:      	movl	$0x4, %eax
     6b6:      	movq	0x8(%rsp), %rdx
     6bb:      	movq	%rsi, %rbp
     6be:      	movl	$0x8, %esi
     6c3:      	callq	*%rax
     6c5:      	movq	0x10(%rsp), %rdi
     6ca:      	movq	%rbp, %rsi
     6cd:      	movq	0x20(%rsp), %rcx
     6d2:      	movl	$0x1, %ebp
     6d7:      	testl	%eax, %eax
     6d9:      	js	0x9e1 <generic_lsm_process_event+0x811>
     6df:      	cmpw	$0x0, 0xe(%rdi)
     6e4:      	je	0x9e9 <generic_lsm_process_event+0x819>
     6ea:      	movl	0x8(%rdi), %ecx
     6ed:      	addq	0x8(%rsp), %rcx
     6f2:      	movq	%rcx, 0x8(%rsp)
     6f7:      	cmpw	$0x0, 0xc(%rdi)
     6fc:      	je	0x736 <generic_lsm_process_event+0x566>
     6fe:      	leaq	0x8(%rsp), %rdi
     703:      	movl	$0x8, %edx
     708:      	movl	$0x4, %eax
     70d:      	movq	0x8(%rsp), %rdx
     712:      	movq	%rsi, %rbp
     715:      	movl	$0x8, %esi
     71a:      	callq	*%rax
     71c:      	movq	0x10(%rsp), %rdi
     721:      	movq	%rbp, %rsi
     724:      	movq	0x20(%rsp), %rcx
     729:      	movl	$0x2, %ebp
     72e:      	testl	%eax, %eax
     730:      	js	0x9e1 <generic_lsm_process_event+0x811>
     736:      	cmpw	$0x0, 0x16(%rdi)
     73b:      	je	0x9e9 <generic_lsm_process_event+0x819>
     741:      	movl	0x10(%rdi), %ecx
     744:      	addq	0x8(%rsp), %rcx
     749:      	movq	%rcx, 0x8(%rsp)
     74e:      	cmpw	$0x0, 0x14(%rdi)
     753:      	je	0x78d <generic_lsm_process_event+0x5bd>
     755:      	leaq	0x8(%rsp), %rdi
     75a:      	movl	$0x8, %edx
     75f:      	movl	$0x4, %eax
     764:      	movq	0x8(%rsp), %rdx
     769:      	movq	%rsi, %rbp
     76c:      	movl	$0x8, %esi
     771:      	callq	*%rax
     773:      	movq	0x10(%rsp), %rdi
     778:      	movq	%rbp, %rsi
     77b:      	movq	0x20(%rsp), %rcx
     780:      	movl	$0x3, %ebp
     785:      	testl	%eax, %eax
     787:      	js	0x9e1 <generic_lsm_process_event+0x811>
     78d:      	cmpw	$0x0, 0x1e(%rdi)
     792:      	je	0x9e9 <generic_lsm_process_event+0x819>
     798:      	movl	0x18(%rdi), %ecx
     79b:      	addq	0x8(%rsp), %rcx
     7a0:      	movq	%rcx, 0x8(%rsp)
     7a5:      	cmpw	$0x0, 0x1c(%rdi)
     7aa:      	je	0x7e4 <generic_lsm_process_event+0x614>
     7ac:      	leaq	0x8(%rsp), %rdi
     7b1:      	movl	$0x8, %edx
     7b6:      	movl	$0x4, %eax
     7bb:      	movq	0x8(%rsp), %rdx
     7c0:      	movq	%rsi, %rbp
     7c3:      	movl	$0x8, %esi
     7c8:      	callq	*%rax
     7ca:      	movq	0x10(%rsp), %rdi
     7cf:      	movq	%rbp, %rsi
     7d2:      	movq	0x20(%rsp), %rcx
     7d7:      	movl	$0x4, %ebp
     7dc:      	testl	%eax, %eax
     7de:      	js	0x9e1 <generic_lsm_process_event+0x811>
     7e4:      	cmpw	$0x0, 0x26(%rdi)
     7e9:      	je	0x9e9 <generic_lsm_process_event+0x819>
     7ef:      	movl	0x20(%rdi), %ecx
     7f2:      	addq	0x8(%rsp), %rcx
     7f7:      	movq	%rcx, 0x8(%rsp)
     7fc:      	cmpw	$0x0, 0x24(%rdi)
     801:      	je	0x83b <generic_lsm_process_event+0x66b>
     803:      	leaq	0x8(%rsp), %rdi
     808:      	movl	$0x8, %edx
     80d:      	movl	$0x4, %eax
     812:      	movq	0x8(%rsp), %rdx
     817:      	movq	%rsi, %rbp
     81a:      	movl	$0x8, %esi
     81f:      	callq	*%rax
     821:      	movq	0x10(%rsp), %rdi
     826:      	movq	%rbp, %rsi
     829:      	movq	0x20(%rsp), %rcx
     82e:      	movl	$0x5, %ebp
     833:      	testl	%eax, %eax
     835:      	js	0x9e1 <generic_lsm_process_event+0x811>
     83b:      	cmpw	$0x0, 0x2e(%rdi)
     840:      	je	0x9e9 <generic_lsm_process_event+0x819>
     846:      	movl	0x28(%rdi), %ecx
     849:      	addq	0x8(%rsp), %rcx
     84e:      	movq	%rcx, 0x8(%rsp)
     853:      	cmpw	$0x0, 0x2c(%rdi)
     858:      	je	0x892 <generic_lsm_process_event+0x6c2>
     85a:      	leaq	0x8(%rsp), %rdi
     85f:      	movl	$0x8, %edx
     864:      	movl	$0x4, %eax
     869:      	movq	0x8(%rsp), %rdx
     86e:      	movq	%rsi, %rbp
     871:      	movl	$0x8, %esi
     876:      	callq	*%rax
     878:      	movq	0x10(%rsp), %rdi
     87d:      	movq	%rbp, %rsi
     880:      	movq	0x20(%rsp), %rcx
     885:      	movl	$0x6, %ebp
     88a:      	testl	%eax, %eax
     88c:      	js	0x9e1 <generic_lsm_process_event+0x811>
     892:      	cmpw	$0x0, 0x36(%rdi)
     897:      	je	0x9e9 <generic_lsm_process_event+0x819>
     89d:      	movl	0x30(%rdi), %ecx
     8a0:      	addq	0x8(%rsp), %rcx
     8a5:      	movq	%rcx, 0x8(%rsp)
     8aa:      	cmpw	$0x0, 0x34(%rdi)
     8af:      	je	0x8e9 <generic_lsm_process_event+0x719>
     8b1:      	leaq	0x8(%rsp), %rdi
     8b6:      	movl	$0x8, %edx
     8bb:      	movl	$0x4, %eax
     8c0:      	movq	0x8(%rsp), %rdx
     8c5:      	movq	%rsi, %rbp
     8c8:      	movl	$0x8, %esi
     8cd:      	callq	*%rax
     8cf:      	movq	0x10(%rsp), %rdi
     8d4:      	movq	%rbp, %rsi
     8d7:      	movq	0x20(%rsp), %rcx
     8dc:      	movl	$0x7, %ebp
     8e1:      	testl	%eax, %eax
     8e3:      	js	0x9e1 <generic_lsm_process_event+0x811>
     8e9:      	cmpw	$0x0, 0x3e(%rdi)
     8ee:      	je	0x9e9 <generic_lsm_process_event+0x819>
     8f4:      	movl	0x38(%rdi), %ecx
     8f7:      	addq	0x8(%rsp), %rcx
     8fc:      	movq	%rcx, 0x8(%rsp)
     901:      	cmpw	$0x0, 0x3c(%rdi)
     906:      	je	0x944 <generic_lsm_process_event+0x774>
     908:      	leaq	0x8(%rsp), %rdi
     90d:      	movl	$0x8, %edx
     912:      	movl	$0x4, %eax
     917:      	movq	0x8(%rsp), %rdx
     91c:      	movl	$0x8, %ebp
     921:      	movq	%rsi, 0x40(%rsp)
     926:      	movl	$0x8, %esi
     92b:      	callq	*%rax
     92d:      	movq	0x10(%rsp), %rdi
     932:      	movq	0x40(%rsp), %rsi
     937:      	movq	0x20(%rsp), %rcx
     93c:      	testl	%eax, %eax
     93e:      	js	0x9e1 <generic_lsm_process_event+0x811>
     944:      	cmpw	$0x0, 0x46(%rdi)
     949:      	je	0x9e9 <generic_lsm_process_event+0x819>
     94f:      	movl	0x40(%rdi), %ecx
     952:      	addq	0x8(%rsp), %rcx
     957:      	movq	%rcx, 0x8(%rsp)
     95c:      	cmpw	$0x0, 0x44(%rdi)
     961:      	je	0x997 <generic_lsm_process_event+0x7c7>
     963:      	leaq	0x8(%rsp), %rdi
     968:      	movl	$0x8, %edx
     96d:      	movl	$0x4, %eax
     972:      	movq	0x8(%rsp), %rdx
     977:      	movq	%rsi, %rbp
     97a:      	movl	$0x8, %esi
     97f:      	callq	*%rax
     981:      	movq	0x10(%rsp), %rdi
     986:      	movq	%rbp, %rsi
     989:      	movq	0x20(%rsp), %rcx
     98e:      	movl	$0x9, %ebp
     993:      	testl	%eax, %eax
     995:      	js	0x9e1 <generic_lsm_process_event+0x811>
     997:      	cmpw	$0x0, 0x4e(%rdi)
     99c:      	je	0x9e9 <generic_lsm_process_event+0x819>
     99e:      	movl	0x48(%rdi), %ecx
     9a1:      	addq	0x8(%rsp), %rcx
     9a6:      	movq	%rcx, 0x8(%rsp)
     9ab:      	cmpw	$0x0, 0x4c(%rdi)
     9b0:      	je	0x9e9 <generic_lsm_process_event+0x819>
     9b2:      	leaq	0x8(%rsp), %rdi
     9b7:      	movl	$0x8, %edx
     9bc:      	movl	$0x4, %eax
     9c1:      	movq	0x8(%rsp), %rdx
     9c6:      	movq	%rsi, %rbp
     9c9:      	movl	$0x8, %esi
     9ce:      	callq	*%rax
     9d0:      	movq	%rbp, %rsi
     9d3:      	movq	0x20(%rsp), %rcx
     9d8:      	movl	$0xa, %ebp
     9dd:      	testl	%eax, %eax
     9df:      	jns	0x9e9 <generic_lsm_process_event+0x819>
     9e1:      	movl	%ebp, 0x5ea0(%r15,%rcx,4)
     9e9:      	movl	%r13d, %ebp
     9ec:      	cmpl	$0x2a, %r13d
     9f0:      	ja	0xbdb <generic_lsm_process_event+0xa0b>
     9f6:      	movabsq	$0x42001018000, %rax    # imm = 0x42001018000
     a00:      	btq	%rbp, %rax
     a04:      	jae	0xbdb <generic_lsm_process_event+0xa0b>
     a0a:      	movq	0x8(%rsp), %rbp
     a0f:      	movl	$0x0, 0x30(%rsp)
     a17:      	movq	(%rip), %rdi            # 0xa1e <generic_lsm_process_event+0x84e>
     a1e:      	leaq	0x30(%rsp), %rsi
     a23:      	movl	$0x1, %eax
     a28:      	callq	*%rax
     a2a:      	testq	%rax, %rax
     a2d:      	je	0xdad <generic_lsm_process_event+0xbdd>
     a33:      	movq	%rax, %r12
     a36:      	cmpl	$0x0, 0x6420(%rax)
     a3d:      	je	0xb83 <generic_lsm_process_event+0x9b3>
     a43:      	movl	$0x0, 0x6420(%r12)
     a4f:      	movq	(%rip), %rdi            # 0xa56 <generic_lsm_process_event+0x886>
     a56:      	leaq	0x30(%rsp), %rsi
     a5b:      	movl	$0x1, %eax
     a60:      	callq	*%rax
     a62:      	testq	%rax, %rax
     a65:      	je	0xdad <generic_lsm_process_event+0xbdd>
     a6b:      	movq	%rax, %rdx
     a6e:      	movq	0x20(%rsp), %rcx
     a73:      	movl	0x5ea0(%r12,%rcx,4), %eax
     a7b:      	movq	0xc8(%rsp), %rbp
     a83:      	movl	%eax, 0x90(%r12,%rbp)
     a8b:      	addq	$0x4, %rbp
     a8f:      	movq	%rbp, 0x5e78(%r12,%rcx,8)
     a97:      	movl	$0x4, %esi
     a9c:      	testl	%eax, %eax
     a9e:      	jne	0xdaf <generic_lsm_process_event+0xbdf>
     aa4:      	movq	%r12, %r15
     aa7:      	addq	$0x90, %r15
     aae:      	movl	0x6424(%r12), %eax
     ab6:      	movq	%rbx, 0x18(%rsp)
     abb:      	movl	$0xfff, %ebx            # imm = 0xFFF
     ac0:      	subl	%eax, %ebx
     ac2:      	andl	$0xfff, %eax            # imm = 0xFFF
     ac7:      	addq	%rax, %rdx
     aca:      	movq	0x6440(%r12), %r13
     ad2:      	leaq	(%r15,%rbp), %rdi
     ad6:      	addq	$0x4, %rdi
     ada:      	andl	$0xfff, %ebx            # imm = 0xFFF
     ae0:      	movl	$0x4, %eax
     ae5:      	addq	%rbp, %r15
     ae8:      	movl	%ebx, %esi
     aea:      	callq	*%rax
     aec:      	movl	%ebx, 0x90(%r12,%rbp)
     af4:      	addq	$0x8, %r13
     af8:      	leaq	0x68(%rsp), %rdi
     afd:      	movl	$0x8, %ecx
     b02:      	movl	$0x4, %eax
     b07:      	movl	$0x8, %esi
     b0c:      	movq	%r13, %rdx
     b0f:      	callq	*%rax
     b11:      	movq	0x68(%rsp), %rcx
     b16:      	addq	$0x30, %rcx
     b1a:      	leaq	0x58(%rsp), %rdi
     b1f:      	movl	$0x8, %edx
     b24:      	movl	$0x4, %eax
     b29:      	movq	0x68(%rsp), %rdx
     b2e:      	addq	$0x30, %rdx
     b32:      	movl	$0x8, %esi
     b37:      	callq	*%rax
     b39:      	movq	0x58(%rsp), %rcx
     b3e:      	leaq	0xb0(%rsp), %rdi
     b46:      	movl	$0x2, %edx
     b4b:      	movl	$0x4, %eax
     b50:      	movq	0x58(%rsp), %rdx
     b55:      	movl	$0x2, %esi
     b5a:      	callq	*%rax
     b5c:      	movq	%rbx, %rsi
     b5f:      	movq	0x18(%rsp), %rbx
     b64:      	movl	$0x0, 0x4(%rsi,%r15)
     b6d:      	movzwl	0xb0(%rsp), %eax
     b75:      	movw	%ax, 0x8(%rsi,%r15)
     b7b:      	addl	$0xe, %esi
     b7e:      	jmp	0xdaf <generic_lsm_process_event+0xbdf>
     b83:      	movq	%rbp, 0x68(%rsp)
     b88:      	movq	$0x0, 0x58(%rsp)
     b91:      	cmpl	$0x17, %r13d
     b95:      	jle	0xc69 <generic_lsm_process_event+0xa99>
     b9b:      	cmpl	$0x18, %r13d
     b9f:      	je	0xce7 <generic_lsm_process_event+0xb17>
     ba5:      	cmpl	$0x25, %r13d
     ba9:      	je	0xd2e <generic_lsm_process_event+0xb5e>
     baf:      	cmpl	$0x2a, %r13d
     bb3:      	jne	0xdad <generic_lsm_process_event+0xbdd>
     bb9:      	movq	%r12, %rax
     bbc:      	addq	$0x6430, %rax           # imm = 0x6430
     bc2:      	movq	$0x0, 0x6430(%r12)
     bce:      	movq	%rbp, 0x6438(%r12)
     bd6:      	jmp	0xd61 <generic_lsm_process_event+0xb91>
     bdb:      	movq	0x8(%rsp), %rax
     be0:      	movq	%rax, 0x10(%rsp)
     be5:      	cmpl	$0x15, %r13d
     be9:      	movq	%rsi, 0x40(%rsp)
     bee:      	jg	0xc3d <generic_lsm_process_event+0xa6d>
     bf0:      	movl	$0x1000, %r15d          # imm = 0x1000
     bf6:      	cmpl	$0x9, %r13d
     bfa:      	jle	0xc8a <generic_lsm_process_event+0xaba>
     c00:      	cmpl	$0x10, %r13d
     c04:      	jle	0xe73 <generic_lsm_process_event+0xca3>
     c0a:      	cmpl	$0x12, %r13d
     c0e:      	jle	0xef5 <generic_lsm_process_event+0xd25>
     c14:      	cmpl	$0x13, %r13d
     c18:      	je	0xeed <generic_lsm_process_event+0xd1d>
     c1e:      	cmpl	$0x14, %r13d
     c22:      	je	0xf22 <generic_lsm_process_event+0xd52>
     c28:      	cmpl	$0x15, %r13d
     c2c:      	jne	0xf30 <generic_lsm_process_event+0xd60>
     c32:      	movl	$0x20, %r15d
     c38:      	jmp	0xf33 <generic_lsm_process_event+0xd63>
     c3d:      	cmpl	$0x20, %r13d
     c41:      	jle	0xcba <generic_lsm_process_event+0xaea>
     c43:      	cmpl	$0x27, %r13d
     c47:      	jg	0xe95 <generic_lsm_process_event+0xcc5>
     c4d:      	leal	-0x21(%r13), %eax
     c51:      	cmpl	$0x4, %eax
     c54:      	jb	0xe8a <generic_lsm_process_event+0xcba>
     c5a:      	cmpl	$0x27, %r13d
     c5e:      	je	0xed1 <generic_lsm_process_event+0xd01>
     c64:      	jmp	0xf30 <generic_lsm_process_event+0xd60>
     c69:      	cmpl	$0xf, %r13d
     c6d:      	je	0xd88 <generic_lsm_process_event+0xbb8>
     c73:      	cmpl	$0x10, %r13d
     c77:      	jne	0xdad <generic_lsm_process_event+0xbdd>
     c7d:      	leaq	0xb0(%rsp), %r15
     c85:      	jmp	0xd15 <generic_lsm_process_event+0xb45>
     c8a:      	cmpl	$0x4, %r13d
     c8e:      	jg	0xeac <generic_lsm_process_event+0xcdc>
     c94:      	leal	-0x2(%r13), %eax
     c98:      	cmpl	$0x2, %eax
     c9b:      	jb	0xec9 <generic_lsm_process_event+0xcf9>
     ca1:      	cmpl	$0x1, %r13d
     ca5:      	je	0xec9 <generic_lsm_process_event+0xcf9>
     cab:      	cmpl	$0x4, %r13d
     caf:      	je	0xe8a <generic_lsm_process_event+0xcba>
     cb5:      	jmp	0xf30 <generic_lsm_process_event+0xd60>
     cba:      	cmpl	$0x1a, %r13d
     cbe:      	jg	0xec0 <generic_lsm_process_event+0xcf0>
     cc4:      	cmpl	$0x16, %r13d
     cc8:      	je	0xed1 <generic_lsm_process_event+0xd01>
     cce:      	cmpl	$0x17, %r13d
     cd2:      	je	0xe8a <generic_lsm_process_event+0xcba>
     cd8:      	cmpl	$0x1a, %r13d
     cdc:      	je	0xf12 <generic_lsm_process_event+0xd42>
     ce2:      	jmp	0xf30 <generic_lsm_process_event+0xd60>
     ce7:      	leaq	0xb0(%rsp), %r15
     cef:      	movl	$0x8, %ecx
     cf4:      	movl	$0x4, %eax
     cf9:      	movq	0x68(%rsp), %rdx
     cfe:      	movq	%r15, %rdi
     d01:      	movl	$0x8, %esi
     d06:      	callq	*%rax
     d08:      	movq	0xb0(%rsp), %rax
     d10:      	movq	%rax, 0x68(%rsp)
     d15:      	leaq	0x68(%rsp), %rdx
     d1a:      	movl	$0x8, %ecx
     d1f:      	movl	$0x4, %eax
     d24:      	leaq	0xb0(%rsp), %rdi
     d2c:      	jmp	0xd4e <generic_lsm_process_event+0xb7e>
     d2e:      	addq	$0x40, %rbp
     d32:      	movq	%rbp, 0x68(%rsp)
     d37:      	leaq	0xb0(%rsp), %rdi
     d3f:      	movl	$0x8, %ecx
     d44:      	movl	$0x4, %eax
     d49:      	movq	0x68(%rsp), %rdx
     d4e:      	movl	$0x8, %esi
     d53:      	callq	*%rax
     d55:      	movq	0xb0(%rsp), %rax
     d5d:      	addq	$0x40, %rax
     d61:      	movq	%rax, 0x6440(%r12)
     d69:      	movq	(%rip), %rsi            # 0xd70 <generic_lsm_process_event+0xba0>
     d70:      	movl	$0x6, %ecx
     d75:      	movl	$0xc, %eax
     d7a:      	movq	%rbx, %rdi
     d7d:      	movl	$0x6, %edx
     d82:      	callq	*%rax
     d84:      	xorl	%esi, %esi
     d86:      	jmp	0xdaf <generic_lsm_process_event+0xbdf>
     d88:      	leaq	0x58(%rsp), %rdi
     d8d:      	leaq	0x68(%rsp), %rdx
     d92:      	movl	$0x8, %ecx
     d97:      	movl	$0x4, %eax
     d9c:      	movl	$0x8, %esi
     da1:      	callq	*%rax
     da3:      	movq	0x58(%rsp), %rax
     da8:      	testq	%rax, %rax
     dab:      	jne	0xd61 <generic_lsm_process_event+0xb91>
     dad:      	xorl	%esi, %esi
     daf:      	addl	0xc8(%rsp), %esi
     db6:      	movl	%esi, %ebp
     db8:      	movq	0x100(%rsp), %r12
     dc0:      	movl	%ebp, 0x4(%r14)
     dc4:      	cmpl	$0x3, %r12d
     dc8:      	jg	0xe39 <generic_lsm_process_event+0xc69>
     dca:      	movl	$0x0, 0x68(%rsp)
     dd2:      	movq	(%rip), %rdi            # 0xdd9 <generic_lsm_process_event+0xc09>
     dd9:      	leaq	0x68(%rsp), %rsi
     dde:      	movl	$0x1, %eax
     de3:      	callq	*%rax
     de5:      	testq	%rax, %rax
     de8:      	je	0xe39 <generic_lsm_process_event+0xc69>
     dea:      	movq	%rax, %rsi
     ded:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
     df4:      	movq	(%rip), %rdi            # 0xdfb <generic_lsm_process_event+0xc2b>
     dfb:      	movl	$0x1, %eax
     e00:      	callq	*%rax
     e02:      	testq	%rax, %rax
     e05:      	je	0xe39 <generic_lsm_process_event+0xc69>
     e07:      	incl	%r12d
     e0a:      	movl	%r12d, %ecx
     e0d:      	andl	$0x7, %ecx
     e10:      	cmpl	$-0x1, 0x40(%rax,%rcx,4)
     e15:      	je	0xe39 <generic_lsm_process_event+0xc69>
     e17:      	movl	%r12d, 0x5efc(%r14)
     e1e:      	movq	(%rip), %rsi            # 0xe25 <generic_lsm_process_event+0xc55>
     e25:      	movl	$0x1, %ecx
     e2a:      	movl	$0xc, %eax
     e2f:      	movq	%rbx, %rdi
     e32:      	movl	$0x1, %edx
     e37:      	callq	*%rax
     e39:      	movl	$0x0, 0x5efc(%r14)
     e44:      	movq	(%rip), %rsi            # 0xe4b <generic_lsm_process_event+0xc7b>
     e4b:      	movl	$0x3, %ecx
     e50:      	movl	$0xc, %eax
     e55:      	movq	%rbx, %rdi
     e58:      	movl	$0x3, %edx
     e5d:      	callq	*%rax
     e5f:      	xorl	%eax, %eax
     e61:      	addq	$0x108, %rsp            # imm = 0x108
     e68:      	popq	%rbx
     e69:      	popq	%r12
     e6b:      	popq	%r13
     e6d:      	popq	%r14
     e6f:      	popq	%r15
     e71:      	popq	%rbp
     e72:      	retq
     e73:      	leal	-0xa(%r13), %eax
     e77:      	cmpl	$0x2, %eax
     e7a:      	jb	0xe8a <generic_lsm_process_event+0xcba>
     e7c:      	leal	-0xc(%r13), %eax
     e80:      	cmpl	$0x2, %eax
     e83:      	jb	0xec9 <generic_lsm_process_event+0xcf9>
     e85:      	jmp	0xf30 <generic_lsm_process_event+0xd60>
     e8a:      	movl	$0x8, %r15d
     e90:      	jmp	0xf33 <generic_lsm_process_event+0xd63>
     e95:      	cmpl	$0x2a, %r13d
     e99:      	jg	0xed9 <generic_lsm_process_event+0xd09>
     e9b:      	cmpl	$0x28, %r13d
     e9f:      	je	0xeed <generic_lsm_process_event+0xd1d>
     ea1:      	cmpl	$0x29, %r13d
     ea5:      	je	0xf1a <generic_lsm_process_event+0xd4a>
     ea7:      	jmp	0xf30 <generic_lsm_process_event+0xd60>
     eac:      	cmpl	$0x6, %r13d
     eb0:      	jg	0xf06 <generic_lsm_process_event+0xd36>
     eb2:      	cmpl	$0x5, %r13d
     eb6:      	je	0xf1a <generic_lsm_process_event+0xd4a>
     eb8:      	cmpl	$0x6, %r13d
     ebc:      	je	0xf33 <generic_lsm_process_event+0xd63>
     ebe:      	jmp	0xf30 <generic_lsm_process_event+0xd60>
     ec0:      	leal	-0x1d(%r13), %eax
     ec4:      	cmpl	$0x4, %eax
     ec7:      	jae	0xf2a <generic_lsm_process_event+0xd5a>
     ec9:      	movl	$0x4, %r15d
     ecf:      	jmp	0xf33 <generic_lsm_process_event+0xd63>
     ed1:      	movl	$0x10, %r15d
     ed7:      	jmp	0xf33 <generic_lsm_process_event+0xd63>
     ed9:      	cmpl	$0x2b, %r13d
     edd:      	je	0xeed <generic_lsm_process_event+0xd1d>
     edf:      	cmpl	$0x2c, %r13d
     ee3:      	jne	0xf30 <generic_lsm_process_event+0xd60>
     ee5:      	movl	$0x70, %r15d
     eeb:      	jmp	0xf33 <generic_lsm_process_event+0xd63>
     eed:      	movl	$0x18, %r15d
     ef3:      	jmp	0xf33 <generic_lsm_process_event+0xd63>
     ef5:      	cmpl	$0x11, %r13d
     ef9:      	je	0xf33 <generic_lsm_process_event+0xd63>
     efb:      	movq	%r12, %r15
     efe:      	cmpl	$0x12, %r13d
     f02:      	je	0xf33 <generic_lsm_process_event+0xd63>
     f04:      	jmp	0xf30 <generic_lsm_process_event+0xd60>
     f06:      	cmpl	$0x7, %r13d
     f0a:      	je	0xf1a <generic_lsm_process_event+0xd4a>
     f0c:      	cmpl	$0x8, %r13d
     f10:      	jne	0xf30 <generic_lsm_process_event+0xd60>
     f12:      	movl	$0x50, %r15d
     f18:      	jmp	0xf33 <generic_lsm_process_event+0xd63>
     f1a:      	movl	$0x40, %r15d
     f20:      	jmp	0xf33 <generic_lsm_process_event+0xd63>
     f22:      	movl	$0x98, %r15d
     f28:      	jmp	0xf33 <generic_lsm_process_event+0xd63>
     f2a:      	cmpl	$0x1b, %r13d
     f2e:      	je	0xf12 <generic_lsm_process_event+0xd42>
     f30:      	xorl	%r15d, %r15d
     f33:      	movl	$0x0, 0xfc(%rsp)
     f3e:      	movq	(%rip), %rdi            # 0xf45 <generic_lsm_process_event+0xd75>
     f45:      	leaq	0xfc(%rsp), %rsi
     f4d:      	movl	$0x1, %eax
     f52:      	callq	*%rax
     f54:      	xorl	%esi, %esi
     f56:      	testq	%rax, %rax
     f59:      	je	0xdaf <generic_lsm_process_event+0xbdf>
     f5f:      	movl	$0x3ffb, %ecx           # imm = 0x3FFB
     f64:      	subq	%r15, %rcx
     f67:      	cmpq	0xc8(%rsp), %rcx
     f6f:      	jbe	0xdaf <generic_lsm_process_event+0xbdf>
     f75:      	movq	0x20(%rsp), %rsi
     f7a:      	movl	0x5ea0(%rax,%rsi,4), %ecx
     f81:      	movq	0xc8(%rsp), %rdx
     f89:      	movl	%ecx, 0x90(%rax,%rdx)
     f90:      	leaq	0x4(%rdx), %rdi
     f94:      	movq	%rdi, 0x5e78(%rax,%rsi,8)
     f9c:      	movl	$0x4, %esi
     fa1:      	testl	%ecx, %ecx
     fa3:      	jne	0xdaf <generic_lsm_process_event+0xbdf>
     fa9:      	movq	%rax, %r15
     fac:      	addq	$0x90, %r15
     fb3:      	addq	%rdi, %r15
     fb6:      	movq	0x10(%rsp), %rdx
     fbb:      	movq	%rdx, 0x68(%rsp)
     fc0:      	movq	$0x0, 0x58(%rsp)
     fc9:      	cmpl	$0x17, %r13d
     fcd:      	movq	%rax, 0x38(%rsp)
     fd2:      	jle	0x100f <generic_lsm_process_event+0xe3f>
     fd4:      	cmpl	$0x18, %r13d
     fd8:      	je	0x102a <generic_lsm_process_event+0xe5a>
     fda:      	cmpl	$0x25, %r13d
     fde:      	je	0x1068 <generic_lsm_process_event+0xe98>
     fe4:      	cmpl	$0x2a, %r13d
     fe8:      	jne	0x187c <generic_lsm_process_event+0x16ac>
     fee:      	movq	$0x0, 0xb0(%rsp)
     ffa:      	movq	%rdx, 0xb8(%rsp)
    1002:      	leaq	0xb0(%rsp), %rax
    100a:      	jmp	0x1095 <generic_lsm_process_event+0xec5>
    100f:      	cmpl	$0xf, %r13d
    1013:      	je	0x17ab <generic_lsm_process_event+0x15db>
    1019:      	cmpl	$0x10, %r13d
    101d:      	jne	0x187c <generic_lsm_process_event+0x16ac>
    1023:      	leaq	0x30(%rsp), %r12
    1028:      	jmp	0x1052 <generic_lsm_process_event+0xe82>
    102a:      	leaq	0x30(%rsp), %r12
    102f:      	movl	$0x8, %ecx
    1034:      	movl	$0x4, %eax
    1039:      	movq	0x68(%rsp), %rdx
    103e:      	movq	%r12, %rdi
    1041:      	movl	$0x8, %esi
    1046:      	callq	*%rax
    1048:      	movq	0x30(%rsp), %rax
    104d:      	movq	%rax, 0x68(%rsp)
    1052:      	leaq	0x68(%rsp), %rdx
    1057:      	movl	$0x8, %ecx
    105c:      	movl	$0x4, %eax
    1061:      	leaq	0x30(%rsp), %rdi
    1066:      	jmp	0x1085 <generic_lsm_process_event+0xeb5>
    1068:      	addq	$0x40, %rdx
    106c:      	movq	%rdx, 0x68(%rsp)
    1071:      	leaq	0x30(%rsp), %rdi
    1076:      	movl	$0x8, %ecx
    107b:      	movl	$0x4, %eax
    1080:      	movq	0x68(%rsp), %rdx
    1085:      	movl	$0x8, %esi
    108a:      	callq	*%rax
    108c:      	movq	0x30(%rsp), %rax
    1091:      	addq	$0x40, %rax
    1095:      	movq	%rax, 0xa8(%rsp)
    109d:      	movl	$0x0, 0xdc(%rsp)
    10a8:      	movq	(%rip), %rdi            # 0x10af <generic_lsm_process_event+0xedf>
    10af:      	leaq	0xdc(%rsp), %rsi
    10b7:      	movl	$0x1, %eax
    10bc:      	callq	*%rax
    10be:      	testq	%rax, %rax
    10c1:      	je	0x16c0 <generic_lsm_process_event+0x14f0>
    10c7:      	movq	%rax, %r12
    10ca:      	movq	%r15, 0x48(%rsp)
    10cf:      	addq	$0x1000, %rax           # imm = 0x1000
    10d5:      	movq	%rax, 0x10(%rsp)
    10da:      	movl	$0x23, %eax
    10df:      	callq	*%rax
    10e1:      	leaq	0xd50(%rax), %rdx
    10e8:      	leaq	0xd0(%rsp), %rdi
    10f0:      	movl	$0x8, %ecx
    10f5:      	movl	$0x4, %eax
    10fa:      	movl	$0x8, %esi
    10ff:      	callq	*%rax
    1101:      	movq	0xd0(%rsp), %rbp
    1109:      	movq	0xa8(%rsp), %rax
    1111:      	leaq	0x8(%rax), %rdx
    1115:      	leaq	0xe0(%rsp), %rdi
    111d:      	movl	$0x8, %ecx
    1122:      	movl	$0x4, %eax
    1127:      	leaq	0x18(%rbp), %rcx
    112b:      	movq	%rcx, 0xe8(%rsp)
    1133:      	movl	$0x8, %esi
    1138:      	movq	%rdx, 0x40(%rsp)
    113d:      	callq	*%rax
    113f:      	movq	0xe0(%rsp), %r13
    1147:      	leaq	0x10(%r13), %rdx
    114b:      	leaq	0x68(%rsp), %rdi
    1150:      	movl	$0x8, %ecx
    1155:      	movl	$0x4, %eax
    115a:      	movl	$0x8, %esi
    115f:      	callq	*%rax
    1161:      	cmpq	$0x0, 0x68(%rsp)
    1167:      	movl	$0x1000, %r15d          # imm = 0x1000
    116d:      	je	0x1176 <generic_lsm_process_event+0xfa6>
    116f:      	movq	0x10(%rsp), %rcx
    1174:      	jmp	0x11c9 <generic_lsm_process_event+0xff9>
    1176:      	leaq	0x18(%r13), %rdx
    117a:      	leaq	0x68(%rsp), %rdi
    117f:      	movl	$0x8, %ecx
    1184:      	movl	$0x4, %eax
    1189:      	movl	$0x8, %esi
    118e:      	callq	*%rax
    1190:      	cmpq	%r13, 0x68(%rsp)
    1195:      	movq	0x10(%rsp), %rcx
    119a:      	je	0x11c9 <generic_lsm_process_event+0xff9>
    119c:      	movq	%r12, %rcx
    119f:      	addq	$0xff6, %rcx            # imm = 0xFF6
    11a6:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
    11b0:      	movq	%rax, 0xff6(%r12)
    11b8:      	movw	$0x2964, 0xffe(%r12)    # imm = 0x2964
    11c3:      	movl	$0xff6, %r15d           # imm = 0xFF6
    11c9:      	movq	$0x0, 0x70(%rsp)
    11d2:      	movq	$0x0, 0x68(%rsp)
    11db:      	movq	%r12, 0x78(%rsp)
    11e0:      	movq	$0x0, 0x80(%rsp)
    11ec:      	movq	$0x0, 0x88(%rsp)
    11f8:      	movq	$0x0, 0x90(%rsp)
    1204:      	movq	%rcx, 0x10(%rsp)
    1209:      	movq	%rcx, 0x98(%rsp)
    1211:      	movl	%r15d, 0xa0(%rsp)
    1219:      	movb	$0x0, 0xa4(%rsp)
    1221:      	addq	$0x20, %rbp
    1225:      	leaq	0x68(%rsp), %rdi
    122a:      	movl	$0x8, %ecx
    122f:      	movl	$0x4, %eax
    1234:      	leaq	0x70(%rsp), %r12
    1239:      	leaq	0x80(%rsp), %r15
    1241:      	leaq	0x88(%rsp), %r13
    1249:      	movl	$0x8, %esi
    124e:      	movq	%rbp, %rdx
    1251:      	callq	*%rax
    1253:      	movl	$0x8, %ecx
    1258:      	movl	$0x4, %eax
    125d:      	movq	0xe8(%rsp), %rdx
    1265:      	movq	%r12, %rdi
    1268:      	movl	$0x8, %esi
    126d:      	callq	*%rax
    126f:      	movl	$0x8, %ecx
    1274:      	movl	$0x4, %eax
    1279:      	movq	0x40(%rsp), %rdx
    127e:      	movq	%r15, %rdi
    1281:      	movl	$0x8, %esi
    1286:      	callq	*%rax
    1288:      	movl	$0x8, %ecx
    128d:      	movl	$0x4, %eax
    1292:      	movq	0xa8(%rsp), %rdx
    129a:      	movq	%r13, %rdi
    129d:      	movl	$0x8, %esi
    12a2:      	callq	*%rax
    12a4:      	movq	0x88(%rsp), %rax
    12ac:      	addq	$-0x20, %rax
    12b0:      	movq	%rax, 0x90(%rsp)
    12b8:      	movq	(%rip), %rax            # 0x12bf <generic_lsm_process_event+0x10ef>
    12bf:      	cmpb	$0x0, (%rax)
    12c2:      	je	0x149d <generic_lsm_process_event+0x12cd>
    12c8:      	movl	$0x80, %r15d
    12ce:      	movl	$0x8, %r13d
    12d4:      	jmp	0x12df <generic_lsm_process_event+0x110f>
    12d6:      	decl	%r15d
    12d9:      	je	0x1677 <generic_lsm_process_event+0x14a7>
    12df:      	movq	0x80(%rsp), %rbp
    12e7:      	movq	0x88(%rsp), %rdx
    12ef:      	movq	0x90(%rsp), %r12
    12f7:      	cmpq	0x68(%rsp), %rbp
    12fc:      	jne	0x1309 <generic_lsm_process_event+0x1139>
    12fe:      	cmpq	0x70(%rsp), %rdx
    1303:      	je	0x166f <generic_lsm_process_event+0x149f>
    1309:      	movl	$0x4, %eax
    130e:      	leaq	0xc0(%rsp), %rdi
    1316:      	movl	$0x8, %esi
    131b:      	callq	*%rax
    131d:      	cmpq	0xc0(%rsp), %rbp
    1325:      	movl	$0x8, %ecx
    132a:      	je	0x1435 <generic_lsm_process_event+0x1265>
    1330:      	leaq	0x18(%rbp), %r13
    1334:      	movl	$0x4, %eax
    1339:      	leaq	0x30(%rsp), %rdi
    133e:      	movl	$0x8, %esi
    1343:      	movq	%r13, %rdx
    1346:      	callq	*%rax
    1348:      	movl	$0x8, %ecx
    134d:      	cmpq	%rbp, 0x30(%rsp)
    1352:      	je	0x1435 <generic_lsm_process_event+0x1265>
    1358:      	movl	$0x4, %eax
    135d:      	leaq	0x50(%rsp), %rdi
    1362:      	movl	$0x8, %esi
    1367:      	movq	%r13, %rdx
    136a:      	callq	*%rax
    136c:      	addq	$0x20, %rbp
    1370:      	movl	$0x4, %eax
    1375:      	leaq	0x58(%rsp), %rdi
    137a:      	movl	$0x10, %ecx
    137f:      	movl	$0x10, %esi
    1384:      	movq	%rbp, %rdx
    1387:      	callq	*%rax
    1389:      	movq	0x78(%rsp), %r12
    138e:      	movq	0x98(%rsp), %rax
    1396:      	movl	0x5c(%rsp), %ebp
    139a:      	subq	%r12, %rax
    139d:      	movl	0xa0(%rsp), %r13d
    13a5:      	movl	%ebp, %edx
    13a7:      	subl	%r13d, %edx
    13aa:      	movl	$0x0, %ecx
    13af:      	cmovbl	%ecx, %edx
    13b2:      	addq	0x60(%rsp), %rdx
    13b7:      	xorl	%esi, %esi
    13b9:      	cmpl	%ebp, %r13d
    13bc:      	seta	%sil
    13c0:      	movl	%ebp, %ecx
    13c2:      	cmovbl	%r13d, %ecx
    13c6:      	addl	%ecx, %esi
    13c8:      	movl	%r13d, %edi
    13cb:      	subl	%esi, %edi
    13cd:      	movl	%edi, 0xa0(%rsp)
    13d4:      	subq	%rsi, %rax
    13d7:      	jb	0x1677 <generic_lsm_process_event+0x14a7>
    13dd:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    13e3:      	ja	0x1677 <generic_lsm_process_event+0x14a7>
    13e9:      	cmpl	%ebp, %r13d
    13ec:      	jbe	0x13f3 <generic_lsm_process_event+0x1223>
    13ee:      	movb	$0x2f, (%r12,%rax)
    13f3:      	xorl	%edi, %edi
    13f5:      	cmpl	%ebp, %r13d
    13f8:      	seta	%dil
    13fc:      	movzbl	%cl, %esi
    13ff:      	addq	%rax, %r12
    1402:      	addq	%r12, %rdi
    1405:      	movl	$0x4, %eax
    140a:      	callq	*%rax
    140c:      	movq	%r12, 0x98(%rsp)
    1414:      	cmpl	%ebp, %r13d
    1417:      	jbe	0x1677 <generic_lsm_process_event+0x14a7>
    141d:      	movq	0x50(%rsp), %rax
    1422:      	movq	%rax, 0x80(%rsp)
    142a:      	movl	$0x8, %r13d
    1430:      	jmp	0x12d6 <generic_lsm_process_event+0x1106>
    1435:      	leaq	0x10(%r12), %rdx
    143a:      	movl	$0x4, %eax
    143f:      	leaq	0x30(%rsp), %rdi
    1444:      	movl	$0x8, %esi
    1449:      	callq	*%rax
    144b:      	movq	0x90(%rsp), %rax
    1453:      	cmpq	0x30(%rsp), %rax
    1458:      	movl	$0x8, %r13d
    145e:      	je	0x166f <generic_lsm_process_event+0x149f>
    1464:      	addq	$0x18, %r12
    1468:      	movl	$0x4, %eax
    146d:      	leaq	0x80(%rsp), %rdi
    1475:      	movl	$0x8, %esi
    147a:      	movq	%r12, %rdx
    147d:      	callq	*%rax
    147f:      	movq	0x30(%rsp), %rax
    1484:      	movq	%rax, 0x90(%rsp)
    148c:      	addq	$0x20, %rax
    1490:      	movq	%rax, 0x88(%rsp)
    1498:      	jmp	0x12d6 <generic_lsm_process_event+0x1106>
    149d:      	movl	$0x80, %r15d
    14a3:      	movl	$0x8, %r13d
    14a9:      	movq	0x80(%rsp), %rbp
    14b1:      	movq	0x88(%rsp), %rdx
    14b9:      	movq	0x90(%rsp), %r12
    14c1:      	cmpq	0x68(%rsp), %rbp
    14c6:      	jne	0x14d3 <generic_lsm_process_event+0x1303>
    14c8:      	cmpq	0x70(%rsp), %rdx
    14cd:      	je	0x166f <generic_lsm_process_event+0x149f>
    14d3:      	movl	$0x4, %eax
    14d8:      	leaq	0xc0(%rsp), %rdi
    14e0:      	movl	$0x8, %esi
    14e5:      	callq	*%rax
    14e7:      	cmpq	0xc0(%rsp), %rbp
    14ef:      	movl	$0x8, %ecx
    14f4:      	je	0x1605 <generic_lsm_process_event+0x1435>
    14fa:      	leaq	0x18(%rbp), %r13
    14fe:      	movl	$0x4, %eax
    1503:      	leaq	0x30(%rsp), %rdi
    1508:      	movl	$0x8, %esi
    150d:      	movq	%r13, %rdx
    1510:      	callq	*%rax
    1512:      	movl	$0x8, %ecx
    1517:      	cmpq	%rbp, 0x30(%rsp)
    151c:      	je	0x1605 <generic_lsm_process_event+0x1435>
    1522:      	movl	$0x4, %eax
    1527:      	leaq	0x50(%rsp), %rdi
    152c:      	movl	$0x8, %esi
    1531:      	movq	%r13, %rdx
    1534:      	callq	*%rax
    1536:      	addq	$0x20, %rbp
    153a:      	movl	$0x4, %eax
    153f:      	leaq	0x58(%rsp), %rdi
    1544:      	movl	$0x10, %ecx
    1549:      	movl	$0x10, %esi
    154e:      	movq	%rbp, %rdx
    1551:      	callq	*%rax
    1553:      	movq	0x78(%rsp), %r12
    1558:      	movq	0x98(%rsp), %rax
    1560:      	movl	0x5c(%rsp), %ebp
    1564:      	subq	%r12, %rax
    1567:      	movl	0xa0(%rsp), %r13d
    156f:      	movl	%ebp, %edx
    1571:      	subl	%r13d, %edx
    1574:      	movl	$0x0, %ecx
    1579:      	cmovbl	%ecx, %edx
    157c:      	addq	0x60(%rsp), %rdx
    1581:      	xorl	%esi, %esi
    1583:      	cmpl	%ebp, %r13d
    1586:      	seta	%sil
    158a:      	movl	%ebp, %ecx
    158c:      	cmovbl	%r13d, %ecx
    1590:      	addl	%ecx, %esi
    1592:      	movl	%r13d, %edi
    1595:      	subl	%esi, %edi
    1597:      	movl	%edi, 0xa0(%rsp)
    159e:      	subq	%rsi, %rax
    15a1:      	jb	0x1677 <generic_lsm_process_event+0x14a7>
    15a7:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    15ad:      	ja	0x1677 <generic_lsm_process_event+0x14a7>
    15b3:      	cmpl	%ebp, %r13d
    15b6:      	jbe	0x15bd <generic_lsm_process_event+0x13ed>
    15b8:      	movb	$0x2f, (%r12,%rax)
    15bd:      	xorl	%edi, %edi
    15bf:      	cmpl	%ebp, %r13d
    15c2:      	seta	%dil
    15c6:      	movzbl	%cl, %esi
    15c9:      	addq	%rax, %r12
    15cc:      	addq	%r12, %rdi
    15cf:      	movl	$0x4, %eax
    15d4:      	callq	*%rax
    15d6:      	movq	%r12, 0x98(%rsp)
    15de:      	cmpl	%ebp, %r13d
    15e1:      	jbe	0x1677 <generic_lsm_process_event+0x14a7>
    15e7:      	movq	0x50(%rsp), %rax
    15ec:      	movq	%rax, 0x80(%rsp)
    15f4:      	movl	$0x8, %r13d
    15fa:      	decl	%r15d
    15fd:      	jne	0x14a9 <generic_lsm_process_event+0x12d9>
    1603:      	jmp	0x1677 <generic_lsm_process_event+0x14a7>
    1605:      	leaq	0x10(%r12), %rdx
    160a:      	movl	$0x4, %eax
    160f:      	leaq	0x30(%rsp), %rdi
    1614:      	movl	$0x8, %esi
    1619:      	callq	*%rax
    161b:      	movq	0x90(%rsp), %rax
    1623:      	cmpq	0x30(%rsp), %rax
    1628:      	movl	$0x8, %r13d
    162e:      	je	0x166f <generic_lsm_process_event+0x149f>
    1630:      	addq	$0x18, %r12
    1634:      	movl	$0x4, %eax
    1639:      	leaq	0x80(%rsp), %rdi
    1641:      	movl	$0x8, %esi
    1646:      	movq	%r12, %rdx
    1649:      	callq	*%rax
    164b:      	movq	0x30(%rsp), %rax
    1650:      	movq	%rax, 0x90(%rsp)
    1658:      	addq	$0x20, %rax
    165c:      	movq	%rax, 0x88(%rsp)
    1664:      	decl	%r15d
    1667:      	jne	0x14a9 <generic_lsm_process_event+0x12d9>
    166d:      	jmp	0x1677 <generic_lsm_process_event+0x14a7>
    166f:      	movb	$0x1, 0xa4(%rsp)
    1677:      	movq	0x98(%rsp), %rax
    167f:      	movq	0x10(%rsp), %rdx
    1684:      	cmpq	%rdx, %rax
    1687:      	je	0x16c8 <generic_lsm_process_event+0x14f8>
    1689:      	xorl	%ebp, %ebp
    168b:      	cmpb	$0x0, 0xa4(%rsp)
    1693:      	sete	%cl
    1696:      	movl	0xa0(%rsp), %edx
    169d:      	movl	$0x1000, %r13d          # imm = 0x1000
    16a3:      	subl	%edx, %r13d
    16a6:      	testl	%edx, %edx
    16a8:      	cmovlel	%edx, %r13d
    16ac:      	testq	%rax, %rax
    16af:      	movq	0x48(%rsp), %r15
    16b4:      	je	0x16c0 <generic_lsm_process_event+0x14f0>
    16b6:      	movb	%cl, %bpl
    16b9:      	addl	%ebp, %ebp
    16bb:      	movq	%rax, %rdx
    16be:      	jmp	0x16d2 <generic_lsm_process_event+0x1502>
    16c0:      	xorl	%r13d, %r13d
    16c3:      	jmp	0x1775 <generic_lsm_process_event+0x15a5>
    16c8:      	xorl	%r13d, %r13d
    16cb:      	xorl	%ebp, %ebp
    16cd:      	movq	0x48(%rsp), %r15
    16d2:      	leaq	0x4(%r15), %rdi
    16d6:      	andl	$0xfff, %r13d           # imm = 0xFFF
    16dd:      	movl	$0x4, %eax
    16e2:      	movl	%r13d, %esi
    16e5:      	callq	*%rax
    16e7:      	movl	%r13d, (%r15)
    16ea:      	leaq	0x68(%rsp), %rdi
    16ef:      	movl	$0x8, %ecx
    16f4:      	movl	$0x4, %eax
    16f9:      	movq	0x40(%rsp), %rdx
    16fe:      	movl	$0x8, %esi
    1703:      	callq	*%rax
    1705:      	movq	0x68(%rsp), %rcx
    170a:      	addq	$0x30, %rcx
    170e:      	leaq	0x58(%rsp), %rdi
    1713:      	movl	$0x8, %edx
    1718:      	movl	$0x4, %eax
    171d:      	movq	0x68(%rsp), %rdx
    1722:      	addq	$0x30, %rdx
    1726:      	movl	$0x8, %esi
    172b:      	callq	*%rax
    172d:      	movq	0x58(%rsp), %rcx
    1732:      	leaq	0x30(%rsp), %rdi
    1737:      	movl	$0x2, %edx
    173c:      	movl	$0x4, %eax
    1741:      	movq	0x58(%rsp), %rdx
    1746:      	movl	$0x2, %esi
    174b:      	callq	*%rax
    174d:      	movl	%ebp, 0x4(%r15,%r13)
    1752:      	movzwl	0x30(%rsp), %eax
    1757:      	movw	%ax, 0x8(%r15,%r13)
    175d:      	addl	$0xa, %r13d
    1761:      	movq	0x38(%rsp), %rax
    1766:      	movq	0x20(%rsp), %rcx
    176b:      	movl	$0x4, %esi
    1770:      	testl	%r13d, %r13d
    1773:      	js	0x1788 <generic_lsm_process_event+0x15b8>
    1775:      	andl	$0x7fffffff, %r13d      # imm = 0x7FFFFFFF
    177c:      	addq	$0x4, %r13
    1780:      	movq	%r13, %rsi
    1783:      	jmp	0xdaf <generic_lsm_process_event+0xbdf>
    1788:      	movl	$0xffffffff, 0x5ea0(%rax,%rcx,4) # imm = 0xFFFFFFFF
    1793:      	movq	0xc8(%rsp), %rcx
    179b:      	movl	$0xffffffff, 0x90(%rax,%rcx) # imm = 0xFFFFFFFF
    17a6:      	jmp	0xdaf <generic_lsm_process_event+0xbdf>
    17ab:      	movq	%rdi, 0x48(%rsp)
    17b0:      	leaq	0x58(%rsp), %rdi
    17b5:      	leaq	0x68(%rsp), %rdx
    17ba:      	movl	$0x8, %ecx
    17bf:      	movl	$0x4, %eax
    17c4:      	movl	$0x8, %esi
    17c9:      	callq	*%rax
    17cb:      	movq	0x58(%rsp), %rax
    17d0:      	movq	%rax, 0xa8(%rsp)
    17d8:      	testq	%rax, %rax
    17db:      	jne	0x109d <generic_lsm_process_event+0xecd>
    17e1:      	movl	$0x0, 0xe0(%rsp)
    17ec:      	movq	(%rip), %rdi            # 0x17f3 <generic_lsm_process_event+0x1623>
    17f3:      	leaq	0xe0(%rsp), %rsi
    17fb:      	movl	$0x1, %eax
    1800:      	callq	*%rax
    1802:      	testq	%rax, %rax
    1805:      	je	0x1920 <generic_lsm_process_event+0x1750>
    180b:      	cmpl	$0x19, %r13d
    180f:      	movq	%rbx, 0x18(%rsp)
    1814:      	movq	%r14, 0x28(%rsp)
    1819:      	jg	0x1ba2 <generic_lsm_process_event+0x19d2>
    181f:      	cmpl	$0x12, %r13d
    1823:      	jle	0x1d1b <generic_lsm_process_event+0x1b4b>
    1829:      	movq	%r13, %rax
    182c:      	cmpl	$0x14, %r13d
    1830:      	jle	0x20ac <generic_lsm_process_event+0x1edc>
    1836:      	cmpl	$0x15, %eax
    1839:      	je	0x2a4e <generic_lsm_process_event+0x287e>
    183f:      	cmpl	$0x16, %eax
    1842:      	je	0x29c6 <generic_lsm_process_event+0x27f6>
    1848:      	cmpl	$0x17, %eax
    184b:      	movq	0x18(%rsp), %rbx
    1850:      	movq	0x28(%rsp), %r14
    1855:      	movl	$0x0, %r13d
    185b:      	jne	0x1761 <generic_lsm_process_event+0x1591>
    1861:      	movl	$0x0, 0x4(%r15)
    1869:      	movq	0x10(%rsp), %rax
    186e:      	movl	%eax, (%r15)
    1871:      	movl	$0x8, %r13d
    1877:      	jmp	0x1761 <generic_lsm_process_event+0x1591>
    187c:      	movq	%rdi, 0x48(%rsp)
    1881:      	cmpl	$0x2c, %r13d
    1885:      	ja	0x17e1 <generic_lsm_process_event+0x1611>
    188b:      	movabsq	$0x11c1f2027cf2, %rax   # imm = 0x11C1F2027CF2
    1895:      	btq	%rbp, %rax
    1899:      	jae	0x17e1 <generic_lsm_process_event+0x1611>
    189f:      	movq	%rdx, 0x50(%rsp)
    18a4:      	movl	$0x0, 0xe0(%rsp)
    18af:      	movq	(%rip), %rdi            # 0x18b6 <generic_lsm_process_event+0x16e6>
    18b6:      	leaq	0xe0(%rsp), %rsi
    18be:      	movl	$0x1, %eax
    18c3:      	callq	*%rax
    18c5:      	testq	%rax, %rax
    18c8:      	je	0x1920 <generic_lsm_process_event+0x1750>
    18ca:      	movq	%r15, %rbp
    18cd:      	cmpl	$0x10, %r13d
    18d1:      	jle	0x1928 <generic_lsm_process_event+0x1758>
    18d3:      	cmpl	$0x1e, %r13d
    18d7:      	jle	0x1aa8 <generic_lsm_process_event+0x18d8>
    18dd:      	movq	%r14, %r15
    18e0:      	movq	%rbx, 0x18(%rsp)
    18e5:      	cmpl	$0x26, %r13d
    18e9:      	jg	0x1be5 <generic_lsm_process_event+0x1a15>
    18ef:      	leal	-0x1f(%r13), %eax
    18f3:      	cmpl	$0x2, %eax
    18f6:      	jae	0x2188 <generic_lsm_process_event+0x1fb8>
    18fc:      	leaq	0x50(%rsp), %rdx
    1901:      	movl	$0x4, %r13d
    1907:      	movl	$0x1, %ecx
    190c:      	movl	$0x4, %eax
    1911:      	movq	%rbp, %rdi
    1914:      	movl	$0x1, %esi
    1919:      	callq	*%rax
    191b:      	jmp	0x2fe6 <generic_lsm_process_event+0x2e16>
    1920:      	xorl	%r13d, %r13d
    1923:      	jmp	0x1761 <generic_lsm_process_event+0x1591>
    1928:      	cmpl	$0x9, %r13d
    192c:      	jg	0x1ae1 <generic_lsm_process_event+0x1911>
    1932:      	movq	%r14, 0x28(%rsp)
    1937:      	movq	%rbx, 0x18(%rsp)
    193c:      	cmpl	$0x4, %r13d
    1940:      	jle	0x1db2 <generic_lsm_process_event+0x1be2>
    1946:      	cmpl	$0x5, %r13d
    194a:      	je	0x24fd <generic_lsm_process_event+0x232d>
    1950:      	movq	%rax, %r15
    1953:      	movq	%r13, %rax
    1956:      	cmpl	$0x6, %eax
    1959:      	je	0x1b6c <generic_lsm_process_event+0x199c>
    195f:      	cmpl	$0x7, %eax
    1962:      	movq	0x38(%rsp), %rax
    1967:      	movq	0x20(%rsp), %rcx
    196c:      	movl	$0x4, %esi
    1971:      	movq	0x18(%rsp), %rbx
    1976:      	movq	0x28(%rsp), %r14
    197b:      	movl	$0x0, %r13d
    1981:      	jne	0x1770 <generic_lsm_process_event+0x15a0>
    1987:      	movq	0x50(%rsp), %r12
    198c:      	movq	%rbp, %rbx
    198f:      	movq	%r12, 0x28(%rbp)
    1993:      	leaq	0x26(%rbp), %rdi
    1997:      	leaq	0x10(%r12), %rdx
    199c:      	movl	$0x2, %ecx
    19a1:      	movl	$0x4, %eax
    19a6:      	movl	$0x2, %esi
    19ab:      	callq	*%rax
    19ad:      	leaq	0x3a(%rbp), %rdi
    19b1:      	leaq	0x12(%r12), %rdx
    19b6:      	movl	$0x1, %ecx
    19bb:      	movl	$0x4, %eax
    19c0:      	movl	$0x1, %esi
    19c5:      	callq	*%rax
    19c7:      	leaq	0x38(%rbp), %rdi
    19cb:      	leaq	0x226(%r12), %rdx
    19d3:      	movl	$0x2, %ecx
    19d8:      	movl	$0x4, %eax
    19dd:      	movl	$0x2, %esi
    19e2:      	callq	*%rax
    19e4:      	leaq	0x24(%rbp), %rdi
    19e8:      	leaq	0x224(%r12), %rdx
    19f0:      	movl	$0x2, %ecx
    19f5:      	movl	$0x4, %eax
    19fa:      	movl	$0x2, %esi
    19ff:      	callq	*%rax
    1a01:      	leaq	0x30(%rbp), %rdi
    1a05:      	leaq	0x21c(%r12), %rdx
    1a0d:      	movl	$0x4, %ecx
    1a12:      	movl	$0x4, %eax
    1a17:      	movl	$0x4, %esi
    1a1c:      	callq	*%rax
    1a1e:      	leaq	0x34(%rbp), %rdi
    1a22:      	leaq	0x218(%r12), %rdx
    1a2a:      	movl	$0x4, %ecx
    1a2f:      	movl	$0x4, %eax
    1a34:      	movl	$0x4, %esi
    1a39:      	callq	*%rax
    1a3b:      	leaq	0x10(%rbp), %r13
    1a3f:      	movq	$0x0, (%rbp)
    1a47:      	movq	$0x0, 0x8(%rbp)
    1a4f:      	movq	$0x0, 0x10(%rbp)
    1a57:      	movq	$0x0, 0x18(%rbp)
    1a5f:      	movzwl	0x26(%rbp), %eax
    1a63:      	cmpl	$0xa, %eax
    1a66:      	je	0x2d1e <generic_lsm_process_event+0x2b4e>
    1a6c:      	cmpl	$0x2, %eax
    1a6f:      	jne	0x2d50 <generic_lsm_process_event+0x2b80>
    1a75:      	leaq	0x4(%r12), %rdx
    1a7a:      	movl	$0x4, %ecx
    1a7f:      	movl	$0x4, %eax
    1a84:      	movq	%rbp, %rdi
    1a87:      	movl	$0x4, %esi
    1a8c:      	callq	*%rax
    1a8e:      	movl	$0x4, %ecx
    1a93:      	movl	$0x4, %eax
    1a98:      	movq	%r13, %rdi
    1a9b:      	movl	$0x4, %esi
    1aa0:      	movq	%r12, %rdx
    1aa3:      	jmp	0x2d4e <generic_lsm_process_event+0x2b7e>
    1aa8:      	cmpl	$0x1c, %r13d
    1aac:      	jg	0x1d8e <generic_lsm_process_event+0x1bbe>
    1ab2:      	movq	%rax, %r15
    1ab5:      	movq	%r13, %rax
    1ab8:      	cmpl	$0x11, %eax
    1abb:      	je	0x21d5 <generic_lsm_process_event+0x2005>
    1ac1:      	cmpl	$0x19, %eax
    1ac4:      	je	0x2291 <generic_lsm_process_event+0x20c1>
    1aca:      	cmpl	$0x1c, %eax
    1acd:      	movq	0x38(%rsp), %rax
    1ad2:      	movq	0x20(%rsp), %rcx
    1ad7:      	movl	$0x4, %esi
    1adc:      	jmp	0x1dd7 <generic_lsm_process_event+0x1c07>
    1ae1:      	leal	-0xa(%r13), %eax
    1ae5:      	cmpl	$0x2, %eax
    1ae8:      	jb	0x1de3 <generic_lsm_process_event+0x1c13>
    1aee:      	movq	%r13, %rcx
    1af1:      	movq	%r14, 0x28(%rsp)
    1af6:      	movq	%rbx, 0x18(%rsp)
    1afb:      	leal	-0xc(%r13), %eax
    1aff:      	cmpl	$0x2, %eax
    1b02:      	jb	0x1e16 <generic_lsm_process_event+0x1c46>
    1b08:      	cmpl	$0xe, %ecx
    1b0b:      	movq	0x38(%rsp), %rax
    1b10:      	movq	0x20(%rsp), %rcx
    1b15:      	movl	$0x4, %esi
    1b1a:      	movq	0x18(%rsp), %rbx
    1b1f:      	movq	0x28(%rsp), %r14
    1b24:      	movl	$0x0, %r13d
    1b2a:      	jne	0x1770 <generic_lsm_process_event+0x15a0>
    1b30:      	leaq	0x68(%rsp), %rdi
    1b35:      	leaq	0x50(%rsp), %r12
    1b3a:      	movl	$0x8, %ecx
    1b3f:      	movl	$0x4, %eax
    1b44:      	movl	$0x8, %esi
    1b49:      	movq	%r12, %rdx
    1b4c:      	callq	*%rax
    1b4e:      	movq	0x68(%rsp), %rcx
    1b53:      	movl	$0x8, %edx
    1b58:      	movl	$0x4, %eax
    1b5d:      	movq	0x68(%rsp), %rdx
    1b62:      	movq	%r12, %rdi
    1b65:      	movl	$0x8, %esi
    1b6a:      	callq	*%rax
    1b6c:      	movq	0x50(%rsp), %rdx
    1b71:      	leaq	0x4(%rbp), %rdi
    1b75:      	movl	$0x1001, %ecx           # imm = 0x1001
    1b7a:      	movl	$0x2d, %eax
    1b7f:      	movl	$0x1001, %esi           # imm = 0x1001
    1b84:      	callq	*%rax
    1b86:      	movq	%rax, %r13
    1b89:      	testq	%rax, %rax
    1b8c:      	js	0x424f <generic_lsm_process_event+0x407f>
    1b92:      	leal	-0x1(%r13), %eax
    1b96:      	movl	%eax, (%rbp)
    1b99:      	addq	$0x3, %r13
    1b9d:      	jmp	0x424f <generic_lsm_process_event+0x407f>
    1ba2:      	movq	%rax, 0x40(%rsp)
    1ba7:      	movq	%r15, %rbp
    1baa:      	cmpl	$0x20, %r13d
    1bae:      	jle	0x1fa3 <generic_lsm_process_event+0x1dd3>
    1bb4:      	leal	-0x21(%r13), %eax
    1bb8:      	cmpl	$0x4, %eax
    1bbb:      	jae	0x1e3a <generic_lsm_process_event+0x1c6a>
    1bc1:      	movl	$0x8, %r13d
    1bc7:      	movl	$0x8, %ecx
    1bcc:      	movl	$0x4, %eax
    1bd1:      	movq	0x10(%rsp), %rdx
    1bd6:      	movq	%rbp, %rdi
    1bd9:      	movl	$0x8, %esi
    1bde:      	callq	*%rax
    1be0:      	jmp	0x3eba <generic_lsm_process_event+0x3cea>
    1be5:      	cmpl	$0x27, %r13d
    1be9:      	je	0x26af <generic_lsm_process_event+0x24df>
    1bef:      	movq	%r13, %rax
    1bf2:      	cmpl	$0x28, %eax
    1bf5:      	je	0x26ea <generic_lsm_process_event+0x251a>
    1bfb:      	cmpl	$0x2c, %eax
    1bfe:      	movq	0x38(%rsp), %rax
    1c03:      	movq	0x20(%rsp), %rcx
    1c08:      	movl	$0x4, %esi
    1c0d:      	movq	0x18(%rsp), %rbx
    1c12:      	movq	%r15, %r14
    1c15:      	movl	$0x0, %r13d
    1c1b:      	jne	0x1770 <generic_lsm_process_event+0x15a0>
    1c21:      	movq	0x50(%rsp), %r12
    1c26:      	movb	$0x0, 0x68(%rsp)
    1c2b:      	movq	%rbp, %rdi
    1c2e:      	movq	$0x0, 0x68(%rbp)
    1c36:      	movq	$0x0, 0x60(%rbp)
    1c3e:      	movq	$0x0, 0x58(%rbp)
    1c46:      	movq	$0x0, 0x50(%rbp)
    1c4e:      	movq	$0x0, 0x48(%rbp)
    1c56:      	movq	$0x0, 0x40(%rbp)
    1c5e:      	movq	$0x0, 0x38(%rbp)
    1c66:      	movq	$0x0, 0x30(%rbp)
    1c6e:      	movq	$0x0, 0x28(%rbp)
    1c76:      	movq	$0x0, 0x20(%rbp)
    1c7e:      	movq	$0x0, 0x18(%rbp)
    1c86:      	movq	$0x0, 0x10(%rbp)
    1c8e:      	movq	$0x0, 0x8(%rbp)
    1c96:      	movq	$0x0, (%rbp)
    1c9e:      	movl	$0x2, %ecx
    1ca3:      	movl	$0x4, %eax
    1ca8:      	movl	$0x2, %esi
    1cad:      	movq	%r12, %rdx
    1cb0:      	callq	*%rax
    1cb2:      	testq	%rax, %rax
    1cb5:      	js	0x2fe0 <generic_lsm_process_event+0x2e10>
    1cbb:      	leaq	0x2(%r12), %r13
    1cc0:      	leaq	0x68(%rsp), %rdi
    1cc5:      	movl	$0x1, %ecx
    1cca:      	movl	$0x4, %eax
    1ccf:      	movl	$0x1, %esi
    1cd4:      	movq	%r13, %rdx
    1cd7:      	callq	*%rax
    1cd9:      	testq	%rax, %rax
    1cdc:      	js	0x2fe0 <generic_lsm_process_event+0x2e10>
    1ce2:      	movq	%rbp, %rax
    1ce5:      	leaq	0x4(%rbp), %rdi
    1ce9:      	cmpb	$0x0, 0x68(%rsp)
    1cee:      	sete	0x2(%rbp)
    1cf2:      	je	0x2fbc <generic_lsm_process_event+0x2dec>
    1cf8:      	movl	$0x6c, %ecx
    1cfd:      	movl	$0x2d, %eax
    1d02:      	movl	$0x6c, %esi
    1d07:      	movq	%r13, %rdx
    1d0a:      	callq	*%rax
    1d0c:      	testl	%eax, %eax
    1d0e:      	js	0x2fe0 <generic_lsm_process_event+0x2e10>
    1d14:      	decb	%al
    1d16:      	jmp	0x2fdd <generic_lsm_process_event+0x2e0d>
    1d1b:      	movq	%rax, %rbp
    1d1e:      	movq	%r13, %rax
    1d21:      	cmpl	$0x7, %r13d
    1d25:      	jg	0x2067 <generic_lsm_process_event+0x1e97>
    1d2b:      	cmpl	$0x2, %eax
    1d2e:      	je	0x2777 <generic_lsm_process_event+0x25a7>
    1d34:      	cmpl	$0x3, %eax
    1d37:      	movq	0x18(%rsp), %rbx
    1d3c:      	movq	0x28(%rsp), %r14
    1d41:      	movl	$0x0, %r13d
    1d47:      	jne	0x1761 <generic_lsm_process_event+0x1591>
    1d4d:      	leaq	0x90(%rbp), %r13
    1d54:      	andl	$0xf, %r12d
    1d58:      	movq	%r12, %rax
    1d5b:      	cmpl	$0x2, %r12d
    1d5f:      	jle	0x2ea2 <generic_lsm_process_event+0x2cd2>
    1d65:      	cmpl	$0x3, %eax
    1d68:      	je	0x3179 <generic_lsm_process_event+0x2fa9>
    1d6e:      	cmpl	$0x4, %eax
    1d71:      	je	0x3184 <generic_lsm_process_event+0x2fb4>
    1d77:      	cmpl	$0x5, %eax
    1d7a:      	jne	0x3531 <generic_lsm_process_event+0x3361>
    1d80:      	movq	%rbp, %rax
    1d83:      	addq	$0x5e70, %rax           # imm = 0x5E70
    1d89:      	jmp	0x3198 <generic_lsm_process_event+0x2fc8>
    1d8e:      	leaq	0x50(%rsp), %rdx
    1d93:      	movl	$0x4, %r13d
    1d99:      	movl	$0x2, %ecx
    1d9e:      	movl	$0x4, %eax
    1da3:      	movq	%rbp, %rdi
    1da6:      	movl	$0x2, %esi
    1dab:      	callq	*%rax
    1dad:      	jmp	0x1761 <generic_lsm_process_event+0x1591>
    1db2:      	cmpl	$0x1, %r13d
    1db6:      	je	0x1e16 <generic_lsm_process_event+0x1c46>
    1db8:      	movq	%r13, %rax
    1dbb:      	cmpl	$0x4, %eax
    1dbe:      	movq	0x38(%rsp), %rax
    1dc3:      	movq	0x20(%rsp), %rcx
    1dc8:      	movl	$0x4, %esi
    1dcd:      	movq	0x18(%rsp), %rbx
    1dd2:      	movq	0x28(%rsp), %r14
    1dd7:      	movl	$0x0, %r13d
    1ddd:      	jne	0x1770 <generic_lsm_process_event+0x15a0>
    1de3:      	movl	$0x8, %r13d
    1de9:      	leaq	0x50(%rsp), %rdx
    1dee:      	movl	$0x8, %ecx
    1df3:      	movl	$0x4, %eax
    1df8:      	movq	%rbp, %rdi
    1dfb:      	movl	$0x8, %esi
    1e00:      	callq	*%rax
    1e02:      	movl	$0x4, %esi
    1e07:      	movq	0x20(%rsp), %rcx
    1e0c:      	movq	0x38(%rsp), %rax
    1e11:      	jmp	0x1770 <generic_lsm_process_event+0x15a0>
    1e16:      	leaq	0x50(%rsp), %rdx
    1e1b:      	movl	$0x4, %r13d
    1e21:      	movl	$0x4, %ecx
    1e26:      	movl	$0x4, %eax
    1e2b:      	movq	%rbp, %rdi
    1e2e:      	movl	$0x4, %esi
    1e33:      	callq	*%rax
    1e35:      	jmp	0x424f <generic_lsm_process_event+0x407f>
    1e3a:      	movq	%r13, %rcx
    1e3d:      	cmpl	$0x2b, %ecx
    1e40:      	je	0x2b3e <generic_lsm_process_event+0x296e>
    1e46:      	cmpl	$0x29, %ecx
    1e49:      	movq	0x18(%rsp), %rbx
    1e4e:      	movq	0x28(%rsp), %r14
    1e53:      	movl	$0x0, %r13d
    1e59:      	jne	0x1761 <generic_lsm_process_event+0x1591>
    1e5f:      	movq	0x10(%rsp), %rdx
    1e64:      	addq	$0x18, %rdx
    1e68:      	leaq	0x68(%rsp), %rdi
    1e6d:      	movl	$0x4, %ebx
    1e72:      	movl	$0x8, %ecx
    1e77:      	movl	$0x4, %eax
    1e7c:      	movl	$0x8, %esi
    1e81:      	callq	*%rax
    1e83:      	movq	0x68(%rsp), %r12
    1e88:      	testq	%r12, %r12
    1e8b:      	je	0x3135 <generic_lsm_process_event+0x2f65>
    1e91:      	movq	%rbp, %r15
    1e94:      	movq	%r12, 0x28(%rbp)
    1e98:      	leaq	0x26(%rbp), %rdi
    1e9c:      	leaq	0x10(%r12), %rdx
    1ea1:      	movl	$0x2, %ecx
    1ea6:      	movl	$0x4, %eax
    1eab:      	movl	$0x2, %esi
    1eb0:      	callq	*%rax
    1eb2:      	leaq	0x3a(%rbp), %rdi
    1eb6:      	leaq	0x12(%r12), %rdx
    1ebb:      	movl	$0x1, %ecx
    1ec0:      	movl	$0x4, %eax
    1ec5:      	movl	$0x1, %esi
    1eca:      	callq	*%rax
    1ecc:      	leaq	0x38(%rbp), %rdi
    1ed0:      	leaq	0x226(%r12), %rdx
    1ed8:      	movl	$0x2, %ecx
    1edd:      	movl	$0x4, %eax
    1ee2:      	movl	$0x2, %esi
    1ee7:      	callq	*%rax
    1ee9:      	leaq	0x24(%rbp), %rdi
    1eed:      	leaq	0x224(%r12), %rdx
    1ef5:      	movl	$0x2, %ecx
    1efa:      	movl	$0x4, %eax
    1eff:      	movl	$0x2, %esi
    1f04:      	callq	*%rax
    1f06:      	leaq	0x30(%rbp), %rdi
    1f0a:      	leaq	0x21c(%r12), %rdx
    1f12:      	movl	$0x4, %eax
    1f17:      	movl	$0x4, %esi
    1f1c:      	callq	*%rax
    1f1e:      	leaq	0x34(%rbp), %rdi
    1f22:      	leaq	0x218(%r12), %rdx
    1f2a:      	movl	$0x4, %eax
    1f2f:      	movl	$0x4, %esi
    1f34:      	callq	*%rax
    1f36:      	leaq	0x10(%rbp), %r13
    1f3a:      	movq	$0x0, (%rbp)
    1f42:      	movq	$0x0, 0x8(%rbp)
    1f4a:      	movq	$0x0, 0x10(%rbp)
    1f52:      	movq	$0x0, 0x18(%rbp)
    1f5a:      	movzwl	0x26(%rbp), %eax
    1f5e:      	cmpl	$0xa, %eax
    1f61:      	je	0x30bd <generic_lsm_process_event+0x2eed>
    1f67:      	cmpl	$0x2, %eax
    1f6a:      	jne	0x30ef <generic_lsm_process_event+0x2f1f>
    1f70:      	leaq	0x4(%r12), %rdx
    1f75:      	movl	$0x4, %ecx
    1f7a:      	movl	$0x4, %eax
    1f7f:      	movq	%rbp, %rdi
    1f82:      	movl	$0x4, %esi
    1f87:      	callq	*%rax
    1f89:      	movl	$0x4, %ecx
    1f8e:      	movl	$0x4, %eax
    1f93:      	movq	%r13, %rdi
    1f96:      	movl	$0x4, %esi
    1f9b:      	movq	%r12, %rdx
    1f9e:      	jmp	0x30ed <generic_lsm_process_event+0x2f1d>
    1fa3:      	cmpl	$0x1a, %r13d
    1fa7:      	je	0x2bd7 <generic_lsm_process_event+0x2a07>
    1fad:      	movq	%r13, %rax
    1fb0:      	cmpl	$0x1b, %eax
    1fb3:      	movq	0x18(%rsp), %rbx
    1fb8:      	movq	0x28(%rsp), %r14
    1fbd:      	movl	$0x0, %r13d
    1fc3:      	jne	0x1761 <generic_lsm_process_event+0x1591>
    1fc9:      	movq	$0x0, 0x48(%rbp)
    1fd1:      	movq	$0x0, 0x40(%rbp)
    1fd9:      	movq	$0x0, 0x38(%rbp)
    1fe1:      	movq	$0x0, 0x30(%rbp)
    1fe9:      	movq	$0x0, 0x28(%rbp)
    1ff1:      	movq	$0x0, 0x20(%rbp)
    1ff9:      	movq	$0x0, 0x18(%rbp)
    2001:      	movq	$0x0, 0x10(%rbp)
    2009:      	movq	$0x0, 0x8(%rbp)
    2011:      	movq	$0x0, (%rbp)
    2019:      	leaq	0x10(%rbp), %rdi
    201d:      	movq	0x10(%rsp), %rax
    2022:      	leaq	0x18(%rax), %rdx
    2026:      	movl	$0x3f, %ecx
    202b:      	movl	$0x2d, %eax
    2030:      	movl	$0x3f, %esi
    2035:      	callq	*%rax
    2037:      	testq	%rax, %rax
    203a:      	js	0x2c4b <generic_lsm_process_event+0x2a7b>
    2040:      	addq	$0x8, %rbp
    2044:      	movq	0x10(%rsp), %rdx
    2049:      	addq	$0x348, %rdx            # imm = 0x348
    2050:      	movl	$0x8, %ecx
    2055:      	movl	$0x4, %eax
    205a:      	movq	%rbp, %rdi
    205d:      	movl	$0x8, %esi
    2062:      	jmp	0x29b9 <generic_lsm_process_event+0x27e9>
    2067:      	cmpl	$0x8, %eax
    206a:      	je	0x27e0 <generic_lsm_process_event+0x2610>
    2070:      	cmpl	$0x12, %eax
    2073:      	movq	0x18(%rsp), %rbx
    2078:      	movq	0x28(%rsp), %r14
    207d:      	movl	$0x0, %r13d
    2083:      	jne	0x1761 <generic_lsm_process_event+0x1591>
    2089:      	movq	0x40(%rsp), %r13
    208e:      	andl	$0x3ff, %r13d           # imm = 0x3FF
    2095:      	movl	$0x4, %eax
    209a:      	movq	0x10(%rsp), %rdx
    209f:      	movq	%r15, %rdi
    20a2:      	movl	%r13d, %esi
    20a5:      	callq	*%rax
    20a7:      	jmp	0x1761 <generic_lsm_process_event+0x1591>
    20ac:      	cmpl	$0x13, %eax
    20af:      	je	0x2ae4 <generic_lsm_process_event+0x2914>
    20b5:      	cmpl	$0x14, %eax
    20b8:      	movq	0x18(%rsp), %rbx
    20bd:      	movq	0x28(%rsp), %r14
    20c2:      	movl	$0x0, %r13d
    20c8:      	jne	0x1761 <generic_lsm_process_event+0x1591>
    20ce:      	movq	$0x0, 0x68(%rsp)
    20d7:      	movq	0x10(%rsp), %r13
    20dc:      	leaq	0x110(%r13), %rdx
    20e3:      	leaq	0x68(%rsp), %rdi
    20e8:      	movl	$0x8, %ecx
    20ed:      	movl	$0x4, %eax
    20f2:      	leaq	0xd8(%r13), %r12
    20f9:      	movl	$0x8, %esi
    20fe:      	callq	*%rax
    2100:      	movq	0x68(%rsp), %rcx
    2105:      	movl	$0x80, %edx
    210a:      	movl	$0x2d, %eax
    210f:      	movq	0x68(%rsp), %rdx
    2114:      	movq	%r15, %rdi
    2117:      	movl	$0x80, %esi
    211c:      	callq	*%rax
    211e:      	leaq	0x90(%r15), %rdi
    2125:      	movl	$0x4, %ecx
    212a:      	movl	$0x4, %eax
    212f:      	movl	$0x4, %esi
    2134:      	movq	%r12, %rdx
    2137:      	callq	*%rax
    2139:      	leaq	0x80(%r15), %rdi
    2140:      	leaq	0xe0(%r13), %rdx
    2147:      	movl	$0x8, %ecx
    214c:      	movl	$0x4, %eax
    2151:      	movl	$0x8, %esi
    2156:      	callq	*%rax
    2158:      	addq	$0x88, %r15
    215f:      	addq	$0x118, %r13            # imm = 0x118
    2166:      	movl	$0x8, %ecx
    216b:      	movl	$0x4, %eax
    2170:      	movq	%r15, %rdi
    2173:      	movl	$0x8, %esi
    2178:      	movq	%r13, %rdx
    217b:      	callq	*%rax
    217d:      	movl	$0x98, %r13d
    2183:      	jmp	0x1761 <generic_lsm_process_event+0x1591>
    2188:      	movq	%r13, %rcx
    218b:      	cmpl	$0x26, %ecx
    218e:      	movq	0x38(%rsp), %rax
    2193:      	movq	0x20(%rsp), %rcx
    2198:      	movl	$0x4, %esi
    219d:      	movq	0x18(%rsp), %rbx
    21a2:      	movq	%r15, %r14
    21a5:      	movl	$0x0, %r13d
    21ab:      	jne	0x1770 <generic_lsm_process_event+0x15a0>
    21b1:      	movq	0x50(%rsp), %rsi
    21b6:      	movzwl	%si, %edx
    21b9:      	addq	%rbx, %rdx
    21bc:      	shrl	$0x10, %esi
    21bf:      	andl	$0xfff, %esi            # imm = 0xFFF
    21c5:      	leaq	0x4(%rbp), %rdi
    21c9:      	incl	%esi
    21cb:      	movl	$0x2d, %eax
    21d0:      	jmp	0x26cc <generic_lsm_process_event+0x24fc>
    21d5:      	movq	$0x0, 0x70(%rsp)
    21de:      	movl	$0xe, %eax
    21e3:      	callq	*%rax
    21e5:      	shrq	$0x20, %rax
    21e9:      	movq	%rax, 0x68(%rsp)
    21ee:      	leaq	0x58(%rsp), %rdi
    21f3:      	leaq	0x50(%rsp), %rdx
    21f8:      	movl	$0x4, %ecx
    21fd:      	movl	$0x4, %eax
    2202:      	movl	$0x4, %esi
    2207:      	callq	*%rax
    2209:      	movl	0x58(%rsp), %eax
    220d:      	movl	%eax, 0x70(%rsp)
    2211:      	movq	(%rip), %rdi            # 0x2218 <generic_lsm_process_event+0x2048>
    2218:      	leaq	0x68(%rsp), %rsi
    221d:      	movl	$0x1, %eax
    2222:      	callq	*%rax
    2224:      	testq	%rax, %rax
    2227:      	je	0x2c6f <generic_lsm_process_event+0x2a9f>
    222d:      	movq	%rax, %r13
    2230:      	movl	(%rax), %r15d
    2233:      	leaq	0x58(%rsp), %rdx
    2238:      	movl	$0x4, %eax
    223d:      	movq	%rbp, %r12
    2240:      	movl	$0x4, %ebp
    2245:      	movq	%r12, %rdi
    2248:      	movl	$0x4, %esi
    224d:      	callq	*%rax
    224f:      	andl	$0xfff, %r15d           # imm = 0xFFF
    2256:      	leaq	0x4(%r12), %rdi
    225b:      	leaq	0x4(%r15), %rsi
    225f:      	movl	$0x4, %eax
    2264:      	movq	%r13, %rdx
    2267:      	callq	*%rax
    2269:      	leaq	(%r12,%r15), %rdi
    226d:      	addq	$0x8, %rdi
    2271:      	leaq	(%r15,%r13), %rdx
    2275:      	addq	$0x4, %rdx
    2279:      	movl	$0x4, %eax
    227e:      	movl	$0x4, %esi
    2283:      	callq	*%rax
    2285:      	addq	$0xc, %r15
    2289:      	movq	%r15, %r13
    228c:      	jmp	0x1761 <generic_lsm_process_event+0x1591>
    2291:      	movq	0x50(%rsp), %r13
    2296:      	leaq	0xd0(%rsp), %rdi
    229e:      	movl	$0x1, %ecx
    22a3:      	movl	$0x4, %eax
    22a8:      	movl	$0x1, %esi
    22ad:      	movq	%r13, %rdx
    22b0:      	callq	*%rax
    22b2:      	cmpb	$0x1, 0xd0(%rsp)
    22ba:      	jne	0x2c53 <generic_lsm_process_event+0x2a83>
    22c0:      	addq	$0x10, %r13
    22c4:      	leaq	0x58(%rsp), %rdi
    22c9:      	movl	$0x8, %ebp
    22ce:      	movl	$0x8, %ecx
    22d3:      	movl	$0x4, %eax
    22d8:      	movl	$0x8, %esi
    22dd:      	movq	%r13, %rdx
    22e0:      	callq	*%rax
    22e2:      	movq	0x58(%rsp), %rdx
    22e7:      	leaq	0xb0(%rsp), %rdi
    22ef:      	movl	$0x8, %ecx
    22f4:      	movl	$0x4, %eax
    22f9:      	movl	$0x8, %esi
    22fe:      	callq	*%rax
    2300:      	movq	0x58(%rsp), %rdx
    2305:      	addq	$0x8, %rdx
    2309:      	leaq	0x30(%rsp), %rdi
    230e:      	movl	$0x8, %ecx
    2313:      	movl	$0x4, %eax
    2318:      	movl	$0x8, %esi
    231d:      	callq	*%rax
    231f:      	movq	0xb0(%rsp), %rax
    2327:      	movq	%rax, 0xa8(%rsp)
    232f:      	movq	0x30(%rsp), %rax
    2334:      	movq	%rax, 0x10(%rsp)
    2339:      	movq	0x48(%rsp), %rax
    233e:      	addq	%r15, %rax
    2341:      	addq	$0x90, %rax
    2347:      	movq	%rax, 0x40(%rsp)
    234c:      	testb	$0x20, %r12b
    2350:      	je	0x302b <generic_lsm_process_event+0x2e5b>
    2356:      	cmpq	$0x1000, 0x10(%rsp)     # imm = 0x1000
    235f:      	jb	0x3002 <generic_lsm_process_event+0x2e32>
    2365:      	movq	0x40(%rsp), %rax
    236a:      	movl	$0x1, (%rax)
    2370:      	movl	$0x0, 0xc0(%rsp)
    237b:      	movq	(%rip), %rdi            # 0x2382 <generic_lsm_process_event+0x21b2>
    2382:      	leaq	0xc0(%rsp), %rsi
    238a:      	movl	$0x1, %eax
    238f:      	callq	*%rax
    2391:      	movq	%rax, 0x48(%rsp)
    2396:      	testq	%rax, %rax
    2399:      	je	0x36ec <generic_lsm_process_event+0x351c>
    239f:      	movq	0x48(%rsp), %r12
    23a4:      	movl	$0x18, (%r12)
    23ac:      	movl	$0xe, %eax
    23b1:      	callq	*%rax
    23b3:      	leaq	0x10(%r12), %r15
    23b8:      	movq	%rax, 0x10(%r12)
    23bd:      	cmpq	$-0x16, %rax
    23c1:      	jne	0x23e5 <generic_lsm_process_event+0x2215>
    23c3:      	leaq	0x20(%rbx), %rdx
    23c7:      	leaq	0x68(%rsp), %rdi
    23cc:      	movl	$0x8, %ecx
    23d1:      	movl	$0x4, %eax
    23d6:      	movl	$0x8, %esi
    23db:      	callq	*%rax
    23dd:      	movq	0x68(%rsp), %rax
    23e2:      	movq	%rax, (%r15)
    23e5:      	movl	$0x7d, %eax
    23ea:      	callq	*%rax
    23ec:      	movq	0x48(%rsp), %rsi
    23f1:      	movq	%rax, 0x18(%rsi)
    23f5:      	movq	(%r15), %rax
    23f8:      	movq	0x8(%r15), %rcx
    23fc:      	movq	0x40(%rsp), %rdx
    2401:      	movq	%rax, 0x14(%rdx)
    2405:      	movq	%rcx, 0x1c(%rdx)
    2409:      	addq	$0x20, %rsi
    240d:      	movq	%rsi, 0xe8(%rsp)
    2415:      	movl	$0xa, %r15d
    241b:      	xorl	%ebp, %ebp
    241d:      	movq	0x10(%rsp), %r13
    2422:      	subq	%rbp, %r13
    2425:      	js	0x3961 <generic_lsm_process_event+0x3791>
    242b:      	movq	0xa8(%rsp), %rax
    2433:      	leaq	(%rax,%rbp), %rdx
    2437:      	cmpq	$0x7fe0, %r13           # imm = 0x7FE0
    243e:      	movl	$0x7fe0, %eax           # imm = 0x7FE0
    2443:      	cmovaeq	%rax, %r13
    2447:      	movl	$0x4, %eax
    244c:      	movq	0xe8(%rsp), %rdi
    2454:      	movl	%r13d, %esi
    2457:      	callq	*%rax
    2459:      	testl	%eax, %eax
    245b:      	js	0x24ce <generic_lsm_process_event+0x22fe>
    245d:      	leal	0x20(%r13), %r12d
    2461:      	movq	0x48(%rsp), %rax
    2466:      	movl	%r12d, 0x4(%rax)
    246a:      	movl	$0x0, 0x68(%rsp)
    2472:      	movl	$0x1, %eax
    2477:      	movq	(%rip), %rdi            # 0x247e <generic_lsm_process_event+0x22ae>
    247e:      	leaq	0x68(%rsp), %rsi
    2483:      	callq	*%rax
    2485:      	testq	%rax, %rax
    2488:      	je	0x24b0 <generic_lsm_process_event+0x22e0>
    248a:      	cmpb	$0x0, 0x28(%rax)
    248e:      	je	0x24b0 <generic_lsm_process_event+0x22e0>
    2490:      	movl	$0x19, %eax
    2495:      	movq	%rbx, %rdi
    2498:      	movq	0x48(%rsp), %rcx
    249d:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    24a2:      	movq	(%rip), %rsi            # 0x24a9 <generic_lsm_process_event+0x22d9>
    24a9:      	movq	%r12, %r8
    24ac:      	callq	*%rax
    24ae:      	jmp	0x24ca <generic_lsm_process_event+0x22fa>
    24b0:      	movl	$0x82, %eax
    24b5:      	movq	0x48(%rsp), %rsi
    24ba:      	xorl	%ecx, %ecx
    24bc:      	movq	(%rip), %rdi            # 0x24c3 <generic_lsm_process_event+0x22f3>
    24c3:      	movq	%r12, %rdx
    24c6:      	xorl	%ecx, %ecx
    24c8:      	callq	*%rax
    24ca:      	testl	%eax, %eax
    24cc:      	jns	0x24d1 <generic_lsm_process_event+0x2301>
    24ce:      	movslq	%eax, %r13
    24d1:      	testl	%r13d, %r13d
    24d4:      	js	0x396a <generic_lsm_process_event+0x379a>
    24da:      	andl	$0x7fffffff, %r13d      # imm = 0x7FFFFFFF
    24e1:      	addq	%r13, %rbp
    24e4:      	cmpq	0x10(%rsp), %rbp
    24e9:      	je	0x39c4 <generic_lsm_process_event+0x37f4>
    24ef:      	decl	%r15d
    24f2:      	jne	0x241d <generic_lsm_process_event+0x224d>
    24f8:      	jmp	0x3d1c <generic_lsm_process_event+0x3b4c>
    24fd:      	movq	0x50(%rsp), %r13
    2502:      	movq	%rbp, %rbx
    2505:      	leaq	0x28(%rbp), %rdi
    2509:      	leaq	0x98(%r13), %rdx
    2510:      	movl	$0x4, %ecx
    2515:      	movl	$0x4, %eax
    251a:      	movl	$0x4, %esi
    251f:      	callq	*%rax
    2521:      	leaq	0x2c(%rbp), %rdi
    2525:      	leaq	0x70(%r13), %rdx
    2529:      	movl	$0x4, %ecx
    252e:      	movl	$0x4, %eax
    2533:      	movl	$0x4, %esi
    2538:      	callq	*%rax
    253a:      	leaq	0x30(%rbp), %rdi
    253e:      	leaq	0x90(%r13), %rdx
    2545:      	movl	$0x4, %ecx
    254a:      	movl	$0x4, %eax
    254f:      	movl	$0x4, %esi
    2554:      	callq	*%rax
    2556:      	leaq	0x34(%rbp), %rdi
    255a:      	leaq	0xa8(%r13), %rdx
    2561:      	movl	$0x4, %ecx
    2566:      	movl	$0x4, %eax
    256b:      	movl	$0x4, %esi
    2570:      	callq	*%rax
    2572:      	movq	$0x0, 0x68(%rsp)
    257b:      	leaq	0xc8(%r13), %rdx
    2582:      	leaq	0x68(%rsp), %rdi
    2587:      	movl	$0x8, %ecx
    258c:      	movl	$0x4, %eax
    2591:      	movl	$0x8, %esi
    2596:      	callq	*%rax
    2598:      	leaq	0xb8(%r13), %rdx
    259f:      	leaq	0x30(%rsp), %rdi
    25a4:      	movl	$0x2, %ecx
    25a9:      	movl	$0x4, %eax
    25ae:      	movl	$0x2, %esi
    25b3:      	callq	*%rax
    25b5:      	movzwl	0x30(%rsp), %r12d
    25bb:      	addq	0x68(%rsp), %r12
    25c0:      	leaq	0xdc(%rsp), %rdi
    25c8:      	movl	$0x1, %ecx
    25cd:      	movl	$0x4, %eax
    25d2:      	movl	$0x1, %esi
    25d7:      	movq	%r12, %rdx
    25da:      	callq	*%rax
    25dc:      	movzbl	0xdc(%rsp), %eax
    25e4:      	shrl	$0x4, %eax
    25e7:      	cmpl	$0x6, %eax
    25ea:      	je	0x2c7b <generic_lsm_process_event+0x2aab>
    25f0:      	cmpl	$0x4, %eax
    25f3:      	jne	0x4249 <generic_lsm_process_event+0x4079>
    25f9:      	leaq	0x9(%r12), %rdx
    25fe:      	leaq	0xd0(%rsp), %rdi
    2606:      	movl	$0x1, %ecx
    260b:      	movl	$0x4, %eax
    2610:      	movl	$0x1, %esi
    2615:      	callq	*%rax
    2617:      	movzbl	0xd0(%rsp), %eax
    261f:      	movq	%rbp, %rdi
    2622:      	movw	%ax, 0x24(%rbp)
    2626:      	movw	$0x2, 0x26(%rbp)
    262c:      	leaq	0xc(%r12), %rdx
    2631:      	movq	$0x0, (%rbp)
    2639:      	movq	$0x0, 0x8(%rbp)
    2641:      	movq	$0x0, 0x10(%rbp)
    2649:      	movq	$0x0, 0x18(%rbp)
    2651:      	movl	$0x4, %ecx
    2656:      	movl	$0x4, %eax
    265b:      	leaq	0x10(%rbp), %rbx
    265f:      	movl	$0x4, %esi
    2664:      	callq	*%rax
    2666:      	addq	$0x10, %r12
    266a:      	movl	$0x4, %ecx
    266f:      	movl	$0x4, %eax
    2674:      	movq	%rbx, %rdi
    2677:      	movl	$0x4, %esi
    267c:      	movq	%r12, %rdx
    267f:      	callq	*%rax
    2681:      	leaq	0xb6(%r13), %rdx
    2688:      	leaq	0xc0(%rsp), %rdi
    2690:      	movl	$0x2, %ecx
    2695:      	movl	$0x4, %eax
    269a:      	movl	$0x2, %esi
    269f:      	callq	*%rax
    26a1:      	movzbl	0xd0(%rsp), %r15d
    26aa:      	jmp	0x40fa <generic_lsm_process_event+0x3f2a>
    26af:      	movl	$0x120, %edx            # imm = 0x120
    26b4:      	addq	0x50(%rsp), %rdx
    26b9:      	leaq	0x4(%rbp), %rdi
    26bd:      	movl	$0x11, %ecx
    26c2:      	movl	$0x2d, %eax
    26c7:      	movl	$0x11, %esi
    26cc:      	callq	*%rax
    26ce:      	movq	%rax, %r13
    26d1:      	testq	%rax, %rax
    26d4:      	js	0x2fe6 <generic_lsm_process_event+0x2e16>
    26da:      	leal	-0x1(%r13), %eax
    26de:      	movl	%eax, (%rbp)
    26e1:      	addq	$0x3, %r13
    26e5:      	jmp	0x2fe6 <generic_lsm_process_event+0x2e16>
    26ea:      	movq	0x50(%rsp), %r12
    26ef:      	movq	%rbp, %rdi
    26f2:      	movq	$0x0, 0x10(%rbp)
    26fa:      	movq	$0x0, 0x8(%rbp)
    2702:      	movq	$0x0, (%rbp)
    270a:      	movl	$0x2, %ecx
    270f:      	movl	$0x4, %eax
    2714:      	movl	$0x2, %esi
    2719:      	movq	%r12, %rdx
    271c:      	callq	*%rax
    271e:      	testq	%rax, %rax
    2721:      	js	0x2f05 <generic_lsm_process_event+0x2d35>
    2727:      	movzwl	(%rbp), %eax
    272b:      	cmpl	$0xa, %eax
    272e:      	je	0x2ec2 <generic_lsm_process_event+0x2cf2>
    2734:      	cmpl	$0x2, %eax
    2737:      	jne	0x2efb <generic_lsm_process_event+0x2d2b>
    273d:      	leaq	0x4(%r12), %rdx
    2742:      	leaq	0x68(%rsp), %rdi
    2747:      	movl	$0x4, %ecx
    274c:      	movl	$0x4, %eax
    2751:      	movl	$0x4, %esi
    2756:      	callq	*%rax
    2758:      	movl	0x68(%rsp), %eax
    275c:      	movq	%rax, 0x8(%rbp)
    2760:      	leaq	0x2(%rbp), %rdi
    2764:      	addq	$0x2, %r12
    2768:      	movl	$0x2, %ecx
    276d:      	movl	$0x4, %eax
    2772:      	jmp	0x2ef1 <generic_lsm_process_event+0x2d21>
    2777:      	movq	0x48(%rsp), %rax
    277c:      	addq	%rbp, %rax
    277f:      	addq	$0x90, %rax
    2785:      	movq	%rax, 0xa8(%rsp)
    278d:      	movq	$0x0, 0x50(%rsp)
    2796:      	testb	$0x10, %r12b
    279a:      	jne	0x2dd6 <generic_lsm_process_event+0x2c06>
    27a0:      	movl	%r12d, %r15d
    27a3:      	movq	0x40(%rsp), %rdx
    27a8:      	andl	$0xf, %edx
    27ab:      	xorl	%eax, %eax
    27ad:      	movq	%rdx, %rcx
    27b0:      	cmpl	$0x2, %edx
    27b3:      	jle	0x309f <generic_lsm_process_event+0x2ecf>
    27b9:      	cmpl	$0x3, %ecx
    27bc:      	je	0x36f7 <generic_lsm_process_event+0x3527>
    27c2:      	cmpl	$0x4, %ecx
    27c5:      	je	0x3700 <generic_lsm_process_event+0x3530>
    27cb:      	cmpl	$0x5, %ecx
    27ce:      	jne	0x3713 <generic_lsm_process_event+0x3543>
    27d4:      	leaq	0x5e70(%rbp), %rax
    27db:      	jmp	0x3710 <generic_lsm_process_event+0x3540>
    27e0:      	movq	%r15, %rbx
    27e3:      	leaq	0x28(%r15), %r13
    27e7:      	leaq	0x40(%r15), %r12
    27eb:      	movq	0x10(%rsp), %r15
    27f0:      	leaq	0x8(%r15), %rdx
    27f4:      	movl	$0x4, %ecx
    27f9:      	movl	$0x4, %eax
    27fe:      	movq	%rbx, %rdi
    2801:      	movl	$0x4, %esi
    2806:      	callq	*%rax
    2808:      	leaq	0x4(%rbx), %rdi
    280c:      	leaq	0xc(%r15), %rdx
    2810:      	movl	$0x4, %ecx
    2815:      	movl	$0x4, %eax
    281a:      	movl	$0x4, %esi
    281f:      	callq	*%rax
    2821:      	leaq	0x10(%rbx), %rdi
    2825:      	leaq	0x18(%r15), %rdx
    2829:      	movl	$0x4, %ecx
    282e:      	movl	$0x4, %eax
    2833:      	movl	$0x4, %esi
    2838:      	callq	*%rax
    283a:      	leaq	0x14(%rbx), %rdi
    283e:      	leaq	0x1c(%r15), %rdx
    2842:      	movl	$0x4, %ecx
    2847:      	movl	$0x4, %eax
    284c:      	movl	$0x4, %esi
    2851:      	callq	*%rax
    2853:      	leaq	0x8(%rbx), %rdi
    2857:      	leaq	0x10(%r15), %rdx
    285b:      	movl	$0x4, %ecx
    2860:      	movl	$0x4, %eax
    2865:      	movl	$0x4, %esi
    286a:      	callq	*%rax
    286c:      	leaq	0xc(%rbx), %rdi
    2870:      	leaq	0x14(%r15), %rdx
    2874:      	movl	$0x4, %ecx
    2879:      	movl	$0x4, %eax
    287e:      	movl	$0x4, %esi
    2883:      	callq	*%rax
    2885:      	leaq	0x18(%rbx), %rdi
    2889:      	leaq	0x20(%r15), %rdx
    288d:      	movl	$0x4, %ecx
    2892:      	movl	$0x4, %eax
    2897:      	movl	$0x4, %esi
    289c:      	callq	*%rax
    289e:      	leaq	0x1c(%rbx), %rdi
    28a2:      	leaq	0x24(%r15), %rdx
    28a6:      	movl	$0x4, %ecx
    28ab:      	movl	$0x4, %eax
    28b0:      	movl	$0x4, %esi
    28b5:      	callq	*%rax
    28b7:      	movl	$0x0, 0x24(%rbx)
    28be:      	leaq	0x20(%rbx), %rdi
    28c2:      	leaq	0x28(%r15), %rdx
    28c6:      	movl	$0x4, %ecx
    28cb:      	movl	$0x4, %eax
    28d0:      	movl	$0x4, %esi
    28d5:      	callq	*%rax
    28d7:      	leaq	0x30(%rbx), %rdi
    28db:      	leaq	0x40(%r15), %rdx
    28df:      	movl	$0x8, %ecx
    28e4:      	movl	$0x4, %eax
    28e9:      	movl	$0x8, %esi
    28ee:      	callq	*%rax
    28f0:      	leaq	0x38(%rbx), %rdi
    28f4:      	leaq	0x30(%r15), %rdx
    28f8:      	movl	$0x8, %ecx
    28fd:      	movl	$0x4, %eax
    2902:      	movl	$0x8, %esi
    2907:      	callq	*%rax
    2909:      	leaq	0x38(%r15), %rdx
    290d:      	movl	$0x8, %ecx
    2912:      	movl	$0x4, %eax
    2917:      	movq	%r13, %rdi
    291a:      	movl	$0x8, %esi
    291f:      	callq	*%rax
    2921:      	addq	$0x90, %r15
    2928:      	leaq	0x68(%rsp), %rdi
    292d:      	movl	$0x8, %ecx
    2932:      	movl	$0x4, %eax
    2937:      	movl	$0x8, %esi
    293c:      	movq	%r15, %rdx
    293f:      	callq	*%rax
    2941:      	movq	0x68(%rsp), %r13
    2946:      	leaq	0xc8(%r13), %rdx
    294d:      	movl	$0x4, %ecx
    2952:      	movl	$0x4, %eax
    2957:      	movq	%r12, %rdi
    295a:      	movl	$0x4, %esi
    295f:      	callq	*%rax
    2961:      	leaq	0x44(%rbx), %rdi
    2965:      	leaq	0xcc(%r13), %rdx
    296c:      	movl	$0x4, %ecx
    2971:      	movl	$0x4, %eax
    2976:      	movl	$0x4, %esi
    297b:      	callq	*%rax
    297d:      	leaq	0x48(%rbx), %rdi
    2981:      	leaq	0xd0(%r13), %rdx
    2988:      	movl	$0x4, %ecx
    298d:      	movl	$0x4, %eax
    2992:      	movl	$0x4, %esi
    2997:      	callq	*%rax
    2999:      	addq	$0x4c, %rbx
    299d:      	addq	$0x158, %r13            # imm = 0x158
    29a4:      	movl	$0x4, %ecx
    29a9:      	movl	$0x4, %eax
    29ae:      	movq	%rbx, %rdi
    29b1:      	movl	$0x4, %esi
    29b6:      	movq	%r13, %rdx
    29b9:      	callq	*%rax
    29bb:      	movl	$0x50, %r13d
    29c1:      	jmp	0x3eba <generic_lsm_process_event+0x3cea>
    29c6:      	movq	0x10(%rsp), %r12
    29cb:      	leaq	0xc8(%r12), %rdx
    29d3:      	movl	$0x4, %ecx
    29d8:      	movl	$0x4, %eax
    29dd:      	movq	%r15, %rdi
    29e0:      	movl	$0x4, %esi
    29e5:      	callq	*%rax
    29e7:      	leaq	0x4(%r15), %rdi
    29eb:      	leaq	0xcc(%r12), %rdx
    29f3:      	movl	$0x4, %ecx
    29f8:      	movl	$0x4, %eax
    29fd:      	movl	$0x4, %esi
    2a02:      	callq	*%rax
    2a04:      	leaq	0x8(%r15), %rdi
    2a08:      	leaq	0xd0(%r12), %rdx
    2a10:      	movl	$0x4, %ecx
    2a15:      	movl	$0x4, %eax
    2a1a:      	movl	$0x4, %esi
    2a1f:      	callq	*%rax
    2a21:      	addq	$0xc, %r15
    2a25:      	addq	$0x158, %r12            # imm = 0x158
    2a2c:      	movl	$0x4, %ecx
    2a31:      	movl	$0x4, %eax
    2a36:      	movq	%r15, %rdi
    2a39:      	movl	$0x4, %esi
    2a3e:      	movq	%r12, %rdx
    2a41:      	callq	*%rax
    2a43:      	movl	$0x10, %r13d
    2a49:      	jmp	0x3eba <generic_lsm_process_event+0x3cea>
    2a4e:      	movq	0x10(%rsp), %r12
    2a53:      	leaq	0x38(%r12), %rdx
    2a58:      	movl	$0x4, %ecx
    2a5d:      	movl	$0x4, %eax
    2a62:      	movq	%r15, %rdi
    2a65:      	movl	$0x4, %esi
    2a6a:      	callq	*%rax
    2a6c:      	leaq	0x4(%r15), %rdi
    2a70:      	leaq	0x3c(%r12), %rdx
    2a75:      	movl	$0x4, %ecx
    2a7a:      	movl	$0x4, %eax
    2a7f:      	movl	$0x4, %esi
    2a84:      	callq	*%rax
    2a86:      	leaq	0x8(%r15), %rdi
    2a8a:      	leaq	0x40(%r12), %rdx
    2a8f:      	movl	$0x4, %ecx
    2a94:      	movl	$0x4, %eax
    2a99:      	movl	$0x4, %esi
    2a9e:      	callq	*%rax
    2aa0:      	leaq	0xc(%r15), %rdi
    2aa4:      	leaq	0x44(%r12), %rdx
    2aa9:      	movl	$0x4, %ecx
    2aae:      	movl	$0x4, %eax
    2ab3:      	movl	$0x4, %esi
    2ab8:      	callq	*%rax
    2aba:      	addq	$0x10, %r15
    2abe:      	subq	$-0x80, %r12
    2ac2:      	movl	$0x10, %ecx
    2ac7:      	movl	$0x4, %eax
    2acc:      	movq	%r15, %rdi
    2acf:      	movl	$0x10, %esi
    2ad4:      	movq	%r12, %rdx
    2ad7:      	callq	*%rax
    2ad9:      	movl	$0x20, %r13d
    2adf:      	jmp	0x3eba <generic_lsm_process_event+0x3cea>
    2ae4:      	movl	$0x4, %ecx
    2ae9:      	movl	$0x4, %eax
    2aee:      	movq	%r15, %rbx
    2af1:      	movq	0x10(%rsp), %r15
    2af6:      	movq	%rbx, %rdi
    2af9:      	movl	$0x4, %esi
    2afe:      	movq	%r15, %rdx
    2b01:      	callq	*%rax
    2b03:      	leaq	0x4(%rbx), %rdi
    2b07:      	leaq	0x4(%r15), %rdx
    2b0b:      	movl	$0x4, %ecx
    2b10:      	movl	$0x4, %eax
    2b15:      	movl	$0x4, %esi
    2b1a:      	callq	*%rax
    2b1c:      	addq	$0x8, %rbx
    2b20:      	addq	$0x30, %r15
    2b24:      	movl	$0x10, %ecx
    2b29:      	movl	$0x4, %eax
    2b2e:      	movq	%rbx, %rdi
    2b31:      	movl	$0x10, %esi
    2b36:      	movq	%r15, %rdx
    2b39:      	jmp	0x2bca <generic_lsm_process_event+0x29fa>
    2b3e:      	movq	0x10(%rsp), %r15
    2b43:      	leaq	0x4(%r15), %rdx
    2b47:      	leaq	0x68(%rsp), %rdi
    2b4c:      	movl	$0x4, %ecx
    2b51:      	movl	$0x4, %eax
    2b56:      	movl	$0x4, %esi
    2b5b:      	callq	*%rax
    2b5d:      	movl	0x68(%rsp), %eax
    2b61:      	movl	%eax, (%rbp)
    2b64:      	leaq	0xc(%r15), %rdx
    2b68:      	leaq	0x68(%rsp), %rdi
    2b6d:      	movl	$0x4, %ecx
    2b72:      	movl	$0x4, %eax
    2b77:      	movl	$0x4, %esi
    2b7c:      	callq	*%rax
    2b7e:      	movl	0x68(%rsp), %eax
    2b82:      	movl	%eax, 0x4(%rbp)
    2b85:      	addq	$0x50, %r15
    2b89:      	leaq	0x68(%rsp), %rdi
    2b8e:      	movl	$0x8, %ecx
    2b93:      	movl	$0x2d, %eax
    2b98:      	movl	$0x8, %esi
    2b9d:      	movq	%r15, %rdx
    2ba0:      	callq	*%rax
    2ba2:      	addq	$0x8, %rbp
    2ba6:      	movl	$0x3f8, %edx            # imm = 0x3F8
    2bab:      	movq	0x68(%rsp), %rcx
    2bb0:      	addq	%rdx, %rcx
    2bb3:      	movl	$0x10, %esi
    2bb8:      	movl	$0x2d, %eax
    2bbd:      	addq	0x68(%rsp), %rdx
    2bc2:      	movq	%rbp, %rdi
    2bc5:      	movl	$0x10, %esi
    2bca:      	callq	*%rax
    2bcc:      	movl	$0x18, %r13d
    2bd2:      	jmp	0x3eba <generic_lsm_process_event+0x3cea>
    2bd7:      	movq	$0x0, 0x48(%rbp)
    2bdf:      	movq	$0x0, 0x40(%rbp)
    2be7:      	movq	$0x0, 0x38(%rbp)
    2bef:      	movq	$0x0, 0x30(%rbp)
    2bf7:      	movq	$0x0, 0x28(%rbp)
    2bff:      	movq	$0x0, 0x20(%rbp)
    2c07:      	movq	$0x0, 0x18(%rbp)
    2c0f:      	movq	$0x0, 0x10(%rbp)
    2c17:      	movq	$0x0, 0x8(%rbp)
    2c1f:      	movq	$0x0, (%rbp)
    2c27:      	leaq	0x68(%rsp), %rdi
    2c2c:      	movl	$0x8, %ecx
    2c31:      	movl	$0x4, %eax
    2c36:      	movq	0x10(%rsp), %rdx
    2c3b:      	movl	$0x8, %esi
    2c40:      	callq	*%rax
    2c42:      	testq	%rax, %rax
    2c45:      	je	0x2f10 <generic_lsm_process_event+0x2d40>
    2c4b:      	xorl	%r13d, %r13d
    2c4e:      	jmp	0x3eba <generic_lsm_process_event+0x3cea>
    2c53:      	movq	0x48(%rsp), %rax
    2c58:      	movq	$0x0, 0x90(%r15,%rax)
    2c64:      	movl	$0x8, %r13d
    2c6a:      	jmp	0x1761 <generic_lsm_process_event+0x1591>
    2c6f:      	movq	$-0x1, %r13
    2c76:      	jmp	0x1761 <generic_lsm_process_event+0x1591>
    2c7b:      	movq	0x68(%rsp), %r14
    2c80:      	movl	$0x0, 0x58(%rsp)
    2c88:      	movzwl	0x30(%rsp), %r15d
    2c8e:      	movq	(%rip), %rdi            # 0x2c95 <generic_lsm_process_event+0x2ac5>
    2c95:      	leaq	0x58(%rsp), %rsi
    2c9a:      	movl	$0x1, %eax
    2c9f:      	leaq	(%r14,%r15), %r12
    2ca3:      	callq	*%rax
    2ca5:      	testq	%rax, %rax
    2ca8:      	je	0x40a9 <generic_lsm_process_event+0x3ed9>
    2cae:      	movq	%rax, %rbx
    2cb1:      	movw	%r15w, (%rax)
    2cb5:      	movb	$-0x1, 0x5(%rax)
    2cb9:      	movb	$0x0, 0x7(%rax)
    2cbd:      	movq	%rax, %rdi
    2cc0:      	addq	$0x6, %rdi
    2cc4:      	leaq	0x6(%r12), %rdx
    2cc9:      	movl	$0x1, %ecx
    2cce:      	movl	$0x4, %eax
    2cd3:      	movq	%rdi, 0x10(%rsp)
    2cd8:      	movl	$0x1, %esi
    2cdd:      	callq	*%rax
    2cdf:      	testq	%rax, %rax
    2ce2:      	js	0x40a9 <generic_lsm_process_event+0x3ed9>
    2ce8:      	movzbl	0x5(%rbx), %eax
    2cec:      	cmpl	$0x32, %eax
    2cef:      	jg	0x362a <generic_lsm_process_event+0x345a>
    2cf5:      	testl	%eax, %eax
    2cf7:      	je	0x36dc <generic_lsm_process_event+0x350c>
    2cfd:      	cmpl	$0x2b, %eax
    2d00:      	je	0x36dc <generic_lsm_process_event+0x350c>
    2d06:      	cmpl	$0x2c, %eax
    2d09:      	jne	0x3a9b <generic_lsm_process_event+0x38cb>
    2d0f:      	movw	$0x8, 0x2(%rbx)
    2d15:      	movw	$0x8, %ax
    2d19:      	jmp	0x39dd <generic_lsm_process_event+0x380d>
    2d1e:      	leaq	0x48(%r12), %rdx
    2d23:      	movl	$0x10, %ecx
    2d28:      	movl	$0x4, %eax
    2d2d:      	movq	%rbp, %rdi
    2d30:      	movl	$0x10, %esi
    2d35:      	callq	*%rax
    2d37:      	leaq	0x38(%r12), %rdx
    2d3c:      	movl	$0x10, %ecx
    2d41:      	movl	$0x4, %eax
    2d46:      	movq	%r13, %rdi
    2d49:      	movl	$0x10, %esi
    2d4e:      	callq	*%rax
    2d50:      	leaq	0x20(%rbp), %rdi
    2d54:      	leaq	0xc(%r12), %r13
    2d59:      	addq	$0xe, %r12
    2d5d:      	movl	$0x2, %ecx
    2d62:      	movl	$0x4, %eax
    2d67:      	movl	$0x2, %esi
    2d6c:      	movq	%r12, %rdx
    2d6f:      	callq	*%rax
    2d71:      	leaq	0x22(%rbp), %rdi
    2d75:      	movl	$0x2, %ecx
    2d7a:      	movl	$0x4, %eax
    2d7f:      	movl	$0x2, %esi
    2d84:      	movq	%r13, %rdx
    2d87:      	callq	*%rax
    2d89:      	movzwl	0x22(%rbp), %eax
    2d8d:      	movbew	%ax, 0x22(%rbp)
    2d93:      	movq	0x50(%rsp), %rax
    2d98:      	movq	%rax, 0x68(%rsp)
    2d9d:      	movq	(%rip), %rdi            # 0x2da4 <generic_lsm_process_event+0x2bd4>
    2da4:      	leaq	0x68(%rsp), %rsi
    2da9:      	movl	$0x1, %eax
    2dae:      	callq	*%rax
    2db0:      	testq	%rax, %rax
    2db3:      	je	0x4249 <generic_lsm_process_event+0x4079>
    2db9:      	movl	(%rax), %ecx
    2dbb:      	movq	%r15, %rbp
    2dbe:      	movl	%ecx, 0x10(%r15)
    2dc2:      	movq	0x8(%rax), %rcx
    2dc6:      	movq	%rcx, 0x18(%r15)
    2dca:      	movl	0x4(%rax), %eax
    2dcd:      	movl	%eax, 0x7c(%r15)
    2dd1:      	jmp	0x4249 <generic_lsm_process_event+0x4079>
    2dd6:      	movl	$0xe, %eax
    2ddb:      	callq	*%rax
    2ddd:      	cmpq	$-0x16, %rax
    2de1:      	jne	0x2e07 <generic_lsm_process_event+0x2c37>
    2de3:      	movq	0x18(%rsp), %rax
    2de8:      	leaq	0x20(%rax), %rdx
    2dec:      	leaq	0x68(%rsp), %rdi
    2df1:      	movl	$0x8, %ecx
    2df6:      	movl	$0x4, %eax
    2dfb:      	movl	$0x8, %esi
    2e00:      	callq	*%rax
    2e02:      	movq	0x68(%rsp), %rax
    2e07:      	movq	0x8(%rbp), %rcx
    2e0b:      	movq	0x60(%rbp), %rdx
    2e0f:      	movq	%rcx, 0x68(%rsp)
    2e14:      	movq	0x10(%rsp), %rcx
    2e19:      	movq	%rcx, 0x70(%rsp)
    2e1e:      	movq	$0x0, 0x78(%rsp)
    2e27:      	movq	%rdx, 0x58(%rsp)
    2e2c:      	movq	%rax, 0x60(%rsp)
    2e31:      	movq	(%rip), %rdi            # 0x2e38 <generic_lsm_process_event+0x2c68>
    2e38:      	xorl	%ecx, %ecx
    2e3a:      	leaq	0x58(%rsp), %rsi
    2e3f:      	leaq	0x68(%rsp), %rdx
    2e44:      	movl	$0x2, %eax
    2e49:      	xorl	%ecx, %ecx
    2e4b:      	callq	*%rax
    2e4d:      	testq	%rax, %rax
    2e50:      	je	0x3683 <generic_lsm_process_event+0x34b3>
    2e56:      	negl	%eax
    2e58:      	movw	%ax, 0xb0(%rsp)
    2e60:      	movw	$0x5, 0xb2(%rsp)
    2e6a:      	movabsq	$0x200000046, %rax      # imm = 0x200000046
    2e74:      	movq	%rax, 0xb4(%rsp)
    2e7c:      	movq	(%rip), %rdi            # 0x2e83 <generic_lsm_process_event+0x2cb3>
    2e83:      	leaq	0xb0(%rsp), %rsi
    2e8b:      	movl	$0x1, %eax
    2e90:      	callq	*%rax
    2e92:      	testq	%rax, %rax
    2e95:      	je	0x3656 <generic_lsm_process_event+0x3486>
    2e9b:      	incl	(%rax)
    2e9d:      	jmp	0x3683 <generic_lsm_process_event+0x34b3>
    2ea2:      	cmpl	$0x1, %eax
    2ea5:      	je	0x318f <generic_lsm_process_event+0x2fbf>
    2eab:      	cmpl	$0x2, %eax
    2eae:      	jne	0x3531 <generic_lsm_process_event+0x3361>
    2eb4:      	movq	%rbp, %rax
    2eb7:      	addq	$0x5e58, %rax           # imm = 0x5E58
    2ebd:      	jmp	0x3198 <generic_lsm_process_event+0x2fc8>
    2ec2:      	movq	%rbp, %rbx
    2ec5:      	leaq	0x8(%rbp), %rdi
    2ec9:      	leaq	0x8(%r12), %rdx
    2ece:      	movl	$0x10, %ecx
    2ed3:      	movl	$0x4, %eax
    2ed8:      	movl	$0x10, %esi
    2edd:      	callq	*%rax
    2edf:      	leaq	0x2(%rbp), %rdi
    2ee3:      	addq	$0x2, %r12
    2ee7:      	movl	$0x2, %ecx
    2eec:      	movl	$0x4, %eax
    2ef1:      	movl	$0x2, %esi
    2ef6:      	movq	%r12, %rdx
    2ef9:      	callq	*%rax
    2efb:      	movzwl	0x2(%rbp), %eax
    2eff:      	movbew	%ax, 0x2(%rbp)
    2f05:      	movl	$0x18, %r13d
    2f0b:      	jmp	0x2fe6 <generic_lsm_process_event+0x2e16>
    2f10:      	leaq	0x10(%rbp), %rdi
    2f14:      	movq	0x68(%rsp), %rcx
    2f19:      	movl	$0x3f, %edx
    2f1e:      	movl	$0x2d, %eax
    2f23:      	movq	0x68(%rsp), %rdx
    2f28:      	movl	$0x3f, %esi
    2f2d:      	callq	*%rax
    2f2f:      	testq	%rax, %rax
    2f32:      	js	0x2c4b <generic_lsm_process_event+0x2a7b>
    2f38:      	movq	0x10(%rsp), %rbx
    2f3d:      	leaq	0x8(%rbx), %rdx
    2f41:      	leaq	0x58(%rsp), %rdi
    2f46:      	movl	$0x8, %ecx
    2f4b:      	movl	$0x4, %eax
    2f50:      	movl	$0x8, %esi
    2f55:      	callq	*%rax
    2f57:      	leaq	0x8(%rbp), %rdi
    2f5b:      	movl	$0x348, %edx            # imm = 0x348
    2f60:      	movq	0x58(%rsp), %rcx
    2f65:      	addq	%rdx, %rcx
    2f68:      	movl	$0x8, %esi
    2f6d:      	movl	$0x4, %eax
    2f72:      	addq	0x58(%rsp), %rdx
    2f77:      	movl	$0x8, %esi
    2f7c:      	callq	*%rax
    2f7e:      	addq	$0x58, %rbx
    2f82:      	leaq	0x58(%rsp), %rdi
    2f87:      	movl	$0x4, %ecx
    2f8c:      	movl	$0x4, %eax
    2f91:      	movl	$0x4, %esi
    2f96:      	movq	%rbx, %rdx
    2f99:      	callq	*%rax
    2f9b:      	movl	$0x50, %r13d
    2fa1:      	testq	%rax, %rax
    2fa4:      	jne	0x3eba <generic_lsm_process_event+0x3cea>
    2faa:      	xorl	%eax, %eax
    2fac:      	cmpl	$0x0, 0x58(%rsp)
    2fb1:      	setne	%al
    2fb4:      	movl	%eax, (%rbp)
    2fb7:      	jmp	0x3eba <generic_lsm_process_event+0x3cea>
    2fbc:      	addq	$0x3, %r12
    2fc0:      	movl	$0x6b, %ecx
    2fc5:      	movl	$0x71, %eax
    2fca:      	movl	$0x6b, %esi
    2fcf:      	movq	%r12, %rdx
    2fd2:      	callq	*%rax
    2fd4:      	movq	%rax, %rcx
    2fd7:      	movb	$0x6b, %al
    2fd9:      	testl	%ecx, %ecx
    2fdb:      	js	0x2fe0 <generic_lsm_process_event+0x2e10>
    2fdd:      	movb	%al, 0x3(%rbp)
    2fe0:      	movl	$0x70, %r13d
    2fe6:      	movq	0x38(%rsp), %rax
    2feb:      	movq	0x20(%rsp), %rcx
    2ff0:      	movl	$0x4, %esi
    2ff5:      	movq	0x18(%rsp), %rbx
    2ffa:      	movq	%r15, %r14
    2ffd:      	jmp	0x1770 <generic_lsm_process_event+0x15a0>
    3002:      	addq	$0x90, %r15
    3009:      	movq	0xc8(%rsp), %rax
    3011:      	movl	$0x0, 0x4(%r15,%rax)
    301a:      	addq	%r15, %rax
    301d:      	addq	$0x8, %rax
    3021:      	movq	%rax, 0x40(%rsp)
    3026:      	movl	$0xc, %ebp
    302b:      	movq	0x10(%rsp), %rax
    3030:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    3036:      	movl	$0xfff, %r13d           # imm = 0xFFF
    303c:      	cmovbq	%rax, %r13
    3040:      	movq	0x40(%rsp), %rax
    3045:      	leaq	0x8(%rax), %rdi
    3049:      	movl	$0x4, %eax
    304e:      	movq	0xa8(%rsp), %rdx
    3056:      	movl	%r13d, %esi
    3059:      	callq	*%rax
    305b:      	testl	%eax, %eax
    305d:      	js	0x307a <generic_lsm_process_event+0x2eaa>
    305f:      	movq	0x40(%rsp), %rax
    3064:      	movq	0x10(%rsp), %rcx
    3069:      	movl	%ecx, (%rax)
    306b:      	movl	%r13d, 0x4(%rax)
    306f:      	addq	%r13, %rbp
    3072:      	movq	%rbp, %r13
    3075:      	jmp	0x1761 <generic_lsm_process_event+0x1591>
    307a:      	movq	0x40(%rsp), %rax
    307f:      	movl	$0xfffffffe, (%rax)     # imm = 0xFFFFFFFE
    3085:      	movq	0x38(%rsp), %rax
    308a:      	movq	0x20(%rsp), %rcx
    308f:      	movl	$0x4, %esi
    3094:      	movl	$0x4, %r13d
    309a:      	jmp	0x1770 <generic_lsm_process_event+0x15a0>
    309f:      	cmpl	$0x1, %ecx
    30a2:      	je	0x3709 <generic_lsm_process_event+0x3539>
    30a8:      	cmpl	$0x2, %ecx
    30ab:      	jne	0x3713 <generic_lsm_process_event+0x3543>
    30b1:      	leaq	0x5e58(%rbp), %rax
    30b8:      	jmp	0x3710 <generic_lsm_process_event+0x3540>
    30bd:      	leaq	0x48(%r12), %rdx
    30c2:      	movl	$0x10, %ecx
    30c7:      	movl	$0x4, %eax
    30cc:      	movq	%rbp, %rdi
    30cf:      	movl	$0x10, %esi
    30d4:      	callq	*%rax
    30d6:      	leaq	0x38(%r12), %rdx
    30db:      	movl	$0x10, %ecx
    30e0:      	movl	$0x4, %eax
    30e5:      	movq	%r13, %rdi
    30e8:      	movl	$0x10, %esi
    30ed:      	callq	*%rax
    30ef:      	movq	%rbp, %rbx
    30f2:      	leaq	0x20(%rbp), %rdi
    30f6:      	leaq	0xc(%r12), %r13
    30fb:      	addq	$0xe, %r12
    30ff:      	movl	$0x2, %ecx
    3104:      	movl	$0x4, %eax
    3109:      	movl	$0x2, %esi
    310e:      	movq	%r12, %rdx
    3111:      	callq	*%rax
    3113:      	leaq	0x22(%rbp), %rdi
    3117:      	movl	$0x2, %ecx
    311c:      	movl	$0x4, %eax
    3121:      	movl	$0x2, %esi
    3126:      	movq	%r13, %rdx
    3129:      	callq	*%rax
    312b:      	movzwl	0x22(%rbp), %eax
    312f:      	movbew	%ax, 0x22(%rbp)
    3135:      	movq	0x28(%rbp), %rax
    3139:      	movq	%rax, 0x68(%rsp)
    313e:      	movq	(%rip), %rdi            # 0x3145 <generic_lsm_process_event+0x2f75>
    3145:      	leaq	0x68(%rsp), %rsi
    314a:      	movl	$0x1, %eax
    314f:      	callq	*%rax
    3151:      	testq	%rax, %rax
    3154:      	je	0x316e <generic_lsm_process_event+0x2f9e>
    3156:      	movl	(%rax), %ecx
    3158:      	movq	0x40(%rsp), %rdx
    315d:      	movl	%ecx, 0x10(%rdx)
    3160:      	movq	0x8(%rax), %rcx
    3164:      	movq	%rcx, 0x18(%rdx)
    3168:      	movl	0x4(%rax), %eax
    316b:      	movl	%eax, 0x7c(%rdx)
    316e:      	movl	$0x40, %r13d
    3174:      	jmp	0x3eba <generic_lsm_process_event+0x3cea>
    3179:      	movq	%rbp, %rax
    317c:      	addq	$0x5e60, %rax           # imm = 0x5E60
    3182:      	jmp	0x3198 <generic_lsm_process_event+0x2fc8>
    3184:      	movq	%rbp, %rax
    3187:      	addq	$0x5e68, %rax           # imm = 0x5E68
    318d:      	jmp	0x3198 <generic_lsm_process_event+0x2fc8>
    318f:      	movq	%rbp, %rax
    3192:      	addq	$0x5e50, %rax           # imm = 0x5E50
    3198:      	movq	(%rax), %rbx
    319b:      	testb	$0x10, 0x40(%rsp)
    31a0:      	jne	0x3544 <generic_lsm_process_event+0x3374>
    31a6:      	testq	%rbx, %rbx
    31a9:      	je	0x360c <generic_lsm_process_event+0x343c>
    31af:      	leaq	0x68(%rsp), %rdi
    31b4:      	movl	$0x10, %ecx
    31b9:      	movl	$0x4, %eax
    31be:      	movq	0x10(%rsp), %rdx
    31c3:      	movl	$0x10, %esi
    31c8:      	callq	*%rax
    31ca:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    31cf:      	testl	%eax, %eax
    31d1:      	js	0x3512 <generic_lsm_process_event+0x3342>
    31d7:      	movq	0x70(%rsp), %r14
    31dc:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    31e1:      	cmpq	$0xffe, %r14            # imm = 0xFFE
    31e8:      	ja	0x3512 <generic_lsm_process_event+0x3342>
    31ee:      	movq	0xc8(%rsp), %rax
    31f6:      	leaq	0xc(%rax), %r15
    31fa:      	leaq	(%r15,%r13), %rdi
    31fe:      	movq	0x68(%rsp), %rcx
    3203:      	movl	$0x4, %eax
    3208:      	movq	0x68(%rsp), %rdx
    320d:      	movl	%r14d, %esi
    3210:      	callq	*%rax
    3212:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3217:      	testl	%eax, %eax
    3219:      	js	0x3512 <generic_lsm_process_event+0x3342>
    321f:      	cmpq	$0x1, %rbx
    3223:      	je	0x360f <generic_lsm_process_event+0x343f>
    3229:      	movq	0x10(%rsp), %rax
    322e:      	leaq	0x10(%rax), %rdx
    3232:      	leaq	0x68(%rsp), %rdi
    3237:      	movl	$0x10, %ecx
    323c:      	movl	$0x4, %eax
    3241:      	movl	$0x10, %esi
    3246:      	callq	*%rax
    3248:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    324d:      	testl	%eax, %eax
    324f:      	js	0x3512 <generic_lsm_process_event+0x3342>
    3255:      	movq	0x70(%rsp), %r12
    325a:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    325f:      	cmpq	$0xffe, %r12            # imm = 0xFFE
    3266:      	ja	0x3512 <generic_lsm_process_event+0x3342>
    326c:      	addq	%r14, %r15
    326f:      	leaq	(%r15,%r13), %rdi
    3273:      	movq	0x68(%rsp), %rcx
    3278:      	movl	$0x4, %eax
    327d:      	movq	0x68(%rsp), %rdx
    3282:      	movl	%r12d, %esi
    3285:      	callq	*%rax
    3287:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    328c:      	testl	%eax, %eax
    328e:      	js	0x3512 <generic_lsm_process_event+0x3342>
    3294:      	addq	%r12, %r14
    3297:      	cmpq	$0x3, %rbx
    329b:      	jb	0x360f <generic_lsm_process_event+0x343f>
    32a1:      	movq	0x10(%rsp), %rax
    32a6:      	leaq	0x20(%rax), %rdx
    32aa:      	leaq	0x68(%rsp), %rdi
    32af:      	movl	$0x10, %ecx
    32b4:      	movl	$0x4, %eax
    32b9:      	movl	$0x10, %esi
    32be:      	callq	*%rax
    32c0:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    32c5:      	testl	%eax, %eax
    32c7:      	js	0x3512 <generic_lsm_process_event+0x3342>
    32cd:      	movq	0x70(%rsp), %rbp
    32d2:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    32d7:      	cmpq	$0xffe, %rbp            # imm = 0xFFE
    32de:      	ja	0x3512 <generic_lsm_process_event+0x3342>
    32e4:      	addq	%r15, %r12
    32e7:      	movl	%r12d, %edi
    32ea:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    32f0:      	addq	%r13, %rdi
    32f3:      	movq	0x68(%rsp), %rcx
    32f8:      	movl	$0x4, %eax
    32fd:      	movq	0x68(%rsp), %rdx
    3302:      	movl	%ebp, %esi
    3304:      	callq	*%rax
    3306:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    330b:      	testl	%eax, %eax
    330d:      	js	0x3512 <generic_lsm_process_event+0x3342>
    3313:      	addq	%rbp, %r14
    3316:      	cmpq	$0x3, %rbx
    331a:      	je	0x360f <generic_lsm_process_event+0x343f>
    3320:      	movq	0x10(%rsp), %rax
    3325:      	leaq	0x30(%rax), %rdx
    3329:      	leaq	0x68(%rsp), %rdi
    332e:      	movl	$0x10, %ecx
    3333:      	movl	$0x4, %eax
    3338:      	movl	$0x10, %esi
    333d:      	callq	*%rax
    333f:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3344:      	testl	%eax, %eax
    3346:      	js	0x3512 <generic_lsm_process_event+0x3342>
    334c:      	movq	0x70(%rsp), %rax
    3351:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    3356:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    335c:      	ja	0x3512 <generic_lsm_process_event+0x3342>
    3362:      	movq	%rax, %r15
    3365:      	addq	%r12, %rbp
    3368:      	movl	%ebp, %edi
    336a:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    3370:      	addq	%r13, %rdi
    3373:      	movq	0x68(%rsp), %rcx
    3378:      	movl	$0x4, %eax
    337d:      	movq	%r15, %rsi
    3380:      	movq	0x68(%rsp), %rdx
    3385:      	callq	*%rax
    3387:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    338c:      	testl	%eax, %eax
    338e:      	js	0x3512 <generic_lsm_process_event+0x3342>
    3394:      	addq	%r15, %r14
    3397:      	cmpq	$0x5, %rbx
    339b:      	jb	0x360f <generic_lsm_process_event+0x343f>
    33a1:      	movq	0x10(%rsp), %rax
    33a6:      	leaq	0x40(%rax), %rdx
    33aa:      	leaq	0x68(%rsp), %rdi
    33af:      	movl	$0x10, %ecx
    33b4:      	movl	$0x4, %eax
    33b9:      	movl	$0x10, %esi
    33be:      	callq	*%rax
    33c0:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    33c5:      	testl	%eax, %eax
    33c7:      	js	0x3512 <generic_lsm_process_event+0x3342>
    33cd:      	movq	0x70(%rsp), %rax
    33d2:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    33d7:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    33dd:      	ja	0x3512 <generic_lsm_process_event+0x3342>
    33e3:      	movq	%rax, %r12
    33e6:      	movq	%r15, %rdi
    33e9:      	addq	%rbp, %rdi
    33ec:      	movq	%rdi, %r15
    33ef:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    33f5:      	addq	%r13, %rdi
    33f8:      	movq	0x68(%rsp), %rcx
    33fd:      	movl	$0x4, %eax
    3402:      	movq	%r12, %rsi
    3405:      	movq	0x68(%rsp), %rdx
    340a:      	callq	*%rax
    340c:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3411:      	testl	%eax, %eax
    3413:      	js	0x3512 <generic_lsm_process_event+0x3342>
    3419:      	addq	%r12, %r14
    341c:      	cmpq	$0x5, %rbx
    3420:      	je	0x360f <generic_lsm_process_event+0x343f>
    3426:      	movq	0x10(%rsp), %rax
    342b:      	leaq	0x50(%rax), %rdx
    342f:      	leaq	0x68(%rsp), %rdi
    3434:      	movl	$0x10, %ecx
    3439:      	movl	$0x4, %eax
    343e:      	movl	$0x10, %esi
    3443:      	callq	*%rax
    3445:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    344a:      	testl	%eax, %eax
    344c:      	js	0x3512 <generic_lsm_process_event+0x3342>
    3452:      	movq	0x70(%rsp), %rbp
    3457:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    345c:      	cmpq	$0xffe, %rbp            # imm = 0xFFE
    3463:      	ja	0x3512 <generic_lsm_process_event+0x3342>
    3469:      	addq	%r15, %r12
    346c:      	movq	%r12, %r15
    346f:      	movl	%r12d, %edi
    3472:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    3478:      	addq	%r13, %rdi
    347b:      	movq	0x68(%rsp), %rcx
    3480:      	movl	$0x4, %eax
    3485:      	movq	0x68(%rsp), %rdx
    348a:      	movl	%ebp, %esi
    348c:      	callq	*%rax
    348e:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3493:      	testl	%eax, %eax
    3495:      	js	0x3512 <generic_lsm_process_event+0x3342>
    3497:      	addq	%rbp, %r14
    349a:      	cmpq	$0x7, %rbx
    349e:      	jb	0x360f <generic_lsm_process_event+0x343f>
    34a4:      	movq	0x10(%rsp), %rdx
    34a9:      	addq	$0x60, %rdx
    34ad:      	leaq	0x68(%rsp), %rdi
    34b2:      	movl	$0x10, %ecx
    34b7:      	movl	$0x4, %eax
    34bc:      	movl	$0x10, %esi
    34c1:      	callq	*%rax
    34c3:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    34c8:      	testl	%eax, %eax
    34ca:      	js	0x3512 <generic_lsm_process_event+0x3342>
    34cc:      	movq	0x70(%rsp), %rbx
    34d1:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    34d6:      	cmpq	$0xffe, %rbx            # imm = 0xFFE
    34dd:      	ja	0x3512 <generic_lsm_process_event+0x3342>
    34df:      	addq	%r15, %rbp
    34e2:      	andl	$0x3fff, %ebp           # imm = 0x3FFF
    34e8:      	addq	%r13, %rbp
    34eb:      	movq	0x68(%rsp), %rcx
    34f0:      	movl	$0x4, %eax
    34f5:      	movq	0x68(%rsp), %rdx
    34fa:      	movq	%rbp, %rdi
    34fd:      	movl	%ebx, %esi
    34ff:      	callq	*%rax
    3501:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3506:      	testl	%eax, %eax
    3508:      	js	0x3512 <generic_lsm_process_event+0x3342>
    350a:      	addq	%rbx, %r14
    350d:      	jmp	0x360f <generic_lsm_process_event+0x343f>
    3512:      	movq	0x48(%rsp), %rax
    3517:      	movl	%ecx, (%r13,%rax)
    351c:      	movq	0x18(%rsp), %rbx
    3521:      	movq	0x28(%rsp), %r14
    3526:      	movl	$0x4, %r13d
    352c:      	jmp	0x1761 <generic_lsm_process_event+0x1591>
    3531:      	xorl	%ebx, %ebx
    3533:      	movl	$0x0, %r14d
    3539:      	testb	$0x10, 0x40(%rsp)
    353e:      	je	0x360f <generic_lsm_process_event+0x343f>
    3544:      	movl	$0xe, %eax
    3549:      	callq	*%rax
    354b:      	cmpq	$-0x16, %rax
    354f:      	jne	0x3575 <generic_lsm_process_event+0x33a5>
    3551:      	movq	0x18(%rsp), %rax
    3556:      	leaq	0x20(%rax), %rdx
    355a:      	leaq	0x68(%rsp), %rdi
    355f:      	movl	$0x8, %ecx
    3564:      	movl	$0x4, %eax
    3569:      	movl	$0x8, %esi
    356e:      	callq	*%rax
    3570:      	movq	0x68(%rsp), %rax
    3575:      	movq	0x8(%rbp), %rcx
    3579:      	movq	0x60(%rbp), %rdx
    357d:      	movq	%rcx, 0x68(%rsp)
    3582:      	movq	0x10(%rsp), %rcx
    3587:      	movq	%rcx, 0x70(%rsp)
    358c:      	movq	%rbx, 0x78(%rsp)
    3591:      	movq	%rdx, 0x58(%rsp)
    3596:      	movq	%rax, 0x60(%rsp)
    359b:      	movq	(%rip), %rdi            # 0x35a2 <generic_lsm_process_event+0x33d2>
    35a2:      	xorl	%ecx, %ecx
    35a4:      	leaq	0x58(%rsp), %rsi
    35a9:      	leaq	0x68(%rsp), %rdx
    35ae:      	movl	$0x2, %eax
    35b3:      	xorl	%ecx, %ecx
    35b5:      	callq	*%rax
    35b7:      	testq	%rax, %rax
    35ba:      	je	0x36c3 <generic_lsm_process_event+0x34f3>
    35c0:      	negl	%eax
    35c2:      	movw	%ax, 0xb0(%rsp)
    35ca:      	movw	$0x5, 0xb2(%rsp)
    35d4:      	movabsq	$0x200000057, %rax      # imm = 0x200000057
    35de:      	movq	%rax, 0xb4(%rsp)
    35e6:      	movq	(%rip), %rdi            # 0x35ed <generic_lsm_process_event+0x341d>
    35ed:      	leaq	0xb0(%rsp), %rsi
    35f5:      	movl	$0x1, %eax
    35fa:      	callq	*%rax
    35fc:      	testq	%rax, %rax
    35ff:      	je	0x369c <generic_lsm_process_event+0x34cc>
    3605:      	incl	(%rax)
    3607:      	jmp	0x36c3 <generic_lsm_process_event+0x34f3>
    360c:      	xorl	%r14d, %r14d
    360f:      	movq	0x48(%rsp), %rax
    3614:      	movl	%r14d, (%r13,%rax)
    3619:      	movl	%r14d, 0x4(%r13,%rax)
    361e:      	addq	$0x8, %r14
    3622:      	movq	%r14, %r13
    3625:      	jmp	0x3eba <generic_lsm_process_event+0x3cea>
    362a:      	cmpl	$0x33, %eax
    362d:      	je	0x39ce <generic_lsm_process_event+0x37fe>
    3633:      	cmpl	$0x3c, %eax
    3636:      	je	0x36dc <generic_lsm_process_event+0x350c>
    363c:      	cmpl	$0xff, %eax
    3641:      	jne	0x3a9b <generic_lsm_process_event+0x38cb>
    3647:      	movw	$0x28, 0x2(%rbx)
    364d:      	movw	$0x28, %ax
    3651:      	jmp	0x39dd <generic_lsm_process_event+0x380d>
    3656:      	movl	$0x1, 0xc0(%rsp)
    3661:      	movq	(%rip), %rdi            # 0x3668 <generic_lsm_process_event+0x3498>
    3668:      	xorl	%ecx, %ecx
    366a:      	leaq	0xb0(%rsp), %rsi
    3672:      	leaq	0xc0(%rsp), %rdx
    367a:      	movl	$0x2, %eax
    367f:      	xorl	%ecx, %ecx
    3681:      	callq	*%rax
    3683:      	movq	0xa8(%rsp), %rax
    368b:      	movl	$0xfffffffc, (%rax)     # imm = 0xFFFFFFFC
    3691:      	movl	$0x4, %r13d
    3697:      	jmp	0x3eba <generic_lsm_process_event+0x3cea>
    369c:      	movl	$0x1, 0x30(%rsp)
    36a4:      	movq	(%rip), %rdi            # 0x36ab <generic_lsm_process_event+0x34db>
    36ab:      	xorl	%ecx, %ecx
    36ad:      	leaq	0xb0(%rsp), %rsi
    36b5:      	leaq	0x30(%rsp), %rdx
    36ba:      	movl	$0x2, %eax
    36bf:      	xorl	%ecx, %ecx
    36c1:      	callq	*%rax
    36c3:      	movq	0x48(%rsp), %rax
    36c8:      	movl	$0xfffffffc, (%r13,%rax) # imm = 0xFFFFFFFC
    36d1:      	movl	$0x4, %r13d
    36d7:      	jmp	0x3eba <generic_lsm_process_event+0x3cea>
    36dc:      	movzbl	0x7(%rbx), %eax
    36e0:      	leal	0x8(,%rax,8), %eax
    36e7:      	jmp	0x39d9 <generic_lsm_process_event+0x3809>
    36ec:      	movl	$0x4, %r13d
    36f2:      	jmp	0x1761 <generic_lsm_process_event+0x1591>
    36f7:      	leaq	0x5e60(%rbp), %rax
    36fe:      	jmp	0x3710 <generic_lsm_process_event+0x3540>
    3700:      	leaq	0x5e68(%rbp), %rax
    3707:      	jmp	0x3710 <generic_lsm_process_event+0x3540>
    3709:      	leaq	0x5e50(%rbp), %rax
    3710:      	movq	(%rax), %rax
    3713:      	movq	%rax, 0x30(%rsp)
    3718:      	leaq	0x50(%rsp), %rdi
    371d:      	leaq	0x30(%rsp), %rdx
    3722:      	movl	$0x8, %ecx
    3727:      	movl	$0x4, %eax
    372c:      	movl	$0x8, %ebx
    3731:      	movl	$0x8, %esi
    3736:      	callq	*%rax
    3738:      	movq	0x50(%rsp), %r14
    373d:      	testb	$0x20, %r15b
    3741:      	je	0x38fe <generic_lsm_process_event+0x372e>
    3747:      	cmpq	$0x1000, %r14           # imm = 0x1000
    374e:      	jb	0x38d3 <generic_lsm_process_event+0x3703>
    3754:      	movq	0xa8(%rsp), %rax
    375c:      	movl	$0x1, (%rax)
    3762:      	movl	$0x0, 0x58(%rsp)
    376a:      	movq	(%rip), %rdi            # 0x3771 <generic_lsm_process_event+0x35a1>
    3771:      	leaq	0x58(%rsp), %rsi
    3776:      	movl	$0x1, %eax
    377b:      	callq	*%rax
    377d:      	testq	%rax, %rax
    3780:      	je	0x3956 <generic_lsm_process_event+0x3786>
    3786:      	movq	%rax, %rbx
    3789:      	movl	$0x18, (%rax)
    378f:      	movl	$0xe, %eax
    3794:      	callq	*%rax
    3796:      	leaq	0x10(%rbx), %r15
    379a:      	movq	%rax, 0x10(%rbx)
    379e:      	cmpq	$-0x16, %rax
    37a2:      	jne	0x37cb <generic_lsm_process_event+0x35fb>
    37a4:      	movq	0x18(%rsp), %rax
    37a9:      	leaq	0x20(%rax), %rdx
    37ad:      	leaq	0x68(%rsp), %rdi
    37b2:      	movl	$0x8, %ecx
    37b7:      	movl	$0x4, %eax
    37bc:      	movl	$0x8, %esi
    37c1:      	callq	*%rax
    37c3:      	movq	0x68(%rsp), %rax
    37c8:      	movq	%rax, (%r15)
    37cb:      	movl	$0x7d, %eax
    37d0:      	callq	*%rax
    37d2:      	movq	%rax, 0x18(%rbx)
    37d6:      	movq	(%r15), %rax
    37d9:      	movq	0x8(%r15), %rcx
    37dd:      	movq	0xa8(%rsp), %rdx
    37e5:      	movq	%rax, 0x14(%rdx)
    37e9:      	movq	%rcx, 0x1c(%rdx)
    37ed:      	movq	%rbx, %rax
    37f0:      	addq	$0x20, %rax
    37f4:      	movq	%rax, 0x40(%rsp)
    37f9:      	movl	$0xa, %r15d
    37ff:      	xorl	%r13d, %r13d
    3802:      	movq	%r14, %rbp
    3805:      	subq	%r13, %rbp
    3808:      	js	0x3acd <generic_lsm_process_event+0x38fd>
    380e:      	movq	0x10(%rsp), %rax
    3813:      	leaq	(%rax,%r13), %rdx
    3817:      	cmpq	$0x7fe0, %rbp           # imm = 0x7FE0
    381e:      	movl	$0x7fe0, %eax           # imm = 0x7FE0
    3823:      	cmovaeq	%rax, %rbp
    3827:      	movl	$0x4, %eax
    382c:      	movq	0x40(%rsp), %rdi
    3831:      	movl	%ebp, %esi
    3833:      	callq	*%rax
    3835:      	testl	%eax, %eax
    3837:      	js	0x38a8 <generic_lsm_process_event+0x36d8>
    3839:      	leal	0x20(%rbp), %r12d
    383d:      	movl	%r12d, 0x4(%rbx)
    3841:      	movl	$0x0, 0x68(%rsp)
    3849:      	movl	$0x1, %eax
    384e:      	movq	(%rip), %rdi            # 0x3855 <generic_lsm_process_event+0x3685>
    3855:      	leaq	0x68(%rsp), %rsi
    385a:      	callq	*%rax
    385c:      	testq	%rax, %rax
    385f:      	je	0x388c <generic_lsm_process_event+0x36bc>
    3861:      	cmpb	$0x0, 0x28(%rax)
    3865:      	je	0x388c <generic_lsm_process_event+0x36bc>
    3867:      	movl	$0x19, %eax
    386c:      	movq	0x18(%rsp), %rdi
    3871:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    3876:      	movq	(%rip), %rsi            # 0x387d <generic_lsm_process_event+0x36ad>
    387d:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    3882:      	movq	%rbx, %rcx
    3885:      	movq	%r12, %r8
    3888:      	callq	*%rax
    388a:      	jmp	0x38a4 <generic_lsm_process_event+0x36d4>
    388c:      	movl	$0x82, %eax
    3891:      	xorl	%ecx, %ecx
    3893:      	movq	(%rip), %rdi            # 0x389a <generic_lsm_process_event+0x36ca>
    389a:      	movq	%rbx, %rsi
    389d:      	movq	%r12, %rdx
    38a0:      	xorl	%ecx, %ecx
    38a2:      	callq	*%rax
    38a4:      	testl	%eax, %eax
    38a6:      	jns	0x38ab <generic_lsm_process_event+0x36db>
    38a8:      	movslq	%eax, %rbp
    38ab:      	testl	%ebp, %ebp
    38ad:      	js	0x3ad6 <generic_lsm_process_event+0x3906>
    38b3:      	andl	$0x7fffffff, %ebp       # imm = 0x7FFFFFFF
    38b9:      	addq	%rbp, %r13
    38bc:      	cmpq	%r14, %r13
    38bf:      	je	0x3b30 <generic_lsm_process_event+0x3960>
    38c5:      	decl	%r15d
    38c8:      	jne	0x3802 <generic_lsm_process_event+0x3632>
    38ce:      	jmp	0x3e67 <generic_lsm_process_event+0x3c97>
    38d3:      	addq	$0x90, %rbp
    38da:      	movq	0xc8(%rsp), %rax
    38e2:      	movl	$0x0, 0x4(%rbp,%rax)
    38ea:      	addq	%rbp, %rax
    38ed:      	addq	$0x8, %rax
    38f1:      	movq	%rax, 0xa8(%rsp)
    38f9:      	movl	$0xc, %ebx
    38fe:      	cmpq	$0xfff, %r14            # imm = 0xFFF
    3905:      	movl	$0xfff, %r13d           # imm = 0xFFF
    390b:      	cmovbq	%r14, %r13
    390f:      	movq	0xa8(%rsp), %rax
    3917:      	leaq	0x8(%rax), %rdi
    391b:      	movl	$0x4, %eax
    3920:      	movq	0x10(%rsp), %rdx
    3925:      	movl	%r13d, %esi
    3928:      	callq	*%rax
    392a:      	testl	%eax, %eax
    392c:      	js	0x3948 <generic_lsm_process_event+0x3778>
    392e:      	movq	0xa8(%rsp), %rax
    3936:      	movl	%r14d, (%rax)
    3939:      	movl	%r13d, 0x4(%rax)
    393d:      	addq	%r13, %rbx
    3940:      	movq	%rbx, %r13
    3943:      	jmp	0x3eba <generic_lsm_process_event+0x3cea>
    3948:      	movq	0xa8(%rsp), %rax
    3950:      	movl	$0xfffffffe, (%rax)     # imm = 0xFFFFFFFE
    3956:      	movl	$0x4, %r13d
    395c:      	jmp	0x3eba <generic_lsm_process_event+0x3cea>
    3961:      	movq	$-0x1, %rbp
    3968:      	jmp	0x396d <generic_lsm_process_event+0x379d>
    396a:      	movq	%r13, %rbp
    396d:      	movl	$0x0, 0x68(%rsp)
    3975:      	movq	(%rip), %rdi            # 0x397c <generic_lsm_process_event+0x37ac>
    397c:      	leaq	0x68(%rsp), %rsi
    3981:      	movl	$0x1, %eax
    3986:      	callq	*%rax
    3988:      	testq	%rax, %rax
    398b:      	je	0x3d1c <generic_lsm_process_event+0x3b4c>
    3991:      	cmpq	$-0xc, %rbp
    3995:      	jg	0x3aa4 <generic_lsm_process_event+0x38d4>
    399b:      	cmpq	$-0x1c, %rbp
    399f:      	je	0x3cf2 <generic_lsm_process_event+0x3b22>
    39a5:      	cmpq	$-0x16, %rbp
    39a9:      	je	0x3d0a <generic_lsm_process_event+0x3b3a>
    39af:      	cmpq	$-0x10, %rbp
    39b3:      	jne	0x3d02 <generic_lsm_process_event+0x3b32>
    39b9:      	addq	$0x558, %rax            # imm = 0x558
    39bf:      	jmp	0x3d18 <generic_lsm_process_event+0x3b48>
    39c4:      	movq	0x10(%rsp), %rbp
    39c9:      	jmp	0x3d1c <generic_lsm_process_event+0x3b4c>
    39ce:      	movzbl	0x7(%rbx), %eax
    39d2:      	leal	0x8(,%rax,4), %eax
    39d9:      	movw	%ax, 0x2(%rbx)
    39dd:      	addw	(%rbx), %ax
    39e0:      	movw	%ax, (%rbx)
    39e3:      	movzbl	0x6(%rbx), %r15d
    39e8:      	cmpq	$0x3c, %r15
    39ec:      	ja	0x426d <generic_lsm_process_event+0x409d>
    39f2:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    39fc:      	btq	%r15, %rcx
    3a00:      	jae	0x426d <generic_lsm_process_event+0x409d>
    3a06:      	movb	%r15b, 0x5(%rbx)
    3a0a:      	movzwl	%ax, %ecx
    3a0d:      	addq	%r14, %rcx
    3a10:      	movl	$0x2, %edx
    3a15:      	movl	$0x4, %eax
    3a1a:      	movq	0x10(%rsp), %rdi
    3a1f:      	movzwl	(%rbx), %edx
    3a22:      	addq	%r14, %rdx
    3a25:      	movl	$0x2, %esi
    3a2a:      	callq	*%rax
    3a2c:      	testq	%rax, %rax
    3a2f:      	js	0x40a9 <generic_lsm_process_event+0x3ed9>
    3a35:      	movzbl	0x5(%rbx), %eax
    3a39:      	cmpl	$0x32, %eax
    3a3c:      	jg	0x3a5f <generic_lsm_process_event+0x388f>
    3a3e:      	testl	%eax, %eax
    3a40:      	je	0x3a87 <generic_lsm_process_event+0x38b7>
    3a42:      	cmpl	$0x2b, %eax
    3a45:      	je	0x3a87 <generic_lsm_process_event+0x38b7>
    3a47:      	cmpl	$0x2c, %eax
    3a4a:      	jne	0x3b49 <generic_lsm_process_event+0x3979>
    3a50:      	movw	$0x8, 0x2(%rbx)
    3a56:      	movw	$0x8, %ax
    3a5a:      	jmp	0x3b4d <generic_lsm_process_event+0x397d>
    3a5f:      	cmpl	$0x33, %eax
    3a62:      	je	0x3b38 <generic_lsm_process_event+0x3968>
    3a68:      	cmpl	$0x3c, %eax
    3a6b:      	je	0x3a87 <generic_lsm_process_event+0x38b7>
    3a6d:      	cmpl	$0xff, %eax
    3a72:      	jne	0x3b49 <generic_lsm_process_event+0x3979>
    3a78:      	movw	$0x28, 0x2(%rbx)
    3a7e:      	movw	$0x28, %ax
    3a82:      	jmp	0x3b4d <generic_lsm_process_event+0x397d>
    3a87:      	movzbl	0x7(%rbx), %eax
    3a8b:      	leal	0x8(,%rax,8), %eax
    3a92:      	movw	%ax, 0x2(%rbx)
    3a96:      	jmp	0x3b4d <generic_lsm_process_event+0x397d>
    3a9b:      	movzwl	0x2(%rbx), %eax
    3a9f:      	jmp	0x39dd <generic_lsm_process_event+0x380d>
    3aa4:      	cmpq	$-0xb, %rbp
    3aa8:      	je	0x3cfa <generic_lsm_process_event+0x3b2a>
    3aae:      	cmpq	$-0x7, %rbp
    3ab2:      	je	0x3d12 <generic_lsm_process_event+0x3b42>
    3ab8:      	cmpq	$-0x2, %rbp
    3abc:      	jne	0x3d02 <generic_lsm_process_event+0x3b32>
    3ac2:      	addq	$0x548, %rax            # imm = 0x548
    3ac8:      	jmp	0x3d18 <generic_lsm_process_event+0x3b48>
    3acd:      	movq	$-0x1, %r13
    3ad4:      	jmp	0x3ad9 <generic_lsm_process_event+0x3909>
    3ad6:      	movq	%rbp, %r13
    3ad9:      	movl	$0x0, 0x68(%rsp)
    3ae1:      	movq	(%rip), %rdi            # 0x3ae8 <generic_lsm_process_event+0x3918>
    3ae8:      	leaq	0x68(%rsp), %rsi
    3aed:      	movl	$0x1, %eax
    3af2:      	callq	*%rax
    3af4:      	testq	%rax, %rax
    3af7:      	je	0x3e67 <generic_lsm_process_event+0x3c97>
    3afd:      	cmpq	$-0xc, %r13
    3b01:      	jg	0x3bf6 <generic_lsm_process_event+0x3a26>
    3b07:      	cmpq	$-0x1c, %r13
    3b0b:      	je	0x3e3d <generic_lsm_process_event+0x3c6d>
    3b11:      	cmpq	$-0x16, %r13
    3b15:      	je	0x3e45 <generic_lsm_process_event+0x3c75>
    3b1b:      	cmpq	$-0x10, %r13
    3b1f:      	jne	0x3e5d <generic_lsm_process_event+0x3c8d>
    3b25:      	addq	$0x558, %rax            # imm = 0x558
    3b2b:      	jmp	0x3e63 <generic_lsm_process_event+0x3c93>
    3b30:      	movq	%r14, %r13
    3b33:      	jmp	0x3e67 <generic_lsm_process_event+0x3c97>
    3b38:      	movzbl	0x7(%rbx), %eax
    3b3c:      	leal	0x8(,%rax,4), %eax
    3b43:      	movw	%ax, 0x2(%rbx)
    3b47:      	jmp	0x3b4d <generic_lsm_process_event+0x397d>
    3b49:      	movzwl	0x2(%rbx), %eax
    3b4d:      	addw	(%rbx), %ax
    3b50:      	movw	%ax, (%rbx)
    3b53:      	movzbl	0x6(%rbx), %r15d
    3b58:      	cmpq	$0x3c, %r15
    3b5c:      	ja	0x426d <generic_lsm_process_event+0x409d>
    3b62:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3b6c:      	btq	%r15, %rcx
    3b70:      	jae	0x426d <generic_lsm_process_event+0x409d>
    3b76:      	movb	%r15b, 0x5(%rbx)
    3b7a:      	movzwl	%ax, %ecx
    3b7d:      	addq	%r14, %rcx
    3b80:      	movl	$0x2, %edx
    3b85:      	movl	$0x4, %eax
    3b8a:      	movq	0x10(%rsp), %rdi
    3b8f:      	movzwl	(%rbx), %edx
    3b92:      	addq	%r14, %rdx
    3b95:      	movl	$0x2, %esi
    3b9a:      	callq	*%rax
    3b9c:      	testq	%rax, %rax
    3b9f:      	js	0x40a9 <generic_lsm_process_event+0x3ed9>
    3ba5:      	movzbl	0x5(%rbx), %eax
    3ba9:      	cmpl	$0x32, %eax
    3bac:      	jg	0x3bc8 <generic_lsm_process_event+0x39f8>
    3bae:      	testl	%eax, %eax
    3bb0:      	je	0x3be5 <generic_lsm_process_event+0x3a15>
    3bb2:      	cmpl	$0x2b, %eax
    3bb5:      	je	0x3be5 <generic_lsm_process_event+0x3a15>
    3bb7:      	cmpl	$0x2c, %eax
    3bba:      	jne	0x3c30 <generic_lsm_process_event+0x3a60>
    3bbc:      	movw	$0x8, 0x2(%rbx)
    3bc2:      	movw	$0x8, %ax
    3bc6:      	jmp	0x3c34 <generic_lsm_process_event+0x3a64>
    3bc8:      	cmpl	$0x33, %eax
    3bcb:      	je	0x3c1f <generic_lsm_process_event+0x3a4f>
    3bcd:      	cmpl	$0x3c, %eax
    3bd0:      	je	0x3be5 <generic_lsm_process_event+0x3a15>
    3bd2:      	cmpl	$0xff, %eax
    3bd7:      	jne	0x3c30 <generic_lsm_process_event+0x3a60>
    3bd9:      	movw	$0x28, 0x2(%rbx)
    3bdf:      	movw	$0x28, %ax
    3be3:      	jmp	0x3c34 <generic_lsm_process_event+0x3a64>
    3be5:      	movzbl	0x7(%rbx), %eax
    3be9:      	leal	0x8(,%rax,8), %eax
    3bf0:      	movw	%ax, 0x2(%rbx)
    3bf4:      	jmp	0x3c34 <generic_lsm_process_event+0x3a64>
    3bf6:      	cmpq	$-0xb, %r13
    3bfa:      	je	0x3e4d <generic_lsm_process_event+0x3c7d>
    3c00:      	cmpq	$-0x7, %r13
    3c04:      	je	0x3e55 <generic_lsm_process_event+0x3c85>
    3c0a:      	cmpq	$-0x2, %r13
    3c0e:      	jne	0x3e5d <generic_lsm_process_event+0x3c8d>
    3c14:      	addq	$0x548, %rax            # imm = 0x548
    3c1a:      	jmp	0x3e63 <generic_lsm_process_event+0x3c93>
    3c1f:      	movzbl	0x7(%rbx), %eax
    3c23:      	leal	0x8(,%rax,4), %eax
    3c2a:      	movw	%ax, 0x2(%rbx)
    3c2e:      	jmp	0x3c34 <generic_lsm_process_event+0x3a64>
    3c30:      	movzwl	0x2(%rbx), %eax
    3c34:      	addw	(%rbx), %ax
    3c37:      	movw	%ax, (%rbx)
    3c3a:      	movzbl	0x6(%rbx), %r15d
    3c3f:      	cmpq	$0x3c, %r15
    3c43:      	ja	0x426d <generic_lsm_process_event+0x409d>
    3c49:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3c53:      	btq	%r15, %rcx
    3c57:      	jae	0x426d <generic_lsm_process_event+0x409d>
    3c5d:      	movb	%r15b, 0x5(%rbx)
    3c61:      	movzwl	%ax, %ecx
    3c64:      	addq	%r14, %rcx
    3c67:      	movl	$0x2, %edx
    3c6c:      	movl	$0x4, %eax
    3c71:      	movq	0x10(%rsp), %rdi
    3c76:      	movzwl	(%rbx), %edx
    3c79:      	addq	%r14, %rdx
    3c7c:      	movl	$0x2, %esi
    3c81:      	callq	*%rax
    3c83:      	testq	%rax, %rax
    3c86:      	js	0x40a9 <generic_lsm_process_event+0x3ed9>
    3c8c:      	movzbl	0x5(%rbx), %eax
    3c90:      	cmpl	$0x32, %eax
    3c93:      	jg	0x3cb6 <generic_lsm_process_event+0x3ae6>
    3c95:      	testl	%eax, %eax
    3c97:      	je	0x3cde <generic_lsm_process_event+0x3b0e>
    3c99:      	cmpl	$0x2b, %eax
    3c9c:      	je	0x3cde <generic_lsm_process_event+0x3b0e>
    3c9e:      	cmpl	$0x2c, %eax
    3ca1:      	jne	0x3d7b <generic_lsm_process_event+0x3bab>
    3ca7:      	movw	$0x8, 0x2(%rbx)
    3cad:      	movw	$0x8, %ax
    3cb1:      	jmp	0x3d7f <generic_lsm_process_event+0x3baf>
    3cb6:      	cmpl	$0x33, %eax
    3cb9:      	je	0x3d6a <generic_lsm_process_event+0x3b9a>
    3cbf:      	cmpl	$0x3c, %eax
    3cc2:      	je	0x3cde <generic_lsm_process_event+0x3b0e>
    3cc4:      	cmpl	$0xff, %eax
    3cc9:      	jne	0x3d7b <generic_lsm_process_event+0x3bab>
    3ccf:      	movw	$0x28, 0x2(%rbx)
    3cd5:      	movw	$0x28, %ax
    3cd9:      	jmp	0x3d7f <generic_lsm_process_event+0x3baf>
    3cde:      	movzbl	0x7(%rbx), %eax
    3ce2:      	leal	0x8(,%rax,8), %eax
    3ce9:      	movw	%ax, 0x2(%rbx)
    3ced:      	jmp	0x3d7f <generic_lsm_process_event+0x3baf>
    3cf2:      	addq	$0x568, %rax            # imm = 0x568
    3cf8:      	jmp	0x3d18 <generic_lsm_process_event+0x3b48>
    3cfa:      	addq	$0x570, %rax            # imm = 0x570
    3d00:      	jmp	0x3d18 <generic_lsm_process_event+0x3b48>
    3d02:      	addq	$0x540, %rax            # imm = 0x540
    3d08:      	jmp	0x3d18 <generic_lsm_process_event+0x3b48>
    3d0a:      	addq	$0x560, %rax            # imm = 0x560
    3d10:      	jmp	0x3d18 <generic_lsm_process_event+0x3b48>
    3d12:      	addq	$0x550, %rax            # imm = 0x550
    3d18:      	lock
    3d19:      	incq	(%rax)
    3d1c:      	testl	%ebp, %ebp
    3d1e:      	js	0x3d41 <generic_lsm_process_event+0x3b71>
    3d20:      	movq	0x40(%rsp), %rax
    3d25:      	movq	$0x0, 0x4(%rax)
    3d2d:      	movq	0x10(%rsp), %rdx
    3d32:      	movl	%edx, %ecx
    3d34:      	subl	%ebp, %ecx
    3d36:      	xorl	%eax, %eax
    3d38:      	cmpq	$-0x1, %rdx
    3d3c:      	cmovnel	%ecx, %eax
    3d3f:      	jmp	0x3d54 <generic_lsm_process_event+0x3b84>
    3d41:      	movq	0x40(%rsp), %rax
    3d46:      	movl	%ebp, 0x4(%rax)
    3d49:      	movl	$0x0, 0x8(%rax)
    3d50:      	xorl	%eax, %eax
    3d52:      	xorl	%ebp, %ebp
    3d54:      	movq	0x40(%rsp), %rcx
    3d59:      	movl	%eax, 0xc(%rcx)
    3d5c:      	movl	%ebp, 0x10(%rcx)
    3d5f:      	movl	$0x24, %r13d
    3d65:      	jmp	0x1761 <generic_lsm_process_event+0x1591>
    3d6a:      	movzbl	0x7(%rbx), %eax
    3d6e:      	leal	0x8(,%rax,4), %eax
    3d75:      	movw	%ax, 0x2(%rbx)
    3d79:      	jmp	0x3d7f <generic_lsm_process_event+0x3baf>
    3d7b:      	movzwl	0x2(%rbx), %eax
    3d7f:      	addw	(%rbx), %ax
    3d82:      	movw	%ax, (%rbx)
    3d85:      	movzbl	0x6(%rbx), %r15d
    3d8a:      	cmpq	$0x3c, %r15
    3d8e:      	ja	0x426d <generic_lsm_process_event+0x409d>
    3d94:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3d9e:      	btq	%r15, %rcx
    3da2:      	jae	0x426d <generic_lsm_process_event+0x409d>
    3da8:      	movb	%r15b, 0x5(%rbx)
    3dac:      	movzwl	%ax, %ecx
    3daf:      	addq	%r14, %rcx
    3db2:      	movl	$0x2, %edx
    3db7:      	movl	$0x4, %eax
    3dbc:      	movq	0x10(%rsp), %rdi
    3dc1:      	movzwl	(%rbx), %edx
    3dc4:      	addq	%r14, %rdx
    3dc7:      	movl	$0x2, %esi
    3dcc:      	callq	*%rax
    3dce:      	testq	%rax, %rax
    3dd1:      	js	0x40a9 <generic_lsm_process_event+0x3ed9>
    3dd7:      	movzbl	0x5(%rbx), %eax
    3ddb:      	cmpl	$0x32, %eax
    3dde:      	jg	0x3e01 <generic_lsm_process_event+0x3c31>
    3de0:      	testl	%eax, %eax
    3de2:      	je	0x3e29 <generic_lsm_process_event+0x3c59>
    3de4:      	cmpl	$0x2b, %eax
    3de7:      	je	0x3e29 <generic_lsm_process_event+0x3c59>
    3de9:      	cmpl	$0x2c, %eax
    3dec:      	jne	0x3eda <generic_lsm_process_event+0x3d0a>
    3df2:      	movw	$0x8, 0x2(%rbx)
    3df8:      	movw	$0x8, %ax
    3dfc:      	jmp	0x3ede <generic_lsm_process_event+0x3d0e>
    3e01:      	cmpl	$0x33, %eax
    3e04:      	je	0x3ec9 <generic_lsm_process_event+0x3cf9>
    3e0a:      	cmpl	$0x3c, %eax
    3e0d:      	je	0x3e29 <generic_lsm_process_event+0x3c59>
    3e0f:      	cmpl	$0xff, %eax
    3e14:      	jne	0x3eda <generic_lsm_process_event+0x3d0a>
    3e1a:      	movw	$0x28, 0x2(%rbx)
    3e20:      	movw	$0x28, %ax
    3e24:      	jmp	0x3ede <generic_lsm_process_event+0x3d0e>
    3e29:      	movzbl	0x7(%rbx), %eax
    3e2d:      	leal	0x8(,%rax,8), %eax
    3e34:      	movw	%ax, 0x2(%rbx)
    3e38:      	jmp	0x3ede <generic_lsm_process_event+0x3d0e>
    3e3d:      	addq	$0x568, %rax            # imm = 0x568
    3e43:      	jmp	0x3e63 <generic_lsm_process_event+0x3c93>
    3e45:      	addq	$0x560, %rax            # imm = 0x560
    3e4b:      	jmp	0x3e63 <generic_lsm_process_event+0x3c93>
    3e4d:      	addq	$0x570, %rax            # imm = 0x570
    3e53:      	jmp	0x3e63 <generic_lsm_process_event+0x3c93>
    3e55:      	addq	$0x550, %rax            # imm = 0x550
    3e5b:      	jmp	0x3e63 <generic_lsm_process_event+0x3c93>
    3e5d:      	addq	$0x540, %rax            # imm = 0x540
    3e63:      	lock
    3e64:      	incq	(%rax)
    3e67:      	testl	%r13d, %r13d
    3e6a:      	js	0x3e8d <generic_lsm_process_event+0x3cbd>
    3e6c:      	movq	0xa8(%rsp), %rax
    3e74:      	movq	$0x0, 0x4(%rax)
    3e7c:      	movl	%r14d, %ecx
    3e7f:      	subl	%r13d, %ecx
    3e82:      	xorl	%eax, %eax
    3e84:      	cmpq	$-0x1, %r14
    3e88:      	cmovnel	%ecx, %eax
    3e8b:      	jmp	0x3ea5 <generic_lsm_process_event+0x3cd5>
    3e8d:      	movq	0xa8(%rsp), %rax
    3e95:      	movl	%r13d, 0x4(%rax)
    3e99:      	movl	$0x0, 0x8(%rax)
    3ea0:      	xorl	%eax, %eax
    3ea2:      	xorl	%r13d, %r13d
    3ea5:      	movq	0xa8(%rsp), %rcx
    3ead:      	movl	%eax, 0xc(%rcx)
    3eb0:      	movl	%r13d, 0x10(%rcx)
    3eb4:      	movl	$0x24, %r13d
    3eba:      	movq	0x18(%rsp), %rbx
    3ebf:      	movq	0x28(%rsp), %r14
    3ec4:      	jmp	0x1761 <generic_lsm_process_event+0x1591>
    3ec9:      	movzbl	0x7(%rbx), %eax
    3ecd:      	leal	0x8(,%rax,4), %eax
    3ed4:      	movw	%ax, 0x2(%rbx)
    3ed8:      	jmp	0x3ede <generic_lsm_process_event+0x3d0e>
    3eda:      	movzwl	0x2(%rbx), %eax
    3ede:      	addw	(%rbx), %ax
    3ee1:      	movw	%ax, (%rbx)
    3ee4:      	movzbl	0x6(%rbx), %r15d
    3ee9:      	cmpq	$0x3c, %r15
    3eed:      	ja	0x426d <generic_lsm_process_event+0x409d>
    3ef3:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3efd:      	btq	%r15, %rcx
    3f01:      	jae	0x426d <generic_lsm_process_event+0x409d>
    3f07:      	movb	%r15b, 0x5(%rbx)
    3f0b:      	movzwl	%ax, %ecx
    3f0e:      	addq	%r14, %rcx
    3f11:      	movl	$0x2, %edx
    3f16:      	movl	$0x4, %eax
    3f1b:      	movq	0x10(%rsp), %rdi
    3f20:      	movzwl	(%rbx), %edx
    3f23:      	addq	%r14, %rdx
    3f26:      	movl	$0x2, %esi
    3f2b:      	callq	*%rax
    3f2d:      	testq	%rax, %rax
    3f30:      	js	0x40a9 <generic_lsm_process_event+0x3ed9>
    3f36:      	movzbl	0x5(%rbx), %eax
    3f3a:      	cmpl	$0x32, %eax
    3f3d:      	jg	0x3f59 <generic_lsm_process_event+0x3d89>
    3f3f:      	testl	%eax, %eax
    3f41:      	je	0x3f76 <generic_lsm_process_event+0x3da6>
    3f43:      	cmpl	$0x2b, %eax
    3f46:      	je	0x3f76 <generic_lsm_process_event+0x3da6>
    3f48:      	cmpl	$0x2c, %eax
    3f4b:      	jne	0x3f98 <generic_lsm_process_event+0x3dc8>
    3f4d:      	movw	$0x8, 0x2(%rbx)
    3f53:      	movw	$0x8, %ax
    3f57:      	jmp	0x3f9c <generic_lsm_process_event+0x3dcc>
    3f59:      	cmpl	$0x33, %eax
    3f5c:      	je	0x3f87 <generic_lsm_process_event+0x3db7>
    3f5e:      	cmpl	$0x3c, %eax
    3f61:      	je	0x3f76 <generic_lsm_process_event+0x3da6>
    3f63:      	cmpl	$0xff, %eax
    3f68:      	jne	0x3f98 <generic_lsm_process_event+0x3dc8>
    3f6a:      	movw	$0x28, 0x2(%rbx)
    3f70:      	movw	$0x28, %ax
    3f74:      	jmp	0x3f9c <generic_lsm_process_event+0x3dcc>
    3f76:      	movzbl	0x7(%rbx), %eax
    3f7a:      	leal	0x8(,%rax,8), %eax
    3f81:      	movw	%ax, 0x2(%rbx)
    3f85:      	jmp	0x3f9c <generic_lsm_process_event+0x3dcc>
    3f87:      	movzbl	0x7(%rbx), %eax
    3f8b:      	leal	0x8(,%rax,4), %eax
    3f92:      	movw	%ax, 0x2(%rbx)
    3f96:      	jmp	0x3f9c <generic_lsm_process_event+0x3dcc>
    3f98:      	movzwl	0x2(%rbx), %eax
    3f9c:      	addw	(%rbx), %ax
    3f9f:      	movw	%ax, (%rbx)
    3fa2:      	movzbl	0x6(%rbx), %r15d
    3fa7:      	cmpq	$0x3c, %r15
    3fab:      	ja	0x426d <generic_lsm_process_event+0x409d>
    3fb1:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3fbb:      	btq	%r15, %rcx
    3fbf:      	jae	0x426d <generic_lsm_process_event+0x409d>
    3fc5:      	movb	%r15b, 0x5(%rbx)
    3fc9:      	movzwl	%ax, %ecx
    3fcc:      	addq	%r14, %rcx
    3fcf:      	movl	$0x2, %edx
    3fd4:      	movl	$0x4, %eax
    3fd9:      	movq	0x10(%rsp), %rdi
    3fde:      	movzwl	(%rbx), %edx
    3fe1:      	addq	%r14, %rdx
    3fe4:      	movl	$0x2, %esi
    3fe9:      	callq	*%rax
    3feb:      	testq	%rax, %rax
    3fee:      	js	0x40a9 <generic_lsm_process_event+0x3ed9>
    3ff4:      	movzbl	0x5(%rbx), %eax
    3ff8:      	cmpl	$0x32, %eax
    3ffb:      	jg	0x4017 <generic_lsm_process_event+0x3e47>
    3ffd:      	testl	%eax, %eax
    3fff:      	je	0x4034 <generic_lsm_process_event+0x3e64>
    4001:      	cmpl	$0x2b, %eax
    4004:      	je	0x4034 <generic_lsm_process_event+0x3e64>
    4006:      	cmpl	$0x2c, %eax
    4009:      	jne	0x4056 <generic_lsm_process_event+0x3e86>
    400b:      	movw	$0x8, 0x2(%rbx)
    4011:      	movw	$0x8, %ax
    4015:      	jmp	0x405a <generic_lsm_process_event+0x3e8a>
    4017:      	cmpl	$0x33, %eax
    401a:      	je	0x4045 <generic_lsm_process_event+0x3e75>
    401c:      	cmpl	$0x3c, %eax
    401f:      	je	0x4034 <generic_lsm_process_event+0x3e64>
    4021:      	cmpl	$0xff, %eax
    4026:      	jne	0x4056 <generic_lsm_process_event+0x3e86>
    4028:      	movw	$0x28, 0x2(%rbx)
    402e:      	movw	$0x28, %ax
    4032:      	jmp	0x405a <generic_lsm_process_event+0x3e8a>
    4034:      	movzbl	0x7(%rbx), %eax
    4038:      	leal	0x8(,%rax,8), %eax
    403f:      	movw	%ax, 0x2(%rbx)
    4043:      	jmp	0x405a <generic_lsm_process_event+0x3e8a>
    4045:      	movzbl	0x7(%rbx), %eax
    4049:      	leal	0x8(,%rax,4), %eax
    4050:      	movw	%ax, 0x2(%rbx)
    4054:      	jmp	0x405a <generic_lsm_process_event+0x3e8a>
    4056:      	movzwl	0x2(%rbx), %eax
    405a:      	addw	(%rbx), %ax
    405d:      	movw	%ax, (%rbx)
    4060:      	movzbl	0x6(%rbx), %r15d
    4065:      	cmpq	$0x3c, %r15
    4069:      	ja	0x426d <generic_lsm_process_event+0x409d>
    406f:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    4079:      	btq	%r15, %rcx
    407d:      	jae	0x426d <generic_lsm_process_event+0x409d>
    4083:      	movb	%r15b, 0x5(%rbx)
    4087:      	movzwl	%ax, %ecx
    408a:      	addq	%r14, %rcx
    408d:      	movl	$0x2, %edx
    4092:      	movl	$0x4, %eax
    4097:      	movq	0x10(%rsp), %rdi
    409c:      	movzwl	(%rbx), %edx
    409f:      	addq	%r14, %rdx
    40a2:      	movl	$0x2, %esi
    40a7:      	callq	*%rax
    40a9:      	xorl	%r15d, %r15d
    40ac:      	movb	%r15b, 0xd0(%rsp)
    40b4:      	movzbl	%r15b, %eax
    40b8:      	movq	%rbp, %rbx
    40bb:      	movw	%ax, 0x24(%rbp)
    40bf:      	movw	$0xa, 0x26(%rbp)
    40c5:      	leaq	0x8(%r12), %rdx
    40ca:      	movl	$0x10, %ecx
    40cf:      	movl	$0x4, %eax
    40d4:      	movq	%rbp, %rdi
    40d7:      	movl	$0x10, %esi
    40dc:      	callq	*%rax
    40de:      	leaq	0x10(%rbp), %rdi
    40e2:      	addq	$0x18, %r12
    40e6:      	movl	$0x10, %ecx
    40eb:      	movl	$0x4, %eax
    40f0:      	movl	$0x10, %esi
    40f5:      	movq	%r12, %rdx
    40f8:      	callq	*%rax
    40fa:      	cmpb	$0x11, %r15b
    40fe:      	je	0x414f <generic_lsm_process_event+0x3f7f>
    4100:      	movzbl	%r15b, %eax
    4104:      	cmpl	$0x6, %eax
    4107:      	jne	0x4198 <generic_lsm_process_event+0x3fc8>
    410d:      	movq	0x68(%rsp), %r15
    4112:      	movzwl	0xc0(%rsp), %r12d
    411b:      	leaq	(%r15,%r12), %rdx
    411f:      	movq	%rbp, %rbx
    4122:      	leaq	0x20(%rbp), %rdi
    4126:      	movl	$0x2, %ecx
    412b:      	movl	$0x4, %eax
    4130:      	movl	$0x2, %esi
    4135:      	callq	*%rax
    4137:      	leaq	0x22(%rbp), %rdi
    413b:      	leaq	(%r15,%r12), %rdx
    413f:      	addq	$0x2, %rdx
    4143:      	movl	$0x2, %ecx
    4148:      	movl	$0x4, %eax
    414d:      	jmp	0x418f <generic_lsm_process_event+0x3fbf>
    414f:      	movq	0x68(%rsp), %r15
    4154:      	movzwl	0xc0(%rsp), %r12d
    415d:      	leaq	(%r15,%r12), %rdx
    4161:      	movq	%rbp, %rbx
    4164:      	leaq	0x20(%rbp), %rdi
    4168:      	movl	$0x2, %ecx
    416d:      	movl	$0x4, %eax
    4172:      	movl	$0x2, %esi
    4177:      	callq	*%rax
    4179:      	leaq	0x22(%rbp), %rdi
    417d:      	leaq	(%r15,%r12), %rdx
    4181:      	addq	$0x2, %rdx
    4185:      	movl	$0x2, %ecx
    418a:      	movl	$0x4, %eax
    418f:      	movl	$0x2, %esi
    4194:      	callq	*%rax
    4196:      	jmp	0x419f <generic_lsm_process_event+0x3fcf>
    4198:      	movl	$0x0, 0x20(%rbp)
    419f:      	movzwl	0x20(%rbp), %eax
    41a3:      	movzwl	0x22(%rbp), %ecx
    41a7:      	movbew	%ax, 0x20(%rbp)
    41ad:      	movbew	%cx, 0x22(%rbp)
    41b3:      	addq	$0xe0, %r13
    41ba:      	leaq	0x58(%rsp), %rdi
    41bf:      	movl	$0x8, %ecx
    41c4:      	movl	$0x4, %eax
    41c9:      	movl	$0x4, %r15d
    41cf:      	movl	$0x8, %esi
    41d4:      	movq	%r13, %rdx
    41d7:      	callq	*%rax
    41d9:      	movq	0x58(%rsp), %rcx
    41de:      	testq	%rcx, %rcx
    41e1:      	je	0x4249 <generic_lsm_process_event+0x4079>
    41e3:      	addq	$0x5, %rcx
    41e7:      	leaq	0xb0(%rsp), %rdi
    41ef:      	movl	$0x8, %edx
    41f4:      	movl	$0x4, %eax
    41f9:      	movq	0x58(%rsp), %rdx
    41fe:      	addq	$0x5, %rdx
    4202:      	movl	$0x8, %esi
    4207:      	callq	*%rax
    4209:      	movq	0x58(%rsp), %r12
    420e:      	movq	0xb0(%rsp), %r13
    4216:      	leaq	0x38(%rbp), %rdi
    421a:      	leaq	(%r12,%r13,8), %rdx
    421e:      	addq	$0x44, %rdx
    4222:      	movl	$0x4, %eax
    4227:      	movl	$0x4, %esi
    422c:      	callq	*%rax
    422e:      	addq	$0x3c, %rbp
    4232:      	leaq	(%r12,%r13,8), %rdx
    4236:      	addq	$0x45, %rdx
    423a:      	movl	$0x4, %eax
    423f:      	movq	%rbp, %rdi
    4242:      	movl	$0x4, %esi
    4247:      	callq	*%rax
    4249:      	movl	$0x40, %r13d
    424f:      	movq	0x38(%rsp), %rax
    4254:      	movq	0x20(%rsp), %rcx
    4259:      	movl	$0x4, %esi
    425e:      	movq	0x18(%rsp), %rbx
    4263:      	movq	0x28(%rsp), %r14
    4268:      	jmp	0x1770 <generic_lsm_process_event+0x15a0>
    426d:      	movw	%ax, 0xc0(%rsp)
    4275:      	jmp	0x40ac <generic_lsm_process_event+0x3edc>
    427a:      	nopw	(%rax,%rax)

0000000000004280 <generic_lsm_process_filter>:
    4280:      	pushq	%rbp
    4281:      	pushq	%r15
    4283:      	pushq	%r14
    4285:      	pushq	%r13
    4287:      	pushq	%r12
    4289:      	pushq	%rbx
    428a:      	subq	$0xe8, %rsp
    4291:      	movq	%rdi, %rbx
    4294:      	movl	$0x0, 0xc8(%rsp)
    429f:      	movq	(%rip), %rdi            # 0x42a6 <generic_lsm_process_filter+0x26>
    42a6:      	leaq	0xc8(%rsp), %rsi
    42ae:      	movl	$0x1, %eax
    42b3:      	callq	*%rax
    42b5:      	testq	%rax, %rax
    42b8:      	je	0x68a3 <generic_lsm_process_filter+0x2623>
    42be:      	movq	%rax, %r14
    42c1:      	movl	$0x23, %eax
    42c6:      	callq	*%rax
    42c8:      	movq	%rax, %rcx
    42cb:      	movq	%rax, 0x60(%rsp)
    42d0:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    42d7:      	leaq	0x10(%rsp), %rdi
    42dc:      	movl	$0x4, %edx
    42e1:      	movl	$0x71, %eax
    42e6:      	movl	$0xaf4, %edx            # imm = 0xAF4
    42eb:      	addq	0x60(%rsp), %rdx
    42f0:      	movl	$0x4, %esi
    42f5:      	callq	*%rax
    42f7:      	movl	0x10(%rsp), %eax
    42fb:      	movl	%eax, 0x40(%rsp)
    42ff:      	movq	(%rip), %rdi            # 0x4306 <generic_lsm_process_filter+0x86>
    4306:      	leaq	0x40(%rsp), %rsi
    430b:      	movl	$0x1, %eax
    4310:      	callq	*%rax
    4312:      	testq	%rax, %rax
    4315:      	movq	%r14, 0x50(%rsp)
    431a:      	je	0x432a <generic_lsm_process_filter+0xaa>
    431c:      	movq	%rax, %r15
    431f:      	cmpq	$0x0, 0x8(%rax)
    4324:      	jne	0x52af <generic_lsm_process_filter+0x102f>
    432a:      	movl	$0xb00, %edx            # imm = 0xB00
    432f:      	movq	0x60(%rsp), %rcx
    4334:      	addq	%rdx, %rcx
    4337:      	leaq	0x60(%rsp), %rdi
    433c:      	movl	$0x8, %esi
    4341:      	movl	$0x71, %eax
    4346:      	addq	0x60(%rsp), %rdx
    434b:      	movl	$0x8, %esi
    4350:      	callq	*%rax
    4352:      	movq	0x60(%rsp), %rcx
    4357:      	testq	%rcx, %rcx
    435a:      	je	0x44ef <generic_lsm_process_filter+0x26f>
    4360:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    4367:      	leaq	0x10(%rsp), %rdi
    436c:      	movl	$0x4, %edx
    4371:      	movl	$0x71, %eax
    4376:      	movl	$0xaf4, %edx            # imm = 0xAF4
    437b:      	addq	0x60(%rsp), %rdx
    4380:      	movl	$0x4, %esi
    4385:      	callq	*%rax
    4387:      	movl	0x10(%rsp), %eax
    438b:      	movl	%eax, 0x40(%rsp)
    438f:      	movq	(%rip), %rdi            # 0x4396 <generic_lsm_process_filter+0x116>
    4396:      	leaq	0x40(%rsp), %rsi
    439b:      	movl	$0x1, %eax
    43a0:      	callq	*%rax
    43a2:      	testq	%rax, %rax
    43a5:      	je	0x43b5 <generic_lsm_process_filter+0x135>
    43a7:      	movq	%rax, %r15
    43aa:      	cmpq	$0x0, 0x8(%rax)
    43af:      	jne	0x52af <generic_lsm_process_filter+0x102f>
    43b5:      	movl	$0xb00, %edx            # imm = 0xB00
    43ba:      	movq	0x60(%rsp), %rcx
    43bf:      	addq	%rdx, %rcx
    43c2:      	leaq	0x60(%rsp), %rdi
    43c7:      	movl	$0x8, %esi
    43cc:      	movl	$0x71, %eax
    43d1:      	addq	0x60(%rsp), %rdx
    43d6:      	movl	$0x8, %esi
    43db:      	callq	*%rax
    43dd:      	movq	0x60(%rsp), %rcx
    43e2:      	testq	%rcx, %rcx
    43e5:      	je	0x44ef <generic_lsm_process_filter+0x26f>
    43eb:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    43f2:      	leaq	0x10(%rsp), %rdi
    43f7:      	movl	$0x4, %edx
    43fc:      	movl	$0x71, %eax
    4401:      	movl	$0xaf4, %edx            # imm = 0xAF4
    4406:      	addq	0x60(%rsp), %rdx
    440b:      	movl	$0x4, %esi
    4410:      	callq	*%rax
    4412:      	movl	0x10(%rsp), %eax
    4416:      	movl	%eax, 0x40(%rsp)
    441a:      	movq	(%rip), %rdi            # 0x4421 <generic_lsm_process_filter+0x1a1>
    4421:      	leaq	0x40(%rsp), %rsi
    4426:      	movl	$0x1, %eax
    442b:      	callq	*%rax
    442d:      	testq	%rax, %rax
    4430:      	je	0x4440 <generic_lsm_process_filter+0x1c0>
    4432:      	movq	%rax, %r15
    4435:      	cmpq	$0x0, 0x8(%rax)
    443a:      	jne	0x52af <generic_lsm_process_filter+0x102f>
    4440:      	movl	$0xb00, %edx            # imm = 0xB00
    4445:      	movq	0x60(%rsp), %rcx
    444a:      	addq	%rdx, %rcx
    444d:      	leaq	0x60(%rsp), %rdi
    4452:      	movl	$0x8, %esi
    4457:      	movl	$0x71, %eax
    445c:      	addq	0x60(%rsp), %rdx
    4461:      	movl	$0x8, %esi
    4466:      	callq	*%rax
    4468:      	movq	0x60(%rsp), %rcx
    446d:      	testq	%rcx, %rcx
    4470:      	je	0x44ef <generic_lsm_process_filter+0x26f>
    4472:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    4479:      	leaq	0x10(%rsp), %rdi
    447e:      	movl	$0x4, %edx
    4483:      	movl	$0x71, %eax
    4488:      	movl	$0xaf4, %edx            # imm = 0xAF4
    448d:      	addq	0x60(%rsp), %rdx
    4492:      	movl	$0x4, %esi
    4497:      	callq	*%rax
    4499:      	movl	0x10(%rsp), %eax
    449d:      	movl	%eax, 0x40(%rsp)
    44a1:      	movq	(%rip), %rdi            # 0x44a8 <generic_lsm_process_filter+0x228>
    44a8:      	leaq	0x40(%rsp), %rsi
    44ad:      	movl	$0x1, %eax
    44b2:      	callq	*%rax
    44b4:      	testq	%rax, %rax
    44b7:      	je	0x44c7 <generic_lsm_process_filter+0x247>
    44b9:      	movq	%rax, %r15
    44bc:      	cmpq	$0x0, 0x8(%rax)
    44c1:      	jne	0x52af <generic_lsm_process_filter+0x102f>
    44c7:      	movl	$0xb00, %edx            # imm = 0xB00
    44cc:      	movq	0x60(%rsp), %rcx
    44d1:      	addq	%rdx, %rcx
    44d4:      	leaq	0x60(%rsp), %rdi
    44d9:      	movl	$0x8, %esi
    44de:      	movl	$0x71, %eax
    44e3:      	addq	0x60(%rsp), %rdx
    44e8:      	movl	$0x8, %esi
    44ed:      	callq	*%rax
    44ef:      	movq	%rbx, 0xb8(%rsp)
    44f7:      	movl	$0x23, %eax
    44fc:      	callq	*%rax
    44fe:      	movq	%rax, %r13
    4501:      	leaq	0xaf4(%rax), %rdx
    4508:      	leaq	0x60(%rsp), %rdi
    450d:      	movl	$0x4, %ecx
    4512:      	movl	$0x4, %eax
    4517:      	movl	$0x4, %ebp
    451c:      	movl	$0x4, %esi
    4521:      	callq	*%rax
    4523:      	movl	0x60(%rsp), %eax
    4527:      	movl	%eax, 0x5f10(%r14)
    452e:      	movl	$0x7d, %eax
    4533:      	callq	*%rax
    4535:      	movq	%rax, 0x5f18(%r14)
    453c:      	movl	$0x0, 0x5f20(%r14)
    4547:      	movq	$0x0, 0x5f28(%r14)
    4552:      	movl	$0x0, 0x5f30(%r14)
    455d:      	leaq	0x60(%r13), %rdx
    4561:      	leaq	0x40(%rsp), %rdi
    4566:      	movl	$0x8, %ecx
    456b:      	movl	$0x71, %eax
    4570:      	movl	$0x8, %esi
    4575:      	callq	*%rax
    4577:      	movq	0x40(%rsp), %rcx
    457c:      	xorl	%ebx, %ebx
    457e:      	testq	%rcx, %rcx
    4581:      	je	0x45f0 <generic_lsm_process_filter+0x370>
    4583:      	addq	$0x4, %rcx
    4587:      	leaq	0x10(%rsp), %rdi
    458c:      	movl	$0x4, %edx
    4591:      	movl	$0x71, %eax
    4596:      	movq	0x40(%rsp), %rdx
    459b:      	addq	$0x4, %rdx
    459f:      	movl	$0x4, %esi
    45a4:      	callq	*%rax
    45a6:      	movl	0x10(%rsp), %eax
    45aa:      	testl	%eax, %eax
    45ac:      	je	0x45f0 <generic_lsm_process_filter+0x370>
    45ae:      	movq	0x40(%rsp), %rcx
    45b3:      	shll	$0x4, %eax
    45b6:      	addq	%rax, %rcx
    45b9:      	addq	$0x80, %rcx
    45c0:      	leaq	0x60(%rsp), %rdi
    45c5:      	movl	$0x10, %edx
    45ca:      	movl	$0x71, %eax
    45cf:      	movq	0x40(%rsp), %rcx
    45d4:      	movl	0x10(%rsp), %edx
    45d8:      	shll	$0x4, %edx
    45db:      	addq	%rcx, %rdx
    45de:      	addq	$0x80, %rdx
    45e5:      	movl	$0x10, %esi
    45ea:      	callq	*%rax
    45ec:      	movl	0x60(%rsp), %ebx
    45f0:      	movl	%ebx, 0x5f34(%r14)
    45f7:      	leaq	0xd00(%r13), %r15
    45fe:      	leaq	0x60(%rsp), %rdi
    4603:      	movl	$0x8, %ecx
    4608:      	movl	$0x4, %eax
    460d:      	leaq	0x5f60(%r14), %rbx
    4614:      	movl	$0x8, %esi
    4619:      	movq	%r15, %rdx
    461c:      	callq	*%rax
    461e:      	movq	0x60(%rsp), %r12
    4623:      	leaq	0x5f68(%r14), %rdi
    462a:      	leaq	0x40(%r12), %rdx
    462f:      	movl	$0x8, %ecx
    4634:      	movl	$0x4, %eax
    4639:      	movl	$0x8, %esi
    463e:      	callq	*%rax
    4640:      	leaq	0x5f70(%r14), %rdi
    4647:      	leaq	0x30(%r12), %rdx
    464c:      	movl	$0x8, %ecx
    4651:      	movl	$0x4, %eax
    4656:      	movl	$0x8, %esi
    465b:      	callq	*%rax
    465d:      	addq	$0x38, %r12
    4661:      	movl	$0x8, %ecx
    4666:      	movl	$0x4, %eax
    466b:      	movq	%rbx, %rdi
    466e:      	movl	$0x8, %esi
    4673:      	movq	%r12, %rdx
    4676:      	callq	*%rax
    4678:      	leaq	0x5f38(%r14), %rbx
    467f:      	leaq	0xd70(%r13), %rdx
    4686:      	leaq	0x10(%rsp), %rdi
    468b:      	movl	$0x8, %ecx
    4690:      	movl	$0x4, %eax
    4695:      	movl	$0x8, %esi
    469a:      	callq	*%rax
    469c:      	movq	0x10(%rsp), %rcx
    46a1:      	leaq	0x60(%rsp), %rdi
    46a6:      	movl	$0x48, %edx
    46ab:      	movl	$0x4, %eax
    46b0:      	movq	0x10(%rsp), %rdx
    46b5:      	movl	$0x48, %esi
    46ba:      	callq	*%rax
    46bc:      	movl	$0x218, %edx            # imm = 0x218
    46c1:      	movq	0x68(%rsp), %rcx
    46c6:      	addq	%rdx, %rcx
    46c9:      	movl	$0x4, %eax
    46ce:      	addq	0x68(%rsp), %rdx
    46d3:      	movq	%rbx, %rdi
    46d6:      	movl	$0x4, %esi
    46db:      	callq	*%rax
    46dd:      	leaq	0x5f3c(%r14), %rdi
    46e4:      	movl	$0x4d8, %edx            # imm = 0x4D8
    46e9:      	movq	0x70(%rsp), %rcx
    46ee:      	addq	%rdx, %rcx
    46f1:      	movl	$0x4, %eax
    46f6:      	addq	0x70(%rsp), %rdx
    46fb:      	movl	$0x4, %esi
    4700:      	callq	*%rax
    4702:      	leaq	0x5f40(%r14), %rdi
    4709:      	movq	0x78(%rsp), %rcx
    470e:      	addq	$0x58, %rcx
    4712:      	movl	$0x4, %eax
    4717:      	movq	0x78(%rsp), %rdx
    471c:      	addq	$0x58, %rdx
    4720:      	movl	$0x4, %esi
    4725:      	callq	*%rax
    4727:      	movq	$0x0, 0x58(%rsp)
    4730:      	leaq	0xb58(%r13), %rdx
    4737:      	leaq	0x58(%rsp), %rdi
    473c:      	movl	$0x8, %ecx
    4741:      	movl	$0x4, %eax
    4746:      	movl	$0x8, %esi
    474b:      	callq	*%rax
    474d:      	movq	0x58(%rsp), %rcx
    4752:      	testq	%rcx, %rcx
    4755:      	je	0x4804 <generic_lsm_process_filter+0x584>
    475b:      	movl	$0x0, 0xa8(%rsp)
    4766:      	addq	$0x4, %rcx
    476a:      	leaq	0xa8(%rsp), %rdi
    4772:      	movl	$0x4, %edx
    4777:      	movl	$0x4, %eax
    477c:      	movq	0x58(%rsp), %rdx
    4781:      	addq	$0x4, %rdx
    4785:      	movl	$0x4, %esi
    478a:      	callq	*%rax
    478c:      	movq	0x58(%rsp), %rax
    4791:      	movslq	0xa8(%rsp), %rcx
    4799:      	shlq	$0x4, %rcx
    479d:      	addq	%rax, %rcx
    47a0:      	addq	$0x80, %rcx
    47a7:      	leaq	0x40(%rsp), %rdi
    47ac:      	movl	$0x10, %edx
    47b1:      	movl	$0x4, %eax
    47b6:      	movq	0x58(%rsp), %rcx
    47bb:      	movslq	0xa8(%rsp), %rdx
    47c3:      	shlq	$0x4, %rdx
    47c7:      	addq	%rcx, %rdx
    47ca:      	addq	$0x80, %rdx
    47d1:      	movl	$0x10, %esi
    47d6:      	callq	*%rax
    47d8:      	leaq	0x5f44(%r14), %rdi
    47df:      	movl	$0x158, %edx            # imm = 0x158
    47e4:      	movq	0x48(%rsp), %rcx
    47e9:      	addq	%rdx, %rcx
    47ec:      	movl	$0x4, %esi
    47f1:      	movl	$0x4, %eax
    47f6:      	addq	0x48(%rsp), %rdx
    47fb:      	movl	$0x4, %esi
    4800:      	callq	*%rax
    4802:      	jmp	0x480f <generic_lsm_process_filter+0x58f>
    4804:      	movl	$0x0, 0x5f44(%r14)
    480f:      	leaq	0x5f48(%r14), %rdi
    4816:      	movl	$0x158, %ebx            # imm = 0x158
    481b:      	movq	0x80(%rsp), %rcx
    4823:      	addq	%rbx, %rcx
    4826:      	movl	$0x4, %edx
    482b:      	movl	$0x4, %eax
    4830:      	movq	0x80(%rsp), %rdx
    4838:      	addq	%rbx, %rdx
    483b:      	movl	$0x4, %esi
    4840:      	callq	*%rax
    4842:      	leaq	0x5f4c(%r14), %rdi
    4849:      	movl	$0x118, %edx            # imm = 0x118
    484e:      	movq	0x88(%rsp), %rcx
    4856:      	addq	%rdx, %rcx
    4859:      	movl	$0x4, %esi
    485e:      	movl	$0x4, %eax
    4863:      	addq	0x88(%rsp), %rdx
    486b:      	movl	$0x4, %esi
    4870:      	callq	*%rax
    4872:      	leaq	0x5f50(%r14), %rdi
    4879:      	movl	$0x98, %r12d
    487f:      	movq	0x90(%rsp), %rcx
    4887:      	addq	%r12, %rcx
    488a:      	movl	$0x4, %edx
    488f:      	movl	$0x4, %eax
    4894:      	movq	0x90(%rsp), %rdx
    489c:      	addq	%r12, %rdx
    489f:      	movl	$0x4, %esi
    48a4:      	callq	*%rax
    48a6:      	leaq	0x5f54(%r14), %rdi
    48ad:      	movq	0x98(%rsp), %rcx
    48b5:      	addq	%r12, %rcx
    48b8:      	movl	$0x4, %edx
    48bd:      	movl	$0x4, %eax
    48c2:      	addq	0x98(%rsp), %r12
    48ca:      	movl	$0x4, %esi
    48cf:      	movq	%r12, %rdx
    48d2:      	callq	*%rax
    48d4:      	leaq	0x5f58(%r14), %rdi
    48db:      	movq	0xa0(%rsp), %rcx
    48e3:      	addq	$0x58, %rcx
    48e7:      	movl	$0x4, %edx
    48ec:      	movl	$0x4, %eax
    48f1:      	movq	0xa0(%rsp), %rdx
    48f9:      	addq	$0x58, %rdx
    48fd:      	movl	$0x4, %esi
    4902:      	callq	*%rax
    4904:      	movq	$0x0, 0x40(%rsp)
    490d:      	movq	$0x0, 0x58(%rsp)
    4916:      	leaq	0x40(%rsp), %rdi
    491b:      	movl	$0x8, %ecx
    4920:      	movl	$0x4, %eax
    4925:      	movl	$0x8, %esi
    492a:      	movq	%r15, %rdx
    492d:      	callq	*%rax
    492f:      	movl	$0x90, %edx
    4934:      	movq	0x40(%rsp), %rcx
    4939:      	addq	%rdx, %rcx
    493c:      	leaq	0x58(%rsp), %rdi
    4941:      	movl	$0x8, %esi
    4946:      	movl	$0x4, %eax
    494b:      	addq	0x40(%rsp), %rdx
    4950:      	movl	$0x8, %esi
    4955:      	callq	*%rax
    4957:      	leaq	0x5f5c(%r14), %rdi
    495e:      	movq	0x58(%rsp), %rcx
    4963:      	addq	%rbx, %rcx
    4966:      	movl	$0x4, %edx
    496b:      	movl	$0x4, %eax
    4970:      	addq	0x58(%rsp), %rbx
    4975:      	movl	$0x4, %esi
    497a:      	movq	%rbx, %rdx
    497d:      	callq	*%rax
    497f:      	cmpl	$0x1, 0x5f34(%r14)
    4987:      	jne	0x4991 <generic_lsm_process_filter+0x711>
    4989:      	orb	$0x2, 0x5f33(%r14)
    4991:      	leaq	0x5f78(%r14), %rdi
    4998:      	movl	$0x308, %edx            # imm = 0x308
    499d:      	movq	%rdi, 0x8(%rsp)
    49a2:      	xorl	%esi, %esi
    49a4:      	callq	0x49a9 <generic_lsm_process_filter+0x729>
    49a9:      	leaq	0x6290(%r14), %rbp
    49b0:      	addq	$0xa78, %r13            # imm = 0xA78
    49b7:      	leaq	0x40(%rsp), %rdi
    49bc:      	movl	$0x8, %ecx
    49c1:      	movl	$0x4, %eax
    49c6:      	movl	$0x8, %esi
    49cb:      	movq	%r13, %rdx
    49ce:      	callq	*%rax
    49d0:      	movl	$0x5f8, %edx            # imm = 0x5F8
    49d5:      	movq	0x40(%rsp), %rcx
    49da:      	addq	%rdx, %rcx
    49dd:      	leaq	0x60(%rsp), %rdi
    49e2:      	movl	$0x8, %esi
    49e7:      	movl	$0x4, %eax
    49ec:      	addq	0x40(%rsp), %rdx
    49f1:      	movl	$0x8, %esi
    49f6:      	callq	*%rax
    49f8:      	movq	0x60(%rsp), %rbx
    49fd:      	movl	$0x0, 0xcc(%rsp)
    4a08:      	movq	(%rip), %rdi            # 0x4a0f <generic_lsm_process_filter+0x78f>
    4a0f:      	leaq	0xcc(%rsp), %rsi
    4a17:      	movl	$0x1, %eax
    4a1c:      	callq	*%rax
    4a1e:      	testq	%rax, %rax
    4a21:      	je	0x5127 <generic_lsm_process_filter+0xea7>
    4a27:      	movq	%rax, %r12
    4a2a:      	movq	%rbp, 0x38(%rsp)
    4a2f:      	movl	$0x1000, 0x6410(%r14)   # imm = 0x1000
    4a3a:      	leaq	0x1000(%rax), %r13
    4a41:      	movl	$0x23, %eax
    4a46:      	callq	*%rax
    4a48:      	leaq	0xd50(%rax), %rdx
    4a4f:      	leaq	0xd8(%rsp), %rdi
    4a57:      	movl	$0x8, %ecx
    4a5c:      	movl	$0x4, %eax
    4a61:      	movl	$0x8, %esi
    4a66:      	callq	*%rax
    4a68:      	movq	0xd8(%rsp), %rbp
    4a70:      	leaq	0x48(%rbx), %r15
    4a74:      	leaq	0xe0(%rsp), %rdi
    4a7c:      	movl	$0x8, %ecx
    4a81:      	movl	$0x4, %eax
    4a86:      	movl	$0x8, %esi
    4a8b:      	movq	%r15, %rdx
    4a8e:      	callq	*%rax
    4a90:      	movq	0xe0(%rsp), %r14
    4a98:      	leaq	0x10(%r14), %rdx
    4a9c:      	leaq	0x60(%rsp), %rdi
    4aa1:      	movl	$0x8, %ecx
    4aa6:      	movl	$0x4, %eax
    4aab:      	movl	$0x8, %esi
    4ab0:      	callq	*%rax
    4ab2:      	cmpq	$0x0, 0x60(%rsp)
    4ab8:      	je	0x4d86 <generic_lsm_process_filter+0xb06>
    4abe:      	movq	0x50(%rsp), %r14
    4ac3:      	movq	$0x0, 0x68(%rsp)
    4acc:      	movq	$0x0, 0x60(%rsp)
    4ad5:      	movq	%r12, 0x70(%rsp)
    4ada:      	movq	$0x0, 0x78(%rsp)
    4ae3:      	movq	$0x0, 0x80(%rsp)
    4aef:      	movq	$0x0, 0x88(%rsp)
    4afb:      	movq	%r13, 0xc0(%rsp)
    4b03:      	movq	%r13, 0x90(%rsp)
    4b0b:      	movl	0x6410(%r14), %eax
    4b12:      	movl	%eax, 0x98(%rsp)
    4b19:      	leaq	0x18(%rbp), %r13
    4b1d:      	movb	$0x0, 0x9c(%rsp)
    4b25:      	addq	$0x20, %rbp
    4b29:      	leaq	0x60(%rsp), %rdi
    4b2e:      	movl	$0x8, %ecx
    4b33:      	movl	$0x4, %eax
    4b38:      	addq	$0x40, %rbx
    4b3c:      	leaq	0x68(%rsp), %r12
    4b41:      	leaq	0x78(%rsp), %r14
    4b46:      	movl	$0x8, %esi
    4b4b:      	movq	%rbp, %rdx
    4b4e:      	callq	*%rax
    4b50:      	movl	$0x8, %ecx
    4b55:      	movl	$0x4, %eax
    4b5a:      	movq	%r12, %rdi
    4b5d:      	movl	$0x8, %esi
    4b62:      	movq	%r13, %rdx
    4b65:      	callq	*%rax
    4b67:      	movl	$0x8, %ecx
    4b6c:      	movl	$0x4, %eax
    4b71:      	movq	%r14, %rdi
    4b74:      	movl	$0x8, %esi
    4b79:      	movq	%r15, %rdx
    4b7c:      	callq	*%rax
    4b7e:      	movl	$0x8, %ecx
    4b83:      	movl	$0x4, %eax
    4b88:      	leaq	0x80(%rsp), %rdi
    4b90:      	movl	$0x8, %esi
    4b95:      	movq	%rbx, %rdx
    4b98:      	callq	*%rax
    4b9a:      	movq	0x80(%rsp), %rax
    4ba2:      	addq	$-0x20, %rax
    4ba6:      	movq	%rax, 0x88(%rsp)
    4bae:      	movq	(%rip), %rax            # 0x4bb5 <generic_lsm_process_filter+0x935>
    4bb5:      	cmpb	$0x0, (%rax)
    4bb8:      	je	0x4ddd <generic_lsm_process_filter+0xb5d>
    4bbe:      	movl	$0x80, %r14d
    4bc4:      	movl	$0x8, %ebp
    4bc9:      	leaq	0x10(%rsp), %rbx
    4bce:      	nop
    4bd0:      	movq	0x78(%rsp), %r15
    4bd5:      	movq	0x80(%rsp), %rdx
    4bdd:      	movq	0x88(%rsp), %r12
    4be5:      	cmpq	0x60(%rsp), %r15
    4bea:      	jne	0x4bf7 <generic_lsm_process_filter+0x977>
    4bec:      	cmpq	0x68(%rsp), %rdx
    4bf1:      	je	0x4f9f <generic_lsm_process_filter+0xd1f>
    4bf7:      	movl	$0x4, %eax
    4bfc:      	leaq	0xa8(%rsp), %rdi
    4c04:      	movl	$0x8, %esi
    4c09:      	callq	*%rax
    4c0b:      	cmpq	0xa8(%rsp), %r15
    4c13:      	je	0x4d20 <generic_lsm_process_filter+0xaa0>
    4c19:      	leaq	0x18(%r15), %r13
    4c1d:      	movl	$0x4, %eax
    4c22:      	movq	%rbx, %rdi
    4c25:      	movl	$0x8, %esi
    4c2a:      	movq	%r13, %rdx
    4c2d:      	callq	*%rax
    4c2f:      	cmpq	%r15, 0x10(%rsp)
    4c34:      	je	0x4d20 <generic_lsm_process_filter+0xaa0>
    4c3a:      	movl	$0x4, %eax
    4c3f:      	leaq	0x58(%rsp), %rdi
    4c44:      	movl	$0x8, %esi
    4c49:      	movq	%r13, %rdx
    4c4c:      	callq	*%rax
    4c4e:      	addq	$0x20, %r15
    4c52:      	movl	$0x4, %eax
    4c57:      	leaq	0x40(%rsp), %rdi
    4c5c:      	movl	$0x10, %ecx
    4c61:      	movl	$0x10, %esi
    4c66:      	movq	%r15, %rdx
    4c69:      	callq	*%rax
    4c6b:      	movq	0x70(%rsp), %r15
    4c70:      	movq	0x90(%rsp), %rax
    4c78:      	movl	0x44(%rsp), %r12d
    4c7d:      	subq	%r15, %rax
    4c80:      	movl	0x98(%rsp), %r13d
    4c88:      	movl	%r12d, %edx
    4c8b:      	subl	%r13d, %edx
    4c8e:      	movl	$0x0, %ecx
    4c93:      	cmovbl	%ecx, %edx
    4c96:      	addq	0x48(%rsp), %rdx
    4c9b:      	xorl	%esi, %esi
    4c9d:      	cmpl	%r12d, %r13d
    4ca0:      	seta	%sil
    4ca4:      	movl	%r12d, %ecx
    4ca7:      	cmovbl	%r13d, %ecx
    4cab:      	addl	%ecx, %esi
    4cad:      	movl	%r13d, %edi
    4cb0:      	subl	%esi, %edi
    4cb2:      	movl	%edi, 0x98(%rsp)
    4cb9:      	subq	%rsi, %rax
    4cbc:      	jb	0x4fa7 <generic_lsm_process_filter+0xd27>
    4cc2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    4cc8:      	ja	0x4fa7 <generic_lsm_process_filter+0xd27>
    4cce:      	cmpl	%r12d, %r13d
    4cd1:      	jbe	0x4cd8 <generic_lsm_process_filter+0xa58>
    4cd3:      	movb	$0x2f, (%r15,%rax)
    4cd8:      	xorl	%edi, %edi
    4cda:      	cmpl	%r12d, %r13d
    4cdd:      	seta	%dil
    4ce1:      	movzbl	%cl, %esi
    4ce4:      	addq	%rax, %r15
    4ce7:      	addq	%r15, %rdi
    4cea:      	movl	$0x4, %eax
    4cef:      	callq	*%rax
    4cf1:      	movq	%r15, 0x90(%rsp)
    4cf9:      	cmpl	%r12d, %r13d
    4cfc:      	jbe	0x4fa7 <generic_lsm_process_filter+0xd27>
    4d02:      	movq	0x58(%rsp), %rax
    4d07:      	movq	%rax, 0x78(%rsp)
    4d0c:      	decl	%r14d
    4d0f:      	jne	0x4bd0 <generic_lsm_process_filter+0x950>
    4d15:      	jmp	0x4fa7 <generic_lsm_process_filter+0xd27>
    4d1a:      	nopw	(%rax,%rax)
    4d20:      	leaq	0x10(%r12), %rdx
    4d25:      	movl	$0x4, %eax
    4d2a:      	movq	%rbx, %rdi
    4d2d:      	movl	$0x8, %esi
    4d32:      	callq	*%rax
    4d34:      	movq	0x88(%rsp), %rax
    4d3c:      	cmpq	0x10(%rsp), %rax
    4d41:      	je	0x4f9f <generic_lsm_process_filter+0xd1f>
    4d47:      	addq	$0x18, %r12
    4d4b:      	movl	$0x4, %eax
    4d50:      	leaq	0x78(%rsp), %rdi
    4d55:      	movl	$0x8, %esi
    4d5a:      	movq	%r12, %rdx
    4d5d:      	callq	*%rax
    4d5f:      	movq	0x10(%rsp), %rax
    4d64:      	movq	%rax, 0x88(%rsp)
    4d6c:      	addq	$0x20, %rax
    4d70:      	movq	%rax, 0x80(%rsp)
    4d78:      	decl	%r14d
    4d7b:      	jne	0x4bd0 <generic_lsm_process_filter+0x950>
    4d81:      	jmp	0x4fa7 <generic_lsm_process_filter+0xd27>
    4d86:      	leaq	0x18(%r14), %rdx
    4d8a:      	leaq	0x60(%rsp), %rdi
    4d8f:      	movl	$0x8, %ecx
    4d94:      	movl	$0x4, %eax
    4d99:      	movl	$0x8, %esi
    4d9e:      	callq	*%rax
    4da0:      	cmpq	%r14, 0x60(%rsp)
    4da5:      	je	0x4abe <generic_lsm_process_filter+0x83e>
    4dab:      	movq	0x50(%rsp), %r14
    4db0:      	movl	0x6410(%r14), %ecx
    4db7:      	leal	-0xa(%rcx), %eax
    4dba:      	movl	%eax, 0x6410(%r14)
    4dc1:      	cmpl	$0x9, %ecx
    4dc4:      	jg	0x5764 <generic_lsm_process_filter+0x14e4>
    4dca:      	movl	$0xffffffdc, 0x6414(%r14) # imm = 0xFFFFFFDC
    4dd5:      	movq	%r13, %rbx
    4dd8:      	jmp	0x5028 <generic_lsm_process_filter+0xda8>
    4ddd:      	movl	$0x80, %r14d
    4de3:      	movl	$0x8, %ebp
    4de8:      	leaq	0x10(%rsp), %rbx
    4ded:      	nopl	(%rax)
    4df0:      	movq	0x78(%rsp), %r15
    4df5:      	movq	0x80(%rsp), %rdx
    4dfd:      	movq	0x88(%rsp), %r12
    4e05:      	cmpq	0x60(%rsp), %r15
    4e0a:      	jne	0x4e17 <generic_lsm_process_filter+0xb97>
    4e0c:      	cmpq	0x68(%rsp), %rdx
    4e11:      	je	0x4f9f <generic_lsm_process_filter+0xd1f>
    4e17:      	movl	$0x4, %eax
    4e1c:      	leaq	0xa8(%rsp), %rdi
    4e24:      	movl	$0x8, %esi
    4e29:      	callq	*%rax
    4e2b:      	cmpq	0xa8(%rsp), %r15
    4e33:      	je	0x4f40 <generic_lsm_process_filter+0xcc0>
    4e39:      	leaq	0x18(%r15), %r13
    4e3d:      	movl	$0x4, %eax
    4e42:      	movq	%rbx, %rdi
    4e45:      	movl	$0x8, %esi
    4e4a:      	movq	%r13, %rdx
    4e4d:      	callq	*%rax
    4e4f:      	cmpq	%r15, 0x10(%rsp)
    4e54:      	je	0x4f40 <generic_lsm_process_filter+0xcc0>
    4e5a:      	movl	$0x4, %eax
    4e5f:      	leaq	0x58(%rsp), %rdi
    4e64:      	movl	$0x8, %esi
    4e69:      	movq	%r13, %rdx
    4e6c:      	callq	*%rax
    4e6e:      	addq	$0x20, %r15
    4e72:      	movl	$0x4, %eax
    4e77:      	leaq	0x40(%rsp), %rdi
    4e7c:      	movl	$0x10, %ecx
    4e81:      	movl	$0x10, %esi
    4e86:      	movq	%r15, %rdx
    4e89:      	callq	*%rax
    4e8b:      	movq	0x70(%rsp), %r15
    4e90:      	movq	0x90(%rsp), %rax
    4e98:      	movl	0x44(%rsp), %r12d
    4e9d:      	subq	%r15, %rax
    4ea0:      	movl	0x98(%rsp), %r13d
    4ea8:      	movl	%r12d, %edx
    4eab:      	subl	%r13d, %edx
    4eae:      	movl	$0x0, %ecx
    4eb3:      	cmovbl	%ecx, %edx
    4eb6:      	addq	0x48(%rsp), %rdx
    4ebb:      	xorl	%esi, %esi
    4ebd:      	cmpl	%r12d, %r13d
    4ec0:      	seta	%sil
    4ec4:      	movl	%r12d, %ecx
    4ec7:      	cmovbl	%r13d, %ecx
    4ecb:      	addl	%ecx, %esi
    4ecd:      	movl	%r13d, %edi
    4ed0:      	subl	%esi, %edi
    4ed2:      	movl	%edi, 0x98(%rsp)
    4ed9:      	subq	%rsi, %rax
    4edc:      	jb	0x4fa7 <generic_lsm_process_filter+0xd27>
    4ee2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    4ee8:      	ja	0x4fa7 <generic_lsm_process_filter+0xd27>
    4eee:      	cmpl	%r12d, %r13d
    4ef1:      	jbe	0x4ef8 <generic_lsm_process_filter+0xc78>
    4ef3:      	movb	$0x2f, (%r15,%rax)
    4ef8:      	xorl	%edi, %edi
    4efa:      	cmpl	%r12d, %r13d
    4efd:      	seta	%dil
    4f01:      	movzbl	%cl, %esi
    4f04:      	addq	%rax, %r15
    4f07:      	addq	%r15, %rdi
    4f0a:      	movl	$0x4, %eax
    4f0f:      	callq	*%rax
    4f11:      	movq	%r15, 0x90(%rsp)
    4f19:      	cmpl	%r12d, %r13d
    4f1c:      	jbe	0x4fa7 <generic_lsm_process_filter+0xd27>
    4f22:      	movq	0x58(%rsp), %rax
    4f27:      	movq	%rax, 0x78(%rsp)
    4f2c:      	decl	%r14d
    4f2f:      	jne	0x4df0 <generic_lsm_process_filter+0xb70>
    4f35:      	jmp	0x4fa7 <generic_lsm_process_filter+0xd27>
    4f37:      	nopw	(%rax,%rax)
    4f40:      	leaq	0x10(%r12), %rdx
    4f45:      	movl	$0x4, %eax
    4f4a:      	movq	%rbx, %rdi
    4f4d:      	movl	$0x8, %esi
    4f52:      	callq	*%rax
    4f54:      	movq	0x88(%rsp), %rax
    4f5c:      	cmpq	0x10(%rsp), %rax
    4f61:      	je	0x4f9f <generic_lsm_process_filter+0xd1f>
    4f63:      	addq	$0x18, %r12
    4f67:      	movl	$0x4, %eax
    4f6c:      	leaq	0x78(%rsp), %rdi
    4f71:      	movl	$0x8, %esi
    4f76:      	movq	%r12, %rdx
    4f79:      	callq	*%rax
    4f7b:      	movq	0x10(%rsp), %rax
    4f80:      	movq	%rax, 0x88(%rsp)
    4f88:      	addq	$0x20, %rax
    4f8c:      	movq	%rax, 0x80(%rsp)
    4f94:      	decl	%r14d
    4f97:      	jne	0x4df0 <generic_lsm_process_filter+0xb70>
    4f9d:      	jmp	0x4fa7 <generic_lsm_process_filter+0xd27>
    4f9f:      	movb	$0x1, 0x9c(%rsp)
    4fa7:      	movq	0x90(%rsp), %rbx
    4faf:      	movq	0xc0(%rsp), %rcx
    4fb7:      	cmpq	%rcx, %rbx
    4fba:      	je	0x5008 <generic_lsm_process_filter+0xd88>
    4fbc:      	xorl	%ecx, %ecx
    4fbe:      	cmpb	$0x0, 0x9c(%rsp)
    4fc6:      	sete	%cl
    4fc9:      	addl	%ecx, %ecx
    4fcb:      	movl	0x98(%rsp), %eax
    4fd2:      	movq	0x50(%rsp), %r14
    4fd7:      	movl	%eax, 0x6410(%r14)
    4fde:      	movl	%ecx, 0x6414(%r14)
    4fe5:      	testl	%eax, %eax
    4fe7:      	movq	0x38(%rsp), %rbp
    4fec:      	jle	0x4ffe <generic_lsm_process_filter+0xd7e>
    4fee:      	movl	$0x1000, %ecx           # imm = 0x1000
    4ff3:      	subl	%eax, %ecx
    4ff5:      	movl	%ecx, 0x6410(%r14)
    4ffc:      	movl	%ecx, %eax
    4ffe:      	testq	%rbx, %rbx
    5001:      	jne	0x502d <generic_lsm_process_filter+0xdad>
    5003:      	jmp	0x5127 <generic_lsm_process_filter+0xea7>
    5008:      	movq	0x50(%rsp), %r14
    500d:      	movl	$0x0, 0x6410(%r14)
    5018:      	movl	$0x0, 0x6414(%r14)
    5023:      	xorl	%eax, %eax
    5025:      	movq	%rcx, %rbx
    5028:      	movq	0x38(%rsp), %rbp
    502d:      	xorl	%ecx, %ecx
    502f:      	movq	%r14, %rdx
    5032:      	movl	%eax, %r14d
    5035:      	subl	$0x7f, %r14d
    5039:      	movl	$0x7f, %r15d
    503f:      	cmovbl	%eax, %r15d
    5043:      	cmovbl	%ecx, %r14d
    5047:      	cmpl	$0xff, %eax
    504c:      	movl	$0xff, %ecx
    5051:      	cmovbl	%eax, %ecx
    5054:      	movzbl	%cl, %esi
    5057:      	movl	%esi, 0x6410(%rdx)
    505d:      	movl	$0x4, %eax
    5062:      	movq	%rbp, %rdi
    5065:      	movq	%rbx, %rdx
    5068:      	callq	*%rax
    506a:      	testq	%rax, %rax
    506d:      	je	0x50cc <generic_lsm_process_filter+0xe4c>
    506f:      	negl	%eax
    5071:      	movw	%ax, 0x60(%rsp)
    5076:      	movw	$0x8, 0x62(%rsp)
    507d:      	movabsq	$0x4000002de, %rax      # imm = 0x4000002DE
    5087:      	movq	%rax, 0x64(%rsp)
    508c:      	movq	(%rip), %rdi            # 0x5093 <generic_lsm_process_filter+0xe13>
    5093:      	leaq	0x60(%rsp), %rsi
    5098:      	movl	$0x1, %eax
    509d:      	callq	*%rax
    509f:      	testq	%rax, %rax
    50a2:      	je	0x50a8 <generic_lsm_process_filter+0xe28>
    50a4:      	incl	(%rax)
    50a6:      	jmp	0x50cc <generic_lsm_process_filter+0xe4c>
    50a8:      	movl	$0x1, 0x40(%rsp)
    50b0:      	movq	(%rip), %rdi            # 0x50b7 <generic_lsm_process_filter+0xe37>
    50b7:      	xorl	%ecx, %ecx
    50b9:      	leaq	0x60(%rsp), %rsi
    50be:      	leaq	0x40(%rsp), %rdx
    50c3:      	movl	$0x2, %eax
    50c8:      	xorl	%ecx, %ecx
    50ca:      	callq	*%rax
    50cc:      	movq	0x50(%rsp), %rax
    50d1:      	leaq	0x6390(%rax), %rdi
    50d8:      	addq	%r14, %rbx
    50db:      	movq	%rax, %r14
    50de:      	movl	$0x4, %eax
    50e3:      	movl	%r15d, %esi
    50e6:      	movq	%rbx, %rdx
    50e9:      	callq	*%rax
    50eb:      	testq	%rax, %rax
    50ee:      	je	0x5127 <generic_lsm_process_filter+0xea7>
    50f0:      	negl	%eax
    50f2:      	movw	%ax, 0x60(%rsp)
    50f7:      	movw	$0x8, 0x62(%rsp)
    50fe:      	movabsq	$0x4000002e0, %rax      # imm = 0x4000002E0
    5108:      	movq	%rax, 0x64(%rsp)
    510d:      	movq	(%rip), %rdi            # 0x5114 <generic_lsm_process_filter+0xe94>
    5114:      	leaq	0x60(%rsp), %rsi
    5119:      	movl	$0x1, %eax
    511e:      	callq	*%rax
    5120:      	testq	%rax, %rax
    5123:      	je	0x5154 <generic_lsm_process_filter+0xed4>
    5125:      	incl	(%rax)
    5127:      	movl	0x6410(%r14), %eax
    512e:      	leal	-0x101(%rax), %ecx
    5134:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
    513a:      	ja	0x518d <generic_lsm_process_filter+0xf0d>
    513c:      	movq	0x8(%rsp), %rax
    5141:      	movl	$0xffffffff, (%rax)     # imm = 0xFFFFFFFF
    5147:      	movq	0xb8(%rsp), %rbx
    514f:      	jmp	0x52a3 <generic_lsm_process_filter+0x1023>
    5154:      	movl	$0x1, 0x40(%rsp)
    515c:      	movq	(%rip), %rdi            # 0x5163 <generic_lsm_process_filter+0xee3>
    5163:      	xorl	%ecx, %ecx
    5165:      	leaq	0x60(%rsp), %rsi
    516a:      	leaq	0x40(%rsp), %rdx
    516f:      	movl	$0x2, %eax
    5174:      	xorl	%ecx, %ecx
    5176:      	callq	*%rax
    5178:      	movl	0x6410(%r14), %eax
    517f:      	leal	-0x101(%rax), %ecx
    5185:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
    518b:      	jbe	0x513c <generic_lsm_process_filter+0xebc>
    518d:      	movzbl	%al, %ebx
    5190:      	leaq	0x5f80(%r14), %rdi
    5197:      	movl	$0x4, %eax
    519c:      	movl	%ebx, %esi
    519e:      	movq	%rbp, %rdx
    51a1:      	callq	*%rax
    51a3:      	movq	%rax, %r15
    51a6:      	testq	%rax, %rax
    51a9:      	je	0x520b <generic_lsm_process_filter+0xf8b>
    51ab:      	movl	%r15d, %eax
    51ae:      	negl	%eax
    51b0:      	movw	%ax, 0x60(%rsp)
    51b5:      	movw	$0xf, 0x62(%rsp)
    51bc:      	movabsq	$0x400000164, %rax      # imm = 0x400000164
    51c6:      	movq	%rax, 0x64(%rsp)
    51cb:      	movq	(%rip), %rdi            # 0x51d2 <generic_lsm_process_filter+0xf52>
    51d2:      	leaq	0x60(%rsp), %rsi
    51d7:      	movl	$0x1, %eax
    51dc:      	callq	*%rax
    51de:      	testq	%rax, %rax
    51e1:      	je	0x51e7 <generic_lsm_process_filter+0xf67>
    51e3:      	incl	(%rax)
    51e5:      	jmp	0x520b <generic_lsm_process_filter+0xf8b>
    51e7:      	movl	$0x1, 0x40(%rsp)
    51ef:      	movq	(%rip), %rdi            # 0x51f6 <generic_lsm_process_filter+0xf76>
    51f6:      	xorl	%ecx, %ecx
    51f8:      	leaq	0x60(%rsp), %rsi
    51fd:      	leaq	0x40(%rsp), %rdx
    5202:      	movl	$0x2, %eax
    5207:      	xorl	%ecx, %ecx
    5209:      	callq	*%rax
    520b:      	testl	%r15d, %r15d
    520e:      	cmovel	%ebx, %r15d
    5212:      	movl	%r15d, 0x5f78(%r14)
    5219:      	cmpl	$0x7f, %ebx
    521c:      	movl	$0x7f, %esi
    5221:      	cmovbl	%ebx, %esi
    5224:      	leaq	0x6080(%r14), %rdi
    522b:      	leaq	0x6390(%r14), %rdx
    5232:      	movl	$0x4, %eax
    5237:      	callq	*%rax
    5239:      	testq	%rax, %rax
    523c:      	movq	0xb8(%rsp), %rbx
    5244:      	je	0x52a3 <generic_lsm_process_filter+0x1023>
    5246:      	negl	%eax
    5248:      	movw	%ax, 0x60(%rsp)
    524d:      	movw	$0xf, 0x62(%rsp)
    5254:      	movabsq	$0x40000016a, %rax      # imm = 0x40000016A
    525e:      	movq	%rax, 0x64(%rsp)
    5263:      	movq	(%rip), %rdi            # 0x526a <generic_lsm_process_filter+0xfea>
    526a:      	leaq	0x60(%rsp), %rsi
    526f:      	movl	$0x1, %eax
    5274:      	callq	*%rax
    5276:      	testq	%rax, %rax
    5279:      	je	0x527f <generic_lsm_process_filter+0xfff>
    527b:      	incl	(%rax)
    527d:      	jmp	0x52a3 <generic_lsm_process_filter+0x1023>
    527f:      	movl	$0x1, 0x40(%rsp)
    5287:      	movq	(%rip), %rdi            # 0x528e <generic_lsm_process_filter+0x100e>
    528e:      	xorl	%ecx, %ecx
    5290:      	leaq	0x60(%rsp), %rsi
    5295:      	leaq	0x40(%rsp), %rdx
    529a:      	movl	$0x2, %eax
    529f:      	xorl	%ecx, %ecx
    52a1:      	callq	*%rax
    52a3:      	leaq	0x5f10(%r14), %r15
    52aa:      	orb	$0x10, 0x1(%r14)
    52af:      	leaq	0x5ef8(%r14), %rsi
    52b6:      	movq	(%rip), %rdi            # 0x52bd <generic_lsm_process_filter+0x103d>
    52bd:      	movl	$0x1, %eax
    52c2:      	callq	*%rax
    52c4:      	testq	%rax, %rax
    52c7:      	je	0x68a3 <generic_lsm_process_filter+0x2623>
    52cd:      	movq	0x5eb8(%r14), %r13
    52d4:      	cmpq	$0x6, %r13
    52d8:      	jae	0x5506 <generic_lsm_process_filter+0x1286>
    52de:      	movslq	(%rax), %rcx
    52e1:      	testq	%rcx, %rcx
    52e4:      	je	0x5528 <generic_lsm_process_filter+0x12a8>
    52ea:      	cmpq	%rcx, %r13
    52ed:      	jae	0x5506 <generic_lsm_process_filter+0x1286>
    52f3:      	movq	%rax, 0x8(%rsp)
    52f8:      	movq	%rcx, 0xc0(%rsp)
    5300:      	movq	%rbx, 0xb8(%rsp)
    5308:      	movl	%r13d, 0x10(%rsp)
    530d:      	movl	$0x0, 0x58(%rsp)
    5315:      	movq	(%rip), %rdi            # 0x531c <generic_lsm_process_filter+0x109c>
    531c:      	leaq	0x10(%rsp), %rsi
    5321:      	movl	$0x1, %eax
    5326:      	callq	*%rax
    5328:      	testq	%rax, %rax
    532b:      	movq	%r15, 0x38(%rsp)
    5330:      	je	0x5544 <generic_lsm_process_filter+0x12c4>
    5336:      	movq	%rax, %rbx
    5339:      	movl	(%rax), %eax
    533b:      	testl	%eax, %eax
    533d:      	je	0x5544 <generic_lsm_process_filter+0x12c4>
    5343:      	cmpl	$0x0, 0x68(%r15)
    5348:      	js	0x684b <generic_lsm_process_filter+0x25cb>
    534e:      	cmpl	$0x1b, %eax
    5351:      	ja	0x684b <generic_lsm_process_filter+0x25cb>
    5357:      	movl	$0x60, %ecx
    535c:      	btl	%eax, %ecx
    535f:      	jb	0x5fdc <generic_lsm_process_filter+0x1d5c>
    5365:      	movl	$0x4000100, %ecx        # imm = 0x4000100
    536a:      	btl	%eax, %ecx
    536d:      	jb	0x5f49 <generic_lsm_process_filter+0x1cc9>
    5373:      	movl	$0x8000200, %ecx        # imm = 0x8000200
    5378:      	btl	%eax, %ecx
    537b:      	jae	0x684b <generic_lsm_process_filter+0x25cb>
    5381:      	movq	%rbx, %rsi
    5384:      	addq	$0x4, %rsi
    5388:      	movq	(%rip), %rdi            # 0x538f <generic_lsm_process_filter+0x110f>
    538f:      	movl	$0x1, %eax
    5394:      	callq	*%rax
    5396:      	testq	%rax, %rax
    5399:      	je	0x684b <generic_lsm_process_filter+0x25cb>
    539f:      	movq	%rax, %r12
    53a2:      	movq	0x38(%rsp), %rax
    53a7:      	movl	0x68(%rax), %eax
    53aa:      	cmpl	$0x7f, %eax
    53ad:      	movl	$0x7f, %r14d
    53b3:      	cmovll	%eax, %r14d
    53b7:      	movq	(%rip), %rdi            # 0x53be <generic_lsm_process_filter+0x113e>
    53be:      	leaq	0x58(%rsp), %rsi
    53c3:      	movl	$0x1, %eax
    53c8:      	callq	*%rax
    53ca:      	testq	%rax, %rax
    53cd:      	je	0x684b <generic_lsm_process_filter+0x25cb>
    53d3:      	movq	%rax, %rbp
    53d6:      	leal	(,%r14,8), %eax
    53de:      	movl	%eax, (%rbp)
    53e1:      	movq	0x38(%rsp), %rax
    53e6:      	cmpl	$0x0, 0x6c(%rax)
    53ea:      	jne	0x54cd <generic_lsm_process_filter+0x124d>
    53f0:      	movq	0x38(%rsp), %r15
    53f5:      	movl	0x68(%r15), %ecx
    53f9:      	movl	%ecx, %eax
    53fb:      	subl	%r14d, %eax
    53fe:      	movl	%r14d, %edx
    5401:      	andl	$0x7f, %edx
    5404:      	addl	%edx, %eax
    5406:      	addl	%ecx, %edx
    5408:      	movl	%r14d, %ecx
    540b:      	notl	%ecx
    540d:      	addl	%edx, %ecx
    540f:      	subl	%r14d, %edx
    5412:      	leal	-0x4(%rdx), %esi
    5415:      	leaq	0x1f3(%r15), %rdi
    541c:      	leal	-0x3(%rdx), %r8d
    5420:      	addl	$-0x2, %edx
    5423:      	movq	$-0x3, %r9
    542a:      	leal	(%rcx,%r9), %r10d
    542e:      	addl	$0x3, %r10d
    5432:      	andl	$0x7f, %r10d
    5436:      	movzbl	0x170(%r15,%r10), %r10d
    543f:      	movb	%r10b, -0x3(%rdi)
    5443:      	leaq	(%rax,%r9), %r10
    5447:      	cmpq	$-0x2, %r10
    544b:      	je	0x54c5 <generic_lsm_process_filter+0x1245>
    544d:      	leal	(%rdx,%r9), %r11d
    5451:      	addl	$0x3, %r11d
    5455:      	andl	$0x7f, %r11d
    5459:      	movzbl	0x170(%r15,%r11), %r11d
    5462:      	movb	%r11b, -0x2(%rdi)
    5466:      	cmpq	$-0x1, %r10
    546a:      	je	0x54c5 <generic_lsm_process_filter+0x1245>
    546c:      	leal	(%r8,%r9), %r10d
    5470:      	addl	$0x3, %r10d
    5474:      	andl	$0x7f, %r10d
    5478:      	movzbl	0x170(%r15,%r10), %r10d
    5481:      	movb	%r10b, -0x1(%rdi)
    5485:      	movq	%rax, %r10
    5488:      	addq	%r9, %r10
    548b:      	je	0x54c5 <generic_lsm_process_filter+0x1245>
    548d:      	cmpq	$-0x7f, %r9
    5491:      	je	0x54c5 <generic_lsm_process_filter+0x1245>
    5493:      	leal	(%rsi,%r9), %r10d
    5497:      	addl	$0x3, %r10d
    549b:      	andl	$0x7f, %r10d
    549f:      	movzbl	0x170(%r15,%r10), %r10d
    54a8:      	movb	%r10b, (%rdi)
    54ab:      	addq	$0x4, %rdi
    54af:      	leaq	(%rax,%r9), %r10
    54b3:      	addq	$-0x4, %r10
    54b7:      	addq	$-0x4, %r9
    54bb:      	cmpq	$-0x3, %r10
    54bf:      	jne	0x542a <generic_lsm_process_filter+0x11aa>
    54c5:      	movl	$0x1, 0x6c(%r15)
    54cd:      	cmpl	$0x7f, %r14d
    54d1:      	ja	0x54f9 <generic_lsm_process_filter+0x1279>
    54d3:      	movslq	%r14d, %rsi
    54d6:      	movq	%rbp, %rdi
    54d9:      	addq	$0x4, %rdi
    54dd:      	movq	0x38(%rsp), %rax
    54e2:      	leaq	0x1f0(%rax), %rdx
    54e9:      	movl	$0x4, %eax
    54ee:      	callq	*%rax
    54f0:      	testq	%rax, %rax
    54f3:      	js	0x684b <generic_lsm_process_filter+0x25cb>
    54f9:      	movl	$0x1, %eax
    54fe:      	movq	%r12, %rdi
    5501:      	jmp	0x5fd4 <generic_lsm_process_filter+0x1d54>
    5506:      	movl	(%r15), %eax
    5509:      	movl	%eax, 0x10(%r14)
    550d:      	movq	0x8(%r15), %rax
    5511:      	movq	%rax, 0x18(%r14)
    5515:      	cmpb	$0x0, 0x5ec0(%r14)
    551d:      	jne	0x688e <generic_lsm_process_filter+0x260e>
    5523:      	jmp	0x68a3 <generic_lsm_process_filter+0x2623>
    5528:      	movb	$0x1, 0x5ec0(%r14)
    5530:      	movl	(%r15), %eax
    5533:      	movl	%eax, 0x10(%r14)
    5537:      	movq	0x8(%r15), %rax
    553b:      	movq	%rax, 0x18(%r14)
    553f:      	jmp	0x688e <generic_lsm_process_filter+0x260e>
    5544:      	movq	0x8(%rsp), %r10
    5549:      	movq	(%rip), %rax            # 0x5550 <generic_lsm_process_filter+0x12d0>
    5550:      	cmpb	$0x0, (%rax)
    5553:      	je	0x5795 <generic_lsm_process_filter+0x1515>
    5559:      	movq	(%rip), %rdi            # 0x5560 <generic_lsm_process_filter+0x12e0>
    5560:      	movl	$0x1, %eax
    5565:      	movq	0x38(%rsp), %rsi
    556a:      	callq	*%rax
    556c:      	movq	0x8(%rsp), %r10
    5571:      	testq	%rax, %rax
    5574:      	je	0x5795 <generic_lsm_process_filter+0x1515>
    557a:      	movq	%rax, %rbp
    557d:      	leal	0x5(%r13), %eax
    5581:      	movl	%eax, 0x10(%rsp)
    5585:      	movl	$0x0, 0x58(%rsp)
    558d:      	movq	(%rip), %rdi            # 0x5594 <generic_lsm_process_filter+0x1314>
    5594:      	leaq	0x10(%rsp), %rsi
    5599:      	movl	$0x1, %eax
    559e:      	callq	*%rax
    55a0:      	testq	%rax, %rax
    55a3:      	je	0x5790 <generic_lsm_process_filter+0x1510>
    55a9:      	movq	%rax, %r12
    55ac:      	movl	(%rax), %eax
    55ae:      	testl	%eax, %eax
    55b0:      	je	0x5790 <generic_lsm_process_filter+0x1510>
    55b6:      	cmpl	$0x0, (%rbp)
    55ba:      	js	0x684b <generic_lsm_process_filter+0x25cb>
    55c0:      	cmpl	$0x1b, %eax
    55c3:      	ja	0x684b <generic_lsm_process_filter+0x25cb>
    55c9:      	movl	$0x60, %ecx
    55ce:      	btl	%eax, %ecx
    55d1:      	jb	0x6238 <generic_lsm_process_filter+0x1fb8>
    55d7:      	movl	$0x4000100, %ecx        # imm = 0x4000100
    55dc:      	btl	%eax, %ecx
    55df:      	jb	0x61a8 <generic_lsm_process_filter+0x1f28>
    55e5:      	movl	$0x8000200, %ecx        # imm = 0x8000200
    55ea:      	btl	%eax, %ecx
    55ed:      	jae	0x684b <generic_lsm_process_filter+0x25cb>
    55f3:      	movq	%r12, %rsi
    55f6:      	addq	$0x4, %rsi
    55fa:      	movq	(%rip), %rdi            # 0x5601 <generic_lsm_process_filter+0x1381>
    5601:      	movl	$0x1, %eax
    5606:      	callq	*%rax
    5608:      	testq	%rax, %rax
    560b:      	je	0x684b <generic_lsm_process_filter+0x25cb>
    5611:      	movq	%rax, %r15
    5614:      	movl	(%rbp), %eax
    5617:      	cmpl	$0x7f, %eax
    561a:      	movl	$0x7f, %r14d
    5620:      	cmovll	%eax, %r14d
    5624:      	movq	(%rip), %rdi            # 0x562b <generic_lsm_process_filter+0x13ab>
    562b:      	leaq	0x58(%rsp), %rsi
    5630:      	movl	$0x1, %eax
    5635:      	callq	*%rax
    5637:      	testq	%rax, %rax
    563a:      	je	0x684b <generic_lsm_process_filter+0x25cb>
    5640:      	movq	%rax, %rbx
    5643:      	leal	(,%r14,8), %eax
    564b:      	movl	%eax, (%rbx)
    564d:      	cmpl	$0x0, 0x4(%rbp)
    5651:      	jne	0x572d <generic_lsm_process_filter+0x14ad>
    5657:      	movl	(%rbp), %ecx
    565a:      	movl	%ecx, %eax
    565c:      	subl	%r14d, %eax
    565f:      	movl	%r14d, %edx
    5662:      	andl	$0x7f, %edx
    5665:      	addl	%edx, %eax
    5667:      	addl	%ecx, %edx
    5669:      	movl	%r14d, %ecx
    566c:      	notl	%ecx
    566e:      	addl	%edx, %ecx
    5670:      	subl	%r14d, %edx
    5673:      	leal	-0x4(%rdx), %esi
    5676:      	leaq	0x18b(%rbp), %rdi
    567d:      	leal	-0x3(%rdx), %r8d
    5681:      	addl	$-0x2, %edx
    5684:      	movq	$-0x3, %r9
    568b:      	leal	(%rcx,%r9), %r10d
    568f:      	addl	$0x3, %r10d
    5693:      	andl	$0x7f, %r10d
    5697:      	movzbl	0x108(%rbp,%r10), %r10d
    56a0:      	movb	%r10b, -0x3(%rdi)
    56a4:      	leaq	(%rax,%r9), %r10
    56a8:      	cmpq	$-0x2, %r10
    56ac:      	je	0x5726 <generic_lsm_process_filter+0x14a6>
    56ae:      	leal	(%rdx,%r9), %r11d
    56b2:      	addl	$0x3, %r11d
    56b6:      	andl	$0x7f, %r11d
    56ba:      	movzbl	0x108(%rbp,%r11), %r11d
    56c3:      	movb	%r11b, -0x2(%rdi)
    56c7:      	cmpq	$-0x1, %r10
    56cb:      	je	0x5726 <generic_lsm_process_filter+0x14a6>
    56cd:      	leal	(%r8,%r9), %r10d
    56d1:      	addl	$0x3, %r10d
    56d5:      	andl	$0x7f, %r10d
    56d9:      	movzbl	0x108(%rbp,%r10), %r10d
    56e2:      	movb	%r10b, -0x1(%rdi)
    56e6:      	movq	%rax, %r10
    56e9:      	addq	%r9, %r10
    56ec:      	je	0x5726 <generic_lsm_process_filter+0x14a6>
    56ee:      	cmpq	$-0x7f, %r9
    56f2:      	je	0x5726 <generic_lsm_process_filter+0x14a6>
    56f4:      	leal	(%rsi,%r9), %r10d
    56f8:      	addl	$0x3, %r10d
    56fc:      	andl	$0x7f, %r10d
    5700:      	movzbl	0x108(%rbp,%r10), %r10d
    5709:      	movb	%r10b, (%rdi)
    570c:      	addq	$0x4, %rdi
    5710:      	leaq	(%rax,%r9), %r10
    5714:      	addq	$-0x4, %r10
    5718:      	addq	$-0x4, %r9
    571c:      	cmpq	$-0x3, %r10
    5720:      	jne	0x568b <generic_lsm_process_filter+0x140b>
    5726:      	movl	$0x1, 0x4(%rbp)
    572d:      	cmpl	$0x7f, %r14d
    5731:      	ja	0x5757 <generic_lsm_process_filter+0x14d7>
    5733:      	movslq	%r14d, %rsi
    5736:      	movq	%rbx, %rdi
    5739:      	addq	$0x4, %rdi
    573d:      	addq	$0x188, %rbp            # imm = 0x188
    5744:      	movl	$0x4, %eax
    5749:      	movq	%rbp, %rdx
    574c:      	callq	*%rax
    574e:      	testq	%rax, %rax
    5751:      	js	0x684b <generic_lsm_process_filter+0x25cb>
    5757:      	movl	$0x1, %eax
    575c:      	movq	%r15, %rdi
    575f:      	jmp	0x6230 <generic_lsm_process_filter+0x1fb0>
    5764:      	movq	%r12, %r13
    5767:      	addq	$0xff6, %r13            # imm = 0xFF6
    576e:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
    5778:      	movq	%rax, 0xff6(%r12)
    5780:      	movw	$0x2964, 0xffe(%r12)    # imm = 0x2964
    578b:      	jmp	0x4ac3 <generic_lsm_process_filter+0x843>
    5790:      	movq	0x8(%rsp), %r10
    5795:      	movl	%r13d, %eax
    5798:      	leaq	0x4(,%rax,4), %rcx
    57a0:      	movl	0x4(%r10,%rax,4), %eax
    57a5:      	leal	(%rax,%rcx), %r14d
    57a9:      	andl	$0x3ff, %r14d           # imm = 0x3FF
    57b0:      	addl	%eax, %ecx
    57b2:      	addl	$0x4, %ecx
    57b5:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    57bb:      	leaq	0x8(%r14), %rbp
    57bf:      	cmpl	$0x5, (%rcx,%r10)
    57c4:      	jb	0x5cee <generic_lsm_process_filter+0x1a6e>
    57ca:      	movl	(%rbp,%r10), %r12d
    57cf:      	movl	0x4(%rbp,%r10), %edi
    57d4:      	movl	0x8(%rbp,%r10), %edx
    57d9:      	movq	$0x0, 0x68(%rsp)
    57e2:      	movq	$0x0, 0x60(%rsp)
    57eb:      	cmpl	$0x4, %edx
    57ee:      	movl	$0x4, %ecx
    57f3:      	cmovbl	%edx, %ecx
    57f6:      	cmpl	$0x6, %r12d
    57fa:      	jne	0x5810 <generic_lsm_process_filter+0x1590>
    57fc:      	movabsq	$0x100000001, %rsi      # imm = 0x100000001
    5806:      	movq	%rsi, 0x60(%rsp)
    580b:      	movq	%rsi, 0x68(%rsp)
    5810:      	testl	%edx, %edx
    5812:      	je	0x5cf5 <generic_lsm_process_filter+0x1a75>
    5818:      	movq	0x38(%rsp), %rdx
    581d:      	leaq	0x24(%rdx), %rsi
    5821:      	testb	$0x1, %dil
    5825:      	movq	%rsi, 0xb0(%rsp)
    582d:      	movq	%rsi, %r8
    5830:      	cmoveq	%rdx, %r8
    5834:      	addq	$0x10, %rdx
    5838:      	movq	%rdx, 0xd0(%rsp)
    5840:      	leal	(%rax,%r13,4), %r9d
    5844:      	addl	$0x4, %r9d
    5848:      	andl	$0x3ff, %r9d            # imm = 0x3FF
    584f:      	addq	$0x14, %r9
    5853:      	decq	%rcx
    5856:      	cmpq	$0x3, %rcx
    585a:      	movl	$0x3, %eax
    585f:      	cmovbq	%rcx, %rax
    5863:      	movl	%eax, %eax
    5865:      	leaq	0x4(,%rax,4), %r11
    586d:      	xorl	%r13d, %r13d
    5870:      	movq	%rdi, 0x30(%rsp)
    5875:      	movq	%r8, 0x28(%rsp)
    587a:      	movq	%r9, 0x20(%rsp)
    587f:      	movq	%r11, 0x18(%rsp)
    5884:      	jmp	0x58c0 <generic_lsm_process_filter+0x1640>
    5886:      	movq	0x8(%rsp), %r10
    588b:      	movq	0x30(%rsp), %rdi
    5890:      	movq	0x28(%rsp), %r8
    5895:      	movq	0x20(%rsp), %r9
    589a:      	movq	0x18(%rsp), %r11
    589f:      	cmpl	$0x6, %r12d
    58a3:      	setne	%al
    58a6:      	xorb	$0x1, %bl
    58a9:      	orb	%al, %bl
    58ab:      	movzbl	%bl, %eax
    58ae:      	movl	%eax, 0x60(%rsp,%r13)
    58b3:      	addq	$0x4, %r13
    58b7:      	cmpq	%r13, %r11
    58ba:      	je	0x5cf5 <generic_lsm_process_filter+0x1a75>
    58c0:      	leaq	(%r9,%r13), %rax
    58c4:      	movl	(%r8), %ecx
    58c7:      	cmpq	$0x3e8, %rax            # imm = 0x3E8
    58cd:      	jbe	0x5ada <generic_lsm_process_filter+0x185a>
    58d3:      	xorl	%r15d, %r15d
    58d6:      	testb	$0x2, %dil
    58da:      	je	0x5af7 <generic_lsm_process_filter+0x1877>
    58e0:      	testb	$0x1, %dil
    58e4:      	jne	0x5b18 <generic_lsm_process_filter+0x1898>
    58ea:      	movq	0x38(%rsp), %rcx
    58ef:      	movl	(%rcx), %eax
    58f1:      	movb	$0x1, %bl
    58f3:      	cmpq	%rax, %r15
    58f6:      	je	0x589f <generic_lsm_process_filter+0x161f>
    58f8:      	movl	0x10(%rcx), %eax
    58fb:      	cmpq	%rax, %r15
    58fe:      	je	0x589f <generic_lsm_process_filter+0x161f>
    5900:      	movl	$0x1, %eax
    5905:      	movq	0xd0(%rsp), %rsi
    590d:      	movq	(%rip), %rdi            # 0x5914 <generic_lsm_process_filter+0x1694>
    5914:      	callq	*%rax
    5916:      	testq	%rax, %rax
    5919:      	je	0x5cbd <generic_lsm_process_filter+0x1a3d>
    591f:      	movq	%rax, %rsi
    5922:      	movl	(%rax), %eax
    5924:      	cmpq	%rax, %r15
    5927:      	je	0x5886 <generic_lsm_process_filter+0x1606>
    592d:      	movl	0x10(%rsi), %eax
    5930:      	cmpq	%rax, %r15
    5933:      	je	0x5886 <generic_lsm_process_filter+0x1606>
    5939:      	addq	$0x10, %rsi
    593d:      	movl	$0x1, %eax
    5942:      	movq	(%rip), %rdi            # 0x5949 <generic_lsm_process_filter+0x16c9>
    5949:      	callq	*%rax
    594b:      	testq	%rax, %rax
    594e:      	je	0x5cbd <generic_lsm_process_filter+0x1a3d>
    5954:      	movq	%rax, %rsi
    5957:      	movl	(%rax), %eax
    5959:      	cmpq	%rax, %r15
    595c:      	je	0x5886 <generic_lsm_process_filter+0x1606>
    5962:      	movl	0x10(%rsi), %eax
    5965:      	cmpq	%rax, %r15
    5968:      	je	0x5886 <generic_lsm_process_filter+0x1606>
    596e:      	addq	$0x10, %rsi
    5972:      	movl	$0x1, %eax
    5977:      	movq	(%rip), %rdi            # 0x597e <generic_lsm_process_filter+0x16fe>
    597e:      	callq	*%rax
    5980:      	testq	%rax, %rax
    5983:      	je	0x5cbd <generic_lsm_process_filter+0x1a3d>
    5989:      	movq	%rax, %rsi
    598c:      	movl	(%rax), %eax
    598e:      	cmpq	%rax, %r15
    5991:      	je	0x5886 <generic_lsm_process_filter+0x1606>
    5997:      	movl	0x10(%rsi), %eax
    599a:      	cmpq	%rax, %r15
    599d:      	je	0x5886 <generic_lsm_process_filter+0x1606>
    59a3:      	addq	$0x10, %rsi
    59a7:      	movl	$0x1, %eax
    59ac:      	movq	(%rip), %rdi            # 0x59b3 <generic_lsm_process_filter+0x1733>
    59b3:      	callq	*%rax
    59b5:      	testq	%rax, %rax
    59b8:      	je	0x5cbd <generic_lsm_process_filter+0x1a3d>
    59be:      	movq	%rax, %rsi
    59c1:      	movl	(%rax), %eax
    59c3:      	cmpq	%rax, %r15
    59c6:      	je	0x5886 <generic_lsm_process_filter+0x1606>
    59cc:      	movl	0x10(%rsi), %eax
    59cf:      	cmpq	%rax, %r15
    59d2:      	je	0x5886 <generic_lsm_process_filter+0x1606>
    59d8:      	addq	$0x10, %rsi
    59dc:      	movl	$0x1, %eax
    59e1:      	movq	(%rip), %rdi            # 0x59e8 <generic_lsm_process_filter+0x1768>
    59e8:      	callq	*%rax
    59ea:      	testq	%rax, %rax
    59ed:      	je	0x5cbd <generic_lsm_process_filter+0x1a3d>
    59f3:      	movq	%rax, %rsi
    59f6:      	movl	(%rax), %eax
    59f8:      	cmpq	%rax, %r15
    59fb:      	je	0x5886 <generic_lsm_process_filter+0x1606>
    5a01:      	movl	0x10(%rsi), %eax
    5a04:      	cmpq	%rax, %r15
    5a07:      	je	0x5886 <generic_lsm_process_filter+0x1606>
    5a0d:      	addq	$0x10, %rsi
    5a11:      	movl	$0x1, %eax
    5a16:      	movq	(%rip), %rdi            # 0x5a1d <generic_lsm_process_filter+0x179d>
    5a1d:      	callq	*%rax
    5a1f:      	testq	%rax, %rax
    5a22:      	je	0x5cbd <generic_lsm_process_filter+0x1a3d>
    5a28:      	movq	%rax, %rsi
    5a2b:      	movl	(%rax), %eax
    5a2d:      	cmpq	%rax, %r15
    5a30:      	je	0x5886 <generic_lsm_process_filter+0x1606>
    5a36:      	movl	0x10(%rsi), %eax
    5a39:      	cmpq	%rax, %r15
    5a3c:      	je	0x5886 <generic_lsm_process_filter+0x1606>
    5a42:      	addq	$0x10, %rsi
    5a46:      	movl	$0x1, %eax
    5a4b:      	movq	(%rip), %rdi            # 0x5a52 <generic_lsm_process_filter+0x17d2>
    5a52:      	callq	*%rax
    5a54:      	testq	%rax, %rax
    5a57:      	je	0x5cbd <generic_lsm_process_filter+0x1a3d>
    5a5d:      	movq	%rax, %rsi
    5a60:      	movl	(%rax), %eax
    5a62:      	cmpq	%rax, %r15
    5a65:      	je	0x5886 <generic_lsm_process_filter+0x1606>
    5a6b:      	movl	0x10(%rsi), %eax
    5a6e:      	cmpq	%rax, %r15
    5a71:      	je	0x5886 <generic_lsm_process_filter+0x1606>
    5a77:      	addq	$0x10, %rsi
    5a7b:      	movl	$0x1, %eax
    5a80:      	movq	(%rip), %rdi            # 0x5a87 <generic_lsm_process_filter+0x1807>
    5a87:      	callq	*%rax
    5a89:      	testq	%rax, %rax
    5a8c:      	je	0x5cbd <generic_lsm_process_filter+0x1a3d>
    5a92:      	movq	%rax, %rsi
    5a95:      	movl	(%rax), %eax
    5a97:      	cmpq	%rax, %r15
    5a9a:      	je	0x5886 <generic_lsm_process_filter+0x1606>
    5aa0:      	movl	0x10(%rsi), %eax
    5aa3:      	cmpq	%rax, %r15
    5aa6:      	movq	0x8(%rsp), %r10
    5aab:      	movq	0x30(%rsp), %rdi
    5ab0:      	movq	0x28(%rsp), %r8
    5ab5:      	movq	0x20(%rsp), %r9
    5aba:      	movq	0x18(%rsp), %r11
    5abf:      	je	0x589f <generic_lsm_process_filter+0x161f>
    5ac5:      	addq	$0x10, %rsi
    5ac9:      	movl	$0x1, %eax
    5ace:      	movq	(%rip), %rcx            # 0x5ad5 <generic_lsm_process_filter+0x1855>
    5ad5:      	jmp	0x5cb4 <generic_lsm_process_filter+0x1a34>
    5ada:      	movl	$0x4, %esi
    5adf:      	xorl	%edx, %edx
    5ae1:      	divq	%rsi
    5ae4:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5ae9:      	movl	(%r10,%rax,4), %r15d
    5aed:      	testb	$0x2, %dil
    5af1:      	jne	0x58e0 <generic_lsm_process_filter+0x1660>
    5af7:      	cmpl	$0x5, %r12d
    5afb:      	jne	0x5b06 <generic_lsm_process_filter+0x1886>
    5afd:      	cmpq	%rcx, %r15
    5b00:      	jne	0x5ce7 <generic_lsm_process_filter+0x1a67>
    5b06:      	cmpq	%rcx, %r15
    5b09:      	setne	%al
    5b0c:      	cmpl	$0x6, %r12d
    5b10:      	setne	%bl
    5b13:      	jmp	0x58a9 <generic_lsm_process_filter+0x1629>
    5b18:      	movq	0xb0(%rsp), %rax
    5b20:      	movl	(%rax), %eax
    5b22:      	testq	%rax, %rax
    5b25:      	je	0x5ce7 <generic_lsm_process_filter+0x1a67>
    5b2b:      	movb	$0x1, %bl
    5b2d:      	testq	%r15, %r15
    5b30:      	je	0x589f <generic_lsm_process_filter+0x161f>
    5b36:      	cmpq	%rax, %r15
    5b39:      	je	0x589f <generic_lsm_process_filter+0x161f>
    5b3f:      	movl	$0x1, %eax
    5b44:      	movq	0xd0(%rsp), %rsi
    5b4c:      	movq	(%rip), %rdi            # 0x5b53 <generic_lsm_process_filter+0x18d3>
    5b53:      	callq	*%rax
    5b55:      	testq	%rax, %rax
    5b58:      	je	0x5cbd <generic_lsm_process_filter+0x1a3d>
    5b5e:      	movq	%rax, %rsi
    5b61:      	movl	0x24(%rax), %eax
    5b64:      	cmpq	%rax, %r15
    5b67:      	je	0x5886 <generic_lsm_process_filter+0x1606>
    5b6d:      	addq	$0x10, %rsi
    5b71:      	movl	$0x1, %eax
    5b76:      	movq	(%rip), %rdi            # 0x5b7d <generic_lsm_process_filter+0x18fd>
    5b7d:      	callq	*%rax
    5b7f:      	testq	%rax, %rax
    5b82:      	je	0x5cbd <generic_lsm_process_filter+0x1a3d>
    5b88:      	movq	%rax, %rsi
    5b8b:      	movl	0x24(%rax), %eax
    5b8e:      	cmpq	%rax, %r15
    5b91:      	je	0x5886 <generic_lsm_process_filter+0x1606>
    5b97:      	addq	$0x10, %rsi
    5b9b:      	movl	$0x1, %eax
    5ba0:      	movq	(%rip), %rdi            # 0x5ba7 <generic_lsm_process_filter+0x1927>
    5ba7:      	callq	*%rax
    5ba9:      	testq	%rax, %rax
    5bac:      	je	0x5cbd <generic_lsm_process_filter+0x1a3d>
    5bb2:      	movq	%rax, %rsi
    5bb5:      	movl	0x24(%rax), %eax
    5bb8:      	cmpq	%rax, %r15
    5bbb:      	je	0x5886 <generic_lsm_process_filter+0x1606>
    5bc1:      	addq	$0x10, %rsi
    5bc5:      	movl	$0x1, %eax
    5bca:      	movq	(%rip), %rdi            # 0x5bd1 <generic_lsm_process_filter+0x1951>
    5bd1:      	callq	*%rax
    5bd3:      	testq	%rax, %rax
    5bd6:      	je	0x5cbd <generic_lsm_process_filter+0x1a3d>
    5bdc:      	movq	%rax, %rsi
    5bdf:      	movl	0x24(%rax), %eax
    5be2:      	cmpq	%rax, %r15
    5be5:      	je	0x5886 <generic_lsm_process_filter+0x1606>
    5beb:      	addq	$0x10, %rsi
    5bef:      	movl	$0x1, %eax
    5bf4:      	movq	(%rip), %rdi            # 0x5bfb <generic_lsm_process_filter+0x197b>
    5bfb:      	callq	*%rax
    5bfd:      	testq	%rax, %rax
    5c00:      	je	0x5cbd <generic_lsm_process_filter+0x1a3d>
    5c06:      	movq	%rax, %rsi
    5c09:      	movl	0x24(%rax), %eax
    5c0c:      	cmpq	%rax, %r15
    5c0f:      	je	0x5886 <generic_lsm_process_filter+0x1606>
    5c15:      	addq	$0x10, %rsi
    5c19:      	movl	$0x1, %eax
    5c1e:      	movq	(%rip), %rdi            # 0x5c25 <generic_lsm_process_filter+0x19a5>
    5c25:      	callq	*%rax
    5c27:      	testq	%rax, %rax
    5c2a:      	je	0x5cbd <generic_lsm_process_filter+0x1a3d>
    5c30:      	movq	%rax, %rsi
    5c33:      	movl	0x24(%rax), %eax
    5c36:      	cmpq	%rax, %r15
    5c39:      	je	0x5886 <generic_lsm_process_filter+0x1606>
    5c3f:      	addq	$0x10, %rsi
    5c43:      	movl	$0x1, %eax
    5c48:      	movq	(%rip), %rdi            # 0x5c4f <generic_lsm_process_filter+0x19cf>
    5c4f:      	callq	*%rax
    5c51:      	testq	%rax, %rax
    5c54:      	je	0x5cbd <generic_lsm_process_filter+0x1a3d>
    5c56:      	movq	%rax, %rsi
    5c59:      	movl	0x24(%rax), %eax
    5c5c:      	cmpq	%rax, %r15
    5c5f:      	je	0x5886 <generic_lsm_process_filter+0x1606>
    5c65:      	addq	$0x10, %rsi
    5c69:      	movl	$0x1, %eax
    5c6e:      	movq	(%rip), %rdi            # 0x5c75 <generic_lsm_process_filter+0x19f5>
    5c75:      	callq	*%rax
    5c77:      	testq	%rax, %rax
    5c7a:      	je	0x5cbd <generic_lsm_process_filter+0x1a3d>
    5c7c:      	movq	%rax, %rsi
    5c7f:      	movl	0x24(%rax), %eax
    5c82:      	cmpq	%rax, %r15
    5c85:      	movq	0x8(%rsp), %r10
    5c8a:      	movq	0x30(%rsp), %rdi
    5c8f:      	movq	0x28(%rsp), %r8
    5c94:      	movq	0x20(%rsp), %r9
    5c99:      	movq	0x18(%rsp), %r11
    5c9e:      	je	0x589f <generic_lsm_process_filter+0x161f>
    5ca4:      	addq	$0x10, %rsi
    5ca8:      	movl	$0x1, %eax
    5cad:      	movq	(%rip), %rcx            # 0x5cb4 <generic_lsm_process_filter+0x1a34>
    5cb4:      	movq	(%rip), %rdi            # 0x5cbb <generic_lsm_process_filter+0x1a3b>
    5cbb:      	callq	*%rax
    5cbd:      	xorl	%ebx, %ebx
    5cbf:      	cmpl	$0x5, %r12d
    5cc3:      	movq	0x8(%rsp), %r10
    5cc8:      	movq	0x30(%rsp), %rdi
    5ccd:      	movq	0x28(%rsp), %r8
    5cd2:      	movq	0x20(%rsp), %r9
    5cd7:      	movq	0x18(%rsp), %r11
    5cdc:      	jne	0x589f <generic_lsm_process_filter+0x161f>
    5ce2:      	jmp	0x58ab <generic_lsm_process_filter+0x162b>
    5ce7:      	xorl	%ebx, %ebx
    5ce9:      	jmp	0x58ab <generic_lsm_process_filter+0x162b>
    5cee:      	movl	$0x1, %eax
    5cf3:      	jmp	0x5d31 <generic_lsm_process_filter+0x1ab1>
    5cf5:      	movl	0x60(%rsp), %esi
    5cf9:      	movl	0x64(%rsp), %ecx
    5cfd:      	movl	0x68(%rsp), %eax
    5d01:      	movl	0x6c(%rsp), %edx
    5d05:      	cmpl	$0x6, %r12d
    5d09:      	jne	0x5d13 <generic_lsm_process_filter+0x1a93>
    5d0b:      	andl	%esi, %ecx
    5d0d:      	andl	%edx, %eax
    5d0f:      	andl	%ecx, %eax
    5d11:      	jmp	0x5d19 <generic_lsm_process_filter+0x1a99>
    5d13:      	orl	%esi, %ecx
    5d15:      	orl	%edx, %eax
    5d17:      	orl	%ecx, %eax
    5d19:      	testl	%eax, %eax
    5d1b:      	je	0x684b <generic_lsm_process_filter+0x25cb>
    5d21:      	addl	$0x14, %r14d
    5d25:      	movl	0x8(%r10,%rbp), %ecx
    5d2a:      	andl	$0x7, %ecx
    5d2d:      	leal	(%r14,%rcx,4), %ebp
    5d31:      	movq	0x50(%rsp), %r9
    5d36:      	movl	%ebp, %ecx
    5d38:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5d3e:      	movl	(%rcx,%r10), %ecx
    5d42:      	addl	$0x4, %ebp
    5d45:      	addl	$-0x4, %ecx
    5d48:      	xorl	%esi, %esi
    5d4a:      	movl	$0x4, %r8d
    5d50:      	jmp	0x5d6f <generic_lsm_process_filter+0x1aef>
    5d52:      	nopw	%cs:(%rax,%rax)
    5d60:      	xorl	%ecx, %ecx
    5d62:      	incq	%rsi
    5d65:      	cmpq	$0xa, %rsi
    5d69:      	je	0x5ef8 <generic_lsm_process_filter+0x1c78>
    5d6f:      	testl	%ecx, %ecx
    5d71:      	je	0x5d60 <generic_lsm_process_filter+0x1ae0>
    5d73:      	movl	%ebp, %r9d
    5d76:      	andl	$0x3ff, %r9d            # imm = 0x3FF
    5d7d:      	movl	(%r9,%r10), %r11d
    5d81:      	movq	%r10, %rax
    5d84:      	movl	0x4(%r9,%r10), %r10d
    5d89:      	movl	0x8(%r9,%rax), %edx
    5d8e:      	movq	$0x0, 0x68(%rsp)
    5d97:      	movq	$0x0, 0x60(%rsp)
    5da0:      	cmpl	$0x4, %edx
    5da3:      	movl	$0x4, %eax
    5da8:      	cmovbl	%edx, %eax
    5dab:      	cmpl	$0x6, %r10d
    5daf:      	jne	0x5dc5 <generic_lsm_process_filter+0x1b45>
    5db1:      	movabsq	$0x100000001, %rdi      # imm = 0x100000001
    5dbb:      	movq	%rdi, 0x60(%rsp)
    5dc0:      	movq	%rdi, 0x68(%rsp)
    5dc5:      	addl	$0xc, %ebp
    5dc8:      	testl	%edx, %edx
    5dca:      	je	0x5ea0 <generic_lsm_process_filter+0x1c20>
    5dd0:      	andl	$0xf, %r11d
    5dd4:      	decq	%rax
    5dd7:      	cmpq	$0x3, %rax
    5ddb:      	movl	$0x3, %edx
    5de0:      	cmovaeq	%rdx, %rax
    5de4:      	leaq	0x4(,%rax,4), %rbx
    5dec:      	movl	%ebp, %r14d
    5def:      	cmpl	$0x9, %r11d
    5df3:      	jbe	0x5e2a <generic_lsm_process_filter+0x1baa>
    5df5:      	xorl	%r11d, %r11d
    5df8:      	jmp	0x5e16 <generic_lsm_process_filter+0x1b96>
    5dfa:      	nopw	(%rax,%rax)
    5e00:      	movl	$0x0, 0x60(%rsp,%r11)
    5e09:      	addq	$0x4, %r11
    5e0d:      	cmpq	%r11, %rbx
    5e10:      	je	0x5ea0 <generic_lsm_process_filter+0x1c20>
    5e16:      	leaq	(%r14,%r11), %rax
    5e1a:      	cmpl	$0x3e8, %eax            # imm = 0x3E8
    5e1f:      	ja	0x5e00 <generic_lsm_process_filter+0x1b80>
    5e21:      	movl	%eax, %eax
    5e23:      	xorl	%edx, %edx
    5e25:      	divq	%r8
    5e28:      	jmp	0x5e00 <generic_lsm_process_filter+0x1b80>
    5e2a:      	xorl	%r15d, %r15d
    5e2d:      	jmp	0x5e71 <generic_lsm_process_filter+0x1bf1>
    5e2f:      	nop
    5e30:      	cmpl	$0x5, %r10d
    5e34:      	setne	%dl
    5e37:      	movl	%r10d, %r13d
    5e3a:      	xorl	$0x6, %r13d
    5e3e:      	movq	0x50(%rsp), %rax
    5e43:      	movl	0x20(%rax,%r11,4), %edi
    5e48:      	movl	%r12d, %eax
    5e4b:      	xorl	%edi, %eax
    5e4d:      	cmpl	%edi, %r12d
    5e50:      	sete	%dil
    5e54:      	orb	%dl, %dil
    5e57:      	orl	%r13d, %eax
    5e5a:      	setne	%al
    5e5d:      	andb	%dil, %al
    5e60:      	movzbl	%al, %eax
    5e63:      	movl	%eax, 0x60(%rsp,%r15)
    5e68:      	addq	$0x4, %r15
    5e6c:      	cmpq	%r15, %rbx
    5e6f:      	je	0x5ea0 <generic_lsm_process_filter+0x1c20>
    5e71:      	leaq	(%r14,%r15), %rdx
    5e75:      	xorl	%r12d, %r12d
    5e78:      	cmpl	$0x3e8, %edx            # imm = 0x3E8
    5e7e:      	ja	0x5e30 <generic_lsm_process_filter+0x1bb0>
    5e80:      	movl	%edx, %eax
    5e82:      	xorl	%edx, %edx
    5e84:      	divq	%r8
    5e87:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5e8c:      	movq	0x8(%rsp), %rdx
    5e91:      	movl	(%rdx,%rax,4), %r12d
    5e95:      	jmp	0x5e30 <generic_lsm_process_filter+0x1bb0>
    5e97:      	nopw	(%rax,%rax)
    5ea0:      	movl	0x60(%rsp), %ebx
    5ea4:      	movl	0x64(%rsp), %edx
    5ea8:      	movl	0x68(%rsp), %eax
    5eac:      	movl	0x6c(%rsp), %r11d
    5eb1:      	cmpl	$0x6, %r10d
    5eb5:      	jne	0x5ec0 <generic_lsm_process_filter+0x1c40>
    5eb7:      	andl	%ebx, %edx
    5eb9:      	andl	%r11d, %eax
    5ebc:      	andl	%edx, %eax
    5ebe:      	jmp	0x5ec7 <generic_lsm_process_filter+0x1c47>
    5ec0:      	orl	%ebx, %edx
    5ec2:      	orl	%r11d, %eax
    5ec5:      	orl	%edx, %eax
    5ec7:      	movq	0x8(%rsp), %r10
    5ecc:      	testl	%eax, %eax
    5ece:      	je	0x684b <generic_lsm_process_filter+0x25cb>
    5ed4:      	movl	0x8(%r10,%r9), %edx
    5ed9:      	shll	$0x2, %edx
    5edc:      	subl	%edx, %ecx
    5ede:      	andl	$0x1c, %edx
    5ee1:      	addl	%edx, %ebp
    5ee3:      	addl	$-0xc, %ecx
    5ee6:      	movq	0x50(%rsp), %r9
    5eeb:      	incq	%rsi
    5eee:      	cmpq	$0xa, %rsi
    5ef2:      	jne	0x5d6f <generic_lsm_process_filter+0x1aef>
    5ef8:      	movl	%ebp, %ecx
    5efa:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5f00:      	leal	0x4(%rbp), %ebx
    5f03:      	cmpl	$0x4, (%rcx,%r10)
    5f08:      	je	0x60d8 <generic_lsm_process_filter+0x1e58>
    5f0e:      	andl	$0x3ff, %ebx            # imm = 0x3FF
    5f14:      	movl	(%rbx,%r10), %ecx
    5f18:      	movl	0x4(%rbx,%r10), %edx
    5f1d:      	movl	0x8(%rbx,%r10), %edi
    5f22:      	movq	0xc(%rbx,%r10), %rax
    5f27:      	testl	%edi, %edi
    5f29:      	je	0x60ac <generic_lsm_process_filter+0x1e2c>
    5f2f:      	xorl	%esi, %esi
    5f31:      	cmpl	$0x2, %ecx
    5f34:      	ja	0x60cf <generic_lsm_process_filter+0x1e4f>
    5f3a:      	cmpl	%edi, 0x44(%r9)
    5f3e:      	jne	0x60b5 <generic_lsm_process_filter+0x1e35>
    5f44:      	jmp	0x60cf <generic_lsm_process_filter+0x1e4f>
    5f49:      	movq	%rbx, %rsi
    5f4c:      	addq	$0x4, %rsi
    5f50:      	movq	(%rip), %rdi            # 0x5f57 <generic_lsm_process_filter+0x1cd7>
    5f57:      	movl	$0x1, %eax
    5f5c:      	callq	*%rax
    5f5e:      	testq	%rax, %rax
    5f61:      	je	0x684b <generic_lsm_process_filter+0x25cb>
    5f67:      	movq	%rax, %r14
    5f6a:      	movq	(%rip), %rdi            # 0x5f71 <generic_lsm_process_filter+0x1cf1>
    5f71:      	leaq	0x58(%rsp), %rsi
    5f76:      	movl	$0x1, %eax
    5f7b:      	callq	*%rax
    5f7d:      	testq	%rax, %rax
    5f80:      	je	0x684b <generic_lsm_process_filter+0x25cb>
    5f86:      	movq	%rax, %rbp
    5f89:      	movl	$0x104, %edx            # imm = 0x104
    5f8e:      	movq	%rax, %rdi
    5f91:      	xorl	%esi, %esi
    5f93:      	callq	0x5f98 <generic_lsm_process_filter+0x1d18>
    5f98:      	movq	0x38(%rsp), %rsi
    5f9d:      	movl	0x68(%rsi), %eax
    5fa0:      	leal	(,%rax,8), %ecx
    5fa7:      	movl	%ecx, (%rbp)
    5faa:      	movq	%rbp, %rdi
    5fad:      	addq	$0x4, %rdi
    5fb1:      	movzbl	%al, %ecx
    5fb4:      	leaq	0x70(%rsi), %rdx
    5fb8:      	movl	$0x4, %eax
    5fbd:      	movzbl	0x68(%rsi), %esi
    5fc1:      	callq	*%rax
    5fc3:      	testq	%rax, %rax
    5fc6:      	js	0x684b <generic_lsm_process_filter+0x25cb>
    5fcc:      	movl	$0x1, %eax
    5fd1:      	movq	%r14, %rdi
    5fd4:      	movq	%rbp, %rsi
    5fd7:      	jmp	0x63d7 <generic_lsm_process_filter+0x2157>
    5fdc:      	movl	$0x0, 0x40(%rsp)
    5fe4:      	movq	(%rip), %rdi            # 0x5feb <generic_lsm_process_filter+0x1d6b>
    5feb:      	leaq	0x40(%rsp), %rsi
    5ff0:      	movl	$0x1, %eax
    5ff5:      	callq	*%rax
    5ff7:      	testq	%rax, %rax
    5ffa:      	movq	0x38(%rsp), %rdx
    5fff:      	je	0x6384 <generic_lsm_process_filter+0x2104>
    6005:      	movq	(%rax), %rcx
    6008:      	cmpq	0x378(%rdx), %rcx
    600f:      	je	0x6384 <generic_lsm_process_filter+0x2104>
    6015:      	movq	%rax, 0xb0(%rsp)
    601d:      	movq	(%rip), %rax            # 0x6024 <generic_lsm_process_filter+0x1da4>
    6024:      	cmpb	$0x0, (%rax)
    6027:      	je	0x62fb <generic_lsm_process_filter+0x207b>
    602d:      	movl	$0x1869f, %r15d         # imm = 0x1869F
    6033:      	xorl	%r14d, %r14d
    6036:      	movq	(%rip), %r12            # 0x603d <generic_lsm_process_filter+0x1dbd>
    603d:      	movq	0x38(%rsp), %rax
    6042:      	movl	0x10(%rax), %eax
    6045:      	movl	%eax, 0x60(%rsp)
    6049:      	movl	$0x1, %eax
    604e:      	leaq	0x60(%rsp), %rsi
    6053:      	movq	%r12, %rdi
    6056:      	callq	*%rax
    6058:      	testq	%rax, %rax
    605b:      	je	0x636d <generic_lsm_process_filter+0x20ed>
    6061:      	movq	%rax, %rbp
    6064:      	leaq	0x70(%rax), %rsi
    6068:      	movl	$0x1, %eax
    606d:      	movq	(%rip), %rdi            # 0x6074 <generic_lsm_process_filter+0x1df4>
    6074:      	callq	*%rax
    6076:      	testq	%rax, %rax
    6079:      	je	0x6090 <generic_lsm_process_filter+0x1e10>
    607b:      	movq	(%rax), %rax
    607e:      	testq	%rax, %rax
    6081:      	je	0x6090 <generic_lsm_process_filter+0x1e10>
    6083:      	movq	0x38(%rsp), %rcx
    6088:      	lock
    6089:      	orq	%rax, 0x370(%rcx)
    6090:      	subl	$0x1, %r15d
    6094:      	setb	%al
    6097:      	cmpq	%r14, %rbp
    609a:      	je	0x636d <generic_lsm_process_filter+0x20ed>
    60a0:      	movq	%rbp, %r14
    60a3:      	testb	%al, %al
    60a5:      	je	0x603d <generic_lsm_process_filter+0x1dbd>
    60a7:      	jmp	0x636d <generic_lsm_process_filter+0x20ed>
    60ac:      	cmpl	$0x2, %ecx
    60af:      	jbe	0x60b5 <generic_lsm_process_filter+0x1e35>
    60b1:      	xorl	%esi, %esi
    60b3:      	jmp	0x60cf <generic_lsm_process_filter+0x1e4f>
    60b5:      	andq	0x48(%r9,%rcx,8), %rax
    60ba:      	cmpl	$0x5, %edx
    60bd:      	jne	0x60c8 <generic_lsm_process_filter+0x1e48>
    60bf:      	testq	%rax, %rax
    60c2:      	setne	%sil
    60c6:      	jmp	0x60cf <generic_lsm_process_filter+0x1e4f>
    60c8:      	testq	%rax, %rax
    60cb:      	sete	%sil
    60cf:      	addl	$0x18, %ebp
    60d2:      	movzbl	%sil, %eax
    60d6:      	movl	%ebp, %ebx
    60d8:      	testl	%eax, %eax
    60da:      	je	0x684b <generic_lsm_process_filter+0x25cb>
    60e0:      	movl	%ebx, %ecx
    60e2:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    60e8:      	leal	0x4(%rbx), %eax
    60eb:      	cmpl	$0x4, (%rcx,%r10)
    60f0:      	je	0x6753 <generic_lsm_process_filter+0x24d3>
    60f6:      	andl	$0x3ff, %eax            # imm = 0x3FF
    60fb:      	movl	(%rax,%r10), %r14d
    60ff:      	movl	0x4(%rax,%r10), %ebp
    6104:      	movl	$0xe, %eax
    6109:      	callq	*%rax
    610b:      	shrq	$0x20, %rax
    610f:      	movl	%eax, 0x60(%rsp)
    6113:      	movq	(%rip), %rdi            # 0x611a <generic_lsm_process_filter+0x1e9a>
    611a:      	leaq	0x60(%rsp), %rsi
    611f:      	movl	$0x1, %eax
    6124:      	callq	*%rax
    6126:      	movq	0x8(%rsp), %r10
    612b:      	testq	%rax, %rax
    612e:      	je	0x684b <generic_lsm_process_filter+0x25cb>
    6134:      	cmpl	$0x5, %r14d
    6138:      	je	0x6176 <generic_lsm_process_filter+0x1ef6>
    613a:      	cmpl	$0x6, %r14d
    613e:      	jne	0x684b <generic_lsm_process_filter+0x25cb>
    6144:      	movq	0x50(%rsp), %rsi
    6149:      	movq	%rsi, %rcx
    614c:      	addq	$0x5ee8, %rcx           # imm = 0x5EE8
    6153:      	testb	$0x1, %bpl
    6157:      	jne	0x6419 <generic_lsm_process_filter+0x2199>
    615d:      	movl	0x28(%rax), %edx
    6160:      	testl	%edx, %edx
    6162:      	je	0x6412 <generic_lsm_process_filter+0x2192>
    6168:      	cmpl	0x20(%rsi), %edx
    616b:      	je	0x6419 <generic_lsm_process_filter+0x2199>
    6171:      	jmp	0x6747 <generic_lsm_process_filter+0x24c7>
    6176:      	movq	0x50(%rsp), %rsi
    617b:      	movq	%rsi, %rcx
    617e:      	addq	$0x5ee8, %rcx           # imm = 0x5EE8
    6185:      	testb	$0x1, %bpl
    6189:      	je	0x6437 <generic_lsm_process_filter+0x21b7>
    618f:      	movl	0x28(%rax), %edx
    6192:      	testl	%edx, %edx
    6194:      	je	0x6430 <generic_lsm_process_filter+0x21b0>
    619a:      	cmpl	0x20(%rsi), %edx
    619d:      	je	0x6437 <generic_lsm_process_filter+0x21b7>
    61a3:      	jmp	0x6747 <generic_lsm_process_filter+0x24c7>
    61a8:      	movq	%r12, %rsi
    61ab:      	addq	$0x4, %rsi
    61af:      	movq	(%rip), %rdi            # 0x61b6 <generic_lsm_process_filter+0x1f36>
    61b6:      	movl	$0x1, %eax
    61bb:      	callq	*%rax
    61bd:      	testq	%rax, %rax
    61c0:      	je	0x684b <generic_lsm_process_filter+0x25cb>
    61c6:      	movq	%rax, %r14
    61c9:      	movq	(%rip), %rdi            # 0x61d0 <generic_lsm_process_filter+0x1f50>
    61d0:      	leaq	0x58(%rsp), %rsi
    61d5:      	movl	$0x1, %eax
    61da:      	callq	*%rax
    61dc:      	testq	%rax, %rax
    61df:      	je	0x684b <generic_lsm_process_filter+0x25cb>
    61e5:      	movq	%rax, %rbx
    61e8:      	movl	$0x104, %edx            # imm = 0x104
    61ed:      	movq	%rax, %rdi
    61f0:      	xorl	%esi, %esi
    61f2:      	callq	0x61f7 <generic_lsm_process_filter+0x1f77>
    61f7:      	movl	(%rbp), %eax
    61fa:      	leal	(,%rax,8), %ecx
    6201:      	movl	%ecx, (%rbx)
    6203:      	movq	%rbx, %rdi
    6206:      	addq	$0x4, %rdi
    620a:      	movzbl	%al, %ecx
    620d:      	movq	%rbp, %rdx
    6210:      	addq	$0x8, %rdx
    6214:      	movl	$0x4, %eax
    6219:      	movzbl	(%rbp), %esi
    621d:      	callq	*%rax
    621f:      	testq	%rax, %rax
    6222:      	js	0x684b <generic_lsm_process_filter+0x25cb>
    6228:      	movl	$0x1, %eax
    622d:      	movq	%r14, %rdi
    6230:      	movq	%rbx, %rsi
    6233:      	jmp	0x65ad <generic_lsm_process_filter+0x232d>
    6238:      	movl	$0x0, 0x40(%rsp)
    6240:      	movq	(%rip), %rdi            # 0x6247 <generic_lsm_process_filter+0x1fc7>
    6247:      	leaq	0x40(%rsp), %rsi
    624c:      	movl	$0x1, %eax
    6251:      	callq	*%rax
    6253:      	testq	%rax, %rax
    6256:      	je	0x655a <generic_lsm_process_filter+0x22da>
    625c:      	movq	(%rax), %rcx
    625f:      	cmpq	0x310(%rbp), %rcx
    6266:      	je	0x655a <generic_lsm_process_filter+0x22da>
    626c:      	movq	%rax, 0xb0(%rsp)
    6274:      	movq	(%rip), %rax            # 0x627b <generic_lsm_process_filter+0x1ffb>
    627b:      	cmpb	$0x0, (%rax)
    627e:      	je	0x64de <generic_lsm_process_filter+0x225e>
    6284:      	movl	$0x1869f, %r15d         # imm = 0x1869F
    628a:      	xorl	%r14d, %r14d
    628d:      	movq	0x38(%rsp), %rax
    6292:      	movl	0x10(%rax), %eax
    6295:      	movl	%eax, 0x60(%rsp)
    6299:      	movl	$0x1, %eax
    629e:      	movq	(%rip), %rdi            # 0x62a5 <generic_lsm_process_filter+0x2025>
    62a5:      	leaq	0x60(%rsp), %rsi
    62aa:      	callq	*%rax
    62ac:      	testq	%rax, %rax
    62af:      	je	0x6548 <generic_lsm_process_filter+0x22c8>
    62b5:      	movq	%rax, %rbx
    62b8:      	leaq	0x70(%rax), %rsi
    62bc:      	movl	$0x1, %eax
    62c1:      	movq	(%rip), %rdi            # 0x62c8 <generic_lsm_process_filter+0x2048>
    62c8:      	callq	*%rax
    62ca:      	testq	%rax, %rax
    62cd:      	je	0x62df <generic_lsm_process_filter+0x205f>
    62cf:      	movq	(%rax), %rax
    62d2:      	testq	%rax, %rax
    62d5:      	je	0x62df <generic_lsm_process_filter+0x205f>
    62d7:      	lock
    62d8:      	orq	%rax, 0x308(%rbp)
    62df:      	subl	$0x1, %r15d
    62e3:      	setb	%al
    62e6:      	cmpq	%r14, %rbx
    62e9:      	je	0x6548 <generic_lsm_process_filter+0x22c8>
    62ef:      	movq	%rbx, %r14
    62f2:      	testb	%al, %al
    62f4:      	je	0x628d <generic_lsm_process_filter+0x200d>
    62f6:      	jmp	0x6548 <generic_lsm_process_filter+0x22c8>
    62fb:      	movl	$0x3ff, %r15d           # imm = 0x3FF
    6301:      	xorl	%r14d, %r14d
    6304:      	movq	(%rip), %r12            # 0x630b <generic_lsm_process_filter+0x208b>
    630b:      	movq	0x38(%rsp), %rax
    6310:      	movl	0x10(%rax), %eax
    6313:      	movl	%eax, 0x60(%rsp)
    6317:      	movl	$0x1, %eax
    631c:      	leaq	0x60(%rsp), %rsi
    6321:      	movq	%r12, %rdi
    6324:      	callq	*%rax
    6326:      	testq	%rax, %rax
    6329:      	je	0x636d <generic_lsm_process_filter+0x20ed>
    632b:      	movq	%rax, %rbp
    632e:      	leaq	0x70(%rax), %rsi
    6332:      	movl	$0x1, %eax
    6337:      	movq	(%rip), %rdi            # 0x633e <generic_lsm_process_filter+0x20be>
    633e:      	callq	*%rax
    6340:      	testq	%rax, %rax
    6343:      	je	0x635a <generic_lsm_process_filter+0x20da>
    6345:      	movq	(%rax), %rax
    6348:      	testq	%rax, %rax
    634b:      	je	0x635a <generic_lsm_process_filter+0x20da>
    634d:      	movq	0x38(%rsp), %rcx
    6352:      	lock
    6353:      	orq	%rax, 0x370(%rcx)
    635a:      	subl	$0x1, %r15d
    635e:      	setb	%al
    6361:      	cmpq	%r14, %rbp
    6364:      	je	0x636d <generic_lsm_process_filter+0x20ed>
    6366:      	movq	%rbp, %r14
    6369:      	testb	%al, %al
    636b:      	je	0x630b <generic_lsm_process_filter+0x208b>
    636d:      	movq	0xb0(%rsp), %rax
    6375:      	movq	(%rax), %rax
    6378:      	movq	0x38(%rsp), %rdx
    637d:      	movq	%rax, 0x378(%rdx)
    6384:      	movl	0x8(%rbx), %eax
    6387:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    638c:      	cmpq	%rcx, %rax
    638f:      	je	0x63aa <generic_lsm_process_filter+0x212a>
    6391:      	movq	0x370(%rdx), %rcx
    6398:      	btq	%rax, %rcx
    639c:      	jae	0x63aa <generic_lsm_process_filter+0x212a>
    639e:      	movabsq	$0xbadc0ffee, %rax      # imm = 0xBADC0FFEE
    63a8:      	jmp	0x63d9 <generic_lsm_process_filter+0x2159>
    63aa:      	movq	(%rip), %rdi            # 0x63b1 <generic_lsm_process_filter+0x2131>
    63b1:      	leaq	0x10(%rsp), %rsi
    63b6:      	movl	$0x1, %eax
    63bb:      	callq	*%rax
    63bd:      	testq	%rax, %rax
    63c0:      	je	0x684b <generic_lsm_process_filter+0x25cb>
    63c6:      	movq	%rax, %rdi
    63c9:      	movq	0x38(%rsp), %rax
    63ce:      	leaq	0x70(%rax), %rsi
    63d2:      	movl	$0x1, %eax
    63d7:      	callq	*%rax
    63d9:      	movl	(%rbx), %ecx
    63db:      	cmpq	$0x25, %rcx
    63df:      	movq	0x8(%rsp), %r10
    63e4:      	ja	0x6404 <generic_lsm_process_filter+0x2184>
    63e6:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    63f0:      	btq	%rcx, %rdx
    63f4:      	jae	0x6404 <generic_lsm_process_filter+0x2184>
    63f6:      	testq	%rax, %rax
    63f9:      	jne	0x684b <generic_lsm_process_filter+0x25cb>
    63ff:      	jmp	0x5549 <generic_lsm_process_filter+0x12c9>
    6404:      	testq	%rax, %rax
    6407:      	jne	0x5549 <generic_lsm_process_filter+0x12c9>
    640d:      	jmp	0x684b <generic_lsm_process_filter+0x25cb>
    6412:      	movq	$0x1, (%rcx)
    6419:      	testb	$0x2, %bpl
    641d:      	jne	0x6455 <generic_lsm_process_filter+0x21d5>
    641f:      	movl	0x2c(%rax), %edx
    6422:      	testl	%edx, %edx
    6424:      	je	0x644e <generic_lsm_process_filter+0x21ce>
    6426:      	cmpl	0x24(%rsi), %edx
    6429:      	je	0x6455 <generic_lsm_process_filter+0x21d5>
    642b:      	jmp	0x6747 <generic_lsm_process_filter+0x24c7>
    6430:      	movq	$0x1, (%rcx)
    6437:      	testb	$0x2, %bpl
    643b:      	je	0x6473 <generic_lsm_process_filter+0x21f3>
    643d:      	movl	0x2c(%rax), %edx
    6440:      	testl	%edx, %edx
    6442:      	je	0x646c <generic_lsm_process_filter+0x21ec>
    6444:      	cmpl	0x24(%rsi), %edx
    6447:      	je	0x6473 <generic_lsm_process_filter+0x21f3>
    6449:      	jmp	0x6747 <generic_lsm_process_filter+0x24c7>
    644e:      	movq	$0x1, (%rcx)
    6455:      	testb	$0x4, %bpl
    6459:      	jne	0x6491 <generic_lsm_process_filter+0x2211>
    645b:      	movl	0x30(%rax), %edx
    645e:      	testl	%edx, %edx
    6460:      	je	0x648a <generic_lsm_process_filter+0x220a>
    6462:      	cmpl	0x28(%rsi), %edx
    6465:      	je	0x6491 <generic_lsm_process_filter+0x2211>
    6467:      	jmp	0x6747 <generic_lsm_process_filter+0x24c7>
    646c:      	movq	$0x1, (%rcx)
    6473:      	testb	$0x4, %bpl
    6477:      	je	0x64bb <generic_lsm_process_filter+0x223b>
    6479:      	movl	0x30(%rax), %edx
    647c:      	testl	%edx, %edx
    647e:      	je	0x64b4 <generic_lsm_process_filter+0x2234>
    6480:      	cmpl	0x28(%rsi), %edx
    6483:      	je	0x64bb <generic_lsm_process_filter+0x223b>
    6485:      	jmp	0x6747 <generic_lsm_process_filter+0x24c7>
    648a:      	movq	$0x1, (%rcx)
    6491:      	testb	$0x8, %bpl
    6495:      	jne	0x65f1 <generic_lsm_process_filter+0x2371>
    649b:      	movl	0x34(%rax), %edx
    649e:      	testl	%edx, %edx
    64a0:      	je	0x65ea <generic_lsm_process_filter+0x236a>
    64a6:      	cmpl	0x2c(%rsi), %edx
    64a9:      	je	0x65f1 <generic_lsm_process_filter+0x2371>
    64af:      	jmp	0x6747 <generic_lsm_process_filter+0x24c7>
    64b4:      	movq	$0x1, (%rcx)
    64bb:      	testb	$0x8, %bpl
    64bf:      	je	0x660f <generic_lsm_process_filter+0x238f>
    64c5:      	movl	0x34(%rax), %edx
    64c8:      	testl	%edx, %edx
    64ca:      	je	0x6608 <generic_lsm_process_filter+0x2388>
    64d0:      	cmpl	0x2c(%rsi), %edx
    64d3:      	je	0x660f <generic_lsm_process_filter+0x238f>
    64d9:      	jmp	0x6747 <generic_lsm_process_filter+0x24c7>
    64de:      	movl	$0x3ff, %r15d           # imm = 0x3FF
    64e4:      	xorl	%r14d, %r14d
    64e7:      	movq	0x38(%rsp), %rax
    64ec:      	movl	0x10(%rax), %eax
    64ef:      	movl	%eax, 0x60(%rsp)
    64f3:      	movl	$0x1, %eax
    64f8:      	movq	(%rip), %rdi            # 0x64ff <generic_lsm_process_filter+0x227f>
    64ff:      	leaq	0x60(%rsp), %rsi
    6504:      	callq	*%rax
    6506:      	testq	%rax, %rax
    6509:      	je	0x6548 <generic_lsm_process_filter+0x22c8>
    650b:      	movq	%rax, %rbx
    650e:      	leaq	0x70(%rax), %rsi
    6512:      	movl	$0x1, %eax
    6517:      	movq	(%rip), %rdi            # 0x651e <generic_lsm_process_filter+0x229e>
    651e:      	callq	*%rax
    6520:      	testq	%rax, %rax
    6523:      	je	0x6535 <generic_lsm_process_filter+0x22b5>
    6525:      	movq	(%rax), %rax
    6528:      	testq	%rax, %rax
    652b:      	je	0x6535 <generic_lsm_process_filter+0x22b5>
    652d:      	lock
    652e:      	orq	%rax, 0x308(%rbp)
    6535:      	subl	$0x1, %r15d
    6539:      	setb	%al
    653c:      	cmpq	%r14, %rbx
    653f:      	je	0x6548 <generic_lsm_process_filter+0x22c8>
    6541:      	movq	%rbx, %r14
    6544:      	testb	%al, %al
    6546:      	je	0x64e7 <generic_lsm_process_filter+0x2267>
    6548:      	movq	0xb0(%rsp), %rax
    6550:      	movq	(%rax), %rax
    6553:      	movq	%rax, 0x310(%rbp)
    655a:      	movl	0x8(%r12), %eax
    655f:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    6564:      	cmpq	%rcx, %rax
    6567:      	je	0x6582 <generic_lsm_process_filter+0x2302>
    6569:      	movq	0x308(%rbp), %rcx
    6570:      	btq	%rax, %rcx
    6574:      	jae	0x6582 <generic_lsm_process_filter+0x2302>
    6576:      	movabsq	$0xbadc0ffee, %rax      # imm = 0xBADC0FFEE
    6580:      	jmp	0x65af <generic_lsm_process_filter+0x232f>
    6582:      	movq	(%rip), %rdi            # 0x6589 <generic_lsm_process_filter+0x2309>
    6589:      	leaq	0x10(%rsp), %rsi
    658e:      	movl	$0x1, %eax
    6593:      	callq	*%rax
    6595:      	testq	%rax, %rax
    6598:      	je	0x684b <generic_lsm_process_filter+0x25cb>
    659e:      	movq	%rax, %rdi
    65a1:      	addq	$0x8, %rbp
    65a5:      	movl	$0x1, %eax
    65aa:      	movq	%rbp, %rsi
    65ad:      	callq	*%rax
    65af:      	movl	(%r12), %ecx
    65b3:      	cmpq	$0x25, %rcx
    65b7:      	movq	0x8(%rsp), %r10
    65bc:      	ja	0x65dc <generic_lsm_process_filter+0x235c>
    65be:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    65c8:      	btq	%rcx, %rdx
    65cc:      	jae	0x65dc <generic_lsm_process_filter+0x235c>
    65ce:      	testq	%rax, %rax
    65d1:      	jne	0x684b <generic_lsm_process_filter+0x25cb>
    65d7:      	jmp	0x5795 <generic_lsm_process_filter+0x1515>
    65dc:      	testq	%rax, %rax
    65df:      	jne	0x5795 <generic_lsm_process_filter+0x1515>
    65e5:      	jmp	0x684b <generic_lsm_process_filter+0x25cb>
    65ea:      	movq	$0x1, (%rcx)
    65f1:      	testb	$0x10, %bpl
    65f5:      	jne	0x662d <generic_lsm_process_filter+0x23ad>
    65f7:      	movl	0x38(%rax), %edx
    65fa:      	testl	%edx, %edx
    65fc:      	je	0x6626 <generic_lsm_process_filter+0x23a6>
    65fe:      	cmpl	0x30(%rsi), %edx
    6601:      	je	0x662d <generic_lsm_process_filter+0x23ad>
    6603:      	jmp	0x6747 <generic_lsm_process_filter+0x24c7>
    6608:      	movq	$0x1, (%rcx)
    660f:      	testb	$0x10, %bpl
    6613:      	je	0x664b <generic_lsm_process_filter+0x23cb>
    6615:      	movl	0x38(%rax), %edx
    6618:      	testl	%edx, %edx
    661a:      	je	0x6644 <generic_lsm_process_filter+0x23c4>
    661c:      	cmpl	0x30(%rsi), %edx
    661f:      	je	0x664b <generic_lsm_process_filter+0x23cb>
    6621:      	jmp	0x6747 <generic_lsm_process_filter+0x24c7>
    6626:      	movq	$0x1, (%rcx)
    662d:      	testb	$0x20, %bpl
    6631:      	jne	0x6669 <generic_lsm_process_filter+0x23e9>
    6633:      	movl	0x3c(%rax), %edx
    6636:      	testl	%edx, %edx
    6638:      	je	0x6662 <generic_lsm_process_filter+0x23e2>
    663a:      	cmpl	0x34(%rsi), %edx
    663d:      	je	0x6669 <generic_lsm_process_filter+0x23e9>
    663f:      	jmp	0x6747 <generic_lsm_process_filter+0x24c7>
    6644:      	movq	$0x1, (%rcx)
    664b:      	testb	$0x20, %bpl
    664f:      	je	0x6687 <generic_lsm_process_filter+0x2407>
    6651:      	movl	0x3c(%rax), %edx
    6654:      	testl	%edx, %edx
    6656:      	je	0x6680 <generic_lsm_process_filter+0x2400>
    6658:      	cmpl	0x34(%rsi), %edx
    665b:      	je	0x6687 <generic_lsm_process_filter+0x2407>
    665d:      	jmp	0x6747 <generic_lsm_process_filter+0x24c7>
    6662:      	movq	$0x1, (%rcx)
    6669:      	testb	$0x40, %bpl
    666d:      	jne	0x66a5 <generic_lsm_process_filter+0x2425>
    666f:      	movl	0x40(%rax), %edx
    6672:      	testl	%edx, %edx
    6674:      	je	0x669e <generic_lsm_process_filter+0x241e>
    6676:      	cmpl	0x38(%rsi), %edx
    6679:      	je	0x66a5 <generic_lsm_process_filter+0x2425>
    667b:      	jmp	0x6747 <generic_lsm_process_filter+0x24c7>
    6680:      	movq	$0x1, (%rcx)
    6687:      	testb	$0x40, %bpl
    668b:      	je	0x66c2 <generic_lsm_process_filter+0x2442>
    668d:      	movl	0x40(%rax), %edx
    6690:      	testl	%edx, %edx
    6692:      	je	0x66bb <generic_lsm_process_filter+0x243b>
    6694:      	cmpl	0x38(%rsi), %edx
    6697:      	je	0x66c2 <generic_lsm_process_filter+0x2442>
    6699:      	jmp	0x6747 <generic_lsm_process_filter+0x24c7>
    669e:      	movq	$0x1, (%rcx)
    66a5:      	testb	%bpl, %bpl
    66a8:      	js	0x66dc <generic_lsm_process_filter+0x245c>
    66aa:      	movl	0x44(%rax), %edx
    66ad:      	testl	%edx, %edx
    66af:      	je	0x66d5 <generic_lsm_process_filter+0x2455>
    66b1:      	cmpl	0x3c(%rsi), %edx
    66b4:      	je	0x66dc <generic_lsm_process_filter+0x245c>
    66b6:      	jmp	0x6747 <generic_lsm_process_filter+0x24c7>
    66bb:      	movq	$0x1, (%rcx)
    66c2:      	testb	%bpl, %bpl
    66c5:      	jns	0x66f9 <generic_lsm_process_filter+0x2479>
    66c7:      	movl	0x44(%rax), %edx
    66ca:      	testl	%edx, %edx
    66cc:      	je	0x66f2 <generic_lsm_process_filter+0x2472>
    66ce:      	cmpl	0x3c(%rsi), %edx
    66d1:      	je	0x66f9 <generic_lsm_process_filter+0x2479>
    66d3:      	jmp	0x6747 <generic_lsm_process_filter+0x24c7>
    66d5:      	movq	$0x1, (%rcx)
    66dc:      	testl	$0x100, %ebp            # imm = 0x100
    66e2:      	jne	0x6722 <generic_lsm_process_filter+0x24a2>
    66e4:      	movl	0x48(%rax), %edx
    66e7:      	testl	%edx, %edx
    66e9:      	je	0x671b <generic_lsm_process_filter+0x249b>
    66eb:      	cmpl	0x40(%rsi), %edx
    66ee:      	je	0x6722 <generic_lsm_process_filter+0x24a2>
    66f0:      	jmp	0x6747 <generic_lsm_process_filter+0x24c7>
    66f2:      	movq	$0x1, (%rcx)
    66f9:      	testl	$0x100, %ebp            # imm = 0x100
    66ff:      	je	0x6831 <generic_lsm_process_filter+0x25b1>
    6705:      	movl	0x48(%rax), %edx
    6708:      	testl	%edx, %edx
    670a:      	je	0x682a <generic_lsm_process_filter+0x25aa>
    6710:      	cmpl	0x40(%rsi), %edx
    6713:      	je	0x6831 <generic_lsm_process_filter+0x25b1>
    6719:      	jmp	0x6747 <generic_lsm_process_filter+0x24c7>
    671b:      	movq	$0x1, (%rcx)
    6722:      	testl	$0x200, %ebp            # imm = 0x200
    6728:      	jne	0x684b <generic_lsm_process_filter+0x25cb>
    672e:      	movl	0x4c(%rax), %eax
    6731:      	testl	%eax, %eax
    6733:      	je	0x6844 <generic_lsm_process_filter+0x25c4>
    6739:      	movq	0x50(%rsp), %rdx
    673e:      	cmpl	0x44(%rdx), %eax
    6741:      	je	0x684b <generic_lsm_process_filter+0x25cb>
    6747:      	addl	$0xc, %ebx
    674a:      	movq	$0x1, (%rcx)
    6751:      	movl	%ebx, %eax
    6753:      	movl	%eax, %ecx
    6755:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    675b:      	cmpl	$0x4, (%rcx,%r10)
    6760:      	movq	0x50(%rsp), %rcx
    6765:      	jne	0x678c <generic_lsm_process_filter+0x250c>
    6767:      	movq	0x5eb8(%rcx), %rax
    676e:      	andl	$0x1f, %eax
    6771:      	movb	$0x1, 0x5ec1(%rcx,%rax)
    6779:      	movb	$0x1, 0x5ee0(%rcx)
    6780:      	movb	$0x1, 0x5ec0(%rcx)
    6787:      	jmp	0x684b <generic_lsm_process_filter+0x25cb>
    678c:      	addl	$0x4, %eax
    678f:      	andl	$0x3ff, %eax            # imm = 0x3FF
    6794:      	movl	(%rax,%r10), %r14d
    6798:      	movl	0x4(%rax,%r10), %ebx
    679d:      	movl	0x8(%rax,%r10), %ebp
    67a2:      	movq	0xc(%rax,%r10), %r15
    67a7:      	movl	$0xe, %eax
    67ac:      	callq	*%rax
    67ae:      	shrq	$0x20, %rax
    67b2:      	movl	%eax, 0x60(%rsp)
    67b6:      	movq	(%rip), %rdi            # 0x67bd <generic_lsm_process_filter+0x253d>
    67bd:      	leaq	0x60(%rsp), %rsi
    67c2:      	movl	$0x1, %eax
    67c7:      	callq	*%rax
    67c9:      	testq	%rax, %rax
    67cc:      	je	0x684b <generic_lsm_process_filter+0x25cb>
    67ce:      	testl	%ebp, %ebp
    67d0:      	je	0x67e4 <generic_lsm_process_filter+0x2564>
    67d2:      	cmpl	$0x2, %r14d
    67d6:      	ja	0x684b <generic_lsm_process_filter+0x25cb>
    67d8:      	movq	0x50(%rsp), %rcx
    67dd:      	cmpl	%ebp, 0x44(%rcx)
    67e0:      	jne	0x67ea <generic_lsm_process_filter+0x256a>
    67e2:      	jmp	0x684b <generic_lsm_process_filter+0x25cb>
    67e4:      	cmpl	$0x2, %r14d
    67e8:      	ja	0x684b <generic_lsm_process_filter+0x25cb>
    67ea:      	movq	0x50(%rax,%r14,8), %rax
    67ef:      	movq	0x50(%rsp), %rcx
    67f4:      	movq	0x48(%rcx,%r14,8), %rcx
    67f9:      	movq	%rcx, %rdx
    67fc:      	xorq	%rax, %rdx
    67ff:      	testq	%r15, %rdx
    6802:      	je	0x680b <generic_lsm_process_filter+0x258b>
    6804:      	cmpl	$0x5, %ebx
    6807:      	jne	0x684b <generic_lsm_process_filter+0x25cb>
    6809:      	jmp	0x6815 <generic_lsm_process_filter+0x2595>
    680b:      	cmpq	%rcx, %rax
    680e:      	je	0x684b <generic_lsm_process_filter+0x25cb>
    6810:      	cmpl	$0x6, %ebx
    6813:      	jne	0x684b <generic_lsm_process_filter+0x25cb>
    6815:      	movq	0x50(%rsp), %rcx
    681a:      	movq	$0x1, 0x5ef0(%rcx)
    6825:      	jmp	0x6767 <generic_lsm_process_filter+0x24e7>
    682a:      	movq	$0x1, (%rcx)
    6831:      	testl	$0x200, %ebp            # imm = 0x200
    6837:      	je	0x684b <generic_lsm_process_filter+0x25cb>
    6839:      	movl	0x4c(%rax), %eax
    683c:      	testl	%eax, %eax
    683e:      	jne	0x6739 <generic_lsm_process_filter+0x24b9>
    6844:      	movq	$0x1, (%rcx)
    684b:      	movq	0x50(%rsp), %rcx
    6850:      	movq	0x5eb8(%rcx), %rax
    6857:      	incq	%rax
    685a:      	movq	%rax, 0x5eb8(%rcx)
    6861:      	cmpq	0xc0(%rsp), %rax
    6869:      	jbe	0x68b7 <generic_lsm_process_filter+0x2637>
    686b:      	movq	0x38(%rsp), %rdx
    6870:      	movl	(%rdx), %eax
    6872:      	movl	%eax, 0x10(%rcx)
    6875:      	movq	0x8(%rdx), %rax
    6879:      	movq	%rax, 0x18(%rcx)
    687d:      	cmpb	$0x0, 0x5ec0(%rcx)
    6884:      	movq	0xb8(%rsp), %rbx
    688c:      	je	0x68a3 <generic_lsm_process_filter+0x2623>
    688e:      	movq	(%rip), %rsi            # 0x6895 <generic_lsm_process_filter+0x2615>
    6895:      	xorl	%ecx, %ecx
    6897:      	movl	$0xc, %eax
    689c:      	movq	%rbx, %rdi
    689f:      	xorl	%edx, %edx
    68a1:      	callq	*%rax
    68a3:      	xorl	%eax, %eax
    68a5:      	addq	$0xe8, %rsp
    68ac:      	popq	%rbx
    68ad:      	popq	%r12
    68af:      	popq	%r13
    68b1:      	popq	%r14
    68b3:      	popq	%r15
    68b5:      	popq	%rbp
    68b6:      	retq
    68b7:      	movq	(%rip), %rsi            # 0x68be <generic_lsm_process_filter+0x263e>
    68be:      	movl	$0x2, %ecx
    68c3:      	movl	$0xc, %eax
    68c8:      	movq	0xb8(%rsp), %rdi
    68d0:      	movl	$0x2, %edx
    68d5:      	jmp	0x68a1 <generic_lsm_process_filter+0x2621>
    68d7:      	nopw	(%rax,%rax)

00000000000068e0 <generic_lsm_filter_arg>:
    68e0:      	pushq	%rbp
    68e1:      	pushq	%r15
    68e3:      	pushq	%r14
    68e5:      	pushq	%r13
    68e7:      	pushq	%r12
    68e9:      	pushq	%rbx
    68ea:      	subq	$0xb8, %rsp
    68f1:      	movq	%rdi, %r12
    68f4:      	movl	$0x0, 0xa4(%rsp)
    68ff:      	movq	(%rip), %rdi            # 0x6906 <generic_lsm_filter_arg+0x26>
    6906:      	leaq	0xa4(%rsp), %rsi
    690e:      	movl	$0x1, %eax
    6913:      	callq	*%rax
    6915:      	testq	%rax, %rax
    6918:      	je	0x6ad2 <generic_lsm_filter_arg+0x1f2>
    691e:      	movq	%rax, %r14
    6921:      	movl	0x5f00(%rax), %ebx
    6927:      	leaq	0x5ef8(%rax), %rsi
    692e:      	movq	(%rip), %rdi            # 0x6935 <generic_lsm_filter_arg+0x55>
    6935:      	movl	$0x1, %eax
    693a:      	callq	*%rax
    693c:      	testq	%rax, %rax
    693f:      	je	0x6ab7 <generic_lsm_filter_arg+0x1d7>
    6945:      	cmpb	$0x0, 0x5ee0(%r14)
    694d:      	je	0x6ab7 <generic_lsm_filter_arg+0x1d7>
    6953:      	movq	%rax, %r15
    6956:      	movq	%r12, 0x98(%rsp)
    695e:      	movl	%ebx, %eax
    6960:      	andl	$0x7, %eax
    6963:      	cmpb	$0x0, 0x5ec1(%r14,%rax)
    696c:      	je	0x69fd <generic_lsm_filter_arg+0x11d>
    6972:      	movl	%eax, %eax
    6974:      	movl	0x4(%r15,%rax,4), %ecx
    6979:      	leaq	(%rcx,%rax,4), %rdx
    697d:      	addq	$0x4, %rdx
    6981:      	leaq	(%rcx,%rax,4), %rax
    6985:      	addq	$0x8, %rax
    6989:      	andl	$0x3ff, %eax            # imm = 0x3FF
    698e:      	movl	(%rax,%r15), %eax
    6992:      	addq	%rdx, %rax
    6995:      	addq	$0x4, %rax
    6999:      	movl	%eax, %ecx
    699b:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    69a1:      	movl	(%rcx,%r15), %ecx
    69a5:      	addq	%rax, %rcx
    69a8:      	movl	%ecx, %eax
    69aa:      	andl	$0x3ff, %eax            # imm = 0x3FF
    69af:      	movl	(%rax,%r15), %eax
    69b3:      	addq	%rcx, %rax
    69b6:      	movl	%eax, %ecx
    69b8:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    69be:      	movl	(%rcx,%r15), %ecx
    69c2:      	addq	%rax, %rcx
    69c5:      	movl	%ecx, %eax
    69c7:      	andl	$0x3ff, %eax            # imm = 0x3FF
    69cc:      	movl	(%rax,%r15), %r9d
    69d0:      	addq	%rcx, %r9
    69d3:      	movl	%r9d, %edi
    69d6:      	andl	$0x3ff, %edi            # imm = 0x3FF
    69dc:      	cmpl	$0x19, (%r15,%rdi)
    69e1:      	jae	0x6a59 <generic_lsm_filter_arg+0x179>
    69e3:      	cmpq	$0x1, %rdi
    69e7:      	movq	0x98(%rsp), %r12
    69ef:      	je	0x6ab7 <generic_lsm_filter_arg+0x1d7>
    69f5:      	testl	%edi, %edi
    69f7:      	jne	0x6a8d <generic_lsm_filter_arg+0x1ad>
    69fd:      	cmpl	$0x1, %ebx
    6a00:      	jg	0x6a26 <generic_lsm_filter_arg+0x146>
    6a02:      	cmpl	$-0x1, %ebx
    6a05:      	movq	0x98(%rsp), %rdi
    6a0d:      	je	0x6ae6 <generic_lsm_filter_arg+0x206>
    6a13:      	testl	%ebx, %ebx
    6a15:      	je	0x6af2 <generic_lsm_filter_arg+0x212>
    6a1b:      	cmpl	$0x1, %ebx
    6a1e:      	je	0x6b01 <generic_lsm_filter_arg+0x221>
    6a24:      	jmp	0x6a49 <generic_lsm_filter_arg+0x169>
    6a26:      	cmpl	$0x2, %ebx
    6a29:      	movq	0x98(%rsp), %rdi
    6a31:      	je	0x6b10 <generic_lsm_filter_arg+0x230>
    6a37:      	cmpl	$0x3, %ebx
    6a3a:      	je	0x6b1f <generic_lsm_filter_arg+0x23f>
    6a40:      	cmpl	$0x4, %ebx
    6a43:      	je	0x6b2e <generic_lsm_filter_arg+0x24e>
    6a49:      	cmpl	$0x4, %ebx
    6a4c:      	jg	0x6b5c <generic_lsm_filter_arg+0x27c>
    6a52:      	incl	%ebx
    6a54:      	jmp	0x6b3d <generic_lsm_filter_arg+0x25d>
    6a59:      	leaq	(%r15,%rdi), %rax
    6a5d:      	movq	%rax, 0xb0(%rsp)
    6a65:      	xorl	%r11d, %r11d
    6a68:      	leaq	0x70(%rsp), %rax
    6a6d:      	movq	%rax, 0x28(%rsp)
    6a72:      	movq	%rbx, 0xa8(%rsp)
    6a7a:      	movq	%rdi, (%rsp)
    6a7e:      	movq	%r9, 0x8(%rsp)
    6a83:      	movq	%r15, 0x68(%rsp)
    6a88:      	jmp	0x6bce <generic_lsm_filter_arg+0x2ee>
    6a8d:      	movl	%edi, 0x5f04(%r14)
    6a94:      	movq	(%rip), %rsi            # 0x6a9b <generic_lsm_filter_arg+0x1bb>
    6a9b:      	movl	$0x4, %ecx
    6aa0:      	movl	$0xc, %eax
    6aa5:      	movq	0x98(%rsp), %r12
    6aad:      	movq	%r12, %rdi
    6ab0:      	movl	$0x4, %edx
    6ab5:      	callq	*%rax
    6ab7:      	movq	(%rip), %rsi            # 0x6abe <generic_lsm_filter_arg+0x1de>
    6abe:      	movl	$0x5, %ecx
    6ac3:      	movl	$0xc, %eax
    6ac8:      	movq	%r12, %rdi
    6acb:      	movl	$0x5, %edx
    6ad0:      	callq	*%rax
    6ad2:      	xorl	%eax, %eax
    6ad4:      	addq	$0xb8, %rsp
    6adb:      	popq	%rbx
    6adc:      	popq	%r12
    6ade:      	popq	%r13
    6ae0:      	popq	%r14
    6ae2:      	popq	%r15
    6ae4:      	popq	%rbp
    6ae5:      	retq
    6ae6:      	xorl	%ebx, %ebx
    6ae8:      	cmpb	$0x0, 0x5ec1(%r14)
    6af0:      	jne	0x6b3d <generic_lsm_filter_arg+0x25d>
    6af2:      	movl	$0x1, %ebx
    6af7:      	cmpb	$0x0, 0x5ec2(%r14)
    6aff:      	jne	0x6b3d <generic_lsm_filter_arg+0x25d>
    6b01:      	movl	$0x2, %ebx
    6b06:      	cmpb	$0x0, 0x5ec3(%r14)
    6b0e:      	jne	0x6b3d <generic_lsm_filter_arg+0x25d>
    6b10:      	movl	$0x3, %ebx
    6b15:      	cmpb	$0x0, 0x5ec4(%r14)
    6b1d:      	jne	0x6b3d <generic_lsm_filter_arg+0x25d>
    6b1f:      	movl	$0x4, %ebx
    6b24:      	cmpb	$0x0, 0x5ec5(%r14)
    6b2c:      	jne	0x6b3d <generic_lsm_filter_arg+0x25d>
    6b2e:      	movl	$0x5, %ebx
    6b33:      	cmpb	$0x0, 0x5ec6(%r14)
    6b3b:      	je	0x6b5c <generic_lsm_filter_arg+0x27c>
    6b3d:      	movl	%ebx, 0x5f00(%r14)
    6b44:      	movq	(%rip), %rsi            # 0x6b4b <generic_lsm_filter_arg+0x26b>
    6b4b:      	movl	$0x3, %ecx
    6b50:      	movl	$0xc, %eax
    6b55:      	movl	$0x3, %edx
    6b5a:      	callq	*%rax
    6b5c:      	movq	0x60(%r14), %rbx
    6b60:      	movl	$0xe, %eax
    6b65:      	callq	*%rax
    6b67:      	movq	%rbx, 0x38(%rsp)
    6b6c:      	movq	%rax, 0x40(%rsp)
    6b71:      	movq	(%rip), %rdi            # 0x6b78 <generic_lsm_filter_arg+0x298>
    6b78:      	leaq	0x38(%rsp), %rsi
    6b7d:      	movl	$0x1, %eax
    6b82:      	callq	*%rax
    6b84:      	testq	%rax, %rax
    6b87:      	je	0x6ad2 <generic_lsm_filter_arg+0x1f2>
    6b8d:      	movq	(%rip), %rdi            # 0x6b94 <generic_lsm_filter_arg+0x2b4>
    6b94:      	leaq	0x38(%rsp), %rsi
    6b99:      	movl	$0x3, %eax
    6b9e:      	callq	*%rax
    6ba0:      	jmp	0x6ad2 <generic_lsm_filter_arg+0x1f2>
    6ba5:      	xorl	%ebx, %ebx
    6ba7:      	cmpl	$0x3, %eax
    6baa:      	sete	%bl
    6bad:      	nopl	(%rax)
    6bb0:      	testq	%rbx, %rbx
    6bb3:      	movq	0xa8(%rsp), %rbx
    6bbb:      	je	0x69fd <generic_lsm_filter_arg+0x11d>
    6bc1:      	incq	%r11
    6bc4:      	cmpq	$0x5, %r11
    6bc8:      	je	0x69e3 <generic_lsm_filter_arg+0x103>
    6bce:      	movq	0xb0(%rsp), %rax
    6bd6:      	movl	0x4(%rax,%r11,4), %r13d
    6bdb:      	testl	$0x3ff, %r13d           # imm = 0x3FF
    6be2:      	je	0x69e3 <generic_lsm_filter_arg+0x103>
    6be8:      	addl	%r9d, %r13d
    6beb:      	andl	$0x3ff, %r13d           # imm = 0x3FF
    6bf2:      	movl	0x4(%r15,%r13), %eax
    6bf7:      	cmpl	$0x23, %eax
    6bfa:      	je	0x69fd <generic_lsm_filter_arg+0x11d>
    6c00:      	addq	%r15, %r13
    6c03:      	movl	(%r13), %ecx
    6c07:      	cmpq	$0x4, %rcx
    6c0b:      	ja	0x69fd <generic_lsm_filter_arg+0x11d>
    6c11:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
    6c1a:      	jne	0x69fd <generic_lsm_filter_arg+0x11d>
    6c20:      	movq	0x5e78(%r14,%rcx,8), %rcx
    6c28:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    6c2e:      	leaq	(%r14,%rcx), %r12
    6c32:      	addq	$0x90, %r12
    6c39:      	movl	0xc(%r13), %ecx
    6c3d:      	cmpl	$0x1b, %ecx
    6c40:      	jle	0x6c5d <generic_lsm_filter_arg+0x37d>
    6c42:      	cmpl	$0x25, %ecx
    6c45:      	jg	0x6c88 <generic_lsm_filter_arg+0x3a8>
    6c47:      	leal	-0x1c(%rcx), %edx
    6c4a:      	cmpl	$0x9, %edx
    6c4d:      	jb	0x6cce <generic_lsm_filter_arg+0x3ee>
    6c4f:      	cmpl	$0x25, %ecx
    6c52:      	je	0x6ee6 <generic_lsm_filter_arg+0x606>
    6c58:      	jmp	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    6c5d:      	cmpl	$0x9, %ecx
    6c60:      	jle	0x6cae <generic_lsm_filter_arg+0x3ce>
    6c62:      	leal	-0xa(%rcx), %edx
    6c65:      	cmpl	$0x4, %edx
    6c68:      	jb	0x6cce <generic_lsm_filter_arg+0x3ee>
    6c6a:      	leal	-0xf(%rcx), %edx
    6c6d:      	cmpl	$0x2, %edx
    6c70:      	jb	0x6ee6 <generic_lsm_filter_arg+0x606>
    6c76:      	cmpl	$0x11, %ecx
    6c79:      	jne	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    6c7f:      	addq	$0x4, %r12
    6c83:      	jmp	0x6ee6 <generic_lsm_filter_arg+0x606>
    6c88:      	cmpl	$0x29, %ecx
    6c8b:      	jg	0x6e53 <generic_lsm_filter_arg+0x573>
    6c91:      	leal	-0x26(%rcx), %edx
    6c94:      	cmpl	$0x2, %edx
    6c97:      	jb	0x6de9 <generic_lsm_filter_arg+0x509>
    6c9d:      	leal	-0x28(%rcx), %edx
    6ca0:      	cmpl	$0x2, %edx
    6ca3:      	jb	0x6d94 <generic_lsm_filter_arg+0x4b4>
    6ca9:      	jmp	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    6cae:      	cmpl	$0x4, %ecx
    6cb1:      	jg	0x6d81 <generic_lsm_filter_arg+0x4a1>
    6cb7:      	cmpl	$0x1, %ecx
    6cba:      	je	0x6cce <generic_lsm_filter_arg+0x3ee>
    6cbc:      	cmpl	$0x2, %ecx
    6cbf:      	je	0x74d3 <generic_lsm_filter_arg+0xbf3>
    6cc5:      	cmpl	$0x4, %ecx
    6cc8:      	jne	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    6cce:      	cmpl	$0xb, %ecx
    6cd1:      	jle	0x6d5e <generic_lsm_filter_arg+0x47e>
    6cd7:      	cmpl	$0x24, %ecx
    6cda:      	ja	0x700b <generic_lsm_filter_arg+0x72b>
    6ce0:      	movl	%ecx, %edx
    6ce2:      	movabsq	$0x1e00000000, %rsi     # imm = 0x1E00000000
    6cec:      	btq	%rdx, %rsi
    6cf0:      	jb	0x6e27 <generic_lsm_filter_arg+0x547>
    6cf6:      	movl	$0x60000000, %esi       # imm = 0x60000000
    6cfb:      	btq	%rdx, %rsi
    6cff:      	jb	0x72a5 <generic_lsm_filter_arg+0x9c5>
    6d05:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
    6d0f:      	btq	%rdx, %rsi
    6d13:      	jae	0x700b <generic_lsm_filter_arg+0x72b>
    6d19:      	cmpl	$0x20, %eax
    6d1c:      	ja	0x69fd <generic_lsm_filter_arg+0x11d>
    6d22:      	movl	%eax, %ecx
    6d24:      	movl	$0x101e, %edx           # imm = 0x101E
    6d29:      	btq	%rcx, %rdx
    6d2d:      	jae	0x79e9 <generic_lsm_filter_arg+0x1109>
    6d33:      	movl	0x10(%r13), %ecx
    6d37:      	cmpl	$0x2, %eax
    6d3a:      	jle	0x7f13 <generic_lsm_filter_arg+0x1633>
    6d40:      	leal	-0x3(%rax), %edx
    6d43:      	cmpl	$0x2, %edx
    6d46:      	jae	0x866e <generic_lsm_filter_arg+0x1d8e>
    6d4c:      	movzbl	(%r12), %edx
    6d51:      	cmpl	%edx, %ecx
    6d53:      	je	0x6ba5 <generic_lsm_filter_arg+0x2c5>
    6d59:      	jmp	0x87a6 <generic_lsm_filter_arg+0x1ec6>
    6d5e:      	leal	-0xa(%rcx), %edx
    6d61:      	cmpl	$0x2, %edx
    6d64:      	jb	0x7553 <generic_lsm_filter_arg+0xc73>
    6d6a:      	cmpl	$0x1, %ecx
    6d6d:      	je	0x7017 <generic_lsm_filter_arg+0x737>
    6d73:      	cmpl	$0x4, %ecx
    6d76:      	je	0x7017 <generic_lsm_filter_arg+0x737>
    6d7c:      	jmp	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    6d81:      	cmpl	$0x5, %ecx
    6d84:      	je	0x6d94 <generic_lsm_filter_arg+0x4b4>
    6d86:      	cmpl	$0x6, %ecx
    6d89:      	je	0x6de9 <generic_lsm_filter_arg+0x509>
    6d8b:      	cmpl	$0x7, %ecx
    6d8e:      	jne	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    6d94:      	movq	$0x0, 0x58(%rsp)
    6d9d:      	movq	$0x0, 0x50(%rsp)
    6da6:      	movq	$0x0, 0x48(%rsp)
    6daf:      	movq	$0x0, 0x40(%rsp)
    6db8:      	movq	$0x0, 0x38(%rsp)
    6dc1:      	cmpl	$0x27, %ecx
    6dc4:      	jg	0x7055 <generic_lsm_filter_arg+0x775>
    6dca:      	cmpl	$0x5, %ecx
    6dcd:      	je	0x76b8 <generic_lsm_filter_arg+0xdd8>
    6dd3:      	movq	%r12, %rdx
    6dd6:      	movl	$0x0, %ebx
    6ddb:      	cmpl	$0x7, %ecx
    6dde:      	je	0x76ba <generic_lsm_filter_arg+0xdda>
    6de4:      	jmp	0x6bb0 <generic_lsm_filter_arg+0x2d0>
    6de9:      	movl	(%r12), %ebp
    6ded:      	addq	$0x4, %r12
    6df1:      	movq	%r12, 0x18(%rsp)
    6df6:      	cmpl	$0x19, %eax
    6df9:      	jg	0x70d8 <generic_lsm_filter_arg+0x7f8>
    6dff:      	leal	-0x3(%rax), %ecx
    6e02:      	cmpl	$0x2, %ecx
    6e05:      	jb	0x791b <generic_lsm_filter_arg+0x103b>
    6e0b:      	cmpl	$0x8, %eax
    6e0e:      	je	0x7885 <generic_lsm_filter_arg+0xfa5>
    6e14:      	movl	$0x0, %ebx
    6e19:      	cmpl	$0x9, %eax
    6e1c:      	je	0x70f8 <generic_lsm_filter_arg+0x818>
    6e22:      	jmp	0x9f1b <generic_lsm_filter_arg+0x363b>
    6e27:      	cmpl	$0x9, %eax
    6e2a:      	jle	0x74c2 <generic_lsm_filter_arg+0xbe2>
    6e30:      	cmpl	$0x1d, %eax
    6e33:      	jg	0x783f <generic_lsm_filter_arg+0xf5f>
    6e39:      	leal	-0xa(%rax), %edx
    6e3c:      	cmpl	$0x2, %edx
    6e3f:      	jb	0x75e0 <generic_lsm_filter_arg+0xd00>
    6e45:      	cmpl	$0xc, %eax
    6e48:      	je	0x7569 <generic_lsm_filter_arg+0xc89>
    6e4e:      	jmp	0x69fd <generic_lsm_filter_arg+0x11d>
    6e53:      	cmpl	$0x2a, %ecx
    6e56:      	je	0x6ee6 <generic_lsm_filter_arg+0x606>
    6e5c:      	cmpl	$0x2c, %ecx
    6e5f:      	jne	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    6e65:      	movq	%r12, %rcx
    6e68:      	leaq	0x4(%r12), %r8
    6e6d:      	movzbl	0x3(%r12), %ebp
    6e73:      	movzbl	%bpl, %esi
    6e77:      	cmpl	$0x19, %eax
    6e7a:      	jg	0x7c5c <generic_lsm_filter_arg+0x137c>
    6e80:      	leal	-0x3(%rax), %ecx
    6e83:      	cmpl	$0x2, %ecx
    6e86:      	jae	0x8201 <generic_lsm_filter_arg+0x1921>
    6e8c:      	movl	$0x0, 0x70(%rsp)
    6e94:      	movl	$0x100, %ebx            # imm = 0x100
    6e99:      	cmpb	$-0x70, %bpl
    6e9d:      	ja	0x7ee3 <generic_lsm_filter_arg+0x1603>
    6ea3:      	testb	%bpl, %bpl
    6ea6:      	je	0x6eb8 <generic_lsm_filter_arg+0x5d8>
    6ea8:      	movl	%esi, %eax
    6eaa:      	movl	$0x18, %ecx
    6eaf:      	cltd
    6eb0:      	idivl	%ecx
    6eb2:      	movl	%esi, %ebx
    6eb4:      	testl	%edx, %edx
    6eb6:      	je	0x6eda <generic_lsm_filter_arg+0x5fa>
    6eb8:      	movl	%esi, %eax
    6eba:      	movl	$0x18, %ecx
    6ebf:      	cltd
    6ec0:      	idivl	%ecx
    6ec2:      	shll	$0x3, %eax
    6ec5:      	leal	(%rax,%rax,2), %eax
    6ec8:      	addl	$0x18, %eax
    6ecb:      	movzwl	%ax, %ebx
    6ece:      	cmpl	$0x90, %ebx
    6ed4:      	ja	0x7ee3 <generic_lsm_filter_arg+0x1603>
    6eda:      	movl	%ebx, %eax
    6edc:      	cltd
    6edd:      	idivl	%ecx
    6edf:      	decl	%eax
    6ee1:      	jmp	0x8dc9 <generic_lsm_filter_arg+0x24e9>
    6ee6:      	movl	(%r12), %ebp
    6eea:      	movl	%eax, %ecx
    6eec:      	andl	$-0x2, %ecx
    6eef:      	cmpl	$0x24, %ecx
    6ef2:      	je	0x6efc <generic_lsm_filter_arg+0x61c>
    6ef4:      	testl	%ebp, %ebp
    6ef6:      	je	0x69fd <generic_lsm_filter_arg+0x11d>
    6efc:      	cmpl	$0x25, %eax
    6eff:      	ja	0x722f <generic_lsm_filter_arg+0x94f>
    6f05:      	movl	%eax, %ecx
    6f07:      	movl	$0x4000100, %edx        # imm = 0x4000100
    6f0c:      	btq	%rcx, %rdx
    6f10:      	jb	0x7420 <generic_lsm_filter_arg+0xb40>
    6f16:      	movl	$0x8000200, %edx        # imm = 0x8000200
    6f1b:      	btq	%rcx, %rdx
    6f1f:      	jb	0x72ea <generic_lsm_filter_arg+0xa0a>
    6f25:      	movabsq	$0x3000000000, %rdx     # imm = 0x3000000000
    6f2f:      	btq	%rcx, %rdx
    6f33:      	jae	0x722f <generic_lsm_filter_arg+0x94f>
    6f39:      	movw	$0x0, 0x38(%rsp)
    6f40:      	cmpl	$0x1000, %ebp           # imm = 0x1000
    6f46:      	ja	0x96cc <generic_lsm_filter_arg+0x2dec>
    6f4c:      	movq	%r11, 0x10(%rsp)
    6f51:      	leaq	(%r12,%rbp), %rcx
    6f55:      	addq	$0x8, %rcx
    6f59:      	movl	$0x4, %eax
    6f5e:      	leaq	0x38(%rsp), %rdi
    6f63:      	movl	$0x2, %edx
    6f68:      	movl	(%r12), %ecx
    6f6c:      	leaq	(%r12,%rcx), %rdx
    6f70:      	addq	$0x8, %rdx
    6f74:      	movl	$0x2, %esi
    6f79:      	callq	*%rax
    6f7b:      	movl	0x10(%r13), %ecx
    6f7f:      	testl	%ecx, %ecx
    6f81:      	je	0x9b73 <generic_lsm_filter_arg+0x3293>
    6f87:      	movzwl	0x38(%rsp), %eax
    6f8c:      	andl	$0xf000, %eax           # imm = 0xF000
    6f91:      	movl	$0x1, %ebx
    6f96:      	cmpl	%eax, %ecx
    6f98:      	je	0x9b75 <generic_lsm_filter_arg+0x3295>
    6f9e:      	movl	0x8(%r13), %ecx
    6fa2:      	cmpl	$0xd, %ecx
    6fa5:      	movq	(%rsp), %rdi
    6fa9:      	movq	0x8(%rsp), %r9
    6fae:      	movq	0x10(%rsp), %r11
    6fb3:      	jb	0x96cc <generic_lsm_filter_arg+0x2dec>
    6fb9:      	movl	0x14(%r13), %edx
    6fbd:      	testl	%edx, %edx
    6fbf:      	je	0x96cc <generic_lsm_filter_arg+0x2dec>
    6fc5:      	cmpl	%eax, %edx
    6fc7:      	je	0x9b83 <generic_lsm_filter_arg+0x32a3>
    6fcd:      	cmpl	$0x11, %ecx
    6fd0:      	jb	0x96cc <generic_lsm_filter_arg+0x2dec>
    6fd6:      	movl	0x18(%r13), %edx
    6fda:      	testl	%edx, %edx
    6fdc:      	je	0x96cc <generic_lsm_filter_arg+0x2dec>
    6fe2:      	cmpl	%eax, %edx
    6fe4:      	je	0x9b83 <generic_lsm_filter_arg+0x32a3>
    6fea:      	cmpl	$0x15, %ecx
    6fed:      	jb	0x9f4d <generic_lsm_filter_arg+0x366d>
    6ff3:      	movl	0x1c(%r13), %ecx
    6ff7:      	testl	%ecx, %ecx
    6ff9:      	je	0x9f4d <generic_lsm_filter_arg+0x366d>
    6fff:      	xorl	%ebx, %ebx
    7001:      	cmpl	%eax, %ecx
    7003:      	sete	%bl
    7006:      	jmp	0x9f4f <generic_lsm_filter_arg+0x366f>
    700b:      	leal	-0xc(%rcx), %edx
    700e:      	cmpl	$0x2, %edx
    7011:      	jae	0x754a <generic_lsm_filter_arg+0xc6a>
    7017:      	cmpl	$0x20, %eax
    701a:      	ja	0x69fd <generic_lsm_filter_arg+0x11d>
    7020:      	movl	%eax, %edx
    7022:      	movl	$0x101e, %esi           # imm = 0x101E
    7027:      	btq	%rdx, %rsi
    702b:      	jae	0x7074 <generic_lsm_filter_arg+0x794>
    702d:      	movl	0x10(%r13), %edx
    7031:      	cmpl	$0x2, %eax
    7034:      	jle	0x7512 <generic_lsm_filter_arg+0xc32>
    703a:      	leal	-0x3(%rax), %esi
    703d:      	cmpl	$0x2, %esi
    7040:      	jae	0x79d1 <generic_lsm_filter_arg+0x10f1>
    7046:      	cmpl	%edx, (%r12)
    704a:      	je	0x6ba5 <generic_lsm_filter_arg+0x2c5>
    7050:      	jmp	0x8b07 <generic_lsm_filter_arg+0x2227>
    7055:      	cmpl	$0x28, %ecx
    7058:      	je	0x768a <generic_lsm_filter_arg+0xdaa>
    705e:      	movq	%r12, %rdx
    7061:      	movl	$0x0, %ebx
    7066:      	cmpl	$0x29, %ecx
    7069:      	je	0x76ba <generic_lsm_filter_arg+0xdda>
    706f:      	jmp	0x6bb0 <generic_lsm_filter_arg+0x2d0>
    7074:      	movl	$0xc00, %esi            # imm = 0xC00
    7079:      	btq	%rdx, %rsi
    707d:      	jb	0x7647 <generic_lsm_filter_arg+0xd67>
    7083:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
    708d:      	btq	%rdx, %rsi
    7091:      	jae	0x69fd <generic_lsm_filter_arg+0x11d>
    7097:      	cmpl	$0x1f, %eax
    709a:      	jne	0x7c29 <generic_lsm_filter_arg+0x1349>
    70a0:      	movl	0x10(%r13), %esi
    70a4:      	movl	0x14(%r13), %edx
    70a8:      	cmpl	$0xc, %ecx
    70ab:      	ja	0x8823 <generic_lsm_filter_arg+0x1f43>
    70b1:      	movl	$0x1402, %eax           # imm = 0x1402
    70b6:      	btl	%ecx, %eax
    70b9:      	jae	0x8823 <generic_lsm_filter_arg+0x1f43>
    70bf:      	movl	(%r12), %eax
    70c3:      	cmpl	%eax, %esi
    70c5:      	jg	0x8833 <generic_lsm_filter_arg+0x1f53>
    70cb:      	cmpl	%edx, %eax
    70cd:      	jle	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    70d3:      	jmp	0x8833 <generic_lsm_filter_arg+0x1f53>
    70d8:      	cmpl	$0x20, %eax
    70db:      	jg	0x773f <generic_lsm_filter_arg+0xe5f>
    70e1:      	cmpl	$0x1a, %eax
    70e4:      	je	0x7885 <generic_lsm_filter_arg+0xfa5>
    70ea:      	movl	$0x0, %ebx
    70ef:      	cmpl	$0x1b, %eax
    70f2:      	jne	0x9f1b <generic_lsm_filter_arg+0x363b>
    70f8:      	movq	%r11, 0x10(%rsp)
    70fd:      	movl	0x10(%r13), %eax
    7101:      	movl	%eax, 0x38(%rsp)
    7105:      	movl	$0x0, 0x70(%rsp)
    710d:      	movl	$0x1, %eax
    7112:      	leaq	0x38(%rsp), %rsi
    7117:      	movq	(%rip), %rdi            # 0x711e <generic_lsm_filter_arg+0x83e>
    711e:      	callq	*%rax
    7120:      	testl	%ebp, %ebp
    7122:      	je	0x9f0b <generic_lsm_filter_arg+0x362b>
    7128:      	movq	%rax, %r12
    712b:      	movl	$0x0, %ebx
    7130:      	testq	%rax, %rax
    7133:      	je	0x9f0d <generic_lsm_filter_arg+0x362d>
    7139:      	movl	$0x1, %eax
    713e:      	movq	0x28(%rsp), %rsi
    7143:      	movq	(%rip), %rdi            # 0x714a <generic_lsm_filter_arg+0x86a>
    714a:      	callq	*%rax
    714c:      	testq	%rax, %rax
    714f:      	je	0x9f0b <generic_lsm_filter_arg+0x362b>
    7155:      	movq	%rax, %rdi
    7158:      	movq	%r12, 0x20(%rsp)
    715d:      	cmpl	$0x7f, %ebp
    7160:      	movl	$0x7f, %eax
    7165:      	cmovbl	%ebp, %eax
    7168:      	shll	$0x3, %eax
    716b:      	movl	%eax, (%rdi)
    716d:      	movq	%rbp, %rax
    7170:      	negq	%rax
    7173:      	movl	$0x3, %ecx
    7178:      	subq	%rbp, %rcx
    717b:      	leal	-0x4(%rbp), %edx
    717e:      	movq	%rdi, 0x60(%rsp)
    7183:      	addq	$0x7, %rdi
    7187:      	movl	$0x2, %r8d
    718d:      	subq	%rbp, %r8
    7190:      	leal	-0x3(%rbp), %r9d
    7194:      	movl	$0x1, %r10d
    719a:      	subq	%rbp, %r10
    719d:      	leal	-0x2(%rbp), %r11d
    71a1:      	decl	%ebp
    71a3:      	xorl	%ebx, %ebx
    71a5:      	movq	0x18(%rsp), %rsi
    71aa:      	leal	(%rbx,%rbp), %r12d
    71ae:      	andl	$0xfff, %r12d           # imm = 0xFFF
    71b5:      	movzbl	(%rsi,%r12), %r12d
    71ba:      	movb	%r12b, -0x3(%rdi)
    71be:      	cmpq	%rbx, %r10
    71c1:      	je	0x721b <generic_lsm_filter_arg+0x93b>
    71c3:      	leal	(%r11,%rbx), %r12d
    71c7:      	andl	$0xfff, %r12d           # imm = 0xFFF
    71ce:      	movzbl	(%rsi,%r12), %r12d
    71d3:      	movb	%r12b, -0x2(%rdi)
    71d7:      	cmpq	%rbx, %r8
    71da:      	je	0x721b <generic_lsm_filter_arg+0x93b>
    71dc:      	leal	(%r9,%rbx), %r12d
    71e0:      	andl	$0xfff, %r12d           # imm = 0xFFF
    71e7:      	movzbl	(%rsi,%r12), %r12d
    71ec:      	movb	%r12b, -0x1(%rdi)
    71f0:      	cmpq	%rbx, %rcx
    71f3:      	je	0x721b <generic_lsm_filter_arg+0x93b>
    71f5:      	cmpq	$-0x7c, %rbx
    71f9:      	je	0x721b <generic_lsm_filter_arg+0x93b>
    71fb:      	leal	(%rdx,%rbx), %r12d
    71ff:      	andl	$0xfff, %r12d           # imm = 0xFFF
    7206:      	movzbl	(%rsi,%r12), %r12d
    720b:      	movb	%r12b, (%rdi)
    720e:      	addq	$-0x4, %rbx
    7212:      	addq	$0x4, %rdi
    7216:      	cmpq	%rbx, %rax
    7219:      	jne	0x71aa <generic_lsm_filter_arg+0x8ca>
    721b:      	movl	$0x1, %eax
    7220:      	movq	0x20(%rsp), %rdi
    7225:      	movq	0x60(%rsp), %rsi
    722a:      	jmp	0x83c8 <generic_lsm_filter_arg+0x1ae8>
    722f:      	addl	$-0x3, %eax
    7232:      	cmpl	$0x2, %eax
    7235:      	jae	0x96cc <generic_lsm_filter_arg+0x2dec>
    723b:      	movl	$0x0, 0x70(%rsp)
    7243:      	cmpl	$0x1000, %ebp           # imm = 0x1000
    7249:      	ja	0x96cc <generic_lsm_filter_arg+0x2dec>
    724f:      	movzwl	%bp, %eax
    7252:      	cmpl	$0x90, %eax
    7257:      	movq	%r11, 0x10(%rsp)
    725c:      	ja	0x8023 <generic_lsm_filter_arg+0x1743>
    7262:      	testw	%bp, %bp
    7265:      	je	0x7277 <generic_lsm_filter_arg+0x997>
    7267:      	movl	%ebp, %eax
    7269:      	movl	$0x18, %ecx
    726e:      	cltd
    726f:      	idivl	%ecx
    7271:      	movl	%ebp, %esi
    7273:      	testl	%edx, %edx
    7275:      	je	0x7299 <generic_lsm_filter_arg+0x9b9>
    7277:      	movl	%ebp, %eax
    7279:      	movl	$0x18, %ecx
    727e:      	cltd
    727f:      	idivl	%ecx
    7281:      	shll	$0x3, %eax
    7284:      	leal	(%rax,%rax,2), %eax
    7287:      	addl	$0x18, %eax
    728a:      	movzwl	%ax, %esi
    728d:      	cmpl	$0x90, %esi
    7293:      	ja	0x805b <generic_lsm_filter_arg+0x177b>
    7299:      	movl	%esi, %eax
    729b:      	cltd
    729c:      	idivl	%ecx
    729e:      	decl	%eax
    72a0:      	jmp	0x8c2f <generic_lsm_filter_arg+0x234f>
    72a5:      	cmpl	$0x20, %eax
    72a8:      	ja	0x69fd <generic_lsm_filter_arg+0x11d>
    72ae:      	movl	%eax, %ecx
    72b0:      	movl	$0x101e, %edx           # imm = 0x101E
    72b5:      	btq	%rcx, %rdx
    72b9:      	jae	0x7a1c <generic_lsm_filter_arg+0x113c>
    72bf:      	movl	0x10(%r13), %ecx
    72c3:      	cmpl	$0x2, %eax
    72c6:      	jle	0x7f37 <generic_lsm_filter_arg+0x1657>
    72cc:      	leal	-0x3(%rax), %edx
    72cf:      	cmpl	$0x2, %edx
    72d2:      	jae	0x8689 <generic_lsm_filter_arg+0x1da9>
    72d8:      	movzwl	(%r12), %edx
    72dd:      	cmpl	%edx, %ecx
    72df:      	je	0x6ba5 <generic_lsm_filter_arg+0x2c5>
    72e5:      	jmp	0x87eb <generic_lsm_filter_arg+0x1f0b>
    72ea:      	movq	%r11, 0x10(%rsp)
    72ef:      	movl	0x10(%r13), %eax
    72f3:      	movl	%eax, 0x38(%rsp)
    72f7:      	movl	$0x0, 0x70(%rsp)
    72ff:      	movl	$0x1, %eax
    7304:      	leaq	0x38(%rsp), %rsi
    7309:      	movq	(%rip), %rdi            # 0x7310 <generic_lsm_filter_arg+0xa30>
    7310:      	callq	*%rax
    7312:      	testl	%ebp, %ebp
    7314:      	je	0x9b73 <generic_lsm_filter_arg+0x3293>
    731a:      	movl	$0x0, %ebx
    731f:      	testq	%rax, %rax
    7322:      	je	0x9b75 <generic_lsm_filter_arg+0x3295>
    7328:      	movq	%rax, 0x18(%rsp)
    732d:      	movl	$0x1, %eax
    7332:      	movq	0x28(%rsp), %rsi
    7337:      	movq	(%rip), %rdi            # 0x733e <generic_lsm_filter_arg+0xa5e>
    733e:      	callq	*%rax
    7340:      	testq	%rax, %rax
    7343:      	je	0x9b73 <generic_lsm_filter_arg+0x3293>
    7349:      	movq	%rax, %rdi
    734c:      	cmpl	$0x7f, %ebp
    734f:      	movl	$0x7f, %eax
    7354:      	cmovbl	%ebp, %eax
    7357:      	shll	$0x3, %eax
    735a:      	movl	%eax, (%rdi)
    735c:      	movq	%rbp, %rax
    735f:      	negq	%rax
    7362:      	movl	$0x3, %ecx
    7367:      	subq	%rbp, %rcx
    736a:      	leal	-0x4(%rbp), %edx
    736d:      	movq	%rdi, 0x20(%rsp)
    7372:      	addq	$0x7, %rdi
    7376:      	movl	$0x2, %r8d
    737c:      	subq	%rbp, %r8
    737f:      	leal	-0x3(%rbp), %r9d
    7383:      	movl	$0x1, %r10d
    7389:      	subq	%rbp, %r10
    738c:      	leal	-0x2(%rbp), %r11d
    7390:      	decl	%ebp
    7392:      	xorl	%ebx, %ebx
    7394:      	movq	%r12, %rsi
    7397:      	leal	(%rbx,%rbp), %r12d
    739b:      	andl	$0xfff, %r12d           # imm = 0xFFF
    73a2:      	movzbl	0x4(%rsi,%r12), %r12d
    73a8:      	movb	%r12b, -0x3(%rdi)
    73ac:      	cmpq	%rbx, %r10
    73af:      	je	0x740c <generic_lsm_filter_arg+0xb2c>
    73b1:      	leal	(%r11,%rbx), %r12d
    73b5:      	andl	$0xfff, %r12d           # imm = 0xFFF
    73bc:      	movzbl	0x4(%rsi,%r12), %r12d
    73c2:      	movb	%r12b, -0x2(%rdi)
    73c6:      	cmpq	%rbx, %r8
    73c9:      	je	0x740c <generic_lsm_filter_arg+0xb2c>
    73cb:      	leal	(%r9,%rbx), %r12d
    73cf:      	andl	$0xfff, %r12d           # imm = 0xFFF
    73d6:      	movzbl	0x4(%rsi,%r12), %r12d
    73dc:      	movb	%r12b, -0x1(%rdi)
    73e0:      	cmpq	%rbx, %rcx
    73e3:      	je	0x740c <generic_lsm_filter_arg+0xb2c>
    73e5:      	cmpq	$-0x7c, %rbx
    73e9:      	je	0x740c <generic_lsm_filter_arg+0xb2c>
    73eb:      	leal	(%rdx,%rbx), %r12d
    73ef:      	andl	$0xfff, %r12d           # imm = 0xFFF
    73f6:      	movzbl	0x4(%rsi,%r12), %r12d
    73fc:      	movb	%r12b, (%rdi)
    73ff:      	addq	$-0x4, %rbx
    7403:      	addq	$0x4, %rdi
    7407:      	cmpq	%rbx, %rax
    740a:      	jne	0x7397 <generic_lsm_filter_arg+0xab7>
    740c:      	movl	$0x1, %eax
    7411:      	movq	0x18(%rsp), %rdi
    7416:      	movq	0x20(%rsp), %rsi
    741b:      	jmp	0x9b67 <generic_lsm_filter_arg+0x3287>
    7420:      	movq	%r11, 0x10(%rsp)
    7425:      	movl	0x10(%r13), %eax
    7429:      	movl	%eax, 0x38(%rsp)
    742d:      	movl	$0x0, 0x70(%rsp)
    7435:      	movl	$0x1, %eax
    743a:      	leaq	0x38(%rsp), %rsi
    743f:      	movq	(%rip), %rdi            # 0x7446 <generic_lsm_filter_arg+0xb66>
    7446:      	callq	*%rax
    7448:      	testl	%ebp, %ebp
    744a:      	je	0x9b73 <generic_lsm_filter_arg+0x3293>
    7450:      	movl	$0x0, %ebx
    7455:      	testq	%rax, %rax
    7458:      	je	0x9b75 <generic_lsm_filter_arg+0x3295>
    745e:      	movq	%rax, 0x18(%rsp)
    7463:      	movl	$0x1, %eax
    7468:      	movq	0x28(%rsp), %rsi
    746d:      	movq	(%rip), %rdi            # 0x7474 <generic_lsm_filter_arg+0xb94>
    7474:      	callq	*%rax
    7476:      	testq	%rax, %rax
    7479:      	je	0x9b73 <generic_lsm_filter_arg+0x3293>
    747f:      	movq	%rax, %rbx
    7482:      	addq	$0x4, %r12
    7486:      	cmpl	$0xff, %ebp
    748c:      	movl	$0xff, %eax
    7491:      	cmovael	%eax, %ebp
    7494:      	leal	(,%rbp,8), %eax
    749b:      	movl	%eax, (%rbx)
    749d:      	movq	%rbx, %rdi
    74a0:      	addq	$0x4, %rdi
    74a4:      	movl	$0x4, %eax
    74a9:      	movl	%ebp, %esi
    74ab:      	movq	%r12, %rdx
    74ae:      	callq	*%rax
    74b0:      	movl	$0x1, %eax
    74b5:      	movq	0x18(%rsp), %rdi
    74ba:      	movq	%rbx, %rsi
    74bd:      	jmp	0x9b67 <generic_lsm_filter_arg+0x3287>
    74c2:      	leal	-0x1(%rax), %edx
    74c5:      	cmpl	$0x4, %edx
    74c8:      	jb	0x7569 <generic_lsm_filter_arg+0xc89>
    74ce:      	jmp	0x69fd <generic_lsm_filter_arg+0x11d>
    74d3:      	movl	0x4(%r12), %ebp
    74d8:      	addq	$0x8, %r12
    74dc:      	movq	%r12, 0x18(%rsp)
    74e1:      	cmpl	$0x19, %eax
    74e4:      	jg	0x7ad2 <generic_lsm_filter_arg+0x11f2>
    74ea:      	leal	-0x3(%rax), %ecx
    74ed:      	cmpl	$0x2, %ecx
    74f0:      	jb	0x83d7 <generic_lsm_filter_arg+0x1af7>
    74f6:      	cmpl	$0x8, %eax
    74f9:      	je	0x8331 <generic_lsm_filter_arg+0x1a51>
    74ff:      	movl	$0x0, %ebx
    7504:      	cmpl	$0x9, %eax
    7507:      	je	0x7af2 <generic_lsm_filter_arg+0x1212>
    750d:      	jmp	0x9f1b <generic_lsm_filter_arg+0x363b>
    7512:      	cmpl	$0x1, %eax
    7515:      	je	0x7dc4 <generic_lsm_filter_arg+0x14e4>
    751b:      	cmpl	$0x2, %eax
    751e:      	jne	0x8b07 <generic_lsm_filter_arg+0x2227>
    7524:      	cmpl	$0xc, %ecx
    7527:      	ja	0x8afd <generic_lsm_filter_arg+0x221d>
    752d:      	movl	$0x1402, %esi           # imm = 0x1402
    7532:      	btl	%ecx, %esi
    7535:      	jae	0x8afd <generic_lsm_filter_arg+0x221d>
    753b:      	cmpl	%edx, (%r12)
    753f:      	jl	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    7545:      	jmp	0x8b07 <generic_lsm_filter_arg+0x2227>
    754a:      	cmpl	$0x1c, %ecx
    754d:      	jne	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    7553:      	cmpl	$0x20, %eax
    7556:      	ja	0x69fd <generic_lsm_filter_arg+0x11d>
    755c:      	movl	%eax, %edx
    755e:      	movl	$0x101e, %esi           # imm = 0x101E
    7563:      	btq	%rdx, %rsi
    7567:      	jae	0x758d <generic_lsm_filter_arg+0xcad>
    7569:      	movq	0x10(%r13), %rdx
    756d:      	cmpl	$0x2, %eax
    7570:      	jle	0x75b1 <generic_lsm_filter_arg+0xcd1>
    7572:      	leal	-0x3(%rax), %esi
    7575:      	cmpl	$0x2, %esi
    7578:      	jae	0x7827 <generic_lsm_filter_arg+0xf47>
    757e:      	cmpq	%rdx, (%r12)
    7582:      	je	0x6ba5 <generic_lsm_filter_arg+0x2c5>
    7588:      	jmp	0x85f2 <generic_lsm_filter_arg+0x1d12>
    758d:      	movl	$0xc00, %esi            # imm = 0xC00
    7592:      	btq	%rdx, %rsi
    7596:      	jb	0x75e0 <generic_lsm_filter_arg+0xd00>
    7598:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
    75a2:      	btq	%rdx, %rsi
    75a6:      	jb	0x784b <generic_lsm_filter_arg+0xf6b>
    75ac:      	jmp	0x69fd <generic_lsm_filter_arg+0x11d>
    75b1:      	cmpl	$0x1, %eax
    75b4:      	je	0x7ab5 <generic_lsm_filter_arg+0x11d5>
    75ba:      	cmpl	$0x2, %eax
    75bd:      	jne	0x85f2 <generic_lsm_filter_arg+0x1d12>
    75c3:      	cmpl	$0xc, %ecx
    75c6:      	je	0x75d1 <generic_lsm_filter_arg+0xcf1>
    75c8:      	cmpl	$0xa, %ecx
    75cb:      	jne	0x85e8 <generic_lsm_filter_arg+0x1d08>
    75d1:      	cmpq	%rdx, (%r12)
    75d5:      	jl	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    75db:      	jmp	0x85f2 <generic_lsm_filter_arg+0x1d12>
    75e0:      	movq	%r11, %rbp
    75e3:      	movzbl	0x10(%r13), %eax
    75e8:      	movl	%eax, 0x70(%rsp)
    75ec:      	movl	$0x1, %eax
    75f1:      	movq	0x28(%rsp), %rsi
    75f6:      	movq	(%rip), %rdi            # 0x75fd <generic_lsm_filter_arg+0xd1d>
    75fd:      	callq	*%rax
    75ff:      	testq	%rax, %rax
    7602:      	je	0x831e <generic_lsm_filter_arg+0x1a3e>
    7608:      	movq	%rax, %rdi
    760b:      	movq	(%r12), %rax
    760f:      	movq	%rax, 0x38(%rsp)
    7614:      	movl	$0x1, %eax
    7619:      	leaq	0x38(%rsp), %rsi
    761e:      	callq	*%rax
    7620:      	movl	0x4(%r13), %ecx
    7624:      	cmpl	$0xb, %ecx
    7627:      	je	0x8009 <generic_lsm_filter_arg+0x1729>
    762d:      	cmpl	$0xa, %ecx
    7630:      	movq	(%rsp), %rdi
    7634:      	movq	0x8(%rsp), %r9
    7639:      	movq	%rbp, %r11
    763c:      	je	0x810f <generic_lsm_filter_arg+0x182f>
    7642:      	jmp	0x811d <generic_lsm_filter_arg+0x183d>
    7647:      	movq	%r11, %rbp
    764a:      	movzbl	0x10(%r13), %eax
    764f:      	movl	%eax, 0x70(%rsp)
    7653:      	movl	$0x1, %eax
    7658:      	movq	0x28(%rsp), %rsi
    765d:      	movq	(%rip), %rdi            # 0x7664 <generic_lsm_filter_arg+0xd84>
    7664:      	callq	*%rax
    7666:      	testq	%rax, %rax
    7669:      	je	0x831e <generic_lsm_filter_arg+0x1a3e>
    766f:      	movq	%rax, %rdi
    7672:      	movl	(%r12), %eax
    7676:      	movq	%rax, 0x38(%rsp)
    767b:      	movl	$0x1, %eax
    7680:      	leaq	0x38(%rsp), %rsi
    7685:      	jmp	0x82e5 <generic_lsm_filter_arg+0x1a05>
    768a:      	movzwl	(%r12), %edx
    768f:      	movw	%dx, 0x5e(%rsp)
    7694:      	movzwl	0x2(%r12), %edx
    769a:      	movw	%dx, 0x58(%rsp)
    769f:      	movq	0x8(%r12), %rdx
    76a4:      	movq	%rdx, 0x38(%rsp)
    76a9:      	movq	0x10(%r12), %rdx
    76ae:      	movq	%rdx, 0x40(%rsp)
    76b3:      	leaq	0x38(%rsp), %r12
    76b8:      	xorl	%edx, %edx
    76ba:      	cmpl	$0x13, %eax
    76bd:      	jle	0x76e6 <generic_lsm_filter_arg+0xe06>
    76bf:      	cmpl	$0x17, %eax
    76c2:      	jg	0x771a <generic_lsm_filter_arg+0xe3a>
    76c4:      	leal	-0x14(%rax), %ecx
    76c7:      	cmpl	$0x2, %ecx
    76ca:      	jb	0x7c99 <generic_lsm_filter_arg+0x13b9>
    76d0:      	leal	-0x16(%rax), %ecx
    76d3:      	movl	$0x0, %ebx
    76d8:      	cmpl	$0x2, %ecx
    76db:      	jb	0x7c8e <generic_lsm_filter_arg+0x13ae>
    76e1:      	jmp	0x6bb0 <generic_lsm_filter_arg+0x2d0>
    76e6:      	cmpl	$0xf, %eax
    76e9:      	jle	0x7980 <generic_lsm_filter_arg+0x10a0>
    76ef:      	cmpl	$0x11, %eax
    76f2:      	jg	0x7c7b <generic_lsm_filter_arg+0x139b>
    76f8:      	cmpl	$0x10, %eax
    76fb:      	je	0x7c8e <generic_lsm_filter_arg+0x13ae>
    7701:      	movl	$0x0, %ebx
    7706:      	cmpl	$0x11, %eax
    7709:      	jne	0x6bb0 <generic_lsm_filter_arg+0x2d0>
    770f:      	movzwl	0x24(%r12), %ebx
    7715:      	jmp	0x8492 <generic_lsm_filter_arg+0x1bb2>
    771a:      	cmpl	$0x1b, %eax
    771d:      	jg	0x7cda <generic_lsm_filter_arg+0x13fa>
    7723:      	cmpl	$0x18, %eax
    7726:      	je	0x7d19 <generic_lsm_filter_arg+0x1439>
    772c:      	movl	$0x0, %ebx
    7731:      	cmpl	$0x19, %eax
    7734:      	je	0x7d0a <generic_lsm_filter_arg+0x142a>
    773a:      	jmp	0x6bb0 <generic_lsm_filter_arg+0x2d0>
    773f:      	cmpl	$0x21, %eax
    7742:      	je	0x7dea <generic_lsm_filter_arg+0x150a>
    7748:      	movl	$0x0, %ebx
    774d:      	cmpl	$0x22, %eax
    7750:      	jne	0x9f1b <generic_lsm_filter_arg+0x363b>
    7756:      	xorl	%ebx, %ebx
    7758:      	xorl	%r12d, %r12d
    775b:      	movq	%r11, %r15
    775e:      	movl	0x10(%r13,%rbx,4), %eax
    7763:      	movl	%eax, 0x38(%rsp)
    7767:      	movl	$0x1, %eax
    776c:      	leaq	0x38(%rsp), %rsi
    7771:      	movq	(%rip), %rdi            # 0x7778 <generic_lsm_filter_arg+0xe98>
    7778:      	callq	*%rax
    777a:      	testq	%rax, %rax
    777d:      	je	0x8a96 <generic_lsm_filter_arg+0x21b6>
    7783:      	testl	%ebp, %ebp
    7785:      	movq	%r15, %r11
    7788:      	movq	0x68(%rsp), %r15
    778d:      	je	0x7804 <generic_lsm_filter_arg+0xf24>
    778f:      	movq	0x18(%rsp), %rdx
    7794:      	xorl	%ecx, %ecx
    7796:      	jmp	0x77a3 <generic_lsm_filter_arg+0xec3>
    7798:      	incq	%rcx
    779b:      	incq	%rdx
    779e:      	cmpq	%rbp, %rcx
    77a1:      	je	0x7804 <generic_lsm_filter_arg+0xf24>
    77a3:      	xorl	%esi, %esi
    77a5:      	nopw	%cs:(%rax,%rax)
    77b0:      	leaq	(%rcx,%rsi), %rdi
    77b4:      	cmpq	%rbp, %rdi
    77b7:      	jae	0x7798 <generic_lsm_filter_arg+0xeb8>
    77b9:      	movsbl	(%rax,%rsi), %edi
    77bd:      	testl	%edi, %edi
    77bf:      	je	0x77fc <generic_lsm_filter_arg+0xf1c>
    77c1:      	movsbl	(%rdx,%rsi), %r9d
    77c6:      	leal	-0x41(%r9), %r10d
    77ca:      	movl	%r9d, %r8d
    77cd:      	orl	$0x20, %r8d
    77d1:      	cmpl	$0x1a, %r10d
    77d5:      	cmovael	%r9d, %r8d
    77d9:      	leal	-0x41(%rdi), %r10d
    77dd:      	movl	%edi, %r9d
    77e0:      	orl	$0x20, %r9d
    77e4:      	cmpl	$0x1a, %r10d
    77e8:      	cmovael	%edi, %r9d
    77ec:      	cmpq	$0x62, %rsi
    77f0:      	ja	0x7798 <generic_lsm_filter_arg+0xeb8>
    77f2:      	incq	%rsi
    77f5:      	cmpl	%r9d, %r8d
    77f8:      	je	0x77b0 <generic_lsm_filter_arg+0xed0>
    77fa:      	jmp	0x7798 <generic_lsm_filter_arg+0xeb8>
    77fc:      	testl	%ecx, %ecx
    77fe:      	jns	0x8f6e <generic_lsm_filter_arg+0x268e>
    7804:      	leal	0xc(%r12), %eax
    7809:      	cmpl	0x8(%r13), %eax
    780d:      	jae	0x7820 <generic_lsm_filter_arg+0xf40>
    780f:      	addl	$0x4, %r12d
    7813:      	incq	%rbx
    7816:      	cmpq	$0x64, %rbx
    781a:      	jne	0x775b <generic_lsm_filter_arg+0xe7b>
    7820:      	xorl	%ebx, %ebx
    7822:      	jmp	0x8f73 <generic_lsm_filter_arg+0x2693>
    7827:      	cmpl	$0xc, %eax
    782a:      	jne	0x85f2 <generic_lsm_filter_arg+0x1d12>
    7830:      	testq	%rdx, (%r12)
    7834:      	jne	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    783a:      	jmp	0x85f2 <generic_lsm_filter_arg+0x1d12>
    783f:      	leal	-0x1f(%rax), %edx
    7842:      	cmpl	$0x2, %edx
    7845:      	jae	0x8127 <generic_lsm_filter_arg+0x1847>
    784b:      	cmpl	$0x1f, %eax
    784e:      	jne	0x79a5 <generic_lsm_filter_arg+0x10c5>
    7854:      	movq	0x10(%r13), %rsi
    7858:      	movq	0x18(%r13), %rdx
    785c:      	cmpl	$0xa, %ecx
    785f:      	je	0x786a <generic_lsm_filter_arg+0xf8a>
    7861:      	cmpl	$0xc, %ecx
    7864:      	jne	0x83f2 <generic_lsm_filter_arg+0x1b12>
    786a:      	movq	(%r12), %rax
    786e:      	cmpq	%rax, %rsi
    7871:      	jg	0x8404 <generic_lsm_filter_arg+0x1b24>
    7877:      	cmpq	%rdx, %rax
    787a:      	jle	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    7880:      	jmp	0x8404 <generic_lsm_filter_arg+0x1b24>
    7885:      	movq	%r11, 0x10(%rsp)
    788a:      	movl	0x10(%r13), %eax
    788e:      	movl	%eax, 0x38(%rsp)
    7892:      	movl	$0x0, 0x70(%rsp)
    789a:      	movl	$0x1, %eax
    789f:      	leaq	0x38(%rsp), %rsi
    78a4:      	movq	(%rip), %rdi            # 0x78ab <generic_lsm_filter_arg+0xfcb>
    78ab:      	callq	*%rax
    78ad:      	testl	%ebp, %ebp
    78af:      	je	0x9f0b <generic_lsm_filter_arg+0x362b>
    78b5:      	movq	%rax, %r12
    78b8:      	movl	$0x0, %ebx
    78bd:      	testq	%rax, %rax
    78c0:      	je	0x9f0d <generic_lsm_filter_arg+0x362d>
    78c6:      	movl	$0x1, %eax
    78cb:      	movq	0x28(%rsp), %rsi
    78d0:      	movq	(%rip), %rdi            # 0x78d7 <generic_lsm_filter_arg+0xff7>
    78d7:      	callq	*%rax
    78d9:      	testq	%rax, %rax
    78dc:      	je	0x9f0b <generic_lsm_filter_arg+0x362b>
    78e2:      	cmpl	$0xff, %ebp
    78e8:      	movl	$0xff, %ecx
    78ed:      	cmovael	%ecx, %ebp
    78f0:      	leal	(,%rbp,8), %ecx
    78f7:      	movl	%ecx, (%rax)
    78f9:      	movq	%rax, %rdi
    78fc:      	addq	$0x4, %rdi
    7900:      	movq	%rax, %rbx
    7903:      	movl	$0x4, %eax
    7908:      	movq	0x18(%rsp), %rdx
    790d:      	movl	%ebp, %esi
    790f:      	callq	*%rax
    7911:      	movl	$0x1, %eax
    7916:      	jmp	0x83c2 <generic_lsm_filter_arg+0x1ae2>
    791b:      	movl	$0x0, 0x70(%rsp)
    7923:      	cmpl	$0x1000, %ebp           # imm = 0x1000
    7929:      	ja	0x83eb <generic_lsm_filter_arg+0x1b0b>
    792f:      	movzwl	%bp, %eax
    7932:      	cmpl	$0x90, %eax
    7937:      	ja	0x8574 <generic_lsm_filter_arg+0x1c94>
    793d:      	testw	%bp, %bp
    7940:      	je	0x7952 <generic_lsm_filter_arg+0x1072>
    7942:      	movl	%ebp, %eax
    7944:      	movl	$0x18, %ecx
    7949:      	cltd
    794a:      	idivl	%ecx
    794c:      	movl	%ebp, %esi
    794e:      	testl	%edx, %edx
    7950:      	je	0x7974 <generic_lsm_filter_arg+0x1094>
    7952:      	movl	%ebp, %eax
    7954:      	movl	$0x18, %ecx
    7959:      	cltd
    795a:      	idivl	%ecx
    795c:      	shll	$0x3, %eax
    795f:      	leal	(%rax,%rax,2), %eax
    7962:      	addl	$0x18, %eax
    7965:      	movzwl	%ax, %esi
    7968:      	cmpl	$0x90, %esi
    796e:      	ja	0x85ac <generic_lsm_filter_arg+0x1ccc>
    7974:      	movl	%esi, %eax
    7976:      	cltd
    7977:      	idivl	%ecx
    7979:      	decl	%eax
    797b:      	jmp	0x91bc <generic_lsm_filter_arg+0x28dc>
    7980:      	cmpl	$0xd, %eax
    7983:      	je	0x7d19 <generic_lsm_filter_arg+0x1439>
    7989:      	cmpl	$0xe, %eax
    798c:      	je	0x7d0a <generic_lsm_filter_arg+0x142a>
    7992:      	movl	$0x0, %ebx
    7997:      	cmpl	$0xf, %eax
    799a:      	je	0x7c99 <generic_lsm_filter_arg+0x13b9>
    79a0:      	jmp	0x6bb0 <generic_lsm_filter_arg+0x2d0>
    79a5:      	movq	0x10(%r13), %rsi
    79a9:      	movq	0x18(%r13), %rax
    79ad:      	cmpl	$0xc, %ecx
    79b0:      	je	0x79bb <generic_lsm_filter_arg+0x10db>
    79b2:      	cmpl	$0xa, %ecx
    79b5:      	jne	0x8442 <generic_lsm_filter_arg+0x1b62>
    79bb:      	movq	(%r12), %rdx
    79bf:      	cmpq	%rdx, %rsi
    79c2:      	setle	%sil
    79c6:      	cmpq	%rax, %rdx
    79c9:      	setle	%al
    79cc:      	jmp	0x8453 <generic_lsm_filter_arg+0x1b73>
    79d1:      	cmpl	$0xc, %eax
    79d4:      	jne	0x8b07 <generic_lsm_filter_arg+0x2227>
    79da:      	testl	%edx, (%r12)
    79de:      	jne	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    79e4:      	jmp	0x8b07 <generic_lsm_filter_arg+0x2227>
    79e9:      	movl	$0xc00, %edx            # imm = 0xC00
    79ee:      	btq	%rcx, %rdx
    79f2:      	jb	0x7f5b <generic_lsm_filter_arg+0x167b>
    79f8:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
    7a02:      	btq	%rcx, %rdx
    7a06:      	jae	0x69fd <generic_lsm_filter_arg+0x11d>
    7a0c:      	cmpl	$0x1f, %eax
    7a0f:      	jne	0x86dd <generic_lsm_filter_arg+0x1dfd>
    7a15:      	movzbl	(%r12), %eax
    7a1a:      	jmp	0x7a4d <generic_lsm_filter_arg+0x116d>
    7a1c:      	movl	$0xc00, %edx            # imm = 0xC00
    7a21:      	btq	%rcx, %rdx
    7a25:      	jb	0x7f9f <generic_lsm_filter_arg+0x16bf>
    7a2b:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
    7a35:      	btq	%rcx, %rdx
    7a39:      	jae	0x69fd <generic_lsm_filter_arg+0x11d>
    7a3f:      	cmpl	$0x1f, %eax
    7a42:      	jne	0x86e8 <generic_lsm_filter_arg+0x1e08>
    7a48:      	movzwl	(%r12), %eax
    7a4d:      	cmpl	%eax, 0x10(%r13)
    7a51:      	ja	0x7a5d <generic_lsm_filter_arg+0x117d>
    7a53:      	cmpl	%eax, 0x14(%r13)
    7a57:      	jae	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    7a5d:      	movl	0x8(%r13), %ecx
    7a61:      	cmpl	$0x11, %ecx
    7a64:      	jb	0x69fd <generic_lsm_filter_arg+0x11d>
    7a6a:      	cmpl	%eax, 0x18(%r13)
    7a6e:      	ja	0x7a7a <generic_lsm_filter_arg+0x119a>
    7a70:      	cmpl	%eax, 0x1c(%r13)
    7a74:      	jae	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    7a7a:      	cmpl	$0x19, %ecx
    7a7d:      	jb	0x69fd <generic_lsm_filter_arg+0x11d>
    7a83:      	cmpl	%eax, 0x20(%r13)
    7a87:      	ja	0x7a93 <generic_lsm_filter_arg+0x11b3>
    7a89:      	cmpl	%eax, 0x24(%r13)
    7a8d:      	jae	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    7a93:      	cmpl	$0x21, %ecx
    7a96:      	jb	0x69fd <generic_lsm_filter_arg+0x11d>
    7a9c:      	cmpl	%eax, 0x28(%r13)
    7aa0:      	ja	0x69fd <generic_lsm_filter_arg+0x11d>
    7aa6:      	cmpl	%eax, 0x2c(%r13)
    7aaa:      	jae	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    7ab0:      	jmp	0x69fd <generic_lsm_filter_arg+0x11d>
    7ab5:      	cmpl	$0xc, %ecx
    7ab8:      	je	0x7ac3 <generic_lsm_filter_arg+0x11e3>
    7aba:      	cmpl	$0xa, %ecx
    7abd:      	jne	0x85dc <generic_lsm_filter_arg+0x1cfc>
    7ac3:      	cmpq	%rdx, (%r12)
    7ac7:      	jg	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    7acd:      	jmp	0x85f2 <generic_lsm_filter_arg+0x1d12>
    7ad2:      	cmpl	$0x20, %eax
    7ad5:      	jg	0x816d <generic_lsm_filter_arg+0x188d>
    7adb:      	cmpl	$0x1a, %eax
    7ade:      	je	0x8331 <generic_lsm_filter_arg+0x1a51>
    7ae4:      	movl	$0x0, %ebx
    7ae9:      	cmpl	$0x1b, %eax
    7aec:      	jne	0x9f1b <generic_lsm_filter_arg+0x363b>
    7af2:      	movq	%r11, 0x10(%rsp)
    7af7:      	movl	0x10(%r13), %eax
    7afb:      	movl	%eax, 0x38(%rsp)
    7aff:      	movl	$0x0, 0x70(%rsp)
    7b07:      	movl	$0x1, %eax
    7b0c:      	leaq	0x38(%rsp), %rsi
    7b11:      	movq	(%rip), %rdi            # 0x7b18 <generic_lsm_filter_arg+0x1238>
    7b18:      	callq	*%rax
    7b1a:      	testl	%ebp, %ebp
    7b1c:      	je	0x9f0b <generic_lsm_filter_arg+0x362b>
    7b22:      	movq	%rax, %r12
    7b25:      	movl	$0x0, %ebx
    7b2a:      	testq	%rax, %rax
    7b2d:      	je	0x9f0d <generic_lsm_filter_arg+0x362d>
    7b33:      	movl	$0x1, %eax
    7b38:      	movq	0x28(%rsp), %rsi
    7b3d:      	movq	(%rip), %rdi            # 0x7b44 <generic_lsm_filter_arg+0x1264>
    7b44:      	callq	*%rax
    7b46:      	testq	%rax, %rax
    7b49:      	je	0x9f0b <generic_lsm_filter_arg+0x362b>
    7b4f:      	movq	%rax, %rdi
    7b52:      	movq	%r12, 0x20(%rsp)
    7b57:      	cmpl	$0x7f, %ebp
    7b5a:      	movl	$0x7f, %eax
    7b5f:      	cmovbl	%ebp, %eax
    7b62:      	shll	$0x3, %eax
    7b65:      	movl	%eax, (%rdi)
    7b67:      	movq	%rbp, %rax
    7b6a:      	negq	%rax
    7b6d:      	movl	$0x3, %ecx
    7b72:      	subq	%rbp, %rcx
    7b75:      	leal	-0x4(%rbp), %edx
    7b78:      	movq	%rdi, 0x60(%rsp)
    7b7d:      	addq	$0x7, %rdi
    7b81:      	movl	$0x2, %r8d
    7b87:      	subq	%rbp, %r8
    7b8a:      	leal	-0x3(%rbp), %r9d
    7b8e:      	movl	$0x1, %r10d
    7b94:      	subq	%rbp, %r10
    7b97:      	leal	-0x2(%rbp), %r11d
    7b9b:      	decl	%ebp
    7b9d:      	xorl	%ebx, %ebx
    7b9f:      	movq	0x18(%rsp), %rsi
    7ba4:      	leal	(%rbx,%rbp), %r12d
    7ba8:      	andl	$0xfff, %r12d           # imm = 0xFFF
    7baf:      	movzbl	(%rsi,%r12), %r12d
    7bb4:      	movb	%r12b, -0x3(%rdi)
    7bb8:      	cmpq	%rbx, %r10
    7bbb:      	je	0x7c15 <generic_lsm_filter_arg+0x1335>
    7bbd:      	leal	(%r11,%rbx), %r12d
    7bc1:      	andl	$0xfff, %r12d           # imm = 0xFFF
    7bc8:      	movzbl	(%rsi,%r12), %r12d
    7bcd:      	movb	%r12b, -0x2(%rdi)
    7bd1:      	cmpq	%rbx, %r8
    7bd4:      	je	0x7c15 <generic_lsm_filter_arg+0x1335>
    7bd6:      	leal	(%r9,%rbx), %r12d
    7bda:      	andl	$0xfff, %r12d           # imm = 0xFFF
    7be1:      	movzbl	(%rsi,%r12), %r12d
    7be6:      	movb	%r12b, -0x1(%rdi)
    7bea:      	cmpq	%rbx, %rcx
    7bed:      	je	0x7c15 <generic_lsm_filter_arg+0x1335>
    7bef:      	cmpq	$-0x7c, %rbx
    7bf3:      	je	0x7c15 <generic_lsm_filter_arg+0x1335>
    7bf5:      	leal	(%rdx,%rbx), %r12d
    7bf9:      	andl	$0xfff, %r12d           # imm = 0xFFF
    7c00:      	movzbl	(%rsi,%r12), %r12d
    7c05:      	movb	%r12b, (%rdi)
    7c08:      	addq	$-0x4, %rbx
    7c0c:      	addq	$0x4, %rdi
    7c10:      	cmpq	%rbx, %rax
    7c13:      	jne	0x7ba4 <generic_lsm_filter_arg+0x12c4>
    7c15:      	movl	$0x1, %eax
    7c1a:      	movq	0x20(%rsp), %rdi
    7c1f:      	movq	0x60(%rsp), %rsi
    7c24:      	jmp	0x83c8 <generic_lsm_filter_arg+0x1ae8>
    7c29:      	movl	0x10(%r13), %esi
    7c2d:      	movl	0x14(%r13), %eax
    7c31:      	cmpl	$0xc, %ecx
    7c34:      	ja	0x887a <generic_lsm_filter_arg+0x1f9a>
    7c3a:      	movl	$0x1402, %edx           # imm = 0x1402
    7c3f:      	btl	%ecx, %edx
    7c42:      	jae	0x887a <generic_lsm_filter_arg+0x1f9a>
    7c48:      	movl	(%r12), %edx
    7c4c:      	cmpl	%edx, %esi
    7c4e:      	setle	%sil
    7c52:      	cmpl	%eax, %edx
    7c54:      	setle	%al
    7c57:      	jmp	0x8889 <generic_lsm_filter_arg+0x1fa9>
    7c5c:      	cmpl	$0x1c, %eax
    7c5f:      	je	0x82aa <generic_lsm_filter_arg+0x19ca>
    7c65:      	movq	%r8, 0x18(%rsp)
    7c6a:      	movq	%rsi, %r12
    7c6d:      	cmpl	$0x1a, %eax
    7c70:      	je	0x8212 <generic_lsm_filter_arg+0x1932>
    7c76:      	jmp	0x69fd <generic_lsm_filter_arg+0x11d>
    7c7b:      	cmpl	$0x12, %eax
    7c7e:      	je	0x7c99 <generic_lsm_filter_arg+0x13b9>
    7c80:      	movl	$0x0, %ebx
    7c85:      	cmpl	$0x13, %eax
    7c88:      	jne	0x6bb0 <generic_lsm_filter_arg+0x2d0>
    7c8e:      	movq	%r12, %rdx
    7c91:      	movzwl	0x22(%r12), %r12d
    7c97:      	jmp	0x7ca2 <generic_lsm_filter_arg+0x13c2>
    7c99:      	movq	%r12, %rdx
    7c9c:      	movzwl	0x20(%r12), %r12d
    7ca2:      	xorl	%esi, %esi
    7ca4:      	xorl	%ebp, %ebp
    7ca6:      	xorl	%r8d, %r8d
    7ca9:      	xorl	%ebx, %ebx
    7cab:      	cmpl	$0x11, %eax
    7cae:      	jg	0x7d3a <generic_lsm_filter_arg+0x145a>
    7cb4:      	leal	-0xd(%rax), %ecx
    7cb7:      	cmpl	$0x2, %ecx
    7cba:      	jb	0x7d6d <generic_lsm_filter_arg+0x148d>
    7cc0:      	leal	-0xf(%rax), %ecx
    7cc3:      	cmpl	$0x2, %ecx
    7cc6:      	jb	0x7ea0 <generic_lsm_filter_arg+0x15c0>
    7ccc:      	cmpl	$0x11, %eax
    7ccf:      	je	0x8492 <generic_lsm_filter_arg+0x1bb2>
    7cd5:      	jmp	0x6bb0 <generic_lsm_filter_arg+0x2d0>
    7cda:      	cmpl	$0x1c, %eax
    7cdd:      	je	0x848c <generic_lsm_filter_arg+0x1bac>
    7ce3:      	movl	$0x0, %ebx
    7ce8:      	cmpl	$0x1d, %eax
    7ceb:      	jne	0x6bb0 <generic_lsm_filter_arg+0x2d0>
    7cf1:      	cmpl	$0x7, %ecx
    7cf4:      	jne	0x8a28 <generic_lsm_filter_arg+0x2148>
    7cfa:      	testq	%rdx, %rdx
    7cfd:      	jne	0x8a34 <generic_lsm_filter_arg+0x2154>
    7d03:      	xorl	%ebx, %ebx
    7d05:      	jmp	0x8a46 <generic_lsm_filter_arg+0x2166>
    7d0a:      	movq	0x10(%r12), %rsi
    7d0f:      	movq	%r12, %rdx
    7d12:      	movq	0x18(%r12), %r8
    7d17:      	jmp	0x7d25 <generic_lsm_filter_arg+0x1445>
    7d19:      	movq	(%r12), %rsi
    7d1d:      	movq	%r12, %rdx
    7d20:      	movq	0x8(%r12), %r8
    7d25:      	movq	%rsi, %rbp
    7d28:      	shrq	$0x20, %rbp
    7d2c:      	xorl	%r12d, %r12d
    7d2f:      	xorl	%ebx, %ebx
    7d31:      	cmpl	$0x11, %eax
    7d34:      	jle	0x7cb4 <generic_lsm_filter_arg+0x13d4>
    7d3a:      	cmpl	$0x19, %eax
    7d3d:      	ja	0x7e94 <generic_lsm_filter_arg+0x15b4>
    7d43:      	movl	$0x500000, %ecx         # imm = 0x500000
    7d48:      	btl	%eax, %ecx
    7d4b:      	jb	0x7fe3 <generic_lsm_filter_arg+0x1703>
    7d51:      	movl	$0xa00000, %ecx         # imm = 0xA00000
    7d56:      	btl	%eax, %ecx
    7d59:      	jb	0x7ff6 <generic_lsm_filter_arg+0x1716>
    7d5f:      	movl	$0x3000000, %ecx        # imm = 0x3000000
    7d64:      	btl	%eax, %ecx
    7d67:      	jae	0x7e94 <generic_lsm_filter_arg+0x15b4>
    7d6d:      	movzwl	0x26(%rdx), %eax
    7d71:      	cmpl	$0xa, %eax
    7d74:      	je	0x808b <generic_lsm_filter_arg+0x17ab>
    7d7a:      	cmpl	$0x2, %eax
    7d7d:      	jne	0x811d <generic_lsm_filter_arg+0x183d>
    7d83:      	movq	%rsi, %r12
    7d86:      	movq	%r11, 0x10(%rsp)
    7d8b:      	movl	0x10(%r13), %eax
    7d8f:      	movl	%eax, 0x34(%rsp)
    7d93:      	movl	$0x1, %eax
    7d98:      	leaq	0x34(%rsp), %rsi
    7d9d:      	movq	(%rip), %rdi            # 0x7da4 <generic_lsm_filter_arg+0x14c4>
    7da4:      	callq	*%rax
    7da6:      	testq	%rax, %rax
    7da9:      	je	0x8549 <generic_lsm_filter_arg+0x1c69>
    7daf:      	movq	%rax, %rdi
    7db2:      	movl	$0x20, 0x70(%rsp)
    7dba:      	movl	%r12d, 0x74(%rsp)
    7dbf:      	jmp	0x80dd <generic_lsm_filter_arg+0x17fd>
    7dc4:      	cmpl	$0xc, %ecx
    7dc7:      	ja	0x8af1 <generic_lsm_filter_arg+0x2211>
    7dcd:      	movl	$0x1402, %esi           # imm = 0x1402
    7dd2:      	btl	%ecx, %esi
    7dd5:      	jae	0x8af1 <generic_lsm_filter_arg+0x2211>
    7ddb:      	cmpl	%edx, (%r12)
    7ddf:      	jg	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    7de5:      	jmp	0x8b07 <generic_lsm_filter_arg+0x2227>
    7dea:      	xorl	%ebx, %ebx
    7dec:      	xorl	%r12d, %r12d
    7def:      	movq	%r11, %r15
    7df2:      	movl	0x10(%r13,%rbx,4), %eax
    7df7:      	movl	%eax, 0x38(%rsp)
    7dfb:      	movl	$0x1, %eax
    7e00:      	leaq	0x38(%rsp), %rsi
    7e05:      	movq	(%rip), %rdi            # 0x7e0c <generic_lsm_filter_arg+0x152c>
    7e0c:      	callq	*%rax
    7e0e:      	testq	%rax, %rax
    7e11:      	je	0x8974 <generic_lsm_filter_arg+0x2094>
    7e17:      	testl	%ebp, %ebp
    7e19:      	movq	0x8(%rsp), %r9
    7e1e:      	movq	%r15, %r11
    7e21:      	movq	0x68(%rsp), %r15
    7e26:      	je	0x7e6f <generic_lsm_filter_arg+0x158f>
    7e28:      	movq	0x18(%rsp), %rdx
    7e2d:      	xorl	%ecx, %ecx
    7e2f:      	jmp	0x7e3c <generic_lsm_filter_arg+0x155c>
    7e31:      	incq	%rcx
    7e34:      	incq	%rdx
    7e37:      	cmpq	%rbp, %rcx
    7e3a:      	je	0x7e6f <generic_lsm_filter_arg+0x158f>
    7e3c:      	xorl	%esi, %esi
    7e3e:      	nop
    7e40:      	leaq	(%rcx,%rsi), %rdi
    7e44:      	cmpq	%rbp, %rdi
    7e47:      	jae	0x7e31 <generic_lsm_filter_arg+0x1551>
    7e49:      	movzbl	(%rax,%rsi), %edi
    7e4d:      	testb	%dil, %dil
    7e50:      	je	0x7e67 <generic_lsm_filter_arg+0x1587>
    7e52:      	cmpq	$0x62, %rsi
    7e56:      	ja	0x7e31 <generic_lsm_filter_arg+0x1551>
    7e58:      	leaq	0x1(%rsi), %r8
    7e5c:      	cmpb	%dil, (%rdx,%rsi)
    7e60:      	movq	%r8, %rsi
    7e63:      	je	0x7e40 <generic_lsm_filter_arg+0x1560>
    7e65:      	jmp	0x7e31 <generic_lsm_filter_arg+0x1551>
    7e67:      	testl	%ecx, %ecx
    7e69:      	jns	0x8bfa <generic_lsm_filter_arg+0x231a>
    7e6f:      	leal	0xc(%r12), %eax
    7e74:      	cmpl	0x8(%r13), %eax
    7e78:      	jae	0x9777 <generic_lsm_filter_arg+0x2e97>
    7e7e:      	addl	$0x4, %r12d
    7e82:      	incq	%rbx
    7e85:      	cmpq	$0x64, %rbx
    7e89:      	jne	0x7def <generic_lsm_filter_arg+0x150f>
    7e8f:      	jmp	0x9777 <generic_lsm_filter_arg+0x2e97>
    7e94:      	addl	$-0x12, %eax
    7e97:      	cmpl	$0x2, %eax
    7e9a:      	jae	0x6bb0 <generic_lsm_filter_arg+0x2d0>
    7ea0:      	movq	%r11, %rbp
    7ea3:      	movzbl	0x10(%r13), %eax
    7ea8:      	movl	%eax, 0x34(%rsp)
    7eac:      	movl	$0x1, %eax
    7eb1:      	movq	(%rip), %rdi            # 0x7eb8 <generic_lsm_filter_arg+0x15d8>
    7eb8:      	leaq	0x34(%rsp), %rsi
    7ebd:      	callq	*%rax
    7ebf:      	testq	%rax, %rax
    7ec2:      	je	0x831e <generic_lsm_filter_arg+0x1a3e>
    7ec8:      	movq	%rax, %rdi
    7ecb:      	movzwl	%r12w, %eax
    7ecf:      	movq	%rax, 0x70(%rsp)
    7ed4:      	movl	$0x1, %eax
    7ed9:      	movq	0x28(%rsp), %rsi
    7ede:      	jmp	0x82e5 <generic_lsm_filter_arg+0x1a05>
    7ee3:      	leal	-0x100(%rbx), %eax
    7ee9:      	rorxl	$0x8, %eax, %eax
    7eef:      	cmpl	$0x2, %eax
    7ef2:      	jg	0x86a4 <generic_lsm_filter_arg+0x1dc4>
    7ef8:      	testl	%eax, %eax
    7efa:      	je	0x8dbd <generic_lsm_filter_arg+0x24dd>
    7f00:      	cmpl	$0x1, %eax
    7f03:      	jne	0x8db6 <generic_lsm_filter_arg+0x24d6>
    7f09:      	movl	$0x7, %eax
    7f0e:      	jmp	0x8dc9 <generic_lsm_filter_arg+0x24e9>
    7f13:      	cmpl	$0x1, %eax
    7f16:      	je	0x8799 <generic_lsm_filter_arg+0x1eb9>
    7f1c:      	cmpl	$0x2, %eax
    7f1f:      	jne	0x87a6 <generic_lsm_filter_arg+0x1ec6>
    7f25:      	movzbl	(%r12), %edx
    7f2a:      	cmpl	%edx, %ecx
    7f2c:      	ja	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    7f32:      	jmp	0x87a6 <generic_lsm_filter_arg+0x1ec6>
    7f37:      	cmpl	$0x1, %eax
    7f3a:      	je	0x87de <generic_lsm_filter_arg+0x1efe>
    7f40:      	cmpl	$0x2, %eax
    7f43:      	jne	0x87eb <generic_lsm_filter_arg+0x1f0b>
    7f49:      	movzwl	(%r12), %edx
    7f4e:      	cmpl	%edx, %ecx
    7f50:      	ja	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    7f56:      	jmp	0x87eb <generic_lsm_filter_arg+0x1f0b>
    7f5b:      	movq	%r11, %rbp
    7f5e:      	movzbl	0x10(%r13), %eax
    7f63:      	movl	%eax, 0x70(%rsp)
    7f67:      	movl	$0x1, %eax
    7f6c:      	movq	0x28(%rsp), %rsi
    7f71:      	movq	(%rip), %rdi            # 0x7f78 <generic_lsm_filter_arg+0x1698>
    7f78:      	callq	*%rax
    7f7a:      	testq	%rax, %rax
    7f7d:      	je	0x831e <generic_lsm_filter_arg+0x1a3e>
    7f83:      	movq	%rax, %rdi
    7f86:      	movzbl	(%r12), %eax
    7f8b:      	movq	%rax, 0x38(%rsp)
    7f90:      	movl	$0x1, %eax
    7f95:      	leaq	0x38(%rsp), %rsi
    7f9a:      	jmp	0x82e5 <generic_lsm_filter_arg+0x1a05>
    7f9f:      	movq	%r11, %rbp
    7fa2:      	movzbl	0x10(%r13), %eax
    7fa7:      	movl	%eax, 0x70(%rsp)
    7fab:      	movl	$0x1, %eax
    7fb0:      	movq	0x28(%rsp), %rsi
    7fb5:      	movq	(%rip), %rdi            # 0x7fbc <generic_lsm_filter_arg+0x16dc>
    7fbc:      	callq	*%rax
    7fbe:      	testq	%rax, %rax
    7fc1:      	je	0x831e <generic_lsm_filter_arg+0x1a3e>
    7fc7:      	movq	%rax, %rdi
    7fca:      	movzwl	(%r12), %eax
    7fcf:      	movq	%rax, 0x38(%rsp)
    7fd4:      	movl	$0x1, %eax
    7fd9:      	leaq	0x38(%rsp), %rsi
    7fde:      	jmp	0x82e5 <generic_lsm_filter_arg+0x1a05>
    7fe3:      	movzwl	%r12w, %eax
    7fe7:      	xorl	%ebx, %ebx
    7fe9:      	cmpl	$0x400, %eax            # imm = 0x400
    7fee:      	setb	%bl
    7ff1:      	jmp	0x6bb0 <generic_lsm_filter_arg+0x2d0>
    7ff6:      	movzwl	%r12w, %eax
    7ffa:      	xorl	%ebx, %ebx
    7ffc:      	cmpl	$0x400, %eax            # imm = 0x400
    8001:      	setae	%bl
    8004:      	jmp	0x6bb0 <generic_lsm_filter_arg+0x2d0>
    8009:      	testq	%rax, %rax
    800c:      	sete	%al
    800f:      	movq	(%rsp), %rdi
    8013:      	movq	0x8(%rsp), %r9
    8018:      	movq	%rbp, %r11
    801b:      	movzbl	%al, %ebx
    801e:      	jmp	0x6bb0 <generic_lsm_filter_arg+0x2d0>
    8023:      	movl	$0x100, %esi            # imm = 0x100
    8028:      	cmpl	$0x101, %eax            # imm = 0x101
    802d:      	jb	0x805b <generic_lsm_filter_arg+0x177b>
    802f:      	movl	$0x200, %esi            # imm = 0x200
    8034:      	cmpl	$0x201, %eax            # imm = 0x201
    8039:      	jb	0x805b <generic_lsm_filter_arg+0x177b>
    803b:      	movl	$0x400, %esi            # imm = 0x400
    8040:      	cmpl	$0x401, %eax            # imm = 0x401
    8045:      	jb	0x805b <generic_lsm_filter_arg+0x177b>
    8047:      	xorl	%esi, %esi
    8049:      	cmpl	$0x801, %eax            # imm = 0x801
    804e:      	setae	%sil
    8052:      	shll	$0xb, %esi
    8055:      	addl	$0x800, %esi            # imm = 0x800
    805b:      	leal	-0x100(%rsi), %eax
    8061:      	rorxl	$0x8, %eax, %eax
    8067:      	cmpl	$0x2, %eax
    806a:      	jg	0x8558 <generic_lsm_filter_arg+0x1c78>
    8070:      	testl	%eax, %eax
    8072:      	je	0x8c23 <generic_lsm_filter_arg+0x2343>
    8078:      	cmpl	$0x1, %eax
    807b:      	jne	0x8c1c <generic_lsm_filter_arg+0x233c>
    8081:      	movl	$0x7, %eax
    8086:      	jmp	0x8c2f <generic_lsm_filter_arg+0x234f>
    808b:      	movq	%r8, %rbx
    808e:      	movq	%rsi, %r12
    8091:      	movq	%r11, 0x10(%rsp)
    8096:      	movl	0x14(%r13), %eax
    809a:      	movl	%eax, 0x34(%rsp)
    809e:      	movl	$0x1, %eax
    80a3:      	movq	(%rip), %rdi            # 0x80aa <generic_lsm_filter_arg+0x17ca>
    80aa:      	leaq	0x34(%rsp), %rsi
    80af:      	callq	*%rax
    80b1:      	testq	%rax, %rax
    80b4:      	je	0x8549 <generic_lsm_filter_arg+0x1c69>
    80ba:      	movq	%rax, %rdi
    80bd:      	movl	$0x80, 0x70(%rsp)
    80c5:      	movl	%r12d, 0x74(%rsp)
    80ca:      	movl	%ebp, 0x78(%rsp)
    80ce:      	movl	%ebx, 0x7c(%rsp)
    80d2:      	shrq	$0x20, %rbx
    80d6:      	movl	%ebx, 0x80(%rsp)
    80dd:      	movl	$0x1, %eax
    80e2:      	movq	0x28(%rsp), %rsi
    80e7:      	callq	*%rax
    80e9:      	movl	0x4(%r13), %ecx
    80ed:      	leal	-0x18(%rcx), %edx
    80f0:      	cmpl	$0x2, %edx
    80f3:      	jb	0x8761 <generic_lsm_filter_arg+0x1e81>
    80f9:      	addl	$-0xd, %ecx
    80fc:      	cmpl	$0x1, %ecx
    80ff:      	movq	(%rsp), %rdi
    8103:      	movq	0x8(%rsp), %r9
    8108:      	movq	0x10(%rsp), %r11
    810d:      	ja	0x811d <generic_lsm_filter_arg+0x183d>
    810f:      	testq	%rax, %rax
    8112:      	setne	%al
    8115:      	movzbl	%al, %ebx
    8118:      	jmp	0x6bb0 <generic_lsm_filter_arg+0x2d0>
    811d:      	xorl	%eax, %eax
    811f:      	movzbl	%al, %ebx
    8122:      	jmp	0x6bb0 <generic_lsm_filter_arg+0x2d0>
    8127:      	cmpl	$0x1e, %eax
    812a:      	jne	0x69fd <generic_lsm_filter_arg+0x11d>
    8130:      	movl	0x10(%r13), %eax
    8134:      	andl	$0x7, %eax
    8137:      	movl	%eax, %ecx
    8139:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
    8142:      	jne	0x69fd <generic_lsm_filter_arg+0x11d>
    8148:      	movq	(%r12), %rcx
    814c:      	movq	0x5e78(%r14,%rax,8), %rax
    8154:      	andl	$0x7ff, %eax            # imm = 0x7FF
    8159:      	xorl	%ebx, %ebx
    815b:      	andnq	0x90(%r14,%rax), %rcx, %rax
    8165:      	setne	%bl
    8168:      	jmp	0x6bb0 <generic_lsm_filter_arg+0x2d0>
    816d:      	cmpl	$0x21, %eax
    8170:      	je	0x88cc <generic_lsm_filter_arg+0x1fec>
    8176:      	movl	$0x0, %ebx
    817b:      	cmpl	$0x22, %eax
    817e:      	jne	0x9f1b <generic_lsm_filter_arg+0x363b>
    8184:      	movl	$0x10, %r12d
    818a:      	movq	%r11, %r15
    818d:      	movl	(%r13,%r12), %eax
    8192:      	movl	%eax, 0x38(%rsp)
    8196:      	movl	$0x1, %eax
    819b:      	leaq	0x38(%rsp), %rsi
    81a0:      	movq	(%rip), %rdi            # 0x81a7 <generic_lsm_filter_arg+0x18c7>
    81a7:      	callq	*%rax
    81a9:      	testq	%rax, %rax
    81ac:      	je	0x9564 <generic_lsm_filter_arg+0x2c84>
    81b2:      	movq	0x18(%rsp), %rdi
    81b7:      	movq	%rax, %rsi
    81ba:      	movq	%rbp, %rdx
    81bd:      	callq	0x81c2 <generic_lsm_filter_arg+0x18e2>
    81c2:      	testl	%eax, %eax
    81c4:      	jns	0x9568 <generic_lsm_filter_arg+0x2c88>
    81ca:      	addq	$0x4, %r12
    81ce:      	leal	-0x8(%r12), %eax
    81d3:      	cmpl	0x8(%r13), %eax
    81d7:      	movq	(%rsp), %rdi
    81db:      	movq	0x8(%rsp), %r9
    81e0:      	movq	%r15, %r11
    81e3:      	jae	0x969d <generic_lsm_filter_arg+0x2dbd>
    81e9:      	movl	$0x0, %ebx
    81ee:      	cmpq	$0x1a0, %r12            # imm = 0x1A0
    81f5:      	movq	0x68(%rsp), %r15
    81fa:      	jne	0x818a <generic_lsm_filter_arg+0x18aa>
    81fc:      	jmp	0x9f1b <generic_lsm_filter_arg+0x363b>
    8201:      	movq	%r8, 0x18(%rsp)
    8206:      	movq	%rsi, %r12
    8209:      	cmpl	$0x8, %eax
    820c:      	jne	0x69fd <generic_lsm_filter_arg+0x11d>
    8212:      	movq	%r11, 0x10(%rsp)
    8217:      	movl	0x10(%r13), %eax
    821b:      	movl	%eax, 0x38(%rsp)
    821f:      	movl	$0x0, 0x70(%rsp)
    8227:      	movl	$0x1, %eax
    822c:      	leaq	0x38(%rsp), %rsi
    8231:      	movq	(%rip), %rdi            # 0x8238 <generic_lsm_filter_arg+0x1958>
    8238:      	callq	*%rax
    823a:      	testb	%bpl, %bpl
    823d:      	je	0x8512 <generic_lsm_filter_arg+0x1c32>
    8243:      	movl	$0x0, %ebx
    8248:      	testq	%rax, %rax
    824b:      	je	0x8514 <generic_lsm_filter_arg+0x1c34>
    8251:      	movq	%rax, %rbp
    8254:      	movl	$0x1, %eax
    8259:      	movq	0x28(%rsp), %rsi
    825e:      	movq	(%rip), %rdi            # 0x8265 <generic_lsm_filter_arg+0x1985>
    8265:      	callq	*%rax
    8267:      	testq	%rax, %rax
    826a:      	je	0x8512 <generic_lsm_filter_arg+0x1c32>
    8270:      	movq	%r12, %rsi
    8273:      	movl	%esi, %ecx
    8275:      	shll	$0x3, %ecx
    8278:      	movl	%ecx, (%rax)
    827a:      	movq	%rax, %rdi
    827d:      	addq	$0x4, %rdi
    8281:      	movq	%rax, %rbx
    8284:      	movl	$0x4, %eax
    8289:      	movq	0x18(%rsp), %rdx
    828e:      	callq	*%rax
    8290:      	movl	$0x1, %eax
    8295:      	movq	%rbp, %rdi
    8298:      	movq	%rbx, %rsi
    829b:      	callq	*%rax
    829d:      	xorl	%ebx, %ebx
    829f:      	testq	%rax, %rax
    82a2:      	setne	%bl
    82a5:      	jmp	0x8514 <generic_lsm_filter_arg+0x1c34>
    82aa:      	movq	%r11, %rbp
    82ad:      	movzwl	(%r12), %ebx
    82b2:      	movzbl	0x10(%r13), %eax
    82b7:      	movl	%eax, 0x70(%rsp)
    82bb:      	movl	$0x1, %eax
    82c0:      	movq	0x28(%rsp), %rsi
    82c5:      	movq	(%rip), %rdi            # 0x82cc <generic_lsm_filter_arg+0x19ec>
    82cc:      	callq	*%rax
    82ce:      	testq	%rax, %rax
    82d1:      	je	0x831e <generic_lsm_filter_arg+0x1a3e>
    82d3:      	movq	%rax, %rdi
    82d6:      	movq	%rbx, 0x38(%rsp)
    82db:      	movl	$0x1, %eax
    82e0:      	leaq	0x38(%rsp), %rsi
    82e5:      	callq	*%rax
    82e7:      	movl	0x4(%r13), %edx
    82eb:      	xorl	%ecx, %ecx
    82ed:      	cmpl	$0x1d, %edx
    82f0:      	ja	0x8c08 <generic_lsm_filter_arg+0x2328>
    82f6:      	movl	$0x30038400, %esi       # imm = 0x30038400
    82fb:      	btl	%edx, %esi
    82fe:      	movq	(%rsp), %rdi
    8302:      	movq	0x8(%rsp), %r9
    8307:      	movq	%rbp, %r11
    830a:      	jae	0x84fa <generic_lsm_filter_arg+0x1c1a>
    8310:      	testq	%rax, %rax
    8313:      	setne	%cl
    8316:      	movzbl	%cl, %ebx
    8319:      	jmp	0x6bb0 <generic_lsm_filter_arg+0x2d0>
    831e:      	xorl	%ebx, %ebx
    8320:      	movq	(%rsp), %rdi
    8324:      	movq	0x8(%rsp), %r9
    8329:      	movq	%rbp, %r11
    832c:      	jmp	0x6bb0 <generic_lsm_filter_arg+0x2d0>
    8331:      	movq	%r11, 0x10(%rsp)
    8336:      	movl	0x10(%r13), %eax
    833a:      	movl	%eax, 0x38(%rsp)
    833e:      	movl	$0x0, 0x70(%rsp)
    8346:      	movl	$0x1, %eax
    834b:      	leaq	0x38(%rsp), %rsi
    8350:      	movq	(%rip), %rdi            # 0x8357 <generic_lsm_filter_arg+0x1a77>
    8357:      	callq	*%rax
    8359:      	testl	%ebp, %ebp
    835b:      	je	0x9f0b <generic_lsm_filter_arg+0x362b>
    8361:      	movq	%rax, %r12
    8364:      	movl	$0x0, %ebx
    8369:      	testq	%rax, %rax
    836c:      	je	0x9f0d <generic_lsm_filter_arg+0x362d>
    8372:      	movl	$0x1, %eax
    8377:      	movq	0x28(%rsp), %rsi
    837c:      	movq	(%rip), %rdi            # 0x8383 <generic_lsm_filter_arg+0x1aa3>
    8383:      	callq	*%rax
    8385:      	testq	%rax, %rax
    8388:      	je	0x9f0b <generic_lsm_filter_arg+0x362b>
    838e:      	cmpl	$0xff, %ebp
    8394:      	movl	$0xff, %ecx
    8399:      	cmovael	%ecx, %ebp
    839c:      	leal	(,%rbp,8), %ecx
    83a3:      	movl	%ecx, (%rax)
    83a5:      	movq	%rax, %rdi
    83a8:      	addq	$0x4, %rdi
    83ac:      	movq	%rax, %rbx
    83af:      	movl	$0x4, %eax
    83b4:      	movq	0x18(%rsp), %rdx
    83b9:      	movl	%ebp, %esi
    83bb:      	callq	*%rax
    83bd:      	movl	$0x1, %eax
    83c2:      	movq	%r12, %rdi
    83c5:      	movq	%rbx, %rsi
    83c8:      	callq	*%rax
    83ca:      	xorl	%ebx, %ebx
    83cc:      	testq	%rax, %rax
    83cf:      	setne	%bl
    83d2:      	jmp	0x9f0d <generic_lsm_filter_arg+0x362d>
    83d7:      	movl	$0x0, 0x70(%rsp)
    83df:      	cmpl	$0x1000, %ebp           # imm = 0x1000
    83e5:      	jbe	0x898c <generic_lsm_filter_arg+0x20ac>
    83eb:      	xorl	%ebx, %ebx
    83ed:      	jmp	0x9f1b <generic_lsm_filter_arg+0x363b>
    83f2:      	movq	(%r12), %rax
    83f6:      	cmpq	%rax, %rsi
    83f9:      	ja	0x8404 <generic_lsm_filter_arg+0x1b24>
    83fb:      	cmpq	%rdx, %rax
    83fe:      	jbe	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    8404:      	movl	0x8(%r13), %edx
    8408:      	cmpl	$0x19, %edx
    840b:      	jb	0x69fd <generic_lsm_filter_arg+0x11d>
    8411:      	movq	0x20(%r13), %rdi
    8415:      	movq	0x28(%r13), %rsi
    8419:      	cmpl	$0xc, %ecx
    841c:      	je	0x8427 <generic_lsm_filter_arg+0x1b47>
    841e:      	cmpl	$0xa, %ecx
    8421:      	jne	0x8aa5 <generic_lsm_filter_arg+0x21c5>
    8427:      	cmpq	%rax, %rdi
    842a:      	movq	(%rsp), %rdi
    842e:      	jg	0x8ab7 <generic_lsm_filter_arg+0x21d7>
    8434:      	cmpq	%rsi, %rax
    8437:      	jle	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    843d:      	jmp	0x8ab7 <generic_lsm_filter_arg+0x21d7>
    8442:      	movq	(%r12), %rdx
    8446:      	cmpq	%rdx, %rsi
    8449:      	setbe	%sil
    844d:      	cmpq	%rax, %rdx
    8450:      	setbe	%al
    8453:      	andb	%sil, %al
    8456:      	movl	0x8(%r13), %esi
    845a:      	cmpl	$0x19, %esi
    845d:      	jb	0x9930 <generic_lsm_filter_arg+0x3050>
    8463:      	movq	0x20(%r13), %r8
    8467:      	movq	0x28(%r13), %rdi
    846b:      	cmpl	$0xc, %ecx
    846e:      	je	0x8479 <generic_lsm_filter_arg+0x1b99>
    8470:      	cmpl	$0xa, %ecx
    8473:      	jne	0x89e2 <generic_lsm_filter_arg+0x2102>
    8479:      	cmpq	%rdx, %r8
    847c:      	setle	%r8b
    8480:      	cmpq	%rdi, %rdx
    8483:      	setle	%dil
    8487:      	jmp	0x89f0 <generic_lsm_filter_arg+0x2110>
    848c:      	movzwl	0x26(%r12), %ebx
    8492:      	movq	%r11, %r12
    8495:      	movzbl	0x10(%r13), %eax
    849a:      	movl	%eax, 0x34(%rsp)
    849e:      	movl	$0x1, %eax
    84a3:      	movq	(%rip), %rdi            # 0x84aa <generic_lsm_filter_arg+0x1bca>
    84aa:      	leaq	0x34(%rsp), %rsi
    84af:      	callq	*%rax
    84b1:      	testq	%rax, %rax
    84b4:      	je	0x8a83 <generic_lsm_filter_arg+0x21a3>
    84ba:      	movq	%rax, %rdi
    84bd:      	movzwl	%bx, %eax
    84c0:      	movq	%rax, 0x70(%rsp)
    84c5:      	movl	$0x1, %eax
    84ca:      	movq	0x28(%rsp), %rsi
    84cf:      	callq	*%rax
    84d1:      	movl	0x4(%r13), %edx
    84d5:      	xorl	%ecx, %ecx
    84d7:      	cmpl	$0x1d, %edx
    84da:      	ja	0x96e1 <generic_lsm_filter_arg+0x2e01>
    84e0:      	movl	$0x30038400, %esi       # imm = 0x30038400
    84e5:      	btl	%edx, %esi
    84e8:      	movq	(%rsp), %rdi
    84ec:      	movq	0x8(%rsp), %r9
    84f1:      	movq	%r12, %r11
    84f4:      	jb	0x8310 <generic_lsm_filter_arg+0x1a30>
    84fa:      	movl	$0xc0800, %esi          # imm = 0xC0800
    84ff:      	btl	%edx, %esi
    8502:      	jae	0x850a <generic_lsm_filter_arg+0x1c2a>
    8504:      	testq	%rax, %rax
    8507:      	sete	%cl
    850a:      	movzbl	%cl, %ebx
    850d:      	jmp	0x6bb0 <generic_lsm_filter_arg+0x2d0>
    8512:      	xorl	%ebx, %ebx
    8514:      	movl	0x4(%r13), %eax
    8518:      	cmpq	$0x25, %rax
    851c:      	ja	0x940f <generic_lsm_filter_arg+0x2b2f>
    8522:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    852c:      	btq	%rax, %rcx
    8530:      	movq	(%rsp), %rdi
    8534:      	movq	0x8(%rsp), %r9
    8539:      	movq	0x10(%rsp), %r11
    853e:      	jb	0x9ba5 <generic_lsm_filter_arg+0x32c5>
    8544:      	jmp	0x6bb0 <generic_lsm_filter_arg+0x2d0>
    8549:      	movl	0x4(%r13), %eax
    854d:      	andl	$-0x2, %eax
    8550:      	cmpl	$0x18, %eax
    8553:      	jmp	0x8764 <generic_lsm_filter_arg+0x1e84>
    8558:      	cmpl	$0x3, %eax
    855b:      	je	0x8c2a <generic_lsm_filter_arg+0x234a>
    8561:      	cmpl	$0x7, %eax
    8564:      	jne	0x8c1c <generic_lsm_filter_arg+0x233c>
    856a:      	movl	$0x9, %eax
    856f:      	jmp	0x8c2f <generic_lsm_filter_arg+0x234f>
    8574:      	movl	$0x100, %esi            # imm = 0x100
    8579:      	cmpl	$0x101, %eax            # imm = 0x101
    857e:      	jb	0x85ac <generic_lsm_filter_arg+0x1ccc>
    8580:      	movl	$0x200, %esi            # imm = 0x200
    8585:      	cmpl	$0x201, %eax            # imm = 0x201
    858a:      	jb	0x85ac <generic_lsm_filter_arg+0x1ccc>
    858c:      	movl	$0x400, %esi            # imm = 0x400
    8591:      	cmpl	$0x401, %eax            # imm = 0x401
    8596:      	jb	0x85ac <generic_lsm_filter_arg+0x1ccc>
    8598:      	xorl	%esi, %esi
    859a:      	cmpl	$0x801, %eax            # imm = 0x801
    859f:      	setae	%sil
    85a3:      	shll	$0xb, %esi
    85a6:      	addl	$0x800, %esi            # imm = 0x800
    85ac:      	leal	-0x100(%rsi), %eax
    85b2:      	rorxl	$0x8, %eax, %eax
    85b8:      	cmpl	$0x2, %eax
    85bb:      	jg	0x877d <generic_lsm_filter_arg+0x1e9d>
    85c1:      	testl	%eax, %eax
    85c3:      	je	0x91b0 <generic_lsm_filter_arg+0x28d0>
    85c9:      	cmpl	$0x1, %eax
    85cc:      	jne	0x91a9 <generic_lsm_filter_arg+0x28c9>
    85d2:      	movl	$0x7, %eax
    85d7:      	jmp	0x91bc <generic_lsm_filter_arg+0x28dc>
    85dc:      	cmpq	%rdx, (%r12)
    85e0:      	ja	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    85e6:      	jmp	0x85f2 <generic_lsm_filter_arg+0x1d12>
    85e8:      	cmpq	%rdx, (%r12)
    85ec:      	jb	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    85f2:      	movl	0x8(%r13), %edx
    85f6:      	cmpl	$0x11, %edx
    85f9:      	jb	0x9fa1 <generic_lsm_filter_arg+0x36c1>
    85ff:      	movq	0x18(%r13), %rsi
    8603:      	cmpl	$0x2, %eax
    8606:      	jle	0x8623 <generic_lsm_filter_arg+0x1d43>
    8608:      	leal	-0x3(%rax), %edi
    860b:      	cmpl	$0x2, %edi
    860e:      	jae	0x8652 <generic_lsm_filter_arg+0x1d72>
    8610:      	cmpq	%rsi, (%r12)
    8614:      	movq	(%rsp), %rdi
    8618:      	je	0x6ba5 <generic_lsm_filter_arg+0x2c5>
    861e:      	jmp	0x9131 <generic_lsm_filter_arg+0x2851>
    8623:      	cmpl	$0x1, %eax
    8626:      	je	0x86c0 <generic_lsm_filter_arg+0x1de0>
    862c:      	cmpl	$0x2, %eax
    862f:      	jne	0x9131 <generic_lsm_filter_arg+0x2851>
    8635:      	cmpl	$0xc, %ecx
    8638:      	je	0x8643 <generic_lsm_filter_arg+0x1d63>
    863a:      	cmpl	$0xa, %ecx
    863d:      	jne	0x9127 <generic_lsm_filter_arg+0x2847>
    8643:      	cmpq	%rsi, (%r12)
    8647:      	jl	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    864d:      	jmp	0x9131 <generic_lsm_filter_arg+0x2851>
    8652:      	cmpl	$0xc, %eax
    8655:      	movq	(%rsp), %rdi
    8659:      	jne	0x9131 <generic_lsm_filter_arg+0x2851>
    865f:      	testq	%rsi, (%r12)
    8663:      	jne	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    8669:      	jmp	0x9131 <generic_lsm_filter_arg+0x2851>
    866e:      	cmpl	$0xc, %eax
    8671:      	jne	0x87a6 <generic_lsm_filter_arg+0x1ec6>
    8677:      	movzbl	(%r12), %edx
    867c:      	testl	%edx, %ecx
    867e:      	jne	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    8684:      	jmp	0x87a6 <generic_lsm_filter_arg+0x1ec6>
    8689:      	cmpl	$0xc, %eax
    868c:      	jne	0x87eb <generic_lsm_filter_arg+0x1f0b>
    8692:      	movzwl	(%r12), %edx
    8697:      	testl	%edx, %ecx
    8699:      	jne	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    869f:      	jmp	0x87eb <generic_lsm_filter_arg+0x1f0b>
    86a4:      	cmpl	$0x3, %eax
    86a7:      	je	0x8dc4 <generic_lsm_filter_arg+0x24e4>
    86ad:      	cmpl	$0x7, %eax
    86b0:      	jne	0x8db6 <generic_lsm_filter_arg+0x24d6>
    86b6:      	movl	$0x9, %eax
    86bb:      	jmp	0x8dc9 <generic_lsm_filter_arg+0x24e9>
    86c0:      	cmpl	$0xc, %ecx
    86c3:      	je	0x86ce <generic_lsm_filter_arg+0x1dee>
    86c5:      	cmpl	$0xa, %ecx
    86c8:      	jne	0x911b <generic_lsm_filter_arg+0x283b>
    86ce:      	cmpq	%rsi, (%r12)
    86d2:      	jg	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    86d8:      	jmp	0x9131 <generic_lsm_filter_arg+0x2851>
    86dd:      	movl	0x8(%r13), %edx
    86e1:      	movzbl	(%r12), %ecx
    86e6:      	jmp	0x86f1 <generic_lsm_filter_arg+0x1e11>
    86e8:      	movl	0x8(%r13), %edx
    86ec:      	movzwl	(%r12), %ecx
    86f1:      	cmpl	%ecx, 0x10(%r13)
    86f5:      	setbe	%sil
    86f9:      	cmpl	%ecx, 0x14(%r13)
    86fd:      	setae	%al
    8700:      	andb	%sil, %al
    8703:      	cmpl	$0x11, %edx
    8706:      	jb	0x9930 <generic_lsm_filter_arg+0x3050>
    870c:      	cmpl	%ecx, 0x18(%r13)
    8710:      	setbe	%sil
    8714:      	cmpl	%ecx, 0x1c(%r13)
    8718:      	setae	%dil
    871c:      	andb	%sil, %dil
    871f:      	orb	%dil, %al
    8722:      	cmpl	$0x19, %edx
    8725:      	jb	0x992c <generic_lsm_filter_arg+0x304c>
    872b:      	cmpl	%ecx, 0x20(%r13)
    872f:      	setbe	%sil
    8733:      	cmpl	%ecx, 0x24(%r13)
    8737:      	setae	%dil
    873b:      	andb	%sil, %dil
    873e:      	orb	%dil, %al
    8741:      	cmpl	$0x21, %edx
    8744:      	jb	0x992c <generic_lsm_filter_arg+0x304c>
    874a:      	cmpl	%ecx, 0x28(%r13)
    874e:      	setbe	%dl
    8751:      	cmpl	%ecx, 0x2c(%r13)
    8755:      	setae	%cl
    8758:      	andb	%dl, %cl
    875a:      	orb	%cl, %al
    875c:      	jmp	0x992c <generic_lsm_filter_arg+0x304c>
    8761:      	testq	%rax, %rax
    8764:      	sete	%al
    8767:      	movq	(%rsp), %rdi
    876b:      	movq	0x8(%rsp), %r9
    8770:      	movq	0x10(%rsp), %r11
    8775:      	movzbl	%al, %ebx
    8778:      	jmp	0x6bb0 <generic_lsm_filter_arg+0x2d0>
    877d:      	cmpl	$0x3, %eax
    8780:      	je	0x91b7 <generic_lsm_filter_arg+0x28d7>
    8786:      	cmpl	$0x7, %eax
    8789:      	jne	0x91a9 <generic_lsm_filter_arg+0x28c9>
    878f:      	movl	$0x9, %eax
    8794:      	jmp	0x91bc <generic_lsm_filter_arg+0x28dc>
    8799:      	movzbl	(%r12), %edx
    879e:      	cmpl	%edx, %ecx
    87a0:      	jb	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    87a6:      	movl	0x8(%r13), %ecx
    87aa:      	cmpl	$0xd, %ecx
    87ad:      	jb	0x9fa1 <generic_lsm_filter_arg+0x36c1>
    87b3:      	movl	0x14(%r13), %edx
    87b7:      	cmpl	$0x2, %eax
    87ba:      	jle	0x8bb2 <generic_lsm_filter_arg+0x22d2>
    87c0:      	leal	-0x3(%rax), %esi
    87c3:      	cmpl	$0x2, %esi
    87c6:      	jae	0x935a <generic_lsm_filter_arg+0x2a7a>
    87cc:      	movzbl	(%r12), %esi
    87d1:      	cmpl	%esi, %edx
    87d3:      	je	0x6ba5 <generic_lsm_filter_arg+0x2c5>
    87d9:      	jmp	0x944b <generic_lsm_filter_arg+0x2b6b>
    87de:      	movzwl	(%r12), %edx
    87e3:      	cmpl	%edx, %ecx
    87e5:      	jb	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    87eb:      	movl	0x8(%r13), %ecx
    87ef:      	cmpl	$0xd, %ecx
    87f2:      	jb	0x9fa1 <generic_lsm_filter_arg+0x36c1>
    87f8:      	movl	0x14(%r13), %edx
    87fc:      	cmpl	$0x2, %eax
    87ff:      	jle	0x8bd6 <generic_lsm_filter_arg+0x22f6>
    8805:      	leal	-0x3(%rax), %esi
    8808:      	cmpl	$0x2, %esi
    880b:      	jae	0x9375 <generic_lsm_filter_arg+0x2a95>
    8811:      	movzwl	(%r12), %esi
    8816:      	cmpl	%esi, %edx
    8818:      	je	0x6ba5 <generic_lsm_filter_arg+0x2c5>
    881e:      	jmp	0x948c <generic_lsm_filter_arg+0x2bac>
    8823:      	movl	(%r12), %eax
    8827:      	cmpl	%eax, %esi
    8829:      	ja	0x8833 <generic_lsm_filter_arg+0x1f53>
    882b:      	cmpl	%edx, %eax
    882d:      	jbe	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    8833:      	movl	0x8(%r13), %edx
    8837:      	cmpl	$0x11, %edx
    883a:      	jb	0x69fd <generic_lsm_filter_arg+0x11d>
    8840:      	movl	0x18(%r13), %edi
    8844:      	movl	0x1c(%r13), %esi
    8848:      	cmpl	$0xc, %ecx
    884b:      	ja	0x8fd7 <generic_lsm_filter_arg+0x26f7>
    8851:      	movl	$0x1402, %r8d           # imm = 0x1402
    8857:      	btl	%ecx, %r8d
    885b:      	jae	0x8fd7 <generic_lsm_filter_arg+0x26f7>
    8861:      	cmpl	%eax, %edi
    8863:      	movq	(%rsp), %rdi
    8867:      	jg	0x8fe7 <generic_lsm_filter_arg+0x2707>
    886d:      	cmpl	%esi, %eax
    886f:      	jle	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    8875:      	jmp	0x8fe7 <generic_lsm_filter_arg+0x2707>
    887a:      	movl	(%r12), %edx
    887e:      	cmpl	%edx, %esi
    8880:      	setbe	%sil
    8884:      	cmpl	%eax, %edx
    8886:      	setbe	%al
    8889:      	andb	%sil, %al
    888c:      	movl	0x8(%r13), %esi
    8890:      	cmpl	$0x11, %esi
    8893:      	jb	0x9930 <generic_lsm_filter_arg+0x3050>
    8899:      	movl	0x18(%r13), %r8d
    889d:      	movl	0x1c(%r13), %edi
    88a1:      	cmpl	$0xc, %ecx
    88a4:      	ja	0x8f81 <generic_lsm_filter_arg+0x26a1>
    88aa:      	movl	$0x1402, %r10d          # imm = 0x1402
    88b0:      	btl	%ecx, %r10d
    88b4:      	jae	0x8f81 <generic_lsm_filter_arg+0x26a1>
    88ba:      	cmpl	%edx, %r8d
    88bd:      	setle	%r8b
    88c1:      	cmpl	%edi, %edx
    88c3:      	setle	%dil
    88c7:      	jmp	0x8f8e <generic_lsm_filter_arg+0x26ae>
    88cc:      	xorl	%ebx, %ebx
    88ce:      	xorl	%r12d, %r12d
    88d1:      	movq	%r11, %r15
    88d4:      	movl	0x10(%r13,%rbx,4), %eax
    88d9:      	movl	%eax, 0x38(%rsp)
    88dd:      	movl	$0x1, %eax
    88e2:      	leaq	0x38(%rsp), %rsi
    88e7:      	movq	(%rip), %rdi            # 0x88ee <generic_lsm_filter_arg+0x200e>
    88ee:      	callq	*%rax
    88f0:      	testq	%rax, %rax
    88f3:      	je	0x8974 <generic_lsm_filter_arg+0x2094>
    88f9:      	testl	%ebp, %ebp
    88fb:      	movq	0x8(%rsp), %r9
    8900:      	movq	%r15, %r11
    8903:      	movq	0x68(%rsp), %r15
    8908:      	je	0x894f <generic_lsm_filter_arg+0x206f>
    890a:      	movq	0x18(%rsp), %rdx
    890f:      	xorl	%ecx, %ecx
    8911:      	jmp	0x891e <generic_lsm_filter_arg+0x203e>
    8913:      	incq	%rcx
    8916:      	incq	%rdx
    8919:      	cmpq	%rbp, %rcx
    891c:      	je	0x894f <generic_lsm_filter_arg+0x206f>
    891e:      	xorl	%esi, %esi
    8920:      	leaq	(%rcx,%rsi), %rdi
    8924:      	cmpq	%rbp, %rdi
    8927:      	jae	0x8913 <generic_lsm_filter_arg+0x2033>
    8929:      	movzbl	(%rax,%rsi), %edi
    892d:      	testb	%dil, %dil
    8930:      	je	0x8947 <generic_lsm_filter_arg+0x2067>
    8932:      	cmpq	$0x62, %rsi
    8936:      	ja	0x8913 <generic_lsm_filter_arg+0x2033>
    8938:      	leaq	0x1(%rsi), %r8
    893c:      	cmpb	%dil, (%rdx,%rsi)
    8940:      	movq	%r8, %rsi
    8943:      	je	0x8920 <generic_lsm_filter_arg+0x2040>
    8945:      	jmp	0x8913 <generic_lsm_filter_arg+0x2033>
    8947:      	testl	%ecx, %ecx
    8949:      	jns	0x8bfa <generic_lsm_filter_arg+0x231a>
    894f:      	leal	0xc(%r12), %eax
    8954:      	cmpl	0x8(%r13), %eax
    8958:      	jae	0x9777 <generic_lsm_filter_arg+0x2e97>
    895e:      	addl	$0x4, %r12d
    8962:      	incq	%rbx
    8965:      	cmpq	$0x64, %rbx
    8969:      	jne	0x88d1 <generic_lsm_filter_arg+0x1ff1>
    896f:      	jmp	0x9777 <generic_lsm_filter_arg+0x2e97>
    8974:      	xorl	%ebx, %ebx
    8976:      	movq	0x8(%rsp), %r9
    897b:      	movq	%r15, %r11
    897e:      	movq	0x68(%rsp), %r15
    8983:      	movq	(%rsp), %rdi
    8987:      	jmp	0x9f1b <generic_lsm_filter_arg+0x363b>
    898c:      	movzwl	%bp, %eax
    898f:      	cmpl	$0x90, %eax
    8994:      	movq	%r11, 0x10(%rsp)
    8999:      	ja	0x902a <generic_lsm_filter_arg+0x274a>
    899f:      	testw	%bp, %bp
    89a2:      	je	0x89b4 <generic_lsm_filter_arg+0x20d4>
    89a4:      	movl	%ebp, %eax
    89a6:      	movl	$0x18, %ecx
    89ab:      	cltd
    89ac:      	idivl	%ecx
    89ae:      	movl	%ebp, %esi
    89b0:      	testl	%edx, %edx
    89b2:      	je	0x89d6 <generic_lsm_filter_arg+0x20f6>
    89b4:      	movl	%ebp, %eax
    89b6:      	movl	$0x18, %ecx
    89bb:      	cltd
    89bc:      	idivl	%ecx
    89be:      	shll	$0x3, %eax
    89c1:      	leal	(%rax,%rax,2), %eax
    89c4:      	addl	$0x18, %eax
    89c7:      	movzwl	%ax, %esi
    89ca:      	cmpl	$0x90, %esi
    89d0:      	ja	0x9062 <generic_lsm_filter_arg+0x2782>
    89d6:      	movl	%esi, %eax
    89d8:      	cltd
    89d9:      	idivl	%ecx
    89db:      	decl	%eax
    89dd:      	jmp	0x9795 <generic_lsm_filter_arg+0x2eb5>
    89e2:      	cmpq	%rdx, %r8
    89e5:      	setbe	%r8b
    89e9:      	cmpq	%rdi, %rdx
    89ec:      	setbe	%dil
    89f0:      	andb	%r8b, %dil
    89f3:      	orb	%dil, %al
    89f6:      	cmpl	$0x29, %esi
    89f9:      	jb	0x992c <generic_lsm_filter_arg+0x304c>
    89ff:      	movq	0x30(%r13), %r8
    8a03:      	movq	0x38(%r13), %rdi
    8a07:      	cmpl	$0xc, %ecx
    8a0a:      	je	0x8a15 <generic_lsm_filter_arg+0x2135>
    8a0c:      	cmpl	$0xa, %ecx
    8a0f:      	jne	0x9092 <generic_lsm_filter_arg+0x27b2>
    8a15:      	cmpq	%rdx, %r8
    8a18:      	setle	%r8b
    8a1c:      	cmpq	%rdi, %rdx
    8a1f:      	setle	%dil
    8a23:      	jmp	0x90a0 <generic_lsm_filter_arg+0x27c0>
    8a28:      	xorl	%ebx, %ebx
    8a2a:      	cmpl	$0x29, %ecx
    8a2d:      	jne	0x8a38 <generic_lsm_filter_arg+0x2158>
    8a2f:      	testq	%rdx, %rdx
    8a32:      	je	0x8a38 <generic_lsm_filter_arg+0x2158>
    8a34:      	movzbl	0x3a(%rdx), %ebx
    8a38:      	cmpl	$0x29, %ecx
    8a3b:      	je	0x8a46 <generic_lsm_filter_arg+0x2166>
    8a3d:      	cmpl	$0x7, %ecx
    8a40:      	jne	0x8fd0 <generic_lsm_filter_arg+0x26f0>
    8a46:      	movq	%r11, %r12
    8a49:      	movzbl	0x10(%r13), %eax
    8a4e:      	movl	%eax, 0x34(%rsp)
    8a52:      	movl	$0x1, %eax
    8a57:      	movq	(%rip), %rdi            # 0x8a5e <generic_lsm_filter_arg+0x217e>
    8a5e:      	leaq	0x34(%rsp), %rsi
    8a63:      	callq	*%rax
    8a65:      	testq	%rax, %rax
    8a68:      	je	0x8a83 <generic_lsm_filter_arg+0x21a3>
    8a6a:      	movq	%rax, %rdi
    8a6d:      	movl	%ebx, %eax
    8a6f:      	movq	%rax, 0x70(%rsp)
    8a74:      	movl	$0x1, %eax
    8a79:      	movq	0x28(%rsp), %rsi
    8a7e:      	jmp	0x84cf <generic_lsm_filter_arg+0x1bef>
    8a83:      	xorl	%ebx, %ebx
    8a85:      	movq	(%rsp), %rdi
    8a89:      	movq	0x8(%rsp), %r9
    8a8e:      	movq	%r12, %r11
    8a91:      	jmp	0x6bb0 <generic_lsm_filter_arg+0x2d0>
    8a96:      	xorl	%ebx, %ebx
    8a98:      	movq	%r15, %r11
    8a9b:      	movq	0x68(%rsp), %r15
    8aa0:      	jmp	0x8f73 <generic_lsm_filter_arg+0x2693>
    8aa5:      	cmpq	%rax, %rdi
    8aa8:      	movq	(%rsp), %rdi
    8aac:      	ja	0x8ab7 <generic_lsm_filter_arg+0x21d7>
    8aae:      	cmpq	%rsi, %rax
    8ab1:      	jbe	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    8ab7:      	cmpl	$0x29, %edx
    8aba:      	jb	0x69fd <generic_lsm_filter_arg+0x11d>
    8ac0:      	movq	0x30(%r13), %rdi
    8ac4:      	movq	0x38(%r13), %rsi
    8ac8:      	cmpl	$0xc, %ecx
    8acb:      	je	0x8ad6 <generic_lsm_filter_arg+0x21f6>
    8acd:      	cmpl	$0xa, %ecx
    8ad0:      	jne	0x90d3 <generic_lsm_filter_arg+0x27f3>
    8ad6:      	cmpq	%rax, %rdi
    8ad9:      	movq	(%rsp), %rdi
    8add:      	jg	0x90e5 <generic_lsm_filter_arg+0x2805>
    8ae3:      	cmpq	%rsi, %rax
    8ae6:      	jle	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    8aec:      	jmp	0x90e5 <generic_lsm_filter_arg+0x2805>
    8af1:      	cmpl	%edx, (%r12)
    8af5:      	ja	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    8afb:      	jmp	0x8b07 <generic_lsm_filter_arg+0x2227>
    8afd:      	cmpl	%edx, (%r12)
    8b01:      	jb	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    8b07:      	movl	0x8(%r13), %edx
    8b0b:      	cmpl	$0xd, %edx
    8b0e:      	jb	0x9fa1 <generic_lsm_filter_arg+0x36c1>
    8b14:      	movl	0x14(%r13), %esi
    8b18:      	cmpl	$0x2, %eax
    8b1b:      	jle	0x8b38 <generic_lsm_filter_arg+0x2258>
    8b1d:      	leal	-0x3(%rax), %edi
    8b20:      	cmpl	$0x2, %edi
    8b23:      	jae	0x8b6e <generic_lsm_filter_arg+0x228e>
    8b25:      	cmpl	%esi, (%r12)
    8b29:      	movq	(%rsp), %rdi
    8b2d:      	je	0x6ba5 <generic_lsm_filter_arg+0x2c5>
    8b33:      	jmp	0x95e8 <generic_lsm_filter_arg+0x2d08>
    8b38:      	cmpl	$0x1, %eax
    8b3b:      	je	0x8b8a <generic_lsm_filter_arg+0x22aa>
    8b3d:      	cmpl	$0x2, %eax
    8b40:      	jne	0x95e8 <generic_lsm_filter_arg+0x2d08>
    8b46:      	cmpl	$0xc, %ecx
    8b49:      	ja	0x95de <generic_lsm_filter_arg+0x2cfe>
    8b4f:      	movl	$0x1402, %r8d           # imm = 0x1402
    8b55:      	btl	%ecx, %r8d
    8b59:      	jae	0x95de <generic_lsm_filter_arg+0x2cfe>
    8b5f:      	cmpl	%esi, (%r12)
    8b63:      	jl	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    8b69:      	jmp	0x95e8 <generic_lsm_filter_arg+0x2d08>
    8b6e:      	cmpl	$0xc, %eax
    8b71:      	movq	(%rsp), %rdi
    8b75:      	jne	0x95e8 <generic_lsm_filter_arg+0x2d08>
    8b7b:      	testl	%esi, (%r12)
    8b7f:      	jne	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    8b85:      	jmp	0x95e8 <generic_lsm_filter_arg+0x2d08>
    8b8a:      	cmpl	$0xc, %ecx
    8b8d:      	ja	0x95d2 <generic_lsm_filter_arg+0x2cf2>
    8b93:      	movl	$0x1402, %r8d           # imm = 0x1402
    8b99:      	btl	%ecx, %r8d
    8b9d:      	jae	0x95d2 <generic_lsm_filter_arg+0x2cf2>
    8ba3:      	cmpl	%esi, (%r12)
    8ba7:      	jg	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    8bad:      	jmp	0x95e8 <generic_lsm_filter_arg+0x2d08>
    8bb2:      	cmpl	$0x1, %eax
    8bb5:      	je	0x943e <generic_lsm_filter_arg+0x2b5e>
    8bbb:      	cmpl	$0x2, %eax
    8bbe:      	jne	0x944b <generic_lsm_filter_arg+0x2b6b>
    8bc4:      	movzbl	(%r12), %esi
    8bc9:      	cmpl	%esi, %edx
    8bcb:      	ja	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    8bd1:      	jmp	0x944b <generic_lsm_filter_arg+0x2b6b>
    8bd6:      	cmpl	$0x1, %eax
    8bd9:      	je	0x947f <generic_lsm_filter_arg+0x2b9f>
    8bdf:      	cmpl	$0x2, %eax
    8be2:      	jne	0x948c <generic_lsm_filter_arg+0x2bac>
    8be8:      	movzwl	(%r12), %esi
    8bed:      	cmpl	%esi, %edx
    8bef:      	ja	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    8bf5:      	jmp	0x948c <generic_lsm_filter_arg+0x2bac>
    8bfa:      	movl	$0x1, %ebx
    8bff:      	movq	(%rsp), %rdi
    8c03:      	jmp	0x9f1b <generic_lsm_filter_arg+0x363b>
    8c08:      	movq	(%rsp), %rdi
    8c0c:      	movq	0x8(%rsp), %r9
    8c11:      	movq	%rbp, %r11
    8c14:      	movzbl	%cl, %ebx
    8c17:      	jmp	0x6bb0 <generic_lsm_filter_arg+0x2d0>
    8c1c:      	movl	$0xa, %eax
    8c21:      	jmp	0x8c2f <generic_lsm_filter_arg+0x234f>
    8c23:      	movl	$0x6, %eax
    8c28:      	jmp	0x8c2f <generic_lsm_filter_arg+0x234f>
    8c2a:      	movl	$0x8, %eax
    8c2f:      	movl	%eax, %ecx
    8c31:      	andl	$0xf, %ecx
    8c34:      	movl	0x10(%r13,%rcx,4), %ecx
    8c39:      	cmpl	$-0x1, %ecx
    8c3c:      	je	0x9b73 <generic_lsm_filter_arg+0x3293>
    8c42:      	movl	%ecx, 0x88(%rsp)
    8c49:      	movl	%eax, 0x18(%rsp)
    8c4d:      	movq	%rsi, 0x60(%rsp)
    8c52:      	movl	$0x1, %eax
    8c57:      	movq	(%rip), %rdi            # 0x8c5e <generic_lsm_filter_arg+0x237e>
    8c5e:      	movq	0x28(%rsp), %rbx
    8c63:      	movq	%rbx, %rsi
    8c66:      	callq	*%rax
    8c68:      	movq	%rax, 0x20(%rsp)
    8c6d:      	movl	$0x1, %eax
    8c72:      	movq	(%rip), %rdi            # 0x8c79 <generic_lsm_filter_arg+0x2399>
    8c79:      	movq	%rbx, %rsi
    8c7c:      	callq	*%rax
    8c7e:      	movq	0x20(%rsp), %rdx
    8c83:      	testq	%rdx, %rdx
    8c86:      	je	0x9b73 <generic_lsm_filter_arg+0x3293>
    8c8c:      	movl	$0x0, %ebx
    8c91:      	testq	%rax, %rax
    8c94:      	movq	(%rsp), %rdi
    8c98:      	movq	0x8(%rsp), %r9
    8c9d:      	movq	0x10(%rsp), %r11
    8ca2:      	je	0x9b83 <generic_lsm_filter_arg+0x32a3>
    8ca8:      	movq	%rdx, %rcx
    8cab:      	movq	%rax, %rbx
    8cae:      	movq	%r12, %rdx
    8cb1:      	addq	$0x4, %rdx
    8cb5:      	cmpl	$0x5, 0x18(%rsp)
    8cba:      	jg	0x8cec <generic_lsm_filter_arg+0x240c>
    8cbc:      	movq	%rcx, %r12
    8cbf:      	movb	%bpl, (%rcx)
    8cc2:      	leaq	0x1(%rcx), %rdi
    8cc6:      	movl	$0x4, %eax
    8ccb:      	movl	%ebp, %esi
    8ccd:      	callq	*%rax
    8ccf:      	movq	0x60(%rsp), %rsi
    8cd4:      	subl	%ebp, %esi
    8cd6:      	jbe	0x8d20 <generic_lsm_filter_arg+0x2440>
    8cd8:      	leaq	(%r12,%rbp), %rdi
    8cdc:      	incq	%rdi
    8cdf:      	andl	$0xfff, %esi            # imm = 0xFFF
    8ce5:      	movl	$0x4, %eax
    8cea:      	jmp	0x8d1b <generic_lsm_filter_arg+0x243b>
    8cec:      	movq	%rcx, %r12
    8cef:      	movw	%bp, (%rcx)
    8cf2:      	leaq	0x2(%rcx), %rdi
    8cf6:      	movl	$0x4, %eax
    8cfb:      	movl	%ebp, %esi
    8cfd:      	callq	*%rax
    8cff:      	movq	0x60(%rsp), %rsi
    8d04:      	subl	%ebp, %esi
    8d06:      	jbe	0x8d20 <generic_lsm_filter_arg+0x2440>
    8d08:      	leaq	(%r12,%rbp), %rdi
    8d0c:      	addq	$0x2, %rdi
    8d10:      	andl	$0xfff, %esi            # imm = 0xFFF
    8d16:      	movl	$0x4, %eax
    8d1b:      	movq	%rbx, %rdx
    8d1e:      	callq	*%rax
    8d20:      	movl	0x88(%rsp), %eax
    8d27:      	movl	%eax, 0x38(%rsp)
    8d2b:      	movl	0x18(%rsp), %eax
    8d2f:      	cmpl	$0x4, %eax
    8d32:      	movq	(%rsp), %rdi
    8d36:      	movq	0x8(%rsp), %r9
    8d3b:      	movq	0x10(%rsp), %r11
    8d40:      	jle	0x8d7c <generic_lsm_filter_arg+0x249c>
    8d42:      	cmpl	$0x7, %eax
    8d45:      	jg	0x9390 <generic_lsm_filter_arg+0x2ab0>
    8d4b:      	cmpl	$0x5, %eax
    8d4e:      	je	0x9a61 <generic_lsm_filter_arg+0x3181>
    8d54:      	cmpl	$0x6, %eax
    8d57:      	je	0x9a28 <generic_lsm_filter_arg+0x3148>
    8d5d:      	cmpl	$0x7, %eax
    8d60:      	jne	0x96cc <generic_lsm_filter_arg+0x2dec>
    8d66:      	movl	$0x1, %eax
    8d6b:      	leaq	0x38(%rsp), %rsi
    8d70:      	movq	(%rip), %rdi            # 0x8d77 <generic_lsm_filter_arg+0x2497>
    8d77:      	jmp	0x9a85 <generic_lsm_filter_arg+0x31a5>
    8d7c:      	cmpl	$0x1, %eax
    8d7f:      	jle	0x94c0 <generic_lsm_filter_arg+0x2be0>
    8d85:      	cmpl	$0x2, %eax
    8d88:      	je	0x9a4e <generic_lsm_filter_arg+0x316e>
    8d8e:      	cmpl	$0x3, %eax
    8d91:      	je	0x9a15 <generic_lsm_filter_arg+0x3135>
    8d97:      	cmpl	$0x4, %eax
    8d9a:      	jne	0x96cc <generic_lsm_filter_arg+0x2dec>
    8da0:      	movl	$0x1, %eax
    8da5:      	leaq	0x38(%rsp), %rsi
    8daa:      	movq	(%rip), %rdi            # 0x8db1 <generic_lsm_filter_arg+0x24d1>
    8db1:      	jmp	0x9a85 <generic_lsm_filter_arg+0x31a5>
    8db6:      	movl	$0xa, %eax
    8dbb:      	jmp	0x8dc9 <generic_lsm_filter_arg+0x24e9>
    8dbd:      	movl	$0x6, %eax
    8dc2:      	jmp	0x8dc9 <generic_lsm_filter_arg+0x24e9>
    8dc4:      	movl	$0x8, %eax
    8dc9:      	movl	%eax, %ecx
    8dcb:      	andl	$0xf, %ecx
    8dce:      	movl	0x10(%r13,%rcx,4), %ecx
    8dd3:      	cmpl	$-0x1, %ecx
    8dd6:      	je	0x96cc <generic_lsm_filter_arg+0x2dec>
    8ddc:      	movl	%ecx, 0x90(%rsp)
    8de3:      	movq	%rbx, 0x88(%rsp)
    8deb:      	movl	%eax, 0x20(%rsp)
    8def:      	movq	%r8, 0x18(%rsp)
    8df4:      	movq	%rsi, 0x60(%rsp)
    8df9:      	movq	%r11, 0x10(%rsp)
    8dfe:      	movl	$0x1, %eax
    8e03:      	movq	(%rip), %rdi            # 0x8e0a <generic_lsm_filter_arg+0x252a>
    8e0a:      	movq	0x28(%rsp), %rbx
    8e0f:      	movq	%rbx, %rsi
    8e12:      	callq	*%rax
    8e14:      	movq	%rax, %r12
    8e17:      	movl	$0x1, %eax
    8e1c:      	movq	(%rip), %rdi            # 0x8e23 <generic_lsm_filter_arg+0x2543>
    8e23:      	movq	%rbx, %rsi
    8e26:      	callq	*%rax
    8e28:      	testq	%r12, %r12
    8e2b:      	je	0x9b73 <generic_lsm_filter_arg+0x3293>
    8e31:      	movl	$0x0, %ebx
    8e36:      	testq	%rax, %rax
    8e39:      	movq	(%rsp), %rdi
    8e3d:      	movq	0x8(%rsp), %r9
    8e42:      	movq	0x10(%rsp), %r11
    8e47:      	je	0x9b83 <generic_lsm_filter_arg+0x32a3>
    8e4d:      	movq	%r12, %rcx
    8e50:      	movq	%rax, %r12
    8e53:      	cmpl	$0x5, 0x20(%rsp)
    8e58:      	jg	0x8e97 <generic_lsm_filter_arg+0x25b7>
    8e5a:      	movb	%bpl, (%rcx)
    8e5d:      	movq	%rcx, %rbp
    8e60:      	leaq	0x1(%rcx), %rdi
    8e64:      	movl	$0x4, %eax
    8e69:      	movq	0x60(%rsp), %rbx
    8e6e:      	movq	0x18(%rsp), %rdx
    8e73:      	movl	%ebx, %esi
    8e75:      	callq	*%rax
    8e77:      	movq	0x88(%rsp), %rsi
    8e7f:      	subl	%ebx, %esi
    8e81:      	jbe	0x8ed8 <generic_lsm_filter_arg+0x25f8>
    8e83:      	leaq	(%rbx,%rbp), %rdi
    8e87:      	incq	%rdi
    8e8a:      	andl	$0xfff, %esi            # imm = 0xFFF
    8e90:      	movl	$0x4, %eax
    8e95:      	jmp	0x8ed3 <generic_lsm_filter_arg+0x25f3>
    8e97:      	movq	0x60(%rsp), %rbx
    8e9c:      	movq	%rcx, %rbp
    8e9f:      	movw	%bx, (%rcx)
    8ea2:      	leaq	0x2(%rcx), %rdi
    8ea6:      	movl	$0x4, %eax
    8eab:      	movq	0x18(%rsp), %rdx
    8eb0:      	movl	%ebx, %esi
    8eb2:      	callq	*%rax
    8eb4:      	movq	0x88(%rsp), %rsi
    8ebc:      	subl	%ebx, %esi
    8ebe:      	jbe	0x8ed8 <generic_lsm_filter_arg+0x25f8>
    8ec0:      	leaq	(%rbx,%rbp), %rdi
    8ec4:      	addq	$0x2, %rdi
    8ec8:      	andl	$0xfff, %esi            # imm = 0xFFF
    8ece:      	movl	$0x4, %eax
    8ed3:      	movq	%r12, %rdx
    8ed6:      	callq	*%rax
    8ed8:      	movl	0x90(%rsp), %eax
    8edf:      	movl	%eax, 0x38(%rsp)
    8ee3:      	movl	0x20(%rsp), %eax
    8ee7:      	cmpl	$0x4, %eax
    8eea:      	movq	(%rsp), %rdi
    8eee:      	movq	0x8(%rsp), %r9
    8ef3:      	movq	0x10(%rsp), %r11
    8ef8:      	jle	0x8f34 <generic_lsm_filter_arg+0x2654>
    8efa:      	cmpl	$0x7, %eax
    8efd:      	jg	0x93de <generic_lsm_filter_arg+0x2afe>
    8f03:      	cmpl	$0x5, %eax
    8f06:      	je	0x9b31 <generic_lsm_filter_arg+0x3251>
    8f0c:      	cmpl	$0x6, %eax
    8f0f:      	je	0x9af8 <generic_lsm_filter_arg+0x3218>
    8f15:      	cmpl	$0x7, %eax
    8f18:      	jne	0x96cc <generic_lsm_filter_arg+0x2dec>
    8f1e:      	movl	$0x1, %eax
    8f23:      	leaq	0x38(%rsp), %rsi
    8f28:      	movq	(%rip), %rdi            # 0x8f2f <generic_lsm_filter_arg+0x264f>
    8f2f:      	jmp	0x9b55 <generic_lsm_filter_arg+0x3275>
    8f34:      	cmpl	$0x1, %eax
    8f37:      	jle	0x96a9 <generic_lsm_filter_arg+0x2dc9>
    8f3d:      	cmpl	$0x2, %eax
    8f40:      	je	0x9b1e <generic_lsm_filter_arg+0x323e>
    8f46:      	cmpl	$0x3, %eax
    8f49:      	je	0x9ae5 <generic_lsm_filter_arg+0x3205>
    8f4f:      	cmpl	$0x4, %eax
    8f52:      	jne	0x96cc <generic_lsm_filter_arg+0x2dec>
    8f58:      	movl	$0x1, %eax
    8f5d:      	leaq	0x38(%rsp), %rsi
    8f62:      	movq	(%rip), %rdi            # 0x8f69 <generic_lsm_filter_arg+0x2689>
    8f69:      	jmp	0x9b55 <generic_lsm_filter_arg+0x3275>
    8f6e:      	movl	$0x1, %ebx
    8f73:      	movq	(%rsp), %rdi
    8f77:      	movq	0x8(%rsp), %r9
    8f7c:      	jmp	0x9f1b <generic_lsm_filter_arg+0x363b>
    8f81:      	cmpl	%edx, %r8d
    8f84:      	setbe	%r8b
    8f88:      	cmpl	%edi, %edx
    8f8a:      	setbe	%dil
    8f8e:      	andb	%r8b, %dil
    8f91:      	orb	%dil, %al
    8f94:      	cmpl	$0x19, %esi
    8f97:      	jb	0x992c <generic_lsm_filter_arg+0x304c>
    8f9d:      	movl	0x20(%r13), %r8d
    8fa1:      	movl	0x24(%r13), %edi
    8fa5:      	cmpl	$0xc, %ecx
    8fa8:      	ja	0x9518 <generic_lsm_filter_arg+0x2c38>
    8fae:      	movl	$0x1402, %r10d          # imm = 0x1402
    8fb4:      	btl	%ecx, %r10d
    8fb8:      	jae	0x9518 <generic_lsm_filter_arg+0x2c38>
    8fbe:      	cmpl	%edx, %r8d
    8fc1:      	setle	%r8b
    8fc5:      	cmpl	%edi, %edx
    8fc7:      	setle	%dil
    8fcb:      	jmp	0x9525 <generic_lsm_filter_arg+0x2c45>
    8fd0:      	xorl	%ebx, %ebx
    8fd2:      	jmp	0x6bb0 <generic_lsm_filter_arg+0x2d0>
    8fd7:      	cmpl	%eax, %edi
    8fd9:      	movq	(%rsp), %rdi
    8fdd:      	ja	0x8fe7 <generic_lsm_filter_arg+0x2707>
    8fdf:      	cmpl	%esi, %eax
    8fe1:      	jbe	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    8fe7:      	cmpl	$0x19, %edx
    8fea:      	jb	0x69fd <generic_lsm_filter_arg+0x11d>
    8ff0:      	movl	0x20(%r13), %edi
    8ff4:      	movl	0x24(%r13), %esi
    8ff8:      	cmpl	$0xc, %ecx
    8ffb:      	ja	0x9583 <generic_lsm_filter_arg+0x2ca3>
    9001:      	movl	$0x1402, %r8d           # imm = 0x1402
    9007:      	btl	%ecx, %r8d
    900b:      	jae	0x9583 <generic_lsm_filter_arg+0x2ca3>
    9011:      	cmpl	%eax, %edi
    9013:      	movq	(%rsp), %rdi
    9017:      	jg	0x9593 <generic_lsm_filter_arg+0x2cb3>
    901d:      	cmpl	%esi, %eax
    901f:      	jle	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    9025:      	jmp	0x9593 <generic_lsm_filter_arg+0x2cb3>
    902a:      	movl	$0x100, %esi            # imm = 0x100
    902f:      	cmpl	$0x101, %eax            # imm = 0x101
    9034:      	jb	0x9062 <generic_lsm_filter_arg+0x2782>
    9036:      	movl	$0x200, %esi            # imm = 0x200
    903b:      	cmpl	$0x201, %eax            # imm = 0x201
    9040:      	jb	0x9062 <generic_lsm_filter_arg+0x2782>
    9042:      	movl	$0x400, %esi            # imm = 0x400
    9047:      	cmpl	$0x401, %eax            # imm = 0x401
    904c:      	jb	0x9062 <generic_lsm_filter_arg+0x2782>
    904e:      	xorl	%esi, %esi
    9050:      	cmpl	$0x801, %eax            # imm = 0x801
    9055:      	setae	%sil
    9059:      	shll	$0xb, %esi
    905c:      	addl	$0x800, %esi            # imm = 0x800
    9062:      	leal	-0x100(%rsi), %eax
    9068:      	rorxl	$0x8, %eax, %eax
    906e:      	cmpl	$0x2, %eax
    9071:      	jg	0x9422 <generic_lsm_filter_arg+0x2b42>
    9077:      	testl	%eax, %eax
    9079:      	je	0x9789 <generic_lsm_filter_arg+0x2ea9>
    907f:      	cmpl	$0x1, %eax
    9082:      	jne	0x9782 <generic_lsm_filter_arg+0x2ea2>
    9088:      	movl	$0x7, %eax
    908d:      	jmp	0x9795 <generic_lsm_filter_arg+0x2eb5>
    9092:      	cmpq	%rdx, %r8
    9095:      	setbe	%r8b
    9099:      	cmpq	%rdi, %rdx
    909c:      	setbe	%dil
    90a0:      	andb	%r8b, %dil
    90a3:      	orb	%dil, %al
    90a6:      	cmpl	$0x39, %esi
    90a9:      	jb	0x992c <generic_lsm_filter_arg+0x304c>
    90af:      	movq	0x40(%r13), %rdi
    90b3:      	movq	0x48(%r13), %rsi
    90b7:      	cmpl	$0xc, %ecx
    90ba:      	je	0x90c5 <generic_lsm_filter_arg+0x27e5>
    90bc:      	cmpl	$0xa, %ecx
    90bf:      	jne	0x968f <generic_lsm_filter_arg+0x2daf>
    90c5:      	cmpq	%rdx, %rdi
    90c8:      	setle	%cl
    90cb:      	cmpq	%rsi, %rdx
    90ce:      	jmp	0x955c <generic_lsm_filter_arg+0x2c7c>
    90d3:      	cmpq	%rax, %rdi
    90d6:      	movq	(%rsp), %rdi
    90da:      	ja	0x90e5 <generic_lsm_filter_arg+0x2805>
    90dc:      	cmpq	%rsi, %rax
    90df:      	jbe	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    90e5:      	cmpl	$0x39, %edx
    90e8:      	jb	0x69fd <generic_lsm_filter_arg+0x11d>
    90ee:      	movq	0x40(%r13), %rsi
    90f2:      	movq	0x48(%r13), %rdx
    90f6:      	cmpl	$0xc, %ecx
    90f9:      	je	0x9104 <generic_lsm_filter_arg+0x2824>
    90fb:      	cmpl	$0xa, %ecx
    90fe:      	jne	0x96f5 <generic_lsm_filter_arg+0x2e15>
    9104:      	cmpq	%rax, %rsi
    9107:      	jg	0x69fd <generic_lsm_filter_arg+0x11d>
    910d:      	cmpq	%rdx, %rax
    9110:      	jle	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    9116:      	jmp	0x69fd <generic_lsm_filter_arg+0x11d>
    911b:      	cmpq	%rsi, (%r12)
    911f:      	ja	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    9125:      	jmp	0x9131 <generic_lsm_filter_arg+0x2851>
    9127:      	cmpq	%rsi, (%r12)
    912b:      	jb	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    9131:      	cmpl	$0x19, %edx
    9134:      	jb	0x9fa1 <generic_lsm_filter_arg+0x36c1>
    913a:      	movq	0x20(%r13), %rsi
    913e:      	cmpl	$0x2, %eax
    9141:      	jle	0x915e <generic_lsm_filter_arg+0x287e>
    9143:      	leal	-0x3(%rax), %edi
    9146:      	cmpl	$0x2, %edi
    9149:      	jae	0x918d <generic_lsm_filter_arg+0x28ad>
    914b:      	cmpq	%rsi, (%r12)
    914f:      	movq	(%rsp), %rdi
    9153:      	je	0x6ba5 <generic_lsm_filter_arg+0x2c5>
    9159:      	jmp	0x9953 <generic_lsm_filter_arg+0x3073>
    915e:      	cmpl	$0x1, %eax
    9161:      	je	0x93c1 <generic_lsm_filter_arg+0x2ae1>
    9167:      	cmpl	$0x2, %eax
    916a:      	jne	0x9953 <generic_lsm_filter_arg+0x3073>
    9170:      	cmpl	$0xc, %ecx
    9173:      	je	0x917e <generic_lsm_filter_arg+0x289e>
    9175:      	cmpl	$0xa, %ecx
    9178:      	jne	0x9949 <generic_lsm_filter_arg+0x3069>
    917e:      	cmpq	%rsi, (%r12)
    9182:      	jl	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    9188:      	jmp	0x9953 <generic_lsm_filter_arg+0x3073>
    918d:      	cmpl	$0xc, %eax
    9190:      	movq	(%rsp), %rdi
    9194:      	jne	0x9953 <generic_lsm_filter_arg+0x3073>
    919a:      	testq	%rsi, (%r12)
    919e:      	jne	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    91a4:      	jmp	0x9953 <generic_lsm_filter_arg+0x3073>
    91a9:      	movl	$0xa, %eax
    91ae:      	jmp	0x91bc <generic_lsm_filter_arg+0x28dc>
    91b0:      	movl	$0x6, %eax
    91b5:      	jmp	0x91bc <generic_lsm_filter_arg+0x28dc>
    91b7:      	movl	$0x8, %eax
    91bc:      	movl	%eax, %ecx
    91be:      	andl	$0xf, %ecx
    91c1:      	movl	0x10(%r13,%rcx,4), %ecx
    91c6:      	cmpl	$-0x1, %ecx
    91c9:      	je	0x9777 <generic_lsm_filter_arg+0x2e97>
    91cf:      	movl	%ecx, 0x88(%rsp)
    91d6:      	movl	%eax, 0x60(%rsp)
    91da:      	movq	%rsi, 0x90(%rsp)
    91e2:      	movq	%r11, 0x10(%rsp)
    91e7:      	movl	$0x1, %eax
    91ec:      	movq	(%rip), %rdi            # 0x91f3 <generic_lsm_filter_arg+0x2913>
    91f3:      	movq	0x28(%rsp), %rbx
    91f8:      	movq	%rbx, %rsi
    91fb:      	callq	*%rax
    91fd:      	movq	%rax, %r12
    9200:      	movl	$0x1, %eax
    9205:      	movq	(%rip), %rdi            # 0x920c <generic_lsm_filter_arg+0x292c>
    920c:      	movq	%rbx, %rsi
    920f:      	callq	*%rax
    9211:      	movq	%r12, 0x20(%rsp)
    9216:      	testq	%r12, %r12
    9219:      	je	0x9f0b <generic_lsm_filter_arg+0x362b>
    921f:      	movl	$0x0, %ebx
    9224:      	testq	%rax, %rax
    9227:      	movq	(%rsp), %rdi
    922b:      	movq	0x8(%rsp), %r9
    9230:      	movq	0x10(%rsp), %r11
    9235:      	je	0x9f1b <generic_lsm_filter_arg+0x363b>
    923b:      	movq	%rax, %r12
    923e:      	movl	0x60(%rsp), %ebx
    9242:      	cmpl	$0x5, %ebx
    9245:      	jg	0x9289 <generic_lsm_filter_arg+0x29a9>
    9247:      	movq	0x20(%rsp), %rax
    924c:      	movb	%bpl, (%rax)
    924f:      	leaq	0x1(%rax), %rdi
    9253:      	movl	$0x4, %eax
    9258:      	movq	0x18(%rsp), %rdx
    925d:      	movl	%ebp, %esi
    925f:      	callq	*%rax
    9261:      	movq	0x90(%rsp), %rsi
    9269:      	subl	%ebp, %esi
    926b:      	jbe	0x92cc <generic_lsm_filter_arg+0x29ec>
    926d:      	movq	0x20(%rsp), %rax
    9272:      	leaq	(%rax,%rbp), %rdi
    9276:      	incq	%rdi
    9279:      	andl	$0xfff, %esi            # imm = 0xFFF
    927f:      	movl	$0x4, %eax
    9284:      	movq	%r12, %rdx
    9287:      	jmp	0x92ca <generic_lsm_filter_arg+0x29ea>
    9289:      	movq	0x20(%rsp), %rax
    928e:      	movw	%bp, (%rax)
    9291:      	leaq	0x2(%rax), %rdi
    9295:      	movl	$0x4, %eax
    929a:      	movq	0x18(%rsp), %rdx
    929f:      	movl	%ebp, %esi
    92a1:      	callq	*%rax
    92a3:      	movq	0x90(%rsp), %rsi
    92ab:      	subl	%ebp, %esi
    92ad:      	jbe	0x92cc <generic_lsm_filter_arg+0x29ec>
    92af:      	movq	0x20(%rsp), %rax
    92b4:      	leaq	(%rax,%rbp), %rdi
    92b8:      	addq	$0x2, %rdi
    92bc:      	andl	$0xfff, %esi            # imm = 0xFFF
    92c2:      	movl	$0x4, %eax
    92c7:      	movq	%r12, %rdx
    92ca:      	callq	*%rax
    92cc:      	movl	0x88(%rsp), %eax
    92d3:      	movl	%eax, 0x38(%rsp)
    92d7:      	cmpl	$0x4, %ebx
    92da:      	movq	0x8(%rsp), %r9
    92df:      	movq	0x10(%rsp), %r11
    92e4:      	jle	0x9320 <generic_lsm_filter_arg+0x2a40>
    92e6:      	cmpl	$0x7, %ebx
    92e9:      	jg	0x94e7 <generic_lsm_filter_arg+0x2c07>
    92ef:      	cmpl	$0x5, %ebx
    92f2:      	je	0x9c0d <generic_lsm_filter_arg+0x332d>
    92f8:      	cmpl	$0x6, %ebx
    92fb:      	je	0x9bd4 <generic_lsm_filter_arg+0x32f4>
    9301:      	cmpl	$0x7, %ebx
    9304:      	jne	0x9777 <generic_lsm_filter_arg+0x2e97>
    930a:      	movl	$0x1, %eax
    930f:      	leaq	0x38(%rsp), %rsi
    9314:      	movq	(%rip), %rdi            # 0x931b <generic_lsm_filter_arg+0x2a3b>
    931b:      	jmp	0x9c31 <generic_lsm_filter_arg+0x3351>
    9320:      	cmpl	$0x1, %ebx
    9323:      	jle	0x9754 <generic_lsm_filter_arg+0x2e74>
    9329:      	cmpl	$0x2, %ebx
    932c:      	je	0x9bfa <generic_lsm_filter_arg+0x331a>
    9332:      	cmpl	$0x3, %ebx
    9335:      	je	0x9bc1 <generic_lsm_filter_arg+0x32e1>
    933b:      	cmpl	$0x4, %ebx
    933e:      	jne	0x9777 <generic_lsm_filter_arg+0x2e97>
    9344:      	movl	$0x1, %eax
    9349:      	leaq	0x38(%rsp), %rsi
    934e:      	movq	(%rip), %rdi            # 0x9355 <generic_lsm_filter_arg+0x2a75>
    9355:      	jmp	0x9c31 <generic_lsm_filter_arg+0x3351>
    935a:      	cmpl	$0xc, %eax
    935d:      	jne	0x944b <generic_lsm_filter_arg+0x2b6b>
    9363:      	movzbl	(%r12), %esi
    9368:      	testl	%esi, %edx
    936a:      	jne	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    9370:      	jmp	0x944b <generic_lsm_filter_arg+0x2b6b>
    9375:      	cmpl	$0xc, %eax
    9378:      	jne	0x948c <generic_lsm_filter_arg+0x2bac>
    937e:      	movzwl	(%r12), %esi
    9383:      	testl	%esi, %edx
    9385:      	jne	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    938b:      	jmp	0x948c <generic_lsm_filter_arg+0x2bac>
    9390:      	cmpl	$0x8, %eax
    9393:      	je	0x9a74 <generic_lsm_filter_arg+0x3194>
    9399:      	cmpl	$0x9, %eax
    939c:      	je	0x9a3b <generic_lsm_filter_arg+0x315b>
    93a2:      	cmpl	$0xa, %eax
    93a5:      	jne	0x96cc <generic_lsm_filter_arg+0x2dec>
    93ab:      	movl	$0x1, %eax
    93b0:      	leaq	0x38(%rsp), %rsi
    93b5:      	movq	(%rip), %rdi            # 0x93bc <generic_lsm_filter_arg+0x2adc>
    93bc:      	jmp	0x9a85 <generic_lsm_filter_arg+0x31a5>
    93c1:      	cmpl	$0xc, %ecx
    93c4:      	je	0x93cf <generic_lsm_filter_arg+0x2aef>
    93c6:      	cmpl	$0xa, %ecx
    93c9:      	jne	0x993d <generic_lsm_filter_arg+0x305d>
    93cf:      	cmpq	%rsi, (%r12)
    93d3:      	jg	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    93d9:      	jmp	0x9953 <generic_lsm_filter_arg+0x3073>
    93de:      	cmpl	$0x8, %eax
    93e1:      	je	0x9b44 <generic_lsm_filter_arg+0x3264>
    93e7:      	cmpl	$0x9, %eax
    93ea:      	je	0x9b0b <generic_lsm_filter_arg+0x322b>
    93f0:      	cmpl	$0xa, %eax
    93f3:      	jne	0x96cc <generic_lsm_filter_arg+0x2dec>
    93f9:      	movl	$0x1, %eax
    93fe:      	leaq	0x38(%rsp), %rsi
    9403:      	movq	(%rip), %rdi            # 0x940a <generic_lsm_filter_arg+0x2b2a>
    940a:      	jmp	0x9b55 <generic_lsm_filter_arg+0x3275>
    940f:      	movq	(%rsp), %rdi
    9413:      	movq	0x8(%rsp), %r9
    9418:      	movq	0x10(%rsp), %r11
    941d:      	jmp	0x6bb0 <generic_lsm_filter_arg+0x2d0>
    9422:      	cmpl	$0x3, %eax
    9425:      	je	0x9790 <generic_lsm_filter_arg+0x2eb0>
    942b:      	cmpl	$0x7, %eax
    942e:      	jne	0x9782 <generic_lsm_filter_arg+0x2ea2>
    9434:      	movl	$0x9, %eax
    9439:      	jmp	0x9795 <generic_lsm_filter_arg+0x2eb5>
    943e:      	movzbl	(%r12), %esi
    9443:      	cmpl	%esi, %edx
    9445:      	jb	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    944b:      	cmpl	$0x11, %ecx
    944e:      	jb	0x9fa1 <generic_lsm_filter_arg+0x36c1>
    9454:      	movl	0x18(%r13), %edx
    9458:      	cmpl	$0x2, %eax
    945b:      	jle	0x970c <generic_lsm_filter_arg+0x2e2c>
    9461:      	leal	-0x3(%rax), %esi
    9464:      	cmpl	$0x2, %esi
    9467:      	jae	0x99cc <generic_lsm_filter_arg+0x30ec>
    946d:      	movzbl	(%r12), %esi
    9472:      	cmpl	%esi, %edx
    9474:      	je	0x6ba5 <generic_lsm_filter_arg+0x2c5>
    947a:      	jmp	0x9c5b <generic_lsm_filter_arg+0x337b>
    947f:      	movzwl	(%r12), %esi
    9484:      	cmpl	%esi, %edx
    9486:      	jb	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    948c:      	cmpl	$0x11, %ecx
    948f:      	jb	0x9fa1 <generic_lsm_filter_arg+0x36c1>
    9495:      	movl	0x18(%r13), %edx
    9499:      	cmpl	$0x2, %eax
    949c:      	jle	0x9730 <generic_lsm_filter_arg+0x2e50>
    94a2:      	leal	-0x3(%rax), %esi
    94a5:      	cmpl	$0x2, %esi
    94a8:      	jae	0x99e7 <generic_lsm_filter_arg+0x3107>
    94ae:      	movzwl	(%r12), %esi
    94b3:      	cmpl	%esi, %edx
    94b5:      	je	0x6ba5 <generic_lsm_filter_arg+0x2c5>
    94bb:      	jmp	0x9ca3 <generic_lsm_filter_arg+0x33c3>
    94c0:      	testl	%eax, %eax
    94c2:      	je	0x9a02 <generic_lsm_filter_arg+0x3122>
    94c8:      	cmpl	$0x1, %eax
    94cb:      	jne	0x96cc <generic_lsm_filter_arg+0x2dec>
    94d1:      	movl	$0x1, %eax
    94d6:      	leaq	0x38(%rsp), %rsi
    94db:      	movq	(%rip), %rdi            # 0x94e2 <generic_lsm_filter_arg+0x2c02>
    94e2:      	jmp	0x9a85 <generic_lsm_filter_arg+0x31a5>
    94e7:      	cmpl	$0x8, %ebx
    94ea:      	je	0x9c20 <generic_lsm_filter_arg+0x3340>
    94f0:      	cmpl	$0x9, %ebx
    94f3:      	je	0x9be7 <generic_lsm_filter_arg+0x3307>
    94f9:      	cmpl	$0xa, %ebx
    94fc:      	jne	0x9777 <generic_lsm_filter_arg+0x2e97>
    9502:      	movl	$0x1, %eax
    9507:      	leaq	0x38(%rsp), %rsi
    950c:      	movq	(%rip), %rdi            # 0x9513 <generic_lsm_filter_arg+0x2c33>
    9513:      	jmp	0x9c31 <generic_lsm_filter_arg+0x3351>
    9518:      	cmpl	%edx, %r8d
    951b:      	setbe	%r8b
    951f:      	cmpl	%edi, %edx
    9521:      	setbe	%dil
    9525:      	andb	%r8b, %dil
    9528:      	orb	%dil, %al
    952b:      	cmpl	$0x21, %esi
    952e:      	jb	0x992c <generic_lsm_filter_arg+0x304c>
    9534:      	movl	0x28(%r13), %edi
    9538:      	movl	0x2c(%r13), %esi
    953c:      	cmpl	$0xc, %ecx
    953f:      	ja	0x991e <generic_lsm_filter_arg+0x303e>
    9545:      	movl	$0x1402, %r8d           # imm = 0x1402
    954b:      	btl	%ecx, %r8d
    954f:      	jae	0x991e <generic_lsm_filter_arg+0x303e>
    9555:      	cmpl	%edx, %edi
    9557:      	setle	%cl
    955a:      	cmpl	%esi, %edx
    955c:      	setle	%dl
    955f:      	jmp	0x9928 <generic_lsm_filter_arg+0x3048>
    9564:      	xorl	%ebx, %ebx
    9566:      	jmp	0x956d <generic_lsm_filter_arg+0x2c8d>
    9568:      	movl	$0x1, %ebx
    956d:      	movq	(%rsp), %rdi
    9571:      	movq	0x8(%rsp), %r9
    9576:      	movq	%r15, %r11
    9579:      	movq	0x68(%rsp), %r15
    957e:      	jmp	0x9f1b <generic_lsm_filter_arg+0x363b>
    9583:      	cmpl	%eax, %edi
    9585:      	movq	(%rsp), %rdi
    9589:      	ja	0x9593 <generic_lsm_filter_arg+0x2cb3>
    958b:      	cmpl	%esi, %eax
    958d:      	jbe	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    9593:      	cmpl	$0x21, %edx
    9596:      	jb	0x69fd <generic_lsm_filter_arg+0x11d>
    959c:      	movl	0x28(%r13), %esi
    95a0:      	movl	0x2c(%r13), %edx
    95a4:      	cmpl	$0xc, %ecx
    95a7:      	ja	0x9aa0 <generic_lsm_filter_arg+0x31c0>
    95ad:      	movl	$0x1402, %r8d           # imm = 0x1402
    95b3:      	btl	%ecx, %r8d
    95b7:      	jae	0x9aa0 <generic_lsm_filter_arg+0x31c0>
    95bd:      	cmpl	%eax, %esi
    95bf:      	jg	0x69fd <generic_lsm_filter_arg+0x11d>
    95c5:      	cmpl	%edx, %eax
    95c7:      	jle	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    95cd:      	jmp	0x69fd <generic_lsm_filter_arg+0x11d>
    95d2:      	cmpl	%esi, (%r12)
    95d6:      	ja	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    95dc:      	jmp	0x95e8 <generic_lsm_filter_arg+0x2d08>
    95de:      	cmpl	%esi, (%r12)
    95e2:      	jb	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    95e8:      	cmpl	$0x11, %edx
    95eb:      	jb	0x9fa1 <generic_lsm_filter_arg+0x36c1>
    95f1:      	movl	0x18(%r13), %esi
    95f5:      	cmpl	$0x2, %eax
    95f8:      	jle	0x9615 <generic_lsm_filter_arg+0x2d35>
    95fa:      	leal	-0x3(%rax), %edi
    95fd:      	cmpl	$0x2, %edi
    9600:      	jae	0x964b <generic_lsm_filter_arg+0x2d6b>
    9602:      	cmpl	%esi, (%r12)
    9606:      	movq	(%rsp), %rdi
    960a:      	je	0x6ba5 <generic_lsm_filter_arg+0x2c5>
    9610:      	jmp	0x9d30 <generic_lsm_filter_arg+0x3450>
    9615:      	cmpl	$0x1, %eax
    9618:      	je	0x9667 <generic_lsm_filter_arg+0x2d87>
    961a:      	cmpl	$0x2, %eax
    961d:      	jne	0x9d30 <generic_lsm_filter_arg+0x3450>
    9623:      	cmpl	$0xc, %ecx
    9626:      	ja	0x9d26 <generic_lsm_filter_arg+0x3446>
    962c:      	movl	$0x1402, %r8d           # imm = 0x1402
    9632:      	btl	%ecx, %r8d
    9636:      	jae	0x9d26 <generic_lsm_filter_arg+0x3446>
    963c:      	cmpl	%esi, (%r12)
    9640:      	jl	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    9646:      	jmp	0x9d30 <generic_lsm_filter_arg+0x3450>
    964b:      	cmpl	$0xc, %eax
    964e:      	movq	(%rsp), %rdi
    9652:      	jne	0x9d30 <generic_lsm_filter_arg+0x3450>
    9658:      	testl	%esi, (%r12)
    965c:      	jne	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    9662:      	jmp	0x9d30 <generic_lsm_filter_arg+0x3450>
    9667:      	cmpl	$0xc, %ecx
    966a:      	ja	0x9d1a <generic_lsm_filter_arg+0x343a>
    9670:      	movl	$0x1402, %r8d           # imm = 0x1402
    9676:      	btl	%ecx, %r8d
    967a:      	jae	0x9d1a <generic_lsm_filter_arg+0x343a>
    9680:      	cmpl	%esi, (%r12)
    9684:      	jg	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    968a:      	jmp	0x9d30 <generic_lsm_filter_arg+0x3450>
    968f:      	cmpq	%rdx, %rdi
    9692:      	setbe	%cl
    9695:      	cmpq	%rsi, %rdx
    9698:      	jmp	0x9925 <generic_lsm_filter_arg+0x3045>
    969d:      	xorl	%ebx, %ebx
    969f:      	movq	0x68(%rsp), %r15
    96a4:      	jmp	0x9f1b <generic_lsm_filter_arg+0x363b>
    96a9:      	testl	%eax, %eax
    96ab:      	je	0x9ad2 <generic_lsm_filter_arg+0x31f2>
    96b1:      	cmpl	$0x1, %eax
    96b4:      	jne	0x96cc <generic_lsm_filter_arg+0x2dec>
    96b6:      	movl	$0x1, %eax
    96bb:      	leaq	0x38(%rsp), %rsi
    96c0:      	movq	(%rip), %rdi            # 0x96c7 <generic_lsm_filter_arg+0x2de7>
    96c7:      	jmp	0x9b55 <generic_lsm_filter_arg+0x3275>
    96cc:      	xorl	%ebx, %ebx
    96ce:      	movl	0x4(%r13), %eax
    96d2:      	cmpq	$0x25, %rax
    96d6:      	jbe	0x9b91 <generic_lsm_filter_arg+0x32b1>
    96dc:      	jmp	0x6bb0 <generic_lsm_filter_arg+0x2d0>
    96e1:      	movq	(%rsp), %rdi
    96e5:      	movq	0x8(%rsp), %r9
    96ea:      	movq	%r12, %r11
    96ed:      	movzbl	%cl, %ebx
    96f0:      	jmp	0x6bb0 <generic_lsm_filter_arg+0x2d0>
    96f5:      	cmpq	%rax, %rsi
    96f8:      	ja	0x69fd <generic_lsm_filter_arg+0x11d>
    96fe:      	cmpq	%rdx, %rax
    9701:      	jbe	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    9707:      	jmp	0x69fd <generic_lsm_filter_arg+0x11d>
    970c:      	cmpl	$0x1, %eax
    970f:      	je	0x9c4e <generic_lsm_filter_arg+0x336e>
    9715:      	cmpl	$0x2, %eax
    9718:      	jne	0x9c5b <generic_lsm_filter_arg+0x337b>
    971e:      	movzbl	(%r12), %esi
    9723:      	cmpl	%esi, %edx
    9725:      	ja	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    972b:      	jmp	0x9c5b <generic_lsm_filter_arg+0x337b>
    9730:      	cmpl	$0x1, %eax
    9733:      	je	0x9c96 <generic_lsm_filter_arg+0x33b6>
    9739:      	cmpl	$0x2, %eax
    973c:      	jne	0x9ca3 <generic_lsm_filter_arg+0x33c3>
    9742:      	movzwl	(%r12), %esi
    9747:      	cmpl	%esi, %edx
    9749:      	ja	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    974f:      	jmp	0x9ca3 <generic_lsm_filter_arg+0x33c3>
    9754:      	testl	%ebx, %ebx
    9756:      	je	0x9bae <generic_lsm_filter_arg+0x32ce>
    975c:      	cmpl	$0x1, %ebx
    975f:      	jne	0x9777 <generic_lsm_filter_arg+0x2e97>
    9761:      	movl	$0x1, %eax
    9766:      	leaq	0x38(%rsp), %rsi
    976b:      	movq	(%rip), %rdi            # 0x9772 <generic_lsm_filter_arg+0x2e92>
    9772:      	jmp	0x9c31 <generic_lsm_filter_arg+0x3351>
    9777:      	xorl	%ebx, %ebx
    9779:      	movq	(%rsp), %rdi
    977d:      	jmp	0x9f1b <generic_lsm_filter_arg+0x363b>
    9782:      	movl	$0xa, %eax
    9787:      	jmp	0x9795 <generic_lsm_filter_arg+0x2eb5>
    9789:      	movl	$0x6, %eax
    978e:      	jmp	0x9795 <generic_lsm_filter_arg+0x2eb5>
    9790:      	movl	$0x8, %eax
    9795:      	movl	%eax, %ecx
    9797:      	andl	$0xf, %ecx
    979a:      	movl	0x10(%r13,%rcx,4), %ecx
    979f:      	cmpl	$-0x1, %ecx
    97a2:      	je	0x9f0b <generic_lsm_filter_arg+0x362b>
    97a8:      	movl	%ecx, 0x90(%rsp)
    97af:      	movl	%eax, 0x88(%rsp)
    97b6:      	movq	%rsi, 0x60(%rsp)
    97bb:      	movl	$0x1, %eax
    97c0:      	movq	(%rip), %rdi            # 0x97c7 <generic_lsm_filter_arg+0x2ee7>
    97c7:      	movq	0x28(%rsp), %rbx
    97cc:      	movq	%rbx, %rsi
    97cf:      	callq	*%rax
    97d1:      	movq	%rax, %r12
    97d4:      	movl	$0x1, %eax
    97d9:      	movq	(%rip), %rdi            # 0x97e0 <generic_lsm_filter_arg+0x2f00>
    97e0:      	movq	%rbx, %rsi
    97e3:      	callq	*%rax
    97e5:      	movq	%r12, 0x20(%rsp)
    97ea:      	testq	%r12, %r12
    97ed:      	je	0x9f0b <generic_lsm_filter_arg+0x362b>
    97f3:      	movl	$0x0, %ebx
    97f8:      	testq	%rax, %rax
    97fb:      	movq	(%rsp), %rdi
    97ff:      	movq	0x8(%rsp), %r9
    9804:      	movq	0x10(%rsp), %r11
    9809:      	je	0x9f1b <generic_lsm_filter_arg+0x363b>
    980f:      	movq	%rax, %r12
    9812:      	movl	0x88(%rsp), %ebx
    9819:      	cmpl	$0x5, %ebx
    981c:      	jg	0x985a <generic_lsm_filter_arg+0x2f7a>
    981e:      	movq	0x20(%rsp), %rax
    9823:      	movb	%bpl, (%rax)
    9826:      	leaq	0x1(%rax), %rdi
    982a:      	movl	$0x4, %eax
    982f:      	movq	0x18(%rsp), %rdx
    9834:      	movl	%ebp, %esi
    9836:      	callq	*%rax
    9838:      	movq	0x60(%rsp), %rsi
    983d:      	subl	%ebp, %esi
    983f:      	jbe	0x989a <generic_lsm_filter_arg+0x2fba>
    9841:      	movq	0x20(%rsp), %rax
    9846:      	leaq	(%rax,%rbp), %rdi
    984a:      	incq	%rdi
    984d:      	andl	$0xfff, %esi            # imm = 0xFFF
    9853:      	movl	$0x4, %eax
    9858:      	jmp	0x9895 <generic_lsm_filter_arg+0x2fb5>
    985a:      	movq	0x20(%rsp), %rax
    985f:      	movw	%bp, (%rax)
    9862:      	leaq	0x2(%rax), %rdi
    9866:      	movl	$0x4, %eax
    986b:      	movq	0x18(%rsp), %rdx
    9870:      	movl	%ebp, %esi
    9872:      	callq	*%rax
    9874:      	movq	0x60(%rsp), %rsi
    9879:      	subl	%ebp, %esi
    987b:      	jbe	0x989a <generic_lsm_filter_arg+0x2fba>
    987d:      	movq	0x20(%rsp), %rax
    9882:      	leaq	(%rax,%rbp), %rdi
    9886:      	addq	$0x2, %rdi
    988a:      	andl	$0xfff, %esi            # imm = 0xFFF
    9890:      	movl	$0x4, %eax
    9895:      	movq	%r12, %rdx
    9898:      	callq	*%rax
    989a:      	movl	0x90(%rsp), %eax
    98a1:      	movl	%eax, 0x38(%rsp)
    98a5:      	cmpl	$0x4, %ebx
    98a8:      	jle	0x98e4 <generic_lsm_filter_arg+0x3004>
    98aa:      	cmpl	$0x7, %ebx
    98ad:      	jg	0x9ce9 <generic_lsm_filter_arg+0x3409>
    98b3:      	cmpl	$0x5, %ebx
    98b6:      	je	0x9ece <generic_lsm_filter_arg+0x35ee>
    98bc:      	cmpl	$0x6, %ebx
    98bf:      	je	0x9e95 <generic_lsm_filter_arg+0x35b5>
    98c5:      	cmpl	$0x7, %ebx
    98c8:      	jne	0x9f0b <generic_lsm_filter_arg+0x362b>
    98ce:      	movl	$0x1, %eax
    98d3:      	leaq	0x38(%rsp), %rsi
    98d8:      	movq	(%rip), %rdi            # 0x98df <generic_lsm_filter_arg+0x2fff>
    98df:      	jmp	0x9ef2 <generic_lsm_filter_arg+0x3612>
    98e4:      	cmpl	$0x1, %ebx
    98e7:      	jle	0x9dd4 <generic_lsm_filter_arg+0x34f4>
    98ed:      	cmpl	$0x2, %ebx
    98f0:      	je	0x9ebb <generic_lsm_filter_arg+0x35db>
    98f6:      	cmpl	$0x3, %ebx
    98f9:      	je	0x9e82 <generic_lsm_filter_arg+0x35a2>
    98ff:      	cmpl	$0x4, %ebx
    9902:      	jne	0x9f0b <generic_lsm_filter_arg+0x362b>
    9908:      	movl	$0x1, %eax
    990d:      	leaq	0x38(%rsp), %rsi
    9912:      	movq	(%rip), %rdi            # 0x9919 <generic_lsm_filter_arg+0x3039>
    9919:      	jmp	0x9ef2 <generic_lsm_filter_arg+0x3612>
    991e:      	cmpl	%edx, %edi
    9920:      	setbe	%cl
    9923:      	cmpl	%esi, %edx
    9925:      	setbe	%dl
    9928:      	andb	%cl, %dl
    992a:      	orb	%dl, %al
    992c:      	movq	(%rsp), %rdi
    9930:      	testb	%al, %al
    9932:      	je	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    9938:      	jmp	0x69fd <generic_lsm_filter_arg+0x11d>
    993d:      	cmpq	%rsi, (%r12)
    9941:      	ja	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    9947:      	jmp	0x9953 <generic_lsm_filter_arg+0x3073>
    9949:      	cmpq	%rsi, (%r12)
    994d:      	jb	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    9953:      	cmpl	$0x21, %edx
    9956:      	jb	0x9fa1 <generic_lsm_filter_arg+0x36c1>
    995c:      	movq	0x28(%r13), %rdx
    9960:      	cmpl	$0x2, %eax
    9963:      	jle	0x998e <generic_lsm_filter_arg+0x30ae>
    9965:      	leal	-0x3(%rax), %ecx
    9968:      	cmpl	$0x2, %ecx
    996b:      	jb	0x99bd <generic_lsm_filter_arg+0x30dd>
    996d:      	cmpl	$0x6, %eax
    9970:      	je	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    9976:      	cmpl	$0xc, %eax
    9979:      	jne	0x69fd <generic_lsm_filter_arg+0x11d>
    997f:      	testq	%rdx, (%r12)
    9983:      	jne	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    9989:      	jmp	0x9fa1 <generic_lsm_filter_arg+0x36c1>
    998e:      	cmpl	$0x1, %eax
    9991:      	je	0x9ab5 <generic_lsm_filter_arg+0x31d5>
    9997:      	cmpl	$0x2, %eax
    999a:      	jne	0x69fd <generic_lsm_filter_arg+0x11d>
    99a0:      	cmpl	$0xc, %ecx
    99a3:      	je	0x99ae <generic_lsm_filter_arg+0x30ce>
    99a5:      	cmpl	$0xa, %ecx
    99a8:      	jne	0x9e51 <generic_lsm_filter_arg+0x3571>
    99ae:      	cmpq	%rdx, (%r12)
    99b2:      	jl	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    99b8:      	jmp	0x9fa1 <generic_lsm_filter_arg+0x36c1>
    99bd:      	cmpq	%rdx, (%r12)
    99c1:      	jne	0x9fa1 <generic_lsm_filter_arg+0x36c1>
    99c7:      	jmp	0x6ba5 <generic_lsm_filter_arg+0x2c5>
    99cc:      	cmpl	$0xc, %eax
    99cf:      	jne	0x9c5b <generic_lsm_filter_arg+0x337b>
    99d5:      	movzbl	(%r12), %esi
    99da:      	testl	%esi, %edx
    99dc:      	jne	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    99e2:      	jmp	0x9c5b <generic_lsm_filter_arg+0x337b>
    99e7:      	cmpl	$0xc, %eax
    99ea:      	jne	0x9ca3 <generic_lsm_filter_arg+0x33c3>
    99f0:      	movzwl	(%r12), %esi
    99f5:      	testl	%esi, %edx
    99f7:      	jne	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    99fd:      	jmp	0x9ca3 <generic_lsm_filter_arg+0x33c3>
    9a02:      	movl	$0x1, %eax
    9a07:      	movq	(%rip), %rdi            # 0x9a0e <generic_lsm_filter_arg+0x312e>
    9a0e:      	leaq	0x38(%rsp), %rsi
    9a13:      	jmp	0x9a85 <generic_lsm_filter_arg+0x31a5>
    9a15:      	movl	$0x1, %eax
    9a1a:      	leaq	0x38(%rsp), %rsi
    9a1f:      	movq	(%rip), %rdi            # 0x9a26 <generic_lsm_filter_arg+0x3146>
    9a26:      	jmp	0x9a85 <generic_lsm_filter_arg+0x31a5>
    9a28:      	movl	$0x1, %eax
    9a2d:      	leaq	0x38(%rsp), %rsi
    9a32:      	movq	(%rip), %rdi            # 0x9a39 <generic_lsm_filter_arg+0x3159>
    9a39:      	jmp	0x9a85 <generic_lsm_filter_arg+0x31a5>
    9a3b:      	movl	$0x1, %eax
    9a40:      	leaq	0x38(%rsp), %rsi
    9a45:      	movq	(%rip), %rdi            # 0x9a4c <generic_lsm_filter_arg+0x316c>
    9a4c:      	jmp	0x9a85 <generic_lsm_filter_arg+0x31a5>
    9a4e:      	movl	$0x1, %eax
    9a53:      	leaq	0x38(%rsp), %rsi
    9a58:      	movq	(%rip), %rdi            # 0x9a5f <generic_lsm_filter_arg+0x317f>
    9a5f:      	jmp	0x9a85 <generic_lsm_filter_arg+0x31a5>
    9a61:      	movl	$0x1, %eax
    9a66:      	leaq	0x38(%rsp), %rsi
    9a6b:      	movq	(%rip), %rdi            # 0x9a72 <generic_lsm_filter_arg+0x3192>
    9a72:      	jmp	0x9a85 <generic_lsm_filter_arg+0x31a5>
    9a74:      	movl	$0x1, %eax
    9a79:      	leaq	0x38(%rsp), %rsi
    9a7e:      	movq	(%rip), %rdi            # 0x9a85 <generic_lsm_filter_arg+0x31a5>
    9a85:      	callq	*%rax
    9a87:      	testq	%rax, %rax
    9a8a:      	je	0x9b73 <generic_lsm_filter_arg+0x3293>
    9a90:      	movq	%rax, %rdi
    9a93:      	movl	$0x1, %eax
    9a98:      	movq	%r12, %rsi
    9a9b:      	jmp	0x9b67 <generic_lsm_filter_arg+0x3287>
    9aa0:      	cmpl	%eax, %esi
    9aa2:      	ja	0x69fd <generic_lsm_filter_arg+0x11d>
    9aa8:      	cmpl	%edx, %eax
    9aaa:      	jbe	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    9ab0:      	jmp	0x69fd <generic_lsm_filter_arg+0x11d>
    9ab5:      	cmpl	$0xc, %ecx
    9ab8:      	je	0x9ac3 <generic_lsm_filter_arg+0x31e3>
    9aba:      	cmpl	$0xa, %ecx
    9abd:      	jne	0x9e60 <generic_lsm_filter_arg+0x3580>
    9ac3:      	cmpq	%rdx, (%r12)
    9ac7:      	jg	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    9acd:      	jmp	0x9fa1 <generic_lsm_filter_arg+0x36c1>
    9ad2:      	movl	$0x1, %eax
    9ad7:      	movq	(%rip), %rdi            # 0x9ade <generic_lsm_filter_arg+0x31fe>
    9ade:      	leaq	0x38(%rsp), %rsi
    9ae3:      	jmp	0x9b55 <generic_lsm_filter_arg+0x3275>
    9ae5:      	movl	$0x1, %eax
    9aea:      	leaq	0x38(%rsp), %rsi
    9aef:      	movq	(%rip), %rdi            # 0x9af6 <generic_lsm_filter_arg+0x3216>
    9af6:      	jmp	0x9b55 <generic_lsm_filter_arg+0x3275>
    9af8:      	movl	$0x1, %eax
    9afd:      	leaq	0x38(%rsp), %rsi
    9b02:      	movq	(%rip), %rdi            # 0x9b09 <generic_lsm_filter_arg+0x3229>
    9b09:      	jmp	0x9b55 <generic_lsm_filter_arg+0x3275>
    9b0b:      	movl	$0x1, %eax
    9b10:      	leaq	0x38(%rsp), %rsi
    9b15:      	movq	(%rip), %rdi            # 0x9b1c <generic_lsm_filter_arg+0x323c>
    9b1c:      	jmp	0x9b55 <generic_lsm_filter_arg+0x3275>
    9b1e:      	movl	$0x1, %eax
    9b23:      	leaq	0x38(%rsp), %rsi
    9b28:      	movq	(%rip), %rdi            # 0x9b2f <generic_lsm_filter_arg+0x324f>
    9b2f:      	jmp	0x9b55 <generic_lsm_filter_arg+0x3275>
    9b31:      	movl	$0x1, %eax
    9b36:      	leaq	0x38(%rsp), %rsi
    9b3b:      	movq	(%rip), %rdi            # 0x9b42 <generic_lsm_filter_arg+0x3262>
    9b42:      	jmp	0x9b55 <generic_lsm_filter_arg+0x3275>
    9b44:      	movl	$0x1, %eax
    9b49:      	leaq	0x38(%rsp), %rsi
    9b4e:      	movq	(%rip), %rdi            # 0x9b55 <generic_lsm_filter_arg+0x3275>
    9b55:      	callq	*%rax
    9b57:      	testq	%rax, %rax
    9b5a:      	je	0x9b73 <generic_lsm_filter_arg+0x3293>
    9b5c:      	movq	%rax, %rdi
    9b5f:      	movl	$0x1, %eax
    9b64:      	movq	%rbp, %rsi
    9b67:      	callq	*%rax
    9b69:      	xorl	%ebx, %ebx
    9b6b:      	testq	%rax, %rax
    9b6e:      	setne	%bl
    9b71:      	jmp	0x9b75 <generic_lsm_filter_arg+0x3295>
    9b73:      	xorl	%ebx, %ebx
    9b75:      	movq	(%rsp), %rdi
    9b79:      	movq	0x8(%rsp), %r9
    9b7e:      	movq	0x10(%rsp), %r11
    9b83:      	movl	0x4(%r13), %eax
    9b87:      	cmpq	$0x25, %rax
    9b8b:      	ja	0x6bb0 <generic_lsm_filter_arg+0x2d0>
    9b91:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    9b9b:      	btq	%rax, %rcx
    9b9f:      	jae	0x6bb0 <generic_lsm_filter_arg+0x2d0>
    9ba5:      	xorq	$0x1, %rbx
    9ba9:      	jmp	0x6bb0 <generic_lsm_filter_arg+0x2d0>
    9bae:      	movl	$0x1, %eax
    9bb3:      	movq	(%rip), %rdi            # 0x9bba <generic_lsm_filter_arg+0x32da>
    9bba:      	leaq	0x38(%rsp), %rsi
    9bbf:      	jmp	0x9c31 <generic_lsm_filter_arg+0x3351>
    9bc1:      	movl	$0x1, %eax
    9bc6:      	leaq	0x38(%rsp), %rsi
    9bcb:      	movq	(%rip), %rdi            # 0x9bd2 <generic_lsm_filter_arg+0x32f2>
    9bd2:      	jmp	0x9c31 <generic_lsm_filter_arg+0x3351>
    9bd4:      	movl	$0x1, %eax
    9bd9:      	leaq	0x38(%rsp), %rsi
    9bde:      	movq	(%rip), %rdi            # 0x9be5 <generic_lsm_filter_arg+0x3305>
    9be5:      	jmp	0x9c31 <generic_lsm_filter_arg+0x3351>
    9be7:      	movl	$0x1, %eax
    9bec:      	leaq	0x38(%rsp), %rsi
    9bf1:      	movq	(%rip), %rdi            # 0x9bf8 <generic_lsm_filter_arg+0x3318>
    9bf8:      	jmp	0x9c31 <generic_lsm_filter_arg+0x3351>
    9bfa:      	movl	$0x1, %eax
    9bff:      	leaq	0x38(%rsp), %rsi
    9c04:      	movq	(%rip), %rdi            # 0x9c0b <generic_lsm_filter_arg+0x332b>
    9c0b:      	jmp	0x9c31 <generic_lsm_filter_arg+0x3351>
    9c0d:      	movl	$0x1, %eax
    9c12:      	leaq	0x38(%rsp), %rsi
    9c17:      	movq	(%rip), %rdi            # 0x9c1e <generic_lsm_filter_arg+0x333e>
    9c1e:      	jmp	0x9c31 <generic_lsm_filter_arg+0x3351>
    9c20:      	movl	$0x1, %eax
    9c25:      	leaq	0x38(%rsp), %rsi
    9c2a:      	movq	(%rip), %rdi            # 0x9c31 <generic_lsm_filter_arg+0x3351>
    9c31:      	callq	*%rax
    9c33:      	testq	%rax, %rax
    9c36:      	je	0x9f0b <generic_lsm_filter_arg+0x362b>
    9c3c:      	movq	%rax, %rdi
    9c3f:      	movl	$0x1, %eax
    9c44:      	movq	0x20(%rsp), %rsi
    9c49:      	jmp	0x83c8 <generic_lsm_filter_arg+0x1ae8>
    9c4e:      	movzbl	(%r12), %esi
    9c53:      	cmpl	%esi, %edx
    9c55:      	jb	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    9c5b:      	cmpl	$0x15, %ecx
    9c5e:      	jb	0x9fa1 <generic_lsm_filter_arg+0x36c1>
    9c64:      	movl	0x1c(%r13), %ecx
    9c68:      	cmpl	$0x2, %eax
    9c6b:      	jle	0x9dfb <generic_lsm_filter_arg+0x351b>
    9c71:      	leal	-0x3(%rax), %edx
    9c74:      	cmpl	$0x2, %edx
    9c77:      	jb	0x9e38 <generic_lsm_filter_arg+0x3558>
    9c7d:      	cmpl	$0x6, %eax
    9c80:      	je	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    9c86:      	cmpl	$0xc, %eax
    9c89:      	jne	0x69fd <generic_lsm_filter_arg+0x11d>
    9c8f:      	movzbl	(%r12), %edx
    9c94:      	jmp	0x9cdc <generic_lsm_filter_arg+0x33fc>
    9c96:      	movzwl	(%r12), %esi
    9c9b:      	cmpl	%esi, %edx
    9c9d:      	jb	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    9ca3:      	cmpl	$0x15, %ecx
    9ca6:      	jb	0x9fa1 <generic_lsm_filter_arg+0x36c1>
    9cac:      	movl	0x1c(%r13), %ecx
    9cb0:      	cmpl	$0x2, %eax
    9cb3:      	jle	0x9e14 <generic_lsm_filter_arg+0x3534>
    9cb9:      	leal	-0x3(%rax), %edx
    9cbc:      	cmpl	$0x2, %edx
    9cbf:      	jb	0x9e3f <generic_lsm_filter_arg+0x355f>
    9cc5:      	cmpl	$0x6, %eax
    9cc8:      	je	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    9cce:      	cmpl	$0xc, %eax
    9cd1:      	jne	0x69fd <generic_lsm_filter_arg+0x11d>
    9cd7:      	movzwl	(%r12), %edx
    9cdc:      	testl	%edx, %ecx
    9cde:      	jne	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    9ce4:      	jmp	0x9fa1 <generic_lsm_filter_arg+0x36c1>
    9ce9:      	cmpl	$0x8, %ebx
    9cec:      	je	0x9ee1 <generic_lsm_filter_arg+0x3601>
    9cf2:      	cmpl	$0x9, %ebx
    9cf5:      	je	0x9ea8 <generic_lsm_filter_arg+0x35c8>
    9cfb:      	cmpl	$0xa, %ebx
    9cfe:      	jne	0x9f0b <generic_lsm_filter_arg+0x362b>
    9d04:      	movl	$0x1, %eax
    9d09:      	leaq	0x38(%rsp), %rsi
    9d0e:      	movq	(%rip), %rdi            # 0x9d15 <generic_lsm_filter_arg+0x3435>
    9d15:      	jmp	0x9ef2 <generic_lsm_filter_arg+0x3612>
    9d1a:      	cmpl	%esi, (%r12)
    9d1e:      	ja	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    9d24:      	jmp	0x9d30 <generic_lsm_filter_arg+0x3450>
    9d26:      	cmpl	%esi, (%r12)
    9d2a:      	jb	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    9d30:      	cmpl	$0x15, %edx
    9d33:      	jb	0x9fa1 <generic_lsm_filter_arg+0x36c1>
    9d39:      	movl	0x1c(%r13), %edx
    9d3d:      	cmpl	$0x2, %eax
    9d40:      	jle	0x9d6b <generic_lsm_filter_arg+0x348b>
    9d42:      	leal	-0x3(%rax), %ecx
    9d45:      	cmpl	$0x2, %ecx
    9d48:      	jb	0x9d9f <generic_lsm_filter_arg+0x34bf>
    9d4a:      	cmpl	$0x6, %eax
    9d4d:      	je	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    9d53:      	cmpl	$0xc, %eax
    9d56:      	jne	0x69fd <generic_lsm_filter_arg+0x11d>
    9d5c:      	testl	%edx, (%r12)
    9d60:      	jne	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    9d66:      	jmp	0x9fa1 <generic_lsm_filter_arg+0x36c1>
    9d6b:      	cmpl	$0x1, %eax
    9d6e:      	je	0x9dae <generic_lsm_filter_arg+0x34ce>
    9d70:      	cmpl	$0x2, %eax
    9d73:      	jne	0x69fd <generic_lsm_filter_arg+0x11d>
    9d79:      	cmpl	$0xc, %ecx
    9d7c:      	ja	0x9f8b <generic_lsm_filter_arg+0x36ab>
    9d82:      	movl	$0x1402, %esi           # imm = 0x1402
    9d87:      	btl	%ecx, %esi
    9d8a:      	jae	0x9f8b <generic_lsm_filter_arg+0x36ab>
    9d90:      	cmpl	%edx, (%r12)
    9d94:      	jl	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    9d9a:      	jmp	0x9fa1 <generic_lsm_filter_arg+0x36c1>
    9d9f:      	cmpl	%edx, (%r12)
    9da3:      	je	0x6ba5 <generic_lsm_filter_arg+0x2c5>
    9da9:      	jmp	0x9fa1 <generic_lsm_filter_arg+0x36c1>
    9dae:      	cmpl	$0xc, %ecx
    9db1:      	ja	0x9f97 <generic_lsm_filter_arg+0x36b7>
    9db7:      	movl	$0x1402, %esi           # imm = 0x1402
    9dbc:      	btl	%ecx, %esi
    9dbf:      	jae	0x9f97 <generic_lsm_filter_arg+0x36b7>
    9dc5:      	cmpl	%edx, (%r12)
    9dc9:      	jg	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    9dcf:      	jmp	0x9fa1 <generic_lsm_filter_arg+0x36c1>
    9dd4:      	testl	%ebx, %ebx
    9dd6:      	je	0x9e6f <generic_lsm_filter_arg+0x358f>
    9ddc:      	cmpl	$0x1, %ebx
    9ddf:      	jne	0x9f0b <generic_lsm_filter_arg+0x362b>
    9de5:      	movl	$0x1, %eax
    9dea:      	leaq	0x38(%rsp), %rsi
    9def:      	movq	(%rip), %rdi            # 0x9df6 <generic_lsm_filter_arg+0x3516>
    9df6:      	jmp	0x9ef2 <generic_lsm_filter_arg+0x3612>
    9dfb:      	cmpl	$0x1, %eax
    9dfe:      	je	0x9f75 <generic_lsm_filter_arg+0x3695>
    9e04:      	cmpl	$0x2, %eax
    9e07:      	jne	0x69fd <generic_lsm_filter_arg+0x11d>
    9e0d:      	movzbl	(%r12), %edx
    9e12:      	jmp	0x9e2b <generic_lsm_filter_arg+0x354b>
    9e14:      	cmpl	$0x1, %eax
    9e17:      	je	0x9f7c <generic_lsm_filter_arg+0x369c>
    9e1d:      	cmpl	$0x2, %eax
    9e20:      	jne	0x69fd <generic_lsm_filter_arg+0x11d>
    9e26:      	movzwl	(%r12), %edx
    9e2b:      	cmpl	%edx, %ecx
    9e2d:      	ja	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    9e33:      	jmp	0x9fa1 <generic_lsm_filter_arg+0x36c1>
    9e38:      	movzbl	(%r12), %edx
    9e3d:      	jmp	0x9e44 <generic_lsm_filter_arg+0x3564>
    9e3f:      	movzwl	(%r12), %edx
    9e44:      	cmpl	%edx, %ecx
    9e46:      	je	0x6ba5 <generic_lsm_filter_arg+0x2c5>
    9e4c:      	jmp	0x9fa1 <generic_lsm_filter_arg+0x36c1>
    9e51:      	cmpq	%rdx, (%r12)
    9e55:      	jb	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    9e5b:      	jmp	0x9fa1 <generic_lsm_filter_arg+0x36c1>
    9e60:      	cmpq	%rdx, (%r12)
    9e64:      	ja	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    9e6a:      	jmp	0x9fa1 <generic_lsm_filter_arg+0x36c1>
    9e6f:      	movl	$0x1, %eax
    9e74:      	movq	(%rip), %rdi            # 0x9e7b <generic_lsm_filter_arg+0x359b>
    9e7b:      	leaq	0x38(%rsp), %rsi
    9e80:      	jmp	0x9ef2 <generic_lsm_filter_arg+0x3612>
    9e82:      	movl	$0x1, %eax
    9e87:      	leaq	0x38(%rsp), %rsi
    9e8c:      	movq	(%rip), %rdi            # 0x9e93 <generic_lsm_filter_arg+0x35b3>
    9e93:      	jmp	0x9ef2 <generic_lsm_filter_arg+0x3612>
    9e95:      	movl	$0x1, %eax
    9e9a:      	leaq	0x38(%rsp), %rsi
    9e9f:      	movq	(%rip), %rdi            # 0x9ea6 <generic_lsm_filter_arg+0x35c6>
    9ea6:      	jmp	0x9ef2 <generic_lsm_filter_arg+0x3612>
    9ea8:      	movl	$0x1, %eax
    9ead:      	leaq	0x38(%rsp), %rsi
    9eb2:      	movq	(%rip), %rdi            # 0x9eb9 <generic_lsm_filter_arg+0x35d9>
    9eb9:      	jmp	0x9ef2 <generic_lsm_filter_arg+0x3612>
    9ebb:      	movl	$0x1, %eax
    9ec0:      	leaq	0x38(%rsp), %rsi
    9ec5:      	movq	(%rip), %rdi            # 0x9ecc <generic_lsm_filter_arg+0x35ec>
    9ecc:      	jmp	0x9ef2 <generic_lsm_filter_arg+0x3612>
    9ece:      	movl	$0x1, %eax
    9ed3:      	leaq	0x38(%rsp), %rsi
    9ed8:      	movq	(%rip), %rdi            # 0x9edf <generic_lsm_filter_arg+0x35ff>
    9edf:      	jmp	0x9ef2 <generic_lsm_filter_arg+0x3612>
    9ee1:      	movl	$0x1, %eax
    9ee6:      	leaq	0x38(%rsp), %rsi
    9eeb:      	movq	(%rip), %rdi            # 0x9ef2 <generic_lsm_filter_arg+0x3612>
    9ef2:      	callq	*%rax
    9ef4:      	testq	%rax, %rax
    9ef7:      	je	0x9f0b <generic_lsm_filter_arg+0x362b>
    9ef9:      	movq	%rax, %rdi
    9efc:      	movl	$0x1, %eax
    9f01:      	movq	0x20(%rsp), %rsi
    9f06:      	jmp	0x83c8 <generic_lsm_filter_arg+0x1ae8>
    9f0b:      	xorl	%ebx, %ebx
    9f0d:      	movq	(%rsp), %rdi
    9f11:      	movq	0x8(%rsp), %r9
    9f16:      	movq	0x10(%rsp), %r11
    9f1b:      	movl	0x4(%r13), %eax
    9f1f:      	cmpq	$0x25, %rax
    9f23:      	ja	0x6bb0 <generic_lsm_filter_arg+0x2d0>
    9f29:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    9f33:      	btq	%rax, %rcx
    9f37:      	jae	0x6bb0 <generic_lsm_filter_arg+0x2d0>
    9f3d:      	xorl	%eax, %eax
    9f3f:      	testq	%rbx, %rbx
    9f42:      	sete	%al
    9f45:      	movq	%rax, %rbx
    9f48:      	jmp	0x6bb0 <generic_lsm_filter_arg+0x2d0>
    9f4d:      	xorl	%ebx, %ebx
    9f4f:      	movq	(%rsp), %rdi
    9f53:      	movq	0x8(%rsp), %r9
    9f58:      	movq	0x10(%rsp), %r11
    9f5d:      	movq	0x68(%rsp), %r15
    9f62:      	movl	0x4(%r13), %eax
    9f66:      	cmpq	$0x25, %rax
    9f6a:      	jbe	0x9b91 <generic_lsm_filter_arg+0x32b1>
    9f70:      	jmp	0x6bb0 <generic_lsm_filter_arg+0x2d0>
    9f75:      	movzbl	(%r12), %edx
    9f7a:      	jmp	0x9f81 <generic_lsm_filter_arg+0x36a1>
    9f7c:      	movzwl	(%r12), %edx
    9f81:      	cmpl	%edx, %ecx
    9f83:      	jb	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    9f89:      	jmp	0x9fa1 <generic_lsm_filter_arg+0x36c1>
    9f8b:      	cmpl	%edx, (%r12)
    9f8f:      	jb	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    9f95:      	jmp	0x9fa1 <generic_lsm_filter_arg+0x36c1>
    9f97:      	cmpl	%edx, (%r12)
    9f9b:      	ja	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    9fa1:      	orl	$0x2, %eax
    9fa4:      	cmpl	$0x6, %eax
    9fa7:      	je	0x6bc1 <generic_lsm_filter_arg+0x2e1>
    9fad:      	jmp	0x69fd <generic_lsm_filter_arg+0x11d>
    9fb2:      	nopw	%cs:(%rax,%rax)

0000000000009fc0 <generic_lsm_actions>:
    9fc0:      	pushq	%rbp
    9fc1:      	pushq	%r15
    9fc3:      	pushq	%r14
    9fc5:      	pushq	%r13
    9fc7:      	pushq	%r12
    9fc9:      	pushq	%rbx
    9fca:      	subq	$0xd8, %rsp
    9fd1:      	movq	%rdi, %r14
    9fd4:      	movl	$0x0, 0xb4(%rsp)
    9fdf:      	movq	(%rip), %rdi            # 0x9fe6 <generic_lsm_actions+0x26>
    9fe6:      	leaq	0xb4(%rsp), %rsi
    9fee:      	movl	$0x1, %eax
    9ff3:      	callq	*%rax
    9ff5:      	movq	%rax, %rsi
    9ff8:      	xorl	%eax, %eax
    9ffa:      	movq	%rax, 0xa8(%rsp)
    a002:      	testq	%rsi, %rsi
    a005:      	je	0xa0aa <generic_lsm_actions+0xea>
    a00b:      	movl	0x5f04(%rsi), %ebx
    a011:      	cmpl	$0x2, %ebx
    a014:      	jl	0xa0aa <generic_lsm_actions+0xea>
    a01a:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    a021:      	movq	(%rip), %rdi            # 0xa028 <generic_lsm_actions+0x68>
    a028:      	movl	$0x1, %eax
    a02d:      	callq	*%rax
    a02f:      	testq	%rax, %rax
    a032:      	je	0xa0aa <generic_lsm_actions+0xea>
    a034:      	movl	%ebx, %ecx
    a036:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    a03c:      	movq	%rax, %r15
    a03f:      	addl	(%rax,%rcx), %ebx
    a042:      	movl	$0x0, 0xb8(%rsp)
    a04d:      	movq	(%rip), %rdi            # 0xa054 <generic_lsm_actions+0x94>
    a054:      	leaq	0xb8(%rsp), %rsi
    a05c:      	movl	$0x1, %eax
    a061:      	andl	$0x7ff, %ebx            # imm = 0x7FF
    a067:      	callq	*%rax
    a069:      	testq	%rax, %rax
    a06c:      	movq	%r14, 0x98(%rsp)
    a074:      	je	0xa1f5 <generic_lsm_actions+0x235>
    a07a:      	xorl	%ecx, %ecx
    a07c:      	cmpb	$0x0, (%rax)
    a07f:      	sete	%cl
    a082:      	movq	%rcx, %rax
    a085:      	xorq	$0x9, %rax
    a089:      	movq	%rax, 0xc8(%rsp)
    a091:      	movq	%rcx, 0xa0(%rsp)
    a099:      	xorq	$0x7, %rcx
    a09d:      	movq	%rcx, 0xc0(%rsp)
    a0a5:      	jmp	0xa219 <generic_lsm_actions+0x259>
    a0aa:      	xorl	%ebx, %ebx
    a0ac:      	movl	$0x0, 0x30(%rsp)
    a0b4:      	movq	(%rip), %rdi            # 0xa0bb <generic_lsm_actions+0xfb>
    a0bb:      	leaq	0x30(%rsp), %rsi
    a0c0:      	movl	$0x1, %eax
    a0c5:      	callq	*%rax
    a0c7:      	testq	%rax, %rax
    a0ca:      	je	0xa1db <generic_lsm_actions+0x21b>
    a0d0:      	movzbl	0x1(%rax), %ecx
    a0d4:      	movb	%bl, 0x5f08(%rax)
    a0da:      	testq	%rbx, %rbx
    a0dd:      	je	0xa176 <generic_lsm_actions+0x1b6>
    a0e3:      	andb	$0x8, %cl
    a0e6:      	je	0xa176 <generic_lsm_actions+0x1b6>
    a0ec:      	movq	%rax, %rbx
    a0ef:      	movl	$0xe, %eax
    a0f4:      	callq	*%rax
    a0f6:      	movq	%rax, 0x18(%rsp)
    a0fb:      	movq	$0x0, 0x49(%rsp)
    a104:      	movq	$0x0, 0x51(%rsp)
    a10d:      	movq	$0x0, 0x59(%rsp)
    a116:      	movq	$0x0, 0x61(%rsp)
    a11f:      	movq	$0x0, 0x69(%rsp)
    a128:      	movq	$0x0, 0x71(%rsp)
    a131:      	movq	$0x0, 0x79(%rsp)
    a13a:      	movq	$0x0, 0x81(%rsp)
    a146:      	movb	$0x0, 0x89(%rsp)
    a14e:      	movb	$0x1, 0x48(%rsp)
    a153:      	movq	(%rip), %rdi            # 0xa15a <generic_lsm_actions+0x19a>
    a15a:      	xorl	%ecx, %ecx
    a15c:      	leaq	0x18(%rsp), %rsi
    a161:      	leaq	0x48(%rsp), %rdx
    a166:      	movl	$0x2, %eax
    a16b:      	xorl	%ecx, %ecx
    a16d:      	callq	*%rax
    a16f:      	movzbl	0x5f08(%rbx), %ebx
    a176:      	testb	%bl, %bl
    a178:      	jne	0xa1db <generic_lsm_actions+0x21b>
    a17a:      	movl	$0xe, %eax
    a17f:      	callq	*%rax
    a181:      	movq	%rax, 0x48(%rsp)
    a186:      	movq	(%rip), %rdi            # 0xa18d <generic_lsm_actions+0x1cd>
    a18d:      	leaq	0x48(%rsp), %rsi
    a192:      	movl	$0x1, %eax
    a197:      	callq	*%rax
    a199:      	testq	%rax, %rax
    a19c:      	je	0xa1d1 <generic_lsm_actions+0x211>
    a19e:      	movq	%rax, %rbx
    a1a1:      	movq	(%rip), %rdi            # 0xa1a8 <generic_lsm_actions+0x1e8>
    a1a8:      	leaq	0x48(%rsp), %rsi
    a1ad:      	movl	$0x3, %eax
    a1b2:      	callq	*%rax
    a1b4:      	movl	(%rbx), %eax
    a1b6:      	leal	-0x1(%rax), %ecx
    a1b9:      	cmpl	$0xfffff000, %ecx       # imm = 0xFFFFF000
    a1bf:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    a1c4:      	cmovael	%eax, %ecx
    a1c7:      	movq	%rcx, 0xa8(%rsp)
    a1cf:      	jmp	0xa1db <generic_lsm_actions+0x21b>
    a1d1:      	xorl	%eax, %eax
    a1d3:      	movq	%rax, 0xa8(%rsp)
    a1db:      	movq	0xa8(%rsp), %rax
    a1e3:      	addq	$0xd8, %rsp
    a1ea:      	popq	%rbx
    a1eb:      	popq	%r12
    a1ed:      	popq	%r13
    a1ef:      	popq	%r14
    a1f1:      	popq	%r15
    a1f3:      	popq	%rbp
    a1f4:      	retq
    a1f5:      	movl	$0x6, %eax
    a1fa:      	movq	%rax, 0xc0(%rsp)
    a202:      	movb	$0x1, %al
    a204:      	movq	%rax, 0xa0(%rsp)
    a20c:      	movl	$0x8, %eax
    a211:      	movq	%rax, 0xc8(%rsp)
    a219:      	movq	%r15, %rcx
    a21c:      	addq	%rbx, %rcx
    a21f:      	movb	$0x1, %al
    a221:      	movl	%eax, 0x40(%rsp)
    a225:      	leaq	0x48(%rsp), %rbp
    a22a:      	xorl	%r13d, %r13d
    a22d:      	xorl	%r12d, %r12d
    a230:      	movq	%rcx, 0x10(%rsp)
    a235:      	jmp	0xa255 <generic_lsm_actions+0x295>
    a237:      	nopw	(%rax,%rax)
    a240:      	movq	0x10(%rsp), %rcx
    a245:      	incl	%r13d
    a248:      	movl	%ebx, %r12d
    a24b:      	cmpl	$0x3, %r13d
    a24f:      	je	0xacee <generic_lsm_actions+0xd2e>
    a255:      	leal	0x4(,%r12,4), %eax
    a25d:      	cmpl	(%rcx), %eax
    a25f:      	jae	0xacee <generic_lsm_actions+0xd2e>
    a265:      	movl	%r12d, %eax
    a268:      	movslq	0x4(%rcx,%rax,4), %r14
    a26d:      	movl	$0x0, 0xbc(%rsp)
    a278:      	movl	$0x1, %eax
    a27d:      	movq	(%rip), %rdi            # 0xa284 <generic_lsm_actions+0x2c4>
    a284:      	leaq	0xbc(%rsp), %rsi
    a28c:      	callq	*%rax
    a28e:      	xorl	%ebx, %ebx
    a290:      	testq	%rax, %rax
    a293:      	je	0xa240 <generic_lsm_actions+0x280>
    a295:      	movq	%rax, %r15
    a298:      	cmpl	$0x7, %r14d
    a29c:      	jg	0xa2d0 <generic_lsm_actions+0x310>
    a29e:      	cmpl	$0x3, %r14d
    a2a2:      	movq	0x10(%rsp), %rcx
    a2a7:      	jg	0xa30d <generic_lsm_actions+0x34d>
    a2a9:      	cmpl	$0x1, %r14d
    a2ad:      	jg	0xa451 <generic_lsm_actions+0x491>
    a2b3:      	testl	%r14d, %r14d
    a2b6:      	je	0xa6fd <generic_lsm_actions+0x73d>
    a2bc:      	cmpl	$0x1, %r14d
    a2c0:      	je	0xa46a <generic_lsm_actions+0x4aa>
    a2c6:      	jmp	0xa9b1 <generic_lsm_actions+0x9f1>
    a2cb:      	nopl	(%rax,%rax)
    a2d0:      	cmpl	$0xb, %r14d
    a2d4:      	movq	0x10(%rsp), %rcx
    a2d9:      	jg	0xa422 <generic_lsm_actions+0x462>
    a2df:      	leal	-0xa(%r14), %eax
    a2e3:      	cmpl	$0x2, %eax
    a2e6:      	jb	0xa4e0 <generic_lsm_actions+0x520>
    a2ec:      	cmpl	$0x8, %r14d
    a2f0:      	je	0xa5d2 <generic_lsm_actions+0x612>
    a2f6:      	cmpl	$0x9, %r14d
    a2fa:      	jne	0xa9b1 <generic_lsm_actions+0x9f1>
    a300:      	incl	%r12d
    a303:      	movl	0x4(%rcx,%r12,4), %eax
    a308:      	jmp	0xa59a <generic_lsm_actions+0x5da>
    a30d:      	leal	-0x6(%r14), %eax
    a311:      	cmpl	$0x2, %eax
    a314:      	jb	0xa5c1 <generic_lsm_actions+0x601>
    a31a:      	cmpl	$0x4, %r14d
    a31e:      	je	0xa5df <generic_lsm_actions+0x61f>
    a324:      	cmpl	$0x5, %r14d
    a328:      	jne	0xa9b1 <generic_lsm_actions+0x9f1>
    a32e:      	leal	0x1(%r12), %eax
    a333:      	movl	0x4(%rcx,%rax,4), %eax
    a337:      	addl	$0x2, %r12d
    a33b:      	movl	0x4(%rcx,%r12,4), %ebx
    a340:      	movq	$0x0, 0x50(%rsp)
    a349:      	movq	$0x0, 0x48(%rsp)
    a352:      	andl	$0x7, %eax
    a355:      	cmpl	$0x4, %eax
    a358:      	ja	0xa9b1 <generic_lsm_actions+0x9f1>
    a35e:      	cmpl	$0x0, 0x5ea0(%r15,%rax,4)
    a367:      	jne	0xa9b1 <generic_lsm_actions+0x9f1>
    a36d:      	movq	0x5e78(%r15,%rax,8), %rax
    a375:      	andl	$0x7ff, %eax            # imm = 0x7FF
    a37a:      	movl	0x90(%r15,%rax), %eax
    a382:      	movl	%eax, 0x50(%rsp)
    a386:      	movl	$0xe, %eax
    a38b:      	callq	*%rax
    a38d:      	shrq	$0x20, %rax
    a391:      	movq	%rax, 0x48(%rsp)
    a396:      	movl	$0x1, %eax
    a39b:      	movq	(%rip), %rdi            # 0xa3a2 <generic_lsm_actions+0x3e2>
    a3a2:      	movq	%rbp, %rsi
    a3a5:      	callq	*%rax
    a3a7:      	movq	0x10(%rsp), %rcx
    a3ac:      	testq	%rax, %rax
    a3af:      	je	0xa9b1 <generic_lsm_actions+0x9f1>
    a3b5:      	andl	$0x7, %ebx
    a3b8:      	cmpl	$0x4, %ebx
    a3bb:      	ja	0xa9b1 <generic_lsm_actions+0x9f1>
    a3c1:      	cmpl	$0x0, 0x5ea0(%r15,%rbx,4)
    a3ca:      	jne	0xa9b1 <generic_lsm_actions+0x9f1>
    a3d0:      	movq	0x5e78(%r15,%rbx,8), %rcx
    a3d8:      	movl	$0x0, 0x54(%rsp)
    a3e0:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    a3e6:      	movl	0x90(%r15,%rcx), %ecx
    a3ee:      	movl	%ecx, 0x50(%rsp)
    a3f2:      	movq	%rax, %rbx
    a3f5:      	movl	$0xe, %eax
    a3fa:      	callq	*%rax
    a3fc:      	shrq	$0x20, %rax
    a400:      	movq	%rax, 0x48(%rsp)
    a405:      	movl	$0x2, %eax
    a40a:      	xorl	%ecx, %ecx
    a40c:      	movq	(%rip), %rdi            # 0xa413 <generic_lsm_actions+0x453>
    a413:      	movq	%rbp, %rsi
    a416:      	movq	%rbx, %rdx
    a419:      	xorl	%ecx, %ecx
    a41b:      	callq	*%rax
    a41d:      	jmp	0xa9ac <generic_lsm_actions+0x9ec>
    a422:      	cmpl	$0xc, %r14d
    a426:      	je	0xa7ad <generic_lsm_actions+0x7ed>
    a42c:      	cmpl	$0xd, %r14d
    a430:      	je	0xa675 <generic_lsm_actions+0x6b5>
    a436:      	cmpl	$0xe, %r14d
    a43a:      	jne	0xa9b1 <generic_lsm_actions+0x9f1>
    a440:      	addl	$0x2, %r12d
    a444:      	movq	0xc8(%rsp), %rbx
    a44c:      	jmp	0xa989 <generic_lsm_actions+0x9c9>
    a451:      	movl	$0x9, %eax
    a456:      	cmpl	$0x2, %r14d
    a45a:      	je	0xa59a <generic_lsm_actions+0x5da>
    a460:      	cmpl	$0x3, %r14d
    a464:      	jne	0xa9b1 <generic_lsm_actions+0x9f1>
    a46a:      	movq	%r15, 0x8(%rsp)
    a46f:      	leal	0x1(%r12), %eax
    a474:      	movl	0x4(%rcx,%rax,4), %r15d
    a479:      	addl	$0x2, %r12d
    a47d:      	movl	0x4(%rcx,%r12,4), %ebp
    a482:      	movq	$0x0, 0x50(%rsp)
    a48b:      	movq	$0x0, 0x48(%rsp)
    a494:      	movl	$0x0, 0x18(%rsp)
    a49c:      	movl	$0x1, %eax
    a4a1:      	leaq	0x18(%rsp), %rsi
    a4a6:      	movq	(%rip), %rdi            # 0xa4ad <generic_lsm_actions+0x4ed>
    a4ad:      	callq	*%rax
    a4af:      	xorl	%edx, %edx
    a4b1:      	testq	%rax, %rax
    a4b4:      	je	0xa4c4 <generic_lsm_actions+0x504>
    a4b6:      	andl	$0x7, %r15d
    a4ba:      	cmpl	$0x4, %r15d
    a4be:      	jbe	0xa7be <generic_lsm_actions+0x7fe>
    a4c4:      	movq	0x10(%rsp), %rcx
    a4c9:      	leaq	0x48(%rsp), %rbp
    a4ce:      	movq	0x8(%rsp), %r15
    a4d3:      	testl	%edx, %edx
    a4d5:      	jne	0xa245 <generic_lsm_actions+0x285>
    a4db:      	jmp	0xa9b1 <generic_lsm_actions+0x9f1>
    a4e0:      	incl	%r12d
    a4e3:      	movl	0x4(%rcx,%r12,4), %eax
    a4e8:      	andl	$0x7, %eax
    a4eb:      	xorl	%edx, %edx
    a4ed:      	cmpl	$0x4, %eax
    a4f0:      	ja	0xa9e3 <generic_lsm_actions+0xa23>
    a4f6:      	cmpl	$0x0, 0x5ea0(%r15,%rax,4)
    a4ff:      	jne	0xa9e3 <generic_lsm_actions+0xa23>
    a505:      	movq	0x5e78(%r15,%rax,8), %rax
    a50d:      	andl	$0x7ff, %eax            # imm = 0x7FF
    a512:      	movq	0xb8(%r15,%rax), %rax
    a51a:      	movq	%rax, 0x18(%rsp)
    a51f:      	testq	%rax, %rax
    a522:      	je	0xa9e3 <generic_lsm_actions+0xa23>
    a528:      	cmpl	$0xa, %r14d
    a52c:      	jne	0xa9ed <generic_lsm_actions+0xa2d>
    a532:      	movl	$0xe, %eax
    a537:      	callq	*%rax
    a539:      	movq	%rax, 0x8(%rsp)
    a53e:      	shrq	$0x20, %rax
    a542:      	movl	%eax, 0x48(%rsp)
    a546:      	movl	$0x1, %eax
    a54b:      	movq	(%rip), %rdi            # 0xa552 <generic_lsm_actions+0x592>
    a552:      	movq	%rbp, %rsi
    a555:      	callq	*%rax
    a557:      	xorl	%edx, %edx
    a559:      	testq	%rax, %rax
    a55c:      	movq	0x10(%rsp), %rcx
    a561:      	je	0xa9e3 <generic_lsm_actions+0xa23>
    a567:      	movl	(%rax), %ecx
    a569:      	movl	%ecx, 0x48(%rsp)
    a56d:      	movq	0x8(%rsp), %rcx
    a572:      	movl	%ecx, 0x4c(%rsp)
    a576:      	movq	0x8(%rax), %rax
    a57a:      	movq	%rax, 0x50(%rsp)
    a57f:      	xorl	%ecx, %ecx
    a581:      	movl	$0x2, %eax
    a586:      	leaq	0x18(%rsp), %rsi
    a58b:      	movq	(%rip), %rdi            # 0xa592 <generic_lsm_actions+0x5d2>
    a592:      	movq	%rbp, %rdx
    a595:      	jmp	0xa8b6 <generic_lsm_actions+0x8f6>
    a59a:      	movl	$0x3, %ebx
    a59f:      	cmpb	$0x0, 0xa0(%rsp)
    a5a7:      	je	0xa989 <generic_lsm_actions+0x9c9>
    a5ad:      	movslq	%eax, %rdi
    a5b0:      	movl	$0x6d, %eax
    a5b5:      	callq	*%rax
    a5b7:      	movl	$0x2, %ebx
    a5bc:      	jmp	0xa989 <generic_lsm_actions+0x9c9>
    a5c1:      	incl	%r12d
    a5c4:      	movl	0x4(%rcx,%r12,4), %eax
    a5c9:      	movl	%eax, 0x78(%r15)
    a5cd:      	jmp	0xa9b1 <generic_lsm_actions+0x9f1>
    a5d2:      	movl	$0x0, 0x40(%rsp)
    a5da:      	jmp	0xa9b1 <generic_lsm_actions+0x9f1>
    a5df:      	incl	%r12d
    a5e2:      	movl	$0x5, %ebx
    a5e7:      	cmpb	$0x0, 0xa0(%rsp)
    a5ef:      	je	0xa989 <generic_lsm_actions+0x9c9>
    a5f5:      	movq	%r15, 0x8(%rsp)
    a5fa:      	movl	%r12d, %eax
    a5fd:      	movl	0x4(%rcx,%rax,4), %eax
    a601:      	movl	%eax, 0x3c(%rsp)
    a605:      	movl	$0xe, %eax
    a60a:      	callq	*%rax
    a60c:      	movq	%rax, 0x18(%rsp)
    a611:      	movl	$0x1, %eax
    a616:      	leaq	0x18(%rsp), %r15
    a61b:      	movq	(%rip), %rbx            # 0xa622 <generic_lsm_actions+0x662>
    a622:      	movq	%rbx, %rdi
    a625:      	movq	%r15, %rsi
    a628:      	callq	*%rax
    a62a:      	testq	%rax, %rax
    a62d:      	je	0xa92c <generic_lsm_actions+0x96c>
    a633:      	movq	%rax, 0x28(%rsp)
    a638:      	movl	$0xe0011, 0x48(%rsp)    # imm = 0xE0011
    a640:      	movq	$0x35c, 0x4c(%rsp)      # imm = 0x35C
    a649:      	movl	$0x1, %eax
    a64e:      	leaq	0x48(%rsp), %r15
    a653:      	movq	(%rip), %rbx            # 0xa65a <generic_lsm_actions+0x69a>
    a65a:      	movq	%rbx, %rdi
    a65d:      	movq	%r15, %rsi
    a660:      	callq	*%rax
    a662:      	testq	%rax, %rax
    a665:      	je	0xa953 <generic_lsm_actions+0x993>
    a66b:      	movq	%r15, %rbp
    a66e:      	incl	(%rax)
    a670:      	jmp	0xa974 <generic_lsm_actions+0x9b4>
    a675:      	movl	$0xe, %eax
    a67a:      	callq	*%rax
    a67c:      	movq	%rax, 0x30(%rsp)
    a681:      	movl	$0x1, %eax
    a686:      	leaq	0x30(%rsp), %rsi
    a68b:      	movq	(%rip), %rdi            # 0xa692 <generic_lsm_actions+0x6d2>
    a692:      	callq	*%rax
    a694:      	testq	%rax, %rax
    a697:      	je	0xa9ac <generic_lsm_actions+0x9ec>
    a69d:      	movq	%r15, 0x8(%rsp)
    a6a2:      	movq	0x4(%rax), %rax
    a6a6:      	movq	%rax, 0x18(%rsp)
    a6ab:      	movl	$0x2, 0x20(%rsp)
    a6b3:      	movl	$0x1, %eax
    a6b8:      	leaq	0x18(%rsp), %rbx
    a6bd:      	movq	(%rip), %r15            # 0xa6c4 <generic_lsm_actions+0x704>
    a6c4:      	movq	%r15, %rdi
    a6c7:      	movq	%rbx, %rsi
    a6ca:      	callq	*%rax
    a6cc:      	movl	$0x1, 0x44(%rsp)
    a6d4:      	testq	%rax, %rax
    a6d7:      	je	0xa8c1 <generic_lsm_actions+0x901>
    a6dd:      	lock
    a6de:      	incl	(%rax)
    a6e0:      	movq	0x8(%rsp), %r15
    a6e5:      	movl	$0x3, %eax
    a6ea:      	leaq	0x30(%rsp), %rsi
    a6ef:      	movq	(%rip), %rdi            # 0xa6f6 <generic_lsm_actions+0x736>
    a6f6:      	callq	*%rax
    a6f8:      	jmp	0xa9ac <generic_lsm_actions+0x9ec>
    a6fd:      	leal	0x1(%r12), %eax
    a702:      	movl	0x4(%rcx,%rax,4), %ebx
    a706:      	leal	0x2(%r12), %eax
    a70b:      	movl	0x4(%rcx,%rax,4), %eax
    a70f:      	movl	%eax, 0x8(%rsp)
    a713:      	movl	$0x7d, %eax
    a718:      	callq	*%rax
    a71a:      	movq	%rax, 0x48(%rsp)
    a71f:      	movl	$0x0, 0x30(%rsp)
    a727:      	movq	%rbx, 0x90(%rsp)
    a72f:      	testq	%rbx, %rbx
    a732:      	je	0xac08 <generic_lsm_actions+0xc48>
    a738:      	movl	$0x1, %eax
    a73d:      	movq	(%rip), %rdi            # 0xa744 <generic_lsm_actions+0x784>
    a744:      	leaq	0x30(%rsp), %rsi
    a749:      	callq	*%rax
    a74b:      	testq	%rax, %rax
    a74e:      	je	0xac08 <generic_lsm_actions+0xc48>
    a754:      	movq	%rax, 0x28(%rsp)
    a759:      	movq	%rax, %rbx
    a75c:      	movl	$0x1, %eax
    a761:      	leaq	0x30(%rsp), %rsi
    a766:      	movq	(%rip), %rdi            # 0xa76d <generic_lsm_actions+0x7ad>
    a76d:      	callq	*%rax
    a76f:      	movq	%rax, %rdx
    a772:      	movq	0x60(%r15), %rax
    a776:      	movq	%rax, (%rbx)
    a779:      	movq	0x70(%r15), %rax
    a77d:      	movq	%rax, 0x8(%rbx)
    a781:      	movl	$0x0, %eax
    a786:      	movl	0x8(%rsp), %ecx
    a78a:      	cmpl	$0x2, %ecx
    a78d:      	je	0xaa16 <generic_lsm_actions+0xa56>
    a793:      	cmpl	$0x1, %ecx
    a796:      	je	0xaa12 <generic_lsm_actions+0xa52>
    a79c:      	testl	%ecx, %ecx
    a79e:      	jne	0xac08 <generic_lsm_actions+0xc48>
    a7a4:      	movl	0x7c(%r15), %eax
    a7a8:      	jmp	0xaa16 <generic_lsm_actions+0xa56>
    a7ad:      	addl	$0x3, %r12d
    a7b1:      	movq	0xc0(%rsp), %rbx
    a7b9:      	jmp	0xa989 <generic_lsm_actions+0x9c9>
    a7be:      	movq	0x8(%rsp), %rcx
    a7c3:      	cmpl	$0x0, 0x5ea0(%rcx,%r15,4)
    a7cc:      	je	0xa7eb <generic_lsm_actions+0x82b>
    a7ce:      	movq	0x10(%rsp), %rax
    a7d3:      	leaq	0x48(%rsp), %rbp
    a7d8:      	movq	%rcx, %r15
    a7db:      	movq	%rax, %rcx
    a7de:      	testl	%edx, %edx
    a7e0:      	jne	0xa245 <generic_lsm_actions+0x285>
    a7e6:      	jmp	0xa9b1 <generic_lsm_actions+0x9f1>
    a7eb:      	movq	%rbp, 0x28(%rsp)
    a7f0:      	movq	%rax, %rbp
    a7f3:      	movq	0x5e78(%rcx,%r15,8), %rax
    a7fb:      	movl	$0x0, 0x54(%rsp)
    a803:      	andl	$0x7ff, %eax            # imm = 0x7FF
    a808:      	movl	0x90(%rcx,%rax), %eax
    a80f:      	movl	%eax, 0x50(%rsp)
    a813:      	movl	$0xe, %eax
    a818:      	callq	*%rax
    a81a:      	shrq	$0x20, %rax
    a81e:      	movq	%rax, 0x48(%rsp)
    a823:      	cmpl	$0x1, %r14d
    a827:      	jne	0xa9c0 <generic_lsm_actions+0xa00>
    a82d:      	movq	%rbp, %rdi
    a830:      	movq	0x28(%rsp), %rax
    a835:      	andl	$0x7, %eax
    a838:      	cmpl	$0x4, %eax
    a83b:      	leaq	0x48(%rsp), %rbp
    a840:      	movl	$0x0, %edx
    a845:      	ja	0xa9d9 <generic_lsm_actions+0xa19>
    a84b:      	movq	0x8(%rsp), %r15
    a850:      	cmpl	$0x0, 0x5ea0(%r15,%rax,4)
    a859:      	movq	0x10(%rsp), %rcx
    a85e:      	jne	0xa9e3 <generic_lsm_actions+0xa23>
    a864:      	movq	0x5e78(%r15,%rax,8), %rax
    a86c:      	andl	$0x7ff, %eax            # imm = 0x7FF
    a871:      	leaq	(%r15,%rax), %rdx
    a875:      	addq	$0x90, %rdx
    a87c:      	movl	0x90(%r15,%rax), %esi
    a884:      	andl	$0xfff, %esi            # imm = 0xFFF
    a88a:      	addq	$0x8, %rsi
    a88e:      	movl	$0x4, %eax
    a893:      	movq	%rdi, 0x90(%rsp)
    a89b:      	callq	*%rax
    a89d:      	xorl	%ecx, %ecx
    a89f:      	movl	$0x2, %eax
    a8a4:      	movq	(%rip), %rdi            # 0xa8ab <generic_lsm_actions+0x8eb>
    a8ab:      	movq	%rbp, %rsi
    a8ae:      	movq	0x90(%rsp), %rdx
    a8b6:      	xorl	%ecx, %ecx
    a8b8:      	callq	*%rax
    a8ba:      	xorl	%edx, %edx
    a8bc:      	jmp	0xaa03 <generic_lsm_actions+0xa43>
    a8c1:      	movl	$0x2, %eax
    a8c6:      	movl	$0x1, %ecx
    a8cb:      	leaq	0x44(%rsp), %rdx
    a8d0:      	movq	%r15, %rdi
    a8d3:      	movq	%rbx, %rsi
    a8d6:      	callq	*%rax
    a8d8:      	testq	%rax, %rax
    a8db:      	movq	0x8(%rsp), %r15
    a8e0:      	je	0xa6e5 <generic_lsm_actions+0x725>
    a8e6:      	movq	%rax, 0x28(%rsp)
    a8eb:      	negl	%eax
    a8ed:      	movw	%ax, 0x48(%rsp)
    a8f2:      	movw	$0x3, 0x4a(%rsp)
    a8f9:      	movabsq	$0x20000003b, %rax      # imm = 0x20000003B
    a903:      	movq	%rax, 0x4c(%rsp)
    a908:      	movl	$0x1, %eax
    a90d:      	movq	(%rip), %rbx            # 0xa914 <generic_lsm_actions+0x954>
    a914:      	movq	%rbp, %rsi
    a917:      	movq	%rbx, %rdi
    a91a:      	callq	*%rax
    a91c:      	testq	%rax, %rax
    a91f:      	je	0xac9b <generic_lsm_actions+0xcdb>
    a925:      	incl	(%rax)
    a927:      	jmp	0xacbb <generic_lsm_actions+0xcfb>
    a92c:      	movl	$0x2, %eax
    a931:      	xorl	%ecx, %ecx
    a933:      	leaq	0x3c(%rsp), %rdx
    a938:      	movq	%rbx, %rdi
    a93b:      	movq	%r15, %rsi
    a93e:      	xorl	%ecx, %ecx
    a940:      	callq	*%rax
    a942:      	movl	$0x4, %ebx
    a947:      	leaq	0x48(%rsp), %rbp
    a94c:      	movq	0x8(%rsp), %r15
    a951:      	jmp	0xa989 <generic_lsm_actions+0x9c9>
    a953:      	movl	$0x1, 0x30(%rsp)
    a95b:      	movl	$0x2, %eax
    a960:      	xorl	%ecx, %ecx
    a962:      	leaq	0x30(%rsp), %rdx
    a967:      	movq	%rbx, %rdi
    a96a:      	movq	%r15, %rbp
    a96d:      	movq	%r15, %rsi
    a970:      	xorl	%ecx, %ecx
    a972:      	callq	*%rax
    a974:      	movq	0x8(%rsp), %r15
    a979:      	movl	0x3c(%rsp), %eax
    a97d:      	movq	0x28(%rsp), %rcx
    a982:      	movl	%eax, (%rcx)
    a984:      	movl	$0x4, %ebx
    a989:      	movl	$0x0, 0x48(%rsp)
    a991:      	movl	$0x1, %eax
    a996:      	movq	(%rip), %rdi            # 0xa99d <generic_lsm_actions+0x9dd>
    a99d:      	movq	%rbp, %rsi
    a9a0:      	callq	*%rax
    a9a2:      	testq	%rax, %rax
    a9a5:      	je	0xa9ac <generic_lsm_actions+0x9ec>
    a9a7:      	lock
    a9a8:      	incq	(%rax,%rbx,8)
    a9ac:      	movq	0x10(%rsp), %rcx
    a9b1:      	movq	%r14, 0x70(%r15)
    a9b5:      	incl	%r12d
    a9b8:      	movl	%r12d, %ebx
    a9bb:      	jmp	0xa245 <generic_lsm_actions+0x285>
    a9c0:      	movl	$0x3, %eax
    a9c5:      	leaq	0x48(%rsp), %rsi
    a9ca:      	movq	(%rip), %rdi            # 0xa9d1 <generic_lsm_actions+0xa11>
    a9d1:      	movq	%rsi, %rbp
    a9d4:      	callq	*%rax
    a9d6:      	movq	%rax, %rdx
    a9d9:      	movq	0x10(%rsp), %rcx
    a9de:      	movq	0x8(%rsp), %r15
    a9e3:      	testl	%edx, %edx
    a9e5:      	jne	0xa245 <generic_lsm_actions+0x285>
    a9eb:      	jmp	0xa9b1 <generic_lsm_actions+0x9f1>
    a9ed:      	movl	$0x3, %eax
    a9f2:      	leaq	0x18(%rsp), %rsi
    a9f7:      	movq	(%rip), %rdi            # 0xa9fe <generic_lsm_actions+0xa3e>
    a9fe:      	callq	*%rax
    aa00:      	movq	%rax, %rdx
    aa03:      	movq	0x10(%rsp), %rcx
    aa08:      	testl	%edx, %edx
    aa0a:      	jne	0xa245 <generic_lsm_actions+0x285>
    aa10:      	jmp	0xa9b1 <generic_lsm_actions+0x9f1>
    aa12:      	movl	0x10(%r15), %eax
    aa16:      	movq	%r15, 0x8(%rsp)
    aa1b:      	movl	%eax, %eax
    aa1d:      	movq	%rbx, 0xd0(%rsp)
    aa25:      	movq	%rax, 0x10(%rbx)
    aa29:      	movq	0x28(%rsp), %rdi
    aa2e:      	addq	$0x18, %rdi
    aa32:      	movl	$0x4, %eax
    aa37:      	movl	$0xc8, %ecx
    aa3c:      	movq	%rdi, 0x28(%rsp)
    aa41:      	movl	$0xc8, %esi
    aa46:      	callq	*%rax
    aa48:      	xorl	%r15d, %r15d
    aa4b:      	leaq	0x18(%rsp), %rbx
    aa50:      	xorl	%ebp, %ebp
    aa52:      	jmp	0xaa73 <generic_lsm_actions+0xab3>
    aa54:      	nopw	%cs:(%rax,%rax)
    aa60:      	leaq	0x18(%rsp), %rbx
    aa65:      	addq	$0x4, %r15
    aa69:      	cmpq	$0x14, %r15
    aa6d:      	je	0xaba3 <generic_lsm_actions+0xbe3>
    aa73:      	movl	$0x0, 0x18(%rsp)
    aa7b:      	movl	$0x1, %eax
    aa80:      	movq	(%rip), %rdi            # 0xaa87 <generic_lsm_actions+0xac7>
    aa87:      	movq	%rbx, %rsi
    aa8a:      	callq	*%rax
    aa8c:      	testq	%rax, %rax
    aa8f:      	je	0xaba3 <generic_lsm_actions+0xbe3>
    aa95:      	movq	%rax, %rsi
    aa98:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    aa9f:      	movl	$0x1, %eax
    aaa4:      	movq	(%rip), %rdi            # 0xaaab <generic_lsm_actions+0xaeb>
    aaab:      	callq	*%rax
    aaad:      	testq	%rax, %rax
    aab0:      	je	0xaba3 <generic_lsm_actions+0xbe3>
    aab6:      	cmpl	$-0x1, 0x40(%rax,%r15)
    aabc:      	je	0xaba3 <generic_lsm_actions+0xbe3>
    aac2:      	movq	0x8(%rsp), %rcx
    aac7:      	movq	0x5e78(%rcx,%r15,2), %rax
    aacf:      	movl	0x4(%rcx), %ecx
    aad2:      	cmpq	%rcx, %rax
    aad5:      	jge	0xaba3 <generic_lsm_actions+0xbe3>
    aadb:      	cmpq	$0x10, %r15
    aadf:      	je	0xab4a <generic_lsm_actions+0xb8a>
    aae1:      	movl	$0x0, 0x18(%rsp)
    aae9:      	movl	$0x1, %eax
    aaee:      	movq	(%rip), %rdi            # 0xaaf5 <generic_lsm_actions+0xb35>
    aaf5:      	movq	%rbx, %rsi
    aaf8:      	callq	*%rax
    aafa:      	testq	%rax, %rax
    aafd:      	je	0xab3d <generic_lsm_actions+0xb7d>
    aaff:      	movq	%rax, %rsi
    ab02:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    ab09:      	movl	$0x1, %eax
    ab0e:      	movq	(%rip), %rdi            # 0xab15 <generic_lsm_actions+0xb55>
    ab15:      	callq	*%rax
    ab17:      	testq	%rax, %rax
    ab1a:      	je	0xab3d <generic_lsm_actions+0xb7d>
    ab1c:      	cmpl	$-0x1, 0x44(%rax,%r15)
    ab22:      	movq	0x8(%rsp), %rcx
    ab27:      	movq	0x5e78(%rcx,%r15,2), %rax
    ab2f:      	je	0xab4a <generic_lsm_actions+0xb8a>
    ab31:      	movl	0x5e80(%rcx,%r15,2), %ebx
    ab39:      	subl	%eax, %ebx
    ab3b:      	jmp	0xab57 <generic_lsm_actions+0xb97>
    ab3d:      	movq	0x8(%rsp), %rax
    ab42:      	movq	0x5e78(%rax,%r15,2), %rax
    ab4a:      	movq	0x8(%rsp), %rcx
    ab4f:      	movl	0x4(%rcx), %ebx
    ab52:      	subl	%eax, %ebx
    ab54:      	addl	$0x4, %ebx
    ab57:      	testl	%ebx, %ebx
    ab59:      	jle	0xaa60 <generic_lsm_actions+0xaa0>
    ab5f:      	addl	$0x3ffc, %eax           # imm = 0x3FFC
    ab64:      	andl	$0x3fff, %eax           # imm = 0x3FFF
    ab69:      	cmpl	$0x28, %ebx
    ab6c:      	movl	$0x28, %ecx
    ab71:      	cmovgel	%ecx, %ebx
    ab74:      	movzbl	%bpl, %ebp
    ab78:      	movq	0x28(%rsp), %rcx
    ab7d:      	leaq	(%rcx,%rbp), %rdi
    ab81:      	movq	0x8(%rsp), %rcx
    ab86:      	leaq	(%rcx,%rax), %rdx
    ab8a:      	addq	$0x90, %rdx
    ab91:      	movl	$0x4, %eax
    ab96:      	movl	%ebx, %esi
    ab98:      	callq	*%rax
    ab9a:      	addl	%ebp, %ebx
    ab9c:      	movl	%ebx, %ebp
    ab9e:      	jmp	0xaa60 <generic_lsm_actions+0xaa0>
    aba3:      	movl	$0x1, %eax
    aba8:      	movq	(%rip), %rdi            # 0xabaf <generic_lsm_actions+0xbef>
    abaf:      	movq	0xd0(%rsp), %rbx
    abb7:      	movq	%rbx, %rsi
    abba:      	callq	*%rax
    abbc:      	testq	%rax, %rax
    abbf:      	je	0xabe6 <generic_lsm_actions+0xc26>
    abc1:      	imulq	$-0xf4240, 0x90(%rsp), %rcx # imm = 0xFFF0BDC0
    abcd:      	addq	0x48(%rsp), %rcx
    abd2:      	cmpq	%rcx, (%rax)
    abd5:      	jbe	0xabe6 <generic_lsm_actions+0xc26>
    abd7:      	movl	$0x0, 0x40(%rsp)
    abdf:      	leaq	0x48(%rsp), %rbp
    abe4:      	jmp	0xac03 <generic_lsm_actions+0xc43>
    abe6:      	movl	$0x2, %eax
    abeb:      	xorl	%ecx, %ecx
    abed:      	movq	(%rip), %rdi            # 0xabf4 <generic_lsm_actions+0xc34>
    abf4:      	leaq	0x48(%rsp), %rdx
    abf9:      	movq	%rbx, %rsi
    abfc:      	movq	%rdx, %rbp
    abff:      	xorl	%ecx, %ecx
    ac01:      	callq	*%rax
    ac03:      	movq	0x8(%rsp), %r15
    ac08:      	leal	0x3(%r12), %eax
    ac0d:      	movq	0x10(%rsp), %rcx
    ac12:      	cmpl	$0x0, 0x4(%rcx,%rax,4)
    ac17:      	je	0xac44 <generic_lsm_actions+0xc84>
    ac19:      	orb	$0x2, 0x1(%r15)
    ac1e:      	movl	$0x1b, %eax
    ac23:      	xorl	%ecx, %ecx
    ac25:      	movq	(%rip), %rsi            # 0xac2c <generic_lsm_actions+0xc6c>
    ac2c:      	movq	0x98(%rsp), %rdi
    ac34:      	xorl	%edx, %edx
    ac36:      	callq	*%rax
    ac38:      	movq	0x10(%rsp), %rcx
    ac3d:      	movq	%rax, 0x80(%r15)
    ac44:      	leal	0x4(%r12), %eax
    ac49:      	cmpl	$0x0, 0x4(%rcx,%rax,4)
    ac4e:      	je	0xac81 <generic_lsm_actions+0xcc1>
    ac50:      	orb	$0x4, 0x1(%r15)
    ac55:      	movl	$0x1b, %eax
    ac5a:      	movq	(%rip), %rsi            # 0xac61 <generic_lsm_actions+0xca1>
    ac61:      	movl	$0x100, %ecx            # imm = 0x100
    ac66:      	movq	0x98(%rsp), %rdi
    ac6e:      	movl	$0x100, %edx            # imm = 0x100
    ac73:      	callq	*%rax
    ac75:      	movq	0x10(%rsp), %rcx
    ac7a:      	movq	%rax, 0x88(%r15)
    ac81:      	addl	$0x5, %r12d
    ac85:      	cmpl	$0x0, 0x4(%rcx,%r12,4)
    ac8b:      	je	0xa9b1 <generic_lsm_actions+0x9f1>
    ac91:      	orb	$0x8, 0x1(%r15)
    ac96:      	jmp	0xa9b1 <generic_lsm_actions+0x9f1>
    ac9b:      	movl	$0x1, 0x3c(%rsp)
    aca3:      	movl	$0x2, %eax
    aca8:      	xorl	%ecx, %ecx
    acaa:      	leaq	0x3c(%rsp), %rdx
    acaf:      	leaq	0x48(%rsp), %rsi
    acb4:      	movq	%rbx, %rdi
    acb7:      	xorl	%ecx, %ecx
    acb9:      	callq	*%rax
    acbb:      	cmpl	$0x0, 0x28(%rsp)
    acc0:      	je	0xa6e5 <generic_lsm_actions+0x725>
    acc6:      	movl	$0x1, %eax
    accb:      	leaq	0x18(%rsp), %rsi
    acd0:      	movq	(%rip), %rdi            # 0xacd7 <generic_lsm_actions+0xd17>
    acd7:      	callq	*%rax
    acd9:      	testq	%rax, %rax
    acdc:      	je	0xa6e5 <generic_lsm_actions+0x725>
    ace2:      	movl	0x44(%rsp), %ecx
    ace6:      	lock
    ace7:      	addl	%ecx, (%rax)
    ace9:      	jmp	0xa6e5 <generic_lsm_actions+0x725>
    acee:      	movl	0x40(%rsp), %ebp
    acf2:      	testb	%bpl, %bpl
    acf5:      	je	0xad17 <generic_lsm_actions+0xd57>
    acf7:      	movq	(%rip), %rsi            # 0xacfe <generic_lsm_actions+0xd3e>
    acfe:      	movl	$0x5, %ecx
    ad03:      	movl	$0xc, %eax
    ad08:      	movq	0x98(%rsp), %rdi
    ad10:      	movl	$0x5, %edx
    ad15:      	callq	*%rax
    ad17:      	xorl	%ebx, %ebx
    ad19:      	testb	%bpl, %bpl
    ad1c:      	setne	%bl
    ad1f:      	jmp	0xa0ac <generic_lsm_actions+0xec>
    ad24:      	nopw	%cs:(%rax,%rax)

000000000000ad30 <generic_lsm_path>:
    ad30:      	pushq	%rbp
    ad31:      	pushq	%r15
    ad33:      	pushq	%r14
    ad35:      	pushq	%r13
    ad37:      	pushq	%r12
    ad39:      	pushq	%rbx
    ad3a:      	subq	$0x88, %rsp
    ad41:      	movq	%rdi, %rbp
    ad44:      	movl	$0x0, 0x70(%rsp)
    ad4c:      	movq	(%rip), %rdi            # 0xad53 <generic_lsm_path+0x23>
    ad53:      	leaq	0x70(%rsp), %rsi
    ad58:      	movl	$0x1, %eax
    ad5d:      	callq	*%rax
    ad5f:      	testq	%rax, %rax
    ad62:      	je	0x16ba9 <generic_lsm_path+0xbe79>
    ad68:      	movq	%rax, %r14
    ad6b:      	movl	0x6420(%rax), %eax
    ad71:      	cmpl	$0x1, %eax
    ad74:      	je	0xae16 <generic_lsm_path+0xe6>
    ad7a:      	testl	%eax, %eax
    ad7c:      	jne	0x16ba9 <generic_lsm_path+0xbe79>
    ad82:      	movq	0x6440(%r14), %r12
    ad89:      	movl	$0x0, 0x10(%rsp)
    ad91:      	movq	(%rip), %rdi            # 0xad98 <generic_lsm_path+0x68>
    ad98:      	leaq	0x10(%rsp), %rsi
    ad9d:      	movl	$0x1, %eax
    ada2:      	callq	*%rax
    ada4:      	testq	%rax, %rax
    ada7:      	je	0x16ba9 <generic_lsm_path+0xbe79>
    adad:      	movq	%rax, %r15
    adb0:      	addq	$0x8, %r12
    adb4:      	leaq	0x58(%rsp), %rdi
    adb9:      	movl	$0x8, %ecx
    adbe:      	movl	$0x4, %eax
    adc3:      	movl	$0x8, %esi
    adc8:      	movq	%r12, %rdx
    adcb:      	callq	*%rax
    adcd:      	testq	%rax, %rax
    add0:      	je	0x16859 <generic_lsm_path+0xbb29>
    add6:      	negl	%eax
    add8:      	movw	%ax, 0x18(%rsp)
    addd:      	movw	$0x6, 0x1a(%rsp)
    ade4:      	movabsq	$0x40000002c, %rax      # imm = 0x40000002C
    adee:      	movq	%rax, 0x1c(%rsp)
    adf3:      	movq	(%rip), %rdi            # 0xadfa <generic_lsm_path+0xca>
    adfa:      	leaq	0x18(%rsp), %rsi
    adff:      	movl	$0x1, %eax
    ae04:      	callq	*%rax
    ae06:      	testq	%rax, %rax
    ae09:      	je	0x16838 <generic_lsm_path+0xbb08>
    ae0f:      	incl	(%rax)
    ae11:      	jmp	0x16859 <generic_lsm_path+0xbb29>
    ae16:      	movq	0x6448(%r14), %rax
    ae1d:      	movq	%rax, 0x18(%rsp)
    ae22:      	movq	0x6450(%r14), %rax
    ae29:      	movq	%rax, 0x20(%rsp)
    ae2e:      	movq	$0x0, 0x28(%rsp)
    ae37:      	movq	0x6458(%r14), %rax
    ae3e:      	movq	%rax, 0x30(%rsp)
    ae43:      	movq	0x6460(%r14), %rax
    ae4a:      	movq	%rax, 0x38(%rsp)
    ae4f:      	movq	0x6468(%r14), %rax
    ae56:      	movq	%rax, 0x40(%rsp)
    ae5b:      	movq	$0x0, 0x48(%rsp)
    ae64:      	movl	$0x0, 0x50(%rsp)
    ae6c:      	movb	$0x0, 0x54(%rsp)
    ae71:      	movl	$0x0, 0x74(%rsp)
    ae79:      	movq	(%rip), %rdi            # 0xae80 <generic_lsm_path+0x150>
    ae80:      	leaq	0x74(%rsp), %rsi
    ae85:      	movl	$0x1, %eax
    ae8a:      	callq	*%rax
    ae8c:      	testq	%rax, %rax
    ae8f:      	je	0x16ba9 <generic_lsm_path+0xbe79>
    ae95:      	movq	%rbp, 0x78(%rsp)
    ae9a:      	movq	%rax, 0x28(%rsp)
    ae9f:      	movl	0x6424(%r14), %edx
    aea6:      	movl	%edx, %ecx
    aea8:      	andl	$0xfff, %ecx            # imm = 0xFFF
    aeae:      	movq	%rax, %rsi
    aeb1:      	movq	%rax, 0x80(%rsp)
    aeb9:      	addq	%rax, %rcx
    aebc:      	movq	%rcx, 0x48(%rsp)
    aec1:      	movl	%edx, 0x50(%rsp)
    aec5:      	movl	$0x200, %eax            # imm = 0x200
    aeca:      	movl	$0x8, %r13d
    aed0:      	movq	%rsp, %rbp
    aed3:      	movl	%eax, 0x6c(%rsp)
    aed7:      	movq	0x30(%rsp), %r12
    aedc:      	movq	0x38(%rsp), %rdx
    aee1:      	movq	0x40(%rsp), %r15
    aee6:      	cmpq	0x18(%rsp), %r12
    aeeb:      	jne	0xaef8 <generic_lsm_path+0x1c8>
    aeed:      	cmpq	0x20(%rsp), %rdx
    aef2:      	je	0x1679d <generic_lsm_path+0xba6d>
    aef8:      	movl	$0x4, %eax
    aefd:      	leaq	0x10(%rsp), %rdi
    af02:      	movl	$0x8, %esi
    af07:      	callq	*%rax
    af09:      	cmpq	0x10(%rsp), %r12
    af0e:      	je	0xb00d <generic_lsm_path+0x2dd>
    af14:      	leaq	0x18(%r12), %rbx
    af19:      	movl	$0x4, %eax
    af1e:      	movq	%rbp, %rdi
    af21:      	movl	$0x8, %esi
    af26:      	movq	%rbx, %rdx
    af29:      	callq	*%rax
    af2b:      	cmpq	%r12, (%rsp)
    af2f:      	je	0xb00d <generic_lsm_path+0x2dd>
    af35:      	movl	$0x4, %eax
    af3a:      	leaq	0x8(%rsp), %rdi
    af3f:      	movl	$0x8, %esi
    af44:      	movq	%rbx, %rdx
    af47:      	callq	*%rax
    af49:      	addq	$0x20, %r12
    af4d:      	movl	$0x4, %eax
    af52:      	leaq	0x58(%rsp), %rdi
    af57:      	movl	$0x10, %ecx
    af5c:      	movl	$0x10, %esi
    af61:      	movq	%r12, %rdx
    af64:      	callq	*%rax
    af66:      	movq	0x28(%rsp), %rbx
    af6b:      	movq	0x48(%rsp), %rax
    af70:      	movl	0x5c(%rsp), %r15d
    af75:      	subq	%rbx, %rax
    af78:      	movl	0x50(%rsp), %r12d
    af7d:      	movl	%r15d, %edx
    af80:      	subl	%r12d, %edx
    af83:      	movl	$0x0, %ecx
    af88:      	cmovbl	%ecx, %edx
    af8b:      	addq	0x60(%rsp), %rdx
    af90:      	xorl	%esi, %esi
    af92:      	cmpl	%r15d, %r12d
    af95:      	seta	%sil
    af99:      	movl	%r15d, %ecx
    af9c:      	cmovbl	%r12d, %ecx
    afa0:      	addl	%ecx, %esi
    afa2:      	movl	%r12d, %edi
    afa5:      	subl	%esi, %edi
    afa7:      	movl	%edi, 0x50(%rsp)
    afab:      	subq	%rsi, %rax
    afae:      	jb	0x167a2 <generic_lsm_path+0xba72>
    afb4:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    afba:      	ja	0x167a2 <generic_lsm_path+0xba72>
    afc0:      	cmpl	%r15d, %r12d
    afc3:      	jbe	0xafc9 <generic_lsm_path+0x299>
    afc5:      	movb	$0x2f, (%rbx,%rax)
    afc9:      	xorl	%edi, %edi
    afcb:      	cmpl	%r15d, %r12d
    afce:      	seta	%dil
    afd2:      	movzbl	%cl, %esi
    afd5:      	addq	%rax, %rbx
    afd8:      	addq	%rbx, %rdi
    afdb:      	movl	$0x4, %eax
    afe0:      	callq	*%rax
    afe2:      	movq	%rbx, 0x48(%rsp)
    afe7:      	cmpl	%r15d, %r12d
    afea:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    aff0:      	movq	0x8(%rsp), %r12
    aff5:      	movq	%r12, 0x30(%rsp)
    affa:      	movq	0x38(%rsp), %rdx
    afff:      	movq	0x40(%rsp), %r15
    b004:      	cmpq	0x18(%rsp), %r12
    b009:      	je	0xb065 <generic_lsm_path+0x335>
    b00b:      	jmp	0xb070 <generic_lsm_path+0x340>
    b00d:      	leaq	0x10(%r15), %rdx
    b011:      	movl	$0x4, %eax
    b016:      	movq	%rbp, %rdi
    b019:      	movl	$0x8, %esi
    b01e:      	callq	*%rax
    b020:      	movq	0x40(%rsp), %rax
    b025:      	cmpq	(%rsp), %rax
    b029:      	je	0x1679d <generic_lsm_path+0xba6d>
    b02f:      	addq	$0x18, %r15
    b033:      	movl	$0x4, %eax
    b038:      	leaq	0x30(%rsp), %rdi
    b03d:      	movl	$0x8, %esi
    b042:      	movq	%r15, %rdx
    b045:      	callq	*%rax
    b047:      	movq	(%rsp), %r15
    b04b:      	movq	%r15, 0x40(%rsp)
    b050:      	leaq	0x20(%r15), %rdx
    b054:      	movq	%rdx, 0x38(%rsp)
    b059:      	movq	0x30(%rsp), %r12
    b05e:      	cmpq	0x18(%rsp), %r12
    b063:      	jne	0xb070 <generic_lsm_path+0x340>
    b065:      	cmpq	0x20(%rsp), %rdx
    b06a:      	je	0x1679d <generic_lsm_path+0xba6d>
    b070:      	movl	$0x4, %eax
    b075:      	leaq	0x10(%rsp), %rdi
    b07a:      	movl	$0x8, %esi
    b07f:      	callq	*%rax
    b081:      	cmpq	0x10(%rsp), %r12
    b086:      	je	0xb185 <generic_lsm_path+0x455>
    b08c:      	leaq	0x18(%r12), %rbx
    b091:      	movl	$0x4, %eax
    b096:      	movq	%rbp, %rdi
    b099:      	movl	$0x8, %esi
    b09e:      	movq	%rbx, %rdx
    b0a1:      	callq	*%rax
    b0a3:      	cmpq	%r12, (%rsp)
    b0a7:      	je	0xb185 <generic_lsm_path+0x455>
    b0ad:      	movl	$0x4, %eax
    b0b2:      	leaq	0x8(%rsp), %rdi
    b0b7:      	movl	$0x8, %esi
    b0bc:      	movq	%rbx, %rdx
    b0bf:      	callq	*%rax
    b0c1:      	addq	$0x20, %r12
    b0c5:      	movl	$0x4, %eax
    b0ca:      	leaq	0x58(%rsp), %rdi
    b0cf:      	movl	$0x10, %ecx
    b0d4:      	movl	$0x10, %esi
    b0d9:      	movq	%r12, %rdx
    b0dc:      	callq	*%rax
    b0de:      	movq	0x28(%rsp), %rbx
    b0e3:      	movq	0x48(%rsp), %rax
    b0e8:      	movl	0x5c(%rsp), %r15d
    b0ed:      	subq	%rbx, %rax
    b0f0:      	movl	0x50(%rsp), %r12d
    b0f5:      	movl	%r15d, %edx
    b0f8:      	subl	%r12d, %edx
    b0fb:      	movl	$0x0, %ecx
    b100:      	cmovbl	%ecx, %edx
    b103:      	addq	0x60(%rsp), %rdx
    b108:      	xorl	%esi, %esi
    b10a:      	cmpl	%r15d, %r12d
    b10d:      	seta	%sil
    b111:      	movl	%r15d, %ecx
    b114:      	cmovbl	%r12d, %ecx
    b118:      	addl	%ecx, %esi
    b11a:      	movl	%r12d, %edi
    b11d:      	subl	%esi, %edi
    b11f:      	movl	%edi, 0x50(%rsp)
    b123:      	subq	%rsi, %rax
    b126:      	jb	0x167a2 <generic_lsm_path+0xba72>
    b12c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b132:      	ja	0x167a2 <generic_lsm_path+0xba72>
    b138:      	cmpl	%r15d, %r12d
    b13b:      	jbe	0xb141 <generic_lsm_path+0x411>
    b13d:      	movb	$0x2f, (%rbx,%rax)
    b141:      	xorl	%edi, %edi
    b143:      	cmpl	%r15d, %r12d
    b146:      	seta	%dil
    b14a:      	movzbl	%cl, %esi
    b14d:      	addq	%rax, %rbx
    b150:      	addq	%rbx, %rdi
    b153:      	movl	$0x4, %eax
    b158:      	callq	*%rax
    b15a:      	movq	%rbx, 0x48(%rsp)
    b15f:      	cmpl	%r15d, %r12d
    b162:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    b168:      	movq	0x8(%rsp), %r12
    b16d:      	movq	%r12, 0x30(%rsp)
    b172:      	movq	0x38(%rsp), %rdx
    b177:      	movq	0x40(%rsp), %r15
    b17c:      	cmpq	0x18(%rsp), %r12
    b181:      	je	0xb1dd <generic_lsm_path+0x4ad>
    b183:      	jmp	0xb1e8 <generic_lsm_path+0x4b8>
    b185:      	leaq	0x10(%r15), %rdx
    b189:      	movl	$0x4, %eax
    b18e:      	movq	%rbp, %rdi
    b191:      	movl	$0x8, %esi
    b196:      	callq	*%rax
    b198:      	movq	0x40(%rsp), %rax
    b19d:      	cmpq	(%rsp), %rax
    b1a1:      	je	0x1679d <generic_lsm_path+0xba6d>
    b1a7:      	addq	$0x18, %r15
    b1ab:      	movl	$0x4, %eax
    b1b0:      	leaq	0x30(%rsp), %rdi
    b1b5:      	movl	$0x8, %esi
    b1ba:      	movq	%r15, %rdx
    b1bd:      	callq	*%rax
    b1bf:      	movq	(%rsp), %r15
    b1c3:      	movq	%r15, 0x40(%rsp)
    b1c8:      	leaq	0x20(%r15), %rdx
    b1cc:      	movq	%rdx, 0x38(%rsp)
    b1d1:      	movq	0x30(%rsp), %r12
    b1d6:      	cmpq	0x18(%rsp), %r12
    b1db:      	jne	0xb1e8 <generic_lsm_path+0x4b8>
    b1dd:      	cmpq	0x20(%rsp), %rdx
    b1e2:      	je	0x1679d <generic_lsm_path+0xba6d>
    b1e8:      	movl	$0x4, %eax
    b1ed:      	leaq	0x10(%rsp), %rdi
    b1f2:      	movl	$0x8, %esi
    b1f7:      	callq	*%rax
    b1f9:      	cmpq	0x10(%rsp), %r12
    b1fe:      	je	0xb2fd <generic_lsm_path+0x5cd>
    b204:      	leaq	0x18(%r12), %rbx
    b209:      	movl	$0x4, %eax
    b20e:      	movq	%rbp, %rdi
    b211:      	movl	$0x8, %esi
    b216:      	movq	%rbx, %rdx
    b219:      	callq	*%rax
    b21b:      	cmpq	%r12, (%rsp)
    b21f:      	je	0xb2fd <generic_lsm_path+0x5cd>
    b225:      	movl	$0x4, %eax
    b22a:      	leaq	0x8(%rsp), %rdi
    b22f:      	movl	$0x8, %esi
    b234:      	movq	%rbx, %rdx
    b237:      	callq	*%rax
    b239:      	addq	$0x20, %r12
    b23d:      	movl	$0x4, %eax
    b242:      	leaq	0x58(%rsp), %rdi
    b247:      	movl	$0x10, %ecx
    b24c:      	movl	$0x10, %esi
    b251:      	movq	%r12, %rdx
    b254:      	callq	*%rax
    b256:      	movq	0x28(%rsp), %rbx
    b25b:      	movq	0x48(%rsp), %rax
    b260:      	movl	0x5c(%rsp), %r15d
    b265:      	subq	%rbx, %rax
    b268:      	movl	0x50(%rsp), %r12d
    b26d:      	movl	%r15d, %edx
    b270:      	subl	%r12d, %edx
    b273:      	movl	$0x0, %ecx
    b278:      	cmovbl	%ecx, %edx
    b27b:      	addq	0x60(%rsp), %rdx
    b280:      	xorl	%esi, %esi
    b282:      	cmpl	%r15d, %r12d
    b285:      	seta	%sil
    b289:      	movl	%r15d, %ecx
    b28c:      	cmovbl	%r12d, %ecx
    b290:      	addl	%ecx, %esi
    b292:      	movl	%r12d, %edi
    b295:      	subl	%esi, %edi
    b297:      	movl	%edi, 0x50(%rsp)
    b29b:      	subq	%rsi, %rax
    b29e:      	jb	0x167a2 <generic_lsm_path+0xba72>
    b2a4:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b2aa:      	ja	0x167a2 <generic_lsm_path+0xba72>
    b2b0:      	cmpl	%r15d, %r12d
    b2b3:      	jbe	0xb2b9 <generic_lsm_path+0x589>
    b2b5:      	movb	$0x2f, (%rbx,%rax)
    b2b9:      	xorl	%edi, %edi
    b2bb:      	cmpl	%r15d, %r12d
    b2be:      	seta	%dil
    b2c2:      	movzbl	%cl, %esi
    b2c5:      	addq	%rax, %rbx
    b2c8:      	addq	%rbx, %rdi
    b2cb:      	movl	$0x4, %eax
    b2d0:      	callq	*%rax
    b2d2:      	movq	%rbx, 0x48(%rsp)
    b2d7:      	cmpl	%r15d, %r12d
    b2da:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    b2e0:      	movq	0x8(%rsp), %r12
    b2e5:      	movq	%r12, 0x30(%rsp)
    b2ea:      	movq	0x38(%rsp), %rdx
    b2ef:      	movq	0x40(%rsp), %r15
    b2f4:      	cmpq	0x18(%rsp), %r12
    b2f9:      	je	0xb355 <generic_lsm_path+0x625>
    b2fb:      	jmp	0xb360 <generic_lsm_path+0x630>
    b2fd:      	leaq	0x10(%r15), %rdx
    b301:      	movl	$0x4, %eax
    b306:      	movq	%rbp, %rdi
    b309:      	movl	$0x8, %esi
    b30e:      	callq	*%rax
    b310:      	movq	0x40(%rsp), %rax
    b315:      	cmpq	(%rsp), %rax
    b319:      	je	0x1679d <generic_lsm_path+0xba6d>
    b31f:      	addq	$0x18, %r15
    b323:      	movl	$0x4, %eax
    b328:      	leaq	0x30(%rsp), %rdi
    b32d:      	movl	$0x8, %esi
    b332:      	movq	%r15, %rdx
    b335:      	callq	*%rax
    b337:      	movq	(%rsp), %r15
    b33b:      	movq	%r15, 0x40(%rsp)
    b340:      	leaq	0x20(%r15), %rdx
    b344:      	movq	%rdx, 0x38(%rsp)
    b349:      	movq	0x30(%rsp), %r12
    b34e:      	cmpq	0x18(%rsp), %r12
    b353:      	jne	0xb360 <generic_lsm_path+0x630>
    b355:      	cmpq	0x20(%rsp), %rdx
    b35a:      	je	0x1679d <generic_lsm_path+0xba6d>
    b360:      	movl	$0x4, %eax
    b365:      	leaq	0x10(%rsp), %rdi
    b36a:      	movl	$0x8, %esi
    b36f:      	callq	*%rax
    b371:      	cmpq	0x10(%rsp), %r12
    b376:      	je	0xb475 <generic_lsm_path+0x745>
    b37c:      	leaq	0x18(%r12), %rbx
    b381:      	movl	$0x4, %eax
    b386:      	movq	%rbp, %rdi
    b389:      	movl	$0x8, %esi
    b38e:      	movq	%rbx, %rdx
    b391:      	callq	*%rax
    b393:      	cmpq	%r12, (%rsp)
    b397:      	je	0xb475 <generic_lsm_path+0x745>
    b39d:      	movl	$0x4, %eax
    b3a2:      	leaq	0x8(%rsp), %rdi
    b3a7:      	movl	$0x8, %esi
    b3ac:      	movq	%rbx, %rdx
    b3af:      	callq	*%rax
    b3b1:      	addq	$0x20, %r12
    b3b5:      	movl	$0x4, %eax
    b3ba:      	leaq	0x58(%rsp), %rdi
    b3bf:      	movl	$0x10, %ecx
    b3c4:      	movl	$0x10, %esi
    b3c9:      	movq	%r12, %rdx
    b3cc:      	callq	*%rax
    b3ce:      	movq	0x28(%rsp), %rbx
    b3d3:      	movq	0x48(%rsp), %rax
    b3d8:      	movl	0x5c(%rsp), %r15d
    b3dd:      	subq	%rbx, %rax
    b3e0:      	movl	0x50(%rsp), %r12d
    b3e5:      	movl	%r15d, %edx
    b3e8:      	subl	%r12d, %edx
    b3eb:      	movl	$0x0, %ecx
    b3f0:      	cmovbl	%ecx, %edx
    b3f3:      	addq	0x60(%rsp), %rdx
    b3f8:      	xorl	%esi, %esi
    b3fa:      	cmpl	%r15d, %r12d
    b3fd:      	seta	%sil
    b401:      	movl	%r15d, %ecx
    b404:      	cmovbl	%r12d, %ecx
    b408:      	addl	%ecx, %esi
    b40a:      	movl	%r12d, %edi
    b40d:      	subl	%esi, %edi
    b40f:      	movl	%edi, 0x50(%rsp)
    b413:      	subq	%rsi, %rax
    b416:      	jb	0x167a2 <generic_lsm_path+0xba72>
    b41c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b422:      	ja	0x167a2 <generic_lsm_path+0xba72>
    b428:      	cmpl	%r15d, %r12d
    b42b:      	jbe	0xb431 <generic_lsm_path+0x701>
    b42d:      	movb	$0x2f, (%rbx,%rax)
    b431:      	xorl	%edi, %edi
    b433:      	cmpl	%r15d, %r12d
    b436:      	seta	%dil
    b43a:      	movzbl	%cl, %esi
    b43d:      	addq	%rax, %rbx
    b440:      	addq	%rbx, %rdi
    b443:      	movl	$0x4, %eax
    b448:      	callq	*%rax
    b44a:      	movq	%rbx, 0x48(%rsp)
    b44f:      	cmpl	%r15d, %r12d
    b452:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    b458:      	movq	0x8(%rsp), %r12
    b45d:      	movq	%r12, 0x30(%rsp)
    b462:      	movq	0x38(%rsp), %rdx
    b467:      	movq	0x40(%rsp), %r15
    b46c:      	cmpq	0x18(%rsp), %r12
    b471:      	je	0xb4cd <generic_lsm_path+0x79d>
    b473:      	jmp	0xb4d8 <generic_lsm_path+0x7a8>
    b475:      	leaq	0x10(%r15), %rdx
    b479:      	movl	$0x4, %eax
    b47e:      	movq	%rbp, %rdi
    b481:      	movl	$0x8, %esi
    b486:      	callq	*%rax
    b488:      	movq	0x40(%rsp), %rax
    b48d:      	cmpq	(%rsp), %rax
    b491:      	je	0x1679d <generic_lsm_path+0xba6d>
    b497:      	addq	$0x18, %r15
    b49b:      	movl	$0x4, %eax
    b4a0:      	leaq	0x30(%rsp), %rdi
    b4a5:      	movl	$0x8, %esi
    b4aa:      	movq	%r15, %rdx
    b4ad:      	callq	*%rax
    b4af:      	movq	(%rsp), %r15
    b4b3:      	movq	%r15, 0x40(%rsp)
    b4b8:      	leaq	0x20(%r15), %rdx
    b4bc:      	movq	%rdx, 0x38(%rsp)
    b4c1:      	movq	0x30(%rsp), %r12
    b4c6:      	cmpq	0x18(%rsp), %r12
    b4cb:      	jne	0xb4d8 <generic_lsm_path+0x7a8>
    b4cd:      	cmpq	0x20(%rsp), %rdx
    b4d2:      	je	0x1679d <generic_lsm_path+0xba6d>
    b4d8:      	movl	$0x4, %eax
    b4dd:      	leaq	0x10(%rsp), %rdi
    b4e2:      	movl	$0x8, %esi
    b4e7:      	callq	*%rax
    b4e9:      	cmpq	0x10(%rsp), %r12
    b4ee:      	je	0xb5ed <generic_lsm_path+0x8bd>
    b4f4:      	leaq	0x18(%r12), %rbx
    b4f9:      	movl	$0x4, %eax
    b4fe:      	movq	%rbp, %rdi
    b501:      	movl	$0x8, %esi
    b506:      	movq	%rbx, %rdx
    b509:      	callq	*%rax
    b50b:      	cmpq	%r12, (%rsp)
    b50f:      	je	0xb5ed <generic_lsm_path+0x8bd>
    b515:      	movl	$0x4, %eax
    b51a:      	leaq	0x8(%rsp), %rdi
    b51f:      	movl	$0x8, %esi
    b524:      	movq	%rbx, %rdx
    b527:      	callq	*%rax
    b529:      	addq	$0x20, %r12
    b52d:      	movl	$0x4, %eax
    b532:      	leaq	0x58(%rsp), %rdi
    b537:      	movl	$0x10, %ecx
    b53c:      	movl	$0x10, %esi
    b541:      	movq	%r12, %rdx
    b544:      	callq	*%rax
    b546:      	movq	0x28(%rsp), %rbx
    b54b:      	movq	0x48(%rsp), %rax
    b550:      	movl	0x5c(%rsp), %r15d
    b555:      	subq	%rbx, %rax
    b558:      	movl	0x50(%rsp), %r12d
    b55d:      	movl	%r15d, %edx
    b560:      	subl	%r12d, %edx
    b563:      	movl	$0x0, %ecx
    b568:      	cmovbl	%ecx, %edx
    b56b:      	addq	0x60(%rsp), %rdx
    b570:      	xorl	%esi, %esi
    b572:      	cmpl	%r15d, %r12d
    b575:      	seta	%sil
    b579:      	movl	%r15d, %ecx
    b57c:      	cmovbl	%r12d, %ecx
    b580:      	addl	%ecx, %esi
    b582:      	movl	%r12d, %edi
    b585:      	subl	%esi, %edi
    b587:      	movl	%edi, 0x50(%rsp)
    b58b:      	subq	%rsi, %rax
    b58e:      	jb	0x167a2 <generic_lsm_path+0xba72>
    b594:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b59a:      	ja	0x167a2 <generic_lsm_path+0xba72>
    b5a0:      	cmpl	%r15d, %r12d
    b5a3:      	jbe	0xb5a9 <generic_lsm_path+0x879>
    b5a5:      	movb	$0x2f, (%rbx,%rax)
    b5a9:      	xorl	%edi, %edi
    b5ab:      	cmpl	%r15d, %r12d
    b5ae:      	seta	%dil
    b5b2:      	movzbl	%cl, %esi
    b5b5:      	addq	%rax, %rbx
    b5b8:      	addq	%rbx, %rdi
    b5bb:      	movl	$0x4, %eax
    b5c0:      	callq	*%rax
    b5c2:      	movq	%rbx, 0x48(%rsp)
    b5c7:      	cmpl	%r15d, %r12d
    b5ca:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    b5d0:      	movq	0x8(%rsp), %r12
    b5d5:      	movq	%r12, 0x30(%rsp)
    b5da:      	movq	0x38(%rsp), %rdx
    b5df:      	movq	0x40(%rsp), %r15
    b5e4:      	cmpq	0x18(%rsp), %r12
    b5e9:      	je	0xb645 <generic_lsm_path+0x915>
    b5eb:      	jmp	0xb650 <generic_lsm_path+0x920>
    b5ed:      	leaq	0x10(%r15), %rdx
    b5f1:      	movl	$0x4, %eax
    b5f6:      	movq	%rbp, %rdi
    b5f9:      	movl	$0x8, %esi
    b5fe:      	callq	*%rax
    b600:      	movq	0x40(%rsp), %rax
    b605:      	cmpq	(%rsp), %rax
    b609:      	je	0x1679d <generic_lsm_path+0xba6d>
    b60f:      	addq	$0x18, %r15
    b613:      	movl	$0x4, %eax
    b618:      	leaq	0x30(%rsp), %rdi
    b61d:      	movl	$0x8, %esi
    b622:      	movq	%r15, %rdx
    b625:      	callq	*%rax
    b627:      	movq	(%rsp), %r15
    b62b:      	movq	%r15, 0x40(%rsp)
    b630:      	leaq	0x20(%r15), %rdx
    b634:      	movq	%rdx, 0x38(%rsp)
    b639:      	movq	0x30(%rsp), %r12
    b63e:      	cmpq	0x18(%rsp), %r12
    b643:      	jne	0xb650 <generic_lsm_path+0x920>
    b645:      	cmpq	0x20(%rsp), %rdx
    b64a:      	je	0x1679d <generic_lsm_path+0xba6d>
    b650:      	movl	$0x4, %eax
    b655:      	leaq	0x10(%rsp), %rdi
    b65a:      	movl	$0x8, %esi
    b65f:      	callq	*%rax
    b661:      	cmpq	0x10(%rsp), %r12
    b666:      	je	0xb765 <generic_lsm_path+0xa35>
    b66c:      	leaq	0x18(%r12), %rbx
    b671:      	movl	$0x4, %eax
    b676:      	movq	%rbp, %rdi
    b679:      	movl	$0x8, %esi
    b67e:      	movq	%rbx, %rdx
    b681:      	callq	*%rax
    b683:      	cmpq	%r12, (%rsp)
    b687:      	je	0xb765 <generic_lsm_path+0xa35>
    b68d:      	movl	$0x4, %eax
    b692:      	leaq	0x8(%rsp), %rdi
    b697:      	movl	$0x8, %esi
    b69c:      	movq	%rbx, %rdx
    b69f:      	callq	*%rax
    b6a1:      	addq	$0x20, %r12
    b6a5:      	movl	$0x4, %eax
    b6aa:      	leaq	0x58(%rsp), %rdi
    b6af:      	movl	$0x10, %ecx
    b6b4:      	movl	$0x10, %esi
    b6b9:      	movq	%r12, %rdx
    b6bc:      	callq	*%rax
    b6be:      	movq	0x28(%rsp), %rbx
    b6c3:      	movq	0x48(%rsp), %rax
    b6c8:      	movl	0x5c(%rsp), %r15d
    b6cd:      	subq	%rbx, %rax
    b6d0:      	movl	0x50(%rsp), %r12d
    b6d5:      	movl	%r15d, %edx
    b6d8:      	subl	%r12d, %edx
    b6db:      	movl	$0x0, %ecx
    b6e0:      	cmovbl	%ecx, %edx
    b6e3:      	addq	0x60(%rsp), %rdx
    b6e8:      	xorl	%esi, %esi
    b6ea:      	cmpl	%r15d, %r12d
    b6ed:      	seta	%sil
    b6f1:      	movl	%r15d, %ecx
    b6f4:      	cmovbl	%r12d, %ecx
    b6f8:      	addl	%ecx, %esi
    b6fa:      	movl	%r12d, %edi
    b6fd:      	subl	%esi, %edi
    b6ff:      	movl	%edi, 0x50(%rsp)
    b703:      	subq	%rsi, %rax
    b706:      	jb	0x167a2 <generic_lsm_path+0xba72>
    b70c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b712:      	ja	0x167a2 <generic_lsm_path+0xba72>
    b718:      	cmpl	%r15d, %r12d
    b71b:      	jbe	0xb721 <generic_lsm_path+0x9f1>
    b71d:      	movb	$0x2f, (%rbx,%rax)
    b721:      	xorl	%edi, %edi
    b723:      	cmpl	%r15d, %r12d
    b726:      	seta	%dil
    b72a:      	movzbl	%cl, %esi
    b72d:      	addq	%rax, %rbx
    b730:      	addq	%rbx, %rdi
    b733:      	movl	$0x4, %eax
    b738:      	callq	*%rax
    b73a:      	movq	%rbx, 0x48(%rsp)
    b73f:      	cmpl	%r15d, %r12d
    b742:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    b748:      	movq	0x8(%rsp), %r12
    b74d:      	movq	%r12, 0x30(%rsp)
    b752:      	movq	0x38(%rsp), %rdx
    b757:      	movq	0x40(%rsp), %r15
    b75c:      	cmpq	0x18(%rsp), %r12
    b761:      	je	0xb7bd <generic_lsm_path+0xa8d>
    b763:      	jmp	0xb7c8 <generic_lsm_path+0xa98>
    b765:      	leaq	0x10(%r15), %rdx
    b769:      	movl	$0x4, %eax
    b76e:      	movq	%rbp, %rdi
    b771:      	movl	$0x8, %esi
    b776:      	callq	*%rax
    b778:      	movq	0x40(%rsp), %rax
    b77d:      	cmpq	(%rsp), %rax
    b781:      	je	0x1679d <generic_lsm_path+0xba6d>
    b787:      	addq	$0x18, %r15
    b78b:      	movl	$0x4, %eax
    b790:      	leaq	0x30(%rsp), %rdi
    b795:      	movl	$0x8, %esi
    b79a:      	movq	%r15, %rdx
    b79d:      	callq	*%rax
    b79f:      	movq	(%rsp), %r15
    b7a3:      	movq	%r15, 0x40(%rsp)
    b7a8:      	leaq	0x20(%r15), %rdx
    b7ac:      	movq	%rdx, 0x38(%rsp)
    b7b1:      	movq	0x30(%rsp), %r12
    b7b6:      	cmpq	0x18(%rsp), %r12
    b7bb:      	jne	0xb7c8 <generic_lsm_path+0xa98>
    b7bd:      	cmpq	0x20(%rsp), %rdx
    b7c2:      	je	0x1679d <generic_lsm_path+0xba6d>
    b7c8:      	movl	$0x4, %eax
    b7cd:      	leaq	0x10(%rsp), %rdi
    b7d2:      	movl	$0x8, %esi
    b7d7:      	callq	*%rax
    b7d9:      	cmpq	0x10(%rsp), %r12
    b7de:      	je	0xb8dd <generic_lsm_path+0xbad>
    b7e4:      	leaq	0x18(%r12), %rbx
    b7e9:      	movl	$0x4, %eax
    b7ee:      	movq	%rbp, %rdi
    b7f1:      	movl	$0x8, %esi
    b7f6:      	movq	%rbx, %rdx
    b7f9:      	callq	*%rax
    b7fb:      	cmpq	%r12, (%rsp)
    b7ff:      	je	0xb8dd <generic_lsm_path+0xbad>
    b805:      	movl	$0x4, %eax
    b80a:      	leaq	0x8(%rsp), %rdi
    b80f:      	movl	$0x8, %esi
    b814:      	movq	%rbx, %rdx
    b817:      	callq	*%rax
    b819:      	addq	$0x20, %r12
    b81d:      	movl	$0x4, %eax
    b822:      	leaq	0x58(%rsp), %rdi
    b827:      	movl	$0x10, %ecx
    b82c:      	movl	$0x10, %esi
    b831:      	movq	%r12, %rdx
    b834:      	callq	*%rax
    b836:      	movq	0x28(%rsp), %rbx
    b83b:      	movq	0x48(%rsp), %rax
    b840:      	movl	0x5c(%rsp), %r15d
    b845:      	subq	%rbx, %rax
    b848:      	movl	0x50(%rsp), %r12d
    b84d:      	movl	%r15d, %edx
    b850:      	subl	%r12d, %edx
    b853:      	movl	$0x0, %ecx
    b858:      	cmovbl	%ecx, %edx
    b85b:      	addq	0x60(%rsp), %rdx
    b860:      	xorl	%esi, %esi
    b862:      	cmpl	%r15d, %r12d
    b865:      	seta	%sil
    b869:      	movl	%r15d, %ecx
    b86c:      	cmovbl	%r12d, %ecx
    b870:      	addl	%ecx, %esi
    b872:      	movl	%r12d, %edi
    b875:      	subl	%esi, %edi
    b877:      	movl	%edi, 0x50(%rsp)
    b87b:      	subq	%rsi, %rax
    b87e:      	jb	0x167a2 <generic_lsm_path+0xba72>
    b884:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b88a:      	ja	0x167a2 <generic_lsm_path+0xba72>
    b890:      	cmpl	%r15d, %r12d
    b893:      	jbe	0xb899 <generic_lsm_path+0xb69>
    b895:      	movb	$0x2f, (%rbx,%rax)
    b899:      	xorl	%edi, %edi
    b89b:      	cmpl	%r15d, %r12d
    b89e:      	seta	%dil
    b8a2:      	movzbl	%cl, %esi
    b8a5:      	addq	%rax, %rbx
    b8a8:      	addq	%rbx, %rdi
    b8ab:      	movl	$0x4, %eax
    b8b0:      	callq	*%rax
    b8b2:      	movq	%rbx, 0x48(%rsp)
    b8b7:      	cmpl	%r15d, %r12d
    b8ba:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    b8c0:      	movq	0x8(%rsp), %r12
    b8c5:      	movq	%r12, 0x30(%rsp)
    b8ca:      	movq	0x38(%rsp), %rdx
    b8cf:      	movq	0x40(%rsp), %r15
    b8d4:      	cmpq	0x18(%rsp), %r12
    b8d9:      	je	0xb935 <generic_lsm_path+0xc05>
    b8db:      	jmp	0xb940 <generic_lsm_path+0xc10>
    b8dd:      	leaq	0x10(%r15), %rdx
    b8e1:      	movl	$0x4, %eax
    b8e6:      	movq	%rbp, %rdi
    b8e9:      	movl	$0x8, %esi
    b8ee:      	callq	*%rax
    b8f0:      	movq	0x40(%rsp), %rax
    b8f5:      	cmpq	(%rsp), %rax
    b8f9:      	je	0x1679d <generic_lsm_path+0xba6d>
    b8ff:      	addq	$0x18, %r15
    b903:      	movl	$0x4, %eax
    b908:      	leaq	0x30(%rsp), %rdi
    b90d:      	movl	$0x8, %esi
    b912:      	movq	%r15, %rdx
    b915:      	callq	*%rax
    b917:      	movq	(%rsp), %r15
    b91b:      	movq	%r15, 0x40(%rsp)
    b920:      	leaq	0x20(%r15), %rdx
    b924:      	movq	%rdx, 0x38(%rsp)
    b929:      	movq	0x30(%rsp), %r12
    b92e:      	cmpq	0x18(%rsp), %r12
    b933:      	jne	0xb940 <generic_lsm_path+0xc10>
    b935:      	cmpq	0x20(%rsp), %rdx
    b93a:      	je	0x1679d <generic_lsm_path+0xba6d>
    b940:      	movl	$0x4, %eax
    b945:      	leaq	0x10(%rsp), %rdi
    b94a:      	movl	$0x8, %esi
    b94f:      	callq	*%rax
    b951:      	cmpq	0x10(%rsp), %r12
    b956:      	je	0xba55 <generic_lsm_path+0xd25>
    b95c:      	leaq	0x18(%r12), %rbx
    b961:      	movl	$0x4, %eax
    b966:      	movq	%rbp, %rdi
    b969:      	movl	$0x8, %esi
    b96e:      	movq	%rbx, %rdx
    b971:      	callq	*%rax
    b973:      	cmpq	%r12, (%rsp)
    b977:      	je	0xba55 <generic_lsm_path+0xd25>
    b97d:      	movl	$0x4, %eax
    b982:      	leaq	0x8(%rsp), %rdi
    b987:      	movl	$0x8, %esi
    b98c:      	movq	%rbx, %rdx
    b98f:      	callq	*%rax
    b991:      	addq	$0x20, %r12
    b995:      	movl	$0x4, %eax
    b99a:      	leaq	0x58(%rsp), %rdi
    b99f:      	movl	$0x10, %ecx
    b9a4:      	movl	$0x10, %esi
    b9a9:      	movq	%r12, %rdx
    b9ac:      	callq	*%rax
    b9ae:      	movq	0x28(%rsp), %rbx
    b9b3:      	movq	0x48(%rsp), %rax
    b9b8:      	movl	0x5c(%rsp), %r15d
    b9bd:      	subq	%rbx, %rax
    b9c0:      	movl	0x50(%rsp), %r12d
    b9c5:      	movl	%r15d, %edx
    b9c8:      	subl	%r12d, %edx
    b9cb:      	movl	$0x0, %ecx
    b9d0:      	cmovbl	%ecx, %edx
    b9d3:      	addq	0x60(%rsp), %rdx
    b9d8:      	xorl	%esi, %esi
    b9da:      	cmpl	%r15d, %r12d
    b9dd:      	seta	%sil
    b9e1:      	movl	%r15d, %ecx
    b9e4:      	cmovbl	%r12d, %ecx
    b9e8:      	addl	%ecx, %esi
    b9ea:      	movl	%r12d, %edi
    b9ed:      	subl	%esi, %edi
    b9ef:      	movl	%edi, 0x50(%rsp)
    b9f3:      	subq	%rsi, %rax
    b9f6:      	jb	0x167a2 <generic_lsm_path+0xba72>
    b9fc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ba02:      	ja	0x167a2 <generic_lsm_path+0xba72>
    ba08:      	cmpl	%r15d, %r12d
    ba0b:      	jbe	0xba11 <generic_lsm_path+0xce1>
    ba0d:      	movb	$0x2f, (%rbx,%rax)
    ba11:      	xorl	%edi, %edi
    ba13:      	cmpl	%r15d, %r12d
    ba16:      	seta	%dil
    ba1a:      	movzbl	%cl, %esi
    ba1d:      	addq	%rax, %rbx
    ba20:      	addq	%rbx, %rdi
    ba23:      	movl	$0x4, %eax
    ba28:      	callq	*%rax
    ba2a:      	movq	%rbx, 0x48(%rsp)
    ba2f:      	cmpl	%r15d, %r12d
    ba32:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    ba38:      	movq	0x8(%rsp), %r12
    ba3d:      	movq	%r12, 0x30(%rsp)
    ba42:      	movq	0x38(%rsp), %rdx
    ba47:      	movq	0x40(%rsp), %r15
    ba4c:      	cmpq	0x18(%rsp), %r12
    ba51:      	je	0xbaad <generic_lsm_path+0xd7d>
    ba53:      	jmp	0xbab8 <generic_lsm_path+0xd88>
    ba55:      	leaq	0x10(%r15), %rdx
    ba59:      	movl	$0x4, %eax
    ba5e:      	movq	%rbp, %rdi
    ba61:      	movl	$0x8, %esi
    ba66:      	callq	*%rax
    ba68:      	movq	0x40(%rsp), %rax
    ba6d:      	cmpq	(%rsp), %rax
    ba71:      	je	0x1679d <generic_lsm_path+0xba6d>
    ba77:      	addq	$0x18, %r15
    ba7b:      	movl	$0x4, %eax
    ba80:      	leaq	0x30(%rsp), %rdi
    ba85:      	movl	$0x8, %esi
    ba8a:      	movq	%r15, %rdx
    ba8d:      	callq	*%rax
    ba8f:      	movq	(%rsp), %r15
    ba93:      	movq	%r15, 0x40(%rsp)
    ba98:      	leaq	0x20(%r15), %rdx
    ba9c:      	movq	%rdx, 0x38(%rsp)
    baa1:      	movq	0x30(%rsp), %r12
    baa6:      	cmpq	0x18(%rsp), %r12
    baab:      	jne	0xbab8 <generic_lsm_path+0xd88>
    baad:      	cmpq	0x20(%rsp), %rdx
    bab2:      	je	0x1679d <generic_lsm_path+0xba6d>
    bab8:      	movl	$0x4, %eax
    babd:      	leaq	0x10(%rsp), %rdi
    bac2:      	movl	$0x8, %esi
    bac7:      	callq	*%rax
    bac9:      	cmpq	0x10(%rsp), %r12
    bace:      	je	0xbbcd <generic_lsm_path+0xe9d>
    bad4:      	leaq	0x18(%r12), %rbx
    bad9:      	movl	$0x4, %eax
    bade:      	movq	%rbp, %rdi
    bae1:      	movl	$0x8, %esi
    bae6:      	movq	%rbx, %rdx
    bae9:      	callq	*%rax
    baeb:      	cmpq	%r12, (%rsp)
    baef:      	je	0xbbcd <generic_lsm_path+0xe9d>
    baf5:      	movl	$0x4, %eax
    bafa:      	leaq	0x8(%rsp), %rdi
    baff:      	movl	$0x8, %esi
    bb04:      	movq	%rbx, %rdx
    bb07:      	callq	*%rax
    bb09:      	addq	$0x20, %r12
    bb0d:      	movl	$0x4, %eax
    bb12:      	leaq	0x58(%rsp), %rdi
    bb17:      	movl	$0x10, %ecx
    bb1c:      	movl	$0x10, %esi
    bb21:      	movq	%r12, %rdx
    bb24:      	callq	*%rax
    bb26:      	movq	0x28(%rsp), %rbx
    bb2b:      	movq	0x48(%rsp), %rax
    bb30:      	movl	0x5c(%rsp), %r15d
    bb35:      	subq	%rbx, %rax
    bb38:      	movl	0x50(%rsp), %r12d
    bb3d:      	movl	%r15d, %edx
    bb40:      	subl	%r12d, %edx
    bb43:      	movl	$0x0, %ecx
    bb48:      	cmovbl	%ecx, %edx
    bb4b:      	addq	0x60(%rsp), %rdx
    bb50:      	xorl	%esi, %esi
    bb52:      	cmpl	%r15d, %r12d
    bb55:      	seta	%sil
    bb59:      	movl	%r15d, %ecx
    bb5c:      	cmovbl	%r12d, %ecx
    bb60:      	addl	%ecx, %esi
    bb62:      	movl	%r12d, %edi
    bb65:      	subl	%esi, %edi
    bb67:      	movl	%edi, 0x50(%rsp)
    bb6b:      	subq	%rsi, %rax
    bb6e:      	jb	0x167a2 <generic_lsm_path+0xba72>
    bb74:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    bb7a:      	ja	0x167a2 <generic_lsm_path+0xba72>
    bb80:      	cmpl	%r15d, %r12d
    bb83:      	jbe	0xbb89 <generic_lsm_path+0xe59>
    bb85:      	movb	$0x2f, (%rbx,%rax)
    bb89:      	xorl	%edi, %edi
    bb8b:      	cmpl	%r15d, %r12d
    bb8e:      	seta	%dil
    bb92:      	movzbl	%cl, %esi
    bb95:      	addq	%rax, %rbx
    bb98:      	addq	%rbx, %rdi
    bb9b:      	movl	$0x4, %eax
    bba0:      	callq	*%rax
    bba2:      	movq	%rbx, 0x48(%rsp)
    bba7:      	cmpl	%r15d, %r12d
    bbaa:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    bbb0:      	movq	0x8(%rsp), %r12
    bbb5:      	movq	%r12, 0x30(%rsp)
    bbba:      	movq	0x38(%rsp), %rdx
    bbbf:      	movq	0x40(%rsp), %r15
    bbc4:      	cmpq	0x18(%rsp), %r12
    bbc9:      	je	0xbc25 <generic_lsm_path+0xef5>
    bbcb:      	jmp	0xbc30 <generic_lsm_path+0xf00>
    bbcd:      	leaq	0x10(%r15), %rdx
    bbd1:      	movl	$0x4, %eax
    bbd6:      	movq	%rbp, %rdi
    bbd9:      	movl	$0x8, %esi
    bbde:      	callq	*%rax
    bbe0:      	movq	0x40(%rsp), %rax
    bbe5:      	cmpq	(%rsp), %rax
    bbe9:      	je	0x1679d <generic_lsm_path+0xba6d>
    bbef:      	addq	$0x18, %r15
    bbf3:      	movl	$0x4, %eax
    bbf8:      	leaq	0x30(%rsp), %rdi
    bbfd:      	movl	$0x8, %esi
    bc02:      	movq	%r15, %rdx
    bc05:      	callq	*%rax
    bc07:      	movq	(%rsp), %r15
    bc0b:      	movq	%r15, 0x40(%rsp)
    bc10:      	leaq	0x20(%r15), %rdx
    bc14:      	movq	%rdx, 0x38(%rsp)
    bc19:      	movq	0x30(%rsp), %r12
    bc1e:      	cmpq	0x18(%rsp), %r12
    bc23:      	jne	0xbc30 <generic_lsm_path+0xf00>
    bc25:      	cmpq	0x20(%rsp), %rdx
    bc2a:      	je	0x1679d <generic_lsm_path+0xba6d>
    bc30:      	movl	$0x4, %eax
    bc35:      	leaq	0x10(%rsp), %rdi
    bc3a:      	movl	$0x8, %esi
    bc3f:      	callq	*%rax
    bc41:      	cmpq	0x10(%rsp), %r12
    bc46:      	je	0xbd3e <generic_lsm_path+0x100e>
    bc4c:      	leaq	0x18(%r12), %rbx
    bc51:      	movl	$0x4, %eax
    bc56:      	movq	%rbp, %rdi
    bc59:      	movl	$0x8, %esi
    bc5e:      	movq	%rbx, %rdx
    bc61:      	callq	*%rax
    bc63:      	cmpq	%r12, (%rsp)
    bc67:      	je	0xbd3e <generic_lsm_path+0x100e>
    bc6d:      	movl	$0x4, %eax
    bc72:      	leaq	0x8(%rsp), %rdi
    bc77:      	movl	$0x8, %esi
    bc7c:      	movq	%rbx, %rdx
    bc7f:      	callq	*%rax
    bc81:      	addq	$0x20, %r12
    bc85:      	movl	$0x4, %eax
    bc8a:      	leaq	0x58(%rsp), %rdi
    bc8f:      	movl	$0x10, %ecx
    bc94:      	movl	$0x10, %esi
    bc99:      	movq	%r12, %rdx
    bc9c:      	callq	*%rax
    bc9e:      	movq	0x28(%rsp), %rbx
    bca3:      	movq	0x48(%rsp), %rax
    bca8:      	movl	0x5c(%rsp), %r15d
    bcad:      	subq	%rbx, %rax
    bcb0:      	movl	0x50(%rsp), %r12d
    bcb5:      	movl	%r15d, %edx
    bcb8:      	subl	%r12d, %edx
    bcbb:      	movl	$0x0, %ecx
    bcc0:      	cmovbl	%ecx, %edx
    bcc3:      	addq	0x60(%rsp), %rdx
    bcc8:      	xorl	%esi, %esi
    bcca:      	cmpl	%r15d, %r12d
    bccd:      	seta	%sil
    bcd1:      	movl	%r15d, %ecx
    bcd4:      	cmovbl	%r12d, %ecx
    bcd8:      	addl	%ecx, %esi
    bcda:      	movl	%r12d, %edi
    bcdd:      	subl	%esi, %edi
    bcdf:      	movl	%edi, 0x50(%rsp)
    bce3:      	subq	%rsi, %rax
    bce6:      	jb	0x167a2 <generic_lsm_path+0xba72>
    bcec:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    bcf2:      	ja	0x167a2 <generic_lsm_path+0xba72>
    bcf8:      	cmpl	%r15d, %r12d
    bcfb:      	jbe	0xbd01 <generic_lsm_path+0xfd1>
    bcfd:      	movb	$0x2f, (%rbx,%rax)
    bd01:      	xorl	%edi, %edi
    bd03:      	cmpl	%r15d, %r12d
    bd06:      	seta	%dil
    bd0a:      	movzbl	%cl, %esi
    bd0d:      	addq	%rax, %rbx
    bd10:      	addq	%rbx, %rdi
    bd13:      	movl	$0x4, %eax
    bd18:      	callq	*%rax
    bd1a:      	movq	%rbx, 0x48(%rsp)
    bd1f:      	cmpl	%r15d, %r12d
    bd22:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    bd28:      	movq	0x8(%rsp), %r12
    bd2d:      	movq	%r12, 0x30(%rsp)
    bd32:      	movq	0x38(%rsp), %rdx
    bd37:      	movq	0x40(%rsp), %r15
    bd3c:      	jmp	0xbd8f <generic_lsm_path+0x105f>
    bd3e:      	leaq	0x10(%r15), %rdx
    bd42:      	movl	$0x4, %eax
    bd47:      	movq	%rbp, %rdi
    bd4a:      	movl	$0x8, %esi
    bd4f:      	callq	*%rax
    bd51:      	movq	0x40(%rsp), %rax
    bd56:      	cmpq	(%rsp), %rax
    bd5a:      	je	0x1679d <generic_lsm_path+0xba6d>
    bd60:      	addq	$0x18, %r15
    bd64:      	movl	$0x4, %eax
    bd69:      	leaq	0x30(%rsp), %rdi
    bd6e:      	movl	$0x8, %esi
    bd73:      	movq	%r15, %rdx
    bd76:      	callq	*%rax
    bd78:      	movq	(%rsp), %r15
    bd7c:      	movq	%r15, 0x40(%rsp)
    bd81:      	leaq	0x20(%r15), %rdx
    bd85:      	movq	%rdx, 0x38(%rsp)
    bd8a:      	movq	0x30(%rsp), %r12
    bd8f:      	cmpq	0x18(%rsp), %r12
    bd94:      	jne	0xbda1 <generic_lsm_path+0x1071>
    bd96:      	cmpq	0x20(%rsp), %rdx
    bd9b:      	je	0x1679d <generic_lsm_path+0xba6d>
    bda1:      	movl	$0x4, %eax
    bda6:      	leaq	0x10(%rsp), %rdi
    bdab:      	movl	$0x8, %esi
    bdb0:      	callq	*%rax
    bdb2:      	cmpq	0x10(%rsp), %r12
    bdb7:      	je	0xbeaf <generic_lsm_path+0x117f>
    bdbd:      	leaq	0x18(%r12), %rbx
    bdc2:      	movl	$0x4, %eax
    bdc7:      	movq	%rbp, %rdi
    bdca:      	movl	$0x8, %esi
    bdcf:      	movq	%rbx, %rdx
    bdd2:      	callq	*%rax
    bdd4:      	cmpq	%r12, (%rsp)
    bdd8:      	je	0xbeaf <generic_lsm_path+0x117f>
    bdde:      	movl	$0x4, %eax
    bde3:      	leaq	0x8(%rsp), %rdi
    bde8:      	movl	$0x8, %esi
    bded:      	movq	%rbx, %rdx
    bdf0:      	callq	*%rax
    bdf2:      	addq	$0x20, %r12
    bdf6:      	movl	$0x4, %eax
    bdfb:      	leaq	0x58(%rsp), %rdi
    be00:      	movl	$0x10, %ecx
    be05:      	movl	$0x10, %esi
    be0a:      	movq	%r12, %rdx
    be0d:      	callq	*%rax
    be0f:      	movq	0x28(%rsp), %rbx
    be14:      	movq	0x48(%rsp), %rax
    be19:      	movl	0x5c(%rsp), %r15d
    be1e:      	subq	%rbx, %rax
    be21:      	movl	0x50(%rsp), %r12d
    be26:      	movl	%r15d, %edx
    be29:      	subl	%r12d, %edx
    be2c:      	movl	$0x0, %ecx
    be31:      	cmovbl	%ecx, %edx
    be34:      	addq	0x60(%rsp), %rdx
    be39:      	xorl	%esi, %esi
    be3b:      	cmpl	%r15d, %r12d
    be3e:      	seta	%sil
    be42:      	movl	%r15d, %ecx
    be45:      	cmovbl	%r12d, %ecx
    be49:      	addl	%ecx, %esi
    be4b:      	movl	%r12d, %edi
    be4e:      	subl	%esi, %edi
    be50:      	movl	%edi, 0x50(%rsp)
    be54:      	subq	%rsi, %rax
    be57:      	jb	0x167a2 <generic_lsm_path+0xba72>
    be5d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    be63:      	ja	0x167a2 <generic_lsm_path+0xba72>
    be69:      	cmpl	%r15d, %r12d
    be6c:      	jbe	0xbe72 <generic_lsm_path+0x1142>
    be6e:      	movb	$0x2f, (%rbx,%rax)
    be72:      	xorl	%edi, %edi
    be74:      	cmpl	%r15d, %r12d
    be77:      	seta	%dil
    be7b:      	movzbl	%cl, %esi
    be7e:      	addq	%rax, %rbx
    be81:      	addq	%rbx, %rdi
    be84:      	movl	$0x4, %eax
    be89:      	callq	*%rax
    be8b:      	movq	%rbx, 0x48(%rsp)
    be90:      	cmpl	%r15d, %r12d
    be93:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    be99:      	movq	0x8(%rsp), %r12
    be9e:      	movq	%r12, 0x30(%rsp)
    bea3:      	movq	0x38(%rsp), %rdx
    bea8:      	movq	0x40(%rsp), %r15
    bead:      	jmp	0xbf00 <generic_lsm_path+0x11d0>
    beaf:      	leaq	0x10(%r15), %rdx
    beb3:      	movl	$0x4, %eax
    beb8:      	movq	%rbp, %rdi
    bebb:      	movl	$0x8, %esi
    bec0:      	callq	*%rax
    bec2:      	movq	0x40(%rsp), %rax
    bec7:      	cmpq	(%rsp), %rax
    becb:      	je	0x1679d <generic_lsm_path+0xba6d>
    bed1:      	addq	$0x18, %r15
    bed5:      	movl	$0x4, %eax
    beda:      	leaq	0x30(%rsp), %rdi
    bedf:      	movl	$0x8, %esi
    bee4:      	movq	%r15, %rdx
    bee7:      	callq	*%rax
    bee9:      	movq	(%rsp), %r15
    beed:      	movq	%r15, 0x40(%rsp)
    bef2:      	leaq	0x20(%r15), %rdx
    bef6:      	movq	%rdx, 0x38(%rsp)
    befb:      	movq	0x30(%rsp), %r12
    bf00:      	cmpq	0x18(%rsp), %r12
    bf05:      	jne	0xbf12 <generic_lsm_path+0x11e2>
    bf07:      	cmpq	0x20(%rsp), %rdx
    bf0c:      	je	0x1679d <generic_lsm_path+0xba6d>
    bf12:      	movl	$0x4, %eax
    bf17:      	leaq	0x10(%rsp), %rdi
    bf1c:      	movl	$0x8, %esi
    bf21:      	callq	*%rax
    bf23:      	cmpq	0x10(%rsp), %r12
    bf28:      	je	0xc020 <generic_lsm_path+0x12f0>
    bf2e:      	leaq	0x18(%r12), %rbx
    bf33:      	movl	$0x4, %eax
    bf38:      	movq	%rbp, %rdi
    bf3b:      	movl	$0x8, %esi
    bf40:      	movq	%rbx, %rdx
    bf43:      	callq	*%rax
    bf45:      	cmpq	%r12, (%rsp)
    bf49:      	je	0xc020 <generic_lsm_path+0x12f0>
    bf4f:      	movl	$0x4, %eax
    bf54:      	leaq	0x8(%rsp), %rdi
    bf59:      	movl	$0x8, %esi
    bf5e:      	movq	%rbx, %rdx
    bf61:      	callq	*%rax
    bf63:      	addq	$0x20, %r12
    bf67:      	movl	$0x4, %eax
    bf6c:      	leaq	0x58(%rsp), %rdi
    bf71:      	movl	$0x10, %ecx
    bf76:      	movl	$0x10, %esi
    bf7b:      	movq	%r12, %rdx
    bf7e:      	callq	*%rax
    bf80:      	movq	0x28(%rsp), %rbx
    bf85:      	movq	0x48(%rsp), %rax
    bf8a:      	movl	0x5c(%rsp), %r15d
    bf8f:      	subq	%rbx, %rax
    bf92:      	movl	0x50(%rsp), %r12d
    bf97:      	movl	%r15d, %edx
    bf9a:      	subl	%r12d, %edx
    bf9d:      	movl	$0x0, %ecx
    bfa2:      	cmovbl	%ecx, %edx
    bfa5:      	addq	0x60(%rsp), %rdx
    bfaa:      	xorl	%esi, %esi
    bfac:      	cmpl	%r15d, %r12d
    bfaf:      	seta	%sil
    bfb3:      	movl	%r15d, %ecx
    bfb6:      	cmovbl	%r12d, %ecx
    bfba:      	addl	%ecx, %esi
    bfbc:      	movl	%r12d, %edi
    bfbf:      	subl	%esi, %edi
    bfc1:      	movl	%edi, 0x50(%rsp)
    bfc5:      	subq	%rsi, %rax
    bfc8:      	jb	0x167a2 <generic_lsm_path+0xba72>
    bfce:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    bfd4:      	ja	0x167a2 <generic_lsm_path+0xba72>
    bfda:      	cmpl	%r15d, %r12d
    bfdd:      	jbe	0xbfe3 <generic_lsm_path+0x12b3>
    bfdf:      	movb	$0x2f, (%rbx,%rax)
    bfe3:      	xorl	%edi, %edi
    bfe5:      	cmpl	%r15d, %r12d
    bfe8:      	seta	%dil
    bfec:      	movzbl	%cl, %esi
    bfef:      	addq	%rax, %rbx
    bff2:      	addq	%rbx, %rdi
    bff5:      	movl	$0x4, %eax
    bffa:      	callq	*%rax
    bffc:      	movq	%rbx, 0x48(%rsp)
    c001:      	cmpl	%r15d, %r12d
    c004:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    c00a:      	movq	0x8(%rsp), %r12
    c00f:      	movq	%r12, 0x30(%rsp)
    c014:      	movq	0x38(%rsp), %rdx
    c019:      	movq	0x40(%rsp), %r15
    c01e:      	jmp	0xc071 <generic_lsm_path+0x1341>
    c020:      	leaq	0x10(%r15), %rdx
    c024:      	movl	$0x4, %eax
    c029:      	movq	%rbp, %rdi
    c02c:      	movl	$0x8, %esi
    c031:      	callq	*%rax
    c033:      	movq	0x40(%rsp), %rax
    c038:      	cmpq	(%rsp), %rax
    c03c:      	je	0x1679d <generic_lsm_path+0xba6d>
    c042:      	addq	$0x18, %r15
    c046:      	movl	$0x4, %eax
    c04b:      	leaq	0x30(%rsp), %rdi
    c050:      	movl	$0x8, %esi
    c055:      	movq	%r15, %rdx
    c058:      	callq	*%rax
    c05a:      	movq	(%rsp), %r15
    c05e:      	movq	%r15, 0x40(%rsp)
    c063:      	leaq	0x20(%r15), %rdx
    c067:      	movq	%rdx, 0x38(%rsp)
    c06c:      	movq	0x30(%rsp), %r12
    c071:      	cmpq	0x18(%rsp), %r12
    c076:      	jne	0xc083 <generic_lsm_path+0x1353>
    c078:      	cmpq	0x20(%rsp), %rdx
    c07d:      	je	0x1679d <generic_lsm_path+0xba6d>
    c083:      	movl	$0x4, %eax
    c088:      	leaq	0x10(%rsp), %rdi
    c08d:      	movl	$0x8, %esi
    c092:      	callq	*%rax
    c094:      	cmpq	0x10(%rsp), %r12
    c099:      	je	0xc191 <generic_lsm_path+0x1461>
    c09f:      	leaq	0x18(%r12), %rbx
    c0a4:      	movl	$0x4, %eax
    c0a9:      	movq	%rbp, %rdi
    c0ac:      	movl	$0x8, %esi
    c0b1:      	movq	%rbx, %rdx
    c0b4:      	callq	*%rax
    c0b6:      	cmpq	%r12, (%rsp)
    c0ba:      	je	0xc191 <generic_lsm_path+0x1461>
    c0c0:      	movl	$0x4, %eax
    c0c5:      	leaq	0x8(%rsp), %rdi
    c0ca:      	movl	$0x8, %esi
    c0cf:      	movq	%rbx, %rdx
    c0d2:      	callq	*%rax
    c0d4:      	addq	$0x20, %r12
    c0d8:      	movl	$0x4, %eax
    c0dd:      	leaq	0x58(%rsp), %rdi
    c0e2:      	movl	$0x10, %ecx
    c0e7:      	movl	$0x10, %esi
    c0ec:      	movq	%r12, %rdx
    c0ef:      	callq	*%rax
    c0f1:      	movq	0x28(%rsp), %rbx
    c0f6:      	movq	0x48(%rsp), %rax
    c0fb:      	movl	0x5c(%rsp), %r15d
    c100:      	subq	%rbx, %rax
    c103:      	movl	0x50(%rsp), %r12d
    c108:      	movl	%r15d, %edx
    c10b:      	subl	%r12d, %edx
    c10e:      	movl	$0x0, %ecx
    c113:      	cmovbl	%ecx, %edx
    c116:      	addq	0x60(%rsp), %rdx
    c11b:      	xorl	%esi, %esi
    c11d:      	cmpl	%r15d, %r12d
    c120:      	seta	%sil
    c124:      	movl	%r15d, %ecx
    c127:      	cmovbl	%r12d, %ecx
    c12b:      	addl	%ecx, %esi
    c12d:      	movl	%r12d, %edi
    c130:      	subl	%esi, %edi
    c132:      	movl	%edi, 0x50(%rsp)
    c136:      	subq	%rsi, %rax
    c139:      	jb	0x167a2 <generic_lsm_path+0xba72>
    c13f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c145:      	ja	0x167a2 <generic_lsm_path+0xba72>
    c14b:      	cmpl	%r15d, %r12d
    c14e:      	jbe	0xc154 <generic_lsm_path+0x1424>
    c150:      	movb	$0x2f, (%rbx,%rax)
    c154:      	xorl	%edi, %edi
    c156:      	cmpl	%r15d, %r12d
    c159:      	seta	%dil
    c15d:      	movzbl	%cl, %esi
    c160:      	addq	%rax, %rbx
    c163:      	addq	%rbx, %rdi
    c166:      	movl	$0x4, %eax
    c16b:      	callq	*%rax
    c16d:      	movq	%rbx, 0x48(%rsp)
    c172:      	cmpl	%r15d, %r12d
    c175:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    c17b:      	movq	0x8(%rsp), %r12
    c180:      	movq	%r12, 0x30(%rsp)
    c185:      	movq	0x38(%rsp), %rdx
    c18a:      	movq	0x40(%rsp), %r15
    c18f:      	jmp	0xc1e2 <generic_lsm_path+0x14b2>
    c191:      	leaq	0x10(%r15), %rdx
    c195:      	movl	$0x4, %eax
    c19a:      	movq	%rbp, %rdi
    c19d:      	movl	$0x8, %esi
    c1a2:      	callq	*%rax
    c1a4:      	movq	0x40(%rsp), %rax
    c1a9:      	cmpq	(%rsp), %rax
    c1ad:      	je	0x1679d <generic_lsm_path+0xba6d>
    c1b3:      	addq	$0x18, %r15
    c1b7:      	movl	$0x4, %eax
    c1bc:      	leaq	0x30(%rsp), %rdi
    c1c1:      	movl	$0x8, %esi
    c1c6:      	movq	%r15, %rdx
    c1c9:      	callq	*%rax
    c1cb:      	movq	(%rsp), %r15
    c1cf:      	movq	%r15, 0x40(%rsp)
    c1d4:      	leaq	0x20(%r15), %rdx
    c1d8:      	movq	%rdx, 0x38(%rsp)
    c1dd:      	movq	0x30(%rsp), %r12
    c1e2:      	cmpq	0x18(%rsp), %r12
    c1e7:      	jne	0xc1f4 <generic_lsm_path+0x14c4>
    c1e9:      	cmpq	0x20(%rsp), %rdx
    c1ee:      	je	0x1679d <generic_lsm_path+0xba6d>
    c1f4:      	movl	$0x4, %eax
    c1f9:      	leaq	0x10(%rsp), %rdi
    c1fe:      	movl	$0x8, %esi
    c203:      	callq	*%rax
    c205:      	cmpq	0x10(%rsp), %r12
    c20a:      	je	0xc302 <generic_lsm_path+0x15d2>
    c210:      	leaq	0x18(%r12), %rbx
    c215:      	movl	$0x4, %eax
    c21a:      	movq	%rbp, %rdi
    c21d:      	movl	$0x8, %esi
    c222:      	movq	%rbx, %rdx
    c225:      	callq	*%rax
    c227:      	cmpq	%r12, (%rsp)
    c22b:      	je	0xc302 <generic_lsm_path+0x15d2>
    c231:      	movl	$0x4, %eax
    c236:      	leaq	0x8(%rsp), %rdi
    c23b:      	movl	$0x8, %esi
    c240:      	movq	%rbx, %rdx
    c243:      	callq	*%rax
    c245:      	addq	$0x20, %r12
    c249:      	movl	$0x4, %eax
    c24e:      	leaq	0x58(%rsp), %rdi
    c253:      	movl	$0x10, %ecx
    c258:      	movl	$0x10, %esi
    c25d:      	movq	%r12, %rdx
    c260:      	callq	*%rax
    c262:      	movq	0x28(%rsp), %rbx
    c267:      	movq	0x48(%rsp), %rax
    c26c:      	movl	0x5c(%rsp), %r15d
    c271:      	subq	%rbx, %rax
    c274:      	movl	0x50(%rsp), %r12d
    c279:      	movl	%r15d, %edx
    c27c:      	subl	%r12d, %edx
    c27f:      	movl	$0x0, %ecx
    c284:      	cmovbl	%ecx, %edx
    c287:      	addq	0x60(%rsp), %rdx
    c28c:      	xorl	%esi, %esi
    c28e:      	cmpl	%r15d, %r12d
    c291:      	seta	%sil
    c295:      	movl	%r15d, %ecx
    c298:      	cmovbl	%r12d, %ecx
    c29c:      	addl	%ecx, %esi
    c29e:      	movl	%r12d, %edi
    c2a1:      	subl	%esi, %edi
    c2a3:      	movl	%edi, 0x50(%rsp)
    c2a7:      	subq	%rsi, %rax
    c2aa:      	jb	0x167a2 <generic_lsm_path+0xba72>
    c2b0:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c2b6:      	ja	0x167a2 <generic_lsm_path+0xba72>
    c2bc:      	cmpl	%r15d, %r12d
    c2bf:      	jbe	0xc2c5 <generic_lsm_path+0x1595>
    c2c1:      	movb	$0x2f, (%rbx,%rax)
    c2c5:      	xorl	%edi, %edi
    c2c7:      	cmpl	%r15d, %r12d
    c2ca:      	seta	%dil
    c2ce:      	movzbl	%cl, %esi
    c2d1:      	addq	%rax, %rbx
    c2d4:      	addq	%rbx, %rdi
    c2d7:      	movl	$0x4, %eax
    c2dc:      	callq	*%rax
    c2de:      	movq	%rbx, 0x48(%rsp)
    c2e3:      	cmpl	%r15d, %r12d
    c2e6:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    c2ec:      	movq	0x8(%rsp), %r12
    c2f1:      	movq	%r12, 0x30(%rsp)
    c2f6:      	movq	0x38(%rsp), %rdx
    c2fb:      	movq	0x40(%rsp), %r15
    c300:      	jmp	0xc353 <generic_lsm_path+0x1623>
    c302:      	leaq	0x10(%r15), %rdx
    c306:      	movl	$0x4, %eax
    c30b:      	movq	%rbp, %rdi
    c30e:      	movl	$0x8, %esi
    c313:      	callq	*%rax
    c315:      	movq	0x40(%rsp), %rax
    c31a:      	cmpq	(%rsp), %rax
    c31e:      	je	0x1679d <generic_lsm_path+0xba6d>
    c324:      	addq	$0x18, %r15
    c328:      	movl	$0x4, %eax
    c32d:      	leaq	0x30(%rsp), %rdi
    c332:      	movl	$0x8, %esi
    c337:      	movq	%r15, %rdx
    c33a:      	callq	*%rax
    c33c:      	movq	(%rsp), %r15
    c340:      	movq	%r15, 0x40(%rsp)
    c345:      	leaq	0x20(%r15), %rdx
    c349:      	movq	%rdx, 0x38(%rsp)
    c34e:      	movq	0x30(%rsp), %r12
    c353:      	cmpq	0x18(%rsp), %r12
    c358:      	jne	0xc365 <generic_lsm_path+0x1635>
    c35a:      	cmpq	0x20(%rsp), %rdx
    c35f:      	je	0x1679d <generic_lsm_path+0xba6d>
    c365:      	movl	$0x4, %eax
    c36a:      	leaq	0x10(%rsp), %rdi
    c36f:      	movl	$0x8, %esi
    c374:      	callq	*%rax
    c376:      	cmpq	0x10(%rsp), %r12
    c37b:      	je	0xc473 <generic_lsm_path+0x1743>
    c381:      	leaq	0x18(%r12), %rbx
    c386:      	movl	$0x4, %eax
    c38b:      	movq	%rbp, %rdi
    c38e:      	movl	$0x8, %esi
    c393:      	movq	%rbx, %rdx
    c396:      	callq	*%rax
    c398:      	cmpq	%r12, (%rsp)
    c39c:      	je	0xc473 <generic_lsm_path+0x1743>
    c3a2:      	movl	$0x4, %eax
    c3a7:      	leaq	0x8(%rsp), %rdi
    c3ac:      	movl	$0x8, %esi
    c3b1:      	movq	%rbx, %rdx
    c3b4:      	callq	*%rax
    c3b6:      	addq	$0x20, %r12
    c3ba:      	movl	$0x4, %eax
    c3bf:      	leaq	0x58(%rsp), %rdi
    c3c4:      	movl	$0x10, %ecx
    c3c9:      	movl	$0x10, %esi
    c3ce:      	movq	%r12, %rdx
    c3d1:      	callq	*%rax
    c3d3:      	movq	0x28(%rsp), %rbx
    c3d8:      	movq	0x48(%rsp), %rax
    c3dd:      	movl	0x5c(%rsp), %r15d
    c3e2:      	subq	%rbx, %rax
    c3e5:      	movl	0x50(%rsp), %r12d
    c3ea:      	movl	%r15d, %edx
    c3ed:      	subl	%r12d, %edx
    c3f0:      	movl	$0x0, %ecx
    c3f5:      	cmovbl	%ecx, %edx
    c3f8:      	addq	0x60(%rsp), %rdx
    c3fd:      	xorl	%esi, %esi
    c3ff:      	cmpl	%r15d, %r12d
    c402:      	seta	%sil
    c406:      	movl	%r15d, %ecx
    c409:      	cmovbl	%r12d, %ecx
    c40d:      	addl	%ecx, %esi
    c40f:      	movl	%r12d, %edi
    c412:      	subl	%esi, %edi
    c414:      	movl	%edi, 0x50(%rsp)
    c418:      	subq	%rsi, %rax
    c41b:      	jb	0x167a2 <generic_lsm_path+0xba72>
    c421:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c427:      	ja	0x167a2 <generic_lsm_path+0xba72>
    c42d:      	cmpl	%r15d, %r12d
    c430:      	jbe	0xc436 <generic_lsm_path+0x1706>
    c432:      	movb	$0x2f, (%rbx,%rax)
    c436:      	xorl	%edi, %edi
    c438:      	cmpl	%r15d, %r12d
    c43b:      	seta	%dil
    c43f:      	movzbl	%cl, %esi
    c442:      	addq	%rax, %rbx
    c445:      	addq	%rbx, %rdi
    c448:      	movl	$0x4, %eax
    c44d:      	callq	*%rax
    c44f:      	movq	%rbx, 0x48(%rsp)
    c454:      	cmpl	%r15d, %r12d
    c457:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    c45d:      	movq	0x8(%rsp), %r12
    c462:      	movq	%r12, 0x30(%rsp)
    c467:      	movq	0x38(%rsp), %rdx
    c46c:      	movq	0x40(%rsp), %r15
    c471:      	jmp	0xc4c4 <generic_lsm_path+0x1794>
    c473:      	leaq	0x10(%r15), %rdx
    c477:      	movl	$0x4, %eax
    c47c:      	movq	%rbp, %rdi
    c47f:      	movl	$0x8, %esi
    c484:      	callq	*%rax
    c486:      	movq	0x40(%rsp), %rax
    c48b:      	cmpq	(%rsp), %rax
    c48f:      	je	0x1679d <generic_lsm_path+0xba6d>
    c495:      	addq	$0x18, %r15
    c499:      	movl	$0x4, %eax
    c49e:      	leaq	0x30(%rsp), %rdi
    c4a3:      	movl	$0x8, %esi
    c4a8:      	movq	%r15, %rdx
    c4ab:      	callq	*%rax
    c4ad:      	movq	(%rsp), %r15
    c4b1:      	movq	%r15, 0x40(%rsp)
    c4b6:      	leaq	0x20(%r15), %rdx
    c4ba:      	movq	%rdx, 0x38(%rsp)
    c4bf:      	movq	0x30(%rsp), %r12
    c4c4:      	cmpq	0x18(%rsp), %r12
    c4c9:      	jne	0xc4d6 <generic_lsm_path+0x17a6>
    c4cb:      	cmpq	0x20(%rsp), %rdx
    c4d0:      	je	0x1679d <generic_lsm_path+0xba6d>
    c4d6:      	movl	$0x4, %eax
    c4db:      	leaq	0x10(%rsp), %rdi
    c4e0:      	movl	$0x8, %esi
    c4e5:      	callq	*%rax
    c4e7:      	cmpq	0x10(%rsp), %r12
    c4ec:      	je	0xc5e4 <generic_lsm_path+0x18b4>
    c4f2:      	leaq	0x18(%r12), %rbx
    c4f7:      	movl	$0x4, %eax
    c4fc:      	movq	%rbp, %rdi
    c4ff:      	movl	$0x8, %esi
    c504:      	movq	%rbx, %rdx
    c507:      	callq	*%rax
    c509:      	cmpq	%r12, (%rsp)
    c50d:      	je	0xc5e4 <generic_lsm_path+0x18b4>
    c513:      	movl	$0x4, %eax
    c518:      	leaq	0x8(%rsp), %rdi
    c51d:      	movl	$0x8, %esi
    c522:      	movq	%rbx, %rdx
    c525:      	callq	*%rax
    c527:      	addq	$0x20, %r12
    c52b:      	movl	$0x4, %eax
    c530:      	leaq	0x58(%rsp), %rdi
    c535:      	movl	$0x10, %ecx
    c53a:      	movl	$0x10, %esi
    c53f:      	movq	%r12, %rdx
    c542:      	callq	*%rax
    c544:      	movq	0x28(%rsp), %rbx
    c549:      	movq	0x48(%rsp), %rax
    c54e:      	movl	0x5c(%rsp), %r15d
    c553:      	subq	%rbx, %rax
    c556:      	movl	0x50(%rsp), %r12d
    c55b:      	movl	%r15d, %edx
    c55e:      	subl	%r12d, %edx
    c561:      	movl	$0x0, %ecx
    c566:      	cmovbl	%ecx, %edx
    c569:      	addq	0x60(%rsp), %rdx
    c56e:      	xorl	%esi, %esi
    c570:      	cmpl	%r15d, %r12d
    c573:      	seta	%sil
    c577:      	movl	%r15d, %ecx
    c57a:      	cmovbl	%r12d, %ecx
    c57e:      	addl	%ecx, %esi
    c580:      	movl	%r12d, %edi
    c583:      	subl	%esi, %edi
    c585:      	movl	%edi, 0x50(%rsp)
    c589:      	subq	%rsi, %rax
    c58c:      	jb	0x167a2 <generic_lsm_path+0xba72>
    c592:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c598:      	ja	0x167a2 <generic_lsm_path+0xba72>
    c59e:      	cmpl	%r15d, %r12d
    c5a1:      	jbe	0xc5a7 <generic_lsm_path+0x1877>
    c5a3:      	movb	$0x2f, (%rbx,%rax)
    c5a7:      	xorl	%edi, %edi
    c5a9:      	cmpl	%r15d, %r12d
    c5ac:      	seta	%dil
    c5b0:      	movzbl	%cl, %esi
    c5b3:      	addq	%rax, %rbx
    c5b6:      	addq	%rbx, %rdi
    c5b9:      	movl	$0x4, %eax
    c5be:      	callq	*%rax
    c5c0:      	movq	%rbx, 0x48(%rsp)
    c5c5:      	cmpl	%r15d, %r12d
    c5c8:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    c5ce:      	movq	0x8(%rsp), %r12
    c5d3:      	movq	%r12, 0x30(%rsp)
    c5d8:      	movq	0x38(%rsp), %rdx
    c5dd:      	movq	0x40(%rsp), %r15
    c5e2:      	jmp	0xc635 <generic_lsm_path+0x1905>
    c5e4:      	leaq	0x10(%r15), %rdx
    c5e8:      	movl	$0x4, %eax
    c5ed:      	movq	%rbp, %rdi
    c5f0:      	movl	$0x8, %esi
    c5f5:      	callq	*%rax
    c5f7:      	movq	0x40(%rsp), %rax
    c5fc:      	cmpq	(%rsp), %rax
    c600:      	je	0x1679d <generic_lsm_path+0xba6d>
    c606:      	addq	$0x18, %r15
    c60a:      	movl	$0x4, %eax
    c60f:      	leaq	0x30(%rsp), %rdi
    c614:      	movl	$0x8, %esi
    c619:      	movq	%r15, %rdx
    c61c:      	callq	*%rax
    c61e:      	movq	(%rsp), %r15
    c622:      	movq	%r15, 0x40(%rsp)
    c627:      	leaq	0x20(%r15), %rdx
    c62b:      	movq	%rdx, 0x38(%rsp)
    c630:      	movq	0x30(%rsp), %r12
    c635:      	cmpq	0x18(%rsp), %r12
    c63a:      	jne	0xc647 <generic_lsm_path+0x1917>
    c63c:      	cmpq	0x20(%rsp), %rdx
    c641:      	je	0x1679d <generic_lsm_path+0xba6d>
    c647:      	movl	$0x4, %eax
    c64c:      	leaq	0x10(%rsp), %rdi
    c651:      	movl	$0x8, %esi
    c656:      	callq	*%rax
    c658:      	cmpq	0x10(%rsp), %r12
    c65d:      	je	0xc755 <generic_lsm_path+0x1a25>
    c663:      	leaq	0x18(%r12), %rbx
    c668:      	movl	$0x4, %eax
    c66d:      	movq	%rbp, %rdi
    c670:      	movl	$0x8, %esi
    c675:      	movq	%rbx, %rdx
    c678:      	callq	*%rax
    c67a:      	cmpq	%r12, (%rsp)
    c67e:      	je	0xc755 <generic_lsm_path+0x1a25>
    c684:      	movl	$0x4, %eax
    c689:      	leaq	0x8(%rsp), %rdi
    c68e:      	movl	$0x8, %esi
    c693:      	movq	%rbx, %rdx
    c696:      	callq	*%rax
    c698:      	addq	$0x20, %r12
    c69c:      	movl	$0x4, %eax
    c6a1:      	leaq	0x58(%rsp), %rdi
    c6a6:      	movl	$0x10, %ecx
    c6ab:      	movl	$0x10, %esi
    c6b0:      	movq	%r12, %rdx
    c6b3:      	callq	*%rax
    c6b5:      	movq	0x28(%rsp), %rbx
    c6ba:      	movq	0x48(%rsp), %rax
    c6bf:      	movl	0x5c(%rsp), %r15d
    c6c4:      	subq	%rbx, %rax
    c6c7:      	movl	0x50(%rsp), %r12d
    c6cc:      	movl	%r15d, %edx
    c6cf:      	subl	%r12d, %edx
    c6d2:      	movl	$0x0, %ecx
    c6d7:      	cmovbl	%ecx, %edx
    c6da:      	addq	0x60(%rsp), %rdx
    c6df:      	xorl	%esi, %esi
    c6e1:      	cmpl	%r15d, %r12d
    c6e4:      	seta	%sil
    c6e8:      	movl	%r15d, %ecx
    c6eb:      	cmovbl	%r12d, %ecx
    c6ef:      	addl	%ecx, %esi
    c6f1:      	movl	%r12d, %edi
    c6f4:      	subl	%esi, %edi
    c6f6:      	movl	%edi, 0x50(%rsp)
    c6fa:      	subq	%rsi, %rax
    c6fd:      	jb	0x167a2 <generic_lsm_path+0xba72>
    c703:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c709:      	ja	0x167a2 <generic_lsm_path+0xba72>
    c70f:      	cmpl	%r15d, %r12d
    c712:      	jbe	0xc718 <generic_lsm_path+0x19e8>
    c714:      	movb	$0x2f, (%rbx,%rax)
    c718:      	xorl	%edi, %edi
    c71a:      	cmpl	%r15d, %r12d
    c71d:      	seta	%dil
    c721:      	movzbl	%cl, %esi
    c724:      	addq	%rax, %rbx
    c727:      	addq	%rbx, %rdi
    c72a:      	movl	$0x4, %eax
    c72f:      	callq	*%rax
    c731:      	movq	%rbx, 0x48(%rsp)
    c736:      	cmpl	%r15d, %r12d
    c739:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    c73f:      	movq	0x8(%rsp), %r12
    c744:      	movq	%r12, 0x30(%rsp)
    c749:      	movq	0x38(%rsp), %rdx
    c74e:      	movq	0x40(%rsp), %r15
    c753:      	jmp	0xc7a6 <generic_lsm_path+0x1a76>
    c755:      	leaq	0x10(%r15), %rdx
    c759:      	movl	$0x4, %eax
    c75e:      	movq	%rbp, %rdi
    c761:      	movl	$0x8, %esi
    c766:      	callq	*%rax
    c768:      	movq	0x40(%rsp), %rax
    c76d:      	cmpq	(%rsp), %rax
    c771:      	je	0x1679d <generic_lsm_path+0xba6d>
    c777:      	addq	$0x18, %r15
    c77b:      	movl	$0x4, %eax
    c780:      	leaq	0x30(%rsp), %rdi
    c785:      	movl	$0x8, %esi
    c78a:      	movq	%r15, %rdx
    c78d:      	callq	*%rax
    c78f:      	movq	(%rsp), %r15
    c793:      	movq	%r15, 0x40(%rsp)
    c798:      	leaq	0x20(%r15), %rdx
    c79c:      	movq	%rdx, 0x38(%rsp)
    c7a1:      	movq	0x30(%rsp), %r12
    c7a6:      	cmpq	0x18(%rsp), %r12
    c7ab:      	jne	0xc7b8 <generic_lsm_path+0x1a88>
    c7ad:      	cmpq	0x20(%rsp), %rdx
    c7b2:      	je	0x1679d <generic_lsm_path+0xba6d>
    c7b8:      	movl	$0x4, %eax
    c7bd:      	leaq	0x10(%rsp), %rdi
    c7c2:      	movl	$0x8, %esi
    c7c7:      	callq	*%rax
    c7c9:      	cmpq	0x10(%rsp), %r12
    c7ce:      	je	0xc8c6 <generic_lsm_path+0x1b96>
    c7d4:      	leaq	0x18(%r12), %rbx
    c7d9:      	movl	$0x4, %eax
    c7de:      	movq	%rbp, %rdi
    c7e1:      	movl	$0x8, %esi
    c7e6:      	movq	%rbx, %rdx
    c7e9:      	callq	*%rax
    c7eb:      	cmpq	%r12, (%rsp)
    c7ef:      	je	0xc8c6 <generic_lsm_path+0x1b96>
    c7f5:      	movl	$0x4, %eax
    c7fa:      	leaq	0x8(%rsp), %rdi
    c7ff:      	movl	$0x8, %esi
    c804:      	movq	%rbx, %rdx
    c807:      	callq	*%rax
    c809:      	addq	$0x20, %r12
    c80d:      	movl	$0x4, %eax
    c812:      	leaq	0x58(%rsp), %rdi
    c817:      	movl	$0x10, %ecx
    c81c:      	movl	$0x10, %esi
    c821:      	movq	%r12, %rdx
    c824:      	callq	*%rax
    c826:      	movq	0x28(%rsp), %rbx
    c82b:      	movq	0x48(%rsp), %rax
    c830:      	movl	0x5c(%rsp), %r15d
    c835:      	subq	%rbx, %rax
    c838:      	movl	0x50(%rsp), %r12d
    c83d:      	movl	%r15d, %edx
    c840:      	subl	%r12d, %edx
    c843:      	movl	$0x0, %ecx
    c848:      	cmovbl	%ecx, %edx
    c84b:      	addq	0x60(%rsp), %rdx
    c850:      	xorl	%esi, %esi
    c852:      	cmpl	%r15d, %r12d
    c855:      	seta	%sil
    c859:      	movl	%r15d, %ecx
    c85c:      	cmovbl	%r12d, %ecx
    c860:      	addl	%ecx, %esi
    c862:      	movl	%r12d, %edi
    c865:      	subl	%esi, %edi
    c867:      	movl	%edi, 0x50(%rsp)
    c86b:      	subq	%rsi, %rax
    c86e:      	jb	0x167a2 <generic_lsm_path+0xba72>
    c874:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c87a:      	ja	0x167a2 <generic_lsm_path+0xba72>
    c880:      	cmpl	%r15d, %r12d
    c883:      	jbe	0xc889 <generic_lsm_path+0x1b59>
    c885:      	movb	$0x2f, (%rbx,%rax)
    c889:      	xorl	%edi, %edi
    c88b:      	cmpl	%r15d, %r12d
    c88e:      	seta	%dil
    c892:      	movzbl	%cl, %esi
    c895:      	addq	%rax, %rbx
    c898:      	addq	%rbx, %rdi
    c89b:      	movl	$0x4, %eax
    c8a0:      	callq	*%rax
    c8a2:      	movq	%rbx, 0x48(%rsp)
    c8a7:      	cmpl	%r15d, %r12d
    c8aa:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    c8b0:      	movq	0x8(%rsp), %r12
    c8b5:      	movq	%r12, 0x30(%rsp)
    c8ba:      	movq	0x38(%rsp), %rdx
    c8bf:      	movq	0x40(%rsp), %r15
    c8c4:      	jmp	0xc917 <generic_lsm_path+0x1be7>
    c8c6:      	leaq	0x10(%r15), %rdx
    c8ca:      	movl	$0x4, %eax
    c8cf:      	movq	%rbp, %rdi
    c8d2:      	movl	$0x8, %esi
    c8d7:      	callq	*%rax
    c8d9:      	movq	0x40(%rsp), %rax
    c8de:      	cmpq	(%rsp), %rax
    c8e2:      	je	0x1679d <generic_lsm_path+0xba6d>
    c8e8:      	addq	$0x18, %r15
    c8ec:      	movl	$0x4, %eax
    c8f1:      	leaq	0x30(%rsp), %rdi
    c8f6:      	movl	$0x8, %esi
    c8fb:      	movq	%r15, %rdx
    c8fe:      	callq	*%rax
    c900:      	movq	(%rsp), %r15
    c904:      	movq	%r15, 0x40(%rsp)
    c909:      	leaq	0x20(%r15), %rdx
    c90d:      	movq	%rdx, 0x38(%rsp)
    c912:      	movq	0x30(%rsp), %r12
    c917:      	cmpq	0x18(%rsp), %r12
    c91c:      	jne	0xc929 <generic_lsm_path+0x1bf9>
    c91e:      	cmpq	0x20(%rsp), %rdx
    c923:      	je	0x1679d <generic_lsm_path+0xba6d>
    c929:      	movl	$0x4, %eax
    c92e:      	leaq	0x10(%rsp), %rdi
    c933:      	movl	$0x8, %esi
    c938:      	callq	*%rax
    c93a:      	cmpq	0x10(%rsp), %r12
    c93f:      	je	0xca37 <generic_lsm_path+0x1d07>
    c945:      	leaq	0x18(%r12), %rbx
    c94a:      	movl	$0x4, %eax
    c94f:      	movq	%rbp, %rdi
    c952:      	movl	$0x8, %esi
    c957:      	movq	%rbx, %rdx
    c95a:      	callq	*%rax
    c95c:      	cmpq	%r12, (%rsp)
    c960:      	je	0xca37 <generic_lsm_path+0x1d07>
    c966:      	movl	$0x4, %eax
    c96b:      	leaq	0x8(%rsp), %rdi
    c970:      	movl	$0x8, %esi
    c975:      	movq	%rbx, %rdx
    c978:      	callq	*%rax
    c97a:      	addq	$0x20, %r12
    c97e:      	movl	$0x4, %eax
    c983:      	leaq	0x58(%rsp), %rdi
    c988:      	movl	$0x10, %ecx
    c98d:      	movl	$0x10, %esi
    c992:      	movq	%r12, %rdx
    c995:      	callq	*%rax
    c997:      	movq	0x28(%rsp), %rbx
    c99c:      	movq	0x48(%rsp), %rax
    c9a1:      	movl	0x5c(%rsp), %r15d
    c9a6:      	subq	%rbx, %rax
    c9a9:      	movl	0x50(%rsp), %r12d
    c9ae:      	movl	%r15d, %edx
    c9b1:      	subl	%r12d, %edx
    c9b4:      	movl	$0x0, %ecx
    c9b9:      	cmovbl	%ecx, %edx
    c9bc:      	addq	0x60(%rsp), %rdx
    c9c1:      	xorl	%esi, %esi
    c9c3:      	cmpl	%r15d, %r12d
    c9c6:      	seta	%sil
    c9ca:      	movl	%r15d, %ecx
    c9cd:      	cmovbl	%r12d, %ecx
    c9d1:      	addl	%ecx, %esi
    c9d3:      	movl	%r12d, %edi
    c9d6:      	subl	%esi, %edi
    c9d8:      	movl	%edi, 0x50(%rsp)
    c9dc:      	subq	%rsi, %rax
    c9df:      	jb	0x167a2 <generic_lsm_path+0xba72>
    c9e5:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c9eb:      	ja	0x167a2 <generic_lsm_path+0xba72>
    c9f1:      	cmpl	%r15d, %r12d
    c9f4:      	jbe	0xc9fa <generic_lsm_path+0x1cca>
    c9f6:      	movb	$0x2f, (%rbx,%rax)
    c9fa:      	xorl	%edi, %edi
    c9fc:      	cmpl	%r15d, %r12d
    c9ff:      	seta	%dil
    ca03:      	movzbl	%cl, %esi
    ca06:      	addq	%rax, %rbx
    ca09:      	addq	%rbx, %rdi
    ca0c:      	movl	$0x4, %eax
    ca11:      	callq	*%rax
    ca13:      	movq	%rbx, 0x48(%rsp)
    ca18:      	cmpl	%r15d, %r12d
    ca1b:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    ca21:      	movq	0x8(%rsp), %r12
    ca26:      	movq	%r12, 0x30(%rsp)
    ca2b:      	movq	0x38(%rsp), %rdx
    ca30:      	movq	0x40(%rsp), %r15
    ca35:      	jmp	0xca88 <generic_lsm_path+0x1d58>
    ca37:      	leaq	0x10(%r15), %rdx
    ca3b:      	movl	$0x4, %eax
    ca40:      	movq	%rbp, %rdi
    ca43:      	movl	$0x8, %esi
    ca48:      	callq	*%rax
    ca4a:      	movq	0x40(%rsp), %rax
    ca4f:      	cmpq	(%rsp), %rax
    ca53:      	je	0x1679d <generic_lsm_path+0xba6d>
    ca59:      	addq	$0x18, %r15
    ca5d:      	movl	$0x4, %eax
    ca62:      	leaq	0x30(%rsp), %rdi
    ca67:      	movl	$0x8, %esi
    ca6c:      	movq	%r15, %rdx
    ca6f:      	callq	*%rax
    ca71:      	movq	(%rsp), %r15
    ca75:      	movq	%r15, 0x40(%rsp)
    ca7a:      	leaq	0x20(%r15), %rdx
    ca7e:      	movq	%rdx, 0x38(%rsp)
    ca83:      	movq	0x30(%rsp), %r12
    ca88:      	cmpq	0x18(%rsp), %r12
    ca8d:      	jne	0xca9a <generic_lsm_path+0x1d6a>
    ca8f:      	cmpq	0x20(%rsp), %rdx
    ca94:      	je	0x1679d <generic_lsm_path+0xba6d>
    ca9a:      	movl	$0x4, %eax
    ca9f:      	leaq	0x10(%rsp), %rdi
    caa4:      	movl	$0x8, %esi
    caa9:      	callq	*%rax
    caab:      	cmpq	0x10(%rsp), %r12
    cab0:      	je	0xcba8 <generic_lsm_path+0x1e78>
    cab6:      	leaq	0x18(%r12), %rbx
    cabb:      	movl	$0x4, %eax
    cac0:      	movq	%rbp, %rdi
    cac3:      	movl	$0x8, %esi
    cac8:      	movq	%rbx, %rdx
    cacb:      	callq	*%rax
    cacd:      	cmpq	%r12, (%rsp)
    cad1:      	je	0xcba8 <generic_lsm_path+0x1e78>
    cad7:      	movl	$0x4, %eax
    cadc:      	leaq	0x8(%rsp), %rdi
    cae1:      	movl	$0x8, %esi
    cae6:      	movq	%rbx, %rdx
    cae9:      	callq	*%rax
    caeb:      	addq	$0x20, %r12
    caef:      	movl	$0x4, %eax
    caf4:      	leaq	0x58(%rsp), %rdi
    caf9:      	movl	$0x10, %ecx
    cafe:      	movl	$0x10, %esi
    cb03:      	movq	%r12, %rdx
    cb06:      	callq	*%rax
    cb08:      	movq	0x28(%rsp), %rbx
    cb0d:      	movq	0x48(%rsp), %rax
    cb12:      	movl	0x5c(%rsp), %r15d
    cb17:      	subq	%rbx, %rax
    cb1a:      	movl	0x50(%rsp), %r12d
    cb1f:      	movl	%r15d, %edx
    cb22:      	subl	%r12d, %edx
    cb25:      	movl	$0x0, %ecx
    cb2a:      	cmovbl	%ecx, %edx
    cb2d:      	addq	0x60(%rsp), %rdx
    cb32:      	xorl	%esi, %esi
    cb34:      	cmpl	%r15d, %r12d
    cb37:      	seta	%sil
    cb3b:      	movl	%r15d, %ecx
    cb3e:      	cmovbl	%r12d, %ecx
    cb42:      	addl	%ecx, %esi
    cb44:      	movl	%r12d, %edi
    cb47:      	subl	%esi, %edi
    cb49:      	movl	%edi, 0x50(%rsp)
    cb4d:      	subq	%rsi, %rax
    cb50:      	jb	0x167a2 <generic_lsm_path+0xba72>
    cb56:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    cb5c:      	ja	0x167a2 <generic_lsm_path+0xba72>
    cb62:      	cmpl	%r15d, %r12d
    cb65:      	jbe	0xcb6b <generic_lsm_path+0x1e3b>
    cb67:      	movb	$0x2f, (%rbx,%rax)
    cb6b:      	xorl	%edi, %edi
    cb6d:      	cmpl	%r15d, %r12d
    cb70:      	seta	%dil
    cb74:      	movzbl	%cl, %esi
    cb77:      	addq	%rax, %rbx
    cb7a:      	addq	%rbx, %rdi
    cb7d:      	movl	$0x4, %eax
    cb82:      	callq	*%rax
    cb84:      	movq	%rbx, 0x48(%rsp)
    cb89:      	cmpl	%r15d, %r12d
    cb8c:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    cb92:      	movq	0x8(%rsp), %r12
    cb97:      	movq	%r12, 0x30(%rsp)
    cb9c:      	movq	0x38(%rsp), %rdx
    cba1:      	movq	0x40(%rsp), %r15
    cba6:      	jmp	0xcbf9 <generic_lsm_path+0x1ec9>
    cba8:      	leaq	0x10(%r15), %rdx
    cbac:      	movl	$0x4, %eax
    cbb1:      	movq	%rbp, %rdi
    cbb4:      	movl	$0x8, %esi
    cbb9:      	callq	*%rax
    cbbb:      	movq	0x40(%rsp), %rax
    cbc0:      	cmpq	(%rsp), %rax
    cbc4:      	je	0x1679d <generic_lsm_path+0xba6d>
    cbca:      	addq	$0x18, %r15
    cbce:      	movl	$0x4, %eax
    cbd3:      	leaq	0x30(%rsp), %rdi
    cbd8:      	movl	$0x8, %esi
    cbdd:      	movq	%r15, %rdx
    cbe0:      	callq	*%rax
    cbe2:      	movq	(%rsp), %r15
    cbe6:      	movq	%r15, 0x40(%rsp)
    cbeb:      	leaq	0x20(%r15), %rdx
    cbef:      	movq	%rdx, 0x38(%rsp)
    cbf4:      	movq	0x30(%rsp), %r12
    cbf9:      	cmpq	0x18(%rsp), %r12
    cbfe:      	jne	0xcc0b <generic_lsm_path+0x1edb>
    cc00:      	cmpq	0x20(%rsp), %rdx
    cc05:      	je	0x1679d <generic_lsm_path+0xba6d>
    cc0b:      	movl	$0x4, %eax
    cc10:      	leaq	0x10(%rsp), %rdi
    cc15:      	movl	$0x8, %esi
    cc1a:      	callq	*%rax
    cc1c:      	cmpq	0x10(%rsp), %r12
    cc21:      	je	0xcd19 <generic_lsm_path+0x1fe9>
    cc27:      	leaq	0x18(%r12), %rbx
    cc2c:      	movl	$0x4, %eax
    cc31:      	movq	%rbp, %rdi
    cc34:      	movl	$0x8, %esi
    cc39:      	movq	%rbx, %rdx
    cc3c:      	callq	*%rax
    cc3e:      	cmpq	%r12, (%rsp)
    cc42:      	je	0xcd19 <generic_lsm_path+0x1fe9>
    cc48:      	movl	$0x4, %eax
    cc4d:      	leaq	0x8(%rsp), %rdi
    cc52:      	movl	$0x8, %esi
    cc57:      	movq	%rbx, %rdx
    cc5a:      	callq	*%rax
    cc5c:      	addq	$0x20, %r12
    cc60:      	movl	$0x4, %eax
    cc65:      	leaq	0x58(%rsp), %rdi
    cc6a:      	movl	$0x10, %ecx
    cc6f:      	movl	$0x10, %esi
    cc74:      	movq	%r12, %rdx
    cc77:      	callq	*%rax
    cc79:      	movq	0x28(%rsp), %rbx
    cc7e:      	movq	0x48(%rsp), %rax
    cc83:      	movl	0x5c(%rsp), %r15d
    cc88:      	subq	%rbx, %rax
    cc8b:      	movl	0x50(%rsp), %r12d
    cc90:      	movl	%r15d, %edx
    cc93:      	subl	%r12d, %edx
    cc96:      	movl	$0x0, %ecx
    cc9b:      	cmovbl	%ecx, %edx
    cc9e:      	addq	0x60(%rsp), %rdx
    cca3:      	xorl	%esi, %esi
    cca5:      	cmpl	%r15d, %r12d
    cca8:      	seta	%sil
    ccac:      	movl	%r15d, %ecx
    ccaf:      	cmovbl	%r12d, %ecx
    ccb3:      	addl	%ecx, %esi
    ccb5:      	movl	%r12d, %edi
    ccb8:      	subl	%esi, %edi
    ccba:      	movl	%edi, 0x50(%rsp)
    ccbe:      	subq	%rsi, %rax
    ccc1:      	jb	0x167a2 <generic_lsm_path+0xba72>
    ccc7:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    cccd:      	ja	0x167a2 <generic_lsm_path+0xba72>
    ccd3:      	cmpl	%r15d, %r12d
    ccd6:      	jbe	0xccdc <generic_lsm_path+0x1fac>
    ccd8:      	movb	$0x2f, (%rbx,%rax)
    ccdc:      	xorl	%edi, %edi
    ccde:      	cmpl	%r15d, %r12d
    cce1:      	seta	%dil
    cce5:      	movzbl	%cl, %esi
    cce8:      	addq	%rax, %rbx
    cceb:      	addq	%rbx, %rdi
    ccee:      	movl	$0x4, %eax
    ccf3:      	callq	*%rax
    ccf5:      	movq	%rbx, 0x48(%rsp)
    ccfa:      	cmpl	%r15d, %r12d
    ccfd:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    cd03:      	movq	0x8(%rsp), %r12
    cd08:      	movq	%r12, 0x30(%rsp)
    cd0d:      	movq	0x38(%rsp), %rdx
    cd12:      	movq	0x40(%rsp), %r15
    cd17:      	jmp	0xcd6a <generic_lsm_path+0x203a>
    cd19:      	leaq	0x10(%r15), %rdx
    cd1d:      	movl	$0x4, %eax
    cd22:      	movq	%rbp, %rdi
    cd25:      	movl	$0x8, %esi
    cd2a:      	callq	*%rax
    cd2c:      	movq	0x40(%rsp), %rax
    cd31:      	cmpq	(%rsp), %rax
    cd35:      	je	0x1679d <generic_lsm_path+0xba6d>
    cd3b:      	addq	$0x18, %r15
    cd3f:      	movl	$0x4, %eax
    cd44:      	leaq	0x30(%rsp), %rdi
    cd49:      	movl	$0x8, %esi
    cd4e:      	movq	%r15, %rdx
    cd51:      	callq	*%rax
    cd53:      	movq	(%rsp), %r15
    cd57:      	movq	%r15, 0x40(%rsp)
    cd5c:      	leaq	0x20(%r15), %rdx
    cd60:      	movq	%rdx, 0x38(%rsp)
    cd65:      	movq	0x30(%rsp), %r12
    cd6a:      	cmpq	0x18(%rsp), %r12
    cd6f:      	jne	0xcd7c <generic_lsm_path+0x204c>
    cd71:      	cmpq	0x20(%rsp), %rdx
    cd76:      	je	0x1679d <generic_lsm_path+0xba6d>
    cd7c:      	movl	$0x4, %eax
    cd81:      	leaq	0x10(%rsp), %rdi
    cd86:      	movl	$0x8, %esi
    cd8b:      	callq	*%rax
    cd8d:      	cmpq	0x10(%rsp), %r12
    cd92:      	je	0xce8a <generic_lsm_path+0x215a>
    cd98:      	leaq	0x18(%r12), %rbx
    cd9d:      	movl	$0x4, %eax
    cda2:      	movq	%rbp, %rdi
    cda5:      	movl	$0x8, %esi
    cdaa:      	movq	%rbx, %rdx
    cdad:      	callq	*%rax
    cdaf:      	cmpq	%r12, (%rsp)
    cdb3:      	je	0xce8a <generic_lsm_path+0x215a>
    cdb9:      	movl	$0x4, %eax
    cdbe:      	leaq	0x8(%rsp), %rdi
    cdc3:      	movl	$0x8, %esi
    cdc8:      	movq	%rbx, %rdx
    cdcb:      	callq	*%rax
    cdcd:      	addq	$0x20, %r12
    cdd1:      	movl	$0x4, %eax
    cdd6:      	leaq	0x58(%rsp), %rdi
    cddb:      	movl	$0x10, %ecx
    cde0:      	movl	$0x10, %esi
    cde5:      	movq	%r12, %rdx
    cde8:      	callq	*%rax
    cdea:      	movq	0x28(%rsp), %rbx
    cdef:      	movq	0x48(%rsp), %rax
    cdf4:      	movl	0x5c(%rsp), %r15d
    cdf9:      	subq	%rbx, %rax
    cdfc:      	movl	0x50(%rsp), %r12d
    ce01:      	movl	%r15d, %edx
    ce04:      	subl	%r12d, %edx
    ce07:      	movl	$0x0, %ecx
    ce0c:      	cmovbl	%ecx, %edx
    ce0f:      	addq	0x60(%rsp), %rdx
    ce14:      	xorl	%esi, %esi
    ce16:      	cmpl	%r15d, %r12d
    ce19:      	seta	%sil
    ce1d:      	movl	%r15d, %ecx
    ce20:      	cmovbl	%r12d, %ecx
    ce24:      	addl	%ecx, %esi
    ce26:      	movl	%r12d, %edi
    ce29:      	subl	%esi, %edi
    ce2b:      	movl	%edi, 0x50(%rsp)
    ce2f:      	subq	%rsi, %rax
    ce32:      	jb	0x167a2 <generic_lsm_path+0xba72>
    ce38:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ce3e:      	ja	0x167a2 <generic_lsm_path+0xba72>
    ce44:      	cmpl	%r15d, %r12d
    ce47:      	jbe	0xce4d <generic_lsm_path+0x211d>
    ce49:      	movb	$0x2f, (%rbx,%rax)
    ce4d:      	xorl	%edi, %edi
    ce4f:      	cmpl	%r15d, %r12d
    ce52:      	seta	%dil
    ce56:      	movzbl	%cl, %esi
    ce59:      	addq	%rax, %rbx
    ce5c:      	addq	%rbx, %rdi
    ce5f:      	movl	$0x4, %eax
    ce64:      	callq	*%rax
    ce66:      	movq	%rbx, 0x48(%rsp)
    ce6b:      	cmpl	%r15d, %r12d
    ce6e:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    ce74:      	movq	0x8(%rsp), %r12
    ce79:      	movq	%r12, 0x30(%rsp)
    ce7e:      	movq	0x38(%rsp), %rdx
    ce83:      	movq	0x40(%rsp), %r15
    ce88:      	jmp	0xcedb <generic_lsm_path+0x21ab>
    ce8a:      	leaq	0x10(%r15), %rdx
    ce8e:      	movl	$0x4, %eax
    ce93:      	movq	%rbp, %rdi
    ce96:      	movl	$0x8, %esi
    ce9b:      	callq	*%rax
    ce9d:      	movq	0x40(%rsp), %rax
    cea2:      	cmpq	(%rsp), %rax
    cea6:      	je	0x1679d <generic_lsm_path+0xba6d>
    ceac:      	addq	$0x18, %r15
    ceb0:      	movl	$0x4, %eax
    ceb5:      	leaq	0x30(%rsp), %rdi
    ceba:      	movl	$0x8, %esi
    cebf:      	movq	%r15, %rdx
    cec2:      	callq	*%rax
    cec4:      	movq	(%rsp), %r15
    cec8:      	movq	%r15, 0x40(%rsp)
    cecd:      	leaq	0x20(%r15), %rdx
    ced1:      	movq	%rdx, 0x38(%rsp)
    ced6:      	movq	0x30(%rsp), %r12
    cedb:      	cmpq	0x18(%rsp), %r12
    cee0:      	jne	0xceed <generic_lsm_path+0x21bd>
    cee2:      	cmpq	0x20(%rsp), %rdx
    cee7:      	je	0x1679d <generic_lsm_path+0xba6d>
    ceed:      	movl	$0x4, %eax
    cef2:      	leaq	0x10(%rsp), %rdi
    cef7:      	movl	$0x8, %esi
    cefc:      	callq	*%rax
    cefe:      	cmpq	0x10(%rsp), %r12
    cf03:      	je	0xcffb <generic_lsm_path+0x22cb>
    cf09:      	leaq	0x18(%r12), %rbx
    cf0e:      	movl	$0x4, %eax
    cf13:      	movq	%rbp, %rdi
    cf16:      	movl	$0x8, %esi
    cf1b:      	movq	%rbx, %rdx
    cf1e:      	callq	*%rax
    cf20:      	cmpq	%r12, (%rsp)
    cf24:      	je	0xcffb <generic_lsm_path+0x22cb>
    cf2a:      	movl	$0x4, %eax
    cf2f:      	leaq	0x8(%rsp), %rdi
    cf34:      	movl	$0x8, %esi
    cf39:      	movq	%rbx, %rdx
    cf3c:      	callq	*%rax
    cf3e:      	addq	$0x20, %r12
    cf42:      	movl	$0x4, %eax
    cf47:      	leaq	0x58(%rsp), %rdi
    cf4c:      	movl	$0x10, %ecx
    cf51:      	movl	$0x10, %esi
    cf56:      	movq	%r12, %rdx
    cf59:      	callq	*%rax
    cf5b:      	movq	0x28(%rsp), %rbx
    cf60:      	movq	0x48(%rsp), %rax
    cf65:      	movl	0x5c(%rsp), %r15d
    cf6a:      	subq	%rbx, %rax
    cf6d:      	movl	0x50(%rsp), %r12d
    cf72:      	movl	%r15d, %edx
    cf75:      	subl	%r12d, %edx
    cf78:      	movl	$0x0, %ecx
    cf7d:      	cmovbl	%ecx, %edx
    cf80:      	addq	0x60(%rsp), %rdx
    cf85:      	xorl	%esi, %esi
    cf87:      	cmpl	%r15d, %r12d
    cf8a:      	seta	%sil
    cf8e:      	movl	%r15d, %ecx
    cf91:      	cmovbl	%r12d, %ecx
    cf95:      	addl	%ecx, %esi
    cf97:      	movl	%r12d, %edi
    cf9a:      	subl	%esi, %edi
    cf9c:      	movl	%edi, 0x50(%rsp)
    cfa0:      	subq	%rsi, %rax
    cfa3:      	jb	0x167a2 <generic_lsm_path+0xba72>
    cfa9:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    cfaf:      	ja	0x167a2 <generic_lsm_path+0xba72>
    cfb5:      	cmpl	%r15d, %r12d
    cfb8:      	jbe	0xcfbe <generic_lsm_path+0x228e>
    cfba:      	movb	$0x2f, (%rbx,%rax)
    cfbe:      	xorl	%edi, %edi
    cfc0:      	cmpl	%r15d, %r12d
    cfc3:      	seta	%dil
    cfc7:      	movzbl	%cl, %esi
    cfca:      	addq	%rax, %rbx
    cfcd:      	addq	%rbx, %rdi
    cfd0:      	movl	$0x4, %eax
    cfd5:      	callq	*%rax
    cfd7:      	movq	%rbx, 0x48(%rsp)
    cfdc:      	cmpl	%r15d, %r12d
    cfdf:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    cfe5:      	movq	0x8(%rsp), %r12
    cfea:      	movq	%r12, 0x30(%rsp)
    cfef:      	movq	0x38(%rsp), %rdx
    cff4:      	movq	0x40(%rsp), %r15
    cff9:      	jmp	0xd04c <generic_lsm_path+0x231c>
    cffb:      	leaq	0x10(%r15), %rdx
    cfff:      	movl	$0x4, %eax
    d004:      	movq	%rbp, %rdi
    d007:      	movl	$0x8, %esi
    d00c:      	callq	*%rax
    d00e:      	movq	0x40(%rsp), %rax
    d013:      	cmpq	(%rsp), %rax
    d017:      	je	0x1679d <generic_lsm_path+0xba6d>
    d01d:      	addq	$0x18, %r15
    d021:      	movl	$0x4, %eax
    d026:      	leaq	0x30(%rsp), %rdi
    d02b:      	movl	$0x8, %esi
    d030:      	movq	%r15, %rdx
    d033:      	callq	*%rax
    d035:      	movq	(%rsp), %r15
    d039:      	movq	%r15, 0x40(%rsp)
    d03e:      	leaq	0x20(%r15), %rdx
    d042:      	movq	%rdx, 0x38(%rsp)
    d047:      	movq	0x30(%rsp), %r12
    d04c:      	cmpq	0x18(%rsp), %r12
    d051:      	jne	0xd05e <generic_lsm_path+0x232e>
    d053:      	cmpq	0x20(%rsp), %rdx
    d058:      	je	0x1679d <generic_lsm_path+0xba6d>
    d05e:      	movl	$0x4, %eax
    d063:      	leaq	0x10(%rsp), %rdi
    d068:      	movl	$0x8, %esi
    d06d:      	callq	*%rax
    d06f:      	cmpq	0x10(%rsp), %r12
    d074:      	je	0xd16c <generic_lsm_path+0x243c>
    d07a:      	leaq	0x18(%r12), %rbx
    d07f:      	movl	$0x4, %eax
    d084:      	movq	%rbp, %rdi
    d087:      	movl	$0x8, %esi
    d08c:      	movq	%rbx, %rdx
    d08f:      	callq	*%rax
    d091:      	cmpq	%r12, (%rsp)
    d095:      	je	0xd16c <generic_lsm_path+0x243c>
    d09b:      	movl	$0x4, %eax
    d0a0:      	leaq	0x8(%rsp), %rdi
    d0a5:      	movl	$0x8, %esi
    d0aa:      	movq	%rbx, %rdx
    d0ad:      	callq	*%rax
    d0af:      	addq	$0x20, %r12
    d0b3:      	movl	$0x4, %eax
    d0b8:      	leaq	0x58(%rsp), %rdi
    d0bd:      	movl	$0x10, %ecx
    d0c2:      	movl	$0x10, %esi
    d0c7:      	movq	%r12, %rdx
    d0ca:      	callq	*%rax
    d0cc:      	movq	0x28(%rsp), %rbx
    d0d1:      	movq	0x48(%rsp), %rax
    d0d6:      	movl	0x5c(%rsp), %r15d
    d0db:      	subq	%rbx, %rax
    d0de:      	movl	0x50(%rsp), %r12d
    d0e3:      	movl	%r15d, %edx
    d0e6:      	subl	%r12d, %edx
    d0e9:      	movl	$0x0, %ecx
    d0ee:      	cmovbl	%ecx, %edx
    d0f1:      	addq	0x60(%rsp), %rdx
    d0f6:      	xorl	%esi, %esi
    d0f8:      	cmpl	%r15d, %r12d
    d0fb:      	seta	%sil
    d0ff:      	movl	%r15d, %ecx
    d102:      	cmovbl	%r12d, %ecx
    d106:      	addl	%ecx, %esi
    d108:      	movl	%r12d, %edi
    d10b:      	subl	%esi, %edi
    d10d:      	movl	%edi, 0x50(%rsp)
    d111:      	subq	%rsi, %rax
    d114:      	jb	0x167a2 <generic_lsm_path+0xba72>
    d11a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d120:      	ja	0x167a2 <generic_lsm_path+0xba72>
    d126:      	cmpl	%r15d, %r12d
    d129:      	jbe	0xd12f <generic_lsm_path+0x23ff>
    d12b:      	movb	$0x2f, (%rbx,%rax)
    d12f:      	xorl	%edi, %edi
    d131:      	cmpl	%r15d, %r12d
    d134:      	seta	%dil
    d138:      	movzbl	%cl, %esi
    d13b:      	addq	%rax, %rbx
    d13e:      	addq	%rbx, %rdi
    d141:      	movl	$0x4, %eax
    d146:      	callq	*%rax
    d148:      	movq	%rbx, 0x48(%rsp)
    d14d:      	cmpl	%r15d, %r12d
    d150:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    d156:      	movq	0x8(%rsp), %r12
    d15b:      	movq	%r12, 0x30(%rsp)
    d160:      	movq	0x38(%rsp), %rdx
    d165:      	movq	0x40(%rsp), %r15
    d16a:      	jmp	0xd1bd <generic_lsm_path+0x248d>
    d16c:      	leaq	0x10(%r15), %rdx
    d170:      	movl	$0x4, %eax
    d175:      	movq	%rbp, %rdi
    d178:      	movl	$0x8, %esi
    d17d:      	callq	*%rax
    d17f:      	movq	0x40(%rsp), %rax
    d184:      	cmpq	(%rsp), %rax
    d188:      	je	0x1679d <generic_lsm_path+0xba6d>
    d18e:      	addq	$0x18, %r15
    d192:      	movl	$0x4, %eax
    d197:      	leaq	0x30(%rsp), %rdi
    d19c:      	movl	$0x8, %esi
    d1a1:      	movq	%r15, %rdx
    d1a4:      	callq	*%rax
    d1a6:      	movq	(%rsp), %r15
    d1aa:      	movq	%r15, 0x40(%rsp)
    d1af:      	leaq	0x20(%r15), %rdx
    d1b3:      	movq	%rdx, 0x38(%rsp)
    d1b8:      	movq	0x30(%rsp), %r12
    d1bd:      	cmpq	0x18(%rsp), %r12
    d1c2:      	jne	0xd1cf <generic_lsm_path+0x249f>
    d1c4:      	cmpq	0x20(%rsp), %rdx
    d1c9:      	je	0x1679d <generic_lsm_path+0xba6d>
    d1cf:      	movl	$0x4, %eax
    d1d4:      	leaq	0x10(%rsp), %rdi
    d1d9:      	movl	$0x8, %esi
    d1de:      	callq	*%rax
    d1e0:      	cmpq	0x10(%rsp), %r12
    d1e5:      	je	0xd2dd <generic_lsm_path+0x25ad>
    d1eb:      	leaq	0x18(%r12), %rbx
    d1f0:      	movl	$0x4, %eax
    d1f5:      	movq	%rbp, %rdi
    d1f8:      	movl	$0x8, %esi
    d1fd:      	movq	%rbx, %rdx
    d200:      	callq	*%rax
    d202:      	cmpq	%r12, (%rsp)
    d206:      	je	0xd2dd <generic_lsm_path+0x25ad>
    d20c:      	movl	$0x4, %eax
    d211:      	leaq	0x8(%rsp), %rdi
    d216:      	movl	$0x8, %esi
    d21b:      	movq	%rbx, %rdx
    d21e:      	callq	*%rax
    d220:      	addq	$0x20, %r12
    d224:      	movl	$0x4, %eax
    d229:      	leaq	0x58(%rsp), %rdi
    d22e:      	movl	$0x10, %ecx
    d233:      	movl	$0x10, %esi
    d238:      	movq	%r12, %rdx
    d23b:      	callq	*%rax
    d23d:      	movq	0x28(%rsp), %rbx
    d242:      	movq	0x48(%rsp), %rax
    d247:      	movl	0x5c(%rsp), %r15d
    d24c:      	subq	%rbx, %rax
    d24f:      	movl	0x50(%rsp), %r12d
    d254:      	movl	%r15d, %edx
    d257:      	subl	%r12d, %edx
    d25a:      	movl	$0x0, %ecx
    d25f:      	cmovbl	%ecx, %edx
    d262:      	addq	0x60(%rsp), %rdx
    d267:      	xorl	%esi, %esi
    d269:      	cmpl	%r15d, %r12d
    d26c:      	seta	%sil
    d270:      	movl	%r15d, %ecx
    d273:      	cmovbl	%r12d, %ecx
    d277:      	addl	%ecx, %esi
    d279:      	movl	%r12d, %edi
    d27c:      	subl	%esi, %edi
    d27e:      	movl	%edi, 0x50(%rsp)
    d282:      	subq	%rsi, %rax
    d285:      	jb	0x167a2 <generic_lsm_path+0xba72>
    d28b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d291:      	ja	0x167a2 <generic_lsm_path+0xba72>
    d297:      	cmpl	%r15d, %r12d
    d29a:      	jbe	0xd2a0 <generic_lsm_path+0x2570>
    d29c:      	movb	$0x2f, (%rbx,%rax)
    d2a0:      	xorl	%edi, %edi
    d2a2:      	cmpl	%r15d, %r12d
    d2a5:      	seta	%dil
    d2a9:      	movzbl	%cl, %esi
    d2ac:      	addq	%rax, %rbx
    d2af:      	addq	%rbx, %rdi
    d2b2:      	movl	$0x4, %eax
    d2b7:      	callq	*%rax
    d2b9:      	movq	%rbx, 0x48(%rsp)
    d2be:      	cmpl	%r15d, %r12d
    d2c1:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    d2c7:      	movq	0x8(%rsp), %r12
    d2cc:      	movq	%r12, 0x30(%rsp)
    d2d1:      	movq	0x38(%rsp), %rdx
    d2d6:      	movq	0x40(%rsp), %r15
    d2db:      	jmp	0xd32e <generic_lsm_path+0x25fe>
    d2dd:      	leaq	0x10(%r15), %rdx
    d2e1:      	movl	$0x4, %eax
    d2e6:      	movq	%rbp, %rdi
    d2e9:      	movl	$0x8, %esi
    d2ee:      	callq	*%rax
    d2f0:      	movq	0x40(%rsp), %rax
    d2f5:      	cmpq	(%rsp), %rax
    d2f9:      	je	0x1679d <generic_lsm_path+0xba6d>
    d2ff:      	addq	$0x18, %r15
    d303:      	movl	$0x4, %eax
    d308:      	leaq	0x30(%rsp), %rdi
    d30d:      	movl	$0x8, %esi
    d312:      	movq	%r15, %rdx
    d315:      	callq	*%rax
    d317:      	movq	(%rsp), %r15
    d31b:      	movq	%r15, 0x40(%rsp)
    d320:      	leaq	0x20(%r15), %rdx
    d324:      	movq	%rdx, 0x38(%rsp)
    d329:      	movq	0x30(%rsp), %r12
    d32e:      	cmpq	0x18(%rsp), %r12
    d333:      	jne	0xd340 <generic_lsm_path+0x2610>
    d335:      	cmpq	0x20(%rsp), %rdx
    d33a:      	je	0x1679d <generic_lsm_path+0xba6d>
    d340:      	movl	$0x4, %eax
    d345:      	leaq	0x10(%rsp), %rdi
    d34a:      	movl	$0x8, %esi
    d34f:      	callq	*%rax
    d351:      	cmpq	0x10(%rsp), %r12
    d356:      	je	0xd44e <generic_lsm_path+0x271e>
    d35c:      	leaq	0x18(%r12), %rbx
    d361:      	movl	$0x4, %eax
    d366:      	movq	%rbp, %rdi
    d369:      	movl	$0x8, %esi
    d36e:      	movq	%rbx, %rdx
    d371:      	callq	*%rax
    d373:      	cmpq	%r12, (%rsp)
    d377:      	je	0xd44e <generic_lsm_path+0x271e>
    d37d:      	movl	$0x4, %eax
    d382:      	leaq	0x8(%rsp), %rdi
    d387:      	movl	$0x8, %esi
    d38c:      	movq	%rbx, %rdx
    d38f:      	callq	*%rax
    d391:      	addq	$0x20, %r12
    d395:      	movl	$0x4, %eax
    d39a:      	leaq	0x58(%rsp), %rdi
    d39f:      	movl	$0x10, %ecx
    d3a4:      	movl	$0x10, %esi
    d3a9:      	movq	%r12, %rdx
    d3ac:      	callq	*%rax
    d3ae:      	movq	0x28(%rsp), %rbx
    d3b3:      	movq	0x48(%rsp), %rax
    d3b8:      	movl	0x5c(%rsp), %r15d
    d3bd:      	subq	%rbx, %rax
    d3c0:      	movl	0x50(%rsp), %r12d
    d3c5:      	movl	%r15d, %edx
    d3c8:      	subl	%r12d, %edx
    d3cb:      	movl	$0x0, %ecx
    d3d0:      	cmovbl	%ecx, %edx
    d3d3:      	addq	0x60(%rsp), %rdx
    d3d8:      	xorl	%esi, %esi
    d3da:      	cmpl	%r15d, %r12d
    d3dd:      	seta	%sil
    d3e1:      	movl	%r15d, %ecx
    d3e4:      	cmovbl	%r12d, %ecx
    d3e8:      	addl	%ecx, %esi
    d3ea:      	movl	%r12d, %edi
    d3ed:      	subl	%esi, %edi
    d3ef:      	movl	%edi, 0x50(%rsp)
    d3f3:      	subq	%rsi, %rax
    d3f6:      	jb	0x167a2 <generic_lsm_path+0xba72>
    d3fc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d402:      	ja	0x167a2 <generic_lsm_path+0xba72>
    d408:      	cmpl	%r15d, %r12d
    d40b:      	jbe	0xd411 <generic_lsm_path+0x26e1>
    d40d:      	movb	$0x2f, (%rbx,%rax)
    d411:      	xorl	%edi, %edi
    d413:      	cmpl	%r15d, %r12d
    d416:      	seta	%dil
    d41a:      	movzbl	%cl, %esi
    d41d:      	addq	%rax, %rbx
    d420:      	addq	%rbx, %rdi
    d423:      	movl	$0x4, %eax
    d428:      	callq	*%rax
    d42a:      	movq	%rbx, 0x48(%rsp)
    d42f:      	cmpl	%r15d, %r12d
    d432:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    d438:      	movq	0x8(%rsp), %r12
    d43d:      	movq	%r12, 0x30(%rsp)
    d442:      	movq	0x38(%rsp), %rdx
    d447:      	movq	0x40(%rsp), %r15
    d44c:      	jmp	0xd49f <generic_lsm_path+0x276f>
    d44e:      	leaq	0x10(%r15), %rdx
    d452:      	movl	$0x4, %eax
    d457:      	movq	%rbp, %rdi
    d45a:      	movl	$0x8, %esi
    d45f:      	callq	*%rax
    d461:      	movq	0x40(%rsp), %rax
    d466:      	cmpq	(%rsp), %rax
    d46a:      	je	0x1679d <generic_lsm_path+0xba6d>
    d470:      	addq	$0x18, %r15
    d474:      	movl	$0x4, %eax
    d479:      	leaq	0x30(%rsp), %rdi
    d47e:      	movl	$0x8, %esi
    d483:      	movq	%r15, %rdx
    d486:      	callq	*%rax
    d488:      	movq	(%rsp), %r15
    d48c:      	movq	%r15, 0x40(%rsp)
    d491:      	leaq	0x20(%r15), %rdx
    d495:      	movq	%rdx, 0x38(%rsp)
    d49a:      	movq	0x30(%rsp), %r12
    d49f:      	cmpq	0x18(%rsp), %r12
    d4a4:      	jne	0xd4b1 <generic_lsm_path+0x2781>
    d4a6:      	cmpq	0x20(%rsp), %rdx
    d4ab:      	je	0x1679d <generic_lsm_path+0xba6d>
    d4b1:      	movl	$0x4, %eax
    d4b6:      	leaq	0x10(%rsp), %rdi
    d4bb:      	movl	$0x8, %esi
    d4c0:      	callq	*%rax
    d4c2:      	cmpq	0x10(%rsp), %r12
    d4c7:      	je	0xd5bf <generic_lsm_path+0x288f>
    d4cd:      	leaq	0x18(%r12), %rbx
    d4d2:      	movl	$0x4, %eax
    d4d7:      	movq	%rbp, %rdi
    d4da:      	movl	$0x8, %esi
    d4df:      	movq	%rbx, %rdx
    d4e2:      	callq	*%rax
    d4e4:      	cmpq	%r12, (%rsp)
    d4e8:      	je	0xd5bf <generic_lsm_path+0x288f>
    d4ee:      	movl	$0x4, %eax
    d4f3:      	leaq	0x8(%rsp), %rdi
    d4f8:      	movl	$0x8, %esi
    d4fd:      	movq	%rbx, %rdx
    d500:      	callq	*%rax
    d502:      	addq	$0x20, %r12
    d506:      	movl	$0x4, %eax
    d50b:      	leaq	0x58(%rsp), %rdi
    d510:      	movl	$0x10, %ecx
    d515:      	movl	$0x10, %esi
    d51a:      	movq	%r12, %rdx
    d51d:      	callq	*%rax
    d51f:      	movq	0x28(%rsp), %rbx
    d524:      	movq	0x48(%rsp), %rax
    d529:      	movl	0x5c(%rsp), %r15d
    d52e:      	subq	%rbx, %rax
    d531:      	movl	0x50(%rsp), %r12d
    d536:      	movl	%r15d, %edx
    d539:      	subl	%r12d, %edx
    d53c:      	movl	$0x0, %ecx
    d541:      	cmovbl	%ecx, %edx
    d544:      	addq	0x60(%rsp), %rdx
    d549:      	xorl	%esi, %esi
    d54b:      	cmpl	%r15d, %r12d
    d54e:      	seta	%sil
    d552:      	movl	%r15d, %ecx
    d555:      	cmovbl	%r12d, %ecx
    d559:      	addl	%ecx, %esi
    d55b:      	movl	%r12d, %edi
    d55e:      	subl	%esi, %edi
    d560:      	movl	%edi, 0x50(%rsp)
    d564:      	subq	%rsi, %rax
    d567:      	jb	0x167a2 <generic_lsm_path+0xba72>
    d56d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d573:      	ja	0x167a2 <generic_lsm_path+0xba72>
    d579:      	cmpl	%r15d, %r12d
    d57c:      	jbe	0xd582 <generic_lsm_path+0x2852>
    d57e:      	movb	$0x2f, (%rbx,%rax)
    d582:      	xorl	%edi, %edi
    d584:      	cmpl	%r15d, %r12d
    d587:      	seta	%dil
    d58b:      	movzbl	%cl, %esi
    d58e:      	addq	%rax, %rbx
    d591:      	addq	%rbx, %rdi
    d594:      	movl	$0x4, %eax
    d599:      	callq	*%rax
    d59b:      	movq	%rbx, 0x48(%rsp)
    d5a0:      	cmpl	%r15d, %r12d
    d5a3:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    d5a9:      	movq	0x8(%rsp), %r12
    d5ae:      	movq	%r12, 0x30(%rsp)
    d5b3:      	movq	0x38(%rsp), %rdx
    d5b8:      	movq	0x40(%rsp), %r15
    d5bd:      	jmp	0xd610 <generic_lsm_path+0x28e0>
    d5bf:      	leaq	0x10(%r15), %rdx
    d5c3:      	movl	$0x4, %eax
    d5c8:      	movq	%rbp, %rdi
    d5cb:      	movl	$0x8, %esi
    d5d0:      	callq	*%rax
    d5d2:      	movq	0x40(%rsp), %rax
    d5d7:      	cmpq	(%rsp), %rax
    d5db:      	je	0x1679d <generic_lsm_path+0xba6d>
    d5e1:      	addq	$0x18, %r15
    d5e5:      	movl	$0x4, %eax
    d5ea:      	leaq	0x30(%rsp), %rdi
    d5ef:      	movl	$0x8, %esi
    d5f4:      	movq	%r15, %rdx
    d5f7:      	callq	*%rax
    d5f9:      	movq	(%rsp), %r15
    d5fd:      	movq	%r15, 0x40(%rsp)
    d602:      	leaq	0x20(%r15), %rdx
    d606:      	movq	%rdx, 0x38(%rsp)
    d60b:      	movq	0x30(%rsp), %r12
    d610:      	cmpq	0x18(%rsp), %r12
    d615:      	jne	0xd622 <generic_lsm_path+0x28f2>
    d617:      	cmpq	0x20(%rsp), %rdx
    d61c:      	je	0x1679d <generic_lsm_path+0xba6d>
    d622:      	movl	$0x4, %eax
    d627:      	leaq	0x10(%rsp), %rdi
    d62c:      	movl	$0x8, %esi
    d631:      	callq	*%rax
    d633:      	cmpq	0x10(%rsp), %r12
    d638:      	je	0xd730 <generic_lsm_path+0x2a00>
    d63e:      	leaq	0x18(%r12), %rbx
    d643:      	movl	$0x4, %eax
    d648:      	movq	%rbp, %rdi
    d64b:      	movl	$0x8, %esi
    d650:      	movq	%rbx, %rdx
    d653:      	callq	*%rax
    d655:      	cmpq	%r12, (%rsp)
    d659:      	je	0xd730 <generic_lsm_path+0x2a00>
    d65f:      	movl	$0x4, %eax
    d664:      	leaq	0x8(%rsp), %rdi
    d669:      	movl	$0x8, %esi
    d66e:      	movq	%rbx, %rdx
    d671:      	callq	*%rax
    d673:      	addq	$0x20, %r12
    d677:      	movl	$0x4, %eax
    d67c:      	leaq	0x58(%rsp), %rdi
    d681:      	movl	$0x10, %ecx
    d686:      	movl	$0x10, %esi
    d68b:      	movq	%r12, %rdx
    d68e:      	callq	*%rax
    d690:      	movq	0x28(%rsp), %rbx
    d695:      	movq	0x48(%rsp), %rax
    d69a:      	movl	0x5c(%rsp), %r15d
    d69f:      	subq	%rbx, %rax
    d6a2:      	movl	0x50(%rsp), %r12d
    d6a7:      	movl	%r15d, %edx
    d6aa:      	subl	%r12d, %edx
    d6ad:      	movl	$0x0, %ecx
    d6b2:      	cmovbl	%ecx, %edx
    d6b5:      	addq	0x60(%rsp), %rdx
    d6ba:      	xorl	%esi, %esi
    d6bc:      	cmpl	%r15d, %r12d
    d6bf:      	seta	%sil
    d6c3:      	movl	%r15d, %ecx
    d6c6:      	cmovbl	%r12d, %ecx
    d6ca:      	addl	%ecx, %esi
    d6cc:      	movl	%r12d, %edi
    d6cf:      	subl	%esi, %edi
    d6d1:      	movl	%edi, 0x50(%rsp)
    d6d5:      	subq	%rsi, %rax
    d6d8:      	jb	0x167a2 <generic_lsm_path+0xba72>
    d6de:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d6e4:      	ja	0x167a2 <generic_lsm_path+0xba72>
    d6ea:      	cmpl	%r15d, %r12d
    d6ed:      	jbe	0xd6f3 <generic_lsm_path+0x29c3>
    d6ef:      	movb	$0x2f, (%rbx,%rax)
    d6f3:      	xorl	%edi, %edi
    d6f5:      	cmpl	%r15d, %r12d
    d6f8:      	seta	%dil
    d6fc:      	movzbl	%cl, %esi
    d6ff:      	addq	%rax, %rbx
    d702:      	addq	%rbx, %rdi
    d705:      	movl	$0x4, %eax
    d70a:      	callq	*%rax
    d70c:      	movq	%rbx, 0x48(%rsp)
    d711:      	cmpl	%r15d, %r12d
    d714:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    d71a:      	movq	0x8(%rsp), %r12
    d71f:      	movq	%r12, 0x30(%rsp)
    d724:      	movq	0x38(%rsp), %rdx
    d729:      	movq	0x40(%rsp), %r15
    d72e:      	jmp	0xd781 <generic_lsm_path+0x2a51>
    d730:      	leaq	0x10(%r15), %rdx
    d734:      	movl	$0x4, %eax
    d739:      	movq	%rbp, %rdi
    d73c:      	movl	$0x8, %esi
    d741:      	callq	*%rax
    d743:      	movq	0x40(%rsp), %rax
    d748:      	cmpq	(%rsp), %rax
    d74c:      	je	0x1679d <generic_lsm_path+0xba6d>
    d752:      	addq	$0x18, %r15
    d756:      	movl	$0x4, %eax
    d75b:      	leaq	0x30(%rsp), %rdi
    d760:      	movl	$0x8, %esi
    d765:      	movq	%r15, %rdx
    d768:      	callq	*%rax
    d76a:      	movq	(%rsp), %r15
    d76e:      	movq	%r15, 0x40(%rsp)
    d773:      	leaq	0x20(%r15), %rdx
    d777:      	movq	%rdx, 0x38(%rsp)
    d77c:      	movq	0x30(%rsp), %r12
    d781:      	cmpq	0x18(%rsp), %r12
    d786:      	jne	0xd793 <generic_lsm_path+0x2a63>
    d788:      	cmpq	0x20(%rsp), %rdx
    d78d:      	je	0x1679d <generic_lsm_path+0xba6d>
    d793:      	movl	$0x4, %eax
    d798:      	leaq	0x10(%rsp), %rdi
    d79d:      	movl	$0x8, %esi
    d7a2:      	callq	*%rax
    d7a4:      	cmpq	0x10(%rsp), %r12
    d7a9:      	je	0xd8a1 <generic_lsm_path+0x2b71>
    d7af:      	leaq	0x18(%r12), %rbx
    d7b4:      	movl	$0x4, %eax
    d7b9:      	movq	%rbp, %rdi
    d7bc:      	movl	$0x8, %esi
    d7c1:      	movq	%rbx, %rdx
    d7c4:      	callq	*%rax
    d7c6:      	cmpq	%r12, (%rsp)
    d7ca:      	je	0xd8a1 <generic_lsm_path+0x2b71>
    d7d0:      	movl	$0x4, %eax
    d7d5:      	leaq	0x8(%rsp), %rdi
    d7da:      	movl	$0x8, %esi
    d7df:      	movq	%rbx, %rdx
    d7e2:      	callq	*%rax
    d7e4:      	addq	$0x20, %r12
    d7e8:      	movl	$0x4, %eax
    d7ed:      	leaq	0x58(%rsp), %rdi
    d7f2:      	movl	$0x10, %ecx
    d7f7:      	movl	$0x10, %esi
    d7fc:      	movq	%r12, %rdx
    d7ff:      	callq	*%rax
    d801:      	movq	0x28(%rsp), %rbx
    d806:      	movq	0x48(%rsp), %rax
    d80b:      	movl	0x5c(%rsp), %r15d
    d810:      	subq	%rbx, %rax
    d813:      	movl	0x50(%rsp), %r12d
    d818:      	movl	%r15d, %edx
    d81b:      	subl	%r12d, %edx
    d81e:      	movl	$0x0, %ecx
    d823:      	cmovbl	%ecx, %edx
    d826:      	addq	0x60(%rsp), %rdx
    d82b:      	xorl	%esi, %esi
    d82d:      	cmpl	%r15d, %r12d
    d830:      	seta	%sil
    d834:      	movl	%r15d, %ecx
    d837:      	cmovbl	%r12d, %ecx
    d83b:      	addl	%ecx, %esi
    d83d:      	movl	%r12d, %edi
    d840:      	subl	%esi, %edi
    d842:      	movl	%edi, 0x50(%rsp)
    d846:      	subq	%rsi, %rax
    d849:      	jb	0x167a2 <generic_lsm_path+0xba72>
    d84f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d855:      	ja	0x167a2 <generic_lsm_path+0xba72>
    d85b:      	cmpl	%r15d, %r12d
    d85e:      	jbe	0xd864 <generic_lsm_path+0x2b34>
    d860:      	movb	$0x2f, (%rbx,%rax)
    d864:      	xorl	%edi, %edi
    d866:      	cmpl	%r15d, %r12d
    d869:      	seta	%dil
    d86d:      	movzbl	%cl, %esi
    d870:      	addq	%rax, %rbx
    d873:      	addq	%rbx, %rdi
    d876:      	movl	$0x4, %eax
    d87b:      	callq	*%rax
    d87d:      	movq	%rbx, 0x48(%rsp)
    d882:      	cmpl	%r15d, %r12d
    d885:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    d88b:      	movq	0x8(%rsp), %r12
    d890:      	movq	%r12, 0x30(%rsp)
    d895:      	movq	0x38(%rsp), %rdx
    d89a:      	movq	0x40(%rsp), %r15
    d89f:      	jmp	0xd8f2 <generic_lsm_path+0x2bc2>
    d8a1:      	leaq	0x10(%r15), %rdx
    d8a5:      	movl	$0x4, %eax
    d8aa:      	movq	%rbp, %rdi
    d8ad:      	movl	$0x8, %esi
    d8b2:      	callq	*%rax
    d8b4:      	movq	0x40(%rsp), %rax
    d8b9:      	cmpq	(%rsp), %rax
    d8bd:      	je	0x1679d <generic_lsm_path+0xba6d>
    d8c3:      	addq	$0x18, %r15
    d8c7:      	movl	$0x4, %eax
    d8cc:      	leaq	0x30(%rsp), %rdi
    d8d1:      	movl	$0x8, %esi
    d8d6:      	movq	%r15, %rdx
    d8d9:      	callq	*%rax
    d8db:      	movq	(%rsp), %r15
    d8df:      	movq	%r15, 0x40(%rsp)
    d8e4:      	leaq	0x20(%r15), %rdx
    d8e8:      	movq	%rdx, 0x38(%rsp)
    d8ed:      	movq	0x30(%rsp), %r12
    d8f2:      	cmpq	0x18(%rsp), %r12
    d8f7:      	jne	0xd904 <generic_lsm_path+0x2bd4>
    d8f9:      	cmpq	0x20(%rsp), %rdx
    d8fe:      	je	0x1679d <generic_lsm_path+0xba6d>
    d904:      	movl	$0x4, %eax
    d909:      	leaq	0x10(%rsp), %rdi
    d90e:      	movl	$0x8, %esi
    d913:      	callq	*%rax
    d915:      	cmpq	0x10(%rsp), %r12
    d91a:      	je	0xda12 <generic_lsm_path+0x2ce2>
    d920:      	leaq	0x18(%r12), %rbx
    d925:      	movl	$0x4, %eax
    d92a:      	movq	%rbp, %rdi
    d92d:      	movl	$0x8, %esi
    d932:      	movq	%rbx, %rdx
    d935:      	callq	*%rax
    d937:      	cmpq	%r12, (%rsp)
    d93b:      	je	0xda12 <generic_lsm_path+0x2ce2>
    d941:      	movl	$0x4, %eax
    d946:      	leaq	0x8(%rsp), %rdi
    d94b:      	movl	$0x8, %esi
    d950:      	movq	%rbx, %rdx
    d953:      	callq	*%rax
    d955:      	addq	$0x20, %r12
    d959:      	movl	$0x4, %eax
    d95e:      	leaq	0x58(%rsp), %rdi
    d963:      	movl	$0x10, %ecx
    d968:      	movl	$0x10, %esi
    d96d:      	movq	%r12, %rdx
    d970:      	callq	*%rax
    d972:      	movq	0x28(%rsp), %rbx
    d977:      	movq	0x48(%rsp), %rax
    d97c:      	movl	0x5c(%rsp), %r15d
    d981:      	subq	%rbx, %rax
    d984:      	movl	0x50(%rsp), %r12d
    d989:      	movl	%r15d, %edx
    d98c:      	subl	%r12d, %edx
    d98f:      	movl	$0x0, %ecx
    d994:      	cmovbl	%ecx, %edx
    d997:      	addq	0x60(%rsp), %rdx
    d99c:      	xorl	%esi, %esi
    d99e:      	cmpl	%r15d, %r12d
    d9a1:      	seta	%sil
    d9a5:      	movl	%r15d, %ecx
    d9a8:      	cmovbl	%r12d, %ecx
    d9ac:      	addl	%ecx, %esi
    d9ae:      	movl	%r12d, %edi
    d9b1:      	subl	%esi, %edi
    d9b3:      	movl	%edi, 0x50(%rsp)
    d9b7:      	subq	%rsi, %rax
    d9ba:      	jb	0x167a2 <generic_lsm_path+0xba72>
    d9c0:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d9c6:      	ja	0x167a2 <generic_lsm_path+0xba72>
    d9cc:      	cmpl	%r15d, %r12d
    d9cf:      	jbe	0xd9d5 <generic_lsm_path+0x2ca5>
    d9d1:      	movb	$0x2f, (%rbx,%rax)
    d9d5:      	xorl	%edi, %edi
    d9d7:      	cmpl	%r15d, %r12d
    d9da:      	seta	%dil
    d9de:      	movzbl	%cl, %esi
    d9e1:      	addq	%rax, %rbx
    d9e4:      	addq	%rbx, %rdi
    d9e7:      	movl	$0x4, %eax
    d9ec:      	callq	*%rax
    d9ee:      	movq	%rbx, 0x48(%rsp)
    d9f3:      	cmpl	%r15d, %r12d
    d9f6:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    d9fc:      	movq	0x8(%rsp), %r12
    da01:      	movq	%r12, 0x30(%rsp)
    da06:      	movq	0x38(%rsp), %rdx
    da0b:      	movq	0x40(%rsp), %r15
    da10:      	jmp	0xda63 <generic_lsm_path+0x2d33>
    da12:      	leaq	0x10(%r15), %rdx
    da16:      	movl	$0x4, %eax
    da1b:      	movq	%rbp, %rdi
    da1e:      	movl	$0x8, %esi
    da23:      	callq	*%rax
    da25:      	movq	0x40(%rsp), %rax
    da2a:      	cmpq	(%rsp), %rax
    da2e:      	je	0x1679d <generic_lsm_path+0xba6d>
    da34:      	addq	$0x18, %r15
    da38:      	movl	$0x4, %eax
    da3d:      	leaq	0x30(%rsp), %rdi
    da42:      	movl	$0x8, %esi
    da47:      	movq	%r15, %rdx
    da4a:      	callq	*%rax
    da4c:      	movq	(%rsp), %r15
    da50:      	movq	%r15, 0x40(%rsp)
    da55:      	leaq	0x20(%r15), %rdx
    da59:      	movq	%rdx, 0x38(%rsp)
    da5e:      	movq	0x30(%rsp), %r12
    da63:      	cmpq	0x18(%rsp), %r12
    da68:      	jne	0xda75 <generic_lsm_path+0x2d45>
    da6a:      	cmpq	0x20(%rsp), %rdx
    da6f:      	je	0x1679d <generic_lsm_path+0xba6d>
    da75:      	movl	$0x4, %eax
    da7a:      	leaq	0x10(%rsp), %rdi
    da7f:      	movl	$0x8, %esi
    da84:      	callq	*%rax
    da86:      	cmpq	0x10(%rsp), %r12
    da8b:      	je	0xdb83 <generic_lsm_path+0x2e53>
    da91:      	leaq	0x18(%r12), %rbx
    da96:      	movl	$0x4, %eax
    da9b:      	movq	%rbp, %rdi
    da9e:      	movl	$0x8, %esi
    daa3:      	movq	%rbx, %rdx
    daa6:      	callq	*%rax
    daa8:      	cmpq	%r12, (%rsp)
    daac:      	je	0xdb83 <generic_lsm_path+0x2e53>
    dab2:      	movl	$0x4, %eax
    dab7:      	leaq	0x8(%rsp), %rdi
    dabc:      	movl	$0x8, %esi
    dac1:      	movq	%rbx, %rdx
    dac4:      	callq	*%rax
    dac6:      	addq	$0x20, %r12
    daca:      	movl	$0x4, %eax
    dacf:      	leaq	0x58(%rsp), %rdi
    dad4:      	movl	$0x10, %ecx
    dad9:      	movl	$0x10, %esi
    dade:      	movq	%r12, %rdx
    dae1:      	callq	*%rax
    dae3:      	movq	0x28(%rsp), %rbx
    dae8:      	movq	0x48(%rsp), %rax
    daed:      	movl	0x5c(%rsp), %r15d
    daf2:      	subq	%rbx, %rax
    daf5:      	movl	0x50(%rsp), %r12d
    dafa:      	movl	%r15d, %edx
    dafd:      	subl	%r12d, %edx
    db00:      	movl	$0x0, %ecx
    db05:      	cmovbl	%ecx, %edx
    db08:      	addq	0x60(%rsp), %rdx
    db0d:      	xorl	%esi, %esi
    db0f:      	cmpl	%r15d, %r12d
    db12:      	seta	%sil
    db16:      	movl	%r15d, %ecx
    db19:      	cmovbl	%r12d, %ecx
    db1d:      	addl	%ecx, %esi
    db1f:      	movl	%r12d, %edi
    db22:      	subl	%esi, %edi
    db24:      	movl	%edi, 0x50(%rsp)
    db28:      	subq	%rsi, %rax
    db2b:      	jb	0x167a2 <generic_lsm_path+0xba72>
    db31:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    db37:      	ja	0x167a2 <generic_lsm_path+0xba72>
    db3d:      	cmpl	%r15d, %r12d
    db40:      	jbe	0xdb46 <generic_lsm_path+0x2e16>
    db42:      	movb	$0x2f, (%rbx,%rax)
    db46:      	xorl	%edi, %edi
    db48:      	cmpl	%r15d, %r12d
    db4b:      	seta	%dil
    db4f:      	movzbl	%cl, %esi
    db52:      	addq	%rax, %rbx
    db55:      	addq	%rbx, %rdi
    db58:      	movl	$0x4, %eax
    db5d:      	callq	*%rax
    db5f:      	movq	%rbx, 0x48(%rsp)
    db64:      	cmpl	%r15d, %r12d
    db67:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    db6d:      	movq	0x8(%rsp), %r12
    db72:      	movq	%r12, 0x30(%rsp)
    db77:      	movq	0x38(%rsp), %rdx
    db7c:      	movq	0x40(%rsp), %r15
    db81:      	jmp	0xdbd4 <generic_lsm_path+0x2ea4>
    db83:      	leaq	0x10(%r15), %rdx
    db87:      	movl	$0x4, %eax
    db8c:      	movq	%rbp, %rdi
    db8f:      	movl	$0x8, %esi
    db94:      	callq	*%rax
    db96:      	movq	0x40(%rsp), %rax
    db9b:      	cmpq	(%rsp), %rax
    db9f:      	je	0x1679d <generic_lsm_path+0xba6d>
    dba5:      	addq	$0x18, %r15
    dba9:      	movl	$0x4, %eax
    dbae:      	leaq	0x30(%rsp), %rdi
    dbb3:      	movl	$0x8, %esi
    dbb8:      	movq	%r15, %rdx
    dbbb:      	callq	*%rax
    dbbd:      	movq	(%rsp), %r15
    dbc1:      	movq	%r15, 0x40(%rsp)
    dbc6:      	leaq	0x20(%r15), %rdx
    dbca:      	movq	%rdx, 0x38(%rsp)
    dbcf:      	movq	0x30(%rsp), %r12
    dbd4:      	cmpq	0x18(%rsp), %r12
    dbd9:      	jne	0xdbe6 <generic_lsm_path+0x2eb6>
    dbdb:      	cmpq	0x20(%rsp), %rdx
    dbe0:      	je	0x1679d <generic_lsm_path+0xba6d>
    dbe6:      	movl	$0x4, %eax
    dbeb:      	leaq	0x10(%rsp), %rdi
    dbf0:      	movl	$0x8, %esi
    dbf5:      	callq	*%rax
    dbf7:      	cmpq	0x10(%rsp), %r12
    dbfc:      	je	0xdcf4 <generic_lsm_path+0x2fc4>
    dc02:      	leaq	0x18(%r12), %rbx
    dc07:      	movl	$0x4, %eax
    dc0c:      	movq	%rbp, %rdi
    dc0f:      	movl	$0x8, %esi
    dc14:      	movq	%rbx, %rdx
    dc17:      	callq	*%rax
    dc19:      	cmpq	%r12, (%rsp)
    dc1d:      	je	0xdcf4 <generic_lsm_path+0x2fc4>
    dc23:      	movl	$0x4, %eax
    dc28:      	leaq	0x8(%rsp), %rdi
    dc2d:      	movl	$0x8, %esi
    dc32:      	movq	%rbx, %rdx
    dc35:      	callq	*%rax
    dc37:      	addq	$0x20, %r12
    dc3b:      	movl	$0x4, %eax
    dc40:      	leaq	0x58(%rsp), %rdi
    dc45:      	movl	$0x10, %ecx
    dc4a:      	movl	$0x10, %esi
    dc4f:      	movq	%r12, %rdx
    dc52:      	callq	*%rax
    dc54:      	movq	0x28(%rsp), %rbx
    dc59:      	movq	0x48(%rsp), %rax
    dc5e:      	movl	0x5c(%rsp), %r15d
    dc63:      	subq	%rbx, %rax
    dc66:      	movl	0x50(%rsp), %r12d
    dc6b:      	movl	%r15d, %edx
    dc6e:      	subl	%r12d, %edx
    dc71:      	movl	$0x0, %ecx
    dc76:      	cmovbl	%ecx, %edx
    dc79:      	addq	0x60(%rsp), %rdx
    dc7e:      	xorl	%esi, %esi
    dc80:      	cmpl	%r15d, %r12d
    dc83:      	seta	%sil
    dc87:      	movl	%r15d, %ecx
    dc8a:      	cmovbl	%r12d, %ecx
    dc8e:      	addl	%ecx, %esi
    dc90:      	movl	%r12d, %edi
    dc93:      	subl	%esi, %edi
    dc95:      	movl	%edi, 0x50(%rsp)
    dc99:      	subq	%rsi, %rax
    dc9c:      	jb	0x167a2 <generic_lsm_path+0xba72>
    dca2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    dca8:      	ja	0x167a2 <generic_lsm_path+0xba72>
    dcae:      	cmpl	%r15d, %r12d
    dcb1:      	jbe	0xdcb7 <generic_lsm_path+0x2f87>
    dcb3:      	movb	$0x2f, (%rbx,%rax)
    dcb7:      	xorl	%edi, %edi
    dcb9:      	cmpl	%r15d, %r12d
    dcbc:      	seta	%dil
    dcc0:      	movzbl	%cl, %esi
    dcc3:      	addq	%rax, %rbx
    dcc6:      	addq	%rbx, %rdi
    dcc9:      	movl	$0x4, %eax
    dcce:      	callq	*%rax
    dcd0:      	movq	%rbx, 0x48(%rsp)
    dcd5:      	cmpl	%r15d, %r12d
    dcd8:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    dcde:      	movq	0x8(%rsp), %r12
    dce3:      	movq	%r12, 0x30(%rsp)
    dce8:      	movq	0x38(%rsp), %rdx
    dced:      	movq	0x40(%rsp), %r15
    dcf2:      	jmp	0xdd45 <generic_lsm_path+0x3015>
    dcf4:      	leaq	0x10(%r15), %rdx
    dcf8:      	movl	$0x4, %eax
    dcfd:      	movq	%rbp, %rdi
    dd00:      	movl	$0x8, %esi
    dd05:      	callq	*%rax
    dd07:      	movq	0x40(%rsp), %rax
    dd0c:      	cmpq	(%rsp), %rax
    dd10:      	je	0x1679d <generic_lsm_path+0xba6d>
    dd16:      	addq	$0x18, %r15
    dd1a:      	movl	$0x4, %eax
    dd1f:      	leaq	0x30(%rsp), %rdi
    dd24:      	movl	$0x8, %esi
    dd29:      	movq	%r15, %rdx
    dd2c:      	callq	*%rax
    dd2e:      	movq	(%rsp), %r15
    dd32:      	movq	%r15, 0x40(%rsp)
    dd37:      	leaq	0x20(%r15), %rdx
    dd3b:      	movq	%rdx, 0x38(%rsp)
    dd40:      	movq	0x30(%rsp), %r12
    dd45:      	cmpq	0x18(%rsp), %r12
    dd4a:      	jne	0xdd57 <generic_lsm_path+0x3027>
    dd4c:      	cmpq	0x20(%rsp), %rdx
    dd51:      	je	0x1679d <generic_lsm_path+0xba6d>
    dd57:      	movl	$0x4, %eax
    dd5c:      	leaq	0x10(%rsp), %rdi
    dd61:      	movl	$0x8, %esi
    dd66:      	callq	*%rax
    dd68:      	cmpq	0x10(%rsp), %r12
    dd6d:      	je	0xde65 <generic_lsm_path+0x3135>
    dd73:      	leaq	0x18(%r12), %rbx
    dd78:      	movl	$0x4, %eax
    dd7d:      	movq	%rbp, %rdi
    dd80:      	movl	$0x8, %esi
    dd85:      	movq	%rbx, %rdx
    dd88:      	callq	*%rax
    dd8a:      	cmpq	%r12, (%rsp)
    dd8e:      	je	0xde65 <generic_lsm_path+0x3135>
    dd94:      	movl	$0x4, %eax
    dd99:      	leaq	0x8(%rsp), %rdi
    dd9e:      	movl	$0x8, %esi
    dda3:      	movq	%rbx, %rdx
    dda6:      	callq	*%rax
    dda8:      	addq	$0x20, %r12
    ddac:      	movl	$0x4, %eax
    ddb1:      	leaq	0x58(%rsp), %rdi
    ddb6:      	movl	$0x10, %ecx
    ddbb:      	movl	$0x10, %esi
    ddc0:      	movq	%r12, %rdx
    ddc3:      	callq	*%rax
    ddc5:      	movq	0x28(%rsp), %rbx
    ddca:      	movq	0x48(%rsp), %rax
    ddcf:      	movl	0x5c(%rsp), %r15d
    ddd4:      	subq	%rbx, %rax
    ddd7:      	movl	0x50(%rsp), %r12d
    dddc:      	movl	%r15d, %edx
    dddf:      	subl	%r12d, %edx
    dde2:      	movl	$0x0, %ecx
    dde7:      	cmovbl	%ecx, %edx
    ddea:      	addq	0x60(%rsp), %rdx
    ddef:      	xorl	%esi, %esi
    ddf1:      	cmpl	%r15d, %r12d
    ddf4:      	seta	%sil
    ddf8:      	movl	%r15d, %ecx
    ddfb:      	cmovbl	%r12d, %ecx
    ddff:      	addl	%ecx, %esi
    de01:      	movl	%r12d, %edi
    de04:      	subl	%esi, %edi
    de06:      	movl	%edi, 0x50(%rsp)
    de0a:      	subq	%rsi, %rax
    de0d:      	jb	0x167a2 <generic_lsm_path+0xba72>
    de13:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    de19:      	ja	0x167a2 <generic_lsm_path+0xba72>
    de1f:      	cmpl	%r15d, %r12d
    de22:      	jbe	0xde28 <generic_lsm_path+0x30f8>
    de24:      	movb	$0x2f, (%rbx,%rax)
    de28:      	xorl	%edi, %edi
    de2a:      	cmpl	%r15d, %r12d
    de2d:      	seta	%dil
    de31:      	movzbl	%cl, %esi
    de34:      	addq	%rax, %rbx
    de37:      	addq	%rbx, %rdi
    de3a:      	movl	$0x4, %eax
    de3f:      	callq	*%rax
    de41:      	movq	%rbx, 0x48(%rsp)
    de46:      	cmpl	%r15d, %r12d
    de49:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    de4f:      	movq	0x8(%rsp), %r12
    de54:      	movq	%r12, 0x30(%rsp)
    de59:      	movq	0x38(%rsp), %rdx
    de5e:      	movq	0x40(%rsp), %r15
    de63:      	jmp	0xdeb6 <generic_lsm_path+0x3186>
    de65:      	leaq	0x10(%r15), %rdx
    de69:      	movl	$0x4, %eax
    de6e:      	movq	%rbp, %rdi
    de71:      	movl	$0x8, %esi
    de76:      	callq	*%rax
    de78:      	movq	0x40(%rsp), %rax
    de7d:      	cmpq	(%rsp), %rax
    de81:      	je	0x1679d <generic_lsm_path+0xba6d>
    de87:      	addq	$0x18, %r15
    de8b:      	movl	$0x4, %eax
    de90:      	leaq	0x30(%rsp), %rdi
    de95:      	movl	$0x8, %esi
    de9a:      	movq	%r15, %rdx
    de9d:      	callq	*%rax
    de9f:      	movq	(%rsp), %r15
    dea3:      	movq	%r15, 0x40(%rsp)
    dea8:      	leaq	0x20(%r15), %rdx
    deac:      	movq	%rdx, 0x38(%rsp)
    deb1:      	movq	0x30(%rsp), %r12
    deb6:      	cmpq	0x18(%rsp), %r12
    debb:      	jne	0xdec8 <generic_lsm_path+0x3198>
    debd:      	cmpq	0x20(%rsp), %rdx
    dec2:      	je	0x1679d <generic_lsm_path+0xba6d>
    dec8:      	movl	$0x4, %eax
    decd:      	leaq	0x10(%rsp), %rdi
    ded2:      	movl	$0x8, %esi
    ded7:      	callq	*%rax
    ded9:      	cmpq	0x10(%rsp), %r12
    dede:      	je	0xdfd6 <generic_lsm_path+0x32a6>
    dee4:      	leaq	0x18(%r12), %rbx
    dee9:      	movl	$0x4, %eax
    deee:      	movq	%rbp, %rdi
    def1:      	movl	$0x8, %esi
    def6:      	movq	%rbx, %rdx
    def9:      	callq	*%rax
    defb:      	cmpq	%r12, (%rsp)
    deff:      	je	0xdfd6 <generic_lsm_path+0x32a6>
    df05:      	movl	$0x4, %eax
    df0a:      	leaq	0x8(%rsp), %rdi
    df0f:      	movl	$0x8, %esi
    df14:      	movq	%rbx, %rdx
    df17:      	callq	*%rax
    df19:      	addq	$0x20, %r12
    df1d:      	movl	$0x4, %eax
    df22:      	leaq	0x58(%rsp), %rdi
    df27:      	movl	$0x10, %ecx
    df2c:      	movl	$0x10, %esi
    df31:      	movq	%r12, %rdx
    df34:      	callq	*%rax
    df36:      	movq	0x28(%rsp), %rbx
    df3b:      	movq	0x48(%rsp), %rax
    df40:      	movl	0x5c(%rsp), %r15d
    df45:      	subq	%rbx, %rax
    df48:      	movl	0x50(%rsp), %r12d
    df4d:      	movl	%r15d, %edx
    df50:      	subl	%r12d, %edx
    df53:      	movl	$0x0, %ecx
    df58:      	cmovbl	%ecx, %edx
    df5b:      	addq	0x60(%rsp), %rdx
    df60:      	xorl	%esi, %esi
    df62:      	cmpl	%r15d, %r12d
    df65:      	seta	%sil
    df69:      	movl	%r15d, %ecx
    df6c:      	cmovbl	%r12d, %ecx
    df70:      	addl	%ecx, %esi
    df72:      	movl	%r12d, %edi
    df75:      	subl	%esi, %edi
    df77:      	movl	%edi, 0x50(%rsp)
    df7b:      	subq	%rsi, %rax
    df7e:      	jb	0x167a2 <generic_lsm_path+0xba72>
    df84:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    df8a:      	ja	0x167a2 <generic_lsm_path+0xba72>
    df90:      	cmpl	%r15d, %r12d
    df93:      	jbe	0xdf99 <generic_lsm_path+0x3269>
    df95:      	movb	$0x2f, (%rbx,%rax)
    df99:      	xorl	%edi, %edi
    df9b:      	cmpl	%r15d, %r12d
    df9e:      	seta	%dil
    dfa2:      	movzbl	%cl, %esi
    dfa5:      	addq	%rax, %rbx
    dfa8:      	addq	%rbx, %rdi
    dfab:      	movl	$0x4, %eax
    dfb0:      	callq	*%rax
    dfb2:      	movq	%rbx, 0x48(%rsp)
    dfb7:      	cmpl	%r15d, %r12d
    dfba:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    dfc0:      	movq	0x8(%rsp), %r12
    dfc5:      	movq	%r12, 0x30(%rsp)
    dfca:      	movq	0x38(%rsp), %rdx
    dfcf:      	movq	0x40(%rsp), %r15
    dfd4:      	jmp	0xe027 <generic_lsm_path+0x32f7>
    dfd6:      	leaq	0x10(%r15), %rdx
    dfda:      	movl	$0x4, %eax
    dfdf:      	movq	%rbp, %rdi
    dfe2:      	movl	$0x8, %esi
    dfe7:      	callq	*%rax
    dfe9:      	movq	0x40(%rsp), %rax
    dfee:      	cmpq	(%rsp), %rax
    dff2:      	je	0x1679d <generic_lsm_path+0xba6d>
    dff8:      	addq	$0x18, %r15
    dffc:      	movl	$0x4, %eax
    e001:      	leaq	0x30(%rsp), %rdi
    e006:      	movl	$0x8, %esi
    e00b:      	movq	%r15, %rdx
    e00e:      	callq	*%rax
    e010:      	movq	(%rsp), %r15
    e014:      	movq	%r15, 0x40(%rsp)
    e019:      	leaq	0x20(%r15), %rdx
    e01d:      	movq	%rdx, 0x38(%rsp)
    e022:      	movq	0x30(%rsp), %r12
    e027:      	cmpq	0x18(%rsp), %r12
    e02c:      	jne	0xe039 <generic_lsm_path+0x3309>
    e02e:      	cmpq	0x20(%rsp), %rdx
    e033:      	je	0x1679d <generic_lsm_path+0xba6d>
    e039:      	movl	$0x4, %eax
    e03e:      	leaq	0x10(%rsp), %rdi
    e043:      	movl	$0x8, %esi
    e048:      	callq	*%rax
    e04a:      	cmpq	0x10(%rsp), %r12
    e04f:      	je	0xe147 <generic_lsm_path+0x3417>
    e055:      	leaq	0x18(%r12), %rbx
    e05a:      	movl	$0x4, %eax
    e05f:      	movq	%rbp, %rdi
    e062:      	movl	$0x8, %esi
    e067:      	movq	%rbx, %rdx
    e06a:      	callq	*%rax
    e06c:      	cmpq	%r12, (%rsp)
    e070:      	je	0xe147 <generic_lsm_path+0x3417>
    e076:      	movl	$0x4, %eax
    e07b:      	leaq	0x8(%rsp), %rdi
    e080:      	movl	$0x8, %esi
    e085:      	movq	%rbx, %rdx
    e088:      	callq	*%rax
    e08a:      	addq	$0x20, %r12
    e08e:      	movl	$0x4, %eax
    e093:      	leaq	0x58(%rsp), %rdi
    e098:      	movl	$0x10, %ecx
    e09d:      	movl	$0x10, %esi
    e0a2:      	movq	%r12, %rdx
    e0a5:      	callq	*%rax
    e0a7:      	movq	0x28(%rsp), %rbx
    e0ac:      	movq	0x48(%rsp), %rax
    e0b1:      	movl	0x5c(%rsp), %r15d
    e0b6:      	subq	%rbx, %rax
    e0b9:      	movl	0x50(%rsp), %r12d
    e0be:      	movl	%r15d, %edx
    e0c1:      	subl	%r12d, %edx
    e0c4:      	movl	$0x0, %ecx
    e0c9:      	cmovbl	%ecx, %edx
    e0cc:      	addq	0x60(%rsp), %rdx
    e0d1:      	xorl	%esi, %esi
    e0d3:      	cmpl	%r15d, %r12d
    e0d6:      	seta	%sil
    e0da:      	movl	%r15d, %ecx
    e0dd:      	cmovbl	%r12d, %ecx
    e0e1:      	addl	%ecx, %esi
    e0e3:      	movl	%r12d, %edi
    e0e6:      	subl	%esi, %edi
    e0e8:      	movl	%edi, 0x50(%rsp)
    e0ec:      	subq	%rsi, %rax
    e0ef:      	jb	0x167a2 <generic_lsm_path+0xba72>
    e0f5:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e0fb:      	ja	0x167a2 <generic_lsm_path+0xba72>
    e101:      	cmpl	%r15d, %r12d
    e104:      	jbe	0xe10a <generic_lsm_path+0x33da>
    e106:      	movb	$0x2f, (%rbx,%rax)
    e10a:      	xorl	%edi, %edi
    e10c:      	cmpl	%r15d, %r12d
    e10f:      	seta	%dil
    e113:      	movzbl	%cl, %esi
    e116:      	addq	%rax, %rbx
    e119:      	addq	%rbx, %rdi
    e11c:      	movl	$0x4, %eax
    e121:      	callq	*%rax
    e123:      	movq	%rbx, 0x48(%rsp)
    e128:      	cmpl	%r15d, %r12d
    e12b:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    e131:      	movq	0x8(%rsp), %r12
    e136:      	movq	%r12, 0x30(%rsp)
    e13b:      	movq	0x38(%rsp), %rdx
    e140:      	movq	0x40(%rsp), %r15
    e145:      	jmp	0xe198 <generic_lsm_path+0x3468>
    e147:      	leaq	0x10(%r15), %rdx
    e14b:      	movl	$0x4, %eax
    e150:      	movq	%rbp, %rdi
    e153:      	movl	$0x8, %esi
    e158:      	callq	*%rax
    e15a:      	movq	0x40(%rsp), %rax
    e15f:      	cmpq	(%rsp), %rax
    e163:      	je	0x1679d <generic_lsm_path+0xba6d>
    e169:      	addq	$0x18, %r15
    e16d:      	movl	$0x4, %eax
    e172:      	leaq	0x30(%rsp), %rdi
    e177:      	movl	$0x8, %esi
    e17c:      	movq	%r15, %rdx
    e17f:      	callq	*%rax
    e181:      	movq	(%rsp), %r15
    e185:      	movq	%r15, 0x40(%rsp)
    e18a:      	leaq	0x20(%r15), %rdx
    e18e:      	movq	%rdx, 0x38(%rsp)
    e193:      	movq	0x30(%rsp), %r12
    e198:      	cmpq	0x18(%rsp), %r12
    e19d:      	jne	0xe1aa <generic_lsm_path+0x347a>
    e19f:      	cmpq	0x20(%rsp), %rdx
    e1a4:      	je	0x1679d <generic_lsm_path+0xba6d>
    e1aa:      	movl	$0x4, %eax
    e1af:      	leaq	0x10(%rsp), %rdi
    e1b4:      	movl	$0x8, %esi
    e1b9:      	callq	*%rax
    e1bb:      	cmpq	0x10(%rsp), %r12
    e1c0:      	je	0xe2b8 <generic_lsm_path+0x3588>
    e1c6:      	leaq	0x18(%r12), %rbx
    e1cb:      	movl	$0x4, %eax
    e1d0:      	movq	%rbp, %rdi
    e1d3:      	movl	$0x8, %esi
    e1d8:      	movq	%rbx, %rdx
    e1db:      	callq	*%rax
    e1dd:      	cmpq	%r12, (%rsp)
    e1e1:      	je	0xe2b8 <generic_lsm_path+0x3588>
    e1e7:      	movl	$0x4, %eax
    e1ec:      	leaq	0x8(%rsp), %rdi
    e1f1:      	movl	$0x8, %esi
    e1f6:      	movq	%rbx, %rdx
    e1f9:      	callq	*%rax
    e1fb:      	addq	$0x20, %r12
    e1ff:      	movl	$0x4, %eax
    e204:      	leaq	0x58(%rsp), %rdi
    e209:      	movl	$0x10, %ecx
    e20e:      	movl	$0x10, %esi
    e213:      	movq	%r12, %rdx
    e216:      	callq	*%rax
    e218:      	movq	0x28(%rsp), %rbx
    e21d:      	movq	0x48(%rsp), %rax
    e222:      	movl	0x5c(%rsp), %r15d
    e227:      	subq	%rbx, %rax
    e22a:      	movl	0x50(%rsp), %r12d
    e22f:      	movl	%r15d, %edx
    e232:      	subl	%r12d, %edx
    e235:      	movl	$0x0, %ecx
    e23a:      	cmovbl	%ecx, %edx
    e23d:      	addq	0x60(%rsp), %rdx
    e242:      	xorl	%esi, %esi
    e244:      	cmpl	%r15d, %r12d
    e247:      	seta	%sil
    e24b:      	movl	%r15d, %ecx
    e24e:      	cmovbl	%r12d, %ecx
    e252:      	addl	%ecx, %esi
    e254:      	movl	%r12d, %edi
    e257:      	subl	%esi, %edi
    e259:      	movl	%edi, 0x50(%rsp)
    e25d:      	subq	%rsi, %rax
    e260:      	jb	0x167a2 <generic_lsm_path+0xba72>
    e266:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e26c:      	ja	0x167a2 <generic_lsm_path+0xba72>
    e272:      	cmpl	%r15d, %r12d
    e275:      	jbe	0xe27b <generic_lsm_path+0x354b>
    e277:      	movb	$0x2f, (%rbx,%rax)
    e27b:      	xorl	%edi, %edi
    e27d:      	cmpl	%r15d, %r12d
    e280:      	seta	%dil
    e284:      	movzbl	%cl, %esi
    e287:      	addq	%rax, %rbx
    e28a:      	addq	%rbx, %rdi
    e28d:      	movl	$0x4, %eax
    e292:      	callq	*%rax
    e294:      	movq	%rbx, 0x48(%rsp)
    e299:      	cmpl	%r15d, %r12d
    e29c:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    e2a2:      	movq	0x8(%rsp), %r12
    e2a7:      	movq	%r12, 0x30(%rsp)
    e2ac:      	movq	0x38(%rsp), %rdx
    e2b1:      	movq	0x40(%rsp), %r15
    e2b6:      	jmp	0xe309 <generic_lsm_path+0x35d9>
    e2b8:      	leaq	0x10(%r15), %rdx
    e2bc:      	movl	$0x4, %eax
    e2c1:      	movq	%rbp, %rdi
    e2c4:      	movl	$0x8, %esi
    e2c9:      	callq	*%rax
    e2cb:      	movq	0x40(%rsp), %rax
    e2d0:      	cmpq	(%rsp), %rax
    e2d4:      	je	0x1679d <generic_lsm_path+0xba6d>
    e2da:      	addq	$0x18, %r15
    e2de:      	movl	$0x4, %eax
    e2e3:      	leaq	0x30(%rsp), %rdi
    e2e8:      	movl	$0x8, %esi
    e2ed:      	movq	%r15, %rdx
    e2f0:      	callq	*%rax
    e2f2:      	movq	(%rsp), %r15
    e2f6:      	movq	%r15, 0x40(%rsp)
    e2fb:      	leaq	0x20(%r15), %rdx
    e2ff:      	movq	%rdx, 0x38(%rsp)
    e304:      	movq	0x30(%rsp), %r12
    e309:      	cmpq	0x18(%rsp), %r12
    e30e:      	jne	0xe31b <generic_lsm_path+0x35eb>
    e310:      	cmpq	0x20(%rsp), %rdx
    e315:      	je	0x1679d <generic_lsm_path+0xba6d>
    e31b:      	movl	$0x4, %eax
    e320:      	leaq	0x10(%rsp), %rdi
    e325:      	movl	$0x8, %esi
    e32a:      	callq	*%rax
    e32c:      	cmpq	0x10(%rsp), %r12
    e331:      	je	0xe429 <generic_lsm_path+0x36f9>
    e337:      	leaq	0x18(%r12), %rbx
    e33c:      	movl	$0x4, %eax
    e341:      	movq	%rbp, %rdi
    e344:      	movl	$0x8, %esi
    e349:      	movq	%rbx, %rdx
    e34c:      	callq	*%rax
    e34e:      	cmpq	%r12, (%rsp)
    e352:      	je	0xe429 <generic_lsm_path+0x36f9>
    e358:      	movl	$0x4, %eax
    e35d:      	leaq	0x8(%rsp), %rdi
    e362:      	movl	$0x8, %esi
    e367:      	movq	%rbx, %rdx
    e36a:      	callq	*%rax
    e36c:      	addq	$0x20, %r12
    e370:      	movl	$0x4, %eax
    e375:      	leaq	0x58(%rsp), %rdi
    e37a:      	movl	$0x10, %ecx
    e37f:      	movl	$0x10, %esi
    e384:      	movq	%r12, %rdx
    e387:      	callq	*%rax
    e389:      	movq	0x28(%rsp), %rbx
    e38e:      	movq	0x48(%rsp), %rax
    e393:      	movl	0x5c(%rsp), %r15d
    e398:      	subq	%rbx, %rax
    e39b:      	movl	0x50(%rsp), %r12d
    e3a0:      	movl	%r15d, %edx
    e3a3:      	subl	%r12d, %edx
    e3a6:      	movl	$0x0, %ecx
    e3ab:      	cmovbl	%ecx, %edx
    e3ae:      	addq	0x60(%rsp), %rdx
    e3b3:      	xorl	%esi, %esi
    e3b5:      	cmpl	%r15d, %r12d
    e3b8:      	seta	%sil
    e3bc:      	movl	%r15d, %ecx
    e3bf:      	cmovbl	%r12d, %ecx
    e3c3:      	addl	%ecx, %esi
    e3c5:      	movl	%r12d, %edi
    e3c8:      	subl	%esi, %edi
    e3ca:      	movl	%edi, 0x50(%rsp)
    e3ce:      	subq	%rsi, %rax
    e3d1:      	jb	0x167a2 <generic_lsm_path+0xba72>
    e3d7:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e3dd:      	ja	0x167a2 <generic_lsm_path+0xba72>
    e3e3:      	cmpl	%r15d, %r12d
    e3e6:      	jbe	0xe3ec <generic_lsm_path+0x36bc>
    e3e8:      	movb	$0x2f, (%rbx,%rax)
    e3ec:      	xorl	%edi, %edi
    e3ee:      	cmpl	%r15d, %r12d
    e3f1:      	seta	%dil
    e3f5:      	movzbl	%cl, %esi
    e3f8:      	addq	%rax, %rbx
    e3fb:      	addq	%rbx, %rdi
    e3fe:      	movl	$0x4, %eax
    e403:      	callq	*%rax
    e405:      	movq	%rbx, 0x48(%rsp)
    e40a:      	cmpl	%r15d, %r12d
    e40d:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    e413:      	movq	0x8(%rsp), %r12
    e418:      	movq	%r12, 0x30(%rsp)
    e41d:      	movq	0x38(%rsp), %rdx
    e422:      	movq	0x40(%rsp), %r15
    e427:      	jmp	0xe47a <generic_lsm_path+0x374a>
    e429:      	leaq	0x10(%r15), %rdx
    e42d:      	movl	$0x4, %eax
    e432:      	movq	%rbp, %rdi
    e435:      	movl	$0x8, %esi
    e43a:      	callq	*%rax
    e43c:      	movq	0x40(%rsp), %rax
    e441:      	cmpq	(%rsp), %rax
    e445:      	je	0x1679d <generic_lsm_path+0xba6d>
    e44b:      	addq	$0x18, %r15
    e44f:      	movl	$0x4, %eax
    e454:      	leaq	0x30(%rsp), %rdi
    e459:      	movl	$0x8, %esi
    e45e:      	movq	%r15, %rdx
    e461:      	callq	*%rax
    e463:      	movq	(%rsp), %r15
    e467:      	movq	%r15, 0x40(%rsp)
    e46c:      	leaq	0x20(%r15), %rdx
    e470:      	movq	%rdx, 0x38(%rsp)
    e475:      	movq	0x30(%rsp), %r12
    e47a:      	cmpq	0x18(%rsp), %r12
    e47f:      	jne	0xe48c <generic_lsm_path+0x375c>
    e481:      	cmpq	0x20(%rsp), %rdx
    e486:      	je	0x1679d <generic_lsm_path+0xba6d>
    e48c:      	movl	$0x4, %eax
    e491:      	leaq	0x10(%rsp), %rdi
    e496:      	movl	$0x8, %esi
    e49b:      	callq	*%rax
    e49d:      	cmpq	0x10(%rsp), %r12
    e4a2:      	je	0xe59a <generic_lsm_path+0x386a>
    e4a8:      	leaq	0x18(%r12), %rbx
    e4ad:      	movl	$0x4, %eax
    e4b2:      	movq	%rbp, %rdi
    e4b5:      	movl	$0x8, %esi
    e4ba:      	movq	%rbx, %rdx
    e4bd:      	callq	*%rax
    e4bf:      	cmpq	%r12, (%rsp)
    e4c3:      	je	0xe59a <generic_lsm_path+0x386a>
    e4c9:      	movl	$0x4, %eax
    e4ce:      	leaq	0x8(%rsp), %rdi
    e4d3:      	movl	$0x8, %esi
    e4d8:      	movq	%rbx, %rdx
    e4db:      	callq	*%rax
    e4dd:      	addq	$0x20, %r12
    e4e1:      	movl	$0x4, %eax
    e4e6:      	leaq	0x58(%rsp), %rdi
    e4eb:      	movl	$0x10, %ecx
    e4f0:      	movl	$0x10, %esi
    e4f5:      	movq	%r12, %rdx
    e4f8:      	callq	*%rax
    e4fa:      	movq	0x28(%rsp), %rbx
    e4ff:      	movq	0x48(%rsp), %rax
    e504:      	movl	0x5c(%rsp), %r15d
    e509:      	subq	%rbx, %rax
    e50c:      	movl	0x50(%rsp), %r12d
    e511:      	movl	%r15d, %edx
    e514:      	subl	%r12d, %edx
    e517:      	movl	$0x0, %ecx
    e51c:      	cmovbl	%ecx, %edx
    e51f:      	addq	0x60(%rsp), %rdx
    e524:      	xorl	%esi, %esi
    e526:      	cmpl	%r15d, %r12d
    e529:      	seta	%sil
    e52d:      	movl	%r15d, %ecx
    e530:      	cmovbl	%r12d, %ecx
    e534:      	addl	%ecx, %esi
    e536:      	movl	%r12d, %edi
    e539:      	subl	%esi, %edi
    e53b:      	movl	%edi, 0x50(%rsp)
    e53f:      	subq	%rsi, %rax
    e542:      	jb	0x167a2 <generic_lsm_path+0xba72>
    e548:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e54e:      	ja	0x167a2 <generic_lsm_path+0xba72>
    e554:      	cmpl	%r15d, %r12d
    e557:      	jbe	0xe55d <generic_lsm_path+0x382d>
    e559:      	movb	$0x2f, (%rbx,%rax)
    e55d:      	xorl	%edi, %edi
    e55f:      	cmpl	%r15d, %r12d
    e562:      	seta	%dil
    e566:      	movzbl	%cl, %esi
    e569:      	addq	%rax, %rbx
    e56c:      	addq	%rbx, %rdi
    e56f:      	movl	$0x4, %eax
    e574:      	callq	*%rax
    e576:      	movq	%rbx, 0x48(%rsp)
    e57b:      	cmpl	%r15d, %r12d
    e57e:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    e584:      	movq	0x8(%rsp), %r12
    e589:      	movq	%r12, 0x30(%rsp)
    e58e:      	movq	0x38(%rsp), %rdx
    e593:      	movq	0x40(%rsp), %r15
    e598:      	jmp	0xe5eb <generic_lsm_path+0x38bb>
    e59a:      	leaq	0x10(%r15), %rdx
    e59e:      	movl	$0x4, %eax
    e5a3:      	movq	%rbp, %rdi
    e5a6:      	movl	$0x8, %esi
    e5ab:      	callq	*%rax
    e5ad:      	movq	0x40(%rsp), %rax
    e5b2:      	cmpq	(%rsp), %rax
    e5b6:      	je	0x1679d <generic_lsm_path+0xba6d>
    e5bc:      	addq	$0x18, %r15
    e5c0:      	movl	$0x4, %eax
    e5c5:      	leaq	0x30(%rsp), %rdi
    e5ca:      	movl	$0x8, %esi
    e5cf:      	movq	%r15, %rdx
    e5d2:      	callq	*%rax
    e5d4:      	movq	(%rsp), %r15
    e5d8:      	movq	%r15, 0x40(%rsp)
    e5dd:      	leaq	0x20(%r15), %rdx
    e5e1:      	movq	%rdx, 0x38(%rsp)
    e5e6:      	movq	0x30(%rsp), %r12
    e5eb:      	cmpq	0x18(%rsp), %r12
    e5f0:      	jne	0xe5fd <generic_lsm_path+0x38cd>
    e5f2:      	cmpq	0x20(%rsp), %rdx
    e5f7:      	je	0x1679d <generic_lsm_path+0xba6d>
    e5fd:      	movl	$0x4, %eax
    e602:      	leaq	0x10(%rsp), %rdi
    e607:      	movl	$0x8, %esi
    e60c:      	callq	*%rax
    e60e:      	cmpq	0x10(%rsp), %r12
    e613:      	je	0xe70b <generic_lsm_path+0x39db>
    e619:      	leaq	0x18(%r12), %rbx
    e61e:      	movl	$0x4, %eax
    e623:      	movq	%rbp, %rdi
    e626:      	movl	$0x8, %esi
    e62b:      	movq	%rbx, %rdx
    e62e:      	callq	*%rax
    e630:      	cmpq	%r12, (%rsp)
    e634:      	je	0xe70b <generic_lsm_path+0x39db>
    e63a:      	movl	$0x4, %eax
    e63f:      	leaq	0x8(%rsp), %rdi
    e644:      	movl	$0x8, %esi
    e649:      	movq	%rbx, %rdx
    e64c:      	callq	*%rax
    e64e:      	addq	$0x20, %r12
    e652:      	movl	$0x4, %eax
    e657:      	leaq	0x58(%rsp), %rdi
    e65c:      	movl	$0x10, %ecx
    e661:      	movl	$0x10, %esi
    e666:      	movq	%r12, %rdx
    e669:      	callq	*%rax
    e66b:      	movq	0x28(%rsp), %rbx
    e670:      	movq	0x48(%rsp), %rax
    e675:      	movl	0x5c(%rsp), %r15d
    e67a:      	subq	%rbx, %rax
    e67d:      	movl	0x50(%rsp), %r12d
    e682:      	movl	%r15d, %edx
    e685:      	subl	%r12d, %edx
    e688:      	movl	$0x0, %ecx
    e68d:      	cmovbl	%ecx, %edx
    e690:      	addq	0x60(%rsp), %rdx
    e695:      	xorl	%esi, %esi
    e697:      	cmpl	%r15d, %r12d
    e69a:      	seta	%sil
    e69e:      	movl	%r15d, %ecx
    e6a1:      	cmovbl	%r12d, %ecx
    e6a5:      	addl	%ecx, %esi
    e6a7:      	movl	%r12d, %edi
    e6aa:      	subl	%esi, %edi
    e6ac:      	movl	%edi, 0x50(%rsp)
    e6b0:      	subq	%rsi, %rax
    e6b3:      	jb	0x167a2 <generic_lsm_path+0xba72>
    e6b9:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e6bf:      	ja	0x167a2 <generic_lsm_path+0xba72>
    e6c5:      	cmpl	%r15d, %r12d
    e6c8:      	jbe	0xe6ce <generic_lsm_path+0x399e>
    e6ca:      	movb	$0x2f, (%rbx,%rax)
    e6ce:      	xorl	%edi, %edi
    e6d0:      	cmpl	%r15d, %r12d
    e6d3:      	seta	%dil
    e6d7:      	movzbl	%cl, %esi
    e6da:      	addq	%rax, %rbx
    e6dd:      	addq	%rbx, %rdi
    e6e0:      	movl	$0x4, %eax
    e6e5:      	callq	*%rax
    e6e7:      	movq	%rbx, 0x48(%rsp)
    e6ec:      	cmpl	%r15d, %r12d
    e6ef:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    e6f5:      	movq	0x8(%rsp), %r12
    e6fa:      	movq	%r12, 0x30(%rsp)
    e6ff:      	movq	0x38(%rsp), %rdx
    e704:      	movq	0x40(%rsp), %r15
    e709:      	jmp	0xe75c <generic_lsm_path+0x3a2c>
    e70b:      	leaq	0x10(%r15), %rdx
    e70f:      	movl	$0x4, %eax
    e714:      	movq	%rbp, %rdi
    e717:      	movl	$0x8, %esi
    e71c:      	callq	*%rax
    e71e:      	movq	0x40(%rsp), %rax
    e723:      	cmpq	(%rsp), %rax
    e727:      	je	0x1679d <generic_lsm_path+0xba6d>
    e72d:      	addq	$0x18, %r15
    e731:      	movl	$0x4, %eax
    e736:      	leaq	0x30(%rsp), %rdi
    e73b:      	movl	$0x8, %esi
    e740:      	movq	%r15, %rdx
    e743:      	callq	*%rax
    e745:      	movq	(%rsp), %r15
    e749:      	movq	%r15, 0x40(%rsp)
    e74e:      	leaq	0x20(%r15), %rdx
    e752:      	movq	%rdx, 0x38(%rsp)
    e757:      	movq	0x30(%rsp), %r12
    e75c:      	cmpq	0x18(%rsp), %r12
    e761:      	jne	0xe76e <generic_lsm_path+0x3a3e>
    e763:      	cmpq	0x20(%rsp), %rdx
    e768:      	je	0x1679d <generic_lsm_path+0xba6d>
    e76e:      	movl	$0x4, %eax
    e773:      	leaq	0x10(%rsp), %rdi
    e778:      	movl	$0x8, %esi
    e77d:      	callq	*%rax
    e77f:      	cmpq	0x10(%rsp), %r12
    e784:      	je	0xe87c <generic_lsm_path+0x3b4c>
    e78a:      	leaq	0x18(%r12), %rbx
    e78f:      	movl	$0x4, %eax
    e794:      	movq	%rbp, %rdi
    e797:      	movl	$0x8, %esi
    e79c:      	movq	%rbx, %rdx
    e79f:      	callq	*%rax
    e7a1:      	cmpq	%r12, (%rsp)
    e7a5:      	je	0xe87c <generic_lsm_path+0x3b4c>
    e7ab:      	movl	$0x4, %eax
    e7b0:      	leaq	0x8(%rsp), %rdi
    e7b5:      	movl	$0x8, %esi
    e7ba:      	movq	%rbx, %rdx
    e7bd:      	callq	*%rax
    e7bf:      	addq	$0x20, %r12
    e7c3:      	movl	$0x4, %eax
    e7c8:      	leaq	0x58(%rsp), %rdi
    e7cd:      	movl	$0x10, %ecx
    e7d2:      	movl	$0x10, %esi
    e7d7:      	movq	%r12, %rdx
    e7da:      	callq	*%rax
    e7dc:      	movq	0x28(%rsp), %rbx
    e7e1:      	movq	0x48(%rsp), %rax
    e7e6:      	movl	0x5c(%rsp), %r15d
    e7eb:      	subq	%rbx, %rax
    e7ee:      	movl	0x50(%rsp), %r12d
    e7f3:      	movl	%r15d, %edx
    e7f6:      	subl	%r12d, %edx
    e7f9:      	movl	$0x0, %ecx
    e7fe:      	cmovbl	%ecx, %edx
    e801:      	addq	0x60(%rsp), %rdx
    e806:      	xorl	%esi, %esi
    e808:      	cmpl	%r15d, %r12d
    e80b:      	seta	%sil
    e80f:      	movl	%r15d, %ecx
    e812:      	cmovbl	%r12d, %ecx
    e816:      	addl	%ecx, %esi
    e818:      	movl	%r12d, %edi
    e81b:      	subl	%esi, %edi
    e81d:      	movl	%edi, 0x50(%rsp)
    e821:      	subq	%rsi, %rax
    e824:      	jb	0x167a2 <generic_lsm_path+0xba72>
    e82a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e830:      	ja	0x167a2 <generic_lsm_path+0xba72>
    e836:      	cmpl	%r15d, %r12d
    e839:      	jbe	0xe83f <generic_lsm_path+0x3b0f>
    e83b:      	movb	$0x2f, (%rbx,%rax)
    e83f:      	xorl	%edi, %edi
    e841:      	cmpl	%r15d, %r12d
    e844:      	seta	%dil
    e848:      	movzbl	%cl, %esi
    e84b:      	addq	%rax, %rbx
    e84e:      	addq	%rbx, %rdi
    e851:      	movl	$0x4, %eax
    e856:      	callq	*%rax
    e858:      	movq	%rbx, 0x48(%rsp)
    e85d:      	cmpl	%r15d, %r12d
    e860:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    e866:      	movq	0x8(%rsp), %r12
    e86b:      	movq	%r12, 0x30(%rsp)
    e870:      	movq	0x38(%rsp), %rdx
    e875:      	movq	0x40(%rsp), %r15
    e87a:      	jmp	0xe8cd <generic_lsm_path+0x3b9d>
    e87c:      	leaq	0x10(%r15), %rdx
    e880:      	movl	$0x4, %eax
    e885:      	movq	%rbp, %rdi
    e888:      	movl	$0x8, %esi
    e88d:      	callq	*%rax
    e88f:      	movq	0x40(%rsp), %rax
    e894:      	cmpq	(%rsp), %rax
    e898:      	je	0x1679d <generic_lsm_path+0xba6d>
    e89e:      	addq	$0x18, %r15
    e8a2:      	movl	$0x4, %eax
    e8a7:      	leaq	0x30(%rsp), %rdi
    e8ac:      	movl	$0x8, %esi
    e8b1:      	movq	%r15, %rdx
    e8b4:      	callq	*%rax
    e8b6:      	movq	(%rsp), %r15
    e8ba:      	movq	%r15, 0x40(%rsp)
    e8bf:      	leaq	0x20(%r15), %rdx
    e8c3:      	movq	%rdx, 0x38(%rsp)
    e8c8:      	movq	0x30(%rsp), %r12
    e8cd:      	cmpq	0x18(%rsp), %r12
    e8d2:      	jne	0xe8df <generic_lsm_path+0x3baf>
    e8d4:      	cmpq	0x20(%rsp), %rdx
    e8d9:      	je	0x1679d <generic_lsm_path+0xba6d>
    e8df:      	movl	$0x4, %eax
    e8e4:      	leaq	0x10(%rsp), %rdi
    e8e9:      	movl	$0x8, %esi
    e8ee:      	callq	*%rax
    e8f0:      	cmpq	0x10(%rsp), %r12
    e8f5:      	je	0xe9ed <generic_lsm_path+0x3cbd>
    e8fb:      	leaq	0x18(%r12), %rbx
    e900:      	movl	$0x4, %eax
    e905:      	movq	%rbp, %rdi
    e908:      	movl	$0x8, %esi
    e90d:      	movq	%rbx, %rdx
    e910:      	callq	*%rax
    e912:      	cmpq	%r12, (%rsp)
    e916:      	je	0xe9ed <generic_lsm_path+0x3cbd>
    e91c:      	movl	$0x4, %eax
    e921:      	leaq	0x8(%rsp), %rdi
    e926:      	movl	$0x8, %esi
    e92b:      	movq	%rbx, %rdx
    e92e:      	callq	*%rax
    e930:      	addq	$0x20, %r12
    e934:      	movl	$0x4, %eax
    e939:      	leaq	0x58(%rsp), %rdi
    e93e:      	movl	$0x10, %ecx
    e943:      	movl	$0x10, %esi
    e948:      	movq	%r12, %rdx
    e94b:      	callq	*%rax
    e94d:      	movq	0x28(%rsp), %rbx
    e952:      	movq	0x48(%rsp), %rax
    e957:      	movl	0x5c(%rsp), %r15d
    e95c:      	subq	%rbx, %rax
    e95f:      	movl	0x50(%rsp), %r12d
    e964:      	movl	%r15d, %edx
    e967:      	subl	%r12d, %edx
    e96a:      	movl	$0x0, %ecx
    e96f:      	cmovbl	%ecx, %edx
    e972:      	addq	0x60(%rsp), %rdx
    e977:      	xorl	%esi, %esi
    e979:      	cmpl	%r15d, %r12d
    e97c:      	seta	%sil
    e980:      	movl	%r15d, %ecx
    e983:      	cmovbl	%r12d, %ecx
    e987:      	addl	%ecx, %esi
    e989:      	movl	%r12d, %edi
    e98c:      	subl	%esi, %edi
    e98e:      	movl	%edi, 0x50(%rsp)
    e992:      	subq	%rsi, %rax
    e995:      	jb	0x167a2 <generic_lsm_path+0xba72>
    e99b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e9a1:      	ja	0x167a2 <generic_lsm_path+0xba72>
    e9a7:      	cmpl	%r15d, %r12d
    e9aa:      	jbe	0xe9b0 <generic_lsm_path+0x3c80>
    e9ac:      	movb	$0x2f, (%rbx,%rax)
    e9b0:      	xorl	%edi, %edi
    e9b2:      	cmpl	%r15d, %r12d
    e9b5:      	seta	%dil
    e9b9:      	movzbl	%cl, %esi
    e9bc:      	addq	%rax, %rbx
    e9bf:      	addq	%rbx, %rdi
    e9c2:      	movl	$0x4, %eax
    e9c7:      	callq	*%rax
    e9c9:      	movq	%rbx, 0x48(%rsp)
    e9ce:      	cmpl	%r15d, %r12d
    e9d1:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    e9d7:      	movq	0x8(%rsp), %r12
    e9dc:      	movq	%r12, 0x30(%rsp)
    e9e1:      	movq	0x38(%rsp), %rdx
    e9e6:      	movq	0x40(%rsp), %r15
    e9eb:      	jmp	0xea3e <generic_lsm_path+0x3d0e>
    e9ed:      	leaq	0x10(%r15), %rdx
    e9f1:      	movl	$0x4, %eax
    e9f6:      	movq	%rbp, %rdi
    e9f9:      	movl	$0x8, %esi
    e9fe:      	callq	*%rax
    ea00:      	movq	0x40(%rsp), %rax
    ea05:      	cmpq	(%rsp), %rax
    ea09:      	je	0x1679d <generic_lsm_path+0xba6d>
    ea0f:      	addq	$0x18, %r15
    ea13:      	movl	$0x4, %eax
    ea18:      	leaq	0x30(%rsp), %rdi
    ea1d:      	movl	$0x8, %esi
    ea22:      	movq	%r15, %rdx
    ea25:      	callq	*%rax
    ea27:      	movq	(%rsp), %r15
    ea2b:      	movq	%r15, 0x40(%rsp)
    ea30:      	leaq	0x20(%r15), %rdx
    ea34:      	movq	%rdx, 0x38(%rsp)
    ea39:      	movq	0x30(%rsp), %r12
    ea3e:      	cmpq	0x18(%rsp), %r12
    ea43:      	jne	0xea50 <generic_lsm_path+0x3d20>
    ea45:      	cmpq	0x20(%rsp), %rdx
    ea4a:      	je	0x1679d <generic_lsm_path+0xba6d>
    ea50:      	movl	$0x4, %eax
    ea55:      	leaq	0x10(%rsp), %rdi
    ea5a:      	movl	$0x8, %esi
    ea5f:      	callq	*%rax
    ea61:      	cmpq	0x10(%rsp), %r12
    ea66:      	je	0xeb5e <generic_lsm_path+0x3e2e>
    ea6c:      	leaq	0x18(%r12), %rbx
    ea71:      	movl	$0x4, %eax
    ea76:      	movq	%rbp, %rdi
    ea79:      	movl	$0x8, %esi
    ea7e:      	movq	%rbx, %rdx
    ea81:      	callq	*%rax
    ea83:      	cmpq	%r12, (%rsp)
    ea87:      	je	0xeb5e <generic_lsm_path+0x3e2e>
    ea8d:      	movl	$0x4, %eax
    ea92:      	leaq	0x8(%rsp), %rdi
    ea97:      	movl	$0x8, %esi
    ea9c:      	movq	%rbx, %rdx
    ea9f:      	callq	*%rax
    eaa1:      	addq	$0x20, %r12
    eaa5:      	movl	$0x4, %eax
    eaaa:      	leaq	0x58(%rsp), %rdi
    eaaf:      	movl	$0x10, %ecx
    eab4:      	movl	$0x10, %esi
    eab9:      	movq	%r12, %rdx
    eabc:      	callq	*%rax
    eabe:      	movq	0x28(%rsp), %rbx
    eac3:      	movq	0x48(%rsp), %rax
    eac8:      	movl	0x5c(%rsp), %r15d
    eacd:      	subq	%rbx, %rax
    ead0:      	movl	0x50(%rsp), %r12d
    ead5:      	movl	%r15d, %edx
    ead8:      	subl	%r12d, %edx
    eadb:      	movl	$0x0, %ecx
    eae0:      	cmovbl	%ecx, %edx
    eae3:      	addq	0x60(%rsp), %rdx
    eae8:      	xorl	%esi, %esi
    eaea:      	cmpl	%r15d, %r12d
    eaed:      	seta	%sil
    eaf1:      	movl	%r15d, %ecx
    eaf4:      	cmovbl	%r12d, %ecx
    eaf8:      	addl	%ecx, %esi
    eafa:      	movl	%r12d, %edi
    eafd:      	subl	%esi, %edi
    eaff:      	movl	%edi, 0x50(%rsp)
    eb03:      	subq	%rsi, %rax
    eb06:      	jb	0x167a2 <generic_lsm_path+0xba72>
    eb0c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    eb12:      	ja	0x167a2 <generic_lsm_path+0xba72>
    eb18:      	cmpl	%r15d, %r12d
    eb1b:      	jbe	0xeb21 <generic_lsm_path+0x3df1>
    eb1d:      	movb	$0x2f, (%rbx,%rax)
    eb21:      	xorl	%edi, %edi
    eb23:      	cmpl	%r15d, %r12d
    eb26:      	seta	%dil
    eb2a:      	movzbl	%cl, %esi
    eb2d:      	addq	%rax, %rbx
    eb30:      	addq	%rbx, %rdi
    eb33:      	movl	$0x4, %eax
    eb38:      	callq	*%rax
    eb3a:      	movq	%rbx, 0x48(%rsp)
    eb3f:      	cmpl	%r15d, %r12d
    eb42:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    eb48:      	movq	0x8(%rsp), %r12
    eb4d:      	movq	%r12, 0x30(%rsp)
    eb52:      	movq	0x38(%rsp), %rdx
    eb57:      	movq	0x40(%rsp), %r15
    eb5c:      	jmp	0xebaf <generic_lsm_path+0x3e7f>
    eb5e:      	leaq	0x10(%r15), %rdx
    eb62:      	movl	$0x4, %eax
    eb67:      	movq	%rbp, %rdi
    eb6a:      	movl	$0x8, %esi
    eb6f:      	callq	*%rax
    eb71:      	movq	0x40(%rsp), %rax
    eb76:      	cmpq	(%rsp), %rax
    eb7a:      	je	0x1679d <generic_lsm_path+0xba6d>
    eb80:      	addq	$0x18, %r15
    eb84:      	movl	$0x4, %eax
    eb89:      	leaq	0x30(%rsp), %rdi
    eb8e:      	movl	$0x8, %esi
    eb93:      	movq	%r15, %rdx
    eb96:      	callq	*%rax
    eb98:      	movq	(%rsp), %r15
    eb9c:      	movq	%r15, 0x40(%rsp)
    eba1:      	leaq	0x20(%r15), %rdx
    eba5:      	movq	%rdx, 0x38(%rsp)
    ebaa:      	movq	0x30(%rsp), %r12
    ebaf:      	cmpq	0x18(%rsp), %r12
    ebb4:      	jne	0xebc1 <generic_lsm_path+0x3e91>
    ebb6:      	cmpq	0x20(%rsp), %rdx
    ebbb:      	je	0x1679d <generic_lsm_path+0xba6d>
    ebc1:      	movl	$0x4, %eax
    ebc6:      	leaq	0x10(%rsp), %rdi
    ebcb:      	movl	$0x8, %esi
    ebd0:      	callq	*%rax
    ebd2:      	cmpq	0x10(%rsp), %r12
    ebd7:      	je	0xeccf <generic_lsm_path+0x3f9f>
    ebdd:      	leaq	0x18(%r12), %rbx
    ebe2:      	movl	$0x4, %eax
    ebe7:      	movq	%rbp, %rdi
    ebea:      	movl	$0x8, %esi
    ebef:      	movq	%rbx, %rdx
    ebf2:      	callq	*%rax
    ebf4:      	cmpq	%r12, (%rsp)
    ebf8:      	je	0xeccf <generic_lsm_path+0x3f9f>
    ebfe:      	movl	$0x4, %eax
    ec03:      	leaq	0x8(%rsp), %rdi
    ec08:      	movl	$0x8, %esi
    ec0d:      	movq	%rbx, %rdx
    ec10:      	callq	*%rax
    ec12:      	addq	$0x20, %r12
    ec16:      	movl	$0x4, %eax
    ec1b:      	leaq	0x58(%rsp), %rdi
    ec20:      	movl	$0x10, %ecx
    ec25:      	movl	$0x10, %esi
    ec2a:      	movq	%r12, %rdx
    ec2d:      	callq	*%rax
    ec2f:      	movq	0x28(%rsp), %rbx
    ec34:      	movq	0x48(%rsp), %rax
    ec39:      	movl	0x5c(%rsp), %r15d
    ec3e:      	subq	%rbx, %rax
    ec41:      	movl	0x50(%rsp), %r12d
    ec46:      	movl	%r15d, %edx
    ec49:      	subl	%r12d, %edx
    ec4c:      	movl	$0x0, %ecx
    ec51:      	cmovbl	%ecx, %edx
    ec54:      	addq	0x60(%rsp), %rdx
    ec59:      	xorl	%esi, %esi
    ec5b:      	cmpl	%r15d, %r12d
    ec5e:      	seta	%sil
    ec62:      	movl	%r15d, %ecx
    ec65:      	cmovbl	%r12d, %ecx
    ec69:      	addl	%ecx, %esi
    ec6b:      	movl	%r12d, %edi
    ec6e:      	subl	%esi, %edi
    ec70:      	movl	%edi, 0x50(%rsp)
    ec74:      	subq	%rsi, %rax
    ec77:      	jb	0x167a2 <generic_lsm_path+0xba72>
    ec7d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ec83:      	ja	0x167a2 <generic_lsm_path+0xba72>
    ec89:      	cmpl	%r15d, %r12d
    ec8c:      	jbe	0xec92 <generic_lsm_path+0x3f62>
    ec8e:      	movb	$0x2f, (%rbx,%rax)
    ec92:      	xorl	%edi, %edi
    ec94:      	cmpl	%r15d, %r12d
    ec97:      	seta	%dil
    ec9b:      	movzbl	%cl, %esi
    ec9e:      	addq	%rax, %rbx
    eca1:      	addq	%rbx, %rdi
    eca4:      	movl	$0x4, %eax
    eca9:      	callq	*%rax
    ecab:      	movq	%rbx, 0x48(%rsp)
    ecb0:      	cmpl	%r15d, %r12d
    ecb3:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    ecb9:      	movq	0x8(%rsp), %r12
    ecbe:      	movq	%r12, 0x30(%rsp)
    ecc3:      	movq	0x38(%rsp), %rdx
    ecc8:      	movq	0x40(%rsp), %r15
    eccd:      	jmp	0xed20 <generic_lsm_path+0x3ff0>
    eccf:      	leaq	0x10(%r15), %rdx
    ecd3:      	movl	$0x4, %eax
    ecd8:      	movq	%rbp, %rdi
    ecdb:      	movl	$0x8, %esi
    ece0:      	callq	*%rax
    ece2:      	movq	0x40(%rsp), %rax
    ece7:      	cmpq	(%rsp), %rax
    eceb:      	je	0x1679d <generic_lsm_path+0xba6d>
    ecf1:      	addq	$0x18, %r15
    ecf5:      	movl	$0x4, %eax
    ecfa:      	leaq	0x30(%rsp), %rdi
    ecff:      	movl	$0x8, %esi
    ed04:      	movq	%r15, %rdx
    ed07:      	callq	*%rax
    ed09:      	movq	(%rsp), %r15
    ed0d:      	movq	%r15, 0x40(%rsp)
    ed12:      	leaq	0x20(%r15), %rdx
    ed16:      	movq	%rdx, 0x38(%rsp)
    ed1b:      	movq	0x30(%rsp), %r12
    ed20:      	cmpq	0x18(%rsp), %r12
    ed25:      	jne	0xed32 <generic_lsm_path+0x4002>
    ed27:      	cmpq	0x20(%rsp), %rdx
    ed2c:      	je	0x1679d <generic_lsm_path+0xba6d>
    ed32:      	movl	$0x4, %eax
    ed37:      	leaq	0x10(%rsp), %rdi
    ed3c:      	movl	$0x8, %esi
    ed41:      	callq	*%rax
    ed43:      	cmpq	0x10(%rsp), %r12
    ed48:      	je	0xee40 <generic_lsm_path+0x4110>
    ed4e:      	leaq	0x18(%r12), %rbx
    ed53:      	movl	$0x4, %eax
    ed58:      	movq	%rbp, %rdi
    ed5b:      	movl	$0x8, %esi
    ed60:      	movq	%rbx, %rdx
    ed63:      	callq	*%rax
    ed65:      	cmpq	%r12, (%rsp)
    ed69:      	je	0xee40 <generic_lsm_path+0x4110>
    ed6f:      	movl	$0x4, %eax
    ed74:      	leaq	0x8(%rsp), %rdi
    ed79:      	movl	$0x8, %esi
    ed7e:      	movq	%rbx, %rdx
    ed81:      	callq	*%rax
    ed83:      	addq	$0x20, %r12
    ed87:      	movl	$0x4, %eax
    ed8c:      	leaq	0x58(%rsp), %rdi
    ed91:      	movl	$0x10, %ecx
    ed96:      	movl	$0x10, %esi
    ed9b:      	movq	%r12, %rdx
    ed9e:      	callq	*%rax
    eda0:      	movq	0x28(%rsp), %rbx
    eda5:      	movq	0x48(%rsp), %rax
    edaa:      	movl	0x5c(%rsp), %r15d
    edaf:      	subq	%rbx, %rax
    edb2:      	movl	0x50(%rsp), %r12d
    edb7:      	movl	%r15d, %edx
    edba:      	subl	%r12d, %edx
    edbd:      	movl	$0x0, %ecx
    edc2:      	cmovbl	%ecx, %edx
    edc5:      	addq	0x60(%rsp), %rdx
    edca:      	xorl	%esi, %esi
    edcc:      	cmpl	%r15d, %r12d
    edcf:      	seta	%sil
    edd3:      	movl	%r15d, %ecx
    edd6:      	cmovbl	%r12d, %ecx
    edda:      	addl	%ecx, %esi
    eddc:      	movl	%r12d, %edi
    eddf:      	subl	%esi, %edi
    ede1:      	movl	%edi, 0x50(%rsp)
    ede5:      	subq	%rsi, %rax
    ede8:      	jb	0x167a2 <generic_lsm_path+0xba72>
    edee:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    edf4:      	ja	0x167a2 <generic_lsm_path+0xba72>
    edfa:      	cmpl	%r15d, %r12d
    edfd:      	jbe	0xee03 <generic_lsm_path+0x40d3>
    edff:      	movb	$0x2f, (%rbx,%rax)
    ee03:      	xorl	%edi, %edi
    ee05:      	cmpl	%r15d, %r12d
    ee08:      	seta	%dil
    ee0c:      	movzbl	%cl, %esi
    ee0f:      	addq	%rax, %rbx
    ee12:      	addq	%rbx, %rdi
    ee15:      	movl	$0x4, %eax
    ee1a:      	callq	*%rax
    ee1c:      	movq	%rbx, 0x48(%rsp)
    ee21:      	cmpl	%r15d, %r12d
    ee24:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    ee2a:      	movq	0x8(%rsp), %r12
    ee2f:      	movq	%r12, 0x30(%rsp)
    ee34:      	movq	0x38(%rsp), %rdx
    ee39:      	movq	0x40(%rsp), %r15
    ee3e:      	jmp	0xee91 <generic_lsm_path+0x4161>
    ee40:      	leaq	0x10(%r15), %rdx
    ee44:      	movl	$0x4, %eax
    ee49:      	movq	%rbp, %rdi
    ee4c:      	movl	$0x8, %esi
    ee51:      	callq	*%rax
    ee53:      	movq	0x40(%rsp), %rax
    ee58:      	cmpq	(%rsp), %rax
    ee5c:      	je	0x1679d <generic_lsm_path+0xba6d>
    ee62:      	addq	$0x18, %r15
    ee66:      	movl	$0x4, %eax
    ee6b:      	leaq	0x30(%rsp), %rdi
    ee70:      	movl	$0x8, %esi
    ee75:      	movq	%r15, %rdx
    ee78:      	callq	*%rax
    ee7a:      	movq	(%rsp), %r15
    ee7e:      	movq	%r15, 0x40(%rsp)
    ee83:      	leaq	0x20(%r15), %rdx
    ee87:      	movq	%rdx, 0x38(%rsp)
    ee8c:      	movq	0x30(%rsp), %r12
    ee91:      	cmpq	0x18(%rsp), %r12
    ee96:      	jne	0xeea3 <generic_lsm_path+0x4173>
    ee98:      	cmpq	0x20(%rsp), %rdx
    ee9d:      	je	0x1679d <generic_lsm_path+0xba6d>
    eea3:      	movl	$0x4, %eax
    eea8:      	leaq	0x10(%rsp), %rdi
    eead:      	movl	$0x8, %esi
    eeb2:      	callq	*%rax
    eeb4:      	cmpq	0x10(%rsp), %r12
    eeb9:      	je	0xefb1 <generic_lsm_path+0x4281>
    eebf:      	leaq	0x18(%r12), %rbx
    eec4:      	movl	$0x4, %eax
    eec9:      	movq	%rbp, %rdi
    eecc:      	movl	$0x8, %esi
    eed1:      	movq	%rbx, %rdx
    eed4:      	callq	*%rax
    eed6:      	cmpq	%r12, (%rsp)
    eeda:      	je	0xefb1 <generic_lsm_path+0x4281>
    eee0:      	movl	$0x4, %eax
    eee5:      	leaq	0x8(%rsp), %rdi
    eeea:      	movl	$0x8, %esi
    eeef:      	movq	%rbx, %rdx
    eef2:      	callq	*%rax
    eef4:      	addq	$0x20, %r12
    eef8:      	movl	$0x4, %eax
    eefd:      	leaq	0x58(%rsp), %rdi
    ef02:      	movl	$0x10, %ecx
    ef07:      	movl	$0x10, %esi
    ef0c:      	movq	%r12, %rdx
    ef0f:      	callq	*%rax
    ef11:      	movq	0x28(%rsp), %rbx
    ef16:      	movq	0x48(%rsp), %rax
    ef1b:      	movl	0x5c(%rsp), %r15d
    ef20:      	subq	%rbx, %rax
    ef23:      	movl	0x50(%rsp), %r12d
    ef28:      	movl	%r15d, %edx
    ef2b:      	subl	%r12d, %edx
    ef2e:      	movl	$0x0, %ecx
    ef33:      	cmovbl	%ecx, %edx
    ef36:      	addq	0x60(%rsp), %rdx
    ef3b:      	xorl	%esi, %esi
    ef3d:      	cmpl	%r15d, %r12d
    ef40:      	seta	%sil
    ef44:      	movl	%r15d, %ecx
    ef47:      	cmovbl	%r12d, %ecx
    ef4b:      	addl	%ecx, %esi
    ef4d:      	movl	%r12d, %edi
    ef50:      	subl	%esi, %edi
    ef52:      	movl	%edi, 0x50(%rsp)
    ef56:      	subq	%rsi, %rax
    ef59:      	jb	0x167a2 <generic_lsm_path+0xba72>
    ef5f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ef65:      	ja	0x167a2 <generic_lsm_path+0xba72>
    ef6b:      	cmpl	%r15d, %r12d
    ef6e:      	jbe	0xef74 <generic_lsm_path+0x4244>
    ef70:      	movb	$0x2f, (%rbx,%rax)
    ef74:      	xorl	%edi, %edi
    ef76:      	cmpl	%r15d, %r12d
    ef79:      	seta	%dil
    ef7d:      	movzbl	%cl, %esi
    ef80:      	addq	%rax, %rbx
    ef83:      	addq	%rbx, %rdi
    ef86:      	movl	$0x4, %eax
    ef8b:      	callq	*%rax
    ef8d:      	movq	%rbx, 0x48(%rsp)
    ef92:      	cmpl	%r15d, %r12d
    ef95:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    ef9b:      	movq	0x8(%rsp), %r12
    efa0:      	movq	%r12, 0x30(%rsp)
    efa5:      	movq	0x38(%rsp), %rdx
    efaa:      	movq	0x40(%rsp), %r15
    efaf:      	jmp	0xf002 <generic_lsm_path+0x42d2>
    efb1:      	leaq	0x10(%r15), %rdx
    efb5:      	movl	$0x4, %eax
    efba:      	movq	%rbp, %rdi
    efbd:      	movl	$0x8, %esi
    efc2:      	callq	*%rax
    efc4:      	movq	0x40(%rsp), %rax
    efc9:      	cmpq	(%rsp), %rax
    efcd:      	je	0x1679d <generic_lsm_path+0xba6d>
    efd3:      	addq	$0x18, %r15
    efd7:      	movl	$0x4, %eax
    efdc:      	leaq	0x30(%rsp), %rdi
    efe1:      	movl	$0x8, %esi
    efe6:      	movq	%r15, %rdx
    efe9:      	callq	*%rax
    efeb:      	movq	(%rsp), %r15
    efef:      	movq	%r15, 0x40(%rsp)
    eff4:      	leaq	0x20(%r15), %rdx
    eff8:      	movq	%rdx, 0x38(%rsp)
    effd:      	movq	0x30(%rsp), %r12
    f002:      	cmpq	0x18(%rsp), %r12
    f007:      	jne	0xf014 <generic_lsm_path+0x42e4>
    f009:      	cmpq	0x20(%rsp), %rdx
    f00e:      	je	0x1679d <generic_lsm_path+0xba6d>
    f014:      	movl	$0x4, %eax
    f019:      	leaq	0x10(%rsp), %rdi
    f01e:      	movl	$0x8, %esi
    f023:      	callq	*%rax
    f025:      	cmpq	0x10(%rsp), %r12
    f02a:      	je	0xf122 <generic_lsm_path+0x43f2>
    f030:      	leaq	0x18(%r12), %rbx
    f035:      	movl	$0x4, %eax
    f03a:      	movq	%rbp, %rdi
    f03d:      	movl	$0x8, %esi
    f042:      	movq	%rbx, %rdx
    f045:      	callq	*%rax
    f047:      	cmpq	%r12, (%rsp)
    f04b:      	je	0xf122 <generic_lsm_path+0x43f2>
    f051:      	movl	$0x4, %eax
    f056:      	leaq	0x8(%rsp), %rdi
    f05b:      	movl	$0x8, %esi
    f060:      	movq	%rbx, %rdx
    f063:      	callq	*%rax
    f065:      	addq	$0x20, %r12
    f069:      	movl	$0x4, %eax
    f06e:      	leaq	0x58(%rsp), %rdi
    f073:      	movl	$0x10, %ecx
    f078:      	movl	$0x10, %esi
    f07d:      	movq	%r12, %rdx
    f080:      	callq	*%rax
    f082:      	movq	0x28(%rsp), %rbx
    f087:      	movq	0x48(%rsp), %rax
    f08c:      	movl	0x5c(%rsp), %r15d
    f091:      	subq	%rbx, %rax
    f094:      	movl	0x50(%rsp), %r12d
    f099:      	movl	%r15d, %edx
    f09c:      	subl	%r12d, %edx
    f09f:      	movl	$0x0, %ecx
    f0a4:      	cmovbl	%ecx, %edx
    f0a7:      	addq	0x60(%rsp), %rdx
    f0ac:      	xorl	%esi, %esi
    f0ae:      	cmpl	%r15d, %r12d
    f0b1:      	seta	%sil
    f0b5:      	movl	%r15d, %ecx
    f0b8:      	cmovbl	%r12d, %ecx
    f0bc:      	addl	%ecx, %esi
    f0be:      	movl	%r12d, %edi
    f0c1:      	subl	%esi, %edi
    f0c3:      	movl	%edi, 0x50(%rsp)
    f0c7:      	subq	%rsi, %rax
    f0ca:      	jb	0x167a2 <generic_lsm_path+0xba72>
    f0d0:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f0d6:      	ja	0x167a2 <generic_lsm_path+0xba72>
    f0dc:      	cmpl	%r15d, %r12d
    f0df:      	jbe	0xf0e5 <generic_lsm_path+0x43b5>
    f0e1:      	movb	$0x2f, (%rbx,%rax)
    f0e5:      	xorl	%edi, %edi
    f0e7:      	cmpl	%r15d, %r12d
    f0ea:      	seta	%dil
    f0ee:      	movzbl	%cl, %esi
    f0f1:      	addq	%rax, %rbx
    f0f4:      	addq	%rbx, %rdi
    f0f7:      	movl	$0x4, %eax
    f0fc:      	callq	*%rax
    f0fe:      	movq	%rbx, 0x48(%rsp)
    f103:      	cmpl	%r15d, %r12d
    f106:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    f10c:      	movq	0x8(%rsp), %r12
    f111:      	movq	%r12, 0x30(%rsp)
    f116:      	movq	0x38(%rsp), %rdx
    f11b:      	movq	0x40(%rsp), %r15
    f120:      	jmp	0xf173 <generic_lsm_path+0x4443>
    f122:      	leaq	0x10(%r15), %rdx
    f126:      	movl	$0x4, %eax
    f12b:      	movq	%rbp, %rdi
    f12e:      	movl	$0x8, %esi
    f133:      	callq	*%rax
    f135:      	movq	0x40(%rsp), %rax
    f13a:      	cmpq	(%rsp), %rax
    f13e:      	je	0x1679d <generic_lsm_path+0xba6d>
    f144:      	addq	$0x18, %r15
    f148:      	movl	$0x4, %eax
    f14d:      	leaq	0x30(%rsp), %rdi
    f152:      	movl	$0x8, %esi
    f157:      	movq	%r15, %rdx
    f15a:      	callq	*%rax
    f15c:      	movq	(%rsp), %r15
    f160:      	movq	%r15, 0x40(%rsp)
    f165:      	leaq	0x20(%r15), %rdx
    f169:      	movq	%rdx, 0x38(%rsp)
    f16e:      	movq	0x30(%rsp), %r12
    f173:      	cmpq	0x18(%rsp), %r12
    f178:      	jne	0xf185 <generic_lsm_path+0x4455>
    f17a:      	cmpq	0x20(%rsp), %rdx
    f17f:      	je	0x1679d <generic_lsm_path+0xba6d>
    f185:      	movl	$0x4, %eax
    f18a:      	leaq	0x10(%rsp), %rdi
    f18f:      	movl	$0x8, %esi
    f194:      	callq	*%rax
    f196:      	cmpq	0x10(%rsp), %r12
    f19b:      	je	0xf293 <generic_lsm_path+0x4563>
    f1a1:      	leaq	0x18(%r12), %rbx
    f1a6:      	movl	$0x4, %eax
    f1ab:      	movq	%rbp, %rdi
    f1ae:      	movl	$0x8, %esi
    f1b3:      	movq	%rbx, %rdx
    f1b6:      	callq	*%rax
    f1b8:      	cmpq	%r12, (%rsp)
    f1bc:      	je	0xf293 <generic_lsm_path+0x4563>
    f1c2:      	movl	$0x4, %eax
    f1c7:      	leaq	0x8(%rsp), %rdi
    f1cc:      	movl	$0x8, %esi
    f1d1:      	movq	%rbx, %rdx
    f1d4:      	callq	*%rax
    f1d6:      	addq	$0x20, %r12
    f1da:      	movl	$0x4, %eax
    f1df:      	leaq	0x58(%rsp), %rdi
    f1e4:      	movl	$0x10, %ecx
    f1e9:      	movl	$0x10, %esi
    f1ee:      	movq	%r12, %rdx
    f1f1:      	callq	*%rax
    f1f3:      	movq	0x28(%rsp), %rbx
    f1f8:      	movq	0x48(%rsp), %rax
    f1fd:      	movl	0x5c(%rsp), %r15d
    f202:      	subq	%rbx, %rax
    f205:      	movl	0x50(%rsp), %r12d
    f20a:      	movl	%r15d, %edx
    f20d:      	subl	%r12d, %edx
    f210:      	movl	$0x0, %ecx
    f215:      	cmovbl	%ecx, %edx
    f218:      	addq	0x60(%rsp), %rdx
    f21d:      	xorl	%esi, %esi
    f21f:      	cmpl	%r15d, %r12d
    f222:      	seta	%sil
    f226:      	movl	%r15d, %ecx
    f229:      	cmovbl	%r12d, %ecx
    f22d:      	addl	%ecx, %esi
    f22f:      	movl	%r12d, %edi
    f232:      	subl	%esi, %edi
    f234:      	movl	%edi, 0x50(%rsp)
    f238:      	subq	%rsi, %rax
    f23b:      	jb	0x167a2 <generic_lsm_path+0xba72>
    f241:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f247:      	ja	0x167a2 <generic_lsm_path+0xba72>
    f24d:      	cmpl	%r15d, %r12d
    f250:      	jbe	0xf256 <generic_lsm_path+0x4526>
    f252:      	movb	$0x2f, (%rbx,%rax)
    f256:      	xorl	%edi, %edi
    f258:      	cmpl	%r15d, %r12d
    f25b:      	seta	%dil
    f25f:      	movzbl	%cl, %esi
    f262:      	addq	%rax, %rbx
    f265:      	addq	%rbx, %rdi
    f268:      	movl	$0x4, %eax
    f26d:      	callq	*%rax
    f26f:      	movq	%rbx, 0x48(%rsp)
    f274:      	cmpl	%r15d, %r12d
    f277:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    f27d:      	movq	0x8(%rsp), %r12
    f282:      	movq	%r12, 0x30(%rsp)
    f287:      	movq	0x38(%rsp), %rdx
    f28c:      	movq	0x40(%rsp), %r15
    f291:      	jmp	0xf2e4 <generic_lsm_path+0x45b4>
    f293:      	leaq	0x10(%r15), %rdx
    f297:      	movl	$0x4, %eax
    f29c:      	movq	%rbp, %rdi
    f29f:      	movl	$0x8, %esi
    f2a4:      	callq	*%rax
    f2a6:      	movq	0x40(%rsp), %rax
    f2ab:      	cmpq	(%rsp), %rax
    f2af:      	je	0x1679d <generic_lsm_path+0xba6d>
    f2b5:      	addq	$0x18, %r15
    f2b9:      	movl	$0x4, %eax
    f2be:      	leaq	0x30(%rsp), %rdi
    f2c3:      	movl	$0x8, %esi
    f2c8:      	movq	%r15, %rdx
    f2cb:      	callq	*%rax
    f2cd:      	movq	(%rsp), %r15
    f2d1:      	movq	%r15, 0x40(%rsp)
    f2d6:      	leaq	0x20(%r15), %rdx
    f2da:      	movq	%rdx, 0x38(%rsp)
    f2df:      	movq	0x30(%rsp), %r12
    f2e4:      	cmpq	0x18(%rsp), %r12
    f2e9:      	jne	0xf2f6 <generic_lsm_path+0x45c6>
    f2eb:      	cmpq	0x20(%rsp), %rdx
    f2f0:      	je	0x1679d <generic_lsm_path+0xba6d>
    f2f6:      	movl	$0x4, %eax
    f2fb:      	leaq	0x10(%rsp), %rdi
    f300:      	movl	$0x8, %esi
    f305:      	callq	*%rax
    f307:      	cmpq	0x10(%rsp), %r12
    f30c:      	je	0xf404 <generic_lsm_path+0x46d4>
    f312:      	leaq	0x18(%r12), %rbx
    f317:      	movl	$0x4, %eax
    f31c:      	movq	%rbp, %rdi
    f31f:      	movl	$0x8, %esi
    f324:      	movq	%rbx, %rdx
    f327:      	callq	*%rax
    f329:      	cmpq	%r12, (%rsp)
    f32d:      	je	0xf404 <generic_lsm_path+0x46d4>
    f333:      	movl	$0x4, %eax
    f338:      	leaq	0x8(%rsp), %rdi
    f33d:      	movl	$0x8, %esi
    f342:      	movq	%rbx, %rdx
    f345:      	callq	*%rax
    f347:      	addq	$0x20, %r12
    f34b:      	movl	$0x4, %eax
    f350:      	leaq	0x58(%rsp), %rdi
    f355:      	movl	$0x10, %ecx
    f35a:      	movl	$0x10, %esi
    f35f:      	movq	%r12, %rdx
    f362:      	callq	*%rax
    f364:      	movq	0x28(%rsp), %rbx
    f369:      	movq	0x48(%rsp), %rax
    f36e:      	movl	0x5c(%rsp), %r15d
    f373:      	subq	%rbx, %rax
    f376:      	movl	0x50(%rsp), %r12d
    f37b:      	movl	%r15d, %edx
    f37e:      	subl	%r12d, %edx
    f381:      	movl	$0x0, %ecx
    f386:      	cmovbl	%ecx, %edx
    f389:      	addq	0x60(%rsp), %rdx
    f38e:      	xorl	%esi, %esi
    f390:      	cmpl	%r15d, %r12d
    f393:      	seta	%sil
    f397:      	movl	%r15d, %ecx
    f39a:      	cmovbl	%r12d, %ecx
    f39e:      	addl	%ecx, %esi
    f3a0:      	movl	%r12d, %edi
    f3a3:      	subl	%esi, %edi
    f3a5:      	movl	%edi, 0x50(%rsp)
    f3a9:      	subq	%rsi, %rax
    f3ac:      	jb	0x167a2 <generic_lsm_path+0xba72>
    f3b2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f3b8:      	ja	0x167a2 <generic_lsm_path+0xba72>
    f3be:      	cmpl	%r15d, %r12d
    f3c1:      	jbe	0xf3c7 <generic_lsm_path+0x4697>
    f3c3:      	movb	$0x2f, (%rbx,%rax)
    f3c7:      	xorl	%edi, %edi
    f3c9:      	cmpl	%r15d, %r12d
    f3cc:      	seta	%dil
    f3d0:      	movzbl	%cl, %esi
    f3d3:      	addq	%rax, %rbx
    f3d6:      	addq	%rbx, %rdi
    f3d9:      	movl	$0x4, %eax
    f3de:      	callq	*%rax
    f3e0:      	movq	%rbx, 0x48(%rsp)
    f3e5:      	cmpl	%r15d, %r12d
    f3e8:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    f3ee:      	movq	0x8(%rsp), %r12
    f3f3:      	movq	%r12, 0x30(%rsp)
    f3f8:      	movq	0x38(%rsp), %rdx
    f3fd:      	movq	0x40(%rsp), %r15
    f402:      	jmp	0xf455 <generic_lsm_path+0x4725>
    f404:      	leaq	0x10(%r15), %rdx
    f408:      	movl	$0x4, %eax
    f40d:      	movq	%rbp, %rdi
    f410:      	movl	$0x8, %esi
    f415:      	callq	*%rax
    f417:      	movq	0x40(%rsp), %rax
    f41c:      	cmpq	(%rsp), %rax
    f420:      	je	0x1679d <generic_lsm_path+0xba6d>
    f426:      	addq	$0x18, %r15
    f42a:      	movl	$0x4, %eax
    f42f:      	leaq	0x30(%rsp), %rdi
    f434:      	movl	$0x8, %esi
    f439:      	movq	%r15, %rdx
    f43c:      	callq	*%rax
    f43e:      	movq	(%rsp), %r15
    f442:      	movq	%r15, 0x40(%rsp)
    f447:      	leaq	0x20(%r15), %rdx
    f44b:      	movq	%rdx, 0x38(%rsp)
    f450:      	movq	0x30(%rsp), %r12
    f455:      	cmpq	0x18(%rsp), %r12
    f45a:      	jne	0xf467 <generic_lsm_path+0x4737>
    f45c:      	cmpq	0x20(%rsp), %rdx
    f461:      	je	0x1679d <generic_lsm_path+0xba6d>
    f467:      	movl	$0x4, %eax
    f46c:      	leaq	0x10(%rsp), %rdi
    f471:      	movl	$0x8, %esi
    f476:      	callq	*%rax
    f478:      	cmpq	0x10(%rsp), %r12
    f47d:      	je	0xf575 <generic_lsm_path+0x4845>
    f483:      	leaq	0x18(%r12), %rbx
    f488:      	movl	$0x4, %eax
    f48d:      	movq	%rbp, %rdi
    f490:      	movl	$0x8, %esi
    f495:      	movq	%rbx, %rdx
    f498:      	callq	*%rax
    f49a:      	cmpq	%r12, (%rsp)
    f49e:      	je	0xf575 <generic_lsm_path+0x4845>
    f4a4:      	movl	$0x4, %eax
    f4a9:      	leaq	0x8(%rsp), %rdi
    f4ae:      	movl	$0x8, %esi
    f4b3:      	movq	%rbx, %rdx
    f4b6:      	callq	*%rax
    f4b8:      	addq	$0x20, %r12
    f4bc:      	movl	$0x4, %eax
    f4c1:      	leaq	0x58(%rsp), %rdi
    f4c6:      	movl	$0x10, %ecx
    f4cb:      	movl	$0x10, %esi
    f4d0:      	movq	%r12, %rdx
    f4d3:      	callq	*%rax
    f4d5:      	movq	0x28(%rsp), %rbx
    f4da:      	movq	0x48(%rsp), %rax
    f4df:      	movl	0x5c(%rsp), %r15d
    f4e4:      	subq	%rbx, %rax
    f4e7:      	movl	0x50(%rsp), %r12d
    f4ec:      	movl	%r15d, %edx
    f4ef:      	subl	%r12d, %edx
    f4f2:      	movl	$0x0, %ecx
    f4f7:      	cmovbl	%ecx, %edx
    f4fa:      	addq	0x60(%rsp), %rdx
    f4ff:      	xorl	%esi, %esi
    f501:      	cmpl	%r15d, %r12d
    f504:      	seta	%sil
    f508:      	movl	%r15d, %ecx
    f50b:      	cmovbl	%r12d, %ecx
    f50f:      	addl	%ecx, %esi
    f511:      	movl	%r12d, %edi
    f514:      	subl	%esi, %edi
    f516:      	movl	%edi, 0x50(%rsp)
    f51a:      	subq	%rsi, %rax
    f51d:      	jb	0x167a2 <generic_lsm_path+0xba72>
    f523:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f529:      	ja	0x167a2 <generic_lsm_path+0xba72>
    f52f:      	cmpl	%r15d, %r12d
    f532:      	jbe	0xf538 <generic_lsm_path+0x4808>
    f534:      	movb	$0x2f, (%rbx,%rax)
    f538:      	xorl	%edi, %edi
    f53a:      	cmpl	%r15d, %r12d
    f53d:      	seta	%dil
    f541:      	movzbl	%cl, %esi
    f544:      	addq	%rax, %rbx
    f547:      	addq	%rbx, %rdi
    f54a:      	movl	$0x4, %eax
    f54f:      	callq	*%rax
    f551:      	movq	%rbx, 0x48(%rsp)
    f556:      	cmpl	%r15d, %r12d
    f559:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    f55f:      	movq	0x8(%rsp), %r12
    f564:      	movq	%r12, 0x30(%rsp)
    f569:      	movq	0x38(%rsp), %rdx
    f56e:      	movq	0x40(%rsp), %r15
    f573:      	jmp	0xf5c6 <generic_lsm_path+0x4896>
    f575:      	leaq	0x10(%r15), %rdx
    f579:      	movl	$0x4, %eax
    f57e:      	movq	%rbp, %rdi
    f581:      	movl	$0x8, %esi
    f586:      	callq	*%rax
    f588:      	movq	0x40(%rsp), %rax
    f58d:      	cmpq	(%rsp), %rax
    f591:      	je	0x1679d <generic_lsm_path+0xba6d>
    f597:      	addq	$0x18, %r15
    f59b:      	movl	$0x4, %eax
    f5a0:      	leaq	0x30(%rsp), %rdi
    f5a5:      	movl	$0x8, %esi
    f5aa:      	movq	%r15, %rdx
    f5ad:      	callq	*%rax
    f5af:      	movq	(%rsp), %r15
    f5b3:      	movq	%r15, 0x40(%rsp)
    f5b8:      	leaq	0x20(%r15), %rdx
    f5bc:      	movq	%rdx, 0x38(%rsp)
    f5c1:      	movq	0x30(%rsp), %r12
    f5c6:      	cmpq	0x18(%rsp), %r12
    f5cb:      	jne	0xf5d8 <generic_lsm_path+0x48a8>
    f5cd:      	cmpq	0x20(%rsp), %rdx
    f5d2:      	je	0x1679d <generic_lsm_path+0xba6d>
    f5d8:      	movl	$0x4, %eax
    f5dd:      	leaq	0x10(%rsp), %rdi
    f5e2:      	movl	$0x8, %esi
    f5e7:      	callq	*%rax
    f5e9:      	cmpq	0x10(%rsp), %r12
    f5ee:      	je	0xf6e6 <generic_lsm_path+0x49b6>
    f5f4:      	leaq	0x18(%r12), %rbx
    f5f9:      	movl	$0x4, %eax
    f5fe:      	movq	%rbp, %rdi
    f601:      	movl	$0x8, %esi
    f606:      	movq	%rbx, %rdx
    f609:      	callq	*%rax
    f60b:      	cmpq	%r12, (%rsp)
    f60f:      	je	0xf6e6 <generic_lsm_path+0x49b6>
    f615:      	movl	$0x4, %eax
    f61a:      	leaq	0x8(%rsp), %rdi
    f61f:      	movl	$0x8, %esi
    f624:      	movq	%rbx, %rdx
    f627:      	callq	*%rax
    f629:      	addq	$0x20, %r12
    f62d:      	movl	$0x4, %eax
    f632:      	leaq	0x58(%rsp), %rdi
    f637:      	movl	$0x10, %ecx
    f63c:      	movl	$0x10, %esi
    f641:      	movq	%r12, %rdx
    f644:      	callq	*%rax
    f646:      	movq	0x28(%rsp), %rbx
    f64b:      	movq	0x48(%rsp), %rax
    f650:      	movl	0x5c(%rsp), %r15d
    f655:      	subq	%rbx, %rax
    f658:      	movl	0x50(%rsp), %r12d
    f65d:      	movl	%r15d, %edx
    f660:      	subl	%r12d, %edx
    f663:      	movl	$0x0, %ecx
    f668:      	cmovbl	%ecx, %edx
    f66b:      	addq	0x60(%rsp), %rdx
    f670:      	xorl	%esi, %esi
    f672:      	cmpl	%r15d, %r12d
    f675:      	seta	%sil
    f679:      	movl	%r15d, %ecx
    f67c:      	cmovbl	%r12d, %ecx
    f680:      	addl	%ecx, %esi
    f682:      	movl	%r12d, %edi
    f685:      	subl	%esi, %edi
    f687:      	movl	%edi, 0x50(%rsp)
    f68b:      	subq	%rsi, %rax
    f68e:      	jb	0x167a2 <generic_lsm_path+0xba72>
    f694:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f69a:      	ja	0x167a2 <generic_lsm_path+0xba72>
    f6a0:      	cmpl	%r15d, %r12d
    f6a3:      	jbe	0xf6a9 <generic_lsm_path+0x4979>
    f6a5:      	movb	$0x2f, (%rbx,%rax)
    f6a9:      	xorl	%edi, %edi
    f6ab:      	cmpl	%r15d, %r12d
    f6ae:      	seta	%dil
    f6b2:      	movzbl	%cl, %esi
    f6b5:      	addq	%rax, %rbx
    f6b8:      	addq	%rbx, %rdi
    f6bb:      	movl	$0x4, %eax
    f6c0:      	callq	*%rax
    f6c2:      	movq	%rbx, 0x48(%rsp)
    f6c7:      	cmpl	%r15d, %r12d
    f6ca:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    f6d0:      	movq	0x8(%rsp), %r12
    f6d5:      	movq	%r12, 0x30(%rsp)
    f6da:      	movq	0x38(%rsp), %rdx
    f6df:      	movq	0x40(%rsp), %r15
    f6e4:      	jmp	0xf737 <generic_lsm_path+0x4a07>
    f6e6:      	leaq	0x10(%r15), %rdx
    f6ea:      	movl	$0x4, %eax
    f6ef:      	movq	%rbp, %rdi
    f6f2:      	movl	$0x8, %esi
    f6f7:      	callq	*%rax
    f6f9:      	movq	0x40(%rsp), %rax
    f6fe:      	cmpq	(%rsp), %rax
    f702:      	je	0x1679d <generic_lsm_path+0xba6d>
    f708:      	addq	$0x18, %r15
    f70c:      	movl	$0x4, %eax
    f711:      	leaq	0x30(%rsp), %rdi
    f716:      	movl	$0x8, %esi
    f71b:      	movq	%r15, %rdx
    f71e:      	callq	*%rax
    f720:      	movq	(%rsp), %r15
    f724:      	movq	%r15, 0x40(%rsp)
    f729:      	leaq	0x20(%r15), %rdx
    f72d:      	movq	%rdx, 0x38(%rsp)
    f732:      	movq	0x30(%rsp), %r12
    f737:      	cmpq	0x18(%rsp), %r12
    f73c:      	jne	0xf749 <generic_lsm_path+0x4a19>
    f73e:      	cmpq	0x20(%rsp), %rdx
    f743:      	je	0x1679d <generic_lsm_path+0xba6d>
    f749:      	movl	$0x4, %eax
    f74e:      	leaq	0x10(%rsp), %rdi
    f753:      	movl	$0x8, %esi
    f758:      	callq	*%rax
    f75a:      	cmpq	0x10(%rsp), %r12
    f75f:      	je	0xf857 <generic_lsm_path+0x4b27>
    f765:      	leaq	0x18(%r12), %rbx
    f76a:      	movl	$0x4, %eax
    f76f:      	movq	%rbp, %rdi
    f772:      	movl	$0x8, %esi
    f777:      	movq	%rbx, %rdx
    f77a:      	callq	*%rax
    f77c:      	cmpq	%r12, (%rsp)
    f780:      	je	0xf857 <generic_lsm_path+0x4b27>
    f786:      	movl	$0x4, %eax
    f78b:      	leaq	0x8(%rsp), %rdi
    f790:      	movl	$0x8, %esi
    f795:      	movq	%rbx, %rdx
    f798:      	callq	*%rax
    f79a:      	addq	$0x20, %r12
    f79e:      	movl	$0x4, %eax
    f7a3:      	leaq	0x58(%rsp), %rdi
    f7a8:      	movl	$0x10, %ecx
    f7ad:      	movl	$0x10, %esi
    f7b2:      	movq	%r12, %rdx
    f7b5:      	callq	*%rax
    f7b7:      	movq	0x28(%rsp), %rbx
    f7bc:      	movq	0x48(%rsp), %rax
    f7c1:      	movl	0x5c(%rsp), %r15d
    f7c6:      	subq	%rbx, %rax
    f7c9:      	movl	0x50(%rsp), %r12d
    f7ce:      	movl	%r15d, %edx
    f7d1:      	subl	%r12d, %edx
    f7d4:      	movl	$0x0, %ecx
    f7d9:      	cmovbl	%ecx, %edx
    f7dc:      	addq	0x60(%rsp), %rdx
    f7e1:      	xorl	%esi, %esi
    f7e3:      	cmpl	%r15d, %r12d
    f7e6:      	seta	%sil
    f7ea:      	movl	%r15d, %ecx
    f7ed:      	cmovbl	%r12d, %ecx
    f7f1:      	addl	%ecx, %esi
    f7f3:      	movl	%r12d, %edi
    f7f6:      	subl	%esi, %edi
    f7f8:      	movl	%edi, 0x50(%rsp)
    f7fc:      	subq	%rsi, %rax
    f7ff:      	jb	0x167a2 <generic_lsm_path+0xba72>
    f805:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f80b:      	ja	0x167a2 <generic_lsm_path+0xba72>
    f811:      	cmpl	%r15d, %r12d
    f814:      	jbe	0xf81a <generic_lsm_path+0x4aea>
    f816:      	movb	$0x2f, (%rbx,%rax)
    f81a:      	xorl	%edi, %edi
    f81c:      	cmpl	%r15d, %r12d
    f81f:      	seta	%dil
    f823:      	movzbl	%cl, %esi
    f826:      	addq	%rax, %rbx
    f829:      	addq	%rbx, %rdi
    f82c:      	movl	$0x4, %eax
    f831:      	callq	*%rax
    f833:      	movq	%rbx, 0x48(%rsp)
    f838:      	cmpl	%r15d, %r12d
    f83b:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    f841:      	movq	0x8(%rsp), %r12
    f846:      	movq	%r12, 0x30(%rsp)
    f84b:      	movq	0x38(%rsp), %rdx
    f850:      	movq	0x40(%rsp), %r15
    f855:      	jmp	0xf8a8 <generic_lsm_path+0x4b78>
    f857:      	leaq	0x10(%r15), %rdx
    f85b:      	movl	$0x4, %eax
    f860:      	movq	%rbp, %rdi
    f863:      	movl	$0x8, %esi
    f868:      	callq	*%rax
    f86a:      	movq	0x40(%rsp), %rax
    f86f:      	cmpq	(%rsp), %rax
    f873:      	je	0x1679d <generic_lsm_path+0xba6d>
    f879:      	addq	$0x18, %r15
    f87d:      	movl	$0x4, %eax
    f882:      	leaq	0x30(%rsp), %rdi
    f887:      	movl	$0x8, %esi
    f88c:      	movq	%r15, %rdx
    f88f:      	callq	*%rax
    f891:      	movq	(%rsp), %r15
    f895:      	movq	%r15, 0x40(%rsp)
    f89a:      	leaq	0x20(%r15), %rdx
    f89e:      	movq	%rdx, 0x38(%rsp)
    f8a3:      	movq	0x30(%rsp), %r12
    f8a8:      	cmpq	0x18(%rsp), %r12
    f8ad:      	jne	0xf8ba <generic_lsm_path+0x4b8a>
    f8af:      	cmpq	0x20(%rsp), %rdx
    f8b4:      	je	0x1679d <generic_lsm_path+0xba6d>
    f8ba:      	movl	$0x4, %eax
    f8bf:      	leaq	0x10(%rsp), %rdi
    f8c4:      	movl	$0x8, %esi
    f8c9:      	callq	*%rax
    f8cb:      	cmpq	0x10(%rsp), %r12
    f8d0:      	je	0xf9c8 <generic_lsm_path+0x4c98>
    f8d6:      	leaq	0x18(%r12), %rbx
    f8db:      	movl	$0x4, %eax
    f8e0:      	movq	%rbp, %rdi
    f8e3:      	movl	$0x8, %esi
    f8e8:      	movq	%rbx, %rdx
    f8eb:      	callq	*%rax
    f8ed:      	cmpq	%r12, (%rsp)
    f8f1:      	je	0xf9c8 <generic_lsm_path+0x4c98>
    f8f7:      	movl	$0x4, %eax
    f8fc:      	leaq	0x8(%rsp), %rdi
    f901:      	movl	$0x8, %esi
    f906:      	movq	%rbx, %rdx
    f909:      	callq	*%rax
    f90b:      	addq	$0x20, %r12
    f90f:      	movl	$0x4, %eax
    f914:      	leaq	0x58(%rsp), %rdi
    f919:      	movl	$0x10, %ecx
    f91e:      	movl	$0x10, %esi
    f923:      	movq	%r12, %rdx
    f926:      	callq	*%rax
    f928:      	movq	0x28(%rsp), %rbx
    f92d:      	movq	0x48(%rsp), %rax
    f932:      	movl	0x5c(%rsp), %r15d
    f937:      	subq	%rbx, %rax
    f93a:      	movl	0x50(%rsp), %r12d
    f93f:      	movl	%r15d, %edx
    f942:      	subl	%r12d, %edx
    f945:      	movl	$0x0, %ecx
    f94a:      	cmovbl	%ecx, %edx
    f94d:      	addq	0x60(%rsp), %rdx
    f952:      	xorl	%esi, %esi
    f954:      	cmpl	%r15d, %r12d
    f957:      	seta	%sil
    f95b:      	movl	%r15d, %ecx
    f95e:      	cmovbl	%r12d, %ecx
    f962:      	addl	%ecx, %esi
    f964:      	movl	%r12d, %edi
    f967:      	subl	%esi, %edi
    f969:      	movl	%edi, 0x50(%rsp)
    f96d:      	subq	%rsi, %rax
    f970:      	jb	0x167a2 <generic_lsm_path+0xba72>
    f976:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f97c:      	ja	0x167a2 <generic_lsm_path+0xba72>
    f982:      	cmpl	%r15d, %r12d
    f985:      	jbe	0xf98b <generic_lsm_path+0x4c5b>
    f987:      	movb	$0x2f, (%rbx,%rax)
    f98b:      	xorl	%edi, %edi
    f98d:      	cmpl	%r15d, %r12d
    f990:      	seta	%dil
    f994:      	movzbl	%cl, %esi
    f997:      	addq	%rax, %rbx
    f99a:      	addq	%rbx, %rdi
    f99d:      	movl	$0x4, %eax
    f9a2:      	callq	*%rax
    f9a4:      	movq	%rbx, 0x48(%rsp)
    f9a9:      	cmpl	%r15d, %r12d
    f9ac:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    f9b2:      	movq	0x8(%rsp), %r12
    f9b7:      	movq	%r12, 0x30(%rsp)
    f9bc:      	movq	0x38(%rsp), %rdx
    f9c1:      	movq	0x40(%rsp), %r15
    f9c6:      	jmp	0xfa19 <generic_lsm_path+0x4ce9>
    f9c8:      	leaq	0x10(%r15), %rdx
    f9cc:      	movl	$0x4, %eax
    f9d1:      	movq	%rbp, %rdi
    f9d4:      	movl	$0x8, %esi
    f9d9:      	callq	*%rax
    f9db:      	movq	0x40(%rsp), %rax
    f9e0:      	cmpq	(%rsp), %rax
    f9e4:      	je	0x1679d <generic_lsm_path+0xba6d>
    f9ea:      	addq	$0x18, %r15
    f9ee:      	movl	$0x4, %eax
    f9f3:      	leaq	0x30(%rsp), %rdi
    f9f8:      	movl	$0x8, %esi
    f9fd:      	movq	%r15, %rdx
    fa00:      	callq	*%rax
    fa02:      	movq	(%rsp), %r15
    fa06:      	movq	%r15, 0x40(%rsp)
    fa0b:      	leaq	0x20(%r15), %rdx
    fa0f:      	movq	%rdx, 0x38(%rsp)
    fa14:      	movq	0x30(%rsp), %r12
    fa19:      	cmpq	0x18(%rsp), %r12
    fa1e:      	jne	0xfa2b <generic_lsm_path+0x4cfb>
    fa20:      	cmpq	0x20(%rsp), %rdx
    fa25:      	je	0x1679d <generic_lsm_path+0xba6d>
    fa2b:      	movl	$0x4, %eax
    fa30:      	leaq	0x10(%rsp), %rdi
    fa35:      	movl	$0x8, %esi
    fa3a:      	callq	*%rax
    fa3c:      	cmpq	0x10(%rsp), %r12
    fa41:      	je	0xfb39 <generic_lsm_path+0x4e09>
    fa47:      	leaq	0x18(%r12), %rbx
    fa4c:      	movl	$0x4, %eax
    fa51:      	movq	%rbp, %rdi
    fa54:      	movl	$0x8, %esi
    fa59:      	movq	%rbx, %rdx
    fa5c:      	callq	*%rax
    fa5e:      	cmpq	%r12, (%rsp)
    fa62:      	je	0xfb39 <generic_lsm_path+0x4e09>
    fa68:      	movl	$0x4, %eax
    fa6d:      	leaq	0x8(%rsp), %rdi
    fa72:      	movl	$0x8, %esi
    fa77:      	movq	%rbx, %rdx
    fa7a:      	callq	*%rax
    fa7c:      	addq	$0x20, %r12
    fa80:      	movl	$0x4, %eax
    fa85:      	leaq	0x58(%rsp), %rdi
    fa8a:      	movl	$0x10, %ecx
    fa8f:      	movl	$0x10, %esi
    fa94:      	movq	%r12, %rdx
    fa97:      	callq	*%rax
    fa99:      	movq	0x28(%rsp), %rbx
    fa9e:      	movq	0x48(%rsp), %rax
    faa3:      	movl	0x5c(%rsp), %r15d
    faa8:      	subq	%rbx, %rax
    faab:      	movl	0x50(%rsp), %r12d
    fab0:      	movl	%r15d, %edx
    fab3:      	subl	%r12d, %edx
    fab6:      	movl	$0x0, %ecx
    fabb:      	cmovbl	%ecx, %edx
    fabe:      	addq	0x60(%rsp), %rdx
    fac3:      	xorl	%esi, %esi
    fac5:      	cmpl	%r15d, %r12d
    fac8:      	seta	%sil
    facc:      	movl	%r15d, %ecx
    facf:      	cmovbl	%r12d, %ecx
    fad3:      	addl	%ecx, %esi
    fad5:      	movl	%r12d, %edi
    fad8:      	subl	%esi, %edi
    fada:      	movl	%edi, 0x50(%rsp)
    fade:      	subq	%rsi, %rax
    fae1:      	jb	0x167a2 <generic_lsm_path+0xba72>
    fae7:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    faed:      	ja	0x167a2 <generic_lsm_path+0xba72>
    faf3:      	cmpl	%r15d, %r12d
    faf6:      	jbe	0xfafc <generic_lsm_path+0x4dcc>
    faf8:      	movb	$0x2f, (%rbx,%rax)
    fafc:      	xorl	%edi, %edi
    fafe:      	cmpl	%r15d, %r12d
    fb01:      	seta	%dil
    fb05:      	movzbl	%cl, %esi
    fb08:      	addq	%rax, %rbx
    fb0b:      	addq	%rbx, %rdi
    fb0e:      	movl	$0x4, %eax
    fb13:      	callq	*%rax
    fb15:      	movq	%rbx, 0x48(%rsp)
    fb1a:      	cmpl	%r15d, %r12d
    fb1d:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    fb23:      	movq	0x8(%rsp), %r12
    fb28:      	movq	%r12, 0x30(%rsp)
    fb2d:      	movq	0x38(%rsp), %rdx
    fb32:      	movq	0x40(%rsp), %r15
    fb37:      	jmp	0xfb8a <generic_lsm_path+0x4e5a>
    fb39:      	leaq	0x10(%r15), %rdx
    fb3d:      	movl	$0x4, %eax
    fb42:      	movq	%rbp, %rdi
    fb45:      	movl	$0x8, %esi
    fb4a:      	callq	*%rax
    fb4c:      	movq	0x40(%rsp), %rax
    fb51:      	cmpq	(%rsp), %rax
    fb55:      	je	0x1679d <generic_lsm_path+0xba6d>
    fb5b:      	addq	$0x18, %r15
    fb5f:      	movl	$0x4, %eax
    fb64:      	leaq	0x30(%rsp), %rdi
    fb69:      	movl	$0x8, %esi
    fb6e:      	movq	%r15, %rdx
    fb71:      	callq	*%rax
    fb73:      	movq	(%rsp), %r15
    fb77:      	movq	%r15, 0x40(%rsp)
    fb7c:      	leaq	0x20(%r15), %rdx
    fb80:      	movq	%rdx, 0x38(%rsp)
    fb85:      	movq	0x30(%rsp), %r12
    fb8a:      	cmpq	0x18(%rsp), %r12
    fb8f:      	jne	0xfb9c <generic_lsm_path+0x4e6c>
    fb91:      	cmpq	0x20(%rsp), %rdx
    fb96:      	je	0x1679d <generic_lsm_path+0xba6d>
    fb9c:      	movl	$0x4, %eax
    fba1:      	leaq	0x10(%rsp), %rdi
    fba6:      	movl	$0x8, %esi
    fbab:      	callq	*%rax
    fbad:      	cmpq	0x10(%rsp), %r12
    fbb2:      	je	0xfcaa <generic_lsm_path+0x4f7a>
    fbb8:      	leaq	0x18(%r12), %rbx
    fbbd:      	movl	$0x4, %eax
    fbc2:      	movq	%rbp, %rdi
    fbc5:      	movl	$0x8, %esi
    fbca:      	movq	%rbx, %rdx
    fbcd:      	callq	*%rax
    fbcf:      	cmpq	%r12, (%rsp)
    fbd3:      	je	0xfcaa <generic_lsm_path+0x4f7a>
    fbd9:      	movl	$0x4, %eax
    fbde:      	leaq	0x8(%rsp), %rdi
    fbe3:      	movl	$0x8, %esi
    fbe8:      	movq	%rbx, %rdx
    fbeb:      	callq	*%rax
    fbed:      	addq	$0x20, %r12
    fbf1:      	movl	$0x4, %eax
    fbf6:      	leaq	0x58(%rsp), %rdi
    fbfb:      	movl	$0x10, %ecx
    fc00:      	movl	$0x10, %esi
    fc05:      	movq	%r12, %rdx
    fc08:      	callq	*%rax
    fc0a:      	movq	0x28(%rsp), %rbx
    fc0f:      	movq	0x48(%rsp), %rax
    fc14:      	movl	0x5c(%rsp), %r15d
    fc19:      	subq	%rbx, %rax
    fc1c:      	movl	0x50(%rsp), %r12d
    fc21:      	movl	%r15d, %edx
    fc24:      	subl	%r12d, %edx
    fc27:      	movl	$0x0, %ecx
    fc2c:      	cmovbl	%ecx, %edx
    fc2f:      	addq	0x60(%rsp), %rdx
    fc34:      	xorl	%esi, %esi
    fc36:      	cmpl	%r15d, %r12d
    fc39:      	seta	%sil
    fc3d:      	movl	%r15d, %ecx
    fc40:      	cmovbl	%r12d, %ecx
    fc44:      	addl	%ecx, %esi
    fc46:      	movl	%r12d, %edi
    fc49:      	subl	%esi, %edi
    fc4b:      	movl	%edi, 0x50(%rsp)
    fc4f:      	subq	%rsi, %rax
    fc52:      	jb	0x167a2 <generic_lsm_path+0xba72>
    fc58:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    fc5e:      	ja	0x167a2 <generic_lsm_path+0xba72>
    fc64:      	cmpl	%r15d, %r12d
    fc67:      	jbe	0xfc6d <generic_lsm_path+0x4f3d>
    fc69:      	movb	$0x2f, (%rbx,%rax)
    fc6d:      	xorl	%edi, %edi
    fc6f:      	cmpl	%r15d, %r12d
    fc72:      	seta	%dil
    fc76:      	movzbl	%cl, %esi
    fc79:      	addq	%rax, %rbx
    fc7c:      	addq	%rbx, %rdi
    fc7f:      	movl	$0x4, %eax
    fc84:      	callq	*%rax
    fc86:      	movq	%rbx, 0x48(%rsp)
    fc8b:      	cmpl	%r15d, %r12d
    fc8e:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    fc94:      	movq	0x8(%rsp), %r12
    fc99:      	movq	%r12, 0x30(%rsp)
    fc9e:      	movq	0x38(%rsp), %rdx
    fca3:      	movq	0x40(%rsp), %r15
    fca8:      	jmp	0xfcfb <generic_lsm_path+0x4fcb>
    fcaa:      	leaq	0x10(%r15), %rdx
    fcae:      	movl	$0x4, %eax
    fcb3:      	movq	%rbp, %rdi
    fcb6:      	movl	$0x8, %esi
    fcbb:      	callq	*%rax
    fcbd:      	movq	0x40(%rsp), %rax
    fcc2:      	cmpq	(%rsp), %rax
    fcc6:      	je	0x1679d <generic_lsm_path+0xba6d>
    fccc:      	addq	$0x18, %r15
    fcd0:      	movl	$0x4, %eax
    fcd5:      	leaq	0x30(%rsp), %rdi
    fcda:      	movl	$0x8, %esi
    fcdf:      	movq	%r15, %rdx
    fce2:      	callq	*%rax
    fce4:      	movq	(%rsp), %r15
    fce8:      	movq	%r15, 0x40(%rsp)
    fced:      	leaq	0x20(%r15), %rdx
    fcf1:      	movq	%rdx, 0x38(%rsp)
    fcf6:      	movq	0x30(%rsp), %r12
    fcfb:      	cmpq	0x18(%rsp), %r12
    fd00:      	jne	0xfd0d <generic_lsm_path+0x4fdd>
    fd02:      	cmpq	0x20(%rsp), %rdx
    fd07:      	je	0x1679d <generic_lsm_path+0xba6d>
    fd0d:      	movl	$0x4, %eax
    fd12:      	leaq	0x10(%rsp), %rdi
    fd17:      	movl	$0x8, %esi
    fd1c:      	callq	*%rax
    fd1e:      	cmpq	0x10(%rsp), %r12
    fd23:      	je	0xfe1b <generic_lsm_path+0x50eb>
    fd29:      	leaq	0x18(%r12), %rbx
    fd2e:      	movl	$0x4, %eax
    fd33:      	movq	%rbp, %rdi
    fd36:      	movl	$0x8, %esi
    fd3b:      	movq	%rbx, %rdx
    fd3e:      	callq	*%rax
    fd40:      	cmpq	%r12, (%rsp)
    fd44:      	je	0xfe1b <generic_lsm_path+0x50eb>
    fd4a:      	movl	$0x4, %eax
    fd4f:      	leaq	0x8(%rsp), %rdi
    fd54:      	movl	$0x8, %esi
    fd59:      	movq	%rbx, %rdx
    fd5c:      	callq	*%rax
    fd5e:      	addq	$0x20, %r12
    fd62:      	movl	$0x4, %eax
    fd67:      	leaq	0x58(%rsp), %rdi
    fd6c:      	movl	$0x10, %ecx
    fd71:      	movl	$0x10, %esi
    fd76:      	movq	%r12, %rdx
    fd79:      	callq	*%rax
    fd7b:      	movq	0x28(%rsp), %rbx
    fd80:      	movq	0x48(%rsp), %rax
    fd85:      	movl	0x5c(%rsp), %r15d
    fd8a:      	subq	%rbx, %rax
    fd8d:      	movl	0x50(%rsp), %r12d
    fd92:      	movl	%r15d, %edx
    fd95:      	subl	%r12d, %edx
    fd98:      	movl	$0x0, %ecx
    fd9d:      	cmovbl	%ecx, %edx
    fda0:      	addq	0x60(%rsp), %rdx
    fda5:      	xorl	%esi, %esi
    fda7:      	cmpl	%r15d, %r12d
    fdaa:      	seta	%sil
    fdae:      	movl	%r15d, %ecx
    fdb1:      	cmovbl	%r12d, %ecx
    fdb5:      	addl	%ecx, %esi
    fdb7:      	movl	%r12d, %edi
    fdba:      	subl	%esi, %edi
    fdbc:      	movl	%edi, 0x50(%rsp)
    fdc0:      	subq	%rsi, %rax
    fdc3:      	jb	0x167a2 <generic_lsm_path+0xba72>
    fdc9:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    fdcf:      	ja	0x167a2 <generic_lsm_path+0xba72>
    fdd5:      	cmpl	%r15d, %r12d
    fdd8:      	jbe	0xfdde <generic_lsm_path+0x50ae>
    fdda:      	movb	$0x2f, (%rbx,%rax)
    fdde:      	xorl	%edi, %edi
    fde0:      	cmpl	%r15d, %r12d
    fde3:      	seta	%dil
    fde7:      	movzbl	%cl, %esi
    fdea:      	addq	%rax, %rbx
    fded:      	addq	%rbx, %rdi
    fdf0:      	movl	$0x4, %eax
    fdf5:      	callq	*%rax
    fdf7:      	movq	%rbx, 0x48(%rsp)
    fdfc:      	cmpl	%r15d, %r12d
    fdff:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    fe05:      	movq	0x8(%rsp), %r12
    fe0a:      	movq	%r12, 0x30(%rsp)
    fe0f:      	movq	0x38(%rsp), %rdx
    fe14:      	movq	0x40(%rsp), %r15
    fe19:      	jmp	0xfe6c <generic_lsm_path+0x513c>
    fe1b:      	leaq	0x10(%r15), %rdx
    fe1f:      	movl	$0x4, %eax
    fe24:      	movq	%rbp, %rdi
    fe27:      	movl	$0x8, %esi
    fe2c:      	callq	*%rax
    fe2e:      	movq	0x40(%rsp), %rax
    fe33:      	cmpq	(%rsp), %rax
    fe37:      	je	0x1679d <generic_lsm_path+0xba6d>
    fe3d:      	addq	$0x18, %r15
    fe41:      	movl	$0x4, %eax
    fe46:      	leaq	0x30(%rsp), %rdi
    fe4b:      	movl	$0x8, %esi
    fe50:      	movq	%r15, %rdx
    fe53:      	callq	*%rax
    fe55:      	movq	(%rsp), %r15
    fe59:      	movq	%r15, 0x40(%rsp)
    fe5e:      	leaq	0x20(%r15), %rdx
    fe62:      	movq	%rdx, 0x38(%rsp)
    fe67:      	movq	0x30(%rsp), %r12
    fe6c:      	cmpq	0x18(%rsp), %r12
    fe71:      	jne	0xfe7e <generic_lsm_path+0x514e>
    fe73:      	cmpq	0x20(%rsp), %rdx
    fe78:      	je	0x1679d <generic_lsm_path+0xba6d>
    fe7e:      	movl	$0x4, %eax
    fe83:      	leaq	0x10(%rsp), %rdi
    fe88:      	movl	$0x8, %esi
    fe8d:      	callq	*%rax
    fe8f:      	cmpq	0x10(%rsp), %r12
    fe94:      	je	0xff8c <generic_lsm_path+0x525c>
    fe9a:      	leaq	0x18(%r12), %rbx
    fe9f:      	movl	$0x4, %eax
    fea4:      	movq	%rbp, %rdi
    fea7:      	movl	$0x8, %esi
    feac:      	movq	%rbx, %rdx
    feaf:      	callq	*%rax
    feb1:      	cmpq	%r12, (%rsp)
    feb5:      	je	0xff8c <generic_lsm_path+0x525c>
    febb:      	movl	$0x4, %eax
    fec0:      	leaq	0x8(%rsp), %rdi
    fec5:      	movl	$0x8, %esi
    feca:      	movq	%rbx, %rdx
    fecd:      	callq	*%rax
    fecf:      	addq	$0x20, %r12
    fed3:      	movl	$0x4, %eax
    fed8:      	leaq	0x58(%rsp), %rdi
    fedd:      	movl	$0x10, %ecx
    fee2:      	movl	$0x10, %esi
    fee7:      	movq	%r12, %rdx
    feea:      	callq	*%rax
    feec:      	movq	0x28(%rsp), %rbx
    fef1:      	movq	0x48(%rsp), %rax
    fef6:      	movl	0x5c(%rsp), %r15d
    fefb:      	subq	%rbx, %rax
    fefe:      	movl	0x50(%rsp), %r12d
    ff03:      	movl	%r15d, %edx
    ff06:      	subl	%r12d, %edx
    ff09:      	movl	$0x0, %ecx
    ff0e:      	cmovbl	%ecx, %edx
    ff11:      	addq	0x60(%rsp), %rdx
    ff16:      	xorl	%esi, %esi
    ff18:      	cmpl	%r15d, %r12d
    ff1b:      	seta	%sil
    ff1f:      	movl	%r15d, %ecx
    ff22:      	cmovbl	%r12d, %ecx
    ff26:      	addl	%ecx, %esi
    ff28:      	movl	%r12d, %edi
    ff2b:      	subl	%esi, %edi
    ff2d:      	movl	%edi, 0x50(%rsp)
    ff31:      	subq	%rsi, %rax
    ff34:      	jb	0x167a2 <generic_lsm_path+0xba72>
    ff3a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ff40:      	ja	0x167a2 <generic_lsm_path+0xba72>
    ff46:      	cmpl	%r15d, %r12d
    ff49:      	jbe	0xff4f <generic_lsm_path+0x521f>
    ff4b:      	movb	$0x2f, (%rbx,%rax)
    ff4f:      	xorl	%edi, %edi
    ff51:      	cmpl	%r15d, %r12d
    ff54:      	seta	%dil
    ff58:      	movzbl	%cl, %esi
    ff5b:      	addq	%rax, %rbx
    ff5e:      	addq	%rbx, %rdi
    ff61:      	movl	$0x4, %eax
    ff66:      	callq	*%rax
    ff68:      	movq	%rbx, 0x48(%rsp)
    ff6d:      	cmpl	%r15d, %r12d
    ff70:      	jbe	0x167a2 <generic_lsm_path+0xba72>
    ff76:      	movq	0x8(%rsp), %r12
    ff7b:      	movq	%r12, 0x30(%rsp)
    ff80:      	movq	0x38(%rsp), %rdx
    ff85:      	movq	0x40(%rsp), %r15
    ff8a:      	jmp	0xffdd <generic_lsm_path+0x52ad>
    ff8c:      	leaq	0x10(%r15), %rdx
    ff90:      	movl	$0x4, %eax
    ff95:      	movq	%rbp, %rdi
    ff98:      	movl	$0x8, %esi
    ff9d:      	callq	*%rax
    ff9f:      	movq	0x40(%rsp), %rax
    ffa4:      	cmpq	(%rsp), %rax
    ffa8:      	je	0x1679d <generic_lsm_path+0xba6d>
    ffae:      	addq	$0x18, %r15
    ffb2:      	movl	$0x4, %eax
    ffb7:      	leaq	0x30(%rsp), %rdi
    ffbc:      	movl	$0x8, %esi
    ffc1:      	movq	%r15, %rdx
    ffc4:      	callq	*%rax
    ffc6:      	movq	(%rsp), %r15
    ffca:      	movq	%r15, 0x40(%rsp)
    ffcf:      	leaq	0x20(%r15), %rdx
    ffd3:      	movq	%rdx, 0x38(%rsp)
    ffd8:      	movq	0x30(%rsp), %r12
    ffdd:      	cmpq	0x18(%rsp), %r12
    ffe2:      	jne	0xffef <generic_lsm_path+0x52bf>
    ffe4:      	cmpq	0x20(%rsp), %rdx
    ffe9:      	je	0x1679d <generic_lsm_path+0xba6d>
    ffef:      	movl	$0x4, %eax
    fff4:      	leaq	0x10(%rsp), %rdi
    fff9:      	movl	$0x8, %esi
    fffe:      	callq	*%rax
   10000:      	cmpq	0x10(%rsp), %r12
   10005:      	je	0x100fd <generic_lsm_path+0x53cd>
   1000b:      	leaq	0x18(%r12), %rbx
   10010:      	movl	$0x4, %eax
   10015:      	movq	%rbp, %rdi
   10018:      	movl	$0x8, %esi
   1001d:      	movq	%rbx, %rdx
   10020:      	callq	*%rax
   10022:      	cmpq	%r12, (%rsp)
   10026:      	je	0x100fd <generic_lsm_path+0x53cd>
   1002c:      	movl	$0x4, %eax
   10031:      	leaq	0x8(%rsp), %rdi
   10036:      	movl	$0x8, %esi
   1003b:      	movq	%rbx, %rdx
   1003e:      	callq	*%rax
   10040:      	addq	$0x20, %r12
   10044:      	movl	$0x4, %eax
   10049:      	leaq	0x58(%rsp), %rdi
   1004e:      	movl	$0x10, %ecx
   10053:      	movl	$0x10, %esi
   10058:      	movq	%r12, %rdx
   1005b:      	callq	*%rax
   1005d:      	movq	0x28(%rsp), %rbx
   10062:      	movq	0x48(%rsp), %rax
   10067:      	movl	0x5c(%rsp), %r15d
   1006c:      	subq	%rbx, %rax
   1006f:      	movl	0x50(%rsp), %r12d
   10074:      	movl	%r15d, %edx
   10077:      	subl	%r12d, %edx
   1007a:      	movl	$0x0, %ecx
   1007f:      	cmovbl	%ecx, %edx
   10082:      	addq	0x60(%rsp), %rdx
   10087:      	xorl	%esi, %esi
   10089:      	cmpl	%r15d, %r12d
   1008c:      	seta	%sil
   10090:      	movl	%r15d, %ecx
   10093:      	cmovbl	%r12d, %ecx
   10097:      	addl	%ecx, %esi
   10099:      	movl	%r12d, %edi
   1009c:      	subl	%esi, %edi
   1009e:      	movl	%edi, 0x50(%rsp)
   100a2:      	subq	%rsi, %rax
   100a5:      	jb	0x167a2 <generic_lsm_path+0xba72>
   100ab:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   100b1:      	ja	0x167a2 <generic_lsm_path+0xba72>
   100b7:      	cmpl	%r15d, %r12d
   100ba:      	jbe	0x100c0 <generic_lsm_path+0x5390>
   100bc:      	movb	$0x2f, (%rbx,%rax)
   100c0:      	xorl	%edi, %edi
   100c2:      	cmpl	%r15d, %r12d
   100c5:      	seta	%dil
   100c9:      	movzbl	%cl, %esi
   100cc:      	addq	%rax, %rbx
   100cf:      	addq	%rbx, %rdi
   100d2:      	movl	$0x4, %eax
   100d7:      	callq	*%rax
   100d9:      	movq	%rbx, 0x48(%rsp)
   100de:      	cmpl	%r15d, %r12d
   100e1:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   100e7:      	movq	0x8(%rsp), %r12
   100ec:      	movq	%r12, 0x30(%rsp)
   100f1:      	movq	0x38(%rsp), %rdx
   100f6:      	movq	0x40(%rsp), %r15
   100fb:      	jmp	0x1014e <generic_lsm_path+0x541e>
   100fd:      	leaq	0x10(%r15), %rdx
   10101:      	movl	$0x4, %eax
   10106:      	movq	%rbp, %rdi
   10109:      	movl	$0x8, %esi
   1010e:      	callq	*%rax
   10110:      	movq	0x40(%rsp), %rax
   10115:      	cmpq	(%rsp), %rax
   10119:      	je	0x1679d <generic_lsm_path+0xba6d>
   1011f:      	addq	$0x18, %r15
   10123:      	movl	$0x4, %eax
   10128:      	leaq	0x30(%rsp), %rdi
   1012d:      	movl	$0x8, %esi
   10132:      	movq	%r15, %rdx
   10135:      	callq	*%rax
   10137:      	movq	(%rsp), %r15
   1013b:      	movq	%r15, 0x40(%rsp)
   10140:      	leaq	0x20(%r15), %rdx
   10144:      	movq	%rdx, 0x38(%rsp)
   10149:      	movq	0x30(%rsp), %r12
   1014e:      	cmpq	0x18(%rsp), %r12
   10153:      	jne	0x10160 <generic_lsm_path+0x5430>
   10155:      	cmpq	0x20(%rsp), %rdx
   1015a:      	je	0x1679d <generic_lsm_path+0xba6d>
   10160:      	movl	$0x4, %eax
   10165:      	leaq	0x10(%rsp), %rdi
   1016a:      	movl	$0x8, %esi
   1016f:      	callq	*%rax
   10171:      	cmpq	0x10(%rsp), %r12
   10176:      	je	0x1026e <generic_lsm_path+0x553e>
   1017c:      	leaq	0x18(%r12), %rbx
   10181:      	movl	$0x4, %eax
   10186:      	movq	%rbp, %rdi
   10189:      	movl	$0x8, %esi
   1018e:      	movq	%rbx, %rdx
   10191:      	callq	*%rax
   10193:      	cmpq	%r12, (%rsp)
   10197:      	je	0x1026e <generic_lsm_path+0x553e>
   1019d:      	movl	$0x4, %eax
   101a2:      	leaq	0x8(%rsp), %rdi
   101a7:      	movl	$0x8, %esi
   101ac:      	movq	%rbx, %rdx
   101af:      	callq	*%rax
   101b1:      	addq	$0x20, %r12
   101b5:      	movl	$0x4, %eax
   101ba:      	leaq	0x58(%rsp), %rdi
   101bf:      	movl	$0x10, %ecx
   101c4:      	movl	$0x10, %esi
   101c9:      	movq	%r12, %rdx
   101cc:      	callq	*%rax
   101ce:      	movq	0x28(%rsp), %rbx
   101d3:      	movq	0x48(%rsp), %rax
   101d8:      	movl	0x5c(%rsp), %r15d
   101dd:      	subq	%rbx, %rax
   101e0:      	movl	0x50(%rsp), %r12d
   101e5:      	movl	%r15d, %edx
   101e8:      	subl	%r12d, %edx
   101eb:      	movl	$0x0, %ecx
   101f0:      	cmovbl	%ecx, %edx
   101f3:      	addq	0x60(%rsp), %rdx
   101f8:      	xorl	%esi, %esi
   101fa:      	cmpl	%r15d, %r12d
   101fd:      	seta	%sil
   10201:      	movl	%r15d, %ecx
   10204:      	cmovbl	%r12d, %ecx
   10208:      	addl	%ecx, %esi
   1020a:      	movl	%r12d, %edi
   1020d:      	subl	%esi, %edi
   1020f:      	movl	%edi, 0x50(%rsp)
   10213:      	subq	%rsi, %rax
   10216:      	jb	0x167a2 <generic_lsm_path+0xba72>
   1021c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10222:      	ja	0x167a2 <generic_lsm_path+0xba72>
   10228:      	cmpl	%r15d, %r12d
   1022b:      	jbe	0x10231 <generic_lsm_path+0x5501>
   1022d:      	movb	$0x2f, (%rbx,%rax)
   10231:      	xorl	%edi, %edi
   10233:      	cmpl	%r15d, %r12d
   10236:      	seta	%dil
   1023a:      	movzbl	%cl, %esi
   1023d:      	addq	%rax, %rbx
   10240:      	addq	%rbx, %rdi
   10243:      	movl	$0x4, %eax
   10248:      	callq	*%rax
   1024a:      	movq	%rbx, 0x48(%rsp)
   1024f:      	cmpl	%r15d, %r12d
   10252:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   10258:      	movq	0x8(%rsp), %r12
   1025d:      	movq	%r12, 0x30(%rsp)
   10262:      	movq	0x38(%rsp), %rdx
   10267:      	movq	0x40(%rsp), %r15
   1026c:      	jmp	0x102bf <generic_lsm_path+0x558f>
   1026e:      	leaq	0x10(%r15), %rdx
   10272:      	movl	$0x4, %eax
   10277:      	movq	%rbp, %rdi
   1027a:      	movl	$0x8, %esi
   1027f:      	callq	*%rax
   10281:      	movq	0x40(%rsp), %rax
   10286:      	cmpq	(%rsp), %rax
   1028a:      	je	0x1679d <generic_lsm_path+0xba6d>
   10290:      	addq	$0x18, %r15
   10294:      	movl	$0x4, %eax
   10299:      	leaq	0x30(%rsp), %rdi
   1029e:      	movl	$0x8, %esi
   102a3:      	movq	%r15, %rdx
   102a6:      	callq	*%rax
   102a8:      	movq	(%rsp), %r15
   102ac:      	movq	%r15, 0x40(%rsp)
   102b1:      	leaq	0x20(%r15), %rdx
   102b5:      	movq	%rdx, 0x38(%rsp)
   102ba:      	movq	0x30(%rsp), %r12
   102bf:      	cmpq	0x18(%rsp), %r12
   102c4:      	jne	0x102d1 <generic_lsm_path+0x55a1>
   102c6:      	cmpq	0x20(%rsp), %rdx
   102cb:      	je	0x1679d <generic_lsm_path+0xba6d>
   102d1:      	movl	$0x4, %eax
   102d6:      	leaq	0x10(%rsp), %rdi
   102db:      	movl	$0x8, %esi
   102e0:      	callq	*%rax
   102e2:      	cmpq	0x10(%rsp), %r12
   102e7:      	je	0x103df <generic_lsm_path+0x56af>
   102ed:      	leaq	0x18(%r12), %rbx
   102f2:      	movl	$0x4, %eax
   102f7:      	movq	%rbp, %rdi
   102fa:      	movl	$0x8, %esi
   102ff:      	movq	%rbx, %rdx
   10302:      	callq	*%rax
   10304:      	cmpq	%r12, (%rsp)
   10308:      	je	0x103df <generic_lsm_path+0x56af>
   1030e:      	movl	$0x4, %eax
   10313:      	leaq	0x8(%rsp), %rdi
   10318:      	movl	$0x8, %esi
   1031d:      	movq	%rbx, %rdx
   10320:      	callq	*%rax
   10322:      	addq	$0x20, %r12
   10326:      	movl	$0x4, %eax
   1032b:      	leaq	0x58(%rsp), %rdi
   10330:      	movl	$0x10, %ecx
   10335:      	movl	$0x10, %esi
   1033a:      	movq	%r12, %rdx
   1033d:      	callq	*%rax
   1033f:      	movq	0x28(%rsp), %rbx
   10344:      	movq	0x48(%rsp), %rax
   10349:      	movl	0x5c(%rsp), %r15d
   1034e:      	subq	%rbx, %rax
   10351:      	movl	0x50(%rsp), %r12d
   10356:      	movl	%r15d, %edx
   10359:      	subl	%r12d, %edx
   1035c:      	movl	$0x0, %ecx
   10361:      	cmovbl	%ecx, %edx
   10364:      	addq	0x60(%rsp), %rdx
   10369:      	xorl	%esi, %esi
   1036b:      	cmpl	%r15d, %r12d
   1036e:      	seta	%sil
   10372:      	movl	%r15d, %ecx
   10375:      	cmovbl	%r12d, %ecx
   10379:      	addl	%ecx, %esi
   1037b:      	movl	%r12d, %edi
   1037e:      	subl	%esi, %edi
   10380:      	movl	%edi, 0x50(%rsp)
   10384:      	subq	%rsi, %rax
   10387:      	jb	0x167a2 <generic_lsm_path+0xba72>
   1038d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10393:      	ja	0x167a2 <generic_lsm_path+0xba72>
   10399:      	cmpl	%r15d, %r12d
   1039c:      	jbe	0x103a2 <generic_lsm_path+0x5672>
   1039e:      	movb	$0x2f, (%rbx,%rax)
   103a2:      	xorl	%edi, %edi
   103a4:      	cmpl	%r15d, %r12d
   103a7:      	seta	%dil
   103ab:      	movzbl	%cl, %esi
   103ae:      	addq	%rax, %rbx
   103b1:      	addq	%rbx, %rdi
   103b4:      	movl	$0x4, %eax
   103b9:      	callq	*%rax
   103bb:      	movq	%rbx, 0x48(%rsp)
   103c0:      	cmpl	%r15d, %r12d
   103c3:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   103c9:      	movq	0x8(%rsp), %r12
   103ce:      	movq	%r12, 0x30(%rsp)
   103d3:      	movq	0x38(%rsp), %rdx
   103d8:      	movq	0x40(%rsp), %r15
   103dd:      	jmp	0x10430 <generic_lsm_path+0x5700>
   103df:      	leaq	0x10(%r15), %rdx
   103e3:      	movl	$0x4, %eax
   103e8:      	movq	%rbp, %rdi
   103eb:      	movl	$0x8, %esi
   103f0:      	callq	*%rax
   103f2:      	movq	0x40(%rsp), %rax
   103f7:      	cmpq	(%rsp), %rax
   103fb:      	je	0x1679d <generic_lsm_path+0xba6d>
   10401:      	addq	$0x18, %r15
   10405:      	movl	$0x4, %eax
   1040a:      	leaq	0x30(%rsp), %rdi
   1040f:      	movl	$0x8, %esi
   10414:      	movq	%r15, %rdx
   10417:      	callq	*%rax
   10419:      	movq	(%rsp), %r15
   1041d:      	movq	%r15, 0x40(%rsp)
   10422:      	leaq	0x20(%r15), %rdx
   10426:      	movq	%rdx, 0x38(%rsp)
   1042b:      	movq	0x30(%rsp), %r12
   10430:      	cmpq	0x18(%rsp), %r12
   10435:      	jne	0x10442 <generic_lsm_path+0x5712>
   10437:      	cmpq	0x20(%rsp), %rdx
   1043c:      	je	0x1679d <generic_lsm_path+0xba6d>
   10442:      	movl	$0x4, %eax
   10447:      	leaq	0x10(%rsp), %rdi
   1044c:      	movl	$0x8, %esi
   10451:      	callq	*%rax
   10453:      	cmpq	0x10(%rsp), %r12
   10458:      	je	0x10550 <generic_lsm_path+0x5820>
   1045e:      	leaq	0x18(%r12), %rbx
   10463:      	movl	$0x4, %eax
   10468:      	movq	%rbp, %rdi
   1046b:      	movl	$0x8, %esi
   10470:      	movq	%rbx, %rdx
   10473:      	callq	*%rax
   10475:      	cmpq	%r12, (%rsp)
   10479:      	je	0x10550 <generic_lsm_path+0x5820>
   1047f:      	movl	$0x4, %eax
   10484:      	leaq	0x8(%rsp), %rdi
   10489:      	movl	$0x8, %esi
   1048e:      	movq	%rbx, %rdx
   10491:      	callq	*%rax
   10493:      	addq	$0x20, %r12
   10497:      	movl	$0x4, %eax
   1049c:      	leaq	0x58(%rsp), %rdi
   104a1:      	movl	$0x10, %ecx
   104a6:      	movl	$0x10, %esi
   104ab:      	movq	%r12, %rdx
   104ae:      	callq	*%rax
   104b0:      	movq	0x28(%rsp), %rbx
   104b5:      	movq	0x48(%rsp), %rax
   104ba:      	movl	0x5c(%rsp), %r15d
   104bf:      	subq	%rbx, %rax
   104c2:      	movl	0x50(%rsp), %r12d
   104c7:      	movl	%r15d, %edx
   104ca:      	subl	%r12d, %edx
   104cd:      	movl	$0x0, %ecx
   104d2:      	cmovbl	%ecx, %edx
   104d5:      	addq	0x60(%rsp), %rdx
   104da:      	xorl	%esi, %esi
   104dc:      	cmpl	%r15d, %r12d
   104df:      	seta	%sil
   104e3:      	movl	%r15d, %ecx
   104e6:      	cmovbl	%r12d, %ecx
   104ea:      	addl	%ecx, %esi
   104ec:      	movl	%r12d, %edi
   104ef:      	subl	%esi, %edi
   104f1:      	movl	%edi, 0x50(%rsp)
   104f5:      	subq	%rsi, %rax
   104f8:      	jb	0x167a2 <generic_lsm_path+0xba72>
   104fe:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10504:      	ja	0x167a2 <generic_lsm_path+0xba72>
   1050a:      	cmpl	%r15d, %r12d
   1050d:      	jbe	0x10513 <generic_lsm_path+0x57e3>
   1050f:      	movb	$0x2f, (%rbx,%rax)
   10513:      	xorl	%edi, %edi
   10515:      	cmpl	%r15d, %r12d
   10518:      	seta	%dil
   1051c:      	movzbl	%cl, %esi
   1051f:      	addq	%rax, %rbx
   10522:      	addq	%rbx, %rdi
   10525:      	movl	$0x4, %eax
   1052a:      	callq	*%rax
   1052c:      	movq	%rbx, 0x48(%rsp)
   10531:      	cmpl	%r15d, %r12d
   10534:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   1053a:      	movq	0x8(%rsp), %r12
   1053f:      	movq	%r12, 0x30(%rsp)
   10544:      	movq	0x38(%rsp), %rdx
   10549:      	movq	0x40(%rsp), %r15
   1054e:      	jmp	0x105a1 <generic_lsm_path+0x5871>
   10550:      	leaq	0x10(%r15), %rdx
   10554:      	movl	$0x4, %eax
   10559:      	movq	%rbp, %rdi
   1055c:      	movl	$0x8, %esi
   10561:      	callq	*%rax
   10563:      	movq	0x40(%rsp), %rax
   10568:      	cmpq	(%rsp), %rax
   1056c:      	je	0x1679d <generic_lsm_path+0xba6d>
   10572:      	addq	$0x18, %r15
   10576:      	movl	$0x4, %eax
   1057b:      	leaq	0x30(%rsp), %rdi
   10580:      	movl	$0x8, %esi
   10585:      	movq	%r15, %rdx
   10588:      	callq	*%rax
   1058a:      	movq	(%rsp), %r15
   1058e:      	movq	%r15, 0x40(%rsp)
   10593:      	leaq	0x20(%r15), %rdx
   10597:      	movq	%rdx, 0x38(%rsp)
   1059c:      	movq	0x30(%rsp), %r12
   105a1:      	cmpq	0x18(%rsp), %r12
   105a6:      	jne	0x105b3 <generic_lsm_path+0x5883>
   105a8:      	cmpq	0x20(%rsp), %rdx
   105ad:      	je	0x1679d <generic_lsm_path+0xba6d>
   105b3:      	movl	$0x4, %eax
   105b8:      	leaq	0x10(%rsp), %rdi
   105bd:      	movl	$0x8, %esi
   105c2:      	callq	*%rax
   105c4:      	cmpq	0x10(%rsp), %r12
   105c9:      	je	0x106c1 <generic_lsm_path+0x5991>
   105cf:      	leaq	0x18(%r12), %rbx
   105d4:      	movl	$0x4, %eax
   105d9:      	movq	%rbp, %rdi
   105dc:      	movl	$0x8, %esi
   105e1:      	movq	%rbx, %rdx
   105e4:      	callq	*%rax
   105e6:      	cmpq	%r12, (%rsp)
   105ea:      	je	0x106c1 <generic_lsm_path+0x5991>
   105f0:      	movl	$0x4, %eax
   105f5:      	leaq	0x8(%rsp), %rdi
   105fa:      	movl	$0x8, %esi
   105ff:      	movq	%rbx, %rdx
   10602:      	callq	*%rax
   10604:      	addq	$0x20, %r12
   10608:      	movl	$0x4, %eax
   1060d:      	leaq	0x58(%rsp), %rdi
   10612:      	movl	$0x10, %ecx
   10617:      	movl	$0x10, %esi
   1061c:      	movq	%r12, %rdx
   1061f:      	callq	*%rax
   10621:      	movq	0x28(%rsp), %rbx
   10626:      	movq	0x48(%rsp), %rax
   1062b:      	movl	0x5c(%rsp), %r15d
   10630:      	subq	%rbx, %rax
   10633:      	movl	0x50(%rsp), %r12d
   10638:      	movl	%r15d, %edx
   1063b:      	subl	%r12d, %edx
   1063e:      	movl	$0x0, %ecx
   10643:      	cmovbl	%ecx, %edx
   10646:      	addq	0x60(%rsp), %rdx
   1064b:      	xorl	%esi, %esi
   1064d:      	cmpl	%r15d, %r12d
   10650:      	seta	%sil
   10654:      	movl	%r15d, %ecx
   10657:      	cmovbl	%r12d, %ecx
   1065b:      	addl	%ecx, %esi
   1065d:      	movl	%r12d, %edi
   10660:      	subl	%esi, %edi
   10662:      	movl	%edi, 0x50(%rsp)
   10666:      	subq	%rsi, %rax
   10669:      	jb	0x167a2 <generic_lsm_path+0xba72>
   1066f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10675:      	ja	0x167a2 <generic_lsm_path+0xba72>
   1067b:      	cmpl	%r15d, %r12d
   1067e:      	jbe	0x10684 <generic_lsm_path+0x5954>
   10680:      	movb	$0x2f, (%rbx,%rax)
   10684:      	xorl	%edi, %edi
   10686:      	cmpl	%r15d, %r12d
   10689:      	seta	%dil
   1068d:      	movzbl	%cl, %esi
   10690:      	addq	%rax, %rbx
   10693:      	addq	%rbx, %rdi
   10696:      	movl	$0x4, %eax
   1069b:      	callq	*%rax
   1069d:      	movq	%rbx, 0x48(%rsp)
   106a2:      	cmpl	%r15d, %r12d
   106a5:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   106ab:      	movq	0x8(%rsp), %r12
   106b0:      	movq	%r12, 0x30(%rsp)
   106b5:      	movq	0x38(%rsp), %rdx
   106ba:      	movq	0x40(%rsp), %r15
   106bf:      	jmp	0x10712 <generic_lsm_path+0x59e2>
   106c1:      	leaq	0x10(%r15), %rdx
   106c5:      	movl	$0x4, %eax
   106ca:      	movq	%rbp, %rdi
   106cd:      	movl	$0x8, %esi
   106d2:      	callq	*%rax
   106d4:      	movq	0x40(%rsp), %rax
   106d9:      	cmpq	(%rsp), %rax
   106dd:      	je	0x1679d <generic_lsm_path+0xba6d>
   106e3:      	addq	$0x18, %r15
   106e7:      	movl	$0x4, %eax
   106ec:      	leaq	0x30(%rsp), %rdi
   106f1:      	movl	$0x8, %esi
   106f6:      	movq	%r15, %rdx
   106f9:      	callq	*%rax
   106fb:      	movq	(%rsp), %r15
   106ff:      	movq	%r15, 0x40(%rsp)
   10704:      	leaq	0x20(%r15), %rdx
   10708:      	movq	%rdx, 0x38(%rsp)
   1070d:      	movq	0x30(%rsp), %r12
   10712:      	cmpq	0x18(%rsp), %r12
   10717:      	jne	0x10724 <generic_lsm_path+0x59f4>
   10719:      	cmpq	0x20(%rsp), %rdx
   1071e:      	je	0x1679d <generic_lsm_path+0xba6d>
   10724:      	movl	$0x4, %eax
   10729:      	leaq	0x10(%rsp), %rdi
   1072e:      	movl	$0x8, %esi
   10733:      	callq	*%rax
   10735:      	cmpq	0x10(%rsp), %r12
   1073a:      	je	0x10832 <generic_lsm_path+0x5b02>
   10740:      	leaq	0x18(%r12), %rbx
   10745:      	movl	$0x4, %eax
   1074a:      	movq	%rbp, %rdi
   1074d:      	movl	$0x8, %esi
   10752:      	movq	%rbx, %rdx
   10755:      	callq	*%rax
   10757:      	cmpq	%r12, (%rsp)
   1075b:      	je	0x10832 <generic_lsm_path+0x5b02>
   10761:      	movl	$0x4, %eax
   10766:      	leaq	0x8(%rsp), %rdi
   1076b:      	movl	$0x8, %esi
   10770:      	movq	%rbx, %rdx
   10773:      	callq	*%rax
   10775:      	addq	$0x20, %r12
   10779:      	movl	$0x4, %eax
   1077e:      	leaq	0x58(%rsp), %rdi
   10783:      	movl	$0x10, %ecx
   10788:      	movl	$0x10, %esi
   1078d:      	movq	%r12, %rdx
   10790:      	callq	*%rax
   10792:      	movq	0x28(%rsp), %rbx
   10797:      	movq	0x48(%rsp), %rax
   1079c:      	movl	0x5c(%rsp), %r15d
   107a1:      	subq	%rbx, %rax
   107a4:      	movl	0x50(%rsp), %r12d
   107a9:      	movl	%r15d, %edx
   107ac:      	subl	%r12d, %edx
   107af:      	movl	$0x0, %ecx
   107b4:      	cmovbl	%ecx, %edx
   107b7:      	addq	0x60(%rsp), %rdx
   107bc:      	xorl	%esi, %esi
   107be:      	cmpl	%r15d, %r12d
   107c1:      	seta	%sil
   107c5:      	movl	%r15d, %ecx
   107c8:      	cmovbl	%r12d, %ecx
   107cc:      	addl	%ecx, %esi
   107ce:      	movl	%r12d, %edi
   107d1:      	subl	%esi, %edi
   107d3:      	movl	%edi, 0x50(%rsp)
   107d7:      	subq	%rsi, %rax
   107da:      	jb	0x167a2 <generic_lsm_path+0xba72>
   107e0:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   107e6:      	ja	0x167a2 <generic_lsm_path+0xba72>
   107ec:      	cmpl	%r15d, %r12d
   107ef:      	jbe	0x107f5 <generic_lsm_path+0x5ac5>
   107f1:      	movb	$0x2f, (%rbx,%rax)
   107f5:      	xorl	%edi, %edi
   107f7:      	cmpl	%r15d, %r12d
   107fa:      	seta	%dil
   107fe:      	movzbl	%cl, %esi
   10801:      	addq	%rax, %rbx
   10804:      	addq	%rbx, %rdi
   10807:      	movl	$0x4, %eax
   1080c:      	callq	*%rax
   1080e:      	movq	%rbx, 0x48(%rsp)
   10813:      	cmpl	%r15d, %r12d
   10816:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   1081c:      	movq	0x8(%rsp), %r12
   10821:      	movq	%r12, 0x30(%rsp)
   10826:      	movq	0x38(%rsp), %rdx
   1082b:      	movq	0x40(%rsp), %r15
   10830:      	jmp	0x10883 <generic_lsm_path+0x5b53>
   10832:      	leaq	0x10(%r15), %rdx
   10836:      	movl	$0x4, %eax
   1083b:      	movq	%rbp, %rdi
   1083e:      	movl	$0x8, %esi
   10843:      	callq	*%rax
   10845:      	movq	0x40(%rsp), %rax
   1084a:      	cmpq	(%rsp), %rax
   1084e:      	je	0x1679d <generic_lsm_path+0xba6d>
   10854:      	addq	$0x18, %r15
   10858:      	movl	$0x4, %eax
   1085d:      	leaq	0x30(%rsp), %rdi
   10862:      	movl	$0x8, %esi
   10867:      	movq	%r15, %rdx
   1086a:      	callq	*%rax
   1086c:      	movq	(%rsp), %r15
   10870:      	movq	%r15, 0x40(%rsp)
   10875:      	leaq	0x20(%r15), %rdx
   10879:      	movq	%rdx, 0x38(%rsp)
   1087e:      	movq	0x30(%rsp), %r12
   10883:      	cmpq	0x18(%rsp), %r12
   10888:      	jne	0x10895 <generic_lsm_path+0x5b65>
   1088a:      	cmpq	0x20(%rsp), %rdx
   1088f:      	je	0x1679d <generic_lsm_path+0xba6d>
   10895:      	movl	$0x4, %eax
   1089a:      	leaq	0x10(%rsp), %rdi
   1089f:      	movl	$0x8, %esi
   108a4:      	callq	*%rax
   108a6:      	cmpq	0x10(%rsp), %r12
   108ab:      	je	0x109a3 <generic_lsm_path+0x5c73>
   108b1:      	leaq	0x18(%r12), %rbx
   108b6:      	movl	$0x4, %eax
   108bb:      	movq	%rbp, %rdi
   108be:      	movl	$0x8, %esi
   108c3:      	movq	%rbx, %rdx
   108c6:      	callq	*%rax
   108c8:      	cmpq	%r12, (%rsp)
   108cc:      	je	0x109a3 <generic_lsm_path+0x5c73>
   108d2:      	movl	$0x4, %eax
   108d7:      	leaq	0x8(%rsp), %rdi
   108dc:      	movl	$0x8, %esi
   108e1:      	movq	%rbx, %rdx
   108e4:      	callq	*%rax
   108e6:      	addq	$0x20, %r12
   108ea:      	movl	$0x4, %eax
   108ef:      	leaq	0x58(%rsp), %rdi
   108f4:      	movl	$0x10, %ecx
   108f9:      	movl	$0x10, %esi
   108fe:      	movq	%r12, %rdx
   10901:      	callq	*%rax
   10903:      	movq	0x28(%rsp), %rbx
   10908:      	movq	0x48(%rsp), %rax
   1090d:      	movl	0x5c(%rsp), %r15d
   10912:      	subq	%rbx, %rax
   10915:      	movl	0x50(%rsp), %r12d
   1091a:      	movl	%r15d, %edx
   1091d:      	subl	%r12d, %edx
   10920:      	movl	$0x0, %ecx
   10925:      	cmovbl	%ecx, %edx
   10928:      	addq	0x60(%rsp), %rdx
   1092d:      	xorl	%esi, %esi
   1092f:      	cmpl	%r15d, %r12d
   10932:      	seta	%sil
   10936:      	movl	%r15d, %ecx
   10939:      	cmovbl	%r12d, %ecx
   1093d:      	addl	%ecx, %esi
   1093f:      	movl	%r12d, %edi
   10942:      	subl	%esi, %edi
   10944:      	movl	%edi, 0x50(%rsp)
   10948:      	subq	%rsi, %rax
   1094b:      	jb	0x167a2 <generic_lsm_path+0xba72>
   10951:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10957:      	ja	0x167a2 <generic_lsm_path+0xba72>
   1095d:      	cmpl	%r15d, %r12d
   10960:      	jbe	0x10966 <generic_lsm_path+0x5c36>
   10962:      	movb	$0x2f, (%rbx,%rax)
   10966:      	xorl	%edi, %edi
   10968:      	cmpl	%r15d, %r12d
   1096b:      	seta	%dil
   1096f:      	movzbl	%cl, %esi
   10972:      	addq	%rax, %rbx
   10975:      	addq	%rbx, %rdi
   10978:      	movl	$0x4, %eax
   1097d:      	callq	*%rax
   1097f:      	movq	%rbx, 0x48(%rsp)
   10984:      	cmpl	%r15d, %r12d
   10987:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   1098d:      	movq	0x8(%rsp), %r12
   10992:      	movq	%r12, 0x30(%rsp)
   10997:      	movq	0x38(%rsp), %rdx
   1099c:      	movq	0x40(%rsp), %r15
   109a1:      	jmp	0x109f4 <generic_lsm_path+0x5cc4>
   109a3:      	leaq	0x10(%r15), %rdx
   109a7:      	movl	$0x4, %eax
   109ac:      	movq	%rbp, %rdi
   109af:      	movl	$0x8, %esi
   109b4:      	callq	*%rax
   109b6:      	movq	0x40(%rsp), %rax
   109bb:      	cmpq	(%rsp), %rax
   109bf:      	je	0x1679d <generic_lsm_path+0xba6d>
   109c5:      	addq	$0x18, %r15
   109c9:      	movl	$0x4, %eax
   109ce:      	leaq	0x30(%rsp), %rdi
   109d3:      	movl	$0x8, %esi
   109d8:      	movq	%r15, %rdx
   109db:      	callq	*%rax
   109dd:      	movq	(%rsp), %r15
   109e1:      	movq	%r15, 0x40(%rsp)
   109e6:      	leaq	0x20(%r15), %rdx
   109ea:      	movq	%rdx, 0x38(%rsp)
   109ef:      	movq	0x30(%rsp), %r12
   109f4:      	cmpq	0x18(%rsp), %r12
   109f9:      	jne	0x10a06 <generic_lsm_path+0x5cd6>
   109fb:      	cmpq	0x20(%rsp), %rdx
   10a00:      	je	0x1679d <generic_lsm_path+0xba6d>
   10a06:      	movl	$0x4, %eax
   10a0b:      	leaq	0x10(%rsp), %rdi
   10a10:      	movl	$0x8, %esi
   10a15:      	callq	*%rax
   10a17:      	cmpq	0x10(%rsp), %r12
   10a1c:      	je	0x10b14 <generic_lsm_path+0x5de4>
   10a22:      	leaq	0x18(%r12), %rbx
   10a27:      	movl	$0x4, %eax
   10a2c:      	movq	%rbp, %rdi
   10a2f:      	movl	$0x8, %esi
   10a34:      	movq	%rbx, %rdx
   10a37:      	callq	*%rax
   10a39:      	cmpq	%r12, (%rsp)
   10a3d:      	je	0x10b14 <generic_lsm_path+0x5de4>
   10a43:      	movl	$0x4, %eax
   10a48:      	leaq	0x8(%rsp), %rdi
   10a4d:      	movl	$0x8, %esi
   10a52:      	movq	%rbx, %rdx
   10a55:      	callq	*%rax
   10a57:      	addq	$0x20, %r12
   10a5b:      	movl	$0x4, %eax
   10a60:      	leaq	0x58(%rsp), %rdi
   10a65:      	movl	$0x10, %ecx
   10a6a:      	movl	$0x10, %esi
   10a6f:      	movq	%r12, %rdx
   10a72:      	callq	*%rax
   10a74:      	movq	0x28(%rsp), %rbx
   10a79:      	movq	0x48(%rsp), %rax
   10a7e:      	movl	0x5c(%rsp), %r15d
   10a83:      	subq	%rbx, %rax
   10a86:      	movl	0x50(%rsp), %r12d
   10a8b:      	movl	%r15d, %edx
   10a8e:      	subl	%r12d, %edx
   10a91:      	movl	$0x0, %ecx
   10a96:      	cmovbl	%ecx, %edx
   10a99:      	addq	0x60(%rsp), %rdx
   10a9e:      	xorl	%esi, %esi
   10aa0:      	cmpl	%r15d, %r12d
   10aa3:      	seta	%sil
   10aa7:      	movl	%r15d, %ecx
   10aaa:      	cmovbl	%r12d, %ecx
   10aae:      	addl	%ecx, %esi
   10ab0:      	movl	%r12d, %edi
   10ab3:      	subl	%esi, %edi
   10ab5:      	movl	%edi, 0x50(%rsp)
   10ab9:      	subq	%rsi, %rax
   10abc:      	jb	0x167a2 <generic_lsm_path+0xba72>
   10ac2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10ac8:      	ja	0x167a2 <generic_lsm_path+0xba72>
   10ace:      	cmpl	%r15d, %r12d
   10ad1:      	jbe	0x10ad7 <generic_lsm_path+0x5da7>
   10ad3:      	movb	$0x2f, (%rbx,%rax)
   10ad7:      	xorl	%edi, %edi
   10ad9:      	cmpl	%r15d, %r12d
   10adc:      	seta	%dil
   10ae0:      	movzbl	%cl, %esi
   10ae3:      	addq	%rax, %rbx
   10ae6:      	addq	%rbx, %rdi
   10ae9:      	movl	$0x4, %eax
   10aee:      	callq	*%rax
   10af0:      	movq	%rbx, 0x48(%rsp)
   10af5:      	cmpl	%r15d, %r12d
   10af8:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   10afe:      	movq	0x8(%rsp), %r12
   10b03:      	movq	%r12, 0x30(%rsp)
   10b08:      	movq	0x38(%rsp), %rdx
   10b0d:      	movq	0x40(%rsp), %r15
   10b12:      	jmp	0x10b65 <generic_lsm_path+0x5e35>
   10b14:      	leaq	0x10(%r15), %rdx
   10b18:      	movl	$0x4, %eax
   10b1d:      	movq	%rbp, %rdi
   10b20:      	movl	$0x8, %esi
   10b25:      	callq	*%rax
   10b27:      	movq	0x40(%rsp), %rax
   10b2c:      	cmpq	(%rsp), %rax
   10b30:      	je	0x1679d <generic_lsm_path+0xba6d>
   10b36:      	addq	$0x18, %r15
   10b3a:      	movl	$0x4, %eax
   10b3f:      	leaq	0x30(%rsp), %rdi
   10b44:      	movl	$0x8, %esi
   10b49:      	movq	%r15, %rdx
   10b4c:      	callq	*%rax
   10b4e:      	movq	(%rsp), %r15
   10b52:      	movq	%r15, 0x40(%rsp)
   10b57:      	leaq	0x20(%r15), %rdx
   10b5b:      	movq	%rdx, 0x38(%rsp)
   10b60:      	movq	0x30(%rsp), %r12
   10b65:      	cmpq	0x18(%rsp), %r12
   10b6a:      	jne	0x10b77 <generic_lsm_path+0x5e47>
   10b6c:      	cmpq	0x20(%rsp), %rdx
   10b71:      	je	0x1679d <generic_lsm_path+0xba6d>
   10b77:      	movl	$0x4, %eax
   10b7c:      	leaq	0x10(%rsp), %rdi
   10b81:      	movl	$0x8, %esi
   10b86:      	callq	*%rax
   10b88:      	cmpq	0x10(%rsp), %r12
   10b8d:      	je	0x10c85 <generic_lsm_path+0x5f55>
   10b93:      	leaq	0x18(%r12), %rbx
   10b98:      	movl	$0x4, %eax
   10b9d:      	movq	%rbp, %rdi
   10ba0:      	movl	$0x8, %esi
   10ba5:      	movq	%rbx, %rdx
   10ba8:      	callq	*%rax
   10baa:      	cmpq	%r12, (%rsp)
   10bae:      	je	0x10c85 <generic_lsm_path+0x5f55>
   10bb4:      	movl	$0x4, %eax
   10bb9:      	leaq	0x8(%rsp), %rdi
   10bbe:      	movl	$0x8, %esi
   10bc3:      	movq	%rbx, %rdx
   10bc6:      	callq	*%rax
   10bc8:      	addq	$0x20, %r12
   10bcc:      	movl	$0x4, %eax
   10bd1:      	leaq	0x58(%rsp), %rdi
   10bd6:      	movl	$0x10, %ecx
   10bdb:      	movl	$0x10, %esi
   10be0:      	movq	%r12, %rdx
   10be3:      	callq	*%rax
   10be5:      	movq	0x28(%rsp), %rbx
   10bea:      	movq	0x48(%rsp), %rax
   10bef:      	movl	0x5c(%rsp), %r15d
   10bf4:      	subq	%rbx, %rax
   10bf7:      	movl	0x50(%rsp), %r12d
   10bfc:      	movl	%r15d, %edx
   10bff:      	subl	%r12d, %edx
   10c02:      	movl	$0x0, %ecx
   10c07:      	cmovbl	%ecx, %edx
   10c0a:      	addq	0x60(%rsp), %rdx
   10c0f:      	xorl	%esi, %esi
   10c11:      	cmpl	%r15d, %r12d
   10c14:      	seta	%sil
   10c18:      	movl	%r15d, %ecx
   10c1b:      	cmovbl	%r12d, %ecx
   10c1f:      	addl	%ecx, %esi
   10c21:      	movl	%r12d, %edi
   10c24:      	subl	%esi, %edi
   10c26:      	movl	%edi, 0x50(%rsp)
   10c2a:      	subq	%rsi, %rax
   10c2d:      	jb	0x167a2 <generic_lsm_path+0xba72>
   10c33:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10c39:      	ja	0x167a2 <generic_lsm_path+0xba72>
   10c3f:      	cmpl	%r15d, %r12d
   10c42:      	jbe	0x10c48 <generic_lsm_path+0x5f18>
   10c44:      	movb	$0x2f, (%rbx,%rax)
   10c48:      	xorl	%edi, %edi
   10c4a:      	cmpl	%r15d, %r12d
   10c4d:      	seta	%dil
   10c51:      	movzbl	%cl, %esi
   10c54:      	addq	%rax, %rbx
   10c57:      	addq	%rbx, %rdi
   10c5a:      	movl	$0x4, %eax
   10c5f:      	callq	*%rax
   10c61:      	movq	%rbx, 0x48(%rsp)
   10c66:      	cmpl	%r15d, %r12d
   10c69:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   10c6f:      	movq	0x8(%rsp), %r12
   10c74:      	movq	%r12, 0x30(%rsp)
   10c79:      	movq	0x38(%rsp), %rdx
   10c7e:      	movq	0x40(%rsp), %r15
   10c83:      	jmp	0x10cd6 <generic_lsm_path+0x5fa6>
   10c85:      	leaq	0x10(%r15), %rdx
   10c89:      	movl	$0x4, %eax
   10c8e:      	movq	%rbp, %rdi
   10c91:      	movl	$0x8, %esi
   10c96:      	callq	*%rax
   10c98:      	movq	0x40(%rsp), %rax
   10c9d:      	cmpq	(%rsp), %rax
   10ca1:      	je	0x1679d <generic_lsm_path+0xba6d>
   10ca7:      	addq	$0x18, %r15
   10cab:      	movl	$0x4, %eax
   10cb0:      	leaq	0x30(%rsp), %rdi
   10cb5:      	movl	$0x8, %esi
   10cba:      	movq	%r15, %rdx
   10cbd:      	callq	*%rax
   10cbf:      	movq	(%rsp), %r15
   10cc3:      	movq	%r15, 0x40(%rsp)
   10cc8:      	leaq	0x20(%r15), %rdx
   10ccc:      	movq	%rdx, 0x38(%rsp)
   10cd1:      	movq	0x30(%rsp), %r12
   10cd6:      	cmpq	0x18(%rsp), %r12
   10cdb:      	jne	0x10ce8 <generic_lsm_path+0x5fb8>
   10cdd:      	cmpq	0x20(%rsp), %rdx
   10ce2:      	je	0x1679d <generic_lsm_path+0xba6d>
   10ce8:      	movl	$0x4, %eax
   10ced:      	leaq	0x10(%rsp), %rdi
   10cf2:      	movl	$0x8, %esi
   10cf7:      	callq	*%rax
   10cf9:      	cmpq	0x10(%rsp), %r12
   10cfe:      	je	0x10df6 <generic_lsm_path+0x60c6>
   10d04:      	leaq	0x18(%r12), %rbx
   10d09:      	movl	$0x4, %eax
   10d0e:      	movq	%rbp, %rdi
   10d11:      	movl	$0x8, %esi
   10d16:      	movq	%rbx, %rdx
   10d19:      	callq	*%rax
   10d1b:      	cmpq	%r12, (%rsp)
   10d1f:      	je	0x10df6 <generic_lsm_path+0x60c6>
   10d25:      	movl	$0x4, %eax
   10d2a:      	leaq	0x8(%rsp), %rdi
   10d2f:      	movl	$0x8, %esi
   10d34:      	movq	%rbx, %rdx
   10d37:      	callq	*%rax
   10d39:      	addq	$0x20, %r12
   10d3d:      	movl	$0x4, %eax
   10d42:      	leaq	0x58(%rsp), %rdi
   10d47:      	movl	$0x10, %ecx
   10d4c:      	movl	$0x10, %esi
   10d51:      	movq	%r12, %rdx
   10d54:      	callq	*%rax
   10d56:      	movq	0x28(%rsp), %rbx
   10d5b:      	movq	0x48(%rsp), %rax
   10d60:      	movl	0x5c(%rsp), %r15d
   10d65:      	subq	%rbx, %rax
   10d68:      	movl	0x50(%rsp), %r12d
   10d6d:      	movl	%r15d, %edx
   10d70:      	subl	%r12d, %edx
   10d73:      	movl	$0x0, %ecx
   10d78:      	cmovbl	%ecx, %edx
   10d7b:      	addq	0x60(%rsp), %rdx
   10d80:      	xorl	%esi, %esi
   10d82:      	cmpl	%r15d, %r12d
   10d85:      	seta	%sil
   10d89:      	movl	%r15d, %ecx
   10d8c:      	cmovbl	%r12d, %ecx
   10d90:      	addl	%ecx, %esi
   10d92:      	movl	%r12d, %edi
   10d95:      	subl	%esi, %edi
   10d97:      	movl	%edi, 0x50(%rsp)
   10d9b:      	subq	%rsi, %rax
   10d9e:      	jb	0x167a2 <generic_lsm_path+0xba72>
   10da4:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10daa:      	ja	0x167a2 <generic_lsm_path+0xba72>
   10db0:      	cmpl	%r15d, %r12d
   10db3:      	jbe	0x10db9 <generic_lsm_path+0x6089>
   10db5:      	movb	$0x2f, (%rbx,%rax)
   10db9:      	xorl	%edi, %edi
   10dbb:      	cmpl	%r15d, %r12d
   10dbe:      	seta	%dil
   10dc2:      	movzbl	%cl, %esi
   10dc5:      	addq	%rax, %rbx
   10dc8:      	addq	%rbx, %rdi
   10dcb:      	movl	$0x4, %eax
   10dd0:      	callq	*%rax
   10dd2:      	movq	%rbx, 0x48(%rsp)
   10dd7:      	cmpl	%r15d, %r12d
   10dda:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   10de0:      	movq	0x8(%rsp), %r12
   10de5:      	movq	%r12, 0x30(%rsp)
   10dea:      	movq	0x38(%rsp), %rdx
   10def:      	movq	0x40(%rsp), %r15
   10df4:      	jmp	0x10e47 <generic_lsm_path+0x6117>
   10df6:      	leaq	0x10(%r15), %rdx
   10dfa:      	movl	$0x4, %eax
   10dff:      	movq	%rbp, %rdi
   10e02:      	movl	$0x8, %esi
   10e07:      	callq	*%rax
   10e09:      	movq	0x40(%rsp), %rax
   10e0e:      	cmpq	(%rsp), %rax
   10e12:      	je	0x1679d <generic_lsm_path+0xba6d>
   10e18:      	addq	$0x18, %r15
   10e1c:      	movl	$0x4, %eax
   10e21:      	leaq	0x30(%rsp), %rdi
   10e26:      	movl	$0x8, %esi
   10e2b:      	movq	%r15, %rdx
   10e2e:      	callq	*%rax
   10e30:      	movq	(%rsp), %r15
   10e34:      	movq	%r15, 0x40(%rsp)
   10e39:      	leaq	0x20(%r15), %rdx
   10e3d:      	movq	%rdx, 0x38(%rsp)
   10e42:      	movq	0x30(%rsp), %r12
   10e47:      	cmpq	0x18(%rsp), %r12
   10e4c:      	jne	0x10e59 <generic_lsm_path+0x6129>
   10e4e:      	cmpq	0x20(%rsp), %rdx
   10e53:      	je	0x1679d <generic_lsm_path+0xba6d>
   10e59:      	movl	$0x4, %eax
   10e5e:      	leaq	0x10(%rsp), %rdi
   10e63:      	movl	$0x8, %esi
   10e68:      	callq	*%rax
   10e6a:      	cmpq	0x10(%rsp), %r12
   10e6f:      	je	0x10f67 <generic_lsm_path+0x6237>
   10e75:      	leaq	0x18(%r12), %rbx
   10e7a:      	movl	$0x4, %eax
   10e7f:      	movq	%rbp, %rdi
   10e82:      	movl	$0x8, %esi
   10e87:      	movq	%rbx, %rdx
   10e8a:      	callq	*%rax
   10e8c:      	cmpq	%r12, (%rsp)
   10e90:      	je	0x10f67 <generic_lsm_path+0x6237>
   10e96:      	movl	$0x4, %eax
   10e9b:      	leaq	0x8(%rsp), %rdi
   10ea0:      	movl	$0x8, %esi
   10ea5:      	movq	%rbx, %rdx
   10ea8:      	callq	*%rax
   10eaa:      	addq	$0x20, %r12
   10eae:      	movl	$0x4, %eax
   10eb3:      	leaq	0x58(%rsp), %rdi
   10eb8:      	movl	$0x10, %ecx
   10ebd:      	movl	$0x10, %esi
   10ec2:      	movq	%r12, %rdx
   10ec5:      	callq	*%rax
   10ec7:      	movq	0x28(%rsp), %rbx
   10ecc:      	movq	0x48(%rsp), %rax
   10ed1:      	movl	0x5c(%rsp), %r15d
   10ed6:      	subq	%rbx, %rax
   10ed9:      	movl	0x50(%rsp), %r12d
   10ede:      	movl	%r15d, %edx
   10ee1:      	subl	%r12d, %edx
   10ee4:      	movl	$0x0, %ecx
   10ee9:      	cmovbl	%ecx, %edx
   10eec:      	addq	0x60(%rsp), %rdx
   10ef1:      	xorl	%esi, %esi
   10ef3:      	cmpl	%r15d, %r12d
   10ef6:      	seta	%sil
   10efa:      	movl	%r15d, %ecx
   10efd:      	cmovbl	%r12d, %ecx
   10f01:      	addl	%ecx, %esi
   10f03:      	movl	%r12d, %edi
   10f06:      	subl	%esi, %edi
   10f08:      	movl	%edi, 0x50(%rsp)
   10f0c:      	subq	%rsi, %rax
   10f0f:      	jb	0x167a2 <generic_lsm_path+0xba72>
   10f15:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10f1b:      	ja	0x167a2 <generic_lsm_path+0xba72>
   10f21:      	cmpl	%r15d, %r12d
   10f24:      	jbe	0x10f2a <generic_lsm_path+0x61fa>
   10f26:      	movb	$0x2f, (%rbx,%rax)
   10f2a:      	xorl	%edi, %edi
   10f2c:      	cmpl	%r15d, %r12d
   10f2f:      	seta	%dil
   10f33:      	movzbl	%cl, %esi
   10f36:      	addq	%rax, %rbx
   10f39:      	addq	%rbx, %rdi
   10f3c:      	movl	$0x4, %eax
   10f41:      	callq	*%rax
   10f43:      	movq	%rbx, 0x48(%rsp)
   10f48:      	cmpl	%r15d, %r12d
   10f4b:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   10f51:      	movq	0x8(%rsp), %r12
   10f56:      	movq	%r12, 0x30(%rsp)
   10f5b:      	movq	0x38(%rsp), %rdx
   10f60:      	movq	0x40(%rsp), %r15
   10f65:      	jmp	0x10fb8 <generic_lsm_path+0x6288>
   10f67:      	leaq	0x10(%r15), %rdx
   10f6b:      	movl	$0x4, %eax
   10f70:      	movq	%rbp, %rdi
   10f73:      	movl	$0x8, %esi
   10f78:      	callq	*%rax
   10f7a:      	movq	0x40(%rsp), %rax
   10f7f:      	cmpq	(%rsp), %rax
   10f83:      	je	0x1679d <generic_lsm_path+0xba6d>
   10f89:      	addq	$0x18, %r15
   10f8d:      	movl	$0x4, %eax
   10f92:      	leaq	0x30(%rsp), %rdi
   10f97:      	movl	$0x8, %esi
   10f9c:      	movq	%r15, %rdx
   10f9f:      	callq	*%rax
   10fa1:      	movq	(%rsp), %r15
   10fa5:      	movq	%r15, 0x40(%rsp)
   10faa:      	leaq	0x20(%r15), %rdx
   10fae:      	movq	%rdx, 0x38(%rsp)
   10fb3:      	movq	0x30(%rsp), %r12
   10fb8:      	cmpq	0x18(%rsp), %r12
   10fbd:      	jne	0x10fca <generic_lsm_path+0x629a>
   10fbf:      	cmpq	0x20(%rsp), %rdx
   10fc4:      	je	0x1679d <generic_lsm_path+0xba6d>
   10fca:      	movl	$0x4, %eax
   10fcf:      	leaq	0x10(%rsp), %rdi
   10fd4:      	movl	$0x8, %esi
   10fd9:      	callq	*%rax
   10fdb:      	cmpq	0x10(%rsp), %r12
   10fe0:      	je	0x110d8 <generic_lsm_path+0x63a8>
   10fe6:      	leaq	0x18(%r12), %rbx
   10feb:      	movl	$0x4, %eax
   10ff0:      	movq	%rbp, %rdi
   10ff3:      	movl	$0x8, %esi
   10ff8:      	movq	%rbx, %rdx
   10ffb:      	callq	*%rax
   10ffd:      	cmpq	%r12, (%rsp)
   11001:      	je	0x110d8 <generic_lsm_path+0x63a8>
   11007:      	movl	$0x4, %eax
   1100c:      	leaq	0x8(%rsp), %rdi
   11011:      	movl	$0x8, %esi
   11016:      	movq	%rbx, %rdx
   11019:      	callq	*%rax
   1101b:      	addq	$0x20, %r12
   1101f:      	movl	$0x4, %eax
   11024:      	leaq	0x58(%rsp), %rdi
   11029:      	movl	$0x10, %ecx
   1102e:      	movl	$0x10, %esi
   11033:      	movq	%r12, %rdx
   11036:      	callq	*%rax
   11038:      	movq	0x28(%rsp), %rbx
   1103d:      	movq	0x48(%rsp), %rax
   11042:      	movl	0x5c(%rsp), %r15d
   11047:      	subq	%rbx, %rax
   1104a:      	movl	0x50(%rsp), %r12d
   1104f:      	movl	%r15d, %edx
   11052:      	subl	%r12d, %edx
   11055:      	movl	$0x0, %ecx
   1105a:      	cmovbl	%ecx, %edx
   1105d:      	addq	0x60(%rsp), %rdx
   11062:      	xorl	%esi, %esi
   11064:      	cmpl	%r15d, %r12d
   11067:      	seta	%sil
   1106b:      	movl	%r15d, %ecx
   1106e:      	cmovbl	%r12d, %ecx
   11072:      	addl	%ecx, %esi
   11074:      	movl	%r12d, %edi
   11077:      	subl	%esi, %edi
   11079:      	movl	%edi, 0x50(%rsp)
   1107d:      	subq	%rsi, %rax
   11080:      	jb	0x167a2 <generic_lsm_path+0xba72>
   11086:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1108c:      	ja	0x167a2 <generic_lsm_path+0xba72>
   11092:      	cmpl	%r15d, %r12d
   11095:      	jbe	0x1109b <generic_lsm_path+0x636b>
   11097:      	movb	$0x2f, (%rbx,%rax)
   1109b:      	xorl	%edi, %edi
   1109d:      	cmpl	%r15d, %r12d
   110a0:      	seta	%dil
   110a4:      	movzbl	%cl, %esi
   110a7:      	addq	%rax, %rbx
   110aa:      	addq	%rbx, %rdi
   110ad:      	movl	$0x4, %eax
   110b2:      	callq	*%rax
   110b4:      	movq	%rbx, 0x48(%rsp)
   110b9:      	cmpl	%r15d, %r12d
   110bc:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   110c2:      	movq	0x8(%rsp), %r12
   110c7:      	movq	%r12, 0x30(%rsp)
   110cc:      	movq	0x38(%rsp), %rdx
   110d1:      	movq	0x40(%rsp), %r15
   110d6:      	jmp	0x11129 <generic_lsm_path+0x63f9>
   110d8:      	leaq	0x10(%r15), %rdx
   110dc:      	movl	$0x4, %eax
   110e1:      	movq	%rbp, %rdi
   110e4:      	movl	$0x8, %esi
   110e9:      	callq	*%rax
   110eb:      	movq	0x40(%rsp), %rax
   110f0:      	cmpq	(%rsp), %rax
   110f4:      	je	0x1679d <generic_lsm_path+0xba6d>
   110fa:      	addq	$0x18, %r15
   110fe:      	movl	$0x4, %eax
   11103:      	leaq	0x30(%rsp), %rdi
   11108:      	movl	$0x8, %esi
   1110d:      	movq	%r15, %rdx
   11110:      	callq	*%rax
   11112:      	movq	(%rsp), %r15
   11116:      	movq	%r15, 0x40(%rsp)
   1111b:      	leaq	0x20(%r15), %rdx
   1111f:      	movq	%rdx, 0x38(%rsp)
   11124:      	movq	0x30(%rsp), %r12
   11129:      	cmpq	0x18(%rsp), %r12
   1112e:      	jne	0x1113b <generic_lsm_path+0x640b>
   11130:      	cmpq	0x20(%rsp), %rdx
   11135:      	je	0x1679d <generic_lsm_path+0xba6d>
   1113b:      	movl	$0x4, %eax
   11140:      	leaq	0x10(%rsp), %rdi
   11145:      	movl	$0x8, %esi
   1114a:      	callq	*%rax
   1114c:      	cmpq	0x10(%rsp), %r12
   11151:      	je	0x11249 <generic_lsm_path+0x6519>
   11157:      	leaq	0x18(%r12), %rbx
   1115c:      	movl	$0x4, %eax
   11161:      	movq	%rbp, %rdi
   11164:      	movl	$0x8, %esi
   11169:      	movq	%rbx, %rdx
   1116c:      	callq	*%rax
   1116e:      	cmpq	%r12, (%rsp)
   11172:      	je	0x11249 <generic_lsm_path+0x6519>
   11178:      	movl	$0x4, %eax
   1117d:      	leaq	0x8(%rsp), %rdi
   11182:      	movl	$0x8, %esi
   11187:      	movq	%rbx, %rdx
   1118a:      	callq	*%rax
   1118c:      	addq	$0x20, %r12
   11190:      	movl	$0x4, %eax
   11195:      	leaq	0x58(%rsp), %rdi
   1119a:      	movl	$0x10, %ecx
   1119f:      	movl	$0x10, %esi
   111a4:      	movq	%r12, %rdx
   111a7:      	callq	*%rax
   111a9:      	movq	0x28(%rsp), %rbx
   111ae:      	movq	0x48(%rsp), %rax
   111b3:      	movl	0x5c(%rsp), %r15d
   111b8:      	subq	%rbx, %rax
   111bb:      	movl	0x50(%rsp), %r12d
   111c0:      	movl	%r15d, %edx
   111c3:      	subl	%r12d, %edx
   111c6:      	movl	$0x0, %ecx
   111cb:      	cmovbl	%ecx, %edx
   111ce:      	addq	0x60(%rsp), %rdx
   111d3:      	xorl	%esi, %esi
   111d5:      	cmpl	%r15d, %r12d
   111d8:      	seta	%sil
   111dc:      	movl	%r15d, %ecx
   111df:      	cmovbl	%r12d, %ecx
   111e3:      	addl	%ecx, %esi
   111e5:      	movl	%r12d, %edi
   111e8:      	subl	%esi, %edi
   111ea:      	movl	%edi, 0x50(%rsp)
   111ee:      	subq	%rsi, %rax
   111f1:      	jb	0x167a2 <generic_lsm_path+0xba72>
   111f7:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   111fd:      	ja	0x167a2 <generic_lsm_path+0xba72>
   11203:      	cmpl	%r15d, %r12d
   11206:      	jbe	0x1120c <generic_lsm_path+0x64dc>
   11208:      	movb	$0x2f, (%rbx,%rax)
   1120c:      	xorl	%edi, %edi
   1120e:      	cmpl	%r15d, %r12d
   11211:      	seta	%dil
   11215:      	movzbl	%cl, %esi
   11218:      	addq	%rax, %rbx
   1121b:      	addq	%rbx, %rdi
   1121e:      	movl	$0x4, %eax
   11223:      	callq	*%rax
   11225:      	movq	%rbx, 0x48(%rsp)
   1122a:      	cmpl	%r15d, %r12d
   1122d:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   11233:      	movq	0x8(%rsp), %r12
   11238:      	movq	%r12, 0x30(%rsp)
   1123d:      	movq	0x38(%rsp), %rdx
   11242:      	movq	0x40(%rsp), %r15
   11247:      	jmp	0x1129a <generic_lsm_path+0x656a>
   11249:      	leaq	0x10(%r15), %rdx
   1124d:      	movl	$0x4, %eax
   11252:      	movq	%rbp, %rdi
   11255:      	movl	$0x8, %esi
   1125a:      	callq	*%rax
   1125c:      	movq	0x40(%rsp), %rax
   11261:      	cmpq	(%rsp), %rax
   11265:      	je	0x1679d <generic_lsm_path+0xba6d>
   1126b:      	addq	$0x18, %r15
   1126f:      	movl	$0x4, %eax
   11274:      	leaq	0x30(%rsp), %rdi
   11279:      	movl	$0x8, %esi
   1127e:      	movq	%r15, %rdx
   11281:      	callq	*%rax
   11283:      	movq	(%rsp), %r15
   11287:      	movq	%r15, 0x40(%rsp)
   1128c:      	leaq	0x20(%r15), %rdx
   11290:      	movq	%rdx, 0x38(%rsp)
   11295:      	movq	0x30(%rsp), %r12
   1129a:      	cmpq	0x18(%rsp), %r12
   1129f:      	jne	0x112ac <generic_lsm_path+0x657c>
   112a1:      	cmpq	0x20(%rsp), %rdx
   112a6:      	je	0x1679d <generic_lsm_path+0xba6d>
   112ac:      	movl	$0x4, %eax
   112b1:      	leaq	0x10(%rsp), %rdi
   112b6:      	movl	$0x8, %esi
   112bb:      	callq	*%rax
   112bd:      	cmpq	0x10(%rsp), %r12
   112c2:      	je	0x113ba <generic_lsm_path+0x668a>
   112c8:      	leaq	0x18(%r12), %rbx
   112cd:      	movl	$0x4, %eax
   112d2:      	movq	%rbp, %rdi
   112d5:      	movl	$0x8, %esi
   112da:      	movq	%rbx, %rdx
   112dd:      	callq	*%rax
   112df:      	cmpq	%r12, (%rsp)
   112e3:      	je	0x113ba <generic_lsm_path+0x668a>
   112e9:      	movl	$0x4, %eax
   112ee:      	leaq	0x8(%rsp), %rdi
   112f3:      	movl	$0x8, %esi
   112f8:      	movq	%rbx, %rdx
   112fb:      	callq	*%rax
   112fd:      	addq	$0x20, %r12
   11301:      	movl	$0x4, %eax
   11306:      	leaq	0x58(%rsp), %rdi
   1130b:      	movl	$0x10, %ecx
   11310:      	movl	$0x10, %esi
   11315:      	movq	%r12, %rdx
   11318:      	callq	*%rax
   1131a:      	movq	0x28(%rsp), %rbx
   1131f:      	movq	0x48(%rsp), %rax
   11324:      	movl	0x5c(%rsp), %r15d
   11329:      	subq	%rbx, %rax
   1132c:      	movl	0x50(%rsp), %r12d
   11331:      	movl	%r15d, %edx
   11334:      	subl	%r12d, %edx
   11337:      	movl	$0x0, %ecx
   1133c:      	cmovbl	%ecx, %edx
   1133f:      	addq	0x60(%rsp), %rdx
   11344:      	xorl	%esi, %esi
   11346:      	cmpl	%r15d, %r12d
   11349:      	seta	%sil
   1134d:      	movl	%r15d, %ecx
   11350:      	cmovbl	%r12d, %ecx
   11354:      	addl	%ecx, %esi
   11356:      	movl	%r12d, %edi
   11359:      	subl	%esi, %edi
   1135b:      	movl	%edi, 0x50(%rsp)
   1135f:      	subq	%rsi, %rax
   11362:      	jb	0x167a2 <generic_lsm_path+0xba72>
   11368:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1136e:      	ja	0x167a2 <generic_lsm_path+0xba72>
   11374:      	cmpl	%r15d, %r12d
   11377:      	jbe	0x1137d <generic_lsm_path+0x664d>
   11379:      	movb	$0x2f, (%rbx,%rax)
   1137d:      	xorl	%edi, %edi
   1137f:      	cmpl	%r15d, %r12d
   11382:      	seta	%dil
   11386:      	movzbl	%cl, %esi
   11389:      	addq	%rax, %rbx
   1138c:      	addq	%rbx, %rdi
   1138f:      	movl	$0x4, %eax
   11394:      	callq	*%rax
   11396:      	movq	%rbx, 0x48(%rsp)
   1139b:      	cmpl	%r15d, %r12d
   1139e:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   113a4:      	movq	0x8(%rsp), %r12
   113a9:      	movq	%r12, 0x30(%rsp)
   113ae:      	movq	0x38(%rsp), %rdx
   113b3:      	movq	0x40(%rsp), %r15
   113b8:      	jmp	0x1140b <generic_lsm_path+0x66db>
   113ba:      	leaq	0x10(%r15), %rdx
   113be:      	movl	$0x4, %eax
   113c3:      	movq	%rbp, %rdi
   113c6:      	movl	$0x8, %esi
   113cb:      	callq	*%rax
   113cd:      	movq	0x40(%rsp), %rax
   113d2:      	cmpq	(%rsp), %rax
   113d6:      	je	0x1679d <generic_lsm_path+0xba6d>
   113dc:      	addq	$0x18, %r15
   113e0:      	movl	$0x4, %eax
   113e5:      	leaq	0x30(%rsp), %rdi
   113ea:      	movl	$0x8, %esi
   113ef:      	movq	%r15, %rdx
   113f2:      	callq	*%rax
   113f4:      	movq	(%rsp), %r15
   113f8:      	movq	%r15, 0x40(%rsp)
   113fd:      	leaq	0x20(%r15), %rdx
   11401:      	movq	%rdx, 0x38(%rsp)
   11406:      	movq	0x30(%rsp), %r12
   1140b:      	cmpq	0x18(%rsp), %r12
   11410:      	jne	0x1141d <generic_lsm_path+0x66ed>
   11412:      	cmpq	0x20(%rsp), %rdx
   11417:      	je	0x1679d <generic_lsm_path+0xba6d>
   1141d:      	movl	$0x4, %eax
   11422:      	leaq	0x10(%rsp), %rdi
   11427:      	movl	$0x8, %esi
   1142c:      	callq	*%rax
   1142e:      	cmpq	0x10(%rsp), %r12
   11433:      	je	0x1152b <generic_lsm_path+0x67fb>
   11439:      	leaq	0x18(%r12), %rbx
   1143e:      	movl	$0x4, %eax
   11443:      	movq	%rbp, %rdi
   11446:      	movl	$0x8, %esi
   1144b:      	movq	%rbx, %rdx
   1144e:      	callq	*%rax
   11450:      	cmpq	%r12, (%rsp)
   11454:      	je	0x1152b <generic_lsm_path+0x67fb>
   1145a:      	movl	$0x4, %eax
   1145f:      	leaq	0x8(%rsp), %rdi
   11464:      	movl	$0x8, %esi
   11469:      	movq	%rbx, %rdx
   1146c:      	callq	*%rax
   1146e:      	addq	$0x20, %r12
   11472:      	movl	$0x4, %eax
   11477:      	leaq	0x58(%rsp), %rdi
   1147c:      	movl	$0x10, %ecx
   11481:      	movl	$0x10, %esi
   11486:      	movq	%r12, %rdx
   11489:      	callq	*%rax
   1148b:      	movq	0x28(%rsp), %rbx
   11490:      	movq	0x48(%rsp), %rax
   11495:      	movl	0x5c(%rsp), %r15d
   1149a:      	subq	%rbx, %rax
   1149d:      	movl	0x50(%rsp), %r12d
   114a2:      	movl	%r15d, %edx
   114a5:      	subl	%r12d, %edx
   114a8:      	movl	$0x0, %ecx
   114ad:      	cmovbl	%ecx, %edx
   114b0:      	addq	0x60(%rsp), %rdx
   114b5:      	xorl	%esi, %esi
   114b7:      	cmpl	%r15d, %r12d
   114ba:      	seta	%sil
   114be:      	movl	%r15d, %ecx
   114c1:      	cmovbl	%r12d, %ecx
   114c5:      	addl	%ecx, %esi
   114c7:      	movl	%r12d, %edi
   114ca:      	subl	%esi, %edi
   114cc:      	movl	%edi, 0x50(%rsp)
   114d0:      	subq	%rsi, %rax
   114d3:      	jb	0x167a2 <generic_lsm_path+0xba72>
   114d9:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   114df:      	ja	0x167a2 <generic_lsm_path+0xba72>
   114e5:      	cmpl	%r15d, %r12d
   114e8:      	jbe	0x114ee <generic_lsm_path+0x67be>
   114ea:      	movb	$0x2f, (%rbx,%rax)
   114ee:      	xorl	%edi, %edi
   114f0:      	cmpl	%r15d, %r12d
   114f3:      	seta	%dil
   114f7:      	movzbl	%cl, %esi
   114fa:      	addq	%rax, %rbx
   114fd:      	addq	%rbx, %rdi
   11500:      	movl	$0x4, %eax
   11505:      	callq	*%rax
   11507:      	movq	%rbx, 0x48(%rsp)
   1150c:      	cmpl	%r15d, %r12d
   1150f:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   11515:      	movq	0x8(%rsp), %r12
   1151a:      	movq	%r12, 0x30(%rsp)
   1151f:      	movq	0x38(%rsp), %rdx
   11524:      	movq	0x40(%rsp), %r15
   11529:      	jmp	0x1157c <generic_lsm_path+0x684c>
   1152b:      	leaq	0x10(%r15), %rdx
   1152f:      	movl	$0x4, %eax
   11534:      	movq	%rbp, %rdi
   11537:      	movl	$0x8, %esi
   1153c:      	callq	*%rax
   1153e:      	movq	0x40(%rsp), %rax
   11543:      	cmpq	(%rsp), %rax
   11547:      	je	0x1679d <generic_lsm_path+0xba6d>
   1154d:      	addq	$0x18, %r15
   11551:      	movl	$0x4, %eax
   11556:      	leaq	0x30(%rsp), %rdi
   1155b:      	movl	$0x8, %esi
   11560:      	movq	%r15, %rdx
   11563:      	callq	*%rax
   11565:      	movq	(%rsp), %r15
   11569:      	movq	%r15, 0x40(%rsp)
   1156e:      	leaq	0x20(%r15), %rdx
   11572:      	movq	%rdx, 0x38(%rsp)
   11577:      	movq	0x30(%rsp), %r12
   1157c:      	cmpq	0x18(%rsp), %r12
   11581:      	jne	0x1158e <generic_lsm_path+0x685e>
   11583:      	cmpq	0x20(%rsp), %rdx
   11588:      	je	0x1679d <generic_lsm_path+0xba6d>
   1158e:      	movl	$0x4, %eax
   11593:      	leaq	0x10(%rsp), %rdi
   11598:      	movl	$0x8, %esi
   1159d:      	callq	*%rax
   1159f:      	cmpq	0x10(%rsp), %r12
   115a4:      	je	0x1169c <generic_lsm_path+0x696c>
   115aa:      	leaq	0x18(%r12), %rbx
   115af:      	movl	$0x4, %eax
   115b4:      	movq	%rbp, %rdi
   115b7:      	movl	$0x8, %esi
   115bc:      	movq	%rbx, %rdx
   115bf:      	callq	*%rax
   115c1:      	cmpq	%r12, (%rsp)
   115c5:      	je	0x1169c <generic_lsm_path+0x696c>
   115cb:      	movl	$0x4, %eax
   115d0:      	leaq	0x8(%rsp), %rdi
   115d5:      	movl	$0x8, %esi
   115da:      	movq	%rbx, %rdx
   115dd:      	callq	*%rax
   115df:      	addq	$0x20, %r12
   115e3:      	movl	$0x4, %eax
   115e8:      	leaq	0x58(%rsp), %rdi
   115ed:      	movl	$0x10, %ecx
   115f2:      	movl	$0x10, %esi
   115f7:      	movq	%r12, %rdx
   115fa:      	callq	*%rax
   115fc:      	movq	0x28(%rsp), %rbx
   11601:      	movq	0x48(%rsp), %rax
   11606:      	movl	0x5c(%rsp), %r15d
   1160b:      	subq	%rbx, %rax
   1160e:      	movl	0x50(%rsp), %r12d
   11613:      	movl	%r15d, %edx
   11616:      	subl	%r12d, %edx
   11619:      	movl	$0x0, %ecx
   1161e:      	cmovbl	%ecx, %edx
   11621:      	addq	0x60(%rsp), %rdx
   11626:      	xorl	%esi, %esi
   11628:      	cmpl	%r15d, %r12d
   1162b:      	seta	%sil
   1162f:      	movl	%r15d, %ecx
   11632:      	cmovbl	%r12d, %ecx
   11636:      	addl	%ecx, %esi
   11638:      	movl	%r12d, %edi
   1163b:      	subl	%esi, %edi
   1163d:      	movl	%edi, 0x50(%rsp)
   11641:      	subq	%rsi, %rax
   11644:      	jb	0x167a2 <generic_lsm_path+0xba72>
   1164a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11650:      	ja	0x167a2 <generic_lsm_path+0xba72>
   11656:      	cmpl	%r15d, %r12d
   11659:      	jbe	0x1165f <generic_lsm_path+0x692f>
   1165b:      	movb	$0x2f, (%rbx,%rax)
   1165f:      	xorl	%edi, %edi
   11661:      	cmpl	%r15d, %r12d
   11664:      	seta	%dil
   11668:      	movzbl	%cl, %esi
   1166b:      	addq	%rax, %rbx
   1166e:      	addq	%rbx, %rdi
   11671:      	movl	$0x4, %eax
   11676:      	callq	*%rax
   11678:      	movq	%rbx, 0x48(%rsp)
   1167d:      	cmpl	%r15d, %r12d
   11680:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   11686:      	movq	0x8(%rsp), %r12
   1168b:      	movq	%r12, 0x30(%rsp)
   11690:      	movq	0x38(%rsp), %rdx
   11695:      	movq	0x40(%rsp), %r15
   1169a:      	jmp	0x116ed <generic_lsm_path+0x69bd>
   1169c:      	leaq	0x10(%r15), %rdx
   116a0:      	movl	$0x4, %eax
   116a5:      	movq	%rbp, %rdi
   116a8:      	movl	$0x8, %esi
   116ad:      	callq	*%rax
   116af:      	movq	0x40(%rsp), %rax
   116b4:      	cmpq	(%rsp), %rax
   116b8:      	je	0x1679d <generic_lsm_path+0xba6d>
   116be:      	addq	$0x18, %r15
   116c2:      	movl	$0x4, %eax
   116c7:      	leaq	0x30(%rsp), %rdi
   116cc:      	movl	$0x8, %esi
   116d1:      	movq	%r15, %rdx
   116d4:      	callq	*%rax
   116d6:      	movq	(%rsp), %r15
   116da:      	movq	%r15, 0x40(%rsp)
   116df:      	leaq	0x20(%r15), %rdx
   116e3:      	movq	%rdx, 0x38(%rsp)
   116e8:      	movq	0x30(%rsp), %r12
   116ed:      	cmpq	0x18(%rsp), %r12
   116f2:      	jne	0x116ff <generic_lsm_path+0x69cf>
   116f4:      	cmpq	0x20(%rsp), %rdx
   116f9:      	je	0x1679d <generic_lsm_path+0xba6d>
   116ff:      	movl	$0x4, %eax
   11704:      	leaq	0x10(%rsp), %rdi
   11709:      	movl	$0x8, %esi
   1170e:      	callq	*%rax
   11710:      	cmpq	0x10(%rsp), %r12
   11715:      	je	0x1180d <generic_lsm_path+0x6add>
   1171b:      	leaq	0x18(%r12), %rbx
   11720:      	movl	$0x4, %eax
   11725:      	movq	%rbp, %rdi
   11728:      	movl	$0x8, %esi
   1172d:      	movq	%rbx, %rdx
   11730:      	callq	*%rax
   11732:      	cmpq	%r12, (%rsp)
   11736:      	je	0x1180d <generic_lsm_path+0x6add>
   1173c:      	movl	$0x4, %eax
   11741:      	leaq	0x8(%rsp), %rdi
   11746:      	movl	$0x8, %esi
   1174b:      	movq	%rbx, %rdx
   1174e:      	callq	*%rax
   11750:      	addq	$0x20, %r12
   11754:      	movl	$0x4, %eax
   11759:      	leaq	0x58(%rsp), %rdi
   1175e:      	movl	$0x10, %ecx
   11763:      	movl	$0x10, %esi
   11768:      	movq	%r12, %rdx
   1176b:      	callq	*%rax
   1176d:      	movq	0x28(%rsp), %rbx
   11772:      	movq	0x48(%rsp), %rax
   11777:      	movl	0x5c(%rsp), %r15d
   1177c:      	subq	%rbx, %rax
   1177f:      	movl	0x50(%rsp), %r12d
   11784:      	movl	%r15d, %edx
   11787:      	subl	%r12d, %edx
   1178a:      	movl	$0x0, %ecx
   1178f:      	cmovbl	%ecx, %edx
   11792:      	addq	0x60(%rsp), %rdx
   11797:      	xorl	%esi, %esi
   11799:      	cmpl	%r15d, %r12d
   1179c:      	seta	%sil
   117a0:      	movl	%r15d, %ecx
   117a3:      	cmovbl	%r12d, %ecx
   117a7:      	addl	%ecx, %esi
   117a9:      	movl	%r12d, %edi
   117ac:      	subl	%esi, %edi
   117ae:      	movl	%edi, 0x50(%rsp)
   117b2:      	subq	%rsi, %rax
   117b5:      	jb	0x167a2 <generic_lsm_path+0xba72>
   117bb:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   117c1:      	ja	0x167a2 <generic_lsm_path+0xba72>
   117c7:      	cmpl	%r15d, %r12d
   117ca:      	jbe	0x117d0 <generic_lsm_path+0x6aa0>
   117cc:      	movb	$0x2f, (%rbx,%rax)
   117d0:      	xorl	%edi, %edi
   117d2:      	cmpl	%r15d, %r12d
   117d5:      	seta	%dil
   117d9:      	movzbl	%cl, %esi
   117dc:      	addq	%rax, %rbx
   117df:      	addq	%rbx, %rdi
   117e2:      	movl	$0x4, %eax
   117e7:      	callq	*%rax
   117e9:      	movq	%rbx, 0x48(%rsp)
   117ee:      	cmpl	%r15d, %r12d
   117f1:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   117f7:      	movq	0x8(%rsp), %r12
   117fc:      	movq	%r12, 0x30(%rsp)
   11801:      	movq	0x38(%rsp), %rdx
   11806:      	movq	0x40(%rsp), %r15
   1180b:      	jmp	0x1185e <generic_lsm_path+0x6b2e>
   1180d:      	leaq	0x10(%r15), %rdx
   11811:      	movl	$0x4, %eax
   11816:      	movq	%rbp, %rdi
   11819:      	movl	$0x8, %esi
   1181e:      	callq	*%rax
   11820:      	movq	0x40(%rsp), %rax
   11825:      	cmpq	(%rsp), %rax
   11829:      	je	0x1679d <generic_lsm_path+0xba6d>
   1182f:      	addq	$0x18, %r15
   11833:      	movl	$0x4, %eax
   11838:      	leaq	0x30(%rsp), %rdi
   1183d:      	movl	$0x8, %esi
   11842:      	movq	%r15, %rdx
   11845:      	callq	*%rax
   11847:      	movq	(%rsp), %r15
   1184b:      	movq	%r15, 0x40(%rsp)
   11850:      	leaq	0x20(%r15), %rdx
   11854:      	movq	%rdx, 0x38(%rsp)
   11859:      	movq	0x30(%rsp), %r12
   1185e:      	cmpq	0x18(%rsp), %r12
   11863:      	jne	0x11870 <generic_lsm_path+0x6b40>
   11865:      	cmpq	0x20(%rsp), %rdx
   1186a:      	je	0x1679d <generic_lsm_path+0xba6d>
   11870:      	movl	$0x4, %eax
   11875:      	leaq	0x10(%rsp), %rdi
   1187a:      	movl	$0x8, %esi
   1187f:      	callq	*%rax
   11881:      	cmpq	0x10(%rsp), %r12
   11886:      	je	0x1197e <generic_lsm_path+0x6c4e>
   1188c:      	leaq	0x18(%r12), %rbx
   11891:      	movl	$0x4, %eax
   11896:      	movq	%rbp, %rdi
   11899:      	movl	$0x8, %esi
   1189e:      	movq	%rbx, %rdx
   118a1:      	callq	*%rax
   118a3:      	cmpq	%r12, (%rsp)
   118a7:      	je	0x1197e <generic_lsm_path+0x6c4e>
   118ad:      	movl	$0x4, %eax
   118b2:      	leaq	0x8(%rsp), %rdi
   118b7:      	movl	$0x8, %esi
   118bc:      	movq	%rbx, %rdx
   118bf:      	callq	*%rax
   118c1:      	addq	$0x20, %r12
   118c5:      	movl	$0x4, %eax
   118ca:      	leaq	0x58(%rsp), %rdi
   118cf:      	movl	$0x10, %ecx
   118d4:      	movl	$0x10, %esi
   118d9:      	movq	%r12, %rdx
   118dc:      	callq	*%rax
   118de:      	movq	0x28(%rsp), %rbx
   118e3:      	movq	0x48(%rsp), %rax
   118e8:      	movl	0x5c(%rsp), %r15d
   118ed:      	subq	%rbx, %rax
   118f0:      	movl	0x50(%rsp), %r12d
   118f5:      	movl	%r15d, %edx
   118f8:      	subl	%r12d, %edx
   118fb:      	movl	$0x0, %ecx
   11900:      	cmovbl	%ecx, %edx
   11903:      	addq	0x60(%rsp), %rdx
   11908:      	xorl	%esi, %esi
   1190a:      	cmpl	%r15d, %r12d
   1190d:      	seta	%sil
   11911:      	movl	%r15d, %ecx
   11914:      	cmovbl	%r12d, %ecx
   11918:      	addl	%ecx, %esi
   1191a:      	movl	%r12d, %edi
   1191d:      	subl	%esi, %edi
   1191f:      	movl	%edi, 0x50(%rsp)
   11923:      	subq	%rsi, %rax
   11926:      	jb	0x167a2 <generic_lsm_path+0xba72>
   1192c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11932:      	ja	0x167a2 <generic_lsm_path+0xba72>
   11938:      	cmpl	%r15d, %r12d
   1193b:      	jbe	0x11941 <generic_lsm_path+0x6c11>
   1193d:      	movb	$0x2f, (%rbx,%rax)
   11941:      	xorl	%edi, %edi
   11943:      	cmpl	%r15d, %r12d
   11946:      	seta	%dil
   1194a:      	movzbl	%cl, %esi
   1194d:      	addq	%rax, %rbx
   11950:      	addq	%rbx, %rdi
   11953:      	movl	$0x4, %eax
   11958:      	callq	*%rax
   1195a:      	movq	%rbx, 0x48(%rsp)
   1195f:      	cmpl	%r15d, %r12d
   11962:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   11968:      	movq	0x8(%rsp), %r12
   1196d:      	movq	%r12, 0x30(%rsp)
   11972:      	movq	0x38(%rsp), %rdx
   11977:      	movq	0x40(%rsp), %r15
   1197c:      	jmp	0x119cf <generic_lsm_path+0x6c9f>
   1197e:      	leaq	0x10(%r15), %rdx
   11982:      	movl	$0x4, %eax
   11987:      	movq	%rbp, %rdi
   1198a:      	movl	$0x8, %esi
   1198f:      	callq	*%rax
   11991:      	movq	0x40(%rsp), %rax
   11996:      	cmpq	(%rsp), %rax
   1199a:      	je	0x1679d <generic_lsm_path+0xba6d>
   119a0:      	addq	$0x18, %r15
   119a4:      	movl	$0x4, %eax
   119a9:      	leaq	0x30(%rsp), %rdi
   119ae:      	movl	$0x8, %esi
   119b3:      	movq	%r15, %rdx
   119b6:      	callq	*%rax
   119b8:      	movq	(%rsp), %r15
   119bc:      	movq	%r15, 0x40(%rsp)
   119c1:      	leaq	0x20(%r15), %rdx
   119c5:      	movq	%rdx, 0x38(%rsp)
   119ca:      	movq	0x30(%rsp), %r12
   119cf:      	cmpq	0x18(%rsp), %r12
   119d4:      	jne	0x119e1 <generic_lsm_path+0x6cb1>
   119d6:      	cmpq	0x20(%rsp), %rdx
   119db:      	je	0x1679d <generic_lsm_path+0xba6d>
   119e1:      	movl	$0x4, %eax
   119e6:      	leaq	0x10(%rsp), %rdi
   119eb:      	movl	$0x8, %esi
   119f0:      	callq	*%rax
   119f2:      	cmpq	0x10(%rsp), %r12
   119f7:      	je	0x11aef <generic_lsm_path+0x6dbf>
   119fd:      	leaq	0x18(%r12), %rbx
   11a02:      	movl	$0x4, %eax
   11a07:      	movq	%rbp, %rdi
   11a0a:      	movl	$0x8, %esi
   11a0f:      	movq	%rbx, %rdx
   11a12:      	callq	*%rax
   11a14:      	cmpq	%r12, (%rsp)
   11a18:      	je	0x11aef <generic_lsm_path+0x6dbf>
   11a1e:      	movl	$0x4, %eax
   11a23:      	leaq	0x8(%rsp), %rdi
   11a28:      	movl	$0x8, %esi
   11a2d:      	movq	%rbx, %rdx
   11a30:      	callq	*%rax
   11a32:      	addq	$0x20, %r12
   11a36:      	movl	$0x4, %eax
   11a3b:      	leaq	0x58(%rsp), %rdi
   11a40:      	movl	$0x10, %ecx
   11a45:      	movl	$0x10, %esi
   11a4a:      	movq	%r12, %rdx
   11a4d:      	callq	*%rax
   11a4f:      	movq	0x28(%rsp), %rbx
   11a54:      	movq	0x48(%rsp), %rax
   11a59:      	movl	0x5c(%rsp), %r15d
   11a5e:      	subq	%rbx, %rax
   11a61:      	movl	0x50(%rsp), %r12d
   11a66:      	movl	%r15d, %edx
   11a69:      	subl	%r12d, %edx
   11a6c:      	movl	$0x0, %ecx
   11a71:      	cmovbl	%ecx, %edx
   11a74:      	addq	0x60(%rsp), %rdx
   11a79:      	xorl	%esi, %esi
   11a7b:      	cmpl	%r15d, %r12d
   11a7e:      	seta	%sil
   11a82:      	movl	%r15d, %ecx
   11a85:      	cmovbl	%r12d, %ecx
   11a89:      	addl	%ecx, %esi
   11a8b:      	movl	%r12d, %edi
   11a8e:      	subl	%esi, %edi
   11a90:      	movl	%edi, 0x50(%rsp)
   11a94:      	subq	%rsi, %rax
   11a97:      	jb	0x167a2 <generic_lsm_path+0xba72>
   11a9d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11aa3:      	ja	0x167a2 <generic_lsm_path+0xba72>
   11aa9:      	cmpl	%r15d, %r12d
   11aac:      	jbe	0x11ab2 <generic_lsm_path+0x6d82>
   11aae:      	movb	$0x2f, (%rbx,%rax)
   11ab2:      	xorl	%edi, %edi
   11ab4:      	cmpl	%r15d, %r12d
   11ab7:      	seta	%dil
   11abb:      	movzbl	%cl, %esi
   11abe:      	addq	%rax, %rbx
   11ac1:      	addq	%rbx, %rdi
   11ac4:      	movl	$0x4, %eax
   11ac9:      	callq	*%rax
   11acb:      	movq	%rbx, 0x48(%rsp)
   11ad0:      	cmpl	%r15d, %r12d
   11ad3:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   11ad9:      	movq	0x8(%rsp), %r12
   11ade:      	movq	%r12, 0x30(%rsp)
   11ae3:      	movq	0x38(%rsp), %rdx
   11ae8:      	movq	0x40(%rsp), %r15
   11aed:      	jmp	0x11b40 <generic_lsm_path+0x6e10>
   11aef:      	leaq	0x10(%r15), %rdx
   11af3:      	movl	$0x4, %eax
   11af8:      	movq	%rbp, %rdi
   11afb:      	movl	$0x8, %esi
   11b00:      	callq	*%rax
   11b02:      	movq	0x40(%rsp), %rax
   11b07:      	cmpq	(%rsp), %rax
   11b0b:      	je	0x1679d <generic_lsm_path+0xba6d>
   11b11:      	addq	$0x18, %r15
   11b15:      	movl	$0x4, %eax
   11b1a:      	leaq	0x30(%rsp), %rdi
   11b1f:      	movl	$0x8, %esi
   11b24:      	movq	%r15, %rdx
   11b27:      	callq	*%rax
   11b29:      	movq	(%rsp), %r15
   11b2d:      	movq	%r15, 0x40(%rsp)
   11b32:      	leaq	0x20(%r15), %rdx
   11b36:      	movq	%rdx, 0x38(%rsp)
   11b3b:      	movq	0x30(%rsp), %r12
   11b40:      	cmpq	0x18(%rsp), %r12
   11b45:      	jne	0x11b52 <generic_lsm_path+0x6e22>
   11b47:      	cmpq	0x20(%rsp), %rdx
   11b4c:      	je	0x1679d <generic_lsm_path+0xba6d>
   11b52:      	movl	$0x4, %eax
   11b57:      	leaq	0x10(%rsp), %rdi
   11b5c:      	movl	$0x8, %esi
   11b61:      	callq	*%rax
   11b63:      	cmpq	0x10(%rsp), %r12
   11b68:      	je	0x11c60 <generic_lsm_path+0x6f30>
   11b6e:      	leaq	0x18(%r12), %rbx
   11b73:      	movl	$0x4, %eax
   11b78:      	movq	%rbp, %rdi
   11b7b:      	movl	$0x8, %esi
   11b80:      	movq	%rbx, %rdx
   11b83:      	callq	*%rax
   11b85:      	cmpq	%r12, (%rsp)
   11b89:      	je	0x11c60 <generic_lsm_path+0x6f30>
   11b8f:      	movl	$0x4, %eax
   11b94:      	leaq	0x8(%rsp), %rdi
   11b99:      	movl	$0x8, %esi
   11b9e:      	movq	%rbx, %rdx
   11ba1:      	callq	*%rax
   11ba3:      	addq	$0x20, %r12
   11ba7:      	movl	$0x4, %eax
   11bac:      	leaq	0x58(%rsp), %rdi
   11bb1:      	movl	$0x10, %ecx
   11bb6:      	movl	$0x10, %esi
   11bbb:      	movq	%r12, %rdx
   11bbe:      	callq	*%rax
   11bc0:      	movq	0x28(%rsp), %rbx
   11bc5:      	movq	0x48(%rsp), %rax
   11bca:      	movl	0x5c(%rsp), %r15d
   11bcf:      	subq	%rbx, %rax
   11bd2:      	movl	0x50(%rsp), %r12d
   11bd7:      	movl	%r15d, %edx
   11bda:      	subl	%r12d, %edx
   11bdd:      	movl	$0x0, %ecx
   11be2:      	cmovbl	%ecx, %edx
   11be5:      	addq	0x60(%rsp), %rdx
   11bea:      	xorl	%esi, %esi
   11bec:      	cmpl	%r15d, %r12d
   11bef:      	seta	%sil
   11bf3:      	movl	%r15d, %ecx
   11bf6:      	cmovbl	%r12d, %ecx
   11bfa:      	addl	%ecx, %esi
   11bfc:      	movl	%r12d, %edi
   11bff:      	subl	%esi, %edi
   11c01:      	movl	%edi, 0x50(%rsp)
   11c05:      	subq	%rsi, %rax
   11c08:      	jb	0x167a2 <generic_lsm_path+0xba72>
   11c0e:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11c14:      	ja	0x167a2 <generic_lsm_path+0xba72>
   11c1a:      	cmpl	%r15d, %r12d
   11c1d:      	jbe	0x11c23 <generic_lsm_path+0x6ef3>
   11c1f:      	movb	$0x2f, (%rbx,%rax)
   11c23:      	xorl	%edi, %edi
   11c25:      	cmpl	%r15d, %r12d
   11c28:      	seta	%dil
   11c2c:      	movzbl	%cl, %esi
   11c2f:      	addq	%rax, %rbx
   11c32:      	addq	%rbx, %rdi
   11c35:      	movl	$0x4, %eax
   11c3a:      	callq	*%rax
   11c3c:      	movq	%rbx, 0x48(%rsp)
   11c41:      	cmpl	%r15d, %r12d
   11c44:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   11c4a:      	movq	0x8(%rsp), %r12
   11c4f:      	movq	%r12, 0x30(%rsp)
   11c54:      	movq	0x38(%rsp), %rdx
   11c59:      	movq	0x40(%rsp), %r15
   11c5e:      	jmp	0x11cb1 <generic_lsm_path+0x6f81>
   11c60:      	leaq	0x10(%r15), %rdx
   11c64:      	movl	$0x4, %eax
   11c69:      	movq	%rbp, %rdi
   11c6c:      	movl	$0x8, %esi
   11c71:      	callq	*%rax
   11c73:      	movq	0x40(%rsp), %rax
   11c78:      	cmpq	(%rsp), %rax
   11c7c:      	je	0x1679d <generic_lsm_path+0xba6d>
   11c82:      	addq	$0x18, %r15
   11c86:      	movl	$0x4, %eax
   11c8b:      	leaq	0x30(%rsp), %rdi
   11c90:      	movl	$0x8, %esi
   11c95:      	movq	%r15, %rdx
   11c98:      	callq	*%rax
   11c9a:      	movq	(%rsp), %r15
   11c9e:      	movq	%r15, 0x40(%rsp)
   11ca3:      	leaq	0x20(%r15), %rdx
   11ca7:      	movq	%rdx, 0x38(%rsp)
   11cac:      	movq	0x30(%rsp), %r12
   11cb1:      	cmpq	0x18(%rsp), %r12
   11cb6:      	jne	0x11cc3 <generic_lsm_path+0x6f93>
   11cb8:      	cmpq	0x20(%rsp), %rdx
   11cbd:      	je	0x1679d <generic_lsm_path+0xba6d>
   11cc3:      	movl	$0x4, %eax
   11cc8:      	leaq	0x10(%rsp), %rdi
   11ccd:      	movl	$0x8, %esi
   11cd2:      	callq	*%rax
   11cd4:      	cmpq	0x10(%rsp), %r12
   11cd9:      	je	0x11dd1 <generic_lsm_path+0x70a1>
   11cdf:      	leaq	0x18(%r12), %rbx
   11ce4:      	movl	$0x4, %eax
   11ce9:      	movq	%rbp, %rdi
   11cec:      	movl	$0x8, %esi
   11cf1:      	movq	%rbx, %rdx
   11cf4:      	callq	*%rax
   11cf6:      	cmpq	%r12, (%rsp)
   11cfa:      	je	0x11dd1 <generic_lsm_path+0x70a1>
   11d00:      	movl	$0x4, %eax
   11d05:      	leaq	0x8(%rsp), %rdi
   11d0a:      	movl	$0x8, %esi
   11d0f:      	movq	%rbx, %rdx
   11d12:      	callq	*%rax
   11d14:      	addq	$0x20, %r12
   11d18:      	movl	$0x4, %eax
   11d1d:      	leaq	0x58(%rsp), %rdi
   11d22:      	movl	$0x10, %ecx
   11d27:      	movl	$0x10, %esi
   11d2c:      	movq	%r12, %rdx
   11d2f:      	callq	*%rax
   11d31:      	movq	0x28(%rsp), %rbx
   11d36:      	movq	0x48(%rsp), %rax
   11d3b:      	movl	0x5c(%rsp), %r15d
   11d40:      	subq	%rbx, %rax
   11d43:      	movl	0x50(%rsp), %r12d
   11d48:      	movl	%r15d, %edx
   11d4b:      	subl	%r12d, %edx
   11d4e:      	movl	$0x0, %ecx
   11d53:      	cmovbl	%ecx, %edx
   11d56:      	addq	0x60(%rsp), %rdx
   11d5b:      	xorl	%esi, %esi
   11d5d:      	cmpl	%r15d, %r12d
   11d60:      	seta	%sil
   11d64:      	movl	%r15d, %ecx
   11d67:      	cmovbl	%r12d, %ecx
   11d6b:      	addl	%ecx, %esi
   11d6d:      	movl	%r12d, %edi
   11d70:      	subl	%esi, %edi
   11d72:      	movl	%edi, 0x50(%rsp)
   11d76:      	subq	%rsi, %rax
   11d79:      	jb	0x167a2 <generic_lsm_path+0xba72>
   11d7f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11d85:      	ja	0x167a2 <generic_lsm_path+0xba72>
   11d8b:      	cmpl	%r15d, %r12d
   11d8e:      	jbe	0x11d94 <generic_lsm_path+0x7064>
   11d90:      	movb	$0x2f, (%rbx,%rax)
   11d94:      	xorl	%edi, %edi
   11d96:      	cmpl	%r15d, %r12d
   11d99:      	seta	%dil
   11d9d:      	movzbl	%cl, %esi
   11da0:      	addq	%rax, %rbx
   11da3:      	addq	%rbx, %rdi
   11da6:      	movl	$0x4, %eax
   11dab:      	callq	*%rax
   11dad:      	movq	%rbx, 0x48(%rsp)
   11db2:      	cmpl	%r15d, %r12d
   11db5:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   11dbb:      	movq	0x8(%rsp), %r12
   11dc0:      	movq	%r12, 0x30(%rsp)
   11dc5:      	movq	0x38(%rsp), %rdx
   11dca:      	movq	0x40(%rsp), %r15
   11dcf:      	jmp	0x11e22 <generic_lsm_path+0x70f2>
   11dd1:      	leaq	0x10(%r15), %rdx
   11dd5:      	movl	$0x4, %eax
   11dda:      	movq	%rbp, %rdi
   11ddd:      	movl	$0x8, %esi
   11de2:      	callq	*%rax
   11de4:      	movq	0x40(%rsp), %rax
   11de9:      	cmpq	(%rsp), %rax
   11ded:      	je	0x1679d <generic_lsm_path+0xba6d>
   11df3:      	addq	$0x18, %r15
   11df7:      	movl	$0x4, %eax
   11dfc:      	leaq	0x30(%rsp), %rdi
   11e01:      	movl	$0x8, %esi
   11e06:      	movq	%r15, %rdx
   11e09:      	callq	*%rax
   11e0b:      	movq	(%rsp), %r15
   11e0f:      	movq	%r15, 0x40(%rsp)
   11e14:      	leaq	0x20(%r15), %rdx
   11e18:      	movq	%rdx, 0x38(%rsp)
   11e1d:      	movq	0x30(%rsp), %r12
   11e22:      	cmpq	0x18(%rsp), %r12
   11e27:      	jne	0x11e34 <generic_lsm_path+0x7104>
   11e29:      	cmpq	0x20(%rsp), %rdx
   11e2e:      	je	0x1679d <generic_lsm_path+0xba6d>
   11e34:      	movl	$0x4, %eax
   11e39:      	leaq	0x10(%rsp), %rdi
   11e3e:      	movl	$0x8, %esi
   11e43:      	callq	*%rax
   11e45:      	cmpq	0x10(%rsp), %r12
   11e4a:      	je	0x11f42 <generic_lsm_path+0x7212>
   11e50:      	leaq	0x18(%r12), %rbx
   11e55:      	movl	$0x4, %eax
   11e5a:      	movq	%rbp, %rdi
   11e5d:      	movl	$0x8, %esi
   11e62:      	movq	%rbx, %rdx
   11e65:      	callq	*%rax
   11e67:      	cmpq	%r12, (%rsp)
   11e6b:      	je	0x11f42 <generic_lsm_path+0x7212>
   11e71:      	movl	$0x4, %eax
   11e76:      	leaq	0x8(%rsp), %rdi
   11e7b:      	movl	$0x8, %esi
   11e80:      	movq	%rbx, %rdx
   11e83:      	callq	*%rax
   11e85:      	addq	$0x20, %r12
   11e89:      	movl	$0x4, %eax
   11e8e:      	leaq	0x58(%rsp), %rdi
   11e93:      	movl	$0x10, %ecx
   11e98:      	movl	$0x10, %esi
   11e9d:      	movq	%r12, %rdx
   11ea0:      	callq	*%rax
   11ea2:      	movq	0x28(%rsp), %rbx
   11ea7:      	movq	0x48(%rsp), %rax
   11eac:      	movl	0x5c(%rsp), %r15d
   11eb1:      	subq	%rbx, %rax
   11eb4:      	movl	0x50(%rsp), %r12d
   11eb9:      	movl	%r15d, %edx
   11ebc:      	subl	%r12d, %edx
   11ebf:      	movl	$0x0, %ecx
   11ec4:      	cmovbl	%ecx, %edx
   11ec7:      	addq	0x60(%rsp), %rdx
   11ecc:      	xorl	%esi, %esi
   11ece:      	cmpl	%r15d, %r12d
   11ed1:      	seta	%sil
   11ed5:      	movl	%r15d, %ecx
   11ed8:      	cmovbl	%r12d, %ecx
   11edc:      	addl	%ecx, %esi
   11ede:      	movl	%r12d, %edi
   11ee1:      	subl	%esi, %edi
   11ee3:      	movl	%edi, 0x50(%rsp)
   11ee7:      	subq	%rsi, %rax
   11eea:      	jb	0x167a2 <generic_lsm_path+0xba72>
   11ef0:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11ef6:      	ja	0x167a2 <generic_lsm_path+0xba72>
   11efc:      	cmpl	%r15d, %r12d
   11eff:      	jbe	0x11f05 <generic_lsm_path+0x71d5>
   11f01:      	movb	$0x2f, (%rbx,%rax)
   11f05:      	xorl	%edi, %edi
   11f07:      	cmpl	%r15d, %r12d
   11f0a:      	seta	%dil
   11f0e:      	movzbl	%cl, %esi
   11f11:      	addq	%rax, %rbx
   11f14:      	addq	%rbx, %rdi
   11f17:      	movl	$0x4, %eax
   11f1c:      	callq	*%rax
   11f1e:      	movq	%rbx, 0x48(%rsp)
   11f23:      	cmpl	%r15d, %r12d
   11f26:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   11f2c:      	movq	0x8(%rsp), %r12
   11f31:      	movq	%r12, 0x30(%rsp)
   11f36:      	movq	0x38(%rsp), %rdx
   11f3b:      	movq	0x40(%rsp), %r15
   11f40:      	jmp	0x11f93 <generic_lsm_path+0x7263>
   11f42:      	leaq	0x10(%r15), %rdx
   11f46:      	movl	$0x4, %eax
   11f4b:      	movq	%rbp, %rdi
   11f4e:      	movl	$0x8, %esi
   11f53:      	callq	*%rax
   11f55:      	movq	0x40(%rsp), %rax
   11f5a:      	cmpq	(%rsp), %rax
   11f5e:      	je	0x1679d <generic_lsm_path+0xba6d>
   11f64:      	addq	$0x18, %r15
   11f68:      	movl	$0x4, %eax
   11f6d:      	leaq	0x30(%rsp), %rdi
   11f72:      	movl	$0x8, %esi
   11f77:      	movq	%r15, %rdx
   11f7a:      	callq	*%rax
   11f7c:      	movq	(%rsp), %r15
   11f80:      	movq	%r15, 0x40(%rsp)
   11f85:      	leaq	0x20(%r15), %rdx
   11f89:      	movq	%rdx, 0x38(%rsp)
   11f8e:      	movq	0x30(%rsp), %r12
   11f93:      	cmpq	0x18(%rsp), %r12
   11f98:      	jne	0x11fa5 <generic_lsm_path+0x7275>
   11f9a:      	cmpq	0x20(%rsp), %rdx
   11f9f:      	je	0x1679d <generic_lsm_path+0xba6d>
   11fa5:      	movl	$0x4, %eax
   11faa:      	leaq	0x10(%rsp), %rdi
   11faf:      	movl	$0x8, %esi
   11fb4:      	callq	*%rax
   11fb6:      	cmpq	0x10(%rsp), %r12
   11fbb:      	je	0x120b3 <generic_lsm_path+0x7383>
   11fc1:      	leaq	0x18(%r12), %rbx
   11fc6:      	movl	$0x4, %eax
   11fcb:      	movq	%rbp, %rdi
   11fce:      	movl	$0x8, %esi
   11fd3:      	movq	%rbx, %rdx
   11fd6:      	callq	*%rax
   11fd8:      	cmpq	%r12, (%rsp)
   11fdc:      	je	0x120b3 <generic_lsm_path+0x7383>
   11fe2:      	movl	$0x4, %eax
   11fe7:      	leaq	0x8(%rsp), %rdi
   11fec:      	movl	$0x8, %esi
   11ff1:      	movq	%rbx, %rdx
   11ff4:      	callq	*%rax
   11ff6:      	addq	$0x20, %r12
   11ffa:      	movl	$0x4, %eax
   11fff:      	leaq	0x58(%rsp), %rdi
   12004:      	movl	$0x10, %ecx
   12009:      	movl	$0x10, %esi
   1200e:      	movq	%r12, %rdx
   12011:      	callq	*%rax
   12013:      	movq	0x28(%rsp), %rbx
   12018:      	movq	0x48(%rsp), %rax
   1201d:      	movl	0x5c(%rsp), %r15d
   12022:      	subq	%rbx, %rax
   12025:      	movl	0x50(%rsp), %r12d
   1202a:      	movl	%r15d, %edx
   1202d:      	subl	%r12d, %edx
   12030:      	movl	$0x0, %ecx
   12035:      	cmovbl	%ecx, %edx
   12038:      	addq	0x60(%rsp), %rdx
   1203d:      	xorl	%esi, %esi
   1203f:      	cmpl	%r15d, %r12d
   12042:      	seta	%sil
   12046:      	movl	%r15d, %ecx
   12049:      	cmovbl	%r12d, %ecx
   1204d:      	addl	%ecx, %esi
   1204f:      	movl	%r12d, %edi
   12052:      	subl	%esi, %edi
   12054:      	movl	%edi, 0x50(%rsp)
   12058:      	subq	%rsi, %rax
   1205b:      	jb	0x167a2 <generic_lsm_path+0xba72>
   12061:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12067:      	ja	0x167a2 <generic_lsm_path+0xba72>
   1206d:      	cmpl	%r15d, %r12d
   12070:      	jbe	0x12076 <generic_lsm_path+0x7346>
   12072:      	movb	$0x2f, (%rbx,%rax)
   12076:      	xorl	%edi, %edi
   12078:      	cmpl	%r15d, %r12d
   1207b:      	seta	%dil
   1207f:      	movzbl	%cl, %esi
   12082:      	addq	%rax, %rbx
   12085:      	addq	%rbx, %rdi
   12088:      	movl	$0x4, %eax
   1208d:      	callq	*%rax
   1208f:      	movq	%rbx, 0x48(%rsp)
   12094:      	cmpl	%r15d, %r12d
   12097:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   1209d:      	movq	0x8(%rsp), %r12
   120a2:      	movq	%r12, 0x30(%rsp)
   120a7:      	movq	0x38(%rsp), %rdx
   120ac:      	movq	0x40(%rsp), %r15
   120b1:      	jmp	0x12104 <generic_lsm_path+0x73d4>
   120b3:      	leaq	0x10(%r15), %rdx
   120b7:      	movl	$0x4, %eax
   120bc:      	movq	%rbp, %rdi
   120bf:      	movl	$0x8, %esi
   120c4:      	callq	*%rax
   120c6:      	movq	0x40(%rsp), %rax
   120cb:      	cmpq	(%rsp), %rax
   120cf:      	je	0x1679d <generic_lsm_path+0xba6d>
   120d5:      	addq	$0x18, %r15
   120d9:      	movl	$0x4, %eax
   120de:      	leaq	0x30(%rsp), %rdi
   120e3:      	movl	$0x8, %esi
   120e8:      	movq	%r15, %rdx
   120eb:      	callq	*%rax
   120ed:      	movq	(%rsp), %r15
   120f1:      	movq	%r15, 0x40(%rsp)
   120f6:      	leaq	0x20(%r15), %rdx
   120fa:      	movq	%rdx, 0x38(%rsp)
   120ff:      	movq	0x30(%rsp), %r12
   12104:      	cmpq	0x18(%rsp), %r12
   12109:      	jne	0x12116 <generic_lsm_path+0x73e6>
   1210b:      	cmpq	0x20(%rsp), %rdx
   12110:      	je	0x1679d <generic_lsm_path+0xba6d>
   12116:      	movl	$0x4, %eax
   1211b:      	leaq	0x10(%rsp), %rdi
   12120:      	movl	$0x8, %esi
   12125:      	callq	*%rax
   12127:      	cmpq	0x10(%rsp), %r12
   1212c:      	je	0x12224 <generic_lsm_path+0x74f4>
   12132:      	leaq	0x18(%r12), %rbx
   12137:      	movl	$0x4, %eax
   1213c:      	movq	%rbp, %rdi
   1213f:      	movl	$0x8, %esi
   12144:      	movq	%rbx, %rdx
   12147:      	callq	*%rax
   12149:      	cmpq	%r12, (%rsp)
   1214d:      	je	0x12224 <generic_lsm_path+0x74f4>
   12153:      	movl	$0x4, %eax
   12158:      	leaq	0x8(%rsp), %rdi
   1215d:      	movl	$0x8, %esi
   12162:      	movq	%rbx, %rdx
   12165:      	callq	*%rax
   12167:      	addq	$0x20, %r12
   1216b:      	movl	$0x4, %eax
   12170:      	leaq	0x58(%rsp), %rdi
   12175:      	movl	$0x10, %ecx
   1217a:      	movl	$0x10, %esi
   1217f:      	movq	%r12, %rdx
   12182:      	callq	*%rax
   12184:      	movq	0x28(%rsp), %rbx
   12189:      	movq	0x48(%rsp), %rax
   1218e:      	movl	0x5c(%rsp), %r15d
   12193:      	subq	%rbx, %rax
   12196:      	movl	0x50(%rsp), %r12d
   1219b:      	movl	%r15d, %edx
   1219e:      	subl	%r12d, %edx
   121a1:      	movl	$0x0, %ecx
   121a6:      	cmovbl	%ecx, %edx
   121a9:      	addq	0x60(%rsp), %rdx
   121ae:      	xorl	%esi, %esi
   121b0:      	cmpl	%r15d, %r12d
   121b3:      	seta	%sil
   121b7:      	movl	%r15d, %ecx
   121ba:      	cmovbl	%r12d, %ecx
   121be:      	addl	%ecx, %esi
   121c0:      	movl	%r12d, %edi
   121c3:      	subl	%esi, %edi
   121c5:      	movl	%edi, 0x50(%rsp)
   121c9:      	subq	%rsi, %rax
   121cc:      	jb	0x167a2 <generic_lsm_path+0xba72>
   121d2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   121d8:      	ja	0x167a2 <generic_lsm_path+0xba72>
   121de:      	cmpl	%r15d, %r12d
   121e1:      	jbe	0x121e7 <generic_lsm_path+0x74b7>
   121e3:      	movb	$0x2f, (%rbx,%rax)
   121e7:      	xorl	%edi, %edi
   121e9:      	cmpl	%r15d, %r12d
   121ec:      	seta	%dil
   121f0:      	movzbl	%cl, %esi
   121f3:      	addq	%rax, %rbx
   121f6:      	addq	%rbx, %rdi
   121f9:      	movl	$0x4, %eax
   121fe:      	callq	*%rax
   12200:      	movq	%rbx, 0x48(%rsp)
   12205:      	cmpl	%r15d, %r12d
   12208:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   1220e:      	movq	0x8(%rsp), %r12
   12213:      	movq	%r12, 0x30(%rsp)
   12218:      	movq	0x38(%rsp), %rdx
   1221d:      	movq	0x40(%rsp), %r15
   12222:      	jmp	0x12275 <generic_lsm_path+0x7545>
   12224:      	leaq	0x10(%r15), %rdx
   12228:      	movl	$0x4, %eax
   1222d:      	movq	%rbp, %rdi
   12230:      	movl	$0x8, %esi
   12235:      	callq	*%rax
   12237:      	movq	0x40(%rsp), %rax
   1223c:      	cmpq	(%rsp), %rax
   12240:      	je	0x1679d <generic_lsm_path+0xba6d>
   12246:      	addq	$0x18, %r15
   1224a:      	movl	$0x4, %eax
   1224f:      	leaq	0x30(%rsp), %rdi
   12254:      	movl	$0x8, %esi
   12259:      	movq	%r15, %rdx
   1225c:      	callq	*%rax
   1225e:      	movq	(%rsp), %r15
   12262:      	movq	%r15, 0x40(%rsp)
   12267:      	leaq	0x20(%r15), %rdx
   1226b:      	movq	%rdx, 0x38(%rsp)
   12270:      	movq	0x30(%rsp), %r12
   12275:      	cmpq	0x18(%rsp), %r12
   1227a:      	jne	0x12287 <generic_lsm_path+0x7557>
   1227c:      	cmpq	0x20(%rsp), %rdx
   12281:      	je	0x1679d <generic_lsm_path+0xba6d>
   12287:      	movl	$0x4, %eax
   1228c:      	leaq	0x10(%rsp), %rdi
   12291:      	movl	$0x8, %esi
   12296:      	callq	*%rax
   12298:      	cmpq	0x10(%rsp), %r12
   1229d:      	je	0x12395 <generic_lsm_path+0x7665>
   122a3:      	leaq	0x18(%r12), %rbx
   122a8:      	movl	$0x4, %eax
   122ad:      	movq	%rbp, %rdi
   122b0:      	movl	$0x8, %esi
   122b5:      	movq	%rbx, %rdx
   122b8:      	callq	*%rax
   122ba:      	cmpq	%r12, (%rsp)
   122be:      	je	0x12395 <generic_lsm_path+0x7665>
   122c4:      	movl	$0x4, %eax
   122c9:      	leaq	0x8(%rsp), %rdi
   122ce:      	movl	$0x8, %esi
   122d3:      	movq	%rbx, %rdx
   122d6:      	callq	*%rax
   122d8:      	addq	$0x20, %r12
   122dc:      	movl	$0x4, %eax
   122e1:      	leaq	0x58(%rsp), %rdi
   122e6:      	movl	$0x10, %ecx
   122eb:      	movl	$0x10, %esi
   122f0:      	movq	%r12, %rdx
   122f3:      	callq	*%rax
   122f5:      	movq	0x28(%rsp), %rbx
   122fa:      	movq	0x48(%rsp), %rax
   122ff:      	movl	0x5c(%rsp), %r15d
   12304:      	subq	%rbx, %rax
   12307:      	movl	0x50(%rsp), %r12d
   1230c:      	movl	%r15d, %edx
   1230f:      	subl	%r12d, %edx
   12312:      	movl	$0x0, %ecx
   12317:      	cmovbl	%ecx, %edx
   1231a:      	addq	0x60(%rsp), %rdx
   1231f:      	xorl	%esi, %esi
   12321:      	cmpl	%r15d, %r12d
   12324:      	seta	%sil
   12328:      	movl	%r15d, %ecx
   1232b:      	cmovbl	%r12d, %ecx
   1232f:      	addl	%ecx, %esi
   12331:      	movl	%r12d, %edi
   12334:      	subl	%esi, %edi
   12336:      	movl	%edi, 0x50(%rsp)
   1233a:      	subq	%rsi, %rax
   1233d:      	jb	0x167a2 <generic_lsm_path+0xba72>
   12343:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12349:      	ja	0x167a2 <generic_lsm_path+0xba72>
   1234f:      	cmpl	%r15d, %r12d
   12352:      	jbe	0x12358 <generic_lsm_path+0x7628>
   12354:      	movb	$0x2f, (%rbx,%rax)
   12358:      	xorl	%edi, %edi
   1235a:      	cmpl	%r15d, %r12d
   1235d:      	seta	%dil
   12361:      	movzbl	%cl, %esi
   12364:      	addq	%rax, %rbx
   12367:      	addq	%rbx, %rdi
   1236a:      	movl	$0x4, %eax
   1236f:      	callq	*%rax
   12371:      	movq	%rbx, 0x48(%rsp)
   12376:      	cmpl	%r15d, %r12d
   12379:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   1237f:      	movq	0x8(%rsp), %r12
   12384:      	movq	%r12, 0x30(%rsp)
   12389:      	movq	0x38(%rsp), %rdx
   1238e:      	movq	0x40(%rsp), %r15
   12393:      	jmp	0x123e6 <generic_lsm_path+0x76b6>
   12395:      	leaq	0x10(%r15), %rdx
   12399:      	movl	$0x4, %eax
   1239e:      	movq	%rbp, %rdi
   123a1:      	movl	$0x8, %esi
   123a6:      	callq	*%rax
   123a8:      	movq	0x40(%rsp), %rax
   123ad:      	cmpq	(%rsp), %rax
   123b1:      	je	0x1679d <generic_lsm_path+0xba6d>
   123b7:      	addq	$0x18, %r15
   123bb:      	movl	$0x4, %eax
   123c0:      	leaq	0x30(%rsp), %rdi
   123c5:      	movl	$0x8, %esi
   123ca:      	movq	%r15, %rdx
   123cd:      	callq	*%rax
   123cf:      	movq	(%rsp), %r15
   123d3:      	movq	%r15, 0x40(%rsp)
   123d8:      	leaq	0x20(%r15), %rdx
   123dc:      	movq	%rdx, 0x38(%rsp)
   123e1:      	movq	0x30(%rsp), %r12
   123e6:      	cmpq	0x18(%rsp), %r12
   123eb:      	jne	0x123f8 <generic_lsm_path+0x76c8>
   123ed:      	cmpq	0x20(%rsp), %rdx
   123f2:      	je	0x1679d <generic_lsm_path+0xba6d>
   123f8:      	movl	$0x4, %eax
   123fd:      	leaq	0x10(%rsp), %rdi
   12402:      	movl	$0x8, %esi
   12407:      	callq	*%rax
   12409:      	cmpq	0x10(%rsp), %r12
   1240e:      	je	0x12506 <generic_lsm_path+0x77d6>
   12414:      	leaq	0x18(%r12), %rbx
   12419:      	movl	$0x4, %eax
   1241e:      	movq	%rbp, %rdi
   12421:      	movl	$0x8, %esi
   12426:      	movq	%rbx, %rdx
   12429:      	callq	*%rax
   1242b:      	cmpq	%r12, (%rsp)
   1242f:      	je	0x12506 <generic_lsm_path+0x77d6>
   12435:      	movl	$0x4, %eax
   1243a:      	leaq	0x8(%rsp), %rdi
   1243f:      	movl	$0x8, %esi
   12444:      	movq	%rbx, %rdx
   12447:      	callq	*%rax
   12449:      	addq	$0x20, %r12
   1244d:      	movl	$0x4, %eax
   12452:      	leaq	0x58(%rsp), %rdi
   12457:      	movl	$0x10, %ecx
   1245c:      	movl	$0x10, %esi
   12461:      	movq	%r12, %rdx
   12464:      	callq	*%rax
   12466:      	movq	0x28(%rsp), %rbx
   1246b:      	movq	0x48(%rsp), %rax
   12470:      	movl	0x5c(%rsp), %r15d
   12475:      	subq	%rbx, %rax
   12478:      	movl	0x50(%rsp), %r12d
   1247d:      	movl	%r15d, %edx
   12480:      	subl	%r12d, %edx
   12483:      	movl	$0x0, %ecx
   12488:      	cmovbl	%ecx, %edx
   1248b:      	addq	0x60(%rsp), %rdx
   12490:      	xorl	%esi, %esi
   12492:      	cmpl	%r15d, %r12d
   12495:      	seta	%sil
   12499:      	movl	%r15d, %ecx
   1249c:      	cmovbl	%r12d, %ecx
   124a0:      	addl	%ecx, %esi
   124a2:      	movl	%r12d, %edi
   124a5:      	subl	%esi, %edi
   124a7:      	movl	%edi, 0x50(%rsp)
   124ab:      	subq	%rsi, %rax
   124ae:      	jb	0x167a2 <generic_lsm_path+0xba72>
   124b4:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   124ba:      	ja	0x167a2 <generic_lsm_path+0xba72>
   124c0:      	cmpl	%r15d, %r12d
   124c3:      	jbe	0x124c9 <generic_lsm_path+0x7799>
   124c5:      	movb	$0x2f, (%rbx,%rax)
   124c9:      	xorl	%edi, %edi
   124cb:      	cmpl	%r15d, %r12d
   124ce:      	seta	%dil
   124d2:      	movzbl	%cl, %esi
   124d5:      	addq	%rax, %rbx
   124d8:      	addq	%rbx, %rdi
   124db:      	movl	$0x4, %eax
   124e0:      	callq	*%rax
   124e2:      	movq	%rbx, 0x48(%rsp)
   124e7:      	cmpl	%r15d, %r12d
   124ea:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   124f0:      	movq	0x8(%rsp), %r12
   124f5:      	movq	%r12, 0x30(%rsp)
   124fa:      	movq	0x38(%rsp), %rdx
   124ff:      	movq	0x40(%rsp), %r15
   12504:      	jmp	0x12557 <generic_lsm_path+0x7827>
   12506:      	leaq	0x10(%r15), %rdx
   1250a:      	movl	$0x4, %eax
   1250f:      	movq	%rbp, %rdi
   12512:      	movl	$0x8, %esi
   12517:      	callq	*%rax
   12519:      	movq	0x40(%rsp), %rax
   1251e:      	cmpq	(%rsp), %rax
   12522:      	je	0x1679d <generic_lsm_path+0xba6d>
   12528:      	addq	$0x18, %r15
   1252c:      	movl	$0x4, %eax
   12531:      	leaq	0x30(%rsp), %rdi
   12536:      	movl	$0x8, %esi
   1253b:      	movq	%r15, %rdx
   1253e:      	callq	*%rax
   12540:      	movq	(%rsp), %r15
   12544:      	movq	%r15, 0x40(%rsp)
   12549:      	leaq	0x20(%r15), %rdx
   1254d:      	movq	%rdx, 0x38(%rsp)
   12552:      	movq	0x30(%rsp), %r12
   12557:      	cmpq	0x18(%rsp), %r12
   1255c:      	jne	0x12569 <generic_lsm_path+0x7839>
   1255e:      	cmpq	0x20(%rsp), %rdx
   12563:      	je	0x1679d <generic_lsm_path+0xba6d>
   12569:      	movl	$0x4, %eax
   1256e:      	leaq	0x10(%rsp), %rdi
   12573:      	movl	$0x8, %esi
   12578:      	callq	*%rax
   1257a:      	cmpq	0x10(%rsp), %r12
   1257f:      	je	0x12677 <generic_lsm_path+0x7947>
   12585:      	leaq	0x18(%r12), %rbx
   1258a:      	movl	$0x4, %eax
   1258f:      	movq	%rbp, %rdi
   12592:      	movl	$0x8, %esi
   12597:      	movq	%rbx, %rdx
   1259a:      	callq	*%rax
   1259c:      	cmpq	%r12, (%rsp)
   125a0:      	je	0x12677 <generic_lsm_path+0x7947>
   125a6:      	movl	$0x4, %eax
   125ab:      	leaq	0x8(%rsp), %rdi
   125b0:      	movl	$0x8, %esi
   125b5:      	movq	%rbx, %rdx
   125b8:      	callq	*%rax
   125ba:      	addq	$0x20, %r12
   125be:      	movl	$0x4, %eax
   125c3:      	leaq	0x58(%rsp), %rdi
   125c8:      	movl	$0x10, %ecx
   125cd:      	movl	$0x10, %esi
   125d2:      	movq	%r12, %rdx
   125d5:      	callq	*%rax
   125d7:      	movq	0x28(%rsp), %rbx
   125dc:      	movq	0x48(%rsp), %rax
   125e1:      	movl	0x5c(%rsp), %r15d
   125e6:      	subq	%rbx, %rax
   125e9:      	movl	0x50(%rsp), %r12d
   125ee:      	movl	%r15d, %edx
   125f1:      	subl	%r12d, %edx
   125f4:      	movl	$0x0, %ecx
   125f9:      	cmovbl	%ecx, %edx
   125fc:      	addq	0x60(%rsp), %rdx
   12601:      	xorl	%esi, %esi
   12603:      	cmpl	%r15d, %r12d
   12606:      	seta	%sil
   1260a:      	movl	%r15d, %ecx
   1260d:      	cmovbl	%r12d, %ecx
   12611:      	addl	%ecx, %esi
   12613:      	movl	%r12d, %edi
   12616:      	subl	%esi, %edi
   12618:      	movl	%edi, 0x50(%rsp)
   1261c:      	subq	%rsi, %rax
   1261f:      	jb	0x167a2 <generic_lsm_path+0xba72>
   12625:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1262b:      	ja	0x167a2 <generic_lsm_path+0xba72>
   12631:      	cmpl	%r15d, %r12d
   12634:      	jbe	0x1263a <generic_lsm_path+0x790a>
   12636:      	movb	$0x2f, (%rbx,%rax)
   1263a:      	xorl	%edi, %edi
   1263c:      	cmpl	%r15d, %r12d
   1263f:      	seta	%dil
   12643:      	movzbl	%cl, %esi
   12646:      	addq	%rax, %rbx
   12649:      	addq	%rbx, %rdi
   1264c:      	movl	$0x4, %eax
   12651:      	callq	*%rax
   12653:      	movq	%rbx, 0x48(%rsp)
   12658:      	cmpl	%r15d, %r12d
   1265b:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   12661:      	movq	0x8(%rsp), %r12
   12666:      	movq	%r12, 0x30(%rsp)
   1266b:      	movq	0x38(%rsp), %rdx
   12670:      	movq	0x40(%rsp), %r15
   12675:      	jmp	0x126c8 <generic_lsm_path+0x7998>
   12677:      	leaq	0x10(%r15), %rdx
   1267b:      	movl	$0x4, %eax
   12680:      	movq	%rbp, %rdi
   12683:      	movl	$0x8, %esi
   12688:      	callq	*%rax
   1268a:      	movq	0x40(%rsp), %rax
   1268f:      	cmpq	(%rsp), %rax
   12693:      	je	0x1679d <generic_lsm_path+0xba6d>
   12699:      	addq	$0x18, %r15
   1269d:      	movl	$0x4, %eax
   126a2:      	leaq	0x30(%rsp), %rdi
   126a7:      	movl	$0x8, %esi
   126ac:      	movq	%r15, %rdx
   126af:      	callq	*%rax
   126b1:      	movq	(%rsp), %r15
   126b5:      	movq	%r15, 0x40(%rsp)
   126ba:      	leaq	0x20(%r15), %rdx
   126be:      	movq	%rdx, 0x38(%rsp)
   126c3:      	movq	0x30(%rsp), %r12
   126c8:      	cmpq	0x18(%rsp), %r12
   126cd:      	jne	0x126da <generic_lsm_path+0x79aa>
   126cf:      	cmpq	0x20(%rsp), %rdx
   126d4:      	je	0x1679d <generic_lsm_path+0xba6d>
   126da:      	movl	$0x4, %eax
   126df:      	leaq	0x10(%rsp), %rdi
   126e4:      	movl	$0x8, %esi
   126e9:      	callq	*%rax
   126eb:      	cmpq	0x10(%rsp), %r12
   126f0:      	je	0x127e8 <generic_lsm_path+0x7ab8>
   126f6:      	leaq	0x18(%r12), %rbx
   126fb:      	movl	$0x4, %eax
   12700:      	movq	%rbp, %rdi
   12703:      	movl	$0x8, %esi
   12708:      	movq	%rbx, %rdx
   1270b:      	callq	*%rax
   1270d:      	cmpq	%r12, (%rsp)
   12711:      	je	0x127e8 <generic_lsm_path+0x7ab8>
   12717:      	movl	$0x4, %eax
   1271c:      	leaq	0x8(%rsp), %rdi
   12721:      	movl	$0x8, %esi
   12726:      	movq	%rbx, %rdx
   12729:      	callq	*%rax
   1272b:      	addq	$0x20, %r12
   1272f:      	movl	$0x4, %eax
   12734:      	leaq	0x58(%rsp), %rdi
   12739:      	movl	$0x10, %ecx
   1273e:      	movl	$0x10, %esi
   12743:      	movq	%r12, %rdx
   12746:      	callq	*%rax
   12748:      	movq	0x28(%rsp), %rbx
   1274d:      	movq	0x48(%rsp), %rax
   12752:      	movl	0x5c(%rsp), %r15d
   12757:      	subq	%rbx, %rax
   1275a:      	movl	0x50(%rsp), %r12d
   1275f:      	movl	%r15d, %edx
   12762:      	subl	%r12d, %edx
   12765:      	movl	$0x0, %ecx
   1276a:      	cmovbl	%ecx, %edx
   1276d:      	addq	0x60(%rsp), %rdx
   12772:      	xorl	%esi, %esi
   12774:      	cmpl	%r15d, %r12d
   12777:      	seta	%sil
   1277b:      	movl	%r15d, %ecx
   1277e:      	cmovbl	%r12d, %ecx
   12782:      	addl	%ecx, %esi
   12784:      	movl	%r12d, %edi
   12787:      	subl	%esi, %edi
   12789:      	movl	%edi, 0x50(%rsp)
   1278d:      	subq	%rsi, %rax
   12790:      	jb	0x167a2 <generic_lsm_path+0xba72>
   12796:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1279c:      	ja	0x167a2 <generic_lsm_path+0xba72>
   127a2:      	cmpl	%r15d, %r12d
   127a5:      	jbe	0x127ab <generic_lsm_path+0x7a7b>
   127a7:      	movb	$0x2f, (%rbx,%rax)
   127ab:      	xorl	%edi, %edi
   127ad:      	cmpl	%r15d, %r12d
   127b0:      	seta	%dil
   127b4:      	movzbl	%cl, %esi
   127b7:      	addq	%rax, %rbx
   127ba:      	addq	%rbx, %rdi
   127bd:      	movl	$0x4, %eax
   127c2:      	callq	*%rax
   127c4:      	movq	%rbx, 0x48(%rsp)
   127c9:      	cmpl	%r15d, %r12d
   127cc:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   127d2:      	movq	0x8(%rsp), %r12
   127d7:      	movq	%r12, 0x30(%rsp)
   127dc:      	movq	0x38(%rsp), %rdx
   127e1:      	movq	0x40(%rsp), %r15
   127e6:      	jmp	0x12839 <generic_lsm_path+0x7b09>
   127e8:      	leaq	0x10(%r15), %rdx
   127ec:      	movl	$0x4, %eax
   127f1:      	movq	%rbp, %rdi
   127f4:      	movl	$0x8, %esi
   127f9:      	callq	*%rax
   127fb:      	movq	0x40(%rsp), %rax
   12800:      	cmpq	(%rsp), %rax
   12804:      	je	0x1679d <generic_lsm_path+0xba6d>
   1280a:      	addq	$0x18, %r15
   1280e:      	movl	$0x4, %eax
   12813:      	leaq	0x30(%rsp), %rdi
   12818:      	movl	$0x8, %esi
   1281d:      	movq	%r15, %rdx
   12820:      	callq	*%rax
   12822:      	movq	(%rsp), %r15
   12826:      	movq	%r15, 0x40(%rsp)
   1282b:      	leaq	0x20(%r15), %rdx
   1282f:      	movq	%rdx, 0x38(%rsp)
   12834:      	movq	0x30(%rsp), %r12
   12839:      	cmpq	0x18(%rsp), %r12
   1283e:      	jne	0x1284b <generic_lsm_path+0x7b1b>
   12840:      	cmpq	0x20(%rsp), %rdx
   12845:      	je	0x1679d <generic_lsm_path+0xba6d>
   1284b:      	movl	$0x4, %eax
   12850:      	leaq	0x10(%rsp), %rdi
   12855:      	movl	$0x8, %esi
   1285a:      	callq	*%rax
   1285c:      	cmpq	0x10(%rsp), %r12
   12861:      	je	0x12959 <generic_lsm_path+0x7c29>
   12867:      	leaq	0x18(%r12), %rbx
   1286c:      	movl	$0x4, %eax
   12871:      	movq	%rbp, %rdi
   12874:      	movl	$0x8, %esi
   12879:      	movq	%rbx, %rdx
   1287c:      	callq	*%rax
   1287e:      	cmpq	%r12, (%rsp)
   12882:      	je	0x12959 <generic_lsm_path+0x7c29>
   12888:      	movl	$0x4, %eax
   1288d:      	leaq	0x8(%rsp), %rdi
   12892:      	movl	$0x8, %esi
   12897:      	movq	%rbx, %rdx
   1289a:      	callq	*%rax
   1289c:      	addq	$0x20, %r12
   128a0:      	movl	$0x4, %eax
   128a5:      	leaq	0x58(%rsp), %rdi
   128aa:      	movl	$0x10, %ecx
   128af:      	movl	$0x10, %esi
   128b4:      	movq	%r12, %rdx
   128b7:      	callq	*%rax
   128b9:      	movq	0x28(%rsp), %rbx
   128be:      	movq	0x48(%rsp), %rax
   128c3:      	movl	0x5c(%rsp), %r15d
   128c8:      	subq	%rbx, %rax
   128cb:      	movl	0x50(%rsp), %r12d
   128d0:      	movl	%r15d, %edx
   128d3:      	subl	%r12d, %edx
   128d6:      	movl	$0x0, %ecx
   128db:      	cmovbl	%ecx, %edx
   128de:      	addq	0x60(%rsp), %rdx
   128e3:      	xorl	%esi, %esi
   128e5:      	cmpl	%r15d, %r12d
   128e8:      	seta	%sil
   128ec:      	movl	%r15d, %ecx
   128ef:      	cmovbl	%r12d, %ecx
   128f3:      	addl	%ecx, %esi
   128f5:      	movl	%r12d, %edi
   128f8:      	subl	%esi, %edi
   128fa:      	movl	%edi, 0x50(%rsp)
   128fe:      	subq	%rsi, %rax
   12901:      	jb	0x167a2 <generic_lsm_path+0xba72>
   12907:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1290d:      	ja	0x167a2 <generic_lsm_path+0xba72>
   12913:      	cmpl	%r15d, %r12d
   12916:      	jbe	0x1291c <generic_lsm_path+0x7bec>
   12918:      	movb	$0x2f, (%rbx,%rax)
   1291c:      	xorl	%edi, %edi
   1291e:      	cmpl	%r15d, %r12d
   12921:      	seta	%dil
   12925:      	movzbl	%cl, %esi
   12928:      	addq	%rax, %rbx
   1292b:      	addq	%rbx, %rdi
   1292e:      	movl	$0x4, %eax
   12933:      	callq	*%rax
   12935:      	movq	%rbx, 0x48(%rsp)
   1293a:      	cmpl	%r15d, %r12d
   1293d:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   12943:      	movq	0x8(%rsp), %r12
   12948:      	movq	%r12, 0x30(%rsp)
   1294d:      	movq	0x38(%rsp), %rdx
   12952:      	movq	0x40(%rsp), %r15
   12957:      	jmp	0x129aa <generic_lsm_path+0x7c7a>
   12959:      	leaq	0x10(%r15), %rdx
   1295d:      	movl	$0x4, %eax
   12962:      	movq	%rbp, %rdi
   12965:      	movl	$0x8, %esi
   1296a:      	callq	*%rax
   1296c:      	movq	0x40(%rsp), %rax
   12971:      	cmpq	(%rsp), %rax
   12975:      	je	0x1679d <generic_lsm_path+0xba6d>
   1297b:      	addq	$0x18, %r15
   1297f:      	movl	$0x4, %eax
   12984:      	leaq	0x30(%rsp), %rdi
   12989:      	movl	$0x8, %esi
   1298e:      	movq	%r15, %rdx
   12991:      	callq	*%rax
   12993:      	movq	(%rsp), %r15
   12997:      	movq	%r15, 0x40(%rsp)
   1299c:      	leaq	0x20(%r15), %rdx
   129a0:      	movq	%rdx, 0x38(%rsp)
   129a5:      	movq	0x30(%rsp), %r12
   129aa:      	cmpq	0x18(%rsp), %r12
   129af:      	jne	0x129bc <generic_lsm_path+0x7c8c>
   129b1:      	cmpq	0x20(%rsp), %rdx
   129b6:      	je	0x1679d <generic_lsm_path+0xba6d>
   129bc:      	movl	$0x4, %eax
   129c1:      	leaq	0x10(%rsp), %rdi
   129c6:      	movl	$0x8, %esi
   129cb:      	callq	*%rax
   129cd:      	cmpq	0x10(%rsp), %r12
   129d2:      	je	0x12aca <generic_lsm_path+0x7d9a>
   129d8:      	leaq	0x18(%r12), %rbx
   129dd:      	movl	$0x4, %eax
   129e2:      	movq	%rbp, %rdi
   129e5:      	movl	$0x8, %esi
   129ea:      	movq	%rbx, %rdx
   129ed:      	callq	*%rax
   129ef:      	cmpq	%r12, (%rsp)
   129f3:      	je	0x12aca <generic_lsm_path+0x7d9a>
   129f9:      	movl	$0x4, %eax
   129fe:      	leaq	0x8(%rsp), %rdi
   12a03:      	movl	$0x8, %esi
   12a08:      	movq	%rbx, %rdx
   12a0b:      	callq	*%rax
   12a0d:      	addq	$0x20, %r12
   12a11:      	movl	$0x4, %eax
   12a16:      	leaq	0x58(%rsp), %rdi
   12a1b:      	movl	$0x10, %ecx
   12a20:      	movl	$0x10, %esi
   12a25:      	movq	%r12, %rdx
   12a28:      	callq	*%rax
   12a2a:      	movq	0x28(%rsp), %rbx
   12a2f:      	movq	0x48(%rsp), %rax
   12a34:      	movl	0x5c(%rsp), %r15d
   12a39:      	subq	%rbx, %rax
   12a3c:      	movl	0x50(%rsp), %r12d
   12a41:      	movl	%r15d, %edx
   12a44:      	subl	%r12d, %edx
   12a47:      	movl	$0x0, %ecx
   12a4c:      	cmovbl	%ecx, %edx
   12a4f:      	addq	0x60(%rsp), %rdx
   12a54:      	xorl	%esi, %esi
   12a56:      	cmpl	%r15d, %r12d
   12a59:      	seta	%sil
   12a5d:      	movl	%r15d, %ecx
   12a60:      	cmovbl	%r12d, %ecx
   12a64:      	addl	%ecx, %esi
   12a66:      	movl	%r12d, %edi
   12a69:      	subl	%esi, %edi
   12a6b:      	movl	%edi, 0x50(%rsp)
   12a6f:      	subq	%rsi, %rax
   12a72:      	jb	0x167a2 <generic_lsm_path+0xba72>
   12a78:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12a7e:      	ja	0x167a2 <generic_lsm_path+0xba72>
   12a84:      	cmpl	%r15d, %r12d
   12a87:      	jbe	0x12a8d <generic_lsm_path+0x7d5d>
   12a89:      	movb	$0x2f, (%rbx,%rax)
   12a8d:      	xorl	%edi, %edi
   12a8f:      	cmpl	%r15d, %r12d
   12a92:      	seta	%dil
   12a96:      	movzbl	%cl, %esi
   12a99:      	addq	%rax, %rbx
   12a9c:      	addq	%rbx, %rdi
   12a9f:      	movl	$0x4, %eax
   12aa4:      	callq	*%rax
   12aa6:      	movq	%rbx, 0x48(%rsp)
   12aab:      	cmpl	%r15d, %r12d
   12aae:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   12ab4:      	movq	0x8(%rsp), %r12
   12ab9:      	movq	%r12, 0x30(%rsp)
   12abe:      	movq	0x38(%rsp), %rdx
   12ac3:      	movq	0x40(%rsp), %r15
   12ac8:      	jmp	0x12b1b <generic_lsm_path+0x7deb>
   12aca:      	leaq	0x10(%r15), %rdx
   12ace:      	movl	$0x4, %eax
   12ad3:      	movq	%rbp, %rdi
   12ad6:      	movl	$0x8, %esi
   12adb:      	callq	*%rax
   12add:      	movq	0x40(%rsp), %rax
   12ae2:      	cmpq	(%rsp), %rax
   12ae6:      	je	0x1679d <generic_lsm_path+0xba6d>
   12aec:      	addq	$0x18, %r15
   12af0:      	movl	$0x4, %eax
   12af5:      	leaq	0x30(%rsp), %rdi
   12afa:      	movl	$0x8, %esi
   12aff:      	movq	%r15, %rdx
   12b02:      	callq	*%rax
   12b04:      	movq	(%rsp), %r15
   12b08:      	movq	%r15, 0x40(%rsp)
   12b0d:      	leaq	0x20(%r15), %rdx
   12b11:      	movq	%rdx, 0x38(%rsp)
   12b16:      	movq	0x30(%rsp), %r12
   12b1b:      	cmpq	0x18(%rsp), %r12
   12b20:      	jne	0x12b2d <generic_lsm_path+0x7dfd>
   12b22:      	cmpq	0x20(%rsp), %rdx
   12b27:      	je	0x1679d <generic_lsm_path+0xba6d>
   12b2d:      	movl	$0x4, %eax
   12b32:      	leaq	0x10(%rsp), %rdi
   12b37:      	movl	$0x8, %esi
   12b3c:      	callq	*%rax
   12b3e:      	cmpq	0x10(%rsp), %r12
   12b43:      	je	0x12c3b <generic_lsm_path+0x7f0b>
   12b49:      	leaq	0x18(%r12), %rbx
   12b4e:      	movl	$0x4, %eax
   12b53:      	movq	%rbp, %rdi
   12b56:      	movl	$0x8, %esi
   12b5b:      	movq	%rbx, %rdx
   12b5e:      	callq	*%rax
   12b60:      	cmpq	%r12, (%rsp)
   12b64:      	je	0x12c3b <generic_lsm_path+0x7f0b>
   12b6a:      	movl	$0x4, %eax
   12b6f:      	leaq	0x8(%rsp), %rdi
   12b74:      	movl	$0x8, %esi
   12b79:      	movq	%rbx, %rdx
   12b7c:      	callq	*%rax
   12b7e:      	addq	$0x20, %r12
   12b82:      	movl	$0x4, %eax
   12b87:      	leaq	0x58(%rsp), %rdi
   12b8c:      	movl	$0x10, %ecx
   12b91:      	movl	$0x10, %esi
   12b96:      	movq	%r12, %rdx
   12b99:      	callq	*%rax
   12b9b:      	movq	0x28(%rsp), %rbx
   12ba0:      	movq	0x48(%rsp), %rax
   12ba5:      	movl	0x5c(%rsp), %r15d
   12baa:      	subq	%rbx, %rax
   12bad:      	movl	0x50(%rsp), %r12d
   12bb2:      	movl	%r15d, %edx
   12bb5:      	subl	%r12d, %edx
   12bb8:      	movl	$0x0, %ecx
   12bbd:      	cmovbl	%ecx, %edx
   12bc0:      	addq	0x60(%rsp), %rdx
   12bc5:      	xorl	%esi, %esi
   12bc7:      	cmpl	%r15d, %r12d
   12bca:      	seta	%sil
   12bce:      	movl	%r15d, %ecx
   12bd1:      	cmovbl	%r12d, %ecx
   12bd5:      	addl	%ecx, %esi
   12bd7:      	movl	%r12d, %edi
   12bda:      	subl	%esi, %edi
   12bdc:      	movl	%edi, 0x50(%rsp)
   12be0:      	subq	%rsi, %rax
   12be3:      	jb	0x167a2 <generic_lsm_path+0xba72>
   12be9:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12bef:      	ja	0x167a2 <generic_lsm_path+0xba72>
   12bf5:      	cmpl	%r15d, %r12d
   12bf8:      	jbe	0x12bfe <generic_lsm_path+0x7ece>
   12bfa:      	movb	$0x2f, (%rbx,%rax)
   12bfe:      	xorl	%edi, %edi
   12c00:      	cmpl	%r15d, %r12d
   12c03:      	seta	%dil
   12c07:      	movzbl	%cl, %esi
   12c0a:      	addq	%rax, %rbx
   12c0d:      	addq	%rbx, %rdi
   12c10:      	movl	$0x4, %eax
   12c15:      	callq	*%rax
   12c17:      	movq	%rbx, 0x48(%rsp)
   12c1c:      	cmpl	%r15d, %r12d
   12c1f:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   12c25:      	movq	0x8(%rsp), %r12
   12c2a:      	movq	%r12, 0x30(%rsp)
   12c2f:      	movq	0x38(%rsp), %rdx
   12c34:      	movq	0x40(%rsp), %r15
   12c39:      	jmp	0x12c8c <generic_lsm_path+0x7f5c>
   12c3b:      	leaq	0x10(%r15), %rdx
   12c3f:      	movl	$0x4, %eax
   12c44:      	movq	%rbp, %rdi
   12c47:      	movl	$0x8, %esi
   12c4c:      	callq	*%rax
   12c4e:      	movq	0x40(%rsp), %rax
   12c53:      	cmpq	(%rsp), %rax
   12c57:      	je	0x1679d <generic_lsm_path+0xba6d>
   12c5d:      	addq	$0x18, %r15
   12c61:      	movl	$0x4, %eax
   12c66:      	leaq	0x30(%rsp), %rdi
   12c6b:      	movl	$0x8, %esi
   12c70:      	movq	%r15, %rdx
   12c73:      	callq	*%rax
   12c75:      	movq	(%rsp), %r15
   12c79:      	movq	%r15, 0x40(%rsp)
   12c7e:      	leaq	0x20(%r15), %rdx
   12c82:      	movq	%rdx, 0x38(%rsp)
   12c87:      	movq	0x30(%rsp), %r12
   12c8c:      	cmpq	0x18(%rsp), %r12
   12c91:      	jne	0x12c9e <generic_lsm_path+0x7f6e>
   12c93:      	cmpq	0x20(%rsp), %rdx
   12c98:      	je	0x1679d <generic_lsm_path+0xba6d>
   12c9e:      	movl	$0x4, %eax
   12ca3:      	leaq	0x10(%rsp), %rdi
   12ca8:      	movl	$0x8, %esi
   12cad:      	callq	*%rax
   12caf:      	cmpq	0x10(%rsp), %r12
   12cb4:      	je	0x12dac <generic_lsm_path+0x807c>
   12cba:      	leaq	0x18(%r12), %rbx
   12cbf:      	movl	$0x4, %eax
   12cc4:      	movq	%rbp, %rdi
   12cc7:      	movl	$0x8, %esi
   12ccc:      	movq	%rbx, %rdx
   12ccf:      	callq	*%rax
   12cd1:      	cmpq	%r12, (%rsp)
   12cd5:      	je	0x12dac <generic_lsm_path+0x807c>
   12cdb:      	movl	$0x4, %eax
   12ce0:      	leaq	0x8(%rsp), %rdi
   12ce5:      	movl	$0x8, %esi
   12cea:      	movq	%rbx, %rdx
   12ced:      	callq	*%rax
   12cef:      	addq	$0x20, %r12
   12cf3:      	movl	$0x4, %eax
   12cf8:      	leaq	0x58(%rsp), %rdi
   12cfd:      	movl	$0x10, %ecx
   12d02:      	movl	$0x10, %esi
   12d07:      	movq	%r12, %rdx
   12d0a:      	callq	*%rax
   12d0c:      	movq	0x28(%rsp), %rbx
   12d11:      	movq	0x48(%rsp), %rax
   12d16:      	movl	0x5c(%rsp), %r15d
   12d1b:      	subq	%rbx, %rax
   12d1e:      	movl	0x50(%rsp), %r12d
   12d23:      	movl	%r15d, %edx
   12d26:      	subl	%r12d, %edx
   12d29:      	movl	$0x0, %ecx
   12d2e:      	cmovbl	%ecx, %edx
   12d31:      	addq	0x60(%rsp), %rdx
   12d36:      	xorl	%esi, %esi
   12d38:      	cmpl	%r15d, %r12d
   12d3b:      	seta	%sil
   12d3f:      	movl	%r15d, %ecx
   12d42:      	cmovbl	%r12d, %ecx
   12d46:      	addl	%ecx, %esi
   12d48:      	movl	%r12d, %edi
   12d4b:      	subl	%esi, %edi
   12d4d:      	movl	%edi, 0x50(%rsp)
   12d51:      	subq	%rsi, %rax
   12d54:      	jb	0x167a2 <generic_lsm_path+0xba72>
   12d5a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12d60:      	ja	0x167a2 <generic_lsm_path+0xba72>
   12d66:      	cmpl	%r15d, %r12d
   12d69:      	jbe	0x12d6f <generic_lsm_path+0x803f>
   12d6b:      	movb	$0x2f, (%rbx,%rax)
   12d6f:      	xorl	%edi, %edi
   12d71:      	cmpl	%r15d, %r12d
   12d74:      	seta	%dil
   12d78:      	movzbl	%cl, %esi
   12d7b:      	addq	%rax, %rbx
   12d7e:      	addq	%rbx, %rdi
   12d81:      	movl	$0x4, %eax
   12d86:      	callq	*%rax
   12d88:      	movq	%rbx, 0x48(%rsp)
   12d8d:      	cmpl	%r15d, %r12d
   12d90:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   12d96:      	movq	0x8(%rsp), %r12
   12d9b:      	movq	%r12, 0x30(%rsp)
   12da0:      	movq	0x38(%rsp), %rdx
   12da5:      	movq	0x40(%rsp), %r15
   12daa:      	jmp	0x12dfd <generic_lsm_path+0x80cd>
   12dac:      	leaq	0x10(%r15), %rdx
   12db0:      	movl	$0x4, %eax
   12db5:      	movq	%rbp, %rdi
   12db8:      	movl	$0x8, %esi
   12dbd:      	callq	*%rax
   12dbf:      	movq	0x40(%rsp), %rax
   12dc4:      	cmpq	(%rsp), %rax
   12dc8:      	je	0x1679d <generic_lsm_path+0xba6d>
   12dce:      	addq	$0x18, %r15
   12dd2:      	movl	$0x4, %eax
   12dd7:      	leaq	0x30(%rsp), %rdi
   12ddc:      	movl	$0x8, %esi
   12de1:      	movq	%r15, %rdx
   12de4:      	callq	*%rax
   12de6:      	movq	(%rsp), %r15
   12dea:      	movq	%r15, 0x40(%rsp)
   12def:      	leaq	0x20(%r15), %rdx
   12df3:      	movq	%rdx, 0x38(%rsp)
   12df8:      	movq	0x30(%rsp), %r12
   12dfd:      	cmpq	0x18(%rsp), %r12
   12e02:      	jne	0x12e0f <generic_lsm_path+0x80df>
   12e04:      	cmpq	0x20(%rsp), %rdx
   12e09:      	je	0x1679d <generic_lsm_path+0xba6d>
   12e0f:      	movl	$0x4, %eax
   12e14:      	leaq	0x10(%rsp), %rdi
   12e19:      	movl	$0x8, %esi
   12e1e:      	callq	*%rax
   12e20:      	cmpq	0x10(%rsp), %r12
   12e25:      	je	0x12f1d <generic_lsm_path+0x81ed>
   12e2b:      	leaq	0x18(%r12), %rbx
   12e30:      	movl	$0x4, %eax
   12e35:      	movq	%rbp, %rdi
   12e38:      	movl	$0x8, %esi
   12e3d:      	movq	%rbx, %rdx
   12e40:      	callq	*%rax
   12e42:      	cmpq	%r12, (%rsp)
   12e46:      	je	0x12f1d <generic_lsm_path+0x81ed>
   12e4c:      	movl	$0x4, %eax
   12e51:      	leaq	0x8(%rsp), %rdi
   12e56:      	movl	$0x8, %esi
   12e5b:      	movq	%rbx, %rdx
   12e5e:      	callq	*%rax
   12e60:      	addq	$0x20, %r12
   12e64:      	movl	$0x4, %eax
   12e69:      	leaq	0x58(%rsp), %rdi
   12e6e:      	movl	$0x10, %ecx
   12e73:      	movl	$0x10, %esi
   12e78:      	movq	%r12, %rdx
   12e7b:      	callq	*%rax
   12e7d:      	movq	0x28(%rsp), %rbx
   12e82:      	movq	0x48(%rsp), %rax
   12e87:      	movl	0x5c(%rsp), %r15d
   12e8c:      	subq	%rbx, %rax
   12e8f:      	movl	0x50(%rsp), %r12d
   12e94:      	movl	%r15d, %edx
   12e97:      	subl	%r12d, %edx
   12e9a:      	movl	$0x0, %ecx
   12e9f:      	cmovbl	%ecx, %edx
   12ea2:      	addq	0x60(%rsp), %rdx
   12ea7:      	xorl	%esi, %esi
   12ea9:      	cmpl	%r15d, %r12d
   12eac:      	seta	%sil
   12eb0:      	movl	%r15d, %ecx
   12eb3:      	cmovbl	%r12d, %ecx
   12eb7:      	addl	%ecx, %esi
   12eb9:      	movl	%r12d, %edi
   12ebc:      	subl	%esi, %edi
   12ebe:      	movl	%edi, 0x50(%rsp)
   12ec2:      	subq	%rsi, %rax
   12ec5:      	jb	0x167a2 <generic_lsm_path+0xba72>
   12ecb:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12ed1:      	ja	0x167a2 <generic_lsm_path+0xba72>
   12ed7:      	cmpl	%r15d, %r12d
   12eda:      	jbe	0x12ee0 <generic_lsm_path+0x81b0>
   12edc:      	movb	$0x2f, (%rbx,%rax)
   12ee0:      	xorl	%edi, %edi
   12ee2:      	cmpl	%r15d, %r12d
   12ee5:      	seta	%dil
   12ee9:      	movzbl	%cl, %esi
   12eec:      	addq	%rax, %rbx
   12eef:      	addq	%rbx, %rdi
   12ef2:      	movl	$0x4, %eax
   12ef7:      	callq	*%rax
   12ef9:      	movq	%rbx, 0x48(%rsp)
   12efe:      	cmpl	%r15d, %r12d
   12f01:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   12f07:      	movq	0x8(%rsp), %r12
   12f0c:      	movq	%r12, 0x30(%rsp)
   12f11:      	movq	0x38(%rsp), %rdx
   12f16:      	movq	0x40(%rsp), %r15
   12f1b:      	jmp	0x12f6e <generic_lsm_path+0x823e>
   12f1d:      	leaq	0x10(%r15), %rdx
   12f21:      	movl	$0x4, %eax
   12f26:      	movq	%rbp, %rdi
   12f29:      	movl	$0x8, %esi
   12f2e:      	callq	*%rax
   12f30:      	movq	0x40(%rsp), %rax
   12f35:      	cmpq	(%rsp), %rax
   12f39:      	je	0x1679d <generic_lsm_path+0xba6d>
   12f3f:      	addq	$0x18, %r15
   12f43:      	movl	$0x4, %eax
   12f48:      	leaq	0x30(%rsp), %rdi
   12f4d:      	movl	$0x8, %esi
   12f52:      	movq	%r15, %rdx
   12f55:      	callq	*%rax
   12f57:      	movq	(%rsp), %r15
   12f5b:      	movq	%r15, 0x40(%rsp)
   12f60:      	leaq	0x20(%r15), %rdx
   12f64:      	movq	%rdx, 0x38(%rsp)
   12f69:      	movq	0x30(%rsp), %r12
   12f6e:      	cmpq	0x18(%rsp), %r12
   12f73:      	jne	0x12f80 <generic_lsm_path+0x8250>
   12f75:      	cmpq	0x20(%rsp), %rdx
   12f7a:      	je	0x1679d <generic_lsm_path+0xba6d>
   12f80:      	movl	$0x4, %eax
   12f85:      	leaq	0x10(%rsp), %rdi
   12f8a:      	movl	$0x8, %esi
   12f8f:      	callq	*%rax
   12f91:      	cmpq	0x10(%rsp), %r12
   12f96:      	je	0x1308e <generic_lsm_path+0x835e>
   12f9c:      	leaq	0x18(%r12), %rbx
   12fa1:      	movl	$0x4, %eax
   12fa6:      	movq	%rbp, %rdi
   12fa9:      	movl	$0x8, %esi
   12fae:      	movq	%rbx, %rdx
   12fb1:      	callq	*%rax
   12fb3:      	cmpq	%r12, (%rsp)
   12fb7:      	je	0x1308e <generic_lsm_path+0x835e>
   12fbd:      	movl	$0x4, %eax
   12fc2:      	leaq	0x8(%rsp), %rdi
   12fc7:      	movl	$0x8, %esi
   12fcc:      	movq	%rbx, %rdx
   12fcf:      	callq	*%rax
   12fd1:      	addq	$0x20, %r12
   12fd5:      	movl	$0x4, %eax
   12fda:      	leaq	0x58(%rsp), %rdi
   12fdf:      	movl	$0x10, %ecx
   12fe4:      	movl	$0x10, %esi
   12fe9:      	movq	%r12, %rdx
   12fec:      	callq	*%rax
   12fee:      	movq	0x28(%rsp), %rbx
   12ff3:      	movq	0x48(%rsp), %rax
   12ff8:      	movl	0x5c(%rsp), %r15d
   12ffd:      	subq	%rbx, %rax
   13000:      	movl	0x50(%rsp), %r12d
   13005:      	movl	%r15d, %edx
   13008:      	subl	%r12d, %edx
   1300b:      	movl	$0x0, %ecx
   13010:      	cmovbl	%ecx, %edx
   13013:      	addq	0x60(%rsp), %rdx
   13018:      	xorl	%esi, %esi
   1301a:      	cmpl	%r15d, %r12d
   1301d:      	seta	%sil
   13021:      	movl	%r15d, %ecx
   13024:      	cmovbl	%r12d, %ecx
   13028:      	addl	%ecx, %esi
   1302a:      	movl	%r12d, %edi
   1302d:      	subl	%esi, %edi
   1302f:      	movl	%edi, 0x50(%rsp)
   13033:      	subq	%rsi, %rax
   13036:      	jb	0x167a2 <generic_lsm_path+0xba72>
   1303c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13042:      	ja	0x167a2 <generic_lsm_path+0xba72>
   13048:      	cmpl	%r15d, %r12d
   1304b:      	jbe	0x13051 <generic_lsm_path+0x8321>
   1304d:      	movb	$0x2f, (%rbx,%rax)
   13051:      	xorl	%edi, %edi
   13053:      	cmpl	%r15d, %r12d
   13056:      	seta	%dil
   1305a:      	movzbl	%cl, %esi
   1305d:      	addq	%rax, %rbx
   13060:      	addq	%rbx, %rdi
   13063:      	movl	$0x4, %eax
   13068:      	callq	*%rax
   1306a:      	movq	%rbx, 0x48(%rsp)
   1306f:      	cmpl	%r15d, %r12d
   13072:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   13078:      	movq	0x8(%rsp), %r12
   1307d:      	movq	%r12, 0x30(%rsp)
   13082:      	movq	0x38(%rsp), %rdx
   13087:      	movq	0x40(%rsp), %r15
   1308c:      	jmp	0x130df <generic_lsm_path+0x83af>
   1308e:      	leaq	0x10(%r15), %rdx
   13092:      	movl	$0x4, %eax
   13097:      	movq	%rbp, %rdi
   1309a:      	movl	$0x8, %esi
   1309f:      	callq	*%rax
   130a1:      	movq	0x40(%rsp), %rax
   130a6:      	cmpq	(%rsp), %rax
   130aa:      	je	0x1679d <generic_lsm_path+0xba6d>
   130b0:      	addq	$0x18, %r15
   130b4:      	movl	$0x4, %eax
   130b9:      	leaq	0x30(%rsp), %rdi
   130be:      	movl	$0x8, %esi
   130c3:      	movq	%r15, %rdx
   130c6:      	callq	*%rax
   130c8:      	movq	(%rsp), %r15
   130cc:      	movq	%r15, 0x40(%rsp)
   130d1:      	leaq	0x20(%r15), %rdx
   130d5:      	movq	%rdx, 0x38(%rsp)
   130da:      	movq	0x30(%rsp), %r12
   130df:      	cmpq	0x18(%rsp), %r12
   130e4:      	jne	0x130f1 <generic_lsm_path+0x83c1>
   130e6:      	cmpq	0x20(%rsp), %rdx
   130eb:      	je	0x1679d <generic_lsm_path+0xba6d>
   130f1:      	movl	$0x4, %eax
   130f6:      	leaq	0x10(%rsp), %rdi
   130fb:      	movl	$0x8, %esi
   13100:      	callq	*%rax
   13102:      	cmpq	0x10(%rsp), %r12
   13107:      	je	0x131ff <generic_lsm_path+0x84cf>
   1310d:      	leaq	0x18(%r12), %rbx
   13112:      	movl	$0x4, %eax
   13117:      	movq	%rbp, %rdi
   1311a:      	movl	$0x8, %esi
   1311f:      	movq	%rbx, %rdx
   13122:      	callq	*%rax
   13124:      	cmpq	%r12, (%rsp)
   13128:      	je	0x131ff <generic_lsm_path+0x84cf>
   1312e:      	movl	$0x4, %eax
   13133:      	leaq	0x8(%rsp), %rdi
   13138:      	movl	$0x8, %esi
   1313d:      	movq	%rbx, %rdx
   13140:      	callq	*%rax
   13142:      	addq	$0x20, %r12
   13146:      	movl	$0x4, %eax
   1314b:      	leaq	0x58(%rsp), %rdi
   13150:      	movl	$0x10, %ecx
   13155:      	movl	$0x10, %esi
   1315a:      	movq	%r12, %rdx
   1315d:      	callq	*%rax
   1315f:      	movq	0x28(%rsp), %rbx
   13164:      	movq	0x48(%rsp), %rax
   13169:      	movl	0x5c(%rsp), %r15d
   1316e:      	subq	%rbx, %rax
   13171:      	movl	0x50(%rsp), %r12d
   13176:      	movl	%r15d, %edx
   13179:      	subl	%r12d, %edx
   1317c:      	movl	$0x0, %ecx
   13181:      	cmovbl	%ecx, %edx
   13184:      	addq	0x60(%rsp), %rdx
   13189:      	xorl	%esi, %esi
   1318b:      	cmpl	%r15d, %r12d
   1318e:      	seta	%sil
   13192:      	movl	%r15d, %ecx
   13195:      	cmovbl	%r12d, %ecx
   13199:      	addl	%ecx, %esi
   1319b:      	movl	%r12d, %edi
   1319e:      	subl	%esi, %edi
   131a0:      	movl	%edi, 0x50(%rsp)
   131a4:      	subq	%rsi, %rax
   131a7:      	jb	0x167a2 <generic_lsm_path+0xba72>
   131ad:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   131b3:      	ja	0x167a2 <generic_lsm_path+0xba72>
   131b9:      	cmpl	%r15d, %r12d
   131bc:      	jbe	0x131c2 <generic_lsm_path+0x8492>
   131be:      	movb	$0x2f, (%rbx,%rax)
   131c2:      	xorl	%edi, %edi
   131c4:      	cmpl	%r15d, %r12d
   131c7:      	seta	%dil
   131cb:      	movzbl	%cl, %esi
   131ce:      	addq	%rax, %rbx
   131d1:      	addq	%rbx, %rdi
   131d4:      	movl	$0x4, %eax
   131d9:      	callq	*%rax
   131db:      	movq	%rbx, 0x48(%rsp)
   131e0:      	cmpl	%r15d, %r12d
   131e3:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   131e9:      	movq	0x8(%rsp), %r12
   131ee:      	movq	%r12, 0x30(%rsp)
   131f3:      	movq	0x38(%rsp), %rdx
   131f8:      	movq	0x40(%rsp), %r15
   131fd:      	jmp	0x13250 <generic_lsm_path+0x8520>
   131ff:      	leaq	0x10(%r15), %rdx
   13203:      	movl	$0x4, %eax
   13208:      	movq	%rbp, %rdi
   1320b:      	movl	$0x8, %esi
   13210:      	callq	*%rax
   13212:      	movq	0x40(%rsp), %rax
   13217:      	cmpq	(%rsp), %rax
   1321b:      	je	0x1679d <generic_lsm_path+0xba6d>
   13221:      	addq	$0x18, %r15
   13225:      	movl	$0x4, %eax
   1322a:      	leaq	0x30(%rsp), %rdi
   1322f:      	movl	$0x8, %esi
   13234:      	movq	%r15, %rdx
   13237:      	callq	*%rax
   13239:      	movq	(%rsp), %r15
   1323d:      	movq	%r15, 0x40(%rsp)
   13242:      	leaq	0x20(%r15), %rdx
   13246:      	movq	%rdx, 0x38(%rsp)
   1324b:      	movq	0x30(%rsp), %r12
   13250:      	cmpq	0x18(%rsp), %r12
   13255:      	jne	0x13262 <generic_lsm_path+0x8532>
   13257:      	cmpq	0x20(%rsp), %rdx
   1325c:      	je	0x1679d <generic_lsm_path+0xba6d>
   13262:      	movl	$0x4, %eax
   13267:      	leaq	0x10(%rsp), %rdi
   1326c:      	movl	$0x8, %esi
   13271:      	callq	*%rax
   13273:      	cmpq	0x10(%rsp), %r12
   13278:      	je	0x13370 <generic_lsm_path+0x8640>
   1327e:      	leaq	0x18(%r12), %rbx
   13283:      	movl	$0x4, %eax
   13288:      	movq	%rbp, %rdi
   1328b:      	movl	$0x8, %esi
   13290:      	movq	%rbx, %rdx
   13293:      	callq	*%rax
   13295:      	cmpq	%r12, (%rsp)
   13299:      	je	0x13370 <generic_lsm_path+0x8640>
   1329f:      	movl	$0x4, %eax
   132a4:      	leaq	0x8(%rsp), %rdi
   132a9:      	movl	$0x8, %esi
   132ae:      	movq	%rbx, %rdx
   132b1:      	callq	*%rax
   132b3:      	addq	$0x20, %r12
   132b7:      	movl	$0x4, %eax
   132bc:      	leaq	0x58(%rsp), %rdi
   132c1:      	movl	$0x10, %ecx
   132c6:      	movl	$0x10, %esi
   132cb:      	movq	%r12, %rdx
   132ce:      	callq	*%rax
   132d0:      	movq	0x28(%rsp), %rbx
   132d5:      	movq	0x48(%rsp), %rax
   132da:      	movl	0x5c(%rsp), %r15d
   132df:      	subq	%rbx, %rax
   132e2:      	movl	0x50(%rsp), %r12d
   132e7:      	movl	%r15d, %edx
   132ea:      	subl	%r12d, %edx
   132ed:      	movl	$0x0, %ecx
   132f2:      	cmovbl	%ecx, %edx
   132f5:      	addq	0x60(%rsp), %rdx
   132fa:      	xorl	%esi, %esi
   132fc:      	cmpl	%r15d, %r12d
   132ff:      	seta	%sil
   13303:      	movl	%r15d, %ecx
   13306:      	cmovbl	%r12d, %ecx
   1330a:      	addl	%ecx, %esi
   1330c:      	movl	%r12d, %edi
   1330f:      	subl	%esi, %edi
   13311:      	movl	%edi, 0x50(%rsp)
   13315:      	subq	%rsi, %rax
   13318:      	jb	0x167a2 <generic_lsm_path+0xba72>
   1331e:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13324:      	ja	0x167a2 <generic_lsm_path+0xba72>
   1332a:      	cmpl	%r15d, %r12d
   1332d:      	jbe	0x13333 <generic_lsm_path+0x8603>
   1332f:      	movb	$0x2f, (%rbx,%rax)
   13333:      	xorl	%edi, %edi
   13335:      	cmpl	%r15d, %r12d
   13338:      	seta	%dil
   1333c:      	movzbl	%cl, %esi
   1333f:      	addq	%rax, %rbx
   13342:      	addq	%rbx, %rdi
   13345:      	movl	$0x4, %eax
   1334a:      	callq	*%rax
   1334c:      	movq	%rbx, 0x48(%rsp)
   13351:      	cmpl	%r15d, %r12d
   13354:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   1335a:      	movq	0x8(%rsp), %r12
   1335f:      	movq	%r12, 0x30(%rsp)
   13364:      	movq	0x38(%rsp), %rdx
   13369:      	movq	0x40(%rsp), %r15
   1336e:      	jmp	0x133c1 <generic_lsm_path+0x8691>
   13370:      	leaq	0x10(%r15), %rdx
   13374:      	movl	$0x4, %eax
   13379:      	movq	%rbp, %rdi
   1337c:      	movl	$0x8, %esi
   13381:      	callq	*%rax
   13383:      	movq	0x40(%rsp), %rax
   13388:      	cmpq	(%rsp), %rax
   1338c:      	je	0x1679d <generic_lsm_path+0xba6d>
   13392:      	addq	$0x18, %r15
   13396:      	movl	$0x4, %eax
   1339b:      	leaq	0x30(%rsp), %rdi
   133a0:      	movl	$0x8, %esi
   133a5:      	movq	%r15, %rdx
   133a8:      	callq	*%rax
   133aa:      	movq	(%rsp), %r15
   133ae:      	movq	%r15, 0x40(%rsp)
   133b3:      	leaq	0x20(%r15), %rdx
   133b7:      	movq	%rdx, 0x38(%rsp)
   133bc:      	movq	0x30(%rsp), %r12
   133c1:      	cmpq	0x18(%rsp), %r12
   133c6:      	jne	0x133d3 <generic_lsm_path+0x86a3>
   133c8:      	cmpq	0x20(%rsp), %rdx
   133cd:      	je	0x1679d <generic_lsm_path+0xba6d>
   133d3:      	movl	$0x4, %eax
   133d8:      	leaq	0x10(%rsp), %rdi
   133dd:      	movl	$0x8, %esi
   133e2:      	callq	*%rax
   133e4:      	cmpq	0x10(%rsp), %r12
   133e9:      	je	0x134e1 <generic_lsm_path+0x87b1>
   133ef:      	leaq	0x18(%r12), %rbx
   133f4:      	movl	$0x4, %eax
   133f9:      	movq	%rbp, %rdi
   133fc:      	movl	$0x8, %esi
   13401:      	movq	%rbx, %rdx
   13404:      	callq	*%rax
   13406:      	cmpq	%r12, (%rsp)
   1340a:      	je	0x134e1 <generic_lsm_path+0x87b1>
   13410:      	movl	$0x4, %eax
   13415:      	leaq	0x8(%rsp), %rdi
   1341a:      	movl	$0x8, %esi
   1341f:      	movq	%rbx, %rdx
   13422:      	callq	*%rax
   13424:      	addq	$0x20, %r12
   13428:      	movl	$0x4, %eax
   1342d:      	leaq	0x58(%rsp), %rdi
   13432:      	movl	$0x10, %ecx
   13437:      	movl	$0x10, %esi
   1343c:      	movq	%r12, %rdx
   1343f:      	callq	*%rax
   13441:      	movq	0x28(%rsp), %rbx
   13446:      	movq	0x48(%rsp), %rax
   1344b:      	movl	0x5c(%rsp), %r15d
   13450:      	subq	%rbx, %rax
   13453:      	movl	0x50(%rsp), %r12d
   13458:      	movl	%r15d, %edx
   1345b:      	subl	%r12d, %edx
   1345e:      	movl	$0x0, %ecx
   13463:      	cmovbl	%ecx, %edx
   13466:      	addq	0x60(%rsp), %rdx
   1346b:      	xorl	%esi, %esi
   1346d:      	cmpl	%r15d, %r12d
   13470:      	seta	%sil
   13474:      	movl	%r15d, %ecx
   13477:      	cmovbl	%r12d, %ecx
   1347b:      	addl	%ecx, %esi
   1347d:      	movl	%r12d, %edi
   13480:      	subl	%esi, %edi
   13482:      	movl	%edi, 0x50(%rsp)
   13486:      	subq	%rsi, %rax
   13489:      	jb	0x167a2 <generic_lsm_path+0xba72>
   1348f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13495:      	ja	0x167a2 <generic_lsm_path+0xba72>
   1349b:      	cmpl	%r15d, %r12d
   1349e:      	jbe	0x134a4 <generic_lsm_path+0x8774>
   134a0:      	movb	$0x2f, (%rbx,%rax)
   134a4:      	xorl	%edi, %edi
   134a6:      	cmpl	%r15d, %r12d
   134a9:      	seta	%dil
   134ad:      	movzbl	%cl, %esi
   134b0:      	addq	%rax, %rbx
   134b3:      	addq	%rbx, %rdi
   134b6:      	movl	$0x4, %eax
   134bb:      	callq	*%rax
   134bd:      	movq	%rbx, 0x48(%rsp)
   134c2:      	cmpl	%r15d, %r12d
   134c5:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   134cb:      	movq	0x8(%rsp), %r12
   134d0:      	movq	%r12, 0x30(%rsp)
   134d5:      	movq	0x38(%rsp), %rdx
   134da:      	movq	0x40(%rsp), %r15
   134df:      	jmp	0x13532 <generic_lsm_path+0x8802>
   134e1:      	leaq	0x10(%r15), %rdx
   134e5:      	movl	$0x4, %eax
   134ea:      	movq	%rbp, %rdi
   134ed:      	movl	$0x8, %esi
   134f2:      	callq	*%rax
   134f4:      	movq	0x40(%rsp), %rax
   134f9:      	cmpq	(%rsp), %rax
   134fd:      	je	0x1679d <generic_lsm_path+0xba6d>
   13503:      	addq	$0x18, %r15
   13507:      	movl	$0x4, %eax
   1350c:      	leaq	0x30(%rsp), %rdi
   13511:      	movl	$0x8, %esi
   13516:      	movq	%r15, %rdx
   13519:      	callq	*%rax
   1351b:      	movq	(%rsp), %r15
   1351f:      	movq	%r15, 0x40(%rsp)
   13524:      	leaq	0x20(%r15), %rdx
   13528:      	movq	%rdx, 0x38(%rsp)
   1352d:      	movq	0x30(%rsp), %r12
   13532:      	cmpq	0x18(%rsp), %r12
   13537:      	jne	0x13544 <generic_lsm_path+0x8814>
   13539:      	cmpq	0x20(%rsp), %rdx
   1353e:      	je	0x1679d <generic_lsm_path+0xba6d>
   13544:      	movl	$0x4, %eax
   13549:      	leaq	0x10(%rsp), %rdi
   1354e:      	movl	$0x8, %esi
   13553:      	callq	*%rax
   13555:      	cmpq	0x10(%rsp), %r12
   1355a:      	je	0x13652 <generic_lsm_path+0x8922>
   13560:      	leaq	0x18(%r12), %rbx
   13565:      	movl	$0x4, %eax
   1356a:      	movq	%rbp, %rdi
   1356d:      	movl	$0x8, %esi
   13572:      	movq	%rbx, %rdx
   13575:      	callq	*%rax
   13577:      	cmpq	%r12, (%rsp)
   1357b:      	je	0x13652 <generic_lsm_path+0x8922>
   13581:      	movl	$0x4, %eax
   13586:      	leaq	0x8(%rsp), %rdi
   1358b:      	movl	$0x8, %esi
   13590:      	movq	%rbx, %rdx
   13593:      	callq	*%rax
   13595:      	addq	$0x20, %r12
   13599:      	movl	$0x4, %eax
   1359e:      	leaq	0x58(%rsp), %rdi
   135a3:      	movl	$0x10, %ecx
   135a8:      	movl	$0x10, %esi
   135ad:      	movq	%r12, %rdx
   135b0:      	callq	*%rax
   135b2:      	movq	0x28(%rsp), %rbx
   135b7:      	movq	0x48(%rsp), %rax
   135bc:      	movl	0x5c(%rsp), %r15d
   135c1:      	subq	%rbx, %rax
   135c4:      	movl	0x50(%rsp), %r12d
   135c9:      	movl	%r15d, %edx
   135cc:      	subl	%r12d, %edx
   135cf:      	movl	$0x0, %ecx
   135d4:      	cmovbl	%ecx, %edx
   135d7:      	addq	0x60(%rsp), %rdx
   135dc:      	xorl	%esi, %esi
   135de:      	cmpl	%r15d, %r12d
   135e1:      	seta	%sil
   135e5:      	movl	%r15d, %ecx
   135e8:      	cmovbl	%r12d, %ecx
   135ec:      	addl	%ecx, %esi
   135ee:      	movl	%r12d, %edi
   135f1:      	subl	%esi, %edi
   135f3:      	movl	%edi, 0x50(%rsp)
   135f7:      	subq	%rsi, %rax
   135fa:      	jb	0x167a2 <generic_lsm_path+0xba72>
   13600:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13606:      	ja	0x167a2 <generic_lsm_path+0xba72>
   1360c:      	cmpl	%r15d, %r12d
   1360f:      	jbe	0x13615 <generic_lsm_path+0x88e5>
   13611:      	movb	$0x2f, (%rbx,%rax)
   13615:      	xorl	%edi, %edi
   13617:      	cmpl	%r15d, %r12d
   1361a:      	seta	%dil
   1361e:      	movzbl	%cl, %esi
   13621:      	addq	%rax, %rbx
   13624:      	addq	%rbx, %rdi
   13627:      	movl	$0x4, %eax
   1362c:      	callq	*%rax
   1362e:      	movq	%rbx, 0x48(%rsp)
   13633:      	cmpl	%r15d, %r12d
   13636:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   1363c:      	movq	0x8(%rsp), %r12
   13641:      	movq	%r12, 0x30(%rsp)
   13646:      	movq	0x38(%rsp), %rdx
   1364b:      	movq	0x40(%rsp), %r15
   13650:      	jmp	0x136a3 <generic_lsm_path+0x8973>
   13652:      	leaq	0x10(%r15), %rdx
   13656:      	movl	$0x4, %eax
   1365b:      	movq	%rbp, %rdi
   1365e:      	movl	$0x8, %esi
   13663:      	callq	*%rax
   13665:      	movq	0x40(%rsp), %rax
   1366a:      	cmpq	(%rsp), %rax
   1366e:      	je	0x1679d <generic_lsm_path+0xba6d>
   13674:      	addq	$0x18, %r15
   13678:      	movl	$0x4, %eax
   1367d:      	leaq	0x30(%rsp), %rdi
   13682:      	movl	$0x8, %esi
   13687:      	movq	%r15, %rdx
   1368a:      	callq	*%rax
   1368c:      	movq	(%rsp), %r15
   13690:      	movq	%r15, 0x40(%rsp)
   13695:      	leaq	0x20(%r15), %rdx
   13699:      	movq	%rdx, 0x38(%rsp)
   1369e:      	movq	0x30(%rsp), %r12
   136a3:      	cmpq	0x18(%rsp), %r12
   136a8:      	jne	0x136b5 <generic_lsm_path+0x8985>
   136aa:      	cmpq	0x20(%rsp), %rdx
   136af:      	je	0x1679d <generic_lsm_path+0xba6d>
   136b5:      	movl	$0x4, %eax
   136ba:      	leaq	0x10(%rsp), %rdi
   136bf:      	movl	$0x8, %esi
   136c4:      	callq	*%rax
   136c6:      	cmpq	0x10(%rsp), %r12
   136cb:      	je	0x137c3 <generic_lsm_path+0x8a93>
   136d1:      	leaq	0x18(%r12), %rbx
   136d6:      	movl	$0x4, %eax
   136db:      	movq	%rbp, %rdi
   136de:      	movl	$0x8, %esi
   136e3:      	movq	%rbx, %rdx
   136e6:      	callq	*%rax
   136e8:      	cmpq	%r12, (%rsp)
   136ec:      	je	0x137c3 <generic_lsm_path+0x8a93>
   136f2:      	movl	$0x4, %eax
   136f7:      	leaq	0x8(%rsp), %rdi
   136fc:      	movl	$0x8, %esi
   13701:      	movq	%rbx, %rdx
   13704:      	callq	*%rax
   13706:      	addq	$0x20, %r12
   1370a:      	movl	$0x4, %eax
   1370f:      	leaq	0x58(%rsp), %rdi
   13714:      	movl	$0x10, %ecx
   13719:      	movl	$0x10, %esi
   1371e:      	movq	%r12, %rdx
   13721:      	callq	*%rax
   13723:      	movq	0x28(%rsp), %rbx
   13728:      	movq	0x48(%rsp), %rax
   1372d:      	movl	0x5c(%rsp), %r15d
   13732:      	subq	%rbx, %rax
   13735:      	movl	0x50(%rsp), %r12d
   1373a:      	movl	%r15d, %edx
   1373d:      	subl	%r12d, %edx
   13740:      	movl	$0x0, %ecx
   13745:      	cmovbl	%ecx, %edx
   13748:      	addq	0x60(%rsp), %rdx
   1374d:      	xorl	%esi, %esi
   1374f:      	cmpl	%r15d, %r12d
   13752:      	seta	%sil
   13756:      	movl	%r15d, %ecx
   13759:      	cmovbl	%r12d, %ecx
   1375d:      	addl	%ecx, %esi
   1375f:      	movl	%r12d, %edi
   13762:      	subl	%esi, %edi
   13764:      	movl	%edi, 0x50(%rsp)
   13768:      	subq	%rsi, %rax
   1376b:      	jb	0x167a2 <generic_lsm_path+0xba72>
   13771:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13777:      	ja	0x167a2 <generic_lsm_path+0xba72>
   1377d:      	cmpl	%r15d, %r12d
   13780:      	jbe	0x13786 <generic_lsm_path+0x8a56>
   13782:      	movb	$0x2f, (%rbx,%rax)
   13786:      	xorl	%edi, %edi
   13788:      	cmpl	%r15d, %r12d
   1378b:      	seta	%dil
   1378f:      	movzbl	%cl, %esi
   13792:      	addq	%rax, %rbx
   13795:      	addq	%rbx, %rdi
   13798:      	movl	$0x4, %eax
   1379d:      	callq	*%rax
   1379f:      	movq	%rbx, 0x48(%rsp)
   137a4:      	cmpl	%r15d, %r12d
   137a7:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   137ad:      	movq	0x8(%rsp), %r12
   137b2:      	movq	%r12, 0x30(%rsp)
   137b7:      	movq	0x38(%rsp), %rdx
   137bc:      	movq	0x40(%rsp), %r15
   137c1:      	jmp	0x13814 <generic_lsm_path+0x8ae4>
   137c3:      	leaq	0x10(%r15), %rdx
   137c7:      	movl	$0x4, %eax
   137cc:      	movq	%rbp, %rdi
   137cf:      	movl	$0x8, %esi
   137d4:      	callq	*%rax
   137d6:      	movq	0x40(%rsp), %rax
   137db:      	cmpq	(%rsp), %rax
   137df:      	je	0x1679d <generic_lsm_path+0xba6d>
   137e5:      	addq	$0x18, %r15
   137e9:      	movl	$0x4, %eax
   137ee:      	leaq	0x30(%rsp), %rdi
   137f3:      	movl	$0x8, %esi
   137f8:      	movq	%r15, %rdx
   137fb:      	callq	*%rax
   137fd:      	movq	(%rsp), %r15
   13801:      	movq	%r15, 0x40(%rsp)
   13806:      	leaq	0x20(%r15), %rdx
   1380a:      	movq	%rdx, 0x38(%rsp)
   1380f:      	movq	0x30(%rsp), %r12
   13814:      	cmpq	0x18(%rsp), %r12
   13819:      	jne	0x13826 <generic_lsm_path+0x8af6>
   1381b:      	cmpq	0x20(%rsp), %rdx
   13820:      	je	0x1679d <generic_lsm_path+0xba6d>
   13826:      	movl	$0x4, %eax
   1382b:      	leaq	0x10(%rsp), %rdi
   13830:      	movl	$0x8, %esi
   13835:      	callq	*%rax
   13837:      	cmpq	0x10(%rsp), %r12
   1383c:      	je	0x13934 <generic_lsm_path+0x8c04>
   13842:      	leaq	0x18(%r12), %rbx
   13847:      	movl	$0x4, %eax
   1384c:      	movq	%rbp, %rdi
   1384f:      	movl	$0x8, %esi
   13854:      	movq	%rbx, %rdx
   13857:      	callq	*%rax
   13859:      	cmpq	%r12, (%rsp)
   1385d:      	je	0x13934 <generic_lsm_path+0x8c04>
   13863:      	movl	$0x4, %eax
   13868:      	leaq	0x8(%rsp), %rdi
   1386d:      	movl	$0x8, %esi
   13872:      	movq	%rbx, %rdx
   13875:      	callq	*%rax
   13877:      	addq	$0x20, %r12
   1387b:      	movl	$0x4, %eax
   13880:      	leaq	0x58(%rsp), %rdi
   13885:      	movl	$0x10, %ecx
   1388a:      	movl	$0x10, %esi
   1388f:      	movq	%r12, %rdx
   13892:      	callq	*%rax
   13894:      	movq	0x28(%rsp), %rbx
   13899:      	movq	0x48(%rsp), %rax
   1389e:      	movl	0x5c(%rsp), %r15d
   138a3:      	subq	%rbx, %rax
   138a6:      	movl	0x50(%rsp), %r12d
   138ab:      	movl	%r15d, %edx
   138ae:      	subl	%r12d, %edx
   138b1:      	movl	$0x0, %ecx
   138b6:      	cmovbl	%ecx, %edx
   138b9:      	addq	0x60(%rsp), %rdx
   138be:      	xorl	%esi, %esi
   138c0:      	cmpl	%r15d, %r12d
   138c3:      	seta	%sil
   138c7:      	movl	%r15d, %ecx
   138ca:      	cmovbl	%r12d, %ecx
   138ce:      	addl	%ecx, %esi
   138d0:      	movl	%r12d, %edi
   138d3:      	subl	%esi, %edi
   138d5:      	movl	%edi, 0x50(%rsp)
   138d9:      	subq	%rsi, %rax
   138dc:      	jb	0x167a2 <generic_lsm_path+0xba72>
   138e2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   138e8:      	ja	0x167a2 <generic_lsm_path+0xba72>
   138ee:      	cmpl	%r15d, %r12d
   138f1:      	jbe	0x138f7 <generic_lsm_path+0x8bc7>
   138f3:      	movb	$0x2f, (%rbx,%rax)
   138f7:      	xorl	%edi, %edi
   138f9:      	cmpl	%r15d, %r12d
   138fc:      	seta	%dil
   13900:      	movzbl	%cl, %esi
   13903:      	addq	%rax, %rbx
   13906:      	addq	%rbx, %rdi
   13909:      	movl	$0x4, %eax
   1390e:      	callq	*%rax
   13910:      	movq	%rbx, 0x48(%rsp)
   13915:      	cmpl	%r15d, %r12d
   13918:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   1391e:      	movq	0x8(%rsp), %r12
   13923:      	movq	%r12, 0x30(%rsp)
   13928:      	movq	0x38(%rsp), %rdx
   1392d:      	movq	0x40(%rsp), %r15
   13932:      	jmp	0x13985 <generic_lsm_path+0x8c55>
   13934:      	leaq	0x10(%r15), %rdx
   13938:      	movl	$0x4, %eax
   1393d:      	movq	%rbp, %rdi
   13940:      	movl	$0x8, %esi
   13945:      	callq	*%rax
   13947:      	movq	0x40(%rsp), %rax
   1394c:      	cmpq	(%rsp), %rax
   13950:      	je	0x1679d <generic_lsm_path+0xba6d>
   13956:      	addq	$0x18, %r15
   1395a:      	movl	$0x4, %eax
   1395f:      	leaq	0x30(%rsp), %rdi
   13964:      	movl	$0x8, %esi
   13969:      	movq	%r15, %rdx
   1396c:      	callq	*%rax
   1396e:      	movq	(%rsp), %r15
   13972:      	movq	%r15, 0x40(%rsp)
   13977:      	leaq	0x20(%r15), %rdx
   1397b:      	movq	%rdx, 0x38(%rsp)
   13980:      	movq	0x30(%rsp), %r12
   13985:      	cmpq	0x18(%rsp), %r12
   1398a:      	jne	0x13997 <generic_lsm_path+0x8c67>
   1398c:      	cmpq	0x20(%rsp), %rdx
   13991:      	je	0x1679d <generic_lsm_path+0xba6d>
   13997:      	movl	$0x4, %eax
   1399c:      	leaq	0x10(%rsp), %rdi
   139a1:      	movl	$0x8, %esi
   139a6:      	callq	*%rax
   139a8:      	cmpq	0x10(%rsp), %r12
   139ad:      	je	0x13aa5 <generic_lsm_path+0x8d75>
   139b3:      	leaq	0x18(%r12), %rbx
   139b8:      	movl	$0x4, %eax
   139bd:      	movq	%rbp, %rdi
   139c0:      	movl	$0x8, %esi
   139c5:      	movq	%rbx, %rdx
   139c8:      	callq	*%rax
   139ca:      	cmpq	%r12, (%rsp)
   139ce:      	je	0x13aa5 <generic_lsm_path+0x8d75>
   139d4:      	movl	$0x4, %eax
   139d9:      	leaq	0x8(%rsp), %rdi
   139de:      	movl	$0x8, %esi
   139e3:      	movq	%rbx, %rdx
   139e6:      	callq	*%rax
   139e8:      	addq	$0x20, %r12
   139ec:      	movl	$0x4, %eax
   139f1:      	leaq	0x58(%rsp), %rdi
   139f6:      	movl	$0x10, %ecx
   139fb:      	movl	$0x10, %esi
   13a00:      	movq	%r12, %rdx
   13a03:      	callq	*%rax
   13a05:      	movq	0x28(%rsp), %rbx
   13a0a:      	movq	0x48(%rsp), %rax
   13a0f:      	movl	0x5c(%rsp), %r15d
   13a14:      	subq	%rbx, %rax
   13a17:      	movl	0x50(%rsp), %r12d
   13a1c:      	movl	%r15d, %edx
   13a1f:      	subl	%r12d, %edx
   13a22:      	movl	$0x0, %ecx
   13a27:      	cmovbl	%ecx, %edx
   13a2a:      	addq	0x60(%rsp), %rdx
   13a2f:      	xorl	%esi, %esi
   13a31:      	cmpl	%r15d, %r12d
   13a34:      	seta	%sil
   13a38:      	movl	%r15d, %ecx
   13a3b:      	cmovbl	%r12d, %ecx
   13a3f:      	addl	%ecx, %esi
   13a41:      	movl	%r12d, %edi
   13a44:      	subl	%esi, %edi
   13a46:      	movl	%edi, 0x50(%rsp)
   13a4a:      	subq	%rsi, %rax
   13a4d:      	jb	0x167a2 <generic_lsm_path+0xba72>
   13a53:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13a59:      	ja	0x167a2 <generic_lsm_path+0xba72>
   13a5f:      	cmpl	%r15d, %r12d
   13a62:      	jbe	0x13a68 <generic_lsm_path+0x8d38>
   13a64:      	movb	$0x2f, (%rbx,%rax)
   13a68:      	xorl	%edi, %edi
   13a6a:      	cmpl	%r15d, %r12d
   13a6d:      	seta	%dil
   13a71:      	movzbl	%cl, %esi
   13a74:      	addq	%rax, %rbx
   13a77:      	addq	%rbx, %rdi
   13a7a:      	movl	$0x4, %eax
   13a7f:      	callq	*%rax
   13a81:      	movq	%rbx, 0x48(%rsp)
   13a86:      	cmpl	%r15d, %r12d
   13a89:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   13a8f:      	movq	0x8(%rsp), %r12
   13a94:      	movq	%r12, 0x30(%rsp)
   13a99:      	movq	0x38(%rsp), %rdx
   13a9e:      	movq	0x40(%rsp), %r15
   13aa3:      	jmp	0x13af6 <generic_lsm_path+0x8dc6>
   13aa5:      	leaq	0x10(%r15), %rdx
   13aa9:      	movl	$0x4, %eax
   13aae:      	movq	%rbp, %rdi
   13ab1:      	movl	$0x8, %esi
   13ab6:      	callq	*%rax
   13ab8:      	movq	0x40(%rsp), %rax
   13abd:      	cmpq	(%rsp), %rax
   13ac1:      	je	0x1679d <generic_lsm_path+0xba6d>
   13ac7:      	addq	$0x18, %r15
   13acb:      	movl	$0x4, %eax
   13ad0:      	leaq	0x30(%rsp), %rdi
   13ad5:      	movl	$0x8, %esi
   13ada:      	movq	%r15, %rdx
   13add:      	callq	*%rax
   13adf:      	movq	(%rsp), %r15
   13ae3:      	movq	%r15, 0x40(%rsp)
   13ae8:      	leaq	0x20(%r15), %rdx
   13aec:      	movq	%rdx, 0x38(%rsp)
   13af1:      	movq	0x30(%rsp), %r12
   13af6:      	cmpq	0x18(%rsp), %r12
   13afb:      	jne	0x13b08 <generic_lsm_path+0x8dd8>
   13afd:      	cmpq	0x20(%rsp), %rdx
   13b02:      	je	0x1679d <generic_lsm_path+0xba6d>
   13b08:      	movl	$0x4, %eax
   13b0d:      	leaq	0x10(%rsp), %rdi
   13b12:      	movl	$0x8, %esi
   13b17:      	callq	*%rax
   13b19:      	cmpq	0x10(%rsp), %r12
   13b1e:      	je	0x13c16 <generic_lsm_path+0x8ee6>
   13b24:      	leaq	0x18(%r12), %rbx
   13b29:      	movl	$0x4, %eax
   13b2e:      	movq	%rbp, %rdi
   13b31:      	movl	$0x8, %esi
   13b36:      	movq	%rbx, %rdx
   13b39:      	callq	*%rax
   13b3b:      	cmpq	%r12, (%rsp)
   13b3f:      	je	0x13c16 <generic_lsm_path+0x8ee6>
   13b45:      	movl	$0x4, %eax
   13b4a:      	leaq	0x8(%rsp), %rdi
   13b4f:      	movl	$0x8, %esi
   13b54:      	movq	%rbx, %rdx
   13b57:      	callq	*%rax
   13b59:      	addq	$0x20, %r12
   13b5d:      	movl	$0x4, %eax
   13b62:      	leaq	0x58(%rsp), %rdi
   13b67:      	movl	$0x10, %ecx
   13b6c:      	movl	$0x10, %esi
   13b71:      	movq	%r12, %rdx
   13b74:      	callq	*%rax
   13b76:      	movq	0x28(%rsp), %rbx
   13b7b:      	movq	0x48(%rsp), %rax
   13b80:      	movl	0x5c(%rsp), %r15d
   13b85:      	subq	%rbx, %rax
   13b88:      	movl	0x50(%rsp), %r12d
   13b8d:      	movl	%r15d, %edx
   13b90:      	subl	%r12d, %edx
   13b93:      	movl	$0x0, %ecx
   13b98:      	cmovbl	%ecx, %edx
   13b9b:      	addq	0x60(%rsp), %rdx
   13ba0:      	xorl	%esi, %esi
   13ba2:      	cmpl	%r15d, %r12d
   13ba5:      	seta	%sil
   13ba9:      	movl	%r15d, %ecx
   13bac:      	cmovbl	%r12d, %ecx
   13bb0:      	addl	%ecx, %esi
   13bb2:      	movl	%r12d, %edi
   13bb5:      	subl	%esi, %edi
   13bb7:      	movl	%edi, 0x50(%rsp)
   13bbb:      	subq	%rsi, %rax
   13bbe:      	jb	0x167a2 <generic_lsm_path+0xba72>
   13bc4:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13bca:      	ja	0x167a2 <generic_lsm_path+0xba72>
   13bd0:      	cmpl	%r15d, %r12d
   13bd3:      	jbe	0x13bd9 <generic_lsm_path+0x8ea9>
   13bd5:      	movb	$0x2f, (%rbx,%rax)
   13bd9:      	xorl	%edi, %edi
   13bdb:      	cmpl	%r15d, %r12d
   13bde:      	seta	%dil
   13be2:      	movzbl	%cl, %esi
   13be5:      	addq	%rax, %rbx
   13be8:      	addq	%rbx, %rdi
   13beb:      	movl	$0x4, %eax
   13bf0:      	callq	*%rax
   13bf2:      	movq	%rbx, 0x48(%rsp)
   13bf7:      	cmpl	%r15d, %r12d
   13bfa:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   13c00:      	movq	0x8(%rsp), %r12
   13c05:      	movq	%r12, 0x30(%rsp)
   13c0a:      	movq	0x38(%rsp), %rdx
   13c0f:      	movq	0x40(%rsp), %r15
   13c14:      	jmp	0x13c67 <generic_lsm_path+0x8f37>
   13c16:      	leaq	0x10(%r15), %rdx
   13c1a:      	movl	$0x4, %eax
   13c1f:      	movq	%rbp, %rdi
   13c22:      	movl	$0x8, %esi
   13c27:      	callq	*%rax
   13c29:      	movq	0x40(%rsp), %rax
   13c2e:      	cmpq	(%rsp), %rax
   13c32:      	je	0x1679d <generic_lsm_path+0xba6d>
   13c38:      	addq	$0x18, %r15
   13c3c:      	movl	$0x4, %eax
   13c41:      	leaq	0x30(%rsp), %rdi
   13c46:      	movl	$0x8, %esi
   13c4b:      	movq	%r15, %rdx
   13c4e:      	callq	*%rax
   13c50:      	movq	(%rsp), %r15
   13c54:      	movq	%r15, 0x40(%rsp)
   13c59:      	leaq	0x20(%r15), %rdx
   13c5d:      	movq	%rdx, 0x38(%rsp)
   13c62:      	movq	0x30(%rsp), %r12
   13c67:      	cmpq	0x18(%rsp), %r12
   13c6c:      	jne	0x13c79 <generic_lsm_path+0x8f49>
   13c6e:      	cmpq	0x20(%rsp), %rdx
   13c73:      	je	0x1679d <generic_lsm_path+0xba6d>
   13c79:      	movl	$0x4, %eax
   13c7e:      	leaq	0x10(%rsp), %rdi
   13c83:      	movl	$0x8, %esi
   13c88:      	callq	*%rax
   13c8a:      	cmpq	0x10(%rsp), %r12
   13c8f:      	je	0x13d87 <generic_lsm_path+0x9057>
   13c95:      	leaq	0x18(%r12), %rbx
   13c9a:      	movl	$0x4, %eax
   13c9f:      	movq	%rbp, %rdi
   13ca2:      	movl	$0x8, %esi
   13ca7:      	movq	%rbx, %rdx
   13caa:      	callq	*%rax
   13cac:      	cmpq	%r12, (%rsp)
   13cb0:      	je	0x13d87 <generic_lsm_path+0x9057>
   13cb6:      	movl	$0x4, %eax
   13cbb:      	leaq	0x8(%rsp), %rdi
   13cc0:      	movl	$0x8, %esi
   13cc5:      	movq	%rbx, %rdx
   13cc8:      	callq	*%rax
   13cca:      	addq	$0x20, %r12
   13cce:      	movl	$0x4, %eax
   13cd3:      	leaq	0x58(%rsp), %rdi
   13cd8:      	movl	$0x10, %ecx
   13cdd:      	movl	$0x10, %esi
   13ce2:      	movq	%r12, %rdx
   13ce5:      	callq	*%rax
   13ce7:      	movq	0x28(%rsp), %rbx
   13cec:      	movq	0x48(%rsp), %rax
   13cf1:      	movl	0x5c(%rsp), %r15d
   13cf6:      	subq	%rbx, %rax
   13cf9:      	movl	0x50(%rsp), %r12d
   13cfe:      	movl	%r15d, %edx
   13d01:      	subl	%r12d, %edx
   13d04:      	movl	$0x0, %ecx
   13d09:      	cmovbl	%ecx, %edx
   13d0c:      	addq	0x60(%rsp), %rdx
   13d11:      	xorl	%esi, %esi
   13d13:      	cmpl	%r15d, %r12d
   13d16:      	seta	%sil
   13d1a:      	movl	%r15d, %ecx
   13d1d:      	cmovbl	%r12d, %ecx
   13d21:      	addl	%ecx, %esi
   13d23:      	movl	%r12d, %edi
   13d26:      	subl	%esi, %edi
   13d28:      	movl	%edi, 0x50(%rsp)
   13d2c:      	subq	%rsi, %rax
   13d2f:      	jb	0x167a2 <generic_lsm_path+0xba72>
   13d35:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13d3b:      	ja	0x167a2 <generic_lsm_path+0xba72>
   13d41:      	cmpl	%r15d, %r12d
   13d44:      	jbe	0x13d4a <generic_lsm_path+0x901a>
   13d46:      	movb	$0x2f, (%rbx,%rax)
   13d4a:      	xorl	%edi, %edi
   13d4c:      	cmpl	%r15d, %r12d
   13d4f:      	seta	%dil
   13d53:      	movzbl	%cl, %esi
   13d56:      	addq	%rax, %rbx
   13d59:      	addq	%rbx, %rdi
   13d5c:      	movl	$0x4, %eax
   13d61:      	callq	*%rax
   13d63:      	movq	%rbx, 0x48(%rsp)
   13d68:      	cmpl	%r15d, %r12d
   13d6b:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   13d71:      	movq	0x8(%rsp), %r12
   13d76:      	movq	%r12, 0x30(%rsp)
   13d7b:      	movq	0x38(%rsp), %rdx
   13d80:      	movq	0x40(%rsp), %r15
   13d85:      	jmp	0x13dd8 <generic_lsm_path+0x90a8>
   13d87:      	leaq	0x10(%r15), %rdx
   13d8b:      	movl	$0x4, %eax
   13d90:      	movq	%rbp, %rdi
   13d93:      	movl	$0x8, %esi
   13d98:      	callq	*%rax
   13d9a:      	movq	0x40(%rsp), %rax
   13d9f:      	cmpq	(%rsp), %rax
   13da3:      	je	0x1679d <generic_lsm_path+0xba6d>
   13da9:      	addq	$0x18, %r15
   13dad:      	movl	$0x4, %eax
   13db2:      	leaq	0x30(%rsp), %rdi
   13db7:      	movl	$0x8, %esi
   13dbc:      	movq	%r15, %rdx
   13dbf:      	callq	*%rax
   13dc1:      	movq	(%rsp), %r15
   13dc5:      	movq	%r15, 0x40(%rsp)
   13dca:      	leaq	0x20(%r15), %rdx
   13dce:      	movq	%rdx, 0x38(%rsp)
   13dd3:      	movq	0x30(%rsp), %r12
   13dd8:      	cmpq	0x18(%rsp), %r12
   13ddd:      	jne	0x13dea <generic_lsm_path+0x90ba>
   13ddf:      	cmpq	0x20(%rsp), %rdx
   13de4:      	je	0x1679d <generic_lsm_path+0xba6d>
   13dea:      	movl	$0x4, %eax
   13def:      	leaq	0x10(%rsp), %rdi
   13df4:      	movl	$0x8, %esi
   13df9:      	callq	*%rax
   13dfb:      	cmpq	0x10(%rsp), %r12
   13e00:      	je	0x13ef8 <generic_lsm_path+0x91c8>
   13e06:      	leaq	0x18(%r12), %rbx
   13e0b:      	movl	$0x4, %eax
   13e10:      	movq	%rbp, %rdi
   13e13:      	movl	$0x8, %esi
   13e18:      	movq	%rbx, %rdx
   13e1b:      	callq	*%rax
   13e1d:      	cmpq	%r12, (%rsp)
   13e21:      	je	0x13ef8 <generic_lsm_path+0x91c8>
   13e27:      	movl	$0x4, %eax
   13e2c:      	leaq	0x8(%rsp), %rdi
   13e31:      	movl	$0x8, %esi
   13e36:      	movq	%rbx, %rdx
   13e39:      	callq	*%rax
   13e3b:      	addq	$0x20, %r12
   13e3f:      	movl	$0x4, %eax
   13e44:      	leaq	0x58(%rsp), %rdi
   13e49:      	movl	$0x10, %ecx
   13e4e:      	movl	$0x10, %esi
   13e53:      	movq	%r12, %rdx
   13e56:      	callq	*%rax
   13e58:      	movq	0x28(%rsp), %rbx
   13e5d:      	movq	0x48(%rsp), %rax
   13e62:      	movl	0x5c(%rsp), %r15d
   13e67:      	subq	%rbx, %rax
   13e6a:      	movl	0x50(%rsp), %r12d
   13e6f:      	movl	%r15d, %edx
   13e72:      	subl	%r12d, %edx
   13e75:      	movl	$0x0, %ecx
   13e7a:      	cmovbl	%ecx, %edx
   13e7d:      	addq	0x60(%rsp), %rdx
   13e82:      	xorl	%esi, %esi
   13e84:      	cmpl	%r15d, %r12d
   13e87:      	seta	%sil
   13e8b:      	movl	%r15d, %ecx
   13e8e:      	cmovbl	%r12d, %ecx
   13e92:      	addl	%ecx, %esi
   13e94:      	movl	%r12d, %edi
   13e97:      	subl	%esi, %edi
   13e99:      	movl	%edi, 0x50(%rsp)
   13e9d:      	subq	%rsi, %rax
   13ea0:      	jb	0x167a2 <generic_lsm_path+0xba72>
   13ea6:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13eac:      	ja	0x167a2 <generic_lsm_path+0xba72>
   13eb2:      	cmpl	%r15d, %r12d
   13eb5:      	jbe	0x13ebb <generic_lsm_path+0x918b>
   13eb7:      	movb	$0x2f, (%rbx,%rax)
   13ebb:      	xorl	%edi, %edi
   13ebd:      	cmpl	%r15d, %r12d
   13ec0:      	seta	%dil
   13ec4:      	movzbl	%cl, %esi
   13ec7:      	addq	%rax, %rbx
   13eca:      	addq	%rbx, %rdi
   13ecd:      	movl	$0x4, %eax
   13ed2:      	callq	*%rax
   13ed4:      	movq	%rbx, 0x48(%rsp)
   13ed9:      	cmpl	%r15d, %r12d
   13edc:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   13ee2:      	movq	0x8(%rsp), %r12
   13ee7:      	movq	%r12, 0x30(%rsp)
   13eec:      	movq	0x38(%rsp), %rdx
   13ef1:      	movq	0x40(%rsp), %r15
   13ef6:      	jmp	0x13f49 <generic_lsm_path+0x9219>
   13ef8:      	leaq	0x10(%r15), %rdx
   13efc:      	movl	$0x4, %eax
   13f01:      	movq	%rbp, %rdi
   13f04:      	movl	$0x8, %esi
   13f09:      	callq	*%rax
   13f0b:      	movq	0x40(%rsp), %rax
   13f10:      	cmpq	(%rsp), %rax
   13f14:      	je	0x1679d <generic_lsm_path+0xba6d>
   13f1a:      	addq	$0x18, %r15
   13f1e:      	movl	$0x4, %eax
   13f23:      	leaq	0x30(%rsp), %rdi
   13f28:      	movl	$0x8, %esi
   13f2d:      	movq	%r15, %rdx
   13f30:      	callq	*%rax
   13f32:      	movq	(%rsp), %r15
   13f36:      	movq	%r15, 0x40(%rsp)
   13f3b:      	leaq	0x20(%r15), %rdx
   13f3f:      	movq	%rdx, 0x38(%rsp)
   13f44:      	movq	0x30(%rsp), %r12
   13f49:      	cmpq	0x18(%rsp), %r12
   13f4e:      	jne	0x13f5b <generic_lsm_path+0x922b>
   13f50:      	cmpq	0x20(%rsp), %rdx
   13f55:      	je	0x1679d <generic_lsm_path+0xba6d>
   13f5b:      	movl	$0x4, %eax
   13f60:      	leaq	0x10(%rsp), %rdi
   13f65:      	movl	$0x8, %esi
   13f6a:      	callq	*%rax
   13f6c:      	cmpq	0x10(%rsp), %r12
   13f71:      	je	0x14069 <generic_lsm_path+0x9339>
   13f77:      	leaq	0x18(%r12), %rbx
   13f7c:      	movl	$0x4, %eax
   13f81:      	movq	%rbp, %rdi
   13f84:      	movl	$0x8, %esi
   13f89:      	movq	%rbx, %rdx
   13f8c:      	callq	*%rax
   13f8e:      	cmpq	%r12, (%rsp)
   13f92:      	je	0x14069 <generic_lsm_path+0x9339>
   13f98:      	movl	$0x4, %eax
   13f9d:      	leaq	0x8(%rsp), %rdi
   13fa2:      	movl	$0x8, %esi
   13fa7:      	movq	%rbx, %rdx
   13faa:      	callq	*%rax
   13fac:      	addq	$0x20, %r12
   13fb0:      	movl	$0x4, %eax
   13fb5:      	leaq	0x58(%rsp), %rdi
   13fba:      	movl	$0x10, %ecx
   13fbf:      	movl	$0x10, %esi
   13fc4:      	movq	%r12, %rdx
   13fc7:      	callq	*%rax
   13fc9:      	movq	0x28(%rsp), %rbx
   13fce:      	movq	0x48(%rsp), %rax
   13fd3:      	movl	0x5c(%rsp), %r15d
   13fd8:      	subq	%rbx, %rax
   13fdb:      	movl	0x50(%rsp), %r12d
   13fe0:      	movl	%r15d, %edx
   13fe3:      	subl	%r12d, %edx
   13fe6:      	movl	$0x0, %ecx
   13feb:      	cmovbl	%ecx, %edx
   13fee:      	addq	0x60(%rsp), %rdx
   13ff3:      	xorl	%esi, %esi
   13ff5:      	cmpl	%r15d, %r12d
   13ff8:      	seta	%sil
   13ffc:      	movl	%r15d, %ecx
   13fff:      	cmovbl	%r12d, %ecx
   14003:      	addl	%ecx, %esi
   14005:      	movl	%r12d, %edi
   14008:      	subl	%esi, %edi
   1400a:      	movl	%edi, 0x50(%rsp)
   1400e:      	subq	%rsi, %rax
   14011:      	jb	0x167a2 <generic_lsm_path+0xba72>
   14017:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1401d:      	ja	0x167a2 <generic_lsm_path+0xba72>
   14023:      	cmpl	%r15d, %r12d
   14026:      	jbe	0x1402c <generic_lsm_path+0x92fc>
   14028:      	movb	$0x2f, (%rbx,%rax)
   1402c:      	xorl	%edi, %edi
   1402e:      	cmpl	%r15d, %r12d
   14031:      	seta	%dil
   14035:      	movzbl	%cl, %esi
   14038:      	addq	%rax, %rbx
   1403b:      	addq	%rbx, %rdi
   1403e:      	movl	$0x4, %eax
   14043:      	callq	*%rax
   14045:      	movq	%rbx, 0x48(%rsp)
   1404a:      	cmpl	%r15d, %r12d
   1404d:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   14053:      	movq	0x8(%rsp), %r12
   14058:      	movq	%r12, 0x30(%rsp)
   1405d:      	movq	0x38(%rsp), %rdx
   14062:      	movq	0x40(%rsp), %r15
   14067:      	jmp	0x140ba <generic_lsm_path+0x938a>
   14069:      	leaq	0x10(%r15), %rdx
   1406d:      	movl	$0x4, %eax
   14072:      	movq	%rbp, %rdi
   14075:      	movl	$0x8, %esi
   1407a:      	callq	*%rax
   1407c:      	movq	0x40(%rsp), %rax
   14081:      	cmpq	(%rsp), %rax
   14085:      	je	0x1679d <generic_lsm_path+0xba6d>
   1408b:      	addq	$0x18, %r15
   1408f:      	movl	$0x4, %eax
   14094:      	leaq	0x30(%rsp), %rdi
   14099:      	movl	$0x8, %esi
   1409e:      	movq	%r15, %rdx
   140a1:      	callq	*%rax
   140a3:      	movq	(%rsp), %r15
   140a7:      	movq	%r15, 0x40(%rsp)
   140ac:      	leaq	0x20(%r15), %rdx
   140b0:      	movq	%rdx, 0x38(%rsp)
   140b5:      	movq	0x30(%rsp), %r12
   140ba:      	cmpq	0x18(%rsp), %r12
   140bf:      	jne	0x140cc <generic_lsm_path+0x939c>
   140c1:      	cmpq	0x20(%rsp), %rdx
   140c6:      	je	0x1679d <generic_lsm_path+0xba6d>
   140cc:      	movl	$0x4, %eax
   140d1:      	leaq	0x10(%rsp), %rdi
   140d6:      	movl	$0x8, %esi
   140db:      	callq	*%rax
   140dd:      	cmpq	0x10(%rsp), %r12
   140e2:      	je	0x141da <generic_lsm_path+0x94aa>
   140e8:      	leaq	0x18(%r12), %rbx
   140ed:      	movl	$0x4, %eax
   140f2:      	movq	%rbp, %rdi
   140f5:      	movl	$0x8, %esi
   140fa:      	movq	%rbx, %rdx
   140fd:      	callq	*%rax
   140ff:      	cmpq	%r12, (%rsp)
   14103:      	je	0x141da <generic_lsm_path+0x94aa>
   14109:      	movl	$0x4, %eax
   1410e:      	leaq	0x8(%rsp), %rdi
   14113:      	movl	$0x8, %esi
   14118:      	movq	%rbx, %rdx
   1411b:      	callq	*%rax
   1411d:      	addq	$0x20, %r12
   14121:      	movl	$0x4, %eax
   14126:      	leaq	0x58(%rsp), %rdi
   1412b:      	movl	$0x10, %ecx
   14130:      	movl	$0x10, %esi
   14135:      	movq	%r12, %rdx
   14138:      	callq	*%rax
   1413a:      	movq	0x28(%rsp), %rbx
   1413f:      	movq	0x48(%rsp), %rax
   14144:      	movl	0x5c(%rsp), %r15d
   14149:      	subq	%rbx, %rax
   1414c:      	movl	0x50(%rsp), %r12d
   14151:      	movl	%r15d, %edx
   14154:      	subl	%r12d, %edx
   14157:      	movl	$0x0, %ecx
   1415c:      	cmovbl	%ecx, %edx
   1415f:      	addq	0x60(%rsp), %rdx
   14164:      	xorl	%esi, %esi
   14166:      	cmpl	%r15d, %r12d
   14169:      	seta	%sil
   1416d:      	movl	%r15d, %ecx
   14170:      	cmovbl	%r12d, %ecx
   14174:      	addl	%ecx, %esi
   14176:      	movl	%r12d, %edi
   14179:      	subl	%esi, %edi
   1417b:      	movl	%edi, 0x50(%rsp)
   1417f:      	subq	%rsi, %rax
   14182:      	jb	0x167a2 <generic_lsm_path+0xba72>
   14188:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1418e:      	ja	0x167a2 <generic_lsm_path+0xba72>
   14194:      	cmpl	%r15d, %r12d
   14197:      	jbe	0x1419d <generic_lsm_path+0x946d>
   14199:      	movb	$0x2f, (%rbx,%rax)
   1419d:      	xorl	%edi, %edi
   1419f:      	cmpl	%r15d, %r12d
   141a2:      	seta	%dil
   141a6:      	movzbl	%cl, %esi
   141a9:      	addq	%rax, %rbx
   141ac:      	addq	%rbx, %rdi
   141af:      	movl	$0x4, %eax
   141b4:      	callq	*%rax
   141b6:      	movq	%rbx, 0x48(%rsp)
   141bb:      	cmpl	%r15d, %r12d
   141be:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   141c4:      	movq	0x8(%rsp), %r12
   141c9:      	movq	%r12, 0x30(%rsp)
   141ce:      	movq	0x38(%rsp), %rdx
   141d3:      	movq	0x40(%rsp), %r15
   141d8:      	jmp	0x1422b <generic_lsm_path+0x94fb>
   141da:      	leaq	0x10(%r15), %rdx
   141de:      	movl	$0x4, %eax
   141e3:      	movq	%rbp, %rdi
   141e6:      	movl	$0x8, %esi
   141eb:      	callq	*%rax
   141ed:      	movq	0x40(%rsp), %rax
   141f2:      	cmpq	(%rsp), %rax
   141f6:      	je	0x1679d <generic_lsm_path+0xba6d>
   141fc:      	addq	$0x18, %r15
   14200:      	movl	$0x4, %eax
   14205:      	leaq	0x30(%rsp), %rdi
   1420a:      	movl	$0x8, %esi
   1420f:      	movq	%r15, %rdx
   14212:      	callq	*%rax
   14214:      	movq	(%rsp), %r15
   14218:      	movq	%r15, 0x40(%rsp)
   1421d:      	leaq	0x20(%r15), %rdx
   14221:      	movq	%rdx, 0x38(%rsp)
   14226:      	movq	0x30(%rsp), %r12
   1422b:      	cmpq	0x18(%rsp), %r12
   14230:      	jne	0x1423d <generic_lsm_path+0x950d>
   14232:      	cmpq	0x20(%rsp), %rdx
   14237:      	je	0x1679d <generic_lsm_path+0xba6d>
   1423d:      	movl	$0x4, %eax
   14242:      	leaq	0x10(%rsp), %rdi
   14247:      	movl	$0x8, %esi
   1424c:      	callq	*%rax
   1424e:      	cmpq	0x10(%rsp), %r12
   14253:      	je	0x1434b <generic_lsm_path+0x961b>
   14259:      	leaq	0x18(%r12), %rbx
   1425e:      	movl	$0x4, %eax
   14263:      	movq	%rbp, %rdi
   14266:      	movl	$0x8, %esi
   1426b:      	movq	%rbx, %rdx
   1426e:      	callq	*%rax
   14270:      	cmpq	%r12, (%rsp)
   14274:      	je	0x1434b <generic_lsm_path+0x961b>
   1427a:      	movl	$0x4, %eax
   1427f:      	leaq	0x8(%rsp), %rdi
   14284:      	movl	$0x8, %esi
   14289:      	movq	%rbx, %rdx
   1428c:      	callq	*%rax
   1428e:      	addq	$0x20, %r12
   14292:      	movl	$0x4, %eax
   14297:      	leaq	0x58(%rsp), %rdi
   1429c:      	movl	$0x10, %ecx
   142a1:      	movl	$0x10, %esi
   142a6:      	movq	%r12, %rdx
   142a9:      	callq	*%rax
   142ab:      	movq	0x28(%rsp), %rbx
   142b0:      	movq	0x48(%rsp), %rax
   142b5:      	movl	0x5c(%rsp), %r15d
   142ba:      	subq	%rbx, %rax
   142bd:      	movl	0x50(%rsp), %r12d
   142c2:      	movl	%r15d, %edx
   142c5:      	subl	%r12d, %edx
   142c8:      	movl	$0x0, %ecx
   142cd:      	cmovbl	%ecx, %edx
   142d0:      	addq	0x60(%rsp), %rdx
   142d5:      	xorl	%esi, %esi
   142d7:      	cmpl	%r15d, %r12d
   142da:      	seta	%sil
   142de:      	movl	%r15d, %ecx
   142e1:      	cmovbl	%r12d, %ecx
   142e5:      	addl	%ecx, %esi
   142e7:      	movl	%r12d, %edi
   142ea:      	subl	%esi, %edi
   142ec:      	movl	%edi, 0x50(%rsp)
   142f0:      	subq	%rsi, %rax
   142f3:      	jb	0x167a2 <generic_lsm_path+0xba72>
   142f9:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   142ff:      	ja	0x167a2 <generic_lsm_path+0xba72>
   14305:      	cmpl	%r15d, %r12d
   14308:      	jbe	0x1430e <generic_lsm_path+0x95de>
   1430a:      	movb	$0x2f, (%rbx,%rax)
   1430e:      	xorl	%edi, %edi
   14310:      	cmpl	%r15d, %r12d
   14313:      	seta	%dil
   14317:      	movzbl	%cl, %esi
   1431a:      	addq	%rax, %rbx
   1431d:      	addq	%rbx, %rdi
   14320:      	movl	$0x4, %eax
   14325:      	callq	*%rax
   14327:      	movq	%rbx, 0x48(%rsp)
   1432c:      	cmpl	%r15d, %r12d
   1432f:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   14335:      	movq	0x8(%rsp), %r12
   1433a:      	movq	%r12, 0x30(%rsp)
   1433f:      	movq	0x38(%rsp), %rdx
   14344:      	movq	0x40(%rsp), %r15
   14349:      	jmp	0x1439c <generic_lsm_path+0x966c>
   1434b:      	leaq	0x10(%r15), %rdx
   1434f:      	movl	$0x4, %eax
   14354:      	movq	%rbp, %rdi
   14357:      	movl	$0x8, %esi
   1435c:      	callq	*%rax
   1435e:      	movq	0x40(%rsp), %rax
   14363:      	cmpq	(%rsp), %rax
   14367:      	je	0x1679d <generic_lsm_path+0xba6d>
   1436d:      	addq	$0x18, %r15
   14371:      	movl	$0x4, %eax
   14376:      	leaq	0x30(%rsp), %rdi
   1437b:      	movl	$0x8, %esi
   14380:      	movq	%r15, %rdx
   14383:      	callq	*%rax
   14385:      	movq	(%rsp), %r15
   14389:      	movq	%r15, 0x40(%rsp)
   1438e:      	leaq	0x20(%r15), %rdx
   14392:      	movq	%rdx, 0x38(%rsp)
   14397:      	movq	0x30(%rsp), %r12
   1439c:      	cmpq	0x18(%rsp), %r12
   143a1:      	jne	0x143ae <generic_lsm_path+0x967e>
   143a3:      	cmpq	0x20(%rsp), %rdx
   143a8:      	je	0x1679d <generic_lsm_path+0xba6d>
   143ae:      	movl	$0x4, %eax
   143b3:      	leaq	0x10(%rsp), %rdi
   143b8:      	movl	$0x8, %esi
   143bd:      	callq	*%rax
   143bf:      	cmpq	0x10(%rsp), %r12
   143c4:      	je	0x144bc <generic_lsm_path+0x978c>
   143ca:      	leaq	0x18(%r12), %rbx
   143cf:      	movl	$0x4, %eax
   143d4:      	movq	%rbp, %rdi
   143d7:      	movl	$0x8, %esi
   143dc:      	movq	%rbx, %rdx
   143df:      	callq	*%rax
   143e1:      	cmpq	%r12, (%rsp)
   143e5:      	je	0x144bc <generic_lsm_path+0x978c>
   143eb:      	movl	$0x4, %eax
   143f0:      	leaq	0x8(%rsp), %rdi
   143f5:      	movl	$0x8, %esi
   143fa:      	movq	%rbx, %rdx
   143fd:      	callq	*%rax
   143ff:      	addq	$0x20, %r12
   14403:      	movl	$0x4, %eax
   14408:      	leaq	0x58(%rsp), %rdi
   1440d:      	movl	$0x10, %ecx
   14412:      	movl	$0x10, %esi
   14417:      	movq	%r12, %rdx
   1441a:      	callq	*%rax
   1441c:      	movq	0x28(%rsp), %rbx
   14421:      	movq	0x48(%rsp), %rax
   14426:      	movl	0x5c(%rsp), %r15d
   1442b:      	subq	%rbx, %rax
   1442e:      	movl	0x50(%rsp), %r12d
   14433:      	movl	%r15d, %edx
   14436:      	subl	%r12d, %edx
   14439:      	movl	$0x0, %ecx
   1443e:      	cmovbl	%ecx, %edx
   14441:      	addq	0x60(%rsp), %rdx
   14446:      	xorl	%esi, %esi
   14448:      	cmpl	%r15d, %r12d
   1444b:      	seta	%sil
   1444f:      	movl	%r15d, %ecx
   14452:      	cmovbl	%r12d, %ecx
   14456:      	addl	%ecx, %esi
   14458:      	movl	%r12d, %edi
   1445b:      	subl	%esi, %edi
   1445d:      	movl	%edi, 0x50(%rsp)
   14461:      	subq	%rsi, %rax
   14464:      	jb	0x167a2 <generic_lsm_path+0xba72>
   1446a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14470:      	ja	0x167a2 <generic_lsm_path+0xba72>
   14476:      	cmpl	%r15d, %r12d
   14479:      	jbe	0x1447f <generic_lsm_path+0x974f>
   1447b:      	movb	$0x2f, (%rbx,%rax)
   1447f:      	xorl	%edi, %edi
   14481:      	cmpl	%r15d, %r12d
   14484:      	seta	%dil
   14488:      	movzbl	%cl, %esi
   1448b:      	addq	%rax, %rbx
   1448e:      	addq	%rbx, %rdi
   14491:      	movl	$0x4, %eax
   14496:      	callq	*%rax
   14498:      	movq	%rbx, 0x48(%rsp)
   1449d:      	cmpl	%r15d, %r12d
   144a0:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   144a6:      	movq	0x8(%rsp), %r12
   144ab:      	movq	%r12, 0x30(%rsp)
   144b0:      	movq	0x38(%rsp), %rdx
   144b5:      	movq	0x40(%rsp), %r15
   144ba:      	jmp	0x1450d <generic_lsm_path+0x97dd>
   144bc:      	leaq	0x10(%r15), %rdx
   144c0:      	movl	$0x4, %eax
   144c5:      	movq	%rbp, %rdi
   144c8:      	movl	$0x8, %esi
   144cd:      	callq	*%rax
   144cf:      	movq	0x40(%rsp), %rax
   144d4:      	cmpq	(%rsp), %rax
   144d8:      	je	0x1679d <generic_lsm_path+0xba6d>
   144de:      	addq	$0x18, %r15
   144e2:      	movl	$0x4, %eax
   144e7:      	leaq	0x30(%rsp), %rdi
   144ec:      	movl	$0x8, %esi
   144f1:      	movq	%r15, %rdx
   144f4:      	callq	*%rax
   144f6:      	movq	(%rsp), %r15
   144fa:      	movq	%r15, 0x40(%rsp)
   144ff:      	leaq	0x20(%r15), %rdx
   14503:      	movq	%rdx, 0x38(%rsp)
   14508:      	movq	0x30(%rsp), %r12
   1450d:      	cmpq	0x18(%rsp), %r12
   14512:      	jne	0x1451f <generic_lsm_path+0x97ef>
   14514:      	cmpq	0x20(%rsp), %rdx
   14519:      	je	0x1679d <generic_lsm_path+0xba6d>
   1451f:      	movl	$0x4, %eax
   14524:      	leaq	0x10(%rsp), %rdi
   14529:      	movl	$0x8, %esi
   1452e:      	callq	*%rax
   14530:      	cmpq	0x10(%rsp), %r12
   14535:      	je	0x1462d <generic_lsm_path+0x98fd>
   1453b:      	leaq	0x18(%r12), %rbx
   14540:      	movl	$0x4, %eax
   14545:      	movq	%rbp, %rdi
   14548:      	movl	$0x8, %esi
   1454d:      	movq	%rbx, %rdx
   14550:      	callq	*%rax
   14552:      	cmpq	%r12, (%rsp)
   14556:      	je	0x1462d <generic_lsm_path+0x98fd>
   1455c:      	movl	$0x4, %eax
   14561:      	leaq	0x8(%rsp), %rdi
   14566:      	movl	$0x8, %esi
   1456b:      	movq	%rbx, %rdx
   1456e:      	callq	*%rax
   14570:      	addq	$0x20, %r12
   14574:      	movl	$0x4, %eax
   14579:      	leaq	0x58(%rsp), %rdi
   1457e:      	movl	$0x10, %ecx
   14583:      	movl	$0x10, %esi
   14588:      	movq	%r12, %rdx
   1458b:      	callq	*%rax
   1458d:      	movq	0x28(%rsp), %rbx
   14592:      	movq	0x48(%rsp), %rax
   14597:      	movl	0x5c(%rsp), %r15d
   1459c:      	subq	%rbx, %rax
   1459f:      	movl	0x50(%rsp), %r12d
   145a4:      	movl	%r15d, %edx
   145a7:      	subl	%r12d, %edx
   145aa:      	movl	$0x0, %ecx
   145af:      	cmovbl	%ecx, %edx
   145b2:      	addq	0x60(%rsp), %rdx
   145b7:      	xorl	%esi, %esi
   145b9:      	cmpl	%r15d, %r12d
   145bc:      	seta	%sil
   145c0:      	movl	%r15d, %ecx
   145c3:      	cmovbl	%r12d, %ecx
   145c7:      	addl	%ecx, %esi
   145c9:      	movl	%r12d, %edi
   145cc:      	subl	%esi, %edi
   145ce:      	movl	%edi, 0x50(%rsp)
   145d2:      	subq	%rsi, %rax
   145d5:      	jb	0x167a2 <generic_lsm_path+0xba72>
   145db:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   145e1:      	ja	0x167a2 <generic_lsm_path+0xba72>
   145e7:      	cmpl	%r15d, %r12d
   145ea:      	jbe	0x145f0 <generic_lsm_path+0x98c0>
   145ec:      	movb	$0x2f, (%rbx,%rax)
   145f0:      	xorl	%edi, %edi
   145f2:      	cmpl	%r15d, %r12d
   145f5:      	seta	%dil
   145f9:      	movzbl	%cl, %esi
   145fc:      	addq	%rax, %rbx
   145ff:      	addq	%rbx, %rdi
   14602:      	movl	$0x4, %eax
   14607:      	callq	*%rax
   14609:      	movq	%rbx, 0x48(%rsp)
   1460e:      	cmpl	%r15d, %r12d
   14611:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   14617:      	movq	0x8(%rsp), %r12
   1461c:      	movq	%r12, 0x30(%rsp)
   14621:      	movq	0x38(%rsp), %rdx
   14626:      	movq	0x40(%rsp), %r15
   1462b:      	jmp	0x1467e <generic_lsm_path+0x994e>
   1462d:      	leaq	0x10(%r15), %rdx
   14631:      	movl	$0x4, %eax
   14636:      	movq	%rbp, %rdi
   14639:      	movl	$0x8, %esi
   1463e:      	callq	*%rax
   14640:      	movq	0x40(%rsp), %rax
   14645:      	cmpq	(%rsp), %rax
   14649:      	je	0x1679d <generic_lsm_path+0xba6d>
   1464f:      	addq	$0x18, %r15
   14653:      	movl	$0x4, %eax
   14658:      	leaq	0x30(%rsp), %rdi
   1465d:      	movl	$0x8, %esi
   14662:      	movq	%r15, %rdx
   14665:      	callq	*%rax
   14667:      	movq	(%rsp), %r15
   1466b:      	movq	%r15, 0x40(%rsp)
   14670:      	leaq	0x20(%r15), %rdx
   14674:      	movq	%rdx, 0x38(%rsp)
   14679:      	movq	0x30(%rsp), %r12
   1467e:      	cmpq	0x18(%rsp), %r12
   14683:      	jne	0x14690 <generic_lsm_path+0x9960>
   14685:      	cmpq	0x20(%rsp), %rdx
   1468a:      	je	0x1679d <generic_lsm_path+0xba6d>
   14690:      	movl	$0x4, %eax
   14695:      	leaq	0x10(%rsp), %rdi
   1469a:      	movl	$0x8, %esi
   1469f:      	callq	*%rax
   146a1:      	cmpq	0x10(%rsp), %r12
   146a6:      	je	0x1479e <generic_lsm_path+0x9a6e>
   146ac:      	leaq	0x18(%r12), %rbx
   146b1:      	movl	$0x4, %eax
   146b6:      	movq	%rbp, %rdi
   146b9:      	movl	$0x8, %esi
   146be:      	movq	%rbx, %rdx
   146c1:      	callq	*%rax
   146c3:      	cmpq	%r12, (%rsp)
   146c7:      	je	0x1479e <generic_lsm_path+0x9a6e>
   146cd:      	movl	$0x4, %eax
   146d2:      	leaq	0x8(%rsp), %rdi
   146d7:      	movl	$0x8, %esi
   146dc:      	movq	%rbx, %rdx
   146df:      	callq	*%rax
   146e1:      	addq	$0x20, %r12
   146e5:      	movl	$0x4, %eax
   146ea:      	leaq	0x58(%rsp), %rdi
   146ef:      	movl	$0x10, %ecx
   146f4:      	movl	$0x10, %esi
   146f9:      	movq	%r12, %rdx
   146fc:      	callq	*%rax
   146fe:      	movq	0x28(%rsp), %rbx
   14703:      	movq	0x48(%rsp), %rax
   14708:      	movl	0x5c(%rsp), %r15d
   1470d:      	subq	%rbx, %rax
   14710:      	movl	0x50(%rsp), %r12d
   14715:      	movl	%r15d, %edx
   14718:      	subl	%r12d, %edx
   1471b:      	movl	$0x0, %ecx
   14720:      	cmovbl	%ecx, %edx
   14723:      	addq	0x60(%rsp), %rdx
   14728:      	xorl	%esi, %esi
   1472a:      	cmpl	%r15d, %r12d
   1472d:      	seta	%sil
   14731:      	movl	%r15d, %ecx
   14734:      	cmovbl	%r12d, %ecx
   14738:      	addl	%ecx, %esi
   1473a:      	movl	%r12d, %edi
   1473d:      	subl	%esi, %edi
   1473f:      	movl	%edi, 0x50(%rsp)
   14743:      	subq	%rsi, %rax
   14746:      	jb	0x167a2 <generic_lsm_path+0xba72>
   1474c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14752:      	ja	0x167a2 <generic_lsm_path+0xba72>
   14758:      	cmpl	%r15d, %r12d
   1475b:      	jbe	0x14761 <generic_lsm_path+0x9a31>
   1475d:      	movb	$0x2f, (%rbx,%rax)
   14761:      	xorl	%edi, %edi
   14763:      	cmpl	%r15d, %r12d
   14766:      	seta	%dil
   1476a:      	movzbl	%cl, %esi
   1476d:      	addq	%rax, %rbx
   14770:      	addq	%rbx, %rdi
   14773:      	movl	$0x4, %eax
   14778:      	callq	*%rax
   1477a:      	movq	%rbx, 0x48(%rsp)
   1477f:      	cmpl	%r15d, %r12d
   14782:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   14788:      	movq	0x8(%rsp), %r12
   1478d:      	movq	%r12, 0x30(%rsp)
   14792:      	movq	0x38(%rsp), %rdx
   14797:      	movq	0x40(%rsp), %r15
   1479c:      	jmp	0x147ef <generic_lsm_path+0x9abf>
   1479e:      	leaq	0x10(%r15), %rdx
   147a2:      	movl	$0x4, %eax
   147a7:      	movq	%rbp, %rdi
   147aa:      	movl	$0x8, %esi
   147af:      	callq	*%rax
   147b1:      	movq	0x40(%rsp), %rax
   147b6:      	cmpq	(%rsp), %rax
   147ba:      	je	0x1679d <generic_lsm_path+0xba6d>
   147c0:      	addq	$0x18, %r15
   147c4:      	movl	$0x4, %eax
   147c9:      	leaq	0x30(%rsp), %rdi
   147ce:      	movl	$0x8, %esi
   147d3:      	movq	%r15, %rdx
   147d6:      	callq	*%rax
   147d8:      	movq	(%rsp), %r15
   147dc:      	movq	%r15, 0x40(%rsp)
   147e1:      	leaq	0x20(%r15), %rdx
   147e5:      	movq	%rdx, 0x38(%rsp)
   147ea:      	movq	0x30(%rsp), %r12
   147ef:      	cmpq	0x18(%rsp), %r12
   147f4:      	jne	0x14801 <generic_lsm_path+0x9ad1>
   147f6:      	cmpq	0x20(%rsp), %rdx
   147fb:      	je	0x1679d <generic_lsm_path+0xba6d>
   14801:      	movl	$0x4, %eax
   14806:      	leaq	0x10(%rsp), %rdi
   1480b:      	movl	$0x8, %esi
   14810:      	callq	*%rax
   14812:      	cmpq	0x10(%rsp), %r12
   14817:      	je	0x1490f <generic_lsm_path+0x9bdf>
   1481d:      	leaq	0x18(%r12), %rbx
   14822:      	movl	$0x4, %eax
   14827:      	movq	%rbp, %rdi
   1482a:      	movl	$0x8, %esi
   1482f:      	movq	%rbx, %rdx
   14832:      	callq	*%rax
   14834:      	cmpq	%r12, (%rsp)
   14838:      	je	0x1490f <generic_lsm_path+0x9bdf>
   1483e:      	movl	$0x4, %eax
   14843:      	leaq	0x8(%rsp), %rdi
   14848:      	movl	$0x8, %esi
   1484d:      	movq	%rbx, %rdx
   14850:      	callq	*%rax
   14852:      	addq	$0x20, %r12
   14856:      	movl	$0x4, %eax
   1485b:      	leaq	0x58(%rsp), %rdi
   14860:      	movl	$0x10, %ecx
   14865:      	movl	$0x10, %esi
   1486a:      	movq	%r12, %rdx
   1486d:      	callq	*%rax
   1486f:      	movq	0x28(%rsp), %rbx
   14874:      	movq	0x48(%rsp), %rax
   14879:      	movl	0x5c(%rsp), %r15d
   1487e:      	subq	%rbx, %rax
   14881:      	movl	0x50(%rsp), %r12d
   14886:      	movl	%r15d, %edx
   14889:      	subl	%r12d, %edx
   1488c:      	movl	$0x0, %ecx
   14891:      	cmovbl	%ecx, %edx
   14894:      	addq	0x60(%rsp), %rdx
   14899:      	xorl	%esi, %esi
   1489b:      	cmpl	%r15d, %r12d
   1489e:      	seta	%sil
   148a2:      	movl	%r15d, %ecx
   148a5:      	cmovbl	%r12d, %ecx
   148a9:      	addl	%ecx, %esi
   148ab:      	movl	%r12d, %edi
   148ae:      	subl	%esi, %edi
   148b0:      	movl	%edi, 0x50(%rsp)
   148b4:      	subq	%rsi, %rax
   148b7:      	jb	0x167a2 <generic_lsm_path+0xba72>
   148bd:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   148c3:      	ja	0x167a2 <generic_lsm_path+0xba72>
   148c9:      	cmpl	%r15d, %r12d
   148cc:      	jbe	0x148d2 <generic_lsm_path+0x9ba2>
   148ce:      	movb	$0x2f, (%rbx,%rax)
   148d2:      	xorl	%edi, %edi
   148d4:      	cmpl	%r15d, %r12d
   148d7:      	seta	%dil
   148db:      	movzbl	%cl, %esi
   148de:      	addq	%rax, %rbx
   148e1:      	addq	%rbx, %rdi
   148e4:      	movl	$0x4, %eax
   148e9:      	callq	*%rax
   148eb:      	movq	%rbx, 0x48(%rsp)
   148f0:      	cmpl	%r15d, %r12d
   148f3:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   148f9:      	movq	0x8(%rsp), %r12
   148fe:      	movq	%r12, 0x30(%rsp)
   14903:      	movq	0x38(%rsp), %rdx
   14908:      	movq	0x40(%rsp), %r15
   1490d:      	jmp	0x14960 <generic_lsm_path+0x9c30>
   1490f:      	leaq	0x10(%r15), %rdx
   14913:      	movl	$0x4, %eax
   14918:      	movq	%rbp, %rdi
   1491b:      	movl	$0x8, %esi
   14920:      	callq	*%rax
   14922:      	movq	0x40(%rsp), %rax
   14927:      	cmpq	(%rsp), %rax
   1492b:      	je	0x1679d <generic_lsm_path+0xba6d>
   14931:      	addq	$0x18, %r15
   14935:      	movl	$0x4, %eax
   1493a:      	leaq	0x30(%rsp), %rdi
   1493f:      	movl	$0x8, %esi
   14944:      	movq	%r15, %rdx
   14947:      	callq	*%rax
   14949:      	movq	(%rsp), %r15
   1494d:      	movq	%r15, 0x40(%rsp)
   14952:      	leaq	0x20(%r15), %rdx
   14956:      	movq	%rdx, 0x38(%rsp)
   1495b:      	movq	0x30(%rsp), %r12
   14960:      	cmpq	0x18(%rsp), %r12
   14965:      	jne	0x14972 <generic_lsm_path+0x9c42>
   14967:      	cmpq	0x20(%rsp), %rdx
   1496c:      	je	0x1679d <generic_lsm_path+0xba6d>
   14972:      	movl	$0x4, %eax
   14977:      	leaq	0x10(%rsp), %rdi
   1497c:      	movl	$0x8, %esi
   14981:      	callq	*%rax
   14983:      	cmpq	0x10(%rsp), %r12
   14988:      	je	0x14a80 <generic_lsm_path+0x9d50>
   1498e:      	leaq	0x18(%r12), %rbx
   14993:      	movl	$0x4, %eax
   14998:      	movq	%rbp, %rdi
   1499b:      	movl	$0x8, %esi
   149a0:      	movq	%rbx, %rdx
   149a3:      	callq	*%rax
   149a5:      	cmpq	%r12, (%rsp)
   149a9:      	je	0x14a80 <generic_lsm_path+0x9d50>
   149af:      	movl	$0x4, %eax
   149b4:      	leaq	0x8(%rsp), %rdi
   149b9:      	movl	$0x8, %esi
   149be:      	movq	%rbx, %rdx
   149c1:      	callq	*%rax
   149c3:      	addq	$0x20, %r12
   149c7:      	movl	$0x4, %eax
   149cc:      	leaq	0x58(%rsp), %rdi
   149d1:      	movl	$0x10, %ecx
   149d6:      	movl	$0x10, %esi
   149db:      	movq	%r12, %rdx
   149de:      	callq	*%rax
   149e0:      	movq	0x28(%rsp), %rbx
   149e5:      	movq	0x48(%rsp), %rax
   149ea:      	movl	0x5c(%rsp), %r15d
   149ef:      	subq	%rbx, %rax
   149f2:      	movl	0x50(%rsp), %r12d
   149f7:      	movl	%r15d, %edx
   149fa:      	subl	%r12d, %edx
   149fd:      	movl	$0x0, %ecx
   14a02:      	cmovbl	%ecx, %edx
   14a05:      	addq	0x60(%rsp), %rdx
   14a0a:      	xorl	%esi, %esi
   14a0c:      	cmpl	%r15d, %r12d
   14a0f:      	seta	%sil
   14a13:      	movl	%r15d, %ecx
   14a16:      	cmovbl	%r12d, %ecx
   14a1a:      	addl	%ecx, %esi
   14a1c:      	movl	%r12d, %edi
   14a1f:      	subl	%esi, %edi
   14a21:      	movl	%edi, 0x50(%rsp)
   14a25:      	subq	%rsi, %rax
   14a28:      	jb	0x167a2 <generic_lsm_path+0xba72>
   14a2e:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14a34:      	ja	0x167a2 <generic_lsm_path+0xba72>
   14a3a:      	cmpl	%r15d, %r12d
   14a3d:      	jbe	0x14a43 <generic_lsm_path+0x9d13>
   14a3f:      	movb	$0x2f, (%rbx,%rax)
   14a43:      	xorl	%edi, %edi
   14a45:      	cmpl	%r15d, %r12d
   14a48:      	seta	%dil
   14a4c:      	movzbl	%cl, %esi
   14a4f:      	addq	%rax, %rbx
   14a52:      	addq	%rbx, %rdi
   14a55:      	movl	$0x4, %eax
   14a5a:      	callq	*%rax
   14a5c:      	movq	%rbx, 0x48(%rsp)
   14a61:      	cmpl	%r15d, %r12d
   14a64:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   14a6a:      	movq	0x8(%rsp), %r12
   14a6f:      	movq	%r12, 0x30(%rsp)
   14a74:      	movq	0x38(%rsp), %rdx
   14a79:      	movq	0x40(%rsp), %r15
   14a7e:      	jmp	0x14ad1 <generic_lsm_path+0x9da1>
   14a80:      	leaq	0x10(%r15), %rdx
   14a84:      	movl	$0x4, %eax
   14a89:      	movq	%rbp, %rdi
   14a8c:      	movl	$0x8, %esi
   14a91:      	callq	*%rax
   14a93:      	movq	0x40(%rsp), %rax
   14a98:      	cmpq	(%rsp), %rax
   14a9c:      	je	0x1679d <generic_lsm_path+0xba6d>
   14aa2:      	addq	$0x18, %r15
   14aa6:      	movl	$0x4, %eax
   14aab:      	leaq	0x30(%rsp), %rdi
   14ab0:      	movl	$0x8, %esi
   14ab5:      	movq	%r15, %rdx
   14ab8:      	callq	*%rax
   14aba:      	movq	(%rsp), %r15
   14abe:      	movq	%r15, 0x40(%rsp)
   14ac3:      	leaq	0x20(%r15), %rdx
   14ac7:      	movq	%rdx, 0x38(%rsp)
   14acc:      	movq	0x30(%rsp), %r12
   14ad1:      	cmpq	0x18(%rsp), %r12
   14ad6:      	jne	0x14ae3 <generic_lsm_path+0x9db3>
   14ad8:      	cmpq	0x20(%rsp), %rdx
   14add:      	je	0x1679d <generic_lsm_path+0xba6d>
   14ae3:      	movl	$0x4, %eax
   14ae8:      	leaq	0x10(%rsp), %rdi
   14aed:      	movl	$0x8, %esi
   14af2:      	callq	*%rax
   14af4:      	cmpq	0x10(%rsp), %r12
   14af9:      	je	0x14bf1 <generic_lsm_path+0x9ec1>
   14aff:      	leaq	0x18(%r12), %rbx
   14b04:      	movl	$0x4, %eax
   14b09:      	movq	%rbp, %rdi
   14b0c:      	movl	$0x8, %esi
   14b11:      	movq	%rbx, %rdx
   14b14:      	callq	*%rax
   14b16:      	cmpq	%r12, (%rsp)
   14b1a:      	je	0x14bf1 <generic_lsm_path+0x9ec1>
   14b20:      	movl	$0x4, %eax
   14b25:      	leaq	0x8(%rsp), %rdi
   14b2a:      	movl	$0x8, %esi
   14b2f:      	movq	%rbx, %rdx
   14b32:      	callq	*%rax
   14b34:      	addq	$0x20, %r12
   14b38:      	movl	$0x4, %eax
   14b3d:      	leaq	0x58(%rsp), %rdi
   14b42:      	movl	$0x10, %ecx
   14b47:      	movl	$0x10, %esi
   14b4c:      	movq	%r12, %rdx
   14b4f:      	callq	*%rax
   14b51:      	movq	0x28(%rsp), %rbx
   14b56:      	movq	0x48(%rsp), %rax
   14b5b:      	movl	0x5c(%rsp), %r15d
   14b60:      	subq	%rbx, %rax
   14b63:      	movl	0x50(%rsp), %r12d
   14b68:      	movl	%r15d, %edx
   14b6b:      	subl	%r12d, %edx
   14b6e:      	movl	$0x0, %ecx
   14b73:      	cmovbl	%ecx, %edx
   14b76:      	addq	0x60(%rsp), %rdx
   14b7b:      	xorl	%esi, %esi
   14b7d:      	cmpl	%r15d, %r12d
   14b80:      	seta	%sil
   14b84:      	movl	%r15d, %ecx
   14b87:      	cmovbl	%r12d, %ecx
   14b8b:      	addl	%ecx, %esi
   14b8d:      	movl	%r12d, %edi
   14b90:      	subl	%esi, %edi
   14b92:      	movl	%edi, 0x50(%rsp)
   14b96:      	subq	%rsi, %rax
   14b99:      	jb	0x167a2 <generic_lsm_path+0xba72>
   14b9f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14ba5:      	ja	0x167a2 <generic_lsm_path+0xba72>
   14bab:      	cmpl	%r15d, %r12d
   14bae:      	jbe	0x14bb4 <generic_lsm_path+0x9e84>
   14bb0:      	movb	$0x2f, (%rbx,%rax)
   14bb4:      	xorl	%edi, %edi
   14bb6:      	cmpl	%r15d, %r12d
   14bb9:      	seta	%dil
   14bbd:      	movzbl	%cl, %esi
   14bc0:      	addq	%rax, %rbx
   14bc3:      	addq	%rbx, %rdi
   14bc6:      	movl	$0x4, %eax
   14bcb:      	callq	*%rax
   14bcd:      	movq	%rbx, 0x48(%rsp)
   14bd2:      	cmpl	%r15d, %r12d
   14bd5:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   14bdb:      	movq	0x8(%rsp), %r12
   14be0:      	movq	%r12, 0x30(%rsp)
   14be5:      	movq	0x38(%rsp), %rdx
   14bea:      	movq	0x40(%rsp), %r15
   14bef:      	jmp	0x14c42 <generic_lsm_path+0x9f12>
   14bf1:      	leaq	0x10(%r15), %rdx
   14bf5:      	movl	$0x4, %eax
   14bfa:      	movq	%rbp, %rdi
   14bfd:      	movl	$0x8, %esi
   14c02:      	callq	*%rax
   14c04:      	movq	0x40(%rsp), %rax
   14c09:      	cmpq	(%rsp), %rax
   14c0d:      	je	0x1679d <generic_lsm_path+0xba6d>
   14c13:      	addq	$0x18, %r15
   14c17:      	movl	$0x4, %eax
   14c1c:      	leaq	0x30(%rsp), %rdi
   14c21:      	movl	$0x8, %esi
   14c26:      	movq	%r15, %rdx
   14c29:      	callq	*%rax
   14c2b:      	movq	(%rsp), %r15
   14c2f:      	movq	%r15, 0x40(%rsp)
   14c34:      	leaq	0x20(%r15), %rdx
   14c38:      	movq	%rdx, 0x38(%rsp)
   14c3d:      	movq	0x30(%rsp), %r12
   14c42:      	cmpq	0x18(%rsp), %r12
   14c47:      	jne	0x14c54 <generic_lsm_path+0x9f24>
   14c49:      	cmpq	0x20(%rsp), %rdx
   14c4e:      	je	0x1679d <generic_lsm_path+0xba6d>
   14c54:      	movl	$0x4, %eax
   14c59:      	leaq	0x10(%rsp), %rdi
   14c5e:      	movl	$0x8, %esi
   14c63:      	callq	*%rax
   14c65:      	cmpq	0x10(%rsp), %r12
   14c6a:      	je	0x14d62 <generic_lsm_path+0xa032>
   14c70:      	leaq	0x18(%r12), %rbx
   14c75:      	movl	$0x4, %eax
   14c7a:      	movq	%rbp, %rdi
   14c7d:      	movl	$0x8, %esi
   14c82:      	movq	%rbx, %rdx
   14c85:      	callq	*%rax
   14c87:      	cmpq	%r12, (%rsp)
   14c8b:      	je	0x14d62 <generic_lsm_path+0xa032>
   14c91:      	movl	$0x4, %eax
   14c96:      	leaq	0x8(%rsp), %rdi
   14c9b:      	movl	$0x8, %esi
   14ca0:      	movq	%rbx, %rdx
   14ca3:      	callq	*%rax
   14ca5:      	addq	$0x20, %r12
   14ca9:      	movl	$0x4, %eax
   14cae:      	leaq	0x58(%rsp), %rdi
   14cb3:      	movl	$0x10, %ecx
   14cb8:      	movl	$0x10, %esi
   14cbd:      	movq	%r12, %rdx
   14cc0:      	callq	*%rax
   14cc2:      	movq	0x28(%rsp), %rbx
   14cc7:      	movq	0x48(%rsp), %rax
   14ccc:      	movl	0x5c(%rsp), %r15d
   14cd1:      	subq	%rbx, %rax
   14cd4:      	movl	0x50(%rsp), %r12d
   14cd9:      	movl	%r15d, %edx
   14cdc:      	subl	%r12d, %edx
   14cdf:      	movl	$0x0, %ecx
   14ce4:      	cmovbl	%ecx, %edx
   14ce7:      	addq	0x60(%rsp), %rdx
   14cec:      	xorl	%esi, %esi
   14cee:      	cmpl	%r15d, %r12d
   14cf1:      	seta	%sil
   14cf5:      	movl	%r15d, %ecx
   14cf8:      	cmovbl	%r12d, %ecx
   14cfc:      	addl	%ecx, %esi
   14cfe:      	movl	%r12d, %edi
   14d01:      	subl	%esi, %edi
   14d03:      	movl	%edi, 0x50(%rsp)
   14d07:      	subq	%rsi, %rax
   14d0a:      	jb	0x167a2 <generic_lsm_path+0xba72>
   14d10:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14d16:      	ja	0x167a2 <generic_lsm_path+0xba72>
   14d1c:      	cmpl	%r15d, %r12d
   14d1f:      	jbe	0x14d25 <generic_lsm_path+0x9ff5>
   14d21:      	movb	$0x2f, (%rbx,%rax)
   14d25:      	xorl	%edi, %edi
   14d27:      	cmpl	%r15d, %r12d
   14d2a:      	seta	%dil
   14d2e:      	movzbl	%cl, %esi
   14d31:      	addq	%rax, %rbx
   14d34:      	addq	%rbx, %rdi
   14d37:      	movl	$0x4, %eax
   14d3c:      	callq	*%rax
   14d3e:      	movq	%rbx, 0x48(%rsp)
   14d43:      	cmpl	%r15d, %r12d
   14d46:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   14d4c:      	movq	0x8(%rsp), %r12
   14d51:      	movq	%r12, 0x30(%rsp)
   14d56:      	movq	0x38(%rsp), %rdx
   14d5b:      	movq	0x40(%rsp), %r15
   14d60:      	jmp	0x14db3 <generic_lsm_path+0xa083>
   14d62:      	leaq	0x10(%r15), %rdx
   14d66:      	movl	$0x4, %eax
   14d6b:      	movq	%rbp, %rdi
   14d6e:      	movl	$0x8, %esi
   14d73:      	callq	*%rax
   14d75:      	movq	0x40(%rsp), %rax
   14d7a:      	cmpq	(%rsp), %rax
   14d7e:      	je	0x1679d <generic_lsm_path+0xba6d>
   14d84:      	addq	$0x18, %r15
   14d88:      	movl	$0x4, %eax
   14d8d:      	leaq	0x30(%rsp), %rdi
   14d92:      	movl	$0x8, %esi
   14d97:      	movq	%r15, %rdx
   14d9a:      	callq	*%rax
   14d9c:      	movq	(%rsp), %r15
   14da0:      	movq	%r15, 0x40(%rsp)
   14da5:      	leaq	0x20(%r15), %rdx
   14da9:      	movq	%rdx, 0x38(%rsp)
   14dae:      	movq	0x30(%rsp), %r12
   14db3:      	cmpq	0x18(%rsp), %r12
   14db8:      	jne	0x14dc5 <generic_lsm_path+0xa095>
   14dba:      	cmpq	0x20(%rsp), %rdx
   14dbf:      	je	0x1679d <generic_lsm_path+0xba6d>
   14dc5:      	movl	$0x4, %eax
   14dca:      	leaq	0x10(%rsp), %rdi
   14dcf:      	movl	$0x8, %esi
   14dd4:      	callq	*%rax
   14dd6:      	cmpq	0x10(%rsp), %r12
   14ddb:      	je	0x14ed3 <generic_lsm_path+0xa1a3>
   14de1:      	leaq	0x18(%r12), %rbx
   14de6:      	movl	$0x4, %eax
   14deb:      	movq	%rbp, %rdi
   14dee:      	movl	$0x8, %esi
   14df3:      	movq	%rbx, %rdx
   14df6:      	callq	*%rax
   14df8:      	cmpq	%r12, (%rsp)
   14dfc:      	je	0x14ed3 <generic_lsm_path+0xa1a3>
   14e02:      	movl	$0x4, %eax
   14e07:      	leaq	0x8(%rsp), %rdi
   14e0c:      	movl	$0x8, %esi
   14e11:      	movq	%rbx, %rdx
   14e14:      	callq	*%rax
   14e16:      	addq	$0x20, %r12
   14e1a:      	movl	$0x4, %eax
   14e1f:      	leaq	0x58(%rsp), %rdi
   14e24:      	movl	$0x10, %ecx
   14e29:      	movl	$0x10, %esi
   14e2e:      	movq	%r12, %rdx
   14e31:      	callq	*%rax
   14e33:      	movq	0x28(%rsp), %rbx
   14e38:      	movq	0x48(%rsp), %rax
   14e3d:      	movl	0x5c(%rsp), %r15d
   14e42:      	subq	%rbx, %rax
   14e45:      	movl	0x50(%rsp), %r12d
   14e4a:      	movl	%r15d, %edx
   14e4d:      	subl	%r12d, %edx
   14e50:      	movl	$0x0, %ecx
   14e55:      	cmovbl	%ecx, %edx
   14e58:      	addq	0x60(%rsp), %rdx
   14e5d:      	xorl	%esi, %esi
   14e5f:      	cmpl	%r15d, %r12d
   14e62:      	seta	%sil
   14e66:      	movl	%r15d, %ecx
   14e69:      	cmovbl	%r12d, %ecx
   14e6d:      	addl	%ecx, %esi
   14e6f:      	movl	%r12d, %edi
   14e72:      	subl	%esi, %edi
   14e74:      	movl	%edi, 0x50(%rsp)
   14e78:      	subq	%rsi, %rax
   14e7b:      	jb	0x167a2 <generic_lsm_path+0xba72>
   14e81:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14e87:      	ja	0x167a2 <generic_lsm_path+0xba72>
   14e8d:      	cmpl	%r15d, %r12d
   14e90:      	jbe	0x14e96 <generic_lsm_path+0xa166>
   14e92:      	movb	$0x2f, (%rbx,%rax)
   14e96:      	xorl	%edi, %edi
   14e98:      	cmpl	%r15d, %r12d
   14e9b:      	seta	%dil
   14e9f:      	movzbl	%cl, %esi
   14ea2:      	addq	%rax, %rbx
   14ea5:      	addq	%rbx, %rdi
   14ea8:      	movl	$0x4, %eax
   14ead:      	callq	*%rax
   14eaf:      	movq	%rbx, 0x48(%rsp)
   14eb4:      	cmpl	%r15d, %r12d
   14eb7:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   14ebd:      	movq	0x8(%rsp), %r12
   14ec2:      	movq	%r12, 0x30(%rsp)
   14ec7:      	movq	0x38(%rsp), %rdx
   14ecc:      	movq	0x40(%rsp), %r15
   14ed1:      	jmp	0x14f24 <generic_lsm_path+0xa1f4>
   14ed3:      	leaq	0x10(%r15), %rdx
   14ed7:      	movl	$0x4, %eax
   14edc:      	movq	%rbp, %rdi
   14edf:      	movl	$0x8, %esi
   14ee4:      	callq	*%rax
   14ee6:      	movq	0x40(%rsp), %rax
   14eeb:      	cmpq	(%rsp), %rax
   14eef:      	je	0x1679d <generic_lsm_path+0xba6d>
   14ef5:      	addq	$0x18, %r15
   14ef9:      	movl	$0x4, %eax
   14efe:      	leaq	0x30(%rsp), %rdi
   14f03:      	movl	$0x8, %esi
   14f08:      	movq	%r15, %rdx
   14f0b:      	callq	*%rax
   14f0d:      	movq	(%rsp), %r15
   14f11:      	movq	%r15, 0x40(%rsp)
   14f16:      	leaq	0x20(%r15), %rdx
   14f1a:      	movq	%rdx, 0x38(%rsp)
   14f1f:      	movq	0x30(%rsp), %r12
   14f24:      	cmpq	0x18(%rsp), %r12
   14f29:      	jne	0x14f36 <generic_lsm_path+0xa206>
   14f2b:      	cmpq	0x20(%rsp), %rdx
   14f30:      	je	0x1679d <generic_lsm_path+0xba6d>
   14f36:      	movl	$0x4, %eax
   14f3b:      	leaq	0x10(%rsp), %rdi
   14f40:      	movl	$0x8, %esi
   14f45:      	callq	*%rax
   14f47:      	cmpq	0x10(%rsp), %r12
   14f4c:      	je	0x15044 <generic_lsm_path+0xa314>
   14f52:      	leaq	0x18(%r12), %rbx
   14f57:      	movl	$0x4, %eax
   14f5c:      	movq	%rbp, %rdi
   14f5f:      	movl	$0x8, %esi
   14f64:      	movq	%rbx, %rdx
   14f67:      	callq	*%rax
   14f69:      	cmpq	%r12, (%rsp)
   14f6d:      	je	0x15044 <generic_lsm_path+0xa314>
   14f73:      	movl	$0x4, %eax
   14f78:      	leaq	0x8(%rsp), %rdi
   14f7d:      	movl	$0x8, %esi
   14f82:      	movq	%rbx, %rdx
   14f85:      	callq	*%rax
   14f87:      	addq	$0x20, %r12
   14f8b:      	movl	$0x4, %eax
   14f90:      	leaq	0x58(%rsp), %rdi
   14f95:      	movl	$0x10, %ecx
   14f9a:      	movl	$0x10, %esi
   14f9f:      	movq	%r12, %rdx
   14fa2:      	callq	*%rax
   14fa4:      	movq	0x28(%rsp), %rbx
   14fa9:      	movq	0x48(%rsp), %rax
   14fae:      	movl	0x5c(%rsp), %r15d
   14fb3:      	subq	%rbx, %rax
   14fb6:      	movl	0x50(%rsp), %r12d
   14fbb:      	movl	%r15d, %edx
   14fbe:      	subl	%r12d, %edx
   14fc1:      	movl	$0x0, %ecx
   14fc6:      	cmovbl	%ecx, %edx
   14fc9:      	addq	0x60(%rsp), %rdx
   14fce:      	xorl	%esi, %esi
   14fd0:      	cmpl	%r15d, %r12d
   14fd3:      	seta	%sil
   14fd7:      	movl	%r15d, %ecx
   14fda:      	cmovbl	%r12d, %ecx
   14fde:      	addl	%ecx, %esi
   14fe0:      	movl	%r12d, %edi
   14fe3:      	subl	%esi, %edi
   14fe5:      	movl	%edi, 0x50(%rsp)
   14fe9:      	subq	%rsi, %rax
   14fec:      	jb	0x167a2 <generic_lsm_path+0xba72>
   14ff2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14ff8:      	ja	0x167a2 <generic_lsm_path+0xba72>
   14ffe:      	cmpl	%r15d, %r12d
   15001:      	jbe	0x15007 <generic_lsm_path+0xa2d7>
   15003:      	movb	$0x2f, (%rbx,%rax)
   15007:      	xorl	%edi, %edi
   15009:      	cmpl	%r15d, %r12d
   1500c:      	seta	%dil
   15010:      	movzbl	%cl, %esi
   15013:      	addq	%rax, %rbx
   15016:      	addq	%rbx, %rdi
   15019:      	movl	$0x4, %eax
   1501e:      	callq	*%rax
   15020:      	movq	%rbx, 0x48(%rsp)
   15025:      	cmpl	%r15d, %r12d
   15028:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   1502e:      	movq	0x8(%rsp), %r12
   15033:      	movq	%r12, 0x30(%rsp)
   15038:      	movq	0x38(%rsp), %rdx
   1503d:      	movq	0x40(%rsp), %r15
   15042:      	jmp	0x15095 <generic_lsm_path+0xa365>
   15044:      	leaq	0x10(%r15), %rdx
   15048:      	movl	$0x4, %eax
   1504d:      	movq	%rbp, %rdi
   15050:      	movl	$0x8, %esi
   15055:      	callq	*%rax
   15057:      	movq	0x40(%rsp), %rax
   1505c:      	cmpq	(%rsp), %rax
   15060:      	je	0x1679d <generic_lsm_path+0xba6d>
   15066:      	addq	$0x18, %r15
   1506a:      	movl	$0x4, %eax
   1506f:      	leaq	0x30(%rsp), %rdi
   15074:      	movl	$0x8, %esi
   15079:      	movq	%r15, %rdx
   1507c:      	callq	*%rax
   1507e:      	movq	(%rsp), %r15
   15082:      	movq	%r15, 0x40(%rsp)
   15087:      	leaq	0x20(%r15), %rdx
   1508b:      	movq	%rdx, 0x38(%rsp)
   15090:      	movq	0x30(%rsp), %r12
   15095:      	cmpq	0x18(%rsp), %r12
   1509a:      	jne	0x150a7 <generic_lsm_path+0xa377>
   1509c:      	cmpq	0x20(%rsp), %rdx
   150a1:      	je	0x1679d <generic_lsm_path+0xba6d>
   150a7:      	movl	$0x4, %eax
   150ac:      	leaq	0x10(%rsp), %rdi
   150b1:      	movl	$0x8, %esi
   150b6:      	callq	*%rax
   150b8:      	cmpq	0x10(%rsp), %r12
   150bd:      	je	0x151b5 <generic_lsm_path+0xa485>
   150c3:      	leaq	0x18(%r12), %rbx
   150c8:      	movl	$0x4, %eax
   150cd:      	movq	%rbp, %rdi
   150d0:      	movl	$0x8, %esi
   150d5:      	movq	%rbx, %rdx
   150d8:      	callq	*%rax
   150da:      	cmpq	%r12, (%rsp)
   150de:      	je	0x151b5 <generic_lsm_path+0xa485>
   150e4:      	movl	$0x4, %eax
   150e9:      	leaq	0x8(%rsp), %rdi
   150ee:      	movl	$0x8, %esi
   150f3:      	movq	%rbx, %rdx
   150f6:      	callq	*%rax
   150f8:      	addq	$0x20, %r12
   150fc:      	movl	$0x4, %eax
   15101:      	leaq	0x58(%rsp), %rdi
   15106:      	movl	$0x10, %ecx
   1510b:      	movl	$0x10, %esi
   15110:      	movq	%r12, %rdx
   15113:      	callq	*%rax
   15115:      	movq	0x28(%rsp), %rbx
   1511a:      	movq	0x48(%rsp), %rax
   1511f:      	movl	0x5c(%rsp), %r15d
   15124:      	subq	%rbx, %rax
   15127:      	movl	0x50(%rsp), %r12d
   1512c:      	movl	%r15d, %edx
   1512f:      	subl	%r12d, %edx
   15132:      	movl	$0x0, %ecx
   15137:      	cmovbl	%ecx, %edx
   1513a:      	addq	0x60(%rsp), %rdx
   1513f:      	xorl	%esi, %esi
   15141:      	cmpl	%r15d, %r12d
   15144:      	seta	%sil
   15148:      	movl	%r15d, %ecx
   1514b:      	cmovbl	%r12d, %ecx
   1514f:      	addl	%ecx, %esi
   15151:      	movl	%r12d, %edi
   15154:      	subl	%esi, %edi
   15156:      	movl	%edi, 0x50(%rsp)
   1515a:      	subq	%rsi, %rax
   1515d:      	jb	0x167a2 <generic_lsm_path+0xba72>
   15163:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15169:      	ja	0x167a2 <generic_lsm_path+0xba72>
   1516f:      	cmpl	%r15d, %r12d
   15172:      	jbe	0x15178 <generic_lsm_path+0xa448>
   15174:      	movb	$0x2f, (%rbx,%rax)
   15178:      	xorl	%edi, %edi
   1517a:      	cmpl	%r15d, %r12d
   1517d:      	seta	%dil
   15181:      	movzbl	%cl, %esi
   15184:      	addq	%rax, %rbx
   15187:      	addq	%rbx, %rdi
   1518a:      	movl	$0x4, %eax
   1518f:      	callq	*%rax
   15191:      	movq	%rbx, 0x48(%rsp)
   15196:      	cmpl	%r15d, %r12d
   15199:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   1519f:      	movq	0x8(%rsp), %r12
   151a4:      	movq	%r12, 0x30(%rsp)
   151a9:      	movq	0x38(%rsp), %rdx
   151ae:      	movq	0x40(%rsp), %r15
   151b3:      	jmp	0x15206 <generic_lsm_path+0xa4d6>
   151b5:      	leaq	0x10(%r15), %rdx
   151b9:      	movl	$0x4, %eax
   151be:      	movq	%rbp, %rdi
   151c1:      	movl	$0x8, %esi
   151c6:      	callq	*%rax
   151c8:      	movq	0x40(%rsp), %rax
   151cd:      	cmpq	(%rsp), %rax
   151d1:      	je	0x1679d <generic_lsm_path+0xba6d>
   151d7:      	addq	$0x18, %r15
   151db:      	movl	$0x4, %eax
   151e0:      	leaq	0x30(%rsp), %rdi
   151e5:      	movl	$0x8, %esi
   151ea:      	movq	%r15, %rdx
   151ed:      	callq	*%rax
   151ef:      	movq	(%rsp), %r15
   151f3:      	movq	%r15, 0x40(%rsp)
   151f8:      	leaq	0x20(%r15), %rdx
   151fc:      	movq	%rdx, 0x38(%rsp)
   15201:      	movq	0x30(%rsp), %r12
   15206:      	cmpq	0x18(%rsp), %r12
   1520b:      	jne	0x15218 <generic_lsm_path+0xa4e8>
   1520d:      	cmpq	0x20(%rsp), %rdx
   15212:      	je	0x1679d <generic_lsm_path+0xba6d>
   15218:      	movl	$0x4, %eax
   1521d:      	leaq	0x10(%rsp), %rdi
   15222:      	movl	$0x8, %esi
   15227:      	callq	*%rax
   15229:      	cmpq	0x10(%rsp), %r12
   1522e:      	je	0x15326 <generic_lsm_path+0xa5f6>
   15234:      	leaq	0x18(%r12), %rbx
   15239:      	movl	$0x4, %eax
   1523e:      	movq	%rbp, %rdi
   15241:      	movl	$0x8, %esi
   15246:      	movq	%rbx, %rdx
   15249:      	callq	*%rax
   1524b:      	cmpq	%r12, (%rsp)
   1524f:      	je	0x15326 <generic_lsm_path+0xa5f6>
   15255:      	movl	$0x4, %eax
   1525a:      	leaq	0x8(%rsp), %rdi
   1525f:      	movl	$0x8, %esi
   15264:      	movq	%rbx, %rdx
   15267:      	callq	*%rax
   15269:      	addq	$0x20, %r12
   1526d:      	movl	$0x4, %eax
   15272:      	leaq	0x58(%rsp), %rdi
   15277:      	movl	$0x10, %ecx
   1527c:      	movl	$0x10, %esi
   15281:      	movq	%r12, %rdx
   15284:      	callq	*%rax
   15286:      	movq	0x28(%rsp), %rbx
   1528b:      	movq	0x48(%rsp), %rax
   15290:      	movl	0x5c(%rsp), %r15d
   15295:      	subq	%rbx, %rax
   15298:      	movl	0x50(%rsp), %r12d
   1529d:      	movl	%r15d, %edx
   152a0:      	subl	%r12d, %edx
   152a3:      	movl	$0x0, %ecx
   152a8:      	cmovbl	%ecx, %edx
   152ab:      	addq	0x60(%rsp), %rdx
   152b0:      	xorl	%esi, %esi
   152b2:      	cmpl	%r15d, %r12d
   152b5:      	seta	%sil
   152b9:      	movl	%r15d, %ecx
   152bc:      	cmovbl	%r12d, %ecx
   152c0:      	addl	%ecx, %esi
   152c2:      	movl	%r12d, %edi
   152c5:      	subl	%esi, %edi
   152c7:      	movl	%edi, 0x50(%rsp)
   152cb:      	subq	%rsi, %rax
   152ce:      	jb	0x167a2 <generic_lsm_path+0xba72>
   152d4:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   152da:      	ja	0x167a2 <generic_lsm_path+0xba72>
   152e0:      	cmpl	%r15d, %r12d
   152e3:      	jbe	0x152e9 <generic_lsm_path+0xa5b9>
   152e5:      	movb	$0x2f, (%rbx,%rax)
   152e9:      	xorl	%edi, %edi
   152eb:      	cmpl	%r15d, %r12d
   152ee:      	seta	%dil
   152f2:      	movzbl	%cl, %esi
   152f5:      	addq	%rax, %rbx
   152f8:      	addq	%rbx, %rdi
   152fb:      	movl	$0x4, %eax
   15300:      	callq	*%rax
   15302:      	movq	%rbx, 0x48(%rsp)
   15307:      	cmpl	%r15d, %r12d
   1530a:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   15310:      	movq	0x8(%rsp), %r12
   15315:      	movq	%r12, 0x30(%rsp)
   1531a:      	movq	0x38(%rsp), %rdx
   1531f:      	movq	0x40(%rsp), %r15
   15324:      	jmp	0x15377 <generic_lsm_path+0xa647>
   15326:      	leaq	0x10(%r15), %rdx
   1532a:      	movl	$0x4, %eax
   1532f:      	movq	%rbp, %rdi
   15332:      	movl	$0x8, %esi
   15337:      	callq	*%rax
   15339:      	movq	0x40(%rsp), %rax
   1533e:      	cmpq	(%rsp), %rax
   15342:      	je	0x1679d <generic_lsm_path+0xba6d>
   15348:      	addq	$0x18, %r15
   1534c:      	movl	$0x4, %eax
   15351:      	leaq	0x30(%rsp), %rdi
   15356:      	movl	$0x8, %esi
   1535b:      	movq	%r15, %rdx
   1535e:      	callq	*%rax
   15360:      	movq	(%rsp), %r15
   15364:      	movq	%r15, 0x40(%rsp)
   15369:      	leaq	0x20(%r15), %rdx
   1536d:      	movq	%rdx, 0x38(%rsp)
   15372:      	movq	0x30(%rsp), %r12
   15377:      	cmpq	0x18(%rsp), %r12
   1537c:      	jne	0x15389 <generic_lsm_path+0xa659>
   1537e:      	cmpq	0x20(%rsp), %rdx
   15383:      	je	0x1679d <generic_lsm_path+0xba6d>
   15389:      	movl	$0x4, %eax
   1538e:      	leaq	0x10(%rsp), %rdi
   15393:      	movl	$0x8, %esi
   15398:      	callq	*%rax
   1539a:      	cmpq	0x10(%rsp), %r12
   1539f:      	je	0x15497 <generic_lsm_path+0xa767>
   153a5:      	leaq	0x18(%r12), %rbx
   153aa:      	movl	$0x4, %eax
   153af:      	movq	%rbp, %rdi
   153b2:      	movl	$0x8, %esi
   153b7:      	movq	%rbx, %rdx
   153ba:      	callq	*%rax
   153bc:      	cmpq	%r12, (%rsp)
   153c0:      	je	0x15497 <generic_lsm_path+0xa767>
   153c6:      	movl	$0x4, %eax
   153cb:      	leaq	0x8(%rsp), %rdi
   153d0:      	movl	$0x8, %esi
   153d5:      	movq	%rbx, %rdx
   153d8:      	callq	*%rax
   153da:      	addq	$0x20, %r12
   153de:      	movl	$0x4, %eax
   153e3:      	leaq	0x58(%rsp), %rdi
   153e8:      	movl	$0x10, %ecx
   153ed:      	movl	$0x10, %esi
   153f2:      	movq	%r12, %rdx
   153f5:      	callq	*%rax
   153f7:      	movq	0x28(%rsp), %rbx
   153fc:      	movq	0x48(%rsp), %rax
   15401:      	movl	0x5c(%rsp), %r15d
   15406:      	subq	%rbx, %rax
   15409:      	movl	0x50(%rsp), %r12d
   1540e:      	movl	%r15d, %edx
   15411:      	subl	%r12d, %edx
   15414:      	movl	$0x0, %ecx
   15419:      	cmovbl	%ecx, %edx
   1541c:      	addq	0x60(%rsp), %rdx
   15421:      	xorl	%esi, %esi
   15423:      	cmpl	%r15d, %r12d
   15426:      	seta	%sil
   1542a:      	movl	%r15d, %ecx
   1542d:      	cmovbl	%r12d, %ecx
   15431:      	addl	%ecx, %esi
   15433:      	movl	%r12d, %edi
   15436:      	subl	%esi, %edi
   15438:      	movl	%edi, 0x50(%rsp)
   1543c:      	subq	%rsi, %rax
   1543f:      	jb	0x167a2 <generic_lsm_path+0xba72>
   15445:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1544b:      	ja	0x167a2 <generic_lsm_path+0xba72>
   15451:      	cmpl	%r15d, %r12d
   15454:      	jbe	0x1545a <generic_lsm_path+0xa72a>
   15456:      	movb	$0x2f, (%rbx,%rax)
   1545a:      	xorl	%edi, %edi
   1545c:      	cmpl	%r15d, %r12d
   1545f:      	seta	%dil
   15463:      	movzbl	%cl, %esi
   15466:      	addq	%rax, %rbx
   15469:      	addq	%rbx, %rdi
   1546c:      	movl	$0x4, %eax
   15471:      	callq	*%rax
   15473:      	movq	%rbx, 0x48(%rsp)
   15478:      	cmpl	%r15d, %r12d
   1547b:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   15481:      	movq	0x8(%rsp), %r12
   15486:      	movq	%r12, 0x30(%rsp)
   1548b:      	movq	0x38(%rsp), %rdx
   15490:      	movq	0x40(%rsp), %r15
   15495:      	jmp	0x154e8 <generic_lsm_path+0xa7b8>
   15497:      	leaq	0x10(%r15), %rdx
   1549b:      	movl	$0x4, %eax
   154a0:      	movq	%rbp, %rdi
   154a3:      	movl	$0x8, %esi
   154a8:      	callq	*%rax
   154aa:      	movq	0x40(%rsp), %rax
   154af:      	cmpq	(%rsp), %rax
   154b3:      	je	0x1679d <generic_lsm_path+0xba6d>
   154b9:      	addq	$0x18, %r15
   154bd:      	movl	$0x4, %eax
   154c2:      	leaq	0x30(%rsp), %rdi
   154c7:      	movl	$0x8, %esi
   154cc:      	movq	%r15, %rdx
   154cf:      	callq	*%rax
   154d1:      	movq	(%rsp), %r15
   154d5:      	movq	%r15, 0x40(%rsp)
   154da:      	leaq	0x20(%r15), %rdx
   154de:      	movq	%rdx, 0x38(%rsp)
   154e3:      	movq	0x30(%rsp), %r12
   154e8:      	cmpq	0x18(%rsp), %r12
   154ed:      	jne	0x154fa <generic_lsm_path+0xa7ca>
   154ef:      	cmpq	0x20(%rsp), %rdx
   154f4:      	je	0x1679d <generic_lsm_path+0xba6d>
   154fa:      	movl	$0x4, %eax
   154ff:      	leaq	0x10(%rsp), %rdi
   15504:      	movl	$0x8, %esi
   15509:      	callq	*%rax
   1550b:      	cmpq	0x10(%rsp), %r12
   15510:      	je	0x15608 <generic_lsm_path+0xa8d8>
   15516:      	leaq	0x18(%r12), %rbx
   1551b:      	movl	$0x4, %eax
   15520:      	movq	%rbp, %rdi
   15523:      	movl	$0x8, %esi
   15528:      	movq	%rbx, %rdx
   1552b:      	callq	*%rax
   1552d:      	cmpq	%r12, (%rsp)
   15531:      	je	0x15608 <generic_lsm_path+0xa8d8>
   15537:      	movl	$0x4, %eax
   1553c:      	leaq	0x8(%rsp), %rdi
   15541:      	movl	$0x8, %esi
   15546:      	movq	%rbx, %rdx
   15549:      	callq	*%rax
   1554b:      	addq	$0x20, %r12
   1554f:      	movl	$0x4, %eax
   15554:      	leaq	0x58(%rsp), %rdi
   15559:      	movl	$0x10, %ecx
   1555e:      	movl	$0x10, %esi
   15563:      	movq	%r12, %rdx
   15566:      	callq	*%rax
   15568:      	movq	0x28(%rsp), %rbx
   1556d:      	movq	0x48(%rsp), %rax
   15572:      	movl	0x5c(%rsp), %r15d
   15577:      	subq	%rbx, %rax
   1557a:      	movl	0x50(%rsp), %r12d
   1557f:      	movl	%r15d, %edx
   15582:      	subl	%r12d, %edx
   15585:      	movl	$0x0, %ecx
   1558a:      	cmovbl	%ecx, %edx
   1558d:      	addq	0x60(%rsp), %rdx
   15592:      	xorl	%esi, %esi
   15594:      	cmpl	%r15d, %r12d
   15597:      	seta	%sil
   1559b:      	movl	%r15d, %ecx
   1559e:      	cmovbl	%r12d, %ecx
   155a2:      	addl	%ecx, %esi
   155a4:      	movl	%r12d, %edi
   155a7:      	subl	%esi, %edi
   155a9:      	movl	%edi, 0x50(%rsp)
   155ad:      	subq	%rsi, %rax
   155b0:      	jb	0x167a2 <generic_lsm_path+0xba72>
   155b6:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   155bc:      	ja	0x167a2 <generic_lsm_path+0xba72>
   155c2:      	cmpl	%r15d, %r12d
   155c5:      	jbe	0x155cb <generic_lsm_path+0xa89b>
   155c7:      	movb	$0x2f, (%rbx,%rax)
   155cb:      	xorl	%edi, %edi
   155cd:      	cmpl	%r15d, %r12d
   155d0:      	seta	%dil
   155d4:      	movzbl	%cl, %esi
   155d7:      	addq	%rax, %rbx
   155da:      	addq	%rbx, %rdi
   155dd:      	movl	$0x4, %eax
   155e2:      	callq	*%rax
   155e4:      	movq	%rbx, 0x48(%rsp)
   155e9:      	cmpl	%r15d, %r12d
   155ec:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   155f2:      	movq	0x8(%rsp), %r12
   155f7:      	movq	%r12, 0x30(%rsp)
   155fc:      	movq	0x38(%rsp), %rdx
   15601:      	movq	0x40(%rsp), %r15
   15606:      	jmp	0x15659 <generic_lsm_path+0xa929>
   15608:      	leaq	0x10(%r15), %rdx
   1560c:      	movl	$0x4, %eax
   15611:      	movq	%rbp, %rdi
   15614:      	movl	$0x8, %esi
   15619:      	callq	*%rax
   1561b:      	movq	0x40(%rsp), %rax
   15620:      	cmpq	(%rsp), %rax
   15624:      	je	0x1679d <generic_lsm_path+0xba6d>
   1562a:      	addq	$0x18, %r15
   1562e:      	movl	$0x4, %eax
   15633:      	leaq	0x30(%rsp), %rdi
   15638:      	movl	$0x8, %esi
   1563d:      	movq	%r15, %rdx
   15640:      	callq	*%rax
   15642:      	movq	(%rsp), %r15
   15646:      	movq	%r15, 0x40(%rsp)
   1564b:      	leaq	0x20(%r15), %rdx
   1564f:      	movq	%rdx, 0x38(%rsp)
   15654:      	movq	0x30(%rsp), %r12
   15659:      	cmpq	0x18(%rsp), %r12
   1565e:      	jne	0x1566b <generic_lsm_path+0xa93b>
   15660:      	cmpq	0x20(%rsp), %rdx
   15665:      	je	0x1679d <generic_lsm_path+0xba6d>
   1566b:      	movl	$0x4, %eax
   15670:      	leaq	0x10(%rsp), %rdi
   15675:      	movl	$0x8, %esi
   1567a:      	callq	*%rax
   1567c:      	cmpq	0x10(%rsp), %r12
   15681:      	je	0x15779 <generic_lsm_path+0xaa49>
   15687:      	leaq	0x18(%r12), %rbx
   1568c:      	movl	$0x4, %eax
   15691:      	movq	%rbp, %rdi
   15694:      	movl	$0x8, %esi
   15699:      	movq	%rbx, %rdx
   1569c:      	callq	*%rax
   1569e:      	cmpq	%r12, (%rsp)
   156a2:      	je	0x15779 <generic_lsm_path+0xaa49>
   156a8:      	movl	$0x4, %eax
   156ad:      	leaq	0x8(%rsp), %rdi
   156b2:      	movl	$0x8, %esi
   156b7:      	movq	%rbx, %rdx
   156ba:      	callq	*%rax
   156bc:      	addq	$0x20, %r12
   156c0:      	movl	$0x4, %eax
   156c5:      	leaq	0x58(%rsp), %rdi
   156ca:      	movl	$0x10, %ecx
   156cf:      	movl	$0x10, %esi
   156d4:      	movq	%r12, %rdx
   156d7:      	callq	*%rax
   156d9:      	movq	0x28(%rsp), %rbx
   156de:      	movq	0x48(%rsp), %rax
   156e3:      	movl	0x5c(%rsp), %r15d
   156e8:      	subq	%rbx, %rax
   156eb:      	movl	0x50(%rsp), %r12d
   156f0:      	movl	%r15d, %edx
   156f3:      	subl	%r12d, %edx
   156f6:      	movl	$0x0, %ecx
   156fb:      	cmovbl	%ecx, %edx
   156fe:      	addq	0x60(%rsp), %rdx
   15703:      	xorl	%esi, %esi
   15705:      	cmpl	%r15d, %r12d
   15708:      	seta	%sil
   1570c:      	movl	%r15d, %ecx
   1570f:      	cmovbl	%r12d, %ecx
   15713:      	addl	%ecx, %esi
   15715:      	movl	%r12d, %edi
   15718:      	subl	%esi, %edi
   1571a:      	movl	%edi, 0x50(%rsp)
   1571e:      	subq	%rsi, %rax
   15721:      	jb	0x167a2 <generic_lsm_path+0xba72>
   15727:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1572d:      	ja	0x167a2 <generic_lsm_path+0xba72>
   15733:      	cmpl	%r15d, %r12d
   15736:      	jbe	0x1573c <generic_lsm_path+0xaa0c>
   15738:      	movb	$0x2f, (%rbx,%rax)
   1573c:      	xorl	%edi, %edi
   1573e:      	cmpl	%r15d, %r12d
   15741:      	seta	%dil
   15745:      	movzbl	%cl, %esi
   15748:      	addq	%rax, %rbx
   1574b:      	addq	%rbx, %rdi
   1574e:      	movl	$0x4, %eax
   15753:      	callq	*%rax
   15755:      	movq	%rbx, 0x48(%rsp)
   1575a:      	cmpl	%r15d, %r12d
   1575d:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   15763:      	movq	0x8(%rsp), %r12
   15768:      	movq	%r12, 0x30(%rsp)
   1576d:      	movq	0x38(%rsp), %rdx
   15772:      	movq	0x40(%rsp), %r15
   15777:      	jmp	0x157ca <generic_lsm_path+0xaa9a>
   15779:      	leaq	0x10(%r15), %rdx
   1577d:      	movl	$0x4, %eax
   15782:      	movq	%rbp, %rdi
   15785:      	movl	$0x8, %esi
   1578a:      	callq	*%rax
   1578c:      	movq	0x40(%rsp), %rax
   15791:      	cmpq	(%rsp), %rax
   15795:      	je	0x1679d <generic_lsm_path+0xba6d>
   1579b:      	addq	$0x18, %r15
   1579f:      	movl	$0x4, %eax
   157a4:      	leaq	0x30(%rsp), %rdi
   157a9:      	movl	$0x8, %esi
   157ae:      	movq	%r15, %rdx
   157b1:      	callq	*%rax
   157b3:      	movq	(%rsp), %r15
   157b7:      	movq	%r15, 0x40(%rsp)
   157bc:      	leaq	0x20(%r15), %rdx
   157c0:      	movq	%rdx, 0x38(%rsp)
   157c5:      	movq	0x30(%rsp), %r12
   157ca:      	cmpq	0x18(%rsp), %r12
   157cf:      	jne	0x157dc <generic_lsm_path+0xaaac>
   157d1:      	cmpq	0x20(%rsp), %rdx
   157d6:      	je	0x1679d <generic_lsm_path+0xba6d>
   157dc:      	movl	$0x4, %eax
   157e1:      	leaq	0x10(%rsp), %rdi
   157e6:      	movl	$0x8, %esi
   157eb:      	callq	*%rax
   157ed:      	cmpq	0x10(%rsp), %r12
   157f2:      	je	0x158ea <generic_lsm_path+0xabba>
   157f8:      	leaq	0x18(%r12), %rbx
   157fd:      	movl	$0x4, %eax
   15802:      	movq	%rbp, %rdi
   15805:      	movl	$0x8, %esi
   1580a:      	movq	%rbx, %rdx
   1580d:      	callq	*%rax
   1580f:      	cmpq	%r12, (%rsp)
   15813:      	je	0x158ea <generic_lsm_path+0xabba>
   15819:      	movl	$0x4, %eax
   1581e:      	leaq	0x8(%rsp), %rdi
   15823:      	movl	$0x8, %esi
   15828:      	movq	%rbx, %rdx
   1582b:      	callq	*%rax
   1582d:      	addq	$0x20, %r12
   15831:      	movl	$0x4, %eax
   15836:      	leaq	0x58(%rsp), %rdi
   1583b:      	movl	$0x10, %ecx
   15840:      	movl	$0x10, %esi
   15845:      	movq	%r12, %rdx
   15848:      	callq	*%rax
   1584a:      	movq	0x28(%rsp), %rbx
   1584f:      	movq	0x48(%rsp), %rax
   15854:      	movl	0x5c(%rsp), %r15d
   15859:      	subq	%rbx, %rax
   1585c:      	movl	0x50(%rsp), %r12d
   15861:      	movl	%r15d, %edx
   15864:      	subl	%r12d, %edx
   15867:      	movl	$0x0, %ecx
   1586c:      	cmovbl	%ecx, %edx
   1586f:      	addq	0x60(%rsp), %rdx
   15874:      	xorl	%esi, %esi
   15876:      	cmpl	%r15d, %r12d
   15879:      	seta	%sil
   1587d:      	movl	%r15d, %ecx
   15880:      	cmovbl	%r12d, %ecx
   15884:      	addl	%ecx, %esi
   15886:      	movl	%r12d, %edi
   15889:      	subl	%esi, %edi
   1588b:      	movl	%edi, 0x50(%rsp)
   1588f:      	subq	%rsi, %rax
   15892:      	jb	0x167a2 <generic_lsm_path+0xba72>
   15898:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1589e:      	ja	0x167a2 <generic_lsm_path+0xba72>
   158a4:      	cmpl	%r15d, %r12d
   158a7:      	jbe	0x158ad <generic_lsm_path+0xab7d>
   158a9:      	movb	$0x2f, (%rbx,%rax)
   158ad:      	xorl	%edi, %edi
   158af:      	cmpl	%r15d, %r12d
   158b2:      	seta	%dil
   158b6:      	movzbl	%cl, %esi
   158b9:      	addq	%rax, %rbx
   158bc:      	addq	%rbx, %rdi
   158bf:      	movl	$0x4, %eax
   158c4:      	callq	*%rax
   158c6:      	movq	%rbx, 0x48(%rsp)
   158cb:      	cmpl	%r15d, %r12d
   158ce:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   158d4:      	movq	0x8(%rsp), %r12
   158d9:      	movq	%r12, 0x30(%rsp)
   158de:      	movq	0x38(%rsp), %rdx
   158e3:      	movq	0x40(%rsp), %r15
   158e8:      	jmp	0x1593b <generic_lsm_path+0xac0b>
   158ea:      	leaq	0x10(%r15), %rdx
   158ee:      	movl	$0x4, %eax
   158f3:      	movq	%rbp, %rdi
   158f6:      	movl	$0x8, %esi
   158fb:      	callq	*%rax
   158fd:      	movq	0x40(%rsp), %rax
   15902:      	cmpq	(%rsp), %rax
   15906:      	je	0x1679d <generic_lsm_path+0xba6d>
   1590c:      	addq	$0x18, %r15
   15910:      	movl	$0x4, %eax
   15915:      	leaq	0x30(%rsp), %rdi
   1591a:      	movl	$0x8, %esi
   1591f:      	movq	%r15, %rdx
   15922:      	callq	*%rax
   15924:      	movq	(%rsp), %r15
   15928:      	movq	%r15, 0x40(%rsp)
   1592d:      	leaq	0x20(%r15), %rdx
   15931:      	movq	%rdx, 0x38(%rsp)
   15936:      	movq	0x30(%rsp), %r12
   1593b:      	cmpq	0x18(%rsp), %r12
   15940:      	jne	0x1594d <generic_lsm_path+0xac1d>
   15942:      	cmpq	0x20(%rsp), %rdx
   15947:      	je	0x1679d <generic_lsm_path+0xba6d>
   1594d:      	movl	$0x4, %eax
   15952:      	leaq	0x10(%rsp), %rdi
   15957:      	movl	$0x8, %esi
   1595c:      	callq	*%rax
   1595e:      	cmpq	0x10(%rsp), %r12
   15963:      	je	0x15a5b <generic_lsm_path+0xad2b>
   15969:      	leaq	0x18(%r12), %rbx
   1596e:      	movl	$0x4, %eax
   15973:      	movq	%rbp, %rdi
   15976:      	movl	$0x8, %esi
   1597b:      	movq	%rbx, %rdx
   1597e:      	callq	*%rax
   15980:      	cmpq	%r12, (%rsp)
   15984:      	je	0x15a5b <generic_lsm_path+0xad2b>
   1598a:      	movl	$0x4, %eax
   1598f:      	leaq	0x8(%rsp), %rdi
   15994:      	movl	$0x8, %esi
   15999:      	movq	%rbx, %rdx
   1599c:      	callq	*%rax
   1599e:      	addq	$0x20, %r12
   159a2:      	movl	$0x4, %eax
   159a7:      	leaq	0x58(%rsp), %rdi
   159ac:      	movl	$0x10, %ecx
   159b1:      	movl	$0x10, %esi
   159b6:      	movq	%r12, %rdx
   159b9:      	callq	*%rax
   159bb:      	movq	0x28(%rsp), %rbx
   159c0:      	movq	0x48(%rsp), %rax
   159c5:      	movl	0x5c(%rsp), %r15d
   159ca:      	subq	%rbx, %rax
   159cd:      	movl	0x50(%rsp), %r12d
   159d2:      	movl	%r15d, %edx
   159d5:      	subl	%r12d, %edx
   159d8:      	movl	$0x0, %ecx
   159dd:      	cmovbl	%ecx, %edx
   159e0:      	addq	0x60(%rsp), %rdx
   159e5:      	xorl	%esi, %esi
   159e7:      	cmpl	%r15d, %r12d
   159ea:      	seta	%sil
   159ee:      	movl	%r15d, %ecx
   159f1:      	cmovbl	%r12d, %ecx
   159f5:      	addl	%ecx, %esi
   159f7:      	movl	%r12d, %edi
   159fa:      	subl	%esi, %edi
   159fc:      	movl	%edi, 0x50(%rsp)
   15a00:      	subq	%rsi, %rax
   15a03:      	jb	0x167a2 <generic_lsm_path+0xba72>
   15a09:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15a0f:      	ja	0x167a2 <generic_lsm_path+0xba72>
   15a15:      	cmpl	%r15d, %r12d
   15a18:      	jbe	0x15a1e <generic_lsm_path+0xacee>
   15a1a:      	movb	$0x2f, (%rbx,%rax)
   15a1e:      	xorl	%edi, %edi
   15a20:      	cmpl	%r15d, %r12d
   15a23:      	seta	%dil
   15a27:      	movzbl	%cl, %esi
   15a2a:      	addq	%rax, %rbx
   15a2d:      	addq	%rbx, %rdi
   15a30:      	movl	$0x4, %eax
   15a35:      	callq	*%rax
   15a37:      	movq	%rbx, 0x48(%rsp)
   15a3c:      	cmpl	%r15d, %r12d
   15a3f:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   15a45:      	movq	0x8(%rsp), %r12
   15a4a:      	movq	%r12, 0x30(%rsp)
   15a4f:      	movq	0x38(%rsp), %rdx
   15a54:      	movq	0x40(%rsp), %r15
   15a59:      	jmp	0x15aac <generic_lsm_path+0xad7c>
   15a5b:      	leaq	0x10(%r15), %rdx
   15a5f:      	movl	$0x4, %eax
   15a64:      	movq	%rbp, %rdi
   15a67:      	movl	$0x8, %esi
   15a6c:      	callq	*%rax
   15a6e:      	movq	0x40(%rsp), %rax
   15a73:      	cmpq	(%rsp), %rax
   15a77:      	je	0x1679d <generic_lsm_path+0xba6d>
   15a7d:      	addq	$0x18, %r15
   15a81:      	movl	$0x4, %eax
   15a86:      	leaq	0x30(%rsp), %rdi
   15a8b:      	movl	$0x8, %esi
   15a90:      	movq	%r15, %rdx
   15a93:      	callq	*%rax
   15a95:      	movq	(%rsp), %r15
   15a99:      	movq	%r15, 0x40(%rsp)
   15a9e:      	leaq	0x20(%r15), %rdx
   15aa2:      	movq	%rdx, 0x38(%rsp)
   15aa7:      	movq	0x30(%rsp), %r12
   15aac:      	cmpq	0x18(%rsp), %r12
   15ab1:      	jne	0x15abe <generic_lsm_path+0xad8e>
   15ab3:      	cmpq	0x20(%rsp), %rdx
   15ab8:      	je	0x1679d <generic_lsm_path+0xba6d>
   15abe:      	movl	$0x4, %eax
   15ac3:      	leaq	0x10(%rsp), %rdi
   15ac8:      	movl	$0x8, %esi
   15acd:      	callq	*%rax
   15acf:      	cmpq	0x10(%rsp), %r12
   15ad4:      	je	0x15bcc <generic_lsm_path+0xae9c>
   15ada:      	leaq	0x18(%r12), %rbx
   15adf:      	movl	$0x4, %eax
   15ae4:      	movq	%rbp, %rdi
   15ae7:      	movl	$0x8, %esi
   15aec:      	movq	%rbx, %rdx
   15aef:      	callq	*%rax
   15af1:      	cmpq	%r12, (%rsp)
   15af5:      	je	0x15bcc <generic_lsm_path+0xae9c>
   15afb:      	movl	$0x4, %eax
   15b00:      	leaq	0x8(%rsp), %rdi
   15b05:      	movl	$0x8, %esi
   15b0a:      	movq	%rbx, %rdx
   15b0d:      	callq	*%rax
   15b0f:      	addq	$0x20, %r12
   15b13:      	movl	$0x4, %eax
   15b18:      	leaq	0x58(%rsp), %rdi
   15b1d:      	movl	$0x10, %ecx
   15b22:      	movl	$0x10, %esi
   15b27:      	movq	%r12, %rdx
   15b2a:      	callq	*%rax
   15b2c:      	movq	0x28(%rsp), %rbx
   15b31:      	movq	0x48(%rsp), %rax
   15b36:      	movl	0x5c(%rsp), %r15d
   15b3b:      	subq	%rbx, %rax
   15b3e:      	movl	0x50(%rsp), %r12d
   15b43:      	movl	%r15d, %edx
   15b46:      	subl	%r12d, %edx
   15b49:      	movl	$0x0, %ecx
   15b4e:      	cmovbl	%ecx, %edx
   15b51:      	addq	0x60(%rsp), %rdx
   15b56:      	xorl	%esi, %esi
   15b58:      	cmpl	%r15d, %r12d
   15b5b:      	seta	%sil
   15b5f:      	movl	%r15d, %ecx
   15b62:      	cmovbl	%r12d, %ecx
   15b66:      	addl	%ecx, %esi
   15b68:      	movl	%r12d, %edi
   15b6b:      	subl	%esi, %edi
   15b6d:      	movl	%edi, 0x50(%rsp)
   15b71:      	subq	%rsi, %rax
   15b74:      	jb	0x167a2 <generic_lsm_path+0xba72>
   15b7a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15b80:      	ja	0x167a2 <generic_lsm_path+0xba72>
   15b86:      	cmpl	%r15d, %r12d
   15b89:      	jbe	0x15b8f <generic_lsm_path+0xae5f>
   15b8b:      	movb	$0x2f, (%rbx,%rax)
   15b8f:      	xorl	%edi, %edi
   15b91:      	cmpl	%r15d, %r12d
   15b94:      	seta	%dil
   15b98:      	movzbl	%cl, %esi
   15b9b:      	addq	%rax, %rbx
   15b9e:      	addq	%rbx, %rdi
   15ba1:      	movl	$0x4, %eax
   15ba6:      	callq	*%rax
   15ba8:      	movq	%rbx, 0x48(%rsp)
   15bad:      	cmpl	%r15d, %r12d
   15bb0:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   15bb6:      	movq	0x8(%rsp), %r12
   15bbb:      	movq	%r12, 0x30(%rsp)
   15bc0:      	movq	0x38(%rsp), %rdx
   15bc5:      	movq	0x40(%rsp), %r15
   15bca:      	jmp	0x15c1d <generic_lsm_path+0xaeed>
   15bcc:      	leaq	0x10(%r15), %rdx
   15bd0:      	movl	$0x4, %eax
   15bd5:      	movq	%rbp, %rdi
   15bd8:      	movl	$0x8, %esi
   15bdd:      	callq	*%rax
   15bdf:      	movq	0x40(%rsp), %rax
   15be4:      	cmpq	(%rsp), %rax
   15be8:      	je	0x1679d <generic_lsm_path+0xba6d>
   15bee:      	addq	$0x18, %r15
   15bf2:      	movl	$0x4, %eax
   15bf7:      	leaq	0x30(%rsp), %rdi
   15bfc:      	movl	$0x8, %esi
   15c01:      	movq	%r15, %rdx
   15c04:      	callq	*%rax
   15c06:      	movq	(%rsp), %r15
   15c0a:      	movq	%r15, 0x40(%rsp)
   15c0f:      	leaq	0x20(%r15), %rdx
   15c13:      	movq	%rdx, 0x38(%rsp)
   15c18:      	movq	0x30(%rsp), %r12
   15c1d:      	cmpq	0x18(%rsp), %r12
   15c22:      	jne	0x15c2f <generic_lsm_path+0xaeff>
   15c24:      	cmpq	0x20(%rsp), %rdx
   15c29:      	je	0x1679d <generic_lsm_path+0xba6d>
   15c2f:      	movl	$0x4, %eax
   15c34:      	leaq	0x10(%rsp), %rdi
   15c39:      	movl	$0x8, %esi
   15c3e:      	callq	*%rax
   15c40:      	cmpq	0x10(%rsp), %r12
   15c45:      	je	0x15d3d <generic_lsm_path+0xb00d>
   15c4b:      	leaq	0x18(%r12), %rbx
   15c50:      	movl	$0x4, %eax
   15c55:      	movq	%rbp, %rdi
   15c58:      	movl	$0x8, %esi
   15c5d:      	movq	%rbx, %rdx
   15c60:      	callq	*%rax
   15c62:      	cmpq	%r12, (%rsp)
   15c66:      	je	0x15d3d <generic_lsm_path+0xb00d>
   15c6c:      	movl	$0x4, %eax
   15c71:      	leaq	0x8(%rsp), %rdi
   15c76:      	movl	$0x8, %esi
   15c7b:      	movq	%rbx, %rdx
   15c7e:      	callq	*%rax
   15c80:      	addq	$0x20, %r12
   15c84:      	movl	$0x4, %eax
   15c89:      	leaq	0x58(%rsp), %rdi
   15c8e:      	movl	$0x10, %ecx
   15c93:      	movl	$0x10, %esi
   15c98:      	movq	%r12, %rdx
   15c9b:      	callq	*%rax
   15c9d:      	movq	0x28(%rsp), %rbx
   15ca2:      	movq	0x48(%rsp), %rax
   15ca7:      	movl	0x5c(%rsp), %r15d
   15cac:      	subq	%rbx, %rax
   15caf:      	movl	0x50(%rsp), %r12d
   15cb4:      	movl	%r15d, %edx
   15cb7:      	subl	%r12d, %edx
   15cba:      	movl	$0x0, %ecx
   15cbf:      	cmovbl	%ecx, %edx
   15cc2:      	addq	0x60(%rsp), %rdx
   15cc7:      	xorl	%esi, %esi
   15cc9:      	cmpl	%r15d, %r12d
   15ccc:      	seta	%sil
   15cd0:      	movl	%r15d, %ecx
   15cd3:      	cmovbl	%r12d, %ecx
   15cd7:      	addl	%ecx, %esi
   15cd9:      	movl	%r12d, %edi
   15cdc:      	subl	%esi, %edi
   15cde:      	movl	%edi, 0x50(%rsp)
   15ce2:      	subq	%rsi, %rax
   15ce5:      	jb	0x167a2 <generic_lsm_path+0xba72>
   15ceb:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15cf1:      	ja	0x167a2 <generic_lsm_path+0xba72>
   15cf7:      	cmpl	%r15d, %r12d
   15cfa:      	jbe	0x15d00 <generic_lsm_path+0xafd0>
   15cfc:      	movb	$0x2f, (%rbx,%rax)
   15d00:      	xorl	%edi, %edi
   15d02:      	cmpl	%r15d, %r12d
   15d05:      	seta	%dil
   15d09:      	movzbl	%cl, %esi
   15d0c:      	addq	%rax, %rbx
   15d0f:      	addq	%rbx, %rdi
   15d12:      	movl	$0x4, %eax
   15d17:      	callq	*%rax
   15d19:      	movq	%rbx, 0x48(%rsp)
   15d1e:      	cmpl	%r15d, %r12d
   15d21:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   15d27:      	movq	0x8(%rsp), %r12
   15d2c:      	movq	%r12, 0x30(%rsp)
   15d31:      	movq	0x38(%rsp), %rdx
   15d36:      	movq	0x40(%rsp), %r15
   15d3b:      	jmp	0x15d8e <generic_lsm_path+0xb05e>
   15d3d:      	leaq	0x10(%r15), %rdx
   15d41:      	movl	$0x4, %eax
   15d46:      	movq	%rbp, %rdi
   15d49:      	movl	$0x8, %esi
   15d4e:      	callq	*%rax
   15d50:      	movq	0x40(%rsp), %rax
   15d55:      	cmpq	(%rsp), %rax
   15d59:      	je	0x1679d <generic_lsm_path+0xba6d>
   15d5f:      	addq	$0x18, %r15
   15d63:      	movl	$0x4, %eax
   15d68:      	leaq	0x30(%rsp), %rdi
   15d6d:      	movl	$0x8, %esi
   15d72:      	movq	%r15, %rdx
   15d75:      	callq	*%rax
   15d77:      	movq	(%rsp), %r15
   15d7b:      	movq	%r15, 0x40(%rsp)
   15d80:      	leaq	0x20(%r15), %rdx
   15d84:      	movq	%rdx, 0x38(%rsp)
   15d89:      	movq	0x30(%rsp), %r12
   15d8e:      	cmpq	0x18(%rsp), %r12
   15d93:      	jne	0x15da0 <generic_lsm_path+0xb070>
   15d95:      	cmpq	0x20(%rsp), %rdx
   15d9a:      	je	0x1679d <generic_lsm_path+0xba6d>
   15da0:      	movl	$0x4, %eax
   15da5:      	leaq	0x10(%rsp), %rdi
   15daa:      	movl	$0x8, %esi
   15daf:      	callq	*%rax
   15db1:      	cmpq	0x10(%rsp), %r12
   15db6:      	je	0x15eae <generic_lsm_path+0xb17e>
   15dbc:      	leaq	0x18(%r12), %rbx
   15dc1:      	movl	$0x4, %eax
   15dc6:      	movq	%rbp, %rdi
   15dc9:      	movl	$0x8, %esi
   15dce:      	movq	%rbx, %rdx
   15dd1:      	callq	*%rax
   15dd3:      	cmpq	%r12, (%rsp)
   15dd7:      	je	0x15eae <generic_lsm_path+0xb17e>
   15ddd:      	movl	$0x4, %eax
   15de2:      	leaq	0x8(%rsp), %rdi
   15de7:      	movl	$0x8, %esi
   15dec:      	movq	%rbx, %rdx
   15def:      	callq	*%rax
   15df1:      	addq	$0x20, %r12
   15df5:      	movl	$0x4, %eax
   15dfa:      	leaq	0x58(%rsp), %rdi
   15dff:      	movl	$0x10, %ecx
   15e04:      	movl	$0x10, %esi
   15e09:      	movq	%r12, %rdx
   15e0c:      	callq	*%rax
   15e0e:      	movq	0x28(%rsp), %rbx
   15e13:      	movq	0x48(%rsp), %rax
   15e18:      	movl	0x5c(%rsp), %r15d
   15e1d:      	subq	%rbx, %rax
   15e20:      	movl	0x50(%rsp), %r12d
   15e25:      	movl	%r15d, %edx
   15e28:      	subl	%r12d, %edx
   15e2b:      	movl	$0x0, %ecx
   15e30:      	cmovbl	%ecx, %edx
   15e33:      	addq	0x60(%rsp), %rdx
   15e38:      	xorl	%esi, %esi
   15e3a:      	cmpl	%r15d, %r12d
   15e3d:      	seta	%sil
   15e41:      	movl	%r15d, %ecx
   15e44:      	cmovbl	%r12d, %ecx
   15e48:      	addl	%ecx, %esi
   15e4a:      	movl	%r12d, %edi
   15e4d:      	subl	%esi, %edi
   15e4f:      	movl	%edi, 0x50(%rsp)
   15e53:      	subq	%rsi, %rax
   15e56:      	jb	0x167a2 <generic_lsm_path+0xba72>
   15e5c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15e62:      	ja	0x167a2 <generic_lsm_path+0xba72>
   15e68:      	cmpl	%r15d, %r12d
   15e6b:      	jbe	0x15e71 <generic_lsm_path+0xb141>
   15e6d:      	movb	$0x2f, (%rbx,%rax)
   15e71:      	xorl	%edi, %edi
   15e73:      	cmpl	%r15d, %r12d
   15e76:      	seta	%dil
   15e7a:      	movzbl	%cl, %esi
   15e7d:      	addq	%rax, %rbx
   15e80:      	addq	%rbx, %rdi
   15e83:      	movl	$0x4, %eax
   15e88:      	callq	*%rax
   15e8a:      	movq	%rbx, 0x48(%rsp)
   15e8f:      	cmpl	%r15d, %r12d
   15e92:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   15e98:      	movq	0x8(%rsp), %r12
   15e9d:      	movq	%r12, 0x30(%rsp)
   15ea2:      	movq	0x38(%rsp), %rdx
   15ea7:      	movq	0x40(%rsp), %r15
   15eac:      	jmp	0x15eff <generic_lsm_path+0xb1cf>
   15eae:      	leaq	0x10(%r15), %rdx
   15eb2:      	movl	$0x4, %eax
   15eb7:      	movq	%rbp, %rdi
   15eba:      	movl	$0x8, %esi
   15ebf:      	callq	*%rax
   15ec1:      	movq	0x40(%rsp), %rax
   15ec6:      	cmpq	(%rsp), %rax
   15eca:      	je	0x1679d <generic_lsm_path+0xba6d>
   15ed0:      	addq	$0x18, %r15
   15ed4:      	movl	$0x4, %eax
   15ed9:      	leaq	0x30(%rsp), %rdi
   15ede:      	movl	$0x8, %esi
   15ee3:      	movq	%r15, %rdx
   15ee6:      	callq	*%rax
   15ee8:      	movq	(%rsp), %r15
   15eec:      	movq	%r15, 0x40(%rsp)
   15ef1:      	leaq	0x20(%r15), %rdx
   15ef5:      	movq	%rdx, 0x38(%rsp)
   15efa:      	movq	0x30(%rsp), %r12
   15eff:      	cmpq	0x18(%rsp), %r12
   15f04:      	jne	0x15f11 <generic_lsm_path+0xb1e1>
   15f06:      	cmpq	0x20(%rsp), %rdx
   15f0b:      	je	0x1679d <generic_lsm_path+0xba6d>
   15f11:      	movl	$0x4, %eax
   15f16:      	leaq	0x10(%rsp), %rdi
   15f1b:      	movl	$0x8, %esi
   15f20:      	callq	*%rax
   15f22:      	cmpq	0x10(%rsp), %r12
   15f27:      	je	0x1601f <generic_lsm_path+0xb2ef>
   15f2d:      	leaq	0x18(%r12), %rbx
   15f32:      	movl	$0x4, %eax
   15f37:      	movq	%rbp, %rdi
   15f3a:      	movl	$0x8, %esi
   15f3f:      	movq	%rbx, %rdx
   15f42:      	callq	*%rax
   15f44:      	cmpq	%r12, (%rsp)
   15f48:      	je	0x1601f <generic_lsm_path+0xb2ef>
   15f4e:      	movl	$0x4, %eax
   15f53:      	leaq	0x8(%rsp), %rdi
   15f58:      	movl	$0x8, %esi
   15f5d:      	movq	%rbx, %rdx
   15f60:      	callq	*%rax
   15f62:      	addq	$0x20, %r12
   15f66:      	movl	$0x4, %eax
   15f6b:      	leaq	0x58(%rsp), %rdi
   15f70:      	movl	$0x10, %ecx
   15f75:      	movl	$0x10, %esi
   15f7a:      	movq	%r12, %rdx
   15f7d:      	callq	*%rax
   15f7f:      	movq	0x28(%rsp), %rbx
   15f84:      	movq	0x48(%rsp), %rax
   15f89:      	movl	0x5c(%rsp), %r15d
   15f8e:      	subq	%rbx, %rax
   15f91:      	movl	0x50(%rsp), %r12d
   15f96:      	movl	%r15d, %edx
   15f99:      	subl	%r12d, %edx
   15f9c:      	movl	$0x0, %ecx
   15fa1:      	cmovbl	%ecx, %edx
   15fa4:      	addq	0x60(%rsp), %rdx
   15fa9:      	xorl	%esi, %esi
   15fab:      	cmpl	%r15d, %r12d
   15fae:      	seta	%sil
   15fb2:      	movl	%r15d, %ecx
   15fb5:      	cmovbl	%r12d, %ecx
   15fb9:      	addl	%ecx, %esi
   15fbb:      	movl	%r12d, %edi
   15fbe:      	subl	%esi, %edi
   15fc0:      	movl	%edi, 0x50(%rsp)
   15fc4:      	subq	%rsi, %rax
   15fc7:      	jb	0x167a2 <generic_lsm_path+0xba72>
   15fcd:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15fd3:      	ja	0x167a2 <generic_lsm_path+0xba72>
   15fd9:      	cmpl	%r15d, %r12d
   15fdc:      	jbe	0x15fe2 <generic_lsm_path+0xb2b2>
   15fde:      	movb	$0x2f, (%rbx,%rax)
   15fe2:      	xorl	%edi, %edi
   15fe4:      	cmpl	%r15d, %r12d
   15fe7:      	seta	%dil
   15feb:      	movzbl	%cl, %esi
   15fee:      	addq	%rax, %rbx
   15ff1:      	addq	%rbx, %rdi
   15ff4:      	movl	$0x4, %eax
   15ff9:      	callq	*%rax
   15ffb:      	movq	%rbx, 0x48(%rsp)
   16000:      	cmpl	%r15d, %r12d
   16003:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   16009:      	movq	0x8(%rsp), %r12
   1600e:      	movq	%r12, 0x30(%rsp)
   16013:      	movq	0x38(%rsp), %rdx
   16018:      	movq	0x40(%rsp), %r15
   1601d:      	jmp	0x16070 <generic_lsm_path+0xb340>
   1601f:      	leaq	0x10(%r15), %rdx
   16023:      	movl	$0x4, %eax
   16028:      	movq	%rbp, %rdi
   1602b:      	movl	$0x8, %esi
   16030:      	callq	*%rax
   16032:      	movq	0x40(%rsp), %rax
   16037:      	cmpq	(%rsp), %rax
   1603b:      	je	0x1679d <generic_lsm_path+0xba6d>
   16041:      	addq	$0x18, %r15
   16045:      	movl	$0x4, %eax
   1604a:      	leaq	0x30(%rsp), %rdi
   1604f:      	movl	$0x8, %esi
   16054:      	movq	%r15, %rdx
   16057:      	callq	*%rax
   16059:      	movq	(%rsp), %r15
   1605d:      	movq	%r15, 0x40(%rsp)
   16062:      	leaq	0x20(%r15), %rdx
   16066:      	movq	%rdx, 0x38(%rsp)
   1606b:      	movq	0x30(%rsp), %r12
   16070:      	cmpq	0x18(%rsp), %r12
   16075:      	jne	0x16082 <generic_lsm_path+0xb352>
   16077:      	cmpq	0x20(%rsp), %rdx
   1607c:      	je	0x1679d <generic_lsm_path+0xba6d>
   16082:      	movl	$0x4, %eax
   16087:      	leaq	0x10(%rsp), %rdi
   1608c:      	movl	$0x8, %esi
   16091:      	callq	*%rax
   16093:      	cmpq	0x10(%rsp), %r12
   16098:      	je	0x16190 <generic_lsm_path+0xb460>
   1609e:      	leaq	0x18(%r12), %rbx
   160a3:      	movl	$0x4, %eax
   160a8:      	movq	%rbp, %rdi
   160ab:      	movl	$0x8, %esi
   160b0:      	movq	%rbx, %rdx
   160b3:      	callq	*%rax
   160b5:      	cmpq	%r12, (%rsp)
   160b9:      	je	0x16190 <generic_lsm_path+0xb460>
   160bf:      	movl	$0x4, %eax
   160c4:      	leaq	0x8(%rsp), %rdi
   160c9:      	movl	$0x8, %esi
   160ce:      	movq	%rbx, %rdx
   160d1:      	callq	*%rax
   160d3:      	addq	$0x20, %r12
   160d7:      	movl	$0x4, %eax
   160dc:      	leaq	0x58(%rsp), %rdi
   160e1:      	movl	$0x10, %ecx
   160e6:      	movl	$0x10, %esi
   160eb:      	movq	%r12, %rdx
   160ee:      	callq	*%rax
   160f0:      	movq	0x28(%rsp), %rbx
   160f5:      	movq	0x48(%rsp), %rax
   160fa:      	movl	0x5c(%rsp), %r15d
   160ff:      	subq	%rbx, %rax
   16102:      	movl	0x50(%rsp), %r12d
   16107:      	movl	%r15d, %edx
   1610a:      	subl	%r12d, %edx
   1610d:      	movl	$0x0, %ecx
   16112:      	cmovbl	%ecx, %edx
   16115:      	addq	0x60(%rsp), %rdx
   1611a:      	xorl	%esi, %esi
   1611c:      	cmpl	%r15d, %r12d
   1611f:      	seta	%sil
   16123:      	movl	%r15d, %ecx
   16126:      	cmovbl	%r12d, %ecx
   1612a:      	addl	%ecx, %esi
   1612c:      	movl	%r12d, %edi
   1612f:      	subl	%esi, %edi
   16131:      	movl	%edi, 0x50(%rsp)
   16135:      	subq	%rsi, %rax
   16138:      	jb	0x167a2 <generic_lsm_path+0xba72>
   1613e:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   16144:      	ja	0x167a2 <generic_lsm_path+0xba72>
   1614a:      	cmpl	%r15d, %r12d
   1614d:      	jbe	0x16153 <generic_lsm_path+0xb423>
   1614f:      	movb	$0x2f, (%rbx,%rax)
   16153:      	xorl	%edi, %edi
   16155:      	cmpl	%r15d, %r12d
   16158:      	seta	%dil
   1615c:      	movzbl	%cl, %esi
   1615f:      	addq	%rax, %rbx
   16162:      	addq	%rbx, %rdi
   16165:      	movl	$0x4, %eax
   1616a:      	callq	*%rax
   1616c:      	movq	%rbx, 0x48(%rsp)
   16171:      	cmpl	%r15d, %r12d
   16174:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   1617a:      	movq	0x8(%rsp), %r12
   1617f:      	movq	%r12, 0x30(%rsp)
   16184:      	movq	0x38(%rsp), %rdx
   16189:      	movq	0x40(%rsp), %r15
   1618e:      	jmp	0x161e1 <generic_lsm_path+0xb4b1>
   16190:      	leaq	0x10(%r15), %rdx
   16194:      	movl	$0x4, %eax
   16199:      	movq	%rbp, %rdi
   1619c:      	movl	$0x8, %esi
   161a1:      	callq	*%rax
   161a3:      	movq	0x40(%rsp), %rax
   161a8:      	cmpq	(%rsp), %rax
   161ac:      	je	0x1679d <generic_lsm_path+0xba6d>
   161b2:      	addq	$0x18, %r15
   161b6:      	movl	$0x4, %eax
   161bb:      	leaq	0x30(%rsp), %rdi
   161c0:      	movl	$0x8, %esi
   161c5:      	movq	%r15, %rdx
   161c8:      	callq	*%rax
   161ca:      	movq	(%rsp), %r15
   161ce:      	movq	%r15, 0x40(%rsp)
   161d3:      	leaq	0x20(%r15), %rdx
   161d7:      	movq	%rdx, 0x38(%rsp)
   161dc:      	movq	0x30(%rsp), %r12
   161e1:      	cmpq	0x18(%rsp), %r12
   161e6:      	jne	0x161f3 <generic_lsm_path+0xb4c3>
   161e8:      	cmpq	0x20(%rsp), %rdx
   161ed:      	je	0x1679d <generic_lsm_path+0xba6d>
   161f3:      	movl	$0x4, %eax
   161f8:      	leaq	0x10(%rsp), %rdi
   161fd:      	movl	$0x8, %esi
   16202:      	callq	*%rax
   16204:      	cmpq	0x10(%rsp), %r12
   16209:      	je	0x16301 <generic_lsm_path+0xb5d1>
   1620f:      	leaq	0x18(%r12), %rbx
   16214:      	movl	$0x4, %eax
   16219:      	movq	%rbp, %rdi
   1621c:      	movl	$0x8, %esi
   16221:      	movq	%rbx, %rdx
   16224:      	callq	*%rax
   16226:      	cmpq	%r12, (%rsp)
   1622a:      	je	0x16301 <generic_lsm_path+0xb5d1>
   16230:      	movl	$0x4, %eax
   16235:      	leaq	0x8(%rsp), %rdi
   1623a:      	movl	$0x8, %esi
   1623f:      	movq	%rbx, %rdx
   16242:      	callq	*%rax
   16244:      	addq	$0x20, %r12
   16248:      	movl	$0x4, %eax
   1624d:      	leaq	0x58(%rsp), %rdi
   16252:      	movl	$0x10, %ecx
   16257:      	movl	$0x10, %esi
   1625c:      	movq	%r12, %rdx
   1625f:      	callq	*%rax
   16261:      	movq	0x28(%rsp), %rbx
   16266:      	movq	0x48(%rsp), %rax
   1626b:      	movl	0x5c(%rsp), %r15d
   16270:      	subq	%rbx, %rax
   16273:      	movl	0x50(%rsp), %r12d
   16278:      	movl	%r15d, %edx
   1627b:      	subl	%r12d, %edx
   1627e:      	movl	$0x0, %ecx
   16283:      	cmovbl	%ecx, %edx
   16286:      	addq	0x60(%rsp), %rdx
   1628b:      	xorl	%esi, %esi
   1628d:      	cmpl	%r15d, %r12d
   16290:      	seta	%sil
   16294:      	movl	%r15d, %ecx
   16297:      	cmovbl	%r12d, %ecx
   1629b:      	addl	%ecx, %esi
   1629d:      	movl	%r12d, %edi
   162a0:      	subl	%esi, %edi
   162a2:      	movl	%edi, 0x50(%rsp)
   162a6:      	subq	%rsi, %rax
   162a9:      	jb	0x167a2 <generic_lsm_path+0xba72>
   162af:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   162b5:      	ja	0x167a2 <generic_lsm_path+0xba72>
   162bb:      	cmpl	%r15d, %r12d
   162be:      	jbe	0x162c4 <generic_lsm_path+0xb594>
   162c0:      	movb	$0x2f, (%rbx,%rax)
   162c4:      	xorl	%edi, %edi
   162c6:      	cmpl	%r15d, %r12d
   162c9:      	seta	%dil
   162cd:      	movzbl	%cl, %esi
   162d0:      	addq	%rax, %rbx
   162d3:      	addq	%rbx, %rdi
   162d6:      	movl	$0x4, %eax
   162db:      	callq	*%rax
   162dd:      	movq	%rbx, 0x48(%rsp)
   162e2:      	cmpl	%r15d, %r12d
   162e5:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   162eb:      	movq	0x8(%rsp), %r12
   162f0:      	movq	%r12, 0x30(%rsp)
   162f5:      	movq	0x38(%rsp), %rdx
   162fa:      	movq	0x40(%rsp), %r15
   162ff:      	jmp	0x16352 <generic_lsm_path+0xb622>
   16301:      	leaq	0x10(%r15), %rdx
   16305:      	movl	$0x4, %eax
   1630a:      	movq	%rbp, %rdi
   1630d:      	movl	$0x8, %esi
   16312:      	callq	*%rax
   16314:      	movq	0x40(%rsp), %rax
   16319:      	cmpq	(%rsp), %rax
   1631d:      	je	0x1679d <generic_lsm_path+0xba6d>
   16323:      	addq	$0x18, %r15
   16327:      	movl	$0x4, %eax
   1632c:      	leaq	0x30(%rsp), %rdi
   16331:      	movl	$0x8, %esi
   16336:      	movq	%r15, %rdx
   16339:      	callq	*%rax
   1633b:      	movq	(%rsp), %r15
   1633f:      	movq	%r15, 0x40(%rsp)
   16344:      	leaq	0x20(%r15), %rdx
   16348:      	movq	%rdx, 0x38(%rsp)
   1634d:      	movq	0x30(%rsp), %r12
   16352:      	cmpq	0x18(%rsp), %r12
   16357:      	jne	0x16364 <generic_lsm_path+0xb634>
   16359:      	cmpq	0x20(%rsp), %rdx
   1635e:      	je	0x1679d <generic_lsm_path+0xba6d>
   16364:      	movl	$0x4, %eax
   16369:      	leaq	0x10(%rsp), %rdi
   1636e:      	movl	$0x8, %esi
   16373:      	callq	*%rax
   16375:      	cmpq	0x10(%rsp), %r12
   1637a:      	je	0x16472 <generic_lsm_path+0xb742>
   16380:      	leaq	0x18(%r12), %rbx
   16385:      	movl	$0x4, %eax
   1638a:      	movq	%rbp, %rdi
   1638d:      	movl	$0x8, %esi
   16392:      	movq	%rbx, %rdx
   16395:      	callq	*%rax
   16397:      	cmpq	%r12, (%rsp)
   1639b:      	je	0x16472 <generic_lsm_path+0xb742>
   163a1:      	movl	$0x4, %eax
   163a6:      	leaq	0x8(%rsp), %rdi
   163ab:      	movl	$0x8, %esi
   163b0:      	movq	%rbx, %rdx
   163b3:      	callq	*%rax
   163b5:      	addq	$0x20, %r12
   163b9:      	movl	$0x4, %eax
   163be:      	leaq	0x58(%rsp), %rdi
   163c3:      	movl	$0x10, %ecx
   163c8:      	movl	$0x10, %esi
   163cd:      	movq	%r12, %rdx
   163d0:      	callq	*%rax
   163d2:      	movq	0x28(%rsp), %rbx
   163d7:      	movq	0x48(%rsp), %rax
   163dc:      	movl	0x5c(%rsp), %r15d
   163e1:      	subq	%rbx, %rax
   163e4:      	movl	0x50(%rsp), %r12d
   163e9:      	movl	%r15d, %edx
   163ec:      	subl	%r12d, %edx
   163ef:      	movl	$0x0, %ecx
   163f4:      	cmovbl	%ecx, %edx
   163f7:      	addq	0x60(%rsp), %rdx
   163fc:      	xorl	%esi, %esi
   163fe:      	cmpl	%r15d, %r12d
   16401:      	seta	%sil
   16405:      	movl	%r15d, %ecx
   16408:      	cmovbl	%r12d, %ecx
   1640c:      	addl	%ecx, %esi
   1640e:      	movl	%r12d, %edi
   16411:      	subl	%esi, %edi
   16413:      	movl	%edi, 0x50(%rsp)
   16417:      	subq	%rsi, %rax
   1641a:      	jb	0x167a2 <generic_lsm_path+0xba72>
   16420:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   16426:      	ja	0x167a2 <generic_lsm_path+0xba72>
   1642c:      	cmpl	%r15d, %r12d
   1642f:      	jbe	0x16435 <generic_lsm_path+0xb705>
   16431:      	movb	$0x2f, (%rbx,%rax)
   16435:      	xorl	%edi, %edi
   16437:      	cmpl	%r15d, %r12d
   1643a:      	seta	%dil
   1643e:      	movzbl	%cl, %esi
   16441:      	addq	%rax, %rbx
   16444:      	addq	%rbx, %rdi
   16447:      	movl	$0x4, %eax
   1644c:      	callq	*%rax
   1644e:      	movq	%rbx, 0x48(%rsp)
   16453:      	cmpl	%r15d, %r12d
   16456:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   1645c:      	movq	0x8(%rsp), %r12
   16461:      	movq	%r12, 0x30(%rsp)
   16466:      	movq	0x38(%rsp), %rdx
   1646b:      	movq	0x40(%rsp), %r15
   16470:      	jmp	0x164c3 <generic_lsm_path+0xb793>
   16472:      	leaq	0x10(%r15), %rdx
   16476:      	movl	$0x4, %eax
   1647b:      	movq	%rbp, %rdi
   1647e:      	movl	$0x8, %esi
   16483:      	callq	*%rax
   16485:      	movq	0x40(%rsp), %rax
   1648a:      	cmpq	(%rsp), %rax
   1648e:      	je	0x1679d <generic_lsm_path+0xba6d>
   16494:      	addq	$0x18, %r15
   16498:      	movl	$0x4, %eax
   1649d:      	leaq	0x30(%rsp), %rdi
   164a2:      	movl	$0x8, %esi
   164a7:      	movq	%r15, %rdx
   164aa:      	callq	*%rax
   164ac:      	movq	(%rsp), %r15
   164b0:      	movq	%r15, 0x40(%rsp)
   164b5:      	leaq	0x20(%r15), %rdx
   164b9:      	movq	%rdx, 0x38(%rsp)
   164be:      	movq	0x30(%rsp), %r12
   164c3:      	cmpq	0x18(%rsp), %r12
   164c8:      	jne	0x164d5 <generic_lsm_path+0xb7a5>
   164ca:      	cmpq	0x20(%rsp), %rdx
   164cf:      	je	0x1679d <generic_lsm_path+0xba6d>
   164d5:      	movl	$0x4, %eax
   164da:      	leaq	0x10(%rsp), %rdi
   164df:      	movl	$0x8, %esi
   164e4:      	callq	*%rax
   164e6:      	cmpq	0x10(%rsp), %r12
   164eb:      	je	0x165e3 <generic_lsm_path+0xb8b3>
   164f1:      	leaq	0x18(%r12), %rbx
   164f6:      	movl	$0x4, %eax
   164fb:      	movq	%rbp, %rdi
   164fe:      	movl	$0x8, %esi
   16503:      	movq	%rbx, %rdx
   16506:      	callq	*%rax
   16508:      	cmpq	%r12, (%rsp)
   1650c:      	je	0x165e3 <generic_lsm_path+0xb8b3>
   16512:      	movl	$0x4, %eax
   16517:      	leaq	0x8(%rsp), %rdi
   1651c:      	movl	$0x8, %esi
   16521:      	movq	%rbx, %rdx
   16524:      	callq	*%rax
   16526:      	addq	$0x20, %r12
   1652a:      	movl	$0x4, %eax
   1652f:      	leaq	0x58(%rsp), %rdi
   16534:      	movl	$0x10, %ecx
   16539:      	movl	$0x10, %esi
   1653e:      	movq	%r12, %rdx
   16541:      	callq	*%rax
   16543:      	movq	0x28(%rsp), %rbx
   16548:      	movq	0x48(%rsp), %rax
   1654d:      	movl	0x5c(%rsp), %r15d
   16552:      	subq	%rbx, %rax
   16555:      	movl	0x50(%rsp), %r12d
   1655a:      	movl	%r15d, %edx
   1655d:      	subl	%r12d, %edx
   16560:      	movl	$0x0, %ecx
   16565:      	cmovbl	%ecx, %edx
   16568:      	addq	0x60(%rsp), %rdx
   1656d:      	xorl	%esi, %esi
   1656f:      	cmpl	%r15d, %r12d
   16572:      	seta	%sil
   16576:      	movl	%r15d, %ecx
   16579:      	cmovbl	%r12d, %ecx
   1657d:      	addl	%ecx, %esi
   1657f:      	movl	%r12d, %edi
   16582:      	subl	%esi, %edi
   16584:      	movl	%edi, 0x50(%rsp)
   16588:      	subq	%rsi, %rax
   1658b:      	jb	0x167a2 <generic_lsm_path+0xba72>
   16591:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   16597:      	ja	0x167a2 <generic_lsm_path+0xba72>
   1659d:      	cmpl	%r15d, %r12d
   165a0:      	jbe	0x165a6 <generic_lsm_path+0xb876>
   165a2:      	movb	$0x2f, (%rbx,%rax)
   165a6:      	xorl	%edi, %edi
   165a8:      	cmpl	%r15d, %r12d
   165ab:      	seta	%dil
   165af:      	movzbl	%cl, %esi
   165b2:      	addq	%rax, %rbx
   165b5:      	addq	%rbx, %rdi
   165b8:      	movl	$0x4, %eax
   165bd:      	callq	*%rax
   165bf:      	movq	%rbx, 0x48(%rsp)
   165c4:      	cmpl	%r15d, %r12d
   165c7:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   165cd:      	movq	0x8(%rsp), %r12
   165d2:      	movq	%r12, 0x30(%rsp)
   165d7:      	movq	0x38(%rsp), %rdx
   165dc:      	movq	0x40(%rsp), %r15
   165e1:      	jmp	0x16634 <generic_lsm_path+0xb904>
   165e3:      	leaq	0x10(%r15), %rdx
   165e7:      	movl	$0x4, %eax
   165ec:      	movq	%rbp, %rdi
   165ef:      	movl	$0x8, %esi
   165f4:      	callq	*%rax
   165f6:      	movq	0x40(%rsp), %rax
   165fb:      	cmpq	(%rsp), %rax
   165ff:      	je	0x1679d <generic_lsm_path+0xba6d>
   16605:      	addq	$0x18, %r15
   16609:      	movl	$0x4, %eax
   1660e:      	leaq	0x30(%rsp), %rdi
   16613:      	movl	$0x8, %esi
   16618:      	movq	%r15, %rdx
   1661b:      	callq	*%rax
   1661d:      	movq	(%rsp), %r15
   16621:      	movq	%r15, 0x40(%rsp)
   16626:      	leaq	0x20(%r15), %rdx
   1662a:      	movq	%rdx, 0x38(%rsp)
   1662f:      	movq	0x30(%rsp), %r12
   16634:      	cmpq	0x18(%rsp), %r12
   16639:      	jne	0x16646 <generic_lsm_path+0xb916>
   1663b:      	cmpq	0x20(%rsp), %rdx
   16640:      	je	0x1679d <generic_lsm_path+0xba6d>
   16646:      	movl	$0x4, %eax
   1664b:      	leaq	0x10(%rsp), %rdi
   16650:      	movl	$0x8, %esi
   16655:      	callq	*%rax
   16657:      	cmpq	0x10(%rsp), %r12
   1665c:      	je	0x16746 <generic_lsm_path+0xba16>
   16662:      	leaq	0x18(%r12), %rbx
   16667:      	movl	$0x4, %eax
   1666c:      	movq	%rbp, %rdi
   1666f:      	movl	$0x8, %esi
   16674:      	movq	%rbx, %rdx
   16677:      	callq	*%rax
   16679:      	cmpq	%r12, (%rsp)
   1667d:      	je	0x16746 <generic_lsm_path+0xba16>
   16683:      	movl	$0x4, %eax
   16688:      	leaq	0x8(%rsp), %rdi
   1668d:      	movl	$0x8, %esi
   16692:      	movq	%rbx, %rdx
   16695:      	callq	*%rax
   16697:      	addq	$0x20, %r12
   1669b:      	movl	$0x4, %eax
   166a0:      	leaq	0x58(%rsp), %rdi
   166a5:      	movl	$0x10, %ecx
   166aa:      	movl	$0x10, %esi
   166af:      	movq	%r12, %rdx
   166b2:      	callq	*%rax
   166b4:      	movq	0x28(%rsp), %rbx
   166b9:      	movq	0x48(%rsp), %rax
   166be:      	movl	0x5c(%rsp), %r15d
   166c3:      	subq	%rbx, %rax
   166c6:      	movl	0x50(%rsp), %r12d
   166cb:      	movl	%r15d, %edx
   166ce:      	subl	%r12d, %edx
   166d1:      	movl	$0x0, %ecx
   166d6:      	cmovbl	%ecx, %edx
   166d9:      	addq	0x60(%rsp), %rdx
   166de:      	xorl	%esi, %esi
   166e0:      	cmpl	%r15d, %r12d
   166e3:      	seta	%sil
   166e7:      	movl	%r15d, %ecx
   166ea:      	cmovbl	%r12d, %ecx
   166ee:      	addl	%ecx, %esi
   166f0:      	movl	%r12d, %edi
   166f3:      	subl	%esi, %edi
   166f5:      	movl	%edi, 0x50(%rsp)
   166f9:      	subq	%rsi, %rax
   166fc:      	jb	0x167a2 <generic_lsm_path+0xba72>
   16702:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   16708:      	ja	0x167a2 <generic_lsm_path+0xba72>
   1670e:      	cmpl	%r15d, %r12d
   16711:      	jbe	0x16717 <generic_lsm_path+0xb9e7>
   16713:      	movb	$0x2f, (%rbx,%rax)
   16717:      	xorl	%edi, %edi
   16719:      	cmpl	%r15d, %r12d
   1671c:      	seta	%dil
   16720:      	movzbl	%cl, %esi
   16723:      	addq	%rax, %rbx
   16726:      	addq	%rbx, %rdi
   16729:      	movl	$0x4, %eax
   1672e:      	callq	*%rax
   16730:      	movq	%rbx, 0x48(%rsp)
   16735:      	cmpl	%r15d, %r12d
   16738:      	jbe	0x167a2 <generic_lsm_path+0xba72>
   1673a:      	movq	0x8(%rsp), %rax
   1673f:      	movq	%rax, 0x30(%rsp)
   16744:      	jmp	0x1678e <generic_lsm_path+0xba5e>
   16746:      	leaq	0x10(%r15), %rdx
   1674a:      	movl	$0x4, %eax
   1674f:      	movq	%rbp, %rdi
   16752:      	movl	$0x8, %esi
   16757:      	callq	*%rax
   16759:      	movq	0x40(%rsp), %rax
   1675e:      	cmpq	(%rsp), %rax
   16762:      	je	0x1679d <generic_lsm_path+0xba6d>
   16764:      	addq	$0x18, %r15
   16768:      	movl	$0x4, %eax
   1676d:      	leaq	0x30(%rsp), %rdi
   16772:      	movl	$0x8, %esi
   16777:      	movq	%r15, %rdx
   1677a:      	callq	*%rax
   1677c:      	movq	(%rsp), %rax
   16780:      	movq	%rax, 0x40(%rsp)
   16785:      	addq	$0x20, %rax
   16789:      	movq	%rax, 0x38(%rsp)
   1678e:      	movl	0x6c(%rsp), %eax
   16792:      	addl	$-0x80, %eax
   16795:      	jne	0xaed3 <generic_lsm_path+0x1a3>
   1679b:      	jmp	0x167a2 <generic_lsm_path+0xba72>
   1679d:      	movb	$0x1, 0x54(%rsp)
   167a2:      	movl	0x6428(%r14), %eax
   167a9:      	incl	%eax
   167ab:      	movl	%eax, 0x6428(%r14)
   167b2:      	movl	0x48(%rsp), %ecx
   167b6:      	subl	0x80(%rsp), %ecx
   167bd:      	movl	%ecx, 0x6424(%r14)
   167c4:      	cmpb	$0x0, 0x54(%rsp)
   167c9:      	jne	0x16811 <generic_lsm_path+0xbae1>
   167cb:      	cmpl	$0x8, %eax
   167ce:      	je	0x16811 <generic_lsm_path+0xbae1>
   167d0:      	movq	0x30(%rsp), %rax
   167d5:      	movq	%rax, 0x6458(%r14)
   167dc:      	movq	0x38(%rsp), %rax
   167e1:      	movq	%rax, 0x6460(%r14)
   167e8:      	movq	0x40(%rsp), %rax
   167ed:      	movq	%rax, 0x6468(%r14)
   167f4:      	movq	(%rip), %rcx            # 0x167fb <generic_lsm_path+0xbacb>
   167fb:      	movl	$0x6, %edx
   16800:      	movl	$0xc, %eax
   16805:      	movq	0x78(%rsp), %rdi
   1680a:      	movl	$0x6, %edx
   1680f:      	jmp	0x1682c <generic_lsm_path+0xbafc>
   16811:      	movq	(%rip), %rcx            # 0x16818 <generic_lsm_path+0xbae8>
   16818:      	movl	$0x1, %edx
   1681d:      	movl	$0xc, %eax
   16822:      	movq	0x78(%rsp), %rdi
   16827:      	movl	$0x1, %edx
   1682c:      	movq	(%rip), %rsi            # 0x16833 <generic_lsm_path+0xbb03>
   16833:      	jmp	0x16ba7 <generic_lsm_path+0xbe77>
   16838:      	movl	$0x1, (%rsp)
   1683f:      	movq	(%rip), %rdi            # 0x16846 <generic_lsm_path+0xbb16>
   16846:      	xorl	%ecx, %ecx
   16848:      	leaq	0x18(%rsp), %rsi
   1684d:      	movq	%rsp, %rdx
   16850:      	movl	$0x2, %eax
   16855:      	xorl	%ecx, %ecx
   16857:      	callq	*%rax
   16859:      	movq	0x58(%rsp), %r12
   1685e:      	leaq	0x10(%r12), %rdx
   16863:      	leaq	0x18(%rsp), %rdi
   16868:      	movl	$0x8, %ecx
   1686d:      	movl	$0x4, %eax
   16872:      	leaq	0xfff(%r15), %rbx
   16879:      	movl	$0x8, %esi
   1687e:      	callq	*%rax
   16880:      	cmpq	$0x0, 0x18(%rsp)
   16886:      	jne	0x168cf <generic_lsm_path+0xbb9f>
   16888:      	leaq	0x18(%r12), %rdx
   1688d:      	leaq	0x18(%rsp), %rdi
   16892:      	movl	$0x8, %ecx
   16897:      	movl	$0x4, %eax
   1689c:      	movl	$0x8, %esi
   168a1:      	callq	*%rax
   168a3:      	cmpq	%r12, 0x18(%rsp)
   168a8:      	je	0x168cf <generic_lsm_path+0xbb9f>
   168aa:      	movq	%r15, %rbx
   168ad:      	addq	$0xff5, %rbx            # imm = 0xFF5
   168b4:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
   168be:      	movq	%rax, 0xff5(%r15)
   168c5:      	movw	$0x2964, 0xffd(%r15)    # imm = 0x2964
   168cf:      	movl	$0x23, %eax
   168d4:      	callq	*%rax
   168d6:      	leaq	0xd50(%rax), %rdx
   168dd:      	movq	%rsp, %rdi
   168e0:      	movl	$0x8, %ecx
   168e5:      	movl	$0x4, %eax
   168ea:      	movl	$0x8, %esi
   168ef:      	callq	*%rax
   168f1:      	testq	%rax, %rax
   168f4:      	je	0x16953 <generic_lsm_path+0xbc23>
   168f6:      	negl	%eax
   168f8:      	movw	%ax, 0x18(%rsp)
   168fd:      	movw	$0x6, 0x1a(%rsp)
   16904:      	movabsq	$0x400000033, %rax      # imm = 0x400000033
   1690e:      	movq	%rax, 0x1c(%rsp)
   16913:      	movq	(%rip), %rdi            # 0x1691a <generic_lsm_path+0xbbea>
   1691a:      	leaq	0x18(%rsp), %rsi
   1691f:      	movl	$0x1, %eax
   16924:      	callq	*%rax
   16926:      	testq	%rax, %rax
   16929:      	je	0x1692f <generic_lsm_path+0xbbff>
   1692b:      	incl	(%rax)
   1692d:      	jmp	0x16953 <generic_lsm_path+0xbc23>
   1692f:      	movl	$0x1, 0x8(%rsp)
   16937:      	movq	(%rip), %rdi            # 0x1693e <generic_lsm_path+0xbc0e>
   1693e:      	xorl	%ecx, %ecx
   16940:      	leaq	0x18(%rsp), %rsi
   16945:      	leaq	0x8(%rsp), %rdx
   1694a:      	movl	$0x2, %eax
   1694f:      	xorl	%ecx, %ecx
   16951:      	callq	*%rax
   16953:      	movq	(%rsp), %rdx
   16957:      	leaq	0x18(%rdx), %r13
   1695b:      	movq	0x6440(%r14), %r12
   16962:      	leaq	0x6448(%r14), %rdi
   16969:      	addq	$0x20, %rdx
   1696d:      	movl	$0x8, %ecx
   16972:      	movl	$0x4, %eax
   16977:      	movl	$0x8, %esi
   1697c:      	callq	*%rax
   1697e:      	testq	%rax, %rax
   16981:      	je	0x169e0 <generic_lsm_path+0xbcb0>
   16983:      	negl	%eax
   16985:      	movw	%ax, 0x18(%rsp)
   1698a:      	movw	$0x6, 0x1a(%rsp)
   16991:      	movabsq	$0x400000038, %rax      # imm = 0x400000038
   1699b:      	movq	%rax, 0x1c(%rsp)
   169a0:      	movq	(%rip), %rdi            # 0x169a7 <generic_lsm_path+0xbc77>
   169a7:      	leaq	0x18(%rsp), %rsi
   169ac:      	movl	$0x1, %eax
   169b1:      	callq	*%rax
   169b3:      	testq	%rax, %rax
   169b6:      	je	0x169bc <generic_lsm_path+0xbc8c>
   169b8:      	incl	(%rax)
   169ba:      	jmp	0x169e0 <generic_lsm_path+0xbcb0>
   169bc:      	movl	$0x1, 0x8(%rsp)
   169c4:      	movq	(%rip), %rdi            # 0x169cb <generic_lsm_path+0xbc9b>
   169cb:      	xorl	%ecx, %ecx
   169cd:      	leaq	0x18(%rsp), %rsi
   169d2:      	leaq	0x8(%rsp), %rdx
   169d7:      	movl	$0x2, %eax
   169dc:      	xorl	%ecx, %ecx
   169de:      	callq	*%rax
   169e0:      	leaq	0x6450(%r14), %rdi
   169e7:      	movl	$0x8, %ecx
   169ec:      	movl	$0x4, %eax
   169f1:      	movl	$0x8, %esi
   169f6:      	movq	%r13, %rdx
   169f9:      	callq	*%rax
   169fb:      	testq	%rax, %rax
   169fe:      	je	0x16a5d <generic_lsm_path+0xbd2d>
   16a00:      	negl	%eax
   16a02:      	movw	%ax, 0x18(%rsp)
   16a07:      	movw	$0x6, 0x1a(%rsp)
   16a0e:      	movabsq	$0x400000039, %rax      # imm = 0x400000039
   16a18:      	movq	%rax, 0x1c(%rsp)
   16a1d:      	movq	(%rip), %rdi            # 0x16a24 <generic_lsm_path+0xbcf4>
   16a24:      	leaq	0x18(%rsp), %rsi
   16a29:      	movl	$0x1, %eax
   16a2e:      	callq	*%rax
   16a30:      	testq	%rax, %rax
   16a33:      	je	0x16a39 <generic_lsm_path+0xbd09>
   16a35:      	incl	(%rax)
   16a37:      	jmp	0x16a5d <generic_lsm_path+0xbd2d>
   16a39:      	movl	$0x1, 0x8(%rsp)
   16a41:      	movq	(%rip), %rdi            # 0x16a48 <generic_lsm_path+0xbd18>
   16a48:      	xorl	%ecx, %ecx
   16a4a:      	leaq	0x18(%rsp), %rsi
   16a4f:      	leaq	0x8(%rsp), %rdx
   16a54:      	movl	$0x2, %eax
   16a59:      	xorl	%ecx, %ecx
   16a5b:      	callq	*%rax
   16a5d:      	leaq	0x6458(%r14), %rdi
   16a64:      	leaq	0x8(%r12), %rdx
   16a69:      	movl	$0x8, %ecx
   16a6e:      	movl	$0x4, %eax
   16a73:      	movl	$0x8, %esi
   16a78:      	callq	*%rax
   16a7a:      	testq	%rax, %rax
   16a7d:      	je	0x16adc <generic_lsm_path+0xbdac>
   16a7f:      	negl	%eax
   16a81:      	movw	%ax, 0x18(%rsp)
   16a86:      	movw	$0x6, 0x1a(%rsp)
   16a8d:      	movabsq	$0x40000003a, %rax      # imm = 0x40000003A
   16a97:      	movq	%rax, 0x1c(%rsp)
   16a9c:      	movq	(%rip), %rdi            # 0x16aa3 <generic_lsm_path+0xbd73>
   16aa3:      	leaq	0x18(%rsp), %rsi
   16aa8:      	movl	$0x1, %eax
   16aad:      	callq	*%rax
   16aaf:      	testq	%rax, %rax
   16ab2:      	je	0x16ab8 <generic_lsm_path+0xbd88>
   16ab4:      	incl	(%rax)
   16ab6:      	jmp	0x16adc <generic_lsm_path+0xbdac>
   16ab8:      	movl	$0x1, 0x8(%rsp)
   16ac0:      	movq	(%rip), %rdi            # 0x16ac7 <generic_lsm_path+0xbd97>
   16ac7:      	xorl	%ecx, %ecx
   16ac9:      	leaq	0x18(%rsp), %rsi
   16ace:      	leaq	0x8(%rsp), %rdx
   16ad3:      	movl	$0x2, %eax
   16ad8:      	xorl	%ecx, %ecx
   16ada:      	callq	*%rax
   16adc:      	movq	%r14, %rdi
   16adf:      	addq	$0x6460, %rdi           # imm = 0x6460
   16ae6:      	movl	$0x8, %ecx
   16aeb:      	movl	$0x4, %eax
   16af0:      	movl	$0x8, %esi
   16af5:      	movq	%r12, %rdx
   16af8:      	callq	*%rax
   16afa:      	testq	%rax, %rax
   16afd:      	je	0x16b5c <generic_lsm_path+0xbe2c>
   16aff:      	negl	%eax
   16b01:      	movw	%ax, 0x18(%rsp)
   16b06:      	movw	$0x6, 0x1a(%rsp)
   16b0d:      	movabsq	$0x40000003b, %rax      # imm = 0x40000003B
   16b17:      	movq	%rax, 0x1c(%rsp)
   16b1c:      	movq	(%rip), %rdi            # 0x16b23 <generic_lsm_path+0xbdf3>
   16b23:      	leaq	0x18(%rsp), %rsi
   16b28:      	movl	$0x1, %eax
   16b2d:      	callq	*%rax
   16b2f:      	testq	%rax, %rax
   16b32:      	je	0x16b38 <generic_lsm_path+0xbe08>
   16b34:      	incl	(%rax)
   16b36:      	jmp	0x16b5c <generic_lsm_path+0xbe2c>
   16b38:      	movl	$0x1, 0x8(%rsp)
   16b40:      	movq	(%rip), %rdi            # 0x16b47 <generic_lsm_path+0xbe17>
   16b47:      	xorl	%ecx, %ecx
   16b49:      	leaq	0x18(%rsp), %rsi
   16b4e:      	leaq	0x8(%rsp), %rdx
   16b53:      	movl	$0x2, %eax
   16b58:      	xorl	%ecx, %ecx
   16b5a:      	callq	*%rax
   16b5c:      	movq	0x6460(%r14), %rax
   16b63:      	addq	$-0x20, %rax
   16b67:      	movq	%rax, 0x6468(%r14)
   16b6e:      	movl	$0x0, 0x6428(%r14)
   16b79:      	subl	%r15d, %ebx
   16b7c:      	movl	%ebx, 0x6424(%r14)
   16b83:      	movl	$0x1, 0x6420(%r14)
   16b8e:      	movq	(%rip), %rsi            # 0x16b95 <generic_lsm_path+0xbe65>
   16b95:      	movl	$0x6, %ecx
   16b9a:      	movl	$0xc, %eax
   16b9f:      	movq	%rbp, %rdi
   16ba2:      	movl	$0x6, %edx
   16ba7:      	callq	*%rax
   16ba9:      	xorl	%eax, %eax
   16bab:      	addq	$0x88, %rsp
   16bb2:      	popq	%rbx
   16bb3:      	popq	%r12
   16bb5:      	popq	%r13
   16bb7:      	popq	%r14
   16bb9:      	popq	%r15
   16bbb:      	popq	%rbp
   16bbc:      	retq

Disassembly of section lsm/generic_lsm_core:

0000000000000000 <generic_lsm_event>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x88, %rsp
      11:      	movq	%rdi, %rbx
      14:      	movl	$0x0, 0x38(%rsp)
      1c:      	movq	(%rip), %rdi            # 0x23 <generic_lsm_event+0x23>
      23:      	leaq	0x38(%rsp), %rsi
      28:      	movl	$0x1, %eax
      2d:      	callq	*%rax
      2f:      	testq	%rax, %rax
      32:      	je	0x62d <generic_lsm_event+0x62d>
      38:      	movq	%rax, %r14
      3b:      	leaq	0x5ef8(%rax), %rsi
      42:      	movl	$0x0, 0x5ef8(%rax)
      4c:      	movq	(%rip), %rdi            # 0x53 <generic_lsm_event+0x53>
      53:      	movl	$0x1, %eax
      58:      	callq	*%rax
      5a:      	testq	%rax, %rax
      5d:      	je	0x62d <generic_lsm_event+0x62d>
      63:      	movl	0x64(%rax), %ecx
      66:      	movl	%ecx, 0x14(%rsp)
      6a:      	testl	%ecx, %ecx
      6c:      	je	0x23b <generic_lsm_event+0x23b>
      72:      	movq	%rax, %r12
      75:      	movq	(%rip), %rdi            # 0x7c <generic_lsm_event+0x7c>
      7c:      	leaq	0x14(%rsp), %rsi
      81:      	movl	$0x1, %eax
      86:      	callq	*%rax
      88:      	testq	%rax, %rax
      8b:      	je	0x62d <generic_lsm_event+0x62d>
      91:      	movq	%rax, %r15
      94:      	movl	$0x0, 0x3c(%rsp)
      9c:      	movq	(%rip), %rdi            # 0xa3 <generic_lsm_event+0xa3>
      a3:      	leaq	0x3c(%rsp), %rsi
      a8:      	movl	$0x1, %eax
      ad:      	callq	*%rax
      af:      	testq	%rax, %rax
      b2:      	je	0xd8 <generic_lsm_event+0xd8>
      b4:      	cmpq	$0x63677270, 0x20(%rax) # imm = 0x63677270
      bc:      	jne	0xdc <generic_lsm_event+0xdc>
      be:      	movl	$0x50, %eax
      c3:      	callq	*%rax
      c5:      	movq	%rax, 0x8(%rsp)
      ca:      	testq	%rax, %rax
      cd:      	jne	0x1f6 <generic_lsm_event+0x1f6>
      d3:      	jmp	0x62d <generic_lsm_event+0x62d>
      d8:      	xorl	%ebp, %ebp
      da:      	jmp	0xdf <generic_lsm_event+0xdf>
      dc:      	movl	0x10(%rax), %ebp
      df:      	movl	$0x23, %eax
      e4:      	callq	*%rax
      e6:      	movq	$0x0, 0x20(%rsp)
      ef:      	leaq	0xf90(%rax), %rdx
      f6:      	leaq	0x28(%rsp), %rdi
      fb:      	movl	$0x8, %ecx
     100:      	movl	$0x71, %eax
     105:      	movl	$0x8, %esi
     10a:      	callq	*%rax
     10c:      	movq	0x28(%rsp), %rax
     111:      	testq	%rax, %rax
     114:      	je	0x62d <generic_lsm_event+0x62d>
     11a:      	cmpl	$0xb, %ebp
     11d:      	ja	0x62d <generic_lsm_event+0x62d>
     123:      	movl	%ebp, %edx
     125:      	leaq	(%rax,%rdx,8), %rcx
     129:      	leaq	0x40(%rsp), %rdi
     12e:      	movl	$0x8, %esi
     133:      	movl	$0x71, %eax
     138:      	shlq	$0x3, %rdx
     13c:      	addq	0x28(%rsp), %rdx
     141:      	movl	$0x8, %esi
     146:      	callq	*%rax
     148:      	movq	0x40(%rsp), %rcx
     14d:      	testq	%rcx, %rcx
     150:      	je	0x62d <generic_lsm_event+0x62d>
     156:      	leaq	0x20(%rsp), %rdi
     15b:      	movl	$0x8, %edx
     160:      	movl	$0x71, %eax
     165:      	movq	0x40(%rsp), %rdx
     16a:      	movl	$0x8, %esi
     16f:      	callq	*%rax
     171:      	movq	0x20(%rsp), %rdx
     176:      	testq	%rdx, %rdx
     179:      	je	0x62d <generic_lsm_event+0x62d>
     17f:      	movq	$0x0, 0x40(%rsp)
     188:      	addq	$0x100, %rdx            # imm = 0x100
     18f:      	leaq	0x40(%rsp), %rdi
     194:      	movl	$0x8, %ecx
     199:      	movl	$0x71, %eax
     19e:      	movl	$0x8, %esi
     1a3:      	callq	*%rax
     1a5:      	movq	0x40(%rsp), %rdx
     1aa:      	movq	$0x0, 0x40(%rsp)
     1b3:      	testq	%rdx, %rdx
     1b6:      	je	0x1e6 <generic_lsm_event+0x1e6>
     1b8:      	addq	$0x60, %rdx
     1bc:      	leaq	0x40(%rsp), %rdi
     1c1:      	movl	$0x8, %ecx
     1c6:      	movl	$0x71, %eax
     1cb:      	movl	$0x8, %esi
     1d0:      	callq	*%rax
     1d2:      	movq	0x40(%rsp), %rax
     1d7:      	movq	%rax, 0x8(%rsp)
     1dc:      	testq	%rax, %rax
     1df:      	jne	0x1f6 <generic_lsm_event+0x1f6>
     1e1:      	jmp	0x62d <generic_lsm_event+0x62d>
     1e6:      	xorl	%eax, %eax
     1e8:      	movq	%rax, 0x8(%rsp)
     1ed:      	testq	%rax, %rax
     1f0:      	je	0x62d <generic_lsm_event+0x62d>
     1f6:      	movq	%rax, 0x40(%rsp)
     1fb:      	movq	(%rip), %rdi            # 0x202 <generic_lsm_event+0x202>
     202:      	leaq	0x40(%rsp), %rsi
     207:      	movl	$0x1, %eax
     20c:      	callq	*%rax
     20e:      	testq	%rax, %rax
     211:      	je	0x220 <generic_lsm_event+0x220>
     213:      	movq	(%rax), %rax
     216:      	testq	%rax, %rax
     219:      	je	0x220 <generic_lsm_event+0x220>
     21b:      	movq	%rax, 0x8(%rsp)
     220:      	leaq	0x8(%rsp), %rsi
     225:      	movl	$0x1, %eax
     22a:      	movq	%r15, %rdi
     22d:      	callq	*%rax
     22f:      	testq	%rax, %rax
     232:      	movq	%r12, %rax
     235:      	je	0x641 <generic_lsm_event+0x641>
     23b:      	movl	(%rax), %eax
     23d:      	movq	%rax, 0x60(%r14)
     241:      	movq	$0x0, 0x68(%r14)
     249:      	movq	$0x0, 0x5efc(%r14)
     254:      	movl	$0x0, 0x6420(%r14)
     25f:      	movq	$0x0, 0x5eb8(%r14)
     26a:      	movq	$0x0, 0x5ec0(%r14)
     275:      	movq	$0x0, 0x5ec8(%r14)
     280:      	movq	$0x0, 0x5ed0(%r14)
     28b:      	movq	$0x0, 0x5ed8(%r14)
     296:      	movb	$0x0, 0x5ee0(%r14)
     29e:      	movl	$0x23, %eax
     2a3:      	callq	*%rax
     2a5:      	movq	%rax, %r15
     2a8:      	leaq	0xd70(%rax), %rdx
     2af:      	leaq	0x20(%rsp), %rdi
     2b4:      	movl	$0x8, %ecx
     2b9:      	movl	$0x4, %eax
     2be:      	leaq	0x20(%r14), %r12
     2c2:      	movl	$0x4, %r13d
     2c8:      	movl	$0x8, %esi
     2cd:      	callq	*%rax
     2cf:      	movq	0x20(%rsp), %rcx
     2d4:      	leaq	0x40(%rsp), %rdi
     2d9:      	movl	$0x48, %edx
     2de:      	movl	$0x4, %eax
     2e3:      	movq	0x20(%rsp), %rdx
     2e8:      	movl	$0x48, %esi
     2ed:      	callq	*%rax
     2ef:      	movl	$0x218, %edx            # imm = 0x218
     2f4:      	movq	0x48(%rsp), %rcx
     2f9:      	addq	%rdx, %rcx
     2fc:      	movl	$0x4, %esi
     301:      	movl	$0x4, %eax
     306:      	addq	0x48(%rsp), %rdx
     30b:      	movq	%r12, %rdi
     30e:      	movl	$0x4, %esi
     313:      	callq	*%rax
     315:      	leaq	0x24(%r14), %rdi
     319:      	movl	$0x4d8, %edx            # imm = 0x4D8
     31e:      	movq	0x50(%rsp), %rcx
     323:      	addq	%rdx, %rcx
     326:      	movl	$0x4, %esi
     32b:      	movl	$0x4, %eax
     330:      	addq	0x50(%rsp), %rdx
     335:      	movl	$0x4, %esi
     33a:      	callq	*%rax
     33c:      	leaq	0x28(%r14), %rdi
     340:      	movq	0x58(%rsp), %rcx
     345:      	addq	$0x58, %rcx
     349:      	movl	$0x4, %edx
     34e:      	movl	$0x4, %eax
     353:      	movq	0x58(%rsp), %rdx
     358:      	addq	$0x58, %rdx
     35c:      	movl	$0x4, %esi
     361:      	callq	*%rax
     363:      	movq	$0x0, 0x8(%rsp)
     36c:      	leaq	0xb58(%r15), %rdx
     373:      	leaq	0x8(%rsp), %rdi
     378:      	movl	$0x8, %ecx
     37d:      	movl	$0x4, %eax
     382:      	movl	$0x8, %esi
     387:      	callq	*%rax
     389:      	movq	0x8(%rsp), %rcx
     38e:      	testq	%rcx, %rcx
     391:      	je	0x427 <generic_lsm_event+0x427>
     397:      	movl	$0x0, 0x18(%rsp)
     39f:      	addq	$0x4, %rcx
     3a3:      	leaq	0x18(%rsp), %rdi
     3a8:      	movl	$0x4, %eax
     3ad:      	movq	0x8(%rsp), %rdx
     3b2:      	addq	$0x4, %rdx
     3b6:      	movl	$0x4, %esi
     3bb:      	callq	*%rax
     3bd:      	movq	0x8(%rsp), %rax
     3c2:      	movslq	0x18(%rsp), %rcx
     3c7:      	shlq	$0x4, %rcx
     3cb:      	addq	%rax, %rcx
     3ce:      	addq	$0x80, %rcx
     3d5:      	leaq	0x28(%rsp), %rdi
     3da:      	movl	$0x10, %edx
     3df:      	movl	$0x4, %eax
     3e4:      	movq	0x8(%rsp), %rcx
     3e9:      	movslq	0x18(%rsp), %rdx
     3ee:      	shlq	$0x4, %rdx
     3f2:      	addq	%rcx, %rdx
     3f5:      	addq	$0x80, %rdx
     3fc:      	movl	$0x10, %esi
     401:      	callq	*%rax
     403:      	leaq	0x2c(%r14), %rdi
     407:      	movl	$0x158, %edx            # imm = 0x158
     40c:      	movq	0x30(%rsp), %rcx
     411:      	addq	%rdx, %rcx
     414:      	movl	$0x4, %eax
     419:      	addq	0x30(%rsp), %rdx
     41e:      	movl	$0x4, %esi
     423:      	callq	*%rax
     425:      	jmp	0x42f <generic_lsm_event+0x42f>
     427:      	movl	$0x0, 0x2c(%r14)
     42f:      	leaq	0x30(%r14), %rdi
     433:      	movl	$0x158, %r12d           # imm = 0x158
     439:      	movq	0x60(%rsp), %rcx
     43e:      	addq	%r12, %rcx
     441:      	movl	$0x4, %edx
     446:      	movl	$0x4, %eax
     44b:      	movq	0x60(%rsp), %rdx
     450:      	addq	%r12, %rdx
     453:      	movl	$0x4, %esi
     458:      	callq	*%rax
     45a:      	leaq	0x34(%r14), %rdi
     45e:      	movl	$0x118, %edx            # imm = 0x118
     463:      	movq	0x68(%rsp), %rcx
     468:      	addq	%rdx, %rcx
     46b:      	movl	$0x4, %esi
     470:      	movl	$0x4, %eax
     475:      	addq	0x68(%rsp), %rdx
     47a:      	movl	$0x4, %esi
     47f:      	callq	*%rax
     481:      	leaq	0x38(%r14), %rdi
     485:      	movl	$0x98, %r13d
     48b:      	movq	0x70(%rsp), %rcx
     490:      	addq	%r13, %rcx
     493:      	movl	$0x4, %edx
     498:      	movl	$0x4, %eax
     49d:      	movq	0x70(%rsp), %rdx
     4a2:      	addq	%r13, %rdx
     4a5:      	movl	$0x4, %esi
     4aa:      	callq	*%rax
     4ac:      	leaq	0x3c(%r14), %rdi
     4b0:      	movq	0x78(%rsp), %rcx
     4b5:      	addq	%r13, %rcx
     4b8:      	movl	$0x4, %edx
     4bd:      	movl	$0x4, %eax
     4c2:      	addq	0x78(%rsp), %r13
     4c7:      	movl	$0x4, %esi
     4cc:      	movq	%r13, %rdx
     4cf:      	callq	*%rax
     4d1:      	leaq	0x40(%r14), %rdi
     4d5:      	movq	0x80(%rsp), %rcx
     4dd:      	addq	$0x58, %rcx
     4e1:      	movl	$0x4, %edx
     4e6:      	movl	$0x4, %eax
     4eb:      	movq	0x80(%rsp), %rdx
     4f3:      	addq	$0x58, %rdx
     4f7:      	movl	$0x4, %esi
     4fc:      	callq	*%rax
     4fe:      	movq	$0x0, 0x28(%rsp)
     507:      	movq	$0x0, 0x8(%rsp)
     510:      	addq	$0xd00, %r15            # imm = 0xD00
     517:      	leaq	0x28(%rsp), %rdi
     51c:      	movl	$0x8, %ecx
     521:      	movl	$0x4, %eax
     526:      	movl	$0x8, %esi
     52b:      	movq	%r15, %rdx
     52e:      	callq	*%rax
     530:      	movl	$0x90, %edx
     535:      	movq	0x28(%rsp), %rcx
     53a:      	addq	%rdx, %rcx
     53d:      	leaq	0x8(%rsp), %rdi
     542:      	movl	$0x8, %esi
     547:      	movl	$0x4, %eax
     54c:      	addq	0x28(%rsp), %rdx
     551:      	movl	$0x8, %esi
     556:      	callq	*%rax
     558:      	leaq	0x44(%r14), %rdi
     55c:      	movq	0x8(%rsp), %rcx
     561:      	addq	%r12, %rcx
     564:      	movl	$0x4, %edx
     569:      	movl	$0x4, %eax
     56e:      	addq	0x8(%rsp), %r12
     573:      	movl	$0x4, %esi
     578:      	movq	%r12, %rdx
     57b:      	callq	*%rax
     57d:      	leaq	0x48(%r14), %r12
     581:      	leaq	0x40(%rsp), %rdi
     586:      	movl	$0x8, %ecx
     58b:      	movl	$0x4, %eax
     590:      	movl	$0x8, %esi
     595:      	movq	%r15, %rdx
     598:      	callq	*%rax
     59a:      	movq	0x40(%rsp), %r15
     59f:      	leaq	0x50(%r14), %rdi
     5a3:      	leaq	0x40(%r15), %rdx
     5a7:      	movl	$0x8, %ecx
     5ac:      	movl	$0x4, %eax
     5b1:      	movl	$0x8, %esi
     5b6:      	callq	*%rax
     5b8:      	movq	%r14, %rdi
     5bb:      	addq	$0x58, %rdi
     5bf:      	leaq	0x30(%r15), %rdx
     5c3:      	movl	$0x8, %ecx
     5c8:      	movl	$0x4, %eax
     5cd:      	movl	$0x8, %esi
     5d2:      	callq	*%rax
     5d4:      	addq	$0x38, %r15
     5d8:      	movl	$0x8, %ecx
     5dd:      	movl	$0x4, %eax
     5e2:      	movq	%r12, %rdi
     5e5:      	movl	$0x8, %esi
     5ea:      	movq	%r15, %rdx
     5ed:      	callq	*%rax
     5ef:      	movb	$0x0, 0x5f08(%r14)
     5f7:      	movb	$0x0, 0x1(%r14)
     5fc:      	movq	$0x0, 0x5ee8(%r14)
     607:      	movq	$0x0, 0x5ef0(%r14)
     612:      	movq	(%rip), %rsi            # 0x619 <generic_lsm_event+0x619>
     619:      	movl	$0x2, %ecx
     61e:      	movl	$0xc, %eax
     623:      	movq	%rbx, %rdi
     626:      	movl	$0x2, %edx
     62b:      	callq	*%rax
     62d:      	xorl	%eax, %eax
     62f:      	addq	$0x88, %rsp
     636:      	popq	%rbx
     637:      	popq	%r12
     639:      	popq	%r13
     63b:      	popq	%r14
     63d:      	popq	%r15
     63f:      	popq	%rbp
     640:      	retq
     641:      	movq	$-0x1, 0x18(%rsp)
     64a:      	leaq	0x18(%rsp), %rsi
     64f:      	movl	$0x1, %eax
     654:      	movq	%r15, %rdi
     657:      	callq	*%rax
     659:      	testq	%rax, %rax
     65c:      	je	0x62d <generic_lsm_event+0x62d>
     65e:      	movl	$0x1, 0x14(%rsp)
     666:      	movq	(%rip), %rdi            # 0x66d <generic_lsm_event+0x66d>
     66d:      	leaq	0x14(%rsp), %rsi
     672:      	movl	$0x1, %eax
     677:      	callq	*%rax
     679:      	testq	%rax, %rax
     67c:      	je	0x62d <generic_lsm_event+0x62d>
     67e:      	movq	%rax, %rdi
     681:      	leaq	0x8(%rsp), %rsi
     686:      	movl	$0x1, %eax
     68b:      	callq	*%rax
     68d:      	testq	%rax, %rax
     690:      	movq	%r12, %rax
     693:      	jne	0x62d <generic_lsm_event+0x62d>
     695:      	jmp	0x23b <generic_lsm_event+0x23b>
