
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/bcc/tcpconnect.native.o:	file format elf64-x86-64

Disassembly of section kprobe/tcp_v4_connect:

0000000000000000 <tcp_v4_connect>:
       0:      	subq	$0x18, %rsp
       4:      	movq	0x70(%rdi), %rax
       8:      	movq	%rax, 0x10(%rsp)
       d:      	callq	0x12 <tcp_v4_connect+0x12>
      12:      	movl	%eax, 0xc(%rsp)
      16:      	movq	(%rip), %rcx            # 0x1d <tcp_v4_connect+0x1d>
      1d:      	cmpl	$0x0, (%rcx)
      20:      	je	0x2c <tcp_v4_connect+0x2c>
      22:      	shrq	$0x20, %rax
      26:      	movl	(%rcx), %ecx
      28:      	cmpl	%eax, %ecx
      2a:      	jne	0x5d <tcp_v4_connect+0x5d>
      2c:      	callq	0x31 <tcp_v4_connect+0x31>
      31:      	movq	(%rip), %rcx            # 0x38 <tcp_v4_connect+0x38>
      38:      	movl	(%rcx), %edx
      3a:      	cmpl	$-0x1, %edx
      3d:      	je	0x45 <tcp_v4_connect+0x45>
      3f:      	movl	(%rcx), %ecx
      41:      	cmpl	%eax, %ecx
      43:      	jne	0x5d <tcp_v4_connect+0x5d>
      45:      	movq	(%rip), %rdi            # 0x4c <tcp_v4_connect+0x4c>
      4c:      	leaq	0xc(%rsp), %rsi
      51:      	leaq	0x10(%rsp), %rdx
      56:      	xorl	%ecx, %ecx
      58:      	callq	0x5d <tcp_v4_connect+0x5d>
      5d:      	xorl	%eax, %eax
      5f:      	addq	$0x18, %rsp
      63:      	retq

Disassembly of section kretprobe/tcp_v4_connect:

0000000000000000 <tcp_v4_connect_ret>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x58, %rsp
       e:      	movq	%rdi, %rbx
      11:      	movl	0x50(%rdi), %r14d
      15:      	callq	0x1a <tcp_v4_connect_ret+0x1a>
      1a:      	movq	%rax, %r15
      1d:      	movl	%r15d, 0xc(%rsp)
      22:      	movw	$0x0, 0x8(%rsp)
      29:      	movq	(%rip), %rdi            # 0x30 <tcp_v4_connect_ret+0x30>
      30:      	leaq	0xc(%rsp), %rsi
      35:      	callq	0x3a <tcp_v4_connect_ret+0x3a>
      3a:      	testq	%rax, %rax
      3d:      	je	0x55 <tcp_v4_connect_ret+0x55>
      3f:      	testq	%r14, %r14
      42:      	je	0x66 <tcp_v4_connect_ret+0x66>
      44:      	movq	(%rip), %rdi            # 0x4b <tcp_v4_connect_ret+0x4b>
      4b:      	leaq	0xc(%rsp), %rsi
      50:      	callq	0x55 <tcp_v4_connect_ret+0x55>
      55:      	xorl	%eax, %eax
      57:      	addq	$0x58, %rsp
      5b:      	popq	%rbx
      5c:      	popq	%r12
      5e:      	popq	%r13
      60:      	popq	%r14
      62:      	popq	%r15
      64:      	popq	%rbp
      65:      	retq
      66:      	movq	(%rax), %r14
      69:      	movq	(%rip), %rax            # 0x70 <tcp_v4_connect_ret+0x70>
      70:      	cmpb	$0x0, (%rax)
      73:      	je	0x88 <tcp_v4_connect_ret+0x88>
      75:      	leaq	0xe(%r14), %rdx
      79:      	leaq	0x8(%rsp), %rdi
      7e:      	movl	$0x2, %esi
      83:      	callq	0x88 <tcp_v4_connect_ret+0x88>
      88:      	leaq	0xc(%r14), %rdx
      8c:      	leaq	0xa(%rsp), %rdi
      91:      	movl	$0x2, %esi
      96:      	callq	0x9b <tcp_v4_connect_ret+0x9b>
      9b:      	movzwl	0xa(%rsp), %ebp
      a0:      	movq	(%rip), %rax            # 0xa7 <tcp_v4_connect_ret+0xa7>
      a7:      	cmpl	$0x0, (%rax)
      aa:      	je	0xe1 <tcp_v4_connect_ret+0xe1>
      ac:      	cmpl	$0x0, (%rax)
      af:      	jle	0x44 <tcp_v4_connect_ret+0x44>
      b1:      	movzwl	%bp, %ecx
      b4:      	xorl	%edx, %edx
      b6:      	movq	(%rip), %rsi            # 0xbd <tcp_v4_connect_ret+0xbd>
      bd:      	nopl	(%rax)
      c0:      	movl	(%rsi,%rdx,4), %edi
      c3:      	cmpl	%ecx, %edi
      c5:      	je	0xe1 <tcp_v4_connect_ret+0xe1>
      c7:      	movslq	(%rax), %rdi
      ca:      	cmpq	$0x3e, %rdx
      ce:      	ja	0x44 <tcp_v4_connect_ret+0x44>
      d4:      	incq	%rdx
      d7:      	cmpq	%rdi, %rdx
      da:      	jl	0xc0 <tcp_v4_connect_ret+0xc0>
      dc:      	jmp	0x44 <tcp_v4_connect_ret+0x44>
      e1:      	movq	(%rip), %rax            # 0xe8 <tcp_v4_connect_ret+0xe8>
      e8:      	cmpb	$0x0, (%rax)
      eb:      	movzwl	0x8(%rsp), %r12d
      f1:      	je	0x158 <tcp_v4_connect_ret+0x158>
      f3:      	movl	$0x0, 0x18(%rsp)
      fb:      	movq	$0x0, 0x10(%rsp)
     104:      	leaq	0x4(%r14), %rdx
     108:      	leaq	0x10(%rsp), %rbx
     10d:      	movq	%rbx, %rdi
     110:      	movl	$0x4, %esi
     115:      	callq	0x11a <tcp_v4_connect_ret+0x11a>
     11a:      	leaq	0x14(%rsp), %rdi
     11f:      	movl	$0x4, %esi
     124:      	movq	%r14, %rdx
     127:      	callq	0x12c <tcp_v4_connect_ret+0x12c>
     12c:      	movw	%r12w, 0x18(%rsp)
     132:      	movw	%bp, 0x1a(%rsp)
     137:      	movq	(%rip), %rdi            # 0x13e <tcp_v4_connect_ret+0x13e>
     13e:      	movq	%rbx, %rsi
     141:      	callq	0x146 <tcp_v4_connect_ret+0x146>
     146:      	testq	%rax, %rax
     149:      	je	0x23e <tcp_v4_connect_ret+0x23e>
     14f:      	lock
     150:      	incq	(%rax)
     153:      	jmp	0x44 <tcp_v4_connect_ret+0x44>
     158:      	shrq	$0x20, %r15
     15c:      	movq	$0x0, 0x48(%rsp)
     165:      	movq	$0x0, 0x50(%rsp)
     16e:      	movq	$0x0, 0x40(%rsp)
     177:      	movq	$0x0, 0x38(%rsp)
     180:      	movq	$0x0, 0x30(%rsp)
     189:      	movq	$0x0, 0x28(%rsp)
     192:      	movq	$0x0, 0x20(%rsp)
     19b:      	movq	$0x0, 0x18(%rsp)
     1a4:      	movq	$0x0, 0x10(%rsp)
     1ad:      	leaq	0x20(%rsp), %r13
     1b2:      	movl	$0x2, 0x48(%rsp)
     1ba:      	movl	%r15d, 0x4c(%rsp)
     1bf:      	callq	0x1c4 <tcp_v4_connect_ret+0x1c4>
     1c4:      	movl	%eax, 0x50(%rsp)
     1c8:      	callq	0x1cd <tcp_v4_connect_ret+0x1cd>
     1cd:      	movl	$0x3e8, %ecx            # imm = 0x3E8
     1d2:      	xorl	%edx, %edx
     1d4:      	divq	%rcx
     1d7:      	movq	%rax, 0x40(%rsp)
     1dc:      	leaq	0x4(%r14), %rdx
     1e0:      	leaq	0x10(%rsp), %r15
     1e5:      	movq	%r15, %rdi
     1e8:      	movl	$0x4, %esi
     1ed:      	callq	0x1f2 <tcp_v4_connect_ret+0x1f2>
     1f2:      	movq	%r13, %rdi
     1f5:      	movl	$0x4, %esi
     1fa:      	movq	%r14, %rdx
     1fd:      	callq	0x202 <tcp_v4_connect_ret+0x202>
     202:      	movw	%r12w, 0x54(%rsp)
     208:      	movw	%bp, 0x56(%rsp)
     20d:      	leaq	0x30(%rsp), %rdi
     212:      	movl	$0x10, %esi
     217:      	callq	0x21c <tcp_v4_connect_ret+0x21c>
     21c:      	movq	(%rip), %rsi            # 0x223 <tcp_v4_connect_ret+0x223>
     223:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     228:      	movl	$0x48, %r8d
     22e:      	movq	%rbx, %rdi
     231:      	movq	%r15, %rcx
     234:      	callq	0x239 <tcp_v4_connect_ret+0x239>
     239:      	jmp	0x44 <tcp_v4_connect_ret+0x44>
     23e:      	movq	(%rip), %rdi            # 0x245 <tcp_v4_connect_ret+0x245>
     245:      	leaq	(%rip), %rdx            # 0x24c <tcp_v4_connect_ret+0x24c>
     24c:      	leaq	0x10(%rsp), %rsi
     251:      	movl	$0x1, %ecx
     256:      	callq	0x25b <tcp_v4_connect_ret+0x25b>
     25b:      	testq	%rax, %rax
     25e:      	je	0x26a <tcp_v4_connect_ret+0x26a>
     260:      	cmpq	$-0x11, %rax
     264:      	jne	0x44 <tcp_v4_connect_ret+0x44>
     26a:      	movq	(%rip), %rdi            # 0x271 <tcp_v4_connect_ret+0x271>
     271:      	leaq	0x10(%rsp), %rsi
     276:      	callq	0x27b <tcp_v4_connect_ret+0x27b>
     27b:      	testq	%rax, %rax
     27e:      	jne	0x14f <tcp_v4_connect_ret+0x14f>
     284:      	jmp	0x44 <tcp_v4_connect_ret+0x44>

Disassembly of section kprobe/tcp_v6_connect:

0000000000000000 <tcp_v6_connect>:
       0:      	subq	$0x18, %rsp
       4:      	movq	0x70(%rdi), %rax
       8:      	movq	%rax, 0x10(%rsp)
       d:      	callq	0x12 <tcp_v6_connect+0x12>
      12:      	movl	%eax, 0xc(%rsp)
      16:      	movq	(%rip), %rcx            # 0x1d <tcp_v6_connect+0x1d>
      1d:      	cmpl	$0x0, (%rcx)
      20:      	je	0x2c <tcp_v6_connect+0x2c>
      22:      	shrq	$0x20, %rax
      26:      	movl	(%rcx), %ecx
      28:      	cmpl	%eax, %ecx
      2a:      	jne	0x5d <tcp_v6_connect+0x5d>
      2c:      	callq	0x31 <tcp_v6_connect+0x31>
      31:      	movq	(%rip), %rcx            # 0x38 <tcp_v6_connect+0x38>
      38:      	movl	(%rcx), %edx
      3a:      	cmpl	$-0x1, %edx
      3d:      	je	0x45 <tcp_v6_connect+0x45>
      3f:      	movl	(%rcx), %ecx
      41:      	cmpl	%eax, %ecx
      43:      	jne	0x5d <tcp_v6_connect+0x5d>
      45:      	movq	(%rip), %rdi            # 0x4c <tcp_v6_connect+0x4c>
      4c:      	leaq	0xc(%rsp), %rsi
      51:      	leaq	0x10(%rsp), %rdx
      56:      	xorl	%ecx, %ecx
      58:      	callq	0x5d <tcp_v6_connect+0x5d>
      5d:      	xorl	%eax, %eax
      5f:      	addq	$0x18, %rsp
      63:      	retq

Disassembly of section kretprobe/tcp_v6_connect:

0000000000000000 <tcp_v6_connect_ret>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x58, %rsp
       e:      	movq	%rdi, %rbx
      11:      	movl	0x50(%rdi), %r14d
      15:      	callq	0x1a <tcp_v6_connect_ret+0x1a>
      1a:      	movq	%rax, %r15
      1d:      	movl	%r15d, 0xc(%rsp)
      22:      	movw	$0x0, 0x8(%rsp)
      29:      	movq	(%rip), %rdi            # 0x30 <tcp_v6_connect_ret+0x30>
      30:      	leaq	0xc(%rsp), %rsi
      35:      	callq	0x3a <tcp_v6_connect_ret+0x3a>
      3a:      	testq	%rax, %rax
      3d:      	je	0x55 <tcp_v6_connect_ret+0x55>
      3f:      	testq	%r14, %r14
      42:      	je	0x66 <tcp_v6_connect_ret+0x66>
      44:      	movq	(%rip), %rdi            # 0x4b <tcp_v6_connect_ret+0x4b>
      4b:      	leaq	0xc(%rsp), %rsi
      50:      	callq	0x55 <tcp_v6_connect_ret+0x55>
      55:      	xorl	%eax, %eax
      57:      	addq	$0x58, %rsp
      5b:      	popq	%rbx
      5c:      	popq	%r12
      5e:      	popq	%r13
      60:      	popq	%r14
      62:      	popq	%r15
      64:      	popq	%rbp
      65:      	retq
      66:      	movq	(%rax), %r14
      69:      	movq	(%rip), %rax            # 0x70 <tcp_v6_connect_ret+0x70>
      70:      	cmpb	$0x0, (%rax)
      73:      	je	0x88 <tcp_v6_connect_ret+0x88>
      75:      	leaq	0xe(%r14), %rdx
      79:      	leaq	0x8(%rsp), %rdi
      7e:      	movl	$0x2, %esi
      83:      	callq	0x88 <tcp_v6_connect_ret+0x88>
      88:      	leaq	0xc(%r14), %rdx
      8c:      	leaq	0xa(%rsp), %rdi
      91:      	movl	$0x2, %esi
      96:      	callq	0x9b <tcp_v6_connect_ret+0x9b>
      9b:      	movzwl	0xa(%rsp), %ebp
      a0:      	movq	(%rip), %rax            # 0xa7 <tcp_v6_connect_ret+0xa7>
      a7:      	cmpl	$0x0, (%rax)
      aa:      	je	0xe1 <tcp_v6_connect_ret+0xe1>
      ac:      	cmpl	$0x0, (%rax)
      af:      	jle	0x44 <tcp_v6_connect_ret+0x44>
      b1:      	movzwl	%bp, %ecx
      b4:      	xorl	%edx, %edx
      b6:      	movq	(%rip), %rsi            # 0xbd <tcp_v6_connect_ret+0xbd>
      bd:      	nopl	(%rax)
      c0:      	movl	(%rsi,%rdx,4), %edi
      c3:      	cmpl	%ecx, %edi
      c5:      	je	0xe1 <tcp_v6_connect_ret+0xe1>
      c7:      	movslq	(%rax), %rdi
      ca:      	cmpq	$0x3e, %rdx
      ce:      	ja	0x44 <tcp_v6_connect_ret+0x44>
      d4:      	incq	%rdx
      d7:      	cmpq	%rdi, %rdx
      da:      	jl	0xc0 <tcp_v6_connect_ret+0xc0>
      dc:      	jmp	0x44 <tcp_v6_connect_ret+0x44>
      e1:      	movq	(%rip), %rax            # 0xe8 <tcp_v6_connect_ret+0xe8>
      e8:      	cmpb	$0x0, (%rax)
      eb:      	movzwl	0x8(%rsp), %r12d
      f1:      	je	0x17e <tcp_v6_connect_ret+0x17e>
      f7:      	movl	$0x0, 0x30(%rsp)
      ff:      	movq	$0x0, 0x28(%rsp)
     108:      	movq	$0x0, 0x20(%rsp)
     111:      	movq	$0x0, 0x18(%rsp)
     11a:      	movq	$0x0, 0x10(%rsp)
     123:      	leaq	0x20(%rsp), %rbx
     128:      	leaq	0x48(%r14), %rdx
     12c:      	leaq	0x10(%rsp), %r15
     131:      	movq	%r15, %rdi
     134:      	movl	$0x10, %esi
     139:      	callq	0x13e <tcp_v6_connect_ret+0x13e>
     13e:      	addq	$0x38, %r14
     142:      	movq	%rbx, %rdi
     145:      	movl	$0x10, %esi
     14a:      	movq	%r14, %rdx
     14d:      	callq	0x152 <tcp_v6_connect_ret+0x152>
     152:      	movw	%r12w, 0x30(%rsp)
     158:      	movw	%bp, 0x32(%rsp)
     15d:      	movq	(%rip), %rdi            # 0x164 <tcp_v6_connect_ret+0x164>
     164:      	movq	%r15, %rsi
     167:      	callq	0x16c <tcp_v6_connect_ret+0x16c>
     16c:      	testq	%rax, %rax
     16f:      	je	0x268 <tcp_v6_connect_ret+0x268>
     175:      	lock
     176:      	incq	(%rax)
     179:      	jmp	0x44 <tcp_v6_connect_ret+0x44>
     17e:      	shrq	$0x20, %r15
     182:      	movq	$0x0, 0x48(%rsp)
     18b:      	movq	$0x0, 0x50(%rsp)
     194:      	movq	$0x0, 0x40(%rsp)
     19d:      	movq	$0x0, 0x38(%rsp)
     1a6:      	movq	$0x0, 0x30(%rsp)
     1af:      	movq	$0x0, 0x28(%rsp)
     1b8:      	movq	$0x0, 0x20(%rsp)
     1c1:      	movq	$0x0, 0x18(%rsp)
     1ca:      	movq	$0x0, 0x10(%rsp)
     1d3:      	leaq	0x20(%rsp), %r13
     1d8:      	movl	$0xa, 0x48(%rsp)
     1e0:      	movl	%r15d, 0x4c(%rsp)
     1e5:      	callq	0x1ea <tcp_v6_connect_ret+0x1ea>
     1ea:      	movl	%eax, 0x50(%rsp)
     1ee:      	callq	0x1f3 <tcp_v6_connect_ret+0x1f3>
     1f3:      	movl	$0x3e8, %ecx            # imm = 0x3E8
     1f8:      	xorl	%edx, %edx
     1fa:      	divq	%rcx
     1fd:      	movq	%rax, 0x40(%rsp)
     202:      	leaq	0x48(%r14), %rdx
     206:      	leaq	0x10(%rsp), %r15
     20b:      	movq	%r15, %rdi
     20e:      	movl	$0x10, %esi
     213:      	callq	0x218 <tcp_v6_connect_ret+0x218>
     218:      	addq	$0x38, %r14
     21c:      	movq	%r13, %rdi
     21f:      	movl	$0x10, %esi
     224:      	movq	%r14, %rdx
     227:      	callq	0x22c <tcp_v6_connect_ret+0x22c>
     22c:      	movw	%r12w, 0x54(%rsp)
     232:      	movw	%bp, 0x56(%rsp)
     237:      	leaq	0x30(%rsp), %rdi
     23c:      	movl	$0x10, %esi
     241:      	callq	0x246 <tcp_v6_connect_ret+0x246>
     246:      	movq	(%rip), %rsi            # 0x24d <tcp_v6_connect_ret+0x24d>
     24d:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     252:      	movl	$0x48, %r8d
     258:      	movq	%rbx, %rdi
     25b:      	movq	%r15, %rcx
     25e:      	callq	0x263 <tcp_v6_connect_ret+0x263>
     263:      	jmp	0x44 <tcp_v6_connect_ret+0x44>
     268:      	movq	(%rip), %rdi            # 0x26f <tcp_v6_connect_ret+0x26f>
     26f:      	leaq	(%rip), %rdx            # 0x276 <tcp_v6_connect_ret+0x276>
     276:      	leaq	0x10(%rsp), %rsi
     27b:      	movl	$0x1, %ecx
     280:      	callq	0x285 <tcp_v6_connect_ret+0x285>
     285:      	testq	%rax, %rax
     288:      	je	0x294 <tcp_v6_connect_ret+0x294>
     28a:      	cmpq	$-0x11, %rax
     28e:      	jne	0x44 <tcp_v6_connect_ret+0x44>
     294:      	movq	(%rip), %rdi            # 0x29b <tcp_v6_connect_ret+0x29b>
     29b:      	leaq	0x10(%rsp), %rsi
     2a0:      	callq	0x2a5 <tcp_v6_connect_ret+0x2a5>
     2a5:      	testq	%rax, %rax
     2a8:      	jne	0x175 <tcp_v6_connect_ret+0x175>
     2ae:      	jmp	0x44 <tcp_v6_connect_ret+0x44>
