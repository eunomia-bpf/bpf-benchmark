
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_generic_tracepoint_v511.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <native_bpf_strncasestr>:
       0:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
       5:      	testq	%rdx, %rdx
       8:      	je	0x74 <native_bpf_strncasestr+0x74>
       a:      	pushq	%rbx
       b:      	xorl	%ecx, %ecx
       d:      	jmp	0x1b <native_bpf_strncasestr+0x1b>
       f:      	nop
      10:      	incq	%rcx
      13:      	incq	%rdi
      16:      	cmpq	%rdx, %rcx
      19:      	je	0x73 <native_bpf_strncasestr+0x73>
      1b:      	xorl	%r8d, %r8d
      1e:      	nop
      20:      	leaq	(%rcx,%r8), %r9
      24:      	cmpq	%rdx, %r9
      27:      	jae	0x10 <native_bpf_strncasestr+0x10>
      29:      	movsbl	(%rsi,%r8), %r9d
      2e:      	testl	%r9d, %r9d
      31:      	je	0x71 <native_bpf_strncasestr+0x71>
      33:      	movsbl	(%rdi,%r8), %r10d
      38:      	leal	-0x41(%r10), %r11d
      3c:      	movl	%r10d, %ebx
      3f:      	orl	$0x20, %ebx
      42:      	cmpl	$0x1a, %r11d
      46:      	cmovael	%r10d, %ebx
      4a:      	leal	-0x41(%r9), %r10d
      4e:      	movl	%r9d, %r11d
      51:      	orl	$0x20, %r11d
      55:      	cmpl	$0x1a, %r10d
      59:      	cmovael	%r9d, %r11d
      5d:      	cmpl	%r11d, %ebx
      60:      	jne	0x10 <native_bpf_strncasestr+0x10>
      62:      	leaq	0x1(%r8), %r9
      66:      	cmpq	$0x63, %r8
      6a:      	movq	%r9, %r8
      6d:      	jb	0x20 <native_bpf_strncasestr+0x20>
      6f:      	jmp	0x10 <native_bpf_strncasestr+0x10>
      71:      	movl	%ecx, %eax
      73:      	popq	%rbx
      74:      	retq

Disassembly of section tracepoint:

0000000000000000 <generic_tracepoint_process_event>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x108, %rsp            # imm = 0x108
      11:      	movq	%rdi, %rbx
      14:      	movl	$0x0, 0xe4(%rsp)
      1f:      	movq	(%rip), %rdi            # 0x26 <generic_tracepoint_process_event+0x26>
      26:      	leaq	0xe4(%rsp), %rsi
      2e:      	movl	$0x1, %eax
      33:      	callq	*%rax
      35:      	testq	%rax, %rax
      38:      	je	0x30c4 <generic_tracepoint_process_event+0x30c4>
      3e:      	movq	%rax, %r14
      41:      	movl	0x5efc(%rax), %r12d
      48:      	movl	0x4(%rax), %ebp
      4b:      	cmpq	$0x2327, %rbp           # imm = 0x2327
      52:      	ja	0x96a <generic_tracepoint_process_event+0x96a>
      58:      	movl	$0x0, 0xe8(%rsp)
      63:      	movq	(%rip), %rdi            # 0x6a <generic_tracepoint_process_event+0x6a>
      6a:      	leaq	0xe8(%rsp), %rsi
      72:      	movl	$0x1, %eax
      77:      	callq	*%rax
      79:      	testq	%rax, %rax
      7c:      	je	0x96a <generic_tracepoint_process_event+0x96a>
      82:      	movq	%rax, %r15
      85:      	leaq	0x5ef8(%rax), %rsi
      8c:      	movq	(%rip), %rdi            # 0x93 <generic_tracepoint_process_event+0x93>
      93:      	movl	$0x1, %eax
      98:      	callq	*%rax
      9a:      	cmpl	$0x4, %r12d
      9e:      	jg	0x96a <generic_tracepoint_process_event+0x96a>
      a4:      	testq	%rax, %rax
      a7:      	je	0x96a <generic_tracepoint_process_event+0x96a>
      ad:      	movq	%rbp, 0x50(%rsp)
      b2:      	movq	%r12, 0xd0(%rsp)
      ba:      	movl	%r12d, %edx
      bd:      	andl	$0x7, %edx
      c0:      	movl	%edx, %ecx
      c2:      	movl	0x4(%rax,%rcx,4), %r12d
      c7:      	movslq	0x18(%rax,%rcx,4), %r13
      cc:      	movl	$0x0, 0x5ea0(%r15,%rcx,4)
      d8:      	movq	0x5e50(%r15,%rcx,8), %rcx
      e0:      	movq	%rcx, (%rsp)
      e4:      	testl	$0x100, %r13d           # imm = 0x100
      eb:      	movq	%rdx, 0x8(%rsp)
      f0:      	jne	0x401 <generic_tracepoint_process_event+0x401>
      f6:      	cmpl	$0x4, %edx
      f9:      	ja	0x409 <generic_tracepoint_process_event+0x409>
      ff:      	leaq	(%rdx,%rdx,4), %rdx
     103:      	shll	$0x4, %edx
     106:      	cmpw	$0x0, 0x76(%rax,%rdx)
     10c:      	je	0x409 <generic_tracepoint_process_event+0x409>
     112:      	leaq	(%rax,%rdx), %rsi
     116:      	addq	$0x70, %rsi
     11a:      	movq	(%rip), %rax            # 0x121 <generic_tracepoint_process_event+0x121>
     121:      	movzbl	(%rax), %edx
     124:      	movl	(%rsi), %eax
     126:      	addq	%rax, %rcx
     129:      	movq	%rcx, (%rsp)
     12d:      	movzwl	0x4(%rsi), %eax
     131:      	testb	%dl, %dl
     133:      	je	0x5a2 <generic_tracepoint_process_event+0x5a2>
     139:      	testw	%ax, %ax
     13c:      	je	0x16e <generic_tracepoint_process_event+0x16e>
     13e:      	movq	%rsp, %rdi
     141:      	movl	$0x8, %edx
     146:      	movl	$0x4, %eax
     14b:      	movq	(%rsp), %rdx
     14f:      	movq	%rsi, %rbp
     152:      	movl	$0x8, %esi
     157:      	callq	*%rax
     159:      	movq	%rbp, %rsi
     15c:      	movq	0x8(%rsp), %rcx
     161:      	movl	$0x1, %ebp
     166:      	testl	%eax, %eax
     168:      	js	0x88a <generic_tracepoint_process_event+0x88a>
     16e:      	cmpw	$0x0, 0xe(%rsi)
     173:      	je	0x409 <generic_tracepoint_process_event+0x409>
     179:      	movl	0x8(%rsi), %ecx
     17c:      	addq	(%rsp), %rcx
     180:      	movq	%rcx, (%rsp)
     184:      	cmpw	$0x0, 0xc(%rsi)
     189:      	je	0x1bb <generic_tracepoint_process_event+0x1bb>
     18b:      	movq	%rsp, %rdi
     18e:      	movl	$0x8, %edx
     193:      	movl	$0x4, %eax
     198:      	movq	(%rsp), %rdx
     19c:      	movq	%rsi, %rbp
     19f:      	movl	$0x8, %esi
     1a4:      	callq	*%rax
     1a6:      	movq	%rbp, %rsi
     1a9:      	movq	0x8(%rsp), %rcx
     1ae:      	movl	$0x2, %ebp
     1b3:      	testl	%eax, %eax
     1b5:      	js	0x88a <generic_tracepoint_process_event+0x88a>
     1bb:      	cmpw	$0x0, 0x16(%rsi)
     1c0:      	je	0x409 <generic_tracepoint_process_event+0x409>
     1c6:      	movl	0x10(%rsi), %ecx
     1c9:      	addq	(%rsp), %rcx
     1cd:      	movq	%rcx, (%rsp)
     1d1:      	cmpw	$0x0, 0x14(%rsi)
     1d6:      	je	0x208 <generic_tracepoint_process_event+0x208>
     1d8:      	movq	%rsp, %rdi
     1db:      	movl	$0x8, %edx
     1e0:      	movl	$0x4, %eax
     1e5:      	movq	(%rsp), %rdx
     1e9:      	movq	%rsi, %rbp
     1ec:      	movl	$0x8, %esi
     1f1:      	callq	*%rax
     1f3:      	movq	%rbp, %rsi
     1f6:      	movq	0x8(%rsp), %rcx
     1fb:      	movl	$0x3, %ebp
     200:      	testl	%eax, %eax
     202:      	js	0x88a <generic_tracepoint_process_event+0x88a>
     208:      	cmpw	$0x0, 0x1e(%rsi)
     20d:      	je	0x409 <generic_tracepoint_process_event+0x409>
     213:      	movl	0x18(%rsi), %ecx
     216:      	addq	(%rsp), %rcx
     21a:      	movq	%rcx, (%rsp)
     21e:      	cmpw	$0x0, 0x1c(%rsi)
     223:      	je	0x255 <generic_tracepoint_process_event+0x255>
     225:      	movq	%rsp, %rdi
     228:      	movl	$0x8, %edx
     22d:      	movl	$0x4, %eax
     232:      	movq	(%rsp), %rdx
     236:      	movq	%rsi, %rbp
     239:      	movl	$0x8, %esi
     23e:      	callq	*%rax
     240:      	movq	%rbp, %rsi
     243:      	movq	0x8(%rsp), %rcx
     248:      	movl	$0x4, %ebp
     24d:      	testl	%eax, %eax
     24f:      	js	0x88a <generic_tracepoint_process_event+0x88a>
     255:      	cmpw	$0x0, 0x26(%rsi)
     25a:      	je	0x409 <generic_tracepoint_process_event+0x409>
     260:      	movl	0x20(%rsi), %ecx
     263:      	addq	(%rsp), %rcx
     267:      	movq	%rcx, (%rsp)
     26b:      	cmpw	$0x0, 0x24(%rsi)
     270:      	je	0x2a2 <generic_tracepoint_process_event+0x2a2>
     272:      	movq	%rsp, %rdi
     275:      	movl	$0x8, %edx
     27a:      	movl	$0x4, %eax
     27f:      	movq	(%rsp), %rdx
     283:      	movq	%rsi, %rbp
     286:      	movl	$0x8, %esi
     28b:      	callq	*%rax
     28d:      	movq	%rbp, %rsi
     290:      	movq	0x8(%rsp), %rcx
     295:      	movl	$0x5, %ebp
     29a:      	testl	%eax, %eax
     29c:      	js	0x88a <generic_tracepoint_process_event+0x88a>
     2a2:      	cmpw	$0x0, 0x2e(%rsi)
     2a7:      	je	0x409 <generic_tracepoint_process_event+0x409>
     2ad:      	movl	0x28(%rsi), %ecx
     2b0:      	addq	(%rsp), %rcx
     2b4:      	movq	%rcx, (%rsp)
     2b8:      	cmpw	$0x0, 0x2c(%rsi)
     2bd:      	je	0x2ef <generic_tracepoint_process_event+0x2ef>
     2bf:      	movq	%rsp, %rdi
     2c2:      	movl	$0x8, %edx
     2c7:      	movl	$0x4, %eax
     2cc:      	movq	(%rsp), %rdx
     2d0:      	movq	%rsi, %rbp
     2d3:      	movl	$0x8, %esi
     2d8:      	callq	*%rax
     2da:      	movq	%rbp, %rsi
     2dd:      	movq	0x8(%rsp), %rcx
     2e2:      	movl	$0x6, %ebp
     2e7:      	testl	%eax, %eax
     2e9:      	js	0x88a <generic_tracepoint_process_event+0x88a>
     2ef:      	cmpw	$0x0, 0x36(%rsi)
     2f4:      	je	0x409 <generic_tracepoint_process_event+0x409>
     2fa:      	movl	0x30(%rsi), %ecx
     2fd:      	addq	(%rsp), %rcx
     301:      	movq	%rcx, (%rsp)
     305:      	cmpw	$0x0, 0x34(%rsi)
     30a:      	je	0x33c <generic_tracepoint_process_event+0x33c>
     30c:      	movq	%rsp, %rdi
     30f:      	movl	$0x8, %edx
     314:      	movl	$0x4, %eax
     319:      	movq	(%rsp), %rdx
     31d:      	movq	%rsi, %rbp
     320:      	movl	$0x8, %esi
     325:      	callq	*%rax
     327:      	movq	%rbp, %rsi
     32a:      	movq	0x8(%rsp), %rcx
     32f:      	movl	$0x7, %ebp
     334:      	testl	%eax, %eax
     336:      	js	0x88a <generic_tracepoint_process_event+0x88a>
     33c:      	cmpw	$0x0, 0x3e(%rsi)
     341:      	je	0x409 <generic_tracepoint_process_event+0x409>
     347:      	movl	0x38(%rsi), %ecx
     34a:      	addq	(%rsp), %rcx
     34e:      	movq	%rcx, (%rsp)
     352:      	cmpw	$0x0, 0x3c(%rsi)
     357:      	je	0x38d <generic_tracepoint_process_event+0x38d>
     359:      	movq	%rsp, %rdi
     35c:      	movl	$0x8, %edx
     361:      	movl	$0x4, %eax
     366:      	movq	(%rsp), %rdx
     36a:      	movl	$0x8, %ebp
     36f:      	movq	%rsi, 0x18(%rsp)
     374:      	movl	$0x8, %esi
     379:      	callq	*%rax
     37b:      	movq	0x18(%rsp), %rsi
     380:      	movq	0x8(%rsp), %rcx
     385:      	testl	%eax, %eax
     387:      	js	0x88a <generic_tracepoint_process_event+0x88a>
     38d:      	cmpw	$0x0, 0x46(%rsi)
     392:      	je	0x409 <generic_tracepoint_process_event+0x409>
     394:      	movl	0x40(%rsi), %ecx
     397:      	addq	(%rsp), %rcx
     39b:      	movq	%rcx, (%rsp)
     39f:      	cmpw	$0x0, 0x44(%rsi)
     3a4:      	je	0x3d6 <generic_tracepoint_process_event+0x3d6>
     3a6:      	movq	%rsp, %rdi
     3a9:      	movl	$0x8, %edx
     3ae:      	movl	$0x4, %eax
     3b3:      	movq	(%rsp), %rdx
     3b7:      	movq	%rsi, %rbp
     3ba:      	movl	$0x8, %esi
     3bf:      	callq	*%rax
     3c1:      	movq	%rbp, %rsi
     3c4:      	movq	0x8(%rsp), %rcx
     3c9:      	movl	$0x9, %ebp
     3ce:      	testl	%eax, %eax
     3d0:      	js	0x88a <generic_tracepoint_process_event+0x88a>
     3d6:      	cmpw	$0x0, 0x4e(%rsi)
     3db:      	je	0x409 <generic_tracepoint_process_event+0x409>
     3dd:      	movl	0x48(%rsi), %ecx
     3e0:      	addq	(%rsp), %rcx
     3e4:      	movq	%rcx, (%rsp)
     3e8:      	cmpw	$0x0, 0x4c(%rsi)
     3ed:      	je	0x409 <generic_tracepoint_process_event+0x409>
     3ef:      	movq	%rsp, %rdi
     3f2:      	movl	$0x8, %edx
     3f7:      	movl	$0x4, %eax
     3fc:      	jmp	0x86d <generic_tracepoint_process_event+0x86d>
     401:      	movq	$0x0, (%rsp)
     409:      	movl	$0x1000, %r15d          # imm = 0x1000
     40f:      	movq	(%rsp), %rax
     413:      	movq	%rax, 0x18(%rsp)
     418:      	cmpl	$0x15, %r12d
     41c:      	jg	0x45a <generic_tracepoint_process_event+0x45a>
     41e:      	cmpl	$0xb, %r12d
     422:      	jg	0x496 <generic_tracepoint_process_event+0x496>
     424:      	cmpl	$0x5, %r12d
     428:      	movq	0x50(%rsp), %rbp
     42d:      	jg	0x52b <generic_tracepoint_process_event+0x52b>
     433:      	cmpl	$0x3, %r12d
     437:      	jg	0x8c1 <generic_tracepoint_process_event+0x8c1>
     43d:      	leal	-0x2(%r12), %eax
     442:      	cmpl	$0x2, %eax
     445:      	jb	0x58c <generic_tracepoint_process_event+0x58c>
     44b:      	cmpl	$0x1, %r12d
     44f:      	je	0x58c <generic_tracepoint_process_event+0x58c>
     455:      	jmp	0x8f3 <generic_tracepoint_process_event+0x8f3>
     45a:      	cmpl	$0x20, %r12d
     45e:      	jle	0x4c6 <generic_tracepoint_process_event+0x4c6>
     460:      	cmpl	$0x27, %r12d
     464:      	movq	0x50(%rsp), %rbp
     469:      	jg	0x4f8 <generic_tracepoint_process_event+0x4f8>
     46f:      	leal	-0x21(%r12), %eax
     474:      	cmpl	$0x4, %eax
     477:      	jb	0x8d5 <generic_tracepoint_process_event+0x8d5>
     47d:      	cmpl	$0x25, %r12d
     481:      	je	0x8f6 <generic_tracepoint_process_event+0x8f6>
     487:      	cmpl	$0x27, %r12d
     48b:      	je	0x597 <generic_tracepoint_process_event+0x597>
     491:      	jmp	0x8f3 <generic_tracepoint_process_event+0x8f3>
     496:      	cmpl	$0x11, %r12d
     49a:      	movq	0x50(%rsp), %rbp
     49f:      	jg	0x558 <generic_tracepoint_process_event+0x558>
     4a5:      	leal	-0xf(%r12), %eax
     4aa:      	cmpl	$0x3, %eax
     4ad:      	jb	0x8f6 <generic_tracepoint_process_event+0x8f6>
     4b3:      	leal	-0xc(%r12), %eax
     4b8:      	cmpl	$0x2, %eax
     4bb:      	jb	0x58c <generic_tracepoint_process_event+0x58c>
     4c1:      	jmp	0x8f3 <generic_tracepoint_process_event+0x8f3>
     4c6:      	cmpl	$0x1a, %r12d
     4ca:      	movq	0x50(%rsp), %rbp
     4cf:      	jg	0x57e <generic_tracepoint_process_event+0x57e>
     4d5:      	cmpl	$0x16, %r12d
     4d9:      	je	0x597 <generic_tracepoint_process_event+0x597>
     4df:      	cmpl	$0x17, %r12d
     4e3:      	je	0x8d5 <generic_tracepoint_process_event+0x8d5>
     4e9:      	cmpl	$0x1a, %r12d
     4ed:      	je	0x8eb <generic_tracepoint_process_event+0x8eb>
     4f3:      	jmp	0x8f3 <generic_tracepoint_process_event+0x8f3>
     4f8:      	cmpl	$0x29, %r12d
     4fc:      	jle	0x8ab <generic_tracepoint_process_event+0x8ab>
     502:      	cmpl	$0x2a, %r12d
     506:      	je	0x8f6 <generic_tracepoint_process_event+0x8f6>
     50c:      	cmpl	$0x2b, %r12d
     510:      	je	0x8b9 <generic_tracepoint_process_event+0x8b9>
     516:      	cmpl	$0x2c, %r12d
     51a:      	jne	0x8f3 <generic_tracepoint_process_event+0x8f3>
     520:      	movl	$0x70, %r15d
     526:      	jmp	0x8f6 <generic_tracepoint_process_event+0x8f6>
     52b:      	cmpl	$0x9, %r12d
     52f:      	jg	0x8d5 <generic_tracepoint_process_event+0x8d5>
     535:      	cmpl	$0x6, %r12d
     539:      	je	0x8f6 <generic_tracepoint_process_event+0x8f6>
     53f:      	cmpl	$0x7, %r12d
     543:      	je	0x8cd <generic_tracepoint_process_event+0x8cd>
     549:      	cmpl	$0x8, %r12d
     54d:      	je	0x8eb <generic_tracepoint_process_event+0x8eb>
     553:      	jmp	0x8f3 <generic_tracepoint_process_event+0x8f3>
     558:      	cmpl	$0x13, %r12d
     55c:      	jg	0x897 <generic_tracepoint_process_event+0x897>
     562:      	movq	%r13, %r15
     565:      	cmpl	$0x12, %r12d
     569:      	je	0x8f6 <generic_tracepoint_process_event+0x8f6>
     56f:      	cmpl	$0x13, %r12d
     573:      	je	0x8b9 <generic_tracepoint_process_event+0x8b9>
     579:      	jmp	0x8f3 <generic_tracepoint_process_event+0x8f3>
     57e:      	leal	-0x1d(%r12), %eax
     583:      	cmpl	$0x4, %eax
     586:      	jae	0x8e5 <generic_tracepoint_process_event+0x8e5>
     58c:      	movl	$0x4, %r15d
     592:      	jmp	0x8f6 <generic_tracepoint_process_event+0x8f6>
     597:      	movl	$0x10, %r15d
     59d:      	jmp	0x8f6 <generic_tracepoint_process_event+0x8f6>
     5a2:      	testw	%ax, %ax
     5a5:      	je	0x5d7 <generic_tracepoint_process_event+0x5d7>
     5a7:      	movq	%rsp, %rdi
     5aa:      	movl	$0x8, %edx
     5af:      	movl	$0x4, %eax
     5b4:      	movq	(%rsp), %rdx
     5b8:      	movq	%rsi, %rbp
     5bb:      	movl	$0x8, %esi
     5c0:      	callq	*%rax
     5c2:      	movq	%rbp, %rsi
     5c5:      	movq	0x8(%rsp), %rcx
     5ca:      	movl	$0x1, %ebp
     5cf:      	testl	%eax, %eax
     5d1:      	js	0x88a <generic_tracepoint_process_event+0x88a>
     5d7:      	cmpw	$0x0, 0xe(%rsi)
     5dc:      	je	0x409 <generic_tracepoint_process_event+0x409>
     5e2:      	movl	0x8(%rsi), %ecx
     5e5:      	addq	(%rsp), %rcx
     5e9:      	movq	%rcx, (%rsp)
     5ed:      	cmpw	$0x0, 0xc(%rsi)
     5f2:      	je	0x624 <generic_tracepoint_process_event+0x624>
     5f4:      	movq	%rsp, %rdi
     5f7:      	movl	$0x8, %edx
     5fc:      	movl	$0x4, %eax
     601:      	movq	(%rsp), %rdx
     605:      	movq	%rsi, %rbp
     608:      	movl	$0x8, %esi
     60d:      	callq	*%rax
     60f:      	movq	%rbp, %rsi
     612:      	movq	0x8(%rsp), %rcx
     617:      	movl	$0x2, %ebp
     61c:      	testl	%eax, %eax
     61e:      	js	0x88a <generic_tracepoint_process_event+0x88a>
     624:      	cmpw	$0x0, 0x16(%rsi)
     629:      	je	0x409 <generic_tracepoint_process_event+0x409>
     62f:      	movl	0x10(%rsi), %ecx
     632:      	addq	(%rsp), %rcx
     636:      	movq	%rcx, (%rsp)
     63a:      	cmpw	$0x0, 0x14(%rsi)
     63f:      	je	0x671 <generic_tracepoint_process_event+0x671>
     641:      	movq	%rsp, %rdi
     644:      	movl	$0x8, %edx
     649:      	movl	$0x4, %eax
     64e:      	movq	(%rsp), %rdx
     652:      	movq	%rsi, %rbp
     655:      	movl	$0x8, %esi
     65a:      	callq	*%rax
     65c:      	movq	%rbp, %rsi
     65f:      	movq	0x8(%rsp), %rcx
     664:      	movl	$0x3, %ebp
     669:      	testl	%eax, %eax
     66b:      	js	0x88a <generic_tracepoint_process_event+0x88a>
     671:      	cmpw	$0x0, 0x1e(%rsi)
     676:      	je	0x409 <generic_tracepoint_process_event+0x409>
     67c:      	movl	0x18(%rsi), %ecx
     67f:      	addq	(%rsp), %rcx
     683:      	movq	%rcx, (%rsp)
     687:      	cmpw	$0x0, 0x1c(%rsi)
     68c:      	je	0x6be <generic_tracepoint_process_event+0x6be>
     68e:      	movq	%rsp, %rdi
     691:      	movl	$0x8, %edx
     696:      	movl	$0x4, %eax
     69b:      	movq	(%rsp), %rdx
     69f:      	movq	%rsi, %rbp
     6a2:      	movl	$0x8, %esi
     6a7:      	callq	*%rax
     6a9:      	movq	%rbp, %rsi
     6ac:      	movq	0x8(%rsp), %rcx
     6b1:      	movl	$0x4, %ebp
     6b6:      	testl	%eax, %eax
     6b8:      	js	0x88a <generic_tracepoint_process_event+0x88a>
     6be:      	cmpw	$0x0, 0x26(%rsi)
     6c3:      	je	0x409 <generic_tracepoint_process_event+0x409>
     6c9:      	movl	0x20(%rsi), %ecx
     6cc:      	addq	(%rsp), %rcx
     6d0:      	movq	%rcx, (%rsp)
     6d4:      	cmpw	$0x0, 0x24(%rsi)
     6d9:      	je	0x70b <generic_tracepoint_process_event+0x70b>
     6db:      	movq	%rsp, %rdi
     6de:      	movl	$0x8, %edx
     6e3:      	movl	$0x4, %eax
     6e8:      	movq	(%rsp), %rdx
     6ec:      	movq	%rsi, %rbp
     6ef:      	movl	$0x8, %esi
     6f4:      	callq	*%rax
     6f6:      	movq	%rbp, %rsi
     6f9:      	movq	0x8(%rsp), %rcx
     6fe:      	movl	$0x5, %ebp
     703:      	testl	%eax, %eax
     705:      	js	0x88a <generic_tracepoint_process_event+0x88a>
     70b:      	cmpw	$0x0, 0x2e(%rsi)
     710:      	je	0x409 <generic_tracepoint_process_event+0x409>
     716:      	movl	0x28(%rsi), %ecx
     719:      	addq	(%rsp), %rcx
     71d:      	movq	%rcx, (%rsp)
     721:      	cmpw	$0x0, 0x2c(%rsi)
     726:      	je	0x758 <generic_tracepoint_process_event+0x758>
     728:      	movq	%rsp, %rdi
     72b:      	movl	$0x8, %edx
     730:      	movl	$0x4, %eax
     735:      	movq	(%rsp), %rdx
     739:      	movq	%rsi, %rbp
     73c:      	movl	$0x8, %esi
     741:      	callq	*%rax
     743:      	movq	%rbp, %rsi
     746:      	movq	0x8(%rsp), %rcx
     74b:      	movl	$0x6, %ebp
     750:      	testl	%eax, %eax
     752:      	js	0x88a <generic_tracepoint_process_event+0x88a>
     758:      	cmpw	$0x0, 0x36(%rsi)
     75d:      	je	0x409 <generic_tracepoint_process_event+0x409>
     763:      	movl	0x30(%rsi), %ecx
     766:      	addq	(%rsp), %rcx
     76a:      	movq	%rcx, (%rsp)
     76e:      	cmpw	$0x0, 0x34(%rsi)
     773:      	je	0x7a5 <generic_tracepoint_process_event+0x7a5>
     775:      	movq	%rsp, %rdi
     778:      	movl	$0x8, %edx
     77d:      	movl	$0x4, %eax
     782:      	movq	(%rsp), %rdx
     786:      	movq	%rsi, %rbp
     789:      	movl	$0x8, %esi
     78e:      	callq	*%rax
     790:      	movq	%rbp, %rsi
     793:      	movq	0x8(%rsp), %rcx
     798:      	movl	$0x7, %ebp
     79d:      	testl	%eax, %eax
     79f:      	js	0x88a <generic_tracepoint_process_event+0x88a>
     7a5:      	cmpw	$0x0, 0x3e(%rsi)
     7aa:      	je	0x409 <generic_tracepoint_process_event+0x409>
     7b0:      	movl	0x38(%rsi), %ecx
     7b3:      	addq	(%rsp), %rcx
     7b7:      	movq	%rcx, (%rsp)
     7bb:      	cmpw	$0x0, 0x3c(%rsi)
     7c0:      	je	0x7f6 <generic_tracepoint_process_event+0x7f6>
     7c2:      	movq	%rsp, %rdi
     7c5:      	movl	$0x8, %edx
     7ca:      	movl	$0x4, %eax
     7cf:      	movq	(%rsp), %rdx
     7d3:      	movl	$0x8, %ebp
     7d8:      	movq	%rsi, 0x18(%rsp)
     7dd:      	movl	$0x8, %esi
     7e2:      	callq	*%rax
     7e4:      	movq	0x18(%rsp), %rsi
     7e9:      	movq	0x8(%rsp), %rcx
     7ee:      	testl	%eax, %eax
     7f0:      	js	0x88a <generic_tracepoint_process_event+0x88a>
     7f6:      	cmpw	$0x0, 0x46(%rsi)
     7fb:      	je	0x409 <generic_tracepoint_process_event+0x409>
     801:      	movl	0x40(%rsi), %ecx
     804:      	addq	(%rsp), %rcx
     808:      	movq	%rcx, (%rsp)
     80c:      	cmpw	$0x0, 0x44(%rsi)
     811:      	je	0x83f <generic_tracepoint_process_event+0x83f>
     813:      	movq	%rsp, %rdi
     816:      	movl	$0x8, %edx
     81b:      	movl	$0x4, %eax
     820:      	movq	(%rsp), %rdx
     824:      	movq	%rsi, %rbp
     827:      	movl	$0x8, %esi
     82c:      	callq	*%rax
     82e:      	movq	%rbp, %rsi
     831:      	movq	0x8(%rsp), %rcx
     836:      	movl	$0x9, %ebp
     83b:      	testl	%eax, %eax
     83d:      	js	0x88a <generic_tracepoint_process_event+0x88a>
     83f:      	cmpw	$0x0, 0x4e(%rsi)
     844:      	je	0x409 <generic_tracepoint_process_event+0x409>
     84a:      	movl	0x48(%rsi), %ecx
     84d:      	addq	(%rsp), %rcx
     851:      	movq	%rcx, (%rsp)
     855:      	cmpw	$0x0, 0x4c(%rsi)
     85a:      	je	0x409 <generic_tracepoint_process_event+0x409>
     860:      	movq	%rsp, %rdi
     863:      	movl	$0x8, %edx
     868:      	movl	$0x4, %eax
     86d:      	movq	(%rsp), %rdx
     871:      	movl	$0x8, %esi
     876:      	callq	*%rax
     878:      	movq	0x8(%rsp), %rcx
     87d:      	movl	$0xa, %ebp
     882:      	testl	%eax, %eax
     884:      	jns	0x409 <generic_tracepoint_process_event+0x409>
     88a:      	movl	%ebp, 0x5ea0(%r15,%rcx,4)
     892:      	jmp	0x409 <generic_tracepoint_process_event+0x409>
     897:      	cmpl	$0x14, %r12d
     89b:      	je	0x8dd <generic_tracepoint_process_event+0x8dd>
     89d:      	cmpl	$0x15, %r12d
     8a1:      	jne	0x8f3 <generic_tracepoint_process_event+0x8f3>
     8a3:      	movl	$0x20, %r15d
     8a9:      	jmp	0x8f6 <generic_tracepoint_process_event+0x8f6>
     8ab:      	cmpl	$0x28, %r12d
     8af:      	je	0x8b9 <generic_tracepoint_process_event+0x8b9>
     8b1:      	cmpl	$0x29, %r12d
     8b5:      	je	0x8cd <generic_tracepoint_process_event+0x8cd>
     8b7:      	jmp	0x8f3 <generic_tracepoint_process_event+0x8f3>
     8b9:      	movl	$0x18, %r15d
     8bf:      	jmp	0x8f6 <generic_tracepoint_process_event+0x8f6>
     8c1:      	cmpl	$0x4, %r12d
     8c5:      	je	0x8d5 <generic_tracepoint_process_event+0x8d5>
     8c7:      	cmpl	$0x5, %r12d
     8cb:      	jne	0x8f3 <generic_tracepoint_process_event+0x8f3>
     8cd:      	movl	$0x40, %r15d
     8d3:      	jmp	0x8f6 <generic_tracepoint_process_event+0x8f6>
     8d5:      	movl	$0x8, %r15d
     8db:      	jmp	0x8f6 <generic_tracepoint_process_event+0x8f6>
     8dd:      	movl	$0x98, %r15d
     8e3:      	jmp	0x8f6 <generic_tracepoint_process_event+0x8f6>
     8e5:      	cmpl	$0x1b, %r12d
     8e9:      	jne	0x8f3 <generic_tracepoint_process_event+0x8f3>
     8eb:      	movl	$0x50, %r15d
     8f1:      	jmp	0x8f6 <generic_tracepoint_process_event+0x8f6>
     8f3:      	xorl	%r15d, %r15d
     8f6:      	movl	$0x0, 0xec(%rsp)
     901:      	movq	(%rip), %rdi            # 0x908 <generic_tracepoint_process_event+0x908>
     908:      	leaq	0xec(%rsp), %rsi
     910:      	movl	$0x1, %eax
     915:      	callq	*%rax
     917:      	testq	%rax, %rax
     91a:      	je	0x962 <generic_tracepoint_process_event+0x962>
     91c:      	movl	$0x3ffb, %ecx           # imm = 0x3FFB
     921:      	subq	%r15, %rcx
     924:      	cmpq	%rbp, %rcx
     927:      	jbe	0x962 <generic_tracepoint_process_event+0x962>
     929:      	movq	0x8(%rsp), %rdx
     92e:      	movl	0x5ea0(%rax,%rdx,4), %ecx
     935:      	movl	%ecx, 0x90(%rax,%rbp)
     93c:      	leaq	0x4(%rbp), %r15
     940:      	movq	%r15, 0x5e78(%rax,%rdx,8)
     948:      	movl	$0x4, %edx
     94d:      	testl	%ecx, %ecx
     94f:      	je	0x9f8 <generic_tracepoint_process_event+0x9f8>
     955:      	movq	0xd0(%rsp), %r12
     95d:      	jmp	0x308c <generic_tracepoint_process_event+0x308c>
     962:      	movq	0xd0(%rsp), %r12
     96a:      	movl	%ebp, 0x4(%r14)
     96e:      	cmpl	$0x3, %r12d
     972:      	jg	0x309e <generic_tracepoint_process_event+0x309e>
     978:      	movl	$0x0, 0x58(%rsp)
     980:      	movq	(%rip), %rdi            # 0x987 <generic_tracepoint_process_event+0x987>
     987:      	leaq	0x58(%rsp), %rsi
     98c:      	movl	$0x1, %eax
     991:      	callq	*%rax
     993:      	testq	%rax, %rax
     996:      	je	0x309e <generic_tracepoint_process_event+0x309e>
     99c:      	movq	%rax, %rsi
     99f:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
     9a6:      	movq	(%rip), %rdi            # 0x9ad <generic_tracepoint_process_event+0x9ad>
     9ad:      	movl	$0x1, %eax
     9b2:      	callq	*%rax
     9b4:      	testq	%rax, %rax
     9b7:      	je	0x309e <generic_tracepoint_process_event+0x309e>
     9bd:      	incl	%r12d
     9c0:      	movl	%r12d, %ecx
     9c3:      	andl	$0x7, %ecx
     9c6:      	cmpl	$-0x1, 0x40(%rax,%rcx,4)
     9cb:      	je	0x309e <generic_tracepoint_process_event+0x309e>
     9d1:      	movl	%r12d, 0x5efc(%r14)
     9d8:      	movq	(%rip), %rsi            # 0x9df <generic_tracepoint_process_event+0x9df>
     9df:      	movl	$0x1, %ecx
     9e4:      	movl	$0xc, %eax
     9e9:      	movq	%rbx, %rdi
     9ec:      	movl	$0x1, %edx
     9f1:      	callq	*%rax
     9f3:      	jmp	0x309e <generic_tracepoint_process_event+0x309e>
     9f8:      	movq	%rax, %rbp
     9fb:      	addq	$0x90, %rbp
     a02:      	addq	%r15, %rbp
     a05:      	movq	0x18(%rsp), %rdx
     a0a:      	movq	%rdx, 0x58(%rsp)
     a0f:      	movq	$0x0, 0x98(%rsp)
     a1b:      	cmpl	$0x17, %r12d
     a1f:      	movq	%rbx, 0x28(%rsp)
     a24:      	movq	%rax, 0x10(%rsp)
     a29:      	jle	0xa66 <generic_tracepoint_process_event+0xa66>
     a2b:      	cmpl	$0x18, %r12d
     a2f:      	je	0xa81 <generic_tracepoint_process_event+0xa81>
     a31:      	cmpl	$0x25, %r12d
     a35:      	je	0xabf <generic_tracepoint_process_event+0xabf>
     a3b:      	cmpl	$0x2a, %r12d
     a3f:      	jne	0x1191 <generic_tracepoint_process_event+0x1191>
     a45:      	movq	$0x0, 0xf8(%rsp)
     a51:      	movq	%rdx, 0x100(%rsp)
     a59:      	leaq	0xf8(%rsp), %rax
     a61:      	jmp	0xaec <generic_tracepoint_process_event+0xaec>
     a66:      	cmpl	$0xf, %r12d
     a6a:      	je	0x10cb <generic_tracepoint_process_event+0x10cb>
     a70:      	cmpl	$0x10, %r12d
     a74:      	jne	0x1191 <generic_tracepoint_process_event+0x1191>
     a7a:      	leaq	0x40(%rsp), %r15
     a7f:      	jmp	0xaa9 <generic_tracepoint_process_event+0xaa9>
     a81:      	leaq	0x40(%rsp), %r15
     a86:      	movl	$0x8, %ecx
     a8b:      	movl	$0x4, %eax
     a90:      	movq	0x58(%rsp), %rdx
     a95:      	movq	%r15, %rdi
     a98:      	movl	$0x8, %esi
     a9d:      	callq	*%rax
     a9f:      	movq	0x40(%rsp), %rax
     aa4:      	movq	%rax, 0x58(%rsp)
     aa9:      	leaq	0x58(%rsp), %rdx
     aae:      	movl	$0x8, %ecx
     ab3:      	movl	$0x4, %eax
     ab8:      	leaq	0x40(%rsp), %rdi
     abd:      	jmp	0xadc <generic_tracepoint_process_event+0xadc>
     abf:      	addq	$0x40, %rdx
     ac3:      	movq	%rdx, 0x58(%rsp)
     ac8:      	leaq	0x40(%rsp), %rdi
     acd:      	movl	$0x8, %ecx
     ad2:      	movl	$0x4, %eax
     ad7:      	movq	0x58(%rsp), %rdx
     adc:      	movl	$0x8, %esi
     ae1:      	callq	*%rax
     ae3:      	movq	0x40(%rsp), %rax
     ae8:      	addq	$0x40, %rax
     aec:      	movq	%rax, 0x30(%rsp)
     af1:      	movl	$0x0, 0xbc(%rsp)
     afc:      	movq	(%rip), %rdi            # 0xb03 <generic_tracepoint_process_event+0xb03>
     b03:      	leaq	0xbc(%rsp), %rsi
     b0b:      	movl	$0x1, %eax
     b10:      	callq	*%rax
     b12:      	testq	%rax, %rax
     b15:      	je	0xbc9 <generic_tracepoint_process_event+0xbc9>
     b1b:      	movq	%rax, %r12
     b1e:      	movq	%rbp, 0x20(%rsp)
     b23:      	addq	$0x1000, %rax           # imm = 0x1000
     b29:      	movq	%rax, 0x18(%rsp)
     b2e:      	movl	$0x23, %eax
     b33:      	callq	*%rax
     b35:      	leaq	0xd50(%rax), %rdx
     b3c:      	leaq	0xd8(%rsp), %rdi
     b44:      	movl	$0x8, %ecx
     b49:      	movl	$0x4, %eax
     b4e:      	movl	$0x8, %esi
     b53:      	callq	*%rax
     b55:      	movq	0xd8(%rsp), %r13
     b5d:      	movq	0x30(%rsp), %rax
     b62:      	leaq	0x8(%rax), %rdx
     b66:      	leaq	0xc0(%rsp), %rdi
     b6e:      	movl	$0x8, %ecx
     b73:      	movl	$0x4, %eax
     b78:      	leaq	0x18(%r13), %rcx
     b7c:      	movq	%rcx, 0xf0(%rsp)
     b84:      	movl	$0x8, %esi
     b89:      	movq	%rdx, 0xb0(%rsp)
     b91:      	callq	*%rax
     b93:      	movq	0xc0(%rsp), %r15
     b9b:      	leaq	0x10(%r15), %rdx
     b9f:      	leaq	0x58(%rsp), %rdi
     ba4:      	movl	$0x8, %ecx
     ba9:      	movl	$0x4, %eax
     bae:      	movl	$0x8, %esi
     bb3:      	callq	*%rax
     bb5:      	cmpq	$0x0, 0x58(%rsp)
     bbb:      	movl	$0x1000, %ebp           # imm = 0x1000
     bc0:      	je	0xbd9 <generic_tracepoint_process_event+0xbd9>
     bc2:      	movq	0x18(%rsp), %rcx
     bc7:      	jmp	0xc2b <generic_tracepoint_process_event+0xc2b>
     bc9:      	xorl	%r15d, %r15d
     bcc:      	movq	0xd0(%rsp), %r12
     bd4:      	jmp	0x1387 <generic_tracepoint_process_event+0x1387>
     bd9:      	leaq	0x18(%r15), %rdx
     bdd:      	leaq	0x58(%rsp), %rdi
     be2:      	movl	$0x8, %ecx
     be7:      	movl	$0x4, %eax
     bec:      	movl	$0x8, %esi
     bf1:      	callq	*%rax
     bf3:      	cmpq	%r15, 0x58(%rsp)
     bf8:      	movq	0x18(%rsp), %rcx
     bfd:      	je	0xc2b <generic_tracepoint_process_event+0xc2b>
     bff:      	movq	%r12, %rcx
     c02:      	addq	$0xff6, %rcx            # imm = 0xFF6
     c09:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
     c13:      	movq	%rax, 0xff6(%r12)
     c1b:      	movw	$0x2964, 0xffe(%r12)    # imm = 0x2964
     c26:      	movl	$0xff6, %ebp            # imm = 0xFF6
     c2b:      	movq	$0x0, 0x60(%rsp)
     c34:      	movq	$0x0, 0x58(%rsp)
     c3d:      	movq	%r12, 0x68(%rsp)
     c42:      	movq	$0x0, 0x70(%rsp)
     c4b:      	movq	$0x0, 0x78(%rsp)
     c54:      	movq	$0x0, 0x80(%rsp)
     c60:      	movq	%rcx, 0x18(%rsp)
     c65:      	movq	%rcx, 0x88(%rsp)
     c6d:      	movl	%ebp, 0x90(%rsp)
     c74:      	movb	$0x0, 0x94(%rsp)
     c7c:      	addq	$0x20, %r13
     c80:      	leaq	0x58(%rsp), %rdi
     c85:      	movl	$0x8, %ecx
     c8a:      	movl	$0x4, %eax
     c8f:      	leaq	0x60(%rsp), %r12
     c94:      	leaq	0x70(%rsp), %r15
     c99:      	leaq	0x78(%rsp), %rbp
     c9e:      	movl	$0x8, %esi
     ca3:      	movq	%r13, %rdx
     ca6:      	callq	*%rax
     ca8:      	movl	$0x8, %ecx
     cad:      	movl	$0x4, %eax
     cb2:      	movq	0xf0(%rsp), %rdx
     cba:      	movq	%r12, %rdi
     cbd:      	movl	$0x8, %esi
     cc2:      	callq	*%rax
     cc4:      	movl	$0x8, %ecx
     cc9:      	movl	$0x4, %eax
     cce:      	movq	0xb0(%rsp), %rdx
     cd6:      	movq	%r15, %rdi
     cd9:      	movl	$0x8, %esi
     cde:      	callq	*%rax
     ce0:      	movl	$0x8, %ecx
     ce5:      	movl	$0x4, %eax
     cea:      	movq	0x30(%rsp), %rdx
     cef:      	movq	%rbp, %rdi
     cf2:      	movl	$0x8, %esi
     cf7:      	callq	*%rax
     cf9:      	movq	0x78(%rsp), %rax
     cfe:      	addq	$-0x20, %rax
     d02:      	movq	%rax, 0x80(%rsp)
     d0a:      	movq	(%rip), %rax            # 0xd11 <generic_tracepoint_process_event+0xd11>
     d11:      	cmpb	$0x0, (%rax)
     d14:      	je	0xef5 <generic_tracepoint_process_event+0xef5>
     d1a:      	movl	$0x80, %ebp
     d1f:      	movl	$0x8, %r15d
     d25:      	movq	0x70(%rsp), %r12
     d2a:      	movq	0x78(%rsp), %rdx
     d2f:      	movq	0x80(%rsp), %r13
     d37:      	cmpq	0x58(%rsp), %r12
     d3c:      	jne	0xd49 <generic_tracepoint_process_event+0xd49>
     d3e:      	cmpq	0x60(%rsp), %rdx
     d43:      	je	0x1244 <generic_tracepoint_process_event+0x1244>
     d49:      	movl	$0x4, %eax
     d4e:      	leaq	0xc8(%rsp), %rdi
     d56:      	movl	$0x8, %esi
     d5b:      	callq	*%rax
     d5d:      	cmpq	0xc8(%rsp), %r12
     d65:      	movl	$0x8, %ebx
     d6a:      	je	0xe87 <generic_tracepoint_process_event+0xe87>
     d70:      	leaq	0x18(%r12), %r15
     d75:      	movl	$0x4, %eax
     d7a:      	leaq	0x40(%rsp), %rdi
     d7f:      	movl	$0x8, %esi
     d84:      	movq	%r15, %rdx
     d87:      	callq	*%rax
     d89:      	cmpq	%r12, 0x40(%rsp)
     d8e:      	je	0xe87 <generic_tracepoint_process_event+0xe87>
     d94:      	movl	$0x4, %eax
     d99:      	leaq	0x38(%rsp), %rdi
     d9e:      	movl	$0x8, %esi
     da3:      	movq	%r15, %rdx
     da6:      	callq	*%rax
     da8:      	addq	$0x20, %r12
     dac:      	movl	$0x4, %eax
     db1:      	leaq	0x98(%rsp), %rdi
     db9:      	movl	$0x10, %ecx
     dbe:      	movl	$0x10, %esi
     dc3:      	movq	%r12, %rdx
     dc6:      	callq	*%rax
     dc8:      	movq	0x68(%rsp), %r15
     dcd:      	movq	0x88(%rsp), %rax
     dd5:      	movl	0x9c(%rsp), %r12d
     ddd:      	subq	%r15, %rax
     de0:      	movl	0x90(%rsp), %r13d
     de8:      	movl	%r12d, %edx
     deb:      	subl	%r13d, %edx
     dee:      	movl	$0x0, %ecx
     df3:      	cmovbl	%ecx, %edx
     df6:      	addq	0xa0(%rsp), %rdx
     dfe:      	xorl	%esi, %esi
     e00:      	cmpl	%r12d, %r13d
     e03:      	seta	%sil
     e07:      	movl	%r12d, %ecx
     e0a:      	cmovbl	%r13d, %ecx
     e0e:      	addl	%ecx, %esi
     e10:      	movl	%r13d, %edi
     e13:      	subl	%esi, %edi
     e15:      	movl	%edi, 0x90(%rsp)
     e1c:      	subq	%rsi, %rax
     e1f:      	movq	0x28(%rsp), %rbx
     e24:      	jb	0x126d <generic_tracepoint_process_event+0x126d>
     e2a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
     e30:      	ja	0x126d <generic_tracepoint_process_event+0x126d>
     e36:      	cmpl	%r12d, %r13d
     e39:      	jbe	0xe40 <generic_tracepoint_process_event+0xe40>
     e3b:      	movb	$0x2f, (%r15,%rax)
     e40:      	xorl	%edi, %edi
     e42:      	cmpl	%r12d, %r13d
     e45:      	seta	%dil
     e49:      	movzbl	%cl, %esi
     e4c:      	addq	%rax, %r15
     e4f:      	addq	%r15, %rdi
     e52:      	movl	$0x4, %eax
     e57:      	callq	*%rax
     e59:      	movq	%r15, 0x88(%rsp)
     e61:      	cmpl	%r12d, %r13d
     e64:      	jbe	0x126d <generic_tracepoint_process_event+0x126d>
     e6a:      	movq	0x38(%rsp), %rax
     e6f:      	movq	%rax, 0x70(%rsp)
     e74:      	movl	$0x8, %r15d
     e7a:      	decl	%ebp
     e7c:      	jne	0xd25 <generic_tracepoint_process_event+0xd25>
     e82:      	jmp	0x126d <generic_tracepoint_process_event+0x126d>
     e87:      	leaq	0x10(%r13), %rdx
     e8b:      	movl	$0x4, %eax
     e90:      	leaq	0x40(%rsp), %rdi
     e95:      	movl	$0x8, %esi
     e9a:      	callq	*%rax
     e9c:      	movq	0x80(%rsp), %rax
     ea4:      	cmpq	0x40(%rsp), %rax
     ea9:      	movl	$0x8, %r15d
     eaf:      	je	0x1260 <generic_tracepoint_process_event+0x1260>
     eb5:      	addq	$0x18, %r13
     eb9:      	movl	$0x4, %eax
     ebe:      	leaq	0x70(%rsp), %rdi
     ec3:      	movl	$0x8, %esi
     ec8:      	movq	%r13, %rdx
     ecb:      	callq	*%rax
     ecd:      	movq	0x40(%rsp), %rax
     ed2:      	movq	%rax, 0x80(%rsp)
     eda:      	addq	$0x20, %rax
     ede:      	movq	%rax, 0x78(%rsp)
     ee3:      	movq	0x28(%rsp), %rbx
     ee8:      	decl	%ebp
     eea:      	jne	0xd25 <generic_tracepoint_process_event+0xd25>
     ef0:      	jmp	0x126d <generic_tracepoint_process_event+0x126d>
     ef5:      	movl	$0x80, %ebp
     efa:      	movl	$0x8, %r15d
     f00:      	movq	0x70(%rsp), %r12
     f05:      	movq	0x78(%rsp), %rdx
     f0a:      	movq	0x80(%rsp), %r13
     f12:      	cmpq	0x58(%rsp), %r12
     f17:      	jne	0xf24 <generic_tracepoint_process_event+0xf24>
     f19:      	cmpq	0x60(%rsp), %rdx
     f1e:      	je	0x1244 <generic_tracepoint_process_event+0x1244>
     f24:      	movl	$0x4, %eax
     f29:      	leaq	0xc8(%rsp), %rdi
     f31:      	movl	$0x8, %esi
     f36:      	callq	*%rax
     f38:      	cmpq	0xc8(%rsp), %r12
     f40:      	movl	$0x8, %ecx
     f45:      	je	0x1062 <generic_tracepoint_process_event+0x1062>
     f4b:      	leaq	0x18(%r12), %r15
     f50:      	movl	$0x4, %eax
     f55:      	leaq	0x40(%rsp), %rdi
     f5a:      	movl	$0x8, %esi
     f5f:      	movq	%r15, %rdx
     f62:      	callq	*%rax
     f64:      	movl	$0x8, %ecx
     f69:      	cmpq	%r12, 0x40(%rsp)
     f6e:      	je	0x1062 <generic_tracepoint_process_event+0x1062>
     f74:      	movl	$0x4, %eax
     f79:      	leaq	0x38(%rsp), %rdi
     f7e:      	movl	$0x8, %esi
     f83:      	movq	%r15, %rdx
     f86:      	callq	*%rax
     f88:      	addq	$0x20, %r12
     f8c:      	movl	$0x4, %eax
     f91:      	leaq	0x98(%rsp), %rdi
     f99:      	movl	$0x10, %ecx
     f9e:      	movl	$0x10, %esi
     fa3:      	movq	%r12, %rdx
     fa6:      	callq	*%rax
     fa8:      	movq	0x68(%rsp), %r15
     fad:      	movq	0x88(%rsp), %rax
     fb5:      	movl	0x9c(%rsp), %r12d
     fbd:      	subq	%r15, %rax
     fc0:      	movl	0x90(%rsp), %r13d
     fc8:      	movl	%r12d, %edx
     fcb:      	subl	%r13d, %edx
     fce:      	movl	$0x0, %ecx
     fd3:      	cmovbl	%ecx, %edx
     fd6:      	addq	0xa0(%rsp), %rdx
     fde:      	xorl	%esi, %esi
     fe0:      	cmpl	%r12d, %r13d
     fe3:      	seta	%sil
     fe7:      	movl	%r12d, %ecx
     fea:      	cmovbl	%r13d, %ecx
     fee:      	addl	%ecx, %esi
     ff0:      	movl	%r13d, %edi
     ff3:      	subl	%esi, %edi
     ff5:      	movl	%edi, 0x90(%rsp)
     ffc:      	subq	%rsi, %rax
     fff:      	jb	0x126d <generic_tracepoint_process_event+0x126d>
    1005:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    100b:      	ja	0x126d <generic_tracepoint_process_event+0x126d>
    1011:      	cmpl	%r12d, %r13d
    1014:      	jbe	0x101b <generic_tracepoint_process_event+0x101b>
    1016:      	movb	$0x2f, (%r15,%rax)
    101b:      	xorl	%edi, %edi
    101d:      	cmpl	%r12d, %r13d
    1020:      	seta	%dil
    1024:      	movzbl	%cl, %esi
    1027:      	addq	%rax, %r15
    102a:      	addq	%r15, %rdi
    102d:      	movl	$0x4, %eax
    1032:      	callq	*%rax
    1034:      	movq	%r15, 0x88(%rsp)
    103c:      	cmpl	%r12d, %r13d
    103f:      	jbe	0x126d <generic_tracepoint_process_event+0x126d>
    1045:      	movq	0x38(%rsp), %rax
    104a:      	movq	%rax, 0x70(%rsp)
    104f:      	movl	$0x8, %r15d
    1055:      	decl	%ebp
    1057:      	jne	0xf00 <generic_tracepoint_process_event+0xf00>
    105d:      	jmp	0x126d <generic_tracepoint_process_event+0x126d>
    1062:      	leaq	0x10(%r13), %rdx
    1066:      	movl	$0x4, %eax
    106b:      	leaq	0x40(%rsp), %rdi
    1070:      	movl	$0x8, %esi
    1075:      	callq	*%rax
    1077:      	movq	0x80(%rsp), %rax
    107f:      	cmpq	0x40(%rsp), %rax
    1084:      	movl	$0x8, %r15d
    108a:      	je	0x1244 <generic_tracepoint_process_event+0x1244>
    1090:      	addq	$0x18, %r13
    1094:      	movl	$0x4, %eax
    1099:      	leaq	0x70(%rsp), %rdi
    109e:      	movl	$0x8, %esi
    10a3:      	movq	%r13, %rdx
    10a6:      	callq	*%rax
    10a8:      	movq	0x40(%rsp), %rax
    10ad:      	movq	%rax, 0x80(%rsp)
    10b5:      	addq	$0x20, %rax
    10b9:      	movq	%rax, 0x78(%rsp)
    10be:      	decl	%ebp
    10c0:      	jne	0xf00 <generic_tracepoint_process_event+0xf00>
    10c6:      	jmp	0x126d <generic_tracepoint_process_event+0x126d>
    10cb:      	leaq	0x98(%rsp), %rdi
    10d3:      	leaq	0x58(%rsp), %rdx
    10d8:      	movl	$0x8, %ecx
    10dd:      	movl	$0x4, %eax
    10e2:      	movl	$0x8, %esi
    10e7:      	callq	*%rax
    10e9:      	movq	0x98(%rsp), %rax
    10f1:      	movq	%rax, 0x30(%rsp)
    10f6:      	testq	%rax, %rax
    10f9:      	jne	0xaf1 <generic_tracepoint_process_event+0xaf1>
    10ff:      	movl	$0x0, 0xd8(%rsp)
    110a:      	movq	(%rip), %rdi            # 0x1111 <generic_tracepoint_process_event+0x1111>
    1111:      	leaq	0xd8(%rsp), %rsi
    1119:      	movl	$0x1, %eax
    111e:      	callq	*%rax
    1120:      	testq	%rax, %rax
    1123:      	je	0x1504 <generic_tracepoint_process_event+0x1504>
    1129:      	movq	%r15, 0x30(%rsp)
    112e:      	xorl	%r15d, %r15d
    1131:      	cmpl	$0x19, %r12d
    1135:      	jg	0x15c8 <generic_tracepoint_process_event+0x15c8>
    113b:      	cmpl	$0x12, %r12d
    113f:      	jle	0x172d <generic_tracepoint_process_event+0x172d>
    1145:      	cmpl	$0x14, %r12d
    1149:      	jle	0x1aac <generic_tracepoint_process_event+0x1aac>
    114f:      	cmpl	$0x15, %r12d
    1153:      	je	0x22e4 <generic_tracepoint_process_event+0x22e4>
    1159:      	cmpl	$0x16, %r12d
    115d:      	je	0x225f <generic_tracepoint_process_event+0x225f>
    1163:      	cmpl	$0x17, %r12d
    1167:      	movq	0x10(%rsp), %rcx
    116c:      	movq	0x8(%rsp), %rdx
    1171:      	jne	0x305b <generic_tracepoint_process_event+0x305b>
    1177:      	movl	$0x0, 0x4(%rbp)
    117e:      	movq	0x18(%rsp), %rax
    1183:      	movl	%eax, (%rbp)
    1186:      	movl	$0x8, %r15d
    118c:      	jmp	0x305b <generic_tracepoint_process_event+0x305b>
    1191:      	cmpl	$0x2c, %r12d
    1195:      	ja	0x10ff <generic_tracepoint_process_event+0x10ff>
    119b:      	movl	%r12d, %eax
    119e:      	movabsq	$0x11c1f2027cf2, %rcx   # imm = 0x11C1F2027CF2
    11a8:      	btq	%rax, %rcx
    11ac:      	jae	0x10ff <generic_tracepoint_process_event+0x10ff>
    11b2:      	movq	%rdx, 0x38(%rsp)
    11b7:      	movl	$0x0, 0xc8(%rsp)
    11c2:      	movq	(%rip), %rdi            # 0x11c9 <generic_tracepoint_process_event+0x11c9>
    11c9:      	leaq	0xc8(%rsp), %rsi
    11d1:      	movl	$0x1, %eax
    11d6:      	callq	*%rax
    11d8:      	testq	%rax, %rax
    11db:      	je	0x124e <generic_tracepoint_process_event+0x124e>
    11dd:      	movq	%r15, %r13
    11e0:      	movq	%rbp, 0x20(%rsp)
    11e5:      	xorl	%r15d, %r15d
    11e8:      	cmpl	$0x10, %r12d
    11ec:      	movq	0x10(%rsp), %rcx
    11f1:      	jle	0x139f <generic_tracepoint_process_event+0x139f>
    11f7:      	cmpl	$0x1e, %r12d
    11fb:      	movq	0x50(%rsp), %rbp
    1200:      	jle	0x150c <generic_tracepoint_process_event+0x150c>
    1206:      	cmpl	$0x26, %r12d
    120a:      	jg	0x1604 <generic_tracepoint_process_event+0x1604>
    1210:      	leal	-0x1f(%r12), %eax
    1215:      	cmpl	$0x2, %eax
    1218:      	jae	0x1b8f <generic_tracepoint_process_event+0x1b8f>
    121e:      	leaq	0x38(%rsp), %rdx
    1223:      	movl	$0x4, %r15d
    1229:      	movl	$0x1, %ecx
    122e:      	movl	$0x4, %eax
    1233:      	movq	0x20(%rsp), %rdi
    1238:      	movl	$0x1, %esi
    123d:      	callq	*%rax
    123f:      	jmp	0x28d7 <generic_tracepoint_process_event+0x28d7>
    1244:      	movb	$0x1, 0x94(%rsp)
    124c:      	jmp	0x126d <generic_tracepoint_process_event+0x126d>
    124e:      	xorl	%r15d, %r15d
    1251:      	movq	0x10(%rsp), %rcx
    1256:      	movq	0x50(%rsp), %rbp
    125b:      	jmp	0x28dc <generic_tracepoint_process_event+0x28dc>
    1260:      	movb	$0x1, 0x94(%rsp)
    1268:      	movq	0x28(%rsp), %rbx
    126d:      	movq	0x88(%rsp), %rax
    1275:      	movq	0x18(%rsp), %rdx
    127a:      	cmpq	%rdx, %rax
    127d:      	je	0x12bd <generic_tracepoint_process_event+0x12bd>
    127f:      	xorl	%ebp, %ebp
    1281:      	cmpb	$0x0, 0x94(%rsp)
    1289:      	sete	%cl
    128c:      	movl	0x90(%rsp), %edx
    1293:      	movl	$0x1000, %r15d          # imm = 0x1000
    1299:      	subl	%edx, %r15d
    129c:      	testl	%edx, %edx
    129e:      	cmovlel	%edx, %r15d
    12a2:      	testq	%rax, %rax
    12a5:      	movq	0xd0(%rsp), %r12
    12ad:      	je	0x1384 <generic_tracepoint_process_event+0x1384>
    12b3:      	movb	%cl, %bpl
    12b6:      	addl	%ebp, %ebp
    12b8:      	movq	%rax, %rdx
    12bb:      	jmp	0x12ca <generic_tracepoint_process_event+0x12ca>
    12bd:      	xorl	%r15d, %r15d
    12c0:      	xorl	%ebp, %ebp
    12c2:      	movq	0xd0(%rsp), %r12
    12ca:      	movq	0x20(%rsp), %r13
    12cf:      	leaq	0x4(%r13), %rdi
    12d3:      	andl	$0xfff, %r15d           # imm = 0xFFF
    12da:      	movl	$0x4, %eax
    12df:      	movl	%r15d, %esi
    12e2:      	callq	*%rax
    12e4:      	movl	%r15d, (%r13)
    12e8:      	leaq	0x58(%rsp), %rdi
    12ed:      	movl	$0x8, %ecx
    12f2:      	movl	$0x4, %eax
    12f7:      	movq	0xb0(%rsp), %rdx
    12ff:      	movl	$0x8, %esi
    1304:      	callq	*%rax
    1306:      	movq	0x58(%rsp), %rcx
    130b:      	addq	$0x30, %rcx
    130f:      	leaq	0x98(%rsp), %rdi
    1317:      	movl	$0x8, %edx
    131c:      	movl	$0x4, %eax
    1321:      	movq	0x58(%rsp), %rdx
    1326:      	addq	$0x30, %rdx
    132a:      	movl	$0x8, %esi
    132f:      	callq	*%rax
    1331:      	movq	0x98(%rsp), %rcx
    1339:      	leaq	0x40(%rsp), %rdi
    133e:      	movl	$0x2, %edx
    1343:      	movl	$0x4, %eax
    1348:      	movq	0x98(%rsp), %rdx
    1350:      	movl	$0x2, %esi
    1355:      	callq	*%rax
    1357:      	movl	%ebp, 0x4(%r13,%r15)
    135c:      	movzwl	0x40(%rsp), %eax
    1361:      	movw	%ax, 0x8(%r13,%r15)
    1367:      	addl	$0xa, %r15d
    136b:      	movq	0x10(%rsp), %rcx
    1370:      	movq	0x50(%rsp), %rbp
    1375:      	movq	0x8(%rsp), %rdx
    137a:      	testl	%r15d, %r15d
    137d:      	jns	0x138c <generic_tracepoint_process_event+0x138c>
    137f:      	jmp	0x3071 <generic_tracepoint_process_event+0x3071>
    1384:      	xorl	%r15d, %r15d
    1387:      	movq	0x50(%rsp), %rbp
    138c:      	andl	$0x7fffffff, %r15d      # imm = 0x7FFFFFFF
    1393:      	addl	$0x4, %r15d
    1397:      	movl	%r15d, %edx
    139a:      	jmp	0x308c <generic_tracepoint_process_event+0x308c>
    139f:      	cmpl	$0x9, %r12d
    13a3:      	movq	0x50(%rsp), %rbp
    13a8:      	movq	0x8(%rsp), %rdx
    13ad:      	jg	0x1543 <generic_tracepoint_process_event+0x1543>
    13b3:      	cmpl	$0x4, %r12d
    13b7:      	jle	0x17bf <generic_tracepoint_process_event+0x17bf>
    13bd:      	cmpl	$0x5, %r12d
    13c1:      	je	0x1d70 <generic_tracepoint_process_event+0x1d70>
    13c7:      	cmpl	$0x6, %r12d
    13cb:      	je	0x15a5 <generic_tracepoint_process_event+0x15a5>
    13d1:      	cmpl	$0x7, %r12d
    13d5:      	movq	0x10(%rsp), %rcx
    13da:      	movq	0x8(%rsp), %rdx
    13df:      	jne	0x28e1 <generic_tracepoint_process_event+0x28e1>
    13e5:      	movq	%rax, %r13
    13e8:      	movq	0x38(%rsp), %r15
    13ed:      	movq	0x20(%rsp), %rbp
    13f2:      	movq	%r15, 0x28(%rbp)
    13f6:      	leaq	0x26(%rbp), %rdi
    13fa:      	leaq	0x10(%r15), %rdx
    13fe:      	movl	$0x2, %ecx
    1403:      	movl	$0x4, %eax
    1408:      	movl	$0x2, %esi
    140d:      	callq	*%rax
    140f:      	leaq	0x3a(%rbp), %rdi
    1413:      	leaq	0x12(%r15), %rdx
    1417:      	movl	$0x1, %ecx
    141c:      	movl	$0x4, %eax
    1421:      	movl	$0x1, %esi
    1426:      	callq	*%rax
    1428:      	leaq	0x38(%rbp), %rdi
    142c:      	leaq	0x226(%r15), %rdx
    1433:      	movl	$0x2, %ecx
    1438:      	movl	$0x4, %eax
    143d:      	movl	$0x2, %esi
    1442:      	callq	*%rax
    1444:      	leaq	0x24(%rbp), %rdi
    1448:      	leaq	0x224(%r15), %rdx
    144f:      	movl	$0x2, %ecx
    1454:      	movl	$0x4, %eax
    1459:      	movl	$0x2, %esi
    145e:      	callq	*%rax
    1460:      	leaq	0x30(%rbp), %rdi
    1464:      	leaq	0x21c(%r15), %rdx
    146b:      	movl	$0x4, %ecx
    1470:      	movl	$0x4, %eax
    1475:      	movl	$0x4, %esi
    147a:      	callq	*%rax
    147c:      	leaq	0x34(%rbp), %rdi
    1480:      	leaq	0x218(%r15), %rdx
    1487:      	movl	$0x4, %ecx
    148c:      	movl	$0x4, %eax
    1491:      	movl	$0x4, %esi
    1496:      	callq	*%rax
    1498:      	leaq	0x10(%rbp), %r12
    149c:      	movq	$0x0, (%rbp)
    14a4:      	movq	$0x0, 0x8(%rbp)
    14ac:      	movq	$0x0, 0x10(%rbp)
    14b4:      	movq	$0x0, 0x18(%rbp)
    14bc:      	movzwl	0x26(%rbp), %eax
    14c0:      	cmpl	$0xa, %eax
    14c3:      	je	0x25c7 <generic_tracepoint_process_event+0x25c7>
    14c9:      	cmpl	$0x2, %eax
    14cc:      	jne	0x25f7 <generic_tracepoint_process_event+0x25f7>
    14d2:      	leaq	0x4(%r15), %rdx
    14d6:      	movl	$0x4, %ecx
    14db:      	movl	$0x4, %eax
    14e0:      	movq	%rbp, %rdi
    14e3:      	movl	$0x4, %esi
    14e8:      	callq	*%rax
    14ea:      	movl	$0x4, %ecx
    14ef:      	movl	$0x4, %eax
    14f4:      	movq	%r12, %rdi
    14f7:      	movl	$0x4, %esi
    14fc:      	movq	%r15, %rdx
    14ff:      	jmp	0x25f5 <generic_tracepoint_process_event+0x25f5>
    1504:      	xorl	%r15d, %r15d
    1507:      	jmp	0x2461 <generic_tracepoint_process_event+0x2461>
    150c:      	cmpl	$0x1c, %r12d
    1510:      	jg	0x1799 <generic_tracepoint_process_event+0x1799>
    1516:      	cmpl	$0x11, %r12d
    151a:      	je	0x1bc8 <generic_tracepoint_process_event+0x1bc8>
    1520:      	movq	%rax, 0x18(%rsp)
    1525:      	cmpl	$0x19, %r12d
    1529:      	je	0x1c8c <generic_tracepoint_process_event+0x1c8c>
    152f:      	cmpl	$0x1c, %r12d
    1533:      	movq	0x8(%rsp), %rdx
    1538:      	je	0x17cf <generic_tracepoint_process_event+0x17cf>
    153e:      	jmp	0x28e1 <generic_tracepoint_process_event+0x28e1>
    1543:      	leal	-0xa(%r12), %eax
    1548:      	cmpl	$0x2, %eax
    154b:      	jb	0x17cf <generic_tracepoint_process_event+0x17cf>
    1551:      	leal	-0xc(%r12), %eax
    1556:      	cmpl	$0x2, %eax
    1559:      	jb	0x17f0 <generic_tracepoint_process_event+0x17f0>
    155f:      	cmpl	$0xe, %r12d
    1563:      	jne	0x28e1 <generic_tracepoint_process_event+0x28e1>
    1569:      	leaq	0x58(%rsp), %rdi
    156e:      	leaq	0x38(%rsp), %r15
    1573:      	movl	$0x8, %ecx
    1578:      	movl	$0x4, %eax
    157d:      	movl	$0x8, %esi
    1582:      	movq	%r15, %rdx
    1585:      	callq	*%rax
    1587:      	movq	0x58(%rsp), %rcx
    158c:      	movl	$0x8, %edx
    1591:      	movl	$0x4, %eax
    1596:      	movq	0x58(%rsp), %rdx
    159b:      	movq	%r15, %rdi
    159e:      	movl	$0x8, %esi
    15a3:      	callq	*%rax
    15a5:      	movq	0x38(%rsp), %rdx
    15aa:      	movq	0x20(%rsp), %r12
    15af:      	leaq	0x4(%r12), %rdi
    15b4:      	movl	$0x1001, %ecx           # imm = 0x1001
    15b9:      	movl	$0x2d, %eax
    15be:      	movl	$0x1001, %esi           # imm = 0x1001
    15c3:      	jmp	0x1f52 <generic_tracepoint_process_event+0x1f52>
    15c8:      	cmpl	$0x20, %r12d
    15cc:      	jle	0x1992 <generic_tracepoint_process_event+0x1992>
    15d2:      	leal	-0x21(%r12), %ecx
    15d7:      	cmpl	$0x4, %ecx
    15da:      	jae	0x1831 <generic_tracepoint_process_event+0x1831>
    15e0:      	movl	$0x8, %r15d
    15e6:      	movl	$0x8, %ecx
    15eb:      	movl	$0x4, %eax
    15f0:      	movq	0x18(%rsp), %rdx
    15f5:      	movq	%rbp, %rdi
    15f8:      	movl	$0x8, %esi
    15fd:      	callq	*%rax
    15ff:      	jmp	0x2461 <generic_tracepoint_process_event+0x2461>
    1604:      	cmpl	$0x27, %r12d
    1608:      	je	0x1f2f <generic_tracepoint_process_event+0x1f2f>
    160e:      	cmpl	$0x28, %r12d
    1612:      	je	0x1f71 <generic_tracepoint_process_event+0x1f71>
    1618:      	cmpl	$0x2c, %r12d
    161c:      	movq	0x8(%rsp), %rdx
    1621:      	jne	0x28e1 <generic_tracepoint_process_event+0x28e1>
    1627:      	movq	0x38(%rsp), %r15
    162c:      	movb	$0x0, 0x58(%rsp)
    1631:      	movq	0x20(%rsp), %rdi
    1636:      	movq	$0x0, 0x68(%rdi)
    163e:      	movq	$0x0, 0x60(%rdi)
    1646:      	movq	$0x0, 0x58(%rdi)
    164e:      	movq	$0x0, 0x50(%rdi)
    1656:      	movq	$0x0, 0x48(%rdi)
    165e:      	movq	$0x0, 0x40(%rdi)
    1666:      	movq	$0x0, 0x38(%rdi)
    166e:      	movq	$0x0, 0x30(%rdi)
    1676:      	movq	$0x0, 0x28(%rdi)
    167e:      	movq	$0x0, 0x20(%rdi)
    1686:      	movq	$0x0, 0x18(%rdi)
    168e:      	movq	$0x0, 0x10(%rdi)
    1696:      	movq	$0x0, 0x8(%rdi)
    169e:      	movq	$0x0, (%rdi)
    16a5:      	movl	$0x2, %ecx
    16aa:      	movl	$0x4, %eax
    16af:      	movl	$0x2, %esi
    16b4:      	movq	%r15, %rdx
    16b7:      	callq	*%rax
    16b9:      	testq	%rax, %rax
    16bc:      	js	0x28d1 <generic_tracepoint_process_event+0x28d1>
    16c2:      	leaq	0x2(%r15), %r12
    16c6:      	leaq	0x58(%rsp), %rdi
    16cb:      	movl	$0x1, %ecx
    16d0:      	movl	$0x4, %eax
    16d5:      	movl	$0x1, %esi
    16da:      	movq	%r12, %rdx
    16dd:      	callq	*%rax
    16df:      	testq	%rax, %rax
    16e2:      	js	0x28d1 <generic_tracepoint_process_event+0x28d1>
    16e8:      	movq	0x20(%rsp), %rax
    16ed:      	leaq	0x4(%rax), %rdi
    16f1:      	cmpb	$0x0, 0x58(%rsp)
    16f6:      	sete	0x2(%rax)
    16fa:      	je	0x289e <generic_tracepoint_process_event+0x289e>
    1700:      	movl	$0x6c, %ecx
    1705:      	movl	$0x2d, %eax
    170a:      	movl	$0x6c, %esi
    170f:      	movq	%r12, %rdx
    1712:      	callq	*%rax
    1714:      	testl	%eax, %eax
    1716:      	movq	0x50(%rsp), %rbp
    171b:      	movq	0x28(%rsp), %rbx
    1720:      	js	0x28d1 <generic_tracepoint_process_event+0x28d1>
    1726:      	decb	%al
    1728:      	jmp	0x28c9 <generic_tracepoint_process_event+0x28c9>
    172d:      	movl	%r13d, %esi
    1730:      	cmpl	$0x7, %r12d
    1734:      	jg	0x1a5f <generic_tracepoint_process_event+0x1a5f>
    173a:      	cmpl	$0x2, %r12d
    173e:      	je	0x200a <generic_tracepoint_process_event+0x200a>
    1744:      	cmpl	$0x3, %r12d
    1748:      	movq	0x10(%rsp), %rcx
    174d:      	movq	0x8(%rsp), %rdx
    1752:      	jne	0x305b <generic_tracepoint_process_event+0x305b>
    1758:      	movq	%rax, %rbp
    175b:      	leaq	0x90(%rax), %r13
    1762:      	movl	%esi, %eax
    1764:      	andl	$0xf, %eax
    1767:      	cmpl	$0x2, %eax
    176a:      	jle	0x2755 <generic_tracepoint_process_event+0x2755>
    1770:      	cmpl	$0x3, %eax
    1773:      	je	0x29d4 <generic_tracepoint_process_event+0x29d4>
    1779:      	cmpl	$0x4, %eax
    177c:      	je	0x29df <generic_tracepoint_process_event+0x29df>
    1782:      	cmpl	$0x5, %eax
    1785:      	jne	0x2dff <generic_tracepoint_process_event+0x2dff>
    178b:      	movq	%rbp, %rax
    178e:      	addq	$0x5e70, %rax           # imm = 0x5E70
    1794:      	jmp	0x29f3 <generic_tracepoint_process_event+0x29f3>
    1799:      	leaq	0x38(%rsp), %rdx
    179e:      	movl	$0x4, %r15d
    17a4:      	movl	$0x2, %ecx
    17a9:      	movl	$0x4, %eax
    17ae:      	movq	0x20(%rsp), %rdi
    17b3:      	movl	$0x2, %esi
    17b8:      	callq	*%rax
    17ba:      	jmp	0x28d7 <generic_tracepoint_process_event+0x28d7>
    17bf:      	cmpl	$0x1, %r12d
    17c3:      	je	0x17f0 <generic_tracepoint_process_event+0x17f0>
    17c5:      	cmpl	$0x4, %r12d
    17c9:      	jne	0x28e1 <generic_tracepoint_process_event+0x28e1>
    17cf:      	movl	$0x8, %r15d
    17d5:      	leaq	0x38(%rsp), %rdx
    17da:      	movl	$0x8, %ecx
    17df:      	movl	$0x4, %eax
    17e4:      	movq	0x20(%rsp), %rdi
    17e9:      	movl	$0x8, %esi
    17ee:      	jmp	0x180f <generic_tracepoint_process_event+0x180f>
    17f0:      	leaq	0x38(%rsp), %rdx
    17f5:      	movl	$0x4, %r15d
    17fb:      	movl	$0x4, %ecx
    1800:      	movl	$0x4, %eax
    1805:      	movq	0x20(%rsp), %rdi
    180a:      	movl	$0x4, %esi
    180f:      	callq	*%rax
    1811:      	movq	0x8(%rsp), %rdx
    1816:      	movq	0x10(%rsp), %rcx
    181b:      	movq	0xd0(%rsp), %r12
    1823:      	testl	%r15d, %r15d
    1826:      	jns	0x138c <generic_tracepoint_process_event+0x138c>
    182c:      	jmp	0x3071 <generic_tracepoint_process_event+0x3071>
    1831:      	movq	%rax, 0x30(%rsp)
    1836:      	cmpl	$0x2b, %r12d
    183a:      	je	0x23cd <generic_tracepoint_process_event+0x23cd>
    1840:      	cmpl	$0x29, %r12d
    1844:      	movq	0x10(%rsp), %rcx
    1849:      	movq	0x8(%rsp), %rdx
    184e:      	jne	0x305b <generic_tracepoint_process_event+0x305b>
    1854:      	movq	0x18(%rsp), %rdx
    1859:      	addq	$0x18, %rdx
    185d:      	leaq	0x58(%rsp), %rdi
    1862:      	movl	$0x4, %r12d
    1868:      	movl	$0x8, %ecx
    186d:      	movl	$0x4, %eax
    1872:      	movl	$0x8, %esi
    1877:      	callq	*%rax
    1879:      	movq	0x58(%rsp), %r15
    187e:      	testq	%r15, %r15
    1881:      	je	0x298e <generic_tracepoint_process_event+0x298e>
    1887:      	movq	%r15, 0x28(%rbp)
    188b:      	leaq	0x26(%rbp), %rdi
    188f:      	leaq	0x10(%r15), %rdx
    1893:      	movl	$0x2, %ecx
    1898:      	movl	$0x4, %eax
    189d:      	movl	$0x2, %esi
    18a2:      	callq	*%rax
    18a4:      	leaq	0x3a(%rbp), %rdi
    18a8:      	leaq	0x12(%r15), %rdx
    18ac:      	movl	$0x1, %ecx
    18b1:      	movl	$0x4, %eax
    18b6:      	movl	$0x1, %esi
    18bb:      	callq	*%rax
    18bd:      	leaq	0x38(%rbp), %rdi
    18c1:      	leaq	0x226(%r15), %rdx
    18c8:      	movl	$0x2, %ecx
    18cd:      	movl	$0x4, %eax
    18d2:      	movl	$0x2, %esi
    18d7:      	callq	*%rax
    18d9:      	leaq	0x24(%rbp), %rdi
    18dd:      	leaq	0x224(%r15), %rdx
    18e4:      	movl	$0x2, %ecx
    18e9:      	movl	$0x4, %eax
    18ee:      	movl	$0x2, %esi
    18f3:      	callq	*%rax
    18f5:      	leaq	0x30(%rbp), %rdi
    18f9:      	leaq	0x21c(%r15), %rdx
    1900:      	movl	$0x4, %eax
    1905:      	movl	$0x4, %esi
    190a:      	callq	*%rax
    190c:      	leaq	0x34(%rbp), %rdi
    1910:      	leaq	0x218(%r15), %rdx
    1917:      	movl	$0x4, %eax
    191c:      	movl	$0x4, %esi
    1921:      	callq	*%rax
    1923:      	leaq	0x10(%rbp), %r12
    1927:      	movq	$0x0, (%rbp)
    192f:      	movq	$0x0, 0x8(%rbp)
    1937:      	movq	$0x0, 0x10(%rbp)
    193f:      	movq	$0x0, 0x18(%rbp)
    1947:      	movq	%rbp, %r13
    194a:      	movzwl	0x26(%rbp), %eax
    194e:      	cmpl	$0xa, %eax
    1951:      	je	0x2917 <generic_tracepoint_process_event+0x2917>
    1957:      	cmpl	$0x2, %eax
    195a:      	jne	0x2947 <generic_tracepoint_process_event+0x2947>
    1960:      	leaq	0x4(%r15), %rdx
    1964:      	movl	$0x4, %ecx
    1969:      	movl	$0x4, %eax
    196e:      	movq	%r13, %rdi
    1971:      	movl	$0x4, %esi
    1976:      	callq	*%rax
    1978:      	movl	$0x4, %ecx
    197d:      	movl	$0x4, %eax
    1982:      	movq	%r12, %rdi
    1985:      	movl	$0x4, %esi
    198a:      	movq	%r15, %rdx
    198d:      	jmp	0x2945 <generic_tracepoint_process_event+0x2945>
    1992:      	cmpl	$0x1a, %r12d
    1996:      	je	0x2470 <generic_tracepoint_process_event+0x2470>
    199c:      	cmpl	$0x1b, %r12d
    19a0:      	movq	0x10(%rsp), %rcx
    19a5:      	movq	0x8(%rsp), %rdx
    19aa:      	jne	0x305b <generic_tracepoint_process_event+0x305b>
    19b0:      	movq	%rcx, %r12
    19b3:      	movq	$0x0, 0x48(%rbp)
    19bb:      	movq	$0x0, 0x40(%rbp)
    19c3:      	movq	$0x0, 0x38(%rbp)
    19cb:      	movq	$0x0, 0x30(%rbp)
    19d3:      	movq	$0x0, 0x28(%rbp)
    19db:      	movq	$0x0, 0x20(%rbp)
    19e3:      	movq	$0x0, 0x18(%rbp)
    19eb:      	movq	$0x0, 0x10(%rbp)
    19f3:      	movq	$0x0, 0x8(%rbp)
    19fb:      	movq	$0x0, (%rbp)
    1a03:      	movq	%rbp, %r15
    1a06:      	leaq	0x10(%rbp), %rdi
    1a0a:      	movq	0x18(%rsp), %rax
    1a0f:      	leaq	0x18(%rax), %rdx
    1a13:      	movl	$0x3f, %ecx
    1a18:      	movl	$0x2d, %eax
    1a1d:      	movl	$0x3f, %esi
    1a22:      	callq	*%rax
    1a24:      	testq	%rax, %rax
    1a27:      	js	0x2893 <generic_tracepoint_process_event+0x2893>
    1a2d:      	movq	%r15, %rdi
    1a30:      	addq	$0x8, %rdi
    1a34:      	movq	0x18(%rsp), %rdx
    1a39:      	addq	$0x348, %rdx            # imm = 0x348
    1a40:      	movl	$0x8, %ecx
    1a45:      	movl	$0x4, %eax
    1a4a:      	movl	$0x8, %esi
    1a4f:      	callq	*%rax
    1a51:      	movl	$0x50, %r15d
    1a57:      	movq	%r12, %rcx
    1a5a:      	jmp	0x3051 <generic_tracepoint_process_event+0x3051>
    1a5f:      	cmpl	$0x8, %r12d
    1a63:      	je	0x206d <generic_tracepoint_process_event+0x206d>
    1a69:      	cmpl	$0x12, %r12d
    1a6d:      	movq	0x10(%rsp), %rcx
    1a72:      	movq	0x8(%rsp), %rdx
    1a77:      	jne	0x305b <generic_tracepoint_process_event+0x305b>
    1a7d:      	movq	%rsi, %r12
    1a80:      	andl	$0x3ff, %r12d           # imm = 0x3FF
    1a87:      	movq	%rcx, %r15
    1a8a:      	movl	$0x4, %eax
    1a8f:      	movq	0x18(%rsp), %rdx
    1a94:      	movq	%rbp, %rdi
    1a97:      	movl	%r12d, %esi
    1a9a:      	callq	*%rax
    1a9c:      	movq	0x8(%rsp), %rdx
    1aa1:      	movq	%r15, %rcx
    1aa4:      	movq	%r12, %r15
    1aa7:      	jmp	0x305b <generic_tracepoint_process_event+0x305b>
    1aac:      	cmpl	$0x13, %r12d
    1ab0:      	je	0x2376 <generic_tracepoint_process_event+0x2376>
    1ab6:      	cmpl	$0x14, %r12d
    1aba:      	movq	0x10(%rsp), %rcx
    1abf:      	movq	0x8(%rsp), %rdx
    1ac4:      	jne	0x305b <generic_tracepoint_process_event+0x305b>
    1aca:      	movq	$0x0, 0x58(%rsp)
    1ad3:      	movq	0x18(%rsp), %r13
    1ad8:      	leaq	0x110(%r13), %rdx
    1adf:      	leaq	0x58(%rsp), %rdi
    1ae4:      	movl	$0x8, %esi
    1ae9:      	movq	%rcx, %r12
    1aec:      	movl	$0x4, %eax
    1af1:      	leaq	0xd8(%r13), %r15
    1af8:      	movl	$0x8, %esi
    1afd:      	callq	*%rax
    1aff:      	movq	0x58(%rsp), %rcx
    1b04:      	movl	$0x80, %edx
    1b09:      	movl	$0x2d, %eax
    1b0e:      	movq	0x58(%rsp), %rdx
    1b13:      	movq	%rbp, %rdi
    1b16:      	movl	$0x80, %esi
    1b1b:      	callq	*%rax
    1b1d:      	leaq	0x90(%rbp), %rdi
    1b24:      	movl	$0x4, %ecx
    1b29:      	movl	$0x4, %eax
    1b2e:      	movl	$0x4, %esi
    1b33:      	movq	%r15, %rdx
    1b36:      	callq	*%rax
    1b38:      	leaq	0x80(%rbp), %rdi
    1b3f:      	leaq	0xe0(%r13), %rdx
    1b46:      	movl	$0x8, %ecx
    1b4b:      	movl	$0x4, %eax
    1b50:      	movl	$0x8, %esi
    1b55:      	callq	*%rax
    1b57:      	addq	$0x88, %rbp
    1b5e:      	addq	$0x118, %r13            # imm = 0x118
    1b65:      	movl	$0x8, %ecx
    1b6a:      	movl	$0x4, %eax
    1b6f:      	movq	%rbp, %rdi
    1b72:      	movl	$0x8, %esi
    1b77:      	movq	%r13, %rdx
    1b7a:      	callq	*%rax
    1b7c:      	movq	0x8(%rsp), %rdx
    1b81:      	movq	%r12, %rcx
    1b84:      	movl	$0x98, %r15d
    1b8a:      	jmp	0x305b <generic_tracepoint_process_event+0x305b>
    1b8f:      	cmpl	$0x26, %r12d
    1b93:      	movq	0x8(%rsp), %rdx
    1b98:      	jne	0x28e1 <generic_tracepoint_process_event+0x28e1>
    1b9e:      	movq	0x38(%rsp), %rsi
    1ba3:      	movzwl	%si, %edx
    1ba6:      	addq	%rbx, %rdx
    1ba9:      	shrl	$0x10, %esi
    1bac:      	andl	$0xfff, %esi            # imm = 0xFFF
    1bb2:      	movq	0x20(%rsp), %r12
    1bb7:      	leaq	0x4(%r12), %rdi
    1bbc:      	incl	%esi
    1bbe:      	movl	$0x2d, %eax
    1bc3:      	jmp	0x1f52 <generic_tracepoint_process_event+0x1f52>
    1bc8:      	movq	$0x0, 0x60(%rsp)
    1bd1:      	movl	$0xe, %eax
    1bd6:      	callq	*%rax
    1bd8:      	shrq	$0x20, %rax
    1bdc:      	movq	%rax, 0x58(%rsp)
    1be1:      	leaq	0x98(%rsp), %rdi
    1be9:      	leaq	0x38(%rsp), %rdx
    1bee:      	movl	$0x4, %ecx
    1bf3:      	movl	$0x4, %eax
    1bf8:      	movl	$0x4, %r13d
    1bfe:      	movl	$0x4, %esi
    1c03:      	callq	*%rax
    1c05:      	movl	0x98(%rsp), %eax
    1c0c:      	movl	%eax, 0x60(%rsp)
    1c10:      	movq	(%rip), %rdi            # 0x1c17 <generic_tracepoint_process_event+0x1c17>
    1c17:      	leaq	0x58(%rsp), %rsi
    1c1c:      	movl	$0x1, %eax
    1c21:      	callq	*%rax
    1c23:      	testq	%rax, %rax
    1c26:      	je	0x250b <generic_tracepoint_process_event+0x250b>
    1c2c:      	movl	(%rax), %r15d
    1c2f:      	leaq	0x98(%rsp), %rdx
    1c37:      	movq	%rax, %r12
    1c3a:      	movl	$0x4, %eax
    1c3f:      	movq	0x20(%rsp), %rbp
    1c44:      	movq	%rbp, %rdi
    1c47:      	movl	$0x4, %esi
    1c4c:      	callq	*%rax
    1c4e:      	andl	$0xfff, %r15d           # imm = 0xFFF
    1c55:      	leaq	0x4(%rbp), %rdi
    1c59:      	leaq	0x4(%r15), %rsi
    1c5d:      	movl	$0x4, %eax
    1c62:      	movq	%r12, %rdx
    1c65:      	callq	*%rax
    1c67:      	leaq	(%r15,%rbp), %rdi
    1c6b:      	addq	$0x8, %rdi
    1c6f:      	leaq	(%r15,%r12), %rdx
    1c73:      	addq	$0x4, %rdx
    1c77:      	movl	$0x4, %eax
    1c7c:      	movl	$0x4, %esi
    1c81:      	callq	*%rax
    1c83:      	addq	$0xc, %r15
    1c87:      	jmp	0x37df <generic_tracepoint_process_event+0x37df>
    1c8c:      	movq	0x38(%rsp), %r15
    1c91:      	leaq	0xc0(%rsp), %rdi
    1c99:      	movl	$0x1, %ecx
    1c9e:      	movl	$0x4, %eax
    1ca3:      	movl	$0x1, %esi
    1ca8:      	movq	%r15, %rdx
    1cab:      	callq	*%rax
    1cad:      	cmpb	$0x1, 0xc0(%rsp)
    1cb5:      	jne	0x24ef <generic_tracepoint_process_event+0x24ef>
    1cbb:      	addq	$0x10, %r15
    1cbf:      	leaq	0x58(%rsp), %rdi
    1cc4:      	movl	$0x8, %ecx
    1cc9:      	movl	$0x4, %eax
    1cce:      	movl	$0x8, %esi
    1cd3:      	movq	%r15, %rdx
    1cd6:      	callq	*%rax
    1cd8:      	movq	0x58(%rsp), %rdx
    1cdd:      	leaq	0x98(%rsp), %rdi
    1ce5:      	movl	$0x8, %ecx
    1cea:      	movl	$0x4, %eax
    1cef:      	movl	$0x8, %esi
    1cf4:      	callq	*%rax
    1cf6:      	movq	0x58(%rsp), %rdx
    1cfb:      	addq	$0x8, %rdx
    1cff:      	leaq	0x40(%rsp), %rdi
    1d04:      	movl	$0x8, %ecx
    1d09:      	movl	$0x4, %eax
    1d0e:      	movl	$0x8, %esi
    1d13:      	callq	*%rax
    1d15:      	movq	0x98(%rsp), %rdx
    1d1d:      	movq	0x40(%rsp), %r12
    1d22:      	cmpq	$0xfff, %r12            # imm = 0xFFF
    1d29:      	movl	$0xfff, %r15d           # imm = 0xFFF
    1d2f:      	cmovbq	%r12, %r15
    1d33:      	movq	0x18(%rsp), %rcx
    1d38:      	leaq	(%rcx,%r13), %rdi
    1d3c:      	addq	$0x98, %rdi
    1d43:      	movl	$0x4, %eax
    1d48:      	addq	%rcx, %r13
    1d4b:      	addq	$0x90, %r13
    1d52:      	movl	%r15d, %esi
    1d55:      	callq	*%rax
    1d57:      	testl	%eax, %eax
    1d59:      	js	0x2742 <generic_tracepoint_process_event+0x2742>
    1d5f:      	movl	%r12d, (%r13)
    1d63:      	movl	%r15d, 0x4(%r13)
    1d67:      	addq	$0x8, %r15
    1d6b:      	jmp	0x37df <generic_tracepoint_process_event+0x37df>
    1d70:      	movq	0x38(%rsp), %r12
    1d75:      	movq	0x20(%rsp), %r15
    1d7a:      	leaq	0x28(%r15), %rdi
    1d7e:      	leaq	0x98(%r12), %rdx
    1d86:      	movl	$0x4, %ecx
    1d8b:      	movl	$0x4, %eax
    1d90:      	movl	$0x4, %esi
    1d95:      	callq	*%rax
    1d97:      	leaq	0x2c(%r15), %rdi
    1d9b:      	leaq	0x70(%r12), %rdx
    1da0:      	movl	$0x4, %ecx
    1da5:      	movl	$0x4, %eax
    1daa:      	movl	$0x4, %esi
    1daf:      	callq	*%rax
    1db1:      	leaq	0x30(%r15), %rdi
    1db5:      	leaq	0x90(%r12), %rdx
    1dbd:      	movl	$0x4, %ecx
    1dc2:      	movl	$0x4, %eax
    1dc7:      	movl	$0x4, %esi
    1dcc:      	callq	*%rax
    1dce:      	leaq	0x34(%r15), %rdi
    1dd2:      	leaq	0xa8(%r12), %rdx
    1dda:      	movl	$0x4, %ecx
    1ddf:      	movl	$0x4, %eax
    1de4:      	movl	$0x4, %esi
    1de9:      	callq	*%rax
    1deb:      	movq	$0x0, 0x58(%rsp)
    1df4:      	leaq	0xc8(%r12), %rdx
    1dfc:      	leaq	0x58(%rsp), %rdi
    1e01:      	movl	$0x8, %ecx
    1e06:      	movl	$0x4, %eax
    1e0b:      	movl	$0x8, %esi
    1e10:      	callq	*%rax
    1e12:      	leaq	0xb8(%r12), %rdx
    1e1a:      	leaq	0xc0(%rsp), %rdi
    1e22:      	movl	$0x2, %ecx
    1e27:      	movl	$0x4, %eax
    1e2c:      	movl	$0x2, %esi
    1e31:      	callq	*%rax
    1e33:      	movzwl	0xc0(%rsp), %r15d
    1e3c:      	addq	0x58(%rsp), %r15
    1e41:      	leaq	0xaf(%rsp), %rdi
    1e49:      	movl	$0x1, %ecx
    1e4e:      	movl	$0x4, %eax
    1e53:      	movl	$0x1, %esi
    1e58:      	movq	%r15, %rdx
    1e5b:      	callq	*%rax
    1e5d:      	movzbl	0xaf(%rsp), %eax
    1e65:      	shrl	$0x4, %eax
    1e68:      	cmpl	$0x6, %eax
    1e6b:      	je	0x2517 <generic_tracepoint_process_event+0x2517>
    1e71:      	cmpl	$0x4, %eax
    1e74:      	jne	0x37d9 <generic_tracepoint_process_event+0x37d9>
    1e7a:      	leaq	0x9(%r15), %rdx
    1e7e:      	leaq	0xbc(%rsp), %rdi
    1e86:      	movl	$0x1, %ecx
    1e8b:      	movl	$0x4, %eax
    1e90:      	movl	$0x1, %esi
    1e95:      	callq	*%rax
    1e97:      	movzbl	0xbc(%rsp), %eax
    1e9f:      	movq	0x20(%rsp), %rdi
    1ea4:      	movw	%ax, 0x24(%rdi)
    1ea8:      	movw	$0x2, 0x26(%rdi)
    1eae:      	leaq	0xc(%r15), %rdx
    1eb2:      	movq	$0x0, (%rdi)
    1eb9:      	movq	$0x0, 0x8(%rdi)
    1ec1:      	movq	$0x0, 0x10(%rdi)
    1ec9:      	movq	$0x0, 0x18(%rdi)
    1ed1:      	movl	$0x4, %ecx
    1ed6:      	movl	$0x4, %eax
    1edb:      	leaq	0x10(%rdi), %r13
    1edf:      	movl	$0x4, %esi
    1ee4:      	callq	*%rax
    1ee6:      	addq	$0x10, %r15
    1eea:      	movl	$0x4, %ecx
    1eef:      	movl	$0x4, %eax
    1ef4:      	movq	%r13, %rdi
    1ef7:      	movl	$0x4, %esi
    1efc:      	movq	%r15, %rdx
    1eff:      	callq	*%rax
    1f01:      	leaq	0xb6(%r12), %rdx
    1f09:      	leaq	0xd8(%rsp), %rdi
    1f11:      	movl	$0x2, %ecx
    1f16:      	movl	$0x4, %eax
    1f1b:      	movl	$0x2, %esi
    1f20:      	callq	*%rax
    1f22:      	movzbl	0xbc(%rsp), %ebp
    1f2a:      	jmp	0x3671 <generic_tracepoint_process_event+0x3671>
    1f2f:      	movl	$0x120, %edx            # imm = 0x120
    1f34:      	addq	0x38(%rsp), %rdx
    1f39:      	movq	0x20(%rsp), %r12
    1f3e:      	leaq	0x4(%r12), %rdi
    1f43:      	movl	$0x11, %ecx
    1f48:      	movl	$0x2d, %eax
    1f4d:      	movl	$0x11, %esi
    1f52:      	callq	*%rax
    1f54:      	movq	%rax, %r15
    1f57:      	testq	%rax, %rax
    1f5a:      	js	0x28d7 <generic_tracepoint_process_event+0x28d7>
    1f60:      	leal	-0x1(%r15), %eax
    1f64:      	movl	%eax, (%r12)
    1f68:      	addq	$0x3, %r15
    1f6c:      	jmp	0x28d7 <generic_tracepoint_process_event+0x28d7>
    1f71:      	movq	0x38(%rsp), %r15
    1f76:      	movq	0x20(%rsp), %r12
    1f7b:      	movq	$0x0, 0x10(%r12)
    1f84:      	movq	$0x0, 0x8(%r12)
    1f8d:      	movq	$0x0, (%r12)
    1f95:      	movl	$0x2, %ecx
    1f9a:      	movl	$0x4, %eax
    1f9f:      	movq	%r12, %rdi
    1fa2:      	movl	$0x2, %esi
    1fa7:      	movq	%r15, %rdx
    1faa:      	callq	*%rax
    1fac:      	testq	%rax, %rax
    1faf:      	js	0x27ca <generic_tracepoint_process_event+0x27ca>
    1fb5:      	movzwl	(%r12), %eax
    1fba:      	cmpl	$0xa, %eax
    1fbd:      	je	0x2775 <generic_tracepoint_process_event+0x2775>
    1fc3:      	cmpl	$0x2, %eax
    1fc6:      	jne	0x27b1 <generic_tracepoint_process_event+0x27b1>
    1fcc:      	leaq	0x4(%r15), %rdx
    1fd0:      	leaq	0x58(%rsp), %rdi
    1fd5:      	movl	$0x4, %ecx
    1fda:      	movl	$0x4, %eax
    1fdf:      	movl	$0x4, %esi
    1fe4:      	callq	*%rax
    1fe6:      	movl	0x58(%rsp), %eax
    1fea:      	movq	0x20(%rsp), %rcx
    1fef:      	movq	%rax, 0x8(%rcx)
    1ff3:      	leaq	0x2(%rcx), %rdi
    1ff7:      	addq	$0x2, %r15
    1ffb:      	movl	$0x2, %ecx
    2000:      	movl	$0x4, %eax
    2005:      	jmp	0x27a7 <generic_tracepoint_process_event+0x27a7>
    200a:      	movq	%rax, %r15
    200d:      	movq	0x30(%rsp), %rcx
    2012:      	leaq	(%rax,%rcx), %rbp
    2016:      	addq	$0x90, %rbp
    201d:      	movq	$0x0, 0xc8(%rsp)
    2029:      	testb	$0x10, %r13b
    202d:      	jne	0x2679 <generic_tracepoint_process_event+0x2679>
    2033:      	andl	$0xf, %r13d
    2037:      	xorl	%eax, %eax
    2039:      	cmpl	$0x2, %r13d
    203d:      	jle	0x28f7 <generic_tracepoint_process_event+0x28f7>
    2043:      	cmpl	$0x3, %r13d
    2047:      	je	0x2fbf <generic_tracepoint_process_event+0x2fbf>
    204d:      	cmpl	$0x4, %r13d
    2051:      	je	0x2fc8 <generic_tracepoint_process_event+0x2fc8>
    2057:      	cmpl	$0x5, %r13d
    205b:      	jne	0x2fdb <generic_tracepoint_process_event+0x2fdb>
    2061:      	addq	$0x5e70, %r15           # imm = 0x5E70
    2068:      	jmp	0x2fd8 <generic_tracepoint_process_event+0x2fd8>
    206d:      	leaq	0x28(%rbp), %r13
    2071:      	leaq	0x40(%rbp), %r15
    2075:      	movq	0x18(%rsp), %r12
    207a:      	leaq	0x8(%r12), %rdx
    207f:      	movl	$0x4, %ecx
    2084:      	movl	$0x4, %eax
    2089:      	movq	%rbp, %rdi
    208c:      	movl	$0x4, %esi
    2091:      	callq	*%rax
    2093:      	leaq	0x4(%rbp), %rdi
    2097:      	leaq	0xc(%r12), %rdx
    209c:      	movl	$0x4, %ecx
    20a1:      	movl	$0x4, %eax
    20a6:      	movl	$0x4, %esi
    20ab:      	callq	*%rax
    20ad:      	leaq	0x10(%rbp), %rdi
    20b1:      	leaq	0x18(%r12), %rdx
    20b6:      	movl	$0x4, %ecx
    20bb:      	movl	$0x4, %eax
    20c0:      	movl	$0x4, %esi
    20c5:      	callq	*%rax
    20c7:      	leaq	0x14(%rbp), %rdi
    20cb:      	leaq	0x1c(%r12), %rdx
    20d0:      	movl	$0x4, %ecx
    20d5:      	movl	$0x4, %eax
    20da:      	movl	$0x4, %esi
    20df:      	callq	*%rax
    20e1:      	leaq	0x8(%rbp), %rdi
    20e5:      	leaq	0x10(%r12), %rdx
    20ea:      	movl	$0x4, %ecx
    20ef:      	movl	$0x4, %eax
    20f4:      	movl	$0x4, %esi
    20f9:      	callq	*%rax
    20fb:      	leaq	0xc(%rbp), %rdi
    20ff:      	leaq	0x14(%r12), %rdx
    2104:      	movl	$0x4, %ecx
    2109:      	movl	$0x4, %eax
    210e:      	movl	$0x4, %esi
    2113:      	callq	*%rax
    2115:      	leaq	0x18(%rbp), %rdi
    2119:      	leaq	0x20(%r12), %rdx
    211e:      	movl	$0x4, %ecx
    2123:      	movl	$0x4, %eax
    2128:      	movl	$0x4, %esi
    212d:      	callq	*%rax
    212f:      	leaq	0x1c(%rbp), %rdi
    2133:      	leaq	0x24(%r12), %rdx
    2138:      	movl	$0x4, %ecx
    213d:      	movl	$0x4, %eax
    2142:      	movl	$0x4, %esi
    2147:      	callq	*%rax
    2149:      	movl	$0x0, 0x24(%rbp)
    2150:      	leaq	0x20(%rbp), %rdi
    2154:      	leaq	0x28(%r12), %rdx
    2159:      	movl	$0x4, %ecx
    215e:      	movl	$0x4, %eax
    2163:      	movl	$0x4, %esi
    2168:      	callq	*%rax
    216a:      	leaq	0x30(%rbp), %rdi
    216e:      	leaq	0x40(%r12), %rdx
    2173:      	movl	$0x8, %ecx
    2178:      	movl	$0x4, %eax
    217d:      	movl	$0x8, %esi
    2182:      	callq	*%rax
    2184:      	leaq	0x38(%rbp), %rdi
    2188:      	leaq	0x30(%r12), %rdx
    218d:      	movl	$0x8, %ecx
    2192:      	movl	$0x4, %eax
    2197:      	movl	$0x8, %esi
    219c:      	callq	*%rax
    219e:      	leaq	0x38(%r12), %rdx
    21a3:      	movl	$0x8, %ecx
    21a8:      	movl	$0x4, %eax
    21ad:      	movq	%r13, %rdi
    21b0:      	movl	$0x8, %esi
    21b5:      	callq	*%rax
    21b7:      	addq	$0x90, %r12
    21be:      	leaq	0x58(%rsp), %rdi
    21c3:      	movl	$0x8, %ecx
    21c8:      	movl	$0x4, %eax
    21cd:      	movl	$0x8, %esi
    21d2:      	movq	%r12, %rdx
    21d5:      	callq	*%rax
    21d7:      	movq	0x58(%rsp), %r12
    21dc:      	leaq	0xc8(%r12), %rdx
    21e4:      	movl	$0x4, %ecx
    21e9:      	movl	$0x4, %eax
    21ee:      	movq	%r15, %rdi
    21f1:      	movl	$0x4, %esi
    21f6:      	callq	*%rax
    21f8:      	leaq	0x44(%rbp), %rdi
    21fc:      	leaq	0xcc(%r12), %rdx
    2204:      	movl	$0x4, %ecx
    2209:      	movl	$0x4, %eax
    220e:      	movl	$0x4, %esi
    2213:      	callq	*%rax
    2215:      	leaq	0x48(%rbp), %rdi
    2219:      	leaq	0xd0(%r12), %rdx
    2221:      	movl	$0x4, %ecx
    2226:      	movl	$0x4, %eax
    222b:      	movl	$0x4, %esi
    2230:      	callq	*%rax
    2232:      	addq	$0x4c, %rbp
    2236:      	addq	$0x158, %r12            # imm = 0x158
    223d:      	movl	$0x4, %ecx
    2242:      	movl	$0x4, %eax
    2247:      	movq	%rbp, %rdi
    224a:      	movl	$0x4, %esi
    224f:      	movq	%r12, %rdx
    2252:      	callq	*%rax
    2254:      	movl	$0x50, %r15d
    225a:      	jmp	0x2461 <generic_tracepoint_process_event+0x2461>
    225f:      	movq	0x18(%rsp), %r15
    2264:      	leaq	0xc8(%r15), %rdx
    226b:      	movl	$0x4, %ecx
    2270:      	movl	$0x4, %eax
    2275:      	movq	%rbp, %rdi
    2278:      	movl	$0x4, %esi
    227d:      	callq	*%rax
    227f:      	leaq	0x4(%rbp), %rdi
    2283:      	leaq	0xcc(%r15), %rdx
    228a:      	movl	$0x4, %ecx
    228f:      	movl	$0x4, %eax
    2294:      	movl	$0x4, %esi
    2299:      	callq	*%rax
    229b:      	leaq	0x8(%rbp), %rdi
    229f:      	leaq	0xd0(%r15), %rdx
    22a6:      	movl	$0x4, %ecx
    22ab:      	movl	$0x4, %eax
    22b0:      	movl	$0x4, %esi
    22b5:      	callq	*%rax
    22b7:      	addq	$0xc, %rbp
    22bb:      	addq	$0x158, %r15            # imm = 0x158
    22c2:      	movl	$0x4, %ecx
    22c7:      	movl	$0x4, %eax
    22cc:      	movq	%rbp, %rdi
    22cf:      	movl	$0x4, %esi
    22d4:      	movq	%r15, %rdx
    22d7:      	callq	*%rax
    22d9:      	movl	$0x10, %r15d
    22df:      	jmp	0x2461 <generic_tracepoint_process_event+0x2461>
    22e4:      	movq	0x18(%rsp), %r15
    22e9:      	leaq	0x38(%r15), %rdx
    22ed:      	movl	$0x4, %ecx
    22f2:      	movl	$0x4, %eax
    22f7:      	movq	%rbp, %rdi
    22fa:      	movl	$0x4, %esi
    22ff:      	callq	*%rax
    2301:      	leaq	0x4(%rbp), %rdi
    2305:      	leaq	0x3c(%r15), %rdx
    2309:      	movl	$0x4, %ecx
    230e:      	movl	$0x4, %eax
    2313:      	movl	$0x4, %esi
    2318:      	callq	*%rax
    231a:      	leaq	0x8(%rbp), %rdi
    231e:      	leaq	0x40(%r15), %rdx
    2322:      	movl	$0x4, %ecx
    2327:      	movl	$0x4, %eax
    232c:      	movl	$0x4, %esi
    2331:      	callq	*%rax
    2333:      	leaq	0xc(%rbp), %rdi
    2337:      	leaq	0x44(%r15), %rdx
    233b:      	movl	$0x4, %ecx
    2340:      	movl	$0x4, %eax
    2345:      	movl	$0x4, %esi
    234a:      	callq	*%rax
    234c:      	addq	$0x10, %rbp
    2350:      	subq	$-0x80, %r15
    2354:      	movl	$0x10, %ecx
    2359:      	movl	$0x4, %eax
    235e:      	movq	%rbp, %rdi
    2361:      	movl	$0x10, %esi
    2366:      	movq	%r15, %rdx
    2369:      	callq	*%rax
    236b:      	movl	$0x20, %r15d
    2371:      	jmp	0x2461 <generic_tracepoint_process_event+0x2461>
    2376:      	movl	$0x4, %ecx
    237b:      	movl	$0x4, %eax
    2380:      	movq	0x18(%rsp), %r15
    2385:      	movq	%rbp, %rdi
    2388:      	movl	$0x4, %esi
    238d:      	movq	%r15, %rdx
    2390:      	callq	*%rax
    2392:      	leaq	0x4(%rbp), %rdi
    2396:      	leaq	0x4(%r15), %rdx
    239a:      	movl	$0x4, %ecx
    239f:      	movl	$0x4, %eax
    23a4:      	movl	$0x4, %esi
    23a9:      	callq	*%rax
    23ab:      	addq	$0x8, %rbp
    23af:      	addq	$0x30, %r15
    23b3:      	movl	$0x10, %ecx
    23b8:      	movl	$0x4, %eax
    23bd:      	movq	%rbp, %rdi
    23c0:      	movl	$0x10, %esi
    23c5:      	movq	%r15, %rdx
    23c8:      	jmp	0x2459 <generic_tracepoint_process_event+0x2459>
    23cd:      	movq	0x18(%rsp), %r15
    23d2:      	leaq	0x4(%r15), %rdx
    23d6:      	leaq	0x58(%rsp), %rdi
    23db:      	movl	$0x4, %ecx
    23e0:      	movl	$0x4, %eax
    23e5:      	movl	$0x4, %esi
    23ea:      	callq	*%rax
    23ec:      	movl	0x58(%rsp), %eax
    23f0:      	movl	%eax, (%rbp)
    23f3:      	leaq	0xc(%r15), %rdx
    23f7:      	leaq	0x58(%rsp), %rdi
    23fc:      	movl	$0x4, %ecx
    2401:      	movl	$0x4, %eax
    2406:      	movl	$0x4, %esi
    240b:      	callq	*%rax
    240d:      	movl	0x58(%rsp), %eax
    2411:      	movl	%eax, 0x4(%rbp)
    2414:      	addq	$0x50, %r15
    2418:      	leaq	0x58(%rsp), %rdi
    241d:      	movl	$0x8, %ecx
    2422:      	movl	$0x2d, %eax
    2427:      	movl	$0x8, %esi
    242c:      	movq	%r15, %rdx
    242f:      	callq	*%rax
    2431:      	addq	$0x8, %rbp
    2435:      	movl	$0x3f8, %edx            # imm = 0x3F8
    243a:      	movq	0x58(%rsp), %rcx
    243f:      	addq	%rdx, %rcx
    2442:      	movl	$0x10, %esi
    2447:      	movl	$0x2d, %eax
    244c:      	addq	0x58(%rsp), %rdx
    2451:      	movq	%rbp, %rdi
    2454:      	movl	$0x10, %esi
    2459:      	callq	*%rax
    245b:      	movl	$0x18, %r15d
    2461:      	movq	0x10(%rsp), %rcx
    2466:      	movq	0x8(%rsp), %rdx
    246b:      	jmp	0x305b <generic_tracepoint_process_event+0x305b>
    2470:      	movq	$0x0, 0x48(%rbp)
    2478:      	movq	$0x0, 0x40(%rbp)
    2480:      	movq	$0x0, 0x38(%rbp)
    2488:      	movq	$0x0, 0x30(%rbp)
    2490:      	movq	$0x0, 0x28(%rbp)
    2498:      	movq	$0x0, 0x20(%rbp)
    24a0:      	movq	$0x0, 0x18(%rbp)
    24a8:      	movq	$0x0, 0x10(%rbp)
    24b0:      	movq	$0x0, 0x8(%rbp)
    24b8:      	movq	%rbp, %r12
    24bb:      	movq	$0x0, (%rbp)
    24c3:      	leaq	0x58(%rsp), %rdi
    24c8:      	movl	$0x8, %ecx
    24cd:      	movl	$0x4, %eax
    24d2:      	movq	0x18(%rsp), %rdx
    24d7:      	movl	$0x8, %esi
    24dc:      	callq	*%rax
    24de:      	testq	%rax, %rax
    24e1:      	je	0x27d5 <generic_tracepoint_process_event+0x27d5>
    24e7:      	xorl	%r15d, %r15d
    24ea:      	jmp	0x304c <generic_tracepoint_process_event+0x304c>
    24ef:      	movq	0x18(%rsp), %rax
    24f4:      	movq	$0x0, 0x90(%rax,%r13)
    2500:      	movl	$0x8, %r15d
    2506:      	jmp	0x28d7 <generic_tracepoint_process_event+0x28d7>
    250b:      	movq	$-0x1, %r15
    2512:      	jmp	0x37df <generic_tracepoint_process_event+0x37df>
    2517:      	movq	0x58(%rsp), %rcx
    251c:      	movl	$0x0, 0x98(%rsp)
    2527:      	movzwl	0xc0(%rsp), %ebp
    252f:      	movq	(%rip), %rdi            # 0x2536 <generic_tracepoint_process_event+0x2536>
    2536:      	leaq	0x98(%rsp), %rsi
    253e:      	movl	$0x1, %eax
    2543:      	movq	%rcx, 0x18(%rsp)
    2548:      	leaq	(%rcx,%rbp), %r13
    254c:      	callq	*%rax
    254e:      	testq	%rax, %rax
    2551:      	je	0x361e <generic_tracepoint_process_event+0x361e>
    2557:      	movq	%rax, %r15
    255a:      	movw	%bp, (%rax)
    255d:      	movb	$-0x1, 0x5(%rax)
    2561:      	movb	$0x0, 0x7(%rax)
    2565:      	movq	%rax, %rdi
    2568:      	addq	$0x6, %rdi
    256c:      	leaq	0x6(%r13), %rdx
    2570:      	movl	$0x1, %ecx
    2575:      	movl	$0x4, %eax
    257a:      	movq	%rdi, 0x30(%rsp)
    257f:      	movl	$0x1, %esi
    2584:      	callq	*%rax
    2586:      	testq	%rax, %rax
    2589:      	js	0x361e <generic_tracepoint_process_event+0x361e>
    258f:      	movzbl	0x5(%r15), %eax
    2594:      	cmpl	$0x32, %eax
    2597:      	jg	0x2f08 <generic_tracepoint_process_event+0x2f08>
    259d:      	testl	%eax, %eax
    259f:      	je	0x2fae <generic_tracepoint_process_event+0x2fae>
    25a5:      	cmpl	$0x2b, %eax
    25a8:      	je	0x2fae <generic_tracepoint_process_event+0x2fae>
    25ae:      	cmpl	$0x2c, %eax
    25b1:      	jne	0x319f <generic_tracepoint_process_event+0x319f>
    25b7:      	movw	$0x8, 0x2(%r15)
    25be:      	movw	$0x8, %ax
    25c2:      	jmp	0x30e9 <generic_tracepoint_process_event+0x30e9>
    25c7:      	leaq	0x48(%r15), %rdx
    25cb:      	movl	$0x10, %ecx
    25d0:      	movl	$0x4, %eax
    25d5:      	movq	%rbp, %rdi
    25d8:      	movl	$0x10, %esi
    25dd:      	callq	*%rax
    25df:      	leaq	0x38(%r15), %rdx
    25e3:      	movl	$0x10, %ecx
    25e8:      	movl	$0x4, %eax
    25ed:      	movq	%r12, %rdi
    25f0:      	movl	$0x10, %esi
    25f5:      	callq	*%rax
    25f7:      	leaq	0x20(%rbp), %rdi
    25fb:      	leaq	0xc(%r15), %r12
    25ff:      	addq	$0xe, %r15
    2603:      	movl	$0x2, %ecx
    2608:      	movl	$0x4, %eax
    260d:      	movl	$0x2, %esi
    2612:      	movq	%r15, %rdx
    2615:      	callq	*%rax
    2617:      	leaq	0x22(%rbp), %rdi
    261b:      	movl	$0x2, %ecx
    2620:      	movl	$0x4, %eax
    2625:      	movl	$0x2, %esi
    262a:      	movq	%r12, %rdx
    262d:      	callq	*%rax
    262f:      	movzwl	0x22(%rbp), %eax
    2633:      	movbew	%ax, 0x22(%rbp)
    2639:      	movq	0x38(%rsp), %rax
    263e:      	movq	%rax, 0x58(%rsp)
    2643:      	movq	(%rip), %rdi            # 0x264a <generic_tracepoint_process_event+0x264a>
    264a:      	leaq	0x58(%rsp), %rsi
    264f:      	movl	$0x1, %eax
    2654:      	callq	*%rax
    2656:      	testq	%rax, %rax
    2659:      	je	0x37d9 <generic_tracepoint_process_event+0x37d9>
    265f:      	movl	(%rax), %ecx
    2661:      	movl	%ecx, 0x10(%r13)
    2665:      	movq	0x8(%rax), %rcx
    2669:      	movq	%rcx, 0x18(%r13)
    266d:      	movl	0x4(%rax), %eax
    2670:      	movl	%eax, 0x7c(%r13)
    2674:      	jmp	0x37d9 <generic_tracepoint_process_event+0x37d9>
    2679:      	movl	$0xe, %eax
    267e:      	callq	*%rax
    2680:      	cmpq	$-0x16, %rax
    2684:      	jne	0x26aa <generic_tracepoint_process_event+0x26aa>
    2686:      	movq	0x28(%rsp), %rax
    268b:      	leaq	0x20(%rax), %rdx
    268f:      	leaq	0x58(%rsp), %rdi
    2694:      	movl	$0x8, %ecx
    2699:      	movl	$0x4, %eax
    269e:      	movl	$0x8, %esi
    26a3:      	callq	*%rax
    26a5:      	movq	0x58(%rsp), %rax
    26aa:      	movq	0x8(%r15), %rcx
    26ae:      	movq	0x60(%r15), %rdx
    26b2:      	movq	%rcx, 0x58(%rsp)
    26b7:      	movq	0x18(%rsp), %rcx
    26bc:      	movq	%rcx, 0x60(%rsp)
    26c1:      	movq	$0x0, 0x68(%rsp)
    26ca:      	movq	%rdx, 0x98(%rsp)
    26d2:      	movq	%rax, 0xa0(%rsp)
    26da:      	movq	(%rip), %rdi            # 0x26e1 <generic_tracepoint_process_event+0x26e1>
    26e1:      	xorl	%ecx, %ecx
    26e3:      	leaq	0x98(%rsp), %rsi
    26eb:      	leaq	0x58(%rsp), %rdx
    26f0:      	movl	$0x2, %eax
    26f5:      	xorl	%ecx, %ecx
    26f7:      	callq	*%rax
    26f9:      	testq	%rax, %rax
    26fc:      	je	0x2f5f <generic_tracepoint_process_event+0x2f5f>
    2702:      	negl	%eax
    2704:      	movw	%ax, 0x40(%rsp)
    2709:      	movw	$0x5, 0x42(%rsp)
    2710:      	movabsq	$0x200000046, %rax      # imm = 0x200000046
    271a:      	movq	%rax, 0x44(%rsp)
    271f:      	movq	(%rip), %rdi            # 0x2726 <generic_tracepoint_process_event+0x2726>
    2726:      	leaq	0x40(%rsp), %rsi
    272b:      	movl	$0x1, %eax
    2730:      	callq	*%rax
    2732:      	testq	%rax, %rax
    2735:      	je	0x2f35 <generic_tracepoint_process_event+0x2f35>
    273b:      	incl	(%rax)
    273d:      	jmp	0x2f5f <generic_tracepoint_process_event+0x2f5f>
    2742:      	movl	$0xfffffffe, (%r13)     # imm = 0xFFFFFFFE
    274a:      	movl	$0x4, %r15d
    2750:      	jmp	0x37df <generic_tracepoint_process_event+0x37df>
    2755:      	cmpl	$0x1, %eax
    2758:      	je	0x29ea <generic_tracepoint_process_event+0x29ea>
    275e:      	cmpl	$0x2, %eax
    2761:      	jne	0x2dff <generic_tracepoint_process_event+0x2dff>
    2767:      	movq	%rbp, %rax
    276a:      	addq	$0x5e58, %rax           # imm = 0x5E58
    2770:      	jmp	0x29f3 <generic_tracepoint_process_event+0x29f3>
    2775:      	movq	0x20(%rsp), %r12
    277a:      	leaq	0x8(%r12), %rdi
    277f:      	leaq	0x8(%r15), %rdx
    2783:      	movl	$0x10, %ecx
    2788:      	movl	$0x4, %eax
    278d:      	movl	$0x10, %esi
    2792:      	callq	*%rax
    2794:      	leaq	0x2(%r12), %rdi
    2799:      	addq	$0x2, %r15
    279d:      	movl	$0x2, %ecx
    27a2:      	movl	$0x4, %eax
    27a7:      	movl	$0x2, %esi
    27ac:      	movq	%r15, %rdx
    27af:      	callq	*%rax
    27b1:      	movq	0x20(%rsp), %rcx
    27b6:      	movzwl	0x2(%rcx), %eax
    27ba:      	movbew	%ax, 0x2(%rcx)
    27c0:      	movq	0x50(%rsp), %rbp
    27c5:      	movq	0x28(%rsp), %rbx
    27ca:      	movl	$0x18, %r15d
    27d0:      	jmp	0x28d7 <generic_tracepoint_process_event+0x28d7>
    27d5:      	leaq	0x10(%r12), %rdi
    27da:      	movq	0x58(%rsp), %rcx
    27df:      	movl	$0x3f, %edx
    27e4:      	movl	$0x2d, %eax
    27e9:      	movq	0x58(%rsp), %rdx
    27ee:      	movl	$0x3f, %esi
    27f3:      	callq	*%rax
    27f5:      	testq	%rax, %rax
    27f8:      	js	0x24e7 <generic_tracepoint_process_event+0x24e7>
    27fe:      	movq	0x18(%rsp), %r15
    2803:      	leaq	0x8(%r15), %rdx
    2807:      	leaq	0x98(%rsp), %rdi
    280f:      	movl	$0x8, %ecx
    2814:      	movl	$0x4, %eax
    2819:      	movl	$0x8, %esi
    281e:      	callq	*%rax
    2820:      	leaq	0x8(%r12), %rdi
    2825:      	movl	$0x348, %edx            # imm = 0x348
    282a:      	movq	0x98(%rsp), %rcx
    2832:      	addq	%rdx, %rcx
    2835:      	movl	$0x8, %esi
    283a:      	movl	$0x4, %eax
    283f:      	addq	0x98(%rsp), %rdx
    2847:      	movl	$0x8, %esi
    284c:      	callq	*%rax
    284e:      	addq	$0x58, %r15
    2852:      	leaq	0x98(%rsp), %rdi
    285a:      	movl	$0x4, %ecx
    285f:      	movl	$0x4, %eax
    2864:      	movl	$0x4, %esi
    2869:      	movq	%r15, %rdx
    286c:      	callq	*%rax
    286e:      	movl	$0x50, %r15d
    2874:      	testq	%rax, %rax
    2877:      	jne	0x304c <generic_tracepoint_process_event+0x304c>
    287d:      	xorl	%eax, %eax
    287f:      	cmpl	$0x0, 0x98(%rsp)
    2887:      	setne	%al
    288a:      	movl	%eax, (%r12)
    288e:      	jmp	0x304c <generic_tracepoint_process_event+0x304c>
    2893:      	xorl	%r15d, %r15d
    2896:      	movq	%r12, %rcx
    2899:      	jmp	0x3051 <generic_tracepoint_process_event+0x3051>
    289e:      	addq	$0x3, %r15
    28a2:      	movl	$0x6b, %ecx
    28a7:      	movl	$0x71, %eax
    28ac:      	movl	$0x6b, %esi
    28b1:      	movq	%r15, %rdx
    28b4:      	callq	*%rax
    28b6:      	movq	%rax, %rcx
    28b9:      	movb	$0x6b, %al
    28bb:      	testl	%ecx, %ecx
    28bd:      	movq	0x50(%rsp), %rbp
    28c2:      	movq	0x28(%rsp), %rbx
    28c7:      	js	0x28d1 <generic_tracepoint_process_event+0x28d1>
    28c9:      	movq	0x20(%rsp), %rcx
    28ce:      	movb	%al, 0x3(%rcx)
    28d1:      	movl	$0x70, %r15d
    28d7:      	movq	0x10(%rsp), %rcx
    28dc:      	movq	0x8(%rsp), %rdx
    28e1:      	movq	0xd0(%rsp), %r12
    28e9:      	testl	%r15d, %r15d
    28ec:      	jns	0x138c <generic_tracepoint_process_event+0x138c>
    28f2:      	jmp	0x3071 <generic_tracepoint_process_event+0x3071>
    28f7:      	cmpl	$0x1, %r13d
    28fb:      	je	0x2fd1 <generic_tracepoint_process_event+0x2fd1>
    2901:      	cmpl	$0x2, %r13d
    2905:      	jne	0x2fdb <generic_tracepoint_process_event+0x2fdb>
    290b:      	addq	$0x5e58, %r15           # imm = 0x5E58
    2912:      	jmp	0x2fd8 <generic_tracepoint_process_event+0x2fd8>
    2917:      	leaq	0x48(%r15), %rdx
    291b:      	movl	$0x10, %ecx
    2920:      	movl	$0x4, %eax
    2925:      	movq	%r13, %rdi
    2928:      	movl	$0x10, %esi
    292d:      	callq	*%rax
    292f:      	leaq	0x38(%r15), %rdx
    2933:      	movl	$0x10, %ecx
    2938:      	movl	$0x4, %eax
    293d:      	movq	%r12, %rdi
    2940:      	movl	$0x10, %esi
    2945:      	callq	*%rax
    2947:      	movq	%r13, %rbp
    294a:      	leaq	0x20(%r13), %rdi
    294e:      	leaq	0xc(%r15), %r12
    2952:      	addq	$0xe, %r15
    2956:      	movl	$0x2, %ecx
    295b:      	movl	$0x4, %eax
    2960:      	movl	$0x2, %esi
    2965:      	movq	%r15, %rdx
    2968:      	callq	*%rax
    296a:      	leaq	0x22(%r13), %rdi
    296e:      	movl	$0x2, %ecx
    2973:      	movl	$0x4, %eax
    2978:      	movl	$0x2, %esi
    297d:      	movq	%r12, %rdx
    2980:      	callq	*%rax
    2982:      	movzwl	0x22(%r13), %eax
    2987:      	movbew	%ax, 0x22(%r13)
    298e:      	movq	0x28(%rbp), %rax
    2992:      	movq	%rax, 0x58(%rsp)
    2997:      	movq	(%rip), %rdi            # 0x299e <generic_tracepoint_process_event+0x299e>
    299e:      	leaq	0x58(%rsp), %rsi
    29a3:      	movl	$0x1, %eax
    29a8:      	callq	*%rax
    29aa:      	testq	%rax, %rax
    29ad:      	je	0x29c9 <generic_tracepoint_process_event+0x29c9>
    29af:      	movl	(%rax), %ecx
    29b1:      	movq	0x30(%rsp), %r13
    29b6:      	movl	%ecx, 0x10(%r13)
    29ba:      	movq	0x8(%rax), %rcx
    29be:      	movq	%rcx, 0x18(%r13)
    29c2:      	movl	0x4(%rax), %eax
    29c5:      	movl	%eax, 0x7c(%r13)
    29c9:      	movl	$0x40, %r15d
    29cf:      	jmp	0x304c <generic_tracepoint_process_event+0x304c>
    29d4:      	movq	%rbp, %rax
    29d7:      	addq	$0x5e60, %rax           # imm = 0x5E60
    29dd:      	jmp	0x29f3 <generic_tracepoint_process_event+0x29f3>
    29df:      	movq	%rbp, %rax
    29e2:      	addq	$0x5e68, %rax           # imm = 0x5E68
    29e8:      	jmp	0x29f3 <generic_tracepoint_process_event+0x29f3>
    29ea:      	movq	%rbp, %rax
    29ed:      	addq	$0x5e50, %rax           # imm = 0x5E50
    29f3:      	movq	(%rax), %r12
    29f6:      	testb	$0x10, %sil
    29fa:      	jne	0x2e19 <generic_tracepoint_process_event+0x2e19>
    2a00:      	testq	%r12, %r12
    2a03:      	je	0x2ede <generic_tracepoint_process_event+0x2ede>
    2a09:      	leaq	0x58(%rsp), %rdi
    2a0e:      	movl	$0x4, %r15d
    2a14:      	movl	$0x10, %ecx
    2a19:      	movl	$0x4, %eax
    2a1e:      	movq	0x18(%rsp), %rdx
    2a23:      	movl	$0x10, %esi
    2a28:      	callq	*%rax
    2a2a:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2a2f:      	testl	%eax, %eax
    2a31:      	js	0x2df0 <generic_tracepoint_process_event+0x2df0>
    2a37:      	movq	0x60(%rsp), %rdx
    2a3c:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2a41:      	movq	%rdx, %rax
    2a44:      	movq	%rdx, 0xb0(%rsp)
    2a4c:      	cmpq	$0xffe, %rdx            # imm = 0xFFE
    2a53:      	ja	0x2df0 <generic_tracepoint_process_event+0x2df0>
    2a59:      	movq	0x50(%rsp), %rax
    2a5e:      	leaq	0xc(%rax), %rbp
    2a62:      	movq	%r13, %rdi
    2a65:      	addq	%rbp, %rdi
    2a68:      	movq	0x58(%rsp), %rcx
    2a6d:      	movl	$0x4, %eax
    2a72:      	movq	0xb0(%rsp), %rsi
    2a7a:      	movq	0x58(%rsp), %rdx
    2a7f:      	callq	*%rax
    2a81:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2a86:      	testl	%eax, %eax
    2a88:      	js	0x2df0 <generic_tracepoint_process_event+0x2df0>
    2a8e:      	cmpq	$0x1, %r12
    2a92:      	je	0x2ee8 <generic_tracepoint_process_event+0x2ee8>
    2a98:      	movq	0x18(%rsp), %rax
    2a9d:      	leaq	0x10(%rax), %rdx
    2aa1:      	leaq	0x58(%rsp), %rdi
    2aa6:      	movl	$0x4, %r15d
    2aac:      	movl	$0x10, %ecx
    2ab1:      	movl	$0x4, %eax
    2ab6:      	movl	$0x10, %esi
    2abb:      	callq	*%rax
    2abd:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2ac2:      	testl	%eax, %eax
    2ac4:      	js	0x2df0 <generic_tracepoint_process_event+0x2df0>
    2aca:      	movq	0x60(%rsp), %rax
    2acf:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2ad4:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    2ada:      	ja	0x2df0 <generic_tracepoint_process_event+0x2df0>
    2ae0:      	movq	%rax, %rbx
    2ae3:      	addq	0xb0(%rsp), %rbp
    2aeb:      	movq	%r13, %rdi
    2aee:      	addq	%rbp, %rdi
    2af1:      	movq	0x58(%rsp), %rcx
    2af6:      	movl	$0x4, %eax
    2afb:      	movq	%rbx, %rsi
    2afe:      	movq	0x58(%rsp), %rdx
    2b03:      	callq	*%rax
    2b05:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2b0a:      	testl	%eax, %eax
    2b0c:      	js	0x2df0 <generic_tracepoint_process_event+0x2df0>
    2b12:      	addq	%rbx, 0xb0(%rsp)
    2b1a:      	cmpq	$0x3, %r12
    2b1e:      	jb	0x2ee8 <generic_tracepoint_process_event+0x2ee8>
    2b24:      	movq	0x18(%rsp), %rax
    2b29:      	leaq	0x20(%rax), %rdx
    2b2d:      	leaq	0x58(%rsp), %rdi
    2b32:      	movl	$0x4, %r15d
    2b38:      	movl	$0x10, %ecx
    2b3d:      	movl	$0x4, %eax
    2b42:      	movl	$0x10, %esi
    2b47:      	callq	*%rax
    2b49:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2b4e:      	testl	%eax, %eax
    2b50:      	js	0x2df0 <generic_tracepoint_process_event+0x2df0>
    2b56:      	movq	0x60(%rsp), %rax
    2b5b:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2b60:      	movq	%rax, 0x20(%rsp)
    2b65:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    2b6b:      	ja	0x2df0 <generic_tracepoint_process_event+0x2df0>
    2b71:      	movq	%rbx, %rdi
    2b74:      	addq	%rbp, %rdi
    2b77:      	movq	%rdi, %rbx
    2b7a:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2b80:      	addq	%r13, %rdi
    2b83:      	movq	0x58(%rsp), %rcx
    2b88:      	movl	$0x4, %eax
    2b8d:      	movq	0x20(%rsp), %rsi
    2b92:      	movq	0x58(%rsp), %rdx
    2b97:      	callq	*%rax
    2b99:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2b9e:      	testl	%eax, %eax
    2ba0:      	js	0x2df0 <generic_tracepoint_process_event+0x2df0>
    2ba6:      	movq	0x20(%rsp), %rax
    2bab:      	addq	%rax, 0xb0(%rsp)
    2bb3:      	cmpq	$0x3, %r12
    2bb7:      	je	0x2ee8 <generic_tracepoint_process_event+0x2ee8>
    2bbd:      	movq	0x18(%rsp), %rax
    2bc2:      	leaq	0x30(%rax), %rdx
    2bc6:      	leaq	0x58(%rsp), %rdi
    2bcb:      	movl	$0x4, %r15d
    2bd1:      	movl	$0x10, %ecx
    2bd6:      	movl	$0x4, %eax
    2bdb:      	movl	$0x10, %esi
    2be0:      	callq	*%rax
    2be2:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2be7:      	testl	%eax, %eax
    2be9:      	js	0x2df0 <generic_tracepoint_process_event+0x2df0>
    2bef:      	movq	0x60(%rsp), %rax
    2bf4:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2bf9:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    2bff:      	ja	0x2df0 <generic_tracepoint_process_event+0x2df0>
    2c05:      	movq	%rax, %rbp
    2c08:      	movq	0x20(%rsp), %rdi
    2c0d:      	addq	%rbx, %rdi
    2c10:      	movq	%rdi, %rbx
    2c13:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2c19:      	addq	%r13, %rdi
    2c1c:      	movq	0x58(%rsp), %rcx
    2c21:      	movl	$0x4, %eax
    2c26:      	movq	%rbp, %rsi
    2c29:      	movq	0x58(%rsp), %rdx
    2c2e:      	callq	*%rax
    2c30:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2c35:      	testl	%eax, %eax
    2c37:      	js	0x2df0 <generic_tracepoint_process_event+0x2df0>
    2c3d:      	addq	%rbp, 0xb0(%rsp)
    2c45:      	cmpq	$0x5, %r12
    2c49:      	jb	0x2ee8 <generic_tracepoint_process_event+0x2ee8>
    2c4f:      	movq	0x18(%rsp), %rax
    2c54:      	leaq	0x40(%rax), %rdx
    2c58:      	leaq	0x58(%rsp), %rdi
    2c5d:      	movl	$0x4, %r15d
    2c63:      	movl	$0x10, %ecx
    2c68:      	movl	$0x4, %eax
    2c6d:      	movl	$0x10, %esi
    2c72:      	callq	*%rax
    2c74:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2c79:      	testl	%eax, %eax
    2c7b:      	js	0x2df0 <generic_tracepoint_process_event+0x2df0>
    2c81:      	movq	0x60(%rsp), %rax
    2c86:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2c8b:      	movq	%rax, 0x20(%rsp)
    2c90:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    2c96:      	ja	0x2df0 <generic_tracepoint_process_event+0x2df0>
    2c9c:      	addq	%rbx, %rbp
    2c9f:      	movq	%rbp, %rbx
    2ca2:      	movl	%ebp, %edi
    2ca4:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2caa:      	addq	%r13, %rdi
    2cad:      	movq	0x58(%rsp), %rcx
    2cb2:      	movl	$0x4, %eax
    2cb7:      	movq	0x20(%rsp), %rsi
    2cbc:      	movq	0x58(%rsp), %rdx
    2cc1:      	callq	*%rax
    2cc3:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2cc8:      	testl	%eax, %eax
    2cca:      	js	0x2df0 <generic_tracepoint_process_event+0x2df0>
    2cd0:      	movq	0x20(%rsp), %rax
    2cd5:      	addq	%rax, 0xb0(%rsp)
    2cdd:      	cmpq	$0x5, %r12
    2ce1:      	je	0x2ee8 <generic_tracepoint_process_event+0x2ee8>
    2ce7:      	movq	0x18(%rsp), %rax
    2cec:      	leaq	0x50(%rax), %rdx
    2cf0:      	leaq	0x58(%rsp), %rdi
    2cf5:      	movl	$0x4, %r15d
    2cfb:      	movl	$0x10, %ecx
    2d00:      	movl	$0x4, %eax
    2d05:      	movl	$0x10, %esi
    2d0a:      	callq	*%rax
    2d0c:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2d11:      	testl	%eax, %eax
    2d13:      	js	0x2df0 <generic_tracepoint_process_event+0x2df0>
    2d19:      	movq	0x60(%rsp), %rbp
    2d1e:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2d23:      	cmpq	$0xffe, %rbp            # imm = 0xFFE
    2d2a:      	ja	0x2df0 <generic_tracepoint_process_event+0x2df0>
    2d30:      	movq	0x20(%rsp), %rdi
    2d35:      	addq	%rbx, %rdi
    2d38:      	movq	%rdi, %rbx
    2d3b:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2d41:      	addq	%r13, %rdi
    2d44:      	movq	0x58(%rsp), %rcx
    2d49:      	movl	$0x4, %eax
    2d4e:      	movq	0x58(%rsp), %rdx
    2d53:      	movl	%ebp, %esi
    2d55:      	callq	*%rax
    2d57:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2d5c:      	testl	%eax, %eax
    2d5e:      	js	0x2df0 <generic_tracepoint_process_event+0x2df0>
    2d64:      	addq	%rbp, 0xb0(%rsp)
    2d6c:      	cmpq	$0x7, %r12
    2d70:      	jb	0x2ee8 <generic_tracepoint_process_event+0x2ee8>
    2d76:      	movq	0x18(%rsp), %rdx
    2d7b:      	addq	$0x60, %rdx
    2d7f:      	leaq	0x58(%rsp), %rdi
    2d84:      	movl	$0x4, %r15d
    2d8a:      	movl	$0x10, %ecx
    2d8f:      	movl	$0x4, %eax
    2d94:      	movl	$0x10, %esi
    2d99:      	callq	*%rax
    2d9b:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2da0:      	testl	%eax, %eax
    2da2:      	js	0x2df0 <generic_tracepoint_process_event+0x2df0>
    2da4:      	movq	0x60(%rsp), %r12
    2da9:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2dae:      	cmpq	$0xffe, %r12            # imm = 0xFFE
    2db5:      	ja	0x2df0 <generic_tracepoint_process_event+0x2df0>
    2db7:      	addq	%rbx, %rbp
    2dba:      	andl	$0x3fff, %ebp           # imm = 0x3FFF
    2dc0:      	addq	%r13, %rbp
    2dc3:      	movq	0x58(%rsp), %rcx
    2dc8:      	movl	$0x4, %eax
    2dcd:      	movq	0x58(%rsp), %rdx
    2dd2:      	movq	%rbp, %rdi
    2dd5:      	movl	%r12d, %esi
    2dd8:      	callq	*%rax
    2dda:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2ddf:      	testl	%eax, %eax
    2de1:      	js	0x2df0 <generic_tracepoint_process_event+0x2df0>
    2de3:      	addq	%r12, 0xb0(%rsp)
    2deb:      	jmp	0x2ee8 <generic_tracepoint_process_event+0x2ee8>
    2df0:      	movq	0x30(%rsp), %rax
    2df5:      	movl	%ecx, (%r13,%rax)
    2dfa:      	jmp	0x304c <generic_tracepoint_process_event+0x304c>
    2dff:      	xorl	%r12d, %r12d
    2e02:      	movl	$0x0, %eax
    2e07:      	movq	%rax, 0xb0(%rsp)
    2e0f:      	testb	$0x10, %sil
    2e13:      	je	0x2ee8 <generic_tracepoint_process_event+0x2ee8>
    2e19:      	movl	$0xe, %eax
    2e1e:      	callq	*%rax
    2e20:      	cmpq	$-0x16, %rax
    2e24:      	jne	0x2e4a <generic_tracepoint_process_event+0x2e4a>
    2e26:      	movq	0x28(%rsp), %rax
    2e2b:      	leaq	0x20(%rax), %rdx
    2e2f:      	leaq	0x58(%rsp), %rdi
    2e34:      	movl	$0x8, %ecx
    2e39:      	movl	$0x4, %eax
    2e3e:      	movl	$0x8, %esi
    2e43:      	callq	*%rax
    2e45:      	movq	0x58(%rsp), %rax
    2e4a:      	movq	0x8(%rbp), %rcx
    2e4e:      	movq	0x60(%rbp), %rdx
    2e52:      	movq	%rcx, 0x58(%rsp)
    2e57:      	movq	0x18(%rsp), %rcx
    2e5c:      	movq	%rcx, 0x60(%rsp)
    2e61:      	movq	%r12, 0x68(%rsp)
    2e66:      	movq	%rdx, 0x98(%rsp)
    2e6e:      	movq	%rax, 0xa0(%rsp)
    2e76:      	movq	(%rip), %rdi            # 0x2e7d <generic_tracepoint_process_event+0x2e7d>
    2e7d:      	xorl	%ecx, %ecx
    2e7f:      	leaq	0x98(%rsp), %rsi
    2e87:      	leaq	0x58(%rsp), %rdx
    2e8c:      	movl	$0x2, %eax
    2e91:      	xorl	%ecx, %ecx
    2e93:      	callq	*%rax
    2e95:      	testq	%rax, %rax
    2e98:      	je	0x2f95 <generic_tracepoint_process_event+0x2f95>
    2e9e:      	negl	%eax
    2ea0:      	movw	%ax, 0x40(%rsp)
    2ea5:      	movw	$0x5, 0x42(%rsp)
    2eac:      	movabsq	$0x200000057, %rax      # imm = 0x200000057
    2eb6:      	movq	%rax, 0x44(%rsp)
    2ebb:      	movq	(%rip), %rdi            # 0x2ec2 <generic_tracepoint_process_event+0x2ec2>
    2ec2:      	leaq	0x40(%rsp), %rsi
    2ec7:      	movl	$0x1, %eax
    2ecc:      	callq	*%rax
    2ece:      	testq	%rax, %rax
    2ed1:      	je	0x2f71 <generic_tracepoint_process_event+0x2f71>
    2ed7:      	incl	(%rax)
    2ed9:      	jmp	0x2f95 <generic_tracepoint_process_event+0x2f95>
    2ede:      	xorl	%eax, %eax
    2ee0:      	movq	%rax, 0xb0(%rsp)
    2ee8:      	movq	0x30(%rsp), %rax
    2eed:      	movq	0xb0(%rsp), %r15
    2ef5:      	movl	%r15d, (%r13,%rax)
    2efa:      	movl	%r15d, 0x4(%r13,%rax)
    2eff:      	addq	$0x8, %r15
    2f03:      	jmp	0x304c <generic_tracepoint_process_event+0x304c>
    2f08:      	cmpl	$0x33, %eax
    2f0b:      	je	0x30d8 <generic_tracepoint_process_event+0x30d8>
    2f11:      	cmpl	$0x3c, %eax
    2f14:      	je	0x2fae <generic_tracepoint_process_event+0x2fae>
    2f1a:      	cmpl	$0xff, %eax
    2f1f:      	jne	0x319f <generic_tracepoint_process_event+0x319f>
    2f25:      	movw	$0x28, 0x2(%r15)
    2f2c:      	movw	$0x28, %ax
    2f30:      	jmp	0x30e9 <generic_tracepoint_process_event+0x30e9>
    2f35:      	movl	$0x1, 0xc0(%rsp)
    2f40:      	movq	(%rip), %rdi            # 0x2f47 <generic_tracepoint_process_event+0x2f47>
    2f47:      	xorl	%ecx, %ecx
    2f49:      	leaq	0x40(%rsp), %rsi
    2f4e:      	leaq	0xc0(%rsp), %rdx
    2f56:      	movl	$0x2, %eax
    2f5b:      	xorl	%ecx, %ecx
    2f5d:      	callq	*%rax
    2f5f:      	movl	$0xfffffffc, (%rbp)     # imm = 0xFFFFFFFC
    2f66:      	movl	$0x4, %r15d
    2f6c:      	jmp	0x304c <generic_tracepoint_process_event+0x304c>
    2f71:      	movl	$0x1, 0x38(%rsp)
    2f79:      	movq	(%rip), %rdi            # 0x2f80 <generic_tracepoint_process_event+0x2f80>
    2f80:      	xorl	%ecx, %ecx
    2f82:      	leaq	0x40(%rsp), %rsi
    2f87:      	leaq	0x38(%rsp), %rdx
    2f8c:      	movl	$0x2, %eax
    2f91:      	xorl	%ecx, %ecx
    2f93:      	callq	*%rax
    2f95:      	movq	0x30(%rsp), %rax
    2f9a:      	movl	$0xfffffffc, (%r13,%rax) # imm = 0xFFFFFFFC
    2fa3:      	movl	$0x4, %r15d
    2fa9:      	jmp	0x304c <generic_tracepoint_process_event+0x304c>
    2fae:      	movzbl	0x7(%r15), %eax
    2fb3:      	leal	0x8(,%rax,8), %eax
    2fba:      	jmp	0x30e4 <generic_tracepoint_process_event+0x30e4>
    2fbf:      	addq	$0x5e60, %r15           # imm = 0x5E60
    2fc6:      	jmp	0x2fd8 <generic_tracepoint_process_event+0x2fd8>
    2fc8:      	addq	$0x5e68, %r15           # imm = 0x5E68
    2fcf:      	jmp	0x2fd8 <generic_tracepoint_process_event+0x2fd8>
    2fd1:      	addq	$0x5e50, %r15           # imm = 0x5E50
    2fd8:      	movq	(%r15), %rax
    2fdb:      	movq	%rax, 0x38(%rsp)
    2fe0:      	leaq	0xc8(%rsp), %rdi
    2fe8:      	leaq	0x38(%rsp), %rdx
    2fed:      	movl	$0x8, %ecx
    2ff2:      	movl	$0x4, %eax
    2ff7:      	movl	$0x4, %r15d
    2ffd:      	movl	$0x8, %esi
    3002:      	callq	*%rax
    3004:      	movq	0xc8(%rsp), %r13
    300c:      	cmpq	$0xfff, %r13            # imm = 0xFFF
    3013:      	movl	$0xfff, %r12d           # imm = 0xFFF
    3019:      	cmovbq	%r13, %r12
    301d:      	leaq	0x8(%rbp), %rdi
    3021:      	movl	$0x4, %eax
    3026:      	movq	0x18(%rsp), %rdx
    302b:      	movl	%r12d, %esi
    302e:      	callq	*%rax
    3030:      	testl	%eax, %eax
    3032:      	js	0x3045 <generic_tracepoint_process_event+0x3045>
    3034:      	movl	%r13d, (%rbp)
    3038:      	movl	%r12d, 0x4(%rbp)
    303c:      	addq	$0x8, %r12
    3040:      	movq	%r12, %r15
    3043:      	jmp	0x304c <generic_tracepoint_process_event+0x304c>
    3045:      	movl	$0xfffffffe, (%rbp)     # imm = 0xFFFFFFFE
    304c:      	movq	0x10(%rsp), %rcx
    3051:      	movq	0x8(%rsp), %rdx
    3056:      	movq	0x28(%rsp), %rbx
    305b:      	movq	0xd0(%rsp), %r12
    3063:      	movq	0x50(%rsp), %rbp
    3068:      	testl	%r15d, %r15d
    306b:      	jns	0x138c <generic_tracepoint_process_event+0x138c>
    3071:      	movl	$0xffffffff, 0x5ea0(%rcx,%rdx,4) # imm = 0xFFFFFFFF
    307c:      	movl	$0xffffffff, 0x90(%rcx,%rbp) # imm = 0xFFFFFFFF
    3087:      	movl	$0x4, %edx
    308c:      	addl	%ebp, %edx
    308e:      	movl	%edx, %ebp
    3090:      	movl	%ebp, 0x4(%r14)
    3094:      	cmpl	$0x3, %r12d
    3098:      	jle	0x978 <generic_tracepoint_process_event+0x978>
    309e:      	movl	$0x0, 0x5efc(%r14)
    30a9:      	movq	(%rip), %rsi            # 0x30b0 <generic_tracepoint_process_event+0x30b0>
    30b0:      	movl	$0x3, %ecx
    30b5:      	movl	$0xc, %eax
    30ba:      	movq	%rbx, %rdi
    30bd:      	movl	$0x3, %edx
    30c2:      	callq	*%rax
    30c4:      	xorl	%eax, %eax
    30c6:      	addq	$0x108, %rsp            # imm = 0x108
    30cd:      	popq	%rbx
    30ce:      	popq	%r12
    30d0:      	popq	%r13
    30d2:      	popq	%r14
    30d4:      	popq	%r15
    30d6:      	popq	%rbp
    30d7:      	retq
    30d8:      	movzbl	0x7(%r15), %eax
    30dd:      	leal	0x8(,%rax,4), %eax
    30e4:      	movw	%ax, 0x2(%r15)
    30e9:      	addw	(%r15), %ax
    30ed:      	movw	%ax, (%r15)
    30f1:      	movzbl	0x6(%r15), %ebp
    30f6:      	cmpq	$0x3c, %rbp
    30fa:      	ja	0x3809 <generic_tracepoint_process_event+0x3809>
    3100:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    310a:      	btq	%rbp, %rcx
    310e:      	jae	0x3809 <generic_tracepoint_process_event+0x3809>
    3114:      	movb	%bpl, 0x5(%r15)
    3118:      	movzwl	%ax, %ecx
    311b:      	movq	0x18(%rsp), %rsi
    3120:      	addq	%rsi, %rcx
    3123:      	movl	$0x2, %edx
    3128:      	movl	$0x4, %eax
    312d:      	movq	0x30(%rsp), %rdi
    3132:      	movzwl	(%r15), %edx
    3136:      	addq	%rsi, %rdx
    3139:      	movl	$0x2, %esi
    313e:      	callq	*%rax
    3140:      	testq	%rax, %rax
    3143:      	js	0x361e <generic_tracepoint_process_event+0x361e>
    3149:      	movzbl	0x5(%r15), %eax
    314e:      	cmpl	$0x32, %eax
    3151:      	jg	0x316e <generic_tracepoint_process_event+0x316e>
    3153:      	testl	%eax, %eax
    3155:      	je	0x318c <generic_tracepoint_process_event+0x318c>
    3157:      	cmpl	$0x2b, %eax
    315a:      	je	0x318c <generic_tracepoint_process_event+0x318c>
    315c:      	cmpl	$0x2c, %eax
    315f:      	jne	0x31bc <generic_tracepoint_process_event+0x31bc>
    3161:      	movw	$0x8, 0x2(%r15)
    3168:      	movw	$0x8, %ax
    316c:      	jmp	0x31c1 <generic_tracepoint_process_event+0x31c1>
    316e:      	cmpl	$0x33, %eax
    3171:      	je	0x31a9 <generic_tracepoint_process_event+0x31a9>
    3173:      	cmpl	$0x3c, %eax
    3176:      	je	0x318c <generic_tracepoint_process_event+0x318c>
    3178:      	cmpl	$0xff, %eax
    317d:      	jne	0x31bc <generic_tracepoint_process_event+0x31bc>
    317f:      	movw	$0x28, 0x2(%r15)
    3186:      	movw	$0x28, %ax
    318a:      	jmp	0x31c1 <generic_tracepoint_process_event+0x31c1>
    318c:      	movzbl	0x7(%r15), %eax
    3191:      	leal	0x8(,%rax,8), %eax
    3198:      	movw	%ax, 0x2(%r15)
    319d:      	jmp	0x31c1 <generic_tracepoint_process_event+0x31c1>
    319f:      	movzwl	0x2(%r15), %eax
    31a4:      	jmp	0x30e9 <generic_tracepoint_process_event+0x30e9>
    31a9:      	movzbl	0x7(%r15), %eax
    31ae:      	leal	0x8(,%rax,4), %eax
    31b5:      	movw	%ax, 0x2(%r15)
    31ba:      	jmp	0x31c1 <generic_tracepoint_process_event+0x31c1>
    31bc:      	movzwl	0x2(%r15), %eax
    31c1:      	addw	(%r15), %ax
    31c5:      	movw	%ax, (%r15)
    31c9:      	movzbl	0x6(%r15), %ebp
    31ce:      	cmpq	$0x3c, %rbp
    31d2:      	ja	0x3809 <generic_tracepoint_process_event+0x3809>
    31d8:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    31e2:      	btq	%rbp, %rcx
    31e6:      	jae	0x3809 <generic_tracepoint_process_event+0x3809>
    31ec:      	movb	%bpl, 0x5(%r15)
    31f0:      	movzwl	%ax, %ecx
    31f3:      	movq	0x18(%rsp), %rsi
    31f8:      	addq	%rsi, %rcx
    31fb:      	movl	$0x2, %edx
    3200:      	movl	$0x4, %eax
    3205:      	movq	0x30(%rsp), %rdi
    320a:      	movzwl	(%r15), %edx
    320e:      	addq	%rsi, %rdx
    3211:      	movl	$0x2, %esi
    3216:      	callq	*%rax
    3218:      	testq	%rax, %rax
    321b:      	js	0x361e <generic_tracepoint_process_event+0x361e>
    3221:      	movzbl	0x5(%r15), %eax
    3226:      	cmpl	$0x32, %eax
    3229:      	jg	0x3246 <generic_tracepoint_process_event+0x3246>
    322b:      	testl	%eax, %eax
    322d:      	je	0x3264 <generic_tracepoint_process_event+0x3264>
    322f:      	cmpl	$0x2b, %eax
    3232:      	je	0x3264 <generic_tracepoint_process_event+0x3264>
    3234:      	cmpl	$0x2c, %eax
    3237:      	jne	0x328a <generic_tracepoint_process_event+0x328a>
    3239:      	movw	$0x8, 0x2(%r15)
    3240:      	movw	$0x8, %ax
    3244:      	jmp	0x328f <generic_tracepoint_process_event+0x328f>
    3246:      	cmpl	$0x33, %eax
    3249:      	je	0x3277 <generic_tracepoint_process_event+0x3277>
    324b:      	cmpl	$0x3c, %eax
    324e:      	je	0x3264 <generic_tracepoint_process_event+0x3264>
    3250:      	cmpl	$0xff, %eax
    3255:      	jne	0x328a <generic_tracepoint_process_event+0x328a>
    3257:      	movw	$0x28, 0x2(%r15)
    325e:      	movw	$0x28, %ax
    3262:      	jmp	0x328f <generic_tracepoint_process_event+0x328f>
    3264:      	movzbl	0x7(%r15), %eax
    3269:      	leal	0x8(,%rax,8), %eax
    3270:      	movw	%ax, 0x2(%r15)
    3275:      	jmp	0x328f <generic_tracepoint_process_event+0x328f>
    3277:      	movzbl	0x7(%r15), %eax
    327c:      	leal	0x8(,%rax,4), %eax
    3283:      	movw	%ax, 0x2(%r15)
    3288:      	jmp	0x328f <generic_tracepoint_process_event+0x328f>
    328a:      	movzwl	0x2(%r15), %eax
    328f:      	addw	(%r15), %ax
    3293:      	movw	%ax, (%r15)
    3297:      	movzbl	0x6(%r15), %ebp
    329c:      	cmpq	$0x3c, %rbp
    32a0:      	ja	0x3809 <generic_tracepoint_process_event+0x3809>
    32a6:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    32b0:      	btq	%rbp, %rcx
    32b4:      	jae	0x3809 <generic_tracepoint_process_event+0x3809>
    32ba:      	movb	%bpl, 0x5(%r15)
    32be:      	movzwl	%ax, %ecx
    32c1:      	movq	0x18(%rsp), %rsi
    32c6:      	addq	%rsi, %rcx
    32c9:      	movl	$0x2, %edx
    32ce:      	movl	$0x4, %eax
    32d3:      	movq	0x30(%rsp), %rdi
    32d8:      	movzwl	(%r15), %edx
    32dc:      	addq	%rsi, %rdx
    32df:      	movl	$0x2, %esi
    32e4:      	callq	*%rax
    32e6:      	testq	%rax, %rax
    32e9:      	js	0x361e <generic_tracepoint_process_event+0x361e>
    32ef:      	movzbl	0x5(%r15), %eax
    32f4:      	cmpl	$0x32, %eax
    32f7:      	jg	0x3314 <generic_tracepoint_process_event+0x3314>
    32f9:      	testl	%eax, %eax
    32fb:      	je	0x3332 <generic_tracepoint_process_event+0x3332>
    32fd:      	cmpl	$0x2b, %eax
    3300:      	je	0x3332 <generic_tracepoint_process_event+0x3332>
    3302:      	cmpl	$0x2c, %eax
    3305:      	jne	0x3358 <generic_tracepoint_process_event+0x3358>
    3307:      	movw	$0x8, 0x2(%r15)
    330e:      	movw	$0x8, %ax
    3312:      	jmp	0x335d <generic_tracepoint_process_event+0x335d>
    3314:      	cmpl	$0x33, %eax
    3317:      	je	0x3345 <generic_tracepoint_process_event+0x3345>
    3319:      	cmpl	$0x3c, %eax
    331c:      	je	0x3332 <generic_tracepoint_process_event+0x3332>
    331e:      	cmpl	$0xff, %eax
    3323:      	jne	0x3358 <generic_tracepoint_process_event+0x3358>
    3325:      	movw	$0x28, 0x2(%r15)
    332c:      	movw	$0x28, %ax
    3330:      	jmp	0x335d <generic_tracepoint_process_event+0x335d>
    3332:      	movzbl	0x7(%r15), %eax
    3337:      	leal	0x8(,%rax,8), %eax
    333e:      	movw	%ax, 0x2(%r15)
    3343:      	jmp	0x335d <generic_tracepoint_process_event+0x335d>
    3345:      	movzbl	0x7(%r15), %eax
    334a:      	leal	0x8(,%rax,4), %eax
    3351:      	movw	%ax, 0x2(%r15)
    3356:      	jmp	0x335d <generic_tracepoint_process_event+0x335d>
    3358:      	movzwl	0x2(%r15), %eax
    335d:      	addw	(%r15), %ax
    3361:      	movw	%ax, (%r15)
    3365:      	movzbl	0x6(%r15), %ebp
    336a:      	cmpq	$0x3c, %rbp
    336e:      	ja	0x3809 <generic_tracepoint_process_event+0x3809>
    3374:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    337e:      	btq	%rbp, %rcx
    3382:      	jae	0x3809 <generic_tracepoint_process_event+0x3809>
    3388:      	movb	%bpl, 0x5(%r15)
    338c:      	movzwl	%ax, %ecx
    338f:      	movq	0x18(%rsp), %rsi
    3394:      	addq	%rsi, %rcx
    3397:      	movl	$0x2, %edx
    339c:      	movl	$0x4, %eax
    33a1:      	movq	0x30(%rsp), %rdi
    33a6:      	movzwl	(%r15), %edx
    33aa:      	addq	%rsi, %rdx
    33ad:      	movl	$0x2, %esi
    33b2:      	callq	*%rax
    33b4:      	testq	%rax, %rax
    33b7:      	js	0x361e <generic_tracepoint_process_event+0x361e>
    33bd:      	movzbl	0x5(%r15), %eax
    33c2:      	cmpl	$0x32, %eax
    33c5:      	jg	0x33e2 <generic_tracepoint_process_event+0x33e2>
    33c7:      	testl	%eax, %eax
    33c9:      	je	0x3400 <generic_tracepoint_process_event+0x3400>
    33cb:      	cmpl	$0x2b, %eax
    33ce:      	je	0x3400 <generic_tracepoint_process_event+0x3400>
    33d0:      	cmpl	$0x2c, %eax
    33d3:      	jne	0x3426 <generic_tracepoint_process_event+0x3426>
    33d5:      	movw	$0x8, 0x2(%r15)
    33dc:      	movw	$0x8, %ax
    33e0:      	jmp	0x342b <generic_tracepoint_process_event+0x342b>
    33e2:      	cmpl	$0x33, %eax
    33e5:      	je	0x3413 <generic_tracepoint_process_event+0x3413>
    33e7:      	cmpl	$0x3c, %eax
    33ea:      	je	0x3400 <generic_tracepoint_process_event+0x3400>
    33ec:      	cmpl	$0xff, %eax
    33f1:      	jne	0x3426 <generic_tracepoint_process_event+0x3426>
    33f3:      	movw	$0x28, 0x2(%r15)
    33fa:      	movw	$0x28, %ax
    33fe:      	jmp	0x342b <generic_tracepoint_process_event+0x342b>
    3400:      	movzbl	0x7(%r15), %eax
    3405:      	leal	0x8(,%rax,8), %eax
    340c:      	movw	%ax, 0x2(%r15)
    3411:      	jmp	0x342b <generic_tracepoint_process_event+0x342b>
    3413:      	movzbl	0x7(%r15), %eax
    3418:      	leal	0x8(,%rax,4), %eax
    341f:      	movw	%ax, 0x2(%r15)
    3424:      	jmp	0x342b <generic_tracepoint_process_event+0x342b>
    3426:      	movzwl	0x2(%r15), %eax
    342b:      	addw	(%r15), %ax
    342f:      	movw	%ax, (%r15)
    3433:      	movzbl	0x6(%r15), %ebp
    3438:      	cmpq	$0x3c, %rbp
    343c:      	ja	0x3809 <generic_tracepoint_process_event+0x3809>
    3442:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    344c:      	btq	%rbp, %rcx
    3450:      	jae	0x3809 <generic_tracepoint_process_event+0x3809>
    3456:      	movb	%bpl, 0x5(%r15)
    345a:      	movzwl	%ax, %ecx
    345d:      	movq	0x18(%rsp), %rsi
    3462:      	addq	%rsi, %rcx
    3465:      	movl	$0x2, %edx
    346a:      	movl	$0x4, %eax
    346f:      	movq	0x30(%rsp), %rdi
    3474:      	movzwl	(%r15), %edx
    3478:      	addq	%rsi, %rdx
    347b:      	movl	$0x2, %esi
    3480:      	callq	*%rax
    3482:      	testq	%rax, %rax
    3485:      	js	0x361e <generic_tracepoint_process_event+0x361e>
    348b:      	movzbl	0x5(%r15), %eax
    3490:      	cmpl	$0x32, %eax
    3493:      	jg	0x34b0 <generic_tracepoint_process_event+0x34b0>
    3495:      	testl	%eax, %eax
    3497:      	je	0x34ce <generic_tracepoint_process_event+0x34ce>
    3499:      	cmpl	$0x2b, %eax
    349c:      	je	0x34ce <generic_tracepoint_process_event+0x34ce>
    349e:      	cmpl	$0x2c, %eax
    34a1:      	jne	0x34f4 <generic_tracepoint_process_event+0x34f4>
    34a3:      	movw	$0x8, 0x2(%r15)
    34aa:      	movw	$0x8, %ax
    34ae:      	jmp	0x34f9 <generic_tracepoint_process_event+0x34f9>
    34b0:      	cmpl	$0x33, %eax
    34b3:      	je	0x34e1 <generic_tracepoint_process_event+0x34e1>
    34b5:      	cmpl	$0x3c, %eax
    34b8:      	je	0x34ce <generic_tracepoint_process_event+0x34ce>
    34ba:      	cmpl	$0xff, %eax
    34bf:      	jne	0x34f4 <generic_tracepoint_process_event+0x34f4>
    34c1:      	movw	$0x28, 0x2(%r15)
    34c8:      	movw	$0x28, %ax
    34cc:      	jmp	0x34f9 <generic_tracepoint_process_event+0x34f9>
    34ce:      	movzbl	0x7(%r15), %eax
    34d3:      	leal	0x8(,%rax,8), %eax
    34da:      	movw	%ax, 0x2(%r15)
    34df:      	jmp	0x34f9 <generic_tracepoint_process_event+0x34f9>
    34e1:      	movzbl	0x7(%r15), %eax
    34e6:      	leal	0x8(,%rax,4), %eax
    34ed:      	movw	%ax, 0x2(%r15)
    34f2:      	jmp	0x34f9 <generic_tracepoint_process_event+0x34f9>
    34f4:      	movzwl	0x2(%r15), %eax
    34f9:      	addw	(%r15), %ax
    34fd:      	movw	%ax, (%r15)
    3501:      	movzbl	0x6(%r15), %ebp
    3506:      	cmpq	$0x3c, %rbp
    350a:      	ja	0x3809 <generic_tracepoint_process_event+0x3809>
    3510:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    351a:      	btq	%rbp, %rcx
    351e:      	jae	0x3809 <generic_tracepoint_process_event+0x3809>
    3524:      	movb	%bpl, 0x5(%r15)
    3528:      	movzwl	%ax, %ecx
    352b:      	movq	0x18(%rsp), %rsi
    3530:      	addq	%rsi, %rcx
    3533:      	movl	$0x2, %edx
    3538:      	movl	$0x4, %eax
    353d:      	movq	0x30(%rsp), %rdi
    3542:      	movzwl	(%r15), %edx
    3546:      	addq	%rsi, %rdx
    3549:      	movl	$0x2, %esi
    354e:      	callq	*%rax
    3550:      	testq	%rax, %rax
    3553:      	js	0x361e <generic_tracepoint_process_event+0x361e>
    3559:      	movzbl	0x5(%r15), %eax
    355e:      	cmpl	$0x32, %eax
    3561:      	jg	0x357e <generic_tracepoint_process_event+0x357e>
    3563:      	testl	%eax, %eax
    3565:      	je	0x359c <generic_tracepoint_process_event+0x359c>
    3567:      	cmpl	$0x2b, %eax
    356a:      	je	0x359c <generic_tracepoint_process_event+0x359c>
    356c:      	cmpl	$0x2c, %eax
    356f:      	jne	0x35c2 <generic_tracepoint_process_event+0x35c2>
    3571:      	movw	$0x8, 0x2(%r15)
    3578:      	movw	$0x8, %ax
    357c:      	jmp	0x35c7 <generic_tracepoint_process_event+0x35c7>
    357e:      	cmpl	$0x33, %eax
    3581:      	je	0x35af <generic_tracepoint_process_event+0x35af>
    3583:      	cmpl	$0x3c, %eax
    3586:      	je	0x359c <generic_tracepoint_process_event+0x359c>
    3588:      	cmpl	$0xff, %eax
    358d:      	jne	0x35c2 <generic_tracepoint_process_event+0x35c2>
    358f:      	movw	$0x28, 0x2(%r15)
    3596:      	movw	$0x28, %ax
    359a:      	jmp	0x35c7 <generic_tracepoint_process_event+0x35c7>
    359c:      	movzbl	0x7(%r15), %eax
    35a1:      	leal	0x8(,%rax,8), %eax
    35a8:      	movw	%ax, 0x2(%r15)
    35ad:      	jmp	0x35c7 <generic_tracepoint_process_event+0x35c7>
    35af:      	movzbl	0x7(%r15), %eax
    35b4:      	leal	0x8(,%rax,4), %eax
    35bb:      	movw	%ax, 0x2(%r15)
    35c0:      	jmp	0x35c7 <generic_tracepoint_process_event+0x35c7>
    35c2:      	movzwl	0x2(%r15), %eax
    35c7:      	addw	(%r15), %ax
    35cb:      	movw	%ax, (%r15)
    35cf:      	movzbl	0x6(%r15), %ebp
    35d4:      	cmpq	$0x3c, %rbp
    35d8:      	ja	0x3809 <generic_tracepoint_process_event+0x3809>
    35de:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    35e8:      	btq	%rbp, %rcx
    35ec:      	jae	0x3809 <generic_tracepoint_process_event+0x3809>
    35f2:      	movb	%bpl, 0x5(%r15)
    35f6:      	movzwl	%ax, %ecx
    35f9:      	movq	0x18(%rsp), %rsi
    35fe:      	addq	%rsi, %rcx
    3601:      	movl	$0x2, %edx
    3606:      	movl	$0x4, %eax
    360b:      	movq	0x30(%rsp), %rdi
    3610:      	movzwl	(%r15), %edx
    3614:      	addq	%rsi, %rdx
    3617:      	movl	$0x2, %esi
    361c:      	callq	*%rax
    361e:      	xorl	%ebp, %ebp
    3620:      	movb	%bpl, 0xbc(%rsp)
    3628:      	movzbl	%bpl, %eax
    362c:      	movq	0x20(%rsp), %r15
    3631:      	movw	%ax, 0x24(%r15)
    3636:      	movw	$0xa, 0x26(%r15)
    363d:      	leaq	0x8(%r13), %rdx
    3641:      	movl	$0x10, %ecx
    3646:      	movl	$0x4, %eax
    364b:      	movq	%r15, %rdi
    364e:      	movl	$0x10, %esi
    3653:      	callq	*%rax
    3655:      	leaq	0x10(%r15), %rdi
    3659:      	addq	$0x18, %r13
    365d:      	movl	$0x10, %ecx
    3662:      	movl	$0x4, %eax
    3667:      	movl	$0x10, %esi
    366c:      	movq	%r13, %rdx
    366f:      	callq	*%rax
    3671:      	cmpb	$0x11, %bpl
    3675:      	je	0x36c8 <generic_tracepoint_process_event+0x36c8>
    3677:      	movzbl	%bpl, %eax
    367b:      	cmpl	$0x6, %eax
    367e:      	jne	0x3713 <generic_tracepoint_process_event+0x3713>
    3684:      	movq	0x58(%rsp), %r15
    3689:      	movzwl	0xd8(%rsp), %r13d
    3692:      	leaq	(%r15,%r13), %rdx
    3696:      	movq	0x20(%rsp), %rbp
    369b:      	leaq	0x20(%rbp), %rdi
    369f:      	movl	$0x2, %ecx
    36a4:      	movl	$0x4, %eax
    36a9:      	movl	$0x2, %esi
    36ae:      	callq	*%rax
    36b0:      	leaq	0x22(%rbp), %rdi
    36b4:      	leaq	(%r15,%r13), %rdx
    36b8:      	addq	$0x2, %rdx
    36bc:      	movl	$0x2, %ecx
    36c1:      	movl	$0x4, %eax
    36c6:      	jmp	0x370a <generic_tracepoint_process_event+0x370a>
    36c8:      	movq	0x58(%rsp), %r15
    36cd:      	movzwl	0xd8(%rsp), %r13d
    36d6:      	leaq	(%r15,%r13), %rdx
    36da:      	movq	0x20(%rsp), %rbp
    36df:      	leaq	0x20(%rbp), %rdi
    36e3:      	movl	$0x2, %ecx
    36e8:      	movl	$0x4, %eax
    36ed:      	movl	$0x2, %esi
    36f2:      	callq	*%rax
    36f4:      	leaq	0x22(%rbp), %rdi
    36f8:      	leaq	(%r15,%r13), %rdx
    36fc:      	addq	$0x2, %rdx
    3700:      	movl	$0x2, %ecx
    3705:      	movl	$0x4, %eax
    370a:      	movl	$0x2, %esi
    370f:      	callq	*%rax
    3711:      	jmp	0x371f <generic_tracepoint_process_event+0x371f>
    3713:      	movq	0x20(%rsp), %rax
    3718:      	movl	$0x0, 0x20(%rax)
    371f:      	movq	0x20(%rsp), %rdx
    3724:      	movzwl	0x20(%rdx), %eax
    3728:      	movzwl	0x22(%rdx), %ecx
    372c:      	movbew	%ax, 0x20(%rdx)
    3732:      	movbew	%cx, 0x22(%rdx)
    3738:      	addq	$0xe0, %r12
    373f:      	leaq	0x98(%rsp), %rdi
    3747:      	movl	$0x8, %ecx
    374c:      	movl	$0x4, %eax
    3751:      	movl	$0x4, %r15d
    3757:      	movl	$0x8, %esi
    375c:      	movq	%r12, %rdx
    375f:      	callq	*%rax
    3761:      	movq	0x98(%rsp), %rcx
    3769:      	testq	%rcx, %rcx
    376c:      	je	0x37d9 <generic_tracepoint_process_event+0x37d9>
    376e:      	addq	$0x5, %rcx
    3772:      	leaq	0x40(%rsp), %rdi
    3777:      	movl	$0x8, %edx
    377c:      	movl	$0x4, %eax
    3781:      	movq	0x98(%rsp), %rdx
    3789:      	addq	$0x5, %rdx
    378d:      	movl	$0x8, %esi
    3792:      	callq	*%rax
    3794:      	movq	0x98(%rsp), %r12
    379c:      	movq	0x40(%rsp), %r13
    37a1:      	movq	0x20(%rsp), %rbp
    37a6:      	leaq	0x38(%rbp), %rdi
    37aa:      	leaq	(%r12,%r13,8), %rdx
    37ae:      	addq	$0x44, %rdx
    37b2:      	movl	$0x4, %eax
    37b7:      	movl	$0x4, %esi
    37bc:      	callq	*%rax
    37be:      	addq	$0x3c, %rbp
    37c2:      	leaq	(%r12,%r13,8), %rdx
    37c6:      	addq	$0x45, %rdx
    37ca:      	movl	$0x4, %eax
    37cf:      	movq	%rbp, %rdi
    37d2:      	movl	$0x4, %esi
    37d7:      	callq	*%rax
    37d9:      	movl	$0x40, %r15d
    37df:      	movq	0x10(%rsp), %rcx
    37e4:      	movq	0x50(%rsp), %rbp
    37e9:      	movq	0x8(%rsp), %rdx
    37ee:      	movq	0x28(%rsp), %rbx
    37f3:      	movq	0xd0(%rsp), %r12
    37fb:      	testl	%r15d, %r15d
    37fe:      	jns	0x138c <generic_tracepoint_process_event+0x138c>
    3804:      	jmp	0x3071 <generic_tracepoint_process_event+0x3071>
    3809:      	movw	%ax, 0xd8(%rsp)
    3811:      	jmp	0x3620 <generic_tracepoint_process_event+0x3620>
    3816:      	nopw	%cs:(%rax,%rax)

0000000000003820 <generic_tracepoint_filter>:
    3820:      	pushq	%rbp
    3821:      	pushq	%r15
    3823:      	pushq	%r14
    3825:      	pushq	%r13
    3827:      	pushq	%r12
    3829:      	pushq	%rbx
    382a:      	subq	$0xe8, %rsp
    3831:      	movq	%rdi, %rbx
    3834:      	movl	$0x0, 0xc8(%rsp)
    383f:      	movq	(%rip), %rdi            # 0x3846 <generic_tracepoint_filter+0x26>
    3846:      	leaq	0xc8(%rsp), %rsi
    384e:      	movl	$0x1, %eax
    3853:      	callq	*%rax
    3855:      	testq	%rax, %rax
    3858:      	je	0x5e49 <generic_tracepoint_filter+0x2629>
    385e:      	movq	%rax, %r14
    3861:      	movl	$0x23, %eax
    3866:      	callq	*%rax
    3868:      	movq	%rax, %rcx
    386b:      	movq	%rax, 0x60(%rsp)
    3870:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    3877:      	leaq	0x10(%rsp), %rdi
    387c:      	movl	$0x4, %edx
    3881:      	movl	$0x71, %eax
    3886:      	movl	$0xaf4, %edx            # imm = 0xAF4
    388b:      	addq	0x60(%rsp), %rdx
    3890:      	movl	$0x4, %esi
    3895:      	callq	*%rax
    3897:      	movl	0x10(%rsp), %eax
    389b:      	movl	%eax, 0x40(%rsp)
    389f:      	movq	(%rip), %rdi            # 0x38a6 <generic_tracepoint_filter+0x86>
    38a6:      	leaq	0x40(%rsp), %rsi
    38ab:      	movl	$0x1, %eax
    38b0:      	callq	*%rax
    38b2:      	testq	%rax, %rax
    38b5:      	movq	%r14, 0x50(%rsp)
    38ba:      	je	0x38ca <generic_tracepoint_filter+0xaa>
    38bc:      	movq	%rax, %r15
    38bf:      	cmpq	$0x0, 0x8(%rax)
    38c4:      	jne	0x484f <generic_tracepoint_filter+0x102f>
    38ca:      	movl	$0xb00, %edx            # imm = 0xB00
    38cf:      	movq	0x60(%rsp), %rcx
    38d4:      	addq	%rdx, %rcx
    38d7:      	leaq	0x60(%rsp), %rdi
    38dc:      	movl	$0x8, %esi
    38e1:      	movl	$0x71, %eax
    38e6:      	addq	0x60(%rsp), %rdx
    38eb:      	movl	$0x8, %esi
    38f0:      	callq	*%rax
    38f2:      	movq	0x60(%rsp), %rcx
    38f7:      	testq	%rcx, %rcx
    38fa:      	je	0x3a8f <generic_tracepoint_filter+0x26f>
    3900:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    3907:      	leaq	0x10(%rsp), %rdi
    390c:      	movl	$0x4, %edx
    3911:      	movl	$0x71, %eax
    3916:      	movl	$0xaf4, %edx            # imm = 0xAF4
    391b:      	addq	0x60(%rsp), %rdx
    3920:      	movl	$0x4, %esi
    3925:      	callq	*%rax
    3927:      	movl	0x10(%rsp), %eax
    392b:      	movl	%eax, 0x40(%rsp)
    392f:      	movq	(%rip), %rdi            # 0x3936 <generic_tracepoint_filter+0x116>
    3936:      	leaq	0x40(%rsp), %rsi
    393b:      	movl	$0x1, %eax
    3940:      	callq	*%rax
    3942:      	testq	%rax, %rax
    3945:      	je	0x3955 <generic_tracepoint_filter+0x135>
    3947:      	movq	%rax, %r15
    394a:      	cmpq	$0x0, 0x8(%rax)
    394f:      	jne	0x484f <generic_tracepoint_filter+0x102f>
    3955:      	movl	$0xb00, %edx            # imm = 0xB00
    395a:      	movq	0x60(%rsp), %rcx
    395f:      	addq	%rdx, %rcx
    3962:      	leaq	0x60(%rsp), %rdi
    3967:      	movl	$0x8, %esi
    396c:      	movl	$0x71, %eax
    3971:      	addq	0x60(%rsp), %rdx
    3976:      	movl	$0x8, %esi
    397b:      	callq	*%rax
    397d:      	movq	0x60(%rsp), %rcx
    3982:      	testq	%rcx, %rcx
    3985:      	je	0x3a8f <generic_tracepoint_filter+0x26f>
    398b:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    3992:      	leaq	0x10(%rsp), %rdi
    3997:      	movl	$0x4, %edx
    399c:      	movl	$0x71, %eax
    39a1:      	movl	$0xaf4, %edx            # imm = 0xAF4
    39a6:      	addq	0x60(%rsp), %rdx
    39ab:      	movl	$0x4, %esi
    39b0:      	callq	*%rax
    39b2:      	movl	0x10(%rsp), %eax
    39b6:      	movl	%eax, 0x40(%rsp)
    39ba:      	movq	(%rip), %rdi            # 0x39c1 <generic_tracepoint_filter+0x1a1>
    39c1:      	leaq	0x40(%rsp), %rsi
    39c6:      	movl	$0x1, %eax
    39cb:      	callq	*%rax
    39cd:      	testq	%rax, %rax
    39d0:      	je	0x39e0 <generic_tracepoint_filter+0x1c0>
    39d2:      	movq	%rax, %r15
    39d5:      	cmpq	$0x0, 0x8(%rax)
    39da:      	jne	0x484f <generic_tracepoint_filter+0x102f>
    39e0:      	movl	$0xb00, %edx            # imm = 0xB00
    39e5:      	movq	0x60(%rsp), %rcx
    39ea:      	addq	%rdx, %rcx
    39ed:      	leaq	0x60(%rsp), %rdi
    39f2:      	movl	$0x8, %esi
    39f7:      	movl	$0x71, %eax
    39fc:      	addq	0x60(%rsp), %rdx
    3a01:      	movl	$0x8, %esi
    3a06:      	callq	*%rax
    3a08:      	movq	0x60(%rsp), %rcx
    3a0d:      	testq	%rcx, %rcx
    3a10:      	je	0x3a8f <generic_tracepoint_filter+0x26f>
    3a12:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    3a19:      	leaq	0x10(%rsp), %rdi
    3a1e:      	movl	$0x4, %edx
    3a23:      	movl	$0x71, %eax
    3a28:      	movl	$0xaf4, %edx            # imm = 0xAF4
    3a2d:      	addq	0x60(%rsp), %rdx
    3a32:      	movl	$0x4, %esi
    3a37:      	callq	*%rax
    3a39:      	movl	0x10(%rsp), %eax
    3a3d:      	movl	%eax, 0x40(%rsp)
    3a41:      	movq	(%rip), %rdi            # 0x3a48 <generic_tracepoint_filter+0x228>
    3a48:      	leaq	0x40(%rsp), %rsi
    3a4d:      	movl	$0x1, %eax
    3a52:      	callq	*%rax
    3a54:      	testq	%rax, %rax
    3a57:      	je	0x3a67 <generic_tracepoint_filter+0x247>
    3a59:      	movq	%rax, %r15
    3a5c:      	cmpq	$0x0, 0x8(%rax)
    3a61:      	jne	0x484f <generic_tracepoint_filter+0x102f>
    3a67:      	movl	$0xb00, %edx            # imm = 0xB00
    3a6c:      	movq	0x60(%rsp), %rcx
    3a71:      	addq	%rdx, %rcx
    3a74:      	leaq	0x60(%rsp), %rdi
    3a79:      	movl	$0x8, %esi
    3a7e:      	movl	$0x71, %eax
    3a83:      	addq	0x60(%rsp), %rdx
    3a88:      	movl	$0x8, %esi
    3a8d:      	callq	*%rax
    3a8f:      	movq	%rbx, 0xb8(%rsp)
    3a97:      	movl	$0x23, %eax
    3a9c:      	callq	*%rax
    3a9e:      	movq	%rax, %r13
    3aa1:      	leaq	0xaf4(%rax), %rdx
    3aa8:      	leaq	0x60(%rsp), %rdi
    3aad:      	movl	$0x4, %ecx
    3ab2:      	movl	$0x4, %eax
    3ab7:      	movl	$0x4, %ebp
    3abc:      	movl	$0x4, %esi
    3ac1:      	callq	*%rax
    3ac3:      	movl	0x60(%rsp), %eax
    3ac7:      	movl	%eax, 0x5f10(%r14)
    3ace:      	movl	$0x7d, %eax
    3ad3:      	callq	*%rax
    3ad5:      	movq	%rax, 0x5f18(%r14)
    3adc:      	movl	$0x0, 0x5f20(%r14)
    3ae7:      	movq	$0x0, 0x5f28(%r14)
    3af2:      	movl	$0x0, 0x5f30(%r14)
    3afd:      	leaq	0x60(%r13), %rdx
    3b01:      	leaq	0x40(%rsp), %rdi
    3b06:      	movl	$0x8, %ecx
    3b0b:      	movl	$0x71, %eax
    3b10:      	movl	$0x8, %esi
    3b15:      	callq	*%rax
    3b17:      	movq	0x40(%rsp), %rcx
    3b1c:      	xorl	%ebx, %ebx
    3b1e:      	testq	%rcx, %rcx
    3b21:      	je	0x3b90 <generic_tracepoint_filter+0x370>
    3b23:      	addq	$0x4, %rcx
    3b27:      	leaq	0x10(%rsp), %rdi
    3b2c:      	movl	$0x4, %edx
    3b31:      	movl	$0x71, %eax
    3b36:      	movq	0x40(%rsp), %rdx
    3b3b:      	addq	$0x4, %rdx
    3b3f:      	movl	$0x4, %esi
    3b44:      	callq	*%rax
    3b46:      	movl	0x10(%rsp), %eax
    3b4a:      	testl	%eax, %eax
    3b4c:      	je	0x3b90 <generic_tracepoint_filter+0x370>
    3b4e:      	movq	0x40(%rsp), %rcx
    3b53:      	shll	$0x4, %eax
    3b56:      	addq	%rax, %rcx
    3b59:      	addq	$0x80, %rcx
    3b60:      	leaq	0x60(%rsp), %rdi
    3b65:      	movl	$0x10, %edx
    3b6a:      	movl	$0x71, %eax
    3b6f:      	movq	0x40(%rsp), %rcx
    3b74:      	movl	0x10(%rsp), %edx
    3b78:      	shll	$0x4, %edx
    3b7b:      	addq	%rcx, %rdx
    3b7e:      	addq	$0x80, %rdx
    3b85:      	movl	$0x10, %esi
    3b8a:      	callq	*%rax
    3b8c:      	movl	0x60(%rsp), %ebx
    3b90:      	movl	%ebx, 0x5f34(%r14)
    3b97:      	leaq	0xd00(%r13), %r15
    3b9e:      	leaq	0x60(%rsp), %rdi
    3ba3:      	movl	$0x8, %ecx
    3ba8:      	movl	$0x4, %eax
    3bad:      	leaq	0x5f60(%r14), %rbx
    3bb4:      	movl	$0x8, %esi
    3bb9:      	movq	%r15, %rdx
    3bbc:      	callq	*%rax
    3bbe:      	movq	0x60(%rsp), %r12
    3bc3:      	leaq	0x5f68(%r14), %rdi
    3bca:      	leaq	0x40(%r12), %rdx
    3bcf:      	movl	$0x8, %ecx
    3bd4:      	movl	$0x4, %eax
    3bd9:      	movl	$0x8, %esi
    3bde:      	callq	*%rax
    3be0:      	leaq	0x5f70(%r14), %rdi
    3be7:      	leaq	0x30(%r12), %rdx
    3bec:      	movl	$0x8, %ecx
    3bf1:      	movl	$0x4, %eax
    3bf6:      	movl	$0x8, %esi
    3bfb:      	callq	*%rax
    3bfd:      	addq	$0x38, %r12
    3c01:      	movl	$0x8, %ecx
    3c06:      	movl	$0x4, %eax
    3c0b:      	movq	%rbx, %rdi
    3c0e:      	movl	$0x8, %esi
    3c13:      	movq	%r12, %rdx
    3c16:      	callq	*%rax
    3c18:      	leaq	0x5f38(%r14), %rbx
    3c1f:      	leaq	0xd70(%r13), %rdx
    3c26:      	leaq	0x10(%rsp), %rdi
    3c2b:      	movl	$0x8, %ecx
    3c30:      	movl	$0x4, %eax
    3c35:      	movl	$0x8, %esi
    3c3a:      	callq	*%rax
    3c3c:      	movq	0x10(%rsp), %rcx
    3c41:      	leaq	0x60(%rsp), %rdi
    3c46:      	movl	$0x48, %edx
    3c4b:      	movl	$0x4, %eax
    3c50:      	movq	0x10(%rsp), %rdx
    3c55:      	movl	$0x48, %esi
    3c5a:      	callq	*%rax
    3c5c:      	movl	$0x218, %edx            # imm = 0x218
    3c61:      	movq	0x68(%rsp), %rcx
    3c66:      	addq	%rdx, %rcx
    3c69:      	movl	$0x4, %eax
    3c6e:      	addq	0x68(%rsp), %rdx
    3c73:      	movq	%rbx, %rdi
    3c76:      	movl	$0x4, %esi
    3c7b:      	callq	*%rax
    3c7d:      	leaq	0x5f3c(%r14), %rdi
    3c84:      	movl	$0x4d8, %edx            # imm = 0x4D8
    3c89:      	movq	0x70(%rsp), %rcx
    3c8e:      	addq	%rdx, %rcx
    3c91:      	movl	$0x4, %eax
    3c96:      	addq	0x70(%rsp), %rdx
    3c9b:      	movl	$0x4, %esi
    3ca0:      	callq	*%rax
    3ca2:      	leaq	0x5f40(%r14), %rdi
    3ca9:      	movq	0x78(%rsp), %rcx
    3cae:      	addq	$0x58, %rcx
    3cb2:      	movl	$0x4, %eax
    3cb7:      	movq	0x78(%rsp), %rdx
    3cbc:      	addq	$0x58, %rdx
    3cc0:      	movl	$0x4, %esi
    3cc5:      	callq	*%rax
    3cc7:      	movq	$0x0, 0x58(%rsp)
    3cd0:      	leaq	0xb58(%r13), %rdx
    3cd7:      	leaq	0x58(%rsp), %rdi
    3cdc:      	movl	$0x8, %ecx
    3ce1:      	movl	$0x4, %eax
    3ce6:      	movl	$0x8, %esi
    3ceb:      	callq	*%rax
    3ced:      	movq	0x58(%rsp), %rcx
    3cf2:      	testq	%rcx, %rcx
    3cf5:      	je	0x3da4 <generic_tracepoint_filter+0x584>
    3cfb:      	movl	$0x0, 0xa8(%rsp)
    3d06:      	addq	$0x4, %rcx
    3d0a:      	leaq	0xa8(%rsp), %rdi
    3d12:      	movl	$0x4, %edx
    3d17:      	movl	$0x4, %eax
    3d1c:      	movq	0x58(%rsp), %rdx
    3d21:      	addq	$0x4, %rdx
    3d25:      	movl	$0x4, %esi
    3d2a:      	callq	*%rax
    3d2c:      	movq	0x58(%rsp), %rax
    3d31:      	movslq	0xa8(%rsp), %rcx
    3d39:      	shlq	$0x4, %rcx
    3d3d:      	addq	%rax, %rcx
    3d40:      	addq	$0x80, %rcx
    3d47:      	leaq	0x40(%rsp), %rdi
    3d4c:      	movl	$0x10, %edx
    3d51:      	movl	$0x4, %eax
    3d56:      	movq	0x58(%rsp), %rcx
    3d5b:      	movslq	0xa8(%rsp), %rdx
    3d63:      	shlq	$0x4, %rdx
    3d67:      	addq	%rcx, %rdx
    3d6a:      	addq	$0x80, %rdx
    3d71:      	movl	$0x10, %esi
    3d76:      	callq	*%rax
    3d78:      	leaq	0x5f44(%r14), %rdi
    3d7f:      	movl	$0x158, %edx            # imm = 0x158
    3d84:      	movq	0x48(%rsp), %rcx
    3d89:      	addq	%rdx, %rcx
    3d8c:      	movl	$0x4, %esi
    3d91:      	movl	$0x4, %eax
    3d96:      	addq	0x48(%rsp), %rdx
    3d9b:      	movl	$0x4, %esi
    3da0:      	callq	*%rax
    3da2:      	jmp	0x3daf <generic_tracepoint_filter+0x58f>
    3da4:      	movl	$0x0, 0x5f44(%r14)
    3daf:      	leaq	0x5f48(%r14), %rdi
    3db6:      	movl	$0x158, %ebx            # imm = 0x158
    3dbb:      	movq	0x80(%rsp), %rcx
    3dc3:      	addq	%rbx, %rcx
    3dc6:      	movl	$0x4, %edx
    3dcb:      	movl	$0x4, %eax
    3dd0:      	movq	0x80(%rsp), %rdx
    3dd8:      	addq	%rbx, %rdx
    3ddb:      	movl	$0x4, %esi
    3de0:      	callq	*%rax
    3de2:      	leaq	0x5f4c(%r14), %rdi
    3de9:      	movl	$0x118, %edx            # imm = 0x118
    3dee:      	movq	0x88(%rsp), %rcx
    3df6:      	addq	%rdx, %rcx
    3df9:      	movl	$0x4, %esi
    3dfe:      	movl	$0x4, %eax
    3e03:      	addq	0x88(%rsp), %rdx
    3e0b:      	movl	$0x4, %esi
    3e10:      	callq	*%rax
    3e12:      	leaq	0x5f50(%r14), %rdi
    3e19:      	movl	$0x98, %r12d
    3e1f:      	movq	0x90(%rsp), %rcx
    3e27:      	addq	%r12, %rcx
    3e2a:      	movl	$0x4, %edx
    3e2f:      	movl	$0x4, %eax
    3e34:      	movq	0x90(%rsp), %rdx
    3e3c:      	addq	%r12, %rdx
    3e3f:      	movl	$0x4, %esi
    3e44:      	callq	*%rax
    3e46:      	leaq	0x5f54(%r14), %rdi
    3e4d:      	movq	0x98(%rsp), %rcx
    3e55:      	addq	%r12, %rcx
    3e58:      	movl	$0x4, %edx
    3e5d:      	movl	$0x4, %eax
    3e62:      	addq	0x98(%rsp), %r12
    3e6a:      	movl	$0x4, %esi
    3e6f:      	movq	%r12, %rdx
    3e72:      	callq	*%rax
    3e74:      	leaq	0x5f58(%r14), %rdi
    3e7b:      	movq	0xa0(%rsp), %rcx
    3e83:      	addq	$0x58, %rcx
    3e87:      	movl	$0x4, %edx
    3e8c:      	movl	$0x4, %eax
    3e91:      	movq	0xa0(%rsp), %rdx
    3e99:      	addq	$0x58, %rdx
    3e9d:      	movl	$0x4, %esi
    3ea2:      	callq	*%rax
    3ea4:      	movq	$0x0, 0x40(%rsp)
    3ead:      	movq	$0x0, 0x58(%rsp)
    3eb6:      	leaq	0x40(%rsp), %rdi
    3ebb:      	movl	$0x8, %ecx
    3ec0:      	movl	$0x4, %eax
    3ec5:      	movl	$0x8, %esi
    3eca:      	movq	%r15, %rdx
    3ecd:      	callq	*%rax
    3ecf:      	movl	$0x90, %edx
    3ed4:      	movq	0x40(%rsp), %rcx
    3ed9:      	addq	%rdx, %rcx
    3edc:      	leaq	0x58(%rsp), %rdi
    3ee1:      	movl	$0x8, %esi
    3ee6:      	movl	$0x4, %eax
    3eeb:      	addq	0x40(%rsp), %rdx
    3ef0:      	movl	$0x8, %esi
    3ef5:      	callq	*%rax
    3ef7:      	leaq	0x5f5c(%r14), %rdi
    3efe:      	movq	0x58(%rsp), %rcx
    3f03:      	addq	%rbx, %rcx
    3f06:      	movl	$0x4, %edx
    3f0b:      	movl	$0x4, %eax
    3f10:      	addq	0x58(%rsp), %rbx
    3f15:      	movl	$0x4, %esi
    3f1a:      	movq	%rbx, %rdx
    3f1d:      	callq	*%rax
    3f1f:      	cmpl	$0x1, 0x5f34(%r14)
    3f27:      	jne	0x3f31 <generic_tracepoint_filter+0x711>
    3f29:      	orb	$0x2, 0x5f33(%r14)
    3f31:      	leaq	0x5f78(%r14), %rdi
    3f38:      	movl	$0x308, %edx            # imm = 0x308
    3f3d:      	movq	%rdi, 0x8(%rsp)
    3f42:      	xorl	%esi, %esi
    3f44:      	callq	0x3f49 <generic_tracepoint_filter+0x729>
    3f49:      	leaq	0x6290(%r14), %rbp
    3f50:      	addq	$0xa78, %r13            # imm = 0xA78
    3f57:      	leaq	0x40(%rsp), %rdi
    3f5c:      	movl	$0x8, %ecx
    3f61:      	movl	$0x4, %eax
    3f66:      	movl	$0x8, %esi
    3f6b:      	movq	%r13, %rdx
    3f6e:      	callq	*%rax
    3f70:      	movl	$0x5f8, %edx            # imm = 0x5F8
    3f75:      	movq	0x40(%rsp), %rcx
    3f7a:      	addq	%rdx, %rcx
    3f7d:      	leaq	0x60(%rsp), %rdi
    3f82:      	movl	$0x8, %esi
    3f87:      	movl	$0x4, %eax
    3f8c:      	addq	0x40(%rsp), %rdx
    3f91:      	movl	$0x8, %esi
    3f96:      	callq	*%rax
    3f98:      	movq	0x60(%rsp), %rbx
    3f9d:      	movl	$0x0, 0xcc(%rsp)
    3fa8:      	movq	(%rip), %rdi            # 0x3faf <generic_tracepoint_filter+0x78f>
    3faf:      	leaq	0xcc(%rsp), %rsi
    3fb7:      	movl	$0x1, %eax
    3fbc:      	callq	*%rax
    3fbe:      	testq	%rax, %rax
    3fc1:      	je	0x46c7 <generic_tracepoint_filter+0xea7>
    3fc7:      	movq	%rax, %r12
    3fca:      	movq	%rbp, 0x38(%rsp)
    3fcf:      	movl	$0x1000, 0x6410(%r14)   # imm = 0x1000
    3fda:      	leaq	0x1000(%rax), %r13
    3fe1:      	movl	$0x23, %eax
    3fe6:      	callq	*%rax
    3fe8:      	leaq	0xd50(%rax), %rdx
    3fef:      	leaq	0xd8(%rsp), %rdi
    3ff7:      	movl	$0x8, %ecx
    3ffc:      	movl	$0x4, %eax
    4001:      	movl	$0x8, %esi
    4006:      	callq	*%rax
    4008:      	movq	0xd8(%rsp), %rbp
    4010:      	leaq	0x48(%rbx), %r15
    4014:      	leaq	0xe0(%rsp), %rdi
    401c:      	movl	$0x8, %ecx
    4021:      	movl	$0x4, %eax
    4026:      	movl	$0x8, %esi
    402b:      	movq	%r15, %rdx
    402e:      	callq	*%rax
    4030:      	movq	0xe0(%rsp), %r14
    4038:      	leaq	0x10(%r14), %rdx
    403c:      	leaq	0x60(%rsp), %rdi
    4041:      	movl	$0x8, %ecx
    4046:      	movl	$0x4, %eax
    404b:      	movl	$0x8, %esi
    4050:      	callq	*%rax
    4052:      	cmpq	$0x0, 0x60(%rsp)
    4058:      	je	0x4326 <generic_tracepoint_filter+0xb06>
    405e:      	movq	0x50(%rsp), %r14
    4063:      	movq	$0x0, 0x68(%rsp)
    406c:      	movq	$0x0, 0x60(%rsp)
    4075:      	movq	%r12, 0x70(%rsp)
    407a:      	movq	$0x0, 0x78(%rsp)
    4083:      	movq	$0x0, 0x80(%rsp)
    408f:      	movq	$0x0, 0x88(%rsp)
    409b:      	movq	%r13, 0xc0(%rsp)
    40a3:      	movq	%r13, 0x90(%rsp)
    40ab:      	movl	0x6410(%r14), %eax
    40b2:      	movl	%eax, 0x98(%rsp)
    40b9:      	leaq	0x18(%rbp), %r13
    40bd:      	movb	$0x0, 0x9c(%rsp)
    40c5:      	addq	$0x20, %rbp
    40c9:      	leaq	0x60(%rsp), %rdi
    40ce:      	movl	$0x8, %ecx
    40d3:      	movl	$0x4, %eax
    40d8:      	addq	$0x40, %rbx
    40dc:      	leaq	0x68(%rsp), %r12
    40e1:      	leaq	0x78(%rsp), %r14
    40e6:      	movl	$0x8, %esi
    40eb:      	movq	%rbp, %rdx
    40ee:      	callq	*%rax
    40f0:      	movl	$0x8, %ecx
    40f5:      	movl	$0x4, %eax
    40fa:      	movq	%r12, %rdi
    40fd:      	movl	$0x8, %esi
    4102:      	movq	%r13, %rdx
    4105:      	callq	*%rax
    4107:      	movl	$0x8, %ecx
    410c:      	movl	$0x4, %eax
    4111:      	movq	%r14, %rdi
    4114:      	movl	$0x8, %esi
    4119:      	movq	%r15, %rdx
    411c:      	callq	*%rax
    411e:      	movl	$0x8, %ecx
    4123:      	movl	$0x4, %eax
    4128:      	leaq	0x80(%rsp), %rdi
    4130:      	movl	$0x8, %esi
    4135:      	movq	%rbx, %rdx
    4138:      	callq	*%rax
    413a:      	movq	0x80(%rsp), %rax
    4142:      	addq	$-0x20, %rax
    4146:      	movq	%rax, 0x88(%rsp)
    414e:      	movq	(%rip), %rax            # 0x4155 <generic_tracepoint_filter+0x935>
    4155:      	cmpb	$0x0, (%rax)
    4158:      	je	0x437d <generic_tracepoint_filter+0xb5d>
    415e:      	movl	$0x80, %r14d
    4164:      	movl	$0x8, %ebp
    4169:      	leaq	0x10(%rsp), %rbx
    416e:      	nop
    4170:      	movq	0x78(%rsp), %r15
    4175:      	movq	0x80(%rsp), %rdx
    417d:      	movq	0x88(%rsp), %r12
    4185:      	cmpq	0x60(%rsp), %r15
    418a:      	jne	0x4197 <generic_tracepoint_filter+0x977>
    418c:      	cmpq	0x68(%rsp), %rdx
    4191:      	je	0x453f <generic_tracepoint_filter+0xd1f>
    4197:      	movl	$0x4, %eax
    419c:      	leaq	0xa8(%rsp), %rdi
    41a4:      	movl	$0x8, %esi
    41a9:      	callq	*%rax
    41ab:      	cmpq	0xa8(%rsp), %r15
    41b3:      	je	0x42c0 <generic_tracepoint_filter+0xaa0>
    41b9:      	leaq	0x18(%r15), %r13
    41bd:      	movl	$0x4, %eax
    41c2:      	movq	%rbx, %rdi
    41c5:      	movl	$0x8, %esi
    41ca:      	movq	%r13, %rdx
    41cd:      	callq	*%rax
    41cf:      	cmpq	%r15, 0x10(%rsp)
    41d4:      	je	0x42c0 <generic_tracepoint_filter+0xaa0>
    41da:      	movl	$0x4, %eax
    41df:      	leaq	0x58(%rsp), %rdi
    41e4:      	movl	$0x8, %esi
    41e9:      	movq	%r13, %rdx
    41ec:      	callq	*%rax
    41ee:      	addq	$0x20, %r15
    41f2:      	movl	$0x4, %eax
    41f7:      	leaq	0x40(%rsp), %rdi
    41fc:      	movl	$0x10, %ecx
    4201:      	movl	$0x10, %esi
    4206:      	movq	%r15, %rdx
    4209:      	callq	*%rax
    420b:      	movq	0x70(%rsp), %r15
    4210:      	movq	0x90(%rsp), %rax
    4218:      	movl	0x44(%rsp), %r12d
    421d:      	subq	%r15, %rax
    4220:      	movl	0x98(%rsp), %r13d
    4228:      	movl	%r12d, %edx
    422b:      	subl	%r13d, %edx
    422e:      	movl	$0x0, %ecx
    4233:      	cmovbl	%ecx, %edx
    4236:      	addq	0x48(%rsp), %rdx
    423b:      	xorl	%esi, %esi
    423d:      	cmpl	%r12d, %r13d
    4240:      	seta	%sil
    4244:      	movl	%r12d, %ecx
    4247:      	cmovbl	%r13d, %ecx
    424b:      	addl	%ecx, %esi
    424d:      	movl	%r13d, %edi
    4250:      	subl	%esi, %edi
    4252:      	movl	%edi, 0x98(%rsp)
    4259:      	subq	%rsi, %rax
    425c:      	jb	0x4547 <generic_tracepoint_filter+0xd27>
    4262:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    4268:      	ja	0x4547 <generic_tracepoint_filter+0xd27>
    426e:      	cmpl	%r12d, %r13d
    4271:      	jbe	0x4278 <generic_tracepoint_filter+0xa58>
    4273:      	movb	$0x2f, (%r15,%rax)
    4278:      	xorl	%edi, %edi
    427a:      	cmpl	%r12d, %r13d
    427d:      	seta	%dil
    4281:      	movzbl	%cl, %esi
    4284:      	addq	%rax, %r15
    4287:      	addq	%r15, %rdi
    428a:      	movl	$0x4, %eax
    428f:      	callq	*%rax
    4291:      	movq	%r15, 0x90(%rsp)
    4299:      	cmpl	%r12d, %r13d
    429c:      	jbe	0x4547 <generic_tracepoint_filter+0xd27>
    42a2:      	movq	0x58(%rsp), %rax
    42a7:      	movq	%rax, 0x78(%rsp)
    42ac:      	decl	%r14d
    42af:      	jne	0x4170 <generic_tracepoint_filter+0x950>
    42b5:      	jmp	0x4547 <generic_tracepoint_filter+0xd27>
    42ba:      	nopw	(%rax,%rax)
    42c0:      	leaq	0x10(%r12), %rdx
    42c5:      	movl	$0x4, %eax
    42ca:      	movq	%rbx, %rdi
    42cd:      	movl	$0x8, %esi
    42d2:      	callq	*%rax
    42d4:      	movq	0x88(%rsp), %rax
    42dc:      	cmpq	0x10(%rsp), %rax
    42e1:      	je	0x453f <generic_tracepoint_filter+0xd1f>
    42e7:      	addq	$0x18, %r12
    42eb:      	movl	$0x4, %eax
    42f0:      	leaq	0x78(%rsp), %rdi
    42f5:      	movl	$0x8, %esi
    42fa:      	movq	%r12, %rdx
    42fd:      	callq	*%rax
    42ff:      	movq	0x10(%rsp), %rax
    4304:      	movq	%rax, 0x88(%rsp)
    430c:      	addq	$0x20, %rax
    4310:      	movq	%rax, 0x80(%rsp)
    4318:      	decl	%r14d
    431b:      	jne	0x4170 <generic_tracepoint_filter+0x950>
    4321:      	jmp	0x4547 <generic_tracepoint_filter+0xd27>
    4326:      	leaq	0x18(%r14), %rdx
    432a:      	leaq	0x60(%rsp), %rdi
    432f:      	movl	$0x8, %ecx
    4334:      	movl	$0x4, %eax
    4339:      	movl	$0x8, %esi
    433e:      	callq	*%rax
    4340:      	cmpq	%r14, 0x60(%rsp)
    4345:      	je	0x405e <generic_tracepoint_filter+0x83e>
    434b:      	movq	0x50(%rsp), %r14
    4350:      	movl	0x6410(%r14), %ecx
    4357:      	leal	-0xa(%rcx), %eax
    435a:      	movl	%eax, 0x6410(%r14)
    4361:      	cmpl	$0x9, %ecx
    4364:      	jg	0x4d04 <generic_tracepoint_filter+0x14e4>
    436a:      	movl	$0xffffffdc, 0x6414(%r14) # imm = 0xFFFFFFDC
    4375:      	movq	%r13, %rbx
    4378:      	jmp	0x45c8 <generic_tracepoint_filter+0xda8>
    437d:      	movl	$0x80, %r14d
    4383:      	movl	$0x8, %ebp
    4388:      	leaq	0x10(%rsp), %rbx
    438d:      	nopl	(%rax)
    4390:      	movq	0x78(%rsp), %r15
    4395:      	movq	0x80(%rsp), %rdx
    439d:      	movq	0x88(%rsp), %r12
    43a5:      	cmpq	0x60(%rsp), %r15
    43aa:      	jne	0x43b7 <generic_tracepoint_filter+0xb97>
    43ac:      	cmpq	0x68(%rsp), %rdx
    43b1:      	je	0x453f <generic_tracepoint_filter+0xd1f>
    43b7:      	movl	$0x4, %eax
    43bc:      	leaq	0xa8(%rsp), %rdi
    43c4:      	movl	$0x8, %esi
    43c9:      	callq	*%rax
    43cb:      	cmpq	0xa8(%rsp), %r15
    43d3:      	je	0x44e0 <generic_tracepoint_filter+0xcc0>
    43d9:      	leaq	0x18(%r15), %r13
    43dd:      	movl	$0x4, %eax
    43e2:      	movq	%rbx, %rdi
    43e5:      	movl	$0x8, %esi
    43ea:      	movq	%r13, %rdx
    43ed:      	callq	*%rax
    43ef:      	cmpq	%r15, 0x10(%rsp)
    43f4:      	je	0x44e0 <generic_tracepoint_filter+0xcc0>
    43fa:      	movl	$0x4, %eax
    43ff:      	leaq	0x58(%rsp), %rdi
    4404:      	movl	$0x8, %esi
    4409:      	movq	%r13, %rdx
    440c:      	callq	*%rax
    440e:      	addq	$0x20, %r15
    4412:      	movl	$0x4, %eax
    4417:      	leaq	0x40(%rsp), %rdi
    441c:      	movl	$0x10, %ecx
    4421:      	movl	$0x10, %esi
    4426:      	movq	%r15, %rdx
    4429:      	callq	*%rax
    442b:      	movq	0x70(%rsp), %r15
    4430:      	movq	0x90(%rsp), %rax
    4438:      	movl	0x44(%rsp), %r12d
    443d:      	subq	%r15, %rax
    4440:      	movl	0x98(%rsp), %r13d
    4448:      	movl	%r12d, %edx
    444b:      	subl	%r13d, %edx
    444e:      	movl	$0x0, %ecx
    4453:      	cmovbl	%ecx, %edx
    4456:      	addq	0x48(%rsp), %rdx
    445b:      	xorl	%esi, %esi
    445d:      	cmpl	%r12d, %r13d
    4460:      	seta	%sil
    4464:      	movl	%r12d, %ecx
    4467:      	cmovbl	%r13d, %ecx
    446b:      	addl	%ecx, %esi
    446d:      	movl	%r13d, %edi
    4470:      	subl	%esi, %edi
    4472:      	movl	%edi, 0x98(%rsp)
    4479:      	subq	%rsi, %rax
    447c:      	jb	0x4547 <generic_tracepoint_filter+0xd27>
    4482:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    4488:      	ja	0x4547 <generic_tracepoint_filter+0xd27>
    448e:      	cmpl	%r12d, %r13d
    4491:      	jbe	0x4498 <generic_tracepoint_filter+0xc78>
    4493:      	movb	$0x2f, (%r15,%rax)
    4498:      	xorl	%edi, %edi
    449a:      	cmpl	%r12d, %r13d
    449d:      	seta	%dil
    44a1:      	movzbl	%cl, %esi
    44a4:      	addq	%rax, %r15
    44a7:      	addq	%r15, %rdi
    44aa:      	movl	$0x4, %eax
    44af:      	callq	*%rax
    44b1:      	movq	%r15, 0x90(%rsp)
    44b9:      	cmpl	%r12d, %r13d
    44bc:      	jbe	0x4547 <generic_tracepoint_filter+0xd27>
    44c2:      	movq	0x58(%rsp), %rax
    44c7:      	movq	%rax, 0x78(%rsp)
    44cc:      	decl	%r14d
    44cf:      	jne	0x4390 <generic_tracepoint_filter+0xb70>
    44d5:      	jmp	0x4547 <generic_tracepoint_filter+0xd27>
    44d7:      	nopw	(%rax,%rax)
    44e0:      	leaq	0x10(%r12), %rdx
    44e5:      	movl	$0x4, %eax
    44ea:      	movq	%rbx, %rdi
    44ed:      	movl	$0x8, %esi
    44f2:      	callq	*%rax
    44f4:      	movq	0x88(%rsp), %rax
    44fc:      	cmpq	0x10(%rsp), %rax
    4501:      	je	0x453f <generic_tracepoint_filter+0xd1f>
    4503:      	addq	$0x18, %r12
    4507:      	movl	$0x4, %eax
    450c:      	leaq	0x78(%rsp), %rdi
    4511:      	movl	$0x8, %esi
    4516:      	movq	%r12, %rdx
    4519:      	callq	*%rax
    451b:      	movq	0x10(%rsp), %rax
    4520:      	movq	%rax, 0x88(%rsp)
    4528:      	addq	$0x20, %rax
    452c:      	movq	%rax, 0x80(%rsp)
    4534:      	decl	%r14d
    4537:      	jne	0x4390 <generic_tracepoint_filter+0xb70>
    453d:      	jmp	0x4547 <generic_tracepoint_filter+0xd27>
    453f:      	movb	$0x1, 0x9c(%rsp)
    4547:      	movq	0x90(%rsp), %rbx
    454f:      	movq	0xc0(%rsp), %rcx
    4557:      	cmpq	%rcx, %rbx
    455a:      	je	0x45a8 <generic_tracepoint_filter+0xd88>
    455c:      	xorl	%ecx, %ecx
    455e:      	cmpb	$0x0, 0x9c(%rsp)
    4566:      	sete	%cl
    4569:      	addl	%ecx, %ecx
    456b:      	movl	0x98(%rsp), %eax
    4572:      	movq	0x50(%rsp), %r14
    4577:      	movl	%eax, 0x6410(%r14)
    457e:      	movl	%ecx, 0x6414(%r14)
    4585:      	testl	%eax, %eax
    4587:      	movq	0x38(%rsp), %rbp
    458c:      	jle	0x459e <generic_tracepoint_filter+0xd7e>
    458e:      	movl	$0x1000, %ecx           # imm = 0x1000
    4593:      	subl	%eax, %ecx
    4595:      	movl	%ecx, 0x6410(%r14)
    459c:      	movl	%ecx, %eax
    459e:      	testq	%rbx, %rbx
    45a1:      	jne	0x45cd <generic_tracepoint_filter+0xdad>
    45a3:      	jmp	0x46c7 <generic_tracepoint_filter+0xea7>
    45a8:      	movq	0x50(%rsp), %r14
    45ad:      	movl	$0x0, 0x6410(%r14)
    45b8:      	movl	$0x0, 0x6414(%r14)
    45c3:      	xorl	%eax, %eax
    45c5:      	movq	%rcx, %rbx
    45c8:      	movq	0x38(%rsp), %rbp
    45cd:      	xorl	%ecx, %ecx
    45cf:      	movq	%r14, %rdx
    45d2:      	movl	%eax, %r14d
    45d5:      	subl	$0x7f, %r14d
    45d9:      	movl	$0x7f, %r15d
    45df:      	cmovbl	%eax, %r15d
    45e3:      	cmovbl	%ecx, %r14d
    45e7:      	cmpl	$0xff, %eax
    45ec:      	movl	$0xff, %ecx
    45f1:      	cmovbl	%eax, %ecx
    45f4:      	movzbl	%cl, %esi
    45f7:      	movl	%esi, 0x6410(%rdx)
    45fd:      	movl	$0x4, %eax
    4602:      	movq	%rbp, %rdi
    4605:      	movq	%rbx, %rdx
    4608:      	callq	*%rax
    460a:      	testq	%rax, %rax
    460d:      	je	0x466c <generic_tracepoint_filter+0xe4c>
    460f:      	negl	%eax
    4611:      	movw	%ax, 0x60(%rsp)
    4616:      	movw	$0x8, 0x62(%rsp)
    461d:      	movabsq	$0x4000002de, %rax      # imm = 0x4000002DE
    4627:      	movq	%rax, 0x64(%rsp)
    462c:      	movq	(%rip), %rdi            # 0x4633 <generic_tracepoint_filter+0xe13>
    4633:      	leaq	0x60(%rsp), %rsi
    4638:      	movl	$0x1, %eax
    463d:      	callq	*%rax
    463f:      	testq	%rax, %rax
    4642:      	je	0x4648 <generic_tracepoint_filter+0xe28>
    4644:      	incl	(%rax)
    4646:      	jmp	0x466c <generic_tracepoint_filter+0xe4c>
    4648:      	movl	$0x1, 0x40(%rsp)
    4650:      	movq	(%rip), %rdi            # 0x4657 <generic_tracepoint_filter+0xe37>
    4657:      	xorl	%ecx, %ecx
    4659:      	leaq	0x60(%rsp), %rsi
    465e:      	leaq	0x40(%rsp), %rdx
    4663:      	movl	$0x2, %eax
    4668:      	xorl	%ecx, %ecx
    466a:      	callq	*%rax
    466c:      	movq	0x50(%rsp), %rax
    4671:      	leaq	0x6390(%rax), %rdi
    4678:      	addq	%r14, %rbx
    467b:      	movq	%rax, %r14
    467e:      	movl	$0x4, %eax
    4683:      	movl	%r15d, %esi
    4686:      	movq	%rbx, %rdx
    4689:      	callq	*%rax
    468b:      	testq	%rax, %rax
    468e:      	je	0x46c7 <generic_tracepoint_filter+0xea7>
    4690:      	negl	%eax
    4692:      	movw	%ax, 0x60(%rsp)
    4697:      	movw	$0x8, 0x62(%rsp)
    469e:      	movabsq	$0x4000002e0, %rax      # imm = 0x4000002E0
    46a8:      	movq	%rax, 0x64(%rsp)
    46ad:      	movq	(%rip), %rdi            # 0x46b4 <generic_tracepoint_filter+0xe94>
    46b4:      	leaq	0x60(%rsp), %rsi
    46b9:      	movl	$0x1, %eax
    46be:      	callq	*%rax
    46c0:      	testq	%rax, %rax
    46c3:      	je	0x46f4 <generic_tracepoint_filter+0xed4>
    46c5:      	incl	(%rax)
    46c7:      	movl	0x6410(%r14), %eax
    46ce:      	leal	-0x101(%rax), %ecx
    46d4:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
    46da:      	ja	0x472d <generic_tracepoint_filter+0xf0d>
    46dc:      	movq	0x8(%rsp), %rax
    46e1:      	movl	$0xffffffff, (%rax)     # imm = 0xFFFFFFFF
    46e7:      	movq	0xb8(%rsp), %rbx
    46ef:      	jmp	0x4843 <generic_tracepoint_filter+0x1023>
    46f4:      	movl	$0x1, 0x40(%rsp)
    46fc:      	movq	(%rip), %rdi            # 0x4703 <generic_tracepoint_filter+0xee3>
    4703:      	xorl	%ecx, %ecx
    4705:      	leaq	0x60(%rsp), %rsi
    470a:      	leaq	0x40(%rsp), %rdx
    470f:      	movl	$0x2, %eax
    4714:      	xorl	%ecx, %ecx
    4716:      	callq	*%rax
    4718:      	movl	0x6410(%r14), %eax
    471f:      	leal	-0x101(%rax), %ecx
    4725:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
    472b:      	jbe	0x46dc <generic_tracepoint_filter+0xebc>
    472d:      	movzbl	%al, %ebx
    4730:      	leaq	0x5f80(%r14), %rdi
    4737:      	movl	$0x4, %eax
    473c:      	movl	%ebx, %esi
    473e:      	movq	%rbp, %rdx
    4741:      	callq	*%rax
    4743:      	movq	%rax, %r15
    4746:      	testq	%rax, %rax
    4749:      	je	0x47ab <generic_tracepoint_filter+0xf8b>
    474b:      	movl	%r15d, %eax
    474e:      	negl	%eax
    4750:      	movw	%ax, 0x60(%rsp)
    4755:      	movw	$0xf, 0x62(%rsp)
    475c:      	movabsq	$0x400000164, %rax      # imm = 0x400000164
    4766:      	movq	%rax, 0x64(%rsp)
    476b:      	movq	(%rip), %rdi            # 0x4772 <generic_tracepoint_filter+0xf52>
    4772:      	leaq	0x60(%rsp), %rsi
    4777:      	movl	$0x1, %eax
    477c:      	callq	*%rax
    477e:      	testq	%rax, %rax
    4781:      	je	0x4787 <generic_tracepoint_filter+0xf67>
    4783:      	incl	(%rax)
    4785:      	jmp	0x47ab <generic_tracepoint_filter+0xf8b>
    4787:      	movl	$0x1, 0x40(%rsp)
    478f:      	movq	(%rip), %rdi            # 0x4796 <generic_tracepoint_filter+0xf76>
    4796:      	xorl	%ecx, %ecx
    4798:      	leaq	0x60(%rsp), %rsi
    479d:      	leaq	0x40(%rsp), %rdx
    47a2:      	movl	$0x2, %eax
    47a7:      	xorl	%ecx, %ecx
    47a9:      	callq	*%rax
    47ab:      	testl	%r15d, %r15d
    47ae:      	cmovel	%ebx, %r15d
    47b2:      	movl	%r15d, 0x5f78(%r14)
    47b9:      	cmpl	$0x7f, %ebx
    47bc:      	movl	$0x7f, %esi
    47c1:      	cmovbl	%ebx, %esi
    47c4:      	leaq	0x6080(%r14), %rdi
    47cb:      	leaq	0x6390(%r14), %rdx
    47d2:      	movl	$0x4, %eax
    47d7:      	callq	*%rax
    47d9:      	testq	%rax, %rax
    47dc:      	movq	0xb8(%rsp), %rbx
    47e4:      	je	0x4843 <generic_tracepoint_filter+0x1023>
    47e6:      	negl	%eax
    47e8:      	movw	%ax, 0x60(%rsp)
    47ed:      	movw	$0xf, 0x62(%rsp)
    47f4:      	movabsq	$0x40000016a, %rax      # imm = 0x40000016A
    47fe:      	movq	%rax, 0x64(%rsp)
    4803:      	movq	(%rip), %rdi            # 0x480a <generic_tracepoint_filter+0xfea>
    480a:      	leaq	0x60(%rsp), %rsi
    480f:      	movl	$0x1, %eax
    4814:      	callq	*%rax
    4816:      	testq	%rax, %rax
    4819:      	je	0x481f <generic_tracepoint_filter+0xfff>
    481b:      	incl	(%rax)
    481d:      	jmp	0x4843 <generic_tracepoint_filter+0x1023>
    481f:      	movl	$0x1, 0x40(%rsp)
    4827:      	movq	(%rip), %rdi            # 0x482e <generic_tracepoint_filter+0x100e>
    482e:      	xorl	%ecx, %ecx
    4830:      	leaq	0x60(%rsp), %rsi
    4835:      	leaq	0x40(%rsp), %rdx
    483a:      	movl	$0x2, %eax
    483f:      	xorl	%ecx, %ecx
    4841:      	callq	*%rax
    4843:      	leaq	0x5f10(%r14), %r15
    484a:      	orb	$0x10, 0x1(%r14)
    484f:      	leaq	0x5ef8(%r14), %rsi
    4856:      	movq	(%rip), %rdi            # 0x485d <generic_tracepoint_filter+0x103d>
    485d:      	movl	$0x1, %eax
    4862:      	callq	*%rax
    4864:      	testq	%rax, %rax
    4867:      	je	0x5e49 <generic_tracepoint_filter+0x2629>
    486d:      	movq	0x5eb8(%r14), %r13
    4874:      	cmpq	$0x6, %r13
    4878:      	jae	0x4aa6 <generic_tracepoint_filter+0x1286>
    487e:      	movslq	(%rax), %rcx
    4881:      	testq	%rcx, %rcx
    4884:      	je	0x4ac8 <generic_tracepoint_filter+0x12a8>
    488a:      	cmpq	%rcx, %r13
    488d:      	jae	0x4aa6 <generic_tracepoint_filter+0x1286>
    4893:      	movq	%rax, 0x8(%rsp)
    4898:      	movq	%rcx, 0xc0(%rsp)
    48a0:      	movq	%rbx, 0xb8(%rsp)
    48a8:      	movl	%r13d, 0x10(%rsp)
    48ad:      	movl	$0x0, 0x58(%rsp)
    48b5:      	movq	(%rip), %rdi            # 0x48bc <generic_tracepoint_filter+0x109c>
    48bc:      	leaq	0x10(%rsp), %rsi
    48c1:      	movl	$0x1, %eax
    48c6:      	callq	*%rax
    48c8:      	testq	%rax, %rax
    48cb:      	movq	%r15, 0x38(%rsp)
    48d0:      	je	0x4ae4 <generic_tracepoint_filter+0x12c4>
    48d6:      	movq	%rax, %rbx
    48d9:      	movl	(%rax), %eax
    48db:      	testl	%eax, %eax
    48dd:      	je	0x4ae4 <generic_tracepoint_filter+0x12c4>
    48e3:      	cmpl	$0x0, 0x68(%r15)
    48e8:      	js	0x5deb <generic_tracepoint_filter+0x25cb>
    48ee:      	cmpl	$0x1b, %eax
    48f1:      	ja	0x5deb <generic_tracepoint_filter+0x25cb>
    48f7:      	movl	$0x60, %ecx
    48fc:      	btl	%eax, %ecx
    48ff:      	jb	0x557c <generic_tracepoint_filter+0x1d5c>
    4905:      	movl	$0x4000100, %ecx        # imm = 0x4000100
    490a:      	btl	%eax, %ecx
    490d:      	jb	0x54e9 <generic_tracepoint_filter+0x1cc9>
    4913:      	movl	$0x8000200, %ecx        # imm = 0x8000200
    4918:      	btl	%eax, %ecx
    491b:      	jae	0x5deb <generic_tracepoint_filter+0x25cb>
    4921:      	movq	%rbx, %rsi
    4924:      	addq	$0x4, %rsi
    4928:      	movq	(%rip), %rdi            # 0x492f <generic_tracepoint_filter+0x110f>
    492f:      	movl	$0x1, %eax
    4934:      	callq	*%rax
    4936:      	testq	%rax, %rax
    4939:      	je	0x5deb <generic_tracepoint_filter+0x25cb>
    493f:      	movq	%rax, %r12
    4942:      	movq	0x38(%rsp), %rax
    4947:      	movl	0x68(%rax), %eax
    494a:      	cmpl	$0x7f, %eax
    494d:      	movl	$0x7f, %r14d
    4953:      	cmovll	%eax, %r14d
    4957:      	movq	(%rip), %rdi            # 0x495e <generic_tracepoint_filter+0x113e>
    495e:      	leaq	0x58(%rsp), %rsi
    4963:      	movl	$0x1, %eax
    4968:      	callq	*%rax
    496a:      	testq	%rax, %rax
    496d:      	je	0x5deb <generic_tracepoint_filter+0x25cb>
    4973:      	movq	%rax, %rbp
    4976:      	leal	(,%r14,8), %eax
    497e:      	movl	%eax, (%rbp)
    4981:      	movq	0x38(%rsp), %rax
    4986:      	cmpl	$0x0, 0x6c(%rax)
    498a:      	jne	0x4a6d <generic_tracepoint_filter+0x124d>
    4990:      	movq	0x38(%rsp), %r15
    4995:      	movl	0x68(%r15), %ecx
    4999:      	movl	%ecx, %eax
    499b:      	subl	%r14d, %eax
    499e:      	movl	%r14d, %edx
    49a1:      	andl	$0x7f, %edx
    49a4:      	addl	%edx, %eax
    49a6:      	addl	%ecx, %edx
    49a8:      	movl	%r14d, %ecx
    49ab:      	notl	%ecx
    49ad:      	addl	%edx, %ecx
    49af:      	subl	%r14d, %edx
    49b2:      	leal	-0x4(%rdx), %esi
    49b5:      	leaq	0x1f3(%r15), %rdi
    49bc:      	leal	-0x3(%rdx), %r8d
    49c0:      	addl	$-0x2, %edx
    49c3:      	movq	$-0x3, %r9
    49ca:      	leal	(%rcx,%r9), %r10d
    49ce:      	addl	$0x3, %r10d
    49d2:      	andl	$0x7f, %r10d
    49d6:      	movzbl	0x170(%r15,%r10), %r10d
    49df:      	movb	%r10b, -0x3(%rdi)
    49e3:      	leaq	(%rax,%r9), %r10
    49e7:      	cmpq	$-0x2, %r10
    49eb:      	je	0x4a65 <generic_tracepoint_filter+0x1245>
    49ed:      	leal	(%rdx,%r9), %r11d
    49f1:      	addl	$0x3, %r11d
    49f5:      	andl	$0x7f, %r11d
    49f9:      	movzbl	0x170(%r15,%r11), %r11d
    4a02:      	movb	%r11b, -0x2(%rdi)
    4a06:      	cmpq	$-0x1, %r10
    4a0a:      	je	0x4a65 <generic_tracepoint_filter+0x1245>
    4a0c:      	leal	(%r8,%r9), %r10d
    4a10:      	addl	$0x3, %r10d
    4a14:      	andl	$0x7f, %r10d
    4a18:      	movzbl	0x170(%r15,%r10), %r10d
    4a21:      	movb	%r10b, -0x1(%rdi)
    4a25:      	movq	%rax, %r10
    4a28:      	addq	%r9, %r10
    4a2b:      	je	0x4a65 <generic_tracepoint_filter+0x1245>
    4a2d:      	cmpq	$-0x7f, %r9
    4a31:      	je	0x4a65 <generic_tracepoint_filter+0x1245>
    4a33:      	leal	(%rsi,%r9), %r10d
    4a37:      	addl	$0x3, %r10d
    4a3b:      	andl	$0x7f, %r10d
    4a3f:      	movzbl	0x170(%r15,%r10), %r10d
    4a48:      	movb	%r10b, (%rdi)
    4a4b:      	addq	$0x4, %rdi
    4a4f:      	leaq	(%rax,%r9), %r10
    4a53:      	addq	$-0x4, %r10
    4a57:      	addq	$-0x4, %r9
    4a5b:      	cmpq	$-0x3, %r10
    4a5f:      	jne	0x49ca <generic_tracepoint_filter+0x11aa>
    4a65:      	movl	$0x1, 0x6c(%r15)
    4a6d:      	cmpl	$0x7f, %r14d
    4a71:      	ja	0x4a99 <generic_tracepoint_filter+0x1279>
    4a73:      	movslq	%r14d, %rsi
    4a76:      	movq	%rbp, %rdi
    4a79:      	addq	$0x4, %rdi
    4a7d:      	movq	0x38(%rsp), %rax
    4a82:      	leaq	0x1f0(%rax), %rdx
    4a89:      	movl	$0x4, %eax
    4a8e:      	callq	*%rax
    4a90:      	testq	%rax, %rax
    4a93:      	js	0x5deb <generic_tracepoint_filter+0x25cb>
    4a99:      	movl	$0x1, %eax
    4a9e:      	movq	%r12, %rdi
    4aa1:      	jmp	0x5574 <generic_tracepoint_filter+0x1d54>
    4aa6:      	movl	(%r15), %eax
    4aa9:      	movl	%eax, 0x10(%r14)
    4aad:      	movq	0x8(%r15), %rax
    4ab1:      	movq	%rax, 0x18(%r14)
    4ab5:      	cmpb	$0x0, 0x5ec0(%r14)
    4abd:      	jne	0x5e2e <generic_tracepoint_filter+0x260e>
    4ac3:      	jmp	0x5e49 <generic_tracepoint_filter+0x2629>
    4ac8:      	movb	$0x1, 0x5ec0(%r14)
    4ad0:      	movl	(%r15), %eax
    4ad3:      	movl	%eax, 0x10(%r14)
    4ad7:      	movq	0x8(%r15), %rax
    4adb:      	movq	%rax, 0x18(%r14)
    4adf:      	jmp	0x5e2e <generic_tracepoint_filter+0x260e>
    4ae4:      	movq	0x8(%rsp), %r10
    4ae9:      	movq	(%rip), %rax            # 0x4af0 <generic_tracepoint_filter+0x12d0>
    4af0:      	cmpb	$0x0, (%rax)
    4af3:      	je	0x4d35 <generic_tracepoint_filter+0x1515>
    4af9:      	movq	(%rip), %rdi            # 0x4b00 <generic_tracepoint_filter+0x12e0>
    4b00:      	movl	$0x1, %eax
    4b05:      	movq	0x38(%rsp), %rsi
    4b0a:      	callq	*%rax
    4b0c:      	movq	0x8(%rsp), %r10
    4b11:      	testq	%rax, %rax
    4b14:      	je	0x4d35 <generic_tracepoint_filter+0x1515>
    4b1a:      	movq	%rax, %rbp
    4b1d:      	leal	0x5(%r13), %eax
    4b21:      	movl	%eax, 0x10(%rsp)
    4b25:      	movl	$0x0, 0x58(%rsp)
    4b2d:      	movq	(%rip), %rdi            # 0x4b34 <generic_tracepoint_filter+0x1314>
    4b34:      	leaq	0x10(%rsp), %rsi
    4b39:      	movl	$0x1, %eax
    4b3e:      	callq	*%rax
    4b40:      	testq	%rax, %rax
    4b43:      	je	0x4d30 <generic_tracepoint_filter+0x1510>
    4b49:      	movq	%rax, %r12
    4b4c:      	movl	(%rax), %eax
    4b4e:      	testl	%eax, %eax
    4b50:      	je	0x4d30 <generic_tracepoint_filter+0x1510>
    4b56:      	cmpl	$0x0, (%rbp)
    4b5a:      	js	0x5deb <generic_tracepoint_filter+0x25cb>
    4b60:      	cmpl	$0x1b, %eax
    4b63:      	ja	0x5deb <generic_tracepoint_filter+0x25cb>
    4b69:      	movl	$0x60, %ecx
    4b6e:      	btl	%eax, %ecx
    4b71:      	jb	0x57d8 <generic_tracepoint_filter+0x1fb8>
    4b77:      	movl	$0x4000100, %ecx        # imm = 0x4000100
    4b7c:      	btl	%eax, %ecx
    4b7f:      	jb	0x5748 <generic_tracepoint_filter+0x1f28>
    4b85:      	movl	$0x8000200, %ecx        # imm = 0x8000200
    4b8a:      	btl	%eax, %ecx
    4b8d:      	jae	0x5deb <generic_tracepoint_filter+0x25cb>
    4b93:      	movq	%r12, %rsi
    4b96:      	addq	$0x4, %rsi
    4b9a:      	movq	(%rip), %rdi            # 0x4ba1 <generic_tracepoint_filter+0x1381>
    4ba1:      	movl	$0x1, %eax
    4ba6:      	callq	*%rax
    4ba8:      	testq	%rax, %rax
    4bab:      	je	0x5deb <generic_tracepoint_filter+0x25cb>
    4bb1:      	movq	%rax, %r15
    4bb4:      	movl	(%rbp), %eax
    4bb7:      	cmpl	$0x7f, %eax
    4bba:      	movl	$0x7f, %r14d
    4bc0:      	cmovll	%eax, %r14d
    4bc4:      	movq	(%rip), %rdi            # 0x4bcb <generic_tracepoint_filter+0x13ab>
    4bcb:      	leaq	0x58(%rsp), %rsi
    4bd0:      	movl	$0x1, %eax
    4bd5:      	callq	*%rax
    4bd7:      	testq	%rax, %rax
    4bda:      	je	0x5deb <generic_tracepoint_filter+0x25cb>
    4be0:      	movq	%rax, %rbx
    4be3:      	leal	(,%r14,8), %eax
    4beb:      	movl	%eax, (%rbx)
    4bed:      	cmpl	$0x0, 0x4(%rbp)
    4bf1:      	jne	0x4ccd <generic_tracepoint_filter+0x14ad>
    4bf7:      	movl	(%rbp), %ecx
    4bfa:      	movl	%ecx, %eax
    4bfc:      	subl	%r14d, %eax
    4bff:      	movl	%r14d, %edx
    4c02:      	andl	$0x7f, %edx
    4c05:      	addl	%edx, %eax
    4c07:      	addl	%ecx, %edx
    4c09:      	movl	%r14d, %ecx
    4c0c:      	notl	%ecx
    4c0e:      	addl	%edx, %ecx
    4c10:      	subl	%r14d, %edx
    4c13:      	leal	-0x4(%rdx), %esi
    4c16:      	leaq	0x18b(%rbp), %rdi
    4c1d:      	leal	-0x3(%rdx), %r8d
    4c21:      	addl	$-0x2, %edx
    4c24:      	movq	$-0x3, %r9
    4c2b:      	leal	(%rcx,%r9), %r10d
    4c2f:      	addl	$0x3, %r10d
    4c33:      	andl	$0x7f, %r10d
    4c37:      	movzbl	0x108(%rbp,%r10), %r10d
    4c40:      	movb	%r10b, -0x3(%rdi)
    4c44:      	leaq	(%rax,%r9), %r10
    4c48:      	cmpq	$-0x2, %r10
    4c4c:      	je	0x4cc6 <generic_tracepoint_filter+0x14a6>
    4c4e:      	leal	(%rdx,%r9), %r11d
    4c52:      	addl	$0x3, %r11d
    4c56:      	andl	$0x7f, %r11d
    4c5a:      	movzbl	0x108(%rbp,%r11), %r11d
    4c63:      	movb	%r11b, -0x2(%rdi)
    4c67:      	cmpq	$-0x1, %r10
    4c6b:      	je	0x4cc6 <generic_tracepoint_filter+0x14a6>
    4c6d:      	leal	(%r8,%r9), %r10d
    4c71:      	addl	$0x3, %r10d
    4c75:      	andl	$0x7f, %r10d
    4c79:      	movzbl	0x108(%rbp,%r10), %r10d
    4c82:      	movb	%r10b, -0x1(%rdi)
    4c86:      	movq	%rax, %r10
    4c89:      	addq	%r9, %r10
    4c8c:      	je	0x4cc6 <generic_tracepoint_filter+0x14a6>
    4c8e:      	cmpq	$-0x7f, %r9
    4c92:      	je	0x4cc6 <generic_tracepoint_filter+0x14a6>
    4c94:      	leal	(%rsi,%r9), %r10d
    4c98:      	addl	$0x3, %r10d
    4c9c:      	andl	$0x7f, %r10d
    4ca0:      	movzbl	0x108(%rbp,%r10), %r10d
    4ca9:      	movb	%r10b, (%rdi)
    4cac:      	addq	$0x4, %rdi
    4cb0:      	leaq	(%rax,%r9), %r10
    4cb4:      	addq	$-0x4, %r10
    4cb8:      	addq	$-0x4, %r9
    4cbc:      	cmpq	$-0x3, %r10
    4cc0:      	jne	0x4c2b <generic_tracepoint_filter+0x140b>
    4cc6:      	movl	$0x1, 0x4(%rbp)
    4ccd:      	cmpl	$0x7f, %r14d
    4cd1:      	ja	0x4cf7 <generic_tracepoint_filter+0x14d7>
    4cd3:      	movslq	%r14d, %rsi
    4cd6:      	movq	%rbx, %rdi
    4cd9:      	addq	$0x4, %rdi
    4cdd:      	addq	$0x188, %rbp            # imm = 0x188
    4ce4:      	movl	$0x4, %eax
    4ce9:      	movq	%rbp, %rdx
    4cec:      	callq	*%rax
    4cee:      	testq	%rax, %rax
    4cf1:      	js	0x5deb <generic_tracepoint_filter+0x25cb>
    4cf7:      	movl	$0x1, %eax
    4cfc:      	movq	%r15, %rdi
    4cff:      	jmp	0x57d0 <generic_tracepoint_filter+0x1fb0>
    4d04:      	movq	%r12, %r13
    4d07:      	addq	$0xff6, %r13            # imm = 0xFF6
    4d0e:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
    4d18:      	movq	%rax, 0xff6(%r12)
    4d20:      	movw	$0x2964, 0xffe(%r12)    # imm = 0x2964
    4d2b:      	jmp	0x4063 <generic_tracepoint_filter+0x843>
    4d30:      	movq	0x8(%rsp), %r10
    4d35:      	movl	%r13d, %eax
    4d38:      	leaq	0x4(,%rax,4), %rcx
    4d40:      	movl	0x4(%r10,%rax,4), %eax
    4d45:      	leal	(%rax,%rcx), %r14d
    4d49:      	andl	$0x3ff, %r14d           # imm = 0x3FF
    4d50:      	addl	%eax, %ecx
    4d52:      	addl	$0x4, %ecx
    4d55:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    4d5b:      	leaq	0x8(%r14), %rbp
    4d5f:      	cmpl	$0x5, (%rcx,%r10)
    4d64:      	jb	0x528e <generic_tracepoint_filter+0x1a6e>
    4d6a:      	movl	(%rbp,%r10), %r12d
    4d6f:      	movl	0x4(%rbp,%r10), %edi
    4d74:      	movl	0x8(%rbp,%r10), %edx
    4d79:      	movq	$0x0, 0x68(%rsp)
    4d82:      	movq	$0x0, 0x60(%rsp)
    4d8b:      	cmpl	$0x4, %edx
    4d8e:      	movl	$0x4, %ecx
    4d93:      	cmovbl	%edx, %ecx
    4d96:      	cmpl	$0x6, %r12d
    4d9a:      	jne	0x4db0 <generic_tracepoint_filter+0x1590>
    4d9c:      	movabsq	$0x100000001, %rsi      # imm = 0x100000001
    4da6:      	movq	%rsi, 0x60(%rsp)
    4dab:      	movq	%rsi, 0x68(%rsp)
    4db0:      	testl	%edx, %edx
    4db2:      	je	0x5295 <generic_tracepoint_filter+0x1a75>
    4db8:      	movq	0x38(%rsp), %rdx
    4dbd:      	leaq	0x24(%rdx), %rsi
    4dc1:      	testb	$0x1, %dil
    4dc5:      	movq	%rsi, 0xb0(%rsp)
    4dcd:      	movq	%rsi, %r8
    4dd0:      	cmoveq	%rdx, %r8
    4dd4:      	addq	$0x10, %rdx
    4dd8:      	movq	%rdx, 0xd0(%rsp)
    4de0:      	leal	(%rax,%r13,4), %r9d
    4de4:      	addl	$0x4, %r9d
    4de8:      	andl	$0x3ff, %r9d            # imm = 0x3FF
    4def:      	addq	$0x14, %r9
    4df3:      	decq	%rcx
    4df6:      	cmpq	$0x3, %rcx
    4dfa:      	movl	$0x3, %eax
    4dff:      	cmovbq	%rcx, %rax
    4e03:      	movl	%eax, %eax
    4e05:      	leaq	0x4(,%rax,4), %r11
    4e0d:      	xorl	%r13d, %r13d
    4e10:      	movq	%rdi, 0x30(%rsp)
    4e15:      	movq	%r8, 0x28(%rsp)
    4e1a:      	movq	%r9, 0x20(%rsp)
    4e1f:      	movq	%r11, 0x18(%rsp)
    4e24:      	jmp	0x4e60 <generic_tracepoint_filter+0x1640>
    4e26:      	movq	0x8(%rsp), %r10
    4e2b:      	movq	0x30(%rsp), %rdi
    4e30:      	movq	0x28(%rsp), %r8
    4e35:      	movq	0x20(%rsp), %r9
    4e3a:      	movq	0x18(%rsp), %r11
    4e3f:      	cmpl	$0x6, %r12d
    4e43:      	setne	%al
    4e46:      	xorb	$0x1, %bl
    4e49:      	orb	%al, %bl
    4e4b:      	movzbl	%bl, %eax
    4e4e:      	movl	%eax, 0x60(%rsp,%r13)
    4e53:      	addq	$0x4, %r13
    4e57:      	cmpq	%r13, %r11
    4e5a:      	je	0x5295 <generic_tracepoint_filter+0x1a75>
    4e60:      	leaq	(%r9,%r13), %rax
    4e64:      	movl	(%r8), %ecx
    4e67:      	cmpq	$0x3e8, %rax            # imm = 0x3E8
    4e6d:      	jbe	0x507a <generic_tracepoint_filter+0x185a>
    4e73:      	xorl	%r15d, %r15d
    4e76:      	testb	$0x2, %dil
    4e7a:      	je	0x5097 <generic_tracepoint_filter+0x1877>
    4e80:      	testb	$0x1, %dil
    4e84:      	jne	0x50b8 <generic_tracepoint_filter+0x1898>
    4e8a:      	movq	0x38(%rsp), %rcx
    4e8f:      	movl	(%rcx), %eax
    4e91:      	movb	$0x1, %bl
    4e93:      	cmpq	%rax, %r15
    4e96:      	je	0x4e3f <generic_tracepoint_filter+0x161f>
    4e98:      	movl	0x10(%rcx), %eax
    4e9b:      	cmpq	%rax, %r15
    4e9e:      	je	0x4e3f <generic_tracepoint_filter+0x161f>
    4ea0:      	movl	$0x1, %eax
    4ea5:      	movq	0xd0(%rsp), %rsi
    4ead:      	movq	(%rip), %rdi            # 0x4eb4 <generic_tracepoint_filter+0x1694>
    4eb4:      	callq	*%rax
    4eb6:      	testq	%rax, %rax
    4eb9:      	je	0x525d <generic_tracepoint_filter+0x1a3d>
    4ebf:      	movq	%rax, %rsi
    4ec2:      	movl	(%rax), %eax
    4ec4:      	cmpq	%rax, %r15
    4ec7:      	je	0x4e26 <generic_tracepoint_filter+0x1606>
    4ecd:      	movl	0x10(%rsi), %eax
    4ed0:      	cmpq	%rax, %r15
    4ed3:      	je	0x4e26 <generic_tracepoint_filter+0x1606>
    4ed9:      	addq	$0x10, %rsi
    4edd:      	movl	$0x1, %eax
    4ee2:      	movq	(%rip), %rdi            # 0x4ee9 <generic_tracepoint_filter+0x16c9>
    4ee9:      	callq	*%rax
    4eeb:      	testq	%rax, %rax
    4eee:      	je	0x525d <generic_tracepoint_filter+0x1a3d>
    4ef4:      	movq	%rax, %rsi
    4ef7:      	movl	(%rax), %eax
    4ef9:      	cmpq	%rax, %r15
    4efc:      	je	0x4e26 <generic_tracepoint_filter+0x1606>
    4f02:      	movl	0x10(%rsi), %eax
    4f05:      	cmpq	%rax, %r15
    4f08:      	je	0x4e26 <generic_tracepoint_filter+0x1606>
    4f0e:      	addq	$0x10, %rsi
    4f12:      	movl	$0x1, %eax
    4f17:      	movq	(%rip), %rdi            # 0x4f1e <generic_tracepoint_filter+0x16fe>
    4f1e:      	callq	*%rax
    4f20:      	testq	%rax, %rax
    4f23:      	je	0x525d <generic_tracepoint_filter+0x1a3d>
    4f29:      	movq	%rax, %rsi
    4f2c:      	movl	(%rax), %eax
    4f2e:      	cmpq	%rax, %r15
    4f31:      	je	0x4e26 <generic_tracepoint_filter+0x1606>
    4f37:      	movl	0x10(%rsi), %eax
    4f3a:      	cmpq	%rax, %r15
    4f3d:      	je	0x4e26 <generic_tracepoint_filter+0x1606>
    4f43:      	addq	$0x10, %rsi
    4f47:      	movl	$0x1, %eax
    4f4c:      	movq	(%rip), %rdi            # 0x4f53 <generic_tracepoint_filter+0x1733>
    4f53:      	callq	*%rax
    4f55:      	testq	%rax, %rax
    4f58:      	je	0x525d <generic_tracepoint_filter+0x1a3d>
    4f5e:      	movq	%rax, %rsi
    4f61:      	movl	(%rax), %eax
    4f63:      	cmpq	%rax, %r15
    4f66:      	je	0x4e26 <generic_tracepoint_filter+0x1606>
    4f6c:      	movl	0x10(%rsi), %eax
    4f6f:      	cmpq	%rax, %r15
    4f72:      	je	0x4e26 <generic_tracepoint_filter+0x1606>
    4f78:      	addq	$0x10, %rsi
    4f7c:      	movl	$0x1, %eax
    4f81:      	movq	(%rip), %rdi            # 0x4f88 <generic_tracepoint_filter+0x1768>
    4f88:      	callq	*%rax
    4f8a:      	testq	%rax, %rax
    4f8d:      	je	0x525d <generic_tracepoint_filter+0x1a3d>
    4f93:      	movq	%rax, %rsi
    4f96:      	movl	(%rax), %eax
    4f98:      	cmpq	%rax, %r15
    4f9b:      	je	0x4e26 <generic_tracepoint_filter+0x1606>
    4fa1:      	movl	0x10(%rsi), %eax
    4fa4:      	cmpq	%rax, %r15
    4fa7:      	je	0x4e26 <generic_tracepoint_filter+0x1606>
    4fad:      	addq	$0x10, %rsi
    4fb1:      	movl	$0x1, %eax
    4fb6:      	movq	(%rip), %rdi            # 0x4fbd <generic_tracepoint_filter+0x179d>
    4fbd:      	callq	*%rax
    4fbf:      	testq	%rax, %rax
    4fc2:      	je	0x525d <generic_tracepoint_filter+0x1a3d>
    4fc8:      	movq	%rax, %rsi
    4fcb:      	movl	(%rax), %eax
    4fcd:      	cmpq	%rax, %r15
    4fd0:      	je	0x4e26 <generic_tracepoint_filter+0x1606>
    4fd6:      	movl	0x10(%rsi), %eax
    4fd9:      	cmpq	%rax, %r15
    4fdc:      	je	0x4e26 <generic_tracepoint_filter+0x1606>
    4fe2:      	addq	$0x10, %rsi
    4fe6:      	movl	$0x1, %eax
    4feb:      	movq	(%rip), %rdi            # 0x4ff2 <generic_tracepoint_filter+0x17d2>
    4ff2:      	callq	*%rax
    4ff4:      	testq	%rax, %rax
    4ff7:      	je	0x525d <generic_tracepoint_filter+0x1a3d>
    4ffd:      	movq	%rax, %rsi
    5000:      	movl	(%rax), %eax
    5002:      	cmpq	%rax, %r15
    5005:      	je	0x4e26 <generic_tracepoint_filter+0x1606>
    500b:      	movl	0x10(%rsi), %eax
    500e:      	cmpq	%rax, %r15
    5011:      	je	0x4e26 <generic_tracepoint_filter+0x1606>
    5017:      	addq	$0x10, %rsi
    501b:      	movl	$0x1, %eax
    5020:      	movq	(%rip), %rdi            # 0x5027 <generic_tracepoint_filter+0x1807>
    5027:      	callq	*%rax
    5029:      	testq	%rax, %rax
    502c:      	je	0x525d <generic_tracepoint_filter+0x1a3d>
    5032:      	movq	%rax, %rsi
    5035:      	movl	(%rax), %eax
    5037:      	cmpq	%rax, %r15
    503a:      	je	0x4e26 <generic_tracepoint_filter+0x1606>
    5040:      	movl	0x10(%rsi), %eax
    5043:      	cmpq	%rax, %r15
    5046:      	movq	0x8(%rsp), %r10
    504b:      	movq	0x30(%rsp), %rdi
    5050:      	movq	0x28(%rsp), %r8
    5055:      	movq	0x20(%rsp), %r9
    505a:      	movq	0x18(%rsp), %r11
    505f:      	je	0x4e3f <generic_tracepoint_filter+0x161f>
    5065:      	addq	$0x10, %rsi
    5069:      	movl	$0x1, %eax
    506e:      	movq	(%rip), %rcx            # 0x5075 <generic_tracepoint_filter+0x1855>
    5075:      	jmp	0x5254 <generic_tracepoint_filter+0x1a34>
    507a:      	movl	$0x4, %esi
    507f:      	xorl	%edx, %edx
    5081:      	divq	%rsi
    5084:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5089:      	movl	(%r10,%rax,4), %r15d
    508d:      	testb	$0x2, %dil
    5091:      	jne	0x4e80 <generic_tracepoint_filter+0x1660>
    5097:      	cmpl	$0x5, %r12d
    509b:      	jne	0x50a6 <generic_tracepoint_filter+0x1886>
    509d:      	cmpq	%rcx, %r15
    50a0:      	jne	0x5287 <generic_tracepoint_filter+0x1a67>
    50a6:      	cmpq	%rcx, %r15
    50a9:      	setne	%al
    50ac:      	cmpl	$0x6, %r12d
    50b0:      	setne	%bl
    50b3:      	jmp	0x4e49 <generic_tracepoint_filter+0x1629>
    50b8:      	movq	0xb0(%rsp), %rax
    50c0:      	movl	(%rax), %eax
    50c2:      	testq	%rax, %rax
    50c5:      	je	0x5287 <generic_tracepoint_filter+0x1a67>
    50cb:      	movb	$0x1, %bl
    50cd:      	testq	%r15, %r15
    50d0:      	je	0x4e3f <generic_tracepoint_filter+0x161f>
    50d6:      	cmpq	%rax, %r15
    50d9:      	je	0x4e3f <generic_tracepoint_filter+0x161f>
    50df:      	movl	$0x1, %eax
    50e4:      	movq	0xd0(%rsp), %rsi
    50ec:      	movq	(%rip), %rdi            # 0x50f3 <generic_tracepoint_filter+0x18d3>
    50f3:      	callq	*%rax
    50f5:      	testq	%rax, %rax
    50f8:      	je	0x525d <generic_tracepoint_filter+0x1a3d>
    50fe:      	movq	%rax, %rsi
    5101:      	movl	0x24(%rax), %eax
    5104:      	cmpq	%rax, %r15
    5107:      	je	0x4e26 <generic_tracepoint_filter+0x1606>
    510d:      	addq	$0x10, %rsi
    5111:      	movl	$0x1, %eax
    5116:      	movq	(%rip), %rdi            # 0x511d <generic_tracepoint_filter+0x18fd>
    511d:      	callq	*%rax
    511f:      	testq	%rax, %rax
    5122:      	je	0x525d <generic_tracepoint_filter+0x1a3d>
    5128:      	movq	%rax, %rsi
    512b:      	movl	0x24(%rax), %eax
    512e:      	cmpq	%rax, %r15
    5131:      	je	0x4e26 <generic_tracepoint_filter+0x1606>
    5137:      	addq	$0x10, %rsi
    513b:      	movl	$0x1, %eax
    5140:      	movq	(%rip), %rdi            # 0x5147 <generic_tracepoint_filter+0x1927>
    5147:      	callq	*%rax
    5149:      	testq	%rax, %rax
    514c:      	je	0x525d <generic_tracepoint_filter+0x1a3d>
    5152:      	movq	%rax, %rsi
    5155:      	movl	0x24(%rax), %eax
    5158:      	cmpq	%rax, %r15
    515b:      	je	0x4e26 <generic_tracepoint_filter+0x1606>
    5161:      	addq	$0x10, %rsi
    5165:      	movl	$0x1, %eax
    516a:      	movq	(%rip), %rdi            # 0x5171 <generic_tracepoint_filter+0x1951>
    5171:      	callq	*%rax
    5173:      	testq	%rax, %rax
    5176:      	je	0x525d <generic_tracepoint_filter+0x1a3d>
    517c:      	movq	%rax, %rsi
    517f:      	movl	0x24(%rax), %eax
    5182:      	cmpq	%rax, %r15
    5185:      	je	0x4e26 <generic_tracepoint_filter+0x1606>
    518b:      	addq	$0x10, %rsi
    518f:      	movl	$0x1, %eax
    5194:      	movq	(%rip), %rdi            # 0x519b <generic_tracepoint_filter+0x197b>
    519b:      	callq	*%rax
    519d:      	testq	%rax, %rax
    51a0:      	je	0x525d <generic_tracepoint_filter+0x1a3d>
    51a6:      	movq	%rax, %rsi
    51a9:      	movl	0x24(%rax), %eax
    51ac:      	cmpq	%rax, %r15
    51af:      	je	0x4e26 <generic_tracepoint_filter+0x1606>
    51b5:      	addq	$0x10, %rsi
    51b9:      	movl	$0x1, %eax
    51be:      	movq	(%rip), %rdi            # 0x51c5 <generic_tracepoint_filter+0x19a5>
    51c5:      	callq	*%rax
    51c7:      	testq	%rax, %rax
    51ca:      	je	0x525d <generic_tracepoint_filter+0x1a3d>
    51d0:      	movq	%rax, %rsi
    51d3:      	movl	0x24(%rax), %eax
    51d6:      	cmpq	%rax, %r15
    51d9:      	je	0x4e26 <generic_tracepoint_filter+0x1606>
    51df:      	addq	$0x10, %rsi
    51e3:      	movl	$0x1, %eax
    51e8:      	movq	(%rip), %rdi            # 0x51ef <generic_tracepoint_filter+0x19cf>
    51ef:      	callq	*%rax
    51f1:      	testq	%rax, %rax
    51f4:      	je	0x525d <generic_tracepoint_filter+0x1a3d>
    51f6:      	movq	%rax, %rsi
    51f9:      	movl	0x24(%rax), %eax
    51fc:      	cmpq	%rax, %r15
    51ff:      	je	0x4e26 <generic_tracepoint_filter+0x1606>
    5205:      	addq	$0x10, %rsi
    5209:      	movl	$0x1, %eax
    520e:      	movq	(%rip), %rdi            # 0x5215 <generic_tracepoint_filter+0x19f5>
    5215:      	callq	*%rax
    5217:      	testq	%rax, %rax
    521a:      	je	0x525d <generic_tracepoint_filter+0x1a3d>
    521c:      	movq	%rax, %rsi
    521f:      	movl	0x24(%rax), %eax
    5222:      	cmpq	%rax, %r15
    5225:      	movq	0x8(%rsp), %r10
    522a:      	movq	0x30(%rsp), %rdi
    522f:      	movq	0x28(%rsp), %r8
    5234:      	movq	0x20(%rsp), %r9
    5239:      	movq	0x18(%rsp), %r11
    523e:      	je	0x4e3f <generic_tracepoint_filter+0x161f>
    5244:      	addq	$0x10, %rsi
    5248:      	movl	$0x1, %eax
    524d:      	movq	(%rip), %rcx            # 0x5254 <generic_tracepoint_filter+0x1a34>
    5254:      	movq	(%rip), %rdi            # 0x525b <generic_tracepoint_filter+0x1a3b>
    525b:      	callq	*%rax
    525d:      	xorl	%ebx, %ebx
    525f:      	cmpl	$0x5, %r12d
    5263:      	movq	0x8(%rsp), %r10
    5268:      	movq	0x30(%rsp), %rdi
    526d:      	movq	0x28(%rsp), %r8
    5272:      	movq	0x20(%rsp), %r9
    5277:      	movq	0x18(%rsp), %r11
    527c:      	jne	0x4e3f <generic_tracepoint_filter+0x161f>
    5282:      	jmp	0x4e4b <generic_tracepoint_filter+0x162b>
    5287:      	xorl	%ebx, %ebx
    5289:      	jmp	0x4e4b <generic_tracepoint_filter+0x162b>
    528e:      	movl	$0x1, %eax
    5293:      	jmp	0x52d1 <generic_tracepoint_filter+0x1ab1>
    5295:      	movl	0x60(%rsp), %esi
    5299:      	movl	0x64(%rsp), %ecx
    529d:      	movl	0x68(%rsp), %eax
    52a1:      	movl	0x6c(%rsp), %edx
    52a5:      	cmpl	$0x6, %r12d
    52a9:      	jne	0x52b3 <generic_tracepoint_filter+0x1a93>
    52ab:      	andl	%esi, %ecx
    52ad:      	andl	%edx, %eax
    52af:      	andl	%ecx, %eax
    52b1:      	jmp	0x52b9 <generic_tracepoint_filter+0x1a99>
    52b3:      	orl	%esi, %ecx
    52b5:      	orl	%edx, %eax
    52b7:      	orl	%ecx, %eax
    52b9:      	testl	%eax, %eax
    52bb:      	je	0x5deb <generic_tracepoint_filter+0x25cb>
    52c1:      	addl	$0x14, %r14d
    52c5:      	movl	0x8(%r10,%rbp), %ecx
    52ca:      	andl	$0x7, %ecx
    52cd:      	leal	(%r14,%rcx,4), %ebp
    52d1:      	movq	0x50(%rsp), %r9
    52d6:      	movl	%ebp, %ecx
    52d8:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    52de:      	movl	(%rcx,%r10), %ecx
    52e2:      	addl	$0x4, %ebp
    52e5:      	addl	$-0x4, %ecx
    52e8:      	xorl	%esi, %esi
    52ea:      	movl	$0x4, %r8d
    52f0:      	jmp	0x530f <generic_tracepoint_filter+0x1aef>
    52f2:      	nopw	%cs:(%rax,%rax)
    5300:      	xorl	%ecx, %ecx
    5302:      	incq	%rsi
    5305:      	cmpq	$0xa, %rsi
    5309:      	je	0x5498 <generic_tracepoint_filter+0x1c78>
    530f:      	testl	%ecx, %ecx
    5311:      	je	0x5300 <generic_tracepoint_filter+0x1ae0>
    5313:      	movl	%ebp, %r9d
    5316:      	andl	$0x3ff, %r9d            # imm = 0x3FF
    531d:      	movl	(%r9,%r10), %r11d
    5321:      	movq	%r10, %rax
    5324:      	movl	0x4(%r9,%r10), %r10d
    5329:      	movl	0x8(%r9,%rax), %edx
    532e:      	movq	$0x0, 0x68(%rsp)
    5337:      	movq	$0x0, 0x60(%rsp)
    5340:      	cmpl	$0x4, %edx
    5343:      	movl	$0x4, %eax
    5348:      	cmovbl	%edx, %eax
    534b:      	cmpl	$0x6, %r10d
    534f:      	jne	0x5365 <generic_tracepoint_filter+0x1b45>
    5351:      	movabsq	$0x100000001, %rdi      # imm = 0x100000001
    535b:      	movq	%rdi, 0x60(%rsp)
    5360:      	movq	%rdi, 0x68(%rsp)
    5365:      	addl	$0xc, %ebp
    5368:      	testl	%edx, %edx
    536a:      	je	0x5440 <generic_tracepoint_filter+0x1c20>
    5370:      	andl	$0xf, %r11d
    5374:      	decq	%rax
    5377:      	cmpq	$0x3, %rax
    537b:      	movl	$0x3, %edx
    5380:      	cmovaeq	%rdx, %rax
    5384:      	leaq	0x4(,%rax,4), %rbx
    538c:      	movl	%ebp, %r14d
    538f:      	cmpl	$0x9, %r11d
    5393:      	jbe	0x53ca <generic_tracepoint_filter+0x1baa>
    5395:      	xorl	%r11d, %r11d
    5398:      	jmp	0x53b6 <generic_tracepoint_filter+0x1b96>
    539a:      	nopw	(%rax,%rax)
    53a0:      	movl	$0x0, 0x60(%rsp,%r11)
    53a9:      	addq	$0x4, %r11
    53ad:      	cmpq	%r11, %rbx
    53b0:      	je	0x5440 <generic_tracepoint_filter+0x1c20>
    53b6:      	leaq	(%r14,%r11), %rax
    53ba:      	cmpl	$0x3e8, %eax            # imm = 0x3E8
    53bf:      	ja	0x53a0 <generic_tracepoint_filter+0x1b80>
    53c1:      	movl	%eax, %eax
    53c3:      	xorl	%edx, %edx
    53c5:      	divq	%r8
    53c8:      	jmp	0x53a0 <generic_tracepoint_filter+0x1b80>
    53ca:      	xorl	%r15d, %r15d
    53cd:      	jmp	0x5411 <generic_tracepoint_filter+0x1bf1>
    53cf:      	nop
    53d0:      	cmpl	$0x5, %r10d
    53d4:      	setne	%dl
    53d7:      	movl	%r10d, %r13d
    53da:      	xorl	$0x6, %r13d
    53de:      	movq	0x50(%rsp), %rax
    53e3:      	movl	0x20(%rax,%r11,4), %edi
    53e8:      	movl	%r12d, %eax
    53eb:      	xorl	%edi, %eax
    53ed:      	cmpl	%edi, %r12d
    53f0:      	sete	%dil
    53f4:      	orb	%dl, %dil
    53f7:      	orl	%r13d, %eax
    53fa:      	setne	%al
    53fd:      	andb	%dil, %al
    5400:      	movzbl	%al, %eax
    5403:      	movl	%eax, 0x60(%rsp,%r15)
    5408:      	addq	$0x4, %r15
    540c:      	cmpq	%r15, %rbx
    540f:      	je	0x5440 <generic_tracepoint_filter+0x1c20>
    5411:      	leaq	(%r14,%r15), %rdx
    5415:      	xorl	%r12d, %r12d
    5418:      	cmpl	$0x3e8, %edx            # imm = 0x3E8
    541e:      	ja	0x53d0 <generic_tracepoint_filter+0x1bb0>
    5420:      	movl	%edx, %eax
    5422:      	xorl	%edx, %edx
    5424:      	divq	%r8
    5427:      	andl	$0x3ff, %eax            # imm = 0x3FF
    542c:      	movq	0x8(%rsp), %rdx
    5431:      	movl	(%rdx,%rax,4), %r12d
    5435:      	jmp	0x53d0 <generic_tracepoint_filter+0x1bb0>
    5437:      	nopw	(%rax,%rax)
    5440:      	movl	0x60(%rsp), %ebx
    5444:      	movl	0x64(%rsp), %edx
    5448:      	movl	0x68(%rsp), %eax
    544c:      	movl	0x6c(%rsp), %r11d
    5451:      	cmpl	$0x6, %r10d
    5455:      	jne	0x5460 <generic_tracepoint_filter+0x1c40>
    5457:      	andl	%ebx, %edx
    5459:      	andl	%r11d, %eax
    545c:      	andl	%edx, %eax
    545e:      	jmp	0x5467 <generic_tracepoint_filter+0x1c47>
    5460:      	orl	%ebx, %edx
    5462:      	orl	%r11d, %eax
    5465:      	orl	%edx, %eax
    5467:      	movq	0x8(%rsp), %r10
    546c:      	testl	%eax, %eax
    546e:      	je	0x5deb <generic_tracepoint_filter+0x25cb>
    5474:      	movl	0x8(%r10,%r9), %edx
    5479:      	shll	$0x2, %edx
    547c:      	subl	%edx, %ecx
    547e:      	andl	$0x1c, %edx
    5481:      	addl	%edx, %ebp
    5483:      	addl	$-0xc, %ecx
    5486:      	movq	0x50(%rsp), %r9
    548b:      	incq	%rsi
    548e:      	cmpq	$0xa, %rsi
    5492:      	jne	0x530f <generic_tracepoint_filter+0x1aef>
    5498:      	movl	%ebp, %ecx
    549a:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    54a0:      	leal	0x4(%rbp), %ebx
    54a3:      	cmpl	$0x4, (%rcx,%r10)
    54a8:      	je	0x5678 <generic_tracepoint_filter+0x1e58>
    54ae:      	andl	$0x3ff, %ebx            # imm = 0x3FF
    54b4:      	movl	(%rbx,%r10), %ecx
    54b8:      	movl	0x4(%rbx,%r10), %edx
    54bd:      	movl	0x8(%rbx,%r10), %edi
    54c2:      	movq	0xc(%rbx,%r10), %rax
    54c7:      	testl	%edi, %edi
    54c9:      	je	0x564c <generic_tracepoint_filter+0x1e2c>
    54cf:      	xorl	%esi, %esi
    54d1:      	cmpl	$0x2, %ecx
    54d4:      	ja	0x566f <generic_tracepoint_filter+0x1e4f>
    54da:      	cmpl	%edi, 0x44(%r9)
    54de:      	jne	0x5655 <generic_tracepoint_filter+0x1e35>
    54e4:      	jmp	0x566f <generic_tracepoint_filter+0x1e4f>
    54e9:      	movq	%rbx, %rsi
    54ec:      	addq	$0x4, %rsi
    54f0:      	movq	(%rip), %rdi            # 0x54f7 <generic_tracepoint_filter+0x1cd7>
    54f7:      	movl	$0x1, %eax
    54fc:      	callq	*%rax
    54fe:      	testq	%rax, %rax
    5501:      	je	0x5deb <generic_tracepoint_filter+0x25cb>
    5507:      	movq	%rax, %r14
    550a:      	movq	(%rip), %rdi            # 0x5511 <generic_tracepoint_filter+0x1cf1>
    5511:      	leaq	0x58(%rsp), %rsi
    5516:      	movl	$0x1, %eax
    551b:      	callq	*%rax
    551d:      	testq	%rax, %rax
    5520:      	je	0x5deb <generic_tracepoint_filter+0x25cb>
    5526:      	movq	%rax, %rbp
    5529:      	movl	$0x104, %edx            # imm = 0x104
    552e:      	movq	%rax, %rdi
    5531:      	xorl	%esi, %esi
    5533:      	callq	0x5538 <generic_tracepoint_filter+0x1d18>
    5538:      	movq	0x38(%rsp), %rsi
    553d:      	movl	0x68(%rsi), %eax
    5540:      	leal	(,%rax,8), %ecx
    5547:      	movl	%ecx, (%rbp)
    554a:      	movq	%rbp, %rdi
    554d:      	addq	$0x4, %rdi
    5551:      	movzbl	%al, %ecx
    5554:      	leaq	0x70(%rsi), %rdx
    5558:      	movl	$0x4, %eax
    555d:      	movzbl	0x68(%rsi), %esi
    5561:      	callq	*%rax
    5563:      	testq	%rax, %rax
    5566:      	js	0x5deb <generic_tracepoint_filter+0x25cb>
    556c:      	movl	$0x1, %eax
    5571:      	movq	%r14, %rdi
    5574:      	movq	%rbp, %rsi
    5577:      	jmp	0x5977 <generic_tracepoint_filter+0x2157>
    557c:      	movl	$0x0, 0x40(%rsp)
    5584:      	movq	(%rip), %rdi            # 0x558b <generic_tracepoint_filter+0x1d6b>
    558b:      	leaq	0x40(%rsp), %rsi
    5590:      	movl	$0x1, %eax
    5595:      	callq	*%rax
    5597:      	testq	%rax, %rax
    559a:      	movq	0x38(%rsp), %rdx
    559f:      	je	0x5924 <generic_tracepoint_filter+0x2104>
    55a5:      	movq	(%rax), %rcx
    55a8:      	cmpq	0x378(%rdx), %rcx
    55af:      	je	0x5924 <generic_tracepoint_filter+0x2104>
    55b5:      	movq	%rax, 0xb0(%rsp)
    55bd:      	movq	(%rip), %rax            # 0x55c4 <generic_tracepoint_filter+0x1da4>
    55c4:      	cmpb	$0x0, (%rax)
    55c7:      	je	0x589b <generic_tracepoint_filter+0x207b>
    55cd:      	movl	$0x1869f, %r15d         # imm = 0x1869F
    55d3:      	xorl	%r14d, %r14d
    55d6:      	movq	(%rip), %r12            # 0x55dd <generic_tracepoint_filter+0x1dbd>
    55dd:      	movq	0x38(%rsp), %rax
    55e2:      	movl	0x10(%rax), %eax
    55e5:      	movl	%eax, 0x60(%rsp)
    55e9:      	movl	$0x1, %eax
    55ee:      	leaq	0x60(%rsp), %rsi
    55f3:      	movq	%r12, %rdi
    55f6:      	callq	*%rax
    55f8:      	testq	%rax, %rax
    55fb:      	je	0x590d <generic_tracepoint_filter+0x20ed>
    5601:      	movq	%rax, %rbp
    5604:      	leaq	0x70(%rax), %rsi
    5608:      	movl	$0x1, %eax
    560d:      	movq	(%rip), %rdi            # 0x5614 <generic_tracepoint_filter+0x1df4>
    5614:      	callq	*%rax
    5616:      	testq	%rax, %rax
    5619:      	je	0x5630 <generic_tracepoint_filter+0x1e10>
    561b:      	movq	(%rax), %rax
    561e:      	testq	%rax, %rax
    5621:      	je	0x5630 <generic_tracepoint_filter+0x1e10>
    5623:      	movq	0x38(%rsp), %rcx
    5628:      	lock
    5629:      	orq	%rax, 0x370(%rcx)
    5630:      	subl	$0x1, %r15d
    5634:      	setb	%al
    5637:      	cmpq	%r14, %rbp
    563a:      	je	0x590d <generic_tracepoint_filter+0x20ed>
    5640:      	movq	%rbp, %r14
    5643:      	testb	%al, %al
    5645:      	je	0x55dd <generic_tracepoint_filter+0x1dbd>
    5647:      	jmp	0x590d <generic_tracepoint_filter+0x20ed>
    564c:      	cmpl	$0x2, %ecx
    564f:      	jbe	0x5655 <generic_tracepoint_filter+0x1e35>
    5651:      	xorl	%esi, %esi
    5653:      	jmp	0x566f <generic_tracepoint_filter+0x1e4f>
    5655:      	andq	0x48(%r9,%rcx,8), %rax
    565a:      	cmpl	$0x5, %edx
    565d:      	jne	0x5668 <generic_tracepoint_filter+0x1e48>
    565f:      	testq	%rax, %rax
    5662:      	setne	%sil
    5666:      	jmp	0x566f <generic_tracepoint_filter+0x1e4f>
    5668:      	testq	%rax, %rax
    566b:      	sete	%sil
    566f:      	addl	$0x18, %ebp
    5672:      	movzbl	%sil, %eax
    5676:      	movl	%ebp, %ebx
    5678:      	testl	%eax, %eax
    567a:      	je	0x5deb <generic_tracepoint_filter+0x25cb>
    5680:      	movl	%ebx, %ecx
    5682:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5688:      	leal	0x4(%rbx), %eax
    568b:      	cmpl	$0x4, (%rcx,%r10)
    5690:      	je	0x5cf3 <generic_tracepoint_filter+0x24d3>
    5696:      	andl	$0x3ff, %eax            # imm = 0x3FF
    569b:      	movl	(%rax,%r10), %r14d
    569f:      	movl	0x4(%rax,%r10), %ebp
    56a4:      	movl	$0xe, %eax
    56a9:      	callq	*%rax
    56ab:      	shrq	$0x20, %rax
    56af:      	movl	%eax, 0x60(%rsp)
    56b3:      	movq	(%rip), %rdi            # 0x56ba <generic_tracepoint_filter+0x1e9a>
    56ba:      	leaq	0x60(%rsp), %rsi
    56bf:      	movl	$0x1, %eax
    56c4:      	callq	*%rax
    56c6:      	movq	0x8(%rsp), %r10
    56cb:      	testq	%rax, %rax
    56ce:      	je	0x5deb <generic_tracepoint_filter+0x25cb>
    56d4:      	cmpl	$0x5, %r14d
    56d8:      	je	0x5716 <generic_tracepoint_filter+0x1ef6>
    56da:      	cmpl	$0x6, %r14d
    56de:      	jne	0x5deb <generic_tracepoint_filter+0x25cb>
    56e4:      	movq	0x50(%rsp), %rsi
    56e9:      	movq	%rsi, %rcx
    56ec:      	addq	$0x5ee8, %rcx           # imm = 0x5EE8
    56f3:      	testb	$0x1, %bpl
    56f7:      	jne	0x59b9 <generic_tracepoint_filter+0x2199>
    56fd:      	movl	0x28(%rax), %edx
    5700:      	testl	%edx, %edx
    5702:      	je	0x59b2 <generic_tracepoint_filter+0x2192>
    5708:      	cmpl	0x20(%rsi), %edx
    570b:      	je	0x59b9 <generic_tracepoint_filter+0x2199>
    5711:      	jmp	0x5ce7 <generic_tracepoint_filter+0x24c7>
    5716:      	movq	0x50(%rsp), %rsi
    571b:      	movq	%rsi, %rcx
    571e:      	addq	$0x5ee8, %rcx           # imm = 0x5EE8
    5725:      	testb	$0x1, %bpl
    5729:      	je	0x59d7 <generic_tracepoint_filter+0x21b7>
    572f:      	movl	0x28(%rax), %edx
    5732:      	testl	%edx, %edx
    5734:      	je	0x59d0 <generic_tracepoint_filter+0x21b0>
    573a:      	cmpl	0x20(%rsi), %edx
    573d:      	je	0x59d7 <generic_tracepoint_filter+0x21b7>
    5743:      	jmp	0x5ce7 <generic_tracepoint_filter+0x24c7>
    5748:      	movq	%r12, %rsi
    574b:      	addq	$0x4, %rsi
    574f:      	movq	(%rip), %rdi            # 0x5756 <generic_tracepoint_filter+0x1f36>
    5756:      	movl	$0x1, %eax
    575b:      	callq	*%rax
    575d:      	testq	%rax, %rax
    5760:      	je	0x5deb <generic_tracepoint_filter+0x25cb>
    5766:      	movq	%rax, %r14
    5769:      	movq	(%rip), %rdi            # 0x5770 <generic_tracepoint_filter+0x1f50>
    5770:      	leaq	0x58(%rsp), %rsi
    5775:      	movl	$0x1, %eax
    577a:      	callq	*%rax
    577c:      	testq	%rax, %rax
    577f:      	je	0x5deb <generic_tracepoint_filter+0x25cb>
    5785:      	movq	%rax, %rbx
    5788:      	movl	$0x104, %edx            # imm = 0x104
    578d:      	movq	%rax, %rdi
    5790:      	xorl	%esi, %esi
    5792:      	callq	0x5797 <generic_tracepoint_filter+0x1f77>
    5797:      	movl	(%rbp), %eax
    579a:      	leal	(,%rax,8), %ecx
    57a1:      	movl	%ecx, (%rbx)
    57a3:      	movq	%rbx, %rdi
    57a6:      	addq	$0x4, %rdi
    57aa:      	movzbl	%al, %ecx
    57ad:      	movq	%rbp, %rdx
    57b0:      	addq	$0x8, %rdx
    57b4:      	movl	$0x4, %eax
    57b9:      	movzbl	(%rbp), %esi
    57bd:      	callq	*%rax
    57bf:      	testq	%rax, %rax
    57c2:      	js	0x5deb <generic_tracepoint_filter+0x25cb>
    57c8:      	movl	$0x1, %eax
    57cd:      	movq	%r14, %rdi
    57d0:      	movq	%rbx, %rsi
    57d3:      	jmp	0x5b4d <generic_tracepoint_filter+0x232d>
    57d8:      	movl	$0x0, 0x40(%rsp)
    57e0:      	movq	(%rip), %rdi            # 0x57e7 <generic_tracepoint_filter+0x1fc7>
    57e7:      	leaq	0x40(%rsp), %rsi
    57ec:      	movl	$0x1, %eax
    57f1:      	callq	*%rax
    57f3:      	testq	%rax, %rax
    57f6:      	je	0x5afa <generic_tracepoint_filter+0x22da>
    57fc:      	movq	(%rax), %rcx
    57ff:      	cmpq	0x310(%rbp), %rcx
    5806:      	je	0x5afa <generic_tracepoint_filter+0x22da>
    580c:      	movq	%rax, 0xb0(%rsp)
    5814:      	movq	(%rip), %rax            # 0x581b <generic_tracepoint_filter+0x1ffb>
    581b:      	cmpb	$0x0, (%rax)
    581e:      	je	0x5a7e <generic_tracepoint_filter+0x225e>
    5824:      	movl	$0x1869f, %r15d         # imm = 0x1869F
    582a:      	xorl	%r14d, %r14d
    582d:      	movq	0x38(%rsp), %rax
    5832:      	movl	0x10(%rax), %eax
    5835:      	movl	%eax, 0x60(%rsp)
    5839:      	movl	$0x1, %eax
    583e:      	movq	(%rip), %rdi            # 0x5845 <generic_tracepoint_filter+0x2025>
    5845:      	leaq	0x60(%rsp), %rsi
    584a:      	callq	*%rax
    584c:      	testq	%rax, %rax
    584f:      	je	0x5ae8 <generic_tracepoint_filter+0x22c8>
    5855:      	movq	%rax, %rbx
    5858:      	leaq	0x70(%rax), %rsi
    585c:      	movl	$0x1, %eax
    5861:      	movq	(%rip), %rdi            # 0x5868 <generic_tracepoint_filter+0x2048>
    5868:      	callq	*%rax
    586a:      	testq	%rax, %rax
    586d:      	je	0x587f <generic_tracepoint_filter+0x205f>
    586f:      	movq	(%rax), %rax
    5872:      	testq	%rax, %rax
    5875:      	je	0x587f <generic_tracepoint_filter+0x205f>
    5877:      	lock
    5878:      	orq	%rax, 0x308(%rbp)
    587f:      	subl	$0x1, %r15d
    5883:      	setb	%al
    5886:      	cmpq	%r14, %rbx
    5889:      	je	0x5ae8 <generic_tracepoint_filter+0x22c8>
    588f:      	movq	%rbx, %r14
    5892:      	testb	%al, %al
    5894:      	je	0x582d <generic_tracepoint_filter+0x200d>
    5896:      	jmp	0x5ae8 <generic_tracepoint_filter+0x22c8>
    589b:      	movl	$0x3ff, %r15d           # imm = 0x3FF
    58a1:      	xorl	%r14d, %r14d
    58a4:      	movq	(%rip), %r12            # 0x58ab <generic_tracepoint_filter+0x208b>
    58ab:      	movq	0x38(%rsp), %rax
    58b0:      	movl	0x10(%rax), %eax
    58b3:      	movl	%eax, 0x60(%rsp)
    58b7:      	movl	$0x1, %eax
    58bc:      	leaq	0x60(%rsp), %rsi
    58c1:      	movq	%r12, %rdi
    58c4:      	callq	*%rax
    58c6:      	testq	%rax, %rax
    58c9:      	je	0x590d <generic_tracepoint_filter+0x20ed>
    58cb:      	movq	%rax, %rbp
    58ce:      	leaq	0x70(%rax), %rsi
    58d2:      	movl	$0x1, %eax
    58d7:      	movq	(%rip), %rdi            # 0x58de <generic_tracepoint_filter+0x20be>
    58de:      	callq	*%rax
    58e0:      	testq	%rax, %rax
    58e3:      	je	0x58fa <generic_tracepoint_filter+0x20da>
    58e5:      	movq	(%rax), %rax
    58e8:      	testq	%rax, %rax
    58eb:      	je	0x58fa <generic_tracepoint_filter+0x20da>
    58ed:      	movq	0x38(%rsp), %rcx
    58f2:      	lock
    58f3:      	orq	%rax, 0x370(%rcx)
    58fa:      	subl	$0x1, %r15d
    58fe:      	setb	%al
    5901:      	cmpq	%r14, %rbp
    5904:      	je	0x590d <generic_tracepoint_filter+0x20ed>
    5906:      	movq	%rbp, %r14
    5909:      	testb	%al, %al
    590b:      	je	0x58ab <generic_tracepoint_filter+0x208b>
    590d:      	movq	0xb0(%rsp), %rax
    5915:      	movq	(%rax), %rax
    5918:      	movq	0x38(%rsp), %rdx
    591d:      	movq	%rax, 0x378(%rdx)
    5924:      	movl	0x8(%rbx), %eax
    5927:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    592c:      	cmpq	%rcx, %rax
    592f:      	je	0x594a <generic_tracepoint_filter+0x212a>
    5931:      	movq	0x370(%rdx), %rcx
    5938:      	btq	%rax, %rcx
    593c:      	jae	0x594a <generic_tracepoint_filter+0x212a>
    593e:      	movabsq	$0xbadc0ffee, %rax      # imm = 0xBADC0FFEE
    5948:      	jmp	0x5979 <generic_tracepoint_filter+0x2159>
    594a:      	movq	(%rip), %rdi            # 0x5951 <generic_tracepoint_filter+0x2131>
    5951:      	leaq	0x10(%rsp), %rsi
    5956:      	movl	$0x1, %eax
    595b:      	callq	*%rax
    595d:      	testq	%rax, %rax
    5960:      	je	0x5deb <generic_tracepoint_filter+0x25cb>
    5966:      	movq	%rax, %rdi
    5969:      	movq	0x38(%rsp), %rax
    596e:      	leaq	0x70(%rax), %rsi
    5972:      	movl	$0x1, %eax
    5977:      	callq	*%rax
    5979:      	movl	(%rbx), %ecx
    597b:      	cmpq	$0x25, %rcx
    597f:      	movq	0x8(%rsp), %r10
    5984:      	ja	0x59a4 <generic_tracepoint_filter+0x2184>
    5986:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    5990:      	btq	%rcx, %rdx
    5994:      	jae	0x59a4 <generic_tracepoint_filter+0x2184>
    5996:      	testq	%rax, %rax
    5999:      	jne	0x5deb <generic_tracepoint_filter+0x25cb>
    599f:      	jmp	0x4ae9 <generic_tracepoint_filter+0x12c9>
    59a4:      	testq	%rax, %rax
    59a7:      	jne	0x4ae9 <generic_tracepoint_filter+0x12c9>
    59ad:      	jmp	0x5deb <generic_tracepoint_filter+0x25cb>
    59b2:      	movq	$0x1, (%rcx)
    59b9:      	testb	$0x2, %bpl
    59bd:      	jne	0x59f5 <generic_tracepoint_filter+0x21d5>
    59bf:      	movl	0x2c(%rax), %edx
    59c2:      	testl	%edx, %edx
    59c4:      	je	0x59ee <generic_tracepoint_filter+0x21ce>
    59c6:      	cmpl	0x24(%rsi), %edx
    59c9:      	je	0x59f5 <generic_tracepoint_filter+0x21d5>
    59cb:      	jmp	0x5ce7 <generic_tracepoint_filter+0x24c7>
    59d0:      	movq	$0x1, (%rcx)
    59d7:      	testb	$0x2, %bpl
    59db:      	je	0x5a13 <generic_tracepoint_filter+0x21f3>
    59dd:      	movl	0x2c(%rax), %edx
    59e0:      	testl	%edx, %edx
    59e2:      	je	0x5a0c <generic_tracepoint_filter+0x21ec>
    59e4:      	cmpl	0x24(%rsi), %edx
    59e7:      	je	0x5a13 <generic_tracepoint_filter+0x21f3>
    59e9:      	jmp	0x5ce7 <generic_tracepoint_filter+0x24c7>
    59ee:      	movq	$0x1, (%rcx)
    59f5:      	testb	$0x4, %bpl
    59f9:      	jne	0x5a31 <generic_tracepoint_filter+0x2211>
    59fb:      	movl	0x30(%rax), %edx
    59fe:      	testl	%edx, %edx
    5a00:      	je	0x5a2a <generic_tracepoint_filter+0x220a>
    5a02:      	cmpl	0x28(%rsi), %edx
    5a05:      	je	0x5a31 <generic_tracepoint_filter+0x2211>
    5a07:      	jmp	0x5ce7 <generic_tracepoint_filter+0x24c7>
    5a0c:      	movq	$0x1, (%rcx)
    5a13:      	testb	$0x4, %bpl
    5a17:      	je	0x5a5b <generic_tracepoint_filter+0x223b>
    5a19:      	movl	0x30(%rax), %edx
    5a1c:      	testl	%edx, %edx
    5a1e:      	je	0x5a54 <generic_tracepoint_filter+0x2234>
    5a20:      	cmpl	0x28(%rsi), %edx
    5a23:      	je	0x5a5b <generic_tracepoint_filter+0x223b>
    5a25:      	jmp	0x5ce7 <generic_tracepoint_filter+0x24c7>
    5a2a:      	movq	$0x1, (%rcx)
    5a31:      	testb	$0x8, %bpl
    5a35:      	jne	0x5b91 <generic_tracepoint_filter+0x2371>
    5a3b:      	movl	0x34(%rax), %edx
    5a3e:      	testl	%edx, %edx
    5a40:      	je	0x5b8a <generic_tracepoint_filter+0x236a>
    5a46:      	cmpl	0x2c(%rsi), %edx
    5a49:      	je	0x5b91 <generic_tracepoint_filter+0x2371>
    5a4f:      	jmp	0x5ce7 <generic_tracepoint_filter+0x24c7>
    5a54:      	movq	$0x1, (%rcx)
    5a5b:      	testb	$0x8, %bpl
    5a5f:      	je	0x5baf <generic_tracepoint_filter+0x238f>
    5a65:      	movl	0x34(%rax), %edx
    5a68:      	testl	%edx, %edx
    5a6a:      	je	0x5ba8 <generic_tracepoint_filter+0x2388>
    5a70:      	cmpl	0x2c(%rsi), %edx
    5a73:      	je	0x5baf <generic_tracepoint_filter+0x238f>
    5a79:      	jmp	0x5ce7 <generic_tracepoint_filter+0x24c7>
    5a7e:      	movl	$0x3ff, %r15d           # imm = 0x3FF
    5a84:      	xorl	%r14d, %r14d
    5a87:      	movq	0x38(%rsp), %rax
    5a8c:      	movl	0x10(%rax), %eax
    5a8f:      	movl	%eax, 0x60(%rsp)
    5a93:      	movl	$0x1, %eax
    5a98:      	movq	(%rip), %rdi            # 0x5a9f <generic_tracepoint_filter+0x227f>
    5a9f:      	leaq	0x60(%rsp), %rsi
    5aa4:      	callq	*%rax
    5aa6:      	testq	%rax, %rax
    5aa9:      	je	0x5ae8 <generic_tracepoint_filter+0x22c8>
    5aab:      	movq	%rax, %rbx
    5aae:      	leaq	0x70(%rax), %rsi
    5ab2:      	movl	$0x1, %eax
    5ab7:      	movq	(%rip), %rdi            # 0x5abe <generic_tracepoint_filter+0x229e>
    5abe:      	callq	*%rax
    5ac0:      	testq	%rax, %rax
    5ac3:      	je	0x5ad5 <generic_tracepoint_filter+0x22b5>
    5ac5:      	movq	(%rax), %rax
    5ac8:      	testq	%rax, %rax
    5acb:      	je	0x5ad5 <generic_tracepoint_filter+0x22b5>
    5acd:      	lock
    5ace:      	orq	%rax, 0x308(%rbp)
    5ad5:      	subl	$0x1, %r15d
    5ad9:      	setb	%al
    5adc:      	cmpq	%r14, %rbx
    5adf:      	je	0x5ae8 <generic_tracepoint_filter+0x22c8>
    5ae1:      	movq	%rbx, %r14
    5ae4:      	testb	%al, %al
    5ae6:      	je	0x5a87 <generic_tracepoint_filter+0x2267>
    5ae8:      	movq	0xb0(%rsp), %rax
    5af0:      	movq	(%rax), %rax
    5af3:      	movq	%rax, 0x310(%rbp)
    5afa:      	movl	0x8(%r12), %eax
    5aff:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    5b04:      	cmpq	%rcx, %rax
    5b07:      	je	0x5b22 <generic_tracepoint_filter+0x2302>
    5b09:      	movq	0x308(%rbp), %rcx
    5b10:      	btq	%rax, %rcx
    5b14:      	jae	0x5b22 <generic_tracepoint_filter+0x2302>
    5b16:      	movabsq	$0xbadc0ffee, %rax      # imm = 0xBADC0FFEE
    5b20:      	jmp	0x5b4f <generic_tracepoint_filter+0x232f>
    5b22:      	movq	(%rip), %rdi            # 0x5b29 <generic_tracepoint_filter+0x2309>
    5b29:      	leaq	0x10(%rsp), %rsi
    5b2e:      	movl	$0x1, %eax
    5b33:      	callq	*%rax
    5b35:      	testq	%rax, %rax
    5b38:      	je	0x5deb <generic_tracepoint_filter+0x25cb>
    5b3e:      	movq	%rax, %rdi
    5b41:      	addq	$0x8, %rbp
    5b45:      	movl	$0x1, %eax
    5b4a:      	movq	%rbp, %rsi
    5b4d:      	callq	*%rax
    5b4f:      	movl	(%r12), %ecx
    5b53:      	cmpq	$0x25, %rcx
    5b57:      	movq	0x8(%rsp), %r10
    5b5c:      	ja	0x5b7c <generic_tracepoint_filter+0x235c>
    5b5e:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    5b68:      	btq	%rcx, %rdx
    5b6c:      	jae	0x5b7c <generic_tracepoint_filter+0x235c>
    5b6e:      	testq	%rax, %rax
    5b71:      	jne	0x5deb <generic_tracepoint_filter+0x25cb>
    5b77:      	jmp	0x4d35 <generic_tracepoint_filter+0x1515>
    5b7c:      	testq	%rax, %rax
    5b7f:      	jne	0x4d35 <generic_tracepoint_filter+0x1515>
    5b85:      	jmp	0x5deb <generic_tracepoint_filter+0x25cb>
    5b8a:      	movq	$0x1, (%rcx)
    5b91:      	testb	$0x10, %bpl
    5b95:      	jne	0x5bcd <generic_tracepoint_filter+0x23ad>
    5b97:      	movl	0x38(%rax), %edx
    5b9a:      	testl	%edx, %edx
    5b9c:      	je	0x5bc6 <generic_tracepoint_filter+0x23a6>
    5b9e:      	cmpl	0x30(%rsi), %edx
    5ba1:      	je	0x5bcd <generic_tracepoint_filter+0x23ad>
    5ba3:      	jmp	0x5ce7 <generic_tracepoint_filter+0x24c7>
    5ba8:      	movq	$0x1, (%rcx)
    5baf:      	testb	$0x10, %bpl
    5bb3:      	je	0x5beb <generic_tracepoint_filter+0x23cb>
    5bb5:      	movl	0x38(%rax), %edx
    5bb8:      	testl	%edx, %edx
    5bba:      	je	0x5be4 <generic_tracepoint_filter+0x23c4>
    5bbc:      	cmpl	0x30(%rsi), %edx
    5bbf:      	je	0x5beb <generic_tracepoint_filter+0x23cb>
    5bc1:      	jmp	0x5ce7 <generic_tracepoint_filter+0x24c7>
    5bc6:      	movq	$0x1, (%rcx)
    5bcd:      	testb	$0x20, %bpl
    5bd1:      	jne	0x5c09 <generic_tracepoint_filter+0x23e9>
    5bd3:      	movl	0x3c(%rax), %edx
    5bd6:      	testl	%edx, %edx
    5bd8:      	je	0x5c02 <generic_tracepoint_filter+0x23e2>
    5bda:      	cmpl	0x34(%rsi), %edx
    5bdd:      	je	0x5c09 <generic_tracepoint_filter+0x23e9>
    5bdf:      	jmp	0x5ce7 <generic_tracepoint_filter+0x24c7>
    5be4:      	movq	$0x1, (%rcx)
    5beb:      	testb	$0x20, %bpl
    5bef:      	je	0x5c27 <generic_tracepoint_filter+0x2407>
    5bf1:      	movl	0x3c(%rax), %edx
    5bf4:      	testl	%edx, %edx
    5bf6:      	je	0x5c20 <generic_tracepoint_filter+0x2400>
    5bf8:      	cmpl	0x34(%rsi), %edx
    5bfb:      	je	0x5c27 <generic_tracepoint_filter+0x2407>
    5bfd:      	jmp	0x5ce7 <generic_tracepoint_filter+0x24c7>
    5c02:      	movq	$0x1, (%rcx)
    5c09:      	testb	$0x40, %bpl
    5c0d:      	jne	0x5c45 <generic_tracepoint_filter+0x2425>
    5c0f:      	movl	0x40(%rax), %edx
    5c12:      	testl	%edx, %edx
    5c14:      	je	0x5c3e <generic_tracepoint_filter+0x241e>
    5c16:      	cmpl	0x38(%rsi), %edx
    5c19:      	je	0x5c45 <generic_tracepoint_filter+0x2425>
    5c1b:      	jmp	0x5ce7 <generic_tracepoint_filter+0x24c7>
    5c20:      	movq	$0x1, (%rcx)
    5c27:      	testb	$0x40, %bpl
    5c2b:      	je	0x5c62 <generic_tracepoint_filter+0x2442>
    5c2d:      	movl	0x40(%rax), %edx
    5c30:      	testl	%edx, %edx
    5c32:      	je	0x5c5b <generic_tracepoint_filter+0x243b>
    5c34:      	cmpl	0x38(%rsi), %edx
    5c37:      	je	0x5c62 <generic_tracepoint_filter+0x2442>
    5c39:      	jmp	0x5ce7 <generic_tracepoint_filter+0x24c7>
    5c3e:      	movq	$0x1, (%rcx)
    5c45:      	testb	%bpl, %bpl
    5c48:      	js	0x5c7c <generic_tracepoint_filter+0x245c>
    5c4a:      	movl	0x44(%rax), %edx
    5c4d:      	testl	%edx, %edx
    5c4f:      	je	0x5c75 <generic_tracepoint_filter+0x2455>
    5c51:      	cmpl	0x3c(%rsi), %edx
    5c54:      	je	0x5c7c <generic_tracepoint_filter+0x245c>
    5c56:      	jmp	0x5ce7 <generic_tracepoint_filter+0x24c7>
    5c5b:      	movq	$0x1, (%rcx)
    5c62:      	testb	%bpl, %bpl
    5c65:      	jns	0x5c99 <generic_tracepoint_filter+0x2479>
    5c67:      	movl	0x44(%rax), %edx
    5c6a:      	testl	%edx, %edx
    5c6c:      	je	0x5c92 <generic_tracepoint_filter+0x2472>
    5c6e:      	cmpl	0x3c(%rsi), %edx
    5c71:      	je	0x5c99 <generic_tracepoint_filter+0x2479>
    5c73:      	jmp	0x5ce7 <generic_tracepoint_filter+0x24c7>
    5c75:      	movq	$0x1, (%rcx)
    5c7c:      	testl	$0x100, %ebp            # imm = 0x100
    5c82:      	jne	0x5cc2 <generic_tracepoint_filter+0x24a2>
    5c84:      	movl	0x48(%rax), %edx
    5c87:      	testl	%edx, %edx
    5c89:      	je	0x5cbb <generic_tracepoint_filter+0x249b>
    5c8b:      	cmpl	0x40(%rsi), %edx
    5c8e:      	je	0x5cc2 <generic_tracepoint_filter+0x24a2>
    5c90:      	jmp	0x5ce7 <generic_tracepoint_filter+0x24c7>
    5c92:      	movq	$0x1, (%rcx)
    5c99:      	testl	$0x100, %ebp            # imm = 0x100
    5c9f:      	je	0x5dd1 <generic_tracepoint_filter+0x25b1>
    5ca5:      	movl	0x48(%rax), %edx
    5ca8:      	testl	%edx, %edx
    5caa:      	je	0x5dca <generic_tracepoint_filter+0x25aa>
    5cb0:      	cmpl	0x40(%rsi), %edx
    5cb3:      	je	0x5dd1 <generic_tracepoint_filter+0x25b1>
    5cb9:      	jmp	0x5ce7 <generic_tracepoint_filter+0x24c7>
    5cbb:      	movq	$0x1, (%rcx)
    5cc2:      	testl	$0x200, %ebp            # imm = 0x200
    5cc8:      	jne	0x5deb <generic_tracepoint_filter+0x25cb>
    5cce:      	movl	0x4c(%rax), %eax
    5cd1:      	testl	%eax, %eax
    5cd3:      	je	0x5de4 <generic_tracepoint_filter+0x25c4>
    5cd9:      	movq	0x50(%rsp), %rdx
    5cde:      	cmpl	0x44(%rdx), %eax
    5ce1:      	je	0x5deb <generic_tracepoint_filter+0x25cb>
    5ce7:      	addl	$0xc, %ebx
    5cea:      	movq	$0x1, (%rcx)
    5cf1:      	movl	%ebx, %eax
    5cf3:      	movl	%eax, %ecx
    5cf5:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5cfb:      	cmpl	$0x4, (%rcx,%r10)
    5d00:      	movq	0x50(%rsp), %rcx
    5d05:      	jne	0x5d2c <generic_tracepoint_filter+0x250c>
    5d07:      	movq	0x5eb8(%rcx), %rax
    5d0e:      	andl	$0x1f, %eax
    5d11:      	movb	$0x1, 0x5ec1(%rcx,%rax)
    5d19:      	movb	$0x1, 0x5ee0(%rcx)
    5d20:      	movb	$0x1, 0x5ec0(%rcx)
    5d27:      	jmp	0x5deb <generic_tracepoint_filter+0x25cb>
    5d2c:      	addl	$0x4, %eax
    5d2f:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5d34:      	movl	(%rax,%r10), %r14d
    5d38:      	movl	0x4(%rax,%r10), %ebx
    5d3d:      	movl	0x8(%rax,%r10), %ebp
    5d42:      	movq	0xc(%rax,%r10), %r15
    5d47:      	movl	$0xe, %eax
    5d4c:      	callq	*%rax
    5d4e:      	shrq	$0x20, %rax
    5d52:      	movl	%eax, 0x60(%rsp)
    5d56:      	movq	(%rip), %rdi            # 0x5d5d <generic_tracepoint_filter+0x253d>
    5d5d:      	leaq	0x60(%rsp), %rsi
    5d62:      	movl	$0x1, %eax
    5d67:      	callq	*%rax
    5d69:      	testq	%rax, %rax
    5d6c:      	je	0x5deb <generic_tracepoint_filter+0x25cb>
    5d6e:      	testl	%ebp, %ebp
    5d70:      	je	0x5d84 <generic_tracepoint_filter+0x2564>
    5d72:      	cmpl	$0x2, %r14d
    5d76:      	ja	0x5deb <generic_tracepoint_filter+0x25cb>
    5d78:      	movq	0x50(%rsp), %rcx
    5d7d:      	cmpl	%ebp, 0x44(%rcx)
    5d80:      	jne	0x5d8a <generic_tracepoint_filter+0x256a>
    5d82:      	jmp	0x5deb <generic_tracepoint_filter+0x25cb>
    5d84:      	cmpl	$0x2, %r14d
    5d88:      	ja	0x5deb <generic_tracepoint_filter+0x25cb>
    5d8a:      	movq	0x50(%rax,%r14,8), %rax
    5d8f:      	movq	0x50(%rsp), %rcx
    5d94:      	movq	0x48(%rcx,%r14,8), %rcx
    5d99:      	movq	%rcx, %rdx
    5d9c:      	xorq	%rax, %rdx
    5d9f:      	testq	%r15, %rdx
    5da2:      	je	0x5dab <generic_tracepoint_filter+0x258b>
    5da4:      	cmpl	$0x5, %ebx
    5da7:      	jne	0x5deb <generic_tracepoint_filter+0x25cb>
    5da9:      	jmp	0x5db5 <generic_tracepoint_filter+0x2595>
    5dab:      	cmpq	%rcx, %rax
    5dae:      	je	0x5deb <generic_tracepoint_filter+0x25cb>
    5db0:      	cmpl	$0x6, %ebx
    5db3:      	jne	0x5deb <generic_tracepoint_filter+0x25cb>
    5db5:      	movq	0x50(%rsp), %rcx
    5dba:      	movq	$0x1, 0x5ef0(%rcx)
    5dc5:      	jmp	0x5d07 <generic_tracepoint_filter+0x24e7>
    5dca:      	movq	$0x1, (%rcx)
    5dd1:      	testl	$0x200, %ebp            # imm = 0x200
    5dd7:      	je	0x5deb <generic_tracepoint_filter+0x25cb>
    5dd9:      	movl	0x4c(%rax), %eax
    5ddc:      	testl	%eax, %eax
    5dde:      	jne	0x5cd9 <generic_tracepoint_filter+0x24b9>
    5de4:      	movq	$0x1, (%rcx)
    5deb:      	movq	0x50(%rsp), %rcx
    5df0:      	movq	0x5eb8(%rcx), %rax
    5df7:      	incq	%rax
    5dfa:      	movq	%rax, 0x5eb8(%rcx)
    5e01:      	cmpq	0xc0(%rsp), %rax
    5e09:      	jbe	0x5e5d <generic_tracepoint_filter+0x263d>
    5e0b:      	movq	0x38(%rsp), %rdx
    5e10:      	movl	(%rdx), %eax
    5e12:      	movl	%eax, 0x10(%rcx)
    5e15:      	movq	0x8(%rdx), %rax
    5e19:      	movq	%rax, 0x18(%rcx)
    5e1d:      	cmpb	$0x0, 0x5ec0(%rcx)
    5e24:      	movq	0xb8(%rsp), %rbx
    5e2c:      	je	0x5e49 <generic_tracepoint_filter+0x2629>
    5e2e:      	movq	(%rip), %rsi            # 0x5e35 <generic_tracepoint_filter+0x2615>
    5e35:      	movl	$0x1, %ecx
    5e3a:      	movl	$0xc, %eax
    5e3f:      	movq	%rbx, %rdi
    5e42:      	movl	$0x1, %edx
    5e47:      	callq	*%rax
    5e49:      	xorl	%eax, %eax
    5e4b:      	addq	$0xe8, %rsp
    5e52:      	popq	%rbx
    5e53:      	popq	%r12
    5e55:      	popq	%r13
    5e57:      	popq	%r14
    5e59:      	popq	%r15
    5e5b:      	popq	%rbp
    5e5c:      	retq
    5e5d:      	movq	(%rip), %rsi            # 0x5e64 <generic_tracepoint_filter+0x2644>
    5e64:      	movl	$0x2, %ecx
    5e69:      	movl	$0xc, %eax
    5e6e:      	movq	0xb8(%rsp), %rdi
    5e76:      	movl	$0x2, %edx
    5e7b:      	jmp	0x5e47 <generic_tracepoint_filter+0x2627>
    5e7d:      	nopl	(%rax)

0000000000005e80 <generic_tracepoint_arg>:
    5e80:      	pushq	%rbp
    5e81:      	pushq	%r15
    5e83:      	pushq	%r14
    5e85:      	pushq	%r13
    5e87:      	pushq	%r12
    5e89:      	pushq	%rbx
    5e8a:      	subq	$0xb8, %rsp
    5e91:      	movq	%rdi, %r12
    5e94:      	movl	$0x0, 0xa4(%rsp)
    5e9f:      	movq	(%rip), %rdi            # 0x5ea6 <generic_tracepoint_arg+0x26>
    5ea6:      	leaq	0xa4(%rsp), %rsi
    5eae:      	movl	$0x1, %eax
    5eb3:      	callq	*%rax
    5eb5:      	testq	%rax, %rax
    5eb8:      	je	0x6072 <generic_tracepoint_arg+0x1f2>
    5ebe:      	movq	%rax, %r14
    5ec1:      	movl	0x5f00(%rax), %ebx
    5ec7:      	leaq	0x5ef8(%rax), %rsi
    5ece:      	movq	(%rip), %rdi            # 0x5ed5 <generic_tracepoint_arg+0x55>
    5ed5:      	movl	$0x1, %eax
    5eda:      	callq	*%rax
    5edc:      	testq	%rax, %rax
    5edf:      	je	0x6057 <generic_tracepoint_arg+0x1d7>
    5ee5:      	cmpb	$0x0, 0x5ee0(%r14)
    5eed:      	je	0x6057 <generic_tracepoint_arg+0x1d7>
    5ef3:      	movq	%rax, %r15
    5ef6:      	movq	%r12, 0x98(%rsp)
    5efe:      	movl	%ebx, %eax
    5f00:      	andl	$0x7, %eax
    5f03:      	cmpb	$0x0, 0x5ec1(%r14,%rax)
    5f0c:      	je	0x5f9d <generic_tracepoint_arg+0x11d>
    5f12:      	movl	%eax, %eax
    5f14:      	movl	0x4(%r15,%rax,4), %ecx
    5f19:      	leaq	(%rcx,%rax,4), %rdx
    5f1d:      	addq	$0x4, %rdx
    5f21:      	leaq	(%rcx,%rax,4), %rax
    5f25:      	addq	$0x8, %rax
    5f29:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5f2e:      	movl	(%rax,%r15), %eax
    5f32:      	addq	%rdx, %rax
    5f35:      	addq	$0x4, %rax
    5f39:      	movl	%eax, %ecx
    5f3b:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5f41:      	movl	(%rcx,%r15), %ecx
    5f45:      	addq	%rax, %rcx
    5f48:      	movl	%ecx, %eax
    5f4a:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5f4f:      	movl	(%rax,%r15), %eax
    5f53:      	addq	%rcx, %rax
    5f56:      	movl	%eax, %ecx
    5f58:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5f5e:      	movl	(%rcx,%r15), %ecx
    5f62:      	addq	%rax, %rcx
    5f65:      	movl	%ecx, %eax
    5f67:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5f6c:      	movl	(%rax,%r15), %r9d
    5f70:      	addq	%rcx, %r9
    5f73:      	movl	%r9d, %edi
    5f76:      	andl	$0x3ff, %edi            # imm = 0x3FF
    5f7c:      	cmpl	$0x19, (%r15,%rdi)
    5f81:      	jae	0x5ff9 <generic_tracepoint_arg+0x179>
    5f83:      	cmpq	$0x1, %rdi
    5f87:      	movq	0x98(%rsp), %r12
    5f8f:      	je	0x6057 <generic_tracepoint_arg+0x1d7>
    5f95:      	testl	%edi, %edi
    5f97:      	jne	0x602d <generic_tracepoint_arg+0x1ad>
    5f9d:      	cmpl	$0x1, %ebx
    5fa0:      	jg	0x5fc6 <generic_tracepoint_arg+0x146>
    5fa2:      	cmpl	$-0x1, %ebx
    5fa5:      	movq	0x98(%rsp), %rdi
    5fad:      	je	0x6086 <generic_tracepoint_arg+0x206>
    5fb3:      	testl	%ebx, %ebx
    5fb5:      	je	0x6092 <generic_tracepoint_arg+0x212>
    5fbb:      	cmpl	$0x1, %ebx
    5fbe:      	je	0x60a1 <generic_tracepoint_arg+0x221>
    5fc4:      	jmp	0x5fe9 <generic_tracepoint_arg+0x169>
    5fc6:      	cmpl	$0x2, %ebx
    5fc9:      	movq	0x98(%rsp), %rdi
    5fd1:      	je	0x60b0 <generic_tracepoint_arg+0x230>
    5fd7:      	cmpl	$0x3, %ebx
    5fda:      	je	0x60bf <generic_tracepoint_arg+0x23f>
    5fe0:      	cmpl	$0x4, %ebx
    5fe3:      	je	0x60ce <generic_tracepoint_arg+0x24e>
    5fe9:      	cmpl	$0x4, %ebx
    5fec:      	jg	0x60fc <generic_tracepoint_arg+0x27c>
    5ff2:      	incl	%ebx
    5ff4:      	jmp	0x60dd <generic_tracepoint_arg+0x25d>
    5ff9:      	leaq	(%r15,%rdi), %rax
    5ffd:      	movq	%rax, 0xb0(%rsp)
    6005:      	xorl	%r11d, %r11d
    6008:      	leaq	0x70(%rsp), %rax
    600d:      	movq	%rax, 0x28(%rsp)
    6012:      	movq	%rbx, 0xa8(%rsp)
    601a:      	movq	%rdi, (%rsp)
    601e:      	movq	%r9, 0x8(%rsp)
    6023:      	movq	%r15, 0x68(%rsp)
    6028:      	jmp	0x616e <generic_tracepoint_arg+0x2ee>
    602d:      	movl	%edi, 0x5f04(%r14)
    6034:      	movq	(%rip), %rsi            # 0x603b <generic_tracepoint_arg+0x1bb>
    603b:      	movl	$0x4, %ecx
    6040:      	movl	$0xc, %eax
    6045:      	movq	0x98(%rsp), %r12
    604d:      	movq	%r12, %rdi
    6050:      	movl	$0x4, %edx
    6055:      	callq	*%rax
    6057:      	movq	(%rip), %rsi            # 0x605e <generic_tracepoint_arg+0x1de>
    605e:      	movl	$0x5, %ecx
    6063:      	movl	$0xc, %eax
    6068:      	movq	%r12, %rdi
    606b:      	movl	$0x5, %edx
    6070:      	callq	*%rax
    6072:      	xorl	%eax, %eax
    6074:      	addq	$0xb8, %rsp
    607b:      	popq	%rbx
    607c:      	popq	%r12
    607e:      	popq	%r13
    6080:      	popq	%r14
    6082:      	popq	%r15
    6084:      	popq	%rbp
    6085:      	retq
    6086:      	xorl	%ebx, %ebx
    6088:      	cmpb	$0x0, 0x5ec1(%r14)
    6090:      	jne	0x60dd <generic_tracepoint_arg+0x25d>
    6092:      	movl	$0x1, %ebx
    6097:      	cmpb	$0x0, 0x5ec2(%r14)
    609f:      	jne	0x60dd <generic_tracepoint_arg+0x25d>
    60a1:      	movl	$0x2, %ebx
    60a6:      	cmpb	$0x0, 0x5ec3(%r14)
    60ae:      	jne	0x60dd <generic_tracepoint_arg+0x25d>
    60b0:      	movl	$0x3, %ebx
    60b5:      	cmpb	$0x0, 0x5ec4(%r14)
    60bd:      	jne	0x60dd <generic_tracepoint_arg+0x25d>
    60bf:      	movl	$0x4, %ebx
    60c4:      	cmpb	$0x0, 0x5ec5(%r14)
    60cc:      	jne	0x60dd <generic_tracepoint_arg+0x25d>
    60ce:      	movl	$0x5, %ebx
    60d3:      	cmpb	$0x0, 0x5ec6(%r14)
    60db:      	je	0x60fc <generic_tracepoint_arg+0x27c>
    60dd:      	movl	%ebx, 0x5f00(%r14)
    60e4:      	movq	(%rip), %rsi            # 0x60eb <generic_tracepoint_arg+0x26b>
    60eb:      	movl	$0x3, %ecx
    60f0:      	movl	$0xc, %eax
    60f5:      	movl	$0x3, %edx
    60fa:      	callq	*%rax
    60fc:      	movq	0x60(%r14), %rbx
    6100:      	movl	$0xe, %eax
    6105:      	callq	*%rax
    6107:      	movq	%rbx, 0x38(%rsp)
    610c:      	movq	%rax, 0x40(%rsp)
    6111:      	movq	(%rip), %rdi            # 0x6118 <generic_tracepoint_arg+0x298>
    6118:      	leaq	0x38(%rsp), %rsi
    611d:      	movl	$0x1, %eax
    6122:      	callq	*%rax
    6124:      	testq	%rax, %rax
    6127:      	je	0x6072 <generic_tracepoint_arg+0x1f2>
    612d:      	movq	(%rip), %rdi            # 0x6134 <generic_tracepoint_arg+0x2b4>
    6134:      	leaq	0x38(%rsp), %rsi
    6139:      	movl	$0x3, %eax
    613e:      	callq	*%rax
    6140:      	jmp	0x6072 <generic_tracepoint_arg+0x1f2>
    6145:      	xorl	%ebx, %ebx
    6147:      	cmpl	$0x3, %eax
    614a:      	sete	%bl
    614d:      	nopl	(%rax)
    6150:      	testq	%rbx, %rbx
    6153:      	movq	0xa8(%rsp), %rbx
    615b:      	je	0x5f9d <generic_tracepoint_arg+0x11d>
    6161:      	incq	%r11
    6164:      	cmpq	$0x5, %r11
    6168:      	je	0x5f83 <generic_tracepoint_arg+0x103>
    616e:      	movq	0xb0(%rsp), %rax
    6176:      	movl	0x4(%rax,%r11,4), %r13d
    617b:      	testl	$0x3ff, %r13d           # imm = 0x3FF
    6182:      	je	0x5f83 <generic_tracepoint_arg+0x103>
    6188:      	addl	%r9d, %r13d
    618b:      	andl	$0x3ff, %r13d           # imm = 0x3FF
    6192:      	movl	0x4(%r15,%r13), %eax
    6197:      	cmpl	$0x23, %eax
    619a:      	je	0x5f9d <generic_tracepoint_arg+0x11d>
    61a0:      	addq	%r15, %r13
    61a3:      	movl	(%r13), %ecx
    61a7:      	cmpq	$0x4, %rcx
    61ab:      	ja	0x5f9d <generic_tracepoint_arg+0x11d>
    61b1:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
    61ba:      	jne	0x5f9d <generic_tracepoint_arg+0x11d>
    61c0:      	movq	0x5e78(%r14,%rcx,8), %rcx
    61c8:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    61ce:      	leaq	(%r14,%rcx), %r12
    61d2:      	addq	$0x90, %r12
    61d9:      	movl	0xc(%r13), %ecx
    61dd:      	cmpl	$0x1b, %ecx
    61e0:      	jle	0x61fd <generic_tracepoint_arg+0x37d>
    61e2:      	cmpl	$0x25, %ecx
    61e5:      	jg	0x6228 <generic_tracepoint_arg+0x3a8>
    61e7:      	leal	-0x1c(%rcx), %edx
    61ea:      	cmpl	$0x9, %edx
    61ed:      	jb	0x626e <generic_tracepoint_arg+0x3ee>
    61ef:      	cmpl	$0x25, %ecx
    61f2:      	je	0x6486 <generic_tracepoint_arg+0x606>
    61f8:      	jmp	0x6161 <generic_tracepoint_arg+0x2e1>
    61fd:      	cmpl	$0x9, %ecx
    6200:      	jle	0x624e <generic_tracepoint_arg+0x3ce>
    6202:      	leal	-0xa(%rcx), %edx
    6205:      	cmpl	$0x4, %edx
    6208:      	jb	0x626e <generic_tracepoint_arg+0x3ee>
    620a:      	leal	-0xf(%rcx), %edx
    620d:      	cmpl	$0x2, %edx
    6210:      	jb	0x6486 <generic_tracepoint_arg+0x606>
    6216:      	cmpl	$0x11, %ecx
    6219:      	jne	0x6161 <generic_tracepoint_arg+0x2e1>
    621f:      	addq	$0x4, %r12
    6223:      	jmp	0x6486 <generic_tracepoint_arg+0x606>
    6228:      	cmpl	$0x29, %ecx
    622b:      	jg	0x63f3 <generic_tracepoint_arg+0x573>
    6231:      	leal	-0x26(%rcx), %edx
    6234:      	cmpl	$0x2, %edx
    6237:      	jb	0x6389 <generic_tracepoint_arg+0x509>
    623d:      	leal	-0x28(%rcx), %edx
    6240:      	cmpl	$0x2, %edx
    6243:      	jb	0x6334 <generic_tracepoint_arg+0x4b4>
    6249:      	jmp	0x6161 <generic_tracepoint_arg+0x2e1>
    624e:      	cmpl	$0x4, %ecx
    6251:      	jg	0x6321 <generic_tracepoint_arg+0x4a1>
    6257:      	cmpl	$0x1, %ecx
    625a:      	je	0x626e <generic_tracepoint_arg+0x3ee>
    625c:      	cmpl	$0x2, %ecx
    625f:      	je	0x6a73 <generic_tracepoint_arg+0xbf3>
    6265:      	cmpl	$0x4, %ecx
    6268:      	jne	0x6161 <generic_tracepoint_arg+0x2e1>
    626e:      	cmpl	$0xb, %ecx
    6271:      	jle	0x62fe <generic_tracepoint_arg+0x47e>
    6277:      	cmpl	$0x24, %ecx
    627a:      	ja	0x65ab <generic_tracepoint_arg+0x72b>
    6280:      	movl	%ecx, %edx
    6282:      	movabsq	$0x1e00000000, %rsi     # imm = 0x1E00000000
    628c:      	btq	%rdx, %rsi
    6290:      	jb	0x63c7 <generic_tracepoint_arg+0x547>
    6296:      	movl	$0x60000000, %esi       # imm = 0x60000000
    629b:      	btq	%rdx, %rsi
    629f:      	jb	0x6845 <generic_tracepoint_arg+0x9c5>
    62a5:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
    62af:      	btq	%rdx, %rsi
    62b3:      	jae	0x65ab <generic_tracepoint_arg+0x72b>
    62b9:      	cmpl	$0x20, %eax
    62bc:      	ja	0x5f9d <generic_tracepoint_arg+0x11d>
    62c2:      	movl	%eax, %ecx
    62c4:      	movl	$0x101e, %edx           # imm = 0x101E
    62c9:      	btq	%rcx, %rdx
    62cd:      	jae	0x6f89 <generic_tracepoint_arg+0x1109>
    62d3:      	movl	0x10(%r13), %ecx
    62d7:      	cmpl	$0x2, %eax
    62da:      	jle	0x74b3 <generic_tracepoint_arg+0x1633>
    62e0:      	leal	-0x3(%rax), %edx
    62e3:      	cmpl	$0x2, %edx
    62e6:      	jae	0x7c0e <generic_tracepoint_arg+0x1d8e>
    62ec:      	movzbl	(%r12), %edx
    62f1:      	cmpl	%edx, %ecx
    62f3:      	je	0x6145 <generic_tracepoint_arg+0x2c5>
    62f9:      	jmp	0x7d46 <generic_tracepoint_arg+0x1ec6>
    62fe:      	leal	-0xa(%rcx), %edx
    6301:      	cmpl	$0x2, %edx
    6304:      	jb	0x6af3 <generic_tracepoint_arg+0xc73>
    630a:      	cmpl	$0x1, %ecx
    630d:      	je	0x65b7 <generic_tracepoint_arg+0x737>
    6313:      	cmpl	$0x4, %ecx
    6316:      	je	0x65b7 <generic_tracepoint_arg+0x737>
    631c:      	jmp	0x6161 <generic_tracepoint_arg+0x2e1>
    6321:      	cmpl	$0x5, %ecx
    6324:      	je	0x6334 <generic_tracepoint_arg+0x4b4>
    6326:      	cmpl	$0x6, %ecx
    6329:      	je	0x6389 <generic_tracepoint_arg+0x509>
    632b:      	cmpl	$0x7, %ecx
    632e:      	jne	0x6161 <generic_tracepoint_arg+0x2e1>
    6334:      	movq	$0x0, 0x58(%rsp)
    633d:      	movq	$0x0, 0x50(%rsp)
    6346:      	movq	$0x0, 0x48(%rsp)
    634f:      	movq	$0x0, 0x40(%rsp)
    6358:      	movq	$0x0, 0x38(%rsp)
    6361:      	cmpl	$0x27, %ecx
    6364:      	jg	0x65f5 <generic_tracepoint_arg+0x775>
    636a:      	cmpl	$0x5, %ecx
    636d:      	je	0x6c58 <generic_tracepoint_arg+0xdd8>
    6373:      	movq	%r12, %rdx
    6376:      	movl	$0x0, %ebx
    637b:      	cmpl	$0x7, %ecx
    637e:      	je	0x6c5a <generic_tracepoint_arg+0xdda>
    6384:      	jmp	0x6150 <generic_tracepoint_arg+0x2d0>
    6389:      	movl	(%r12), %ebp
    638d:      	addq	$0x4, %r12
    6391:      	movq	%r12, 0x18(%rsp)
    6396:      	cmpl	$0x19, %eax
    6399:      	jg	0x6678 <generic_tracepoint_arg+0x7f8>
    639f:      	leal	-0x3(%rax), %ecx
    63a2:      	cmpl	$0x2, %ecx
    63a5:      	jb	0x6ebb <generic_tracepoint_arg+0x103b>
    63ab:      	cmpl	$0x8, %eax
    63ae:      	je	0x6e25 <generic_tracepoint_arg+0xfa5>
    63b4:      	movl	$0x0, %ebx
    63b9:      	cmpl	$0x9, %eax
    63bc:      	je	0x6698 <generic_tracepoint_arg+0x818>
    63c2:      	jmp	0x94bb <generic_tracepoint_arg+0x363b>
    63c7:      	cmpl	$0x9, %eax
    63ca:      	jle	0x6a62 <generic_tracepoint_arg+0xbe2>
    63d0:      	cmpl	$0x1d, %eax
    63d3:      	jg	0x6ddf <generic_tracepoint_arg+0xf5f>
    63d9:      	leal	-0xa(%rax), %edx
    63dc:      	cmpl	$0x2, %edx
    63df:      	jb	0x6b80 <generic_tracepoint_arg+0xd00>
    63e5:      	cmpl	$0xc, %eax
    63e8:      	je	0x6b09 <generic_tracepoint_arg+0xc89>
    63ee:      	jmp	0x5f9d <generic_tracepoint_arg+0x11d>
    63f3:      	cmpl	$0x2a, %ecx
    63f6:      	je	0x6486 <generic_tracepoint_arg+0x606>
    63fc:      	cmpl	$0x2c, %ecx
    63ff:      	jne	0x6161 <generic_tracepoint_arg+0x2e1>
    6405:      	movq	%r12, %rcx
    6408:      	leaq	0x4(%r12), %r8
    640d:      	movzbl	0x3(%r12), %ebp
    6413:      	movzbl	%bpl, %esi
    6417:      	cmpl	$0x19, %eax
    641a:      	jg	0x71fc <generic_tracepoint_arg+0x137c>
    6420:      	leal	-0x3(%rax), %ecx
    6423:      	cmpl	$0x2, %ecx
    6426:      	jae	0x77a1 <generic_tracepoint_arg+0x1921>
    642c:      	movl	$0x0, 0x70(%rsp)
    6434:      	movl	$0x100, %ebx            # imm = 0x100
    6439:      	cmpb	$-0x70, %bpl
    643d:      	ja	0x7483 <generic_tracepoint_arg+0x1603>
    6443:      	testb	%bpl, %bpl
    6446:      	je	0x6458 <generic_tracepoint_arg+0x5d8>
    6448:      	movl	%esi, %eax
    644a:      	movl	$0x18, %ecx
    644f:      	cltd
    6450:      	idivl	%ecx
    6452:      	movl	%esi, %ebx
    6454:      	testl	%edx, %edx
    6456:      	je	0x647a <generic_tracepoint_arg+0x5fa>
    6458:      	movl	%esi, %eax
    645a:      	movl	$0x18, %ecx
    645f:      	cltd
    6460:      	idivl	%ecx
    6462:      	shll	$0x3, %eax
    6465:      	leal	(%rax,%rax,2), %eax
    6468:      	addl	$0x18, %eax
    646b:      	movzwl	%ax, %ebx
    646e:      	cmpl	$0x90, %ebx
    6474:      	ja	0x7483 <generic_tracepoint_arg+0x1603>
    647a:      	movl	%ebx, %eax
    647c:      	cltd
    647d:      	idivl	%ecx
    647f:      	decl	%eax
    6481:      	jmp	0x8369 <generic_tracepoint_arg+0x24e9>
    6486:      	movl	(%r12), %ebp
    648a:      	movl	%eax, %ecx
    648c:      	andl	$-0x2, %ecx
    648f:      	cmpl	$0x24, %ecx
    6492:      	je	0x649c <generic_tracepoint_arg+0x61c>
    6494:      	testl	%ebp, %ebp
    6496:      	je	0x5f9d <generic_tracepoint_arg+0x11d>
    649c:      	cmpl	$0x25, %eax
    649f:      	ja	0x67cf <generic_tracepoint_arg+0x94f>
    64a5:      	movl	%eax, %ecx
    64a7:      	movl	$0x4000100, %edx        # imm = 0x4000100
    64ac:      	btq	%rcx, %rdx
    64b0:      	jb	0x69c0 <generic_tracepoint_arg+0xb40>
    64b6:      	movl	$0x8000200, %edx        # imm = 0x8000200
    64bb:      	btq	%rcx, %rdx
    64bf:      	jb	0x688a <generic_tracepoint_arg+0xa0a>
    64c5:      	movabsq	$0x3000000000, %rdx     # imm = 0x3000000000
    64cf:      	btq	%rcx, %rdx
    64d3:      	jae	0x67cf <generic_tracepoint_arg+0x94f>
    64d9:      	movw	$0x0, 0x38(%rsp)
    64e0:      	cmpl	$0x1000, %ebp           # imm = 0x1000
    64e6:      	ja	0x8c6c <generic_tracepoint_arg+0x2dec>
    64ec:      	movq	%r11, 0x10(%rsp)
    64f1:      	leaq	(%r12,%rbp), %rcx
    64f5:      	addq	$0x8, %rcx
    64f9:      	movl	$0x4, %eax
    64fe:      	leaq	0x38(%rsp), %rdi
    6503:      	movl	$0x2, %edx
    6508:      	movl	(%r12), %ecx
    650c:      	leaq	(%r12,%rcx), %rdx
    6510:      	addq	$0x8, %rdx
    6514:      	movl	$0x2, %esi
    6519:      	callq	*%rax
    651b:      	movl	0x10(%r13), %ecx
    651f:      	testl	%ecx, %ecx
    6521:      	je	0x9113 <generic_tracepoint_arg+0x3293>
    6527:      	movzwl	0x38(%rsp), %eax
    652c:      	andl	$0xf000, %eax           # imm = 0xF000
    6531:      	movl	$0x1, %ebx
    6536:      	cmpl	%eax, %ecx
    6538:      	je	0x9115 <generic_tracepoint_arg+0x3295>
    653e:      	movl	0x8(%r13), %ecx
    6542:      	cmpl	$0xd, %ecx
    6545:      	movq	(%rsp), %rdi
    6549:      	movq	0x8(%rsp), %r9
    654e:      	movq	0x10(%rsp), %r11
    6553:      	jb	0x8c6c <generic_tracepoint_arg+0x2dec>
    6559:      	movl	0x14(%r13), %edx
    655d:      	testl	%edx, %edx
    655f:      	je	0x8c6c <generic_tracepoint_arg+0x2dec>
    6565:      	cmpl	%eax, %edx
    6567:      	je	0x9123 <generic_tracepoint_arg+0x32a3>
    656d:      	cmpl	$0x11, %ecx
    6570:      	jb	0x8c6c <generic_tracepoint_arg+0x2dec>
    6576:      	movl	0x18(%r13), %edx
    657a:      	testl	%edx, %edx
    657c:      	je	0x8c6c <generic_tracepoint_arg+0x2dec>
    6582:      	cmpl	%eax, %edx
    6584:      	je	0x9123 <generic_tracepoint_arg+0x32a3>
    658a:      	cmpl	$0x15, %ecx
    658d:      	jb	0x94ed <generic_tracepoint_arg+0x366d>
    6593:      	movl	0x1c(%r13), %ecx
    6597:      	testl	%ecx, %ecx
    6599:      	je	0x94ed <generic_tracepoint_arg+0x366d>
    659f:      	xorl	%ebx, %ebx
    65a1:      	cmpl	%eax, %ecx
    65a3:      	sete	%bl
    65a6:      	jmp	0x94ef <generic_tracepoint_arg+0x366f>
    65ab:      	leal	-0xc(%rcx), %edx
    65ae:      	cmpl	$0x2, %edx
    65b1:      	jae	0x6aea <generic_tracepoint_arg+0xc6a>
    65b7:      	cmpl	$0x20, %eax
    65ba:      	ja	0x5f9d <generic_tracepoint_arg+0x11d>
    65c0:      	movl	%eax, %edx
    65c2:      	movl	$0x101e, %esi           # imm = 0x101E
    65c7:      	btq	%rdx, %rsi
    65cb:      	jae	0x6614 <generic_tracepoint_arg+0x794>
    65cd:      	movl	0x10(%r13), %edx
    65d1:      	cmpl	$0x2, %eax
    65d4:      	jle	0x6ab2 <generic_tracepoint_arg+0xc32>
    65da:      	leal	-0x3(%rax), %esi
    65dd:      	cmpl	$0x2, %esi
    65e0:      	jae	0x6f71 <generic_tracepoint_arg+0x10f1>
    65e6:      	cmpl	%edx, (%r12)
    65ea:      	je	0x6145 <generic_tracepoint_arg+0x2c5>
    65f0:      	jmp	0x80a7 <generic_tracepoint_arg+0x2227>
    65f5:      	cmpl	$0x28, %ecx
    65f8:      	je	0x6c2a <generic_tracepoint_arg+0xdaa>
    65fe:      	movq	%r12, %rdx
    6601:      	movl	$0x0, %ebx
    6606:      	cmpl	$0x29, %ecx
    6609:      	je	0x6c5a <generic_tracepoint_arg+0xdda>
    660f:      	jmp	0x6150 <generic_tracepoint_arg+0x2d0>
    6614:      	movl	$0xc00, %esi            # imm = 0xC00
    6619:      	btq	%rdx, %rsi
    661d:      	jb	0x6be7 <generic_tracepoint_arg+0xd67>
    6623:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
    662d:      	btq	%rdx, %rsi
    6631:      	jae	0x5f9d <generic_tracepoint_arg+0x11d>
    6637:      	cmpl	$0x1f, %eax
    663a:      	jne	0x71c9 <generic_tracepoint_arg+0x1349>
    6640:      	movl	0x10(%r13), %esi
    6644:      	movl	0x14(%r13), %edx
    6648:      	cmpl	$0xc, %ecx
    664b:      	ja	0x7dc3 <generic_tracepoint_arg+0x1f43>
    6651:      	movl	$0x1402, %eax           # imm = 0x1402
    6656:      	btl	%ecx, %eax
    6659:      	jae	0x7dc3 <generic_tracepoint_arg+0x1f43>
    665f:      	movl	(%r12), %eax
    6663:      	cmpl	%eax, %esi
    6665:      	jg	0x7dd3 <generic_tracepoint_arg+0x1f53>
    666b:      	cmpl	%edx, %eax
    666d:      	jle	0x6161 <generic_tracepoint_arg+0x2e1>
    6673:      	jmp	0x7dd3 <generic_tracepoint_arg+0x1f53>
    6678:      	cmpl	$0x20, %eax
    667b:      	jg	0x6cdf <generic_tracepoint_arg+0xe5f>
    6681:      	cmpl	$0x1a, %eax
    6684:      	je	0x6e25 <generic_tracepoint_arg+0xfa5>
    668a:      	movl	$0x0, %ebx
    668f:      	cmpl	$0x1b, %eax
    6692:      	jne	0x94bb <generic_tracepoint_arg+0x363b>
    6698:      	movq	%r11, 0x10(%rsp)
    669d:      	movl	0x10(%r13), %eax
    66a1:      	movl	%eax, 0x38(%rsp)
    66a5:      	movl	$0x0, 0x70(%rsp)
    66ad:      	movl	$0x1, %eax
    66b2:      	leaq	0x38(%rsp), %rsi
    66b7:      	movq	(%rip), %rdi            # 0x66be <generic_tracepoint_arg+0x83e>
    66be:      	callq	*%rax
    66c0:      	testl	%ebp, %ebp
    66c2:      	je	0x94ab <generic_tracepoint_arg+0x362b>
    66c8:      	movq	%rax, %r12
    66cb:      	movl	$0x0, %ebx
    66d0:      	testq	%rax, %rax
    66d3:      	je	0x94ad <generic_tracepoint_arg+0x362d>
    66d9:      	movl	$0x1, %eax
    66de:      	movq	0x28(%rsp), %rsi
    66e3:      	movq	(%rip), %rdi            # 0x66ea <generic_tracepoint_arg+0x86a>
    66ea:      	callq	*%rax
    66ec:      	testq	%rax, %rax
    66ef:      	je	0x94ab <generic_tracepoint_arg+0x362b>
    66f5:      	movq	%rax, %rdi
    66f8:      	movq	%r12, 0x20(%rsp)
    66fd:      	cmpl	$0x7f, %ebp
    6700:      	movl	$0x7f, %eax
    6705:      	cmovbl	%ebp, %eax
    6708:      	shll	$0x3, %eax
    670b:      	movl	%eax, (%rdi)
    670d:      	movq	%rbp, %rax
    6710:      	negq	%rax
    6713:      	movl	$0x3, %ecx
    6718:      	subq	%rbp, %rcx
    671b:      	leal	-0x4(%rbp), %edx
    671e:      	movq	%rdi, 0x60(%rsp)
    6723:      	addq	$0x7, %rdi
    6727:      	movl	$0x2, %r8d
    672d:      	subq	%rbp, %r8
    6730:      	leal	-0x3(%rbp), %r9d
    6734:      	movl	$0x1, %r10d
    673a:      	subq	%rbp, %r10
    673d:      	leal	-0x2(%rbp), %r11d
    6741:      	decl	%ebp
    6743:      	xorl	%ebx, %ebx
    6745:      	movq	0x18(%rsp), %rsi
    674a:      	leal	(%rbx,%rbp), %r12d
    674e:      	andl	$0xfff, %r12d           # imm = 0xFFF
    6755:      	movzbl	(%rsi,%r12), %r12d
    675a:      	movb	%r12b, -0x3(%rdi)
    675e:      	cmpq	%rbx, %r10
    6761:      	je	0x67bb <generic_tracepoint_arg+0x93b>
    6763:      	leal	(%r11,%rbx), %r12d
    6767:      	andl	$0xfff, %r12d           # imm = 0xFFF
    676e:      	movzbl	(%rsi,%r12), %r12d
    6773:      	movb	%r12b, -0x2(%rdi)
    6777:      	cmpq	%rbx, %r8
    677a:      	je	0x67bb <generic_tracepoint_arg+0x93b>
    677c:      	leal	(%r9,%rbx), %r12d
    6780:      	andl	$0xfff, %r12d           # imm = 0xFFF
    6787:      	movzbl	(%rsi,%r12), %r12d
    678c:      	movb	%r12b, -0x1(%rdi)
    6790:      	cmpq	%rbx, %rcx
    6793:      	je	0x67bb <generic_tracepoint_arg+0x93b>
    6795:      	cmpq	$-0x7c, %rbx
    6799:      	je	0x67bb <generic_tracepoint_arg+0x93b>
    679b:      	leal	(%rdx,%rbx), %r12d
    679f:      	andl	$0xfff, %r12d           # imm = 0xFFF
    67a6:      	movzbl	(%rsi,%r12), %r12d
    67ab:      	movb	%r12b, (%rdi)
    67ae:      	addq	$-0x4, %rbx
    67b2:      	addq	$0x4, %rdi
    67b6:      	cmpq	%rbx, %rax
    67b9:      	jne	0x674a <generic_tracepoint_arg+0x8ca>
    67bb:      	movl	$0x1, %eax
    67c0:      	movq	0x20(%rsp), %rdi
    67c5:      	movq	0x60(%rsp), %rsi
    67ca:      	jmp	0x7968 <generic_tracepoint_arg+0x1ae8>
    67cf:      	addl	$-0x3, %eax
    67d2:      	cmpl	$0x2, %eax
    67d5:      	jae	0x8c6c <generic_tracepoint_arg+0x2dec>
    67db:      	movl	$0x0, 0x70(%rsp)
    67e3:      	cmpl	$0x1000, %ebp           # imm = 0x1000
    67e9:      	ja	0x8c6c <generic_tracepoint_arg+0x2dec>
    67ef:      	movzwl	%bp, %eax
    67f2:      	cmpl	$0x90, %eax
    67f7:      	movq	%r11, 0x10(%rsp)
    67fc:      	ja	0x75c3 <generic_tracepoint_arg+0x1743>
    6802:      	testw	%bp, %bp
    6805:      	je	0x6817 <generic_tracepoint_arg+0x997>
    6807:      	movl	%ebp, %eax
    6809:      	movl	$0x18, %ecx
    680e:      	cltd
    680f:      	idivl	%ecx
    6811:      	movl	%ebp, %esi
    6813:      	testl	%edx, %edx
    6815:      	je	0x6839 <generic_tracepoint_arg+0x9b9>
    6817:      	movl	%ebp, %eax
    6819:      	movl	$0x18, %ecx
    681e:      	cltd
    681f:      	idivl	%ecx
    6821:      	shll	$0x3, %eax
    6824:      	leal	(%rax,%rax,2), %eax
    6827:      	addl	$0x18, %eax
    682a:      	movzwl	%ax, %esi
    682d:      	cmpl	$0x90, %esi
    6833:      	ja	0x75fb <generic_tracepoint_arg+0x177b>
    6839:      	movl	%esi, %eax
    683b:      	cltd
    683c:      	idivl	%ecx
    683e:      	decl	%eax
    6840:      	jmp	0x81cf <generic_tracepoint_arg+0x234f>
    6845:      	cmpl	$0x20, %eax
    6848:      	ja	0x5f9d <generic_tracepoint_arg+0x11d>
    684e:      	movl	%eax, %ecx
    6850:      	movl	$0x101e, %edx           # imm = 0x101E
    6855:      	btq	%rcx, %rdx
    6859:      	jae	0x6fbc <generic_tracepoint_arg+0x113c>
    685f:      	movl	0x10(%r13), %ecx
    6863:      	cmpl	$0x2, %eax
    6866:      	jle	0x74d7 <generic_tracepoint_arg+0x1657>
    686c:      	leal	-0x3(%rax), %edx
    686f:      	cmpl	$0x2, %edx
    6872:      	jae	0x7c29 <generic_tracepoint_arg+0x1da9>
    6878:      	movzwl	(%r12), %edx
    687d:      	cmpl	%edx, %ecx
    687f:      	je	0x6145 <generic_tracepoint_arg+0x2c5>
    6885:      	jmp	0x7d8b <generic_tracepoint_arg+0x1f0b>
    688a:      	movq	%r11, 0x10(%rsp)
    688f:      	movl	0x10(%r13), %eax
    6893:      	movl	%eax, 0x38(%rsp)
    6897:      	movl	$0x0, 0x70(%rsp)
    689f:      	movl	$0x1, %eax
    68a4:      	leaq	0x38(%rsp), %rsi
    68a9:      	movq	(%rip), %rdi            # 0x68b0 <generic_tracepoint_arg+0xa30>
    68b0:      	callq	*%rax
    68b2:      	testl	%ebp, %ebp
    68b4:      	je	0x9113 <generic_tracepoint_arg+0x3293>
    68ba:      	movl	$0x0, %ebx
    68bf:      	testq	%rax, %rax
    68c2:      	je	0x9115 <generic_tracepoint_arg+0x3295>
    68c8:      	movq	%rax, 0x18(%rsp)
    68cd:      	movl	$0x1, %eax
    68d2:      	movq	0x28(%rsp), %rsi
    68d7:      	movq	(%rip), %rdi            # 0x68de <generic_tracepoint_arg+0xa5e>
    68de:      	callq	*%rax
    68e0:      	testq	%rax, %rax
    68e3:      	je	0x9113 <generic_tracepoint_arg+0x3293>
    68e9:      	movq	%rax, %rdi
    68ec:      	cmpl	$0x7f, %ebp
    68ef:      	movl	$0x7f, %eax
    68f4:      	cmovbl	%ebp, %eax
    68f7:      	shll	$0x3, %eax
    68fa:      	movl	%eax, (%rdi)
    68fc:      	movq	%rbp, %rax
    68ff:      	negq	%rax
    6902:      	movl	$0x3, %ecx
    6907:      	subq	%rbp, %rcx
    690a:      	leal	-0x4(%rbp), %edx
    690d:      	movq	%rdi, 0x20(%rsp)
    6912:      	addq	$0x7, %rdi
    6916:      	movl	$0x2, %r8d
    691c:      	subq	%rbp, %r8
    691f:      	leal	-0x3(%rbp), %r9d
    6923:      	movl	$0x1, %r10d
    6929:      	subq	%rbp, %r10
    692c:      	leal	-0x2(%rbp), %r11d
    6930:      	decl	%ebp
    6932:      	xorl	%ebx, %ebx
    6934:      	movq	%r12, %rsi
    6937:      	leal	(%rbx,%rbp), %r12d
    693b:      	andl	$0xfff, %r12d           # imm = 0xFFF
    6942:      	movzbl	0x4(%rsi,%r12), %r12d
    6948:      	movb	%r12b, -0x3(%rdi)
    694c:      	cmpq	%rbx, %r10
    694f:      	je	0x69ac <generic_tracepoint_arg+0xb2c>
    6951:      	leal	(%r11,%rbx), %r12d
    6955:      	andl	$0xfff, %r12d           # imm = 0xFFF
    695c:      	movzbl	0x4(%rsi,%r12), %r12d
    6962:      	movb	%r12b, -0x2(%rdi)
    6966:      	cmpq	%rbx, %r8
    6969:      	je	0x69ac <generic_tracepoint_arg+0xb2c>
    696b:      	leal	(%r9,%rbx), %r12d
    696f:      	andl	$0xfff, %r12d           # imm = 0xFFF
    6976:      	movzbl	0x4(%rsi,%r12), %r12d
    697c:      	movb	%r12b, -0x1(%rdi)
    6980:      	cmpq	%rbx, %rcx
    6983:      	je	0x69ac <generic_tracepoint_arg+0xb2c>
    6985:      	cmpq	$-0x7c, %rbx
    6989:      	je	0x69ac <generic_tracepoint_arg+0xb2c>
    698b:      	leal	(%rdx,%rbx), %r12d
    698f:      	andl	$0xfff, %r12d           # imm = 0xFFF
    6996:      	movzbl	0x4(%rsi,%r12), %r12d
    699c:      	movb	%r12b, (%rdi)
    699f:      	addq	$-0x4, %rbx
    69a3:      	addq	$0x4, %rdi
    69a7:      	cmpq	%rbx, %rax
    69aa:      	jne	0x6937 <generic_tracepoint_arg+0xab7>
    69ac:      	movl	$0x1, %eax
    69b1:      	movq	0x18(%rsp), %rdi
    69b6:      	movq	0x20(%rsp), %rsi
    69bb:      	jmp	0x9107 <generic_tracepoint_arg+0x3287>
    69c0:      	movq	%r11, 0x10(%rsp)
    69c5:      	movl	0x10(%r13), %eax
    69c9:      	movl	%eax, 0x38(%rsp)
    69cd:      	movl	$0x0, 0x70(%rsp)
    69d5:      	movl	$0x1, %eax
    69da:      	leaq	0x38(%rsp), %rsi
    69df:      	movq	(%rip), %rdi            # 0x69e6 <generic_tracepoint_arg+0xb66>
    69e6:      	callq	*%rax
    69e8:      	testl	%ebp, %ebp
    69ea:      	je	0x9113 <generic_tracepoint_arg+0x3293>
    69f0:      	movl	$0x0, %ebx
    69f5:      	testq	%rax, %rax
    69f8:      	je	0x9115 <generic_tracepoint_arg+0x3295>
    69fe:      	movq	%rax, 0x18(%rsp)
    6a03:      	movl	$0x1, %eax
    6a08:      	movq	0x28(%rsp), %rsi
    6a0d:      	movq	(%rip), %rdi            # 0x6a14 <generic_tracepoint_arg+0xb94>
    6a14:      	callq	*%rax
    6a16:      	testq	%rax, %rax
    6a19:      	je	0x9113 <generic_tracepoint_arg+0x3293>
    6a1f:      	movq	%rax, %rbx
    6a22:      	addq	$0x4, %r12
    6a26:      	cmpl	$0xff, %ebp
    6a2c:      	movl	$0xff, %eax
    6a31:      	cmovael	%eax, %ebp
    6a34:      	leal	(,%rbp,8), %eax
    6a3b:      	movl	%eax, (%rbx)
    6a3d:      	movq	%rbx, %rdi
    6a40:      	addq	$0x4, %rdi
    6a44:      	movl	$0x4, %eax
    6a49:      	movl	%ebp, %esi
    6a4b:      	movq	%r12, %rdx
    6a4e:      	callq	*%rax
    6a50:      	movl	$0x1, %eax
    6a55:      	movq	0x18(%rsp), %rdi
    6a5a:      	movq	%rbx, %rsi
    6a5d:      	jmp	0x9107 <generic_tracepoint_arg+0x3287>
    6a62:      	leal	-0x1(%rax), %edx
    6a65:      	cmpl	$0x4, %edx
    6a68:      	jb	0x6b09 <generic_tracepoint_arg+0xc89>
    6a6e:      	jmp	0x5f9d <generic_tracepoint_arg+0x11d>
    6a73:      	movl	0x4(%r12), %ebp
    6a78:      	addq	$0x8, %r12
    6a7c:      	movq	%r12, 0x18(%rsp)
    6a81:      	cmpl	$0x19, %eax
    6a84:      	jg	0x7072 <generic_tracepoint_arg+0x11f2>
    6a8a:      	leal	-0x3(%rax), %ecx
    6a8d:      	cmpl	$0x2, %ecx
    6a90:      	jb	0x7977 <generic_tracepoint_arg+0x1af7>
    6a96:      	cmpl	$0x8, %eax
    6a99:      	je	0x78d1 <generic_tracepoint_arg+0x1a51>
    6a9f:      	movl	$0x0, %ebx
    6aa4:      	cmpl	$0x9, %eax
    6aa7:      	je	0x7092 <generic_tracepoint_arg+0x1212>
    6aad:      	jmp	0x94bb <generic_tracepoint_arg+0x363b>
    6ab2:      	cmpl	$0x1, %eax
    6ab5:      	je	0x7364 <generic_tracepoint_arg+0x14e4>
    6abb:      	cmpl	$0x2, %eax
    6abe:      	jne	0x80a7 <generic_tracepoint_arg+0x2227>
    6ac4:      	cmpl	$0xc, %ecx
    6ac7:      	ja	0x809d <generic_tracepoint_arg+0x221d>
    6acd:      	movl	$0x1402, %esi           # imm = 0x1402
    6ad2:      	btl	%ecx, %esi
    6ad5:      	jae	0x809d <generic_tracepoint_arg+0x221d>
    6adb:      	cmpl	%edx, (%r12)
    6adf:      	jl	0x6161 <generic_tracepoint_arg+0x2e1>
    6ae5:      	jmp	0x80a7 <generic_tracepoint_arg+0x2227>
    6aea:      	cmpl	$0x1c, %ecx
    6aed:      	jne	0x6161 <generic_tracepoint_arg+0x2e1>
    6af3:      	cmpl	$0x20, %eax
    6af6:      	ja	0x5f9d <generic_tracepoint_arg+0x11d>
    6afc:      	movl	%eax, %edx
    6afe:      	movl	$0x101e, %esi           # imm = 0x101E
    6b03:      	btq	%rdx, %rsi
    6b07:      	jae	0x6b2d <generic_tracepoint_arg+0xcad>
    6b09:      	movq	0x10(%r13), %rdx
    6b0d:      	cmpl	$0x2, %eax
    6b10:      	jle	0x6b51 <generic_tracepoint_arg+0xcd1>
    6b12:      	leal	-0x3(%rax), %esi
    6b15:      	cmpl	$0x2, %esi
    6b18:      	jae	0x6dc7 <generic_tracepoint_arg+0xf47>
    6b1e:      	cmpq	%rdx, (%r12)
    6b22:      	je	0x6145 <generic_tracepoint_arg+0x2c5>
    6b28:      	jmp	0x7b92 <generic_tracepoint_arg+0x1d12>
    6b2d:      	movl	$0xc00, %esi            # imm = 0xC00
    6b32:      	btq	%rdx, %rsi
    6b36:      	jb	0x6b80 <generic_tracepoint_arg+0xd00>
    6b38:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
    6b42:      	btq	%rdx, %rsi
    6b46:      	jb	0x6deb <generic_tracepoint_arg+0xf6b>
    6b4c:      	jmp	0x5f9d <generic_tracepoint_arg+0x11d>
    6b51:      	cmpl	$0x1, %eax
    6b54:      	je	0x7055 <generic_tracepoint_arg+0x11d5>
    6b5a:      	cmpl	$0x2, %eax
    6b5d:      	jne	0x7b92 <generic_tracepoint_arg+0x1d12>
    6b63:      	cmpl	$0xc, %ecx
    6b66:      	je	0x6b71 <generic_tracepoint_arg+0xcf1>
    6b68:      	cmpl	$0xa, %ecx
    6b6b:      	jne	0x7b88 <generic_tracepoint_arg+0x1d08>
    6b71:      	cmpq	%rdx, (%r12)
    6b75:      	jl	0x6161 <generic_tracepoint_arg+0x2e1>
    6b7b:      	jmp	0x7b92 <generic_tracepoint_arg+0x1d12>
    6b80:      	movq	%r11, %rbp
    6b83:      	movzbl	0x10(%r13), %eax
    6b88:      	movl	%eax, 0x70(%rsp)
    6b8c:      	movl	$0x1, %eax
    6b91:      	movq	0x28(%rsp), %rsi
    6b96:      	movq	(%rip), %rdi            # 0x6b9d <generic_tracepoint_arg+0xd1d>
    6b9d:      	callq	*%rax
    6b9f:      	testq	%rax, %rax
    6ba2:      	je	0x78be <generic_tracepoint_arg+0x1a3e>
    6ba8:      	movq	%rax, %rdi
    6bab:      	movq	(%r12), %rax
    6baf:      	movq	%rax, 0x38(%rsp)
    6bb4:      	movl	$0x1, %eax
    6bb9:      	leaq	0x38(%rsp), %rsi
    6bbe:      	callq	*%rax
    6bc0:      	movl	0x4(%r13), %ecx
    6bc4:      	cmpl	$0xb, %ecx
    6bc7:      	je	0x75a9 <generic_tracepoint_arg+0x1729>
    6bcd:      	cmpl	$0xa, %ecx
    6bd0:      	movq	(%rsp), %rdi
    6bd4:      	movq	0x8(%rsp), %r9
    6bd9:      	movq	%rbp, %r11
    6bdc:      	je	0x76af <generic_tracepoint_arg+0x182f>
    6be2:      	jmp	0x76bd <generic_tracepoint_arg+0x183d>
    6be7:      	movq	%r11, %rbp
    6bea:      	movzbl	0x10(%r13), %eax
    6bef:      	movl	%eax, 0x70(%rsp)
    6bf3:      	movl	$0x1, %eax
    6bf8:      	movq	0x28(%rsp), %rsi
    6bfd:      	movq	(%rip), %rdi            # 0x6c04 <generic_tracepoint_arg+0xd84>
    6c04:      	callq	*%rax
    6c06:      	testq	%rax, %rax
    6c09:      	je	0x78be <generic_tracepoint_arg+0x1a3e>
    6c0f:      	movq	%rax, %rdi
    6c12:      	movl	(%r12), %eax
    6c16:      	movq	%rax, 0x38(%rsp)
    6c1b:      	movl	$0x1, %eax
    6c20:      	leaq	0x38(%rsp), %rsi
    6c25:      	jmp	0x7885 <generic_tracepoint_arg+0x1a05>
    6c2a:      	movzwl	(%r12), %edx
    6c2f:      	movw	%dx, 0x5e(%rsp)
    6c34:      	movzwl	0x2(%r12), %edx
    6c3a:      	movw	%dx, 0x58(%rsp)
    6c3f:      	movq	0x8(%r12), %rdx
    6c44:      	movq	%rdx, 0x38(%rsp)
    6c49:      	movq	0x10(%r12), %rdx
    6c4e:      	movq	%rdx, 0x40(%rsp)
    6c53:      	leaq	0x38(%rsp), %r12
    6c58:      	xorl	%edx, %edx
    6c5a:      	cmpl	$0x13, %eax
    6c5d:      	jle	0x6c86 <generic_tracepoint_arg+0xe06>
    6c5f:      	cmpl	$0x17, %eax
    6c62:      	jg	0x6cba <generic_tracepoint_arg+0xe3a>
    6c64:      	leal	-0x14(%rax), %ecx
    6c67:      	cmpl	$0x2, %ecx
    6c6a:      	jb	0x7239 <generic_tracepoint_arg+0x13b9>
    6c70:      	leal	-0x16(%rax), %ecx
    6c73:      	movl	$0x0, %ebx
    6c78:      	cmpl	$0x2, %ecx
    6c7b:      	jb	0x722e <generic_tracepoint_arg+0x13ae>
    6c81:      	jmp	0x6150 <generic_tracepoint_arg+0x2d0>
    6c86:      	cmpl	$0xf, %eax
    6c89:      	jle	0x6f20 <generic_tracepoint_arg+0x10a0>
    6c8f:      	cmpl	$0x11, %eax
    6c92:      	jg	0x721b <generic_tracepoint_arg+0x139b>
    6c98:      	cmpl	$0x10, %eax
    6c9b:      	je	0x722e <generic_tracepoint_arg+0x13ae>
    6ca1:      	movl	$0x0, %ebx
    6ca6:      	cmpl	$0x11, %eax
    6ca9:      	jne	0x6150 <generic_tracepoint_arg+0x2d0>
    6caf:      	movzwl	0x24(%r12), %ebx
    6cb5:      	jmp	0x7a32 <generic_tracepoint_arg+0x1bb2>
    6cba:      	cmpl	$0x1b, %eax
    6cbd:      	jg	0x727a <generic_tracepoint_arg+0x13fa>
    6cc3:      	cmpl	$0x18, %eax
    6cc6:      	je	0x72b9 <generic_tracepoint_arg+0x1439>
    6ccc:      	movl	$0x0, %ebx
    6cd1:      	cmpl	$0x19, %eax
    6cd4:      	je	0x72aa <generic_tracepoint_arg+0x142a>
    6cda:      	jmp	0x6150 <generic_tracepoint_arg+0x2d0>
    6cdf:      	cmpl	$0x21, %eax
    6ce2:      	je	0x738a <generic_tracepoint_arg+0x150a>
    6ce8:      	movl	$0x0, %ebx
    6ced:      	cmpl	$0x22, %eax
    6cf0:      	jne	0x94bb <generic_tracepoint_arg+0x363b>
    6cf6:      	xorl	%ebx, %ebx
    6cf8:      	xorl	%r12d, %r12d
    6cfb:      	movq	%r11, %r15
    6cfe:      	movl	0x10(%r13,%rbx,4), %eax
    6d03:      	movl	%eax, 0x38(%rsp)
    6d07:      	movl	$0x1, %eax
    6d0c:      	leaq	0x38(%rsp), %rsi
    6d11:      	movq	(%rip), %rdi            # 0x6d18 <generic_tracepoint_arg+0xe98>
    6d18:      	callq	*%rax
    6d1a:      	testq	%rax, %rax
    6d1d:      	je	0x8036 <generic_tracepoint_arg+0x21b6>
    6d23:      	testl	%ebp, %ebp
    6d25:      	movq	%r15, %r11
    6d28:      	movq	0x68(%rsp), %r15
    6d2d:      	je	0x6da4 <generic_tracepoint_arg+0xf24>
    6d2f:      	movq	0x18(%rsp), %rdx
    6d34:      	xorl	%ecx, %ecx
    6d36:      	jmp	0x6d43 <generic_tracepoint_arg+0xec3>
    6d38:      	incq	%rcx
    6d3b:      	incq	%rdx
    6d3e:      	cmpq	%rbp, %rcx
    6d41:      	je	0x6da4 <generic_tracepoint_arg+0xf24>
    6d43:      	xorl	%esi, %esi
    6d45:      	nopw	%cs:(%rax,%rax)
    6d50:      	leaq	(%rcx,%rsi), %rdi
    6d54:      	cmpq	%rbp, %rdi
    6d57:      	jae	0x6d38 <generic_tracepoint_arg+0xeb8>
    6d59:      	movsbl	(%rax,%rsi), %edi
    6d5d:      	testl	%edi, %edi
    6d5f:      	je	0x6d9c <generic_tracepoint_arg+0xf1c>
    6d61:      	movsbl	(%rdx,%rsi), %r9d
    6d66:      	leal	-0x41(%r9), %r10d
    6d6a:      	movl	%r9d, %r8d
    6d6d:      	orl	$0x20, %r8d
    6d71:      	cmpl	$0x1a, %r10d
    6d75:      	cmovael	%r9d, %r8d
    6d79:      	leal	-0x41(%rdi), %r10d
    6d7d:      	movl	%edi, %r9d
    6d80:      	orl	$0x20, %r9d
    6d84:      	cmpl	$0x1a, %r10d
    6d88:      	cmovael	%edi, %r9d
    6d8c:      	cmpq	$0x62, %rsi
    6d90:      	ja	0x6d38 <generic_tracepoint_arg+0xeb8>
    6d92:      	incq	%rsi
    6d95:      	cmpl	%r9d, %r8d
    6d98:      	je	0x6d50 <generic_tracepoint_arg+0xed0>
    6d9a:      	jmp	0x6d38 <generic_tracepoint_arg+0xeb8>
    6d9c:      	testl	%ecx, %ecx
    6d9e:      	jns	0x850e <generic_tracepoint_arg+0x268e>
    6da4:      	leal	0xc(%r12), %eax
    6da9:      	cmpl	0x8(%r13), %eax
    6dad:      	jae	0x6dc0 <generic_tracepoint_arg+0xf40>
    6daf:      	addl	$0x4, %r12d
    6db3:      	incq	%rbx
    6db6:      	cmpq	$0x64, %rbx
    6dba:      	jne	0x6cfb <generic_tracepoint_arg+0xe7b>
    6dc0:      	xorl	%ebx, %ebx
    6dc2:      	jmp	0x8513 <generic_tracepoint_arg+0x2693>
    6dc7:      	cmpl	$0xc, %eax
    6dca:      	jne	0x7b92 <generic_tracepoint_arg+0x1d12>
    6dd0:      	testq	%rdx, (%r12)
    6dd4:      	jne	0x6161 <generic_tracepoint_arg+0x2e1>
    6dda:      	jmp	0x7b92 <generic_tracepoint_arg+0x1d12>
    6ddf:      	leal	-0x1f(%rax), %edx
    6de2:      	cmpl	$0x2, %edx
    6de5:      	jae	0x76c7 <generic_tracepoint_arg+0x1847>
    6deb:      	cmpl	$0x1f, %eax
    6dee:      	jne	0x6f45 <generic_tracepoint_arg+0x10c5>
    6df4:      	movq	0x10(%r13), %rsi
    6df8:      	movq	0x18(%r13), %rdx
    6dfc:      	cmpl	$0xa, %ecx
    6dff:      	je	0x6e0a <generic_tracepoint_arg+0xf8a>
    6e01:      	cmpl	$0xc, %ecx
    6e04:      	jne	0x7992 <generic_tracepoint_arg+0x1b12>
    6e0a:      	movq	(%r12), %rax
    6e0e:      	cmpq	%rax, %rsi
    6e11:      	jg	0x79a4 <generic_tracepoint_arg+0x1b24>
    6e17:      	cmpq	%rdx, %rax
    6e1a:      	jle	0x6161 <generic_tracepoint_arg+0x2e1>
    6e20:      	jmp	0x79a4 <generic_tracepoint_arg+0x1b24>
    6e25:      	movq	%r11, 0x10(%rsp)
    6e2a:      	movl	0x10(%r13), %eax
    6e2e:      	movl	%eax, 0x38(%rsp)
    6e32:      	movl	$0x0, 0x70(%rsp)
    6e3a:      	movl	$0x1, %eax
    6e3f:      	leaq	0x38(%rsp), %rsi
    6e44:      	movq	(%rip), %rdi            # 0x6e4b <generic_tracepoint_arg+0xfcb>
    6e4b:      	callq	*%rax
    6e4d:      	testl	%ebp, %ebp
    6e4f:      	je	0x94ab <generic_tracepoint_arg+0x362b>
    6e55:      	movq	%rax, %r12
    6e58:      	movl	$0x0, %ebx
    6e5d:      	testq	%rax, %rax
    6e60:      	je	0x94ad <generic_tracepoint_arg+0x362d>
    6e66:      	movl	$0x1, %eax
    6e6b:      	movq	0x28(%rsp), %rsi
    6e70:      	movq	(%rip), %rdi            # 0x6e77 <generic_tracepoint_arg+0xff7>
    6e77:      	callq	*%rax
    6e79:      	testq	%rax, %rax
    6e7c:      	je	0x94ab <generic_tracepoint_arg+0x362b>
    6e82:      	cmpl	$0xff, %ebp
    6e88:      	movl	$0xff, %ecx
    6e8d:      	cmovael	%ecx, %ebp
    6e90:      	leal	(,%rbp,8), %ecx
    6e97:      	movl	%ecx, (%rax)
    6e99:      	movq	%rax, %rdi
    6e9c:      	addq	$0x4, %rdi
    6ea0:      	movq	%rax, %rbx
    6ea3:      	movl	$0x4, %eax
    6ea8:      	movq	0x18(%rsp), %rdx
    6ead:      	movl	%ebp, %esi
    6eaf:      	callq	*%rax
    6eb1:      	movl	$0x1, %eax
    6eb6:      	jmp	0x7962 <generic_tracepoint_arg+0x1ae2>
    6ebb:      	movl	$0x0, 0x70(%rsp)
    6ec3:      	cmpl	$0x1000, %ebp           # imm = 0x1000
    6ec9:      	ja	0x798b <generic_tracepoint_arg+0x1b0b>
    6ecf:      	movzwl	%bp, %eax
    6ed2:      	cmpl	$0x90, %eax
    6ed7:      	ja	0x7b14 <generic_tracepoint_arg+0x1c94>
    6edd:      	testw	%bp, %bp
    6ee0:      	je	0x6ef2 <generic_tracepoint_arg+0x1072>
    6ee2:      	movl	%ebp, %eax
    6ee4:      	movl	$0x18, %ecx
    6ee9:      	cltd
    6eea:      	idivl	%ecx
    6eec:      	movl	%ebp, %esi
    6eee:      	testl	%edx, %edx
    6ef0:      	je	0x6f14 <generic_tracepoint_arg+0x1094>
    6ef2:      	movl	%ebp, %eax
    6ef4:      	movl	$0x18, %ecx
    6ef9:      	cltd
    6efa:      	idivl	%ecx
    6efc:      	shll	$0x3, %eax
    6eff:      	leal	(%rax,%rax,2), %eax
    6f02:      	addl	$0x18, %eax
    6f05:      	movzwl	%ax, %esi
    6f08:      	cmpl	$0x90, %esi
    6f0e:      	ja	0x7b4c <generic_tracepoint_arg+0x1ccc>
    6f14:      	movl	%esi, %eax
    6f16:      	cltd
    6f17:      	idivl	%ecx
    6f19:      	decl	%eax
    6f1b:      	jmp	0x875c <generic_tracepoint_arg+0x28dc>
    6f20:      	cmpl	$0xd, %eax
    6f23:      	je	0x72b9 <generic_tracepoint_arg+0x1439>
    6f29:      	cmpl	$0xe, %eax
    6f2c:      	je	0x72aa <generic_tracepoint_arg+0x142a>
    6f32:      	movl	$0x0, %ebx
    6f37:      	cmpl	$0xf, %eax
    6f3a:      	je	0x7239 <generic_tracepoint_arg+0x13b9>
    6f40:      	jmp	0x6150 <generic_tracepoint_arg+0x2d0>
    6f45:      	movq	0x10(%r13), %rsi
    6f49:      	movq	0x18(%r13), %rax
    6f4d:      	cmpl	$0xc, %ecx
    6f50:      	je	0x6f5b <generic_tracepoint_arg+0x10db>
    6f52:      	cmpl	$0xa, %ecx
    6f55:      	jne	0x79e2 <generic_tracepoint_arg+0x1b62>
    6f5b:      	movq	(%r12), %rdx
    6f5f:      	cmpq	%rdx, %rsi
    6f62:      	setle	%sil
    6f66:      	cmpq	%rax, %rdx
    6f69:      	setle	%al
    6f6c:      	jmp	0x79f3 <generic_tracepoint_arg+0x1b73>
    6f71:      	cmpl	$0xc, %eax
    6f74:      	jne	0x80a7 <generic_tracepoint_arg+0x2227>
    6f7a:      	testl	%edx, (%r12)
    6f7e:      	jne	0x6161 <generic_tracepoint_arg+0x2e1>
    6f84:      	jmp	0x80a7 <generic_tracepoint_arg+0x2227>
    6f89:      	movl	$0xc00, %edx            # imm = 0xC00
    6f8e:      	btq	%rcx, %rdx
    6f92:      	jb	0x74fb <generic_tracepoint_arg+0x167b>
    6f98:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
    6fa2:      	btq	%rcx, %rdx
    6fa6:      	jae	0x5f9d <generic_tracepoint_arg+0x11d>
    6fac:      	cmpl	$0x1f, %eax
    6faf:      	jne	0x7c7d <generic_tracepoint_arg+0x1dfd>
    6fb5:      	movzbl	(%r12), %eax
    6fba:      	jmp	0x6fed <generic_tracepoint_arg+0x116d>
    6fbc:      	movl	$0xc00, %edx            # imm = 0xC00
    6fc1:      	btq	%rcx, %rdx
    6fc5:      	jb	0x753f <generic_tracepoint_arg+0x16bf>
    6fcb:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
    6fd5:      	btq	%rcx, %rdx
    6fd9:      	jae	0x5f9d <generic_tracepoint_arg+0x11d>
    6fdf:      	cmpl	$0x1f, %eax
    6fe2:      	jne	0x7c88 <generic_tracepoint_arg+0x1e08>
    6fe8:      	movzwl	(%r12), %eax
    6fed:      	cmpl	%eax, 0x10(%r13)
    6ff1:      	ja	0x6ffd <generic_tracepoint_arg+0x117d>
    6ff3:      	cmpl	%eax, 0x14(%r13)
    6ff7:      	jae	0x6161 <generic_tracepoint_arg+0x2e1>
    6ffd:      	movl	0x8(%r13), %ecx
    7001:      	cmpl	$0x11, %ecx
    7004:      	jb	0x5f9d <generic_tracepoint_arg+0x11d>
    700a:      	cmpl	%eax, 0x18(%r13)
    700e:      	ja	0x701a <generic_tracepoint_arg+0x119a>
    7010:      	cmpl	%eax, 0x1c(%r13)
    7014:      	jae	0x6161 <generic_tracepoint_arg+0x2e1>
    701a:      	cmpl	$0x19, %ecx
    701d:      	jb	0x5f9d <generic_tracepoint_arg+0x11d>
    7023:      	cmpl	%eax, 0x20(%r13)
    7027:      	ja	0x7033 <generic_tracepoint_arg+0x11b3>
    7029:      	cmpl	%eax, 0x24(%r13)
    702d:      	jae	0x6161 <generic_tracepoint_arg+0x2e1>
    7033:      	cmpl	$0x21, %ecx
    7036:      	jb	0x5f9d <generic_tracepoint_arg+0x11d>
    703c:      	cmpl	%eax, 0x28(%r13)
    7040:      	ja	0x5f9d <generic_tracepoint_arg+0x11d>
    7046:      	cmpl	%eax, 0x2c(%r13)
    704a:      	jae	0x6161 <generic_tracepoint_arg+0x2e1>
    7050:      	jmp	0x5f9d <generic_tracepoint_arg+0x11d>
    7055:      	cmpl	$0xc, %ecx
    7058:      	je	0x7063 <generic_tracepoint_arg+0x11e3>
    705a:      	cmpl	$0xa, %ecx
    705d:      	jne	0x7b7c <generic_tracepoint_arg+0x1cfc>
    7063:      	cmpq	%rdx, (%r12)
    7067:      	jg	0x6161 <generic_tracepoint_arg+0x2e1>
    706d:      	jmp	0x7b92 <generic_tracepoint_arg+0x1d12>
    7072:      	cmpl	$0x20, %eax
    7075:      	jg	0x770d <generic_tracepoint_arg+0x188d>
    707b:      	cmpl	$0x1a, %eax
    707e:      	je	0x78d1 <generic_tracepoint_arg+0x1a51>
    7084:      	movl	$0x0, %ebx
    7089:      	cmpl	$0x1b, %eax
    708c:      	jne	0x94bb <generic_tracepoint_arg+0x363b>
    7092:      	movq	%r11, 0x10(%rsp)
    7097:      	movl	0x10(%r13), %eax
    709b:      	movl	%eax, 0x38(%rsp)
    709f:      	movl	$0x0, 0x70(%rsp)
    70a7:      	movl	$0x1, %eax
    70ac:      	leaq	0x38(%rsp), %rsi
    70b1:      	movq	(%rip), %rdi            # 0x70b8 <generic_tracepoint_arg+0x1238>
    70b8:      	callq	*%rax
    70ba:      	testl	%ebp, %ebp
    70bc:      	je	0x94ab <generic_tracepoint_arg+0x362b>
    70c2:      	movq	%rax, %r12
    70c5:      	movl	$0x0, %ebx
    70ca:      	testq	%rax, %rax
    70cd:      	je	0x94ad <generic_tracepoint_arg+0x362d>
    70d3:      	movl	$0x1, %eax
    70d8:      	movq	0x28(%rsp), %rsi
    70dd:      	movq	(%rip), %rdi            # 0x70e4 <generic_tracepoint_arg+0x1264>
    70e4:      	callq	*%rax
    70e6:      	testq	%rax, %rax
    70e9:      	je	0x94ab <generic_tracepoint_arg+0x362b>
    70ef:      	movq	%rax, %rdi
    70f2:      	movq	%r12, 0x20(%rsp)
    70f7:      	cmpl	$0x7f, %ebp
    70fa:      	movl	$0x7f, %eax
    70ff:      	cmovbl	%ebp, %eax
    7102:      	shll	$0x3, %eax
    7105:      	movl	%eax, (%rdi)
    7107:      	movq	%rbp, %rax
    710a:      	negq	%rax
    710d:      	movl	$0x3, %ecx
    7112:      	subq	%rbp, %rcx
    7115:      	leal	-0x4(%rbp), %edx
    7118:      	movq	%rdi, 0x60(%rsp)
    711d:      	addq	$0x7, %rdi
    7121:      	movl	$0x2, %r8d
    7127:      	subq	%rbp, %r8
    712a:      	leal	-0x3(%rbp), %r9d
    712e:      	movl	$0x1, %r10d
    7134:      	subq	%rbp, %r10
    7137:      	leal	-0x2(%rbp), %r11d
    713b:      	decl	%ebp
    713d:      	xorl	%ebx, %ebx
    713f:      	movq	0x18(%rsp), %rsi
    7144:      	leal	(%rbx,%rbp), %r12d
    7148:      	andl	$0xfff, %r12d           # imm = 0xFFF
    714f:      	movzbl	(%rsi,%r12), %r12d
    7154:      	movb	%r12b, -0x3(%rdi)
    7158:      	cmpq	%rbx, %r10
    715b:      	je	0x71b5 <generic_tracepoint_arg+0x1335>
    715d:      	leal	(%r11,%rbx), %r12d
    7161:      	andl	$0xfff, %r12d           # imm = 0xFFF
    7168:      	movzbl	(%rsi,%r12), %r12d
    716d:      	movb	%r12b, -0x2(%rdi)
    7171:      	cmpq	%rbx, %r8
    7174:      	je	0x71b5 <generic_tracepoint_arg+0x1335>
    7176:      	leal	(%r9,%rbx), %r12d
    717a:      	andl	$0xfff, %r12d           # imm = 0xFFF
    7181:      	movzbl	(%rsi,%r12), %r12d
    7186:      	movb	%r12b, -0x1(%rdi)
    718a:      	cmpq	%rbx, %rcx
    718d:      	je	0x71b5 <generic_tracepoint_arg+0x1335>
    718f:      	cmpq	$-0x7c, %rbx
    7193:      	je	0x71b5 <generic_tracepoint_arg+0x1335>
    7195:      	leal	(%rdx,%rbx), %r12d
    7199:      	andl	$0xfff, %r12d           # imm = 0xFFF
    71a0:      	movzbl	(%rsi,%r12), %r12d
    71a5:      	movb	%r12b, (%rdi)
    71a8:      	addq	$-0x4, %rbx
    71ac:      	addq	$0x4, %rdi
    71b0:      	cmpq	%rbx, %rax
    71b3:      	jne	0x7144 <generic_tracepoint_arg+0x12c4>
    71b5:      	movl	$0x1, %eax
    71ba:      	movq	0x20(%rsp), %rdi
    71bf:      	movq	0x60(%rsp), %rsi
    71c4:      	jmp	0x7968 <generic_tracepoint_arg+0x1ae8>
    71c9:      	movl	0x10(%r13), %esi
    71cd:      	movl	0x14(%r13), %eax
    71d1:      	cmpl	$0xc, %ecx
    71d4:      	ja	0x7e1a <generic_tracepoint_arg+0x1f9a>
    71da:      	movl	$0x1402, %edx           # imm = 0x1402
    71df:      	btl	%ecx, %edx
    71e2:      	jae	0x7e1a <generic_tracepoint_arg+0x1f9a>
    71e8:      	movl	(%r12), %edx
    71ec:      	cmpl	%edx, %esi
    71ee:      	setle	%sil
    71f2:      	cmpl	%eax, %edx
    71f4:      	setle	%al
    71f7:      	jmp	0x7e29 <generic_tracepoint_arg+0x1fa9>
    71fc:      	cmpl	$0x1c, %eax
    71ff:      	je	0x784a <generic_tracepoint_arg+0x19ca>
    7205:      	movq	%r8, 0x18(%rsp)
    720a:      	movq	%rsi, %r12
    720d:      	cmpl	$0x1a, %eax
    7210:      	je	0x77b2 <generic_tracepoint_arg+0x1932>
    7216:      	jmp	0x5f9d <generic_tracepoint_arg+0x11d>
    721b:      	cmpl	$0x12, %eax
    721e:      	je	0x7239 <generic_tracepoint_arg+0x13b9>
    7220:      	movl	$0x0, %ebx
    7225:      	cmpl	$0x13, %eax
    7228:      	jne	0x6150 <generic_tracepoint_arg+0x2d0>
    722e:      	movq	%r12, %rdx
    7231:      	movzwl	0x22(%r12), %r12d
    7237:      	jmp	0x7242 <generic_tracepoint_arg+0x13c2>
    7239:      	movq	%r12, %rdx
    723c:      	movzwl	0x20(%r12), %r12d
    7242:      	xorl	%esi, %esi
    7244:      	xorl	%ebp, %ebp
    7246:      	xorl	%r8d, %r8d
    7249:      	xorl	%ebx, %ebx
    724b:      	cmpl	$0x11, %eax
    724e:      	jg	0x72da <generic_tracepoint_arg+0x145a>
    7254:      	leal	-0xd(%rax), %ecx
    7257:      	cmpl	$0x2, %ecx
    725a:      	jb	0x730d <generic_tracepoint_arg+0x148d>
    7260:      	leal	-0xf(%rax), %ecx
    7263:      	cmpl	$0x2, %ecx
    7266:      	jb	0x7440 <generic_tracepoint_arg+0x15c0>
    726c:      	cmpl	$0x11, %eax
    726f:      	je	0x7a32 <generic_tracepoint_arg+0x1bb2>
    7275:      	jmp	0x6150 <generic_tracepoint_arg+0x2d0>
    727a:      	cmpl	$0x1c, %eax
    727d:      	je	0x7a2c <generic_tracepoint_arg+0x1bac>
    7283:      	movl	$0x0, %ebx
    7288:      	cmpl	$0x1d, %eax
    728b:      	jne	0x6150 <generic_tracepoint_arg+0x2d0>
    7291:      	cmpl	$0x7, %ecx
    7294:      	jne	0x7fc8 <generic_tracepoint_arg+0x2148>
    729a:      	testq	%rdx, %rdx
    729d:      	jne	0x7fd4 <generic_tracepoint_arg+0x2154>
    72a3:      	xorl	%ebx, %ebx
    72a5:      	jmp	0x7fe6 <generic_tracepoint_arg+0x2166>
    72aa:      	movq	0x10(%r12), %rsi
    72af:      	movq	%r12, %rdx
    72b2:      	movq	0x18(%r12), %r8
    72b7:      	jmp	0x72c5 <generic_tracepoint_arg+0x1445>
    72b9:      	movq	(%r12), %rsi
    72bd:      	movq	%r12, %rdx
    72c0:      	movq	0x8(%r12), %r8
    72c5:      	movq	%rsi, %rbp
    72c8:      	shrq	$0x20, %rbp
    72cc:      	xorl	%r12d, %r12d
    72cf:      	xorl	%ebx, %ebx
    72d1:      	cmpl	$0x11, %eax
    72d4:      	jle	0x7254 <generic_tracepoint_arg+0x13d4>
    72da:      	cmpl	$0x19, %eax
    72dd:      	ja	0x7434 <generic_tracepoint_arg+0x15b4>
    72e3:      	movl	$0x500000, %ecx         # imm = 0x500000
    72e8:      	btl	%eax, %ecx
    72eb:      	jb	0x7583 <generic_tracepoint_arg+0x1703>
    72f1:      	movl	$0xa00000, %ecx         # imm = 0xA00000
    72f6:      	btl	%eax, %ecx
    72f9:      	jb	0x7596 <generic_tracepoint_arg+0x1716>
    72ff:      	movl	$0x3000000, %ecx        # imm = 0x3000000
    7304:      	btl	%eax, %ecx
    7307:      	jae	0x7434 <generic_tracepoint_arg+0x15b4>
    730d:      	movzwl	0x26(%rdx), %eax
    7311:      	cmpl	$0xa, %eax
    7314:      	je	0x762b <generic_tracepoint_arg+0x17ab>
    731a:      	cmpl	$0x2, %eax
    731d:      	jne	0x76bd <generic_tracepoint_arg+0x183d>
    7323:      	movq	%rsi, %r12
    7326:      	movq	%r11, 0x10(%rsp)
    732b:      	movl	0x10(%r13), %eax
    732f:      	movl	%eax, 0x34(%rsp)
    7333:      	movl	$0x1, %eax
    7338:      	leaq	0x34(%rsp), %rsi
    733d:      	movq	(%rip), %rdi            # 0x7344 <generic_tracepoint_arg+0x14c4>
    7344:      	callq	*%rax
    7346:      	testq	%rax, %rax
    7349:      	je	0x7ae9 <generic_tracepoint_arg+0x1c69>
    734f:      	movq	%rax, %rdi
    7352:      	movl	$0x20, 0x70(%rsp)
    735a:      	movl	%r12d, 0x74(%rsp)
    735f:      	jmp	0x767d <generic_tracepoint_arg+0x17fd>
    7364:      	cmpl	$0xc, %ecx
    7367:      	ja	0x8091 <generic_tracepoint_arg+0x2211>
    736d:      	movl	$0x1402, %esi           # imm = 0x1402
    7372:      	btl	%ecx, %esi
    7375:      	jae	0x8091 <generic_tracepoint_arg+0x2211>
    737b:      	cmpl	%edx, (%r12)
    737f:      	jg	0x6161 <generic_tracepoint_arg+0x2e1>
    7385:      	jmp	0x80a7 <generic_tracepoint_arg+0x2227>
    738a:      	xorl	%ebx, %ebx
    738c:      	xorl	%r12d, %r12d
    738f:      	movq	%r11, %r15
    7392:      	movl	0x10(%r13,%rbx,4), %eax
    7397:      	movl	%eax, 0x38(%rsp)
    739b:      	movl	$0x1, %eax
    73a0:      	leaq	0x38(%rsp), %rsi
    73a5:      	movq	(%rip), %rdi            # 0x73ac <generic_tracepoint_arg+0x152c>
    73ac:      	callq	*%rax
    73ae:      	testq	%rax, %rax
    73b1:      	je	0x7f14 <generic_tracepoint_arg+0x2094>
    73b7:      	testl	%ebp, %ebp
    73b9:      	movq	0x8(%rsp), %r9
    73be:      	movq	%r15, %r11
    73c1:      	movq	0x68(%rsp), %r15
    73c6:      	je	0x740f <generic_tracepoint_arg+0x158f>
    73c8:      	movq	0x18(%rsp), %rdx
    73cd:      	xorl	%ecx, %ecx
    73cf:      	jmp	0x73dc <generic_tracepoint_arg+0x155c>
    73d1:      	incq	%rcx
    73d4:      	incq	%rdx
    73d7:      	cmpq	%rbp, %rcx
    73da:      	je	0x740f <generic_tracepoint_arg+0x158f>
    73dc:      	xorl	%esi, %esi
    73de:      	nop
    73e0:      	leaq	(%rcx,%rsi), %rdi
    73e4:      	cmpq	%rbp, %rdi
    73e7:      	jae	0x73d1 <generic_tracepoint_arg+0x1551>
    73e9:      	movzbl	(%rax,%rsi), %edi
    73ed:      	testb	%dil, %dil
    73f0:      	je	0x7407 <generic_tracepoint_arg+0x1587>
    73f2:      	cmpq	$0x62, %rsi
    73f6:      	ja	0x73d1 <generic_tracepoint_arg+0x1551>
    73f8:      	leaq	0x1(%rsi), %r8
    73fc:      	cmpb	%dil, (%rdx,%rsi)
    7400:      	movq	%r8, %rsi
    7403:      	je	0x73e0 <generic_tracepoint_arg+0x1560>
    7405:      	jmp	0x73d1 <generic_tracepoint_arg+0x1551>
    7407:      	testl	%ecx, %ecx
    7409:      	jns	0x819a <generic_tracepoint_arg+0x231a>
    740f:      	leal	0xc(%r12), %eax
    7414:      	cmpl	0x8(%r13), %eax
    7418:      	jae	0x8d17 <generic_tracepoint_arg+0x2e97>
    741e:      	addl	$0x4, %r12d
    7422:      	incq	%rbx
    7425:      	cmpq	$0x64, %rbx
    7429:      	jne	0x738f <generic_tracepoint_arg+0x150f>
    742f:      	jmp	0x8d17 <generic_tracepoint_arg+0x2e97>
    7434:      	addl	$-0x12, %eax
    7437:      	cmpl	$0x2, %eax
    743a:      	jae	0x6150 <generic_tracepoint_arg+0x2d0>
    7440:      	movq	%r11, %rbp
    7443:      	movzbl	0x10(%r13), %eax
    7448:      	movl	%eax, 0x34(%rsp)
    744c:      	movl	$0x1, %eax
    7451:      	movq	(%rip), %rdi            # 0x7458 <generic_tracepoint_arg+0x15d8>
    7458:      	leaq	0x34(%rsp), %rsi
    745d:      	callq	*%rax
    745f:      	testq	%rax, %rax
    7462:      	je	0x78be <generic_tracepoint_arg+0x1a3e>
    7468:      	movq	%rax, %rdi
    746b:      	movzwl	%r12w, %eax
    746f:      	movq	%rax, 0x70(%rsp)
    7474:      	movl	$0x1, %eax
    7479:      	movq	0x28(%rsp), %rsi
    747e:      	jmp	0x7885 <generic_tracepoint_arg+0x1a05>
    7483:      	leal	-0x100(%rbx), %eax
    7489:      	rorxl	$0x8, %eax, %eax
    748f:      	cmpl	$0x2, %eax
    7492:      	jg	0x7c44 <generic_tracepoint_arg+0x1dc4>
    7498:      	testl	%eax, %eax
    749a:      	je	0x835d <generic_tracepoint_arg+0x24dd>
    74a0:      	cmpl	$0x1, %eax
    74a3:      	jne	0x8356 <generic_tracepoint_arg+0x24d6>
    74a9:      	movl	$0x7, %eax
    74ae:      	jmp	0x8369 <generic_tracepoint_arg+0x24e9>
    74b3:      	cmpl	$0x1, %eax
    74b6:      	je	0x7d39 <generic_tracepoint_arg+0x1eb9>
    74bc:      	cmpl	$0x2, %eax
    74bf:      	jne	0x7d46 <generic_tracepoint_arg+0x1ec6>
    74c5:      	movzbl	(%r12), %edx
    74ca:      	cmpl	%edx, %ecx
    74cc:      	ja	0x6161 <generic_tracepoint_arg+0x2e1>
    74d2:      	jmp	0x7d46 <generic_tracepoint_arg+0x1ec6>
    74d7:      	cmpl	$0x1, %eax
    74da:      	je	0x7d7e <generic_tracepoint_arg+0x1efe>
    74e0:      	cmpl	$0x2, %eax
    74e3:      	jne	0x7d8b <generic_tracepoint_arg+0x1f0b>
    74e9:      	movzwl	(%r12), %edx
    74ee:      	cmpl	%edx, %ecx
    74f0:      	ja	0x6161 <generic_tracepoint_arg+0x2e1>
    74f6:      	jmp	0x7d8b <generic_tracepoint_arg+0x1f0b>
    74fb:      	movq	%r11, %rbp
    74fe:      	movzbl	0x10(%r13), %eax
    7503:      	movl	%eax, 0x70(%rsp)
    7507:      	movl	$0x1, %eax
    750c:      	movq	0x28(%rsp), %rsi
    7511:      	movq	(%rip), %rdi            # 0x7518 <generic_tracepoint_arg+0x1698>
    7518:      	callq	*%rax
    751a:      	testq	%rax, %rax
    751d:      	je	0x78be <generic_tracepoint_arg+0x1a3e>
    7523:      	movq	%rax, %rdi
    7526:      	movzbl	(%r12), %eax
    752b:      	movq	%rax, 0x38(%rsp)
    7530:      	movl	$0x1, %eax
    7535:      	leaq	0x38(%rsp), %rsi
    753a:      	jmp	0x7885 <generic_tracepoint_arg+0x1a05>
    753f:      	movq	%r11, %rbp
    7542:      	movzbl	0x10(%r13), %eax
    7547:      	movl	%eax, 0x70(%rsp)
    754b:      	movl	$0x1, %eax
    7550:      	movq	0x28(%rsp), %rsi
    7555:      	movq	(%rip), %rdi            # 0x755c <generic_tracepoint_arg+0x16dc>
    755c:      	callq	*%rax
    755e:      	testq	%rax, %rax
    7561:      	je	0x78be <generic_tracepoint_arg+0x1a3e>
    7567:      	movq	%rax, %rdi
    756a:      	movzwl	(%r12), %eax
    756f:      	movq	%rax, 0x38(%rsp)
    7574:      	movl	$0x1, %eax
    7579:      	leaq	0x38(%rsp), %rsi
    757e:      	jmp	0x7885 <generic_tracepoint_arg+0x1a05>
    7583:      	movzwl	%r12w, %eax
    7587:      	xorl	%ebx, %ebx
    7589:      	cmpl	$0x400, %eax            # imm = 0x400
    758e:      	setb	%bl
    7591:      	jmp	0x6150 <generic_tracepoint_arg+0x2d0>
    7596:      	movzwl	%r12w, %eax
    759a:      	xorl	%ebx, %ebx
    759c:      	cmpl	$0x400, %eax            # imm = 0x400
    75a1:      	setae	%bl
    75a4:      	jmp	0x6150 <generic_tracepoint_arg+0x2d0>
    75a9:      	testq	%rax, %rax
    75ac:      	sete	%al
    75af:      	movq	(%rsp), %rdi
    75b3:      	movq	0x8(%rsp), %r9
    75b8:      	movq	%rbp, %r11
    75bb:      	movzbl	%al, %ebx
    75be:      	jmp	0x6150 <generic_tracepoint_arg+0x2d0>
    75c3:      	movl	$0x100, %esi            # imm = 0x100
    75c8:      	cmpl	$0x101, %eax            # imm = 0x101
    75cd:      	jb	0x75fb <generic_tracepoint_arg+0x177b>
    75cf:      	movl	$0x200, %esi            # imm = 0x200
    75d4:      	cmpl	$0x201, %eax            # imm = 0x201
    75d9:      	jb	0x75fb <generic_tracepoint_arg+0x177b>
    75db:      	movl	$0x400, %esi            # imm = 0x400
    75e0:      	cmpl	$0x401, %eax            # imm = 0x401
    75e5:      	jb	0x75fb <generic_tracepoint_arg+0x177b>
    75e7:      	xorl	%esi, %esi
    75e9:      	cmpl	$0x801, %eax            # imm = 0x801
    75ee:      	setae	%sil
    75f2:      	shll	$0xb, %esi
    75f5:      	addl	$0x800, %esi            # imm = 0x800
    75fb:      	leal	-0x100(%rsi), %eax
    7601:      	rorxl	$0x8, %eax, %eax
    7607:      	cmpl	$0x2, %eax
    760a:      	jg	0x7af8 <generic_tracepoint_arg+0x1c78>
    7610:      	testl	%eax, %eax
    7612:      	je	0x81c3 <generic_tracepoint_arg+0x2343>
    7618:      	cmpl	$0x1, %eax
    761b:      	jne	0x81bc <generic_tracepoint_arg+0x233c>
    7621:      	movl	$0x7, %eax
    7626:      	jmp	0x81cf <generic_tracepoint_arg+0x234f>
    762b:      	movq	%r8, %rbx
    762e:      	movq	%rsi, %r12
    7631:      	movq	%r11, 0x10(%rsp)
    7636:      	movl	0x14(%r13), %eax
    763a:      	movl	%eax, 0x34(%rsp)
    763e:      	movl	$0x1, %eax
    7643:      	movq	(%rip), %rdi            # 0x764a <generic_tracepoint_arg+0x17ca>
    764a:      	leaq	0x34(%rsp), %rsi
    764f:      	callq	*%rax
    7651:      	testq	%rax, %rax
    7654:      	je	0x7ae9 <generic_tracepoint_arg+0x1c69>
    765a:      	movq	%rax, %rdi
    765d:      	movl	$0x80, 0x70(%rsp)
    7665:      	movl	%r12d, 0x74(%rsp)
    766a:      	movl	%ebp, 0x78(%rsp)
    766e:      	movl	%ebx, 0x7c(%rsp)
    7672:      	shrq	$0x20, %rbx
    7676:      	movl	%ebx, 0x80(%rsp)
    767d:      	movl	$0x1, %eax
    7682:      	movq	0x28(%rsp), %rsi
    7687:      	callq	*%rax
    7689:      	movl	0x4(%r13), %ecx
    768d:      	leal	-0x18(%rcx), %edx
    7690:      	cmpl	$0x2, %edx
    7693:      	jb	0x7d01 <generic_tracepoint_arg+0x1e81>
    7699:      	addl	$-0xd, %ecx
    769c:      	cmpl	$0x1, %ecx
    769f:      	movq	(%rsp), %rdi
    76a3:      	movq	0x8(%rsp), %r9
    76a8:      	movq	0x10(%rsp), %r11
    76ad:      	ja	0x76bd <generic_tracepoint_arg+0x183d>
    76af:      	testq	%rax, %rax
    76b2:      	setne	%al
    76b5:      	movzbl	%al, %ebx
    76b8:      	jmp	0x6150 <generic_tracepoint_arg+0x2d0>
    76bd:      	xorl	%eax, %eax
    76bf:      	movzbl	%al, %ebx
    76c2:      	jmp	0x6150 <generic_tracepoint_arg+0x2d0>
    76c7:      	cmpl	$0x1e, %eax
    76ca:      	jne	0x5f9d <generic_tracepoint_arg+0x11d>
    76d0:      	movl	0x10(%r13), %eax
    76d4:      	andl	$0x7, %eax
    76d7:      	movl	%eax, %ecx
    76d9:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
    76e2:      	jne	0x5f9d <generic_tracepoint_arg+0x11d>
    76e8:      	movq	(%r12), %rcx
    76ec:      	movq	0x5e78(%r14,%rax,8), %rax
    76f4:      	andl	$0x7ff, %eax            # imm = 0x7FF
    76f9:      	xorl	%ebx, %ebx
    76fb:      	andnq	0x90(%r14,%rax), %rcx, %rax
    7705:      	setne	%bl
    7708:      	jmp	0x6150 <generic_tracepoint_arg+0x2d0>
    770d:      	cmpl	$0x21, %eax
    7710:      	je	0x7e6c <generic_tracepoint_arg+0x1fec>
    7716:      	movl	$0x0, %ebx
    771b:      	cmpl	$0x22, %eax
    771e:      	jne	0x94bb <generic_tracepoint_arg+0x363b>
    7724:      	movl	$0x10, %r12d
    772a:      	movq	%r11, %r15
    772d:      	movl	(%r13,%r12), %eax
    7732:      	movl	%eax, 0x38(%rsp)
    7736:      	movl	$0x1, %eax
    773b:      	leaq	0x38(%rsp), %rsi
    7740:      	movq	(%rip), %rdi            # 0x7747 <generic_tracepoint_arg+0x18c7>
    7747:      	callq	*%rax
    7749:      	testq	%rax, %rax
    774c:      	je	0x8b04 <generic_tracepoint_arg+0x2c84>
    7752:      	movq	0x18(%rsp), %rdi
    7757:      	movq	%rax, %rsi
    775a:      	movq	%rbp, %rdx
    775d:      	callq	0x7762 <generic_tracepoint_arg+0x18e2>
    7762:      	testl	%eax, %eax
    7764:      	jns	0x8b08 <generic_tracepoint_arg+0x2c88>
    776a:      	addq	$0x4, %r12
    776e:      	leal	-0x8(%r12), %eax
    7773:      	cmpl	0x8(%r13), %eax
    7777:      	movq	(%rsp), %rdi
    777b:      	movq	0x8(%rsp), %r9
    7780:      	movq	%r15, %r11
    7783:      	jae	0x8c3d <generic_tracepoint_arg+0x2dbd>
    7789:      	movl	$0x0, %ebx
    778e:      	cmpq	$0x1a0, %r12            # imm = 0x1A0
    7795:      	movq	0x68(%rsp), %r15
    779a:      	jne	0x772a <generic_tracepoint_arg+0x18aa>
    779c:      	jmp	0x94bb <generic_tracepoint_arg+0x363b>
    77a1:      	movq	%r8, 0x18(%rsp)
    77a6:      	movq	%rsi, %r12
    77a9:      	cmpl	$0x8, %eax
    77ac:      	jne	0x5f9d <generic_tracepoint_arg+0x11d>
    77b2:      	movq	%r11, 0x10(%rsp)
    77b7:      	movl	0x10(%r13), %eax
    77bb:      	movl	%eax, 0x38(%rsp)
    77bf:      	movl	$0x0, 0x70(%rsp)
    77c7:      	movl	$0x1, %eax
    77cc:      	leaq	0x38(%rsp), %rsi
    77d1:      	movq	(%rip), %rdi            # 0x77d8 <generic_tracepoint_arg+0x1958>
    77d8:      	callq	*%rax
    77da:      	testb	%bpl, %bpl
    77dd:      	je	0x7ab2 <generic_tracepoint_arg+0x1c32>
    77e3:      	movl	$0x0, %ebx
    77e8:      	testq	%rax, %rax
    77eb:      	je	0x7ab4 <generic_tracepoint_arg+0x1c34>
    77f1:      	movq	%rax, %rbp
    77f4:      	movl	$0x1, %eax
    77f9:      	movq	0x28(%rsp), %rsi
    77fe:      	movq	(%rip), %rdi            # 0x7805 <generic_tracepoint_arg+0x1985>
    7805:      	callq	*%rax
    7807:      	testq	%rax, %rax
    780a:      	je	0x7ab2 <generic_tracepoint_arg+0x1c32>
    7810:      	movq	%r12, %rsi
    7813:      	movl	%esi, %ecx
    7815:      	shll	$0x3, %ecx
    7818:      	movl	%ecx, (%rax)
    781a:      	movq	%rax, %rdi
    781d:      	addq	$0x4, %rdi
    7821:      	movq	%rax, %rbx
    7824:      	movl	$0x4, %eax
    7829:      	movq	0x18(%rsp), %rdx
    782e:      	callq	*%rax
    7830:      	movl	$0x1, %eax
    7835:      	movq	%rbp, %rdi
    7838:      	movq	%rbx, %rsi
    783b:      	callq	*%rax
    783d:      	xorl	%ebx, %ebx
    783f:      	testq	%rax, %rax
    7842:      	setne	%bl
    7845:      	jmp	0x7ab4 <generic_tracepoint_arg+0x1c34>
    784a:      	movq	%r11, %rbp
    784d:      	movzwl	(%r12), %ebx
    7852:      	movzbl	0x10(%r13), %eax
    7857:      	movl	%eax, 0x70(%rsp)
    785b:      	movl	$0x1, %eax
    7860:      	movq	0x28(%rsp), %rsi
    7865:      	movq	(%rip), %rdi            # 0x786c <generic_tracepoint_arg+0x19ec>
    786c:      	callq	*%rax
    786e:      	testq	%rax, %rax
    7871:      	je	0x78be <generic_tracepoint_arg+0x1a3e>
    7873:      	movq	%rax, %rdi
    7876:      	movq	%rbx, 0x38(%rsp)
    787b:      	movl	$0x1, %eax
    7880:      	leaq	0x38(%rsp), %rsi
    7885:      	callq	*%rax
    7887:      	movl	0x4(%r13), %edx
    788b:      	xorl	%ecx, %ecx
    788d:      	cmpl	$0x1d, %edx
    7890:      	ja	0x81a8 <generic_tracepoint_arg+0x2328>
    7896:      	movl	$0x30038400, %esi       # imm = 0x30038400
    789b:      	btl	%edx, %esi
    789e:      	movq	(%rsp), %rdi
    78a2:      	movq	0x8(%rsp), %r9
    78a7:      	movq	%rbp, %r11
    78aa:      	jae	0x7a9a <generic_tracepoint_arg+0x1c1a>
    78b0:      	testq	%rax, %rax
    78b3:      	setne	%cl
    78b6:      	movzbl	%cl, %ebx
    78b9:      	jmp	0x6150 <generic_tracepoint_arg+0x2d0>
    78be:      	xorl	%ebx, %ebx
    78c0:      	movq	(%rsp), %rdi
    78c4:      	movq	0x8(%rsp), %r9
    78c9:      	movq	%rbp, %r11
    78cc:      	jmp	0x6150 <generic_tracepoint_arg+0x2d0>
    78d1:      	movq	%r11, 0x10(%rsp)
    78d6:      	movl	0x10(%r13), %eax
    78da:      	movl	%eax, 0x38(%rsp)
    78de:      	movl	$0x0, 0x70(%rsp)
    78e6:      	movl	$0x1, %eax
    78eb:      	leaq	0x38(%rsp), %rsi
    78f0:      	movq	(%rip), %rdi            # 0x78f7 <generic_tracepoint_arg+0x1a77>
    78f7:      	callq	*%rax
    78f9:      	testl	%ebp, %ebp
    78fb:      	je	0x94ab <generic_tracepoint_arg+0x362b>
    7901:      	movq	%rax, %r12
    7904:      	movl	$0x0, %ebx
    7909:      	testq	%rax, %rax
    790c:      	je	0x94ad <generic_tracepoint_arg+0x362d>
    7912:      	movl	$0x1, %eax
    7917:      	movq	0x28(%rsp), %rsi
    791c:      	movq	(%rip), %rdi            # 0x7923 <generic_tracepoint_arg+0x1aa3>
    7923:      	callq	*%rax
    7925:      	testq	%rax, %rax
    7928:      	je	0x94ab <generic_tracepoint_arg+0x362b>
    792e:      	cmpl	$0xff, %ebp
    7934:      	movl	$0xff, %ecx
    7939:      	cmovael	%ecx, %ebp
    793c:      	leal	(,%rbp,8), %ecx
    7943:      	movl	%ecx, (%rax)
    7945:      	movq	%rax, %rdi
    7948:      	addq	$0x4, %rdi
    794c:      	movq	%rax, %rbx
    794f:      	movl	$0x4, %eax
    7954:      	movq	0x18(%rsp), %rdx
    7959:      	movl	%ebp, %esi
    795b:      	callq	*%rax
    795d:      	movl	$0x1, %eax
    7962:      	movq	%r12, %rdi
    7965:      	movq	%rbx, %rsi
    7968:      	callq	*%rax
    796a:      	xorl	%ebx, %ebx
    796c:      	testq	%rax, %rax
    796f:      	setne	%bl
    7972:      	jmp	0x94ad <generic_tracepoint_arg+0x362d>
    7977:      	movl	$0x0, 0x70(%rsp)
    797f:      	cmpl	$0x1000, %ebp           # imm = 0x1000
    7985:      	jbe	0x7f2c <generic_tracepoint_arg+0x20ac>
    798b:      	xorl	%ebx, %ebx
    798d:      	jmp	0x94bb <generic_tracepoint_arg+0x363b>
    7992:      	movq	(%r12), %rax
    7996:      	cmpq	%rax, %rsi
    7999:      	ja	0x79a4 <generic_tracepoint_arg+0x1b24>
    799b:      	cmpq	%rdx, %rax
    799e:      	jbe	0x6161 <generic_tracepoint_arg+0x2e1>
    79a4:      	movl	0x8(%r13), %edx
    79a8:      	cmpl	$0x19, %edx
    79ab:      	jb	0x5f9d <generic_tracepoint_arg+0x11d>
    79b1:      	movq	0x20(%r13), %rdi
    79b5:      	movq	0x28(%r13), %rsi
    79b9:      	cmpl	$0xc, %ecx
    79bc:      	je	0x79c7 <generic_tracepoint_arg+0x1b47>
    79be:      	cmpl	$0xa, %ecx
    79c1:      	jne	0x8045 <generic_tracepoint_arg+0x21c5>
    79c7:      	cmpq	%rax, %rdi
    79ca:      	movq	(%rsp), %rdi
    79ce:      	jg	0x8057 <generic_tracepoint_arg+0x21d7>
    79d4:      	cmpq	%rsi, %rax
    79d7:      	jle	0x6161 <generic_tracepoint_arg+0x2e1>
    79dd:      	jmp	0x8057 <generic_tracepoint_arg+0x21d7>
    79e2:      	movq	(%r12), %rdx
    79e6:      	cmpq	%rdx, %rsi
    79e9:      	setbe	%sil
    79ed:      	cmpq	%rax, %rdx
    79f0:      	setbe	%al
    79f3:      	andb	%sil, %al
    79f6:      	movl	0x8(%r13), %esi
    79fa:      	cmpl	$0x19, %esi
    79fd:      	jb	0x8ed0 <generic_tracepoint_arg+0x3050>
    7a03:      	movq	0x20(%r13), %r8
    7a07:      	movq	0x28(%r13), %rdi
    7a0b:      	cmpl	$0xc, %ecx
    7a0e:      	je	0x7a19 <generic_tracepoint_arg+0x1b99>
    7a10:      	cmpl	$0xa, %ecx
    7a13:      	jne	0x7f82 <generic_tracepoint_arg+0x2102>
    7a19:      	cmpq	%rdx, %r8
    7a1c:      	setle	%r8b
    7a20:      	cmpq	%rdi, %rdx
    7a23:      	setle	%dil
    7a27:      	jmp	0x7f90 <generic_tracepoint_arg+0x2110>
    7a2c:      	movzwl	0x26(%r12), %ebx
    7a32:      	movq	%r11, %r12
    7a35:      	movzbl	0x10(%r13), %eax
    7a3a:      	movl	%eax, 0x34(%rsp)
    7a3e:      	movl	$0x1, %eax
    7a43:      	movq	(%rip), %rdi            # 0x7a4a <generic_tracepoint_arg+0x1bca>
    7a4a:      	leaq	0x34(%rsp), %rsi
    7a4f:      	callq	*%rax
    7a51:      	testq	%rax, %rax
    7a54:      	je	0x8023 <generic_tracepoint_arg+0x21a3>
    7a5a:      	movq	%rax, %rdi
    7a5d:      	movzwl	%bx, %eax
    7a60:      	movq	%rax, 0x70(%rsp)
    7a65:      	movl	$0x1, %eax
    7a6a:      	movq	0x28(%rsp), %rsi
    7a6f:      	callq	*%rax
    7a71:      	movl	0x4(%r13), %edx
    7a75:      	xorl	%ecx, %ecx
    7a77:      	cmpl	$0x1d, %edx
    7a7a:      	ja	0x8c81 <generic_tracepoint_arg+0x2e01>
    7a80:      	movl	$0x30038400, %esi       # imm = 0x30038400
    7a85:      	btl	%edx, %esi
    7a88:      	movq	(%rsp), %rdi
    7a8c:      	movq	0x8(%rsp), %r9
    7a91:      	movq	%r12, %r11
    7a94:      	jb	0x78b0 <generic_tracepoint_arg+0x1a30>
    7a9a:      	movl	$0xc0800, %esi          # imm = 0xC0800
    7a9f:      	btl	%edx, %esi
    7aa2:      	jae	0x7aaa <generic_tracepoint_arg+0x1c2a>
    7aa4:      	testq	%rax, %rax
    7aa7:      	sete	%cl
    7aaa:      	movzbl	%cl, %ebx
    7aad:      	jmp	0x6150 <generic_tracepoint_arg+0x2d0>
    7ab2:      	xorl	%ebx, %ebx
    7ab4:      	movl	0x4(%r13), %eax
    7ab8:      	cmpq	$0x25, %rax
    7abc:      	ja	0x89af <generic_tracepoint_arg+0x2b2f>
    7ac2:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    7acc:      	btq	%rax, %rcx
    7ad0:      	movq	(%rsp), %rdi
    7ad4:      	movq	0x8(%rsp), %r9
    7ad9:      	movq	0x10(%rsp), %r11
    7ade:      	jb	0x9145 <generic_tracepoint_arg+0x32c5>
    7ae4:      	jmp	0x6150 <generic_tracepoint_arg+0x2d0>
    7ae9:      	movl	0x4(%r13), %eax
    7aed:      	andl	$-0x2, %eax
    7af0:      	cmpl	$0x18, %eax
    7af3:      	jmp	0x7d04 <generic_tracepoint_arg+0x1e84>
    7af8:      	cmpl	$0x3, %eax
    7afb:      	je	0x81ca <generic_tracepoint_arg+0x234a>
    7b01:      	cmpl	$0x7, %eax
    7b04:      	jne	0x81bc <generic_tracepoint_arg+0x233c>
    7b0a:      	movl	$0x9, %eax
    7b0f:      	jmp	0x81cf <generic_tracepoint_arg+0x234f>
    7b14:      	movl	$0x100, %esi            # imm = 0x100
    7b19:      	cmpl	$0x101, %eax            # imm = 0x101
    7b1e:      	jb	0x7b4c <generic_tracepoint_arg+0x1ccc>
    7b20:      	movl	$0x200, %esi            # imm = 0x200
    7b25:      	cmpl	$0x201, %eax            # imm = 0x201
    7b2a:      	jb	0x7b4c <generic_tracepoint_arg+0x1ccc>
    7b2c:      	movl	$0x400, %esi            # imm = 0x400
    7b31:      	cmpl	$0x401, %eax            # imm = 0x401
    7b36:      	jb	0x7b4c <generic_tracepoint_arg+0x1ccc>
    7b38:      	xorl	%esi, %esi
    7b3a:      	cmpl	$0x801, %eax            # imm = 0x801
    7b3f:      	setae	%sil
    7b43:      	shll	$0xb, %esi
    7b46:      	addl	$0x800, %esi            # imm = 0x800
    7b4c:      	leal	-0x100(%rsi), %eax
    7b52:      	rorxl	$0x8, %eax, %eax
    7b58:      	cmpl	$0x2, %eax
    7b5b:      	jg	0x7d1d <generic_tracepoint_arg+0x1e9d>
    7b61:      	testl	%eax, %eax
    7b63:      	je	0x8750 <generic_tracepoint_arg+0x28d0>
    7b69:      	cmpl	$0x1, %eax
    7b6c:      	jne	0x8749 <generic_tracepoint_arg+0x28c9>
    7b72:      	movl	$0x7, %eax
    7b77:      	jmp	0x875c <generic_tracepoint_arg+0x28dc>
    7b7c:      	cmpq	%rdx, (%r12)
    7b80:      	ja	0x6161 <generic_tracepoint_arg+0x2e1>
    7b86:      	jmp	0x7b92 <generic_tracepoint_arg+0x1d12>
    7b88:      	cmpq	%rdx, (%r12)
    7b8c:      	jb	0x6161 <generic_tracepoint_arg+0x2e1>
    7b92:      	movl	0x8(%r13), %edx
    7b96:      	cmpl	$0x11, %edx
    7b99:      	jb	0x9541 <generic_tracepoint_arg+0x36c1>
    7b9f:      	movq	0x18(%r13), %rsi
    7ba3:      	cmpl	$0x2, %eax
    7ba6:      	jle	0x7bc3 <generic_tracepoint_arg+0x1d43>
    7ba8:      	leal	-0x3(%rax), %edi
    7bab:      	cmpl	$0x2, %edi
    7bae:      	jae	0x7bf2 <generic_tracepoint_arg+0x1d72>
    7bb0:      	cmpq	%rsi, (%r12)
    7bb4:      	movq	(%rsp), %rdi
    7bb8:      	je	0x6145 <generic_tracepoint_arg+0x2c5>
    7bbe:      	jmp	0x86d1 <generic_tracepoint_arg+0x2851>
    7bc3:      	cmpl	$0x1, %eax
    7bc6:      	je	0x7c60 <generic_tracepoint_arg+0x1de0>
    7bcc:      	cmpl	$0x2, %eax
    7bcf:      	jne	0x86d1 <generic_tracepoint_arg+0x2851>
    7bd5:      	cmpl	$0xc, %ecx
    7bd8:      	je	0x7be3 <generic_tracepoint_arg+0x1d63>
    7bda:      	cmpl	$0xa, %ecx
    7bdd:      	jne	0x86c7 <generic_tracepoint_arg+0x2847>
    7be3:      	cmpq	%rsi, (%r12)
    7be7:      	jl	0x6161 <generic_tracepoint_arg+0x2e1>
    7bed:      	jmp	0x86d1 <generic_tracepoint_arg+0x2851>
    7bf2:      	cmpl	$0xc, %eax
    7bf5:      	movq	(%rsp), %rdi
    7bf9:      	jne	0x86d1 <generic_tracepoint_arg+0x2851>
    7bff:      	testq	%rsi, (%r12)
    7c03:      	jne	0x6161 <generic_tracepoint_arg+0x2e1>
    7c09:      	jmp	0x86d1 <generic_tracepoint_arg+0x2851>
    7c0e:      	cmpl	$0xc, %eax
    7c11:      	jne	0x7d46 <generic_tracepoint_arg+0x1ec6>
    7c17:      	movzbl	(%r12), %edx
    7c1c:      	testl	%edx, %ecx
    7c1e:      	jne	0x6161 <generic_tracepoint_arg+0x2e1>
    7c24:      	jmp	0x7d46 <generic_tracepoint_arg+0x1ec6>
    7c29:      	cmpl	$0xc, %eax
    7c2c:      	jne	0x7d8b <generic_tracepoint_arg+0x1f0b>
    7c32:      	movzwl	(%r12), %edx
    7c37:      	testl	%edx, %ecx
    7c39:      	jne	0x6161 <generic_tracepoint_arg+0x2e1>
    7c3f:      	jmp	0x7d8b <generic_tracepoint_arg+0x1f0b>
    7c44:      	cmpl	$0x3, %eax
    7c47:      	je	0x8364 <generic_tracepoint_arg+0x24e4>
    7c4d:      	cmpl	$0x7, %eax
    7c50:      	jne	0x8356 <generic_tracepoint_arg+0x24d6>
    7c56:      	movl	$0x9, %eax
    7c5b:      	jmp	0x8369 <generic_tracepoint_arg+0x24e9>
    7c60:      	cmpl	$0xc, %ecx
    7c63:      	je	0x7c6e <generic_tracepoint_arg+0x1dee>
    7c65:      	cmpl	$0xa, %ecx
    7c68:      	jne	0x86bb <generic_tracepoint_arg+0x283b>
    7c6e:      	cmpq	%rsi, (%r12)
    7c72:      	jg	0x6161 <generic_tracepoint_arg+0x2e1>
    7c78:      	jmp	0x86d1 <generic_tracepoint_arg+0x2851>
    7c7d:      	movl	0x8(%r13), %edx
    7c81:      	movzbl	(%r12), %ecx
    7c86:      	jmp	0x7c91 <generic_tracepoint_arg+0x1e11>
    7c88:      	movl	0x8(%r13), %edx
    7c8c:      	movzwl	(%r12), %ecx
    7c91:      	cmpl	%ecx, 0x10(%r13)
    7c95:      	setbe	%sil
    7c99:      	cmpl	%ecx, 0x14(%r13)
    7c9d:      	setae	%al
    7ca0:      	andb	%sil, %al
    7ca3:      	cmpl	$0x11, %edx
    7ca6:      	jb	0x8ed0 <generic_tracepoint_arg+0x3050>
    7cac:      	cmpl	%ecx, 0x18(%r13)
    7cb0:      	setbe	%sil
    7cb4:      	cmpl	%ecx, 0x1c(%r13)
    7cb8:      	setae	%dil
    7cbc:      	andb	%sil, %dil
    7cbf:      	orb	%dil, %al
    7cc2:      	cmpl	$0x19, %edx
    7cc5:      	jb	0x8ecc <generic_tracepoint_arg+0x304c>
    7ccb:      	cmpl	%ecx, 0x20(%r13)
    7ccf:      	setbe	%sil
    7cd3:      	cmpl	%ecx, 0x24(%r13)
    7cd7:      	setae	%dil
    7cdb:      	andb	%sil, %dil
    7cde:      	orb	%dil, %al
    7ce1:      	cmpl	$0x21, %edx
    7ce4:      	jb	0x8ecc <generic_tracepoint_arg+0x304c>
    7cea:      	cmpl	%ecx, 0x28(%r13)
    7cee:      	setbe	%dl
    7cf1:      	cmpl	%ecx, 0x2c(%r13)
    7cf5:      	setae	%cl
    7cf8:      	andb	%dl, %cl
    7cfa:      	orb	%cl, %al
    7cfc:      	jmp	0x8ecc <generic_tracepoint_arg+0x304c>
    7d01:      	testq	%rax, %rax
    7d04:      	sete	%al
    7d07:      	movq	(%rsp), %rdi
    7d0b:      	movq	0x8(%rsp), %r9
    7d10:      	movq	0x10(%rsp), %r11
    7d15:      	movzbl	%al, %ebx
    7d18:      	jmp	0x6150 <generic_tracepoint_arg+0x2d0>
    7d1d:      	cmpl	$0x3, %eax
    7d20:      	je	0x8757 <generic_tracepoint_arg+0x28d7>
    7d26:      	cmpl	$0x7, %eax
    7d29:      	jne	0x8749 <generic_tracepoint_arg+0x28c9>
    7d2f:      	movl	$0x9, %eax
    7d34:      	jmp	0x875c <generic_tracepoint_arg+0x28dc>
    7d39:      	movzbl	(%r12), %edx
    7d3e:      	cmpl	%edx, %ecx
    7d40:      	jb	0x6161 <generic_tracepoint_arg+0x2e1>
    7d46:      	movl	0x8(%r13), %ecx
    7d4a:      	cmpl	$0xd, %ecx
    7d4d:      	jb	0x9541 <generic_tracepoint_arg+0x36c1>
    7d53:      	movl	0x14(%r13), %edx
    7d57:      	cmpl	$0x2, %eax
    7d5a:      	jle	0x8152 <generic_tracepoint_arg+0x22d2>
    7d60:      	leal	-0x3(%rax), %esi
    7d63:      	cmpl	$0x2, %esi
    7d66:      	jae	0x88fa <generic_tracepoint_arg+0x2a7a>
    7d6c:      	movzbl	(%r12), %esi
    7d71:      	cmpl	%esi, %edx
    7d73:      	je	0x6145 <generic_tracepoint_arg+0x2c5>
    7d79:      	jmp	0x89eb <generic_tracepoint_arg+0x2b6b>
    7d7e:      	movzwl	(%r12), %edx
    7d83:      	cmpl	%edx, %ecx
    7d85:      	jb	0x6161 <generic_tracepoint_arg+0x2e1>
    7d8b:      	movl	0x8(%r13), %ecx
    7d8f:      	cmpl	$0xd, %ecx
    7d92:      	jb	0x9541 <generic_tracepoint_arg+0x36c1>
    7d98:      	movl	0x14(%r13), %edx
    7d9c:      	cmpl	$0x2, %eax
    7d9f:      	jle	0x8176 <generic_tracepoint_arg+0x22f6>
    7da5:      	leal	-0x3(%rax), %esi
    7da8:      	cmpl	$0x2, %esi
    7dab:      	jae	0x8915 <generic_tracepoint_arg+0x2a95>
    7db1:      	movzwl	(%r12), %esi
    7db6:      	cmpl	%esi, %edx
    7db8:      	je	0x6145 <generic_tracepoint_arg+0x2c5>
    7dbe:      	jmp	0x8a2c <generic_tracepoint_arg+0x2bac>
    7dc3:      	movl	(%r12), %eax
    7dc7:      	cmpl	%eax, %esi
    7dc9:      	ja	0x7dd3 <generic_tracepoint_arg+0x1f53>
    7dcb:      	cmpl	%edx, %eax
    7dcd:      	jbe	0x6161 <generic_tracepoint_arg+0x2e1>
    7dd3:      	movl	0x8(%r13), %edx
    7dd7:      	cmpl	$0x11, %edx
    7dda:      	jb	0x5f9d <generic_tracepoint_arg+0x11d>
    7de0:      	movl	0x18(%r13), %edi
    7de4:      	movl	0x1c(%r13), %esi
    7de8:      	cmpl	$0xc, %ecx
    7deb:      	ja	0x8577 <generic_tracepoint_arg+0x26f7>
    7df1:      	movl	$0x1402, %r8d           # imm = 0x1402
    7df7:      	btl	%ecx, %r8d
    7dfb:      	jae	0x8577 <generic_tracepoint_arg+0x26f7>
    7e01:      	cmpl	%eax, %edi
    7e03:      	movq	(%rsp), %rdi
    7e07:      	jg	0x8587 <generic_tracepoint_arg+0x2707>
    7e0d:      	cmpl	%esi, %eax
    7e0f:      	jle	0x6161 <generic_tracepoint_arg+0x2e1>
    7e15:      	jmp	0x8587 <generic_tracepoint_arg+0x2707>
    7e1a:      	movl	(%r12), %edx
    7e1e:      	cmpl	%edx, %esi
    7e20:      	setbe	%sil
    7e24:      	cmpl	%eax, %edx
    7e26:      	setbe	%al
    7e29:      	andb	%sil, %al
    7e2c:      	movl	0x8(%r13), %esi
    7e30:      	cmpl	$0x11, %esi
    7e33:      	jb	0x8ed0 <generic_tracepoint_arg+0x3050>
    7e39:      	movl	0x18(%r13), %r8d
    7e3d:      	movl	0x1c(%r13), %edi
    7e41:      	cmpl	$0xc, %ecx
    7e44:      	ja	0x8521 <generic_tracepoint_arg+0x26a1>
    7e4a:      	movl	$0x1402, %r10d          # imm = 0x1402
    7e50:      	btl	%ecx, %r10d
    7e54:      	jae	0x8521 <generic_tracepoint_arg+0x26a1>
    7e5a:      	cmpl	%edx, %r8d
    7e5d:      	setle	%r8b
    7e61:      	cmpl	%edi, %edx
    7e63:      	setle	%dil
    7e67:      	jmp	0x852e <generic_tracepoint_arg+0x26ae>
    7e6c:      	xorl	%ebx, %ebx
    7e6e:      	xorl	%r12d, %r12d
    7e71:      	movq	%r11, %r15
    7e74:      	movl	0x10(%r13,%rbx,4), %eax
    7e79:      	movl	%eax, 0x38(%rsp)
    7e7d:      	movl	$0x1, %eax
    7e82:      	leaq	0x38(%rsp), %rsi
    7e87:      	movq	(%rip), %rdi            # 0x7e8e <generic_tracepoint_arg+0x200e>
    7e8e:      	callq	*%rax
    7e90:      	testq	%rax, %rax
    7e93:      	je	0x7f14 <generic_tracepoint_arg+0x2094>
    7e99:      	testl	%ebp, %ebp
    7e9b:      	movq	0x8(%rsp), %r9
    7ea0:      	movq	%r15, %r11
    7ea3:      	movq	0x68(%rsp), %r15
    7ea8:      	je	0x7eef <generic_tracepoint_arg+0x206f>
    7eaa:      	movq	0x18(%rsp), %rdx
    7eaf:      	xorl	%ecx, %ecx
    7eb1:      	jmp	0x7ebe <generic_tracepoint_arg+0x203e>
    7eb3:      	incq	%rcx
    7eb6:      	incq	%rdx
    7eb9:      	cmpq	%rbp, %rcx
    7ebc:      	je	0x7eef <generic_tracepoint_arg+0x206f>
    7ebe:      	xorl	%esi, %esi
    7ec0:      	leaq	(%rcx,%rsi), %rdi
    7ec4:      	cmpq	%rbp, %rdi
    7ec7:      	jae	0x7eb3 <generic_tracepoint_arg+0x2033>
    7ec9:      	movzbl	(%rax,%rsi), %edi
    7ecd:      	testb	%dil, %dil
    7ed0:      	je	0x7ee7 <generic_tracepoint_arg+0x2067>
    7ed2:      	cmpq	$0x62, %rsi
    7ed6:      	ja	0x7eb3 <generic_tracepoint_arg+0x2033>
    7ed8:      	leaq	0x1(%rsi), %r8
    7edc:      	cmpb	%dil, (%rdx,%rsi)
    7ee0:      	movq	%r8, %rsi
    7ee3:      	je	0x7ec0 <generic_tracepoint_arg+0x2040>
    7ee5:      	jmp	0x7eb3 <generic_tracepoint_arg+0x2033>
    7ee7:      	testl	%ecx, %ecx
    7ee9:      	jns	0x819a <generic_tracepoint_arg+0x231a>
    7eef:      	leal	0xc(%r12), %eax
    7ef4:      	cmpl	0x8(%r13), %eax
    7ef8:      	jae	0x8d17 <generic_tracepoint_arg+0x2e97>
    7efe:      	addl	$0x4, %r12d
    7f02:      	incq	%rbx
    7f05:      	cmpq	$0x64, %rbx
    7f09:      	jne	0x7e71 <generic_tracepoint_arg+0x1ff1>
    7f0f:      	jmp	0x8d17 <generic_tracepoint_arg+0x2e97>
    7f14:      	xorl	%ebx, %ebx
    7f16:      	movq	0x8(%rsp), %r9
    7f1b:      	movq	%r15, %r11
    7f1e:      	movq	0x68(%rsp), %r15
    7f23:      	movq	(%rsp), %rdi
    7f27:      	jmp	0x94bb <generic_tracepoint_arg+0x363b>
    7f2c:      	movzwl	%bp, %eax
    7f2f:      	cmpl	$0x90, %eax
    7f34:      	movq	%r11, 0x10(%rsp)
    7f39:      	ja	0x85ca <generic_tracepoint_arg+0x274a>
    7f3f:      	testw	%bp, %bp
    7f42:      	je	0x7f54 <generic_tracepoint_arg+0x20d4>
    7f44:      	movl	%ebp, %eax
    7f46:      	movl	$0x18, %ecx
    7f4b:      	cltd
    7f4c:      	idivl	%ecx
    7f4e:      	movl	%ebp, %esi
    7f50:      	testl	%edx, %edx
    7f52:      	je	0x7f76 <generic_tracepoint_arg+0x20f6>
    7f54:      	movl	%ebp, %eax
    7f56:      	movl	$0x18, %ecx
    7f5b:      	cltd
    7f5c:      	idivl	%ecx
    7f5e:      	shll	$0x3, %eax
    7f61:      	leal	(%rax,%rax,2), %eax
    7f64:      	addl	$0x18, %eax
    7f67:      	movzwl	%ax, %esi
    7f6a:      	cmpl	$0x90, %esi
    7f70:      	ja	0x8602 <generic_tracepoint_arg+0x2782>
    7f76:      	movl	%esi, %eax
    7f78:      	cltd
    7f79:      	idivl	%ecx
    7f7b:      	decl	%eax
    7f7d:      	jmp	0x8d35 <generic_tracepoint_arg+0x2eb5>
    7f82:      	cmpq	%rdx, %r8
    7f85:      	setbe	%r8b
    7f89:      	cmpq	%rdi, %rdx
    7f8c:      	setbe	%dil
    7f90:      	andb	%r8b, %dil
    7f93:      	orb	%dil, %al
    7f96:      	cmpl	$0x29, %esi
    7f99:      	jb	0x8ecc <generic_tracepoint_arg+0x304c>
    7f9f:      	movq	0x30(%r13), %r8
    7fa3:      	movq	0x38(%r13), %rdi
    7fa7:      	cmpl	$0xc, %ecx
    7faa:      	je	0x7fb5 <generic_tracepoint_arg+0x2135>
    7fac:      	cmpl	$0xa, %ecx
    7faf:      	jne	0x8632 <generic_tracepoint_arg+0x27b2>
    7fb5:      	cmpq	%rdx, %r8
    7fb8:      	setle	%r8b
    7fbc:      	cmpq	%rdi, %rdx
    7fbf:      	setle	%dil
    7fc3:      	jmp	0x8640 <generic_tracepoint_arg+0x27c0>
    7fc8:      	xorl	%ebx, %ebx
    7fca:      	cmpl	$0x29, %ecx
    7fcd:      	jne	0x7fd8 <generic_tracepoint_arg+0x2158>
    7fcf:      	testq	%rdx, %rdx
    7fd2:      	je	0x7fd8 <generic_tracepoint_arg+0x2158>
    7fd4:      	movzbl	0x3a(%rdx), %ebx
    7fd8:      	cmpl	$0x29, %ecx
    7fdb:      	je	0x7fe6 <generic_tracepoint_arg+0x2166>
    7fdd:      	cmpl	$0x7, %ecx
    7fe0:      	jne	0x8570 <generic_tracepoint_arg+0x26f0>
    7fe6:      	movq	%r11, %r12
    7fe9:      	movzbl	0x10(%r13), %eax
    7fee:      	movl	%eax, 0x34(%rsp)
    7ff2:      	movl	$0x1, %eax
    7ff7:      	movq	(%rip), %rdi            # 0x7ffe <generic_tracepoint_arg+0x217e>
    7ffe:      	leaq	0x34(%rsp), %rsi
    8003:      	callq	*%rax
    8005:      	testq	%rax, %rax
    8008:      	je	0x8023 <generic_tracepoint_arg+0x21a3>
    800a:      	movq	%rax, %rdi
    800d:      	movl	%ebx, %eax
    800f:      	movq	%rax, 0x70(%rsp)
    8014:      	movl	$0x1, %eax
    8019:      	movq	0x28(%rsp), %rsi
    801e:      	jmp	0x7a6f <generic_tracepoint_arg+0x1bef>
    8023:      	xorl	%ebx, %ebx
    8025:      	movq	(%rsp), %rdi
    8029:      	movq	0x8(%rsp), %r9
    802e:      	movq	%r12, %r11
    8031:      	jmp	0x6150 <generic_tracepoint_arg+0x2d0>
    8036:      	xorl	%ebx, %ebx
    8038:      	movq	%r15, %r11
    803b:      	movq	0x68(%rsp), %r15
    8040:      	jmp	0x8513 <generic_tracepoint_arg+0x2693>
    8045:      	cmpq	%rax, %rdi
    8048:      	movq	(%rsp), %rdi
    804c:      	ja	0x8057 <generic_tracepoint_arg+0x21d7>
    804e:      	cmpq	%rsi, %rax
    8051:      	jbe	0x6161 <generic_tracepoint_arg+0x2e1>
    8057:      	cmpl	$0x29, %edx
    805a:      	jb	0x5f9d <generic_tracepoint_arg+0x11d>
    8060:      	movq	0x30(%r13), %rdi
    8064:      	movq	0x38(%r13), %rsi
    8068:      	cmpl	$0xc, %ecx
    806b:      	je	0x8076 <generic_tracepoint_arg+0x21f6>
    806d:      	cmpl	$0xa, %ecx
    8070:      	jne	0x8673 <generic_tracepoint_arg+0x27f3>
    8076:      	cmpq	%rax, %rdi
    8079:      	movq	(%rsp), %rdi
    807d:      	jg	0x8685 <generic_tracepoint_arg+0x2805>
    8083:      	cmpq	%rsi, %rax
    8086:      	jle	0x6161 <generic_tracepoint_arg+0x2e1>
    808c:      	jmp	0x8685 <generic_tracepoint_arg+0x2805>
    8091:      	cmpl	%edx, (%r12)
    8095:      	ja	0x6161 <generic_tracepoint_arg+0x2e1>
    809b:      	jmp	0x80a7 <generic_tracepoint_arg+0x2227>
    809d:      	cmpl	%edx, (%r12)
    80a1:      	jb	0x6161 <generic_tracepoint_arg+0x2e1>
    80a7:      	movl	0x8(%r13), %edx
    80ab:      	cmpl	$0xd, %edx
    80ae:      	jb	0x9541 <generic_tracepoint_arg+0x36c1>
    80b4:      	movl	0x14(%r13), %esi
    80b8:      	cmpl	$0x2, %eax
    80bb:      	jle	0x80d8 <generic_tracepoint_arg+0x2258>
    80bd:      	leal	-0x3(%rax), %edi
    80c0:      	cmpl	$0x2, %edi
    80c3:      	jae	0x810e <generic_tracepoint_arg+0x228e>
    80c5:      	cmpl	%esi, (%r12)
    80c9:      	movq	(%rsp), %rdi
    80cd:      	je	0x6145 <generic_tracepoint_arg+0x2c5>
    80d3:      	jmp	0x8b88 <generic_tracepoint_arg+0x2d08>
    80d8:      	cmpl	$0x1, %eax
    80db:      	je	0x812a <generic_tracepoint_arg+0x22aa>
    80dd:      	cmpl	$0x2, %eax
    80e0:      	jne	0x8b88 <generic_tracepoint_arg+0x2d08>
    80e6:      	cmpl	$0xc, %ecx
    80e9:      	ja	0x8b7e <generic_tracepoint_arg+0x2cfe>
    80ef:      	movl	$0x1402, %r8d           # imm = 0x1402
    80f5:      	btl	%ecx, %r8d
    80f9:      	jae	0x8b7e <generic_tracepoint_arg+0x2cfe>
    80ff:      	cmpl	%esi, (%r12)
    8103:      	jl	0x6161 <generic_tracepoint_arg+0x2e1>
    8109:      	jmp	0x8b88 <generic_tracepoint_arg+0x2d08>
    810e:      	cmpl	$0xc, %eax
    8111:      	movq	(%rsp), %rdi
    8115:      	jne	0x8b88 <generic_tracepoint_arg+0x2d08>
    811b:      	testl	%esi, (%r12)
    811f:      	jne	0x6161 <generic_tracepoint_arg+0x2e1>
    8125:      	jmp	0x8b88 <generic_tracepoint_arg+0x2d08>
    812a:      	cmpl	$0xc, %ecx
    812d:      	ja	0x8b72 <generic_tracepoint_arg+0x2cf2>
    8133:      	movl	$0x1402, %r8d           # imm = 0x1402
    8139:      	btl	%ecx, %r8d
    813d:      	jae	0x8b72 <generic_tracepoint_arg+0x2cf2>
    8143:      	cmpl	%esi, (%r12)
    8147:      	jg	0x6161 <generic_tracepoint_arg+0x2e1>
    814d:      	jmp	0x8b88 <generic_tracepoint_arg+0x2d08>
    8152:      	cmpl	$0x1, %eax
    8155:      	je	0x89de <generic_tracepoint_arg+0x2b5e>
    815b:      	cmpl	$0x2, %eax
    815e:      	jne	0x89eb <generic_tracepoint_arg+0x2b6b>
    8164:      	movzbl	(%r12), %esi
    8169:      	cmpl	%esi, %edx
    816b:      	ja	0x6161 <generic_tracepoint_arg+0x2e1>
    8171:      	jmp	0x89eb <generic_tracepoint_arg+0x2b6b>
    8176:      	cmpl	$0x1, %eax
    8179:      	je	0x8a1f <generic_tracepoint_arg+0x2b9f>
    817f:      	cmpl	$0x2, %eax
    8182:      	jne	0x8a2c <generic_tracepoint_arg+0x2bac>
    8188:      	movzwl	(%r12), %esi
    818d:      	cmpl	%esi, %edx
    818f:      	ja	0x6161 <generic_tracepoint_arg+0x2e1>
    8195:      	jmp	0x8a2c <generic_tracepoint_arg+0x2bac>
    819a:      	movl	$0x1, %ebx
    819f:      	movq	(%rsp), %rdi
    81a3:      	jmp	0x94bb <generic_tracepoint_arg+0x363b>
    81a8:      	movq	(%rsp), %rdi
    81ac:      	movq	0x8(%rsp), %r9
    81b1:      	movq	%rbp, %r11
    81b4:      	movzbl	%cl, %ebx
    81b7:      	jmp	0x6150 <generic_tracepoint_arg+0x2d0>
    81bc:      	movl	$0xa, %eax
    81c1:      	jmp	0x81cf <generic_tracepoint_arg+0x234f>
    81c3:      	movl	$0x6, %eax
    81c8:      	jmp	0x81cf <generic_tracepoint_arg+0x234f>
    81ca:      	movl	$0x8, %eax
    81cf:      	movl	%eax, %ecx
    81d1:      	andl	$0xf, %ecx
    81d4:      	movl	0x10(%r13,%rcx,4), %ecx
    81d9:      	cmpl	$-0x1, %ecx
    81dc:      	je	0x9113 <generic_tracepoint_arg+0x3293>
    81e2:      	movl	%ecx, 0x88(%rsp)
    81e9:      	movl	%eax, 0x18(%rsp)
    81ed:      	movq	%rsi, 0x60(%rsp)
    81f2:      	movl	$0x1, %eax
    81f7:      	movq	(%rip), %rdi            # 0x81fe <generic_tracepoint_arg+0x237e>
    81fe:      	movq	0x28(%rsp), %rbx
    8203:      	movq	%rbx, %rsi
    8206:      	callq	*%rax
    8208:      	movq	%rax, 0x20(%rsp)
    820d:      	movl	$0x1, %eax
    8212:      	movq	(%rip), %rdi            # 0x8219 <generic_tracepoint_arg+0x2399>
    8219:      	movq	%rbx, %rsi
    821c:      	callq	*%rax
    821e:      	movq	0x20(%rsp), %rdx
    8223:      	testq	%rdx, %rdx
    8226:      	je	0x9113 <generic_tracepoint_arg+0x3293>
    822c:      	movl	$0x0, %ebx
    8231:      	testq	%rax, %rax
    8234:      	movq	(%rsp), %rdi
    8238:      	movq	0x8(%rsp), %r9
    823d:      	movq	0x10(%rsp), %r11
    8242:      	je	0x9123 <generic_tracepoint_arg+0x32a3>
    8248:      	movq	%rdx, %rcx
    824b:      	movq	%rax, %rbx
    824e:      	movq	%r12, %rdx
    8251:      	addq	$0x4, %rdx
    8255:      	cmpl	$0x5, 0x18(%rsp)
    825a:      	jg	0x828c <generic_tracepoint_arg+0x240c>
    825c:      	movq	%rcx, %r12
    825f:      	movb	%bpl, (%rcx)
    8262:      	leaq	0x1(%rcx), %rdi
    8266:      	movl	$0x4, %eax
    826b:      	movl	%ebp, %esi
    826d:      	callq	*%rax
    826f:      	movq	0x60(%rsp), %rsi
    8274:      	subl	%ebp, %esi
    8276:      	jbe	0x82c0 <generic_tracepoint_arg+0x2440>
    8278:      	leaq	(%r12,%rbp), %rdi
    827c:      	incq	%rdi
    827f:      	andl	$0xfff, %esi            # imm = 0xFFF
    8285:      	movl	$0x4, %eax
    828a:      	jmp	0x82bb <generic_tracepoint_arg+0x243b>
    828c:      	movq	%rcx, %r12
    828f:      	movw	%bp, (%rcx)
    8292:      	leaq	0x2(%rcx), %rdi
    8296:      	movl	$0x4, %eax
    829b:      	movl	%ebp, %esi
    829d:      	callq	*%rax
    829f:      	movq	0x60(%rsp), %rsi
    82a4:      	subl	%ebp, %esi
    82a6:      	jbe	0x82c0 <generic_tracepoint_arg+0x2440>
    82a8:      	leaq	(%r12,%rbp), %rdi
    82ac:      	addq	$0x2, %rdi
    82b0:      	andl	$0xfff, %esi            # imm = 0xFFF
    82b6:      	movl	$0x4, %eax
    82bb:      	movq	%rbx, %rdx
    82be:      	callq	*%rax
    82c0:      	movl	0x88(%rsp), %eax
    82c7:      	movl	%eax, 0x38(%rsp)
    82cb:      	movl	0x18(%rsp), %eax
    82cf:      	cmpl	$0x4, %eax
    82d2:      	movq	(%rsp), %rdi
    82d6:      	movq	0x8(%rsp), %r9
    82db:      	movq	0x10(%rsp), %r11
    82e0:      	jle	0x831c <generic_tracepoint_arg+0x249c>
    82e2:      	cmpl	$0x7, %eax
    82e5:      	jg	0x8930 <generic_tracepoint_arg+0x2ab0>
    82eb:      	cmpl	$0x5, %eax
    82ee:      	je	0x9001 <generic_tracepoint_arg+0x3181>
    82f4:      	cmpl	$0x6, %eax
    82f7:      	je	0x8fc8 <generic_tracepoint_arg+0x3148>
    82fd:      	cmpl	$0x7, %eax
    8300:      	jne	0x8c6c <generic_tracepoint_arg+0x2dec>
    8306:      	movl	$0x1, %eax
    830b:      	leaq	0x38(%rsp), %rsi
    8310:      	movq	(%rip), %rdi            # 0x8317 <generic_tracepoint_arg+0x2497>
    8317:      	jmp	0x9025 <generic_tracepoint_arg+0x31a5>
    831c:      	cmpl	$0x1, %eax
    831f:      	jle	0x8a60 <generic_tracepoint_arg+0x2be0>
    8325:      	cmpl	$0x2, %eax
    8328:      	je	0x8fee <generic_tracepoint_arg+0x316e>
    832e:      	cmpl	$0x3, %eax
    8331:      	je	0x8fb5 <generic_tracepoint_arg+0x3135>
    8337:      	cmpl	$0x4, %eax
    833a:      	jne	0x8c6c <generic_tracepoint_arg+0x2dec>
    8340:      	movl	$0x1, %eax
    8345:      	leaq	0x38(%rsp), %rsi
    834a:      	movq	(%rip), %rdi            # 0x8351 <generic_tracepoint_arg+0x24d1>
    8351:      	jmp	0x9025 <generic_tracepoint_arg+0x31a5>
    8356:      	movl	$0xa, %eax
    835b:      	jmp	0x8369 <generic_tracepoint_arg+0x24e9>
    835d:      	movl	$0x6, %eax
    8362:      	jmp	0x8369 <generic_tracepoint_arg+0x24e9>
    8364:      	movl	$0x8, %eax
    8369:      	movl	%eax, %ecx
    836b:      	andl	$0xf, %ecx
    836e:      	movl	0x10(%r13,%rcx,4), %ecx
    8373:      	cmpl	$-0x1, %ecx
    8376:      	je	0x8c6c <generic_tracepoint_arg+0x2dec>
    837c:      	movl	%ecx, 0x90(%rsp)
    8383:      	movq	%rbx, 0x88(%rsp)
    838b:      	movl	%eax, 0x20(%rsp)
    838f:      	movq	%r8, 0x18(%rsp)
    8394:      	movq	%rsi, 0x60(%rsp)
    8399:      	movq	%r11, 0x10(%rsp)
    839e:      	movl	$0x1, %eax
    83a3:      	movq	(%rip), %rdi            # 0x83aa <generic_tracepoint_arg+0x252a>
    83aa:      	movq	0x28(%rsp), %rbx
    83af:      	movq	%rbx, %rsi
    83b2:      	callq	*%rax
    83b4:      	movq	%rax, %r12
    83b7:      	movl	$0x1, %eax
    83bc:      	movq	(%rip), %rdi            # 0x83c3 <generic_tracepoint_arg+0x2543>
    83c3:      	movq	%rbx, %rsi
    83c6:      	callq	*%rax
    83c8:      	testq	%r12, %r12
    83cb:      	je	0x9113 <generic_tracepoint_arg+0x3293>
    83d1:      	movl	$0x0, %ebx
    83d6:      	testq	%rax, %rax
    83d9:      	movq	(%rsp), %rdi
    83dd:      	movq	0x8(%rsp), %r9
    83e2:      	movq	0x10(%rsp), %r11
    83e7:      	je	0x9123 <generic_tracepoint_arg+0x32a3>
    83ed:      	movq	%r12, %rcx
    83f0:      	movq	%rax, %r12
    83f3:      	cmpl	$0x5, 0x20(%rsp)
    83f8:      	jg	0x8437 <generic_tracepoint_arg+0x25b7>
    83fa:      	movb	%bpl, (%rcx)
    83fd:      	movq	%rcx, %rbp
    8400:      	leaq	0x1(%rcx), %rdi
    8404:      	movl	$0x4, %eax
    8409:      	movq	0x60(%rsp), %rbx
    840e:      	movq	0x18(%rsp), %rdx
    8413:      	movl	%ebx, %esi
    8415:      	callq	*%rax
    8417:      	movq	0x88(%rsp), %rsi
    841f:      	subl	%ebx, %esi
    8421:      	jbe	0x8478 <generic_tracepoint_arg+0x25f8>
    8423:      	leaq	(%rbx,%rbp), %rdi
    8427:      	incq	%rdi
    842a:      	andl	$0xfff, %esi            # imm = 0xFFF
    8430:      	movl	$0x4, %eax
    8435:      	jmp	0x8473 <generic_tracepoint_arg+0x25f3>
    8437:      	movq	0x60(%rsp), %rbx
    843c:      	movq	%rcx, %rbp
    843f:      	movw	%bx, (%rcx)
    8442:      	leaq	0x2(%rcx), %rdi
    8446:      	movl	$0x4, %eax
    844b:      	movq	0x18(%rsp), %rdx
    8450:      	movl	%ebx, %esi
    8452:      	callq	*%rax
    8454:      	movq	0x88(%rsp), %rsi
    845c:      	subl	%ebx, %esi
    845e:      	jbe	0x8478 <generic_tracepoint_arg+0x25f8>
    8460:      	leaq	(%rbx,%rbp), %rdi
    8464:      	addq	$0x2, %rdi
    8468:      	andl	$0xfff, %esi            # imm = 0xFFF
    846e:      	movl	$0x4, %eax
    8473:      	movq	%r12, %rdx
    8476:      	callq	*%rax
    8478:      	movl	0x90(%rsp), %eax
    847f:      	movl	%eax, 0x38(%rsp)
    8483:      	movl	0x20(%rsp), %eax
    8487:      	cmpl	$0x4, %eax
    848a:      	movq	(%rsp), %rdi
    848e:      	movq	0x8(%rsp), %r9
    8493:      	movq	0x10(%rsp), %r11
    8498:      	jle	0x84d4 <generic_tracepoint_arg+0x2654>
    849a:      	cmpl	$0x7, %eax
    849d:      	jg	0x897e <generic_tracepoint_arg+0x2afe>
    84a3:      	cmpl	$0x5, %eax
    84a6:      	je	0x90d1 <generic_tracepoint_arg+0x3251>
    84ac:      	cmpl	$0x6, %eax
    84af:      	je	0x9098 <generic_tracepoint_arg+0x3218>
    84b5:      	cmpl	$0x7, %eax
    84b8:      	jne	0x8c6c <generic_tracepoint_arg+0x2dec>
    84be:      	movl	$0x1, %eax
    84c3:      	leaq	0x38(%rsp), %rsi
    84c8:      	movq	(%rip), %rdi            # 0x84cf <generic_tracepoint_arg+0x264f>
    84cf:      	jmp	0x90f5 <generic_tracepoint_arg+0x3275>
    84d4:      	cmpl	$0x1, %eax
    84d7:      	jle	0x8c49 <generic_tracepoint_arg+0x2dc9>
    84dd:      	cmpl	$0x2, %eax
    84e0:      	je	0x90be <generic_tracepoint_arg+0x323e>
    84e6:      	cmpl	$0x3, %eax
    84e9:      	je	0x9085 <generic_tracepoint_arg+0x3205>
    84ef:      	cmpl	$0x4, %eax
    84f2:      	jne	0x8c6c <generic_tracepoint_arg+0x2dec>
    84f8:      	movl	$0x1, %eax
    84fd:      	leaq	0x38(%rsp), %rsi
    8502:      	movq	(%rip), %rdi            # 0x8509 <generic_tracepoint_arg+0x2689>
    8509:      	jmp	0x90f5 <generic_tracepoint_arg+0x3275>
    850e:      	movl	$0x1, %ebx
    8513:      	movq	(%rsp), %rdi
    8517:      	movq	0x8(%rsp), %r9
    851c:      	jmp	0x94bb <generic_tracepoint_arg+0x363b>
    8521:      	cmpl	%edx, %r8d
    8524:      	setbe	%r8b
    8528:      	cmpl	%edi, %edx
    852a:      	setbe	%dil
    852e:      	andb	%r8b, %dil
    8531:      	orb	%dil, %al
    8534:      	cmpl	$0x19, %esi
    8537:      	jb	0x8ecc <generic_tracepoint_arg+0x304c>
    853d:      	movl	0x20(%r13), %r8d
    8541:      	movl	0x24(%r13), %edi
    8545:      	cmpl	$0xc, %ecx
    8548:      	ja	0x8ab8 <generic_tracepoint_arg+0x2c38>
    854e:      	movl	$0x1402, %r10d          # imm = 0x1402
    8554:      	btl	%ecx, %r10d
    8558:      	jae	0x8ab8 <generic_tracepoint_arg+0x2c38>
    855e:      	cmpl	%edx, %r8d
    8561:      	setle	%r8b
    8565:      	cmpl	%edi, %edx
    8567:      	setle	%dil
    856b:      	jmp	0x8ac5 <generic_tracepoint_arg+0x2c45>
    8570:      	xorl	%ebx, %ebx
    8572:      	jmp	0x6150 <generic_tracepoint_arg+0x2d0>
    8577:      	cmpl	%eax, %edi
    8579:      	movq	(%rsp), %rdi
    857d:      	ja	0x8587 <generic_tracepoint_arg+0x2707>
    857f:      	cmpl	%esi, %eax
    8581:      	jbe	0x6161 <generic_tracepoint_arg+0x2e1>
    8587:      	cmpl	$0x19, %edx
    858a:      	jb	0x5f9d <generic_tracepoint_arg+0x11d>
    8590:      	movl	0x20(%r13), %edi
    8594:      	movl	0x24(%r13), %esi
    8598:      	cmpl	$0xc, %ecx
    859b:      	ja	0x8b23 <generic_tracepoint_arg+0x2ca3>
    85a1:      	movl	$0x1402, %r8d           # imm = 0x1402
    85a7:      	btl	%ecx, %r8d
    85ab:      	jae	0x8b23 <generic_tracepoint_arg+0x2ca3>
    85b1:      	cmpl	%eax, %edi
    85b3:      	movq	(%rsp), %rdi
    85b7:      	jg	0x8b33 <generic_tracepoint_arg+0x2cb3>
    85bd:      	cmpl	%esi, %eax
    85bf:      	jle	0x6161 <generic_tracepoint_arg+0x2e1>
    85c5:      	jmp	0x8b33 <generic_tracepoint_arg+0x2cb3>
    85ca:      	movl	$0x100, %esi            # imm = 0x100
    85cf:      	cmpl	$0x101, %eax            # imm = 0x101
    85d4:      	jb	0x8602 <generic_tracepoint_arg+0x2782>
    85d6:      	movl	$0x200, %esi            # imm = 0x200
    85db:      	cmpl	$0x201, %eax            # imm = 0x201
    85e0:      	jb	0x8602 <generic_tracepoint_arg+0x2782>
    85e2:      	movl	$0x400, %esi            # imm = 0x400
    85e7:      	cmpl	$0x401, %eax            # imm = 0x401
    85ec:      	jb	0x8602 <generic_tracepoint_arg+0x2782>
    85ee:      	xorl	%esi, %esi
    85f0:      	cmpl	$0x801, %eax            # imm = 0x801
    85f5:      	setae	%sil
    85f9:      	shll	$0xb, %esi
    85fc:      	addl	$0x800, %esi            # imm = 0x800
    8602:      	leal	-0x100(%rsi), %eax
    8608:      	rorxl	$0x8, %eax, %eax
    860e:      	cmpl	$0x2, %eax
    8611:      	jg	0x89c2 <generic_tracepoint_arg+0x2b42>
    8617:      	testl	%eax, %eax
    8619:      	je	0x8d29 <generic_tracepoint_arg+0x2ea9>
    861f:      	cmpl	$0x1, %eax
    8622:      	jne	0x8d22 <generic_tracepoint_arg+0x2ea2>
    8628:      	movl	$0x7, %eax
    862d:      	jmp	0x8d35 <generic_tracepoint_arg+0x2eb5>
    8632:      	cmpq	%rdx, %r8
    8635:      	setbe	%r8b
    8639:      	cmpq	%rdi, %rdx
    863c:      	setbe	%dil
    8640:      	andb	%r8b, %dil
    8643:      	orb	%dil, %al
    8646:      	cmpl	$0x39, %esi
    8649:      	jb	0x8ecc <generic_tracepoint_arg+0x304c>
    864f:      	movq	0x40(%r13), %rdi
    8653:      	movq	0x48(%r13), %rsi
    8657:      	cmpl	$0xc, %ecx
    865a:      	je	0x8665 <generic_tracepoint_arg+0x27e5>
    865c:      	cmpl	$0xa, %ecx
    865f:      	jne	0x8c2f <generic_tracepoint_arg+0x2daf>
    8665:      	cmpq	%rdx, %rdi
    8668:      	setle	%cl
    866b:      	cmpq	%rsi, %rdx
    866e:      	jmp	0x8afc <generic_tracepoint_arg+0x2c7c>
    8673:      	cmpq	%rax, %rdi
    8676:      	movq	(%rsp), %rdi
    867a:      	ja	0x8685 <generic_tracepoint_arg+0x2805>
    867c:      	cmpq	%rsi, %rax
    867f:      	jbe	0x6161 <generic_tracepoint_arg+0x2e1>
    8685:      	cmpl	$0x39, %edx
    8688:      	jb	0x5f9d <generic_tracepoint_arg+0x11d>
    868e:      	movq	0x40(%r13), %rsi
    8692:      	movq	0x48(%r13), %rdx
    8696:      	cmpl	$0xc, %ecx
    8699:      	je	0x86a4 <generic_tracepoint_arg+0x2824>
    869b:      	cmpl	$0xa, %ecx
    869e:      	jne	0x8c95 <generic_tracepoint_arg+0x2e15>
    86a4:      	cmpq	%rax, %rsi
    86a7:      	jg	0x5f9d <generic_tracepoint_arg+0x11d>
    86ad:      	cmpq	%rdx, %rax
    86b0:      	jle	0x6161 <generic_tracepoint_arg+0x2e1>
    86b6:      	jmp	0x5f9d <generic_tracepoint_arg+0x11d>
    86bb:      	cmpq	%rsi, (%r12)
    86bf:      	ja	0x6161 <generic_tracepoint_arg+0x2e1>
    86c5:      	jmp	0x86d1 <generic_tracepoint_arg+0x2851>
    86c7:      	cmpq	%rsi, (%r12)
    86cb:      	jb	0x6161 <generic_tracepoint_arg+0x2e1>
    86d1:      	cmpl	$0x19, %edx
    86d4:      	jb	0x9541 <generic_tracepoint_arg+0x36c1>
    86da:      	movq	0x20(%r13), %rsi
    86de:      	cmpl	$0x2, %eax
    86e1:      	jle	0x86fe <generic_tracepoint_arg+0x287e>
    86e3:      	leal	-0x3(%rax), %edi
    86e6:      	cmpl	$0x2, %edi
    86e9:      	jae	0x872d <generic_tracepoint_arg+0x28ad>
    86eb:      	cmpq	%rsi, (%r12)
    86ef:      	movq	(%rsp), %rdi
    86f3:      	je	0x6145 <generic_tracepoint_arg+0x2c5>
    86f9:      	jmp	0x8ef3 <generic_tracepoint_arg+0x3073>
    86fe:      	cmpl	$0x1, %eax
    8701:      	je	0x8961 <generic_tracepoint_arg+0x2ae1>
    8707:      	cmpl	$0x2, %eax
    870a:      	jne	0x8ef3 <generic_tracepoint_arg+0x3073>
    8710:      	cmpl	$0xc, %ecx
    8713:      	je	0x871e <generic_tracepoint_arg+0x289e>
    8715:      	cmpl	$0xa, %ecx
    8718:      	jne	0x8ee9 <generic_tracepoint_arg+0x3069>
    871e:      	cmpq	%rsi, (%r12)
    8722:      	jl	0x6161 <generic_tracepoint_arg+0x2e1>
    8728:      	jmp	0x8ef3 <generic_tracepoint_arg+0x3073>
    872d:      	cmpl	$0xc, %eax
    8730:      	movq	(%rsp), %rdi
    8734:      	jne	0x8ef3 <generic_tracepoint_arg+0x3073>
    873a:      	testq	%rsi, (%r12)
    873e:      	jne	0x6161 <generic_tracepoint_arg+0x2e1>
    8744:      	jmp	0x8ef3 <generic_tracepoint_arg+0x3073>
    8749:      	movl	$0xa, %eax
    874e:      	jmp	0x875c <generic_tracepoint_arg+0x28dc>
    8750:      	movl	$0x6, %eax
    8755:      	jmp	0x875c <generic_tracepoint_arg+0x28dc>
    8757:      	movl	$0x8, %eax
    875c:      	movl	%eax, %ecx
    875e:      	andl	$0xf, %ecx
    8761:      	movl	0x10(%r13,%rcx,4), %ecx
    8766:      	cmpl	$-0x1, %ecx
    8769:      	je	0x8d17 <generic_tracepoint_arg+0x2e97>
    876f:      	movl	%ecx, 0x88(%rsp)
    8776:      	movl	%eax, 0x60(%rsp)
    877a:      	movq	%rsi, 0x90(%rsp)
    8782:      	movq	%r11, 0x10(%rsp)
    8787:      	movl	$0x1, %eax
    878c:      	movq	(%rip), %rdi            # 0x8793 <generic_tracepoint_arg+0x2913>
    8793:      	movq	0x28(%rsp), %rbx
    8798:      	movq	%rbx, %rsi
    879b:      	callq	*%rax
    879d:      	movq	%rax, %r12
    87a0:      	movl	$0x1, %eax
    87a5:      	movq	(%rip), %rdi            # 0x87ac <generic_tracepoint_arg+0x292c>
    87ac:      	movq	%rbx, %rsi
    87af:      	callq	*%rax
    87b1:      	movq	%r12, 0x20(%rsp)
    87b6:      	testq	%r12, %r12
    87b9:      	je	0x94ab <generic_tracepoint_arg+0x362b>
    87bf:      	movl	$0x0, %ebx
    87c4:      	testq	%rax, %rax
    87c7:      	movq	(%rsp), %rdi
    87cb:      	movq	0x8(%rsp), %r9
    87d0:      	movq	0x10(%rsp), %r11
    87d5:      	je	0x94bb <generic_tracepoint_arg+0x363b>
    87db:      	movq	%rax, %r12
    87de:      	movl	0x60(%rsp), %ebx
    87e2:      	cmpl	$0x5, %ebx
    87e5:      	jg	0x8829 <generic_tracepoint_arg+0x29a9>
    87e7:      	movq	0x20(%rsp), %rax
    87ec:      	movb	%bpl, (%rax)
    87ef:      	leaq	0x1(%rax), %rdi
    87f3:      	movl	$0x4, %eax
    87f8:      	movq	0x18(%rsp), %rdx
    87fd:      	movl	%ebp, %esi
    87ff:      	callq	*%rax
    8801:      	movq	0x90(%rsp), %rsi
    8809:      	subl	%ebp, %esi
    880b:      	jbe	0x886c <generic_tracepoint_arg+0x29ec>
    880d:      	movq	0x20(%rsp), %rax
    8812:      	leaq	(%rax,%rbp), %rdi
    8816:      	incq	%rdi
    8819:      	andl	$0xfff, %esi            # imm = 0xFFF
    881f:      	movl	$0x4, %eax
    8824:      	movq	%r12, %rdx
    8827:      	jmp	0x886a <generic_tracepoint_arg+0x29ea>
    8829:      	movq	0x20(%rsp), %rax
    882e:      	movw	%bp, (%rax)
    8831:      	leaq	0x2(%rax), %rdi
    8835:      	movl	$0x4, %eax
    883a:      	movq	0x18(%rsp), %rdx
    883f:      	movl	%ebp, %esi
    8841:      	callq	*%rax
    8843:      	movq	0x90(%rsp), %rsi
    884b:      	subl	%ebp, %esi
    884d:      	jbe	0x886c <generic_tracepoint_arg+0x29ec>
    884f:      	movq	0x20(%rsp), %rax
    8854:      	leaq	(%rax,%rbp), %rdi
    8858:      	addq	$0x2, %rdi
    885c:      	andl	$0xfff, %esi            # imm = 0xFFF
    8862:      	movl	$0x4, %eax
    8867:      	movq	%r12, %rdx
    886a:      	callq	*%rax
    886c:      	movl	0x88(%rsp), %eax
    8873:      	movl	%eax, 0x38(%rsp)
    8877:      	cmpl	$0x4, %ebx
    887a:      	movq	0x8(%rsp), %r9
    887f:      	movq	0x10(%rsp), %r11
    8884:      	jle	0x88c0 <generic_tracepoint_arg+0x2a40>
    8886:      	cmpl	$0x7, %ebx
    8889:      	jg	0x8a87 <generic_tracepoint_arg+0x2c07>
    888f:      	cmpl	$0x5, %ebx
    8892:      	je	0x91ad <generic_tracepoint_arg+0x332d>
    8898:      	cmpl	$0x6, %ebx
    889b:      	je	0x9174 <generic_tracepoint_arg+0x32f4>
    88a1:      	cmpl	$0x7, %ebx
    88a4:      	jne	0x8d17 <generic_tracepoint_arg+0x2e97>
    88aa:      	movl	$0x1, %eax
    88af:      	leaq	0x38(%rsp), %rsi
    88b4:      	movq	(%rip), %rdi            # 0x88bb <generic_tracepoint_arg+0x2a3b>
    88bb:      	jmp	0x91d1 <generic_tracepoint_arg+0x3351>
    88c0:      	cmpl	$0x1, %ebx
    88c3:      	jle	0x8cf4 <generic_tracepoint_arg+0x2e74>
    88c9:      	cmpl	$0x2, %ebx
    88cc:      	je	0x919a <generic_tracepoint_arg+0x331a>
    88d2:      	cmpl	$0x3, %ebx
    88d5:      	je	0x9161 <generic_tracepoint_arg+0x32e1>
    88db:      	cmpl	$0x4, %ebx
    88de:      	jne	0x8d17 <generic_tracepoint_arg+0x2e97>
    88e4:      	movl	$0x1, %eax
    88e9:      	leaq	0x38(%rsp), %rsi
    88ee:      	movq	(%rip), %rdi            # 0x88f5 <generic_tracepoint_arg+0x2a75>
    88f5:      	jmp	0x91d1 <generic_tracepoint_arg+0x3351>
    88fa:      	cmpl	$0xc, %eax
    88fd:      	jne	0x89eb <generic_tracepoint_arg+0x2b6b>
    8903:      	movzbl	(%r12), %esi
    8908:      	testl	%esi, %edx
    890a:      	jne	0x6161 <generic_tracepoint_arg+0x2e1>
    8910:      	jmp	0x89eb <generic_tracepoint_arg+0x2b6b>
    8915:      	cmpl	$0xc, %eax
    8918:      	jne	0x8a2c <generic_tracepoint_arg+0x2bac>
    891e:      	movzwl	(%r12), %esi
    8923:      	testl	%esi, %edx
    8925:      	jne	0x6161 <generic_tracepoint_arg+0x2e1>
    892b:      	jmp	0x8a2c <generic_tracepoint_arg+0x2bac>
    8930:      	cmpl	$0x8, %eax
    8933:      	je	0x9014 <generic_tracepoint_arg+0x3194>
    8939:      	cmpl	$0x9, %eax
    893c:      	je	0x8fdb <generic_tracepoint_arg+0x315b>
    8942:      	cmpl	$0xa, %eax
    8945:      	jne	0x8c6c <generic_tracepoint_arg+0x2dec>
    894b:      	movl	$0x1, %eax
    8950:      	leaq	0x38(%rsp), %rsi
    8955:      	movq	(%rip), %rdi            # 0x895c <generic_tracepoint_arg+0x2adc>
    895c:      	jmp	0x9025 <generic_tracepoint_arg+0x31a5>
    8961:      	cmpl	$0xc, %ecx
    8964:      	je	0x896f <generic_tracepoint_arg+0x2aef>
    8966:      	cmpl	$0xa, %ecx
    8969:      	jne	0x8edd <generic_tracepoint_arg+0x305d>
    896f:      	cmpq	%rsi, (%r12)
    8973:      	jg	0x6161 <generic_tracepoint_arg+0x2e1>
    8979:      	jmp	0x8ef3 <generic_tracepoint_arg+0x3073>
    897e:      	cmpl	$0x8, %eax
    8981:      	je	0x90e4 <generic_tracepoint_arg+0x3264>
    8987:      	cmpl	$0x9, %eax
    898a:      	je	0x90ab <generic_tracepoint_arg+0x322b>
    8990:      	cmpl	$0xa, %eax
    8993:      	jne	0x8c6c <generic_tracepoint_arg+0x2dec>
    8999:      	movl	$0x1, %eax
    899e:      	leaq	0x38(%rsp), %rsi
    89a3:      	movq	(%rip), %rdi            # 0x89aa <generic_tracepoint_arg+0x2b2a>
    89aa:      	jmp	0x90f5 <generic_tracepoint_arg+0x3275>
    89af:      	movq	(%rsp), %rdi
    89b3:      	movq	0x8(%rsp), %r9
    89b8:      	movq	0x10(%rsp), %r11
    89bd:      	jmp	0x6150 <generic_tracepoint_arg+0x2d0>
    89c2:      	cmpl	$0x3, %eax
    89c5:      	je	0x8d30 <generic_tracepoint_arg+0x2eb0>
    89cb:      	cmpl	$0x7, %eax
    89ce:      	jne	0x8d22 <generic_tracepoint_arg+0x2ea2>
    89d4:      	movl	$0x9, %eax
    89d9:      	jmp	0x8d35 <generic_tracepoint_arg+0x2eb5>
    89de:      	movzbl	(%r12), %esi
    89e3:      	cmpl	%esi, %edx
    89e5:      	jb	0x6161 <generic_tracepoint_arg+0x2e1>
    89eb:      	cmpl	$0x11, %ecx
    89ee:      	jb	0x9541 <generic_tracepoint_arg+0x36c1>
    89f4:      	movl	0x18(%r13), %edx
    89f8:      	cmpl	$0x2, %eax
    89fb:      	jle	0x8cac <generic_tracepoint_arg+0x2e2c>
    8a01:      	leal	-0x3(%rax), %esi
    8a04:      	cmpl	$0x2, %esi
    8a07:      	jae	0x8f6c <generic_tracepoint_arg+0x30ec>
    8a0d:      	movzbl	(%r12), %esi
    8a12:      	cmpl	%esi, %edx
    8a14:      	je	0x6145 <generic_tracepoint_arg+0x2c5>
    8a1a:      	jmp	0x91fb <generic_tracepoint_arg+0x337b>
    8a1f:      	movzwl	(%r12), %esi
    8a24:      	cmpl	%esi, %edx
    8a26:      	jb	0x6161 <generic_tracepoint_arg+0x2e1>
    8a2c:      	cmpl	$0x11, %ecx
    8a2f:      	jb	0x9541 <generic_tracepoint_arg+0x36c1>
    8a35:      	movl	0x18(%r13), %edx
    8a39:      	cmpl	$0x2, %eax
    8a3c:      	jle	0x8cd0 <generic_tracepoint_arg+0x2e50>
    8a42:      	leal	-0x3(%rax), %esi
    8a45:      	cmpl	$0x2, %esi
    8a48:      	jae	0x8f87 <generic_tracepoint_arg+0x3107>
    8a4e:      	movzwl	(%r12), %esi
    8a53:      	cmpl	%esi, %edx
    8a55:      	je	0x6145 <generic_tracepoint_arg+0x2c5>
    8a5b:      	jmp	0x9243 <generic_tracepoint_arg+0x33c3>
    8a60:      	testl	%eax, %eax
    8a62:      	je	0x8fa2 <generic_tracepoint_arg+0x3122>
    8a68:      	cmpl	$0x1, %eax
    8a6b:      	jne	0x8c6c <generic_tracepoint_arg+0x2dec>
    8a71:      	movl	$0x1, %eax
    8a76:      	leaq	0x38(%rsp), %rsi
    8a7b:      	movq	(%rip), %rdi            # 0x8a82 <generic_tracepoint_arg+0x2c02>
    8a82:      	jmp	0x9025 <generic_tracepoint_arg+0x31a5>
    8a87:      	cmpl	$0x8, %ebx
    8a8a:      	je	0x91c0 <generic_tracepoint_arg+0x3340>
    8a90:      	cmpl	$0x9, %ebx
    8a93:      	je	0x9187 <generic_tracepoint_arg+0x3307>
    8a99:      	cmpl	$0xa, %ebx
    8a9c:      	jne	0x8d17 <generic_tracepoint_arg+0x2e97>
    8aa2:      	movl	$0x1, %eax
    8aa7:      	leaq	0x38(%rsp), %rsi
    8aac:      	movq	(%rip), %rdi            # 0x8ab3 <generic_tracepoint_arg+0x2c33>
    8ab3:      	jmp	0x91d1 <generic_tracepoint_arg+0x3351>
    8ab8:      	cmpl	%edx, %r8d
    8abb:      	setbe	%r8b
    8abf:      	cmpl	%edi, %edx
    8ac1:      	setbe	%dil
    8ac5:      	andb	%r8b, %dil
    8ac8:      	orb	%dil, %al
    8acb:      	cmpl	$0x21, %esi
    8ace:      	jb	0x8ecc <generic_tracepoint_arg+0x304c>
    8ad4:      	movl	0x28(%r13), %edi
    8ad8:      	movl	0x2c(%r13), %esi
    8adc:      	cmpl	$0xc, %ecx
    8adf:      	ja	0x8ebe <generic_tracepoint_arg+0x303e>
    8ae5:      	movl	$0x1402, %r8d           # imm = 0x1402
    8aeb:      	btl	%ecx, %r8d
    8aef:      	jae	0x8ebe <generic_tracepoint_arg+0x303e>
    8af5:      	cmpl	%edx, %edi
    8af7:      	setle	%cl
    8afa:      	cmpl	%esi, %edx
    8afc:      	setle	%dl
    8aff:      	jmp	0x8ec8 <generic_tracepoint_arg+0x3048>
    8b04:      	xorl	%ebx, %ebx
    8b06:      	jmp	0x8b0d <generic_tracepoint_arg+0x2c8d>
    8b08:      	movl	$0x1, %ebx
    8b0d:      	movq	(%rsp), %rdi
    8b11:      	movq	0x8(%rsp), %r9
    8b16:      	movq	%r15, %r11
    8b19:      	movq	0x68(%rsp), %r15
    8b1e:      	jmp	0x94bb <generic_tracepoint_arg+0x363b>
    8b23:      	cmpl	%eax, %edi
    8b25:      	movq	(%rsp), %rdi
    8b29:      	ja	0x8b33 <generic_tracepoint_arg+0x2cb3>
    8b2b:      	cmpl	%esi, %eax
    8b2d:      	jbe	0x6161 <generic_tracepoint_arg+0x2e1>
    8b33:      	cmpl	$0x21, %edx
    8b36:      	jb	0x5f9d <generic_tracepoint_arg+0x11d>
    8b3c:      	movl	0x28(%r13), %esi
    8b40:      	movl	0x2c(%r13), %edx
    8b44:      	cmpl	$0xc, %ecx
    8b47:      	ja	0x9040 <generic_tracepoint_arg+0x31c0>
    8b4d:      	movl	$0x1402, %r8d           # imm = 0x1402
    8b53:      	btl	%ecx, %r8d
    8b57:      	jae	0x9040 <generic_tracepoint_arg+0x31c0>
    8b5d:      	cmpl	%eax, %esi
    8b5f:      	jg	0x5f9d <generic_tracepoint_arg+0x11d>
    8b65:      	cmpl	%edx, %eax
    8b67:      	jle	0x6161 <generic_tracepoint_arg+0x2e1>
    8b6d:      	jmp	0x5f9d <generic_tracepoint_arg+0x11d>
    8b72:      	cmpl	%esi, (%r12)
    8b76:      	ja	0x6161 <generic_tracepoint_arg+0x2e1>
    8b7c:      	jmp	0x8b88 <generic_tracepoint_arg+0x2d08>
    8b7e:      	cmpl	%esi, (%r12)
    8b82:      	jb	0x6161 <generic_tracepoint_arg+0x2e1>
    8b88:      	cmpl	$0x11, %edx
    8b8b:      	jb	0x9541 <generic_tracepoint_arg+0x36c1>
    8b91:      	movl	0x18(%r13), %esi
    8b95:      	cmpl	$0x2, %eax
    8b98:      	jle	0x8bb5 <generic_tracepoint_arg+0x2d35>
    8b9a:      	leal	-0x3(%rax), %edi
    8b9d:      	cmpl	$0x2, %edi
    8ba0:      	jae	0x8beb <generic_tracepoint_arg+0x2d6b>
    8ba2:      	cmpl	%esi, (%r12)
    8ba6:      	movq	(%rsp), %rdi
    8baa:      	je	0x6145 <generic_tracepoint_arg+0x2c5>
    8bb0:      	jmp	0x92d0 <generic_tracepoint_arg+0x3450>
    8bb5:      	cmpl	$0x1, %eax
    8bb8:      	je	0x8c07 <generic_tracepoint_arg+0x2d87>
    8bba:      	cmpl	$0x2, %eax
    8bbd:      	jne	0x92d0 <generic_tracepoint_arg+0x3450>
    8bc3:      	cmpl	$0xc, %ecx
    8bc6:      	ja	0x92c6 <generic_tracepoint_arg+0x3446>
    8bcc:      	movl	$0x1402, %r8d           # imm = 0x1402
    8bd2:      	btl	%ecx, %r8d
    8bd6:      	jae	0x92c6 <generic_tracepoint_arg+0x3446>
    8bdc:      	cmpl	%esi, (%r12)
    8be0:      	jl	0x6161 <generic_tracepoint_arg+0x2e1>
    8be6:      	jmp	0x92d0 <generic_tracepoint_arg+0x3450>
    8beb:      	cmpl	$0xc, %eax
    8bee:      	movq	(%rsp), %rdi
    8bf2:      	jne	0x92d0 <generic_tracepoint_arg+0x3450>
    8bf8:      	testl	%esi, (%r12)
    8bfc:      	jne	0x6161 <generic_tracepoint_arg+0x2e1>
    8c02:      	jmp	0x92d0 <generic_tracepoint_arg+0x3450>
    8c07:      	cmpl	$0xc, %ecx
    8c0a:      	ja	0x92ba <generic_tracepoint_arg+0x343a>
    8c10:      	movl	$0x1402, %r8d           # imm = 0x1402
    8c16:      	btl	%ecx, %r8d
    8c1a:      	jae	0x92ba <generic_tracepoint_arg+0x343a>
    8c20:      	cmpl	%esi, (%r12)
    8c24:      	jg	0x6161 <generic_tracepoint_arg+0x2e1>
    8c2a:      	jmp	0x92d0 <generic_tracepoint_arg+0x3450>
    8c2f:      	cmpq	%rdx, %rdi
    8c32:      	setbe	%cl
    8c35:      	cmpq	%rsi, %rdx
    8c38:      	jmp	0x8ec5 <generic_tracepoint_arg+0x3045>
    8c3d:      	xorl	%ebx, %ebx
    8c3f:      	movq	0x68(%rsp), %r15
    8c44:      	jmp	0x94bb <generic_tracepoint_arg+0x363b>
    8c49:      	testl	%eax, %eax
    8c4b:      	je	0x9072 <generic_tracepoint_arg+0x31f2>
    8c51:      	cmpl	$0x1, %eax
    8c54:      	jne	0x8c6c <generic_tracepoint_arg+0x2dec>
    8c56:      	movl	$0x1, %eax
    8c5b:      	leaq	0x38(%rsp), %rsi
    8c60:      	movq	(%rip), %rdi            # 0x8c67 <generic_tracepoint_arg+0x2de7>
    8c67:      	jmp	0x90f5 <generic_tracepoint_arg+0x3275>
    8c6c:      	xorl	%ebx, %ebx
    8c6e:      	movl	0x4(%r13), %eax
    8c72:      	cmpq	$0x25, %rax
    8c76:      	jbe	0x9131 <generic_tracepoint_arg+0x32b1>
    8c7c:      	jmp	0x6150 <generic_tracepoint_arg+0x2d0>
    8c81:      	movq	(%rsp), %rdi
    8c85:      	movq	0x8(%rsp), %r9
    8c8a:      	movq	%r12, %r11
    8c8d:      	movzbl	%cl, %ebx
    8c90:      	jmp	0x6150 <generic_tracepoint_arg+0x2d0>
    8c95:      	cmpq	%rax, %rsi
    8c98:      	ja	0x5f9d <generic_tracepoint_arg+0x11d>
    8c9e:      	cmpq	%rdx, %rax
    8ca1:      	jbe	0x6161 <generic_tracepoint_arg+0x2e1>
    8ca7:      	jmp	0x5f9d <generic_tracepoint_arg+0x11d>
    8cac:      	cmpl	$0x1, %eax
    8caf:      	je	0x91ee <generic_tracepoint_arg+0x336e>
    8cb5:      	cmpl	$0x2, %eax
    8cb8:      	jne	0x91fb <generic_tracepoint_arg+0x337b>
    8cbe:      	movzbl	(%r12), %esi
    8cc3:      	cmpl	%esi, %edx
    8cc5:      	ja	0x6161 <generic_tracepoint_arg+0x2e1>
    8ccb:      	jmp	0x91fb <generic_tracepoint_arg+0x337b>
    8cd0:      	cmpl	$0x1, %eax
    8cd3:      	je	0x9236 <generic_tracepoint_arg+0x33b6>
    8cd9:      	cmpl	$0x2, %eax
    8cdc:      	jne	0x9243 <generic_tracepoint_arg+0x33c3>
    8ce2:      	movzwl	(%r12), %esi
    8ce7:      	cmpl	%esi, %edx
    8ce9:      	ja	0x6161 <generic_tracepoint_arg+0x2e1>
    8cef:      	jmp	0x9243 <generic_tracepoint_arg+0x33c3>
    8cf4:      	testl	%ebx, %ebx
    8cf6:      	je	0x914e <generic_tracepoint_arg+0x32ce>
    8cfc:      	cmpl	$0x1, %ebx
    8cff:      	jne	0x8d17 <generic_tracepoint_arg+0x2e97>
    8d01:      	movl	$0x1, %eax
    8d06:      	leaq	0x38(%rsp), %rsi
    8d0b:      	movq	(%rip), %rdi            # 0x8d12 <generic_tracepoint_arg+0x2e92>
    8d12:      	jmp	0x91d1 <generic_tracepoint_arg+0x3351>
    8d17:      	xorl	%ebx, %ebx
    8d19:      	movq	(%rsp), %rdi
    8d1d:      	jmp	0x94bb <generic_tracepoint_arg+0x363b>
    8d22:      	movl	$0xa, %eax
    8d27:      	jmp	0x8d35 <generic_tracepoint_arg+0x2eb5>
    8d29:      	movl	$0x6, %eax
    8d2e:      	jmp	0x8d35 <generic_tracepoint_arg+0x2eb5>
    8d30:      	movl	$0x8, %eax
    8d35:      	movl	%eax, %ecx
    8d37:      	andl	$0xf, %ecx
    8d3a:      	movl	0x10(%r13,%rcx,4), %ecx
    8d3f:      	cmpl	$-0x1, %ecx
    8d42:      	je	0x94ab <generic_tracepoint_arg+0x362b>
    8d48:      	movl	%ecx, 0x90(%rsp)
    8d4f:      	movl	%eax, 0x88(%rsp)
    8d56:      	movq	%rsi, 0x60(%rsp)
    8d5b:      	movl	$0x1, %eax
    8d60:      	movq	(%rip), %rdi            # 0x8d67 <generic_tracepoint_arg+0x2ee7>
    8d67:      	movq	0x28(%rsp), %rbx
    8d6c:      	movq	%rbx, %rsi
    8d6f:      	callq	*%rax
    8d71:      	movq	%rax, %r12
    8d74:      	movl	$0x1, %eax
    8d79:      	movq	(%rip), %rdi            # 0x8d80 <generic_tracepoint_arg+0x2f00>
    8d80:      	movq	%rbx, %rsi
    8d83:      	callq	*%rax
    8d85:      	movq	%r12, 0x20(%rsp)
    8d8a:      	testq	%r12, %r12
    8d8d:      	je	0x94ab <generic_tracepoint_arg+0x362b>
    8d93:      	movl	$0x0, %ebx
    8d98:      	testq	%rax, %rax
    8d9b:      	movq	(%rsp), %rdi
    8d9f:      	movq	0x8(%rsp), %r9
    8da4:      	movq	0x10(%rsp), %r11
    8da9:      	je	0x94bb <generic_tracepoint_arg+0x363b>
    8daf:      	movq	%rax, %r12
    8db2:      	movl	0x88(%rsp), %ebx
    8db9:      	cmpl	$0x5, %ebx
    8dbc:      	jg	0x8dfa <generic_tracepoint_arg+0x2f7a>
    8dbe:      	movq	0x20(%rsp), %rax
    8dc3:      	movb	%bpl, (%rax)
    8dc6:      	leaq	0x1(%rax), %rdi
    8dca:      	movl	$0x4, %eax
    8dcf:      	movq	0x18(%rsp), %rdx
    8dd4:      	movl	%ebp, %esi
    8dd6:      	callq	*%rax
    8dd8:      	movq	0x60(%rsp), %rsi
    8ddd:      	subl	%ebp, %esi
    8ddf:      	jbe	0x8e3a <generic_tracepoint_arg+0x2fba>
    8de1:      	movq	0x20(%rsp), %rax
    8de6:      	leaq	(%rax,%rbp), %rdi
    8dea:      	incq	%rdi
    8ded:      	andl	$0xfff, %esi            # imm = 0xFFF
    8df3:      	movl	$0x4, %eax
    8df8:      	jmp	0x8e35 <generic_tracepoint_arg+0x2fb5>
    8dfa:      	movq	0x20(%rsp), %rax
    8dff:      	movw	%bp, (%rax)
    8e02:      	leaq	0x2(%rax), %rdi
    8e06:      	movl	$0x4, %eax
    8e0b:      	movq	0x18(%rsp), %rdx
    8e10:      	movl	%ebp, %esi
    8e12:      	callq	*%rax
    8e14:      	movq	0x60(%rsp), %rsi
    8e19:      	subl	%ebp, %esi
    8e1b:      	jbe	0x8e3a <generic_tracepoint_arg+0x2fba>
    8e1d:      	movq	0x20(%rsp), %rax
    8e22:      	leaq	(%rax,%rbp), %rdi
    8e26:      	addq	$0x2, %rdi
    8e2a:      	andl	$0xfff, %esi            # imm = 0xFFF
    8e30:      	movl	$0x4, %eax
    8e35:      	movq	%r12, %rdx
    8e38:      	callq	*%rax
    8e3a:      	movl	0x90(%rsp), %eax
    8e41:      	movl	%eax, 0x38(%rsp)
    8e45:      	cmpl	$0x4, %ebx
    8e48:      	jle	0x8e84 <generic_tracepoint_arg+0x3004>
    8e4a:      	cmpl	$0x7, %ebx
    8e4d:      	jg	0x9289 <generic_tracepoint_arg+0x3409>
    8e53:      	cmpl	$0x5, %ebx
    8e56:      	je	0x946e <generic_tracepoint_arg+0x35ee>
    8e5c:      	cmpl	$0x6, %ebx
    8e5f:      	je	0x9435 <generic_tracepoint_arg+0x35b5>
    8e65:      	cmpl	$0x7, %ebx
    8e68:      	jne	0x94ab <generic_tracepoint_arg+0x362b>
    8e6e:      	movl	$0x1, %eax
    8e73:      	leaq	0x38(%rsp), %rsi
    8e78:      	movq	(%rip), %rdi            # 0x8e7f <generic_tracepoint_arg+0x2fff>
    8e7f:      	jmp	0x9492 <generic_tracepoint_arg+0x3612>
    8e84:      	cmpl	$0x1, %ebx
    8e87:      	jle	0x9374 <generic_tracepoint_arg+0x34f4>
    8e8d:      	cmpl	$0x2, %ebx
    8e90:      	je	0x945b <generic_tracepoint_arg+0x35db>
    8e96:      	cmpl	$0x3, %ebx
    8e99:      	je	0x9422 <generic_tracepoint_arg+0x35a2>
    8e9f:      	cmpl	$0x4, %ebx
    8ea2:      	jne	0x94ab <generic_tracepoint_arg+0x362b>
    8ea8:      	movl	$0x1, %eax
    8ead:      	leaq	0x38(%rsp), %rsi
    8eb2:      	movq	(%rip), %rdi            # 0x8eb9 <generic_tracepoint_arg+0x3039>
    8eb9:      	jmp	0x9492 <generic_tracepoint_arg+0x3612>
    8ebe:      	cmpl	%edx, %edi
    8ec0:      	setbe	%cl
    8ec3:      	cmpl	%esi, %edx
    8ec5:      	setbe	%dl
    8ec8:      	andb	%cl, %dl
    8eca:      	orb	%dl, %al
    8ecc:      	movq	(%rsp), %rdi
    8ed0:      	testb	%al, %al
    8ed2:      	je	0x6161 <generic_tracepoint_arg+0x2e1>
    8ed8:      	jmp	0x5f9d <generic_tracepoint_arg+0x11d>
    8edd:      	cmpq	%rsi, (%r12)
    8ee1:      	ja	0x6161 <generic_tracepoint_arg+0x2e1>
    8ee7:      	jmp	0x8ef3 <generic_tracepoint_arg+0x3073>
    8ee9:      	cmpq	%rsi, (%r12)
    8eed:      	jb	0x6161 <generic_tracepoint_arg+0x2e1>
    8ef3:      	cmpl	$0x21, %edx
    8ef6:      	jb	0x9541 <generic_tracepoint_arg+0x36c1>
    8efc:      	movq	0x28(%r13), %rdx
    8f00:      	cmpl	$0x2, %eax
    8f03:      	jle	0x8f2e <generic_tracepoint_arg+0x30ae>
    8f05:      	leal	-0x3(%rax), %ecx
    8f08:      	cmpl	$0x2, %ecx
    8f0b:      	jb	0x8f5d <generic_tracepoint_arg+0x30dd>
    8f0d:      	cmpl	$0x6, %eax
    8f10:      	je	0x6161 <generic_tracepoint_arg+0x2e1>
    8f16:      	cmpl	$0xc, %eax
    8f19:      	jne	0x5f9d <generic_tracepoint_arg+0x11d>
    8f1f:      	testq	%rdx, (%r12)
    8f23:      	jne	0x6161 <generic_tracepoint_arg+0x2e1>
    8f29:      	jmp	0x9541 <generic_tracepoint_arg+0x36c1>
    8f2e:      	cmpl	$0x1, %eax
    8f31:      	je	0x9055 <generic_tracepoint_arg+0x31d5>
    8f37:      	cmpl	$0x2, %eax
    8f3a:      	jne	0x5f9d <generic_tracepoint_arg+0x11d>
    8f40:      	cmpl	$0xc, %ecx
    8f43:      	je	0x8f4e <generic_tracepoint_arg+0x30ce>
    8f45:      	cmpl	$0xa, %ecx
    8f48:      	jne	0x93f1 <generic_tracepoint_arg+0x3571>
    8f4e:      	cmpq	%rdx, (%r12)
    8f52:      	jl	0x6161 <generic_tracepoint_arg+0x2e1>
    8f58:      	jmp	0x9541 <generic_tracepoint_arg+0x36c1>
    8f5d:      	cmpq	%rdx, (%r12)
    8f61:      	jne	0x9541 <generic_tracepoint_arg+0x36c1>
    8f67:      	jmp	0x6145 <generic_tracepoint_arg+0x2c5>
    8f6c:      	cmpl	$0xc, %eax
    8f6f:      	jne	0x91fb <generic_tracepoint_arg+0x337b>
    8f75:      	movzbl	(%r12), %esi
    8f7a:      	testl	%esi, %edx
    8f7c:      	jne	0x6161 <generic_tracepoint_arg+0x2e1>
    8f82:      	jmp	0x91fb <generic_tracepoint_arg+0x337b>
    8f87:      	cmpl	$0xc, %eax
    8f8a:      	jne	0x9243 <generic_tracepoint_arg+0x33c3>
    8f90:      	movzwl	(%r12), %esi
    8f95:      	testl	%esi, %edx
    8f97:      	jne	0x6161 <generic_tracepoint_arg+0x2e1>
    8f9d:      	jmp	0x9243 <generic_tracepoint_arg+0x33c3>
    8fa2:      	movl	$0x1, %eax
    8fa7:      	movq	(%rip), %rdi            # 0x8fae <generic_tracepoint_arg+0x312e>
    8fae:      	leaq	0x38(%rsp), %rsi
    8fb3:      	jmp	0x9025 <generic_tracepoint_arg+0x31a5>
    8fb5:      	movl	$0x1, %eax
    8fba:      	leaq	0x38(%rsp), %rsi
    8fbf:      	movq	(%rip), %rdi            # 0x8fc6 <generic_tracepoint_arg+0x3146>
    8fc6:      	jmp	0x9025 <generic_tracepoint_arg+0x31a5>
    8fc8:      	movl	$0x1, %eax
    8fcd:      	leaq	0x38(%rsp), %rsi
    8fd2:      	movq	(%rip), %rdi            # 0x8fd9 <generic_tracepoint_arg+0x3159>
    8fd9:      	jmp	0x9025 <generic_tracepoint_arg+0x31a5>
    8fdb:      	movl	$0x1, %eax
    8fe0:      	leaq	0x38(%rsp), %rsi
    8fe5:      	movq	(%rip), %rdi            # 0x8fec <generic_tracepoint_arg+0x316c>
    8fec:      	jmp	0x9025 <generic_tracepoint_arg+0x31a5>
    8fee:      	movl	$0x1, %eax
    8ff3:      	leaq	0x38(%rsp), %rsi
    8ff8:      	movq	(%rip), %rdi            # 0x8fff <generic_tracepoint_arg+0x317f>
    8fff:      	jmp	0x9025 <generic_tracepoint_arg+0x31a5>
    9001:      	movl	$0x1, %eax
    9006:      	leaq	0x38(%rsp), %rsi
    900b:      	movq	(%rip), %rdi            # 0x9012 <generic_tracepoint_arg+0x3192>
    9012:      	jmp	0x9025 <generic_tracepoint_arg+0x31a5>
    9014:      	movl	$0x1, %eax
    9019:      	leaq	0x38(%rsp), %rsi
    901e:      	movq	(%rip), %rdi            # 0x9025 <generic_tracepoint_arg+0x31a5>
    9025:      	callq	*%rax
    9027:      	testq	%rax, %rax
    902a:      	je	0x9113 <generic_tracepoint_arg+0x3293>
    9030:      	movq	%rax, %rdi
    9033:      	movl	$0x1, %eax
    9038:      	movq	%r12, %rsi
    903b:      	jmp	0x9107 <generic_tracepoint_arg+0x3287>
    9040:      	cmpl	%eax, %esi
    9042:      	ja	0x5f9d <generic_tracepoint_arg+0x11d>
    9048:      	cmpl	%edx, %eax
    904a:      	jbe	0x6161 <generic_tracepoint_arg+0x2e1>
    9050:      	jmp	0x5f9d <generic_tracepoint_arg+0x11d>
    9055:      	cmpl	$0xc, %ecx
    9058:      	je	0x9063 <generic_tracepoint_arg+0x31e3>
    905a:      	cmpl	$0xa, %ecx
    905d:      	jne	0x9400 <generic_tracepoint_arg+0x3580>
    9063:      	cmpq	%rdx, (%r12)
    9067:      	jg	0x6161 <generic_tracepoint_arg+0x2e1>
    906d:      	jmp	0x9541 <generic_tracepoint_arg+0x36c1>
    9072:      	movl	$0x1, %eax
    9077:      	movq	(%rip), %rdi            # 0x907e <generic_tracepoint_arg+0x31fe>
    907e:      	leaq	0x38(%rsp), %rsi
    9083:      	jmp	0x90f5 <generic_tracepoint_arg+0x3275>
    9085:      	movl	$0x1, %eax
    908a:      	leaq	0x38(%rsp), %rsi
    908f:      	movq	(%rip), %rdi            # 0x9096 <generic_tracepoint_arg+0x3216>
    9096:      	jmp	0x90f5 <generic_tracepoint_arg+0x3275>
    9098:      	movl	$0x1, %eax
    909d:      	leaq	0x38(%rsp), %rsi
    90a2:      	movq	(%rip), %rdi            # 0x90a9 <generic_tracepoint_arg+0x3229>
    90a9:      	jmp	0x90f5 <generic_tracepoint_arg+0x3275>
    90ab:      	movl	$0x1, %eax
    90b0:      	leaq	0x38(%rsp), %rsi
    90b5:      	movq	(%rip), %rdi            # 0x90bc <generic_tracepoint_arg+0x323c>
    90bc:      	jmp	0x90f5 <generic_tracepoint_arg+0x3275>
    90be:      	movl	$0x1, %eax
    90c3:      	leaq	0x38(%rsp), %rsi
    90c8:      	movq	(%rip), %rdi            # 0x90cf <generic_tracepoint_arg+0x324f>
    90cf:      	jmp	0x90f5 <generic_tracepoint_arg+0x3275>
    90d1:      	movl	$0x1, %eax
    90d6:      	leaq	0x38(%rsp), %rsi
    90db:      	movq	(%rip), %rdi            # 0x90e2 <generic_tracepoint_arg+0x3262>
    90e2:      	jmp	0x90f5 <generic_tracepoint_arg+0x3275>
    90e4:      	movl	$0x1, %eax
    90e9:      	leaq	0x38(%rsp), %rsi
    90ee:      	movq	(%rip), %rdi            # 0x90f5 <generic_tracepoint_arg+0x3275>
    90f5:      	callq	*%rax
    90f7:      	testq	%rax, %rax
    90fa:      	je	0x9113 <generic_tracepoint_arg+0x3293>
    90fc:      	movq	%rax, %rdi
    90ff:      	movl	$0x1, %eax
    9104:      	movq	%rbp, %rsi
    9107:      	callq	*%rax
    9109:      	xorl	%ebx, %ebx
    910b:      	testq	%rax, %rax
    910e:      	setne	%bl
    9111:      	jmp	0x9115 <generic_tracepoint_arg+0x3295>
    9113:      	xorl	%ebx, %ebx
    9115:      	movq	(%rsp), %rdi
    9119:      	movq	0x8(%rsp), %r9
    911e:      	movq	0x10(%rsp), %r11
    9123:      	movl	0x4(%r13), %eax
    9127:      	cmpq	$0x25, %rax
    912b:      	ja	0x6150 <generic_tracepoint_arg+0x2d0>
    9131:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    913b:      	btq	%rax, %rcx
    913f:      	jae	0x6150 <generic_tracepoint_arg+0x2d0>
    9145:      	xorq	$0x1, %rbx
    9149:      	jmp	0x6150 <generic_tracepoint_arg+0x2d0>
    914e:      	movl	$0x1, %eax
    9153:      	movq	(%rip), %rdi            # 0x915a <generic_tracepoint_arg+0x32da>
    915a:      	leaq	0x38(%rsp), %rsi
    915f:      	jmp	0x91d1 <generic_tracepoint_arg+0x3351>
    9161:      	movl	$0x1, %eax
    9166:      	leaq	0x38(%rsp), %rsi
    916b:      	movq	(%rip), %rdi            # 0x9172 <generic_tracepoint_arg+0x32f2>
    9172:      	jmp	0x91d1 <generic_tracepoint_arg+0x3351>
    9174:      	movl	$0x1, %eax
    9179:      	leaq	0x38(%rsp), %rsi
    917e:      	movq	(%rip), %rdi            # 0x9185 <generic_tracepoint_arg+0x3305>
    9185:      	jmp	0x91d1 <generic_tracepoint_arg+0x3351>
    9187:      	movl	$0x1, %eax
    918c:      	leaq	0x38(%rsp), %rsi
    9191:      	movq	(%rip), %rdi            # 0x9198 <generic_tracepoint_arg+0x3318>
    9198:      	jmp	0x91d1 <generic_tracepoint_arg+0x3351>
    919a:      	movl	$0x1, %eax
    919f:      	leaq	0x38(%rsp), %rsi
    91a4:      	movq	(%rip), %rdi            # 0x91ab <generic_tracepoint_arg+0x332b>
    91ab:      	jmp	0x91d1 <generic_tracepoint_arg+0x3351>
    91ad:      	movl	$0x1, %eax
    91b2:      	leaq	0x38(%rsp), %rsi
    91b7:      	movq	(%rip), %rdi            # 0x91be <generic_tracepoint_arg+0x333e>
    91be:      	jmp	0x91d1 <generic_tracepoint_arg+0x3351>
    91c0:      	movl	$0x1, %eax
    91c5:      	leaq	0x38(%rsp), %rsi
    91ca:      	movq	(%rip), %rdi            # 0x91d1 <generic_tracepoint_arg+0x3351>
    91d1:      	callq	*%rax
    91d3:      	testq	%rax, %rax
    91d6:      	je	0x94ab <generic_tracepoint_arg+0x362b>
    91dc:      	movq	%rax, %rdi
    91df:      	movl	$0x1, %eax
    91e4:      	movq	0x20(%rsp), %rsi
    91e9:      	jmp	0x7968 <generic_tracepoint_arg+0x1ae8>
    91ee:      	movzbl	(%r12), %esi
    91f3:      	cmpl	%esi, %edx
    91f5:      	jb	0x6161 <generic_tracepoint_arg+0x2e1>
    91fb:      	cmpl	$0x15, %ecx
    91fe:      	jb	0x9541 <generic_tracepoint_arg+0x36c1>
    9204:      	movl	0x1c(%r13), %ecx
    9208:      	cmpl	$0x2, %eax
    920b:      	jle	0x939b <generic_tracepoint_arg+0x351b>
    9211:      	leal	-0x3(%rax), %edx
    9214:      	cmpl	$0x2, %edx
    9217:      	jb	0x93d8 <generic_tracepoint_arg+0x3558>
    921d:      	cmpl	$0x6, %eax
    9220:      	je	0x6161 <generic_tracepoint_arg+0x2e1>
    9226:      	cmpl	$0xc, %eax
    9229:      	jne	0x5f9d <generic_tracepoint_arg+0x11d>
    922f:      	movzbl	(%r12), %edx
    9234:      	jmp	0x927c <generic_tracepoint_arg+0x33fc>
    9236:      	movzwl	(%r12), %esi
    923b:      	cmpl	%esi, %edx
    923d:      	jb	0x6161 <generic_tracepoint_arg+0x2e1>
    9243:      	cmpl	$0x15, %ecx
    9246:      	jb	0x9541 <generic_tracepoint_arg+0x36c1>
    924c:      	movl	0x1c(%r13), %ecx
    9250:      	cmpl	$0x2, %eax
    9253:      	jle	0x93b4 <generic_tracepoint_arg+0x3534>
    9259:      	leal	-0x3(%rax), %edx
    925c:      	cmpl	$0x2, %edx
    925f:      	jb	0x93df <generic_tracepoint_arg+0x355f>
    9265:      	cmpl	$0x6, %eax
    9268:      	je	0x6161 <generic_tracepoint_arg+0x2e1>
    926e:      	cmpl	$0xc, %eax
    9271:      	jne	0x5f9d <generic_tracepoint_arg+0x11d>
    9277:      	movzwl	(%r12), %edx
    927c:      	testl	%edx, %ecx
    927e:      	jne	0x6161 <generic_tracepoint_arg+0x2e1>
    9284:      	jmp	0x9541 <generic_tracepoint_arg+0x36c1>
    9289:      	cmpl	$0x8, %ebx
    928c:      	je	0x9481 <generic_tracepoint_arg+0x3601>
    9292:      	cmpl	$0x9, %ebx
    9295:      	je	0x9448 <generic_tracepoint_arg+0x35c8>
    929b:      	cmpl	$0xa, %ebx
    929e:      	jne	0x94ab <generic_tracepoint_arg+0x362b>
    92a4:      	movl	$0x1, %eax
    92a9:      	leaq	0x38(%rsp), %rsi
    92ae:      	movq	(%rip), %rdi            # 0x92b5 <generic_tracepoint_arg+0x3435>
    92b5:      	jmp	0x9492 <generic_tracepoint_arg+0x3612>
    92ba:      	cmpl	%esi, (%r12)
    92be:      	ja	0x6161 <generic_tracepoint_arg+0x2e1>
    92c4:      	jmp	0x92d0 <generic_tracepoint_arg+0x3450>
    92c6:      	cmpl	%esi, (%r12)
    92ca:      	jb	0x6161 <generic_tracepoint_arg+0x2e1>
    92d0:      	cmpl	$0x15, %edx
    92d3:      	jb	0x9541 <generic_tracepoint_arg+0x36c1>
    92d9:      	movl	0x1c(%r13), %edx
    92dd:      	cmpl	$0x2, %eax
    92e0:      	jle	0x930b <generic_tracepoint_arg+0x348b>
    92e2:      	leal	-0x3(%rax), %ecx
    92e5:      	cmpl	$0x2, %ecx
    92e8:      	jb	0x933f <generic_tracepoint_arg+0x34bf>
    92ea:      	cmpl	$0x6, %eax
    92ed:      	je	0x6161 <generic_tracepoint_arg+0x2e1>
    92f3:      	cmpl	$0xc, %eax
    92f6:      	jne	0x5f9d <generic_tracepoint_arg+0x11d>
    92fc:      	testl	%edx, (%r12)
    9300:      	jne	0x6161 <generic_tracepoint_arg+0x2e1>
    9306:      	jmp	0x9541 <generic_tracepoint_arg+0x36c1>
    930b:      	cmpl	$0x1, %eax
    930e:      	je	0x934e <generic_tracepoint_arg+0x34ce>
    9310:      	cmpl	$0x2, %eax
    9313:      	jne	0x5f9d <generic_tracepoint_arg+0x11d>
    9319:      	cmpl	$0xc, %ecx
    931c:      	ja	0x952b <generic_tracepoint_arg+0x36ab>
    9322:      	movl	$0x1402, %esi           # imm = 0x1402
    9327:      	btl	%ecx, %esi
    932a:      	jae	0x952b <generic_tracepoint_arg+0x36ab>
    9330:      	cmpl	%edx, (%r12)
    9334:      	jl	0x6161 <generic_tracepoint_arg+0x2e1>
    933a:      	jmp	0x9541 <generic_tracepoint_arg+0x36c1>
    933f:      	cmpl	%edx, (%r12)
    9343:      	je	0x6145 <generic_tracepoint_arg+0x2c5>
    9349:      	jmp	0x9541 <generic_tracepoint_arg+0x36c1>
    934e:      	cmpl	$0xc, %ecx
    9351:      	ja	0x9537 <generic_tracepoint_arg+0x36b7>
    9357:      	movl	$0x1402, %esi           # imm = 0x1402
    935c:      	btl	%ecx, %esi
    935f:      	jae	0x9537 <generic_tracepoint_arg+0x36b7>
    9365:      	cmpl	%edx, (%r12)
    9369:      	jg	0x6161 <generic_tracepoint_arg+0x2e1>
    936f:      	jmp	0x9541 <generic_tracepoint_arg+0x36c1>
    9374:      	testl	%ebx, %ebx
    9376:      	je	0x940f <generic_tracepoint_arg+0x358f>
    937c:      	cmpl	$0x1, %ebx
    937f:      	jne	0x94ab <generic_tracepoint_arg+0x362b>
    9385:      	movl	$0x1, %eax
    938a:      	leaq	0x38(%rsp), %rsi
    938f:      	movq	(%rip), %rdi            # 0x9396 <generic_tracepoint_arg+0x3516>
    9396:      	jmp	0x9492 <generic_tracepoint_arg+0x3612>
    939b:      	cmpl	$0x1, %eax
    939e:      	je	0x9515 <generic_tracepoint_arg+0x3695>
    93a4:      	cmpl	$0x2, %eax
    93a7:      	jne	0x5f9d <generic_tracepoint_arg+0x11d>
    93ad:      	movzbl	(%r12), %edx
    93b2:      	jmp	0x93cb <generic_tracepoint_arg+0x354b>
    93b4:      	cmpl	$0x1, %eax
    93b7:      	je	0x951c <generic_tracepoint_arg+0x369c>
    93bd:      	cmpl	$0x2, %eax
    93c0:      	jne	0x5f9d <generic_tracepoint_arg+0x11d>
    93c6:      	movzwl	(%r12), %edx
    93cb:      	cmpl	%edx, %ecx
    93cd:      	ja	0x6161 <generic_tracepoint_arg+0x2e1>
    93d3:      	jmp	0x9541 <generic_tracepoint_arg+0x36c1>
    93d8:      	movzbl	(%r12), %edx
    93dd:      	jmp	0x93e4 <generic_tracepoint_arg+0x3564>
    93df:      	movzwl	(%r12), %edx
    93e4:      	cmpl	%edx, %ecx
    93e6:      	je	0x6145 <generic_tracepoint_arg+0x2c5>
    93ec:      	jmp	0x9541 <generic_tracepoint_arg+0x36c1>
    93f1:      	cmpq	%rdx, (%r12)
    93f5:      	jb	0x6161 <generic_tracepoint_arg+0x2e1>
    93fb:      	jmp	0x9541 <generic_tracepoint_arg+0x36c1>
    9400:      	cmpq	%rdx, (%r12)
    9404:      	ja	0x6161 <generic_tracepoint_arg+0x2e1>
    940a:      	jmp	0x9541 <generic_tracepoint_arg+0x36c1>
    940f:      	movl	$0x1, %eax
    9414:      	movq	(%rip), %rdi            # 0x941b <generic_tracepoint_arg+0x359b>
    941b:      	leaq	0x38(%rsp), %rsi
    9420:      	jmp	0x9492 <generic_tracepoint_arg+0x3612>
    9422:      	movl	$0x1, %eax
    9427:      	leaq	0x38(%rsp), %rsi
    942c:      	movq	(%rip), %rdi            # 0x9433 <generic_tracepoint_arg+0x35b3>
    9433:      	jmp	0x9492 <generic_tracepoint_arg+0x3612>
    9435:      	movl	$0x1, %eax
    943a:      	leaq	0x38(%rsp), %rsi
    943f:      	movq	(%rip), %rdi            # 0x9446 <generic_tracepoint_arg+0x35c6>
    9446:      	jmp	0x9492 <generic_tracepoint_arg+0x3612>
    9448:      	movl	$0x1, %eax
    944d:      	leaq	0x38(%rsp), %rsi
    9452:      	movq	(%rip), %rdi            # 0x9459 <generic_tracepoint_arg+0x35d9>
    9459:      	jmp	0x9492 <generic_tracepoint_arg+0x3612>
    945b:      	movl	$0x1, %eax
    9460:      	leaq	0x38(%rsp), %rsi
    9465:      	movq	(%rip), %rdi            # 0x946c <generic_tracepoint_arg+0x35ec>
    946c:      	jmp	0x9492 <generic_tracepoint_arg+0x3612>
    946e:      	movl	$0x1, %eax
    9473:      	leaq	0x38(%rsp), %rsi
    9478:      	movq	(%rip), %rdi            # 0x947f <generic_tracepoint_arg+0x35ff>
    947f:      	jmp	0x9492 <generic_tracepoint_arg+0x3612>
    9481:      	movl	$0x1, %eax
    9486:      	leaq	0x38(%rsp), %rsi
    948b:      	movq	(%rip), %rdi            # 0x9492 <generic_tracepoint_arg+0x3612>
    9492:      	callq	*%rax
    9494:      	testq	%rax, %rax
    9497:      	je	0x94ab <generic_tracepoint_arg+0x362b>
    9499:      	movq	%rax, %rdi
    949c:      	movl	$0x1, %eax
    94a1:      	movq	0x20(%rsp), %rsi
    94a6:      	jmp	0x7968 <generic_tracepoint_arg+0x1ae8>
    94ab:      	xorl	%ebx, %ebx
    94ad:      	movq	(%rsp), %rdi
    94b1:      	movq	0x8(%rsp), %r9
    94b6:      	movq	0x10(%rsp), %r11
    94bb:      	movl	0x4(%r13), %eax
    94bf:      	cmpq	$0x25, %rax
    94c3:      	ja	0x6150 <generic_tracepoint_arg+0x2d0>
    94c9:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    94d3:      	btq	%rax, %rcx
    94d7:      	jae	0x6150 <generic_tracepoint_arg+0x2d0>
    94dd:      	xorl	%eax, %eax
    94df:      	testq	%rbx, %rbx
    94e2:      	sete	%al
    94e5:      	movq	%rax, %rbx
    94e8:      	jmp	0x6150 <generic_tracepoint_arg+0x2d0>
    94ed:      	xorl	%ebx, %ebx
    94ef:      	movq	(%rsp), %rdi
    94f3:      	movq	0x8(%rsp), %r9
    94f8:      	movq	0x10(%rsp), %r11
    94fd:      	movq	0x68(%rsp), %r15
    9502:      	movl	0x4(%r13), %eax
    9506:      	cmpq	$0x25, %rax
    950a:      	jbe	0x9131 <generic_tracepoint_arg+0x32b1>
    9510:      	jmp	0x6150 <generic_tracepoint_arg+0x2d0>
    9515:      	movzbl	(%r12), %edx
    951a:      	jmp	0x9521 <generic_tracepoint_arg+0x36a1>
    951c:      	movzwl	(%r12), %edx
    9521:      	cmpl	%edx, %ecx
    9523:      	jb	0x6161 <generic_tracepoint_arg+0x2e1>
    9529:      	jmp	0x9541 <generic_tracepoint_arg+0x36c1>
    952b:      	cmpl	%edx, (%r12)
    952f:      	jb	0x6161 <generic_tracepoint_arg+0x2e1>
    9535:      	jmp	0x9541 <generic_tracepoint_arg+0x36c1>
    9537:      	cmpl	%edx, (%r12)
    953b:      	ja	0x6161 <generic_tracepoint_arg+0x2e1>
    9541:      	orl	$0x2, %eax
    9544:      	cmpl	$0x6, %eax
    9547:      	je	0x6161 <generic_tracepoint_arg+0x2e1>
    954d:      	jmp	0x5f9d <generic_tracepoint_arg+0x11d>
    9552:      	nopw	%cs:(%rax,%rax)

0000000000009560 <generic_tracepoint_actions>:
    9560:      	pushq	%rbp
    9561:      	pushq	%r15
    9563:      	pushq	%r14
    9565:      	pushq	%r13
    9567:      	pushq	%r12
    9569:      	pushq	%rbx
    956a:      	subq	$0xa8, %rsp
    9571:      	movq	%rdi, 0x70(%rsp)
    9576:      	movl	$0x0, 0x84(%rsp)
    9581:      	movq	(%rip), %rdi            # 0x9588 <generic_tracepoint_actions+0x28>
    9588:      	leaq	0x84(%rsp), %rsi
    9590:      	movl	$0x1, %eax
    9595:      	callq	*%rax
    9597:      	testq	%rax, %rax
    959a:      	je	0xa285 <generic_tracepoint_actions+0xd25>
    95a0:      	movq	%rax, %rsi
    95a3:      	movl	0x5f04(%rax), %ebx
    95a9:      	cmpl	$0x2, %ebx
    95ac:      	jl	0xa285 <generic_tracepoint_actions+0xd25>
    95b2:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    95b9:      	movq	(%rip), %rdi            # 0x95c0 <generic_tracepoint_actions+0x60>
    95c0:      	movl	$0x1, %eax
    95c5:      	callq	*%rax
    95c7:      	testq	%rax, %rax
    95ca:      	je	0xa285 <generic_tracepoint_actions+0xd25>
    95d0:      	movq	%rax, %r14
    95d3:      	movl	%ebx, %eax
    95d5:      	andl	$0x7ff, %eax            # imm = 0x7FF
    95da:      	addl	(%r14,%rax), %ebx
    95de:      	movl	$0x0, 0x88(%rsp)
    95e9:      	movq	(%rip), %rdi            # 0x95f0 <generic_tracepoint_actions+0x90>
    95f0:      	leaq	0x88(%rsp), %rsi
    95f8:      	movl	$0x1, %eax
    95fd:      	andl	$0x7ff, %ebx            # imm = 0x7FF
    9603:      	callq	*%rax
    9605:      	testq	%rax, %rax
    9608:      	je	0x9634 <generic_tracepoint_actions+0xd4>
    960a:      	xorl	%ecx, %ecx
    960c:      	cmpb	$0x0, (%rax)
    960f:      	sete	%cl
    9612:      	movq	%rcx, %rax
    9615:      	xorq	$0x9, %rax
    9619:      	movq	%rax, 0x98(%rsp)
    9621:      	movq	%rcx, 0x68(%rsp)
    9626:      	xorq	$0x5, %rcx
    962a:      	movq	%rcx, 0x90(%rsp)
    9632:      	jmp	0x9655 <generic_tracepoint_actions+0xf5>
    9634:      	movl	$0x4, %eax
    9639:      	movq	%rax, 0x90(%rsp)
    9641:      	movb	$0x1, %al
    9643:      	movq	%rax, 0x68(%rsp)
    9648:      	movl	$0x8, %eax
    964d:      	movq	%rax, 0x98(%rsp)
    9655:      	addq	%rbx, %r14
    9658:      	movb	$0x1, %al
    965a:      	movl	%eax, 0x58(%rsp)
    965e:      	xorl	%ebp, %ebp
    9660:      	xorl	%r15d, %r15d
    9663:      	movq	%r14, 0x30(%rsp)
    9668:      	jmp	0x9698 <generic_tracepoint_actions+0x138>
    966a:      	incl	%r15d
    966d:      	movl	0x4(%r14,%r15,4), %eax
    9672:      	movl	%eax, 0x78(%rdx)
    9675:      	nopw	%cs:(%rax,%rax)
    9680:      	movq	%r12, 0x70(%rdx)
    9684:      	incl	%r15d
    9687:      	movl	%r15d, %ebx
    968a:      	incl	%ebp
    968c:      	movl	%ebx, %r15d
    968f:      	cmpl	$0x3, %ebp
    9692:      	je	0xa261 <generic_tracepoint_actions+0xd01>
    9698:      	leal	0x4(,%r15,4), %eax
    96a0:      	cmpl	(%r14), %eax
    96a3:      	jae	0xa261 <generic_tracepoint_actions+0xd01>
    96a9:      	movl	%r15d, %eax
    96ac:      	movslq	0x4(%r14,%rax,4), %r12
    96b1:      	movl	$0x0, 0x8c(%rsp)
    96bc:      	movl	$0x1, %eax
    96c1:      	movq	(%rip), %rdi            # 0x96c8 <generic_tracepoint_actions+0x168>
    96c8:      	leaq	0x8c(%rsp), %rsi
    96d0:      	callq	*%rax
    96d2:      	xorl	%ebx, %ebx
    96d4:      	testq	%rax, %rax
    96d7:      	je	0x968a <generic_tracepoint_actions+0x12a>
    96d9:      	movq	%rax, %rdx
    96dc:      	cmpl	$0x7, %r12d
    96e0:      	jg	0x9710 <generic_tracepoint_actions+0x1b0>
    96e2:      	cmpl	$0x3, %r12d
    96e6:      	jg	0x974c <generic_tracepoint_actions+0x1ec>
    96e8:      	cmpl	$0x1, %r12d
    96ec:      	jg	0x9898 <generic_tracepoint_actions+0x338>
    96f2:      	testl	%r12d, %r12d
    96f5:      	je	0x9a9e <generic_tracepoint_actions+0x53e>
    96fb:      	cmpl	$0x1, %r12d
    96ff:      	je	0x98b1 <generic_tracepoint_actions+0x351>
    9705:      	jmp	0x9680 <generic_tracepoint_actions+0x120>
    970a:      	nopw	(%rax,%rax)
    9710:      	cmpl	$0xb, %r12d
    9714:      	jg	0x9866 <generic_tracepoint_actions+0x306>
    971a:      	leal	-0xa(%r12), %eax
    971f:      	cmpl	$0x2, %eax
    9722:      	jb	0x9934 <generic_tracepoint_actions+0x3d4>
    9728:      	cmpl	$0x8, %r12d
    972c:      	je	0x99f2 <generic_tracepoint_actions+0x492>
    9732:      	cmpl	$0x9, %r12d
    9736:      	jne	0x9680 <generic_tracepoint_actions+0x120>
    973c:      	movq	%rdx, %rbx
    973f:      	incl	%r15d
    9742:      	movl	0x4(%r14,%r15,4), %eax
    9747:      	jmp	0x9b60 <generic_tracepoint_actions+0x600>
    974c:      	leal	-0x6(%r12), %eax
    9751:      	cmpl	$0x2, %eax
    9754:      	jb	0x966a <generic_tracepoint_actions+0x10a>
    975a:      	cmpl	$0x4, %r12d
    975e:      	je	0x99ff <generic_tracepoint_actions+0x49f>
    9764:      	cmpl	$0x5, %r12d
    9768:      	jne	0x9680 <generic_tracepoint_actions+0x120>
    976e:      	leal	0x1(%r15), %eax
    9772:      	movl	0x4(%r14,%rax,4), %eax
    9777:      	addl	$0x2, %r15d
    977b:      	movl	0x4(%r14,%r15,4), %ebx
    9780:      	movq	$0x0, 0x10(%rsp)
    9789:      	movq	$0x0, 0x8(%rsp)
    9792:      	andl	$0x7, %eax
    9795:      	cmpl	$0x4, %eax
    9798:      	ja	0x9680 <generic_tracepoint_actions+0x120>
    979e:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    97a6:      	jne	0x9680 <generic_tracepoint_actions+0x120>
    97ac:      	movq	0x5e78(%rdx,%rax,8), %rax
    97b4:      	andl	$0x7ff, %eax            # imm = 0x7FF
    97b9:      	movl	0x90(%rdx,%rax), %eax
    97c0:      	movl	%eax, 0x10(%rsp)
    97c4:      	movl	$0xe, %eax
    97c9:      	movq	%rdx, %r13
    97cc:      	callq	*%rax
    97ce:      	shrq	$0x20, %rax
    97d2:      	movq	%rax, 0x8(%rsp)
    97d7:      	movl	$0x1, %eax
    97dc:      	leaq	0x8(%rsp), %rsi
    97e1:      	movq	(%rip), %rdi            # 0x97e8 <generic_tracepoint_actions+0x288>
    97e8:      	callq	*%rax
    97ea:      	movq	%r13, %rdx
    97ed:      	testq	%rax, %rax
    97f0:      	je	0x9680 <generic_tracepoint_actions+0x120>
    97f6:      	andl	$0x7, %ebx
    97f9:      	cmpl	$0x4, %ebx
    97fc:      	ja	0x9680 <generic_tracepoint_actions+0x120>
    9802:      	cmpl	$0x0, 0x5ea0(%rdx,%rbx,4)
    980a:      	jne	0x9680 <generic_tracepoint_actions+0x120>
    9810:      	movq	0x5e78(%rdx,%rbx,8), %rcx
    9818:      	movl	$0x0, 0x14(%rsp)
    9820:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    9826:      	movl	0x90(%rdx,%rcx), %ecx
    982d:      	movl	%ecx, 0x10(%rsp)
    9831:      	movq	%rax, %rbx
    9834:      	movl	$0xe, %eax
    9839:      	callq	*%rax
    983b:      	shrq	$0x20, %rax
    983f:      	movq	%rax, 0x8(%rsp)
    9844:      	movl	$0x2, %eax
    9849:      	xorl	%ecx, %ecx
    984b:      	leaq	0x8(%rsp), %rsi
    9850:      	movq	(%rip), %rdi            # 0x9857 <generic_tracepoint_actions+0x2f7>
    9857:      	movq	%rbx, %rdx
    985a:      	xorl	%ecx, %ecx
    985c:      	callq	*%rax
    985e:      	movq	%r13, %rdx
    9861:      	jmp	0x9680 <generic_tracepoint_actions+0x120>
    9866:      	cmpl	$0xc, %r12d
    986a:      	je	0x9b94 <generic_tracepoint_actions+0x634>
    9870:      	cmpl	$0xd, %r12d
    9874:      	je	0x9a1a <generic_tracepoint_actions+0x4ba>
    987a:      	cmpl	$0xe, %r12d
    987e:      	jne	0x9680 <generic_tracepoint_actions+0x120>
    9884:      	movq	%rdx, %rbx
    9887:      	addl	$0x2, %r15d
    988b:      	movq	0x98(%rsp), %r14
    9893:      	jmp	0x9a0d <generic_tracepoint_actions+0x4ad>
    9898:      	movl	$0x9, %eax
    989d:      	cmpl	$0x2, %r12d
    98a1:      	je	0x9b5d <generic_tracepoint_actions+0x5fd>
    98a7:      	cmpl	$0x3, %r12d
    98ab:      	jne	0x9680 <generic_tracepoint_actions+0x120>
    98b1:      	movq	%rdx, %r13
    98b4:      	leal	0x1(%r15), %eax
    98b8:      	movq	%r14, %rcx
    98bb:      	movl	0x4(%r14,%rax,4), %r14d
    98c0:      	addl	$0x2, %r15d
    98c4:      	movl	0x4(%rcx,%r15,4), %eax
    98c9:      	movq	%rax, 0x18(%rsp)
    98ce:      	movq	$0x0, 0x10(%rsp)
    98d7:      	movq	$0x0, 0x8(%rsp)
    98e0:      	movl	$0x0, 0x20(%rsp)
    98e8:      	movl	$0x1, %eax
    98ed:      	leaq	0x20(%rsp), %rsi
    98f2:      	movq	(%rip), %rdi            # 0x98f9 <generic_tracepoint_actions+0x399>
    98f9:      	callq	*%rax
    98fb:      	xorl	%ecx, %ecx
    98fd:      	testq	%rax, %rax
    9900:      	je	0x9e55 <generic_tracepoint_actions+0x8f5>
    9906:      	andl	$0x7, %r14d
    990a:      	cmpl	$0x4, %r14d
    990e:      	movq	%r13, %rdx
    9911:      	ja	0x9922 <generic_tracepoint_actions+0x3c2>
    9913:      	cmpl	$0x0, 0x5ea0(%rdx,%r14,4)
    991c:      	je	0x9ca0 <generic_tracepoint_actions+0x740>
    9922:      	movq	0x30(%rsp), %r14
    9927:      	testl	%ecx, %ecx
    9929:      	jne	0x968a <generic_tracepoint_actions+0x12a>
    992f:      	jmp	0x9680 <generic_tracepoint_actions+0x120>
    9934:      	incl	%r15d
    9937:      	movl	0x4(%r14,%r15,4), %eax
    993c:      	andl	$0x7, %eax
    993f:      	xorl	%ecx, %ecx
    9941:      	cmpl	$0x4, %eax
    9944:      	ja	0x9e5d <generic_tracepoint_actions+0x8fd>
    994a:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    9952:      	jne	0x9e5d <generic_tracepoint_actions+0x8fd>
    9958:      	movq	0x5e78(%rdx,%rax,8), %rax
    9960:      	andl	$0x7ff, %eax            # imm = 0x7FF
    9965:      	movq	0xb8(%rdx,%rax), %rax
    996d:      	movq	%rax, 0x20(%rsp)
    9972:      	testq	%rax, %rax
    9975:      	je	0x9e5d <generic_tracepoint_actions+0x8fd>
    997b:      	movq	%rdx, %r13
    997e:      	cmpl	$0xa, %r12d
    9982:      	jne	0x9e6a <generic_tracepoint_actions+0x90a>
    9988:      	movl	$0xe, %eax
    998d:      	callq	*%rax
    998f:      	movq	%rax, 0x18(%rsp)
    9994:      	shrq	$0x20, %rax
    9998:      	movl	%eax, 0x8(%rsp)
    999c:      	movl	$0x1, %eax
    99a1:      	leaq	0x8(%rsp), %rsi
    99a6:      	movq	(%rip), %rdi            # 0x99ad <generic_tracepoint_actions+0x44d>
    99ad:      	callq	*%rax
    99af:      	xorl	%ecx, %ecx
    99b1:      	testq	%rax, %rax
    99b4:      	movq	%r13, %rdx
    99b7:      	je	0x9e5d <generic_tracepoint_actions+0x8fd>
    99bd:      	movl	(%rax), %ecx
    99bf:      	movl	%ecx, 0x8(%rsp)
    99c3:      	movq	0x18(%rsp), %rcx
    99c8:      	movl	%ecx, 0xc(%rsp)
    99cc:      	movq	0x8(%rax), %rax
    99d0:      	movq	%rax, 0x10(%rsp)
    99d5:      	xorl	%ecx, %ecx
    99d7:      	movl	$0x2, %eax
    99dc:      	leaq	0x20(%rsp), %rsi
    99e1:      	leaq	0x8(%rsp), %rdx
    99e6:      	movq	(%rip), %rdi            # 0x99ed <generic_tracepoint_actions+0x48d>
    99ed:      	jmp	0x9d59 <generic_tracepoint_actions+0x7f9>
    99f2:      	movl	$0x0, 0x58(%rsp)
    99fa:      	jmp	0x9680 <generic_tracepoint_actions+0x120>
    99ff:      	movq	%rdx, %rbx
    9a02:      	incl	%r15d
    9a05:      	movq	0x90(%rsp), %r14
    9a0d:      	movl	%r15d, %r13d
    9a10:      	leaq	0x8(%rsp), %rsi
    9a15:      	jmp	0xa1de <generic_tracepoint_actions+0xc7e>
    9a1a:      	movq	%rdx, 0x18(%rsp)
    9a1f:      	movl	$0xe, %eax
    9a24:      	callq	*%rax
    9a26:      	movq	%rax, 0x48(%rsp)
    9a2b:      	movl	$0x1, %eax
    9a30:      	leaq	0x48(%rsp), %rsi
    9a35:      	movq	(%rip), %rdi            # 0x9a3c <generic_tracepoint_actions+0x4dc>
    9a3c:      	callq	*%rax
    9a3e:      	testq	%rax, %rax
    9a41:      	je	0x9a94 <generic_tracepoint_actions+0x534>
    9a43:      	movq	0x4(%rax), %rax
    9a47:      	movq	%rax, 0x20(%rsp)
    9a4c:      	movl	$0x2, 0x28(%rsp)
    9a54:      	movl	$0x1, %eax
    9a59:      	leaq	0x20(%rsp), %rbx
    9a5e:      	movq	(%rip), %r13            # 0x9a65 <generic_tracepoint_actions+0x505>
    9a65:      	movq	%r13, %rdi
    9a68:      	movq	%rbx, %rsi
    9a6b:      	callq	*%rax
    9a6d:      	movl	$0x1, 0x3c(%rsp)
    9a75:      	testq	%rax, %rax
    9a78:      	je	0x9d6f <generic_tracepoint_actions+0x80f>
    9a7e:      	lock
    9a7f:      	incl	(%rax)
    9a81:      	movl	$0x3, %eax
    9a86:      	leaq	0x48(%rsp), %rsi
    9a8b:      	movq	(%rip), %rdi            # 0x9a92 <generic_tracepoint_actions+0x532>
    9a92:      	callq	*%rax
    9a94:      	movq	0x18(%rsp), %rdx
    9a99:      	jmp	0x9680 <generic_tracepoint_actions+0x120>
    9a9e:      	movq	%rdx, 0x18(%rsp)
    9aa3:      	leal	0x1(%r15), %eax
    9aa7:      	movl	0x4(%r14,%rax,4), %r13d
    9aac:      	leal	0x2(%r15), %eax
    9ab0:      	movl	0x4(%r14,%rax,4), %ebx
    9ab5:      	movl	$0x7d, %eax
    9aba:      	callq	*%rax
    9abc:      	movq	%rax, 0x8(%rsp)
    9ac1:      	movl	$0x0, 0x48(%rsp)
    9ac9:      	movq	%r13, 0xa0(%rsp)
    9ad1:      	testq	%r13, %r13
    9ad4:      	je	0xa0c2 <generic_tracepoint_actions+0xb62>
    9ada:      	movl	$0x1, %eax
    9adf:      	movq	(%rip), %rdi            # 0x9ae6 <generic_tracepoint_actions+0x586>
    9ae6:      	leaq	0x48(%rsp), %rsi
    9aeb:      	callq	*%rax
    9aed:      	testq	%rax, %rax
    9af0:      	je	0xa0c2 <generic_tracepoint_actions+0xb62>
    9af6:      	movq	%rax, 0x40(%rsp)
    9afb:      	movq	%rax, %r13
    9afe:      	movl	$0x1, %eax
    9b03:      	leaq	0x48(%rsp), %rsi
    9b08:      	movq	(%rip), %rdi            # 0x9b0f <generic_tracepoint_actions+0x5af>
    9b0f:      	callq	*%rax
    9b11:      	movq	%rax, %rdx
    9b14:      	movq	0x18(%rsp), %rcx
    9b19:      	movq	0x60(%rcx), %rax
    9b1d:      	movq	%rax, (%r13)
    9b21:      	movq	0x70(%rcx), %rax
    9b25:      	movq	%r13, 0x60(%rsp)
    9b2a:      	movq	%rax, 0x8(%r13)
    9b2e:      	xorl	%r13d, %r13d
    9b31:      	movl	$0x0, %eax
    9b36:      	cmpl	$0x2, %ebx
    9b39:      	je	0x9f00 <generic_tracepoint_actions+0x9a0>
    9b3f:      	cmpl	$0x1, %ebx
    9b42:      	je	0x9efd <generic_tracepoint_actions+0x99d>
    9b48:      	testl	%ebx, %ebx
    9b4a:      	jne	0xa0c2 <generic_tracepoint_actions+0xb62>
    9b50:      	movq	0x18(%rsp), %rax
    9b55:      	movl	0x7c(%rax), %eax
    9b58:      	jmp	0x9f00 <generic_tracepoint_actions+0x9a0>
    9b5d:      	movq	%rdx, %rbx
    9b60:      	movl	%r15d, %r13d
    9b63:      	movl	$0x3, %r14d
    9b69:      	cmpb	$0x0, 0x68(%rsp)
    9b6e:      	leaq	0x8(%rsp), %rsi
    9b73:      	je	0xa1de <generic_tracepoint_actions+0xc7e>
    9b79:      	movslq	%eax, %rdi
    9b7c:      	movl	$0x6d, %eax
    9b81:      	movq	%rsi, %r14
    9b84:      	callq	*%rax
    9b86:      	movq	%r14, %rsi
    9b89:      	movl	$0x2, %r14d
    9b8f:      	jmp	0xa1de <generic_tracepoint_actions+0xc7e>
    9b94:      	leal	0x3(%r15), %r13d
    9b98:      	movl	$0x7, %r14d
    9b9e:      	cmpb	$0x0, 0x68(%rsp)
    9ba3:      	je	0x9c93 <generic_tracepoint_actions+0x733>
    9ba9:      	movl	%r13d, %eax
    9bac:      	movq	0x30(%rsp), %rcx
    9bb1:      	movl	0x4(%rcx,%rax,4), %eax
    9bb5:      	cmpq	$0x4, %rax
    9bb9:      	movl	%r13d, 0x18(%rsp)
    9bbe:      	ja	0x9bce <generic_tracepoint_actions+0x66e>
    9bc0:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    9bc8:      	je	0xa14c <generic_tracepoint_actions+0xbec>
    9bce:      	xorl	%r14d, %r14d
    9bd1:      	leal	0x2(%r15), %eax
    9bd5:      	incl	%r15d
    9bd8:      	movq	0x30(%rsp), %rcx
    9bdd:      	movl	0x4(%rcx,%rax,4), %r13d
    9be2:      	movl	0x4(%rcx,%r15,4), %r15d
    9be7:      	movq	%rdx, %rbx
    9bea:      	movl	0x60(%rdx), %ecx
    9bed:      	movl	$0xe, %eax
    9bf2:      	shlq	$0x20, %r14
    9bf6:      	orq	%rcx, %r14
    9bf9:      	callq	*%rax
    9bfb:      	movq	%rax, 0x78(%rsp)
    9c00:      	movw	%r15w, 0x20(%rsp)
    9c06:      	movw	%r13w, 0x22(%rsp)
    9c0c:      	movq	%r14, 0x24(%rsp)
    9c11:      	movl	$0x1, %eax
    9c16:      	movq	(%rip), %r14            # 0x9c1d <generic_tracepoint_actions+0x6bd>
    9c1d:      	leaq	0x78(%rsp), %r13
    9c22:      	movq	%r14, %rdi
    9c25:      	movq	%r13, %rsi
    9c28:      	callq	*%rax
    9c2a:      	testq	%rax, %rax
    9c2d:      	je	0x9dd5 <generic_tracepoint_actions+0x875>
    9c33:      	movq	%rax, %r15
    9c36:      	movq	0x4(%rax), %rax
    9c3a:      	movq	%rax, 0x48(%rsp)
    9c3f:      	movl	$0x1, 0x50(%rsp)
    9c47:      	movl	$0x1, %eax
    9c4c:      	leaq	0x48(%rsp), %r13
    9c51:      	movq	(%rip), %r14            # 0x9c58 <generic_tracepoint_actions+0x6f8>
    9c58:      	movq	%r14, %rdi
    9c5b:      	movq	%r13, %rsi
    9c5e:      	callq	*%rax
    9c60:      	movl	$0x1, 0x5c(%rsp)
    9c68:      	testq	%rax, %rax
    9c6b:      	je	0x9e90 <generic_tracepoint_actions+0x930>
    9c71:      	lock
    9c72:      	incl	(%rax)
    9c74:      	movl	0x18(%rsp), %r13d
    9c79:      	movl	0x28(%rsp), %eax
    9c7d:      	movl	%eax, 0x8(%r15)
    9c81:      	movq	0x20(%rsp), %rax
    9c86:      	movq	%rax, (%r15)
    9c89:      	leaq	0x8(%rsp), %rsi
    9c8e:      	jmp	0xa1d8 <generic_tracepoint_actions+0xc78>
    9c93:      	movq	%rdx, %rbx
    9c96:      	leaq	0x8(%rsp), %rsi
    9c9b:      	jmp	0xa1de <generic_tracepoint_actions+0xc7e>
    9ca0:      	movq	%rax, 0x40(%rsp)
    9ca5:      	movq	0x5e78(%rdx,%r14,8), %rax
    9cad:      	movl	$0x0, 0x14(%rsp)
    9cb5:      	andl	$0x7ff, %eax            # imm = 0x7FF
    9cba:      	movl	0x90(%rdx,%rax), %eax
    9cc1:      	movl	%eax, 0x10(%rsp)
    9cc5:      	movl	$0xe, %eax
    9cca:      	callq	*%rax
    9ccc:      	shrq	$0x20, %rax
    9cd0:      	movq	%rax, 0x8(%rsp)
    9cd5:      	cmpl	$0x1, %r12d
    9cd9:      	jne	0x9e3f <generic_tracepoint_actions+0x8df>
    9cdf:      	movq	0x18(%rsp), %rax
    9ce4:      	andl	$0x7, %eax
    9ce7:      	cmpl	$0x4, %eax
    9cea:      	movq	0x30(%rsp), %r14
    9cef:      	movl	$0x0, %ecx
    9cf4:      	ja	0x9e5a <generic_tracepoint_actions+0x8fa>
    9cfa:      	movq	%r13, %rdx
    9cfd:      	cmpl	$0x0, 0x5ea0(%r13,%rax,4)
    9d06:      	jne	0x9e5d <generic_tracepoint_actions+0x8fd>
    9d0c:      	movq	0x5e78(%rdx,%rax,8), %rax
    9d14:      	andl	$0x7ff, %eax            # imm = 0x7FF
    9d19:      	addq	%rax, %rdx
    9d1c:      	addq	$0x90, %rdx
    9d23:      	movl	0x90(%r13,%rax), %esi
    9d2b:      	andl	$0xfff, %esi            # imm = 0xFFF
    9d31:      	addq	$0x8, %rsi
    9d35:      	movl	$0x4, %eax
    9d3a:      	movq	0x40(%rsp), %rdi
    9d3f:      	callq	*%rax
    9d41:      	xorl	%ecx, %ecx
    9d43:      	movl	$0x2, %eax
    9d48:      	leaq	0x8(%rsp), %rsi
    9d4d:      	movq	(%rip), %rdi            # 0x9d54 <generic_tracepoint_actions+0x7f4>
    9d54:      	movq	0x40(%rsp), %rdx
    9d59:      	xorl	%ecx, %ecx
    9d5b:      	callq	*%rax
    9d5d:      	xorl	%ecx, %ecx
    9d5f:      	movq	%r13, %rdx
    9d62:      	testl	%ecx, %ecx
    9d64:      	jne	0x968a <generic_tracepoint_actions+0x12a>
    9d6a:      	jmp	0x9680 <generic_tracepoint_actions+0x120>
    9d6f:      	movl	$0x2, %eax
    9d74:      	movl	$0x1, %ecx
    9d79:      	leaq	0x3c(%rsp), %rdx
    9d7e:      	movq	%r13, %rdi
    9d81:      	movq	%rbx, %rsi
    9d84:      	callq	*%rax
    9d86:      	testq	%rax, %rax
    9d89:      	je	0x9a81 <generic_tracepoint_actions+0x521>
    9d8f:      	movq	%rax, %r13
    9d92:      	negl	%eax
    9d94:      	movw	%ax, 0x8(%rsp)
    9d99:      	movw	$0x3, 0xa(%rsp)
    9da0:      	movabsq	$0x20000003b, %rax      # imm = 0x20000003B
    9daa:      	movq	%rax, 0xc(%rsp)
    9daf:      	movl	$0x1, %eax
    9db4:      	leaq	0x8(%rsp), %rsi
    9db9:      	movq	(%rip), %rbx            # 0x9dc0 <generic_tracepoint_actions+0x860>
    9dc0:      	movq	%rbx, %rdi
    9dc3:      	callq	*%rax
    9dc5:      	testq	%rax, %rax
    9dc8:      	je	0xa166 <generic_tracepoint_actions+0xc06>
    9dce:      	incl	(%rax)
    9dd0:      	jmp	0xa186 <generic_tracepoint_actions+0xc26>
    9dd5:      	movl	$0x2, %eax
    9dda:      	xorl	%ecx, %ecx
    9ddc:      	leaq	0x20(%rsp), %rdx
    9de1:      	movq	%r14, %rdi
    9de4:      	movq	%r13, %rsi
    9de7:      	xorl	%ecx, %ecx
    9de9:      	callq	*%rax
    9deb:      	testq	%rax, %rax
    9dee:      	leaq	0x8(%rsp), %rsi
    9df3:      	movl	0x18(%rsp), %r13d
    9df8:      	je	0xa1d8 <generic_tracepoint_actions+0xc78>
    9dfe:      	negl	%eax
    9e00:      	movw	%ax, 0x8(%rsp)
    9e05:      	movw	$0x3, 0xa(%rsp)
    9e0c:      	movabsq	$0x20000006b, %rax      # imm = 0x20000006B
    9e16:      	movq	%rax, 0xc(%rsp)
    9e1b:      	movl	$0x1, %eax
    9e20:      	movq	(%rip), %r14            # 0x9e27 <generic_tracepoint_actions+0x8c7>
    9e27:      	movq	%r14, %rdi
    9e2a:      	movq	%rsi, %r15
    9e2d:      	callq	*%rax
    9e2f:      	testq	%rax, %rax
    9e32:      	je	0xa1b7 <generic_tracepoint_actions+0xc57>
    9e38:      	incl	(%rax)
    9e3a:      	jmp	0xa1d5 <generic_tracepoint_actions+0xc75>
    9e3f:      	movl	$0x3, %eax
    9e44:      	leaq	0x8(%rsp), %rsi
    9e49:      	movq	(%rip), %rdi            # 0x9e50 <generic_tracepoint_actions+0x8f0>
    9e50:      	callq	*%rax
    9e52:      	movq	%rax, %rcx
    9e55:      	movq	0x30(%rsp), %r14
    9e5a:      	movq	%r13, %rdx
    9e5d:      	testl	%ecx, %ecx
    9e5f:      	jne	0x968a <generic_tracepoint_actions+0x12a>
    9e65:      	jmp	0x9680 <generic_tracepoint_actions+0x120>
    9e6a:      	movl	$0x3, %eax
    9e6f:      	leaq	0x20(%rsp), %rsi
    9e74:      	movq	(%rip), %rdi            # 0x9e7b <generic_tracepoint_actions+0x91b>
    9e7b:      	callq	*%rax
    9e7d:      	movq	%rax, %rcx
    9e80:      	movq	%r13, %rdx
    9e83:      	testl	%ecx, %ecx
    9e85:      	jne	0x968a <generic_tracepoint_actions+0x12a>
    9e8b:      	jmp	0x9680 <generic_tracepoint_actions+0x120>
    9e90:      	movl	$0x2, %eax
    9e95:      	movl	$0x1, %ecx
    9e9a:      	leaq	0x5c(%rsp), %rdx
    9e9f:      	movq	%r14, %rdi
    9ea2:      	movq	%r13, %rsi
    9ea5:      	callq	*%rax
    9ea7:      	testq	%rax, %rax
    9eaa:      	movl	0x18(%rsp), %r13d
    9eaf:      	je	0x9c79 <generic_tracepoint_actions+0x719>
    9eb5:      	movq	%rax, 0x40(%rsp)
    9eba:      	negl	%eax
    9ebc:      	movw	%ax, 0x8(%rsp)
    9ec1:      	movw	$0x3, 0xa(%rsp)
    9ec8:      	movabsq	$0x20000003b, %rax      # imm = 0x20000003B
    9ed2:      	movq	%rax, 0xc(%rsp)
    9ed7:      	movl	$0x1, %eax
    9edc:      	leaq	0x8(%rsp), %rsi
    9ee1:      	movq	(%rip), %r14            # 0x9ee8 <generic_tracepoint_actions+0x988>
    9ee8:      	movq	%r14, %rdi
    9eeb:      	callq	*%rax
    9eed:      	testq	%rax, %rax
    9ef0:      	je	0xa20e <generic_tracepoint_actions+0xcae>
    9ef6:      	incl	(%rax)
    9ef8:      	jmp	0xa22e <generic_tracepoint_actions+0xcce>
    9efd:      	movl	0x10(%rcx), %eax
    9f00:      	movl	%eax, %eax
    9f02:      	movq	0x60(%rsp), %rcx
    9f07:      	movq	%rax, 0x10(%rcx)
    9f0b:      	movq	0x40(%rsp), %rdi
    9f10:      	addq	$0x18, %rdi
    9f14:      	movl	$0x4, %eax
    9f19:      	movl	$0xc8, %ecx
    9f1e:      	movq	%rdi, 0x40(%rsp)
    9f23:      	movl	$0xc8, %esi
    9f28:      	callq	*%rax
    9f2a:      	xorl	%r14d, %r14d
    9f2d:      	jmp	0x9f3e <generic_tracepoint_actions+0x9de>
    9f2f:      	nop
    9f30:      	addq	$0x4, %r14
    9f34:      	cmpq	$0x14, %r14
    9f38:      	je	0xa069 <generic_tracepoint_actions+0xb09>
    9f3e:      	movl	$0x0, 0x20(%rsp)
    9f46:      	movl	$0x1, %eax
    9f4b:      	movq	(%rip), %rdi            # 0x9f52 <generic_tracepoint_actions+0x9f2>
    9f52:      	leaq	0x20(%rsp), %rsi
    9f57:      	callq	*%rax
    9f59:      	testq	%rax, %rax
    9f5c:      	je	0xa069 <generic_tracepoint_actions+0xb09>
    9f62:      	movq	%rax, %rsi
    9f65:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    9f6c:      	movl	$0x1, %eax
    9f71:      	movq	(%rip), %rdi            # 0x9f78 <generic_tracepoint_actions+0xa18>
    9f78:      	callq	*%rax
    9f7a:      	testq	%rax, %rax
    9f7d:      	je	0xa069 <generic_tracepoint_actions+0xb09>
    9f83:      	cmpl	$-0x1, 0x40(%rax,%r14)
    9f89:      	movq	0x18(%rsp), %rdx
    9f8e:      	je	0xa069 <generic_tracepoint_actions+0xb09>
    9f94:      	movq	0x5e78(%rdx,%r14,2), %rax
    9f9c:      	movl	0x4(%rdx), %ecx
    9f9f:      	cmpq	%rcx, %rax
    9fa2:      	jge	0xa069 <generic_tracepoint_actions+0xb09>
    9fa8:      	cmpq	$0x10, %r14
    9fac:      	je	0xa019 <generic_tracepoint_actions+0xab9>
    9fae:      	movl	$0x0, 0x20(%rsp)
    9fb6:      	movl	$0x1, %eax
    9fbb:      	movq	(%rip), %rdi            # 0x9fc2 <generic_tracepoint_actions+0xa62>
    9fc2:      	leaq	0x20(%rsp), %rsi
    9fc7:      	callq	*%rax
    9fc9:      	testq	%rax, %rax
    9fcc:      	je	0xa00c <generic_tracepoint_actions+0xaac>
    9fce:      	movq	%rax, %rsi
    9fd1:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    9fd8:      	movl	$0x1, %eax
    9fdd:      	movq	(%rip), %rdi            # 0x9fe4 <generic_tracepoint_actions+0xa84>
    9fe4:      	callq	*%rax
    9fe6:      	testq	%rax, %rax
    9fe9:      	je	0xa00c <generic_tracepoint_actions+0xaac>
    9feb:      	cmpl	$-0x1, 0x44(%rax,%r14)
    9ff1:      	movq	0x18(%rsp), %rdx
    9ff6:      	movq	0x5e78(%rdx,%r14,2), %rax
    9ffe:      	je	0xa019 <generic_tracepoint_actions+0xab9>
    a000:      	movl	0x5e80(%rdx,%r14,2), %ebx
    a008:      	subl	%eax, %ebx
    a00a:      	jmp	0xa021 <generic_tracepoint_actions+0xac1>
    a00c:      	movq	0x18(%rsp), %rdx
    a011:      	movq	0x5e78(%rdx,%r14,2), %rax
    a019:      	movl	0x4(%rdx), %ebx
    a01c:      	subl	%eax, %ebx
    a01e:      	addl	$0x4, %ebx
    a021:      	testl	%ebx, %ebx
    a023:      	jle	0x9f30 <generic_tracepoint_actions+0x9d0>
    a029:      	addl	$0x3ffc, %eax           # imm = 0x3FFC
    a02e:      	andl	$0x3fff, %eax           # imm = 0x3FFF
    a033:      	cmpl	$0x28, %ebx
    a036:      	movl	$0x28, %ecx
    a03b:      	cmovgel	%ecx, %ebx
    a03e:      	movzbl	%r13b, %r13d
    a042:      	movq	0x40(%rsp), %rcx
    a047:      	leaq	(%rcx,%r13), %rdi
    a04b:      	addq	%rax, %rdx
    a04e:      	addq	$0x90, %rdx
    a055:      	movl	$0x4, %eax
    a05a:      	movl	%ebx, %esi
    a05c:      	callq	*%rax
    a05e:      	addl	%r13d, %ebx
    a061:      	movl	%ebx, %r13d
    a064:      	jmp	0x9f30 <generic_tracepoint_actions+0x9d0>
    a069:      	movl	$0x1, %eax
    a06e:      	movq	(%rip), %rdi            # 0xa075 <generic_tracepoint_actions+0xb15>
    a075:      	movq	0x60(%rsp), %rsi
    a07a:      	callq	*%rax
    a07c:      	testq	%rax, %rax
    a07f:      	movq	0x30(%rsp), %r14
    a084:      	je	0xa0a6 <generic_tracepoint_actions+0xb46>
    a086:      	imulq	$-0xf4240, 0xa0(%rsp), %rcx # imm = 0xFFF0BDC0
    a092:      	addq	0x8(%rsp), %rcx
    a097:      	cmpq	%rcx, (%rax)
    a09a:      	jbe	0xa0a6 <generic_tracepoint_actions+0xb46>
    a09c:      	movl	$0x0, 0x58(%rsp)
    a0a4:      	jmp	0xa0c2 <generic_tracepoint_actions+0xb62>
    a0a6:      	movl	$0x2, %eax
    a0ab:      	xorl	%ecx, %ecx
    a0ad:      	movq	(%rip), %rdi            # 0xa0b4 <generic_tracepoint_actions+0xb54>
    a0b4:      	leaq	0x8(%rsp), %rdx
    a0b9:      	movq	0x60(%rsp), %rsi
    a0be:      	xorl	%ecx, %ecx
    a0c0:      	callq	*%rax
    a0c2:      	leal	0x3(%r15), %eax
    a0c6:      	cmpl	$0x0, 0x4(%r14,%rax,4)
    a0cc:      	movq	0x18(%rsp), %rdx
    a0d1:      	je	0xa0fa <generic_tracepoint_actions+0xb9a>
    a0d3:      	orb	$0x2, 0x1(%rdx)
    a0d7:      	movl	$0x1b, %eax
    a0dc:      	xorl	%ecx, %ecx
    a0de:      	movq	(%rip), %rsi            # 0xa0e5 <generic_tracepoint_actions+0xb85>
    a0e5:      	movq	0x70(%rsp), %rdi
    a0ea:      	xorl	%edx, %edx
    a0ec:      	callq	*%rax
    a0ee:      	movq	0x18(%rsp), %rdx
    a0f3:      	movq	%rax, 0x80(%rdx)
    a0fa:      	leal	0x4(%r15), %eax
    a0fe:      	cmpl	$0x0, 0x4(%r14,%rax,4)
    a104:      	je	0xa133 <generic_tracepoint_actions+0xbd3>
    a106:      	orb	$0x4, 0x1(%rdx)
    a10a:      	movl	$0x1b, %eax
    a10f:      	movq	(%rip), %rsi            # 0xa116 <generic_tracepoint_actions+0xbb6>
    a116:      	movl	$0x100, %ecx            # imm = 0x100
    a11b:      	movq	0x70(%rsp), %rdi
    a120:      	movl	$0x100, %edx            # imm = 0x100
    a125:      	callq	*%rax
    a127:      	movq	0x18(%rsp), %rdx
    a12c:      	movq	%rax, 0x88(%rdx)
    a133:      	addl	$0x5, %r15d
    a137:      	cmpl	$0x0, 0x4(%r14,%r15,4)
    a13d:      	je	0x9680 <generic_tracepoint_actions+0x120>
    a143:      	orb	$0x8, 0x1(%rdx)
    a147:      	jmp	0x9680 <generic_tracepoint_actions+0x120>
    a14c:      	movq	0x5e78(%rdx,%rax,8), %rax
    a154:      	andl	$0x7ff, %eax            # imm = 0x7FF
    a159:      	movq	0x90(%rdx,%rax), %r14
    a161:      	jmp	0x9bd1 <generic_tracepoint_actions+0x671>
    a166:      	movl	$0x1, 0x78(%rsp)
    a16e:      	movl	$0x2, %eax
    a173:      	xorl	%ecx, %ecx
    a175:      	leaq	0x78(%rsp), %rdx
    a17a:      	leaq	0x8(%rsp), %rsi
    a17f:      	movq	%rbx, %rdi
    a182:      	xorl	%ecx, %ecx
    a184:      	callq	*%rax
    a186:      	testl	%r13d, %r13d
    a189:      	je	0x9a81 <generic_tracepoint_actions+0x521>
    a18f:      	movl	$0x1, %eax
    a194:      	leaq	0x20(%rsp), %rsi
    a199:      	movq	(%rip), %rdi            # 0xa1a0 <generic_tracepoint_actions+0xc40>
    a1a0:      	callq	*%rax
    a1a2:      	testq	%rax, %rax
    a1a5:      	je	0x9a81 <generic_tracepoint_actions+0x521>
    a1ab:      	movl	0x3c(%rsp), %ecx
    a1af:      	lock
    a1b0:      	addl	%ecx, (%rax)
    a1b2:      	jmp	0x9a81 <generic_tracepoint_actions+0x521>
    a1b7:      	movl	$0x1, 0x48(%rsp)
    a1bf:      	movl	$0x2, %eax
    a1c4:      	xorl	%ecx, %ecx
    a1c6:      	movq	%r15, %rsi
    a1c9:      	leaq	0x48(%rsp), %rdx
    a1ce:      	movq	%r14, %rdi
    a1d1:      	xorl	%ecx, %ecx
    a1d3:      	callq	*%rax
    a1d5:      	movq	%r15, %rsi
    a1d8:      	movl	$0x6, %r14d
    a1de:      	movl	$0x0, 0x8(%rsp)
    a1e6:      	movl	$0x1, %eax
    a1eb:      	movq	(%rip), %rdi            # 0xa1f2 <generic_tracepoint_actions+0xc92>
    a1f2:      	callq	*%rax
    a1f4:      	testq	%rax, %rax
    a1f7:      	je	0xa1fe <generic_tracepoint_actions+0xc9e>
    a1f9:      	lock
    a1fa:      	incq	(%rax,%r14,8)
    a1fe:      	movl	%r13d, %r15d
    a201:      	movq	0x30(%rsp), %r14
    a206:      	movq	%rbx, %rdx
    a209:      	jmp	0x9680 <generic_tracepoint_actions+0x120>
    a20e:      	movl	$0x1, 0x3c(%rsp)
    a216:      	movl	$0x2, %eax
    a21b:      	xorl	%ecx, %ecx
    a21d:      	leaq	0x3c(%rsp), %rdx
    a222:      	leaq	0x8(%rsp), %rsi
    a227:      	movq	%r14, %rdi
    a22a:      	xorl	%ecx, %ecx
    a22c:      	callq	*%rax
    a22e:      	cmpl	$0x0, 0x40(%rsp)
    a233:      	movq	(%rip), %rdi            # 0xa23a <generic_tracepoint_actions+0xcda>
    a23a:      	je	0x9c79 <generic_tracepoint_actions+0x719>
    a240:      	movl	$0x1, %eax
    a245:      	leaq	0x48(%rsp), %rsi
    a24a:      	callq	*%rax
    a24c:      	testq	%rax, %rax
    a24f:      	je	0x9c79 <generic_tracepoint_actions+0x719>
    a255:      	movl	0x5c(%rsp), %ecx
    a259:      	lock
    a25a:      	addl	%ecx, (%rax)
    a25c:      	jmp	0x9c79 <generic_tracepoint_actions+0x719>
    a261:      	cmpb	$0x0, 0x58(%rsp)
    a266:      	je	0xa285 <generic_tracepoint_actions+0xd25>
    a268:      	movq	(%rip), %rsi            # 0xa26f <generic_tracepoint_actions+0xd0f>
    a26f:      	movl	$0x5, %ecx
    a274:      	movl	$0xc, %eax
    a279:      	movq	0x70(%rsp), %rdi
    a27e:      	movl	$0x5, %edx
    a283:      	callq	*%rax
    a285:      	xorl	%eax, %eax
    a287:      	addq	$0xa8, %rsp
    a28e:      	popq	%rbx
    a28f:      	popq	%r12
    a291:      	popq	%r13
    a293:      	popq	%r14
    a295:      	popq	%r15
    a297:      	popq	%rbp
    a298:      	retq
    a299:      	nopl	(%rax)

000000000000a2a0 <generic_tracepoint_output>:
    a2a0:      	pushq	%rbp
    a2a1:      	pushq	%r15
    a2a3:      	pushq	%r14
    a2a5:      	pushq	%r13
    a2a7:      	pushq	%r12
    a2a9:      	pushq	%rbx
    a2aa:      	subq	$0x78, %rsp
    a2ae:      	movq	%rdi, %r14
    a2b1:      	movl	$0x0, 0x24(%rsp)
    a2b9:      	movq	(%rip), %rdi            # 0xa2c0 <generic_tracepoint_output+0x20>
    a2c0:      	leaq	0x24(%rsp), %rsi
    a2c5:      	movl	$0x1, %eax
    a2ca:      	callq	*%rax
    a2cc:      	testq	%rax, %rax
    a2cf:      	je	0xa779 <generic_tracepoint_output+0x4d9>
    a2d5:      	movq	%rax, %rbx
    a2d8:      	cmpq	$0x0, 0x5ee8(%rax)
    a2e0:      	je	0xa5e8 <generic_tracepoint_output+0x348>
    a2e6:      	movl	$0xe, %eax
    a2eb:      	callq	*%rax
    a2ed:      	movq	%rax, %r15
    a2f0:      	shrq	$0x20, %r15
    a2f4:      	movl	$0x23, %eax
    a2f9:      	callq	*%rax
    a2fb:      	movq	%rax, %r12
    a2fe:      	movl	%r15d, 0x28(%rsp)
    a303:      	movq	(%rip), %rdi            # 0xa30a <generic_tracepoint_output+0x6a>
    a30a:      	leaq	0x28(%rsp), %rsi
    a30f:      	movl	$0x1, %eax
    a314:      	callq	*%rax
    a316:      	testq	%rax, %rax
    a319:      	je	0xa5e8 <generic_tracepoint_output+0x348>
    a31f:      	movq	%rax, %r15
    a322:      	leaq	0xd70(%r12), %rdx
    a32a:      	leaq	0x70(%rsp), %rdi
    a32f:      	movl	$0x8, %ecx
    a334:      	movl	$0x4, %eax
    a339:      	leaq	0x28(%r15), %r13
    a33d:      	movl	$0x4, %ebp
    a342:      	movl	$0x8, %esi
    a347:      	callq	*%rax
    a349:      	movq	0x70(%rsp), %rcx
    a34e:      	leaq	0x28(%rsp), %rdi
    a353:      	movl	$0x48, %edx
    a358:      	movl	$0x4, %eax
    a35d:      	movq	0x70(%rsp), %rdx
    a362:      	movl	$0x48, %esi
    a367:      	callq	*%rax
    a369:      	movl	$0x218, %edx            # imm = 0x218
    a36e:      	movq	0x30(%rsp), %rcx
    a373:      	addq	%rdx, %rcx
    a376:      	movl	$0x4, %esi
    a37b:      	movl	$0x4, %eax
    a380:      	addq	0x30(%rsp), %rdx
    a385:      	movq	%r13, %rdi
    a388:      	movl	$0x4, %esi
    a38d:      	callq	*%rax
    a38f:      	leaq	0x2c(%r15), %rdi
    a393:      	movl	$0x4d8, %edx            # imm = 0x4D8
    a398:      	movq	0x38(%rsp), %rcx
    a39d:      	addq	%rdx, %rcx
    a3a0:      	movl	$0x4, %esi
    a3a5:      	movl	$0x4, %eax
    a3aa:      	addq	0x38(%rsp), %rdx
    a3af:      	movl	$0x4, %esi
    a3b4:      	callq	*%rax
    a3b6:      	leaq	0x30(%r15), %rdi
    a3ba:      	movq	0x40(%rsp), %rcx
    a3bf:      	addq	$0x58, %rcx
    a3c3:      	movl	$0x4, %edx
    a3c8:      	movl	$0x4, %eax
    a3cd:      	movq	0x40(%rsp), %rdx
    a3d2:      	addq	$0x58, %rdx
    a3d6:      	movl	$0x4, %esi
    a3db:      	callq	*%rax
    a3dd:      	movq	$0x0, (%rsp)
    a3e5:      	leaq	0xb58(%r12), %rdx
    a3ed:      	movq	%rsp, %rdi
    a3f0:      	movl	$0x8, %ecx
    a3f5:      	movl	$0x4, %eax
    a3fa:      	movl	$0x8, %esi
    a3ff:      	callq	*%rax
    a401:      	movq	(%rsp), %rcx
    a405:      	testq	%rcx, %rcx
    a408:      	je	0xa49b <generic_tracepoint_output+0x1fb>
    a40e:      	movl	$0x0, 0xc(%rsp)
    a416:      	addq	$0x4, %rcx
    a41a:      	leaq	0xc(%rsp), %rdi
    a41f:      	movl	$0x4, %eax
    a424:      	movq	(%rsp), %rdx
    a428:      	addq	$0x4, %rdx
    a42c:      	movl	$0x4, %esi
    a431:      	callq	*%rax
    a433:      	movq	(%rsp), %rax
    a437:      	movslq	0xc(%rsp), %rcx
    a43c:      	shlq	$0x4, %rcx
    a440:      	addq	%rax, %rcx
    a443:      	addq	$0x80, %rcx
    a44a:      	leaq	0x10(%rsp), %rdi
    a44f:      	movl	$0x10, %edx
    a454:      	movl	$0x4, %eax
    a459:      	movq	(%rsp), %rcx
    a45d:      	movslq	0xc(%rsp), %rdx
    a462:      	shlq	$0x4, %rdx
    a466:      	addq	%rcx, %rdx
    a469:      	addq	$0x80, %rdx
    a470:      	movl	$0x10, %esi
    a475:      	callq	*%rax
    a477:      	leaq	0x34(%r15), %rdi
    a47b:      	movl	$0x158, %edx            # imm = 0x158
    a480:      	movq	0x18(%rsp), %rcx
    a485:      	addq	%rdx, %rcx
    a488:      	movl	$0x4, %eax
    a48d:      	addq	0x18(%rsp), %rdx
    a492:      	movl	$0x4, %esi
    a497:      	callq	*%rax
    a499:      	jmp	0xa4a3 <generic_tracepoint_output+0x203>
    a49b:      	movl	$0x0, 0x34(%r15)
    a4a3:      	leaq	0x38(%r15), %rdi
    a4a7:      	movl	$0x158, %r13d           # imm = 0x158
    a4ad:      	movq	0x48(%rsp), %rcx
    a4b2:      	addq	%r13, %rcx
    a4b5:      	movl	$0x4, %edx
    a4ba:      	movl	$0x4, %eax
    a4bf:      	movq	0x48(%rsp), %rdx
    a4c4:      	addq	%r13, %rdx
    a4c7:      	movl	$0x4, %esi
    a4cc:      	callq	*%rax
    a4ce:      	leaq	0x3c(%r15), %rdi
    a4d2:      	movl	$0x118, %edx            # imm = 0x118
    a4d7:      	movq	0x50(%rsp), %rcx
    a4dc:      	addq	%rdx, %rcx
    a4df:      	movl	$0x4, %esi
    a4e4:      	movl	$0x4, %eax
    a4e9:      	addq	0x50(%rsp), %rdx
    a4ee:      	movl	$0x4, %esi
    a4f3:      	callq	*%rax
    a4f5:      	leaq	0x40(%r15), %rdi
    a4f9:      	movl	$0x98, %ebp
    a4fe:      	movq	0x58(%rsp), %rcx
    a503:      	addq	%rbp, %rcx
    a506:      	movl	$0x4, %edx
    a50b:      	movl	$0x4, %eax
    a510:      	movq	0x58(%rsp), %rdx
    a515:      	addq	%rbp, %rdx
    a518:      	movl	$0x4, %esi
    a51d:      	callq	*%rax
    a51f:      	leaq	0x44(%r15), %rdi
    a523:      	movq	0x60(%rsp), %rcx
    a528:      	addq	%rbp, %rcx
    a52b:      	movl	$0x4, %edx
    a530:      	movl	$0x4, %eax
    a535:      	addq	0x60(%rsp), %rbp
    a53a:      	movl	$0x4, %esi
    a53f:      	movq	%rbp, %rdx
    a542:      	callq	*%rax
    a544:      	leaq	0x48(%r15), %rdi
    a548:      	movq	0x68(%rsp), %rcx
    a54d:      	addq	$0x58, %rcx
    a551:      	movl	$0x4, %edx
    a556:      	movl	$0x4, %eax
    a55b:      	movq	0x68(%rsp), %rdx
    a560:      	addq	$0x58, %rdx
    a564:      	movl	$0x4, %esi
    a569:      	callq	*%rax
    a56b:      	movq	$0x0, 0x10(%rsp)
    a574:      	movq	$0x0, (%rsp)
    a57c:      	addq	$0xd00, %r12            # imm = 0xD00
    a583:      	leaq	0x10(%rsp), %rdi
    a588:      	movl	$0x8, %ecx
    a58d:      	movl	$0x4, %eax
    a592:      	movl	$0x8, %esi
    a597:      	movq	%r12, %rdx
    a59a:      	callq	*%rax
    a59c:      	movl	$0x90, %edx
    a5a1:      	movq	0x10(%rsp), %rcx
    a5a6:      	addq	%rdx, %rcx
    a5a9:      	movq	%rsp, %rdi
    a5ac:      	movl	$0x8, %esi
    a5b1:      	movl	$0x4, %eax
    a5b6:      	addq	0x10(%rsp), %rdx
    a5bb:      	movl	$0x8, %esi
    a5c0:      	callq	*%rax
    a5c2:      	addq	$0x4c, %r15
    a5c6:      	movq	(%rsp), %rcx
    a5ca:      	addq	%r13, %rcx
    a5cd:      	movl	$0x4, %edx
    a5d2:      	movl	$0x4, %eax
    a5d7:      	addq	(%rsp), %r13
    a5db:      	movq	%r15, %rdi
    a5de:      	movl	$0x4, %esi
    a5e3:      	movq	%r13, %rdx
    a5e6:      	callq	*%rax
    a5e8:      	cmpq	$0x0, 0x5ef0(%rbx)
    a5f0:      	je	0xa6a9 <generic_tracepoint_output+0x409>
    a5f6:      	movl	$0xe, %eax
    a5fb:      	callq	*%rax
    a5fd:      	movq	%rax, %r15
    a600:      	shrq	$0x20, %r15
    a604:      	movl	$0x23, %eax
    a609:      	callq	*%rax
    a60b:      	movq	%rax, %r12
    a60e:      	movl	%r15d, 0x28(%rsp)
    a613:      	movq	(%rip), %rdi            # 0xa61a <generic_tracepoint_output+0x37a>
    a61a:      	leaq	0x28(%rsp), %rsi
    a61f:      	movl	$0x1, %eax
    a624:      	callq	*%rax
    a626:      	testq	%rax, %rax
    a629:      	je	0xa6a9 <generic_tracepoint_output+0x409>
    a62b:      	leaq	0x50(%rax), %r15
    a62f:      	addq	$0xd00, %r12            # imm = 0xD00
    a636:      	leaq	0x28(%rsp), %rdi
    a63b:      	movl	$0x8, %ecx
    a640:      	movq	%rax, %r13
    a643:      	movl	$0x4, %eax
    a648:      	movl	$0x8, %esi
    a64d:      	movq	%r12, %rdx
    a650:      	callq	*%rax
    a652:      	movq	0x28(%rsp), %r12
    a657:      	leaq	0x58(%r13), %rdi
    a65b:      	leaq	0x40(%r12), %rdx
    a660:      	movl	$0x8, %ecx
    a665:      	movl	$0x4, %eax
    a66a:      	movl	$0x8, %esi
    a66f:      	callq	*%rax
    a671:      	addq	$0x60, %r13
    a675:      	leaq	0x30(%r12), %rdx
    a67a:      	movl	$0x8, %ecx
    a67f:      	movl	$0x4, %eax
    a684:      	movq	%r13, %rdi
    a687:      	movl	$0x8, %esi
    a68c:      	callq	*%rax
    a68e:      	addq	$0x38, %r12
    a692:      	movl	$0x8, %ecx
    a697:      	movl	$0x4, %eax
    a69c:      	movq	%r15, %rdi
    a69f:      	movl	$0x8, %esi
    a6a4:      	movq	%r12, %rdx
    a6a7:      	callq	*%rax
    a6a9:      	movl	$0x90, %eax
    a6ae:      	addl	0x4(%rbx), %eax
    a6b1:      	andl	$0x7fff, %eax           # imm = 0x7FFF
    a6b6:      	cmpl	$0x2328, %eax           # imm = 0x2328
    a6bb:      	movl	$0x2328, %r15d          # imm = 0x2328
    a6c1:      	cmovbl	%eax, %r15d
    a6c5:      	movl	$0x0, 0x10(%rsp)
    a6cd:      	movq	(%rip), %rdi            # 0xa6d4 <generic_tracepoint_output+0x434>
    a6d4:      	leaq	0x10(%rsp), %rsi
    a6d9:      	movl	$0x1, %eax
    a6de:      	callq	*%rax
    a6e0:      	testq	%rax, %rax
    a6e3:      	je	0xa737 <generic_tracepoint_output+0x497>
    a6e5:      	cmpb	$0x0, 0x28(%rax)
    a6e9:      	je	0xa737 <generic_tracepoint_output+0x497>
    a6eb:      	movq	(%rip), %rsi            # 0xa6f2 <generic_tracepoint_output+0x452>
    a6f2:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    a6f7:      	movl	$0x19, %eax
    a6fc:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    a701:      	movq	%r14, %rdi
    a704:      	movq	%rbx, %rcx
    a707:      	movq	%r15, %r8
    a70a:      	callq	*%rax
    a70c:      	testq	%rax, %rax
    a70f:      	js	0xa7d9 <generic_tracepoint_output+0x539>
    a715:      	movl	$0x0, 0x28(%rsp)
    a71d:      	movq	(%rip), %rdi            # 0xa724 <generic_tracepoint_output+0x484>
    a724:      	leaq	0x28(%rsp), %rsi
    a729:      	movl	$0x1, %eax
    a72e:      	callq	*%rax
    a730:      	testq	%rax, %rax
    a733:      	jne	0xa774 <generic_tracepoint_output+0x4d4>
    a735:      	jmp	0xa779 <generic_tracepoint_output+0x4d9>
    a737:      	movq	(%rip), %rdi            # 0xa73e <generic_tracepoint_output+0x49e>
    a73e:      	xorl	%ecx, %ecx
    a740:      	movl	$0x82, %eax
    a745:      	movq	%rbx, %rsi
    a748:      	movq	%r15, %rdx
    a74b:      	xorl	%ecx, %ecx
    a74d:      	callq	*%rax
    a74f:      	testq	%rax, %rax
    a752:      	js	0xa78a <generic_tracepoint_output+0x4ea>
    a754:      	movl	$0x0, 0x28(%rsp)
    a75c:      	movq	(%rip), %rdi            # 0xa763 <generic_tracepoint_output+0x4c3>
    a763:      	leaq	0x28(%rsp), %rsi
    a768:      	movl	$0x1, %eax
    a76d:      	callq	*%rax
    a76f:      	testq	%rax, %rax
    a772:      	je	0xa779 <generic_tracepoint_output+0x4d9>
    a774:      	lock
    a775:      	incq	0x8(%rax)
    a779:      	xorl	%eax, %eax
    a77b:      	addq	$0x78, %rsp
    a77f:      	popq	%rbx
    a780:      	popq	%r12
    a782:      	popq	%r13
    a784:      	popq	%r14
    a786:      	popq	%r15
    a788:      	popq	%rbp
    a789:      	retq
    a78a:      	movq	%rax, %rbx
    a78d:      	movl	$0x0, 0x28(%rsp)
    a795:      	movq	(%rip), %rdi            # 0xa79c <generic_tracepoint_output+0x4fc>
    a79c:      	leaq	0x28(%rsp), %rsi
    a7a1:      	movl	$0x1, %eax
    a7a6:      	callq	*%rax
    a7a8:      	testq	%rax, %rax
    a7ab:      	je	0xa779 <generic_tracepoint_output+0x4d9>
    a7ad:      	cmpq	$-0xc, %rbx
    a7b1:      	jg	0xa821 <generic_tracepoint_output+0x581>
    a7b3:      	cmpq	$-0x1c, %rbx
    a7b7:      	je	0xa863 <generic_tracepoint_output+0x5c3>
    a7bd:      	cmpq	$-0x16, %rbx
    a7c1:      	je	0xa812 <generic_tracepoint_output+0x572>
    a7c3:      	cmpq	$-0x10, %rbx
    a7c7:      	jne	0xa854 <generic_tracepoint_output+0x5b4>
    a7cd:      	addq	$0x328, %rax            # imm = 0x328
    a7d3:      	lock
    a7d4:      	incq	(%rax)
    a7d7:      	jmp	0xa779 <generic_tracepoint_output+0x4d9>
    a7d9:      	movq	%rax, %rbx
    a7dc:      	movl	$0x0, 0x28(%rsp)
    a7e4:      	movq	(%rip), %rdi            # 0xa7eb <generic_tracepoint_output+0x54b>
    a7eb:      	leaq	0x28(%rsp), %rsi
    a7f0:      	movl	$0x1, %eax
    a7f5:      	callq	*%rax
    a7f7:      	testq	%rax, %rax
    a7fa:      	je	0xa779 <generic_tracepoint_output+0x4d9>
    a800:      	cmpq	$-0xc, %rbx
    a804:      	jg	0xa842 <generic_tracepoint_output+0x5a2>
    a806:      	cmpq	$-0x1c, %rbx
    a80a:      	je	0xa863 <generic_tracepoint_output+0x5c3>
    a80c:      	cmpq	$-0x16, %rbx
    a810:      	jne	0xa7c3 <generic_tracepoint_output+0x523>
    a812:      	addq	$0x330, %rax            # imm = 0x330
    a818:      	lock
    a819:      	incq	(%rax)
    a81c:      	jmp	0xa779 <generic_tracepoint_output+0x4d9>
    a821:      	cmpq	$-0xb, %rbx
    a825:      	je	0xa872 <generic_tracepoint_output+0x5d2>
    a827:      	cmpq	$-0x7, %rbx
    a82b:      	je	0xa881 <generic_tracepoint_output+0x5e1>
    a82d:      	cmpq	$-0x2, %rbx
    a831:      	jne	0xa854 <generic_tracepoint_output+0x5b4>
    a833:      	addq	$0x318, %rax            # imm = 0x318
    a839:      	lock
    a83a:      	incq	(%rax)
    a83d:      	jmp	0xa779 <generic_tracepoint_output+0x4d9>
    a842:      	cmpq	$-0xb, %rbx
    a846:      	je	0xa872 <generic_tracepoint_output+0x5d2>
    a848:      	cmpq	$-0x7, %rbx
    a84c:      	je	0xa881 <generic_tracepoint_output+0x5e1>
    a84e:      	cmpq	$-0x2, %rbx
    a852:      	je	0xa833 <generic_tracepoint_output+0x593>
    a854:      	addq	$0x310, %rax            # imm = 0x310
    a85a:      	lock
    a85b:      	incq	(%rax)
    a85e:      	jmp	0xa779 <generic_tracepoint_output+0x4d9>
    a863:      	addq	$0x338, %rax            # imm = 0x338
    a869:      	lock
    a86a:      	incq	(%rax)
    a86d:      	jmp	0xa779 <generic_tracepoint_output+0x4d9>
    a872:      	addq	$0x340, %rax            # imm = 0x340
    a878:      	lock
    a879:      	incq	(%rax)
    a87c:      	jmp	0xa779 <generic_tracepoint_output+0x4d9>
    a881:      	addq	$0x320, %rax            # imm = 0x320
    a887:      	lock
    a888:      	incq	(%rax)
    a88b:      	jmp	0xa779 <generic_tracepoint_output+0x4d9>

Disassembly of section tracepoint/generic_tracepoint:

0000000000000000 <generic_tracepoint_event>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x88, %rsp
      11:      	movq	%rdi, %rbx
      14:      	movl	$0x0, 0x80(%rsp)
      1f:      	movq	(%rip), %rdi            # 0x26 <generic_tracepoint_event+0x26>
      26:      	leaq	0x80(%rsp), %rsi
      2e:      	movl	$0x1, %eax
      33:      	callq	*%rax
      35:      	testq	%rax, %rax
      38:      	je	0x32ec <generic_tracepoint_event+0x32ec>
      3e:      	movq	%rax, %r14
      41:      	movq	(%rip), %rdi            # 0x48 <generic_tracepoint_event+0x48>
      48:      	leaq	0x80(%rsp), %rsi
      50:      	movl	$0x1, %eax
      55:      	callq	*%rax
      57:      	testq	%rax, %rax
      5a:      	je	0x32ec <generic_tracepoint_event+0x32ec>
      60:      	movq	%rax, %r15
      63:      	movl	0x64(%rax), %eax
      66:      	movl	%eax, 0x7c(%rsp)
      6a:      	testl	%eax, %eax
      6c:      	je	0x23f <generic_tracepoint_event+0x23f>
      72:      	movq	(%rip), %rdi            # 0x79 <generic_tracepoint_event+0x79>
      79:      	leaq	0x7c(%rsp), %rsi
      7e:      	movl	$0x1, %eax
      83:      	callq	*%rax
      85:      	testq	%rax, %rax
      88:      	je	0x32ec <generic_tracepoint_event+0x32ec>
      8e:      	movq	%rax, %r12
      91:      	movl	$0x0, 0x84(%rsp)
      9c:      	movq	(%rip), %rdi            # 0xa3 <generic_tracepoint_event+0xa3>
      a3:      	leaq	0x84(%rsp), %rsi
      ab:      	movl	$0x1, %eax
      b0:      	callq	*%rax
      b2:      	testq	%rax, %rax
      b5:      	je	0xdb <generic_tracepoint_event+0xdb>
      b7:      	cmpq	$0x63677270, 0x20(%rax) # imm = 0x63677270
      bf:      	jne	0xdf <generic_tracepoint_event+0xdf>
      c1:      	movl	$0x50, %eax
      c6:      	callq	*%rax
      c8:      	movq	%rax, 0x68(%rsp)
      cd:      	testq	%rax, %rax
      d0:      	jne	0x1ed <generic_tracepoint_event+0x1ed>
      d6:      	jmp	0x32ec <generic_tracepoint_event+0x32ec>
      db:      	xorl	%ebp, %ebp
      dd:      	jmp	0xe2 <generic_tracepoint_event+0xe2>
      df:      	movl	0x10(%rax), %ebp
      e2:      	movl	$0x23, %eax
      e7:      	callq	*%rax
      e9:      	movq	$0x0, 0x8(%rsp)
      f2:      	leaq	0xf90(%rax), %rdx
      f9:      	leaq	0x10(%rsp), %rdi
      fe:      	movl	$0x8, %ecx
     103:      	movl	$0x71, %eax
     108:      	movl	$0x8, %esi
     10d:      	callq	*%rax
     10f:      	movq	0x10(%rsp), %rax
     114:      	testq	%rax, %rax
     117:      	je	0x168 <generic_tracepoint_event+0x168>
     119:      	cmpl	$0xb, %ebp
     11c:      	ja	0x168 <generic_tracepoint_event+0x168>
     11e:      	movl	%ebp, %edx
     120:      	leaq	(%rax,%rdx,8), %rcx
     124:      	leaq	0x20(%rsp), %rdi
     129:      	movl	$0x8, %esi
     12e:      	movl	$0x71, %eax
     133:      	shlq	$0x3, %rdx
     137:      	addq	0x10(%rsp), %rdx
     13c:      	movl	$0x8, %esi
     141:      	callq	*%rax
     143:      	movq	0x20(%rsp), %rcx
     148:      	testq	%rcx, %rcx
     14b:      	je	0x168 <generic_tracepoint_event+0x168>
     14d:      	leaq	0x8(%rsp), %rdi
     152:      	movl	$0x8, %edx
     157:      	movl	$0x71, %eax
     15c:      	movq	0x20(%rsp), %rdx
     161:      	movl	$0x8, %esi
     166:      	callq	*%rax
     168:      	movq	0x8(%rsp), %rdx
     16d:      	testq	%rdx, %rdx
     170:      	je	0x32ec <generic_tracepoint_event+0x32ec>
     176:      	movq	$0x0, 0x20(%rsp)
     17f:      	addq	$0x100, %rdx            # imm = 0x100
     186:      	leaq	0x20(%rsp), %rdi
     18b:      	movl	$0x8, %ecx
     190:      	movl	$0x71, %eax
     195:      	movl	$0x8, %esi
     19a:      	callq	*%rax
     19c:      	movq	0x20(%rsp), %rdx
     1a1:      	movq	$0x0, 0x20(%rsp)
     1aa:      	testq	%rdx, %rdx
     1ad:      	je	0x1dd <generic_tracepoint_event+0x1dd>
     1af:      	addq	$0x60, %rdx
     1b3:      	leaq	0x20(%rsp), %rdi
     1b8:      	movl	$0x8, %ecx
     1bd:      	movl	$0x71, %eax
     1c2:      	movl	$0x8, %esi
     1c7:      	callq	*%rax
     1c9:      	movq	0x20(%rsp), %rax
     1ce:      	movq	%rax, 0x68(%rsp)
     1d3:      	testq	%rax, %rax
     1d6:      	jne	0x1ed <generic_tracepoint_event+0x1ed>
     1d8:      	jmp	0x32ec <generic_tracepoint_event+0x32ec>
     1dd:      	xorl	%eax, %eax
     1df:      	movq	%rax, 0x68(%rsp)
     1e4:      	testq	%rax, %rax
     1e7:      	je	0x32ec <generic_tracepoint_event+0x32ec>
     1ed:      	movq	%rax, 0x20(%rsp)
     1f2:      	movq	(%rip), %rdi            # 0x1f9 <generic_tracepoint_event+0x1f9>
     1f9:      	leaq	0x20(%rsp), %rsi
     1fe:      	movl	$0x1, %eax
     203:      	callq	*%rax
     205:      	testq	%rax, %rax
     208:      	je	0x21e <generic_tracepoint_event+0x21e>
     20a:      	movq	(%rax), %rax
     20d:      	movq	%rax, 0x70(%rsp)
     212:      	testq	%rax, %rax
     215:      	je	0x227 <generic_tracepoint_event+0x227>
     217:      	movq	%rax, 0x68(%rsp)
     21c:      	jmp	0x227 <generic_tracepoint_event+0x227>
     21e:      	movq	$0x0, 0x70(%rsp)
     227:      	leaq	0x68(%rsp), %rsi
     22c:      	movl	$0x1, %eax
     231:      	movq	%r12, %rdi
     234:      	callq	*%rax
     236:      	testq	%rax, %rax
     239:      	je	0x461 <generic_tracepoint_event+0x461>
     23f:      	movl	$0x0, 0x5ef8(%r14)
     24a:      	movl	(%r15), %eax
     24d:      	movq	%rax, 0x60(%r14)
     251:      	movq	$0x0, 0x68(%r14)
     259:      	movzwl	0x2c(%r15), %edx
     25e:      	movl	0x4(%r15), %r13d
     262:      	addq	%rbx, %rdx
     265:      	xorl	%r12d, %r12d
     268:      	cmpl	$0xb, %r13d
     26c:      	jg	0x2a5 <generic_tracepoint_event+0x2a5>
     26e:      	cmpl	$0x3, %r13d
     272:      	jle	0x336 <generic_tracepoint_event+0x336>
     278:      	cmpl	$0x6, %r13d
     27c:      	jg	0x4c3 <generic_tracepoint_event+0x4c3>
     282:      	cmpl	$0x4, %r13d
     286:      	je	0x924 <generic_tracepoint_event+0x924>
     28c:      	cmpl	$0x5, %r13d
     290:      	je	0x7c9 <generic_tracepoint_event+0x7c9>
     296:      	cmpl	$0x6, %r13d
     29a:      	je	0x357 <generic_tracepoint_event+0x357>
     2a0:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     2a5:      	cmpl	$0x1d, %r13d
     2a9:      	jle	0x3d4 <generic_tracepoint_event+0x3d4>
     2af:      	cmpl	$0x25, %r13d
     2b3:      	jg	0x52f <generic_tracepoint_event+0x52f>
     2b9:      	cmpl	$0x1e, %r13d
     2bd:      	je	0x983 <generic_tracepoint_event+0x983>
     2c3:      	cmpl	$0x1f, %r13d
     2c7:      	je	0x846 <generic_tracepoint_event+0x846>
     2cd:      	cmpl	$0x20, %r13d
     2d1:      	jne	0xb87 <generic_tracepoint_event+0xb87>
     2d7:      	leaq	0x8(%rsp), %rdi
     2dc:      	movl	$0x1, %ecx
     2e1:      	movl	$0x4, %eax
     2e6:      	movl	$0x1, %esi
     2eb:      	callq	*%rax
     2ed:      	testq	%rax, %rax
     2f0:      	je	0xafc <generic_tracepoint_event+0xafc>
     2f6:      	negl	%eax
     2f8:      	movw	%ax, 0x20(%rsp)
     2fd:      	movw	$0x7, 0x22(%rsp)
     304:      	movabsq	$0x400000073, %rax      # imm = 0x400000073
     30e:      	movq	%rax, 0x24(%rsp)
     313:      	movq	(%rip), %rdi            # 0x31a <generic_tracepoint_event+0x31a>
     31a:      	leaq	0x20(%rsp), %rsi
     31f:      	movl	$0x1, %eax
     324:      	callq	*%rax
     326:      	testq	%rax, %rax
     329:      	je	0xad8 <generic_tracepoint_event+0xad8>
     32f:      	incl	(%rax)
     331:      	jmp	0xafc <generic_tracepoint_event+0xafc>
     336:      	cmpl	$-0xc, %r13d
     33a:      	jle	0x5ca <generic_tracepoint_event+0x5ca>
     340:      	leal	0xb(%r13), %eax
     344:      	cmpl	$0x2, %eax
     347:      	jb	0x4d0 <generic_tracepoint_event+0x4d0>
     34d:      	cmpl	$0x2, %r13d
     351:      	jne	0xb87 <generic_tracepoint_event+0xb87>
     357:      	leaq	0x10(%rsp), %rdi
     35c:      	movl	$0x8, %ecx
     361:      	movl	$0x4, %eax
     366:      	movl	$0x8, %esi
     36b:      	callq	*%rax
     36d:      	testq	%rax, %rax
     370:      	je	0xb2b <generic_tracepoint_event+0xb2b>
     376:      	negl	%eax
     378:      	movw	%ax, 0x20(%rsp)
     37d:      	movw	$0x7, 0x22(%rsp)
     384:      	movabsq	$0x400000081, %rax      # imm = 0x400000081
     38e:      	movq	%rax, 0x24(%rsp)
     393:      	movq	(%rip), %rdi            # 0x39a <generic_tracepoint_event+0x39a>
     39a:      	leaq	0x20(%rsp), %rsi
     39f:      	movl	$0x1, %eax
     3a4:      	callq	*%rax
     3a6:      	testq	%rax, %rax
     3a9:      	jne	0x97c <generic_tracepoint_event+0x97c>
     3af:      	movl	$0x1, 0x8(%rsp)
     3b7:      	movq	(%rip), %rdi            # 0x3be <generic_tracepoint_event+0x3be>
     3be:      	xorl	%ecx, %ecx
     3c0:      	leaq	0x20(%rsp), %rsi
     3c5:      	leaq	0x8(%rsp), %rdx
     3ca:      	movl	$0x2, %eax
     3cf:      	jmp	0xb27 <generic_tracepoint_event+0xb27>
     3d4:      	cmpl	$0x11, %r13d
     3d8:      	jle	0x5df <generic_tracepoint_event+0x5df>
     3de:      	cmpl	$0x12, %r13d
     3e2:      	je	0x7c1 <generic_tracepoint_event+0x7c1>
     3e8:      	cmpl	$0x1c, %r13d
     3ec:      	je	0x4d0 <generic_tracepoint_event+0x4d0>
     3f2:      	cmpl	$0x1d, %r13d
     3f6:      	jne	0xb87 <generic_tracepoint_event+0xb87>
     3fc:      	leaq	0x8(%rsp), %rdi
     401:      	movl	$0x2, %ecx
     406:      	movl	$0x4, %eax
     40b:      	movl	$0x2, %esi
     410:      	callq	*%rax
     412:      	testq	%rax, %rax
     415:      	je	0xa9e <generic_tracepoint_event+0xa9e>
     41b:      	negl	%eax
     41d:      	movw	%ax, 0x20(%rsp)
     422:      	movw	$0x7, 0x22(%rsp)
     429:      	movabsq	$0x40000006c, %rax      # imm = 0x40000006C
     433:      	movq	%rax, 0x24(%rsp)
     438:      	movq	(%rip), %rdi            # 0x43f <generic_tracepoint_event+0x43f>
     43f:      	leaq	0x20(%rsp), %rsi
     444:      	movl	$0x1, %eax
     449:      	callq	*%rax
     44b:      	testq	%rax, %rax
     44e:      	je	0xa7a <generic_tracepoint_event+0xa7a>
     454:      	incl	(%rax)
     456:      	movswq	0x8(%rsp), %r12
     45c:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     461:      	movq	$-0x1, 0x70(%rsp)
     46a:      	leaq	0x70(%rsp), %rsi
     46f:      	movl	$0x1, %eax
     474:      	movq	%r12, %rdi
     477:      	callq	*%rax
     479:      	testq	%rax, %rax
     47c:      	je	0x32ec <generic_tracepoint_event+0x32ec>
     482:      	movl	$0x1, 0x7c(%rsp)
     48a:      	movq	(%rip), %rdi            # 0x491 <generic_tracepoint_event+0x491>
     491:      	leaq	0x7c(%rsp), %rsi
     496:      	movl	$0x1, %eax
     49b:      	callq	*%rax
     49d:      	testq	%rax, %rax
     4a0:      	je	0x32ec <generic_tracepoint_event+0x32ec>
     4a6:      	movq	%rax, %rdi
     4a9:      	leaq	0x68(%rsp), %rsi
     4ae:      	movl	$0x1, %eax
     4b3:      	callq	*%rax
     4b5:      	testq	%rax, %rax
     4b8:      	jne	0x32ec <generic_tracepoint_event+0x32ec>
     4be:      	jmp	0x23f <generic_tracepoint_event+0x23f>
     4c3:      	leal	-0xa(%r13), %eax
     4c7:      	cmpl	$0x2, %eax
     4ca:      	jae	0x73a <generic_tracepoint_event+0x73a>
     4d0:      	leaq	0x10(%rsp), %rdi
     4d5:      	movl	$0x8, %ecx
     4da:      	movl	$0x4, %eax
     4df:      	movl	$0x8, %esi
     4e4:      	callq	*%rax
     4e6:      	testq	%rax, %rax
     4e9:      	je	0x6f8 <generic_tracepoint_event+0x6f8>
     4ef:      	negl	%eax
     4f1:      	movw	%ax, 0x20(%rsp)
     4f6:      	movw	$0x7, 0x22(%rsp)
     4fd:      	movabsq	$0x400000045, %rax      # imm = 0x400000045
     507:      	movq	%rax, 0x24(%rsp)
     50c:      	movq	(%rip), %rdi            # 0x513 <generic_tracepoint_event+0x513>
     513:      	leaq	0x20(%rsp), %rsi
     518:      	movl	$0x1, %eax
     51d:      	callq	*%rax
     51f:      	testq	%rax, %rax
     522:      	je	0x6d4 <generic_tracepoint_event+0x6d4>
     528:      	incl	(%rax)
     52a:      	jmp	0x6f8 <generic_tracepoint_event+0x6f8>
     52f:      	cmpl	$0x26, %r13d
     533:      	je	0x9e8 <generic_tracepoint_event+0x9e8>
     539:      	cmpl	$0x28, %r13d
     53d:      	je	0x8ab <generic_tracepoint_event+0x8ab>
     543:      	cmpl	$0x29, %r13d
     547:      	jne	0xb87 <generic_tracepoint_event+0xb87>
     54d:      	leaq	0x10(%rsp), %rdi
     552:      	movl	$0x8, %ecx
     557:      	movl	$0x4, %eax
     55c:      	movl	$0x8, %esi
     561:      	callq	*%rax
     563:      	testq	%rax, %rax
     566:      	je	0xb2b <generic_tracepoint_event+0xb2b>
     56c:      	negl	%eax
     56e:      	movw	%ax, 0x20(%rsp)
     573:      	movw	$0x7, 0x22(%rsp)
     57a:      	movabsq	$0x4000000a8, %rax      # imm = 0x4000000A8
     584:      	movq	%rax, 0x24(%rsp)
     589:      	movq	(%rip), %rdi            # 0x590 <generic_tracepoint_event+0x590>
     590:      	leaq	0x20(%rsp), %rsi
     595:      	movl	$0x1, %eax
     59a:      	callq	*%rax
     59c:      	testq	%rax, %rax
     59f:      	jne	0x97c <generic_tracepoint_event+0x97c>
     5a5:      	movl	$0x1, 0x8(%rsp)
     5ad:      	movq	(%rip), %rdi            # 0x5b4 <generic_tracepoint_event+0x5b4>
     5b4:      	xorl	%ecx, %ecx
     5b6:      	leaq	0x20(%rsp), %rsi
     5bb:      	leaq	0x8(%rsp), %rdx
     5c0:      	movl	$0x2, %eax
     5c5:      	jmp	0xb27 <generic_tracepoint_event+0xb27>
     5ca:      	cmpl	$-0xd, %r13d
     5ce:      	je	0x670 <generic_tracepoint_event+0x670>
     5d4:      	cmpl	$-0xc, %r13d
     5d8:      	je	0x5f3 <generic_tracepoint_event+0x5f3>
     5da:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     5df:      	cmpl	$0xc, %r13d
     5e3:      	je	0x670 <generic_tracepoint_event+0x670>
     5e9:      	cmpl	$0xd, %r13d
     5ed:      	jne	0xb87 <generic_tracepoint_event+0xb87>
     5f3:      	leaq	0x8(%rsp), %rdi
     5f8:      	movl	$0x4, %ecx
     5fd:      	movl	$0x4, %eax
     602:      	movl	$0x4, %esi
     607:      	callq	*%rax
     609:      	testq	%rax, %rax
     60c:      	je	0xb82 <generic_tracepoint_event+0xb82>
     612:      	negl	%eax
     614:      	movw	%ax, 0x20(%rsp)
     619:      	movw	$0x7, 0x22(%rsp)
     620:      	movabsq	$0x40000005e, %rax      # imm = 0x40000005E
     62a:      	movq	%rax, 0x24(%rsp)
     62f:      	movq	(%rip), %rdi            # 0x636 <generic_tracepoint_event+0x636>
     636:      	leaq	0x20(%rsp), %rsi
     63b:      	movl	$0x1, %eax
     640:      	callq	*%rax
     642:      	testq	%rax, %rax
     645:      	jne	0xa40 <generic_tracepoint_event+0xa40>
     64b:      	movl	$0x1, 0x10(%rsp)
     653:      	movq	(%rip), %rdi            # 0x65a <generic_tracepoint_event+0x65a>
     65a:      	xorl	%ecx, %ecx
     65c:      	leaq	0x20(%rsp), %rsi
     661:      	leaq	0x10(%rsp), %rdx
     666:      	movl	$0x2, %eax
     66b:      	jmp	0xb7e <generic_tracepoint_event+0xb7e>
     670:      	leaq	0x8(%rsp), %rdi
     675:      	movl	$0x4, %ecx
     67a:      	movl	$0x4, %eax
     67f:      	movl	$0x4, %esi
     684:      	callq	*%rax
     686:      	testq	%rax, %rax
     689:      	je	0xa70 <generic_tracepoint_event+0xa70>
     68f:      	negl	%eax
     691:      	movw	%ax, 0x20(%rsp)
     696:      	movw	$0x7, 0x22(%rsp)
     69d:      	movabsq	$0x400000056, %rax      # imm = 0x400000056
     6a7:      	movq	%rax, 0x24(%rsp)
     6ac:      	movq	(%rip), %rdi            # 0x6b3 <generic_tracepoint_event+0x6b3>
     6b3:      	leaq	0x20(%rsp), %rsi
     6b8:      	movl	$0x1, %eax
     6bd:      	callq	*%rax
     6bf:      	testq	%rax, %rax
     6c2:      	je	0xa4c <generic_tracepoint_event+0xa4c>
     6c8:      	incl	(%rax)
     6ca:      	movslq	0x8(%rsp), %r12
     6cf:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     6d4:      	movl	$0x1, 0x8(%rsp)
     6dc:      	movq	(%rip), %rdi            # 0x6e3 <generic_tracepoint_event+0x6e3>
     6e3:      	xorl	%ecx, %ecx
     6e5:      	leaq	0x20(%rsp), %rsi
     6ea:      	leaq	0x8(%rsp), %rdx
     6ef:      	movl	$0x2, %eax
     6f4:      	xorl	%ecx, %ecx
     6f6:      	callq	*%rax
     6f8:      	movq	0x10(%rsp), %r12
     6fd:      	cmpl	$0x1c, %r13d
     701:      	jne	0xb87 <generic_tracepoint_event+0xb87>
     707:      	movl	$0x23, %eax
     70c:      	callq	*%rax
     70e:      	leaq	0x10(%rax), %rdx
     712:      	leaq	0x20(%rsp), %rdi
     717:      	movl	$0x4, %ecx
     71c:      	movl	$0x4, %eax
     721:      	movl	$0x4, %esi
     726:      	callq	*%rax
     728:      	movl	0x20(%rsp), %eax
     72c:      	andl	$-0x2, %eax
     72f:      	shll	$0x1e, %eax
     732:      	orq	%rax, %r12
     735:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     73a:      	cmpl	$0x7, %r13d
     73e:      	jne	0xb87 <generic_tracepoint_event+0xb87>
     744:      	leaq	0x10(%rsp), %rdi
     749:      	movl	$0x8, %ecx
     74e:      	movl	$0x4, %eax
     753:      	movl	$0x8, %esi
     758:      	callq	*%rax
     75a:      	testq	%rax, %rax
     75d:      	je	0xb2b <generic_tracepoint_event+0xb2b>
     763:      	negl	%eax
     765:      	movw	%ax, 0x20(%rsp)
     76a:      	movw	$0x7, 0x22(%rsp)
     771:      	movabsq	$0x40000009a, %rax      # imm = 0x40000009A
     77b:      	movq	%rax, 0x24(%rsp)
     780:      	movq	(%rip), %rdi            # 0x787 <generic_tracepoint_event+0x787>
     787:      	leaq	0x20(%rsp), %rsi
     78c:      	movl	$0x1, %eax
     791:      	callq	*%rax
     793:      	testq	%rax, %rax
     796:      	jne	0x97c <generic_tracepoint_event+0x97c>
     79c:      	movl	$0x1, 0x8(%rsp)
     7a4:      	movq	(%rip), %rdi            # 0x7ab <generic_tracepoint_event+0x7ab>
     7ab:      	xorl	%ecx, %ecx
     7ad:      	leaq	0x20(%rsp), %rsi
     7b2:      	leaq	0x8(%rsp), %rdx
     7b7:      	movl	$0x2, %eax
     7bc:      	jmp	0xb27 <generic_tracepoint_event+0xb27>
     7c1:      	movq	%rdx, %r12
     7c4:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     7c9:      	leaq	0x10(%rsp), %rdi
     7ce:      	movl	$0x8, %ecx
     7d3:      	movl	$0x4, %eax
     7d8:      	movl	$0x8, %esi
     7dd:      	callq	*%rax
     7df:      	testq	%rax, %rax
     7e2:      	je	0xb2b <generic_tracepoint_event+0xb2b>
     7e8:      	negl	%eax
     7ea:      	movw	%ax, 0x20(%rsp)
     7ef:      	movw	$0x7, 0x22(%rsp)
     7f6:      	movabsq	$0x400000093, %rax      # imm = 0x400000093
     800:      	movq	%rax, 0x24(%rsp)
     805:      	movq	(%rip), %rdi            # 0x80c <generic_tracepoint_event+0x80c>
     80c:      	leaq	0x20(%rsp), %rsi
     811:      	movl	$0x1, %eax
     816:      	callq	*%rax
     818:      	testq	%rax, %rax
     81b:      	jne	0x97c <generic_tracepoint_event+0x97c>
     821:      	movl	$0x1, 0x8(%rsp)
     829:      	movq	(%rip), %rdi            # 0x830 <generic_tracepoint_event+0x830>
     830:      	xorl	%ecx, %ecx
     832:      	leaq	0x20(%rsp), %rsi
     837:      	leaq	0x8(%rsp), %rdx
     83c:      	movl	$0x2, %eax
     841:      	jmp	0xb27 <generic_tracepoint_event+0xb27>
     846:      	leaq	0x8(%rsp), %rdi
     84b:      	movl	$0x1, %ecx
     850:      	movl	$0x4, %eax
     855:      	movl	$0x1, %esi
     85a:      	callq	*%rax
     85c:      	testq	%rax, %rax
     85f:      	je	0xacd <generic_tracepoint_event+0xacd>
     865:      	negl	%eax
     867:      	movw	%ax, 0x20(%rsp)
     86c:      	movw	$0x7, 0x22(%rsp)
     873:      	movabsq	$0x40000007a, %rax      # imm = 0x40000007A
     87d:      	movq	%rax, 0x24(%rsp)
     882:      	movq	(%rip), %rdi            # 0x889 <generic_tracepoint_event+0x889>
     889:      	leaq	0x20(%rsp), %rsi
     88e:      	movl	$0x1, %eax
     893:      	callq	*%rax
     895:      	testq	%rax, %rax
     898:      	je	0xaa9 <generic_tracepoint_event+0xaa9>
     89e:      	incl	(%rax)
     8a0:      	movsbq	0x8(%rsp), %r12
     8a6:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     8ab:      	leaq	0x10(%rsp), %rdi
     8b0:      	movl	$0x8, %ecx
     8b5:      	movl	$0x4, %eax
     8ba:      	movl	$0x8, %esi
     8bf:      	callq	*%rax
     8c1:      	testq	%rax, %rax
     8c4:      	je	0xb2b <generic_tracepoint_event+0xb2b>
     8ca:      	negl	%eax
     8cc:      	movw	%ax, 0x20(%rsp)
     8d1:      	movw	$0x7, 0x22(%rsp)
     8d8:      	movabsq	$0x4000000a1, %rax      # imm = 0x4000000A1
     8e2:      	movq	%rax, 0x24(%rsp)
     8e7:      	movq	(%rip), %rdi            # 0x8ee <generic_tracepoint_event+0x8ee>
     8ee:      	leaq	0x20(%rsp), %rsi
     8f3:      	movl	$0x1, %eax
     8f8:      	callq	*%rax
     8fa:      	testq	%rax, %rax
     8fd:      	jne	0x97c <generic_tracepoint_event+0x97c>
     8ff:      	movl	$0x1, 0x8(%rsp)
     907:      	movq	(%rip), %rdi            # 0x90e <generic_tracepoint_event+0x90e>
     90e:      	xorl	%ecx, %ecx
     910:      	leaq	0x20(%rsp), %rsi
     915:      	leaq	0x8(%rsp), %rdx
     91a:      	movl	$0x2, %eax
     91f:      	jmp	0xb27 <generic_tracepoint_event+0xb27>
     924:      	leaq	0x10(%rsp), %rdi
     929:      	movl	$0x8, %ecx
     92e:      	movl	$0x4, %eax
     933:      	movl	$0x8, %esi
     938:      	callq	*%rax
     93a:      	testq	%rax, %rax
     93d:      	je	0xb2b <generic_tracepoint_event+0xb2b>
     943:      	negl	%eax
     945:      	movw	%ax, 0x20(%rsp)
     94a:      	movw	$0x7, 0x22(%rsp)
     951:      	movabsq	$0x40000004e, %rax      # imm = 0x40000004E
     95b:      	movq	%rax, 0x24(%rsp)
     960:      	movq	(%rip), %rdi            # 0x967 <generic_tracepoint_event+0x967>
     967:      	leaq	0x20(%rsp), %rsi
     96c:      	movl	$0x1, %eax
     971:      	callq	*%rax
     973:      	testq	%rax, %rax
     976:      	je	0xb07 <generic_tracepoint_event+0xb07>
     97c:      	incl	(%rax)
     97e:      	jmp	0xb2b <generic_tracepoint_event+0xb2b>
     983:      	leaq	0x8(%rsp), %rdi
     988:      	movl	$0x2, %ecx
     98d:      	movl	$0x4, %eax
     992:      	movl	$0x2, %esi
     997:      	callq	*%rax
     999:      	testq	%rax, %rax
     99c:      	je	0xb56 <generic_tracepoint_event+0xb56>
     9a2:      	negl	%eax
     9a4:      	movw	%ax, 0x20(%rsp)
     9a9:      	movw	$0x7, 0x22(%rsp)
     9b0:      	movabsq	$0x400000065, %rax      # imm = 0x400000065
     9ba:      	movq	%rax, 0x24(%rsp)
     9bf:      	movq	(%rip), %rdi            # 0x9c6 <generic_tracepoint_event+0x9c6>
     9c6:      	leaq	0x20(%rsp), %rsi
     9cb:      	movl	$0x1, %eax
     9d0:      	callq	*%rax
     9d2:      	testq	%rax, %rax
     9d5:      	je	0xb32 <generic_tracepoint_event+0xb32>
     9db:      	incl	(%rax)
     9dd:      	movzwl	0x8(%rsp), %r12d
     9e3:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     9e8:      	leaq	0x8(%rsp), %rdi
     9ed:      	movl	$0x4, %ecx
     9f2:      	movl	$0x4, %eax
     9f7:      	movl	$0x4, %esi
     9fc:      	callq	*%rax
     9fe:      	testq	%rax, %rax
     a01:      	je	0xb82 <generic_tracepoint_event+0xb82>
     a07:      	negl	%eax
     a09:      	movw	%ax, 0x20(%rsp)
     a0e:      	movw	$0x7, 0x22(%rsp)
     a15:      	movabsq	$0x400000088, %rax      # imm = 0x400000088
     a1f:      	movq	%rax, 0x24(%rsp)
     a24:      	movq	(%rip), %rdi            # 0xa2b <generic_tracepoint_event+0xa2b>
     a2b:      	leaq	0x20(%rsp), %rsi
     a30:      	movl	$0x1, %eax
     a35:      	callq	*%rax
     a37:      	testq	%rax, %rax
     a3a:      	je	0xb5e <generic_tracepoint_event+0xb5e>
     a40:      	incl	(%rax)
     a42:      	movl	0x8(%rsp), %r12d
     a47:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     a4c:      	movl	$0x1, 0x10(%rsp)
     a54:      	movq	(%rip), %rdi            # 0xa5b <generic_tracepoint_event+0xa5b>
     a5b:      	xorl	%ecx, %ecx
     a5d:      	leaq	0x20(%rsp), %rsi
     a62:      	leaq	0x10(%rsp), %rdx
     a67:      	movl	$0x2, %eax
     a6c:      	xorl	%ecx, %ecx
     a6e:      	callq	*%rax
     a70:      	movslq	0x8(%rsp), %r12
     a75:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     a7a:      	movl	$0x1, 0x10(%rsp)
     a82:      	movq	(%rip), %rdi            # 0xa89 <generic_tracepoint_event+0xa89>
     a89:      	xorl	%ecx, %ecx
     a8b:      	leaq	0x20(%rsp), %rsi
     a90:      	leaq	0x10(%rsp), %rdx
     a95:      	movl	$0x2, %eax
     a9a:      	xorl	%ecx, %ecx
     a9c:      	callq	*%rax
     a9e:      	movswq	0x8(%rsp), %r12
     aa4:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     aa9:      	movl	$0x1, 0x10(%rsp)
     ab1:      	movq	(%rip), %rdi            # 0xab8 <generic_tracepoint_event+0xab8>
     ab8:      	xorl	%ecx, %ecx
     aba:      	leaq	0x20(%rsp), %rsi
     abf:      	leaq	0x10(%rsp), %rdx
     ac4:      	movl	$0x2, %eax
     ac9:      	xorl	%ecx, %ecx
     acb:      	callq	*%rax
     acd:      	movsbq	0x8(%rsp), %r12
     ad3:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     ad8:      	movl	$0x1, 0x10(%rsp)
     ae0:      	movq	(%rip), %rdi            # 0xae7 <generic_tracepoint_event+0xae7>
     ae7:      	xorl	%ecx, %ecx
     ae9:      	leaq	0x20(%rsp), %rsi
     aee:      	leaq	0x10(%rsp), %rdx
     af3:      	movl	$0x2, %eax
     af8:      	xorl	%ecx, %ecx
     afa:      	callq	*%rax
     afc:      	movzbl	0x8(%rsp), %r12d
     b02:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     b07:      	movl	$0x1, 0x8(%rsp)
     b0f:      	movq	(%rip), %rdi            # 0xb16 <generic_tracepoint_event+0xb16>
     b16:      	xorl	%ecx, %ecx
     b18:      	leaq	0x20(%rsp), %rsi
     b1d:      	leaq	0x8(%rsp), %rdx
     b22:      	movl	$0x2, %eax
     b27:      	xorl	%ecx, %ecx
     b29:      	callq	*%rax
     b2b:      	movq	0x10(%rsp), %r12
     b30:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     b32:      	movl	$0x1, 0x10(%rsp)
     b3a:      	movq	(%rip), %rdi            # 0xb41 <generic_tracepoint_event+0xb41>
     b41:      	xorl	%ecx, %ecx
     b43:      	leaq	0x20(%rsp), %rsi
     b48:      	leaq	0x10(%rsp), %rdx
     b4d:      	movl	$0x2, %eax
     b52:      	xorl	%ecx, %ecx
     b54:      	callq	*%rax
     b56:      	movzwl	0x8(%rsp), %r12d
     b5c:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     b5e:      	movl	$0x1, 0x10(%rsp)
     b66:      	movq	(%rip), %rdi            # 0xb6d <generic_tracepoint_event+0xb6d>
     b6d:      	xorl	%ecx, %ecx
     b6f:      	leaq	0x20(%rsp), %rsi
     b74:      	leaq	0x10(%rsp), %rdx
     b79:      	movl	$0x2, %eax
     b7e:      	xorl	%ecx, %ecx
     b80:      	callq	*%rax
     b82:      	movl	0x8(%rsp), %r12d
     b87:      	movq	%r12, 0x5e50(%r14)
     b8e:      	movzwl	0x30(%r15), %edx
     b93:      	movl	0x8(%r15), %r13d
     b97:      	addq	%rbx, %rdx
     b9a:      	xorl	%r12d, %r12d
     b9d:      	cmpl	$0xb, %r13d
     ba1:      	jg	0xbda <generic_tracepoint_event+0xbda>
     ba3:      	cmpl	$0x3, %r13d
     ba7:      	jle	0xc71 <generic_tracepoint_event+0xc71>
     bad:      	cmpl	$0x6, %r13d
     bb1:      	jg	0xd98 <generic_tracepoint_event+0xd98>
     bb7:      	cmpl	$0x4, %r13d
     bbb:      	je	0x11f9 <generic_tracepoint_event+0x11f9>
     bc1:      	cmpl	$0x5, %r13d
     bc5:      	je	0x109e <generic_tracepoint_event+0x109e>
     bcb:      	cmpl	$0x6, %r13d
     bcf:      	je	0xc92 <generic_tracepoint_event+0xc92>
     bd5:      	jmp	0x145c <generic_tracepoint_event+0x145c>
     bda:      	cmpl	$0x1d, %r13d
     bde:      	jle	0xd0f <generic_tracepoint_event+0xd0f>
     be4:      	cmpl	$0x25, %r13d
     be8:      	jg	0xe04 <generic_tracepoint_event+0xe04>
     bee:      	cmpl	$0x1e, %r13d
     bf2:      	je	0x1258 <generic_tracepoint_event+0x1258>
     bf8:      	cmpl	$0x1f, %r13d
     bfc:      	je	0x111b <generic_tracepoint_event+0x111b>
     c02:      	cmpl	$0x20, %r13d
     c06:      	jne	0x145c <generic_tracepoint_event+0x145c>
     c0c:      	leaq	0x8(%rsp), %rdi
     c11:      	movl	$0x1, %ecx
     c16:      	movl	$0x4, %eax
     c1b:      	movl	$0x1, %esi
     c20:      	callq	*%rax
     c22:      	testq	%rax, %rax
     c25:      	je	0x13d1 <generic_tracepoint_event+0x13d1>
     c2b:      	negl	%eax
     c2d:      	movw	%ax, 0x20(%rsp)
     c32:      	movw	$0x7, 0x22(%rsp)
     c39:      	movabsq	$0x400000073, %rax      # imm = 0x400000073
     c43:      	movq	%rax, 0x24(%rsp)
     c48:      	movq	(%rip), %rdi            # 0xc4f <generic_tracepoint_event+0xc4f>
     c4f:      	leaq	0x20(%rsp), %rsi
     c54:      	movl	$0x1, %eax
     c59:      	callq	*%rax
     c5b:      	testq	%rax, %rax
     c5e:      	je	0x13ad <generic_tracepoint_event+0x13ad>
     c64:      	incl	(%rax)
     c66:      	movzbl	0x8(%rsp), %r12d
     c6c:      	jmp	0x145c <generic_tracepoint_event+0x145c>
     c71:      	cmpl	$-0xc, %r13d
     c75:      	jle	0xe9f <generic_tracepoint_event+0xe9f>
     c7b:      	leal	0xb(%r13), %eax
     c7f:      	cmpl	$0x2, %eax
     c82:      	jb	0xda5 <generic_tracepoint_event+0xda5>
     c88:      	cmpl	$0x2, %r13d
     c8c:      	jne	0x145c <generic_tracepoint_event+0x145c>
     c92:      	leaq	0x10(%rsp), %rdi
     c97:      	movl	$0x8, %ecx
     c9c:      	movl	$0x4, %eax
     ca1:      	movl	$0x8, %esi
     ca6:      	callq	*%rax
     ca8:      	testq	%rax, %rax
     cab:      	je	0x1400 <generic_tracepoint_event+0x1400>
     cb1:      	negl	%eax
     cb3:      	movw	%ax, 0x20(%rsp)
     cb8:      	movw	$0x7, 0x22(%rsp)
     cbf:      	movabsq	$0x400000081, %rax      # imm = 0x400000081
     cc9:      	movq	%rax, 0x24(%rsp)
     cce:      	movq	(%rip), %rdi            # 0xcd5 <generic_tracepoint_event+0xcd5>
     cd5:      	leaq	0x20(%rsp), %rsi
     cda:      	movl	$0x1, %eax
     cdf:      	callq	*%rax
     ce1:      	testq	%rax, %rax
     ce4:      	jne	0x1251 <generic_tracepoint_event+0x1251>
     cea:      	movl	$0x1, 0x8(%rsp)
     cf2:      	movq	(%rip), %rdi            # 0xcf9 <generic_tracepoint_event+0xcf9>
     cf9:      	xorl	%ecx, %ecx
     cfb:      	leaq	0x20(%rsp), %rsi
     d00:      	leaq	0x8(%rsp), %rdx
     d05:      	movl	$0x2, %eax
     d0a:      	jmp	0x13fc <generic_tracepoint_event+0x13fc>
     d0f:      	cmpl	$0x11, %r13d
     d13:      	jle	0xeb4 <generic_tracepoint_event+0xeb4>
     d19:      	cmpl	$0x12, %r13d
     d1d:      	je	0x1096 <generic_tracepoint_event+0x1096>
     d23:      	cmpl	$0x1c, %r13d
     d27:      	je	0xda5 <generic_tracepoint_event+0xda5>
     d29:      	cmpl	$0x1d, %r13d
     d2d:      	jne	0x145c <generic_tracepoint_event+0x145c>
     d33:      	leaq	0x8(%rsp), %rdi
     d38:      	movl	$0x2, %ecx
     d3d:      	movl	$0x4, %eax
     d42:      	movl	$0x2, %esi
     d47:      	callq	*%rax
     d49:      	testq	%rax, %rax
     d4c:      	je	0x1373 <generic_tracepoint_event+0x1373>
     d52:      	negl	%eax
     d54:      	movw	%ax, 0x20(%rsp)
     d59:      	movw	$0x7, 0x22(%rsp)
     d60:      	movabsq	$0x40000006c, %rax      # imm = 0x40000006C
     d6a:      	movq	%rax, 0x24(%rsp)
     d6f:      	movq	(%rip), %rdi            # 0xd76 <generic_tracepoint_event+0xd76>
     d76:      	leaq	0x20(%rsp), %rsi
     d7b:      	movl	$0x1, %eax
     d80:      	callq	*%rax
     d82:      	testq	%rax, %rax
     d85:      	je	0x134f <generic_tracepoint_event+0x134f>
     d8b:      	incl	(%rax)
     d8d:      	movswq	0x8(%rsp), %r12
     d93:      	jmp	0x145c <generic_tracepoint_event+0x145c>
     d98:      	leal	-0xa(%r13), %eax
     d9c:      	cmpl	$0x2, %eax
     d9f:      	jae	0x100f <generic_tracepoint_event+0x100f>
     da5:      	leaq	0x10(%rsp), %rdi
     daa:      	movl	$0x8, %ecx
     daf:      	movl	$0x4, %eax
     db4:      	movl	$0x8, %esi
     db9:      	callq	*%rax
     dbb:      	testq	%rax, %rax
     dbe:      	je	0xfcd <generic_tracepoint_event+0xfcd>
     dc4:      	negl	%eax
     dc6:      	movw	%ax, 0x20(%rsp)
     dcb:      	movw	$0x7, 0x22(%rsp)
     dd2:      	movabsq	$0x400000045, %rax      # imm = 0x400000045
     ddc:      	movq	%rax, 0x24(%rsp)
     de1:      	movq	(%rip), %rdi            # 0xde8 <generic_tracepoint_event+0xde8>
     de8:      	leaq	0x20(%rsp), %rsi
     ded:      	movl	$0x1, %eax
     df2:      	callq	*%rax
     df4:      	testq	%rax, %rax
     df7:      	je	0xfa9 <generic_tracepoint_event+0xfa9>
     dfd:      	incl	(%rax)
     dff:      	jmp	0xfcd <generic_tracepoint_event+0xfcd>
     e04:      	cmpl	$0x26, %r13d
     e08:      	je	0x12bd <generic_tracepoint_event+0x12bd>
     e0e:      	cmpl	$0x28, %r13d
     e12:      	je	0x1180 <generic_tracepoint_event+0x1180>
     e18:      	cmpl	$0x29, %r13d
     e1c:      	jne	0x145c <generic_tracepoint_event+0x145c>
     e22:      	leaq	0x10(%rsp), %rdi
     e27:      	movl	$0x8, %ecx
     e2c:      	movl	$0x4, %eax
     e31:      	movl	$0x8, %esi
     e36:      	callq	*%rax
     e38:      	testq	%rax, %rax
     e3b:      	je	0x1400 <generic_tracepoint_event+0x1400>
     e41:      	negl	%eax
     e43:      	movw	%ax, 0x20(%rsp)
     e48:      	movw	$0x7, 0x22(%rsp)
     e4f:      	movabsq	$0x4000000a8, %rax      # imm = 0x4000000A8
     e59:      	movq	%rax, 0x24(%rsp)
     e5e:      	movq	(%rip), %rdi            # 0xe65 <generic_tracepoint_event+0xe65>
     e65:      	leaq	0x20(%rsp), %rsi
     e6a:      	movl	$0x1, %eax
     e6f:      	callq	*%rax
     e71:      	testq	%rax, %rax
     e74:      	jne	0x1251 <generic_tracepoint_event+0x1251>
     e7a:      	movl	$0x1, 0x8(%rsp)
     e82:      	movq	(%rip), %rdi            # 0xe89 <generic_tracepoint_event+0xe89>
     e89:      	xorl	%ecx, %ecx
     e8b:      	leaq	0x20(%rsp), %rsi
     e90:      	leaq	0x8(%rsp), %rdx
     e95:      	movl	$0x2, %eax
     e9a:      	jmp	0x13fc <generic_tracepoint_event+0x13fc>
     e9f:      	cmpl	$-0xd, %r13d
     ea3:      	je	0xf45 <generic_tracepoint_event+0xf45>
     ea9:      	cmpl	$-0xc, %r13d
     ead:      	je	0xec8 <generic_tracepoint_event+0xec8>
     eaf:      	jmp	0x145c <generic_tracepoint_event+0x145c>
     eb4:      	cmpl	$0xc, %r13d
     eb8:      	je	0xf45 <generic_tracepoint_event+0xf45>
     ebe:      	cmpl	$0xd, %r13d
     ec2:      	jne	0x145c <generic_tracepoint_event+0x145c>
     ec8:      	leaq	0x8(%rsp), %rdi
     ecd:      	movl	$0x4, %ecx
     ed2:      	movl	$0x4, %eax
     ed7:      	movl	$0x4, %esi
     edc:      	callq	*%rax
     ede:      	testq	%rax, %rax
     ee1:      	je	0x1457 <generic_tracepoint_event+0x1457>
     ee7:      	negl	%eax
     ee9:      	movw	%ax, 0x20(%rsp)
     eee:      	movw	$0x7, 0x22(%rsp)
     ef5:      	movabsq	$0x40000005e, %rax      # imm = 0x40000005E
     eff:      	movq	%rax, 0x24(%rsp)
     f04:      	movq	(%rip), %rdi            # 0xf0b <generic_tracepoint_event+0xf0b>
     f0b:      	leaq	0x20(%rsp), %rsi
     f10:      	movl	$0x1, %eax
     f15:      	callq	*%rax
     f17:      	testq	%rax, %rax
     f1a:      	jne	0x1315 <generic_tracepoint_event+0x1315>
     f20:      	movl	$0x1, 0x10(%rsp)
     f28:      	movq	(%rip), %rdi            # 0xf2f <generic_tracepoint_event+0xf2f>
     f2f:      	xorl	%ecx, %ecx
     f31:      	leaq	0x20(%rsp), %rsi
     f36:      	leaq	0x10(%rsp), %rdx
     f3b:      	movl	$0x2, %eax
     f40:      	jmp	0x1453 <generic_tracepoint_event+0x1453>
     f45:      	leaq	0x8(%rsp), %rdi
     f4a:      	movl	$0x4, %ecx
     f4f:      	movl	$0x4, %eax
     f54:      	movl	$0x4, %esi
     f59:      	callq	*%rax
     f5b:      	testq	%rax, %rax
     f5e:      	je	0x1345 <generic_tracepoint_event+0x1345>
     f64:      	negl	%eax
     f66:      	movw	%ax, 0x20(%rsp)
     f6b:      	movw	$0x7, 0x22(%rsp)
     f72:      	movabsq	$0x400000056, %rax      # imm = 0x400000056
     f7c:      	movq	%rax, 0x24(%rsp)
     f81:      	movq	(%rip), %rdi            # 0xf88 <generic_tracepoint_event+0xf88>
     f88:      	leaq	0x20(%rsp), %rsi
     f8d:      	movl	$0x1, %eax
     f92:      	callq	*%rax
     f94:      	testq	%rax, %rax
     f97:      	je	0x1321 <generic_tracepoint_event+0x1321>
     f9d:      	incl	(%rax)
     f9f:      	movslq	0x8(%rsp), %r12
     fa4:      	jmp	0x145c <generic_tracepoint_event+0x145c>
     fa9:      	movl	$0x1, 0x8(%rsp)
     fb1:      	movq	(%rip), %rdi            # 0xfb8 <generic_tracepoint_event+0xfb8>
     fb8:      	xorl	%ecx, %ecx
     fba:      	leaq	0x20(%rsp), %rsi
     fbf:      	leaq	0x8(%rsp), %rdx
     fc4:      	movl	$0x2, %eax
     fc9:      	xorl	%ecx, %ecx
     fcb:      	callq	*%rax
     fcd:      	movq	0x10(%rsp), %r12
     fd2:      	cmpl	$0x1c, %r13d
     fd6:      	jne	0x145c <generic_tracepoint_event+0x145c>
     fdc:      	movl	$0x23, %eax
     fe1:      	callq	*%rax
     fe3:      	leaq	0x10(%rax), %rdx
     fe7:      	leaq	0x20(%rsp), %rdi
     fec:      	movl	$0x4, %ecx
     ff1:      	movl	$0x4, %eax
     ff6:      	movl	$0x4, %esi
     ffb:      	callq	*%rax
     ffd:      	movl	0x20(%rsp), %eax
    1001:      	andl	$-0x2, %eax
    1004:      	shll	$0x1e, %eax
    1007:      	orq	%rax, %r12
    100a:      	jmp	0x145c <generic_tracepoint_event+0x145c>
    100f:      	cmpl	$0x7, %r13d
    1013:      	jne	0x145c <generic_tracepoint_event+0x145c>
    1019:      	leaq	0x10(%rsp), %rdi
    101e:      	movl	$0x8, %ecx
    1023:      	movl	$0x4, %eax
    1028:      	movl	$0x8, %esi
    102d:      	callq	*%rax
    102f:      	testq	%rax, %rax
    1032:      	je	0x1400 <generic_tracepoint_event+0x1400>
    1038:      	negl	%eax
    103a:      	movw	%ax, 0x20(%rsp)
    103f:      	movw	$0x7, 0x22(%rsp)
    1046:      	movabsq	$0x40000009a, %rax      # imm = 0x40000009A
    1050:      	movq	%rax, 0x24(%rsp)
    1055:      	movq	(%rip), %rdi            # 0x105c <generic_tracepoint_event+0x105c>
    105c:      	leaq	0x20(%rsp), %rsi
    1061:      	movl	$0x1, %eax
    1066:      	callq	*%rax
    1068:      	testq	%rax, %rax
    106b:      	jne	0x1251 <generic_tracepoint_event+0x1251>
    1071:      	movl	$0x1, 0x8(%rsp)
    1079:      	movq	(%rip), %rdi            # 0x1080 <generic_tracepoint_event+0x1080>
    1080:      	xorl	%ecx, %ecx
    1082:      	leaq	0x20(%rsp), %rsi
    1087:      	leaq	0x8(%rsp), %rdx
    108c:      	movl	$0x2, %eax
    1091:      	jmp	0x13fc <generic_tracepoint_event+0x13fc>
    1096:      	movq	%rdx, %r12
    1099:      	jmp	0x145c <generic_tracepoint_event+0x145c>
    109e:      	leaq	0x10(%rsp), %rdi
    10a3:      	movl	$0x8, %ecx
    10a8:      	movl	$0x4, %eax
    10ad:      	movl	$0x8, %esi
    10b2:      	callq	*%rax
    10b4:      	testq	%rax, %rax
    10b7:      	je	0x1400 <generic_tracepoint_event+0x1400>
    10bd:      	negl	%eax
    10bf:      	movw	%ax, 0x20(%rsp)
    10c4:      	movw	$0x7, 0x22(%rsp)
    10cb:      	movabsq	$0x400000093, %rax      # imm = 0x400000093
    10d5:      	movq	%rax, 0x24(%rsp)
    10da:      	movq	(%rip), %rdi            # 0x10e1 <generic_tracepoint_event+0x10e1>
    10e1:      	leaq	0x20(%rsp), %rsi
    10e6:      	movl	$0x1, %eax
    10eb:      	callq	*%rax
    10ed:      	testq	%rax, %rax
    10f0:      	jne	0x1251 <generic_tracepoint_event+0x1251>
    10f6:      	movl	$0x1, 0x8(%rsp)
    10fe:      	movq	(%rip), %rdi            # 0x1105 <generic_tracepoint_event+0x1105>
    1105:      	xorl	%ecx, %ecx
    1107:      	leaq	0x20(%rsp), %rsi
    110c:      	leaq	0x8(%rsp), %rdx
    1111:      	movl	$0x2, %eax
    1116:      	jmp	0x13fc <generic_tracepoint_event+0x13fc>
    111b:      	leaq	0x8(%rsp), %rdi
    1120:      	movl	$0x1, %ecx
    1125:      	movl	$0x4, %eax
    112a:      	movl	$0x1, %esi
    112f:      	callq	*%rax
    1131:      	testq	%rax, %rax
    1134:      	je	0x13a2 <generic_tracepoint_event+0x13a2>
    113a:      	negl	%eax
    113c:      	movw	%ax, 0x20(%rsp)
    1141:      	movw	$0x7, 0x22(%rsp)
    1148:      	movabsq	$0x40000007a, %rax      # imm = 0x40000007A
    1152:      	movq	%rax, 0x24(%rsp)
    1157:      	movq	(%rip), %rdi            # 0x115e <generic_tracepoint_event+0x115e>
    115e:      	leaq	0x20(%rsp), %rsi
    1163:      	movl	$0x1, %eax
    1168:      	callq	*%rax
    116a:      	testq	%rax, %rax
    116d:      	je	0x137e <generic_tracepoint_event+0x137e>
    1173:      	incl	(%rax)
    1175:      	movsbq	0x8(%rsp), %r12
    117b:      	jmp	0x145c <generic_tracepoint_event+0x145c>
    1180:      	leaq	0x10(%rsp), %rdi
    1185:      	movl	$0x8, %ecx
    118a:      	movl	$0x4, %eax
    118f:      	movl	$0x8, %esi
    1194:      	callq	*%rax
    1196:      	testq	%rax, %rax
    1199:      	je	0x1400 <generic_tracepoint_event+0x1400>
    119f:      	negl	%eax
    11a1:      	movw	%ax, 0x20(%rsp)
    11a6:      	movw	$0x7, 0x22(%rsp)
    11ad:      	movabsq	$0x4000000a1, %rax      # imm = 0x4000000A1
    11b7:      	movq	%rax, 0x24(%rsp)
    11bc:      	movq	(%rip), %rdi            # 0x11c3 <generic_tracepoint_event+0x11c3>
    11c3:      	leaq	0x20(%rsp), %rsi
    11c8:      	movl	$0x1, %eax
    11cd:      	callq	*%rax
    11cf:      	testq	%rax, %rax
    11d2:      	jne	0x1251 <generic_tracepoint_event+0x1251>
    11d4:      	movl	$0x1, 0x8(%rsp)
    11dc:      	movq	(%rip), %rdi            # 0x11e3 <generic_tracepoint_event+0x11e3>
    11e3:      	xorl	%ecx, %ecx
    11e5:      	leaq	0x20(%rsp), %rsi
    11ea:      	leaq	0x8(%rsp), %rdx
    11ef:      	movl	$0x2, %eax
    11f4:      	jmp	0x13fc <generic_tracepoint_event+0x13fc>
    11f9:      	leaq	0x10(%rsp), %rdi
    11fe:      	movl	$0x8, %ecx
    1203:      	movl	$0x4, %eax
    1208:      	movl	$0x8, %esi
    120d:      	callq	*%rax
    120f:      	testq	%rax, %rax
    1212:      	je	0x1400 <generic_tracepoint_event+0x1400>
    1218:      	negl	%eax
    121a:      	movw	%ax, 0x20(%rsp)
    121f:      	movw	$0x7, 0x22(%rsp)
    1226:      	movabsq	$0x40000004e, %rax      # imm = 0x40000004E
    1230:      	movq	%rax, 0x24(%rsp)
    1235:      	movq	(%rip), %rdi            # 0x123c <generic_tracepoint_event+0x123c>
    123c:      	leaq	0x20(%rsp), %rsi
    1241:      	movl	$0x1, %eax
    1246:      	callq	*%rax
    1248:      	testq	%rax, %rax
    124b:      	je	0x13dc <generic_tracepoint_event+0x13dc>
    1251:      	incl	(%rax)
    1253:      	jmp	0x1400 <generic_tracepoint_event+0x1400>
    1258:      	leaq	0x8(%rsp), %rdi
    125d:      	movl	$0x2, %ecx
    1262:      	movl	$0x4, %eax
    1267:      	movl	$0x2, %esi
    126c:      	callq	*%rax
    126e:      	testq	%rax, %rax
    1271:      	je	0x142b <generic_tracepoint_event+0x142b>
    1277:      	negl	%eax
    1279:      	movw	%ax, 0x20(%rsp)
    127e:      	movw	$0x7, 0x22(%rsp)
    1285:      	movabsq	$0x400000065, %rax      # imm = 0x400000065
    128f:      	movq	%rax, 0x24(%rsp)
    1294:      	movq	(%rip), %rdi            # 0x129b <generic_tracepoint_event+0x129b>
    129b:      	leaq	0x20(%rsp), %rsi
    12a0:      	movl	$0x1, %eax
    12a5:      	callq	*%rax
    12a7:      	testq	%rax, %rax
    12aa:      	je	0x1407 <generic_tracepoint_event+0x1407>
    12b0:      	incl	(%rax)
    12b2:      	movzwl	0x8(%rsp), %r12d
    12b8:      	jmp	0x145c <generic_tracepoint_event+0x145c>
    12bd:      	leaq	0x8(%rsp), %rdi
    12c2:      	movl	$0x4, %ecx
    12c7:      	movl	$0x4, %eax
    12cc:      	movl	$0x4, %esi
    12d1:      	callq	*%rax
    12d3:      	testq	%rax, %rax
    12d6:      	je	0x1457 <generic_tracepoint_event+0x1457>
    12dc:      	negl	%eax
    12de:      	movw	%ax, 0x20(%rsp)
    12e3:      	movw	$0x7, 0x22(%rsp)
    12ea:      	movabsq	$0x400000088, %rax      # imm = 0x400000088
    12f4:      	movq	%rax, 0x24(%rsp)
    12f9:      	movq	(%rip), %rdi            # 0x1300 <generic_tracepoint_event+0x1300>
    1300:      	leaq	0x20(%rsp), %rsi
    1305:      	movl	$0x1, %eax
    130a:      	callq	*%rax
    130c:      	testq	%rax, %rax
    130f:      	je	0x1433 <generic_tracepoint_event+0x1433>
    1315:      	incl	(%rax)
    1317:      	movl	0x8(%rsp), %r12d
    131c:      	jmp	0x145c <generic_tracepoint_event+0x145c>
    1321:      	movl	$0x1, 0x10(%rsp)
    1329:      	movq	(%rip), %rdi            # 0x1330 <generic_tracepoint_event+0x1330>
    1330:      	xorl	%ecx, %ecx
    1332:      	leaq	0x20(%rsp), %rsi
    1337:      	leaq	0x10(%rsp), %rdx
    133c:      	movl	$0x2, %eax
    1341:      	xorl	%ecx, %ecx
    1343:      	callq	*%rax
    1345:      	movslq	0x8(%rsp), %r12
    134a:      	jmp	0x145c <generic_tracepoint_event+0x145c>
    134f:      	movl	$0x1, 0x10(%rsp)
    1357:      	movq	(%rip), %rdi            # 0x135e <generic_tracepoint_event+0x135e>
    135e:      	xorl	%ecx, %ecx
    1360:      	leaq	0x20(%rsp), %rsi
    1365:      	leaq	0x10(%rsp), %rdx
    136a:      	movl	$0x2, %eax
    136f:      	xorl	%ecx, %ecx
    1371:      	callq	*%rax
    1373:      	movswq	0x8(%rsp), %r12
    1379:      	jmp	0x145c <generic_tracepoint_event+0x145c>
    137e:      	movl	$0x1, 0x10(%rsp)
    1386:      	movq	(%rip), %rdi            # 0x138d <generic_tracepoint_event+0x138d>
    138d:      	xorl	%ecx, %ecx
    138f:      	leaq	0x20(%rsp), %rsi
    1394:      	leaq	0x10(%rsp), %rdx
    1399:      	movl	$0x2, %eax
    139e:      	xorl	%ecx, %ecx
    13a0:      	callq	*%rax
    13a2:      	movsbq	0x8(%rsp), %r12
    13a8:      	jmp	0x145c <generic_tracepoint_event+0x145c>
    13ad:      	movl	$0x1, 0x10(%rsp)
    13b5:      	movq	(%rip), %rdi            # 0x13bc <generic_tracepoint_event+0x13bc>
    13bc:      	xorl	%ecx, %ecx
    13be:      	leaq	0x20(%rsp), %rsi
    13c3:      	leaq	0x10(%rsp), %rdx
    13c8:      	movl	$0x2, %eax
    13cd:      	xorl	%ecx, %ecx
    13cf:      	callq	*%rax
    13d1:      	movzbl	0x8(%rsp), %r12d
    13d7:      	jmp	0x145c <generic_tracepoint_event+0x145c>
    13dc:      	movl	$0x1, 0x8(%rsp)
    13e4:      	movq	(%rip), %rdi            # 0x13eb <generic_tracepoint_event+0x13eb>
    13eb:      	xorl	%ecx, %ecx
    13ed:      	leaq	0x20(%rsp), %rsi
    13f2:      	leaq	0x8(%rsp), %rdx
    13f7:      	movl	$0x2, %eax
    13fc:      	xorl	%ecx, %ecx
    13fe:      	callq	*%rax
    1400:      	movq	0x10(%rsp), %r12
    1405:      	jmp	0x145c <generic_tracepoint_event+0x145c>
    1407:      	movl	$0x1, 0x10(%rsp)
    140f:      	movq	(%rip), %rdi            # 0x1416 <generic_tracepoint_event+0x1416>
    1416:      	xorl	%ecx, %ecx
    1418:      	leaq	0x20(%rsp), %rsi
    141d:      	leaq	0x10(%rsp), %rdx
    1422:      	movl	$0x2, %eax
    1427:      	xorl	%ecx, %ecx
    1429:      	callq	*%rax
    142b:      	movzwl	0x8(%rsp), %r12d
    1431:      	jmp	0x145c <generic_tracepoint_event+0x145c>
    1433:      	movl	$0x1, 0x10(%rsp)
    143b:      	movq	(%rip), %rdi            # 0x1442 <generic_tracepoint_event+0x1442>
    1442:      	xorl	%ecx, %ecx
    1444:      	leaq	0x20(%rsp), %rsi
    1449:      	leaq	0x10(%rsp), %rdx
    144e:      	movl	$0x2, %eax
    1453:      	xorl	%ecx, %ecx
    1455:      	callq	*%rax
    1457:      	movl	0x8(%rsp), %r12d
    145c:      	movq	%r12, 0x5e58(%r14)
    1463:      	movzwl	0x34(%r15), %edx
    1468:      	movl	0xc(%r15), %r13d
    146c:      	addq	%rbx, %rdx
    146f:      	xorl	%r12d, %r12d
    1472:      	cmpl	$0xb, %r13d
    1476:      	jg	0x14af <generic_tracepoint_event+0x14af>
    1478:      	cmpl	$0x3, %r13d
    147c:      	jle	0x1546 <generic_tracepoint_event+0x1546>
    1482:      	cmpl	$0x6, %r13d
    1486:      	jg	0x166d <generic_tracepoint_event+0x166d>
    148c:      	cmpl	$0x4, %r13d
    1490:      	je	0x1ace <generic_tracepoint_event+0x1ace>
    1496:      	cmpl	$0x5, %r13d
    149a:      	je	0x1973 <generic_tracepoint_event+0x1973>
    14a0:      	cmpl	$0x6, %r13d
    14a4:      	je	0x1567 <generic_tracepoint_event+0x1567>
    14aa:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    14af:      	cmpl	$0x1d, %r13d
    14b3:      	jle	0x15e4 <generic_tracepoint_event+0x15e4>
    14b9:      	cmpl	$0x25, %r13d
    14bd:      	jg	0x16d9 <generic_tracepoint_event+0x16d9>
    14c3:      	cmpl	$0x1e, %r13d
    14c7:      	je	0x1b2d <generic_tracepoint_event+0x1b2d>
    14cd:      	cmpl	$0x1f, %r13d
    14d1:      	je	0x19f0 <generic_tracepoint_event+0x19f0>
    14d7:      	cmpl	$0x20, %r13d
    14db:      	jne	0x1d31 <generic_tracepoint_event+0x1d31>
    14e1:      	leaq	0x8(%rsp), %rdi
    14e6:      	movl	$0x1, %ecx
    14eb:      	movl	$0x4, %eax
    14f0:      	movl	$0x1, %esi
    14f5:      	callq	*%rax
    14f7:      	testq	%rax, %rax
    14fa:      	je	0x1ca6 <generic_tracepoint_event+0x1ca6>
    1500:      	negl	%eax
    1502:      	movw	%ax, 0x20(%rsp)
    1507:      	movw	$0x7, 0x22(%rsp)
    150e:      	movabsq	$0x400000073, %rax      # imm = 0x400000073
    1518:      	movq	%rax, 0x24(%rsp)
    151d:      	movq	(%rip), %rdi            # 0x1524 <generic_tracepoint_event+0x1524>
    1524:      	leaq	0x20(%rsp), %rsi
    1529:      	movl	$0x1, %eax
    152e:      	callq	*%rax
    1530:      	testq	%rax, %rax
    1533:      	je	0x1c82 <generic_tracepoint_event+0x1c82>
    1539:      	incl	(%rax)
    153b:      	movzbl	0x8(%rsp), %r12d
    1541:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    1546:      	cmpl	$-0xc, %r13d
    154a:      	jle	0x1774 <generic_tracepoint_event+0x1774>
    1550:      	leal	0xb(%r13), %eax
    1554:      	cmpl	$0x2, %eax
    1557:      	jb	0x167a <generic_tracepoint_event+0x167a>
    155d:      	cmpl	$0x2, %r13d
    1561:      	jne	0x1d31 <generic_tracepoint_event+0x1d31>
    1567:      	leaq	0x10(%rsp), %rdi
    156c:      	movl	$0x8, %ecx
    1571:      	movl	$0x4, %eax
    1576:      	movl	$0x8, %esi
    157b:      	callq	*%rax
    157d:      	testq	%rax, %rax
    1580:      	je	0x1cd5 <generic_tracepoint_event+0x1cd5>
    1586:      	negl	%eax
    1588:      	movw	%ax, 0x20(%rsp)
    158d:      	movw	$0x7, 0x22(%rsp)
    1594:      	movabsq	$0x400000081, %rax      # imm = 0x400000081
    159e:      	movq	%rax, 0x24(%rsp)
    15a3:      	movq	(%rip), %rdi            # 0x15aa <generic_tracepoint_event+0x15aa>
    15aa:      	leaq	0x20(%rsp), %rsi
    15af:      	movl	$0x1, %eax
    15b4:      	callq	*%rax
    15b6:      	testq	%rax, %rax
    15b9:      	jne	0x1b26 <generic_tracepoint_event+0x1b26>
    15bf:      	movl	$0x1, 0x8(%rsp)
    15c7:      	movq	(%rip), %rdi            # 0x15ce <generic_tracepoint_event+0x15ce>
    15ce:      	xorl	%ecx, %ecx
    15d0:      	leaq	0x20(%rsp), %rsi
    15d5:      	leaq	0x8(%rsp), %rdx
    15da:      	movl	$0x2, %eax
    15df:      	jmp	0x1cd1 <generic_tracepoint_event+0x1cd1>
    15e4:      	cmpl	$0x11, %r13d
    15e8:      	jle	0x1789 <generic_tracepoint_event+0x1789>
    15ee:      	cmpl	$0x12, %r13d
    15f2:      	je	0x196b <generic_tracepoint_event+0x196b>
    15f8:      	cmpl	$0x1c, %r13d
    15fc:      	je	0x167a <generic_tracepoint_event+0x167a>
    15fe:      	cmpl	$0x1d, %r13d
    1602:      	jne	0x1d31 <generic_tracepoint_event+0x1d31>
    1608:      	leaq	0x8(%rsp), %rdi
    160d:      	movl	$0x2, %ecx
    1612:      	movl	$0x4, %eax
    1617:      	movl	$0x2, %esi
    161c:      	callq	*%rax
    161e:      	testq	%rax, %rax
    1621:      	je	0x1c48 <generic_tracepoint_event+0x1c48>
    1627:      	negl	%eax
    1629:      	movw	%ax, 0x20(%rsp)
    162e:      	movw	$0x7, 0x22(%rsp)
    1635:      	movabsq	$0x40000006c, %rax      # imm = 0x40000006C
    163f:      	movq	%rax, 0x24(%rsp)
    1644:      	movq	(%rip), %rdi            # 0x164b <generic_tracepoint_event+0x164b>
    164b:      	leaq	0x20(%rsp), %rsi
    1650:      	movl	$0x1, %eax
    1655:      	callq	*%rax
    1657:      	testq	%rax, %rax
    165a:      	je	0x1c24 <generic_tracepoint_event+0x1c24>
    1660:      	incl	(%rax)
    1662:      	movswq	0x8(%rsp), %r12
    1668:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    166d:      	leal	-0xa(%r13), %eax
    1671:      	cmpl	$0x2, %eax
    1674:      	jae	0x18e4 <generic_tracepoint_event+0x18e4>
    167a:      	leaq	0x10(%rsp), %rdi
    167f:      	movl	$0x8, %ecx
    1684:      	movl	$0x4, %eax
    1689:      	movl	$0x8, %esi
    168e:      	callq	*%rax
    1690:      	testq	%rax, %rax
    1693:      	je	0x18a2 <generic_tracepoint_event+0x18a2>
    1699:      	negl	%eax
    169b:      	movw	%ax, 0x20(%rsp)
    16a0:      	movw	$0x7, 0x22(%rsp)
    16a7:      	movabsq	$0x400000045, %rax      # imm = 0x400000045
    16b1:      	movq	%rax, 0x24(%rsp)
    16b6:      	movq	(%rip), %rdi            # 0x16bd <generic_tracepoint_event+0x16bd>
    16bd:      	leaq	0x20(%rsp), %rsi
    16c2:      	movl	$0x1, %eax
    16c7:      	callq	*%rax
    16c9:      	testq	%rax, %rax
    16cc:      	je	0x187e <generic_tracepoint_event+0x187e>
    16d2:      	incl	(%rax)
    16d4:      	jmp	0x18a2 <generic_tracepoint_event+0x18a2>
    16d9:      	cmpl	$0x26, %r13d
    16dd:      	je	0x1b92 <generic_tracepoint_event+0x1b92>
    16e3:      	cmpl	$0x28, %r13d
    16e7:      	je	0x1a55 <generic_tracepoint_event+0x1a55>
    16ed:      	cmpl	$0x29, %r13d
    16f1:      	jne	0x1d31 <generic_tracepoint_event+0x1d31>
    16f7:      	leaq	0x10(%rsp), %rdi
    16fc:      	movl	$0x8, %ecx
    1701:      	movl	$0x4, %eax
    1706:      	movl	$0x8, %esi
    170b:      	callq	*%rax
    170d:      	testq	%rax, %rax
    1710:      	je	0x1cd5 <generic_tracepoint_event+0x1cd5>
    1716:      	negl	%eax
    1718:      	movw	%ax, 0x20(%rsp)
    171d:      	movw	$0x7, 0x22(%rsp)
    1724:      	movabsq	$0x4000000a8, %rax      # imm = 0x4000000A8
    172e:      	movq	%rax, 0x24(%rsp)
    1733:      	movq	(%rip), %rdi            # 0x173a <generic_tracepoint_event+0x173a>
    173a:      	leaq	0x20(%rsp), %rsi
    173f:      	movl	$0x1, %eax
    1744:      	callq	*%rax
    1746:      	testq	%rax, %rax
    1749:      	jne	0x1b26 <generic_tracepoint_event+0x1b26>
    174f:      	movl	$0x1, 0x8(%rsp)
    1757:      	movq	(%rip), %rdi            # 0x175e <generic_tracepoint_event+0x175e>
    175e:      	xorl	%ecx, %ecx
    1760:      	leaq	0x20(%rsp), %rsi
    1765:      	leaq	0x8(%rsp), %rdx
    176a:      	movl	$0x2, %eax
    176f:      	jmp	0x1cd1 <generic_tracepoint_event+0x1cd1>
    1774:      	cmpl	$-0xd, %r13d
    1778:      	je	0x181a <generic_tracepoint_event+0x181a>
    177e:      	cmpl	$-0xc, %r13d
    1782:      	je	0x179d <generic_tracepoint_event+0x179d>
    1784:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    1789:      	cmpl	$0xc, %r13d
    178d:      	je	0x181a <generic_tracepoint_event+0x181a>
    1793:      	cmpl	$0xd, %r13d
    1797:      	jne	0x1d31 <generic_tracepoint_event+0x1d31>
    179d:      	leaq	0x8(%rsp), %rdi
    17a2:      	movl	$0x4, %ecx
    17a7:      	movl	$0x4, %eax
    17ac:      	movl	$0x4, %esi
    17b1:      	callq	*%rax
    17b3:      	testq	%rax, %rax
    17b6:      	je	0x1d2c <generic_tracepoint_event+0x1d2c>
    17bc:      	negl	%eax
    17be:      	movw	%ax, 0x20(%rsp)
    17c3:      	movw	$0x7, 0x22(%rsp)
    17ca:      	movabsq	$0x40000005e, %rax      # imm = 0x40000005E
    17d4:      	movq	%rax, 0x24(%rsp)
    17d9:      	movq	(%rip), %rdi            # 0x17e0 <generic_tracepoint_event+0x17e0>
    17e0:      	leaq	0x20(%rsp), %rsi
    17e5:      	movl	$0x1, %eax
    17ea:      	callq	*%rax
    17ec:      	testq	%rax, %rax
    17ef:      	jne	0x1bea <generic_tracepoint_event+0x1bea>
    17f5:      	movl	$0x1, 0x10(%rsp)
    17fd:      	movq	(%rip), %rdi            # 0x1804 <generic_tracepoint_event+0x1804>
    1804:      	xorl	%ecx, %ecx
    1806:      	leaq	0x20(%rsp), %rsi
    180b:      	leaq	0x10(%rsp), %rdx
    1810:      	movl	$0x2, %eax
    1815:      	jmp	0x1d28 <generic_tracepoint_event+0x1d28>
    181a:      	leaq	0x8(%rsp), %rdi
    181f:      	movl	$0x4, %ecx
    1824:      	movl	$0x4, %eax
    1829:      	movl	$0x4, %esi
    182e:      	callq	*%rax
    1830:      	testq	%rax, %rax
    1833:      	je	0x1c1a <generic_tracepoint_event+0x1c1a>
    1839:      	negl	%eax
    183b:      	movw	%ax, 0x20(%rsp)
    1840:      	movw	$0x7, 0x22(%rsp)
    1847:      	movabsq	$0x400000056, %rax      # imm = 0x400000056
    1851:      	movq	%rax, 0x24(%rsp)
    1856:      	movq	(%rip), %rdi            # 0x185d <generic_tracepoint_event+0x185d>
    185d:      	leaq	0x20(%rsp), %rsi
    1862:      	movl	$0x1, %eax
    1867:      	callq	*%rax
    1869:      	testq	%rax, %rax
    186c:      	je	0x1bf6 <generic_tracepoint_event+0x1bf6>
    1872:      	incl	(%rax)
    1874:      	movslq	0x8(%rsp), %r12
    1879:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    187e:      	movl	$0x1, 0x8(%rsp)
    1886:      	movq	(%rip), %rdi            # 0x188d <generic_tracepoint_event+0x188d>
    188d:      	xorl	%ecx, %ecx
    188f:      	leaq	0x20(%rsp), %rsi
    1894:      	leaq	0x8(%rsp), %rdx
    1899:      	movl	$0x2, %eax
    189e:      	xorl	%ecx, %ecx
    18a0:      	callq	*%rax
    18a2:      	movq	0x10(%rsp), %r12
    18a7:      	cmpl	$0x1c, %r13d
    18ab:      	jne	0x1d31 <generic_tracepoint_event+0x1d31>
    18b1:      	movl	$0x23, %eax
    18b6:      	callq	*%rax
    18b8:      	leaq	0x10(%rax), %rdx
    18bc:      	leaq	0x20(%rsp), %rdi
    18c1:      	movl	$0x4, %ecx
    18c6:      	movl	$0x4, %eax
    18cb:      	movl	$0x4, %esi
    18d0:      	callq	*%rax
    18d2:      	movl	0x20(%rsp), %eax
    18d6:      	andl	$-0x2, %eax
    18d9:      	shll	$0x1e, %eax
    18dc:      	orq	%rax, %r12
    18df:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    18e4:      	cmpl	$0x7, %r13d
    18e8:      	jne	0x1d31 <generic_tracepoint_event+0x1d31>
    18ee:      	leaq	0x10(%rsp), %rdi
    18f3:      	movl	$0x8, %ecx
    18f8:      	movl	$0x4, %eax
    18fd:      	movl	$0x8, %esi
    1902:      	callq	*%rax
    1904:      	testq	%rax, %rax
    1907:      	je	0x1cd5 <generic_tracepoint_event+0x1cd5>
    190d:      	negl	%eax
    190f:      	movw	%ax, 0x20(%rsp)
    1914:      	movw	$0x7, 0x22(%rsp)
    191b:      	movabsq	$0x40000009a, %rax      # imm = 0x40000009A
    1925:      	movq	%rax, 0x24(%rsp)
    192a:      	movq	(%rip), %rdi            # 0x1931 <generic_tracepoint_event+0x1931>
    1931:      	leaq	0x20(%rsp), %rsi
    1936:      	movl	$0x1, %eax
    193b:      	callq	*%rax
    193d:      	testq	%rax, %rax
    1940:      	jne	0x1b26 <generic_tracepoint_event+0x1b26>
    1946:      	movl	$0x1, 0x8(%rsp)
    194e:      	movq	(%rip), %rdi            # 0x1955 <generic_tracepoint_event+0x1955>
    1955:      	xorl	%ecx, %ecx
    1957:      	leaq	0x20(%rsp), %rsi
    195c:      	leaq	0x8(%rsp), %rdx
    1961:      	movl	$0x2, %eax
    1966:      	jmp	0x1cd1 <generic_tracepoint_event+0x1cd1>
    196b:      	movq	%rdx, %r12
    196e:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    1973:      	leaq	0x10(%rsp), %rdi
    1978:      	movl	$0x8, %ecx
    197d:      	movl	$0x4, %eax
    1982:      	movl	$0x8, %esi
    1987:      	callq	*%rax
    1989:      	testq	%rax, %rax
    198c:      	je	0x1cd5 <generic_tracepoint_event+0x1cd5>
    1992:      	negl	%eax
    1994:      	movw	%ax, 0x20(%rsp)
    1999:      	movw	$0x7, 0x22(%rsp)
    19a0:      	movabsq	$0x400000093, %rax      # imm = 0x400000093
    19aa:      	movq	%rax, 0x24(%rsp)
    19af:      	movq	(%rip), %rdi            # 0x19b6 <generic_tracepoint_event+0x19b6>
    19b6:      	leaq	0x20(%rsp), %rsi
    19bb:      	movl	$0x1, %eax
    19c0:      	callq	*%rax
    19c2:      	testq	%rax, %rax
    19c5:      	jne	0x1b26 <generic_tracepoint_event+0x1b26>
    19cb:      	movl	$0x1, 0x8(%rsp)
    19d3:      	movq	(%rip), %rdi            # 0x19da <generic_tracepoint_event+0x19da>
    19da:      	xorl	%ecx, %ecx
    19dc:      	leaq	0x20(%rsp), %rsi
    19e1:      	leaq	0x8(%rsp), %rdx
    19e6:      	movl	$0x2, %eax
    19eb:      	jmp	0x1cd1 <generic_tracepoint_event+0x1cd1>
    19f0:      	leaq	0x8(%rsp), %rdi
    19f5:      	movl	$0x1, %ecx
    19fa:      	movl	$0x4, %eax
    19ff:      	movl	$0x1, %esi
    1a04:      	callq	*%rax
    1a06:      	testq	%rax, %rax
    1a09:      	je	0x1c77 <generic_tracepoint_event+0x1c77>
    1a0f:      	negl	%eax
    1a11:      	movw	%ax, 0x20(%rsp)
    1a16:      	movw	$0x7, 0x22(%rsp)
    1a1d:      	movabsq	$0x40000007a, %rax      # imm = 0x40000007A
    1a27:      	movq	%rax, 0x24(%rsp)
    1a2c:      	movq	(%rip), %rdi            # 0x1a33 <generic_tracepoint_event+0x1a33>
    1a33:      	leaq	0x20(%rsp), %rsi
    1a38:      	movl	$0x1, %eax
    1a3d:      	callq	*%rax
    1a3f:      	testq	%rax, %rax
    1a42:      	je	0x1c53 <generic_tracepoint_event+0x1c53>
    1a48:      	incl	(%rax)
    1a4a:      	movsbq	0x8(%rsp), %r12
    1a50:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    1a55:      	leaq	0x10(%rsp), %rdi
    1a5a:      	movl	$0x8, %ecx
    1a5f:      	movl	$0x4, %eax
    1a64:      	movl	$0x8, %esi
    1a69:      	callq	*%rax
    1a6b:      	testq	%rax, %rax
    1a6e:      	je	0x1cd5 <generic_tracepoint_event+0x1cd5>
    1a74:      	negl	%eax
    1a76:      	movw	%ax, 0x20(%rsp)
    1a7b:      	movw	$0x7, 0x22(%rsp)
    1a82:      	movabsq	$0x4000000a1, %rax      # imm = 0x4000000A1
    1a8c:      	movq	%rax, 0x24(%rsp)
    1a91:      	movq	(%rip), %rdi            # 0x1a98 <generic_tracepoint_event+0x1a98>
    1a98:      	leaq	0x20(%rsp), %rsi
    1a9d:      	movl	$0x1, %eax
    1aa2:      	callq	*%rax
    1aa4:      	testq	%rax, %rax
    1aa7:      	jne	0x1b26 <generic_tracepoint_event+0x1b26>
    1aa9:      	movl	$0x1, 0x8(%rsp)
    1ab1:      	movq	(%rip), %rdi            # 0x1ab8 <generic_tracepoint_event+0x1ab8>
    1ab8:      	xorl	%ecx, %ecx
    1aba:      	leaq	0x20(%rsp), %rsi
    1abf:      	leaq	0x8(%rsp), %rdx
    1ac4:      	movl	$0x2, %eax
    1ac9:      	jmp	0x1cd1 <generic_tracepoint_event+0x1cd1>
    1ace:      	leaq	0x10(%rsp), %rdi
    1ad3:      	movl	$0x8, %ecx
    1ad8:      	movl	$0x4, %eax
    1add:      	movl	$0x8, %esi
    1ae2:      	callq	*%rax
    1ae4:      	testq	%rax, %rax
    1ae7:      	je	0x1cd5 <generic_tracepoint_event+0x1cd5>
    1aed:      	negl	%eax
    1aef:      	movw	%ax, 0x20(%rsp)
    1af4:      	movw	$0x7, 0x22(%rsp)
    1afb:      	movabsq	$0x40000004e, %rax      # imm = 0x40000004E
    1b05:      	movq	%rax, 0x24(%rsp)
    1b0a:      	movq	(%rip), %rdi            # 0x1b11 <generic_tracepoint_event+0x1b11>
    1b11:      	leaq	0x20(%rsp), %rsi
    1b16:      	movl	$0x1, %eax
    1b1b:      	callq	*%rax
    1b1d:      	testq	%rax, %rax
    1b20:      	je	0x1cb1 <generic_tracepoint_event+0x1cb1>
    1b26:      	incl	(%rax)
    1b28:      	jmp	0x1cd5 <generic_tracepoint_event+0x1cd5>
    1b2d:      	leaq	0x8(%rsp), %rdi
    1b32:      	movl	$0x2, %ecx
    1b37:      	movl	$0x4, %eax
    1b3c:      	movl	$0x2, %esi
    1b41:      	callq	*%rax
    1b43:      	testq	%rax, %rax
    1b46:      	je	0x1d00 <generic_tracepoint_event+0x1d00>
    1b4c:      	negl	%eax
    1b4e:      	movw	%ax, 0x20(%rsp)
    1b53:      	movw	$0x7, 0x22(%rsp)
    1b5a:      	movabsq	$0x400000065, %rax      # imm = 0x400000065
    1b64:      	movq	%rax, 0x24(%rsp)
    1b69:      	movq	(%rip), %rdi            # 0x1b70 <generic_tracepoint_event+0x1b70>
    1b70:      	leaq	0x20(%rsp), %rsi
    1b75:      	movl	$0x1, %eax
    1b7a:      	callq	*%rax
    1b7c:      	testq	%rax, %rax
    1b7f:      	je	0x1cdc <generic_tracepoint_event+0x1cdc>
    1b85:      	incl	(%rax)
    1b87:      	movzwl	0x8(%rsp), %r12d
    1b8d:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    1b92:      	leaq	0x8(%rsp), %rdi
    1b97:      	movl	$0x4, %ecx
    1b9c:      	movl	$0x4, %eax
    1ba1:      	movl	$0x4, %esi
    1ba6:      	callq	*%rax
    1ba8:      	testq	%rax, %rax
    1bab:      	je	0x1d2c <generic_tracepoint_event+0x1d2c>
    1bb1:      	negl	%eax
    1bb3:      	movw	%ax, 0x20(%rsp)
    1bb8:      	movw	$0x7, 0x22(%rsp)
    1bbf:      	movabsq	$0x400000088, %rax      # imm = 0x400000088
    1bc9:      	movq	%rax, 0x24(%rsp)
    1bce:      	movq	(%rip), %rdi            # 0x1bd5 <generic_tracepoint_event+0x1bd5>
    1bd5:      	leaq	0x20(%rsp), %rsi
    1bda:      	movl	$0x1, %eax
    1bdf:      	callq	*%rax
    1be1:      	testq	%rax, %rax
    1be4:      	je	0x1d08 <generic_tracepoint_event+0x1d08>
    1bea:      	incl	(%rax)
    1bec:      	movl	0x8(%rsp), %r12d
    1bf1:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    1bf6:      	movl	$0x1, 0x10(%rsp)
    1bfe:      	movq	(%rip), %rdi            # 0x1c05 <generic_tracepoint_event+0x1c05>
    1c05:      	xorl	%ecx, %ecx
    1c07:      	leaq	0x20(%rsp), %rsi
    1c0c:      	leaq	0x10(%rsp), %rdx
    1c11:      	movl	$0x2, %eax
    1c16:      	xorl	%ecx, %ecx
    1c18:      	callq	*%rax
    1c1a:      	movslq	0x8(%rsp), %r12
    1c1f:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    1c24:      	movl	$0x1, 0x10(%rsp)
    1c2c:      	movq	(%rip), %rdi            # 0x1c33 <generic_tracepoint_event+0x1c33>
    1c33:      	xorl	%ecx, %ecx
    1c35:      	leaq	0x20(%rsp), %rsi
    1c3a:      	leaq	0x10(%rsp), %rdx
    1c3f:      	movl	$0x2, %eax
    1c44:      	xorl	%ecx, %ecx
    1c46:      	callq	*%rax
    1c48:      	movswq	0x8(%rsp), %r12
    1c4e:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    1c53:      	movl	$0x1, 0x10(%rsp)
    1c5b:      	movq	(%rip), %rdi            # 0x1c62 <generic_tracepoint_event+0x1c62>
    1c62:      	xorl	%ecx, %ecx
    1c64:      	leaq	0x20(%rsp), %rsi
    1c69:      	leaq	0x10(%rsp), %rdx
    1c6e:      	movl	$0x2, %eax
    1c73:      	xorl	%ecx, %ecx
    1c75:      	callq	*%rax
    1c77:      	movsbq	0x8(%rsp), %r12
    1c7d:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    1c82:      	movl	$0x1, 0x10(%rsp)
    1c8a:      	movq	(%rip), %rdi            # 0x1c91 <generic_tracepoint_event+0x1c91>
    1c91:      	xorl	%ecx, %ecx
    1c93:      	leaq	0x20(%rsp), %rsi
    1c98:      	leaq	0x10(%rsp), %rdx
    1c9d:      	movl	$0x2, %eax
    1ca2:      	xorl	%ecx, %ecx
    1ca4:      	callq	*%rax
    1ca6:      	movzbl	0x8(%rsp), %r12d
    1cac:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    1cb1:      	movl	$0x1, 0x8(%rsp)
    1cb9:      	movq	(%rip), %rdi            # 0x1cc0 <generic_tracepoint_event+0x1cc0>
    1cc0:      	xorl	%ecx, %ecx
    1cc2:      	leaq	0x20(%rsp), %rsi
    1cc7:      	leaq	0x8(%rsp), %rdx
    1ccc:      	movl	$0x2, %eax
    1cd1:      	xorl	%ecx, %ecx
    1cd3:      	callq	*%rax
    1cd5:      	movq	0x10(%rsp), %r12
    1cda:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    1cdc:      	movl	$0x1, 0x10(%rsp)
    1ce4:      	movq	(%rip), %rdi            # 0x1ceb <generic_tracepoint_event+0x1ceb>
    1ceb:      	xorl	%ecx, %ecx
    1ced:      	leaq	0x20(%rsp), %rsi
    1cf2:      	leaq	0x10(%rsp), %rdx
    1cf7:      	movl	$0x2, %eax
    1cfc:      	xorl	%ecx, %ecx
    1cfe:      	callq	*%rax
    1d00:      	movzwl	0x8(%rsp), %r12d
    1d06:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    1d08:      	movl	$0x1, 0x10(%rsp)
    1d10:      	movq	(%rip), %rdi            # 0x1d17 <generic_tracepoint_event+0x1d17>
    1d17:      	xorl	%ecx, %ecx
    1d19:      	leaq	0x20(%rsp), %rsi
    1d1e:      	leaq	0x10(%rsp), %rdx
    1d23:      	movl	$0x2, %eax
    1d28:      	xorl	%ecx, %ecx
    1d2a:      	callq	*%rax
    1d2c:      	movl	0x8(%rsp), %r12d
    1d31:      	movq	%r12, 0x5e60(%r14)
    1d38:      	movzwl	0x38(%r15), %edx
    1d3d:      	movl	0x10(%r15), %r13d
    1d41:      	addq	%rbx, %rdx
    1d44:      	xorl	%r12d, %r12d
    1d47:      	cmpl	$0xb, %r13d
    1d4b:      	jg	0x1d84 <generic_tracepoint_event+0x1d84>
    1d4d:      	cmpl	$0x3, %r13d
    1d51:      	jle	0x1e1b <generic_tracepoint_event+0x1e1b>
    1d57:      	cmpl	$0x6, %r13d
    1d5b:      	jg	0x1f42 <generic_tracepoint_event+0x1f42>
    1d61:      	cmpl	$0x4, %r13d
    1d65:      	je	0x23a3 <generic_tracepoint_event+0x23a3>
    1d6b:      	cmpl	$0x5, %r13d
    1d6f:      	je	0x2248 <generic_tracepoint_event+0x2248>
    1d75:      	cmpl	$0x6, %r13d
    1d79:      	je	0x1e3c <generic_tracepoint_event+0x1e3c>
    1d7f:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    1d84:      	cmpl	$0x1d, %r13d
    1d88:      	jle	0x1eb9 <generic_tracepoint_event+0x1eb9>
    1d8e:      	cmpl	$0x25, %r13d
    1d92:      	jg	0x1fae <generic_tracepoint_event+0x1fae>
    1d98:      	cmpl	$0x1e, %r13d
    1d9c:      	je	0x2402 <generic_tracepoint_event+0x2402>
    1da2:      	cmpl	$0x1f, %r13d
    1da6:      	je	0x22c5 <generic_tracepoint_event+0x22c5>
    1dac:      	cmpl	$0x20, %r13d
    1db0:      	jne	0x2606 <generic_tracepoint_event+0x2606>
    1db6:      	leaq	0x8(%rsp), %rdi
    1dbb:      	movl	$0x1, %ecx
    1dc0:      	movl	$0x4, %eax
    1dc5:      	movl	$0x1, %esi
    1dca:      	callq	*%rax
    1dcc:      	testq	%rax, %rax
    1dcf:      	je	0x257b <generic_tracepoint_event+0x257b>
    1dd5:      	negl	%eax
    1dd7:      	movw	%ax, 0x20(%rsp)
    1ddc:      	movw	$0x7, 0x22(%rsp)
    1de3:      	movabsq	$0x400000073, %rax      # imm = 0x400000073
    1ded:      	movq	%rax, 0x24(%rsp)
    1df2:      	movq	(%rip), %rdi            # 0x1df9 <generic_tracepoint_event+0x1df9>
    1df9:      	leaq	0x20(%rsp), %rsi
    1dfe:      	movl	$0x1, %eax
    1e03:      	callq	*%rax
    1e05:      	testq	%rax, %rax
    1e08:      	je	0x2557 <generic_tracepoint_event+0x2557>
    1e0e:      	incl	(%rax)
    1e10:      	movzbl	0x8(%rsp), %r12d
    1e16:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    1e1b:      	cmpl	$-0xc, %r13d
    1e1f:      	jle	0x2049 <generic_tracepoint_event+0x2049>
    1e25:      	leal	0xb(%r13), %eax
    1e29:      	cmpl	$0x2, %eax
    1e2c:      	jb	0x1f4f <generic_tracepoint_event+0x1f4f>
    1e32:      	cmpl	$0x2, %r13d
    1e36:      	jne	0x2606 <generic_tracepoint_event+0x2606>
    1e3c:      	leaq	0x10(%rsp), %rdi
    1e41:      	movl	$0x8, %ecx
    1e46:      	movl	$0x4, %eax
    1e4b:      	movl	$0x8, %esi
    1e50:      	callq	*%rax
    1e52:      	testq	%rax, %rax
    1e55:      	je	0x25aa <generic_tracepoint_event+0x25aa>
    1e5b:      	negl	%eax
    1e5d:      	movw	%ax, 0x20(%rsp)
    1e62:      	movw	$0x7, 0x22(%rsp)
    1e69:      	movabsq	$0x400000081, %rax      # imm = 0x400000081
    1e73:      	movq	%rax, 0x24(%rsp)
    1e78:      	movq	(%rip), %rdi            # 0x1e7f <generic_tracepoint_event+0x1e7f>
    1e7f:      	leaq	0x20(%rsp), %rsi
    1e84:      	movl	$0x1, %eax
    1e89:      	callq	*%rax
    1e8b:      	testq	%rax, %rax
    1e8e:      	jne	0x23fb <generic_tracepoint_event+0x23fb>
    1e94:      	movl	$0x1, 0x8(%rsp)
    1e9c:      	movq	(%rip), %rdi            # 0x1ea3 <generic_tracepoint_event+0x1ea3>
    1ea3:      	xorl	%ecx, %ecx
    1ea5:      	leaq	0x20(%rsp), %rsi
    1eaa:      	leaq	0x8(%rsp), %rdx
    1eaf:      	movl	$0x2, %eax
    1eb4:      	jmp	0x25a6 <generic_tracepoint_event+0x25a6>
    1eb9:      	cmpl	$0x11, %r13d
    1ebd:      	jle	0x205e <generic_tracepoint_event+0x205e>
    1ec3:      	cmpl	$0x12, %r13d
    1ec7:      	je	0x2240 <generic_tracepoint_event+0x2240>
    1ecd:      	cmpl	$0x1c, %r13d
    1ed1:      	je	0x1f4f <generic_tracepoint_event+0x1f4f>
    1ed3:      	cmpl	$0x1d, %r13d
    1ed7:      	jne	0x2606 <generic_tracepoint_event+0x2606>
    1edd:      	leaq	0x8(%rsp), %rdi
    1ee2:      	movl	$0x2, %ecx
    1ee7:      	movl	$0x4, %eax
    1eec:      	movl	$0x2, %esi
    1ef1:      	callq	*%rax
    1ef3:      	testq	%rax, %rax
    1ef6:      	je	0x251d <generic_tracepoint_event+0x251d>
    1efc:      	negl	%eax
    1efe:      	movw	%ax, 0x20(%rsp)
    1f03:      	movw	$0x7, 0x22(%rsp)
    1f0a:      	movabsq	$0x40000006c, %rax      # imm = 0x40000006C
    1f14:      	movq	%rax, 0x24(%rsp)
    1f19:      	movq	(%rip), %rdi            # 0x1f20 <generic_tracepoint_event+0x1f20>
    1f20:      	leaq	0x20(%rsp), %rsi
    1f25:      	movl	$0x1, %eax
    1f2a:      	callq	*%rax
    1f2c:      	testq	%rax, %rax
    1f2f:      	je	0x24f9 <generic_tracepoint_event+0x24f9>
    1f35:      	incl	(%rax)
    1f37:      	movswq	0x8(%rsp), %r12
    1f3d:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    1f42:      	leal	-0xa(%r13), %eax
    1f46:      	cmpl	$0x2, %eax
    1f49:      	jae	0x21b9 <generic_tracepoint_event+0x21b9>
    1f4f:      	leaq	0x10(%rsp), %rdi
    1f54:      	movl	$0x8, %ecx
    1f59:      	movl	$0x4, %eax
    1f5e:      	movl	$0x8, %esi
    1f63:      	callq	*%rax
    1f65:      	testq	%rax, %rax
    1f68:      	je	0x2177 <generic_tracepoint_event+0x2177>
    1f6e:      	negl	%eax
    1f70:      	movw	%ax, 0x20(%rsp)
    1f75:      	movw	$0x7, 0x22(%rsp)
    1f7c:      	movabsq	$0x400000045, %rax      # imm = 0x400000045
    1f86:      	movq	%rax, 0x24(%rsp)
    1f8b:      	movq	(%rip), %rdi            # 0x1f92 <generic_tracepoint_event+0x1f92>
    1f92:      	leaq	0x20(%rsp), %rsi
    1f97:      	movl	$0x1, %eax
    1f9c:      	callq	*%rax
    1f9e:      	testq	%rax, %rax
    1fa1:      	je	0x2153 <generic_tracepoint_event+0x2153>
    1fa7:      	incl	(%rax)
    1fa9:      	jmp	0x2177 <generic_tracepoint_event+0x2177>
    1fae:      	cmpl	$0x26, %r13d
    1fb2:      	je	0x2467 <generic_tracepoint_event+0x2467>
    1fb8:      	cmpl	$0x28, %r13d
    1fbc:      	je	0x232a <generic_tracepoint_event+0x232a>
    1fc2:      	cmpl	$0x29, %r13d
    1fc6:      	jne	0x2606 <generic_tracepoint_event+0x2606>
    1fcc:      	leaq	0x10(%rsp), %rdi
    1fd1:      	movl	$0x8, %ecx
    1fd6:      	movl	$0x4, %eax
    1fdb:      	movl	$0x8, %esi
    1fe0:      	callq	*%rax
    1fe2:      	testq	%rax, %rax
    1fe5:      	je	0x25aa <generic_tracepoint_event+0x25aa>
    1feb:      	negl	%eax
    1fed:      	movw	%ax, 0x20(%rsp)
    1ff2:      	movw	$0x7, 0x22(%rsp)
    1ff9:      	movabsq	$0x4000000a8, %rax      # imm = 0x4000000A8
    2003:      	movq	%rax, 0x24(%rsp)
    2008:      	movq	(%rip), %rdi            # 0x200f <generic_tracepoint_event+0x200f>
    200f:      	leaq	0x20(%rsp), %rsi
    2014:      	movl	$0x1, %eax
    2019:      	callq	*%rax
    201b:      	testq	%rax, %rax
    201e:      	jne	0x23fb <generic_tracepoint_event+0x23fb>
    2024:      	movl	$0x1, 0x8(%rsp)
    202c:      	movq	(%rip), %rdi            # 0x2033 <generic_tracepoint_event+0x2033>
    2033:      	xorl	%ecx, %ecx
    2035:      	leaq	0x20(%rsp), %rsi
    203a:      	leaq	0x8(%rsp), %rdx
    203f:      	movl	$0x2, %eax
    2044:      	jmp	0x25a6 <generic_tracepoint_event+0x25a6>
    2049:      	cmpl	$-0xd, %r13d
    204d:      	je	0x20ef <generic_tracepoint_event+0x20ef>
    2053:      	cmpl	$-0xc, %r13d
    2057:      	je	0x2072 <generic_tracepoint_event+0x2072>
    2059:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    205e:      	cmpl	$0xc, %r13d
    2062:      	je	0x20ef <generic_tracepoint_event+0x20ef>
    2068:      	cmpl	$0xd, %r13d
    206c:      	jne	0x2606 <generic_tracepoint_event+0x2606>
    2072:      	leaq	0x8(%rsp), %rdi
    2077:      	movl	$0x4, %ecx
    207c:      	movl	$0x4, %eax
    2081:      	movl	$0x4, %esi
    2086:      	callq	*%rax
    2088:      	testq	%rax, %rax
    208b:      	je	0x2601 <generic_tracepoint_event+0x2601>
    2091:      	negl	%eax
    2093:      	movw	%ax, 0x20(%rsp)
    2098:      	movw	$0x7, 0x22(%rsp)
    209f:      	movabsq	$0x40000005e, %rax      # imm = 0x40000005E
    20a9:      	movq	%rax, 0x24(%rsp)
    20ae:      	movq	(%rip), %rdi            # 0x20b5 <generic_tracepoint_event+0x20b5>
    20b5:      	leaq	0x20(%rsp), %rsi
    20ba:      	movl	$0x1, %eax
    20bf:      	callq	*%rax
    20c1:      	testq	%rax, %rax
    20c4:      	jne	0x24bf <generic_tracepoint_event+0x24bf>
    20ca:      	movl	$0x1, 0x10(%rsp)
    20d2:      	movq	(%rip), %rdi            # 0x20d9 <generic_tracepoint_event+0x20d9>
    20d9:      	xorl	%ecx, %ecx
    20db:      	leaq	0x20(%rsp), %rsi
    20e0:      	leaq	0x10(%rsp), %rdx
    20e5:      	movl	$0x2, %eax
    20ea:      	jmp	0x25fd <generic_tracepoint_event+0x25fd>
    20ef:      	leaq	0x8(%rsp), %rdi
    20f4:      	movl	$0x4, %ecx
    20f9:      	movl	$0x4, %eax
    20fe:      	movl	$0x4, %esi
    2103:      	callq	*%rax
    2105:      	testq	%rax, %rax
    2108:      	je	0x24ef <generic_tracepoint_event+0x24ef>
    210e:      	negl	%eax
    2110:      	movw	%ax, 0x20(%rsp)
    2115:      	movw	$0x7, 0x22(%rsp)
    211c:      	movabsq	$0x400000056, %rax      # imm = 0x400000056
    2126:      	movq	%rax, 0x24(%rsp)
    212b:      	movq	(%rip), %rdi            # 0x2132 <generic_tracepoint_event+0x2132>
    2132:      	leaq	0x20(%rsp), %rsi
    2137:      	movl	$0x1, %eax
    213c:      	callq	*%rax
    213e:      	testq	%rax, %rax
    2141:      	je	0x24cb <generic_tracepoint_event+0x24cb>
    2147:      	incl	(%rax)
    2149:      	movslq	0x8(%rsp), %r12
    214e:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    2153:      	movl	$0x1, 0x8(%rsp)
    215b:      	movq	(%rip), %rdi            # 0x2162 <generic_tracepoint_event+0x2162>
    2162:      	xorl	%ecx, %ecx
    2164:      	leaq	0x20(%rsp), %rsi
    2169:      	leaq	0x8(%rsp), %rdx
    216e:      	movl	$0x2, %eax
    2173:      	xorl	%ecx, %ecx
    2175:      	callq	*%rax
    2177:      	movq	0x10(%rsp), %r12
    217c:      	cmpl	$0x1c, %r13d
    2180:      	jne	0x2606 <generic_tracepoint_event+0x2606>
    2186:      	movl	$0x23, %eax
    218b:      	callq	*%rax
    218d:      	leaq	0x10(%rax), %rdx
    2191:      	leaq	0x20(%rsp), %rdi
    2196:      	movl	$0x4, %ecx
    219b:      	movl	$0x4, %eax
    21a0:      	movl	$0x4, %esi
    21a5:      	callq	*%rax
    21a7:      	movl	0x20(%rsp), %eax
    21ab:      	andl	$-0x2, %eax
    21ae:      	shll	$0x1e, %eax
    21b1:      	orq	%rax, %r12
    21b4:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    21b9:      	cmpl	$0x7, %r13d
    21bd:      	jne	0x2606 <generic_tracepoint_event+0x2606>
    21c3:      	leaq	0x10(%rsp), %rdi
    21c8:      	movl	$0x8, %ecx
    21cd:      	movl	$0x4, %eax
    21d2:      	movl	$0x8, %esi
    21d7:      	callq	*%rax
    21d9:      	testq	%rax, %rax
    21dc:      	je	0x25aa <generic_tracepoint_event+0x25aa>
    21e2:      	negl	%eax
    21e4:      	movw	%ax, 0x20(%rsp)
    21e9:      	movw	$0x7, 0x22(%rsp)
    21f0:      	movabsq	$0x40000009a, %rax      # imm = 0x40000009A
    21fa:      	movq	%rax, 0x24(%rsp)
    21ff:      	movq	(%rip), %rdi            # 0x2206 <generic_tracepoint_event+0x2206>
    2206:      	leaq	0x20(%rsp), %rsi
    220b:      	movl	$0x1, %eax
    2210:      	callq	*%rax
    2212:      	testq	%rax, %rax
    2215:      	jne	0x23fb <generic_tracepoint_event+0x23fb>
    221b:      	movl	$0x1, 0x8(%rsp)
    2223:      	movq	(%rip), %rdi            # 0x222a <generic_tracepoint_event+0x222a>
    222a:      	xorl	%ecx, %ecx
    222c:      	leaq	0x20(%rsp), %rsi
    2231:      	leaq	0x8(%rsp), %rdx
    2236:      	movl	$0x2, %eax
    223b:      	jmp	0x25a6 <generic_tracepoint_event+0x25a6>
    2240:      	movq	%rdx, %r12
    2243:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    2248:      	leaq	0x10(%rsp), %rdi
    224d:      	movl	$0x8, %ecx
    2252:      	movl	$0x4, %eax
    2257:      	movl	$0x8, %esi
    225c:      	callq	*%rax
    225e:      	testq	%rax, %rax
    2261:      	je	0x25aa <generic_tracepoint_event+0x25aa>
    2267:      	negl	%eax
    2269:      	movw	%ax, 0x20(%rsp)
    226e:      	movw	$0x7, 0x22(%rsp)
    2275:      	movabsq	$0x400000093, %rax      # imm = 0x400000093
    227f:      	movq	%rax, 0x24(%rsp)
    2284:      	movq	(%rip), %rdi            # 0x228b <generic_tracepoint_event+0x228b>
    228b:      	leaq	0x20(%rsp), %rsi
    2290:      	movl	$0x1, %eax
    2295:      	callq	*%rax
    2297:      	testq	%rax, %rax
    229a:      	jne	0x23fb <generic_tracepoint_event+0x23fb>
    22a0:      	movl	$0x1, 0x8(%rsp)
    22a8:      	movq	(%rip), %rdi            # 0x22af <generic_tracepoint_event+0x22af>
    22af:      	xorl	%ecx, %ecx
    22b1:      	leaq	0x20(%rsp), %rsi
    22b6:      	leaq	0x8(%rsp), %rdx
    22bb:      	movl	$0x2, %eax
    22c0:      	jmp	0x25a6 <generic_tracepoint_event+0x25a6>
    22c5:      	leaq	0x8(%rsp), %rdi
    22ca:      	movl	$0x1, %ecx
    22cf:      	movl	$0x4, %eax
    22d4:      	movl	$0x1, %esi
    22d9:      	callq	*%rax
    22db:      	testq	%rax, %rax
    22de:      	je	0x254c <generic_tracepoint_event+0x254c>
    22e4:      	negl	%eax
    22e6:      	movw	%ax, 0x20(%rsp)
    22eb:      	movw	$0x7, 0x22(%rsp)
    22f2:      	movabsq	$0x40000007a, %rax      # imm = 0x40000007A
    22fc:      	movq	%rax, 0x24(%rsp)
    2301:      	movq	(%rip), %rdi            # 0x2308 <generic_tracepoint_event+0x2308>
    2308:      	leaq	0x20(%rsp), %rsi
    230d:      	movl	$0x1, %eax
    2312:      	callq	*%rax
    2314:      	testq	%rax, %rax
    2317:      	je	0x2528 <generic_tracepoint_event+0x2528>
    231d:      	incl	(%rax)
    231f:      	movsbq	0x8(%rsp), %r12
    2325:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    232a:      	leaq	0x10(%rsp), %rdi
    232f:      	movl	$0x8, %ecx
    2334:      	movl	$0x4, %eax
    2339:      	movl	$0x8, %esi
    233e:      	callq	*%rax
    2340:      	testq	%rax, %rax
    2343:      	je	0x25aa <generic_tracepoint_event+0x25aa>
    2349:      	negl	%eax
    234b:      	movw	%ax, 0x20(%rsp)
    2350:      	movw	$0x7, 0x22(%rsp)
    2357:      	movabsq	$0x4000000a1, %rax      # imm = 0x4000000A1
    2361:      	movq	%rax, 0x24(%rsp)
    2366:      	movq	(%rip), %rdi            # 0x236d <generic_tracepoint_event+0x236d>
    236d:      	leaq	0x20(%rsp), %rsi
    2372:      	movl	$0x1, %eax
    2377:      	callq	*%rax
    2379:      	testq	%rax, %rax
    237c:      	jne	0x23fb <generic_tracepoint_event+0x23fb>
    237e:      	movl	$0x1, 0x8(%rsp)
    2386:      	movq	(%rip), %rdi            # 0x238d <generic_tracepoint_event+0x238d>
    238d:      	xorl	%ecx, %ecx
    238f:      	leaq	0x20(%rsp), %rsi
    2394:      	leaq	0x8(%rsp), %rdx
    2399:      	movl	$0x2, %eax
    239e:      	jmp	0x25a6 <generic_tracepoint_event+0x25a6>
    23a3:      	leaq	0x10(%rsp), %rdi
    23a8:      	movl	$0x8, %ecx
    23ad:      	movl	$0x4, %eax
    23b2:      	movl	$0x8, %esi
    23b7:      	callq	*%rax
    23b9:      	testq	%rax, %rax
    23bc:      	je	0x25aa <generic_tracepoint_event+0x25aa>
    23c2:      	negl	%eax
    23c4:      	movw	%ax, 0x20(%rsp)
    23c9:      	movw	$0x7, 0x22(%rsp)
    23d0:      	movabsq	$0x40000004e, %rax      # imm = 0x40000004E
    23da:      	movq	%rax, 0x24(%rsp)
    23df:      	movq	(%rip), %rdi            # 0x23e6 <generic_tracepoint_event+0x23e6>
    23e6:      	leaq	0x20(%rsp), %rsi
    23eb:      	movl	$0x1, %eax
    23f0:      	callq	*%rax
    23f2:      	testq	%rax, %rax
    23f5:      	je	0x2586 <generic_tracepoint_event+0x2586>
    23fb:      	incl	(%rax)
    23fd:      	jmp	0x25aa <generic_tracepoint_event+0x25aa>
    2402:      	leaq	0x8(%rsp), %rdi
    2407:      	movl	$0x2, %ecx
    240c:      	movl	$0x4, %eax
    2411:      	movl	$0x2, %esi
    2416:      	callq	*%rax
    2418:      	testq	%rax, %rax
    241b:      	je	0x25d5 <generic_tracepoint_event+0x25d5>
    2421:      	negl	%eax
    2423:      	movw	%ax, 0x20(%rsp)
    2428:      	movw	$0x7, 0x22(%rsp)
    242f:      	movabsq	$0x400000065, %rax      # imm = 0x400000065
    2439:      	movq	%rax, 0x24(%rsp)
    243e:      	movq	(%rip), %rdi            # 0x2445 <generic_tracepoint_event+0x2445>
    2445:      	leaq	0x20(%rsp), %rsi
    244a:      	movl	$0x1, %eax
    244f:      	callq	*%rax
    2451:      	testq	%rax, %rax
    2454:      	je	0x25b1 <generic_tracepoint_event+0x25b1>
    245a:      	incl	(%rax)
    245c:      	movzwl	0x8(%rsp), %r12d
    2462:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    2467:      	leaq	0x8(%rsp), %rdi
    246c:      	movl	$0x4, %ecx
    2471:      	movl	$0x4, %eax
    2476:      	movl	$0x4, %esi
    247b:      	callq	*%rax
    247d:      	testq	%rax, %rax
    2480:      	je	0x2601 <generic_tracepoint_event+0x2601>
    2486:      	negl	%eax
    2488:      	movw	%ax, 0x20(%rsp)
    248d:      	movw	$0x7, 0x22(%rsp)
    2494:      	movabsq	$0x400000088, %rax      # imm = 0x400000088
    249e:      	movq	%rax, 0x24(%rsp)
    24a3:      	movq	(%rip), %rdi            # 0x24aa <generic_tracepoint_event+0x24aa>
    24aa:      	leaq	0x20(%rsp), %rsi
    24af:      	movl	$0x1, %eax
    24b4:      	callq	*%rax
    24b6:      	testq	%rax, %rax
    24b9:      	je	0x25dd <generic_tracepoint_event+0x25dd>
    24bf:      	incl	(%rax)
    24c1:      	movl	0x8(%rsp), %r12d
    24c6:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    24cb:      	movl	$0x1, 0x10(%rsp)
    24d3:      	movq	(%rip), %rdi            # 0x24da <generic_tracepoint_event+0x24da>
    24da:      	xorl	%ecx, %ecx
    24dc:      	leaq	0x20(%rsp), %rsi
    24e1:      	leaq	0x10(%rsp), %rdx
    24e6:      	movl	$0x2, %eax
    24eb:      	xorl	%ecx, %ecx
    24ed:      	callq	*%rax
    24ef:      	movslq	0x8(%rsp), %r12
    24f4:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    24f9:      	movl	$0x1, 0x10(%rsp)
    2501:      	movq	(%rip), %rdi            # 0x2508 <generic_tracepoint_event+0x2508>
    2508:      	xorl	%ecx, %ecx
    250a:      	leaq	0x20(%rsp), %rsi
    250f:      	leaq	0x10(%rsp), %rdx
    2514:      	movl	$0x2, %eax
    2519:      	xorl	%ecx, %ecx
    251b:      	callq	*%rax
    251d:      	movswq	0x8(%rsp), %r12
    2523:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    2528:      	movl	$0x1, 0x10(%rsp)
    2530:      	movq	(%rip), %rdi            # 0x2537 <generic_tracepoint_event+0x2537>
    2537:      	xorl	%ecx, %ecx
    2539:      	leaq	0x20(%rsp), %rsi
    253e:      	leaq	0x10(%rsp), %rdx
    2543:      	movl	$0x2, %eax
    2548:      	xorl	%ecx, %ecx
    254a:      	callq	*%rax
    254c:      	movsbq	0x8(%rsp), %r12
    2552:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    2557:      	movl	$0x1, 0x10(%rsp)
    255f:      	movq	(%rip), %rdi            # 0x2566 <generic_tracepoint_event+0x2566>
    2566:      	xorl	%ecx, %ecx
    2568:      	leaq	0x20(%rsp), %rsi
    256d:      	leaq	0x10(%rsp), %rdx
    2572:      	movl	$0x2, %eax
    2577:      	xorl	%ecx, %ecx
    2579:      	callq	*%rax
    257b:      	movzbl	0x8(%rsp), %r12d
    2581:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    2586:      	movl	$0x1, 0x8(%rsp)
    258e:      	movq	(%rip), %rdi            # 0x2595 <generic_tracepoint_event+0x2595>
    2595:      	xorl	%ecx, %ecx
    2597:      	leaq	0x20(%rsp), %rsi
    259c:      	leaq	0x8(%rsp), %rdx
    25a1:      	movl	$0x2, %eax
    25a6:      	xorl	%ecx, %ecx
    25a8:      	callq	*%rax
    25aa:      	movq	0x10(%rsp), %r12
    25af:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    25b1:      	movl	$0x1, 0x10(%rsp)
    25b9:      	movq	(%rip), %rdi            # 0x25c0 <generic_tracepoint_event+0x25c0>
    25c0:      	xorl	%ecx, %ecx
    25c2:      	leaq	0x20(%rsp), %rsi
    25c7:      	leaq	0x10(%rsp), %rdx
    25cc:      	movl	$0x2, %eax
    25d1:      	xorl	%ecx, %ecx
    25d3:      	callq	*%rax
    25d5:      	movzwl	0x8(%rsp), %r12d
    25db:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    25dd:      	movl	$0x1, 0x10(%rsp)
    25e5:      	movq	(%rip), %rdi            # 0x25ec <generic_tracepoint_event+0x25ec>
    25ec:      	xorl	%ecx, %ecx
    25ee:      	leaq	0x20(%rsp), %rsi
    25f3:      	leaq	0x10(%rsp), %rdx
    25f8:      	movl	$0x2, %eax
    25fd:      	xorl	%ecx, %ecx
    25ff:      	callq	*%rax
    2601:      	movl	0x8(%rsp), %r12d
    2606:      	movq	%r12, 0x5e68(%r14)
    260d:      	movzwl	0x3c(%r15), %edx
    2612:      	movl	0x14(%r15), %r12d
    2616:      	addq	%rbx, %rdx
    2619:      	xorl	%r15d, %r15d
    261c:      	cmpl	$0xb, %r12d
    2620:      	jg	0x2659 <generic_tracepoint_event+0x2659>
    2622:      	cmpl	$0x3, %r12d
    2626:      	jle	0x26f0 <generic_tracepoint_event+0x26f0>
    262c:      	cmpl	$0x6, %r12d
    2630:      	jg	0x2818 <generic_tracepoint_event+0x2818>
    2636:      	cmpl	$0x4, %r12d
    263a:      	je	0x2c7a <generic_tracepoint_event+0x2c7a>
    2640:      	cmpl	$0x5, %r12d
    2644:      	je	0x2b1f <generic_tracepoint_event+0x2b1f>
    264a:      	cmpl	$0x6, %r12d
    264e:      	je	0x2712 <generic_tracepoint_event+0x2712>
    2654:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2659:      	cmpl	$0x1d, %r12d
    265d:      	jle	0x278f <generic_tracepoint_event+0x278f>
    2663:      	cmpl	$0x25, %r12d
    2667:      	jg	0x2885 <generic_tracepoint_event+0x2885>
    266d:      	cmpl	$0x1e, %r12d
    2671:      	je	0x2cd9 <generic_tracepoint_event+0x2cd9>
    2677:      	cmpl	$0x1f, %r12d
    267b:      	je	0x2b9c <generic_tracepoint_event+0x2b9c>
    2681:      	cmpl	$0x20, %r12d
    2685:      	jne	0x2edd <generic_tracepoint_event+0x2edd>
    268b:      	leaq	0x8(%rsp), %rdi
    2690:      	movl	$0x1, %ecx
    2695:      	movl	$0x4, %eax
    269a:      	movl	$0x1, %esi
    269f:      	callq	*%rax
    26a1:      	testq	%rax, %rax
    26a4:      	je	0x2e52 <generic_tracepoint_event+0x2e52>
    26aa:      	negl	%eax
    26ac:      	movw	%ax, 0x20(%rsp)
    26b1:      	movw	$0x7, 0x22(%rsp)
    26b8:      	movabsq	$0x400000073, %rax      # imm = 0x400000073
    26c2:      	movq	%rax, 0x24(%rsp)
    26c7:      	movq	(%rip), %rdi            # 0x26ce <generic_tracepoint_event+0x26ce>
    26ce:      	leaq	0x20(%rsp), %rsi
    26d3:      	movl	$0x1, %eax
    26d8:      	callq	*%rax
    26da:      	testq	%rax, %rax
    26dd:      	je	0x2e2e <generic_tracepoint_event+0x2e2e>
    26e3:      	incl	(%rax)
    26e5:      	movzbl	0x8(%rsp), %r15d
    26eb:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    26f0:      	cmpl	$-0xc, %r12d
    26f4:      	jle	0x2920 <generic_tracepoint_event+0x2920>
    26fa:      	leal	0xb(%r12), %eax
    26ff:      	cmpl	$0x2, %eax
    2702:      	jb	0x2826 <generic_tracepoint_event+0x2826>
    2708:      	cmpl	$0x2, %r12d
    270c:      	jne	0x2edd <generic_tracepoint_event+0x2edd>
    2712:      	leaq	0x10(%rsp), %rdi
    2717:      	movl	$0x8, %ecx
    271c:      	movl	$0x4, %eax
    2721:      	movl	$0x8, %esi
    2726:      	callq	*%rax
    2728:      	testq	%rax, %rax
    272b:      	je	0x2e81 <generic_tracepoint_event+0x2e81>
    2731:      	negl	%eax
    2733:      	movw	%ax, 0x20(%rsp)
    2738:      	movw	$0x7, 0x22(%rsp)
    273f:      	movabsq	$0x400000081, %rax      # imm = 0x400000081
    2749:      	movq	%rax, 0x24(%rsp)
    274e:      	movq	(%rip), %rdi            # 0x2755 <generic_tracepoint_event+0x2755>
    2755:      	leaq	0x20(%rsp), %rsi
    275a:      	movl	$0x1, %eax
    275f:      	callq	*%rax
    2761:      	testq	%rax, %rax
    2764:      	jne	0x2cd2 <generic_tracepoint_event+0x2cd2>
    276a:      	movl	$0x1, 0x8(%rsp)
    2772:      	movq	(%rip), %rdi            # 0x2779 <generic_tracepoint_event+0x2779>
    2779:      	xorl	%ecx, %ecx
    277b:      	leaq	0x20(%rsp), %rsi
    2780:      	leaq	0x8(%rsp), %rdx
    2785:      	movl	$0x2, %eax
    278a:      	jmp	0x2e7d <generic_tracepoint_event+0x2e7d>
    278f:      	cmpl	$0x11, %r12d
    2793:      	jle	0x2935 <generic_tracepoint_event+0x2935>
    2799:      	cmpl	$0x12, %r12d
    279d:      	je	0x2b17 <generic_tracepoint_event+0x2b17>
    27a3:      	cmpl	$0x1c, %r12d
    27a7:      	je	0x2826 <generic_tracepoint_event+0x2826>
    27a9:      	cmpl	$0x1d, %r12d
    27ad:      	jne	0x2edd <generic_tracepoint_event+0x2edd>
    27b3:      	leaq	0x8(%rsp), %rdi
    27b8:      	movl	$0x2, %ecx
    27bd:      	movl	$0x4, %eax
    27c2:      	movl	$0x2, %esi
    27c7:      	callq	*%rax
    27c9:      	testq	%rax, %rax
    27cc:      	je	0x2df4 <generic_tracepoint_event+0x2df4>
    27d2:      	negl	%eax
    27d4:      	movw	%ax, 0x20(%rsp)
    27d9:      	movw	$0x7, 0x22(%rsp)
    27e0:      	movabsq	$0x40000006c, %rax      # imm = 0x40000006C
    27ea:      	movq	%rax, 0x24(%rsp)
    27ef:      	movq	(%rip), %rdi            # 0x27f6 <generic_tracepoint_event+0x27f6>
    27f6:      	leaq	0x20(%rsp), %rsi
    27fb:      	movl	$0x1, %eax
    2800:      	callq	*%rax
    2802:      	testq	%rax, %rax
    2805:      	je	0x2dd0 <generic_tracepoint_event+0x2dd0>
    280b:      	incl	(%rax)
    280d:      	movswq	0x8(%rsp), %r15
    2813:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2818:      	leal	-0xa(%r12), %eax
    281d:      	cmpl	$0x2, %eax
    2820:      	jae	0x2a90 <generic_tracepoint_event+0x2a90>
    2826:      	leaq	0x10(%rsp), %rdi
    282b:      	movl	$0x8, %ecx
    2830:      	movl	$0x4, %eax
    2835:      	movl	$0x8, %esi
    283a:      	callq	*%rax
    283c:      	testq	%rax, %rax
    283f:      	je	0x2a4e <generic_tracepoint_event+0x2a4e>
    2845:      	negl	%eax
    2847:      	movw	%ax, 0x20(%rsp)
    284c:      	movw	$0x7, 0x22(%rsp)
    2853:      	movabsq	$0x400000045, %rax      # imm = 0x400000045
    285d:      	movq	%rax, 0x24(%rsp)
    2862:      	movq	(%rip), %rdi            # 0x2869 <generic_tracepoint_event+0x2869>
    2869:      	leaq	0x20(%rsp), %rsi
    286e:      	movl	$0x1, %eax
    2873:      	callq	*%rax
    2875:      	testq	%rax, %rax
    2878:      	je	0x2a2a <generic_tracepoint_event+0x2a2a>
    287e:      	incl	(%rax)
    2880:      	jmp	0x2a4e <generic_tracepoint_event+0x2a4e>
    2885:      	cmpl	$0x26, %r12d
    2889:      	je	0x2d3e <generic_tracepoint_event+0x2d3e>
    288f:      	cmpl	$0x28, %r12d
    2893:      	je	0x2c01 <generic_tracepoint_event+0x2c01>
    2899:      	cmpl	$0x29, %r12d
    289d:      	jne	0x2edd <generic_tracepoint_event+0x2edd>
    28a3:      	leaq	0x10(%rsp), %rdi
    28a8:      	movl	$0x8, %ecx
    28ad:      	movl	$0x4, %eax
    28b2:      	movl	$0x8, %esi
    28b7:      	callq	*%rax
    28b9:      	testq	%rax, %rax
    28bc:      	je	0x2e81 <generic_tracepoint_event+0x2e81>
    28c2:      	negl	%eax
    28c4:      	movw	%ax, 0x20(%rsp)
    28c9:      	movw	$0x7, 0x22(%rsp)
    28d0:      	movabsq	$0x4000000a8, %rax      # imm = 0x4000000A8
    28da:      	movq	%rax, 0x24(%rsp)
    28df:      	movq	(%rip), %rdi            # 0x28e6 <generic_tracepoint_event+0x28e6>
    28e6:      	leaq	0x20(%rsp), %rsi
    28eb:      	movl	$0x1, %eax
    28f0:      	callq	*%rax
    28f2:      	testq	%rax, %rax
    28f5:      	jne	0x2cd2 <generic_tracepoint_event+0x2cd2>
    28fb:      	movl	$0x1, 0x8(%rsp)
    2903:      	movq	(%rip), %rdi            # 0x290a <generic_tracepoint_event+0x290a>
    290a:      	xorl	%ecx, %ecx
    290c:      	leaq	0x20(%rsp), %rsi
    2911:      	leaq	0x8(%rsp), %rdx
    2916:      	movl	$0x2, %eax
    291b:      	jmp	0x2e7d <generic_tracepoint_event+0x2e7d>
    2920:      	cmpl	$-0xd, %r12d
    2924:      	je	0x29c6 <generic_tracepoint_event+0x29c6>
    292a:      	cmpl	$-0xc, %r12d
    292e:      	je	0x2949 <generic_tracepoint_event+0x2949>
    2930:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2935:      	cmpl	$0xc, %r12d
    2939:      	je	0x29c6 <generic_tracepoint_event+0x29c6>
    293f:      	cmpl	$0xd, %r12d
    2943:      	jne	0x2edd <generic_tracepoint_event+0x2edd>
    2949:      	leaq	0x8(%rsp), %rdi
    294e:      	movl	$0x4, %ecx
    2953:      	movl	$0x4, %eax
    2958:      	movl	$0x4, %esi
    295d:      	callq	*%rax
    295f:      	testq	%rax, %rax
    2962:      	je	0x2ed8 <generic_tracepoint_event+0x2ed8>
    2968:      	negl	%eax
    296a:      	movw	%ax, 0x20(%rsp)
    296f:      	movw	$0x7, 0x22(%rsp)
    2976:      	movabsq	$0x40000005e, %rax      # imm = 0x40000005E
    2980:      	movq	%rax, 0x24(%rsp)
    2985:      	movq	(%rip), %rdi            # 0x298c <generic_tracepoint_event+0x298c>
    298c:      	leaq	0x20(%rsp), %rsi
    2991:      	movl	$0x1, %eax
    2996:      	callq	*%rax
    2998:      	testq	%rax, %rax
    299b:      	jne	0x2d96 <generic_tracepoint_event+0x2d96>
    29a1:      	movl	$0x1, 0x10(%rsp)
    29a9:      	movq	(%rip), %rdi            # 0x29b0 <generic_tracepoint_event+0x29b0>
    29b0:      	xorl	%ecx, %ecx
    29b2:      	leaq	0x20(%rsp), %rsi
    29b7:      	leaq	0x10(%rsp), %rdx
    29bc:      	movl	$0x2, %eax
    29c1:      	jmp	0x2ed4 <generic_tracepoint_event+0x2ed4>
    29c6:      	leaq	0x8(%rsp), %rdi
    29cb:      	movl	$0x4, %ecx
    29d0:      	movl	$0x4, %eax
    29d5:      	movl	$0x4, %esi
    29da:      	callq	*%rax
    29dc:      	testq	%rax, %rax
    29df:      	je	0x2dc6 <generic_tracepoint_event+0x2dc6>
    29e5:      	negl	%eax
    29e7:      	movw	%ax, 0x20(%rsp)
    29ec:      	movw	$0x7, 0x22(%rsp)
    29f3:      	movabsq	$0x400000056, %rax      # imm = 0x400000056
    29fd:      	movq	%rax, 0x24(%rsp)
    2a02:      	movq	(%rip), %rdi            # 0x2a09 <generic_tracepoint_event+0x2a09>
    2a09:      	leaq	0x20(%rsp), %rsi
    2a0e:      	movl	$0x1, %eax
    2a13:      	callq	*%rax
    2a15:      	testq	%rax, %rax
    2a18:      	je	0x2da2 <generic_tracepoint_event+0x2da2>
    2a1e:      	incl	(%rax)
    2a20:      	movslq	0x8(%rsp), %r15
    2a25:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2a2a:      	movl	$0x1, 0x8(%rsp)
    2a32:      	movq	(%rip), %rdi            # 0x2a39 <generic_tracepoint_event+0x2a39>
    2a39:      	xorl	%ecx, %ecx
    2a3b:      	leaq	0x20(%rsp), %rsi
    2a40:      	leaq	0x8(%rsp), %rdx
    2a45:      	movl	$0x2, %eax
    2a4a:      	xorl	%ecx, %ecx
    2a4c:      	callq	*%rax
    2a4e:      	movq	0x10(%rsp), %r15
    2a53:      	cmpl	$0x1c, %r12d
    2a57:      	jne	0x2edd <generic_tracepoint_event+0x2edd>
    2a5d:      	movl	$0x23, %eax
    2a62:      	callq	*%rax
    2a64:      	leaq	0x10(%rax), %rdx
    2a68:      	leaq	0x20(%rsp), %rdi
    2a6d:      	movl	$0x4, %ecx
    2a72:      	movl	$0x4, %eax
    2a77:      	movl	$0x4, %esi
    2a7c:      	callq	*%rax
    2a7e:      	movl	0x20(%rsp), %eax
    2a82:      	andl	$-0x2, %eax
    2a85:      	shll	$0x1e, %eax
    2a88:      	orq	%rax, %r15
    2a8b:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2a90:      	cmpl	$0x7, %r12d
    2a94:      	jne	0x2edd <generic_tracepoint_event+0x2edd>
    2a9a:      	leaq	0x10(%rsp), %rdi
    2a9f:      	movl	$0x8, %ecx
    2aa4:      	movl	$0x4, %eax
    2aa9:      	movl	$0x8, %esi
    2aae:      	callq	*%rax
    2ab0:      	testq	%rax, %rax
    2ab3:      	je	0x2e81 <generic_tracepoint_event+0x2e81>
    2ab9:      	negl	%eax
    2abb:      	movw	%ax, 0x20(%rsp)
    2ac0:      	movw	$0x7, 0x22(%rsp)
    2ac7:      	movabsq	$0x40000009a, %rax      # imm = 0x40000009A
    2ad1:      	movq	%rax, 0x24(%rsp)
    2ad6:      	movq	(%rip), %rdi            # 0x2add <generic_tracepoint_event+0x2add>
    2add:      	leaq	0x20(%rsp), %rsi
    2ae2:      	movl	$0x1, %eax
    2ae7:      	callq	*%rax
    2ae9:      	testq	%rax, %rax
    2aec:      	jne	0x2cd2 <generic_tracepoint_event+0x2cd2>
    2af2:      	movl	$0x1, 0x8(%rsp)
    2afa:      	movq	(%rip), %rdi            # 0x2b01 <generic_tracepoint_event+0x2b01>
    2b01:      	xorl	%ecx, %ecx
    2b03:      	leaq	0x20(%rsp), %rsi
    2b08:      	leaq	0x8(%rsp), %rdx
    2b0d:      	movl	$0x2, %eax
    2b12:      	jmp	0x2e7d <generic_tracepoint_event+0x2e7d>
    2b17:      	movq	%rdx, %r15
    2b1a:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2b1f:      	leaq	0x10(%rsp), %rdi
    2b24:      	movl	$0x8, %ecx
    2b29:      	movl	$0x4, %eax
    2b2e:      	movl	$0x8, %esi
    2b33:      	callq	*%rax
    2b35:      	testq	%rax, %rax
    2b38:      	je	0x2e81 <generic_tracepoint_event+0x2e81>
    2b3e:      	negl	%eax
    2b40:      	movw	%ax, 0x20(%rsp)
    2b45:      	movw	$0x7, 0x22(%rsp)
    2b4c:      	movabsq	$0x400000093, %rax      # imm = 0x400000093
    2b56:      	movq	%rax, 0x24(%rsp)
    2b5b:      	movq	(%rip), %rdi            # 0x2b62 <generic_tracepoint_event+0x2b62>
    2b62:      	leaq	0x20(%rsp), %rsi
    2b67:      	movl	$0x1, %eax
    2b6c:      	callq	*%rax
    2b6e:      	testq	%rax, %rax
    2b71:      	jne	0x2cd2 <generic_tracepoint_event+0x2cd2>
    2b77:      	movl	$0x1, 0x8(%rsp)
    2b7f:      	movq	(%rip), %rdi            # 0x2b86 <generic_tracepoint_event+0x2b86>
    2b86:      	xorl	%ecx, %ecx
    2b88:      	leaq	0x20(%rsp), %rsi
    2b8d:      	leaq	0x8(%rsp), %rdx
    2b92:      	movl	$0x2, %eax
    2b97:      	jmp	0x2e7d <generic_tracepoint_event+0x2e7d>
    2b9c:      	leaq	0x8(%rsp), %rdi
    2ba1:      	movl	$0x1, %ecx
    2ba6:      	movl	$0x4, %eax
    2bab:      	movl	$0x1, %esi
    2bb0:      	callq	*%rax
    2bb2:      	testq	%rax, %rax
    2bb5:      	je	0x2e23 <generic_tracepoint_event+0x2e23>
    2bbb:      	negl	%eax
    2bbd:      	movw	%ax, 0x20(%rsp)
    2bc2:      	movw	$0x7, 0x22(%rsp)
    2bc9:      	movabsq	$0x40000007a, %rax      # imm = 0x40000007A
    2bd3:      	movq	%rax, 0x24(%rsp)
    2bd8:      	movq	(%rip), %rdi            # 0x2bdf <generic_tracepoint_event+0x2bdf>
    2bdf:      	leaq	0x20(%rsp), %rsi
    2be4:      	movl	$0x1, %eax
    2be9:      	callq	*%rax
    2beb:      	testq	%rax, %rax
    2bee:      	je	0x2dff <generic_tracepoint_event+0x2dff>
    2bf4:      	incl	(%rax)
    2bf6:      	movsbq	0x8(%rsp), %r15
    2bfc:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2c01:      	leaq	0x10(%rsp), %rdi
    2c06:      	movl	$0x8, %ecx
    2c0b:      	movl	$0x4, %eax
    2c10:      	movl	$0x8, %esi
    2c15:      	callq	*%rax
    2c17:      	testq	%rax, %rax
    2c1a:      	je	0x2e81 <generic_tracepoint_event+0x2e81>
    2c20:      	negl	%eax
    2c22:      	movw	%ax, 0x20(%rsp)
    2c27:      	movw	$0x7, 0x22(%rsp)
    2c2e:      	movabsq	$0x4000000a1, %rax      # imm = 0x4000000A1
    2c38:      	movq	%rax, 0x24(%rsp)
    2c3d:      	movq	(%rip), %rdi            # 0x2c44 <generic_tracepoint_event+0x2c44>
    2c44:      	leaq	0x20(%rsp), %rsi
    2c49:      	movl	$0x1, %eax
    2c4e:      	callq	*%rax
    2c50:      	testq	%rax, %rax
    2c53:      	jne	0x2cd2 <generic_tracepoint_event+0x2cd2>
    2c55:      	movl	$0x1, 0x8(%rsp)
    2c5d:      	movq	(%rip), %rdi            # 0x2c64 <generic_tracepoint_event+0x2c64>
    2c64:      	xorl	%ecx, %ecx
    2c66:      	leaq	0x20(%rsp), %rsi
    2c6b:      	leaq	0x8(%rsp), %rdx
    2c70:      	movl	$0x2, %eax
    2c75:      	jmp	0x2e7d <generic_tracepoint_event+0x2e7d>
    2c7a:      	leaq	0x10(%rsp), %rdi
    2c7f:      	movl	$0x8, %ecx
    2c84:      	movl	$0x4, %eax
    2c89:      	movl	$0x8, %esi
    2c8e:      	callq	*%rax
    2c90:      	testq	%rax, %rax
    2c93:      	je	0x2e81 <generic_tracepoint_event+0x2e81>
    2c99:      	negl	%eax
    2c9b:      	movw	%ax, 0x20(%rsp)
    2ca0:      	movw	$0x7, 0x22(%rsp)
    2ca7:      	movabsq	$0x40000004e, %rax      # imm = 0x40000004E
    2cb1:      	movq	%rax, 0x24(%rsp)
    2cb6:      	movq	(%rip), %rdi            # 0x2cbd <generic_tracepoint_event+0x2cbd>
    2cbd:      	leaq	0x20(%rsp), %rsi
    2cc2:      	movl	$0x1, %eax
    2cc7:      	callq	*%rax
    2cc9:      	testq	%rax, %rax
    2ccc:      	je	0x2e5d <generic_tracepoint_event+0x2e5d>
    2cd2:      	incl	(%rax)
    2cd4:      	jmp	0x2e81 <generic_tracepoint_event+0x2e81>
    2cd9:      	leaq	0x8(%rsp), %rdi
    2cde:      	movl	$0x2, %ecx
    2ce3:      	movl	$0x4, %eax
    2ce8:      	movl	$0x2, %esi
    2ced:      	callq	*%rax
    2cef:      	testq	%rax, %rax
    2cf2:      	je	0x2eac <generic_tracepoint_event+0x2eac>
    2cf8:      	negl	%eax
    2cfa:      	movw	%ax, 0x20(%rsp)
    2cff:      	movw	$0x7, 0x22(%rsp)
    2d06:      	movabsq	$0x400000065, %rax      # imm = 0x400000065
    2d10:      	movq	%rax, 0x24(%rsp)
    2d15:      	movq	(%rip), %rdi            # 0x2d1c <generic_tracepoint_event+0x2d1c>
    2d1c:      	leaq	0x20(%rsp), %rsi
    2d21:      	movl	$0x1, %eax
    2d26:      	callq	*%rax
    2d28:      	testq	%rax, %rax
    2d2b:      	je	0x2e88 <generic_tracepoint_event+0x2e88>
    2d31:      	incl	(%rax)
    2d33:      	movzwl	0x8(%rsp), %r15d
    2d39:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2d3e:      	leaq	0x8(%rsp), %rdi
    2d43:      	movl	$0x4, %ecx
    2d48:      	movl	$0x4, %eax
    2d4d:      	movl	$0x4, %esi
    2d52:      	callq	*%rax
    2d54:      	testq	%rax, %rax
    2d57:      	je	0x2ed8 <generic_tracepoint_event+0x2ed8>
    2d5d:      	negl	%eax
    2d5f:      	movw	%ax, 0x20(%rsp)
    2d64:      	movw	$0x7, 0x22(%rsp)
    2d6b:      	movabsq	$0x400000088, %rax      # imm = 0x400000088
    2d75:      	movq	%rax, 0x24(%rsp)
    2d7a:      	movq	(%rip), %rdi            # 0x2d81 <generic_tracepoint_event+0x2d81>
    2d81:      	leaq	0x20(%rsp), %rsi
    2d86:      	movl	$0x1, %eax
    2d8b:      	callq	*%rax
    2d8d:      	testq	%rax, %rax
    2d90:      	je	0x2eb4 <generic_tracepoint_event+0x2eb4>
    2d96:      	incl	(%rax)
    2d98:      	movl	0x8(%rsp), %r15d
    2d9d:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2da2:      	movl	$0x1, 0x10(%rsp)
    2daa:      	movq	(%rip), %rdi            # 0x2db1 <generic_tracepoint_event+0x2db1>
    2db1:      	xorl	%ecx, %ecx
    2db3:      	leaq	0x20(%rsp), %rsi
    2db8:      	leaq	0x10(%rsp), %rdx
    2dbd:      	movl	$0x2, %eax
    2dc2:      	xorl	%ecx, %ecx
    2dc4:      	callq	*%rax
    2dc6:      	movslq	0x8(%rsp), %r15
    2dcb:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2dd0:      	movl	$0x1, 0x10(%rsp)
    2dd8:      	movq	(%rip), %rdi            # 0x2ddf <generic_tracepoint_event+0x2ddf>
    2ddf:      	xorl	%ecx, %ecx
    2de1:      	leaq	0x20(%rsp), %rsi
    2de6:      	leaq	0x10(%rsp), %rdx
    2deb:      	movl	$0x2, %eax
    2df0:      	xorl	%ecx, %ecx
    2df2:      	callq	*%rax
    2df4:      	movswq	0x8(%rsp), %r15
    2dfa:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2dff:      	movl	$0x1, 0x10(%rsp)
    2e07:      	movq	(%rip), %rdi            # 0x2e0e <generic_tracepoint_event+0x2e0e>
    2e0e:      	xorl	%ecx, %ecx
    2e10:      	leaq	0x20(%rsp), %rsi
    2e15:      	leaq	0x10(%rsp), %rdx
    2e1a:      	movl	$0x2, %eax
    2e1f:      	xorl	%ecx, %ecx
    2e21:      	callq	*%rax
    2e23:      	movsbq	0x8(%rsp), %r15
    2e29:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2e2e:      	movl	$0x1, 0x10(%rsp)
    2e36:      	movq	(%rip), %rdi            # 0x2e3d <generic_tracepoint_event+0x2e3d>
    2e3d:      	xorl	%ecx, %ecx
    2e3f:      	leaq	0x20(%rsp), %rsi
    2e44:      	leaq	0x10(%rsp), %rdx
    2e49:      	movl	$0x2, %eax
    2e4e:      	xorl	%ecx, %ecx
    2e50:      	callq	*%rax
    2e52:      	movzbl	0x8(%rsp), %r15d
    2e58:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2e5d:      	movl	$0x1, 0x8(%rsp)
    2e65:      	movq	(%rip), %rdi            # 0x2e6c <generic_tracepoint_event+0x2e6c>
    2e6c:      	xorl	%ecx, %ecx
    2e6e:      	leaq	0x20(%rsp), %rsi
    2e73:      	leaq	0x8(%rsp), %rdx
    2e78:      	movl	$0x2, %eax
    2e7d:      	xorl	%ecx, %ecx
    2e7f:      	callq	*%rax
    2e81:      	movq	0x10(%rsp), %r15
    2e86:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2e88:      	movl	$0x1, 0x10(%rsp)
    2e90:      	movq	(%rip), %rdi            # 0x2e97 <generic_tracepoint_event+0x2e97>
    2e97:      	xorl	%ecx, %ecx
    2e99:      	leaq	0x20(%rsp), %rsi
    2e9e:      	leaq	0x10(%rsp), %rdx
    2ea3:      	movl	$0x2, %eax
    2ea8:      	xorl	%ecx, %ecx
    2eaa:      	callq	*%rax
    2eac:      	movzwl	0x8(%rsp), %r15d
    2eb2:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2eb4:      	movl	$0x1, 0x10(%rsp)
    2ebc:      	movq	(%rip), %rdi            # 0x2ec3 <generic_tracepoint_event+0x2ec3>
    2ec3:      	xorl	%ecx, %ecx
    2ec5:      	leaq	0x20(%rsp), %rsi
    2eca:      	leaq	0x10(%rsp), %rdx
    2ecf:      	movl	$0x2, %eax
    2ed4:      	xorl	%ecx, %ecx
    2ed6:      	callq	*%rax
    2ed8:      	movl	0x8(%rsp), %r15d
    2edd:      	movq	%r15, 0x5e70(%r14)
    2ee4:      	movb	$0xe, (%r14)
    2ee8:      	movw	$0x0, 0x2(%r14)
    2eef:      	movl	$0x0, 0x4(%r14)
    2ef7:      	movl	$0x7d, %eax
    2efc:      	callq	*%rax
    2efe:      	movq	%rax, 0x8(%r14)
    2f02:      	movq	$0x0, 0x70(%r14)
    2f0a:      	movl	$0x0, 0x14(%r14)
    2f12:      	movl	$0xe, %eax
    2f17:      	callq	*%rax
    2f19:      	movl	%eax, 0x7c(%r14)
    2f1d:      	movb	$0xe, (%r14)
    2f21:      	movq	$0x0, 0x5efc(%r14)
    2f2c:      	movq	$0x0, 0x5eb8(%r14)
    2f37:      	movq	$0x0, 0x5ec0(%r14)
    2f42:      	movq	$0x0, 0x5ec8(%r14)
    2f4d:      	movq	$0x0, 0x5ed0(%r14)
    2f58:      	movq	$0x0, 0x5ed8(%r14)
    2f63:      	movb	$0x0, 0x5ee0(%r14)
    2f6b:      	movl	$0x23, %eax
    2f70:      	callq	*%rax
    2f72:      	movq	%rax, %r15
    2f75:      	leaq	0xd70(%rax), %rdx
    2f7c:      	leaq	0x8(%rsp), %rdi
    2f81:      	movl	$0x8, %ecx
    2f86:      	movl	$0x4, %eax
    2f8b:      	leaq	0x20(%r14), %r12
    2f8f:      	movl	$0x4, %r13d
    2f95:      	movl	$0x8, %esi
    2f9a:      	callq	*%rax
    2f9c:      	movq	0x8(%rsp), %rcx
    2fa1:      	leaq	0x20(%rsp), %rdi
    2fa6:      	movl	$0x48, %edx
    2fab:      	movl	$0x4, %eax
    2fb0:      	movq	0x8(%rsp), %rdx
    2fb5:      	movl	$0x48, %esi
    2fba:      	callq	*%rax
    2fbc:      	movl	$0x218, %edx            # imm = 0x218
    2fc1:      	movq	0x28(%rsp), %rcx
    2fc6:      	addq	%rdx, %rcx
    2fc9:      	movl	$0x4, %esi
    2fce:      	movl	$0x4, %eax
    2fd3:      	addq	0x28(%rsp), %rdx
    2fd8:      	movq	%r12, %rdi
    2fdb:      	movl	$0x4, %esi
    2fe0:      	callq	*%rax
    2fe2:      	leaq	0x24(%r14), %rdi
    2fe6:      	movl	$0x4d8, %edx            # imm = 0x4D8
    2feb:      	movq	0x30(%rsp), %rcx
    2ff0:      	addq	%rdx, %rcx
    2ff3:      	movl	$0x4, %esi
    2ff8:      	movl	$0x4, %eax
    2ffd:      	addq	0x30(%rsp), %rdx
    3002:      	movl	$0x4, %esi
    3007:      	callq	*%rax
    3009:      	leaq	0x28(%r14), %rdi
    300d:      	movq	0x38(%rsp), %rcx
    3012:      	addq	$0x58, %rcx
    3016:      	movl	$0x4, %edx
    301b:      	movl	$0x4, %eax
    3020:      	movq	0x38(%rsp), %rdx
    3025:      	addq	$0x58, %rdx
    3029:      	movl	$0x4, %esi
    302e:      	callq	*%rax
    3030:      	movq	$0x0, 0x68(%rsp)
    3039:      	leaq	0xb58(%r15), %rdx
    3040:      	leaq	0x68(%rsp), %rdi
    3045:      	movl	$0x8, %ecx
    304a:      	movl	$0x4, %eax
    304f:      	movl	$0x8, %esi
    3054:      	callq	*%rax
    3056:      	movq	0x68(%rsp), %rcx
    305b:      	testq	%rcx, %rcx
    305e:      	je	0x30f4 <generic_tracepoint_event+0x30f4>
    3064:      	movl	$0x0, 0x70(%rsp)
    306c:      	addq	$0x4, %rcx
    3070:      	leaq	0x70(%rsp), %rdi
    3075:      	movl	$0x4, %eax
    307a:      	movq	0x68(%rsp), %rdx
    307f:      	addq	$0x4, %rdx
    3083:      	movl	$0x4, %esi
    3088:      	callq	*%rax
    308a:      	movq	0x68(%rsp), %rax
    308f:      	movslq	0x70(%rsp), %rcx
    3094:      	shlq	$0x4, %rcx
    3098:      	addq	%rax, %rcx
    309b:      	addq	$0x80, %rcx
    30a2:      	leaq	0x10(%rsp), %rdi
    30a7:      	movl	$0x10, %edx
    30ac:      	movl	$0x4, %eax
    30b1:      	movq	0x68(%rsp), %rcx
    30b6:      	movslq	0x70(%rsp), %rdx
    30bb:      	shlq	$0x4, %rdx
    30bf:      	addq	%rcx, %rdx
    30c2:      	addq	$0x80, %rdx
    30c9:      	movl	$0x10, %esi
    30ce:      	callq	*%rax
    30d0:      	leaq	0x2c(%r14), %rdi
    30d4:      	movl	$0x158, %edx            # imm = 0x158
    30d9:      	movq	0x18(%rsp), %rcx
    30de:      	addq	%rdx, %rcx
    30e1:      	movl	$0x4, %eax
    30e6:      	addq	0x18(%rsp), %rdx
    30eb:      	movl	$0x4, %esi
    30f0:      	callq	*%rax
    30f2:      	jmp	0x30fc <generic_tracepoint_event+0x30fc>
    30f4:      	movl	$0x0, 0x2c(%r14)
    30fc:      	leaq	0x30(%r14), %rdi
    3100:      	movl	$0x158, %r12d           # imm = 0x158
    3106:      	movq	0x40(%rsp), %rcx
    310b:      	addq	%r12, %rcx
    310e:      	movl	$0x4, %edx
    3113:      	movl	$0x4, %eax
    3118:      	movq	0x40(%rsp), %rdx
    311d:      	addq	%r12, %rdx
    3120:      	movl	$0x4, %esi
    3125:      	callq	*%rax
    3127:      	leaq	0x34(%r14), %rdi
    312b:      	movl	$0x118, %edx            # imm = 0x118
    3130:      	movq	0x48(%rsp), %rcx
    3135:      	addq	%rdx, %rcx
    3138:      	movl	$0x4, %esi
    313d:      	movl	$0x4, %eax
    3142:      	addq	0x48(%rsp), %rdx
    3147:      	movl	$0x4, %esi
    314c:      	callq	*%rax
    314e:      	leaq	0x38(%r14), %rdi
    3152:      	movl	$0x98, %r13d
    3158:      	movq	0x50(%rsp), %rcx
    315d:      	addq	%r13, %rcx
    3160:      	movl	$0x4, %edx
    3165:      	movl	$0x4, %eax
    316a:      	movq	0x50(%rsp), %rdx
    316f:      	addq	%r13, %rdx
    3172:      	movl	$0x4, %esi
    3177:      	callq	*%rax
    3179:      	leaq	0x3c(%r14), %rdi
    317d:      	movq	0x58(%rsp), %rcx
    3182:      	addq	%r13, %rcx
    3185:      	movl	$0x4, %edx
    318a:      	movl	$0x4, %eax
    318f:      	addq	0x58(%rsp), %r13
    3194:      	movl	$0x4, %esi
    3199:      	movq	%r13, %rdx
    319c:      	callq	*%rax
    319e:      	leaq	0x40(%r14), %rdi
    31a2:      	movq	0x60(%rsp), %rcx
    31a7:      	addq	$0x58, %rcx
    31ab:      	movl	$0x4, %edx
    31b0:      	movl	$0x4, %eax
    31b5:      	movq	0x60(%rsp), %rdx
    31ba:      	addq	$0x58, %rdx
    31be:      	movl	$0x4, %esi
    31c3:      	callq	*%rax
    31c5:      	movq	$0x0, 0x10(%rsp)
    31ce:      	movq	$0x0, 0x68(%rsp)
    31d7:      	addq	$0xd00, %r15            # imm = 0xD00
    31de:      	leaq	0x10(%rsp), %rdi
    31e3:      	movl	$0x8, %ecx
    31e8:      	movl	$0x4, %eax
    31ed:      	movl	$0x8, %esi
    31f2:      	movq	%r15, %rdx
    31f5:      	callq	*%rax
    31f7:      	movl	$0x90, %edx
    31fc:      	movq	0x10(%rsp), %rcx
    3201:      	addq	%rdx, %rcx
    3204:      	leaq	0x68(%rsp), %rdi
    3209:      	movl	$0x8, %esi
    320e:      	movl	$0x4, %eax
    3213:      	addq	0x10(%rsp), %rdx
    3218:      	movl	$0x8, %esi
    321d:      	callq	*%rax
    321f:      	leaq	0x44(%r14), %rdi
    3223:      	movq	0x68(%rsp), %rcx
    3228:      	addq	%r12, %rcx
    322b:      	movl	$0x4, %edx
    3230:      	movl	$0x4, %eax
    3235:      	addq	0x68(%rsp), %r12
    323a:      	movl	$0x4, %esi
    323f:      	movq	%r12, %rdx
    3242:      	callq	*%rax
    3244:      	leaq	0x48(%r14), %r12
    3248:      	leaq	0x20(%rsp), %rdi
    324d:      	movl	$0x8, %ecx
    3252:      	movl	$0x4, %eax
    3257:      	movl	$0x8, %esi
    325c:      	movq	%r15, %rdx
    325f:      	callq	*%rax
    3261:      	movq	0x20(%rsp), %r15
    3266:      	leaq	0x50(%r14), %rdi
    326a:      	leaq	0x40(%r15), %rdx
    326e:      	movl	$0x8, %ecx
    3273:      	movl	$0x4, %eax
    3278:      	movl	$0x8, %esi
    327d:      	callq	*%rax
    327f:      	movq	%r14, %rdi
    3282:      	addq	$0x58, %rdi
    3286:      	leaq	0x30(%r15), %rdx
    328a:      	movl	$0x8, %ecx
    328f:      	movl	$0x4, %eax
    3294:      	movl	$0x8, %esi
    3299:      	callq	*%rax
    329b:      	addq	$0x38, %r15
    329f:      	movl	$0x8, %ecx
    32a4:      	movl	$0x4, %eax
    32a9:      	movq	%r12, %rdi
    32ac:      	movl	$0x8, %esi
    32b1:      	movq	%r15, %rdx
    32b4:      	callq	*%rax
    32b6:      	movb	$0x0, 0x1(%r14)
    32bb:      	movq	$0x0, 0x5ee8(%r14)
    32c6:      	movq	$0x0, 0x5ef0(%r14)
    32d1:      	movq	(%rip), %rsi            # 0x32d8 <generic_tracepoint_event+0x32d8>
    32d8:      	movl	$0x2, %ecx
    32dd:      	movl	$0xc, %eax
    32e2:      	movq	%rbx, %rdi
    32e5:      	movl	$0x2, %edx
    32ea:      	callq	*%rax
    32ec:      	xorl	%eax, %eax
    32ee:      	addq	$0x88, %rsp
    32f5:      	popq	%rbx
    32f6:      	popq	%r12
    32f8:      	popq	%r13
    32fa:      	popq	%r14
    32fc:      	popq	%r15
    32fe:      	popq	%rbp
    32ff:      	retq
