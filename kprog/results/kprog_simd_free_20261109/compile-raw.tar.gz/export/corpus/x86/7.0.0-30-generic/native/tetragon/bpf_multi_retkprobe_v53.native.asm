
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_multi_retkprobe_v53.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <native_bpf_strncasestr>:
       0:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
       5:      	testq	%rdx, %rdx
       8:      	je	0x74 <native_bpf_strncasestr+0x74>
       a:      	pushq	%rbx
       b:      	xorl	%ecx, %ecx
       d:      	jmp	0x1b <native_bpf_strncasestr+0x1b>
       f:      	nop
      10:      	incq	%rcx
      13:      	incq	%rdi
      16:      	cmpq	%rdx, %rcx
      19:      	je	0x73 <native_bpf_strncasestr+0x73>
      1b:      	xorl	%r8d, %r8d
      1e:      	nop
      20:      	leaq	(%rcx,%r8), %r9
      24:      	cmpq	%rdx, %r9
      27:      	jae	0x10 <native_bpf_strncasestr+0x10>
      29:      	movsbl	(%rsi,%r8), %r9d
      2e:      	testl	%r9d, %r9d
      31:      	je	0x71 <native_bpf_strncasestr+0x71>
      33:      	movsbl	(%rdi,%r8), %r10d
      38:      	leal	-0x41(%r10), %r11d
      3c:      	movl	%r10d, %ebx
      3f:      	orl	$0x20, %ebx
      42:      	cmpl	$0x1a, %r11d
      46:      	cmovael	%r10d, %ebx
      4a:      	leal	-0x41(%r9), %r10d
      4e:      	movl	%r9d, %r11d
      51:      	orl	$0x20, %r11d
      55:      	cmpl	$0x1a, %r10d
      59:      	cmovael	%r9d, %r11d
      5d:      	cmpl	%r11d, %ebx
      60:      	jne	0x10 <native_bpf_strncasestr+0x10>
      62:      	leaq	0x1(%r8), %r9
      66:      	cmpq	$0x63, %r8
      6a:      	movq	%r9, %r8
      6d:      	jb	0x20 <native_bpf_strncasestr+0x20>
      6f:      	jmp	0x10 <native_bpf_strncasestr+0x10>
      71:      	movl	%ecx, %eax
      73:      	popq	%rbx
      74:      	retq

Disassembly of section kprobe.multi:

0000000000000000 <generic_retkprobe_filter_arg>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0xb8, %rsp
      11:      	movq	%rdi, %r12
      14:      	movl	$0x0, 0xa4(%rsp)
      1f:      	movq	(%rip), %rdi            # 0x26 <generic_retkprobe_filter_arg+0x26>
      26:      	leaq	0xa4(%rsp), %rsi
      2e:      	movl	$0x1, %eax
      33:      	callq	*%rax
      35:      	testq	%rax, %rax
      38:      	je	0x17a <generic_retkprobe_filter_arg+0x17a>
      3e:      	movq	%rax, %r14
      41:      	movl	0x5f00(%rax), %ebx
      47:      	leaq	0x5ef8(%rax), %rsi
      4e:      	movq	(%rip), %rdi            # 0x55 <generic_retkprobe_filter_arg+0x55>
      55:      	movl	$0x1, %eax
      5a:      	callq	*%rax
      5c:      	testq	%rax, %rax
      5f:      	je	0x15f <generic_retkprobe_filter_arg+0x15f>
      65:      	cmpb	$0x0, 0x5ee0(%r14)
      6d:      	je	0x15f <generic_retkprobe_filter_arg+0x15f>
      73:      	movq	%rax, %rdi
      76:      	movl	%ebx, %eax
      78:      	andl	$0x7, %eax
      7b:      	cmpb	$0x0, 0x5ec1(%r14,%rax)
      84:      	je	0xb8 <generic_retkprobe_filter_arg+0xb8>
      86:      	movl	%eax, %eax
      88:      	movl	0x4(%rdi,%rax,4), %ecx
      8c:      	leaq	(%rcx,%rax,4), %r11
      90:      	addq	$0x8, %r11
      94:      	movl	%r11d, %r9d
      97:      	andl	$0x3ff, %r9d            # imm = 0x3FF
      9e:      	cmpl	$0x19, (%rdi,%r9)
      a3:      	jae	0x104 <generic_retkprobe_filter_arg+0x104>
      a5:      	cmpq	$0x1, %r9
      a9:      	je	0x15f <generic_retkprobe_filter_arg+0x15f>
      af:      	testl	%r9d, %r9d
      b2:      	jne	0x13d <generic_retkprobe_filter_arg+0x13d>
      b8:      	cmpl	$0x1, %ebx
      bb:      	jg	0xd9 <generic_retkprobe_filter_arg+0xd9>
      bd:      	cmpl	$-0x1, %ebx
      c0:      	je	0x18e <generic_retkprobe_filter_arg+0x18e>
      c6:      	testl	%ebx, %ebx
      c8:      	je	0x19a <generic_retkprobe_filter_arg+0x19a>
      ce:      	cmpl	$0x1, %ebx
      d1:      	je	0x1a9 <generic_retkprobe_filter_arg+0x1a9>
      d7:      	jmp	0xf4 <generic_retkprobe_filter_arg+0xf4>
      d9:      	cmpl	$0x2, %ebx
      dc:      	je	0x1b8 <generic_retkprobe_filter_arg+0x1b8>
      e2:      	cmpl	$0x3, %ebx
      e5:      	je	0x1c7 <generic_retkprobe_filter_arg+0x1c7>
      eb:      	cmpl	$0x4, %ebx
      ee:      	je	0x1d6 <generic_retkprobe_filter_arg+0x1d6>
      f4:      	cmpl	$0x4, %ebx
      f7:      	jg	0x207 <generic_retkprobe_filter_arg+0x207>
      fd:      	incl	%ebx
      ff:      	jmp	0x1e5 <generic_retkprobe_filter_arg+0x1e5>
     104:      	leaq	(%rdi,%r9), %rax
     108:      	movq	%rax, 0xb0(%rsp)
     110:      	xorl	%r13d, %r13d
     113:      	leaq	0x70(%rsp), %rax
     118:      	movq	%rax, 0x30(%rsp)
     11d:      	movq	%rbx, 0xa8(%rsp)
     125:      	movq	%rdi, (%rsp)
     129:      	movq	%r9, 0x8(%rsp)
     12e:      	movq	%r11, 0x10(%rsp)
     133:      	movq	%r12, 0x68(%rsp)
     138:      	jmp	0x283 <generic_retkprobe_filter_arg+0x283>
     13d:      	movl	%r9d, 0x5f04(%r14)
     144:      	movq	(%rip), %rsi            # 0x14b <generic_retkprobe_filter_arg+0x14b>
     14b:      	movl	$0x4, %ecx
     150:      	movl	$0xc, %eax
     155:      	movq	%r12, %rdi
     158:      	movl	$0x4, %edx
     15d:      	callq	*%rax
     15f:      	movq	(%rip), %rsi            # 0x166 <generic_retkprobe_filter_arg+0x166>
     166:      	movl	$0x5, %ecx
     16b:      	movl	$0xc, %eax
     170:      	movq	%r12, %rdi
     173:      	movl	$0x5, %edx
     178:      	callq	*%rax
     17a:      	xorl	%eax, %eax
     17c:      	addq	$0xb8, %rsp
     183:      	popq	%rbx
     184:      	popq	%r12
     186:      	popq	%r13
     188:      	popq	%r14
     18a:      	popq	%r15
     18c:      	popq	%rbp
     18d:      	retq
     18e:      	xorl	%ebx, %ebx
     190:      	cmpb	$0x0, 0x5ec1(%r14)
     198:      	jne	0x1e5 <generic_retkprobe_filter_arg+0x1e5>
     19a:      	movl	$0x1, %ebx
     19f:      	cmpb	$0x0, 0x5ec2(%r14)
     1a7:      	jne	0x1e5 <generic_retkprobe_filter_arg+0x1e5>
     1a9:      	movl	$0x2, %ebx
     1ae:      	cmpb	$0x0, 0x5ec3(%r14)
     1b6:      	jne	0x1e5 <generic_retkprobe_filter_arg+0x1e5>
     1b8:      	movl	$0x3, %ebx
     1bd:      	cmpb	$0x0, 0x5ec4(%r14)
     1c5:      	jne	0x1e5 <generic_retkprobe_filter_arg+0x1e5>
     1c7:      	movl	$0x4, %ebx
     1cc:      	cmpb	$0x0, 0x5ec5(%r14)
     1d4:      	jne	0x1e5 <generic_retkprobe_filter_arg+0x1e5>
     1d6:      	movl	$0x5, %ebx
     1db:      	cmpb	$0x0, 0x5ec6(%r14)
     1e3:      	je	0x207 <generic_retkprobe_filter_arg+0x207>
     1e5:      	movl	%ebx, 0x5f00(%r14)
     1ec:      	movq	(%rip), %rsi            # 0x1f3 <generic_retkprobe_filter_arg+0x1f3>
     1f3:      	movl	$0x3, %ecx
     1f8:      	movl	$0xc, %eax
     1fd:      	movq	%r12, %rdi
     200:      	movl	$0x3, %edx
     205:      	callq	*%rax
     207:      	movq	0x60(%r14), %rbx
     20b:      	movl	$0xe, %eax
     210:      	callq	*%rax
     212:      	movq	%rbx, 0x38(%rsp)
     217:      	movq	%rax, 0x40(%rsp)
     21c:      	movq	(%rip), %rdi            # 0x223 <generic_retkprobe_filter_arg+0x223>
     223:      	leaq	0x38(%rsp), %rsi
     228:      	movl	$0x1, %eax
     22d:      	callq	*%rax
     22f:      	testq	%rax, %rax
     232:      	je	0x17a <generic_retkprobe_filter_arg+0x17a>
     238:      	movq	(%rip), %rdi            # 0x23f <generic_retkprobe_filter_arg+0x23f>
     23f:      	leaq	0x38(%rsp), %rsi
     244:      	movl	$0x3, %eax
     249:      	callq	*%rax
     24b:      	jmp	0x17a <generic_retkprobe_filter_arg+0x17a>
     250:      	xorl	%ebx, %ebx
     252:      	movq	(%rsp), %rdi
     256:      	movq	0x8(%rsp), %r9
     25b:      	movq	0x10(%rsp), %r11
     260:      	movq	0x68(%rsp), %r12
     265:      	testq	%rbx, %rbx
     268:      	movq	0xa8(%rsp), %rbx
     270:      	je	0xb8 <generic_retkprobe_filter_arg+0xb8>
     276:      	incq	%r13
     279:      	cmpq	$0x5, %r13
     27d:      	je	0xa5 <generic_retkprobe_filter_arg+0xa5>
     283:      	movq	0xb0(%rsp), %rax
     28b:      	movl	0x4(%rax,%r13,4), %r15d
     290:      	testl	$0x3ff, %r15d           # imm = 0x3FF
     297:      	je	0xa5 <generic_retkprobe_filter_arg+0xa5>
     29d:      	addl	%r11d, %r15d
     2a0:      	andl	$0x3ff, %r15d           # imm = 0x3FF
     2a7:      	movl	0x4(%rdi,%r15), %eax
     2ac:      	cmpl	$0x23, %eax
     2af:      	je	0xb8 <generic_retkprobe_filter_arg+0xb8>
     2b5:      	addq	%rdi, %r15
     2b8:      	movl	(%r15), %ecx
     2bb:      	cmpq	$0x4, %rcx
     2bf:      	ja	0xb8 <generic_retkprobe_filter_arg+0xb8>
     2c5:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
     2ce:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
     2d4:      	movq	0x5e78(%r14,%rcx,8), %rcx
     2dc:      	andl	$0x7ff, %ecx            # imm = 0x7FF
     2e2:      	leaq	(%r14,%rcx), %rbp
     2e6:      	addq	$0x90, %rbp
     2ed:      	movl	0xc(%r15), %ecx
     2f1:      	cmpl	$0x10, %ecx
     2f4:      	jle	0x350 <generic_retkprobe_filter_arg+0x350>
     2f6:      	leal	-0x1c(%rcx), %edx
     2f9:      	cmpl	$0x9, %edx
     2fc:      	jb	0x541 <generic_retkprobe_filter_arg+0x541>
     302:      	cmpl	$0x2a, %ecx
     305:      	ja	0x341 <generic_retkprobe_filter_arg+0x341>
     307:      	movl	%ecx, %edx
     309:      	movabsq	$0xc000000000, %rsi     # imm = 0xC000000000
     313:      	btq	%rdx, %rsi
     317:      	jb	0x379 <generic_retkprobe_filter_arg+0x379>
     319:      	movabsq	$0x30000000000, %rsi    # imm = 0x30000000000
     323:      	btq	%rdx, %rsi
     327:      	jb	0x89c <generic_retkprobe_filter_arg+0x89c>
     32d:      	movabsq	$0x42000000000, %rsi    # imm = 0x42000000000
     337:      	btq	%rdx, %rsi
     33b:      	jb	0x3cc <generic_retkprobe_filter_arg+0x3cc>
     341:      	cmpl	$0x11, %ecx
     344:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
     34a:      	addq	$0x4, %rbp
     34e:      	jmp	0x3cc <generic_retkprobe_filter_arg+0x3cc>
     350:      	cmpl	$0x6, %ecx
     353:      	jg	0x3b4 <generic_retkprobe_filter_arg+0x3b4>
     355:      	cmpl	$0x3, %ecx
     358:      	jle	0x4f3 <generic_retkprobe_filter_arg+0x4f3>
     35e:      	cmpl	$0x4, %ecx
     361:      	je	0x541 <generic_retkprobe_filter_arg+0x541>
     367:      	cmpl	$0x5, %ecx
     36a:      	je	0x89c <generic_retkprobe_filter_arg+0x89c>
     370:      	cmpl	$0x6, %ecx
     373:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
     379:      	movq	%rbp, %rsi
     37c:      	movl	(%rbp), %ebp
     37f:      	addq	$0x4, %rsi
     383:      	cmpl	$0x19, %eax
     386:      	jg	0x6c6 <generic_retkprobe_filter_arg+0x6c6>
     38c:      	leal	-0x3(%rax), %ecx
     38f:      	cmpl	$0x2, %ecx
     392:      	jb	0xf07 <generic_retkprobe_filter_arg+0xf07>
     398:      	cmpl	$0x8, %eax
     39b:      	je	0xe67 <generic_retkprobe_filter_arg+0xe67>
     3a1:      	movl	$0x0, %ebx
     3a6:      	cmpl	$0x9, %eax
     3a9:      	je	0x6e6 <generic_retkprobe_filter_arg+0x6e6>
     3af:      	jmp	0x2c6b <generic_retkprobe_filter_arg+0x2c6b>
     3b4:      	leal	-0xa(%rcx), %edx
     3b7:      	cmpl	$0x4, %edx
     3ba:      	jb	0x541 <generic_retkprobe_filter_arg+0x541>
     3c0:      	leal	-0xf(%rcx), %edx
     3c3:      	cmpl	$0x2, %edx
     3c6:      	jae	0x893 <generic_retkprobe_filter_arg+0x893>
     3cc:      	movq	%rbp, 0x20(%rsp)
     3d1:      	movl	(%rbp), %ebp
     3d4:      	movl	%eax, %ecx
     3d6:      	andl	$-0x2, %ecx
     3d9:      	cmpl	$0x24, %ecx
     3dc:      	je	0x3e6 <generic_retkprobe_filter_arg+0x3e6>
     3de:      	testl	%ebp, %ebp
     3e0:      	je	0xb8 <generic_retkprobe_filter_arg+0xb8>
     3e6:      	cmpl	$0x25, %eax
     3e9:      	movq	0x20(%rsp), %rsi
     3ee:      	ja	0x829 <generic_retkprobe_filter_arg+0x829>
     3f4:      	movl	%eax, %ecx
     3f6:      	movl	$0x4000100, %edx        # imm = 0x4000100
     3fb:      	btq	%rcx, %rdx
     3ff:      	jb	0xb9d <generic_retkprobe_filter_arg+0xb9d>
     405:      	movl	$0x8000200, %edx        # imm = 0x8000200
     40a:      	btq	%rcx, %rdx
     40e:      	jb	0xa5b <generic_retkprobe_filter_arg+0xa5b>
     414:      	movabsq	$0x3000000000, %rdx     # imm = 0x3000000000
     41e:      	btq	%rcx, %rdx
     422:      	jae	0x829 <generic_retkprobe_filter_arg+0x829>
     428:      	movw	$0x0, 0x38(%rsp)
     42f:      	cmpl	$0x1fe, %ebp            # imm = 0x1FE
     435:      	ja	0x845 <generic_retkprobe_filter_arg+0x845>
     43b:      	leaq	(%rsi,%rbp), %rcx
     43f:      	addq	$0x8, %rcx
     443:      	movl	$0x4, %eax
     448:      	leaq	0x38(%rsp), %rdi
     44d:      	movl	$0x2, %edx
     452:      	movl	(%rsi), %ecx
     454:      	leaq	(%rsi,%rcx), %rdx
     458:      	addq	$0x8, %rdx
     45c:      	movl	$0x2, %esi
     461:      	callq	*%rax
     463:      	movl	0x10(%r15), %ecx
     467:      	testl	%ecx, %ecx
     469:      	je	0x2aa6 <generic_retkprobe_filter_arg+0x2aa6>
     46f:      	movzwl	0x38(%rsp), %eax
     474:      	andl	$0xf000, %eax           # imm = 0xF000
     479:      	movl	$0x1, %ebx
     47e:      	cmpl	%eax, %ecx
     480:      	je	0x2aa8 <generic_retkprobe_filter_arg+0x2aa8>
     486:      	movl	0x8(%r15), %ecx
     48a:      	cmpl	$0xd, %ecx
     48d:      	movq	(%rsp), %rdi
     491:      	movq	0x8(%rsp), %r9
     496:      	movq	0x10(%rsp), %r11
     49b:      	jb	0x845 <generic_retkprobe_filter_arg+0x845>
     4a1:      	movl	0x14(%r15), %edx
     4a5:      	testl	%edx, %edx
     4a7:      	je	0x845 <generic_retkprobe_filter_arg+0x845>
     4ad:      	cmpl	%eax, %edx
     4af:      	je	0x2ab6 <generic_retkprobe_filter_arg+0x2ab6>
     4b5:      	cmpl	$0x11, %ecx
     4b8:      	jb	0x845 <generic_retkprobe_filter_arg+0x845>
     4be:      	movl	0x18(%r15), %edx
     4c2:      	testl	%edx, %edx
     4c4:      	je	0x845 <generic_retkprobe_filter_arg+0x845>
     4ca:      	cmpl	%eax, %edx
     4cc:      	je	0x2ab6 <generic_retkprobe_filter_arg+0x2ab6>
     4d2:      	cmpl	$0x15, %ecx
     4d5:      	jb	0x2aa6 <generic_retkprobe_filter_arg+0x2aa6>
     4db:      	movl	0x1c(%r15), %ecx
     4df:      	testl	%ecx, %ecx
     4e1:      	je	0x2aa6 <generic_retkprobe_filter_arg+0x2aa6>
     4e7:      	xorl	%ebx, %ebx
     4e9:      	cmpl	%eax, %ecx
     4eb:      	sete	%bl
     4ee:      	jmp	0x2aa8 <generic_retkprobe_filter_arg+0x2aa8>
     4f3:      	cmpl	$0x1, %ecx
     4f6:      	je	0x541 <generic_retkprobe_filter_arg+0x541>
     4f8:      	cmpl	$0x2, %ecx
     4fb:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
     501:      	movq	%rbp, %rsi
     504:      	movl	0x4(%rbp), %ebp
     507:      	addq	$0x8, %rsi
     50b:      	cmpl	$0x19, %eax
     50e:      	jg	0xf81 <generic_retkprobe_filter_arg+0xf81>
     514:      	leal	-0x3(%rax), %ecx
     517:      	cmpl	$0x2, %ecx
     51a:      	jb	0x1754 <generic_retkprobe_filter_arg+0x1754>
     520:      	movq	%rsi, 0x20(%rsp)
     525:      	cmpl	$0x8, %eax
     528:      	je	0x16c0 <generic_retkprobe_filter_arg+0x16c0>
     52e:      	movl	$0x0, %ebx
     533:      	cmpl	$0x9, %eax
     536:      	je	0xfa6 <generic_retkprobe_filter_arg+0xfa6>
     53c:      	jmp	0x2ef2 <generic_retkprobe_filter_arg+0x2ef2>
     541:      	cmpl	$0xb, %ecx
     544:      	jle	0x5d3 <generic_retkprobe_filter_arg+0x5d3>
     54a:      	cmpl	$0x24, %ecx
     54d:      	ja	0x61a <generic_retkprobe_filter_arg+0x61a>
     553:      	movl	%ecx, %edx
     555:      	movabsq	$0x1e00000000, %rsi     # imm = 0x1E00000000
     55f:      	btq	%rdx, %rsi
     563:      	jb	0x5ee <generic_retkprobe_filter_arg+0x5ee>
     569:      	movl	$0x60000000, %esi       # imm = 0x60000000
     56e:      	btq	%rdx, %rsi
     572:      	jb	0x84c <generic_retkprobe_filter_arg+0x84c>
     578:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
     582:      	btq	%rdx, %rsi
     586:      	jae	0x61a <generic_retkprobe_filter_arg+0x61a>
     58c:      	cmpl	$0x20, %eax
     58f:      	ja	0xb8 <generic_retkprobe_filter_arg+0xb8>
     595:      	movl	%eax, %ecx
     597:      	movl	$0x101e, %edx           # imm = 0x101E
     59c:      	btq	%rcx, %rdx
     5a0:      	jae	0x10ef <generic_retkprobe_filter_arg+0x10ef>
     5a6:      	movl	0x10(%r15), %ecx
     5aa:      	cmpl	$0x2, %eax
     5ad:      	jle	0x157c <generic_retkprobe_filter_arg+0x157c>
     5b3:      	leal	-0x3(%rax), %edx
     5b6:      	cmpl	$0x2, %edx
     5b9:      	jae	0x1b2c <generic_retkprobe_filter_arg+0x1b2c>
     5bf:      	movq	%rbp, %rdx
     5c2:      	movzbl	(%rbp), %edx
     5c6:      	cmpl	%edx, %ecx
     5c8:      	jne	0x1e23 <generic_retkprobe_filter_arg+0x1e23>
     5ce:      	jmp	0x2e81 <generic_retkprobe_filter_arg+0x2e81>
     5d3:      	leal	-0xa(%rcx), %edx
     5d6:      	cmpl	$0x2, %edx
     5d9:      	jb	0x95f <generic_retkprobe_filter_arg+0x95f>
     5df:      	cmpl	$0x1, %ecx
     5e2:      	je	0x626 <generic_retkprobe_filter_arg+0x626>
     5e4:      	cmpl	$0x4, %ecx
     5e7:      	je	0x626 <generic_retkprobe_filter_arg+0x626>
     5e9:      	jmp	0x276 <generic_retkprobe_filter_arg+0x276>
     5ee:      	cmpl	$0x9, %eax
     5f1:      	jle	0x912 <generic_retkprobe_filter_arg+0x912>
     5f7:      	cmpl	$0x1d, %eax
     5fa:      	jg	0xd40 <generic_retkprobe_filter_arg+0xd40>
     600:      	leal	-0xa(%rax), %edx
     603:      	cmpl	$0x2, %edx
     606:      	jb	0x9ec <generic_retkprobe_filter_arg+0x9ec>
     60c:      	cmpl	$0xc, %eax
     60f:      	je	0x975 <generic_retkprobe_filter_arg+0x975>
     615:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
     61a:      	leal	-0xc(%rcx), %edx
     61d:      	cmpl	$0x2, %edx
     620:      	jae	0x956 <generic_retkprobe_filter_arg+0x956>
     626:      	cmpl	$0x20, %eax
     629:      	ja	0xb8 <generic_retkprobe_filter_arg+0xb8>
     62f:      	movl	%eax, %edx
     631:      	movl	$0x101e, %esi           # imm = 0x101E
     636:      	btq	%rdx, %rsi
     63a:      	jae	0x663 <generic_retkprobe_filter_arg+0x663>
     63c:      	movl	0x10(%r15), %edx
     640:      	cmpl	$0x2, %eax
     643:      	jle	0x91f <generic_retkprobe_filter_arg+0x91f>
     649:      	leal	-0x3(%rax), %esi
     64c:      	cmpl	$0x2, %esi
     64f:      	jae	0x10d8 <generic_retkprobe_filter_arg+0x10d8>
     655:      	cmpl	%edx, (%rbp)
     658:      	jne	0x2062 <generic_retkprobe_filter_arg+0x2062>
     65e:      	jmp	0x2e81 <generic_retkprobe_filter_arg+0x2e81>
     663:      	movl	$0xc00, %esi            # imm = 0xC00
     668:      	btq	%rdx, %rsi
     66c:      	jb	0xc3c <generic_retkprobe_filter_arg+0xc3c>
     672:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
     67c:      	btq	%rdx, %rsi
     680:      	jae	0xb8 <generic_retkprobe_filter_arg+0xb8>
     686:      	cmpl	$0x1f, %eax
     689:      	jne	0x1227 <generic_retkprobe_filter_arg+0x1227>
     68f:      	movl	0x10(%r15), %esi
     693:      	movl	0x14(%r15), %edx
     697:      	cmpl	$0xc, %ecx
     69a:      	ja	0x1eb9 <generic_retkprobe_filter_arg+0x1eb9>
     6a0:      	movl	$0x1402, %eax           # imm = 0x1402
     6a5:      	btl	%ecx, %eax
     6a8:      	jae	0x1eb9 <generic_retkprobe_filter_arg+0x1eb9>
     6ae:      	movl	(%rbp), %eax
     6b1:      	cmpl	%eax, %esi
     6b3:      	jg	0x1ec8 <generic_retkprobe_filter_arg+0x1ec8>
     6b9:      	cmpl	%edx, %eax
     6bb:      	jle	0x276 <generic_retkprobe_filter_arg+0x276>
     6c1:      	jmp	0x1ec8 <generic_retkprobe_filter_arg+0x1ec8>
     6c6:      	cmpl	$0x20, %eax
     6c9:      	jg	0xd86 <generic_retkprobe_filter_arg+0xd86>
     6cf:      	cmpl	$0x1a, %eax
     6d2:      	je	0xe67 <generic_retkprobe_filter_arg+0xe67>
     6d8:      	movl	$0x0, %ebx
     6dd:      	cmpl	$0x1b, %eax
     6e0:      	jne	0x2c6b <generic_retkprobe_filter_arg+0x2c6b>
     6e6:      	movq	%rsi, 0x20(%rsp)
     6eb:      	movl	0x10(%r15), %eax
     6ef:      	movl	%eax, 0x38(%rsp)
     6f3:      	movl	$0x0, 0x70(%rsp)
     6fb:      	movl	$0x1, %eax
     700:      	leaq	0x38(%rsp), %rsi
     705:      	movq	(%rip), %rdi            # 0x70c <generic_retkprobe_filter_arg+0x70c>
     70c:      	callq	*%rax
     70e:      	testl	%ebp, %ebp
     710:      	je	0x2c5b <generic_retkprobe_filter_arg+0x2c5b>
     716:      	movl	$0x0, %ebx
     71b:      	testq	%rax, %rax
     71e:      	je	0x2c5d <generic_retkprobe_filter_arg+0x2c5d>
     724:      	movq	%rax, 0x18(%rsp)
     729:      	movl	$0x1, %eax
     72e:      	movq	0x30(%rsp), %rsi
     733:      	movq	(%rip), %rdi            # 0x73a <generic_retkprobe_filter_arg+0x73a>
     73a:      	callq	*%rax
     73c:      	testq	%rax, %rax
     73f:      	je	0x2c5b <generic_retkprobe_filter_arg+0x2c5b>
     745:      	movq	%rax, %rdi
     748:      	cmpl	$0x7f, %ebp
     74b:      	movl	$0x7f, %eax
     750:      	cmovbl	%ebp, %eax
     753:      	shll	$0x3, %eax
     756:      	movl	%eax, (%rdi)
     758:      	movq	%rbp, %rax
     75b:      	negq	%rax
     75e:      	movl	$0x3, %ecx
     763:      	subq	%rbp, %rcx
     766:      	leal	-0x4(%rbp), %edx
     769:      	movq	%rdi, 0x60(%rsp)
     76e:      	addq	$0x7, %rdi
     772:      	movl	$0x2, %r8d
     778:      	subq	%rbp, %r8
     77b:      	leal	-0x3(%rbp), %r9d
     77f:      	movl	$0x1, %r10d
     785:      	subq	%rbp, %r10
     788:      	leal	-0x2(%rbp), %r11d
     78c:      	decl	%ebp
     78e:      	xorl	%ebx, %ebx
     790:      	movq	0x20(%rsp), %rsi
     795:      	leal	(%rbx,%rbp), %r12d
     799:      	andl	$0xfff, %r12d           # imm = 0xFFF
     7a0:      	movzbl	(%rsi,%r12), %r12d
     7a5:      	movb	%r12b, -0x3(%rdi)
     7a9:      	cmpq	%rbx, %r10
     7ac:      	je	0x806 <generic_retkprobe_filter_arg+0x806>
     7ae:      	leal	(%r11,%rbx), %r12d
     7b2:      	andl	$0xfff, %r12d           # imm = 0xFFF
     7b9:      	movzbl	(%rsi,%r12), %r12d
     7be:      	movb	%r12b, -0x2(%rdi)
     7c2:      	cmpq	%rbx, %r8
     7c5:      	je	0x806 <generic_retkprobe_filter_arg+0x806>
     7c7:      	leal	(%r9,%rbx), %r12d
     7cb:      	andl	$0xfff, %r12d           # imm = 0xFFF
     7d2:      	movzbl	(%rsi,%r12), %r12d
     7d7:      	movb	%r12b, -0x1(%rdi)
     7db:      	cmpq	%rbx, %rcx
     7de:      	je	0x806 <generic_retkprobe_filter_arg+0x806>
     7e0:      	cmpq	$-0x7c, %rbx
     7e4:      	je	0x806 <generic_retkprobe_filter_arg+0x806>
     7e6:      	leal	(%rdx,%rbx), %r12d
     7ea:      	andl	$0xfff, %r12d           # imm = 0xFFF
     7f1:      	movzbl	(%rsi,%r12), %r12d
     7f6:      	movb	%r12b, (%rdi)
     7f9:      	addq	$-0x4, %rbx
     7fd:      	addq	$0x4, %rdi
     801:      	cmpq	%rbx, %rax
     804:      	jne	0x795 <generic_retkprobe_filter_arg+0x795>
     806:      	movl	$0x1, %eax
     80b:      	movq	0x18(%rsp), %rdi
     810:      	movq	0x60(%rsp), %rsi
     815:      	callq	*%rax
     817:      	xorl	%ebx, %ebx
     819:      	testq	%rax, %rax
     81c:      	setne	%bl
     81f:      	movq	0x68(%rsp), %r12
     824:      	jmp	0x2c5d <generic_retkprobe_filter_arg+0x2c5d>
     829:      	addl	$-0x3, %eax
     82c:      	cmpl	$0x2, %eax
     82f:      	jae	0x845 <generic_retkprobe_filter_arg+0x845>
     831:      	movl	$0x0, 0x70(%rsp)
     839:      	cmpl	$0x1fe, %ebp            # imm = 0x1FE
     83f:      	jbe	0x11d6 <generic_retkprobe_filter_arg+0x11d6>
     845:      	xorl	%ebx, %ebx
     847:      	jmp	0x2ab6 <generic_retkprobe_filter_arg+0x2ab6>
     84c:      	cmpl	$0x20, %eax
     84f:      	ja	0xb8 <generic_retkprobe_filter_arg+0xb8>
     855:      	movl	%eax, %ecx
     857:      	movl	$0x101e, %edx           # imm = 0x101E
     85c:      	btq	%rcx, %rdx
     860:      	jae	0x1121 <generic_retkprobe_filter_arg+0x1121>
     866:      	movl	0x10(%r15), %ecx
     86a:      	cmpl	$0x2, %eax
     86d:      	jle	0x159f <generic_retkprobe_filter_arg+0x159f>
     873:      	leal	-0x3(%rax), %edx
     876:      	cmpl	$0x2, %edx
     879:      	jae	0x1b46 <generic_retkprobe_filter_arg+0x1b46>
     87f:      	movq	%rbp, %rdx
     882:      	movzwl	(%rbp), %edx
     886:      	cmpl	%edx, %ecx
     888:      	jne	0x1e66 <generic_retkprobe_filter_arg+0x1e66>
     88e:      	jmp	0x2e81 <generic_retkprobe_filter_arg+0x2e81>
     893:      	cmpl	$0x7, %ecx
     896:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
     89c:      	movq	$0x0, 0x58(%rsp)
     8a5:      	movq	$0x0, 0x50(%rsp)
     8ae:      	movq	$0x0, 0x48(%rsp)
     8b7:      	movq	$0x0, 0x40(%rsp)
     8c0:      	movq	$0x0, 0x38(%rsp)
     8c9:      	cmpl	$0x27, %ecx
     8cc:      	jg	0x8f0 <generic_retkprobe_filter_arg+0x8f0>
     8ce:      	cmpl	$0x5, %ecx
     8d1:      	movq	%rbp, %rsi
     8d4:      	je	0xcbb <generic_retkprobe_filter_arg+0xcbb>
     8da:      	movq	%rsi, %rdx
     8dd:      	movl	$0x0, %ebx
     8e2:      	cmpl	$0x7, %ecx
     8e5:      	je	0xcbd <generic_retkprobe_filter_arg+0xcbd>
     8eb:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
     8f0:      	cmpl	$0x28, %ecx
     8f3:      	movq	%rbp, %rsi
     8f6:      	je	0xc93 <generic_retkprobe_filter_arg+0xc93>
     8fc:      	movq	%rsi, %rdx
     8ff:      	movl	$0x0, %ebx
     904:      	cmpl	$0x29, %ecx
     907:      	je	0xcbd <generic_retkprobe_filter_arg+0xcbd>
     90d:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
     912:      	leal	-0x1(%rax), %edx
     915:      	cmpl	$0x4, %edx
     918:      	jb	0x975 <generic_retkprobe_filter_arg+0x975>
     91a:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
     91f:      	cmpl	$0x1, %eax
     922:      	je	0x1382 <generic_retkprobe_filter_arg+0x1382>
     928:      	cmpl	$0x2, %eax
     92b:      	jne	0x2062 <generic_retkprobe_filter_arg+0x2062>
     931:      	cmpl	$0xc, %ecx
     934:      	ja	0x2059 <generic_retkprobe_filter_arg+0x2059>
     93a:      	movl	$0x1402, %esi           # imm = 0x1402
     93f:      	btl	%ecx, %esi
     942:      	jae	0x2059 <generic_retkprobe_filter_arg+0x2059>
     948:      	cmpl	%edx, (%rbp)
     94b:      	jl	0x276 <generic_retkprobe_filter_arg+0x276>
     951:      	jmp	0x2062 <generic_retkprobe_filter_arg+0x2062>
     956:      	cmpl	$0x1c, %ecx
     959:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
     95f:      	cmpl	$0x20, %eax
     962:      	ja	0xb8 <generic_retkprobe_filter_arg+0xb8>
     968:      	movl	%eax, %edx
     96a:      	movl	$0x101e, %esi           # imm = 0x101E
     96f:      	btq	%rdx, %rsi
     973:      	jae	0x999 <generic_retkprobe_filter_arg+0x999>
     975:      	movq	0x10(%r15), %rdx
     979:      	cmpl	$0x2, %eax
     97c:      	jle	0x9bd <generic_retkprobe_filter_arg+0x9bd>
     97e:      	leal	-0x3(%rax), %esi
     981:      	cmpl	$0x2, %esi
     984:      	jae	0xc7b <generic_retkprobe_filter_arg+0xc7b>
     98a:      	cmpq	%rdx, (%rbp)
     98e:      	jne	0x1ab0 <generic_retkprobe_filter_arg+0x1ab0>
     994:      	jmp	0x2e81 <generic_retkprobe_filter_arg+0x2e81>
     999:      	movl	$0xc00, %esi            # imm = 0xC00
     99e:      	btq	%rdx, %rsi
     9a2:      	jb	0x9ec <generic_retkprobe_filter_arg+0x9ec>
     9a4:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
     9ae:      	btq	%rdx, %rsi
     9b2:      	jb	0xd4c <generic_retkprobe_filter_arg+0xd4c>
     9b8:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
     9bd:      	cmpl	$0x1, %eax
     9c0:      	je	0x11b9 <generic_retkprobe_filter_arg+0x11b9>
     9c6:      	cmpl	$0x2, %eax
     9c9:      	jne	0x1ab0 <generic_retkprobe_filter_arg+0x1ab0>
     9cf:      	cmpl	$0xc, %ecx
     9d2:      	je	0x9dd <generic_retkprobe_filter_arg+0x9dd>
     9d4:      	cmpl	$0xa, %ecx
     9d7:      	jne	0x1aa6 <generic_retkprobe_filter_arg+0x1aa6>
     9dd:      	cmpq	%rdx, (%rbp)
     9e1:      	jl	0x276 <generic_retkprobe_filter_arg+0x276>
     9e7:      	jmp	0x1ab0 <generic_retkprobe_filter_arg+0x1ab0>
     9ec:      	movzbl	0x10(%r15), %eax
     9f1:      	movl	%eax, 0x70(%rsp)
     9f5:      	movl	$0x1, %eax
     9fa:      	movq	0x30(%rsp), %rsi
     9ff:      	movq	(%rip), %rdi            # 0xa06 <generic_retkprobe_filter_arg+0xa06>
     a06:      	callq	*%rax
     a08:      	testq	%rax, %rax
     a0b:      	je	0x166d <generic_retkprobe_filter_arg+0x166d>
     a11:      	movq	%rax, %rdi
     a14:      	movq	(%rbp), %rax
     a18:      	movq	%rax, 0x38(%rsp)
     a1d:      	movl	$0x1, %eax
     a22:      	leaq	0x38(%rsp), %rsi
     a27:      	callq	*%rax
     a29:      	movl	0x4(%r15), %ecx
     a2d:      	cmpl	$0xb, %ecx
     a30:      	je	0x169a <generic_retkprobe_filter_arg+0x169a>
     a36:      	cmpl	$0xa, %ecx
     a39:      	movq	(%rsp), %rdi
     a3d:      	movq	0x8(%rsp), %r9
     a42:      	movq	0x10(%rsp), %r11
     a47:      	jne	0x16b6 <generic_retkprobe_filter_arg+0x16b6>
     a4d:      	testq	%rax, %rax
     a50:      	setne	%al
     a53:      	movzbl	%al, %ebx
     a56:      	jmp	0x265 <generic_retkprobe_filter_arg+0x265>
     a5b:      	movl	0x10(%r15), %eax
     a5f:      	movl	%eax, 0x38(%rsp)
     a63:      	movl	$0x0, 0x70(%rsp)
     a6b:      	movl	$0x1, %eax
     a70:      	leaq	0x38(%rsp), %rsi
     a75:      	movq	(%rip), %rdi            # 0xa7c <generic_retkprobe_filter_arg+0xa7c>
     a7c:      	callq	*%rax
     a7e:      	testl	%ebp, %ebp
     a80:      	je	0x2aa6 <generic_retkprobe_filter_arg+0x2aa6>
     a86:      	movl	$0x0, %ebx
     a8b:      	testq	%rax, %rax
     a8e:      	je	0x2aa8 <generic_retkprobe_filter_arg+0x2aa8>
     a94:      	movq	%rax, 0x18(%rsp)
     a99:      	movl	$0x1, %eax
     a9e:      	movq	0x30(%rsp), %rsi
     aa3:      	movq	(%rip), %rdi            # 0xaaa <generic_retkprobe_filter_arg+0xaaa>
     aaa:      	callq	*%rax
     aac:      	testq	%rax, %rax
     aaf:      	je	0x2aa6 <generic_retkprobe_filter_arg+0x2aa6>
     ab5:      	movq	%rax, %rdi
     ab8:      	cmpl	$0x7f, %ebp
     abb:      	movl	$0x7f, %eax
     ac0:      	cmovbl	%ebp, %eax
     ac3:      	shll	$0x3, %eax
     ac6:      	movl	%eax, (%rdi)
     ac8:      	movq	%rbp, %rax
     acb:      	negq	%rax
     ace:      	movl	$0x3, %ecx
     ad3:      	subq	%rbp, %rcx
     ad6:      	leal	-0x4(%rbp), %edx
     ad9:      	movq	%rdi, 0x60(%rsp)
     ade:      	addq	$0x7, %rdi
     ae2:      	movl	$0x2, %r8d
     ae8:      	subq	%rbp, %r8
     aeb:      	leal	-0x3(%rbp), %r9d
     aef:      	movl	$0x1, %r10d
     af5:      	subq	%rbp, %r10
     af8:      	leal	-0x2(%rbp), %r11d
     afc:      	decl	%ebp
     afe:      	xorl	%ebx, %ebx
     b00:      	movq	0x20(%rsp), %rsi
     b05:      	leal	(%rbx,%rbp), %r12d
     b09:      	andl	$0xfff, %r12d           # imm = 0xFFF
     b10:      	movzbl	0x4(%rsi,%r12), %r12d
     b16:      	movb	%r12b, -0x3(%rdi)
     b1a:      	cmpq	%rbx, %r10
     b1d:      	je	0xb7a <generic_retkprobe_filter_arg+0xb7a>
     b1f:      	leal	(%r11,%rbx), %r12d
     b23:      	andl	$0xfff, %r12d           # imm = 0xFFF
     b2a:      	movzbl	0x4(%rsi,%r12), %r12d
     b30:      	movb	%r12b, -0x2(%rdi)
     b34:      	cmpq	%rbx, %r8
     b37:      	je	0xb7a <generic_retkprobe_filter_arg+0xb7a>
     b39:      	leal	(%r9,%rbx), %r12d
     b3d:      	andl	$0xfff, %r12d           # imm = 0xFFF
     b44:      	movzbl	0x4(%rsi,%r12), %r12d
     b4a:      	movb	%r12b, -0x1(%rdi)
     b4e:      	cmpq	%rbx, %rcx
     b51:      	je	0xb7a <generic_retkprobe_filter_arg+0xb7a>
     b53:      	cmpq	$-0x7c, %rbx
     b57:      	je	0xb7a <generic_retkprobe_filter_arg+0xb7a>
     b59:      	leal	(%rdx,%rbx), %r12d
     b5d:      	andl	$0xfff, %r12d           # imm = 0xFFF
     b64:      	movzbl	0x4(%rsi,%r12), %r12d
     b6a:      	movb	%r12b, (%rdi)
     b6d:      	addq	$-0x4, %rbx
     b71:      	addq	$0x4, %rdi
     b75:      	cmpq	%rbx, %rax
     b78:      	jne	0xb05 <generic_retkprobe_filter_arg+0xb05>
     b7a:      	movl	$0x1, %eax
     b7f:      	movq	0x18(%rsp), %rdi
     b84:      	movq	0x60(%rsp), %rsi
     b89:      	callq	*%rax
     b8b:      	xorl	%ebx, %ebx
     b8d:      	testq	%rax, %rax
     b90:      	setne	%bl
     b93:      	movq	0x68(%rsp), %r12
     b98:      	jmp	0x2aa8 <generic_retkprobe_filter_arg+0x2aa8>
     b9d:      	movl	0x10(%r15), %eax
     ba1:      	movl	%eax, 0x38(%rsp)
     ba5:      	movl	$0x0, 0x70(%rsp)
     bad:      	movl	$0x1, %eax
     bb2:      	leaq	0x38(%rsp), %rsi
     bb7:      	movq	(%rip), %rdi            # 0xbbe <generic_retkprobe_filter_arg+0xbbe>
     bbe:      	callq	*%rax
     bc0:      	testl	%ebp, %ebp
     bc2:      	je	0x2aa6 <generic_retkprobe_filter_arg+0x2aa6>
     bc8:      	movl	$0x0, %ebx
     bcd:      	testq	%rax, %rax
     bd0:      	je	0x2aa8 <generic_retkprobe_filter_arg+0x2aa8>
     bd6:      	movq	%rax, 0x18(%rsp)
     bdb:      	movl	$0x1, %eax
     be0:      	movq	0x30(%rsp), %rsi
     be5:      	movq	(%rip), %rdi            # 0xbec <generic_retkprobe_filter_arg+0xbec>
     bec:      	callq	*%rax
     bee:      	testq	%rax, %rax
     bf1:      	je	0x2aa6 <generic_retkprobe_filter_arg+0x2aa6>
     bf7:      	movq	%rax, %rbx
     bfa:      	movq	0x20(%rsp), %rdx
     bff:      	addq	$0x4, %rdx
     c03:      	cmpl	$0xff, %ebp
     c09:      	movl	$0xff, %eax
     c0e:      	cmovael	%eax, %ebp
     c11:      	leal	(,%rbp,8), %eax
     c18:      	movl	%eax, (%rbx)
     c1a:      	movq	%rbx, %rdi
     c1d:      	addq	$0x4, %rdi
     c21:      	movl	$0x4, %eax
     c26:      	movl	%ebp, %esi
     c28:      	callq	*%rax
     c2a:      	movl	$0x1, %eax
     c2f:      	movq	0x18(%rsp), %rdi
     c34:      	movq	%rbx, %rsi
     c37:      	jmp	0x2a9a <generic_retkprobe_filter_arg+0x2a9a>
     c3c:      	movzbl	0x10(%r15), %eax
     c41:      	movl	%eax, 0x70(%rsp)
     c45:      	movl	$0x1, %eax
     c4a:      	movq	0x30(%rsp), %rsi
     c4f:      	movq	(%rip), %rdi            # 0xc56 <generic_retkprobe_filter_arg+0xc56>
     c56:      	callq	*%rax
     c58:      	testq	%rax, %rax
     c5b:      	je	0x166d <generic_retkprobe_filter_arg+0x166d>
     c61:      	movq	%rax, %rdi
     c64:      	movl	(%rbp), %eax
     c67:      	movq	%rax, 0x38(%rsp)
     c6c:      	movl	$0x1, %eax
     c71:      	leaq	0x38(%rsp), %rsi
     c76:      	jmp	0x1636 <generic_retkprobe_filter_arg+0x1636>
     c7b:      	cmpl	$0xc, %eax
     c7e:      	jne	0x1ab0 <generic_retkprobe_filter_arg+0x1ab0>
     c84:      	testq	%rdx, (%rbp)
     c88:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
     c8e:      	jmp	0x1ab0 <generic_retkprobe_filter_arg+0x1ab0>
     c93:      	movzwl	(%rsi), %edx
     c96:      	movw	%dx, 0x5e(%rsp)
     c9b:      	movzwl	0x2(%rsi), %edx
     c9f:      	movw	%dx, 0x58(%rsp)
     ca4:      	movq	0x8(%rsi), %rdx
     ca8:      	movq	%rdx, 0x38(%rsp)
     cad:      	movq	0x10(%rsi), %rdx
     cb1:      	movq	%rdx, 0x40(%rsp)
     cb6:      	leaq	0x38(%rsp), %rsi
     cbb:      	xorl	%edx, %edx
     cbd:      	cmpl	$0x13, %eax
     cc0:      	jle	0xce9 <generic_retkprobe_filter_arg+0xce9>
     cc2:      	cmpl	$0x17, %eax
     cc5:      	jg	0xd1b <generic_retkprobe_filter_arg+0xd1b>
     cc7:      	leal	-0x14(%rax), %ecx
     cca:      	cmpl	$0x2, %ecx
     ccd:      	jb	0x1273 <generic_retkprobe_filter_arg+0x1273>
     cd3:      	leal	-0x16(%rax), %ecx
     cd6:      	movl	$0x0, %ebx
     cdb:      	cmpl	$0x2, %ecx
     cde:      	jb	0x126c <generic_retkprobe_filter_arg+0x126c>
     ce4:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
     ce9:      	cmpl	$0xf, %eax
     cec:      	jle	0xf5c <generic_retkprobe_filter_arg+0xf5c>
     cf2:      	cmpl	$0x11, %eax
     cf5:      	jg	0x1259 <generic_retkprobe_filter_arg+0x1259>
     cfb:      	cmpl	$0x10, %eax
     cfe:      	je	0x126c <generic_retkprobe_filter_arg+0x126c>
     d04:      	movl	$0x0, %ebx
     d09:      	cmpl	$0x11, %eax
     d0c:      	jne	0x260 <generic_retkprobe_filter_arg+0x260>
     d12:      	movzwl	0x24(%rsi), %ebx
     d16:      	jmp	0x1a17 <generic_retkprobe_filter_arg+0x1a17>
     d1b:      	cmpl	$0x1b, %eax
     d1e:      	jg	0x12ac <generic_retkprobe_filter_arg+0x12ac>
     d24:      	cmpl	$0x18, %eax
     d27:      	je	0x12e6 <generic_retkprobe_filter_arg+0x12e6>
     d2d:      	movl	$0x0, %ebx
     d32:      	cmpl	$0x19, %eax
     d35:      	je	0x12dc <generic_retkprobe_filter_arg+0x12dc>
     d3b:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
     d40:      	leal	-0x1f(%rax), %edx
     d43:      	cmpl	$0x2, %edx
     d46:      	jae	0x176f <generic_retkprobe_filter_arg+0x176f>
     d4c:      	cmpl	$0x1f, %eax
     d4f:      	jne	0xf30 <generic_retkprobe_filter_arg+0xf30>
     d55:      	movq	0x10(%r15), %rsi
     d59:      	movq	0x18(%r15), %rdx
     d5d:      	cmpl	$0xa, %ecx
     d60:      	je	0xd6b <generic_retkprobe_filter_arg+0xd6b>
     d62:      	cmpl	$0xc, %ecx
     d65:      	jne	0x1979 <generic_retkprobe_filter_arg+0x1979>
     d6b:      	movq	(%rbp), %rax
     d6f:      	cmpq	%rax, %rsi
     d72:      	jg	0x198b <generic_retkprobe_filter_arg+0x198b>
     d78:      	cmpq	%rdx, %rax
     d7b:      	jle	0x276 <generic_retkprobe_filter_arg+0x276>
     d81:      	jmp	0x198b <generic_retkprobe_filter_arg+0x198b>
     d86:      	cmpl	$0x21, %eax
     d89:      	je	0x13a7 <generic_retkprobe_filter_arg+0x13a7>
     d8f:      	movl	$0x0, %ebx
     d94:      	cmpl	$0x22, %eax
     d97:      	jne	0x2c6b <generic_retkprobe_filter_arg+0x2c6b>
     d9d:      	movq	%rsi, 0x20(%rsp)
     da2:      	xorl	%ebx, %ebx
     da4:      	xorl	%r12d, %r12d
     da7:      	movl	0x10(%r15,%rbx,4), %eax
     dac:      	movl	%eax, 0x38(%rsp)
     db0:      	movl	$0x1, %eax
     db5:      	leaq	0x38(%rsp), %rsi
     dba:      	movq	(%rip), %rdi            # 0xdc1 <generic_retkprobe_filter_arg+0xdc1>
     dc1:      	callq	*%rax
     dc3:      	testq	%rax, %rax
     dc6:      	je	0x211a <generic_retkprobe_filter_arg+0x211a>
     dcc:      	testl	%ebp, %ebp
     dce:      	movq	0x10(%rsp), %r11
     dd3:      	je	0xe44 <generic_retkprobe_filter_arg+0xe44>
     dd5:      	movq	0x20(%rsp), %rdx
     dda:      	xorl	%ecx, %ecx
     ddc:      	jmp	0xde9 <generic_retkprobe_filter_arg+0xde9>
     dde:      	incq	%rcx
     de1:      	incq	%rdx
     de4:      	cmpq	%rbp, %rcx
     de7:      	je	0xe44 <generic_retkprobe_filter_arg+0xe44>
     de9:      	xorl	%esi, %esi
     deb:      	nopl	(%rax,%rax)
     df0:      	leaq	(%rcx,%rsi), %rdi
     df4:      	cmpq	%rbp, %rdi
     df7:      	jae	0xdde <generic_retkprobe_filter_arg+0xdde>
     df9:      	movsbl	(%rax,%rsi), %edi
     dfd:      	testl	%edi, %edi
     dff:      	je	0xe3c <generic_retkprobe_filter_arg+0xe3c>
     e01:      	movsbl	(%rdx,%rsi), %r9d
     e06:      	leal	-0x41(%r9), %r10d
     e0a:      	movl	%r9d, %r8d
     e0d:      	orl	$0x20, %r8d
     e11:      	cmpl	$0x1a, %r10d
     e15:      	cmovael	%r9d, %r8d
     e19:      	leal	-0x41(%rdi), %r10d
     e1d:      	movl	%edi, %r9d
     e20:      	orl	$0x20, %r9d
     e24:      	cmpl	$0x1a, %r10d
     e28:      	cmovael	%edi, %r9d
     e2c:      	cmpq	$0x62, %rsi
     e30:      	ja	0xdde <generic_retkprobe_filter_arg+0xdde>
     e32:      	incq	%rsi
     e35:      	cmpl	%r9d, %r8d
     e38:      	je	0xdf0 <generic_retkprobe_filter_arg+0xdf0>
     e3a:      	jmp	0xdde <generic_retkprobe_filter_arg+0xdde>
     e3c:      	testl	%ecx, %ecx
     e3e:      	jns	0x23f8 <generic_retkprobe_filter_arg+0x23f8>
     e44:      	leal	0xc(%r12), %eax
     e49:      	cmpl	0x8(%r15), %eax
     e4d:      	jae	0xe60 <generic_retkprobe_filter_arg+0xe60>
     e4f:      	addl	$0x4, %r12d
     e53:      	incq	%rbx
     e56:      	cmpq	$0x64, %rbx
     e5a:      	jne	0xda7 <generic_retkprobe_filter_arg+0xda7>
     e60:      	xorl	%ebx, %ebx
     e62:      	jmp	0x23fd <generic_retkprobe_filter_arg+0x23fd>
     e67:      	movq	%rsi, 0x20(%rsp)
     e6c:      	movl	0x10(%r15), %eax
     e70:      	movl	%eax, 0x38(%rsp)
     e74:      	movl	$0x0, 0x70(%rsp)
     e7c:      	movl	$0x1, %eax
     e81:      	leaq	0x38(%rsp), %rsi
     e86:      	movq	(%rip), %rdi            # 0xe8d <generic_retkprobe_filter_arg+0xe8d>
     e8d:      	callq	*%rax
     e8f:      	testl	%ebp, %ebp
     e91:      	je	0x2c5b <generic_retkprobe_filter_arg+0x2c5b>
     e97:      	movl	$0x0, %ebx
     e9c:      	testq	%rax, %rax
     e9f:      	je	0x2c5d <generic_retkprobe_filter_arg+0x2c5d>
     ea5:      	movq	%rax, 0x18(%rsp)
     eaa:      	movl	$0x1, %eax
     eaf:      	movq	0x30(%rsp), %rsi
     eb4:      	movq	(%rip), %rdi            # 0xebb <generic_retkprobe_filter_arg+0xebb>
     ebb:      	callq	*%rax
     ebd:      	testq	%rax, %rax
     ec0:      	je	0x2c5b <generic_retkprobe_filter_arg+0x2c5b>
     ec6:      	cmpl	$0xff, %ebp
     ecc:      	movl	$0xff, %ecx
     ed1:      	cmovael	%ecx, %ebp
     ed4:      	leal	(,%rbp,8), %ecx
     edb:      	movl	%ecx, (%rax)
     edd:      	movq	%rax, %rdi
     ee0:      	addq	$0x4, %rdi
     ee4:      	movq	%rax, %rbx
     ee7:      	movl	$0x4, %eax
     eec:      	movq	0x20(%rsp), %rdx
     ef1:      	movl	%ebp, %esi
     ef3:      	callq	*%rax
     ef5:      	movl	$0x1, %eax
     efa:      	movq	0x18(%rsp), %rdi
     eff:      	movq	%rbx, %rsi
     f02:      	jmp	0x2c4f <generic_retkprobe_filter_arg+0x2c4f>
     f07:      	movl	$0x0, 0x70(%rsp)
     f0f:      	cmpl	$0x1fe, %ebp            # imm = 0x1FE
     f15:      	jbe	0x1452 <generic_retkprobe_filter_arg+0x1452>
     f1b:      	xorl	%ebx, %ebx
     f1d:      	movl	0x4(%r15), %eax
     f21:      	cmpq	$0x25, %rax
     f25:      	jbe	0x2c79 <generic_retkprobe_filter_arg+0x2c79>
     f2b:      	jmp	0x265 <generic_retkprobe_filter_arg+0x265>
     f30:      	movq	0x10(%r15), %rsi
     f34:      	movq	0x18(%r15), %rax
     f38:      	cmpl	$0xc, %ecx
     f3b:      	je	0xf46 <generic_retkprobe_filter_arg+0xf46>
     f3d:      	cmpl	$0xa, %ecx
     f40:      	jne	0x19c9 <generic_retkprobe_filter_arg+0x19c9>
     f46:      	movq	(%rbp), %rdx
     f4a:      	cmpq	%rdx, %rsi
     f4d:      	setle	%sil
     f51:      	cmpq	%rax, %rdx
     f54:      	setle	%al
     f57:      	jmp	0x19da <generic_retkprobe_filter_arg+0x19da>
     f5c:      	cmpl	$0xd, %eax
     f5f:      	je	0x12e6 <generic_retkprobe_filter_arg+0x12e6>
     f65:      	cmpl	$0xe, %eax
     f68:      	je	0x12dc <generic_retkprobe_filter_arg+0x12dc>
     f6e:      	movl	$0x0, %ebx
     f73:      	cmpl	$0xf, %eax
     f76:      	je	0x1273 <generic_retkprobe_filter_arg+0x1273>
     f7c:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
     f81:      	cmpl	$0x20, %eax
     f84:      	movq	%rsi, 0x20(%rsp)
     f89:      	jg	0x14ef <generic_retkprobe_filter_arg+0x14ef>
     f8f:      	cmpl	$0x1a, %eax
     f92:      	je	0x16c0 <generic_retkprobe_filter_arg+0x16c0>
     f98:      	movl	$0x0, %ebx
     f9d:      	cmpl	$0x1b, %eax
     fa0:      	jne	0x2ef2 <generic_retkprobe_filter_arg+0x2ef2>
     fa6:      	movl	0x10(%r15), %eax
     faa:      	movl	%eax, 0x38(%rsp)
     fae:      	movl	$0x0, 0x70(%rsp)
     fb6:      	movl	$0x1, %eax
     fbb:      	leaq	0x38(%rsp), %rsi
     fc0:      	movq	(%rip), %rdi            # 0xfc7 <generic_retkprobe_filter_arg+0xfc7>
     fc7:      	callq	*%rax
     fc9:      	testl	%ebp, %ebp
     fcb:      	je	0x2ee2 <generic_retkprobe_filter_arg+0x2ee2>
     fd1:      	movq	%rax, %r12
     fd4:      	movl	$0x0, %ebx
     fd9:      	testq	%rax, %rax
     fdc:      	je	0x2ee4 <generic_retkprobe_filter_arg+0x2ee4>
     fe2:      	movl	$0x1, %eax
     fe7:      	movq	0x30(%rsp), %rsi
     fec:      	movq	(%rip), %rdi            # 0xff3 <generic_retkprobe_filter_arg+0xff3>
     ff3:      	callq	*%rax
     ff5:      	testq	%rax, %rax
     ff8:      	je	0x2ee2 <generic_retkprobe_filter_arg+0x2ee2>
     ffe:      	movq	%rax, %rdi
    1001:      	movq	%r12, 0x18(%rsp)
    1006:      	cmpl	$0x7f, %ebp
    1009:      	movl	$0x7f, %eax
    100e:      	cmovbl	%ebp, %eax
    1011:      	shll	$0x3, %eax
    1014:      	movl	%eax, (%rdi)
    1016:      	movq	%rbp, %rax
    1019:      	negq	%rax
    101c:      	movl	$0x3, %ecx
    1021:      	subq	%rbp, %rcx
    1024:      	leal	-0x4(%rbp), %edx
    1027:      	movq	%rdi, 0x60(%rsp)
    102c:      	addq	$0x7, %rdi
    1030:      	movl	$0x2, %r8d
    1036:      	subq	%rbp, %r8
    1039:      	leal	-0x3(%rbp), %r9d
    103d:      	movl	$0x1, %r10d
    1043:      	subq	%rbp, %r10
    1046:      	leal	-0x2(%rbp), %r11d
    104a:      	decl	%ebp
    104c:      	xorl	%ebx, %ebx
    104e:      	movq	0x20(%rsp), %rsi
    1053:      	leal	(%rbx,%rbp), %r12d
    1057:      	andl	$0xfff, %r12d           # imm = 0xFFF
    105e:      	movzbl	(%rsi,%r12), %r12d
    1063:      	movb	%r12b, -0x3(%rdi)
    1067:      	cmpq	%rbx, %r10
    106a:      	je	0x10c4 <generic_retkprobe_filter_arg+0x10c4>
    106c:      	leal	(%r11,%rbx), %r12d
    1070:      	andl	$0xfff, %r12d           # imm = 0xFFF
    1077:      	movzbl	(%rsi,%r12), %r12d
    107c:      	movb	%r12b, -0x2(%rdi)
    1080:      	cmpq	%rbx, %r8
    1083:      	je	0x10c4 <generic_retkprobe_filter_arg+0x10c4>
    1085:      	leal	(%r9,%rbx), %r12d
    1089:      	andl	$0xfff, %r12d           # imm = 0xFFF
    1090:      	movzbl	(%rsi,%r12), %r12d
    1095:      	movb	%r12b, -0x1(%rdi)
    1099:      	cmpq	%rbx, %rcx
    109c:      	je	0x10c4 <generic_retkprobe_filter_arg+0x10c4>
    109e:      	cmpq	$-0x7c, %rbx
    10a2:      	je	0x10c4 <generic_retkprobe_filter_arg+0x10c4>
    10a4:      	leal	(%rdx,%rbx), %r12d
    10a8:      	andl	$0xfff, %r12d           # imm = 0xFFF
    10af:      	movzbl	(%rsi,%r12), %r12d
    10b4:      	movb	%r12b, (%rdi)
    10b7:      	addq	$-0x4, %rbx
    10bb:      	addq	$0x4, %rdi
    10bf:      	cmpq	%rbx, %rax
    10c2:      	jne	0x1053 <generic_retkprobe_filter_arg+0x1053>
    10c4:      	movl	$0x1, %eax
    10c9:      	movq	0x18(%rsp), %rdi
    10ce:      	movq	0x60(%rsp), %rsi
    10d3:      	jmp	0x2ed6 <generic_retkprobe_filter_arg+0x2ed6>
    10d8:      	cmpl	$0xc, %eax
    10db:      	jne	0x2062 <generic_retkprobe_filter_arg+0x2062>
    10e1:      	testl	%edx, (%rbp)
    10e4:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
    10ea:      	jmp	0x2062 <generic_retkprobe_filter_arg+0x2062>
    10ef:      	movl	$0xc00, %edx            # imm = 0xC00
    10f4:      	btq	%rcx, %rdx
    10f8:      	jb	0x15c2 <generic_retkprobe_filter_arg+0x15c2>
    10fe:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
    1108:      	btq	%rcx, %rdx
    110c:      	jae	0xb8 <generic_retkprobe_filter_arg+0xb8>
    1112:      	cmpl	$0x1f, %eax
    1115:      	jne	0x1c93 <generic_retkprobe_filter_arg+0x1c93>
    111b:      	movzbl	(%rbp), %eax
    111f:      	jmp	0x1151 <generic_retkprobe_filter_arg+0x1151>
    1121:      	movl	$0xc00, %edx            # imm = 0xC00
    1126:      	btq	%rcx, %rdx
    112a:      	jb	0x15ff <generic_retkprobe_filter_arg+0x15ff>
    1130:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
    113a:      	btq	%rcx, %rdx
    113e:      	jae	0xb8 <generic_retkprobe_filter_arg+0xb8>
    1144:      	cmpl	$0x1f, %eax
    1147:      	jne	0x1c9d <generic_retkprobe_filter_arg+0x1c9d>
    114d:      	movzwl	(%rbp), %eax
    1151:      	cmpl	%eax, 0x10(%r15)
    1155:      	ja	0x1161 <generic_retkprobe_filter_arg+0x1161>
    1157:      	cmpl	%eax, 0x14(%r15)
    115b:      	jae	0x276 <generic_retkprobe_filter_arg+0x276>
    1161:      	movl	0x8(%r15), %ecx
    1165:      	cmpl	$0x11, %ecx
    1168:      	jb	0xb8 <generic_retkprobe_filter_arg+0xb8>
    116e:      	cmpl	%eax, 0x18(%r15)
    1172:      	ja	0x117e <generic_retkprobe_filter_arg+0x117e>
    1174:      	cmpl	%eax, 0x1c(%r15)
    1178:      	jae	0x276 <generic_retkprobe_filter_arg+0x276>
    117e:      	cmpl	$0x19, %ecx
    1181:      	jb	0xb8 <generic_retkprobe_filter_arg+0xb8>
    1187:      	cmpl	%eax, 0x20(%r15)
    118b:      	ja	0x1197 <generic_retkprobe_filter_arg+0x1197>
    118d:      	cmpl	%eax, 0x24(%r15)
    1191:      	jae	0x276 <generic_retkprobe_filter_arg+0x276>
    1197:      	cmpl	$0x21, %ecx
    119a:      	jb	0xb8 <generic_retkprobe_filter_arg+0xb8>
    11a0:      	cmpl	%eax, 0x28(%r15)
    11a4:      	ja	0xb8 <generic_retkprobe_filter_arg+0xb8>
    11aa:      	cmpl	%eax, 0x2c(%r15)
    11ae:      	jae	0x276 <generic_retkprobe_filter_arg+0x276>
    11b4:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
    11b9:      	cmpl	$0xc, %ecx
    11bc:      	je	0x11c7 <generic_retkprobe_filter_arg+0x11c7>
    11be:      	cmpl	$0xa, %ecx
    11c1:      	jne	0x1a9a <generic_retkprobe_filter_arg+0x1a9a>
    11c7:      	cmpq	%rdx, (%rbp)
    11cb:      	jg	0x276 <generic_retkprobe_filter_arg+0x276>
    11d1:      	jmp	0x1ab0 <generic_retkprobe_filter_arg+0x1ab0>
    11d6:      	movzwl	%bp, %eax
    11d9:      	cmpl	$0x90, %eax
    11de:      	ja	0x17db <generic_retkprobe_filter_arg+0x17db>
    11e4:      	testw	%bp, %bp
    11e7:      	je	0x11f9 <generic_retkprobe_filter_arg+0x11f9>
    11e9:      	movl	%ebp, %eax
    11eb:      	movl	$0x18, %ecx
    11f0:      	cltd
    11f1:      	idivl	%ecx
    11f3:      	movl	%ebp, %esi
    11f5:      	testl	%edx, %edx
    11f7:      	je	0x121b <generic_retkprobe_filter_arg+0x121b>
    11f9:      	movl	%ebp, %eax
    11fb:      	movl	$0x18, %ecx
    1200:      	cltd
    1201:      	idivl	%ecx
    1203:      	shll	$0x3, %eax
    1206:      	leal	(%rax,%rax,2), %eax
    1209:      	addl	$0x18, %eax
    120c:      	movzwl	%ax, %esi
    120f:      	cmpl	$0x90, %esi
    1215:      	ja	0x17ef <generic_retkprobe_filter_arg+0x17ef>
    121b:      	movl	%esi, %eax
    121d:      	cltd
    121e:      	idivl	%ecx
    1220:      	decl	%eax
    1222:      	jmp	0x1800 <generic_retkprobe_filter_arg+0x1800>
    1227:      	movl	0x10(%r15), %esi
    122b:      	movl	0x14(%r15), %eax
    122f:      	cmpl	$0xc, %ecx
    1232:      	ja	0x1f0f <generic_retkprobe_filter_arg+0x1f0f>
    1238:      	movl	$0x1402, %edx           # imm = 0x1402
    123d:      	btl	%ecx, %edx
    1240:      	jae	0x1f0f <generic_retkprobe_filter_arg+0x1f0f>
    1246:      	movl	(%rbp), %edx
    1249:      	cmpl	%edx, %esi
    124b:      	setle	%sil
    124f:      	cmpl	%eax, %edx
    1251:      	setle	%al
    1254:      	jmp	0x1f1d <generic_retkprobe_filter_arg+0x1f1d>
    1259:      	cmpl	$0x12, %eax
    125c:      	je	0x1273 <generic_retkprobe_filter_arg+0x1273>
    125e:      	movl	$0x0, %ebx
    1263:      	cmpl	$0x13, %eax
    1266:      	jne	0x260 <generic_retkprobe_filter_arg+0x260>
    126c:      	movzwl	0x22(%rsi), %r12d
    1271:      	jmp	0x1278 <generic_retkprobe_filter_arg+0x1278>
    1273:      	movzwl	0x20(%rsi), %r12d
    1278:      	xorl	%edx, %edx
    127a:      	xorl	%ebp, %ebp
    127c:      	xorl	%r8d, %r8d
    127f:      	xorl	%ebx, %ebx
    1281:      	cmpl	$0x11, %eax
    1284:      	jg	0x12fe <generic_retkprobe_filter_arg+0x12fe>
    1286:      	leal	-0xd(%rax), %ecx
    1289:      	cmpl	$0x2, %ecx
    128c:      	jb	0x1331 <generic_retkprobe_filter_arg+0x1331>
    1292:      	leal	-0xf(%rax), %ecx
    1295:      	cmpl	$0x2, %ecx
    1298:      	jb	0x14af <generic_retkprobe_filter_arg+0x14af>
    129e:      	cmpl	$0x11, %eax
    12a1:      	je	0x1a17 <generic_retkprobe_filter_arg+0x1a17>
    12a7:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    12ac:      	cmpl	$0x1c, %eax
    12af:      	je	0x1a13 <generic_retkprobe_filter_arg+0x1a13>
    12b5:      	movl	$0x0, %ebx
    12ba:      	cmpl	$0x1d, %eax
    12bd:      	jne	0x260 <generic_retkprobe_filter_arg+0x260>
    12c3:      	cmpl	$0x7, %ecx
    12c6:      	jne	0x1ff2 <generic_retkprobe_filter_arg+0x1ff2>
    12cc:      	testq	%rdx, %rdx
    12cf:      	jne	0x1ffe <generic_retkprobe_filter_arg+0x1ffe>
    12d5:      	xorl	%ebx, %ebx
    12d7:      	jmp	0x2010 <generic_retkprobe_filter_arg+0x2010>
    12dc:      	movq	0x10(%rsi), %rdx
    12e0:      	movq	0x18(%rsi), %r8
    12e4:      	jmp	0x12ed <generic_retkprobe_filter_arg+0x12ed>
    12e6:      	movq	(%rsi), %rdx
    12e9:      	movq	0x8(%rsi), %r8
    12ed:      	movq	%rdx, %rbp
    12f0:      	shrq	$0x20, %rbp
    12f4:      	xorl	%r12d, %r12d
    12f7:      	xorl	%ebx, %ebx
    12f9:      	cmpl	$0x11, %eax
    12fc:      	jle	0x1286 <generic_retkprobe_filter_arg+0x1286>
    12fe:      	cmpl	$0x19, %eax
    1301:      	ja	0x14a3 <generic_retkprobe_filter_arg+0x14a3>
    1307:      	movl	$0x500000, %ecx         # imm = 0x500000
    130c:      	btl	%eax, %ecx
    130f:      	jb	0x17b5 <generic_retkprobe_filter_arg+0x17b5>
    1315:      	movl	$0xa00000, %ecx         # imm = 0xA00000
    131a:      	btl	%eax, %ecx
    131d:      	jb	0x17c8 <generic_retkprobe_filter_arg+0x17c8>
    1323:      	movl	$0x3000000, %ecx        # imm = 0x3000000
    1328:      	btl	%eax, %ecx
    132b:      	jae	0x14a3 <generic_retkprobe_filter_arg+0x14a3>
    1331:      	movzwl	0x26(%rsi), %eax
    1335:      	cmpl	$0xa, %eax
    1338:      	je	0x18e1 <generic_retkprobe_filter_arg+0x18e1>
    133e:      	cmpl	$0x2, %eax
    1341:      	jne	0x196f <generic_retkprobe_filter_arg+0x196f>
    1347:      	movq	%rdx, %rbx
    134a:      	movl	0x10(%r15), %eax
    134e:      	movl	%eax, 0x2c(%rsp)
    1352:      	movl	$0x1, %eax
    1357:      	leaq	0x2c(%rsp), %rsi
    135c:      	movq	(%rip), %rdi            # 0x1363 <generic_retkprobe_filter_arg+0x1363>
    1363:      	callq	*%rax
    1365:      	testq	%rax, %rax
    1368:      	je	0x1b60 <generic_retkprobe_filter_arg+0x1b60>
    136e:      	movq	%rax, %rdi
    1371:      	movl	$0x20, 0x70(%rsp)
    1379:      	movl	%ebx, 0x74(%rsp)
    137d:      	jmp	0x192f <generic_retkprobe_filter_arg+0x192f>
    1382:      	cmpl	$0xc, %ecx
    1385:      	ja	0x204e <generic_retkprobe_filter_arg+0x204e>
    138b:      	movl	$0x1402, %esi           # imm = 0x1402
    1390:      	btl	%ecx, %esi
    1393:      	jae	0x204e <generic_retkprobe_filter_arg+0x204e>
    1399:      	cmpl	%edx, (%rbp)
    139c:      	jg	0x276 <generic_retkprobe_filter_arg+0x276>
    13a2:      	jmp	0x2062 <generic_retkprobe_filter_arg+0x2062>
    13a7:      	movq	%rsi, 0x20(%rsp)
    13ac:      	xorl	%ebx, %ebx
    13ae:      	xorl	%r12d, %r12d
    13b1:      	movl	0x10(%r15,%rbx,4), %eax
    13b6:      	movl	%eax, 0x38(%rsp)
    13ba:      	movl	$0x1, %eax
    13bf:      	leaq	0x38(%rsp), %rsi
    13c4:      	movq	(%rip), %rdi            # 0x13cb <generic_retkprobe_filter_arg+0x13cb>
    13cb:      	callq	*%rax
    13cd:      	testq	%rax, %rax
    13d0:      	je	0x2109 <generic_retkprobe_filter_arg+0x2109>
    13d6:      	testl	%ebp, %ebp
    13d8:      	movq	0x8(%rsp), %r9
    13dd:      	movq	0x10(%rsp), %r11
    13e2:      	je	0x142f <generic_retkprobe_filter_arg+0x142f>
    13e4:      	movq	0x20(%rsp), %rdx
    13e9:      	xorl	%ecx, %ecx
    13eb:      	jmp	0x13f8 <generic_retkprobe_filter_arg+0x13f8>
    13ed:      	incq	%rcx
    13f0:      	incq	%rdx
    13f3:      	cmpq	%rbp, %rcx
    13f6:      	je	0x142f <generic_retkprobe_filter_arg+0x142f>
    13f8:      	xorl	%esi, %esi
    13fa:      	nopw	(%rax,%rax)
    1400:      	leaq	(%rcx,%rsi), %rdi
    1404:      	cmpq	%rbp, %rdi
    1407:      	jae	0x13ed <generic_retkprobe_filter_arg+0x13ed>
    1409:      	movzbl	(%rax,%rsi), %edi
    140d:      	testb	%dil, %dil
    1410:      	je	0x1427 <generic_retkprobe_filter_arg+0x1427>
    1412:      	cmpq	$0x62, %rsi
    1416:      	ja	0x13ed <generic_retkprobe_filter_arg+0x13ed>
    1418:      	leaq	0x1(%rsi), %r8
    141c:      	cmpb	%dil, (%rdx,%rsi)
    1420:      	movq	%r8, %rsi
    1423:      	je	0x1400 <generic_retkprobe_filter_arg+0x1400>
    1425:      	jmp	0x13ed <generic_retkprobe_filter_arg+0x13ed>
    1427:      	testl	%ecx, %ecx
    1429:      	jns	0x23d7 <generic_retkprobe_filter_arg+0x23d7>
    142f:      	leal	0xc(%r12), %eax
    1434:      	cmpl	0x8(%r15), %eax
    1438:      	jae	0x144b <generic_retkprobe_filter_arg+0x144b>
    143a:      	addl	$0x4, %r12d
    143e:      	incq	%rbx
    1441:      	cmpq	$0x64, %rbx
    1445:      	jne	0x13b1 <generic_retkprobe_filter_arg+0x13b1>
    144b:      	xorl	%ebx, %ebx
    144d:      	jmp	0x23dc <generic_retkprobe_filter_arg+0x23dc>
    1452:      	movzwl	%bp, %eax
    1455:      	cmpl	$0x90, %eax
    145a:      	ja	0x1b6f <generic_retkprobe_filter_arg+0x1b6f>
    1460:      	testw	%bp, %bp
    1463:      	je	0x1475 <generic_retkprobe_filter_arg+0x1475>
    1465:      	movl	%ebp, %eax
    1467:      	movl	$0x18, %ecx
    146c:      	cltd
    146d:      	idivl	%ecx
    146f:      	movl	%ebp, %edi
    1471:      	testl	%edx, %edx
    1473:      	je	0x1497 <generic_retkprobe_filter_arg+0x1497>
    1475:      	movl	%ebp, %eax
    1477:      	movl	$0x18, %ecx
    147c:      	cltd
    147d:      	idivl	%ecx
    147f:      	shll	$0x3, %eax
    1482:      	leal	(%rax,%rax,2), %eax
    1485:      	addl	$0x18, %eax
    1488:      	movzwl	%ax, %edi
    148b:      	cmpl	$0x90, %edi
    1491:      	ja	0x1b83 <generic_retkprobe_filter_arg+0x1b83>
    1497:      	movl	%edi, %eax
    1499:      	cltd
    149a:      	idivl	%ecx
    149c:      	decl	%eax
    149e:      	jmp	0x1b94 <generic_retkprobe_filter_arg+0x1b94>
    14a3:      	addl	$-0x12, %eax
    14a6:      	cmpl	$0x2, %eax
    14a9:      	jae	0x260 <generic_retkprobe_filter_arg+0x260>
    14af:      	movzbl	0x10(%r15), %eax
    14b4:      	movl	%eax, 0x2c(%rsp)
    14b8:      	movl	$0x1, %eax
    14bd:      	movq	(%rip), %rdi            # 0x14c4 <generic_retkprobe_filter_arg+0x14c4>
    14c4:      	leaq	0x2c(%rsp), %rsi
    14c9:      	callq	*%rax
    14cb:      	testq	%rax, %rax
    14ce:      	je	0x250 <generic_retkprobe_filter_arg+0x250>
    14d4:      	movq	%rax, %rdi
    14d7:      	movzwl	%r12w, %eax
    14db:      	movq	%rax, 0x70(%rsp)
    14e0:      	movl	$0x1, %eax
    14e5:      	movq	0x30(%rsp), %rsi
    14ea:      	jmp	0x1a51 <generic_retkprobe_filter_arg+0x1a51>
    14ef:      	cmpl	$0x21, %eax
    14f2:      	je	0x1d15 <generic_retkprobe_filter_arg+0x1d15>
    14f8:      	movl	$0x0, %ebx
    14fd:      	cmpl	$0x22, %eax
    1500:      	jne	0x2ef2 <generic_retkprobe_filter_arg+0x2ef2>
    1506:      	movl	$0x10, %r12d
    150c:      	movl	(%r15,%r12), %eax
    1510:      	movl	%eax, 0x38(%rsp)
    1514:      	movl	$0x1, %eax
    1519:      	leaq	0x38(%rsp), %rsi
    151e:      	movq	(%rip), %rdi            # 0x1525 <generic_retkprobe_filter_arg+0x1525>
    1525:      	callq	*%rax
    1527:      	testq	%rax, %rax
    152a:      	je	0x2ee2 <generic_retkprobe_filter_arg+0x2ee2>
    1530:      	movq	0x20(%rsp), %rdi
    1535:      	movq	%rax, %rsi
    1538:      	movq	%rbp, %rdx
    153b:      	callq	0x1540 <generic_retkprobe_filter_arg+0x1540>
    1540:      	testl	%eax, %eax
    1542:      	jns	0x26e8 <generic_retkprobe_filter_arg+0x26e8>
    1548:      	addq	$0x4, %r12
    154c:      	leal	-0x8(%r12), %eax
    1551:      	cmpl	0x8(%r15), %eax
    1555:      	movq	(%rsp), %rdi
    1559:      	movq	0x8(%rsp), %r9
    155e:      	movq	0x10(%rsp), %r11
    1563:      	jae	0x1768 <generic_retkprobe_filter_arg+0x1768>
    1569:      	movl	$0x0, %ebx
    156e:      	cmpq	$0x1a0, %r12            # imm = 0x1A0
    1575:      	jne	0x150c <generic_retkprobe_filter_arg+0x150c>
    1577:      	jmp	0x2ef2 <generic_retkprobe_filter_arg+0x2ef2>
    157c:      	cmpl	$0x1, %eax
    157f:      	je	0x1e17 <generic_retkprobe_filter_arg+0x1e17>
    1585:      	cmpl	$0x2, %eax
    1588:      	jne	0x1e23 <generic_retkprobe_filter_arg+0x1e23>
    158e:      	movzbl	(%rbp), %edx
    1592:      	cmpl	%edx, %ecx
    1594:      	ja	0x276 <generic_retkprobe_filter_arg+0x276>
    159a:      	jmp	0x1e23 <generic_retkprobe_filter_arg+0x1e23>
    159f:      	cmpl	$0x1, %eax
    15a2:      	je	0x1e5a <generic_retkprobe_filter_arg+0x1e5a>
    15a8:      	cmpl	$0x2, %eax
    15ab:      	jne	0x1e66 <generic_retkprobe_filter_arg+0x1e66>
    15b1:      	movzwl	(%rbp), %edx
    15b5:      	cmpl	%edx, %ecx
    15b7:      	ja	0x276 <generic_retkprobe_filter_arg+0x276>
    15bd:      	jmp	0x1e66 <generic_retkprobe_filter_arg+0x1e66>
    15c2:      	movzbl	0x10(%r15), %eax
    15c7:      	movl	%eax, 0x70(%rsp)
    15cb:      	movl	$0x1, %eax
    15d0:      	movq	0x30(%rsp), %rsi
    15d5:      	movq	(%rip), %rdi            # 0x15dc <generic_retkprobe_filter_arg+0x15dc>
    15dc:      	callq	*%rax
    15de:      	testq	%rax, %rax
    15e1:      	je	0x166d <generic_retkprobe_filter_arg+0x166d>
    15e7:      	movq	%rax, %rdi
    15ea:      	movzbl	(%rbp), %eax
    15ee:      	movq	%rax, 0x38(%rsp)
    15f3:      	movl	$0x1, %eax
    15f8:      	leaq	0x38(%rsp), %rsi
    15fd:      	jmp	0x1636 <generic_retkprobe_filter_arg+0x1636>
    15ff:      	movzbl	0x10(%r15), %eax
    1604:      	movl	%eax, 0x70(%rsp)
    1608:      	movl	$0x1, %eax
    160d:      	movq	0x30(%rsp), %rsi
    1612:      	movq	(%rip), %rdi            # 0x1619 <generic_retkprobe_filter_arg+0x1619>
    1619:      	callq	*%rax
    161b:      	testq	%rax, %rax
    161e:      	je	0x166d <generic_retkprobe_filter_arg+0x166d>
    1620:      	movq	%rax, %rdi
    1623:      	movzwl	(%rbp), %eax
    1627:      	movq	%rax, 0x38(%rsp)
    162c:      	movl	$0x1, %eax
    1631:      	leaq	0x38(%rsp), %rsi
    1636:      	callq	*%rax
    1638:      	movl	0x4(%r15), %edx
    163c:      	xorl	%ecx, %ecx
    163e:      	cmpl	$0x1d, %edx
    1641:      	ja	0x263d <generic_retkprobe_filter_arg+0x263d>
    1647:      	movl	$0x30038400, %esi       # imm = 0x30038400
    164c:      	btl	%edx, %esi
    164f:      	movq	(%rsp), %rdi
    1653:      	movq	0x8(%rsp), %r9
    1658:      	movq	0x10(%rsp), %r11
    165d:      	jae	0x1682 <generic_retkprobe_filter_arg+0x1682>
    165f:      	testq	%rax, %rax
    1662:      	setne	%cl
    1665:      	movzbl	%cl, %ebx
    1668:      	jmp	0x265 <generic_retkprobe_filter_arg+0x265>
    166d:      	xorl	%ebx, %ebx
    166f:      	movq	(%rsp), %rdi
    1673:      	movq	0x8(%rsp), %r9
    1678:      	movq	0x10(%rsp), %r11
    167d:      	jmp	0x265 <generic_retkprobe_filter_arg+0x265>
    1682:      	movl	$0xc0800, %esi          # imm = 0xC0800
    1687:      	btl	%edx, %esi
    168a:      	jae	0x1692 <generic_retkprobe_filter_arg+0x1692>
    168c:      	testq	%rax, %rax
    168f:      	sete	%cl
    1692:      	movzbl	%cl, %ebx
    1695:      	jmp	0x265 <generic_retkprobe_filter_arg+0x265>
    169a:      	testq	%rax, %rax
    169d:      	sete	%al
    16a0:      	movq	(%rsp), %rdi
    16a4:      	movq	0x8(%rsp), %r9
    16a9:      	movq	0x10(%rsp), %r11
    16ae:      	movzbl	%al, %ebx
    16b1:      	jmp	0x265 <generic_retkprobe_filter_arg+0x265>
    16b6:      	xorl	%eax, %eax
    16b8:      	movzbl	%al, %ebx
    16bb:      	jmp	0x265 <generic_retkprobe_filter_arg+0x265>
    16c0:      	movl	0x10(%r15), %eax
    16c4:      	movl	%eax, 0x38(%rsp)
    16c8:      	movl	$0x0, 0x70(%rsp)
    16d0:      	movl	$0x1, %eax
    16d5:      	leaq	0x38(%rsp), %rsi
    16da:      	movq	(%rip), %rdi            # 0x16e1 <generic_retkprobe_filter_arg+0x16e1>
    16e1:      	callq	*%rax
    16e3:      	testl	%ebp, %ebp
    16e5:      	je	0x2ee2 <generic_retkprobe_filter_arg+0x2ee2>
    16eb:      	movq	%rax, %r12
    16ee:      	movl	$0x0, %ebx
    16f3:      	testq	%rax, %rax
    16f6:      	je	0x2ee4 <generic_retkprobe_filter_arg+0x2ee4>
    16fc:      	movl	$0x1, %eax
    1701:      	movq	0x30(%rsp), %rsi
    1706:      	movq	(%rip), %rdi            # 0x170d <generic_retkprobe_filter_arg+0x170d>
    170d:      	callq	*%rax
    170f:      	testq	%rax, %rax
    1712:      	je	0x2ee2 <generic_retkprobe_filter_arg+0x2ee2>
    1718:      	cmpl	$0xff, %ebp
    171e:      	movl	$0xff, %ecx
    1723:      	cmovael	%ecx, %ebp
    1726:      	leal	(,%rbp,8), %ecx
    172d:      	movl	%ecx, (%rax)
    172f:      	movq	%rax, %rdi
    1732:      	addq	$0x4, %rdi
    1736:      	movq	%rax, %rbx
    1739:      	movl	$0x4, %eax
    173e:      	movq	0x20(%rsp), %rdx
    1743:      	movl	%ebp, %esi
    1745:      	callq	*%rax
    1747:      	movl	$0x1, %eax
    174c:      	movq	%r12, %rdi
    174f:      	jmp	0x2ed3 <generic_retkprobe_filter_arg+0x2ed3>
    1754:      	movl	$0x0, 0x70(%rsp)
    175c:      	cmpl	$0x1fe, %ebp            # imm = 0x1FE
    1762:      	jbe	0x1dc6 <generic_retkprobe_filter_arg+0x1dc6>
    1768:      	xorl	%ebx, %ebx
    176a:      	jmp	0x2ef2 <generic_retkprobe_filter_arg+0x2ef2>
    176f:      	cmpl	$0x1e, %eax
    1772:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    1778:      	movl	0x10(%r15), %eax
    177c:      	andl	$0x7, %eax
    177f:      	movl	%eax, %ecx
    1781:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
    178a:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    1790:      	movq	(%rbp), %rcx
    1794:      	movq	0x5e78(%r14,%rax,8), %rax
    179c:      	andl	$0x7ff, %eax            # imm = 0x7FF
    17a1:      	xorl	%ebx, %ebx
    17a3:      	andnq	0x90(%r14,%rax), %rcx, %rax
    17ad:      	setne	%bl
    17b0:      	jmp	0x265 <generic_retkprobe_filter_arg+0x265>
    17b5:      	movzwl	%r12w, %eax
    17b9:      	xorl	%ebx, %ebx
    17bb:      	cmpl	$0x400, %eax            # imm = 0x400
    17c0:      	setb	%bl
    17c3:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    17c8:      	movzwl	%r12w, %eax
    17cc:      	xorl	%ebx, %ebx
    17ce:      	cmpl	$0x400, %eax            # imm = 0x400
    17d3:      	setae	%bl
    17d6:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    17db:      	cmpl	$0x101, %eax            # imm = 0x101
    17e0:      	movl	$0x100, %esi            # imm = 0x100
    17e5:      	movl	$0x1fe, %eax            # imm = 0x1FE
    17ea:      	cmovael	%eax, %esi
    17ed:      	movl	%esi, %eax
    17ef:      	movzwl	%ax, %ecx
    17f2:      	xorl	%eax, %eax
    17f4:      	cmpl	$0x100, %ecx            # imm = 0x100
    17fa:      	sete	%al
    17fd:      	xorl	$0x7, %eax
    1800:      	movl	%eax, %ecx
    1802:      	andl	$0xf, %ecx
    1805:      	movl	0x10(%r15,%rcx,4), %ecx
    180a:      	cmpl	$-0x1, %ecx
    180d:      	je	0x2aa6 <generic_retkprobe_filter_arg+0x2aa6>
    1813:      	movl	%ecx, 0x90(%rsp)
    181a:      	movq	%rsi, 0x88(%rsp)
    1822:      	movl	%eax, 0x60(%rsp)
    1826:      	movl	$0x1, %eax
    182b:      	movq	(%rip), %rdi            # 0x1832 <generic_retkprobe_filter_arg+0x1832>
    1832:      	movq	0x30(%rsp), %rbx
    1837:      	movq	%rbx, %rsi
    183a:      	callq	*%rax
    183c:      	movq	%rax, 0x18(%rsp)
    1841:      	movl	$0x1, %eax
    1846:      	movq	(%rip), %rdi            # 0x184d <generic_retkprobe_filter_arg+0x184d>
    184d:      	movq	%rbx, %rsi
    1850:      	callq	*%rax
    1852:      	cmpq	$0x0, 0x18(%rsp)
    1858:      	je	0x2aa6 <generic_retkprobe_filter_arg+0x2aa6>
    185e:      	movl	$0x0, %ebx
    1863:      	testq	%rax, %rax
    1866:      	movq	(%rsp), %rdi
    186a:      	movq	0x8(%rsp), %r9
    186f:      	movq	0x10(%rsp), %r11
    1874:      	je	0x2ab6 <generic_retkprobe_filter_arg+0x2ab6>
    187a:      	movq	%rax, 0x98(%rsp)
    1882:      	movq	0x20(%rsp), %rdx
    1887:      	addq	$0x4, %rdx
    188b:      	movl	0x60(%rsp), %ebx
    188f:      	cmpl	$0x5, %ebx
    1892:      	jg	0x216c <generic_retkprobe_filter_arg+0x216c>
    1898:      	movq	0x18(%rsp), %rax
    189d:      	movb	%bpl, (%rax)
    18a0:      	leaq	0x1(%rax), %rdi
    18a4:      	movl	$0x4, %eax
    18a9:      	movl	%ebp, %esi
    18ab:      	callq	*%rax
    18ad:      	movq	0x88(%rsp), %rsi
    18b5:      	subl	%ebp, %esi
    18b7:      	jbe	0x21af <generic_retkprobe_filter_arg+0x21af>
    18bd:      	movq	0x18(%rsp), %rax
    18c2:      	leaq	(%rax,%rbp), %rdi
    18c6:      	incq	%rdi
    18c9:      	andl	$0xfff, %esi            # imm = 0xFFF
    18cf:      	movl	$0x4, %eax
    18d4:      	movq	0x98(%rsp), %rdx
    18dc:      	jmp	0x21ad <generic_retkprobe_filter_arg+0x21ad>
    18e1:      	movq	%r8, %r12
    18e4:      	movq	%rdx, %rbx
    18e7:      	movl	0x14(%r15), %eax
    18eb:      	movl	%eax, 0x2c(%rsp)
    18ef:      	movl	$0x1, %eax
    18f4:      	movq	(%rip), %rdi            # 0x18fb <generic_retkprobe_filter_arg+0x18fb>
    18fb:      	leaq	0x2c(%rsp), %rsi
    1900:      	callq	*%rax
    1902:      	testq	%rax, %rax
    1905:      	je	0x1b60 <generic_retkprobe_filter_arg+0x1b60>
    190b:      	movq	%rax, %rdi
    190e:      	movl	$0x80, 0x70(%rsp)
    1916:      	movl	%ebx, 0x74(%rsp)
    191a:      	movl	%ebp, 0x78(%rsp)
    191e:      	movl	%r12d, 0x7c(%rsp)
    1923:      	shrq	$0x20, %r12
    1927:      	movl	%r12d, 0x80(%rsp)
    192f:      	movl	$0x1, %eax
    1934:      	movq	0x30(%rsp), %rsi
    1939:      	callq	*%rax
    193b:      	movl	0x4(%r15), %ecx
    193f:      	leal	-0x18(%rcx), %edx
    1942:      	cmpl	$0x2, %edx
    1945:      	jb	0x1e9d <generic_retkprobe_filter_arg+0x1e9d>
    194b:      	addl	$-0xd, %ecx
    194e:      	cmpl	$0x1, %ecx
    1951:      	movq	(%rsp), %rdi
    1955:      	movq	0x8(%rsp), %r9
    195a:      	movq	0x10(%rsp), %r11
    195f:      	ja	0x196f <generic_retkprobe_filter_arg+0x196f>
    1961:      	testq	%rax, %rax
    1964:      	setne	%al
    1967:      	movzbl	%al, %ebx
    196a:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    196f:      	xorl	%eax, %eax
    1971:      	movzbl	%al, %ebx
    1974:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    1979:      	movq	(%rbp), %rax
    197d:      	cmpq	%rax, %rsi
    1980:      	ja	0x198b <generic_retkprobe_filter_arg+0x198b>
    1982:      	cmpq	%rdx, %rax
    1985:      	jbe	0x276 <generic_retkprobe_filter_arg+0x276>
    198b:      	movl	0x8(%r15), %edx
    198f:      	cmpl	$0x19, %edx
    1992:      	jb	0xb8 <generic_retkprobe_filter_arg+0xb8>
    1998:      	movq	0x20(%r15), %rdi
    199c:      	movq	0x28(%r15), %rsi
    19a0:      	cmpl	$0xc, %ecx
    19a3:      	je	0x19ae <generic_retkprobe_filter_arg+0x19ae>
    19a5:      	cmpl	$0xa, %ecx
    19a8:      	jne	0x1fa6 <generic_retkprobe_filter_arg+0x1fa6>
    19ae:      	cmpq	%rax, %rdi
    19b1:      	movq	(%rsp), %rdi
    19b5:      	jg	0x1fb8 <generic_retkprobe_filter_arg+0x1fb8>
    19bb:      	cmpq	%rsi, %rax
    19be:      	jle	0x276 <generic_retkprobe_filter_arg+0x276>
    19c4:      	jmp	0x1fb8 <generic_retkprobe_filter_arg+0x1fb8>
    19c9:      	movq	(%rbp), %rdx
    19cd:      	cmpq	%rdx, %rsi
    19d0:      	setbe	%sil
    19d4:      	cmpq	%rax, %rdx
    19d7:      	setbe	%al
    19da:      	andb	%sil, %al
    19dd:      	movl	0x8(%r15), %esi
    19e1:      	cmpl	$0x19, %esi
    19e4:      	jb	0x2af3 <generic_retkprobe_filter_arg+0x2af3>
    19ea:      	movq	0x20(%r15), %r8
    19ee:      	movq	0x28(%r15), %rdi
    19f2:      	cmpl	$0xc, %ecx
    19f5:      	je	0x1a00 <generic_retkprobe_filter_arg+0x1a00>
    19f7:      	cmpl	$0xa, %ecx
    19fa:      	jne	0x1f60 <generic_retkprobe_filter_arg+0x1f60>
    1a00:      	cmpq	%rdx, %r8
    1a03:      	setle	%r8b
    1a07:      	cmpq	%rdi, %rdx
    1a0a:      	setle	%dil
    1a0e:      	jmp	0x1f6e <generic_retkprobe_filter_arg+0x1f6e>
    1a13:      	movzwl	0x26(%rsi), %ebx
    1a17:      	movzbl	0x10(%r15), %eax
    1a1c:      	movl	%eax, 0x2c(%rsp)
    1a20:      	movl	$0x1, %eax
    1a25:      	movq	(%rip), %rdi            # 0x1a2c <generic_retkprobe_filter_arg+0x1a2c>
    1a2c:      	leaq	0x2c(%rsp), %rsi
    1a31:      	callq	*%rax
    1a33:      	testq	%rax, %rax
    1a36:      	je	0x250 <generic_retkprobe_filter_arg+0x250>
    1a3c:      	movq	%rax, %rdi
    1a3f:      	movzwl	%bx, %eax
    1a42:      	movq	%rax, 0x70(%rsp)
    1a47:      	movl	$0x1, %eax
    1a4c:      	movq	0x30(%rsp), %rsi
    1a51:      	callq	*%rax
    1a53:      	movl	0x4(%r15), %edx
    1a57:      	xorl	%ecx, %ecx
    1a59:      	cmpl	$0x1d, %edx
    1a5c:      	ja	0x2653 <generic_retkprobe_filter_arg+0x2653>
    1a62:      	movl	$0x30038400, %esi       # imm = 0x30038400
    1a67:      	btl	%edx, %esi
    1a6a:      	movq	(%rsp), %rdi
    1a6e:      	movq	0x8(%rsp), %r9
    1a73:      	movq	0x10(%rsp), %r11
    1a78:      	jae	0x1a82 <generic_retkprobe_filter_arg+0x1a82>
    1a7a:      	testq	%rax, %rax
    1a7d:      	setne	%cl
    1a80:      	jmp	0x1a92 <generic_retkprobe_filter_arg+0x1a92>
    1a82:      	movl	$0xc0800, %esi          # imm = 0xC0800
    1a87:      	btl	%edx, %esi
    1a8a:      	jae	0x1a92 <generic_retkprobe_filter_arg+0x1a92>
    1a8c:      	testq	%rax, %rax
    1a8f:      	sete	%cl
    1a92:      	movzbl	%cl, %ebx
    1a95:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    1a9a:      	cmpq	%rdx, (%rbp)
    1a9e:      	ja	0x276 <generic_retkprobe_filter_arg+0x276>
    1aa4:      	jmp	0x1ab0 <generic_retkprobe_filter_arg+0x1ab0>
    1aa6:      	cmpq	%rdx, (%rbp)
    1aaa:      	jb	0x276 <generic_retkprobe_filter_arg+0x276>
    1ab0:      	movl	0x8(%r15), %edx
    1ab4:      	cmpl	$0x11, %edx
    1ab7:      	jb	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    1abd:      	movq	0x18(%r15), %rsi
    1ac1:      	cmpl	$0x2, %eax
    1ac4:      	jle	0x1ae1 <generic_retkprobe_filter_arg+0x1ae1>
    1ac6:      	leal	-0x3(%rax), %edi
    1ac9:      	cmpl	$0x2, %edi
    1acc:      	jae	0x1b10 <generic_retkprobe_filter_arg+0x1b10>
    1ace:      	cmpq	%rsi, (%rbp)
    1ad2:      	movq	(%rsp), %rdi
    1ad6:      	jne	0x2591 <generic_retkprobe_filter_arg+0x2591>
    1adc:      	jmp	0x2e81 <generic_retkprobe_filter_arg+0x2e81>
    1ae1:      	cmpl	$0x1, %eax
    1ae4:      	je	0x1c76 <generic_retkprobe_filter_arg+0x1c76>
    1aea:      	cmpl	$0x2, %eax
    1aed:      	jne	0x2591 <generic_retkprobe_filter_arg+0x2591>
    1af3:      	cmpl	$0xc, %ecx
    1af6:      	je	0x1b01 <generic_retkprobe_filter_arg+0x1b01>
    1af8:      	cmpl	$0xa, %ecx
    1afb:      	jne	0x2587 <generic_retkprobe_filter_arg+0x2587>
    1b01:      	cmpq	%rsi, (%rbp)
    1b05:      	jl	0x276 <generic_retkprobe_filter_arg+0x276>
    1b0b:      	jmp	0x2591 <generic_retkprobe_filter_arg+0x2591>
    1b10:      	cmpl	$0xc, %eax
    1b13:      	movq	(%rsp), %rdi
    1b17:      	jne	0x2591 <generic_retkprobe_filter_arg+0x2591>
    1b1d:      	testq	%rsi, (%rbp)
    1b21:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
    1b27:      	jmp	0x2591 <generic_retkprobe_filter_arg+0x2591>
    1b2c:      	cmpl	$0xc, %eax
    1b2f:      	jne	0x1e23 <generic_retkprobe_filter_arg+0x1e23>
    1b35:      	movzbl	(%rbp), %edx
    1b39:      	testl	%edx, %ecx
    1b3b:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
    1b41:      	jmp	0x1e23 <generic_retkprobe_filter_arg+0x1e23>
    1b46:      	cmpl	$0xc, %eax
    1b49:      	jne	0x1e66 <generic_retkprobe_filter_arg+0x1e66>
    1b4f:      	movzwl	(%rbp), %edx
    1b53:      	testl	%edx, %ecx
    1b55:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
    1b5b:      	jmp	0x1e66 <generic_retkprobe_filter_arg+0x1e66>
    1b60:      	movl	0x4(%r15), %eax
    1b64:      	andl	$-0x2, %eax
    1b67:      	cmpl	$0x18, %eax
    1b6a:      	jmp	0x1ea0 <generic_retkprobe_filter_arg+0x1ea0>
    1b6f:      	cmpl	$0x101, %eax            # imm = 0x101
    1b74:      	movl	$0x100, %edi            # imm = 0x100
    1b79:      	movl	$0x1fe, %eax            # imm = 0x1FE
    1b7e:      	cmovael	%eax, %edi
    1b81:      	movl	%edi, %eax
    1b83:      	movzwl	%ax, %ecx
    1b86:      	xorl	%eax, %eax
    1b88:      	cmpl	$0x100, %ecx            # imm = 0x100
    1b8e:      	sete	%al
    1b91:      	xorl	$0x7, %eax
    1b94:      	movl	%eax, %ecx
    1b96:      	andl	$0xf, %ecx
    1b99:      	movl	0x10(%r15,%rcx,4), %ecx
    1b9e:      	cmpl	$-0x1, %ecx
    1ba1:      	je	0x2c5b <generic_retkprobe_filter_arg+0x2c5b>
    1ba7:      	movl	%ecx, 0x90(%rsp)
    1bae:      	movq	%rdi, 0x88(%rsp)
    1bb6:      	movl	%eax, 0x60(%rsp)
    1bba:      	movq	%rsi, 0x20(%rsp)
    1bbf:      	movl	$0x1, %eax
    1bc4:      	movq	(%rip), %rdi            # 0x1bcb <generic_retkprobe_filter_arg+0x1bcb>
    1bcb:      	movq	0x30(%rsp), %rbx
    1bd0:      	movq	%rbx, %rsi
    1bd3:      	callq	*%rax
    1bd5:      	movq	%rax, 0x18(%rsp)
    1bda:      	movl	$0x1, %eax
    1bdf:      	movq	(%rip), %rdi            # 0x1be6 <generic_retkprobe_filter_arg+0x1be6>
    1be6:      	movq	%rbx, %rsi
    1be9:      	callq	*%rax
    1beb:      	cmpq	$0x0, 0x18(%rsp)
    1bf1:      	je	0x2c5b <generic_retkprobe_filter_arg+0x2c5b>
    1bf7:      	movl	$0x0, %ebx
    1bfc:      	testq	%rax, %rax
    1bff:      	movq	(%rsp), %rdi
    1c03:      	movq	0x8(%rsp), %r9
    1c08:      	movq	0x10(%rsp), %r11
    1c0d:      	je	0x2c6b <generic_retkprobe_filter_arg+0x2c6b>
    1c13:      	movq	%rax, 0x98(%rsp)
    1c1b:      	movl	0x60(%rsp), %ebx
    1c1f:      	cmpl	$0x5, %ebx
    1c22:      	jg	0x2466 <generic_retkprobe_filter_arg+0x2466>
    1c28:      	movq	0x18(%rsp), %rax
    1c2d:      	movb	%bpl, (%rax)
    1c30:      	leaq	0x1(%rax), %rdi
    1c34:      	movl	$0x4, %eax
    1c39:      	movq	0x20(%rsp), %rdx
    1c3e:      	movl	%ebp, %esi
    1c40:      	callq	*%rax
    1c42:      	movq	0x88(%rsp), %rsi
    1c4a:      	subl	%ebp, %esi
    1c4c:      	jbe	0x24ae <generic_retkprobe_filter_arg+0x24ae>
    1c52:      	movq	0x18(%rsp), %rax
    1c57:      	leaq	(%rax,%rbp), %rdi
    1c5b:      	incq	%rdi
    1c5e:      	andl	$0xfff, %esi            # imm = 0xFFF
    1c64:      	movl	$0x4, %eax
    1c69:      	movq	0x98(%rsp), %rdx
    1c71:      	jmp	0x24ac <generic_retkprobe_filter_arg+0x24ac>
    1c76:      	cmpl	$0xc, %ecx
    1c79:      	je	0x1c84 <generic_retkprobe_filter_arg+0x1c84>
    1c7b:      	cmpl	$0xa, %ecx
    1c7e:      	jne	0x257b <generic_retkprobe_filter_arg+0x257b>
    1c84:      	cmpq	%rsi, (%rbp)
    1c88:      	jg	0x276 <generic_retkprobe_filter_arg+0x276>
    1c8e:      	jmp	0x2591 <generic_retkprobe_filter_arg+0x2591>
    1c93:      	movl	0x8(%r15), %edx
    1c97:      	movzbl	(%rbp), %ecx
    1c9b:      	jmp	0x1ca5 <generic_retkprobe_filter_arg+0x1ca5>
    1c9d:      	movl	0x8(%r15), %edx
    1ca1:      	movzwl	(%rbp), %ecx
    1ca5:      	cmpl	%ecx, 0x10(%r15)
    1ca9:      	setbe	%sil
    1cad:      	cmpl	%ecx, 0x14(%r15)
    1cb1:      	setae	%al
    1cb4:      	andb	%sil, %al
    1cb7:      	cmpl	$0x11, %edx
    1cba:      	jb	0x2af3 <generic_retkprobe_filter_arg+0x2af3>
    1cc0:      	cmpl	%ecx, 0x18(%r15)
    1cc4:      	setbe	%sil
    1cc8:      	cmpl	%ecx, 0x1c(%r15)
    1ccc:      	setae	%dil
    1cd0:      	andb	%sil, %dil
    1cd3:      	orb	%dil, %al
    1cd6:      	cmpl	$0x19, %edx
    1cd9:      	jb	0x2aef <generic_retkprobe_filter_arg+0x2aef>
    1cdf:      	cmpl	%ecx, 0x20(%r15)
    1ce3:      	setbe	%sil
    1ce7:      	cmpl	%ecx, 0x24(%r15)
    1ceb:      	setae	%dil
    1cef:      	andb	%sil, %dil
    1cf2:      	orb	%dil, %al
    1cf5:      	cmpl	$0x21, %edx
    1cf8:      	jb	0x2aef <generic_retkprobe_filter_arg+0x2aef>
    1cfe:      	cmpl	%ecx, 0x28(%r15)
    1d02:      	setbe	%dl
    1d05:      	cmpl	%ecx, 0x2c(%r15)
    1d09:      	setae	%cl
    1d0c:      	andb	%dl, %cl
    1d0e:      	orb	%cl, %al
    1d10:      	jmp	0x2aef <generic_retkprobe_filter_arg+0x2aef>
    1d15:      	xorl	%ebx, %ebx
    1d17:      	xorl	%r12d, %r12d
    1d1a:      	movl	0x10(%r15,%rbx,4), %eax
    1d1f:      	movl	%eax, 0x38(%rsp)
    1d23:      	movl	$0x1, %eax
    1d28:      	leaq	0x38(%rsp), %rsi
    1d2d:      	movq	(%rip), %rdi            # 0x1d34 <generic_retkprobe_filter_arg+0x1d34>
    1d34:      	callq	*%rax
    1d36:      	testq	%rax, %rax
    1d39:      	je	0x2683 <generic_retkprobe_filter_arg+0x2683>
    1d3f:      	testl	%ebp, %ebp
    1d41:      	movq	0x8(%rsp), %r9
    1d46:      	movq	0x10(%rsp), %r11
    1d4b:      	je	0x1d9f <generic_retkprobe_filter_arg+0x1d9f>
    1d4d:      	movq	0x20(%rsp), %rdx
    1d52:      	xorl	%ecx, %ecx
    1d54:      	jmp	0x1d61 <generic_retkprobe_filter_arg+0x1d61>
    1d56:      	incq	%rcx
    1d59:      	incq	%rdx
    1d5c:      	cmpq	%rbp, %rcx
    1d5f:      	je	0x1d9f <generic_retkprobe_filter_arg+0x1d9f>
    1d61:      	xorl	%esi, %esi
    1d63:      	nopw	%cs:(%rax,%rax)
    1d70:      	leaq	(%rcx,%rsi), %rdi
    1d74:      	cmpq	%rbp, %rdi
    1d77:      	jae	0x1d56 <generic_retkprobe_filter_arg+0x1d56>
    1d79:      	movzbl	(%rax,%rsi), %edi
    1d7d:      	testb	%dil, %dil
    1d80:      	je	0x1d97 <generic_retkprobe_filter_arg+0x1d97>
    1d82:      	cmpq	$0x62, %rsi
    1d86:      	ja	0x1d56 <generic_retkprobe_filter_arg+0x1d56>
    1d88:      	leaq	0x1(%rsi), %r8
    1d8c:      	cmpb	%dil, (%rdx,%rsi)
    1d90:      	movq	%r8, %rsi
    1d93:      	je	0x1d70 <generic_retkprobe_filter_arg+0x1d70>
    1d95:      	jmp	0x1d56 <generic_retkprobe_filter_arg+0x1d56>
    1d97:      	testl	%ecx, %ecx
    1d99:      	jns	0x297d <generic_retkprobe_filter_arg+0x297d>
    1d9f:      	leal	0xc(%r12), %eax
    1da4:      	cmpl	0x8(%r15), %eax
    1da8:      	jae	0x1dbb <generic_retkprobe_filter_arg+0x1dbb>
    1daa:      	addl	$0x4, %r12d
    1dae:      	incq	%rbx
    1db1:      	cmpq	$0x64, %rbx
    1db5:      	jne	0x1d1a <generic_retkprobe_filter_arg+0x1d1a>
    1dbb:      	xorl	%ebx, %ebx
    1dbd:      	movq	(%rsp), %rdi
    1dc1:      	jmp	0x2ef2 <generic_retkprobe_filter_arg+0x2ef2>
    1dc6:      	movzwl	%bp, %eax
    1dc9:      	cmpl	$0x90, %eax
    1dce:      	ja	0x223c <generic_retkprobe_filter_arg+0x223c>
    1dd4:      	testw	%bp, %bp
    1dd7:      	je	0x1de9 <generic_retkprobe_filter_arg+0x1de9>
    1dd9:      	movl	%ebp, %eax
    1ddb:      	movl	$0x18, %ecx
    1de0:      	cltd
    1de1:      	idivl	%ecx
    1de3:      	movl	%ebp, %edi
    1de5:      	testl	%edx, %edx
    1de7:      	je	0x1e0b <generic_retkprobe_filter_arg+0x1e0b>
    1de9:      	movl	%ebp, %eax
    1deb:      	movl	$0x18, %ecx
    1df0:      	cltd
    1df1:      	idivl	%ecx
    1df3:      	shll	$0x3, %eax
    1df6:      	leal	(%rax,%rax,2), %eax
    1df9:      	addl	$0x18, %eax
    1dfc:      	movzwl	%ax, %edi
    1dff:      	cmpl	$0x90, %edi
    1e05:      	ja	0x2250 <generic_retkprobe_filter_arg+0x2250>
    1e0b:      	movl	%edi, %eax
    1e0d:      	cltd
    1e0e:      	idivl	%ecx
    1e10:      	decl	%eax
    1e12:      	jmp	0x2261 <generic_retkprobe_filter_arg+0x2261>
    1e17:      	movzbl	(%rbp), %edx
    1e1b:      	cmpl	%edx, %ecx
    1e1d:      	jb	0x276 <generic_retkprobe_filter_arg+0x276>
    1e23:      	movl	0x8(%r15), %ecx
    1e27:      	cmpl	$0xd, %ecx
    1e2a:      	jb	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    1e30:      	movl	0x14(%r15), %edx
    1e34:      	cmpl	$0x2, %eax
    1e37:      	jle	0x2126 <generic_retkprobe_filter_arg+0x2126>
    1e3d:      	leal	-0x3(%rax), %esi
    1e40:      	cmpl	$0x2, %esi
    1e43:      	jae	0x2609 <generic_retkprobe_filter_arg+0x2609>
    1e49:      	movzbl	(%rbp), %esi
    1e4d:      	cmpl	%esi, %edx
    1e4f:      	jne	0x26fe <generic_retkprobe_filter_arg+0x26fe>
    1e55:      	jmp	0x2e81 <generic_retkprobe_filter_arg+0x2e81>
    1e5a:      	movzwl	(%rbp), %edx
    1e5e:      	cmpl	%edx, %ecx
    1e60:      	jb	0x276 <generic_retkprobe_filter_arg+0x276>
    1e66:      	movl	0x8(%r15), %ecx
    1e6a:      	cmpl	$0xd, %ecx
    1e6d:      	jb	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    1e73:      	movl	0x14(%r15), %edx
    1e77:      	cmpl	$0x2, %eax
    1e7a:      	jle	0x2149 <generic_retkprobe_filter_arg+0x2149>
    1e80:      	leal	-0x3(%rax), %esi
    1e83:      	cmpl	$0x2, %esi
    1e86:      	jae	0x2623 <generic_retkprobe_filter_arg+0x2623>
    1e8c:      	movzwl	(%rbp), %esi
    1e90:      	cmpl	%esi, %edx
    1e92:      	jne	0x273d <generic_retkprobe_filter_arg+0x273d>
    1e98:      	jmp	0x2e81 <generic_retkprobe_filter_arg+0x2e81>
    1e9d:      	testq	%rax, %rax
    1ea0:      	sete	%al
    1ea3:      	movq	(%rsp), %rdi
    1ea7:      	movq	0x8(%rsp), %r9
    1eac:      	movq	0x10(%rsp), %r11
    1eb1:      	movzbl	%al, %ebx
    1eb4:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    1eb9:      	movl	(%rbp), %eax
    1ebc:      	cmpl	%eax, %esi
    1ebe:      	ja	0x1ec8 <generic_retkprobe_filter_arg+0x1ec8>
    1ec0:      	cmpl	%edx, %eax
    1ec2:      	jbe	0x276 <generic_retkprobe_filter_arg+0x276>
    1ec8:      	movl	0x8(%r15), %edx
    1ecc:      	cmpl	$0x11, %edx
    1ecf:      	jb	0xb8 <generic_retkprobe_filter_arg+0xb8>
    1ed5:      	movl	0x18(%r15), %edi
    1ed9:      	movl	0x1c(%r15), %esi
    1edd:      	cmpl	$0xc, %ecx
    1ee0:      	ja	0x2384 <generic_retkprobe_filter_arg+0x2384>
    1ee6:      	movl	$0x1402, %r8d           # imm = 0x1402
    1eec:      	btl	%ecx, %r8d
    1ef0:      	jae	0x2384 <generic_retkprobe_filter_arg+0x2384>
    1ef6:      	cmpl	%eax, %edi
    1ef8:      	movq	(%rsp), %rdi
    1efc:      	jg	0x2394 <generic_retkprobe_filter_arg+0x2394>
    1f02:      	cmpl	%esi, %eax
    1f04:      	jle	0x276 <generic_retkprobe_filter_arg+0x276>
    1f0a:      	jmp	0x2394 <generic_retkprobe_filter_arg+0x2394>
    1f0f:      	movl	(%rbp), %edx
    1f12:      	cmpl	%edx, %esi
    1f14:      	setbe	%sil
    1f18:      	cmpl	%eax, %edx
    1f1a:      	setbe	%al
    1f1d:      	andb	%sil, %al
    1f20:      	movl	0x8(%r15), %esi
    1f24:      	cmpl	$0x11, %esi
    1f27:      	jb	0x2af3 <generic_retkprobe_filter_arg+0x2af3>
    1f2d:      	movl	0x18(%r15), %r8d
    1f31:      	movl	0x1c(%r15), %edi
    1f35:      	cmpl	$0xc, %ecx
    1f38:      	ja	0x2335 <generic_retkprobe_filter_arg+0x2335>
    1f3e:      	movl	$0x1402, %r10d          # imm = 0x1402
    1f44:      	btl	%ecx, %r10d
    1f48:      	jae	0x2335 <generic_retkprobe_filter_arg+0x2335>
    1f4e:      	cmpl	%edx, %r8d
    1f51:      	setle	%r8b
    1f55:      	cmpl	%edi, %edx
    1f57:      	setle	%dil
    1f5b:      	jmp	0x2342 <generic_retkprobe_filter_arg+0x2342>
    1f60:      	cmpq	%rdx, %r8
    1f63:      	setbe	%r8b
    1f67:      	cmpq	%rdi, %rdx
    1f6a:      	setbe	%dil
    1f6e:      	andb	%r8b, %dil
    1f71:      	orb	%dil, %al
    1f74:      	cmpl	$0x29, %esi
    1f77:      	jb	0x2aef <generic_retkprobe_filter_arg+0x2aef>
    1f7d:      	movq	0x30(%r15), %r8
    1f81:      	movq	0x38(%r15), %rdi
    1f85:      	cmpl	$0xc, %ecx
    1f88:      	je	0x1f93 <generic_retkprobe_filter_arg+0x1f93>
    1f8a:      	cmpl	$0xa, %ecx
    1f8d:      	jne	0x241e <generic_retkprobe_filter_arg+0x241e>
    1f93:      	cmpq	%rdx, %r8
    1f96:      	setle	%r8b
    1f9a:      	cmpq	%rdi, %rdx
    1f9d:      	setle	%dil
    1fa1:      	jmp	0x242c <generic_retkprobe_filter_arg+0x242c>
    1fa6:      	cmpq	%rax, %rdi
    1fa9:      	movq	(%rsp), %rdi
    1fad:      	ja	0x1fb8 <generic_retkprobe_filter_arg+0x1fb8>
    1faf:      	cmpq	%rsi, %rax
    1fb2:      	jbe	0x276 <generic_retkprobe_filter_arg+0x276>
    1fb8:      	cmpl	$0x29, %edx
    1fbb:      	jb	0xb8 <generic_retkprobe_filter_arg+0xb8>
    1fc1:      	movq	0x30(%r15), %rdi
    1fc5:      	movq	0x38(%r15), %rsi
    1fc9:      	cmpl	$0xc, %ecx
    1fcc:      	je	0x1fd7 <generic_retkprobe_filter_arg+0x1fd7>
    1fce:      	cmpl	$0xa, %ecx
    1fd1:      	jne	0x2533 <generic_retkprobe_filter_arg+0x2533>
    1fd7:      	cmpq	%rax, %rdi
    1fda:      	movq	(%rsp), %rdi
    1fde:      	jg	0x2545 <generic_retkprobe_filter_arg+0x2545>
    1fe4:      	cmpq	%rsi, %rax
    1fe7:      	jle	0x276 <generic_retkprobe_filter_arg+0x276>
    1fed:      	jmp	0x2545 <generic_retkprobe_filter_arg+0x2545>
    1ff2:      	xorl	%ebx, %ebx
    1ff4:      	cmpl	$0x29, %ecx
    1ff7:      	jne	0x2002 <generic_retkprobe_filter_arg+0x2002>
    1ff9:      	testq	%rdx, %rdx
    1ffc:      	je	0x2002 <generic_retkprobe_filter_arg+0x2002>
    1ffe:      	movzbl	0x3a(%rdx), %ebx
    2002:      	cmpl	$0x29, %ecx
    2005:      	je	0x2010 <generic_retkprobe_filter_arg+0x2010>
    2007:      	cmpl	$0x7, %ecx
    200a:      	jne	0x245f <generic_retkprobe_filter_arg+0x245f>
    2010:      	movzbl	0x10(%r15), %eax
    2015:      	movl	%eax, 0x2c(%rsp)
    2019:      	movl	$0x1, %eax
    201e:      	movq	(%rip), %rdi            # 0x2025 <generic_retkprobe_filter_arg+0x2025>
    2025:      	leaq	0x2c(%rsp), %rsi
    202a:      	callq	*%rax
    202c:      	testq	%rax, %rax
    202f:      	je	0x250 <generic_retkprobe_filter_arg+0x250>
    2035:      	movq	%rax, %rdi
    2038:      	movl	%ebx, %eax
    203a:      	movq	%rax, 0x70(%rsp)
    203f:      	movl	$0x1, %eax
    2044:      	movq	0x30(%rsp), %rsi
    2049:      	jmp	0x1a51 <generic_retkprobe_filter_arg+0x1a51>
    204e:      	cmpl	%edx, (%rbp)
    2051:      	ja	0x276 <generic_retkprobe_filter_arg+0x276>
    2057:      	jmp	0x2062 <generic_retkprobe_filter_arg+0x2062>
    2059:      	cmpl	%edx, (%rbp)
    205c:      	jb	0x276 <generic_retkprobe_filter_arg+0x276>
    2062:      	movl	0x8(%r15), %edx
    2066:      	cmpl	$0xd, %edx
    2069:      	jb	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    206f:      	movl	0x14(%r15), %esi
    2073:      	cmpl	$0x2, %eax
    2076:      	jle	0x2092 <generic_retkprobe_filter_arg+0x2092>
    2078:      	leal	-0x3(%rax), %edi
    207b:      	cmpl	$0x2, %edi
    207e:      	jae	0x20c7 <generic_retkprobe_filter_arg+0x20c7>
    2080:      	cmpl	%esi, (%rbp)
    2083:      	movq	(%rsp), %rdi
    2087:      	jne	0x281f <generic_retkprobe_filter_arg+0x281f>
    208d:      	jmp	0x2e81 <generic_retkprobe_filter_arg+0x2e81>
    2092:      	cmpl	$0x1, %eax
    2095:      	je	0x20e2 <generic_retkprobe_filter_arg+0x20e2>
    2097:      	cmpl	$0x2, %eax
    209a:      	jne	0x281f <generic_retkprobe_filter_arg+0x281f>
    20a0:      	cmpl	$0xc, %ecx
    20a3:      	ja	0x2816 <generic_retkprobe_filter_arg+0x2816>
    20a9:      	movl	$0x1402, %r8d           # imm = 0x1402
    20af:      	btl	%ecx, %r8d
    20b3:      	jae	0x2816 <generic_retkprobe_filter_arg+0x2816>
    20b9:      	cmpl	%esi, (%rbp)
    20bc:      	jl	0x276 <generic_retkprobe_filter_arg+0x276>
    20c2:      	jmp	0x281f <generic_retkprobe_filter_arg+0x281f>
    20c7:      	cmpl	$0xc, %eax
    20ca:      	movq	(%rsp), %rdi
    20ce:      	jne	0x281f <generic_retkprobe_filter_arg+0x281f>
    20d4:      	testl	%esi, (%rbp)
    20d7:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
    20dd:      	jmp	0x281f <generic_retkprobe_filter_arg+0x281f>
    20e2:      	cmpl	$0xc, %ecx
    20e5:      	ja	0x280b <generic_retkprobe_filter_arg+0x280b>
    20eb:      	movl	$0x1402, %r8d           # imm = 0x1402
    20f1:      	btl	%ecx, %r8d
    20f5:      	jae	0x280b <generic_retkprobe_filter_arg+0x280b>
    20fb:      	cmpl	%esi, (%rbp)
    20fe:      	jg	0x276 <generic_retkprobe_filter_arg+0x276>
    2104:      	jmp	0x281f <generic_retkprobe_filter_arg+0x281f>
    2109:      	xorl	%ebx, %ebx
    210b:      	movq	0x8(%rsp), %r9
    2110:      	movq	0x10(%rsp), %r11
    2115:      	jmp	0x23dc <generic_retkprobe_filter_arg+0x23dc>
    211a:      	xorl	%ebx, %ebx
    211c:      	movq	0x10(%rsp), %r11
    2121:      	jmp	0x23fd <generic_retkprobe_filter_arg+0x23fd>
    2126:      	cmpl	$0x1, %eax
    2129:      	je	0x26f2 <generic_retkprobe_filter_arg+0x26f2>
    212f:      	cmpl	$0x2, %eax
    2132:      	jne	0x26fe <generic_retkprobe_filter_arg+0x26fe>
    2138:      	movzbl	(%rbp), %esi
    213c:      	cmpl	%esi, %edx
    213e:      	ja	0x276 <generic_retkprobe_filter_arg+0x276>
    2144:      	jmp	0x26fe <generic_retkprobe_filter_arg+0x26fe>
    2149:      	cmpl	$0x1, %eax
    214c:      	je	0x2731 <generic_retkprobe_filter_arg+0x2731>
    2152:      	cmpl	$0x2, %eax
    2155:      	jne	0x273d <generic_retkprobe_filter_arg+0x273d>
    215b:      	movzwl	(%rbp), %esi
    215f:      	cmpl	%esi, %edx
    2161:      	ja	0x276 <generic_retkprobe_filter_arg+0x276>
    2167:      	jmp	0x273d <generic_retkprobe_filter_arg+0x273d>
    216c:      	movq	0x18(%rsp), %rax
    2171:      	movw	%bp, (%rax)
    2174:      	leaq	0x2(%rax), %rdi
    2178:      	movl	$0x4, %eax
    217d:      	movl	%ebp, %esi
    217f:      	callq	*%rax
    2181:      	movq	0x88(%rsp), %rsi
    2189:      	subl	%ebp, %esi
    218b:      	jbe	0x21af <generic_retkprobe_filter_arg+0x21af>
    218d:      	movq	0x18(%rsp), %rax
    2192:      	leaq	(%rax,%rbp), %rdi
    2196:      	addq	$0x2, %rdi
    219a:      	andl	$0xfff, %esi            # imm = 0xFFF
    21a0:      	movl	$0x4, %eax
    21a5:      	movq	0x98(%rsp), %rdx
    21ad:      	callq	*%rax
    21af:      	movl	0x90(%rsp), %eax
    21b6:      	movl	%eax, 0x38(%rsp)
    21ba:      	cmpl	$0x3, %ebx
    21bd:      	jg	0x21fd <generic_retkprobe_filter_arg+0x21fd>
    21bf:      	cmpl	$0x1, %ebx
    21c2:      	movq	(%rsp), %rdi
    21c6:      	movq	0x8(%rsp), %r9
    21cb:      	movq	0x10(%rsp), %r11
    21d0:      	jg	0x2698 <generic_retkprobe_filter_arg+0x2698>
    21d6:      	testl	%ebx, %ebx
    21d8:      	je	0x2a3c <generic_retkprobe_filter_arg+0x2a3c>
    21de:      	cmpl	$0x1, %ebx
    21e1:      	jne	0x845 <generic_retkprobe_filter_arg+0x845>
    21e7:      	movl	$0x1, %eax
    21ec:      	leaq	0x38(%rsp), %rsi
    21f1:      	movq	(%rip), %rdi            # 0x21f8 <generic_retkprobe_filter_arg+0x21f8>
    21f8:      	jmp	0x2a86 <generic_retkprobe_filter_arg+0x2a86>
    21fd:      	cmpl	$0x5, %ebx
    2200:      	movq	(%rsp), %rdi
    2204:      	movq	0x8(%rsp), %r9
    2209:      	movq	0x10(%rsp), %r11
    220e:      	jg	0x26c0 <generic_retkprobe_filter_arg+0x26c0>
    2214:      	cmpl	$0x4, %ebx
    2217:      	je	0x2a4f <generic_retkprobe_filter_arg+0x2a4f>
    221d:      	cmpl	$0x5, %ebx
    2220:      	jne	0x845 <generic_retkprobe_filter_arg+0x845>
    2226:      	movl	$0x1, %eax
    222b:      	leaq	0x38(%rsp), %rsi
    2230:      	movq	(%rip), %rdi            # 0x2237 <generic_retkprobe_filter_arg+0x2237>
    2237:      	jmp	0x2a86 <generic_retkprobe_filter_arg+0x2a86>
    223c:      	cmpl	$0x101, %eax            # imm = 0x101
    2241:      	movl	$0x100, %edi            # imm = 0x100
    2246:      	movl	$0x1fe, %eax            # imm = 0x1FE
    224b:      	cmovael	%eax, %edi
    224e:      	movl	%edi, %eax
    2250:      	movzwl	%ax, %ecx
    2253:      	xorl	%eax, %eax
    2255:      	cmpl	$0x100, %ecx            # imm = 0x100
    225b:      	sete	%al
    225e:      	xorl	$0x7, %eax
    2261:      	movl	%eax, %ecx
    2263:      	andl	$0xf, %ecx
    2266:      	movl	0x10(%r15,%rcx,4), %ecx
    226b:      	cmpl	$-0x1, %ecx
    226e:      	je	0x2ee2 <generic_retkprobe_filter_arg+0x2ee2>
    2274:      	movl	%ecx, 0x88(%rsp)
    227b:      	movq	%rdi, 0x90(%rsp)
    2283:      	movl	%eax, 0x18(%rsp)
    2287:      	movq	%rsi, 0x20(%rsp)
    228c:      	movl	$0x1, %eax
    2291:      	movq	(%rip), %rdi            # 0x2298 <generic_retkprobe_filter_arg+0x2298>
    2298:      	movq	0x30(%rsp), %rbx
    229d:      	movq	%rbx, %rsi
    22a0:      	callq	*%rax
    22a2:      	movq	%rax, 0x60(%rsp)
    22a7:      	movl	$0x1, %eax
    22ac:      	movq	(%rip), %rdi            # 0x22b3 <generic_retkprobe_filter_arg+0x22b3>
    22b3:      	movq	%rbx, %rsi
    22b6:      	callq	*%rax
    22b8:      	movq	0x60(%rsp), %rdx
    22bd:      	testq	%rdx, %rdx
    22c0:      	je	0x2ee2 <generic_retkprobe_filter_arg+0x2ee2>
    22c6:      	movl	$0x0, %ebx
    22cb:      	testq	%rax, %rax
    22ce:      	movq	(%rsp), %rdi
    22d2:      	movq	0x8(%rsp), %r9
    22d7:      	movq	0x10(%rsp), %r11
    22dc:      	je	0x2ef2 <generic_retkprobe_filter_arg+0x2ef2>
    22e2:      	movq	%rdx, %rcx
    22e5:      	movq	%rax, %r12
    22e8:      	cmpl	$0x5, 0x18(%rsp)
    22ed:      	jg	0x298b <generic_retkprobe_filter_arg+0x298b>
    22f3:      	movq	%rcx, %rbx
    22f6:      	movb	%bpl, (%rcx)
    22f9:      	leaq	0x1(%rcx), %rdi
    22fd:      	movl	$0x4, %eax
    2302:      	movq	0x20(%rsp), %rdx
    2307:      	movl	%ebp, %esi
    2309:      	callq	*%rax
    230b:      	movq	0x90(%rsp), %rsi
    2313:      	subl	%ebp, %esi
    2315:      	jbe	0x29c7 <generic_retkprobe_filter_arg+0x29c7>
    231b:      	leaq	(%rbx,%rbp), %rdi
    231f:      	incq	%rdi
    2322:      	andl	$0xfff, %esi            # imm = 0xFFF
    2328:      	movl	$0x4, %eax
    232d:      	movq	%r12, %rdx
    2330:      	jmp	0x29c5 <generic_retkprobe_filter_arg+0x29c5>
    2335:      	cmpl	%edx, %r8d
    2338:      	setbe	%r8b
    233c:      	cmpl	%edi, %edx
    233e:      	setbe	%dil
    2342:      	andb	%r8b, %dil
    2345:      	orb	%dil, %al
    2348:      	cmpl	$0x19, %esi
    234b:      	jb	0x2aef <generic_retkprobe_filter_arg+0x2aef>
    2351:      	movl	0x20(%r15), %r8d
    2355:      	movl	0x24(%r15), %edi
    2359:      	cmpl	$0xc, %ecx
    235c:      	ja	0x2770 <generic_retkprobe_filter_arg+0x2770>
    2362:      	movl	$0x1402, %r10d          # imm = 0x1402
    2368:      	btl	%ecx, %r10d
    236c:      	jae	0x2770 <generic_retkprobe_filter_arg+0x2770>
    2372:      	cmpl	%edx, %r8d
    2375:      	setle	%r8b
    2379:      	cmpl	%edi, %edx
    237b:      	setle	%dil
    237f:      	jmp	0x277d <generic_retkprobe_filter_arg+0x277d>
    2384:      	cmpl	%eax, %edi
    2386:      	movq	(%rsp), %rdi
    238a:      	ja	0x2394 <generic_retkprobe_filter_arg+0x2394>
    238c:      	cmpl	%esi, %eax
    238e:      	jbe	0x276 <generic_retkprobe_filter_arg+0x276>
    2394:      	cmpl	$0x19, %edx
    2397:      	jb	0xb8 <generic_retkprobe_filter_arg+0xb8>
    239d:      	movl	0x20(%r15), %edi
    23a1:      	movl	0x24(%r15), %esi
    23a5:      	cmpl	$0xc, %ecx
    23a8:      	ja	0x27bc <generic_retkprobe_filter_arg+0x27bc>
    23ae:      	movl	$0x1402, %r8d           # imm = 0x1402
    23b4:      	btl	%ecx, %r8d
    23b8:      	jae	0x27bc <generic_retkprobe_filter_arg+0x27bc>
    23be:      	cmpl	%eax, %edi
    23c0:      	movq	(%rsp), %rdi
    23c4:      	jg	0x27cc <generic_retkprobe_filter_arg+0x27cc>
    23ca:      	cmpl	%esi, %eax
    23cc:      	jle	0x276 <generic_retkprobe_filter_arg+0x276>
    23d2:      	jmp	0x27cc <generic_retkprobe_filter_arg+0x27cc>
    23d7:      	movl	$0x1, %ebx
    23dc:      	movq	0x68(%rsp), %r12
    23e1:      	movq	(%rsp), %rdi
    23e5:      	movl	0x4(%r15), %eax
    23e9:      	cmpq	$0x25, %rax
    23ed:      	jbe	0x2c79 <generic_retkprobe_filter_arg+0x2c79>
    23f3:      	jmp	0x265 <generic_retkprobe_filter_arg+0x265>
    23f8:      	movl	$0x1, %ebx
    23fd:      	movq	0x68(%rsp), %r12
    2402:      	movq	(%rsp), %rdi
    2406:      	movq	0x8(%rsp), %r9
    240b:      	movl	0x4(%r15), %eax
    240f:      	cmpq	$0x25, %rax
    2413:      	jbe	0x2c79 <generic_retkprobe_filter_arg+0x2c79>
    2419:      	jmp	0x265 <generic_retkprobe_filter_arg+0x265>
    241e:      	cmpq	%rdx, %r8
    2421:      	setbe	%r8b
    2425:      	cmpq	%rdi, %rdx
    2428:      	setbe	%dil
    242c:      	andb	%r8b, %dil
    242f:      	orb	%dil, %al
    2432:      	cmpl	$0x39, %esi
    2435:      	jb	0x2aef <generic_retkprobe_filter_arg+0x2aef>
    243b:      	movq	0x40(%r15), %rdi
    243f:      	movq	0x48(%r15), %rsi
    2443:      	cmpl	$0xc, %ecx
    2446:      	je	0x2451 <generic_retkprobe_filter_arg+0x2451>
    2448:      	cmpl	$0xa, %ecx
    244b:      	jne	0x28c2 <generic_retkprobe_filter_arg+0x28c2>
    2451:      	cmpq	%rdx, %rdi
    2454:      	setle	%cl
    2457:      	cmpq	%rsi, %rdx
    245a:      	jmp	0x27b4 <generic_retkprobe_filter_arg+0x27b4>
    245f:      	xorl	%ebx, %ebx
    2461:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    2466:      	movq	0x18(%rsp), %rax
    246b:      	movw	%bp, (%rax)
    246e:      	leaq	0x2(%rax), %rdi
    2472:      	movl	$0x4, %eax
    2477:      	movq	0x20(%rsp), %rdx
    247c:      	movl	%ebp, %esi
    247e:      	callq	*%rax
    2480:      	movq	0x88(%rsp), %rsi
    2488:      	subl	%ebp, %esi
    248a:      	jbe	0x24ae <generic_retkprobe_filter_arg+0x24ae>
    248c:      	movq	0x18(%rsp), %rax
    2491:      	leaq	(%rax,%rbp), %rdi
    2495:      	addq	$0x2, %rdi
    2499:      	andl	$0xfff, %esi            # imm = 0xFFF
    249f:      	movl	$0x4, %eax
    24a4:      	movq	0x98(%rsp), %rdx
    24ac:      	callq	*%rax
    24ae:      	movl	0x90(%rsp), %eax
    24b5:      	movl	%eax, 0x38(%rsp)
    24b9:      	cmpl	$0x3, %ebx
    24bc:      	jg	0x24f8 <generic_retkprobe_filter_arg+0x24f8>
    24be:      	cmpl	$0x1, %ebx
    24c1:      	movq	0x8(%rsp), %r9
    24c6:      	movq	0x10(%rsp), %r11
    24cb:      	jg	0x28d0 <generic_retkprobe_filter_arg+0x28d0>
    24d1:      	testl	%ebx, %ebx
    24d3:      	je	0x2bf1 <generic_retkprobe_filter_arg+0x2bf1>
    24d9:      	cmpl	$0x1, %ebx
    24dc:      	jne	0x2c92 <generic_retkprobe_filter_arg+0x2c92>
    24e2:      	movl	$0x1, %eax
    24e7:      	leaq	0x38(%rsp), %rsi
    24ec:      	movq	(%rip), %rdi            # 0x24f3 <generic_retkprobe_filter_arg+0x24f3>
    24f3:      	jmp	0x2c3b <generic_retkprobe_filter_arg+0x2c3b>
    24f8:      	cmpl	$0x5, %ebx
    24fb:      	movq	0x8(%rsp), %r9
    2500:      	movq	0x10(%rsp), %r11
    2505:      	jg	0x28f8 <generic_retkprobe_filter_arg+0x28f8>
    250b:      	cmpl	$0x4, %ebx
    250e:      	je	0x2c04 <generic_retkprobe_filter_arg+0x2c04>
    2514:      	cmpl	$0x5, %ebx
    2517:      	jne	0x2c92 <generic_retkprobe_filter_arg+0x2c92>
    251d:      	movl	$0x1, %eax
    2522:      	leaq	0x38(%rsp), %rsi
    2527:      	movq	(%rip), %rdi            # 0x252e <generic_retkprobe_filter_arg+0x252e>
    252e:      	jmp	0x2c3b <generic_retkprobe_filter_arg+0x2c3b>
    2533:      	cmpq	%rax, %rdi
    2536:      	movq	(%rsp), %rdi
    253a:      	ja	0x2545 <generic_retkprobe_filter_arg+0x2545>
    253c:      	cmpq	%rsi, %rax
    253f:      	jbe	0x276 <generic_retkprobe_filter_arg+0x276>
    2545:      	cmpl	$0x39, %edx
    2548:      	jb	0xb8 <generic_retkprobe_filter_arg+0xb8>
    254e:      	movq	0x40(%r15), %rsi
    2552:      	movq	0x48(%r15), %rdx
    2556:      	cmpl	$0xc, %ecx
    2559:      	je	0x2564 <generic_retkprobe_filter_arg+0x2564>
    255b:      	cmpl	$0xa, %ecx
    255e:      	jne	0x2920 <generic_retkprobe_filter_arg+0x2920>
    2564:      	cmpq	%rax, %rsi
    2567:      	jg	0xb8 <generic_retkprobe_filter_arg+0xb8>
    256d:      	cmpq	%rdx, %rax
    2570:      	jle	0x276 <generic_retkprobe_filter_arg+0x276>
    2576:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
    257b:      	cmpq	%rsi, (%rbp)
    257f:      	ja	0x276 <generic_retkprobe_filter_arg+0x276>
    2585:      	jmp	0x2591 <generic_retkprobe_filter_arg+0x2591>
    2587:      	cmpq	%rsi, (%rbp)
    258b:      	jb	0x276 <generic_retkprobe_filter_arg+0x276>
    2591:      	cmpl	$0x19, %edx
    2594:      	jb	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    259a:      	movq	0x20(%r15), %rsi
    259e:      	cmpl	$0x2, %eax
    25a1:      	jle	0x25be <generic_retkprobe_filter_arg+0x25be>
    25a3:      	leal	-0x3(%rax), %edi
    25a6:      	cmpl	$0x2, %edi
    25a9:      	jae	0x25ed <generic_retkprobe_filter_arg+0x25ed>
    25ab:      	cmpq	%rsi, (%rbp)
    25af:      	movq	(%rsp), %rdi
    25b3:      	jne	0x2b16 <generic_retkprobe_filter_arg+0x2b16>
    25b9:      	jmp	0x2e81 <generic_retkprobe_filter_arg+0x2e81>
    25be:      	cmpl	$0x1, %eax
    25c1:      	je	0x2666 <generic_retkprobe_filter_arg+0x2666>
    25c7:      	cmpl	$0x2, %eax
    25ca:      	jne	0x2b16 <generic_retkprobe_filter_arg+0x2b16>
    25d0:      	cmpl	$0xc, %ecx
    25d3:      	je	0x25de <generic_retkprobe_filter_arg+0x25de>
    25d5:      	cmpl	$0xa, %ecx
    25d8:      	jne	0x2b0c <generic_retkprobe_filter_arg+0x2b0c>
    25de:      	cmpq	%rsi, (%rbp)
    25e2:      	jl	0x276 <generic_retkprobe_filter_arg+0x276>
    25e8:      	jmp	0x2b16 <generic_retkprobe_filter_arg+0x2b16>
    25ed:      	cmpl	$0xc, %eax
    25f0:      	movq	(%rsp), %rdi
    25f4:      	jne	0x2b16 <generic_retkprobe_filter_arg+0x2b16>
    25fa:      	testq	%rsi, (%rbp)
    25fe:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
    2604:      	jmp	0x2b16 <generic_retkprobe_filter_arg+0x2b16>
    2609:      	cmpl	$0xc, %eax
    260c:      	jne	0x26fe <generic_retkprobe_filter_arg+0x26fe>
    2612:      	movzbl	(%rbp), %esi
    2616:      	testl	%esi, %edx
    2618:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
    261e:      	jmp	0x26fe <generic_retkprobe_filter_arg+0x26fe>
    2623:      	cmpl	$0xc, %eax
    2626:      	jne	0x273d <generic_retkprobe_filter_arg+0x273d>
    262c:      	movzwl	(%rbp), %esi
    2630:      	testl	%esi, %edx
    2632:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
    2638:      	jmp	0x273d <generic_retkprobe_filter_arg+0x273d>
    263d:      	movq	(%rsp), %rdi
    2641:      	movq	0x8(%rsp), %r9
    2646:      	movq	0x10(%rsp), %r11
    264b:      	movzbl	%cl, %ebx
    264e:      	jmp	0x265 <generic_retkprobe_filter_arg+0x265>
    2653:      	movq	(%rsp), %rdi
    2657:      	movq	0x8(%rsp), %r9
    265c:      	movq	0x10(%rsp), %r11
    2661:      	jmp	0x1a92 <generic_retkprobe_filter_arg+0x1a92>
    2666:      	cmpl	$0xc, %ecx
    2669:      	je	0x2674 <generic_retkprobe_filter_arg+0x2674>
    266b:      	cmpl	$0xa, %ecx
    266e:      	jne	0x2b00 <generic_retkprobe_filter_arg+0x2b00>
    2674:      	cmpq	%rsi, (%rbp)
    2678:      	jg	0x276 <generic_retkprobe_filter_arg+0x276>
    267e:      	jmp	0x2b16 <generic_retkprobe_filter_arg+0x2b16>
    2683:      	xorl	%ebx, %ebx
    2685:      	movq	0x8(%rsp), %r9
    268a:      	movq	0x10(%rsp), %r11
    268f:      	movq	(%rsp), %rdi
    2693:      	jmp	0x2ef2 <generic_retkprobe_filter_arg+0x2ef2>
    2698:      	cmpl	$0x2, %ebx
    269b:      	je	0x2a62 <generic_retkprobe_filter_arg+0x2a62>
    26a1:      	cmpl	$0x3, %ebx
    26a4:      	jne	0x845 <generic_retkprobe_filter_arg+0x845>
    26aa:      	movl	$0x1, %eax
    26af:      	leaq	0x38(%rsp), %rsi
    26b4:      	movq	(%rip), %rdi            # 0x26bb <generic_retkprobe_filter_arg+0x26bb>
    26bb:      	jmp	0x2a86 <generic_retkprobe_filter_arg+0x2a86>
    26c0:      	cmpl	$0x6, %ebx
    26c3:      	je	0x2a75 <generic_retkprobe_filter_arg+0x2a75>
    26c9:      	cmpl	$0x7, %ebx
    26cc:      	jne	0x845 <generic_retkprobe_filter_arg+0x845>
    26d2:      	movl	$0x1, %eax
    26d7:      	leaq	0x38(%rsp), %rsi
    26dc:      	movq	(%rip), %rdi            # 0x26e3 <generic_retkprobe_filter_arg+0x26e3>
    26e3:      	jmp	0x2a86 <generic_retkprobe_filter_arg+0x2a86>
    26e8:      	movl	$0x1, %ebx
    26ed:      	jmp	0x2ee4 <generic_retkprobe_filter_arg+0x2ee4>
    26f2:      	movzbl	(%rbp), %esi
    26f6:      	cmpl	%esi, %edx
    26f8:      	jb	0x276 <generic_retkprobe_filter_arg+0x276>
    26fe:      	cmpl	$0x11, %ecx
    2701:      	jb	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2707:      	movl	0x18(%r15), %edx
    270b:      	cmpl	$0x2, %eax
    270e:      	jle	0x2937 <generic_retkprobe_filter_arg+0x2937>
    2714:      	leal	-0x3(%rax), %esi
    2717:      	cmpl	$0x2, %esi
    271a:      	jae	0x2b8b <generic_retkprobe_filter_arg+0x2b8b>
    2720:      	movzbl	(%rbp), %esi
    2724:      	cmpl	%esi, %edx
    2726:      	jne	0x2cf9 <generic_retkprobe_filter_arg+0x2cf9>
    272c:      	jmp	0x2e81 <generic_retkprobe_filter_arg+0x2e81>
    2731:      	movzwl	(%rbp), %esi
    2735:      	cmpl	%esi, %edx
    2737:      	jb	0x276 <generic_retkprobe_filter_arg+0x276>
    273d:      	cmpl	$0x11, %ecx
    2740:      	jb	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2746:      	movl	0x18(%r15), %edx
    274a:      	cmpl	$0x2, %eax
    274d:      	jle	0x295a <generic_retkprobe_filter_arg+0x295a>
    2753:      	leal	-0x3(%rax), %esi
    2756:      	cmpl	$0x2, %esi
    2759:      	jae	0x2ba5 <generic_retkprobe_filter_arg+0x2ba5>
    275f:      	movzwl	(%rbp), %esi
    2763:      	cmpl	%esi, %edx
    2765:      	jne	0x2d3f <generic_retkprobe_filter_arg+0x2d3f>
    276b:      	jmp	0x2e81 <generic_retkprobe_filter_arg+0x2e81>
    2770:      	cmpl	%edx, %r8d
    2773:      	setbe	%r8b
    2777:      	cmpl	%edi, %edx
    2779:      	setbe	%dil
    277d:      	andb	%r8b, %dil
    2780:      	orb	%dil, %al
    2783:      	cmpl	$0x21, %esi
    2786:      	jb	0x2aef <generic_retkprobe_filter_arg+0x2aef>
    278c:      	movl	0x28(%r15), %edi
    2790:      	movl	0x2c(%r15), %esi
    2794:      	cmpl	$0xc, %ecx
    2797:      	ja	0x2ae1 <generic_retkprobe_filter_arg+0x2ae1>
    279d:      	movl	$0x1402, %r8d           # imm = 0x1402
    27a3:      	btl	%ecx, %r8d
    27a7:      	jae	0x2ae1 <generic_retkprobe_filter_arg+0x2ae1>
    27ad:      	cmpl	%edx, %edi
    27af:      	setle	%cl
    27b2:      	cmpl	%esi, %edx
    27b4:      	setle	%dl
    27b7:      	jmp	0x2aeb <generic_retkprobe_filter_arg+0x2aeb>
    27bc:      	cmpl	%eax, %edi
    27be:      	movq	(%rsp), %rdi
    27c2:      	ja	0x27cc <generic_retkprobe_filter_arg+0x27cc>
    27c4:      	cmpl	%esi, %eax
    27c6:      	jbe	0x276 <generic_retkprobe_filter_arg+0x276>
    27cc:      	cmpl	$0x21, %edx
    27cf:      	jb	0xb8 <generic_retkprobe_filter_arg+0xb8>
    27d5:      	movl	0x28(%r15), %esi
    27d9:      	movl	0x2c(%r15), %edx
    27dd:      	cmpl	$0xc, %ecx
    27e0:      	ja	0x2bbf <generic_retkprobe_filter_arg+0x2bbf>
    27e6:      	movl	$0x1402, %r8d           # imm = 0x1402
    27ec:      	btl	%ecx, %r8d
    27f0:      	jae	0x2bbf <generic_retkprobe_filter_arg+0x2bbf>
    27f6:      	cmpl	%eax, %esi
    27f8:      	jg	0xb8 <generic_retkprobe_filter_arg+0xb8>
    27fe:      	cmpl	%edx, %eax
    2800:      	jle	0x276 <generic_retkprobe_filter_arg+0x276>
    2806:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
    280b:      	cmpl	%esi, (%rbp)
    280e:      	ja	0x276 <generic_retkprobe_filter_arg+0x276>
    2814:      	jmp	0x281f <generic_retkprobe_filter_arg+0x281f>
    2816:      	cmpl	%esi, (%rbp)
    2819:      	jb	0x276 <generic_retkprobe_filter_arg+0x276>
    281f:      	cmpl	$0x11, %edx
    2822:      	jb	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2828:      	movl	0x18(%r15), %esi
    282c:      	cmpl	$0x2, %eax
    282f:      	jle	0x284b <generic_retkprobe_filter_arg+0x284b>
    2831:      	leal	-0x3(%rax), %edi
    2834:      	cmpl	$0x2, %edi
    2837:      	jae	0x2880 <generic_retkprobe_filter_arg+0x2880>
    2839:      	cmpl	%esi, (%rbp)
    283c:      	movq	(%rsp), %rdi
    2840:      	jne	0x2d98 <generic_retkprobe_filter_arg+0x2d98>
    2846:      	jmp	0x2e81 <generic_retkprobe_filter_arg+0x2e81>
    284b:      	cmpl	$0x1, %eax
    284e:      	je	0x289b <generic_retkprobe_filter_arg+0x289b>
    2850:      	cmpl	$0x2, %eax
    2853:      	jne	0x2d98 <generic_retkprobe_filter_arg+0x2d98>
    2859:      	cmpl	$0xc, %ecx
    285c:      	ja	0x2d8f <generic_retkprobe_filter_arg+0x2d8f>
    2862:      	movl	$0x1402, %r8d           # imm = 0x1402
    2868:      	btl	%ecx, %r8d
    286c:      	jae	0x2d8f <generic_retkprobe_filter_arg+0x2d8f>
    2872:      	cmpl	%esi, (%rbp)
    2875:      	jl	0x276 <generic_retkprobe_filter_arg+0x276>
    287b:      	jmp	0x2d98 <generic_retkprobe_filter_arg+0x2d98>
    2880:      	cmpl	$0xc, %eax
    2883:      	movq	(%rsp), %rdi
    2887:      	jne	0x2d98 <generic_retkprobe_filter_arg+0x2d98>
    288d:      	testl	%esi, (%rbp)
    2890:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
    2896:      	jmp	0x2d98 <generic_retkprobe_filter_arg+0x2d98>
    289b:      	cmpl	$0xc, %ecx
    289e:      	ja	0x2d84 <generic_retkprobe_filter_arg+0x2d84>
    28a4:      	movl	$0x1402, %r8d           # imm = 0x1402
    28aa:      	btl	%ecx, %r8d
    28ae:      	jae	0x2d84 <generic_retkprobe_filter_arg+0x2d84>
    28b4:      	cmpl	%esi, (%rbp)
    28b7:      	jg	0x276 <generic_retkprobe_filter_arg+0x276>
    28bd:      	jmp	0x2d98 <generic_retkprobe_filter_arg+0x2d98>
    28c2:      	cmpq	%rdx, %rdi
    28c5:      	setbe	%cl
    28c8:      	cmpq	%rsi, %rdx
    28cb:      	jmp	0x2ae8 <generic_retkprobe_filter_arg+0x2ae8>
    28d0:      	cmpl	$0x2, %ebx
    28d3:      	je	0x2c17 <generic_retkprobe_filter_arg+0x2c17>
    28d9:      	cmpl	$0x3, %ebx
    28dc:      	jne	0x2c92 <generic_retkprobe_filter_arg+0x2c92>
    28e2:      	movl	$0x1, %eax
    28e7:      	leaq	0x38(%rsp), %rsi
    28ec:      	movq	(%rip), %rdi            # 0x28f3 <generic_retkprobe_filter_arg+0x28f3>
    28f3:      	jmp	0x2c3b <generic_retkprobe_filter_arg+0x2c3b>
    28f8:      	cmpl	$0x6, %ebx
    28fb:      	je	0x2c2a <generic_retkprobe_filter_arg+0x2c2a>
    2901:      	cmpl	$0x7, %ebx
    2904:      	jne	0x2c92 <generic_retkprobe_filter_arg+0x2c92>
    290a:      	movl	$0x1, %eax
    290f:      	leaq	0x38(%rsp), %rsi
    2914:      	movq	(%rip), %rdi            # 0x291b <generic_retkprobe_filter_arg+0x291b>
    291b:      	jmp	0x2c3b <generic_retkprobe_filter_arg+0x2c3b>
    2920:      	cmpq	%rax, %rsi
    2923:      	ja	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2929:      	cmpq	%rdx, %rax
    292c:      	jbe	0x276 <generic_retkprobe_filter_arg+0x276>
    2932:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2937:      	cmpl	$0x1, %eax
    293a:      	je	0x2ced <generic_retkprobe_filter_arg+0x2ced>
    2940:      	cmpl	$0x2, %eax
    2943:      	jne	0x2cf9 <generic_retkprobe_filter_arg+0x2cf9>
    2949:      	movzbl	(%rbp), %esi
    294d:      	cmpl	%esi, %edx
    294f:      	ja	0x276 <generic_retkprobe_filter_arg+0x276>
    2955:      	jmp	0x2cf9 <generic_retkprobe_filter_arg+0x2cf9>
    295a:      	cmpl	$0x1, %eax
    295d:      	je	0x2d33 <generic_retkprobe_filter_arg+0x2d33>
    2963:      	cmpl	$0x2, %eax
    2966:      	jne	0x2d3f <generic_retkprobe_filter_arg+0x2d3f>
    296c:      	movzwl	(%rbp), %esi
    2970:      	cmpl	%esi, %edx
    2972:      	ja	0x276 <generic_retkprobe_filter_arg+0x276>
    2978:      	jmp	0x2d3f <generic_retkprobe_filter_arg+0x2d3f>
    297d:      	movl	$0x1, %ebx
    2982:      	movq	(%rsp), %rdi
    2986:      	jmp	0x2ef2 <generic_retkprobe_filter_arg+0x2ef2>
    298b:      	movq	%rcx, %rbx
    298e:      	movw	%bp, (%rcx)
    2991:      	leaq	0x2(%rcx), %rdi
    2995:      	movl	$0x4, %eax
    299a:      	movq	0x20(%rsp), %rdx
    299f:      	movl	%ebp, %esi
    29a1:      	callq	*%rax
    29a3:      	movq	0x90(%rsp), %rsi
    29ab:      	subl	%ebp, %esi
    29ad:      	jbe	0x29c7 <generic_retkprobe_filter_arg+0x29c7>
    29af:      	leaq	(%rbx,%rbp), %rdi
    29b3:      	addq	$0x2, %rdi
    29b7:      	andl	$0xfff, %esi            # imm = 0xFFF
    29bd:      	movl	$0x4, %eax
    29c2:      	movq	%r12, %rdx
    29c5:      	callq	*%rax
    29c7:      	movl	0x88(%rsp), %eax
    29ce:      	movl	%eax, 0x38(%rsp)
    29d2:      	movl	0x18(%rsp), %eax
    29d6:      	cmpl	$0x3, %eax
    29d9:      	jg	0x2a0b <generic_retkprobe_filter_arg+0x2a0b>
    29db:      	cmpl	$0x1, %eax
    29de:      	leaq	0x38(%rsp), %rsi
    29e3:      	jg	0x2ca7 <generic_retkprobe_filter_arg+0x2ca7>
    29e9:      	testl	%eax, %eax
    29eb:      	je	0x2e8e <generic_retkprobe_filter_arg+0x2e8e>
    29f1:      	cmpl	$0x1, %eax
    29f4:      	jne	0x2ee2 <generic_retkprobe_filter_arg+0x2ee2>
    29fa:      	movl	$0x1, %eax
    29ff:      	movq	(%rip), %rdi            # 0x2a06 <generic_retkprobe_filter_arg+0x2a06>
    2a06:      	jmp	0x2ec4 <generic_retkprobe_filter_arg+0x2ec4>
    2a0b:      	cmpl	$0x5, %eax
    2a0e:      	leaq	0x38(%rsp), %rsi
    2a13:      	jg	0x2cca <generic_retkprobe_filter_arg+0x2cca>
    2a19:      	cmpl	$0x4, %eax
    2a1c:      	je	0x2e9c <generic_retkprobe_filter_arg+0x2e9c>
    2a22:      	cmpl	$0x5, %eax
    2a25:      	jne	0x2ee2 <generic_retkprobe_filter_arg+0x2ee2>
    2a2b:      	movl	$0x1, %eax
    2a30:      	movq	(%rip), %rdi            # 0x2a37 <generic_retkprobe_filter_arg+0x2a37>
    2a37:      	jmp	0x2ec4 <generic_retkprobe_filter_arg+0x2ec4>
    2a3c:      	movl	$0x1, %eax
    2a41:      	movq	(%rip), %rdi            # 0x2a48 <generic_retkprobe_filter_arg+0x2a48>
    2a48:      	leaq	0x38(%rsp), %rsi
    2a4d:      	jmp	0x2a86 <generic_retkprobe_filter_arg+0x2a86>
    2a4f:      	movl	$0x1, %eax
    2a54:      	leaq	0x38(%rsp), %rsi
    2a59:      	movq	(%rip), %rdi            # 0x2a60 <generic_retkprobe_filter_arg+0x2a60>
    2a60:      	jmp	0x2a86 <generic_retkprobe_filter_arg+0x2a86>
    2a62:      	movl	$0x1, %eax
    2a67:      	leaq	0x38(%rsp), %rsi
    2a6c:      	movq	(%rip), %rdi            # 0x2a73 <generic_retkprobe_filter_arg+0x2a73>
    2a73:      	jmp	0x2a86 <generic_retkprobe_filter_arg+0x2a86>
    2a75:      	movl	$0x1, %eax
    2a7a:      	leaq	0x38(%rsp), %rsi
    2a7f:      	movq	(%rip), %rdi            # 0x2a86 <generic_retkprobe_filter_arg+0x2a86>
    2a86:      	callq	*%rax
    2a88:      	testq	%rax, %rax
    2a8b:      	je	0x2aa6 <generic_retkprobe_filter_arg+0x2aa6>
    2a8d:      	movq	%rax, %rdi
    2a90:      	movl	$0x1, %eax
    2a95:      	movq	0x18(%rsp), %rsi
    2a9a:      	callq	*%rax
    2a9c:      	xorl	%ebx, %ebx
    2a9e:      	testq	%rax, %rax
    2aa1:      	setne	%bl
    2aa4:      	jmp	0x2aa8 <generic_retkprobe_filter_arg+0x2aa8>
    2aa6:      	xorl	%ebx, %ebx
    2aa8:      	movq	(%rsp), %rdi
    2aac:      	movq	0x8(%rsp), %r9
    2ab1:      	movq	0x10(%rsp), %r11
    2ab6:      	movl	0x4(%r15), %eax
    2aba:      	cmpq	$0x25, %rax
    2abe:      	ja	0x265 <generic_retkprobe_filter_arg+0x265>
    2ac4:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    2ace:      	btq	%rax, %rcx
    2ad2:      	jae	0x265 <generic_retkprobe_filter_arg+0x265>
    2ad8:      	xorq	$0x1, %rbx
    2adc:      	jmp	0x265 <generic_retkprobe_filter_arg+0x265>
    2ae1:      	cmpl	%edx, %edi
    2ae3:      	setbe	%cl
    2ae6:      	cmpl	%esi, %edx
    2ae8:      	setbe	%dl
    2aeb:      	andb	%cl, %dl
    2aed:      	orb	%dl, %al
    2aef:      	movq	(%rsp), %rdi
    2af3:      	testb	%al, %al
    2af5:      	je	0x276 <generic_retkprobe_filter_arg+0x276>
    2afb:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2b00:      	cmpq	%rsi, (%rbp)
    2b04:      	ja	0x276 <generic_retkprobe_filter_arg+0x276>
    2b0a:      	jmp	0x2b16 <generic_retkprobe_filter_arg+0x2b16>
    2b0c:      	cmpq	%rsi, (%rbp)
    2b10:      	jb	0x276 <generic_retkprobe_filter_arg+0x276>
    2b16:      	cmpl	$0x21, %edx
    2b19:      	jb	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2b1f:      	movq	0x28(%r15), %rdx
    2b23:      	cmpl	$0x2, %eax
    2b26:      	jle	0x2b51 <generic_retkprobe_filter_arg+0x2b51>
    2b28:      	leal	-0x3(%rax), %ecx
    2b2b:      	cmpl	$0x2, %ecx
    2b2e:      	jb	0x2b7c <generic_retkprobe_filter_arg+0x2b7c>
    2b30:      	cmpl	$0x6, %eax
    2b33:      	je	0x276 <generic_retkprobe_filter_arg+0x276>
    2b39:      	cmpl	$0xc, %eax
    2b3c:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2b42:      	testq	%rdx, (%rbp)
    2b46:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
    2b4c:      	jmp	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2b51:      	cmpl	$0x1, %eax
    2b54:      	je	0x2bd4 <generic_retkprobe_filter_arg+0x2bd4>
    2b56:      	cmpl	$0x2, %eax
    2b59:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2b5f:      	cmpl	$0xc, %ecx
    2b62:      	je	0x2b6d <generic_retkprobe_filter_arg+0x2b6d>
    2b64:      	cmpl	$0xa, %ecx
    2b67:      	jne	0x2f29 <generic_retkprobe_filter_arg+0x2f29>
    2b6d:      	cmpq	%rdx, (%rbp)
    2b71:      	jl	0x276 <generic_retkprobe_filter_arg+0x276>
    2b77:      	jmp	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2b7c:      	cmpq	%rdx, (%rbp)
    2b80:      	je	0x2e81 <generic_retkprobe_filter_arg+0x2e81>
    2b86:      	jmp	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2b8b:      	cmpl	$0xc, %eax
    2b8e:      	jne	0x2cf9 <generic_retkprobe_filter_arg+0x2cf9>
    2b94:      	movzbl	(%rbp), %esi
    2b98:      	testl	%esi, %edx
    2b9a:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
    2ba0:      	jmp	0x2cf9 <generic_retkprobe_filter_arg+0x2cf9>
    2ba5:      	cmpl	$0xc, %eax
    2ba8:      	jne	0x2d3f <generic_retkprobe_filter_arg+0x2d3f>
    2bae:      	movzwl	(%rbp), %esi
    2bb2:      	testl	%esi, %edx
    2bb4:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
    2bba:      	jmp	0x2d3f <generic_retkprobe_filter_arg+0x2d3f>
    2bbf:      	cmpl	%eax, %esi
    2bc1:      	ja	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2bc7:      	cmpl	%edx, %eax
    2bc9:      	jbe	0x276 <generic_retkprobe_filter_arg+0x276>
    2bcf:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2bd4:      	cmpl	$0xc, %ecx
    2bd7:      	je	0x2be2 <generic_retkprobe_filter_arg+0x2be2>
    2bd9:      	cmpl	$0xa, %ecx
    2bdc:      	jne	0x2f35 <generic_retkprobe_filter_arg+0x2f35>
    2be2:      	cmpq	%rdx, (%rbp)
    2be6:      	jg	0x276 <generic_retkprobe_filter_arg+0x276>
    2bec:      	jmp	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2bf1:      	movl	$0x1, %eax
    2bf6:      	movq	(%rip), %rdi            # 0x2bfd <generic_retkprobe_filter_arg+0x2bfd>
    2bfd:      	leaq	0x38(%rsp), %rsi
    2c02:      	jmp	0x2c3b <generic_retkprobe_filter_arg+0x2c3b>
    2c04:      	movl	$0x1, %eax
    2c09:      	leaq	0x38(%rsp), %rsi
    2c0e:      	movq	(%rip), %rdi            # 0x2c15 <generic_retkprobe_filter_arg+0x2c15>
    2c15:      	jmp	0x2c3b <generic_retkprobe_filter_arg+0x2c3b>
    2c17:      	movl	$0x1, %eax
    2c1c:      	leaq	0x38(%rsp), %rsi
    2c21:      	movq	(%rip), %rdi            # 0x2c28 <generic_retkprobe_filter_arg+0x2c28>
    2c28:      	jmp	0x2c3b <generic_retkprobe_filter_arg+0x2c3b>
    2c2a:      	movl	$0x1, %eax
    2c2f:      	leaq	0x38(%rsp), %rsi
    2c34:      	movq	(%rip), %rdi            # 0x2c3b <generic_retkprobe_filter_arg+0x2c3b>
    2c3b:      	callq	*%rax
    2c3d:      	testq	%rax, %rax
    2c40:      	je	0x2c5b <generic_retkprobe_filter_arg+0x2c5b>
    2c42:      	movq	%rax, %rdi
    2c45:      	movl	$0x1, %eax
    2c4a:      	movq	0x18(%rsp), %rsi
    2c4f:      	callq	*%rax
    2c51:      	xorl	%ebx, %ebx
    2c53:      	testq	%rax, %rax
    2c56:      	setne	%bl
    2c59:      	jmp	0x2c5d <generic_retkprobe_filter_arg+0x2c5d>
    2c5b:      	xorl	%ebx, %ebx
    2c5d:      	movq	(%rsp), %rdi
    2c61:      	movq	0x8(%rsp), %r9
    2c66:      	movq	0x10(%rsp), %r11
    2c6b:      	movl	0x4(%r15), %eax
    2c6f:      	cmpq	$0x25, %rax
    2c73:      	ja	0x265 <generic_retkprobe_filter_arg+0x265>
    2c79:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    2c83:      	btq	%rax, %rcx
    2c87:      	jb	0x2f19 <generic_retkprobe_filter_arg+0x2f19>
    2c8d:      	jmp	0x265 <generic_retkprobe_filter_arg+0x265>
    2c92:      	xorl	%ebx, %ebx
    2c94:      	movq	(%rsp), %rdi
    2c98:      	movl	0x4(%r15), %eax
    2c9c:      	cmpq	$0x25, %rax
    2ca0:      	jbe	0x2c79 <generic_retkprobe_filter_arg+0x2c79>
    2ca2:      	jmp	0x265 <generic_retkprobe_filter_arg+0x265>
    2ca7:      	cmpl	$0x2, %eax
    2caa:      	je	0x2eaa <generic_retkprobe_filter_arg+0x2eaa>
    2cb0:      	cmpl	$0x3, %eax
    2cb3:      	jne	0x2ee2 <generic_retkprobe_filter_arg+0x2ee2>
    2cb9:      	movl	$0x1, %eax
    2cbe:      	movq	(%rip), %rdi            # 0x2cc5 <generic_retkprobe_filter_arg+0x2cc5>
    2cc5:      	jmp	0x2ec4 <generic_retkprobe_filter_arg+0x2ec4>
    2cca:      	cmpl	$0x6, %eax
    2ccd:      	je	0x2eb8 <generic_retkprobe_filter_arg+0x2eb8>
    2cd3:      	cmpl	$0x7, %eax
    2cd6:      	jne	0x2ee2 <generic_retkprobe_filter_arg+0x2ee2>
    2cdc:      	movl	$0x1, %eax
    2ce1:      	movq	(%rip), %rdi            # 0x2ce8 <generic_retkprobe_filter_arg+0x2ce8>
    2ce8:      	jmp	0x2ec4 <generic_retkprobe_filter_arg+0x2ec4>
    2ced:      	movzbl	(%rbp), %esi
    2cf1:      	cmpl	%esi, %edx
    2cf3:      	jb	0x276 <generic_retkprobe_filter_arg+0x276>
    2cf9:      	cmpl	$0x15, %ecx
    2cfc:      	jb	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2d02:      	movl	0x1c(%r15), %ecx
    2d06:      	cmpl	$0x2, %eax
    2d09:      	jle	0x2e34 <generic_retkprobe_filter_arg+0x2e34>
    2d0f:      	leal	-0x3(%rax), %edx
    2d12:      	cmpl	$0x2, %edx
    2d15:      	jb	0x2e6f <generic_retkprobe_filter_arg+0x2e6f>
    2d1b:      	cmpl	$0x6, %eax
    2d1e:      	je	0x276 <generic_retkprobe_filter_arg+0x276>
    2d24:      	cmpl	$0xc, %eax
    2d27:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2d2d:      	movzbl	(%rbp), %edx
    2d31:      	jmp	0x2d77 <generic_retkprobe_filter_arg+0x2d77>
    2d33:      	movzwl	(%rbp), %esi
    2d37:      	cmpl	%esi, %edx
    2d39:      	jb	0x276 <generic_retkprobe_filter_arg+0x276>
    2d3f:      	cmpl	$0x15, %ecx
    2d42:      	jb	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2d48:      	movl	0x1c(%r15), %ecx
    2d4c:      	cmpl	$0x2, %eax
    2d4f:      	jle	0x2e4c <generic_retkprobe_filter_arg+0x2e4c>
    2d55:      	leal	-0x3(%rax), %edx
    2d58:      	cmpl	$0x2, %edx
    2d5b:      	jb	0x2e75 <generic_retkprobe_filter_arg+0x2e75>
    2d61:      	cmpl	$0x6, %eax
    2d64:      	je	0x276 <generic_retkprobe_filter_arg+0x276>
    2d6a:      	cmpl	$0xc, %eax
    2d6d:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2d73:      	movzwl	(%rbp), %edx
    2d77:      	testl	%edx, %ecx
    2d79:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
    2d7f:      	jmp	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2d84:      	cmpl	%esi, (%rbp)
    2d87:      	ja	0x276 <generic_retkprobe_filter_arg+0x276>
    2d8d:      	jmp	0x2d98 <generic_retkprobe_filter_arg+0x2d98>
    2d8f:      	cmpl	%esi, (%rbp)
    2d92:      	jb	0x276 <generic_retkprobe_filter_arg+0x276>
    2d98:      	cmpl	$0x15, %edx
    2d9b:      	jb	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2da1:      	movl	0x1c(%r15), %edx
    2da5:      	cmpl	$0x2, %eax
    2da8:      	jle	0x2dd2 <generic_retkprobe_filter_arg+0x2dd2>
    2daa:      	leal	-0x3(%rax), %ecx
    2dad:      	cmpl	$0x2, %ecx
    2db0:      	jb	0x2e05 <generic_retkprobe_filter_arg+0x2e05>
    2db2:      	cmpl	$0x6, %eax
    2db5:      	je	0x276 <generic_retkprobe_filter_arg+0x276>
    2dbb:      	cmpl	$0xc, %eax
    2dbe:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2dc4:      	testl	%edx, (%rbp)
    2dc7:      	jne	0x276 <generic_retkprobe_filter_arg+0x276>
    2dcd:      	jmp	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2dd2:      	cmpl	$0x1, %eax
    2dd5:      	je	0x2e0f <generic_retkprobe_filter_arg+0x2e0f>
    2dd7:      	cmpl	$0x2, %eax
    2dda:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2de0:      	cmpl	$0xc, %ecx
    2de3:      	ja	0x2f55 <generic_retkprobe_filter_arg+0x2f55>
    2de9:      	movl	$0x1402, %esi           # imm = 0x1402
    2dee:      	btl	%ecx, %esi
    2df1:      	jae	0x2f55 <generic_retkprobe_filter_arg+0x2f55>
    2df7:      	cmpl	%edx, (%rbp)
    2dfa:      	jl	0x276 <generic_retkprobe_filter_arg+0x276>
    2e00:      	jmp	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2e05:      	cmpl	%edx, (%rbp)
    2e08:      	je	0x2e81 <generic_retkprobe_filter_arg+0x2e81>
    2e0a:      	jmp	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2e0f:      	cmpl	$0xc, %ecx
    2e12:      	ja	0x2f60 <generic_retkprobe_filter_arg+0x2f60>
    2e18:      	movl	$0x1402, %esi           # imm = 0x1402
    2e1d:      	btl	%ecx, %esi
    2e20:      	jae	0x2f60 <generic_retkprobe_filter_arg+0x2f60>
    2e26:      	cmpl	%edx, (%rbp)
    2e29:      	jg	0x276 <generic_retkprobe_filter_arg+0x276>
    2e2f:      	jmp	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2e34:      	cmpl	$0x1, %eax
    2e37:      	je	0x2f41 <generic_retkprobe_filter_arg+0x2f41>
    2e3d:      	cmpl	$0x2, %eax
    2e40:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2e46:      	movzbl	(%rbp), %edx
    2e4a:      	jmp	0x2e62 <generic_retkprobe_filter_arg+0x2e62>
    2e4c:      	cmpl	$0x1, %eax
    2e4f:      	je	0x2f47 <generic_retkprobe_filter_arg+0x2f47>
    2e55:      	cmpl	$0x2, %eax
    2e58:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2e5e:      	movzwl	(%rbp), %edx
    2e62:      	cmpl	%edx, %ecx
    2e64:      	ja	0x276 <generic_retkprobe_filter_arg+0x276>
    2e6a:      	jmp	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2e6f:      	movzbl	(%rbp), %edx
    2e73:      	jmp	0x2e79 <generic_retkprobe_filter_arg+0x2e79>
    2e75:      	movzwl	(%rbp), %edx
    2e79:      	cmpl	%edx, %ecx
    2e7b:      	jne	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2e81:      	xorl	%ebx, %ebx
    2e83:      	cmpl	$0x3, %eax
    2e86:      	sete	%bl
    2e89:      	jmp	0x265 <generic_retkprobe_filter_arg+0x265>
    2e8e:      	movl	$0x1, %eax
    2e93:      	movq	(%rip), %rdi            # 0x2e9a <generic_retkprobe_filter_arg+0x2e9a>
    2e9a:      	jmp	0x2ec4 <generic_retkprobe_filter_arg+0x2ec4>
    2e9c:      	movl	$0x1, %eax
    2ea1:      	movq	(%rip), %rdi            # 0x2ea8 <generic_retkprobe_filter_arg+0x2ea8>
    2ea8:      	jmp	0x2ec4 <generic_retkprobe_filter_arg+0x2ec4>
    2eaa:      	movl	$0x1, %eax
    2eaf:      	movq	(%rip), %rdi            # 0x2eb6 <generic_retkprobe_filter_arg+0x2eb6>
    2eb6:      	jmp	0x2ec4 <generic_retkprobe_filter_arg+0x2ec4>
    2eb8:      	movl	$0x1, %eax
    2ebd:      	movq	(%rip), %rdi            # 0x2ec4 <generic_retkprobe_filter_arg+0x2ec4>
    2ec4:      	callq	*%rax
    2ec6:      	testq	%rax, %rax
    2ec9:      	je	0x2ee2 <generic_retkprobe_filter_arg+0x2ee2>
    2ecb:      	movq	%rax, %rdi
    2ece:      	movl	$0x1, %eax
    2ed3:      	movq	%rbx, %rsi
    2ed6:      	callq	*%rax
    2ed8:      	xorl	%ebx, %ebx
    2eda:      	testq	%rax, %rax
    2edd:      	setne	%bl
    2ee0:      	jmp	0x2ee4 <generic_retkprobe_filter_arg+0x2ee4>
    2ee2:      	xorl	%ebx, %ebx
    2ee4:      	movq	(%rsp), %rdi
    2ee8:      	movq	0x8(%rsp), %r9
    2eed:      	movq	0x10(%rsp), %r11
    2ef2:      	movl	0x4(%r15), %eax
    2ef6:      	cmpq	$0x25, %rax
    2efa:      	ja	0x260 <generic_retkprobe_filter_arg+0x260>
    2f00:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    2f0a:      	btq	%rax, %rcx
    2f0e:      	movq	0x68(%rsp), %r12
    2f13:      	jae	0x265 <generic_retkprobe_filter_arg+0x265>
    2f19:      	xorl	%eax, %eax
    2f1b:      	testq	%rbx, %rbx
    2f1e:      	sete	%al
    2f21:      	movq	%rax, %rbx
    2f24:      	jmp	0x265 <generic_retkprobe_filter_arg+0x265>
    2f29:      	cmpq	%rdx, (%rbp)
    2f2d:      	jb	0x276 <generic_retkprobe_filter_arg+0x276>
    2f33:      	jmp	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2f35:      	cmpq	%rdx, (%rbp)
    2f39:      	ja	0x276 <generic_retkprobe_filter_arg+0x276>
    2f3f:      	jmp	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2f41:      	movzbl	(%rbp), %edx
    2f45:      	jmp	0x2f4b <generic_retkprobe_filter_arg+0x2f4b>
    2f47:      	movzwl	(%rbp), %edx
    2f4b:      	cmpl	%edx, %ecx
    2f4d:      	jb	0x276 <generic_retkprobe_filter_arg+0x276>
    2f53:      	jmp	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2f55:      	cmpl	%edx, (%rbp)
    2f58:      	jb	0x276 <generic_retkprobe_filter_arg+0x276>
    2f5e:      	jmp	0x2f69 <generic_retkprobe_filter_arg+0x2f69>
    2f60:      	cmpl	%edx, (%rbp)
    2f63:      	ja	0x276 <generic_retkprobe_filter_arg+0x276>
    2f69:      	orl	$0x2, %eax
    2f6c:      	cmpl	$0x6, %eax
    2f6f:      	je	0x276 <generic_retkprobe_filter_arg+0x276>
    2f75:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2f7a:      	nopw	(%rax,%rax)

0000000000002f80 <generic_retkprobe_actions>:
    2f80:      	pushq	%rbp
    2f81:      	pushq	%r15
    2f83:      	pushq	%r14
    2f85:      	pushq	%r13
    2f87:      	pushq	%r12
    2f89:      	pushq	%rbx
    2f8a:      	subq	$0xa8, %rsp
    2f91:      	movq	%rdi, 0x80(%rsp)
    2f99:      	movl	$0x0, 0x88(%rsp)
    2fa4:      	movq	(%rip), %rdi            # 0x2fab <generic_retkprobe_actions+0x2b>
    2fab:      	leaq	0x88(%rsp), %rsi
    2fb3:      	movl	$0x1, %eax
    2fb8:      	callq	*%rax
    2fba:      	testq	%rax, %rax
    2fbd:      	je	0x3aa8 <generic_retkprobe_actions+0xb28>
    2fc3:      	movq	%rax, %rsi
    2fc6:      	movl	0x5f04(%rax), %ebx
    2fcc:      	cmpl	$0x2, %ebx
    2fcf:      	jl	0x3aa8 <generic_retkprobe_actions+0xb28>
    2fd5:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    2fdc:      	movq	(%rip), %rdi            # 0x2fe3 <generic_retkprobe_actions+0x63>
    2fe3:      	movl	$0x1, %eax
    2fe8:      	callq	*%rax
    2fea:      	testq	%rax, %rax
    2fed:      	je	0x3aa8 <generic_retkprobe_actions+0xb28>
    2ff3:      	movq	%rax, %r14
    2ff6:      	movl	%ebx, %eax
    2ff8:      	andl	$0x7ff, %eax            # imm = 0x7FF
    2ffd:      	addl	(%r14,%rax), %ebx
    3001:      	movl	$0x0, 0x8c(%rsp)
    300c:      	movq	(%rip), %rdi            # 0x3013 <generic_retkprobe_actions+0x93>
    3013:      	leaq	0x8c(%rsp), %rsi
    301b:      	movl	$0x1, %eax
    3020:      	andl	$0x7ff, %ebx            # imm = 0x7FF
    3026:      	callq	*%rax
    3028:      	testq	%rax, %rax
    302b:      	je	0x3052 <generic_retkprobe_actions+0xd2>
    302d:      	cmpb	$0x0, (%rax)
    3030:      	sete	0x17(%rsp)
    3035:      	je	0x306d <generic_retkprobe_actions+0xed>
    3037:      	movl	$0x5, %eax
    303c:      	movq	%rax, 0x78(%rsp)
    3041:      	movl	$0x9, %eax
    3046:      	movq	%rax, 0x70(%rsp)
    304b:      	movl	$0x7, %eax
    3050:      	jmp	0x3086 <generic_retkprobe_actions+0x106>
    3052:      	movl	$0x4, %eax
    3057:      	movq	%rax, 0x78(%rsp)
    305c:      	movl	$0x8, %eax
    3061:      	movq	%rax, 0x70(%rsp)
    3066:      	movb	$0x1, 0x17(%rsp)
    306b:      	jmp	0x3081 <generic_retkprobe_actions+0x101>
    306d:      	movl	$0x4, %eax
    3072:      	movq	%rax, 0x78(%rsp)
    3077:      	movl	$0x8, %eax
    307c:      	movq	%rax, 0x70(%rsp)
    3081:      	movl	$0x6, %eax
    3086:      	movq	%rax, 0x68(%rsp)
    308b:      	addq	%rbx, %r14
    308e:      	movb	$0x1, %al
    3090:      	movl	%eax, 0x44(%rsp)
    3094:      	movq	(%rip), %rbp            # 0x309b <generic_retkprobe_actions+0x11b>
    309b:      	xorl	%r12d, %r12d
    309e:      	xorl	%r15d, %r15d
    30a1:      	jmp	0x30ca <generic_retkprobe_actions+0x14a>
    30a3:      	incl	%r15d
    30a6:      	movl	0x4(%r14,%r15,4), %eax
    30ab:      	movl	%eax, 0x78(%rdx)
    30ae:      	nop
    30b0:      	movq	%r13, 0x70(%rdx)
    30b4:      	incl	%r15d
    30b7:      	movl	%r15d, %ebx
    30ba:      	incl	%r12d
    30bd:      	movl	%ebx, %r15d
    30c0:      	cmpl	$0x3, %r12d
    30c4:      	je	0x3a81 <generic_retkprobe_actions+0xb01>
    30ca:      	leal	0x4(,%r15,4), %eax
    30d2:      	cmpl	(%r14), %eax
    30d5:      	jae	0x3a81 <generic_retkprobe_actions+0xb01>
    30db:      	movl	%r15d, %eax
    30de:      	movslq	0x4(%r14,%rax,4), %r13
    30e3:      	movl	$0x0, 0x90(%rsp)
    30ee:      	movl	$0x1, %eax
    30f3:      	leaq	0x90(%rsp), %rsi
    30fb:      	movq	%rbp, %rdi
    30fe:      	callq	*%rax
    3100:      	xorl	%ebx, %ebx
    3102:      	testq	%rax, %rax
    3105:      	je	0x30ba <generic_retkprobe_actions+0x13a>
    3107:      	movq	%rax, %rdx
    310a:      	cmpl	$0x7, %r13d
    310e:      	jg	0x3140 <generic_retkprobe_actions+0x1c0>
    3110:      	cmpl	$0x3, %r13d
    3114:      	jg	0x3196 <generic_retkprobe_actions+0x216>
    311a:      	cmpl	$0x1, %r13d
    311e:      	jg	0x32e7 <generic_retkprobe_actions+0x367>
    3124:      	testl	%r13d, %r13d
    3127:      	je	0x34f7 <generic_retkprobe_actions+0x577>
    312d:      	cmpl	$0x1, %r13d
    3131:      	je	0x3300 <generic_retkprobe_actions+0x380>
    3137:      	jmp	0x30b0 <generic_retkprobe_actions+0x130>
    313c:      	nopl	(%rax)
    3140:      	cmpl	$0xb, %r13d
    3144:      	jg	0x32b0 <generic_retkprobe_actions+0x330>
    314a:      	leal	-0xa(%r13), %eax
    314e:      	cmpl	$0x2, %eax
    3151:      	jb	0x338f <generic_retkprobe_actions+0x40f>
    3157:      	cmpl	$0x8, %r13d
    315b:      	je	0x3451 <generic_retkprobe_actions+0x4d1>
    3161:      	cmpl	$0x9, %r13d
    3165:      	jne	0x30b0 <generic_retkprobe_actions+0x130>
    316b:      	movq	%r13, 0x8(%rsp)
    3170:      	movq	%r14, %rax
    3173:      	movq	%rbp, %r13
    3176:      	incl	%r15d
    3179:      	movl	0x4(%r14,%r15,4), %eax
    317e:      	movq	%rdx, %rbp
    3181:      	movl	$0x3, %ebx
    3186:      	cmpb	$0x0, 0x17(%rsp)
    318b:      	jne	0x35d3 <generic_retkprobe_actions+0x653>
    3191:      	jmp	0x35f8 <generic_retkprobe_actions+0x678>
    3196:      	leal	-0x6(%r13), %eax
    319a:      	cmpl	$0x2, %eax
    319d:      	jb	0x30a3 <generic_retkprobe_actions+0x123>
    31a3:      	cmpl	$0x4, %r13d
    31a7:      	je	0x345e <generic_retkprobe_actions+0x4de>
    31ad:      	cmpl	$0x5, %r13d
    31b1:      	jne	0x30b0 <generic_retkprobe_actions+0x130>
    31b7:      	leal	0x1(%r15), %eax
    31bb:      	movl	0x4(%r14,%rax,4), %eax
    31c0:      	addl	$0x2, %r15d
    31c4:      	movl	0x4(%r14,%r15,4), %ebx
    31c9:      	movq	$0x0, 0x20(%rsp)
    31d2:      	movq	$0x0, 0x18(%rsp)
    31db:      	andl	$0x7, %eax
    31de:      	cmpl	$0x4, %eax
    31e1:      	ja	0x30b0 <generic_retkprobe_actions+0x130>
    31e7:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    31ef:      	jne	0x30b0 <generic_retkprobe_actions+0x130>
    31f5:      	movq	0x5e78(%rdx,%rax,8), %rax
    31fd:      	andl	$0x7ff, %eax            # imm = 0x7FF
    3202:      	movl	0x90(%rdx,%rax), %eax
    3209:      	movl	%eax, 0x20(%rsp)
    320d:      	movl	$0xe, %eax
    3212:      	movq	%rdx, 0x8(%rsp)
    3217:      	callq	*%rax
    3219:      	shrq	$0x20, %rax
    321d:      	movq	%rax, 0x18(%rsp)
    3222:      	movl	$0x1, %eax
    3227:      	leaq	0x18(%rsp), %rsi
    322c:      	movq	(%rip), %rdi            # 0x3233 <generic_retkprobe_actions+0x2b3>
    3233:      	callq	*%rax
    3235:      	movq	0x8(%rsp), %rdx
    323a:      	testq	%rax, %rax
    323d:      	je	0x30b0 <generic_retkprobe_actions+0x130>
    3243:      	andl	$0x7, %ebx
    3246:      	cmpl	$0x4, %ebx
    3249:      	ja	0x30b0 <generic_retkprobe_actions+0x130>
    324f:      	cmpl	$0x0, 0x5ea0(%rdx,%rbx,4)
    3257:      	jne	0x30b0 <generic_retkprobe_actions+0x130>
    325d:      	movq	0x5e78(%rdx,%rbx,8), %rcx
    3265:      	movl	$0x0, 0x24(%rsp)
    326d:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    3273:      	movl	0x90(%rdx,%rcx), %ecx
    327a:      	movl	%ecx, 0x20(%rsp)
    327e:      	movq	%rax, %rbx
    3281:      	movl	$0xe, %eax
    3286:      	callq	*%rax
    3288:      	shrq	$0x20, %rax
    328c:      	movq	%rax, 0x18(%rsp)
    3291:      	movl	$0x2, %eax
    3296:      	xorl	%ecx, %ecx
    3298:      	leaq	0x18(%rsp), %rsi
    329d:      	movq	(%rip), %rdi            # 0x32a4 <generic_retkprobe_actions+0x324>
    32a4:      	movq	%rbx, %rdx
    32a7:      	xorl	%ecx, %ecx
    32a9:      	callq	*%rax
    32ab:      	jmp	0x34ed <generic_retkprobe_actions+0x56d>
    32b0:      	cmpl	$0xc, %r13d
    32b4:      	je	0x35e4 <generic_retkprobe_actions+0x664>
    32ba:      	cmpl	$0xd, %r13d
    32be:      	je	0x3476 <generic_retkprobe_actions+0x4f6>
    32c4:      	cmpl	$0xe, %r13d
    32c8:      	jne	0x30b0 <generic_retkprobe_actions+0x130>
    32ce:      	movq	%r13, 0x8(%rsp)
    32d3:      	movq	%rbp, %r13
    32d6:      	movq	%rdx, %rbp
    32d9:      	addl	$0x2, %r15d
    32dd:      	movq	0x70(%rsp), %rbx
    32e2:      	jmp	0x35f8 <generic_retkprobe_actions+0x678>
    32e7:      	movl	$0x9, %eax
    32ec:      	cmpl	$0x2, %r13d
    32f0:      	je	0x35bc <generic_retkprobe_actions+0x63c>
    32f6:      	cmpl	$0x3, %r13d
    32fa:      	jne	0x30b0 <generic_retkprobe_actions+0x130>
    3300:      	movq	%rdx, 0x8(%rsp)
    3305:      	leal	0x1(%r15), %eax
    3309:      	movq	%r14, %rcx
    330c:      	movl	0x4(%r14,%rax,4), %r14d
    3311:      	addl	$0x2, %r15d
    3315:      	movq	%rcx, %rbp
    3318:      	movl	0x4(%rcx,%r15,4), %eax
    331d:      	movq	%rax, 0x38(%rsp)
    3322:      	movq	$0x0, 0x20(%rsp)
    332b:      	movq	$0x0, 0x18(%rsp)
    3334:      	movl	$0x0, 0x28(%rsp)
    333c:      	movl	$0x1, %eax
    3341:      	leaq	0x28(%rsp), %rsi
    3346:      	movq	(%rip), %rdi            # 0x334d <generic_retkprobe_actions+0x3cd>
    334d:      	callq	*%rax
    334f:      	xorl	%ecx, %ecx
    3351:      	testq	%rax, %rax
    3354:      	je	0x3788 <generic_retkprobe_actions+0x808>
    335a:      	andl	$0x7, %r14d
    335e:      	cmpl	$0x4, %r14d
    3362:      	movq	0x8(%rsp), %rdx
    3367:      	ja	0x3378 <generic_retkprobe_actions+0x3f8>
    3369:      	cmpl	$0x0, 0x5ea0(%rdx,%r14,4)
    3372:      	je	0x362d <generic_retkprobe_actions+0x6ad>
    3378:      	movq	%rbp, %r14
    337b:      	movq	(%rip), %rbp            # 0x3382 <generic_retkprobe_actions+0x402>
    3382:      	testl	%ecx, %ecx
    3384:      	jne	0x30ba <generic_retkprobe_actions+0x13a>
    338a:      	jmp	0x30b0 <generic_retkprobe_actions+0x130>
    338f:      	incl	%r15d
    3392:      	movl	0x4(%r14,%r15,4), %eax
    3397:      	andl	$0x7, %eax
    339a:      	xorl	%ecx, %ecx
    339c:      	cmpl	$0x4, %eax
    339f:      	ja	0x3797 <generic_retkprobe_actions+0x817>
    33a5:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    33ad:      	jne	0x3797 <generic_retkprobe_actions+0x817>
    33b3:      	movq	0x5e78(%rdx,%rax,8), %rax
    33bb:      	andl	$0x7ff, %eax            # imm = 0x7FF
    33c0:      	movq	0xb8(%rdx,%rax), %rax
    33c8:      	movq	%rax, 0x28(%rsp)
    33cd:      	testq	%rax, %rax
    33d0:      	je	0x3797 <generic_retkprobe_actions+0x817>
    33d6:      	movq	%rdx, 0x8(%rsp)
    33db:      	cmpl	$0xa, %r13d
    33df:      	jne	0x37a4 <generic_retkprobe_actions+0x824>
    33e5:      	movl	$0xe, %eax
    33ea:      	callq	*%rax
    33ec:      	movq	%rax, 0x38(%rsp)
    33f1:      	shrq	$0x20, %rax
    33f5:      	movl	%eax, 0x18(%rsp)
    33f9:      	movl	$0x1, %eax
    33fe:      	leaq	0x18(%rsp), %rsi
    3403:      	movq	(%rip), %rdi            # 0x340a <generic_retkprobe_actions+0x48a>
    340a:      	callq	*%rax
    340c:      	xorl	%ecx, %ecx
    340e:      	testq	%rax, %rax
    3411:      	movq	0x8(%rsp), %rdx
    3416:      	je	0x3797 <generic_retkprobe_actions+0x817>
    341c:      	movl	(%rax), %ecx
    341e:      	movl	%ecx, 0x18(%rsp)
    3422:      	movq	0x38(%rsp), %rcx
    3427:      	movl	%ecx, 0x1c(%rsp)
    342b:      	movq	0x8(%rax), %rax
    342f:      	movq	%rax, 0x20(%rsp)
    3434:      	xorl	%ecx, %ecx
    3436:      	movl	$0x2, %eax
    343b:      	leaq	0x28(%rsp), %rsi
    3440:      	leaq	0x18(%rsp), %rdx
    3445:      	movq	(%rip), %rdi            # 0x344c <generic_retkprobe_actions+0x4cc>
    344c:      	jmp	0x36f0 <generic_retkprobe_actions+0x770>
    3451:      	movl	$0x0, 0x44(%rsp)
    3459:      	jmp	0x30b0 <generic_retkprobe_actions+0x130>
    345e:      	movq	%r13, 0x8(%rsp)
    3463:      	movq	%rbp, %r13
    3466:      	movq	%rdx, %rbp
    3469:      	incl	%r15d
    346c:      	movq	0x78(%rsp), %rbx
    3471:      	jmp	0x35f8 <generic_retkprobe_actions+0x678>
    3476:      	movq	%rdx, 0x8(%rsp)
    347b:      	movl	$0xe, %eax
    3480:      	callq	*%rax
    3482:      	movq	%rax, 0x50(%rsp)
    3487:      	movl	$0x1, %eax
    348c:      	leaq	0x50(%rsp), %rsi
    3491:      	movq	(%rip), %rdi            # 0x3498 <generic_retkprobe_actions+0x518>
    3498:      	callq	*%rax
    349a:      	testq	%rax, %rax
    349d:      	je	0x34ed <generic_retkprobe_actions+0x56d>
    349f:      	movq	0x4(%rax), %rax
    34a3:      	movq	%rax, 0x28(%rsp)
    34a8:      	movl	$0x2, 0x30(%rsp)
    34b0:      	movl	$0x1, %eax
    34b5:      	leaq	0x28(%rsp), %rsi
    34ba:      	movq	(%rip), %rbx            # 0x34c1 <generic_retkprobe_actions+0x541>
    34c1:      	movq	%rbx, %rdi
    34c4:      	callq	*%rax
    34c6:      	movl	$0x1, 0x5c(%rsp)
    34ce:      	testq	%rax, %rax
    34d1:      	je	0x3708 <generic_retkprobe_actions+0x788>
    34d7:      	lock
    34d8:      	incl	(%rax)
    34da:      	movl	$0x3, %eax
    34df:      	leaq	0x50(%rsp), %rsi
    34e4:      	movq	(%rip), %rdi            # 0x34eb <generic_retkprobe_actions+0x56b>
    34eb:      	callq	*%rax
    34ed:      	movq	0x8(%rsp), %rdx
    34f2:      	jmp	0x30b0 <generic_retkprobe_actions+0x130>
    34f7:      	movq	%rdx, 0x8(%rsp)
    34fc:      	leal	0x1(%r15), %eax
    3500:      	movl	0x4(%r14,%rax,4), %ebx
    3505:      	leal	0x2(%r15), %eax
    3509:      	movl	0x4(%r14,%rax,4), %eax
    350e:      	movl	%eax, 0x60(%rsp)
    3512:      	movl	$0x7d, %eax
    3517:      	callq	*%rax
    3519:      	movq	%rax, 0x18(%rsp)
    351e:      	movl	$0x0, 0x50(%rsp)
    3526:      	movq	%rbx, 0xa0(%rsp)
    352e:      	testq	%rbx, %rbx
    3531:      	je	0x39a8 <generic_retkprobe_actions+0xa28>
    3537:      	movl	$0x1, %eax
    353c:      	movq	(%rip), %rdi            # 0x3543 <generic_retkprobe_actions+0x5c3>
    3543:      	leaq	0x50(%rsp), %rsi
    3548:      	callq	*%rax
    354a:      	testq	%rax, %rax
    354d:      	je	0x39a8 <generic_retkprobe_actions+0xa28>
    3553:      	movq	%rax, 0x48(%rsp)
    3558:      	movq	%rax, %rbx
    355b:      	movl	$0x1, %eax
    3560:      	leaq	0x50(%rsp), %rsi
    3565:      	movq	(%rip), %rdi            # 0x356c <generic_retkprobe_actions+0x5ec>
    356c:      	callq	*%rax
    356e:      	movq	%rax, %rdx
    3571:      	movq	0x8(%rsp), %rcx
    3576:      	movq	0x60(%rcx), %rax
    357a:      	movq	%rax, (%rbx)
    357d:      	movq	0x70(%rcx), %rax
    3581:      	movq	%rax, 0x8(%rbx)
    3585:      	xorl	%eax, %eax
    3587:      	movq	%rax, 0x38(%rsp)
    358c:      	movl	$0x0, %eax
    3591:      	movl	0x60(%rsp), %esi
    3595:      	cmpl	$0x2, %esi
    3598:      	je	0x37cf <generic_retkprobe_actions+0x84f>
    359e:      	cmpl	$0x1, %esi
    35a1:      	je	0x37cc <generic_retkprobe_actions+0x84c>
    35a7:      	testl	%esi, %esi
    35a9:      	jne	0x39a8 <generic_retkprobe_actions+0xa28>
    35af:      	movq	0x8(%rsp), %rax
    35b4:      	movl	0x7c(%rax), %eax
    35b7:      	jmp	0x37cf <generic_retkprobe_actions+0x84f>
    35bc:      	movq	%r13, 0x8(%rsp)
    35c1:      	movq	%rbp, %r13
    35c4:      	movq	%rdx, %rbp
    35c7:      	movl	$0x3, %ebx
    35cc:      	cmpb	$0x0, 0x17(%rsp)
    35d1:      	je	0x35f8 <generic_retkprobe_actions+0x678>
    35d3:      	movslq	%eax, %rdi
    35d6:      	movl	$0x6d, %eax
    35db:      	callq	*%rax
    35dd:      	movl	$0x2, %ebx
    35e2:      	jmp	0x35f8 <generic_retkprobe_actions+0x678>
    35e4:      	movq	%r13, 0x8(%rsp)
    35e9:      	movq	%rbp, %r13
    35ec:      	movq	%rdx, %rbp
    35ef:      	addl	$0x3, %r15d
    35f3:      	movq	0x68(%rsp), %rbx
    35f8:      	movl	$0x0, 0x18(%rsp)
    3600:      	movl	$0x1, %eax
    3605:      	leaq	0x18(%rsp), %rsi
    360a:      	movq	(%rip), %rdi            # 0x3611 <generic_retkprobe_actions+0x691>
    3611:      	callq	*%rax
    3613:      	testq	%rax, %rax
    3616:      	je	0x361d <generic_retkprobe_actions+0x69d>
    3618:      	lock
    3619:      	incq	(%rax,%rbx,8)
    361d:      	movq	%rbp, %rdx
    3620:      	movq	%r13, %rbp
    3623:      	movq	0x8(%rsp), %r13
    3628:      	jmp	0x30b0 <generic_retkprobe_actions+0x130>
    362d:      	movq	%rax, 0x48(%rsp)
    3632:      	movq	0x5e78(%rdx,%r14,8), %rax
    363a:      	movl	$0x0, 0x24(%rsp)
    3642:      	andl	$0x7ff, %eax            # imm = 0x7FF
    3647:      	movl	0x90(%rdx,%rax), %eax
    364e:      	movl	%eax, 0x20(%rsp)
    3652:      	movl	$0xe, %eax
    3657:      	callq	*%rax
    3659:      	shrq	$0x20, %rax
    365d:      	movq	%rax, 0x18(%rsp)
    3662:      	cmpl	$0x1, %r13d
    3666:      	jne	0x3772 <generic_retkprobe_actions+0x7f2>
    366c:      	movq	0x38(%rsp), %rax
    3671:      	andl	$0x7, %eax
    3674:      	cmpl	$0x4, %eax
    3677:      	movq	%rbp, %r14
    367a:      	movl	$0x0, %ecx
    367f:      	ja	0x378b <generic_retkprobe_actions+0x80b>
    3685:      	movq	0x8(%rsp), %rdx
    368a:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    3692:      	movq	(%rip), %rbp            # 0x3699 <generic_retkprobe_actions+0x719>
    3699:      	jne	0x3797 <generic_retkprobe_actions+0x817>
    369f:      	movq	0x5e78(%rdx,%rax,8), %rax
    36a7:      	andl	$0x7ff, %eax            # imm = 0x7FF
    36ac:      	addq	%rax, %rdx
    36af:      	addq	$0x90, %rdx
    36b6:      	movq	0x8(%rsp), %rcx
    36bb:      	movl	0x90(%rcx,%rax), %esi
    36c2:      	andl	$0xfff, %esi            # imm = 0xFFF
    36c8:      	addq	$0x8, %rsi
    36cc:      	movl	$0x4, %eax
    36d1:      	movq	0x48(%rsp), %rdi
    36d6:      	callq	*%rax
    36d8:      	xorl	%ecx, %ecx
    36da:      	movl	$0x2, %eax
    36df:      	leaq	0x18(%rsp), %rsi
    36e4:      	movq	(%rip), %rdi            # 0x36eb <generic_retkprobe_actions+0x76b>
    36eb:      	movq	0x48(%rsp), %rdx
    36f0:      	xorl	%ecx, %ecx
    36f2:      	callq	*%rax
    36f4:      	xorl	%ecx, %ecx
    36f6:      	movq	0x8(%rsp), %rdx
    36fb:      	testl	%ecx, %ecx
    36fd:      	jne	0x30ba <generic_retkprobe_actions+0x13a>
    3703:      	jmp	0x30b0 <generic_retkprobe_actions+0x130>
    3708:      	movl	$0x2, %eax
    370d:      	movl	$0x1, %ecx
    3712:      	leaq	0x5c(%rsp), %rdx
    3717:      	leaq	0x28(%rsp), %rsi
    371c:      	movq	%rbx, %rdi
    371f:      	callq	*%rax
    3721:      	testq	%rax, %rax
    3724:      	je	0x34da <generic_retkprobe_actions+0x55a>
    372a:      	movq	%rax, 0x38(%rsp)
    372f:      	negl	%eax
    3731:      	movw	%ax, 0x18(%rsp)
    3736:      	movw	$0x3, 0x1a(%rsp)
    373d:      	movabsq	$0x20000003b, %rax      # imm = 0x20000003B
    3747:      	movq	%rax, 0x1c(%rsp)
    374c:      	movl	$0x1, %eax
    3751:      	leaq	0x18(%rsp), %rsi
    3756:      	movq	(%rip), %rbx            # 0x375d <generic_retkprobe_actions+0x7dd>
    375d:      	movq	%rbx, %rdi
    3760:      	callq	*%rax
    3762:      	testq	%rax, %rax
    3765:      	je	0x3a28 <generic_retkprobe_actions+0xaa8>
    376b:      	incl	(%rax)
    376d:      	jmp	0x3a4e <generic_retkprobe_actions+0xace>
    3772:      	movl	$0x3, %eax
    3777:      	leaq	0x18(%rsp), %rsi
    377c:      	movq	(%rip), %rdi            # 0x3783 <generic_retkprobe_actions+0x803>
    3783:      	callq	*%rax
    3785:      	movq	%rax, %rcx
    3788:      	movq	%rbp, %r14
    378b:      	movq	(%rip), %rbp            # 0x3792 <generic_retkprobe_actions+0x812>
    3792:      	movq	0x8(%rsp), %rdx
    3797:      	testl	%ecx, %ecx
    3799:      	jne	0x30ba <generic_retkprobe_actions+0x13a>
    379f:      	jmp	0x30b0 <generic_retkprobe_actions+0x130>
    37a4:      	movl	$0x3, %eax
    37a9:      	leaq	0x28(%rsp), %rsi
    37ae:      	movq	(%rip), %rdi            # 0x37b5 <generic_retkprobe_actions+0x835>
    37b5:      	callq	*%rax
    37b7:      	movq	%rax, %rcx
    37ba:      	movq	0x8(%rsp), %rdx
    37bf:      	testl	%ecx, %ecx
    37c1:      	jne	0x30ba <generic_retkprobe_actions+0x13a>
    37c7:      	jmp	0x30b0 <generic_retkprobe_actions+0x130>
    37cc:      	movl	0x10(%rcx), %eax
    37cf:      	movq	%r14, 0x60(%rsp)
    37d4:      	movl	%eax, %eax
    37d6:      	movq	%rbx, 0x98(%rsp)
    37de:      	movq	%rax, 0x10(%rbx)
    37e2:      	movq	0x48(%rsp), %rdi
    37e7:      	addq	$0x18, %rdi
    37eb:      	movl	$0x4, %eax
    37f0:      	movl	$0xc8, %ecx
    37f5:      	movq	%rdi, 0x48(%rsp)
    37fa:      	movl	$0xc8, %esi
    37ff:      	callq	*%rax
    3801:      	xorl	%r14d, %r14d
    3804:      	leaq	0x28(%rsp), %rbx
    3809:      	jmp	0x3823 <generic_retkprobe_actions+0x8a3>
    380b:      	nopl	(%rax,%rax)
    3810:      	leaq	0x28(%rsp), %rbx
    3815:      	addq	$0x4, %r14
    3819:      	cmpq	$0x14, %r14
    381d:      	je	0x394b <generic_retkprobe_actions+0x9cb>
    3823:      	movl	$0x0, 0x28(%rsp)
    382b:      	movl	$0x1, %eax
    3830:      	movq	%rbp, %rdi
    3833:      	movq	%rbx, %rsi
    3836:      	callq	*%rax
    3838:      	testq	%rax, %rax
    383b:      	je	0x394b <generic_retkprobe_actions+0x9cb>
    3841:      	movq	%rax, %rsi
    3844:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    384b:      	movl	$0x1, %eax
    3850:      	movq	(%rip), %rdi            # 0x3857 <generic_retkprobe_actions+0x8d7>
    3857:      	callq	*%rax
    3859:      	testq	%rax, %rax
    385c:      	je	0x394b <generic_retkprobe_actions+0x9cb>
    3862:      	cmpl	$-0x1, 0x40(%rax,%r14)
    3868:      	movq	0x8(%rsp), %rdx
    386d:      	je	0x394b <generic_retkprobe_actions+0x9cb>
    3873:      	movq	0x5e78(%rdx,%r14,2), %rax
    387b:      	movl	0x4(%rdx), %ecx
    387e:      	cmpq	%rcx, %rax
    3881:      	jge	0x394b <generic_retkprobe_actions+0x9cb>
    3887:      	cmpq	$0x10, %r14
    388b:      	je	0x38f2 <generic_retkprobe_actions+0x972>
    388d:      	movl	$0x0, 0x28(%rsp)
    3895:      	movl	$0x1, %eax
    389a:      	movq	%rbp, %rdi
    389d:      	movq	%rbx, %rsi
    38a0:      	callq	*%rax
    38a2:      	testq	%rax, %rax
    38a5:      	je	0x38e5 <generic_retkprobe_actions+0x965>
    38a7:      	movq	%rax, %rsi
    38aa:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    38b1:      	movl	$0x1, %eax
    38b6:      	movq	(%rip), %rdi            # 0x38bd <generic_retkprobe_actions+0x93d>
    38bd:      	callq	*%rax
    38bf:      	testq	%rax, %rax
    38c2:      	je	0x38e5 <generic_retkprobe_actions+0x965>
    38c4:      	cmpl	$-0x1, 0x44(%rax,%r14)
    38ca:      	movq	0x8(%rsp), %rdx
    38cf:      	movq	0x5e78(%rdx,%r14,2), %rax
    38d7:      	je	0x38f2 <generic_retkprobe_actions+0x972>
    38d9:      	movl	0x5e80(%rdx,%r14,2), %ebx
    38e1:      	subl	%eax, %ebx
    38e3:      	jmp	0x38fa <generic_retkprobe_actions+0x97a>
    38e5:      	movq	0x8(%rsp), %rdx
    38ea:      	movq	0x5e78(%rdx,%r14,2), %rax
    38f2:      	movl	0x4(%rdx), %ebx
    38f5:      	subl	%eax, %ebx
    38f7:      	addl	$0x4, %ebx
    38fa:      	testl	%ebx, %ebx
    38fc:      	jle	0x3810 <generic_retkprobe_actions+0x890>
    3902:      	addl	$0x3ffc, %eax           # imm = 0x3FFC
    3907:      	andl	$0x3fff, %eax           # imm = 0x3FFF
    390c:      	cmpl	$0x28, %ebx
    390f:      	movl	$0x28, %ecx
    3914:      	cmovgel	%ecx, %ebx
    3917:      	movzbl	0x38(%rsp), %ebp
    391c:      	movq	0x48(%rsp), %rcx
    3921:      	leaq	(%rcx,%rbp), %rdi
    3925:      	addq	%rax, %rdx
    3928:      	addq	$0x90, %rdx
    392f:      	movl	$0x4, %eax
    3934:      	movl	%ebx, %esi
    3936:      	callq	*%rax
    3938:      	addl	%ebp, %ebx
    393a:      	movq	(%rip), %rbp            # 0x3941 <generic_retkprobe_actions+0x9c1>
    3941:      	movq	%rbx, 0x38(%rsp)
    3946:      	jmp	0x3810 <generic_retkprobe_actions+0x890>
    394b:      	movl	$0x1, %eax
    3950:      	movq	(%rip), %rdi            # 0x3957 <generic_retkprobe_actions+0x9d7>
    3957:      	movq	0x98(%rsp), %rbx
    395f:      	movq	%rbx, %rsi
    3962:      	callq	*%rax
    3964:      	testq	%rax, %rax
    3967:      	movq	0x60(%rsp), %r14
    396c:      	je	0x398e <generic_retkprobe_actions+0xa0e>
    396e:      	imulq	$-0xf4240, 0xa0(%rsp), %rcx # imm = 0xFFF0BDC0
    397a:      	addq	0x18(%rsp), %rcx
    397f:      	cmpq	%rcx, (%rax)
    3982:      	jbe	0x398e <generic_retkprobe_actions+0xa0e>
    3984:      	movl	$0x0, 0x44(%rsp)
    398c:      	jmp	0x39a8 <generic_retkprobe_actions+0xa28>
    398e:      	movl	$0x2, %eax
    3993:      	xorl	%ecx, %ecx
    3995:      	movq	(%rip), %rdi            # 0x399c <generic_retkprobe_actions+0xa1c>
    399c:      	leaq	0x18(%rsp), %rdx
    39a1:      	movq	%rbx, %rsi
    39a4:      	xorl	%ecx, %ecx
    39a6:      	callq	*%rax
    39a8:      	leal	0x3(%r15), %eax
    39ac:      	cmpl	$0x0, 0x4(%r14,%rax,4)
    39b2:      	movq	0x8(%rsp), %rdx
    39b7:      	je	0x39e3 <generic_retkprobe_actions+0xa63>
    39b9:      	orb	$0x2, 0x1(%rdx)
    39bd:      	movl	$0x1b, %eax
    39c2:      	movq	0x80(%rsp), %rdi
    39ca:      	xorl	%ecx, %ecx
    39cc:      	movq	(%rip), %rsi            # 0x39d3 <generic_retkprobe_actions+0xa53>
    39d3:      	xorl	%edx, %edx
    39d5:      	callq	*%rax
    39d7:      	movq	0x8(%rsp), %rdx
    39dc:      	movq	%rax, 0x80(%rdx)
    39e3:      	addl	$0x4, %r15d
    39e7:      	cmpl	$0x0, 0x4(%r14,%r15,4)
    39ed:      	je	0x30b0 <generic_retkprobe_actions+0x130>
    39f3:      	orb	$0x4, 0x1(%rdx)
    39f7:      	movl	$0x1b, %eax
    39fc:      	movq	0x80(%rsp), %rdi
    3a04:      	movq	(%rip), %rsi            # 0x3a0b <generic_retkprobe_actions+0xa8b>
    3a0b:      	movl	$0x100, %ecx            # imm = 0x100
    3a10:      	movl	$0x100, %edx            # imm = 0x100
    3a15:      	callq	*%rax
    3a17:      	movq	0x8(%rsp), %rdx
    3a1c:      	movq	%rax, 0x88(%rdx)
    3a23:      	jmp	0x30b0 <generic_retkprobe_actions+0x130>
    3a28:      	movl	$0x1, 0x94(%rsp)
    3a33:      	movl	$0x2, %eax
    3a38:      	xorl	%ecx, %ecx
    3a3a:      	leaq	0x94(%rsp), %rdx
    3a42:      	leaq	0x18(%rsp), %rsi
    3a47:      	movq	%rbx, %rdi
    3a4a:      	xorl	%ecx, %ecx
    3a4c:      	callq	*%rax
    3a4e:      	cmpl	$0x0, 0x38(%rsp)
    3a53:      	je	0x34da <generic_retkprobe_actions+0x55a>
    3a59:      	movl	$0x1, %eax
    3a5e:      	leaq	0x28(%rsp), %rsi
    3a63:      	movq	(%rip), %rdi            # 0x3a6a <generic_retkprobe_actions+0xaea>
    3a6a:      	callq	*%rax
    3a6c:      	testq	%rax, %rax
    3a6f:      	je	0x34da <generic_retkprobe_actions+0x55a>
    3a75:      	movl	0x5c(%rsp), %ecx
    3a79:      	lock
    3a7a:      	addl	%ecx, (%rax)
    3a7c:      	jmp	0x34da <generic_retkprobe_actions+0x55a>
    3a81:      	cmpb	$0x0, 0x44(%rsp)
    3a86:      	je	0x3aa8 <generic_retkprobe_actions+0xb28>
    3a88:      	movq	(%rip), %rsi            # 0x3a8f <generic_retkprobe_actions+0xb0f>
    3a8f:      	movl	$0x5, %ecx
    3a94:      	movl	$0xc, %eax
    3a99:      	movq	0x80(%rsp), %rdi
    3aa1:      	movl	$0x5, %edx
    3aa6:      	callq	*%rax
    3aa8:      	xorl	%eax, %eax
    3aaa:      	addq	$0xa8, %rsp
    3ab1:      	popq	%rbx
    3ab2:      	popq	%r12
    3ab4:      	popq	%r13
    3ab6:      	popq	%r14
    3ab8:      	popq	%r15
    3aba:      	popq	%rbp
    3abb:      	retq
    3abc:      	nopl	(%rax)

0000000000003ac0 <generic_retkprobe_output>:
    3ac0:      	pushq	%rbx
    3ac1:      	subq	$0x10, %rsp
    3ac5:      	movq	%rdi, %rbx
    3ac8:      	movl	$0x0, 0x4(%rsp)
    3ad0:      	movq	(%rip), %rdi            # 0x3ad7 <generic_retkprobe_output+0x17>
    3ad7:      	leaq	0x4(%rsp), %rsi
    3adc:      	movl	$0x1, %eax
    3ae1:      	callq	*%rax
    3ae3:      	testq	%rax, %rax
    3ae6:      	je	0x3b90 <generic_retkprobe_output+0xd0>
    3aec:      	movq	%rax, %rcx
    3aef:      	movl	$0x90, %eax
    3af4:      	addl	0x4(%rcx), %eax
    3af7:      	andl	$0x7fff, %eax           # imm = 0x7FFF
    3afc:      	cmpl	$0x2328, %eax           # imm = 0x2328
    3b01:      	movl	$0x2328, %r8d           # imm = 0x2328
    3b07:      	cmovbl	%eax, %r8d
    3b0b:      	movq	(%rip), %rsi            # 0x3b12 <generic_retkprobe_output+0x52>
    3b12:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    3b17:      	movl	$0x19, %eax
    3b1c:      	movq	%rbx, %rdi
    3b1f:      	callq	*%rax
    3b21:      	testq	%rax, %rax
    3b24:      	js	0x3b4d <generic_retkprobe_output+0x8d>
    3b26:      	movl	$0x0, 0xc(%rsp)
    3b2e:      	movq	(%rip), %rdi            # 0x3b35 <generic_retkprobe_output+0x75>
    3b35:      	leaq	0xc(%rsp), %rsi
    3b3a:      	movl	$0x1, %eax
    3b3f:      	callq	*%rax
    3b41:      	testq	%rax, %rax
    3b44:      	je	0x3b90 <generic_retkprobe_output+0xd0>
    3b46:      	lock
    3b47:      	incq	0x8(%rax)
    3b4b:      	jmp	0x3b90 <generic_retkprobe_output+0xd0>
    3b4d:      	movq	%rax, %rbx
    3b50:      	movl	$0x0, 0x8(%rsp)
    3b58:      	movq	(%rip), %rdi            # 0x3b5f <generic_retkprobe_output+0x9f>
    3b5f:      	leaq	0x8(%rsp), %rsi
    3b64:      	movl	$0x1, %eax
    3b69:      	callq	*%rax
    3b6b:      	testq	%rax, %rax
    3b6e:      	je	0x3b90 <generic_retkprobe_output+0xd0>
    3b70:      	cmpq	$-0xc, %rbx
    3b74:      	jg	0x3b98 <generic_retkprobe_output+0xd8>
    3b76:      	cmpq	$-0x1c, %rbx
    3b7a:      	je	0x3bb2 <generic_retkprobe_output+0xf2>
    3b7c:      	cmpq	$-0x16, %rbx
    3b80:      	je	0x3bca <generic_retkprobe_output+0x10a>
    3b82:      	cmpq	$-0x10, %rbx
    3b86:      	jne	0x3bc2 <generic_retkprobe_output+0x102>
    3b88:      	addq	$0x2f0, %rax            # imm = 0x2F0
    3b8e:      	jmp	0x3bd8 <generic_retkprobe_output+0x118>
    3b90:      	xorl	%eax, %eax
    3b92:      	addq	$0x10, %rsp
    3b96:      	popq	%rbx
    3b97:      	retq
    3b98:      	cmpq	$-0xb, %rbx
    3b9c:      	je	0x3bba <generic_retkprobe_output+0xfa>
    3b9e:      	cmpq	$-0x7, %rbx
    3ba2:      	je	0x3bd2 <generic_retkprobe_output+0x112>
    3ba4:      	cmpq	$-0x2, %rbx
    3ba8:      	jne	0x3bc2 <generic_retkprobe_output+0x102>
    3baa:      	addq	$0x2e0, %rax            # imm = 0x2E0
    3bb0:      	jmp	0x3bd8 <generic_retkprobe_output+0x118>
    3bb2:      	addq	$0x300, %rax            # imm = 0x300
    3bb8:      	jmp	0x3bd8 <generic_retkprobe_output+0x118>
    3bba:      	addq	$0x308, %rax            # imm = 0x308
    3bc0:      	jmp	0x3bd8 <generic_retkprobe_output+0x118>
    3bc2:      	addq	$0x2d8, %rax            # imm = 0x2D8
    3bc8:      	jmp	0x3bd8 <generic_retkprobe_output+0x118>
    3bca:      	addq	$0x2f8, %rax            # imm = 0x2F8
    3bd0:      	jmp	0x3bd8 <generic_retkprobe_output+0x118>
    3bd2:      	addq	$0x2e8, %rax            # imm = 0x2E8
    3bd8:      	lock
    3bd9:      	incq	(%rax)
    3bdc:      	xorl	%eax, %eax
    3bde:      	addq	$0x10, %rsp
    3be2:      	popq	%rbx
    3be3:      	retq

Disassembly of section kprobe.multi/generic_retkprobe:

0000000000000000 <generic_retkprobe_event>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0xf8, %rsp
      11:      	movq	%rdi, %r13
      14:      	movq	0x50(%rdi), %rax
      18:      	movq	%rax, 0xc8(%rsp)
      20:      	movl	$0x0, 0xe8(%rsp)
      2b:      	movq	(%rip), %rdi            # 0x32 <generic_retkprobe_event+0x32>
      32:      	leaq	0xe8(%rsp), %rsi
      3a:      	movl	$0x1, %eax
      3f:      	callq	*%rax
      41:      	xorl	%ebp, %ebp
      43:      	testq	%rax, %rax
      46:      	je	0x3028 <generic_retkprobe_event+0x3028>
      4c:      	movq	%rax, %r12
      4f:      	movq	%rax, %rbx
      52:      	movl	$0xae, %eax
      57:      	movq	%r13, %rdi
      5a:      	callq	*%rax
      5c:      	leaq	0x5ef8(%r12), %rsi
      64:      	movl	%eax, 0x5ef8(%r12)
      6c:      	movq	(%rip), %rdi            # 0x73 <generic_retkprobe_event+0x73>
      73:      	movl	$0x1, %eax
      78:      	callq	*%rax
      7a:      	testq	%rax, %rax
      7d:      	je	0x3028 <generic_retkprobe_event+0x3028>
      83:      	movq	%rax, %r15
      86:      	movl	(%rax), %eax
      88:      	movq	%rax, 0x60(%rbx)
      8c:      	movl	$0xe, %eax
      91:      	callq	*%rax
      93:      	cmpq	$-0x16, %rax
      97:      	jne	0xb8 <generic_retkprobe_event+0xb8>
      99:      	leaq	0x20(%r13), %rdx
      9d:      	leaq	0x30(%rsp), %rdi
      a2:      	movl	$0x8, %ecx
      a7:      	movl	$0x4, %eax
      ac:      	movl	$0x8, %esi
      b1:      	callq	*%rax
      b3:      	movq	0x30(%rsp), %rax
      b8:      	movq	%rax, 0x68(%rbx)
      bc:      	movl	$0xe, %eax
      c1:      	callq	*%rax
      c3:      	movl	%eax, 0x7c(%rbx)
      c6:      	movq	0x60(%rbx), %rax
      ca:      	movq	0x68(%rbx), %rcx
      ce:      	movq	%rax, 0x30(%rsp)
      d3:      	movq	%rcx, 0x38(%rsp)
      d8:      	movq	(%rip), %rdi            # 0xdf <generic_retkprobe_event+0xdf>
      df:      	leaq	0x30(%rsp), %rsi
      e4:      	movl	$0x1, %eax
      e9:      	callq	*%rax
      eb:      	testq	%rax, %rax
      ee:      	je	0x3028 <generic_retkprobe_event+0x3028>
      f4:      	movq	(%rax), %r14
      f7:      	movq	0x8(%rax), %rcx
      fb:      	movq	%rcx, 0x98(%rsp)
     103:      	movq	0x10(%rax), %rax
     107:      	movq	%rax, 0x88(%rsp)
     10f:      	movq	(%rip), %rdi            # 0x116 <generic_retkprobe_event+0x116>
     116:      	leaq	0x30(%rsp), %rsi
     11b:      	movl	$0x3, %eax
     120:      	callq	*%rax
     122:      	movq	%r14, 0x90(%rbx)
     129:      	movl	0x58(%r15), %eax
     12d:      	movl	0x5c(%r15), %r14d
     131:      	testl	%r14d, %r14d
     134:      	movq	%r15, 0x90(%rsp)
     13c:      	je	0x1ff <generic_retkprobe_event+0x1ff>
     142:      	movl	%eax, 0x80(%rsp)
     149:      	movl	$0x0, 0x5ea0(%rbx)
     153:      	movq	0xc8(%rsp), %rbp
     15b:      	movl	$0x0, 0xec(%rsp)
     166:      	movq	(%rip), %rdi            # 0x16d <generic_retkprobe_event+0x16d>
     16d:      	leaq	0xec(%rsp), %rsi
     175:      	movl	$0x1, %eax
     17a:      	callq	*%rax
     17c:      	testq	%rax, %rax
     17f:      	je	0x2f3 <generic_retkprobe_event+0x2f3>
     185:      	movl	0x5ea0(%rax), %ecx
     18b:      	movl	%ecx, 0x98(%rax)
     191:      	movq	$0xc, 0x5e78(%rax)
     19c:      	testl	%ecx, %ecx
     19e:      	je	0x3d2 <generic_retkprobe_event+0x3d2>
     1a4:      	movl	$0x4, %r14d
     1aa:      	addq	$0x8, %r14
     1ae:      	movl	0x60(%r15), %eax
     1b2:      	cmpl	$0xb, %eax
     1b5:      	je	0x307 <generic_retkprobe_event+0x307>
     1bb:      	cmpl	$0xa, %eax
     1be:      	jne	0x31d <generic_retkprobe_event+0x31d>
     1c4:      	movl	0x10(%rbx), %eax
     1c7:      	movl	%eax, 0x30(%rsp)
     1cb:      	movl	0x7c(%rbx), %eax
     1ce:      	movl	%eax, 0x34(%rsp)
     1d2:      	movq	0x18(%rbx), %rax
     1d6:      	movq	%rax, 0x38(%rsp)
     1db:      	movq	(%rip), %rdi            # 0x1e2 <generic_retkprobe_event+0x1e2>
     1e2:      	xorl	%ecx, %ecx
     1e4:      	leaq	0xc8(%rsp), %rsi
     1ec:      	leaq	0x30(%rsp), %rdx
     1f1:      	movl	$0x2, %eax
     1f6:      	xorl	%ecx, %ecx
     1f8:      	callq	*%rax
     1fa:      	jmp	0x31d <generic_retkprobe_event+0x31d>
     1ff:      	movl	$0x8, %r14d
     205:      	addq	$0x90, %r12
     20c:      	cmpl	$0x3, %eax
     20f:      	jne	0x33b <generic_retkprobe_event+0x33b>
     215:      	movl	$0x0, (%r12,%r14)
     21d:      	movq	%r14, %r15
     220:      	addq	$0x4, %r14
     224:      	cmpq	$0x0, 0x88(%rsp)
     22d:      	movq	%r13, 0xc0(%rsp)
     235:      	movq	%r12, 0x18(%rsp)
     23a:      	je	0x43a <generic_retkprobe_event+0x43a>
     240:      	movq	0xc8(%rsp), %r12
     248:      	leaq	0x30(%rsp), %rdi
     24d:      	movl	$0x4, %ebp
     252:      	movl	$0x10, %ecx
     257:      	movl	$0x4, %eax
     25c:      	movq	0x98(%rsp), %rdx
     264:      	movl	$0x10, %esi
     269:      	callq	*%rax
     26b:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     270:      	testl	%eax, %eax
     272:      	js	0x2d70 <generic_retkprobe_event+0x2d70>
     278:      	movq	0x38(%rsp), %rsi
     27d:      	cmpq	%r12, %rsi
     280:      	movq	%r12, %rax
     283:      	cmovbq	%rsi, %r12
     287:      	testq	%rax, %rax
     28a:      	cmovneq	%r12, %rsi
     28e:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
     293:      	cmpq	$0xffe, %rsi            # imm = 0xFFE
     29a:      	ja	0x2d70 <generic_retkprobe_event+0x2d70>
     2a0:      	movq	%rax, %r13
     2a3:      	addq	$0xc, %r15
     2a7:      	movq	%r15, 0x80(%rsp)
     2af:      	movq	0x18(%rsp), %rax
     2b4:      	leaq	(%rax,%r15), %rdi
     2b8:      	movq	0x30(%rsp), %rcx
     2bd:      	movl	$0x4, %eax
     2c2:      	movq	0x30(%rsp), %rdx
     2c7:      	movq	%rsi, %r15
     2ca:      	callq	*%rax
     2cc:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     2d1:      	testl	%eax, %eax
     2d3:      	js	0x2d70 <generic_retkprobe_event+0x2d70>
     2d9:      	movq	%r15, %rdx
     2dc:      	testq	%r13, %r13
     2df:      	je	0xc40 <generic_retkprobe_event+0xc40>
     2e5:      	subq	%r12, %r13
     2e8:      	jne	0xc43 <generic_retkprobe_event+0xc43>
     2ee:      	jmp	0x43d <generic_retkprobe_event+0x43d>
     2f3:      	xorl	%r14d, %r14d
     2f6:      	addq	$0x8, %r14
     2fa:      	movl	0x60(%r15), %eax
     2fe:      	cmpl	$0xb, %eax
     301:      	jne	0x1bb <generic_retkprobe_event+0x1bb>
     307:      	movq	(%rip), %rdi            # 0x30e <generic_retkprobe_event+0x30e>
     30e:      	leaq	0xc8(%rsp), %rsi
     316:      	movl	$0x3, %eax
     31b:      	callq	*%rax
     31d:      	andl	$0x1fff, %r14d          # imm = 0x1FFF
     324:      	movl	0x80(%rsp), %eax
     32b:      	addq	$0x90, %r12
     332:      	cmpl	$0x3, %eax
     335:      	je	0x215 <generic_retkprobe_event+0x215>
     33b:      	cmpl	$0x2, %eax
     33e:      	jne	0x2d87 <generic_retkprobe_event+0x2d87>
     344:      	movq	%rbx, 0x88(%rsp)
     34c:      	movq	%r13, %rbp
     34f:      	movl	$0x0, (%r12,%r14)
     357:      	movq	0xc8(%rsp), %r15
     35f:      	cmpq	$0xfff, %r15            # imm = 0xFFF
     366:      	movq	%r14, %rsi
     369:      	movl	$0xfff, %r14d           # imm = 0xFFF
     36f:      	cmovbq	%r15, %r14
     373:      	leaq	(%r12,%rsi), %rdi
     377:      	addq	$0xc, %rdi
     37b:      	movl	$0x4, %eax
     380:      	movq	0x98(%rsp), %rdx
     388:      	movq	%r12, %rcx
     38b:      	leaq	0x4(%rsi), %r12
     38f:      	leaq	(%rcx,%rsi), %r13
     393:      	addq	$0x4, %r13
     397:      	movl	$0x4, %ebx
     39c:      	movl	%r14d, %esi
     39f:      	callq	*%rax
     3a1:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     3a6:      	testl	%eax, %eax
     3a8:      	js	0x3b8 <generic_retkprobe_event+0x3b8>
     3aa:      	movl	%r14d, 0x4(%r13)
     3ae:      	addq	$0x8, %r14
     3b2:      	movl	%r15d, %ecx
     3b5:      	movq	%r14, %rbx
     3b8:      	addq	%r12, %rbx
     3bb:      	movl	%ecx, (%r13)
     3bf:      	movq	%rbp, %r13
     3c2:      	movq	%rbx, %r14
     3c5:      	movq	0x88(%rsp), %rbx
     3cd:      	jmp	0x2d87 <generic_retkprobe_event+0x2d87>
     3d2:      	leaq	0x9c(%rax), %rcx
     3d9:      	movq	%rbp, 0x30(%rsp)
     3de:      	movq	$0x0, 0x70(%rsp)
     3e7:      	cmpl	$0x17, %r14d
     3eb:      	movq	%rax, 0x8(%rsp)
     3f0:      	movq	%r12, 0x18(%rsp)
     3f5:      	movq	%r13, 0xc0(%rsp)
     3fd:      	jle	0x457 <generic_retkprobe_event+0x457>
     3ff:      	cmpl	$0x18, %r14d
     403:      	je	0x472 <generic_retkprobe_event+0x472>
     405:      	cmpl	$0x25, %r14d
     409:      	je	0x4b0 <generic_retkprobe_event+0x4b0>
     40f:      	cmpl	$0x2a, %r14d
     413:      	jne	0xa54 <generic_retkprobe_event+0xa54>
     419:      	movq	$0x0, 0xa0(%rsp)
     425:      	movq	%rbp, 0xa8(%rsp)
     42d:      	leaq	0xa0(%rsp), %r12
     435:      	jmp	0x4dd <generic_retkprobe_event+0x4dd>
     43a:      	xorl	%r12d, %r12d
     43d:      	movq	0x18(%rsp), %r15
     442:      	movl	%r12d, (%r15,%r14)
     446:      	movl	%r12d, 0x4(%r15,%r14)
     44b:      	addq	$0x8, %r12
     44f:      	movq	%r12, %rbp
     452:      	jmp	0x2d79 <generic_retkprobe_event+0x2d79>
     457:      	cmpl	$0xf, %r14d
     45b:      	je	0x990 <generic_retkprobe_event+0x990>
     461:      	cmpl	$0x10, %r14d
     465:      	jne	0xa54 <generic_retkprobe_event+0xa54>
     46b:      	leaq	0x20(%rsp), %r14
     470:      	jmp	0x49a <generic_retkprobe_event+0x49a>
     472:      	leaq	0x20(%rsp), %r14
     477:      	movl	$0x8, %ecx
     47c:      	movl	$0x4, %eax
     481:      	movq	0x30(%rsp), %rdx
     486:      	movq	%r14, %rdi
     489:      	movl	$0x8, %esi
     48e:      	callq	*%rax
     490:      	movq	0x20(%rsp), %rax
     495:      	movq	%rax, 0x30(%rsp)
     49a:      	leaq	0x30(%rsp), %rdx
     49f:      	movl	$0x8, %ecx
     4a4:      	movl	$0x4, %eax
     4a9:      	leaq	0x20(%rsp), %rdi
     4ae:      	jmp	0x4cd <generic_retkprobe_event+0x4cd>
     4b0:      	addq	$0x40, %rbp
     4b4:      	movq	%rbp, 0x30(%rsp)
     4b9:      	leaq	0x20(%rsp), %rdi
     4be:      	movl	$0x8, %ecx
     4c3:      	movl	$0x4, %eax
     4c8:      	movq	0x30(%rsp), %rdx
     4cd:      	movl	$0x8, %esi
     4d2:      	callq	*%rax
     4d4:      	movq	0x20(%rsp), %r12
     4d9:      	addq	$0x40, %r12
     4dd:      	movl	$0x0, 0xb4(%rsp)
     4e8:      	movq	(%rip), %rdi            # 0x4ef <generic_retkprobe_event+0x4ef>
     4ef:      	leaq	0xb4(%rsp), %rsi
     4f7:      	movl	$0x1, %eax
     4fc:      	callq	*%rax
     4fe:      	testq	%rax, %rax
     501:      	je	0x5aa <generic_retkprobe_event+0x5aa>
     507:      	movq	%rax, %r13
     50a:      	addq	$0x1000, %rax           # imm = 0x1000
     510:      	movq	%rax, 0x10(%rsp)
     515:      	movl	$0x23, %eax
     51a:      	callq	*%rax
     51c:      	leaq	0xd50(%rax), %rdx
     523:      	leaq	0xd0(%rsp), %rdi
     52b:      	movl	$0x8, %ecx
     530:      	movl	$0x4, %eax
     535:      	movl	$0x8, %esi
     53a:      	callq	*%rax
     53c:      	movq	0xd0(%rsp), %rbp
     544:      	leaq	0x8(%r12), %rdx
     549:      	leaq	0xd8(%rsp), %rdi
     551:      	movl	$0x8, %ecx
     556:      	movl	$0x4, %eax
     55b:      	leaq	0x18(%rbp), %rcx
     55f:      	movq	%rcx, 0xf0(%rsp)
     567:      	movl	$0x8, %esi
     56c:      	movq	%rdx, 0x28(%rsp)
     571:      	callq	*%rax
     573:      	movq	0xd8(%rsp), %r15
     57b:      	leaq	0x10(%r15), %rdx
     57f:      	leaq	0x30(%rsp), %rdi
     584:      	movl	$0x8, %ecx
     589:      	movl	$0x4, %eax
     58e:      	movl	$0x8, %esi
     593:      	callq	*%rax
     595:      	cmpq	$0x0, 0x30(%rsp)
     59b:      	movl	$0x1000, %r14d          # imm = 0x1000
     5a1:      	je	0x5bf <generic_retkprobe_event+0x5bf>
     5a3:      	movq	0x10(%rsp), %rcx
     5a8:      	jmp	0x610 <generic_retkprobe_event+0x610>
     5aa:      	xorl	%r13d, %r13d
     5ad:      	movq	0x90(%rsp), %r15
     5b5:      	movq	0x18(%rsp), %r12
     5ba:      	jmp	0x2b93 <generic_retkprobe_event+0x2b93>
     5bf:      	leaq	0x18(%r15), %rdx
     5c3:      	leaq	0x30(%rsp), %rdi
     5c8:      	movl	$0x8, %ecx
     5cd:      	movl	$0x4, %eax
     5d2:      	movl	$0x8, %esi
     5d7:      	callq	*%rax
     5d9:      	cmpq	%r15, 0x30(%rsp)
     5de:      	movq	0x10(%rsp), %rcx
     5e3:      	je	0x610 <generic_retkprobe_event+0x610>
     5e5:      	movq	%r13, %rcx
     5e8:      	addq	$0xff6, %rcx            # imm = 0xFF6
     5ef:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
     5f9:      	movq	%rax, 0xff6(%r13)
     600:      	movw	$0x2964, 0xffe(%r13)    # imm = 0x2964
     60a:      	movl	$0xff6, %r14d           # imm = 0xFF6
     610:      	movq	$0x0, 0x38(%rsp)
     619:      	movq	$0x0, 0x30(%rsp)
     622:      	movq	%r13, 0x40(%rsp)
     627:      	movq	$0x0, 0x48(%rsp)
     630:      	movq	$0x0, 0x50(%rsp)
     639:      	movq	$0x0, 0x58(%rsp)
     642:      	movq	%rcx, 0x10(%rsp)
     647:      	movq	%rcx, 0x60(%rsp)
     64c:      	movl	%r14d, 0x68(%rsp)
     651:      	movb	$0x0, 0x6c(%rsp)
     656:      	addq	$0x20, %rbp
     65a:      	leaq	0x30(%rsp), %rdi
     65f:      	movl	$0x8, %r15d
     665:      	movl	$0x4, %eax
     66a:      	leaq	0x38(%rsp), %r13
     66f:      	leaq	0x48(%rsp), %r14
     674:      	movl	$0x8, %esi
     679:      	movq	%rbp, %rdx
     67c:      	callq	*%rax
     67e:      	movl	$0x8, %ecx
     683:      	movl	$0x4, %eax
     688:      	movq	0xf0(%rsp), %rdx
     690:      	movq	%r13, %rdi
     693:      	movl	$0x8, %esi
     698:      	callq	*%rax
     69a:      	movl	$0x8, %ecx
     69f:      	movl	$0x4, %eax
     6a4:      	movq	0x28(%rsp), %rdx
     6a9:      	movq	%r14, %rdi
     6ac:      	movl	$0x8, %esi
     6b1:      	callq	*%rax
     6b3:      	movl	$0x8, %ecx
     6b8:      	movl	$0x4, %eax
     6bd:      	leaq	0x50(%rsp), %rdi
     6c2:      	movl	$0x8, %esi
     6c7:      	movq	%r12, %rdx
     6ca:      	callq	*%rax
     6cc:      	movq	0x50(%rsp), %rax
     6d1:      	addq	$-0x20, %rax
     6d5:      	movq	%rax, 0x58(%rsp)
     6da:      	movl	$0x80, %ebp
     6df:      	movq	0x48(%rsp), %r14
     6e4:      	movq	0x50(%rsp), %rdx
     6e9:      	movq	0x58(%rsp), %r13
     6ee:      	cmpq	0x30(%rsp), %r14
     6f3:      	jne	0x700 <generic_retkprobe_event+0x700>
     6f5:      	cmpq	0x38(%rsp), %rdx
     6fa:      	je	0x877 <generic_retkprobe_event+0x877>
     700:      	movl	$0x4, %eax
     705:      	leaq	0xb8(%rsp), %rdi
     70d:      	movl	$0x8, %esi
     712:      	callq	*%rax
     714:      	cmpq	0xb8(%rsp), %r14
     71c:      	je	0x81c <generic_retkprobe_event+0x81c>
     722:      	leaq	0x18(%r14), %r12
     726:      	movl	$0x4, %eax
     72b:      	leaq	0x20(%rsp), %rdi
     730:      	movl	$0x8, %esi
     735:      	movq	%r12, %rdx
     738:      	callq	*%rax
     73a:      	cmpq	%r14, 0x20(%rsp)
     73f:      	je	0x81c <generic_retkprobe_event+0x81c>
     745:      	movl	$0x4, %eax
     74a:      	leaq	0xe0(%rsp), %rdi
     752:      	movl	$0x8, %esi
     757:      	movq	%r12, %rdx
     75a:      	callq	*%rax
     75c:      	addq	$0x20, %r14
     760:      	movl	$0x4, %eax
     765:      	leaq	0x70(%rsp), %rdi
     76a:      	movl	$0x10, %ecx
     76f:      	movl	$0x10, %esi
     774:      	movq	%r14, %rdx
     777:      	callq	*%rax
     779:      	movq	0x40(%rsp), %r14
     77e:      	movq	0x60(%rsp), %rax
     783:      	movl	0x74(%rsp), %r12d
     788:      	subq	%r14, %rax
     78b:      	movl	0x68(%rsp), %r13d
     790:      	movl	%r12d, %edx
     793:      	subl	%r13d, %edx
     796:      	movl	$0x0, %ecx
     79b:      	cmovbl	%ecx, %edx
     79e:      	addq	0x78(%rsp), %rdx
     7a3:      	xorl	%esi, %esi
     7a5:      	cmpl	%r12d, %r13d
     7a8:      	seta	%sil
     7ac:      	movl	%r12d, %ecx
     7af:      	cmovbl	%r13d, %ecx
     7b3:      	addl	%ecx, %esi
     7b5:      	movl	%r13d, %edi
     7b8:      	subl	%esi, %edi
     7ba:      	movl	%edi, 0x68(%rsp)
     7be:      	subq	%rsi, %rax
     7c1:      	jb	0x87c <generic_retkprobe_event+0x87c>
     7c7:      	cmpq	$0xfff, %rax            # imm = 0xFFF
     7cd:      	ja	0x87c <generic_retkprobe_event+0x87c>
     7d3:      	cmpl	%r12d, %r13d
     7d6:      	jbe	0x7dd <generic_retkprobe_event+0x7dd>
     7d8:      	movb	$0x2f, (%r14,%rax)
     7dd:      	xorl	%edi, %edi
     7df:      	cmpl	%r12d, %r13d
     7e2:      	seta	%dil
     7e6:      	movzbl	%cl, %esi
     7e9:      	addq	%rax, %r14
     7ec:      	addq	%r14, %rdi
     7ef:      	movl	$0x4, %eax
     7f4:      	callq	*%rax
     7f6:      	movq	%r14, 0x60(%rsp)
     7fb:      	cmpl	%r12d, %r13d
     7fe:      	jbe	0x87c <generic_retkprobe_event+0x87c>
     800:      	movq	0xe0(%rsp), %rax
     808:      	movq	%rax, 0x48(%rsp)
     80d:      	movq	0x18(%rsp), %r12
     812:      	decl	%ebp
     814:      	jne	0x6df <generic_retkprobe_event+0x6df>
     81a:      	jmp	0x881 <generic_retkprobe_event+0x881>
     81c:      	leaq	0x10(%r13), %rdx
     820:      	movl	$0x4, %eax
     825:      	leaq	0x20(%rsp), %rdi
     82a:      	movl	$0x8, %esi
     82f:      	callq	*%rax
     831:      	movq	0x58(%rsp), %rax
     836:      	cmpq	0x20(%rsp), %rax
     83b:      	je	0x877 <generic_retkprobe_event+0x877>
     83d:      	addq	$0x18, %r13
     841:      	movl	$0x4, %eax
     846:      	leaq	0x48(%rsp), %rdi
     84b:      	movl	$0x8, %esi
     850:      	movq	%r13, %rdx
     853:      	callq	*%rax
     855:      	movq	0x20(%rsp), %rax
     85a:      	movq	%rax, 0x58(%rsp)
     85f:      	addq	$0x20, %rax
     863:      	movq	%rax, 0x50(%rsp)
     868:      	movq	0x18(%rsp), %r12
     86d:      	decl	%ebp
     86f:      	jne	0x6df <generic_retkprobe_event+0x6df>
     875:      	jmp	0x881 <generic_retkprobe_event+0x881>
     877:      	movb	$0x1, 0x6c(%rsp)
     87c:      	movq	0x18(%rsp), %r12
     881:      	movq	0x60(%rsp), %rax
     886:      	movq	0x10(%rsp), %rdx
     88b:      	cmpq	%rdx, %rax
     88e:      	movl	$0x4, %r14d
     894:      	je	0x8d3 <generic_retkprobe_event+0x8d3>
     896:      	xorl	%ebp, %ebp
     898:      	cmpb	$0x0, 0x6c(%rsp)
     89d:      	sete	%cl
     8a0:      	movl	0x68(%rsp), %edx
     8a4:      	movl	$0x1000, %r13d          # imm = 0x1000
     8aa:      	subl	%edx, %r13d
     8ad:      	testl	%edx, %edx
     8af:      	cmovlel	%edx, %r13d
     8b3:      	testq	%rax, %rax
     8b6:      	movq	0x8(%rsp), %rdi
     8bb:      	movq	0x90(%rsp), %r15
     8c3:      	je	0xc38 <generic_retkprobe_event+0xc38>
     8c9:      	movb	%cl, %bpl
     8cc:      	addl	%ebp, %ebp
     8ce:      	movq	%rax, %rdx
     8d1:      	jmp	0x8e5 <generic_retkprobe_event+0x8e5>
     8d3:      	xorl	%ebp, %ebp
     8d5:      	xorl	%r13d, %r13d
     8d8:      	movq	0x8(%rsp), %rdi
     8dd:      	movq	0x90(%rsp), %r15
     8e5:      	addq	$0xa0, %rdi
     8ec:      	andl	$0xfff, %r13d           # imm = 0xFFF
     8f3:      	movl	$0x4, %eax
     8f8:      	movl	%r13d, %esi
     8fb:      	callq	*%rax
     8fd:      	movq	0x8(%rsp), %rax
     902:      	movl	%r13d, 0x9c(%rax)
     909:      	leaq	0x30(%rsp), %rdi
     90e:      	movl	$0x8, %ecx
     913:      	movl	$0x4, %eax
     918:      	movq	0x28(%rsp), %rdx
     91d:      	movl	$0x8, %esi
     922:      	callq	*%rax
     924:      	movq	0x30(%rsp), %rcx
     929:      	addq	$0x30, %rcx
     92d:      	leaq	0x70(%rsp), %rdi
     932:      	movl	$0x8, %edx
     937:      	movl	$0x4, %eax
     93c:      	movq	0x30(%rsp), %rdx
     941:      	addq	$0x30, %rdx
     945:      	movl	$0x8, %esi
     94a:      	callq	*%rax
     94c:      	movq	0x70(%rsp), %rcx
     951:      	leaq	0x20(%rsp), %rdi
     956:      	movl	$0x2, %edx
     95b:      	movl	$0x4, %eax
     960:      	movq	0x70(%rsp), %rdx
     965:      	movl	$0x2, %esi
     96a:      	callq	*%rax
     96c:      	movq	0x8(%rsp), %rcx
     971:      	movl	%ebp, 0xa0(%rcx,%r13)
     979:      	movzwl	0x20(%rsp), %eax
     97e:      	movw	%ax, 0xa4(%rcx,%r13)
     987:      	addl	$0xa, %r13d
     98b:      	jmp	0x2b8e <generic_retkprobe_event+0x2b8e>
     990:      	movq	%rcx, 0x10(%rsp)
     995:      	leaq	0x70(%rsp), %rdi
     99a:      	leaq	0x30(%rsp), %rdx
     99f:      	movl	$0x8, %ecx
     9a4:      	movl	$0x4, %eax
     9a9:      	movl	$0x8, %esi
     9ae:      	callq	*%rax
     9b0:      	movq	0x70(%rsp), %r12
     9b5:      	testq	%r12, %r12
     9b8:      	jne	0x4dd <generic_retkprobe_event+0x4dd>
     9be:      	movl	$0x0, 0xa0(%rsp)
     9c9:      	movq	(%rip), %rdi            # 0x9d0 <generic_retkprobe_event+0x9d0>
     9d0:      	leaq	0xa0(%rsp), %rsi
     9d8:      	movl	$0x1, %eax
     9dd:      	callq	*%rax
     9df:      	xorl	%r13d, %r13d
     9e2:      	testq	%rax, %rax
     9e5:      	je	0x21b9 <generic_retkprobe_event+0x21b9>
     9eb:      	cmpl	$0x19, %r14d
     9ef:      	movq	0x8(%rsp), %rcx
     9f4:      	movq	0x90(%rsp), %r15
     9fc:      	movq	0x18(%rsp), %r12
     a01:      	jg	0xe2f <generic_retkprobe_event+0xe2f>
     a07:      	cmpl	$0x12, %r14d
     a0b:      	jle	0xe65 <generic_retkprobe_event+0xe65>
     a11:      	cmpl	$0x14, %r14d
     a15:      	jle	0x128a <generic_retkprobe_event+0x128a>
     a1b:      	cmpl	$0x15, %r14d
     a1f:      	je	0x1ba8 <generic_retkprobe_event+0x1ba8>
     a25:      	cmpl	$0x16, %r14d
     a29:      	je	0x1b0c <generic_retkprobe_event+0x1b0c>
     a2f:      	cmpl	$0x17, %r14d
     a33:      	jne	0x2b88 <generic_retkprobe_event+0x2b88>
     a39:      	movl	$0x0, 0xa0(%rcx)
     a43:      	movl	%ebp, 0x9c(%rcx)
     a49:      	movl	$0x8, %r13d
     a4f:      	jmp	0x2b88 <generic_retkprobe_event+0x2b88>
     a54:      	movq	%rcx, 0x10(%rsp)
     a59:      	cmpl	$0x28, %r14d
     a5d:      	ja	0x9be <generic_retkprobe_event+0x9be>
     a63:      	movl	%r14d, %eax
     a66:      	movabsq	$0x1c1f2027cf2, %rcx    # imm = 0x1C1F2027CF2
     a70:      	btq	%rax, %rcx
     a74:      	jae	0x9be <generic_retkprobe_event+0x9be>
     a7a:      	movq	%rbp, 0x20(%rsp)
     a7f:      	movl	$0x0, 0xe0(%rsp)
     a8a:      	movq	(%rip), %rdi            # 0xa91 <generic_retkprobe_event+0xa91>
     a91:      	leaq	0xe0(%rsp), %rsi
     a99:      	movl	$0x1, %eax
     a9e:      	callq	*%rax
     aa0:      	xorl	%r13d, %r13d
     aa3:      	testq	%rax, %rax
     aa6:      	je	0x2b76 <generic_retkprobe_event+0x2b76>
     aac:      	cmpl	$0x10, %r14d
     ab0:      	jg	0xd18 <generic_retkprobe_event+0xd18>
     ab6:      	cmpl	$0x9, %r14d
     aba:      	movq	0x18(%rsp), %r12
     abf:      	jg	0xd59 <generic_retkprobe_event+0xd59>
     ac5:      	cmpl	$0x4, %r14d
     ac9:      	movq	0x8(%rsp), %rcx
     ace:      	jle	0xe99 <generic_retkprobe_event+0xe99>
     ad4:      	cmpl	$0x5, %r14d
     ad8:      	je	0x1448 <generic_retkprobe_event+0x1448>
     ade:      	cmpl	$0x6, %r14d
     ae2:      	je	0xdc3 <generic_retkprobe_event+0xdc3>
     ae8:      	cmpl	$0x7, %r14d
     aec:      	jne	0x2b80 <generic_retkprobe_event+0x2b80>
     af2:      	movq	%rax, %r15
     af5:      	movq	0x20(%rsp), %r12
     afa:      	movq	%r12, 0xc4(%rcx)
     b01:      	leaq	0xc2(%rcx), %rdi
     b08:      	leaq	0x10(%r12), %rdx
     b0d:      	movl	$0x2, %esi
     b12:      	movq	%rcx, %r13
     b15:      	movl	$0x4, %eax
     b1a:      	movl	$0x2, %esi
     b1f:      	callq	*%rax
     b21:      	leaq	0xd6(%r13), %rdi
     b28:      	leaq	0x12(%r12), %rdx
     b2d:      	movl	$0x1, %ecx
     b32:      	movl	$0x4, %eax
     b37:      	movl	$0x1, %esi
     b3c:      	callq	*%rax
     b3e:      	leaq	0xd4(%r13), %rdi
     b45:      	leaq	0x226(%r12), %rdx
     b4d:      	movl	$0x2, %ecx
     b52:      	movl	$0x4, %eax
     b57:      	movl	$0x2, %esi
     b5c:      	callq	*%rax
     b5e:      	leaq	0xc0(%r13), %rdi
     b65:      	leaq	0x224(%r12), %rdx
     b6d:      	movl	$0x2, %ecx
     b72:      	movl	$0x4, %eax
     b77:      	movl	$0x2, %esi
     b7c:      	callq	*%rax
     b7e:      	leaq	0xcc(%r13), %rdi
     b85:      	leaq	0x21c(%r12), %rdx
     b8d:      	movl	$0x4, %ecx
     b92:      	movl	$0x4, %eax
     b97:      	movl	$0x4, %esi
     b9c:      	callq	*%rax
     b9e:      	leaq	0xd0(%r13), %rdi
     ba5:      	leaq	0x218(%r12), %rdx
     bad:      	movl	$0x4, %ecx
     bb2:      	movl	$0x4, %eax
     bb7:      	movl	$0x4, %esi
     bbc:      	callq	*%rax
     bbe:      	leaq	0xac(%r13), %r14
     bc5:      	movq	0x10(%rsp), %rax
     bca:      	movq	$0x0, (%rax)
     bd1:      	movq	$0x0, 0x8(%rax)
     bd9:      	movq	$0x0, 0x10(%rax)
     be1:      	movq	$0x0, 0x18(%rax)
     be9:      	movzwl	0xc2(%r13), %eax
     bf1:      	cmpl	$0xa, %eax
     bf4:      	je	0x1ed9 <generic_retkprobe_event+0x1ed9>
     bfa:      	cmpl	$0x2, %eax
     bfd:      	jne	0x1f0d <generic_retkprobe_event+0x1f0d>
     c03:      	leaq	0x4(%r12), %rdx
     c08:      	movl	$0x4, %ecx
     c0d:      	movl	$0x4, %eax
     c12:      	movq	0x10(%rsp), %rdi
     c17:      	movl	$0x4, %esi
     c1c:      	callq	*%rax
     c1e:      	movl	$0x4, %ecx
     c23:      	movl	$0x4, %eax
     c28:      	movq	%r14, %rdi
     c2b:      	movl	$0x4, %esi
     c30:      	movq	%r12, %rdx
     c33:      	jmp	0x1f0b <generic_retkprobe_event+0x1f0b>
     c38:      	xorl	%r13d, %r13d
     c3b:      	jmp	0x2b93 <generic_retkprobe_event+0x2b93>
     c40:      	xorl	%r13d, %r13d
     c43:      	cmpq	$0x1, 0x88(%rsp)
     c4c:      	jne	0xc56 <generic_retkprobe_event+0xc56>
     c4e:      	movq	%rdx, %r12
     c51:      	jmp	0x43d <generic_retkprobe_event+0x43d>
     c56:      	movq	0x98(%rsp), %rax
     c5e:      	leaq	0x10(%rax), %rdx
     c62:      	leaq	0x30(%rsp), %rdi
     c67:      	movl	$0x4, %ebp
     c6c:      	movl	$0x10, %ecx
     c71:      	movl	$0x4, %eax
     c76:      	movl	$0x10, %esi
     c7b:      	callq	*%rax
     c7d:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     c82:      	testl	%eax, %eax
     c84:      	js	0x2d70 <generic_retkprobe_event+0x2d70>
     c8a:      	movq	0x38(%rsp), %rsi
     c8f:      	movq	%r13, %rax
     c92:      	cmpq	%r13, %rsi
     c95:      	movq	%r13, %r12
     c98:      	cmovbq	%rsi, %r12
     c9c:      	testq	%r13, %r13
     c9f:      	cmovneq	%r12, %rsi
     ca3:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
     ca8:      	cmpq	$0xffe, %rsi            # imm = 0xFFE
     caf:      	ja	0x2d70 <generic_retkprobe_event+0x2d70>
     cb5:      	movq	0x80(%rsp), %rcx
     cbd:      	addq	%r15, %rcx
     cc0:      	movq	%rcx, 0x80(%rsp)
     cc8:      	movq	0x18(%rsp), %rax
     ccd:      	leaq	(%rax,%rcx), %rdi
     cd1:      	movq	0x30(%rsp), %rcx
     cd6:      	movl	$0x4, %eax
     cdb:      	movq	0x30(%rsp), %rdx
     ce0:      	movq	%rsi, 0x8(%rsp)
     ce5:      	movq	0x8(%rsp), %rsi
     cea:      	callq	*%rax
     cec:      	movq	0x8(%rsp), %rdx
     cf1:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     cf6:      	testl	%eax, %eax
     cf8:      	js	0x2d70 <generic_retkprobe_event+0x2d70>
     cfe:      	addq	%rdx, %r15
     d01:      	testq	%r13, %r13
     d04:      	je	0x1730 <generic_retkprobe_event+0x1730>
     d0a:      	subq	%r12, %r13
     d0d:      	jne	0x1733 <generic_retkprobe_event+0x1733>
     d13:      	jmp	0x1810 <generic_retkprobe_event+0x1810>
     d18:      	cmpl	$0x1e, %r14d
     d1c:      	movq	0x18(%rsp), %r12
     d21:      	jg	0xdf4 <generic_retkprobe_event+0xdf4>
     d27:      	cmpl	$0x1c, %r14d
     d2b:      	jg	0xeeb <generic_retkprobe_event+0xeeb>
     d31:      	cmpl	$0x11, %r14d
     d35:      	je	0x1610 <generic_retkprobe_event+0x1610>
     d3b:      	cmpl	$0x19, %r14d
     d3f:      	je	0x1366 <generic_retkprobe_event+0x1366>
     d45:      	cmpl	$0x1c, %r14d
     d49:      	movq	0x8(%rsp), %rcx
     d4e:      	je	0xea9 <generic_retkprobe_event+0xea9>
     d54:      	jmp	0x2b80 <generic_retkprobe_event+0x2b80>
     d59:      	leal	-0xa(%r14), %eax
     d5d:      	cmpl	$0x2, %eax
     d60:      	movq	0x8(%rsp), %rcx
     d65:      	jb	0xea9 <generic_retkprobe_event+0xea9>
     d6b:      	leal	-0xc(%r14), %eax
     d6f:      	cmpl	$0x2, %eax
     d72:      	jb	0xeca <generic_retkprobe_event+0xeca>
     d78:      	cmpl	$0xe, %r14d
     d7c:      	jne	0x2b80 <generic_retkprobe_event+0x2b80>
     d82:      	leaq	0x30(%rsp), %rdi
     d87:      	leaq	0x20(%rsp), %r14
     d8c:      	movl	$0x8, %ecx
     d91:      	movl	$0x4, %eax
     d96:      	movl	$0x8, %esi
     d9b:      	movq	%r14, %rdx
     d9e:      	callq	*%rax
     da0:      	movq	0x30(%rsp), %rcx
     da5:      	movl	$0x8, %edx
     daa:      	movl	$0x4, %eax
     daf:      	movq	0x30(%rsp), %rdx
     db4:      	movq	%r14, %rdi
     db7:      	movl	$0x8, %esi
     dbc:      	callq	*%rax
     dbe:      	movq	0x8(%rsp), %rcx
     dc3:      	movq	0x20(%rsp), %rdx
     dc8:      	movq	%rcx, %rdi
     dcb:      	addq	$0xa0, %rdi
     dd2:      	movl	$0x1ff, %ecx            # imm = 0x1FF
     dd7:      	movl	$0x2d, %eax
     ddc:      	movl	$0x1ff, %esi            # imm = 0x1FF
     de1:      	callq	*%rax
     de3:      	movq	%rax, %r13
     de6:      	testq	%rax, %rax
     de9:      	jns	0x1717 <generic_retkprobe_event+0x1717>
     def:      	jmp	0x1e15 <generic_retkprobe_event+0x1e15>
     df4:      	cmpl	$0x26, %r14d
     df8:      	jg	0xf16 <generic_retkprobe_event+0xf16>
     dfe:      	leal	-0x1f(%r14), %eax
     e02:      	cmpl	$0x2, %eax
     e05:      	jae	0x120c <generic_retkprobe_event+0x120c>
     e0b:      	leaq	0x20(%rsp), %rdx
     e10:      	movl	$0x4, %r13d
     e16:      	movl	$0x1, %ecx
     e1b:      	movl	$0x4, %eax
     e20:      	movq	0x10(%rsp), %rdi
     e25:      	movl	$0x1, %esi
     e2a:      	jmp	0xf0a <generic_retkprobe_event+0xf0a>
     e2f:      	cmpl	$0x20, %r14d
     e33:      	jle	0x1147 <generic_retkprobe_event+0x1147>
     e39:      	leal	-0x21(%r14), %edx
     e3d:      	cmpl	$0x4, %edx
     e40:      	jae	0xfcb <generic_retkprobe_event+0xfcb>
     e46:      	movl	$0x8, %r13d
     e4c:      	movl	$0x8, %ecx
     e51:      	movl	$0x4, %eax
     e56:      	movq	0x10(%rsp), %rdi
     e5b:      	movl	$0x8, %esi
     e60:      	jmp	0x127b <generic_retkprobe_event+0x127b>
     e65:      	cmpl	$0x7, %r14d
     e69:      	jg	0x1258 <generic_retkprobe_event+0x1258>
     e6f:      	cmpl	$0x2, %r14d
     e73:      	je	0x1818 <generic_retkprobe_event+0x1818>
     e79:      	cmpl	$0x3, %r14d
     e7d:      	jne	0x2b88 <generic_retkprobe_event+0x2b88>
     e83:      	movq	$0x0, 0x9c(%rax)
     e8e:      	movl	$0x8, %r13d
     e94:      	jmp	0x2b88 <generic_retkprobe_event+0x2b88>
     e99:      	cmpl	$0x1, %r14d
     e9d:      	je	0xeca <generic_retkprobe_event+0xeca>
     e9f:      	cmpl	$0x4, %r14d
     ea3:      	jne	0x2b80 <generic_retkprobe_event+0x2b80>
     ea9:      	movl	$0x8, %r13d
     eaf:      	leaq	0x20(%rsp), %rdx
     eb4:      	movl	$0x8, %ecx
     eb9:      	movl	$0x4, %eax
     ebe:      	movq	0x10(%rsp), %rdi
     ec3:      	movl	$0x8, %esi
     ec8:      	jmp	0xf0a <generic_retkprobe_event+0xf0a>
     eca:      	leaq	0x20(%rsp), %rdx
     ecf:      	movl	$0x4, %r13d
     ed5:      	movl	$0x4, %ecx
     eda:      	movl	$0x4, %eax
     edf:      	movq	0x10(%rsp), %rdi
     ee4:      	movl	$0x4, %esi
     ee9:      	jmp	0xf0a <generic_retkprobe_event+0xf0a>
     eeb:      	leaq	0x20(%rsp), %rdx
     ef0:      	movl	$0x4, %r13d
     ef6:      	movl	$0x2, %ecx
     efb:      	movl	$0x4, %eax
     f00:      	movq	0x10(%rsp), %rdi
     f05:      	movl	$0x2, %esi
     f0a:      	callq	*%rax
     f0c:      	movq	0x8(%rsp), %rcx
     f11:      	jmp	0x2b80 <generic_retkprobe_event+0x2b80>
     f16:      	cmpl	$0x27, %r14d
     f1a:      	je	0x16e4 <generic_retkprobe_event+0x16e4>
     f20:      	cmpl	$0x28, %r14d
     f24:      	movq	0x8(%rsp), %rcx
     f29:      	jne	0x2b80 <generic_retkprobe_event+0x2b80>
     f2f:      	movq	0x20(%rsp), %r12
     f34:      	movq	0x10(%rsp), %r14
     f39:      	movq	$0x0, 0x10(%r14)
     f41:      	movq	$0x0, 0x8(%r14)
     f49:      	movq	$0x0, (%r14)
     f50:      	movl	$0x2, %ecx
     f55:      	movl	$0x4, %eax
     f5a:      	movq	%r14, %rdi
     f5d:      	movl	$0x2, %esi
     f62:      	movq	%r12, %rdx
     f65:      	callq	*%rax
     f67:      	testq	%rax, %rax
     f6a:      	js	0x2023 <generic_retkprobe_event+0x2023>
     f70:      	movzwl	(%r14), %eax
     f74:      	cmpl	$0xa, %eax
     f77:      	je	0x1fca <generic_retkprobe_event+0x1fca>
     f7d:      	cmpl	$0x2, %eax
     f80:      	jne	0x200e <generic_retkprobe_event+0x200e>
     f86:      	leaq	0x4(%r12), %rdx
     f8b:      	leaq	0x30(%rsp), %rdi
     f90:      	movl	$0x4, %ecx
     f95:      	movl	$0x4, %eax
     f9a:      	movl	$0x4, %esi
     f9f:      	callq	*%rax
     fa1:      	movl	0x30(%rsp), %eax
     fa5:      	movq	0x8(%rsp), %rdi
     faa:      	movq	%rax, 0xa4(%rdi)
     fb1:      	addq	$0x9e, %rdi
     fb8:      	addq	$0x2, %r12
     fbc:      	movl	$0x2, %ecx
     fc1:      	movl	$0x4, %eax
     fc6:      	jmp	0x2004 <generic_retkprobe_event+0x2004>
     fcb:      	cmpl	$0x2b, %r14d
     fcf:      	je	0x1cba <generic_retkprobe_event+0x1cba>
     fd5:      	cmpl	$0x29, %r14d
     fd9:      	jne	0x2b88 <generic_retkprobe_event+0x2b88>
     fdf:      	movq	%rax, %r15
     fe2:      	addq	$0x18, %rbp
     fe6:      	leaq	0x30(%rsp), %rdi
     feb:      	movl	$0x4, %r14d
     ff1:      	movl	$0x8, %ecx
     ff6:      	movl	$0x4, %eax
     ffb:      	movl	$0x8, %esi
    1000:      	movq	%rbp, %rdx
    1003:      	callq	*%rax
    1005:      	movq	0x30(%rsp), %r12
    100a:      	testq	%r12, %r12
    100d:      	je	0x2175 <generic_retkprobe_event+0x2175>
    1013:      	movq	0x8(%rsp), %r13
    1018:      	movq	%r12, 0xc4(%r13)
    101f:      	leaq	0xc2(%r13), %rdi
    1026:      	leaq	0x10(%r12), %rdx
    102b:      	movl	$0x2, %ecx
    1030:      	movl	$0x4, %eax
    1035:      	movl	$0x2, %esi
    103a:      	callq	*%rax
    103c:      	leaq	0xd6(%r13), %rdi
    1043:      	leaq	0x12(%r12), %rdx
    1048:      	movl	$0x1, %ecx
    104d:      	movl	$0x4, %eax
    1052:      	movl	$0x1, %esi
    1057:      	callq	*%rax
    1059:      	leaq	0xd4(%r13), %rdi
    1060:      	leaq	0x226(%r12), %rdx
    1068:      	movl	$0x2, %ecx
    106d:      	movl	$0x4, %eax
    1072:      	movl	$0x2, %esi
    1077:      	callq	*%rax
    1079:      	leaq	0xc0(%r13), %rdi
    1080:      	leaq	0x224(%r12), %rdx
    1088:      	movl	$0x2, %ecx
    108d:      	movl	$0x4, %eax
    1092:      	movl	$0x2, %esi
    1097:      	callq	*%rax
    1099:      	leaq	0xcc(%r13), %rdi
    10a0:      	leaq	0x21c(%r12), %rdx
    10a8:      	movl	$0x4, %eax
    10ad:      	movl	$0x4, %esi
    10b2:      	callq	*%rax
    10b4:      	leaq	0xd0(%r13), %rdi
    10bb:      	leaq	0x218(%r12), %rdx
    10c3:      	movl	$0x4, %eax
    10c8:      	movl	$0x4, %esi
    10cd:      	callq	*%rax
    10cf:      	leaq	0xac(%r13), %r14
    10d6:      	movq	0x10(%rsp), %rax
    10db:      	movq	$0x0, (%rax)
    10e2:      	movq	$0x0, 0x8(%rax)
    10ea:      	movq	$0x0, 0x10(%rax)
    10f2:      	movq	%rax, %rdi
    10f5:      	movq	$0x0, 0x18(%rax)
    10fd:      	movzwl	0xc2(%r13), %eax
    1105:      	cmpl	$0xa, %eax
    1108:      	je	0x20ed <generic_retkprobe_event+0x20ed>
    110e:      	cmpl	$0x2, %eax
    1111:      	jne	0x211c <generic_retkprobe_event+0x211c>
    1117:      	leaq	0x4(%r12), %rdx
    111c:      	movl	$0x4, %ecx
    1121:      	movl	$0x4, %eax
    1126:      	movl	$0x4, %esi
    112b:      	callq	*%rax
    112d:      	movl	$0x4, %ecx
    1132:      	movl	$0x4, %eax
    1137:      	movq	%r14, %rdi
    113a:      	movl	$0x4, %esi
    113f:      	movq	%r12, %rdx
    1142:      	jmp	0x211a <generic_retkprobe_event+0x211a>
    1147:      	cmpl	$0x1a, %r14d
    114b:      	je	0x1d68 <generic_retkprobe_event+0x1d68>
    1151:      	cmpl	$0x1b, %r14d
    1155:      	jne	0x2b88 <generic_retkprobe_event+0x2b88>
    115b:      	movq	0x10(%rsp), %rax
    1160:      	movq	$0x0, 0x48(%rax)
    1168:      	movq	$0x0, 0x40(%rax)
    1170:      	movq	$0x0, 0x38(%rax)
    1178:      	movq	$0x0, 0x30(%rax)
    1180:      	movq	$0x0, 0x28(%rax)
    1188:      	movq	$0x0, 0x20(%rax)
    1190:      	movq	$0x0, 0x18(%rax)
    1198:      	movq	$0x0, 0x10(%rax)
    11a0:      	movq	$0x0, 0x8(%rax)
    11a8:      	movq	$0x0, (%rax)
    11af:      	leaq	0xac(%rcx), %rdi
    11b6:      	leaq	0x18(%rbp), %rdx
    11ba:      	movl	$0x3f, %ecx
    11bf:      	movl	$0x2d, %eax
    11c4:      	movl	$0x3f, %esi
    11c9:      	callq	*%rax
    11cb:      	testq	%rax, %rax
    11ce:      	js	0x20e5 <generic_retkprobe_event+0x20e5>
    11d4:      	movq	0x8(%rsp), %r14
    11d9:      	movq	%r14, %rdi
    11dc:      	addq	$0xa4, %rdi
    11e3:      	addq	$0x348, %rbp            # imm = 0x348
    11ea:      	movl	$0x8, %ecx
    11ef:      	movl	$0x4, %eax
    11f4:      	movl	$0x8, %esi
    11f9:      	movq	%rbp, %rdx
    11fc:      	callq	*%rax
    11fe:      	movq	%r14, %rcx
    1201:      	movl	$0x50, %r13d
    1207:      	jmp	0x2b88 <generic_retkprobe_event+0x2b88>
    120c:      	cmpl	$0x26, %r14d
    1210:      	movq	0x8(%rsp), %rcx
    1215:      	jne	0x2b80 <generic_retkprobe_event+0x2b80>
    121b:      	movq	0x20(%rsp), %rsi
    1220:      	movzwl	%si, %edx
    1223:      	addq	0xc0(%rsp), %rdx
    122b:      	shrl	$0x10, %esi
    122e:      	andl	$0xfff, %esi            # imm = 0xFFF
    1234:      	movq	%rcx, %rdi
    1237:      	addq	$0xa0, %rdi
    123e:      	incl	%esi
    1240:      	movl	$0x2d, %eax
    1245:      	callq	*%rax
    1247:      	movq	%rax, %r13
    124a:      	testq	%rax, %rax
    124d:      	jns	0x1717 <generic_retkprobe_event+0x1717>
    1253:      	jmp	0x1e15 <generic_retkprobe_event+0x1e15>
    1258:      	cmpl	$0x8, %r14d
    125c:      	je	0x18af <generic_retkprobe_event+0x18af>
    1262:      	cmpl	$0x12, %r14d
    1266:      	jne	0x2b88 <generic_retkprobe_event+0x2b88>
    126c:      	xorl	%r13d, %r13d
    126f:      	movl	$0x4, %eax
    1274:      	movq	0x10(%rsp), %rdi
    1279:      	xorl	%esi, %esi
    127b:      	movq	%rbp, %rdx
    127e:      	callq	*%rax
    1280:      	movq	0x8(%rsp), %rcx
    1285:      	jmp	0x2b88 <generic_retkprobe_event+0x2b88>
    128a:      	cmpl	$0x13, %r14d
    128e:      	je	0x1c59 <generic_retkprobe_event+0x1c59>
    1294:      	cmpl	$0x14, %r14d
    1298:      	jne	0x2b88 <generic_retkprobe_event+0x2b88>
    129e:      	movq	$0x0, 0x30(%rsp)
    12a7:      	leaq	0x110(%rbp), %rdx
    12ae:      	leaq	0x30(%rsp), %rdi
    12b3:      	movl	$0x8, %ecx
    12b8:      	movl	$0x4, %eax
    12bd:      	leaq	0xd8(%rbp), %r14
    12c4:      	movl	$0x8, %esi
    12c9:      	callq	*%rax
    12cb:      	movq	0x30(%rsp), %rcx
    12d0:      	movl	$0x80, %edx
    12d5:      	movl	$0x2d, %eax
    12da:      	movq	0x10(%rsp), %rdi
    12df:      	movq	0x30(%rsp), %rdx
    12e4:      	movl	$0x80, %esi
    12e9:      	callq	*%rax
    12eb:      	movq	0x8(%rsp), %rax
    12f0:      	leaq	0x12c(%rax), %rdi
    12f7:      	movl	$0x4, %ecx
    12fc:      	movl	$0x4, %eax
    1301:      	movl	$0x4, %esi
    1306:      	movq	%r14, %rdx
    1309:      	callq	*%rax
    130b:      	movq	0x8(%rsp), %rax
    1310:      	leaq	0x11c(%rax), %rdi
    1317:      	leaq	0xe0(%rbp), %rdx
    131e:      	movl	$0x8, %ecx
    1323:      	movl	$0x4, %eax
    1328:      	movl	$0x8, %esi
    132d:      	callq	*%rax
    132f:      	movq	0x8(%rsp), %rdi
    1334:      	addq	$0x124, %rdi            # imm = 0x124
    133b:      	addq	$0x118, %rbp            # imm = 0x118
    1342:      	movl	$0x8, %ecx
    1347:      	movl	$0x4, %eax
    134c:      	movl	$0x8, %esi
    1351:      	movq	%rbp, %rdx
    1354:      	callq	*%rax
    1356:      	movq	0x8(%rsp), %rcx
    135b:      	movl	$0x98, %r13d
    1361:      	jmp	0x2b88 <generic_retkprobe_event+0x2b88>
    1366:      	movq	%rax, %r15
    1369:      	movq	0x20(%rsp), %r14
    136e:      	leaq	0xb8(%rsp), %rdi
    1376:      	movl	$0x1, %ecx
    137b:      	movl	$0x4, %eax
    1380:      	movl	$0x1, %esi
    1385:      	movq	%r14, %rdx
    1388:      	callq	*%rax
    138a:      	cmpb	$0x1, 0xb8(%rsp)
    1392:      	jne	0x1df3 <generic_retkprobe_event+0x1df3>
    1398:      	addq	$0x10, %r14
    139c:      	leaq	0x30(%rsp), %rdi
    13a1:      	movl	$0x8, %ecx
    13a6:      	movl	$0x4, %eax
    13ab:      	movl	$0x8, %esi
    13b0:      	movq	%r14, %rdx
    13b3:      	callq	*%rax
    13b5:      	movq	0x30(%rsp), %rdx
    13ba:      	leaq	0x70(%rsp), %rdi
    13bf:      	movl	$0x8, %ecx
    13c4:      	movl	$0x4, %eax
    13c9:      	movl	$0x8, %esi
    13ce:      	callq	*%rax
    13d0:      	movq	0x30(%rsp), %rdx
    13d5:      	addq	$0x8, %rdx
    13d9:      	leaq	0xa0(%rsp), %rdi
    13e1:      	movl	$0x8, %ecx
    13e6:      	movl	$0x4, %eax
    13eb:      	movl	$0x8, %esi
    13f0:      	callq	*%rax
    13f2:      	movq	0x70(%rsp), %rdx
    13f7:      	movq	0xa0(%rsp), %r14
    13ff:      	cmpq	$0xfff, %r14            # imm = 0xFFF
    1406:      	movl	$0xfff, %r13d           # imm = 0xFFF
    140c:      	cmovbq	%r14, %r13
    1410:      	movq	%r15, %rdi
    1413:      	addq	$0xa4, %rdi
    141a:      	movl	$0x4, %eax
    141f:      	movl	%r13d, %esi
    1422:      	callq	*%rax
    1424:      	testl	%eax, %eax
    1426:      	js	0x1faf <generic_retkprobe_event+0x1faf>
    142c:      	movl	%r14d, 0x9c(%r15)
    1433:      	movl	%r13d, 0xa0(%r15)
    143a:      	addq	$0x8, %r13
    143e:      	movq	0x8(%rsp), %rcx
    1443:      	jmp	0x2b80 <generic_retkprobe_event+0x2b80>
    1448:      	movq	0x20(%rsp), %rbp
    144d:      	leaq	0xc4(%rcx), %rdi
    1454:      	leaq	0x98(%rbp), %rdx
    145b:      	movl	$0x4, %esi
    1460:      	movq	%rcx, %r14
    1463:      	movl	$0x4, %eax
    1468:      	movl	$0x4, %esi
    146d:      	callq	*%rax
    146f:      	leaq	0xc8(%r14), %rdi
    1476:      	leaq	0x70(%rbp), %rdx
    147a:      	movl	$0x4, %ecx
    147f:      	movl	$0x4, %eax
    1484:      	movl	$0x4, %esi
    1489:      	callq	*%rax
    148b:      	leaq	0xcc(%r14), %rdi
    1492:      	leaq	0x90(%rbp), %rdx
    1499:      	movl	$0x4, %ecx
    149e:      	movl	$0x4, %eax
    14a3:      	movl	$0x4, %esi
    14a8:      	callq	*%rax
    14aa:      	leaq	0xd0(%r14), %rdi
    14b1:      	leaq	0xa8(%rbp), %rdx
    14b8:      	movl	$0x4, %ecx
    14bd:      	movl	$0x4, %eax
    14c2:      	movl	$0x4, %esi
    14c7:      	callq	*%rax
    14c9:      	movq	$0x0, 0x30(%rsp)
    14d2:      	leaq	0xc8(%rbp), %rdx
    14d9:      	leaq	0x30(%rsp), %rdi
    14de:      	movl	$0x8, %ecx
    14e3:      	movl	$0x4, %eax
    14e8:      	movl	$0x8, %esi
    14ed:      	callq	*%rax
    14ef:      	leaq	0xb8(%rbp), %rdx
    14f6:      	leaq	0xb8(%rsp), %rdi
    14fe:      	movl	$0x2, %ecx
    1503:      	movl	$0x4, %eax
    1508:      	movl	$0x2, %esi
    150d:      	callq	*%rax
    150f:      	movzwl	0xb8(%rsp), %r12d
    1518:      	addq	0x30(%rsp), %r12
    151d:      	leaq	0xb4(%rsp), %rdi
    1525:      	movl	$0x1, %ecx
    152a:      	movl	$0x4, %eax
    152f:      	movl	$0x1, %esi
    1534:      	movq	%r12, %rdx
    1537:      	callq	*%rax
    1539:      	movzbl	0xb4(%rsp), %eax
    1541:      	shrl	$0x4, %eax
    1544:      	cmpl	$0x6, %eax
    1547:      	je	0x1e2d <generic_retkprobe_event+0x1e2d>
    154d:      	cmpl	$0x4, %eax
    1550:      	jne	0x2b70 <generic_retkprobe_event+0x2b70>
    1556:      	leaq	0x9(%r12), %rdx
    155b:      	leaq	0xd0(%rsp), %rdi
    1563:      	movl	$0x1, %ecx
    1568:      	movl	$0x4, %eax
    156d:      	movl	$0x1, %esi
    1572:      	callq	*%rax
    1574:      	movzbl	0xd0(%rsp), %eax
    157c:      	movq	0x8(%rsp), %rcx
    1581:      	movw	%ax, 0xc0(%rcx)
    1588:      	movw	$0x2, 0xc2(%rcx)
    1591:      	leaq	0xc(%r12), %rdx
    1596:      	movq	0x10(%rsp), %rdi
    159b:      	movq	$0x0, (%rdi)
    15a2:      	movq	$0x0, 0x8(%rdi)
    15aa:      	movq	$0x0, 0x10(%rdi)
    15b2:      	movq	$0x0, 0x18(%rdi)
    15ba:      	movl	$0x4, %esi
    15bf:      	movl	$0x4, %eax
    15c4:      	leaq	0xac(%rcx), %r14
    15cb:      	movl	$0x4, %esi
    15d0:      	callq	*%rax
    15d2:      	addq	$0x10, %r12
    15d6:      	movl	$0x4, %ecx
    15db:      	movl	$0x4, %eax
    15e0:      	movq	%r14, %rdi
    15e3:      	movl	$0x4, %esi
    15e8:      	movq	%r12, %rdx
    15eb:      	callq	*%rax
    15ed:      	leaq	0xb6(%rbp), %rdx
    15f4:      	leaq	0xd8(%rsp), %rdi
    15fc:      	movl	$0x2, %ecx
    1601:      	movl	$0x4, %eax
    1606:      	movl	$0x2, %esi
    160b:      	jmp	0x29e4 <generic_retkprobe_event+0x29e4>
    1610:      	movq	$0x0, 0x38(%rsp)
    1619:      	movq	$0x0, 0x30(%rsp)
    1622:      	movl	$0xe, %eax
    1627:      	callq	*%rax
    1629:      	shrq	$0x20, %rax
    162d:      	movq	%rax, 0x30(%rsp)
    1632:      	leaq	0x70(%rsp), %rdi
    1637:      	leaq	0x20(%rsp), %rdx
    163c:      	movl	$0x4, %ecx
    1641:      	movl	$0x4, %eax
    1646:      	movl	$0x4, %r15d
    164c:      	movl	$0x4, %esi
    1651:      	callq	*%rax
    1653:      	movl	0x70(%rsp), %eax
    1657:      	movl	%eax, 0x38(%rsp)
    165b:      	movq	(%rip), %rdi            # 0x1662 <generic_retkprobe_event+0x1662>
    1662:      	leaq	0x30(%rsp), %rsi
    1667:      	movl	$0x1, %eax
    166c:      	callq	*%rax
    166e:      	testq	%rax, %rax
    1671:      	je	0x1e0e <generic_retkprobe_event+0x1e0e>
    1677:      	movl	(%rax), %r13d
    167a:      	leaq	0x70(%rsp), %rdx
    167f:      	movq	%rax, %r14
    1682:      	movl	$0x4, %eax
    1687:      	movq	0x10(%rsp), %rbp
    168c:      	movq	%rbp, %rdi
    168f:      	movl	$0x4, %esi
    1694:      	callq	*%rax
    1696:      	andl	$0xfff, %r13d           # imm = 0xFFF
    169d:      	movq	0x8(%rsp), %rdi
    16a2:      	addq	$0xa0, %rdi
    16a9:      	leaq	0x4(%r13), %rsi
    16ad:      	movl	$0x4, %eax
    16b2:      	movq	%r14, %rdx
    16b5:      	callq	*%rax
    16b7:      	leaq	0x8(,%r13), %rdi
    16bf:      	addq	%rbp, %rdi
    16c2:      	leaq	(%r14,%r13), %rdx
    16c6:      	addq	$0x4, %rdx
    16ca:      	movl	$0x4, %eax
    16cf:      	movl	$0x4, %esi
    16d4:      	callq	*%rax
    16d6:      	addq	$0xc, %r13
    16da:      	movq	0x8(%rsp), %rcx
    16df:      	jmp	0x2b80 <generic_retkprobe_event+0x2b80>
    16e4:      	movl	$0x120, %edx            # imm = 0x120
    16e9:      	addq	0x20(%rsp), %rdx
    16ee:      	movq	0x8(%rsp), %rdi
    16f3:      	addq	$0xa0, %rdi
    16fa:      	movl	$0x11, %ecx
    16ff:      	movl	$0x2d, %eax
    1704:      	movl	$0x11, %esi
    1709:      	callq	*%rax
    170b:      	movq	%rax, %r13
    170e:      	testq	%rax, %rax
    1711:      	js	0x1e15 <generic_retkprobe_event+0x1e15>
    1717:      	leal	-0x1(%r13), %eax
    171b:      	movq	0x10(%rsp), %rcx
    1720:      	movl	%eax, (%rcx)
    1722:      	addq	$0x3, %r13
    1726:      	movq	0x8(%rsp), %rcx
    172b:      	jmp	0x2b80 <generic_retkprobe_event+0x2b80>
    1730:      	xorl	%r13d, %r13d
    1733:      	cmpq	$0x3, 0x88(%rsp)
    173c:      	jb	0x1810 <generic_retkprobe_event+0x1810>
    1742:      	movq	%r15, 0x10(%rsp)
    1747:      	movq	0x98(%rsp), %rax
    174f:      	leaq	0x20(%rax), %rdx
    1753:      	leaq	0x30(%rsp), %rdi
    1758:      	movl	$0x4, %ebp
    175d:      	movl	$0x10, %ecx
    1762:      	movl	$0x4, %eax
    1767:      	movl	$0x10, %esi
    176c:      	callq	*%rax
    176e:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    1773:      	testl	%eax, %eax
    1775:      	js	0x1e1f <generic_retkprobe_event+0x1e1f>
    177b:      	movq	0x38(%rsp), %r15
    1780:      	cmpq	%r13, %r15
    1783:      	movq	%r13, %rax
    1786:      	cmovbq	%r15, %rax
    178a:      	movq	%r13, 0x28(%rsp)
    178f:      	testq	%r13, %r13
    1792:      	cmovneq	%rax, %r15
    1796:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    179b:      	cmpq	$0xffe, %r15            # imm = 0xFFE
    17a2:      	movq	0x18(%rsp), %r12
    17a7:      	ja	0x1fa6 <generic_retkprobe_event+0x1fa6>
    17ad:      	movq	%rax, %r13
    17b0:      	movq	0x8(%rsp), %rdi
    17b5:      	addq	0x80(%rsp), %rdi
    17bd:      	movq	%rdi, 0x8(%rsp)
    17c2:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    17c8:      	addq	%r12, %rdi
    17cb:      	movq	0x30(%rsp), %rcx
    17d0:      	movl	$0x4, %eax
    17d5:      	movq	0x30(%rsp), %rdx
    17da:      	movl	%r15d, %esi
    17dd:      	callq	*%rax
    17df:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    17e4:      	testl	%eax, %eax
    17e6:      	js	0x1fa6 <generic_retkprobe_event+0x1fa6>
    17ec:      	movq	%r15, %r12
    17ef:      	addq	%r15, 0x10(%rsp)
    17f4:      	cmpq	$0x0, 0x28(%rsp)
    17fa:      	je	0x220f <generic_retkprobe_event+0x220f>
    1800:      	subq	%r13, 0x28(%rsp)
    1805:      	jne	0x2216 <generic_retkprobe_event+0x2216>
    180b:      	jmp	0x2221 <generic_retkprobe_event+0x2221>
    1810:      	movq	%r15, %r12
    1813:      	jmp	0x43d <generic_retkprobe_event+0x43d>
    1818:      	movq	$0x0, 0x70(%rsp)
    1821:      	movq	$0x0, 0x30(%rsp)
    182a:      	leaq	0x70(%rsp), %rdi
    182f:      	leaq	0x30(%rsp), %rdx
    1834:      	movl	$0x8, %ecx
    1839:      	movq	%rax, %r15
    183c:      	movl	$0x4, %eax
    1841:      	movl	$0x4, %r13d
    1847:      	movl	$0x8, %esi
    184c:      	callq	*%rax
    184e:      	movq	0x70(%rsp), %r12
    1853:      	cmpq	$0xfff, %r12            # imm = 0xFFF
    185a:      	movl	$0xfff, %r14d           # imm = 0xFFF
    1860:      	cmovbq	%r12, %r14
    1864:      	movq	%r15, 0x10(%rsp)
    1869:      	addq	$0xa4, %r15
    1870:      	movl	$0x4, %eax
    1875:      	movq	%r15, %rdi
    1878:      	movl	%r14d, %esi
    187b:      	movq	%rbp, %rdx
    187e:      	callq	*%rax
    1880:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    1885:      	testl	%eax, %eax
    1887:      	js	0x189f <generic_retkprobe_event+0x189f>
    1889:      	movq	0x10(%rsp), %rax
    188e:      	movl	%r14d, 0xa0(%rax)
    1895:      	addq	$0x8, %r14
    1899:      	movl	%r12d, %ecx
    189c:      	movq	%r14, %r13
    189f:      	movq	0x10(%rsp), %rax
    18a4:      	movl	%ecx, 0x9c(%rax)
    18aa:      	jmp	0x21b9 <generic_retkprobe_event+0x21b9>
    18af:      	leaq	0xc4(%rcx), %r13
    18b6:      	leaq	0xdc(%rcx), %r12
    18bd:      	leaq	0x8(%rbp), %rdx
    18c1:      	movl	$0x4, %ecx
    18c6:      	movl	$0x4, %eax
    18cb:      	movq	0x10(%rsp), %rdi
    18d0:      	movl	$0x4, %esi
    18d5:      	callq	*%rax
    18d7:      	movq	0x8(%rsp), %rax
    18dc:      	leaq	0xa0(%rax), %rdi
    18e3:      	leaq	0xc(%rbp), %rdx
    18e7:      	movl	$0x4, %ecx
    18ec:      	movl	$0x4, %eax
    18f1:      	movl	$0x4, %esi
    18f6:      	callq	*%rax
    18f8:      	movq	0x8(%rsp), %rax
    18fd:      	leaq	0xac(%rax), %rdi
    1904:      	leaq	0x18(%rbp), %rdx
    1908:      	movl	$0x4, %ecx
    190d:      	movl	$0x4, %eax
    1912:      	movl	$0x4, %esi
    1917:      	callq	*%rax
    1919:      	movq	0x8(%rsp), %rax
    191e:      	leaq	0xb0(%rax), %rdi
    1925:      	leaq	0x1c(%rbp), %rdx
    1929:      	movl	$0x4, %ecx
    192e:      	movl	$0x4, %eax
    1933:      	movl	$0x4, %esi
    1938:      	callq	*%rax
    193a:      	movq	0x8(%rsp), %rax
    193f:      	leaq	0xa4(%rax), %rdi
    1946:      	leaq	0x10(%rbp), %rdx
    194a:      	movl	$0x4, %ecx
    194f:      	movl	$0x4, %eax
    1954:      	movl	$0x4, %esi
    1959:      	callq	*%rax
    195b:      	movq	0x8(%rsp), %rax
    1960:      	leaq	0xa8(%rax), %rdi
    1967:      	leaq	0x14(%rbp), %rdx
    196b:      	movl	$0x4, %ecx
    1970:      	movl	$0x4, %eax
    1975:      	movl	$0x4, %esi
    197a:      	callq	*%rax
    197c:      	movq	0x8(%rsp), %rax
    1981:      	leaq	0xb4(%rax), %rdi
    1988:      	leaq	0x20(%rbp), %rdx
    198c:      	movl	$0x4, %ecx
    1991:      	movl	$0x4, %eax
    1996:      	movl	$0x4, %esi
    199b:      	callq	*%rax
    199d:      	movq	0x8(%rsp), %rax
    19a2:      	leaq	0xb8(%rax), %rdi
    19a9:      	leaq	0x24(%rbp), %rdx
    19ad:      	movl	$0x4, %ecx
    19b2:      	movl	$0x4, %eax
    19b7:      	movl	$0x4, %esi
    19bc:      	callq	*%rax
    19be:      	movq	0x8(%rsp), %rax
    19c3:      	movl	$0x0, 0xc0(%rax)
    19cd:      	movq	0x8(%rsp), %rax
    19d2:      	leaq	0xbc(%rax), %rdi
    19d9:      	leaq	0x28(%rbp), %rdx
    19dd:      	movl	$0x4, %ecx
    19e2:      	movl	$0x4, %eax
    19e7:      	movl	$0x4, %esi
    19ec:      	callq	*%rax
    19ee:      	movq	0x8(%rsp), %rax
    19f3:      	leaq	0xcc(%rax), %rdi
    19fa:      	leaq	0x40(%rbp), %rdx
    19fe:      	movl	$0x8, %ecx
    1a03:      	movl	$0x4, %eax
    1a08:      	movl	$0x8, %esi
    1a0d:      	callq	*%rax
    1a0f:      	movq	0x8(%rsp), %rax
    1a14:      	leaq	0xd4(%rax), %rdi
    1a1b:      	leaq	0x30(%rbp), %rdx
    1a1f:      	movl	$0x8, %ecx
    1a24:      	movl	$0x4, %eax
    1a29:      	movl	$0x8, %esi
    1a2e:      	callq	*%rax
    1a30:      	leaq	0x38(%rbp), %rdx
    1a34:      	movl	$0x8, %ecx
    1a39:      	movl	$0x4, %eax
    1a3e:      	movq	%r13, %rdi
    1a41:      	movl	$0x8, %esi
    1a46:      	callq	*%rax
    1a48:      	addq	$0x90, %rbp
    1a4f:      	leaq	0x30(%rsp), %rdi
    1a54:      	movl	$0x8, %ecx
    1a59:      	movl	$0x4, %eax
    1a5e:      	movl	$0x8, %esi
    1a63:      	movq	%rbp, %rdx
    1a66:      	callq	*%rax
    1a68:      	movq	0x30(%rsp), %r14
    1a6d:      	leaq	0xc8(%r14), %rdx
    1a74:      	movl	$0x4, %ecx
    1a79:      	movl	$0x4, %eax
    1a7e:      	movq	%r12, %rdi
    1a81:      	movq	0x18(%rsp), %r12
    1a86:      	movl	$0x4, %esi
    1a8b:      	callq	*%rax
    1a8d:      	movq	0x8(%rsp), %rax
    1a92:      	leaq	0xe0(%rax), %rdi
    1a99:      	leaq	0xcc(%r14), %rdx
    1aa0:      	movl	$0x4, %ecx
    1aa5:      	movl	$0x4, %eax
    1aaa:      	movl	$0x4, %esi
    1aaf:      	callq	*%rax
    1ab1:      	movq	0x8(%rsp), %rax
    1ab6:      	leaq	0xe4(%rax), %rdi
    1abd:      	leaq	0xd0(%r14), %rdx
    1ac4:      	movl	$0x4, %ecx
    1ac9:      	movl	$0x4, %eax
    1ace:      	movl	$0x4, %esi
    1ad3:      	callq	*%rax
    1ad5:      	movq	0x8(%rsp), %rdi
    1ada:      	addq	$0xe8, %rdi
    1ae1:      	addq	$0x158, %r14            # imm = 0x158
    1ae8:      	movl	$0x4, %ecx
    1aed:      	movl	$0x4, %eax
    1af2:      	movl	$0x4, %esi
    1af7:      	movq	%r14, %rdx
    1afa:      	callq	*%rax
    1afc:      	movq	0x8(%rsp), %rcx
    1b01:      	movl	$0x50, %r13d
    1b07:      	jmp	0x2b88 <generic_retkprobe_event+0x2b88>
    1b0c:      	leaq	0xc8(%rbp), %rdx
    1b13:      	movl	$0x4, %ecx
    1b18:      	movl	$0x4, %eax
    1b1d:      	movq	0x10(%rsp), %rdi
    1b22:      	movl	$0x4, %esi
    1b27:      	callq	*%rax
    1b29:      	movq	0x8(%rsp), %rax
    1b2e:      	leaq	0xa0(%rax), %rdi
    1b35:      	leaq	0xcc(%rbp), %rdx
    1b3c:      	movl	$0x4, %ecx
    1b41:      	movl	$0x4, %eax
    1b46:      	movl	$0x4, %esi
    1b4b:      	callq	*%rax
    1b4d:      	movq	0x8(%rsp), %rax
    1b52:      	leaq	0xa4(%rax), %rdi
    1b59:      	leaq	0xd0(%rbp), %rdx
    1b60:      	movl	$0x4, %ecx
    1b65:      	movl	$0x4, %eax
    1b6a:      	movl	$0x4, %esi
    1b6f:      	callq	*%rax
    1b71:      	movq	0x8(%rsp), %rdi
    1b76:      	addq	$0xa8, %rdi
    1b7d:      	addq	$0x158, %rbp            # imm = 0x158
    1b84:      	movl	$0x4, %ecx
    1b89:      	movl	$0x4, %eax
    1b8e:      	movl	$0x4, %esi
    1b93:      	movq	%rbp, %rdx
    1b96:      	callq	*%rax
    1b98:      	movq	0x8(%rsp), %rcx
    1b9d:      	movl	$0x10, %r13d
    1ba3:      	jmp	0x2b88 <generic_retkprobe_event+0x2b88>
    1ba8:      	leaq	0x38(%rbp), %rdx
    1bac:      	movl	$0x4, %ecx
    1bb1:      	movl	$0x4, %eax
    1bb6:      	movq	0x10(%rsp), %rdi
    1bbb:      	movl	$0x4, %esi
    1bc0:      	callq	*%rax
    1bc2:      	movq	0x8(%rsp), %rax
    1bc7:      	leaq	0xa0(%rax), %rdi
    1bce:      	leaq	0x3c(%rbp), %rdx
    1bd2:      	movl	$0x4, %ecx
    1bd7:      	movl	$0x4, %eax
    1bdc:      	movl	$0x4, %esi
    1be1:      	callq	*%rax
    1be3:      	movq	0x8(%rsp), %rax
    1be8:      	leaq	0xa4(%rax), %rdi
    1bef:      	leaq	0x40(%rbp), %rdx
    1bf3:      	movl	$0x4, %ecx
    1bf8:      	movl	$0x4, %eax
    1bfd:      	movl	$0x4, %esi
    1c02:      	callq	*%rax
    1c04:      	movq	0x8(%rsp), %rax
    1c09:      	leaq	0xa8(%rax), %rdi
    1c10:      	leaq	0x44(%rbp), %rdx
    1c14:      	movl	$0x4, %ecx
    1c19:      	movl	$0x4, %eax
    1c1e:      	movl	$0x4, %esi
    1c23:      	callq	*%rax
    1c25:      	movq	0x8(%rsp), %rdi
    1c2a:      	addq	$0xac, %rdi
    1c31:      	subq	$-0x80, %rbp
    1c35:      	movl	$0x10, %ecx
    1c3a:      	movl	$0x4, %eax
    1c3f:      	movl	$0x10, %esi
    1c44:      	movq	%rbp, %rdx
    1c47:      	callq	*%rax
    1c49:      	movq	0x8(%rsp), %rcx
    1c4e:      	movl	$0x20, %r13d
    1c54:      	jmp	0x2b88 <generic_retkprobe_event+0x2b88>
    1c59:      	movl	$0x4, %ecx
    1c5e:      	movl	$0x4, %eax
    1c63:      	movq	0x10(%rsp), %rdi
    1c68:      	movl	$0x4, %esi
    1c6d:      	movq	%rbp, %rdx
    1c70:      	callq	*%rax
    1c72:      	movq	0x8(%rsp), %rax
    1c77:      	leaq	0xa0(%rax), %rdi
    1c7e:      	leaq	0x4(%rbp), %rdx
    1c82:      	movl	$0x4, %ecx
    1c87:      	movl	$0x4, %eax
    1c8c:      	movl	$0x4, %esi
    1c91:      	callq	*%rax
    1c93:      	movq	0x8(%rsp), %rdi
    1c98:      	addq	$0xa4, %rdi
    1c9f:      	addq	$0x30, %rbp
    1ca3:      	movl	$0x10, %ecx
    1ca8:      	movl	$0x4, %eax
    1cad:      	movl	$0x10, %esi
    1cb2:      	movq	%rbp, %rdx
    1cb5:      	jmp	0x1d56 <generic_retkprobe_event+0x1d56>
    1cba:      	leaq	0x4(%rbp), %rdx
    1cbe:      	leaq	0x30(%rsp), %rdi
    1cc3:      	movl	$0x4, %ecx
    1cc8:      	movl	$0x4, %eax
    1ccd:      	movl	$0x4, %esi
    1cd2:      	callq	*%rax
    1cd4:      	movl	0x30(%rsp), %ecx
    1cd8:      	movq	0x8(%rsp), %rax
    1cdd:      	movl	%ecx, 0x9c(%rax)
    1ce3:      	leaq	0xc(%rbp), %rdx
    1ce7:      	leaq	0x30(%rsp), %rdi
    1cec:      	movl	$0x4, %ecx
    1cf1:      	movl	$0x4, %eax
    1cf6:      	movl	$0x4, %esi
    1cfb:      	callq	*%rax
    1cfd:      	movl	0x30(%rsp), %ecx
    1d01:      	movq	0x8(%rsp), %rax
    1d06:      	movl	%ecx, 0xa0(%rax)
    1d0c:      	addq	$0x50, %rbp
    1d10:      	leaq	0x30(%rsp), %rdi
    1d15:      	movl	$0x8, %ecx
    1d1a:      	movl	$0x2d, %eax
    1d1f:      	movl	$0x8, %esi
    1d24:      	movq	%rbp, %rdx
    1d27:      	callq	*%rax
    1d29:      	movq	0x8(%rsp), %rdi
    1d2e:      	addq	$0xa4, %rdi
    1d35:      	movl	$0x3f8, %edx            # imm = 0x3F8
    1d3a:      	movq	0x30(%rsp), %rcx
    1d3f:      	addq	%rdx, %rcx
    1d42:      	movl	$0x10, %esi
    1d47:      	movl	$0x2d, %eax
    1d4c:      	addq	0x30(%rsp), %rdx
    1d51:      	movl	$0x10, %esi
    1d56:      	callq	*%rax
    1d58:      	movq	0x8(%rsp), %rcx
    1d5d:      	movl	$0x18, %r13d
    1d63:      	jmp	0x2b88 <generic_retkprobe_event+0x2b88>
    1d68:      	movq	0x10(%rsp), %rax
    1d6d:      	movq	$0x0, 0x48(%rax)
    1d75:      	movq	$0x0, 0x40(%rax)
    1d7d:      	movq	$0x0, 0x38(%rax)
    1d85:      	movq	$0x0, 0x30(%rax)
    1d8d:      	movq	$0x0, 0x28(%rax)
    1d95:      	movq	$0x0, 0x20(%rax)
    1d9d:      	movq	$0x0, 0x18(%rax)
    1da5:      	movq	$0x0, 0x10(%rax)
    1dad:      	movq	$0x0, 0x8(%rax)
    1db5:      	movq	%rax, %r14
    1db8:      	movq	$0x0, (%rax)
    1dbf:      	leaq	0x30(%rsp), %rdi
    1dc4:      	movl	$0x8, %ecx
    1dc9:      	movl	$0x4, %eax
    1dce:      	movl	$0x8, %esi
    1dd3:      	movq	%rbp, %rdx
    1dd6:      	callq	*%rax
    1dd8:      	testq	%rax, %rax
    1ddb:      	je	0x202e <generic_retkprobe_event+0x202e>
    1de1:      	xorl	%r13d, %r13d
    1de4:      	movq	0x8(%rsp), %rcx
    1de9:      	movq	0x18(%rsp), %r12
    1dee:      	jmp	0x2b88 <generic_retkprobe_event+0x2b88>
    1df3:      	movq	$0x0, 0x9c(%r15)
    1dfe:      	movl	$0x8, %r13d
    1e04:      	movq	0x8(%rsp), %rcx
    1e09:      	jmp	0x2b80 <generic_retkprobe_event+0x2b80>
    1e0e:      	movq	$-0x1, %r13
    1e15:      	movq	0x8(%rsp), %rcx
    1e1a:      	jmp	0x2b80 <generic_retkprobe_event+0x2b80>
    1e1f:      	movq	0x18(%rsp), %r12
    1e24:      	movl	%ecx, (%r12,%r14)
    1e28:      	jmp	0x2d79 <generic_retkprobe_event+0x2d79>
    1e2d:      	movq	0x30(%rsp), %r14
    1e32:      	movl	$0x0, 0x70(%rsp)
    1e3a:      	movzwl	0xb8(%rsp), %r15d
    1e43:      	movq	(%rip), %rdi            # 0x1e4a <generic_retkprobe_event+0x1e4a>
    1e4a:      	leaq	0x70(%rsp), %rsi
    1e4f:      	movl	$0x1, %eax
    1e54:      	leaq	(%r14,%r15), %r13
    1e58:      	callq	*%rax
    1e5a:      	testq	%rax, %rax
    1e5d:      	je	0x298a <generic_retkprobe_event+0x298a>
    1e63:      	movq	%rax, %r12
    1e66:      	movw	%r15w, (%r12)
    1e6b:      	movb	$-0x1, 0x5(%r12)
    1e71:      	movb	$0x0, 0x7(%r12)
    1e77:      	movq	%r12, %rdi
    1e7a:      	addq	$0x6, %rdi
    1e7e:      	leaq	0x6(%r13), %rdx
    1e82:      	movl	$0x1, %ecx
    1e87:      	movl	$0x4, %eax
    1e8c:      	movq	%rdi, %r15
    1e8f:      	movl	$0x1, %esi
    1e94:      	callq	*%rax
    1e96:      	testq	%rax, %rax
    1e99:      	js	0x298a <generic_retkprobe_event+0x298a>
    1e9f:      	movzbl	0x5(%r12), %eax
    1ea5:      	cmpl	$0x32, %eax
    1ea8:      	jg	0x21d0 <generic_retkprobe_event+0x21d0>
    1eae:      	testl	%eax, %eax
    1eb0:      	je	0x21fa <generic_retkprobe_event+0x21fa>
    1eb6:      	cmpl	$0x2b, %eax
    1eb9:      	je	0x21fa <generic_retkprobe_event+0x21fa>
    1ebf:      	cmpl	$0x2c, %eax
    1ec2:      	jne	0x23bc <generic_retkprobe_event+0x23bc>
    1ec8:      	movw	$0x8, 0x2(%r12)
    1ed0:      	movw	$0x8, %ax
    1ed4:      	jmp	0x22fd <generic_retkprobe_event+0x22fd>
    1ed9:      	leaq	0x48(%r12), %rdx
    1ede:      	movl	$0x10, %ecx
    1ee3:      	movl	$0x4, %eax
    1ee8:      	movq	0x10(%rsp), %rdi
    1eed:      	movl	$0x10, %esi
    1ef2:      	callq	*%rax
    1ef4:      	leaq	0x38(%r12), %rdx
    1ef9:      	movl	$0x10, %ecx
    1efe:      	movl	$0x4, %eax
    1f03:      	movq	%r14, %rdi
    1f06:      	movl	$0x10, %esi
    1f0b:      	callq	*%rax
    1f0d:      	movq	0x8(%rsp), %r13
    1f12:      	leaq	0xbc(%r13), %rdi
    1f19:      	leaq	0xc(%r12), %r14
    1f1e:      	addq	$0xe, %r12
    1f22:      	movl	$0x2, %ecx
    1f27:      	movl	$0x4, %eax
    1f2c:      	movl	$0x2, %esi
    1f31:      	movq	%r12, %rdx
    1f34:      	callq	*%rax
    1f36:      	movq	%r13, %rdi
    1f39:      	addq	$0xbe, %rdi
    1f40:      	movl	$0x2, %ecx
    1f45:      	movl	$0x4, %eax
    1f4a:      	movl	$0x2, %esi
    1f4f:      	movq	%r14, %rdx
    1f52:      	callq	*%rax
    1f54:      	movzwl	0xbe(%r13), %eax
    1f5c:      	movbew	%ax, 0xbe(%r13)
    1f66:      	movq	0x20(%rsp), %rax
    1f6b:      	movq	%rax, 0x30(%rsp)
    1f70:      	movq	(%rip), %rdi            # 0x1f77 <generic_retkprobe_event+0x1f77>
    1f77:      	leaq	0x30(%rsp), %rsi
    1f7c:      	movl	$0x1, %eax
    1f81:      	callq	*%rax
    1f83:      	testq	%rax, %rax
    1f86:      	je	0x2b70 <generic_retkprobe_event+0x2b70>
    1f8c:      	movl	(%rax), %ecx
    1f8e:      	movl	%ecx, 0x10(%r15)
    1f92:      	movq	0x8(%rax), %rcx
    1f96:      	movq	%rcx, 0x18(%r15)
    1f9a:      	movl	0x4(%rax), %eax
    1f9d:      	movl	%eax, 0x7c(%r15)
    1fa1:      	jmp	0x2b70 <generic_retkprobe_event+0x2b70>
    1fa6:      	movl	%ecx, (%r12,%r14)
    1faa:      	jmp	0x2d79 <generic_retkprobe_event+0x2d79>
    1faf:      	movl	$0xfffffffe, 0x9c(%r15) # imm = 0xFFFFFFFE
    1fba:      	movl	$0x4, %r13d
    1fc0:      	movq	0x8(%rsp), %rcx
    1fc5:      	jmp	0x2b80 <generic_retkprobe_event+0x2b80>
    1fca:      	movq	0x8(%rsp), %r14
    1fcf:      	leaq	0xa4(%r14), %rdi
    1fd6:      	leaq	0x8(%r12), %rdx
    1fdb:      	movl	$0x10, %ecx
    1fe0:      	movl	$0x4, %eax
    1fe5:      	movl	$0x10, %esi
    1fea:      	callq	*%rax
    1fec:      	movq	%r14, %rdi
    1fef:      	addq	$0x9e, %rdi
    1ff6:      	addq	$0x2, %r12
    1ffa:      	movl	$0x2, %ecx
    1fff:      	movl	$0x4, %eax
    2004:      	movl	$0x2, %esi
    2009:      	movq	%r12, %rdx
    200c:      	callq	*%rax
    200e:      	movq	0x8(%rsp), %rax
    2013:      	movzwl	0x9e(%rax), %ecx
    201a:      	movbew	%cx, 0x9e(%rax)
    2023:      	movl	$0x18, %r13d
    2029:      	jmp	0x2b76 <generic_retkprobe_event+0x2b76>
    202e:      	movq	0x8(%rsp), %rax
    2033:      	leaq	0xac(%rax), %rdi
    203a:      	movq	0x30(%rsp), %rcx
    203f:      	movl	$0x3f, %edx
    2044:      	movl	$0x2d, %eax
    2049:      	movq	0x30(%rsp), %rdx
    204e:      	movl	$0x3f, %esi
    2053:      	callq	*%rax
    2055:      	testq	%rax, %rax
    2058:      	js	0x1de1 <generic_retkprobe_event+0x1de1>
    205e:      	leaq	0x8(%rbp), %rdx
    2062:      	leaq	0x70(%rsp), %rdi
    2067:      	movl	$0x8, %ecx
    206c:      	movl	$0x4, %eax
    2071:      	movl	$0x8, %esi
    2076:      	callq	*%rax
    2078:      	movq	0x8(%rsp), %rdi
    207d:      	addq	$0xa4, %rdi
    2084:      	movl	$0x348, %edx            # imm = 0x348
    2089:      	movq	0x70(%rsp), %rcx
    208e:      	addq	%rdx, %rcx
    2091:      	movl	$0x8, %esi
    2096:      	movl	$0x4, %eax
    209b:      	addq	0x70(%rsp), %rdx
    20a0:      	movl	$0x8, %esi
    20a5:      	callq	*%rax
    20a7:      	addq	$0x58, %rbp
    20ab:      	leaq	0x70(%rsp), %rdi
    20b0:      	movl	$0x4, %ecx
    20b5:      	movl	$0x4, %eax
    20ba:      	movl	$0x4, %esi
    20bf:      	movq	%rbp, %rdx
    20c2:      	callq	*%rax
    20c4:      	movl	$0x50, %r13d
    20ca:      	testq	%rax, %rax
    20cd:      	jne	0x1de4 <generic_retkprobe_event+0x1de4>
    20d3:      	xorl	%eax, %eax
    20d5:      	cmpl	$0x0, 0x70(%rsp)
    20da:      	setne	%al
    20dd:      	movl	%eax, (%r14)
    20e0:      	jmp	0x1de4 <generic_retkprobe_event+0x1de4>
    20e5:      	xorl	%r13d, %r13d
    20e8:      	jmp	0x1280 <generic_retkprobe_event+0x1280>
    20ed:      	leaq	0x48(%r12), %rdx
    20f2:      	movl	$0x10, %ecx
    20f7:      	movl	$0x4, %eax
    20fc:      	movl	$0x10, %esi
    2101:      	callq	*%rax
    2103:      	leaq	0x38(%r12), %rdx
    2108:      	movl	$0x10, %ecx
    210d:      	movl	$0x4, %eax
    2112:      	movq	%r14, %rdi
    2115:      	movl	$0x10, %esi
    211a:      	callq	*%rax
    211c:      	movq	0x8(%rsp), %r13
    2121:      	leaq	0xbc(%r13), %rdi
    2128:      	leaq	0xc(%r12), %r14
    212d:      	addq	$0xe, %r12
    2131:      	movl	$0x2, %ecx
    2136:      	movl	$0x4, %eax
    213b:      	movl	$0x2, %esi
    2140:      	movq	%r12, %rdx
    2143:      	callq	*%rax
    2145:      	movq	%r13, %rdi
    2148:      	addq	$0xbe, %rdi
    214f:      	movl	$0x2, %ecx
    2154:      	movl	$0x4, %eax
    2159:      	movl	$0x2, %esi
    215e:      	movq	%r14, %rdx
    2161:      	callq	*%rax
    2163:      	movzwl	0xbe(%r13), %eax
    216b:      	movbew	%ax, 0xbe(%r13)
    2175:      	movq	0x8(%rsp), %rax
    217a:      	movq	0xc4(%rax), %rax
    2181:      	movq	%rax, 0x30(%rsp)
    2186:      	movq	(%rip), %rdi            # 0x218d <generic_retkprobe_event+0x218d>
    218d:      	leaq	0x30(%rsp), %rsi
    2192:      	movl	$0x1, %eax
    2197:      	callq	*%rax
    2199:      	testq	%rax, %rax
    219c:      	je	0x21b3 <generic_retkprobe_event+0x21b3>
    219e:      	movl	(%rax), %ecx
    21a0:      	movl	%ecx, 0x10(%r15)
    21a4:      	movq	0x8(%rax), %rcx
    21a8:      	movq	%rcx, 0x18(%r15)
    21ac:      	movl	0x4(%rax), %eax
    21af:      	movl	%eax, 0x7c(%r15)
    21b3:      	movl	$0x40, %r13d
    21b9:      	movq	0x8(%rsp), %rcx
    21be:      	movq	0x90(%rsp), %r15
    21c6:      	movq	0x18(%rsp), %r12
    21cb:      	jmp	0x2b88 <generic_retkprobe_event+0x2b88>
    21d0:      	cmpl	$0x33, %eax
    21d3:      	je	0x22e7 <generic_retkprobe_event+0x22e7>
    21d9:      	cmpl	$0x3c, %eax
    21dc:      	je	0x21fa <generic_retkprobe_event+0x21fa>
    21de:      	cmpl	$0xff, %eax
    21e3:      	jne	0x23bc <generic_retkprobe_event+0x23bc>
    21e9:      	movw	$0x28, 0x2(%r12)
    21f1:      	movw	$0x28, %ax
    21f5:      	jmp	0x22fd <generic_retkprobe_event+0x22fd>
    21fa:      	movq	%r12, %rcx
    21fd:      	movzbl	0x7(%r12), %eax
    2203:      	leal	0x8(,%rax,8), %eax
    220a:      	jmp	0x22f7 <generic_retkprobe_event+0x22f7>
    220f:      	xorl	%eax, %eax
    2211:      	movq	%rax, 0x28(%rsp)
    2216:      	cmpq	$0x3, 0x88(%rsp)
    221f:      	jne	0x222b <generic_retkprobe_event+0x222b>
    2221:      	movq	0x10(%rsp), %r12
    2226:      	jmp	0x43d <generic_retkprobe_event+0x43d>
    222b:      	movq	0x98(%rsp), %rax
    2233:      	leaq	0x30(%rax), %rdx
    2237:      	leaq	0x30(%rsp), %rdi
    223c:      	movl	$0x4, %ebp
    2241:      	movl	$0x10, %ecx
    2246:      	movl	$0x4, %eax
    224b:      	movl	$0x10, %esi
    2250:      	callq	*%rax
    2252:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2257:      	testl	%eax, %eax
    2259:      	js	0x2d70 <generic_retkprobe_event+0x2d70>
    225f:      	movq	0x38(%rsp), %rdx
    2264:      	movq	0x28(%rsp), %rax
    2269:      	cmpq	%rax, %rdx
    226c:      	movq	%rax, %r13
    226f:      	cmovbq	%rdx, %r13
    2273:      	testq	%rax, %rax
    2276:      	cmovneq	%r13, %rdx
    227a:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    227f:      	cmpq	$0xffe, %rdx            # imm = 0xFFE
    2286:      	ja	0x2d70 <generic_retkprobe_event+0x2d70>
    228c:      	movq	%rdx, %r15
    228f:      	movq	%r12, %rdi
    2292:      	addq	0x8(%rsp), %rdi
    2297:      	movq	%rdi, %r12
    229a:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    22a0:      	addq	0x18(%rsp), %rdi
    22a5:      	movq	0x30(%rsp), %rcx
    22aa:      	movl	$0x4, %eax
    22af:      	movq	%rdx, %rsi
    22b2:      	movq	0x30(%rsp), %rdx
    22b7:      	callq	*%rax
    22b9:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    22be:      	testl	%eax, %eax
    22c0:      	js	0x2d70 <generic_retkprobe_event+0x2d70>
    22c6:      	addq	%r15, 0x10(%rsp)
    22cb:      	cmpq	$0x0, 0x28(%rsp)
    22d1:      	je	0x2673 <generic_retkprobe_event+0x2673>
    22d7:      	subq	%r13, 0x28(%rsp)
    22dc:      	jne	0x267a <generic_retkprobe_event+0x267a>
    22e2:      	jmp	0x2221 <generic_retkprobe_event+0x2221>
    22e7:      	movq	%r12, %rcx
    22ea:      	movzbl	0x7(%r12), %eax
    22f0:      	leal	0x8(,%rax,4), %eax
    22f7:      	movw	%ax, 0x2(%r12)
    22fd:      	movq	%r12, %rcx
    2300:      	addw	(%r12), %ax
    2305:      	movw	%ax, (%r12)
    230a:      	movzbl	0x6(%r12), %ecx
    2310:      	cmpq	$0x3c, %rcx
    2314:      	ja	0x2bd5 <generic_retkprobe_event+0x2bd5>
    231a:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2324:      	btq	%rcx, %rdx
    2328:      	jae	0x2bd5 <generic_retkprobe_event+0x2bd5>
    232e:      	movb	%cl, 0x5(%r12)
    2333:      	movzwl	%ax, %ecx
    2336:      	addq	%r14, %rcx
    2339:      	movl	$0x2, %edx
    233e:      	movl	$0x4, %eax
    2343:      	movq	%r15, %rdi
    2346:      	movzwl	(%r12), %edx
    234b:      	addq	%r14, %rdx
    234e:      	movl	$0x2, %esi
    2353:      	callq	*%rax
    2355:      	testq	%rax, %rax
    2358:      	js	0x298a <generic_retkprobe_event+0x298a>
    235e:      	movzbl	0x5(%r12), %eax
    2364:      	cmpl	$0x32, %eax
    2367:      	jg	0x2385 <generic_retkprobe_event+0x2385>
    2369:      	testl	%eax, %eax
    236b:      	je	0x23a4 <generic_retkprobe_event+0x23a4>
    236d:      	cmpl	$0x2b, %eax
    2370:      	je	0x23a4 <generic_retkprobe_event+0x23a4>
    2372:      	cmpl	$0x2c, %eax
    2375:      	jne	0x23df <generic_retkprobe_event+0x23df>
    2377:      	movw	$0x8, 0x2(%r12)
    237f:      	movw	$0x8, %ax
    2383:      	jmp	0x23e5 <generic_retkprobe_event+0x23e5>
    2385:      	cmpl	$0x33, %eax
    2388:      	je	0x23c7 <generic_retkprobe_event+0x23c7>
    238a:      	cmpl	$0x3c, %eax
    238d:      	je	0x23a4 <generic_retkprobe_event+0x23a4>
    238f:      	cmpl	$0xff, %eax
    2394:      	jne	0x23df <generic_retkprobe_event+0x23df>
    2396:      	movw	$0x28, 0x2(%r12)
    239e:      	movw	$0x28, %ax
    23a2:      	jmp	0x23e5 <generic_retkprobe_event+0x23e5>
    23a4:      	movq	%r12, %rcx
    23a7:      	movzbl	0x7(%r12), %eax
    23ad:      	leal	0x8(,%rax,8), %eax
    23b4:      	movw	%ax, 0x2(%r12)
    23ba:      	jmp	0x23e5 <generic_retkprobe_event+0x23e5>
    23bc:      	movzwl	0x2(%r12), %eax
    23c2:      	jmp	0x22fd <generic_retkprobe_event+0x22fd>
    23c7:      	movq	%r12, %rcx
    23ca:      	movzbl	0x7(%r12), %eax
    23d0:      	leal	0x8(,%rax,4), %eax
    23d7:      	movw	%ax, 0x2(%r12)
    23dd:      	jmp	0x23e5 <generic_retkprobe_event+0x23e5>
    23df:      	movzwl	0x2(%r12), %eax
    23e5:      	movq	%r12, %rcx
    23e8:      	addw	(%r12), %ax
    23ed:      	movw	%ax, (%r12)
    23f2:      	movzbl	0x6(%r12), %ecx
    23f8:      	cmpq	$0x3c, %rcx
    23fc:      	ja	0x2bd5 <generic_retkprobe_event+0x2bd5>
    2402:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    240c:      	btq	%rcx, %rdx
    2410:      	jae	0x2bd5 <generic_retkprobe_event+0x2bd5>
    2416:      	movb	%cl, 0x5(%r12)
    241b:      	movzwl	%ax, %ecx
    241e:      	addq	%r14, %rcx
    2421:      	movl	$0x2, %edx
    2426:      	movl	$0x4, %eax
    242b:      	movq	%r15, %rdi
    242e:      	movzwl	(%r12), %edx
    2433:      	addq	%r14, %rdx
    2436:      	movl	$0x2, %esi
    243b:      	callq	*%rax
    243d:      	testq	%rax, %rax
    2440:      	js	0x298a <generic_retkprobe_event+0x298a>
    2446:      	movzbl	0x5(%r12), %eax
    244c:      	cmpl	$0x32, %eax
    244f:      	jg	0x246d <generic_retkprobe_event+0x246d>
    2451:      	testl	%eax, %eax
    2453:      	je	0x248c <generic_retkprobe_event+0x248c>
    2455:      	cmpl	$0x2b, %eax
    2458:      	je	0x248c <generic_retkprobe_event+0x248c>
    245a:      	cmpl	$0x2c, %eax
    245d:      	jne	0x24bc <generic_retkprobe_event+0x24bc>
    245f:      	movw	$0x8, 0x2(%r12)
    2467:      	movw	$0x8, %ax
    246b:      	jmp	0x24c2 <generic_retkprobe_event+0x24c2>
    246d:      	cmpl	$0x33, %eax
    2470:      	je	0x24a4 <generic_retkprobe_event+0x24a4>
    2472:      	cmpl	$0x3c, %eax
    2475:      	je	0x248c <generic_retkprobe_event+0x248c>
    2477:      	cmpl	$0xff, %eax
    247c:      	jne	0x24bc <generic_retkprobe_event+0x24bc>
    247e:      	movw	$0x28, 0x2(%r12)
    2486:      	movw	$0x28, %ax
    248a:      	jmp	0x24c2 <generic_retkprobe_event+0x24c2>
    248c:      	movq	%r12, %rcx
    248f:      	movzbl	0x7(%r12), %eax
    2495:      	leal	0x8(,%rax,8), %eax
    249c:      	movw	%ax, 0x2(%r12)
    24a2:      	jmp	0x24c2 <generic_retkprobe_event+0x24c2>
    24a4:      	movq	%r12, %rcx
    24a7:      	movzbl	0x7(%r12), %eax
    24ad:      	leal	0x8(,%rax,4), %eax
    24b4:      	movw	%ax, 0x2(%r12)
    24ba:      	jmp	0x24c2 <generic_retkprobe_event+0x24c2>
    24bc:      	movzwl	0x2(%r12), %eax
    24c2:      	movq	%r12, %rcx
    24c5:      	addw	(%r12), %ax
    24ca:      	movw	%ax, (%r12)
    24cf:      	movzbl	0x6(%r12), %ecx
    24d5:      	cmpq	$0x3c, %rcx
    24d9:      	ja	0x2bd5 <generic_retkprobe_event+0x2bd5>
    24df:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    24e9:      	btq	%rcx, %rdx
    24ed:      	jae	0x2bd5 <generic_retkprobe_event+0x2bd5>
    24f3:      	movb	%cl, 0x5(%r12)
    24f8:      	movzwl	%ax, %ecx
    24fb:      	addq	%r14, %rcx
    24fe:      	movl	$0x2, %edx
    2503:      	movl	$0x4, %eax
    2508:      	movq	%r15, %rdi
    250b:      	movzwl	(%r12), %edx
    2510:      	addq	%r14, %rdx
    2513:      	movl	$0x2, %esi
    2518:      	callq	*%rax
    251a:      	testq	%rax, %rax
    251d:      	js	0x298a <generic_retkprobe_event+0x298a>
    2523:      	movzbl	0x5(%r12), %eax
    2529:      	cmpl	$0x32, %eax
    252c:      	jg	0x254a <generic_retkprobe_event+0x254a>
    252e:      	testl	%eax, %eax
    2530:      	je	0x2569 <generic_retkprobe_event+0x2569>
    2532:      	cmpl	$0x2b, %eax
    2535:      	je	0x2569 <generic_retkprobe_event+0x2569>
    2537:      	cmpl	$0x2c, %eax
    253a:      	jne	0x2599 <generic_retkprobe_event+0x2599>
    253c:      	movw	$0x8, 0x2(%r12)
    2544:      	movw	$0x8, %ax
    2548:      	jmp	0x259f <generic_retkprobe_event+0x259f>
    254a:      	cmpl	$0x33, %eax
    254d:      	je	0x2581 <generic_retkprobe_event+0x2581>
    254f:      	cmpl	$0x3c, %eax
    2552:      	je	0x2569 <generic_retkprobe_event+0x2569>
    2554:      	cmpl	$0xff, %eax
    2559:      	jne	0x2599 <generic_retkprobe_event+0x2599>
    255b:      	movw	$0x28, 0x2(%r12)
    2563:      	movw	$0x28, %ax
    2567:      	jmp	0x259f <generic_retkprobe_event+0x259f>
    2569:      	movq	%r12, %rcx
    256c:      	movzbl	0x7(%r12), %eax
    2572:      	leal	0x8(,%rax,8), %eax
    2579:      	movw	%ax, 0x2(%r12)
    257f:      	jmp	0x259f <generic_retkprobe_event+0x259f>
    2581:      	movq	%r12, %rcx
    2584:      	movzbl	0x7(%r12), %eax
    258a:      	leal	0x8(,%rax,4), %eax
    2591:      	movw	%ax, 0x2(%r12)
    2597:      	jmp	0x259f <generic_retkprobe_event+0x259f>
    2599:      	movzwl	0x2(%r12), %eax
    259f:      	movq	%r12, %rcx
    25a2:      	addw	(%r12), %ax
    25a7:      	movw	%ax, (%r12)
    25ac:      	movzbl	0x6(%r12), %ecx
    25b2:      	cmpq	$0x3c, %rcx
    25b6:      	ja	0x2bd5 <generic_retkprobe_event+0x2bd5>
    25bc:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    25c6:      	btq	%rcx, %rdx
    25ca:      	jae	0x2bd5 <generic_retkprobe_event+0x2bd5>
    25d0:      	movb	%cl, 0x5(%r12)
    25d5:      	movzwl	%ax, %ecx
    25d8:      	addq	%r14, %rcx
    25db:      	movl	$0x2, %edx
    25e0:      	movl	$0x4, %eax
    25e5:      	movq	%r15, %rdi
    25e8:      	movzwl	(%r12), %edx
    25ed:      	addq	%r14, %rdx
    25f0:      	movl	$0x2, %esi
    25f5:      	callq	*%rax
    25f7:      	testq	%rax, %rax
    25fa:      	js	0x298a <generic_retkprobe_event+0x298a>
    2600:      	movzbl	0x5(%r12), %eax
    2606:      	cmpl	$0x32, %eax
    2609:      	jg	0x262e <generic_retkprobe_event+0x262e>
    260b:      	testl	%eax, %eax
    260d:      	je	0x2658 <generic_retkprobe_event+0x2658>
    260f:      	cmpl	$0x2b, %eax
    2612:      	je	0x2658 <generic_retkprobe_event+0x2658>
    2614:      	cmpl	$0x2c, %eax
    2617:      	jne	0x2772 <generic_retkprobe_event+0x2772>
    261d:      	movw	$0x8, 0x2(%r12)
    2625:      	movw	$0x8, %ax
    2629:      	jmp	0x2778 <generic_retkprobe_event+0x2778>
    262e:      	cmpl	$0x33, %eax
    2631:      	je	0x275a <generic_retkprobe_event+0x275a>
    2637:      	cmpl	$0x3c, %eax
    263a:      	je	0x2658 <generic_retkprobe_event+0x2658>
    263c:      	cmpl	$0xff, %eax
    2641:      	jne	0x2772 <generic_retkprobe_event+0x2772>
    2647:      	movw	$0x28, 0x2(%r12)
    264f:      	movw	$0x28, %ax
    2653:      	jmp	0x2778 <generic_retkprobe_event+0x2778>
    2658:      	movq	%r12, %rcx
    265b:      	movzbl	0x7(%r12), %eax
    2661:      	leal	0x8(,%rax,8), %eax
    2668:      	movw	%ax, 0x2(%r12)
    266e:      	jmp	0x2778 <generic_retkprobe_event+0x2778>
    2673:      	xorl	%eax, %eax
    2675:      	movq	%rax, 0x28(%rsp)
    267a:      	cmpq	$0x5, 0x88(%rsp)
    2683:      	jb	0x2221 <generic_retkprobe_event+0x2221>
    2689:      	movq	0x98(%rsp), %rax
    2691:      	leaq	0x40(%rax), %rdx
    2695:      	leaq	0x30(%rsp), %rdi
    269a:      	movl	$0x4, %ebp
    269f:      	movl	$0x10, %ecx
    26a4:      	movl	$0x4, %eax
    26a9:      	movl	$0x10, %esi
    26ae:      	callq	*%rax
    26b0:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    26b5:      	testl	%eax, %eax
    26b7:      	js	0x2d70 <generic_retkprobe_event+0x2d70>
    26bd:      	movq	0x38(%rsp), %rdx
    26c2:      	movq	0x28(%rsp), %rax
    26c7:      	cmpq	%rax, %rdx
    26ca:      	movq	%rax, %r13
    26cd:      	cmovbq	%rdx, %r13
    26d1:      	testq	%rax, %rax
    26d4:      	cmovneq	%r13, %rdx
    26d8:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    26dd:      	movq	%rdx, 0x80(%rsp)
    26e5:      	cmpq	$0xffe, %rdx            # imm = 0xFFE
    26ec:      	ja	0x2d70 <generic_retkprobe_event+0x2d70>
    26f2:      	movq	%r15, %rdi
    26f5:      	addq	%r12, %rdi
    26f8:      	movq	%rdi, %r15
    26fb:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2701:      	addq	0x18(%rsp), %rdi
    2706:      	movq	0x30(%rsp), %rcx
    270b:      	movl	$0x4, %eax
    2710:      	movq	0x80(%rsp), %rsi
    2718:      	movq	0x30(%rsp), %rdx
    271d:      	callq	*%rax
    271f:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2724:      	testl	%eax, %eax
    2726:      	js	0x2d70 <generic_retkprobe_event+0x2d70>
    272c:      	movq	0x10(%rsp), %rax
    2731:      	addq	0x80(%rsp), %rax
    2739:      	movq	%rax, 0x10(%rsp)
    273e:      	cmpq	$0x0, 0x28(%rsp)
    2744:      	je	0x2be2 <generic_retkprobe_event+0x2be2>
    274a:      	subq	%r13, 0x28(%rsp)
    274f:      	jne	0x2be9 <generic_retkprobe_event+0x2be9>
    2755:      	jmp	0x2221 <generic_retkprobe_event+0x2221>
    275a:      	movq	%r12, %rcx
    275d:      	movzbl	0x7(%r12), %eax
    2763:      	leal	0x8(,%rax,4), %eax
    276a:      	movw	%ax, 0x2(%r12)
    2770:      	jmp	0x2778 <generic_retkprobe_event+0x2778>
    2772:      	movzwl	0x2(%r12), %eax
    2778:      	movq	%r12, %rcx
    277b:      	addw	(%r12), %ax
    2780:      	movw	%ax, (%r12)
    2785:      	movzbl	0x6(%r12), %ecx
    278b:      	cmpq	$0x3c, %rcx
    278f:      	ja	0x2bd5 <generic_retkprobe_event+0x2bd5>
    2795:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    279f:      	btq	%rcx, %rdx
    27a3:      	jae	0x2bd5 <generic_retkprobe_event+0x2bd5>
    27a9:      	movb	%cl, 0x5(%r12)
    27ae:      	movzwl	%ax, %ecx
    27b1:      	addq	%r14, %rcx
    27b4:      	movl	$0x2, %edx
    27b9:      	movl	$0x4, %eax
    27be:      	movq	%r15, %rdi
    27c1:      	movzwl	(%r12), %edx
    27c6:      	addq	%r14, %rdx
    27c9:      	movl	$0x2, %esi
    27ce:      	callq	*%rax
    27d0:      	testq	%rax, %rax
    27d3:      	js	0x298a <generic_retkprobe_event+0x298a>
    27d9:      	movzbl	0x5(%r12), %eax
    27df:      	cmpl	$0x32, %eax
    27e2:      	jg	0x2800 <generic_retkprobe_event+0x2800>
    27e4:      	testl	%eax, %eax
    27e6:      	je	0x281f <generic_retkprobe_event+0x281f>
    27e8:      	cmpl	$0x2b, %eax
    27eb:      	je	0x281f <generic_retkprobe_event+0x281f>
    27ed:      	cmpl	$0x2c, %eax
    27f0:      	jne	0x284f <generic_retkprobe_event+0x284f>
    27f2:      	movw	$0x8, 0x2(%r12)
    27fa:      	movw	$0x8, %ax
    27fe:      	jmp	0x2855 <generic_retkprobe_event+0x2855>
    2800:      	cmpl	$0x33, %eax
    2803:      	je	0x2837 <generic_retkprobe_event+0x2837>
    2805:      	cmpl	$0x3c, %eax
    2808:      	je	0x281f <generic_retkprobe_event+0x281f>
    280a:      	cmpl	$0xff, %eax
    280f:      	jne	0x284f <generic_retkprobe_event+0x284f>
    2811:      	movw	$0x28, 0x2(%r12)
    2819:      	movw	$0x28, %ax
    281d:      	jmp	0x2855 <generic_retkprobe_event+0x2855>
    281f:      	movq	%r12, %rcx
    2822:      	movzbl	0x7(%r12), %eax
    2828:      	leal	0x8(,%rax,8), %eax
    282f:      	movw	%ax, 0x2(%r12)
    2835:      	jmp	0x2855 <generic_retkprobe_event+0x2855>
    2837:      	movq	%r12, %rcx
    283a:      	movzbl	0x7(%r12), %eax
    2840:      	leal	0x8(,%rax,4), %eax
    2847:      	movw	%ax, 0x2(%r12)
    284d:      	jmp	0x2855 <generic_retkprobe_event+0x2855>
    284f:      	movzwl	0x2(%r12), %eax
    2855:      	movq	%r12, %rcx
    2858:      	addw	(%r12), %ax
    285d:      	movw	%ax, (%r12)
    2862:      	movzbl	0x6(%r12), %ecx
    2868:      	cmpq	$0x3c, %rcx
    286c:      	ja	0x2bd5 <generic_retkprobe_event+0x2bd5>
    2872:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    287c:      	btq	%rcx, %rdx
    2880:      	jae	0x2bd5 <generic_retkprobe_event+0x2bd5>
    2886:      	movb	%cl, 0x5(%r12)
    288b:      	movzwl	%ax, %ecx
    288e:      	addq	%r14, %rcx
    2891:      	movl	$0x2, %edx
    2896:      	movl	$0x4, %eax
    289b:      	movq	%r15, %rdi
    289e:      	movzwl	(%r12), %edx
    28a3:      	addq	%r14, %rdx
    28a6:      	movl	$0x2, %esi
    28ab:      	callq	*%rax
    28ad:      	testq	%rax, %rax
    28b0:      	js	0x298a <generic_retkprobe_event+0x298a>
    28b6:      	movzbl	0x5(%r12), %eax
    28bc:      	cmpl	$0x32, %eax
    28bf:      	jg	0x28dd <generic_retkprobe_event+0x28dd>
    28c1:      	testl	%eax, %eax
    28c3:      	je	0x28fc <generic_retkprobe_event+0x28fc>
    28c5:      	cmpl	$0x2b, %eax
    28c8:      	je	0x28fc <generic_retkprobe_event+0x28fc>
    28ca:      	cmpl	$0x2c, %eax
    28cd:      	jne	0x292c <generic_retkprobe_event+0x292c>
    28cf:      	movw	$0x8, 0x2(%r12)
    28d7:      	movw	$0x8, %ax
    28db:      	jmp	0x2932 <generic_retkprobe_event+0x2932>
    28dd:      	cmpl	$0x33, %eax
    28e0:      	je	0x2914 <generic_retkprobe_event+0x2914>
    28e2:      	cmpl	$0x3c, %eax
    28e5:      	je	0x28fc <generic_retkprobe_event+0x28fc>
    28e7:      	cmpl	$0xff, %eax
    28ec:      	jne	0x292c <generic_retkprobe_event+0x292c>
    28ee:      	movw	$0x28, 0x2(%r12)
    28f6:      	movw	$0x28, %ax
    28fa:      	jmp	0x2932 <generic_retkprobe_event+0x2932>
    28fc:      	movq	%r12, %rcx
    28ff:      	movzbl	0x7(%r12), %eax
    2905:      	leal	0x8(,%rax,8), %eax
    290c:      	movw	%ax, 0x2(%r12)
    2912:      	jmp	0x2932 <generic_retkprobe_event+0x2932>
    2914:      	movq	%r12, %rcx
    2917:      	movzbl	0x7(%r12), %eax
    291d:      	leal	0x8(,%rax,4), %eax
    2924:      	movw	%ax, 0x2(%r12)
    292a:      	jmp	0x2932 <generic_retkprobe_event+0x2932>
    292c:      	movzwl	0x2(%r12), %eax
    2932:      	movq	%r12, %rcx
    2935:      	addw	(%r12), %ax
    293a:      	movw	%ax, (%r12)
    293f:      	movzbl	0x6(%r12), %ecx
    2945:      	cmpq	$0x3c, %rcx
    2949:      	ja	0x2bd5 <generic_retkprobe_event+0x2bd5>
    294f:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2959:      	btq	%rcx, %rdx
    295d:      	jae	0x2bd5 <generic_retkprobe_event+0x2bd5>
    2963:      	movb	%cl, 0x5(%r12)
    2968:      	movzwl	%ax, %ecx
    296b:      	addq	%r14, %rcx
    296e:      	movl	$0x2, %edx
    2973:      	movl	$0x4, %eax
    2978:      	movzwl	(%r12), %edx
    297d:      	addq	%r14, %rdx
    2980:      	movq	%r15, %rdi
    2983:      	movl	$0x2, %esi
    2988:      	callq	*%rax
    298a:      	xorl	%ecx, %ecx
    298c:      	movb	%cl, 0xd0(%rsp)
    2993:      	movzbl	%cl, %eax
    2996:      	movq	0x8(%rsp), %r14
    299b:      	movw	%ax, 0xc0(%r14)
    29a3:      	movw	$0xa, 0xc2(%r14)
    29ad:      	leaq	0x8(%r13), %rdx
    29b1:      	movl	$0x10, %ecx
    29b6:      	movl	$0x4, %eax
    29bb:      	movq	0x10(%rsp), %rdi
    29c0:      	movl	$0x10, %esi
    29c5:      	callq	*%rax
    29c7:      	leaq	0xac(%r14), %rdi
    29ce:      	addq	$0x18, %r13
    29d2:      	movl	$0x10, %ecx
    29d7:      	movl	$0x4, %eax
    29dc:      	movl	$0x10, %esi
    29e1:      	movq	%r13, %rdx
    29e4:      	callq	*%rax
    29e6:      	movzbl	0xd0(%rsp), %eax
    29ee:      	cmpl	$0x11, %eax
    29f1:      	je	0x2a48 <generic_retkprobe_event+0x2a48>
    29f3:      	cmpl	$0x6, %eax
    29f6:      	jne	0x2a9b <generic_retkprobe_event+0x2a9b>
    29fc:      	movq	0x30(%rsp), %r14
    2a01:      	movzwl	0xd8(%rsp), %r15d
    2a0a:      	leaq	(%r14,%r15), %rdx
    2a0e:      	movq	0x8(%rsp), %r12
    2a13:      	leaq	0xbc(%r12), %rdi
    2a1b:      	movl	$0x2, %ecx
    2a20:      	movl	$0x4, %eax
    2a25:      	movl	$0x2, %esi
    2a2a:      	callq	*%rax
    2a2c:      	leaq	0xbe(%r12), %rdi
    2a34:      	leaq	(%r14,%r15), %rdx
    2a38:      	addq	$0x2, %rdx
    2a3c:      	movl	$0x2, %ecx
    2a41:      	movl	$0x4, %eax
    2a46:      	jmp	0x2a92 <generic_retkprobe_event+0x2a92>
    2a48:      	movq	0x30(%rsp), %r14
    2a4d:      	movzwl	0xd8(%rsp), %r15d
    2a56:      	leaq	(%r14,%r15), %rdx
    2a5a:      	movq	0x8(%rsp), %r12
    2a5f:      	leaq	0xbc(%r12), %rdi
    2a67:      	movl	$0x2, %ecx
    2a6c:      	movl	$0x4, %eax
    2a71:      	movl	$0x2, %esi
    2a76:      	callq	*%rax
    2a78:      	leaq	0xbe(%r12), %rdi
    2a80:      	leaq	(%r14,%r15), %rdx
    2a84:      	addq	$0x2, %rdx
    2a88:      	movl	$0x2, %ecx
    2a8d:      	movl	$0x4, %eax
    2a92:      	movl	$0x2, %esi
    2a97:      	callq	*%rax
    2a99:      	jmp	0x2aaa <generic_retkprobe_event+0x2aaa>
    2a9b:      	movq	0x8(%rsp), %rax
    2aa0:      	movl	$0x0, 0xbc(%rax)
    2aaa:      	movq	0x8(%rsp), %rax
    2aaf:      	movzwl	0xbc(%rax), %ecx
    2ab6:      	movzwl	0xbe(%rax), %edx
    2abd:      	movbew	%cx, 0xbc(%rax)
    2ac6:      	movbew	%dx, 0xbe(%rax)
    2acf:      	addq	$0xe0, %rbp
    2ad6:      	leaq	0x70(%rsp), %rdi
    2adb:      	movl	$0x8, %ecx
    2ae0:      	movl	$0x4, %eax
    2ae5:      	movl	$0x4, %r14d
    2aeb:      	movl	$0x8, %esi
    2af0:      	movq	%rbp, %rdx
    2af3:      	callq	*%rax
    2af5:      	movq	0x70(%rsp), %rcx
    2afa:      	testq	%rcx, %rcx
    2afd:      	je	0x2b70 <generic_retkprobe_event+0x2b70>
    2aff:      	addq	$0x5, %rcx
    2b03:      	leaq	0xa0(%rsp), %rdi
    2b0b:      	movl	$0x8, %edx
    2b10:      	movl	$0x4, %eax
    2b15:      	movq	0x70(%rsp), %rdx
    2b1a:      	addq	$0x5, %rdx
    2b1e:      	movl	$0x8, %esi
    2b23:      	callq	*%rax
    2b25:      	movq	0x70(%rsp), %r15
    2b2a:      	movq	0xa0(%rsp), %r12
    2b32:      	movq	0x8(%rsp), %r13
    2b37:      	leaq	0xd4(%r13), %rdi
    2b3e:      	leaq	(%r15,%r12,8), %rdx
    2b42:      	addq	$0x44, %rdx
    2b46:      	movl	$0x4, %eax
    2b4b:      	movl	$0x4, %esi
    2b50:      	callq	*%rax
    2b52:      	movq	%r13, %rdi
    2b55:      	addq	$0xd8, %rdi
    2b5c:      	leaq	(%r15,%r12,8), %rdx
    2b60:      	addq	$0x45, %rdx
    2b64:      	movl	$0x4, %eax
    2b69:      	movl	$0x4, %esi
    2b6e:      	callq	*%rax
    2b70:      	movl	$0x40, %r13d
    2b76:      	movq	0x8(%rsp), %rcx
    2b7b:      	movq	0x18(%rsp), %r12
    2b80:      	movq	0x90(%rsp), %r15
    2b88:      	movl	$0x4, %r14d
    2b8e:      	testl	%r13d, %r13d
    2b91:      	js	0x2ba3 <generic_retkprobe_event+0x2ba3>
    2b93:      	andl	$0x7fffffff, %r13d      # imm = 0x7FFFFFFF
    2b9a:      	addq	$0x4, %r13
    2b9e:      	movq	%r13, %r14
    2ba1:      	jmp	0x2bb7 <generic_retkprobe_event+0x2bb7>
    2ba3:      	movl	$0xffffffff, 0x5ea0(%rcx) # imm = 0xFFFFFFFF
    2bad:      	movl	$0xffffffff, 0x98(%rcx) # imm = 0xFFFFFFFF
    2bb7:      	movq	0xc0(%rsp), %r13
    2bbf:      	addq	$0x8, %r14
    2bc3:      	movl	0x60(%r15), %eax
    2bc7:      	cmpl	$0xb, %eax
    2bca:      	jne	0x1bb <generic_retkprobe_event+0x1bb>
    2bd0:      	jmp	0x307 <generic_retkprobe_event+0x307>
    2bd5:      	movw	%ax, 0xd8(%rsp)
    2bdd:      	jmp	0x298c <generic_retkprobe_event+0x298c>
    2be2:      	xorl	%eax, %eax
    2be4:      	movq	%rax, 0x28(%rsp)
    2be9:      	cmpq	$0x5, 0x88(%rsp)
    2bf2:      	je	0x2221 <generic_retkprobe_event+0x2221>
    2bf8:      	movq	0x98(%rsp), %rax
    2c00:      	leaq	0x50(%rax), %rdx
    2c04:      	leaq	0x30(%rsp), %rdi
    2c09:      	movl	$0x4, %ebp
    2c0e:      	movl	$0x10, %ecx
    2c13:      	movl	$0x4, %eax
    2c18:      	movl	$0x10, %esi
    2c1d:      	callq	*%rax
    2c1f:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2c24:      	testl	%eax, %eax
    2c26:      	js	0x2d70 <generic_retkprobe_event+0x2d70>
    2c2c:      	movq	0x38(%rsp), %rdx
    2c31:      	movq	0x28(%rsp), %rax
    2c36:      	cmpq	%rax, %rdx
    2c39:      	movq	%rax, %r12
    2c3c:      	cmovbq	%rdx, %r12
    2c40:      	testq	%rax, %rax
    2c43:      	cmovneq	%r12, %rdx
    2c47:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2c4c:      	movq	%rdx, 0x8(%rsp)
    2c51:      	cmpq	$0xffe, %rdx            # imm = 0xFFE
    2c58:      	ja	0x2d70 <generic_retkprobe_event+0x2d70>
    2c5e:      	movq	0x80(%rsp), %rdi
    2c66:      	addq	%r15, %rdi
    2c69:      	movq	%rdi, 0x80(%rsp)
    2c71:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2c77:      	addq	0x18(%rsp), %rdi
    2c7c:      	movq	0x30(%rsp), %rcx
    2c81:      	movl	$0x4, %eax
    2c86:      	movq	0x8(%rsp), %rsi
    2c8b:      	movq	0x30(%rsp), %rdx
    2c90:      	callq	*%rax
    2c92:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2c97:      	testl	%eax, %eax
    2c99:      	js	0x2d70 <generic_retkprobe_event+0x2d70>
    2c9f:      	movq	0x10(%rsp), %rax
    2ca4:      	addq	0x8(%rsp), %rax
    2ca9:      	movq	%rax, 0x10(%rsp)
    2cae:      	cmpq	$0x0, 0x28(%rsp)
    2cb4:      	je	0x2cc2 <generic_retkprobe_event+0x2cc2>
    2cb6:      	subq	%r12, 0x28(%rsp)
    2cbb:      	jne	0x2cc9 <generic_retkprobe_event+0x2cc9>
    2cbd:      	jmp	0x2221 <generic_retkprobe_event+0x2221>
    2cc2:      	xorl	%eax, %eax
    2cc4:      	movq	%rax, 0x28(%rsp)
    2cc9:      	cmpq	$0x7, 0x88(%rsp)
    2cd2:      	jb	0x2221 <generic_retkprobe_event+0x2221>
    2cd8:      	movq	0x98(%rsp), %rdx
    2ce0:      	addq	$0x60, %rdx
    2ce4:      	leaq	0x30(%rsp), %rdi
    2ce9:      	movl	$0x4, %ebp
    2cee:      	movl	$0x10, %ecx
    2cf3:      	movl	$0x4, %eax
    2cf8:      	movl	$0x10, %esi
    2cfd:      	callq	*%rax
    2cff:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2d04:      	testl	%eax, %eax
    2d06:      	js	0x2d70 <generic_retkprobe_event+0x2d70>
    2d08:      	movq	0x38(%rsp), %rax
    2d0d:      	movq	0x28(%rsp), %rcx
    2d12:      	cmpq	%rcx, %rax
    2d15:      	movq	%rcx, %r12
    2d18:      	cmovbq	%rax, %r12
    2d1c:      	testq	%rcx, %rcx
    2d1f:      	cmoveq	%rax, %r12
    2d23:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2d28:      	cmpq	$0xffe, %r12            # imm = 0xFFE
    2d2f:      	ja	0x2d70 <generic_retkprobe_event+0x2d70>
    2d31:      	movq	0x8(%rsp), %rdi
    2d36:      	addq	0x80(%rsp), %rdi
    2d3e:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2d44:      	addq	0x18(%rsp), %rdi
    2d49:      	movq	0x30(%rsp), %rcx
    2d4e:      	movl	$0x4, %eax
    2d53:      	movq	0x30(%rsp), %rdx
    2d58:      	movl	%r12d, %esi
    2d5b:      	callq	*%rax
    2d5d:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2d62:      	testl	%eax, %eax
    2d64:      	js	0x2d70 <generic_retkprobe_event+0x2d70>
    2d66:      	addq	0x10(%rsp), %r12
    2d6b:      	jmp	0x43d <generic_retkprobe_event+0x43d>
    2d70:      	movq	0x18(%rsp), %rax
    2d75:      	movl	%ecx, (%rax,%r14)
    2d79:      	addq	%r14, %rbp
    2d7c:      	movq	%rbp, %r14
    2d7f:      	movq	0xc0(%rsp), %r13
    2d87:      	movl	$0x23, %eax
    2d8c:      	callq	*%rax
    2d8e:      	movq	%rax, %rcx
    2d91:      	movq	%rax, 0x30(%rsp)
    2d96:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    2d9d:      	leaq	0xa0(%rsp), %rdi
    2da5:      	movl	$0x4, %edx
    2daa:      	movl	$0x71, %eax
    2daf:      	movl	$0xaf4, %edx            # imm = 0xAF4
    2db4:      	addq	0x30(%rsp), %rdx
    2db9:      	movl	$0x4, %esi
    2dbe:      	callq	*%rax
    2dc0:      	movl	0xa0(%rsp), %eax
    2dc7:      	movl	%eax, 0x70(%rsp)
    2dcb:      	movq	(%rip), %rdi            # 0x2dd2 <generic_retkprobe_event+0x2dd2>
    2dd2:      	leaq	0x70(%rsp), %rsi
    2dd7:      	movl	$0x1, %eax
    2ddc:      	callq	*%rax
    2dde:      	testq	%rax, %rax
    2de1:      	je	0x2df1 <generic_retkprobe_event+0x2df1>
    2de3:      	movq	%rax, %r15
    2de6:      	cmpq	$0x0, 0x8(%rax)
    2deb:      	jne	0x2fc7 <generic_retkprobe_event+0x2fc7>
    2df1:      	movl	$0xb00, %edx            # imm = 0xB00
    2df6:      	movq	0x30(%rsp), %rcx
    2dfb:      	addq	%rdx, %rcx
    2dfe:      	leaq	0x30(%rsp), %rdi
    2e03:      	movl	$0x8, %esi
    2e08:      	movl	$0x71, %eax
    2e0d:      	addq	0x30(%rsp), %rdx
    2e12:      	movl	$0x8, %esi
    2e17:      	callq	*%rax
    2e19:      	movq	0x30(%rsp), %rcx
    2e1e:      	testq	%rcx, %rcx
    2e21:      	je	0x2fc4 <generic_retkprobe_event+0x2fc4>
    2e27:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    2e2e:      	leaq	0xa0(%rsp), %rdi
    2e36:      	movl	$0x4, %edx
    2e3b:      	movl	$0x71, %eax
    2e40:      	movl	$0xaf4, %edx            # imm = 0xAF4
    2e45:      	addq	0x30(%rsp), %rdx
    2e4a:      	movl	$0x4, %esi
    2e4f:      	callq	*%rax
    2e51:      	movl	0xa0(%rsp), %eax
    2e58:      	movl	%eax, 0x70(%rsp)
    2e5c:      	movq	(%rip), %rdi            # 0x2e63 <generic_retkprobe_event+0x2e63>
    2e63:      	leaq	0x70(%rsp), %rsi
    2e68:      	movl	$0x1, %eax
    2e6d:      	callq	*%rax
    2e6f:      	testq	%rax, %rax
    2e72:      	je	0x2e82 <generic_retkprobe_event+0x2e82>
    2e74:      	movq	%rax, %r15
    2e77:      	cmpq	$0x0, 0x8(%rax)
    2e7c:      	jne	0x2fc7 <generic_retkprobe_event+0x2fc7>
    2e82:      	movl	$0xb00, %edx            # imm = 0xB00
    2e87:      	movq	0x30(%rsp), %rcx
    2e8c:      	addq	%rdx, %rcx
    2e8f:      	leaq	0x30(%rsp), %rdi
    2e94:      	movl	$0x8, %esi
    2e99:      	movl	$0x71, %eax
    2e9e:      	addq	0x30(%rsp), %rdx
    2ea3:      	movl	$0x8, %esi
    2ea8:      	callq	*%rax
    2eaa:      	movq	0x30(%rsp), %rcx
    2eaf:      	testq	%rcx, %rcx
    2eb2:      	je	0x2fc4 <generic_retkprobe_event+0x2fc4>
    2eb8:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    2ebf:      	leaq	0xa0(%rsp), %rdi
    2ec7:      	movl	$0x4, %edx
    2ecc:      	movl	$0x71, %eax
    2ed1:      	movl	$0xaf4, %edx            # imm = 0xAF4
    2ed6:      	addq	0x30(%rsp), %rdx
    2edb:      	movl	$0x4, %esi
    2ee0:      	callq	*%rax
    2ee2:      	movl	0xa0(%rsp), %eax
    2ee9:      	movl	%eax, 0x70(%rsp)
    2eed:      	movq	(%rip), %rdi            # 0x2ef4 <generic_retkprobe_event+0x2ef4>
    2ef4:      	leaq	0x70(%rsp), %rsi
    2ef9:      	movl	$0x1, %eax
    2efe:      	callq	*%rax
    2f00:      	testq	%rax, %rax
    2f03:      	je	0x2f13 <generic_retkprobe_event+0x2f13>
    2f05:      	movq	%rax, %r15
    2f08:      	cmpq	$0x0, 0x8(%rax)
    2f0d:      	jne	0x2fc7 <generic_retkprobe_event+0x2fc7>
    2f13:      	movl	$0xb00, %edx            # imm = 0xB00
    2f18:      	movq	0x30(%rsp), %rcx
    2f1d:      	addq	%rdx, %rcx
    2f20:      	leaq	0x30(%rsp), %rdi
    2f25:      	movl	$0x8, %esi
    2f2a:      	movl	$0x71, %eax
    2f2f:      	addq	0x30(%rsp), %rdx
    2f34:      	movl	$0x8, %esi
    2f39:      	callq	*%rax
    2f3b:      	movq	0x30(%rsp), %rcx
    2f40:      	testq	%rcx, %rcx
    2f43:      	je	0x2fc4 <generic_retkprobe_event+0x2fc4>
    2f45:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    2f4c:      	leaq	0xa0(%rsp), %rdi
    2f54:      	movl	$0x4, %edx
    2f59:      	movl	$0x71, %eax
    2f5e:      	movl	$0xaf4, %edx            # imm = 0xAF4
    2f63:      	addq	0x30(%rsp), %rdx
    2f68:      	movl	$0x4, %esi
    2f6d:      	callq	*%rax
    2f6f:      	movl	0xa0(%rsp), %eax
    2f76:      	movl	%eax, 0x70(%rsp)
    2f7a:      	movq	(%rip), %rdi            # 0x2f81 <generic_retkprobe_event+0x2f81>
    2f81:      	leaq	0x70(%rsp), %rsi
    2f86:      	movl	$0x1, %eax
    2f8b:      	callq	*%rax
    2f8d:      	testq	%rax, %rax
    2f90:      	je	0x2f9c <generic_retkprobe_event+0x2f9c>
    2f92:      	movq	%rax, %r15
    2f95:      	cmpq	$0x0, 0x8(%rax)
    2f9a:      	jne	0x2fc7 <generic_retkprobe_event+0x2fc7>
    2f9c:      	movl	$0xb00, %edx            # imm = 0xB00
    2fa1:      	movq	0x30(%rsp), %rcx
    2fa6:      	addq	%rdx, %rcx
    2fa9:      	leaq	0x30(%rsp), %rdi
    2fae:      	movl	$0x8, %esi
    2fb3:      	movl	$0x71, %eax
    2fb8:      	addq	0x30(%rsp), %rdx
    2fbd:      	movl	$0x8, %esi
    2fc2:      	callq	*%rax
    2fc4:      	xorl	%r15d, %r15d
    2fc7:      	movl	$0x10d, (%rbx)          # imm = 0x10D
    2fcd:      	movl	%r14d, 0x4(%rbx)
    2fd1:      	movl	$0x7d, %eax
    2fd6:      	callq	*%rax
    2fd8:      	movq	%rax, 0x8(%rbx)
    2fdc:      	testq	%r15, %r15
    2fdf:      	je	0x2fef <generic_retkprobe_event+0x2fef>
    2fe1:      	movl	(%r15), %eax
    2fe4:      	movl	%eax, 0x10(%rbx)
    2fe7:      	movq	0x8(%r15), %rax
    2feb:      	movq	%rax, 0x18(%rbx)
    2fef:      	movl	$0x0, 0x14(%rbx)
    2ff6:      	movq	0x90(%rsp), %rax
    2ffe:      	movl	(%rax), %eax
    3000:      	movq	%rax, 0x60(%rbx)
    3004:      	movl	%r14d, 0x4(%rbx)
    3008:      	movq	(%rip), %rsi            # 0x300f <generic_retkprobe_event+0x300f>
    300f:      	movl	$0x3, %ecx
    3014:      	movl	$0xc, %eax
    3019:      	movq	%r13, %rdi
    301c:      	movl	$0x3, %edx
    3021:      	callq	*%rax
    3023:      	movl	$0x1, %ebp
    3028:      	movl	%ebp, %eax
    302a:      	addq	$0xf8, %rsp
    3031:      	popq	%rbx
    3032:      	popq	%r12
    3034:      	popq	%r13
    3036:      	popq	%r14
    3038:      	popq	%r15
    303a:      	popq	%rbp
    303b:      	retq
